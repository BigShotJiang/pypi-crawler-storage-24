"""Auth commands for bb2gh CLI.

Provides `bb2gh auth login`, `bb2gh auth status`, and `bb2gh auth logout`
subcommands for managing authentication credentials.
"""

from __future__ import annotations

import contextlib
import sys
from typing import TYPE_CHECKING, Any

import typer

if TYPE_CHECKING:
    from bb2gh.adapters.bitbucket_dc import BitbucketDCAdapter
    from bb2gh.services.credential_store import CredentialStore

auth_app = typer.Typer(
    name="auth",
    help="Manage authentication credentials.",
    no_args_is_help=True,
)


def _is_interactive() -> bool:
    """Check if stdin is an interactive TTY."""
    return sys.stdin.isatty()


async def _validate_bitbucket_credentials(username: str, api_token: str) -> bool:
    """Validate Bitbucket credentials by calling the API.

    Args:
        username: Bitbucket username.
        api_token: API token or app password.

    Returns:
        True if credentials are valid, False otherwise.
    """
    from bb2gh.adapters.bitbucket_cloud import BitbucketCloudAdapter

    try:
        adapter = BitbucketCloudAdapter(username=username, api_token=api_token)
        async with adapter:
            await adapter.verify_credentials()
        return True
    except Exception:
        return False


async def _validate_github_credentials(token: str) -> bool:
    """Validate GitHub PAT by calling the API.

    Args:
        token: GitHub personal access token.

    Returns:
        True if credentials are valid, False otherwise.
    """
    from bb2gh.adapters.github_cloud import GitHubCloudAdapter

    try:
        adapter = GitHubCloudAdapter(token=token)
        async with adapter:
            await adapter.verify_credentials()
        return True
    except Exception:
        return False


async def _validate_dc_credentials(base_url: str, token: str) -> bool:
    """Validate Bitbucket DC credentials by calling the API.

    Args:
        base_url: DC base URL.
        token: Personal Access Token.

    Returns:
        True if credentials are valid, False otherwise.
    """
    from bb2gh.adapters.bitbucket_dc import BitbucketDCAdapter

    try:
        adapter = BitbucketDCAdapter(base_url=base_url, token=token, verify_ssl=True)
        async with adapter:
            await adapter.verify_credentials()
        return True
    except Exception:
        return False


async def _verify_dc(adapter: BitbucketDCAdapter) -> None:
    """Verify DC credentials using the adapter."""
    async with adapter:
        await adapter.verify_credentials()


@auth_app.command("dc")
def auth_dc(
    url: str = typer.Option(..., "--url", help="Bitbucket DC base URL"),
    insecure: bool = typer.Option(False, "--insecure", help="Skip SSL verification"),
    profile: str = typer.Option("default", "--profile", help="Profile name"),
    config_dir: str | None = typer.Option(
        None,
        "--config-dir",
        help="Path to config directory. Defaults to ~/.bb2gh",
    ),
) -> None:
    """Authenticate with Bitbucket Data Center using a Personal Access Token."""
    import asyncio
    from pathlib import Path

    from rich.prompt import Prompt

    from bb2gh.adapters.bitbucket_dc import BitbucketDCAdapter as _DCAdapter
    from bb2gh.cli.console import get_shared_console
    from bb2gh.cli.credential_resolver import store_dc_credentials
    from bb2gh.cli.output import print_error, print_success
    from bb2gh.licensing.decorators import LicenseRequiredError
    from bb2gh.licensing.features import require_license

    console = get_shared_console()

    # License check — same pattern as discover.py
    try:
        require_license()
    except LicenseRequiredError as e:
        print_error(str(e))
        raise typer.Exit(1) from None

    token = Prompt.ask("Bitbucket DC Personal Access Token", password=True, console=console)

    verify_ssl: str | bool = not insecure
    adapter = _DCAdapter(base_url=url, token=token, verify_ssl=verify_ssl)

    try:
        asyncio.run(_verify_dc(adapter))
    except Exception as e:
        print_error(f"DC authentication failed: {e}")
        raise typer.Exit(1) from None

    cfg_dir = Path(config_dir) if config_dir else Path.home() / ".bb2gh"
    store_dc_credentials(
        base_url=url,
        token=token,
        verify_ssl=verify_ssl,
        profile_name=profile,
        config_dir=cfg_dir,
    )
    print_success(f"Bitbucket DC credentials verified and stored (profile: {profile})")


@auth_app.command("login")
def login(
    profile: str = typer.Option(
        "default",
        "--profile",
        "-p",
        help="Profile name to configure.",
    ),
    config_dir: str | None = typer.Option(
        None,
        "--config-dir",
        help="Path to config directory. Defaults to ~/.bb2gh",
    ),
) -> None:
    """Interactively set up source and target credentials for a profile.

    Prompts for Bitbucket (source) and GitHub (target) credentials,
    stores secrets in the OS keychain via keyring, and saves non-secret
    configuration to ~/.bb2gh/config.yaml.
    """
    from pathlib import Path

    from rich.prompt import Prompt

    from bb2gh.cli.console import get_shared_console
    from bb2gh.cli.output import (
        print_error,
        print_info,
        print_success,
        print_warning,
    )
    from bb2gh.models.config import (
        MigrationProfile,
        SourceProfile,
        TargetProfile,
    )
    from bb2gh.services.credential_store import CredentialStore
    from bb2gh.utils.config import save_profile_to_config

    console = get_shared_console()

    if not _is_interactive():
        print_error(
            "Interactive login requires a TTY. Use environment variables for non-interactive setup."
        )
        raise typer.Exit(1)

    console.print(f"\n[bold]Configuring profile:[/bold] [cyan]{profile}[/cyan]\n")

    # --- Source (Bitbucket) ---
    console.print("[bold underline]Source (Bitbucket)[/bold underline]")
    source_type = Prompt.ask(
        "Source type",
        choices=["bitbucket-cloud", "bitbucket-dc"],
        default="bitbucket-cloud",
    )

    source_username: str | None = None
    source_client_id: str | None = None
    source_workspace: str | None = None
    source_base_url: str | None = None

    if source_type == "bitbucket-dc":
        source_auth = "pat"
        source_base_url = Prompt.ask("Bitbucket DC base URL (e.g. https://bitbucket.example.com)")
        source_token = Prompt.ask("Personal Access Token", password=True)
    else:
        source_auth = Prompt.ask(
            "Auth method",
            choices=["api-token", "oauth2"],
            default="api-token",
        )
        if source_auth == "api-token":
            source_username = Prompt.ask("Bitbucket username")
            source_token = Prompt.ask("Bitbucket app password / API token", password=True)
        else:
            source_client_id = Prompt.ask("OAuth2 client ID")
            source_token = Prompt.ask("OAuth2 client secret", password=True)

    source_workspace = Prompt.ask(
        "Default workspace (optional, press Enter to skip)",
        default="",
    )
    if not source_workspace:
        source_workspace = None

    # --- Target (GitHub) ---
    console.print("\n[bold underline]Target (GitHub)[/bold underline]")
    target_auth = Prompt.ask(
        "Auth method",
        choices=["pat", "app"],
        default="pat",
    )

    target_org: str | None = None
    target_app_id: int | None = None
    target_installation_id: int | None = None
    target_app_key_file: Path | None = None

    if target_auth == "pat":
        target_token = Prompt.ask("GitHub personal access token", password=True)
    else:
        target_app_id = int(Prompt.ask("GitHub App ID"))
        target_installation_id = int(Prompt.ask("Installation ID"))
        key_file = Prompt.ask("Path to private key PEM file")
        target_app_key_file = Path(key_file)
        target_token = ""  # No token needed for app auth

    target_org = Prompt.ask(
        "Default GitHub organization (optional, press Enter to skip)",
        default="",
    )
    if not target_org:
        target_org = None

    # --- Validate credentials ---
    import asyncio

    if source_type == "bitbucket-dc" and source_token and source_base_url:
        print_info("Validating Bitbucket DC credentials...")
        valid = asyncio.run(_validate_dc_credentials(source_base_url, source_token))
        if valid:
            print_success("Bitbucket DC credentials valid!")
        else:
            print_warning("Could not validate Bitbucket DC credentials. They will be saved anyway.")
    elif source_auth == "api-token" and source_token:
        print_info("Validating Bitbucket credentials...")
        valid = asyncio.run(_validate_bitbucket_credentials(source_username or "", source_token))
        if valid:
            print_success("Bitbucket credentials valid!")
        else:
            print_warning("Could not validate Bitbucket credentials. They will be saved anyway.")

    if target_auth == "pat" and target_token:
        print_info("Validating GitHub credentials...")
        valid = asyncio.run(_validate_github_credentials(target_token))
        if valid:
            print_success("GitHub credentials valid!")
        else:
            print_warning("Could not validate GitHub credentials. They will be saved anyway.")

    # --- Store secrets ---
    store = CredentialStore.auto_detect()

    if source_type == "bitbucket-dc":
        store.set_secret(f"bb2gh:{profile}:source:pat", source_token)
    elif source_auth == "api-token":
        store.set_secret(f"bb2gh:{profile}:source:api_token", source_token)
    else:
        store.set_secret(f"bb2gh:{profile}:source:client_secret", source_token)

    if target_auth == "pat" and target_token:
        store.set_secret(f"bb2gh:{profile}:target:token", target_token)

    # --- Build profile ---
    source_kwargs: dict[str, Any] = {
        "type": source_type,
        "auth_method": source_auth,
        "username": source_username,
        "client_id": source_client_id,
        "workspace": source_workspace,
    }
    if source_base_url:
        source_kwargs["base_url"] = source_base_url
    source_profile = SourceProfile(**source_kwargs)
    target_profile = TargetProfile(
        type="github-cloud",
        auth_method=target_auth,  # type: ignore[arg-type]
        organization=target_org,
        app_id=target_app_id,
        installation_id=target_installation_id,
        app_private_key_file=target_app_key_file,
    )
    migration_profile = MigrationProfile(source=source_profile, target=target_profile)

    # --- Save to config ---
    cfg_dir = Path(config_dir) if config_dir else Path.home() / ".bb2gh"
    config_path = cfg_dir / "config.yaml"
    save_profile_to_config(config_path, profile, migration_profile)

    console.print()
    print_success(f"Profile '{profile}' configured successfully!")
    print_info("Secrets stored in OS keychain.")
    print_info(f"Config saved to {config_path}")
    console.print(
        "\n[dim]Next steps:[/dim]"
        "\n  bb2gh auth status          # verify credentials"
        "\n  bb2gh discover -w <ws>     # discover repositories"
    )


@auth_app.command("status")
def status(
    profile: str | None = typer.Option(
        None,
        "--profile",
        "-p",
        help="Show status for a specific profile. Shows all if omitted.",
    ),
    config_dir: str | None = typer.Option(
        None,
        "--config-dir",
        help="Path to config directory. Defaults to ~/.bb2gh",
    ),
) -> None:
    """Show configured profiles and credential availability."""
    from pathlib import Path

    from rich.table import Table

    from bb2gh.cli.console import get_shared_console
    from bb2gh.cli.output import print_info
    from bb2gh.services.credential_store import CredentialStore
    from bb2gh.utils.config import load_profiles_from_config

    console = get_shared_console()
    cfg_dir = Path(config_dir) if config_dir else Path.home() / ".bb2gh"
    config_path = cfg_dir / "config.yaml"

    profiles = load_profiles_from_config(config_path)

    if profile:
        if profile not in profiles:
            print_info(f"Profile '{profile}' not found.")
            return
        profiles = {profile: profiles[profile]}

    if not profiles:
        print_info("No profiles configured. Run 'bb2gh auth login' to set up.")
        return

    store = CredentialStore.auto_detect()

    table = Table(title="Authentication Profiles")
    table.add_column("Profile", style="cyan")
    table.add_column("Source", style="bold")
    table.add_column("Source Auth")
    table.add_column("Source Creds", justify="center")
    table.add_column("Target", style="bold")
    table.add_column("Target Auth")
    table.add_column("Target Creds", justify="center")

    for name, prof in profiles.items():
        # Check source credentials
        src = prof.source
        if src.auth_method == "api-token":
            src_key = f"bb2gh:{name}:source:api_token"
        else:
            src_key = f"bb2gh:{name}:source:client_secret"
        src_cred = "[green]OK[/green]" if store.get_secret(src_key) else "[red]MISSING[/red]"

        # Check target credentials
        tgt = prof.target
        if tgt.auth_method == "pat":
            tgt_key = f"bb2gh:{name}:target:token"
            tgt_cred = "[green]OK[/green]" if store.get_secret(tgt_key) else "[red]MISSING[/red]"
        else:
            # App auth uses key file, not keyring secret
            tgt_cred = (
                "[green]OK[/green]"
                if tgt.app_private_key_file and tgt.app_private_key_file.exists()
                else "[yellow]KEY FILE[/yellow]"
            )

        table.add_row(
            name,
            src.type,
            src.auth_method,
            src_cred,
            tgt.type,
            tgt.auth_method,
            tgt_cred,
        )

    console.print()
    console.print(table)
    console.print()


@auth_app.command("logout")
def logout(
    profile: str = typer.Option(
        "default",
        "--profile",
        "-p",
        help="Profile to remove credentials for.",
    ),
    all_profiles: bool = typer.Option(
        False,
        "--all",
        help="Remove credentials for all profiles.",
    ),
    config_dir: str | None = typer.Option(
        None,
        "--config-dir",
        help="Path to config directory. Defaults to ~/.bb2gh",
    ),
) -> None:
    """Remove stored credentials for a profile."""
    from pathlib import Path

    from bb2gh.cli.console import get_shared_console
    from bb2gh.cli.output import print_info, print_success, print_warning
    from bb2gh.services.credential_store import (
        CredentialStore,
        StorageBackend,
    )
    from bb2gh.utils.config import load_profiles_from_config

    console = get_shared_console()
    cfg_dir = Path(config_dir) if config_dir else Path.home() / ".bb2gh"
    config_path = cfg_dir / "config.yaml"

    store = CredentialStore.auto_detect()

    if store.backend == StorageBackend.ENV:
        print_warning(
            "Using ENV backend (read-only). "
            "Unset environment variables manually to remove credentials."
        )
        return

    profiles = load_profiles_from_config(config_path)

    names = list(profiles.keys()) if all_profiles else [profile]

    if not names:
        print_info("No profiles found.")
        return

    for name in names:
        _delete_profile_secrets(store, name)
        console.print(f"  Removed credentials for profile: [cyan]{name}[/cyan]")

    print_success(f"Cleared credentials for {len(names)} profile(s).")
    print_info("Profile config remains in config.yaml. Run 'bb2gh auth login' to re-configure.")


def _delete_profile_secrets(store: CredentialStore, profile: str) -> None:
    """Delete all known secret keys for a profile.

    Args:
        store: The credential store to delete from.
        profile: The profile name.
    """
    keys = [
        f"bb2gh:{profile}:source:api_token",
        f"bb2gh:{profile}:source:client_secret",
        f"bb2gh:{profile}:source:pat",
        f"bb2gh:{profile}:target:token",
    ]
    for key in keys:
        with contextlib.suppress(Exception):
            store.delete_secret(key)
