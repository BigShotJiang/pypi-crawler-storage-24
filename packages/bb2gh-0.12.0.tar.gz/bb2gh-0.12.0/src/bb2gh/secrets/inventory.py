"""Secrets inventory service for bb2gh.

Discovers and inventories secrets from source platforms.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

import structlog

from bb2gh.models.secret import (
    Secret,
    SecretInventory,
    SecretScope,
    SecretType,
    SecretVisibility,
)

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

    from bb2gh.adapters.base import SourceAdapter

logger = structlog.get_logger(__name__)


class SecretsInventoryService:
    """Service for discovering and inventorying secrets."""

    def __init__(
        self,
        *,
        source_adapter: SourceAdapter,
    ) -> None:
        """Initialize SecretsInventoryService.

        Args:
            source_adapter: Adapter for source platform.
        """
        self._source = source_adapter

    async def discover_secrets(
        self,
        workspace: str,
        *,
        repositories: list[str] | None = None,
    ) -> SecretInventory:
        """Discover all secrets in a workspace.

        Args:
            workspace: Workspace/organization name.
            repositories: Optional list of specific repositories to scan.

        Returns:
            SecretInventory with all discovered secrets.
        """
        inventory = SecretInventory(
            source_workspace=workspace,
            source_platform="bitbucket",
            discovered_at=datetime.now(UTC),
        )

        log = logger.bind(workspace=workspace)
        log.info("discovering_secrets")

        # Discover workspace-level variables
        try:
            async for var in self._list_workspace_variables(workspace):
                secret = Secret(
                    name=var["key"],
                    secret_type=SecretType.WORKSPACE_VARIABLE,
                    scope=SecretScope.WORKSPACE,
                    visibility=SecretVisibility.SECURED
                    if var.get("secured")
                    else SecretVisibility.PLAINTEXT,
                    workspace=workspace,
                )
                inventory.secrets.append(secret)
        except NotImplementedError:
            log.debug("workspace_variables_not_supported")
        except Exception as e:
            log.warning("workspace_variables_error", error=str(e))

        # Discover repository-level secrets
        if repositories:
            repo_list = repositories
        else:
            # Get all repositories in workspace
            repo_list = []
            try:
                repos = await self._source.list_repositories(workspace=workspace)
                repo_list = [r.full_name for r in repos]
            except Exception as e:
                log.warning("list_repositories_error", error=str(e))

        for repo_full_name in repo_list:
            await self._discover_repository_secrets(inventory, repo_full_name)

        log.info(
            "secrets_discovered",
            total=len(inventory.secrets),
            by_scope=inventory.by_scope,
        )

        return inventory

    async def _discover_repository_secrets(
        self,
        inventory: SecretInventory,
        repo_full_name: str,
    ) -> None:
        """Discover secrets for a specific repository.

        Args:
            inventory: Inventory to add secrets to.
            repo_full_name: Full repository name (workspace/repo).
        """
        log = logger.bind(repo=repo_full_name)

        # Pipeline variables (repository-level)
        try:
            async for var in self._list_pipeline_variables(repo_full_name):
                secret = Secret(
                    name=var["key"],
                    secret_type=SecretType.PIPELINE_VARIABLE,
                    scope=SecretScope.REPOSITORY,
                    visibility=SecretVisibility.SECURED
                    if var.get("secured")
                    else SecretVisibility.PLAINTEXT,
                    repository=repo_full_name,
                )
                inventory.secrets.append(secret)
        except NotImplementedError:
            log.debug("pipeline_variables_not_supported")
        except Exception as e:
            log.warning("pipeline_variables_error", error=str(e))

        # Deployment environment variables
        try:
            async for env in self._list_deployment_environments(repo_full_name):
                env_name = env.get("name", "")
                async for var in self._list_environment_variables(repo_full_name, env_name):
                    secret = Secret(
                        name=var["key"],
                        secret_type=SecretType.DEPLOYMENT_VARIABLE,
                        scope=SecretScope.ENVIRONMENT,
                        visibility=SecretVisibility.SECURED
                        if var.get("secured")
                        else SecretVisibility.PLAINTEXT,
                        repository=repo_full_name,
                        environment=env_name,
                    )
                    inventory.secrets.append(secret)
        except NotImplementedError:
            log.debug("deployment_environments_not_supported")
        except Exception as e:
            log.warning("deployment_environments_error", error=str(e))

    async def _list_workspace_variables(self, workspace: str) -> AsyncIterator[dict[str, Any]]:
        """List workspace-level pipeline variables.

        Args:
            workspace: Workspace name.

        Yields:
            Variable dicts with key, value, secured fields.
        """
        # Call adapter method if available
        if hasattr(self._source, "list_workspace_variables"):
            async for var in self._source.list_workspace_variables(workspace):
                yield var
        else:
            raise NotImplementedError("list_workspace_variables not available")

    async def _list_pipeline_variables(self, repo_full_name: str) -> AsyncIterator[dict[str, Any]]:
        """List repository pipeline variables.

        Args:
            repo_full_name: Full repository name.

        Yields:
            Variable dicts with key, value, secured fields.
        """
        if hasattr(self._source, "list_pipeline_variables"):
            async for var in self._source.list_pipeline_variables(repo_full_name):
                yield var
        else:
            raise NotImplementedError("list_pipeline_variables not available")

    async def _list_deployment_environments(
        self, repo_full_name: str
    ) -> AsyncIterator[dict[str, Any]]:
        """List deployment environments for a repository.

        Args:
            repo_full_name: Full repository name.

        Yields:
            Environment dicts with name, uuid fields.
        """
        if hasattr(self._source, "list_deployment_environments"):
            async for env in self._source.list_deployment_environments(repo_full_name):
                yield env
        else:
            raise NotImplementedError("list_deployment_environments not available")

    async def _list_environment_variables(
        self, repo_full_name: str, env_name: str
    ) -> AsyncIterator[dict[str, Any]]:
        """List variables for a deployment environment.

        Args:
            repo_full_name: Full repository name.
            env_name: Environment name.

        Yields:
            Variable dicts with key, value, secured fields.
        """
        if hasattr(self._source, "list_environment_variables"):
            async for var in self._source.list_environment_variables(repo_full_name, env_name):
                yield var
        else:
            raise NotImplementedError("list_environment_variables not available")
