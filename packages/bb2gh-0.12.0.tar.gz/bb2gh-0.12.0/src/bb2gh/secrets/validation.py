"""Secrets validation service for bb2gh.

Validates that secrets have been properly migrated.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import structlog

from bb2gh.models.secret import (
    SecretInventory,
    SecretScope,
    SecretValidationResult,
)

if TYPE_CHECKING:
    from bb2gh.adapters.base import TargetAdapter

logger = structlog.get_logger(__name__)


class SecretsValidationService:
    """Service for validating secret migrations."""

    def __init__(
        self,
        *,
        target_adapter: TargetAdapter,
    ) -> None:
        """Initialize SecretsValidationService.

        Args:
            target_adapter: Adapter for target platform (GitHub).
        """
        self._target = target_adapter

    async def validate_secrets(
        self,
        inventory: SecretInventory,
        *,
        target_org: str,
        repo_mapping: dict[str, str] | None = None,
    ) -> SecretValidationResult:
        """Validate secrets exist in target platform.

        Args:
            inventory: Source secret inventory.
            target_org: Target GitHub organization.
            repo_mapping: Optional source to target repo mapping.

        Returns:
            SecretValidationResult with comparison.
        """
        result = SecretValidationResult(
            source_count=len(inventory.secrets),
        )

        log = logger.bind(
            target_org=target_org,
            source_count=result.source_count,
        )
        log.info("validating_secrets")

        # Group secrets by repository
        repo_secrets: dict[str, list[str]] = {}
        for secret in inventory.secrets:
            target_repo = self._resolve_target_repo(
                secret.repository,
                target_org,
                repo_mapping,
            )
            if target_repo not in repo_secrets:
                repo_secrets[target_repo] = []
            repo_secrets[target_repo].append(secret.name)

        # Check each repository's secrets
        for repo, expected_secrets in repo_secrets.items():
            try:
                target_secrets = await self._list_repository_secrets(repo)
                result.target_count += len(target_secrets)

                for name in expected_secrets:
                    if name not in target_secrets:
                        result.missing_secrets.append(f"{repo}/{name}")

                for name in target_secrets:
                    if name not in expected_secrets:
                        result.extra_secrets.append(f"{repo}/{name}")

            except Exception as e:
                log.warning("validate_repo_secrets_error", repo=repo, error=str(e))
                # Mark all expected secrets as missing
                for name in expected_secrets:
                    result.missing_secrets.append(f"{repo}/{name}")

        log.info(
            "secrets_validated",
            source_count=result.source_count,
            target_count=result.target_count,
            missing=len(result.missing_secrets),
            extra=len(result.extra_secrets),
            valid=result.is_valid,
        )

        return result

    def _resolve_target_repo(
        self,
        source_repo: str | None,
        target_org: str,
        repo_mapping: dict[str, str] | None,
    ) -> str:
        """Resolve target repository name.

        Args:
            source_repo: Source repository name.
            target_org: Target organization.
            repo_mapping: Optional source to target mapping.

        Returns:
            Target repository full name.
        """
        if not source_repo:
            return target_org

        if repo_mapping and source_repo in repo_mapping:
            return repo_mapping[source_repo]

        _, repo_name = source_repo.split("/", 1)
        return f"{target_org}/{repo_name}"

    async def _list_repository_secrets(self, repo: str) -> list[str]:
        """List secret names in a repository.

        Args:
            repo: Repository full name (org/repo).

        Returns:
            List of secret names.
        """
        if hasattr(self._target, "list_repository_secrets"):
            secrets = []
            async for secret in self._target.list_repository_secrets(repo):
                secrets.append(secret.get("name", ""))
            return secrets
        else:
            raise NotImplementedError("list_repository_secrets not available")

    async def compare_inventories(
        self,
        source_inventory: SecretInventory,
        target_inventory: SecretInventory,
    ) -> SecretValidationResult:
        """Compare two secret inventories.

        Args:
            source_inventory: Source platform inventory.
            target_inventory: Target platform inventory.

        Returns:
            SecretValidationResult with differences.
        """
        result = SecretValidationResult(
            source_count=len(source_inventory.secrets),
            target_count=len(target_inventory.secrets),
        )

        source_names = {s.name for s in source_inventory.secrets}
        target_names = {s.name for s in target_inventory.secrets}

        result.missing_secrets = list(source_names - target_names)
        result.extra_secrets = list(target_names - source_names)

        # Check scope mismatches
        source_by_name = {s.name: s for s in source_inventory.secrets}
        target_by_name = {s.name: s for s in target_inventory.secrets}

        for name in source_names & target_names:
            source_scope = source_by_name[name].scope
            target_scope = target_by_name[name].scope

            # Map scopes (workspace -> org is OK)
            if source_scope == SecretScope.WORKSPACE and target_scope == SecretScope.ORGANIZATION:
                continue
            if source_scope != target_scope:
                result.scope_mismatches.append(
                    f"{name}: {source_scope.value} -> {target_scope.value}"
                )

        return result
