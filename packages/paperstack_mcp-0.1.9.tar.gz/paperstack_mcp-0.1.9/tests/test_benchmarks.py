import os
from pathlib import Path

import pytest

try:
    import pytest_benchmark  # noqa: F401
    HAVE_BENCH = True
except ImportError:
    HAVE_BENCH = False

from src.pdf_parser import PDFParser
from src.arxiv_client import ArxivClient
from src.models import Author, PaperMetadata


def create_sample_pdf(path: Path):
    import fitz
    doc = fitz.open()
    for i in range(2):
        page = doc.new_page()
        page.insert_text((72, 72), f"Page {i+1} sample for benchmark.")
    doc.save(str(path))
    doc.close()


@pytest.mark.skipif(not HAVE_BENCH, reason="pytest-benchmark plugin is not installed")
def test_pdf_parser_benchmark(benchmark, tmp_path):
    file = tmp_path / "benchmark.pdf"
    create_sample_pdf(file)
    parser = PDFParser()

    def parse_action():
        parser.parse(str(file), "1706.03762")

    benchmark(parse_action)


@pytest.mark.skipif(not HAVE_BENCH, reason="pytest-benchmark plugin is not installed")
@pytest.mark.asyncio
async def test_arxiv_search_benchmark(benchmark):
    client = ArxivClient()
    sample_result = [
        PaperMetadata(
            arxiv_id="1706.03762",
            title="Test",
            authors=[Author(name="A")],
            abstract="x",
            categories=["cs.CL"],
            primary_category="cs.CL",
            published="2024-01-01T00:00:00Z",
            updated="2024-01-02T00:00:00Z",
            pdf_url="https://arxiv.org/pdf/1706.03762.pdf",
            entry_url="https://arxiv.org/abs/1706.03762",
        )
    ]

    async def stub_search(*args, **kwargs):
        return sample_result

    client._client.results = stub_search

    async def search_action():
        await client.search("attention transformer NLP", max_results=3)

    benchmark(search_action)
