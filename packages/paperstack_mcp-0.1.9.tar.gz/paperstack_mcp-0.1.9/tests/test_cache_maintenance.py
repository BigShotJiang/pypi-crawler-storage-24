import os
import tempfile
import time
from pathlib import Path

import pytest

from src.cache import evict_stale_cache, purge_old_pdfs, set_paper_metadata, get_paper_metadata
from src.models import PaperMetadata, Author


def test_evict_stale_cache(tmp_path):
    os.environ["ARXIV_CACHE_DB"] = str(tmp_path / "cache.db")

    pm = PaperMetadata(
        arxiv_id="1706.03762",
        title="Test",
        authors=[Author(name="A")],
        abstract="x",
        categories=["cs.CL"],
        primary_category="cs.CL",
        published="2024-01-01T00:00:00Z",
        updated="2024-01-02T00:00:00Z",
        pdf_url="https://arxiv.org/pdf/1706.03762.pdf",
        entry_url="https://arxiv.org/abs/1706.03762",
    )

    set_paper_metadata(pm)
    assert get_paper_metadata("1706.03762") is not None

    # simulate an old entry by directly squashing timestamp
    db_path = Path(os.environ["ARXIV_CACHE_DB"])
    import sqlite3

    conn = sqlite3.connect(str(db_path))
    conn.execute("UPDATE papers SET updated_at = ?", (int(time.time()) - 999999,))
    conn.commit()
    conn.close()

    deleted = evict_stale_cache(max_age_hours=1)
    assert deleted >= 1
    assert get_paper_metadata("1706.03762") is None


def test_purge_old_pdfs(tmp_path):
    # create old file and fresh file
    from src.models import DOWNLOAD_DIR
    old_file = tmp_path / "old.pdf"
    new_file = tmp_path / "new.pdf"
    old_file.write_bytes(b"a" * 1024)
    new_file.write_bytes(b"a" * 1024)
    os.utime(old_file, (time.time() - 40 * 86400, time.time() - 40 * 86400))

    os.environ["ARXIV_DOWNLOAD_DIR"] = str(tmp_path)
    deleted = purge_old_pdfs(max_age_days=30)
    assert deleted == 1
    assert old_file.exists() is False
    assert new_file.exists() is True
