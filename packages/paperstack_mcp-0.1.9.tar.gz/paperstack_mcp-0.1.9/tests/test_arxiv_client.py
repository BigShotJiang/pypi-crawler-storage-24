import asyncio
import json
import os
from pathlib import Path
from unittest.mock import AsyncMock, patch

import pytest

from src.arxiv_client import ArxivClient, detect_arxiv_id, normalize_arxiv_id, validate_arxiv_id_format
from src.cache import set_paper_metadata, get_paper_metadata
from src.models import PaperMetadata, Author


def test_detect_arxiv_id():
    assert detect_arxiv_id("What's new in 1706.03762?") == "1706.03762"
    assert detect_arxiv_id("Check arxiv:2304.12345v2 now") == "2304.12345"
    assert detect_arxiv_id("no id here") is None


def test_validate_arxiv_id_format():
    assert validate_arxiv_id_format("1706.03762")
    assert validate_arxiv_id_format("arxiv:1706.03762v1")
    assert not validate_arxiv_id_format("not-id")


def test_normalize_arxiv_id():
    assert normalize_arxiv_id("arxiv:1706.03762v1") == "1706.03762"
    assert normalize_arxiv_id("1706.03762") == "1706.03762"


def test_cache_write_and_read(tmp_path):
    os.environ["ARXIV_CACHE_DB"] = str(tmp_path / "cache.db")
    pm = PaperMetadata(
        arxiv_id="1706.03762",
        title="Test",
        authors=[Author(name="A")],
        abstract="x",
        categories=["cs.CL"],
        primary_category="cs.CL",
        published="2024-01-01T00:00:00Z",
        updated="2024-01-02T00:00:00Z",
        pdf_url="https://arxiv.org/pdf/1706.03762.pdf",
        entry_url="https://arxiv.org/abs/1706.03762",
    )

    set_paper_metadata(pm)
    loaded = get_paper_metadata("1706.03762")
    assert loaded is not None
    assert loaded.arxiv_id == "1706.03762"


@pytest.mark.asyncio
async def test_get_by_id_cache(monkeypatch, tmp_path):
    os.environ["ARXIV_CACHE_DB"] = str(tmp_path / "cache.db")

    pm = PaperMetadata(
        arxiv_id="1706.03762",
        title="Test",
        authors=[Author(name="A")],
        abstract="x",
        categories=["cs.CL"],
        primary_category="cs.CL",
        published="2024-01-01T00:00:00Z",
        updated="2024-01-02T00:00:00Z",
        pdf_url="https://arxiv.org/pdf/1706.03762.pdf",
        entry_url="https://arxiv.org/abs/1706.03762",
    )
    set_paper_metadata(pm)

    client = ArxivClient()

    # make sure arxiv.Client.results is never called by mocking
    monkeypatch.setattr(client._client, "results", lambda _: iter([]))

    res = await client.get_by_id("1706.03762")
    assert res is not None
    assert res.title == "Test"
