import tempfile
from pathlib import Path

import fitz
import pytest

from src.pdf_parser import PDFParser, _clean_text, _extract_title_heuristic
from src.models import PDF_MAX_PAGES


def create_test_pdf(path: Path, pages: int = 1) -> None:
    doc = fitz.open()
    for i in range(pages):
        page = doc.new_page()
        page.insert_text((72, 72), f"This is page {i+1} of {pages}")
    doc.save(str(path))
    doc.close()


def test_pdf_parser_single_page(tmp_path):
    file = tmp_path / "test.pdf"
    create_test_pdf(file, pages=1)
    parser = PDFParser()
    extracted = parser.parse(str(file), "1706.03762")
    assert extracted.total_pages == 1
    assert "page" in extracted.full_text.lower()


def test_pdf_parser_page_limit(tmp_path):
    file = tmp_path / "test_big.pdf"
    create_test_pdf(file, pages=PDF_MAX_PAGES + 1)
    parser = PDFParser()
    with pytest.raises(ValueError, match="exceeds max allowed"):
        parser.parse(str(file), "1706.03762")


def test_clean_text():
    raw = "This is  a test.\n\n\nSome text -\ncontinued.\n\n\n"
    cleaned = _clean_text(raw)
    assert "  " not in cleaned
    assert "continued" in cleaned


def test_extract_title_heuristic_skips_copyright_notice():
    text = (
        "Copyright 2026 Example Corp. All rights reserved.\n"
        "This work is licensed under CC BY 4.0.\n"
        "https://arxiv.org/abs/9999.99999\n"
        "An Accurate Transformer for Contextual Understanding\n"
        "Authors: A. Author, B. Author\n"
    )
    title = _extract_title_heuristic(text)
    assert title == "An Accurate Transformer for Contextual Understanding"
