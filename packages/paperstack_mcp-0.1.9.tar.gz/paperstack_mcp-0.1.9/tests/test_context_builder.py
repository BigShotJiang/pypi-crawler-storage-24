from src.context_builder import ContextBuilder
from src.models import PaperMetadata, ExtractedPaper, TextChunk, Author


def test_context_builder_basic():
    metadata = PaperMetadata(
        arxiv_id="1706.03762",
        title="Test",
        authors=[Author(name="A"), Author(name="B")],
        abstract="This is abstract",
        categories=["cs.CL"],
        primary_category="cs.CL",
        published="2024-01-01T00:00:00Z",
        updated="2024-01-02T00:00:00Z",
        pdf_url="https://arxiv.org/pdf/1706.03762.pdf",
        entry_url="https://arxiv.org/abs/1706.03762",
    )

    extracted = ExtractedPaper(
        arxiv_id="1706.03762",
        title="Test paper",
        total_pages=1,
        full_text="Some text",
        chunks=[TextChunk(chunk_index=0, text="Some text", token_count=5, section_hint="Introduction")],
        extraction_method="pymupdf",
    )

    builder = ContextBuilder()
    context = builder.build(metadata, extracted)

    assert context.chunk_count == 1
    assert "Problem Statement" in context.summary_prompt
