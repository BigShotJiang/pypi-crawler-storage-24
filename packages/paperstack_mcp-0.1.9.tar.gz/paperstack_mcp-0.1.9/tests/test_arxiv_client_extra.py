from unittest.mock import AsyncMock

import pytest

from src.arxiv_client import ArxivClient, detect_arxiv_id, validate_arxiv_id_format, normalize_arxiv_id
from src.models import SearchResult, PaperMetadata, Author


@pytest.mark.asyncio
async def test_search_routes_to_get_by_id(monkeypatch):
    client = ArxivClient()

    mocked_meta = PaperMetadata(
        arxiv_id="1706.03762",
        title="Test",
        authors=[Author(name="A")],
        abstract="x",
        categories=["cs.CL"],
        primary_category="cs.CL",
        published="2024-01-01T00:00:00Z",
        updated="2024-01-02T00:00:00Z",
        pdf_url="https://arxiv.org/pdf/1706.03762.pdf",
        entry_url="https://arxiv.org/abs/1706.03762",
    )

    monkeypatch.setattr(client, "get_by_id", AsyncMock(return_value=mocked_meta))

    results = await client.search("1706.03762")
    assert len(results) == 1
    assert results[0].arxiv_id == "1706.03762"


# Additional `search` path coverage would normally require mocking arxiv client network interactions.
# For this suite we focus on ID routing and helpers.


def test_id_helpers():
    assert detect_arxiv_id("arxiv:1706.03762v2") == "1706.03762"
    assert validate_arxiv_id_format("1706.03762")
    assert normalize_arxiv_id("arXiv:1706.03762v2") == "1706.03762"
