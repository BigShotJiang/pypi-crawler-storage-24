import os
import tempfile

import pytest

from src.pdf_fetcher import PDFFetcher
from src.models import DOWNLOAD_DIR


@pytest.mark.asyncio
async def test_pdf_fetcher_cache_hit(tmp_path, monkeypatch):
    os.environ["ARXIV_DOWNLOAD_DIR"] = str(tmp_path)
    pdf_path = tmp_path / "1706.03762.pdf"
    pdf_path.write_bytes(b"PDFDATA")

    fetcher = PDFFetcher()
    result = await fetcher.download("1706.03762")
    assert result.success
    assert result.local_path == str(pdf_path)
    assert result.file_size_bytes == pdf_path.stat().st_size


@pytest.mark.asyncio
async def test_pdf_fetcher_download_with_mock(monkeypatch, tmp_path):
    os.environ["ARXIV_DOWNLOAD_DIR"] = str(tmp_path)

    def mock_stream(method, url):
        class DummyResponse:
            status_code = 200
            headers = {"content-type": "application/pdf", "content-length": "6"}

            async def __aenter__(self):
                return self

            async def __aexit__(self, exc_type, exc, tb):
                return False

            def raise_for_status(self):
                return None

            async def aiter_bytes(self, chunk_size=8192):
                yield b"ABC123"

        return DummyResponse()

    fetcher = PDFFetcher()
    monkeypatch.setattr(fetcher._client, "stream", mock_stream)

    result = await fetcher.download("1706.03763", force=True)
    assert result.success
    assert result.file_size_bytes == 6
    assert (tmp_path / "1706.03763.pdf").exists()


@pytest.mark.asyncio
async def test_pdf_fetcher_content_type_error(monkeypatch, tmp_path):
    os.environ["ARXIV_DOWNLOAD_DIR"] = str(tmp_path)

    def bad_stream(method, url):
        class BadResponse:
            status_code = 200
            headers = {"content-type": "text/html", "content-length": "10"}

            async def __aenter__(self):
                return self

            async def __aexit__(self, exc_type, exc, tb):
                return False

            def raise_for_status(self):
                return None

            async def aiter_bytes(self, chunk_size=8192):
                yield b"notpdf"

        return BadResponse()

    fetcher = PDFFetcher()
    monkeypatch.setattr(fetcher._client, "stream", bad_stream)

    result = await fetcher.download("1706.03764", force=True)
    assert not result.success
    assert "Unexpected content-type" in result.error
