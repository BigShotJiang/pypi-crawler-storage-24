import sys
from unittest.mock import patch, Mock

import pytest

from src import console


def test_parse_args_default(monkeypatch):
    monkeypatch.setattr(sys, "argv", ["arxiv-mcp"])
    args = console.parse_args()
    assert args.download_dir is None


def test_entrypoint_calls_main(monkeypatch):
    monkeypatch.setattr(sys, "argv", ["arxiv-mcp"])
    monkeypatch.setattr(console, "asyncio", type("A", (), {"run": lambda x: None}))
    with patch("src.console.main", new_callable=Mock):
        console.entrypoint()
