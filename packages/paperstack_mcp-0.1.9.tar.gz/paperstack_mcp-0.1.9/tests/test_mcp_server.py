import asyncio
import json
from pathlib import Path
from unittest.mock import AsyncMock

import pytest

from src import mcp_server
from src.models import SearchResult, Author


@pytest.mark.asyncio
async def test_handle_search_arxiv():
    dummy = SearchResult(
        arxiv_id="1706.03762",
        title="Test",
        authors=["A"],
        abstract_snippet="x",
        published="2024-01-01T00:00:00Z",
        categories=["cs.CL"],
        pdf_url="https://arxiv.org/pdf/1706.03762.pdf",
    )
    orig_search = mcp_server._arxiv_client.search
    mcp_server._arxiv_client.search = AsyncMock(return_value=[dummy])

    res = await mcp_server._handle_search_arxiv({"query": "test", "max_results": 1})
    payload = json.loads(res[0].text)
    assert payload["total_found"] == 1
    assert payload["results"][0]["arxiv_id"] == "1706.03762"

    mcp_server._arxiv_client.search = orig_search


@pytest.mark.asyncio
async def test_handle_get_paper_by_id_not_found():
    orig_get = mcp_server._arxiv_client.get_by_id
    mcp_server._arxiv_client.get_by_id = AsyncMock(return_value=None)

    res = await mcp_server._handle_get_paper_by_id({"arxiv_id": "nope"})
    payload = json.loads(res[0].text)
    assert "error" in payload

    mcp_server._arxiv_client.get_by_id = orig_get


@pytest.mark.asyncio
async def test_handle_download_and_extract_and_context(monkeypatch):
    from src.models import (
        DownloadResult,
        ExtractedPaper,
        TextChunk,
        PaperContext,
        PaperMetadata,
        Author,
    )

    # Download route
    expected_download = DownloadResult(
        arxiv_id="1706.03762",
        local_path="/tmp/1706.03762.pdf",
        file_size_bytes=1234,
        success=True,
    )
    monkeypatch.setattr(
        mcp_server.PDFFetcher, "download", AsyncMock(return_value=expected_download)
    )

    res_download = await mcp_server._handle_download_pdf(
        {"arxiv_id": "1706.03762", "force": False}
    )
    payload_download = json.loads(res_download[0].text)
    assert payload_download["success"] is True

    # Extract route
    monkeypatch.setattr(
        mcp_server.PDFFetcher, "download", AsyncMock(return_value=expected_download)
    )
    fake_extracted = ExtractedPaper(
        arxiv_id="1706.03762",
        title="Title",
        total_pages=1,
        full_text="abc",
        chunks=[TextChunk(chunk_index=0, text="abc", token_count=3)],
        extraction_method="pymupdf",
    )
    monkeypatch.setattr(
        mcp_server.PDFParser, "parse", lambda self, path, aid: fake_extracted
    )

    res_extract = await mcp_server._handle_extract_text({"arxiv_id": "1706.03762"})
    payload_extract = json.loads(res_extract[0].text)
    assert payload_extract["arxiv_id"] == "1706.03762"
    assert payload_extract["chunk_count"] == 1

    # Context route
    fake_metadata = PaperMetadata(
        arxiv_id="1706.03762",
        title="Title",
        authors=[Author(name="A")],
        abstract="x",
        categories=["cs.CL"],
        primary_category="cs.CL",
        published="2024-01-01T00:00:00Z",
        updated="2024-01-02T00:00:00Z",
        pdf_url="https://arxiv.org/pdf/1706.03762.pdf",
        entry_url="https://arxiv.org/abs/1706.03762",
    )
    monkeypatch.setattr(
        mcp_server._arxiv_client, "get_by_id", AsyncMock(return_value=fake_metadata)
    )
    monkeypatch.setattr(
        mcp_server.ContextBuilder,
        "build",
        lambda self, metadata, extracted, max_chunks=None: PaperContext(
            metadata=metadata,
            chunks=extracted.chunks,
            total_tokens=3,
            chunk_count=1,
            llm_system_prompt="s",
            summary_prompt="p",
        ),
    )

    res_context = await mcp_server._handle_get_paper_context({"arxiv_id": "1706.03762"})
    payload_context = json.loads(res_context[0].text)
    assert payload_context["arxiv_id"] == "1706.03762"
    assert payload_context["chunk_count"] == 1


@pytest.mark.asyncio
async def test_handle_extract_text_and_context_error_paths(monkeypatch, tmp_path):
    from src.models import (
        DownloadResult,
        PaperMetadata,
    )

    # Extract text fail path
    monkeypatch.setattr(
        mcp_server.PDFFetcher,
        "download",
        AsyncMock(
            return_value=DownloadResult(
                arxiv_id="1706.03762",
                local_path="",
                file_size_bytes=0,
                success=False,
                error="nope",
            )
        ),
    )
    res = await mcp_server._handle_extract_text({"arxiv_id": "1706.03762"})
    assert "error" in json.loads(res[0].text)

    # get paper context metadata not found
    monkeypatch.setattr(
        mcp_server._arxiv_client, "get_by_id", AsyncMock(return_value=None)
    )
    res2 = await mcp_server._handle_get_paper_context({"arxiv_id": "1706.03762"})
    assert "error" in json.loads(res2[0].text)

    # get paper context pdf download fail
    fake_meta = PaperMetadata(
        arxiv_id="1706.03762",
        title="Title",
        authors=[Author(name="A")],
        abstract="x",
        categories=["cs.CL"],
        primary_category="cs.CL",
        published="2024-01-01T00:00:00Z",
        updated="2024-01-02T00:00:00Z",
        pdf_url="https://arxiv.org/pdf/1706.03762.pdf",
        entry_url="https://arxiv.org/abs/1706.03762",
    )
    monkeypatch.setattr(
        mcp_server._arxiv_client, "get_by_id", AsyncMock(return_value=fake_meta)
    )
    monkeypatch.setattr(
        mcp_server.PDFFetcher,
        "download",
        AsyncMock(
            return_value=DownloadResult(
                arxiv_id="1706.03762",
                local_path="",
                file_size_bytes=0,
                success=False,
                error="nope",
            )
        ),
    )
    res3 = await mcp_server._handle_get_paper_context({"arxiv_id": "1706.03762"})
    assert "error" in json.loads(res3[0].text)


def test_handle_search_arxiv_no_results(monkeypatch):

    monkeypatch.setattr(mcp_server._arxiv_client, "search", AsyncMock(return_value=[]))
    res = asyncio.run(
        mcp_server._handle_search_arxiv({"query": "nothing", "max_results": 1})
    )
    assert "No papers found" in res[0].text


def test_handle_get_paper_by_id_none(monkeypatch):
    monkeypatch.setattr(
        mcp_server._arxiv_client, "get_by_id", AsyncMock(return_value=None)
    )
    res = asyncio.run(mcp_server._handle_get_paper_by_id({"arxiv_id": "unknown"}))
    assert "Paper not found" in res[0].text


def test_call_tool_unknown():
    results = asyncio.run(mcp_server.call_tool("unknown_tool", {}))
    assert "error" in results[0].text


@pytest.mark.asyncio
async def test_extraction_keep_pdfs_false(monkeypatch, tmp_path):
    from src.models import DownloadResult, ExtractedPaper, TextChunk

    fake_download = DownloadResult(
        arxiv_id="1706.03762",
        local_path=str(tmp_path / "temp.pdf"),
        file_size_bytes=4,
        success=True,
    )
    (tmp_path / "temp.pdf").write_bytes(b"abcd")

    monkeypatch.setattr(
        mcp_server.PDFFetcher, "download", AsyncMock(return_value=fake_download)
    )
    monkeypatch.setattr(
        mcp_server.PDFParser,
        "parse",
        lambda self, path, arxiv_id: ExtractedPaper(
            arxiv_id=arxiv_id,
            title="Test",
            total_pages=1,
            full_text="abc",
            chunks=[TextChunk(chunk_index=0, text="abc", token_count=3)],
            extraction_method="pymupdf",
        ),
    )

    monkeypatch.setattr(mcp_server, "KEEP_PDFS", False)

    result = await mcp_server._handle_extract_text({"arxiv_id": "1706.03762"})
    payload = json.loads(result[0].text)
    assert payload["arxiv_id"] == "1706.03762"
    assert not Path(fake_download.local_path).exists()


def test_list_tools_schema():
    tools = asyncio.run(mcp_server.list_tools())
    names = {t.name for t in tools}
    assert "search_arxiv" in names
    assert "get_paper_context" in names


@pytest.mark.asyncio
async def test_call_tool_dispatch(monkeypatch):
    fake_payload = [mcp_server.types.TextContent(type="text", text="{}")]  # nosem
    monkeypatch.setattr(
        mcp_server, "_handle_search_arxiv", AsyncMock(return_value=fake_payload)
    )
    monkeypatch.setattr(
        mcp_server, "_handle_get_paper_by_id", AsyncMock(return_value=fake_payload)
    )
    monkeypatch.setattr(
        mcp_server, "_handle_download_pdf", AsyncMock(return_value=fake_payload)
    )
    monkeypatch.setattr(
        mcp_server, "_handle_extract_text", AsyncMock(return_value=fake_payload)
    )
    monkeypatch.setattr(
        mcp_server, "_handle_get_paper_context", AsyncMock(return_value=fake_payload)
    )

    assert await mcp_server.call_tool("search_arxiv", {"query": "x"}) == fake_payload
    assert (
        await mcp_server.call_tool("get_paper_by_id", {"arxiv_id": "1706.03762"})
        == fake_payload
    )
    assert (
        await mcp_server.call_tool("download_pdf", {"arxiv_id": "1706.03762"})
        == fake_payload
    )
    assert (
        await mcp_server.call_tool("extract_text", {"arxiv_id": "1706.03762"})
        == fake_payload
    )
    assert (
        await mcp_server.call_tool("get_paper_context", {"arxiv_id": "1706.03762"})
        == fake_payload
    )

    """New Phase 6 tools dispatch checks"""
    monkeypatch.setattr(
        mcp_server, "_handle_citation_graph", AsyncMock(return_value=fake_payload)
    )
    monkeypatch.setattr(
        mcp_server,
        "_handle_extract_contributions",
        AsyncMock(return_value=fake_payload),
    )
    monkeypatch.setattr(
        mcp_server, "_handle_compare_papers", AsyncMock(return_value=fake_payload)
    )
    monkeypatch.setattr(
        mcp_server, "_handle_find_related", AsyncMock(return_value=fake_payload)
    )
    monkeypatch.setattr(
        mcp_server, "_handle_extract_code_links", AsyncMock(return_value=fake_payload)
    )
    monkeypatch.setattr(
        mcp_server,
        "_handle_reproducibility_score",
        AsyncMock(return_value=fake_payload),
    )
    monkeypatch.setattr(
        mcp_server, "_handle_diff_implementations", AsyncMock(return_value=fake_payload)
    )

    assert (
        await mcp_server.call_tool("arxiv_citation_graph", {"arxiv_id": "1706.03762"})
        == fake_payload
    )
    assert (
        await mcp_server.call_tool(
            "arxiv_extract_contributions", {"arxiv_id": "1706.03762"}
        )
        == fake_payload
    )
    assert (
        await mcp_server.call_tool(
            "arxiv_compare_papers", {"arxiv_ids": ["1706.03762", "1706.03763"]}
        )
        == fake_payload
    )
    assert (
        await mcp_server.call_tool("arxiv_find_related", {"query_text": "NLP"})
        == fake_payload
    )
    assert (
        await mcp_server.call_tool(
            "arxiv_extract_code_links", {"arxiv_id": "1706.03762"}
        )
        == fake_payload
    )
    assert (
        await mcp_server.call_tool(
            "arxiv_reproducibility_score", {"arxiv_id": "1706.03762"}
        )
        == fake_payload
    )
    assert (
        await mcp_server.call_tool(
            "arxiv_diff_implementations",
            {"arxiv_id": "1706.03762", "github_url": "https://github.com/owner/repo"},
        )
        == fake_payload
    )

    # unknown tool should return text content with error
    res = await mcp_server.call_tool("bad_tool", {})
    assert "error" in res[0].text


@pytest.mark.asyncio
async def test_handle_reading_list_and_watch_topic_and_explain(monkeypatch):
    from src.models import PaperMetadata, Author, PaperContributions

    # reading list integration
    monkeypatch.setattr(
        mcp_server._arxiv_client,
        "get_by_id",
        AsyncMock(
            return_value=PaperMetadata(
                arxiv_id="1706.03762",
                title="Test",
                authors=[Author(name="A")],
                abstract="test",
                categories=["cs.AI"],
                primary_category="cs.AI",
                published="2026-01-01T00:00:00Z",
                updated="2026-01-02T00:00:00Z",
                pdf_url="https://arxiv.org/pdf/1706.03762.pdf",
                entry_url="https://arxiv.org/abs/1706.03762",
            )
        ),
    )

    res_reading = await mcp_server._handle_reading_list(
        {"action": "add", "arxiv_id": "1706.03762"}
    )
    payload_reading = json.loads(res_reading[0].text)
    assert payload_reading["action"] == "add"
    assert payload_reading["entry"]["arxiv_id"] == "1706.03762"

    # watch topic integration
    class DummyPaper:
        def __init__(self, arxiv_id):
            self.arxiv_id = arxiv_id

    monkeypatch.setattr(
        mcp_server._arxiv_client,
        "search",
        AsyncMock(return_value=[DummyPaper("id1"), DummyPaper("id2")]),
    )

    res_watch = await mcp_server._handle_watch_topic(
        {"action": "add", "query": "test", "label": "test"}
    )
    payload_watch = json.loads(res_watch[0].text)
    assert payload_watch["action"] == "add"
    assert payload_watch["topics"]

    topic_id = payload_watch["topics"][0]["id"]
    res_check = await mcp_server._handle_watch_topic(
        {"action": "check", "topic_id": topic_id}
    )
    payload_check = json.loads(res_check[0].text)
    assert payload_check["action"] == "check"

    # explainer integration
    monkeypatch.setattr(
        mcp_server.ContributionExtractor,
        "extract",
        AsyncMock(
            return_value=PaperContributions(
                arxiv_id="1706.03762",
                core_claim="core",
                proposed_method="method",
                key_results=["r1"],
                baselines_compared=[],
                limitations=[],
                datasets_used=[],
                task_domain="NLP",
                novelty_type="empirical",
                extraction_method="heuristic",
                extracted_at="2026-01-01T00:00:00Z",
            )
        ),
    )

    async def fake_ollama(prompt):
        return json.dumps(
            {
                "what_it_is": "X",
                "problem_solved": "Y",
                "how_it_works": "Z",
                "why_it_matters": "W",
                "key_result": "K",
                "reading_time_minutes": 2,
            }
        )

    monkeypatch.setattr(mcp_server.Explainer, "_call_ollama", fake_ollama)
    res_explain = await mcp_server._handle_explain_for_audience(
        {"arxiv_id": "1706.03762", "audience": "practitioner"}
    )
    payload_explain = json.loads(res_explain[0].text)
    assert payload_explain["generation_method"] in {"llm", "passthrough"}
