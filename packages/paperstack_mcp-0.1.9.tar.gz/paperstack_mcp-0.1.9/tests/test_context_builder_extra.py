from src.context_builder import ContextBuilder
from src.models import TextChunk, ExtractedPaper, PaperMetadata, Author


def test_context_builder_window_and_text():
    metadata = PaperMetadata(
        arxiv_id="1706.03762",
        title="Test",
        authors=[Author(name="A")],
        abstract="x",
        categories=["cs.CL"],
        primary_category="cs.CL",
        published="2024-01-01T00:00:00Z",
        updated="2024-01-02T00:00:00Z",
        pdf_url="https://arxiv.org/pdf/1706.03762.pdf",
        entry_url="https://arxiv.org/abs/1706.03762",
    )

    extracted = ExtractedPaper(
        arxiv_id="1706.03762",
        title="Test",
        total_pages=1,
        full_text="A\nB\nC",
        chunks=[TextChunk(chunk_index=0, text="A", token_count=1, section_hint="Intro"), TextChunk(chunk_index=1, text="B", token_count=1)],
        extraction_method="pymupdf",
    )

    builder = ContextBuilder()
    context = builder.build(metadata, extracted)
    assert context.chunk_count == 2

    window = builder.get_chunk_window(context, start=0, count=1)
    assert len(window) == 1
    text = builder.chunks_to_text(window)
    assert "Intro" in text
