import os
from pathlib import Path
from unittest import mock

import pytest

from src.console import configure_env_from_args, parse_args, entrypoint


def test_configure_env_from_args(tmp_path):
    class Args:
        download_dir = str(tmp_path)
        keep_pdfs = True

    configure_env_from_args(Args)
    assert os.getenv("ARXIV_DOWNLOAD_DIR") == str(Path(tmp_path).resolve())
    assert os.getenv("ARXIV_KEEP_PDFS") == "true"


def test_entrypoint_env(monkeypatch, capsys):
    monkeypatch.setattr("sys.argv", ["arxiv-mcp", "--env"])
    entrypoint()
    captured = capsys.readouterr()
    assert "ARXIV_DOWNLOAD_DIR" in captured.out
