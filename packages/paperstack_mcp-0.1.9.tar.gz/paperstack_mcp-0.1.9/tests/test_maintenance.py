import asyncio
import os
import time
from pathlib import Path

import pytest

from src.cache import purge_old_pdfs, evict_stale_cache, set_paper_metadata, get_paper_metadata
from src.maintenance import periodic_cleanup
from src.models import PaperMetadata, Author


@pytest.mark.asyncio
async def test_periodic_cleanup(tmp_path, monkeypatch):
    os.environ["ARXIV_CACHE_DB"] = str(tmp_path / "cache.db")
    os.environ["ARXIV_DOWNLOAD_DIR"] = str(tmp_path)

    pm = PaperMetadata(
        arxiv_id="1706.03762",
        title="Test",
        authors=[Author(name="A")],
        abstract="x",
        categories=["cs.CL"],
        primary_category="cs.CL",
        published="2024-01-01T00:00:00Z",
        updated="2024-01-02T00:00:00Z",
        pdf_url="https://arxiv.org/pdf/1706.03762.pdf",
        entry_url="https://arxiv.org/abs/1706.03762",
    )
    set_paper_metadata(pm)

    # make metadata stale for eviction
    import sqlite3
    conn = sqlite3.connect(str(tmp_path / "cache.db"))
    conn.execute("UPDATE papers SET updated_at = ?", (int(time.time()) - 999999,))
    conn.commit()
    conn.close()

    old = Path(tmp_path / "old.pdf")
    old.write_bytes(b"x")
    os.utime(old, (time.time() - 60 * 60 * 24 * 40, time.time() - 60 * 60 * 24 * 40))

    # run one cycle and then stop
    stop_event = asyncio.Event()
    task = asyncio.create_task(periodic_cleanup(interval_hours=0.001, cache_max_age_hours=0, pdf_max_age_days=30, stop_event=stop_event))
    await asyncio.sleep(0.05)
    stop_event.set()
    await task

    assert not old.exists()
    assert get_paper_metadata("1706.03762") is None


@pytest.mark.asyncio
async def test_periodic_cleanup_without_cache(tmp_path):
    os.environ.pop("ARXIV_CACHE_DB", None)
    os.environ["ARXIV_DOWNLOAD_DIR"] = str(tmp_path)

    old = Path(tmp_path / "old2.pdf")
    old.write_bytes(b"x")
    os.utime(old, (time.time() - 60 * 60 * 24 * 40, time.time() - 60 * 60 * 24 * 40))

    stop_event = asyncio.Event()
    task = asyncio.create_task(periodic_cleanup(interval_hours=0.001, cache_max_age_hours=0, pdf_max_age_days=30, stop_event=stop_event))
    await asyncio.sleep(0.05)
    stop_event.set()
    await task

    assert not old.exists()
