import sys
import types
from pathlib import Path

import pytest

from src.pdf_parser import PDFParser


def test_pdf_parser_tiktoken_fallback(tmp_path, monkeypatch):
    # Ensure tiktoken import raises inside _chunk_text
    fake = types.ModuleType("tiktoken")
    def get_encoding(name):
        raise RuntimeError("no tiktoken")
    fake.get_encoding = get_encoding

    sys.modules["tiktoken"] = fake

    file = tmp_path / "test.pdf"
    import fitz
    doc = fitz.open()
    page = doc.new_page()
    page.insert_text((72, 72), "hello world")
    doc.save(str(file))
    doc.close()

    parser = PDFParser()
    extracted = parser.parse(str(file), "1706.03762")
    assert len(extracted.chunks) >= 1
