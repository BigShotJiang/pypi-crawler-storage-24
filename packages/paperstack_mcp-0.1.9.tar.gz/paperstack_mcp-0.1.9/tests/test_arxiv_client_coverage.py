import asyncio
import time
from unittest.mock import AsyncMock

import pytest

from src.arxiv_client import ArxivClient, _rate_limit, _result_to_metadata, _result_to_search_result_from_meta
from src.models import PaperMetadata, Author


class FakeArxivResult:
    entry_id = "https://arxiv.org/abs/1706.03762"
    title = "Test title"
    authors = []
    summary = "abstract"
    categories = ["cs.CL"]
    primary_category = "cs.CL"
    published = None
    updated = None
    comment = None
    journal_ref = None


def test_rate_limit_enforces_delay():
    t1 = time.monotonic()
    asyncio.run(_rate_limit())
    asyncio.run(_rate_limit())
    t2 = time.monotonic()
    assert t2 - t1 >= 0


def test_result_to_metadata_and_search_result_conversion():
    fake = FakeArxivResult()
    meta = _result_to_metadata(fake)
    assert isinstance(meta, PaperMetadata)
    sr = _result_to_search_result_from_meta(meta)
    assert sr.arxiv_id == "1706.03762"


@pytest.mark.asyncio
async def test_search_id_routing(monkeypatch):
    client = ArxivClient()
    monkeypatch.setattr(client, "get_by_id", AsyncMock(return_value=PaperMetadata(
        arxiv_id="1706.03762",
        title="Title",
        authors=[Author(name="A")],
        abstract="x",
        categories=["cs.CL"],
        primary_category="cs.CL",
        published="2024-01-01T00:00:00Z",
        updated="2024-01-02T00:00:00Z",
        pdf_url="https://arxiv.org/pdf/1706.03762.pdf",
        entry_url="https://arxiv.org/abs/1706.03762",
    )))

    res = await client.search("1706.03762")
    assert len(res) == 1


@pytest.mark.asyncio
async def test_get_by_id_fetches(monkeypatch):
    client = ArxivClient()

    class FakeResult:
        entry_id = "https://arxiv.org/abs/1706.03762"
        title = "Fake"
        authors = []
        summary = "abstract"
        categories = ["cs.CL"]
        primary_category = "cs.CL"
        published = None
        updated = None
        comment = None
        journal_ref = None

    from src import arxiv_client
    monkeypatch.setattr(arxiv_client, "_rate_limit", AsyncMock())
    monkeypatch.setattr(client._client, "results", lambda q: [FakeResult()])

    meta = await client.get_by_id("1706.03762")
    assert meta.arxiv_id == "1706.03762"


@pytest.mark.asyncio
async def test_search_invalid_id_no_meta(monkeypatch):
    client = ArxivClient()
    from src import arxiv_client
    monkeypatch.setattr(arxiv_client, "_rate_limit", AsyncMock())
    monkeypatch.setattr(client, "get_by_id", AsyncMock(return_value=None))

    results = await client.search("1706.03762")
    assert results == []


@pytest.mark.asyncio
async def test_search_raises_on_api_error(monkeypatch):
    client = ArxivClient()
    from src import arxiv_client
    monkeypatch.setattr(arxiv_client, "_rate_limit", AsyncMock())
    monkeypatch.setattr(client._client, "results", lambda q: (_ for _ in ()).throw(RuntimeError("x")))

    with pytest.raises(RuntimeError):
        await client.search("machine learning")


@pytest.mark.asyncio
async def test_get_by_id_not_found(monkeypatch, tmp_path):
    import os
    client = ArxivClient()
    os.environ["ARXIV_CACHE_DB"] = str(tmp_path / "cache.db")
    from src import arxiv_client
    monkeypatch.setattr(arxiv_client, "_rate_limit", AsyncMock())
    monkeypatch.setattr(client._client, "results", lambda q: [])

    res = await client.get_by_id("1706.03762")
    assert res is None


@pytest.mark.asyncio
async def test_validate_id(monkeypatch):
    client = ArxivClient()
    monkeypatch.setattr(client, "get_by_id", AsyncMock(return_value=PaperMetadata(
        arxiv_id="1706.03762",
        title="Title",
        authors=[Author(name="A")],
        abstract="x",
        categories=["cs.CL"],
        primary_category="cs.CL",
        published="2024-01-01T00:00:00Z",
        updated="2024-01-02T00:00:00Z",
        pdf_url="https://arxiv.org/pdf/1706.03762.pdf",
        entry_url="https://arxiv.org/abs/1706.03762",
    )))

    assert await client.validate_id("1706.03762") is True
