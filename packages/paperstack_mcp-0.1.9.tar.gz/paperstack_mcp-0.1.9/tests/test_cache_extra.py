import os
import sys
from pathlib import Path
from unittest.mock import Mock

import pytest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import importlib
cache = importlib.import_module("src.cache")
from src.models import PaperMetadata, Author


def test_get_db_path_and_connection_none(monkeypatch):
    monkeypatch.delenv("ARXIV_CACHE_DB", raising=False)
    assert cache._get_db_path() is None
    assert cache._get_connection() is None


def test_get_paper_metadata_exception(monkeypatch):
    class BadConn:
        def execute(self, *args, **kwargs):
            raise RuntimeError("db fail")

        def close(self):
            return None

    monkeypatch.setattr(cache, "_get_connection", lambda: BadConn())
    res = cache.get_paper_metadata("1706.03762")
    assert res is None


def test_evict_stale_cache_exception(monkeypatch):
    class BadConn:
        def execute(self, *args, **kwargs):
            raise RuntimeError("db fail")

        def commit(self):
            pass

        def close(self):
            pass

    monkeypatch.setattr(cache, "_get_connection", lambda: BadConn())
    deleted = cache.evict_stale_cache(max_age_hours=1)
    assert deleted == 0


def test_set_paper_metadata_exception(monkeypatch):
    class BadConn:
        def execute(self, *args, **kwargs):
            raise RuntimeError("db write fail")

        def commit(self):
            pass

        def close(self):
            pass

    monkeypatch.setattr(cache, "_get_connection", lambda: BadConn())
    pm = PaperMetadata(
        arxiv_id="1706.03762",
        title="Test",
        authors=[Author(name="A")],
        abstract="x",
        categories=["cs.CL"],
        primary_category="cs.CL",
        published="2024-01-01T00:00:00Z",
        updated="2024-01-02T00:00:00Z",
        pdf_url="https://arxiv.org/pdf/1706.03762.pdf",
        entry_url="https://arxiv.org/abs/1706.03762",
    )
    cache.set_paper_metadata(pm)


def test_purge_old_pdfs_exception(monkeypatch, tmp_path):
    os.environ["ARXIV_DOWNLOAD_DIR"] = str(tmp_path)
    test_file = tmp_path / "old.pdf"
    test_file.write_bytes(b"x")
    os.utime(test_file, (0, 0))

    # Use custom cache.Path to avoid affecting global pathlib.Path.
    class FakePath:
        def stat(self):
            raise RuntimeError("stat fail")

        def unlink(self):
            pass

    class FakePathFactory:
        def __init__(self, path):
            self._path = path

        def glob(self, pattern):
            return [FakePath()]

    monkeypatch.setattr(cache, "Path", FakePathFactory)
    monkeypatch.setattr("src.models.get_download_dir", lambda: tmp_path)

    deleted = cache.purge_old_pdfs(max_age_days=1)
    assert deleted == 0
