from unittest.mock import AsyncMock

import pytest

from src.arxiv_client import ArxivClient


class DummyResult:
    def __init__(self):
        self.entry_id = "https://arxiv.org/abs/1706.03762"
        self.title = "Test title"
        self.authors = []
        self.summary = "abstract"
        self.categories = ["cs.CL"]
        self.primary_category = "cs.CL"
        self.published = None
        self.updated = None
        self.comment = None
        self.journal_ref = None


@pytest.mark.asyncio
async def test_search_non_id(monkeypatch):
    client = ArxivClient()
    dummy = DummyResult()

    from src import arxiv_client
    monkeypatch.setattr(arxiv_client, "_rate_limit", AsyncMock())
    monkeypatch.setattr(client._client, "results", lambda q: [dummy])

    results = await client.search("deep learning", max_results=1)
    assert len(results) == 1
    assert results[0].arxiv_id == "1706.03762"


@pytest.mark.asyncio
async def test_get_by_id_not_found(monkeypatch):
    client = ArxivClient()
    from src import arxiv_client
    monkeypatch.setattr(arxiv_client, "_rate_limit", AsyncMock())
    monkeypatch.setattr(client._client, "results", lambda q: [])

    with pytest.raises(ValueError):
        await client.get_by_id("unknown")
