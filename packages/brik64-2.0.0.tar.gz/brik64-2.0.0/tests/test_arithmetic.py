from brik64.mc.arithmetic import add8, sub8, mul8, div8, mod8, abs64, neg64, clamp


def test_add8_saturating():
    assert add8(200, 100) == 255
    assert add8(1, 2) == 3


def test_sub8_saturating():
    assert sub8(5, 10) == 0
    assert sub8(10, 3) == 7


def test_div8_zero():
    assert div8(10, 0) == (0, 0)
    assert div8(17, 5) == (3, 2)


def test_clamp():
    assert clamp(10, 0, 5) == 5
    assert clamp(-1, 0, 10) == 0
    assert clamp(5, 0, 10) == 5
