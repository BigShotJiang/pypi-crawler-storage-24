# brik64 — Digital Circuitality for Python

64 formally verified atomic operations (monomers) implementing the BRIK-64 Digital Circuitality architecture.

## Install

```bash
pip install brik64
```

## Usage

```python
from brik64 import mc, eva

# Arithmetic
result = mc.arithmetic.add8(200, 100)  # saturating: 255
q, r = mc.arithmetic.div8(17, 5)       # (3, 2)

# EVA algebra
pipeline = eva.seq(mc.arithmetic.add8, lambda x: x * 2)
```

## License

Proprietary — © 2026 BRIK-64 Inc.
