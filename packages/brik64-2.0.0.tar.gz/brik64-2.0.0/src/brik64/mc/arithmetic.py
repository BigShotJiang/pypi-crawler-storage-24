"""F0 — Arithmetic monomers (MC_00–MC_07)."""

_U8_MAX = 255
_I64_MIN = -(2**63)
_I64_MAX = 2**63 - 1


def add8(a: int, b: int) -> int:
    """MC_00: saturating u8 addition."""
    return min(a + b, _U8_MAX)


def sub8(a: int, b: int) -> int:
    """MC_01: saturating u8 subtraction."""
    return max(a - b, 0)


def mul8(a: int, b: int) -> int:
    """MC_02: saturating u8 multiplication."""
    return min(a * b, _U8_MAX)


def div8(a: int, b: int) -> tuple[int, int]:
    """MC_03: u8 division → (quotient, remainder). div-by-zero → (0, 0)."""
    if b == 0:
        return (0, 0)
    return (a // b, a % b)


def mod8(a: int, b: int) -> int:
    """MC_04: u8 modulo. mod-by-zero → 0."""
    if b == 0:
        return 0
    return a % b


def abs64(a: int) -> int:
    """MC_05: i64 absolute value."""
    return abs(a)


def neg64(a: int) -> int:
    """MC_06: i64 negation, clamped to i64 range."""
    return max(_I64_MIN, -a)


def clamp(val: int, lo: int, hi: int) -> int:
    """MC_07: clamp value to [lo, hi]."""
    return max(lo, min(val, hi))
