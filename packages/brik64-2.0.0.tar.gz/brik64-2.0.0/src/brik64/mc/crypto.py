"""F6 — Crypto monomers (MC_48–MC_55)."""
import hashlib
import hmac as _hmac
import secrets


def hash_sha256(data: bytes) -> bytes:
    """MC_48: SHA-256 hash."""
    return hashlib.sha256(data).digest()


def hash_hex(data: bytes) -> str:
    """MC_49: SHA-256 hex digest."""
    return hashlib.sha256(data).hexdigest()


def xor_bytes(a: bytes, b: bytes) -> bytes:
    """MC_50: XOR two byte sequences (truncates to shorter length)."""
    return bytes(x ^ y for x, y in zip(a, b))


def rotate_left(val: int, shift: int, bits: int = 32) -> int:
    """MC_51: rotate left."""
    shift %= bits
    mask = (1 << bits) - 1
    return ((val << shift) | (val >> (bits - shift))) & mask


def rotate_right(val: int, shift: int, bits: int = 32) -> int:
    """MC_52: rotate right."""
    shift %= bits
    mask = (1 << bits) - 1
    return ((val >> shift) | (val << (bits - shift))) & mask


def constant_eq(a: bytes, b: bytes) -> bool:
    """MC_53: timing-safe equality comparison."""
    return _hmac.compare_digest(a, b)


def zero_bytes(n: int) -> bytes:
    """MC_54: generate n zero bytes."""
    return bytes(n)


def bytes_to_hex(data: bytes) -> str:
    """MC_55: bytes to hex string."""
    return data.hex()
