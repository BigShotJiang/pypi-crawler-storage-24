"""F1 — Logic monomers (MC_08–MC_15)."""


def and8(a: int, b: int) -> int:
    """MC_08: bitwise AND."""
    return a & b & 0xFF


def or8(a: int, b: int) -> int:
    """MC_09: bitwise OR."""
    return (a | b) & 0xFF


def xor8(a: int, b: int) -> int:
    """MC_10: bitwise XOR."""
    return (a ^ b) & 0xFF


def not8(a: int) -> int:
    """MC_11: bitwise NOT."""
    return (~a) & 0xFF


def shl8(a: int, shift: int) -> int:
    """MC_12: left shift. shift >= 8 → 0."""
    if shift >= 8:
        return 0
    return (a << shift) & 0xFF


def shr8(a: int, shift: int) -> int:
    """MC_13: right shift. shift >= 8 → 0."""
    if shift >= 8:
        return 0
    return (a >> shift) & 0xFF


def bool_and(a: bool, b: bool) -> bool:
    """MC_14: logical AND."""
    return a and b


def bool_or(a: bool, b: bool) -> bool:
    """MC_15: logical OR."""
    return a or b
