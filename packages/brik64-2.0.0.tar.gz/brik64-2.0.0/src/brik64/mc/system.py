"""F7 — System monomers (MC_56–MC_63)."""
import os
import sys
import time


def time_unix() -> int:
    """MC_56: Unix timestamp in seconds."""
    return int(time.time())


def time_ms() -> int:
    """MC_57: Unix timestamp in milliseconds."""
    return int(time.time() * 1000)


def env_get(key: str) -> str | None:
    """MC_58: get environment variable."""
    return os.environ.get(key)


def env_set(key: str, value: str) -> None:
    """MC_59: set environment variable."""
    os.environ[key] = value


def pid() -> int:
    """MC_60: current process ID."""
    return os.getpid()


def args() -> list[str]:
    """MC_61: command-line arguments."""
    return sys.argv[:]


def exit_code(code: int) -> int:
    """MC_62: return exit code (does not exit)."""
    return code


def sleep_ms(ms: int) -> None:
    """MC_63: sleep for ms milliseconds (capped at 60,000ms)."""
    time.sleep(min(ms, 60_000) / 1000.0)
