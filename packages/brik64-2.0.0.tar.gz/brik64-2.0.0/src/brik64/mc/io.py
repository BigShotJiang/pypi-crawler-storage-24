"""F4 — I/O monomers (MC_32–MC_39)."""
import os
import sys


def read_file(path: str) -> str | None:
    """MC_32: read file contents."""
    try:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()
    except OSError:
        return None


def write_file(path: str, content: str) -> bool:
    """MC_33: write file contents."""
    try:
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        return True
    except OSError:
        return False


def append_file(path: str, content: str) -> bool:
    """MC_34: append to file."""
    try:
        with open(path, "a", encoding="utf-8") as f:
            f.write(content)
        return True
    except OSError:
        return False


def read_str() -> str:
    """MC_35: read line from stdin."""
    try:
        return input()
    except EOFError:
        return ""


def write_stdout(s: str) -> None:
    """MC_36: write to stdout."""
    sys.stdout.write(s)


def write_stderr(s: str) -> None:
    """MC_37: write to stderr."""
    sys.stderr.write(s)


def file_exists(path: str) -> bool:
    """MC_38: check if file exists."""
    return os.path.exists(path)


def file_size(path: str) -> int:
    """MC_39: get file size in bytes. Returns -1 on error."""
    try:
        return os.path.getsize(path)
    except OSError:
        return -1
