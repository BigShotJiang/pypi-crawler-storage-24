"""F3 — Control monomers (MC_24–MC_31)."""
from typing import Any, Callable

_MAX_LOOPS = 1_000_000


def mc_if(cond: bool, then_val: Any, else_val: Any) -> Any:
    """MC_24: conditional select."""
    return then_val if cond else else_val


def mc_loop(n: int, f: Callable[[int], None]) -> None:
    """MC_25: bounded loop (capped at 1,000,000 iterations)."""
    for i in range(min(n, _MAX_LOOPS)):
        f(i)


def nop() -> None:
    """MC_26: no operation."""
    pass


def halt(code: int = 0) -> int:
    """MC_27: return exit code."""
    return code


def cmp_eq(a: Any, b: Any) -> bool:
    """MC_28: equality comparison."""
    return a == b


def cmp_lt(a: Any, b: Any) -> bool:
    """MC_29: less-than comparison."""
    return a < b


def cmp_gt(a: Any, b: Any) -> bool:
    """MC_30: greater-than comparison."""
    return a > b


def mc_call(f: Callable, *args: Any) -> Any:
    """MC_31: call a function."""
    return f(*args)
