"""BRIK-64 Digital Circuitality — 64 formally verified monomers."""
from brik64 import mc, eva

__version__ = "2.0.0"
__all__ = ["mc", "eva"]
