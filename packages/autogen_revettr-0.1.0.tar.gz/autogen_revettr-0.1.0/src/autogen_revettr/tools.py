"""Revettr counterparty risk scoring tools for AutoGen agents."""

from __future__ import annotations

import os
from typing import Any


async def revettr_score(
    domain: str | None = None,
    ip: str | None = None,
    wallet_address: str | None = None,
    chain: str = "base",
    company_name: str | None = None,
) -> str:
    """Score a counterparty 0-100 before sending payments in agentic commerce.

    Covers domain intelligence, IP reputation, wallet history, and sanctions
    screening (OFAC/EU/UN). Accepts any combination of identifiers for higher
    confidence. Pricing: $0.01 USDC per score via x402 on Base.

    Args:
        domain: Domain or URL of the counterparty (e.g., 'uniswap.org').
        ip: IP address of the counterparty server.
        wallet_address: EVM wallet address (0x...).
        chain: Blockchain network for wallet analysis (default: 'base').
        company_name: Legal name to screen against OFAC/EU/UN sanctions lists.

    Returns:
        Formatted risk score with per-signal breakdown.
    """
    if not any([domain, ip, wallet_address, company_name]):
        return (
            "Error: At least one identifier is required. "
            "Provide a domain, IP address, wallet address, or company name."
        )

    from revettr import Revettr

    try:
        wallet_key = os.getenv("REVETTR_WALLET_KEY")
        client_kwargs: dict[str, Any] = {}
        if wallet_key:
            client_kwargs["wallet_key"] = wallet_key

        client = Revettr(**client_kwargs)

        score_kwargs: dict[str, Any] = {}
        if domain:
            score_kwargs["domain"] = domain
        if ip:
            score_kwargs["ip"] = ip
        if wallet_address:
            score_kwargs["wallet_address"] = wallet_address
            score_kwargs["chain"] = chain
        if company_name:
            score_kwargs["company_name"] = company_name

        result = client.score(**score_kwargs)

        lines = [
            "Revettr Counterparty Risk Score",
            "=" * 40,
            f"Score: {result.score}/100",
            f"Tier: {result.tier}",
            f"Confidence: {result.confidence}",
        ]

        if hasattr(result, "flags") and result.flags:
            lines.append("\nFlags:")
            for flag in result.flags:
                lines.append(f"  - {flag}")

        if hasattr(result, "signals") and result.signals:
            lines.append("\nSignal Breakdown:")
            for signal in result.signals:
                name = getattr(signal, "name", str(signal))
                score = getattr(signal, "score", "N/A")
                lines.append(f"  {name}: {score}")

        return "\n".join(lines)

    except Exception as e:
        error_msg = str(e)
        if "402" in error_msg:
            return (
                f"Payment required: Set REVETTR_WALLET_KEY environment variable "
                f"with an EVM private key funded with USDC on Base. "
                f"Cost: $0.01 per score. Details: {error_msg}"
            )
        return f"Error scoring counterparty: {error_msg}"
