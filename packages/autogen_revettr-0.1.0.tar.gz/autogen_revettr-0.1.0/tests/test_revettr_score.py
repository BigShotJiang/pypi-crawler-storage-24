"""Tests for autogen_revettr.revettr_score."""

from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest

from autogen_revettr.tools import revettr_score


@pytest.fixture
def mock_score_result():
    return SimpleNamespace(
        score=82,
        tier="low_risk",
        confidence=0.95,
        flags=["verified_domain"],
        signals=[
            SimpleNamespace(name="domain_age", score=90),
            SimpleNamespace(name="ssl_valid", score=85),
        ],
    )


class TestInputValidation:
    @pytest.mark.asyncio
    async def test_no_identifiers_returns_error(self):
        result = await revettr_score()
        assert "Error" in result
        assert "At least one identifier" in result

    @pytest.mark.asyncio
    async def test_all_none_returns_error(self):
        result = await revettr_score(
            domain=None, ip=None, wallet_address=None, company_name=None
        )
        assert "Error" in result


class TestScoring:
    @pytest.mark.asyncio
    @patch("autogen_revettr.tools.Revettr")
    async def test_score_by_domain(self, mock_revettr_cls, mock_score_result):
        mock_client = MagicMock()
        mock_client.score.return_value = mock_score_result
        mock_revettr_cls.return_value = mock_client

        result = await revettr_score(domain="uniswap.org")

        mock_client.score.assert_called_once_with(domain="uniswap.org")
        assert "82/100" in result
        assert "low_risk" in result

    @pytest.mark.asyncio
    @patch("autogen_revettr.tools.Revettr")
    async def test_score_by_wallet(self, mock_revettr_cls, mock_score_result):
        mock_client = MagicMock()
        mock_client.score.return_value = mock_score_result
        mock_revettr_cls.return_value = mock_client

        result = await revettr_score(wallet_address="0xabc", chain="ethereum")

        mock_client.score.assert_called_once_with(
            wallet_address="0xabc", chain="ethereum"
        )

    @pytest.mark.asyncio
    @patch("autogen_revettr.tools.Revettr")
    async def test_score_by_company_name(self, mock_revettr_cls, mock_score_result):
        mock_client = MagicMock()
        mock_client.score.return_value = mock_score_result
        mock_revettr_cls.return_value = mock_client

        result = await revettr_score(company_name="Acme Corp")

        mock_client.score.assert_called_once_with(company_name="Acme Corp")

    @pytest.mark.asyncio
    @patch("autogen_revettr.tools.Revettr")
    async def test_combined_signals(self, mock_revettr_cls, mock_score_result):
        mock_client = MagicMock()
        mock_client.score.return_value = mock_score_result
        mock_revettr_cls.return_value = mock_client

        result = await revettr_score(
            domain="merchant.com",
            wallet_address="0xabc",
            company_name="Merchant Inc",
        )

        mock_client.score.assert_called_once_with(
            domain="merchant.com",
            wallet_address="0xabc",
            chain="base",
            company_name="Merchant Inc",
        )


class TestOutputFormatting:
    @pytest.mark.asyncio
    @patch("autogen_revettr.tools.Revettr")
    async def test_flags_displayed(self, mock_revettr_cls, mock_score_result):
        mock_client = MagicMock()
        mock_client.score.return_value = mock_score_result
        mock_revettr_cls.return_value = mock_client

        result = await revettr_score(domain="example.com")

        assert "Flags:" in result
        assert "verified_domain" in result

    @pytest.mark.asyncio
    @patch("autogen_revettr.tools.Revettr")
    async def test_signals_displayed(self, mock_revettr_cls, mock_score_result):
        mock_client = MagicMock()
        mock_client.score.return_value = mock_score_result
        mock_revettr_cls.return_value = mock_client

        result = await revettr_score(domain="example.com")

        assert "Signal Breakdown:" in result
        assert "domain_age: 90" in result

    @pytest.mark.asyncio
    @patch("autogen_revettr.tools.Revettr")
    async def test_no_flags_or_signals(self, mock_revettr_cls):
        mock_client = MagicMock()
        mock_client.score.return_value = SimpleNamespace(
            score=50, tier="medium_risk", confidence=0.7
        )
        mock_revettr_cls.return_value = mock_client

        result = await revettr_score(domain="example.com")

        assert "Flags:" not in result
        assert "Signal Breakdown:" not in result
        assert "50/100" in result


class TestWalletKey:
    @pytest.mark.asyncio
    @patch.dict("os.environ", {"REVETTR_WALLET_KEY": "0xsecret"})
    @patch("autogen_revettr.tools.Revettr")
    async def test_wallet_key_passed(self, mock_revettr_cls, mock_score_result):
        mock_client = MagicMock()
        mock_client.score.return_value = mock_score_result
        mock_revettr_cls.return_value = mock_client

        await revettr_score(domain="example.com")

        mock_revettr_cls.assert_called_once_with(wallet_key="0xsecret")

    @pytest.mark.asyncio
    @patch.dict("os.environ", {}, clear=True)
    @patch("autogen_revettr.tools.Revettr")
    async def test_no_wallet_key(self, mock_revettr_cls, mock_score_result):
        mock_client = MagicMock()
        mock_client.score.return_value = mock_score_result
        mock_revettr_cls.return_value = mock_client

        await revettr_score(domain="example.com")

        mock_revettr_cls.assert_called_once_with()


class TestErrorHandling:
    @pytest.mark.asyncio
    @patch("autogen_revettr.tools.Revettr")
    async def test_402_error(self, mock_revettr_cls):
        mock_client = MagicMock()
        mock_client.score.side_effect = Exception("402 Payment Required")
        mock_revettr_cls.return_value = mock_client

        result = await revettr_score(domain="example.com")

        assert "Payment required" in result
        assert "REVETTR_WALLET_KEY" in result

    @pytest.mark.asyncio
    @patch("autogen_revettr.tools.Revettr")
    async def test_generic_error(self, mock_revettr_cls):
        mock_client = MagicMock()
        mock_client.score.side_effect = Exception("Connection refused")
        mock_revettr_cls.return_value = mock_client

        result = await revettr_score(domain="example.com")

        assert "Error scoring counterparty" in result
        assert "Connection refused" in result
