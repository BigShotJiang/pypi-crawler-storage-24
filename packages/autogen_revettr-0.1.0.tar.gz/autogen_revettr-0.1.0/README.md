# autogen-revettr

Score counterparties 0-100 before sending payments in agentic commerce.

Covers domain intelligence, IP reputation, wallet history, and sanctions screening (OFAC/EU/UN). Uses the [Revettr](https://revettr.com) x402-native API -- no API keys needed, just a funded wallet.

## Installation

```bash
pip install autogen-revettr

# For x402 auto-payment support:
pip install autogen-revettr[x402]
```

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `REVETTR_WALLET_KEY` | Optional | EVM private key for x402 auto-payment ($0.01 USDC per score on Base) |

## Usage

```python
from autogen_revettr import revettr_score

# Use directly
result = await revettr_score(domain="uniswap.org")

# Score by wallet address
result = await revettr_score(wallet_address="0x1234...", chain="base")

# Combine multiple signals
result = await revettr_score(
    domain="merchant.com",
    wallet_address="0xabc...",
    company_name="Merchant Inc",
)
```

## Use with AutoGen Agents

```python
from autogen_agentchat.agents import AssistantAgent
from autogen_revettr import revettr_score

agent = AssistantAgent(
    name="compliance_officer",
    model_client=model_client,
    tools=[revettr_score],
    system_message="Verify counterparty risk before approving payments.",
)
```

## License

MIT
