# Conf To Spl2 Converter
# Copyright (C) 2026 Splunk Inc. All Rights Reserved.
#
# Installation and use subject to the Splunk General Terms,
# see https://www.splunk.com/en_us/legal/splunk-general-terms.html


"""Pipeline generation for SPL2 templates."""

from __future__ import annotations

import json
import logging
import os
import re
from typing import Any

from conf_spl2_converter.converter import commands
from conf_spl2_converter.converter.input.configuration_constants import (
    INPUT_FOLDER,
    PIPELINE_FILE_NAME,
)
from conf_spl2_converter.converter.pipeline_utils import (
    EMPTY,
    INDENT,
    NEWLINE,
    calculate_main_sourcetype_function_name,
    create_function_to_apply_lookups,
    create_functions_for_source_sourcetype,
    format_commands,
    format_kv_mode,
    format_lookup_imports,
    format_regex_commands,
)
from conf_spl2_converter.utils.utils import (
    load_convert_string_to_array_template,
    load_remove_duplicate_fields_template,
    load_trim_fields_template,
    sluggify_string,
)

logger = logging.getLogger("conf-spl2-converter")


def _strip_trailing_whitespace(text: str) -> str:
    """Remove trailing whitespace from each line to match pre-commit hooks."""
    return "\n".join(line.rstrip() for line in text.split("\n"))


class Pipeline:
    """Generates SPL2 pipeline files from template code."""

    def __init__(
        self,
        addon_name: str,
        template_version: str,
        version: str,
        splunk_base_url: str,
        slug: str | None = None,
        sourcetype: str | None = None,
        multiple_sources: bool = False,
        multiple_sourcetypes: bool = False,
    ):
        template_name = (
            "pipeline_with_multiple_sources.template" if sourcetype and multiple_sources else "pipeline_spl2.template"
        )

        template_path = os.path.join(INPUT_FOLDER, template_name)
        with open(template_path) as f:
            self.template = f.read()
        self.flatten_json_function = EMPTY
        self.bitmask_to_values = EMPTY
        self.flatten_one_element_mv = EMPTY
        self.add_on_name = addon_name
        self.template_version = template_version
        self.version = version
        self.splunk_base_url = splunk_base_url
        self.sourcetype = sourcetype
        self.multiple_sources = multiple_sources
        self.slug = slug or sluggify_string(sourcetype)
        self.remove_duplicate_fields = ""
        self.remove_duplicate_fields_function = ""
        self.multiple_sourcetypes = multiple_sourcetypes

    def create_branch_for_sources(self, template_code, pipeline_code, source_function, sourcetype_lookups):
        _function_name = template_code["function_name"]
        if _function_name != self.sourcetype and not template_code.get("default_stanza"):
            trim_whitespace = " | trim_whitespace" if template_code["trim_fields_eval_commands"] else ""

            main_sourcetype_function = calculate_main_sourcetype_function_name(self.sourcetype)
            condition_value = "source" if not self.multiple_sourcetypes else "sourcetype"

            branch_function_name = source_function
            condition = f'{condition_value}="{_function_name}"'
            source_function_value = "| " + source_function if source_function else ""
            source_lookups = f"| apply_{source_function}_lookups " if template_code["lookup_spl2_commands"] else ""
            sourcetype_lookups_str = f"| apply_{main_sourcetype_function}_lookups " if sourcetype_lookups else ""
            trim_newline = "| trim_newline" if template_code["trim_fields_newlines_eval_commands"] else ""
            convert_string_to_array = (
                " | convert_string_to_array" if template_code["fields_to_convert_eval_commands"] else ""
            )

            self._add_branch_function(
                branch_function_name,
                condition,
                convert_string_to_array,
                pipeline_code,
                source_function_value,
                source_lookups,
                sourcetype_lookups_str,
                trim_newline,
                trim_whitespace,
            )

    def _add_branch_function(
        self,
        branch_function_name: str,
        condition: str,
        convert_string_to_array: str,
        pipeline_code: dict,
        source_function: str,
        source_lookups: str,
        sourcetype_lookups: str,
        trim_newline: str,
        trim_whitespace: str,
    ):
        branch_code = commands.BranchCommand().generate(
            branch_function_name=branch_function_name,
            condition=condition,
        )
        pipeline_code["branches"] += NEWLINE + INDENT + branch_code + ("," if branch_function_name != "default" else "")

        branch_function = commands.BranchFunctionCommand().generate(
            branch_function_name=branch_function_name,
            source_function=source_function,
            source_lookups=source_lookups,
            sourcetype_lookups=sourcetype_lookups,
            trim_newline=trim_newline,
            trim_whitespace=trim_whitespace,
            convert_string_to_array=convert_string_to_array,
            remove_duplicate_fields=self.remove_duplicate_fields,
        )
        pipeline_code["branch_functions"] += NEWLINE + branch_function

    def _generate_code(self, template_codes: dict) -> str:
        pipeline_code = {"functions": EMPTY, "branches": EMPTY, "branch_functions": EMPTY, "lookup_functions": EMPTY}
        processed_sources: list[str] = []
        default_extractions: list[str] = []
        sourcetype_lookups = False

        # Load helper .spl2 files at most once per pipeline (avoid repeated disk I/O in loop)
        if self.flatten_json_function == EMPTY and any(
            tc.get("kv_mode") == "json" or tc.get("indexed_extractions") == "json" for tc in template_codes.values()
        ):
            with open(os.path.join(INPUT_FOLDER, "flatten_json.spl2")) as f:
                self.flatten_json_function = f.read()
        if self.bitmask_to_values == EMPTY and any(tc.get("is_bitmask_lookups") for tc in template_codes.values()):
            with open(os.path.join(INPUT_FOLDER, "bitmask_function.spl2")) as f:
                self.bitmask_to_values = f.read()
            with open(os.path.join(INPUT_FOLDER, "flatten_one_element_mv.spl2")) as f:
                self.flatten_one_element_mv = f.read()

        for template_code in template_codes.values():
            for field in ["regex_spl2_commands"]:
                template_code[field] = format_regex_commands(template_code.get(field))

            for field in [
                "rename_spl2_commands",
                "eval_spl2_commands",
                "trim_fields_eval_commands",
                "trim_fields_newlines_eval_commands",
                "fields_to_convert_eval_commands",
                "lookup_spl2_commands",
                "default_lookup_extractions",
                "scripted_lookups",
            ]:
                template_code[field] = format_commands(template_code.get(field))

            for field in ["kv_mode", "indexed_extractions"]:
                template_code[field] = format_kv_mode(template_code.get(field))

            for field in ["lookup_names"]:
                template_code[field] = format_lookup_imports(template_code.get(field))

            trim_fields = ""
            if template_code.get("trim_fields_eval_commands"):
                trim_fields_template = load_trim_fields_template()
                trim_fields = trim_fields_template.format(
                    trim_character="whitespace",
                    trim_fields=template_code["trim_fields_eval_commands"],
                )

            if template_code.get("trim_fields_newlines_eval_commands"):
                trim_newlines_template = load_trim_fields_template()
                trim_fields += NEWLINE + trim_newlines_template.format(
                    trim_character="newline",
                    trim_fields=template_code["trim_fields_newlines_eval_commands"],
                )

            if template_code.get("remove_duplicate_fields"):
                self.remove_duplicate_fields = " | remove_duplicate_fields"
                remove_duplicate_fields_template = load_remove_duplicate_fields_template()
                # Wrap field names containing '.' or spaces in single quotes for valid
                # SPL2 syntax (e.g. 'ExtendedProperties.Client IP Address').
                # Fields already wrapped in quotes from input.json are left as-is.
                quoted_fields = []
                for f in template_code["remove_duplicate_fields"]:
                    if not (f.startswith("'") and f.endswith("'")) and ("." in f or " " in f):
                        quoted_fields.append(f"'{f}'")
                    else:
                        quoted_fields.append(f)
                self.remove_duplicate_fields_function = remove_duplicate_fields_template.format(
                    remove_duplicate_fields_case_insensitive=", ".join(quoted_fields)
                )

            convert_string_to_array_code = ""
            if template_code.get("fields_to_convert_eval_commands"):
                conversion_template = load_convert_string_to_array_template()
                convert_string_to_array_code += NEWLINE + conversion_template.format(
                    string_to_array_code=template_code["fields_to_convert_eval_commands"]
                )

            if template_code["function_name"] == self.sourcetype and template_code.get("lookup_spl2_commands"):
                sourcetype_lookups = True

            source_function = re.sub(r"[^a-zA-Z0-9_]", "_", template_code["function_name"])

            if template_code.get("default_stanza"):
                default_function = re.sub(r"[^a-zA-Z0-9_]", "_", template_code["function_name"])
                default_extractions.append(default_function)

            if self.multiple_sources:
                source = template_code.get("source")
                if not template_code.get("default_stanza") and source_function != template_code["function_name"]:
                    processed_sources.append(template_code["function_name"])
                create_functions_for_source_sourcetype(template_code, pipeline_code, source, source_function)
                if template_code.get("lookup_spl2_commands"):
                    create_function_to_apply_lookups(template_code, pipeline_code, source_function)
            else:
                return self._create_single_pipeline(
                    convert_string_to_array_code,
                    default_extractions,
                    pipeline_code,
                    template_code,
                    template_codes,
                    trim_fields,
                )

        for template_code in template_codes.values():
            source_function = re.sub(r"[^a-zA-Z0-9_]", "_", template_code["function_name"])
            self.create_branch_for_sources(template_code, pipeline_code, source_function, sourcetype_lookups)

        main_sourcetype_function = calculate_main_sourcetype_function_name(self.sourcetype)

        # Add default branch for sources not matching any processed sources
        if self.multiple_sources and len(processed_sources) > 0:
            condition_value = "source" if not self.multiple_sourcetypes else "sourcetype"
            condition = " AND ".join([f'{condition_value}!="{source}"' for source in processed_sources])
            sourcetype_lookups_str = f" | apply_{main_sourcetype_function}_lookups" if sourcetype_lookups else ""

            trim_whitespace = " | trim_whitespace" if template_code["trim_fields_eval_commands"] else ""
            trim_newline = "| trim_newline" if template_code["trim_fields_newlines_eval_commands"] else ""
            convert_string_to_array = (
                "| convert_string_to_array" if template_code["fields_to_convert_eval_commands"] else ""
            )

            self._add_branch_function(
                "default",
                condition,
                convert_string_to_array,
                pipeline_code,
                "",
                "",
                sourcetype_lookups_str,
                trim_newline,
                trim_whitespace,
            )

        return self.template.format(
            addon_name=self.add_on_name,
            template_version=self.template_version,
            version=self.version,
            sourcetype=self.sourcetype,
            splunk_base_url=self.splunk_base_url,
            lookup_import_statements=template_codes[self.sourcetype]["lookup_names"],
            default_extractions="| " + " | ".join(default_extractions) if default_extractions else "",
            functions=pipeline_code["functions"],
            trim_fields=trim_fields
            if template_codes[self.sourcetype].get("trim_fields_eval_commands")
            or template_codes[self.sourcetype].get("trim_fields_newlines_eval_commands")
            else "",
            convert_string_to_array=convert_string_to_array_code,
            main_sourcetype_function=main_sourcetype_function,
            apply_functions=pipeline_code["branches"],
            branch_functions=pipeline_code["branch_functions"],
            apply_lookups=pipeline_code["lookup_functions"],
            flatten_json_function_placeholder=self.flatten_json_function,
            remove_duplicate_fields_function=self.remove_duplicate_fields_function,
        )

    def _create_single_pipeline(
        self,
        convert_string_to_array_code: str,
        default_extractions: list[Any],
        pipeline_code: dict[str, str],
        template_code: dict,
        template_codes: dict,
        trim_fields: str,
    ) -> str:
        main_sourcetype_function = calculate_main_sourcetype_function_name(self.sourcetype)

        return self.template.format(
            main_sourcetype_function=main_sourcetype_function,
            template_version=self.template_version,
            addon_name=self.add_on_name,
            version=self.version,
            sourcetype=self.sourcetype,
            splunk_base_url=self.splunk_base_url,
            default_functions=pipeline_code["functions"],
            regex_based_extractions=template_code["regex_spl2_commands"],
            aliases=template_code["rename_spl2_commands"],
            code_based_extractions=template_code["eval_spl2_commands"],
            trim_fields=trim_fields
            if template_codes[self.sourcetype].get("trim_fields_eval_commands")
            or template_codes[self.sourcetype].get("trim_fields_newlines_eval_commands")
            else "",
            convert_string_to_array=convert_string_to_array_code,
            apply_trim_newline="| trim_newline" if template_code["trim_fields_newlines_eval_commands"] else "",
            apply_trim_whitespace="| trim_whitespace" if template_code["trim_fields_eval_commands"] else "",
            apply_convert_string_to_array=" | convert_string_to_array"
            if template_code["fields_to_convert_eval_commands"]
            else "",
            timestamping_args=template_code.get("timestamping_args", EMPTY),
            lookups=template_code["lookup_spl2_commands"],
            default_lookup_extractions=template_code["default_lookup_extractions"],
            default_extractions="| " + " | ".join(default_extractions) if default_extractions else "",
            scripted_lookups=template_code["scripted_lookups"],
            lookup_import_statements=template_code["lookup_names"],
            kv_mode_extractions=template_code["kv_mode"]
            if template_code["kv_mode"]
            else template_code["indexed_extractions"],
            flatten_json_function_placeholder=self.flatten_json_function,
            bitmask_to_values_placeholder=self.bitmask_to_values,
            flatten_one_element_mv_placeholder=self.flatten_one_element_mv,
            remove_duplicate_fields=self.remove_duplicate_fields,
            remove_duplicate_fields_function=self.remove_duplicate_fields_function,
        )

    def generate_pipeline(
        self,
        template_code: dict,
        output_dir: str = ".",
        output_format: str = "spl2",
    ) -> None:
        """Generate the pipeline file and write to disk.

        Args:
            template_code: Template code dict keyed by sourcetype/source.
            output_dir: Output directory. Defaults to <ta_path>/default/data/spl2/.
            output_format: 'spl2' (default) or 'json'.
        """
        pipeline_dir = os.path.join(output_dir, self.slug)
        os.makedirs(pipeline_dir, exist_ok=True)

        if output_format == "json":
            json_file_path = os.path.join(pipeline_dir, f"pipeline_{self.slug}.json")
            json_data = {
                "sourcetype": self.sourcetype,
                "slug": self.slug,
                "addon_name": self.add_on_name,
                "template_version": self.template_version,
                "version": self.version,
                "splunk_base_url": self.splunk_base_url,
                "multiple_sources": self.multiple_sources,
                "template_code": template_code,
            }
            with open(json_file_path, "w") as f:
                json.dump(json_data, f, indent=2, default=str)
            logger.info(f"JSON output generated at: {json_file_path}")
        else:
            code = self._generate_code(template_code)
            code = _strip_trailing_whitespace(code)
            pipeline_file_path = os.path.join(pipeline_dir, PIPELINE_FILE_NAME.format(slug=self.slug))
            with open(pipeline_file_path, "w") as pipeline_file:
                pipeline_file.write(code)
            logger.info(f"Pipeline file generated at: {pipeline_file_path}")
