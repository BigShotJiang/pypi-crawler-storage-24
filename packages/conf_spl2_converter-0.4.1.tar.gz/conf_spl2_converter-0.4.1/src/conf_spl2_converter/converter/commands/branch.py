# Conf To Spl2 Converter
# Copyright (C) 2026 Splunk Inc. All Rights Reserved.
#
# Installation and use subject to the Splunk General Terms,
# see https://www.splunk.com/en_us/legal/splunk-general-terms.html


"""Branch commands."""

from conf_spl2_converter.converter.commands.base import SPL2Command


class BranchCommand(SPL2Command):
    """Generate SPL2 branch condition."""

    def __init__(self):
        super().__init__("branch")

    def generate(self, condition, branch_function_name):
        return self.template.format(
            condition=condition,
            branch_function_name=branch_function_name,
        ).strip()


class BranchFunctionCommand(SPL2Command):
    """Generate SPL2 branch function."""

    def __init__(self):
        super().__init__("branch_function")

    def generate(
        self,
        branch_function_name,
        source_function,
        source_lookups,
        sourcetype_lookups,
        trim_newline,
        trim_whitespace,
        convert_string_to_array,
        remove_duplicate_fields,
    ):
        return self.template.format(
            branch_function_name=branch_function_name,
            source_function=source_function,
            source_lookups=source_lookups,
            sourcetype_lookups=sourcetype_lookups,
            trim_newline=trim_newline,
            trim_whitespace=trim_whitespace,
            convert_string_to_array=convert_string_to_array,
            remove_duplicate_fields=remove_duplicate_fields,
        ).strip()
