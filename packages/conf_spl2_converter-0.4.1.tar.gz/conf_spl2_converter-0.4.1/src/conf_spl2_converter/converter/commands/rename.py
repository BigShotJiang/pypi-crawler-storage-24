# Conf To Spl2 Converter
# Copyright (C) 2026 Splunk Inc. All Rights Reserved.
#
# Installation and use subject to the Splunk General Terms,
# see https://www.splunk.com/en_us/legal/splunk-general-terms.html


"""Rename command."""

from conf_spl2_converter.converter.commands.base import SPL2Command
from conf_spl2_converter.converter.parsers.rename_parser import RenameCommandData, RenameSPLCommandParser


class RenameCommand(SPL2Command):
    """Generate SPL2 rename command."""

    def __init__(self):
        super().__init__("rename")

    def parse(self, spl_command_str) -> RenameCommandData:
        extractor = RenameSPLCommandParser()
        return extractor.parse(spl_command_str)

    def convert_spl_to_spl2(self, spl_command_data: RenameCommandData) -> str:
        input_clause = []
        for source_field, target_field in spl_command_data.input_fields_mapping:
            input_clause.append(f"{source_field} AS {target_field}")
        input_clause_str = ", ".join(input_clause) if input_clause else ""
        return f" {input_clause_str}"

    def generate(self, rename_action):
        spl_command_data = self.parse("rename " + rename_action)
        spl2_command_args = self.convert_spl_to_spl2(spl_command_data)
        return self.template.format(rename_action=spl2_command_args).strip()
