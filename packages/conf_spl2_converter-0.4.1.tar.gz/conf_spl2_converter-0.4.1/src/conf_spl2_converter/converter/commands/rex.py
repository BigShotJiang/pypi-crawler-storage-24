# Conf To Spl2 Converter
# Copyright (C) 2026 Splunk Inc. All Rights Reserved.
#
# Installation and use subject to the Splunk General Terms,
# see https://www.splunk.com/en_us/legal/splunk-general-terms.html


"""Rex command with named capture group injection."""

from __future__ import annotations

import logging
import re

from conf_spl2_converter.converter.commands.base import SPL2Command
from conf_spl2_converter.utils.utils import load_kv_extraction_template

logger = logging.getLogger("conf-spl2-converter")


class RexCommand(SPL2Command):
    """Generate SPL2 rex command with named capture group injection."""

    def __init__(self):
        super().__init__("rex")

    def inject_named_groups(self, regex, format_str, dest_field):
        """Inject named capture groups into regex based on format string mappings."""
        named_mappings = re.findall(r'([A-Za-z_]\w*)::["\']?\$?([\w:]+)["\']?', format_str)
        if not named_mappings:
            if dest_field and format_str and format_str.strip().strip("'\"") == "$1":
                named_mappings = [(dest_field, "1")]
            else:
                logger.warning(
                    f"Could not parse named mappings from format string: {format_str}. Skipping named group injection."
                )
                return None

        group_pattern = re.compile(r"(?<!\\)\((?!\?)")
        group_indices = [m.start() for m in group_pattern.finditer(regex)]

        regex_list = list(regex)
        default_value_field = {}
        offset = 0
        field_counts = {}
        for field, idx_str in named_mappings:
            try:
                idx = int(idx_str) - 1
            except ValueError:
                default_value_field[field] = idx_str
                continue
            if idx < 0 or idx >= len(group_indices):
                continue

            count = field_counts.get(field, 0)
            field_counts[field] = count + 1
            field_name = f"{field}{count}" if count > 0 else field
            if count > 0:
                logger.warning(
                    f"Duplicated field name '{field}' found in format string, using '{field_name}' to avoid conflicts."
                )

            insert_pos = group_indices[idx] + 1 + offset
            name_str = f"?P<{field_name}>"
            regex_list[insert_pos:insert_pos] = list(name_str)
            offset += len(name_str)
        return default_value_field, "".join(regex_list), field_counts

    def generate(self, regex, source_field, format, dest_field):
        dest_field_extraction = False
        if regex and "/" in regex:
            regex = re.sub(r"(?<!(?<!\\)\\)\/", r"\\/", regex)
        if regex and "(?s)" in regex:
            regex = regex.replace("(?s)", "(?ms)")

        default_value_field = {}
        field_counts = {}

        if format:
            if dest_field in ["queue", "MetaData:Source", "MetaData:Host", "MetaData:Sourcetype"]:
                dest_field_extraction = True

            if format == "$1::$2":
                kv_template = load_kv_extraction_template()
                return (
                    default_value_field,
                    kv_template.format(source_field=source_field, regex=regex),
                    regex,
                    dest_field_extraction,
                    field_counts,
                )
            default_value_field, regex, field_counts = self.inject_named_groups(regex, format, dest_field)
            logger.debug(f"Final regex generated: {regex}\n ")

        return (
            default_value_field,
            self.template.format(source_field=source_field, regex=regex).strip(),
            regex,
            dest_field_extraction,
            field_counts,
        )
