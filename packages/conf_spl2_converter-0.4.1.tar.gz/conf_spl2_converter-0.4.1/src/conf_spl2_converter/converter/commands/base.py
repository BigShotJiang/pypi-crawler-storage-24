# Conf To Spl2 Converter
# Copyright (C) 2026 Splunk Inc. All Rights Reserved.
#
# Installation and use subject to the Splunk General Terms,
# see https://www.splunk.com/en_us/legal/splunk-general-terms.html


"""Base class for SPL2 command generation."""

import json
import os

from conf_spl2_converter.converter.input.configuration_constants import LANGUAGE_TEMPLATE


class SPL2Command:
    """Base class for SPL2 command generation."""

    def __init__(self, name: str):
        self.name = name
        with open(os.path.join(LANGUAGE_TEMPLATE, name)) as f:
            self.template = f.read()

    def generate(self, *args):
        return self.template.format(*args).strip()

    def parse(self, command_str):
        raise NotImplementedError("Parser method not implemented for this command.")

    def convert_spl_to_spl2(self, spl_command_data):
        raise NotImplementedError("Conversion method not implemented for this command.")

    def __str__(self):
        return json.dumps({"name": self.name, "template": self.template}, indent=4, sort_keys=True)
