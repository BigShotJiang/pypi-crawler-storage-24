# Conf To Spl2 Converter
# Copyright (C) 2026 Splunk Inc. All Rights Reserved.
#
# Installation and use subject to the Splunk General Terms,
# see https://www.splunk.com/en_us/legal/splunk-general-terms.html


"""Eval command with SPL-to-SPL2 expression conversion."""

from __future__ import annotations

import logging
import re

from conf_spl2_converter.converter.commands.base import SPL2Command
from conf_spl2_converter.converter.commands.fields import FieldsCommand
from conf_spl2_converter.converter.input.configuration_constants import SPL2_RESERVED_FIELDS

logger = logging.getLogger("conf-spl2-converter")


class EvalCommandData:
    def __init__(self, field, expression):
        self.field = field
        self.expression = expression


class EvalCommand(SPL2Command):
    """Generate SPL2 eval command with SPL-to-SPL2 expression conversion."""

    def __init__(self):
        super().__init__("eval")

    def convert_spl_to_spl2(self, eval_command_expression: str) -> str:
        """Fix syntactic differences between SPL and SPL2."""
        # Boolean and null function difference
        eval_command_expression = eval_command_expression.replace("true()", "true")
        eval_command_expression = eval_command_expression.replace("false()", "false")
        eval_command_expression = eval_command_expression.replace("null()", "null")

        # Concatenation difference (. -> +)
        eval_command_expression = re.sub(r"(\S)\s+\.\s+(\S)", r"\1 + \2", eval_command_expression)
        eval_command_expression = re.sub(r"""(['")\]])\s*\.\s*(['"(\w])""", r"\1 + \2", eval_command_expression)

        # Escape backslashes in match/replace functions
        eval_command_expression = self._escape_backslashes_in_match(eval_command_expression)

        eval_command_expression = self._extract_multivalue_field(eval_command_expression)

        # Wrap split(mvindex(... with split(tostring(mvindex(...
        eval_command_expression = self._wrap_mvindex_with_tostring_in_split(eval_command_expression)

        return eval_command_expression

    def generate(self, field, expression, convert_spl_to_spl2=True, pure_eval=False, fields_to_trim=None):
        logger.debug(f"Generating for field: '{field}' and expression: '{expression}'")
        expression = self.convert_spl_to_spl2(expression) if convert_spl_to_spl2 else expression
        extraction_list = []
        logger.debug(f"expression after conversion: '{expression}'")
        extraction_generated = False

        # Handle keyword field names in SPL2
        if field in SPL2_RESERVED_FIELDS:
            if fields_to_trim is not None and field in fields_to_trim and pure_eval:
                temp_field = f"{field}_temp"
                extraction_list.append(self.template.format(field=temp_field, expression=expression).strip())
                expression = f"trim({temp_field})"
                field = f"'{field}'"
                extraction_list.append(self.template.format(field=field, expression=expression).strip())
                fields_command = FieldsCommand()
                extraction_list.append(fields_command.generate(fields=temp_field, operation="-"))
                extraction_generated = True
            else:
                field = f"'{field}'"

        # Escape field names containing ':'
        if ":" in field and not (field.startswith("'") and field.endswith("'")):
            field = f"'{field}'"

        subtract_pattern = r"^([a-zA-Z0-9_\s]*)\-([a-zA-Z0-9_\s]*)$"
        match = re.match(subtract_pattern, expression)
        if match:
            expression = (
                f"if(isnotnull(tonumber({match.group(1)})) and isnotnull(tonumber({match.group(2)})), "
                f"tonumber({match.group(1)}) - tonumber({match.group(2)}), null)"
            )
            extraction_list.append(self.template.format(field=field, expression=expression).strip())
            extraction_generated = True

        multiply_pattern = r"\(([\w\(\),\s]+\*[\d\*\s]+)\)"
        if re.search(multiply_pattern, expression):
            expression = re.sub(multiply_pattern, r"if(\1 == 0, null, \1)", expression)
            expression = f"tonumber({expression})"
            extraction_list.append(self.template.format(field=field, expression=expression).strip())
            extraction_generated = True

        add_pattern = r"\b(\w+)\s*\+\s*(\w+)\b"
        if re.search(add_pattern, expression) and pure_eval:
            expression = re.sub(add_pattern, r"tonumber(\1) + tonumber(\2)", expression)
            extraction_list.append(self.template.format(field=field, expression=expression).strip())
            extraction_generated = True

        # Workaround: remove null values from mv fields, display single value if length is one
        mvappend_pattern = r"mvappend\s*\("
        if re.search(mvappend_pattern, expression):
            extraction_list.append(self.template.format(field=field, expression=expression).strip())
            extraction_list.append(
                "// Workaround to remove null values from mv fields "
                "and display only a single value if length of mv field is one"
            )
            remove_nulls_expr = f"if(ismv({field}), filter(mv_to_json_array({field}), $row-> isnotnull($row)), {field})"
            extraction_list.append(self.template.format(field=field, expression=remove_nulls_expr).strip())
            extract_single_value_expr = f"if(ismv({field}) and mvcount({field}) == 1, mvindex({field}, 0), {field})"
            extraction_list.append(self.template.format(field=field, expression=extract_single_value_expr).strip())
            extraction_generated = True

        if not extraction_generated:
            extraction_list.append(self.template.format(field=field, expression=expression).strip())
        logger.debug(f"Extractions list created for field ({field}) -> {extraction_list}")
        return extraction_list

    def _escape_backslashes_in_match(self, expr: str) -> str:
        result = []
        i = 0
        n = len(expr)
        while i < n:
            for func in ("match(", "replace("):
                if expr.startswith(func, i):
                    i += len(func)
                    content, i = self._extract_function_call_content(expr, i, n)
                    content_escaped = content.replace("\\", "\\\\").replace('\\\\"', '\\"')
                    result.append(f"{func}{content_escaped})")
                    break
            else:
                result.append(expr[i])
                i += 1
        return "".join(result)

    def _wrap_mvindex_with_tostring_in_split(self, expr: str) -> str:
        result = []
        i = 0
        n = len(expr)
        while i < n:
            if expr.startswith("split(mvindex(", i):
                result.append("split(tostring(mvindex(")
                i += len("split(mvindex(")
                content, i = self._extract_function_call_content(expr, i, n)
                result.append(content)
                result.append("))")
            else:
                result.append(expr[i])
                i += 1
        return "".join(result)

    def _extract_function_call_content(self, expr: str, i: int, n: int) -> tuple[str, int]:
        depth = 1
        start = i
        while i < n and depth > 0:
            if expr[i] == "(":
                depth += 1
            elif expr[i] == ")":
                depth -= 1
            i += 1
        content = expr[start : i - 1]
        return content, i

    def _extract_multivalue_field(self, expr: str) -> str:
        """Handle multivalue fields with {} notation (not supported in SPL2)."""
        multivalue_field_regex = r"(['\"])([^'\"]*?\{\}[^'\"]*)\1"
        matches = list(re.finditer(multivalue_field_regex, expr))

        replacements = {}
        for m in matches:
            full_token = m.group(0)
            field = m.group(2)
            replacements[full_token] = f'json_extract(_raw, "{field}")'

        for orig, new in replacements.items():
            expr = expr.replace(orig, new)

        json_path_pattern = r"^([a-zA-Z_][a-zA-Z0-9_]*(?:\.[a-zA-Z0-9_{}]+)+)$"

        def replace_json_path(match):
            path = match.group(1)
            return f'json_extract(_raw, "{path}")'

        if not re.search(r"json_extract\s*\(", expr):
            expr = re.sub(json_path_pattern, replace_json_path, expr)

        return expr
