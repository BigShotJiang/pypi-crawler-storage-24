# Conf To Spl2 Converter
# Copyright (C) 2026 Splunk Inc. All Rights Reserved.
#
# Installation and use subject to the Splunk General Terms,
# see https://www.splunk.com/en_us/legal/splunk-general-terms.html


"""Wrapper around TABConfigParser for reading Splunk .conf files."""

from __future__ import annotations

import logging

from addonfactory_splunk_conf_parser_lib import TABConfigParser

logger = logging.getLogger("conf-spl2-converter")


def get_ta_config_object() -> TABConfigParser:
    """Create a new TABConfigParser instance."""
    return TABConfigParser()


def load_conf_files(config: TABConfigParser, files: list[str]) -> None:
    """Load a list of .conf files into the parser."""
    config.read(files)
