# Conf To Spl2 Converter
# Copyright (C) 2026 Splunk Inc. All Rights Reserved.
#
# Installation and use subject to the Splunk General Terms,
# see https://www.splunk.com/en_us/legal/splunk-general-terms.html


"""Configuration constants for the converter."""

import os
from pathlib import Path

# Base directory is the input/ package itself
INPUT_FOLDER = str(Path(__file__).parent)

# Language templates
LANGUAGE_TEMPLATE = os.path.join(INPUT_FOLDER, "language_templates")

# Pipeline templates
PIPELINE_SPL2_TEMPLATE = os.path.join(INPUT_FOLDER, "pipeline_spl2.template")
PIPELINE_FILE_NAME = "pipeline_{slug}.spl2"

# Constants for conversion
SPL2_RESERVED_FIELDS = ["desc", "asc", "group"]
