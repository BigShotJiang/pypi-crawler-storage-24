# Generated from src/conf_spl2_converter/converter/input/grammar/lookup/lookup_spl.g4 by ANTLR 4.13.2
from antlr4 import *

if "." in __name__:
    from .lookup_splParser import lookup_splParser
else:
    from lookup_splParser import lookup_splParser

# This class defines a complete generic visitor for a parse tree produced by lookup_splParser.


class lookup_splVisitor(ParseTreeVisitor):
    # Visit a parse tree produced by lookup_splParser#spl_cmd_start.
    def visitSpl_cmd_start(self, ctx: lookup_splParser.Spl_cmd_startContext):
        return self.visitChildren(ctx)

    # Visit a parse tree produced by lookup_splParser#lookup_spl_command.
    def visitLookup_spl_command(self, ctx: lookup_splParser.Lookup_spl_commandContext):
        return self.visitChildren(ctx)

    # Visit a parse tree produced by lookup_splParser#lookup_name.
    def visitLookup_name(self, ctx: lookup_splParser.Lookup_nameContext):
        return self.visitChildren(ctx)

    # Visit a parse tree produced by lookup_splParser#input_clause.
    def visitInput_clause(self, ctx: lookup_splParser.Input_clauseContext):
        return self.visitChildren(ctx)

    # Visit a parse tree produced by lookup_splParser#output_clause.
    def visitOutput_clause(self, ctx: lookup_splParser.Output_clauseContext):
        return self.visitChildren(ctx)

    # Visit a parse tree produced by lookup_splParser#input_field_mapping.
    def visitInput_field_mapping(self, ctx: lookup_splParser.Input_field_mappingContext):
        return self.visitChildren(ctx)

    # Visit a parse tree produced by lookup_splParser#output_field_mapping.
    def visitOutput_field_mapping(self, ctx: lookup_splParser.Output_field_mappingContext):
        return self.visitChildren(ctx)

    # Visit a parse tree produced by lookup_splParser#separator.
    def visitSeparator(self, ctx: lookup_splParser.SeparatorContext):
        return self.visitChildren(ctx)

    # Visit a parse tree produced by lookup_splParser#as_keyword.
    def visitAs_keyword(self, ctx: lookup_splParser.As_keywordContext):
        return self.visitChildren(ctx)


del lookup_splParser
