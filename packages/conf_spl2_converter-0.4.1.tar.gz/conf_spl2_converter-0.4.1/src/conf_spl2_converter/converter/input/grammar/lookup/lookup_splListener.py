# Generated from src/conf_spl2_converter/converter/input/grammar/lookup/lookup_spl.g4 by ANTLR 4.13.2
from antlr4 import *

if "." in __name__:
    from .lookup_splParser import lookup_splParser
else:
    from lookup_splParser import lookup_splParser


# This class defines a complete listener for a parse tree produced by lookup_splParser.
class lookup_splListener(ParseTreeListener):
    # Enter a parse tree produced by lookup_splParser#spl_cmd_start.
    def enterSpl_cmd_start(self, ctx: lookup_splParser.Spl_cmd_startContext):
        pass

    # Exit a parse tree produced by lookup_splParser#spl_cmd_start.
    def exitSpl_cmd_start(self, ctx: lookup_splParser.Spl_cmd_startContext):
        pass

    # Enter a parse tree produced by lookup_splParser#lookup_spl_command.
    def enterLookup_spl_command(self, ctx: lookup_splParser.Lookup_spl_commandContext):
        pass

    # Exit a parse tree produced by lookup_splParser#lookup_spl_command.
    def exitLookup_spl_command(self, ctx: lookup_splParser.Lookup_spl_commandContext):
        pass

    # Enter a parse tree produced by lookup_splParser#lookup_name.
    def enterLookup_name(self, ctx: lookup_splParser.Lookup_nameContext):
        pass

    # Exit a parse tree produced by lookup_splParser#lookup_name.
    def exitLookup_name(self, ctx: lookup_splParser.Lookup_nameContext):
        pass

    # Enter a parse tree produced by lookup_splParser#input_clause.
    def enterInput_clause(self, ctx: lookup_splParser.Input_clauseContext):
        pass

    # Exit a parse tree produced by lookup_splParser#input_clause.
    def exitInput_clause(self, ctx: lookup_splParser.Input_clauseContext):
        pass

    # Enter a parse tree produced by lookup_splParser#output_clause.
    def enterOutput_clause(self, ctx: lookup_splParser.Output_clauseContext):
        pass

    # Exit a parse tree produced by lookup_splParser#output_clause.
    def exitOutput_clause(self, ctx: lookup_splParser.Output_clauseContext):
        pass

    # Enter a parse tree produced by lookup_splParser#input_field_mapping.
    def enterInput_field_mapping(self, ctx: lookup_splParser.Input_field_mappingContext):
        pass

    # Exit a parse tree produced by lookup_splParser#input_field_mapping.
    def exitInput_field_mapping(self, ctx: lookup_splParser.Input_field_mappingContext):
        pass

    # Enter a parse tree produced by lookup_splParser#output_field_mapping.
    def enterOutput_field_mapping(self, ctx: lookup_splParser.Output_field_mappingContext):
        pass

    # Exit a parse tree produced by lookup_splParser#output_field_mapping.
    def exitOutput_field_mapping(self, ctx: lookup_splParser.Output_field_mappingContext):
        pass

    # Enter a parse tree produced by lookup_splParser#separator.
    def enterSeparator(self, ctx: lookup_splParser.SeparatorContext):
        pass

    # Exit a parse tree produced by lookup_splParser#separator.
    def exitSeparator(self, ctx: lookup_splParser.SeparatorContext):
        pass

    # Enter a parse tree produced by lookup_splParser#as_keyword.
    def enterAs_keyword(self, ctx: lookup_splParser.As_keywordContext):
        pass

    # Exit a parse tree produced by lookup_splParser#as_keyword.
    def exitAs_keyword(self, ctx: lookup_splParser.As_keywordContext):
        pass


del lookup_splParser
