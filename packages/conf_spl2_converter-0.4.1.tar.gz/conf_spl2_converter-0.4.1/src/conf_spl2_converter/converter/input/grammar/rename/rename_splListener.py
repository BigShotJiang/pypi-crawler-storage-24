# Generated from src/conf_spl2_converter/converter/input/grammar/rename/rename_spl.g4 by ANTLR 4.13.2
from antlr4 import *

if "." in __name__:
    from .rename_splParser import rename_splParser
else:
    from rename_splParser import rename_splParser


# This class defines a complete listener for a parse tree produced by rename_splParser.
class rename_splListener(ParseTreeListener):
    # Enter a parse tree produced by rename_splParser#spl_cmd_start.
    def enterSpl_cmd_start(self, ctx: rename_splParser.Spl_cmd_startContext):
        pass

    # Exit a parse tree produced by rename_splParser#spl_cmd_start.
    def exitSpl_cmd_start(self, ctx: rename_splParser.Spl_cmd_startContext):
        pass

    # Enter a parse tree produced by rename_splParser#rename_spl_command.
    def enterRename_spl_command(self, ctx: rename_splParser.Rename_spl_commandContext):
        pass

    # Exit a parse tree produced by rename_splParser#rename_spl_command.
    def exitRename_spl_command(self, ctx: rename_splParser.Rename_spl_commandContext):
        pass

    # Enter a parse tree produced by rename_splParser#input_clause.
    def enterInput_clause(self, ctx: rename_splParser.Input_clauseContext):
        pass

    # Exit a parse tree produced by rename_splParser#input_clause.
    def exitInput_clause(self, ctx: rename_splParser.Input_clauseContext):
        pass

    # Enter a parse tree produced by rename_splParser#input_field_mapping.
    def enterInput_field_mapping(self, ctx: rename_splParser.Input_field_mappingContext):
        pass

    # Exit a parse tree produced by rename_splParser#input_field_mapping.
    def exitInput_field_mapping(self, ctx: rename_splParser.Input_field_mappingContext):
        pass

    # Enter a parse tree produced by rename_splParser#separator.
    def enterSeparator(self, ctx: rename_splParser.SeparatorContext):
        pass

    # Exit a parse tree produced by rename_splParser#separator.
    def exitSeparator(self, ctx: rename_splParser.SeparatorContext):
        pass

    # Enter a parse tree produced by rename_splParser#as_keyword.
    def enterAs_keyword(self, ctx: rename_splParser.As_keywordContext):
        pass

    # Exit a parse tree produced by rename_splParser#as_keyword.
    def exitAs_keyword(self, ctx: rename_splParser.As_keywordContext):
        pass


del rename_splParser
