grammar lookup_spl;

spl_cmd_start: lookup_spl_command;
lookup_spl_command: 'lookup' lookup_name input_clause output_clause?;

lookup_name: SPLUNK_IDENTIFIER;
input_clause: input_field_mapping (separator input_field_mapping)*;
output_clause: ( OUTPUT | OUTPUTNEW ) output_field_mapping (separator output_field_mapping)*;
input_field_mapping: lookup_field=SPLUNK_IDENTIFIER ( as_keyword event_field=SPLUNK_IDENTIFIER)?;
output_field_mapping: lookup_destfield=SPLUNK_IDENTIFIER ( as_keyword event_destfield=SPLUNK_IDENTIFIER)?;
separator: (',' )?;  // allow comma OR nothing (i.e., just space)

as_keyword: AS | ASNEW;

AS: [aA][sS];
ASNEW: [aA][sS][nN][eE][wW];
OUTPUT: [oO][uU][tT][pP][uU][tT];
OUTPUTNEW: [oO][uU][tT][pP][uU][tT][nN][eE][wW];

SPLUNK_IDENTIFIER: [a-zA-Z][a-zA-Z0-9_.:-]*;
WS: [ \t\r\n]+ -> skip;
