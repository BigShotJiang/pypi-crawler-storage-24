# Conf To Spl2 Converter
# Copyright (C) 2026 Splunk Inc. All Rights Reserved.
#
# Installation and use subject to the Splunk General Terms,
# see https://www.splunk.com/en_us/legal/splunk-general-terms.html


"""Parser for SPL rename commands using ANTLR grammar."""

from __future__ import annotations

from dataclasses import dataclass, field

from antlr4 import CommonTokenStream, InputStream

from conf_spl2_converter.converter.input.grammar.rename.rename_splLexer import rename_splLexer
from conf_spl2_converter.converter.input.grammar.rename.rename_splParser import rename_splParser
from conf_spl2_converter.converter.input.grammar.rename.rename_splVisitor import rename_splVisitor


@dataclass
class RenameCommandData:
    input_fields_mapping: list[tuple[str, str]] = field(default_factory=list)


class RenameSPLCommandParser(rename_splVisitor):
    def __init__(self):
        self.command_data = RenameCommandData()

    def visitSpl_cmd_start(self, ctx):
        cmd_ctx = ctx.rename_spl_command()
        self.visit(cmd_ctx.input_clause())
        return self

    def visitInput_clause(self, ctx):
        for input_field_mapping in ctx.input_field_mapping():
            source_field = input_field_mapping.source_field.text
            if input_field_mapping.target_field is not None:
                target_field = input_field_mapping.target_field.text
            else:
                target_field = source_field
            self.command_data.input_fields_mapping.append((source_field, target_field))

    def parse(self, command_str) -> RenameCommandData:
        input_stream = InputStream(command_str)
        lexer = rename_splLexer(input_stream)
        stream = CommonTokenStream(lexer)
        parser = rename_splParser(stream)
        tree = parser.spl_cmd_start()
        self.visit(tree)
        return self.command_data
