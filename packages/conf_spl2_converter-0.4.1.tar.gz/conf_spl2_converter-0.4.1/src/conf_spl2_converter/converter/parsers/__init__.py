# Conf To Spl2 Converter
# Copyright (C) 2026 Splunk Inc. All Rights Reserved.
#
# Installation and use subject to the Splunk General Terms,
# see https://www.splunk.com/en_us/legal/splunk-general-terms.html


"""ANTLR-based parsers for SPL commands."""
