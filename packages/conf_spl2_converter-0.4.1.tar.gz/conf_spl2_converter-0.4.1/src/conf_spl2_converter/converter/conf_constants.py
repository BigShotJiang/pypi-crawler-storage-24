# Conf To Spl2 Converter
# Copyright (C) 2026 Splunk Inc. All Rights Reserved.
#
# Installation and use subject to the Splunk General Terms,
# see https://www.splunk.com/en_us/legal/splunk-general-terms.html


"""Splunk .conf file clause constants and enumerations."""


class SplunkEventFields:
    RAW = "_raw"


class PropsConfClause:
    FIELDALIAS = "FIELDALIAS"
    KV_MODE = "KV_MODE"
    INDEXED_EXTRACTIONS = "INDEXED_EXTRACTIONS"
    AUTO_KV_JSON = "AUTO_KV_JSON"
    REPORT = "REPORT"
    EXTRACT = "EXTRACT"
    EVAL = "EVAL"
    TRANSFORMS = "TRANSFORMS"
    LOOKUP = "LOOKUP"

    # Timestamping clauses
    DATETIME_CONFIG = "DATETIME_CONFIG"
    TIME_PREFIX = "TIME_PREFIX"
    MAX_TIMESTAMP_LOOKAHEAD = "MAX_TIMESTAMP_LOOKAHEAD"
    TIME_FORMAT = "TIME_FORMAT"
    TZ = "TZ"

    # Line breaking clauses
    TRUNCATE = "TRUNCATE"
    LINE_BREAKER = "LINE_BREAKER"
    LINE_BREAKER_LOOKBEHIND = "LINE_BREAKER_LOOKBEHIND"
    SHOULD_LINEMERGE = "SHOULD_LINEMERGE"
    BREAK_ONLY_BEFORE_DATE = "BREAK_ONLY_BEFORE_DATE"
    BREAK_ONLY_BEFORE = "BREAK_ONLY_BEFORE"
    MUST_BREAK_AFTER = "MUST_BREAK_AFTER"
    MUST_NOT_BREAK_AFTER = "MUST_NOT_BREAK_AFTER"
    MUST_NOT_BREAK_BEFORE = "MUST_NOT_BREAK_BEFORE"
    MAX_EVENTS = "MAX_EVENTS"
    ROUTE_EVENTS_OLDER_THAN = "ROUTE_EVENTS_OLDER_THAN"
    EVENT_BREAKER_ENABLE = "EVENT_BREAKER_ENABLE"
    EVENT_BREAKER = "EVENT_BREAKER"
    LB_CHUNK_BREAKER = "LB_CHUNK_BREAKER"
    LB_CHUNK_BREAKER_TRUNCATE = "LB_CHUNK_BREAKER_TRUNCATE"


class TransformsConfClause:
    REGEX = "REGEX"
    SOURCE_KEY = "SOURCE_KEY"
    DEST_KEY = "DEST_KEY"
    FORMAT = "FORMAT"
    DELIMS = "DELIMS"
    FIELDS = "FIELDS"
    FILENAME = "filename"
    EXTERNAL_TYPE = "external_type"


class KVModes:
    AUTO = "auto"
    JSON = "json"
    XML = "xml"
    NONE = "none"
    AUTO_ESCAPED = "auto_escaped"
    MULTI = "multi"


class Booleans:
    TRUE = "true"
    FALSE = "false"


class IndexedExtractions:
    CSV = "csv"
    TSV = "tsv"
    PSV = "psv"
    W3C = "w3c"
    JSON = "json"
    HEC = "hec"
