# Conf To Spl2 Converter
# Copyright (C) 2026 Splunk Inc. All Rights Reserved.
#
# Installation and use subject to the Splunk General Terms,
# see https://www.splunk.com/en_us/legal/splunk-general-terms.html


"""Content creation for SPL2 templates from TA configuration objects."""

from __future__ import annotations

import ast
import json
import logging
import os
import re
from pathlib import Path

from conf_spl2_converter.converter import commands
from conf_spl2_converter.converter.conf_clause_utils import (
    get_kv_pairs_for_stanza,
    is_eval_clause,
    is_extract_clause,
    is_field_alias_attribute,
    is_indexed_extraction_clause,
    is_kvmode_clause,
    is_lookup_attribute,
    is_max_timestamp_lookahead_clause,
    is_report_clause,
    is_time_clause,
    is_time_prefix_clause,
    is_transforms_clause,
    parse_eval_clause,
    parse_extract_clause,
    parse_report_clause,
    parse_transforms_clause,
)
from conf_spl2_converter.converter.conf_parser import get_ta_config_object, load_conf_files
from conf_spl2_converter.converter.input.configuration_constants import SPL2_RESERVED_FIELDS
from conf_spl2_converter.converter.input_config import (
    HUMAN_READABLE_NAME,
    SPLUNK_BASE_URL,
    TEMPLATE_VERSION,
    VERSION,
    InputConfig,
)
from conf_spl2_converter.converter.pipeline import Pipeline

logger = logging.getLogger("conf-spl2-converter")


def read_python_file(python_script: str, ta_package_bin_path: Path) -> dict:
    """Read a python script and extract the lookup_table variable.

    Args:
        python_script: Python script filename to read.
        ta_package_bin_path: Path to the bin folder of the addon.

    Returns:
        The lookup_table dict extracted from the script.
    """
    script_path = str(Path(os.path.join(ta_package_bin_path, f"{python_script}")))
    src = Path(script_path).read_text(encoding="utf-8")
    tree = ast.parse(src, filename=str(script_path.format(python_script=python_script)))
    lookup_table = {}
    for node in tree.body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id == "lookup_table":
                    lookup_table = ast.literal_eval(node.value)
    if not lookup_table:
        logger.warning(
            f"No 'lookup_table' variable found (or it is empty) in "
            f"'{script_path}'. Bitmask generation will fail for this script."
        )
    return lookup_table


def generate_bitmask_function_call_template(lookup_dict: dict, input_field: str) -> str:
    """Generate an eval expression for a call to bitmask_function.

    Args:
        lookup_dict: Dictionary of flags {bit_value: 'FLAG_NAME'}.
        input_field: Placeholder for the variable name.

    Returns:
        Expression for a function call.
    """
    max_key = max(lookup_dict.keys())
    key = 1
    while key <= max_key:
        lookup_dict.setdefault(key, "")
        key <<= 1

    lookup_values = json.dumps([lookup_dict[k] for k in sorted(lookup_dict.keys())])
    return f"flatten_one_element_mv(bitmask_to_values({input_field}, {lookup_values}))"


def reverse_report_statements(extractions: list) -> list:
    """Reverse report statements that share the same format string."""
    format_occurrences: dict[str, list[int]] = {}
    for i, item in enumerate(extractions):
        if "format" in item and item["format"] is not None and item["format"] != "$1::$2":
            format_value = item["format"]
            format_occurrences.setdefault(format_value.replace('"', ""), []).append(i)

    for _, indices_list in format_occurrences.items():
        if len(indices_list) > 1:
            extractions[indices_list[0] : indices_list[-1] + 1] = extractions[indices_list[0] : indices_list[-1] + 1][
                ::-1
            ]

    return extractions


def handle_extraction(extraction: dict, commands_to_add: list) -> None:
    """Process a single extraction and append generated commands."""
    if "regex" in extraction and extraction["regex"] is not None:
        rex_command = commands.RexCommand()
        # TODO ....
        if extraction["format"] and extraction["format"].startswith("nullQueue"):
            logger.warning(f"Format is 'nullQueue'. Skipping the extraction for regex: {extraction['regex']}")
            return
        if extraction["format"] and extraction["format"].startswith("$1_$2::$3"):
            logger.warning(
                f"Format is '$1_$2::$3'. This format is not supported in SPL2 and may lead to incorrect field extractions. "
                f"Consider changing the format to '$1::$2::$3' or similar. Skipping the extraction for regex: {extraction['regex']}"
            )
            return
        default_value_fields, generated_command, regex, dest_field_extraction, field_counts = rex_command.generate(
            source_field=extraction["source_field"],
            regex=extraction["regex"],
            format=extraction["format"],
            dest_field=extraction["dest_field"],
        )
        if not dest_field_extraction:
            commands_to_add.append(generated_command)
        if len(default_value_fields) > 0:
            for key, value in default_value_fields.items():
                eval_command = commands.EvalCommand()
                expression = f'coalesce({key}, if(match(_raw, /{regex}/), "{value}", null))'
                commands_to_add.extend(
                    eval_command.generate(field=key, expression=expression, convert_spl_to_spl2=False)
                )
        if any(value > 1 for value in field_counts.values()):
            for field, count in field_counts.items():
                if count > 1:
                    eval_command = commands.EvalCommand()
                    variants = [f"{field}{i}" for i in range(1, count)]
                    coalesce_expr = f"coalesce({', '.join([field, *variants])})"
                    commands_to_add.extend(
                        eval_command.generate(field=field, expression=coalesce_expr, convert_spl_to_spl2=False)
                    )
                    fields_command = commands.FieldsCommand()
                    commands_to_add.append(fields_command.generate(fields=" ".join(variants), operation="-"))
    elif "delims" in extraction and extraction["delims"] is not None:
        delims_command = commands.DelimsCommand()
        commands_to_add.append(
            delims_command.generate(
                source_field=extraction["source_field"],
                delims=extraction["delims"],
                fields=extraction["fields"],
            )
        )


def create_content(
    ta_config_object, input_config: InputConfig, sourcetype=None, source=None, sub_sourcetype=None
) -> dict:
    """Create SPL2 template content for a given sourcetype/source.

    Args:
        ta_config_object: The TA configuration object.
        input_config: The field extraction configuration.
        sourcetype: The sourcetype to process.
        source: The source to process (optional).
        sub_sourcetype: A sub-sourcetype to process (optional).

    Returns:
        A dict containing all template code for this sourcetype/source.
    """
    lookup_list = input_config.get_lookup_list(sourcetype)
    fields_to_trim = input_config.get_fields_to_trim(sourcetype)
    remove_duplicate_fields_case_insensitive = input_config.get_duplicate_fields_to_remove(sourcetype)
    fields_to_trim_newlines = input_config.get_fields_to_trim_newlines(sourcetype)
    fields_to_convert = input_config.get_convert_string_to_array(sourcetype)
    fields_to_trim_quotes = input_config.get_fields_to_trim_quotes(sourcetype)

    if source:
        logger.info(f"============== Creating content for: {source} ==============")
        clauses: list = get_kv_pairs_for_stanza(ta_config_object, "source::" + source)
    elif sub_sourcetype:
        logger.info(f"============== Creating content for: {sub_sourcetype} ==============")
        clauses: list = get_kv_pairs_for_stanza(ta_config_object, sub_sourcetype)
        sourcetype = sub_sourcetype
    else:
        logger.info(f"============== Creating content for: {sourcetype} ==============")
        clauses: list = get_kv_pairs_for_stanza(ta_config_object, sourcetype)
    rename_spl2_commands = []
    eval_spl2_commands = []
    trim_fields_eval_commands = []
    trim_fields_newlines_eval_commands = []
    fields_to_convert_eval_commands = []
    rex_spl2_commands_index_time = []
    rex_spl2_commands_search_time = []
    timestamping_kv_pairs = []
    lookup_spl2_commands = {}
    default_lookup_extractions = []
    scripted_lookups = []
    lookup_names = []
    kv_mode = input_config.get_kv_mode(sourcetype)
    is_bitmask_lookups = False
    indexed_extractions = "none"

    for clause in clauses:
        clause_key = clause[0]
        clause_value = clause[1]

        if clause_value == "":
            logger.warning(f"Skipping empty clause: {clause_key}")
            continue
        # Skip extractions with mvfilter (not supported in edge/ingest processor profiles)
        if "mvfilter" in clause_value:
            logger.warning(
                f"Skipping clause with 'mvfilter' (not supported in edge/ingest processor profiles): {clause_key} = {clause_value}"
            )
            continue
        # Skip problematic regex patterns
        if "\\\\\\" in clause_value:
            logger.warning(
                f"Skipping clause with problematic regex pattern '\\\\\\' (not supported in edge/ingest processor profiles): {clause_key} = {clause_value}"
            )
            continue
        if r"%\%" in clause_value:
            clause_value = clause_value.replace("%\\%", "%\\\\%")

        if is_transforms_clause(clause_key):
            extractions = parse_transforms_clause(clause_key, clause_value, ta_config_object)
            if (
                sourcetype is not None
                and sub_sourcetype is None
                and "dest_field" in extractions[0]
                and extractions[0]["dest_field"] == "MetaData:Sourcetype"
            ):
                logger.info(
                    f"Ignoring transforms clause '{clause_key} = {clause_value}' "
                    f"for sourcetype '{sourcetype}' as child sourcetype extraction is skipped."
                )
                continue
            for extraction in extractions:
                handle_extraction(extraction, rex_spl2_commands_index_time)

        elif is_extract_clause(clause_key):
            extractions = parse_extract_clause(clause_key, clause_value)
            for extraction in extractions:
                handle_extraction(extraction, rex_spl2_commands_search_time)

        elif is_report_clause(clause_key):
            extractions = parse_report_clause(clause_key, clause_value, ta_config_object)
            extractions = reverse_report_statements(extractions)
            for extraction in extractions:
                handle_extraction(extraction, rex_spl2_commands_search_time)

        elif is_field_alias_attribute(clause_key):
            # FIELDALIAS keeps both source and target field names,
            # so it maps to SPL2 eval (not rename).
            # e.g. FIELDALIAS-foo = bar AS baz -> | eval baz = bar
            rename_command = commands.RenameCommand()
            if "ASNEW" not in clause_value:
                command_data = rename_command.parse("rename " + clause_value.strip())
                eval_command = commands.EvalCommand()
                for field_mapping in command_data.input_fields_mapping:
                    rename_spl2_commands.extend(
                        eval_command.generate(
                            field=field_mapping[1],
                            expression=field_mapping[0],
                            pure_eval=True,
                            fields_to_trim=fields_to_trim,
                        )
                    )
            else:
                clause_values = clause_value.split(" ")
                src_field, dest_field = clause_values[0], clause_values[-1]
                field_expression = f"coalesce({dest_field}, {src_field})"
                logger.debug(field_expression)
                eval_command = commands.EvalCommand()
                rename_spl2_commands.extend(eval_command.generate(field=dest_field, expression=field_expression))

        elif is_eval_clause(clause_key):
            if "lookup(" in clause_value:
                pattern = r'json_extract\(lookup\("([^"]+)",\s*json_object\("([^"]+)",\s*[^)]+\),\s*json_array\("([^"]+)"\)\),\s*"[^"]+"\)'
                matches = re.findall(pattern, clause_value)

                lookup_commands = set()
                for _i, (table, source_field, output_field) in enumerate(matches, 1):
                    lookup_clause = f"{table} {source_field} OUTPUTNEW {output_field}"
                    lookup_command = commands.LookupCommand()
                    lookup_commands.add(lookup_command.generate(lookup_action=lookup_clause))

                clause_value = re.sub(pattern, lambda m: m.group(3), clause_value)
                eval_spl2_commands.extend(lookup_commands)

            if "nullif(" in clause_value:
                pattern = r"nullif\s*\(([^,]+?)\s*,\s*([^)]+?)\)"
                replacement_pattern = r"if(\1 == \2, null, \1)"
                clause_value = re.sub(pattern, replacement_pattern, clause_value)

            if "NOT" in clause_value:
                pattern = re.compile(r"NOT\s+(\w+)\s+IN\s*(\([^)]*\))")
                clause_value = pattern.sub(r"\1 NOT IN \2", clause_value)

            field_expression = parse_eval_clause(clause_key, clause_value)
            eval_command = commands.EvalCommand()
            eval_spl2_commands.extend(
                eval_command.generate(
                    field=field_expression["field"],
                    expression=field_expression["expression"],
                    pure_eval=True,
                )
            )

        elif is_time_clause(clause_key):
            clause_key = clause_key.strip()
            clause_value = clause_value.split("#")[0].strip()
            if is_time_prefix_clause(clause_key):
                timestamping_kv_pairs.append(clause_key.lower() + "=" + "/" + clause_value + "/")
            elif is_max_timestamp_lookahead_clause(clause_key):
                timestamping_kv_pairs.append(clause_key.lower() + "=" + clause_value)
            else:
                timestamping_kv_pairs.append(clause_key.lower() + "=" + '"' + clause_value + '"')

        elif is_lookup_attribute(clause_key):
            clause_key = clause_key.strip()
            clause_value = clause_value.split("#")[0].strip()

            transform_clause = clause_value.split(" ")[0]
            lookup_command = commands.LookupCommand()
            lookup_command_data = lookup_command.parse("lookup " + clause_value)

            logger.debug(f"clause key: '{clause_key}' and its transform clause: '{transform_clause}'")
            logger.debug(f"Lookup Command Data is: {lookup_command_data}")

            extractions = parse_transforms_clause(clause_key, transform_clause, ta_config_object)
            logger.debug(f"Extractions of '{transform_clause}' from transforms.conf are: {extractions}")
            ingest_lookup_import = True

            # Handle scripted lookups
            if (
                isinstance(extractions, dict)
                and "external_type" in extractions
                and extractions["external_type"] == "python"
            ):
                is_bitmask_lookups = True
                ingest_lookup_import = False
                python_script = extractions["external_cmd"].split()[0]
                ta_package_bin_path = Path(os.path.join(input_config.get_ta_location_for_sourcetype(sourcetype), "bin"))
                lookup_table = read_python_file(python_script, ta_package_bin_path)
                if not lookup_table:
                    logger.warning(
                        f"Skipping bitmask generation for scripted lookup "
                        f"'{python_script}' (sourcetype '{sourcetype}'): "
                        f"no 'lookup_table' found in script."
                    )
                else:
                    is_bitmask_lookups = True
                    output_field = lookup_command_data.output_fields[0][1]
                    field_expression = generate_bitmask_function_call_template(
                        lookup_dict=lookup_table,
                        input_field=lookup_command_data.input_fields[0][1],
                    )
                    eval_command = commands.EvalCommand()
                    scripted_lookups.extend(eval_command.generate(field=output_field, expression=field_expression))

            # Handle default_match in lookups
            if isinstance(extractions, dict) and "default_match" in extractions and "match_type" not in extractions:
                logger.debug("Found 'default_match' in the lookup extraction")
                input_field = lookup_command_data.input_fields[0]
                input_field_name = (
                    f"'{input_field[1]}'" if ":" in input_field[1] or "." in input_field[1] else input_field[1]
                )
                for output_field in lookup_command_data.output_fields:
                    output_field_name = f"'{output_field[1]}'" if ":" in output_field[1] else output_field[1]
                    default_match_ = extractions["default_match"]
                    field_expression = f'if(isnotnull({input_field_name}), coalesce({output_field_name}, "{default_match_}"), {output_field_name})'
                    eval_command = commands.EvalCommand()
                    default_lookup_extractions.extend(
                        eval_command.generate(field=output_field_name, expression=field_expression)
                    )
                    logger.debug(f"Handled the default match for '{output_field_name}'")

            if ingest_lookup_import:
                lookup_spl2_commands[clause_key] = [lookup_command.generate(lookup_action=clause_value)]
                if lookup_command_data.lookup_name in lookup_list:
                    for output_field in lookup_command_data.output_fields:
                        output_field_name = f"'{output_field[1]}'" if ":" in output_field[1] else output_field[1]
                        field_expression = f'if({output_field_name} == "<nil>", null, {output_field_name})'
                        eval_command = commands.EvalCommand()
                        lookup_spl2_commands[clause_key].extend(
                            eval_command.generate(field=output_field_name, expression=field_expression)
                        )
                        logger.debug(f"Added an eval for handling <nil> value in field '{output_field_name}'")
                lookup_names.append(lookup_command_data.lookup_name)

        else:
            if clause_key != "__name__":
                if is_kvmode_clause(clause_key):
                    kv_mode = clause_value.lower()
                elif is_indexed_extraction_clause(clause_key):
                    indexed_extractions = clause_value.lower()

    rex_spl2_commands = rex_spl2_commands_index_time + rex_spl2_commands_search_time
    timestamping_args = ", ".join(timestamping_kv_pairs)

    lookups = []
    for lookup_command in sorted(lookup_spl2_commands):
        lookups.extend(lookup_spl2_commands[lookup_command])

    for field in fields_to_trim:
        if field in SPL2_RESERVED_FIELDS:
            continue
        eval_command = commands.EvalCommand()
        trim_fields_eval_commands.extend(eval_command.generate(field=field, expression=f"trim({field})"))

    for field in fields_to_trim_newlines:
        eval_command = commands.EvalCommand()
        trim_fields_newlines_eval_commands.extend(
            eval_command.generate(field=field, expression=f'trim({field}, "\\r\\n ")', convert_spl_to_spl2=False)
        )

    for field in fields_to_trim_quotes:
        eval_command = commands.EvalCommand()
        trim_fields_eval_commands.extend(
            eval_command.generate(field=field, expression=f'replace({field}, /"/, "")', convert_spl_to_spl2=False)
        )

    # Removing duplicates while preserving order
    lookup_names = list(dict.fromkeys(lookup_names))

    for field in fields_to_convert:
        field_expression = f'if(isarray({field}) or ismv({field}), {field}, if(isnull({field}) or {field}=="", json_array(), json_array({field})))'
        eval_command = commands.EvalCommand()
        fields_to_convert_eval_commands.extend(
            eval_command.generate(field=field, expression=field_expression, convert_spl_to_spl2=False)
        )

    template_code = {
        "function_name": source if source else sourcetype,
        "regex_spl2_commands": rex_spl2_commands,
        "rename_spl2_commands": rename_spl2_commands,
        "eval_spl2_commands": eval_spl2_commands,
        "trim_fields_eval_commands": trim_fields_eval_commands,
        "trim_fields_newlines_eval_commands": trim_fields_newlines_eval_commands,
        "fields_to_convert_eval_commands": fields_to_convert_eval_commands,
        "timestamping_args": timestamping_args,
        "lookup_spl2_commands": lookups,
        "kv_mode": kv_mode,
        "indexed_extractions": indexed_extractions,
        "lookup_names": lookup_names,
        "default_lookup_extractions": default_lookup_extractions,
        "is_bitmask_lookups": is_bitmask_lookups,
        "scripted_lookups": scripted_lookups,
    }

    if len(remove_duplicate_fields_case_insensitive) > 0:
        template_code["remove_duplicate_fields"] = remove_duplicate_fields_case_insensitive

    return template_code


def create_spl2_templates(
    ta_path: str,
    config_file: str | None = None,
    output_dir: str | None = None,
    output_format: str = "spl2",
):
    """Main entry point: create SPL2 templates from TA configuration.

    Args:
        ta_path: Path to the TA package directory (contains default/props.conf).
        config_file: Optional path to field_extraction_config.json.
                     When omitted, all sourcetypes from props.conf are processed.
        output_dir: Optional output directory. Defaults to <ta_path>/default/data/spl2/.
        output_format: Output format - 'spl2' (default) or 'json'.
    """
    logger.info("=" * 20 + " CONTENT CREATION - STARTING " + "=" * 20)

    input_config = InputConfig(ta_path, config_file)

    if not output_dir:
        output_dir = os.path.join(input_config.ta_path, "default", "data", "spl2")
        logger.info(f"No output directory specified; using TA default: {output_dir}")

    ta_config_object = get_ta_config_object()
    conf_files = input_config.get_pt_conf_files()
    load_conf_files(ta_config_object, conf_files)
    input_sourcetypes = input_config.get_input_sourcetypes()

    for input_sourcetype in input_sourcetypes:
        multiple_sources = False
        multiple_sourcetypes = False
        template_code = {}

        input_sources = input_config.get_source(input_sourcetype)
        sub_sourcetypes = input_config.get_sub_sourcetypes(input_sourcetype)
        default_stanzas = input_config.get_default_stanza(input_sourcetype)

        if default_stanzas:
            for default_stanza in default_stanzas:
                code = create_content(ta_config_object, input_config, sourcetype=default_stanza)
                code["default_stanza"] = True
                template_code[default_stanza] = code

        if input_sources or sub_sourcetypes:
            multiple_sources = True
            if input_sources:
                for input_source in input_sources:
                    code = create_content(
                        ta_config_object, input_config, source=input_source, sourcetype=input_sourcetype
                    )
                    code["source"] = input_source
                    code["default_stanza"] = False
                    template_code[input_source] = code

            if sub_sourcetypes:
                multiple_sourcetypes = True
                for sub_sourcetype in sub_sourcetypes:
                    code = create_content(
                        ta_config_object, input_config, sub_sourcetype=sub_sourcetype, sourcetype=input_sourcetype
                    )
                    code["source"] = sub_sourcetype
                    code["default_stanza"] = False
                    template_code[sub_sourcetype] = code

            code = create_content(ta_config_object, input_config, sourcetype=input_sourcetype)
            code["default_stanza"] = False
            template_code[input_sourcetype] = code

            lookup_import_statements = []
            for template in template_code.values():
                for lookup_name in template["lookup_names"]:
                    if lookup_name not in lookup_import_statements:
                        lookup_import_statements.append(lookup_name)
            template_code[input_sourcetype]["lookup_names"] = lookup_import_statements

        else:
            code = create_content(ta_config_object, input_config, sourcetype=input_sourcetype)
            code["default_stanza"] = False
            template_code[input_sourcetype] = code

        pipeline = Pipeline(
            template_version=input_config.get_attribute_value_for_sourcetype(input_sourcetype, TEMPLATE_VERSION),
            addon_name=input_config.get_attribute_value_for_sourcetype(input_sourcetype, HUMAN_READABLE_NAME),
            version=input_config.get_attribute_value_for_sourcetype(input_sourcetype, VERSION),
            splunk_base_url=input_config.get_attribute_value_for_sourcetype(input_sourcetype, SPLUNK_BASE_URL),
            slug=input_config.get_slug_for_sourcetype(input_sourcetype),
            sourcetype=input_sourcetype,
            multiple_sources=multiple_sources,
            multiple_sourcetypes=multiple_sourcetypes,
        )
        pipeline.generate_pipeline(template_code, output_dir=output_dir, output_format=output_format)
