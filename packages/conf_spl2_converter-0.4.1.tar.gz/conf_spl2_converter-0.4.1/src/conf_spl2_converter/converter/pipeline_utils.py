# Conf To Spl2 Converter
# Copyright (C) 2026 Splunk Inc. All Rights Reserved.
#
# Installation and use subject to the Splunk General Terms,
# see https://www.splunk.com/en_us/legal/splunk-general-terms.html


"""Utility functions for pipeline formatting and generation."""

from __future__ import annotations

import logging
import re

from conf_spl2_converter.converter import commands
from conf_spl2_converter.utils.utils import load_kv_extraction_template

logger = logging.getLogger("conf-spl2-converter")

# Constants
EMPTY = ""
INDENT = " " * 11
NEWLINE = "\n"
OVERALL_INDENT = NEWLINE + INDENT


def format_commands(commands_list: list | None) -> str:
    """Format a list of commands with proper indentation."""
    if not commands_list:
        return EMPTY
    formatted = OVERALL_INDENT.join(commands_list)
    return OVERALL_INDENT + formatted


def format_regex_commands(regex_commands: list | None) -> str:
    """Format regex commands, filtering out invalid ones."""
    if not regex_commands:
        return EMPTY
    filtered = [cmd for cmd in regex_commands if "/None/" not in cmd]
    if not filtered:
        return EMPTY
    formatted = OVERALL_INDENT.join(filtered)
    return OVERALL_INDENT + formatted


def format_lookup_imports(lookup_names: list | None) -> str:
    """Format lookup import statements."""
    if not lookup_names:
        return EMPTY
    lookup_import = "import {lookup_name} from ~/../../lookups"
    imports = []
    for name in lookup_names:
        formatted_name = f"'{name}'" if "-" in name else name
        imports.append(lookup_import.format(lookup_name=formatted_name))
    return NEWLINE.join(imports)


def format_kv_mode(kv_mode: str | None) -> str:
    """Format KV mode extractions."""
    if kv_mode == "json":
        return OVERALL_INDENT + "| _flatten_json"
    elif kv_mode == "auto":
        kv_template = load_kv_extraction_template()
        formatted_template = kv_template.format(
            source_field="_raw",
            regex=r"(?ms)^(\w+)=\s*([\s\S]*?)(?=\R\w+=|\Z)",
        )
        return OVERALL_INDENT + formatted_template
    return EMPTY


def create_functions_for_source_sourcetype(
    template_code: dict, pipeline_code: dict, source: str | None, source_function: str
) -> None:
    """Create SPL2 functions for a source/sourcetype."""
    function_command = commands.SourcetypeFunctionCommand()
    function_code = function_command.generate(
        function=source_function,
        auto_kv_mode="" if source else template_code["kv_mode"],
        regex_based_extractions=template_code["regex_spl2_commands"],
        aliases=template_code["rename_spl2_commands"],
        code_based_extractions=template_code["eval_spl2_commands"],
    )
    pipeline_code["functions"] += NEWLINE + function_code


def create_function_to_apply_lookups(template_code: dict, pipeline_code: dict, source_function: str) -> None:
    """Create SPL2 function to apply lookups."""
    lookup_function_command = commands.LookupFunctionCommand()
    lookup_function_code = lookup_function_command.generate(
        function=source_function,
        lookups=template_code["lookup_spl2_commands"],
        default_lookup_extractions=template_code["default_lookup_extractions"],
        scripted_lookups=template_code["scripted_lookups"],
    )
    pipeline_code["lookup_functions"] += NEWLINE + lookup_function_code


def calculate_main_sourcetype_function_name(sourcetype: str) -> str:
    """Convert sourcetype to a valid SPL2 function name."""
    return re.sub(r"[^a-zA-Z0-9_]", "_", sourcetype)
