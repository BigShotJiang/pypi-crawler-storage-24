# Conf To Spl2 Converter
# Copyright (C) 2026 Splunk Inc. All Rights Reserved.
#
# Installation and use subject to the Splunk General Terms,
# see https://www.splunk.com/en_us/legal/splunk-general-terms.html


"""conf-spl2-converter - A Python CLI tool for converting configurations."""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("conf-spl2-converter")
except PackageNotFoundError:
    __version__ = "0.0.0-dev"
