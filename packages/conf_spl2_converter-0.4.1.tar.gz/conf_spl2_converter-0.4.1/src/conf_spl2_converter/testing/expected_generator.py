# Conf To Spl2 Converter
# Copyright (C) 2026 Splunk Inc. All Rights Reserved.
#
# Installation and use subject to the Splunk General Terms,
# see https://www.splunk.com/en_us/legal/splunk-general-terms.html


"""Generate module.test.json files by sending samples through Splunk and capturing extracted fields."""

from __future__ import annotations

import json
import logging
import os
import re
import uuid
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy

from conf_spl2_converter.testing.constants import (
    IGNORE_KEYS_FOR_COMPARISON,
    MAX_WORKERS,
    MODULE_TEST_TEMPLATE,
    SPLUNK_INDEX,
)
from conf_spl2_converter.testing.splunk_manager import SplunkManager, send_event_to_splunk

logger = logging.getLogger("conf-spl2-converter")


def _filter_fields(splunk_fields: dict) -> dict:
    """Remove internal/comparison-irrelevant fields, keeping only _time and _raw from underscore-prefixed ones."""
    return {
        k: v
        for k, v in splunk_fields.items()
        if k not in IGNORE_KEYS_FOR_COMPARISON and (not k.startswith("_") or k in {"_time", "_raw"})
    }


def _convert_string_to_array(fields_to_alter: list[str], event_fields: dict) -> dict:
    """Convert comma-separated string fields to arrays for module.test.json compatibility."""
    for field in fields_to_alter:
        if field in event_fields and isinstance(event_fields[field], str):
            value = event_fields[field].strip()
            event_fields[field] = [] if not value else [item.strip() for item in value.split(",") if item.strip()]
        elif field not in event_fields:
            event_fields[field] = []
    return event_fields


def _prepare_module_test(sourcetype_slug: str, filtered_fields: dict, source_host: str | None = None) -> dict:
    """Build a single module_test entry for one event."""
    module_test = deepcopy(MODULE_TEST_TEMPLATE)
    module_test["filename"] = module_test["filename"].format(sourcetype_slug=sourcetype_slug)

    host_for_source = source_host if source_host is not None else filtered_fields.get("host")
    module_test["test"]["source"] = module_test["test"]["source"].format(
        raw=json.dumps(filtered_fields.get("_raw"))[1:-1],
        source=filtered_fields.get("source"),
        sourcetype=filtered_fields.get("sourcetype"),
        host=host_for_source,
    )
    module_test["test"]["expected_destination_result"] = [filtered_fields]
    return module_test


def _read_existing_module_test(module_test_path: str) -> list[dict]:
    """Read an existing module.test.json if present."""
    if not os.path.exists(module_test_path):
        return []
    try:
        with open(module_test_path) as f:
            data = json.load(f)
            logger.info(f"Found existing module.test.json with {len(data)} test(s)")
            return data
    except Exception as e:
        logger.warning(f"Failed to read existing module.test.json: {e}")
        return []


def _find_existing_test_by_raw(existing_tests: list[dict], raw_value: str) -> dict | None:
    """Find an existing test entry by matching _raw field.

    Returns a merged dict including fields from excluded sections so that
    preserved values like _time survive across regenerations.
    """
    for test in existing_tests:
        try:
            test_section = test.get("test", {})
            expected_results = test_section.get("expected_destination_result", [])
            if expected_results and expected_results[0].get("_raw") == raw_value:
                merged = dict(expected_results[0])
                for section in ("expected_missing", "expected_different", "expected_additional"):
                    for item in test_section.get(section, []):
                        if isinstance(item, dict) and "key" in item and "value" in item and item["key"] not in merged:
                            merged[item["key"]] = item["value"]
                return merged
        except (KeyError, IndexError):
            continue
    return None


def _extract_source_host_from_test(test: dict) -> str | None:
    """Extract the host value from the source template string in an existing test."""
    try:
        source_str = test.get("test", {}).get("source", "")
        match = re.search(r'host:\s*"([^"]+)"', source_str)
        if match:
            return match.group(1)
    except Exception as e:
        logger.warning(f"Failed to extract source host: {e}")
    return None


def _preserve_existing_fields(filtered_fields: dict, existing_data: dict | None) -> dict:
    """Preserve certain fields from existing test data to maintain stability across regenerations."""
    if not existing_data:
        return filtered_fields
    fields_to_preserve = [
        "host",
        "_time",
        "source",
        "dvc_nt_host",
        "event_time",
        "event_ingest_time",
        "dvc",
        "dest",
        "dest_host",
        "src",
    ]
    for field in fields_to_preserve:
        if field in existing_data:
            filtered_fields[field] = existing_data[field]
            logger.debug(f"Preserved existing '{field}' field")
    return filtered_fields


def _merge_tests_preserve_order(existing_tests: list[dict], new_events_dict: dict, sourcetype_slug: str) -> list[dict]:
    """Merge new tests with existing ones, preserving order of existing tests."""
    module_test_json: list[dict] = []
    processed_raws: set[str] = set()

    for existing_test in existing_tests:
        try:
            expected_results = existing_test.get("test", {}).get("expected_destination_result", [])
            if expected_results:
                raw_value = expected_results[0].get("_raw")
                if raw_value and raw_value in new_events_dict:
                    event_data = new_events_dict[raw_value]
                    module_test = _prepare_module_test(sourcetype_slug, event_data["fields"], event_data["host"])
                    module_test_json.append(module_test)
                    processed_raws.add(raw_value)
        except (KeyError, IndexError) as e:
            logger.warning(f"Error processing existing test: {e}")
            continue

    for raw_value, event_data in new_events_dict.items():
        if raw_value not in processed_raws:
            module_test = _prepare_module_test(sourcetype_slug, event_data["fields"], event_data["host"])
            module_test_json.append(module_test)

    new_count = len(new_events_dict) - len(processed_raws)
    logger.info(f"Merged tests: {len(processed_raws)} existing (order preserved) + {new_count} new")
    return module_test_json


def _ingest_sample(sample: dict) -> None:
    """Send a single sample event to Splunk via HEC with a unique host."""
    source = sample.get("transport", {}).get("source")
    host = str(uuid.uuid4())
    sourcetype = sample.get("transport", {}).get("sourcetype")
    send_event_to_splunk(SPLUNK_INDEX, sample.get("raw", ""), sourcetype, host, source)


def generate_expected_for_sourcetype(
    samples_file: str,
    sourcetype_slug: str,
    sourcetypes_to_process: list[str],
    output_dir: str,
    string_to_array_fields: list[str] | None = None,
) -> None:
    """Generate module.test.json for a single sourcetype by running samples through Splunk.

    Args:
        samples_file: Path to the .samples JSONL file.
        sourcetype_slug: The slug identifier for file naming.
        sourcetypes_to_process: All sourcetypes to query (main + sub_sourcetypes).
        output_dir: Directory to write module.test.json.
        string_to_array_fields: Fields whose values should be converted from string to array.
    """
    if string_to_array_fields is None:
        string_to_array_fields = []

    module_test_json_path = os.path.join(output_dir, sourcetype_slug, "module.test.json")
    existing_module_tests = _read_existing_module_test(module_test_json_path)

    with open(samples_file) as f:
        samples = [json.loads(line) for line in f]

    if not samples:
        logger.info(f"No samples in '{samples_file}', skipping")
        return

    logger.info(f"Processing {len(samples)} samples from {samples_file}")

    logger.info(f"Sending {len(samples)} events to Splunk...")
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        list(executor.map(_ingest_sample, samples))
    logger.info(f"Successfully sent {len(samples)} event(s) to Splunk")

    splunk = SplunkManager()

    all_events: list[dict] = []
    for sourcetype in sourcetypes_to_process:
        logger.info(f"Fetching events for sourcetype: '{sourcetype}'")
        events = splunk.get_events_by_sourcetype(sourcetype=sourcetype)
        all_events.extend(events)
        logger.info(f"Got {len(events)} events for sourcetype '{sourcetype}'")
    logger.info(f"Total events from Splunk: {len(all_events)}")

    new_events_dict: dict[str, dict] = {}
    for event_fields in all_events:
        filtered = _filter_fields(event_fields)
        filtered = _convert_string_to_array(string_to_array_fields, filtered)

        raw_value = filtered.get("_raw")
        if not raw_value or raw_value in new_events_dict:
            if raw_value in new_events_dict:
                logger.warning(f"Skipping duplicate event with same _raw: {raw_value[:50]}...")
            continue

        new_host = filtered.get("host")
        existing_data = _find_existing_test_by_raw(existing_module_tests, raw_value)
        filtered = _preserve_existing_fields(filtered, existing_data)

        host_to_use = filtered.get("host") if existing_data else new_host
        new_events_dict[raw_value] = {"fields": filtered, "host": host_to_use}

    module_test_json = _merge_tests_preserve_order(existing_module_tests, new_events_dict, sourcetype_slug)

    for sourcetype in sourcetypes_to_process:
        logger.info(f"Cleaning up events for sourcetype: '{sourcetype}'")
        splunk.delete_all_events(sourcetype=sourcetype)

    output_path = os.path.join(output_dir, sourcetype_slug)
    os.makedirs(output_path, exist_ok=True)
    with open(module_test_json_path, "w") as f:
        json.dump(module_test_json, f, indent=2)
        f.write("\n")

    logger.info(f"Generated module.test.json at '{module_test_json_path}' with {len(module_test_json)} test(s)")
