# Conf To Spl2 Converter
# Copyright (C) 2026 Splunk Inc. All Rights Reserved.
#
# Installation and use subject to the Splunk General Terms,
# see https://www.splunk.com/en_us/legal/splunk-general-terms.html


"""Docker Compose orchestration for Splunk field-extraction container."""

from __future__ import annotations

import logging
import os
import subprocess
import time

from conf_spl2_converter.testing.constants import (
    DOCKER_COMPOSE_DIR,
    DOCKER_CONTAINER_NAME,
    SPLUNK_API_PORT,
    SPLUNK_HOST,
    SPLUNK_PASSWORD,
    SPLUNK_USERNAME,
)

logger = logging.getLogger("conf-spl2-converter")

HEALTH_CHECK_INTERVAL = 10
HEALTH_CHECK_MAX_RETRIES = 60


def _run_compose(args: list[str], env: dict[str, str] | None = None) -> subprocess.CompletedProcess:
    """Run a docker compose command in the docker/ directory."""
    cmd = ["docker", "compose", *args]
    merged_env = {**os.environ, **(env or {})}
    logger.debug(f"Running: {' '.join(cmd)}")
    return subprocess.run(cmd, cwd=DOCKER_COMPOSE_DIR, env=merged_env, capture_output=True, text=True, check=False)


def start_splunk(ta_package_path: str, ta_label: str) -> None:
    """Start the Splunk container with the TA mounted."""
    env = {
        "TA_PACKAGE_PATH": os.path.abspath(ta_package_path),
        "TA_LABEL": ta_label,
    }
    logger.info(f"Starting Splunk container with TA mounted at /opt/splunk/etc/apps/{ta_label}")

    result = _run_compose(["up", "-d", "--build"], env=env)
    if result.returncode != 0:
        raise RuntimeError(f"Failed to start Splunk container:\n{result.stderr}")

    logger.info("Splunk container started, waiting for it to become healthy...")
    _wait_for_splunk_ready()


def _wait_for_splunk_ready() -> None:
    """Poll Splunk's management API until it responds, indicating readiness."""
    import requests
    import urllib3

    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    url = f"https://{SPLUNK_HOST}:{SPLUNK_API_PORT}/services/server/info"
    for attempt in range(1, HEALTH_CHECK_MAX_RETRIES + 1):
        try:
            resp = requests.get(url, auth=(SPLUNK_USERNAME, SPLUNK_PASSWORD), verify=False, timeout=5)
            if resp.status_code == 200:
                logger.info(f"Splunk is ready (took {attempt * HEALTH_CHECK_INTERVAL}s)")
                return
        except Exception:
            pass
        logger.debug(f"Waiting for Splunk... attempt {attempt}/{HEALTH_CHECK_MAX_RETRIES}")
        time.sleep(HEALTH_CHECK_INTERVAL)

    raise TimeoutError(
        f"Splunk did not become ready after {HEALTH_CHECK_MAX_RETRIES * HEALTH_CHECK_INTERVAL}s. "
        f"Check container logs: docker logs {DOCKER_CONTAINER_NAME}"
    )


def stop_splunk() -> None:
    """Stop and remove the Splunk container."""
    logger.info("Stopping Splunk container...")
    result = _run_compose(["down", "-v"])
    if result.returncode != 0:
        logger.warning(f"Issue stopping Splunk container: {result.stderr}")
    else:
        logger.info("Splunk container stopped and removed")


def is_splunk_running() -> bool:
    """Check if the Splunk container is already running."""
    result = subprocess.run(
        ["docker", "inspect", "-f", "{{.State.Running}}", DOCKER_CONTAINER_NAME],
        capture_output=True,
        text=True,
        check=False,
    )
    return result.returncode == 0 and "true" in result.stdout.strip().lower()
