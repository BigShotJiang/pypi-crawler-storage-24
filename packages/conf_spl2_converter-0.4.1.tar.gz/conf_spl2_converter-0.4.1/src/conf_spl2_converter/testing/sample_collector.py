# Conf To Spl2 Converter
# Copyright (C) 2026 Splunk Inc. All Rights Reserved.
#
# Installation and use subject to the Splunk General Terms,
# see https://www.splunk.com/en_us/legal/splunk-general-terms.html


"""Collect test samples from TA repositories and write .samples files."""

from __future__ import annotations

import glob
import json
import logging
import os

from defusedxml import ElementTree

logger = logging.getLogger("conf-spl2-converter")


def _extract_cim_fields(event_elem) -> dict | None:
    """Extract CIM models, fields, and missing recommended fields from an <event> element.

    Returns a dict with 'models', 'cim_fields', and 'missing_recommended_fields',
    or None if no CIM data is present.
    """
    cim_elem = event_elem.find("cim")
    if cim_elem is None or len(cim_elem) == 0:
        return None

    models: list[str] = []
    models_elem = cim_elem.find("models")
    if models_elem is not None:
        models = [m.text for m in models_elem.findall("model") if m.text]

    cim_fields: dict[str, str] = {}
    cim_fields_elem = cim_elem.find("cim_fields")
    if cim_fields_elem is not None:
        for field in cim_fields_elem.findall("field"):
            name = field.attrib.get("name")
            value = field.attrib.get("value")
            if name is not None and value is not None:
                cim_fields[name] = value

    missing: list[str] = []
    missing_elem = cim_elem.find("missing_recommended_fields")
    if missing_elem is not None:
        missing = [f.text for f in missing_elem.findall("field") if f.text]

    if not models and not cim_fields and not missing:
        return None

    result: dict = {}
    if models:
        result["models"] = models
    if cim_fields:
        result["cim_fields"] = cim_fields
    if missing:
        result["missing_recommended_fields"] = missing

    return result


def discover_sample_files(ta_path: str) -> list[str]:
    """Find all .xml and .log sample files in the TA's tests/knowledge/samples/ directory."""
    samples_dir = os.path.join(ta_path, "tests", "knowledge", "samples")
    if not os.path.isdir(samples_dir):
        logger.warning(f"Samples directory not found: {samples_dir}")
        return []

    xml_files = glob.glob(os.path.join(samples_dir, "*.xml"))
    log_files = glob.glob(os.path.join(samples_dir, "*.log"))
    all_files = xml_files + log_files

    logger.info(f"Discovered {len(all_files)} sample files in {samples_dir}")
    return all_files


def collect_samples_for_sourcetypes(
    sample_files: list[str],
    sourcetypes_to_collect: list[str],
    output_file: str,
) -> int:
    """Parse XML/log sample files, filter by sourcetype, and write a .samples JSONL file.

    Returns the number of samples collected.
    """
    os.makedirs(os.path.dirname(output_file), exist_ok=True)
    if os.path.exists(output_file):
        os.remove(output_file)

    samples_collected = 0
    samples_by_sourcetype: dict[str, int] = {st: 0 for st in sourcetypes_to_collect}

    for sample_file in sample_files:
        try:
            tree = ElementTree.parse(sample_file)
            device = tree.getroot()
        except ElementTree.ParseError as e:
            logger.warning(f"Skipping malformed XML file '{sample_file}': {e}")
            continue
        except Exception as e:
            logger.warning(f"Error parsing file '{sample_file}': {e}")
            continue

        with open(output_file, "a") as f:
            for event in device.findall("event"):
                transport_elem = event.find("transport")
                raw_elem = event.find("raw")
                if transport_elem is None or raw_elem is None:
                    continue

                event_sourcetype = transport_elem.attrib.get("sourcetype", "")
                if event_sourcetype not in sourcetypes_to_collect:
                    continue

                data_dict: dict = {
                    "transport": dict(transport_elem.attrib),
                    "raw": raw_elem.text.strip() if raw_elem.text else "",
                }

                cim_data = _extract_cim_fields(event)
                if cim_data:
                    data_dict["cim"] = cim_data

                f.write(json.dumps(data_dict) + "\n")
                samples_collected += 1
                samples_by_sourcetype[event_sourcetype] += 1

    logger.info(f"Collected {samples_collected} samples -> {output_file}")
    if len(sourcetypes_to_collect) > 1:
        logger.info(f"  Breakdown by sourcetype: {samples_by_sourcetype}")

    return samples_collected
