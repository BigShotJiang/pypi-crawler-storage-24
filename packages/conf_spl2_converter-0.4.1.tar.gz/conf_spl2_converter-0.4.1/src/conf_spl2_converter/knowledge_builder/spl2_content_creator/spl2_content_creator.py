from __future__ import annotations

import contextlib
import json
import os
import re

from conf_spl2_converter.converter.input_config import (
    HUMAN_READABLE_NAME,
    SPLUNK_BASE_URL,
    TEMPLATE_VERSION,
    VERSION,
    InputConfig,
)
from conf_spl2_converter.knowledge_builder.common_utils.log_utils import logger
from conf_spl2_converter.knowledge_builder.common_utils.spl2_utils import (
    get_combined_knowledge_base_provider_spl2_file,
    get_knowledge_base_provider_function_name,
    get_knowledge_base_provider_function_name_source_sourcetype,
    get_spl2_safe_sourcetype_name,
)
from conf_spl2_converter.knowledge_builder.common_utils.utils import (
    get_knowledge_base_for_sourcetype,
    sort_knowledge_base,
)
from conf_spl2_converter.knowledge_builder.input.configuration_constants import (
    IMPORT_NOISEREDUCE_TEMPLATE,
    KNOWLEDGE_BASE_PROVIDER_SPL2_TEMPLATE,
    PIPELINE_SPL2_TEMPLATE,
    SPL2_CONTENT_FOLDER,
)


def format_knowledge_base_json(knowledge_base_for_sourcetype_json_str):
    formatted_json = []
    for line_number, line in enumerate(knowledge_base_for_sourcetype_json_str.splitlines(), start=1):
        if line_number == 1:
            formatted_json.append(line)
        else:
            formatted_json.append(" " * 18 + line)

    return "\n".join(formatted_json)


def get_knowledge_base_provider_spl2_template():
    with open(KNOWLEDGE_BASE_PROVIDER_SPL2_TEMPLATE) as f:
        return f.read()


def get_import_noisereduce_spl2_template():
    with open(IMPORT_NOISEREDUCE_TEMPLATE) as f:
        return f.read()


def get_pipeline_spl2_template():
    with open(PIPELINE_SPL2_TEMPLATE) as f:
        return f.read()


def _get_sourcetypes_from_kb_pairs(kb_pairs):
    """Return distinct sourcetypes from kb_pairs keys (sourcetype, source), sorted."""
    return sorted({pair[0] for pair in kb_pairs})


def _get_expanded_sourcetypes(input_config: InputConfig) -> tuple[list, list]:
    """
    Return (branch_sourcetypes, catchall_sourcetypes).
    - branch_sourcetypes: sourcetypes that get a branch and KB function (sub_sourcetypes only when present; else parent).
    - catchall_sourcetypes: sourcetypes to list in the last-line negative condition (parent + sub_sourcetypes when present).
    So when sub_sourcetypes exist we do not branch on the main sourcetype and do not emit a function for it.
    """
    branch_list = []
    catchall_list = []
    for st in input_config.get_input_sourcetypes():
        sub_sourcetypes = input_config.get_sub_sourcetypes(st)
        if sub_sourcetypes:
            branch_list.extend(sub_sourcetypes)
            catchall_list.append(st)
            catchall_list.extend(sub_sourcetypes)
        else:
            branch_list.append(st)
            catchall_list.append(st)
    return branch_list, catchall_list


def _get_pairs_for_sourcetype(kb_pairs, sourcetype):
    """Return the subset of kb_pairs for the given sourcetype."""
    return {pair: kb for pair, kb in kb_pairs.items() if pair[0] == sourcetype}


def _kb_function_block(kb_template: str, fn_name: str, kb: dict) -> str:
    """One KB function block: sort kb, format with template, return string."""
    sort_knowledge_base(kb)
    return kb_template.format(
        knowledge_base_provider_function_name=fn_name,
        knowledgebase_json=format_knowledge_base_json(json.dumps(kb, indent=2)),
    )


def _branch_line(match_field: str, regex: str, fn_name: str, end_semicolon: bool = False) -> str:
    """One pipeline branch: match on field, noisereduce with fn_name, into $destination.
    Suffix is '],' or '];' only (no extra ']' before suffix to avoid ']],')."""
    suffix = "];" if end_semicolon else "],"
    base = f"[ where match({match_field}, /{regex}/) | eval _raw=noisereduce({fn_name}(), _raw)  | into $destination"
    return base + suffix


def create_spl2_content(input_config: InputConfig, kb_pairs=None):
    """
    Single entry point: generate one SPL2 file for all sourcetypes/sources.
    - When kb_pairs is None or empty: branch on sourcetype (one KB per sourcetype + catch-all).
    - When kb_pairs is non-empty: branch on source (per-pair, per-sourcetype, default branch).
    Output path is get_combined_knowledge_base_provider_spl2_file(sourcetypes).
    """
    if kb_pairs is None:
        kb_pairs = {}
    if kb_pairs:
        sourcetypes = _get_sourcetypes_from_kb_pairs(kb_pairs)
        catchall_sourcetypes = None  # use same as sourcetypes
        filename_sourcetypes = sourcetypes
    else:
        branch_sourcetypes, catchall_sourcetypes = _get_expanded_sourcetypes(input_config) if input_config else ([], [])
        sourcetypes = branch_sourcetypes
        catchall_sourcetypes = catchall_sourcetypes if branch_sourcetypes != catchall_sourcetypes else None
        # Filename uses only parent sourcetype(s), not sub_sourcetypes
        if input_config and catchall_sourcetypes is not None and len(catchall_sourcetypes) > len(sourcetypes):
            filename_sourcetypes = input_config.get_input_sourcetypes()
        else:
            filename_sourcetypes = catchall_sourcetypes if catchall_sourcetypes is not None else sourcetypes
    if not sourcetypes:
        return

    _write_spl2_content(input_config, kb_pairs, sourcetypes, catchall_sourcetypes, filename_sourcetypes)


def _to_spl2_regex(s: str) -> str:
    r"""
    Convert a glob-like or regex-like pattern into a string safe for use inside an SPL2
    regex literal (the text that would appear between the `/` delimiters).

    - Normalize `...` -> `.*`.
    - If the pattern contains explicit regex tokens, treat it as a regex:
      - do not disturb existing `.*`
      - convert standalone `*` (not part of `.*`) -> `.*` (heuristic)
      - double backslashes and escape `/`
    - Otherwise treat as glob-like:
      - escape with `re.escape`, convert escaped `\*` -> `.*`, and escape `/`.
    """
    if not s:
        return ""

    # normalize the explicit shorthand
    s = s.replace("...", ".*")

    regex_tokens = ("(", ")", "|", "[", "]", "{", "}", "?", "+", "^", "$")
    is_regex_like = any(tok in s for tok in regex_tokens)

    if is_regex_like:
        # Heuristic: convert '*' that are NOT already part of '.*' into '.*' to support mixed inputs,
        # but avoid converting existing '.*' into '..*'
        s = re.sub(r"(?<!\.)\*", ".*", s)
        # double backslashes so the SPL2 regex literal sees '\\' for each '\' in the pattern
        s = s.replace("\\", r"\\")
        # escape the SPL2 regex delimiter '/'
        s = s.replace("/", r"\/")
        return s
    else:
        # Treat as glob-like: escape regex metacharacters, convert glob '*' -> '.*'
        escaped = re.escape(s)
        # convert escaped glob stars back into '.*'
        escaped = escaped.replace(r"\*", ".*")
        # ensure slash is escaped for /.../ delimiter
        escaped = escaped.replace("/", r"\/")
        return escaped


# Knowledge Builder template naming: output_dir/<slug>/{slug}_noisereduce.spl2
NOISEREDUCE_FILE_NAME = "{slug}_noisereduce.spl2"
COMBINED_SLUG = "all_sourcetypes"

DEFAULT_TEMPLATE_VERSION = "0.1.0"
HEADER_PLACEHOLDER_ADDON = "[ADDON_DISPLAY_NAME]"
HEADER_PLACEHOLDER_VERSION = "[COMPATIBLE_VERSION]"
HEADER_PLACEHOLDER_URL = "[SPLUNKBASE_URL]"
HEADER_PLACEHOLDER_TEMPLATE_VERSION = "[TEMPLATE_VERSION]"

DISCLAIMER_TEXT = """
 Disclaimer :
 BY USING SPL2 TEMPLATES FOR DATA PROCESSING (THE "TEMPLATES"), YOU UNDERSTAND AND AGREE THAT TEMPLATES ARE PROVIDED "AS IS". SPLUNK DISCLAIMS ANY AND ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND WARRANTIES ARISING OUT OF COURSE OF DEALING OR USAGE OF TRADE OR BY STATUTE OR IN LAW. SPLUNK SPECIFICALLY DOES NOT WARRANT THAT TEMPLATES WILL MEET YOUR REQUIREMENTS, THE OPERATION OR OUTPUT OF TEMPLATES WILL BE ERROR-FREE, ACCURATE, RELIABLE, COMPLETE OR UNINTERRUPTED.
"""


def _addon_display_name_from_addon_name(addon_name: str) -> str:
    """Derive short display name from addon_name (e.g. splunk-add-on-for-cisco-asa -> Cisco ASA)."""
    if not addon_name or not addon_name.strip():
        return HEADER_PLACEHOLDER_ADDON
    s = addon_name.strip().lower()
    for prefix in ("splunk-add-on-for-", "splunk_ta_", "splunk-ta-"):
        if s.startswith(prefix):
            s = s[len(prefix) :]
            break
    return s.replace("-", " ").replace("_", " ").title()


def _build_noisereduce_header(
    input_config: InputConfig | None,
    sourcetypes: list,
    include_disclaimer: bool = True,
    overview_note: str | None = None,
) -> str:
    """
    Build the comment header for a noise reduction SPL2 template.
    Uses metadata from the first sourcetype when input_config is provided; otherwise placeholders.
    """
    if not sourcetypes:
        first_st = None
        sourcetype_display = "[SOURCETYPE]"
    else:
        first_st = sourcetypes[0]
        sourcetype_display = ", ".join(sourcetypes) if len(sourcetypes) > 1 else first_st

    if input_config and first_st:
        human = input_config.get_attribute_value_for_sourcetype(first_st, HUMAN_READABLE_NAME)
        addon_name = input_config.get_addon_name_for_sourcetype(first_st)
        version = input_config.get_attribute_value_for_sourcetype(first_st, VERSION)
        url = input_config.get_attribute_value_for_sourcetype(first_st, SPLUNK_BASE_URL)
        template_version = input_config.get_attribute_value_for_sourcetype(first_st, TEMPLATE_VERSION)
        addon_display = (
            human or _addon_display_name_from_addon_name(addon_name or "") or HEADER_PLACEHOLDER_ADDON
        ).strip()
    else:
        addon_display = HEADER_PLACEHOLDER_ADDON
        version = HEADER_PLACEHOLDER_VERSION
        url = HEADER_PLACEHOLDER_URL
        template_version = HEADER_PLACEHOLDER_TEMPLATE_VERSION

    if not addon_display:
        addon_display = HEADER_PLACEHOLDER_ADDON
    if not version:
        version = HEADER_PLACEHOLDER_VERSION
    if not url:
        url = HEADER_PLACEHOLDER_URL
    if not template_version:
        template_version = DEFAULT_TEMPLATE_VERSION

    title = f"SPL2 template for {addon_display} noise reduction"
    sep = "=" * len(title)
    table_row = "|---------------------|------------------------------------------------------------|"
    lines = [
        title,
        sep,
        "",
        "Metadata:",
        table_row,
        f"| Template version    | {template_version}",
        f"| Add-on Name         | {addon_display}",
        f"| Compatible version  | {version}",
        f"| Splunkbase URL      | {url}",
        f"| Sourcetype          | {sourcetype_display}",
        table_row,
        "",
    ]
    if include_disclaimer:
        lines.append(DISCLAIMER_TEXT.strip())
        lines.append("")
    lines.extend(
        [
            "Overview:",
            "This SPL2 template is auto-generated using regular expressions from Splunk add-on configuration files (`props.conf`, `transforms.conf`).",
            "It enables the `noisereduce` function to filter out noise from log events, enhancing data quality for analysis.",
            "",
        ]
    )
    if overview_note:
        lines.append(overview_note)
        lines.append("")
    lines.extend(
        [
            "Purpose:",
            "Automates noise reduction for logs by leveraging Splunk Knowledge Objects, improving downstream analytics and alerting.",
            "",
            "Generated by:",
            "Automated SPL2 knowledge builder for Splunk Knowledge Object-based noise reduction.",
        ]
    )
    return "\n".join(lines)


def _prepend_header(content: str, header: str) -> str:
    """Prepend a block comment header to SPL2 content."""
    return "/*\n" + header + "\n*/\n\n" + content


def _build_spl2_content(kb_pairs: dict, sourcetypes: list, catchall_sourcetypes: list | None = None) -> str:
    """
    Build SPL2 content string for the given sourcetypes (and kb_pairs when non-empty).
    One KB block and one branch per sourcetype in sourcetypes. When catchall_sourcetypes
    is set (e.g. when sub_sourcetypes exist), the last-line negative condition uses
    catchall_sourcetypes so the main sourcetype is only in the catch-all, not in the branch list.
    """
    kb_template = get_knowledge_base_provider_spl2_template()
    has_pairs = bool(kb_pairs)
    if has_pairs:
        kb_pairs = dict(sorted(kb_pairs.items(), key=lambda item: item[0]))

    blocks = [get_import_noisereduce_spl2_template()]
    branch_by_key = {} if has_pairs else None
    branch_list = [] if not has_pairs else None
    # For catch-all "where not (...)" use catchall_sourcetypes when provided (main + subs), else sourcetypes
    catchall_for_regex = catchall_sourcetypes if catchall_sourcetypes is not None else sourcetypes
    srctype_regexes = [] if not has_pairs else None

    if has_pairs:
        for pair, kb in kb_pairs.items():
            fn_name = get_knowledge_base_provider_function_name_source_sourcetype(sourcetype=pair[0], source=pair[1])
            blocks.append(_kb_function_block(kb_template, fn_name, kb))
            src = pair[1].removeprefix("source::")
            branch_by_key[src] = _branch_line("source", _to_spl2_regex(src), fn_name, end_semicolon=False)

    for sourcetype in sourcetypes:
        kb = get_knowledge_base_for_sourcetype(sourcetype=sourcetype)
        fn_name = get_knowledge_base_provider_function_name(sourcetype=sourcetype)
        blocks.append(_kb_function_block(kb_template, fn_name, kb))
        regex = _to_spl2_regex(sourcetype)

        if has_pairs:
            key = get_spl2_safe_sourcetype_name(sourcetype)
            branch_by_key[key] = _branch_line("source", regex, fn_name, end_semicolon=False)
            pairs_for_st = _get_pairs_for_sourcetype(kb_pairs, sourcetype)
            if pairs_for_st:
                base_source, last_line = calculate_last_branch_case_for_multiple_sources(pairs_for_st, sourcetype)
                branch_by_key[base_source] = last_line
        else:
            branch_list.append(_branch_line("sourcetype", regex, fn_name, end_semicolon=False))

    if not has_pairs and catchall_for_regex:
        srctype_regexes = [_to_spl2_regex(st) for st in catchall_for_regex]

    single_sourcetype_no_pairs = not has_pairs and len(sourcetypes) == 1
    if has_pairs:
        pipeline = "\n".join(branch_by_key.values()) + "\n"
    elif single_sourcetype_no_pairs:
        fn_name = get_knowledge_base_provider_function_name(sourcetype=sourcetypes[0])
        pipeline = f"| eval _raw=noisereduce({fn_name}(), _raw)  | into $destination;\n"
    else:
        no_match = " or ".join(f"match(sourcetype, /{r}/)" for r in srctype_regexes)
        branch_list.append(f"[ where not ({no_match}) | into $destination]")
        parts = list(branch_list[:-1])
        last = branch_list[-1]
        last = last[:-1] + "];" if last.endswith("]") else last + ";"
        pipeline = "\n".join([*parts, last]) + "\n"
        pipeline = pipeline.replace("]],,", "],")
        pipeline = pipeline.replace("]],", "],")

    pipeline_intro = "| from $source \n " if single_sourcetype_no_pairs else "| from $source \n | branch \n"
    return "\n\n".join(blocks) + "\n\n$pipeline = " + pipeline_intro + pipeline


def _write_spl2_content(
    input_config: InputConfig,
    kb_pairs: dict,
    sourcetypes: list,
    catchall_sourcetypes: list | None = None,
    filename_sourcetypes: list | None = None,
):
    """
    Build and write SPL2 file(s). When no config was provided (used_auto_discovery),
    writes one combined template (all sourcetypes) and one per sourcetype:
    <output_dir>/<slug>/{slug}_noisereduce.spl2.
    Otherwise writes a single combined file to the legacy path.
    catchall_sourcetypes: when set, only these are listed in the last-line negative condition (main + subs).
    filename_sourcetypes: sourcetypes used for the output filename (e.g. parent only when sub_sourcetypes exist).
    """
    display_sourcetypes = catchall_sourcetypes if catchall_sourcetypes is not None else sourcetypes
    name_sourcetypes = filename_sourcetypes if filename_sourcetypes is not None else display_sourcetypes
    used_auto = getattr(input_config, "used_auto_discovery", False)
    if used_auto and sourcetypes:
        # One combined + one per sourcetype, converter-style layout
        content_combined = _build_spl2_content(kb_pairs, sourcetypes, catchall_sourcetypes)
        header_combined = _build_noisereduce_header(input_config, display_sourcetypes, include_disclaimer=True)
        content_combined = _prepend_header(content_combined, header_combined)
        combined_dir = os.path.join(SPL2_CONTENT_FOLDER, COMBINED_SLUG)
        os.makedirs(combined_dir, exist_ok=True)
        combined_path = os.path.join(combined_dir, NOISEREDUCE_FILE_NAME.format(slug=COMBINED_SLUG))
        with open(combined_path, "w") as f:
            f.write(content_combined)
        logger.info("FILEINFO: SPL2 combined template: %s", combined_path)

        for st in sourcetypes:
            slug = input_config.get_slug_for_sourcetype(st)
            st_pairs = _get_pairs_for_sourcetype(kb_pairs, st) if kb_pairs else {}
            content_single = _build_spl2_content(st_pairs, [st], None)
            header_single = _build_noisereduce_header(input_config, [st], include_disclaimer=True)
            content_single = _prepend_header(content_single, header_single)
            st_dir = os.path.join(SPL2_CONTENT_FOLDER, slug)
            os.makedirs(st_dir, exist_ok=True)
            st_path = os.path.join(st_dir, NOISEREDUCE_FILE_NAME.format(slug=slug))
            with open(st_path, "w") as f:
                f.write(content_single)
            logger.info("FILEINFO: SPL2 template for %s: %s", st, st_path)
    else:
        content = _build_spl2_content(kb_pairs, sourcetypes, catchall_sourcetypes)
        header = _build_noisereduce_header(input_config, display_sourcetypes, include_disclaimer=True)
        content = _prepend_header(content, header)
        out_path = get_combined_knowledge_base_provider_spl2_file(name_sourcetypes)
        out_dir = os.path.dirname(out_path)
        if out_dir:
            with contextlib.suppress(PermissionError, OSError):
                os.makedirs(out_dir, exist_ok=True)
        with open(out_path, "w") as f:
            f.write(content)
        logger.info("FILEINFO: SPL2 file for sourcetypes %s : %s", display_sourcetypes, out_path)


def calculate_last_branch_case_for_multiple_sources(kb_pairs, sourcetype=None):
    """
    Compute the final branch case for events whose source matches the base source
    but not any specific sub-source (e.g. source=WinEventLog but not WinEventLog:Security).

    Returns:
        tuple[str, str]: (base_source, branch_line).
    """
    sources = [v[1].replace("source::", "") for v in kb_pairs]
    if not sources:
        raise ValueError("Can't calculate base source from empty kb_pairs")
    try:
        base_source = sources[0].split(":")[0]
    except Exception as e:
        raise ValueError(f"Can't calculate base source from {sources!r}") from e
    if not base_source:
        raise ValueError(f"Empty base_source from {sources!r}")
    fn_name = (
        get_knowledge_base_provider_function_name(sourcetype=sourcetype)
        if sourcetype is not None
        else f"noise_reduction_knowledgebase_{get_spl2_safe_sourcetype_name(base_source)}"
    )
    # Escape base_source for SPL2 regex (e.g. source patterns with parentheses/backslashes)
    base_regex = _to_spl2_regex(base_source)
    base_regex_with_colon = _to_spl2_regex(base_source + ":")
    last_line = (
        f"[ where match(source, /{base_regex}/) and not match(source, /{base_regex_with_colon}/) | "
        f"eval _raw=noisereduce({fn_name}(), _raw)  | into $destination];\n"
    )
    return base_source, last_line


def create_spl2_content_for_source_sourcetype_pairs(kb_pairs):
    """Backward compatibility: generate combined SPL2 for source+sourcetype pairs."""
    create_spl2_content(None, kb_pairs)


if __name__ == "__main__":
    import sys

    from conf_spl2_converter.knowledge_builder.knowledge_base.nr_knowledge_base_creator import create_knowledge_base

    if len(sys.argv) < 2:
        print("Usage: python -m ... <ta_path> [config_file]", file=sys.stderr)
        sys.exit(1)
    ta_path = sys.argv[1]
    config_file = sys.argv[2] if len(sys.argv) > 2 else None
    input_config = InputConfig(ta_path, config_file)
    _, kb_pairs = create_knowledge_base(input_config)
    create_spl2_content(input_config, kb_pairs)
