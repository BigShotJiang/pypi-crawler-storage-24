# Knowledge Builder integration: KB creation and SPL2 content.
