import json
import logging
import os
from pathlib import Path


def load_config():
    """Load configuration from JSON file."""
    config_file = os.path.join(os.path.dirname(__file__), "config.json")
    try:
        with open(config_file) as f:
            return json.load(f)
    except FileNotFoundError:
        logging.error(f"Configuration file not found: {config_file}")
        raise
    except json.JSONDecodeError as e:
        logging.error(f"Error parsing configuration file: {e}")
        raise


# Load configuration
_config = load_config()

# Project base: repo root (conf-spl2-converter root). Path is input/ -> knowledge_builder -> conf_spl2_converter -> src -> repo.
_PROJECT_BASE_PATH = Path(__file__).resolve().parents[4]
PROJECT_BASE = str(_PROJECT_BASE_PATH)

# Package input dir: templates and input configs live inside the knowledge_builder package
_INPUT_DIR = Path(__file__).resolve().parent


def _resolve_path(key: str, value: str) -> str:
    """Paths under 'input/' use package input dir; others use PROJECT_BASE."""
    if value.startswith("input/"):
        return str(_INPUT_DIR / value.split("/", 1)[1])
    return os.path.join(PROJECT_BASE, value)


# Load all variables from config.json
TA_ALL_LOCATION = os.path.join(PROJECT_BASE, _config["TA_ALL_LOCATION"])
SECURITY_CONTENT_LOCATION = os.path.join(PROJECT_BASE, _config["SECURITY_CONTENT_LOCATION"])
ORIGINAL_SAMPLE_FILE_LOCATION = os.path.join(PROJECT_BASE, _config["ORIGINAL_SAMPLE_FILE_LOCATION"])
SPL2_CONTENT_FOLDER = os.path.join(PROJECT_BASE, _config["SPL2_CONTENT_FOLDER"])
TA_KNOWLEDGE_BASE_FOLDER = os.path.join(PROJECT_BASE, _config["TA_KNOWLEDGE_BASE_FOLDER"])
INPUT_CONFIG_FILE = _resolve_path("INPUT_CONFIG_FILE", _config["INPUT_CONFIG_FILE"])

KNOWLEDGE_BASE_PROVIDER_SPL2_TEMPLATE = _resolve_path(
    "KNOWLEDGE_BASE_PROVIDER_SPL2_TEMPLATE", _config["KNOWLEDGE_BASE_PROVIDER_SPL2_TEMPLATE"]
)
IMPORT_NOISEREDUCE_TEMPLATE = _resolve_path("IMPORT_NOISEREDUCE_TEMPLATE", _config["IMPORT_NOISEREDUCE_TEMPLATE"])
PIPELINE_SPL2_TEMPLATE = _resolve_path("PIPELINE_SPL2_TEMPLATE", _config["PIPELINE_SPL2_TEMPLATE"])
SPLUNK_CONF_FILE_COMBINED = os.path.join(PROJECT_BASE, _config["SPLUNK_CONF_FILE_COMBINED"])
TMP_SAMPLE_FILE_NAME = _config["TMP_SAMPLE_FILE_NAME"]
KNOWLEDGE_SOURCE = _config.get("KNOWLEDGE_SOURCE", "ta")  # Options: "ta" or "security_content"

# Optional CIM paths (in package input)
CIM_SOURCETYPE_MAPPING_FILE = _resolve_path(
    "CIM_MAPPING", _config.get("CIM_SOURCETYPE_MAPPING_FILE", "input/cim_sourcetype_mapping.json")
)
CIM_DATAMODEL_FIELDS_FILE = _resolve_path(
    "CIM_FIELDS", _config.get("CIM_DATAMODEL_FIELDS_FILE", "input/cim_datamodel_fields.json")
)
SEARCH_BY_DATAMODEL_IN_ESCU = _config.get("SEARCH_BY_DATAMODEL_IN_ESCU", False)
