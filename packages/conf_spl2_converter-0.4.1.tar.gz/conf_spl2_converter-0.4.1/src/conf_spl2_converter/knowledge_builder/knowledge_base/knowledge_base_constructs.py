class KnowledgeBaseAttribute:
    DEPENDENT_FIELDS = "dependent_fields"
    REGEXES = "regexes"
    KV_MODE = "kv_mode"
    AUTO_KV_JSON = "auto_kv_json"
