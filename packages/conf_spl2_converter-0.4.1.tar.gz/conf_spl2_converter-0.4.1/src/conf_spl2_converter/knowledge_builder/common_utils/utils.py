import json
import os
import time

from conf_spl2_converter.knowledge_builder.common_utils.input_config_file_processor import InputConfig
from conf_spl2_converter.knowledge_builder.common_utils.log_utils import logger
from conf_spl2_converter.knowledge_builder.common_utils.spl2_utils import get_spl2_safe_sourcetype_name
from conf_spl2_converter.knowledge_builder.input.configuration_constants import TA_KNOWLEDGE_BASE_FOLDER


def get_unique_id():
    return str(int(time.time()))


# just for tests : don't use it for huge files
def get_data_from_file(file) -> str:
    with open(file) as f:
        return f.read()


def write_stringdata_to_file(string_data, file_location):
    with open(file_location, "w") as file:
        file.write(string_data)


def delete_file(file_path):
    try:
        os.remove(file_path)
    except FileNotFoundError:
        logger.info("File '%s' not found.", file_path)


def get_knowledge_base(input_config: InputConfig):
    sourcetypes = input_config.get_input_sourcetypes()
    consolidated_kb = {}
    for sourcetype in sourcetypes:
        logger.info(
            "Reading Knowledge Base for sourcetype "
            + sourcetype
            + " from file "
            + get_knowledge_base_file_for_sourcetype(sourcetype=sourcetype)
        )
        consolidated_kb[sourcetype] = get_knowledge_base_for_sourcetype(sourcetype=sourcetype)
    return consolidated_kb


def get_knowledge_base_file_for_sourcetype(sourcetype):
    sourcetype = get_spl2_safe_sourcetype_name(sourcetype)
    return os.path.join(TA_KNOWLEDGE_BASE_FOLDER, sourcetype + ".json")


def get_knowledge_base_for_sourcetype(sourcetype):
    filename = get_knowledge_base_file_for_sourcetype(sourcetype)
    kb_str = get_data_from_file(filename)
    # Validate kb_str
    if not kb_str:
        raise ValueError(f"Knowledge base string for sourcetype '{sourcetype}' is empty or None.")

    # Parse the JSON string
    try:
        kb_json = json.loads(kb_str)
    except json.JSONDecodeError as e:
        raise ValueError(f"Failed to decode knowledge base JSON for sourcetype '{sourcetype}': {e}") from e

    return kb_json


def get_file_name_from_path(path):
    return os.path.basename(path)


def sort_knowledge_base(knowledge_base: dict):
    for k, v in knowledge_base.items():
        if isinstance(v, list):
            knowledge_base[k] = sorted(v)
