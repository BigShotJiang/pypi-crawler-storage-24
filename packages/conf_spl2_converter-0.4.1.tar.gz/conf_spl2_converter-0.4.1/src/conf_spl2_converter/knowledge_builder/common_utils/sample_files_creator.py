import json
import os

import xmltodict

from conf_spl2_converter.knowledge_builder.common_utils.log_utils import logger
from conf_spl2_converter.knowledge_builder.input.configuration_constants import (
    ORIGINAL_SAMPLE_FILE_LOCATION,
)

SAMPLE_FILE_EXTENSION = ".sample"


def parse_to_dict(all_samples_xml_filename):
    with open(os.path.join(ORIGINAL_SAMPLE_FILE_LOCATION, all_samples_xml_filename)) as f:
        xml_content = f.read()
    return xmltodict.parse(xml_content)


def get_sample_filename(sample_file_name_prefix, unique_id):
    return sample_file_name_prefix + str(unique_id) + SAMPLE_FILE_EXTENSION


def create_sample_file(all_samples_xml_filename, sample_file_name_prefix):
    xml_dict = parse_to_dict(all_samples_xml_filename)
    events = xml_dict["device"]["event"]
    unique_id = 1
    sample_file_names = []
    if isinstance(events, list):
        for event in events:
            unique_id = unique_id + 1

            sample_file_name = get_sample_filename(sample_file_name_prefix, unique_id)
            with open(os.path.join(ORIGINAL_SAMPLE_FILE_LOCATION, sample_file_name), "w") as sample_file:
                sample_file.write(event["raw"])
                sample_file_names.append(sample_file_name)
    else:
        unique_id = unique_id + 1
        sample_file_name = get_sample_filename(sample_file_name_prefix, unique_id)
        with open(os.path.join(ORIGINAL_SAMPLE_FILE_LOCATION, sample_file_name), "w") as sample_file:
            sample_file.write(events["raw"])
            sample_file_names.append(sample_file_name)

    logger.info(json.dumps(sample_file_names))


if __name__ == "__main__":
    # create_sample_file(all_samples_xml_filename="aws_cloudfront_accesslogs.xml", sample_file_name_prefix="aws_cloudfront_accesslogs")
    # create_sample_file(all_samples_xml_filename="aws_elb_accesslogs.xml",sample_file_name_prefix="aws_elb_accesslogs")
    create_sample_file(all_samples_xml_filename="aws_s3_accesslogs.xml", sample_file_name_prefix="aws_s3_accesslogs")
