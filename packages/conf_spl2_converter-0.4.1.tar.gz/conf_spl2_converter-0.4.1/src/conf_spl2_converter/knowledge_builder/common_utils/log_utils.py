import logging
import os
from pathlib import Path

MAIN_STAGE_FORMAT = "\n" + "-" * 30 + " {msg}  " + "-" * 30

# Ensure the logs/ directory exists
BASE_DIR = Path(__file__).resolve().parents[1]  # Get the project root directory
LOGS_DIR = BASE_DIR / "../logs"
try:
    os.makedirs(LOGS_DIR, exist_ok=True)
except OSError as e:
    raise RuntimeError(f"Failed to create logs directory: {e}") from e

# Define the log file path
LOG_FILE_PATH = os.path.join(LOGS_DIR, "knowledge_builder.log")

# Configure the logger
logger = logging.getLogger("splunk-ko-based-noise-removal_logger")
logger.setLevel(logging.INFO)

# File handler for logging to a file
file_handler = logging.FileHandler(LOG_FILE_PATH)
file_handler.setLevel(logging.INFO)

# Console handler for logging to the console
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)

# Formatter for log messages
formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
file_handler.setFormatter(formatter)
console_handler.setFormatter(formatter)

# Add handlers to the logger
logger.addHandler(file_handler)
logger.addHandler(console_handler)
