import os

from conf_spl2_converter.knowledge_builder.input.configuration_constants import TA_ALL_LOCATION


def get_pt_conf_files(all_ta_names):
    conf_files = []
    for ta_name in all_ta_names:
        props_conf_file = os.path.join(TA_ALL_LOCATION, ta_name, "package", "default", "props.conf")
        transforms_conf_file = os.path.join(TA_ALL_LOCATION, ta_name, "package", "default", "transforms.conf")
        conf_files.append(props_conf_file)
        conf_files.append(transforms_conf_file)
    return conf_files
