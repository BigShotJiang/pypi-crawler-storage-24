from conf_spl2_converter.knowledge_builder.common_utils.log_utils import logger
from conf_spl2_converter.knowledge_builder.common_utils.splunk_utils.var_extractor_utils import (
    clean_double_quote_strings,
    clean_single_quote_strings,
    clean_single_tick_strings,
    extract_single_quote_variables,
    is_int,
    remove_booleans,
    remove_newline,
    remove_unwanted_variables,
)

# BUGS
# | rename properties.* as *
TERMINATORS = ["(", ")", "=", ",", "!", "\\\n", "+", "-", "*", "|", " ", ">", "<", "[", "]"]
FUNCTION_STARTERS = ["("]
COMMA_TERMINATOR = ","


def straight_variables(code) -> list:
    variables = set()
    current_var = ""
    index = -1
    for character in code:
        index = index + 1
        if character in TERMINATORS:
            # analyse whether it is a variable or a function
            if character in FUNCTION_STARTERS:
                # it is a function
                # reset the current_var
                current_var = ""
            else:
                if not is_int(current_var):
                    if current_var == "datamodel":
                        logger.info("")
                    variables.add(current_var)
                # reset the current_var
                current_var = ""
        else:
            current_var = current_var + character
    else:
        if current_var and not is_int(current_var):
            variables.add(current_var)
    return list(set(variables))


def replace_key_words_with_terminator(code):
    and_not_clause = " AND NOT "
    or_clause = " OR "
    in_clause = " IN "
    as_clause = " AS "
    and_clause = " AND "
    not_clause = " NOT "
    by_clause = " BY "
    output_clause = " OUTPUT "
    from_clause = " FROM "
    clauses = [
        and_not_clause,
        or_clause,
        in_clause,
        as_clause,
        and_clause,
        not_clause,
        output_clause,
        from_clause,
        by_clause,
    ]
    for clause in clauses:
        code = code.replace(clause, COMMA_TERMINATOR)
        code = code.replace(clause.lower(), COMMA_TERMINATOR)

    return code


def extract_variables_from_spl_code(code):
    variables = []

    # CLEANUP
    code = replace_key_words_with_terminator(code)
    code = remove_booleans(code)
    code = clean_single_tick_strings(code)
    code = remove_newline(code)
    # code = remove_space(code) this will deform SPLs
    code = clean_double_quote_strings(code)

    # EXTRACT
    single_quote_variables = extract_single_quote_variables(
        code
    )  # saw some cases where it has spaces ExtendedProperties.Attacker IP Address
    code = clean_single_quote_strings(code)
    non_quote_variables = straight_variables(code)
    variables.extend(single_quote_variables)
    variables.extend(non_quote_variables)

    # CLEAN
    variables = remove_unwanted_variables(variables)
    return variables


def main():
    test_cases = []
    with open("sample_spls.txt") as spl_file:
        spls = spl_file.readlines()
        for spl in spls:
            if spl.strip() != "":
                logger.info("#" * 20)
                logger.info(spl)
                variables = extract_variables_from_spl_code(spl)
                logger.info(variables)
                test_case = {"input_code": "", "expected_output": ""}
                test_case["input_code"] = spl
                test_cases.append(test_case)
    # with open('spl_variable_extractor_testcases2.json', 'w') as spl_variable_extractor_testcases_file:
    #     spl_variable_extractor_testcases_file.write(json.dumps(test_cases, indent=2))
    logger.info("Collected %d test cases", len(test_cases))


if __name__ == "__main__":
    main()
