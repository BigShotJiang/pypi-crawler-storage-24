import json

from conf_spl2_converter.knowledge_builder.common_utils.log_utils import logger
from conf_spl2_converter.knowledge_builder.common_utils.splunk_utils.var_extractor_utils import (
    clean_double_quote_strings,
    clean_single_quote_strings,
    extract_single_quote_variables,
    is_int,
    remove_newline,
    remove_space,
    remove_unwanted_variables,
)

TERMINATORS = ["(", ")", "=", ",", "!", "\\\n", "+", "-", "*"]
FUNCTION_STARTERS = ["("]
COMMA_TERMINATOR = ","


def straight_variables(code) -> list:
    variables = set()
    current_var = ""
    index = -1
    for character in code:
        index = index + 1
        if character in TERMINATORS:
            # analyse whether it is a variable or a function
            if character in FUNCTION_STARTERS:
                # it is a function
                # reset the current_var
                current_var = ""
            else:
                if not is_int(current_var):
                    variables.add(current_var)
                # reset the current_var
                current_var = ""
        else:
            current_var = current_var + character
    else:
        if current_var and not is_int(current_var):
            variables.add(current_var)
    return list(set(variables))


def replace_key_words_with_terminator(code):
    and_not_clause = " AND NOT "
    or_clause = " OR "
    in_clause = " IN "
    as_clause = " AS "
    and_clause = " AND "
    not_clause = " NOT "
    clauses = [and_not_clause, or_clause, in_clause, as_clause, and_clause, not_clause]
    for clause in clauses:
        code = code.replace(clause, COMMA_TERMINATOR)
        code = code.replace(clause.lower(), COMMA_TERMINATOR)

    return code


def extract_variables_from_eval_code(code):
    variables = []
    single_quote_variables = extract_single_quote_variables(
        code
    )  # saw some cases where it has spaces ExtendedProperties.Attacker IP Address

    # CLEANUP
    code = replace_key_words_with_terminator(code)
    code = remove_newline(code)
    code = remove_space(code)
    code = clean_double_quote_strings(code)

    # EXTRACT
    code = clean_single_quote_strings(code)
    non_quote_variables = straight_variables(code)
    variables.extend(single_quote_variables)
    variables.extend(non_quote_variables)

    # CLEAN
    variables = remove_unwanted_variables(variables)
    return variables


def main():
    with open("./interested_content.json") as unprocessed_data_ptr:
        unprocessed_data_list = json.loads(unprocessed_data_ptr.read())
        index = -1
        for unprocessed_data in unprocessed_data_list:
            logger.info("##################")
            index = index + 1

            code = unprocessed_data["input"]
            logger.info(code)
            variables = extract_variables_from_eval_code(code)
            logger.info(variables)


if __name__ == "__main__":
    main()
