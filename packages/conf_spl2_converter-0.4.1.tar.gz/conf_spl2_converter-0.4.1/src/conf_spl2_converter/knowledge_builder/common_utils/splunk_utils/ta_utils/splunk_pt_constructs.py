class PropsConfAttribute:
    FIELDALIAS = "FIELDALIAS"
    KV_MODE = "kv_mode"
    REPORT = "REPORT"
    EXTRACT = "EXTRACT"
    EVAL = "EVAL"
    TRANSFORMS = "TRANSFORMS"
    LOOKUP = "LOOKUP"


class TransformsConfAttribute:
    REGEX = "REGEX"
    SOURCE_KEY = "SOURCE_KEY"


class KvModes:
    AUTO = "auto"
    JSON = "json"
    XML = "xml"
    NONE = "none"
    AUTO_ESCAPED = "auto_escaped"
    MULTI = "multi"


# Backward-compatible alias (class named KvModes for CapWords)
KV_MODES = KvModes


class Booleans:
    TRUE = "true"
    FALSE = "false"


class TimeAttribute:
    TIME_PREFIX = "TIME_PREFIX"
    TIME_FORMAT = "TIME_FORMAT"
    TIME_ZONE = "TZ"
    MAX_TIMESTAMP_LOOKAHEAD = "MAX_TIMESTAMP_LOOKAHEAD"
