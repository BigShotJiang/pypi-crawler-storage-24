from conf_spl2_converter.knowledge_builder.common_utils.log_utils import logger
from conf_spl2_converter.knowledge_builder.common_utils.splunk_utils.spl_utils.spl_variable_extractor import (
    extract_variables_from_spl_code,
)


def find_dependent_fields_from_spl_code_using_static_analysis(spl_code):
    variables = extract_variables_from_spl_code(spl_code)
    return ",".join(variables)


if __name__ == "__main__":
    spl_code = '| tstats `security_content_summariesonly` count min(_time) as firstTime max(_time) as lastTime values(DNS.answer) as answer from datamodel=Network_Resolution by DNS.src DNS.query | `drop_dm_object_name("DNS")` | `security_content_ctime(firstTime)` | `security_content_ctime(lastTime)` | lookup remote_access_software remote_domain AS query OUTPUT isutility, description as signature, comment_reference as desc, category | eval dest = query | search isutility = True | `remote_access_software_usage_exceptions` | `detect_remote_access_software_usage_dns_filter`'
    response = find_dependent_fields_from_spl_code_using_static_analysis(spl_code=spl_code)
    logger.info(response)
