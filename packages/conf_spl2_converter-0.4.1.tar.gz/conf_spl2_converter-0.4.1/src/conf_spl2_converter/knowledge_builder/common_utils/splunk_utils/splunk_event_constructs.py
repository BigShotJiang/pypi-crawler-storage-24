class SplunkEventFields:
    _raw = "_raw"
