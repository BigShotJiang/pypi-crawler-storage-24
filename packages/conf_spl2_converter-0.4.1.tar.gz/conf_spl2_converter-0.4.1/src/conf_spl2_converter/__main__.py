# Conf To Spl2 Converter
# Copyright (C) 2026 Splunk Inc. All Rights Reserved.
#
# Installation and use subject to the Splunk General Terms,
# see https://www.splunk.com/en_us/legal/splunk-general-terms.html


"""Entry point for the CLI application."""

from conf_spl2_converter.cli import app

if __name__ == "__main__":
    app()
