# Split configs (one per sourcetype)

Generated from `x/input.json`, one config file per sourcetype. Matching: **sourcetype → config file**.

| Sourcetype | Config file | TA path (from addon_name) |
|------------|-------------|---------------------------|
| aws:cloudtrail | aws_cloudtrail.json | x/ta_storage/splunk-add-on-for-amazon-web-services |
| aws:cloudwatchlogs:vpcflow | aws_cloudwatchlogs_vpcflow.json | x/ta_storage/splunk-add-on-for-amazon-web-services |
| pan:firewall | pan_firewall.json | x/ta_storage/splunk-add-on-for-palo-alto-networks |
| pan:firewall:cloud | pan_firewall_cloud.json | x/ta_storage/splunk-add-on-for-palo-alto-networks |
| crowdstrike:events:sensor | crowdstrike_events_sensor.json | x/ta_storage/splunk-add-on-for-crowdstrike-fdr |
| WinEventLog | wineventlog.json | x/ta_storage/splunk-add-on-for-microsoft-windows |
| XmlWinEventLog | xmlwineventlog.json | x/ta_storage/splunk-add-on-for-microsoft-windows |
| mscs:azure:eventhub | mscs_azure_eventhub.json | x/ta_storage/splunk-add-on-for-microsoft-cloud-services |
| cisco:asa | cisco_asa.json | x/ta_storage/splunk-add-on-for-cisco-asa |
| google:gcp:pubsub:message | google_gcp_pubsub_message.json | x/ta_storage/splunk-add-on-for-google-cloud-platform |

The script `../run_generate_and_kb.sh` reads `addon_name` from each config to resolve the TA path. Run from repo root: `./x/run_generate_and_kb.sh` (requires `jq`).
