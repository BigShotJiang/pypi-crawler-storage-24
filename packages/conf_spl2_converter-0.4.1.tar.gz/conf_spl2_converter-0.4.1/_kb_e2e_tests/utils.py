import glob
import json
import os
import subprocess
import time
from itertools import chain, product

import requests
import splunklib.client as client
import splunklib.results as results
from requests.auth import HTTPBasicAuth

from conf_spl2_converter.knowledge_builder.common_utils.log_utils import logger
from conf_spl2_converter.knowledge_builder.common_utils.spl2_utils import get_combined_knowledge_base_provider_spl2_file


class Scenario:
    def __init__(self, config, samples, test_config):
        self.config = (config,)
        self.test_config = (test_config,)
        self.samples = samples
        self._convert_to_params()

    def _convert_to_params(self):
        self.params = list(product(self.config, self.samples, self.test_config))

    def __iter__(self):
        return iter(self.params)

    @staticmethod
    def scenario_id(x):
        if isinstance(x, dict):
            return str(list(x.keys()))
        elif isinstance(x, str):
            return x
        else:
            return str(x)


def _default_scenarios_dir():
    """Scenarios next to this utils module (_kb_e2e_tests/scenarios)."""
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "scenarios")


class Suite:
    def __init__(self, test_scenarios_dir=None):
        if test_scenarios_dir is None:
            test_scenarios_dir = _default_scenarios_dir()
        self._test_scenarios_dir = test_scenarios_dir
        self.scenarios = []
        self._tests = []

        self._load_scenarios()
        self._create_tests_list()

    def _load_scenarios(self):
        for files in glob.glob(f"{self._test_scenarios_dir}/test_*.json"):
            with open(files) as file:
                scenario_data = json.load(file)
                self.scenarios.append(
                    Scenario(scenario_data["input_config"], scenario_data["samples"], scenario_data["test_config"])
                )

    def _create_tests_list(self):
        for test in chain(*self.scenarios):
            self._tests.append(test)

    @property
    def tests(self):
        return self._tests


def push_to_hec(config, log_data, sourcetype, host, source=None):
    headers = {"Authorization": "Splunk " + config["authentication"]["hec_token"]}
    # Encode body as UTF-8 so non-Latin-1 characters (e.g. €) are sent correctly
    body = log_data.encode("utf-8") if isinstance(log_data, str) else log_data
    if isinstance(log_data, str):
        headers["Content-Type"] = "text/plain; charset=utf-8"
    if source is not None:
        response = requests.post(
            url=config["hec_raw_url"],
            data=body,
            params={"sourcetype": sourcetype, "index": config["index"], "host": host, "source": source},
            headers=headers,
            verify=False,
        )
    else:
        response = requests.post(
            url=config["hec_raw_url"],
            data=body,
            params={"sourcetype": sourcetype, "index": config["index"], "host": host},
            headers=headers,
            verify=False,
        )
    response.raise_for_status()


def get_events_by_host_and_index(config, host):
    spl_template = "| search index={index} host={host} | fields *"
    # Connect to Splunk
    service = client.connect(
        host=config["ip"],
        port=config["api_port"],
        username=config["authentication"]["username"],
        password=config["authentication"]["password"],
        app="search",
    )
    spl = spl_template.format(index=config["index"], host=host)

    results_all = []
    retry = 0
    while not results_all and retry < 20:
        kwargs = {"adhoc_search_level": "verbose"}
        job = service.jobs.create(spl, **kwargs)
        while not job.is_done():
            time.sleep(0.25)
        results_splunk = job.results(output_mode="json")
        rr = results.JSONResultsReader(results_splunk)
        for result in rr:
            if isinstance(result, results.Message):
                logger.info("%s: %s", result.type, result.message)
            elif isinstance(result, dict):
                # Normal events are returned as dicts
                results_all.append(result)
        retry = retry + 1
    return results_all


def calculate_reduction_rate(original_event, reduced_event, correct_timestamp=True):
    reduced_event_len = len(reduced_event)
    original_event_len = len(original_event)

    reduction_rate = (original_event_len - reduced_event_len) / original_event_len
    return reduction_rate


def create_index(config):
    response = requests.post(
        url=config["index_url"],
        data={"name": config["index"], "output_mode": "json"},
        auth=HTTPBasicAuth(config["authentication"]["username"], config["authentication"]["password"]),
        verify=False,
    )
    return response.json()


def get_generated_template_path(knowledge_base_object, sourcetype=None):
    """
    Return the path to the generated SPL2 template (single combined file for all sourcetypes).
    sourcetype is unused; the same template path is used for all events in the scenario.
    """
    if not isinstance(knowledge_base_object, dict) or not knowledge_base_object:
        raise ValueError("knowledge_base_object must be a non-empty dict to resolve template path")
    first_key = next(iter(knowledge_base_object.keys()))
    is_kb_pairs = isinstance(first_key, tuple)
    if is_kb_pairs:
        sourcetypes = sorted({k[0] for k in knowledge_base_object})
    else:
        # Only sourcetype keys (exclude source:: stanzas) so path matches creator output
        sourcetypes = sorted(k for k in knowledge_base_object if not (isinstance(k, str) and k.startswith("source::")))
    if not sourcetypes:
        raise ValueError("could not derive any sourcetypes from knowledge_base_object")
    path = get_combined_knowledge_base_provider_spl2_file(sourcetypes)
    return os.path.abspath(path)


def get_output_from_template(template_path, event, source, sourcetype):
    with open(template_path) as f:
        template = f.read()

        ex = json.dumps([{"_raw": event, "source": source, "sourcetype": sourcetype}])
        template += f"\n$source = from {ex!s};"
        command = ["spl2-processor-cli", "test", "-s", "pipeline"]
        result = subprocess.run(
            command,
            input=template,  # Pass data to stdin
            text=True,  # Encode input_data as string
            capture_output=True,
        )
        output = json.loads(result.stdout)["destination"][0]["_raw"]

        return output


if __name__ == "__main__":
    import os

    os.chdir("../tests")

    ts = Scenario({"1": {"2": "3"}}, ["4", "5", "6"], {"f1": ["f2", "f3"]})
    assert ts.params == [
        ({"1": {"2": "3"}}, "4", {"f1": ["f2", "f3"]}),
        ({"1": {"2": "3"}}, "5", {"f1": ["f2", "f3"]}),
        ({"1": {"2": "3"}}, "6", {"f1": ["f2", "f3"]}),
    ]

    test_suite = Suite()
    logger.info(test_suite.scenarios)
    logger.info(test_suite.tests)
