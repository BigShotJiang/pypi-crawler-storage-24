import os
import uuid
from collections import defaultdict
from pprint import pformat
from time import sleep

import pandas as pd
import pytest

from _kb_e2e_tests.utils import (
    Scenario,
    Suite,
    calculate_reduction_rate,
    get_events_by_host_and_index,
    get_output_from_template,
    push_to_hec,
)
from conf_spl2_converter.knowledge_builder.common_utils.log_utils import logger


@pytest.fixture(scope="session")
def stats():
    s = defaultdict(lambda: defaultdict(list))
    yield s

    for sourcetype, v in s.items():
        x = pd.DataFrame(v)
        logger.info(" *** *** ***")
        logger.info(sourcetype)
        logger.info(x.describe())


@pytest.mark.parametrize(
    "input_config, event, test_config",
    Suite().tests,
    ids=Scenario.scenario_id,
    indirect=["input_config"],
    scope="session",
)
def test_e2e(input_config, event, test_config, request, stats, general_config, generated_template_path):
    source = event[1].get("source", "")
    sourcetype = event[1].get("sourcetype", None)
    if sourcetype is None and getattr(input_config, "input_to_process", None):
        sourcetype = next(iter(input_config.input_to_process.keys()))

    event = event[0]

    template_path = test_config.get("use_template") or generated_template_path
    if template_path and not os.path.isabs(template_path):
        template_path = os.path.abspath(template_path)
    if not template_path or not os.path.isfile(template_path):
        template_path = generated_template_path
    output = get_output_from_template(template_path, event, source, sourcetype)

    r = uuid.uuid4()
    host_1 = f"test_{r}_event_origin"
    host_2 = f"test_{r}_event_reduced"
    push_to_hec(general_config, event, sourcetype, host_1, source)
    push_to_hec(general_config, output, sourcetype, host_2, source)

    parsed_original = get_events_by_host_and_index(general_config, host_1)
    if parsed_original:
        parsed_original = parsed_original[0]
    else:
        sleep(0.1)
        parsed_original = get_events_by_host_and_index(general_config, host_1)[0]

    parsed_reduced = get_events_by_host_and_index(general_config, host_2)
    if parsed_reduced:
        parsed_reduced = parsed_reduced[0]
    else:
        sleep(0.1)
        parsed_reduced = get_events_by_host_and_index(general_config, host_2)[0]

    for field in test_config.get("fields_not_to_compare", []):
        parsed_original.pop(field, None)
        parsed_reduced.pop(field, None)

    for k, v in parsed_original.items():
        parsed_original[k] = str(v).removesuffix("_event_origin")

    for k, v in parsed_reduced.items():
        parsed_reduced[k] = str(v).removesuffix("_event_reduced")

    reduction_rate = calculate_reduction_rate(event, output, correct_timestamp=True)
    stats[sourcetype]["reduction_rate"].append(reduction_rate)

    logger.info(f"Reduction_rate: {reduction_rate:.2%}")

    logger.info("Original event: \n %s", event)
    logger.info("Reduced event: \n %s", output)

    assert parsed_reduced == parsed_original

    logger.info("Extractions:\n %s ", pformat(parsed_original))
