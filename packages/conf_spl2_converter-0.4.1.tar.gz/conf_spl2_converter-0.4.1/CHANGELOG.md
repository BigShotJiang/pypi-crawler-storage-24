# CHANGELOG


## v0.4.1 (2026-03-20)

### Bug Fixes

- Integrate more escu related changes
  ([`52c6483`](https://cd.splunkdev.com/taautomation/conf-spl2-converter/-/commit/52c6483b2fa670a546850444be8163a50c69381e))


## v0.4.0 (2026-03-17)

### Features

- Knowledge builder cleanup and bug fixes
  ([`87a6cfa`](https://cd.splunkdev.com/taautomation/conf-spl2-converter/-/commit/87a6cfa70335817b5fe059aa4bec510384f6a3d9))


## v0.3.0 (2026-03-16)

### Features

- Add field extraction test generation
  ([`a8193e6`](https://cd.splunkdev.com/taautomation/conf-spl2-converter/-/commit/a8193e600a833e53cc461a46546112f2d67b4939))


## v0.2.0 (2026-03-03)

### Bug Fixes

- Fix commit depth to help semantic release to do release
  ([`34209a6`](https://cd.splunkdev.com/taautomation/conf-spl2-converter/-/commit/34209a6dfb7e96337bbeacec3b5c652fea01e422))

- Fix release
  ([`404f4b1`](https://cd.splunkdev.com/taautomation/conf-spl2-converter/-/commit/404f4b1886bd1a200074874f4b9cafe4208901d5))

- Improve public packaging and fix tag
  ([`7a528d8`](https://cd.splunkdev.com/taautomation/conf-spl2-converter/-/commit/7a528d800b45338de194bbc2de8b9fa2eb71bbe3))

### Chores

- Improve default paths to work better in TA
  ([`8bd3d22`](https://cd.splunkdev.com/taautomation/conf-spl2-converter/-/commit/8bd3d22f2e3ffdac4466553b4fcf8abeb70150de))

- **deps**: Update dependency ruff to v0.15.2
  ([`af2c414`](https://cd.splunkdev.com/taautomation/conf-spl2-converter/-/commit/af2c414090190b19d57cf465223fa327e94fd14f))

- **deps**: Update python docker tag to v3.14
  ([`ca2bd2f`](https://cd.splunkdev.com/taautomation/conf-spl2-converter/-/commit/ca2bd2fa1404aa8d01c0d4826f36c17041180eec))

### Features

- Publish to pypi org
  ([`ab17527`](https://cd.splunkdev.com/taautomation/conf-spl2-converter/-/commit/ab175275fd89141a4ae2101a2b0af106db7f4885))


## v0.1.8 (2026-02-20)

### Chores

- Add renovate to code owners
  ([`01cb232`](https://cd.splunkdev.com/taautomation/conf-spl2-converter/-/commit/01cb232cb8d95bfae8fc895fe5517d1fc0c5bcb7))


## v0.1.7 (2026-02-20)


## v0.1.6 (2026-02-18)

### Bug Fixes

- Deployment fix + few workarounds for TAs
  ([`7274a15`](https://cd.splunkdev.com/taautomation/conf-spl2-converter/-/commit/7274a15c60279a9d74a4e7fc0d11aef675faf929))


## v0.1.0 (2026-02-13)

### Features

- Addon-85381 fix README.md
  ([`5f4dc2c`](https://cd.splunkdev.com/taautomation/conf-spl2-converter/-/commit/5f4dc2c9785cfa0222a011a9e603e9cf10c2eaf5))

- Addon-85381 Put P&T to SPL2 converter (FIELD EXTRACTION) as the CLI tool - initial commit
  ([`c7df1d3`](https://cd.splunkdev.com/taautomation/conf-spl2-converter/-/commit/c7df1d315f4805d8d2cb9c9204241e73bb7736e6))
