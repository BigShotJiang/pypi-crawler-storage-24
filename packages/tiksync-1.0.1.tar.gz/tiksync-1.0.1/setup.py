from setuptools import setup, find_packages

setup(
    name="tiksync",
    version="1.0.1",
    description="TikSync — TikTok Live SDK for Python. Real-time chat, gifts, likes & viewer events.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="SyncLive",
    author_email="contact@synclive.fr",
    url="https://tiksync.com",
    project_urls={
        "Documentation": "https://tiksync.com/docs",
        "Source": "https://github.com/tiksync/tiksync-python",
    },
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=["aiohttp>=3.8"],
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries",
    ],
    keywords=["tiktok", "tiktok-live", "websocket", "api", "sdk", "gifts", "chat"],
    license="MIT",
)
