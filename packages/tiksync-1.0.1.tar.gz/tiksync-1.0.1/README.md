# TikSync Python SDK

**TikTok Live SDK for Python** - Real-time chat, gifts, likes, follows & viewer events.

[![PyPI](https://img.shields.io/pypi/v/tiksync.svg)](https://pypi.org/project/tiksync/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

```python
from tiksync import TikSync

client = TikSync("username", api_key="your_api_key")

@client.on("chat")
async def on_chat(data):
    print(f"[{data['uniqueId']}] {data['comment']}")

@client.on("gift")
async def on_gift(data):
    print(f"{data['uniqueId']} sent {data['giftName']} x{data['repeatCount']}")

await client.connect()
```

## Installation

```bash
pip install tiksync
```

## Quick Start

```python
import asyncio
from tiksync import TikSync

async def main():
    client = TikSync("charlidamelio", api_key="your_api_key")

    client.on("chat", lambda data: print(f"[{data['uniqueId']}] {data['comment']}"))
    client.on("gift", lambda data: print(f"{data['uniqueId']} sent {data['giftName']}"))
    client.on("like", lambda data: print(f"{data['uniqueId']} liked ({data['totalLikeCount']} total)"))
    client.on("follow", lambda data: print(f"{data['uniqueId']} followed"))
    client.on("member", lambda data: print(f"{data['uniqueId']} joined"))

    await client.connect()

asyncio.run(main())
```

## REST API

```python
from tiksync import TikSyncAPI

api = TikSyncAPI(api_key="your_api_key")
health = await api.health()
usage = await api.usage()
signed = await api.sign("username")
```

## Events

| Event | Description |
|-------|-------------|
| `chat` | Chat messages |
| `gift` | Gift events with diamond values |
| `like` | Like events |
| `follow` | New followers |
| `share` | Stream shares |
| `member` | User joins |
| `roomUser` | Viewer count updates |
| `subscribe` | Subscriptions |
| `streamEnd` | Stream ended |
| `connected` | Connected to stream |
| `disconnected` | Disconnected |
| `error` | Connection error |

## Pricing

| Plan | Price | Requests/day | WebSocket connections | CAPTCHA cost |
|------|-------|-------------|----------------------|-------------|
| **Free** | $0 | 1,000 | 10 | $0 |
| **Pro** | $39/mo | 15,000 | 50 | $0 |
| **Business** | $99/mo | 250,000 | 1,500 | $0 |

Get your API key at [tiksync.com](https://tiksync.com)

## License

MIT - built by [SyncLive](https://synclive.fr) | [tiksync.com](https://tiksync.com)
