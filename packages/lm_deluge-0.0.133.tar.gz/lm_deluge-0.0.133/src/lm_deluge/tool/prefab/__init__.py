"""
Prefab tools for lm-deluge.

This module uses lazy imports to avoid requiring all dependencies at once.
Import specific tools directly:
    from lm_deluge.tool.prefab.sandbox import ModalSandbox
    from lm_deluge.tool.prefab.full_text_search import FullTextSearchManager
"""

import sys
from typing import TYPE_CHECKING

# For type checkers, import everything so autocompletion works
if TYPE_CHECKING:
    from .batch_tool import BatchTool
    from .curl import get_curl_tool
    from .docs import DocsManager
    from .email import EmailManager
    from .filesystem import (
        FilesystemManager,
        FilesystemParams,
        InMemoryWorkspaceBackend,
        WorkspaceBackend,
    )
    from .full_text_search import FullTextSearchManager
    from .hue import PhilipsHueManager
    from .otc import ToolComposer
    from .random import RandomTools
    from .rlm import RLMManager, RLMPipeline, RLMResult
    from .sandbox import (
        DaytonaSandbox,
        DockerSandbox,
        FargateSandbox,
        JustBashSandbox,
        ModalSandbox,
        PybubbleSandbox,  # noqa: F401
    )
    from .sheets import SheetsManager
    from .sqlite import SqliteManager, SqliteParams
    from .subagents import SubAgentManager
    from .todos import TodoItem, TodoManager, TodoPriority, TodoStatus
    from .tool_search import ToolSearchTool
    from .vector_db import InProcessVectorDB, VectorDBBackend, VectorDBManager

__all__ = [
    "BatchTool",
    "DaytonaSandbox",
    "get_curl_tool",
    "DockerSandbox",
    "DocsManager",
    "EmailManager",
    "FargateSandbox",
    "FilesystemManager",
    "FilesystemParams",
    "FullTextSearchManager",
    "InMemoryWorkspaceBackend",
    "JustBashSandbox",
    "ModalSandbox",
    "PhilipsHueManager",
    "RandomTools",
    "RLMManager",
    "RLMPipeline",
    "RLMResult",
    "SheetsManager",
    "SqliteManager",
    "SqliteParams",
    "SubAgentManager",
    "TodoItem",
    "TodoManager",
    "TodoPriority",
    "TodoStatus",
    "ToolComposer",
    "ToolSearchTool",
    "VectorDBBackend",
    "VectorDBManager",
    "InProcessVectorDB",
    "WorkspaceBackend",
]

if sys.platform == "linux":
    __all__.append("PybubbleSandbox")

# Mapping of names to their module paths for lazy loading
_LAZY_IMPORTS: dict[str, tuple[str, str]] = {
    # batch_tool
    "BatchTool": (".batch_tool", "BatchTool"),
    # curl
    "get_curl_tool": (".curl", "get_curl_tool"),
    # docs
    "DocsManager": (".docs", "DocsManager"),
    # email
    "EmailManager": (".email", "EmailManager"),
    # filesystem
    "FilesystemManager": (".filesystem", "FilesystemManager"),
    "FilesystemParams": (".filesystem", "FilesystemParams"),
    "InMemoryWorkspaceBackend": (".filesystem", "InMemoryWorkspaceBackend"),
    "WorkspaceBackend": (".filesystem", "WorkspaceBackend"),
    # full_text_search
    "FullTextSearchManager": (".full_text_search", "FullTextSearchManager"),
    # otc
    "ToolComposer": (".otc", "ToolComposer"),
    # philips_hue
    "PhilipsHueManager": (".hue", "PhilipsHueManager"),
    # random
    "RandomTools": (".random", "RandomTools"),
    # rlm
    "RLMManager": (".rlm", "RLMManager"),
    "RLMPipeline": (".rlm", "RLMPipeline"),
    "RLMResult": (".rlm", "RLMResult"),
    # sandbox
    "DaytonaSandbox": (".sandbox", "DaytonaSandbox"),
    "DockerSandbox": (".sandbox", "DockerSandbox"),
    "FargateSandbox": (".sandbox", "FargateSandbox"),
    "JustBashSandbox": (".sandbox", "JustBashSandbox"),
    "ModalSandbox": (".sandbox", "ModalSandbox"),
    "PybubbleSandbox": (".sandbox", "PybubbleSandbox"),
    # sheets
    "SheetsManager": (".sheets", "SheetsManager"),
    # sqlite
    "SqliteManager": (".sqlite", "SqliteManager"),
    "SqliteParams": (".sqlite", "SqliteParams"),
    # subagents
    "SubAgentManager": (".subagents", "SubAgentManager"),
    # todos
    "TodoItem": (".todos", "TodoItem"),
    "TodoManager": (".todos", "TodoManager"),
    "TodoPriority": (".todos", "TodoPriority"),
    "TodoStatus": (".todos", "TodoStatus"),
    # tool_search
    "ToolSearchTool": (".tool_search", "ToolSearchTool"),
    # vector_db
    "InProcessVectorDB": (".vector_db", "InProcessVectorDB"),
    "VectorDBBackend": (".vector_db", "VectorDBBackend"),
    "VectorDBManager": (".vector_db", "VectorDBManager"),
}


def __getattr__(name: str):
    """Lazy import handler for prefab tools."""
    if name in _LAZY_IMPORTS:
        module_path, attr_name = _LAZY_IMPORTS[name]
        import importlib

        module = importlib.import_module(module_path, __package__)
        return getattr(module, attr_name)

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
