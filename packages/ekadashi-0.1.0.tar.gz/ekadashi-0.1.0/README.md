# Ekadashi Calendar – Python Library

A Python library for accurately calculating **Vaishnava / ISKCON Ekadashi dates** using astronomical calculations powered by Swiss Ephemeris.

This library provides a simple interface to determine:

* Whether a given date is **Ekadashi**
* The **next upcoming Ekadashi**
* A complete list of **Ekadashi dates for any year**

The calculations follow traditional **Vaishnava observance rules**, including:

* Dashami purity validation
* Arunodaya (96 minutes before sunrise) verification
* Correct handling of consecutive Ekadashi tithis
* Shukla and Krishna Paksha identification

The goal of this library is to make **accurate Vedic calendar calculations accessible to developers worldwide** through a lightweight and easy-to-use Python module.

---

## Installation

```bash
pip install ekadashi-calendar
```

---

## Quick Example

```python
import ekadashi

# Check if a date is Ekadashi
print(ekadashi.is_ekadashi("2026-03-29"))

# Get next Ekadashi
print(ekadashi.next_ekadashi())

# Get all Ekadashi dates in a year
print(ekadashi.get_ekadashi_dates(2026))
```

Example output:

```
{
 "date": "2026-03-29",
 "paksha": "Shukla",
 "days_until": 14
}
```

---

## Features

* Accurate Ekadashi calculations using Swiss Ephemeris
* Implements traditional **Vaishnava fasting rules**
* Clean and simple Python API
* Supports **centuries of astronomical calculations**
* Designed for integration into **apps, APIs, and calendar systems**

---

## Use Cases

This library can be used for:

* Hindu calendar applications
* Panchang calculation systems
* Devotional or spiritual reminder apps
* Astrology and astronomical tools
* Educational or research purposes

---

## Author

Developed and maintained by **Hari Prajwal** ❤️
