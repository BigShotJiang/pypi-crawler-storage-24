"""Document-knowledge MCP agents — full-text search, parsers, blob sync"""

__version__ = "0.0.1"
