import os, time, json
import ctypes
import struct
import queue
import subprocess
from threading import Thread

from ctypes import wintypes, windll, byref
kernel32 = windll.kernel32
stdout_handle = kernel32.GetStdHandle(-11) 
mode = wintypes.DWORD()
kernel32.GetConsoleMode(stdout_handle, byref(mode))
kernel32.SetConsoleMode(stdout_handle, mode.value | 0x0004)

# encoder types
class encode:
    H265 = "hevc"
    H264 = "h264"
    AV1 = "av1"

# container types
class suffix:
    MP4 = "mp4"
    M4V = "m4v"
    MOV = "mov"
    
class yuv4xx:
    YUV444 = "YUV444"
    YUV420 = "NV12"

class preset:
    P1 = "P1"
    P2 = "P2"
    P3 = "P3"
    P4 = "P4"
    P5 = "P5"
    P6 = "P6"
    P7 = "P7"

class loading():
    def __init__(self, prompt="正在加载数据"):
        self.prompt = prompt
        self.loading = True
        self.t = Thread(target=self.start)
        self.t.daemon = True
        self.t.start()

    def __enter__(self):
        return self
    
    def __exit__(self, *args, **kwargs):
        self.loading = False
        self.t.join()
        print("\r\x1b[K", end="\r")
        return False
    
    def start(self):
        while self.loading:
            for i in "/-\\|":
                print("\r\x1b[K\r{0} ... {1}".format(self.prompt, i), end="")
                for _ in range(10):
                    if not self.loading: break
                    time.sleep(0.02)

class DEVsettings:
    def __init__(self):
        self.default = self.get_default()
        self.load()

    def get_default(self):
        return {
            "兼容模式": [True, [True, False]],
            "编码预设": ['P3', ['P1', 'P2', 'P3', 'P4', 'P5', 'P6', 'P7']],
            "色彩采样": [yuv4xx.YUV444, [yuv4xx.YUV444, yuv4xx.YUV420]],
            "码率模式": ['vbr', ['cbr', 'vbr']],
            "编解码器": [encode.H265, [encode.H265, encode.AV1]],
            "封装容器": [suffix.MP4, [suffix.MP4, suffix.M4V, suffix.MOV]],
        }

    def reset(self):
        self.default = self.get_default()
        self.save()

    def load(self):
        self.file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "settings.json")
        if os.path.exists(self.file):
            with open(self.file, "r", encoding="utf-8") as f:
                local = json.load(f)
            default = self.default
            keys_local = set(local.keys())
            keys_default = set(default.keys())
            
            for k in keys_local - keys_default: # 删除多余项
                del local[k]
            for k in keys_default - keys_local: # 添加缺失项
                local[k] = default[k]

            for k in keys_default & keys_local: # 修复异常项（类型/范围/枚举/嵌套）
                dv = default[k]
                lv = local[k]
                if isinstance(dv, list) and isinstance(lv, list) and len(dv) == len(lv) and isinstance(dv[1], list) and isinstance(lv[1], list):
                    valid_value = lv[0] if lv[0] in lv[1] else dv[0]
                    if not isinstance(valid_value, type(dv[0])):
                        valid_value = dv[0]
                    valid_enum = lv[1] if all(isinstance(item, type(dv[1][0])) for item in lv[1]) else dv[1]
                    local[k] = [valid_value, valid_enum]
                    continue
                if type(lv) != type(dv):
                    local[k] = dv
                    continue
                local[k] = lv
            with open(self.file, "w", encoding="utf-8") as f:
                json.dump(local, f, ensure_ascii=False, indent=4)
            self.default = local
        else:
            with open(self.file, "w", encoding="utf-8") as f:
                json.dump(self.default, f, ensure_ascii=False, indent=4)

    def save(self):
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "settings.json"), "w", encoding="utf-8") as f:
            json.dump(self.default, f, ensure_ascii=False, indent=4)

    def change(self):
        while True:
            self.load()

            if (results := cli.menu([f"{i}: {j[0]}" for i, j in self.default.items()] + ["重置"], title="开发人员选项")) == cli.BACK:
                return cli.BACK
            
            if results == "重置":
                if cli.menu(["是", "否"], title="确认将所有设置还原为默认值吗") in [cli.BACK, "否"]:
                    continue
                self.reset()
                continue
        
            current = "（当前）"
            results = results.split(": ")[0]
            inputs = self.default.get(results)
            
            option = [str(i) + current if i == inputs[0] else i for i in inputs[1]]
            if (values := cli.menu(option, title=results, default_index=option.index(f"{inputs[0]}{current}"))) == cli.BACK:
                continue
            values = values.removesuffix(current)
            values = next(opt for opt in inputs[1] if str(opt) == values)
            self.default[results] = [values, inputs[1]]

            self.save()

profile = DEVsettings()

class cli:
    class MenuResult(ctypes.Structure):
        _fields_ = [
            ("type", ctypes.c_int),     
            ("index", ctypes.c_int),    
            ("item", ctypes.c_char_p)   
        ]

    class ArgsTracker:
        args = None
        is_rollback = False

    NAME = "Kaguya - MoonHalo"
    BACK = "__HONKAI_BACK_Event_123__"
    EXIT = "__HONKAI_EXIT_Event_000__"

    bee_lib = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'bin', 'libhonkai_all.dll')
    cli_lib = ctypes.CDLL(bee_lib)

    cli_lib.run.restype = MenuResult
    cli_lib.pick_path.restype = ctypes.c_int
    cli_lib.get_terminal_width.restype = ctypes.c_int
    cli_lib.unicode_display_width.restype = ctypes.c_int

    cli_lib.run.argtypes = [ctypes.c_char_p, ctypes.POINTER(ctypes.c_char_p), ctypes.c_int, ctypes.c_int, ctypes.c_int]
    cli_lib.pick_path.argtypes = [ctypes.c_char_p, ctypes.c_int, ctypes.c_int, ctypes.c_char_p, ctypes.c_char_p]
    cli_lib.get_terminal_width.argtypes = []
    cli_lib.unicode_display_width.argtypes = [ctypes.c_char_p]

    cli_lib.honkai_build_timestamp.restype = ctypes.c_char_p 

    beep_que = queue.Queue(1)
    beep_busy = False

    def Tracker(name, ui):
        cli.ArgsTracker.args = cli.ArgsTracker.args or []
        order = [k for k, _ in cli.ArgsTracker.args]
        m = dict(cli.ArgsTracker.args)
        if name in m:
            cli.ArgsTracker.is_rollback = True
            value = m.get(name)
        else:
            value = ui() if callable(ui) else ui
            if value == cli.BACK:
                cli.ArgsTracker.is_rollback = True
                if len(cli.ArgsTracker.args) > 0:
                    del cli.ArgsTracker.args[-1]
                return value
            elif not value:
                cli.ArgsTracker.is_rollback = False
                return value
            cli.ArgsTracker.is_rollback = False
            m[name] = value
        if name not in order:
            order.append(name)
        cli.ArgsTracker.args[:] = [(k, m.get(k)) for k in order]
        return value

    def _beep(freq=900, dur=150):
        if not os.path.exists(cli.bee_lib):
            return
        try:
            subprocess.Popen(["rundll32", cli.bee_lib + ",beep", str(freq), str(dur)], creationflags=0x08000000)
        except: pass
        
    def beep(frequency=900, duration=350):
        try:
            if not cli.beep_busy:
                cli.beep_que.put_nowait((frequency, duration))
                cli.beep_busy = True
        except: pass

    def _beep_worker():
        while True:
            freq, dur = cli.beep_que.get()
            ctypes.windll.kernel32.Beep(freq, dur)
            cli.beep_busy = False   

    def stop(s=0):
        cli._beep(2000, 500)
        print("\n进程结束。")
        os._exit(s)

    def menu(choices, title="请选择任务", page_size=10, show_choice=False, default_index=0):
        assert choices, 'choices must not be empty or None'
        assert isinstance(choices, (list, tuple)), 'choices must be list/tuple, got {0}'.format(choices)
        if isinstance(choices, list) and all(isinstance(item, tuple) and len(item) == 2 for item in choices):
            all_choices = []
            choice_functions = {}
            for key, value in choices:
                all_choices.append(key)
                choice_functions[key] = value
        else:
            all_choices = list(choices)
            choice_functions = {}
        
        choice_count = len(all_choices)
        choice_array = (ctypes.c_char_p * choice_count)(*[str(choice).encode('utf-8') for choice in all_choices])
        cli.beep(900, 150)
        result = cli.cli_lib.run(title.encode('utf-8'), choice_array, choice_count, page_size, default_index)
        if result.item is not None:
            if isinstance(result.item, bytes):
                item_text = result.item.decode('utf-8')
            elif isinstance(result.item, str):
                item_text = result.item
            else:
                item_text = str(result.item)
        else:
            item_text = str()
        if result.type == -423:   
            cli.stop(0)
        if result.type == 1:  
            return cli.BACK
        cli.beep(900, 150)
        if result.type == 0 and item_text in choice_functions:   
            func = choice_functions[item_text]
            if callable(func):
                return func()   
        return item_text
    
    def UnicodeDisplayWidth(text: str):
        if not text:
            return 0
        encoded_text = text.encode('utf-8')
        return cli.cli_lib.unicode_display_width(encoded_text)
    
    def init_cli():
        bar = [
            RF"  _  __   _   ___ _   ___   ___           __  __  ___   ___  _  _ _  _   _   _    ___  ",
            RF" | |/ /  /_\ / __| | | \ \ / /_\    ___  |  \/  |/ _ \ / _ \| \| | || | /_\ | |  / _ \ ",
            RF" | ' <  / _ \ (_ | |_| |\ V / _ \  |___| | |\/| | (_) | (_) | .` | __ |/ _ \| |_| (_) |",
            RF" |_|\_\/_/ \_\___|\___/  |_/_/ \_\       |_|  |_|\___/ \___/|_|\_|_||_/_/ \_\____\___/ ",
        ]
        h = ctypes.windll.kernel32.GetStdHandle(-11)
        csbi = ctypes.create_string_buffer(22)
        cols, rows = struct.unpack("hh", csbi.raw[:4])
        size = cols * rows
        fill = ctypes.c_ulong()
        ctypes.windll.kernel32.FillConsoleOutputCharacterA(h, ctypes.c_char(b' '), size, 0, ctypes.byref(fill))
        ctypes.windll.kernel32.FillConsoleOutputAttribute(h, struct.unpack("H", csbi.raw[4:6])[0], size, 0, ctypes.byref(fill))
        ctypes.windll.kernel32.SetConsoleCursorPosition(h, 0)
        print('\n'.join(bar), end='\n\n')
    
    def pick_file(title="选择文件", initial=""):
        buf = ctypes.create_string_buffer(8192)  # 输出缓冲区(UTF-8 bytes)
        ret = cli.cli_lib.pick_path(
            buf, ctypes.sizeof(buf),
            0,  # pick_folder=0 => file
            title.encode("utf-8"),
            initial.encode("utf-8") if initial else None
        )
        if ret == 1:
            return buf.value.decode("utf-8")
        if ret == 0:
            return None
        raise RuntimeError("pick_path failed")
    
Thread(target=cli._beep_worker, daemon=True).start()