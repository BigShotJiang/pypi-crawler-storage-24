import torch
import tensorrt as trt

orig_dlpack = torch.Tensor.__dlpack__
def dlpack_patch(self, *args, **kwargs):
    if args:
        kwargs["stream"] = args[0]
    return orig_dlpack(self, **kwargs)
torch.Tensor.__dlpack__ = dlpack_patch

class SRVGGNetTRT:
    """
    Usage:
        model = SRVGGNetTRT('model/example.trt', upscale=4)
        output = model(img_tensor)  # [1, 3, H, W], fp16
    """

    def __init__(self, engine_path, upscale=4):
        self.engine_path = engine_path
        self.upscale = upscale
        self.logger = trt.Logger(trt.Logger.WARNING)
        with open(engine_path, "rb") as f:
            engine_bytes = f.read()
        self.runtime = trt.Runtime(self.logger)
        self.engine = self.runtime.deserialize_cuda_engine(engine_bytes)
        self.context = self.engine.create_execution_context()

        # 缓存输出张量和对应的输入形状
        self._input_name = None
        self._cached_output = None
        self._last_input_shape = None

        for idx in range(self.engine.num_io_tensors):
            name = self.engine.get_tensor_name(idx)
            if self.engine.get_tensor_mode(name) == trt.TensorIOMode.INPUT:
                self._input_name = name
                break

        if self._input_name is None:
            raise RuntimeError("No input tensor found")

        if self.engine.num_optimization_profiles > 0:
            # 获取第一个 profile 的 [min, opt, max] shape
            min_shape, opt_shape, max_shape = self.engine.get_tensor_profile_shape(self._input_name, 0)
            self.min_shape = min_shape
            self.opt_shape = opt_shape
            self.max_shape = max_shape
        else:
            binding_idx = self.engine.get_binding_index(self._input_name)
            self.min_shape = tuple(self.engine.get_binding_shape(binding_idx))
            self.opt_shape = tuple(self.engine.get_binding_shape(binding_idx))
            self.max_shape = tuple(self.engine.get_binding_shape(binding_idx))

    def __call__(self, img_tensor: torch.Tensor):
        if not img_tensor.is_cuda:
            img_tensor = img_tensor.cuda()
        if not img_tensor.is_contiguous():
            img_tensor = img_tensor.contiguous()
        if img_tensor.dtype != torch.float16:
            img_tensor = img_tensor.half()

        batch, _, in_h, in_w = img_tensor.shape
        out_h, out_w = in_h * self.upscale, in_w * self.upscale
        input_shape = (batch, 3, in_h, in_w)
        output_shape = (batch, 3, out_h, out_w)
        
        if self._last_input_shape != input_shape:
            self._cached_output = torch.empty(output_shape, dtype=torch.float16, device='cuda')
            self._last_input_shape = input_shape
        output = self._cached_output

        for idx in range(self.engine.num_io_tensors):
            tensor_name = self.engine.get_tensor_name(idx)
            if self.engine.get_tensor_mode(tensor_name) == trt.TensorIOMode.INPUT:
                self.context.set_input_shape(tensor_name, img_tensor.shape)

        bindings = [int(img_tensor.data_ptr()), int(output.data_ptr())]
        self.context.execute_v2(bindings)

        return output