import cv2, torch
import numpy as np
import torch.nn.functional as F
import os, gc

from math import ceil
from itertools import product

import tensorrt as trt

_TRT_LOGGER = trt.Logger(trt.Logger.ERROR)

CFG_RE50 = {
    "min_sizes": [[16, 32], [64, 128], [256, 512]],
    "steps": [8, 16, 32],
    "variance": [0.1, 0.2],
    "clip": False,
}

MEAN_BGR = np.array([104.0, 117.0, 123.0], dtype=np.float32)

class TrtTorchModule:
    def __init__(self, engine_path: str, device="cuda"):
        if device != "cuda":
            raise ValueError("This runner requires CUDA (torch CUDA tensors).")
        if not torch.cuda.is_available():
            raise RuntimeError("torch.cuda is not available.")

        self.logger = _TRT_LOGGER
        with open(engine_path, "rb") as f:
            engine_bytes = f.read()
        self.runtime = trt.Runtime(self.logger)
        self.engine = self.runtime.deserialize_cuda_engine(engine_bytes)
        if self.engine is None:
            raise RuntimeError(f"Failed to deserialize engine: {engine_path}")

        self.context = self.engine.create_execution_context()
        if self.context is None:
            raise RuntimeError("Failed to create execution context")

        # Collect IO tensor names in engine order (num_io_tensors order)
        self.io_names = [self.engine.get_tensor_name(i) for i in range(self.engine.num_io_tensors)]
        self.input_names = [n for n in self.io_names if self.engine.get_tensor_mode(n) == trt.TensorIOMode.INPUT]
        self.output_names = [n for n in self.io_names if self.engine.get_tensor_mode(n) == trt.TensorIOMode.OUTPUT]

        if len(self.input_names) == 0:
            raise RuntimeError("No input tensor found")
        if len(self.output_names) == 0:
            raise RuntimeError("No output tensor found")

        # default "same as ORT [0]" behavior
        self.default_input_name = self.input_names[0]
        self.default_output_name = self.output_names[0]

        # Cache output tensors by (name, shape, dtype)
        self._out_cache = {}

    def _torch_dtype_for_trt(self, trt_dtype: trt.DataType):
        if trt_dtype == trt.DataType.FLOAT:
            return torch.float32
        if trt_dtype == trt.DataType.HALF:
            return torch.float16
        if trt_dtype == trt.DataType.INT32:
            return torch.int32
        if trt_dtype == trt.DataType.INT8:
            return torch.int8
        raise TypeError(f"Unsupported TRT dtype: {trt_dtype}")

    def _ensure_cuda_contiguous(self, t: torch.Tensor, want_dtype: torch.dtype):
        if not t.is_cuda:
            t = t.cuda()
        if t.dtype != want_dtype:
            t = t.to(dtype=want_dtype)
        if not t.is_contiguous():
            t = t.contiguous()
        return t

    def infer(self, feed_dict: dict):
        """
        feed_dict: {input_name: np.ndarray or torch.Tensor}

        returns: {output_name: np.ndarray}  (默认返回 numpy，便于你保持原逻辑不变)
        """
        # prepare inputs (torch cuda)
        torch_inputs = {}
        for in_name, arr in feed_dict.items():
            if isinstance(arr, torch.Tensor):
                t = arr
            else:
                t = torch.from_numpy(arr)
            want_dtype = self._torch_dtype_for_trt(self.engine.get_tensor_dtype(in_name))
            t = self._ensure_cuda_contiguous(t, want_dtype)
            torch_inputs[in_name] = t

        # set dynamic shapes for inputs
        for in_name, t in torch_inputs.items():
            self.context.set_input_shape(in_name, tuple(t.shape))

        # allocate outputs as torch cuda tensors (cached)
        torch_outputs = {}
        for out_name in self.output_names:
            out_shape = tuple(self.context.get_tensor_shape(out_name))
            if any(d < 0 for d in out_shape):
                raise RuntimeError(f"Unresolved output shape for {out_name}: {out_shape}")

            want_dtype = self._torch_dtype_for_trt(self.engine.get_tensor_dtype(out_name))
            key = (out_name, out_shape, want_dtype)
            out_t = self._out_cache.get(key)
            if out_t is None or (not out_t.is_cuda):
                out_t = torch.empty(out_shape, device="cuda", dtype=want_dtype)
                self._out_cache[key] = out_t
            torch_outputs[out_name] = out_t

        # build bindings in engine io order
        bindings = []
        for name in self.io_names:
            if self.engine.get_tensor_mode(name) == trt.TensorIOMode.INPUT:
                bindings.append(int(torch_inputs[name].data_ptr()))
            else:
                bindings.append(int(torch_outputs[name].data_ptr()))

        # execute
        ok = self.context.execute_v2(bindings)
        if not ok:
            raise RuntimeError("TensorRT execute_v2 failed")

        # return numpy outputs (like ORT run result)
        outs = {}
        for out_name, out_t in torch_outputs.items():
            outs[out_name] = out_t.detach().cpu().numpy()
        return outs

def prior_box(image_size_hw, cfg=CFG_RE50):
    """Return priors [N,4] in center-form (cx,cy,w,h), normalized to [0,1]."""
    image_h, image_w = image_size_hw
    feature_maps = [[ceil(image_h / step), ceil(image_w / step)] for step in cfg["steps"]]

    anchors = []
    for k, f in enumerate(feature_maps):
        min_sizes = cfg["min_sizes"][k]
        step = cfg["steps"][k]
        for i, j in product(range(f[0]), range(f[1])):
            for min_size in min_sizes:
                s_kx = min_size / image_w
                s_ky = min_size / image_h
                cx = (j + 0.5) * step / image_w
                cy = (i + 0.5) * step / image_h
                anchors.append([cx, cy, s_kx, s_ky])

    priors = np.asarray(anchors, dtype=np.float32)
    if cfg.get("clip", False):
        priors = np.clip(priors, 0.0, 1.0)
    return priors


def decode(loc, priors, variances):
    """
    loc:   [N,4] predicted offsets
    priors:[N,4] (cx,cy,w,h) normalized
    return boxes [N,4] (x1,y1,x2,y2) normalized
    """
    boxes_xy = priors[:, :2] + loc[:, :2] * variances[0] * priors[:, 2:]
    boxes_wh = priors[:, 2:] * np.exp(loc[:, 2:] * variances[1])
    x1y1 = boxes_xy - boxes_wh / 2.0
    x2y2 = x1y1 + boxes_wh
    return np.concatenate([x1y1, x2y2], axis=1).astype(np.float32)


def decode_landm(pre, priors, variances):
    """
    pre:   [N,10]
    priors:[N,4]
    return landms [N,10] normalized (x1,y1,...,x5,y5)
    """
    cxcy = priors[:, :2]
    wh = priors[:, 2:]
    out = []
    for i in range(5):
        out.append(cxcy + pre[:, (2*i):(2*i+2)] * variances[0] * wh)
    landms = np.concatenate(out, axis=1)
    return landms.astype(np.float32)


def py_cpu_nms(dets, iou_thresh):
    """
    dets: [N,5] x1,y1,x2,y2,score (absolute coords)
    return kept indices
    """
    if dets.shape[0] == 0:
        return []

    x1 = dets[:, 0]
    y1 = dets[:, 1]
    x2 = dets[:, 2]
    y2 = dets[:, 3]
    scores = dets[:, 4]

    areas = (x2 - x1 + 1.0) * (y2 - y1 + 1.0)
    order = scores.argsort()[::-1]

    keep = []
    while order.size > 0:
        i = order[0]
        keep.append(i)

        xx1 = np.maximum(x1[i], x1[order[1:]])
        yy1 = np.maximum(y1[i], y1[order[1:]])
        xx2 = np.minimum(x2[i], x2[order[1:]])
        yy2 = np.minimum(y2[i], y2[order[1:]])

        w = np.maximum(0.0, xx2 - xx1 + 1.0)
        h = np.maximum(0.0, yy2 - yy1 + 1.0)
        inter = w * h

        ovr = inter / (areas[i] + areas[order[1:]] - inter + 1e-9)
        inds = np.where(ovr <= iou_thresh)[0]
        order = order[inds + 1]

    return keep


class RetinaFaceONNX:
    def __init__(self, onnx_path):
        self.sess = TrtTorchModule(onnx_path)

        self.in_name = "input"
        self.out_names = ["loc", "conf", "landms"]

        self.cfg = CFG_RE50

        # resize
        self.target_size = 1600
        self.max_size = 2150

    def _transform(self, image_bgr):
        img = image_bgr.astype(np.float32)

        im_size_min = min(img.shape[0:2])
        im_size_max = max(img.shape[0:2])
        resize = float(self.target_size) / float(im_size_min)
        if round(resize * im_size_max) > self.max_size:
            resize = float(self.max_size) / float(im_size_max)
        else:
            resize = 1.0

        if resize != 1.0:
            img = cv2.resize(img, None, None, fx=resize, fy=resize, interpolation=cv2.INTER_LINEAR)

        # BGR mean
        img = img - MEAN_BGR.reshape(1, 1, 3)

        # NCHW
        x = img.transpose(2, 0, 1)[None, ...].astype(np.float32)
        return x, resize, img.shape[0], img.shape[1]

    def detect(self, image_bgr, conf_threshold=0.8, nms_threshold=0.4):
        x, resize, H, W = self._transform(image_bgr)

        outs_dict = self.sess.infer({self.in_name: x})
        outs = [outs_dict[n] for n in self.out_names]

        loc = conf = landms = None
        for o in outs:
            if o.ndim == 3 and o.shape[2] == 4:
                loc = o
            elif o.ndim == 3 and o.shape[2] == 2:
                conf = o
            elif o.ndim == 3 and o.shape[2] == 10:
                landms = o
        if loc is None or conf is None or landms is None:
            shapes = [getattr(o, "shape", None) for o in outs]
            raise RuntimeError(f"Cannot identify outputs as loc/conf/landms. Got shapes: {shapes}")

        loc = loc[0]      # [N,4]
        conf = conf[0]    # [N,2] 
        landms = landms[0]  # [N,10]

        priors = prior_box((H, W), self.cfg)  # [N,4] normalized

        boxes = decode(loc, priors, self.cfg["variance"])  # normalized
        land = decode_landm(landms, priors, self.cfg["variance"])  # normalized

        # to absolute coords on resized image
        scale = np.array([W, H, W, H], dtype=np.float32)
        scale1 = np.array([W, H] * 5, dtype=np.float32)

        boxes = boxes * scale / resize
        land = land * scale1 / resize
        scores = conf[:, 1]

        inds = np.where(scores > conf_threshold)[0]
        boxes = boxes[inds]
        land = land[inds]
        scores = scores[inds]

        order = scores.argsort()[::-1]
        boxes = boxes[order]
        land = land[order]
        scores = scores[order]

        dets = np.hstack([boxes, scores[:, None]]).astype(np.float32)
        keep = py_cpu_nms(dets, nms_threshold)

        dets = dets[keep]
        land = land[keep]
        return np.concatenate([dets, land], axis=1)  # [M, 15]

def tensor2img(tensor, rgb2bgr=True, out_type=np.uint8, min_max=(0, 1)):

    if not torch.is_tensor(tensor):
        raise TypeError(f"tensor expected, got {type(tensor)}")
    if tensor.dim() != 3:
        raise TypeError(f"Only support 3D CHW tensor here. Got dim={tensor.dim()}")

    lo, hi = float(min_max[0]), float(min_max[1])
    denom = (hi - lo) if (hi - lo) != 0 else 1.0

    t = tensor.detach()
    if t.dtype != torch.float32:
        t = t.float()
    t = t.clamp_(lo, hi)
    t = (t - lo) / denom  # [0,1]

    img = t.permute(1, 2, 0).contiguous().cpu().numpy()  # HWC, RGB
    if rgb2bgr:
        img = img[:, :, ::-1]

    if out_type == np.uint8:
        img = (img * 255.0).round().clip(0, 255).astype(np.uint8)
    else:
        img = img.astype(out_type)
    return img


def img2tensor(imgs, bgr2rgb=True, float32=True):

    if not isinstance(imgs, np.ndarray):
        raise TypeError(f"img expected np.ndarray, got {type(imgs)}")
    if imgs.ndim != 3 or imgs.shape[2] != 3:
        raise ValueError(f"Expected HWC BGR image with 3 channels, got shape {imgs.shape}")

    img = np.ascontiguousarray(imgs)
    if bgr2rgb:
 
        if img.dtype == np.float64:
            img = img.astype(np.float32, copy=False)
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

    t = torch.from_numpy(img).permute(2, 0, 1).contiguous()
    if float32:
        t = t.float()
    return t
    
class FaceRestoreHelper(object):
    """Helper for the face restoration pipeline (base class)."""

    def __init__(self,
                 upscale_factor,
                 face_size=512,
                 crop_ratio=(1, 1),
                 save_ext='png',
                 template_3points=False,
                 pad_blur=False,
                 use_parse=False,
                 device=None,
                 RetinaFace_onnx=r"C:\Users\Zhang\Downloads\GFPGAN-master\onnx\trtoutput\MoonHalo_SM86\detection_Resnet50_Final.trt",
                 parsing_parsenet=r"C:\Users\Zhang\Downloads\GFPGAN-master\onnx\trtoutput\MoonHalo_SM86\parsing_parsenet.trt",
        ):
        self.template_3points = template_3points  # improve robustness
        self.upscale_factor = upscale_factor
        # the cropped face ratio based on the square face
        self.crop_ratio = crop_ratio  # (h, w)
        assert (self.crop_ratio[0] >= 1 and self.crop_ratio[1] >= 1), 'crop ration only supports >=1'
        self.face_size = (int(face_size * self.crop_ratio[1]), int(face_size * self.crop_ratio[0]))

        if self.template_3points:
            self.face_template = np.array([[192, 240], [319, 240], [257, 371]])
        else:
            # standard 5 landmarks for FFHQ faces with 512 x 512
            self.face_template = np.array([[192.98138, 239.94708], [318.90277, 240.1936], [256.63416, 314.01935],
                                           [201.26117, 371.41043], [313.08905, 371.15118]])
        self.face_template = self.face_template * (face_size / 512.0)
        if self.crop_ratio[0] > 1:
            self.face_template[:, 1] += face_size * (self.crop_ratio[0] - 1) / 2
        if self.crop_ratio[1] > 1:
            self.face_template[:, 0] += face_size * (self.crop_ratio[1] - 1) / 2
        self.save_ext = save_ext
        self.pad_blur = pad_blur
        if self.pad_blur is True:
            self.template_3points = False

        self.all_landmarks_5 = []
        self.det_faces = []
        self.affine_matrices = []
        self.inverse_affine_matrices = []
        self.cropped_faces = []
        self.restored_faces = []
        self.pad_input_imgs = []

        if device is None:
            self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        else:
            self.device = device

        self.use_parse = use_parse

        self.detector = RetinaFaceONNX(onnx_path=RetinaFace_onnx)

        self.parsing_sess = TrtTorchModule(parsing_parsenet)
        self.parsing_input_name = "input"
        self.parsing_output_name = "logits"
        #print("Parsing ONNX loaded:", self.parsing_onnx_path)
   

    def set_upscale_factor(self, upscale_factor):
        self.upscale_factor = upscale_factor

    def read_image(self, img):
        """img can be image path or cv2 loaded image."""
        # self.input_img is Numpy array, (h, w, c), BGR, uint8, [0, 255]
        if isinstance(img, str):
            img = cv2.imread(img)

        if np.max(img) > 256:  # 16-bit image
            img = img / 65535 * 255
        if len(img.shape) == 2:  # gray image
            img = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
        elif img.shape[2] == 4:  # RGBA image with alpha channel
            img = img[:, :, 0:3]

        self.input_img = img

    def get_face_landmarks_5(self,
                             resize=None,
                             blur_ratio=0.01,
                             eye_dist_threshold=None):
        if resize is None:
            scale = 1
            input_img = self.input_img
        else:
            h, w = self.input_img.shape[0:2]
            scale = min(h, w) / resize
            h, w = int(h / scale), int(w / scale)
            input_img = cv2.resize(self.input_img, (w, h), interpolation=cv2.INTER_LANCZOS4)

        with torch.no_grad():
            bboxes = self.detector.detect(input_img, conf_threshold=0.97) * scale
            del self.detector
        for bbox in bboxes:
            # remove faces with too small eye distance: side faces or too small faces
            eye_dist = np.linalg.norm([bbox[5] - bbox[7], bbox[6] - bbox[8]])
            if eye_dist_threshold is not None and (eye_dist < eye_dist_threshold):
                continue

            if self.template_3points:
                landmark = np.array([[bbox[i], bbox[i + 1]] for i in range(5, 11, 2)])
            else:
                landmark = np.array([[bbox[i], bbox[i + 1]] for i in range(5, 15, 2)])
            self.all_landmarks_5.append(landmark)
            self.det_faces.append(bbox[0:5])
        if len(self.det_faces) == 0:
            return 0

        # pad blurry images
        if self.pad_blur:
            self.pad_input_imgs = []
            for landmarks in self.all_landmarks_5:
                # get landmarks
                eye_left = landmarks[0, :]
                eye_right = landmarks[1, :]
                eye_avg = (eye_left + eye_right) * 0.5
                mouth_avg = (landmarks[3, :] + landmarks[4, :]) * 0.5
                eye_to_eye = eye_right - eye_left
                eye_to_mouth = mouth_avg - eye_avg

                # Get the oriented crop rectangle
                # x: half width of the oriented crop rectangle
                x = eye_to_eye - np.flipud(eye_to_mouth) * [-1, 1]
                #  - np.flipud(eye_to_mouth) * [-1, 1]: rotate 90 clockwise
                # norm with the hypotenuse: get the direction
                x /= np.hypot(*x)  # get the hypotenuse of a right triangle
                rect_scale = 1.5
                x *= max(np.hypot(*eye_to_eye) * 2.0 * rect_scale, np.hypot(*eye_to_mouth) * 1.8 * rect_scale)
                # y: half height of the oriented crop rectangle
                y = np.flipud(x) * [-1, 1]

                # c: center
                c = eye_avg + eye_to_mouth * 0.1
                # quad: (left_top, left_bottom, right_bottom, right_top)
                quad = np.stack([c - x - y, c - x + y, c + x + y, c + x - y])
                # qsize: side length of the square
                qsize = np.hypot(*x) * 2
                border = max(int(np.rint(qsize * 0.1)), 3)

                # get pad
                # pad: (width_left, height_top, width_right, height_bottom)
                pad = (int(np.floor(min(quad[:, 0]))), int(np.floor(min(quad[:, 1]))), int(np.ceil(max(quad[:, 0]))),
                       int(np.ceil(max(quad[:, 1]))))
                pad = [
                    max(-pad[0] + border, 1),
                    max(-pad[1] + border, 1),
                    max(pad[2] - self.input_img.shape[0] + border, 1),
                    max(pad[3] - self.input_img.shape[1] + border, 1)
                ]

                if max(pad) > 1:
                    # pad image
                    pad_img = np.pad(self.input_img, ((pad[1], pad[3]), (pad[0], pad[2]), (0, 0)), 'reflect')
                    # modify landmark coords
                    landmarks[:, 0] += pad[0]
                    landmarks[:, 1] += pad[1]
                    # blur pad images
                    h, w, _ = pad_img.shape
                    y, x, _ = np.ogrid[:h, :w, :1]
                    mask = np.maximum(1.0 - np.minimum(np.float32(x) / pad[0],
                                                       np.float32(w - 1 - x) / pad[2]),
                                      1.0 - np.minimum(np.float32(y) / pad[1],
                                                       np.float32(h - 1 - y) / pad[3]))
                    blur = int(qsize * blur_ratio)
                    if blur % 2 == 0:
                        blur += 1
                    blur_img = cv2.boxFilter(pad_img, 0, ksize=(blur, blur))
                    # blur_img = cv2.GaussianBlur(pad_img, (blur, blur), 0)

                    pad_img = pad_img.astype('float32')
                    pad_img += (blur_img - pad_img) * np.clip(mask * 3.0 + 1.0, 0.0, 1.0)
                    pad_img += (np.median(pad_img, axis=(0, 1)) - pad_img) * np.clip(mask, 0.0, 1.0)
                    pad_img = np.clip(pad_img, 0, 255)  # float32, [0, 255]
                    self.pad_input_imgs.append(pad_img)
                else:
                    self.pad_input_imgs.append(np.copy(self.input_img))

        return len(self.all_landmarks_5)

    def align_warp_face(self):
        """Align and warp faces with face template.
        """
        if self.pad_blur:
            assert len(self.pad_input_imgs) == len(
                self.all_landmarks_5), f'Mismatched samples: {len(self.pad_input_imgs)} and {len(self.all_landmarks_5)}'
        for idx, landmark in enumerate(self.all_landmarks_5):
            # use 5 landmarks to get affine matrix
            # use cv2.LMEDS method for the equivalence to skimage transform
            # ref: https://blog.csdn.net/yichxi/article/details/115827338
            affine_matrix = cv2.estimateAffinePartial2D(landmark, self.face_template, method=cv2.LMEDS)[0]
            self.affine_matrices.append(affine_matrix)
            if self.pad_blur:
                input_img = self.pad_input_imgs[idx]
            else:
                input_img = self.input_img
            cropped_face = cv2.warpAffine(
                input_img, affine_matrix, self.face_size, borderMode=cv2.BORDER_REFLECT101, borderValue=(135, 133, 132))  # gray
            self.cropped_faces.append(cropped_face)

    def get_inverse_affine(self, save_inverse_affine_path=None):
        """Get inverse affine matrix."""
        for idx, affine_matrix in enumerate(self.affine_matrices):
            inverse_affine = cv2.invertAffineTransform(affine_matrix)
            inverse_affine *= self.upscale_factor
            self.inverse_affine_matrices.append(inverse_affine)
            # save inverse affine matrices
            if save_inverse_affine_path is not None:
                path, _ = os.path.splitext(save_inverse_affine_path)
                save_path = f'{path}_{idx:02d}.pth'
                torch.save(inverse_affine, save_path)

    def add_restored_face(self, face):
        self.restored_faces.append(face)

    def paste_faces_to_input_image(self, upsample_img=None):

        def _to_torch_image(img_np, device, dtype=torch.float32):
            if isinstance(img_np, torch.Tensor):
                t = img_np
            else:
                t = torch.from_numpy(img_np)
            if t.ndim != 3:
                raise ValueError(f"Expected HWC image, got shape {tuple(t.shape)}")
            t = t.permute(2, 0, 1).contiguous().unsqueeze(0)
            if t.dtype in (torch.uint8, torch.int8, torch.int16, torch.int32, torch.int64, torch.uint16):
                denom = 65535.0 if t.dtype == torch.uint16 else 255.0
                t = t.to(device=device, dtype=dtype) / denom
            else:
                t = t.to(device=device, dtype=dtype)
            return t

        def _from_torch_image(t, out_uint16=False):
            t = t.clamp(0, 1)
            if out_uint16:
                t = (t * 65535.0).round().to(torch.uint16)
            else:
                t = (t * 255.0).round().to(torch.uint8)
            t = t.squeeze(0).permute(1, 2, 0).contiguous()
            return t.cpu().numpy()

        def _resize_nchw(img_nchw, size_hw):
            return F.interpolate(img_nchw, size=size_hw, mode="bilinear", align_corners=False)

        def _invert_affine_2x3(M):
            A = M[..., :2]
            b = M[..., 2:]
            A_inv = torch.linalg.inv(A)
            b_inv = -A_inv @ b
            return torch.cat([A_inv, b_inv], dim=-1)

        def _grid_from_affine_out_to_in_roi(M_out_from_in, out_y0, out_x0, out_h, out_w, in_h, in_w, device, dtype):
            M = M_out_from_in.to(device=device, dtype=dtype).unsqueeze(0)
            M_in_from_out = _invert_affine_2x3(M)

            ys = torch.arange(out_y0, out_y0 + out_h, device=device, dtype=dtype)
            xs = torch.arange(out_x0, out_x0 + out_w, device=device, dtype=dtype)
            yy, xx = torch.meshgrid(ys, xs, indexing="ij")

            ones = torch.ones_like(xx)
            p_out = torch.stack([xx, yy, ones], dim=-1).view(-1, 3).t().unsqueeze(0)

            p_in = (M_in_from_out @ p_out)
            x_in = p_in[:, 0, :].view(out_h, out_w)
            y_in = p_in[:, 1, :].view(out_h, out_w)

            x_norm = (x_in + 0.5) * (2.0 / in_w) - 1.0
            y_norm = (y_in + 0.5) * (2.0 / in_h) - 1.0

            return torch.stack([x_norm, y_norm], dim=-1).unsqueeze(0)

        def _roi_from_inverse_affine(inv_2x3, in_h, in_w, out_h, out_w):
            M = inv_2x3.astype(np.float32)
            corners = np.array([[0, 0, 1],
                                [in_w - 1, 0, 1],
                                [0, in_h - 1, 1],
                                [in_w - 1, in_h - 1, 1]], dtype=np.float32).T
            pts = (M @ corners).T
            xs = pts[:, 0]
            ys = pts[:, 1]
            x0 = int(np.floor(xs.min()))
            y0 = int(np.floor(ys.min()))
            x1 = int(np.ceil(xs.max()))
            y1 = int(np.ceil(ys.max()))
            pad = int(max(8, 0.02 * max(x1 - x0, y1 - y0)))
            x0 = max(0, x0 - pad)
            y0 = max(0, y0 - pad)
            x1 = min(out_w, x1 + pad)
            y1 = min(out_h, y1 + pad)
            if x1 <= x0 or y1 <= y0:
                return 0, 0, 0, 0
            return y0, x0, y1 - y0, x1 - x0

        h, w, _ = self.input_img.shape
        h_up, w_up = int(h * self.upscale_factor), int(w * self.upscale_factor)

        device = self.device if isinstance(self.device, torch.device) else torch.device(str(self.device))
        if device.type == "cuda" and not torch.cuda.is_available():
            device = torch.device("cpu")

        out_uint16 = (self.input_img.dtype == np.uint16)

        bg_np = self.input_img if upsample_img is None else upsample_img

        has_alpha = (len(bg_np.shape) == 3 and bg_np.shape[2] == 4)
        if has_alpha:
            alpha_np = bg_np[:, :, 3:4]
            bg_rgb_np = bg_np[:, :, 0:3]
        else:
            alpha_np = None
            bg_rgb_np = bg_np

        bg_t = _to_torch_image(bg_rgb_np, device=device)
        bg_t = _resize_nchw(bg_t, (h_up, w_up))

        if len(self.restored_faces) != len(self.inverse_affine_matrices):
            raise AssertionError("length of restored_faces and inverse_affine_matrices are different.")

        for restored_face, inverse_affine in zip(self.restored_faces, self.inverse_affine_matrices):
            inv = np.array(inverse_affine, copy=True)
            extra_offset = 0.5 * self.upscale_factor if self.upscale_factor > 1 else 0.0
            inv[:, 2] += extra_offset

            if not isinstance(restored_face, np.ndarray):
                if isinstance(restored_face, torch.Tensor):
                    rf = restored_face.detach().cpu().numpy()
                else:
                    raise TypeError(f"restored_face must be numpy array or torch tensor, got {type(restored_face)}")
            else:
                rf = restored_face

            if rf.ndim == 2:
                rf = cv2.cvtColor(rf, cv2.COLOR_GRAY2BGR)
            elif rf.shape[2] == 4:
                rf = rf[:, :, 0:3]

            face_t = _to_torch_image(rf, device=device)
            in_h, in_w = face_t.shape[-2], face_t.shape[-1]

            face_rgb = face_t[:, [2, 1, 0], :, :]
            face_rgb_512 = _resize_nchw(face_rgb, (512, 512))
            face_norm = (face_rgb_512 - 0.5) / 0.5

            with torch.no_grad():
                face_norm_np = face_norm.detach().cpu().numpy().astype(np.float32)
                logits = self.parsing_sess.infer({self.parsing_input_name: face_norm_np})[self.parsing_output_name]
                out = torch.from_numpy(logits).to(device=device).argmax(dim=1).squeeze(0)  # (512,512)

            keep_ids = [1, 2, 3, 4, 5, 6, 10, 11, 12, 13]
            mask = torch.zeros_like(out, dtype=face_t.dtype)
            for kid in keep_ids:
                mask = mask + (out == kid).to(face_t.dtype)
            mask = (mask > 0).to(face_t.dtype)

            k = 7
            pad = k // 2
            mask_t = mask.unsqueeze(0).unsqueeze(0)
            mask_t = F.max_pool2d(mask_t, kernel_size=k, stride=1, padding=pad)
            mask_t = 1.0 - F.max_pool2d(1.0 - mask_t, kernel_size=k, stride=1, padding=pad)

            ksize = 61
            sigma = 8.0
            x = torch.arange(ksize, device=device, dtype=face_t.dtype) - (ksize - 1) / 2.0
            g = torch.exp(-(x * x) / (2.0 * sigma * sigma))
            g = g / g.sum()
            g_h = g.view(1, 1, 1, ksize)
            g_v = g.view(1, 1, ksize, 1)

            mask_t = F.conv2d(mask_t, g_h, padding=(0, ksize // 2))
            mask_t = F.conv2d(mask_t, g_v, padding=(ksize // 2, 0))

            thres = 12
            mask_t[:, :, :thres, :] = 0
            mask_t[:, :, -thres:, :] = 0
            mask_t[:, :, :, :thres] = 0
            mask_t[:, :, :, -thres:] = 0

            mask_face = _resize_nchw(mask_t, (in_h, in_w))

            y0, x0, rh, rw = _roi_from_inverse_affine(inv, in_h, in_w, h_up, w_up)
            if rh == 0 or rw == 0:
                continue

            M_out_from_in = torch.from_numpy(inv.astype(np.float32))
            grid = _grid_from_affine_out_to_in_roi(
                M_out_from_in, out_y0=y0, out_x0=x0, out_h=rh, out_w=rw, in_h=in_h, in_w=in_w, device=device, dtype=face_t.dtype
            )

            warped_face = F.grid_sample(face_t, grid, mode="bicubic", padding_mode="zeros", align_corners=False)
            warped_mask = F.grid_sample(mask_face, grid, mode="nearest", padding_mode="zeros", align_corners=False).clamp(0, 1)

            bg_roi = bg_t[:, :, y0:y0 + rh, x0:x0 + rw]
            bg_t[:, :, y0:y0 + rh, x0:x0 + rw] = warped_mask * warped_face + (1.0 - warped_mask) * bg_roi

        out_rgb_np = _from_torch_image(bg_t, out_uint16=out_uint16)

        del self.parsing_sess

        if has_alpha:
            if alpha_np.dtype == np.uint16:
                alpha_t = _to_torch_image(alpha_np.astype(np.uint16), device=device)
                alpha_t = _resize_nchw(alpha_t, (h_up, w_up))
                alpha_out = (alpha_t.clamp(0, 1) * 65535.0).round().to(torch.uint16)
            else:
                alpha_t = _to_torch_image(alpha_np.astype(np.uint8), device=device)
                alpha_t = _resize_nchw(alpha_t, (h_up, w_up))
                alpha_out = (alpha_t.clamp(0, 1) * 255.0).round().to(torch.uint8)

            alpha_out = alpha_out.squeeze(0).permute(1, 2, 0).contiguous().cpu().numpy()
            out = np.concatenate([out_rgb_np, alpha_out], axis=2)
            return out

        return out_rgb_np

    def clean_all(self):
        self.all_landmarks_5 = []
        self.restored_faces = []
        self.affine_matrices = []
        self.cropped_faces = []
        self.inverse_affine_matrices = []
        self.det_faces = []
        self.pad_input_imgs = []


# 1. 加载图片
upsample_img = None

def set_upsample_img(img):
    global upsample_img
    upsample_img = np.ascontiguousarray(img)

def inference_face(
        img: str = "",
        scale_factor: int = 4,
        model_gfpgan: str = "./GFPGANv1.4.trt",
        model_retina: str = "./detection_Resnet50_Final.trt",
        model_parsenet: str = "./parsing_parsenet.trt"
    ):

    #input_img_path = r"D:\Anti_Entropy\Desktop\f2ae619b748e1507409189ae28e32428.jpg"
    output_img_path = r'C:\Users\Zhang\Downloads\GFPGAN-master\results\restored_centerface.png'
    #img = cv2.imread(input_path, cv2.IMREAD_UNCHANGED)

    alpha = None
    if img is not None and img.ndim == 3 and img.shape[2] == 4:
        alpha = img[:, :, 3:4].copy()
        img = img[:, :, :3] 

    # 2. 初始化人脸检测&对齐工具
    helper = FaceRestoreHelper(
        upscale_factor=scale_factor,
        face_size=512,
        crop_ratio=(1, 1),
        save_ext='png',
        use_parse=True,
        device='cuda',
        RetinaFace_onnx=model_retina,
        parsing_parsenet=model_parsenet,
    )
    helper.clean_all()
    helper.read_image(img)
    helper.get_face_landmarks_5(eye_dist_threshold=5)  
    helper.align_warp_face()

    if not helper.cropped_faces:
        #print('No face detected!')
        return None

    sess = TrtTorchModule(model_gfpgan)
    input_name = sess.default_input_name
    output_name = sess.default_output_name

    mean = torch.tensor([0.5, 0.5, 0.5], dtype=torch.float32, device="cuda").view(1, 3, 1, 1)
    std  = torch.tensor([0.5, 0.5, 0.5], dtype=torch.float32, device="cuda").view(1, 3, 1, 1)

    for cropped_face in helper.cropped_faces:
        model_in = cv2.resize(cropped_face, (512, 512), interpolation=cv2.INTER_LANCZOS4)
        cropped_face_t = img2tensor(model_in / 255., bgr2rgb=True, float32=True).unsqueeze(0)
        cropped_face_t = cropped_face_t.cuda(non_blocking=True).contiguous()

        cropped_face_t = (cropped_face_t - mean) / std

        output = sess.infer({input_name: cropped_face_t})[output_name]   # output 仍是 numpy

        out_tensor = torch.from_numpy(output)
        restored_512 = tensor2img(out_tensor.squeeze(0), rgb2bgr=True, min_max=(-1, 1)).astype('uint8')
        restored_crop = cv2.resize(restored_512, (512, 512), interpolation=cv2.INTER_LANCZOS4)
        helper.add_restored_face(restored_crop)

    helper.get_inverse_affine(None)
    #print("推理完成")
    del sess
    torch.cuda.empty_cache()
    gc.collect()
    restored_img = helper.paste_faces_to_input_image(upsample_img)

    if alpha is not None:
        if (alpha.shape[0], alpha.shape[1]) != (restored_img.shape[0], restored_img.shape[1]):
            alpha = cv2.resize(alpha, (restored_img.shape[1], restored_img.shape[0]), interpolation=cv2.INTER_LINEAR)

        if alpha.ndim == 2:
            alpha = alpha[:, :, None]
            
        restored_img = np.concatenate([restored_img, alpha], axis=2)

    return restored_img

    #cv2.imwrite(output_img_path, restored_img)
    #print('Restored image saved at', output_img_path)