from .MoonHalo.utils import *
from inspect import signature
from KaguyaSR_models import MODELDIR
import importlib

# 启动时屏蔽系统CUDA
root_dir = os.path.dirname(os.path.abspath(__file__))
bin_dirs = [
    os.path.join(root_dir, 'bin')
]
paths = os.environ["PATH"].split(";")
paths = list(bin_dirs) + [p for p in paths if "NVIDIA GPU Computing Toolkit" not in p]
os.environ["PATH"] = ";".join(paths)

def fastboot():
    for lib in ['cupy', 'torch', 'PyNvVideoCodec']:
        importlib.import_module(lib)

def get_cc():
    import cupy
    return "80+"
    cc = cupy.cuda.Device(0).compute_capability
    return cc
    if int(cc) < 80:
        ...

def kaguya_image():
    def inference(scale = 4, model = "", has_face=False):
        if (image := cli.pick_file(title = "选择一个图片文件")) is None:
            return 1
        from kaguya import inference_image
        return inference_image(
            scale_size = scale,
            model_path = model,
            input_path = image,
            has_face = has_face
        )
    return cli.menu([
        ("针对电脑动画图像 4x", lambda: inference(4, os.path.join(MODELDIR, f"MoonHalo_SM{get_cc()}/anime-x4_FP16.trt"))),
        ("针对一般现实图像 8x", lambda: inference(8, os.path.join(MODELDIR, f"MoonHalo_SM{get_cc()}/real-x8_FP16.trt"))),
        ("针对一般现实图像 4x", lambda: inference(4, os.path.join(MODELDIR, f"MoonHalo_SM{get_cc()}/real-x4_FP16.trt"))),
        ("针对一般现实图像 2x", lambda: inference(2, os.path.join(MODELDIR, f"MoonHalo_SM{get_cc()}/real-x2_FP16.trt"))),
        ("带人脸的现实图像 8x （preview）", lambda: inference(8, os.path.join(MODELDIR, f"MoonHalo_SM{get_cc()}/real-x8_FP16.trt"), has_face=True)),
        ("带人脸的现实图像 4x （preview）", lambda: inference(4, os.path.join(MODELDIR, f"MoonHalo_SM{get_cc()}/real-x4_FP16.trt"), has_face=True)),
        ("带人脸的现实图像 2x （preview）", lambda: inference(2, os.path.join(MODELDIR, f"MoonHalo_SM{get_cc()}/real-x2_FP16.trt"), has_face=True))
    ], title = "选择图像任务")

def kaguya_video():
    def inference(scale = 4, model = ""):
        params = signature(inference).parameters
        kwargs = {k: locals()[k] for k in params}
        if (Mbps := cli.Tracker("video_bitrate", lambda: cli.menu([
            ("2 Mbps", lambda: 1),
            ("6 Mbps", lambda: 6),
            ("12 Mbps", lambda: 12),
            ("24 Mbps", lambda: 24),
            ("30 Mbps", lambda: 30),
            ("40 Mbps", lambda: 40),
            ("50 Mbps", lambda: 50),
            ("60 Mbps", lambda: 60),
            ("80 Mbps", lambda: 80),
            ("100 Mbps", lambda: 100),
            ("120 Mbps", lambda: 120),
            ("150 Mbps", lambda: 150),
            ("180 Mbps", lambda: 180),
            ("200 Mbps", lambda: 200),
            ("240 Mbps", lambda: 240),
        ], title = "选择目标输出码率", page_size = 15, default_index=12))) == cli.BACK:
            return "BACK_TO_VIDEO_MENU"
        
        if (coder_param := cli.Tracker("cache_mode", lambda: cli.menu([
            ("单机 - 有缓存", lambda: (False, True)),
            ("单机 - 无缓存", lambda: (False, False)),
            ("联机 - 分布式计算（未完待续）", lambda: (True, True)),
        ], title = "选择工作模式"))) == cli.BACK:
            return inference(**kwargs)
        
        # TODO: 分布式计算
        
        _     = coder_param[0]
        cache = coder_param[1]

        while (video := cli.pick_file(title="选择一个视频文件")) is None:
            del cli.ArgsTracker.args[-1]
            return inference(**kwargs)
        
        from kaguya import inference_video
        return inference_video(
            scale_size = scale,
            model_path = model,
            input_path = video,
            cache_file = cache,
            coder_bits = Mbps * 1_000_000
        )
    
    while (result := cli.menu([
        ("针对动画视频 4x", lambda: inference(4, os.path.join(MODELDIR, f"MoonHalo_SM{get_cc()}/animevideov3_FP16.trt"))),
        ("针对现实视频 4x", lambda: inference(4, os.path.join(MODELDIR, f"MoonHalo_SM{get_cc()}/general-x4v3_FP16.trt")))
    ], title="选择视频任务")) == "BACK_TO_VIDEO_MENU": ...
    return result

def kaguya_benchmark():
    print("执行显卡性能测试")
    from kaguya import inference_benchmark
    return inference_benchmark(os.path.join(MODELDIR, f"MoonHalo_SM{get_cc()}/animevideov3_FP16.trt"), 4)

def clear_cache(folder):
    import shutil
    if cli.menu([f"是否确认清空 {os.path.abspath("./cache")} 文件夹"], title = "格式化缓存目录") != cli.BACK and os.path.exists(folder):
        shutil.rmtree(folder)
        os.makedirs(folder)
    return cli.BACK


def main():
    Thread(target=fastboot).start()
    cli.init_cli()
    while True:
        cli.ArgsTracker.args = None
        cli.ArgsTracker.is_rollback = False

        task = cli.menu([
            ("图片超分辨率", kaguya_image),
            ("视频超分辨率", kaguya_video),
            ("显卡性能测试", kaguya_benchmark),
            ("清空缓存目录", lambda: clear_cache("./cache")),
            ("开发人员选项", profile.change),
            ("退出", cli.stop)
        ])
        if task != cli.BACK:
            print("\n")
            cli.menu(["返回主菜单"], title="", page_size=1)
            cli.init_cli()

main()