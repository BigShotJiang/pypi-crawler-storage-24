import os
import threading
import subprocess
import queue
import torch
import ffmpeg
import gc
import shutil
import blake3
import PyNvVideoCodec as nvc
import cupy as cp
import numpy as np
import cv2
from PIL import Image
from tqdm import tqdm
from importlib import resources
from PyNvVideoCodec import ThreadedDecoder, OutputColorType

# moonhalo
from kaguya_mp4box import *
from .MoonHalo.utils import *
from .MoonHalo.model import SRVGGNetTRT

KAGUYA_ROOT = os.getenv("KAGUYA_ROOT", os.path.dirname(__file__))
CACHE_DIR = os.path.join(KAGUYA_ROOT, "cache")
OUTPUT_DIR = os.path.join(KAGUYA_ROOT, "output")

def inference_video(
    scale_size = 4,
    queue_size = 1,
    tiles_size = 8,
    model_path = "",
    input_path = "",
    cache_file = True,
    color_type = profile.default["色彩采样"][0],
    coder_type = profile.default["编解码器"][0],
    muxer_type = profile.default["封装容器"][0],
    coder_bits = 180_000_000
    ):
    torch.cuda.empty_cache()
    gc.collect()

    scale = scale_size

    assert scale in [4], "请指定有效缩放倍数"
    assert queue_size >= 1, f"队列大小: {queue_size} 必须大于等于1"
    assert input_path and os.path.exists(input_path), "视频不存在"
    assert model_path and os.path.exists(model_path), "模型不存在"

    output_video = os.path.splitext(os.path.basename(input_path))[0]

    coder_type = coder_type.lower()
    muxer_type = muxer_type.lower()

    assert coder_type in [v for k, v in vars(encode).items() if not k.startswith('__') and not callable(v)], f"不支持的编码类型: {coder_type}"
    assert muxer_type in [v for k, v in vars(suffix).items() if not k.startswith('__') and not callable(v)], f"不支持的媒体容器: {muxer_type}"

    if coder_type == encode.AV1:
        color_type = yuv4xx.YUV420

    if cache_file:
        print("计算哈希...", end="\r")
        hasher = blake3.blake3()
        with open(input_path, "rb") as f:
            while chunk := f.read(65536):
                hasher.update(chunk)
        video_hash = hasher.hexdigest()

        V_hashd = os.path.join(CACHE_DIR, video_hash[:32])
        V_cache = os.path.join(V_hashd, f"{output_video}.{coder_type}")
        os.makedirs(os.path.dirname(V_cache), exist_ok=True)

    product = os.path.join(OUTPUT_DIR, f"{output_video}.{muxer_type}")
    os.makedirs(os.path.dirname(product), exist_ok=True)

    frame_queue = queue.Queue(maxsize=queue_size)
    enhanced_queue = queue.Queue(maxsize=queue_size)

    print("读取媒体...", end="\r")
    probe_info = ffmpeg.probe(input_path)
    video = next((s for s in probe_info['streams'] if s['codec_type'] == 'video'), None)
    audio = next((s for s in probe_info['streams'] if s['codec_type'] == 'audio'), None)

    total_frames = int(video.get('nb_frames', 0))
    original_fps = eval(video['r_frame_rate']) 
    resolution = f"{video.get('width', 0)}x{video.get('height', 0)}"
    
    with resources.open_text('MoonHalo', 'rgb2yuv444.cu', encoding='utf-8') as f:
        yuv444_src = f.read()
    yuv444_kernel = cp.RawKernel(yuv444_src, 'rgb2yuv444')

    with resources.open_text('MoonHalo', 'rgb2nv12.cu', encoding='utf-8') as f:
        nv12_src = f.read()
    nv12_kernel = cp.RawKernel(nv12_src, 'rgb2nv12')

    trt_model = SRVGGNetTRT(model_path, scale)

    _, _, max_input_h, max_input_w = trt_model.max_shape

    video_info = [
        f' 输入视频名称: {os.path.basename(input_path)}',
        f' 视频推理模型: {os.path.basename(model_path)}. 形状: {max_input_w}x{max_input_h}',
        f' 输入视频信息: {resolution}, {original_fps}fps',
        f' 输出编码信息: {coder_type}, {muxer_type}, {int(coder_bits/1000_000)}MBps, {profile.default["编码预设"][0]}, {profile.default["码率模式"][0]}'
    ]

    infobar_len = max(cli.UnicodeDisplayWidth(item) for item in video_info) + 2
    print("-" * infobar_len)
    print("\n".join(video_info))
    print("-" * infobar_len, end="\n\n")

    pbar = tqdm(desc="[视频推理]", ascii=" ▓", unit="帧", total=total_frames)

    def nvcodec_reader(frame_count = 0):
        decoder = ThreadedDecoder(
            enc_file_path=input_path,
            buffer_size=1,
            gpu_id=0,
            use_device_memory=True,
            output_color_type=OutputColorType.RGBP
        )
        while frame_count < decoder.get_stream_metadata().num_frames:
            frame = decoder.get_batch_frames(1)
            if not frame:
                break
        
            # GPU torch tensor（planar RGB）
            img_tensor = torch.from_dlpack(frame[0]).contiguous()  # [3, H, W], uint8, GPU
            img_tensor = img_tensor.float() / 255.0      # float32
            img_tensor = img_tensor.unsqueeze(0).half()  # [1, 3, H, W], half
            frame_queue.put(img_tensor)
            frame_count += 1
        frame_queue.put(None)

    def rgb_tensor_to_nv12_cuda(rgb, nv12_bytes=None):
        # rgb: [H, W, 3], uint8, CUDA
        h, w, c = rgb.shape
        assert c == 3, "Input must have 3 color channels"
        stride_rgb = w * 3
        stride_nv12 = w

        # 输出形状: (h * 3 // 2, w)
        nv12_shape = (h * 3 // 2, w)
        if nv12_bytes is None or nv12_bytes.shape != nv12_shape:
            nv12_bytes = torch.empty(nv12_shape, dtype=torch.uint8, device=rgb.device)
        
        # 调用kernel
        threads = (16, 16)
        blocks = ((w + threads[0] - 1) // threads[0],
                (h + threads[1] - 1) // threads[1])
        nv12_kernel(
            blocks, threads,
            (
                cp.asarray(rgb.contiguous()),
                cp.asarray(nv12_bytes),
                w, h, stride_rgb, stride_nv12
            )
        )
        return nv12_bytes

    def rgb_tensor_to_yuv444_cuda(rgb, yuv_bytes=None):
        h, w, c = rgb.shape # rgb: [H, W, 3], uint8, CUDA
        assert c == 3, "Input must have 3 color channels"
        stride_rgb = w * 3
        stride_yuv = w
        yuv444_shape = (h * 3, w)
        if yuv_bytes is None or yuv_bytes.shape != yuv444_shape:
            yuv_bytes = torch.empty(yuv444_shape, dtype=torch.uint8, device=rgb.device)
        threads = (16, 16)
        blocks = ((w + threads[0] - 1) // threads[0],
                (h + threads[1] - 1) // threads[1])
        yuv444_kernel(
            blocks, threads,
            (
                cp.asarray(rgb.contiguous()),
                cp.asarray(yuv_bytes),
                w, h, stride_rgb, stride_yuv
            )
        )
        return yuv_bytes # (3h, w), YUV444

    def nvcodec_writer():
        frame = enhanced_queue.get()
        h, w = frame.shape[:2]
        encoder = nvc.CreateEncoder(
            width=w, 
            height=h, 
            fps=original_fps, 
            rc=profile.default["码率模式"][0], 
            fmt=color_type, 
            codec=coder_type, 
            preset=profile.default["编码预设"][0], 
            bitrate=coder_bits, 
            maxbitrate=coder_bits*3,
            usecpuinputbuffer=False
        )
        yuv_bytes = None

        if cache_file:
            with open(V_cache, "wb") as o:
                while frame is not None:
                    yuv_bytes = rgb_tensor_to_yuv444_cuda(frame, yuv_bytes) if color_type == yuv4xx.YUV444 else rgb_tensor_to_nv12_cuda(frame, yuv_bytes)
                    bitstream = encoder.Encode(yuv_bytes)
                    o.write(bytearray(bitstream))
                    frame = enhanced_queue.get()
                bitstream = encoder.EndEncode()
                o.write(bytearray(bitstream))

            pbar.close()
            cmd = ['MP4Box', '-add', f'{V_cache}:fps={str(original_fps)}']
            if os.path.exists(product):
                os.remove(product)
            if audio is not None:
                cmd.extend(['-add', f'{input_path}#audio'])
            if (code := subprocess.run(cmd + [product], check=True).returncode) != 0:
                raise RuntimeError(f"MP4Box failed: {code}")
            if os.path.exists(V_hashd):
                shutil.rmtree(V_hashd)

        else:
            process = (
                ffmpeg
                .input('pipe:')
                .output(
                    product,
                    vcodec='copy',
                    loglevel='error'
                )
                .overwrite_output()
                .run_async(pipe_stdin=True, pipe_stderr=True)
            )

            while frame is not None:
                yuv_bytes = rgb_tensor_to_yuv444_cuda(frame, yuv_bytes) if color_type == yuv4xx.YUV444 else rgb_tensor_to_nv12_cuda(frame, yuv_bytes)
                bitstream = encoder.Encode(yuv_bytes)
                process.stdin.write(bytearray(bitstream))
                frame = enhanced_queue.get()
            bitstream = encoder.EndEncode()
            process.stdin.write(bytearray(bitstream))
            process.stdin.close()
            process.wait()
            pbar.close()

            if audio is not None:
                cmd = [
                    'MP4Box',
                    '-add', f'{input_path}#audio',
                    product
                ]
                if (code := subprocess.run(cmd, check=True).returncode) != 0:
                    raise RuntimeError(f"MP4Box failed: {code}")
                
        if audio is None:
            print("No audio track found, skipping audio copy")

    t_reader = threading.Thread(target=nvcodec_reader)
    t_encoder = threading.Thread(target=nvcodec_writer)

    # 启动所有线程
    t_reader.start()
    t_encoder.start()

    TILE_PAD = int(tiles_size)
    TILE_MODE = False

    while True:
        img_tensor = frame_queue.get()
        if img_tensor is None:
            break

        img_rotate = img_tensor.shape[2] > img_tensor.shape[3] # [1, 3, H, W], H>W为竖屏
        if img_rotate: 
            img_tensor = img_tensor.permute(0, 1, 3, 2).flip(-2)

        _, _, H, W = img_tensor.shape

        if not ((H > max_input_h) or (W > max_input_w)):
            output_tensor = trt_model(img_tensor)
        else:
            if not TILE_MODE:
                print(f"分块模式启动")
                TILE_MODE = True

            output_H = H * scale
            output_W = W * scale
            output_tensor = torch.zeros((1, 3, output_H, output_W), dtype=img_tensor.dtype, device=img_tensor.device)

            block_w = max_input_w - 2 * TILE_PAD
            block_h = max_input_h - 2 * TILE_PAD

            tiles_x = (W + block_w - 1) // block_w  
            tiles_y = (H + block_h - 1) // block_h 

            for ty in range(tiles_y):
                for tx in range(tiles_x):
                    in_x0 = tx * block_w  
                    in_y0 = ty * block_h 
                    in_x1 = min(in_x0 + block_w, W)
                    in_y1 = min(in_y0 + block_h, H)

                    if (in_x1 - in_x0) % scale != 0:
                        in_x0 = in_x1 - ((in_x1 - in_x0 + scale - 1) // scale) * scale
                        in_x0 = max(0, in_x0)
                    if (in_y1 - in_y0) % scale != 0:
                        in_y0 = in_y1 - ((in_y1 - in_y0 + scale - 1) // scale) * scale
                        in_y0 = max(0, in_y0)

                    pad_x0 = max(in_x0 - TILE_PAD, 0)
                    pad_x1 = min(in_x1 + TILE_PAD, W)
                    pad_y0 = max(in_y0 - TILE_PAD, 0)
                    pad_y1 = min(in_y1 + TILE_PAD, H)

                    # tile
                    tile_input = img_tensor[:, :, pad_y0:pad_y1, pad_x0:pad_x1]
                    tile_output = trt_model(tile_input)

                    out_x0 = in_x0 * scale
                    out_y0 = in_y0 * scale
                    out_x1 = in_x1 * scale
                    out_y1 = in_y1 * scale

                    # calculate the tile_output padding field
                    crop_x0 = (in_x0 - pad_x0) * scale
                    crop_y0 = (in_y0 - pad_y0) * scale
                    crop_x1 = crop_x0 + (in_x1 - in_x0) * scale
                    crop_y1 = crop_y0 + (in_y1 - in_y0) * scale

                    output_tensor[:, :, out_y0:out_y1, out_x0:out_x1] = tile_output[:, :, crop_y0:crop_y1, crop_x0:crop_x1]

        if img_rotate:
            output_tensor = output_tensor.permute(0, 1, 3, 2).flip(-1)

        if output_tensor.shape[0] == 1:
            output_tensor = output_tensor.squeeze(0)

        output_img = (output_tensor.clamp_(0, 1).mul_(255).round_().to(torch.uint8).permute(1, 2, 0))
        enhanced_queue.put(output_img)
        pbar.update(1)

    enhanced_queue.put(None)
    del trt_model 
    torch.cuda.empty_cache()
    gc.collect()

    t_encoder.join()
    t_reader.join()

    return 0

def inference_image(
    scale_size: int = 4,
    tiles_size: int = 8,
    model_path: str = "",
    input_path: str = "",
    has_face: bool = False,
    ):
    torch.cuda.empty_cache()
    gc.collect()

    scale = scale_size

    if has_face:
        from kaguya_face import inference_face, set_upsample_img

    assert scale in [2, 4, 8], "请指定有效缩放倍数"
    assert input_path and os.path.exists(input_path), "视频不存在"
    assert model_path and os.path.exists(model_path), "模型不存在"

    output_image = os.path.splitext(os.path.basename(input_path))[0] + ".png"

    product = os.path.join(OUTPUT_DIR, f"{output_image}")

    os.makedirs(os.path.dirname(product), exist_ok=True)

    print("读取媒体...")

    if os.path.splitext(input_path)[1].lower().lstrip('.') in ["png", "jpg", "jpeg", "bmp"]:
        # 使用 OpenCV 加载常规格式
        with open(input_path, 'rb') as f:
            data = f.read()
        img_bgr = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_UNCHANGED)
        has_alpha = (img_bgr.shape[2] == 4) if img_bgr.ndim == 3 else False
        if has_alpha:
            rgb_img = cv2.cvtColor(img_bgr[:, :, :3], cv2.COLOR_BGR2RGB)
            alpha_img = Image.fromarray(img_bgr[:, :, 3], mode='L')
        else:
            rgb_img = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)
            alpha_img = None
    else:
        # 使用 PIL 加载非常规格式
        with Image.open(input_path) as img_pil:
            has_alpha = img_pil.mode in ("RGBA", "LA")
            rgb_img = np.array(img_pil.convert("RGB"))
            if has_alpha:
                alpha_img = img_pil.split()[-1]
            else:
                alpha_img = None

    # 转为 tensor
    img_tensor = torch.from_numpy(rgb_img).permute(2, 0, 1).float() / 255.0
    img_tensor = img_tensor.unsqueeze(0).half().cuda()

    trt_model = SRVGGNetTRT(model_path, scale)
    _, _, max_input_h, max_input_w = trt_model.max_shape
    print(f"最大模型输入: {max_input_w}x{max_input_h}")

    TILE_PAD = int(tiles_size)

    img_rotate = img_tensor.shape[2] > img_tensor.shape[3]

    img_pad_h = img_tensor.shape[2] % 2 and scale == 2
    img_pad_w = img_tensor.shape[3] % 2 and scale == 2

    if img_pad_h:
        zero_row = torch.zeros_like(img_tensor[:, :, :1, :])
        img_tensor = torch.cat([img_tensor, zero_row], dim=2)
    
    if img_pad_w:
        zero_col = torch.zeros_like(img_tensor[:, :, :, :1])
        img_tensor = torch.cat([img_tensor, zero_col], dim=3)

    if img_rotate:
        img_tensor = img_tensor.permute(0, 1, 3, 2).flip(-2)

    _, _, H, W = img_tensor.shape
    output_H, output_W = H * scale, W * scale

    output_rgb_cpu = np.empty((output_H, output_W, 3), dtype=np.uint8)

    if not ((H > max_input_h) or (W > max_input_w)):
        # 整图推理
        pbar = tqdm(desc="[图像推理]", ascii=" ▓", unit="块", total=1)
        output_tensor = trt_model(img_tensor)
        if img_rotate:
            output_tensor = output_tensor.permute(0, 1, 3, 2).flip(-1)
        output_tensor = output_tensor.squeeze(0)
        output_rgb_cpu = output_tensor.clamp_(0, 1).mul_(255).round_().to(torch.uint8).permute(1, 2, 0).cpu().numpy()
        pbar.update(1)
        pbar.close()
    else:
        block_w = max_input_w - 2 * TILE_PAD
        block_h = max_input_h - 2 * TILE_PAD
        tiles_x = (W + block_w - 1) // block_w
        tiles_y = (H + block_h - 1) // block_h

        pbar = tqdm(desc="[图像推理]", ascii=" ▓", unit="块", total=tiles_x * tiles_y)

        for ty in range(tiles_y):
            for tx in range(tiles_x):
                in_x0 = tx * block_w
                in_y0 = ty * block_h
                in_x1 = min(in_x0 + block_w, W)
                in_y1 = min(in_y0 + block_h, H)

                if (in_x1 - in_x0) % scale != 0:
                    in_x0 = in_x1 - ((in_x1 - in_x0 + scale - 1) // scale) * scale
                    in_x0 = max(0, in_x0)
                if (in_y1 - in_y0) % scale != 0:
                    in_y0 = in_y1 - ((in_y1 - in_y0 + scale - 1) // scale) * scale
                    in_y0 = max(0, in_y0)

                pad_x0 = max(in_x0 - TILE_PAD, 0)
                pad_x1 = min(in_x1 + TILE_PAD, W)
                pad_y0 = max(in_y0 - TILE_PAD, 0)
                pad_y1 = min(in_y1 + TILE_PAD, H)

                # 只拷贝当前 tile 到 GPU（如果尚未在 GPU）
                tile_input = img_tensor[:, :, pad_y0:pad_y1, pad_x0:pad_x1]
                tile_output = trt_model(tile_input)

                out_x0 = in_x0 * scale
                out_y0 = in_y0 * scale
                out_x1 = in_x1 * scale
                out_y1 = in_y1 * scale

                crop_x0 = (in_x0 - pad_x0) * scale
                crop_y0 = (in_y0 - pad_y0) * scale
                crop_x1 = crop_x0 + (in_x1 - in_x0) * scale
                crop_y1 = crop_y0 + (in_y1 - in_y0) * scale

                tile_rgb = tile_output[:, :, crop_y0:crop_y1, crop_x0:crop_x1]
                tile_rgb = tile_rgb.squeeze(0).permute(1, 2, 0)  # [H, W, 3]
                tile_rgb = (tile_rgb.clamp_(0, 1).mul_(255).round_().to(torch.uint8))
                output_rgb_cpu[out_y0:out_y1, out_x0:out_x1] = tile_rgb.cpu().numpy()
                pbar.update(1)

        if img_rotate:
            output_rgb_cpu = np.rot90(output_rgb_cpu, k=-1, axes=(0, 1))

        pbar.close()

    if img_pad_h:
        output_rgb_cpu = output_rgb_cpu[:-scale, :]

    if img_pad_w:
        output_rgb_cpu = output_rgb_cpu[:, :-scale]

    final_h, final_w = output_rgb_cpu.shape[:2]

    del trt_model 
    torch.cuda.empty_cache()
    gc.collect()

    with loading("正在执行后处理") as loading_bar:
        if has_alpha:
            alpha_resized = alpha_img.resize((final_w, final_h), Image.BICUBIC)
            alpha_np = np.array(alpha_resized)  # (H, W)
            rgba = np.concatenate([output_rgb_cpu, alpha_np[..., None]], axis=-1)  # [H, W, 4], RGB + A
            bgra = rgba[:, :, [2, 1, 0, 3]]  # RGB → BGR for OpenCV
            if has_face:
                loading_bar.prompt = "正在处理面部信息"
                set_upsample_img(bgra)
                result = inference_face(
                    img=cv2.cvtColor(rgb_img, cv2.COLOR_RGB2BGR),
                    scale_factor = scale,
                    model_gfpgan = F"{os.path.dirname(model_path)}/GFPGANv1.4.trt",
                    model_retina = F"{os.path.dirname(model_path)}/detection_Resnet50_Final.trt",
                    model_parsenet = F"{os.path.dirname(model_path)}/parsing_parsenet.trt"
                )
                bgra = result if result is not None else bgra
            loading_bar.prompt = "正在编码图片数据"
            success, encoded = cv2.imencode('.png', bgra)
        else:
            bgr = output_rgb_cpu[:, :, ::-1]
            if has_face:
                loading_bar.prompt = "正在处理面部信息"
                set_upsample_img(bgr)
                result = inference_face(
                    img=cv2.cvtColor(rgb_img, cv2.COLOR_RGB2BGR),
                    scale_factor = scale,
                    model_gfpgan = F"{os.path.dirname(model_path)}/GFPGANv1.4.trt",
                    model_retina = F"{os.path.dirname(model_path)}/detection_Resnet50_Final.trt",
                    model_parsenet = F"{os.path.dirname(model_path)}/parsing_parsenet.trt"
                )
                bgr = result if result is not None else bgr
            loading_bar.prompt = "正在编码图片数据"
            success, encoded = cv2.imencode('.png', bgr)

        if not success:
            raise RuntimeError("图片编码失败")
    
    with loading("正在写入图片文件"):
        with open(product, 'wb') as f:
            f.write(encoded.tobytes())

    torch.cuda.empty_cache()
    gc.collect()
    return 0

def inference_benchmark(model_path, scale):
    color_type = profile.default["色彩采样"][0]
    torch.cuda.empty_cache()
    gc.collect()

    with resources.open_text('MoonHalo', 'rgb2yuv444.cu', encoding='utf-8') as f:
        yuv444_src = f.read()
    yuv444_kernel = cp.RawKernel(yuv444_src, 'rgb2yuv444')

    with resources.open_text('MoonHalo', 'rgb2nv12.cu', encoding='utf-8') as f:
        nv12_src = f.read()
    nv12_kernel = cp.RawKernel(nv12_src, 'rgb2nv12')

    trt_images = {
        " 4K ": torch.rand(1, 3, 720, 1280, dtype=torch.float32, device='cuda').cuda().contiguous().half(),
        " 8K ": torch.rand(1, 3, 1080, 1920, dtype=torch.float32, device='cuda').cuda().contiguous().half()
    }
    print("正在进行性能测试，预计耗时 20 秒")
    trt_model = SRVGGNetTRT(model_path, scale)
    for i, trt_image in trt_images.items():
        count = 0
        bar_test = tqdm(desc=f"{i}推理", leave=False)
        trt_model(trt_image)
        start_time = time.perf_counter_ns()
        while (time.perf_counter_ns() - start_time) < 5_000_000_000: 
            trt_model(trt_image)
            bar_test.update(1)
            count += 1

        elapsed_ns = time.perf_counter_ns() - start_time
        bar_test.close()
        print(f"{i}推理: {count / (elapsed_ns / 1_000_000_000):.2f} fps")
        torch.cuda.empty_cache()
        gc.collect()

    def rgb_tensor_to_nv12_cuda(rgb, nv12_bytes=None):
        # rgb: [H, W, 3], uint8, CUDA
        h, w, c = rgb.shape
        assert c == 3, "Input must have 3 color channels"
        stride_rgb = w * 3
        stride_nv12 = w

        # 输出形状: (h * 3 // 2, w)
        nv12_shape = (h * 3 // 2, w)
        if nv12_bytes is None or nv12_bytes.shape != nv12_shape:
            nv12_bytes = torch.empty(nv12_shape, dtype=torch.uint8, device=rgb.device)
        
        # 调用kernel
        threads = (16, 16)
        blocks = ((w + threads[0] - 1) // threads[0],
                (h + threads[1] - 1) // threads[1])
        nv12_kernel(
            blocks, threads,
            (
                cp.asarray(rgb.contiguous()),
                cp.asarray(nv12_bytes),
                w, h, stride_rgb, stride_nv12
            )
        )
        return nv12_bytes
   
    def rgb_tensor_to_yuv444_cuda(rgb, yuv_bytes=None):
        h, w, c = rgb.shape # rgb: [H, W, 3], uint8, CUDA
        assert c == 3, "Input must have 3 color channels"
        stride_rgb = w * 3
        stride_yuv = w
        yuv444_shape = (h * 3, w)
        if yuv_bytes is None or yuv_bytes.shape != yuv444_shape:
            yuv_bytes = torch.empty(yuv444_shape, dtype=torch.uint8, device=rgb.device)
        threads = (16, 16)
        blocks = ((w + threads[0] - 1) // threads[0],
                (h + threads[1] - 1) // threads[1])
        yuv444_kernel(
            blocks, threads,
            (
                cp.asarray(rgb.contiguous()),
                cp.asarray(yuv_bytes),
                w, h, stride_rgb, stride_yuv
            )
        )
        return yuv_bytes

    for i, trt_image in trt_images.items():
        count = 0
        yuv = None
        bar_test = tqdm(desc=f"{i}编码", leave=False)
        img = (trt_model(trt_image).squeeze(0).clamp_(0, 1).mul_(255).round_().to(torch.uint8).permute(1, 2, 0))
        encoder = nvc.CreateEncoder(
            width=img.shape[:2][1], 
            height=img.shape[:2][0], 
            rc=profile.default["码率模式"][0],
            fmt=color_type, 
            codec="hevc", 
            preset=profile.default["编码预设"][0], 
            bitrate=180_000_000, 
            usecpuinputbuffer=False
        )
        start_time = time.perf_counter_ns()
        while (time.perf_counter_ns() - start_time) < 5_000_000_000: 
            yuv = rgb_tensor_to_yuv444_cuda(img, yuv) if color_type == yuv4xx.YUV444 else rgb_tensor_to_nv12_cuda(img, yuv)
            encoder.Encode(yuv)
            bar_test.update(1)
            count += 1
        
        encoder.EndEncode()
        elapsed_ns = time.perf_counter_ns() - start_time
        bar_test.close()
        print(f"{i}编码: {count / (elapsed_ns / 1_000_000_000):.2f} fps")
        torch.cuda.empty_cache()
        gc.collect()
        
    del trt_model
    torch.cuda.empty_cache()
    gc.collect()
    