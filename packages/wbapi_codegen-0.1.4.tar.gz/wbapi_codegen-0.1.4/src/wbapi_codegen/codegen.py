"""
Wildberries API code generator for wbapi-async.

Parses OpenAPI YAML files and generates:
  - <target>/src/wbapi_async/types/<name>.py
  - <target>/src/wbapi_async/methods/<name>.py
  - <target>/src/wbapi_async/types/__init__.py
  - <target>/src/wbapi_async/methods/__init__.py
  - <target>/src/wbapi_async/client/api.py
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from keyword import iskeyword
from pathlib import Path
from typing import Any

import yaml


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_CAMEL_RE = re.compile(r"(?<=[a-z0-9])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])")


def camel_to_snake(name: str) -> str:
    """nmID → nm_id, listGoods → list_goods, X-Nm-Id → x_nm_id"""
    name = re.sub(r"[^a-zA-Z0-9]", "_", name)
    s = _CAMEL_RE.sub("_", name).lower()
    s = re.sub(r"_+", "_", s).strip("_")
    if iskeyword(s):
        s = s + "_"
    return s


def snake_to_class(name: str) -> str:
    return "".join(w.title() for w in name.split("_"))


def path_to_method_name(path: str) -> str:
    parts = [p for p in path.strip("/").split("/") if p]
    if parts and parts[0] == "api":
        parts = parts[1:]
    parts = [p for p in parts if not re.fullmatch(r"v\d+", p)]
    parts = [re.sub(r"\{(\w+)\}", lambda m: camel_to_snake(m.group(1)), p) for p in parts]
    parts = [camel_to_snake(p) for p in parts]
    return "_".join(parts)


def openapi_type_to_python(schema: dict[str, Any], required: bool = False) -> str:
    if not schema:
        return "Any"
    nullable = schema.get("nullable", False)
    t = schema.get("type")
    ref = schema.get("$ref")
    if ref:
        base = "Any"
    elif t == "integer":
        base = "int"
    elif t == "number":
        base = "float"
    elif t == "boolean":
        base = "bool"
    elif t == "string":
        base = "str"
    elif t == "array":
        items = schema.get("items", {})
        inner = openapi_type_to_python(items, required=True)
        base = f"list[{inner}]"
    elif t == "object":
        base = "dict[str, Any]"
    else:
        base = "Any"
    if not required or nullable:
        return f"{base} | None"
    return base


# ---------------------------------------------------------------------------
# Rate limit parsing
# ---------------------------------------------------------------------------

_RL_TABLE_RE = re.compile(
    r"\|\s*(\d+)\s+(\w+)\s*\|"
    r"\s*(\d+)\s+requests?\s*\|"
    r"\s*(\d+)\s+(\w+)\s*\|"
    r"\s*(\d+)\s+requests?\s*\|",
    re.IGNORECASE,
)

_PERIOD_UNITS = {"sec": 1, "s": 1, "min": 60, "minute": 60, "hour": 3600}
_INTERVAL_UNITS = {"ms": 1, "s": 1000, "sec": 1000, "min": 60_000}


def _parse_duration(value: int, unit: str) -> int:
    u = unit.lower()
    result = _PERIOD_UNITS.get(u) or _PERIOD_UNITS.get(u.rstrip("s"))
    return value * (result or 60)


def _parse_interval(value: int, unit: str) -> int:
    u = unit.lower().rstrip("s")
    return value * _INTERVAL_UNITS.get(u, 1)


@dataclass
class RateLimit:
    period: int = 60
    limit: int = 10
    interval: int = 600
    burst: int = 5

    def __str__(self) -> str:
        return (
            f"RequestLimit(period={self.period}, limit={self.limit}, "
            f"interval={self.interval}, burst={self.burst})"
        )


_DEFAULT_RATE_LIMIT = RateLimit()


def parse_rate_limit(description: str) -> RateLimit:
    if not description:
        return _DEFAULT_RATE_LIMIT
    m = _RL_TABLE_RE.search(description)
    if not m:
        return _DEFAULT_RATE_LIMIT
    period_val, period_unit, limit_val, interval_val, interval_unit, burst_val = m.groups()
    return RateLimit(
        period=_parse_duration(int(period_val), period_unit),
        limit=int(limit_val),
        interval=_parse_interval(int(interval_val), interval_unit),
        burst=int(burst_val),
    )


# ---------------------------------------------------------------------------
# Intermediate representation
# ---------------------------------------------------------------------------

@dataclass
class FieldDef:
    py_name: str
    alias: str
    py_type: str
    default: Any
    description: str = ""
    exclude: bool = False


@dataclass
class TypeDef:
    class_name: str
    fields: list[FieldDef]
    description: str = ""


@dataclass
class MethodDef:
    class_name: str
    method_name: str
    api_host: str
    http_method: str
    path: str
    path_template: str | None
    return_type: str
    return_type_file: str
    data_key: str | None
    rate_limit: RateLimit
    params: list[FieldDef]
    description: str = ""
    source_url: str = ""
    type_def: TypeDef | None = None
    empty_response: bool = False  # True for 204 No Content or empty schema


# ---------------------------------------------------------------------------
# OpenAPI parser
# ---------------------------------------------------------------------------

def _host_from_server(servers: list[dict]) -> str:
    if not servers:
        return "api"
    url: str = servers[0].get("url", "")
    host = url.replace("https://", "").replace("http://", "")
    host = re.sub(r"\.wildberries\.ru$", "", host)
    host = re.sub(r"\.ru$", "", host)
    return host


def _resolve_ref(ref: str, spec: dict) -> dict:
    parts = ref.lstrip("#/").split("/")
    node: Any = spec
    for part in parts:
        if isinstance(node, dict):
            node = node.get(part, {})
        else:
            return {}
    return node if isinstance(node, dict) else {}


def _resolve_schema(schema: dict, spec: dict) -> dict:
    if "$ref" not in schema:
        return schema
    return _resolve_ref(schema["$ref"], spec)


def _collect_fields(schema: dict, spec: dict, required_set: set[str] | None = None) -> list[FieldDef]:
    schema = _resolve_schema(schema, spec)
    props = schema.get("properties", {})
    required_keys = set(schema.get("required", required_set or []))
    fields: list[FieldDef] = []
    for prop_name, prop_schema in props.items():
        prop_schema = _resolve_schema(prop_schema, spec)
        py_name = camel_to_snake(prop_name)
        required = prop_name in required_keys
        py_type = openapi_type_to_python(prop_schema, required=required)
        desc = prop_schema.get("description", "").strip().split("\n")[0]
        fields.append(FieldDef(
            py_name=py_name,
            alias=prop_name,
            py_type=py_type,
            default=None,
            description=desc,
        ))
    return fields


def _find_response_array(schema: dict, spec: dict) -> tuple[list[FieldDef], str | None]:
    schema = _resolve_schema(schema, spec)

    def walk(node: dict, path: list[str]) -> tuple[list[FieldDef] | None, list[str] | None]:
        node = _resolve_schema(node, spec)
        if node.get("type") == "array":
            items = _resolve_schema(node.get("items", {}), spec)
            return _collect_fields(items, spec), path
        if node.get("type") == "object" or "properties" in node:
            for prop, sub in node.get("properties", {}).items():
                result, found_path = walk(_resolve_schema(sub, spec), path + [prop])
                if result is not None:
                    return result, found_path
        return None, None

    fields, path_parts = walk(schema, [])
    if fields is None:
        fields = _collect_fields(schema, spec)
        return fields, None
    dot_path = ".".join(path_parts) if path_parts else None
    return fields, dot_path


_DOC_SLUG_MAP: dict[str, str] = {
    "01-general": "api-information",
    "02-products": "work-with-products",
    "03-orders-fbs": "orders-fbs",
    "04-orders-dbw": "orders-dbw",
    "05-orders-dbs": "orders-dbs",
    "06-in-store-pickup": "in-store-pickup",
    "07-orders-fbw": "orders-fbw",
    "08-promotion": "promotion",
    "09-communications": "communications",
    "10-tariffs": "tariffs",
    "11-analytics": "analytics",
    "12-reports": "reports",
    "13-finances": "financial-reports-and-accounting",
}


def _yaml_stem_to_doc_slug(stem: str) -> str:
    return _DOC_SLUG_MAP.get(stem, stem)


def parse_yaml(yaml_path: Path) -> list[MethodDef]:
    with yaml_path.open() as f:
        spec = yaml.safe_load(f)

    paths = spec.get("paths", {})
    results: list[MethodDef] = []

    for path_str, path_item in paths.items():
        path_servers = path_item.get("servers", [])

        for http_verb in ("get", "post", "put", "delete", "patch"):
            operation = path_item.get(http_verb)
            if not operation:
                continue

            servers = operation.get("servers") or path_servers or spec.get("servers", [])
            api_host = _host_from_server(servers)
            http_method = http_verb.upper()
            summary = operation.get("summary", "")
            description = operation.get("description", "")
            rate_limit = parse_rate_limit(description)

            # request parameters
            parameters = operation.get("parameters", []) + path_item.get("parameters", [])
            param_fields: list[FieldDef] = []
            path_params: list[str] = []

            for param in parameters:
                param = _resolve_schema(param, spec)
                p_name: str = param.get("name", "")
                p_in: str = param.get("in", "query")
                p_required: bool = param.get("required", p_in == "path")
                p_schema = _resolve_schema(param.get("schema", {}), spec)
                py_name = camel_to_snake(p_name)
                py_type = openapi_type_to_python(p_schema, required=p_required)
                default_val = p_schema.get("default")
                desc = param.get("description", "").strip().split("\n")[0]

                if p_in == "path":
                    path_params.append(py_name)
                    param_fields.append(FieldDef(
                        py_name=py_name,
                        alias=p_name,
                        py_type=py_type.replace(" | None", ""),
                        default=None,
                        description=desc,
                        exclude=True,
                    ))
                else:
                    if not p_required and default_val is None:
                        py_type = py_type if "| None" in py_type else f"{py_type} | None"
                    param_fields.append(FieldDef(
                        py_name=py_name,
                        alias=p_name,
                        py_type=py_type,
                        default=default_val,
                        description=desc,
                    ))

            # request body
            request_body = _resolve_schema(operation.get("requestBody", {}), spec)
            if request_body:
                body_content = request_body.get("content", {})
                body_schema = _resolve_schema(
                    body_content.get("application/json", {}).get("schema", {}), spec
                )
                body_required_keys = set(body_schema.get("required", []))
                for prop_name, prop_schema in body_schema.get("properties", {}).items():
                    prop_schema = _resolve_schema(prop_schema, spec)
                    py_name = camel_to_snake(prop_name)
                    required = prop_name in body_required_keys
                    py_type = openapi_type_to_python(prop_schema, required=required)
                    default_val = prop_schema.get("default")
                    desc = prop_schema.get("description", "").strip().split("\n")[0]
                    param_fields.append(FieldDef(
                        py_name=py_name,
                        alias=prop_name,
                        py_type=py_type,
                        default=default_val,
                        description=desc,
                    ))

            # response type
            responses = operation.get("responses", {})
            # prefer 200, then 201, then 204
            ok_response = _resolve_schema(
                responses.get("200", responses.get("201", responses.get("204", {}))), spec
            )
            ok_content = ok_response.get("content", {})
            ok_schema = _resolve_schema(
                ok_content.get("application/json", {}).get("schema", {}), spec
            )
            item_fields, data_key = _find_response_array(ok_schema, spec)
            empty_response = not ok_content or not ok_schema

            # build names from summary
            if summary:
                words = re.sub(r"[^a-zA-Z0-9 ]", "", summary).split()
                method_name = "_".join(w.lower() for w in words)
            else:
                verb_map = {"GET": "get", "POST": "post", "PUT": "update", "DELETE": "delete", "PATCH": "patch"}
                method_name = f"{verb_map.get(http_method, http_method.lower())}_{path_to_method_name(path_str)}"

            if http_method == "GET" and not method_name.startswith("get_"):
                method_name = "get_" + method_name

            type_base = method_name[4:] if method_name.startswith("get_") else method_name
            class_name = snake_to_class(method_name)
            type_class_base = snake_to_class(type_base)
            type_name = type_class_base + "Item" if data_key else type_class_base + "Response"
            type_file = camel_to_snake(type_name)

            path_clean = path_str.lstrip("/")
            if path_params:
                path_template = re.sub(
                    r"\{(\w+)\}",
                    lambda m: "{" + camel_to_snake(m.group(1)) + "}",
                    path_clean,
                )
                path_for_method = ""
            else:
                path_template = None
                path_for_method = path_clean

            tag = (operation.get("tags") or [""])[0]
            tag_slug = re.sub(r"-+", "-", re.sub(r"[^a-zA-Z0-9]", "-", tag)).strip("-")
            path_encoded = (
                path_str.replace("/", "~1")
                        .replace("{", "%7B")
                        .replace("}", "%7D")
            )
            source_url = (
                f"https://dev.wildberries.ru/en/docs/openapi/"
                f"{_yaml_stem_to_doc_slug(yaml_path.stem)}"
                f"#tag/{tag_slug}/paths/{path_encoded}/{http_verb}"
            )

            results.append(MethodDef(
                class_name=class_name,
                method_name=method_name,
                api_host=api_host,
                http_method=http_method,
                path=path_for_method,
                path_template=path_template,
                return_type=type_name,
                return_type_file=type_file,
                data_key=data_key,
                rate_limit=rate_limit,
                params=param_fields,
                description=description.strip().split("\n")[0] or summary,
                source_url=source_url,
                empty_response=empty_response,
                type_def=TypeDef(
                    class_name=type_name,
                    fields=item_fields or [],
                    description=summary,
                ),
            ))

    return results


# ---------------------------------------------------------------------------
# Code generators
# ---------------------------------------------------------------------------

def _field_line(f: FieldDef, indent: int = 4) -> str:
    pad = " " * indent
    alias_part = f', alias="{f.alias}"' if f.alias != f.py_name else ""
    exclude_part = ", exclude=True" if f.exclude else ""

    if f.default is None and not f.exclude:
        default_part = "None"
    elif f.default is not None:
        default_part = f'"{f.default}"' if isinstance(f.default, str) else str(f.default)
    else:
        default_part = None

    if default_part is not None:
        return f"{pad}{f.py_name}: {f.py_type} = Field({default_part}{alias_part}{exclude_part})"
    else:
        args = ", ".join(filter(None, [alias_part.lstrip(", "), exclude_part.lstrip(", ")]))
        return f"{pad}{f.py_name}: {f.py_type} = Field({args})"


def generate_type_file(td: TypeDef) -> str:
    uses_any = any("Any" in f.py_type for f in td.fields)
    imports = ["from pydantic import Field", "", "from .base import BaseType"]
    if uses_any:
        imports.insert(0, "from typing import Any")
        imports.insert(1, "")
    lines = imports + ["", ""]
    lines.append(f"class {td.class_name}(BaseType):")
    if td.description:
        lines.append(f'    """{td.description}"""')
        lines.append("")
    if not td.fields:
        lines.append("    pass")
    else:
        for f in td.fields:
            lines.append(_field_line(f))
    lines.append("")
    return "\n".join(lines)


def generate_method_file(md: MethodDef) -> str:
    type_import = f"from ..types.{md.return_type_file} import {md.return_type}"
    uses_field = bool(md.params)
    uses_any = any("Any" in p.py_type for p in md.params)

    imports: list[str] = []
    if uses_any:
        imports += ["from typing import Any", ""]
    if uses_field:
        imports += ["from pydantic import Field", ""]
    imports += [type_import, "from ..types.request_limit import RequestLimit", "from .base import WbMethod"]

    lines = imports + ["", ""]
    lines.append(f"class {md.class_name}(WbMethod):")

    doc_lines = []
    if md.description:
        doc_lines += _wrap_docstring_line(md.description, "    ")
    if md.source_url:
        if doc_lines:
            doc_lines.append("")
        doc_lines.append(f"    Source: {md.source_url}")
    if doc_lines:
        lines += ['    """'] + doc_lines + ['    """', ""]

    lines.append(f"    __return__ = {md.return_type}")
    if md.empty_response:
        lines.append("    __empty_response__ = True")
    lines.append(f'    __api__ = "{md.api_host}"')
    if md.path_template:
        lines.append('    __method__ = ""')
        lines.append(f'    __method_template__ = "{md.path_template}"')
    else:
        lines.append(f'    __method__ = "{md.path}"')
    if md.http_method != "GET":
        lines.append(f'    __http_method__ = "{md.http_method}"')
    if md.data_key:
        lines.append(f'    __data_key__ = "{md.data_key}"')
    lines += ["", f"    request_limit: RequestLimit = {md.rate_limit}", ""]

    if md.params:
        for p in md.params:
            lines.append(_field_line(p))
        lines.append("")

    return "\n".join(lines)


def generate_types_init(generated: list[tuple[str, str]], manual: list[tuple[str, str]]) -> str:
    all_entries = sorted(set(manual + generated), key=lambda x: x[0])
    lines = [f"from .{stem} import {cls}" for cls, stem in all_entries]
    lines += ["", "", "__all__ = ("]
    lines += [f'    "{cls}",' for cls, _ in all_entries]
    lines += [")", ""]
    return "\n".join(lines)


def generate_methods_init(generated: list[tuple[str, str]], manual: list[tuple[str, str]]) -> str:
    lines = ["from .base import WbMethod"]
    all_entries = sorted(set(manual + generated), key=lambda x: x[0])
    lines += [f"from .{stem} import {cls}" for cls, stem in all_entries]
    lines += ["", "", "__all__ = (", '    "WbMethod",']
    lines += [f'    "{cls}",' for cls, _ in all_entries]
    lines += [")", ""]
    return "\n".join(lines)


def _extract_unofficial_api_methods(api_path: Path) -> str:
    if not api_path.exists():
        return ""
    lines = api_path.read_text().splitlines(keepends=True)
    blocks: list[str] = []
    i = 0
    while i < len(lines):
        if re.match(r"    @unofficial\s*(\n|$)", lines[i]):
            block: list[str] = [lines[i]]
            i += 1
            inside_def = False
            while i < len(lines):
                l = lines[i]
                if re.match(r"    async def |    def ", l):
                    if inside_def:
                        break
                    inside_def = True
                elif inside_def and re.match(r"    @\w", l):
                    break
                block.append(l)
                i += 1
            blocks.append("".join(block).rstrip())
        else:
            i += 1
    return ("\n\n".join(blocks) + "\n") if blocks else ""


def _extract_names_from_block(block: str) -> tuple[set[str], set[str]]:
    type_names: set[str] = set()
    method_names: set[str] = set()
    for m in re.finditer(r"->\s*(?:list\[)?([A-Z][A-Za-z0-9]+)\]?", block):
        type_names.add(m.group(1))
    for m in re.finditer(r"=\s*([A-Z][A-Za-z0-9]+)\(", block):
        method_names.add(m.group(1))
    return type_names, method_names


def _wrap_docstring_line(text: str, indent: str, max_width: int = 99) -> list[str]:
    """Wrap a long docstring line at max_width, preserving indent on continuation lines."""
    words = text.split()
    lines: list[str] = []
    current = indent
    for word in words:
        candidate = current + word
        if len(candidate) > max_width and current != indent:
            lines.append(current.rstrip())
            current = indent + word
        else:
            current = candidate + " "
    lines.append(current.rstrip())
    return lines


def _api_method_wrapper(md: MethodDef) -> str:
    non_path_params = [p for p in md.params if not p.exclude]
    path_params = [p for p in md.params if p.exclude]

    sig_parts = ["self"]
    for p in path_params:
        sig_parts.append(f"{p.py_name}: {p.py_type}")
    for p in non_path_params:
        default = "None" if p.default is None else (
            f'"{p.default}"' if isinstance(p.default, str) else str(p.default)
        )
        sig_parts.append(f"{p.py_name}: {p.py_type} = {default}")

    ret = "None" if md.empty_response else f"list[{md.return_type}]"

    call_args = ", ".join(
        f"{p.py_name}={p.py_name}" for p in path_params + non_path_params
    )

    one_line_sig = ", ".join(sig_parts)
    if len(f"    async def {md.method_name}(self, {one_line_sig},") <= 99:
        sig_block = [f"        {one_line_sig},"]
    else:
        sig_block = [f"        {part}," for part in sig_parts]

    lines = [f"    async def {md.method_name}("] + sig_block + [f"    ) -> {ret}:"]
    param_docs = [p for p in path_params + non_path_params if p.description]
    ret = "None" if md.empty_response else f"list[{md.return_type}]"
    lines.append('        """')
    desc = md.description or md.method_name.replace("_", " ").title()
    lines += _wrap_docstring_line(desc, "        ")
    if md.source_url:
        lines += ["", f"        Source: {md.source_url}"]
    if param_docs:
        lines.append("")
        for p in param_docs:
            prefix = f"        :param {p.py_name}: "
            continuation = " " * len(prefix)
            words = p.description.split()
            current = prefix
            for word in words:
                candidate = current + word
                if len(candidate) > 99 and current != prefix:
                    lines.append(current.rstrip())
                    current = continuation + word
                else:
                    current = candidate + " "
            lines.append(current.rstrip())
    lines.append(f"        :return: {ret}")
    lines.append('        """')
    call_line = f"        call = {md.class_name}({call_args})"
    if len(call_line) <= 99:
        lines.append(call_line)
    else:
        inner = ",\n            ".join(f"{p.py_name}={p.py_name}" for p in path_params + non_path_params)
        lines.append(f"        call = {md.class_name}(\n            {inner},\n        )")
    lines.append("        return await self(call)")
    return "\n".join(lines)


def generate_api_file(method_defs: list[MethodDef], unofficial_block: str) -> str:
    type_imports: set[str] = set()
    method_imports: set[str] = set()

    for md in method_defs:
        type_imports.add(md.return_type)
        method_imports.add(md.class_name)

    extra_types, extra_methods = _extract_names_from_block(unofficial_block)
    type_imports |= extra_types
    method_imports |= extra_methods

    lines = [
        "from typing import Any",
        "",
        "from ..client.session.base import BaseSession",
        "from ..methods import (",
        "    WbMethod,",
        *[f"    {cls}," for cls in sorted(method_imports)],
        ")",
        "from ..types import (",
        *[f"    {cls}," for cls in sorted(type_imports)],
        ")",
        "from ..utils.token import validate_token",
        "from ..utils.unofficial import unofficial",
        "",
        "",
        "class WbAPI:",
        "    def __init__(self, token: str, session: BaseSession | None = None, **kwargs: Any) -> None:",
        '        """',
        "        WbAPI class.",
        "",
        "        Attributes:",
        "",
        "            token: Access token",
        "",
        "            Source: https://dev.wildberries.ru/en/docs/openapi/api-information#tag/Authorization/How-to-create-a-personal-access-base-or-test-token",
        '        """',
        "        validate_token(token)",
        "        if session is None:",
        '            read_timeout = kwargs.get("read_timeout", 60)',
        '            base = kwargs.get("base", "wildberries.ru")',
        "            session = BaseSession(",
        "                base=base,",
        "                timeout=read_timeout,",
        "            )",
        "",
        "        self._token = token",
        "        self.session = session",
        "",
        '    async def __aenter__(self) -> "WbAPI":',
        "        return self",
        "",
        "    async def __aexit__(self, exc_type: Any, _exc: Any, _tb: Any) -> None:",
        "        await self.session.close()",
        "",
        "    async def __call__(self, method: WbMethod) -> Any:",
        "        return await method.emit(self)",
        "",
    ]

    for md in method_defs:
        lines.append(_api_method_wrapper(md))
        lines.append("")

    if unofficial_block.strip():
        lines += ["    # --- unofficial methods (hand-written, not generated) ---", ""]
        lines += unofficial_block.splitlines()
        lines.append("")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Test generator
# ---------------------------------------------------------------------------

def _mock_value(py_type: str, field_name: str) -> str:
    """Return a plausible mock value for a given Python type string."""
    t = py_type.replace(" | None", "").strip()
    if t == "int":
        return "1"
    if t == "float":
        return "1.0"
    if t == "bool":
        return "True"
    if t == "str":
        return f'"{field_name}"'
    if t.startswith("list["):
        return "[]"
    if t.startswith("dict["):
        return "{}"
    return "None"


def _build_mock_response(fields: list[FieldDef], data_key: str | None) -> str:
    """Build the dict literal for api.add_response(...)."""
    # item dict — 3 levels deep inside add_response(...)
    pad_field = "                "  # 16 spaces
    pad_item = "            "       # 12 spaces
    field_lines = []
    for f in fields:
        val = _mock_value(f.py_type, f.alias)
        field_lines.append(f'{pad_field}"{f.alias}": {val},')

    item_dict = "{\n" + "\n".join(field_lines) + f"\n{pad_item}}}"

    if not data_key:
        return f"[{item_dict}]"

    # wrap: "data.listGoods" → {"data": {"listGoods": [item]}}
    keys = data_key.split(".")
    result = f"[{item_dict}]"
    for key in reversed(keys):
        result = '{\n' + pad_item + f'"{key}": ' + result + f"\n        }}"
    return result


def generate_test_file(md: MethodDef) -> str:
    """Render tests/test_methods/test_<name>.py for a MethodDef."""
    class_name = f"Test{md.class_name}"
    test_fn = f"test_{md.method_name}"

    # required call args (path params + required non-path params without defaults)
    required_params = [p for p in md.params if p.exclude]  # path params always required
    # also include non-optional body/query params
    for p in md.params:
        if not p.exclude and "| None" not in p.py_type and p.default is None:
            required_params.append(p)

    call_args = ", ".join(
        f"{p.py_name}={_mock_value(p.py_type, p.py_name)}" for p in required_params
    )

    if md.empty_response:
        mock_response = "None"
        assert_lines = ["        assert result is None"]
    else:
        mock_response = _build_mock_response(
            md.type_def.fields if md.type_def else [], md.data_key
        )
        assert_lines = [
            f"        assert isinstance(result, list)",
            f"        assert len(result) == 1",
            f"        assert isinstance(result[0], {md.return_type})",
        ]
        if md.type_def and md.type_def.fields:
            for f in md.type_def.fields[:3]:
                val = _mock_value(f.py_type, f.alias)
                if val != "None":
                    assert_lines.append(f"        assert result[0].{f.py_name} == {val}")

    lines = [
        "import pytest",
        "",
        *([f"from wbapi_async.types.{md.return_type_file} import {md.return_type}"] if not md.empty_response else []),
        "from tests.mocked_api import MockedAPI",
        "",
        "",
        f"@pytest.mark.unit",
        f"class {class_name}:",
        "",
        f"    async def {test_fn}(self, api: MockedAPI) -> None:",
        f"        api.add_response(",
        f"            {mock_response}",
        f"        )",
        "",
        f"        result = await api.{md.method_name}({call_args})",
        "",
        *assert_lines,
        "",
    ]
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# File discovery
# ---------------------------------------------------------------------------

def _scan_unofficial_methods(methods_dir: Path) -> set[str]:
    result: list[str] = []
    for py in methods_dir.glob("*.py"):
        if py.name.startswith("_"):
            continue
        text = py.read_text()
        if "__unofficial__" in text and "True" in text:
            result.append(py.stem)
    return set(result)


def _scan_existing(directory: Path, skip_files: set[str]) -> list[tuple[str, str]]:
    results = []
    for py in sorted(directory.glob("*.py")):
        stem = py.stem
        if stem.startswith("_") or stem in {"base", "request_limit"}:
            continue
        if stem in skip_files:
            continue
        text = py.read_text()
        for m in re.finditer(r"^class (\w+)\(", text, re.MULTILINE):
            results.append((m.group(1), stem))
    return results


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def run(yaml_files: list[Path], target: Path) -> None:
    src = target / "src" / "wbapi_async"
    methods_dir = src / "methods"
    types_dir = src / "types"
    api_path = src / "client" / "api.py"

    unofficial_stems = _scan_unofficial_methods(methods_dir)
    print(f"Unofficial methods (protected): {unofficial_stems or 'none'}")

    unofficial_block = _extract_unofficial_api_methods(api_path)

    new_type_entries: list[tuple[str, str]] = []
    new_method_entries: list[tuple[str, str]] = []
    all_method_defs: list[MethodDef] = []
    generated_stems_types: set[str] = set()
    generated_stems_methods: set[str] = set()

    for yaml_path in yaml_files:
        print(f"\nParsing {yaml_path.name} …")
        try:
            methods = parse_yaml(yaml_path)
        except Exception as e:
            print(f"  ERROR: {e}")
            continue

        print(f"  Found {len(methods)} endpoints")

        for md in methods:
            type_stem = md.return_type_file
            type_path = types_dir / f"{type_stem}.py"
            type_path.write_text(generate_type_file(md.type_def))
            print(f"  [type]   {type_path.relative_to(target)}")
            if (md.return_type, type_stem) not in new_type_entries:
                new_type_entries.append((md.return_type, type_stem))
            generated_stems_types.add(type_stem)

            method_stem = camel_to_snake(md.class_name)
            if method_stem in unofficial_stems:
                print(f"  [method] SKIP (unofficial): {method_stem}.py")
                continue
            (methods_dir / f"{method_stem}.py").write_text(generate_method_file(md))
            print(f"  [method] {(methods_dir / method_stem).relative_to(target)}.py")
            if (md.class_name, method_stem) not in new_method_entries:
                new_method_entries.append((md.class_name, method_stem))
                all_method_defs.append(md)
            generated_stems_methods.add(method_stem)

    manual_type_entries = _scan_existing(types_dir, generated_stems_types)
    unofficial_entries = _scan_existing(methods_dir, generated_stems_methods)

    # Remove stale files no longer produced by codegen
    _TYPES_KEEP = {"__init__", "base", "error", "request_limit"}
    for f in sorted(types_dir.glob("*.py")):
        if f.stem not in _TYPES_KEEP \
                and f.stem not in generated_stems_types \
                and f.stem not in {e[1] for e in manual_type_entries}:
            f.unlink()
            print(f"[removed] {f.relative_to(target)}")

    _METHODS_KEEP = {"__init__", "base"}
    for f in sorted(methods_dir.glob("*.py")):
        if f.stem not in _METHODS_KEEP \
                and f.stem not in generated_stems_methods \
                and f.stem not in unofficial_stems:
            f.unlink()
            print(f"[removed] {f.relative_to(target)}")

    always_types = [("BaseType", "base"), ("RequestLimit", "request_limit")]
    (types_dir / "__init__.py").write_text(generate_types_init(
        new_type_entries,
        [e for e in manual_type_entries if e not in new_type_entries] + always_types,
    ))
    print(f"\n[init] {(types_dir / '__init__.py').relative_to(target)}")

    (methods_dir / "__init__.py").write_text(generate_methods_init(
        new_method_entries,
        [e for e in unofficial_entries if e not in new_method_entries],
    ))
    print(f"[init] {(methods_dir / '__init__.py').relative_to(target)}")

    all_method_defs.sort(key=lambda m: m.method_name)
    api_path.write_text(generate_api_file(all_method_defs, unofficial_block))
    print(f"[api]  {api_path.relative_to(target)}")

    # --- generate tests ---
    tests_dir = target / "tests" / "test_methods"
    tests_dir.mkdir(parents=True, exist_ok=True)
    init = tests_dir / "__init__.py"
    if not init.exists():
        init.write_text("")

    # collect stems of unofficial tests (skip overwriting)
    unofficial_test_stems = {f"test_{s}" for s in unofficial_stems}

    for md in all_method_defs:
        test_stem = f"test_{camel_to_snake(md.class_name)}"
        test_path = tests_dir / f"{test_stem}.py"
        if test_stem in unofficial_test_stems:
            print(f"  [test]  SKIP (unofficial): {test_stem}.py")
            continue
        test_path.write_text(generate_test_file(md))
        print(f"[test] {test_path.relative_to(target)}")

    print("\nDone.")
