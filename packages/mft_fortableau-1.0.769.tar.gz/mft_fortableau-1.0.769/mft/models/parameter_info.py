from __future__ import annotations

from dataclasses import dataclass, field

from mft.parameterfile.parameter_info_dto import ID_PATTERN, ParameterInfoDTO, ParameterType


@dataclass
class ParameterInfo:
    id: str
    display_name: str
    type: ParameterType
    description: str | None = None
    required: bool = False
    is_list: bool = False
    enum_values: list[str] | None = None
    object_properties: list[ParameterInfo] | None = None

    def validate(self, path: str = "") -> list[str]:
        errors: list[str] = []
        prefix = f"{path}.{self.id}" if path else self.id

        if not self.id or not ID_PATTERN.match(self.id):
            errors.append(
                f"{prefix}: id must match ^[a-zA-Z][a-zA-Z\\d_]*$ (got {self.id!r})"
            )

        if not self.display_name or not self.display_name.strip():
            errors.append(f"{prefix}: display_name is required and cannot be blank")

        if self.type == ParameterType.Enum:
            if not self.enum_values or len(self.enum_values) == 0:
                errors.append(
                    f"{prefix}: Enum type requires a non-empty enum_values list"
                )

        if self.type == ParameterType.Object:
            if not self.object_properties or len(self.object_properties) == 0:
                errors.append(
                    f"{prefix}: Object type requires a non-empty object_properties list"
                )
            elif self.object_properties:
                for prop in self.object_properties:
                    errors.extend(prop.validate(prefix))

        return errors

    def to_binary_dto(self) -> ParameterInfoDTO:
        obj_props: list[ParameterInfoDTO] | None = None
        if self.object_properties:
            obj_props = [p.to_binary_dto() for p in self.object_properties]

        return ParameterInfoDTO(
            id=self.id,
            display_name=self.display_name,
            description=self.description,
            required=self.required,
            parameter_type=self.type,
            is_list=self.is_list,
            enum_values=self.enum_values,
            object_properties=obj_props,
        )

    def to_json_dict(self) -> dict:
        result: dict = {
            "id": self.id,
            "display_name": self.display_name,
            "type": self.type.name,
            "is_list": self.is_list,
            "required": self.required,
        }
        if self.description is not None:
            result["description"] = self.description
        if self.enum_values is not None:
            result["enum_values"] = self.enum_values
        if self.object_properties is not None:
            result["object_properties"] = [
                p.to_json_dict() for p in self.object_properties
            ]
        return result
