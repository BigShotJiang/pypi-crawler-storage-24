from __future__ import annotations

from dataclasses import dataclass, field

from mft.models.parameter_info import ParameterInfo
from mft.models.task_usage import TaskUsage


@dataclass
class TaskMeta:
    display_name: str
    inputs: list[ParameterInfo] = field(default_factory=list)
    outputs: list[ParameterInfo] = field(default_factory=list)
    description: str | None = None
    group: str = "Custom Tasks"
    group_index: int | None = None
    major_version: int = 1
    version_description: str | None = None
    uses: list[TaskUsage] = field(default_factory=list)

    def validate(self) -> list[str]:
        errors: list[str] = []

        if not self.display_name or not self.display_name.strip():
            errors.append("display_name is required and cannot be blank")

        if self.major_version < 1:
            errors.append("major_version must be >= 1")

        for param in self.inputs:
            errors.extend(param.validate("inputs"))

        for param in self.outputs:
            errors.extend(param.validate("outputs"))

        return errors
