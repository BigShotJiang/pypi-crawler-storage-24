from __future__ import annotations

import atexit
import json
import logging
import os
import sys
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

from mft._converter import Converter
from mft._input import Input
from mft._meta import load_task_meta
from mft._output import Output
from mft._repository import Repository
from mft._tableau_api import TableauApi
from mft._tm_client import TMClient
from mft.models.task_meta import TaskMeta
from mft.models.task_usage import TaskUsage


class MFT:
    """Central entry point for Manager for Tableau custom workflow tasks.

    ``MFT`` uses a singleton pattern: all state lives on the class itself.
    Call :meth:`init` once at the top of your script to bootstrap the runtime,
    then use the returned instance to read inputs, call Tableau APIs, query the
    repository, and write outputs. Finish every task with :meth:`Ok` or
    :meth:`Err` -- these write the final status and exit the process.

    Usage example::

        from mft import MFT

        mft = MFT.init()

        name = mft.input.get_string("name")
        rows = mft.repository.execute("SELECT * FROM _workbooks LIMIT 10")
        workbooks = mft.tableau_api.server.workbooks.get()

        mft.output.set_string("result", "done")
        MFT.Ok("Task completed")

    Dev mode vs prod mode
    ---------------------
    * **Dev mode** -- activated by passing the positional ``dev`` argument on
      the command line together with ``--server``, ``--token``, ``--server-id``,
      and ``--site``. Input is read from a JSON file (default
      ``./dev-files/input.json``), converted to the binary format
      automatically, and output is converted back to JSON on completion.
    * **Prod mode** -- the default when no ``dev`` argument is present.
      Configuration is read from environment variables (``MFT_SERVER_URL``,
      ``MFT_AUTH_TOKEN``, ``MFT_SERVER_ID``, ``MFT_SITE_CONTENT_URL``,
      ``MFT_TASK_NODE_ID``, ``MFT_JOB_ID``, ``MFT_INPUT_FILE``,
      ``MFT_OUTPUT_FILE``). Binary parameter files are used directly.

    Optional services
    -----------------
    The :attr:`tableau_api` and :attr:`repository` properties are
    **lazy-initialised** -- credentials are fetched on first access. To use
    them your ``task-meta.json`` must list the service in the ``uses`` array::

        {
            "uses": ["RestApi", "Repository"]
        }

    Accessing a property whose service is not declared in ``uses`` raises
    ``RuntimeError``.
    """

    # -- class-level state ----------------------------------------------------

    _meta: TaskMeta | None = None
    _input: Input | None = None
    _output: Output | None = None
    _is_dev: bool = False
    _tm_client: TMClient | None = None
    _server_id: str | None = None
    _site_content_url: str | None = None
    _args: dict[str, str] = {}
    _status_written: bool = False
    _converter: Converter | None = None
    _dev_output_bin_path: Path | None = None
    _dev_output_json_path: Path | None = None
    _tableau_api: TableauApi | None = None
    _repository: Repository | None = None
    _atexit_registered: bool = False
    _dev_token_file: Path | None = None
    _dev_cli_token: str | None = None

    # -- public API -----------------------------------------------------------

    @classmethod
    def init(cls, meta_path: str | Path | None = None) -> MFT:
        """Initialise the MFT runtime and return an instance for property access.

        This is the first call in every custom task script. It parses CLI
        arguments, loads ``task-meta.json``, sets up input/output streams,
        and registers an ``atexit`` safety-net that writes a failure status if
        neither :meth:`Ok` nor :meth:`Err` is called before the process ends.

        Parameters
        ----------
        meta_path:
            Explicit path to ``task-meta.json``. When *None* (the default) the
            file is located automatically relative to the calling script.

        Returns
        -------
        MFT
            A singleton instance whose properties give access to
            :attr:`input`, :attr:`output`, :attr:`tableau_api`, and
            :attr:`repository`.

        Raises
        ------
        ValueError
            If required CLI arguments (dev mode) or environment variables
            (prod mode) are missing.
        FileNotFoundError
            If the input JSON file (dev mode) or ``task-meta.json`` cannot
            be found.

        Example::

            from mft import MFT

            mft = MFT.init()                   # auto-detect dev/prod
            mft = MFT.init("path/to/meta.json") # explicit meta path
        """
        cls._args = cls._parse_args(sys.argv)
        cls._meta = load_task_meta(meta_path)

        if cls._args.get("env") == "dev":
            logger.debug("Initialising MFT in dev mode")
            cls._init_dev_mode()
        else:
            logger.debug("Initialising MFT in prod mode")
            cls._init_prod_mode()

        if not cls._atexit_registered:
            atexit.register(cls._atexit_handler)
            cls._atexit_registered = True

        return cls()

    @classmethod
    def Ok(cls, message: str = "Task completed successfully") -> None:  # noqa: N802
        """Signal successful task completion, write status, and exit.

        Call this as the last statement in your task script. It performs the
        following steps in order:

        1. Closes input/output streams and disconnects any active services
           (Tableau API, Repository, MFT backend client).
        2. In dev mode, converts the binary output file back to JSON for
           inspection.
        3. Writes a ``{"status": "Completed", "message": ...}`` status payload.
        4. Exits the process with code **0**.

        Parameters
        ----------
        message:
            Human-readable completion message included in the status output.
            Defaults to ``"Task completed successfully"``.

        Example::

            mft.output.set_string("result", "done")
            MFT.Ok()
            MFT.Ok("Processed 42 workbooks")
        """
        cls._finalize()

        if cls._is_dev and cls._converter is not None and cls._meta is not None:
            cls._converter.parameter_file_to_json(
                cls._meta.outputs,
                cls._dev_output_bin_path,
                cls._dev_output_json_path,
            )

        print(f"Task completed: {message}", file=sys.stderr)
        cls._write_status({"status": "Completed", "message": message})
        sys.exit(0)

    @classmethod
    def Err(cls, message: str, error_id: str = "TaskError") -> None:  # noqa: N802
        """Signal task failure, write status, and exit.

        Call this when your task encounters an error it cannot recover from.
        It performs the same cleanup as :meth:`Ok` (closing streams,
        disconnecting services), then writes a failure status and exits with
        code **1**. In dev mode the output converter runs on a best-effort
        basis -- converter failures are logged but do not mask the original
        error.

        Parameters
        ----------
        message:
            Human-readable error description included in the status output.
        error_id:
            Machine-readable error identifier. Defaults to ``"TaskError"``.
            Use a specific id (e.g. ``"ValidationError"``, ``"ApiTimeout"``)
            to allow the workflow engine to route errors.

        Example::

            try:
                result = risky_operation()
            except TimeoutError as exc:
                MFT.Err(str(exc), error_id="ApiTimeout")
        """
        cls._finalize()

        if cls._is_dev and cls._converter is not None and cls._meta is not None:
            try:
                cls._converter.parameter_file_to_json(
                    cls._meta.outputs,
                    cls._dev_output_bin_path,
                    cls._dev_output_json_path,
                )
            except Exception:
                logger.debug("Best-effort output conversion failed", exc_info=True)

        print(f"Task failed with error '{error_id}': {message}", file=sys.stderr)
        cls._write_status({
            "status": "Failed",
            "error": {"id": error_id, "message": message},
        })
        sys.exit(1)

    # -- properties -----------------------------------------------------------

    @property
    def input(self) -> Input:
        """Read-only accessor for task input parameters.

        Returns an :class:`~mft._input.Input` instance with typed getters
        such as ``get_string()``, ``get_integer()``, ``get_boolean()``, etc.
        The available parameter ids are defined in the ``inputs`` section of
        your ``task-meta.json``.

        Raises
        ------
        RuntimeError
            If :meth:`init` has not been called yet.

        Example::

            name = mft.input.get_string("name")
            count = mft.input.get_integer("count")
            tags = mft.input.get_string_list("tags")
        """
        if MFT._input is None:
            raise RuntimeError("MFT.init() must be called before accessing input")
        return MFT._input

    @property
    def output(self) -> Output:
        """Write accessor for task output parameters.

        Returns an :class:`~mft._output.Output` instance with typed setters
        such as ``set_string()``, ``set_integer()``, ``set_boolean()``, etc.
        The available parameter ids are defined in the ``outputs`` section of
        your ``task-meta.json``.

        Raises
        ------
        RuntimeError
            If :meth:`init` has not been called yet.

        Example::

            mft.output.set_string("result", "done")
            mft.output.set_integer("processed_count", 42)
        """
        if MFT._output is None:
            raise RuntimeError("MFT.init() must be called before accessing output")
        return MFT._output

    @property
    def tableau_api(self) -> TableauApi:
        """Lazy-initialised Tableau Server REST API client.

        Returns a connected :class:`~mft._tableau_api.TableauApi` instance.
        The underlying ``tableauserverclient.Server`` is available via
        ``mft.tableau_api.server`` and supports the full TSC API surface.

        Credentials are fetched from the MFT backend on first access and the
        connection is cached for subsequent calls. The connection is
        automatically closed when :meth:`Ok` or :meth:`Err` is called.

        Prerequisites
        -------------
        * ``"RestApi"`` must be listed in the ``uses`` array of your
          ``task-meta.json``.
        * The ``tableauserverclient`` package must be installed.

        Raises
        ------
        RuntimeError
            If :meth:`init` has not been called, or if ``"RestApi"`` is not
            declared in ``task-meta.json`` ``uses``.
        ImportError
            If ``tableauserverclient`` is not installed.

        Example::

            all_workbooks, pagination = mft.tableau_api.server.workbooks.get()
            for wb in all_workbooks:
                print(wb.name)
        """
        if MFT._meta is None:
            raise RuntimeError("MFT.init() must be called before accessing tableau_api")
        if TaskUsage.RestApi not in MFT._meta.uses:
            raise RuntimeError(
                "tableau_api requires 'RestApi' in task-meta.json 'uses' list"
            )
        if MFT._tm_client is None:
            raise RuntimeError(
                "MFT.init() must be called before accessing tableau_api"
            )
        if MFT._tableau_api is None:
            try:
                creds = MFT._tm_client.get_tableau_api_credentials(
                    MFT._server_id, MFT._site_content_url,
                )
            except Exception as exc:
                raise RuntimeError(
                    f"Failed to fetch Tableau API credentials: {exc}"
                ) from exc
            try:
                MFT._tableau_api = TableauApi(creds).connect()
            except ImportError:
                raise
            except Exception as exc:
                raise RuntimeError(
                    f"Failed to connect to Tableau Server at {creds.server_url}: {exc}"
                ) from exc
        return MFT._tableau_api

    @property
    def repository(self) -> Repository:
        """Lazy-initialised read-only Tableau Repository database client.

        Returns a connected :class:`~mft._repository.Repository` instance
        with convenience methods :meth:`~mft._repository.Repository.execute`
        (returns rows as tuples) and
        :meth:`~mft._repository.Repository.execute_dict` (returns rows as
        dicts). For advanced use cases the raw ``psycopg2`` connection is
        available via ``mft.repository.connection``.

        Credentials are fetched from the MFT backend on first access and the
        connection is cached for subsequent calls. The connection is
        automatically closed when :meth:`Ok` or :meth:`Err` is called.

        Prerequisites
        -------------
        * ``"Repository"`` must be listed in the ``uses`` array of your
          ``task-meta.json``.
        * The ``psycopg2-binary`` package must be installed.

        Raises
        ------
        RuntimeError
            If :meth:`init` has not been called, or if ``"Repository"`` is
            not declared in ``task-meta.json`` ``uses``.
        ImportError
            If ``psycopg2`` is not installed.

        Example::

            rows = mft.repository.execute(
                "SELECT name, owner_name FROM _workbooks WHERE site_id = %s",
                (site_id,),
            )
            for name, owner in rows:
                print(f"{name} owned by {owner}")
        """
        if MFT._meta is None:
            raise RuntimeError("MFT.init() must be called before accessing repository")
        if TaskUsage.Repository not in MFT._meta.uses:
            raise RuntimeError(
                "repository requires 'Repository' in task-meta.json 'uses' list"
            )
        if MFT._tm_client is None:
            raise RuntimeError(
                "MFT.init() must be called before accessing repository"
            )
        if MFT._repository is None:
            try:
                creds = MFT._tm_client.get_repository_credentials(MFT._server_id)
            except Exception as exc:
                raise RuntimeError(
                    f"Failed to fetch Repository credentials: {exc}"
                ) from exc
            try:
                MFT._repository = Repository(creds).connect()
            except ImportError:
                raise
            except Exception as exc:
                raise RuntimeError(
                    f"Failed to connect to Tableau Repository at "
                    f"{creds.host}:{creds.port}/{creds.database}: {exc}"
                ) from exc
        return MFT._repository

    # -- init helpers ---------------------------------------------------------

    @classmethod
    def _init_dev_mode(cls) -> None:
        cls._is_dev = True

        required = ["server", "token", "server_id", "site"]
        missing = [k for k in required if k not in cls._args]
        if missing:
            raise ValueError(
                f"Dev mode requires the following arguments: {', '.join('--' + k for k in missing)}"
            )

        cls._server_id = cls._args["server_id"]
        cls._site_content_url = cls._args["site"]

        # Resolve the refresh token: use the persisted token from a previous
        # run if available, otherwise fall back to the CLI --token value.
        # This avoids forcing the user to generate a new PAT for every run.
        token_file = Path("./dev-files/.mft_token")
        cli_token = cls._args["token"]
        refresh_token = cls._load_persisted_token(token_file, cli_token)

        cls._dev_token_file = token_file
        cls._dev_cli_token = cli_token
        cls._tm_client = TMClient(
            server_url=cls._args["server"],
            refresh_token=refresh_token,
            on_token_refresh=lambda t: cls._persist_token(
                token_file, cli_token, t
            ),
        )

        input_json_path = Path(cls._args.get("input_file", "./dev-files/input.json"))
        if not input_json_path.exists():
            raise FileNotFoundError(
                f"Input JSON file not found: {input_json_path}"
            )

        # Validate input JSON before converting to binary format
        cls._validate_dev_input(input_json_path)

        converter = Converter()
        cls._converter = converter

        input_bin_path = input_json_path.with_suffix(".parameterFile")
        output_bin_path = input_json_path.parent / "output.parameterFile"
        output_json_path = input_json_path.parent / "output.json"

        cls._dev_output_bin_path = output_bin_path
        cls._dev_output_json_path = output_json_path

        if cls._meta is None:
            raise RuntimeError("_meta must be set before _init_dev_mode()")
        converter.json_to_parameter_file(
            cls._meta.inputs, input_json_path, input_bin_path
        )

        input_dtos = [p.to_binary_dto() for p in cls._meta.inputs]
        output_dtos = [p.to_binary_dto() for p in cls._meta.outputs]

        cls._input = Input(str(input_bin_path), input_dtos).open()
        cls._output = Output(str(output_bin_path), output_dtos).open()

    @classmethod
    def _init_prod_mode(cls) -> None:
        cls._is_dev = False

        required_env = [
            "MFT_SERVER_URL",
            "MFT_AUTH_TOKEN",
            "MFT_SERVER_ID",
            "MFT_TASK_NODE_ID",
            "MFT_JOB_ID",
            "MFT_INPUT_FILE",
            "MFT_OUTPUT_FILE",
        ]
        missing = [k for k in required_env if not os.environ.get(k)]
        if missing:
            raise ValueError(
                f"Production mode requires the following environment variables: {', '.join(missing)}"
            )

        cls._server_id = os.environ["MFT_SERVER_ID"]
        # MFT_SITE_CONTENT_URL is set by the workflow engine.
        cls._site_content_url = os.environ.get("MFT_SITE_CONTENT_URL", "")
        cls._tm_client = TMClient(
            server_url=os.environ["MFT_SERVER_URL"],
            action_token=os.environ["MFT_AUTH_TOKEN"],
        )

        if cls._meta is None:
            raise RuntimeError("_meta must be set before _init_prod_mode()")
        input_dtos = [p.to_binary_dto() for p in cls._meta.inputs]
        output_dtos = [p.to_binary_dto() for p in cls._meta.outputs]

        cls._input = Input(os.environ["MFT_INPUT_FILE"], input_dtos).open()
        cls._output = Output(os.environ["MFT_OUTPUT_FILE"], output_dtos).open()

    # -- input validation -----------------------------------------------------

    @classmethod
    def _validate_dev_input(cls, input_json_path: Path) -> None:
        """Validate the dev-mode input JSON against metadata before conversion.

        Reads the JSON file, runs :func:`~mft._validate_input.validate_input`,
        and raises ``ValueError`` if there are validation errors.  Warnings are
        logged but do not block execution.
        """
        from mft._validate_input import validate_input

        if cls._meta is None:
            raise RuntimeError("_meta must be set before _validate_dev_input()")

        with open(input_json_path, "r", encoding="utf-8") as fh:
            data = json.load(fh)

        result = validate_input(data, cls._meta.inputs)

        for warning in result.warnings:
            logger.warning("Input validation: %s", warning)

        if not result.is_valid:
            error_list = "\n".join(f"  - {e}" for e in result.errors)
            raise ValueError(
                f"Input validation failed for {input_json_path}:\n{error_list}"
            )

    # -- finalize / status ----------------------------------------------------

    @classmethod
    def _finalize(cls) -> None:
        """Close Input/Output streams and disconnect TableauApi/Repository/TMClient (best-effort)."""
        if cls._input is not None:
            try:
                cls._input.close()
            except Exception:
                logger.warning("Failed to close Input", exc_info=True)
        if cls._output is not None:
            try:
                cls._output.close()
            except Exception:
                logger.warning("Failed to close Output", exc_info=True)
        if cls._tableau_api is not None:
            try:
                cls._tableau_api.disconnect()
            except Exception:
                logger.warning("Failed to disconnect TableauApi", exc_info=True)
        if cls._repository is not None:
            try:
                cls._repository.disconnect()
            except Exception:
                logger.warning("Failed to disconnect Repository", exc_info=True)
        if cls._tm_client is not None:
            try:
                cls._tm_client.close()
            except Exception:
                logger.warning("Failed to close TMClient", exc_info=True)

    @classmethod
    def _write_status(cls, status: dict[str, Any]) -> None:
        cls._status_written = True
        payload = json.dumps(status, indent=2)

        if cls._is_dev:
            status_path = Path("./dev-files/status.json")
            status_path.parent.mkdir(parents=True, exist_ok=True)
            status_path.write_text(payload, encoding="utf-8")
            print(payload)
        else:
            status_file = os.environ.get("MFT_STATUS_FILE")
            if status_file:
                Path(status_file).write_text(payload, encoding="utf-8")
            else:
                print(payload)

    @classmethod
    def _atexit_handler(cls) -> None:
        if cls._status_written:
            return
        cls._finalize()
        print(
            "Task exited without calling MFT.Ok() or MFT.Err()",
            file=sys.stderr,
        )
        cls._write_status({
            "status": "Failed",
            "error": {
                "id": "UnexpectedExit",
                "message": "Task exited without calling MFT.Ok() or MFT.Err()",
            },
        })

    # -- token persistence (dev mode) -----------------------------------------

    @staticmethod
    def _load_persisted_token(token_file: Path, cli_token: str) -> str:
        """Return the best available refresh token for dev mode.

        If a persisted token file exists *and* the CLI ``--token`` value has
        not changed since it was written, use the persisted (rotated) token.
        Otherwise fall back to the CLI token (first run or token change).
        """
        try:
            if token_file.exists():
                data = json.loads(token_file.read_text(encoding="utf-8"))
                if data.get("cli_token") == cli_token and data.get("refresh_token"):
                    logger.debug("Using persisted refresh token from %s", token_file)
                    return data["refresh_token"]
        except (json.JSONDecodeError, OSError):
            logger.debug("Could not read token file %s, using CLI token", token_file)
        return cli_token

    @staticmethod
    def _persist_token(
        token_file: Path, cli_token: str, refresh_token: str
    ) -> None:
        """Save the rotated refresh token to disk for the next run."""
        try:
            token_file.parent.mkdir(parents=True, exist_ok=True)
            token_file.write_text(
                json.dumps({"cli_token": cli_token, "refresh_token": refresh_token}),
                encoding="utf-8",
            )
            # Restrict to owner-only (rw-------) so other users cannot read the token.
            # On Windows this is a no-op but harmless.
            try:
                os.chmod(token_file, 0o600)
            except OSError:
                pass
            logger.debug("Persisted refresh token to %s", token_file)
        except OSError:
            logger.debug("Could not persist refresh token to %s", token_file, exc_info=True)

    # -- arg parsing ----------------------------------------------------------

    @staticmethod
    def _parse_args(argv: list[str]) -> dict[str, str]:
        args: dict[str, str] = {}
        i = 1  # skip script name
        while i < len(argv):
            arg = argv[i]
            if arg.startswith("--"):
                key, _, val = arg.partition("=")
                key = key.lstrip("-").replace("-", "_")
                if val:
                    args[key] = val
                elif i + 1 < len(argv) and not argv[i + 1].startswith("--"):
                    args[key] = argv[i + 1]
                    i += 1
                else:
                    args[key] = ""
            elif "env" not in args:
                args["env"] = arg
            i += 1
        return args

    # -- test helper ----------------------------------------------------------

    @classmethod
    def _reset(cls) -> None:
        """Reset all class-level state. For test isolation only."""
        cls._meta = None
        cls._input = None
        cls._output = None
        cls._is_dev = False
        cls._tm_client = None
        cls._server_id = None
        cls._site_content_url = None
        cls._args = {}
        cls._status_written = True  # suppress atexit handler after reset
        cls._converter = None
        cls._dev_output_bin_path = None
        cls._dev_output_json_path = None
        cls._tableau_api = None
        cls._repository = None
        cls._atexit_registered = False
        cls._dev_token_file = None
        cls._dev_cli_token = None
