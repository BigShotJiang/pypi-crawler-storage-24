from __future__ import annotations

import logging
from collections.abc import Callable
from dataclasses import dataclass
from datetime import datetime, timezone

import requests

logger = logging.getLogger(__name__)

_TIMEOUT = 30


def _extract_error(response: requests.Response) -> tuple[str, str]:
    """Best-effort extraction of the error code and message from a backend JSON response.

    Returns (error_code, message) — either or both may be empty strings.
    """
    try:
        body = response.json()
        if isinstance(body, dict):
            return (str(body.get("error", "")), str(body.get("message", "")))
    except Exception:
        pass
    return ("", "")


@dataclass
class TableauApiCredentials:
    """Tableau Server PAT credentials for TSC authentication.

    Returned by :meth:`TMClient.get_tableau_api_credentials`.  The fields
    map directly to the arguments required by
    ``tableauserverclient.PersonalAccessTokenAuth``.

    Attributes:
        server_url: Tableau Server base URL
            (e.g. ``https://tableau.example.com``).
        site_content_url: Site content URL used for site-scoped
            authentication (e.g. ``"MySite"``).
        token_name: Tableau personal-access-token name.
        token_secret: Tableau personal-access-token secret.
    """

    server_url: str
    site_content_url: str
    token_name: str
    token_secret: str


@dataclass
class RepositoryCredentials:
    """Tableau Repository (PostgreSQL) connection credentials.

    Returned by :meth:`TMClient.get_repository_credentials`.  These
    credentials connect to the Tableau Server *read-only* PostgreSQL
    repository.  Not available for Tableau Cloud servers.

    Attributes:
        host: PostgreSQL host address.
        port: PostgreSQL port (typically ``8060`` for Tableau Repository).
        database: Database name (typically ``"workgroup"``).
        username: Read-only database username.
        password: Database password.
    """

    host: str
    port: int
    database: str
    username: str
    password: str


class TMClient:
    """HTTP client for the Tableau Manager backend API.

    Acquires Tableau Server and Repository credentials on behalf of custom
    tasks.  Typically used internally by :class:`~mft.MFT` -- most task
    authors should not need to instantiate this class directly.

    Supports two authentication modes:

    - **PAT (dev mode):** Uses an MFT PAT *refresh_token* to obtain a
      short-lived *access_token* (JWT) via ``POST /api/pats/refresh``.
      The token is auto-refreshed when it expires.
    - **ActionToken (prod mode):** Uses a short-lived ActionToken directly
      as ``Authorization: CustomTask <token>``.  No refresh is needed.
    """

    def __init__(
        self,
        server_url: str,
        refresh_token: str | None = None,
        action_token: str | None = None,
        on_token_refresh: Callable[[str], None] | None = None,
    ) -> None:
        self._server_url = server_url.rstrip("/")
        if not self._server_url.startswith("https://"):
            logger.warning("TMClient server_url is not HTTPS -- credentials may be transmitted in plaintext")
        self._session = requests.Session()
        self._refresh_token = refresh_token
        self._access_token: str | None = None
        self._access_token_expires: datetime | None = None
        self._on_token_refresh = on_token_refresh

        if refresh_token is not None:
            pass  # PAT mode: tokens refreshed lazily in _ensure_access_token()
        elif action_token is not None:
            self._session.headers["Authorization"] = f"CustomTask {action_token}"
        else:
            raise ValueError("Either refresh_token or action_token must be provided")

    def _ensure_access_token(self) -> None:
        """Exchange refresh_token for access_token if expired or not yet obtained."""
        if self._refresh_token is None:
            return
        if (
            self._access_token
            and self._access_token_expires
            and datetime.now(timezone.utc) < self._access_token_expires
        ):
            return

        try:
            resp = self._session.post(
                f"{self._server_url}/api/pats/refresh",
                params={"refreshToken": self._refresh_token},
                timeout=_TIMEOUT,
            )
            resp.raise_for_status()
        except requests.ConnectionError as exc:
            raise ConnectionError(
                f"Cannot connect to MFT server at {self._server_url}. "
                f"Check that --server is correct and the server is reachable."
            ) from exc
        except requests.HTTPError as exc:
            status = getattr(exc.response, "status_code", None) if hasattr(exc, "response") else None
            error_code, detail = _extract_error(exc.response) if hasattr(exc, "response") and exc.response is not None else ("", "")
            if status == 401 or error_code in ("InvalidRefreshToken", "PatExpired"):
                raise RuntimeError(
                    "Authentication failed: the refresh token is invalid or expired. "
                    "Generate a new Personal Access Token in the MFT web UI and pass it via --token."
                ) from exc
            msg = f"Token refresh failed (HTTP {status or '?'})"
            if detail:
                msg += f": {detail}"
            else:
                msg += f". Check that --server points to a valid MFT instance."
            raise RuntimeError(msg) from exc

        data = resp.json()

        try:
            self._access_token = data["accessToken"]["token"]
            expires_str: str = data["accessToken"]["expires"]
            self._refresh_token = data["refreshToken"]["token"]
        except KeyError as exc:
            raise ValueError(
                f"Unexpected PAT refresh response format: missing key {exc}"
            ) from exc

        expires_str = expires_str.replace("Z", "+00:00")
        self._access_token_expires = datetime.fromisoformat(expires_str)
        self._session.headers["Authorization"] = f"Bearer {self._access_token}"
        logger.debug("Access token refreshed, expires %s", self._access_token_expires)

        if self._on_token_refresh is not None:
            try:
                self._on_token_refresh(self._refresh_token)
            except Exception:
                logger.debug("on_token_refresh callback failed", exc_info=True)

    def get_tableau_api_credentials(
        self, server_id: str, site_content_url: str
    ) -> TableauApiCredentials:
        """Request Tableau Server PAT credentials from the MFT backend.

        Issues ``POST /api/custom-tasks/tableau-credentials`` with the given
        server and site identifiers.  Returns credentials suitable for
        ``tableauserverclient.PersonalAccessTokenAuth``.

        Args:
            server_id: GUID of the Tableau Server registered in TM.
            site_content_url: Content URL of the target Tableau site.

        Returns:
            A :class:`TableauApiCredentials` instance containing the PAT
            token name, secret, server URL, and site content URL.

        Raises:
            requests.HTTPError: On any HTTP-level failure -- for example
                ``404`` when *server_id* is unknown (``ServerNotFound``) or
                the site is not found (``CustomTaskSiteNotFound``).
            ValueError: If the response JSON is missing expected keys.
        """
        self._ensure_access_token()
        try:
            resp = self._session.post(
                f"{self._server_url}/api/custom-tasks/tableau-credentials",
                json={"serverId": server_id, "siteContentUrl": site_content_url},
                timeout=_TIMEOUT,
            )
            resp.raise_for_status()
        except requests.ConnectionError as exc:
            raise ConnectionError(
                f"Cannot connect to MFT server at {self._server_url} "
                f"to fetch Tableau API credentials."
            ) from exc
        except requests.HTTPError as exc:
            status = getattr(exc.response, "status_code", None) if hasattr(exc, "response") else None
            error_code, detail = _extract_error(exc.response) if hasattr(exc, "response") and exc.response is not None else ("", "")
            if status == 404:
                raise RuntimeError(
                    f"Tableau API credentials request failed (HTTP 404): "
                    f"server ID {server_id!r} or site {site_content_url!r} not found. "
                    f"Check that --server-id and --site are correct."
                ) from exc
            if status == 401:
                raise RuntimeError(
                    "Tableau API credentials request failed (HTTP 401): "
                    "authentication token is invalid or expired."
                ) from exc
            msg = f"Tableau API credentials request failed (HTTP {status or '?'})"
            if detail:
                msg += f": {detail}"
            raise RuntimeError(msg) from exc

        data = resp.json()
        logger.debug("Acquired Tableau API credentials for server %s", server_id)
        try:
            return TableauApiCredentials(
                server_url=data["serverUrl"].strip(),
                site_content_url=data["siteContentUrl"].strip(),
                token_name=data["tokenName"].strip(),
                token_secret=data["tokenSecret"].strip(),
            )
        except KeyError as exc:
            raise ValueError(
                f"Unexpected tableau-credentials response format: missing key {exc}"
            ) from exc

    def get_repository_credentials(self, server_id: str) -> RepositoryCredentials:
        """Request Tableau Repository PostgreSQL credentials from the MFT backend.

        Issues ``POST /api/custom-tasks/repository-credentials`` with the
        given server identifier.  The returned credentials provide read-only
        access to the Tableau Server PostgreSQL repository.

        Args:
            server_id: GUID of the Tableau Server registered in TM.

        Returns:
            A :class:`RepositoryCredentials` instance containing host, port,
            database name, username, and password.

        Raises:
            requests.HTTPError: On any HTTP-level failure -- for example
                ``404`` when *server_id* is unknown (``ServerNotFound``) or
                the repository is not configured
                (``CustomTaskRepositoryNotConfigured``).  Tableau Cloud
                servers do not have a PostgreSQL repository and will always
                return this error.
            ValueError: If the response JSON is missing expected keys.
        """
        self._ensure_access_token()
        try:
            resp = self._session.post(
                f"{self._server_url}/api/custom-tasks/repository-credentials",
                json={"serverId": server_id},
                timeout=_TIMEOUT,
            )
            resp.raise_for_status()
        except requests.ConnectionError as exc:
            raise ConnectionError(
                f"Cannot connect to MFT server at {self._server_url} "
                f"to fetch Repository credentials."
            ) from exc
        except requests.HTTPError as exc:
            status = getattr(exc.response, "status_code", None) if hasattr(exc, "response") else None
            error_code, detail = _extract_error(exc.response) if hasattr(exc, "response") and exc.response is not None else ("", "")
            if status == 404:
                raise RuntimeError(
                    f"Repository credentials request failed (HTTP 404): "
                    f"server ID {server_id!r} not found, or the Repository is not configured. "
                    f"Note: Tableau Cloud servers do not have a PostgreSQL repository."
                ) from exc
            if status == 401:
                raise RuntimeError(
                    "Repository credentials request failed (HTTP 401): "
                    "authentication token is invalid or expired."
                ) from exc
            msg = f"Repository credentials request failed (HTTP {status or '?'})"
            if detail:
                msg += f": {detail}"
            raise RuntimeError(msg) from exc

        data = resp.json()
        logger.debug("Acquired Repository credentials for server %s", server_id)
        try:
            return RepositoryCredentials(
                host=data["host"].strip(),
                port=data["port"],
                database=data["database"].strip(),
                username=data["username"].strip(),
                password=data["password"].strip(),
            )
        except KeyError as exc:
            raise ValueError(
                f"Unexpected repository-credentials response format: missing key {exc}"
            ) from exc

    def close(self) -> None:
        """Close the underlying HTTP session and release resources.

        Safe to call multiple times.  When using :class:`~mft.MFT`, this
        is called automatically -- you only need to call it when managing
        a ``TMClient`` instance directly.
        """
        self._session.close()
