from __future__ import annotations


class Errors:

    class WorkflowTaskParameterError(Exception):
        def __init__(self, id: str, message: str):
            self.id = id
            self.message = message
            super().__init__(f"[{id}] {message}")
