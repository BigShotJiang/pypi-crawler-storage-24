from __future__ import annotations

import re
from enum import Enum

ID_PATTERN = re.compile(r"^[a-zA-Z][a-zA-Z\d_]*$")


class ParameterType(Enum):
    String = 0
    Integer = 1
    Double = 2
    Boolean = 3
    Date = 4
    DateTime = 5
    TimeSpan = 6
    Guid = 7
    Enum = 8
    Binary = 9
    Object = 10


class ParameterInfoDTO:
    def __init__(
        self,
        id: str,
        display_name: str,
        description: str | None = None,
        required: bool = False,
        parameter_type: ParameterType | None = None,
        is_list: bool | None = None,
        enum_values: list[str] | None = None,
        object_properties: list[ParameterInfoDTO] | None = None,
    ):
        if not id:
            raise ValueError("Id is required.")
        if not display_name:
            raise ValueError("Display name is required.")
        if parameter_type is None:
            raise ValueError("Parameter type is required.")
        if is_list is None:
            raise ValueError("Is List is required.")
        if not ID_PATTERN.match(id):
            raise ValueError(
                "Must be a valid JSON property name. A-Z, a-z, _ and numbers are supported. "
                "Cannot start with a number or _."
            )

        self.id = id
        self.display_name = display_name
        self.description = description
        self.required = required
        self.parameter_type = parameter_type
        self.is_list = is_list
        self.enum_values = enum_values
        self.object_properties = object_properties
