"""Validate input JSON data against task metadata parameter definitions.

Checks that every declared parameter has the correct type, format, and
presence before the data reaches the C# JsonConverter or the binary I/O
layer.  Catches common developer mistakes early with clear, actionable
error messages.

Typical usage::

    from mft._meta import load_task_meta
    from mft._validate_input import validate_input

    meta = load_task_meta()
    result = validate_input(data, meta.inputs)

    if not result.is_valid:
        for error in result.errors:
            print(f"  ERROR: {error}")
        for warning in result.warnings:
            print(f"  WARNING: {warning}")
"""

from __future__ import annotations

import base64
import re
import uuid
from dataclasses import dataclass, field
from datetime import date, datetime
from typing import Any

from mft.models.parameter_info import ParameterInfo
from mft.parameterfile.parameter_info_dto import ParameterType

# Patterns for string-encoded types
_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
_DATETIME_RE = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}")
_TIMESPAN_RE = re.compile(r"^(\d+\.)?\d{2}:\d{2}:\d{2}$")


@dataclass
class ValidationResult:
    """Outcome of validating input data against parameter definitions.

    Attributes
    ----------
    errors:
        Fatal problems that will cause the converter or binary layer to
        fail.  Each string is a human-readable message prefixed with the
        dot-separated parameter path.
    warnings:
        Non-fatal issues the developer should be aware of (e.g. unknown
        keys in the input data).
    """

    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def is_valid(self) -> bool:
        """``True`` when there are no errors."""
        return len(self.errors) == 0


def validate_input(
    data: dict[str, Any],
    params: list[ParameterInfo],
) -> ValidationResult:
    """Validate *data* against *params* and return a :class:`ValidationResult`.

    Performs the following checks:

    1. Warns on unknown top-level keys not declared in *params*.
    2. For each declared parameter, validates presence (if required),
       type correctness, format (dates, GUIDs, etc.), and recursively
       validates nested objects.

    Parameters
    ----------
    data:
        The parsed JSON input dictionary.
    params:
        The input parameter definitions from ``task-meta.json``.

    Returns
    -------
    ValidationResult
        Aggregated errors and warnings.
    """
    result = ValidationResult()
    declared_ids = {p.id for p in params}

    for key in data:
        if key not in declared_ids:
            result.warnings.append(
                f"{key}: unknown parameter (not declared in task-meta.json)"
            )

    for param in params:
        _validate_param(data, param, "", result)

    return result


def _validate_param(
    data: dict[str, Any],
    param: ParameterInfo,
    parent_path: str,
    result: ValidationResult,
) -> None:
    """Validate a single parameter within *data*."""
    path = f"{parent_path}.{param.id}" if parent_path else param.id

    if param.id not in data or data[param.id] is None:
        if param.required:
            result.errors.append(f"{path}: required parameter is missing")
        return

    value = data[param.id]

    if param.is_list:
        if not isinstance(value, list):
            result.errors.append(
                f"{path}: expected a list, got {type(value).__name__}"
            )
            return
        for i, item in enumerate(value):
            _validate_value(item, param, f"{path}[{i}]", result)
    else:
        _validate_value(value, param, path, result)


def _validate_value(
    value: Any,
    param: ParameterInfo,
    path: str,
    result: ValidationResult,
) -> None:
    """Validate a single value against *param*'s type definition."""
    # Check for leftover TODO markers on any string value
    if isinstance(value, str) and value.startswith("TODO:"):
        result.errors.append(
            f"{path}: contains a TODO marker that must be replaced"
        )
        return

    ptype = param.type

    if ptype == ParameterType.String:
        _validate_string(value, param, path, result)
    elif ptype == ParameterType.Integer:
        _validate_integer(value, path, result)
    elif ptype == ParameterType.Double:
        _validate_double(value, path, result)
    elif ptype == ParameterType.Boolean:
        _validate_boolean(value, path, result)
    elif ptype == ParameterType.Date:
        _validate_date(value, path, result)
    elif ptype == ParameterType.DateTime:
        _validate_datetime(value, path, result)
    elif ptype == ParameterType.TimeSpan:
        _validate_timespan(value, path, result)
    elif ptype == ParameterType.Guid:
        _validate_guid(value, path, result)
    elif ptype == ParameterType.Enum:
        _validate_enum(value, param, path, result)
    elif ptype == ParameterType.Binary:
        _validate_binary(value, path, result)
    elif ptype == ParameterType.Object:
        _validate_object(value, param, path, result)


# ---------------------------------------------------------------------------
# Per-type validators
# ---------------------------------------------------------------------------


def _validate_string(
    value: Any,
    param: ParameterInfo,
    path: str,
    result: ValidationResult,
) -> None:
    if not isinstance(value, str):
        result.errors.append(
            f"{path}: expected a string, got {type(value).__name__}"
        )
        return
    if param.required and value == "":
        result.errors.append(
            f"{path}: required string cannot be empty"
        )


def _validate_integer(value: Any, path: str, result: ValidationResult) -> None:
    # bool is a subclass of int in Python — reject it explicitly
    if isinstance(value, bool) or not isinstance(value, int):
        result.errors.append(
            f"{path}: expected an integer, got {type(value).__name__}"
        )


def _validate_double(value: Any, path: str, result: ValidationResult) -> None:
    if isinstance(value, bool):
        result.errors.append(
            f"{path}: expected a number, got bool"
        )
        return
    if not isinstance(value, (int, float)):
        result.errors.append(
            f"{path}: expected a number, got {type(value).__name__}"
        )


def _validate_boolean(value: Any, path: str, result: ValidationResult) -> None:
    if not isinstance(value, bool):
        result.errors.append(
            f"{path}: expected a boolean, got {type(value).__name__}"
        )


def _validate_date(value: Any, path: str, result: ValidationResult) -> None:
    if not isinstance(value, str):
        result.errors.append(
            f"{path}: expected a date string, got {type(value).__name__}"
        )
        return
    if not _DATE_RE.match(value):
        result.errors.append(
            f"{path}: invalid date format, expected YYYY-MM-DD (got {value!r})"
        )
        return
    try:
        date.fromisoformat(value)
    except ValueError:
        result.errors.append(
            f"{path}: invalid date value (got {value!r})"
        )


def _validate_datetime(value: Any, path: str, result: ValidationResult) -> None:
    if not isinstance(value, str):
        result.errors.append(
            f"{path}: expected a datetime string, got {type(value).__name__}"
        )
        return
    if not _DATETIME_RE.match(value):
        result.errors.append(
            f"{path}: invalid datetime format, expected YYYY-MM-DDTHH:MM:SS (got {value!r})"
        )
        return
    try:
        datetime.fromisoformat(value)
    except ValueError:
        result.errors.append(
            f"{path}: invalid datetime value (got {value!r})"
        )


def _validate_timespan(value: Any, path: str, result: ValidationResult) -> None:
    if not isinstance(value, str):
        result.errors.append(
            f"{path}: expected a timespan string, got {type(value).__name__}"
        )
        return
    if not _TIMESPAN_RE.match(value):
        result.errors.append(
            f"{path}: invalid timespan format, expected HH:MM:SS or d.HH:MM:SS (got {value!r})"
        )


def _validate_guid(value: Any, path: str, result: ValidationResult) -> None:
    if not isinstance(value, str):
        result.errors.append(
            f"{path}: expected a GUID string, got {type(value).__name__}"
        )
        return
    try:
        uuid.UUID(value)
    except ValueError:
        result.errors.append(
            f"{path}: invalid GUID format (got {value!r})"
        )


def _validate_enum(
    value: Any,
    param: ParameterInfo,
    path: str,
    result: ValidationResult,
) -> None:
    if not isinstance(value, str):
        result.errors.append(
            f"{path}: expected a string, got {type(value).__name__}"
        )
        return
    if param.enum_values and value not in param.enum_values:
        result.errors.append(
            f"{path}: invalid enum value {value!r}, "
            f"allowed values: {', '.join(param.enum_values)}"
        )


def _validate_binary(value: Any, path: str, result: ValidationResult) -> None:
    if not isinstance(value, str):
        result.errors.append(
            f"{path}: expected a base64 string, got {type(value).__name__}"
        )
        return
    try:
        base64.b64decode(value, validate=True)
    except Exception:
        result.errors.append(
            f"{path}: invalid base64 encoding"
        )


def _validate_object(
    value: Any,
    param: ParameterInfo,
    path: str,
    result: ValidationResult,
) -> None:
    if not isinstance(value, dict):
        result.errors.append(
            f"{path}: expected an object, got {type(value).__name__}"
        )
        return

    if not param.object_properties:
        return

    declared_ids = {p.id for p in param.object_properties}
    for key in value:
        if key not in declared_ids:
            result.warnings.append(
                f"{path}.{key}: unknown property (not declared in object_properties)"
            )

    for prop in param.object_properties:
        _validate_param(value, prop, path, result)
