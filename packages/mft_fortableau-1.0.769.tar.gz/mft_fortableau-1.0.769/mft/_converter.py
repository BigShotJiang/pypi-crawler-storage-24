from __future__ import annotations

import base64
import json
import subprocess
import tempfile
from pathlib import Path
from typing import ClassVar

from mft.models.parameter_info import ParameterInfo


class ConverterError(RuntimeError):
    """Raised when the JsonConverter process exits with a non-zero return code."""

    def __init__(self, stderr: str, returncode: int) -> None:
        self.stderr = stderr
        self.returncode = returncode
        super().__init__(f"Converter failed (exit code {returncode}): {stderr}")


class Converter:
    """Python wrapper around the pre-built C# JsonConverter CLI executable.

    The converter translates between JSON and binary ParameterFile format.

    CLI invocation::

        ./converter <MODE> <PARAM_DEFINITION> <SOURCE_FILE> <TARGET_FILE>

    Where MODE is ``"ParameterFile"`` (JSON -> binary) or ``"JSON"`` (binary -> JSON),
    and PARAM_DEFINITION is either a base64-encoded JSON string or a file path
    (auto-detected by the C# side via ``File.Exists()``).
    """

    DEFAULT_PATH: ClassVar[Path] = (
        Path(__file__).parent
        / "bin"
        / "JsonConverter"
        / "linux"
        / "Services.Workflows.ParameterFile.JsonConverter"
    )

    def __init__(self, converter_path: str | Path | None = None) -> None:
        if converter_path is None:
            self._path = self.DEFAULT_PATH
        else:
            self._path = Path(converter_path)

        if not self._path.exists():
            raise FileNotFoundError(
                f"Converter binary not found at {self._path}"
            )

    @staticmethod
    def _prepare_meta_arg(
        parameters: list[ParameterInfo],
        *,
        use_base64: bool,
    ) -> str | tuple[str, Path]:
        """Serialize parameter definitions for the converter CLI.

        When *use_base64* is ``True`` (the default), returns a base64-encoded
        JSON string that can be passed directly as the PARAM_DEFINITION argument.

        When *use_base64* is ``False``, writes the JSON to a temporary file and
        returns a ``(path_string, Path)`` tuple so the caller can clean up after.
        """
        json_list = [p.to_json_dict() for p in parameters]
        json_str = json.dumps(json_list)

        if use_base64:
            return base64.b64encode(json_str.encode()).decode()

        tmp = tempfile.NamedTemporaryFile(
            mode="w", suffix=".json", delete=False
        )
        tmp.write(json_str)
        tmp.close()
        return tmp.name, Path(tmp.name)

    def _run(
        self,
        mode: str,
        meta_arg: str,
        input_path: str | Path,
        output_path: str | Path,
    ) -> None:
        """Execute the converter binary with the given arguments."""
        result = subprocess.run(
            [str(self._path), mode, meta_arg, str(input_path), str(output_path)],
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            raise ConverterError(
                stderr=result.stderr.strip(),
                returncode=result.returncode,
            )

    def json_to_parameter_file(
        self,
        parameters: list[ParameterInfo],
        json_input_path: str | Path,
        binary_output_path: str | Path,
        *,
        use_base64_meta: bool = True,
    ) -> None:
        """Convert a JSON file to binary ParameterFile format."""
        meta = self._prepare_meta_arg(parameters, use_base64=use_base64_meta)

        if use_base64_meta:
            self._run("ParameterFile", meta, json_input_path, binary_output_path)
        else:
            meta_path_str, meta_path = meta
            try:
                self._run("ParameterFile", meta_path_str, json_input_path, binary_output_path)
            finally:
                meta_path.unlink(missing_ok=True)

    def parameter_file_to_json(
        self,
        parameters: list[ParameterInfo],
        binary_input_path: str | Path,
        json_output_path: str | Path,
        *,
        use_base64_meta: bool = True,
    ) -> None:
        """Convert a binary ParameterFile to JSON format."""
        meta = self._prepare_meta_arg(parameters, use_base64=use_base64_meta)

        if use_base64_meta:
            self._run("JSON", meta, binary_input_path, json_output_path)
        else:
            meta_path_str, meta_path = meta
            try:
                self._run("JSON", meta_path_str, binary_input_path, json_output_path)
            finally:
                meta_path.unlink(missing_ok=True)
