from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from mft._tm_client import TableauApiCredentials

logger = logging.getLogger(__name__)

try:
    import tableauserverclient as TSC
except ImportError:
    TSC = None  # type: ignore[assignment]

if TYPE_CHECKING:
    from tableauserverclient import Server as _TSCServer


class TableauApi:
    """Pre-authenticated client for the Tableau Server REST API.

    Wraps ``tableauserverclient`` (TSC) so that custom tasks can query
    workbooks, projects, users, and any other Tableau resource without
    managing authentication themselves.

    The session is managed by MFT -- :meth:`connect` and :meth:`disconnect`
    are called automatically.  Custom-task code only needs the
    :attr:`server` property.

    Example::

        mft = MFT.init()
        workbooks, pagination = mft.tableau_api.server.workbooks.get()
        for wb in workbooks:
            print(wb.name)

    Tip: access via ``mft.tableau_api.server`` -- see the
    `tableauserverclient documentation
    <https://tableau.github.io/server-client-python/docs/>`_
    for available operations.

    Note: requires ``"RestApi"`` in the ``uses`` list of your
    ``task-meta.json``.
    """

    def __init__(self, credentials: TableauApiCredentials) -> None:
        self._credentials = credentials
        self._server: _TSCServer | None = None

    def connect(self) -> TableauApi:
        """Sign in to Tableau Server and return *self* for chaining.

        Authentication uses a Personal Access Token (PAT) scoped to the
        configured Tableau site.  The PAT name, secret, and site content
        URL are provided by the MFT backend at task startup -- custom
        tasks do not need to supply credentials.

        Raises
        ------
        ImportError
            If ``tableauserverclient`` is not installed.
        """
        if TSC is None:
            raise ImportError(
                "tableauserverclient is required for TableauApi. "
                "Install it with: pip install tableauserverclient"
            )

        self._server = TSC.Server(
            self._credentials.server_url, use_server_version=True,
        )
        auth = TSC.PersonalAccessTokenAuth(
            self._credentials.token_name,
            personal_access_token=self._credentials.token_secret,
            site_id=self._credentials.site_content_url,
        )
        self._server.auth.sign_in(auth)
        logger.debug("Connected to Tableau Server at %s", self._credentials.server_url)
        return self

    # -- query helpers --------------------------------------------------------

    def _ensure_connected(self) -> _TSCServer:
        """Return the active server or raise if not connected."""
        if self._server is None:
            raise RuntimeError(
                "TableauApi is not connected. Call connect() first."
            )
        return self._server

    @property
    def server(self) -> _TSCServer:
        """The underlying ``TSC.Server`` instance, ready to use.

        When accessed via ``mft.tableau_api.server`` the session is
        always authenticated, so you can call any TSC endpoint directly::

            # List all workbooks
            workbooks, _ = mft.tableau_api.server.workbooks.get()

            # Fetch a single project by ID
            project = mft.tableau_api.server.projects.get_by_id(project_id)

        Raises
        ------
        RuntimeError
            If the ``TableauApi`` has not been connected yet.
        """
        return self._ensure_connected()

    def disconnect(self) -> None:
        """Sign out from Tableau Server."""
        if self._server is not None:
            self._server.auth.sign_out()
            self._server = None
            logger.debug("Disconnected from Tableau Server")
