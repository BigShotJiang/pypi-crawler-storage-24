from __future__ import annotations

from pathlib import Path

import chardet


def detect_encoding(file_path: Path) -> str:
    """Best-effort encoding detection based on file header bytes."""

    with file_path.open("rb") as file_handle:
        raw = file_handle.read(4096)
    result = chardet.detect(raw)
    return result["encoding"] or "utf-8"


def count_physical_lines(file_path: Path, encoding: str | None = None) -> int:
    """Count physical lines in a text file using a detected or provided encoding."""

    file_encoding = encoding or detect_encoding(file_path)
    with file_path.open("r", encoding=file_encoding, errors="replace") as file_handle:
        return sum(1 for _ in file_handle)
