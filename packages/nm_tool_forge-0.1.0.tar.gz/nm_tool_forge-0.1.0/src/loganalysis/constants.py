from __future__ import annotations

import re

DEFAULT_LOGS_DIR = "logs"
DEFAULT_OUT_DIR = "log_analyse_out"
DEFAULT_TOP_EXAMPLES = 3
DEFAULT_REPORT_TITLE = "Log Analysis Report"
REPORT_TOP_PER_FILE = 20
REPORT_TOP_GLOBAL = 50

EXIT_SUCCESS = 0
EXIT_NO_LOG_FILES = 2

SEVERITY_ALIASES = {
    "INFO": "INFO",
    "INFORMATION": "INFO",
    "I": "INFO",
    "ERROR": "ERROR",
    "ERR": "ERROR",
    "E": "ERROR",
    "WARNING": "WARNING",
    "WARN": "WARNING",
    "W": "WARNING",
}

RE_GUID = re.compile(r"\b[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}\b")
RE_INT = re.compile(r"\b\d+\b")
RE_WHITESPACE = re.compile(r"\s+")
RE_WINDOWS_PATH = re.compile(r"\b[a-zA-Z]:\\[^;\n\r,]*")
RE_UNIX_PATH = re.compile(r"(?<![A-Za-z0-9])(?:/[^/;\s,:]+){2,}")
RE_ENTRY_START = re.compile(
    r"^\s*(?P<severity>Info|Information|I|Error|Err|E|Warning|Warn|W)\b(?:\s*[;,]|\t)",
    re.IGNORECASE,
)
RE_LINE_PREFIX = re.compile(r"^\s*Line\s+\d+\s*:\s*", re.IGNORECASE)
RE_TRAILING_DATASET = re.compile(r"\s*;(?:[^\n;]*;){2,}[^\n;]*\s*$")
RE_SEMANTIC_VALUE_CHAR = re.compile(r"[0-9A-Za-zÄÖÜäöüß]")
RE_LOOKUP_ASSIGNMENT = re.compile(
    r'(?P<head>\b(?:Mandatory Field Invalid|Conversion)\b.*?=)'
    r'(?P<value>.*?)'
    r'\s*[.,;:]*\s*(?:\d+\s+)?'
    r'The record was not found in table\s+"(?P<table>[^"]+)"\.?',
    re.IGNORECASE,
)
RE_VALIDATE_QUOTED_KEY = re.compile(
    r"(?P<head>\bValidate\b.*?\{[^}]+\}\s*')"
    r"(?P<value>[^']*)"
    r"(?P<tail>':)",
    re.IGNORECASE,
)
RE_QUOTED_VALUE = re.compile(r"\s*'[^']*'\s*")
RE_MARKDOWN_TABLE_SEPARATOR = re.compile(r"^\s*\|?(?:\s*:?-+:?\s*\|)+\s*$")
RE_HTML_BREAK = re.compile(r"<br\s*/?>", re.IGNORECASE)
RE_INLINE_CODE_SPAN = re.compile(r"(`[^`]*`)")
RE_LEADING_TIMESTAMP_PLACEHOLDER = re.compile(r"^\s*<N>\.<N>\.<N>/<N>:<N>:<N>\s*(?:-\s*)?")

LATEX_SPECIAL_CHAR_REPLACEMENTS = {
    "\\": r"\textbackslash{}",
    "{": r"\{",
    "}": r"\}",
    "_": r"\_",
    "%": r"\%",
    "&": r"\&",
    "#": r"\#",
    "$": r"\$",
    "~": r"\textasciitilde{}",
    "^": r"\textasciicircum{}",
}
LATEX_PDF_ENGINES = {"xelatex", "pdflatex"}
COMMON_MOJIBAKE_TOKENS = ("ÔÇ£", "ÔÇ¥", "â€“", "â€”", "â€ž", "â€œ", "â€")

NORMALIZATION_SELF_TEST_CASES: tuple[tuple[str, str], ...] = (
    (
        'Mandatory Field Invalid: X =. The record was not found in table "Teile".',
        'Mandatory Field Invalid: X =<EMPTY> The record was not found in table "Teile".',
    ),
    (
        'Mandatory Field Invalid: X =., The record was not found in table "Teile".',
        'Mandatory Field Invalid: X =<EMPTY> The record was not found in table "Teile".',
    ),
    (
        'Mandatory Field Invalid: X = ; The record was not found in table "Teile".',
        'Mandatory Field Invalid: X =<EMPTY> The record was not found in table "Teile".',
    ),
    (
        'Mandatory Field Invalid: X =3000613.40 138 The record was not found in table "Teile".',
        'Mandatory Field Invalid: X =<VALUE> The record was not found in table "Teile".',
    ),
    (
        'Conversion: X =3100110. 138 The record was not found in table "Teile".',
        'Conversion: X =<VALUE> The record was not found in table "Teile".',
    ),
    (
        "Validate gbS_EAN: s_trg00021 {Teil} '7006563.1,6RS':",
        "Validate gbS_EAN: s_trg00021 {Teil} '<VALUE>':",
    ),
    (
        "Validate gbS_EAN: s_trg00021 {Teil} '., ':",
        "Validate gbS_EAN: s_trg00021 {Teil} '<EMPTY>':",
    ),
    (
        "See /var/log/app/output.txt for details",
        "See <PATH> for details",
    ),
    (
        "Error x40 exclusion criteria: s_art00002 {Teil} '.': {Der Datensatz ist nicht angelegt.}",
        "Error x40 exclusion criteria: s_art00002 {Teil}: {Der Datensatz ist nicht angelegt.}",
    ),
    (
        "Error x40 exclusion criteria: s_art00002 {Teil} '.,': {Der Datensatz ist nicht angelegt.}",
        "Error x40 exclusion criteria: s_art00002 {Teil}: {Der Datensatz ist nicht angelegt.}",
    ),
    (
        "Error x40 exclusion criteria: s_art00002 {Teil} '2053052.35': {Der Datensatz ist nicht angelegt.}",
        "Error x40 exclusion criteria: s_art00002 {Teil}: {Der Datensatz ist nicht angelegt.}",
    ),
    (
        "Error x40 exclusion criteria: s_art00002 {Teil} '179020.6,3': {Der Datensatz ist nicht angelegt.}",
        "Error x40 exclusion criteria: s_art00002 {Teil}: {Der Datensatz ist nicht angelegt.}",
    ),
    (
        "Error x40 exclusion criteria: s_art00002 {Teil} '9008001.': {Der Datensatz ist nicht angelegt.}",
        "Error x40 exclusion criteria: s_art00002 {Teil}: {Der Datensatz ist nicht angelegt.}",
    ),
)
