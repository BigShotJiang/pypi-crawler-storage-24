from __future__ import annotations

import re

from .constants import (
    RE_GUID,
    RE_INT,
    RE_LOOKUP_ASSIGNMENT,
    RE_QUOTED_VALUE,
    RE_SEMANTIC_VALUE_CHAR,
    RE_UNIX_PATH,
    RE_VALIDATE_QUOTED_KEY,
    RE_WHITESPACE,
    RE_WINDOWS_PATH,
)


def classify_value_fragment(value: str) -> str:
    """Classify a matched value fragment as meaningful or empty."""

    stripped = (value or "").strip()
    if not stripped:
        return "<EMPTY>"
    if not RE_SEMANTIC_VALUE_CHAR.search(stripped):
        return "<EMPTY>"
    return "<VALUE>"


def normalize_lookup_assignment_message(message: str) -> str:
    """Normalize value-bearing lookup error messages."""

    def replace(match: re.Match[str]) -> str:
        value_token = classify_value_fragment(match.group("value"))
        table_name = match.group("table")
        return f'{match.group("head")}{value_token} The record was not found in table "{table_name}".'

    return RE_LOOKUP_ASSIGNMENT.sub(replace, message)


def normalize_validate_key_message(message: str) -> str:
    """Normalize Validate... {Key} 'value' style messages."""

    def replace(match: re.Match[str]) -> str:
        value_token = classify_value_fragment(match.group("value"))
        return f'{match.group("head")}{value_token}{match.group("tail")}'

    return RE_VALIDATE_QUOTED_KEY.sub(replace, message)


def semantic_normalize_message(message: str) -> str:
    """Apply semantic normalization rules before generic token normalization."""

    normalized = message.strip()
    normalized = normalize_lookup_assignment_message(normalized)
    normalized = normalize_validate_key_message(normalized)
    return normalized


def normalize_generic_quoted_values(message: str) -> str:
    """Remove quoted values that are no longer semantically relevant."""

    def replace(match: re.Match[str]) -> str:
        matched = match.group(0).strip()
        inner = matched[1:-1] if len(matched) >= 2 else ""
        if inner in {"<VALUE>", "<EMPTY>"}:
            return match.group(0)
        return ""

    return RE_QUOTED_VALUE.sub(replace, message)


def cleanup_normalized_message(message: str) -> str:
    """Tidy whitespace and punctuation artifacts after normalization."""

    normalized = RE_WHITESPACE.sub(" ", message).strip()
    normalized = re.sub(r"\s+:", ":", normalized)
    normalized = re.sub(r"\s+,", ",", normalized)
    normalized = re.sub(r"\s+\.", ".", normalized)
    normalized = re.sub(r"\s+;", ";", normalized)
    normalized = re.sub(r"\s+\)", ")", normalized)
    normalized = re.sub(r"\(\s+", "(", normalized)
    normalized = re.sub(r"\s{2,}", " ", normalized)
    return normalized.strip()


def normalize_message(message: str) -> str:
    """Normalize a log message for aggregation."""

    normalized = message.strip()
    normalized = semantic_normalize_message(normalized)
    normalized = RE_GUID.sub("<GUID>", normalized)
    normalized = RE_WINDOWS_PATH.sub("<PATH>", normalized)
    normalized = RE_UNIX_PATH.sub("<PATH>", normalized)
    normalized = normalize_generic_quoted_values(normalized)
    normalized = RE_INT.sub("<N>", normalized)
    normalized = cleanup_normalized_message(normalized)
    return normalized if normalized else "(no message)"
