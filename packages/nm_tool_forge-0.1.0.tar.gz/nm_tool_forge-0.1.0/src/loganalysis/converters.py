from __future__ import annotations

import subprocess
import tempfile
from pathlib import Path

from .filesystem import ensure_dir
from .report_html import render_report_html_document, resolve_report_date
from .report_markdown import parse_report_markdown
from .report_pdf import build_pdf_safe_markdown, contains_common_mojibake, select_pdf_engine


def convert_report_md_to_html_pdf(md_path: Path, html_path: Path, pdf_path: Path) -> dict[str, object]:
    """Convert the generated markdown report to HTML and optionally to PDF."""

    status: dict[str, object] = {
        "html_created": False,
        "pdf_created": False,
        "pdf_reason": None,
        "pdf_engine": None,
    }

    try:
        ensure_dir(html_path.parent)
        ensure_dir(pdf_path.parent)

        markdown = md_path.read_text(encoding="utf-8")
        report = parse_report_markdown(markdown)
        report_date = resolve_report_date(report, md_path)
        html_document = render_report_html_document(report, md_path.name, report_date)
        html_path.write_text(html_document, encoding="utf-8")
    except Exception as exc:
        print(f"[ERROR] HTML generation failed: {exc}")
        status["pdf_reason"] = "html_failed"
        return status

    html_created = html_path.exists() and html_path.stat().st_size > 0
    status["html_created"] = html_created
    if not html_created:
        print("[ERROR] HTML generation failed: HTML file was not created.")
        status["pdf_reason"] = "html_failed"
        return status

    pdf_engine = select_pdf_engine()
    if pdf_engine is None:
        print("[WARN] No supported PDF engine found. HTML was generated, PDF skipped.")
        status["pdf_reason"] = "no_pdf_engine"
        return status

    status["pdf_engine"] = pdf_engine

    pdf_source_path = md_path
    temp_md_path: Path | None = None
    temp_pdf_path: Path | None = None

    try:
        with tempfile.NamedTemporaryFile(
            prefix=f"{pdf_path.stem}.",
            suffix=pdf_path.suffix,
            dir=str(pdf_path.parent),
            delete=False,
        ) as handle:
            temp_pdf_path = Path(handle.name)

        if pdf_engine == "weasyprint":
            from weasyprint import HTML

            HTML(filename=str(html_path), base_url=str(html_path.parent)).write_pdf(str(temp_pdf_path))
        elif pdf_engine == "wkhtmltopdf":
            import shutil

            wkhtmltopdf_path = shutil.which("wkhtmltopdf")
            if wkhtmltopdf_path is None:
                print("[WARN] wkhtmltopdf is not available anymore. PDF skipped.")
                status["pdf_reason"] = "no_pdf_engine"
                return status

            subprocess.run(
                [
                    wkhtmltopdf_path,
                    "--enable-local-file-access",
                    "--page-size",
                    "A4",
                    "--orientation",
                    "Portrait",
                    str(html_path),
                    str(temp_pdf_path),
                ],
                check=True,
            )
        else:
            import shutil

            pandoc_path = shutil.which("pandoc")
            if pandoc_path is None:
                print("[WARN] pandoc is not installed or not in PATH. HTML generated, PDF skipped.")
                status["pdf_reason"] = "pandoc_missing"
                return status

            pdf_safe_markdown = build_pdf_safe_markdown(markdown)
            if pdf_safe_markdown != markdown:
                with tempfile.NamedTemporaryFile(
                    prefix=f"{md_path.stem}.pdfsafe.",
                    suffix=md_path.suffix,
                    dir=str(md_path.parent),
                    mode="w",
                    encoding="utf-8",
                    newline="\n",
                    delete=False,
                ) as handle:
                    handle.write(pdf_safe_markdown)
                    pdf_source_path = temp_md_path = Path(handle.name)

            if contains_common_mojibake(markdown):
                print(
                    "[WARN] Report contains suspicious mojibake sequences. PDF escaping was applied, "
                    "but the source encoding should still be checked."
                )

            subprocess.run(
                [
                    pandoc_path,
                    str(pdf_source_path),
                    "-o",
                    str(temp_pdf_path),
                    "--from",
                    "markdown",
                    f"--pdf-engine={pdf_engine}",
                ],
                check=True,
            )

        if temp_pdf_path.exists() and temp_pdf_path.stat().st_size > 0:
            temp_pdf_path.replace(pdf_path)
            status["pdf_created"] = True
            status["pdf_reason"] = None
            print(f"PDF generated via {pdf_engine}: {pdf_path}")
        else:
            print("[ERROR] PDF generation finished without creating a PDF file.")
            status["pdf_reason"] = "pdf_not_created"
    except Exception as exc:
        print(f"[ERROR] PDF generation failed via {pdf_engine}: {exc}")
        status["pdf_reason"] = "pdf_failed"
    finally:
        if temp_pdf_path and temp_pdf_path.exists():
            temp_pdf_path.unlink()
        if temp_md_path and temp_md_path.exists():
            temp_md_path.unlink()

    return status
