from __future__ import annotations

from pathlib import Path
from typing import Iterable

from .constants import RE_ENTRY_START, RE_LINE_PREFIX, RE_TRAILING_DATASET, RE_WHITESPACE, SEVERITY_ALIASES
from .encoding import detect_encoding
from .models import ParsedLine


def canonical_severity(raw: str) -> str:
    """Map a raw severity token to the canonical output severity."""

    severity = (raw or "").strip().upper()
    return SEVERITY_ALIASES.get(severity, severity if severity else "UNKNOWN")


def is_entry_start(line: str) -> bool:
    """Return whether a physical line starts a new logical log entry."""

    return bool(RE_ENTRY_START.match(line))


def iter_logical_entries(file_path: Path, encoding: str | None = None) -> Iterable[str]:
    """Yield logical log entries assembled from one or more physical lines."""

    current_lines: list[str] = []
    file_encoding = encoding or detect_encoding(file_path)

    with file_path.open("r", encoding=file_encoding, errors="replace") as file_handle:
        for line in file_handle:
            if is_entry_start(line):
                if current_lines:
                    yield "".join(current_lines)
                current_lines = [line]
                continue

            if current_lines:
                current_lines.append(line)

    if current_lines:
        yield "".join(current_lines)


def parse_entry(entry: str) -> ParsedLine | None:
    """Parse one logical entry into severity and normalized message text."""

    stripped = entry.strip()
    if not stripped:
        return None

    match = RE_ENTRY_START.match(stripped)
    if not match:
        message = RE_WHITESPACE.sub(" ", stripped).strip()
        return ParsedLine(severity="UNKNOWN", message=message or "(no message)")

    severity = canonical_severity(match.group("severity") or "")
    message = stripped[match.end():].strip()
    message = RE_LINE_PREFIX.sub("", message, count=1)
    message = RE_WHITESPACE.sub(" ", message).strip()
    message = RE_TRAILING_DATASET.sub("", message).strip()
    message = RE_WHITESPACE.sub(" ", message).strip()
    return ParsedLine(severity=severity, message=message or "(no message)")


def parse_line(line: str) -> ParsedLine | None:
    """Backward-compatible alias for parsing a logical entry."""

    return parse_entry(line)
