from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ReportTable:
    """Structured representation of a markdown report table."""

    headers: tuple[str, ...]
    rows: tuple[tuple[str, ...], ...]


@dataclass(frozen=True)
class ReportSection:
    """Logical report section used by markdown and HTML renderers."""

    title: str
    metadata: tuple[tuple[str, str], ...]
    subtitle: str | None
    table: ReportTable | None
    note: str | None


@dataclass(frozen=True)
class ReportDocument:
    """Top-level report document model."""

    title: str
    metadata: tuple[tuple[str, str], ...]
    sections: tuple[ReportSection, ...]
