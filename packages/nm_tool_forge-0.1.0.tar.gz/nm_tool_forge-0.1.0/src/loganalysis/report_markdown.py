from __future__ import annotations

import datetime as dt
from collections import Counter

from .constants import DEFAULT_REPORT_TITLE, RE_MARKDOWN_TABLE_SEPARATOR, REPORT_TOP_GLOBAL, REPORT_TOP_PER_FILE
from .models import AnalysisConfig, AnalysisSummary, MessageKey
from .report_models import ReportDocument, ReportSection, ReportTable


def _top_counter_items(counter: Counter[MessageKey], limit: int) -> list[tuple[MessageKey, int]]:
    return sorted(counter.items(), key=lambda item: (-item[1], item[0][0], item[0][1]))[:limit]


def build_markdown_report(
    summary: AnalysisSummary,
    config: AnalysisConfig,
    *,
    timestamp: dt.datetime | None = None,
) -> str:
    """Build the human-readable markdown report from aggregated analysis data."""

    report_time = timestamp or dt.datetime.now()
    backup_dir = config.backup_dir or (config.out_dir / "backup")

    lines: list[str] = [
        f"# {DEFAULT_REPORT_TITLE}",
        "",
        f"- Logs directory: `{config.logs_dir.resolve()}`",
        f"- Output directory: `{config.out_dir.resolve()}`",
        f"- Backup directory: `{backup_dir.resolve()}`",
        f"- Timestamp: {report_time.isoformat(timespec='seconds')}",
        "",
    ]

    for analysis in summary.analyses:
        lines.append(f"## File: {analysis.file.name}")
        lines.append("")
        if analysis.backup_path is not None:
            lines.append(f"- Backup: `{analysis.backup_path}`")
        lines.append(f"- Physical lines: {analysis.total_lines}")
        lines.append(f"- Logical entries: {analysis.total_entries}")
        lines.append(f"- UNKNOWN severity entries: {analysis.unknown_lines}")
        lines.append("")
        lines.append("### Top messages (normalized)")
        lines.append("")

        top_norm = _top_counter_items(analysis.norm_counts, REPORT_TOP_PER_FILE)
        if not top_norm:
            lines.append("_No messages found._")
            lines.append("")
            continue

        lines.append("| Severity | Count | Normalized message | Examples |")
        lines.append("|---|---:|---|---|")
        for (severity, normalized_message), count in top_norm:
            examples_counter = analysis.norm_examples[(severity, normalized_message)]
            examples = [f"{message} ({amount})" for message, amount in examples_counter.most_common(config.top_examples)]
            examples_text = "<br>".join(examples) if examples else ""
            lines.append(f"| {severity} | {count} | {normalized_message} | {examples_text} |")
        lines.append("")

    lines.append("## Overall summary (all files)")
    lines.append("")
    top_global = _top_counter_items(summary.global_norm, REPORT_TOP_GLOBAL)
    if top_global:
        lines.append("| Severity | Count | Normalized message | Examples |")
        lines.append("|---|---:|---|---|")
        for (severity, normalized_message), count in top_global:
            examples_counter = summary.global_norm_examples[(severity, normalized_message)]
            examples = [f"{message} ({amount})" for message, amount in examples_counter.most_common(config.top_examples)]
            examples_text = "<br>".join(examples) if examples else ""
            lines.append(f"| {severity} | {count} | {normalized_message} | {examples_text} |")
        lines.append("")
    else:
        lines.append("_No messages found._")
        lines.append("")

    return "\n".join(lines).strip() + "\n"


def parse_markdown_list_item(line: str) -> tuple[str, str] | None:
    """Parse one markdown bullet item from the generated report."""

    stripped = line.strip()
    if not stripped.startswith("- "):
        return None

    content = stripped[2:].strip()
    if ": " in content:
        label, value = content.split(": ", 1)
        return label.strip(), value.strip()
    return content, ""


def split_markdown_table_row(line: str) -> list[str] | None:
    """Split a pipe-separated markdown table row into cells."""

    stripped = line.strip()
    if not stripped.startswith("|") or not stripped.endswith("|"):
        return None
    return [cell.strip() for cell in stripped[1:-1].split("|")]


def parse_markdown_table(lines: list[str], start_index: int) -> tuple[ReportTable | None, int]:
    """Parse a markdown table starting at the given index."""

    if start_index + 1 >= len(lines):
        return None, start_index

    headers = split_markdown_table_row(lines[start_index])
    separator = lines[start_index + 1].strip()
    if not headers or not RE_MARKDOWN_TABLE_SEPARATOR.match(separator):
        return None, start_index

    rows: list[tuple[str, ...]] = []
    index = start_index + 2
    while index < len(lines):
        row = split_markdown_table_row(lines[index])
        if row is None:
            break
        rows.append(tuple(row))
        index += 1

    return ReportTable(headers=tuple(headers), rows=tuple(rows)), index


def parse_report_markdown(markdown: str) -> ReportDocument:
    """Parse a generated markdown report into a structured report document."""

    lines = markdown.splitlines()
    index = 0
    title = DEFAULT_REPORT_TITLE
    metadata: list[tuple[str, str]] = []
    sections: list[ReportSection] = []

    while index < len(lines) and not lines[index].strip():
        index += 1

    if index < len(lines) and lines[index].startswith("# "):
        title = lines[index][2:].strip() or title
        index += 1

    while index < len(lines) and not lines[index].strip():
        index += 1

    while index < len(lines):
        item = parse_markdown_list_item(lines[index])
        if item is None:
            break
        metadata.append(item)
        index += 1

    while index < len(lines):
        while index < len(lines) and not lines[index].strip():
            index += 1
        if index >= len(lines):
            break

        if not lines[index].startswith("## "):
            index += 1
            continue

        title_line = lines[index][3:].strip()
        index += 1

        while index < len(lines) and not lines[index].strip():
            index += 1

        section_metadata: list[tuple[str, str]] = []
        while index < len(lines):
            item = parse_markdown_list_item(lines[index])
            if item is None:
                break
            section_metadata.append(item)
            index += 1

        while index < len(lines) and not lines[index].strip():
            index += 1

        subtitle: str | None = None
        note: str | None = None
        table: ReportTable | None = None

        if index < len(lines) and lines[index].startswith("### "):
            subtitle = lines[index][4:].strip()
            index += 1

        while index < len(lines) and not lines[index].strip():
            index += 1

        if index < len(lines):
            if lines[index].startswith("|"):
                table, index = parse_markdown_table(lines, index)
            elif lines[index].startswith("_") and lines[index].endswith("_"):
                note = lines[index].strip().strip("_")
                index += 1

        sections.append(
            ReportSection(
                title=title_line,
                metadata=tuple(section_metadata),
                subtitle=subtitle,
                table=table,
                note=note,
            )
        )

    return ReportDocument(title=title, metadata=tuple(metadata), sections=tuple(sections))
