from __future__ import annotations

import csv
from pathlib import Path
from typing import Iterable

from .filesystem import ensure_dir


def write_csv(path: Path, rows: Iterable[tuple[str, str, int]], headers: list[str]) -> None:
    """Write semicolon-separated CSV output."""

    ensure_dir(path.parent)
    with path.open("w", encoding="utf-8", newline="") as file_handle:
        writer = csv.writer(file_handle, delimiter=";")
        writer.writerow(headers)
        for row in rows:
            writer.writerow(row)
