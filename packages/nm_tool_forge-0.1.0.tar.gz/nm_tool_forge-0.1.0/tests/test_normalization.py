from __future__ import annotations

import pytest

from loganalysis.constants import NORMALIZATION_SELF_TEST_CASES
from loganalysis.normalization import normalize_message


@pytest.mark.parametrize(("raw_message", "expected"), NORMALIZATION_SELF_TEST_CASES)
def test_normalize_message_matches_existing_cases(raw_message: str, expected: str) -> None:
    assert normalize_message(raw_message) == expected


@pytest.mark.parametrize(
    ("raw_message", "expected"),
    [
        ("Object 123 saved to C:\\temp\\foo.txt", "Object <N> saved to <PATH>"),
        ("GUID 12345678-1234-1234-1234-1234567890ab failed", "GUID <GUID> failed"),
        ("See /srv/app/output.log for details", "See <PATH> for details"),
    ],
)
def test_normalize_message_applies_generic_replacements(raw_message: str, expected: str) -> None:
    assert normalize_message(raw_message) == expected
