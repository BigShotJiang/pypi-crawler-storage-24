"""Tests for run_policy module — _collect_files."""

from __future__ import annotations

from pathlib import Path

from atomicguard.run_policy import _collect_files


class TestCollectFiles:
    """Tests for _collect_files with gym-driven patterns."""

    def test_single_file_returned_directly(self, tmp_path: Path):
        f = tmp_path / "main.py"
        f.write_text("x = 1\n")
        result = _collect_files(f, ("*.py",))
        assert result == [f]

    def test_single_file_ignores_patterns(self, tmp_path: Path):
        """A direct file path is returned even if it doesn't match patterns."""
        f = tmp_path / "main.go"
        f.write_text("package main\n")
        result = _collect_files(f, ("*.py",))
        assert result == [f]

    def test_directory_uses_patterns(self, tmp_path: Path):
        (tmp_path / "a.py").write_text("x = 1\n")
        (tmp_path / "b.py").write_text("y = 2\n")
        (tmp_path / "c.txt").write_text("not python\n")
        result = _collect_files(tmp_path, ("*.py",))
        assert len(result) == 2
        assert all(f.suffix == ".py" for f in result)

    def test_multiple_patterns(self, tmp_path: Path):
        (tmp_path / "a.py").write_text("x = 1\n")
        (tmp_path / "b.go").write_text("package main\n")
        (tmp_path / "c.txt").write_text("ignored\n")
        result = _collect_files(tmp_path, ("*.py", "*.go"))
        assert len(result) == 2
        names = {f.name for f in result}
        assert names == {"a.py", "b.go"}

    def test_recursive_discovery(self, tmp_path: Path):
        sub = tmp_path / "pkg"
        sub.mkdir()
        (sub / "deep.py").write_text("z = 3\n")
        (tmp_path / "top.py").write_text("x = 1\n")
        result = _collect_files(tmp_path, ("*.py",))
        assert len(result) == 2

    def test_empty_directory(self, tmp_path: Path):
        result = _collect_files(tmp_path, ("*.py",))
        assert result == []

    def test_no_duplicates_with_overlapping_patterns(self, tmp_path: Path):
        (tmp_path / "a.py").write_text("x = 1\n")
        result = _collect_files(tmp_path, ("*.py", "*.py"))
        assert len(result) == 1
