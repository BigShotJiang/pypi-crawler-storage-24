"""
Domain value objects for RL training and curriculum scheduling.

Pure frozen dataclasses and enums — no framework dependencies.
These live in domain/ so the frozen-dataclass convention tests cover
them automatically.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

# =============================================================================
# Checkpoint metadata
# =============================================================================


@dataclass(frozen=True)
class CheckpointMetadata:
    """Metadata stored alongside policy weights.

    Captures training progress at the time a checkpoint is saved so
    that training can be resumed from any checkpoint.

    Args:
        epoch: Checkpoint epoch index.
        total_episodes: Cumulative episode count at this checkpoint.
        mean_reward: Mean episode reward over the checkpoint window.
        checkpoint_path: Filesystem path where the checkpoint was saved.
        epsilon: Exploration rate at save time.
        env_state: Optional environment state dict for resumable training
            (e.g. current instance index in a multi-instance environment).
    """

    epoch: int
    total_episodes: int
    mean_reward: float
    checkpoint_path: str
    epsilon: float = 0.0
    env_state: dict | None = None


# =============================================================================
# Phase (reward shaping)
# =============================================================================


@dataclass(frozen=True)
class Phase:
    """A named group of action pairs that form a logical workflow stage.

    Phases define the expected ordering of AP execution. The RL agent
    is rewarded for completing phases in order (Discovery before Analysis,
    Analysis before Generation, etc.).

    Args:
        name: Human-readable label (e.g. "discovery", "analysis").
        ap_ids: Action pair IDs that belong to this phase.
    """

    name: str
    ap_ids: frozenset[str]


# =============================================================================
# Training loop value objects
# =============================================================================


@dataclass(frozen=True)
class StepInfo:
    """Per-step data passed to the on_step callback.

    Provides enough context to reconstruct the episode's action pair
    execution sequence, including which APs were satisfied before/after
    and whether the guard passed.
    """

    episode: int
    step: int
    max_steps: int
    action: int  # index into AP pool
    reward_value: float
    guard_passed: bool
    terminal: bool
    satisfied_before: frozenset[str]
    satisfied_after: frozenset[str]
    available_after: frozenset[str]
    step_duration_ms: float = 0.0


@dataclass(frozen=True)
class EpisodeMetrics:
    """Per-episode metrics passed to the on_episode callback.

    Replaces the growing positional argument list with a single
    structured object.  Fields that depend on the environment
    (tokens_used, backtrack_count) come from
    ``EnvironmentInterface.get_episode_stats()``.
    """

    episode: int
    reward: float
    steps: int
    satisfied_count: int
    total_aps: int
    all_satisfied: bool
    duration_secs: float
    tokens_used: int
    backtrack_count: int
    execution_duration_ms: float = 0.0
    started_at: str = ""
    finished_at: str = ""


@dataclass(frozen=True)
class TrainingConfig:
    """Training hyperparameters.

    Note on exploration decay: the Trainer does not call
    ``policy.decay_epsilon()`` directly. Epsilon scheduling is the
    caller's responsibility via the ``on_checkpoint`` callback — this
    keeps the Trainer agnostic to the policy's exploration strategy.
    For example, the RL training CLI decays epsilon at each checkpoint::

        def on_checkpoint(episode, mean_reward):
            policy.decay_epsilon(epsilon_decay ** checkpoint_interval)
            policy.save(checkpoint_dir)
    """

    num_episodes: int = 1000
    max_steps_per_episode: int = 100
    batch_size: int = 32
    learning_rate: float = 3e-4
    gamma: float = 0.99  # Discount factor
    checkpoint_interval: int = 100  # Save every N episodes
    rmax_per_ap: int = (
        2  # Max retries within DualStateAgent per RL step (3 total attempts)
    )


# =============================================================================
# Curriculum scheduling value objects
# =============================================================================


class DifficultyLevel(Enum):
    """Task difficulty tiers for curriculum scheduling."""

    EASY = "easy"
    MEDIUM = "medium"
    HARD = "hard"


@dataclass(frozen=True)
class CurriculumTask:
    """A single task in the curriculum with difficulty metadata."""

    task_id: str
    specification: str
    difficulty: DifficultyLevel
    estimated_steps: int  # Expected number of workflow steps
