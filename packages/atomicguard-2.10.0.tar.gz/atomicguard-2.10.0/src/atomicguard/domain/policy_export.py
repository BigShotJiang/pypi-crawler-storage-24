"""
PolicyExporter — domain service that converts a trained Q-table into a WorkflowDefinition.

Lives in ``domain/`` because it depends only on domain types (``PolicyInterface``,
``WorkflowDefinition``, ``ActionPairDefinition``) and performs a pure transformation.
This makes it importable by any layer (application, infrastructure, web) without
violating the dependency rule.

The lifecycle this closes:

    WorkflowOrchestrator JSON → RL training → Q-table → PolicyExporter → new WorkflowOrchestrator JSON

The exported JSON can be loaded by ``build_workflow()`` and executed via
``WorkflowOrchestrator.execute()`` — no RLAgent required in production.

See ``docs/design/plans/policy_export_and_production_execution.md`` for the
full design rationale.
"""

from __future__ import annotations

from atomicguard.domain.interfaces import PolicyInterface
from atomicguard.domain.models import ActionPairDefinition, WorkflowDefinition


class PolicyExporter:
    """Export a trained TabularPolicy to a WorkflowDefinition.

    Usage::

        exporter = PolicyExporter(policy)
        workflow_def = exporter.export(base_workflow)

    The resulting ``WorkflowDefinition`` mirrors the base workflow's action
    pairs and configuration, but with ``requires`` edges derived from the
    greedy policy trace.  Pass it to a workflow serialiser (e.g.
    ``atomicguard.tools.export_workflow``) to write the JSON to disk.
    """

    def __init__(self, policy: PolicyInterface) -> None:
        self._policy = policy

    def export(
        self,
        base_workflow: WorkflowDefinition,
        *,
        include_all_aps: bool = True,
    ) -> WorkflowDefinition:
        """Build a WorkflowDefinition from the greedy policy ordering.

        The greedy trace gives an ordered list of AP IDs.  Each AP in the
        trace receives a ``requires`` edge pointing to the previous AP,
        encoding the learned sequencing as a linear dependency chain.

        APs from the base workflow that are NOT in the policy's AP pool are
        appended to the end with their original ``requires`` intact (if
        ``include_all_aps`` is True).

        Args:
            base_workflow: Source of AP definitions, metadata, and config.
            include_all_aps: If True, APs absent from the policy are appended
                with their original definitions unchanged.  Default True.

        Returns:
            New WorkflowDefinition with policy-derived ``requires`` edges.
        """
        ordering = self._policy.greedy_trace()
        policy_ap_ids: set[str] = set(ordering)

        # Index base workflow APs for quick lookup
        base_ap_map: dict[str, ActionPairDefinition] = {
            ap.ap_id: ap for ap in base_workflow.action_pairs
        }

        exported_aps: list[ActionPairDefinition] = []
        prev_ap_id: str | None = None

        for ap_id in ordering:
            base_ap = base_ap_map.get(ap_id)
            if base_ap is None:
                # Policy knows about an AP not in the base workflow — skip it
                # (training ran with a superset of APs).
                continue

            requires: tuple[str, ...] = (prev_ap_id,) if prev_ap_id is not None else ()
            exported_aps.append(
                ActionPairDefinition(
                    ap_id=base_ap.ap_id,
                    generator=base_ap.generator,
                    generator_config=base_ap.generator_config,
                    guard=base_ap.guard,
                    guards=base_ap.guards,
                    guard_config=base_ap.guard_config,
                    requires=requires,
                    artifact_type=base_ap.artifact_type,
                    output_type=base_ap.output_type,
                    r_patience=base_ap.r_patience,
                    e_max=base_ap.e_max,
                    escalate_feedback_to=base_ap.escalate_feedback_to,
                    escalate_feedback_by_guard=base_ap.escalate_feedback_by_guard,
                    human_prompt_title=base_ap.human_prompt_title,
                    description=base_ap.description,
                    group=base_ap.group,
                    goal=base_ap.goal,
                )
            )
            prev_ap_id = ap_id

        if include_all_aps:
            for ap_id, base_ap in base_ap_map.items():
                if ap_id not in policy_ap_ids:
                    exported_aps.append(base_ap)

        return WorkflowDefinition(
            slug=base_workflow.slug,
            name=base_workflow.name,
            description=base_workflow.description,
            specification=base_workflow.specification,
            constraints=base_workflow.constraints,
            model=base_workflow.model,
            provider=base_workflow.provider,
            rmax=base_workflow.rmax,
            action_pairs=tuple(exported_aps),
        )

    def ordering(self) -> list[str]:
        """Return the greedy AP ordering without building a full WorkflowDefinition."""
        return self._policy.greedy_trace()
