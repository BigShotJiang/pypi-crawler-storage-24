"""
Domain models for the Dual-State Framework.

These are pure data structures aligned with paper Definitions 4-6.
All models are immutable (frozen dataclasses) to ensure referential transparency.
"""

from dataclasses import dataclass, field
from enum import Enum
from types import MappingProxyType
from typing import TYPE_CHECKING, Any, NewType

# ---------------------------------------------------------------------------
# ID types — zero-cost NewType wrappers for type-safe ID handling (DDD §3)
# These are plain str at runtime; mypy catches swapped-ID mistakes.
# ---------------------------------------------------------------------------

ArtifactId = NewType("ArtifactId", str)
ActionPairId = NewType("ActionPairId", str)
WorkflowId = NewType("WorkflowId", str)
GuardId = NewType("GuardId", str)

if TYPE_CHECKING:
    from atomicguard.domain.interfaces import ArtifactDAGInterface


# =============================================================================
# GUARD RESULT (moved before Artifact for forward reference)
# =============================================================================


@dataclass(frozen=True)
class SubGuardOutcome:
    """Outcome from a single sub-guard within a composite (Definition 43).

    Captures individual guard result for attribution in composite validations.
    """

    guard_name: str  # Class name of the sub-guard
    passed: bool  # Whether this sub-guard passed
    feedback: str  # Feedback from this sub-guard
    execution_time_ms: float = 0.0  # Time spent in this sub-guard


@dataclass(frozen=True)
class GuardResult:
    """Immutable guard validation outcome (Definition 6).

    G(α, C) → {v, φ} where:
    - v = passed (⊤ or ⊥)
    - φ = feedback signal
    - fatal = ⊥_fatal (non-recoverable, requires escalation)

    Note: Stagnation detection is done by the agent (which sees feedback history),
    not by guards (which are stateless and validate single artifacts).
    """

    passed: bool
    feedback: str = ""
    fatal: bool = False  # ⊥_fatal - skip retry, escalate to human
    guard_name: str | None = None  # Name of the guard that produced this result
    metadata: dict[str, str] | None = (
        None  # Structured guard observations (e.g. strategy recommendation)
    )
    sub_results: tuple[SubGuardOutcome, ...] = ()  # For composite guards (Extension 08)

    def should_retry(self) -> bool:
        """Return True if the failure is retryable (not fatal, not passed)."""
        return not self.passed and not self.fatal

    def should_escalate(self) -> bool:
        """Return True if the failure is fatal and requires escalation."""
        return not self.passed and self.fatal


# =============================================================================
# ARTIFACT MODEL (Definition 4-6)
# =============================================================================


class ArtifactStatus(Enum):
    """Status of an artifact in the DAG."""

    PENDING = "pending"  # Generated, not yet validated
    REJECTED = "rejected"  # Guard returned ⊥
    ACCEPTED = "accepted"  # Guard returned ⊤, final for this step
    SUPERSEDED = "superseded"  # Guard returned ⊤, but later attempt also passed


class ArtifactSource(Enum):
    """Origin of artifact content."""

    GENERATED = "generated"  # LLM-generated
    HUMAN = "human"  # Human-provided during amendment
    IMPORTED = "imported"  # Imported from external source


@dataclass(frozen=True)
class FeedbackEntry:
    """Single entry in feedback history H."""

    artifact_id: str  # Reference to the rejected artifact
    feedback: str  # Guard's rejection message φ


@dataclass(frozen=True)
class ContextSnapshot:
    """Immutable context C that conditioned generation (Definition 5)."""

    workflow_id: str  # UUID of the workflow execution instance
    specification: str  # Ψ - static specification
    constraints: str  # Ω - global constraints
    feedback_history: tuple[FeedbackEntry, ...]  # H - accumulated rejections
    dependency_artifacts: tuple[
        tuple[str, str], ...
    ] = ()  # (action_pair_id, artifact_id) - matches schema
    escalation_feedback: tuple[str, ...] = ()  # One entry per escalation cycle
    dependency_types: tuple[
        tuple[str, str], ...
    ] = ()  # (action_pair_id, artifact_type) for type-based lookup


@dataclass(frozen=True)
class Artifact:
    """
    Immutable node in the Versioned Repository DAG (Definition 4).

    Represents a single generation attempt with full provenance tracking.
    """

    # Identity
    artifact_id: ArtifactId  # Unique identifier (UUID)
    workflow_id: WorkflowId  # UUID of the workflow execution instance
    content: str  # The generated code/text

    # DAG Structure
    previous_attempt_id: ArtifactId | None  # Retry chain within same action pair
    parent_action_pair_id: (
        ActionPairId | None
    )  # Parent hierarchy for composite generators
    # Cross-step deps are in context.dependency_artifacts

    # Action Pair Coupling (Definition 6: A = ⟨ρ, a_gen, G⟩)
    action_pair_id: ActionPairId  # Which action pair produced this

    # Metadata
    created_at: str  # ISO timestamp
    attempt_number: int  # Attempt within this action pair context
    status: ArtifactStatus  # pending/rejected/accepted/superseded
    guard_result: GuardResult | None  # Full guard result (None if pending)
    context: ContextSnapshot  # Full context snapshot at generation time
    source: ArtifactSource = ArtifactSource.GENERATED  # Origin of content

    # Extension 01: Versioned Environment (Definition 10)
    workflow_ref: str | None = None  # W_ref: Content-addressed workflow hash (Def 11)

    # Extension 07: Incremental Execution (Definition 33)
    config_ref: str | None = (
        None  # Ψ_ref: Configuration fingerprint for change detection
    )

    metadata: MappingProxyType[str, Any] = field(
        default_factory=lambda: MappingProxyType({})
    )  # Immutable metadata dict

    # Semantic type tag for dependency resolution by type
    artifact_type: str | None = None  # e.g. "patch", "localization", "test"

    # Producer-driven context instruction for consumers
    artifact_context: str | None = None

    def __post_init__(self) -> None:
        """Convert metadata dict to immutable MappingProxyType if needed."""
        # Handle case where metadata is passed as a regular dict
        if isinstance(object.__getattribute__(self, "metadata"), dict):
            object.__setattr__(self, "metadata", MappingProxyType(self.metadata))

    def is_accepted(self) -> bool:
        """Return True if this artifact was accepted by its guard."""
        return self.status == ArtifactStatus.ACCEPTED

    def is_terminal(self) -> bool:
        """Return True if this artifact has a final (non-pending) status."""
        return self.status != ArtifactStatus.PENDING


# =============================================================================
# CONTEXT AND ENVIRONMENT
# =============================================================================


@dataclass(frozen=True)
class AmbientEnvironment:
    """Ambient Environment E = ⟨R, Ω⟩"""

    repository: "ArtifactDAGInterface"
    constraints: str = ""


@dataclass(frozen=True)
class Context:
    """Immutable hierarchical context composition (Definition 5)."""

    ambient: AmbientEnvironment
    specification: str
    current_artifact: str | None = None
    feedback_history: tuple[tuple[str, str], ...] = ()
    dependency_artifacts: tuple[
        tuple[str, str], ...
    ] = ()  # (action_pair_id, artifact_id) - matches schema
    workflow_id: str | None = None  # Extension 03: Agent workflow identifier (Def 19)
    escalation_feedback: tuple[str, ...] = ()  # Downstream failure summaries
    dependency_types: tuple[
        tuple[str, str], ...
    ] = ()  # (action_pair_id, artifact_type) for type-based lookup
    dependency_artifact_contexts: tuple[
        tuple[str, str], ...
    ] = ()  # (action_pair_id, artifact_context) for producer-driven context

    def get_dependency_by_type(self, artifact_type: str) -> str | None:
        """Look up artifact_id by artifact_type.

        Returns the artifact_id for the first dependency whose type matches.
        """
        for ap_id, dep_type in self.dependency_types:
            if dep_type == artifact_type:
                return self.get_dependency(ap_id)
        return None

    def get_dependency(self, action_pair_id: str) -> str | None:
        """Look up artifact_id by action_pair_id."""
        for key, artifact_id in self.dependency_artifacts:
            if key == action_pair_id:
                return artifact_id
        return None

    def amend(self, delta_spec: str = "", delta_constraints: str = "") -> "Context":
        """Monotonic configuration amendment (⊕ operator, Definition 12).

        Creates a new Context with appended specification and/or constraints.
        Original Context remains unchanged (immutability preserved).

        Args:
            delta_spec: Additional specification to append to current specification.
            delta_constraints: Additional constraints to append to ambient constraints.

        Returns:
            New Context with amended specification and constraints.
        """
        new_spec = self.specification
        if delta_spec:
            new_spec = f"{self.specification}\n{delta_spec}"

        new_constraints = self.ambient.constraints
        if delta_constraints:
            new_constraints = f"{self.ambient.constraints}\n{delta_constraints}"

        new_ambient = AmbientEnvironment(
            repository=self.ambient.repository,
            constraints=new_constraints,
        )

        return Context(
            ambient=new_ambient,
            specification=new_spec,
            current_artifact=self.current_artifact,
            feedback_history=self.feedback_history,
            dependency_artifacts=self.dependency_artifacts,
            workflow_id=self.workflow_id,
            escalation_feedback=self.escalation_feedback,
            dependency_types=self.dependency_types,
            dependency_artifact_contexts=self.dependency_artifact_contexts,
        )


# =============================================================================
# WORKFLOW STATE
# =============================================================================


class WorkflowStatus(Enum):
    """Workflow execution outcome."""

    SUCCESS = "success"  # All steps completed
    FAILED = "failed"  # Rmax exhausted on a step
    ESCALATION = "escalation"  # Fatal guard triggered


@dataclass(frozen=True)
class WorkflowState:
    """Immutable workflow state tracking guard satisfaction.

    Use with_satisfied() / with_unsatisfied() to derive new states;
    no in-place mutation is permitted (frozen dataclass).
    """

    guards: MappingProxyType[GuardId, bool] = field(
        default_factory=lambda: MappingProxyType({})
    )
    artifact_ids: MappingProxyType[GuardId, ArtifactId] = field(
        default_factory=lambda: MappingProxyType({})
    )

    def is_satisfied(self, guard_id: GuardId) -> bool:
        return self.guards.get(guard_id, False)

    def with_satisfied(
        self, guard_id: GuardId, artifact_id: ArtifactId
    ) -> "WorkflowState":
        """Return a new WorkflowState with guard_id satisfied."""
        return WorkflowState(
            guards=MappingProxyType({**self.guards, guard_id: True}),
            artifact_ids=MappingProxyType({**self.artifact_ids, guard_id: artifact_id}),
        )

    def with_unsatisfied(self, guard_id: GuardId) -> "WorkflowState":
        """Return a new WorkflowState with guard_id unsatisfied (Extension 09: Cascade Invalidation)."""
        return WorkflowState(
            guards=MappingProxyType({**self.guards, guard_id: False}),
            artifact_ids=MappingProxyType(
                {k: v for k, v in self.artifact_ids.items() if k != guard_id}
            ),
        )

    def get_artifact_id(self, guard_id: GuardId) -> ArtifactId | None:
        return self.artifact_ids.get(guard_id)

    def get_satisfied_guards(self) -> tuple[GuardId, ...]:
        """Return tuple of all currently satisfied guard IDs."""
        return tuple(gid for gid, satisfied in self.guards.items() if satisfied)


@dataclass(frozen=True)
class WorkflowStep:
    """Internal step representation used by WorkflowOrchestrator to store registered steps."""

    guard_id: str
    action_pair: Any  # ActionPair — typed as Any to avoid domain→application import
    requires: tuple[str, ...]
    deps: tuple[str, ...]  # Artifacts to pass to guard
    # Extension 09: Escalation parameters
    r_patience: int | None = None  # Consecutive similar failures before escalation
    e_max: int = 1  # Maximum escalation attempts before FAIL
    escalate_feedback_to: tuple[
        str, ...
    ] = ()  # Upstream steps to receive failure context
    escalate_feedback_by_guard: MappingProxyType[str, tuple[str, ...]] = field(
        default_factory=lambda: MappingProxyType({})
    )  # Definition 45: guard-specific feedback routing
    # OR-group dependencies and variant groups
    requires_any: tuple[tuple[str, ...], ...] = ()  # Each tuple is an OR-group
    group: str | None = None  # Variant group name (e.g. "gen_patch")
    # Semantic type tag for artifact resolution
    artifact_type: str | None = None  # e.g. "patch", "localization"
    # Producer-driven artifact context string
    artifact_context: str | None = None
    # Whether this step is required for workflow completion (default: True)
    required: bool = True
    # Whether this step is a goal/exit state for the episode (default: False)
    goal: bool = False


@dataclass(frozen=True)
class WorkflowResult:
    """Result of workflow execution."""

    status: WorkflowStatus
    artifacts: dict[str, Artifact]
    failed_step: str | None = None
    provenance: tuple[tuple[Artifact, str], ...] = ()
    escalation_artifact: Artifact | None = None  # Artifact that triggered escalation
    escalation_feedback: str = ""  # Fatal feedback message


# =============================================================================
# STAGNATION INFO (Definition 44)
# =============================================================================


@dataclass(frozen=True)
class StagnationInfo:
    """Result of stagnation detection (Definition 44).

    Captures whether consecutive failures are similar enough to trigger
    escalation, along with summary information for context injection.
    """

    detected: bool  # True if r_patience consecutive similar failures
    similar_count: int  # Number of consecutive similar failures
    error_signature: str  # Deduplicated error type/pattern
    approaches_tried: tuple[str, ...]  # Summary of what was attempted
    failure_summary: str  # Full summary for context injection (Definition 48)
    stagnant_guard: str | None = (
        None  # Sub-guard that caused stagnation (composite guards)
    )

    def should_escalate(self) -> bool:
        """Return True if stagnation has been detected and warrants escalation."""
        return self.detected

    def context_for_injection(self) -> str:
        """Return the failure summary string for upstream context injection (Definition 48)."""
        return self.failure_summary


# =============================================================================
# WEB UI DOMAIN MODELS (workflow/AP context persistence)
# =============================================================================


@dataclass(frozen=True)
class WorkflowSummary:
    """Lightweight workflow metadata for list views."""

    slug: str
    name: str
    description: str = ""
    action_pair_count: int = 0
    model: str = ""
    provider: str = ""


@dataclass(frozen=True)
class ActionPairDefinition:
    """Stored definition of a single action pair within a workflow."""

    ap_id: str
    generator: str = ""
    generator_config: dict[str, Any] = field(default_factory=dict)
    guard: str = ""
    guards: Any = None  # list[str] | CompositeGuardSpec dict | None
    guard_config: dict[str, Any] = field(default_factory=dict)
    requires: tuple[str, ...] = ()
    artifact_type: str = ""
    output_type: str = ""
    r_patience: int | None = None
    e_max: int = 1
    escalate_feedback_to: tuple[str, ...] = ()
    escalate_feedback_by_guard: dict[str, tuple[str, ...]] = field(default_factory=dict)
    human_prompt_title: str = ""
    description: str = ""
    group: str = ""
    goal: bool = False


@dataclass(frozen=True)
class WorkflowDefinition:
    """Full workflow definition for persistence and round-trip export."""

    slug: str
    name: str
    description: str = ""
    specification: Any = None  # str | SpecificationSource dict
    constraints: str = ""
    model: str = ""
    provider: str = ""
    rmax: int = 3
    action_pairs: tuple[ActionPairDefinition, ...] = ()
    source_policy_slug: str = ""  # provenance: policy that generated this workflow


@dataclass(frozen=True)
class APContextEntry:
    """Stored AP context (prompt template) for a single action pair."""

    ap_id: str
    role: str = ""
    constraints: str = ""
    task: str = ""
    feedback_wrapper: str = ""
    escalation_feedback_wrapper: str = ""
    feedback_mode: str = "inline"
    artifact_context: str = ""


# =============================================================================
# Production Run Management (Web UI — Step 4)
# =============================================================================


@dataclass(frozen=True)
class ProductionRun:
    """A production experiment run tracked by the web UI."""

    id: int
    workflow_slug: str
    model: str = ""
    provider: str = ""
    arms: tuple[str, ...] = ()
    language: str | None = None
    max_instances: int | None = None
    max_workers: int = 1
    output_dir: str = ""
    policy_path: str = ""  # path to trained RL policy checkpoint dir
    status: str = "pending"  # pending | running | completed | failed | cancelled
    pid: int | None = None
    created_at: str = ""  # ISO 8601
    started_at: str | None = None
    finished_at: str | None = None
    error: str | None = None
    # Summary stats (populated after completion or during progress)
    total_instances: int = 0
    completed_instances: int = 0
    failed_instances: int = 0
    resolved_instances: int = 0


@dataclass(frozen=True)
class GuardResultRecord:
    """A single guard result from a production run, for the timeline view."""

    id: int
    run_id: int
    instance_id: str
    arm: str
    step_id: str
    guard_name: str
    passed: bool
    feedback: str = ""
    attempt: int = 1
    wall_time_seconds: float = 0.0
    tokens_used: int = 0
    recorded_at: str = ""  # ISO 8601


# =============================================================================
# Training Run Management (Web UI — Step 5)
# =============================================================================


@dataclass(frozen=True)
class TrainingRunRecord:
    """A training run tracked by the web UI."""

    id: int
    slug: str
    display_name: str
    path: str  # filesystem path to training run directory
    model: str = ""
    provider: str = ""
    arm: str = ""
    reward: str = ""
    episodes: int = 0
    gamma: float = 0.0
    alpha: float = 0.0
    epsilon_initial: float = 0.0
    epsilon_final: float = 0.0
    epsilon_decay: float = 0.0
    instances: int = 0
    language: str | None = None
    gym_slug: str | None = None
    training_mean_reward: float = 0.0
    eval_mean_reward: float = 0.0
    eval_success_rate: float = 0.0
    ap_ids: tuple[str, ...] = ()
    status: str = "complete"  # in_progress | complete | terminated
    completed_episodes: int = 0
    created_at: str = ""
    updated_at: str = ""


@dataclass(frozen=True)
class TrainingEpisodeRecord:
    """A single training episode record."""

    id: int
    training_run_id: int
    episode: int
    reward: float = 0.0
    steps: int = 0
    epsilon: float = 0.0
    satisfied: int | None = None
    total_aps: int | None = None
    all_satisfied: bool | None = None
    duration_secs: float | None = None
    tokens: int | None = None
    backtracks: int | None = None
    instance_id: str | None = None


# =============================================================================
# Policy Library (Web UI — Step 6)
# =============================================================================


@dataclass(frozen=True)
class PolicyRecord:
    """A trained policy in the policy library."""

    id: int
    slug: str
    display_name: str
    path: str  # filesystem path to checkpoint directory
    training_run_id: int | None = None  # link to source training run
    training_run_slug: str = ""
    model: str = ""
    provider: str = ""
    arm: str = ""
    reward: str = ""
    episodes: int = 0
    mean_reward: float = 0.0
    eval_success_rate: float = 0.0
    ap_ids: tuple[str, ...] = ()
    num_states: int = 0
    num_actions: int = 0
    total_visits: int = 0
    gym_slug: str | None = None
    created_at: str = ""


# =============================================================================
# Gym Catalogue (Web UI — Gym Phase 2)
# =============================================================================


@dataclass(frozen=True)
class GymRecord:
    """A gym entry as stored in the database for the web UI."""

    slug: str
    name: str
    description: str = ""
    version: str = "1.0"
    workflow_slug: str = ""
    requires_docker: bool = False
    requires_llm: bool = True
    languages: tuple[str, ...] = ()
    instance_count: int = 0
    tiers: tuple[int, ...] = ()
    ap_count: int = 0
    created_at: str = ""


@dataclass(frozen=True)
class APCatalogueEntry:
    """An action pair entry from the AP catalogue."""

    ap_id: str
    name: str = ""
    description: str = ""
    generator: str = ""
    guard: str = ""
    domain: str = "generic"
    language: str | None = None
    stochasticity: str = "stochastic"
    artifact_type: str = ""
    tags: tuple[str, ...] = ()


@dataclass(frozen=True)
class PolicyEntry:
    """A trained RL policy registered for production use.

    Registered via ``atomicguard policy register`` and resolved by name
    when ``atomicguard run --policy <name>`` is invoked.
    """

    name: str
    path: str
    checkpoint: str
    gym: str
    model: str
    provider: str
    ap_ids: tuple[str, ...]
    total_episodes: int
    registered_at: str  # ISO-8601 UTC


# =============================================================================
# Gym Instance Models
# =============================================================================


@dataclass(frozen=True)
class PreCommitInstance:
    """A synthetic code module for pre-commit training.

    Attributes:
        instance_id: Unique identifier.
        description: Human-readable description of the issue.
        module_content: The Python source code.
        test_content: Associated pytest test code (may be empty).
        issues: Set of issue categories present in this instance.
        tier: Difficulty tier (1 = simple, 2 = medium, 3 = complex).
    """

    instance_id: str
    description: str
    module_content: str
    test_content: str
    issues: frozenset[str]
    tier: int = 1
    change_size: int = 0  # 0=unknown, 1=small (<10 lines), 2=medium (<100), 3=large
