"""SubprocessGenerator — runs a shell command and captures output as an artifact.

Deterministic generator for tool-based APs (linters, formatters, test runners).
The command's stdout/stderr becomes the artifact content; the exit code is
stored in artifact metadata for downstream guards to inspect.

Supports Docker isolation: when ``docker_container_id`` is set, the command
is executed via ``docker exec`` inside the specified container.
"""

from __future__ import annotations

import subprocess
import uuid
from datetime import UTC, datetime
from types import MappingProxyType
from typing import Any

from atomicguard.domain.interfaces import GeneratorInterface
from atomicguard.domain.models import (
    ActionPairId,
    Artifact,
    ArtifactId,
    ArtifactStatus,
    Context,
    ContextSnapshot,
    WorkflowId,
)
from atomicguard.domain.prompts import PromptTemplate


class SubprocessGenerator(GeneratorInterface):
    """Runs a shell command and captures output as an artifact.

    The command is executed via ``subprocess.run`` with a configurable
    timeout.  stdout and stderr are captured and concatenated as the
    artifact content.  The process exit code is stored in
    ``artifact.metadata["exit_code"]`` so that downstream guards
    (e.g. ``ExitCodeGuard``) can inspect it without re-running the
    command.

    When ``docker_container_id`` is set, the command is executed via
    ``docker exec`` inside the specified container instead of on the
    host.

    Args:
        command: Command to run as a list of strings (e.g. ``["ruff", "check", "."]``).
        cwd: Working directory for the command.  If ``None``, uses the
            current process working directory.
        timeout: Maximum seconds to wait for the command.  Default 120.
        env: Optional environment variable overrides.
        docker_container_id: If set, execute via ``docker exec`` in this
            container.  The ``cwd`` argument is ignored when using Docker
            (use the container's working directory instead).
    """

    def __init__(
        self,
        command: list[str],
        cwd: str | None = None,
        timeout: int = 120,
        env: dict[str, str] | None = None,
        docker_container_id: str | None = None,
        **_kwargs: Any,
    ) -> None:
        self._command = command
        self._cwd = cwd
        self._timeout = timeout
        self._env = env
        self._docker_container_id = docker_container_id

    def _build_command(self) -> list[str]:
        """Build the final command, wrapping in ``docker exec`` if needed."""
        if self._docker_container_id:
            return ["docker", "exec", self._docker_container_id] + self._command
        return self._command

    def generate(
        self,
        context: Context,
        template: PromptTemplate,  # noqa: ARG002
        action_pair_id: str = "unknown",
        workflow_id: str = "unknown",
        workflow_ref: str | None = None,
    ) -> Artifact:
        """Execute the subprocess and return its output as an artifact.

        The artifact's ``metadata["exit_code"]`` contains the process
        return code.  Guards should inspect this rather than parsing
        the output text.
        """
        cmd = self._build_command()
        # When using Docker, cwd is irrelevant (container has its own workdir)
        cwd = None if self._docker_container_id else self._cwd

        try:
            result = subprocess.run(
                cmd,
                cwd=cwd,
                capture_output=True,
                text=True,
                timeout=self._timeout,
                env=self._env,
            )
            content = result.stdout
            if result.stderr:
                content = f"{content}\n{result.stderr}" if content else result.stderr
            exit_code = result.returncode
        except subprocess.TimeoutExpired:
            content = (
                f"Command timed out after {self._timeout}s: {' '.join(self._command)}"
            )
            exit_code = -1
        except FileNotFoundError:
            content = f"Command not found: {cmd[0]}"
            exit_code = -1

        now = datetime.now(tz=UTC).isoformat()
        ctx_snapshot = ContextSnapshot(
            workflow_id=workflow_id,
            specification=context.specification,
            constraints=context.ambient.constraints,
            feedback_history=(),
        )

        return Artifact(
            artifact_id=ArtifactId(str(uuid.uuid4())),
            workflow_id=WorkflowId(workflow_id),
            content=content.strip() if content else "",
            previous_attempt_id=None,
            parent_action_pair_id=None,
            action_pair_id=ActionPairId(action_pair_id),
            created_at=now,
            attempt_number=1,
            status=ArtifactStatus.PENDING,
            guard_result=None,
            context=ctx_snapshot,
            workflow_ref=workflow_ref,
            metadata=MappingProxyType({"exit_code": str(exit_code)}),
        )
