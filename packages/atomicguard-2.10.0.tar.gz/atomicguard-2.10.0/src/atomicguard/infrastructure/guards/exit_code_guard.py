"""ExitCodeGuard — validates that a subprocess exited with code 0.

Reads ``artifact.metadata["exit_code"]`` set by ``SubprocessGenerator``
and passes when the value is ``"0"``.
"""

from __future__ import annotations

from typing import Any

from atomicguard.domain.interfaces import GuardInterface
from atomicguard.domain.models import Artifact, GuardResult


class ExitCodeGuard(GuardInterface):
    """Validates that a subprocess exited with code 0.

    Inspects ``artifact.metadata["exit_code"]`` (set by
    ``SubprocessGenerator``) and passes when it equals ``"0"``.

    When the exit code is non-zero, the artifact content (command
    output) is returned as feedback so that downstream fix APs can
    see what went wrong.

    Args:
        expected_code: The exit code that means success.  Default ``0``.
    """

    def __init__(self, expected_code: int = 0, **_kwargs: Any) -> None:
        self._expected = str(expected_code)

    def validate(self, artifact: Artifact, **dependencies: Artifact) -> GuardResult:  # noqa: ARG002
        exit_code = artifact.metadata.get("exit_code", "-1")

        if exit_code == self._expected:
            return GuardResult(
                passed=True,
                feedback="",
                guard_name="ExitCodeGuard",
            )

        return GuardResult(
            passed=False,
            feedback=artifact.content or f"Process exited with code {exit_code}",
            guard_name="ExitCodeGuard",
        )
