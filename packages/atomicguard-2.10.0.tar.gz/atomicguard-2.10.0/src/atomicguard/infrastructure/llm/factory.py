"""Shared PydanticAI model factory.

Centralises provider-specific model construction so that any module
that needs a PydanticAI model (generators, gym fix APs, etc.) uses
a single implementation instead of duplicating the provider dispatch.
"""

from __future__ import annotations

from typing import Any


def create_llm_model(
    provider: str,
    model: str,
    base_url: str,
    api_key: str,
    timeout: float = 180.0,
) -> Any:
    """Create a PydanticAI model for the given provider.

    Args:
        provider: One of ``"ollama"``, ``"huggingface"``, ``"openrouter"``,
            ``"openai"``.
        model: Model name / identifier.
        base_url: API base URL (used by ollama and openai; ignored for
            huggingface and openrouter whose providers handle routing).
        api_key: API key.
        timeout: HTTP timeout in seconds (connect + read + write + pool).

    Returns:
        A PydanticAI model instance.

    Raises:
        ValueError: If *provider* is not recognised.
    """
    import httpx

    http_client = httpx.AsyncClient(timeout=httpx.Timeout(timeout))

    if provider == "ollama":
        from pydantic_ai.models.openai import OpenAIChatModel
        from pydantic_ai.providers.ollama import OllamaProvider

        return OpenAIChatModel(
            model_name=model,
            provider=OllamaProvider(base_url=base_url, http_client=http_client),
        )

    if provider == "huggingface":
        from pydantic_ai.models.huggingface import HuggingFaceModel
        from pydantic_ai.providers.huggingface import HuggingFaceProvider

        # HuggingFaceProvider uses hf_client (not http_client) internally,
        # so we don't pass our httpx client here.
        return HuggingFaceModel(
            model,
            provider=HuggingFaceProvider(api_key=api_key),
        )

    if provider == "openrouter":
        from pydantic_ai.models.openai import OpenAIChatModel
        from pydantic_ai.providers.openrouter import OpenRouterProvider

        return OpenAIChatModel(
            model_name=model,
            provider=OpenRouterProvider(api_key=api_key, http_client=http_client),
        )

    if provider == "openai":
        from pydantic_ai.models.openai import OpenAIChatModel
        from pydantic_ai.providers.openai import OpenAIProvider

        # Only pass base_url if non-empty (empty string breaks URL construction)
        provider_kwargs: dict[str, Any] = {
            "api_key": api_key,
            "http_client": http_client,
        }
        if base_url:
            provider_kwargs["base_url"] = base_url

        return OpenAIChatModel(
            model_name=model,
            provider=OpenAIProvider(**provider_kwargs),
        )

    raise ValueError(
        f"Unknown provider: {provider!r}. "
        f"Supported: ollama, huggingface, openrouter, openai"
    )
