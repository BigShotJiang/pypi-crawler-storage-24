"""
Ollama LLM generator implementation.

Connects to Ollama instances via the OpenAI-compatible API.
"""

import os
import re
import uuid
from dataclasses import dataclass
from datetime import datetime
from typing import Any, cast

from atomicguard.domain.interfaces import GeneratorInterface
from atomicguard.domain.models import (
    ActionPairId,
    Artifact,
    ArtifactId,
    ArtifactStatus,
    Context,
    ContextSnapshot,
    WorkflowId,
)
from atomicguard.domain.prompts import PromptTemplate

DEFAULT_OLLAMA_URL = "http://localhost:11434/v1"
OLLAMA_CLOUD_URL = "https://ollama.com/v1"


@dataclass
class OllamaGeneratorConfig:
    """Configuration for OllamaGenerator.

    This typed config ensures unknown fields are rejected at construction time.
    """

    model: str = "qwen2.5-coder:7b"
    base_url: str = DEFAULT_OLLAMA_URL
    timeout: float = 120.0
    api_key: str | None = None  # For Ollama Cloud; auto-detects from OLLAMA_API_KEY


class OllamaGenerator(GeneratorInterface):
    """Connects to Ollama instance using OpenAI-compatible API."""

    config_class = OllamaGeneratorConfig

    def __init__(self, config: OllamaGeneratorConfig | None = None, **kwargs: Any):
        """
        Args:
            config: Typed configuration object (preferred)
            **kwargs: Legacy kwargs for backward compatibility (deprecated)
        """
        # Support both config object and legacy kwargs
        if config is None:
            config = OllamaGeneratorConfig(**kwargs)

        try:
            from openai import OpenAI
        except ImportError as err:
            raise ImportError("openai library required: pip install openai") from err

        # Determine API key: explicit config > env var (for cloud) > placeholder (local)
        api_key = config.api_key
        if api_key is None:
            if "ollama.com" in config.base_url:
                # Cloud URL detected - require API key
                api_key = os.environ.get("OLLAMA_API_KEY")
                if not api_key:
                    raise ValueError(
                        "OLLAMA_API_KEY environment variable required for Ollama Cloud"
                    )
            else:
                # Local instance - placeholder is fine
                api_key = "ollama"

        self._model = config.model
        self._client = OpenAI(
            base_url=config.base_url,
            api_key=api_key,
            timeout=config.timeout,
        )
        self._version_counter = 0

    def generate(
        self,
        context: Context,
        template: PromptTemplate,
        action_pair_id: str = "unknown",
        workflow_id: str = "unknown",
        workflow_ref: str | None = None,
    ) -> Artifact:
        """Generate an artifact based on context."""
        # Build prompt
        prompt = template.render(context)

        # Call Ollama
        messages = [
            {
                "role": "system",
                "content": "You are a Python programming assistant. Provide complete, runnable code in a markdown block:\n```python\n# code\n```",
            },
            {"role": "user", "content": prompt},
        ]

        response = self._client.chat.completions.create(
            model=self._model, messages=cast(Any, messages), temperature=0.7
        )

        content = response.choices[0].message.content or ""
        code = self._extract_code(content)

        self._version_counter += 1

        return Artifact(
            artifact_id=ArtifactId(str(uuid.uuid4())),
            workflow_id=WorkflowId(workflow_id),
            content=code,
            previous_attempt_id=None,
            parent_action_pair_id=None,
            action_pair_id=ActionPairId(action_pair_id),
            created_at=datetime.now().isoformat(),
            attempt_number=self._version_counter,
            status=ArtifactStatus.PENDING,
            guard_result=None,  # Guard result set after validation
            context=ContextSnapshot(
                workflow_id=workflow_id,
                specification=context.specification,
                constraints=context.ambient.constraints,
                feedback_history=(),
                dependency_artifacts=context.dependency_artifacts,
            ),
            workflow_ref=workflow_ref,
        )

    def _extract_code(self, content: str) -> str:
        """Extract Python code from response."""
        if not content or content.isspace():
            return ""

        # Try python block
        match = re.search(r"```python\n(.*?)\n```", content, re.DOTALL)
        if match:
            return match.group(1)

        # Try generic block
        match = re.search(r"```\n(.*?)\n```", content, re.DOTALL)
        if match:
            return match.group(1)

        # Try first def/import/class
        match = re.search(r"^(def |import |class )", content, re.MULTILINE)
        if match:
            return content[match.start() :]

        # No code block found - return empty to trigger guard validation failure
        return ""
