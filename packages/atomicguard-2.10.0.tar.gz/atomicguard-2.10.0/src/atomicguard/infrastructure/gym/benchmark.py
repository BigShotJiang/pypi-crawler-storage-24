"""BenchmarkGym — wraps the existing benchmark TDD dataset and workflows.

Formalises the ad-hoc wiring in ``examples/benchmark/rl_training.py``
into the ``GymInterface`` contract.  This is Phase 1 of the gym
abstraction: no new APs, no new infrastructure — just extract the
wiring into a gym.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from atomicguard.domain.gym import GymInstance, GymInterface, GymManifest
from atomicguard.domain.interfaces import (
    ArtifactDAGInterface,
    EnvironmentInterface,
)
from atomicguard.domain.rl.reward import RewardFunctionInterface

VALID_CONSTRAINT_MODES = ("unconstrained", "physical_only", "preserve")

logger = logging.getLogger(__name__)

# WorkflowOrchestrator JSON directory lives in the swe_bench_common examples
# Path: src/atomicguard/infrastructure/gym/ → up 5 levels → project root
_PROJECT_ROOT = Path(__file__).parent.parent.parent.parent.parent

_WORKFLOW_DIR = _PROJECT_ROOT / "examples" / "swe_bench_common" / "workflows"

_ARM_MAP = {
    "benchmark_tdd": "36_benchmark_tdd",
    "benchmark_tdd_v2": "37_benchmark_tdd_v2",
    "benchmark_tdd_v3": "38_benchmark_tdd_v3",
}

_V3_ARMS = frozenset({"benchmark_tdd_v3"})


class BenchmarkGym(GymInterface):
    """Wraps the existing benchmark TDD dataset and workflows.

    Provides 9 TDD tasks across 3 tiers (Stack, Calculator, Queue, …).
    Uses the existing benchmark workflow configs and AP context files.
    """

    def __init__(
        self,
        arm: str = "benchmark_tdd_v3",
        model: str = "",
        provider: str = "ollama",
        base_url: str = "http://localhost:11434/v1",
        api_key: str = "",
        output_mode: str = "tool",
        constraint_mode: str = "preserve",
        agent_cls: type | None = None,
        **_kwargs: Any,
    ) -> None:
        if arm not in _ARM_MAP:
            raise ValueError(f"Unknown arm: {arm!r}. Valid: {', '.join(_ARM_MAP)}")
        if constraint_mode not in VALID_CONSTRAINT_MODES:
            raise ValueError(
                f"Unknown constraint_mode: {constraint_mode!r}. "
                f"Valid: {', '.join(VALID_CONSTRAINT_MODES)}"
            )
        self._arm = arm
        self._arm_variant = _ARM_MAP[arm]
        self._model = model
        self._provider = provider
        self._base_url = base_url
        self._api_key = api_key
        self._output_mode = output_mode
        self._constraint_mode = constraint_mode
        self._agent_cls: type | None = agent_cls

        # Lazily loaded
        self._instances: list[GymInstance] | None = None
        self._ap_ids: tuple[str, ...] | None = None

    def _load_benchmark_instances(self) -> list[GymInstance]:
        """Load benchmark instances, converting to GymInstance."""
        from examples.benchmark.dataset import get_benchmark_instances

        raw = get_benchmark_instances()
        return [
            GymInstance(
                instance_id=inst.instance_id,
                specification=inst.specification,
                tier=inst.tier,
                context={"reference_tests": inst.reference_tests},
            )
            for inst in raw
        ]

    def get_instances(self, limit: int | None = None) -> list[GymInstance]:
        """Return available benchmark task instances."""
        if self._instances is None:
            self._instances = self._load_benchmark_instances()
        instances = self._instances
        if limit is not None:
            instances = instances[:limit]
        return instances

    def _load_workflow_config(self) -> dict[str, Any]:
        """Load the workflow JSON config."""
        from examples.swe_bench_common.config import (
            load_workflow_config as _load_workflow_config,
        )

        return _load_workflow_config(_WORKFLOW_DIR, self._arm_variant)

    def _validate_constraint_mode(self, config: dict[str, Any]) -> None:
        """Validate workflow config against the constraint_mode setting."""
        if self._constraint_mode != "unconstrained":
            return
        action_pairs = config.get("action_pairs", {})
        for ap_id, ap_def in action_pairs.items():
            requires = ap_def.get("requires", [])
            if requires:
                raise ValueError(
                    f"constraint_mode='unconstrained' but AP {ap_id!r} has "
                    f"non-empty requires: {requires}. All APs must have "
                    f"empty requires for unconstrained exploration."
                )

    def build_environment(
        self,
        instance: GymInstance,
        reward_fn: RewardFunctionInterface,
        artifact_dag: ArtifactDAGInterface,
        *,
        max_steps: int | None = None,
        enable_backtracking: bool = False,
        max_selections_per_ap: int | None = None,
    ) -> EnvironmentInterface:
        """Build a training environment for one benchmark instance."""
        from examples.swe_bench_common.config import (
            load_ap_context,
            load_artifact_contexts,
        )
        from examples.swe_bench_pro.experiment_runner import build_workflow
        from examples.swe_bench_pro.language import get_language_config

        from atomicguard.infrastructure.rl.environment import TrainingEnvironment

        config = self._load_workflow_config()
        self._validate_constraint_mode(config)

        # Select AP context file
        if self._arm in _V3_ARMS:
            ap_context_file = (
                _PROJECT_ROOT / "examples" / "benchmark" / "ap_context_v3.json"
            )
        else:
            ap_context_file = (
                _PROJECT_ROOT / "examples" / "benchmark" / "ap_context.json"
            )

        ap_context = (
            load_ap_context(ap_context_file) if ap_context_file.exists() else {}
        )
        artifact_contexts = load_artifact_contexts(ap_context_file)
        lang_config = get_language_config("python")

        workflow = build_workflow(
            config=config,
            ap_context=ap_context,
            lang_config=lang_config,
            model=self._model,
            base_url=self._base_url,
            artifact_dag=artifact_dag,  # type: ignore[arg-type]
            repo_root=None,
            api_key=self._api_key,
            provider=self._provider,
            instance=None,
            output_mode=self._output_mode,
            guard_context=instance.context,
            artifact_contexts=artifact_contexts,
        )

        if self._agent_cls is None:
            raise RuntimeError(
                "BenchmarkGym requires agent_cls to be injected at construction time.\n"
                "Pass it as a keyword argument:\n\n"
                "    from atomicguard.application.agent import DualStateAgent\n"
                "    gym = BenchmarkGym(..., agent_cls=DualStateAgent)"
            )
        return TrainingEnvironment(
            workflow=workflow,
            specification=instance.specification,
            reward_fn=reward_fn,
            max_steps=max_steps,
            artifact_dag=artifact_dag,
            enable_backtracking=enable_backtracking,
            max_selections_per_ap=max_selections_per_ap,
            agent_cls=self._agent_cls,
        )

    def build_action_pair_pool_from_file(
        self, file_path: Path
    ) -> tuple[Any, Path, str]:
        """Not implemented for BenchmarkGym.

        BenchmarkGym operates on structured dataset instances rather than
        raw source files.  Use ``PreCommitGym`` for file-based evaluation.
        """
        raise NotImplementedError(
            "BenchmarkGym does not support build_action_pair_pool_from_file. "
            "Use PreCommitGym for file-based policy evaluation."
        )

    def get_workflow_definition(self) -> Any:
        """Return the gym's WorkflowDefinition from its JSON config."""
        from atomicguard.domain.models import ActionPairDefinition, WorkflowDefinition

        config = self._load_workflow_config()
        action_pairs_raw = config.get("action_pairs", {})
        ap_defs = tuple(
            ActionPairDefinition(
                ap_id=ap_id,
                requires=tuple(ap_def.get("requires", [])),
                artifact_type=ap_def.get("artifact_type", ""),
                goal=ap_def.get("goal", False),
                guard=ap_def.get("guard", ""),
            )
            for ap_id, ap_def in action_pairs_raw.items()
        )
        return WorkflowDefinition(
            slug=self._arm_variant,
            name=f"Benchmark TDD ({self._arm})",
            description=f"Benchmark TDD workflow variant: {self._arm}",
            rmax=config.get("rmax", 3),
            action_pairs=ap_defs,
        )

    def build_orchestrator_from_definition(self, definition: Any) -> Any:
        """Not implemented for BenchmarkGym.

        BenchmarkGym uses dataset-backed ``GymInstance`` objects rather than
        file paths, so the ``prepare_instance`` → ``build_orchestrator_from_definition``
        lifecycle does not apply.  Use ``build_environment()`` for training.
        """
        raise NotImplementedError(
            "BenchmarkGym does not support build_orchestrator_from_definition. "
            "Use build_environment() for training and evaluation."
        )

    def get_ap_ids(self) -> tuple[str, ...]:
        """Return AP vocabulary from the workflow config."""
        if self._ap_ids is None:
            config = self._load_workflow_config()
            action_pairs = config.get("action_pairs", {})
            # action_pairs is a dict keyed by ap_id
            self._ap_ids = tuple(action_pairs.keys())
        return self._ap_ids

    def get_manifest(self) -> GymManifest:
        """Return gym metadata."""
        instances = self.get_instances()
        ap_ids = self.get_ap_ids()

        # Determine goal APs from workflow config
        config = self._load_workflow_config()
        action_pairs = config.get("action_pairs", {})
        goal_aps = tuple(
            ap_id for ap_id, ap_def in action_pairs.items() if ap_def.get("goal", False)
        )

        tiers = tuple(sorted({inst.tier for inst in instances}))

        return GymManifest(
            name=self._arm,
            description=f"Benchmark TDD gym ({self._arm}): {len(instances)} tasks across {len(tiers)} tiers",
            ap_ids=ap_ids,
            goal_aps=goal_aps,
            instance_count=len(instances),
            tiers=tiers,
            requires_docker=True,
            requires_llm=True,
            languages=("python",),
        )

    def get_fixed_content(self, instance_dir: Path) -> str:
        """Read the patched file from the instance directory."""
        patch_file = instance_dir / "patch.diff"
        if patch_file.exists():
            return patch_file.read_text()
        return ""

    def cleanup(self) -> None:
        """No resources to release for BenchmarkGym."""
