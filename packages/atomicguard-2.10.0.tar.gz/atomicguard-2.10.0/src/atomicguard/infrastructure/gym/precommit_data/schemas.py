"""Gym-local schema API for precommit gym instances.

Colocated with the data it validates. Uses importlib.resources so this works
both in development (editable install) and when packaged.
"""

from __future__ import annotations

import json
from importlib.resources import files
from typing import Any


def get_precommit_instance_schema() -> dict[str, Any]:
    """Return the precommit_instance JSON Schema dict."""
    schema_text = (
        files("atomicguard.infrastructure.gym.precommit_data")
        .joinpath("precommit_instance.schema.json")
        .read_text(encoding="utf-8")
    )
    return json.loads(schema_text)  # type: ignore[no-any-return]


def validate_precommit_instance(data: dict[str, Any]) -> None:
    """Validate *data* against the precommit instance schema.

    Raises:
        ImportError: if jsonschema is not installed.
        jsonschema.ValidationError: if validation fails.
    """
    try:
        import jsonschema  # noqa: PLC0415
    except ImportError as exc:
        raise ImportError(
            "jsonschema is required for schema validation. "
            "Install it with: pip install jsonschema"
        ) from exc

    schema = get_precommit_instance_schema()
    jsonschema.validate(data, schema)
