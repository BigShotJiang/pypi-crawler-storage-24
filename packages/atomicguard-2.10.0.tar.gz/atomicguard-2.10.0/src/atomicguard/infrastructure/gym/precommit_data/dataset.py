"""Dataset for the pre-commit quality gate gym.

Combines 15 hardcoded synthetic instances with JSON-loaded instances from
``precommit_data/instances/**/*.json``.  Call ``get_precommit_instances()``
to get the full combined list.

Issue categories:
- ``format``: Code has formatting issues (ruff format would change it).
- ``lint``: Code has lint violations (ruff check would flag them).
- ``type``: Code has type errors (mypy would flag them).
- ``test``: Code has bugs that cause test failures.
- ``clean``: No issues — all checks should pass.
"""

from __future__ import annotations

import json
from pathlib import Path

from atomicguard.domain.models import PreCommitInstance
from atomicguard.infrastructure.gym.precommit_data.schemas import (
    validate_precommit_instance as _validate_schema,
)

_DATA_DIR = Path(__file__).parent


def load_instances_from_dir(data_dir: Path) -> list[PreCommitInstance]:
    """Load PreCommitInstance objects from JSON files in data_dir/instances/**/*.json.

    Each JSON file must contain at minimum: ``instance_id``, ``description``,
    ``module_content``, ``test_content``, ``issues`` (list of strings).
    Optional: ``tier`` (int, default 1), ``change_size`` (int, default 0),
    ``source`` (str, ignored — metadata only).

    Raises:
        ValueError: If a JSON file is malformed or missing required fields.
    """
    instances: list[PreCommitInstance] = []
    instances_dir = data_dir / "instances"
    if not instances_dir.exists():
        return []
    for json_file in sorted(instances_dir.glob("**/*.json")):
        try:
            with json_file.open() as f:
                data: dict[str, object] = json.load(f)
        except json.JSONDecodeError as exc:
            raise ValueError(f"{json_file}: invalid JSON: {exc}") from exc
        try:
            _validate_schema(data)
        except ImportError:
            # Fallback: manual required-field check when jsonschema not installed
            required = {
                "instance_id",
                "description",
                "module_content",
                "test_content",
                "issues",
            }
            missing = required - data.keys()
            if missing:
                raise ValueError(
                    f"{json_file}: missing required fields: {missing}"
                ) from None
            if not isinstance(data["issues"], list):
                raise ValueError(f"{json_file}: 'issues' must be a list") from None
        except Exception as exc:
            raise ValueError(f"{json_file}: schema validation failed: {exc}") from exc
        issues_raw = data["issues"]
        if not isinstance(issues_raw, list):
            raise ValueError(
                f"{json_file}: 'issues' must be a list, got {type(issues_raw)}"
            )
        instances.append(
            PreCommitInstance(
                instance_id=str(data["instance_id"]),
                description=str(data["description"]),
                module_content=str(data["module_content"]),
                test_content=str(data["test_content"]),
                issues=frozenset(str(i) for i in issues_raw),
                tier=int(str(data.get("tier", 1))),
                change_size=int(str(data.get("change_size", 0))),
            )
        )
    return instances


def get_precommit_instances() -> list[PreCommitInstance]:
    """Return all pre-commit instances: 15 synthetic hardcoded + JSON-loaded."""
    return _get_synthetic_instances() + load_instances_from_dir(_DATA_DIR)


def _get_synthetic_instances() -> list[PreCommitInstance]:
    """Return the 15 hardcoded synthetic instances."""
    return [
        # ── Tier 1: Single-issue instances ────────────────────
        PreCommitInstance(
            instance_id="pc_format_only_01",
            description="Formatting issue: inconsistent indentation and missing trailing newline",
            module_content="""def   greet( name ):
    return "Hello, "+name
x=1
y =   2
""",
            test_content="""from module import greet

def test_greet():
    assert greet("Alice") == "Hello, Alice"
""",
            issues=frozenset({"format"}),
            tier=1,
            change_size=1,  # 4 lines
        ),
        PreCommitInstance(
            instance_id="pc_format_only_02",
            description="Formatting issue: long lines and inconsistent spacing",
            module_content="""def calculate_total_price_with_tax_and_discount_applied(price,tax_rate,discount_percentage):
    total = price*(1+tax_rate)*(1-discount_percentage)
    return  total

def   format_currency(  amount  ):
    return f"${amount:.2f}"
""",
            test_content="""from module import calculate_total_price_with_tax_and_discount_applied, format_currency

def test_calculate():
    import pytest
    assert calculate_total_price_with_tax_and_discount_applied(100, 0.1, 0.2) == pytest.approx(88.0)

def test_format():
    assert format_currency(42.5) == "$42.50"
""",
            issues=frozenset({"format"}),
            tier=1,
            change_size=1,  # 6 lines
        ),
        PreCommitInstance(
            instance_id="pc_lint_only_01",
            description="Lint issue: unused imports and undefined variable",
            module_content="""import os
import sys
import json

def add(a, b):
    return a + b

result = ad(1, 2)
""",
            test_content="""from module import add

def test_add():
    assert add(1, 2) == 3
""",
            issues=frozenset({"lint"}),
            tier=1,
            change_size=1,  # 8 lines
        ),
        PreCommitInstance(
            instance_id="pc_lint_only_02",
            description="Lint issue: bare except and mutable default argument",
            module_content="""def process_items(items=[]):
    results = []
    for item in items:
        try:
            results.append(int(item))
        except:
            results.append(None)
    return results
""",
            test_content="""from module import process_items

def test_process_items():
    assert process_items(["1", "2", "bad"]) == [1, 2, None]
""",
            issues=frozenset({"lint"}),
            tier=1,
            change_size=1,  # 8 lines
        ),
        PreCommitInstance(
            instance_id="pc_type_only_01",
            description="Type error: incompatible return type and wrong argument type",
            module_content="""def double(x: int) -> int:
    return str(x * 2)

def concat(a: str, b: str) -> str:
    return a + b

result: int = concat("hello", "world")
""",
            test_content="",
            issues=frozenset({"type"}),
            tier=1,
            change_size=1,  # 7 lines
        ),
        PreCommitInstance(
            instance_id="pc_test_only_01",
            description="Test failure: off-by-one bug in range function",
            module_content='''def count_up_to(n: int) -> list[int]:
    """Return [1, 2, ..., n]."""
    return list(range(1, n))
''',
            test_content="""from module import count_up_to

def test_count_up_to():
    assert count_up_to(5) == [1, 2, 3, 4, 5]

def test_count_up_to_one():
    assert count_up_to(1) == [1]
""",
            issues=frozenset({"test"}),
            tier=1,
            change_size=1,  # 3 lines
        ),
        PreCommitInstance(
            instance_id="pc_clean_01",
            description="Clean code: no issues expected",
            module_content='''def fibonacci(n: int) -> list[int]:
    """Return the first n Fibonacci numbers."""
    if n <= 0:
        return []
    if n == 1:
        return [0]
    result = [0, 1]
    for _ in range(2, n):
        result.append(result[-1] + result[-2])
    return result
''',
            test_content="""from module import fibonacci

def test_fibonacci_zero():
    assert fibonacci(0) == []

def test_fibonacci_one():
    assert fibonacci(1) == [0]

def test_fibonacci_five():
    assert fibonacci(5) == [0, 1, 1, 2, 3]
""",
            issues=frozenset(),
            tier=1,
            change_size=1,  # 9 lines
        ),
        # ── Tier 2: Multi-issue instances ────────────────────
        PreCommitInstance(
            instance_id="pc_format_lint_01",
            description="Format + lint: bad spacing and unused import",
            module_content="""import math
import os

def   square( x ):
    return x*x

def cube(x):
    return x*x*x
""",
            test_content="""from module import square, cube

def test_square():
    assert square(3) == 9

def test_cube():
    assert cube(2) == 8
""",
            issues=frozenset({"format", "lint"}),
            tier=2,
            change_size=1,  # 8 lines
        ),
        PreCommitInstance(
            instance_id="pc_lint_type_01",
            description="Lint + type: unused variable and type mismatch",
            module_content="""import sys

unused_var = 42

def safe_divide(a: int, b: int) -> float:
    if b == 0:
        return "error"
    return a / b
""",
            test_content="""from module import safe_divide

def test_safe_divide():
    assert safe_divide(10, 2) == 5.0
""",
            issues=frozenset({"lint", "type"}),
            tier=2,
            change_size=1,  # 7 lines
        ),
        PreCommitInstance(
            instance_id="pc_format_test_01",
            description="Format + test: bad formatting and logic bug",
            module_content="""def   is_palindrome(s:str)->bool:
    cleaned=s.lower().replace(" ","")
    return cleaned==cleaned[::-1]

def reverse_string(s:str)->str:
    return s[:-1]
""",
            test_content="""from module import is_palindrome, reverse_string

def test_palindrome():
    assert is_palindrome("racecar") is True
    assert is_palindrome("hello") is False

def test_reverse():
    assert reverse_string("hello") == "olleh"
""",
            issues=frozenset({"format", "test"}),
            tier=2,
            change_size=1,  # 7 lines
        ),
        PreCommitInstance(
            instance_id="pc_type_test_01",
            description="Type + test: wrong return type annotation and wrong logic",
            module_content='''def max_value(items: list[int]) -> int:
    """Return the maximum value in the list."""
    if not items:
        return None
    return max(items)

def min_value(items: list[int]) -> int:
    """Return the minimum value in the list."""
    return max(items)
''',
            test_content="""from module import max_value, min_value

def test_max_value():
    assert max_value([3, 1, 4, 1, 5]) == 5

def test_min_value():
    assert min_value([3, 1, 4, 1, 5]) == 1

def test_max_empty():
    assert max_value([]) is None
""",
            issues=frozenset({"type", "test"}),
            tier=2,
            change_size=1,  # 8 lines
        ),
        # ── Tier 3: Multiple issues or complex scenarios ─────
        PreCommitInstance(
            instance_id="pc_all_issues_01",
            description="All issues: format + lint + type + test problems",
            module_content="""import os
import json
import re

def   parse_csv_line(line:str)->list:
    parts=line.split(",")
    return parts

def count_words(text:str)->int:
    words=text.split( )
    return len(words)

result:int = parse_csv_line("a,b,c")
""",
            test_content="""from module import parse_csv_line, count_words

def test_parse_csv():
    assert parse_csv_line("a,b,c") == ["a", "b", "c"]

def test_count_words():
    assert count_words("hello world foo") == 3

def test_count_words_empty():
    assert count_words("") == 0
""",
            issues=frozenset({"format", "lint", "type", "test"}),
            tier=3,
            change_size=2,  # 12 lines
        ),
        PreCommitInstance(
            instance_id="pc_all_issues_02",
            description="All issues: complex module with multiple problem types",
            module_content="""import sys
import ast
import collections

class   DataProcessor:
    def __init__(self,data=[]):
        self.data=data

    def process( self )->str:
        total = sum(self.data)
        return total

    def filter_positive(self)->list:
        return [x for x in self.data if x > 0]
""",
            test_content="""from module import DataProcessor

def test_process():
    dp = DataProcessor([1, 2, 3])
    assert dp.process() == "6"

def test_filter_positive():
    dp = DataProcessor([-1, 0, 1, 2])
    assert dp.filter_positive() == [1, 2]
""",
            issues=frozenset({"format", "lint", "type", "test"}),
            tier=3,
            change_size=2,  # 14 lines
        ),
        PreCommitInstance(
            instance_id="pc_clean_02",
            description="Clean code: well-formatted, typed, tested stack implementation",
            module_content='''class Stack:
    """A simple stack implementation."""

    def __init__(self) -> None:
        self._items: list[int] = []

    def push(self, item: int) -> None:
        self._items.append(item)

    def pop(self) -> int:
        if not self._items:
            raise IndexError("pop from empty stack")
        return self._items.pop()

    def peek(self) -> int:
        if not self._items:
            raise IndexError("peek at empty stack")
        return self._items[-1]

    def is_empty(self) -> bool:
        return len(self._items) == 0

    def size(self) -> int:
        return len(self._items)
''',
            test_content="""import pytest

from module import Stack

def test_push_and_pop():
    s = Stack()
    s.push(1)
    s.push(2)
    assert s.pop() == 2
    assert s.pop() == 1

def test_peek():
    s = Stack()
    s.push(42)
    assert s.peek() == 42

def test_is_empty():
    s = Stack()
    assert s.is_empty() is True
    s.push(1)
    assert s.is_empty() is False

def test_pop_empty_raises():
    s = Stack()
    with pytest.raises(IndexError):
        s.pop()
""",
            issues=frozenset(),
            tier=3,
            change_size=2,  # 18 lines
        ),
        PreCommitInstance(
            instance_id="pc_lint_format_type_01",
            description="Format + lint + type: complex multi-issue without test failures",
            module_content="""import os
import re

def   merge_dicts(a:dict,b:dict)->dict:
    result={}
    result.update(a)
    result.update(b)
    return result

def   flatten(nested:list)->list:
    result=[]
    for item in nested:
        if isinstance(item,list):
            result.extend(flatten(item))
        else:
            result.append(item)
    return result

status:int = merge_dicts({"a": 1}, {"b": 2})
""",
            test_content="""from module import merge_dicts, flatten

def test_merge():
    assert merge_dicts({"a": 1}, {"b": 2}) == {"a": 1, "b": 2}

def test_flatten():
    assert flatten([1, [2, 3], [4, [5]]]) == [1, 2, 3, 4, 5]
""",
            issues=frozenset({"format", "lint", "type"}),
            tier=3,
            change_size=2,  # 18 lines
        ),
    ]
