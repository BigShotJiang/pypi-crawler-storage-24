"""AtomicGuard JSON Schema definitions and validation utilities.

This module provides JSON Schema definitions for AtomicGuard configuration files,
aligned with the formal framework defined in the paper.

Schemas:
    - workflow.schema.json: WorkflowOrchestrator definition (action pairs, guards, preconditions)
    - ap_context.schema.json: AP context definitions for generators
    - artifact.schema.json: Artifact storage format in DAG

Usage:
    from atomicguard.schemas import validate_workflow, validate_ap_context

    # Validate a workflow configuration
    with open("workflow.json") as f:
        data = json.load(f)
    validate_workflow(data)  # Raises jsonschema.ValidationError if invalid
"""

from __future__ import annotations

import json
from importlib.resources import files
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    import types

try:
    import jsonschema as _jsonschema

    jsonschema: types.ModuleType | None = _jsonschema
except ImportError:
    jsonschema = None


def _load_schema(name: str) -> dict[str, Any]:
    """Load a JSON schema from the schemas package.

    Args:
        name: Schema filename (e.g., 'workflow.schema.json')

    Returns:
        Parsed JSON schema as a dictionary
    """
    schema_text = files("atomicguard.schemas").joinpath(name).read_text()
    result: dict[str, Any] = json.loads(schema_text)
    return result


def get_workflow_schema() -> dict[str, Any]:
    """Get the workflow.json schema.

    Returns:
        JSON Schema for workflow configuration
    """
    return _load_schema("workflow.schema.json")


def get_ap_context_schema() -> dict[str, Any]:
    """Get the ap_context.json schema.

    Returns:
        JSON Schema for AP context definitions
    """
    return _load_schema("ap_context.schema.json")


def get_artifact_schema() -> dict[str, Any]:
    """Get the artifact.json schema.

    Returns:
        JSON Schema for artifact storage
    """
    return _load_schema("artifact.schema.json")


def get_gym_schema() -> dict[str, Any]:
    """Get the gym.json schema.

    Returns:
        JSON Schema for gym definitions
    """
    return _load_schema("gym.schema.json")


def get_ap_catalogue_schema() -> dict[str, Any]:
    """Get the ap_catalogue.json schema.

    Returns:
        JSON Schema for AP catalogue entries
    """
    return _load_schema("ap_catalogue.schema.json")


def validate_workflow(data: dict[str, Any]) -> None:
    """Validate a workflow configuration against the schema.

    Args:
        data: WorkflowOrchestrator configuration dictionary

    Raises:
        jsonschema.ValidationError: If validation fails
        ImportError: If jsonschema is not installed
    """
    if jsonschema is None:
        raise ImportError(
            "jsonschema is required for validation. "
            "Install it with: pip install jsonschema"
        )
    schema = get_workflow_schema()
    jsonschema.validate(data, schema)


def validate_ap_context(data: dict[str, Any]) -> None:
    """Validate AP context definitions against the schema.

    Args:
        data: AP context configuration dictionary

    Raises:
        jsonschema.ValidationError: If validation fails
        ImportError: If jsonschema is not installed
    """
    if jsonschema is None:
        raise ImportError(
            "jsonschema is required for validation. "
            "Install it with: pip install jsonschema"
        )
    schema = get_ap_context_schema()
    jsonschema.validate(data, schema)


def validate_artifact(data: dict[str, Any]) -> None:
    """Validate an artifact against the schema.

    Args:
        data: Artifact dictionary

    Raises:
        jsonschema.ValidationError: If validation fails
        ImportError: If jsonschema is not installed
    """
    if jsonschema is None:
        raise ImportError(
            "jsonschema is required for validation. "
            "Install it with: pip install jsonschema"
        )
    schema = get_artifact_schema()
    jsonschema.validate(data, schema)


def validate_gym(data: dict[str, Any]) -> None:
    """Validate a gym definition against the schema.

    Args:
        data: Gym definition dictionary

    Raises:
        jsonschema.ValidationError: If validation fails
        ImportError: If jsonschema is not installed
    """
    if jsonschema is None:
        raise ImportError(
            "jsonschema is required for validation. "
            "Install it with: pip install jsonschema"
        )
    schema = get_gym_schema()
    jsonschema.validate(data, schema)


def get_gym_instance_schema() -> dict[str, Any]:
    """Get the gym_instance.schema.json schema (common base fields)."""
    return _load_schema("gym_instance.schema.json")


def validate_gym_instance(data: dict[str, Any]) -> None:
    """Validate *data* against the gym instance base schema.

    Raises:
        ImportError: if jsonschema is not installed.
        jsonschema.ValidationError: if validation fails.
    """
    try:
        import jsonschema as _js  # noqa: PLC0415
    except ImportError as exc:
        raise ImportError(
            "jsonschema is required for schema validation. "
            "Install it with: pip install jsonschema"
        ) from exc

    schema = get_gym_instance_schema()
    _js.validate(data, schema)


def _get_core_schema_entries() -> list[tuple[str, dict[str, Any]]]:
    """Entry point provider: return (id, schema_dict) pairs for all core schemas."""
    return [
        ("atomicguard/workflow.schema.json", get_workflow_schema()),
        ("atomicguard/ap_context.schema.json", get_ap_context_schema()),
        ("atomicguard/artifact.schema.json", get_artifact_schema()),
        ("atomicguard/gym.schema.json", get_gym_schema()),
        ("atomicguard/gym_instance.schema.json", get_gym_instance_schema()),
        ("atomicguard/ap_catalogue.schema.json", get_ap_catalogue_schema()),
    ]


def build_schema_registry() -> Any:
    """Build a jsonschema referencing.Registry from all atomicguard.schemas entry points.

    Each entry point is a callable returning [(schema_id, schema_dict), ...].
    Requires jsonschema >= 4.18 (ships with referencing package).

    Raises:
        ImportError: if jsonschema or referencing is not installed.
    """
    try:
        import referencing  # noqa: PLC0415
        from referencing import jsonschema as referencing_jsonschema  # noqa: PLC0415
    except ImportError as exc:
        raise ImportError(
            "referencing package is required for build_schema_registry(). "
            "Install it with: pip install referencing"
        ) from exc

    from importlib.metadata import entry_points  # noqa: PLC0415

    eps = entry_points(group="atomicguard.schemas")
    resources = []
    for ep in eps:
        provider = ep.load()
        for schema_id, schema_dict in provider():
            resource = referencing.Resource.from_contents(
                schema_dict,
                default_specification=referencing_jsonschema.DRAFT202012,
            )
            resources.append((schema_id, resource))

    registry: referencing.Registry = referencing.Registry().with_resources(resources)
    return registry


def validate_ap_catalogue(data: dict[str, Any]) -> None:
    """Validate AP catalogue data against the schema.

    Args:
        data: AP catalogue dictionary

    Raises:
        jsonschema.ValidationError: If validation fails
        ImportError: If jsonschema is not installed
    """
    if jsonschema is None:
        raise ImportError(
            "jsonschema is required for validation. "
            "Install it with: pip install jsonschema"
        )
    schema = get_ap_catalogue_schema()
    jsonschema.validate(data, schema)


# Backward-compat aliases
get_prompts_schema = get_ap_context_schema
validate_prompts = validate_ap_context

__all__ = [
    "get_workflow_schema",
    "get_ap_context_schema",
    "get_prompts_schema",
    "get_artifact_schema",
    "get_gym_schema",
    "get_ap_catalogue_schema",
    "get_gym_instance_schema",
    "validate_workflow",
    "validate_ap_context",
    "validate_prompts",
    "validate_artifact",
    "validate_gym",
    "validate_ap_catalogue",
    "validate_gym_instance",
    "_get_core_schema_entries",
    "build_schema_registry",
]
