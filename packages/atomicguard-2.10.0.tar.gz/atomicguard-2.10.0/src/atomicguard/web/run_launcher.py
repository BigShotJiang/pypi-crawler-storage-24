"""Launch production runs as subprocesses and monitor their progress."""

from __future__ import annotations

import datetime as dt
import logging
import subprocess
import sys
import threading
from pathlib import Path

from atomicguard.domain.interfaces import RunRepositoryInterface

logger = logging.getLogger(__name__)


def launch_run(run_id: int, repo: RunRepositoryInterface) -> None:
    """Launch a production run as a background subprocess.

    Builds a CLI command from the run config, starts it as a subprocess,
    and spawns a monitor thread that updates the DB when it finishes.
    """
    run = repo.get_run(run_id)

    # Build output directory
    timestamp = dt.datetime.now(dt.UTC).strftime("%Y%m%d_%H%M%S")
    output_dir = str(
        Path("output/experiments") / f"swe_bench_pro_{timestamp}_run{run_id}"
    )

    # Build the CLI command
    cmd = [
        sys.executable,
        "-m",
        "examples.swe_bench_pro.demo",
        "experiment",
        "--model",
        run.model or "moonshotai/kimi-k2-0905",
        "--provider",
        run.provider or "openrouter",
        "--output-dir",
        output_dir,
    ]

    if run.policy_path:
        cmd.extend(["--policy", run.policy_path])
    elif run.arms:
        cmd.extend(["--arms", ",".join(run.arms)])

    if run.language:
        cmd.extend(["--language", run.language])

    if run.max_instances:
        cmd.extend(["--max-instances", str(run.max_instances)])

    if run.max_workers > 1:
        cmd.extend(["--max-workers", str(run.max_workers)])

    logger.info("Launching run %d: %s", run_id, " ".join(cmd))

    # Start the subprocess
    proc = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )

    # Update run status
    now = dt.datetime.now(dt.UTC).isoformat()
    repo.update_run(
        run_id,
        status="running",
        pid=proc.pid,
        started_at=now,
        output_dir=output_dir,
    )

    # Monitor in background thread
    thread = threading.Thread(
        target=_monitor_run,
        args=(run_id, proc, output_dir, repo),
        daemon=True,
    )
    thread.start()


def _monitor_run(
    run_id: int,
    proc: subprocess.Popen[str],
    output_dir: str,
    repo: RunRepositoryInterface,
) -> None:
    """Wait for the subprocess to finish and update the DB."""
    try:
        # Read output for logging
        stdout_lines: list[str] = []
        if proc.stdout:
            for line in proc.stdout:
                stdout_lines.append(line)
                logger.info("[run:%d] %s", run_id, line.rstrip())

        returncode = proc.wait()
        now = dt.datetime.now(dt.UTC).isoformat()

        if returncode == 0:
            # Import results
            results_path = Path(output_dir) / "results.jsonl"
            if results_path.exists():
                repo.import_results_jsonl(run_id, str(results_path))

            repo.update_run(
                run_id,
                status="completed",
                finished_at=now,
            )
            logger.info("Run %d completed successfully", run_id)
        else:
            error_tail = "".join(stdout_lines[-20:]) if stdout_lines else ""
            repo.update_run(
                run_id,
                status="failed",
                finished_at=now,
                error=f"Exit code {returncode}\n{error_tail}"[:2000],
            )
            logger.error("Run %d failed with exit code %d", run_id, returncode)
    except Exception:
        logger.exception("Error monitoring run %d", run_id)
        try:
            repo.update_run(
                run_id,
                status="failed",
                finished_at=dt.datetime.now(dt.UTC).isoformat(),
                error="Monitor thread crashed",
            )
        except Exception:
            logger.exception("Failed to update run %d after monitor crash", run_id)
