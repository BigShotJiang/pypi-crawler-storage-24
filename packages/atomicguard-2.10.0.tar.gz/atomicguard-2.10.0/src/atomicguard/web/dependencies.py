"""FastAPI dependency injection for repository interfaces."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from atomicguard.web.dag_reader import DAGReader

from atomicguard.domain.interfaces import (
    APContextRepositoryInterface,
    GymRepositoryInterface,
    PolicyRepositoryInterface,
    RunRepositoryInterface,
    TrainingObserverInterface,
    TrainingRunRepositoryInterface,
    WorkflowRepositoryInterface,
)
from atomicguard.infrastructure.persistence.sqlite import (
    SQLiteAPContextRepository,
    SQLiteConnection,
    SQLiteGymRepository,
    SQLitePolicyRepository,
    SQLiteRunRepository,
    SqliteTrainingObserver,
    SQLiteTrainingRunRepository,
    SQLiteWorkflowRepository,
)

_conn: SQLiteConnection | None = None
_workflow_repo: SQLiteWorkflowRepository | None = None
_ap_context_repo: SQLiteAPContextRepository | None = None
_run_repo: SQLiteRunRepository | None = None
_training_repo: SQLiteTrainingRunRepository | None = None
_policy_repo: SQLitePolicyRepository | None = None
_gym_repo: SQLiteGymRepository | None = None
_training_observer: SqliteTrainingObserver | None = None


def init_db(db_path: Path) -> SQLiteConnection:
    """Initialise the SQLite connection and create tables if needed."""
    global _conn, _workflow_repo, _ap_context_repo, _run_repo, _training_repo, _policy_repo, _gym_repo, _training_observer  # noqa: PLW0603
    _conn = SQLiteConnection(db_path)
    _conn.init_schema()
    _workflow_repo = SQLiteWorkflowRepository(_conn)
    _ap_context_repo = SQLiteAPContextRepository(_conn)
    _run_repo = SQLiteRunRepository(_conn)
    _training_repo = SQLiteTrainingRunRepository(_conn)
    _policy_repo = SQLitePolicyRepository(_conn)
    _gym_repo = SQLiteGymRepository(_conn)
    _training_observer = SqliteTrainingObserver(_training_repo)
    return _conn


def get_db_connection() -> SQLiteConnection | None:
    """Return the shared SQLiteConnection, or None if DB not initialised."""
    return _conn


def get_workflow_repo() -> WorkflowRepositoryInterface:
    """FastAPI Depends() provider for WorkflowRepositoryInterface."""
    if _workflow_repo is None:
        raise RuntimeError("Database not initialised — call init_db() first")
    return _workflow_repo


def get_ap_context_repo() -> APContextRepositoryInterface:
    """FastAPI Depends() provider for APContextRepositoryInterface."""
    if _ap_context_repo is None:
        raise RuntimeError("Database not initialised — call init_db() first")
    return _ap_context_repo


def get_run_repo() -> RunRepositoryInterface:
    """FastAPI Depends() provider for RunRepositoryInterface."""
    if _run_repo is None:
        raise RuntimeError("Database not initialised — call init_db() first")
    return _run_repo


def get_training_repo() -> TrainingRunRepositoryInterface:
    """FastAPI Depends() provider for TrainingRunRepositoryInterface."""
    if _training_repo is None:
        raise RuntimeError("Database not initialised — call init_db() first")
    return _training_repo


def get_policy_repo() -> PolicyRepositoryInterface:
    """FastAPI Depends() provider for PolicyRepositoryInterface."""
    if _policy_repo is None:
        raise RuntimeError("Database not initialised — call init_db() first")
    return _policy_repo


def get_gym_repo() -> GymRepositoryInterface:
    """FastAPI Depends() provider for GymRepositoryInterface."""
    if _gym_repo is None:
        raise RuntimeError("Database not initialised — call init_db() first")
    return _gym_repo


def get_training_observer() -> TrainingObserverInterface:
    """FastAPI Depends() provider for TrainingObserverInterface."""
    if _training_observer is None:
        raise RuntimeError("Database not initialised — call init_db() first")
    return _training_observer


def create_dag_reader(dag_dir: Path) -> DAGReader:
    """Factory for DAGReader — the only place that wires the concrete DAG adapter.

    Keeps dag_reader.py free of infrastructure imports (DDD boundary compliance).
    """
    from atomicguard.infrastructure.persistence.filesystem import FilesystemArtifactDAG
    from atomicguard.web.dag_reader import DAGReader

    return DAGReader(FilesystemArtifactDAG(str(dag_dir)))
