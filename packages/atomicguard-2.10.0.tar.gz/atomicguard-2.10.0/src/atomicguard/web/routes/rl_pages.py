"""RL training dashboard routes — backward-compatible redirects.

All detail and episode views are served by the training pages router
under /training/.  These routes redirect old /rl/ URLs so bookmarks
and external links continue to work.
"""

from __future__ import annotations

from fastapi import APIRouter
from fastapi.responses import RedirectResponse

router = APIRouter(prefix="/rl")


@router.get("/")
async def rl_root() -> RedirectResponse:
    """Redirect /rl/ to /training/."""
    return RedirectResponse(url="/training/", status_code=301)


@router.get("/{slug}/")
async def rl_detail(slug: str) -> RedirectResponse:
    """Redirect /rl/{slug}/ to /training/{slug}/."""
    return RedirectResponse(url=f"/training/{slug}/", status_code=301)


@router.get("/{slug}/episode/{episode}/")
async def rl_episode(slug: str, episode: int) -> RedirectResponse:
    """Redirect /rl/{slug}/episode/{ep}/ to /training/{slug}/episode/{ep}/."""
    return RedirectResponse(url=f"/training/{slug}/episode/{episode}/", status_code=301)
