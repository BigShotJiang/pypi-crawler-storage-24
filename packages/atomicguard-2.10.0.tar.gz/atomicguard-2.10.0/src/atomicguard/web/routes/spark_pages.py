"""DGX Spark GPU/RAM monitor routes."""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse, JSONResponse

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/spark")


def _ctx(request: Request) -> dict[str, Any]:
    """Base template context."""
    return {"request": request}


def _load_spark_metrics(output_dir: Path | None) -> list[dict[str, Any]]:
    """Load metrics from spark_monitor/metrics.jsonl."""
    if not output_dir:
        return []
    metrics_file = Path(output_dir) / "spark_monitor" / "metrics.jsonl"
    if not metrics_file.exists():
        return []
    metrics: list[dict[str, Any]] = []
    for line in metrics_file.read_text().splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            metrics.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return metrics


@router.get("/", response_class=HTMLResponse)
async def spark_monitor(request: Request) -> HTMLResponse:
    """Spark GPU/RAM monitor page."""
    output_dir = getattr(request.app.state, "output_dir", None)
    metrics = _load_spark_metrics(output_dir)
    latest = metrics[-1] if metrics else None
    templates = request.app.state.templates
    return templates.TemplateResponse(
        "spark_monitor.html",
        {
            **_ctx(request),
            "latest": latest,
            "metrics_json": json.dumps(metrics),
            "metric_count": len(metrics),
        },
    )


@router.get("/api/metrics", response_class=JSONResponse)
async def spark_api_metrics(request: Request) -> JSONResponse:
    """Return spark metrics as JSON array (for chart JS fetch)."""
    output_dir = getattr(request.app.state, "output_dir", None)
    metrics = _load_spark_metrics(output_dir)
    return JSONResponse(content=metrics)
