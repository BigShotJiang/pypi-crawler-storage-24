"""Policy library routes — list, detail, scan, export to workflow."""

from __future__ import annotations

import contextlib
import json
import logging
from dataclasses import replace
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Depends, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse

from atomicguard.domain.interfaces import (
    PolicyRepositoryInterface,
    TrainingRunRepositoryInterface,
    WorkflowRepositoryInterface,
)

from ..dependencies import get_policy_repo, get_training_repo, get_workflow_repo
from ..utils import slugify

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/policies", tags=["policies"])


def _ctx(request: Request) -> dict[str, Any]:
    return {
        "request": request,
        "config_loader": getattr(request.app.state, "config_loader", None),
        "nav_active": "policies",
    }


# ─── List ──────────────────────────────────────────────────


@router.get("/", response_class=HTMLResponse)
async def policy_list(
    request: Request,
    repo: PolicyRepositoryInterface = Depends(get_policy_repo),
) -> HTMLResponse:
    """List all policies in the library."""
    policies = repo.list_policies(limit=100)
    templates = request.app.state.templates
    return templates.TemplateResponse(
        "policy_list.html",
        {**_ctx(request), "policies": policies},
    )


# ─── Detail ────────────────────────────────────────────────


@router.get("/{slug}/", response_class=HTMLResponse)
async def policy_detail(
    request: Request,
    slug: str,
    repo: PolicyRepositoryInterface = Depends(get_policy_repo),
    training_repo: TrainingRunRepositoryInterface = Depends(get_training_repo),
    wf_repo: WorkflowRepositoryInterface = Depends(get_workflow_repo),
) -> HTMLResponse:
    """Policy detail with Q-table heatmap and provenance."""
    try:
        policy = repo.get_policy_by_slug(slug)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Policy not found") from exc

    # Load training run if linked
    training_run = None
    if policy.training_run_id:
        with contextlib.suppress(KeyError):
            training_run = training_repo.get_run(policy.training_run_id)

    # Load Q-table data from filesystem for heatmap
    policy_json = "null"
    greedy_ordering: list[str] = []

    from ..rl_loader import load_policy_info_from_checkpoint

    policy_path = Path(policy.path) if policy.path else None
    if policy_path and policy_path.is_dir():
        # The path is a checkpoint dir — load Q-table from this specific checkpoint
        policy_info = load_policy_info_from_checkpoint(policy_path)
        if policy_info:
            policy_json = json.dumps(
                {
                    "ap_ids": policy_info.ap_ids,
                    "num_states": policy_info.num_states,
                    "num_actions": policy_info.num_actions,
                    "q_table": policy_info.q_table,
                    "visit_counts": policy_info.visit_counts,
                    "greedy_actions": policy_info.greedy_actions,
                    "total_visits": policy_info.total_visits,
                }
            )
            # Extract greedy ordering for the export preview
            greedy_ordering = _extract_greedy_ordering(policy_path)

    # Workflows available for export base
    workflows = wf_repo.list_workflows()

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "policy_detail.html",
        {
            **_ctx(request),
            "breadcrumbs": [("Policies", "/policies/"), (policy.display_name, "")],
            "policy": policy,
            "training_run": training_run,
            "policy_json": policy_json,
            "greedy_ordering": greedy_ordering,
            "workflows": workflows,
        },
    )


# ─── Export to Workflow ─────────────────────────────────────


def _extract_greedy_ordering(checkpoint_path: Path) -> list[str]:
    """Load policy and extract greedy trace ordering. Returns [] on failure."""
    from ..policy_loader import extract_greedy_ordering

    return extract_greedy_ordering(checkpoint_path)


def _load_tabular_policy(checkpoint_path: str) -> Any:
    """Load a TabularPolicy from a checkpoint directory."""
    from ..policy_loader import load_tabular_policy

    return load_tabular_policy(checkpoint_path)


@router.post("/{slug}/export-to-workflow", response_class=HTMLResponse)
async def export_policy_to_workflow(
    slug: str,
    base_workflow_slug: str = Form(...),
    workflow_name: str = Form(""),
    repo: PolicyRepositoryInterface = Depends(get_policy_repo),
    wf_repo: WorkflowRepositoryInterface = Depends(get_workflow_repo),
) -> HTMLResponse:
    """Export a trained policy to a new editable workflow."""
    from ..policy_loader import export_policy_to_workflow

    try:
        policy_record = repo.get_policy_by_slug(slug)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Policy not found") from exc

    try:
        base_workflow = wf_repo.get_workflow(base_workflow_slug)
    except KeyError as exc:
        raise HTTPException(
            status_code=404, detail=f"Base workflow '{base_workflow_slug}' not found"
        ) from exc

    try:
        tab_policy = _load_tabular_policy(policy_record.path)
    except (FileNotFoundError, ValueError) as exc:
        raise HTTPException(
            status_code=400, detail=f"Cannot load policy: {exc}"
        ) from exc

    exported = export_policy_to_workflow(tab_policy, base_workflow)

    # Generate slug and name
    name = workflow_name.strip() or f"{policy_record.display_name} — exported"
    new_slug = slugify(name)

    # Ensure unique slug
    existing = {w.slug for w in wf_repo.list_workflows()}
    base_slug = new_slug
    counter = 2
    while new_slug in existing:
        new_slug = f"{base_slug}-{counter}"
        counter += 1

    exported_with_provenance = replace(
        exported,
        slug=new_slug,
        name=name,
        source_policy_slug=slug,
    )
    wf_repo.save_workflow(exported_with_provenance)

    return HTMLResponse(
        content="",
        status_code=200,
        headers={"HX-Redirect": f"/workflows/{new_slug}/edit"},
    )


# ─── Scan ──────────────────────────────────────────────────


@router.post("/scan", response_class=HTMLResponse)
async def policy_scan(
    request: Request,
    repo: PolicyRepositoryInterface = Depends(get_policy_repo),
) -> RedirectResponse:
    """Scan checkpoint directories and import new policies."""
    output_dir = getattr(request.app.state, "output_dir", None)
    if not output_dir:
        raise HTTPException(status_code=400, detail="No output directory configured")

    repo.scan_checkpoints(str(output_dir))
    return RedirectResponse(url="/policies/", status_code=303)
