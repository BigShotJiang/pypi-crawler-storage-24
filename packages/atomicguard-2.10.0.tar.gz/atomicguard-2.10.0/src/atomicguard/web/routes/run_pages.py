"""Production run management routes — list, detail, create, and status."""

from __future__ import annotations

import contextlib
import datetime as dt
from typing import Any

from fastapi import APIRouter, Depends, Form, HTTPException, Request
from fastapi.responses import HTMLResponse

from atomicguard.domain.interfaces import (
    PolicyRepositoryInterface,
    RunRepositoryInterface,
    WorkflowRepositoryInterface,
)
from atomicguard.domain.models import ProductionRun

from ..dependencies import get_policy_repo, get_run_repo, get_workflow_repo

router = APIRouter(prefix="/runs", tags=["runs"])

# Available arms for the form (mirrors demo.py _ARM_MAP)
AVAILABLE_ARMS = [
    "singleshot",
    "s1_direct",
    "s1_tdd",
    "s1_tdd_verified",
    "s1_tdd_behavior",
    "s1_decomposed",
    "s1_decomposed_lite",
    "s1_tdd_review",
    "s1_tdd_review_backtrack",
    "s1_tdd_rule_backtrack",
    "adaptive_backtrack",
    "s1_tdd_eval",
    "s1_decomposed_lite_eval",
    "singleshot_eval",
]


def _now_iso() -> str:
    return dt.datetime.now(dt.UTC).isoformat()


def _ctx(request: Request) -> dict[str, Any]:
    """Base template context."""
    return {
        "request": request,
        "config_loader": request.app.state.config_loader,
        "nav_active": "runs",
    }


# ─── List ──────────────────────────────────────────────────


@router.get("/", response_class=HTMLResponse)
async def run_list(
    request: Request,
    status: str = "",
    repo: RunRepositoryInterface = Depends(get_run_repo),
) -> HTMLResponse:
    """List production runs with optional status filter."""
    runs = repo.list_runs(status=status or None, limit=100)

    templates = request.app.state.templates
    ctx = {
        **_ctx(request),
        "runs": runs,
        "status_filter": status,
    }

    if request.headers.get("HX-Request"):
        return templates.TemplateResponse("partials/run_cards.html", ctx)

    return templates.TemplateResponse("run_list.html", ctx)


# ─── Detail ────────────────────────────────────────────────


@router.get("/{run_id}/", response_class=HTMLResponse)
async def run_detail(
    request: Request,
    run_id: int,
    repo: RunRepositoryInterface = Depends(get_run_repo),
) -> HTMLResponse:
    """Run detail page with guard result timeline."""
    try:
        run = repo.get_run(run_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Run not found") from exc

    guard_results = repo.get_guard_results(run_id, limit=500)

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "run_detail.html",
        {
            **_ctx(request),
            "breadcrumbs": [("Runs", "/runs/"), (f"Run #{run.id}", "")],
            "run": run,
            "guard_results": guard_results,
        },
    )


# ─── Status partial (for HTMX polling) ────────────────────


@router.get("/{run_id}/status", response_class=HTMLResponse)
async def run_status_partial(
    request: Request,
    run_id: int,
    repo: RunRepositoryInterface = Depends(get_run_repo),
) -> HTMLResponse:
    """Return run status card as HTMX partial for polling."""
    try:
        run = repo.get_run(run_id)
    except KeyError as exc:
        raise HTTPException(status_code=404) from exc

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "partials/run_status_card.html",
        {**_ctx(request), "run": run},
    )


# ─── Guard results partial ────────────────────────────────


@router.get("/{run_id}/guard-results", response_class=HTMLResponse)
async def run_guard_results_partial(
    request: Request,
    run_id: int,
    instance_id: str = "",
    repo: RunRepositoryInterface = Depends(get_run_repo),
) -> HTMLResponse:
    """Return guard results table as HTMX partial."""
    guard_results = repo.get_guard_results(
        run_id,
        instance_id=instance_id or None,
        limit=500,
    )

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "partials/guard_results_table.html",
        {**_ctx(request), "guard_results": guard_results, "run_id": run_id},
    )


# ─── Create form ──────────────────────────────────────────


@router.get("/new", response_class=HTMLResponse)
async def run_new_form(
    request: Request,
    policy: str = "",
    wf_repo: WorkflowRepositoryInterface = Depends(get_workflow_repo),
    policy_repo: PolicyRepositoryInterface = Depends(get_policy_repo),
) -> HTMLResponse:
    """Show the new run configuration form."""
    workflows = wf_repo.list_workflows()
    policies = policy_repo.list_policies(limit=100)

    # Pre-select policy if passed via query param
    selected_policy = None
    if policy:
        with contextlib.suppress(KeyError):
            selected_policy = policy_repo.get_policy_by_slug(policy)

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "run_new.html",
        {
            **_ctx(request),
            "workflows": workflows,
            "available_arms": AVAILABLE_ARMS,
            "policies": policies,
            "selected_policy": selected_policy,
        },
    )


@router.post("/", response_class=HTMLResponse)
async def run_create(
    workflow_slug: str = Form(...),
    model: str = Form(""),
    provider: str = Form("openrouter"),
    arms: str = Form(""),
    policy_path: str = Form(""),
    language: str = Form(""),
    max_instances: int = Form(0),
    max_workers: int = Form(1),
    repo: RunRepositoryInterface = Depends(get_run_repo),
) -> HTMLResponse:
    """Create a new production run and redirect to its detail page."""
    arms_list = tuple(a.strip() for a in arms.split(",") if a.strip())

    run = ProductionRun(
        id=0,  # assigned by DB
        workflow_slug=workflow_slug.strip(),
        model=model.strip(),
        provider=provider.strip(),
        arms=arms_list,
        policy_path=policy_path.strip(),
        language=language.strip() or None,
        max_instances=max_instances if max_instances > 0 else None,
        max_workers=max(1, max_workers),
        status="pending",
        created_at=_now_iso(),
    )
    run_id = repo.create_run(run)

    return HTMLResponse(
        content="",
        status_code=200,
        headers={"HX-Redirect": f"/runs/{run_id}/"},
    )


# ─── Start / Cancel ───────────────────────────────────────


@router.post("/{run_id}/start", response_class=HTMLResponse)
async def run_start(
    run_id: int,
    repo: RunRepositoryInterface = Depends(get_run_repo),
) -> HTMLResponse:
    """Launch the production run as a subprocess."""
    try:
        run = repo.get_run(run_id)
    except KeyError as exc:
        raise HTTPException(status_code=404) from exc

    if run.status not in ("pending", "failed"):
        raise HTTPException(
            status_code=400,
            detail=f"Cannot start run in '{run.status}' status",
        )

    from ..run_launcher import launch_run

    try:
        launch_run(run_id, repo)
    except Exception as exc:
        repo.update_run(
            run_id,
            status="failed",
            error=str(exc),
            finished_at=_now_iso(),
        )
        raise HTTPException(status_code=500, detail=str(exc)) from exc

    return HTMLResponse(
        content="",
        status_code=200,
        headers={"HX-Redirect": f"/runs/{run_id}/"},
    )


@router.post("/{run_id}/cancel", response_class=HTMLResponse)
async def run_cancel(
    run_id: int,
    repo: RunRepositoryInterface = Depends(get_run_repo),
) -> HTMLResponse:
    """Cancel a running production run."""
    import os
    import signal

    try:
        run = repo.get_run(run_id)
    except KeyError as exc:
        raise HTTPException(status_code=404) from exc

    if run.status != "running":
        raise HTTPException(
            status_code=400,
            detail=f"Cannot cancel run in '{run.status}' status",
        )

    if run.pid:
        with contextlib.suppress(ProcessLookupError):
            os.kill(run.pid, signal.SIGTERM)

    repo.update_run(
        run_id,
        status="cancelled",
        finished_at=_now_iso(),
    )

    return HTMLResponse(
        content="",
        status_code=200,
        headers={"HX-Redirect": f"/runs/{run_id}/"},
    )


# ─── Import results ───────────────────────────────────────


@router.post("/{run_id}/import-results", response_class=HTMLResponse)
async def run_import_results(
    request: Request,
    run_id: int,
    repo: RunRepositoryInterface = Depends(get_run_repo),
) -> HTMLResponse:
    """Import results.jsonl into the run's guard_results table."""
    try:
        run = repo.get_run(run_id)
    except KeyError as exc:
        raise HTTPException(status_code=404) from exc

    if not run.output_dir:
        raise HTTPException(status_code=400, detail="Run has no output directory")

    from pathlib import Path

    results_path = Path(run.output_dir) / "results.jsonl"
    count = repo.import_results_jsonl(run_id, str(results_path))

    templates = request.app.state.templates
    updated_run = repo.get_run(run_id)
    return templates.TemplateResponse(
        "partials/run_status_card.html",
        {**_ctx(request), "run": updated_run, "import_count": count},
    )
