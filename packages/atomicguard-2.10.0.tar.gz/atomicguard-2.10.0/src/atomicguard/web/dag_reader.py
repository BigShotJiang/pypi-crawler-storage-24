"""Read-only DAG wrapper for the dashboard."""

from __future__ import annotations

from atomicguard.domain.interfaces import ArtifactDAGInterface
from atomicguard.visualization.html_exporter import (
    WorkflowVisualizationData,
    _serialize_artifact,
    extract_workflow_data,
)


class DAGReader:
    """Read-only wrapper around an ArtifactDAGInterface."""

    def __init__(self, dag: ArtifactDAGInterface) -> None:
        self._dag = dag

    def get_visualization_data(self) -> WorkflowVisualizationData:
        """Extract full visualization data (nodes, edges, artifacts, runs)."""
        return extract_workflow_data(self._dag)

    def get_visualization_data_for_episode(
        self,
        workflow_id: str | None = None,
        time_start: float | None = None,
        time_end: float | None = None,
    ) -> WorkflowVisualizationData:
        """Extract visualization data for a specific training episode.

        Filtering priority:
        1. workflow_id — exact match (future runs with per-episode IDs)
        2. time_start/time_end — created_at window (intermediate runs)
        3. No filters — return all artifacts (oldest runs)

        Args:
            workflow_id: Filter by exact workflow_id (e.g. "training_ep0042").
            time_start: Include artifacts created at or after this timestamp.
            time_end: Include artifacts created before this timestamp.

        Returns:
            WorkflowVisualizationData for the filtered artifact set.
        """
        if workflow_id:
            return extract_workflow_data(self._dag, workflow_id=workflow_id)

        all_artifacts = self._dag.get_all()
        if time_start is not None or time_end is not None:
            from datetime import datetime

            filtered = []
            for a in all_artifacts:
                try:
                    ts = datetime.fromisoformat(a.created_at).timestamp()
                except (ValueError, TypeError):
                    continue
                if time_start is not None and ts < time_start:
                    continue
                if time_end is not None and ts >= time_end:
                    continue
                filtered.append(a)
            return extract_workflow_data(self._dag, artifacts_override=filtered)

        # No filters — return full instance DAG
        return extract_workflow_data(self._dag)

    def get_artifact_detail(self, artifact_id: str) -> dict:
        """Serialize a single artifact for the sidebar."""
        return _serialize_artifact(self._dag.get_artifact(artifact_id))
