"""Launch RL training runs as subprocesses and monitor their progress."""

from __future__ import annotations

import datetime as dt
import logging
import subprocess
import sys
import threading

from atomicguard.domain.interfaces import TrainingRunRepositoryInterface

logger = logging.getLogger(__name__)


def launch_training(
    run_id: int,
    repo: TrainingRunRepositoryInterface,
    model: str,
    provider: str,
    base_url: str,
    arm: str,
    reward: str,
    episodes: int,
    max_steps: int,
    gamma: float,
    epsilon: float,
    epsilon_decay: float,
    alpha: float,
    instances: int,
    language: str,
    checkpoint_dir: str,
    gym_slug: str | None = None,
    checkpoint_interval: int = 5,
    instance_ids: list[str] | None = None,
) -> None:
    """Launch an RL training run as a background subprocess.

    When *gym_slug* is provided the training is dispatched via the gym CLI
    (``python -m atomicguard.gym train``).  Otherwise the legacy
    ``examples.swe_bench_pro.rl_training`` entry point is used.
    """
    if gym_slug:
        cmd = _build_gym_cmd(
            gym_slug=gym_slug,
            model=model,
            provider=provider,
            base_url=base_url,
            reward=reward,
            episodes=episodes,
            max_steps=max_steps,
            gamma=gamma,
            epsilon=epsilon,
            epsilon_decay=epsilon_decay,
            alpha=alpha,
            instances=instances,
            checkpoint_dir=checkpoint_dir,
            checkpoint_interval=checkpoint_interval,
            instance_ids=instance_ids,
        )
    else:
        cmd = _build_legacy_cmd(
            model=model,
            provider=provider,
            base_url=base_url,
            arm=arm,
            reward=reward,
            episodes=episodes,
            max_steps=max_steps,
            gamma=gamma,
            epsilon=epsilon,
            epsilon_decay=epsilon_decay,
            alpha=alpha,
            instances=instances,
            language=language,
            checkpoint_dir=checkpoint_dir,
        )

    logger.info("Launching training %d: %s", run_id, " ".join(cmd))

    proc = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )

    repo.update_run(
        run_id, status="in_progress", updated_at=dt.datetime.now(dt.UTC).isoformat()
    )

    thread = threading.Thread(
        target=_monitor_training,
        args=(run_id, proc, checkpoint_dir, repo),
        daemon=True,
    )
    thread.start()


def _build_gym_cmd(
    *,
    gym_slug: str,
    model: str,
    provider: str,
    base_url: str,
    reward: str,
    episodes: int,
    max_steps: int,
    gamma: float,
    epsilon: float,
    epsilon_decay: float,
    alpha: float,
    instances: int,
    checkpoint_dir: str,
    checkpoint_interval: int = 5,
    instance_ids: list[str] | None = None,
) -> list[str]:
    """Build command for ``python -m atomicguard.gym train``."""
    cmd = [
        sys.executable,
        "-m",
        "atomicguard.gym",
        "train",
        "--gym",
        gym_slug,
        "--model",
        model or "moonshotai/kimi-k2-0905",
        "--provider",
        provider or "openrouter",
        "--base-url",
        base_url or "http://localhost:11434/v1",
        "--reward",
        reward or "potential-based",
        "--episodes",
        str(episodes),
        "--gamma",
        str(gamma),
        "--epsilon",
        str(epsilon),
        "--epsilon-decay",
        str(epsilon_decay),
        "--alpha",
        str(alpha),
        "--instances",
        str(instances),
        "--checkpoint-dir",
        checkpoint_dir,
        "--checkpoint-interval",
        str(checkpoint_interval),
    ]
    if max_steps > 0:
        cmd.extend(["--max-steps", str(max_steps)])
    if instance_ids:
        cmd.extend(["--instance-ids", ",".join(instance_ids)])
    return cmd


def _build_legacy_cmd(
    *,
    model: str,
    provider: str,
    base_url: str,
    arm: str,
    reward: str,
    episodes: int,
    max_steps: int,
    gamma: float,
    epsilon: float,
    epsilon_decay: float,
    alpha: float,
    instances: int,
    language: str,
    checkpoint_dir: str,
) -> list[str]:
    """Build command for legacy ``examples.swe_bench_pro.rl_training``."""
    cmd = [
        sys.executable,
        "-m",
        "examples.swe_bench_pro.rl_training",
        "--model",
        model or "moonshotai/kimi-k2-0905",
        "--provider",
        provider or "openrouter",
        "--base-url",
        base_url or "",
        "--arm",
        arm or "s1_tdd_rule_backtrack",
        "--reward",
        reward or "potential-based",
        "--episodes",
        str(episodes),
        "--gamma",
        str(gamma),
        "--epsilon",
        str(epsilon),
        "--epsilon-decay",
        str(epsilon_decay),
        "--alpha",
        str(alpha),
        "--instances",
        str(instances),
        "--checkpoint-dir",
        checkpoint_dir,
    ]
    if max_steps > 0:
        cmd.extend(["--max-steps", str(max_steps)])
    if language:
        cmd.extend(["--language", language])
    return cmd


def _monitor_training(
    run_id: int,
    proc: subprocess.Popen[str],
    checkpoint_dir: str,
    repo: TrainingRunRepositoryInterface,
) -> None:
    """Wait for the training subprocess to finish and update the DB."""
    try:
        if proc.stdout:
            for line in proc.stdout:
                logger.info("[training:%d] %s", run_id, line.rstrip())

        returncode = proc.wait()
        now = dt.datetime.now(dt.UTC).isoformat()

        if returncode == 0:
            # Import episode log from filesystem
            repo.import_from_filesystem(checkpoint_dir)
            repo.update_run(run_id, status="complete", updated_at=now)
            logger.info("Training %d completed successfully", run_id)
        else:
            repo.update_run(run_id, status="terminated", updated_at=now)
            logger.error("Training %d failed with exit code %d", run_id, returncode)
    except Exception:
        logger.exception("Error monitoring training %d", run_id)
        try:
            repo.update_run(
                run_id,
                status="terminated",
                updated_at=dt.datetime.now(dt.UTC).isoformat(),
            )
        except Exception:
            logger.exception("Failed to update training %d after monitor crash", run_id)
