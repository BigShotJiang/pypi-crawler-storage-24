"""Load trained RL policies and export to workflows for web routes.

This module bridges the web layer to the infrastructure and application layers
for policy-related operations. Route modules import from here instead of
importing infrastructure/application directly.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING, Any

import numpy as np

if TYPE_CHECKING:
    from atomicguard.domain.models import WorkflowDefinition

logger = logging.getLogger(__name__)


def extract_greedy_ordering(checkpoint_path: Path) -> list[str]:
    """Load policy from checkpoint and extract greedy trace ordering.

    Returns empty list on failure.
    """
    try:
        from atomicguard.infrastructure.rl.policy import TabularPolicy

        p = Path(checkpoint_path)
        npz_path = p / "qtable.npz" if p.is_dir() else p
        if not npz_path.exists():
            return []
        data = np.load(npz_path, allow_pickle=True)
        ap_ids = tuple(str(x) for x in data["ap_ids"]) if "ap_ids" in data else ()
        if not ap_ids:
            return []
        policy = TabularPolicy(num_action_pairs=len(ap_ids), action_pair_ids=ap_ids)
        policy.load(p)
        return policy.greedy_trace()
    except Exception:
        logger.debug("Failed to extract greedy ordering", exc_info=True)
        return []


def load_tabular_policy(checkpoint_path: str | Path) -> Any:
    """Load a TabularPolicy from a checkpoint directory.

    Raises FileNotFoundError if qtable.npz is missing, ValueError if no ap_ids.
    """
    from atomicguard.infrastructure.rl.policy import TabularPolicy

    p = Path(checkpoint_path)
    npz_path = p / "qtable.npz" if p.is_dir() else p
    if not npz_path.exists():
        raise FileNotFoundError(f"Q-table not found at {npz_path}")
    data = np.load(npz_path, allow_pickle=True)
    ap_ids = tuple(str(x) for x in data["ap_ids"]) if "ap_ids" in data else ()
    if not ap_ids:
        raise ValueError("Checkpoint has no ap_ids")
    policy = TabularPolicy(num_action_pairs=len(ap_ids), action_pair_ids=ap_ids)
    policy.load(p)
    return policy


def export_policy_to_workflow(
    policy: Any,
    base_workflow: WorkflowDefinition,
) -> WorkflowDefinition:
    """Export a trained policy to a new WorkflowDefinition.

    Delegates to ``PolicyExporter.export()`` in the application layer.
    """
    from atomicguard.application.policy_export import PolicyExporter

    exporter = PolicyExporter(policy)
    return exporter.export(base_workflow)
