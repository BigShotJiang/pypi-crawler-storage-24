"""Production policy runner — apply a trained RL policy to real source files.

Discovers files under a target path using the gym's manifest-driven file
patterns, exports the policy's greedy ordering via ``PolicyExporter``,
and executes via ``WorkflowOrchestrator.execute()``.

The lifecycle::

    checkpoint → PolicyExporter.export(base_def) → exported_def (policy ordering)
    gym.prepare_instance(file_path) → GymInstanceContext
    gym.build_orchestrator_from_definition(exported_def) → WorkflowExecutorInterface
    executor.execute(ctx.specification) → WorkflowResult

Production always routes through ``WorkflowOrchestrator.execute()``,
which provides retry, backtracking, cascade invalidation, and escalation.
The policy's learned AP ordering drives execution via ``PolicyExporter``-derived
``requires`` edges.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from atomicguard.domain.gym import GymInterface
    from atomicguard.domain.interfaces import PolicyInterface

logger = logging.getLogger(__name__)


class FileStatus(str, Enum):
    FIXED = "FIXED"
    FAILED = "FAILED"


@dataclass
class FileResult:
    file: Path
    status: FileStatus
    steps: int = 0
    message: str = ""
    unsatisfied_aps: tuple[str, ...] = ()
    artifacts: list[Any] = field(default_factory=list)


def _collect_files(target: Path, patterns: tuple[str, ...]) -> list[Path]:
    """Collect files matching *patterns* under *target*.

    If *target* is a file, returns it directly regardless of patterns.
    """
    if target.is_file():
        return [target]
    files: set[Path] = set()
    for pattern in patterns:
        files.update(target.rglob(pattern))
    return sorted(files)


def run_policy_on_path(
    policy_path: Path,
    target_path: Path,
    gym_name: str = "precommit_python",
    model: str | None = None,
    provider: str | None = None,
    base_url: str = "http://localhost:11434/v1",
    api_key: str = "",
    dry_run: bool = False,
) -> list[FileResult]:
    """Apply a trained policy to files under *target_path*.

    Uses the three-phase gym interface (``get_workflow_definition`` →
    ``prepare_instance`` → ``build_orchestrator_from_definition``) for
    production-quality execution with retry, backtracking, cascade
    invalidation, and escalation.

    Args:
        policy_path: Path to checkpoint directory (or ``latest`` symlink).
        target_path: File or directory to scan.
        gym_name: Gym whose AP vocabulary the policy was trained on.
        model: LLM model ID (falls back to training_config.json value).
        provider: LLM provider (falls back to training_config.json value).
        base_url: LLM API base URL.
        api_key: LLM API key.
        dry_run: If True, do not write fixed content back to disk.

    Returns:
        List of :class:`FileResult` — one per discovered file.
    """
    from atomicguard.application.action_pair import ActionPair
    from atomicguard.application.workflow import WorkflowOrchestrator
    from atomicguard.gym import GYM_REGISTRY
    from atomicguard.gym.__main__ import _instantiate_gym
    from atomicguard.tools.export_workflow import load_training_artifacts

    # ------------------------------------------------------------------ #
    # Load policy and training config                                      #
    # ------------------------------------------------------------------ #
    policy, training_config, _meta = load_training_artifacts(policy_path, greedy=True)

    ap_ids: tuple[str, ...] = tuple(training_config.get("ap_ids", []))
    if not ap_ids:
        raise ValueError(
            "training_config.json missing 'ap_ids'. "
            "Re-run training to generate a valid checkpoint."
        )

    resolved_model = model or training_config.get("model", "qwen3-coder-next")
    resolved_provider = provider or training_config.get("provider", "ollama")

    logger.info(
        "Policy loaded: %d APs, model=%s (%s)",
        len(ap_ids),
        resolved_model,
        resolved_provider,
    )

    # ------------------------------------------------------------------ #
    # Instantiate gym                                                       #
    # ------------------------------------------------------------------ #
    gym_cls = GYM_REGISTRY.get(gym_name)
    if gym_cls is None:
        raise ValueError(
            f"Unknown gym: {gym_name!r}. Available: {sorted(GYM_REGISTRY)}"
        )
    gym = _instantiate_gym(
        gym_cls,
        gym_name,
        model=resolved_model,
        provider=resolved_provider,
        base_url=base_url,
        api_key=api_key,
        llm_timeout=int(training_config.get("llm_timeout", 120)),
        action_pair_cls=ActionPair,
        workflow_cls=WorkflowOrchestrator,
    )

    # Use gym manifest for file discovery instead of hardcoded *.py
    file_patterns = gym.get_file_glob_patterns()

    # ------------------------------------------------------------------ #
    # Process files                                                         #
    # ------------------------------------------------------------------ #
    files = _collect_files(target_path, file_patterns)
    results: list[FileResult] = []

    try:
        for file_path in files:
            result = _process_file(
                file_path=file_path,
                gym=gym,
                policy=policy,
                dry_run=dry_run,
            )
            results.append(result)
    finally:
        gym.cleanup()

    return results


def _process_file(
    *,
    file_path: Path,
    gym: GymInterface,
    policy: PolicyInterface,
    dry_run: bool,
) -> FileResult:
    """Run the policy on a single file via ``WorkflowOrchestrator.execute()``.

    The three-phase production lifecycle:
    1. ``PolicyExporter.export(base_def)`` — derive policy-ordered requires edges.
    2. ``gym.prepare_instance(file_path)`` — set up temp dir, Docker, files.
    3. ``gym.build_orchestrator_from_definition(exported_def)`` — wire generators/guards.
    """
    from atomicguard.domain.models import WorkflowStatus
    from atomicguard.domain.policy_export import PolicyExporter

    logger.info("Running policy on %s", file_path)

    # Phase 1: export policy ordering into a WorkflowDefinition with new requires edges.
    try:
        exporter = PolicyExporter(policy)
        base_def = gym.get_workflow_definition()
        exported_def = exporter.export(base_def)
        ordering = exporter.ordering()
        logger.info("Policy greedy ordering: %s", " → ".join(ordering))
    except Exception as exc:
        logger.warning("Failed to export policy ordering for %s: %s", file_path, exc)
        return FileResult(
            file=file_path,
            status=FileStatus.FAILED,
            message=f"policy export failed: {exc}",
        )

    # Phase 2: prepare instance (temp dir, Docker container, file copy).
    try:
        ctx = gym.prepare_instance(file_path)
    except Exception as exc:
        logger.warning("Failed to prepare instance for %s: %s", file_path, exc)
        return FileResult(
            file=file_path,
            status=FileStatus.FAILED,
            message=f"instance setup failed: {exc}",
        )

    # Phase 3: build executor with policy-ordered requires edges.
    try:
        executor = gym.build_orchestrator_from_definition(exported_def)
    except Exception as exc:
        logger.warning("Failed to build orchestrator for %s: %s", file_path, exc)
        return FileResult(
            file=file_path,
            status=FileStatus.FAILED,
            message=f"orchestrator build failed: {exc}",
        )

    # Execute via WorkflowOrchestrator — retry, backtracking, cascade
    # invalidation, and escalation are all handled by the production executor.
    try:
        result = executor.execute(ctx.specification)

        if result.status == WorkflowStatus.SUCCESS:
            # Read fixed content from the gym's instance directory
            fixed_content = gym.get_fixed_content(ctx.instance_dir)
            if not dry_run:
                file_path.write_text(fixed_content)
                logger.info("  Fixed: %s", file_path)
            else:
                logger.info("  Would fix: %s [dry-run]", file_path)

            return FileResult(
                file=file_path,
                status=FileStatus.FIXED,
                artifacts=list(result.artifacts.values()),
            )
        else:
            failed_step = result.failed_step or "unknown"
            message = (
                result.escalation_feedback
                or f"workflow {result.status.value}: step={failed_step}"
            )
            logger.warning("Policy failed for %s: %s", file_path, message)
            return FileResult(
                file=file_path,
                status=FileStatus.FAILED,
                message=message,
            )

    except Exception as exc:
        logger.warning("Episode failed for %s: %s", file_path, exc)
        return FileResult(
            file=file_path,
            status=FileStatus.FAILED,
            message=f"episode error: {exc}",
        )
