# susatest-agent

Local agent for [SUSATest](https://susatest.com) — connects your Android device to the cloud testing platform.

## Install

```bash
pip install susatest-agent
```

## Usage

1. Get your API key from [susatest.com/app/settings](https://susatest.com/app/settings)
2. Connect your Android device via USB (USB debugging enabled)
3. Run:

```bash
susatest-agent connect --api-key susa_YOUR_API_KEY
```

Your device will appear in the SUSATest dashboard. Upload an APK and tests run directly on your phone.

## Requirements

- Python 3.9+
- ADB installed (`adb` in PATH) — comes with [Android Studio](https://developer.android.com/studio)
- Android device connected via USB with USB debugging enabled

## Commands

```bash
# Connect to SUSATest (default server)
susatest-agent connect --api-key susa_xxxx

# Connect specific device (if multiple)
susatest-agent connect --api-key susa_xxxx --device R5CR1234567

# Custom server URL
susatest-agent connect --api-key susa_xxxx --server wss://your-server.com

# Custom ADB path
susatest-agent connect --api-key susa_xxxx --adb-path /path/to/adb
```

## How It Works

The agent creates a WebSocket tunnel between your local machine and susatest.com. When you start a test on the website:

1. Server sends commands (tap, screenshot, swipe, etc.) through the tunnel
2. Agent executes them via ADB on your local device
3. Results stream back to the server in real-time

No ports need to be opened — the connection is outbound only.

## License

MIT
