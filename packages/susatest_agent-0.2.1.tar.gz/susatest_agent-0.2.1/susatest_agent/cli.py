"""CLI entry point for susatest-agent."""
from __future__ import annotations

import argparse
import asyncio
import sys


def main():
    parser = argparse.ArgumentParser(
        prog="susatest-agent",
        description="SUSATest CLI — test your app from the command line",
    )
    subparsers = parser.add_subparsers(dest="command")

    # test command — upload APK/URL and run a test
    test_parser = subparsers.add_parser("test", help="Upload an APK or URL and run a test")
    test_parser.add_argument("target", help="Path to .apk file or web URL (https://...)")
    test_parser.add_argument("--api-key", required=True, help="Your SUSATest API key")
    test_parser.add_argument("--persona", default="curious", help="Test persona (default: curious)")
    test_parser.add_argument("--steps", type=int, default=200, help="Max exploration steps (default: 200)")
    test_parser.add_argument("--strategy", default="ai", choices=["ai", "heuristic"], help="Exploration strategy (default: ai)")
    test_parser.add_argument("--format", default="html", choices=["html", "json", "junit"], help="Report format (default: html)")
    test_parser.add_argument("--output", default=None, help="Output file path for report (default: <app>_report.<format>)")
    test_parser.add_argument("--server", default="https://www.susatest.com", help="Server URL")
    test_parser.add_argument("--username", default=None, help="Login username/email")
    test_parser.add_argument("--password", default=None, help="Login password")
    test_parser.add_argument("--no-wait", action="store_true", help="Don't wait for completion, just upload and exit")

    # connect command — bridge local device
    connect_parser = subparsers.add_parser("connect", help="Connect local device to SUSATest server")
    connect_parser.add_argument("--api-key", required=True, help="Your SUSATest API key (susa_xxxx)")
    connect_parser.add_argument("--server", default="https://www.susatest.com", help="Server URL")
    connect_parser.add_argument("--device", default=None, help="Specific device serial")
    connect_parser.add_argument("--adb-path", default="adb", help="Path to adb binary")

    # status command
    subparsers.add_parser("status", help="Show connection status")

    args = parser.parse_args()

    if args.command == "test":
        from .test_runner import run_test
        try:
            asyncio.run(run_test(
                target=args.target,
                api_key=args.api_key,
                persona=args.persona,
                max_steps=args.steps,
                strategy=args.strategy,
                report_format=args.format,
                output_path=args.output,
                server_url=args.server,
                username=args.username,
                password=args.password,
                no_wait=args.no_wait,
            ))
        except KeyboardInterrupt:
            print("\n[susatest] Cancelled.")
            sys.exit(1)
    elif args.command == "connect":
        from .agent import run_agent
        try:
            asyncio.run(run_agent(
                api_key=args.api_key,
                server_url=args.server,
                device_serial=args.device,
                adb_path=args.adb_path,
            ))
        except KeyboardInterrupt:
            print("\n[susatest] Disconnected.")
            sys.exit(0)
    elif args.command == "status":
        print("[susatest] Status check not yet implemented. Use 'connect' to start.")
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
