"""SUSATest Local Agent — connects your Android device to susatest.com."""
__version__ = "0.1.0"
