"""Allow running as python -m susatest_agent."""
from .cli import main

main()
