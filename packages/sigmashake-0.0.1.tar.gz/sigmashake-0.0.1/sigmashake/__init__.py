"""SigmaShake — AI-native infrastructure platform. https://sigmashake.com"""
__version__ = "0.0.1"
