Overview
========

.. note::

   The Automathics project does nothing yet, development is happening now.

Automathics creates elementary maths worksheets with detailed solutions.
