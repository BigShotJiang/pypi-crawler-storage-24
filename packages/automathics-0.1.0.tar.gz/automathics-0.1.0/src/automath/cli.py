# -*- coding: utf-8 -*-

# Copyright 2026 Nicolas Hainaux <nh.techn@posteo.net>

# This file is part of Automathics.

# Automathics is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.

# Automathics is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with Automathics; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

from importlib.metadata import metadata

import click

__version__ = metadata("automathics")['Version']


@click.group()
@click.version_option(__version__, prog_name="automath")
def cli():
    """Automathics exercise generator."""
    click.echo(f"automath {VERSION}")
    click.echo("Automathics exercise generator")
    click.echo("This is an early placeholder version and currently does nothing.")
