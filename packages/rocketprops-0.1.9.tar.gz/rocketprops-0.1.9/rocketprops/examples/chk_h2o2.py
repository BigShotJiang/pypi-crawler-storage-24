
from rocketprops.plot_multi_props import make_plots

make_plots( ['H2O2'], abs_T=True,
             Tmin=500, Tmax=600, save_figures=False)
