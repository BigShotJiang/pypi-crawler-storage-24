def hello():
    print("Hello from Epirus!")
