###########################################################################
# Copyright (c), The AiiDA team. All rights reserved.                     #
# This file is part of the AiiDA code.                                    #
#                                                                         #
# The code is hosted on GitHub at https://github.com/aiidateam/aiida-core #
# For further information on the license, see the LICENSE.txt file        #
# For further information please visit http://www.aiida.net               #
###########################################################################
"""Initialize the storage logger."""

from aiida.common.log import AIIDA_LOGGER

STORAGE_LOGGER = AIIDA_LOGGER.getChild('storage')
MIGRATE_LOGGER = STORAGE_LOGGER.getChild('migrate')
