import re
from .utils import OpenAPIToSparkConverter
import copy
from typing import Any


# Теперь мы не парсим всю спеку - мы перебираем /path на предмет OperationID
# В противном случае - мы ищем спецификацию конкретной операции по endpoint,method(в случае если в endpoint содержатся несколько методов) и 
# На Вход получаем только словарь


class OASParser:
    def __init__(self, OpName:str = None,endpoint_url:str= None,method:str= None,loaded_spec:dict = None):
        self.operation_Name = copy.copy(OpName)
        self.target_endpoint = copy.copy(endpoint_url)
        self.target_method = copy.copy(method)
        self.spec = copy.deepcopy(loaded_spec)
        self.base_url = self.__getbaseurl(self.spec)
        #Парсим документ,формируем справочник
        self.post = self.__parse_specification(self.__getEndpoint(self.spec))
        #Версия словаря для REST2JSON
        self.request = self.__transform_spec_to_requests(self.__resolve_refs_in_operation(copy.deepcopy(self.post),self.__extract_schemas_with_payloads(copy.deepcopy(self.spec))))
        #Версия словаря для OneETL
        self.response_map = self.__resolve_refs_in_operation(copy.deepcopy(self.post),self.__extract_schemas(copy.deepcopy(self.spec))).get('response',None)
        


    ##_parse_specification теперь работает с уровнем ниже
    #Я ищу по endpoint, если endpoint пустой,то пытаюсь через OperationID
    #Поскольку операции разнородные - нужно придумать метод обхода сначала 

    def getStructTypeSchema(self,type_mapping):
        return self.__convert_schema_to_sprkfrm(copy.deepcopy(self.response_map),type_mapping)
    
    def getSpecification(self):
        return self.spec
    
    def __findendpointbypath(self,spec_dict: dict,key) -> dict:
        endpoints = spec_dict.get('paths', {})
        endpoint =  endpoints.get(key,None)
        if endpoint:
            for key,value in endpoint.items():
                if key == self.target_method:
                    return endpoint
        return None
        

    def __findendpointbyOpId(self,spec_dict: dict,key) -> dict:
        for path, methods in spec_dict.get('paths', {}).items():
            for method_name, method_details in methods.items():
                operation_id = method_details.get('operationId',None)
                if operation_id == key:
                    self.target_endpoint = path
                    return {method_name:method_details}
        return None

    def __getEndpoint(self,spec:dict) -> dict: 
        endpoint = None
        #Сначала проверяем по endpoint_url
        endpoint = self.__findendpointbypath(spec,self.target_endpoint)
        if endpoint:
            return endpoint
        #затем по name
        endpoint =  self.__findendpointbyOpId(spec,self.operation_Name)
        if endpoint:
            return endpoint
        if endpoint is None:
            raise f'endpoint_url {self.target_endpoint} или OperationID{self.operation_Name} отсутствуют в спецификации.Дальнейшая работа невозможна.'

    def __resolve_refs_in_operation(self, operation_spec: dict,ref_dict : dict) -> dict:
        """
        Заменяет $ref в параметрах операции.
        """
        if isinstance(operation_spec, dict):
            for key, value in list(operation_spec.items()):
                if isinstance(value, dict):
                    # Если нашли словарь с $ref
                    if "$ref" in value and isinstance(value["$ref"], str) and value["$ref"] in ref_dict:
                        # Заменяем весь словарь на содержимое схемы
                        operation_spec[key] = ref_dict[value["$ref"]]
                    else:
                        # Рекурсивно обрабатываем дальше
                        self.__resolve_refs_in_operation(value, ref_dict)
                elif isinstance(value, list):
                    self.__resolve_refs_in_operation(value, ref_dict)
        elif isinstance(operation_spec, list):
            for i, item in enumerate(operation_spec):
                if isinstance(item, dict):
                    if "$ref" in item and isinstance(item["$ref"], str) and item["$ref"] in ref_dict:
                        # Заменяем элемент списка на содержимое схемы
                        operation_spec[i] = ref_dict[item["$ref"]]
                    else:
                        self.__resolve_refs_in_operation(item, ref_dict)
                elif isinstance(item, list):
                    self.__resolve_refs_in_operation(item, ref_dict)
        
        return operation_spec

    def __getbaseurl(self, spec_dict: dict):
        '''
            __getbaseurl
            возвращает первый элемент списка,
            если сервер в формате переменной то (раскрыть из enum) - 
            взять сначала default потом первый из enum
        '''
        servers = spec_dict.get('servers', [])
        if not servers:
            return ''
        
        # Сначала ищем сервер с default значениями
        for server in servers:
            url_template = server.get('url', '').rstrip('/')
            variables = re.findall(r'\{(\w+)\}', url_template)
            
            if not variables:
                return url_template
            
            var_configs = server.get('variables', {})
            values = {}
            
            for var in variables:
                default_val = var_configs.get(var, {}).get('default')
                if not default_val:
                    break
                values[var] = default_val
            else:
                try:
                    return url_template.format(**values)
                except KeyError:
                    continue
        
        if servers:
            first_server = servers[0]
            first_url = first_server.get('url', '').rstrip('/')
            first_vars = re.findall(r'\{(\w+)\}', first_url)
            
            if not first_vars:
                return first_url
            
            values = {}
            var_configs = first_server.get('variables', {})
            
            for var in first_vars:
                values[var] = var_configs.get(var, {}).get('default', '')
            
            try:
                return first_url.format(**values)
            except KeyError:
                return first_url
        
        return ''
        
    def __parse_specification(self, spec_dict: dict) -> dict:
            result = {}
            path = self.target_endpoint
            for method_name, method_details in spec_dict.items():
                method_upper = method_name.upper()
                if isinstance(method_details,dict):
                    parameters =  method_details.get('parameters',None)
                    endpoint_data = {}
                    method_security = method_details.get('security')
                    method_responses = method_details.get('responses')
                    if method_responses is not None:
                        # Добавить схему ответа
                        response = method_details.get('responses')
                        if response is not None:                    
                             endpoint_data['response'] = self.__find_response_schema(response)
                    if method_security is not None:
                        # Используем security из метода - выкинуть
                        endpoint_data['security'] = method_security
                            
                    request_body = method_details.get('requestBody', {}) 
                    if request_body:
                        content = request_body.get('content', {}) #Тут возможная проблема, мы берем контент из request,а надо response
                        if content:
                            content_type = next(iter(content))
                            content_details = content[content_type]
                            schema = content_details.get('schema', {})
                            endpoint_data.update({
                                    'content': content_type,
                                    'request_body': schema
                                })
                    req_params = re.findall(r'\{(\w+)\}', path)
                    if req_params :
                        param_list = []
                        for req_par in req_params:
                            param_list.append(req_par)
                        endpoint_data['reqref_params'] = param_list
                    operation_id = method_details.get('operationId',None)
                    endpoint_data['operationId'] = operation_id
                    if parameters:
                        endpoint_data['parameters'] = parameters
                    endpoint_data['method'] = method_upper
                    endpoint_data['path'] = path
                    result.update(endpoint_data)
            return result
    
    def __find_response_schema(self, obj: Any, depth: int = 0, max_depth: int = 15) -> dict | str | None:
        """
        Рекурсивно ищет "наиболее вероятную" схему ответа.
        Возвращает:
        - dict — если нашёл inline-схему
        - str  — если нашёл $ref (строку вида "#/components/schemas/...")
        - None — если ничего не нашёл
        """
        if depth > max_depth:
            return None

        if not isinstance(obj, (dict, list)):
            return None

        # schema или $ref на текущем уровне
        if isinstance(obj, dict):
            if "$ref" in obj:
                ref = obj["$ref"]
                if isinstance(ref, str) and ref.startswith("#/"):
                    return ref  # возвращаем ref как есть — дальше можно резолвить

            if "schema" in obj and isinstance(obj["schema"], (dict, str)):
                return obj["schema"]

        #  Типичные пути в OpenAPI
        common_paths = [
            ("content", "application/json", "schema"),
            ("content", "application/json", "$ref"),
            ("content", "application/vnd.api+json", "schema"),
            ("schema",),
            ("$ref",),
            ("responses", "200", "content", "application/json", "schema"),
            ("responses", "200", "schema"),
        ]

        for path in common_paths:
            current = obj
            try:
                for key in path:
                    current = current[key]
                if isinstance(current, (dict, str)):
                    return current
            except (KeyError, TypeError):
                continue

        #  oneOf / allOf / anyOf 
        if isinstance(obj, dict):
            for combinator in ["oneOf", "allOf", "anyOf"]:
                if combinator in obj and isinstance(obj[combinator], list):
                    for variant in obj[combinator]:
                        if isinstance(variant, dict):
                            found = self.__find_response_schema(variant, depth + 1, max_depth)
                            if found is not None:
                                return found  # возвращаем первый найденный рабочий вариант

        #  Рекурсия по всем вложенным словарям и спискам
        if isinstance(obj, dict):
            for v in obj.values():
                found = self.__find_response_schema(v, depth + 1, max_depth)
                if found is not None:
                    return found

        elif isinstance(obj, list):
            for item in obj:
                found = self.__find_response_schema(item, depth + 1, max_depth)
                if found is not None:
                    return found

        return None

    def __transform_spec_to_requests(self, spec: dict) -> dict:
        request = {}
        try:
            path = spec.get("path", '')            
            # Получаем метод
            method = spec.get("method", "GET").upper()
            base_url = spec.get("base_url", "")
            # Получаем путь
            url = spec["path"]
            
            # Собираем все переменные
            all_variables = set()
            required_variables = set()
            
            # Path параметры из parameters
            parameters = spec.get("parameters", [])
            for param in parameters:
                if isinstance(param, dict):
                    param_name = param.get("name")
                    param_in = param.get("in")
                    param_required = param.get("required", False)
                    
                    if param_name and param_in in ("path","header"):
                        all_variables.add(param_name)
                        if param_required:
                            required_variables.add(param_name)
            
            #  Path параметры из reqref_params
            reqref_params = spec.get("reqref_params", [])
            for param in reqref_params:
                if isinstance(param, str):
                    all_variables.add(param)
                    required_variables.add(param)
                elif isinstance(param, dict):
                    param_name = param.get("name")
                    if param_name:
                        all_variables.add(param_name)
                        required_variables.add(param_name)
            
            # Path переменные из URL
            import re
            path_vars = re.findall(r'\{([^}]+)\}', url)
            for var in path_vars:
                all_variables.add(var)
                required_variables.add(var)
            
            # Query параметры из parameters
            for param in parameters:
                if isinstance(param, dict):
                    param_name = param.get("name")
                    param_in = param.get("in")
                    param_required = param.get("required", False)
                    #тоже лишний кусок,возможно
                    if param_name and param_in == "query":
                        all_variables.add(param_name)
                        if param_required:
                            required_variables.add(param_name)
            
            # 5. Параметры из request_body
            request_body = spec.get("request_body", {})
            
            def __extract_body_params(body_spec, parent_path="", skip_parent=False):
                """
                Извлекает имена параметров из body
                skip_parent: True если нужно пропустить имя родительского контейнера
                """
                params = set()
                required_params = set()
                
                if not body_spec or not isinstance(body_spec, dict):
                    return params, required_params
                
                # Проверяем наличие properties (для объектов)
                if "properties" in body_spec:
                    properties = body_spec.get("properties", {})
                    required_fields = body_spec.get("required", [])
                    
                    for prop_name, prop_schema in properties.items():
                        # Формируем полное имя параметра
                        if skip_parent:
                            # Если нужно пропустить родителя, используем только имя свойства
                            full_name = prop_name
                        elif parent_path:
                            full_name = f"{parent_path}.{prop_name}"
                        else:
                            full_name = prop_name
                        
                        # Добавляем параметр
                        params.add(full_name)
                        
                        # Проверяем required
                        if prop_name in required_fields:
                            required_params.add(full_name)
                        
                        # Рекурсивно обрабатываем вложенные объекты
                        if isinstance(prop_schema, dict):
                            prop_type = prop_schema.get("type")
                            
                            # Если это объект с properties
                            if prop_type == "object" and "properties" in prop_schema:
                                nested_params, nested_required = __extract_body_params(
                                    prop_schema,
                                    parent_path=full_name,
                                    skip_parent=False
                                )
                                params.update(nested_params)
                                required_params.update(nested_required)
                            
                            # Если это массив объектов
                            elif prop_type == "array" and "items" in prop_schema:
                                items = prop_schema["items"]
                                if isinstance(items, dict) and items.get("type") == "object" and "properties" in items:
                                    nested_params, nested_required = __extract_body_params(
                                        items,
                                        parent_path=f"{full_name}[*]",
                                        skip_parent=False
                                    )
                                    params.update(nested_params)
                                    required_params.update(nested_required)
                
                # Если это не объект с properties, а просто словарь с полями
                else:
                    for field_name, field_schema in body_spec.items():
                        if isinstance(field_schema, dict) and 'type' in field_schema:
                            # Формируем полное имя
                            if skip_parent:
                                full_name = field_name
                            elif parent_path:
                                full_name = f"{parent_path}.{field_name}"
                            else:
                                full_name = field_name
                            
                            # Добавляем параметр
                            params.add(full_name)
                            
                            # Проверяем required
                            if field_schema.get("required", False):
                                required_params.add(full_name)
                            
                            # Рекурсивно обрабатываем вложенные объекты
                            field_type = field_schema.get("type")
                            if field_type == "object" and "properties" in field_schema:
                                nested_params, nested_required = __extract_body_params(
                                    field_schema,
                                    parent_path=full_name,
                                    skip_parent=False
                                )
                                params.update(nested_params)
                                required_params.update(nested_required)
                            elif field_type == "array" and "items" in field_schema:
                                items = field_schema["items"]
                                if isinstance(items, dict):
                                    if items.get("type") == "object" and "properties" in items:
                                        nested_params, nested_required = __extract_body_params(
                                            items,
                                            parent_path=f"{full_name}[*]",
                                            skip_parent=False
                                        )
                                        params.update(nested_params)
                                        required_params.update(nested_required)
                
                return params, required_params
            
            # Извлекаем параметры из body
            if request_body:
                body_params = set()
                body_required = set()
                
                # Проверяем структуру request_body
                if "properties" in request_body:
                    properties = request_body.get("properties", {})
                    
                    # Обрабатываем каждое поле верхнего уровня
                    for prop_name, prop_schema in properties.items():
                        # Проверяем, является ли это поле контейнером параметров (например, "params")
                        if (isinstance(prop_schema, dict) and 
                            prop_schema.get("type") == "object"):
                            
                            # Получаем все поля внутри этого объекта
                            if "properties" in prop_schema:
                                # Это объект с properties - обрабатываем его поля как параметры верхнего уровня
                                container_params, container_required = __extract_body_params(
                                    prop_schema,
                                    skip_parent=True  # Пропускаем имя контейнера
                                )
                                body_params.update(container_params)
                                body_required.update(container_required)
                            else:
                                # Это объект без properties - возможно, поля на верхнем уровне
                                for field_name, field_schema in prop_schema.items():
                                    if isinstance(field_schema, dict) and 'type' in field_schema:
                                        # Добавляем поле как параметр верхнего уровня
                                        body_params.add(field_name)
                                        if field_schema.get("required", False):
                                            body_required.add(field_name)
                        else:
                            # Обычное поле не-контейнер
                            field_params, field_required = __extract_body_params(
                                {prop_name: prop_schema}
                            )
                            body_params.update(field_params)
                            body_required.update(field_required)
                else:
                    # Если нет properties, пробуем обработать как есть
                    body_params, body_required = __extract_body_params(request_body)
                
                all_variables.update(body_params)
                required_variables.update(body_required)
                
            
            # Формируем финальную конфигурацию
            request = {
                "base_url":self.base_url,
                "method": method,
                "url": url,
                "headers": {
                    "Content-Type": spec.get("content", ""),#application/json
                    "Accept": ""#application/json
                },
                "auth_types": spec.get("security", None),
                "variables": sorted(list(all_variables)) if all_variables else [],
                "required": sorted(list(required_variables)) if required_variables else []
            }
            
            # Отладка
            
        except Exception as e:
            print(f"Предупреждение: Ошибка обработки endpoint '': {e}")
            import traceback
            traceback.print_exc()
        
        return request

    def get_response_map(self,ID:str = None): 
        return self.response_map
        
    def _get_request_config(self):
        return self.request

    def __schema_to_payload(self, schema: dict) -> dict:

        """Преобразует одну схему в payload структуру"""
        payload = {}
        composite_types = ['oneOf', 'anyOf', 'allOf']
        
        # Определяем тип схемы
        schema_type = schema.get('type')
        
        # Если это объект
        if schema_type == 'object':
            properties = schema.get('properties', {})
            required_fields = schema.get('required', [])
            
            if properties:
                for prop_name, prop_schema in properties.items():
                    # Инициализируем базовую структуру для свойства
                    prop_payload = {
                        'name': prop_name,
                        'required': prop_name in required_fields,
                        'nullable': prop_schema.get('nullable', False),
                    }
                    
                    # Добавляем type, format, items если они есть
                    if 'type' in prop_schema:
                        prop_payload['type'] = prop_schema['type']
                    if 'format' in prop_schema:
                        prop_payload['format'] = prop_schema['format']
                    if 'items' in prop_schema:
                        prop_payload['items'] = prop_schema['items']
                    if '$ref' in prop_schema:
                        prop_payload['$ref'] = prop_schema['$ref']
                    
                    # Обрабатываем составные типы
                    for comp_type in composite_types:
                        if comp_type in prop_schema:
                            comp_value = prop_schema[comp_type]
                            if isinstance(comp_value, list):
                                # Сохраняем ссылки как есть, они будут разыменованы позже
                                prop_payload[comp_type] = [
                                    item.get('$ref', item) if isinstance(item, dict) else item 
                                    for item in comp_value
                                ]
                    
                    payload[prop_name] = prop_payload
            else:
                # Обработка случая, когда нет properties
                for key, value in schema.items():
                    if key in composite_types:
                        if isinstance(value, list):
                            payload[key] = [
                                item.get('$ref', item) if isinstance(item, dict) else item 
                                for item in value
                            ]
        
        # Если это параметр (имеет name и schema)
        elif 'name' in schema and 'schema' in schema and isinstance(schema['schema'], dict):
            param_name = schema['name']
            param_schema = schema['schema']
            param_required = schema.get('required',None)
            
            payload[param_name] = {
                'name': param_name,
                'required': param_required,
                'nullable': param_schema.get('nullable',None),
                'type': param_schema.get('type',None),
                'format': param_schema.get('format',None),
                'items': param_schema.get('items',None),
            }
            if '$ref' in param_schema:
                payload[param_name]['$ref'] = param_schema['$ref']
        
        # Если это другой тип данных (string, array и т.д.)
        elif schema_type:
            payload['value'] = {
                'name': 'value',
                'required': True,
                'nullable': schema.get('nullable', None),
                'type': schema_type,
                'format': schema.get('format', None),
                'items': schema.get('items', None),
            }
            if '$ref' in schema:
                payload['value']['$ref'] = schema['$ref']
        
        return payload

    def __extract_schemas(self, openapi_spec: dict) -> dict:
        
        # Загружаем сырые схемы
        # много хардкода,т.к идем по стандарту
        raw_schemas = {}
        if 'components' in openapi_spec and isinstance(openapi_spec['components'], dict):
            if 'schemas' in openapi_spec['components'] and isinstance(openapi_spec['components']['schemas'], dict):
                for schema_name, schema_content in openapi_spec['components']['schemas'].items():
                    ref_key = f"#/components/schemas/{schema_name}"
                    raw_schemas[ref_key] = copy.deepcopy(schema_content)
        
        resolved_schemas = {}
        
        def __resolve_obj(obj, stack=None):
            """Разрешает ссылки в объекте с контролем стека"""
            if stack is None:
                stack = []
            
            if isinstance(obj, dict):
                # Если это словарь с одной ссылкой
                if "$ref" in obj and len(obj) == 1:
                    ref = obj["$ref"]
                    if ref in raw_schemas:
                        if ref in stack:
                            return {"type": "object"}  # рекурсия - заменяем на object
                        
                        stack.append(ref)
                        resolved = raw_schemas[ref]
                        result = __resolve_obj(resolved, stack)
                        stack.pop()
                        return result
                    return obj
                
                # Обычный словарь
                result = {}
                for key, value in obj.items():
                    if key == "$ref" and isinstance(value, str) and value in raw_schemas:
                        # Обрабатываем ссылку внутри словаря
                        if value in stack:
                            result[key] = {"type": "object"}  # рекурсия - заменяем на object
                        else:
                            stack.append(value)
                            resolved = raw_schemas[value]
                            result[key] = __resolve_obj(resolved, stack)
                            stack.pop()
                    else:
                        result[key] = __resolve_obj(value, stack)
                return result
            
            elif isinstance(obj, list):
                return [__resolve_obj(item, stack) for item in obj]
            
            return obj
        
        # Разрешаем все схемы
        for ref_key in raw_schemas.keys():
            resolved_schemas[ref_key] = __resolve_obj(raw_schemas[ref_key])
        
        return resolved_schemas

    def __extract_schemas_with_payloads(self, spec_dict: dict) -> dict:
        """
        Извлекает все схемы из всех разделов components и преобразует их в payload
        Возвращает словарь {полный_ref: payload}
        """
        if 'components' not in spec_dict:
            return {}
        
        components = spec_dict['components']
        payloads = {}
        
        # Сначала собираем все схемы
        for section_name, section_content in components.items():
            if not isinstance(section_content, dict):
                continue
            for item_name, item_data in section_content.items():
                full_ref = f"#/components/{section_name}/{item_name}"
                if isinstance(item_data, dict):
                    payload = self.__schema_to_payload(item_data)
                    if payload:
                        payloads[full_ref] = payload
        
        def __resolve_refs(obj, visited=None, path=""):
            if visited is None:
                visited = set()
            
            if isinstance(obj, dict):
                # Сохраняем метаданные текущего объекта
                metadata = {}
                if 'name' in obj:
                    metadata['name'] = obj['name']
                if 'required' in obj:
                    metadata['required'] = obj['required']
                if 'nullable' in obj:
                    metadata['nullable'] = obj['nullable']
                
                # Проверяем, есть ли ссылка для разыменования
                ref = obj.get('$ref')
                if ref and isinstance(ref, str) and ref in payloads and ref not in visited:
                    visited.add(ref)
                    resolved = payloads[ref]
                    
                    # Разыменовываем вложенные ссылки в resolved
                    resolved = __resolve_refs(resolved, visited, path + "->" + ref)
                    
                    # Если resolved - это словарь, объединяем с метаданными
                    if isinstance(resolved, dict):
                        result = resolved.copy()
                        # Добавляем метаданные на верхний уровень, если их нет в resolved
                        for key, value in metadata.items():
                            if key not in result:
                                result[key] = value
                        return result
                
                # Обрабатываем составные типы (oneOf, anyOf, allOf)
                result = {}
                for key, value in obj.items():
                    if key in ['oneOf', 'anyOf', 'allOf'] and isinstance(value, list):
                        # Для составных типов разыменовываем каждый элемент
                        resolved_list = []
                        for item in value:
                            if isinstance(item, str):
                                # Если это строка-ссылка
                                if item in payloads and item not in visited:
                                    visited_copy = visited.copy()
                                    visited_copy.add(item)
                                    resolved_item = payloads[item]
                                    resolved_item = __resolve_refs(resolved_item, visited_copy, path + "->" + item)
                                    resolved_list.append(resolved_item)
                                else:
                                    resolved_list.append(item)
                            elif isinstance(item, dict):
                                # Если это словарь с возможной ссылкой
                                resolved_item = __resolve_refs(item, visited.copy(), path)
                                resolved_list.append(resolved_item)
                            else:
                                resolved_list.append(item)
                        result[key] = resolved_list
                    elif key != '$ref':  # Не обрабатываем саму ссылку повторно
                        result[key] = __resolve_refs(value, visited.copy(), path)
                
                # Добавляем сохраненные метаданные, если их нет в результате
                for key, value in metadata.items():
                    if key not in result:
                        result[key] = value
                
                return result if result else metadata
            
            elif isinstance(obj, list):
                # Рекурсивно обрабатываем все элементы списка
                result = []
                for i, item in enumerate(obj):
                    if isinstance(item, str) and item.startswith('#/components/'):
                        # Если это строка-ссылка в списке
                        if item in payloads and item not in visited:
                            visited_copy = visited.copy()
                            visited_copy.add(item)
                            resolved_item = payloads[item]
                            resolved_item = __resolve_refs(resolved_item, visited_copy, path + "->" + item)
                            result.append(resolved_item)
                        else:
                            result.append(item)
                    else:
                        result.append(__resolve_refs(item, visited.copy(), path))
                return result
            
            else:
                return obj
        
        resolved_payloads = {}
        
        for ref, payload in payloads.items():
            resolved_payloads[ref] = __resolve_refs(payload)
        
        return resolved_payloads

    def __convert_schema_to_sprkfrm(self,response_map,type_mapping):
        converter = OpenAPIToSparkConverter(type_mapping)
        spark_json_schema = converter.convert(response_map)
        return spark_json_schema
        
