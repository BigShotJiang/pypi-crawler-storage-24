"""
AGENTICSTAR Platform SDK - Pod Runtime Management
Podライフサイクル管理 - 状態遷移と終了処理

Pod起動時のステータス設定、終了時のステータス更新と自己スケールダウンを統合
"""

import logging
from typing import Any, Dict

from .data_access import DataAccess

logger = logging.getLogger(__name__)


class PodRuntime:
    """
    Podライフサイクル管理クラス

    execution_podsテーブルへのステータス管理と、
    Pod終了時の自己スケールダウンを統合:
    - start(): Pod起動時にrunningステータスを設定
    - final(): Pod終了時にステータス更新 + scale_down_self()
    """

    def __init__(self, db: DataAccess, execution_id: str, pod_name: str):
        """
        Args:
            db: DataAccessインスタンス
            execution_id: 実行ID
            pod_name: Pod名
        """
        self._db = db
        self._execution_id = execution_id
        self._pod_name = pod_name
        self.logger = logger

    async def start(self) -> Dict[str, Any]:
        """
        Pod起動: ステータスをrunning/healthyに設定

        Returns:
            Dict with keys: success, data, error (optional)
        """
        self.logger.info(f"[IN] PodRuntime.start: execution_id={self._execution_id}, pod_name={self._pod_name}")
        result = await self._save_pod_status("running", "healthy")
        if result.get("success"):
            self.logger.info(f"[OUT] PodRuntime.start: Pod status set to running")
        else:
            self.logger.error(f"[ERROR] PodRuntime.start: Failed to set pod status: {result.get('error')}")
        return result

    async def final(self, status: str = "completed") -> Dict[str, Any]:
        """
        Pod終了: ステータス更新 → 自己スケールダウン

        Args:
            status: 終了ステータス ('completed', 'failed')

        Returns:
            Dict with execution_id and status
        """
        self.logger.info(f"[IN] PodRuntime.final: execution_id={self._execution_id}, status={status}")

        # 1. DBステータス更新
        await self._save_pod_status(status, "stopped")

        # 2. StatefulSet scale=0（自己削除）
        try:
            from src.utils.self_scaler import scale_down_self
            await scale_down_self(self._execution_id)
            self.logger.info(f"[OUT] PodRuntime.final: Scale down completed for {self._execution_id}")
        except Exception as e:
            self.logger.error(f"[ERROR] PodRuntime.final: Scale down failed: {e}")

        return {"execution_id": self._execution_id, "status": status}

    async def _save_pod_status(self, pod_status: str, health_status: str) -> Dict[str, Any]:
        """
        execution_podsテーブルにステータス保存（UPSERT）

        Args:
            pod_status: Podステータス (running, completed, failed)
            health_status: ヘルス状態 (healthy, stopped, unknown)

        Returns:
            Dict with keys: success, data, error (optional)
        """
        query = """
            INSERT INTO execution_pods
            (execution_id, pod_name, pod_status, health_status, created_at, updated_at)
            VALUES ($1, $2, $3, $4, NOW(), NOW())
            ON CONFLICT (execution_id)
            DO UPDATE SET
                pod_name = EXCLUDED.pod_name,
                pod_status = EXCLUDED.pod_status,
                health_status = EXCLUDED.health_status,
                updated_at = NOW(),
                last_health_check = CASE
                    WHEN EXCLUDED.health_status != execution_pods.health_status THEN NOW()
                    ELSE execution_pods.last_health_check
                END
        """
        return await self._db.execute_query(
            query, (self._execution_id, self._pod_name, pod_status, health_status)
        )
