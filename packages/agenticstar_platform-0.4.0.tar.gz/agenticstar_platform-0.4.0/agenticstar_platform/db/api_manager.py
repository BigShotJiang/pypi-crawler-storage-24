"""
AGENTICSTAR Platform SDK - API PostgreSQL Manager
API経由でデータベースアクセスを行うPostgreSQLManager実装（CLIモード用）
"""

from __future__ import annotations

import base64
import logging
from datetime import date, datetime
from decimal import Decimal
from typing import Any, Callable, Dict, List, Optional
from uuid import UUID

import httpx

from .config import PostgreSQLConfig

logger = logging.getLogger(__name__)


def _serialize_param(value: Any) -> Any:
    """
    SQLパラメータをJSONシリアライズ可能な形式に変換

    Args:
        value: 変換する値

    Returns:
        JSONシリアライズ可能な値
    """
    if value is None:
        return None
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, Decimal):
        return str(value)
    if isinstance(value, UUID):
        return str(value)
    if isinstance(value, bytes):
        # base64エンコーディングでバイナリデータを安全にシリアライズ
        return {"__bytes__": base64.b64encode(value).decode("ascii")}
    if isinstance(value, (list, tuple)):
        return [_serialize_param(v) for v in value]
    if isinstance(value, dict):
        return {k: _serialize_param(v) for k, v in value.items()}
    return value


class ApiPostgreSQLManager:
    """
    API経由でDBにアクセスするPostgreSQLManager

    CLIモード用の実装。直接DB接続ではなく、APIプロキシを経由する。
    PostgreSQLManagerと同等のasyncインタフェースを提供。
    """

    def __init__(
        self,
        config: PostgreSQLConfig,
        *,
        token_provider: Callable[[], Optional[str]],
    ):
        """
        Args:
            config: PostgreSQL設定（api_proxy_url必須）
            token_provider: 認証トークンを取得する関数（必須、都度呼び出し）

        Raises:
            ValueError: api_proxy_url未設定時
        """
        self.config = config
        self._token_provider = token_provider

        # API URL取得・検証
        if config.api_proxy_url:
            self.api_url = config.api_proxy_url
        else:
            raise ValueError(
                "api_proxy_url not configured. "
                "Set [database] api_proxy_url in config.toml for CLI/Desktop mode."
            )

        logger.info(f"[ApiPostgreSQLManager] Using API proxy: {self.api_url}")

    def _get_token(self) -> str:
        """トークンを取得（都度呼び出し、期限切れ対応）

        Raises:
            RuntimeError: トークン取得失敗時
        """
        token = self._token_provider()
        if not token:
            raise RuntimeError(
                "Failed to obtain authentication token. "
                "Please re-authenticate with 'agenticai auth login'."
            )
        return token

    async def initialize(self) -> None:
        """初期化（API Proxyモードでは何もしない）"""
        logger.debug("[ApiPostgreSQLManager] initialize: Skipping in API mode")

    async def close(self) -> None:
        """接続を閉じる（API Proxyモードでは何もしない）"""
        logger.debug("[ApiPostgreSQLManager] close: Nothing to close in API mode")

    async def execute_query(
        self, query: str, params: tuple = ()
    ) -> Dict[str, Any]:
        """
        API経由でクエリを実行

        Args:
            query: 実行するSQLクエリ
            params: クエリパラメータ

        Returns:
            Dict with keys: success, data, error (optional), error_code (optional)
        """
        return await self._api_request("execute", query, params)

    async def fetch_one(
        self, query: str, params: tuple = ()
    ) -> Optional[Dict[str, Any]]:
        """
        API経由で単一行を取得

        Args:
            query: 実行するSQLクエリ
            params: クエリパラメータ

        Returns:
            Dict (結果がある場合) or None
        """
        result = await self._api_request("fetch_one", query, params)
        if result.get("success") and result.get("data"):
            return result["data"]
        return None

    async def fetch_all(
        self, query: str, params: tuple = ()
    ) -> List[Dict[str, Any]]:
        """
        API経由で全行を取得

        Args:
            query: 実行するSQLクエリ
            params: クエリパラメータ

        Returns:
            List[Dict]: クエリ結果のリスト
        """
        result = await self._api_request("fetch_all", query, params)
        if result.get("success") and result.get("data"):
            return result["data"]
        return []

    async def _api_request(
        self,
        operation: str,
        query: str,
        params: tuple,
    ) -> Dict[str, Any]:
        """API共通リクエスト処理"""
        try:
            token = self._get_token()
            headers = {"Authorization": f"Bearer {token}"}

            # パラメータをJSONシリアライズ可能な形式に変換
            serialized_params = [_serialize_param(p) for p in params]

            timeout = httpx.Timeout(30.0, connect=10.0)
            async with httpx.AsyncClient(timeout=timeout) as client:
                response = await client.post(
                    f"{self.api_url}/{operation}",
                    json={"query": query, "params": serialized_params},
                    headers=headers,
                )

                if response.status_code == 401:
                    logger.warning("[ApiPostgreSQLManager] Authentication failed (401)")
                    return {
                        "success": False,
                        "data": None,
                        "error": "Authentication failed. Please re-authenticate.",
                        "error_code": "UNAUTHORIZED",
                    }

                if response.status_code >= 400:
                    error_text = response.text
                    logger.error(
                        f"[ApiPostgreSQLManager] API error: {response.status_code}"
                    )
                    return {
                        "success": False,
                        "data": None,
                        "error": f"API error: {response.status_code} - {error_text}",
                        "error_code": "API_ERROR",
                    }

                return response.json()

        except RuntimeError as e:
            # トークン取得失敗
            logger.error(f"[ApiPostgreSQLManager] Token error: {e}")
            return {
                "success": False,
                "data": None,
                "error": str(e),
                "error_code": "AUTH_ERROR",
            }
        except httpx.TimeoutException:
            logger.error("[ApiPostgreSQLManager] Request timeout")
            return {
                "success": False,
                "data": None,
                "error": "API request timeout",
                "error_code": "TIMEOUT",
            }
        except Exception as e:
            logger.error(f"[ApiPostgreSQLManager] Request failed: {e}")
            return {
                "success": False,
                "data": None,
                "error": f"Failed to execute query via API: {str(e)}",
                "error_code": "REQUEST_ERROR",
            }
