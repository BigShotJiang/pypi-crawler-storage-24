"""
AGENTICSTAR Platform SDK - PostgreSQL Manager Factory
実行モードに応じて適切なPostgreSQLManagerを作成
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Callable, Optional, Union

if TYPE_CHECKING:
    from .api_manager import ApiPostgreSQLManager
    from .config import PostgreSQLConfig
    from .manager import PostgreSQLManager

logger = logging.getLogger(__name__)


def create_postgresql_manager(
    config: "PostgreSQLConfig",
    *,
    use_proxy: bool = False,
    token_provider: Optional[Callable[[], Optional[str]]] = None,
) -> Union["PostgreSQLManager", "ApiPostgreSQLManager"]:
    """
    PostgreSQLManagerを作成

    Args:
        config: PostgreSQL設定
        use_proxy: True=ApiPostgreSQLManager（API経由）, False=PostgreSQLManager（DB直結）
        token_provider: API Proxy使用時の認証トークン取得関数（use_proxy=True時は必須）

    Returns:
        PostgreSQLManager または ApiPostgreSQLManager インスタンス

    Raises:
        ValueError: use_proxy=True で token_provider が未指定の場合
    """
    if use_proxy:
        # バリデーション: API Proxyモードではtoken_provider必須
        if token_provider is None:
            raise ValueError(
                "token_provider is required when use_proxy=True. "
                "CLI/Desktop mode requires authentication."
            )

        logger.info("Creating ApiPostgreSQLManager for API Proxy mode")
        from .api_manager import ApiPostgreSQLManager

        return ApiPostgreSQLManager(config, token_provider=token_provider)
    else:
        logger.info("Creating PostgreSQLManager for direct DB connection")
        from .manager import PostgreSQLManager

        return PostgreSQLManager(config)
