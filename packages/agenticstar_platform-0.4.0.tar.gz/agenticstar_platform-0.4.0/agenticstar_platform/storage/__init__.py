"""
AGENTICSTAR Platform SDK - Storage Module
マルチクラウド対応のオブジェクトストレージクライアント

サポートプロバイダー:
- Azure Blob Storage
- AWS S3
- Google Cloud Storage

Example:
    from agenticstar_platform.storage import (
        AzureBlobStorageClient, AzureBlobConfig,
        S3StorageClient, S3Config,
        GCSStorageClient, GCSConfig,
    )

    # Azure
    client = AzureBlobStorageClient(AzureBlobConfig(
        bucket_name="my-container",
        connection_string="DefaultEndpointsProtocol=https;...",
    ))

    # AWS S3
    client = S3StorageClient(S3Config(
        bucket_name="my-bucket",
        aws_access_key_id="AKIA...",
        aws_secret_access_key="...",
    ))

    # GCS
    client = GCSStorageClient(GCSConfig(
        bucket_name="my-bucket",
        project_id="my-project",
    ))

    result = await client.upload_file("/path/to/file.txt", prefix="uploads")
    print(result.object_url)
    await client.close()
"""

# Base classes and types
from .base import (
    # Enums
    StorageProvider,
    # Errors
    StorageError,
    StorageConfigError,
    StorageConnectionError,
    StorageOperationError,
    # Result types
    UploadResult,
    DownloadResult,
    ObjectInfo,
    ListResult,
    # Config types
    StorageConfig,
    AzureBlobConfig,
    S3Config,
    GCSConfig,
    # Protocol/ABC
    StorageClientProtocol,
    StorageClientBase,
)

# Provider implementations
from .azure import AzureBlobStorageClient
from .s3 import S3StorageClient
from .gcs import GCSStorageClient

# Path conventions
from .paths import StoragePaths

__all__ = [
    # Enums
    "StorageProvider",
    # Errors
    "StorageError",
    "StorageConfigError",
    "StorageConnectionError",
    "StorageOperationError",
    # Result types
    "UploadResult",
    "DownloadResult",
    "ObjectInfo",
    "ListResult",
    # Config types
    "StorageConfig",
    "AzureBlobConfig",
    "S3Config",
    "GCSConfig",
    # Protocol/ABC
    "StorageClientProtocol",
    "StorageClientBase",
    # Provider implementations
    "AzureBlobStorageClient",
    "S3StorageClient",
    "GCSStorageClient",
    # Path conventions
    "StoragePaths",
]
