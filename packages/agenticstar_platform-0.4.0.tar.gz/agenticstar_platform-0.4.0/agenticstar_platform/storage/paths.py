"""
AGENTICSTAR Platform SDK - Storage Path Conventions
フロントエンド・バックエンド間で共有するストレージパスの命名規則

AgenticStar プラットフォーム全体で統一されたパス構造を提供:
- plans/{plan_id}/{subdir}/{filename}   … エージェント実行成果物
- uploads/{conversation_id}/{message_id}/{filename} … ユーザーアップロード

Usage:
    from agenticstar_platform.storage.paths import StoragePaths

    # プランパス構築
    prefix = StoragePaths.plan_prefix("exec-123", "files")
    # → "plans/exec-123/files"

    path = StoragePaths.plan_path("exec-123", "files", "report.pdf")
    # → "plans/exec-123/files/report.pdf"

    # アップロードパス構築
    prefix = StoragePaths.upload_prefix("conv-456", "msg-789")
    # → "uploads/conv-456/msg-789"

    # サブディレクトリ定数
    StoragePaths.SUBDIR_FILES        # "files"
    StoragePaths.SUBDIR_DOWNLOADS    # "downloads"
    StoragePaths.SUBDIR_SCREENSHOTS  # "screenshots"
    StoragePaths.SUBDIR_DELIVERABLES # "deliverables"
"""

from typing import Final


class StoragePaths:
    """AgenticStar ストレージパス命名規則

    フロントエンド (ChatBoard) とバックエンド (Autonomous Agent) 間で
    共有するパス構造を定義する。
    """

    # ========== Top-level prefixes ==========
    PLANS_PREFIX: Final[str] = "plans"
    UPLOADS_PREFIX: Final[str] = "uploads"

    # ========== Subdirectory constants ==========
    SUBDIR_FILES: Final[str] = "files"
    SUBDIR_DOWNLOADS: Final[str] = "downloads"
    SUBDIR_SCREENSHOTS: Final[str] = "screenshots"
    SUBDIR_DELIVERABLES: Final[str] = "deliverables"
    SUBDIR_COT: Final[str] = ".CoT"

    # ========== Default subdirectory ==========
    DEFAULT_SUBDIR: Final[str] = SUBDIR_FILES

    # ========== Path builders ==========

    @staticmethod
    def plan_prefix(plan_id: str, subdir: str = "") -> str:
        """プラン成果物のストレージプレフィックスを構築

        Args:
            plan_id: 実行ID / プランID
            subdir: サブディレクトリ（files, screenshots 等）

        Returns:
            "plans/{plan_id}/{subdir}" or "plans/{plan_id}"

        Raises:
            ValueError: plan_id が空文字列の場合
        """
        if not plan_id:
            raise ValueError("plan_id must not be empty")
        if subdir:
            return f"{StoragePaths.PLANS_PREFIX}/{plan_id}/{subdir}"
        return f"{StoragePaths.PLANS_PREFIX}/{plan_id}"

    @staticmethod
    def plan_path(plan_id: str, subdir: str, filename: str) -> str:
        """プラン成果物のフルパスを構築

        Args:
            plan_id: 実行ID / プランID
            subdir: サブディレクトリ
            filename: ファイル名

        Returns:
            "plans/{plan_id}/{subdir}/{filename}"

        Raises:
            ValueError: plan_id, subdir, filename のいずれかが空文字列の場合
        """
        if not plan_id:
            raise ValueError("plan_id must not be empty")
        if not subdir:
            raise ValueError("subdir must not be empty")
        if not filename:
            raise ValueError("filename must not be empty")
        return f"{StoragePaths.PLANS_PREFIX}/{plan_id}/{subdir}/{filename}"

    @staticmethod
    def upload_prefix(conversation_id: str, message_id: str) -> str:
        """ユーザーアップロードのストレージプレフィックスを構築

        末尾スラッシュなし（plan_prefix と統一）。

        Args:
            conversation_id: 会話ID
            message_id: メッセージID

        Returns:
            "uploads/{conversation_id}/{message_id}"

        Raises:
            ValueError: conversation_id または message_id が空文字列の場合
        """
        if not conversation_id:
            raise ValueError("conversation_id must not be empty")
        if not message_id:
            raise ValueError("message_id must not be empty")
        return f"{StoragePaths.UPLOADS_PREFIX}/{conversation_id}/{message_id}"

    @staticmethod
    def upload_path(
        conversation_id: str, message_id: str, filename: str
    ) -> str:
        """ユーザーアップロードのフルパスを構築

        Args:
            conversation_id: 会話ID
            message_id: メッセージID
            filename: ファイル名

        Returns:
            "uploads/{conversation_id}/{message_id}/{filename}"

        Raises:
            ValueError: conversation_id, message_id, filename のいずれかが空文字列の場合
        """
        if not conversation_id:
            raise ValueError("conversation_id must not be empty")
        if not message_id:
            raise ValueError("message_id must not be empty")
        if not filename:
            raise ValueError("filename must not be empty")
        return f"{StoragePaths.UPLOADS_PREFIX}/{conversation_id}/{message_id}/{filename}"
