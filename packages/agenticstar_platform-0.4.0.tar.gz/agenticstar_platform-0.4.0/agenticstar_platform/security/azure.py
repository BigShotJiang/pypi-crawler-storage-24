"""
AGENTICSTAR Platform SDK - Azure Security Client
Azure Content Safety + Language Service (PII) 統合クライアント

機能:
- Content Moderation (有害コンテンツ検出)
- Prompt Shield (Jailbreak攻撃検出)
- PII Detection & Masking (個人情報検出・マスキング)

Example:
    config = AzureSecurityConfig(
        content_safety_endpoint="https://xxx.cognitiveservices.azure.com",
        content_safety_api_key="xxx",
        language_endpoint="https://xxx.cognitiveservices.azure.com",
        language_api_key="xxx",
    )
    client = AzureSecurityClient(config)

    # 統合チェック
    result = await client.check_security(text, check_pii=True)
    if not result.allowed:
        print(f"Violations: {result.violations}")

    await client.close()
"""

import logging
from typing import Any, Dict, List, Optional

import httpx

from .base import (
    AzureSecurityConfig,
    ContentCategory,
    ContentModerationResult,
    PIICategory,
    PIIDetectionResult,
    PIIEntity,
    PromptShieldResult,
    SecurityAPIError,
    SecurityClientBase,
    SecurityConfigError,
    SecurityProvider,
)

logger = logging.getLogger(__name__)


# Azure Language Service PII Categories (全189種)
AZURE_PII_CATEGORIES = [
    "ABARoutingNumber", "ARNationalIdentityNumber", "AUBankAccountNumber",
    "AUDriversLicenseNumber", "AUMedicalAccountNumber", "AUPassportNumber",
    "AUTaxFileNumber", "AUBusinessNumber", "AUCompanyNumber", "ATIdentityCard",
    "ATTaxIdentificationNumber", "ATValueAddedTaxNumber", "BENationalNumber",
    "BENationalNumberV2", "BEValueAddedTaxNumber", "BRCPFNumber",
    "BRLegalEntityNumber", "BRNationalIDRG", "BGUniformCivilNumber",
    "CABankAccountNumber", "CADriversLicenseNumber", "CAHealthServiceNumber",
    "CAPassportNumber", "CAPersonalHealthIdentification", "CASocialInsuranceNumber",
    "CLIdentityCardNumber", "CNResidentIdentityCardNumber", "CreditCardNumber",
    "HRIdentityCardNumber", "HRNationalIDNumber", "HRPersonalIdentificationNumber",
    "HRPersonalIdentificationOIBNumberV2", "CYIdentityCard", "CYTaxIdentificationNumber",
    "CZPersonalIdentityNumber", "CZPersonalIdentityV2", "DKPersonalIdentificationNumber",
    "DKPersonalIdentificationV2", "DrugEnforcementAgencyNumber", "EEPersonalIdentificationCode",
    "EUDebitCardNumber", "EUDriversLicenseNumber", "EUGPSCoordinates",
    "EUNationalIdentificationNumber", "EUPassportNumber", "EUSocialSecurityNumber",
    "EUTaxIdentificationNumber", "FIEuropeanHealthNumber", "FINationalID",
    "FINationalIDV2", "FIPassportNumber", "FRDriversLicenseNumber",
    "FRHealthInsuranceNumber", "FRNationalID", "FRPassportNumber",
    "FRSocialSecurityNumber", "FRTaxIdentificationNumber", "FRValueAddedTaxNumber",
    "DEDriversLicenseNumber", "DEPassportNumber", "DEIdentityCardNumber",
    "DETaxIdentificationNumber", "DEValueAddedNumber", "GRNationalIDCard",
    "GRNationalIDV2", "GRTaxIdentificationNumber", "HKIdentityCardNumber",
    "HUValueAddedNumber", "HUPersonalIdentificationNumber", "HUTaxIdentificationNumber",
    "INPermanentAccount", "INUniqueIdentificationNumber", "IDIdentityCardNumber",
    "InternationalBankingAccountNumber", "IEPersonalPublicServiceNumber",
    "IEPersonalPublicServiceNumberV2", "ILBankAccountNumber", "ILNationalID",
    "ITDriversLicenseNumber", "ITFiscalCode", "ITValueAddedTaxNumber",
    "JPBankAccountNumber", "JPDriversLicenseNumber", "JPPassportNumber",
    "JPResidentRegistrationNumber", "JPSocialInsuranceNumber", "JPMyNumberCorporate",
    "JPMyNumberPersonal", "JPResidenceCardNumber", "LVPersonalCode",
    "LTPersonalCode", "LUNationalIdentificationNumberNatural",
    "LUNationalIdentificationNumberNonNatural", "MYIdentityCardNumber",
    "MTIdentityCardNumber", "MTTaxIDNumber", "NLCitizensServiceNumber",
    "NLCitizensServiceNumberV2", "NLTaxIdentificationNumber", "NLValueAddedTaxNumber",
    "NZBankAccountNumber", "NZDriversLicenseNumber", "NZInlandRevenueNumber",
    "NZMinistryOfHealthNumber", "NZSocialWelfareNumber", "NOIdentityNumber",
    "PHUnifiedMultiPurposeIDNumber", "PLIdentityCard", "PLNationalID",
    "PLNationalIDV2", "PLPassportNumber", "PLTaxIdentificationNumber",
    "PLREGONNumber", "PTCitizenCardNumber", "PTCitizenCardNumberV2",
    "PTTaxIdentificationNumber", "ROPersonalNumericalCode", "RUPassportNumberDomestic",
    "RUPassportNumberInternational", "SANationalID", "SGNationalRegistrationIdentityCardNumber",
    "SKPersonalNumber", "SITaxIdentificationNumber", "SIUniqueMasterCitizenNumber",
    "ZAIdentificationNumber", "KRResidentRegistrationNumber", "ESDNI",
    "ESSocialSecurityNumber", "ESTaxIdentificationNumber", "SQLServerConnectionString",
    "SENationalID", "SENationalIDV2", "SEPassportNumber", "SETaxIdentificationNumber",
    "SWIFTCode", "CHSocialSecurityNumber", "TWNationalID", "TWPassportNumber",
    "TWResidentCertificate", "THPopulationIdentificationCode", "TRNationalIdentificationNumber",
    "UKDriversLicenseNumber", "UKElectoralRollNumber", "UKNationalHealthNumber",
    "UKNationalInsuranceNumber", "UKUniqueTaxpayerNumber", "USUKPassportNumber",
    "USBankAccountNumber", "USDriversLicenseNumber", "USIndividualTaxpayerIdentification",
    "USSocialSecurityNumber", "UAPassportNumberDomestic", "UAPassportNumberInternational",
    "Email", "Age", "PhoneNumber", "Person", "Address",
]


class AzureSecurityClient(SecurityClientBase):
    """
    Azure Security クライアント

    Azure Content Safety APIとLanguage Service APIを統合し、
    コンテンツモデレーション、Jailbreak攻撃検出、PII検出・マスキングを提供。

    Example:
        config = AzureSecurityConfig(
            content_safety_endpoint="https://xxx.cognitiveservices.azure.com",
            content_safety_api_key="xxx",
        )
        client = AzureSecurityClient(config)

        # Content Moderation
        result = await client.check_content_moderation("some text")
        if result.blocked:
            print("Content blocked")

        # Prompt Shield
        result = await client.check_prompt_shield("user prompt")
        if result.attack_detected:
            print("Attack detected")

        # PII Detection
        result = await client.detect_pii("My email is test@example.com")
        print(result.masked_text)  # "My email is ***"

        await client.close()
    """

    def __init__(self, config: AzureSecurityConfig):
        """
        Initialize Azure Security Client

        Content SafetyまたはPII（Language Service）のどちらか一方でも設定があれば初期化可能。
        両方未設定の場合のみエラー。

        Args:
            config: AzureSecurityConfig instance

        Raises:
            SecurityConfigError: Content SafetyとPII両方が未設定の場合
        """
        super().__init__(config)

        # Content SafetyまたはPIIのどちらかが設定されていればOK
        has_content_safety = bool(config.content_safety_endpoint and config.content_safety_api_key)
        has_pii = bool(config.language_endpoint and config.language_api_key)

        if not has_content_safety and not has_pii:
            raise SecurityConfigError(
                "At least one of Content Safety or PII (Language Service) must be configured. "
                "Provide content_safety_endpoint/api_key or language_endpoint/api_key."
            )

        self._azure_config: AzureSecurityConfig = config
        self._http_client: Optional[httpx.AsyncClient] = None
        self._enabled = config.enabled
        self._has_content_safety = has_content_safety
        self._has_pii = has_pii

        # ログ出力
        cs_status = f"{config.content_safety_endpoint[:30]}..." if has_content_safety else "disabled"
        pii_status = "enabled" if has_pii else "disabled"
        logger.info(
            f"AzureSecurityClient initialized - "
            f"content_safety={cs_status}, "
            f"pii={pii_status}"
        )

    @property
    def provider(self) -> SecurityProvider:
        return SecurityProvider.AZURE

    def _get_http_client(self) -> httpx.AsyncClient:
        """HTTP clientを取得（遅延初期化）"""
        if self._http_client is None or self._http_client.is_closed:
            self._http_client = httpx.AsyncClient(timeout=self._azure_config.timeout)
        return self._http_client

    async def check_content_moderation(
        self,
        text: str,
        threshold: Optional[int] = None,
    ) -> ContentModerationResult:
        """
        有害コンテンツをチェック（Azure Content Safety Moderation API）

        Args:
            text: チェック対象テキスト（最大10,000文字）
            threshold: しきい値（0=無効, 2=推奨, 4=緩い, 6=極度のみ）

        Returns:
            ContentModerationResult: モデレーション結果
        """
        if not self._enabled:
            return ContentModerationResult(blocked=False, error="Client disabled")

        if not self._has_content_safety:
            return ContentModerationResult(blocked=False, error="Content Safety not configured")

        if not self._azure_config.moderation_enabled:
            return ContentModerationResult(blocked=False, threshold=0)

        if not text:
            return ContentModerationResult(blocked=False)

        effective_threshold = threshold if threshold is not None else self._azure_config.moderation_threshold
        if effective_threshold == 0:
            return ContentModerationResult(blocked=False, threshold=0)

        try:
            endpoint = (
                f"{self._azure_config.content_safety_endpoint.rstrip('/')}"
                f"/contentsafety/text:analyze?api-version=2024-09-01"
            )

            request_body = {
                "text": text[:10000],
                "categories": ["Hate", "Sexual", "SelfHarm", "Violence"],
                "outputType": "FourSeverityLevels",
            }

            client = self._get_http_client()
            response = await client.post(
                endpoint,
                headers={
                    "Ocp-Apim-Subscription-Key": self._get_api_key(self._azure_config.content_safety_api_key),
                    "Content-Type": "application/json",
                },
                json=request_body,
            )

            if response.status_code == 200:
                result = response.json()
                categories_analysis = result.get("categoriesAnalysis", [])

                # カテゴリ別severity取得
                categories: Dict[ContentCategory, int] = {}
                blocked = False

                for cat in categories_analysis:
                    category_name = cat.get("category", "").lower()
                    severity = cat.get("severity", 0)

                    normalized_cat = self._normalize_content_category(category_name)
                    categories[normalized_cat] = severity

                    if severity >= effective_threshold:
                        blocked = True
                        logger.warning(
                            f"Content moderation blocked: {category_name} "
                            f"severity={severity} >= threshold={effective_threshold}"
                        )

                return ContentModerationResult(
                    blocked=blocked,
                    categories=categories,
                    threshold=effective_threshold,
                    raw_response=result,
                )
            else:
                error_msg = f"Status {response.status_code}: {response.text}"
                logger.error(f"Content Safety Moderation API error: {error_msg}")
                raise SecurityAPIError(error_msg, response.status_code)

        except SecurityAPIError:
            raise
        except httpx.RequestError as e:
            logger.error(f"Content Safety Moderation request failed: {e}")
            raise SecurityAPIError(str(e), error_code="REQUEST_ERROR")
        except Exception as e:
            logger.error(f"Error in content moderation: {e}")
            raise SecurityAPIError(str(e), error_code="UNKNOWN_ERROR")

    async def check_prompt_shield(
        self,
        user_prompt: str,
        documents: Optional[List[str]] = None,
    ) -> PromptShieldResult:
        """
        Jailbreak攻撃を検出（Azure Content Safety Prompt Shield API）

        Args:
            user_prompt: ユーザープロンプト（最大10,000文字）
            documents: ドキュメント内容（オプション、外部コンテンツ検証用）

        Returns:
            PromptShieldResult: Prompt Shield結果
        """
        if not self._enabled:
            return PromptShieldResult(attack_detected=False, error="Client disabled")

        if not self._has_content_safety:
            return PromptShieldResult(attack_detected=False, error="Content Safety not configured")

        if not self._azure_config.prompt_shield_enabled:
            return PromptShieldResult(attack_detected=False)

        if not user_prompt:
            return PromptShieldResult(attack_detected=False)

        try:
            endpoint = (
                f"{self._azure_config.content_safety_endpoint.rstrip('/')}"
                f"/contentsafety/text:shieldPrompt?api-version=2024-09-01"
            )

            request_body: Dict[str, Any] = {
                "userPrompt": user_prompt[:10000],
            }

            if documents:
                # Azure Prompt Shield: documents合計10,000文字制限のためトリミング
                request_body["documents"] = [doc[:10000] for doc in documents]

            client = self._get_http_client()
            response = await client.post(
                endpoint,
                headers={
                    "Ocp-Apim-Subscription-Key": self._get_api_key(self._azure_config.content_safety_api_key),
                    "Content-Type": "application/json",
                },
                json=request_body,
            )

            if response.status_code == 200:
                result = response.json()
                user_analysis = result.get("userPromptAnalysis", {})
                attack_detected = user_analysis.get("attackDetected", False)

                attack_type = None
                if attack_detected:
                    attack_type = "jailbreak"
                    logger.warning("Prompt Shield detected jailbreak attack")

                return PromptShieldResult(
                    attack_detected=attack_detected,
                    attack_type=attack_type,
                    raw_response=result,
                )
            else:
                error_msg = f"Status {response.status_code}: {response.text}"
                logger.error(f"Prompt Shield API error: {error_msg}")
                raise SecurityAPIError(error_msg, response.status_code)

        except SecurityAPIError:
            raise
        except httpx.RequestError as e:
            logger.error(f"Prompt Shield request failed: {e}")
            raise SecurityAPIError(str(e), error_code="REQUEST_ERROR")
        except Exception as e:
            logger.error(f"Error in prompt shield: {e}")
            raise SecurityAPIError(str(e), error_code="UNKNOWN_ERROR")

    async def detect_pii(
        self,
        text: str,
        mask: bool = True,
        language: str = "ja",
    ) -> PIIDetectionResult:
        """
        PIIを検出・マスク（Azure Language Service PII Detection API）

        Args:
            text: チェック対象テキスト（最大125,000文字）
            mask: マスク処理を行うかどうか
            language: テキストの言語コード（"ja", "en"等）。デフォルト"ja"

        Returns:
            PIIDetectionResult: PII検出結果
        """
        if not self._enabled:
            return PIIDetectionResult(success=False, error="Client disabled")

        if not self._has_pii:
            return PIIDetectionResult(success=False, error="PII (Language Service) not configured")

        if not self._azure_config.pii_enabled:
            return PIIDetectionResult(success=True, masked_text=text)

        if not text:
            return PIIDetectionResult(success=True, masked_text="")

        try:
            endpoint = (
                f"{self._azure_config.language_endpoint.rstrip('/')}"
                f"/language/:analyze-text?api-version=2024-11-01"
            )

            request_body = {
                "kind": "PiiEntityRecognition",
                "parameters": {
                    "modelVersion": "latest",
                    "domain": "none",
                    "loggingOptOut": True,
                    "piiCategories": AZURE_PII_CATEGORIES,
                },
                "analysisInput": {
                    "documents": [
                        {
                            "id": "1",
                            "language": language,
                            "text": text[:125000],
                        }
                    ]
                },
            }

            client = self._get_http_client()
            response = await client.post(
                endpoint,
                headers={
                    "Ocp-Apim-Subscription-Key": self._get_api_key(self._azure_config.language_api_key),
                    "Content-Type": "application/json",
                },
                json=request_body,
            )

            if response.status_code == 200:
                result = response.json()
                documents = result.get("results", {}).get("documents", [])

                if not documents:
                    return PIIDetectionResult(
                        success=True,
                        masked_text="" if mask else text,  # データ保護優先
                    )

                doc_result = documents[0]
                entities_raw = doc_result.get("entities", [])

                # エンティティをPIIEntityに変換
                entities: List[PIIEntity] = []
                categories_detected: List[PIICategory] = []

                for entity in entities_raw:
                    confidence = entity.get("confidenceScore", 0)
                    if confidence < self._azure_config.pii_confidence_threshold:
                        continue

                    provider_category = entity.get("category", "Unknown")
                    normalized_category = self._normalize_pii_category(provider_category)

                    entities.append(PIIEntity(
                        category=normalized_category,
                        text=entity.get("text", ""),
                        offset=entity.get("offset", 0),
                        length=entity.get("length", 0),
                        confidence=confidence,
                        provider_category=provider_category,
                    ))

                    if normalized_category not in categories_detected:
                        categories_detected.append(normalized_category)

                # マスク処理
                masked_text = text
                if mask and entities:
                    # オフセット順で降順ソート（後ろから処理）
                    sorted_entities = sorted(entities, key=lambda x: x.offset, reverse=True)
                    for entity in sorted_entities:
                        masked_text = (
                            masked_text[:entity.offset]
                            + self._azure_config.pii_mask_string
                            + masked_text[entity.offset + entity.length:]
                        )

                if entities:
                    logger.info(f"PII detected and masked: {categories_detected}")

                return PIIDetectionResult(
                    success=True,
                    masked_text=masked_text,
                    entities=entities,
                    categories_detected=categories_detected,
                    raw_response=result,
                )

            else:
                error_msg = f"Status {response.status_code}: {response.text}"
                logger.error(f"Language Service PII API error: {error_msg}")
                # PII検出エラー時は空文字を返す（データ保護優先）
                return PIIDetectionResult(
                    success=False,
                    masked_text="",
                    error=error_msg,
                    error_code="API_ERROR",
                )

        except httpx.RequestError as e:
            logger.error(f"Language Service PII request failed: {e}")
            return PIIDetectionResult(
                success=False,
                masked_text="",
                error=str(e),
                error_code="REQUEST_ERROR",
            )
        except Exception as e:
            logger.error(f"Error in PII detection: {e}")
            return PIIDetectionResult(
                success=False,
                masked_text="",
                error=str(e),
                error_code="UNKNOWN_ERROR",
            )

    async def close(self) -> None:
        """クライアントリソースをクローズ

        Note:
            例外が発生してもリソースを確実にクリーンアップします。
        """
        try:
            if self._http_client and not self._http_client.is_closed:
                await self._http_client.aclose()
        except Exception as e:
            logger.warning(f"Error closing HTTP client: {e}")
        finally:
            self._http_client = None
            self._enabled = False
            logger.debug("AzureSecurityClient closed")
