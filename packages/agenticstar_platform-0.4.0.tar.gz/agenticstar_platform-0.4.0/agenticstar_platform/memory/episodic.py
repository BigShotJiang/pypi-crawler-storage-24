"""
AGENTICSTAR Platform SDK - Episodic Memory (Graphiti/FalkorDB)
汎用エピソディックメモリクライアント

組織階層やPIIマスキングは提供せず、一般的なエピソード保存・検索機能を提供
"""

import os
import re
import hashlib
import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

# Disable Graphiti telemetry before importing graphiti_core
os.environ['GRAPHITI_TELEMETRY_ENABLED'] = 'false'

logger = logging.getLogger(__name__)


class EpisodicMemoryError(Exception):
    """Episodic Memory操作エラー"""
    pass


class EpisodicMemoryConfigError(EpisodicMemoryError):
    """Episodic Memory設定エラー"""
    pass


# ============================================================
# 共通ユーティリティ関数（autonomousからも使用可能）
# ============================================================

# Embedding dimensions by model (共通定数)
EMBEDDING_DIMS = {
    # OpenAI models
    "text-embedding-3-small": 1536,
    "text-embedding-3-large": 3072,
    "text-embedding-ada-002": 1536,
    # Azure variants
    "text-embedding-3-small-1": 1536,
    "ada": 1536,
    # Voyage AI models
    "voyage-3": 1024,
    "voyage-3-lite": 512,
    "voyage-code-3": 1024,
    "voyage-finance-2": 1024,
    "voyage-law-2": 1024,
    "voyage-large-2": 1536,
    "voyage-2": 1024,
    # Gemini models
    "text-embedding-004": 768,
    "embedding-001": 768,
}


def get_embedding_dim(model_name: str) -> int:
    """モデル名から埋め込み次元数を取得

    Args:
        model_name: Embeddingモデル名

    Returns:
        埋め込み次元数（デフォルト: 1536）
    """
    # 完全一致
    if model_name in EMBEDDING_DIMS:
        return EMBEDDING_DIMS[model_name]

    # 部分一致
    model_lower = model_name.lower()
    for key, dim in EMBEDDING_DIMS.items():
        if key in model_lower or model_lower in key:
            return dim

    # デフォルト
    logger.warning(
        f"Unknown embedding model '{model_name}', using default dimension 1536"
    )
    return 1536


def normalize_group_id(group_id: str) -> str:
    """
    group_idをFalkorDB互換形式に正規化

    FalkorDBの制約:
    - 英数字、ハイフン、アンダースコアのみ使用可能
    - 日本語等の特殊文字はハッシュ化

    Args:
        group_id: 元のgroup_id（日本語、スペース等を含む可能性あり）

    Returns:
        正規化されたgroup_id

    Examples:
        "org-ソリューションエンジニアリング本部" → "org-a1b2c3d4e5f6"
        "role-プロダクトマネージャー" → "role-9g8h7i6j5k4l"
        "user-12345" → "user-12345" (変更なし)
    """
    # Already valid? (alphanumeric, dash, underscore only)
    if re.match(r'^[a-zA-Z0-9_-]+$', group_id):
        return group_id

    # Extract prefix (org-/role-/user-/global-)
    prefix_match = re.match(r'^(org-|role-|user-|global-)', group_id)
    if prefix_match:
        prefix = prefix_match.group(1)
        suffix = group_id[len(prefix):]
    else:
        prefix = ""
        suffix = group_id

    # Hash the suffix if it contains non-ASCII or special chars
    if not re.match(r'^[a-zA-Z0-9_-]+$', suffix):
        # SHA256 hash (first 12 chars for readability)
        hash_hex = hashlib.sha256(suffix.encode('utf-8')).hexdigest()[:12]
        normalized = f"{prefix}{hash_hex}"
        logger.debug(f"Normalized group_id: '{group_id}' → '{normalized}'")
        return normalized

    # Suffix is valid, just replace spaces with dashes
    normalized = f"{prefix}{suffix}".replace(" ", "-").replace("_", "-")
    return normalized


@dataclass
class LLMProviderConfig:
    """LLMプロバイダー設定（Mem0と共通）

    マルチプロバイダー対応:
    - azure: Azure OpenAI
    - openai: OpenAI
    - anthropic: Anthropic Claude
    - bedrock: AWS Bedrock
    - gemini: Google Gemini
    - groq: Groq
    """
    model: str  # "azure/gpt-4" or "openai/gpt-4" format
    api_key: str
    base_url: Optional[str] = None  # For Azure
    api_version: Optional[str] = None  # For Azure
    # AWS Bedrock specific
    aws_access_key_id: Optional[str] = None
    aws_secret_access_key: Optional[str] = None
    aws_region_name: Optional[str] = None


@dataclass
class EpisodicMemoryConfig:
    """Episodic Memory設定

    FalkorDB/Graphitiベースのエピソード記憶システムの設定。

    Attributes:
        llm_config: LLMプロバイダー設定
        embedder_config: Embedderプロバイダー設定
        host: FalkorDBホスト（デフォルト: localhost）
        port: FalkorDBポート（デフォルト: 6379）
        database: データベース名（デフォルト: graphiti）

    Example:
        >>> from agenticstar_platform.memory import (
        ...     EpisodicMemoryConfig, EpisodicMemoryClient, LLMProviderConfig
        ... )
        >>>
        >>> config = EpisodicMemoryConfig(
        ...     llm_config=LLMProviderConfig(
        ...         model="azure/gpt-4",
        ...         api_key="your-key",
        ...         base_url="https://your-resource.openai.azure.com",
        ...     ),
        ...     embedder_config=LLMProviderConfig(
        ...         model="azure/text-embedding-3-small",
        ...         api_key="your-key",
        ...         base_url="https://your-resource.openai.azure.com",
        ...     ),
        ...     host="localhost",
        ...     port=6379,
        ... )
        >>> client = EpisodicMemoryClient(config)
    """
    llm_config: LLMProviderConfig
    embedder_config: LLMProviderConfig
    # FalkorDB connection
    host: str = "localhost"
    port: int = 6379
    database: str = "graphiti"

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "EpisodicMemoryConfig":
        """辞書からEpisodicMemoryConfigを作成

        Args:
            data: 設定辞書

        Returns:
            EpisodicMemoryConfig instance

        Example:
            >>> config = EpisodicMemoryConfig.from_dict({
            ...     "llm": {"model": "azure/gpt-4", "api_key": "...", "base_url": "..."},
            ...     "embedder": {"model": "azure/text-embedding-3-small", ...},
            ...     "host": "localhost",
            ...     "port": 6379,
            ... })
        """
        # LLM config
        llm_data = data.get("llm") or data.get("llm_config") or {}
        llm_config = LLMProviderConfig(
            model=llm_data.get("model", ""),
            api_key=llm_data.get("api_key", ""),
            base_url=llm_data.get("base_url"),
            api_version=llm_data.get("api_version"),
        )

        # Embedder config
        embedder_data = data.get("embedder") or data.get("embedder_config") or {}
        embedder_config = LLMProviderConfig(
            model=embedder_data.get("model", ""),
            api_key=embedder_data.get("api_key", ""),
            base_url=embedder_data.get("base_url"),
            api_version=embedder_data.get("api_version"),
        )

        # FalkorDB connection
        host = data.get("host", "localhost")
        port = data.get("port", 6379)
        database = data.get("database", "graphiti")

        return cls(
            llm_config=llm_config,
            embedder_config=embedder_config,
            host=host,
            port=port,
            database=database,
        )


class EpisodicMemoryClient:
    """
    汎用エピソディックメモリクライアント（Graphiti/FalkorDBベース）

    Features:
    - マルチプロバイダーLLM/Embedder/Reranker対応
    - FalkorDBグラフストレージ
    - エピソード追加・検索

    Note:
    - 組織階層（personal/role/org/global）は提供しない
    - PIIマスキングは提供しない（利用側で実装）
    - Community機能は提供しない（利用側で必要に応じて実装）

    Warning:
    - graphiti_coreの制約により、EMBEDDING_DIMはプロセス内でグローバルに設定される
    - 異なるembedding_modelを使用する複数クライアントを同一プロセスで使用すると、
      最後に作成されたクライアントのEMBEDDING_DIMが適用される
    - 異なる次元数のモデルを使用する場合は、別プロセスで実行することを推奨
    """

    # Embedding dimensions by model
    EMBEDDING_DIMS = {
        # OpenAI models
        "text-embedding-3-small": 1536,
        "text-embedding-3-large": 3072,
        "text-embedding-ada-002": 1536,
        # Azure variants
        "text-embedding-3-small-1": 1536,
        "ada": 1536,
        # Voyage AI models
        "voyage-3": 1024,
        "voyage-3-lite": 512,
        "voyage-code-3": 1024,
        "voyage-finance-2": 1024,
        "voyage-law-2": 1024,
        "voyage-large-2": 1536,
        "voyage-2": 1024,
        # Gemini models
        "text-embedding-004": 768,
        "embedding-001": 768,
    }

    def __init__(self, config: EpisodicMemoryConfig):
        """
        Initialize Episodic Memory Client

        Args:
            config: EpisodicMemoryConfig instance

        Raises:
            EpisodicMemoryConfigError: 設定が不正な場合
        """
        if not config:
            raise EpisodicMemoryConfigError("EpisodicMemoryConfig is required")

        if not config.llm_config or not config.embedder_config:
            raise EpisodicMemoryConfigError(
                "Both llm_config and embedder_config are required"
            )

        self._config = config
        self._graphiti = None
        self._driver = None
        self._enabled = False
        self._embedding_dim: Optional[int] = None
        # Track clients for proper cleanup
        self._llm_client = None
        self._embedder = None
        self._reranker = None
        self._openai_client = None  # For Azure/OpenAI async client

        try:
            from graphiti_core import Graphiti
            from graphiti_core.driver.falkordb_driver import FalkorDriver

            # Initialize FalkorDB driver
            self._driver = FalkorDriver(
                host=config.host,
                port=config.port,
                database=config.database,
            )
            logger.info(
                f"FalkorDB driver initialized - "
                f"host={config.host}, port={config.port}, database={config.database}"
            )

            # Initialize LLM client
            self._llm_client, self._openai_client = self._create_llm_client(config.llm_config)

            # Initialize embedder
            self._embedder = self._create_embedder(config.embedder_config)

            # Initialize reranker
            self._reranker = self._create_reranker(config.llm_config, self._openai_client)

            # Initialize Graphiti
            self._graphiti = Graphiti(
                graph_driver=self._driver,
                llm_client=self._llm_client,
                embedder=self._embedder,
                cross_encoder=self._reranker,
            )

            self._enabled = True
            logger.info(
                f"EpisodicMemoryClient initialized - "
                f"llm={config.llm_config.model}, "
                f"embedder={config.embedder_config.model}"
            )

        except ImportError as e:
            logger.warning(
                f"graphiti-core not installed. "
                f"Episodic memory will be disabled: {e}"
            )
            self._enabled = False
        except Exception as e:
            logger.error(f"Failed to initialize EpisodicMemoryClient: {e}")
            raise EpisodicMemoryConfigError(
                f"Failed to initialize Graphiti: {e}"
            ) from e

    @property
    def enabled(self) -> bool:
        """クライアントが有効かどうか"""
        return self._enabled

    @property
    def embedding_dim(self) -> Optional[int]:
        """現在のembedding次元数"""
        return self._embedding_dim

    @property
    def graphiti(self):
        """内部Graphitiインスタンスへのアクセス（高度な操作用）"""
        return self._graphiti

    def _parse_model_string(self, model: str) -> tuple[str, str]:
        """モデル文字列をプロバイダーとモデル名に分離"""
        if "/" in model:
            provider = model.split("/")[0]
            model_name = model.split("/", 1)[1]
        else:
            provider = "openai"
            model_name = model
        return provider.lower(), model_name

    def _get_api_key(self, config: LLMProviderConfig) -> str:
        """APIキーを取得（SecretStr対応）"""
        api_key = config.api_key
        if hasattr(api_key, 'get_secret_value'):
            return api_key.get_secret_value()
        return api_key

    def _get_embedding_dim(self, model_name: str) -> int:
        """モデル名から埋め込み次元数を取得"""
        # 完全一致
        if model_name in self.EMBEDDING_DIMS:
            return self.EMBEDDING_DIMS[model_name]

        # 部分一致
        model_lower = model_name.lower()
        for key, dim in self.EMBEDDING_DIMS.items():
            if key in model_lower or model_lower in key:
                return dim

        # デフォルト
        logger.warning(
            f"Unknown embedding model '{model_name}', using default dimension 1536"
        )
        return 1536

    def _create_llm_client(self, llm_config: LLMProviderConfig):
        """LLMクライアントを作成（マルチプロバイダー対応）"""
        from graphiti_core.llm_client import LLMConfig, OpenAIClient

        provider, model_name = self._parse_model_string(llm_config.model)
        api_key = self._get_api_key(llm_config)

        graphiti_config = LLMConfig(
            model=model_name,
            small_model=model_name,
        )

        if provider == "azure":
            from graphiti_core.llm_client.azure_openai_client import AzureOpenAILLMClient
            from openai import AsyncAzureOpenAI

            azure_client = AsyncAzureOpenAI(
                azure_endpoint=llm_config.base_url,
                api_key=api_key,
                api_version=llm_config.api_version or "2025-03-01-preview"
            )
            return AzureOpenAILLMClient(
                azure_client=azure_client,
                config=graphiti_config
            ), azure_client

        elif provider == "anthropic":
            from graphiti_core.llm_client.anthropic_client import AnthropicClient
            graphiti_config.api_key = api_key
            client = AnthropicClient(config=graphiti_config)
            return client, client.client

        elif provider == "openai":
            graphiti_config.api_key = api_key
            client = OpenAIClient(config=graphiti_config)
            return client, client.client

        elif provider == "gemini":
            from graphiti_core.llm_client.gemini_client import GeminiClient
            graphiti_config.api_key = api_key
            client = GeminiClient(config=graphiti_config)
            return client, client.client

        elif provider == "groq":
            from graphiti_core.llm_client.groq_client import GroqClient
            graphiti_config.api_key = api_key
            client = GroqClient(config=graphiti_config)
            return client, client.client

        else:
            raise EpisodicMemoryConfigError(f"Unsupported LLM provider: {provider}")

    def _create_embedder(self, embedder_config: LLMProviderConfig):
        """Embedderを作成（マルチプロバイダー対応）

        Note:
            graphiti_coreの制約により、EMBEDDING_DIMはプロセスレベルで設定される。
            同一プロセスで異なるembedding次元を使用する複数クライアントは非推奨。
        """
        from graphiti_core.embedder.openai import OpenAIEmbedder, OpenAIEmbedderConfig

        provider, model_name = self._parse_model_string(embedder_config.model)
        api_key = self._get_api_key(embedder_config)

        # Get and store embedding dimension
        self._embedding_dim = self._get_embedding_dim(model_name)

        # Set embedding dimension environment variable (graphiti_core requirement)
        # WARNING: This is a global setting that affects all clients in the process
        os.environ['EMBEDDING_DIM'] = str(self._embedding_dim)
        # Update graphiti_core constant
        import graphiti_core.embedder.client as embedder_client
        embedder_client.EMBEDDING_DIM = self._embedding_dim
        logger.debug(f"Set EMBEDDING_DIM={self._embedding_dim} for model: {model_name}")

        if provider == "azure":
            from graphiti_core.embedder.azure_openai import AzureOpenAIEmbedderClient
            from openai import AsyncAzureOpenAI

            azure_client = AsyncAzureOpenAI(
                azure_endpoint=embedder_config.base_url,
                api_key=api_key,
                api_version=embedder_config.api_version or "2023-05-15"
            )
            return AzureOpenAIEmbedderClient(
                azure_client=azure_client,
                model=model_name
            )

        elif provider == "openai":
            config = OpenAIEmbedderConfig(
                embedding_model=model_name,
                api_key=api_key,
            )
            return OpenAIEmbedder(config=config)

        elif provider == "gemini":
            from graphiti_core.embedder.gemini import GeminiEmbedder, GeminiEmbedderConfig
            config = GeminiEmbedderConfig(
                embedding_model=model_name,
                api_key=api_key,
            )
            return GeminiEmbedder(config=config)

        elif provider == "voyage":
            from graphiti_core.embedder.voyage import VoyageEmbedder, VoyageEmbedderConfig
            config = VoyageEmbedderConfig(
                embedding_model=model_name,
                api_key=api_key,
            )
            return VoyageEmbedder(config=config)

        else:
            # Default to OpenAI format
            config = OpenAIEmbedderConfig(
                embedding_model=model_name,
                api_key=api_key,
            )
            return OpenAIEmbedder(config=config)

    def _create_reranker(self, llm_config: LLMProviderConfig, openai_client):
        """Rerankerを作成（マルチプロバイダー対応）"""
        from graphiti_core.llm_client import LLMConfig

        provider, model_name = self._parse_model_string(llm_config.model)
        api_key = self._get_api_key(llm_config)

        if provider in ("azure", "openai"):
            from graphiti_core.cross_encoder.openai_reranker_client import OpenAIRerankerClient
            reranker_config = LLMConfig(model=model_name)
            return OpenAIRerankerClient(config=reranker_config, client=openai_client)

        elif provider == "gemini":
            from graphiti_core.cross_encoder.gemini_reranker_client import GeminiRerankerClient
            reranker_config = LLMConfig(
                api_key=api_key,
                model="gemini-2.5-flash-lite-preview-06-17",
            )
            return GeminiRerankerClient(config=reranker_config)

        else:
            # Anthropic, Groq等はネイティブrerankerがない
            logger.warning(
                f"Provider '{provider}' does not have native reranker support. "
                "Reranking disabled."
            )
            return None

    # Maximum recommended episode body size (characters)
    MAX_EPISODE_BODY_SIZE = 100000

    async def add_episode(
        self,
        group_id: str,
        content: str,
        name: Optional[str] = None,
        user_id: Optional[str] = None,
    ) -> bool:
        """
        エピソードを追加

        テキストをエピソードとして追加します。

        Args:
            group_id: グループID（FalkorDB互換形式に自動正規化）
            content: エピソード内容（テキスト）
            name: エピソード名（省略時は自動生成）
            user_id: ユーザーID（ソース記述に使用）

        Returns:
            成功した場合True

        Raises:
            EpisodicMemoryError: 追加に失敗した場合

        Example:
            >>> await client.add_episode(
            ...     group_id="user-123",
            ...     content="ユーザーはPythonに興味があります",
            ...     name="user_interest",
            ... )

        Note:
            episode_bodyが100,000文字を超える場合は警告を出力します。
            大きなエピソードはパフォーマンスに影響する可能性があります。
        """
        if not self._enabled:
            return False

        if not content:
            raise EpisodicMemoryError("'content' is required")

        try:
            from graphiti_core.nodes import EpisodeType

            # Normalize group_id
            normalized_group_id = normalize_group_id(group_id)

            # Warn if episode body is too large
            body_size = len(content)
            if body_size > self.MAX_EPISODE_BODY_SIZE:
                logger.warning(
                    f"Episode body is large ({body_size} chars, recommended max: "
                    f"{self.MAX_EPISODE_BODY_SIZE}). Consider splitting into smaller episodes."
                )

            # エピソード名を決定
            actual_name = name
            if not actual_name:
                actual_name = content[:50] + "..." if len(content) > 50 else content

            # Add episode to Graphiti
            # NOTE: update_communities=False to avoid graphiti-core bugs
            await self._graphiti.add_episode(
                group_id=normalized_group_id,
                name=actual_name,
                episode_body=content,
                source=EpisodeType.message,
                source_description=f"sdk-client-{user_id}" if user_id else "sdk-client",
                reference_time=datetime.now(timezone.utc),
                update_communities=False,
            )

            logger.debug(
                f"Episode added - group_id={normalized_group_id}"
            )
            return True

        except Exception as e:
            logger.error(f"Failed to add episode: {e}")
            raise EpisodicMemoryError(f"Failed to add episode: {e}") from e

    async def search(
        self,
        query: str,
        group_ids: Optional[List[str]] = None,
        max_facts: int = 10,
    ) -> Dict[str, Any]:
        """
        エピソード記憶を検索

        Args:
            query: 検索クエリ
            group_ids: 検索対象グループIDリスト（省略時は全グループ）
            max_facts: 結果数上限（デフォルト: 10）

        Returns:
            Dict[str, Any]: 検索結果
                - success: bool
                - data: {
                    "query": str,
                    "results": [{"fact": str, "created_at": str, "uuid": str}],
                    "total_found": int
                  }
                - error: str, error_code: str (失敗時)

        Example:
            >>> result = await client.search(
            ...     query="Pythonに関する情報",
            ...     group_ids=["user-123"],
            ...     max_facts=5,
            ... )
            >>> if result["success"]:
            ...     for item in result["data"]["results"]:
            ...         print(item["fact"])

        Raises:
            EpisodicMemoryError: 検索に失敗した場合
        """
        if not self._enabled:
            return {
                "success": False,
                "error": "Episodic memory is not enabled",
                "error_code": "DISABLED",
            }

        try:
            # Normalize group_ids
            normalized_group_ids = None
            if group_ids:
                normalized_group_ids = [normalize_group_id(gid) for gid in group_ids]

            # Search
            edges = await self._graphiti.search(
                query=query,
                group_ids=normalized_group_ids,
                num_results=max_facts,
            )

            # Convert to fact dicts
            facts = []
            for edge in edges:
                fact = {
                    "fact": edge.fact if hasattr(edge, 'fact') else str(edge),
                    "created_at": edge.created_at.isoformat() if hasattr(edge, 'created_at') else None,
                    "uuid": edge.uuid if hasattr(edge, 'uuid') else None,
                }
                facts.append(fact)

            logger.debug(f"Search returned {len(facts)} facts")
            return {
                "success": True,
                "data": {
                    "query": query,
                    "results": facts,
                    "total_found": len(facts),
                },
            }

        except Exception as e:
            logger.error(f"Failed to search: {e}")
            return {
                "success": False,
                "error": f"Search error: {str(e)}",
                "error_code": "EPISODIC_SEARCH_ERROR",
            }

    async def get_recent_episodes(
        self,
        group_id: str,
        last_n: int = 5,
    ) -> List[Any]:
        """
        最近のエピソードを取得

        Args:
            group_id: グループID
            last_n: 取得するエピソード数

        Returns:
            エピソードリスト
        """
        if not self._enabled:
            return []

        try:
            normalized_group_id = normalize_group_id(group_id)

            episodes = await self._graphiti.retrieve_episodes(
                group_ids=[normalized_group_id],
                last_n=last_n,
                reference_time=datetime.now(timezone.utc),
            )

            logger.debug(
                f"Retrieved {len(episodes)} recent episodes for group_id={group_id}"
            )
            return episodes

        except Exception as e:
            logger.error(f"Failed to get recent episodes: {e}")
            raise EpisodicMemoryError(
                f"Failed to get recent episodes: {e}"
            ) from e

    def format_facts_for_context(
        self,
        facts: List[Dict[str, Any]],
        max_facts: int = 5,
        title: str = "### Episodic Memory",
    ) -> str:
        """
        ファクトをLLMコンテキスト用にフォーマット

        Args:
            facts: ファクトリスト
            max_facts: 最大ファクト数
            title: セクションタイトル

        Returns:
            フォーマットされた文字列
        """
        if not facts:
            return ""

        lines = [title]

        for i, fact in enumerate(facts[:max_facts], 1):
            fact_text = fact.get("fact", "")
            created_at = fact.get("created_at")

            if created_at:
                try:
                    dt = datetime.fromisoformat(created_at.replace("Z", "+00:00"))
                    time_str = dt.strftime("%Y-%m-%d %H:%M")
                except:
                    time_str = created_at
                lines.append(f"{i}. [{time_str}] {fact_text}")
            else:
                lines.append(f"{i}. {fact_text}")

        return "\n".join(lines)

    async def close(self) -> None:
        """コネクションとクライアントリソースをクローズ

        Note:
            FalkorDBドライバー、LLMクライアント、Embedder、Rerankerを
            すべてクローズします。
        """
        errors = []

        # Close FalkorDB driver
        try:
            if self._driver and hasattr(self._driver, 'close'):
                await self._driver.close()
                self._driver = None
        except Exception as e:
            errors.append(f"driver: {e}")

        # Close OpenAI/Azure async client
        try:
            if self._openai_client and hasattr(self._openai_client, 'close'):
                await self._openai_client.close()
                self._openai_client = None
        except Exception as e:
            errors.append(f"openai_client: {e}")

        # Note: LLM client, embedder, reranker typically don't have close methods
        # but we clear references to allow garbage collection
        self._llm_client = None
        self._embedder = None
        self._reranker = None
        self._graphiti = None
        self._enabled = False

        if errors:
            logger.warning(f"Errors during close: {', '.join(errors)}")
        else:
            logger.debug("EpisodicMemoryClient closed successfully")
