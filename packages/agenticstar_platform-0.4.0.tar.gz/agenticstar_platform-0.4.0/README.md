# AGENTICSTAR Platform SDK

Enterprise AI Agent Infrastructure SDK for building autonomous agent systems.

## Installation

```bash
# Core (minimal)
pip install agenticstar-platform

# With specific modules
pip install agenticstar-platform[db]           # PostgreSQL
pip install agenticstar-platform[rag]          # Qdrant + Embedding
pip install agenticstar-platform[storage]      # Azure Blob, S3, GCS
pip install agenticstar-platform[storage-azure] # Azure Blob only
pip install agenticstar-platform[semantic]     # Semantic memory (Mem0)
pip install agenticstar-platform[episodic]     # Episodic memory (Graphiti/FalkorDB)
pip install agenticstar-platform[security]     # PII detection
pip install agenticstar-platform[all]          # All modules
```

## Quick Start

```python
from agenticstar_platform import (
    # Database
    PostgreSQLManager, PostgreSQLConfig,
    # RAG (Vector DB + Embedding)
    QdrantManager, QdrantConfig, EmbeddingGenerator, EmbeddingConfig,
    # Storage
    AzureBlobStorageClient, AzureBlobConfig,
    # Events
    EventEmitter, EventType,
    # Auth
    AgenticStarAuthClient, AgenticStarAuthConfig,
    # Memory
    SemanticMemoryClient, SemanticMemoryConfig,
)

# Optional: Episodic memory (requires agenticstar-platform[episodic])
from agenticstar_platform.memory import EpisodicMemoryClient, EpisodicMemoryConfig

# Example: Initialize SDK components
async def main():
    # Database
    db_config = PostgreSQLConfig.from_toml("config.toml", section="database")
    async with PostgreSQLManager(db_config) as db:
        users = await db.fetch_all("SELECT * FROM users WHERE active = $1", (True,))

    # RAG System
    embedding_config = EmbeddingConfig.from_toml("config.toml", section="rag.embedding")
    embedding_gen = EmbeddingGenerator(embedding_config)

    qdrant_config = QdrantConfig.from_toml("config.toml", section="rag.qdrant")
    async with QdrantManager(qdrant_config, embedding_gen) as qdrant:
        results = await qdrant.search("How to use the SDK?", limit=5)

    # Storage (uses from_dict, not from_toml)
    storage_config = AzureBlobConfig.from_dict({
        "bucket_name": "your-container",
        "connection_string": "your-connection-string",
    })
    storage = AzureBlobStorageClient(storage_config)
```

## Modules

| Module | Extra | Description |
|--------|-------|-------------|
| **db** | `[db]` | PostgreSQL data access layer with Azure AD support |
| **rag** | `[rag]` | Qdrant vector database and Azure OpenAI embedding integration |
| **storage** | `[storage]` / `[storage-azure]` / `[storage-aws]` / `[storage-gcp]` | Multi-cloud storage (Azure Blob, S3, GCS) |
| **auth** | *(core)* | AgenticStar Auth API client (authentication, user management, MCP tokens) |
| **memory** | `[semantic]` / `[episodic]` | Semantic (Mem0) and episodic (Graphiti/FalkorDB) memory |
| **security** | `[security]` | PII detection (Azure Presidio, AWS Comprehend, GCP DLP) |
| **events** | *(core)* | Event type definitions for streaming |
| **common** | *(core)* | Shared utilities (secret masking, validation) |

### Auth Module

```python
from agenticstar_platform.auth import AgenticStarAuthClient, AgenticStarAuthConfig

# From config.toml [auth.agenticstar] section
config = AgenticStarAuthConfig.from_config("config.toml")
client = AgenticStarAuthClient(config)

# Get user info
user = await client.get_user(user_id="user-001")

# Get MCP tokens
tokens = await client.get_mcp_tokens(user_id="user-001")
```

### Memory Module

**Semantic Memory** (requires `pip install agenticstar-platform[semantic]`):

```python
from agenticstar_platform.memory import SemanticMemoryClient, SemanticMemoryConfig

config = SemanticMemoryConfig.from_toml("config.toml")
memory = SemanticMemoryClient(config)

# Add memory
await memory.add("User prefers dark mode", user_id="user-001")

# Search memory
results = await memory.search("user preferences", user_id="user-001")
```

**Episodic Memory** (requires `pip install agenticstar-platform[episodic]`):

```python
from agenticstar_platform.memory import EpisodicMemoryClient, EpisodicMemoryConfig

config = EpisodicMemoryConfig.from_toml("config.toml")
memory = EpisodicMemoryClient(config)

# Add episode
await memory.add_episode(
    name="task_completed",
    episode_body="User completed the deployment task",
    group_id="project-alpha",
)

# Search episodes
results = await memory.search("deployment", group_id="project-alpha")
```

### Storage Module

Note: `AzureBlobConfig` uses `from_dict()` (not `from_toml()`):

```python
from agenticstar_platform.storage import AzureBlobStorageClient, AzureBlobConfig

config = AzureBlobConfig.from_dict({
    "bucket_name": "your-container",
    "connection_string": "DefaultEndpointsProtocol=https;...",
    "prefix": "uploads/",
})
client = AzureBlobStorageClient(config)
result = await client.upload_file("local/file.pdf", prefix="docs/")
```

## Platform Class Example

Below is an example of a Platform class that wraps SDK components for your agent system:

```python
"""
Platform class example - Using AGENTICSTAR Platform SDK
"""
import asyncio
from dataclasses import dataclass
from typing import Optional

from agenticstar_platform import (
    PostgreSQLManager, PostgreSQLConfig,
    QdrantManager, QdrantConfig,
    EmbeddingGenerator, EmbeddingConfig,
    EventEmitter, EventType,
    SemanticMemoryClient, SemanticMemoryConfig,
    AzureBlobStorageClient, AzureBlobConfig,
    AgenticStarAuthClient, AgenticStarAuthConfig,
)


@dataclass
class PlatformConfig:
    """Platform configuration"""
    db_config: PostgreSQLConfig
    qdrant_config: QdrantConfig
    embedding_config: EmbeddingConfig
    storage_config: Optional[AzureBlobConfig] = None
    memory_config: Optional[SemanticMemoryConfig] = None
    auth_config: Optional[AgenticStarAuthConfig] = None

    @classmethod
    def from_toml(cls, path: str) -> "PlatformConfig":
        """Load all configurations from TOML file"""
        return cls(
            db_config=PostgreSQLConfig.from_toml(path, section="database"),
            qdrant_config=QdrantConfig.from_toml(path, section="rag.qdrant"),
            embedding_config=EmbeddingConfig.from_toml(path, section="rag.embedding"),
            storage_config=AzureBlobConfig.from_dict({
                # Load from environment or config
                "bucket_name": "your-container",
                "connection_string": "your-connection-string",
            }),
            auth_config=AgenticStarAuthConfig.from_config(path),
        )


class AgentPlatform:
    """
    Platform class wrapping SDK components.

    Example:
        >>> config = PlatformConfig.from_toml("config.toml")
        >>> platform = AgentPlatform(config)
        >>> await platform.initialize()
        >>>
        >>> # Use database
        >>> users = await platform.db.fetch_all("SELECT * FROM users")
        >>>
        >>> # Use RAG
        >>> results = await platform.search_knowledge("How to deploy?")
        >>>
        >>> # Clean up
        >>> await platform.cleanup()
    """

    def __init__(self, config: PlatformConfig):
        self.config = config
        self._db: Optional[PostgreSQLManager] = None
        self._qdrant: Optional[QdrantManager] = None
        self._embedding: Optional[EmbeddingGenerator] = None
        self._storage: Optional[AzureBlobStorageClient] = None
        self._memory: Optional[SemanticMemoryClient] = None
        self._auth: Optional[AgenticStarAuthClient] = None

    async def initialize(self) -> None:
        """Initialize all SDK components"""
        # Database
        self._db = PostgreSQLManager(self.config.db_config)
        await self._db.initialize()

        # Embedding generator
        self._embedding = EmbeddingGenerator(self.config.embedding_config)

        # Vector DB (RAG)
        self._qdrant = QdrantManager(self.config.qdrant_config, self._embedding)
        await self._qdrant.initialize()

        # Storage (optional)
        if self.config.storage_config:
            self._storage = AzureBlobStorageClient(self.config.storage_config)

        # Memory (optional)
        if self.config.memory_config:
            self._memory = SemanticMemoryClient(self.config.memory_config)

        # Auth (optional)
        if self.config.auth_config:
            self._auth = AgenticStarAuthClient(self.config.auth_config)

    @property
    def db(self) -> PostgreSQLManager:
        if not self._db:
            raise RuntimeError("Platform not initialized. Call initialize() first.")
        return self._db

    @property
    def qdrant(self) -> QdrantManager:
        if not self._qdrant:
            raise RuntimeError("Platform not initialized. Call initialize() first.")
        return self._qdrant

    @property
    def storage(self) -> Optional[AzureBlobStorageClient]:
        return self._storage

    @property
    def memory(self) -> Optional[SemanticMemoryClient]:
        return self._memory

    @property
    def auth(self) -> Optional[AgenticStarAuthClient]:
        return self._auth

    async def search_knowledge(self, query: str, limit: int = 10):
        return await self.qdrant.search(query, limit=limit)

    async def cleanup(self) -> None:
        """Clean up all resources"""
        if self._qdrant:
            await self._qdrant.close()
        if self._db:
            await self._db.close()
        if self._storage:
            await self._storage.close()
        if self._memory:
            await self._memory.cleanup()
```

## Configuration (config.toml example)

```toml
[database]
host = "your-postgresql.postgres.database.azure.com"
port = 5432
database = "agenticai"
username = "admin"
password = "your-password"
use_azure_ad = false
pool_min_size = 2
pool_max_size = 10

[database.azure_ad]
tenant_id = "your-tenant-id"
client_id = "your-client-id"
client_secret = "your-client-secret"

[auth.agenticstar]
base_url = "https://auth.agenticstar.tm.softbank.jp"
api_key = ""
timeout = 30.0
max_retries = 3

[rag.embedding]
api_base = "https://your-openai.openai.azure.com/"
api_key = "your-api-key"
deployment_name = "text-embedding-ada-002"

[rag.qdrant]
url = "http://localhost:6333"
collection_name = "knowledge_base"
vector_size = 1536

[storage.azure]
bucket_name = "your-container"
connection_string = "DefaultEndpointsProtocol=https;..."
prefix = "uploads/"

[memory.llm]
model = "azure/gpt-4"
api_key = "your-api-key"
base_url = "https://your-openai.openai.azure.com/"
api_version = "2024-02-15-preview"

[memory.embedder]
model = "azure/text-embedding-ada-002"
api_key = "your-api-key"
base_url = "https://your-openai.openai.azure.com/"
api_version = "2024-02-15-preview"

[memory.graphiti]
enabled = true
host = "falkordb.falkordb.svc.cluster.local"
port = 6379
database = "graphiti"
```

## API Reference

See [API_REFERENCE.md](./API_REFERENCE.md) for detailed API documentation.

## Changelog

### 0.4.0 (2026-03-21)

- **Security: Prompt Shield documents trimming** - `check_prompt_shield()` now trims each document to 10,000 characters to comply with Azure API limits. Previously, WebFetch results exceeding 10,000 characters were blocked even without violations.
- **Security: PII detection language support** - `detect_pii()` now accepts a `language` parameter (default: `"ja"`) for accurate multi-language PII detection. Previously hardcoded to Japanese.
- **Security: Protocol/ABC updated** - `SecurityClientProtocol` and `SecurityClientBase` updated with `language` parameter in `detect_pii()`.

### 0.3.2

- Storage module: Multi-cloud support (Azure Blob, S3, GCS)
- Auth module: AgenticStar Auth API client
- Memory module: Semantic (Mem0) and Episodic (Graphiti) memory

## Version

0.4.0
