"""Allow running as python -m ai_interview or python -m ai_interview.overlay."""
from ai_interview.cli import cli

cli()
