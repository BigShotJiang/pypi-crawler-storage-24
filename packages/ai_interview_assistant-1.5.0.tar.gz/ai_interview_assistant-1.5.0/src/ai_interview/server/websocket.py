"""WebSocket endpoint and broadcast helper."""

from __future__ import annotations

import json
import logging

from aiohttp import web, WSMsgType

from ai_interview.state import state

logger = logging.getLogger(__name__)


async def ws_handler(request: web.Request) -> web.WebSocketResponse:
    """Handle a WebSocket connection from a viewer device."""
    ws = web.WebSocketResponse()
    await ws.prepare(request)

    state.ws_clients.add(ws)
    logger.info("Viewer connected (total=%d)", len(state.ws_clients))

    # Send current status immediately so the viewer reflects the right state
    await ws.send_str(json.dumps({"type": "status", "value": state.status}))

    # If there's a previous response, send it so a reconnecting phone sees the last answer
    if state.last_response:
        await ws.send_str(json.dumps({"type": "done", "full_text": state.last_response}))

    try:
        async for msg in ws:
            if msg.type in (WSMsgType.CLOSE, WSMsgType.ERROR):
                break
            # No client→server messages expected, but silently ignore anything sent
    finally:
        state.ws_clients.discard(ws)
        logger.info("Viewer disconnected (total=%d)", len(state.ws_clients))

    return ws


async def broadcast(message: dict) -> None:
    """Send a JSON message to all connected viewers."""
    if not state.ws_clients:
        return

    data = json.dumps(message)
    dead = set()

    for ws in list(state.ws_clients):
        try:
            await ws.send_str(data)
        except Exception:
            dead.add(ws)

    state.ws_clients -= dead
