"""AI Interview Assistant — ghost background tool for live code challenges."""

__version__ = "1.5.0"
