#!/usr/bin/env python
"""
Calculate the RNA-seq reads coverage over gene body.

Note:
1) Only input sorted and indexed BAM file(s). SAM format is not supported.
2) Genes/transcripts with mRNA length < 100 will be skipped (Number specified to "-l" cannot be < 100).
"""

import collections
import operator
import sys
from os.path import basename
from time import strftime

import numpy as np
import pysam
from numpy import mean, std

from rseqc import getBamFiles, mystat
from rseqc.cli_common import add_output_prefix_arg, add_refgene_arg, create_parser, run_rscript, validate_files_exist


def valid_name(s: str) -> str:
    """make sure the string 's' is valid name for R variable"""
    symbols = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_."
    digit = "0123456789"
    rid = "_".join(i for i in s.split())  # replace space(s) with '_'
    if rid[0] in digit:
        rid = "V" + rid
    tmp = ""
    for i in rid:
        if i in symbols:
            tmp = tmp + i
        else:
            tmp = tmp + "_"
    return tmp


def printlog(mesg: str) -> None:
    """print progress into stderr and log file"""
    mesg = "@ " + strftime("%Y-%m-%d %H:%M:%S") + ": " + mesg
    print(mesg, file=sys.stderr)
    with open("log.txt", "a") as LOG:
        print(mesg, file=LOG)


def pearson_moment_coefficient(lst: list[float]) -> float:
    """measure skewness"""
    mid_value = lst[int(len(lst) / 2)]
    sigma = std(lst, ddof=1)
    tmp = []
    for i in lst:
        tmp.append(((i - mid_value) / sigma) ** 3)
    return mean(tmp)


def genebody_percentile(refbed: str, mRNA_len_cut: int = 100) -> dict:
    """
    return percentile points of gene body
    mRNA length < mRNA_len_cut will be skipped
    """
    if refbed is None:
        print("You must specify a bed file representing gene model\n", file=sys.stderr)
        sys.exit(1)

    g_percentiles = {}
    transcript_count = 0
    with open(refbed, "r") as _fh:
        for line in _fh:
            try:
                if line.startswith(("#", "track", "browser")):
                    continue
                # Parse fields from gene tabls
                fields = line.split()
                chrom = fields[0]
                tx_start = int(fields[1])
                tx_end = int(fields[2])
                geneName = fields[3]
                strand = fields[5]
                geneID = "_".join([str(j) for j in (chrom, tx_start, tx_end, geneName, strand)])

                exon_starts = [int(x) for x in fields[11].rstrip(",\n").split(",")]
                exon_starts = [x + tx_start for x in exon_starts]
                exon_ends = [int(x) for x in fields[10].rstrip(",\n").split(",")]
                exon_ends = [x + y for x, y in zip(exon_starts, exon_ends)]
                transcript_count += 1
            except (IndexError, ValueError):
                print("[NOTE:input bed must be 12-column] skipped this line: " + line, end=" ", file=sys.stderr)
                continue
            gene_all_base = []
            for st, end in zip(exon_starts, exon_ends):
                gene_all_base.extend(list(range(st + 1, end + 1)))  # 1-based coordinates on genome
            if len(gene_all_base) < mRNA_len_cut:
                continue
            g_percentiles[geneID] = (
                chrom,
                strand,
                mystat.percentile_list(gene_all_base),
            )  # get 100 points from each gene's coordinates
    printlog("Total " + str(transcript_count) + " transcripts loaded")
    return g_percentiles


def genebody_coverage(bam: str, position_list: dict) -> dict:
    """
    position_list is dict returned from genebody_percentile
    position is 1-based genome coordinate

    Uses pysam's C-level count_coverage() instead of Python-level pileup iteration.
    """
    samfile = pysam.AlignmentFile(bam, "rb")
    aggreagated_cvg = collections.defaultdict(int)

    gene_finished = 0
    for chrom, strand, positions in position_list.values():
        chrom_start = positions[0] - 1
        if chrom_start < 0:
            chrom_start = 0
        chrom_end = positions[-1]
        try:
            # count_coverage returns 4 array.array objects (A, C, G, T per-base counts)
            # quality_threshold=0: no base quality filtering (matches original behavior)
            # read_callback='all': skip unmapped, qcfail, secondary, duplicate
            a_arr, c_arr, g_arr, t_arr = samfile.count_coverage(
                chrom, chrom_start, chrom_end, quality_threshold=0, read_callback="all"
            )
        except (KeyError, ValueError):
            continue

        total = np.array(a_arr) + np.array(c_arr) + np.array(g_arr) + np.array(t_arr)

        # Extract coverage at the selected percentile positions
        tmp = []
        for pos in positions:
            idx = pos - 1 - chrom_start
            if 0 <= idx < len(total):
                tmp.append(int(total[idx]))
            else:
                tmp.append(0)

        if strand == "-":
            tmp = tmp[::-1]
        for i in range(len(tmp)):
            aggreagated_cvg[i] += tmp[i]
        gene_finished += 1

        if gene_finished % 100 == 0:
            print("\t%d transcripts finished\r" % (gene_finished), end=" ", file=sys.stderr)
    return aggreagated_cvg


def Rcode_write(dataset: list, file_prefix: str, format: str = "pdf", colNum: int = 100) -> None:
    """generate R script for visualization"""
    with open(file_prefix + ".r", "w") as ROUT:
        names = []
        datas = []
        for name, data, tmp in dataset:
            names.append(name)
            datas.append(data)
            print(name + " <- c(" + ",".join([str(i) for i in data]) + ")", file=ROUT)

        tick_pos = [1, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100]
        tick_lab = [1, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100]

        # do not generate heatmap if only 1 sample
        if len(names) >= 3:
            print(
                "data_matrix" + " <- matrix(c(" + ",".join(names) + "), byrow=T, " + "ncol=" + str(colNum) + ")",
                file=ROUT,
            )
            print("rowLabel <- c(" + ",".join(['"' + i + '"' for i in names]) + ")", file=ROUT)
            print("\n", file=ROUT)
            print('%s("%s.%s")' % (format.lower(), file_prefix + ".heatMap", format.lower()), file=ROUT)
            print("rc <- cm.colors(ncol(data_matrix))", file=ROUT)
            heatmap_cmd = (
                "heatmap(data_matrix"
                ', scale=c("none"),keep.dendro=F, labRow = rowLabel '
                ",Colv = NA,Rowv = NA,labCol=NA,col=cm.colors(256),"
                "margins = c(6, 8),ColSideColors = rc,"
                "cexRow=1,cexCol=1,"
                "xlab=\"Gene body percentile (5'->3')\", "
                "add.expr=x_axis_expr <- axis(side=1,at=c(%s),"
                "labels=c(%s)))"
                % (
                    ",".join([str(i) for i in tick_pos]),
                    ",".join(['"' + str(i) + '"' for i in tick_lab]),
                )
            )
            print(heatmap_cmd, file=ROUT)
            print("dev.off()", file=ROUT)

        print("\n", file=ROUT)

        print('%s("%s.%s")' % (format.lower(), file_prefix + ".curves", format.lower()), file=ROUT)
        print("x=1:%d" % (colNum), file=ROUT)
        print(
            'icolor = colorRampPalette(c("#7fc97f","#beaed4","#fdc086","#ffff99","#386cb0","#f0027f"))(%d)'
            % (len(names)),
            file=ROUT,
        )

        if len(names) == 1:
            print(
                "plot(x,%s,type='l',xlab=\"Gene body percentile (5'->3')\", ylab=\"Coverage\",lwd=0.8,col=icolor[1])"
                % (names[0]),
                file=ROUT,
            )

        elif len(names) >= 2 and len(names) <= 6:
            print(
                "plot(x,%s,type='l',xlab=\"Gene body percentile (5'->3')\", ylab=\"Coverage\",lwd=0.8,col=icolor[1])"
                % (names[0]),
                file=ROUT,
            )
            for i in range(1, len(names)):
                print("lines(x,%s,type='l',col=icolor[%d])" % (names[i], i + 1), file=ROUT)
            print(
                "legend(0,1,fill=icolor[%d:%d], legend=c(%s))"
                % (1, len(names), ",".join(["'" + str(n) + "'" for n in names])),
                file=ROUT,
            )

        elif len(names) > 6:
            print("layout(matrix(c(1,1,1,2,1,1,1,2,1,1,1,2), 4, 4, byrow = TRUE))", file=ROUT)
            print(
                "plot(x,%s,type='l',xlab=\"Gene body percentile (5'->3')\", ylab=\"Coverage\",lwd=0.8,col=icolor[1])"
                % (names[0]),
                file=ROUT,
            )
            for i in range(1, len(names)):
                print("lines(x,%s,type='l',col=icolor[%d])" % (names[i], i + 1), file=ROUT)
            print("par(mar=c(1,0,2,1))", file=ROUT)
            print("plot.new()", file=ROUT)
            print(
                "legend(0,1,fill=icolor[%d:%d],legend=c(%s))"
                % (1, len(names), ",".join(["'" + str(n) + "'" for n in names])),
                file=ROUT,
            )

        print("dev.off()", file=ROUT)


def main() -> None:
    parser = create_parser(__doc__)
    parser.add_argument(
        "-i",
        "--input",
        dest="input_files",
        help=(
            'Input file(s) in BAM format. "-i" takes these input:'
            " 1) a single BAM file."
            ' 2) "," separated BAM files.'
            " 3) directory containing one or more bam files."
            " 4) plain text file containing the path of one or more"
            " bam file (Each row is a BAM file path). All BAM files"
            " should be sorted and indexed using samtools."
        ),
    )
    add_refgene_arg(parser)
    parser.add_argument(
        "-l",
        "--minimum_length",
        type=int,
        default=100,
        dest="min_mRNA_length",
        help='Minimum mRNA length (bp). mRNA smaller than "min_mRNA_length" will be skipped. default=%(default)s',
    )
    parser.add_argument(
        "-f",
        "--format",
        dest="output_format",
        default="pdf",
        help="Output file format, 'pdf', 'png' or 'jpeg'. default=%(default)s",
    )
    add_output_prefix_arg(parser, help="Prefix of output files(s). [required]")
    args = parser.parse_args()

    if not (args.output_prefix and args.input_files and args.ref_gene_model):
        parser.print_help()
        sys.exit(1)

    validate_files_exist(args.ref_gene_model)
    if args.min_mRNA_length < 100:
        print('The number specified to "-l" cannot be smaller than 100.' + "\n", file=sys.stderr)
        sys.exit(1)

    with open(args.output_prefix + ".geneBodyCoverage.txt", "w") as OUT1:
        print("Percentile\t" + "\t".join([str(i) for i in range(1, 101)]), file=OUT1)

        printlog("Read BED file (reference gene model) ...")
        gene_percentiles = genebody_percentile(refbed=args.ref_gene_model, mRNA_len_cut=args.min_mRNA_length)

        printlog("Get BAM file(s) ...")
        bamfiles = getBamFiles.get_bam_files(args.input_files)
        for f in bamfiles:
            print("\t" + f, file=sys.stderr)

        file_container = []
        for bamfile in bamfiles:
            printlog("Processing " + basename(bamfile) + " ...")
            cvg = genebody_coverage(bamfile, gene_percentiles)
            if len(cvg) == 0:
                print("\nCannot get coverage signal from " + basename(bamfile) + " ! Skip", file=sys.stderr)
                continue
            tmp = valid_name(basename(bamfile).replace(".bam", ""))  # scrutinize R identifer
            if file_container.count(tmp) == 0:
                print(tmp + "\t" + "\t".join([str(cvg[k]) for k in sorted(cvg)]), file=OUT1)
            else:
                print(
                    tmp + "." + str(file_container.count(tmp)) + "\t" + "\t".join([str(cvg[k]) for k in sorted(cvg)]),
                    file=OUT1,
                )
            file_container.append(tmp)

    dataset = []
    with open(args.output_prefix + ".geneBodyCoverage.txt", "r") as _fh:
        for line in _fh:
            line = line.strip()
            if line.startswith("Percentile"):
                continue
            f = line.split()
            name = f[0]
            dat = [float(i) for i in f[1:]]
            skewness = pearson_moment_coefficient(dat)
            dataset.append((name, [(i - min(dat)) / (max(dat) - min(dat)) for i in dat], skewness))
    dataset.sort(key=operator.itemgetter(2), reverse=True)

    print("\n\n", file=sys.stderr)
    print("\tSample\tSkewness", file=sys.stderr)
    for a, b, c in dataset:
        print("\t" + a + "\t" + str(c), file=sys.stderr)
    Rcode_write(dataset, args.output_prefix + ".geneBodyCoverage", format=args.output_format)

    printlog("Running R script ...")
    run_rscript(args.output_prefix + ".geneBodyCoverage.r")


if __name__ == "__main__":
    main()
