"""
Get bam files from input, input could be:
1) directory that containing one or more bam files
2) plain text file containing one or more bam file paths
3) a single bam file
4) ',' separated multiple bam files

in all cases, the index .bai file(s) should be exist in the same location. eg, if test.bam
exists, test.bam.bai must also exist.

"""

import os
import sys
from os.path import abspath, getsize, join


def isbamfile(infile: str) -> bool:
    """check if it is bam file, if it is empty and if the .bai file exists"""
    if os.path.isfile(infile) and infile[-4:].lower() == ".bam":
        if getsize(infile) != 0:
            if os.path.isfile(infile + ".bai"):
                return True
            else:
                print("Warning: %s.bai does not exist! Skip it." % (infile), file=sys.stderr)
                return False
        else:
            print("The size of %s is 0! Skip it." % (infile), file=sys.stderr)
            return False
    else:
        return False


def get_bam_files(input: str, printit: bool = False) -> list[str]:
    bam_files = []

    # dir
    if os.path.isdir(input):
        for root, directories, files in os.walk(input, followlinks=True):
            full_names = [join(abspath(root), name) for name in files]
            for fn in full_names:
                if isbamfile(fn):
                    bam_files.append(fn)
    # single bam file
    elif isbamfile(input):
        bam_files.append(input)
    # plain text file
    elif os.path.isfile(input):
        try:
            with open(input) as _fh:
                for line in _fh:
                    line = line.strip()
                    if line.startswith("#"):
                        continue
                    if isbamfile(line):
                        bam_files.append(line)
        except OSError:
            pass
    else:
        tmp = input.split(",")
        for i in tmp:
            if isbamfile(i):
                bam_files.append(i)

    if printit:
        for i in bam_files:
            print(i)
    return bam_files
