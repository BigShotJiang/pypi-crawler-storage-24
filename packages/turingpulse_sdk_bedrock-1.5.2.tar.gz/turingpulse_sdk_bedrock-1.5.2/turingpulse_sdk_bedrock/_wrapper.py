"""AWS Bedrock monkey-patch instrumentation for TuringPulse."""

from __future__ import annotations

import json
import logging
import os
from contextvars import ContextVar
from typing import Any, Optional

from turingpulse_sdk import instrument, GovernanceDirective
from turingpulse_sdk.config import MAX_FIELD_SIZE
from turingpulse_sdk.context import current_context
from turingpulse_sdk.exceptions import ConfigurationError

logger = logging.getLogger("turingpulse.sdk.bedrock")

_INSTRUMENTING: ContextVar[bool] = ContextVar("_tp_bedrock_instrumenting", default=False)

_ORIGINAL_CONVERSE: Any = None


def patch_bedrock(
    *,
    name: str | None = None,
    governance: Optional[GovernanceDirective] = None,
) -> None:
    """Monkey-patch ``botocore`` to intercept ``bedrock-runtime.converse`` calls."""
    global _ORIGINAL_CONVERSE

    effective_name = name or os.getenv("TP_WORKFLOW_NAME", "")
    if not effective_name:
        raise ConfigurationError(
            "patch_bedrock() requires name= or TP_WORKFLOW_NAME to be set."
        )

    try:
        import botocore.client
    except ImportError as exc:
        raise ImportError("boto3 package is required: pip install boto3") from exc

    if _ORIGINAL_CONVERSE is not None:
        logger.warning("Bedrock is already patched — skipping")
        return

    _ORIGINAL_CONVERSE = botocore.client.ClientCreator.create_client

    original_create = _ORIGINAL_CONVERSE

    def _patched_create_client(self_creator, *args: Any, **kwargs: Any) -> Any:
        client = original_create(self_creator, *args, **kwargs)
        service_name = args[0] if args else kwargs.get("service_name", "")
        if service_name == "bedrock-runtime":
            _wrap_converse(client, effective_name, governance)
        return client

    botocore.client.ClientCreator.create_client = _patched_create_client
    logger.info("Bedrock patched for TuringPulse instrumentation")


def unpatch_bedrock() -> None:
    """Restore original botocore client creator."""
    global _ORIGINAL_CONVERSE
    if _ORIGINAL_CONVERSE is None:
        return
    try:
        import botocore.client
        botocore.client.ClientCreator.create_client = _ORIGINAL_CONVERSE
    except ImportError:
        pass
    _ORIGINAL_CONVERSE = None
    logger.info("Bedrock unpatched — original methods restored")


def _set_prompt_pre_call(kwargs: dict) -> None:
    """Extract and set prompt on the context before the LLM call."""
    ctx = current_context()
    if not ctx:
        return
    messages = kwargs.get("messages", [])
    if messages:
        last_user = next(
            (m for m in reversed(messages) if m.get("role") == "user"),
            None,
        )
        if last_user:
            content = last_user.get("content", [])
            if isinstance(content, list):
                texts = [c.get("text", "") for c in content if "text" in c]
                ctx.set_prompt("\n".join(texts)[:MAX_FIELD_SIZE])
            elif isinstance(content, str):
                ctx.set_prompt(content[:MAX_FIELD_SIZE])


def _wrap_converse(client: Any, name: str, governance: Optional[GovernanceDirective]) -> None:
    """Wrap the converse method of a bedrock-runtime client."""
    original_converse = client.converse

    @instrument(name=name, governance=governance)
    def _patched_converse(**kwargs: Any) -> Any:
        if _INSTRUMENTING.get(False):
            return original_converse(**kwargs)
        token = _INSTRUMENTING.set(True)
        try:
            _set_prompt_pre_call(kwargs)
            response = original_converse(**kwargs)
            _record_bedrock_span(response, kwargs)
            return response
        finally:
            _INSTRUMENTING.reset(token)

    client.converse = _patched_converse

    original_converse_stream = getattr(client, "converse_stream", None)
    if original_converse_stream is not None and callable(original_converse_stream):

        @instrument(name=name, governance=governance)
        def _patched_converse_stream(**kwargs: Any) -> Any:
            if _INSTRUMENTING.get(False):
                return original_converse_stream(**kwargs)
            token = _INSTRUMENTING.set(True)
            try:
                _set_prompt_pre_call(kwargs)
                response = original_converse_stream(**kwargs)
                return _BedrockStreamEnricher(response, kwargs)
            finally:
                _INSTRUMENTING.reset(token)

        client.converse_stream = _patched_converse_stream


def _enrich_context_from_bedrock_stream(chunks: list, kwargs: dict) -> None:
    """Extract accumulated telemetry from Bedrock converse_stream events."""
    ctx = current_context()
    if not ctx:
        return
    ctx.framework = "bedrock"
    ctx.node_type = "llm"

    text_parts: list[str] = []
    input_tokens = 0
    output_tokens = 0

    for event in chunks:
        ev = _bedrock_event_as_dict(event)
        if not ev:
            continue
        delta_block = ev.get("contentBlockDelta") or ev.get("content_block_delta")
        if isinstance(delta_block, dict):
            delta = delta_block.get("delta") or {}
            if isinstance(delta, dict):
                t = delta.get("text")
                if t:
                    text_parts.append(str(t))
        meta_block = ev.get("metadata") or ev.get("Metadata")
        if isinstance(meta_block, dict):
            usage = meta_block.get("usage") or {}
            if isinstance(usage, dict):
                it = usage.get("inputTokens")
                if it is None:
                    it = usage.get("input_tokens")
                ot = usage.get("outputTokens")
                if ot is None:
                    ot = usage.get("output_tokens")
                if it is not None:
                    input_tokens = int(it)
                if ot is not None:
                    output_tokens = int(ot)

    model_id = kwargs.get("modelId", "unknown")
    ctx.set_tokens(int(input_tokens), int(output_tokens))
    ctx.set_model(str(model_id), "bedrock")
    output_text = "".join(text_parts)
    if output_text:
        ctx.set_io(output_data=output_text[:MAX_FIELD_SIZE])

    tool_config = kwargs.get("toolConfig")
    if isinstance(tool_config, dict):
        tools_list = tool_config.get("tools", [])
        if tools_list:
            tool_names = []
            for t in tools_list:
                spec = t.get("toolSpec", {}) if isinstance(t, dict) else {}
                tname = spec.get("name") if isinstance(spec, dict) else None
                if tname:
                    tool_names.append(tname)
            if tool_names:
                ctx.available_tools = tool_names


def _bedrock_event_as_dict(event: Any) -> dict | None:
    if isinstance(event, dict):
        return event
    if hasattr(event, "get") and callable(getattr(event, "get")):
        try:
            return dict(event)  # type: ignore[arg-type]
        except (TypeError, ValueError):
            pass
    return None


class _BedrockStreamEnricher:
    """Wraps Bedrock ``converse_stream`` event iteration; enriches context when exhausted."""

    __slots__ = ("_inner", "_kwargs", "_chunks", "_done", "_response_meta")

    def __init__(self, response: Any, kwargs: dict):
        self._kwargs = kwargs
        if isinstance(response, dict):
            self._response_meta = {k: v for k, v in response.items() if k != "stream"}
            raw_stream = response.get("stream")
        else:
            self._response_meta = {}
            raw_stream = response
        self._inner = iter(raw_stream) if raw_stream is not None else iter(())
        self._chunks: list = []
        self._done = False

    def __iter__(self):
        return self

    def __next__(self):
        try:
            chunk = next(self._inner)
            self._chunks.append(chunk)
            return chunk
        except StopIteration:
            self._enrich()
            raise

    def __aiter__(self):
        return self

    async def __anext__(self):
        try:
            chunk = next(self._inner)
            self._chunks.append(chunk)
            return chunk
        except StopIteration:
            self._enrich()
            raise StopAsyncIteration

    def __enter__(self):
        if hasattr(self._inner, "__enter__"):
            self._inner.__enter__()
        return self

    def __exit__(self, *exc_info):
        if hasattr(self._inner, "__exit__"):
            self._inner.__exit__(*exc_info)
        self._enrich()
        return False

    async def __aenter__(self):
        if hasattr(self._inner, "__aenter__"):
            await self._inner.__aenter__()
        elif hasattr(self._inner, "__enter__"):
            self._inner.__enter__()
        return self

    async def __aexit__(self, *exc_info):
        if hasattr(self._inner, "__aexit__"):
            await self._inner.__aexit__(*exc_info)
        elif hasattr(self._inner, "__exit__"):
            self._inner.__exit__(*exc_info)
        self._enrich()
        return False

    def close(self):
        if hasattr(self._inner, "close"):
            self._inner.close()
        self._enrich()

    @property
    def response(self):
        return getattr(self._inner, "response", None)

    def _enrich(self):
        if self._done:
            return
        self._done = True
        try:
            _enrich_context_from_bedrock_stream(self._chunks, self._kwargs)
        except Exception:
            pass

    def __getitem__(self, key):
        if key == "stream":
            return self
        if key in self._response_meta:
            return self._response_meta[key]
        raise KeyError(key)

    def get(self, key, default=None):
        try:
            return self[key]
        except KeyError:
            return default

    def __contains__(self, key):
        return key == "stream" or key in self._response_meta

    def keys(self):
        return list(self._response_meta.keys()) + ["stream"]


def _record_bedrock_span(response: Any, kwargs: dict) -> None:
    ctx = current_context()
    if not ctx:
        return
    ctx.framework = "bedrock"
    ctx.node_type = "llm"

    usage = response.get("usage", {}) if isinstance(response, dict) else {}
    ctx.set_tokens(
        usage.get("inputTokens", 0),
        usage.get("outputTokens", 0),
    )

    model_id = kwargs.get("modelId", "unknown")
    ctx.set_model(model_id, "bedrock")

    tool_config = kwargs.get("toolConfig")
    if isinstance(tool_config, dict):
        tools_list = tool_config.get("tools", [])
        if tools_list:
            tool_names = []
            for t in tools_list:
                spec = t.get("toolSpec", {}) if isinstance(t, dict) else {}
                tname = spec.get("name") if isinstance(spec, dict) else None
                if tname:
                    tool_names.append(tname)
            if tool_names:
                ctx.available_tools = tool_names

    output = response.get("output", {}) if isinstance(response, dict) else {}
    message = output.get("message", {})
    content = message.get("content", [])
    if content:
        texts = [c.get("text", "") for c in content if "text" in c]
        if texts:
            ctx.set_io(output_data="\n".join(texts)[:MAX_FIELD_SIZE])

        for c in content:
            if "toolUse" in c:
                tool = c["toolUse"]
                ctx.add_tool_call(
                    tool_name=tool.get("name", "unknown"),
                    tool_args=tool.get("input", {}),
                    tool_id=tool.get("toolUseId"),
                )
