# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ShowFlavorDetailRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'flavor_id': 'str'
    }

    attribute_map = {
        'flavor_id': 'flavor_id'
    }

    def __init__(self, flavor_id=None):
        r"""ShowFlavorDetailRequest

        The model defined in huaweicloud sdk

        :param flavor_id: 规格ID，获取方法请参见[查询版本规格](ShowFlavors.xml)。
        :type flavor_id: str
        """
        
        

        self._flavor_id = None
        self.discriminator = None

        self.flavor_id = flavor_id

    @property
    def flavor_id(self):
        r"""Gets the flavor_id of this ShowFlavorDetailRequest.

        规格ID，获取方法请参见[查询版本规格](ShowFlavors.xml)。

        :return: The flavor_id of this ShowFlavorDetailRequest.
        :rtype: str
        """
        return self._flavor_id

    @flavor_id.setter
    def flavor_id(self, flavor_id):
        r"""Sets the flavor_id of this ShowFlavorDetailRequest.

        规格ID，获取方法请参见[查询版本规格](ShowFlavors.xml)。

        :param flavor_id: The flavor_id of this ShowFlavorDetailRequest.
        :type flavor_id: str
        """
        self._flavor_id = flavor_id

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ShowFlavorDetailRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
