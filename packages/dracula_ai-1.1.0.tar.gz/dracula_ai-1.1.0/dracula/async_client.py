import json
import asyncio
from enum import Enum
from pathlib import Path
from .memory import AsyncMemory
from .tools import Tool, ToolRegistry, ToolResult
from .stats import AsyncStats
from .cache import AsyncCache
from .pricing import estimate_cost
from .retry import async_retry
from .models import GeminiModel
from .personas import PERSONAS
from ._version import __version__
from .version_checker import check_latest_version
from .logger import get_logger, enable_logging, disable_logging, enable_file_logging
from .exceptions import (
    InvalidAPIKeyException,
    ChatException,
    PersonaException,
    ValidationException,
    BudgetExceededException,
)
from .validators import (
    validate_api_key,
    validate_temperature,
    validate_max_output_tokens,
    validate_max_messages,
    validate_prompt,
    validate_message,
    validate_filepath,
    validate_language,
)
from .adapters.base import AsyncBaseAdapter

logger = get_logger(f"dracula.{__name__}")


class AsyncDracula:
    """
    Async version of Dracula for use in async applications.

    AsyncDracula provides the same features as Dracula but with
    full async support, making it perfect for Discord bots, FastAPI
    web apps, Telegram bots, and any other async Python application.

    By default, AsyncDracula uses Google Gemini. Pass a custom ``adapter``
    to use any other provider (OpenAI, Anthropic, or your own implementation).

    Args:
        api_key (str): Your Google Gemini API key. Required when no adapter
            is provided. Ignored when adapter is provided.
        model (GeminiModel | str): The Gemini model to use. Only applies
            when no adapter is provided. Defaults to GeminiModel.FLASH.
        adapter (AsyncBaseAdapter): Optional async provider adapter.
        max_messages (int): Maximum number of messages to keep in memory.
        prompt (str): System prompt that defines the AI's personality.
        temperature (float): Controls response creativity between 0.0 and 2.0.
        max_output_tokens (int): Maximum length of responses in tokens.
        language (str): Language for responses. Defaults to 'English'.
        session_id (str): Optional identifier for this conversation session.
        cache_ttl (int): Seconds to cache identical responses. 0 disables caching.
        token_budget (int): Maximum cumulative tokens before BudgetExceededException.
        auto_compress (bool): Automatically summarize old history instead of trimming.
        compress_ratio (float): Fraction of max_messages at which compression triggers.
        compress_keep_turns (int): Recent messages preserved verbatim after compression.

    Example:
        >>> import asyncio
        >>> from dracula import AsyncDracula
        >>> async def main():
        ...     async with AsyncDracula(api_key="your-api-key") as ai:
        ...         response = await ai.chat("Hello!")
        ...         print(response)
        >>> asyncio.run(main())

        >>> # OpenAI via adapter
        >>> from dracula.adapters import AsyncOpenAIAdapter
        >>> ai = AsyncDracula(adapter=AsyncOpenAIAdapter(api_key="sk-...", model="gpt-4o"))
    """

    def __init__(
        self,
        api_key: str = None,
        model: GeminiModel | str = GeminiModel.FLASH,
        max_messages: int = 10,
        prompt: str = "You are a helpful assistant.",
        temperature: float = 1.0,
        max_output_tokens: int = 8192,
        language: str = "English",
        logging: bool = False,
        log_level: str = "DEBUG",
        log_file: str = None,
        log_max_bytes: int = 5 * 1024 * 1024,
        log_backup_count: int = 5,
        tools: list = None,
        max_retries: int = 3,
        retry_delay: float = 1.0,
        db_path: str | Path = None,
        stats_db_path: str | Path = None,
        session_id: str = None,
        cache_ttl: int = 0,
        cache_db_path: str | Path = None,
        token_budget: int = None,
        auto_compress: bool = False,
        compress_ratio: float = 0.8,
        compress_keep_turns: int = 4,
        adapter: AsyncBaseAdapter = None,
    ):
        validate_temperature(temperature)
        validate_max_output_tokens(max_output_tokens)
        validate_max_messages(max_messages)
        validate_prompt(prompt)
        validate_language(language)

        if adapter is None:
            if api_key is None:
                raise ValidationException(
                    "Either api_key or adapter must be provided."
                )
            validate_api_key(api_key)
            from .adapters.gemini import AsyncGeminiAdapter

            adapter = AsyncGeminiAdapter(api_key, model)

        self._adapter = adapter
        self._api_key = api_key
        self.model_name = adapter.model_name
        self.tool_registry = ToolRegistry(tools or [])
        self._token_budget = token_budget
        self._auto_compress = auto_compress
        self._compress_ratio = compress_ratio
        self._compress_keep_turns = compress_keep_turns
        self._before_hooks: list = []
        self._after_hooks: list = []

        if logging:
            enable_logging(log_level)
        else:
            disable_logging()

        if log_file:
            enable_file_logging(
                log_file, max_bytes=log_max_bytes, backup_count=log_backup_count
            )

        self.prompt = prompt
        self.language = language
        self.temperature = temperature
        self.max_output_tokens = max_output_tokens
        self.memory = AsyncMemory(
            db_path=db_path, max_messages=max_messages, session_id=session_id
        )
        self.stats = AsyncStats(db_path=stats_db_path)
        self._cache = AsyncCache(db_path=cache_db_path, ttl=cache_ttl)
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        check_latest_version(__version__)

        self._initialized = False

        logger.debug(
            f"AsyncDracula initialized with model={self.model_name}, "
            f"language={language}, temperature={temperature}"
        )

    async def _ensure_initialized(self):
        """Ensures that the memory database and storage are ready.

        Since async operations cannot occur in __init__, this method handles
        the deferred setup of the SQLite schema.
        """
        if not self._initialized:
            await self.memory.initialize()
            await self.stats.initialize()
            await self._cache.initialize()
            self._initialized = True

    # ------------------------------------------------------------------
    # Hooks
    # ------------------------------------------------------------------

    def before_chat(self, func):
        """Register a hook to run before every chat() call.

        The hook receives the outgoing message string and may return a
        transformed replacement, or None to keep the original unchanged.
        Both sync and async hook functions are supported.

        Args:
            func (Callable): A function (or coroutine function) that accepts
                the message string and optionally returns a new string.

        Returns:
            Callable: The original function, unchanged (decorator pattern).

        Example:
            >>> @ai.before_chat
            ... async def uppercase(msg):
            ...     return msg.upper()
        """
        self._before_hooks.append(func)
        return func

    def after_chat(self, func):
        """Register a hook to run after every chat() call.

        The hook receives (message, response) and may return a transformed
        reply string, or None to keep the original unchanged.
        Both sync and async hook functions are supported.

        Args:
            func (Callable): A function (or coroutine function) that accepts
                the sent message and the model's reply, and optionally returns
                a new reply string.

        Returns:
            Callable: The original function, unchanged (decorator pattern).

        Example:
            >>> @ai.after_chat
            ... async def log(msg, reply):
            ...     print(f"[{len(reply)} chars]")
        """
        self._after_hooks.append(func)
        return func

    async def _run_before_hooks(self, message: str) -> str:
        for hook in self._before_hooks:
            if asyncio.iscoroutinefunction(hook):
                result = await hook(message)
            else:
                result = hook(message)
            if result is not None:
                message = result
        return message

    async def _run_after_hooks(self, message: str, reply: str) -> str:
        for hook in self._after_hooks:
            if asyncio.iscoroutinefunction(hook):
                result = await hook(message, reply)
            else:
                result = hook(message, reply)
            if result is not None:
                reply = result
        return reply

    # ------------------------------------------------------------------
    # Context compression
    # ------------------------------------------------------------------

    async def _maybe_compress(self):
        history = await self.memory.get_history()
        threshold = int(self.memory.max_messages * self._compress_ratio)
        if len(history) >= threshold:
            await self._compress_history(history)

    async def _compress_history(self, history: list):
        keep = self._compress_keep_turns
        to_summarize = history[:-keep] if keep > 0 else history
        if len(to_summarize) < 2:
            return
        conv_text = "\n".join(
            f"{m['role'].upper()}: {m['content']}" for m in to_summarize
        )
        prompt = (
            "Summarize the following conversation in 2-3 sentences, "
            "preserving all key facts and decisions:\n\n" + conv_text
        )
        try:
            result = await self._adapter.send_message(
                history=[],
                message=prompt,
                system="",
                temperature=self.temperature,
                max_tokens=self.max_output_tokens,
            )
            summary = result.text if hasattr(result, "text") else str(result)
            summary = summary or "No summary available."
            await self.memory.compress_to_summary(summary, keep_last_n=keep)
            logger.info(
                f"Async context compressed: {len(to_summarize)} messages -> 1 summary."
            )
        except Exception as e:
            logger.warning(f"Async context compression failed, skipping: {e}")

    # ------------------------------------------------------------------
    # chat()
    # ------------------------------------------------------------------

    async def chat(
        self,
        message: str,
        filepath: str | Path = None,
        auto_call: bool = True,
        schema=None,
    ) -> str | dict | ToolResult:
        """Sends a message and returns the model's response asynchronously.

        Args:
            message (str): The user input text.
            filepath (str | Path): Optional file to attach (provider-dependent).
            auto_call (bool): Handle tool calls automatically.
            schema: Optional Pydantic BaseModel subclass or JSON-schema dict
                for structured output.

        Returns:
            str | dict | BaseModel: The response in the requested format.
        """
        await self._ensure_initialized()
        validate_message(message)

        # Budget check
        if self._token_budget is not None:
            s = await self.stats.get_stats()
            used = s.get("total_input_tokens", 0) + s.get("total_output_tokens", 0)
            if used >= self._token_budget:
                raise BudgetExceededException(
                    f"Token budget of {self._token_budget:,} exceeded "
                    f"(used: {used:,} tokens)."
                )

        message = await self._run_before_hooks(message)

        if schema is not None:
            return await self._chat_with_schema(message, schema)

        cached = await self._cache.get(self.memory.session_id, message)
        if cached is not None:
            logger.debug("Cache hit — returning cached response.")
            return await self._run_after_hooks(message, cached)

        if self._auto_compress:
            await self._maybe_compress()

        async def _do_chat():
            await self.stats.record_message(message)
            logger.debug(f"Sending message: {message[:50]}...")

            history = await self.memory.get_history()
            result = await self._adapter.send_message(
                history=history,
                message=message,
                system=self._build_system_instruction(),
                temperature=self.temperature,
                max_tokens=self.max_output_tokens,
                tool_registry=self.tool_registry
                if self.tool_registry.has_tools()
                else None,
                auto_call=auto_call,
                filepath=filepath,
            )

            # Tool call requested (auto_call=False)
            if isinstance(result, ToolResult):
                return result

            # Normal text response
            reply = result.text
            if not reply:
                raise ChatException("Received an empty response.")

            if result.input_tokens or result.output_tokens:
                await self.stats.record_tokens(result.input_tokens, result.output_tokens)

            history_msg = (
                f"{message} [Attached: {Path(filepath).name}]"
                if filepath
                else message
            )
            await self.memory.add_message("user", history_msg)
            await self.memory.add_message("model", reply)
            await self.stats.record_response(reply)

            await self._cache.set(self.memory.session_id, message, reply)

            reply = await self._run_after_hooks(message, reply)
            logger.debug(f"Received response: {reply[:50]}...")
            return reply

        return await async_retry(
            _do_chat, max_retries=self.max_retries, retry_delay=self.retry_delay
        )

    async def _chat_with_schema(self, message: str, schema) -> str | dict:
        """Internal: structured output via the active adapter."""
        try:
            pydantic_model = None
            if isinstance(schema, type) and hasattr(schema, "model_json_schema"):
                pydantic_model = schema
                json_schema = schema.model_json_schema()
            elif isinstance(schema, dict):
                json_schema = schema
            else:
                raise ValidationException(
                    "schema must be a Pydantic BaseModel subclass or a JSON-schema dict."
                )

            history = await self.memory.get_history()
            reply = await self._adapter.generate_structured(
                history=history,
                message=message,
                system=self._build_system_instruction(),
                temperature=self.temperature,
                max_tokens=self.max_output_tokens,
                schema=json_schema,
            )

            await self.memory.add_message("user", message)
            await self.memory.add_message("model", reply)
            await self.stats.record_message(message)
            await self.stats.record_response(reply)

            if pydantic_model is not None:
                return pydantic_model.model_validate_json(reply)
            return json.loads(reply)

        except (ValidationException, ChatException):
            raise
        except Exception as e:
            raise ChatException(f"Structured output request failed: {str(e)}")

    async def stream(self, message: str):
        """Asynchronously streams the response chunk by chunk with memory integration.

        Args:
            message (str): The user input text to send.

        Yields:
            str: Chunks of text as they are generated by the model.

        Raises:
            ChatException: If the stream is interrupted or retries are exhausted.
        """
        await self._ensure_initialized()
        validate_message(message)

        # Budget check
        if self._token_budget is not None:
            s = await self.stats.get_stats()
            used = s.get("total_input_tokens", 0) + s.get("total_output_tokens", 0)
            if used >= self._token_budget:
                raise BudgetExceededException(
                    f"Token budget of {self._token_budget:,} exceeded "
                    f"(used: {used:,} tokens)."
                )

        message = await self._run_before_hooks(message)

        if self._auto_compress:
            await self._maybe_compress()

        await self.stats.record_message(message)
        last_exception = None

        for attempt in range(self.max_retries + 1):
            full_reply = ""
            try:
                history = await self.memory.get_history()
                async for chunk in self._adapter.stream(
                    history=history,
                    message=message,
                    system=self._build_system_instruction(),
                    temperature=self.temperature,
                    max_tokens=self.max_output_tokens,
                ):
                    full_reply += chunk
                    yield chunk

                await self.memory.add_message("user", message)
                await self.memory.add_message("model", full_reply)

                await self.stats.record_response(full_reply)
                await self._run_after_hooks(message, full_reply)
                return

            except Exception as e:
                last_exception = e

                if full_reply:
                    logger.error(
                        f"Async stream interrupted after partial response: {str(e)}"
                    )
                    raise ChatException(
                        f"Stream interrupted during generation: {str(e)}"
                    )

                if attempt == self.max_retries:
                    raise ChatException(
                        f"Stream failed after {self.max_retries} retries. Last error: {str(e)}"
                    )

                delay = self.retry_delay * (2**attempt)
                logger.warning(
                    f"Async stream attempt {attempt + 1} failed: {str(e)}. "
                    f"Retrying in {delay}s..."
                )
                await asyncio.sleep(delay)

        raise last_exception

    async def set_prompt(self, prompt: str) -> "AsyncDracula":
        """
        Change the system prompt and clear conversation memory.

        Args:
            prompt (str): The new system prompt.

        Returns:
            AsyncDracula: The current instance for method chaining.
        """
        validate_prompt(prompt)
        self.prompt = prompt
        await self.memory.clear()
        logger.info("Prompt updated.")
        return self

    def set_temperature(self, temperature: float) -> "AsyncDracula":
        """
        Change the temperature setting.

        Args:
            temperature (float): A value between 0.0 and 2.0.

        Returns:
            AsyncDracula: The current instance for method chaining.
        """
        validate_temperature(temperature)
        self.temperature = temperature
        return self

    def set_max_output_tokens(self, max_output_tokens: int) -> "AsyncDracula":
        """
        Change the maximum response length in tokens.

        Args:
            max_output_tokens (int): Maximum number of tokens in the response.

        Returns:
            AsyncDracula: The current instance for method chaining.
        """
        validate_max_output_tokens(max_output_tokens)
        self.max_output_tokens = max_output_tokens
        return self

    async def set_language(self, language: str) -> "AsyncDracula":
        """
        Change the response language and clear conversation memory.

        Args:
            language (str): The language for responses.

        Returns:
            AsyncDracula: The current instance for method chaining.
        """
        validate_language(language)
        self.language = language
        await self.memory.clear()
        logger.info(f"Language changed to '{language}'")
        return self

    async def set_model(self, model) -> "AsyncDracula":
        """
        Change the active model.

        Args:
            model (GeminiModel | OpenAIModel | AnthropicModel | str): The model to use.

        Returns:
            AsyncDracula: The current instance for method chaining.
        """
        from .validators import validate_model

        validate_model(model)
        model_str = model.value if isinstance(model, Enum) else model
        self.model_name = model_str
        self._adapter.model_name = model_str
        logger.info(f"Model changed to '{model_str}'")
        return self

    async def set_persona(self, persona: str) -> "AsyncDracula":
        """
        Switch to a built-in persona instantly.

        Args:
            persona (str): The name of the persona to use.

        Returns:
            AsyncDracula: The current instance for method chaining.

        Raises:
            PersonaException: If the persona name is not recognized.
        """
        if persona not in PERSONAS:
            available = ", ".join(PERSONAS.keys())
            raise PersonaException(
                f"Unknown persona '{persona}'. Available personas: {available}"
            )

        selected = PERSONAS[persona]
        await self.set_prompt(selected["prompt"])
        self.set_temperature(selected["temperature"])
        await self.set_language(selected["language"])
        logger.info(f"Persona changed to '{persona}'")
        return self

    def set_log_level(self, level: str) -> "AsyncDracula":
        """
        Change the logging level.

        Args:
            level (str): Logging level — DEBUG, INFO, WARNING, ERROR, or CRITICAL.

        Returns:
            AsyncDracula: The current instance for method chaining.
        """
        enable_logging(level)
        return self

    def set_retry(self, max_retries: int, retry_delay: float = 1.0) -> "AsyncDracula":
        """Change the retry settings.

        Args:
            max_retries (int): Maximum number of retry attempts.
            retry_delay (float): Initial delay in seconds between retries.

        Returns:
            AsyncDracula: The current instance for method chaining.

        Example:
            >>> ai.set_retry(max_retries=5, retry_delay=2.0)
        """
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        logger.info(
            f"Retry settings updated: max_retries={max_retries}, retry_delay={retry_delay}"
        )
        return self

    def list_personas(self) -> list:
        """
        Return a list of all available built-in persona names.

        Returns:
            list: A list of persona name strings.
        """
        return list(PERSONAS.keys())

    async def list_available_models(self) -> list:
        """Asynchronously fetch all currently available models from the provider.

        Returns:
            list: A list of available model name strings.

        Raises:
            ChatException: If the API request fails.
        """
        return await self._adapter.list_models()

    async def get_stats(self) -> dict:
        """Return the current usage statistics.

        Returns:
            dict: A dictionary with token and message counts.

        Example:
            >>> print(await ai.get_stats())
        """
        return await self.stats.get_stats()

    async def reset_stats(self):
        """Reset all usage statistics back to zero.

        Example:
            >>> await ai.reset_stats()
        """
        await self.stats.reset()

    async def save_stats(self, filepath: str):
        """Asynchronously export the current usage statistics to a JSON file.

        Args:
            filepath (str): Destination path for the JSON file.

        Example:
            >>> await ai.save_stats("stats.json")
        """
        validate_filepath(filepath)
        await self.stats.save(filepath)

    async def load_stats(self, filepath: str):
        """Asynchronously restore usage statistics from a previously saved JSON file.

        Args:
            filepath (str): Path to the JSON file to load.

        Example:
            >>> await ai.load_stats("stats.json")
        """
        validate_filepath(filepath)
        await self.stats.load(filepath)

    async def estimated_cost(self) -> float:
        """Return the estimated API cost in USD based on tokens used so far.

        Returns:
            float: Estimated cost in USD, rounded to 6 decimal places.

        Example:
            >>> print(f"${await ai.estimated_cost():.4f}")
        """
        s = await self.stats.get_stats()
        return estimate_cost(
            self.model_name,
            s.get("total_input_tokens", 0),
            s.get("total_output_tokens", 0),
        )

    async def fork(self, session_id: str = None) -> "AsyncDracula":
        """Create a new AsyncDracula instance with a copy of the current conversation.

        Args:
            session_id (str): Optional session ID for the fork.

        Returns:
            AsyncDracula: A new instance pre-loaded with the current history.
        """
        branch = AsyncDracula(
            adapter=self._adapter,
            max_messages=self.memory.max_messages,
            prompt=self.prompt,
            temperature=self.temperature,
            max_output_tokens=self.max_output_tokens,
            language=self.language,
            db_path=self.memory.db_path,
            stats_db_path=self.stats.db_path,
            session_id=session_id,
            cache_ttl=self._cache.ttl,
            token_budget=self._token_budget,
            auto_compress=self._auto_compress,
            compress_ratio=self._compress_ratio,
            compress_keep_turns=self._compress_keep_turns,
        )
        await branch._ensure_initialized()
        for msg in await self.memory.get_history():
            await branch.memory.add_message(msg["role"], msg["content"])
        logger.info(f"Forked async session into '{branch.memory.session_id}'.")
        return branch

    async def save_history(self, filepath: str):
        """Save the conversation history to a JSON file.

        Args:
            filepath (str): Destination path for the JSON file.

        Example:
            >>> await ai.save_history("conversation.json")
        """
        validate_filepath(filepath)
        await self.memory.save(filepath)

    async def load_history(self, filepath: str):
        """Load conversation history from a JSON file.

        Args:
            filepath (str): Path to the JSON file to load.

        Example:
            >>> await ai.load_history("conversation.json")
        """
        validate_filepath(filepath)
        await self.memory.load(filepath)

    async def export_to_markdown(self, filepath: str):
        """
        Asynchronously export the conversation history to a formatted Markdown file.

        Args:
            filepath (str): The destination path for the .md file.

        Example:
            >>> await ai.export_to_markdown("my_chat.md")
        """
        validate_filepath(filepath)
        await self._ensure_initialized()
        history = await self.memory.get_history()

        try:
            from datetime import datetime

            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

            md_content = "# Dracula Conversation History\n\n"
            md_content += f"> Exported on: {now}\n\n---\n\n"

            if not history:
                md_content += "*No conversation history yet.*\n"
            else:
                for msg in history:
                    role_icon = (
                        "👤 **You**" if msg["role"] == "user" else "🤖 **AI**"
                    )
                    md_content += f"### {role_icon}\n\n"
                    md_content += f"{msg['content']}\n\n---\n\n"

            Path(filepath).write_text(md_content, encoding="utf-8")
            logger.info(f"Async history successfully exported to markdown: {filepath}")

        except Exception as e:
            raise ChatException(f"Failed to export async markdown: {str(e)}")

    async def clear_memory(self):
        """Permanently clears conversational history from the SQLite database."""
        await self._ensure_initialized()
        await self.memory.clear()
        logger.info("Asynchronous memory cleared.")

    async def get_history(self) -> list:
        """Return the full conversation history for this session.

        Returns:
            list: A list of message dicts with 'role' and 'content' keys.

        Example:
            >>> print(await ai.get_history())
        """
        return await self.memory.get_history()

    async def print_history(self):
        """Print the conversation history in a clean, human-readable format."""
        history = await self.memory.get_history()

        if not history:
            print("No conversation history yet.")
            return

        print("\n" + "═" * 50)
        print("         🧛 DRACULA CONVERSATION HISTORY")
        print("═" * 50)

        for i, msg in enumerate(history, 1):
            if msg["role"] == "user":
                print(f"\n[{i}] 👤 You:")
            else:
                print(f"\n[{i}] 🤖 AI:")
            print(f"    {msg['content']}")

        print("\n" + "═" * 50 + "\n")

    async def close(self):
        """Close the async HTTP session and release all resources.

        Safe to call even if the session was never opened or is already closed.
        Called automatically by __aexit__ when using the async context manager.
        """
        try:
            client = getattr(self._adapter, "_client", None)
            if client and hasattr(client, "_api_client"):
                api_client = client._api_client
                if hasattr(api_client, "_session"):
                    session = api_client._session
                    if session and not session.closed:
                        await session.close()
        except Exception:
            pass

    async def __aenter__(self) -> "AsyncDracula":
        """Enter the async context manager.

        Returns:
            AsyncDracula: The current instance.

        Example:
            >>> async with AsyncDracula(api_key="your-api-key") as ai:
            ...     response = await ai.chat("Hello!")
        """
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> bool:
        """Exit the async context manager and clean up.

        Automatically clears conversation memory when the async with block ends.
        Stats are NOT reset — use reset_stats() explicitly if needed.

        Returns:
            bool: False so exceptions are not suppressed.
        """
        await self.clear_memory()
        await self.close()
        return False

    def _build_system_instruction(self) -> str:
        """Build the system instruction with language."""
        if self.language.lower() != "auto":
            return f"{self.prompt} Always respond in {self.language}."
        return self.prompt

    async def add_tool(self, tool: Tool) -> "AsyncDracula":
        """
        Register a new tool after initialization.

        Args:
            tool (Tool): The tool to register.

        Returns:
            AsyncDracula: The current instance for method chaining.

        Example:
            >>> await ai.add_tool(get_weather)
        """
        self.tool_registry.register(tool)
        logger.info(f"Tool '{tool.name}' registered.")
        return self

    def list_tools(self) -> list:
        """
        Return a list of all registered tool names.

        Returns:
            list: List of tool name strings.

        Example:
            >>> print(ai.list_tools())
        """
        return self.tool_registry.list_tools()

    async def count_tokens(self, text: str) -> int:
        """
        Asynchronously count the number of tokens in a given text.

        Args:
            text (str): The text to calculate tokens for.

        Returns:
            int: The total number of tokens.

        Example:
            >>> tokens = await ai.count_tokens("Hello!")
        """
        validate_message(text)
        return await self._adapter.count_tokens(text)

    async def count_history_tokens(self) -> int:
        """
        Asynchronously count the total number of tokens used by the current
        conversation history, including the system prompt.

        Returns:
            int: The total number of tokens in the active session.

        Example:
            >>> total_usage = await ai.count_history_tokens()
        """
        return await self._adapter.count_history_tokens(
            history=await self.memory.get_history(),
            system=self._build_system_instruction(),
        )
