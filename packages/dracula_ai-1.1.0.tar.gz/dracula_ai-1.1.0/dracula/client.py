import json
from enum import Enum
from pathlib import Path
from .memory import Memory
from .tools import Tool, ToolRegistry, ToolResult
from .stats import Stats
from .cache import Cache
from .pricing import estimate_cost
from .retry import retry
from .models import GeminiModel
from ._version import __version__
from .version_checker import check_latest_version
from .logger import (
    get_logger,
    enable_logging,
    disable_logging,
    enable_file_logging,
    disable_file_logging,
)
from .personas import PERSONAS
from .exceptions import (
    InvalidAPIKeyException,
    ChatException,
    PersonaException,
    ValidationException,
    BudgetExceededException,
)
from .validators import (
    validate_api_key,
    validate_filepath,
    validate_max_output_tokens,
    validate_message,
    validate_prompt,
    validate_temperature,
    validate_max_messages,
    validate_language,
)
from .adapters.base import BaseAdapter

logger = get_logger(f"dracula.{__name__}")


class Dracula:
    """
    The main class for interacting with AI models using the Dracula library.

    Dracula provides a simple and elegant interface for chatting with any
    supported AI provider, managing conversation memory, controlling AI
    behavior, and tracking usage stats.

    By default, Dracula uses Google Gemini. Pass a custom ``adapter`` to use
    any other provider (OpenAI, Anthropic, or your own implementation).

    Args:
        api_key (str): Your Google Gemini API key. Required when no adapter
            is provided. Ignored when adapter is provided.
        model (str): The Gemini model to use. Only applies when no adapter
            is provided. Defaults to 'gemini-2.5-flash'.
        adapter (BaseAdapter): Optional provider adapter. When supplied,
            ``api_key`` and ``model`` are ignored and all API calls are
            routed through this adapter.
        max_messages (int): Maximum number of messages to keep in memory.
        prompt (str): System prompt that defines the AI's personality.
        temperature (float): Controls response creativity between 0.0 and 2.0.
        max_output_tokens (int): Maximum length of responses in tokens.
        language (str): Language for responses. Defaults to 'English'.
        session_id (str): Optional identifier for this conversation session.
        cache_ttl (int): Seconds to cache identical responses. 0 disables caching.
        token_budget (int): Maximum cumulative tokens before BudgetExceededException.
        auto_compress (bool): Automatically summarize old history instead of trimming.
        compress_ratio (float): Fraction of max_messages at which compression triggers.
        compress_keep_turns (int): Recent messages preserved verbatim after compression.

    Example:
        >>> # Default: Google Gemini
        >>> from dracula import Dracula
        >>> ai = Dracula(api_key="your-gemini-key")
        >>> print(ai.chat("Hello!"))

        >>> # OpenAI via adapter
        >>> from dracula.adapters import OpenAIAdapter
        >>> ai = Dracula(adapter=OpenAIAdapter(api_key="sk-...", model="gpt-4o"))
        >>> print(ai.chat("Hello!"))

        >>> # Anthropic via adapter
        >>> from dracula.adapters import AnthropicAdapter
        >>> ai = Dracula(adapter=AnthropicAdapter(api_key="sk-ant-..."))
        >>> print(ai.chat("Hello!"))
    """

    def __init__(
        self,
        api_key: str = None,
        model: GeminiModel | str = GeminiModel.FLASH,
        max_messages: int = 10,
        prompt: str = "You are a helpful assistant.",
        temperature: float = 1.0,
        max_output_tokens: int = 8192,
        language: str = "English",
        logging: bool = False,
        log_file: str = None,
        log_level: str = "Debug",
        log_max_bytes: int = 5 * 1024 * 1024,
        log_backup_count: int = 5,
        tools: list = None,
        max_retries: int = 3,
        retry_delay: float = 1.0,
        db_path: str | Path = None,
        stats_db_path: str | Path = None,
        session_id: str = None,
        cache_ttl: int = 0,
        cache_db_path: str | Path = None,
        token_budget: int = None,
        auto_compress: bool = False,
        compress_ratio: float = 0.8,
        compress_keep_turns: int = 4,
        adapter: BaseAdapter = None,
    ):
        validate_temperature(temperature)
        validate_max_output_tokens(max_output_tokens)
        validate_max_messages(max_messages)
        validate_prompt(prompt)
        validate_language(language)

        if adapter is None:
            if api_key is None:
                raise ValidationException(
                    "Either api_key or adapter must be provided."
                )
            validate_api_key(api_key)
            from .adapters.gemini import GeminiAdapter

            adapter = GeminiAdapter(api_key, model)

        self._adapter = adapter
        self._api_key = api_key
        self.model_name = adapter.model_name
        self.tool_registry = ToolRegistry(tools or [])
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self._token_budget = token_budget
        self._auto_compress = auto_compress
        self._compress_ratio = compress_ratio
        self._compress_keep_turns = compress_keep_turns
        self._before_hooks: list = []
        self._after_hooks: list = []

        if logging:
            enable_logging(log_level)
        else:
            disable_logging()

        if log_file:
            enable_file_logging(
                log_file, max_bytes=log_max_bytes, backup_count=log_backup_count
            )

        self.prompt = prompt
        self.language = language
        self.temperature = temperature
        self.max_output_tokens = max_output_tokens
        self.memory = Memory(
            db_path=db_path, max_messages=max_messages, session_id=session_id
        )
        self.stats = Stats(db_path=stats_db_path)
        self._cache = Cache(db_path=cache_db_path, ttl=cache_ttl)

        check_latest_version(__version__)
        logger.debug(
            f"Dracula initialized with model={self.model_name}, "
            f"language={language}, temperature={temperature}"
        )

    def __enter__(self):
        """
        Enter the context manager.

        Returns:
            Dracula: The current instance.

        Example:
            >>> with Dracula(api_key="your-api-key") as ai:
            ...     ai.chat("Hello!")
        """
        return self

    def __exit__(self, exc_type, exc, tb):
        """
        Exit the context manager and clean up.

        Automatically clears conversation memory when the with block ends.
        Stats are NOT reset — use reset_stats() explicitly if needed.

        Returns:
            bool: False so exceptions are not suppressed.
        """
        self.clear_memory()
        return False

    # ------------------------------------------------------------------
    # Hooks
    # ------------------------------------------------------------------

    def before_chat(self, func):
        """Register a hook to run before every chat() call.

        The hook receives the outgoing message string and may return a
        transformed replacement, or None to keep the original unchanged.

        Args:
            func (Callable): A function that accepts the message string and
                optionally returns a new string to use instead.

        Returns:
            Callable: The original function, unchanged (decorator pattern).

        Example:
            >>> @ai.before_chat
            ... def uppercase(msg):
            ...     return msg.upper()
        """
        self._before_hooks.append(func)
        return func

    def after_chat(self, func):
        """Register a hook to run after every chat() call.

        The hook receives (message, response) and may return a transformed
        reply string, or None to keep the original unchanged.

        Args:
            func (Callable): A function that accepts the sent message and the
                model's reply, and optionally returns a new reply string.

        Returns:
            Callable: The original function, unchanged (decorator pattern).

        Example:
            >>> @ai.after_chat
            ... def log(msg, reply):
            ...     print(f"[{len(reply)} chars]")
        """
        self._after_hooks.append(func)
        return func

    def _run_before_hooks(self, message: str) -> str:
        for hook in self._before_hooks:
            result = hook(message)
            if result is not None:
                message = result
        return message

    def _run_after_hooks(self, message: str, reply: str) -> str:
        for hook in self._after_hooks:
            result = hook(message, reply)
            if result is not None:
                reply = result
        return reply

    # ------------------------------------------------------------------
    # Context compression
    # ------------------------------------------------------------------

    def _maybe_compress(self):
        """Trigger compression if history exceeds compress_ratio * max_messages."""
        history = self.memory.get_history()
        threshold = int(self.memory.max_messages * self._compress_ratio)
        if len(history) >= threshold:
            self._compress_history(history)

    def _compress_history(self, history: list):
        keep = self._compress_keep_turns
        to_summarize = history[:-keep] if keep > 0 else history
        if len(to_summarize) < 2:
            return
        conv_text = "\n".join(
            f"{m['role'].upper()}: {m['content']}" for m in to_summarize
        )
        prompt = (
            "Summarize the following conversation in 2-3 sentences, "
            "preserving all key facts and decisions:\n\n" + conv_text
        )
        try:
            result = self._adapter.send_message(
                history=[],
                message=prompt,
                system="",
                temperature=self.temperature,
                max_tokens=self.max_output_tokens,
            )
            summary = result.text if hasattr(result, "text") else str(result)
            summary = summary or "No summary available."
            self.memory.compress_to_summary(summary, keep_last_n=keep)
            logger.info(
                f"Context compressed: {len(to_summarize)} messages -> 1 summary."
            )
        except Exception as e:
            logger.warning(f"Context compression failed, skipping: {e}")

    # ------------------------------------------------------------------
    # chat()
    # ------------------------------------------------------------------

    def chat(
        self,
        message: str,
        filepath: str | Path = None,
        auto_call: bool = True,
        schema=None,
    ) -> str | dict | ToolResult:
        """Send a message to the AI and get a response.

        Args:
            message (str): The message to send.
            filepath (str | Path): Optional file to attach (provider-dependent).
            auto_call (bool): Automatically execute tool calls. Defaults to True.
            schema: Optional response schema. Pass a Pydantic ``BaseModel``
                subclass or a JSON-schema ``dict`` to receive structured output.
                When provided, tool calls are bypassed.

        Returns:
            str: Plain text response (default).
            dict: Parsed JSON when ``schema`` is a dict.
            BaseModel instance: When ``schema`` is a Pydantic model class.
        """
        validate_message(message)

        # Budget check
        if self._token_budget is not None:
            s = self.stats.get_stats()
            used = s.get("total_input_tokens", 0) + s.get("total_output_tokens", 0)
            if used >= self._token_budget:
                raise BudgetExceededException(
                    f"Token budget of {self._token_budget:,} exceeded "
                    f"(used: {used:,} tokens)."
                )

        # Before hooks
        message = self._run_before_hooks(message)

        # Structured output path
        if schema is not None:
            return self._chat_with_schema(message, schema)

        # Cache check
        cached = self._cache.get(self.memory.session_id, message)
        if cached is not None:
            logger.debug("Cache hit — returning cached response.")
            reply = self._run_after_hooks(message, cached)
            return reply

        # Auto-compress before adding new messages
        if self._auto_compress:
            self._maybe_compress()

        def _do_chat():
            self.stats.record_message(message)
            logger.debug(f"Sending message: {message[:50]}...")

            history = self.memory.get_history()
            result = self._adapter.send_message(
                history=history,
                message=message,
                system=self._build_system_instruction(),
                temperature=self.temperature,
                max_tokens=self.max_output_tokens,
                tool_registry=self.tool_registry
                if self.tool_registry.has_tools()
                else None,
                auto_call=auto_call,
                filepath=filepath,
            )

            # Tool call requested (auto_call=False)
            if isinstance(result, ToolResult):
                return result

            # Normal text response
            reply = result.text
            if not reply:
                raise ChatException("Received an empty response.")

            if result.input_tokens or result.output_tokens:
                self.stats.record_tokens(result.input_tokens, result.output_tokens)

            history_mesg = (
                f"{message} [Attached: {Path(filepath).name}]"
                if filepath
                else message
            )
            self.memory.add_message("user", history_mesg)
            self.memory.add_message("model", reply)
            self.stats.record_response(reply)

            self._cache.set(self.memory.session_id, message, reply)

            reply = self._run_after_hooks(message, reply)
            logger.debug(f"Received response: {reply[:50]}...")
            return reply

        return retry(
            _do_chat, max_retries=self.max_retries, retry_delay=self.retry_delay
        )

    def _chat_with_schema(self, message: str, schema) -> str | dict:
        """Internal: structured output via the active adapter."""
        try:
            pydantic_model = None
            if isinstance(schema, type) and hasattr(schema, "model_json_schema"):
                pydantic_model = schema
                json_schema = schema.model_json_schema()
            elif isinstance(schema, dict):
                json_schema = schema
            else:
                raise ValidationException(
                    "schema must be a Pydantic BaseModel subclass or a JSON-schema dict."
                )

            history = self.memory.get_history()
            reply = self._adapter.generate_structured(
                history=history,
                message=message,
                system=self._build_system_instruction(),
                temperature=self.temperature,
                max_tokens=self.max_output_tokens,
                schema=json_schema,
            )

            self.memory.add_message("user", message)
            self.memory.add_message("model", reply)
            self.stats.record_message(message)
            self.stats.record_response(reply)

            if pydantic_model is not None:
                return pydantic_model.model_validate_json(reply)
            return json.loads(reply)

        except (ValidationException, ChatException):
            raise
        except Exception as e:
            raise ChatException(f"Structured output request failed: {str(e)}")

    def stream(self, message: str):
        """Stream the response token by token in real time.

        Hooks and auto-compression are applied the same way as chat().
        The full reply is saved to memory once the stream completes.

        Args:
            message (str): The message to send.

        Yields:
            str: Successive text chunks as they are generated by the model.

        Raises:
            BudgetExceededException: If the configured token budget is exceeded.
            ChatException: If the stream is interrupted or all retries are exhausted.
        """
        validate_message(message)

        # Budget check
        if self._token_budget is not None:
            s = self.stats.get_stats()
            used = s.get("total_input_tokens", 0) + s.get("total_output_tokens", 0)
            if used >= self._token_budget:
                raise BudgetExceededException(
                    f"Token budget of {self._token_budget:,} exceeded "
                    f"(used: {used:,} tokens)."
                )

        message = self._run_before_hooks(message)

        if self._auto_compress:
            self._maybe_compress()

        self.stats.record_message(message)
        last_exception = None

        for attempt in range(self.max_retries + 1):
            full_reply = ""
            try:
                history = self.memory.get_history()
                for chunk in self._adapter.stream(
                    history=history,
                    message=message,
                    system=self._build_system_instruction(),
                    temperature=self.temperature,
                    max_tokens=self.max_output_tokens,
                ):
                    full_reply += chunk
                    yield chunk

                self.memory.add_message("user", message)
                self.memory.add_message("model", full_reply)
                self.stats.record_response(full_reply)
                self._run_after_hooks(message, full_reply)
                return

            except Exception as e:
                last_exception = e

                if full_reply:
                    logger.error(f"Stream interrupted after partial response: {str(e)}")
                    raise ChatException(f"Stream interrupted: {str(e)}")

                if attempt == self.max_retries:
                    raise ChatException(
                        f"Stream failed after {self.max_retries} retries. Error: {str(e)}"
                    )

                import time

                delay = self.retry_delay * (2**attempt)
                logger.warning(
                    f"Stream attempt {attempt + 1} failed: {str(e)}. Retrying in {delay}s..."
                )
                time.sleep(delay)

        raise last_exception

    def get_stats(self) -> dict:
        """
        Return the current usage statistics.

        Returns:
            dict: A dictionary containing total_messages, total_responses,
                total_characters_sent, and total_characters_received.

        Example:
            >>> print(ai.get_stats())
        """
        return self.stats.get_stats()

    def reset_stats(self):
        """
        Reset all usage statistics back to zero.

        Example:
            >>> ai.reset_stats()
        """
        self.stats.reset()

    def save_stats(self, filepath: str):
        """Export the current usage statistics to a JSON file.

        Args:
            filepath (str): Destination path for the JSON file.

        Raises:
            ValidationException: If the filepath is empty.
            ChatException: If the file cannot be written.

        Example:
            >>> ai.save_stats("stats.json")
        """
        validate_filepath(filepath)
        self.stats.save(filepath)

    def load_stats(self, filepath: str):
        """Restore usage statistics from a previously saved JSON file.

        The current stats are replaced by the values in the file.

        Args:
            filepath (str): Path to the JSON file to load.

        Raises:
            ValidationException: If the filepath is empty.
            ChatException: If the file cannot be read or parsed.

        Example:
            >>> ai.load_stats("stats.json")
        """
        validate_filepath(filepath)
        self.stats.load(filepath)

    def estimated_cost(self) -> float:
        """Return the estimated API cost in USD based on tokens used so far.

        The calculation uses Dracula's built-in pricing table. For models not
        in the table a conservative default of $0.10/$0.40 per million tokens
        (input/output) is used.

        Returns:
            float: Estimated cost in USD (rounded to 6 decimal places).

        Example:
            >>> print(f"${ai.estimated_cost():.4f}")
        """
        s = self.stats.get_stats()
        return estimate_cost(
            self.model_name,
            s.get("total_input_tokens", 0),
            s.get("total_output_tokens", 0),
        )

    def fork(self, session_id: str = None) -> "Dracula":
        """Create a new Dracula instance with a copy of the current conversation.

        The fork shares the same database file but uses a new ``session_id``,
        so both branches can evolve independently without affecting each other.

        Args:
            session_id (str): Optional session ID for the fork. Auto-generated
                if not provided.

        Returns:
            Dracula: A new instance pre-loaded with the current history.

        Example:
            >>> branch = ai.fork()
            >>> branch.chat("What if we tried a different approach?")
        """
        branch = Dracula(
            adapter=self._adapter,
            max_messages=self.memory.max_messages,
            prompt=self.prompt,
            temperature=self.temperature,
            max_output_tokens=self.max_output_tokens,
            language=self.language,
            db_path=self.memory.db_path,
            stats_db_path=self.stats.db_path,
            session_id=session_id,
            cache_ttl=self._cache.ttl,
            token_budget=self._token_budget,
            auto_compress=self._auto_compress,
            compress_ratio=self._compress_ratio,
            compress_keep_turns=self._compress_keep_turns,
        )
        for msg in self.memory.get_history():
            branch.memory.add_message(msg["role"], msg["content"])
        logger.info(f"Forked session into '{branch.memory.session_id}'.")
        return branch

    def print_history(self):
        """
        Print the conversation history in a clean, human-readable format.

        Example:
            >>> ai.print_history()
        """
        history = self.memory.get_history()

        if not history:
            print("No conversation history yet.")
            return

        print("\n" + "=" * 150)
        print("         🧛 DRACULA CONVERSATION HISTORY")
        print("=" * 150)

        for i, msg in enumerate(history, 1):
            if msg["role"] == "user":
                print(f"\n[{i}] 👤 You:")
            else:
                print(f"\n[{i}] 🤖 AI:")

            print(f"    {msg['content']}")

        print("\n" + "═" * 150 + "\n")

    def save_history(self, filepath: str):
        """
        Save the conversation history to a JSON file.

        Args:
            filepath (str): Path to the file where history will be saved.

        Raises:
            ValidationException: If the filepath is empty.
            ChatException: If the file cannot be saved.

        Example:
            >>> ai.save_history("conversation.json")
        """
        validate_filepath(filepath)
        self.memory.save(filepath)

    def load_history(self, filepath: str):
        """
        Load conversation history from a JSON file.

        Args:
            filepath (str): Path to the file to load history from.

        Raises:
            ValidationException: If the filepath is empty.
            ChatException: If the file cannot be loaded or does not exist.

        Example:
            >>> ai.load_history("conversation.json")
        """
        validate_filepath(filepath)
        self.memory.load(filepath)

    def export_to_markdown(self, filepath: str | Path):
        """
        Export the conversation history to a beautifully formatted Markdown file.

        Args:
            filepath (str): The destination path for the .md file.

        Raises:
            ValidationException: If the filepath is invalid.
            ChatException: If the file cannot be written.

        Example:
            >>> ai.export_to_markdown("my_chat.md")
        """
        validate_filepath(filepath)
        history = self.memory.get_history()

        try:
            from datetime import datetime

            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

            md_content = "# Dracula Conversation History\n\n"
            md_content += f"> Exported on: {now}\n\n---\n\n"

            if not history:
                md_content += "*No conversation history yet.*\n"

            else:
                for msg in history:
                    role_icon = (
                        "👤 **You**" if msg["role"] == "user" else "🤖 **AI**"
                    )
                    md_content += f"### {role_icon}\n\n"
                    md_content += f"{msg['content']}\n\n---\n\n"

            Path(filepath).write_text(md_content, encoding="utf-8")
            logger.info(f"History successfully exported to markdown: {filepath}")

        except Exception as e:
            raise ChatException(f"Failed to export markdown: {str(e)}")

    def clear_memory(self):
        """
        Clear the conversation history.

        After calling this, the AI will have no memory of previous messages.

        Example:
            >>> ai.clear_memory()
        """
        self.memory.clear()
        logger.info("Memory cleared.")

    def set_model(self, model) -> "Dracula":
        """
        Change the active model.

        Args:
            model (GeminiModel | OpenAIModel | AnthropicModel | str): The model to use.

        Returns:
            Dracula: The current instance for method chaining.

        Example:
            >>> from dracula import GeminiModel
            >>> ai.set_model(GeminiModel.PRO)
        """
        from .validators import validate_model

        validate_model(model)
        model_str = model.value if isinstance(model, Enum) else model
        self.model_name = model_str
        self._adapter.model_name = model_str
        logger.info(f"Model changed to '{model_str}'")
        return self

    def set_prompt(self, prompt: str) -> "Dracula":
        """
        Change the system prompt and clear conversation memory.

        Args:
            prompt (str): The new system prompt.

        Returns:
            Dracula: The current instance for method chaining.

        Example:
            >>> ai.set_prompt("You are a pirate.")
        """
        validate_prompt(prompt)
        self.prompt = prompt
        self.memory.clear()
        logger.info("Prompt updated.")
        return self

    def set_temperature(self, temperature: float) -> "Dracula":
        """
        Change the temperature setting.

        Temperature controls how creative and random responses are.
        Lower values (close to 0.0) produce focused, predictable responses.
        Higher values (close to 2.0) produce creative, varied responses.

        Args:
            temperature (float): A value between 0.0 and 2.0.

        Returns:
            Dracula: The current instance for method chaining.

        Example:
            >>> ai.set_temperature(0.5)
        """
        validate_temperature(temperature)
        self.temperature = temperature
        return self

    def set_max_output_tokens(self, max_output_tokens: int) -> "Dracula":
        """
        Change the maximum response length in tokens.

        Args:
            max_output_tokens (int): Maximum number of tokens in the response.

        Returns:
            Dracula: The current instance for method chaining.

        Example:
            >>> ai.set_max_output_tokens(512)
        """
        validate_max_output_tokens(max_output_tokens)
        self.max_output_tokens = max_output_tokens
        logger.info(f"Max output tokens changed to '{max_output_tokens}'")
        return self

    def set_language(self, language: str) -> "Dracula":
        """
        Change the response language and clear conversation memory.

        Forces the AI to always respond in the specified language
        regardless of what language the user writes in.

        Args:
            language (str): The language for responses (e.g. 'Turkish', 'Spanish').

        Returns:
            Dracula: The current instance for method chaining.

        Example:
            >>> ai.set_language("Turkish")
        """
        validate_language(language)
        self.language = language
        self.memory.clear()
        logger.info(f"Language changed to '{language}'")
        return self

    def set_persona(self, persona: str) -> "Dracula":
        """
        Switch to a built-in persona instantly.

        Each persona comes with a predefined prompt, temperature, and language.
        Switching personas automatically clears the conversation memory.

        Args:
            persona (str): The name of the persona to use.

        Returns:
            Dracula: The current instance for method chaining.

        Raises:
            PersonaException: If the persona name is not recognized.

        Example:
            >>> ai.set_persona("pirate")
        """
        if persona not in PERSONAS:
            available = ", ".join(PERSONAS.keys())
            raise PersonaException(
                f"Unknown persona '{persona}'. Available personas: {available}"
            )

        selected = PERSONAS[persona]
        self.set_prompt(selected["prompt"])
        self.set_temperature(selected["temperature"])
        self.set_language(selected["language"])

        logger.info(f"Persona changed to '{persona}'")

    def set_retry(self, max_retries: int, retry_delay: float = 1.0) -> "Dracula":
        """
        Change the retry settings.

        Args:
            max_retries (int): Maximum number of retry attempts.
            retry_delay (float): Initial delay in seconds between retries.

        Returns:
            Dracula: The current instance for method chaining.

        Example:
            >>> ai.set_retry(max_retries=5, retry_delay=2.0)
        """
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        logger.info(
            f"Retry settings updated: max_retries={max_retries}, retry_delay={retry_delay}"
        )
        return self

    def set_log_level(self, level: str) -> "Dracula":
        """
        Change the logging level at any time.

        Args:
            level (str): Logging level — DEBUG, INFO, WARNING, ERROR, or CRITICAL.

        Returns:
            Dracula: The current instance for method chaining.

        Example:
            >>> ai.set_log_level("WARNING")
        """
        enable_logging(level)
        return self

    def list_personas(self):
        """
        Return a list of all available built-in persona names.

        Returns:
            list: A list of persona name strings.

        Example:
            >>> print(ai.list_personas())
            ['assistant', 'pirate', 'chef', 'shakespeare', 'scientist', 'comedian',
             'philosopher', 'therapist', 'tutor', 'hacker', 'stoic', 'storyteller']
        """
        return list(PERSONAS.keys())

    def list_available_models(self) -> list:
        """
        Fetch all currently available models from the provider in real time.

        Returns:
            list: A list of available model name strings.

        Example:
            >>> print(ai.list_available_models())
        """
        return self._adapter.list_models()

    def get_history(self):
        """
        Return the full conversation history as a list of dictionaries.

        Returns:
            list: A list of message dictionaries with 'role' and 'content' keys.

        Example:
            >>> print(ai.get_history())
        """
        return self.memory.get_history()

    def add_tool(self, tool: Tool) -> "Dracula":
        """
        Register a new tool after initialization.

        Args:
            tool (Tool): The tool to register.

        Returns:
            Dracula: The current instance for method chaining.

        Example:
            >>> ai.add_tool(get_weather)
        """
        self.tool_registry.register(tool)
        logger.info(f"Tool '{tool.name}' registered.")
        return self

    def list_tools(self) -> list:
        """
        Return a list of all registered tool names.

        Returns:
            list: List of tool name strings.

        Example:
            >>> print(ai.list_tools())
        """
        return self.tool_registry.list_tools()

    def _build_system_instruction(self) -> str:
        """Build the system instruction with language."""
        if self.language.lower() != "auto":
            return f"{self.prompt} Always respond in {self.language}."
        return self.prompt

    def count_tokens(self, text: str) -> int:
        """
        Count the number of tokens in a given text using the current model.

        Args:
            text (str): The text to calculate tokens for.

        Returns:
            int: The total number of tokens.

        Raises:
            ValidationException: If the text is invalid.
            ChatException: If the provider fails to count tokens.

        Example:
            >>> tokens = ai.count_tokens("Hello!")
            >>> print(f"This text uses {tokens} tokens.")
        """
        validate_message(text)
        return self._adapter.count_tokens(text)

    def count_history_tokens(self) -> int:
        """
        Count the total number of tokens used by the current conversation history,
        including the system prompt.

        Returns:
            int: The total number of tokens in the active session.

        Raises:
            ChatException: If the provider fails to count tokens.

        Example:
            >>> total_usage = ai.count_history_tokens()
            >>> print(f"Current session uses {total_usage} tokens.")
        """
        return self._adapter.count_history_tokens(
            history=self.memory.get_history(),
            system=self._build_system_instruction(),
        )
