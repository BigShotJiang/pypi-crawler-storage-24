import mimetypes
from enum import Enum
from pathlib import Path
from google import genai

from .base import BaseAdapter, AsyncBaseAdapter, AdapterResponse
from ..tools import ToolResult
from ..exceptions import InvalidAPIKeyException, ChatException, ValidationException
from ..models import GeminiModel
from ..validators import validate_model
from ..logger import get_logger

logger = get_logger("dracula.adapters.gemini")


class GeminiAdapter(BaseAdapter):
    """Adapter for Google Gemini models (google-genai SDK, synchronous).

    This is the default adapter used when Dracula is initialized with an
    api_key. It wraps the google-genai SDK and supports all Gemini-specific
    features including multimodal input, function calling, and JSON output.

    Args:
        api_key (str): Your Google Gemini API key.
        model (GeminiModel | str): The model to use. Defaults to GeminiModel.FLASH.

    Example:
        >>> from dracula.adapters import GeminiAdapter
        >>> from dracula import Dracula
        >>> ai = Dracula(adapter=GeminiAdapter(api_key="your-key", model="gemini-2.5-pro"))
    """

    def __init__(self, api_key: str, model: GeminiModel | str = GeminiModel.FLASH):
        validate_model(model)
        try:
            self._client = genai.Client(api_key=api_key)
            self._model_name = model.value if isinstance(model, Enum) else model
        except Exception:
            raise InvalidAPIKeyException("Invalid API key or Gemini model name.")

    @property
    def model_name(self) -> str:
        return self._model_name

    @model_name.setter
    def model_name(self, value) -> None:
        self._model_name = value.value if isinstance(value, Enum) else value

    def _history_to_contents(self, history: list[dict]) -> list:
        return [
            genai.types.Content(
                role=m["role"], parts=[genai.types.Part(text=m["content"])]
            )
            for m in history
        ]

    def _build_config(self, system, temperature, max_tokens, tool_registry=None):
        config = genai.types.GenerateContentConfig(
            system_instruction=system,
            temperature=temperature,
            max_output_tokens=max_tokens,
        )
        if tool_registry and tool_registry.has_tools():
            config.tools = [
                genai.types.Tool(
                    function_declarations=tool_registry.get_gemini_schemas()
                )
            ]
        return config

    def send_message(
        self,
        history,
        message,
        system,
        temperature,
        max_tokens,
        tool_registry=None,
        auto_call=True,
        filepath=None,
    ):
        config = self._build_config(system, temperature, max_tokens, tool_registry)
        session = self._client.chats.create(
            model=self._model_name,
            config=config,
            history=self._history_to_contents(history),
        )

        if filepath:
            path = Path(filepath)
            if not path.exists():
                raise ValidationException(f"File not found: {filepath}")
            mime_type, _ = mimetypes.guess_type(path)
            if not mime_type:
                mime_type = "application/octet-stream"
            file_part = genai.types.Part.from_bytes(
                data=path.read_bytes(), mime_type=mime_type
            )
            payload = [message, file_part]
        else:
            payload = message

        response = session.send_message(payload)

        while True:
            if not response.candidates or not response.candidates[0].content:
                raise ChatException(
                    "Response was blocked or returned empty (likely due to safety filters)."
                )

            tool_call_found = False
            for part in response.candidates[0].content.parts:
                if hasattr(part, "function_call") and part.function_call:
                    tool_call_found = True
                    tool_name = part.function_call.name
                    tool_args = dict(part.function_call.args)
                    logger.debug(f"Tool call requested: {tool_name}({tool_args})")

                    if not auto_call:
                        return ToolResult(
                            requires_tool_call=True,
                            tool_name=tool_name,
                            tool_args=tool_args,
                            text=None,
                        )

                    tool = tool_registry.get(tool_name)
                    tool_result = tool.call(**tool_args)
                    logger.debug(f"Tool '{tool_name}' returned: {tool_result}")

                    response = session.send_message(
                        genai.types.Part(
                            function_response=genai.types.FunctionResponse(
                                name=tool_name,
                                response={"result": str(tool_result)},
                            )
                        )
                    )
                    break

            if not tool_call_found:
                reply = response.text
                if not reply:
                    raise ChatException("Received an empty response from Gemini.")

                input_tokens = 0
                output_tokens = 0
                if hasattr(response, "usage_metadata") and response.usage_metadata:
                    input_tokens = (
                        getattr(response.usage_metadata, "prompt_token_count", 0) or 0
                    )
                    output_tokens = (
                        getattr(response.usage_metadata, "candidates_token_count", 0)
                        or 0
                    )

                return AdapterResponse(
                    text=reply,
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                )

    def stream(self, history, message, system, temperature, max_tokens):
        config = self._build_config(system, temperature, max_tokens)
        session = self._client.chats.create(
            model=self._model_name,
            config=config,
            history=self._history_to_contents(history),
        )
        for chunk in session.send_message_stream(message):
            if chunk.text:
                yield chunk.text

    def generate_structured(
        self, history, message, system, temperature, max_tokens, schema
    ) -> str:
        contents = self._history_to_contents(history)
        contents.append(
            genai.types.Content(role="user", parts=[genai.types.Part(text=message)])
        )
        config = genai.types.GenerateContentConfig(
            system_instruction=system,
            temperature=temperature,
            max_output_tokens=max_tokens,
            response_mime_type="application/json",
            response_schema=schema,
        )
        response = self._client.models.generate_content(
            model=self._model_name,
            contents=contents,
            config=config,
        )
        reply = response.text
        if not reply:
            raise ChatException("Received an empty structured response from Gemini.")
        return reply

    def count_tokens(self, text: str) -> int:
        try:
            response = self._client.models.count_tokens(
                model=self._model_name, contents=text
            )
            return response.total_tokens
        except Exception as e:
            raise ChatException(f"Failed to count tokens: {str(e)}")

    def count_history_tokens(self, history: list[dict], system: str) -> int:
        try:
            if not history:
                return self.count_tokens(system)
            contents = self._history_to_contents(history)
            config = genai.types.GenerateContentConfig(system_instruction=system)
            response = self._client.models.count_tokens(
                model=self._model_name, contents=contents, config=config
            )
            return response.total_tokens
        except Exception as e:
            raise ChatException(f"Failed to count history tokens: {str(e)}")

    def list_models(self) -> list[str]:
        try:
            models = self._client.models.list()
            return [model.name for model in models]
        except Exception as e:
            raise ChatException(f"Failed to fetch models: {str(e)}")


class AsyncGeminiAdapter(AsyncBaseAdapter):
    """Adapter for Google Gemini models (google-genai SDK, asynchronous).

    This is the default adapter used when AsyncDracula is initialized with an
    api_key. Supports all Gemini features with full async/await support.

    Args:
        api_key (str): Your Google Gemini API key.
        model (GeminiModel | str): The model to use. Defaults to GeminiModel.FLASH.

    Example:
        >>> from dracula.adapters import AsyncGeminiAdapter
        >>> from dracula import AsyncDracula
        >>> ai = AsyncDracula(adapter=AsyncGeminiAdapter(api_key="your-key"))
    """

    def __init__(self, api_key: str, model: GeminiModel | str = GeminiModel.FLASH):
        validate_model(model)
        try:
            self._client = genai.Client(api_key=api_key)
            self._model_name = model.value if isinstance(model, Enum) else model
        except Exception:
            raise InvalidAPIKeyException("Invalid API key or Gemini model name.")

    @property
    def model_name(self) -> str:
        return self._model_name

    @model_name.setter
    def model_name(self, value) -> None:
        self._model_name = value.value if isinstance(value, Enum) else value

    def _history_to_contents(self, history: list[dict]) -> list:
        return [
            genai.types.Content(
                role=m["role"], parts=[genai.types.Part(text=m["content"])]
            )
            for m in history
        ]

    def _build_config(self, system, temperature, max_tokens, tool_registry=None):
        config = genai.types.GenerateContentConfig(
            system_instruction=system,
            temperature=temperature,
            max_output_tokens=max_tokens,
        )
        if tool_registry and tool_registry.has_tools():
            config.tools = [
                genai.types.Tool(
                    function_declarations=tool_registry.get_gemini_schemas()
                )
            ]
        return config

    async def send_message(
        self,
        history,
        message,
        system,
        temperature,
        max_tokens,
        tool_registry=None,
        auto_call=True,
        filepath=None,
    ):
        import asyncio

        config = self._build_config(system, temperature, max_tokens, tool_registry)
        session = self._client.aio.chats.create(
            model=self._model_name,
            config=config,
            history=self._history_to_contents(history),
        )

        if filepath:
            path = Path(filepath)
            if not path.exists():
                raise ValidationException(f"File not found: {filepath}")
            mime_type, _ = mimetypes.guess_type(path)
            if not mime_type:
                mime_type = "application/octet-stream"
            data = await asyncio.to_thread(path.read_bytes)
            file_part = genai.types.Part.from_bytes(data=data, mime_type=mime_type)
            payload = [message, file_part]
        else:
            payload = message

        response = await session.send_message(payload)

        while True:
            if not response.candidates or not response.candidates[0].content:
                raise ChatException(
                    "Response was blocked or returned empty (likely due to safety filters)."
                )

            tool_call_found = False
            for part in response.candidates[0].content.parts:
                if hasattr(part, "function_call") and part.function_call:
                    tool_call_found = True
                    tool_name = part.function_call.name
                    tool_args = dict(part.function_call.args)
                    logger.debug(f"Tool call requested: {tool_name}({tool_args})")

                    if not auto_call:
                        return ToolResult(
                            requires_tool_call=True,
                            tool_name=tool_name,
                            tool_args=tool_args,
                            text=None,
                        )

                    tool = tool_registry.get(tool_name)
                    tool_result = tool.call(**tool_args)
                    logger.debug(f"Tool '{tool_name}' returned: {tool_result}")

                    response = await session.send_message(
                        genai.types.Part(
                            function_response=genai.types.FunctionResponse(
                                name=tool_name,
                                response={"result": str(tool_result)},
                            )
                        )
                    )
                    break

            if not tool_call_found:
                reply = response.text
                if not reply:
                    raise ChatException("Received an empty response from Gemini.")

                input_tokens = 0
                output_tokens = 0
                if hasattr(response, "usage_metadata") and response.usage_metadata:
                    input_tokens = (
                        getattr(response.usage_metadata, "prompt_token_count", 0) or 0
                    )
                    output_tokens = (
                        getattr(response.usage_metadata, "candidates_token_count", 0)
                        or 0
                    )

                return AdapterResponse(
                    text=reply,
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                )

    async def stream(self, history, message, system, temperature, max_tokens):
        config = self._build_config(system, temperature, max_tokens)
        session = self._client.aio.chats.create(
            model=self._model_name,
            config=config,
            history=self._history_to_contents(history),
        )
        async for chunk in await session.send_message_stream(message):
            if chunk.text:
                yield chunk.text

    async def generate_structured(
        self, history, message, system, temperature, max_tokens, schema
    ) -> str:
        contents = self._history_to_contents(history)
        contents.append(
            genai.types.Content(role="user", parts=[genai.types.Part(text=message)])
        )
        config = genai.types.GenerateContentConfig(
            system_instruction=system,
            temperature=temperature,
            max_output_tokens=max_tokens,
            response_mime_type="application/json",
            response_schema=schema,
        )
        response = await self._client.aio.models.generate_content(
            model=self._model_name,
            contents=contents,
            config=config,
        )
        reply = response.text
        if not reply:
            raise ChatException("Received an empty structured response from Gemini.")
        return reply

    async def count_tokens(self, text: str) -> int:
        try:
            response = await self._client.aio.models.count_tokens(
                model=self._model_name, contents=text
            )
            return response.total_tokens
        except Exception as e:
            raise ChatException(f"Failed to count tokens: {str(e)}")

    async def count_history_tokens(self, history: list[dict], system: str) -> int:
        try:
            if not history:
                return await self.count_tokens(system)
            contents = self._history_to_contents(history)
            config = genai.types.GenerateContentConfig(system_instruction=system)
            response = await self._client.aio.models.count_tokens(
                model=self._model_name, contents=contents, config=config
            )
            return response.total_tokens
        except Exception as e:
            raise ChatException(f"Failed to count history tokens: {str(e)}")

    async def list_models(self) -> list[str]:
        try:
            models = await self._client.aio.models.list()
            return [model.name for model in models]
        except Exception as e:
            raise ChatException(f"Failed to fetch models: {str(e)}")
