import json
from enum import Enum

from .base import BaseAdapter, AsyncBaseAdapter, AdapterResponse
from ..tools import ToolResult
from ..exceptions import ChatException, ValidationException
from ..logger import get_logger

logger = get_logger("dracula.adapters.openai")

# Dracula uses "model" for assistant role; OpenAI uses "assistant"
_ROLE_MAP = {"model": "assistant"}

# Reasoning models do not accept a temperature parameter
_REASONING_MODEL_PREFIXES = ("o1", "o3", "o4")


def _is_reasoning_model(model_name: str) -> bool:
    return any(model_name.startswith(p) for p in _REASONING_MODEL_PREFIXES)


def _convert_history(history: list[dict]) -> list[dict]:
    return [
        {"role": _ROLE_MAP.get(m["role"], m["role"]), "content": m["content"]}
        for m in history
    ]


class OpenAIAdapter(BaseAdapter):
    """Adapter for OpenAI models (openai SDK, synchronous).

    Requires the openai package: pip install openai

    Args:
        api_key (str): Your OpenAI API key.
        model (str): The model to use. Defaults to 'gpt-4o'.

    Example:
        >>> from dracula.adapters import OpenAIAdapter
        >>> from dracula import Dracula
        >>> ai = Dracula(adapter=OpenAIAdapter(api_key="sk-...", model="gpt-4o"))
        >>> print(ai.chat("Hello!"))
    """

    def __init__(self, api_key: str, model="gpt-4o"):
        try:
            from openai import OpenAI

            self._client = OpenAI(api_key=api_key)
            self._model_name = model.value if isinstance(model, Enum) else model
        except ImportError:
            raise ImportError(
                "openai package is required. Install it with: pip install openai"
            )
        except Exception as e:
            from ..exceptions import InvalidAPIKeyException

            raise InvalidAPIKeyException(
                f"Failed to initialize OpenAI client: {e}"
            )

    @property
    def model_name(self) -> str:
        return self._model_name

    @model_name.setter
    def model_name(self, value) -> None:
        self._model_name = value.value if isinstance(value, Enum) else value

    def _build_tools(self, tool_registry) -> list | None:
        if not tool_registry or not tool_registry.has_tools():
            return None
        return [
            {"type": "function", "function": schema}
            for schema in tool_registry.get_gemini_schemas()
        ]

    def send_message(
        self,
        history,
        message,
        system,
        temperature,
        max_tokens,
        tool_registry=None,
        auto_call=True,
        filepath=None,
    ):
        if filepath:
            raise ValidationException(
                "File attachments are not supported by OpenAIAdapter."
            )

        messages = [{"role": "system", "content": system}]
        messages.extend(_convert_history(history))
        messages.append({"role": "user", "content": message})

        tools = self._build_tools(tool_registry)
        kwargs = dict(model=self._model_name, messages=messages, max_tokens=max_tokens)
        if not _is_reasoning_model(self._model_name):
            kwargs["temperature"] = temperature
        if tools:
            kwargs["tools"] = tools

        response = self._client.chat.completions.create(**kwargs)

        while True:
            choice = response.choices[0]
            msg = choice.message

            if msg.tool_calls:
                tc = msg.tool_calls[0]
                tool_name = tc.function.name
                tool_args = json.loads(tc.function.arguments)
                logger.debug(f"Tool call requested: {tool_name}({tool_args})")

                if not auto_call:
                    return ToolResult(
                        requires_tool_call=True,
                        tool_name=tool_name,
                        tool_args=tool_args,
                        text=None,
                    )

                tool = tool_registry.get(tool_name)
                tool_result = tool.call(**tool_args)
                logger.debug(f"Tool '{tool_name}' returned: {tool_result}")

                messages.append(msg.model_dump())
                messages.append(
                    {
                        "role": "tool",
                        "tool_call_id": tc.id,
                        "content": str(tool_result),
                    }
                )
                kwargs["messages"] = messages
                response = self._client.chat.completions.create(**kwargs)
            else:
                reply = msg.content
                if not reply:
                    raise ChatException("Received an empty response from OpenAI.")

                return AdapterResponse(
                    text=reply,
                    input_tokens=response.usage.prompt_tokens if response.usage else 0,
                    output_tokens=response.usage.completion_tokens
                    if response.usage
                    else 0,
                )

    def stream(self, history, message, system, temperature, max_tokens):
        messages = [{"role": "system", "content": system}]
        messages.extend(_convert_history(history))
        messages.append({"role": "user", "content": message})

        stream_kwargs = dict(model=self._model_name, messages=messages, max_tokens=max_tokens, stream=True)
        if not _is_reasoning_model(self._model_name):
            stream_kwargs["temperature"] = temperature
        with self._client.chat.completions.create(**stream_kwargs) as stream:
            for chunk in stream:
                delta = chunk.choices[0].delta.content
                if delta:
                    yield delta

    def generate_structured(
        self, history, message, system, temperature, max_tokens, schema
    ) -> str:
        schema_hint = (
            f"\n\nRespond with valid JSON matching this schema: {json.dumps(schema)}"
        )
        messages = [{"role": "system", "content": system + schema_hint}]
        messages.extend(_convert_history(history))
        messages.append({"role": "user", "content": message})

        struct_kwargs = dict(model=self._model_name, messages=messages, max_tokens=max_tokens, response_format={"type": "json_object"})
        if not _is_reasoning_model(self._model_name):
            struct_kwargs["temperature"] = temperature
        response = self._client.chat.completions.create(**struct_kwargs)
        reply = response.choices[0].message.content
        if not reply:
            raise ChatException("Received an empty structured response from OpenAI.")
        return reply

    def count_tokens(self, text: str) -> int:
        try:
            import tiktoken

            enc = tiktoken.encoding_for_model(self._model_name)
            return len(enc.encode(text))
        except Exception:
            # Rough estimate: ~4 characters per token
            return len(text) // 4

    def list_models(self) -> list[str]:
        try:
            models = self._client.models.list()
            return [m.id for m in models.data]
        except Exception as e:
            raise ChatException(f"Failed to fetch OpenAI models: {str(e)}")


class AsyncOpenAIAdapter(AsyncBaseAdapter):
    """Adapter for OpenAI models (openai SDK, asynchronous).

    Requires the openai package: pip install openai

    Args:
        api_key (str): Your OpenAI API key.
        model (str): The model to use. Defaults to 'gpt-4o'.

    Example:
        >>> from dracula.adapters import AsyncOpenAIAdapter
        >>> from dracula import AsyncDracula
        >>> ai = AsyncDracula(adapter=AsyncOpenAIAdapter(api_key="sk-...", model="gpt-4o"))
        >>> response = await ai.chat("Hello!")
    """

    def __init__(self, api_key: str, model="gpt-4o"):
        try:
            from openai import AsyncOpenAI

            self._client = AsyncOpenAI(api_key=api_key)
            self._model_name = model.value if isinstance(model, Enum) else model
        except ImportError:
            raise ImportError(
                "openai package is required. Install it with: pip install openai"
            )
        except Exception as e:
            from ..exceptions import InvalidAPIKeyException

            raise InvalidAPIKeyException(
                f"Failed to initialize AsyncOpenAI client: {e}"
            )

    @property
    def model_name(self) -> str:
        return self._model_name

    @model_name.setter
    def model_name(self, value) -> None:
        self._model_name = value.value if isinstance(value, Enum) else value

    def _build_tools(self, tool_registry) -> list | None:
        if not tool_registry or not tool_registry.has_tools():
            return None
        return [
            {"type": "function", "function": schema}
            for schema in tool_registry.get_gemini_schemas()
        ]

    async def send_message(
        self,
        history,
        message,
        system,
        temperature,
        max_tokens,
        tool_registry=None,
        auto_call=True,
        filepath=None,
    ):
        if filepath:
            raise ValidationException(
                "File attachments are not supported by AsyncOpenAIAdapter."
            )

        messages = [{"role": "system", "content": system}]
        messages.extend(_convert_history(history))
        messages.append({"role": "user", "content": message})

        tools = self._build_tools(tool_registry)
        kwargs = dict(model=self._model_name, messages=messages, max_tokens=max_tokens)
        if not _is_reasoning_model(self._model_name):
            kwargs["temperature"] = temperature
        if tools:
            kwargs["tools"] = tools

        response = await self._client.chat.completions.create(**kwargs)

        while True:
            choice = response.choices[0]
            msg = choice.message

            if msg.tool_calls:
                tc = msg.tool_calls[0]
                tool_name = tc.function.name
                tool_args = json.loads(tc.function.arguments)

                if not auto_call:
                    return ToolResult(
                        requires_tool_call=True,
                        tool_name=tool_name,
                        tool_args=tool_args,
                        text=None,
                    )

                tool = tool_registry.get(tool_name)
                tool_result = tool.call(**tool_args)

                messages.append(msg.model_dump())
                messages.append(
                    {
                        "role": "tool",
                        "tool_call_id": tc.id,
                        "content": str(tool_result),
                    }
                )
                kwargs["messages"] = messages
                response = await self._client.chat.completions.create(**kwargs)
            else:
                reply = msg.content
                if not reply:
                    raise ChatException("Received an empty response from OpenAI.")

                return AdapterResponse(
                    text=reply,
                    input_tokens=response.usage.prompt_tokens if response.usage else 0,
                    output_tokens=response.usage.completion_tokens
                    if response.usage
                    else 0,
                )

    async def stream(self, history, message, system, temperature, max_tokens):
        messages = [{"role": "system", "content": system}]
        messages.extend(_convert_history(history))
        messages.append({"role": "user", "content": message})

        stream_kwargs = dict(model=self._model_name, messages=messages, max_tokens=max_tokens, stream=True)
        if not _is_reasoning_model(self._model_name):
            stream_kwargs["temperature"] = temperature
        async with await self._client.chat.completions.create(**stream_kwargs) as stream:
            async for chunk in stream:
                delta = chunk.choices[0].delta.content
                if delta:
                    yield delta

    async def generate_structured(
        self, history, message, system, temperature, max_tokens, schema
    ) -> str:
        schema_hint = (
            f"\n\nRespond with valid JSON matching this schema: {json.dumps(schema)}"
        )
        messages = [{"role": "system", "content": system + schema_hint}]
        messages.extend(_convert_history(history))
        messages.append({"role": "user", "content": message})

        struct_kwargs = dict(model=self._model_name, messages=messages, max_tokens=max_tokens, response_format={"type": "json_object"})
        if not _is_reasoning_model(self._model_name):
            struct_kwargs["temperature"] = temperature
        response = await self._client.chat.completions.create(**struct_kwargs)
        reply = response.choices[0].message.content
        if not reply:
            raise ChatException(
                "Received an empty structured response from OpenAI."
            )
        return reply

    async def count_tokens(self, text: str) -> int:
        try:
            import tiktoken

            enc = tiktoken.encoding_for_model(self._model_name)
            return len(enc.encode(text))
        except Exception:
            return len(text) // 4

    async def list_models(self) -> list[str]:
        try:
            models = await self._client.models.list()
            return [m.id for m in models.data]
        except Exception as e:
            raise ChatException(f"Failed to fetch OpenAI models: {str(e)}")
