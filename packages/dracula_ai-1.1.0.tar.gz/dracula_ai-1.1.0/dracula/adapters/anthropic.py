import json
from enum import Enum

from .base import BaseAdapter, AsyncBaseAdapter, AdapterResponse
from ..tools import ToolResult
from ..exceptions import ChatException, ValidationException
from ..logger import get_logger

logger = get_logger("dracula.adapters.anthropic")

# Dracula uses "model" for assistant role; Anthropic uses "assistant"
_ROLE_MAP = {"model": "assistant"}


def _convert_history(history: list[dict]) -> list[dict]:
    return [
        {"role": _ROLE_MAP.get(m["role"], m["role"]), "content": m["content"]}
        for m in history
    ]


class AnthropicAdapter(BaseAdapter):
    """Adapter for Anthropic Claude models (anthropic SDK, synchronous).

    Requires the anthropic package: pip install anthropic

    Args:
        api_key (str): Your Anthropic API key.
        model (str): The model to use. Defaults to 'claude-sonnet-4-6'.

    Example:
        >>> from dracula.adapters import AnthropicAdapter
        >>> from dracula import Dracula
        >>> ai = Dracula(adapter=AnthropicAdapter(api_key="sk-ant-...", model="claude-opus-4-6"))
        >>> print(ai.chat("Hello!"))
    """

    def __init__(self, api_key: str, model="claude-sonnet-4-6"):
        try:
            from anthropic import Anthropic

            self._client = Anthropic(api_key=api_key)
            self._model_name = model.value if isinstance(model, Enum) else model
        except ImportError:
            raise ImportError(
                "anthropic package is required. Install it with: pip install anthropic"
            )
        except Exception as e:
            from ..exceptions import InvalidAPIKeyException

            raise InvalidAPIKeyException(
                f"Failed to initialize Anthropic client: {e}"
            )

    @property
    def model_name(self) -> str:
        return self._model_name

    @model_name.setter
    def model_name(self, value) -> None:
        self._model_name = value.value if isinstance(value, Enum) else value

    def _build_tools(self, tool_registry) -> list | None:
        if not tool_registry or not tool_registry.has_tools():
            return None
        return [
            {
                "name": s["name"],
                "description": s["description"],
                "input_schema": s["parameters"],
            }
            for s in tool_registry.get_gemini_schemas()
        ]

    def send_message(
        self,
        history,
        message,
        system,
        temperature,
        max_tokens,
        tool_registry=None,
        auto_call=True,
        filepath=None,
    ):
        if filepath:
            raise ValidationException(
                "File attachments are not supported by AnthropicAdapter."
            )

        messages = list(_convert_history(history))
        messages.append({"role": "user", "content": message})

        tools = self._build_tools(tool_registry)
        kwargs = dict(
            model=self._model_name,
            messages=messages,
            system=system,
            temperature=temperature,
            max_tokens=max_tokens,
        )
        if tools:
            kwargs["tools"] = tools

        response = self._client.messages.create(**kwargs)

        while True:
            tool_use_block = next(
                (b for b in response.content if b.type == "tool_use"), None
            )

            if tool_use_block:
                tool_name = tool_use_block.name
                tool_args = tool_use_block.input
                logger.debug(f"Tool call requested: {tool_name}({tool_args})")

                if not auto_call:
                    return ToolResult(
                        requires_tool_call=True,
                        tool_name=tool_name,
                        tool_args=tool_args,
                        text=None,
                    )

                tool = tool_registry.get(tool_name)
                tool_result = tool.call(**tool_args)
                logger.debug(f"Tool '{tool_name}' returned: {tool_result}")

                messages.append({"role": "assistant", "content": response.content})
                messages.append(
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "tool_result",
                                "tool_use_id": tool_use_block.id,
                                "content": str(tool_result),
                            }
                        ],
                    }
                )
                kwargs["messages"] = messages
                response = self._client.messages.create(**kwargs)
            else:
                reply = "".join(
                    b.text for b in response.content if hasattr(b, "text")
                )
                if not reply:
                    raise ChatException("Received an empty response from Anthropic.")

                return AdapterResponse(
                    text=reply,
                    input_tokens=response.usage.input_tokens if response.usage else 0,
                    output_tokens=response.usage.output_tokens if response.usage else 0,
                )

    def stream(self, history, message, system, temperature, max_tokens):
        messages = list(_convert_history(history))
        messages.append({"role": "user", "content": message})

        with self._client.messages.stream(
            model=self._model_name,
            messages=messages,
            system=system,
            temperature=temperature,
            max_tokens=max_tokens,
        ) as stream:
            for chunk in stream.text_stream:
                if chunk:
                    yield chunk

    def generate_structured(
        self, history, message, system, temperature, max_tokens, schema
    ) -> str:
        structured_system = (
            system
            + f"\n\nYou must respond with valid JSON matching this schema:\n"
            f"{json.dumps(schema, indent=2)}\n\nRespond with JSON only, no other text."
        )
        messages = list(_convert_history(history))
        messages.append({"role": "user", "content": message})

        response = self._client.messages.create(
            model=self._model_name,
            messages=messages,
            system=structured_system,
            temperature=temperature,
            max_tokens=max_tokens,
        )
        reply = "".join(b.text for b in response.content if hasattr(b, "text"))
        if not reply:
            raise ChatException(
                "Received an empty structured response from Anthropic."
            )
        return reply

    def count_tokens(self, text: str) -> int:
        try:
            response = self._client.messages.count_tokens(
                model=self._model_name,
                messages=[{"role": "user", "content": text}],
            )
            return response.input_tokens
        except Exception:
            # Rough estimate: ~4 characters per token
            return len(text) // 4

    def list_models(self) -> list[str]:
        try:
            models = self._client.models.list()
            return [m.id for m in models.data]
        except Exception as e:
            raise ChatException(f"Failed to fetch Anthropic models: {str(e)}")


class AsyncAnthropicAdapter(AsyncBaseAdapter):
    """Adapter for Anthropic Claude models (anthropic SDK, asynchronous).

    Requires the anthropic package: pip install anthropic

    Args:
        api_key (str): Your Anthropic API key.
        model (str): The model to use. Defaults to 'claude-sonnet-4-6'.

    Example:
        >>> from dracula.adapters import AsyncAnthropicAdapter
        >>> from dracula import AsyncDracula
        >>> ai = AsyncDracula(adapter=AsyncAnthropicAdapter(api_key="sk-ant-..."))
        >>> response = await ai.chat("Hello!")
    """

    def __init__(self, api_key: str, model="claude-sonnet-4-6"):
        try:
            from anthropic import AsyncAnthropic

            self._client = AsyncAnthropic(api_key=api_key)
            self._model_name = model.value if isinstance(model, Enum) else model
        except ImportError:
            raise ImportError(
                "anthropic package is required. Install it with: pip install anthropic"
            )
        except Exception as e:
            from ..exceptions import InvalidAPIKeyException

            raise InvalidAPIKeyException(
                f"Failed to initialize AsyncAnthropic client: {e}"
            )

    @property
    def model_name(self) -> str:
        return self._model_name

    @model_name.setter
    def model_name(self, value) -> None:
        self._model_name = value.value if isinstance(value, Enum) else value

    def _build_tools(self, tool_registry) -> list | None:
        if not tool_registry or not tool_registry.has_tools():
            return None
        return [
            {
                "name": s["name"],
                "description": s["description"],
                "input_schema": s["parameters"],
            }
            for s in tool_registry.get_gemini_schemas()
        ]

    async def send_message(
        self,
        history,
        message,
        system,
        temperature,
        max_tokens,
        tool_registry=None,
        auto_call=True,
        filepath=None,
    ):
        if filepath:
            raise ValidationException(
                "File attachments are not supported by AsyncAnthropicAdapter."
            )

        messages = list(_convert_history(history))
        messages.append({"role": "user", "content": message})

        tools = self._build_tools(tool_registry)
        kwargs = dict(
            model=self._model_name,
            messages=messages,
            system=system,
            temperature=temperature,
            max_tokens=max_tokens,
        )
        if tools:
            kwargs["tools"] = tools

        response = await self._client.messages.create(**kwargs)

        while True:
            tool_use_block = next(
                (b for b in response.content if b.type == "tool_use"), None
            )

            if tool_use_block:
                tool_name = tool_use_block.name
                tool_args = tool_use_block.input

                if not auto_call:
                    return ToolResult(
                        requires_tool_call=True,
                        tool_name=tool_name,
                        tool_args=tool_args,
                        text=None,
                    )

                tool = tool_registry.get(tool_name)
                tool_result = tool.call(**tool_args)

                messages.append({"role": "assistant", "content": response.content})
                messages.append(
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "tool_result",
                                "tool_use_id": tool_use_block.id,
                                "content": str(tool_result),
                            }
                        ],
                    }
                )
                kwargs["messages"] = messages
                response = await self._client.messages.create(**kwargs)
            else:
                reply = "".join(
                    b.text for b in response.content if hasattr(b, "text")
                )
                if not reply:
                    raise ChatException("Received an empty response from Anthropic.")

                return AdapterResponse(
                    text=reply,
                    input_tokens=response.usage.input_tokens if response.usage else 0,
                    output_tokens=response.usage.output_tokens if response.usage else 0,
                )

    async def stream(self, history, message, system, temperature, max_tokens):
        messages = list(_convert_history(history))
        messages.append({"role": "user", "content": message})

        async with self._client.messages.stream(
            model=self._model_name,
            messages=messages,
            system=system,
            temperature=temperature,
            max_tokens=max_tokens,
        ) as stream:
            async for chunk in stream.text_stream:
                if chunk:
                    yield chunk

    async def generate_structured(
        self, history, message, system, temperature, max_tokens, schema
    ) -> str:
        structured_system = (
            system
            + f"\n\nYou must respond with valid JSON matching this schema:\n"
            f"{json.dumps(schema, indent=2)}\n\nRespond with JSON only, no other text."
        )
        messages = list(_convert_history(history))
        messages.append({"role": "user", "content": message})

        response = await self._client.messages.create(
            model=self._model_name,
            messages=messages,
            system=structured_system,
            temperature=temperature,
            max_tokens=max_tokens,
        )
        reply = "".join(b.text for b in response.content if hasattr(b, "text"))
        if not reply:
            raise ChatException(
                "Received an empty structured response from Anthropic."
            )
        return reply

    async def count_tokens(self, text: str) -> int:
        try:
            response = await self._client.messages.count_tokens(
                model=self._model_name,
                messages=[{"role": "user", "content": text}],
            )
            return response.input_tokens
        except Exception:
            return len(text) // 4

    async def list_models(self) -> list[str]:
        try:
            models = await self._client.models.list()
            return [m.id for m in models.data]
        except Exception as e:
            raise ChatException(f"Failed to fetch Anthropic models: {str(e)}")
