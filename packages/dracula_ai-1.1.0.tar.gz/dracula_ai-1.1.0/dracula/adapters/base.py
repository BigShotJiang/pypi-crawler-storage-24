from abc import ABC, abstractmethod
from dataclasses import dataclass


@dataclass
class AdapterResponse:
    """Standardized response returned by any AI provider adapter."""

    text: str
    input_tokens: int = 0
    output_tokens: int = 0


class BaseAdapter(ABC):
    """Abstract base class for synchronous AI provider adapters.

    Implement this class to integrate a new AI provider with Dracula.
    All provider-specific API calls, message format conversions, and
    tool-call handling must be encapsulated here, keeping the core
    Dracula client completely provider-agnostic.

    Example:
        >>> from dracula.adapters import OpenAIAdapter
        >>> from dracula import Dracula
        >>> ai = Dracula(adapter=OpenAIAdapter(api_key="sk-...", model="gpt-4o"))
        >>> print(ai.chat("Hello!"))
    """

    @property
    @abstractmethod
    def model_name(self) -> str:
        """The active model identifier (e.g. 'gpt-4o', 'gemini-2.5-flash')."""
        ...

    @model_name.setter
    @abstractmethod
    def model_name(self, value: str) -> None:
        """Update the active model."""
        ...

    @abstractmethod
    def send_message(
        self,
        history: list[dict],
        message: str,
        system: str,
        temperature: float,
        max_tokens: int,
        tool_registry=None,
        auto_call: bool = True,
        filepath=None,
    ):
        """Send a message and return the model's response.

        Args:
            history: Conversation history as [{"role": ..., "content": ...}].
                     Roles use Dracula's canonical format: "user" and "model".
            message: The new user message to send.
            system: System instruction text.
            temperature: Sampling temperature (0.0–2.0).
            max_tokens: Maximum output tokens.
            tool_registry: Optional ToolRegistry for function calling support.
            auto_call: If True, execute tool calls automatically and return
                       the final text response. If False, return a ToolResult
                       immediately when the model requests a tool call.
            filepath: Optional path to a file attachment (provider-dependent).

        Returns:
            AdapterResponse on success, or ToolResult if auto_call=False and
            the model requested a tool call.
        """
        ...

    @abstractmethod
    def stream(
        self,
        history: list[dict],
        message: str,
        system: str,
        temperature: float,
        max_tokens: int,
    ):
        """Stream the model's response token by token.

        Args:
            history: Conversation history.
            message: The new user message.
            system: System instruction text.
            temperature: Sampling temperature.
            max_tokens: Maximum output tokens.

        Yields:
            str: Text chunks as they are generated.
        """
        ...

    @abstractmethod
    def generate_structured(
        self,
        history: list[dict],
        message: str,
        system: str,
        temperature: float,
        max_tokens: int,
        schema: dict,
    ) -> str:
        """Generate a structured JSON response conforming to a schema.

        Args:
            history: Conversation history.
            message: The new user message.
            system: System instruction text.
            temperature: Sampling temperature.
            max_tokens: Maximum output tokens.
            schema: JSON Schema dict describing the expected output format.

        Returns:
            str: Raw JSON string conforming to the schema.
        """
        ...

    @abstractmethod
    def count_tokens(self, text: str) -> int:
        """Count the number of tokens in the given text.

        Args:
            text: The text to tokenize.

        Returns:
            int: Token count.
        """
        ...

    def count_history_tokens(self, history: list[dict], system: str) -> int:
        """Count tokens for the full conversation context.

        The default implementation concatenates all text and calls
        count_tokens(). Override this for a more accurate provider-specific
        estimate that accounts for message structure and system prompt overhead.

        Args:
            history: Conversation history.
            system: System instruction text.

        Returns:
            int: Approximate total token count.
        """
        combined = system + " " + " ".join(m["content"] for m in history)
        return self.count_tokens(combined)

    @abstractmethod
    def list_models(self) -> list[str]:
        """Return a list of available model names for this provider.

        Returns:
            list[str]: Model identifier strings.
        """
        ...


class AsyncBaseAdapter(ABC):
    """Abstract base class for asynchronous AI provider adapters.

    Async mirror of BaseAdapter. Implement this for use with AsyncDracula.

    Example:
        >>> from dracula.adapters import AsyncOpenAIAdapter
        >>> from dracula import AsyncDracula
        >>> ai = AsyncDracula(adapter=AsyncOpenAIAdapter(api_key="sk-...", model="gpt-4o"))
        >>> response = await ai.chat("Hello!")
    """

    @property
    @abstractmethod
    def model_name(self) -> str: ...

    @model_name.setter
    @abstractmethod
    def model_name(self, value: str) -> None: ...

    @abstractmethod
    async def send_message(
        self,
        history: list[dict],
        message: str,
        system: str,
        temperature: float,
        max_tokens: int,
        tool_registry=None,
        auto_call: bool = True,
        filepath=None,
    ): ...

    @abstractmethod
    async def stream(
        self,
        history: list[dict],
        message: str,
        system: str,
        temperature: float,
        max_tokens: int,
    ): ...

    @abstractmethod
    async def generate_structured(
        self,
        history: list[dict],
        message: str,
        system: str,
        temperature: float,
        max_tokens: int,
        schema: dict,
    ) -> str: ...

    @abstractmethod
    async def count_tokens(self, text: str) -> int: ...

    async def count_history_tokens(self, history: list[dict], system: str) -> int:
        """Count tokens for the full conversation context (approximate)."""
        combined = system + " " + " ".join(m["content"] for m in history)
        return await self.count_tokens(combined)

    @abstractmethod
    async def list_models(self) -> list[str]: ...
