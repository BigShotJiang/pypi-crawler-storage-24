from enum import Enum
from pathlib import Path

from .exceptions import ValidationException
from .models import GeminiModel, OpenAIModel, AnthropicModel

_MODEL_ENUMS = (GeminiModel, OpenAIModel, AnthropicModel)


def validate_model(model):
    """Validate that model is a supported model enum or a non-empty string.

    Accepts GeminiModel, OpenAIModel, AnthropicModel enum values, or any
    non-empty string for custom model names.

    Args:
        model (GeminiModel | OpenAIModel | AnthropicModel | str): The model value to validate.

    Raises:
        ValidationException: If model is not a recognised enum or a non-empty string.
    """
    if isinstance(model, _MODEL_ENUMS):
        return
    if isinstance(model, str):
        if not model.strip():
            raise ValidationException("Model name cannot be empty.")
        return
    raise ValidationException(
        "Model must be a GeminiModel, OpenAIModel, AnthropicModel enum value, "
        "or a non-empty string."
    )


def validate_api_key(api_key: str):
    """Validate that api_key is a non-empty string.

    Args:
        api_key (str): The API key to validate.

    Raises:
        ValidationException: If api_key is not a non-empty string.
    """
    if not isinstance(api_key, str) or not api_key.strip():
        raise ValidationException("API key must be a non-empty string.")


def validate_temperature(temperature: float):
    """Validate that temperature is a number between 0.0 and 2.0.

    Args:
        temperature (float): The temperature value to validate.

    Raises:
        ValidationException: If temperature is not a number or is out of range.
    """
    if not isinstance(temperature, (int, float)):
        raise ValidationException("Temperature must be a number.")

    if not 0.0 <= temperature <= 2.0:
        raise ValidationException("Temperature must be between 0.0 and 2.0.")


def validate_max_output_tokens(max_output_tokens: int):
    """Validate that max_output_tokens is a positive integer.

    Args:
        max_output_tokens (int): The token limit to validate.

    Raises:
        ValidationException: If max_output_tokens is not an int or is less than 1.
    """
    if not isinstance(max_output_tokens, int):
        raise ValidationException("Max output tokens must be a number.")

    if max_output_tokens < 1:
        raise ValidationException("Max output tokens must be at least 1.")


def validate_max_messages(max_messages: int):
    """Validate that max_messages is a positive integer.

    Args:
        max_messages (int): The message limit to validate.

    Raises:
        ValidationException: If max_messages is not an int or is less than 1.
    """
    if not isinstance(max_messages, int):
        raise ValidationException("Max messages must be an integer.")
    if max_messages < 1:
        raise ValidationException("Max messages must be at least 1.")


def validate_prompt(prompt: str):
    """Validate that prompt is a non-empty string.

    Args:
        prompt (str): The system prompt to validate.

    Raises:
        ValidationException: If prompt is not a non-empty string.
    """
    if not isinstance(prompt, str) or not prompt.strip():
        raise ValidationException("Prompt must be a non-empty string.")


def validate_message(message: str):
    """Validate that message is a non-empty string.

    Args:
        message (str): The user message to validate.

    Raises:
        ValidationException: If message is not a non-empty string.
    """
    if not isinstance(message, str) or not message.strip():
        raise ValidationException("Message must be a non-empty string.")


def validate_filepath(filepath: str):
    """Validate that filepath is a non-empty, syntactically valid path string.

    Args:
        filepath (str): The file path to validate.

    Raises:
        ValidationException: If filepath is empty, not a string, or not parseable
            as a Path.
    """
    if not isinstance(filepath, str) or not filepath.strip():
        raise ValidationException("Filepath must be a non-empty string.")
    try:
        Path(filepath)
    except Exception:
        raise ValidationException(f"Invalid filepath: {filepath}")


def validate_language(language: str):
    """Validate that language is a non-empty string.

    Args:
        language (str): The language name to validate (e.g. 'English', 'Turkish').

    Raises:
        ValidationException: If language is not a non-empty string.
    """
    if not isinstance(language, str) or not language.strip():
        raise ValidationException("Language must be a non-empty string.")
