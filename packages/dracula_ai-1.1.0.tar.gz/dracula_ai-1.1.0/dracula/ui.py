import sys
from pathlib import Path
from PyQt6.QtWidgets import (
    QApplication,
    QMainWindow,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QTextEdit,
    QLineEdit,
    QPushButton,
    QLabel,
    QFileDialog,  # Added for file selection
)

from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtGui import QFont
from .client import Dracula

# ============================================================
# WORKER THREAD — Updated to support file_path
# ============================================================


class Worker(QThread):
    response_ready = pyqtSignal(str)
    error_occurred = pyqtSignal(str)

    def __init__(self, ai: Dracula, message: str, file_path: str = None):
        super().__init__()
        self.ai = ai
        self.message = message
        self.file_path = file_path  # Store the file path

    def run(self):
        try:
            # Pass the file_path to the new multimodal chat method
            response = self.ai.chat(self.message, filepath=self.file_path)
            self.response_ready.emit(response)
        except Exception as e:
            self.error_occurred.emit(str(e))


# ============================================================
# THEMES (No changes needed here)
# ============================================================

DARK_THEME = {
    "window_bg": "#1e1e2e",
    "chat_bg": "#181825",
    "user_bubble": "#89b4fa",
    "user_text": "#1e1e2e",
    "ai_bubble": "#313244",
    "ai_text": "#cdd6f4",
    "input_bg": "#313244",
    "input_text": "#cdd6f4",
    "button_bg": "#89b4fa",
    "button_text": "#1e1e2e",
    "button_hover": "#74c7ec",
    "title_text": "#cdd6f4",
    "subtitle_text": "#6c7086",
    "attachment_btn": "#fab387",  # Warm color for attachment
}

LIGHT_THEME = {
    "window_bg": "#eff1f5",
    "chat_bg": "#ffffff",
    "user_bubble": "#1e66f5",
    "user_text": "#ffffff",
    "ai_bubble": "#e6e9ef",
    "ai_text": "#4c4f69",
    "input_bg": "#ffffff",
    "input_text": "#4c4f69",
    "button_bg": "#1e66f5",
    "button_text": "#ffffff",
    "button_hover": "#04a5e5",
    "title_text": "#4c4f69",
    "subtitle_text": "#9ca0b0",
    "attachment_btn": "#fe640b",
}

# ============================================================
# MAIN CHAT WINDOW
# ============================================================


class DraculaChatUI(QMainWindow):
    def __init__(
        self,
        ai: Dracula,
        title: str = "Dracula AI Chat",
        subtitle: str = "Powered by Dracula & Google Gemini",
        theme: str = "dark",
    ):
        super().__init__()
        self.ai = ai
        self.theme = DARK_THEME if theme == "dark" else LIGHT_THEME
        self.title = title
        self.subtitle = subtitle
        self.selected_file_path = None  # State for selected file

        self._setup_window()
        self._setup_ui()
        self._apply_theme()

    def _setup_window(self):
        self.setWindowTitle(self.title)
        self.setMinimumSize(600, 700)
        self.resize(700, 800)

    def _setup_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)
        layout.setSpacing(0)
        layout.setContentsMargins(0, 0, 0, 0)

        # Header
        header = QWidget()
        header_layout = QVBoxLayout(header)
        header_layout.setContentsMargins(20, 15, 20, 15)

        self.title_label = QLabel(self.title)
        self.title_label.setFont(QFont("Segoe UI", 16, QFont.Weight.Bold))

        self.subtitle_label = QLabel(self.subtitle)
        self.subtitle_label.setFont(QFont("Segoe UI", 10))

        header_layout.addWidget(self.title_label)
        header_layout.addWidget(self.subtitle_label)
        layout.addWidget(header)

        # Chat display
        self.chat_display = QTextEdit()
        self.chat_display.setReadOnly(True)
        self.chat_display.setFont(QFont("Segoe UI", 11))
        layout.addWidget(self.chat_display, stretch=1)

        self.file_label = QLabel("")
        self.file_label.setFont(QFont("Segoe UI", 9))
        self.file_label.setCursor(Qt.CursorShape.PointingHandCursor)
        self.file_label.setVisible(False)
        self.file_label.mousePressEvent = lambda e: self._clear_attachment()
        layout.addWidget(self.file_label)

        # Input area
        input_widget = QWidget()
        input_layout = QHBoxLayout(input_widget)
        input_layout.setContentsMargins(15, 10, 15, 15)
        input_layout.setSpacing(10)

        # Attachment button
        self.attach_button = QPushButton("📎")
        self.attach_button.setFixedSize(45, 45)
        self.attach_button.setFont(QFont("Segoe UI", 14))
        self.attach_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.attach_button.clicked.connect(self._select_file)

        self.input_field = QLineEdit()
        self.input_field.setPlaceholderText("Type a message or drop a file...")
        self.input_field.setFont(QFont("Segoe UI", 11))
        self.input_field.returnPressed.connect(self._send_message)

        self.send_button = QPushButton("Send")
        self.send_button.setFixedSize(90, 45)
        self.send_button.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
        self.send_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.send_button.clicked.connect(self._send_message)

        input_layout.addWidget(self.attach_button)  # Add attach button
        input_layout.addWidget(self.input_field)
        input_layout.addWidget(self.send_button)
        layout.addWidget(input_widget)

    def _apply_theme(self):
        t = self.theme
        self.setStyleSheet(f"background-color: {t['window_bg']};")
        self.title_label.setStyleSheet(f"color: {t['title_text']};")
        self.subtitle_label.setStyleSheet(f"color: {t['subtitle_text']};")
        self.file_label.setStyleSheet(
            f"color: {t['attachment_btn']}; padding-left: 20px;"
        )

        self.chat_display.setStyleSheet(
            f"QTextEdit {{ background-color: {t['chat_bg']}; border: none; padding: 10px; color: {t['ai_text']}; }}"
        )

        self.input_field.setStyleSheet(
            f"QLineEdit {{ background-color: {t['input_bg']}; color: {t['input_text']}; border: 2px solid {t['ai_bubble']}; border-radius: 22px; padding: 0 15px; }}"
            f"QLineEdit:focus {{ border: 2px solid {t['button_bg']}; }}"
        )

        self.send_button.setStyleSheet(
            f"QPushButton {{ background-color: {t['button_bg']}; color: {t['button_text']}; border: none; border-radius: 22px; }}"
            f"QPushButton:hover {{ background-color: {t['button_hover']}; }}"
            f"QPushButton:disabled {{ background-color: {t['ai_bubble']}; color: {t['subtitle_text']}; }}"
        )

        # Style for the new attachment button
        self.attach_button.setStyleSheet(
            f"QPushButton {{ background-color: {t['ai_bubble']}; color: {t['title_text']}; border-radius: 22px; border: none; }}"
            f"QPushButton:hover {{ background-color: {t['attachment_btn']}; color: {t['window_bg']}; }}"
        )

    def _select_file(self):
        """Open a file dialog to select an image, pdf, or document."""
        file_filter = "All Files (*);;Images (*.png *.jpg *.jpeg *.webp);;PDFs (*.pdf)"
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Select File to Attach", "", file_filter
        )

        if file_path:
            self.selected_file_path = file_path
            self.file_label.setText(
                f"📎 Attached: {Path(file_path).name} (Click to clear)"
            )
            self.file_label.setVisible(True)
            self.input_field.setFocus()

    def _clear_attachment(self):
        """Reset the selected file."""
        self.selected_file_path = None
        self.file_label.setVisible(False)
        self.file_label.setText("")

    def _send_message(self):
        message = self.input_field.text().strip()

        # Allow sending if there's a message OR a file
        if not message and not self.selected_file_path:
            return

        # If no message but file exists, provide a default text
        if not message and self.selected_file_path:
            message = "Analyze this file."

        self.input_field.clear()
        self.send_button.setEnabled(False)
        self.input_field.setEnabled(False)
        self.attach_button.setEnabled(False)

        # Show attachment in the user bubble
        display_text = message
        if self.selected_file_path:
            display_text += f"\n\n<i>📎 {Path(self.selected_file_path).name}</i>"

        self._add_message("You", display_text, is_user=True)
        self._add_message("Gemini", "Thinking...", is_user=False)

        # Start background worker with file_path
        self.worker = Worker(self.ai, message, self.selected_file_path)
        self.worker.response_ready.connect(self._on_response)
        self.worker.error_occurred.connect(self._on_error)
        self.worker.start()

        # Clear attachment for the next message
        self._clear_attachment()

    def _on_response(self, response: str):
        self._replace_last_message("Gemini", response, is_user=False)
        self.send_button.setEnabled(True)
        self.input_field.setEnabled(True)
        self.attach_button.setEnabled(True)
        self.input_field.setFocus()

    def _on_error(self, error: str):
        self._replace_last_message("Gemini", f"❌ Error: {error}", is_user=False)
        self.send_button.setEnabled(True)
        self.input_field.setEnabled(True)
        self.attach_button.setEnabled(True)

    def _add_message(self, sender: str, message: str, is_user: bool):
        import markdown

        t = self.theme
        bubble_color = t["user_bubble"] if is_user else t["ai_bubble"]
        text_color = t["user_text"] if is_user else t["ai_text"]
        align = "right" if is_user else "left"
        emoji = "👤" if is_user else "🤖"

        if not is_user:
            formatted_message = markdown.markdown(
                message, extensions=["fenced_code", "codehilite", "tables"]
            )
        else:
            # User messages use simple text but we handle manual HTML for attachments
            formatted_message = message.replace("\n", "<br>")

        html = f"""
        <div style="text-align: {align}; margin: 8px 5px;">
            <span style="
                display: inline-block;
                background-color: {bubble_color};
                color: {text_color};
                padding: 10px 15px;
                border-radius: 18px;
                max-width: 75%;
                font-size: 13px;
                line-height: 1.5;
            ">
                <b>{emoji} {sender}</b><br>{formatted_message}
            </span>
        </div>
        """
        self.chat_display.append(html)
        self.chat_display.verticalScrollBar().setValue(
            self.chat_display.verticalScrollBar().maximum()
        )

    def _replace_last_message(self, sender: str, message: str, is_user: bool):
        cursor = self.chat_display.textCursor()
        cursor.movePosition(cursor.MoveOperation.End)
        self.chat_display.setTextCursor(cursor)

        content = self.chat_display.toHtml()
        last_idx = content.rfind("Thinking...")
        if last_idx != -1:
            self.chat_display.clear()
            clean = content[:last_idx].rsplit("<div", 1)[0]
            self.chat_display.setHtml(clean)

        self._add_message(sender, message, is_user)


# ============================================================
# LAUNCH FUNCTION
# ============================================================


def launch(
    ai: Dracula,
    title: str = "Dracula AI Chat 🧛",
    subtitle: str = "Powered by Dracula & Google Gemini",
    theme: str = "dark",
):
    app = QApplication(sys.argv)
    window = DraculaChatUI(ai=ai, title=title, subtitle=subtitle, theme=theme)
    window.show()
    sys.exit(app.exec())
