from enum import Enum


class OpenAIModel(Enum):
    """
    Available OpenAI models.

    Attributes:
        GPT_4O: GPT-4o — flagship multimodal model, fast and highly capable.
        GPT_4O_MINI: GPT-4o Mini — lightweight and cost-efficient version of GPT-4o.
        GPT_4_1: GPT-4.1 — improved reasoning and instruction following.
        GPT_4_1_MINI: GPT-4.1 Mini — smaller, faster version of GPT-4.1.
        GPT_4_1_NANO: GPT-4.1 Nano — smallest and fastest GPT-4.1 variant.
        O3: o3 — advanced reasoning model for complex tasks.
        O4_MINI: o4-mini — efficient reasoning model with strong performance.

    Example:
        >>> from dracula import Dracula
        >>> from dracula.adapters import OpenAIAdapter
        >>> from dracula.models import OpenAIModel
        >>> ai = Dracula(adapter=OpenAIAdapter(api_key="sk-...", model=OpenAIModel.GPT_4O))
    """

    GPT_4O = "gpt-4o"
    GPT_4O_MINI = "gpt-4o-mini"
    GPT_4_1 = "gpt-4.1"
    GPT_4_1_MINI = "gpt-4.1-mini"
    GPT_4_1_NANO = "gpt-4.1-nano"
    O3 = "o3"
    O4_MINI = "o4-mini"


class AnthropicModel(Enum):
    """
    Available Anthropic Claude models.

    Attributes:
        OPUS_4: Claude Opus 4.6 — most powerful model, best for complex tasks.
        SONNET_4: Claude Sonnet 4.6 — balanced performance and speed.
        HAIKU_4: Claude Haiku 4.5 — fastest and most compact model.

    Example:
        >>> from dracula import Dracula
        >>> from dracula.adapters import AnthropicAdapter
        >>> from dracula.models import AnthropicModel
        >>> ai = Dracula(adapter=AnthropicAdapter(api_key="sk-ant-...", model=AnthropicModel.SONNET_4))
    """

    OPUS_4 = "claude-opus-4-6"
    SONNET_4 = "claude-sonnet-4-6"
    HAIKU_4 = "claude-haiku-4-5-20251001"


class GeminiModel(Enum):
    """
    Available Google Gemini models.

    Attributes:
        FLASH: Gemini 2.5 Flash — fast and efficient, great for most use cases.
        FLASH_LITE: Gemini 2.5 Flash Lite — lightweight and fastest model.
        PRO: Gemini 2.5 Pro — most powerful model, best for complex tasks.
        FLASH_2: Gemini 2.0 Flash — previous generation Flash model.
        FLASH_2_LITE: Gemini 2.0 Flash Lite — previous generation lite model.
        FLASH_3: Gemini 3 Flash — latest experimental Flash model.
        PRO_3: Gemini 3 Pro — latest experimental Pro model.
        FLASH_LATEST: Always points to the latest Flash model.
        PRO_LATEST: Always points to the latest Pro model.

    Example:
        >>> from dracula import Dracula, GeminiModel
        >>> ai = Dracula(api_key="your-api-key", model=GeminiModel.FLASH)
    """

    # Gemini 2.5
    FLASH = "gemini-2.5-flash"
    FLASH_LITE = "gemini-2.5-flash-lite"
    PRO = "gemini-2.5-pro"

    # Gemini 2.0
    FLASH_2 = "gemini-2.0-flash"
    FLASH_2_LITE = "gemini-2.0-flash-lite"

    # Gemini 3 (not yet available — included for forward compatibility)
    FLASH_3 = "gemini-3-flash-preview"
    PRO_3 = "gemini-3-pro-preview"

    # Always latest
    FLASH_LATEST = "gemini-flash-latest"
    FLASH_LITE_LATEST = "gemini-flash-lite-latest"
    PRO_LATEST = "gemini-pro-latest"
