from .client import Dracula
from .async_client import AsyncDracula
from .tools import Tool, ToolResult, ToolRegistry, tool
from .retry import retry, async_retry
from .stats import Stats
from .models import GeminiModel, OpenAIModel, AnthropicModel
from ._version import __version__
from .adapters import (
    BaseAdapter,
    AsyncBaseAdapter,
    AdapterResponse,
    GeminiAdapter,
    AsyncGeminiAdapter,
    OpenAIAdapter,
    AsyncOpenAIAdapter,
    AnthropicAdapter,
    AsyncAnthropicAdapter,
)

try:
    from .ui import launch, DraculaChatUI
except ImportError:

    def launch(*args, **kwargs):
        raise ImportError(
            "UI components are not installed. "
            "Please install them using: pip install dracula-ai[ui]"
        )

    DraculaChatUI = None
from .logger import (
    get_logger,
    enable_logging,
    disable_logging,
    enable_file_logging,
    disable_file_logging,
)
from .exceptions import (
    DraculaException,
    InvalidAPIKeyException,
    ChatException,
    ValidationException,
    PersonaException,
    ToolException,
    BudgetExceededException,
)
from .cache import Cache, AsyncCache
from .pricing import estimate_cost

__author__ = "Suleyman Ibis"

__all__ = [
    "Dracula",
    "AsyncDracula",
    "Stats",
    "GeminiModel",
    "OpenAIModel",
    "AnthropicModel",
    "Tool",
    "ToolResult",
    "ToolRegistry",
    "tool",
    "DraculaChatUI",
    "launch",
    "get_logger",
    "enable_logging",
    "disable_logging",
    "enable_file_logging",
    "disable_file_logging",
    "DraculaException",
    "InvalidAPIKeyException",
    "ChatException",
    "ValidationException",
    "PersonaException",
    "ToolException",
    "BudgetExceededException",
    "Cache",
    "AsyncCache",
    "estimate_cost",
    "retry",
    "async_retry",
    # Adapter pattern
    "BaseAdapter",
    "AsyncBaseAdapter",
    "AdapterResponse",
    "GeminiAdapter",
    "AsyncGeminiAdapter",
    "OpenAIAdapter",
    "AsyncOpenAIAdapter",
    "AnthropicAdapter",
    "AsyncAnthropicAdapter",
]
