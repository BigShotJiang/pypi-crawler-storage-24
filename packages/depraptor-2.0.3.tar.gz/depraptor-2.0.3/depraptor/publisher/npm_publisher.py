"""
npm publisher.
Publishes a Node.js PoC package using the npm CLI.
"""

from __future__ import annotations

import logging
import os
import shutil
import subprocess
from pathlib import Path

logger = logging.getLogger(__name__)


def _npm() -> str:
    """Return the resolved npm executable (handles npm.cmd on Windows)."""
    cmd = shutil.which("npm")
    if not cmd:
        raise FileNotFoundError(
            "npm not found on PATH. Install Node.js to publish npm packages."
        )
    return cmd


def publish(poc_dir: Path, token: str, simulate: bool = False) -> bool:
    """
    Publish a Node.js PoC package to the npm registry.

    Args:
        poc_dir:  Path to the PoC package directory (must contain package.json).
        token:    npm access token.
        simulate: If True, run 'npm pack' only (no publish).

    Returns:
        True on success, False on failure.
    """
    if not (poc_dir / "package.json").exists():
        logger.error(f"No package.json found in {poc_dir}")
        return False

    try:
        npm = _npm()
    except FileNotFoundError as exc:
        logger.error(str(exc))
        return False

    if simulate:
        logger.info(f"[SIMULATE] npm pack {poc_dir.name}")
        try:
            result = subprocess.run([npm, "pack"], cwd=poc_dir, capture_output=True, text=True)
            logger.info(result.stdout)
            return result.returncode == 0
        except Exception as exc:
            logger.error(f"npm pack error: {exc}")
            return False

    logger.info(f"Publishing {poc_dir.name} to npm …")
    env = {**os.environ, "NPM_TOKEN": token}
    try:
        result = subprocess.run(
            [npm, "publish", "--access", "public"],
            cwd=poc_dir,
            capture_output=True,
            text=True,
            env=env,
        )
    except Exception as exc:
        logger.error(f"npm publish error: {exc}")
        return False

    if result.returncode != 0:
        logger.error(f"npm publish failed:\n{result.stderr}")
        return False

    logger.info(f"Successfully published {poc_dir.name} to npm.")
    return True
