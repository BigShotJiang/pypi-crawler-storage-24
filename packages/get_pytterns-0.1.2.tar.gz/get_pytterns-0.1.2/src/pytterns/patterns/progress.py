import time as t
def draw(size, time,center, update_time=1, title=None, title_center=True, 
         char="█",start_char="[", end_char="]", filler=" ",**kwargs):
    
#title.center(size)    
    string=start_char + char * time + filler * (size -len(start_char+char*time+end_char)) + end_char
    print(string)
    
    
    
    
    