from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

from ..config import settings
from ..errors import CliError
from ..utilities import read_json, write_json_secure
from .api import _validate_token
DEFAULT_CREDS: Dict[str, Any] = {"version": 1, "current_profile": "default", "profiles": {}}
try:
    import keyring  # optional
except Exception:  # pragma: no cover
    keyring = None  # type: ignore


APP_NAME = "aiel"
KEYRING_SERVICE = "aiel"


def _current_profile(data: Dict[str, Any]) -> str:
    return data.get("current_profile") or "default"


def _get_profile(data: Dict[str, Any], name: str) -> Dict[str, Any]:
    return (data.get("profiles") or {}).get(name) or {}


def _config_dir() -> Path:
    if os.name == "nt":
        from pathlib import Path as _Path
        base = _Path(os.environ.get("APPDATA", str(_Path.home())))
        return base / APP_NAME
    return Path.home() / ".config" / APP_NAME


CREDENTIALS_PATH = _config_dir() / "credentials.json"


@dataclass(frozen=True)
class Profile:
    name: str
    base_url: str
    token: str
    token_source: str  # env | keyring | file


@dataclass(frozen=True)
class WorkspaceRef:
    id: str
    slug: str
    name: str | None = None


@dataclass(frozen=True)
class ProjectRef:
    id: str
    slug: str
    name: str | None = None


def _keyring_set(profile: str, token: str) -> Tuple[bool, str]:
    if keyring is None:
        return False, "keyring-unavailable"
    try:
        keyring.set_password(KEYRING_SERVICE, profile, token)
        return True, "keyring"
    except Exception:
        return False, "keyring-unavailable"


def _keyring_get(profile: str) -> Optional[str]:
    if keyring is None:
        return None
    try:
        return keyring.get_password(KEYRING_SERVICE, profile)
    except Exception:
        return None


def _keyring_del(profile: str) -> bool:
    if keyring is None:
        return False
    try:
        keyring.delete_password(KEYRING_SERVICE, profile)
        return True
    except Exception:
        return False


def resolve_token() -> Optional[Tuple[str, str]]:
    """Returns (token, source) or None. Source: env | keyring | file"""
    env = os.environ.get("AIEL_TOKEN")
    if env:
        return env, "env"

    data = read_json(CREDENTIALS_PATH,DEFAULT_CREDS )
    current = _current_profile(data)
    prof = _get_profile(data, current)
    if not prof:
        return None

    token_ref = prof.get("token_ref")
    if isinstance(token_ref, str) and token_ref.startswith("keyring:"):
        token = _keyring_get(current)
        if token:
            return token, "keyring"

    token = prof.get("token")
    if isinstance(token, str) and token:
        return token, "file"

    return None


def get_current_base_url(default: str = settings.BASE_URL) -> str:
    data = read_json(CREDENTIALS_PATH, DEFAULT_CREDS)
    current = _current_profile(data)
    prof = _get_profile(data, current)
    return (prof or {}).get("base_url") or default


def save_profile(
    profile: str,
    base_url: str,
    token: str,
    email: str,
    tenant: str,
    tenant_id: str | None = None,
    user_id: str | None = None,
) -> str:
    data = read_json(CREDENTIALS_PATH, DEFAULT_CREDS)
    data.setdefault("profiles", {})

    ok, token_source = _keyring_set(profile, token)
    if ok:
        data["profiles"][profile] = {
            "base_url": base_url,
            "token_ref": f"keyring:{APP_NAME}:{profile}",
            "user": email,
            "tenant": tenant,
            "tenant_id": tenant_id,
            "user_id": user_id
        }
    else:
        data["profiles"][profile] = {
            "base_url": base_url,
            "token": token,
            "user": email,
            "tenant": tenant,
            "tenant_id": tenant_id,
            "user_id": user_id
        }

    data["current_profile"] = profile
    write_json_secure(CREDENTIALS_PATH, data)
    return token_source


def delete_profile(profile: str) -> None:
    data = read_json(CREDENTIALS_PATH, DEFAULT_CREDS)
    profiles = data.get("profiles") or {}
    profiles.pop(profile, None)
    data["profiles"] = profiles

    if data.get("current_profile") == profile:
        data["current_profile"] = "default"

    write_json_secure(CREDENTIALS_PATH, data)
    _keyring_del(profile)


def list_profiles() -> Dict[str, Any]:
    return read_json(CREDENTIALS_PATH, DEFAULT_CREDS)


def get_current_context() -> Dict[str, Any]:
    data = read_json(CREDENTIALS_PATH, DEFAULT_CREDS)
    current = _current_profile(data)
    prof = _get_profile(data, current) or {}
    return {
        "profile": current,
        "base_url": prof.get("base_url"),
        "user": prof.get("user"),
        "tenant": prof.get("tenant"),
        "workspace": prof.get("workspace"),
        "project": prof.get("project"),
    }


def set_workspace(workspace: Dict[str, Any]) -> None:
    # minimal validation
    if not workspace.get("id") or not workspace.get("slug"):
        raise CliError("Workspace must include 'id' and 'slug'.")

    data = read_json(CREDENTIALS_PATH, DEFAULT_CREDS)
    current = _current_profile(data)
    data.setdefault("profiles", {})
    prof = data["profiles"].setdefault(current, {})
    prof["workspace"] = workspace
    write_json_secure(CREDENTIALS_PATH, data)


def set_project(project: Dict[str, Any]) -> None:
    if not project.get("id") or not project.get("slug"):
        raise CliError("Project must include 'id' and 'slug'.")

    data = read_json(CREDENTIALS_PATH,DEFAULT_CREDS )
    current = _current_profile(data)
    data.setdefault("profiles", {})
    prof = data["profiles"].setdefault(current, {})
    prof["project"] = project
    write_json_secure(CREDENTIALS_PATH, data)


def _get_me(profile: Dict[str, Any]) -> Dict[str, Any]:
    base_url = profile.get("base_url")
    if not base_url:
        raise CliError(
            "Missing base_url in credentials profile.",
            hint="Run `aiel auth login` to create or select a profile.",
        )

    resolved = resolve_token()
    token = resolved[0] if resolved else None
    if not token:
        raise CliError(
            "Missing credentials for the active profile.",
            hint="Run `aiel auth login` or set AIEL_TOKEN.",
        )

    return _validate_token(base_url, token)
