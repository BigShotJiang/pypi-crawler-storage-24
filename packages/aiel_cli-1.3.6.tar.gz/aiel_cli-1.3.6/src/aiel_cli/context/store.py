from __future__ import annotations

from typing import Any, Dict, Optional
from aiel_cli.auth.credentials import read_json, CREDENTIALS_PATH, write_json_secure, _current_profile, _get_profile
DEFAULT_CREDS: Dict[str, Any] = {"version": 1, "current_profile": "default", "profiles": {}}

# Uses your existing globals/helpers:
# - CREDENTIALS_PATH
# - read_json
# - write_json_secure
# - _current_profile
# - _get_profile

def _validate_ref(ref: Dict[str, Any], kind: str) -> None:
    """Minimal schema guard: require id + slug; name optional."""
    if not isinstance(ref, dict):
        raise ValueError(f"{kind} must be a dict")
    if not ref.get("id") or not ref.get("slug"):
        raise ValueError(f"{kind} must include 'id' and 'slug'")

def _load_credentials() -> Dict[str, Any]:
    data = read_json(CREDENTIALS_PATH, DEFAULT_CREDS)
    data.setdefault("version", 1)
    data.setdefault("current_profile", "default")
    data.setdefault("profiles", {})
    return data

def _save_credentials(data: Dict[str, Any]) -> None:
    write_json_secure(CREDENTIALS_PATH, data)

def get_active_profile_name() -> str:
    data = _load_credentials()
    return _current_profile(data)

def get_active_profile() -> Dict[str, Any]:
    data = _load_credentials()
    current = _current_profile(data)
    prof = _get_profile(data, current)
    return prof

def update_active_profile(**patch: Any) -> None:
    """Patch fields on the current profile (shallow merge)."""
    data = _load_credentials()
    current = _current_profile(data)
    profiles = data.get("profiles") or {}
    prof = (profiles.get(current) or {}).copy()
    prof.update(patch)
    profiles[current] = prof
    data["profiles"] = profiles
    _save_credentials(data)

def set_workspace(profile: str, workspace: Dict[str, Any], *, clear_project: bool = True) -> None:
    """
    Persist workspace selection for a profile.
    If clear_project=True, also removes any existing project selection.
    """
    _validate_ref(workspace, "workspace")

    data = _load_credentials()
    profiles = data["profiles"]
    prof = (profiles.get(profile) or {}).copy()

    prof["workspace"] = {
        "id": workspace["id"],
        "slug": workspace["slug"],
        "name": workspace.get("name"),
    }
    if clear_project:
        prof.pop("project", None)

    profiles[profile] = prof
    data["profiles"] = profiles
    _save_credentials(data)

def set_project(profile: str, project: Dict[str, Any]) -> None:
    """Persist project selection for a profile. Requires workspace already set."""
    _validate_ref(project, "project")

    data = _load_credentials()
    profiles = data["profiles"]
    prof = (profiles.get(profile) or {}).copy()

    if not prof.get("workspace"):
        raise ValueError("Cannot set project before workspace. Set workspace first.")

    prof["project"] = {
        "id": project["id"],
        "slug": project["slug"],
        "name": project.get("name"),
    }

    profiles[profile] = prof
    data["profiles"] = profiles
    _save_credentials(data)

def clear_project(profile: str) -> None:
    data = _load_credentials()
    profiles = data["profiles"]
    prof = (profiles.get(profile) or {}).copy()
    prof.pop("project", None)
    profiles[profile] = prof
    data["profiles"] = profiles
    _save_credentials(data)

def clear_context(profile: str) -> None:
    """Remove workspace + project from a profile."""
    data = _load_credentials()
    profiles = data["profiles"]
    prof = (profiles.get(profile) or {}).copy()
    prof.pop("workspace", None)
    prof.pop("project", None)
    profiles[profile] = prof
    data["profiles"] = profiles
    _save_credentials(data)

def get_context(profile: Optional[str] = None) -> Dict[str, Any]:
    """Return context info for a profile (defaults to active profile)."""
    data = _load_credentials()
    if profile is None:
        profile = _current_profile(data)
    prof = _get_profile(data, profile) or {}
    return {
        "profile": profile,
        "base_url": prof.get("base_url"),
        "user": prof.get("user"),
        "tenant": prof.get("tenant"),
        "workspace": prof.get("workspace"),
        "project": prof.get("project"),
    }
