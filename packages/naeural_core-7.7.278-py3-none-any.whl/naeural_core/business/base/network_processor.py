"""


"""

from naeural_core.business.base import BasePluginExecutor as BaseClass
from naeural_core.business.mixins_libs.network_processor_mixin import _NetworkProcessorMixin, __VER__

_CONFIG = {
  **BaseClass.CONFIG,
  
  'ALLOW_EMPTY_INPUTS' : False,

  'MAX_INPUTS_QUEUE_SIZE' : 1024,

  "PROCESS_DELAY" : 0,  # seconds, how often to process the network
  "LOG_STATS_PERIOD": 5 * 60,  # seconds, how often to log how many messages were processed from each signature

  "NETWORK_ROUTE_BY_HANDLER": True,
  
  'VALIDATION_RULES' : {
    **BaseClass.CONFIG['VALIDATION_RULES'],
    'MAX_INPUTS_QUEUE_SIZE': {
      'DESCRIPTION': "Advanced setting: Controls the queue size of the plugin instance. In the case of NetworkProcessor plugins this queue should be allowed to be much larger due to the reduced size of the messages and the fast-paced nature of them.",
      'TYPE': 'int',
      'MIN_VAL': 1,
      'MAX_VAL': 4096,
    },
    'NETWORK_ROUTE_BY_HANDLER': {
      'DESCRIPTION': "When true, drop payloads that do not have a registered handler before verification/dispatch.",
      'TYPE': 'bool',
    },
  },  
}

class NetworkProcessorPlugin(
  BaseClass,
  _NetworkProcessorMixin
):
  CONFIG = _CONFIG

  def _on_init(self):
    self.network_processor_init()
    self.P(
      "NetworkProcessorPlugin v{} base initialization completed. Proceeding to custom init...".format(__VER__),
      color="green"
    )
    self.on_init()
    return


  def _process(self):
    """
    This method must be protected while the child plugins should have normal `process`
    """
    self.network_processor_loop()
    return self.process()
