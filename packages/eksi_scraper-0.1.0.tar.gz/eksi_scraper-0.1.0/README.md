# eksi-scraper

asynchronously scrapes eksisozluk threads in python, and puts entries in a csv or json file, named after the thread. intended for educational purposes only.

## installation

```
uv pip install eksi-scraper
```
or with pip:
```
pip install eksi-scraper
```

## usage

```
eksi-scraper -t [thread1] [thread2] ... -f [inputFile.txt] -o (csv or json)
```
you can pass full URLs or just the slug (the part of the url after '/' and before '?'). for example:

```
eksi-scraper -t https://eksisozluk.com/murat-kurum--2582131 https://eksisozluk.com/ekrem-imamoglu--2577439 -o json
```
or using slugs:
```
eksi-scraper -t murat-kurum--2582131 ekrem-imamoglu--2577439 -o json
```
or from a file:
```
eksi-scraper -f threads.txt -o csv
```

where in threads.txt, threads are listed as URLs or slugs, one per line:

```
https://eksisozluk.com/murat-kurum--2582131
ekrem-imamoglu--2577439
...
```

## contact

reach out to me at ceylaniberkay@gmail.com
