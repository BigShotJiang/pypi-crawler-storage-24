# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Setup

```bash
pip3 install -r requirements.txt
```

## Running the scraper

```bash
# Run from the src/ directory
cd src

# Scrape specific threads
python3 main.py -t murat-kurum--2582131 ekrem-imamoglu--2577439 -o json

# Scrape from a file (one thread slug per line)
python3 main.py -f threads.txt -o csv
```

Thread slugs are the URL path segment after `eksisozluk.com/` and before any `?` (e.g., `murat-kurum--2582131`).

Output files are written to the working directory where the script is run. Logs go to `eksisozluk_scraper.log`.

## Architecture

Three modules in `src/`:

- **`main.py`** — Entry point. Parses CLI args, creates one async task per thread, runs them concurrently via `asyncio.gather`. Uses `curl_cffi` with Chrome browser impersonation (`impersonate="chrome124"`) to bypass bot detection.

- **`eksisozluk_scraper.py`** — `EksiSozlukScraper` class. First fetches the thread's first page to read `data-pagecount` from the `.pager` div, then concurrently scrapes all pages using an `asyncio.Semaphore` (default: 15 concurrent requests). BeautifulSoup parsing is offloaded to a `ThreadPoolExecutor` to avoid blocking the event loop. Page requests retry with exponential backoff (up to 8 tries / 300s) via the `backoff` library.

- **`data_writer.py`** — `DataWriter` static class. Writes scraped entries (Content, Author, Date Created, Last Changed) to CSV or JSON using `aiofiles` for async I/O.

Each scraped entry dict has keys: `Content`, `Author`, `Date Created`, `Last Changed`.
