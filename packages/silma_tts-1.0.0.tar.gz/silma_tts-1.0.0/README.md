# silma-tts
SILMA TTS V1 Official Repo







## Setup

apt-get update && apt install ffmpeg -y