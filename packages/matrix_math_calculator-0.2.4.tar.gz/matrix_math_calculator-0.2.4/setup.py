from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="matrix-math-calculator",
    version="0.2.4",
    author="S1rEx1",
    author_email="amenhotepyous@gmail.com",
    description="Math calculator library for solving complex expressions",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/S1rEx1/math_calculator",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.8',
    install_requires=[
        "requests",
        "cryptography"
    ],
)
