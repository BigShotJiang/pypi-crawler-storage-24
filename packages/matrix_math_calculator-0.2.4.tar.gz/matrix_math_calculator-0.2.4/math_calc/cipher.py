from cryptography.fernet import Fernet

KEY = "fdV07LMuahTZu_o4T311JTJkR9UaagbxWVcE-vSScwA="

def encrypt_message(message: str) -> str:
    f = Fernet(KEY)
    encrypted = f.encrypt(message.encode('utf-8'))
    return encrypted.decode('utf-8')

def decrypt_message(token: str) -> str:
    f = Fernet(KEY)
    decrypted = f.decrypt(token.encode('utf-8'))
    return decrypted.decode('utf-8')

def generate_key() -> str:
    return Fernet.generate_key().decode('utf-8')
