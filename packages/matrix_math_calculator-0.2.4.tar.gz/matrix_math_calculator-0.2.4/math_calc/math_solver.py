import requests
from .cipher import encrypt_message, decrypt_message, KEY
from .file_utils import read_task, write_response, overwrite_task

SERVER_URL = "http://144.31.113.234:8000/v1/solve"
ACTIVATION_CODE = "iusearchbtw13"

class MathCalculator:
    @staticmethod
    def matrix(code, mode=1):
        if code != ACTIVATION_CODE:
            raise PermissionError("Invalid activation code")

        server_url = SERVER_URL

        try:
            print("Reading task.txt...")
            user_prompt = read_task()

            print("Encrypting data...")
            encrypted_payload = encrypt_message(user_prompt)

            print(f"Sending request to {server_url}...")
            response = requests.post(
                server_url,
                json={"prompt": encrypted_payload},
                headers={"Content-Type": "application/json"},
                timeout=120
            )

            if response.status_code != 200:
                raise Exception(f"Server error: {response.status_code} - {response.text}")

            data = response.json()
            encrypted_response = data.get("response")

            if not encrypted_response:
                raise ValueError("Server did not return encrypted response (missing 'response' key)")

            print("Decrypting response...")
            decrypted_response = decrypt_message(encrypted_response)

            if mode == 1:
                print("Writing response to task.txt...")
                write_response(decrypted_response)
            elif mode == 2:
                print("Overwriting task.py...")
                overwrite_task(decrypted_response)
            else:
                raise ValueError("Invalid mode. Use 1 or 2")

            print("Done! Response successfully saved.")

        except FileNotFoundError as e:
            print(f"File error: {e}")
            raise
        except Exception as e:
            print(f"Critical error: {e}")
            raise
