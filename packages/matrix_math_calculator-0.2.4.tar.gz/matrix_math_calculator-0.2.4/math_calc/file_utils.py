import os
from typing import List

FILE_NAME = "task.txt"
INSERT_LINE_INDEX = 50
RESPONSE_START_MARKER = "\n# === RESPONSE START ===\n"
RESPONSE_END_MARKER = "\n# === RESPONSE END ===\n"

def read_task() -> str:
    if not os.path.exists(FILE_NAME):
        raise FileNotFoundError(
            f"File {FILE_NAME} not found in current directory."
        )
    with open(FILE_NAME, "r", encoding="utf-8") as f:
        return f.read()

def write_response(response_text: str):
    if not os.path.exists(FILE_NAME):
        with open(FILE_NAME, "w", encoding="utf-8") as f:
            f.write(f"{RESPONSE_START_MARKER}{response_text}{RESPONSE_END_MARKER}")
        return

    with open(FILE_NAME, "r", encoding="utf-8") as f:
        lines = f.readlines()

    response_block = [
        RESPONSE_START_MARKER,
        response_text + "\n",
        RESPONSE_END_MARKER,
        "\n"
    ]

    if len(lines) > INSERT_LINE_INDEX:
        for i, line in enumerate(response_block):
            lines.insert(INSERT_LINE_INDEX + i, line)
    else:
        lines.extend(response_block)

    with open(FILE_NAME, "w", encoding="utf-8") as f:
        f.writelines(lines)

def overwrite_task(response_text: str):
    with open("task.py", "w", encoding="utf-8") as f:
        f.write(response_text)
