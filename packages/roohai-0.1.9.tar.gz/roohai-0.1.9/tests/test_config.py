"""Tests for the config loader."""

import pytest
from roohai.config import load_config


class TestConfig:
    def test_load_valid_config(self, sample_config):
        config = load_config(sample_config)
        assert "pipeline" in config
        assert config["pipeline"]["stt"] == "whisper-tiny"
        assert config["pipeline"]["tts"] == "piper"
        assert config["pipeline"]["llm"] == "bedrock-claude"
        assert "models" in config

    def test_load_missing_config_raises(self, tmp_path):
        with pytest.raises(FileNotFoundError):
            load_config(str(tmp_path / "nonexistent.yaml"))

    def test_config_has_audio_settings(self, sample_config):
        config = load_config(sample_config)
        assert config["audio"]["sample_rate"] == 16000
        assert config["audio"]["channels"] == 1

    def test_config_has_server_settings(self, sample_config):
        config = load_config(sample_config)
        assert config["server"]["port"] == 8000
