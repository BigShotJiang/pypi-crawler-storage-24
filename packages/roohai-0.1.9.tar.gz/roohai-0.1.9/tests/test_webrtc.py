"""Tests for WebRTC offer/answer exchange."""

from unittest.mock import MagicMock, AsyncMock, patch


class TestWebRTCEndpoint:
    async def test_offer_returns_answer(self):
        """create_offer_response should return session_id, sdp, and type."""
        mock_pc = MagicMock()
        mock_pc.createAnswer = AsyncMock()
        mock_pc.setRemoteDescription = AsyncMock()
        mock_pc.setLocalDescription = AsyncMock()
        mock_pc.localDescription = MagicMock(sdp="answer-sdp", type="answer")
        mock_pc.createDataChannel = MagicMock()

        with patch("server.webrtc.RTCPeerConnection", return_value=mock_pc):
            from server.webrtc import create_offer_response

            result = await create_offer_response("offer-sdp", "offer", MagicMock())

        assert "session_id" in result
        assert result["sdp"] == "answer-sdp"
        assert result["type"] == "answer"

    async def test_cleanup_all(self):
        """cleanup_all should close all peer connections."""
        mock_pc = MagicMock()
        mock_pc.close = AsyncMock()

        with patch("server.webrtc.peer_connections", {"sess1": mock_pc}):
            from server.webrtc import cleanup_all

            await cleanup_all()

        mock_pc.close.assert_called_once()
