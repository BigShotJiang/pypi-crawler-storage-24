"""Strands-backed LLM provider stubs for the model catalog.

These classes exist solely to provide META (display name, description,
config_fields) so the wizard UI can render cards and collect config.
Actual inference is handled by the Strands Agent hook — these classes
are never called directly at runtime.
"""

from __future__ import annotations

from roohai.base import LLMModel


class _StrandsLLMStub(LLMModel):
    """Base stub for Strands-backed providers. Not meant to be called directly."""

    def __init__(self, **kwargs) -> None:
        self._kwargs = kwargs

    def load(self) -> None:
        pass

    def unload(self) -> None:
        pass

    @property
    def is_loaded(self) -> bool:
        return True

    async def chat(self, message, history=None, system_prompt=None, session_id=None):
        raise RuntimeError("Strands LLM stub should not be called directly — use the Strands hook")


class OpenAILLM(_StrandsLLMStub):
    META = {
        "display_name": "OpenAI",
        "description": "GPT-4o, GPT-4o-mini and other OpenAI models via Strands SDK. Requires API key.",
        "kind": "cloud",
        "config_fields": [
            {
                "name": "api_key",
                "label": "OpenAI API Key",
                "type": "secret",
                "required": False,
                "env_var": "OPENAI_API_KEY",
            },
            {
                "name": "model_id",
                "label": "Model ID",
                "type": "text",
                "required": False,
                "default": "gpt-4o",
                "placeholder": "gpt-4o, gpt-4o-mini, gpt-4.1, etc.",
            },
            {
                "name": "base_url",
                "label": "Base URL (optional)",
                "type": "text",
                "required": False,
                "placeholder": "https://api.openai.com/v1",
            },
        ],
    }


class AnthropicLLM(_StrandsLLMStub):
    META = {
        "display_name": "Anthropic",
        "description": "Claude models via the Anthropic API (direct, not Bedrock). Requires API key.",
        "kind": "cloud",
        "config_fields": [
            {
                "name": "api_key",
                "label": "Anthropic API Key",
                "type": "secret",
                "required": False,
                "env_var": "ANTHROPIC_API_KEY",
            },
            {
                "name": "model_id",
                "label": "Model ID",
                "type": "text",
                "required": False,
                "default": "claude-sonnet-4-20250514",
                "placeholder": "claude-sonnet-4-20250514, claude-haiku-4-5-20251001, etc.",
            },
        ],
    }


class GeminiLLM(_StrandsLLMStub):
    META = {
        "display_name": "Google Gemini",
        "description": "Gemini Flash and Pro models via Google AI. Requires API key.",
        "kind": "cloud",
        "config_fields": [
            {
                "name": "api_key",
                "label": "Google API Key",
                "type": "secret",
                "required": False,
                "env_var": "GOOGLE_API_KEY",
            },
            {
                "name": "model_id",
                "label": "Model ID",
                "type": "text",
                "required": False,
                "default": "gemini-2.5-flash",
                "placeholder": "gemini-2.5-flash, gemini-2.5-pro, etc.",
            },
        ],
    }


class OllamaLLM(_StrandsLLMStub):
    META = {
        "display_name": "Ollama",
        "description": "Run any model locally via Ollama (Llama 3, Mistral, Qwen, etc.). No API key needed.",
        "kind": "local",
        "config_fields": [
            {
                "name": "model_id",
                "label": "Model Name",
                "type": "text",
                "required": False,
                "default": "llama3",
                "placeholder": "llama3, mistral, qwen2, etc.",
            },
            {
                "name": "host",
                "label": "Ollama Host",
                "type": "text",
                "required": False,
                "default": "http://localhost:11434",
            },
        ],
    }
