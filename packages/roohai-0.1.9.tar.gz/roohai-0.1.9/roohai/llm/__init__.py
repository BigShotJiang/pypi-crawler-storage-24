"""LLM model implementations."""

_all_classes = {}
_loaded = False


def _lazy_load():
    global _loaded
    if _loaded:
        return _all_classes
    _loaded = True

    try:
        from roohai.llm.bedrock import BedrockLLM
        _all_classes["BedrockLLM"] = BedrockLLM
    except ImportError:
        pass

    try:
        from roohai.llm.local import LocalLLM
        _all_classes["LocalLLM"] = LocalLLM
    except ImportError:
        pass

    try:
        from roohai.llm.strands_providers import OpenAILLM, AnthropicLLM, GeminiLLM, OllamaLLM
        _all_classes["OpenAILLM"] = OpenAILLM
        _all_classes["AnthropicLLM"] = AnthropicLLM
        _all_classes["GeminiLLM"] = GeminiLLM
        _all_classes["OllamaLLM"] = OllamaLLM
    except ImportError:
        pass

    try:
        from roohai.llm.strands_hook import (
            strands_hook,
            clear_session,
            clear_all_sessions,
            configure as configure_strands,
        )
        _all_classes["strands_hook"] = strands_hook
        _all_classes["clear_session"] = clear_session
        _all_classes["clear_all_sessions"] = clear_all_sessions
        _all_classes["configure_strands"] = configure_strands
    except ImportError:
        pass

    return _all_classes


def __getattr__(name):
    classes = _lazy_load()
    if name in classes:
        return classes[name]
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "BedrockLLM",
    "LocalLLM",
    "OpenAILLM",
    "AnthropicLLM",
    "GeminiLLM",
    "OllamaLLM",
    "strands_hook",
    "clear_session",
    "clear_all_sessions",
    "configure_strands",
]
