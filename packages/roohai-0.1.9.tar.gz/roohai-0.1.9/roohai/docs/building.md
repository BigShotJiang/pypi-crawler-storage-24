# Building & Publishing

How to build, test, and publish the RoohAI library. This guide is for contributors and maintainers.

## Prerequisites

```bash
conda activate roohai
pip install build twine
```

## Build

```bash
python -m build
```

This creates two files in `dist/`:
- `roohai-<version>-py3-none-any.whl` — wheel (pip install target)
- `roohai-<version>.tar.gz` — source distribution

## Test Locally

```bash
# Create a fresh env
conda create -n roohai-test python=3.11 -y
conda activate roohai-test

# Install from the built wheel
pip install dist/roohai-*.whl

# Verify imports work
python -c "
from roohai.pipeline import Rooh, register_all_models
from roohai.registry import registry
from roohai.base import STTModel, TTSModel, LLMModel, VADModel
from roohai.agents import list_agents
print('All imports OK')
register_all_models()
print('STT:', registry.list_stt())
print('TTS:', registry.list_tts())
print('LLM:', registry.list_llm())
print('VAD:', registry.list_vad())
"

# Start the server
roohai

# Clean up
conda deactivate
conda env remove -n roohai-test
```

## Optional Dependencies

All STT, TTS, and LLM providers are included in the base install. The only optional extra is for NVIDIA models:

```bash
pip install "roohai[nvidia]"    # NeMo toolkit (requires CUDA GPU)
```

## Editable Install (Development)

For active development where you want changes reflected immediately:

```bash
pip install -e ".[all]"
```

## Version Bump

Update the version in `pyproject.toml`:

```toml
[project]
version = "0.2.0"
```

Then rebuild:

```bash
rm -rf dist/
python -m build
```

## Publish to PyPI

```bash
# Test PyPI first
twine upload --repository testpypi dist/*

# Install from Test PyPI to verify
pip install --index-url https://test.pypi.org/simple/ roohai

# Production PyPI
twine upload dist/*
```

## Publish to Private Registry (CodeArtifact, etc.)

```bash
# AWS CodeArtifact
aws codeartifact login --tool twine --domain myorg --repository myrepo
twine upload --repository codeartifact dist/*

# Install from CodeArtifact
aws codeartifact login --tool pip --domain myorg --repository myrepo
pip install roohai
```

## Data Directories

The library stores runtime data outside the package:

| Data | Location | Override |
|------|----------|---------|
| Agent configs | `~/.roohai/agents/` | `ROOHAI_DATA_DIR` |
| Secrets | `~/.roohai/secrets.yaml` | `ROOHAI_DATA_DIR` |

```bash
# Default (local dev)
~/.roohai/
    agents/*.yaml
    secrets.yaml

# EC2 / production
export ROOHAI_DATA_DIR=/opt/roohai/data
```

## Secrets in Production

Don't use the local secrets file in production. Options:

```bash
# Option 1: Environment variables
export ROOHAI_SECRET_MYAGENT_DEEPGRAM_APIKEY=dg-xxx

# Option 2: AWS Secrets Manager
export ROOHAI_SECRETS_ARN=arn:aws:secretsmanager:us-east-1:123456:secret:roohai/prod

# Option 3: IAM roles for Bedrock (no keys needed)
# Just attach the bedrock policy to the EC2 instance role
```

Priority: env vars > Secrets Manager > local file.
