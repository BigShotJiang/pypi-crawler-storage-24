# Models Reference

Every model in RoohAI is a subclass of one of the four base types and exposes a `META` dictionary describing its capabilities, dependencies, and configurable fields.

---

## Speech-to-Text (STT)

### Whisper

| Property | Value |
|----------|-------|
| Class | `WhisperSTT` |
| Registry name | `whisper` |
| Kind | Local |
| Dependencies | `transformers>=4.46.0,<5.0.0`, `torch`, `sentencepiece` |
| Download size | ~150 MB |
| Streaming | No |

OpenAI's open-source speech recognition model. Accurate across many languages, runs entirely locally.

**Configuration:**

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `model_id` | text | `openai/whisper-tiny` | HuggingFace model ID. Options: `openai/whisper-tiny`, `openai/whisper-base`, `openai/whisper-small` |
| `language` | text | `en` | Language code |

**Example config:**

```yaml
whisper-tiny:
  type: stt
  class: whisper
  model_id: openai/whisper-tiny
  language: en
```

---

### Wav2Vec2

| Property | Value |
|----------|-------|
| Class | `Wav2Vec2STT` |
| Registry name | `wav2vec2` |
| Kind | Local |
| Dependencies | `transformers>=4.46.0,<5.0.0`, `torch` |
| Download size | ~360 MB |
| Streaming | No |

Facebook's self-supervised speech recognition. English-only, runs locally.

**Configuration:**

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `model_id` | text | `facebook/wav2vec2-base-960h` | HuggingFace model ID |

**Example config:**

```yaml
wav2vec2:
  type: stt
  class: wav2vec2
  model_id: facebook/wav2vec2-base-960h
```

---

### Deepgram

| Property | Value |
|----------|-------|
| Class | `DeepgramSTT` |
| Registry name | `deepgram` |
| Kind | Cloud |
| Dependencies | `deepgram-sdk>=6.0` |
| Download size | 0 (cloud API) |
| Streaming | **Yes** |

Cloud-based streaming speech recognition with real-time interim results and utterance boundary detection. Recommended for production use.

**Configuration:**

| Field | Type | Default | Required | Description |
|-------|------|---------|----------|-------------|
| `api_key` | secret | — | Yes | Deepgram API key (env: `DEEPGRAM_API_KEY`) |
| `model` | select | `nova-3` | No | Recognition model (`nova-3`, `nova-2`) |
| `language` | text | `en` | No | Language code |

**Example config:**

```yaml
deepgram:
  type: stt
  class: deepgram
  model: nova-3
  language: en
  # api_key stored in ~/.roohai/secrets.yaml
```

**Streaming features:**
- Interim transcriptions (updated in real time as user speaks)
- `speech_final` detection (natural pause = end of turn)
- `utterance_end` events (silence timeout, default 1500ms)
- Smart formatting and punctuation

---

### NVIDIA Canary-Qwen

| Property | Value |
|----------|-------|
| Class | `NvidiaCanarySTT` |
| Registry name | `nvidia-canary` |
| Kind | Local |
| Dependencies | `nemo_toolkit[asr]`, `torch`, `soundfile` |
| Download size | ~5000 MB |
| Streaming | No |

NVIDIA's Canary-Qwen 2.5B ASR model via NeMo toolkit. State-of-the-art accuracy, requires CUDA GPU.

**Configuration:**

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `model_id` | text | `nvidia/canary-qwen-2.5b` | Pretrained model name |
| `language` | text | `en` | Language code |

**Example config:**

```yaml
nvidia-canary:
  type: stt
  class: nvidia-canary
  model_id: nvidia/canary-qwen-2.5b
  language: en
```

> **Note:** Requires a CUDA-capable GPU. The NeMo toolkit will be installed automatically during agent preparation.

---

### NVIDIA Parakeet

| Property | Value |
|----------|-------|
| Class | `NvidiaParakeetSTT` |
| Registry name | `nvidia-parakeet` |
| Kind | Local |
| Dependencies | `nemo_toolkit[asr]`, `torch`, `soundfile` |
| Download size | ~600 MB |
| Streaming | No |

NVIDIA's Parakeet TDT 0.6B — a smaller, faster ASR model. Good accuracy-to-speed ratio.

**Configuration:**

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `model_id` | text | `nvidia/parakeet-tdt-0.6b-v2` | Pretrained model name |
| `language` | text | `en` | Language code |

**Example config:**

```yaml
nvidia-parakeet:
  type: stt
  class: nvidia-parakeet
  model_id: nvidia/parakeet-tdt-0.6b-v2
  language: en
```

---

## Language Models (LLM)

### Amazon Bedrock (Claude)

| Property | Value |
|----------|-------|
| Class | `BedrockLLM` |
| Registry name | `bedrock` |
| Kind | Cloud |
| Dependencies | `boto3` |
| Download size | 0 (cloud API) |

Anthropic Claude via Amazon Bedrock. Supports environment-based auth (IAM roles, SSO), explicit access keys, or Bedrock API Keys.

**Authentication modes:**

| Mode | Description |
|------|-------------|
| `environment` | Uses AWS CLI config, SSO, or environment variables (default for local use) |
| `access_keys` | Explicit AWS IAM Access Key ID and Secret Access Key |
| `api_key` | Bedrock API Key (simpler, no IAM needed — recommended for managed platforms) |

**Configuration:**

| Field | Type | Default | Required | Description |
|-------|------|---------|----------|-------------|
| `auth_mode` | select | `environment` | No | `environment`, `access_keys`, or `api_key` |
| `aws_access_key_id` | secret | — | If `access_keys` | AWS access key (env: `AWS_ACCESS_KEY_ID`) |
| `aws_secret_access_key` | secret | — | If `access_keys` | AWS secret key (env: `AWS_SECRET_ACCESS_KEY`) |
| `bedrock_api_key` | secret | — | If `api_key` | Bedrock API key (env: `AWS_BEARER_TOKEN_BEDROCK`) |
| `region` | text | `us-east-1` | No | AWS region |
| `model_id` | text | `anthropic.claude-3-haiku-20240307-v1:0` | No | Bedrock model ID |

**Example configs:**

```yaml
# Using environment auth (default)
bedrock-claude:
  type: llm
  class: bedrock
  model_id: anthropic.claude-3-haiku-20240307-v1:0
  region: us-east-1
  auth_mode: environment
```

```yaml
# Using Bedrock API Key
bedrock-claude:
  type: llm
  class: bedrock
  model_id: anthropic.claude-3-haiku-20240307-v1:0
  region: us-east-1
  auth_mode: api_key
  # bedrock_api_key stored in ~/.roohai/secrets.yaml
```

**Bedrock API details:**
- Uses API version `bedrock-2023-05-31`
- System prompt: "You are a helpful voice assistant. Keep responses concise and conversational."
- Supports conversation history

---

### OpenAI (via Strands SDK)

| Property | Value |
|----------|-------|
| Class | `OpenAILLM` |
| Registry name | `openai` |
| Kind | Cloud |
| Dependencies | `strands-agents`, `openai>=1.0.0` |
| Download size | 0 (cloud API) |

GPT-4o, GPT-4o-mini and other OpenAI models via the Strands Agent SDK. Supports tool use and conversation memory.

**Configuration:**

| Field | Type | Default | Required | Description |
|-------|------|---------|----------|-------------|
| `api_key` | secret | — | No | OpenAI API key (env: `OPENAI_API_KEY`) |
| `model_id` | text | `gpt-4o` | No | Model ID (e.g. `gpt-4o`, `gpt-4o-mini`, `gpt-4.1`) |
| `base_url` | text | — | No | Custom API base URL (optional) |

**Example config:**

```yaml
openai:
  type: llm
  class: openai
  model_id: gpt-4o
  # api_key stored in ~/.roohai/secrets.yaml or OPENAI_API_KEY env var
```

---

### Anthropic (via Strands SDK)

| Property | Value |
|----------|-------|
| Class | `AnthropicLLM` |
| Registry name | `anthropic` |
| Kind | Cloud |
| Dependencies | `strands-agents`, `anthropic>=0.40.0` |
| Download size | 0 (cloud API) |

Claude models via the Anthropic API directly (not through Bedrock). Supports tool use and conversation memory.

**Configuration:**

| Field | Type | Default | Required | Description |
|-------|------|---------|----------|-------------|
| `api_key` | secret | — | No | Anthropic API key (env: `ANTHROPIC_API_KEY`) |
| `model_id` | text | `claude-sonnet-4-20250514` | No | Model ID |

**Example config:**

```yaml
anthropic:
  type: llm
  class: anthropic
  model_id: claude-sonnet-4-20250514
  # api_key stored in ~/.roohai/secrets.yaml or ANTHROPIC_API_KEY env var
```

---

### Google Gemini (via Strands SDK)

| Property | Value |
|----------|-------|
| Class | `GeminiLLM` |
| Registry name | `gemini` |
| Kind | Cloud |
| Dependencies | `strands-agents`, `google-genai>=1.0.0` |
| Download size | 0 (cloud API) |

Gemini Flash and Pro models via Google AI. Supports tool use and conversation memory.

**Configuration:**

| Field | Type | Default | Required | Description |
|-------|------|---------|----------|-------------|
| `api_key` | secret | — | No | Google API key (env: `GOOGLE_API_KEY`) |
| `model_id` | text | `gemini-2.5-flash` | No | Model ID (e.g. `gemini-2.5-flash`, `gemini-2.5-pro`) |

**Example config:**

```yaml
gemini:
  type: llm
  class: gemini
  model_id: gemini-2.5-flash
  # api_key stored in ~/.roohai/secrets.yaml or GOOGLE_API_KEY env var
```

---

### Ollama (Local)

| Property | Value |
|----------|-------|
| Class | `OllamaLLM` |
| Registry name | `ollama` |
| Kind | Local |
| Dependencies | `strands-agents`, `ollama>=0.4.0` |
| Download size | 0 (models managed by Ollama) |

Run any model locally via Ollama (Llama 3, Mistral, Qwen, etc.). No API key needed — requires an Ollama server running locally.

**Configuration:**

| Field | Type | Default | Required | Description |
|-------|------|---------|----------|-------------|
| `model_id` | text | `llama3` | No | Ollama model name (e.g. `llama3`, `mistral`, `qwen2`, `gemma3:4b`) |
| `host` | text | `http://localhost:11434` | No | Ollama server URL |

**Example config:**

```yaml
ollama:
  type: llm
  class: ollama
  model_id: llama3
  host: http://localhost:11434
```

---

### Local LLM (TinyLlama)

| Property | Value |
|----------|-------|
| Class | `LocalLLM` |
| Registry name | `local` |
| Kind | Local |
| Dependencies | `transformers>=4.46.0,<5.0.0`, `torch`, `accelerate` |
| Download size | ~2200 MB |

Run a HuggingFace language model locally using the `text-generation` pipeline with chat template support. No Strands SDK — direct inference.

**Configuration:**

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `model_id` | text | `TinyLlama/TinyLlama-1.1B-Chat-v1.0` | HuggingFace model ID |

**Example config:**

```yaml
local-llm:
  type: llm
  class: local
  model_id: TinyLlama/TinyLlama-1.1B-Chat-v1.0
```

> **Note:** Local LLMs are significantly slower than cloud APIs, especially on CPU. A GPU is recommended for reasonable response times.

---

## Text-to-Speech (TTS)

### SpeechT5

| Property | Value |
|----------|-------|
| Class | `SpeechT5TTS` |
| Registry name | `speecht5` |
| Kind | Local |
| Dependencies | `transformers>=4.46.0,<5.0.0`, `torch`, `sentencepiece` |
| Download size | ~600 MB |

Microsoft's unified speech-text model. Generates speech locally with a HiFi-GAN vocoder.

**Configuration:**

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `model_id` | text | `microsoft/speecht5_tts` | TTS model ID |
| `vocoder` | text | `microsoft/speecht5_hifigan` | Vocoder model ID |

**Example config:**

```yaml
speecht5:
  type: tts
  class: speecht5
  model_id: microsoft/speecht5_tts
  vocoder: microsoft/speecht5_hifigan
```

> **Note:** Uses random speaker embeddings (`torch.randn(1, 512)`) since the standard speaker embedding dataset is currently unavailable.

---

### Bark

| Property | Value |
|----------|-------|
| Class | `BarkTTS` |
| Registry name | `bark` |
| Kind | Local |
| Dependencies | `transformers>=4.46.0,<5.0.0`, `torch` |
| Download size | ~1800 MB |

Suno's generative text-to-audio model. Produces expressive, natural-sounding speech. Slower but higher quality than SpeechT5.

**Configuration:**

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `model_id` | text | `suno/bark-small` | HuggingFace model ID |

**Example config:**

```yaml
bark:
  type: tts
  class: bark
  model_id: suno/bark-small
```

---

### Piper

| Property | Value |
|----------|-------|
| Class | `PiperTTS` |
| Registry name | `piper` |
| Kind | Local |
| Dependencies | `piper-tts>=1.4` |
| Download size | ~60 MB |

Fast, lightweight local TTS engine. Downloads voice models automatically on first use. Excellent speed-to-quality ratio.

**Configuration:**

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `voice` | select | `en_US-lessac-medium` | Voice model |

**Available voices:**

| Value | Description |
|-------|-------------|
| `en_US-lessac-medium` | Lessac (US English, Medium quality) |
| `en_US-amy-medium` | Amy (US English, Medium quality) |
| `en_US-ryan-medium` | Ryan (US English, Medium quality) |
| `en_US-libritts_r-medium` | LibriTTS-R (US English, Medium quality) |
| `en_GB-alan-medium` | Alan (British English, Medium quality) |
| `en_GB-cori-medium` | Cori (British English, Medium quality) |

**Example config:**

```yaml
piper:
  type: tts
  class: piper
  voice: en_US-lessac-medium
```

---

### Cartesia

| Property | Value |
|----------|-------|
| Class | `CartesiaTTS` |
| Registry name | `cartesia` |
| Kind | Cloud |
| Dependencies | `cartesia` |
| Download size | 0 (cloud API) |

Cloud-based TTS with fast, natural-sounding voices. Low latency, high quality. Recommended for production.

**Configuration:**

| Field | Type | Default | Required | Description |
|-------|------|---------|----------|-------------|
| `api_key` | secret | — | Yes | Cartesia API key (env: `CARTESIA_API_KEY`) |
| `model_id` | text | `sonic-2` | No | TTS model |
| `voice_id` | text | `a0e99841-...` | No | Voice identifier |
| `language` | text | `en` | No | Language code |
| `sample_rate` | text | `24000` | No | Output sample rate (8000-48000) |

**Example config:**

```yaml
cartesia:
  type: tts
  class: cartesia
  model_id: sonic-2
  voice_id: a0e99841-438c-4a64-b679-ae501e7d6091
  language: en
  sample_rate: 24000
  # api_key stored in ~/.roohai/secrets.yaml
```

---

### Deepgram Aura-2

| Property | Value |
|----------|-------|
| Class | `DeepgramTTS` |
| Registry name | `deepgram-aura-2` |
| Kind | Cloud |
| Dependencies | `httpx` |
| Download size | 0 (cloud API) |

Cloud-based TTS with 90+ natural voices across 7 languages (English, Spanish, Dutch, German, Italian, Japanese, French). Shares the same `DEEPGRAM_API_KEY` as Deepgram STT.

**Configuration:**

| Field | Type | Default | Required | Description |
|-------|------|---------|----------|-------------|
| `api_key` | secret | — | Yes | Deepgram API key (env: `DEEPGRAM_API_KEY`) |
| `model` | text | `aura-2-thalia-en` | No | Voice model ID (e.g. `aura-2-apollo-en`, `aura-2-thalia-en`) |
| `sample_rate` | text | `24000` | No | Output sample rate (8000, 16000, 24000, 32000, 48000) |

**Example config:**

```yaml
deepgram-tts:
  type: tts
  class: deepgram-tts
  model: aura-2-thalia-en
  sample_rate: 24000
  # api_key stored in ~/.roohai/secrets.yaml (shared with Deepgram STT)
```

**Popular voices:**

| Model ID | Gender | Accent | Style |
|----------|--------|--------|-------|
| `aura-2-thalia-en` | Feminine | American | Energetic |
| `aura-2-apollo-en` | Masculine | American | Casual |
| `aura-2-aurora-en` | Feminine | British | Professional |
| `aura-2-orion-en` | Masculine | British | Confident |

See [Deepgram TTS models](https://developers.deepgram.com/docs/tts-models) for the full voice catalog.

---

## Voice Activity Detection (VAD)

### Silero VAD

| Property | Value |
|----------|-------|
| Class | `SileroVAD` |
| Registry name | `silero` |
| Kind | Local |
| Dependencies | `silero-vad>=5.1`, `torch` |
| Download size | ~2 MB |

Lightweight, accurate voice activity detection. Standard choice for all configurations.

**Configuration:** None required.

**Example config:**

```yaml
silero:
  type: vad
  class: silero
```

**Additional method:**

```python
# Get speech segments with timestamps
segments = vad.get_speech_segments(audio, sample_rate=16000)
# Returns: [{"start": 0.5, "end": 2.1}, {"start": 3.0, "end": 4.5}]
```

---

## RoohBuilder Quick Reference

All built-in models can be used via the `RoohBuilder` with string provider names.
Any extra `**kwargs` are forwarded directly to the model constructor.

### Built-in STT Providers

| Provider string | Class | Kind | Default model | Key kwargs |
|----------------|-------|------|---------------|------------|
| `"whisper"` | `WhisperSTT` | Local | `openai/whisper-tiny` | `model_id`, `language` (default `"en"`) |
| `"deepgram"` | `DeepgramSTT` | Cloud | `nova-3` | `model` (`"nova-3"`, `"nova-2"`), `language`, `api_key` (env: `DEEPGRAM_API_KEY`) |
| `"nvidia-canary"` | `NvidiaCanarySTT` | Local | `nvidia/canary-qwen-2.5b` | `model_id`, `language` |
| `"nvidia-parakeet"` | `NvidiaParakeetSTT` | Local | `nvidia/parakeet-tdt-0.6b-v2` | `model_id`, `language` |
| `"wav2vec2"` | `Wav2Vec2STT` | Local | `facebook/wav2vec2-base-960h` | `model_id` |

### Built-in LLM Providers

| Provider string | Class | Kind | Default model | Key kwargs |
|----------------|-------|------|---------------|------------|
| `"bedrock"` | `BedrockLLM` | Cloud | `anthropic.claude-3-haiku-20240307-v1:0` | `model_id`, `region` (default `"us-east-1"`), `auth_mode` (`"environment"`, `"access_keys"`, `"api_key"`), `aws_access_key_id`, `aws_secret_access_key`, `bedrock_api_key` |
| `"openai"` | `OpenAILLM` | Cloud | `gpt-4o` | `model_id`, `api_key` (env: `OPENAI_API_KEY`), `base_url` |
| `"anthropic"` | `AnthropicLLM` | Cloud | `claude-sonnet-4-20250514` | `model_id`, `api_key` (env: `ANTHROPIC_API_KEY`) |
| `"gemini"` | `GeminiLLM` | Cloud | `gemini-2.5-flash` | `model_id`, `api_key` (env: `GOOGLE_API_KEY`) |
| `"ollama"` | `OllamaLLM` | Local | `llama3` | `model_id`, `host` (default `"http://localhost:11434"`) |
| `"local"` | `LocalLLM` | Local | `TinyLlama/TinyLlama-1.1B-Chat-v1.0` | `model_id` |

### Built-in TTS Providers

| Provider string | Class | Kind | Default model/voice | Key kwargs |
|----------------|-------|------|---------------------|------------|
| `"cartesia"` | `CartesiaTTS` | Cloud | `sonic-2` / `a0e99841-...` | `model_id`, `voice_id`, `language`, `sample_rate`, `api_key` (env: `CARTESIA_API_KEY`) |
| `"deepgram-tts"` | `DeepgramTTS` | Cloud | `aura-2-thalia-en` | `model`, `sample_rate`, `api_key` (env: `DEEPGRAM_API_KEY`) |
| `"piper"` | `PiperTTS` | Local | `en_US-lessac-medium` | `voice` |
| `"speecht5"` | `SpeechT5TTS` | Local | `microsoft/speecht5_tts` | `model_id`, `vocoder` |
| `"bark"` | `BarkTTS` | Local | `suno/bark-small` | `model_id` |

### Built-in VAD Providers

| Provider string | Class | Kind | Key kwargs |
|----------------|-------|------|------------|
| `"silero"` | `SileroVAD` | Local | (none) |

### Usage Examples

```python
from roohai import Rooh

# Cloud pipeline: Deepgram + Bedrock + Cartesia
pipeline = (
    Rooh.builder()
    .stt("deepgram", model="nova-3")
    .llm("bedrock", model_id="anthropic.claude-3-haiku-20240307-v1:0", region="us-west-2")
    .tts("cartesia", voice_id="79a125e8-cd45-4c13-8a67-188112f4dd22")
    .vad()
    .system_prompt("You are a helpful voice assistant.")
    .build()
)

# Fully local pipeline: Whisper + Ollama + Piper
pipeline = (
    Rooh.builder()
    .stt("whisper", model_id="openai/whisper-small")
    .llm("ollama", model_id="gemma3:4b")
    .tts("piper", voice="en_US-amy-medium")
    .vad()
    .build()
)

# Custom model class — no framework changes needed
from my_module import ElevenLabsTTS

pipeline = (
    Rooh.builder()
    .stt("deepgram")
    .llm("anthropic", model_id="claude-sonnet-4-20250514")
    .custom_tts("elevenlabs", ElevenLabsTTS, api_key="sk-xxx", voice_id="abc")
    .vad()
    .build()
)
```

For implementing your own model classes, see [Building Custom Models](custom-models.md).

---

## Pre-registered Variants

The framework registers named variants of built-in models with preset configurations.
These are the registry names used in YAML agent configs and the `swap_model()` API:

### STT Variants

| Registry name | Base class | Preset kwargs |
|--------------|-----------|---------------|
| `whisper-tiny` | `WhisperSTT` | `model_id="openai/whisper-tiny"` |
| `whisper-base` | `WhisperSTT` | `model_id="openai/whisper-base"` |
| `whisper-small` | `WhisperSTT` | `model_id="openai/whisper-small"` |
| `whisper-medium` | `WhisperSTT` | `model_id="openai/whisper-medium"` |
| `whisper-large` | `WhisperSTT` | `model_id="openai/whisper-large-v3"` |
| `wav2vec2` | `Wav2Vec2STT` | `model_id="facebook/wav2vec2-base-960h"` |
| `wav2vec2-large` | `Wav2Vec2STT` | `model_id="facebook/wav2vec2-large-960h-lv60-self"` |
| `deepgram-nova-3` | `DeepgramSTT` | `model="nova-3"` |
| `deepgram-nova-2` | `DeepgramSTT` | `model="nova-2"` |
| `nvidia-canary` | `NvidiaCanarySTT` | `model_id="nvidia/canary-qwen-2.5b"` |
| `nvidia-parakeet` | `NvidiaParakeetSTT` | `model_id="nvidia/parakeet-tdt-0.6b-v2"` |

### TTS Variants

| Registry name | Base class | Preset kwargs |
|--------------|-----------|---------------|
| `speecht5` | `SpeechT5TTS` | (defaults) |
| `bark-small` | `BarkTTS` | `model_id="suno/bark-small"` |
| `bark-large` | `BarkTTS` | `model_id="suno/bark"` |
| `piper` | `PiperTTS` | `voice="en_US-lessac-medium"` |
| `cartesia` | `CartesiaTTS` | `model_id="sonic-2"` |
| `deepgram-aura-2` | `DeepgramTTS` | `model="aura-2-thalia-en"` |

### LLM Variants

| Registry name | Base class | Preset kwargs |
|--------------|-----------|---------------|
| `bedrock` | `BedrockLLM` | `model_id="anthropic.claude-3-haiku-20240307-v1:0"` |
| `local` | `LocalLLM` | `model_id="TinyLlama/TinyLlama-1.1B-Chat-v1.0"` |
| `openai` | `OpenAILLM` | `model_id="gpt-4o"` |
| `anthropic` | `AnthropicLLM` | `model_id="claude-sonnet-4-20250514"` |
| `gemini` | `GeminiLLM` | `model_id="gemini-2.5-flash"` |
| `ollama` | `OllamaLLM` | `model_id="llama3"` |

### VAD Variants

| Registry name | Base class | Preset kwargs |
|--------------|-----------|---------------|
| `silero` | `SileroVAD` | (defaults) |

---

