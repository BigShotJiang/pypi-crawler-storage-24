"""Speech-to-text model implementations."""

_all_classes = {}
_loaded = False


def _lazy_load():
    global _loaded
    if _loaded:
        return _all_classes
    _loaded = True

    try:
        from roohai.stt.whisper import WhisperSTT
        _all_classes["WhisperSTT"] = WhisperSTT
    except ImportError:
        pass

    try:
        from roohai.stt.wav2vec2 import Wav2Vec2STT
        _all_classes["Wav2Vec2STT"] = Wav2Vec2STT
    except ImportError:
        pass

    try:
        from roohai.stt.deepgram import DeepgramSTT
        _all_classes["DeepgramSTT"] = DeepgramSTT
    except ImportError:
        pass

    try:
        from roohai.stt.nvidia_nemo import NvidiaCanarySTT, NvidiaParakeetSTT
        _all_classes["NvidiaCanarySTT"] = NvidiaCanarySTT
        _all_classes["NvidiaParakeetSTT"] = NvidiaParakeetSTT
    except ImportError:
        pass

    return _all_classes


def __getattr__(name):
    classes = _lazy_load()
    if name in classes:
        return classes[name]
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = ["WhisperSTT", "Wav2Vec2STT", "DeepgramSTT", "NvidiaCanarySTT", "NvidiaParakeetSTT"]
