"""Voice activity detection implementations."""

_all_classes = {}
_loaded = False


def _lazy_load():
    global _loaded
    if _loaded:
        return _all_classes
    _loaded = True

    try:
        from roohai.vad.silero import SileroVAD
        _all_classes["SileroVAD"] = SileroVAD
    except ImportError:
        pass

    return _all_classes


def __getattr__(name):
    classes = _lazy_load()
    if name in classes:
        return classes[name]
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = ["SileroVAD"]
