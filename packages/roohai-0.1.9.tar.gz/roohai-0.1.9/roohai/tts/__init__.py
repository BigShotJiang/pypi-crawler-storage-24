"""Text-to-speech model implementations."""

_all_classes = {}
_loaded = False


def _lazy_load():
    global _loaded
    if _loaded:
        return _all_classes
    _loaded = True

    try:
        from roohai.tts.speecht5 import SpeechT5TTS
        _all_classes["SpeechT5TTS"] = SpeechT5TTS
    except ImportError:
        pass

    try:
        from roohai.tts.bark import BarkTTS
        _all_classes["BarkTTS"] = BarkTTS
    except ImportError:
        pass

    try:
        from roohai.tts.piper import PiperTTS
        _all_classes["PiperTTS"] = PiperTTS
    except ImportError:
        pass

    try:
        from roohai.tts.cartesia import CartesiaTTS
        _all_classes["CartesiaTTS"] = CartesiaTTS
    except ImportError:
        pass

    try:
        from roohai.tts.deepgram import DeepgramTTS
        _all_classes["DeepgramTTS"] = DeepgramTTS
    except ImportError:
        pass

    return _all_classes


def __getattr__(name):
    classes = _lazy_load()
    if name in classes:
        return classes[name]
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = ["SpeechT5TTS", "BarkTTS", "PiperTTS", "CartesiaTTS", "DeepgramTTS"]
