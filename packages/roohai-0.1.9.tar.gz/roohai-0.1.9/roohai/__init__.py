"""RoohAI - A modular voice AI framework with swappable STT, TTS, and LLM components."""
__version__ = "0.1.9"

from roohai.base import STTModel, TTSModel, LLMModel
from roohai.registry import registry
from roohai.config import load_config
from roohai.pipeline import Rooh, RoohBuilder
from roohai.hooks import LLMHook, make_wrapper

# Backward compatibility alias
Pipeline = Rooh

__all__ = [
    "__version__", "STTModel", "TTSModel", "LLMModel", "registry",
    "load_config", "Rooh", "RoohBuilder", "Pipeline", "LLMHook", "make_wrapper",
]
