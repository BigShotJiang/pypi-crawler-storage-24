"""YAML-based configuration loader."""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any

import yaml

logger = logging.getLogger(__name__)


def load_config(path: str | Path = "config.yaml") -> dict[str, Any]:
    """Load configuration from a YAML file."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")
    with open(path) as f:
        return yaml.safe_load(f)


def load_config_from_env() -> dict[str, Any] | None:
    """Load configuration from the AGENT_CONFIG_YAML environment variable.

    Returns the parsed dict, or None if the env var is not set.
    """
    raw = os.environ.get("AGENT_CONFIG_YAML")
    if not raw:
        return None
    logger.info("Loading config from AGENT_CONFIG_YAML env var")
    return yaml.safe_load(raw)
