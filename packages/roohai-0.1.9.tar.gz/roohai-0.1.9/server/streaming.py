"""WebSocket streaming endpoint with server-side VAD and barge-in support."""

from __future__ import annotations

import asyncio
import base64
import json
import logging
import time
import uuid

import numpy as np
from fastapi import WebSocket, WebSocketDisconnect

from roohai.audio import audio_to_wav_bytes
from roohai.pipeline import Rooh

from .callbacks import notify_session_end, notify_session_start
from .voice_common import (
    BARGE_IN_CONFIRM_CHUNKS,
    BARGE_IN_SPEECH_THRESHOLD,
    MAX_SPEECH_BUFFER_CHUNKS,
    MIN_SPEECH_CHUNKS,
    SPEECH_THRESHOLD,
    BargeInState,
    PipelineMetrics,
    _elapsed_ms,
    generate_and_synthesize,
    silence_chunks_for_ms,
)

logger = logging.getLogger(__name__)


async def handle_streaming(websocket: WebSocket, pipeline: Rooh) -> None:
    await websocket.accept()
    session_id = str(uuid.uuid4())
    logger.info("WebSocket session started: %s", session_id)
    await websocket.send_json({"type": "session", "session_id": session_id})

    # Per-session VAD threshold — defaults from pipeline config (YAML),
    # can be overridden at runtime via set_vad_threshold WebSocket message.
    vad_threshold = getattr(pipeline, "vad_threshold", SPEECH_THRESHOLD)

    await notify_session_start(session_id)
    try:
        if pipeline.stt_supports_streaming:
            await _handle_streaming_stt(websocket, pipeline, session_id, vad_threshold=vad_threshold)
        else:
            await _handle_batch_stt(websocket, pipeline, session_id, vad_threshold=vad_threshold)
    finally:
        await notify_session_end(session_id)
        # Clean up Strands agent session memory on disconnect
        pipeline.on_session_disconnect(session_id)


def _ws_send_interrupt(websocket: WebSocket):
    """Return a send_interrupt callback bound to the given WebSocket."""
    async def _send():
        await websocket.send_json({"type": "interrupt"})
    return _send


async def _ws_send_audio(websocket: WebSocket, wav_bytes: bytes) -> None:
    """Send WAV bytes over WebSocket as base64-encoded JSON."""
    audio_b64 = base64.b64encode(wav_bytes).decode()
    await websocket.send_json({"type": "audio", "audio": audio_b64})


async def _handle_streaming_stt(
    websocket: WebSocket, pipeline: Rooh, session_id: str,
    vad_threshold: float = SPEECH_THRESHOLD,
) -> None:
    """Streaming STT path: forward audio to Deepgram, use local VAD for UI only."""
    vad = pipeline.vad
    stt = pipeline.stt
    is_speaking = False
    paused = False
    state = BargeInState()
    pending_tasks: set[asyncio.Task] = set()
    threshold = vad_threshold
    barge_in_speech_count = 0  # consecutive speech chunks during active playback

    async def on_transcript(text: str, is_final: bool) -> None:
        """Called by STT with interim/final segment transcripts."""
        try:
            await websocket.send_json({
                "type": "interim_transcription",
                "text": text,
            })
        except Exception:
            logger.debug("Failed to send transcript to client", exc_info=True)

    async def _run_generation(text: str) -> None:
        """Run a single LLM+TTS generation with barge-in support."""
        gen_id = await state.start_generation(_ws_send_interrupt(websocket))
        try:
            await _process_transcript(
                websocket, pipeline, text, state.cancel_event,
                session_id=session_id, gen_id=gen_id,
            )
        finally:
            state.finish_generation()

    async def on_utterance_end(text: str) -> None:
        """Called when STT detects end of turn -- fire off LLM+TTS as a task."""
        task = asyncio.create_task(_run_generation(text))
        pending_tasks.add(task)
        task.add_done_callback(pending_tasks.discard)

    try:
        # Start streaming STT connection
        await stt.start_stream(on_transcript, on_utterance_end)
        await websocket.send_json({"type": "status", "state": "listening"})

        while True:
            msg = await websocket.receive_text()
            data = json.loads(msg)

            if data.get("type") == "audio_chunk":
                if paused:
                    continue

                raw = base64.b64decode(data["audio"])

                # Forward raw PCM16 bytes directly to STT
                await stt.send_chunk(raw)

                # Run local VAD for UI indicator + barge-in detection
                if vad is not None:
                    chunk = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
                    speech_prob = await asyncio.to_thread(vad.is_speech, chunk, 16000)

                    # Barge-in: use lower VAD threshold during playback since mic is attenuated.
                    # Speaker echo is intermittent; a real user holds speech for 5+ chunks (~160ms).
                    barge_threshold = BARGE_IN_SPEECH_THRESHOLD if state.is_active else threshold
                    if speech_prob >= barge_threshold and state.is_active and not state.cancel_event.is_set() and pipeline.barge_in_enabled:
                        barge_in_speech_count += 1
                        if barge_in_speech_count >= BARGE_IN_CONFIRM_CHUNKS:
                            logger.info(
                                "Barge-in confirmed (%d chunks) during generation %d",
                                barge_in_speech_count, state.generation_id,
                            )
                            barge_in_speech_count = 0
                            state.cancel_event.set()
                            try:
                                await websocket.send_json({"type": "interrupt"})
                            except Exception:
                                pass
                            if pipeline._barge_in_hook is not None:
                                try:
                                    await pipeline._barge_in_hook(
                                        session_id=session_id, generation_id=state.generation_id,
                                    )
                                except Exception:
                                    logger.debug("Barge-in hook error", exc_info=True)
                    elif speech_prob < barge_threshold:
                        barge_in_speech_count = 0

                    if speech_prob >= threshold:
                        if not is_speaking:
                            is_speaking = True
                            await websocket.send_json(
                                {"type": "status", "state": "listening", "vad": "speech_start"}
                            )
                    else:
                        if is_speaking:
                            is_speaking = False
                            await websocket.send_json(
                                {"type": "status", "state": "listening", "vad": "speech_end"}
                            )

            elif data.get("type") == "pause_audio":
                paused = True
                logger.info("Audio paused by client")
                await websocket.send_json({"type": "status", "state": "paused"})

            elif data.get("type") == "resume_audio":
                paused = False
                logger.info("Audio resumed by client")
                await websocket.send_json({"type": "status", "state": "listening"})

            elif data.get("type") == "playback_done":
                state.playback_done()

            elif data.get("type") == "ping":
                await websocket.send_json({"type": "pong"})

            elif data.get("type") == "set_vad_threshold":
                val = float(data.get("value", SPEECH_THRESHOLD))
                threshold = max(0.0, min(1.0, val))
                logger.info("VAD threshold updated to %.2f (session %s)", threshold, session_id)

    except WebSocketDisconnect:
        pass
    except Exception as e:
        logger.exception("WebSocket streaming error")
        try:
            await websocket.send_json({"type": "error", "message": str(e)})
        except Exception:
            pass
    finally:
        for task in pending_tasks:
            task.cancel()
        await asyncio.gather(*pending_tasks, return_exceptions=True)
        pending_tasks.clear()
        await stt.stop_stream()


async def _handle_batch_stt(
    websocket: WebSocket, pipeline: Rooh, session_id: str,
    vad_threshold: float = SPEECH_THRESHOLD,
) -> None:
    """Batch STT path: accumulate speech via VAD, then transcribe full utterance."""
    vad = pipeline.vad
    if vad is None:
        await websocket.send_json({"type": "error", "message": "VAD model not loaded"})
        await websocket.close()
        return

    speech_buffer: list[np.ndarray] = []
    is_speaking = False
    paused = False
    silence_count = 0
    speech_chunk_count = 0
    barge_in_speech_count = 0  # consecutive speech chunks during active playback
    state = BargeInState()
    pending_tasks: set[asyncio.Task] = set()
    threshold = vad_threshold
    silence_chunks = silence_chunks_for_ms(getattr(pipeline, "silence_duration_ms", 1000))

    try:
        await websocket.send_json({"type": "status", "state": "listening"})

        while True:
            msg = await websocket.receive_text()
            data = json.loads(msg)

            if data.get("type") == "audio_chunk":
                if paused:
                    continue

                # Decode PCM16 audio chunk
                raw = base64.b64decode(data["audio"])
                chunk = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0

                # Run VAD
                speech_prob = await asyncio.to_thread(vad.is_speech, chunk, 16000)

                # Barge-in: use lower VAD threshold during playback since mic is attenuated.
                barge_threshold = BARGE_IN_SPEECH_THRESHOLD if state.is_active else threshold
                if speech_prob >= barge_threshold and state.is_active and pipeline.barge_in_enabled:
                    if not state.cancel_event.is_set():
                        barge_in_speech_count += 1
                        if barge_in_speech_count >= BARGE_IN_CONFIRM_CHUNKS:
                            logger.info(
                                "Barge-in confirmed (%d chunks) during generation %d",
                                barge_in_speech_count, state.generation_id,
                            )
                            barge_in_speech_count = 0
                            state.cancel_event.set()
                            state.playback_pending = False
                            try:
                                await websocket.send_json({"type": "interrupt"})
                            except Exception:
                                pass
                            if pipeline._barge_in_hook is not None:
                                try:
                                    await pipeline._barge_in_hook(
                                        session_id=session_id,
                                        generation_id=state.generation_id,
                                    )
                                except Exception:
                                    logger.debug("Barge-in hook error", exc_info=True)
                elif speech_prob < barge_threshold:
                    barge_in_speech_count = 0

                if speech_prob >= threshold:
                    if not is_speaking:
                        is_speaking = True
                        await websocket.send_json(
                            {"type": "status", "state": "listening", "vad": "speech_start"}
                        )
                    speech_buffer.append(chunk)
                    speech_chunk_count += 1
                    silence_count = 0
                else:
                    if is_speaking:
                        speech_buffer.append(chunk)
                        silence_count += 1

                    if is_speaking and (
                        (silence_count >= silence_chunks and speech_chunk_count >= MIN_SPEECH_CHUNKS)
                        or len(speech_buffer) >= MAX_SPEECH_BUFFER_CHUNKS
                    ):
                        # Speech ended or buffer overflow -- process the utterance
                        if len(speech_buffer) >= MAX_SPEECH_BUFFER_CHUNKS:
                            logger.warning(
                                "Speech buffer overflow (%d chunks) — processing early",
                                len(speech_buffer),
                            )
                        await websocket.send_json(
                            {"type": "status", "state": "listening", "vad": "speech_end"}
                        )
                        audio = np.concatenate(speech_buffer)
                        speech_buffer = []
                        is_speaking = False
                        silence_count = 0
                        speech_chunk_count = 0

                        task = asyncio.create_task(
                            _process_utterance(websocket, pipeline, audio, state, session_id=session_id)
                        )
                        pending_tasks.add(task)
                        task.add_done_callback(pending_tasks.discard)

            elif data.get("type") == "pause_audio":
                paused = True
                logger.info("Audio paused by client (batch mode)")
                await websocket.send_json({"type": "status", "state": "paused"})

            elif data.get("type") == "resume_audio":
                paused = False
                logger.info("Audio resumed by client (batch mode)")
                await websocket.send_json({"type": "status", "state": "listening"})

            elif data.get("type") == "playback_done":
                state.playback_done()

            elif data.get("type") == "ping":
                await websocket.send_json({"type": "pong"})

            elif data.get("type") == "set_vad_threshold":
                val = float(data.get("value", SPEECH_THRESHOLD))
                threshold = max(0.0, min(1.0, val))
                logger.info("VAD threshold updated to %.2f (session %s)", threshold, session_id)

    except WebSocketDisconnect:
        pass
    except Exception as e:
        logger.exception("WebSocket streaming error")
        try:
            await websocket.send_json({"type": "error", "message": str(e)})
        except Exception:
            pass
    finally:
        for task in pending_tasks:
            task.cancel()
        await asyncio.gather(*pending_tasks, return_exceptions=True)
        pending_tasks.clear()


async def _process_transcript(
    websocket: WebSocket,
    pipeline: Rooh,
    transcript: str,
    cancel: asyncio.Event | None = None,
    session_id: str | None = None,
    gen_id: int | None = None,
) -> None:
    """Run LLM -> TTS on a completed transcript (streaming or batch per config)."""
    try:
        if not transcript or not transcript.strip():
            await websocket.send_json({"type": "status", "state": "listening"})
            return

        metrics = PipelineMetrics()

        # Send the final committed transcription (replaces any interim)
        await websocket.send_json({"type": "transcription", "text": transcript})

        if cancel and cancel.is_set():
            logger.info("Generation cancelled before LLM")
            return

        await websocket.send_json({"type": "status", "state": "thinking"})

        async def send_audio(wav_bytes: bytes) -> None:
            audio_b64 = base64.b64encode(wav_bytes).decode()
            await websocket.send_json({"type": "audio", "audio": audio_b64, "gen_id": gen_id})

        async def send_chunk(token: str) -> None:
            await websocket.send_json({"type": "llm_response_chunk", "text": token})

        async def send_done(full_text: str) -> None:
            await websocket.send_json({"type": "llm_response_done", "text": full_text})

        async def send_full(full_text: str) -> None:
            await websocket.send_json({"type": "llm_response", "text": full_text})

        await websocket.send_json({"type": "status", "state": "speaking", "gen_id": gen_id})

        await generate_and_synthesize(
            pipeline, transcript, send_audio, send_chunk, send_done, send_full,
            cancel, metrics=metrics, session_id=session_id,
        )

        metrics.finish()
        logger.info("Pipeline metrics: %s", metrics.to_dict())
        if not (cancel and cancel.is_set()):
            await websocket.send_json({"type": "metrics", **metrics.to_dict()})
            await websocket.send_json({"type": "status", "state": "listening"})
    except Exception as e:
        logger.exception("Transcript processing failed")
        try:
            await websocket.send_json({"type": "error", "message": str(e)})
            await websocket.send_json({"type": "status", "state": "listening"})
        except Exception:
            pass


async def _process_utterance(
    websocket: WebSocket,
    pipeline: Rooh,
    audio: np.ndarray,
    state: BargeInState,
    session_id: str | None = None,
) -> None:
    """Run STT -> LLM -> TTS on the detected utterance (streaming or batch per config)."""
    gen_id = await state.start_generation(_ws_send_interrupt(websocket))
    cancel = state.cancel_event
    try:
        metrics = PipelineMetrics()

        # STT
        await websocket.send_json({"type": "status", "state": "transcribing"})
        stt_start = time.monotonic()
        wav_bytes = audio_to_wav_bytes(audio, 16000)
        transcription = await pipeline.transcribe(wav_bytes)
        metrics.stt_ms = _elapsed_ms(stt_start)
        await websocket.send_json({"type": "transcription", "text": transcription})

        if not transcription or not transcription.strip():
            await websocket.send_json({"type": "status", "state": "listening"})
            return

        if cancel.is_set():
            logger.info("Generation %d cancelled before LLM", gen_id)
            return

        await websocket.send_json({"type": "status", "state": "thinking"})

        async def send_audio(wav_bytes: bytes) -> None:
            audio_b64 = base64.b64encode(wav_bytes).decode()
            await websocket.send_json({"type": "audio", "audio": audio_b64, "gen_id": gen_id})

        async def send_chunk(token: str) -> None:
            await websocket.send_json({"type": "llm_response_chunk", "text": token})

        async def send_done(full_text: str) -> None:
            await websocket.send_json({"type": "llm_response_done", "text": full_text})

        async def send_full(full_text: str) -> None:
            await websocket.send_json({"type": "llm_response", "text": full_text})

        await websocket.send_json({"type": "status", "state": "speaking", "gen_id": gen_id})

        await generate_and_synthesize(
            pipeline, transcription, send_audio, send_chunk, send_done, send_full,
            cancel, metrics=metrics, session_id=session_id,
        )

        metrics.finish()
        logger.info("Pipeline metrics: %s", metrics.to_dict())
        if not cancel.is_set():
            await websocket.send_json({"type": "metrics", **metrics.to_dict()})
            await websocket.send_json({"type": "status", "state": "listening"})
    except Exception as e:
        logger.exception("Utterance processing failed")
        try:
            await websocket.send_json({"type": "error", "message": str(e)})
            await websocket.send_json({"type": "status", "state": "listening"})
        except Exception:
            pass
    finally:
        state.finish_generation()
