"""RoohAI CLI entry point."""
import argparse
import os
import uvicorn


def main():
    parser = argparse.ArgumentParser(description="RoohAI voice agent server")
    parser.add_argument("--host", default="0.0.0.0", help="Bind host (default: 0.0.0.0)")
    parser.add_argument("--port", type=int, default=8000, help="Bind port (default: 8000)")
    parser.add_argument("--reload", action="store_true", help="Enable auto-reload for development")
    parser.add_argument(
        "--log-level", default="info",
        choices=["debug", "info", "warning", "error"],
        help="Log level (default: info)",
    )
    parser.add_argument(
        "--cors-origins",
        default=None,
        help='Comma-separated allowed CORS origins (default: "*"). '
             "Example: --cors-origins https://myapp.com,https://staging.myapp.com",
    )
    parser.add_argument(
        "--auth-jwks-url",
        default=None,
        help="JWKS endpoint URL to enable JWT authentication on all protected routes. "
             "Example: --auth-jwks-url https://myproject.supabase.co/auth/v1/.well-known/jwks.json",
    )
    parser.add_argument(
        "--auth-issuer",
        default=None,
        help="Expected JWT issuer (optional). Tokens with a different 'iss' claim are rejected.",
    )
    parser.add_argument(
        "--auth-audience",
        default=None,
        help="Expected JWT audience (optional). Tokens with a different 'aud' claim are rejected.",
    )
    parser.add_argument(
        "--internal-token",
        default=None,
        help="Shared secret for platform-to-agent internal APIs (domain management, etc.).",
    )
    args = parser.parse_args()

    if args.cors_origins is not None:
        os.environ["ROOHAI_CORS_ORIGINS"] = args.cors_origins
    if args.auth_jwks_url is not None:
        os.environ["ROOHAI_AUTH_JWKS_URL"] = args.auth_jwks_url
    if args.auth_issuer is not None:
        os.environ["ROOHAI_AUTH_ISSUER"] = args.auth_issuer
    if args.auth_audience is not None:
        os.environ["ROOHAI_AUTH_AUDIENCE"] = args.auth_audience
    if args.internal_token is not None:
        os.environ["ROOHAI_INTERNAL_TOKEN"] = args.internal_token

    uvicorn.run("server.app:app", host=args.host, port=args.port, reload=args.reload, log_level=args.log_level)


if __name__ == "__main__":
    main()
