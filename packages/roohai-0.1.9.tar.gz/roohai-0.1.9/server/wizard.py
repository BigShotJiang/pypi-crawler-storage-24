"""Wizard API router — agent CRUD, model catalog, activation."""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from roohai.agents import list_agents, get_agent, save_agent, delete_agent, validate_agent_name
from roohai.registry import registry
from roohai.secrets import set_agent_secrets, get_agent_secrets, delete_agent_secrets
from .auth import require_auth

logger = logging.getLogger(__name__)

router = APIRouter(dependencies=[Depends(require_auth)])


class CreateAgentRequest(BaseModel):
    name: str
    pipeline: dict
    models: dict
    secrets: dict | None = None
    system_prompt: str
    transport: str = "websocket"
    llm_streaming: bool = True


# --- Catalog ---


@router.get("/api/catalog")
async def catalog():
    """Return the full model catalog from registry."""
    from roohai.pipeline import register_all_models
    register_all_models()
    return {"catalog": registry.catalog()}


# --- Agent CRUD ---


@router.get("/api/agents")
async def api_list_agents():
    return {"agents": list_agents()}


@router.post("/api/agents")
async def api_create_agent(req: CreateAgentRequest):
    # Validate name
    try:
        validate_agent_name(req.name)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    # Check for duplicates
    if get_agent(req.name):
        raise HTTPException(status_code=409, detail=f"Agent '{req.name}' already exists")

    config = {
        "name": req.name,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "status": "created",
        "pipeline": req.pipeline,
        "models": req.models,
        "system_prompt": req.system_prompt,
        "transport": req.transport,
        "llm_streaming": req.llm_streaming,
    }

    save_agent(config)

    # Store secrets separately (never in agent yaml)
    if req.secrets:
        set_agent_secrets(req.name, req.secrets)

    return {"status": "created", "agent": config}


@router.get("/api/agents/{name}")
async def api_get_agent(name: str):
    agent = get_agent(name)
    if not agent:
        raise HTTPException(status_code=404, detail=f"Agent '{name}' not found")
    return {"agent": agent}


@router.delete("/api/agents/{name}")
async def api_delete_agent(name: str):
    if not get_agent(name):
        raise HTTPException(status_code=404, detail=f"Agent '{name}' not found")
    delete_agent(name)
    delete_agent_secrets(name)
    return {"status": "deleted", "name": name}


# --- Activation ---


@router.post("/api/agents/{name}/activate")
async def api_activate_agent(name: str):
    """Load an agent's model configuration into the running pipeline."""
    from server.app import pipeline
    from roohai.pipeline import _register_from_config

    agent = get_agent(name)
    if not agent:
        raise HTTPException(status_code=404, detail=f"Agent '{name}' not found")
    if pipeline is None:
        raise HTTPException(status_code=503, detail="Rooh pipeline not initialized")

    # Deactivate all other active agents first
    all_agents = list_agents()
    for other in all_agents:
        if other.get("status") == "active" and other["name"] != name:
            other["status"] = "inactive"
            save_agent(other)

    # Merge agent secrets into model configs for cloud models
    secrets = get_agent_secrets(name)
    models = agent.get("models", {})
    for model_name, model_cfg in models.items():
        model_secrets = secrets.get(model_name, {})
        if model_secrets:
            model_cfg.update(model_secrets)

    # Register the agent's models into the registry
    agent_as_config = {"models": models}
    _register_from_config(agent_as_config)

    # Validate llm_hook before committing to activation
    # Add the agents directory to sys.path so agent-local hook
    # modules (e.g. hooks.py alongside agent YAMLs) are importable.
    import sys
    from roohai.agents import AGENTS_DIR
    agents_dir_str = str(AGENTS_DIR)
    if agents_dir_str not in sys.path:
        sys.path.insert(0, agents_dir_str)

    hook_path = agent.get("llm_hook")
    hook_fn = None
    stream_hook_fn = None
    if hook_path:
        import importlib
        module_path, _, attr = hook_path.rpartition(".")
        try:
            mod = importlib.import_module(module_path)
            hook_fn = getattr(mod, attr)
        except (ModuleNotFoundError, AttributeError) as exc:
            raise HTTPException(
                status_code=422,
                detail=f"Cannot activate agent '{name}': llm_hook '{hook_path}' could not be resolved — {exc}",
            )
    stream_hook_path = agent.get("llm_stream_hook")
    if stream_hook_path:
        import importlib
        module_path, _, attr = stream_hook_path.rpartition(".")
        try:
            mod = importlib.import_module(module_path)
            stream_hook_fn = getattr(mod, attr)
        except (ModuleNotFoundError, AttributeError) as exc:
            raise HTTPException(
                status_code=422,
                detail=(
                    f"Cannot activate agent '{name}': "
                    f"llm_stream_hook '{stream_hook_path}' could not be resolved — {exc}"
                ),
            )

    # Swap each model in the pipeline
    agent_pipeline = agent.get("pipeline", {})
    for model_type in ("stt", "tts", "llm", "vad"):
        model_name = agent_pipeline.get(model_type)
        if model_name:
            try:
                await asyncio.to_thread(pipeline.swap_model, model_type, model_name)
            except Exception as exc:
                raise HTTPException(
                    status_code=422,
                    detail=f"Cannot activate agent '{name}': failed to load {model_type} model '{model_name}' — {exc}",
                )

    # Set system prompt, LLM streaming, and pipeline behaviour
    pipeline.set_system_prompt(agent.get("system_prompt"))
    pipeline.llm_streaming = agent.get("llm_streaming", True)
    pipeline.barge_in_enabled = agent_pipeline.get("barge_in_enabled", True)
    pipeline.silence_duration_ms = int(agent_pipeline.get("silence_duration_ms", 1000))
    pipeline.vad_threshold = float(agent_pipeline.get("vad_threshold", 0.7))

    # Apply validated hooks, or default to Strands Agent hook
    if hook_fn:
        pipeline.set_llm_hook(hook_fn, stream_hook=stream_hook_fn)
    else:
        llm_name = agent_pipeline.get("llm", pipeline._llm_name)
        llm_config = models.get(llm_name, {})
        llm_class = llm_config.get("class", "")

        # Local models (e.g. TinyLlama via HuggingFace transformers) don't have
        # a Strands model provider — skip the Strands hook and let the pipeline
        # fall back to the loaded LocalLLM directly via pipeline.chat().
        _STRANDS_SUPPORTED_PROVIDERS = {"bedrock", "openai", "anthropic", "gemini", "ollama"}

        if llm_class in _STRANDS_SUPPORTED_PROVIDERS:
            # Wire up Strands Agent as the default LLM hook — gives every agent
            # conversation memory + tool use for free (same as startup path).
            from roohai.llm.strands_hook import configure as configure_strands
            from roohai.llm.strands_hook import strands_hook, clear_session, reset_session

            strands_cfg = agent.get("strands", {})
            tool_names = strands_cfg.get("tools")
            window_size = int(strands_cfg.get("conversation_window", 40))

            # Map Langfuse secrets to OTEL env vars for Strands tracing
            langfuse_secrets = secrets.get("langfuse", {})
            if langfuse_secrets.get("public_key"):
                from server.app import _set_langfuse_otel_env
                _set_langfuse_otel_env(langfuse_secrets)

            configure_strands(
                llm_config=llm_config,
                system_prompt=agent.get("system_prompt"),
                tool_names=tool_names,
                window_size=window_size,
            )
            pipeline.set_llm_hook(strands_hook)
            pipeline.set_session_disconnect_hook(clear_session)

            async def _on_barge_in(session_id: str, generation_id: int, **_kw) -> None:
                reset_session(session_id)

            pipeline.set_barge_in_hook(_on_barge_in)
        else:
            # No Strands support — clear any previously set hooks so the
            # pipeline uses the loaded LLM model directly.
            logger.info(
                "LLM class '%s' not supported by Strands — using direct pipeline LLM fallback",
                llm_class,
            )
            pipeline.set_llm_hook(None)

    # Update agent status
    agent["status"] = "active"
    save_agent(agent)

    return {
        "status": "activated",
        "agent": name,
        "transport": agent.get("transport", "websocket"),
        "active_models": {
            "stt": pipeline._stt_name,
            "tts": pipeline._tts_name,
            "llm": pipeline._llm_name,
        }
    }
