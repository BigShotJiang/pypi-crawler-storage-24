import threading
from contextlib import contextmanager
from typing import Optional

from infrastructure_connector import get_session


class DBSessionSingleton:
    """Singleton global - compatible infrastructure_connector"""

    _instance: Optional["DBSessionSingleton"] = None
    _lock = threading.Lock()
    _session = None

    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
        return cls._instance

    @property
    def session(self):
        """Renvoie la session globale via infrastructure_connector"""
        if self._session is None:
            self._session = get_session()
        return self._session

    def open(self):
        """Ouvre la session globale"""
        self._session = get_session()

    def close(self):
        """Ferme la session globale proprement"""
        if self._session is not None:
            try:
                self._session.close()
            except:
                pass  # Ignore les erreurs de close
            self._session = None

    def commit(self):
        """Commit global"""
        session = self.session
        try:
            session.commit()
        except Exception:
            try:
                session.rollback()
            except:
                pass
            raise

    def rollback(self):
        """Rollback global"""
        if self._session is not None:
            try:
                self._session.rollback()
            except:
                pass

    @contextmanager
    def managed(self):
        """Context manager auto-open/close"""
        self.open()
        try:
            yield self.session
        finally:
            self.close()

# Export singleton global (importe-le partout !)
DBSession = DBSessionSingleton()
