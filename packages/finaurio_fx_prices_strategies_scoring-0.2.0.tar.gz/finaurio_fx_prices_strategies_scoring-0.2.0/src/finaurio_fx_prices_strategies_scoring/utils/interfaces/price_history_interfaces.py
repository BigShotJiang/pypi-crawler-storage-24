import json
from datetime import datetime
from decimal import Decimal
from pathlib import Path
from typing import NamedTuple

from infrastructure_connector.utils.enums import TimeUnitEnum


class PriceEvolutionResult(NamedTuple):
    """
    Representation of an asset's price evolution in time range.
    Both absolute and relative evolutions.
    """
    start_price: Decimal
    end_price: Decimal
    abs_change: Decimal
    rel_change: Decimal

class PriceVolatilityResult(NamedTuple):
    """
    Volatilities statistics on asset's prices in time range.
    """
    simple_vol:float
    log_vol:float
    annualized:float | None = None
    annualization_days: int | None = None

class PriceRangeLevels(NamedTuple):
    level_pips:float
    hits:float
    strength:str
    range_pips:list[float]

# TODO Are true ranges needed ?
class PriceRangeResult(NamedTuple):
    """Prices ranges for a given time range & asset.
    Args:
        atr (_float_): Average true range in pip
        total_range (_float_): Min - Max Range
        true_ranges(_list[PriceinPip]_): All True Range values from prices, converted in pips.
        levels(_list[PriceRangeLevels]_): Price Range Levels 
    """
    atr:float
    total_range:float
    true_ranges:list[float]

class GlobalPriceAnalytic(NamedTuple):
    """ Base statistics on prices for a given time range & asset.
    """
    asset_symbol:str
    start_time: datetime
    end_time: datetime
    nb_periods:int
    time_unit:TimeUnitEnum
    price_evolution:PriceEvolutionResult
    price_volatility:PriceVolatilityResult
    price_range:PriceRangeResult



def load_global_price_analytic(json_file: str = "GLOBAL_ANALYSIS.json") -> GlobalPriceAnalytic:
    """
    Charge un fichier JSON à la racine du projet et retourne une instance de GlobalPriceAnalytic.
    
    Args:
        json_file: Chemin relatif vers le fichier JSON (défaut: "GLOBAL_ANALYSIS.json").
    
    Returns:
        GlobalPriceAnalytic instancié.
    
    Raises:
        FileNotFoundError: Si le fichier n'existe pas.
        KeyError: Si la structure JSON est invalide.
        ValueError: Si les données ne peuvent pas être parsées.
    """
    file_path = Path(json_file)
    if not file_path.exists():
        raise FileNotFoundError(f"Fichier JSON non trouvé: {file_path.absolute()}")

    with open(file_path, "r", encoding="utf-8") as f:
        raw_data = json.load(f)

    # Extraction des données (assume 1 seul item comme dans l'exemple)
    if raw_data["total_items"] != 1 or len(raw_data["data"]) != 1:
        raise ValueError("Le JSON doit contenir exactement 1 item dans 'data'.")

    data = raw_data["data"][0]["data"]

    # Parsing des champs simples
    asset_symbol: str = data["asset_symbol"]
    start_time: datetime = datetime.fromisoformat(data["start_time"].replace(" ", "T"))
    end_time: datetime = datetime.fromisoformat(data["end_time"].replace(" ", "T"))
    nb_periods: int = data["nb_periods"]
    time_unit_str: str = data["time_unit"]
    # TODO: Convertir time_unit_str en TimeUnitEnum(value=time_unit_str)

    # Price Evolution (liste de 4 valeurs: start, end, abs_change, rel_change)
    price_evo = [Decimal(str(v)) if isinstance(v, (int, float)) else Decimal(v) for v in data["price_evolution"]]
    price_evolution = PriceEvolutionResult(*price_evo)

    # Price Volatility (liste de 4: simple_vol, log_vol, annualized, annualization_days)
    price_vol_raw = data["price_volatility"]
    simple_vol = float(price_vol_raw[0]) if price_vol_raw[0] is not None else 0.0
    log_vol = float(price_vol_raw[1]) if price_vol_raw[1] is not None else 0.0
    annualized = float(price_vol_raw[2]) if price_vol_raw[2] is not None else None
    annualization_days = int(price_vol_raw[3]) if price_vol_raw[3] is not None else None
    price_volatility = PriceVolatilityResult(simple_vol, log_vol, annualized, annualization_days)

    # Price Range (liste de 3: atr, total_range, true_ranges (liste de floats))
    price_range_raw = data["price_range"]
    atr: float = float(price_range_raw[0])
    total_range: float = float(price_range_raw[1])
    true_ranges: list[float] = [float(v) for v in price_range_raw[2]]
    price_range = PriceRangeResult(atr, total_range, true_ranges)

    return GlobalPriceAnalytic(
        asset_symbol=asset_symbol,
        start_time=start_time,
        end_time=end_time,
        nb_periods=nb_periods,
        time_unit=TimeUnitEnum(time_unit_str),  # À convertir en enum
        price_evolution=price_evolution,
        price_volatility=price_volatility,
        price_range=price_range
    )
