from finaurio_fx_prices_strategies_scoring.utils.interfaces.kpis import AnalyticsKPIs, AnalyticsKPIsFactory
from finaurio_fx_prices_strategies_scoring.utils.interfaces.price_history_interfaces import (
    PriceEvolutionResult,
    PriceRangeResult,
    PriceRangeLevels,
    PriceVolatilityResult,
    GlobalPriceAnalytic,
    load_global_price_analytic
)
