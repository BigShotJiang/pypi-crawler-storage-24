import statistics
from typing import NamedTuple

import numpy as np

from utils.interfaces.price_history_interfaces import GlobalPriceAnalytic


class AnalyticsKPIs(NamedTuple):
    """KPIs standardisés pour matching stratégie depuis GlobalPriceAnalytic."""

    # Métriques de base (copiées)
    asset_symbol: str
    time_unit: str  # ou TimeUnitEnum
    nb_periods: int
    start_price: float
    end_price: float
    rel_change_pct: float  # en %
    abs_change_pips: float  # en pips

    # Trend & Direction
    trend_strength: float  # |rel_change| / vol (force relative du move)
    direction: str  # 'UP', 'DOWN', 'FLAT'

    # Volatility Regime
    simple_vol_pct: float  # en %
    atr_pips: float
    atr_pct: float  # ATR en % du prix
    vol_regime: str  # 'LOW', 'MEDIUM', 'HIGH', 'EXPANDING'

    # True Range Dynamics
    mean_tr_pips: float
    median_tr_pips: float
    std_tr_pips: float
    tr_cv: float  # coefficient de variation std/mean
    tr_percentiles: dict  # {p25, p50, p75, p95}
    expansion_pct: float  # % de TR > 2*ATR
    max_tr_pct: float  # max TR / mean TR

    # Regime Classification
    price_regime: str  # 'TRENDING', 'RANGING', 'VOLATILE', 'CONSOLIDATION'


class AnalyticsKPIsFactory:
    @staticmethod  # CORRECTION 1: @staticmethod
    def from_global_analysis(analysis: GlobalPriceAnalytic, pip_size: float) -> AnalyticsKPIs:
        """Convertit GlobalPriceAnalytic → AnalyticsKPIs avec tous calculs."""

        # Base data
        true_ranges = analysis.price_range.true_ranges
        atr = analysis.price_range.atr
        end_price = float(analysis.price_evolution.end_price)

        # CORRECTION 2: Pip conversion correcte
        abs_change_pips = abs(float(analysis.price_evolution.abs_change)) / pip_size

        # Stats TR
        mean_tr = statistics.mean(true_ranges)
        median_tr = statistics.median(true_ranges)
        std_tr = statistics.stdev(true_ranges)
        tr_cv = std_tr / mean_tr if mean_tr > 0 else 0.0

        # Percentiles TR
        tr_percentiles = {
            "p25": float(np.percentile(true_ranges, 25)),
            "p50": median_tr,
            "p75": float(np.percentile(true_ranges, 75)),
            "p95": float(np.percentile(true_ranges, 95)),
        }

        # Expansion (spikes de vol)
        vol_spikes = sum(1 for tr in true_ranges if tr > atr * 2)
        expansion_pct = vol_spikes / len(true_ranges) * 100

        # CORRECTION 3: Forces calculées CORRECTES
        rel_change_pct = float(analysis.price_evolution.rel_change)  # -0.2
        simple_vol_pct = analysis.price_volatility.simple_vol * 100  # 0.12
        trend_strength = round((abs(rel_change_pct) / simple_vol_pct),2) if simple_vol_pct > 0 else 0.0  # 1.67
        atr_pips = atr
        # CORRECTION 4: ATR % CORRECT (pips convention)
        atr_pct = round(atr / end_price * 0.01,2)  # 6.54/0.70655 * 10000 * 0.01 = 0.092%
        max_tr_pct = max(true_ranges) / mean_tr

        # Classifications
        direction = (
            "UP"
            if analysis.price_evolution.rel_change > 0.001
            else "DOWN"
            if analysis.price_evolution.rel_change < -0.001
            else "FLAT"
        )

        vol_regime = (
            "LOW"
            if simple_vol_pct < 0.10
            else "MEDIUM"
            if simple_vol_pct < 0.20
            else "HIGH"
            if simple_vol_pct < 0.50
            else "EXTREME"
        )

        # CORRECTION 5: price_regime correct
        if expansion_pct > 25:
            price_regime = "VOLATILE"
        elif abs(analysis.price_evolution.rel_change) > 0.003:
            price_regime ="TRENDING"
        else:
            price_regime ="RANGING"

        return AnalyticsKPIs(
            asset_symbol=analysis.asset_symbol,
            time_unit=analysis.time_unit.value,
            nb_periods=analysis.nb_periods,
            start_price=float(analysis.price_evolution.start_price),
            end_price=float(analysis.price_evolution.end_price),
            rel_change_pct=rel_change_pct,
            abs_change_pips=abs_change_pips,
            trend_strength=trend_strength,
            direction=direction,
            simple_vol_pct=simple_vol_pct,
            atr_pips=atr_pips,
            atr_pct=atr_pct,
            vol_regime=vol_regime,
            mean_tr_pips=mean_tr,
            median_tr_pips=median_tr,
            std_tr_pips=std_tr,
            tr_cv=tr_cv,
            tr_percentiles=tr_percentiles,
            expansion_pct=expansion_pct,
            max_tr_pct=max_tr_pct,
            price_regime=price_regime,
        )
