class NoEntryForModelError(Exception):
    def __init__(self, model_name):
        super().__init__(f"No entry in db for {model_name}")

class PostRequestFailError(Exception):
    def __init__(self, object,model_name):
        super().__init__(f"Create failed for {object},instance of{model_name}")

class NotInEnumError(Exception):
    def __init__(self, value, enum_name):
        super().__init__(f"{value} is not a valid member of {enum_name}")