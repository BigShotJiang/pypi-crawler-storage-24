import random
from enum import Enum

from utils.exceptions import NotInEnumError


class BaseEnum(str, Enum):
    """Base enum with common helper methods."""
    def __str__(self) -> str:
        return self.value

    # TODO extract to helper clas exclusive to development and testing, not to be used in production code
    @classmethod
    def select_randomized(cls):
        return random.sample(list(cls), 1)[0]

    @classmethod
    def is_enum(cls, value: str) -> bool:
        try:
            cls(value)
            return True
        except NotInEnumError as e:
            raise NotInEnumError(value, cls.__name__) from e

def generic_select_randomized(data:dict[str,Enum]):
    return random.sample(list(data), 1)[0]
