from infrastructure_connector.models import Strategies
from infrastructure_connector.utils.enums import StrategyType

from utils.interfaces.kpis import AnalyticsKPIs


def match_analysis_strategy(
    kpis:AnalyticsKPIs,
    strategies:list[Strategies],
)->list[Strategies]:
    filtered: list[Strategies] = []
    for strat in strategies:
        if fit_strategy_by_type(strat,kpis):
            filtered.append(strat)
    return filtered

def fit_strategy_by_type(strategy:Strategies,kpis:AnalyticsKPIs):
      match strategy.strategy_type:
        case StrategyType.TREND_FOLLOWING:
            # Fort trend + faible volatilité relative
            return (
                kpis.trend_strength > 2.0 and
                kpis.vol_regime in ["LOW", "MEDIUM"] and
                kpis.price_regime == "TRENDING"
            )

        case StrategyType.RANGE_TRADING:
            # Faible trend + volatilité stable + ranging
            return (
                kpis.trend_strength < 1.5 and
                kpis.tr_cv < 0.8 and  # TR stable
                kpis.price_regime == "RANGING" and
                kpis.vol_regime == "LOW"
            )

        case StrategyType.BREAKOUT:
            # Haute expansion + volatilité croissante
            return (
                kpis.expansion_pct > 25 and
                kpis.max_tr_pct > 3.0 and
                kpis.vol_regime in ["MEDIUM", "HIGH"]
            )

        case StrategyType.MEAN_REVERSION:
            # Volatilité modérée + dispersion TR + ranging
            return (
                kpis.tr_cv > 0.5 and  # Dispersion des TR
                kpis.vol_regime == "MEDIUM" and
                kpis.price_regime == "RANGING"
            )

        case StrategyType.PRICE_ACTION:
            # Structures claires (expansion ou range serré)
            return (
                kpis.expansion_pct > 20 or
                (kpis.tr_cv < 0.6 and kpis.abs_change_pips < 20)
            )

        case StrategyType.CARRY:
            # Position trading → faible fréquence, trend modéré
            return (
                kpis.nb_periods > 100 and  # Horizon long
                kpis.trend_strength > 1.0 and
                kpis.vol_regime == "LOW"
            )

        case StrategyType.NEWS_TRADING:
            # Volatilité explosive + spikes
            return (
                kpis.expansion_pct > 35 and
                kpis.max_tr_pct > 4.0 and
                kpis.vol_regime in ["HIGH", "EXTREME"]
            )

        case StrategyType.MACRO_FX:
            # Mouvements lents + horizon long
            return (
                kpis.nb_periods > 200 and
                abs(kpis.rel_change_pct) > 0.5 and  # >0.5%
                kpis.vol_regime == "LOW"
            )
