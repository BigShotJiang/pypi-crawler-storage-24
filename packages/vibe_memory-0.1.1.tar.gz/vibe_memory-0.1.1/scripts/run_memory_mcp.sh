#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"

if [[ -x "${PROJECT_ROOT}/.venv/bin/python" ]]; then
  exec "${PROJECT_ROOT}/.venv/bin/python" -m memory_manager.cli serve-mcp --root "${PROJECT_ROOT}"
fi

exec uv run --project "${PROJECT_ROOT}" memory serve-mcp --root "${PROJECT_ROOT}"
