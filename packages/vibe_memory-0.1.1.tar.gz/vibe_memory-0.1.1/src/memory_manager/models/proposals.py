"""Proposal and curation models."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from hashlib import sha256
from typing import Any, Literal

from pydantic import BaseModel, Field, field_validator, model_validator

from memory_manager.models.schema import Card, _normalize_path


class EvidenceDigest(BaseModel):
    """Compact persisted evidence summary for a proposal batch."""

    task_summary: str = ""
    implementation_summary: str = ""
    diff_summary: str = ""
    test_summary: str = ""
    changed_paths: list[str] = Field(default_factory=list)
    file_excerpt_count: int = 0
    source_kind: str = "curation"
    source_paths: list[str] = Field(default_factory=list)
    content_hash: str

    @field_validator("changed_paths", mode="before")
    @classmethod
    def normalize_paths(cls, value: Any) -> list[str]:
        if value in (None, ""):
            return []
        if isinstance(value, str):
            return [_normalize_path(value)]
        return [_normalize_path(item) for item in value if str(item).strip()]

    @field_validator("source_paths", mode="before")
    @classmethod
    def normalize_source_paths(cls, value: Any) -> list[str]:
        if value in (None, ""):
            return []
        if isinstance(value, str):
            return [_normalize_path(value)]
        return [_normalize_path(item) for item in value if str(item).strip()]


class CurationEvidence(BaseModel):
    """Transient evidence used to suggest memory updates."""

    task_summary: str = ""
    implementation_summary: str = ""
    changed_paths: list[str] = Field(default_factory=list)
    diff_summary: str = ""
    diff_text: str = ""
    test_summary: str = ""
    file_excerpts: list[str] = Field(default_factory=list)
    source_kind: str = "curation"
    source_paths: list[str] = Field(default_factory=list)

    @field_validator("changed_paths", mode="before")
    @classmethod
    def normalize_paths(cls, value: Any) -> list[str]:
        if value in (None, ""):
            return []
        if isinstance(value, str):
            return [_normalize_path(value)]
        return [_normalize_path(item) for item in value if str(item).strip()]

    @field_validator("file_excerpts", mode="before")
    @classmethod
    def normalize_excerpts(cls, value: Any) -> list[str]:
        if value in (None, ""):
            return []
        if isinstance(value, str):
            return [value]
        return [str(item) for item in value if str(item).strip()]

    @field_validator("source_paths", mode="before")
    @classmethod
    def normalize_source_paths(cls, value: Any) -> list[str]:
        if value in (None, ""):
            return []
        if isinstance(value, str):
            return [_normalize_path(value)]
        return [_normalize_path(item) for item in value if str(item).strip()]

    def combined_text(self) -> str:
        return "\n".join(
            part.strip()
            for part in [
                self.task_summary,
                self.implementation_summary,
                self.diff_summary,
                self.diff_text,
                self.test_summary,
                *self.file_excerpts,
            ]
            if part and str(part).strip()
        )

    def to_digest(self) -> EvidenceDigest:
        payload = {
            "task_summary": self.task_summary.strip(),
            "implementation_summary": self.implementation_summary.strip(),
            "diff_summary": self.diff_summary.strip(),
            "test_summary": self.test_summary.strip(),
            "changed_paths": self.changed_paths,
            "file_excerpt_count": len(self.file_excerpts),
            "source_kind": self.source_kind,
            "source_paths": self.source_paths,
        }
        content_hash = sha256(
            (
                self.source_kind
                + "\n"
                + self.task_summary
                + self.implementation_summary
                + self.diff_summary
                + self.diff_text
                + self.test_summary
                + "\n".join(self.file_excerpts)
                + "\n".join(self.changed_paths)
                + "\n".join(self.source_paths)
            ).encode("utf-8")
        ).hexdigest()
        return EvidenceDigest.model_validate({**payload, "content_hash": content_hash})


class ProposedMemoryChange(BaseModel):
    """A single create/update/deprecate/remove action within a batch."""

    action: Literal["create", "update", "deprecate", "remove"]
    target_card_id: str
    target_revision: str | None = None
    replacement_card_id: str | None = None
    replacement_revision: str | None = None
    reason: str = Field(min_length=1)
    proposed_card: Card | None = None
    field_diff: dict[str, Any] | None = None

    @model_validator(mode="after")
    def validate_change(self) -> "ProposedMemoryChange":
        if self.action in {"create", "update"} and self.proposed_card is None:
            raise ValueError(f"{self.action} requires proposed_card")
        if self.action == "create" and self.proposed_card and self.proposed_card.id != self.target_card_id:
            raise ValueError("create target_card_id must match proposed_card.id")
        if self.action == "update" and self.proposed_card and self.proposed_card.id != self.target_card_id:
            raise ValueError("update target_card_id must match proposed_card.id")
        if self.action == "remove" and not self.replacement_card_id:
            raise ValueError("remove requires replacement_card_id")
        return self


class ProposalBatch(BaseModel):
    """A saved proposal batch awaiting approval or already decided."""

    id: str = Field(min_length=1)
    status: Literal["pending", "applied", "rejected", "expired"] = "pending"
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    changed_paths: list[str] = Field(default_factory=list)
    evidence_digest: EvidenceDigest
    changes: list[ProposedMemoryChange] = Field(default_factory=list)
    decision_note: str | None = None

    @field_validator("created_at", mode="before")
    @classmethod
    def parse_created_at(cls, value: Any) -> datetime:
        if isinstance(value, datetime):
            return value.astimezone(UTC)
        if isinstance(value, str):
            parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
            return parsed.astimezone(UTC)
        raise TypeError("created_at must be an ISO datetime string")

    @field_validator("changed_paths", mode="before")
    @classmethod
    def normalize_paths(cls, value: Any) -> list[str]:
        if value in (None, ""):
            return []
        if isinstance(value, str):
            return [_normalize_path(value)]
        return [_normalize_path(item) for item in value if str(item).strip()]

    def effective_status(self, retention_days: int, now: datetime | None = None) -> str:
        reference = now or datetime.now(UTC)
        if self.status == "pending" and reference > self.created_at + timedelta(days=retention_days):
            return "expired"
        return self.status
