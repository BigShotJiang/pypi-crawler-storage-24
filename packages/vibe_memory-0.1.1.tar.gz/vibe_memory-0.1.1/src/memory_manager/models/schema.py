"""Pydantic models for canonical workspace config and cards."""

from __future__ import annotations

from datetime import UTC, datetime
from fnmatch import fnmatch
from hashlib import sha256
import json
from typing import Any, Literal

from pydantic import BaseModel, Field, field_validator, model_validator

from memory_manager.constants import (
    DEFAULT_MAX_CHARS,
    DEFAULT_PROPOSAL_RETENTION_DAYS,
    DEFAULT_TARGETS,
    SCHEMA_VERSION,
)


def _normalize_path(value: str) -> str:
    return value.replace("\\", "/").strip("/")


class RenderDefaults(BaseModel):
    """Per-target render defaults."""

    max_chars: int = Field(default=DEFAULT_MAX_CHARS, ge=500, le=500_000)


class WorkspaceConfig(BaseModel):
    """The root configuration stored in `.memory/memory.yaml`."""

    workspace_id: str = Field(min_length=1)
    schema_version: str = Field(default=SCHEMA_VERSION)
    write_mode: Literal["propose_confirm"] = "propose_confirm"
    proposal_retention_days: int = Field(default=DEFAULT_PROPOSAL_RETENTION_DAYS, ge=1, le=365)
    render_deprecated: bool = False
    enabled_adapters: list[str] = Field(default_factory=lambda: list(DEFAULT_TARGETS))
    render_defaults: dict[str, RenderDefaults] = Field(
        default_factory=lambda: {
            target: RenderDefaults() for target in DEFAULT_TARGETS
        }
    )

    @field_validator("enabled_adapters")
    @classmethod
    def validate_enabled_adapters(cls, value: list[str]) -> list[str]:
        invalid = sorted(set(value) - set(DEFAULT_TARGETS))
        if invalid:
            raise ValueError(f"Unsupported adapters: {', '.join(invalid)}")
        return value


class Card(BaseModel):
    """Canonical memory card."""

    id: str = Field(min_length=1)
    title: str = Field(min_length=1)
    kind: str = Field(min_length=1)
    summary: str = Field(default="")
    paths: list[str] = Field(default_factory=list)
    tags: list[str] = Field(default_factory=list)
    priority: int = Field(default=50, ge=0, le=1000)
    updated_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    targets: list[str] = Field(default_factory=lambda: list(DEFAULT_TARGETS))
    status: Literal["active", "deprecated"] = "active"
    deprecated_at: datetime | None = None
    supersedes: list[str] = Field(default_factory=list)
    body: str = Field(min_length=1)
    source_path: str | None = None

    @field_validator("paths", mode="before")
    @classmethod
    def normalize_paths(cls, value: Any) -> list[str]:
        if value in (None, ""):
            return []
        if isinstance(value, str):
            return [_normalize_path(value)]
        return [_normalize_path(item) for item in value if str(item).strip()]

    @field_validator("tags", mode="before")
    @classmethod
    def normalize_tags(cls, value: Any) -> list[str]:
        if value in (None, ""):
            return []
        if isinstance(value, str):
            return [value.strip()]
        return [str(item).strip() for item in value if str(item).strip()]

    @field_validator("supersedes", mode="before")
    @classmethod
    def normalize_supersedes(cls, value: Any) -> list[str]:
        if value in (None, ""):
            return []
        if isinstance(value, str):
            return [value.strip()]
        return [str(item).strip() for item in value if str(item).strip()]

    @field_validator("targets")
    @classmethod
    def validate_targets(cls, value: list[str]) -> list[str]:
        invalid = sorted(set(value) - set(DEFAULT_TARGETS))
        if invalid:
            raise ValueError(f"Unsupported targets: {', '.join(invalid)}")
        return value

    @field_validator("updated_at", mode="before")
    @classmethod
    def parse_updated_at(cls, value: Any) -> datetime:
        if isinstance(value, datetime):
            return value.astimezone(UTC)
        if isinstance(value, str):
            parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
            return parsed.astimezone(UTC)
        raise TypeError("updated_at must be an ISO datetime string")

    @field_validator("deprecated_at", mode="before")
    @classmethod
    def parse_deprecated_at(cls, value: Any) -> datetime | None:
        if value in (None, ""):
            return None
        if isinstance(value, datetime):
            return value.astimezone(UTC)
        if isinstance(value, str):
            parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
            return parsed.astimezone(UTC)
        raise TypeError("deprecated_at must be an ISO datetime string or null")

    @model_validator(mode="after")
    def normalize_fields(self) -> "Card":
        self.body = self.body.strip()
        self.summary = self.summary.strip()
        self.tags = sorted(dict.fromkeys(self.tags))
        self.paths = list(dict.fromkeys(self.paths))
        self.targets = list(dict.fromkeys(self.targets))
        self.supersedes = list(dict.fromkeys(self.supersedes))
        if self.status == "active":
            self.deprecated_at = None
        elif self.deprecated_at is None:
            self.deprecated_at = self.updated_at
        return self

    @property
    def is_global(self) -> bool:
        return not self.paths

    @property
    def is_active(self) -> bool:
        return self.status == "active"

    def matches_target(self, target: str) -> bool:
        return target in self.targets

    def matches_path(self, candidate: str) -> bool:
        if self.is_global:
            return True
        normalized = _normalize_path(candidate)
        for pattern in self.paths:
            if fnmatch(normalized, pattern):
                return True
            if normalized.startswith(pattern.rstrip("/") + "/"):
                return True
        return False

    def clone_for_update(self, **changes: Any) -> "Card":
        """Return a copy with updated metadata and source path cleared."""
        payload = self.model_dump(mode="python")
        payload.update(changes)
        payload["source_path"] = None
        return Card.model_validate(payload)

    @property
    def revision(self) -> str:
        """Stable digest used for optimistic concurrency checks."""
        payload = {
            "id": self.id,
            "title": self.title,
            "kind": self.kind,
            "summary": self.summary,
            "paths": self.paths,
            "tags": self.tags,
            "priority": self.priority,
            "targets": self.targets,
            "status": self.status,
            "deprecated_at": self.deprecated_at.isoformat() if self.deprecated_at else None,
            "supersedes": self.supersedes,
            "body": self.body,
        }
        return sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()
