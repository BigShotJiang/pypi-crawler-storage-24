"""Existing-project bootstrap scanning and candidate extraction."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import re

from memory_manager.models import Card

DOC_PATTERNS = (
    "README.md",
    "README*.md",
    "docs/**/*.md",
    "AGENTS.md",
    "CLAUDE.md",
    ".cursor/rules/*.mdc",
    "opencode.json",
)


@dataclass(slots=True)
class BootstrapCandidate:
    source_path: str
    source_kind: str
    card: Card


def discover_bootstrap_sources(
    root: Path,
    *,
    include: list[str] | None = None,
    exclude: list[str] | None = None,
) -> list[Path]:
    patterns = include or list(DOC_PATTERNS)
    discovered: list[Path] = []
    seen: set[Path] = set()
    for pattern in patterns:
        for path in root.glob(pattern):
            if not path.is_file():
                continue
            if ".memory" in path.parts:
                continue
            relative = path.relative_to(root).as_posix()
            if exclude and any(path.match(item) or relative == item for item in exclude):
                continue
            resolved = path.resolve()
            if resolved not in seen:
                discovered.append(resolved)
                seen.add(resolved)
    return sorted(discovered)


def extract_bootstrap_candidates(root: Path, files: list[Path]) -> list[BootstrapCandidate]:
    candidates: list[BootstrapCandidate] = []
    for path in files:
        relative = path.relative_to(root).as_posix()
        text = path.read_text(encoding="utf-8").strip()
        if not text:
            continue
        kind = classify_source(relative)
        title = infer_title(relative, text)
        summary = infer_summary(text)
        body = compact_body(text, relative)
        card = Card(
            id=infer_id(relative),
            title=title,
            kind=kind,
            summary=summary,
            body=body,
            paths=infer_paths(relative, text),
            tags=infer_tags(kind, relative),
            priority=infer_priority(relative),
        )
        candidates.append(
            BootstrapCandidate(
                source_path=relative,
                source_kind=kind,
                card=card,
            )
        )
    return candidates


def classify_source(relative_path: str) -> str:
    lowered = relative_path.lower()
    if lowered.endswith("agents.md") or lowered.endswith("claude.md") or "/rules/" in lowered:
        return "convention"
    if lowered.endswith("readme.md") or lowered.startswith("docs/"):
        return "architecture"
    if lowered.endswith("opencode.json"):
        return "command"
    return "pattern"


def infer_id(relative_path: str) -> str:
    stem = relative_path.lower().replace("/", "-")
    stem = re.sub(r"[^a-z0-9-]+", "-", stem)
    return stem.strip("-")


def infer_title(relative_path: str, text: str) -> str:
    first_heading = next(
        (line.lstrip("# ").strip() for line in text.splitlines() if line.strip().startswith("#")),
        "",
    )
    if first_heading:
        return first_heading[:80]
    stem = Path(relative_path).stem.replace("-", " ").replace("_", " ").strip()
    return stem.title() or "Imported Project Memory"


def infer_summary(text: str) -> str:
    for line in text.splitlines():
        stripped = line.strip(" -#*")
        if stripped:
            return stripped[:160]
    return "Imported existing project knowledge."


def compact_body(text: str, relative_path: str) -> str:
    lines = [line.rstrip() for line in text.splitlines()]
    nonempty = [line for line in lines if line.strip()]
    excerpt = "\n".join(nonempty[:18]).strip()
    return f"Imported from `{relative_path}`.\n\n{excerpt}"


def infer_paths(relative_path: str, text: str) -> list[str]:
    if relative_path.startswith(".cursor/rules/"):
        globs = re.findall(r"globs:\s*\[(.*?)\]", text, re.IGNORECASE)
        if globs:
            raw = globs[0]
            values = [item.strip(" '\"") for item in raw.split(",") if item.strip(" '\"")]
            return values
    return []


def infer_tags(kind: str, relative_path: str) -> list[str]:
    tags = [kind]
    name = Path(relative_path).stem.lower()
    if name not in tags:
        tags.append(name)
    if relative_path.startswith("docs/") and "docs" not in tags:
        tags.append("docs")
    if relative_path.startswith(".cursor/") and "cursor" not in tags:
        tags.append("cursor")
    return sorted(dict.fromkeys(tags))


def infer_priority(relative_path: str) -> int:
    if relative_path.endswith("AGENTS.md") or relative_path.endswith("CLAUDE.md"):
        return 95
    if relative_path.endswith("README.md"):
        return 90
    if relative_path.startswith(".cursor/rules/"):
        return 85
    return 75
