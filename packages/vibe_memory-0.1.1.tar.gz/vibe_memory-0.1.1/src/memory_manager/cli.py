"""Typer CLI for memory."""

from __future__ import annotations

from pathlib import Path

import typer
import yaml

from memory_manager.exceptions import MemoryManagerError
from memory_manager.mcp_server import run_server
from memory_manager.models import CurationEvidence, ProposalBatch
from memory_manager.service import MemoryService

app = typer.Typer(add_completion=False, no_args_is_help=True)
proposals_app = typer.Typer(add_completion=False, no_args_is_help=True)
app.add_typer(proposals_app, name="proposals")


def _service(root: Path | None) -> MemoryService:
    return MemoryService(root or Path.cwd())


def _parse_csv(value: str | None) -> list[str] | None:
    if value is None or not value.strip():
        return None
    return [item.strip() for item in value.split(",") if item.strip()]


def _read_text_option(value: str, file: Path | None) -> str:
    if file is not None:
        return file.read_text(encoding="utf-8")
    return value


def _build_evidence(
    *,
    changed_paths: str | None,
    task_summary: str,
    implementation_summary: str,
    implementation_file: Path | None,
    diff_summary: str,
    diff_file: Path | None,
    test_summary: str,
    test_summary_file: Path | None,
    file_excerpts: list[str] | None = None,
) -> CurationEvidence:
    return CurationEvidence(
        task_summary=task_summary,
        implementation_summary=_read_text_option(implementation_summary, implementation_file),
        changed_paths=_parse_csv(changed_paths) or [],
        diff_summary=diff_summary,
        diff_text=_read_text_option("", diff_file),
        test_summary=_read_text_option(test_summary, test_summary_file),
        file_excerpts=file_excerpts or [],
    )


def _exit_with_error(exc: MemoryManagerError) -> None:
    typer.echo(str(exc), err=True)
    raise typer.Exit(code=1) from exc


def _print_proposal_summary(proposal: ProposalBatch) -> None:
    typer.echo(f"proposal_id: {proposal.id}")
    typer.echo(f"status: {proposal.status}")
    typer.echo(f"source_kind: {proposal.evidence_digest.source_kind}")
    typer.echo(f"changes: {len(proposal.changes)}")
    for change in proposal.changes:
        suffix = f" -> {change.replacement_card_id}" if change.replacement_card_id else ""
        typer.echo(f"- {change.action}: {change.target_card_id}{suffix} :: {change.reason}")


@app.callback()
def main() -> None:
    """Manage portable project memory for coding agents."""


@app.command("init")
def init_command(
    workspace_id: str = typer.Option("workspace", "--workspace-id"),
    force: bool = typer.Option(False, "--force"),
    root: Path | None = typer.Option(None, "--root", exists=False, file_okay=False, dir_okay=True),
) -> None:
    """Initialize `.memory/` for the current workspace."""
    try:
        config = _service(root).init(workspace_id=workspace_id, force=force)
        typer.echo(f"Initialized .memory for workspace `{config.workspace_id}`")
    except MemoryManagerError as exc:
        _exit_with_error(exc)


@app.command("bootstrap")
def bootstrap_command(
    workspace_id: str = typer.Option("workspace", "--workspace-id"),
    apply: bool = typer.Option(False, "--apply"),
    paths: str | None = typer.Option(None, "--paths", help="Comma-separated relative files to import."),
    include: list[str] = typer.Option([], "--include", help="Additional glob patterns to scan."),
    exclude: list[str] = typer.Option([], "--exclude", help="Glob patterns to skip."),
    root: Path | None = typer.Option(None, "--root", exists=False, file_okay=False, dir_okay=True),
) -> None:
    """Initialize or refresh memory proposals from an existing project."""
    try:
        proposal = _service(root).bootstrap(
            workspace_id=workspace_id,
            apply=apply,
            include=include or None,
            exclude=exclude or None,
            paths=_parse_csv(paths),
        )
        _print_proposal_summary(proposal)
    except MemoryManagerError as exc:
        _exit_with_error(exc)


@app.command("add")
def add_command(
    title: str = typer.Argument(...),
    kind: str = typer.Option(..., "--kind"),
    summary: str = typer.Option("", "--summary"),
    body: str = typer.Option("", "--body"),
    body_file: Path | None = typer.Option(None, "--body-file", exists=True, dir_okay=False),
    paths: str | None = typer.Option(None, "--paths", help="Comma-separated path globs."),
    tags: str | None = typer.Option(None, "--tags", help="Comma-separated tags."),
    priority: int = typer.Option(50, "--priority"),
    targets: str | None = typer.Option(None, "--targets", help="Comma-separated render targets."),
    card_id: str | None = typer.Option(None, "--id"),
    root: Path | None = typer.Option(None, "--root", exists=False, file_okay=False, dir_okay=True),
) -> None:
    """Create a new canonical memory card."""
    body_text = body_file.read_text(encoding="utf-8") if body_file else body
    if not body_text.strip():
        raise typer.BadParameter("Provide --body or --body-file with non-empty content.")
    try:
        card = _service(root).add_card(
            title=title,
            kind=kind,
            summary=summary,
            body=body_text,
            paths=_parse_csv(paths),
            tags=_parse_csv(tags),
            priority=priority,
            targets=_parse_csv(targets),
            card_id=card_id,
        )
        typer.echo(f"Added card `{card.id}`")
    except MemoryManagerError as exc:
        _exit_with_error(exc)


@app.command("validate")
def validate_command(
    root: Path | None = typer.Option(None, "--root", exists=False, file_okay=False, dir_okay=True),
) -> None:
    """Validate cards and rebuild the derived search index."""
    try:
        cards = _service(root).validate()
        typer.echo(f"Validated {len(cards)} cards")
    except MemoryManagerError as exc:
        _exit_with_error(exc)


@app.command("list")
def list_command(
    kind: str | None = typer.Option(None, "--kind"),
    tag: str | None = typer.Option(None, "--tag"),
    path: str | None = typer.Option(None, "--path"),
    include_deprecated: bool = typer.Option(False, "--include-deprecated"),
    root: Path | None = typer.Option(None, "--root", exists=False, file_okay=False, dir_okay=True),
) -> None:
    """List cards with optional filters."""
    try:
        cards = _service(root).list_cards(
            kind=kind,
            tag=tag,
            path=path,
            include_deprecated=include_deprecated,
        )
    except MemoryManagerError as exc:
        _exit_with_error(exc)
    for card in cards:
        typer.echo(f"{card.id}\t{card.kind}\t{card.status}\t{card.priority}\t{card.title}")


@app.command("search")
def search_command(
    query: str = typer.Argument(...),
    paths: str | None = typer.Option(None, "--paths"),
    limit: int = typer.Option(10, "--limit"),
    include_deprecated: bool = typer.Option(False, "--include-deprecated"),
    root: Path | None = typer.Option(None, "--root", exists=False, file_okay=False, dir_okay=True),
) -> None:
    """Search indexed memory cards."""
    try:
        cards = _service(root).search(
            query,
            paths=_parse_csv(paths),
            limit=limit,
            include_deprecated=include_deprecated,
        )
    except MemoryManagerError as exc:
        _exit_with_error(exc)
    for card in cards:
        typer.echo(f"{card.id}\t{card.kind}\t{card.status}\t{card.summary}")


@app.command("render")
def render_command(
    target: str = typer.Argument(...),
    paths: str | None = typer.Option(None, "--paths"),
    kinds: str | None = typer.Option(None, "--kinds"),
    format: str = typer.Option("stdout", "--format", help="stdout or dist"),
    max_chars: int | None = typer.Option(None, "--max-chars"),
    root: Path | None = typer.Option(None, "--root", exists=False, file_okay=False, dir_okay=True),
) -> None:
    """Render a target bundle from canonical cards."""
    try:
        service = _service(root)
        result = service.render(
            target,
            paths=_parse_csv(paths),
            kinds=_parse_csv(kinds),
            max_chars=max_chars,
        )
        if format == "stdout":
            for artifact in result.artifacts:
                typer.echo(f"# FILE: {artifact.relative_path}")
                typer.echo(artifact.content.rstrip())
                typer.echo("")
            return
        if format != "dist":
            raise typer.BadParameter("format must be stdout or dist")
        written = service.write_render(result)
        for path in written:
            typer.echo(str(path))
    except MemoryManagerError as exc:
        _exit_with_error(exc)


@app.command("suggest-updates")
def suggest_updates_command(
    changed_paths: str | None = typer.Option(None, "--changed-paths"),
    task_summary: str = typer.Option("", "--task-summary"),
    implementation_summary: str = typer.Option("", "--implementation-summary"),
    implementation_file: Path | None = typer.Option(None, "--implementation-file", exists=True, dir_okay=False),
    diff_summary: str = typer.Option("", "--diff-summary"),
    diff_file: Path | None = typer.Option(None, "--diff-file", exists=True, dir_okay=False),
    test_summary: str = typer.Option("", "--test-summary"),
    test_summary_file: Path | None = typer.Option(None, "--test-summary-file", exists=True, dir_okay=False),
    file_excerpt: list[str] = typer.Option([], "--file-excerpt"),
    root: Path | None = typer.Option(None, "--root", exists=False, file_okay=False, dir_okay=True),
) -> None:
    """Create a proposal batch from end-of-task evidence."""
    try:
        proposal = _service(root).suggest_updates(
            _build_evidence(
                changed_paths=changed_paths,
                task_summary=task_summary,
                implementation_summary=implementation_summary,
                implementation_file=implementation_file,
                diff_summary=diff_summary,
                diff_file=diff_file,
                test_summary=test_summary,
                test_summary_file=test_summary_file,
                file_excerpts=file_excerpt,
            )
        )
        _print_proposal_summary(proposal)
    except MemoryManagerError as exc:
        _exit_with_error(exc)


@app.command("curate")
def curate_command(
    changed_paths: str | None = typer.Option(None, "--changed-paths"),
    task_summary: str = typer.Option("", "--task-summary"),
    implementation_summary: str = typer.Option("", "--implementation-summary"),
    implementation_file: Path | None = typer.Option(None, "--implementation-file", exists=True, dir_okay=False),
    diff_summary: str = typer.Option("", "--diff-summary"),
    diff_file: Path | None = typer.Option(None, "--diff-file", exists=True, dir_okay=False),
    test_summary: str = typer.Option("", "--test-summary"),
    test_summary_file: Path | None = typer.Option(None, "--test-summary-file", exists=True, dir_okay=False),
    file_excerpt: list[str] = typer.Option([], "--file-excerpt"),
    confirm_apply: bool = typer.Option(False, "--confirm-apply"),
    root: Path | None = typer.Option(None, "--root", exists=False, file_okay=False, dir_okay=True),
) -> None:
    """Suggest memory changes and optionally apply them after explicit confirmation."""
    try:
        proposal = _service(root).curate(
            _build_evidence(
                changed_paths=changed_paths,
                task_summary=task_summary,
                implementation_summary=implementation_summary,
                implementation_file=implementation_file,
                diff_summary=diff_summary,
                diff_file=diff_file,
                test_summary=test_summary,
                test_summary_file=test_summary_file,
                file_excerpts=file_excerpt,
            ),
            confirm_apply=confirm_apply,
        )
        _print_proposal_summary(proposal)
    except MemoryManagerError as exc:
        _exit_with_error(exc)


@app.command("serve-mcp")
def serve_mcp_command(
    root: Path | None = typer.Option(None, "--root", exists=False, file_okay=False, dir_okay=True),
) -> None:
    """Run the MCP server over stdio."""
    try:
        run_server((root or Path.cwd()).resolve())
    except MemoryManagerError as exc:
        _exit_with_error(exc)


@app.command("doctor")
def doctor_command(
    root: Path | None = typer.Option(None, "--root", exists=False, file_okay=False, dir_okay=True),
) -> None:
    """Inspect workspace health without mutating native tool files."""
    try:
        report = _service(root).doctor()
    except MemoryManagerError as exc:
        _exit_with_error(exc)
    typer.echo(f"workspace_root: {report.workspace_root}")
    typer.echo(f"memory_root: {report.memory_root}")
    typer.echo(f"workspace_id: {report.config.workspace_id}")
    typer.echo(f"card_count: {report.card_count}")
    typer.echo(f"proposal_count: {report.proposal_count}")
    typer.echo(f"index_exists: {report.index_exists}")
    for name, exists in report.native_file_presence.items():
        typer.echo(f"native_present[{name}]: {exists}")


@proposals_app.command("list")
def proposals_list_command(
    root: Path | None = typer.Option(None, "--root", exists=False, file_okay=False, dir_okay=True),
) -> None:
    """List saved proposal batches."""
    try:
        proposals = _service(root).list_proposals()
    except MemoryManagerError as exc:
        _exit_with_error(exc)
    for proposal in proposals:
        typer.echo(f"{proposal.id}\t{proposal.status}\t{proposal.evidence_digest.source_kind}\t{len(proposal.changes)}\t{proposal.created_at.isoformat()}")


@proposals_app.command("show")
def proposals_show_command(
    proposal_id: str = typer.Argument(...),
    root: Path | None = typer.Option(None, "--root", exists=False, file_okay=False, dir_okay=True),
) -> None:
    """Show a saved proposal batch."""
    try:
        proposal = _service(root).get_proposal(proposal_id)
    except MemoryManagerError as exc:
        _exit_with_error(exc)
    typer.echo(yaml.safe_dump(proposal.model_dump(mode="json"), sort_keys=False, allow_unicode=False))


@proposals_app.command("apply")
def proposals_apply_command(
    proposal_id: str = typer.Argument(...),
    root: Path | None = typer.Option(None, "--root", exists=False, file_okay=False, dir_okay=True),
) -> None:
    """Apply a pending proposal batch."""
    try:
        proposal = _service(root).apply_proposal(proposal_id, confirm=True)
        _print_proposal_summary(proposal)
    except MemoryManagerError as exc:
        _exit_with_error(exc)


@proposals_app.command("reject")
def proposals_reject_command(
    proposal_id: str = typer.Argument(...),
    reason: str | None = typer.Option(None, "--reason"),
    root: Path | None = typer.Option(None, "--root", exists=False, file_okay=False, dir_okay=True),
) -> None:
    """Reject a pending proposal batch."""
    try:
        proposal = _service(root).reject_proposal(proposal_id, reason=reason)
        _print_proposal_summary(proposal)
    except MemoryManagerError as exc:
        _exit_with_error(exc)


if __name__ == "__main__":
    app()
