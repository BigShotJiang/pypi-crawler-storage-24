"""Project-wide constants."""

from __future__ import annotations

from pathlib import Path

APP_NAME = "Vibe Memory"
SCHEMA_VERSION = "1"
DEFAULT_WORKSPACE_ID = "workspace"
DEFAULT_TARGETS = ("codex", "claude", "cursor", "opencode", "generic")
DEFAULT_MAX_CHARS = 12_000
MEMORY_DIRNAME = ".memory"
CARDS_DIRNAME = "cards"
DIST_DIRNAME = "dist"
PROPOSALS_DIRNAME = "proposals"
CONFIG_FILENAME = "memory.yaml"
INDEX_FILENAME = "index.sqlite"
DEFAULT_PROPOSAL_RETENTION_DAYS = 14
NATIVE_FILES = (
    "AGENTS.md",
    "CLAUDE.md",
    ".cursor/rules",
    ".opencode",
)


def default_memory_root(root: Path) -> Path:
    """Return the canonical memory directory for a workspace."""
    return root / MEMORY_DIRNAME
