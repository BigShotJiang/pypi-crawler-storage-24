"""Renderer registry."""

from .factory import RenderResult, render_target

__all__ = ["RenderResult", "render_target"]

