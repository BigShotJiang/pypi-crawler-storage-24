"""Common rendering helpers."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from memory_manager.exceptions import RenderError
from memory_manager.models import Card, WorkspaceConfig


@dataclass(slots=True)
class RenderArtifact:
    relative_path: Path
    content: str


@dataclass(slots=True)
class RenderContext:
    target: str
    config: WorkspaceConfig
    cards: list[Card]
    paths: list[str]
    max_chars: int


class Renderer:
    """Base renderer for an agent target."""

    target: str

    def render(self, context: RenderContext) -> list[RenderArtifact]:
        raise NotImplementedError

    def ensure_enabled(self, context: RenderContext) -> None:
        if self.target not in context.config.enabled_adapters:
            raise RenderError(f"Target `{self.target}` is disabled in memory.yaml")


def trim_to_budget(context: RenderContext, chunks: list[str]) -> str:
    """Trim rendered Markdown to the configured character budget."""
    assembled: list[str] = []
    consumed = 0
    for chunk in chunks:
        normalized = chunk.strip()
        if not normalized:
            continue
        if consumed + len(chunk) <= context.max_chars:
            assembled.append(normalized)
            consumed += len(normalized)
            continue
        remaining = context.max_chars - consumed
        if remaining > 80:
            assembled.append(normalized[: remaining - 1].rstrip())
        break
    return "\n\n".join(assembled).strip() + "\n"
