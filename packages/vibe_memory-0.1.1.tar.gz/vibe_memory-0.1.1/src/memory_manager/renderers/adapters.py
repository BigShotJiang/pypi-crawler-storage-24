"""Agent-specific renderers."""

from __future__ import annotations

from pathlib import Path

from memory_manager.models import Card
from memory_manager.renderers.base import RenderArtifact, RenderContext, Renderer, trim_to_budget


def _card_sections(cards: list[Card], include_paths: bool) -> list[str]:
    sections: list[str] = []
    for card in cards:
        lines = [
            f"## {card.title}",
            "",
            f"- id: `{card.id}`",
            f"- kind: `{card.kind}`",
            f"- priority: `{card.priority}`",
        ]
        if card.summary:
            lines.append(f"- summary: {card.summary}")
        if include_paths and card.paths:
            lines.append(f"- paths: {', '.join(f'`{path}`' for path in card.paths)}")
        if card.tags:
            lines.append(f"- tags: {', '.join(f'`{tag}`' for tag in card.tags)}")
        lines.extend(["", card.body.strip(), ""])
        sections.append("\n".join(lines))
    return sections


def _curation_guidance(context: RenderContext) -> str:
    return (
        "# Memory Curation\n\n"
        "At the end of a feature task:\n"
        "1. Call `memory.suggest_updates` or `memory suggest-updates` with changed paths and concise summaries.\n"
        "2. Present the proposal batch to the user.\n"
        "3. Only after explicit approval, call `memory.apply_proposal` or `memory proposals apply`.\n"
        "4. Never write root `AGENTS.md`, `CLAUDE.md`, `.cursor/rules`, or `.opencode/*` directly.\n"
    )


def _header(target_name: str, context: RenderContext) -> str:
    scope = ", ".join(f"`{path}`" for path in context.paths) if context.paths else "all paths"
    return (
        f"# {target_name} Memory Bundle\n\n"
        "This file is generated from `.memory/cards/*.md`.\n\n"
        f"Scope: {scope}\n"
        f"Budget: {context.max_chars} characters\n"
    )


class CodexRenderer(Renderer):
    target = "codex"

    def render(self, context: RenderContext) -> list[RenderArtifact]:
        content = trim_to_budget(
            context,
            [_header("AGENTS.md", context), *_card_sections(context.cards, include_paths=True)],
        )
        return [
            RenderArtifact(Path("AGENTS.md"), content),
            RenderArtifact(Path("MEMORY_CURATION.md"), _curation_guidance(context)),
        ]


class OpenCodeRenderer(Renderer):
    target = "opencode"

    def render(self, context: RenderContext) -> list[RenderArtifact]:
        content = trim_to_budget(
            context,
            [_header("OpenCode AGENTS.md", context), *_card_sections(context.cards, include_paths=True)],
        )
        return [
            RenderArtifact(Path("AGENTS.md"), content),
            RenderArtifact(Path("MEMORY_CURATION.md"), _curation_guidance(context)),
        ]


class ClaudeRenderer(Renderer):
    target = "claude"

    def render(self, context: RenderContext) -> list[RenderArtifact]:
        global_cards = [card for card in context.cards if card.is_global]
        scoped_cards = [card for card in context.cards if not card.is_global]
        artifacts = [
            RenderArtifact(
                Path("CLAUDE.md"),
                trim_to_budget(
                    context,
                    [_header("CLAUDE.md", context), *_card_sections(global_cards, include_paths=False)],
                ),
            )
        ]
        for card in scoped_cards:
            slug = card.id.replace("_", "-")
            content = trim_to_budget(
                context,
                [
                    _header(f"Claude rule: {card.title}", context),
                    *_card_sections([card], include_paths=True),
                ],
            )
            artifacts.append(RenderArtifact(Path(".claude/rules") / f"{slug}.md", content))
        artifacts.append(RenderArtifact(Path("MEMORY_CURATION.md"), _curation_guidance(context)))
        return artifacts


class CursorRenderer(Renderer):
    target = "cursor"

    def render(self, context: RenderContext) -> list[RenderArtifact]:
        artifacts = [
            RenderArtifact(
                Path("AGENTS.md"),
                trim_to_budget(
                    context,
                    [_header("Cursor AGENTS.md", context), *_card_sections(context.cards, include_paths=True)],
                ),
            )
        ]
        for card in context.cards:
            if card.is_global:
                metadata = ["---", "description: Shared project memory", "alwaysApply: true", "---", ""]
            else:
                metadata = [
                    "---",
                    f"description: {card.summary or card.title}",
                    "alwaysApply: false",
                    f"globs: [{', '.join(card.paths)}]",
                    "---",
                    "",
                ]
            body = trim_to_budget(
                context,
                ["\n".join(metadata), *_card_sections([card], include_paths=True)],
            )
            artifacts.append(
                RenderArtifact(Path(".cursor/rules") / f"{card.id}.mdc", body)
            )
        artifacts.append(RenderArtifact(Path("MEMORY_CURATION.md"), _curation_guidance(context)))
        return artifacts


class GenericRenderer(Renderer):
    target = "generic"

    def render(self, context: RenderContext) -> list[RenderArtifact]:
        content = trim_to_budget(
            context,
            [_header("Generic Memory Bundle", context), *_card_sections(context.cards, include_paths=True)],
        )
        return [
            RenderArtifact(Path("memory.md"), content),
            RenderArtifact(Path("MEMORY_CURATION.md"), _curation_guidance(context)),
        ]
