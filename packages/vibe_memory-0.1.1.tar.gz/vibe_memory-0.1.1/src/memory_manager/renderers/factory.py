"""Renderer registry and result container."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from memory_manager.exceptions import RenderError
from memory_manager.models import Card, WorkspaceConfig
from memory_manager.renderers.adapters import (
    ClaudeRenderer,
    CodexRenderer,
    CursorRenderer,
    GenericRenderer,
    OpenCodeRenderer,
)
from memory_manager.renderers.base import RenderArtifact, RenderContext, Renderer


@dataclass(slots=True)
class RenderResult:
    target: str
    artifacts: list[RenderArtifact]


REGISTRY: dict[str, Renderer] = {
    "codex": CodexRenderer(),
    "claude": ClaudeRenderer(),
    "cursor": CursorRenderer(),
    "opencode": OpenCodeRenderer(),
    "generic": GenericRenderer(),
}


def render_target(
    target: str,
    *,
    config: WorkspaceConfig,
    cards: list[Card],
    paths: list[str] | None = None,
    max_chars: int | None = None,
) -> RenderResult:
    renderer = REGISTRY.get(target)
    if renderer is None:
        raise RenderError(f"Unsupported target `{target}`")
    budget = max_chars or config.render_defaults[target].max_chars
    context = RenderContext(
        target=target,
        config=config,
        cards=cards,
        paths=paths or [],
        max_chars=budget,
    )
    renderer.ensure_enabled(context)
    return RenderResult(target=target, artifacts=renderer.render(context))


def write_render_result(output_dir: Path, result: RenderResult) -> list[Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    written: list[Path] = []
    for artifact in result.artifacts:
        destination = output_dir / artifact.relative_path
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(artifact.content, encoding="utf-8")
        written.append(destination)
    return written

