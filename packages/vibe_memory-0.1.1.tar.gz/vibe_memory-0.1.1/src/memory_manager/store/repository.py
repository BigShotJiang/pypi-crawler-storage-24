"""Canonical repository and rebuildable SQLite FTS index."""

from __future__ import annotations

import os
import shutil
import sqlite3
from datetime import UTC, datetime
from pathlib import Path
from typing import Iterable

import yaml

from memory_manager.constants import (
    CARDS_DIRNAME,
    CONFIG_FILENAME,
    DEFAULT_MAX_CHARS,
    DEFAULT_WORKSPACE_ID,
    DIST_DIRNAME,
    INDEX_FILENAME,
    PROPOSALS_DIRNAME,
    default_memory_root,
)
from memory_manager.exceptions import ConfigNotFoundError, ProposalError, ValidationError
from memory_manager.markdown import parse_card_file, serialize_card
from memory_manager.models import Card, ProposalBatch, WorkspaceConfig


class MemoryRepository:
    """Read and write canonical workspace memory state."""

    def __init__(self, workspace_root: Path) -> None:
        self.workspace_root = workspace_root.resolve()
        self.memory_root = default_memory_root(self.workspace_root)
        self.cards_dir = self.memory_root / CARDS_DIRNAME
        self.dist_dir = self.memory_root / DIST_DIRNAME
        self.proposals_dir = self.memory_root / PROPOSALS_DIRNAME
        self.config_path = self.memory_root / CONFIG_FILENAME
        self.index_path = self.memory_root / INDEX_FILENAME

    def exists(self) -> bool:
        return self.config_path.exists()

    def init_workspace(self, workspace_id: str | None = None, force: bool = False) -> WorkspaceConfig:
        if self.exists() and not force:
            raise ValidationError(f"Workspace already initialized at {self.memory_root}")

        self.cards_dir.mkdir(parents=True, exist_ok=True)
        self.dist_dir.mkdir(parents=True, exist_ok=True)
        self.proposals_dir.mkdir(parents=True, exist_ok=True)
        config = WorkspaceConfig(workspace_id=workspace_id or DEFAULT_WORKSPACE_ID)
        self.write_config(config)
        sample = Card(
            id="architecture-overview",
            title="Architecture overview",
            kind="architecture",
            summary="High-level system shape and constraints.",
            tags=["architecture", "overview"],
            priority=100,
            body=(
                "Document the project architecture, primary workflows, and constraints here.\n\n"
                "- Record system boundaries.\n"
                "- Note critical commands.\n"
                "- Capture important caveats for agents."
            ),
        )
        self.write_card(sample, overwrite=False)
        self.rebuild_index()
        return config

    def load_config(self) -> WorkspaceConfig:
        if not self.config_path.exists():
            raise ConfigNotFoundError(
                f"No memory workspace found at {self.memory_root}. Run `memory init` first."
            )
        data = yaml.safe_load(self.config_path.read_text(encoding="utf-8")) or {}
        try:
            return WorkspaceConfig.model_validate(data)
        except Exception as exc:
            raise ValidationError(f"Invalid config file {self.config_path}: {exc}") from exc

    def write_config(self, config: WorkspaceConfig) -> None:
        self.memory_root.mkdir(parents=True, exist_ok=True)
        payload = yaml.safe_dump(
            config.model_dump(mode="json"),
            sort_keys=False,
            allow_unicode=False,
        )
        self.config_path.write_text(payload, encoding="utf-8")

    def load_cards(self) -> list[Card]:
        self.load_config()
        cards: list[Card] = []
        seen: dict[str, Path] = {}
        for path in sorted(self.cards_dir.glob("*.md")):
            card = parse_card_file(path)
            if card.id in seen:
                raise ValidationError(
                    f"Duplicate card id `{card.id}` in {seen[card.id]} and {path}"
                )
            seen[card.id] = path
            cards.append(card)
        return cards

    def write_card(self, card: Card, overwrite: bool = False) -> Path:
        self.cards_dir.mkdir(parents=True, exist_ok=True)
        destination = self.cards_dir / f"{card.id}.md"
        if destination.exists() and not overwrite:
            raise ValidationError(f"Card already exists at {destination}")
        destination.write_text(serialize_card(card), encoding="utf-8")
        return destination

    def card_path(self, card_id: str) -> Path:
        return self.cards_dir / f"{card_id}.md"

    def replace_cards(self, cards: Iterable[Card]) -> None:
        final_cards = list(cards)
        tmp_dir = self.memory_root / ".cards.tmp"
        backup_dir = self.memory_root / ".cards.backup"
        if tmp_dir.exists():
            shutil.rmtree(tmp_dir)
        if backup_dir.exists():
            shutil.rmtree(backup_dir)
        tmp_dir.mkdir(parents=True, exist_ok=True)
        try:
            for card in final_cards:
                (tmp_dir / f"{card.id}.md").write_text(serialize_card(card), encoding="utf-8")
            if self.cards_dir.exists():
                os.replace(self.cards_dir, backup_dir)
            os.replace(tmp_dir, self.cards_dir)
            if backup_dir.exists():
                shutil.rmtree(backup_dir)
            self.rebuild_index(final_cards)
        except Exception:
            if self.cards_dir.exists() and not any(self.cards_dir.iterdir()) and backup_dir.exists():
                shutil.rmtree(self.cards_dir)
            if backup_dir.exists() and not self.cards_dir.exists():
                os.replace(backup_dir, self.cards_dir)
            if tmp_dir.exists():
                shutil.rmtree(tmp_dir)
            raise

    def validate(self) -> list[Card]:
        cards = self.load_cards()
        self.load_config()
        return cards

    def rebuild_index(self, cards: Iterable[Card] | None = None) -> None:
        loaded_cards = list(cards) if cards is not None else self.load_cards()
        self.index_path.parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(self.index_path) as connection:
            connection.execute("DROP TABLE IF EXISTS cards")
            connection.execute("DROP TABLE IF EXISTS cards_fts")
            connection.execute(
                """
                CREATE TABLE cards (
                    id TEXT PRIMARY KEY,
                    title TEXT NOT NULL,
                    kind TEXT NOT NULL,
                    summary TEXT NOT NULL,
                    body TEXT NOT NULL,
                    paths TEXT NOT NULL,
                    tags TEXT NOT NULL,
                    priority INTEGER NOT NULL,
                    updated_at TEXT NOT NULL,
                    targets TEXT NOT NULL,
                    status TEXT NOT NULL,
                    deprecated_at TEXT,
                    supersedes TEXT NOT NULL,
                    source_path TEXT
                )
                """
            )
            connection.execute(
                """
                CREATE VIRTUAL TABLE cards_fts USING fts5(
                    id,
                    title,
                    kind,
                    summary,
                    body,
                    tags,
                    content='cards',
                    content_rowid='rowid'
                )
                """
            )
            for card in loaded_cards:
                cursor = connection.execute(
                    """
                    INSERT INTO cards (
                        id, title, kind, summary, body, paths, tags,
                        priority, updated_at, targets, status, deprecated_at,
                        supersedes, source_path
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        card.id,
                        card.title,
                        card.kind,
                        card.summary,
                        card.body,
                        "\n".join(card.paths),
                        "\n".join(card.tags),
                        card.priority,
                        card.updated_at.isoformat(),
                        "\n".join(card.targets),
                        card.status,
                        card.deprecated_at.isoformat() if card.deprecated_at else None,
                        "\n".join(card.supersedes),
                        card.source_path,
                    ),
                )
                rowid = cursor.lastrowid
                connection.execute(
                    """
                    INSERT INTO cards_fts(rowid, id, title, kind, summary, body, tags)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        rowid,
                        card.id,
                        card.title,
                        card.kind,
                        card.summary,
                        card.body,
                        " ".join(card.tags),
                    ),
                )
            connection.commit()

    def search(
        self,
        query: str,
        *,
        paths: list[str] | None = None,
        limit: int = 10,
        include_deprecated: bool = False,
    ) -> list[Card]:
        cards = {card.id: card for card in self.load_cards()}
        if not self.index_path.exists():
            self.rebuild_index(cards.values())
        with sqlite3.connect(self.index_path) as connection:
            rows = connection.execute(
                """
                SELECT c.id
                FROM cards_fts f
                JOIN cards c ON c.rowid = f.rowid
                WHERE cards_fts MATCH ?
                ORDER BY bm25(cards_fts), c.priority DESC
                LIMIT ?
                """,
                (query, limit * 3),
            ).fetchall()
        results = [cards[row[0]] for row in rows if row[0] in cards]
        if not include_deprecated:
            results = [card for card in results if card.is_active]
        if paths:
            results = [
                card for card in results if card.is_global or any(card.matches_path(path) for path in paths)
            ]
        return results[:limit]

    def proposal_path(self, proposal_id: str) -> Path:
        return self.proposals_dir / f"{proposal_id}.yaml"

    def write_proposal(self, proposal: ProposalBatch) -> Path:
        self.proposals_dir.mkdir(parents=True, exist_ok=True)
        destination = self.proposal_path(proposal.id)
        destination.write_text(
            yaml.safe_dump(proposal.model_dump(mode="json"), sort_keys=False, allow_unicode=False),
            encoding="utf-8",
        )
        return destination

    def load_proposal(self, proposal_id: str) -> ProposalBatch:
        path = self.proposal_path(proposal_id)
        if not path.exists():
            raise ProposalError(f"Unknown proposal `{proposal_id}`")
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        try:
            return ProposalBatch.model_validate(data)
        except Exception as exc:
            raise ProposalError(f"Invalid proposal file {path}: {exc}") from exc

    def list_proposals(self) -> list[ProposalBatch]:
        self.load_config()
        proposals: list[ProposalBatch] = []
        for path in sorted(self.proposals_dir.glob("*.yaml"), reverse=True):
            data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
            proposals.append(ProposalBatch.model_validate(data))
        return sorted(proposals, key=lambda proposal: proposal.created_at, reverse=True)

    def index_health(self) -> dict[str, str | int | bool]:
        cards = self.load_cards()
        return {
            "index_exists": self.index_path.exists(),
            "card_count": len(cards),
            "proposal_count": len(list(self.proposals_dir.glob("*.yaml"))) if self.proposals_dir.exists() else 0,
            "last_checked_at": datetime.now(UTC).isoformat(),
            "default_max_chars": self.load_config().render_defaults.get(
                "generic", {"max_chars": DEFAULT_MAX_CHARS}
            ).max_chars,
        }
