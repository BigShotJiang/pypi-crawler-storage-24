"""FastMCP server exposing workspace memory and gated curation tools."""

from __future__ import annotations

from pathlib import Path
from typing import Annotated

from mcp.server.fastmcp import FastMCP

from memory_manager.models import CurationEvidence
from memory_manager.service import MemoryService


def build_server(workspace_root: Path) -> FastMCP:
    service = MemoryService(workspace_root)
    mcp = FastMCP(
        "vibe-memory",
        instructions=(
            "Use this server to read shared project memory and manage proposal-based updates. "
            "For existing projects, use memory.bootstrap to import docs and rules into reviewable cards. "
            "Keep native tool files procedural and fetch canonical memory on demand. "
            "Never apply a proposal without explicit user approval."
        ),
        json_response=True,
    )

    @mcp.resource("memory://workspace")
    def workspace_metadata() -> str:
        report = service.doctor()
        adapters = ", ".join(report.config.enabled_adapters)
        return (
            f"workspace_root: {report.workspace_root}\n"
            f"memory_root: {report.memory_root}\n"
            f"workspace_id: {report.config.workspace_id}\n"
            f"schema_version: {report.config.schema_version}\n"
            f"write_mode: {report.config.write_mode}\n"
            f"enabled_adapters: {adapters}\n"
            f"card_count: {report.card_count}\n"
            f"proposal_count: {report.proposal_count}\n"
            f"index_exists: {report.index_exists}\n"
        )

    @mcp.prompt(title="Load shared project memory")
    def load_shared_project_memory(
        paths: Annotated[list[str] | None, "Optional relevant workspace paths"] = None,
        kinds: Annotated[list[str] | None, "Optional memory kinds to include"] = None,
    ) -> str:
        return (
            "Load shared project memory before responding. "
            f"Use paths={paths or []} and kinds={kinds or []} when calling memory.get_context."
        )

    @mcp.prompt(title="Bootstrap existing project memory")
    def bootstrap_existing_project_memory() -> str:
        return (
            "For an existing repository without good canonical memory, call memory.bootstrap first. "
            "Review the proposal batch, then apply it only after explicit user approval."
        )

    @mcp.prompt(title="Curate project memory after a task")
    def curate_project_memory(
        changed_paths: Annotated[list[str] | None, "Relevant changed paths"] = None,
    ) -> str:
        return (
            "At task end, call memory.suggest_updates with changed_paths and concise summaries. "
            "Present any proposal batch to the user. Only after explicit approval, call "
            "memory.apply_proposal with confirm=true."
        )

    @mcp.tool(name="memory.get_context")
    def get_context(
        paths: list[str] | None = None,
        kinds: list[str] | None = None,
        max_chars: int | None = None,
    ) -> dict[str, str | list[str]]:
        return {
            "target": "generic",
            "paths": paths or [],
            "content": service.get_context(
                target="generic", paths=paths, kinds=kinds, max_chars=max_chars
            ),
        }

    @mcp.tool(name="memory.search")
    def search(
        query: str,
        paths: list[str] | None = None,
        limit: int = 10,
    ) -> list[dict[str, str | int | list[str]]]:
        cards = service.search(query, paths=paths, limit=limit)
        return [
            {
                "id": card.id,
                "title": card.title,
                "kind": card.kind,
                "summary": card.summary,
                "paths": card.paths,
                "priority": card.priority,
                "status": card.status,
            }
            for card in cards
        ]

    @mcp.tool(name="memory.list_cards")
    def list_cards(
        kind: str | None = None,
        tag: str | None = None,
        path: str | None = None,
        include_deprecated: bool = False,
    ) -> list[dict[str, str | int | list[str]]]:
        cards = service.list_cards(
            kind=kind,
            tag=tag,
            path=path,
            include_deprecated=include_deprecated,
        )
        return [
            {
                "id": card.id,
                "title": card.title,
                "kind": card.kind,
                "summary": card.summary,
                "paths": card.paths,
                "tags": card.tags,
                "priority": card.priority,
                "status": card.status,
            }
            for card in cards
        ]

    @mcp.tool(name="memory.render")
    def render(
        target: str,
        paths: list[str] | None = None,
        max_chars: int | None = None,
    ) -> dict[str, object]:
        result = service.render(target=target, paths=paths, max_chars=max_chars)
        return {
            "target": target,
            "artifacts": [
                {"path": str(artifact.relative_path), "content": artifact.content}
                for artifact in result.artifacts
            ],
        }

    @mcp.tool(name="memory.bootstrap")
    def bootstrap(
        workspace_id: str = "workspace",
        apply: bool = False,
        paths: list[str] | None = None,
        include: list[str] | None = None,
        exclude: list[str] | None = None,
    ) -> dict[str, object]:
        proposal = service.bootstrap(
            workspace_id=workspace_id,
            apply=apply,
            paths=paths,
            include=include,
            exclude=exclude,
        )
        return proposal.model_dump(mode="json")

    @mcp.tool(name="memory.suggest_updates")
    def suggest_updates(
        changed_paths: list[str] | None = None,
        task_summary: str = "",
        implementation_summary: str = "",
        diff_summary: str = "",
        diff_text: str = "",
        test_summary: str = "",
        file_excerpts: list[str] | None = None,
    ) -> dict[str, object]:
        proposal = service.suggest_updates(
            CurationEvidence(
                task_summary=task_summary,
                implementation_summary=implementation_summary,
                changed_paths=changed_paths or [],
                diff_summary=diff_summary,
                diff_text=diff_text,
                test_summary=test_summary,
                file_excerpts=file_excerpts or [],
            )
        )
        return proposal.model_dump(mode="json")

    @mcp.tool(name="memory.list_proposals")
    def list_proposals() -> list[dict[str, object]]:
        return [proposal.model_dump(mode="json") for proposal in service.list_proposals()]

    @mcp.tool(name="memory.show_proposal")
    def show_proposal(proposal_id: str) -> dict[str, object]:
        return service.get_proposal(proposal_id).model_dump(mode="json")

    @mcp.tool(name="memory.apply_proposal")
    def apply_proposal(proposal_id: str, confirm: bool = False) -> dict[str, object]:
        return service.apply_proposal(proposal_id, confirm=confirm).model_dump(mode="json")

    @mcp.tool(name="memory.reject_proposal")
    def reject_proposal(proposal_id: str, reason: str | None = None) -> dict[str, object]:
        return service.reject_proposal(proposal_id, reason=reason).model_dump(mode="json")

    return mcp


def run_server(workspace_root: Path) -> None:
    server = build_server(workspace_root)
    server.run()
