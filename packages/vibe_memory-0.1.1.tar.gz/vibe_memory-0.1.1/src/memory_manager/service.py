"""High-level service orchestration."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
import re
from re import sub
from uuid import uuid4

from memory_manager.bootstrap import (
    BootstrapCandidate,
    discover_bootstrap_sources,
    extract_bootstrap_candidates,
)
from memory_manager.constants import NATIVE_FILES
from memory_manager.exceptions import ProposalError
from memory_manager.models import Card, CurationEvidence, ProposalBatch, ProposedMemoryChange, WorkspaceConfig
from memory_manager.renderers import RenderResult, render_target
from memory_manager.renderers.factory import write_render_result
from memory_manager.store import MemoryRepository

TOKEN_RE = re.compile(r"[a-z0-9][a-z0-9_-]{2,}")
REMOVE_RE = re.compile(r"(?:memory:)?remove[: ]([a-z0-9-]+)\s*(?:->|to)\s*([a-z0-9-]+)")
DEPRECATE_RE = re.compile(r"(?:memory:)?deprecat(?:e|ed)[: ]([a-z0-9-]+)")


def _slugify(value: str) -> str:
    lowered = value.strip().lower()
    lowered = sub(r"[^a-z0-9]+", "-", lowered)
    return lowered.strip("-") or "memory-card"


def _tokens(value: str) -> set[str]:
    return set(TOKEN_RE.findall(value.lower()))


@dataclass(slots=True)
class DoctorReport:
    workspace_root: Path
    memory_root: Path
    config: WorkspaceConfig
    card_count: int
    proposal_count: int
    index_exists: bool
    native_file_presence: dict[str, bool]


class MemoryService:
    """Facade for CLI and MCP entry points."""

    def __init__(self, workspace_root: Path) -> None:
        self.repository = MemoryRepository(workspace_root)

    @property
    def workspace_root(self) -> Path:
        return self.repository.workspace_root

    def init(self, workspace_id: str | None = None, force: bool = False) -> WorkspaceConfig:
        return self.repository.init_workspace(workspace_id=workspace_id, force=force)

    def validate(self) -> list[Card]:
        cards = self.repository.validate()
        self.repository.rebuild_index(cards)
        return cards

    def list_cards(
        self,
        *,
        kind: str | None = None,
        tag: str | None = None,
        path: str | None = None,
        include_deprecated: bool = False,
    ) -> list[Card]:
        cards = self.repository.load_cards()
        filtered = []
        for card in cards:
            if not include_deprecated and not card.is_active:
                continue
            if kind and card.kind != kind:
                continue
            if tag and tag not in card.tags:
                continue
            if path and not card.matches_path(path):
                continue
            filtered.append(card)
        return self._sort_cards(filtered, selected_paths=[path] if path else None)

    def add_card(
        self,
        *,
        title: str,
        kind: str,
        summary: str,
        body: str,
        paths: list[str] | None = None,
        tags: list[str] | None = None,
        priority: int = 50,
        targets: list[str] | None = None,
        card_id: str | None = None,
    ) -> Card:
        config = self.repository.load_config()
        card = Card(
            id=card_id or _slugify(title),
            title=title,
            kind=kind,
            summary=summary,
            body=body,
            paths=paths or [],
            tags=tags or [],
            priority=priority,
            targets=targets or list(config.enabled_adapters),
            updated_at=datetime.now(UTC),
        )
        self.repository.write_card(card)
        self.repository.rebuild_index()
        return card

    def search(
        self,
        query: str,
        *,
        paths: list[str] | None = None,
        limit: int = 10,
        include_deprecated: bool = False,
    ) -> list[Card]:
        return self.repository.search(
            query,
            paths=paths,
            limit=limit,
            include_deprecated=include_deprecated,
        )

    def get_context(
        self,
        *,
        target: str = "generic",
        paths: list[str] | None = None,
        kinds: list[str] | None = None,
        max_chars: int | None = None,
    ) -> str:
        cards = self.select_cards(target=target, paths=paths, kinds=kinds)
        result = render_target(
            target,
            config=self.repository.load_config(),
            cards=cards,
            paths=paths,
            max_chars=max_chars,
        )
        return "\n\n".join(artifact.content.strip() for artifact in result.artifacts if artifact.content.strip())

    def render(
        self,
        target: str,
        *,
        paths: list[str] | None = None,
        kinds: list[str] | None = None,
        max_chars: int | None = None,
    ) -> RenderResult:
        cards = self.select_cards(target=target, paths=paths, kinds=kinds)
        config = self.repository.load_config()
        return render_target(
            target,
            config=config,
            cards=cards,
            paths=paths,
            max_chars=max_chars,
        )

    def write_render(self, result: RenderResult) -> list[Path]:
        output_dir = self.repository.dist_dir / result.target
        return write_render_result(output_dir, result)

    def doctor(self) -> DoctorReport:
        cards = self.repository.load_cards() if self.repository.exists() else []
        config = self.repository.load_config() if self.repository.exists() else WorkspaceConfig(workspace_id="uninitialized")
        proposal_count = len(self.repository.list_proposals()) if self.repository.proposals_dir.exists() else 0
        return DoctorReport(
            workspace_root=self.repository.workspace_root,
            memory_root=self.repository.memory_root,
            config=config,
            card_count=len(cards),
            proposal_count=proposal_count,
            index_exists=self.repository.index_path.exists(),
            native_file_presence={
                native: (self.repository.workspace_root / native).exists() for native in NATIVE_FILES
            },
        )

    def select_cards(
        self,
        *,
        target: str,
        paths: list[str] | None = None,
        kinds: list[str] | None = None,
        include_deprecated: bool | None = None,
    ) -> list[Card]:
        config = self.repository.load_config()
        cards = self.repository.load_cards()
        include_deprecated = config.render_deprecated if include_deprecated is None else include_deprecated
        filtered: list[Card] = []
        for card in cards:
            if not include_deprecated and not card.is_active:
                continue
            if not card.matches_target(target):
                continue
            if kinds and card.kind not in kinds:
                continue
            if paths and not (card.is_global or any(card.matches_path(path) for path in paths)):
                continue
            filtered.append(card)
        return self._sort_cards(filtered, selected_paths=paths)

    def suggest_updates(self, evidence: CurationEvidence) -> ProposalBatch:
        self.repository.load_config()
        changes = self._generate_proposed_changes(evidence)
        proposal = ProposalBatch(
            id=f"proposal-{datetime.now(UTC).strftime('%Y%m%d%H%M%S')}-{uuid4().hex[:8]}",
            status="pending",
            created_at=datetime.now(UTC),
            changed_paths=evidence.changed_paths,
            evidence_digest=evidence.to_digest(),
            changes=changes,
        )
        self.repository.write_proposal(proposal)
        return proposal

    def bootstrap(
        self,
        *,
        workspace_id: str | None = None,
        apply: bool = False,
        include: list[str] | None = None,
        exclude: list[str] | None = None,
        paths: list[str] | None = None,
    ) -> ProposalBatch:
        if not self.repository.exists():
            self.repository.init_workspace(workspace_id=workspace_id, force=False)
        files = discover_bootstrap_sources(
            self.workspace_root,
            include=include,
            exclude=exclude,
        )
        if paths:
            normalized = {Path(path).as_posix().lstrip("./") for path in paths}
            files = [path for path in files if path.relative_to(self.workspace_root).as_posix() in normalized]
        candidates = extract_bootstrap_candidates(self.workspace_root, files)
        proposal = self._build_bootstrap_proposal(candidates)
        self.repository.write_proposal(proposal)
        if apply:
            return self.apply_proposal(proposal.id, confirm=True)
        return proposal

    def list_proposals(self) -> list[ProposalBatch]:
        proposals = self.repository.list_proposals()
        return [self._refresh_proposal_status(proposal) for proposal in proposals]

    def get_proposal(self, proposal_id: str) -> ProposalBatch:
        return self._refresh_proposal_status(self.repository.load_proposal(proposal_id))

    def reject_proposal(self, proposal_id: str, *, reason: str | None = None) -> ProposalBatch:
        proposal = self._refresh_proposal_status(self.repository.load_proposal(proposal_id))
        if proposal.status != "pending":
            raise ProposalError(f"Proposal `{proposal_id}` is not pending")
        rejected = proposal.model_copy(update={"status": "rejected", "decision_note": reason})
        self.repository.write_proposal(rejected)
        return rejected

    def apply_proposal(self, proposal_id: str, *, confirm: bool = False) -> ProposalBatch:
        if not confirm:
            raise ProposalError("Applying a proposal requires explicit confirmation")
        proposal = self._refresh_proposal_status(self.repository.load_proposal(proposal_id))
        if proposal.status != "pending":
            raise ProposalError(f"Proposal `{proposal_id}` is not pending")

        cards = {card.id: card for card in self.repository.load_cards()}
        now = datetime.now(UTC)
        for change in proposal.changes:
            target = cards.get(change.target_card_id)
            if change.action == "create":
                if change.target_card_id in cards:
                    raise ProposalError(f"Proposal `{proposal_id}` is inconsistent: card already exists")
                cards[change.target_card_id] = change.proposed_card.model_copy(
                    update={"updated_at": now, "source_path": None, "status": "active", "deprecated_at": None}
                )
                continue
            if target is None:
                raise ProposalError(
                    f"Proposal `{proposal_id}` is inconsistent: missing card `{change.target_card_id}`"
                )
            if not change.target_revision:
                raise ProposalError(
                    f"Proposal `{proposal_id}` is missing revision metadata for `{change.target_card_id}`; regenerate it"
                )
            if change.target_revision != target.revision:
                raise ProposalError(
                    f"Proposal `{proposal_id}` is stale: card `{change.target_card_id}` changed after proposal creation"
                )
            if change.action == "update":
                if change.proposed_card is None:
                    raise ProposalError(f"Proposal `{proposal_id}` is inconsistent: update missing proposed card")
                cards[target.id] = change.proposed_card.model_copy(
                    update={"updated_at": now, "source_path": None, "status": "active", "deprecated_at": None}
                )
            elif change.action == "deprecate":
                cards[target.id] = target.clone_for_update(
                    status="deprecated",
                    deprecated_at=now,
                    updated_at=now,
                )
            elif change.action == "remove":
                replacement = cards.get(change.replacement_card_id or "")
                if replacement is None:
                    raise ProposalError(
                        f"Proposal `{proposal_id}` is inconsistent: missing replacement `{change.replacement_card_id}`"
                    )
                if not change.replacement_revision:
                    raise ProposalError(
                        f"Proposal `{proposal_id}` is missing revision metadata for replacement `{replacement.id}`; regenerate it"
                    )
                if change.replacement_revision != replacement.revision:
                    raise ProposalError(
                        f"Proposal `{proposal_id}` is stale: replacement card `{replacement.id}` changed after proposal creation"
                    )
                cards[replacement.id] = replacement.clone_for_update(
                    supersedes=sorted(set(replacement.supersedes + [target.id])),
                    updated_at=now,
                )
                cards.pop(target.id, None)
            else:
                raise ProposalError(f"Unsupported proposal action `{change.action}`")

        self.repository.replace_cards(sorted(cards.values(), key=lambda card: card.id))
        applied = proposal.model_copy(update={"status": "applied"})
        self.repository.write_proposal(applied)
        return applied

    def curate(self, evidence: CurationEvidence, *, confirm_apply: bool = False) -> ProposalBatch:
        proposal = self.suggest_updates(evidence)
        if confirm_apply:
            return self.apply_proposal(proposal.id, confirm=True)
        return proposal

    def _refresh_proposal_status(self, proposal: ProposalBatch) -> ProposalBatch:
        retention_days = self.repository.load_config().proposal_retention_days
        effective = proposal.effective_status(retention_days)
        if effective != proposal.status:
            proposal = proposal.model_copy(update={"status": effective})
            self.repository.write_proposal(proposal)
        return proposal

    def _build_bootstrap_proposal(self, candidates: list[BootstrapCandidate]) -> ProposalBatch:
        existing_cards = self.repository.load_cards()
        active_cards = [card for card in existing_cards if card.is_active]
        by_id = {card.id: card for card in existing_cards}
        consumed_ids: set[str] = set()
        changes: list[ProposedMemoryChange] = []
        source_paths = [candidate.source_path for candidate in candidates]

        for candidate in candidates:
            match = self._match_bootstrap_candidate(candidate, active_cards)
            if match is None:
                changes.append(
                    ProposedMemoryChange(
                        action="create",
                        target_card_id=candidate.card.id,
                        reason=f"Imported from `{candidate.source_path}` during bootstrap.",
                        proposed_card=candidate.card,
                        field_diff={"source_path": {"before": None, "after": candidate.source_path}},
                    )
                )
                continue
            consumed_ids.add(match.id)
            proposed = candidate.card.model_copy(
                update={
                    "id": match.id,
                    "targets": match.targets,
                    "priority": max(match.priority, candidate.card.priority),
                    "status": "active",
                    "deprecated_at": None,
                    "supersedes": match.supersedes,
                }
            )
            field_diff = self._field_diff(match, proposed)
            if not field_diff:
                continue
            changes.append(
                ProposedMemoryChange(
                    action="update",
                    target_card_id=match.id,
                    target_revision=match.revision,
                    reason=f"Refreshed from `{candidate.source_path}` during bootstrap.",
                    proposed_card=proposed,
                    field_diff=field_diff,
                )
            )

        candidate_ids = {change.target_card_id for change in changes if change.action in {"create", "update"}}
        for card in active_cards:
            if card.id in consumed_ids or card.id in candidate_ids:
                continue
            if card.id == "architecture-overview":
                continue
            changes.append(
                ProposedMemoryChange(
                    action="deprecate",
                    target_card_id=card.id,
                    target_revision=card.revision,
                    reason="Bootstrap did not find a matching source file for this active card.",
                )
            )

        evidence = CurationEvidence(
            task_summary="Bootstrap project memory from existing documentation and agent instruction files.",
            implementation_summary="Scanned project docs and rule files and converted them into canonical card proposals.",
            changed_paths=[],
            diff_summary=f"Discovered {len(candidates)} bootstrap source files.",
            test_summary="Bootstrap import generated a proposal batch for review.",
            file_excerpts=[candidate.card.summary for candidate in candidates[:10]],
            source_kind="bootstrap",
            source_paths=source_paths,
        )
        return ProposalBatch(
            id=f"proposal-{datetime.now(UTC).strftime('%Y%m%d%H%M%S')}-{uuid4().hex[:8]}",
            status="pending",
            created_at=datetime.now(UTC),
            changed_paths=[],
            evidence_digest=evidence.to_digest(),
            changes=changes,
        )

    def _match_bootstrap_candidate(self, candidate: BootstrapCandidate, cards: list[Card]) -> Card | None:
        candidate_tokens = _tokens(
            f"{candidate.card.id} {candidate.card.title} {candidate.card.summary} {' '.join(candidate.card.tags)}"
        )
        best: tuple[int, Card] | None = None
        for card in cards:
            score = 0
            if card.id == candidate.card.id:
                score += 10
            if card.kind == candidate.card.kind:
                score += 2
            overlap = len(candidate_tokens & _tokens(f"{card.id} {card.title} {card.summary} {' '.join(card.tags)}"))
            score += min(overlap, 6)
            if candidate.card.paths and card.paths and set(candidate.card.paths) & set(card.paths):
                score += 3
            if best is None or score > best[0]:
                best = (score, card)
        if best and best[0] >= 5:
            return best[1]
        return None

    def _generate_proposed_changes(self, evidence: CurationEvidence) -> list[ProposedMemoryChange]:
        combined_text = evidence.combined_text()
        if not combined_text.strip() and not evidence.changed_paths:
            return []

        all_cards = self.repository.load_cards()
        active_cards = [card for card in all_cards if card.is_active]
        explicit = self._extract_explicit_changes(
            combined_text.lower(),
            {card.id: card for card in all_cards},
        )
        if explicit:
            return explicit

        impacted = self._select_impacted_cards(evidence, active_cards)
        if impacted:
            target = impacted[0]
            proposed = self._build_card_from_evidence(evidence, existing=target)
            field_diff = self._field_diff(target, proposed)
            if not field_diff:
                return []
            return [
                ProposedMemoryChange(
                    action="update",
                    target_card_id=target.id,
                    target_revision=target.revision,
                    reason="Implementation and task summaries diverge from the existing matching memory card.",
                    proposed_card=proposed,
                    field_diff=field_diff,
                )
            ]

        proposed = self._build_card_from_evidence(evidence)
        return [
            ProposedMemoryChange(
                action="create",
                target_card_id=proposed.id,
                reason="Feature work introduced stable project memory not covered by existing cards.",
                proposed_card=proposed,
                field_diff=None,
            )
        ]

    def _extract_explicit_changes(
        self,
        combined_text: str,
        existing_by_id: dict[str, Card],
    ) -> list[ProposedMemoryChange]:
        changes: list[ProposedMemoryChange] = []
        for old_id, replacement_id in REMOVE_RE.findall(combined_text):
            target = existing_by_id.get(old_id)
            if target is None:
                continue
            if replacement_id not in existing_by_id:
                changes.append(
                    ProposedMemoryChange(
                        action="deprecate",
                        target_card_id=old_id,
                        target_revision=target.revision,
                        reason=(
                            f"Requested removal of `{old_id}` but replacement `{replacement_id}` was not found, "
                            "so the change was downgraded to deprecate."
                        ),
                    )
                )
            else:
                changes.append(
                    ProposedMemoryChange(
                        action="remove",
                        target_card_id=old_id,
                        target_revision=target.revision,
                        replacement_card_id=replacement_id,
                        replacement_revision=existing_by_id[replacement_id].revision,
                        reason=f"`{old_id}` has been explicitly replaced by `{replacement_id}`.",
                    )
                )
        for target_id in DEPRECATE_RE.findall(combined_text):
            if target_id not in existing_by_id:
                continue
            if any(change.target_card_id == target_id for change in changes):
                continue
            changes.append(
                ProposedMemoryChange(
                    action="deprecate",
                    target_card_id=target_id,
                    target_revision=existing_by_id[target_id].revision,
                    reason=f"`{target_id}` was explicitly marked as deprecated by the evidence bundle.",
                )
            )
        return changes

    def _select_impacted_cards(self, evidence: CurationEvidence, cards: list[Card]) -> list[Card]:
        evidence_text = evidence.combined_text()
        evidence_tokens = _tokens(evidence_text)
        inferred_kind = self._infer_kind(evidence_text)
        scored: list[tuple[int, Card]] = []
        for card in cards:
            score = 0
            card_tokens = _tokens(f"{card.title} {card.summary} {card.body} {' '.join(card.tags)} {card.kind}")
            overlap = len(evidence_tokens & card_tokens)
            if overlap:
                score += min(overlap, 6)
            if inferred_kind == card.kind:
                score += 2
            if evidence.changed_paths and not card.is_global and any(
                card.matches_path(path) for path in evidence.changed_paths
            ):
                score += 5
            elif card.is_global and overlap >= 2:
                score += 2
            threshold = 4 if card.is_global else 5
            if score >= threshold:
                scored.append((score, card))
        scored.sort(key=lambda item: (-item[0], -item[1].priority, item[1].id))
        return [card for _, card in scored]

    def _build_card_from_evidence(self, evidence: CurationEvidence, existing: Card | None = None) -> Card:
        config = self.repository.load_config()
        kind = existing.kind if existing else self._infer_kind(evidence.combined_text())
        title = existing.title if existing else self._infer_title(evidence)
        card_id = existing.id if existing else _slugify(title)
        summary = self._infer_summary(evidence)
        body = self._build_body(evidence, existing=existing)
        paths = self._merge_paths(existing.paths if existing else [], evidence.changed_paths or evidence.source_paths)
        tags = self._infer_tags(kind, paths, existing=existing)
        priority = existing.priority if existing else (90 if kind == "architecture" else 70)
        supersedes = existing.supersedes if existing else []
        return Card(
            id=card_id,
            title=title,
            kind=kind,
            summary=summary,
            body=body,
            paths=paths if not (existing and existing.is_global) else [],
            tags=tags,
            priority=priority,
            targets=existing.targets if existing else list(config.enabled_adapters),
            updated_at=datetime.now(UTC),
            status="active",
            supersedes=supersedes,
        )

    @staticmethod
    def _infer_kind(text: str) -> str:
        lowered = text.lower()
        if "architecture" in lowered:
            return "architecture"
        if "command" in lowered or "cli" in lowered:
            return "command"
        if "pitfall" in lowered or "warning" in lowered:
            return "pitfall"
        if "decision" in lowered:
            return "decision"
        if "convention" in lowered or "rule" in lowered:
            return "convention"
        return "pattern"

    @staticmethod
    def _infer_title(evidence: CurationEvidence) -> str:
        source = next(
            (
                item.strip()
                for item in [evidence.task_summary, evidence.implementation_summary, evidence.diff_summary]
                if item and item.strip()
            ),
            "Project memory update",
        )
        first_sentence = source.splitlines()[0].split(".")[0].strip()
        first_sentence = re.sub(r"^\[[^\]]+\]\s*", "", first_sentence)
        return first_sentence[:80] or "Project memory update"

    @staticmethod
    def _infer_summary(evidence: CurationEvidence) -> str:
        source = next(
            (
                item.strip()
                for item in [evidence.task_summary, evidence.implementation_summary, evidence.test_summary]
                if item and item.strip()
            ),
            "Stable project memory captured from recent feature work.",
        )
        return source[:160]

    @staticmethod
    def _merge_paths(existing_paths: list[str], changed_paths: list[str]) -> list[str]:
        merged: list[str] = []
        for path in [*existing_paths, *changed_paths]:
            if path and path not in merged:
                merged.append(path)
        return merged

    def _infer_tags(self, kind: str, paths: list[str], *, existing: Card | None) -> list[str]:
        tags = list(existing.tags) if existing else []
        if kind not in tags:
            tags.append(kind)
        for path in paths:
            head = path.split("/", 1)[0]
            if head and head not in tags:
                tags.append(head)
        return sorted(dict.fromkeys(tags))

    @staticmethod
    def _build_body(evidence: CurationEvidence, *, existing: Card | None) -> str:
        sections: list[str] = []
        if evidence.source_kind == "bootstrap" and evidence.source_paths:
            sections.append("Imported Sources\n" + "\n".join(f"- {path}" for path in evidence.source_paths))
        if evidence.task_summary.strip():
            sections.append(f"Task\n{evidence.task_summary.strip()}")
        if evidence.implementation_summary.strip():
            sections.append(f"Implementation\n{evidence.implementation_summary.strip()}")
        elif existing is not None and existing.body.strip():
            sections.append(f"Implementation\n{existing.body.strip()}")
        if evidence.diff_summary.strip():
            sections.append(f"Diff Summary\n{evidence.diff_summary.strip()}")
        elif evidence.diff_text.strip():
            sections.append(f"Diff Summary\n{evidence.diff_text.strip()[:800]}")
        if evidence.changed_paths:
            sections.append("Changed Paths\n" + "\n".join(f"- {path}" for path in evidence.changed_paths))
        if evidence.test_summary.strip():
            sections.append(f"Tests\n{evidence.test_summary.strip()}")
        if evidence.file_excerpts:
            sections.append("Extracts\n" + "\n\n".join(item.strip() for item in evidence.file_excerpts[:5]))
        return "\n\n".join(section.strip() for section in sections if section.strip())

    @staticmethod
    def _field_diff(original: Card, proposed: Card) -> dict[str, dict[str, object]]:
        diff: dict[str, dict[str, object]] = {}
        for field in ["title", "kind", "summary", "body", "paths", "tags", "priority", "targets", "status"]:
            before = getattr(original, field)
            after = getattr(proposed, field)
            if before != after:
                diff[field] = {"before": before, "after": after}
        return diff

    @staticmethod
    def _sort_cards(cards: list[Card], selected_paths: list[str] | None = None) -> list[Card]:
        selected_paths = selected_paths or []

        def sort_key(card: Card) -> tuple[int, int, str, str]:
            scope_rank = 0 if card.is_global else 1
            path_rank = 0
            if selected_paths and not card.is_global:
                path_rank = 0 if any(card.matches_path(path) for path in selected_paths) else 1
            return (scope_rank, path_rank, -card.priority, card.id)

        return sorted(cards, key=sort_key)
