"""Helpers for Markdown card parsing and serialization."""

from __future__ import annotations

from pathlib import Path

import yaml

from memory_manager.exceptions import ValidationError
from memory_manager.models import Card


def parse_card_file(path: Path) -> Card:
    """Load a card from a Markdown file with YAML frontmatter."""
    raw = path.read_text(encoding="utf-8")
    if not raw.startswith("---\n"):
        raise ValidationError(f"{path} is missing YAML frontmatter")

    closing_marker = "\n---\n"
    closing_index = raw.find(closing_marker, 4)
    if closing_index == -1:
        raise ValidationError(f"{path} has invalid frontmatter format")

    frontmatter_text = raw[4:closing_index]
    body = raw[closing_index + len(closing_marker) :]
    frontmatter = yaml.safe_load(frontmatter_text) or {}
    if not isinstance(frontmatter, dict):
        raise ValidationError(f"{path} frontmatter must be a mapping")

    try:
        return Card.model_validate(
            {
                **frontmatter,
                "body": body.strip(),
                "source_path": str(path),
            }
        )
    except Exception as exc:  # pydantic raises structured errors we re-wrap
        raise ValidationError(f"{path} is invalid: {exc}") from exc


def serialize_card(card: Card) -> str:
    """Serialize a card back into canonical Markdown."""
    payload = card.model_dump(mode="json", exclude={"body", "source_path"})
    frontmatter = yaml.safe_dump(payload, sort_keys=False, allow_unicode=False).strip()
    return f"---\n{frontmatter}\n---\n{card.body.strip()}\n"
