"""Typed exceptions for the memory manager."""


class MemoryManagerError(Exception):
    """Base exception for the project."""


class ConfigNotFoundError(MemoryManagerError):
    """Raised when the workspace has not been initialized."""


class ValidationError(MemoryManagerError):
    """Raised when canonical memory data is invalid."""


class RenderError(MemoryManagerError):
    """Raised when a render target is unsupported or misconfigured."""


class ProposalError(MemoryManagerError):
    """Raised when a proposal workflow is invalid or unsafe to apply."""
