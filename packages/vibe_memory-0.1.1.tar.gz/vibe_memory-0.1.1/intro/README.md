# Start Here

These guides explain how to use this project on any computer.

They do not assume a specific username or folder like `/Users/abhinavdev/...`.

Use this variable in the commands below:

```bash
export PROJECT_ROOT="/path/to/your/project"
cd "$PROJECT_ROOT"
```

Then follow one of these guides:

- [codex.md](/Users/abhinavdev/Projects/memory/intro/codex.md)
- [claude.md](/Users/abhinavdev/Projects/memory/intro/claude.md)
- [cursor.md](/Users/abhinavdev/Projects/memory/intro/cursor.md)
- [opencode.md](/Users/abhinavdev/Projects/memory/intro/opencode.md)

## Simple Mental Model

This project has one shared memory system for all coding agents.

- The real memory lives in `.memory/cards/`
- Agents read memory through MCP or CLI
- Agents do not write memory directly
- Agents suggest memory changes
- You approve those changes
- Then the system updates the cards safely

## Quick Setup For Any Tool

```bash
export PROJECT_ROOT="/path/to/your/project"
cd "$PROJECT_ROOT"
uv run memory init --workspace-id my-project
```

If the project already has a `README.md`, `AGENTS.md`, `CLAUDE.md`, Cursor rules, or docs you want converted into cards, use:

```bash
uv run memory bootstrap --workspace-id my-project
```

Start the MCP server manually if you want to test it:

```bash
uv run memory serve-mcp --root "$PROJECT_ROOT"
```

Useful CLI commands:

```bash
uv run memory search "validation"
uv run memory list
uv run memory suggest-updates \
  --changed-paths "src/api/routes.py" \
  --task-summary "API validation rules" \
  --implementation-summary "Validate payloads before database writes."
uv run memory proposals list
```

## Important Note

Some config files inside this repo may use an absolute path because they were generated and verified on this machine.

The docs in this `intro/` folder are the generic instructions you should follow on another computer.
