# Claude Code Guide

## What You Are Doing

You are connecting Claude Code to the shared memory system for this project.

Claude Code will then:

- load project instructions from `CLAUDE.md`
- use MCP to fetch relevant memory
- suggest memory updates after implementation

## Step 1: Go To Your Project

```bash
export PROJECT_ROOT="/path/to/your/project"
cd "$PROJECT_ROOT"
```

## Step 2: Initialize Memory

Run this once per project:

```bash
uv run memory init --workspace-id my-project
```

## Step 3: Register The MCP Server For Claude Code

Project-scoped setup:

```bash
claude mcp add vibe-memory --scope project -- bash "$PROJECT_ROOT/scripts/run_memory_mcp.sh"
```

## Step 4: Verify It

```bash
claude mcp list
claude mcp get vibe-memory
```

## Step 5: Make Sure The Project Has Instruction Files

Claude Code uses:

- `CLAUDE.md`
- `AGENTS.md`

This repo already includes:

- [CLAUDE.md](/Users/abhinavdev/Projects/memory/CLAUDE.md)
- [AGENTS.md](/Users/abhinavdev/Projects/memory/AGENTS.md)

## How Claude Should Work

Before coding:

```text
Use memory.get_context(paths=[...]) or memory.search(query=...)
```

After coding:

```text
Use memory.suggest_updates(...)
Show the proposal
If approved, use memory.apply_proposal(...)
```

## Helpful Commands

```bash
uv run memory render claude --format dist
uv run memory search "architecture"
uv run memory proposals list
```
