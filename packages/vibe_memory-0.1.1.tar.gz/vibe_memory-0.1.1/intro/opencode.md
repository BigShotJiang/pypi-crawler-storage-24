# OpenCode Guide

## What You Are Doing

You are connecting OpenCode to the same shared memory system used by the other coding agents.

OpenCode should:

- read project instructions from `AGENTS.md`
- use MCP to fetch relevant memory
- suggest memory changes after task completion

## Step 1: Go To Your Project

```bash
export PROJECT_ROOT="/path/to/your/project"
cd "$PROJECT_ROOT"
```

## Step 2: Initialize Memory

Run this once per project:

```bash
uv run memory init --workspace-id my-project
```

## Step 3: Add OpenCode Config

OpenCode uses `opencode.json`.

Example:

```json
{
  "mcp": {
    "vibe-memory": {
      "type": "local",
      "command": ["bash", "./scripts/run_memory_mcp.sh"],
      "enabled": true
    }
  }
}
```

This repo already includes:

- [opencode.json](/Users/abhinavdev/Projects/memory/opencode.json)
- [AGENTS.md](/Users/abhinavdev/Projects/memory/AGENTS.md)

## Step 4: Verify

OpenCode verification depends on your local OpenCode install and networked model setup.

Basic checks:

- confirm `opencode.json` exists
- confirm `AGENTS.md` exists
- confirm `scripts/run_memory_mcp.sh` exists

## How OpenCode Should Work

Before coding:

```text
Use memory.get_context(paths=[...]) or memory.search(query=...)
```

After coding:

```text
Use memory.suggest_updates(...)
Show the proposal
If approved, use memory.apply_proposal(...)
```

## Helpful Commands

```bash
uv run memory render opencode --format dist
uv run memory search "decision"
uv run memory proposals list
```
