# Codex Guide

## What You Are Doing

You are connecting Codex to this project's shared memory system.

That lets Codex:

- load project memory before coding
- search project memory while coding
- suggest memory updates after coding
- apply memory updates only after approval

## Step 1: Go To Your Project

```bash
export PROJECT_ROOT="/path/to/your/project"
cd "$PROJECT_ROOT"
```

## Step 2: Initialize Memory

Run this once per project:

```bash
uv run memory init --workspace-id my-project
```

## Step 3: Register The MCP Server In Codex

```bash
codex mcp add vibe-memory -- bash "$PROJECT_ROOT/scripts/run_memory_mcp.sh"
```

## Step 4: Verify It

```bash
codex mcp list
codex mcp get vibe-memory --json
```

You want to see:

- the server is present
- it is enabled
- it uses `bash`
- it points to `scripts/run_memory_mcp.sh`

## Step 5: Let Codex Use It

Codex reads:

- `AGENTS.md`

This project already includes [AGENTS.md](/Users/abhinavdev/Projects/memory/AGENTS.md).

## How Codex Should Work

Before coding:

```text
Use memory.get_context(paths=[...]) or memory.search(query=...)
```

After coding:

```text
Use memory.suggest_updates(...)
Show the proposal to the user
If approved, use memory.apply_proposal(...)
```

## Helpful Commands

```bash
uv run memory search "authentication"
uv run memory list --path "src/api/routes.py"
uv run memory proposals list
```
