# Cursor Guide

## What You Are Doing

You are connecting Cursor to the shared project memory system.

Cursor can use:

- MCP for retrieval and proposal workflows
- Cursor rules for automatic behavior
- `AGENTS.md` for shared agent instructions

## Step 1: Go To Your Project

```bash
export PROJECT_ROOT="/path/to/your/project"
cd "$PROJECT_ROOT"
```

## Step 2: Initialize Memory

Run this once per project:

```bash
uv run memory init --workspace-id my-project
```

## Step 3: Create Cursor MCP Config

Cursor uses `.cursor/mcp.json`.

Example:

```json
{
  "mcpServers": {
    "vibe-memory": {
      "type": "stdio",
      "command": "bash",
      "args": ["./scripts/run_memory_mcp.sh"]
    }
  }
}
```

This repo already includes a project config at:

- [.cursor/mcp.json](/Users/abhinavdev/Projects/memory/.cursor/mcp.json)

## Step 4: Add Cursor Rules

Cursor rules live in `.cursor/rules/*.mdc`.

This repo already includes:

- [.cursor/rules/portable-memory.mdc](/Users/abhinavdev/Projects/memory/.cursor/rules/portable-memory.mdc)

## Step 5: Verify

```bash
cursor-agent mcp list
cursor-agent mcp list-tools vibe-memory
```

If Cursor CLI is signed in properly, it should detect the project MCP config.

## How Cursor Should Work

Before coding:

```text
Use memory.get_context(paths=[...]) or memory.search(query=...)
```

After coding:

```text
Use memory.suggest_updates(...)
Show the proposal
If approved, use memory.apply_proposal(...)
```

## Helpful Commands

```bash
uv run memory render cursor --format dist
uv run memory search "pattern"
uv run memory proposals list
```
