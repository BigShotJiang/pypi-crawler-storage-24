# Design Critique

This project should be treated as a shared project-memory layer, not as a replacement
for Codex, Claude Code, Cursor, or OpenCode native instruction systems.

## Recommended Model

Use four layers with clear precedence:

1. Tool-native policy and safety controls.
2. Thin project instruction files such as `AGENTS.md`, `CLAUDE.md`, and Cursor rules.
3. Canonical memory retrieved from `.memory/cards/` through MCP or the CLI.
4. Session-local reasoning and user prompts.

The native files should stay procedural. They should tell the agent when to call:

- `memory.get_context`
- `memory.search`
- `memory.bootstrap`
- `memory.suggest_updates`
- `memory.apply_proposal`

They should not duplicate large memory bundles. The knowledge itself belongs in
canonical cards and should be fetched on demand.

## Why This Matters

Claude Code loads project memory automatically, Cursor injects rules into context,
and OpenCode and Codex can expose MCP tools directly. If the same memory is copied
into every native file and also fetched dynamically, the agent sees duplicated and
sometimes conflicting guidance.

The safest split is:

- native files are the control plane
- `.memory/cards/` is the knowledge plane
- MCP and the CLI are the retrieval and write planes

## Current Safeguards

- Canonical cards are the only source of truth.
- Generated outputs stay under `.memory/dist/`.
- Proposal application is approval-gated.
- Proposal application now includes optimistic concurrency checks: update,
  deprecate, and remove actions capture the expected card revision and fail if the
  card changed before approval.

## Remaining Risks

- Agents still treat these instructions as context, not as absolute enforcement.
- Native tool memories can still drift from canonical cards if they are edited by hand.
- Overly broad retrieval can waste tokens and reduce compliance.

## Operating Guidance

- Keep native tool files short and workflow-oriented.
- Prefer MCP for retrieval instead of static rendered bundles when the tool supports it.
- Review and apply proposals quickly; stale pending proposals are more likely to fail
  revision checks or become semantically outdated.
- Treat bootstrap imports as drafts to review, not as truth.
