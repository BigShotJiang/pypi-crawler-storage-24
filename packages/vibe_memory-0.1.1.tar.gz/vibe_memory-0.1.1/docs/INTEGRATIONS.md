# Agent Integrations

This project is set up so Codex, Claude Code, Cursor, OpenCode, and MCP-capable editors can all use the same canonical memory under `.memory/`.

## What is already configured in this repo

- [AGENTS.md](/Users/abhinavdev/Projects/memory/AGENTS.md) for Codex, OpenCode, Cursor, and other AGENTS-aware tools.
- [CLAUDE.md](/Users/abhinavdev/Projects/memory/CLAUDE.md) for Claude Code.
- [.mcp.json](/Users/abhinavdev/Projects/memory/.mcp.json) for Claude Code project-scoped MCP.
- [.cursor/mcp.json](/Users/abhinavdev/Projects/memory/.cursor/mcp.json) for Cursor project MCP.
- [.cursor/rules/portable-memory.mdc](/Users/abhinavdev/Projects/memory/.cursor/rules/portable-memory.mdc) for Cursor automatic behavior.
- [opencode.json](/Users/abhinavdev/Projects/memory/opencode.json) for OpenCode MCP and project instructions.
- [.vscode/mcp.json](/Users/abhinavdev/Projects/memory/.vscode/mcp.json) for GitHub Copilot Agent / MCP-capable VS Code setups.
- [scripts/run_memory_mcp.sh](/Users/abhinavdev/Projects/memory/scripts/run_memory_mcp.sh) as the shared stdio launcher.

## Codex

Codex MCP configuration is shared between the CLI and IDE extension. OpenAI’s docs show:

```bash
codex mcp add openaiDeveloperDocs --url https://developers.openai.com/mcp
```

and the equivalent `~/.codex/config.toml` format:

```toml
[mcp_servers.openaiDeveloperDocs]
url = "https://developers.openai.com/mcp"
```

For this project, configure the local stdio server with:

```bash
codex mcp add vibe-memory -- bash /Users/abhinavdev/Projects/memory/scripts/run_memory_mcp.sh
```

Then verify:

```bash
codex mcp list
codex mcp get vibe-memory --json
```

## Claude Code

Anthropic’s docs specify project-scoped MCP servers in `.mcp.json` and note that project memory files like `CLAUDE.md` are automatically loaded at session start.

This repo already includes:

- [CLAUDE.md](/Users/abhinavdev/Projects/memory/CLAUDE.md)
- [.mcp.json](/Users/abhinavdev/Projects/memory/.mcp.json)

Equivalent command from the docs style:

```bash
claude mcp add vibe-memory --scope project -- bash ./scripts/run_memory_mcp.sh
```

Useful checks:

```bash
claude mcp list
claude mcp get vibe-memory
```

## Cursor

Cursor’s docs specify project MCP in `.cursor/mcp.json` and project rules in `.cursor/rules`. The Composer Agent can automatically use MCP tools when relevant.

This repo already includes:

- [.cursor/mcp.json](/Users/abhinavdev/Projects/memory/.cursor/mcp.json)
- [.cursor/rules/portable-memory.mdc](/Users/abhinavdev/Projects/memory/.cursor/rules/portable-memory.mdc)
- [AGENTS.md](/Users/abhinavdev/Projects/memory/AGENTS.md)

Useful checks:

```bash
cursor-agent mcp list
cursor-agent mcp list-tools vibe-memory
```

## OpenCode

OpenCode’s docs specify project config in `opencode.json`, local MCP under `mcp`, and note that MCP tools become available alongside built-in tools. They also recommend committing `AGENTS.md`.

This repo already includes:

- [opencode.json](/Users/abhinavdev/Projects/memory/opencode.json)
- [AGENTS.md](/Users/abhinavdev/Projects/memory/AGENTS.md)

## Recommended agent workflow

At task start:

```text
Call memory.get_context(paths=[...]) or memory.search(query=...)
```

At task end:

```text
Call memory.suggest_updates(...)
Show the proposal to the user
Only after approval call memory.apply_proposal(...)
```

## Source references

- OpenAI Codex MCP and AGENTS guidance: [Docs MCP](https://developers.openai.com/resources/docs-mcp), [Agentic AI Foundation / AGENTS.md](https://openai.com/index/agentic-ai-foundation)
- Anthropic Claude Code MCP and memory docs: [MCP](https://code.claude.com/docs/en/mcp), [Memory](https://code.claude.com/docs/en/memory)
- Cursor MCP and rules docs: [MCP](https://docs.cursor.com/context/model-context-protocol), [Rules](https://docs.cursor.com/en/context)
- OpenCode docs: [MCP servers](https://opencode.ai/docs/mcp-servers/), [Config](https://opencode.ai/docs/config/), [Intro](https://opencode.ai/docs/)
