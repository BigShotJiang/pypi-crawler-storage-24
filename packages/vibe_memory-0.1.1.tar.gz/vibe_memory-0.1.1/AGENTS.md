# Vibe Memory

Use the `vibe-memory` MCP server for project memory instead of editing `.memory/cards/*.md` directly.

## Retrieval
- At task start, load relevant memory before planning or coding.
- Prefer `memory.get_context` when you know the affected paths.
- Prefer `memory.search` when you need to find an existing pattern, convention, command, or decision.
- Scope retrieval by changed or referenced paths whenever possible to keep token usage low.

## Update Workflow
- At task end, after implementation and tests, call `memory.suggest_updates`.
- Include concise `task_summary`, `implementation_summary`, `changed_paths`, and `test_summary`.
- Show the proposal batch to the user before changing memory.
- Only after explicit approval, call `memory.apply_proposal`.
- If the proposal is wrong or premature, call `memory.reject_proposal`.

## Safety
- Never write root `AGENTS.md`, `CLAUDE.md`, `.cursor/rules`, or `.opencode/*` as a source of truth for project memory.
- Never edit `.memory/cards/*.md` manually unless the user explicitly asks for direct card edits.
- Prefer `deprecate` over delete unless a replacement memory card is explicit.
