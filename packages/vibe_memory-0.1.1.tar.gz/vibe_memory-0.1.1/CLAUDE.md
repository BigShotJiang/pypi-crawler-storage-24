# Claude Code Instructions

@AGENTS.md

## Claude Code MCP Usage
- Use the project-scoped `vibe-memory` MCP server for retrieval and curation.
- Claude Code automatically loads this file at session start and can use MCP resources and tools from the project configuration.
- Keep MCP responses concise; if output gets too large, narrow the request by `paths` or specific search terms.
