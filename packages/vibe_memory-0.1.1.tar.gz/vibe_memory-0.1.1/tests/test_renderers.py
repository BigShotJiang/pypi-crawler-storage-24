from __future__ import annotations

from pathlib import Path

from memory_manager.service import MemoryService
from tests.helpers import init_workspace, make_card


def test_render_targets_match_golden_outputs(tmp_path: Path) -> None:
    init_workspace(
        tmp_path,
        [
            make_card(
                card_id="architecture-overview",
                title="Architecture overview",
                kind="architecture",
                summary="High-level shape",
                body="Use the API server as the write boundary.",
                priority=100,
            ),
            make_card(
                card_id="api-patterns",
                title="API patterns",
                kind="pattern",
                summary="HTTP handler rules",
                body="Validate input before touching the database.",
                paths=["src/api/**"],
                priority=80,
            ),
        ],
    )
    service = MemoryService(tmp_path)

    expected_codex = (Path(__file__).parent / "golden" / "codex_AGENTS.md").read_text(encoding="utf-8")
    expected_claude = (Path(__file__).parent / "golden" / "claude_CLAUDE.md").read_text(encoding="utf-8")
    expected_cursor = (Path(__file__).parent / "golden" / "cursor_AGENTS.md").read_text(encoding="utf-8")

    assert service.render("codex").artifacts[0].content == expected_codex
    assert service.render("claude").artifacts[0].content == expected_claude
    assert service.render("cursor").artifacts[0].content == expected_cursor


def test_render_writes_only_under_dist(tmp_path: Path) -> None:
    init_workspace(
        tmp_path,
        [
            make_card(
                card_id="architecture-overview",
                title="Architecture overview",
                kind="architecture",
                summary="High-level shape",
                body="Keep writes under dist.",
                priority=100,
            )
        ],
    )
    service = MemoryService(tmp_path)
    result = service.render("codex")
    written = service.write_render(result)

    assert all(".memory/dist/codex" in str(path) for path in written)
    assert not (tmp_path / "AGENTS.md").exists()
    assert not (tmp_path / "CLAUDE.md").exists()
    assert not (tmp_path / ".cursor" / "rules").exists()
