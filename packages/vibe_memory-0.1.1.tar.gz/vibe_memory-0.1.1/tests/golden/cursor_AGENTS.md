# Cursor AGENTS.md Memory Bundle

This file is generated from `.memory/cards/*.md`.

Scope: all paths
Budget: 12000 characters

## Architecture overview

- id: `architecture-overview`
- kind: `architecture`
- priority: `100`
- summary: High-level shape

Use the API server as the write boundary.

## API patterns

- id: `api-patterns`
- kind: `pattern`
- priority: `80`
- summary: HTTP handler rules
- paths: `src/api/**`

Validate input before touching the database.
