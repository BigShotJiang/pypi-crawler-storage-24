# CLAUDE.md Memory Bundle

This file is generated from `.memory/cards/*.md`.

Scope: all paths
Budget: 12000 characters

## Architecture overview

- id: `architecture-overview`
- kind: `architecture`
- priority: `100`
- summary: High-level shape

Use the API server as the write boundary.
