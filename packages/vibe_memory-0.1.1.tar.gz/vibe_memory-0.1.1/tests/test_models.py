from __future__ import annotations

from datetime import timedelta
from pathlib import Path

import pytest
from pydantic import ValidationError as PydanticValidationError

from memory_manager.exceptions import ValidationError
from memory_manager.markdown import parse_card_file
from memory_manager.models import Card, ProposedMemoryChange


def test_card_path_matching_supports_global_and_scoped() -> None:
    global_card = Card(
        id="global",
        title="Global",
        kind="architecture",
        summary="global",
        body="shared",
    )
    scoped = Card(
        id="scoped",
        title="Scoped",
        kind="pattern",
        summary="scoped",
        body="scoped body",
        paths=["src/api/**"],
    )

    assert global_card.matches_path("any/file.py")
    assert scoped.matches_path("src/api/routes.py")
    assert not scoped.matches_path("tests/test_api.py")


def test_parse_card_rejects_missing_frontmatter(tmp_path: Path) -> None:
    path = tmp_path / "broken.md"
    path.write_text("hello", encoding="utf-8")
    with pytest.raises(ValidationError):
        parse_card_file(path)


def test_remove_proposal_requires_replacement() -> None:
    with pytest.raises(PydanticValidationError):
        ProposedMemoryChange(
            action="remove",
            target_card_id="legacy-api",
            reason="legacy rule removed",
        )


def test_card_revision_ignores_updated_at_but_changes_with_content() -> None:
    original = Card(
        id="api-patterns",
        title="API patterns",
        kind="pattern",
        summary="Typed handlers",
        body="Validate before DB writes.",
    )
    same_content_new_time = original.clone_for_update(updated_at=original.updated_at + timedelta(minutes=5))
    changed = original.clone_for_update(body="Validate before any side effects.")

    assert original.revision == same_content_new_time.revision
    assert original.revision != changed.revision
