from __future__ import annotations

import asyncio
from pathlib import Path

import pytest

from memory_manager.mcp_server import build_server
from tests.helpers import init_workspace, make_card


def test_build_server_exposes_expected_routes(tmp_path: Path) -> None:
    init_workspace(
        tmp_path,
        [
            make_card(
                card_id="architecture-overview",
                title="Architecture overview",
                kind="architecture",
                summary="High-level shape",
                body="Use services for orchestration.",
                priority=100,
            ),
        ],
    )
    server = build_server(tmp_path)

    # FastMCP keeps decorated handlers on the server instance; this verifies
    # construction without needing a network round-trip.
    assert server is not None
    assert server.name == "vibe-memory"
    tool_names = {tool.name for tool in asyncio.run(server.list_tools())}
    assert {
        "memory.get_context",
        "memory.search",
        "memory.list_cards",
        "memory.render",
        "memory.bootstrap",
        "memory.suggest_updates",
        "memory.list_proposals",
        "memory.show_proposal",
        "memory.apply_proposal",
        "memory.reject_proposal",
    }.issubset(tool_names)


def test_mcp_write_flow_requires_confirmation(tmp_path: Path) -> None:
    init_workspace(
        tmp_path,
        [
            make_card(
                card_id="api-patterns",
                title="API patterns",
                kind="pattern",
                summary="rules",
                body="Use typed handlers.",
                paths=["src/api/**"],
            ),
        ],
    )
    server = build_server(tmp_path)

    result = asyncio.run(
        server.call_tool(
            "memory.suggest_updates",
            {
                "changed_paths": ["src/api/routes.py"],
                "task_summary": "API validation conventions",
                "implementation_summary": "Validate input before DB writes.",
            },
        )
    )
    proposal = result[1]
    assert proposal["status"] == "pending"

    with pytest.raises(Exception, match="Applying a proposal requires explicit confirmation"):
        asyncio.run(
            server.call_tool(
                "memory.apply_proposal",
                {"proposal_id": proposal["id"], "confirm": False},
            )
        )


def test_mcp_bootstrap_returns_bootstrap_proposal(tmp_path: Path) -> None:
    (tmp_path / "README.md").write_text("# Existing Project\n\nThis project handles analytics.", encoding="utf-8")
    server = build_server(tmp_path)

    result = asyncio.run(
        server.call_tool(
            "memory.bootstrap",
            {"workspace_id": "existing-project"},
        )
    )
    proposal = result[1]

    assert proposal["status"] == "pending"
    assert proposal["evidence_digest"]["source_kind"] == "bootstrap"
