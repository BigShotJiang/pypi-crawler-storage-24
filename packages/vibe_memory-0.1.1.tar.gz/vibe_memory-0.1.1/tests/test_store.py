from __future__ import annotations

from pathlib import Path

import pytest

from memory_manager.exceptions import ProposalError, ValidationError
from memory_manager.markdown import serialize_card
from memory_manager.models import CurationEvidence
from memory_manager.service import MemoryService
from memory_manager.store import MemoryRepository
from tests.helpers import init_workspace, make_card


def test_duplicate_ids_are_rejected(tmp_path: Path) -> None:
    repo = MemoryRepository(tmp_path)
    repo.init_workspace(workspace_id="dupes", force=True)
    card = make_card(
        card_id="same-id",
        title="A",
        kind="architecture",
        summary="a",
        body="alpha",
    )
    repo.write_card(card, overwrite=True)
    (repo.cards_dir / "second.md").write_text(serialize_card(card), encoding="utf-8")

    with pytest.raises(ValidationError):
        repo.load_cards()


def test_search_filters_by_path(tmp_path: Path) -> None:
    init_workspace(
        tmp_path,
        [
            make_card(
                card_id="global",
                title="Architecture",
                kind="architecture",
                summary="global card",
                body="shared architecture",
                priority=100,
            ),
            make_card(
                card_id="feature",
                title="Feature",
                kind="pattern",
                summary="api only",
                body="api workflow",
                paths=["src/api/**"],
                priority=90,
            ),
        ],
    )
    service = MemoryService(tmp_path)
    cards = service.search("workflow", paths=["src/api/routes.py"])

    assert [card.id for card in cards] == ["feature"]


def test_priority_sorting_keeps_global_before_scoped(tmp_path: Path) -> None:
    init_workspace(
        tmp_path,
        [
            make_card(
                card_id="scoped-high",
                title="Scoped high",
                kind="pattern",
                summary="",
                body="scoped body",
                paths=["src/**"],
                priority=100,
            ),
            make_card(
                card_id="global-lower",
                title="Global lower",
                kind="architecture",
                summary="",
                body="body",
                priority=10,
            ),
        ],
    )
    service = MemoryService(tmp_path)
    cards = service.select_cards(target="generic", paths=["src/main.py"])

    assert [card.id for card in cards] == ["global-lower", "scoped-high"]


def test_suggest_updates_creates_new_card_when_no_memory_matches(tmp_path: Path) -> None:
    init_workspace(tmp_path, [])
    service = MemoryService(tmp_path)

    proposal = service.suggest_updates(
        CurationEvidence(
            task_summary="API validation conventions",
            implementation_summary="Validate request payloads before database writes.",
            changed_paths=["src/api/routes.py"],
            test_summary="Added route tests for invalid payloads.",
        )
    )

    assert proposal.status == "pending"
    assert len(proposal.changes) == 1
    assert proposal.changes[0].action == "create"
    assert proposal.changes[0].proposed_card.status == "active"


def test_suggest_updates_updates_matching_card(tmp_path: Path) -> None:
    init_workspace(
        tmp_path,
        [
            make_card(
                card_id="api-patterns",
                title="API patterns",
                kind="pattern",
                summary="Old API rules",
                body="Use generic handlers.",
                paths=["src/api/**"],
                priority=90,
            )
        ],
    )
    service = MemoryService(tmp_path)

    proposal = service.suggest_updates(
        CurationEvidence(
            task_summary="API patterns",
            implementation_summary="Validate input before touching the database and keep handlers typed.",
            changed_paths=["src/api/routes.py"],
        )
    )

    assert proposal.changes[0].action == "update"
    assert proposal.changes[0].target_card_id == "api-patterns"
    assert "body" in proposal.changes[0].field_diff


def test_deprecate_and_remove_flows_apply_safely(tmp_path: Path) -> None:
    init_workspace(
        tmp_path,
        [
            make_card(
                card_id="legacy-api",
                title="Legacy API",
                kind="pattern",
                summary="legacy flow",
                body="Use the old gateway.",
                paths=["src/api/**"],
            ),
            make_card(
                card_id="new-api",
                title="New API",
                kind="pattern",
                summary="new flow",
                body="Use the new gateway.",
                paths=["src/api/**"],
            ),
        ],
    )
    service = MemoryService(tmp_path)

    deprecate = service.suggest_updates(
        CurationEvidence(
            implementation_summary="memory:deprecate:legacy-api",
            changed_paths=["src/api/routes.py"],
        )
    )
    service.apply_proposal(deprecate.id, confirm=True)
    assert [card.id for card in service.list_cards()] == ["new-api"]
    deprecated = service.list_cards(include_deprecated=True)
    assert any(card.id == "legacy-api" and card.status == "deprecated" for card in deprecated)
    assert "Legacy API" not in service.render("generic").artifacts[0].content

    remove = service.suggest_updates(
        CurationEvidence(
            implementation_summary="memory:remove:legacy-api->new-api",
            changed_paths=["src/api/routes.py"],
        )
    )
    with pytest.raises(ProposalError):
        service.apply_proposal(remove.id, confirm=False)

    remove = service.suggest_updates(
        CurationEvidence(
            implementation_summary="memory:remove:legacy-api->new-api",
            changed_paths=["src/api/routes.py"],
        )
    )
    applied = service.apply_proposal(remove.id, confirm=True)
    assert applied.status == "applied"
    cards = service.list_cards(include_deprecated=True)
    assert [card.id for card in cards] == ["new-api"]
    assert cards[0].supersedes == ["legacy-api"]


def test_bootstrap_existing_project_creates_reviewable_cards(tmp_path: Path) -> None:
    (tmp_path / "README.md").write_text("# Existing Project\n\nThis project handles billing workflows.", encoding="utf-8")
    (tmp_path / "AGENTS.md").write_text("# Agent notes\n\nUse typed service boundaries.", encoding="utf-8")
    service = MemoryService(tmp_path)

    proposal = service.bootstrap(workspace_id="existing-project")

    assert proposal.evidence_digest.source_kind == "bootstrap"
    assert proposal.status == "pending"
    assert proposal.changes
    assert {change.action for change in proposal.changes} == {"create"}
    assert {"README.md", "AGENTS.md"} <= set(proposal.evidence_digest.source_paths)


def test_bootstrap_refreshes_existing_cards_with_delta_proposals(tmp_path: Path) -> None:
    init_workspace(
        tmp_path,
        [
            make_card(
                card_id="readme-md",
                title="Existing Project",
                kind="architecture",
                summary="Old summary",
                body="Old body",
                priority=90,
            )
        ],
    )
    (tmp_path / "README.md").write_text("# Existing Project\n\nNew architecture summary.", encoding="utf-8")
    service = MemoryService(tmp_path)

    proposal = service.bootstrap(workspace_id="existing-project")

    assert any(change.action == "update" and change.target_card_id == "readme-md" for change in proposal.changes)
    assert not any(change.action == "create" and change.target_card_id == "readme-md" for change in proposal.changes)


def test_bootstrap_can_apply_imported_cards(tmp_path: Path) -> None:
    (tmp_path / "README.md").write_text("# Existing Project\n\nThis project handles payments.", encoding="utf-8")
    service = MemoryService(tmp_path)

    applied = service.bootstrap(workspace_id="existing-project", apply=True)

    assert applied.status == "applied"
    cards = service.list_cards()
    assert any(card.id == "readme-md" for card in cards)


def test_apply_proposal_rejects_stale_card_revisions(tmp_path: Path) -> None:
    init_workspace(
        tmp_path,
        [
            make_card(
                card_id="api-patterns",
                title="API patterns",
                kind="pattern",
                summary="Typed handlers",
                body="Validate request payloads.",
                paths=["src/api/**"],
            )
        ],
    )
    service = MemoryService(tmp_path)
    proposal = service.suggest_updates(
        CurationEvidence(
            task_summary="API patterns",
            implementation_summary="Validate input before touching the database.",
            changed_paths=["src/api/routes.py"],
        )
    )

    repository = MemoryRepository(tmp_path)
    current = repository.load_cards()[0]
    repository.replace_cards(
        [
            current.clone_for_update(
                summary="Updated outside the proposal flow",
            )
        ]
    )

    with pytest.raises(ProposalError, match="stale"):
        service.apply_proposal(proposal.id, confirm=True)
