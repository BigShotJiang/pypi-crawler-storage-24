from __future__ import annotations

"""Shared pytest configuration lives here if needed later."""
