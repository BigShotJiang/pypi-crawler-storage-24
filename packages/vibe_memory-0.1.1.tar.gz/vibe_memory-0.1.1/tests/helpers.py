from __future__ import annotations

from pathlib import Path

import yaml

from memory_manager.models import Card, WorkspaceConfig
from memory_manager.store import MemoryRepository


def make_card(
    *,
    card_id: str,
    title: str,
    kind: str,
    summary: str,
    body: str,
    paths: list[str] | None = None,
    tags: list[str] | None = None,
    priority: int = 50,
    targets: list[str] | None = None,
) -> Card:
    return Card(
        id=card_id,
        title=title,
        kind=kind,
        summary=summary,
        body=body,
        paths=paths or [],
        tags=tags or [],
        priority=priority,
        targets=targets or ["codex", "claude", "cursor", "opencode", "generic"],
    )


def init_workspace(tmp_path: Path, cards: list[Card]) -> MemoryRepository:
    repo = MemoryRepository(tmp_path)
    repo.cards_dir.mkdir(parents=True, exist_ok=True)
    repo.dist_dir.mkdir(parents=True, exist_ok=True)
    config = WorkspaceConfig(workspace_id="test-workspace")
    repo.config_path.write_text(
        yaml.safe_dump(config.model_dump(mode="json"), sort_keys=False),
        encoding="utf-8",
    )
    for card in cards:
        repo.write_card(card, overwrite=False)
    repo.rebuild_index(cards)
    return repo

