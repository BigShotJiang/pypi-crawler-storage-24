from __future__ import annotations

from pathlib import Path

from typer.testing import CliRunner

from memory_manager.cli import app

runner = CliRunner()


def test_init_add_validate_and_render_flow(tmp_path: Path) -> None:
    init_result = runner.invoke(app, ["init", "--root", str(tmp_path), "--workspace-id", "demo"])
    assert init_result.exit_code == 0

    add_result = runner.invoke(
        app,
        [
            "add",
            "API patterns",
            "--root",
            str(tmp_path),
            "--kind",
            "pattern",
            "--summary",
            "api rules",
            "--body",
            "Validate input first.",
            "--paths",
            "src/api/**",
        ],
    )
    assert add_result.exit_code == 0

    validate_result = runner.invoke(app, ["validate", "--root", str(tmp_path)])
    assert validate_result.exit_code == 0

    render_result = runner.invoke(app, ["render", "codex", "--root", str(tmp_path)])
    assert render_result.exit_code == 0
    assert "# FILE: AGENTS.md" in render_result.stdout


def test_doctor_reports_native_file_presence(tmp_path: Path) -> None:
    runner.invoke(app, ["init", "--root", str(tmp_path), "--workspace-id", "demo"])
    (tmp_path / "AGENTS.md").write_text("do not touch", encoding="utf-8")

    result = runner.invoke(app, ["doctor", "--root", str(tmp_path)])

    assert result.exit_code == 0
    assert "native_present[AGENTS.md]: True" in result.stdout


def test_suggest_apply_and_reject_proposals_from_cli(tmp_path: Path) -> None:
    runner.invoke(app, ["init", "--root", str(tmp_path), "--workspace-id", "demo"])

    suggest = runner.invoke(
        app,
        [
            "suggest-updates",
            "--root",
            str(tmp_path),
            "--changed-paths",
            "src/api/routes.py",
            "--task-summary",
            "API validation conventions",
            "--implementation-summary",
            "Validate payloads before database writes.",
        ],
    )
    assert suggest.exit_code == 0
    proposal_id = next(
        line.split(": ", 1)[1] for line in suggest.stdout.splitlines() if line.startswith("proposal_id:")
    )

    show = runner.invoke(app, ["proposals", "show", proposal_id, "--root", str(tmp_path)])
    assert show.exit_code == 0
    assert "changes:" in show.stdout

    apply_result = runner.invoke(app, ["proposals", "apply", proposal_id, "--root", str(tmp_path)])
    assert apply_result.exit_code == 0
    assert "status: applied" in apply_result.stdout

    reject_candidate = runner.invoke(
        app,
        [
            "suggest-updates",
            "--root",
            str(tmp_path),
            "--changed-paths",
            "src/api/routes.py",
            "--implementation-summary",
            "memory:deprecate:architecture-overview",
        ],
    )
    reject_id = next(
        line.split(": ", 1)[1]
        for line in reject_candidate.stdout.splitlines()
        if line.startswith("proposal_id:")
    )
    reject_result = runner.invoke(
        app,
        ["proposals", "reject", reject_id, "--root", str(tmp_path), "--reason", "not now"],
    )
    assert reject_result.exit_code == 0
    assert "status: rejected" in reject_result.stdout


def test_bootstrap_cli_initializes_existing_project_and_emits_proposals(tmp_path: Path) -> None:
    (tmp_path / "README.md").write_text("# Existing Project\n\nThis project handles billing workflows.", encoding="utf-8")

    result = runner.invoke(
        app,
        ["bootstrap", "--root", str(tmp_path), "--workspace-id", "existing-project"],
    )

    assert result.exit_code == 0
    assert "source_kind: bootstrap" in result.stdout
    assert "proposal_id:" in result.stdout


def test_bootstrap_cli_apply_creates_cards(tmp_path: Path) -> None:
    (tmp_path / "README.md").write_text("# Existing Project\n\nThis project handles billing workflows.", encoding="utf-8")

    result = runner.invoke(
        app,
        ["bootstrap", "--root", str(tmp_path), "--workspace-id", "existing-project", "--apply"],
    )

    assert result.exit_code == 0
    assert "status: applied" in result.stdout

    list_result = runner.invoke(app, ["list", "--root", str(tmp_path)])
    assert "readme-md" in list_result.stdout
