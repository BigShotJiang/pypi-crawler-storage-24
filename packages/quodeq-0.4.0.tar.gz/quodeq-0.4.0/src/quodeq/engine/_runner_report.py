"""Full pipeline runner — scores and writes per-dimension reports."""
from __future__ import annotations

from pathlib import Path

from quodeq.engine.runner import RunConfig, run_per_dimension, cleanup_stream


def run_full(config: RunConfig, output_dir: Path, mode: str = "numerical") -> dict:
    """Full pipeline: run per-dimension → score each → write per-dimension reports.

    Returns dict of {dimension: overall_score_str}.
    """
    from quodeq.engine.scoring import score_evidence
    from quodeq.engine.report import write_dimension_report

    work_dir = config.work_dir or config.src
    per_dim_evidence = run_per_dimension(config)
    results: dict[str, str] = {}

    for dimension, evidence in per_dim_evidence.items():
        scores = score_evidence(evidence, mode=mode)
        write_dimension_report(evidence, scores, dimension, output_dir)
        # Clean up stream now that the eval JSON exists
        cleanup_stream(work_dir / f"{dimension}_live.stream")
        overall = scores.get("overall", {})
        if mode == "numerical":
            val = overall.get("weighted_score")
            results[dimension] = f"{val}/10" if val is not None else "N/A"
        else:
            results[dimension] = overall.get("weighted_grade", "N/A")

    return results
