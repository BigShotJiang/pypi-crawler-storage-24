"""Benchmark runner for LLMHosts Core inference engine.

Sends concurrent completion requests to a running llmhosts server and measures
TTFT, throughput, latency percentiles, and VRAM usage.
"""

from __future__ import annotations

import asyncio
import json
import statistics
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone

import httpx

# ---------------------------------------------------------------------------
# Synthetic prompts of varying lengths (no real model required in CI).
# These are character-approximate stand-ins; real benchmarks use GGUF models.
# ---------------------------------------------------------------------------

_SHORT_PROMPT = " ".join(["hello world"] * 10)  # ~100 tokens
_MEDIUM_PROMPT = " ".join(["The quick brown fox jumped over the lazy dog."] * 20)  # ~512 tokens
_LONG_PROMPT = " ".join(["Artificial intelligence is transforming every industry."] * 60)  # ~2048 tokens

_PROMPT_BY_LENGTH: dict[int, str] = {
    100: _SHORT_PROMPT,
    512: _MEDIUM_PROMPT,
    2048: _LONG_PROMPT,
}


@dataclass
class BenchmarkResult:
    """Single benchmark measurement for one (model, scenario, prompt_length) combination."""

    model: str
    scenario: str  # "single" | "concurrent_2" | "concurrent_4" | "concurrent_8"
    prompt_length: int  # approximate token count: 100 | 512 | 2048
    ttft_ms: float  # Time To First Token P50 (ms)
    ttft_p95_ms: float  # Time To First Token P95 (ms)
    throughput_tps: float  # tokens per second (output throughput)
    latency_p50_ms: float  # end-to-end latency P50 (ms)
    latency_p95_ms: float  # end-to-end latency P95 (ms)
    latency_p99_ms: float  # end-to-end latency P99 (ms)
    vram_used_gb: float  # VRAM consumed at peak (0.0 on CPU-only runners)
    backend: str  # "cuda" | "wgpu" | "cpu"
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    # Number of samples used to calculate the percentiles
    sample_count: int = 0

    def to_dict(self) -> dict[str, object]:
        """Serialize to a plain dict for JSON export."""
        return {
            "model": self.model,
            "scenario": self.scenario,
            "prompt_length": self.prompt_length,
            "ttft_ms": self.ttft_ms,
            "ttft_p95_ms": self.ttft_p95_ms,
            "throughput_tps": self.throughput_tps,
            "latency_p50_ms": self.latency_p50_ms,
            "latency_p95_ms": self.latency_p95_ms,
            "latency_p99_ms": self.latency_p99_ms,
            "vram_used_gb": self.vram_used_gb,
            "backend": self.backend,
            "timestamp": self.timestamp,
            "sample_count": self.sample_count,
        }

    @classmethod
    def from_dict(cls, data: dict[str, object]) -> BenchmarkResult:
        """Deserialize from a plain dict (JSON import)."""
        return cls(
            model=str(data["model"]),
            scenario=str(data["scenario"]),
            prompt_length=int(data["prompt_length"]),  # type: ignore[call-overload]
            ttft_ms=float(data["ttft_ms"]),  # type: ignore[arg-type]
            ttft_p95_ms=float(data["ttft_p95_ms"]),  # type: ignore[arg-type]
            throughput_tps=float(data["throughput_tps"]),  # type: ignore[arg-type]
            latency_p50_ms=float(data["latency_p50_ms"]),  # type: ignore[arg-type]
            latency_p95_ms=float(data["latency_p95_ms"]),  # type: ignore[arg-type]
            latency_p99_ms=float(data["latency_p99_ms"]),  # type: ignore[arg-type]
            vram_used_gb=float(data["vram_used_gb"]),  # type: ignore[arg-type]
            backend=str(data["backend"]),
            timestamp=str(data.get("timestamp", "")),
            sample_count=int(data.get("sample_count", 0)),  # type: ignore[call-overload]
        )


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _percentile(values: list[float], p: float) -> float:
    """Return the p-th percentile of *values* (0-100).

    Uses nearest-rank method (no interpolation) for simplicity.
    Returns 0.0 for empty lists.
    """
    if not values:
        return 0.0
    sorted_vals = sorted(values)
    idx = max(0, int(len(sorted_vals) * p / 100) - 1)
    return sorted_vals[idx]


async def _single_request(
    client: httpx.AsyncClient,
    base_url: str,
    model: str,
    prompt: str,
    max_tokens: int = 64,
) -> tuple[float, float, int]:
    """Fire one /v1/chat/completions request (SSE streaming) and measure:

    Returns:
        (ttft_ms, total_ms, token_count) — TTFT measured to first SSE data chunk.
    """
    payload = {
        "model": model,
        "messages": [{"role": "user", "content": prompt}],
        "max_tokens": max_tokens,
        "stream": True,
    }

    ttft_ms = 0.0
    token_count = 0
    first_token_seen = False
    start = time.perf_counter()

    try:
        async with client.stream(
            "POST",
            f"{base_url}/v1/chat/completions",
            json=payload,
            timeout=120.0,
        ) as response:
            response.raise_for_status()
            async for line in response.aiter_lines():
                if not line.startswith("data: "):
                    continue
                data_part = line[6:].strip()
                if data_part in ("", "[DONE]"):
                    continue
                if not first_token_seen:
                    ttft_ms = (time.perf_counter() - start) * 1000
                    first_token_seen = True
                # Count tokens via delta content length (approximate)
                try:
                    chunk = json.loads(data_part)
                    delta = chunk.get("choices", [{}])[0].get("delta", {})
                    content = delta.get("content", "")
                    if content:
                        # Approximate: 1 token ≈ 4 chars
                        token_count += max(1, len(content) // 4)
                except (json.JSONDecodeError, IndexError, KeyError):
                    pass
    except httpx.HTTPStatusError:
        # Server returned an error — record a degraded result rather than crashing
        total_ms = (time.perf_counter() - start) * 1000
        return total_ms, total_ms, 0

    total_ms = (time.perf_counter() - start) * 1000
    if not first_token_seen:
        ttft_ms = total_ms  # no streaming — fallback

    return ttft_ms, total_ms, max(token_count, 1)


async def _fetch_backend_info(client: httpx.AsyncClient, base_url: str) -> tuple[str, float]:
    """Return (backend, vram_used_gb) from /health endpoint.

    Falls back to ("cpu", 0.0) if the endpoint is unavailable.
    """
    try:
        resp = await client.get(f"{base_url}/health", timeout=5.0)
        if resp.status_code == 200:
            data = resp.json()
            backend = data.get("engine_backend", "cpu")
            vram_gb = float(data.get("vram_used_gb", 0.0))
            return backend, vram_gb
    except Exception:
        pass
    return "cpu", 0.0


async def _run_scenario(
    client: httpx.AsyncClient,
    base_url: str,
    model: str,
    concurrency: int,
    prompt: str,
    prompt_length: int,
    repeats: int = 5,
) -> BenchmarkResult:
    """Run *concurrency* concurrent requests *repeats* times and aggregate."""
    scenario = "single" if concurrency == 1 else f"concurrent_{concurrency}"

    backend, vram_gb = await _fetch_backend_info(client, base_url)

    all_ttfts: list[float] = []
    all_latencies: list[float] = []
    all_tps: list[float] = []

    for _ in range(repeats):
        tasks = [_single_request(client, base_url, model, prompt) for _ in range(concurrency)]
        batch_start = time.perf_counter()
        results = await asyncio.gather(*tasks, return_exceptions=True)
        batch_elapsed_s = time.perf_counter() - batch_start

        total_tokens = 0
        for r in results:
            if isinstance(r, BaseException):
                continue
            ttft_ms, total_ms, tok = r
            all_ttfts.append(ttft_ms)
            all_latencies.append(total_ms)
            total_tokens += tok

        # Throughput: total tokens generated / wall-clock time for entire batch
        if batch_elapsed_s > 0 and total_tokens > 0:
            all_tps.append(total_tokens / batch_elapsed_s)

    return BenchmarkResult(
        model=model,
        scenario=scenario,
        prompt_length=prompt_length,
        ttft_ms=_percentile(all_ttfts, 50),
        ttft_p95_ms=_percentile(all_ttfts, 95),
        throughput_tps=statistics.mean(all_tps) if all_tps else 0.0,
        latency_p50_ms=_percentile(all_latencies, 50),
        latency_p95_ms=_percentile(all_latencies, 95),
        latency_p99_ms=_percentile(all_latencies, 99),
        vram_used_gb=vram_gb,
        backend=backend,
        sample_count=len(all_latencies),
    )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


async def run_benchmark(
    model_path: str,
    concurrency: list[int],
    prompt_lengths: list[int],
    base_url: str = "http://localhost:11400",
    repeats: int = 5,
) -> list[BenchmarkResult]:
    """Run the full benchmark suite against a running llmhosts server.

    Args:
        model_path: Path or name of the model to benchmark. Used as identifier
                    in results; the server must already have this model loaded.
        concurrency: List of concurrency levels, e.g. [1, 2, 4].
        prompt_lengths: List of approximate prompt token counts, e.g. [100, 512, 2048].
        base_url: Base URL of the running llmhosts server.
        repeats: Number of repeat runs per (concurrency, prompt_length) combination.

    Returns:
        List of BenchmarkResult, one per (concurrency, prompt_length) combination.
    """
    results: list[BenchmarkResult] = []

    async with httpx.AsyncClient() as client:
        for prompt_length in prompt_lengths:
            prompt = _PROMPT_BY_LENGTH.get(prompt_length, _PROMPT_BY_LENGTH[100])
            for c in concurrency:
                result = await _run_scenario(
                    client=client,
                    base_url=base_url,
                    model=model_path,
                    concurrency=c,
                    prompt=prompt,
                    prompt_length=prompt_length,
                    repeats=repeats,
                )
                results.append(result)

    return results
