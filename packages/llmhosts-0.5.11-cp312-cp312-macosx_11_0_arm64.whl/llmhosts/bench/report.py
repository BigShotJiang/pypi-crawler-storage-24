"""Benchmark report formatters.

Produces human-readable Markdown (for GitHub Step Summary / PR comments)
and machine-readable JSON (for artifact storage and future baseline diffs).
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import TYPE_CHECKING

from llmhosts.bench.runner import BenchmarkResult

if TYPE_CHECKING:
    from llmhosts.bench.compare import ComparisonReport, MetricDelta, ScenarioComparison

# ---------------------------------------------------------------------------
# JSON serialisation
# ---------------------------------------------------------------------------


def format_json_report(results: list[BenchmarkResult]) -> str:
    """Serialize benchmark results to JSON string.

    The top-level structure is::

        {
            "generated_at": "<ISO timestamp>",
            "result_count": <int>,
            "results": [ {BenchmarkResult fields...}, ... ]
        }
    """
    payload = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "result_count": len(results),
        "results": [r.to_dict() for r in results],
    }
    return json.dumps(payload, indent=2)


def load_json_results(json_str: str) -> list[BenchmarkResult]:
    """Deserialize a JSON string produced by :func:`format_json_report`."""
    payload = json.loads(json_str)
    raw = payload.get("results", payload) if isinstance(payload, dict) else payload
    if isinstance(raw, list):
        return [BenchmarkResult.from_dict(item) for item in raw]
    return []


# ---------------------------------------------------------------------------
# Markdown formatting helpers
# ---------------------------------------------------------------------------


def _change_badge(delta: MetricDelta) -> str:
    """Return a compact badge string for a metric delta."""
    pct = delta.change_pct * 100
    sign = "+" if pct >= 0 else ""
    label = f"{sign}{pct:.1f}%"
    if delta.is_regression:
        return f"🔴 **{label}** (regression)"
    if abs(pct) < 1.0:
        return f"✅ {label} (stable)"
    if pct < 0:
        return f"🟢 {label} (improvement)"
    return f"🟡 {label}"


def _format_scenario_comparison(sc: ScenarioComparison) -> str:
    """Render a single scenario comparison as a Markdown table section."""
    lines: list[str] = []
    emoji = "❌" if sc.has_regression else "✅"
    lines.append(f"#### {emoji} `{sc.scenario}` — prompt {sc.prompt_length} tokens")
    lines.append("")
    lines.append("| Metric | Baseline | Current | Change |")
    lines.append("|--------|----------|---------|--------|")
    for d in sc.deltas:
        base_fmt = f"{d.baseline_value:.1f}"
        curr_fmt = f"{d.current_value:.1f}"
        badge = _change_badge(d)
        lines.append(f"| `{d.metric}` | {base_fmt} | {curr_fmt} | {badge} |")
    lines.append("")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def format_markdown_report(
    results: list[BenchmarkResult],
    comparison: ComparisonReport | None = None,
) -> str:
    """Generate a Markdown benchmark report.

    When *comparison* is provided the report includes a regression section.
    This output is suitable for GitHub Step Summary (``>> $GITHUB_STEP_SUMMARY``)
    and PR comments.

    Args:
        results: Benchmark results from the current run.
        comparison: Optional comparison report from :func:`compare_results`.

    Returns:
        Multi-line Markdown string.
    """
    lines: list[str] = []

    # ---- Header ----
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    lines.append("## LLMHosts Core — Benchmark Report")
    lines.append("")
    lines.append(f"*Generated {ts}*")
    lines.append("")

    # ---- Regression summary (if comparison provided) ----
    if comparison is not None:
        if comparison.passed:
            lines.append("### ✅ Regression Gate: PASSED")
            lines.append(f"No metrics regressed more than {comparison.threshold * 100:.0f}%.")
        else:
            regressions = comparison.total_regressions
            lines.append("### ❌ Regression Gate: FAILED")
            lines.append(
                f"**{regressions} metric(s)** regressed by more than {comparison.threshold * 100:.0f}% vs baseline."
            )
        lines.append("")

    # ---- Current results table ----
    lines.append("### Current Run Results")
    lines.append("")
    lines.append(
        "| Model | Scenario | Tokens | Backend | TTFT P50 (ms) | TTFT P95 (ms) "
        "| Throughput (tps) | Latency P50 (ms) | Latency P95 (ms) | Latency P99 (ms) |"
    )
    lines.append(
        "|-------|----------|--------|---------|---------------|---------------|"
        "-----------------|-----------------|-----------------|-----------------|"
    )
    for r in results:
        model_short = r.model.split("/")[-1][:30]
        lines.append(
            f"| {model_short} | {r.scenario} | {r.prompt_length} | {r.backend} "
            f"| {r.ttft_ms:.1f} | {r.ttft_p95_ms:.1f} "
            f"| {r.throughput_tps:.1f} | {r.latency_p50_ms:.1f} "
            f"| {r.latency_p95_ms:.1f} | {r.latency_p99_ms:.1f} |"
        )
    lines.append("")

    # ---- Regression details ----
    if comparison is not None and comparison.scenarios:
        lines.append("### Regression Details")
        lines.append("")
        lines.append(f"Threshold: >{comparison.threshold * 100:.0f}% degradation = regression")
        lines.append("")
        for sc in comparison.scenarios:
            lines.append(_format_scenario_comparison(sc))

    # ---- Footer ----
    lines.append("---")
    lines.append("*Powered by [LLMHosts Core](https://llmhosts.com) — Rust inference engine*")
    lines.append("")

    return "\n".join(lines)
