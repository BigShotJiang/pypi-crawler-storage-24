"""Benchmark comparison engine.

Compares a current result set against a baseline and flags regressions that
exceed a configurable threshold. A regression is defined as a *worsening*:
  - latency/TTFT increasing by > threshold (higher is worse)
  - throughput decreasing by > threshold (lower is worse)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from llmhosts.bench.runner import BenchmarkResult

# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------


@dataclass
class MetricDelta:
    """Change in a single metric between current and baseline."""

    metric: str
    baseline_value: float
    current_value: float
    change_pct: float  # positive = current is worse, negative = current is better
    is_regression: bool
    threshold: float


@dataclass
class ScenarioComparison:
    """Comparison for one (model, scenario, prompt_length) combination."""

    model: str
    scenario: str
    prompt_length: int
    deltas: list[MetricDelta] = field(default_factory=list)

    @property
    def has_regression(self) -> bool:
        return any(d.is_regression for d in self.deltas)

    @property
    def regression_count(self) -> int:
        return sum(1 for d in self.deltas if d.is_regression)


@dataclass
class ComparisonReport:
    """Full comparison report between current and baseline result sets."""

    scenarios: list[ScenarioComparison] = field(default_factory=list)
    threshold: float = 0.05
    passed: bool = True  # False if any regression found

    @property
    def total_regressions(self) -> int:
        return sum(s.regression_count for s in self.scenarios)

    @property
    def regressed_scenarios(self) -> list[ScenarioComparison]:
        return [s for s in self.scenarios if s.has_regression]


# ---------------------------------------------------------------------------
# Comparison logic
# ---------------------------------------------------------------------------


def _make_key(r: BenchmarkResult) -> tuple[str, str, int]:
    """Build a lookup key from a BenchmarkResult."""
    return (r.model, r.scenario, r.prompt_length)


def _latency_change_pct(baseline: float, current: float) -> float:
    """Return signed percentage change where positive = regression (latency went up)."""
    if baseline <= 0:
        return 0.0
    return (current - baseline) / baseline


def _throughput_change_pct(baseline: float, current: float) -> float:
    """Return signed percentage change where positive = regression (throughput went down)."""
    if baseline <= 0:
        return 0.0
    return (baseline - current) / baseline  # note: inverted vs latency


def _compare_scenario(
    current: BenchmarkResult,
    baseline: BenchmarkResult,
    threshold: float,
) -> ScenarioComparison:
    """Compute per-metric deltas for one matched (model, scenario, prompt_length) pair."""
    deltas: list[MetricDelta] = []

    # Latency-type metrics: higher = worse
    latency_metrics: list[tuple[str, float, float]] = [
        ("ttft_ms", baseline.ttft_ms, current.ttft_ms),
        ("ttft_p95_ms", baseline.ttft_p95_ms, current.ttft_p95_ms),
        ("latency_p50_ms", baseline.latency_p50_ms, current.latency_p50_ms),
        ("latency_p95_ms", baseline.latency_p95_ms, current.latency_p95_ms),
        ("latency_p99_ms", baseline.latency_p99_ms, current.latency_p99_ms),
    ]
    for name, base_val, curr_val in latency_metrics:
        if base_val <= 0:
            continue
        change = _latency_change_pct(base_val, curr_val)
        deltas.append(
            MetricDelta(
                metric=name,
                baseline_value=base_val,
                current_value=curr_val,
                change_pct=change,
                is_regression=change > threshold,
                threshold=threshold,
            )
        )

    # Throughput: lower = worse
    if baseline.throughput_tps > 0:
        change = _throughput_change_pct(baseline.throughput_tps, current.throughput_tps)
        deltas.append(
            MetricDelta(
                metric="throughput_tps",
                baseline_value=baseline.throughput_tps,
                current_value=current.throughput_tps,
                change_pct=change,
                is_regression=change > threshold,
                threshold=threshold,
            )
        )

    return ScenarioComparison(
        model=current.model,
        scenario=current.scenario,
        prompt_length=current.prompt_length,
        deltas=deltas,
    )


def compare_results(
    current: list[BenchmarkResult],
    baseline: list[BenchmarkResult],
    regression_threshold: float = 0.05,
) -> ComparisonReport:
    """Compare two result sets and return a ComparisonReport.

    Only compares results that exist in *both* sets (matched by model, scenario,
    prompt_length). Results present in current but not baseline are skipped
    (treated as new scenarios — not a regression).

    Args:
        current: Results from the current commit.
        baseline: Results from the previous/reference run.
        regression_threshold: Fraction (0-1) by which a metric must worsen to
                               count as a regression. Default 0.05 = 5%.

    Returns:
        ComparisonReport with per-scenario breakdown and overall pass/fail.
    """
    baseline_map: dict[tuple[str, str, int], BenchmarkResult] = {_make_key(r): r for r in baseline}
    scenarios: list[ScenarioComparison] = []

    for curr in current:
        key = _make_key(curr)
        base = baseline_map.get(key)
        if base is None:
            # New scenario — no baseline to compare against, skip
            continue
        sc = _compare_scenario(curr, base, regression_threshold)
        scenarios.append(sc)

    has_any_regression = any(s.has_regression for s in scenarios)
    return ComparisonReport(
        scenarios=scenarios,
        threshold=regression_threshold,
        passed=not has_any_regression,
    )
