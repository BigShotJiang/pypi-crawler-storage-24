"""LLMHosts benchmark package.

Provides automated benchmark regression testing for LLMHosts Core (Rust inference engine).

Usage:
    llmhosts bench run --model path/to/model.gguf --concurrency 1,2,4
    llmhosts bench compare current.json baseline.json --threshold 0.05
    llmhosts bench report current.json --format markdown
"""

from __future__ import annotations

from llmhosts.bench.compare import ComparisonReport, compare_results
from llmhosts.bench.report import format_json_report, format_markdown_report
from llmhosts.bench.runner import BenchmarkResult, run_benchmark

__all__ = [
    "BenchmarkResult",
    "ComparisonReport",
    "compare_results",
    "format_json_report",
    "format_markdown_report",
    "run_benchmark",
]
