"""Self-update mechanism for LLMHosts.

Checks for new versions on startup (non-blocking background thread),
downloads updates, and applies them atomically on next launch.

Architecture follows the Claude Code / Ollama pattern:
1. On startup: background thread checks /releases/latest.json
2. If newer version available: download to ~/.llmhosts/updates/
3. Verify SHA256 checksum
4. On next launch: atomic rename (new → current)

Opt-out: set LLMHOSTS_DISABLE_UPDATE=1 or `llmhosts config set auto-update false`
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import platform
import shutil
import sys
import tempfile
import threading
from pathlib import Path
from typing import Any

import httpx

from llmhosts import __version__

logger = logging.getLogger(__name__)

# Where to check for new versions
_MANIFEST_URL = "https://llmhosts.com/releases/latest.json"
_STABLE_MANIFEST_URL = "https://llmhosts.com/releases/stable.json"

# Update storage
_UPDATES_DIR = Path.home() / ".llmhosts" / "updates"
_VERSION_FILE = _UPDATES_DIR / "pending_version.json"


def _current_platform() -> str:
    """Return the current platform key matching the manifest format."""
    system = platform.system().lower()
    machine = platform.machine().lower()

    os_map = {"linux": "linux", "darwin": "darwin", "windows": "win"}
    arch_map = {
        "x86_64": "x86_64",
        "amd64": "x86_64",
        "aarch64": "aarch64",
        "arm64": "aarch64",
    }

    os_key = os_map.get(system, system)
    arch_key = arch_map.get(machine, machine)
    return f"{os_key}-{arch_key}"


def _is_update_disabled() -> bool:
    """Check if auto-update is disabled via env var or config."""
    if os.environ.get("LLMHOSTS_DISABLE_UPDATE", "").strip() in ("1", "true", "yes"):
        return True

    config_path = Path.home() / ".llmhosts" / "config.toml"
    if config_path.exists():
        try:
            import tomllib

            with open(config_path, "rb") as f:
                config = tomllib.load(f)
            if config.get("auto_update") is False or config.get("auto-update") is False:
                return True
        except Exception:
            pass

    return False


def _get_channel() -> str:
    """Get the configured release channel."""
    config_path = Path.home() / ".llmhosts" / "config.toml"
    if config_path.exists():
        try:
            import tomllib

            with open(config_path, "rb") as f:
                config = tomllib.load(f)
            channel = config.get("update_channel") or config.get("update-channel")
            if channel in ("stable", "latest"):
                return str(channel)
        except Exception:
            pass
    return "latest"


def check_for_update() -> dict[str, Any] | None:
    """Check if a newer version is available. Returns manifest dict or None.

    This is a synchronous call (meant to run in a background thread).
    """
    if _is_update_disabled():
        logger.debug("Auto-update disabled")
        return None

    channel = _get_channel()
    manifest_url = _STABLE_MANIFEST_URL if channel == "stable" else _MANIFEST_URL

    try:
        with httpx.Client(timeout=5.0) as client:
            resp = client.get(manifest_url)
            if resp.status_code != 200:
                logger.debug("Version check returned %d", resp.status_code)
                return None

            manifest = resp.json()
    except Exception as exc:
        logger.debug("Version check failed: %s", exc)
        return None

    remote_version = manifest.get("version", "")
    if not remote_version:
        return None

    # Compare versions (simple tuple comparison)
    try:
        local_parts = tuple(int(x) for x in __version__.split(".")[:3])
        remote_parts = tuple(int(x) for x in remote_version.split(".")[:3])
    except ValueError:
        return None

    if remote_parts <= local_parts:
        logger.debug("Already up to date: %s (remote: %s)", __version__, remote_version)
        return None

    # Check if we have a binary for this platform
    plat = _current_platform()
    binaries = manifest.get("binaries", {})
    if plat not in binaries:
        logger.debug("No binary for platform %s", plat)
        return None

    logger.info("Update available: %s → %s", __version__, remote_version)
    return dict(manifest)


def download_update(manifest: dict[str, Any]) -> Path | None:
    """Download the update binary and verify its SHA256 checksum.

    Returns the path to the verified binary, or None on failure.
    """
    plat = _current_platform()
    binary_info = manifest.get("binaries", {}).get(plat)
    if not binary_info:
        return None

    url = binary_info.get("url", "")
    expected_sha = binary_info.get("sha256", "")
    if not url or not expected_sha:
        logger.warning("Manifest missing url or sha256 for %s", plat)
        return None

    _UPDATES_DIR.mkdir(parents=True, exist_ok=True)

    try:
        with httpx.Client(timeout=300.0, follow_redirects=True) as client, client.stream("GET", url) as resp:
            resp.raise_for_status()

            # Download to temp file
            with tempfile.NamedTemporaryFile(dir=_UPDATES_DIR, prefix="llmhosts-", delete=False) as tmp:
                sha = hashlib.sha256()
                for chunk in resp.iter_bytes(chunk_size=65536):
                    tmp.write(chunk)
                    sha.update(chunk)
                tmp_path = Path(tmp.name)

        # Verify SHA256
        actual_sha = sha.hexdigest()
        if actual_sha != expected_sha:
            logger.error("SHA256 mismatch: expected %s, got %s", expected_sha, actual_sha)
            tmp_path.unlink(missing_ok=True)
            return None

        # Mark as executable
        tmp_path.chmod(0o755)

        # Save version metadata
        _VERSION_FILE.write_text(
            json.dumps(
                {
                    "version": manifest["version"],
                    "binary": str(tmp_path),
                    "sha256": actual_sha,
                    "platform": plat,
                }
            )
        )

        logger.info("Update downloaded: %s (%s)", manifest["version"], tmp_path)
        return tmp_path

    except Exception as exc:
        logger.debug("Update download failed: %s", exc)
        return None


def apply_pending_update() -> str | None:
    """Apply a previously downloaded update. Returns the new version, or None.

    Call this at startup BEFORE doing anything else.
    """
    if not _VERSION_FILE.exists():
        return None

    try:
        meta = json.loads(_VERSION_FILE.read_text())
    except Exception:
        _VERSION_FILE.unlink(missing_ok=True)
        return None

    binary_path = Path(meta.get("binary", ""))
    if not binary_path.exists():
        _VERSION_FILE.unlink(missing_ok=True)
        return None

    # Determine current binary location
    current_binary = Path(sys.executable)

    # If running from a venv wrapper, find the actual llmhosts binary
    wrapper = Path.home() / ".local" / "bin" / "llmhosts"
    if wrapper.exists():
        current_binary = wrapper

    try:
        # Atomic replacement: copy new → backup old → rename new
        backup_path = current_binary.with_suffix(".bak")

        if current_binary.exists():
            shutil.copy2(current_binary, backup_path)

        shutil.move(str(binary_path), str(current_binary))
        current_binary.chmod(0o755)

        # Cleanup
        _VERSION_FILE.unlink(missing_ok=True)
        backup_path.unlink(missing_ok=True)

        version: str = meta.get("version", "unknown")
        logger.info("Updated to %s", version)
        return version

    except Exception as exc:
        logger.error("Update apply failed: %s", exc)
        # Restore backup if exists
        backup_path = current_binary.with_suffix(".bak")
        if backup_path.exists():
            shutil.move(str(backup_path), str(current_binary))
        _VERSION_FILE.unlink(missing_ok=True)
        return None


def revert_update() -> bool:
    """Revert to the previous version if a backup exists."""
    current_binary = Path.home() / ".local" / "bin" / "llmhosts"
    backup_path = current_binary.with_suffix(".bak")

    if not backup_path.exists():
        return False

    try:
        shutil.move(str(backup_path), str(current_binary))
        current_binary.chmod(0o755)
        return True
    except Exception as exc:
        logger.error("Revert failed: %s", exc)
        return False


def background_update_check() -> None:
    """Run the update check in a background thread (non-blocking).

    Call this from the CLI startup path. It won't slow down the CLI.
    """
    if _is_update_disabled():
        return

    def _check() -> None:
        manifest = check_for_update()
        if manifest:
            version = manifest.get("version", "unknown")
            logger.info(
                "Update available: %s → %s. Run 'llmhosts update' to apply, or it will apply on next restart.",
                __version__,
                version,
            )
            # Download in background (don't auto-apply — apply on next launch)
            download_update(manifest)

    thread = threading.Thread(target=_check, daemon=True, name="llmhosts-updater")
    thread.start()
