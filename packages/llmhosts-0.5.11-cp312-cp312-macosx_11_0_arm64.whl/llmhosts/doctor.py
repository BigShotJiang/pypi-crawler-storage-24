"""Comprehensive system health verification for ``llmhost doctor``.

The :class:`Doctor` class runs a suite of diagnostic checks concurrently and
returns structured :class:`DoctorCheck` results.  This module centralises
all doctor logic that previously lived in ``cli.py``.
"""

from __future__ import annotations

import asyncio
import importlib
import logging
import os
import platform
import re
import shutil
import socket
import ssl
import sys
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from llmhosts.banner import DoctorCheck

logger = logging.getLogger(__name__)


class Doctor:
    """Comprehensive system health verification.

    Checks: Python, config, inference engine, keys, port, tier, disk,
    hardware, proxy responsiveness, cache, database integrity.

    Usage::

        doctor = Doctor()
        results = await doctor.run_all()
        print_doctor_report(results)
    """

    def __init__(self, config: Any | None = None, data_dir: Path | None = None) -> None:
        """Initialise the doctor.

        Args:
            config: An :class:`~llmhost.config.LLMHostsConfig` instance.
                    If ``None``, one is loaded from default location.
            data_dir: Override for ``~/.llmhosts``.  Used mainly in tests.
        """
        if config is None:
            from llmhosts.config import load_config

            config = load_config()
        self._config = config
        self._data_dir = data_dir or self._default_data_dir()

    @staticmethod
    def _default_data_dir() -> Path:
        from llmhosts.constants import DATA_DIR_NAME

        return Path.home() / DATA_DIR_NAME

    # ------------------------------------------------------------------
    # Main entry point
    # ------------------------------------------------------------------

    async def run_all(self) -> list[DoctorCheck]:
        """Run all checks concurrently where possible.

        Returns:
            A list of :class:`DoctorCheck` results ordered by category.
        """
        # Group into concurrent and sequential checks
        tasks = [
            self.check_python(),
            self.check_install_method(),
            self.check_path(),
            self.check_config(),
            self.check_ollama(),
            self.check_keys(),
            self.check_port(),
            self.check_tier(),
            self.check_disk(),
            self.check_disk_for_models(),
            self.check_model_storage(),
            self.check_model_integrity(),
            self.check_hardware(),
            self.check_gpu_drivers(),
            self.check_gpu_utilization(),
            self.check_cuda_runtime(),
            self.check_cuda_backend(),
            self.check_binary_version(),
            self.check_relay_connectivity(),
            self.check_cuda_backend(),
            self.check_model_registry_network(),
            self.check_database(),
            self.check_cache(),
            self.check_relay(),
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        checks: list[DoctorCheck] = []
        for result in results:
            if isinstance(result, DoctorCheck):
                checks.append(result)
            elif isinstance(result, BaseException):
                checks.append(
                    DoctorCheck(
                        name="Unknown",
                        status="fail",
                        message=f"Check raised exception: {result}",
                    )
                )
        return checks

    # ------------------------------------------------------------------
    # Individual checks
    # ------------------------------------------------------------------

    async def check_python(self) -> DoctorCheck:
        """Verify Python version >= 3.10."""
        py_ver = platform.python_version()
        py_ok = sys.version_info >= (3, 10)
        status = "ok" if py_ok else "fail"
        message = f"Python {py_ver} — {'supported' if py_ok else 'unsupported (need 3.10+)'}"
        return DoctorCheck(
            name="Python version",
            status=status,
            message=message,
            suggestion="LLMHosts requires Python 3.10+. Upgrade your Python installation." if not py_ok else None,
        )

    async def check_config(self) -> DoctorCheck:
        """Verify config file exists and is valid TOML."""
        from llmhosts.config import llmhosts_dir

        cfg_path = llmhosts_dir() / "config.toml"
        if not cfg_path.is_file():
            return DoctorCheck(
                name="Config file",
                status="warn",
                message="Not found (using defaults)",
                suggestion="Run: mkdir -p ~/.llmhosts && llmhost config init",
            )

        # Validate TOML syntax
        try:
            import toml  # type: ignore[import-untyped]

            toml.load(cfg_path)
            return DoctorCheck(
                name="Config file",
                status="ok",
                message=str(cfg_path),
            )
        except Exception as exc:
            return DoctorCheck(
                name="Config file",
                status="fail",
                message=f"Invalid TOML: {exc}",
                suggestion="Fix syntax errors in your config.toml or delete it to use defaults.",
            )

    async def check_ollama(self) -> DoctorCheck:
        """Ping inference engine, list models."""
        try:
            from llmhosts.discovery.ollama import OllamaDiscovery

            ollama_host = self._config.ollama.host
            async with OllamaDiscovery(host=ollama_host, timeout=5.0) as ollama:
                if await ollama.is_available():
                    models = await ollama.list_models()
                    model_names = ", ".join(m.name for m in models[:5])
                    suffix = f" (+{len(models) - 5} more)" if len(models) > 5 else ""
                    if models:
                        return DoctorCheck(
                            name="Inference Engine",
                            status="ok",
                            message=f"Running at {ollama_host}, {len(models)} model(s): {model_names}{suffix}",
                        )
                    return DoctorCheck(
                        name="Inference Engine",
                        status="warn",
                        message=f"Running at {ollama_host} but no models installed",
                        suggestion="Pull a model with: llmhosts serve (auto-provisions)",
                    )
                return DoctorCheck(
                    name="Inference Engine",
                    status="warn",
                    message=f"Not reachable at {ollama_host}",
                    suggestion="Run: llmhosts serve (auto-installs inference engine)",
                )
        except Exception as exc:
            return DoctorCheck(name="Inference Engine", status="fail", message=str(exc))

    async def check_keys(self) -> DoctorCheck:
        """Verify stored keys are decryptable and optionally valid."""
        try:
            from llmhosts.keys.manager import KeyManager

            mgr = KeyManager(data_dir=self._data_dir)
            providers = mgr.list_providers()
            if providers:
                names = ", ".join(p.provider for p in providers)
                # Check if any have decrypt errors
                decrypt_errors = [p for p in providers if p.masked_key == "***decrypt-error***"]
                if decrypt_errors:
                    bad = ", ".join(p.provider for p in decrypt_errors)
                    return DoctorCheck(
                        name="BYOK API keys",
                        status="warn",
                        message=f"{len(providers)} key(s): {names} ({len(decrypt_errors)} decrypt error(s): {bad})",
                        suggestion="Some keys cannot be decrypted. Re-add them with: llmhost keys add <provider> <key>",
                    )
                return DoctorCheck(
                    name="BYOK API keys",
                    status="ok",
                    message=f"{len(providers)} key(s): {names}",
                )
            return DoctorCheck(
                name="BYOK API keys",
                status="warn",
                message="No keys configured",
                suggestion="Add cloud keys with: llmhost keys add <provider> <key>",
            )
        except Exception as exc:
            return DoctorCheck(name="BYOK API keys", status="fail", message=str(exc))

    async def check_port(self) -> DoctorCheck:
        """Verify default port (11400) is available; suggest next free port if not."""
        from llmhosts.ports import DEFAULT_UP_PORT, find_available_port, is_port_free

        port = DEFAULT_UP_PORT
        if is_port_free(port):
            return DoctorCheck(
                name="Proxy port",
                status="ok",
                message=f"Port {port} — available",
            )
        # Find next free port
        next_free = find_available_port(port + 1, quiet=True)
        suggestion = (
            f"Port {port} is occupied. Use --port {next_free} to pick the next free port."
            if next_free
            else f"Port {port} is occupied. Use --port to pick another."
        )
        return DoctorCheck(
            name="Proxy port",
            status="warn",
            message=f"Port {port} — in use",
            suggestion=suggestion,
        )

    async def check_tier(self) -> DoctorCheck:
        """Detect installed pip tier (core/smart/full)."""
        tiers_found: list[str] = ["core"]

        # Smart tier markers
        smart_modules = ["onnxruntime", "faiss", "tokenizers"]
        smart_available = all(self._can_import(m) for m in smart_modules)
        if smart_available:
            tiers_found.append("smart")

        # Full tier markers
        full_modules = ["torch", "transformers", "sentence_transformers"]
        full_available = all(self._can_import(m) for m in full_modules)
        if full_available:
            tiers_found.append("full")

        tier_str = " + ".join(tiers_found)
        if full_available:
            msg = f"Installed: [{tier_str}] — all router tiers available"
        elif smart_available:
            msg = f"Installed: [{tier_str}] — kNN + ModernBERT router available"
        else:
            msg = f"Installed: [{tier_str}] — rule-based router only"

        return DoctorCheck(
            name="Installed tier",
            status="ok",
            message=msg,
            suggestion="Upgrade with: pip install llmhosts[smart] or llmhost[full]" if not smart_available else None,
        )

    async def check_disk(self) -> DoctorCheck:
        """Verify sufficient disk space (>1GB free)."""
        disk_total, disk_free = self._get_disk_space()
        disk_ok = disk_free > 1.0
        return DoctorCheck(
            name="Disk space",
            status="ok" if disk_ok else "warn",
            message=f"{disk_free:.1f} GB free / {disk_total:.1f} GB total",
            suggestion="Low disk space may prevent model downloads." if not disk_ok else None,
        )

    async def check_hardware(self) -> DoctorCheck:
        """Detect GPU, RAM, CPU."""
        try:
            from llmhosts.discovery.hardware import HardwareDetector

            hw = await HardwareDetector.detect()
            parts: list[str] = []
            if hw.gpus:
                for gpu in hw.gpus:
                    vram_gb = round(gpu.vram_total_mb / 1024, 1)
                    parts.append(f"{gpu.name} ({vram_gb}GB VRAM)")
                gpu_str = ", ".join(parts)
            else:
                gpu_str = "No GPU detected"
            msg = f"{gpu_str}, {hw.ram_total_gb:.0f}GB RAM, {hw.cpu_cores} CPU cores"
            return DoctorCheck(
                name="Hardware",
                status="ok" if hw.gpus else "warn",
                message=msg,
                suggestion="A GPU is recommended for local inference performance." if not hw.gpus else None,
            )
        except Exception as exc:
            return DoctorCheck(name="Hardware", status="fail", message=f"Detection failed: {exc}")

    async def check_database(self) -> DoctorCheck:
        """Verify SQLite database is accessible and tables exist."""
        from llmhosts.constants import DB_FILENAME

        db_path = self._data_dir / DB_FILENAME
        if not db_path.exists():
            return DoctorCheck(
                name="Database",
                status="warn",
                message=f"Database not found at {db_path}",
                suggestion="Database will be created on first server start.",
            )

        try:
            import aiosqlite

            async with aiosqlite.connect(str(db_path)) as db:
                # Check for expected tables
                cursor = await db.execute("SELECT name FROM sqlite_master WHERE type='table'")
                tables = [row[0] for row in await cursor.fetchall()]

                if not tables:
                    return DoctorCheck(
                        name="Database",
                        status="warn",
                        message=f"Database exists but has no tables ({db_path})",
                        suggestion="Tables will be created on first server start.",
                    )

                # Quick integrity check
                cursor = await db.execute("PRAGMA integrity_check")
                row = await cursor.fetchone()
                integrity = row[0] if row else "unknown"
                if integrity != "ok":
                    return DoctorCheck(
                        name="Database",
                        status="fail",
                        message=f"Database integrity check failed: {integrity}",
                        suggestion="Delete the database file and restart. Data will be re-created.",
                    )

                return DoctorCheck(
                    name="Database",
                    status="ok",
                    message=f"{len(tables)} table(s): {', '.join(sorted(tables)[:5])}",
                )
        except Exception as exc:
            return DoctorCheck(name="Database", status="fail", message=f"Database error: {exc}")

    async def check_cache(self) -> DoctorCheck:
        """Verify cache is functional (write + read test)."""
        if not self._config.cache.enabled:
            return DoctorCheck(
                name="Cache",
                status="ok",
                message="Cache is disabled in config",
            )

        try:
            import hashlib
            import time

            # Simple write/read test using a temp file in data dir
            test_dir = self._data_dir / "cache"
            test_dir.mkdir(parents=True, exist_ok=True)

            test_key = f"doctor-test-{time.time_ns()}"
            test_value = b"llmhost-cache-test-payload"
            test_hash = hashlib.sha256(test_key.encode()).hexdigest()[:16]
            test_file = test_dir / f".doctor-{test_hash}"

            # Write
            start = asyncio.get_event_loop().time()
            test_file.write_bytes(test_value)

            # Read back
            read_back = test_file.read_bytes()
            elapsed_ms = (asyncio.get_event_loop().time() - start) * 1000

            # Cleanup
            test_file.unlink(missing_ok=True)

            if read_back == test_value:
                # Check cache directory size
                cache_size_mb = sum(f.stat().st_size for f in test_dir.rglob("*") if f.is_file()) / (1024 * 1024)
                return DoctorCheck(
                    name="Cache",
                    status="ok",
                    message=f"Write/read OK ({elapsed_ms:.1f}ms), cache dir: {cache_size_mb:.1f}MB",
                )
            return DoctorCheck(
                name="Cache",
                status="fail",
                message="Cache read-back mismatch",
                suggestion="Check filesystem permissions on ~/.llmhosts/cache/",
            )
        except Exception as exc:
            return DoctorCheck(name="Cache", status="fail", message=f"Cache test failed: {exc}")

    # ------------------------------------------------------------------
    # New checks: driver staleness, disk for models, network, GPU util
    # ------------------------------------------------------------------

    async def check_disk_for_models(self) -> DoctorCheck:
        """Verify enough disk space for at least the smallest AI model (1.4GB + 20% overhead)."""
        min_required_gb = 1.4 * 1.2  # 1.68 GB minimum
        _, disk_free = self._get_disk_space()

        if disk_free >= min_required_gb * 3:
            return DoctorCheck(
                name="Disk (models)",
                status="ok",
                message=f"{disk_free:.1f} GB free -- room for multiple AI models",
            )
        elif disk_free >= min_required_gb:
            return DoctorCheck(
                name="Disk (models)",
                status="warn",
                message=f"{disk_free:.1f} GB free -- tight for larger models",
                suggestion="Free up disk space for better model selection. Models range from 1.4GB to 40GB.",
            )
        else:
            return DoctorCheck(
                name="Disk (models)",
                status="fail",
                message=f"Only {disk_free:.1f} GB free -- insufficient for any AI model (need {min_required_gb:.1f} GB)",
                suggestion="Free up at least 2 GB of disk space. "
                "The smallest model needs 1.7 GB. Larger models need 5-40 GB.",
            )

    async def check_gpu_drivers(self) -> DoctorCheck:
        """Check GPU driver version staleness with platform-specific update commands."""
        try:
            from llmhosts.discovery.hardware import HardwareDetector

            hw = await HardwareDetector.detect()
        except Exception:
            return DoctorCheck(
                name="GPU drivers",
                status="ok",
                message="Hardware detection unavailable -- skipped",
            )

        if not hw.gpus:
            return DoctorCheck(
                name="GPU drivers",
                status="ok",
                message="No GPU detected -- driver check not applicable",
            )

        system = platform.system().lower()
        issues: list[str] = []

        for gpu in hw.gpus:
            if gpu.gpu_type == "nvidia" and gpu.driver_version:
                # Parse major version
                import re

                match = re.match(r"(\d+)", gpu.driver_version.strip())
                if match:
                    major = int(match.group(1))
                    min_driver = 560
                    if major < min_driver:
                        if system == "linux":
                            issues.append(
                                f"NVIDIA driver v{gpu.driver_version} is outdated "
                                f"(need >={min_driver} for CUDA 13.1). "
                                f"Update: sudo apt install nvidia-driver-{min_driver}"
                            )
                        elif system == "windows":
                            issues.append(
                                f"NVIDIA driver v{gpu.driver_version} is outdated "
                                f"(need >={min_driver}). "
                                "Update: https://www.nvidia.com/download"
                            )
                        elif system == "darwin":
                            issues.append(
                                f"NVIDIA driver v{gpu.driver_version} is outdated. "
                                "Update to the latest driver for your platform."
                            )
            elif gpu.gpu_type == "amd":
                # Check for ROCm
                rocm_path = Path("/opt/rocm/.info/version")
                if system == "linux":
                    if not rocm_path.exists() and not shutil.which("rocm-smi"):
                        issues.append(
                            "AMD GPU detected but ROCm not found. "
                            "Install ROCm 6.4+: https://rocm.docs.amd.com/projects/install-on-linux/en/latest/"
                        )
                    elif rocm_path.exists():
                        try:
                            version_str = rocm_path.read_text().strip()
                            import re

                            match = re.match(r"(\d+)\.(\d+)", version_str)
                            if match and (int(match.group(1)), int(match.group(2))) < (6, 4):
                                issues.append(
                                    f"ROCm v{version_str} is outdated (need >=6.4). "
                                    "Update: https://rocm.docs.amd.com/projects/install-on-linux/en/latest/"
                                )
                        except (OSError, ValueError):
                            pass

        if issues:
            return DoctorCheck(
                name="GPU drivers",
                status="warn",
                message="; ".join(issues),
                suggestion=issues[0],  # Show the first fix as suggestion
            )

        # All good
        gpu_summaries = []
        for gpu in hw.gpus:
            driver_info = f" (driver {gpu.driver_version})" if gpu.driver_version else ""
            gpu_summaries.append(f"{gpu.name}{driver_info}")
        return DoctorCheck(
            name="GPU drivers",
            status="ok",
            message=f"Up to date: {', '.join(gpu_summaries)}",
        )

    async def check_gpu_utilization(self) -> DoctorCheck:
        """Show current GPU utilization (informational, not pass/fail)."""
        if not shutil.which("nvidia-smi"):
            return DoctorCheck(
                name="GPU utilization",
                status="ok",
                message="No NVIDIA GPU or nvidia-smi not available -- skipped",
            )

        try:
            import asyncio as _asyncio

            proc = await _asyncio.create_subprocess_exec(
                "nvidia-smi",
                "--query-gpu=name,utilization.gpu,memory.used,memory.total",
                "--format=csv,nounits,noheader",
                stdout=_asyncio.subprocess.PIPE,
                stderr=_asyncio.subprocess.PIPE,
            )
            stdout, _ = await _asyncio.wait_for(proc.communicate(), timeout=10.0)
            if proc.returncode != 0:
                return DoctorCheck(
                    name="GPU utilization",
                    status="ok",
                    message="Could not query GPU utilization",
                )

            parts_list = []
            for line in stdout.decode().strip().splitlines():
                parts = [p.strip() for p in line.split(",")]
                if len(parts) >= 4:
                    name, util_pct, mem_used, mem_total = parts[0], parts[1], parts[2], parts[3]
                    parts_list.append(f"{name}: {util_pct}% GPU, {mem_used}/{mem_total} MB VRAM")

            if parts_list:
                return DoctorCheck(
                    name="GPU utilization",
                    status="ok",
                    message="; ".join(parts_list),
                )
            return DoctorCheck(
                name="GPU utilization",
                status="ok",
                message="No GPU utilization data available",
            )
        except Exception as exc:
            return DoctorCheck(
                name="GPU utilization",
                status="ok",
                message=f"GPU utilization check skipped: {exc}",
            )

    async def check_install_method(self) -> DoctorCheck:
        """Detect how llmhosts was installed and warn if PATH-risky."""
        import os

        home = Path.home()

        # pipx: check PIPX_HOME env or ~/.local/pipx/venvs/llmhosts
        pipx_home = os.environ.get("PIPX_HOME")
        if pipx_home:
            pipx_venv = Path(pipx_home) / "venvs" / "llmhosts"
        else:
            pipx_venv = home / ".local" / "pipx" / "venvs" / "llmhosts"

        # uv tool: check UV_CACHE_DIR or standard uv tool paths
        uv_cache = os.environ.get("UV_CACHE_DIR")
        uv_tool_paths = [
            home / ".local" / "share" / "uv" / "tools" / "llmhosts",
        ]
        if uv_cache:
            uv_tool_paths.insert(0, Path(uv_cache).parent / "tools" / "llmhosts")

        # conda
        in_conda = bool(os.environ.get("CONDA_PREFIX"))
        # virtual env
        in_venv = bool(os.environ.get("VIRTUAL_ENV"))
        # pipx
        in_pipx = pipx_venv.exists()
        # uv tool
        in_uv_tool = any(p.exists() for p in uv_tool_paths)
        # system pip: prefix == base_prefix and not in any isolated environment
        in_system_pip = (
            sys.prefix == sys.base_prefix and not in_venv and not in_conda and not in_pipx and not in_uv_tool
        )

        if in_uv_tool:
            return DoctorCheck(
                name="Install method",
                status="ok",
                message="Installed via uv tool (isolated, PATH-safe)",
            )
        if in_pipx:
            return DoctorCheck(
                name="Install method",
                status="ok",
                message="Installed via pipx (isolated, PATH-safe)",
            )
        if in_conda:
            return DoctorCheck(
                name="Install method",
                status="ok",
                message=f"Installed in conda environment ({os.environ['CONDA_PREFIX']})",
            )
        if in_venv:
            return DoctorCheck(
                name="Install method",
                status="ok",
                message=f"Installed in virtual environment ({os.environ['VIRTUAL_ENV']})",
            )
        if in_system_pip:
            return DoctorCheck(
                name="Install method",
                status="warn",
                message="Installed into system Python — may cause PATH or permission issues",
                suggestion="For better isolation, reinstall with: pipx install llmhosts  or: uv tool install llmhosts",
            )
        # Editable / dev install or other method
        return DoctorCheck(
            name="Install method",
            status="ok",
            message="Installed (development/editable mode)",
        )

    async def check_path(self) -> DoctorCheck:
        """Verify llmhosts binary is on PATH correctly."""
        llmhosts_bin = shutil.which("llmhosts")
        if llmhosts_bin is None:
            # Provide platform-appropriate fix hint
            system = platform.system().lower()
            if system == "windows":
                fix = (
                    "Add the uv/pipx tool bin to PATH: "
                    r"%USERPROFILE%\.local\bin or %APPDATA%\uv\bin"
                )
            else:
                fix = 'Add ~/.local/bin to PATH: export PATH="$HOME/.local/bin:$PATH"'
            return DoctorCheck(
                name="PATH check",
                status="error",
                message="llmhosts binary not found on PATH",
                suggestion=fix,
            )
        return DoctorCheck(
            name="PATH check",
            status="ok",
            message=f"llmhosts found at {llmhosts_bin}",
        )

    async def check_cuda_backend(self) -> DoctorCheck:
        """Report LLMHosts Core CUDA backend status: device name, VRAM, compute capability."""
        try:
            from llmhosts.inference.core import LLMHOSTS_CORE_AVAILABLE, query_cuda_devices

            if not LLMHOSTS_CORE_AVAILABLE:
                return DoctorCheck(
                    name="CUDA backend",
                    status="ok",
                    message="LLMHosts Core not compiled in (CPU inference only)",
                )

            devices = query_cuda_devices()
            if not devices:
                return DoctorCheck(
                    name="CUDA backend",
                    status="ok",
                    message="No NVIDIA GPU detected (CPU inference active)",
                    suggestion=(
                        "For GPU acceleration, ensure CUDA 12.3+ is installed. Run: nvidia-smi to check driver status."
                    ),
                )

            summaries = []
            warnings = []
            for d in devices:
                total_gb = d["total_vram_bytes"] / (1024**3)
                free_gb = d["free_vram_bytes"] / (1024**3)
                cc_major = d["compute_capability_major"]
                cc_minor = d["compute_capability_minor"]
                driver_int = d["cuda_driver_version"]
                driver_str = f"{driver_int // 1000}.{(driver_int % 1000) // 10}"
                summaries.append(
                    f"{d['name']} — {total_gb:.1f} GB VRAM "
                    f"({free_gb:.1f} GB free), CC {cc_major}.{cc_minor}, "
                    f"CUDA driver {driver_str}"
                )
                if cc_major < 7:
                    warnings.append(
                        f"{d['name']} compute capability {cc_major}.{cc_minor} < 7.0 "
                        "(pre-Volta). GPU inference not supported — CPU fallback active."
                    )
                if driver_int < 12030:
                    warnings.append(f"CUDA driver {driver_str} < 12.3 (minimum required). Update NVIDIA drivers.")

            if warnings:
                return DoctorCheck(
                    name="CUDA backend",
                    status="warn",
                    message="; ".join(summaries),
                    suggestion=warnings[0],
                )
            return DoctorCheck(
                name="CUDA backend",
                status="ok",
                message="; ".join(summaries),
            )
        except Exception as exc:
            return DoctorCheck(
                name="CUDA backend",
                status="ok",
                message=f"CUDA backend check skipped: {exc}",
            )

    async def check_model_registry_network(self) -> DoctorCheck:
        """Check network connectivity to the model registry."""
        try:
            import httpx

            async with httpx.AsyncClient(timeout=5.0) as client:
                resp = await client.head("https://registry.ollama.ai/v2/")
                if resp.status_code in (200, 401):
                    return DoctorCheck(
                        name="Model registry",
                        status="ok",
                        message="Model registry reachable",
                    )
                return DoctorCheck(
                    name="Model registry",
                    status="warn",
                    message=f"Model registry returned HTTP {resp.status_code}",
                    suggestion="Model downloads may fail. Check your internet connection.",
                )
        except Exception:
            return DoctorCheck(
                name="Model registry",
                status="warn",
                message="Model registry unreachable (offline mode)",
                suggestion="No internet connectivity. Existing local models will still work. "
                "New model downloads require internet access.",
            )

    async def check_relay(self) -> DoctorCheck:
        """Report the active relay transport (WebSocket / HTTP/2 SSE / HTTP/1.1 chunked).

        Transport labels returned by ``_relay_core.get_active_transport()``:
          - ``"wss"``           — primary WebSocket transport (ideal)
          - ``"http2-sse"``     — HTTP/2 SSE fallback (WebSocket blocked by firewall)
          - ``"http1-chunked"`` — HTTP/1.1 chunked fallback (HTTP/2 also blocked)
          - ``""``              — relay not connected / not initialised
        """
        try:
            from llmhosts.tunnel.relay import get_relay_client  # type: ignore[import-untyped]

            client = get_relay_client()
        except (ImportError, AttributeError):
            # Relay module not present or not yet initialised — skip gracefully.
            return DoctorCheck(
                name="Relay transport",
                status="ok",
                message="Relay not initialised (start with: llmhosts tunnel start)",
            )

        if client is None:
            return DoctorCheck(
                name="Relay transport",
                status="warn",
                message="Relay not connected",
                suggestion="Start the tunnel with: llmhosts tunnel start",
            )

        try:
            # Prefer the struct-level property; fall back to the standalone pyfunction.
            transport_label: str = getattr(client, "active_transport", None) or ""
            if not transport_label:
                try:
                    from _relay_core import get_active_transport  # type: ignore[import-untyped]

                    transport_label = get_active_transport(client) or ""
                except ImportError:
                    pass

            if not transport_label:
                return DoctorCheck(
                    name="Relay transport",
                    status="warn",
                    message="Relay connected but transport unknown",
                )

            transport_labels = {
                "wss": "WebSocket",
                "http2-sse": "HTTP/2 SSE",
                "http1-chunked": "HTTP/1.1 chunked",
            }
            human = transport_labels.get(transport_label, transport_label)

            if transport_label == "wss":
                return DoctorCheck(
                    name="Relay transport",
                    status="ok",
                    message=f"connected ({human})",
                )
            # Fallback transport in use — connected but warn that WebSocket is blocked.
            return DoctorCheck(
                name="Relay transport",
                status="warn",
                message=f"connected ({human}, WebSocket blocked by firewall)",
                suggestion=(
                    "Your network blocks WebSocket connections. "
                    "The relay is using an HTTP fallback transport — performance may be slightly lower. "
                    "Contact your network administrator to allow WSS on port 443 for best results."
                ),
            )
        except Exception as exc:
            return DoctorCheck(
                name="Relay transport",
                status="fail",
                message=f"Relay transport check failed: {exc}",
            )

    # ------------------------------------------------------------------
    # New checks: binary version, CUDA runtime, relay, model storage
    # ------------------------------------------------------------------

    async def check_binary_version(self) -> DoctorCheck:
        """Compare LLMHosts Core Rust binary version to the Python package version.

        If the pyo3-exposed ``_llmhosts.LLMHOSTS_CORE_VERSION`` attribute is not
        available (CPU wheel without the Rust extension), the check is skipped.
        """
        import llmhosts as _pkg

        pkg_version = _pkg.__version__

        try:
            import _llmhosts  # type: ignore[import-not-found]

            core_version: str = getattr(_llmhosts, "LLMHOSTS_CORE_VERSION", "")
            if not core_version:
                return DoctorCheck(
                    name="Binary version",
                    status="ok",
                    message=f"LLMHosts Core version not exposed by extension (package v{pkg_version})",
                )
        except ImportError:
            return DoctorCheck(
                name="Binary version",
                status="ok",
                message=f"LLMHosts Core extension not installed (CPU wheel) — package v{pkg_version}",
            )

        # Parse major.minor from both versions
        def _major_minor(v: str) -> tuple[int, int]:
            m = re.match(r"(\d+)\.(\d+)", v.strip())
            return (int(m.group(1)), int(m.group(2))) if m else (0, 0)

        core_mm = _major_minor(core_version)
        pkg_mm = _major_minor(pkg_version)

        if core_mm != pkg_mm:
            return DoctorCheck(
                name="Binary version",
                status="warn",
                message=f"LLMHosts Core v{core_version} vs package v{pkg_version} — major/minor mismatch",
                suggestion="Reinstall: pip install --force-reinstall llmhosts",
            )

        return DoctorCheck(
            name="Binary version",
            status="ok",
            message=f"LLMHosts Core v{core_version} matches package v{pkg_version}",
        )

    async def check_cuda_runtime(self) -> DoctorCheck:
        """Parse CUDA version via ``nvcc --version`` or ``nvidia-smi``.

        - Error if CUDA < 11.0
        - Warn if CUDA < 11.8
        - OK otherwise
        """
        cuda_version: str | None = None

        # Try nvcc first
        if shutil.which("nvcc"):
            try:
                proc = await asyncio.create_subprocess_exec(
                    "nvcc",
                    "--version",
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=10.0)
                text = stdout.decode()
                m = re.search(r"release\s+(\d+\.\d+)", text)
                if m:
                    cuda_version = m.group(1)
            except Exception:
                pass

        # Fall back to nvidia-smi
        if cuda_version is None and shutil.which("nvidia-smi"):
            try:
                proc = await asyncio.create_subprocess_exec(
                    "nvidia-smi",
                    "--query-gpu=driver_version",
                    "--format=csv,noheader",
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=10.0)
                # nvidia-smi doesn't expose CUDA directly; try cuda_version query
            except Exception:
                pass

            try:
                proc = await asyncio.create_subprocess_exec(
                    "nvidia-smi",
                    "--query-gpu=cuda_version",
                    "--format=csv,noheader",
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=10.0)
                lines = stdout.decode().strip().splitlines()
                if lines:
                    # Strip leading "CUDA " prefix if present
                    raw = lines[0].strip().replace("CUDA ", "").strip()
                    m = re.match(r"(\d+\.\d+)", raw)
                    if m:
                        cuda_version = m.group(1)
            except Exception:
                pass

        if cuda_version is None:
            return DoctorCheck(
                name="CUDA runtime",
                status="ok",
                message="CUDA not detected (CPU-only mode or nvidia-smi/nvcc not on PATH)",
            )

        # Parse major.minor
        try:
            major, minor = (int(x) for x in cuda_version.split(".")[:2])
        except ValueError:
            return DoctorCheck(
                name="CUDA runtime",
                status="ok",
                message=f"CUDA detected but version could not be parsed: {cuda_version}",
            )

        if (major, minor) < (11, 0):
            return DoctorCheck(
                name="CUDA runtime",
                status="fail",
                message=f"CUDA {cuda_version} — too old (minimum 11.0 required)",
                suggestion="Upgrade CUDA toolkit: https://developer.nvidia.com/cuda-downloads",
            )

        if (major, minor) < (11, 8):
            return DoctorCheck(
                name="CUDA runtime",
                status="warn",
                message=f"CUDA {cuda_version} — functional but 11.8+ recommended for best performance",
                suggestion="Upgrade CUDA toolkit to 11.8+ for optimal LLMHosts Core support.",
            )

        return DoctorCheck(
            name="CUDA runtime",
            status="ok",
            message=f"CUDA {cuda_version} — compatible",
        )

    async def check_relay_connectivity(self) -> DoctorCheck:
        """Check TCP/TLS connectivity to the configured relay server.

        Reads relay URL from ``LLMHOSTS_RELAY_URL`` env var or the default
        ``DEFAULT_RELAY_URL`` in the tunnel module.  Validates TLS cert for
        WSS endpoints and reports Noise NK encryption state if accessible.
        """
        # Determine relay URL
        relay_url: str | None = os.environ.get("LLMHOSTS_RELAY_URL")
        if not relay_url:
            try:
                from llmhosts.tunnel.relay import DEFAULT_RELAY_URL

                relay_url = DEFAULT_RELAY_URL
            except ImportError:
                relay_url = None

        if not relay_url:
            return DoctorCheck(
                name="Relay connectivity",
                status="warn",
                message="Relay not configured — tunnel disabled",
                suggestion="Set LLMHOSTS_RELAY_URL or configure the relay in ~/.llmhosts/config.toml",
            )

        parsed = urlparse(relay_url)
        host = parsed.hostname or ""
        # WSS → port 443, WS → port 80 (override if explicit)
        port = parsed.port or (443 if parsed.scheme in ("wss", "https") else 80)
        use_tls = parsed.scheme in ("wss", "https")

        import time

        t_start = time.monotonic()
        try:
            if use_tls:
                ctx = ssl.create_default_context()
                with (
                    socket.create_connection((host, port), timeout=3.0) as raw_sock,
                    ctx.wrap_socket(raw_sock, server_hostname=host),
                ):
                    rtt_ms = (time.monotonic() - t_start) * 1000
            else:
                with socket.create_connection((host, port), timeout=3.0):
                    rtt_ms = (time.monotonic() - t_start) * 1000
        except ssl.SSLCertVerificationError as exc:
            return DoctorCheck(
                name="Relay connectivity",
                status="fail",
                message=f"Relay {host} — TLS certificate error: {exc}",
                suggestion="Check that the relay server certificate is valid and trusted.",
            )
        except (OSError, TimeoutError, ConnectionRefusedError) as exc:
            return DoctorCheck(
                name="Relay connectivity",
                status="warn",
                message=f"Relay {host} — unreachable: {exc}",
                suggestion="Check your internet connection or relay server status.",
            )

        # Check Noise NK state from relay module if available
        noise_info = "Noise NK unknown"
        try:
            from llmhosts.tunnel import relay as _relay_mod

            provider = getattr(_relay_mod, "_relay_provider", None)
            if provider is not None:
                client = getattr(provider, "_client", None)
                if client is not None:
                    is_encrypted = getattr(client, "is_noise_encrypted", False)
                    noise_info = "Noise NK active" if is_encrypted else "Noise NK inactive"
        except Exception:
            noise_info = "Noise NK state unavailable"

        return DoctorCheck(
            name="Relay connectivity",
            status="ok",
            message=f"Relay {host} — connected, {noise_info}, {rtt_ms:.0f}ms RTT",
        )

    async def check_model_storage(self) -> DoctorCheck:
        """Check free disk space on the model storage path.

        - Error if < 10 GB free
        - Warn if < 50 GB free
        - OK otherwise
        """
        models_dir = self._data_dir / "models"

        try:
            usage = shutil.disk_usage(str(models_dir if models_dir.exists() else Path.home()))
            free_gb = usage.free / (1024**3)
        except OSError:
            return DoctorCheck(
                name="Model storage",
                status="warn",
                message="Could not determine free space for model storage",
            )

        display_path = "~/.llmhosts/models/"
        if free_gb < 10.0:
            return DoctorCheck(
                name="Model storage",
                status="fail",
                message=f"Only {free_gb:.1f} GB free at {display_path} — insufficient (need ≥10 GB)",
                suggestion="Free up disk space before pulling models. Minimum recommended: 20 GB.",
            )

        if free_gb < 50.0:
            return DoctorCheck(
                name="Model storage",
                status="warn",
                message=f"{free_gb:.1f} GB free at {display_path} — tight for large models",
                suggestion="Free up space for larger models (70B+ require 40-80 GB). Currently sufficient for small/medium models.",
            )

        return DoctorCheck(
            name="Model storage",
            status="ok",
            message=f"{free_gb:.0f} GB free at {display_path}",
        )

    async def check_model_integrity(self) -> DoctorCheck:
        """List .gguf models in ~/.llmhosts/models/ and check for truncated files.

        Checks:
        - File size > 0
        - Compares to manifest ``<model>.gguf.size`` if present
        """
        models_dir = self._data_dir / "models"

        if not models_dir.exists():
            return DoctorCheck(
                name="Model integrity",
                status="ok",
                message="No model storage directory yet — models will be downloaded on first use",
            )

        gguf_files = sorted(models_dir.rglob("*.gguf"))
        if not gguf_files:
            return DoctorCheck(
                name="Model integrity",
                status="ok",
                message="No models found in ~/.llmhosts/models/",
            )

        total_bytes = 0
        corrupted: list[str] = []
        for f in gguf_files:
            try:
                size = f.stat().st_size
            except OSError:
                corrupted.append(f.name)
                continue

            if size == 0:
                corrupted.append(f"{f.name} (empty)")
                continue

            total_bytes += size

            # Check against manifest if available
            manifest = f.with_suffix(".gguf.size")
            if manifest.exists():
                try:
                    expected = int(manifest.read_text().strip())
                    if size != expected:
                        corrupted.append(f"{f.name} (size mismatch: {size} vs {expected})")
                except (ValueError, OSError):
                    pass

        total_gb = total_bytes / (1024**3)
        count = len(gguf_files)

        if corrupted:
            return DoctorCheck(
                name="Model integrity",
                status="warn",
                message=f"{count} models, {total_gb:.1f} GB total — {len(corrupted)} suspect: {', '.join(corrupted[:3])}",
                suggestion="Re-pull affected models: llmhosts pull <model>",
            )

        return DoctorCheck(
            name="Model integrity",
            status="ok",
            message=f"{count} {'model' if count == 1 else 'models'}, {total_gb:.1f} GB total, all intact",
        )

    # ------------------------------------------------------------------
    # Static helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _is_port_free(host: str, port: int) -> bool:
        """Check if a TCP port is available (connect-based, not bind-based)."""
        from llmhosts.ports import is_port_free

        return is_port_free(port)

    @staticmethod
    def _can_import(module: str) -> bool:
        """Check if a module can be imported without triggering side effects."""
        try:
            importlib.import_module(module)
            return True
        except ImportError:
            return False

    @staticmethod
    def _get_disk_space() -> tuple[float, float]:
        """Return (total_gb, free_gb) for the home directory filesystem."""
        try:
            usage = shutil.disk_usage(str(Path.home()))
            return (round(usage.total / (1024**3), 1), round(usage.free / (1024**3), 1))
        except OSError:
            return (0.0, 0.0)
