"""Wave success gate evaluation system.

Provides automated go/no-go evaluation for LLMHosts development waves.
Each wave has a set of measurable criteria that must all pass before work
on the next wave begins.
"""

from __future__ import annotations

from llmhosts.gates.wave2 import GateResult, WaveGateReport, evaluate_wave2_gates

__all__ = ["GateResult", "WaveGateReport", "evaluate_wave2_gates"]
