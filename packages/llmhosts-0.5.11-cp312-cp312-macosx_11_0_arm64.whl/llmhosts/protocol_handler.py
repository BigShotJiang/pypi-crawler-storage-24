"""OS-level URL scheme (protocol handler) registration for LLMHosts.

Registers the ``llmhosts://`` URL scheme so that deep links such as
``llmhosts://configure?tool=cursor&port=11400`` can trigger CLI actions
from a browser button or dashboard.

Platform support:
- macOS:   LaunchAgent plist at ~/Library/LaunchAgents/com.llmhosts.protocol.plist
- Linux:   .desktop file at ~/.local/share/applications/llmhosts-protocol.desktop
- Windows: Registry key at HKCU\\Software\\Classes\\llmhosts
"""

from __future__ import annotations

import contextlib
import os
import shutil
import subprocess
import sys
from pathlib import Path
from urllib.parse import parse_qs, urlparse

# ---------------------------------------------------------------------------
# Deep-link dispatcher
# ---------------------------------------------------------------------------


def handle_url(url: str) -> dict[str, object]:
    """Parse and dispatch a ``llmhosts://`` deep link.

    Args:
        url: Full URL, e.g. ``llmhosts://configure?tool=cursor&port=11400``.

    Returns:
        dict with ``success`` (bool) and ``message`` (str).
    """
    parsed = urlparse(url)
    if parsed.scheme != "llmhosts":
        return {"success": False, "message": f"Unknown scheme: {parsed.scheme}"}

    host = parsed.netloc or parsed.path.lstrip("/")
    params = {k: v[0] if v else "" for k, v in parse_qs(parsed.query).items()}

    if host == "configure":
        tool = params.get("tool", "")
        port = int(params.get("port", "11400"))
        return _dispatch_configure(tool, port)

    return {"success": False, "message": f"Unknown llmhosts:// action: {host!r}"}


def _dispatch_configure(tool: str, port: int) -> dict[str, object]:
    """Run the configure command for *tool* at *port*."""
    from llmhosts.configure import configure_cursor, configure_vscode

    if tool == "cursor":
        return configure_cursor(port=port)
    if tool == "vscode":
        return configure_vscode(port=port)
    return {"success": False, "message": f"Unknown tool: {tool!r}. Use 'cursor' or 'vscode'."}


# ---------------------------------------------------------------------------
# Registration helpers
# ---------------------------------------------------------------------------


def register_protocol() -> dict[str, object]:
    """Register the ``llmhosts://`` URL scheme for the current platform.

    Returns:
        dict with ``success`` (bool), ``message`` (str), and ``path`` (str).
    """
    if sys.platform == "darwin":
        return _register_macos()
    if sys.platform == "win32":
        return _register_windows()
    # Linux and other POSIX systems
    return _register_linux()


def unregister_protocol() -> dict[str, object]:
    """Remove the ``llmhosts://`` URL scheme registration.

    Returns:
        dict with ``success`` (bool), ``message`` (str).
    """
    if sys.platform == "darwin":
        return _unregister_macos()
    if sys.platform == "win32":
        return _unregister_windows()
    return _unregister_linux()


# ---------------------------------------------------------------------------
# macOS — LaunchAgent
# ---------------------------------------------------------------------------

_MACOS_PLIST_PATH = Path.home() / "Library" / "LaunchAgents" / "com.llmhosts.protocol.plist"

_MACOS_PLIST_TEMPLATE = """\
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
    "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.llmhosts.protocol</string>
    <key>ProgramArguments</key>
    <array>
        <string>{llmhosts_bin}</string>
        <string>handle-url</string>
        <string>$1</string>
    </array>
    <key>RunAtLoad</key>
    <false/>
</dict>
</plist>
"""

_MACOS_URI_HANDLER_PLIST = """\
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
    "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleIdentifier</key>
    <string>com.llmhosts.protocol</string>
    <key>CFBundleName</key>
    <string>LLMHosts Protocol Handler</string>
    <key>CFBundleURLTypes</key>
    <array>
        <dict>
            <key>CFBundleURLName</key>
            <string>com.llmhosts.protocol</string>
            <key>CFBundleURLSchemes</key>
            <array>
                <string>llmhosts</string>
            </array>
        </dict>
    </array>
    <key>LSUIElement</key>
    <true/>
    <key>CFBundleExecutable</key>
    <string>{llmhosts_bin}</string>
</dict>
</plist>
"""


def _register_macos() -> dict[str, object]:
    llmhosts_bin = shutil.which("llmhosts") or sys.executable
    plist_path = _MACOS_PLIST_PATH
    plist_path.parent.mkdir(parents=True, exist_ok=True)
    plist_content = _MACOS_PLIST_TEMPLATE.format(llmhosts_bin=llmhosts_bin)
    plist_path.write_text(plist_content, encoding="utf-8")
    # Inform macOS of the new URL scheme handler via lsregister if available
    _try_lsregister(str(plist_path))
    return {
        "success": True,
        "message": "llmhosts:// URL scheme registered via LaunchAgent",
        "path": str(plist_path),
    }


def _try_lsregister(path: str) -> None:
    """Best-effort call to /System/Library/Frameworks/CoreServices.framework lsregister."""
    lsregister = (
        "/System/Library/Frameworks/CoreServices.framework"
        "/Versions/A/Frameworks/LaunchServices.framework"
        "/Versions/A/Support/lsregister"
    )
    if Path(lsregister).exists():
        with contextlib.suppress(OSError):
            subprocess.run([lsregister, "-f", path], check=False, capture_output=True)


def _unregister_macos() -> dict[str, object]:
    if _MACOS_PLIST_PATH.exists():
        _MACOS_PLIST_PATH.unlink()
        return {"success": True, "message": "LaunchAgent plist removed"}
    return {"success": True, "message": "No LaunchAgent plist found — nothing to remove"}


# ---------------------------------------------------------------------------
# Linux — .desktop file
# ---------------------------------------------------------------------------

_LINUX_DESKTOP_PATH = Path.home() / ".local" / "share" / "applications" / "llmhosts-protocol.desktop"

_LINUX_DESKTOP_TEMPLATE = """\
[Desktop Entry]
Type=Application
Name=LLMHosts Protocol Handler
Exec={llmhosts_bin} handle-url %u
MimeType=x-scheme-handler/llmhosts;
NoDisplay=true
Terminal=false
"""


def _register_linux() -> dict[str, object]:
    llmhosts_bin = shutil.which("llmhosts") or sys.executable
    desktop_path = _LINUX_DESKTOP_PATH
    desktop_path.parent.mkdir(parents=True, exist_ok=True)
    desktop_path.write_text(
        _LINUX_DESKTOP_TEMPLATE.format(llmhosts_bin=llmhosts_bin),
        encoding="utf-8",
    )
    # Register with xdg-mime if available
    _try_xdg_mime(str(desktop_path))
    return {
        "success": True,
        "message": "llmhosts:// URL scheme registered via .desktop file",
        "path": str(desktop_path),
    }


def _try_xdg_mime(desktop_path: str) -> None:
    """Best-effort xdg-mime default registration."""
    xdg = shutil.which("xdg-mime")
    update_db = shutil.which("update-desktop-database")
    if xdg:
        with contextlib.suppress(OSError):
            subprocess.run(
                [xdg, "default", "llmhosts-protocol.desktop", "x-scheme-handler/llmhosts"],
                check=False,
                capture_output=True,
            )
    if update_db:
        with contextlib.suppress(OSError):
            parent = str(Path(desktop_path).parent)
            subprocess.run([update_db, parent], check=False, capture_output=True)


def _unregister_linux() -> dict[str, object]:
    if _LINUX_DESKTOP_PATH.exists():
        _LINUX_DESKTOP_PATH.unlink()
        return {"success": True, "message": ".desktop file removed"}
    return {"success": True, "message": "No .desktop file found — nothing to remove"}


# ---------------------------------------------------------------------------
# Windows — Registry
# ---------------------------------------------------------------------------

_WIN_REG_KEY = r"Software\Classes\llmhosts"


def _register_windows() -> dict[str, object]:
    """Write HKCU registry keys to register the llmhosts:// URL scheme."""
    try:
        import winreg  # type: ignore[import]
    except ImportError:
        return {"success": False, "message": "winreg not available (not running on Windows)"}

    llmhosts_bin = shutil.which("llmhosts") or sys.executable
    command = f'"{llmhosts_bin}" handle-url "%1"'

    try:
        key = winreg.CreateKeyEx(winreg.HKEY_CURRENT_USER, _WIN_REG_KEY, 0, winreg.KEY_WRITE)  # type: ignore[attr-defined]
        winreg.SetValueEx(key, "", 0, winreg.REG_SZ, "URL:llmhosts Protocol")  # type: ignore[attr-defined]
        winreg.SetValueEx(key, "URL Protocol", 0, winreg.REG_SZ, "")  # type: ignore[attr-defined]
        winreg.CloseKey(key)  # type: ignore[attr-defined]

        cmd_key = winreg.CreateKeyEx(  # type: ignore[attr-defined]
            winreg.HKEY_CURRENT_USER,  # type: ignore[attr-defined]
            _WIN_REG_KEY + r"\shell\open\command",
            0,
            winreg.KEY_WRITE,  # type: ignore[attr-defined]
        )
        winreg.SetValueEx(cmd_key, "", 0, winreg.REG_SZ, command)  # type: ignore[attr-defined]
        winreg.CloseKey(cmd_key)  # type: ignore[attr-defined]
    except OSError as exc:
        return {"success": False, "message": f"Registry write failed: {exc}"}

    return {
        "success": True,
        "message": "llmhosts:// URL scheme registered in Windows registry",
        "path": f"HKCU\\{_WIN_REG_KEY}",
    }


def _unregister_windows() -> dict[str, object]:
    try:
        import winreg  # type: ignore[import]
    except ImportError:
        return {"success": False, "message": "winreg not available (not running on Windows)"}

    try:
        _del_registry_tree(winreg.HKEY_CURRENT_USER, _WIN_REG_KEY)  # type: ignore[attr-defined]
    except FileNotFoundError:
        return {"success": True, "message": "No registry key found — nothing to remove"}
    except OSError as exc:
        return {"success": False, "message": f"Registry removal failed: {exc}"}

    return {"success": True, "message": "llmhosts:// registry key removed"}


def _del_registry_tree(hive: object, key_path: str) -> None:
    """Recursively delete a Windows registry key and all subkeys."""
    try:
        import winreg  # type: ignore[import]
    except ImportError:
        return

    try:
        key = winreg.OpenKeyEx(hive, key_path, 0, winreg.KEY_READ | winreg.KEY_WRITE)  # type: ignore[attr-defined]
    except FileNotFoundError:
        return

    # Delete subkeys first
    while True:
        try:
            subkey_name = winreg.EnumKey(key, 0)  # type: ignore[attr-defined]
            _del_registry_tree(hive, key_path + "\\" + subkey_name)  # type: ignore[operator]
        except OSError:
            break

    winreg.CloseKey(key)  # type: ignore[attr-defined]
    winreg.DeleteKey(hive, key_path)  # type: ignore[attr-defined]


# ---------------------------------------------------------------------------
# Unused import guard for Windows
# ---------------------------------------------------------------------------

if sys.platform != "win32":
    # Silence linters that flag unused imports in the Windows-only branches.
    _ = os
