"""GPU metrics collection for the live utilisation dashboard.

Collects tokens/sec, VRAM usage, queue depth, GPU temperature, and
active-request count.  Returns zero-filled metrics gracefully when no
GPU or monitoring library (pynvml) is available.
"""

from __future__ import annotations

import logging
import time
from typing import Any

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# NVML helper (optional dependency)
# ---------------------------------------------------------------------------

_nvml_initialised = False
_nvml_available = False


def _try_init_nvml() -> bool:
    """Attempt to initialise NVML once.  Returns True on success."""
    global _nvml_initialised, _nvml_available
    if _nvml_initialised:
        return _nvml_available
    _nvml_initialised = True
    try:
        import pynvml  # type: ignore[import-untyped]

        pynvml.nvmlInit()
        _nvml_available = True
        logger.debug("pynvml initialised — GPU metrics available")
    except Exception as exc:
        logger.debug("pynvml unavailable (%s) — GPU metrics will return zeros", exc)
        _nvml_available = False
    return _nvml_available


# ---------------------------------------------------------------------------
# TPS counter (module-level singleton updated by the inference engine)
# ---------------------------------------------------------------------------

_tps_counter: _TPSCounter | None = None


class _TPSCounter:
    """Sliding-window tokens-per-second counter.

    The inference dispatcher (or batch scheduler) calls :meth:`record_tokens`
    after each completed generation step.  :meth:`current_tps` returns the
    rate over the last ``window_seconds`` of activity.
    """

    def __init__(self, window_seconds: float = 10.0) -> None:
        import collections

        self._window = window_seconds
        self._events: collections.deque[tuple[float, int]] = collections.deque()

    def record_tokens(self, count: int) -> None:
        """Record that *count* tokens were generated at the current moment."""
        now = time.monotonic()
        self._events.append((now, count))
        self._trim(now)

    def current_tps(self) -> float:
        """Return tokens per second over the sliding window."""
        now = time.monotonic()
        self._trim(now)
        if not self._events:
            return 0.0
        total_tokens = sum(n for _, n in self._events)
        return round(total_tokens / self._window, 2)

    def _trim(self, now: float) -> None:
        cutoff = now - self._window
        while self._events and self._events[0][0] < cutoff:
            self._events.popleft()


def get_tps_counter() -> _TPSCounter:
    """Return the module-level TPS counter, creating it on first access."""
    global _tps_counter
    if _tps_counter is None:
        _tps_counter = _TPSCounter()
    return _tps_counter


# ---------------------------------------------------------------------------
# Active-request tracker
# ---------------------------------------------------------------------------

_active_request_count: int = 0


def increment_active_requests() -> None:
    """Increment the in-flight request counter.  Called by the dispatcher."""
    global _active_request_count
    _active_request_count += 1


def decrement_active_requests() -> None:
    """Decrement the in-flight request counter.  Called by the dispatcher."""
    global _active_request_count
    _active_request_count = max(0, _active_request_count - 1)


def get_active_requests() -> int:
    """Return the current number of in-flight requests."""
    return _active_request_count


# ---------------------------------------------------------------------------
# Server start time (for uptime)
# ---------------------------------------------------------------------------

_server_start_time: float = time.time()


def set_server_start_time(t: float) -> None:
    """Set the server start time (called during app lifespan startup)."""
    global _server_start_time
    _server_start_time = t


# ---------------------------------------------------------------------------
# Queue depth accessor
# ---------------------------------------------------------------------------


def _get_queue_depth() -> int:
    """Try to read queue depth from the batch scheduler if available."""
    try:
        from llmhosts_core import get_batch_scheduler  # type: ignore[import-not-found,attr-defined]

        scheduler = get_batch_scheduler()
        if scheduler is not None and hasattr(scheduler, "queue_depth"):
            return int(scheduler.queue_depth())
    except Exception:
        pass
    # Fallback: use active request count as a proxy
    return _active_request_count


# ---------------------------------------------------------------------------
# Main collection function
# ---------------------------------------------------------------------------


async def collect_gpu_metrics(app_state: Any = None) -> dict[str, Any]:
    """Collect current GPU metrics snapshot.

    Returns a dict with the following keys:

    ======================== ===================================================
    timestamp                Unix float, seconds since epoch
    current_tps              Tokens per second (10s sliding window)
    vram_used_gb             VRAM currently in use (GB), 0 if no GPU
    vram_total_gb            Total VRAM capacity (GB), 0 if no GPU
    queue_depth              Pending requests in scheduler queue
    gpu_temp_celsius         GPU core temperature, 0 if unavailable
    active_requests          Requests currently being processed
    uptime_seconds           Seconds since server started
    model_name               Currently-loaded model name, None if unknown
    ======================== ===================================================

    All values default to safe zeros when hardware or monitoring libraries are
    unavailable — the endpoint never errors out.
    """
    result: dict[str, Any] = {
        "timestamp": time.time(),
        "current_tps": 0.0,
        "vram_used_gb": 0.0,
        "vram_total_gb": 0.0,
        "queue_depth": 0,
        "gpu_temp_celsius": 0,
        "active_requests": 0,
        "uptime_seconds": 0,
        "model_name": None,
    }

    # --- TPS ---------------------------------------------------------------
    result["current_tps"] = get_tps_counter().current_tps()

    # --- active requests ---------------------------------------------------
    result["active_requests"] = get_active_requests()

    # --- queue depth -------------------------------------------------------
    result["queue_depth"] = _get_queue_depth()

    # --- uptime ------------------------------------------------------------
    result["uptime_seconds"] = int(time.time() - _server_start_time)

    # --- VRAM + temperature via pynvml ------------------------------------
    if _try_init_nvml():
        try:
            import pynvml  # type: ignore[import-untyped]

            device_count = pynvml.nvmlDeviceGetCount()
            if device_count > 0:
                # Aggregate across all GPUs; use GPU 0 for temperature
                total_used = 0
                total_total = 0
                for i in range(device_count):
                    handle = pynvml.nvmlDeviceGetHandleByIndex(i)
                    mem = pynvml.nvmlDeviceGetMemoryInfo(handle)
                    total_used += mem.used
                    total_total += mem.total

                result["vram_used_gb"] = round(total_used / (1024**3), 2)
                result["vram_total_gb"] = round(total_total / (1024**3), 2)

                # Temperature from GPU 0
                try:
                    handle0 = pynvml.nvmlDeviceGetHandleByIndex(0)
                    result["gpu_temp_celsius"] = int(
                        pynvml.nvmlDeviceGetTemperature(handle0, pynvml.NVML_TEMPERATURE_GPU)
                    )
                except Exception:
                    pass
        except Exception as exc:
            logger.debug("NVML query failed: %s", exc)

    # --- Fallback: sysfs / /proc for non-NVIDIA GPUs ----------------------
    if result["vram_total_gb"] == 0.0:
        result.update(_try_sysfs_vram())

    # --- model name -------------------------------------------------------
    if app_state is not None:
        result["model_name"] = _get_active_model(app_state)

    return result


def _try_sysfs_vram() -> dict[str, float]:
    """Try reading VRAM from Linux sysfs (AMD / Intel GPUs).

    Returns a partial dict with ``vram_used_gb`` and ``vram_total_gb``.
    """
    import pathlib

    try:
        # AMD GPUs expose VRAM via hwmon or drm
        drm = pathlib.Path("/sys/class/drm")
        if not drm.exists():
            return {}

        total_used = 0
        total_total = 0
        found = False

        for card in sorted(drm.iterdir()):
            # device/mem_info_vram_used  (amdgpu driver)
            used_path = card / "device" / "mem_info_vram_used"
            total_path = card / "device" / "mem_info_vram_total"
            if used_path.exists() and total_path.exists():
                try:
                    total_used += int(used_path.read_text().strip())
                    total_total += int(total_path.read_text().strip())
                    found = True
                except Exception:
                    pass

        if found and total_total > 0:
            return {
                "vram_used_gb": round(total_used / (1024**3), 2),
                "vram_total_gb": round(total_total / (1024**3), 2),
            }
    except Exception:
        pass
    return {}


def _get_active_model(app_state: Any) -> str | None:
    """Extract the currently active model name from app state."""
    try:
        dispatcher = getattr(app_state, "dispatcher", None)
        if dispatcher is not None:
            backends = getattr(dispatcher, "_backends", [])
            for b in backends:
                models = getattr(b, "models", [])
                if models:
                    return str(models[0])
    except Exception:
        pass
    return None
