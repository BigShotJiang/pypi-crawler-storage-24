"""LLMHosts status -- live health summary for the running server.

Queries ``/health`` and ``/api/status`` from the local proxy and formats
a human-readable table or JSON output.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

_DEFAULT_PORT = 4000
_TIMEOUT_S = 2.0


async def get_status(port: int = _DEFAULT_PORT) -> dict[str, Any]:
    """Query the running LLMHosts proxy and return a status dict.

    Hits ``/health`` and ``/api/status`` on the local proxy with a 2s timeout.
    Gracefully returns degraded state when the server is not running.
    """
    try:
        import httpx
    except ImportError:
        return _offline_status(port, error="httpx not installed")

    base = f"http://localhost:{port}"
    status: dict[str, Any] = {"port": port, "server_running": False}

    try:
        async with httpx.AsyncClient(timeout=_TIMEOUT_S) as client:
            # /health — basic liveness
            try:
                health_resp = await client.get(f"{base}/health")
                if health_resp.status_code == 200:
                    status["server_running"] = True
                    status["health"] = health_resp.json()
            except (httpx.ConnectError, httpx.TimeoutException):
                return _offline_status(port)

            # /api/status — rich component detail
            try:
                api_resp = await client.get(f"{base}/api/status")
                if api_resp.status_code == 200:
                    status["components"] = api_resp.json()
            except (httpx.ConnectError, httpx.TimeoutException, Exception):
                status["components"] = _default_components()
    except Exception:
        return _offline_status(port)

    # Scan local models directory
    status["local_models"] = _list_local_model_files()
    return status


def _offline_status(port: int, error: str | None = None) -> dict[str, Any]:
    """Return a status dict for when the server is not running."""
    result: dict[str, Any] = {
        "port": port,
        "server_running": False,
        "local_models": _list_local_model_files(),
    }
    if error:
        result["error"] = error
    return result


def _default_components() -> dict[str, Any]:
    """Return a zeroed-out components structure when /api/status is unavailable."""
    return {
        "engine": {"loaded": False, "model": None, "vram_gb": None, "backend": "unknown"},
        "relay": {"connected": False, "url": None, "encryption": None, "uptime_s": 0, "bytes_relayed": 0},
        "proxy": {"running": False, "port": 0, "requests_served": 0, "cache_hit_rate": 0.0},
        "recent_errors": [],
    }


def _list_local_model_files() -> list[dict[str, Any]]:
    """List GGUF files in ``~/.llmhosts/models/`` with sizes."""
    models_dir = Path.home() / ".llmhosts" / "models"
    if not models_dir.exists():
        return []

    results = []
    for entry in sorted(models_dir.iterdir()):
        if entry.suffix.lower() == ".gguf" and entry.is_file():
            try:
                size_bytes = entry.stat().st_size
                size_gb = size_bytes / (1024**3)
                results.append({"name": entry.name, "size_gb": round(size_gb, 1), "path": str(entry)})
            except OSError:
                pass
    return results


def format_status_table(status: dict[str, Any]) -> str:
    """Return a Rich-formatted status table as a string.

    Uses Rich markup so the caller can pass it directly to ``console.print()``.
    """
    lines: list[str] = []
    sep = "[dim]" + "\u2501" * 40 + "[/dim]"

    lines.append("\n[bold]LLMHosts Status[/bold]")
    lines.append(sep)

    if not status.get("server_running"):
        port = status.get("port", _DEFAULT_PORT)
        lines.append(f"[red]Server not running[/red] on :{port}")
        lines.append("[dim]Start with: llmhosts serve[/dim]")
        _append_local_models(lines, status, sep)
        return "\n".join(lines)

    comp = status.get("components", _default_components())
    engine = comp.get("engine", {})
    relay = comp.get("relay", {})
    proxy = comp.get("proxy", {})
    errors = comp.get("recent_errors", [])

    # Engine row
    if engine.get("loaded"):
        model = engine.get("model") or "unknown"
        vram = engine.get("vram_gb")
        backend = engine.get("backend", "unknown")
        vram_str = f"   {vram} GB VRAM" if vram is not None else ""
        lines.append(f"[bold cyan]Inference Engine[/bold cyan]   [green]loaded[/green]   {model}{vram_str}   {backend}")
    else:
        lines.append("[bold cyan]Inference Engine[/bold cyan]   [yellow]idle[/yellow]   no model loaded")

    # Relay row
    if relay.get("connected"):
        url = relay.get("url") or ""
        enc = relay.get("encryption") or ""
        mb_up = relay.get("bytes_relayed", 0) / (1024 * 1024)
        lines.append(
            f"[bold cyan]Relay Tunnel[/bold cyan]       [green]connected[/green]   {url}   {enc}   "
            f"[dim]\u2191{mb_up:.1f} MB[/dim]"
        )
    else:
        lines.append("[bold cyan]Relay Tunnel[/bold cyan]       [yellow]disconnected[/yellow]")

    # Proxy row
    port = proxy.get("port", status.get("port", _DEFAULT_PORT))
    req = proxy.get("requests_served", 0)
    hit_rate = proxy.get("cache_hit_rate", 0.0)
    lines.append(
        f"[bold cyan]API Proxy[/bold cyan]          [green]running[/green]   :{port}   "
        f"{req:,} req served   {hit_rate:.0%} cache hit"
    )

    lines.append(sep)
    _append_local_models(lines, status, sep)

    # Recent errors
    if errors:
        lines.append("[bold]Recent errors:[/bold]")
        for err in errors[:5]:
            lines.append(f"  [red]•[/red] {err}")
    else:
        lines.append("[dim]Recent errors: none[/dim]")

    return "\n".join(lines)


def _append_local_models(lines: list[str], status: dict[str, Any], sep: str) -> None:
    """Append the local models section to lines."""
    models = status.get("local_models", [])
    if models:
        lines.append(f"[bold]Models Available ({len(models)}):[/bold]")
        for m in models:
            lines.append(f"  [dim]\u2022[/dim] {m['name']}   {m['size_gb']} GB")
        lines.append(sep)
    else:
        lines.append("[dim]No local models found. Run: llmhosts pull --list[/dim]")
        lines.append(sep)
