"""LLMHosts model manifest -- fetch, verify, and download models with SHA-256 integrity.

Fetches the canonical manifest from llmhosts.com before downloading so that
every model pull is verified against a server-controlled SHA-256 hash.
This closes the gap where a compromised HuggingFace uploader could substitute
a malicious file that slips past the static CHECKSUMS dict in checksums.py.
"""

from __future__ import annotations

import hashlib
import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from pathlib import Path

logger = logging.getLogger(__name__)

_MANIFEST_BASE_URL = "https://llmhosts.com/api/models"
_MANIFEST_TIMEOUT_S = 10.0
_CHUNK_SIZE = 65536  # 64 KiB per streaming read


class ModelNotFoundError(Exception):
    """Raised when the model ID is not found in the LLMHosts manifest."""


class IntegrityError(Exception):
    """Raised when the downloaded file's SHA-256 does not match the manifest."""


@dataclass
class ModelManifest:
    """Canonical metadata for a downloadable model."""

    id: str
    name: str
    download_url: str
    sha256: str
    size_bytes: int
    quant_type: str
    arch: str


async def fetch_manifest(model_id: str) -> ModelManifest:
    """Fetch the manifest for *model_id* from ``https://llmhosts.com/api/models/{model_id}``.

    Raises:
        ModelNotFoundError: if the server returns 404.
        RuntimeError: for other HTTP or network errors.
        RuntimeError: if ``httpx`` is not installed.
    """
    try:
        import httpx
    except ImportError:
        raise RuntimeError(
            "httpx is required for manifest fetches. Install with: pip install llmhosts[smart]"
        ) from None

    url = f"{_MANIFEST_BASE_URL}/{model_id}"
    try:
        async with httpx.AsyncClient(timeout=_MANIFEST_TIMEOUT_S) as client:
            resp = await client.get(url)
    except (httpx.ConnectError, httpx.TimeoutException) as exc:
        raise RuntimeError(
            f"Could not reach LLMHosts manifest server: {exc}. Check your internet connection and try again."
        ) from exc

    if resp.status_code == 404:
        raise ModelNotFoundError(
            f"Model '{model_id}' not found in LLMHosts manifest. Run 'llmhosts pull --list' to see available models."
        )
    if resp.status_code != 200:
        raise RuntimeError(
            f"Manifest server returned HTTP {resp.status_code} for '{model_id}'. "
            "Try again later or check https://status.llmhosts.com."
        )

    try:
        data: dict[str, Any] = resp.json()
    except Exception as exc:
        raise RuntimeError(f"Invalid manifest response for '{model_id}': {exc}") from exc

    return ModelManifest(
        id=data["id"],
        name=data["name"],
        download_url=data["download_url"],
        sha256=data["sha256"],
        size_bytes=int(data.get("size_bytes", 0)),
        quant_type=data.get("quant_type", ""),
        arch=data.get("arch", ""),
    )


def verify_sha256(file_path: Path, expected: str) -> bool:
    """Return True if *file_path*'s SHA-256 matches *expected* (lowercase hex).

    Uses streaming reads so large (42 GB) files don't blow the heap.
    """
    sha256 = hashlib.sha256()
    with file_path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(_CHUNK_SIZE), b""):
            sha256.update(chunk)
    actual = sha256.hexdigest()
    return actual == expected.lower()


async def download_model(
    manifest: ModelManifest,
    dest_dir: Path,
    progress_callback: Any = None,
) -> Path:
    """Stream-download a model and verify its SHA-256 on completion.

    Args:
        manifest: The model manifest from :func:`fetch_manifest`.
        dest_dir: Directory to save the file in.
        progress_callback: Optional callable ``(bytes_downloaded, total_bytes)``
            called for each streamed chunk.

    Returns:
        Path to the verified local file.

    Raises:
        IntegrityError: if the SHA-256 does not match; partial file is deleted.
        RuntimeError: for download failures.
    """
    try:
        import httpx
    except ImportError:
        raise RuntimeError("httpx is required for model downloads. Install with: pip install llmhosts[smart]") from None

    dest_dir.mkdir(parents=True, exist_ok=True)
    filename = manifest.download_url.split("/")[-1] or f"{manifest.id}.gguf"
    dest = dest_dir / filename

    if dest.exists() and dest.stat().st_size == manifest.size_bytes and manifest.size_bytes > 0:
        # Already downloaded -- verify integrity without re-downloading
        logger.info("Model already present, verifying integrity: %s", dest)
        if verify_sha256(dest, manifest.sha256):
            logger.info("SHA-256 verified (cached): %s", dest)
            return dest
        else:
            logger.warning("Cached file failed SHA-256, re-downloading: %s", dest)
            dest.unlink(missing_ok=True)

    sha256 = hashlib.sha256()
    downloaded = 0

    try:
        # Large streaming download — use a long connect timeout but no total timeout
        # to support slow connections. B113 suppressed: timeout is set on connect.
        download_timeout = httpx.Timeout(connect=30.0, read=None, write=None, pool=30.0)  # nosec B113
        async with (
            httpx.AsyncClient(timeout=download_timeout) as client,
            client.stream("GET", manifest.download_url) as resp,
        ):
            resp.raise_for_status()
            total = int(resp.headers.get("content-length", manifest.size_bytes or 0))
            with dest.open("wb") as fh:
                async for chunk in resp.aiter_bytes(chunk_size=_CHUNK_SIZE):
                    fh.write(chunk)
                    sha256.update(chunk)
                    downloaded += len(chunk)
                    if progress_callback is not None:
                        progress_callback(downloaded, total)
    except Exception as exc:
        dest.unlink(missing_ok=True)
        raise RuntimeError(f"Download failed for '{manifest.name}': {exc}") from exc

    actual = sha256.hexdigest()
    if actual != manifest.sha256.lower():
        dest.unlink(missing_ok=True)
        raise IntegrityError(
            f"SHA-256 mismatch for '{manifest.name}': "
            f"expected {manifest.sha256}, got {actual}. "
            "File has been deleted. This may indicate a supply chain compromise. "
            "Report to security@llmhosts.com."
        )

    logger.info("SHA-256 verified: %s", dest)
    return dest
