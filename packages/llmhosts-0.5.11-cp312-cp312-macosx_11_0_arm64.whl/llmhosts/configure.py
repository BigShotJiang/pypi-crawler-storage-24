"""IDE auto-configuration for LLMHosts proxy.

Supports one-click configuration of:
- Cursor (cursor.sh)
- VS Code Continue.dev extension
"""

from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path
from typing import Literal

# ---------------------------------------------------------------------------
# Path resolution
# ---------------------------------------------------------------------------

ToolName = Literal["cursor", "vscode"]


def _cursor_settings_path() -> Path:
    """Return the platform-specific Cursor settings.json path."""
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / "Cursor" / "User" / "settings.json"
    if sys.platform == "win32":
        appdata = Path.home() / "AppData" / "Roaming"
        return appdata / "Cursor" / "User" / "settings.json"
    # Linux / other POSIX
    return Path.home() / ".config" / "Cursor" / "User" / "settings.json"


def _continue_config_path() -> Path:
    """Return the platform-specific Continue.dev config.json path.

    Continue uses ``~/.continue/config.json`` on all platforms.
    """
    return Path.home() / ".continue" / "config.json"


def _backup_path(target: Path) -> Path:
    """Return the backup path for a given settings file."""
    return target.with_suffix(target.suffix + ".llmhosts.bak")


# ---------------------------------------------------------------------------
# Cursor
# ---------------------------------------------------------------------------

_CURSOR_BASE_URL_KEY = "openai.baseUrl"
_CURSOR_API_KEY_KEY = "openai.apiKey"
_CURSOR_API_KEY_VALUE = "llmhosts-local"


def configure_cursor(port: int = 11400, undo: bool = False) -> dict[str, object]:
    """Configure (or unconfigure) Cursor to use the local LLMHosts proxy.

    Args:
        port: Local proxy port (default 11400).
        undo: If True, restore from backup or remove the added keys.

    Returns:
        dict with keys ``success`` (bool), ``message`` (str), ``path`` (str).
    """
    settings_path = _cursor_settings_path()
    backup = _backup_path(settings_path)

    if undo:
        return _undo_cursor(settings_path, backup)

    return _apply_cursor(settings_path, backup, port)


def _apply_cursor(settings_path: Path, backup: Path, port: int) -> dict[str, object]:
    """Write Cursor settings, creating the file and parent dirs if needed."""
    base_url = f"http://localhost:{port}/v1"

    # Load existing settings (or start fresh)
    if settings_path.exists():
        try:
            with settings_path.open(encoding="utf-8") as fh:
                existing: dict[str, object] = json.load(fh)
        except (json.JSONDecodeError, OSError):
            existing = {}
        # Back up only if not already backed up
        if not backup.exists():
            shutil.copy2(settings_path, backup)
    else:
        existing = {}
        settings_path.parent.mkdir(parents=True, exist_ok=True)

    # Check if already configured to the same values
    if existing.get(_CURSOR_BASE_URL_KEY) == base_url and existing.get(_CURSOR_API_KEY_KEY) == _CURSOR_API_KEY_VALUE:
        return {
            "success": True,
            "message": f"Cursor is already configured to use LLMHosts at {base_url}",
            "path": str(settings_path),
            "already_configured": True,
        }

    existing[_CURSOR_BASE_URL_KEY] = base_url
    existing[_CURSOR_API_KEY_KEY] = _CURSOR_API_KEY_VALUE

    with settings_path.open("w", encoding="utf-8") as fh:
        json.dump(existing, fh, indent=2)
        fh.write("\n")

    return {
        "success": True,
        "message": f"Cursor configured to use LLMHosts at {base_url}",
        "path": str(settings_path),
        "already_configured": False,
    }


def _undo_cursor(settings_path: Path, backup: Path) -> dict[str, object]:
    """Restore Cursor settings from backup, or remove the added keys."""
    if backup.exists():
        shutil.copy2(backup, settings_path)
        backup.unlink()
        return {
            "success": True,
            "message": "Cursor settings restored from backup",
            "path": str(settings_path),
        }

    if not settings_path.exists():
        return {
            "success": True,
            "message": "Nothing to undo — Cursor settings file does not exist",
            "path": str(settings_path),
        }

    try:
        with settings_path.open(encoding="utf-8") as fh:
            existing: dict[str, object] = json.load(fh)
    except (json.JSONDecodeError, OSError):
        return {
            "success": False,
            "message": "Failed to read Cursor settings file",
            "path": str(settings_path),
        }

    changed = False
    for key in (_CURSOR_BASE_URL_KEY, _CURSOR_API_KEY_KEY):
        if key in existing:
            del existing[key]
            changed = True

    if changed:
        with settings_path.open("w", encoding="utf-8") as fh:
            json.dump(existing, fh, indent=2)
            fh.write("\n")
        return {
            "success": True,
            "message": "LLMHosts keys removed from Cursor settings",
            "path": str(settings_path),
        }

    return {
        "success": True,
        "message": "No LLMHosts keys found in Cursor settings — nothing to undo",
        "path": str(settings_path),
    }


# ---------------------------------------------------------------------------
# VS Code Continue.dev
# ---------------------------------------------------------------------------

_CONTINUE_PROVIDER_TITLE = "LLMHosts (local)"


def configure_vscode(port: int = 11400, undo: bool = False) -> dict[str, object]:
    """Configure (or unconfigure) VS Code Continue.dev to use the local LLMHosts proxy.

    Args:
        port: Local proxy port (default 11400).
        undo: If True, restore from backup or remove the added provider entry.

    Returns:
        dict with keys ``success`` (bool), ``message`` (str), ``path`` (str).
    """
    config_path = _continue_config_path()
    backup = _backup_path(config_path)

    if undo:
        return _undo_vscode(config_path, backup)

    return _apply_vscode(config_path, backup, port)


def _make_continue_provider(port: int) -> dict[str, object]:
    """Build the Continue.dev OpenAI provider dict for LLMHosts."""
    return {
        "title": _CONTINUE_PROVIDER_TITLE,
        "provider": "openai",
        "model": "llmhosts-local",
        "apiBase": f"http://localhost:{port}/v1",
        "apiKey": "llmhosts-local",
    }


def _apply_vscode(config_path: Path, backup: Path, port: int) -> dict[str, object]:
    """Write Continue.dev config, creating the file and parent dirs if needed."""
    # Load or create default config
    if config_path.exists():
        try:
            with config_path.open(encoding="utf-8") as fh:
                existing: dict[str, object] = json.load(fh)
        except (json.JSONDecodeError, OSError):
            existing = {}
        if not backup.exists():
            shutil.copy2(config_path, backup)
    else:
        existing = {}
        config_path.parent.mkdir(parents=True, exist_ok=True)

    models: list[dict[str, object]] = existing.get("models", [])  # type: ignore[assignment]
    if not isinstance(models, list):
        models = []

    provider_entry = _make_continue_provider(port)
    api_base = provider_entry["apiBase"]

    # Check if already configured (matching title or apiBase)
    for entry in models:
        if not isinstance(entry, dict):
            continue
        if entry.get("title") == _CONTINUE_PROVIDER_TITLE or entry.get("apiBase") == api_base:
            # Update in place with correct port
            entry.update(provider_entry)
            existing["models"] = models
            with config_path.open("w", encoding="utf-8") as fh:
                json.dump(existing, fh, indent=2)
                fh.write("\n")
            return {
                "success": True,
                "message": f"Continue.dev provider updated to use LLMHosts at {api_base}",
                "path": str(config_path),
                "already_configured": True,
            }

    # Prepend so LLMHosts appears first in the model list
    models.insert(0, provider_entry)
    existing["models"] = models

    with config_path.open("w", encoding="utf-8") as fh:
        json.dump(existing, fh, indent=2)
        fh.write("\n")

    return {
        "success": True,
        "message": f"VS Code Continue.dev configured to use LLMHosts at {api_base}",
        "path": str(config_path),
        "already_configured": False,
    }


def _undo_vscode(config_path: Path, backup: Path) -> dict[str, object]:
    """Restore Continue.dev config from backup, or remove the LLMHosts entry."""
    if backup.exists():
        shutil.copy2(backup, config_path)
        backup.unlink()
        return {
            "success": True,
            "message": "Continue.dev config restored from backup",
            "path": str(config_path),
        }

    if not config_path.exists():
        return {
            "success": True,
            "message": "Nothing to undo — Continue.dev config file does not exist",
            "path": str(config_path),
        }

    try:
        with config_path.open(encoding="utf-8") as fh:
            existing: dict[str, object] = json.load(fh)
    except (json.JSONDecodeError, OSError):
        return {
            "success": False,
            "message": "Failed to read Continue.dev config file",
            "path": str(config_path),
        }

    models: list[dict[str, object]] = existing.get("models", [])  # type: ignore[assignment]
    if not isinstance(models, list):
        return {
            "success": True,
            "message": "No models list found in Continue.dev config — nothing to undo",
            "path": str(config_path),
        }

    original_len = len(models)
    models = [m for m in models if not (isinstance(m, dict) and m.get("title") == _CONTINUE_PROVIDER_TITLE)]

    if len(models) < original_len:
        existing["models"] = models
        with config_path.open("w", encoding="utf-8") as fh:
            json.dump(existing, fh, indent=2)
            fh.write("\n")
        return {
            "success": True,
            "message": "LLMHosts provider removed from Continue.dev config",
            "path": str(config_path),
        }

    return {
        "success": True,
        "message": "No LLMHosts provider found in Continue.dev config — nothing to undo",
        "path": str(config_path),
    }


# ---------------------------------------------------------------------------
# Undo-all helper
# ---------------------------------------------------------------------------


def undo_all(port: int = 11400) -> list[dict[str, object]]:
    """Run --undo on every supported tool and return their results."""
    return [
        configure_cursor(port=port, undo=True),
        configure_vscode(port=port, undo=True),
    ]
