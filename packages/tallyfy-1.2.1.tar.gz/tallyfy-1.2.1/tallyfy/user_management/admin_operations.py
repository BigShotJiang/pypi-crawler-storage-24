"""
Admin user management operations
"""

from typing import Dict, Any
from .base import UserManagerBase
from ..models import TallyfyError
from ..validation import validate_id, validate_positive_int


class AdminOperations(UserManagerBase):
    """Handles admin user management operations"""

    def change_user_role(self, org_id: str, user_id: int, role: str) -> bool:
        """
        Change a user's role in the organization.

        Args:
            org_id: Organization ID
            user_id: User ID
            role: New role ('light', 'standard', or 'admin')

        Returns:
            True if role changed successfully

        Raises:
            TallyfyError: If the request fails
            ValueError: If parameters are invalid
        """
        self._validate_org_id(org_id)
        validate_positive_int(user_id, "User ID")
        self._validate_role(role)

        try:
            endpoint = f"organizations/{org_id}/users/{user_id}/role"
            body: Dict[str, Any] = {"role": role}
            self.sdk._make_request('PUT', endpoint, data=body)
            return True

        except TallyfyError:
            raise
        except Exception as e:
            self._handle_api_error(e, "change user role", org_id=org_id, user_id=user_id)

    def disable_user(self, org_id: str, user_id: int) -> bool:
        """
        Disable a user in the organization.

        Args:
            org_id: Organization ID
            user_id: User ID to disable

        Returns:
            True if disabled successfully

        Raises:
            TallyfyError: If the request fails
        """
        self._validate_org_id(org_id)
        validate_positive_int(user_id, "User ID")

        try:
            endpoint = f"organizations/{org_id}/users/{user_id}/disable"
            self.sdk._make_request('DELETE', endpoint)
            return True

        except TallyfyError:
            raise
        except Exception as e:
            self._handle_api_error(e, "disable user", org_id=org_id, user_id=user_id)

    def enable_user(self, org_id: str, user_id: int) -> bool:
        """
        Re-enable a previously disabled user.

        Args:
            org_id: Organization ID
            user_id: User ID to enable

        Returns:
            True if enabled successfully

        Raises:
            TallyfyError: If the request fails
        """
        self._validate_org_id(org_id)
        validate_positive_int(user_id, "User ID")

        try:
            endpoint = f"organizations/{org_id}/users/{user_id}/enable"
            self.sdk._make_request('PUT', endpoint)
            return True

        except TallyfyError:
            raise
        except Exception as e:
            self._handle_api_error(e, "enable user", org_id=org_id, user_id=user_id)

    def approve_user(self, org_id: str, user_id: int) -> bool:
        """
        Approve a pending user in the organization.

        Args:
            org_id: Organization ID
            user_id: User ID to approve

        Returns:
            True if approved successfully

        Raises:
            TallyfyError: If the request fails
        """
        self._validate_org_id(org_id)
        validate_positive_int(user_id, "User ID")

        try:
            endpoint = f"organizations/{org_id}/users/{user_id}/approve"
            self.sdk._make_request('PUT', endpoint)
            return True

        except TallyfyError:
            raise
        except Exception as e:
            self._handle_api_error(e, "approve user", org_id=org_id, user_id=user_id)
