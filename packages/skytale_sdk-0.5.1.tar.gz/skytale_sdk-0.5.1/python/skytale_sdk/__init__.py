"""Skytale SDK: Encrypted channels for AI agents.

Usage:
    from skytale_sdk import SkytaleClient

    # Authenticated (typical usage)
    client = SkytaleClient(
        endpoint="https://relay.skytale.sh:5000",
        data_dir="/tmp/agent",
        identity=b"my-agent-id",
        api_key="sk_live_...",
        api_url="https://api.skytale.sh",
    )

    channel = client.create_channel("org/team/research")
    channel.send(b"Hello, encrypted world!")
"""

__version__ = "0.5.1"

try:
    from skytale_sdk._native import PySkytaleClient as SkytaleClient
    from skytale_sdk._native import PyChannel as Channel
    from skytale_sdk._native import PyMessageIterator as MessageIterator
except ImportError:
    raise ImportError(
        "skytale-sdk native module not found. "
        "Install with: pip install skytale-sdk"
    )

from skytale_sdk.channels import SkytaleChannelManager
from skytale_sdk.envelope import Envelope, Protocol
from skytale_sdk.errors import (
    AuthError,
    ChannelError,
    MlsError,
    QuotaExceededError,
    SkytaleError,
    TransportError,
)
from skytale_sdk.identity import AgentIdentity
from skytale_sdk.audit import AuditLog, AuditEvent, EventType
from skytale_sdk.attestation import (
    Attestation,
    create_attestation,
    verify_attestation,
    disclosed_claims,
)
from skytale_sdk.auction import SealedBidAuction, Commitment, Reveal, AuctionResult
from skytale_sdk.payment import PaymentConfig
from skytale_sdk.trust import TrustCircle, AdmissionPolicy
from skytale_sdk.context import SharedContext
from skytale_sdk.context_types import ContextType, ContextEntry, AccessScope, HLC

__all__ = [
    # Native client
    "SkytaleClient",
    "Channel",
    "MessageIterator",
    # Channel manager
    "SkytaleChannelManager",
    # Envelope
    "Envelope",
    "Protocol",
    # Errors
    "SkytaleError",
    "AuthError",
    "TransportError",
    "ChannelError",
    "QuotaExceededError",
    "MlsError",
    # Identity
    "AgentIdentity",
    # Audit
    "AuditLog",
    "AuditEvent",
    "EventType",
    # Attestation
    "Attestation",
    "create_attestation",
    "verify_attestation",
    "disclosed_claims",
    # Auction
    "SealedBidAuction",
    "Commitment",
    "Reveal",
    "AuctionResult",
    # Payment
    "PaymentConfig",
    # Trust
    "TrustCircle",
    "AdmissionPolicy",
    # Context
    "SharedContext",
    "ContextType",
    "ContextEntry",
    "AccessScope",
    "HLC",
]
