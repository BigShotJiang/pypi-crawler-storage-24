"""Skytale integrations for AI agent frameworks and protocols.

Submodules:
    langgraph: LangGraph / LangChain tool bindings
    crewai: CrewAI tool bindings
    mcp: MCP (Model Context Protocol) server (Skytale-as-tools)
    mcp_transport: MCP JSON-RPC transport over encrypted channels
    a2a: A2A (Agent-to-Agent) protocol adapter + JSON-RPC 2.0 transport
    slim: SLIM (Secure Lightweight Inter-agent Messaging) adapter
    acp: ACP adapter (DEPRECATED — use a2a instead)
    acp_private: ACP (Virtuals) private negotiation over encrypted channels
    openai_agents: OpenAI Agents SDK tool bindings
    pydantic_ai: Pydantic AI tool bindings
    smolagents: Hugging Face smolagents tool bindings
    agentkit: Coinbase AgentKit action provider
    agno: Agno toolkit bindings
    google_adk: Google ADK tool bindings
    autogen: AutoGen (Microsoft) tool bindings
    llamaindex: LlamaIndex tool bindings
    strands: Strands Agents (AWS) tool bindings
    anp: ANP (Agent Network Protocol) adapter
    lmos: LMOS (Eclipse) adapter
    nlip: NLIP (Natural Language Interaction Protocol) adapter

Legacy underscore-prefixed imports (_langgraph, _crewai, etc.) still work
for backward compatibility.

.. deprecated:: acp
    The ``acp`` module is deprecated.  Use ``a2a`` instead.  ACP imports
    continue to work but emit :class:`DeprecationWarning`.
"""

import importlib

# Map clean names to underscore-prefixed module names
_ALIASES = {
    "langgraph": "_langgraph",
    "crewai": "_crewai",
    "mcp": "_mcp",
    "mcp_transport": "_mcp_transport",
    "a2a": "_a2a",
    "slim": "_slim",
    "acp": "_acp",
    "acp_private": "_acp_private",
    "openai_agents": "_openai_agents",
    "pydantic_ai": "_pydantic_ai",
    "smolagents": "_smolagents",
    "agentkit": "_agentkit",
    "agno": "_agno",
    "google_adk": "_google_adk",
    "autogen": "_autogen",
    "llamaindex": "_llamaindex",
    "strands": "_strands",
    "anp": "_anp",
    "lmos": "_lmos",
    "nlip": "_nlip",
}


def __getattr__(name):
    # Clean name -> underscore module
    if name in _ALIASES:
        return importlib.import_module(f".{_ALIASES[name]}", __package__)
    # Underscore name still works directly
    if name in _ALIASES.values():
        return importlib.import_module(f".{name}", __package__)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
