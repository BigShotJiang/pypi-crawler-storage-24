# Changelog

## [0.5.0](https://github.com/nicholasraimbault/skytale/compare/sdk-v0.4.2...sdk-v0.5.0) (2026-03-10)


### Features

* **identity:** Agent identity with Ed25519 DID:key credentials, signatures, and DID documents
* **audit:** Hash-chained tamper-evident audit logging for all channel operations
* **attestations:** SD-JWT attestations with selective disclosure for agent trust and reputation
* **trust:** Trust circles with credential-gated MLS groups and admission policies
* **registry:** Agent registry with capability-based discovery
* **integrations:** ElizaOS, GOAT SDK, Coinbase AgentKit, AutoGen, LlamaIndex, Strands, Mastra framework support
* **payment:** Payment channels and sealed-bid auctions for agent commerce

## [0.4.2](https://github.com/nicholasraimbault/skytale/compare/sdk-v0.4.1...sdk-v0.4.2) (2026-03-08)


### Bug Fixes

* **sdk:** rename npm scope from [@skytale](https://github.com/skytale) to [@skytalesh](https://github.com/skytalesh) ([44c92a3](https://github.com/nicholasraimbault/skytale/commit/44c92a3ee7515e47c6f837947e7dc146a4a46427))

## [0.4.1](https://github.com/nicholasraimbault/skytale/compare/sdk-v0.4.0...sdk-v0.4.1) (2026-03-06)


### Bug Fixes

* **sdk:** rename npm scope from [@skytale](https://github.com/skytale) to [@skytalesh](https://github.com/skytalesh) ([ffff0fb](https://github.com/nicholasraimbault/skytale/commit/ffff0fb89bcd646e9a6db0919be70bf7c05100bd))
