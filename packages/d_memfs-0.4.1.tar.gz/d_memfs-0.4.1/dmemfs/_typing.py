from typing import TypedDict


class MFSStats(TypedDict):
    """Aggregate filesystem usage statistics returned by :meth:`MemoryFileSystem.stats`.

    Fields
    ------
    used_bytes : int
        Total quota bytes currently consumed by file data and chunk
        overhead.
    quota_bytes : int
        Configured maximum quota (``max_quota`` passed to the constructor).
    free_bytes : int
        Remaining quota (``quota_bytes - used_bytes``).
    file_count : int
        Number of file nodes in the filesystem.
    dir_count : int
        Number of directory nodes (including the root).
    chunk_count : int
        Total number of chunks held by :class:`SequentialMemoryFile`
        instances.  Files that have been promoted to
        :class:`RandomAccessMemoryFile` are not counted.
    overhead_per_chunk_estimate : int
        Per-chunk overhead value used for quota accounting.
    """

    used_bytes: int
    quota_bytes: int
    free_bytes: int
    file_count: int
    dir_count: int
    chunk_count: int
    overhead_per_chunk_estimate: int


class MFSStatResult(TypedDict):
    """Per-path metadata returned by :meth:`MemoryFileSystem.stat`.

    Fields
    ------
    size : int
        File size in bytes.  Always ``0`` for directories.
    created_at : float
        Creation timestamp in the same format as :func:`time.time`.
    modified_at : float
        Timestamp of the last data modification (``write()`` or
        ``truncate()``).  Equal to ``created_at`` for files that have
        not been written to.
    generation : int
        Monotonically increasing change counter.  ``0`` means the file
        has not been written since creation or the last
        :meth:`~MemoryFileSystem.import_tree` call.
    is_dir : bool
        ``True`` for directories, ``False`` for files.
    """

    size: int
    created_at: float
    modified_at: float
    generation: int
    is_dir: bool
