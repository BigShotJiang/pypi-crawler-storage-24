class MFSQuotaExceededError(OSError):
    """Raised when the quota limit is exceeded. Subclass of OSError."""

    def __init__(self, requested: int, available: int) -> None:
        """
        Parameters
        ----------
        requested : int
            Number of bytes that were requested.
        available : int
            Number of bytes that were available at the time of the request.
        """
        self.requested = requested
        self.available = available
        super().__init__(
            f"MFS quota exceeded: requested {requested} bytes, only {available} bytes available."
        )


class MFSNodeLimitExceededError(MFSQuotaExceededError):
    """Raised when the node count limit is exceeded. Subclass of MFSQuotaExceededError."""

    def __init__(self, current: int, limit: int) -> None:
        """
        Parameters
        ----------
        current : int
            Number of nodes present when the limit was hit.
        limit : int
            Configured ``max_nodes`` value.
        """
        self.current = current
        self.limit = limit
        super().__init__(requested=current + 1, available=limit - current)
        self.args = (f"MFS node limit exceeded: current {current} nodes, limit is {limit}.",)
