from __future__ import annotations

from dataclasses import dataclass

import pytest

import nighthawk as nh
from nighthawk.runtime.step_context import StepContext
from nighthawk.runtime.step_contract import PassStepOutcome

NATURAL_BLOCK_ORDERING_GLOBAL_NUMBER = 7


def test_docstring_step_executes_first_and_name_is_undefined() -> None:
    nh.StepExecutorConfiguration()

    @dataclass
    class NoopExecutor:
        def run_step(
            self,
            *,
            processed_natural_program: str,
            step_context: StepContext,
            binding_names: list[str],
            allowed_step_kinds: tuple[str, ...],
        ) -> tuple[PassStepOutcome, dict[str, object]]:
            _ = processed_natural_program
            _ = step_context
            _ = binding_names
            _ = allowed_step_kinds
            return PassStepOutcome(kind="pass"), {}

    with nh.run(NoopExecutor()):

        @nh.natural_function
        def f() -> int:
            """natural
            <later_value>
            <:result>
            {"step_outcome": {"kind": "pass"}, "bindings": {"result": 0}}
            """
            later_value = 123
            _ = later_value
            result = 0
            return result

        with pytest.raises(UnboundLocalError, match="later_value"):
            f()


def test_missing_input_binding_raises_even_if_program_text_does_not_use_it() -> None:
    nh.StepExecutorConfiguration()

    @dataclass
    class NoopExecutor:
        def run_step(
            self,
            *,
            processed_natural_program: str,
            step_context: StepContext,
            binding_names: list[str],
            allowed_step_kinds: tuple[str, ...],
        ) -> tuple[PassStepOutcome, dict[str, object]]:
            _ = processed_natural_program
            _ = step_context
            _ = binding_names
            _ = allowed_step_kinds
            return PassStepOutcome(kind="pass"), {}

    with nh.run(NoopExecutor()):

        @nh.natural_function
        def f() -> None:
            """natural
            <missing>
            Hello.
            """

        with pytest.raises(NameError, match="missing"):
            f()


def test_input_binding_globals_are_injected_into_step_locals_for_agent_tool_eval() -> None:
    nh.StepExecutorConfiguration()

    GLOBAL_NUMBER = NATURAL_BLOCK_ORDERING_GLOBAL_NUMBER  # noqa: N806

    class FakeRunResult:
        def __init__(self, output: object):
            self.output = output

    class FakeAgent:
        def run_sync(self, user_prompt: str, *, deps=None, **kwargs):
            from nighthawk.runtime.step_contract import PassStepOutcome, StepFinalResult
            from nighthawk.tools.assignment import assign_tool

            assert deps is not None
            _ = user_prompt
            _ = kwargs

            assign_tool(deps, "result", "NATURAL_BLOCK_ORDERING_GLOBAL_NUMBER")

            return FakeRunResult(StepFinalResult(result=PassStepOutcome(kind="pass")))

    with nh.run(nh.AgentStepExecutor.from_agent(agent=FakeAgent())):

        @nh.natural_function
        def f() -> int:
            """natural
            <NATURAL_BLOCK_ORDERING_GLOBAL_NUMBER>
            <:result>
            Set result.
            """
            return result  # noqa: F821  # pyright: ignore[reportUndefinedVariable]

        assert f() == GLOBAL_NUMBER


def test_agent_backend_commits_only_on_assignment() -> None:
    nh.StepExecutorConfiguration()

    class FakeRunResult:
        def __init__(self, output: object):
            self.output = output

    class FakeAgent:
        def run_sync(self, user_prompt: str, *, deps=None, **kwargs):
            from nighthawk.runtime.step_contract import PassStepOutcome, StepFinalResult

            assert deps is not None
            _ = user_prompt
            _ = kwargs

            return FakeRunResult(StepFinalResult(result=PassStepOutcome(kind="pass")))

    with nh.run(nh.AgentStepExecutor.from_agent(agent=FakeAgent())):
        from nighthawk.runtime.runner import Runner

        runner = Runner(nh.get_step_executor())
        import inspect

        frame = inspect.currentframe()
        assert frame is not None

        envelope = runner.run_step(
            "Hello.",
            input_binding_names=[],
            output_binding_names=["result"],
            binding_name_to_type={},
            return_annotation=int,
            is_in_loop=False,
            caller_frame=frame,
        )

    assert envelope["bindings"] == {}
