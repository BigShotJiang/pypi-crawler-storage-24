from __future__ import annotations

import re
from collections.abc import Callable, Iterator
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass
from typing import Any, overload

from pydantic_ai.tools import Tool

from ..errors import ToolRegistrationError
from ..runtime.step_context import StepContext
from .provided import build_provided_tool_definitions


@dataclass(frozen=True)
class ToolDefinition:
    name: str
    tool: Tool[StepContext]


_builtin_tool_name_to_definition: dict[str, ToolDefinition] = {}
_builtin_tools_registered = False

_global_tool_name_to_definition: dict[str, ToolDefinition] = {}

_tool_scope_stack_var: ContextVar[tuple[dict[str, ToolDefinition], ...]] = ContextVar(
    "nighthawk_tool_scope_stack",
    default=(),
)

_call_scope_stack_var: ContextVar[tuple[dict[str, ToolDefinition], ...]] = ContextVar(
    "nighthawk_call_tool_scope_stack",
    default=(),
)

_VALID_NAME_PATTERN = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def _validate_tool_name(name: str) -> None:
    try:
        name.encode("ascii")
    except UnicodeEncodeError as e:
        raise ToolRegistrationError(f"Tool name must be ASCII: {name!r}") from e

    if not _VALID_NAME_PATTERN.fullmatch(name):
        raise ToolRegistrationError(f"Tool name must match ^[A-Za-z_][A-Za-z0-9_]*$: {name!r}")


def ensure_builtin_tools_registered() -> None:
    global _builtin_tools_registered

    if _builtin_tools_registered:
        return

    for builtin_definition in build_provided_tool_definitions():
        _validate_tool_name(builtin_definition.name)
        if builtin_definition.name in _builtin_tool_name_to_definition:
            raise ToolRegistrationError(f"Duplicate builtin tool name: {builtin_definition.name!r}")
        _builtin_tool_name_to_definition[builtin_definition.name] = ToolDefinition(
            name=builtin_definition.name,
            tool=builtin_definition.tool,
        )

    _builtin_tools_registered = True


def _visible_tool_definitions() -> dict[str, ToolDefinition]:
    ensure_builtin_tools_registered()

    merged: dict[str, ToolDefinition] = dict(_builtin_tool_name_to_definition)
    merged.update(_global_tool_name_to_definition)

    for scope in _tool_scope_stack_var.get():
        merged.update(scope)

    for scope in _call_scope_stack_var.get():
        merged.update(scope)

    return merged


def _register_tool_definition(tool_definition: ToolDefinition, *, overwrite: bool) -> None:
    ensure_builtin_tools_registered()

    name = tool_definition.name
    visible = _visible_tool_definitions()

    if name in visible and not overwrite:
        raise ToolRegistrationError(f"Tool name conflict: {name!r}. Pass overwrite=True to replace the visible definition.")

    call_scope_stack = _call_scope_stack_var.get()
    if call_scope_stack:
        call_scope_stack[-1][name] = tool_definition
        return

    tool_scope_stack = _tool_scope_stack_var.get()
    if tool_scope_stack:
        tool_scope_stack[-1][name] = tool_definition
        return

    _global_tool_name_to_definition[name] = tool_definition


@contextmanager
def tool_scope() -> Iterator[None]:
    current = _tool_scope_stack_var.get()
    token = _tool_scope_stack_var.set((*current, {}))
    try:
        yield
    finally:
        _tool_scope_stack_var.reset(token)


@contextmanager
def call_scope() -> Iterator[None]:
    current = _call_scope_stack_var.get()
    token = _call_scope_stack_var.set((*current, {}))
    try:
        yield
    finally:
        _call_scope_stack_var.reset(token)


def get_visible_tools() -> list[Tool[StepContext]]:
    ensure_builtin_tools_registered()
    visible = dict(_visible_tool_definitions())
    return [definition.tool for definition in visible.values()]


type ToolFunction = Callable[..., Any]


@overload
def tool(func: ToolFunction, /) -> ToolFunction: ...


@overload
def tool(
    func: None = None,
    /,
    *,
    name: str | None = None,
    overwrite: bool = False,
    description: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> Callable[[ToolFunction], ToolFunction]: ...


def tool(
    func: ToolFunction | None = None,
    /,
    *,
    name: str | None = None,
    overwrite: bool = False,
    description: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> ToolFunction | Callable[[ToolFunction], ToolFunction]:
    """Register a Python function as a Nighthawk tool visible to Natural blocks.

    Args:
        func: The function to register. Can be omitted for use as a bare decorator.
        name: Tool name override. Defaults to the function name.
        overwrite: If True, replace any existing tool with the same name.
        description: Tool description override. Defaults to the function docstring.
        metadata: Arbitrary metadata attached to the tool definition.

    Raises:
        ToolRegistrationError: If the name conflicts with an existing tool and
            overwrite is False.

    Example:
        ```python
        @nighthawk.tool
        def lookup_user(user_id: str) -> dict:
            return {"user_id": user_id, "name": "Alice"}
        ```
    """

    def decorator(inner: ToolFunction) -> ToolFunction:
        ensure_builtin_tools_registered()

        tool_name = name or inner.__name__
        _validate_tool_name(tool_name)

        resolved_description = description
        if resolved_description is None:
            resolved_description = inner.__doc__

        tool_object: Tool[StepContext] = Tool(
            inner,
            name=tool_name,
            description=resolved_description,
            metadata=metadata,
        )

        tool_definition = ToolDefinition(name=tool_name, tool=tool_object)
        _register_tool_definition(tool_definition, overwrite=overwrite)
        return inner

    if func is not None:
        return decorator(func)

    return decorator


def _reset_all_tools_for_tests() -> None:
    global _builtin_tools_registered
    _global_tool_name_to_definition.clear()
    _builtin_tool_name_to_definition.clear()
    _builtin_tools_registered = False
