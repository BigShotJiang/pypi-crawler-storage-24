"""Shared session accessor for DAO classes."""

from sqlalchemy.ext.asyncio import AsyncSession


def get_session() -> AsyncSession:
    from viper_db.dao import get_default_client

    return get_default_client().get_session()
