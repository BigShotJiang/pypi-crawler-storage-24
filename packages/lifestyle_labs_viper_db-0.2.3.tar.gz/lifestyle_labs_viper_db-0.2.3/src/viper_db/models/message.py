from datetime import datetime
from typing import Any, TYPE_CHECKING

import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import JSONB
from sqlmodel import Field, Relationship, SQLModel

from ._base import utcnow_field
from .enums import MessageRole

if TYPE_CHECKING:
    from .conversation import Conversation


class Message(SQLModel, table=True):
    __tablename__ = "messages"
    __table_args__ = (
        sa.Index("idx_messages_conversation_id", "conversation_id"),
    )

    id: int | None = Field(default=None, primary_key=True)
    conversation_id: int = Field(
        sa_column=sa.Column(
            sa.Integer,
            sa.ForeignKey("conversations.id", ondelete="CASCADE"),
            nullable=False,
        ),
    )
    role: MessageRole = Field(
        sa_column=sa.Column(
            sa.Enum(
                MessageRole,
                name="message_role",
                create_type=True,
                values_callable=lambda e: [m.value for m in e],
            ),
            nullable=False,
        ),
    )
    content: str = Field(sa_column=sa.Column(sa.Text, nullable=False))
    blocks: list[dict[str, Any]] | None = Field(
        default=None,
        sa_column=sa.Column(JSONB, nullable=True),
    )
    created_at: datetime = utcnow_field()
    updated_at: datetime = utcnow_field()

    conversation: "Conversation" = Relationship(back_populates="messages")
