from typing import TYPE_CHECKING

import sqlalchemy as sa
from sqlmodel import Field, Relationship, SQLModel

if TYPE_CHECKING:
    from .experience import Experience


class ExperienceType(SQLModel, table=True):
    __tablename__ = "experience_types"

    id: int | None = Field(default=None, primary_key=True)
    name: str = Field(sa_column=sa.Column(sa.Text, nullable=False, unique=True))

    experiences: list["Experience"] = Relationship(back_populates="experience_type")
