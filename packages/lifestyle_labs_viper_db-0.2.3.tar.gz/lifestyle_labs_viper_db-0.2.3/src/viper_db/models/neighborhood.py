from typing import TYPE_CHECKING

import sqlalchemy as sa
from sqlmodel import Field, Relationship, SQLModel

if TYPE_CHECKING:
    from .experience import Experience


class Neighborhood(SQLModel, table=True):
    __tablename__ = "neighborhoods"
    __table_args__ = (sa.UniqueConstraint("name", "city"),)

    id: int | None = Field(default=None, primary_key=True)
    name: str = Field(sa_column=sa.Column(sa.Text, nullable=False))
    city: str = Field(sa_column=sa.Column(sa.Text, nullable=False))

    experiences: list["Experience"] = Relationship(back_populates="neighborhood")
