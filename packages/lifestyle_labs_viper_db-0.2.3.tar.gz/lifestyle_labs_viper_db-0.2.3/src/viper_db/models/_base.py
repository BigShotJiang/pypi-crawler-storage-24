"""Shared column helpers used across multiple models."""

import uuid as _uuid
from datetime import datetime, timezone
from uuid import UUID

import sqlalchemy as sa
from sqlmodel import Field


def uuid_pk_field() -> UUID:
    """UUID primary key, generated in Python before INSERT."""
    return Field(default_factory=_uuid.uuid4, primary_key=True)


def utcnow_field(nullable: bool = False, **kw) -> datetime:
    """Shorthand for a TIMESTAMPTZ column that defaults to NOW()."""
    return Field(
        default_factory=lambda: datetime.now(timezone.utc),
        sa_column=sa.Column(
            sa.DateTime(timezone=True),
            nullable=nullable,
            server_default=sa.text("NOW()"),
        ),
        **kw,
    )
