"""
SQLModel table definitions — the single source of truth for the database schema.

Import `Base` (or any table class) to get access to SQLModel.metadata,
which Alembic uses for autogenerate.
"""

from .availability_slot import AvailabilitySlot
from .booking import Booking
from .conversation import Conversation
from .enums import BookingStatus, MessageRole
from .experience import Experience
from .experience_type import ExperienceType
from .message import Message
from .neighborhood import Neighborhood
from .nightlife import Nightlife
from .restaurant import Restaurant
from .user import User
from .wellness import Wellness

__all__ = [
    "BookingStatus",
    "MessageRole",
    "ExperienceType",
    "Neighborhood",
    "User",
    "Experience",
    "Restaurant",
    "Nightlife",
    "Wellness",
    "Booking",
    "Conversation",
    "Message",
    "AvailabilitySlot",
]
