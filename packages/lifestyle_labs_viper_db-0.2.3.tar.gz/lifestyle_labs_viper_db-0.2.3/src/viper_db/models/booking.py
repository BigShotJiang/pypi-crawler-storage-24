"""
DECISION: `status` uses a Postgres-native ENUM type `booking_status`.
We pass `create_type=True` so Alembic will emit `CREATE TYPE booking_status`
in the migration.  The enum type name is set explicitly to match the original
schema.
"""

from datetime import date, datetime, time
from typing import TYPE_CHECKING
from uuid import UUID

import sqlalchemy as sa
from sqlmodel import Field, Relationship, SQLModel

from ._base import utcnow_field
from .enums import BookingStatus

if TYPE_CHECKING:
    from .conversation import Conversation
    from .experience import Experience
    from .user import User


class Booking(SQLModel, table=True):
    __tablename__ = "bookings"
    __table_args__ = (
        sa.Index("idx_bookings_user_id", "user_id"),
        sa.Index("idx_bookings_experience_id", "experience_id"),
        sa.Index("idx_bookings_status", "status"),
        sa.Index("idx_bookings_booking_date", "booking_date"),
    )

    id: int | None = Field(default=None, primary_key=True)
    user_id: UUID = Field(
        sa_column=sa.Column(
            sa.Uuid,
            sa.ForeignKey("users.id", ondelete="CASCADE"),
            nullable=False,
        ),
    )
    experience_id: int = Field(foreign_key="experiences.id", nullable=False)
    status: BookingStatus = Field(
        default=BookingStatus.PENDING,
        sa_column=sa.Column(
            sa.Enum(
                BookingStatus,
                name="booking_status",
                create_type=True,
                values_callable=lambda e: [m.value for m in e],
            ),
            nullable=False,
            server_default="pending",
        ),
    )
    party_size: int | None = Field(
        default=None, sa_column=sa.Column(sa.SmallInteger)
    )
    booking_date: date = Field(nullable=False)
    booking_time: time = Field(
        sa_column=sa.Column(sa.Time, nullable=False),
    )
    special_requests: str | None = Field(
        default=None, sa_column=sa.Column(sa.Text),
    )
    total_amount: float | None = Field(
        default=None,
        sa_column=sa.Column(sa.Numeric(10, 2)),
    )
    confirmed_at: datetime | None = Field(
        default=None,
        sa_column=sa.Column(sa.DateTime(timezone=True)),
    )
    cancelled_at: datetime | None = Field(
        default=None,
        sa_column=sa.Column(sa.DateTime(timezone=True)),
    )
    cancellation_reason: str | None = Field(
        default=None, sa_column=sa.Column(sa.Text),
    )
    created_at: datetime = utcnow_field()
    updated_at: datetime = utcnow_field()

    user: "User" = Relationship(back_populates="bookings")
    experience: "Experience" = Relationship(back_populates="bookings")
    conversations: list["Conversation"] = Relationship(back_populates="booking")
