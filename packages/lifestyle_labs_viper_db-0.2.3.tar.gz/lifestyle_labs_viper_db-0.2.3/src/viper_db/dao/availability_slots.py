"""CRUD operations for the availability_slots table."""

import datetime as dt
import json
from collections import defaultdict
from typing import Optional

from sqlalchemy import text as sa_text
from sqlmodel import select

from viper_db.models.availability_slot import AvailabilitySlot
from viper_db.utils.db import get_session

DEFAULT_UPSERT_BATCH_SIZE = 500


def _serialize_metadata(meta: dict | None) -> str:
    if not meta:
        return "{}"
    return json.dumps(meta)


def _to_date(val: str | dt.date) -> dt.date:
    if isinstance(val, dt.date):
        return val
    return dt.date.fromisoformat(val)


def _to_time(val: str | dt.time | None) -> dt.time | None:
    if val is None:
        return None
    if isinstance(val, dt.time):
        return val
    return dt.time.fromisoformat(val)


def _prepare_row(slot: dict, idx: int) -> tuple[str, dict]:
    """Build a numbered placeholder tuple and its param dict for one row."""
    s = f"_{idx}"
    placeholders = (
        f"(:experience_id{s}, :date{s}, :party_size{s}, :time{s}, "
        f":end_time{s}, :slot_type{s}, :is_available{s}, "
        f"CAST(:metadata{s} AS jsonb))"
    )
    params = {
        f"experience_id{s}": slot["experience_id"],
        f"date{s}": _to_date(slot["date"]),
        f"party_size{s}": slot["party_size"],
        f"time{s}": _to_time(slot["time"]),
        f"end_time{s}": _to_time(slot.get("end_time")),
        f"slot_type{s}": slot.get("slot_type"),
        f"is_available{s}": slot.get("is_available", True),
        f"metadata{s}": _serialize_metadata(slot.get("metadata")),
    }
    return placeholders, params


class AvailabilitySlotsDAO:
    @property
    def session(self):
        return get_session()

    async def upsert_batch(
        self,
        slots: list[dict],
        batch_size: int = DEFAULT_UPSERT_BATCH_SIZE,
    ) -> tuple[int, int, dict[tuple[int, dt.date], set[int]]]:
        """Batch-upsert slots. Returns (inserted, updated, scoped_ids).

        scoped_ids maps (experience_id, date) -> set of upserted row IDs,
        so stale deletion can be scoped per pair instead of globally.
        """
        if not slots:
            return 0, 0, {}

        inserted = 0
        updated = 0
        scoped_ids: dict[tuple[int, dt.date], set[int]] = defaultdict(set)

        for batch_start in range(0, len(slots), batch_size):
            batch = slots[batch_start : batch_start + batch_size]

            value_clauses = []
            all_params: dict = {}
            for i, slot in enumerate(batch):
                placeholders, params = _prepare_row(slot, i)
                value_clauses.append(placeholders)
                all_params.update(params)

            sql = (
                "INSERT INTO availability_slots "
                "(experience_id, date, party_size, time, "
                "end_time, slot_type, is_available, metadata) "
                "VALUES " + ", ".join(value_clauses) + " "
                "ON CONFLICT ON CONSTRAINT uq_availability_slot "
                "DO UPDATE SET "
                "is_available = EXCLUDED.is_available, "
                "end_time = EXCLUDED.end_time, "
                "metadata = EXCLUDED.metadata, "
                "updated_at = NOW() "
                "RETURNING id, experience_id, date, (xmax = 0) AS is_insert"
            )

            result = await self.session.execute(sa_text(sql), all_params)
            for row in result.fetchall():
                row_id, exp_id, row_date, is_insert = row
                scoped_ids[(exp_id, row_date)].add(row_id)
                if is_insert:
                    inserted += 1
                else:
                    updated += 1

        return inserted, updated, dict(scoped_ids)

    async def delete_stale(
        self,
        experience_id: int,
        date: dt.date,
        keep_ids: set[int],
    ) -> int:
        """Delete slots for a given (experience_id, date) not in keep_ids."""
        if keep_ids:
            result = await self.session.execute(
                sa_text(
                    "DELETE FROM availability_slots "
                    "WHERE experience_id = :exp_id "
                    "AND date = :date "
                    "AND id != ALL(:keep_ids)"
                ),
                {
                    "exp_id": experience_id,
                    "date": date,
                    "keep_ids": list(keep_ids),
                },
            )
        else:
            result = await self.session.execute(
                sa_text(
                    "DELETE FROM availability_slots "
                    "WHERE experience_id = :exp_id "
                    "AND date = :date"
                ),
                {"exp_id": experience_id, "date": date},
            )
        return result.rowcount

    async def delete_stale_for_scope(
        self,
        scoped_ids: dict[tuple[int, dt.date], set[int]],
    ) -> int:
        """Delete stale rows, scoped per (experience_id, date) pair."""
        deleted = 0
        for (exp_id, d), keep_ids in scoped_ids.items():
            deleted += await self.delete_stale(exp_id, d, keep_ids)
        return deleted

    async def get_by_experience_and_date(
        self,
        experience_id: int,
        date: dt.date,
    ) -> list[AvailabilitySlot]:
        result = await self.session.execute(
            select(AvailabilitySlot).where(
                AvailabilitySlot.experience_id == experience_id,
                AvailabilitySlot.date == date,
                AvailabilitySlot.is_available == True,  # noqa: E712
            )
        )
        return list(result.scalars().all())

    async def get_available_for_experience(
        self,
        experience_id: int,
        party_size: Optional[int] = None,
        from_date: Optional[dt.date] = None,
        to_date: Optional[dt.date] = None,
    ) -> list[AvailabilitySlot]:
        """Return available slots for an experience with optional filters."""
        stmt = select(AvailabilitySlot).where(
            AvailabilitySlot.experience_id == experience_id,
            AvailabilitySlot.is_available == True,  # noqa: E712
        )
        if party_size is not None:
            stmt = stmt.where(AvailabilitySlot.party_size == party_size)
        if from_date is not None:
            stmt = stmt.where(AvailabilitySlot.date >= from_date)
        if to_date is not None:
            stmt = stmt.where(AvailabilitySlot.date <= to_date)

        stmt = stmt.order_by(AvailabilitySlot.date, AvailabilitySlot.time)
        result = await self.session.execute(stmt)
        return list(result.scalars().all())

    async def count_by_experience(self, experience_id: int) -> int:
        result = await self.session.execute(
            sa_text(
                "SELECT COUNT(*) FROM availability_slots "
                "WHERE experience_id = :exp_id AND is_available = true"
            ),
            {"exp_id": experience_id},
        )
        return result.scalar() or 0

    async def get_experiences_available_on_date(
        self,
        date: dt.date,
        party_size: Optional[int] = None,
        time_from: Optional[dt.time] = None,
        limit: int = 10,
        offset: int = 0,
    ) -> list[dict]:
        """Return experiences with available slots on a given date.

        Each dict contains experience fields, cuisine, neighborhood,
        the count of available slots, and the earliest available time.
        """
        party_filter = ""
        if party_size is not None:
            party_filter = "AND a.party_size = :party_size "

        time_filter = ""
        if time_from is not None:
            time_filter = "AND a.time >= :time_from "

        sql = (
            "SELECT e.id AS experience_id, e.name, e.image_urls, "
            "  e.vibes, e.price_tier, "
            "  n.name AS neighborhood, "
            "  r.cuisine, "
            "  COUNT(a.id) AS slot_count, "
            "  MIN(a.time) AS next_available_time "
            "FROM availability_slots a "
            "JOIN experiences e ON e.id = a.experience_id "
            "LEFT JOIN neighborhoods n ON n.id = e.neighborhood_id "
            "LEFT JOIN restaurants r ON r.experience_id = e.id "
            "WHERE a.date = :date "
            "  AND a.is_available = true "
            "  AND e.is_active = true "
            f"{party_filter}"
            f"{time_filter}"
            "GROUP BY e.id, e.name, e.image_urls, e.vibes, e.price_tier, "
            "  n.name, r.cuisine "
            "ORDER BY slot_count DESC "
            "LIMIT :limit OFFSET :offset"
        )

        params: dict = {"date": date, "limit": limit, "offset": offset}
        if party_size is not None:
            params["party_size"] = party_size
        if time_from is not None:
            params["time_from"] = time_from

        result = await self.session.execute(sa_text(sql), params)
        rows = result.fetchall()

        return [
            {
                "experience_id": row.experience_id,
                "name": row.name,
                "image_urls": row.image_urls or [],
                "vibes": row.vibes or [],
                "price_tier": row.price_tier,
                "neighborhood": row.neighborhood,
                "cuisine": row.cuisine or [],
                "slot_count": row.slot_count,
                "next_available_time": row.next_available_time,
            }
            for row in rows
        ]


availability_slots_dao = AvailabilitySlotsDAO()
