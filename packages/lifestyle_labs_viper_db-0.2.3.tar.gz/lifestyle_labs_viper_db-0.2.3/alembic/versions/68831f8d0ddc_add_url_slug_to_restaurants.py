"""add_url_slug_to_restaurants

Revision ID: 68831f8d0ddc
Revises: 0007
Create Date: 2026-03-17 23:49:08.495107
"""

from typing import Sequence, Union

import sqlalchemy as sa
import sqlmodel  # noqa: F401 — needed so sa.Enum can resolve SQLModel types

from alembic import op

# revision identifiers, used by Alembic.
revision: str = "68831f8d0ddc"
down_revision: Union[str, None] = "0007"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column("restaurants", sa.Column("url_slug", sa.Text(), nullable=True))


def downgrade() -> None:
    op.drop_column("restaurants", "url_slug")
