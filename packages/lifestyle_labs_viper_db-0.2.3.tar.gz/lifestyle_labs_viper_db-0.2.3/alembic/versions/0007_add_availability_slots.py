"""add_availability_slots

Revision ID: 0007
Revises: 0006
Create Date: 2026-03-17

Creates the availability_slots table for storing scraped Resy
table availability data.
"""

from typing import Sequence, Union

import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import JSONB

from alembic import op

revision: str = "0007"
down_revision: Union[str, None] = "0006"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "availability_slots",
        sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
        sa.Column(
            "experience_id",
            sa.Integer,
            sa.ForeignKey("experiences.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("date", sa.Date, nullable=False),
        sa.Column("party_size", sa.SmallInteger, nullable=False),
        sa.Column("time", sa.Time, nullable=False),
        sa.Column("end_time", sa.Time),
        sa.Column("slot_type", sa.Text),
        sa.Column(
            "is_available",
            sa.Boolean,
            nullable=False,
            server_default=sa.text("true"),
        ),
        sa.Column(
            "metadata",
            JSONB,
            server_default=sa.text("'{}'::jsonb"),
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("NOW()"),
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("NOW()"),
        ),
        sa.UniqueConstraint(
            "experience_id",
            "date",
            "party_size",
            "time",
            "slot_type",
            name="uq_availability_slot",
        ),
    )

    op.create_index(
        "idx_availability_experience_date",
        "availability_slots",
        ["experience_id", "date"],
    )

    # MANUAL: Partial index — Alembic autogenerate cannot emit WHERE clauses.
    op.execute(
        "CREATE INDEX idx_availability_date_available "
        "ON availability_slots (date, is_available) "
        "WHERE is_available = true"
    )

    # MANUAL: GIN index on metadata JSONB column.
    op.execute(
        "CREATE INDEX idx_availability_metadata "
        "ON availability_slots USING GIN (metadata)"
    )

    # Reuse the existing set_updated_at() trigger function.
    op.execute(
        "CREATE TRIGGER availability_slots_updated_at "
        "BEFORE UPDATE ON availability_slots "
        "FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();"
    )


def downgrade() -> None:
    op.drop_table("availability_slots")
