"""initial_schema

Revision ID: 0001
Revises:
Create Date: 2026-02-19

This migration replicates the original Supabase SQL migration
(20260219050948_initial_schema.sql) so that Alembic's revision history
starts from a known baseline.

IMPORTANT — Items that Alembic autogenerate cannot handle are called out
with "MANUAL:" comments below.  These were added by hand.
"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import JSONB

revision: str = "0001"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # ── MANUAL: Custom Postgres ENUM types ──────────────────────────────
    # Alembic can create these via sa.Enum columns, but we create them
    # explicitly so the names match the original schema exactly.
    op.execute(
        "CREATE TYPE booking_status AS ENUM "
        "('pending', 'awaiting_confirmation', 'confirmed', 'cancelled')"
    )
    op.execute(
        "CREATE TYPE message_role AS ENUM "
        "('user', 'ai_agent', 'human_agent')"
    )

    # ── Lookup tables ───────────────────────────────────────────────────
    op.create_table(
        "experience_types",
        sa.Column("id", sa.Integer, primary_key=True, autoincrement=True),
        sa.Column("name", sa.Text, nullable=False, unique=True),
    )

    op.create_table(
        "neighborhoods",
        sa.Column("id", sa.Integer, primary_key=True, autoincrement=True),
        sa.Column("name", sa.Text, nullable=False),
        sa.Column("city", sa.Text, nullable=False),
        sa.UniqueConstraint("name", "city"),
    )

    # MANUAL: Seed data — Alembic does not autogenerate INSERT statements.
    op.execute(
        "INSERT INTO experience_types (name) "
        "VALUES ('restaurant'), ('nightlife'), ('wellness')"
    )

    # ── Users ───────────────────────────────────────────────────────────
    op.create_table(
        "users",
        sa.Column("id", sa.Uuid, primary_key=True),
        sa.Column("email", sa.Text, nullable=False, unique=True),
        sa.Column("phone", sa.Text),
        sa.Column(
            "first_name", sa.Text, nullable=False, server_default=sa.text("''")
        ),
        sa.Column(
            "last_name", sa.Text, nullable=False, server_default=sa.text("''")
        ),
        sa.Column("preferences", JSONB, server_default=sa.text("'{}'::jsonb")),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("NOW()"),
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("NOW()"),
        ),
    )

    # MANUAL: FK to auth.users and the handle_new_user trigger live in the
    # Supabase auth schema and are NOT managed by Alembic.  If you need
    # them, add:
    #   op.execute(
    #       "ALTER TABLE public.users "
    #       "ADD CONSTRAINT users_id_fkey "
    #       "FOREIGN KEY (id) REFERENCES auth.users(id) ON DELETE CASCADE"
    #   )
    # and the trigger/function from the original migration.

    # ── Experiences ─────────────────────────────────────────────────────
    op.create_table(
        "experiences",
        sa.Column("id", sa.Integer, primary_key=True, autoincrement=True),
        sa.Column(
            "experience_type_id",
            sa.Integer,
            sa.ForeignKey("experience_types.id"),
            nullable=False,
        ),
        sa.Column("name", sa.Text, nullable=False),
        sa.Column("description", sa.Text, nullable=False),
        sa.Column("address", sa.Text, nullable=False),
        sa.Column("latitude", sa.Numeric(9, 6)),
        sa.Column("longitude", sa.Numeric(9, 6)),
        sa.Column(
            "neighborhood_id",
            sa.Integer,
            sa.ForeignKey("neighborhoods.id"),
        ),
        sa.Column("price_tier", sa.SmallInteger),
        sa.Column("price", sa.Numeric(10, 2)),
        sa.Column("vibe", sa.ARRAY(sa.Text), server_default="{}"),
        sa.Column("phone", sa.Text),
        sa.Column("website", sa.Text),
        sa.Column("image_urls", sa.ARRAY(sa.Text), server_default="{}"),
        sa.Column("is_active", sa.Boolean, nullable=False, server_default=sa.text("true")),
        sa.Column("booking_rules", sa.Text),
        sa.Column("cancellation_policy", sa.Text),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("NOW()"),
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("NOW()"),
        ),
        sa.CheckConstraint(
            "price_tier BETWEEN 1 AND 4", name="ck_experiences_price_tier"
        ),
    )

    op.create_index("idx_experiences_type", "experiences", ["experience_type_id"])
    op.create_index("idx_experiences_neighborhood", "experiences", ["neighborhood_id"])
    op.create_index("idx_experiences_price_tier", "experiences", ["price_tier"])
    op.create_index("idx_experiences_is_active", "experiences", ["is_active"])

    # MANUAL: GIN index — Alembic autogenerate does not emit USING GIN.
    op.execute(
        "CREATE INDEX idx_experiences_vibe ON experiences USING GIN(vibe)"
    )

    # ── Category detail tables ──────────────────────────────────────────
    op.create_table(
        "restaurants",
        sa.Column(
            "experience_id",
            sa.Integer,
            sa.ForeignKey("experiences.id", ondelete="CASCADE"),
            primary_key=True,
        ),
        sa.Column("cuisine", sa.ARRAY(sa.Text), server_default="{}"),
        sa.Column("categories", sa.ARRAY(sa.Text), server_default="{}"),
        sa.Column("resy_name", sa.Text),
        sa.Column("resy_url", sa.Text),
        sa.Column("resy_venue_id", sa.Integer),
    )

    op.create_table(
        "nightlife",
        sa.Column(
            "experience_id",
            sa.Integer,
            sa.ForeignKey("experiences.id", ondelete="CASCADE"),
            primary_key=True,
        ),
        sa.Column("venue_type", sa.Text, nullable=False),
        sa.Column(
            "has_dancefloor",
            sa.Boolean,
            server_default=sa.text("false"),
        ),
        sa.Column("dress_code", sa.Text),
        sa.Column("age_minimum", sa.SmallInteger, server_default=sa.text("21")),
        sa.Column("cover_charge", sa.Numeric(8, 2)),
    )

    op.create_table(
        "wellness",
        sa.Column(
            "experience_id",
            sa.Integer,
            sa.ForeignKey("experiences.id", ondelete="CASCADE"),
            primary_key=True,
        ),
        sa.Column("wellness_type", sa.Text, nullable=False),
        sa.Column(
            "booking_required",
            sa.Boolean,
            server_default=sa.text("true"),
        ),
        sa.Column("amenities", sa.ARRAY(sa.Text), server_default="{}"),
    )

    # ── Bookings ────────────────────────────────────────────────────────
    op.create_table(
        "bookings",
        sa.Column("id", sa.Integer, primary_key=True, autoincrement=True),
        sa.Column(
            "user_id",
            sa.Uuid,
            sa.ForeignKey("users.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "experience_id",
            sa.Integer,
            sa.ForeignKey("experiences.id"),
            nullable=False,
        ),
        sa.Column(
            "status",
            sa.Enum(
                "pending",
                "awaiting_confirmation",
                "confirmed",
                "cancelled",
                name="booking_status",
                create_type=False,
            ),
            nullable=False,
            server_default="pending",
        ),
        sa.Column("party_size", sa.SmallInteger),
        sa.Column("booking_date", sa.Date, nullable=False),
        sa.Column("booking_time", sa.Time, nullable=False),
        sa.Column("special_requests", sa.Text),
        sa.Column("total_amount", sa.Numeric(10, 2)),
        sa.Column("confirmed_at", sa.DateTime(timezone=True)),
        sa.Column("cancelled_at", sa.DateTime(timezone=True)),
        sa.Column("cancellation_reason", sa.Text),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("NOW()"),
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("NOW()"),
        ),
    )

    op.create_index("idx_bookings_user_id", "bookings", ["user_id"])
    op.create_index("idx_bookings_experience_id", "bookings", ["experience_id"])
    op.create_index("idx_bookings_status", "bookings", ["status"])
    op.create_index("idx_bookings_booking_date", "bookings", ["booking_date"])

    # ── Conversations & Messages ────────────────────────────────────────
    op.create_table(
        "conversations",
        sa.Column("id", sa.Integer, primary_key=True, autoincrement=True),
        sa.Column("thread_id", sa.Text),
        sa.Column(
            "user_id",
            sa.Uuid,
            sa.ForeignKey("users.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "booking_id",
            sa.Integer,
            sa.ForeignKey("bookings.id", ondelete="SET NULL"),
        ),
        sa.Column(
            "experience_id",
            sa.Integer,
            sa.ForeignKey("experiences.id", ondelete="SET NULL"),
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("NOW()"),
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("NOW()"),
        ),
    )

    op.create_index("idx_conversations_user_id", "conversations", ["user_id"])
    op.create_index(
        "idx_conversations_booking_id", "conversations", ["booking_id"]
    )

    op.create_table(
        "messages",
        sa.Column("id", sa.Integer, primary_key=True, autoincrement=True),
        sa.Column(
            "conversation_id",
            sa.Integer,
            sa.ForeignKey("conversations.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "role",
            sa.Enum(
                "user",
                "ai_agent",
                "human_agent",
                name="message_role",
                create_type=False,
            ),
            nullable=False,
        ),
        sa.Column("content", sa.Text, nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("NOW()"),
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("NOW()"),
        ),
    )

    op.create_index(
        "idx_messages_conversation_id", "messages", ["conversation_id"]
    )

    # MANUAL: updated_at triggers — Alembic does not manage triggers.
    # These replicate the original set_updated_at() function and per-table
    # triggers.  You may prefer to handle this in application code instead.
    op.execute("""
        CREATE OR REPLACE FUNCTION public.set_updated_at()
        RETURNS TRIGGER AS $$
        BEGIN
            NEW.updated_at = NOW();
            RETURN NEW;
        END;
        $$ LANGUAGE plpgsql;
    """)

    for table in (
        "users",
        "experiences",
        "bookings",
        "conversations",
        "messages",
    ):
        op.execute(
            f"CREATE TRIGGER {table}_updated_at "
            f"BEFORE UPDATE ON {table} "
            f"FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();"
        )


def downgrade() -> None:
    for table in (
        "messages",
        "conversations",
        "bookings",
        "wellness",
        "nightlife",
        "restaurants",
        "experiences",
        "users",
        "neighborhoods",
        "experience_types",
    ):
        op.drop_table(table)

    op.execute("DROP FUNCTION IF EXISTS public.set_updated_at() CASCADE")
    op.execute("DROP TYPE IF EXISTS booking_status")
    op.execute("DROP TYPE IF EXISTS message_role")
