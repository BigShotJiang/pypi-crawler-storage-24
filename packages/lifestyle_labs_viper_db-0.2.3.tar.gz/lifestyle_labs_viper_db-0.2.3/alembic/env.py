"""
Alembic environment configuration.

Reads the database URL from dynaconf settings (SUPABASE.db_url) and imports
all SQLModel table classes so that `target_metadata` is fully populated for
autogenerate.
"""

from logging.config import fileConfig

from sqlalchemy import engine_from_config, pool
from sqlmodel import SQLModel

import viper_db.models  # noqa: F401 — registers tables on metadata
from alembic import context

config = context.config

if config.config_file_name is not None:
    fileConfig(config.config_file_name)

target_metadata = SQLModel.metadata

from viper_db.config import settings  # noqa: E402

_supabase_cfg = settings.get("SUPABASE", {})
_db_url: str = _supabase_cfg.get("db_url", "")
if not _db_url:
    raise RuntimeError("SUPABASE.db_url must be set in settings for Alembic to run")

config.set_main_option("sqlalchemy.url", _db_url)


def _include_object(object, name, type_, reflected, compare_to):
    """Filter out objects that Alembic should not manage."""
    if type_ == "foreign_key_constraint":
        if name == "users_id_fkey":
            return False
        referent_table = getattr(object, "referred_table", None)
        if referent_table is not None:
            if referent_table.schema == "auth":
                return False
    return True


def run_migrations_offline() -> None:
    """Run migrations in 'offline' mode — emit SQL to stdout."""
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        include_object=_include_object,
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    """Run migrations against a live database connection."""
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    with connectable.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            include_object=_include_object,
        )
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
