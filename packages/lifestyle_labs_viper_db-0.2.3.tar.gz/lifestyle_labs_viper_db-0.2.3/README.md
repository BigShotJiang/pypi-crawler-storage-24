# viper-db

This is the database layer for Viper. It is a thin wrapper around the Supabase client.