"""Authentication utilities for Point Topic MCP.

Auth0 OAuth integration with role-based access control:
- @public decorator - Tools available to everyone
- @requires_permissions decorator - Tools requiring specific permissions
- ptAdmin role - Full access to all tools
- JWT token claims contain user permissions

Usage:
    from point_topic_mcp.auth import public, requires_permissions

    @public
    @mcp.tool()
    async def health_check():
        return {"status": "ok"}  # Available to everyone

    @requires_permissions(["read:data"])
    @mcp.tool()
    async def query_database():
        return {"data": "result"}  # Requires permission
"""

# Permission decorators
from point_topic_mcp.auth.decorators import (
    public,
    is_public_tool,
    PUBLIC_TOOLS,
    requires_permissions,
    get_tool_permissions,
    has_tool_permissions,
    TOOL_PERMISSIONS,
)

# Permission middleware
from point_topic_mcp.auth.middleware import (
    PermissionMiddleware,
    get_user_permissions,
    is_pt_admin,
    check_tool_access,
)

# Auth0 helpers
from point_topic_mcp.auth.auth0_helpers import (
    get_user_roles,
    require_admin_role,
    has_role,
    has_any_role,
    require_role,
    get_user_info,
)

__all__ = [
    # Decorators
    "public",
    "is_public_tool",
    "PUBLIC_TOOLS",
    "requires_permissions",
    "get_tool_permissions",
    "has_tool_permissions",
    "TOOL_PERMISSIONS",
    # Middleware
    "PermissionMiddleware",
    "get_user_permissions",
    "is_pt_admin",
    "check_tool_access",
    # Auth0 helpers
    "get_user_roles",
    "require_admin_role",
    "has_role",
    "has_any_role",
    "require_role",
    "get_user_info",
]
