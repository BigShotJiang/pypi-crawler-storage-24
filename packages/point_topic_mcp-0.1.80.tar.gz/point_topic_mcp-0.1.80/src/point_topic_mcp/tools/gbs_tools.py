"""GBS (Global Broadband Statistics) tools for PT Research App.

MongoDB utils for Statistics and Sources. Used by PT Systems Agent for
human-supervised GBS data entry (see upc_query_agent issue #37).

Uses mongosh (shell) instead of PyMongo - avoids Python SSL issues in
cloud/EC2 environments. Requires mongosh installed on the host.

Ref: pt-research-app schema (Statistics, Sources)
"""

from typing import Optional

from point_topic_mcp.core.utils import check_env_vars
from point_topic_mcp.core import mongodb_utils as mongo
from dotenv import load_dotenv

load_dotenv()

# GBS tools require PT Research App MongoDB connection
if check_env_vars("gbs_tools", ["PT_RESEARCH_DATABASE_URI"]):

    # Valid enums from pt-research-app
    VALID_TYPES = ["broadband", "mobile", "iptv"]
    VALID_CHANNELS = ["Infrastructure", "Retail"]
    VALID_DOMAINS = ["Residential", "Business", "Total"]

    def _valid_object_id(oid: str) -> bool:
        """Check if string is valid 24-char hex ObjectId."""
        if not oid or len(oid) != 24:
            return False
        return all(c in "0123456789abcdefABCDEF" for c in oid)

    def list_operators(country: str = "", ctx=None) -> str:
        """
        List operators in the GBS database. Use before get_gbs_status to discover
        valid operator names and IDs.

        Args:
            country: Optional filter by country (exact match, e.g. "United Kingdom"). Leave empty for all.

        Returns:
            List of operators with name, country, operator_id (use in add_statistic/create_source).
        """
        ops = mongo.find_operators(country)
        rows = []
        for op in ops:
            oid = mongo._oid_from_doc(op)
            name = op.get("name", "?")
            c = op.get("country", "?")
            techs = op.get("technologies", [])
            rows.append(f"  {name} | {c} | id={oid} | techs={techs}")
        if not rows:
            return f"No operators found" + (f" for country '{country}'" if country else "")
        return "Operators:\n" + "\n".join(rows)

    def get_gbs_status(
        country: str,
        operator: str,
        period: str,
        ctx=None,
    ) -> str:
        """
        Get GBS status for a country/operator/period: what exists, gaps, staleness.

        Args:
            country: Country name (exact match, e.g. "United Kingdom" not "UK")
            operator: Operator name (exact match, case-sensitive)
            period: Quarter string (e.g. "2025Q1", "2024Q4")

        Returns:
            Summary of existing statistics, missing combinations (gaps), and
            staleness vs current stats period.
        """
        op = mongo.find_one_operator(operator, country)
        if not op:
            return f"Operator not found: '{operator}' in '{country}'. Check name and country match exactly."

        operator_id = mongo._oid_from_doc(op)
        technologies = op.get("technologies", [])

        gv = mongo.find_global_variables_current()
        current_period = gv.get("currentStatsPeriod", "unknown") if gv else "unknown"

        existing = mongo.find_statistics(operator_id, period)

        existing_combos = {
            (s["type"], s["tech"], s["channel"], s["domain"]) for s in existing
        }

        gaps = []
        for t in VALID_TYPES:
            for tech in technologies:
                for ch in VALID_CHANNELS:
                    for dom in VALID_DOMAINS:
                        combo = (t, tech, ch, dom)
                        if combo not in existing_combos:
                            gaps.append(f"  {t} / {tech} / {ch} / {dom}")

        state_names = {1: "pending", 2: "approved", 3: "published"}
        by_state = {}
        for s in existing:
            st = s.get("state", 1)
            by_state[st] = by_state.get(st, 0) + 1

        lines = [
            f"GBS status: {operator} ({country}) — {period}",
            f"operator_id: {operator_id} (use for add_statistic, create_source)",
            "",
            f"Existing: {len(existing)} records",
            f"By state: {', '.join(f'{state_names.get(k, k)}: {v}' for k, v in sorted(by_state.items()))}",
            "",
            f"Current stats period: {current_period}",
            f"Staleness: period is {'current' if period == current_period else 'older than current'}",
            "",
            f"Gaps ({len(gaps)} missing combinations):",
            *gaps[:20],
        ]
        if len(gaps) > 20:
            lines.append(f"  ... and {len(gaps) - 20} more")

        return "\n".join(lines)

    def add_statistic(
        type: str,
        operator: str,
        operator_id: str,
        country: str,
        period: str,
        tech: str,
        channel: str,
        domain: str,
        subscribers: int,
        is_estimate: bool = False,
        restated: bool = False,
        notes: str = "",
        created_by: str = "gbs-agent",
        ctx=None,
    ) -> str:
        """
        Insert a Statistics (GBS) record with state: 1 (pending).

        Args:
            type: broadband | mobile | iptv
            operator: Operator display name
            operator_id: Operator ObjectId (from Operator collection)
            country: Country name
            period: Quarter string (e.g. "2025Q1")
            tech: Technology (must match operator's technologies)
            channel: Infrastructure | Retail
            domain: Residential | Business | Total
            subscribers: Subscriber count
            is_estimate: Whether value is estimated
            restated: Whether value was restated
            notes: Optional notes
            created_by: Creator identifier (e.g. user email)

        Returns:
            Inserted record id or error message.
        """
        if type not in VALID_TYPES:
            return f"Invalid type: {type}. Must be one of {VALID_TYPES}"
        if channel not in VALID_CHANNELS:
            return f"Invalid channel: {channel}. Must be one of {VALID_CHANNELS}"
        if domain not in VALID_DOMAINS:
            return f"Invalid domain: {domain}. Must be one of {VALID_DOMAINS}"
        if not _valid_object_id(operator_id):
            return f"Invalid operator_id: must be 24 hex chars"

        op = mongo.find_one_operator_by_id(operator_id)
        if not op:
            return f"Operator not found: {operator_id}"
        techs = op.get("technologies", [])
        tech_match = next((t for t in techs if t.lower() == tech.lower()), None)
        if not tech_match:
            return f"Tech '{tech}' not valid for operator. Valid: {techs}"

        doc = {
            "type": type,
            "country": country,
            "operator": operator,
            "operatorId": operator_id,
            "period": period,
            "tech": tech_match,
            "channel": channel,
            "domain": domain,
            "subscribers": subscribers,
            "is_estimate": is_estimate,
            "restated": restated,
            "notes": notes or None,
            "createdBy": created_by,
        }
        inserted_id = mongo.insert_one_statistic(doc)
        return f"Created statistic {inserted_id} (state: pending)"

    def create_source(
        operator_id: str,
        year: int,
        quarter: int,
        type: str,
        url: str = "",
        file_url: Optional[str] = None,
        ctx=None,
    ) -> str:
        """
        Insert a Source record for an operator/period.

        Args:
            operator_id: Operator ObjectId (from Operator collection)
            year: Year (e.g. 2025)
            quarter: Quarter 1-4
            type: Source type (e.g. "report", "tariff")
            url: Source URL
            file_url: Optional file URL (e.g. S3 path)

        Returns:
            Inserted record id or error message.
        """
        if quarter < 1 or quarter > 4:
            return f"Invalid quarter: {quarter}. Must be 1-4"
        if not _valid_object_id(operator_id):
            return f"Invalid operator_id: must be 24 hex chars"

        if not mongo.find_one_operator_by_id(operator_id):
            return f"Operator not found: {operator_id}"

        doc = {
            "operatorId": operator_id,
            "year": year,
            "quarter": quarter,
            "type": type,
            "url": url or None,
            "fileUrl": file_url,
        }
        inserted_id = mongo.insert_one_source(doc)
        return f"Created source {inserted_id}"


def _run_test_flow():
    """Run GBS tools with real MongoDB. Use: uv run python -m point_topic_mcp.tools.gbs_tools"""
    import sys

    mod_name = "point_topic_mcp.tools.gbs_tools"
    gbs = sys.modules.get(mod_name) or sys.modules.get("__main__")
    if not gbs or not hasattr(gbs, "list_operators"):
        print("SKIP: GBS tools not loaded (PT_RESEARCH_DATABASE_URI not set)")
        return

    print("=== GBS Tools Test Flow ===\n")

    print("1. list_operators():")
    try:
        out = gbs.list_operators()
        print(out[:2000] + ("..." if len(out) > 2000 else ""))
    except Exception as e:
        print(f"   FAIL: {e}")
        return

    out, first_line, country, op_name = "", "", "", ""
    print("\n2. get_gbs_status() for first UK operator:")
    try:
        for c in ("United Kingdom", "UK"):
            out = gbs.list_operators(country=c)
            if "id=" in out:
                country = c
                break
        if "id=" not in out:
            print("   No UK operators - cannot test get_gbs_status")
        else:
            first_line = [l for l in out.split("\n") if l.strip() and "|" in l][0]
            parts = first_line.split("|")
            op_name = parts[0].strip()
            status = gbs.get_gbs_status(country, op_name, "2025Q1")
            print(status[:600] + ("..." if len(status) > 600 else ""))
    except Exception as e:
        print(f"   FAIL: {e}")

    print("\n3. add_statistic():")
    try:
        result = gbs.add_statistic(
            type="invalid",
            operator="BT",
            operator_id="000000000000000000000001",
            country="UK",
            period="2025Q1",
            tech="FTTP",
            channel="Wrong",
            domain="Residential",
            subscribers=1000,
        )
        assert "Invalid" in result
        print("   Validation OK: rejected invalid type/channel")
    except Exception as e:
        print(f"   Validation FAIL: {e}")

    op_id = None
    if "id=" in out and first_line:
        import re
        m = re.search(r"id=([a-f0-9]{24})", first_line)
        if m:
            op_id = m.group(1)

    if op_id:
        print("\n4. add_statistic() real insert:")
        try:
            result = gbs.add_statistic(
                type="broadband",
                operator=op_name,
                operator_id=op_id,
                country=country,
                period="2025Q1",
                tech="FTTP",
                channel="Infrastructure",
                domain="Residential",
                subscribers=99999,
                notes="gbs_tools test flow",
                created_by="gbs-test-script",
            )
            print(f"   {result}")
        except Exception as e:
            print(f"   FAIL: {e}")

        print("\n5. create_source() real insert:")
        try:
            result = gbs.create_source(
                operator_id=op_id,
                year=2025,
                quarter=1,
                type="test",
                url="https://example.com/gbs-test",
            )
            print(f"   {result}")
        except Exception as e:
            print(f"   FAIL: {e}")

    print("\n=== Test flow complete ===")


if __name__ == "__main__":
    _run_test_flow()
