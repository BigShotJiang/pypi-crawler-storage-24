def get_dataset_summary():
    "This will be visible to the agent at all times, so keep it short, but let the agent know if the dataset can answer the question of the user."
    return """
    Point Topic Telecommunications Ontology: Comprehensive structured knowledge base for UK telecom market analysis.
    
    CORE CAPABILITIES:
    - Organization analysis: ISPs, network operators, corporate relationships, ownership structures
    - Infrastructure mapping: Networks, coverage areas, technology types (fiber, cable, wireless)
    - Service analysis: Broadband offerings, pricing, technology specifications
    - Market structure: Retail vs wholesale relationships, consolidations, mergers
    - Temporal analysis: Historical changes, entity lifecycles, market evolution
    - Geographical data: Coverage areas, location-based analysis
    
    QUERY TYPES SUPPORTED:
    - "Who owns/operates network X?" - Corporate relationships and ownership
    - "Which ISPs use fiber networks?" - Technology and service analysis  
    - "Show market consolidations over time" - Historical M&A analysis
    - "What services does ISP X offer?" - Service portfolio analysis
    - "Which networks cover location Y?" - Geographic coverage analysis
    - "Find retail-only ISPs" - Business model classification
    
    DATA SCOPE: UK telecommunications market with 3-tier ontology (core/business/documents), temporal validity, enforced relationships.
    """


def get_db_info():
    return f"""
    {DB_INFO}

    {DB_SCHEMA}

    {SQL_EXAMPLES}
    """


DB_INFO = """
STRUCTURED KNOWLEDGE BASE FOR UK TELECOM MARKET. 
IMPLEMENTED IN SQL (NOT RDF) FOR SPEED AND SCALABILITY.

Schema pattern: ONTOLOGY.[entity_type].[entity_name]

ONTOLOGY VIEWS:
- core: foundational entities (~10-500 rows), enforced constraints, stable schema
- business: core + business data (thousands-millions rows), coverage/subscriber/service data
- business_documents: all above + DCAT metadata, document/publication links

ENTITY TYPES:
1. CLASS: fundamental concepts (e.g. foaf_organization, cto_network, cto_broadband_service)
2. OBJECT_PROPERTY: relationships (e.g. cto_uses_network, cto_owns_network, cto_offers_broadband_service)
3. DATA_PROPERTY: attributes (e.g. cto_is_retail_only, cto_has_subscribers)

CRITICAL: DATE COLUMNS ARE VARCHAR
All date columns stored as VARCHAR in Snowflake. Use TO_DATE() when filtering:
  WHERE TO_DATE(valid_from) <= CURRENT_DATE()
  WHERE valid_to IS NULL OR TO_DATE(valid_to) > CURRENT_DATE()

TEMPORAL VALIDITY:
All entities have valid_from/valid_to for historical tracking, with valid_to = null if still valid. Filter for current:
  WHERE valid_to IS NULL OR TO_DATE(valid_to) > CURRENT_DATE()

ORGANIZATION TYPES:
"ISP", "Network Operator", "Non Telco Organization" (exact spelling)
Country: "United Kingdom" (exact spelling)

GENERIC MEASUREMENTS:
cto_measurement_record contains generic measurements that describe geo/demographic data. This is useful for many calculations. To explore this:
SELECT DISTINCT aspect_name FROM ontology.class.cto_measurement_record;

QUERY TIP:
Start with simple queries to check exact spelling: FOAF_ORGANIZATION, CTO_NETWORK, CTO_USES_NETWORK
"""

SQL_EXAMPLES = [
    {
        "request": "List all current ISPs",
        "response": """
            select o.organization_name, o.country
            from ontology.class.foaf_organization o
            join ontology.object_property.cto_is_organization_type ot
              on o.organization_name = ot.organization_name
            where ot.organization_type_name = 'ISP'
              and (o.valid_to is null or to_date(o.valid_to) > current_date())
        """,
    },
    {
        "request": "Show current ISP-network relationships",
        "response": """
            select
              un.isp_name,
              un.network_name,
              own.network_operator_name as network_owner
            from ontology.object_property.cto_uses_network un
            join ontology.object_property.cto_owns_network own
              on un.network_name = own.network_name
            where un.valid_to is null or to_date(un.valid_to) > current_date()
        """,
    },
    {
        "request": "Percentage of UK premises Virgin Media could potentially sell to.",
        "response": """
            with get_network_footprint_pcd as (
              -- entity_name will be networks in this case.
              select distinct
                location_name as postcode
              from ontology.class.cto_measurement_record
              -- filter for positive presence measurements that are still existent
              where aspect_name = 'presence' and magnitude_name = '1' and valid_to is null
                -- we filter entity_name as the list of networks associated with the ISP 'Virgin Media'
                and entity_name in (
                  select
                    network_name
                  from ontology.object_property.cto_uses_network
                  where isp_name = 'Virgin Media'
                )
            ),
            get_prems_to_pcd_lookup as (
              select
                location_name as postcode,
                magnitude_name as prems
              from ontology.class.cto_measurement_record
              where entity_name = 'UPC Premises'
                and valid_to is null
            ),
            get_prem_count as (
              select
                sum(prems) as prems_sum
              from get_network_footprint_pcd
              inner join get_prems_to_pcd_lookup
              using (postcode)
            )
            select * from get_prem_count
            limit 10
        """,
    },
    {
        "request": "Postcodes which got their very first full fibre connection sometime in the last year?",
        "response": """
            with get_network_footprint_pcd as (
              -- entity_name will be networks in this case.
              select distinct
                location_name as postcode
              from ontology.class.cto_measurement_record
              -- filter for positive presence measurements that are still existent
              where aspect_name = 'presence' and magnitude_name = '1' and valid_to is null
                -- we filter entity_name as the list of networks associated with the ISP 'Virgin Media'
                and entity_name in (
                  select
                    network_name
                  from ontology.object_property.cto_uses_network
                  where isp_name = 'Virgin Media'
                )
            ),
            get_prems_to_pcd_lookup as (
              select
                location_name as postcode,
                magnitude_name as prems
              from ontology.class.cto_measurement_record
              where entity_name = 'UPC Premises'
                and valid_to is null
            ),
            get_prem_count as (
              select
                sum(prems) as prems_sum
              from get_network_footprint_pcd
              inner join get_prems_to_pcd_lookup
              using (postcode)
            )
            select * from get_prem_count
            limit 10
        """,
    },
]

# can we get this dynamically from snowflake? (ONTOLOGY.UTILS.UTIL_ONTO_METADATA_ENTITY)
DB_SCHEMA = '''
TABLE_NAME,ONTOLOGY_VIEW_NAME,ENTITY_TYPE,DESCRIPTION,COLUMN_NAMES
cto_broadband_service,business,class,Any service specifically related to providing broadband services.,"[""broadband_service_name"",""isp_name"",""tech"",""fastest_down"",""guaranteed_down"",""fastest_up"",""guaranteed_up"",""monthly_cost"",""setup_cost"",""local_currency"",""contract_length"",""bundle_home_phone"",""bundle_mobile_phone"",""bundle_video"",""valid_from"",""valid_to"",""comment"",""country""]"
cto_concept_entity,business,class,"A conceptual entity. Generally, an entity that does not occupy space in the physical world. Mutually exclusive with cto_physical_entities.","[""concept_entity_name"",""comment""]"
cto_measurement_record,business,class,"A record containing quantitative measurement data for telecom entities, including aspects, magnitudes, units, and metadata.","[""entity_name"",""aspect_name"",""location_name"",""magnitude_name"",""unit_of_measure_name"",""accuracy_name"",""valid_from"",""valid_to"",""comment"",""country"",""data_source"",""id""]"
cto_physical_entities,business,class,"A physical entity. Generally, an entity that occupies space in the physical world. Mutually exclusive with cto_concept_entity.","[""physical_entity_name"",""comment""]"
cto_physical_infrastructure,business,class,"Categories of physical infrastructure, which must occupy physical space in/on the ground.","[""physical_infrastructure_name"",""comment""]"
cto_service,business,class,Any service provided by a company to a user. Includes broadband/entertainment/mobile services.,"[""service_name"",""comment""]"
dcterms_location,business,class,"A spatial region or named place. Any spatial thing considered to be a location, e.g. country, street, postcode, NUTS3 ID.","[""location_name"",""location_type_name"",""data_source"",""geo"",""valid_from"",""valid_to"",""comment"",""country"",""id""]"
wgs84_spatial_thing,business,class,"Anything with spatial extent, i.e. size, shape, or position. e.g. people, places, bowling balls, as well as abstract areas like cubes.","[""spatial_thing_name"",""geo"",""valid_from"",""valid_to"",""comment""]"
cto_containment_assertion,business,object_property,"Relates spatial entities to express containment relationships (e.g., a city is contained within a region).","[""spatial_subject"",""spatial_object"",""spatial_relation"",""valid_from"",""valid_to"",""country"",""id""]"
cto_has_coverage_data,business,object_property,"coverage level of a network at a location (percentage, population, or otherwise)","[""network_name"",""location_name"",""value"",""unit"",""valid_from"",""valid_to"",""comment"",""country""]"
cto_offers_broadband_service,business,object_property,Relates an ISP to the broadband services it offers to customers.,"[""isp_name"",""broadband_service_name"",""valid_from"",""valid_to"",""comment""]"
cto_accuracy,core,class,"A classification of the precision or reliability level of a measurement or data point, ranging from high to low accuracy, or unknown when accuracy cannot be determined.","[""accuracy_name"",""comment""]"
cto_country,core,class,A sovereign state or nation used for geographical and administrative classification in telecom data.,"[""country_name"",""comment""]"
cto_link,core,class,The physical transmission medium or infrastructure type used to connect a premises or network endpoint to the broadband access network.,"[""link_name"",""comment""]"
cto_link_standard,core,class,The data transmission standard or protocol used over the physical transmission medium/infrastructure (cto_link) to deliver broadband connectivity.,"[""link_standard_name"",""comment""]"
cto_network,core,class,Any physical infrastructure network that forms a telecom-related network and occupies physical space in/on the ground.,"[""network_name"",""valid_from"",""valid_to"",""comment"",""country""]"
cto_network_type,core,class,"A classification type for networks based on their technology and service delivery method (e.g., Fixed, Satellite, Mobile, Hybrid).","[""network_type_name"",""comment""]"
cto_organization_type,core,class,"A classification type for organizations based on their role in the telecom industry (e.g., ISP, Network Operator, Non Telco Organization).","[""organization_type_name"",""comment""]"
cto_unit_of_measure,core,class,"A standardized quantity used to express and compare measurements, such as binary values, household counts, or percentage values.","[""unit_of_measurement_name"",""comment""]"
foaf_organization,core,class,"Any kind of organization. The Organization class represents a kind of Agent corresponding to social instititutions such as companies, societies etc.","[""organization_name"",""valid_from"",""valid_to"",""comment"",""country""]"
gist_aspect,core,class,"A particular feature or dimension of measurement that can be observed or quantified, such as coverage, presence, roadworks location, or subscriber counts.","[""aspect_name"",""comment""]"
cto_is_altnet,core,data_property,"UK-specific term: an Altnet is an informal term for non-incumbent network operator usually deploying its own high-speed (fibre optic) network in the UK. Usually understood to represent all network operators except BT/Openreach, Virgin Media, KCOM. While generally referring to network operators, we also label any ISPs related to these network operators as altnets.","[""organization_name"",""is_altnet"",""valid_from"",""valid_to"",""comment""]"
cto_is_business_only,core,data_property,Specifies whether an organization (ISP or Network Operator) is business-only (exclusively sells to business customers).,"[""isp_name"",""is_business_only"",""valid_from"",""valid_to"",""comment""]"
cto_is_network_segment,core,data_property,"Indicates whether a network represents a segment or part of a larger network infrastructure, rather than a complete network.","[""network_name"",""is_network_segment"",""valid_from"",""valid_to"",""comment""]"
cto_is_retail_only,core,data_property,Specifies whether an ISP is retail-only (does not own any network infrastructure).,"[""isp_name"",""is_retail_only"",""valid_from"",""valid_to"",""comment""]"
cto_is_wholesale_only,core,data_property,Specifies whether a network operator is only wholesale (does not sell services directly to end-users).,"[""network_operator_name"",""is_wholesale_only"",""valid_from"",""valid_to"",""comment""]"
cto_has_corporate_relationship,core,object_property,Indicates that one organization has an ownership/investment stake in another organization.,"[""relationship_from"",""relationship_to"",""relationship_type"",""valid_from"",""valid_to"",""comment""]"
cto_is_consolidated,core,object_property,Relates a network or organization to the network or organization it is consolidated into.,"[""consolidated_from"",""consolidated_to"",""announced_at"",""completed_at"",""is_merged"",""is_acquired"",""is_dissolved"",""comment"",""country""]"
cto_is_network_type,core,object_property,"Relates a network to its type classification (e.g., Fixed, Satellite, Mobile, Hybrid).","[""network_name"",""network_type_name"",""valid_from"",""valid_to"",""comment""]"
cto_is_organization_type,core,object_property,"Relates an organization to its type classification (e.g., ISP, Network Operator, Non Telco Organization).","[""organization_name"",""organization_type_name"",""valid_from"",""valid_to"",""comment""]"
cto_owns_network,core,object_property,Relates a telco organization to the network it owns.,"[""network_operator_name"",""network_name"",""valid_from"",""valid_to"",""comment""]"
cto_supports_link_standard,core,object_property,Relates a physical transmission medium/infrastructure link to the protocol/standard.,"[""link_name"",""link_standard_name"",""comment""]"
cto_uses_link,core,object_property,Relates a network to the link technology it uses.,"[""network_name"",""link_name"",""comment""]"
cto_uses_link_standard,core,object_property,Relates a network to the protocol/standard used by the physical link infrastructure.,"[""network_name"",""link_standard_name"",""comment""]"
cto_uses_network,core,object_property,Relates an ISP to the network it uses to provide services.,"[""isp_name"",""network_name"",""valid_from"",""valid_to"",""comment""]"
dcat_catalogue,documents,class,A catalogue or repository that hosts the Datasets or Data Services being described.,"[""title"",""description"",""publisher"",""creator"",""service"",""geographical_coverage"",""temporal_coverage"",""themes"",""release_date"",""modification_date"",""language"",""rights""]"
dcat_data_service,documents,class,A collection of operations that provides access to one or more datasets or data processing functions.,"[""title"",""description"",""publisher"",""theme"",""format"",""access_rights"",""licence"",""landing_page"",""serves_dataset""]"
dcat_dataset,documents,class,"A conceptual entity that represents the information published. (doesn't have to be a dataset, can also be an article, webpage).","[""dataset_name"",""title"",""description"",""publisher"",""release_date"",""version"",""type"",""theme"",""keyword"",""language"",""geographical_coverage"",""temporal_coverage"",""spatial_resolution"",""temporal_resolution"",""in_series"",""documentation"",""source"",""related_resource"",""was_generated_by"",""related_entities_raw"",""related_entities_cto""]"
dcat_dataset_series,documents,class,"A collection of datasets that are published separately, but share some characteristics that group them.","[""title"",""description"",""publisher""]"
dcat_geographical_coverage,documents,object_property,A geographical area covered by the Catalogue. (note: may be merged with cto_has_coverage_area in the future),"[""object_name"",""location_name"",""valid_from"",""valid_to"",""comment""]"
dcat_has_record,documents,object_property,A Catalogue Record that is part of the Catalogue.,"[""catalgue_name"",""dataset_name"",""valid_from"",""valid_to"",""comment""]"
dcat_in_series,documents,object_property,A dataset series of which the dataset is part.,"[""dataset_name"",""dataset_series_name"",""valid_from"",""valid_to"",""comment""]"
dcat_is_publisher,documents,object_property,An entity (organisation) responsible for making something available.,"[""organization_name"",""object_name"",""valid_from"",""valid_to"",""comment""]"
dcat_serves_dataset,documents,object_property,This property refers to a collection of data that this data service can distribute.,"[""data_service_name"",""dataset_name"",""valid_from"",""valid_to"",""comment""]"
foaf_is_topic,documents,object_property,A topic of some page or document.,"[""organization_name"",""object_name"",""valid_from"",""valid_to"",""comment""]"

'''
