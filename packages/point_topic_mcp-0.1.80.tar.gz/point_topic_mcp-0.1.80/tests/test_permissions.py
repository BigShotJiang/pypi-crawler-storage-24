"""Test script to verify the permission system works correctly.

Run this to verify:
1. Auth imports work
2. Decorators are properly registered
3. Permission checking functions work
"""

from point_topic_mcp.auth import (
    public,
    requires_permissions,
    is_public_tool,
    get_tool_permissions,
    has_tool_permissions,
    PUBLIC_TOOLS,
    TOOL_PERMISSIONS,
    PermissionMiddleware,
    is_pt_admin,
    check_tool_access,
)


# Test 1: @public decorator
@public
def test_public_tool():
    return "public"


assert is_public_tool("test_public_tool"), "Public tool should be registered"
print("✓ @public decorator works")


# Test 2: @requires_permissions decorator
@requires_permissions(["read:data", "write:data"])
def test_permission_tool():
    return "permission required"


perms = get_tool_permissions("test_permission_tool")
assert perms == ["read:data", "write:data"], f"Expected permissions, got {perms}"
print("✓ @requires_permissions decorator works")

# Test 3: Permission checking
user_perms = ["read:data"]
result = has_tool_permissions("test_permission_tool", user_perms)
assert result == False, "Should fail - missing write:data permission"

user_perms = ["read:data", "write:data"]
result = has_tool_permissions("test_permission_tool", user_perms)
assert result == True, "Should succeed - has all permissions"
print("✓ Permission checking works")

# Test 4: ptAdmin bypass
user_perms = ["ptAdmin"]
result = has_tool_permissions("test_permission_tool", user_perms)
assert result == True, "ptAdmin should bypass permission checks"

user_perms = ["Point Topic Admin"]
result = has_tool_permissions("test_permission_tool", user_perms)
assert result == True, "Point Topic Admin should bypass permission checks"
print("✓ ptAdmin bypass works")

# Test 5: Public tools always allowed
user_perms = []  # No permissions
result = has_tool_permissions("test_public_tool", user_perms)
assert result == True, "Public tools should always be allowed"
print("✓ Public tools always accessible")

# Test 6: is_pt_admin helper
assert is_pt_admin(["ptAdmin"]) == True
assert is_pt_admin(["Point Topic Admin"]) == True
assert is_pt_admin(["admin"]) == True
assert is_pt_admin(["regular_user"]) == False
print("✓ is_pt_admin helper works")

# Test 7: check_tool_access function
allowed, reason = check_tool_access("test_public_tool", [])
assert allowed == True, "Public tool should be allowed"

allowed, reason = check_tool_access("test_permission_tool", [])
assert allowed == False, "Should require auth"
assert "Authentication required" in reason

allowed, reason = check_tool_access("test_permission_tool", ["read:data"])
assert allowed == False, "Should require both permissions"
assert "Missing permissions" in reason

allowed, reason = check_tool_access("test_permission_tool", ["read:data", "write:data"])
assert allowed == True, "Should have both permissions"

allowed, reason = check_tool_access("test_permission_tool", ["ptAdmin"])
assert allowed == True, "ptAdmin should have access"
assert "ptAdmin access" in reason
print("✓ check_tool_access works correctly")

print("\n" + "=" * 50)
print("✅ All permission system tests passed!")
print("=" * 50)
