# GBS tools implementation (issue #63)

## Summary
- New `gbs_tools.py` with 3 tools for PT Research App MongoDB
- Parent: upc_query_agent#37 (PT Systems Agent + GBS Pipeline)

## Tools
1. **get_gbs_status** — country, operator, period → existing stats, gaps (missing type/tech/channel/domain combos), staleness vs current period. Returns operator_id for downstream calls.
2. **add_statistic** — insert Statistics with state 1 (pending). Validates type/channel/domain, operator exists, tech in operator's technologies.
3. **create_source** — insert Sources (operatorId, year, quarter, type, url, fileUrl)

## Changes
- Added pymongo to pyproject.toml
- Env var: `PT_RESEARCH_DATABASE_URI` (same MongoDB as pt-research-app DATABASE_URI)
- No silent fallbacks: tools only register when env present; _get_db() raises if URI empty
- Updated server_info_tools docstring with PT_RESEARCH_DATABASE_URI

## Schema ref
- Prisma collections: Statistics, Sources, Operator, GlobalVariables
- Statistics: type, operatorId, period, tech, channel, domain, state (1=pending), subscribers, etc.
- Sources: operatorId, year, quarter, type, url, fileUrl
