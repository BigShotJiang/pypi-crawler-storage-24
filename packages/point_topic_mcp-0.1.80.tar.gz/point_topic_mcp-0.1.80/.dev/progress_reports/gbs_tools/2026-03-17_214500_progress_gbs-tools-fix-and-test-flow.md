# GBS tools fix and test flow

- **list_operators** new tool – discover operators before get_gbs_status (country uses exact match, e.g. "United Kingdom" not "UK")
- MongoClient: added serverSelectionTimeoutMS=10000, connectTimeoutMS=10000
- __main__ test flow: `uv run python -m point_topic_mcp.tools.gbs_tools`
- Test flow: list_operators → get_gbs_status → add_statistic validation → add_statistic real insert → create_source real insert
- Docstrings: country must match exactly (United Kingdom vs UK)
- PT_RESEARCH_DATABASE_URI added to .env.example
- All 7 unit tests pass (incl. new test_list_operators)
