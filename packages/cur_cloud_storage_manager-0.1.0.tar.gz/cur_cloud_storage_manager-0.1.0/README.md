# Cloud Storage Manager

Unified Python interface for AWS S3 and Google Cloud Storage operations.

## Installation

```bash
pip install cloud-storage-manager
```

## Quick Start

```python
from cloud_storage_manager import StorageFactory

# Create storage client
storage = StorageFactory.create(
    provider='aws',  # or 'gcp'
    bucket_name='my-bucket'
)

# Upload
url = storage.upload(data=b'...', remote_path='file.txt')

# Download
data = storage.download('file.txt')

# List
files = storage.list_objects(prefix='folder/')
```

## Features

- ✅ Unified API for AWS S3 and GCP Storage
- ✅ Upload, download, delete operations
- ✅ List objects with prefix filtering
- ✅ Generate public and signed URLs
- ✅ Custom metadata and cache control
- ✅ Type hints and full documentation
- ✅ Extensible for additional providers

## Documentation

See [full documentation](https://github.com/yourusername/cloud-storage-manager) for more examples.