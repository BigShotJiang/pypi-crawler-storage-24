import pytest
from cloud_storage_manager import StorageFactory


@pytest.fixture
def gcp_storage():
    return StorageFactory.create(
        provider='gcp',
        bucket_name='my-gcp-bucket',
        credentials_path='path/to/credentials.json'
    )


def test_upload(gcp_storage):
    url = gcp_storage.upload(data=b'test data', remote_path='test.txt')
    assert url is not None


def test_download(gcp_storage):
    gcp_storage.upload(data=b'test data', remote_path='test.txt')
    data = gcp_storage.download('test.txt')
    assert data == b'test data'


def test_delete(gcp_storage):
    gcp_storage.upload(data=b'test data', remote_path='test.txt')
    assert gcp_storage.delete('test.txt')
