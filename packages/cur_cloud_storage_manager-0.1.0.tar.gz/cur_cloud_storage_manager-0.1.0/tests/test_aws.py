import pytest
from cloud_storage_manager import StorageFactory


@pytest.fixture
def aws_storage():
    return StorageFactory.create(
        provider='aws',
        bucket_name='my-aws-bucket',
        aws_access_key_id='YOUR_ACCESS_KEY',
        aws_secret_access_key='YOUR_SECRET_KEY',
        region='us-west-2'
    )


def test_upload(aws_storage):
    url = aws_storage.upload(data=b'test data', remote_path='test.txt')
    assert url is not None


def test_download(aws_storage):
    aws_storage.upload(data=b'test data', remote_path='test.txt')
    data = aws_storage.download('test.txt')
    assert data == b'test data'


def test_delete(aws_storage):
    aws_storage.upload(data=b'test data', remote_path='test.txt')
    assert aws_storage.delete('test.txt')
