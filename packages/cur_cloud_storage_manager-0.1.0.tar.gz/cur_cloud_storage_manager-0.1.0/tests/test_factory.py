import pytest
from cloud_storage_manager import StorageFactory
from cloud_storage_manager.exceptions import InvalidProviderError


def test_create_aws_storage():
    storage = StorageFactory.create(
        provider='aws',
        bucket_name='my-aws-bucket',
        aws_access_key_id='YOUR_ACCESS_KEY',
        aws_secret_access_key='YOUR_SECRET_KEY',
        region='us-west-2'
    )
    assert storage is not None


def test_create_gcp_storage():
    storage = StorageFactory.create(
        provider='gcp',
        bucket_name='my-gcp-bucket',
        credentials_path='path/to/credentials.json'
    )
    assert storage is not None


def test_invalid_provider():
    with pytest.raises(InvalidProviderError):
        StorageFactory.create(
            provider='unknown_provider',
            bucket_name='my-bucket'
        )
