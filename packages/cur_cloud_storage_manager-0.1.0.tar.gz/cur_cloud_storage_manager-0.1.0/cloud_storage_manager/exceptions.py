class CloudStorageError(Exception):
    """Base exception for cloud storage operations"""
    pass


class StorageUploadError(CloudStorageError):
    """Raised when upload fails"""
    pass


class StorageDownloadError(CloudStorageError):
    """Raised when download fails"""
    pass


class StorageNotFoundError(CloudStorageError):
    """Raised when object is not found"""
    pass


class InvalidProviderError(CloudStorageError):
    """Raised when provider is not recognized"""
    pass
