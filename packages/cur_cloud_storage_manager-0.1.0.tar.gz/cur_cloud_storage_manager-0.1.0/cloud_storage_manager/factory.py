from typing import Dict, Any
from .base import BaseStorageProvider
from .aws_storage import AWSStorage
from .gcp_storage import GCPStorage
from .exceptions import InvalidProviderError


class StorageFactory:
    """Factory for creating storage provider instances"""
    
    _providers = {
        'aws': AWSStorage,
        's3': AWSStorage,
        'gcp': GCPStorage,
        'gcs': GCPStorage,
        'google': GCPStorage,
    }
    
    @classmethod
    def create(cls, provider: str, bucket_name: str, **kwargs) -> BaseStorageProvider:
        """
        Create a storage provider instance
        
        Args:
            provider: Provider name ('aws', 's3', 'gcp', 'gcs', 'google')
            bucket_name: Name of the bucket
            **kwargs: Provider-specific configuration
            
        Returns:
            BaseStorageProvider instance
        """
        provider_lower = provider.lower()
        
        if provider_lower not in cls._providers:
            raise InvalidProviderError(
                f"Unknown provider: {provider}. "
                f"Available: {', '.join(cls._providers.keys())}"
            )
        
        provider_class = cls._providers[provider_lower]
        return provider_class(bucket_name, **kwargs)
    
    @classmethod
    def register_provider(cls, name: str, provider_class: type):
        """Register a custom storage provider"""
        cls._providers[name.lower()] = provider_class
