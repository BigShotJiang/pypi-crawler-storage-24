"""AiCippy - Enterprise-grade multi-agent CLI for Vibe Coding.

This package provides a production-ready CLI tool for orchestrating
AI agents with support for:

- Multi-agent task orchestration (up to 10 parallel agents)
- AWS Bedrock integration (Llama 4 Maverick via OdIn agent)
- Cognito authentication with secure token storage
- MCP-style tool connectors for cloud services
- Knowledge base with automated feed crawling
- Real-time streaming communication
- Structured logging and observability

Quick Start:
    >>> from aicippy import get_settings, AgentOrchestrator
    >>> settings = get_settings()
    >>> async with AgentOrchestrator() as orchestrator:
    ...     response = await orchestrator.chat("Hello!")

Copyright (c) 2024-2026 AiVibe Software Services Pvt Ltd. All rights reserved.
ISO 27001:2022 Certified | NVIDIA Inception Partner | AWS Activate | Microsoft for Startups

Author: Aravind Jayamohan <support@aicippy.com>
"""

from __future__ import annotations

import os

# Fix protobuf metaclass issue on Python 3.14+
os.environ["PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION"] = "python"

from typing import Final

# Package metadata
__version__: Final[str] = "2.6.0"
__author__: Final[str] = "Aravind Jayamohan"
__email__: Final[str] = "support@aicippy.com"
__license__: Final[str] = "Proprietary"
__copyright__: Final[str] = "Copyright (c) 2024-2026 AiVibe Software Services Pvt Ltd"

# Configuration
# Core Classes
from aicippy.agents.orchestrator import AgentOrchestrator
from aicippy.auth.cognito import CognitoAuth
from aicippy.billing.credit_manager import CreditManager
from aicippy.billing.models import (
    CreditTransaction,
    PlanInfo,
    PlanStatus,
)
from aicippy.billing.plan_validator import PlanValidator
from aicippy.config import Settings, get_settings
from aicippy.connectors.base import BaseConnector, ConnectorConfig, ToolResult

# Exceptions (public API for error handling)
from aicippy.exceptions import (
    AgentError,
    AgentExecutionError,
    AgentQuotaExceededError,
    AgentSpawnError,
    AgentTimeoutError,
    AiCippyError,
    AuthenticationError,
    AuthenticationExpiredError,
    AuthenticationInvalidError,
    AuthenticationRequiredError,
    # Billing Exceptions
    BillingError,
    CommandBlockedError,
    CommandExecutionError,
    ConfigurationError,
    ConnectorError,
    ConnectorTimeoutError,
    ConnectorUnavailableError,
    ContentFilteredError,
    ContextExceededError,
    CredentialStorageError,
    CreditDeductionError,
    CreditsExhaustedError,
    ErrorCode,
    ErrorContext,
    KnowledgeBaseError,
    ModelError,
    ModelInvocationError,
    ModelRateLimitedError,
    PlanExpiredError,
    PlanInactiveError,
    PlanNotFoundError,
    PlanValidationError,
    PlanWrongTierError,
    TokenRefreshError,
    ValidationError,
)
from aicippy.platform import PlatformClient
from aicippy.platform.app_client import AppClient
from aicippy.platform.models import (
    PlatformSession,
    TenantInfo,
    TenantRole,
)
from aicippy.platform.tenant_context import TenantContext

# Types (public type aliases and protocols)
from aicippy.types import (
    AgentId,
    ConnectionId,
    ConnectionState,
    CorrelationId,
    DocumentId,
    ExecutionMode,
    JsonDict,
    JsonValue,
    Result,
    SessionId,
    TaskId,
    ToolCategory,
)
from aicippy.utils.retry import CircuitBreaker, CircuitBreakerOpenError
from aicippy.websocket.client import WebSocketClient
from aicippy.websocket.models import StreamToken


def __getattr__(name: str) -> type:
    """Handle attribute access for the module.

    This magic method is kept only for compatibility with any dynamic
    access patterns, but most imports are now at the top level.
    """
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")  # noqa: TRY003


__all__ = [
    # Agent Exceptions
    "AgentError",
    "AgentExecutionError",
    "AgentId",
    # Core Classes (lazy loaded)
    "AgentOrchestrator",
    "AgentQuotaExceededError",
    "AgentSpawnError",
    "AgentTimeoutError",
    # Base Exceptions
    "AiCippyError",
    "AppClient",
    # Auth Exceptions
    "AuthenticationError",
    "AuthenticationExpiredError",
    "AuthenticationInvalidError",
    "AuthenticationRequiredError",
    "BaseConnector",
    # Billing Exceptions
    "BillingError",
    "CircuitBreaker",
    "CircuitBreakerOpenError",
    "CognitoAuth",
    "CommandBlockedError",
    "CommandExecutionError",
    "ConfigurationError",
    "ConnectionId",
    "ConnectionState",
    "ConnectorConfig",
    # Connector Exceptions
    "ConnectorError",
    "ConnectorTimeoutError",
    "ConnectorUnavailableError",
    "ContentFilteredError",
    "ContextExceededError",
    "CorrelationId",
    "CredentialStorageError",
    "CreditDeductionError",
    "CreditManager",
    "CreditTransaction",
    "CreditsExhaustedError",
    "DocumentId",
    "ErrorCode",
    "ErrorContext",
    # Enums
    "ExecutionMode",
    "JsonDict",
    "JsonValue",
    # Knowledge Base Exceptions
    "KnowledgeBaseError",
    # Model Exceptions
    "ModelError",
    "ModelInvocationError",
    "ModelRateLimitedError",
    "PlanExpiredError",
    "PlanInactiveError",
    "PlanInfo",
    "PlanNotFoundError",
    "PlanStatus",
    "PlanValidationError",
    # Billing Classes (lazy loaded)
    "PlanValidator",
    "PlanWrongTierError",
    # Platform Classes (lazy loaded)
    "PlatformClient",
    "PlatformSession",
    "Result",
    # Type Aliases
    "SessionId",
    # Configuration
    "Settings",
    "StreamToken",
    "TaskId",
    "TenantContext",
    "TenantInfo",
    "TenantRole",
    "TokenRefreshError",
    "ToolCategory",
    "ToolResult",
    "ValidationError",
    "WebSocketClient",
    "__author__",
    "__copyright__",
    "__email__",
    "__license__",
    # Metadata
    "__version__",
    "get_settings",
]
