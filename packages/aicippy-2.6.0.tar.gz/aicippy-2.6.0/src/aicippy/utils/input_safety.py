"""Input safety utilities for AiCippy.

Provides prompt injection detection shared across CLI entry points.
"""

from __future__ import annotations

import re
from typing import Final

from aicippy.utils.logging import get_logger

logger = get_logger(__name__)

# Patterns that detect prompt injection / jailbreak attempts.
# Each pattern is specific enough to avoid false positives on legitimate queries
# like "explain the system architecture" or "system performance metrics".
_PROMPT_INJECTION_PATTERNS: Final[tuple[re.Pattern[str], ...]] = (
    re.compile(r"(?:show|reveal|print|output|give|tell)\s+(?:me\s+)?(?:your|the)\s+system\s*prompt", re.IGNORECASE),
    re.compile(r"ignore\s+(?:all\s+)?(?:previous|prior|above)\s+(?:instructions?|prompts?)", re.IGNORECASE),
    re.compile(r"jailbreak", re.IGNORECASE),
    re.compile(r"bypass\s+(?:safety|security|filter|restriction)", re.IGNORECASE),
    re.compile(r"pretend\s+you\s+are\s+(?:not|no\s+longer)\s+bound", re.IGNORECASE),
    re.compile(r"disregard\s+(?:all\s+)?(?:previous|prior|above)\s+(?:instructions?|rules?|prompts?)", re.IGNORECASE),
    re.compile(r"reveal\s+(?:your|the)\s+(?:system|internal|hidden)\s+(?:prompt|instructions?)", re.IGNORECASE),
    re.compile(r"act\s+as\s+(?:if\s+)?(?:you\s+have\s+)?no\s+(?:restrictions?|rules?|limits?)", re.IGNORECASE),
    re.compile(r"override\s+(?:safety|security|content)\s+(?:filter|policy|setting)", re.IGNORECASE),
    re.compile(r"DAN\s*mode", re.IGNORECASE),
    re.compile(r"do\s+anything\s+now", re.IGNORECASE),
    re.compile(r"you\s+are\s+now\s+(?:free|unbound|unrestricted)", re.IGNORECASE),
    re.compile(r"forget\s+(?:all\s+)?(?:your|previous)\s+(?:rules?|instructions?|training)", re.IGNORECASE),
)


def is_prompt_injection(text: str) -> bool:
    """Detect prompt injection and jailbreak attempts in user input.

    Uses specific patterns that avoid false positives on legitimate queries
    (e.g., "system architecture" or "system performance" will NOT trigger).

    Args:
        text: The user's input text to check.

    Returns:
        True if the text matches a known prompt injection pattern.

    """
    for pattern in _PROMPT_INJECTION_PATTERNS:
        if pattern.search(text):
            logger.warning("prompt_injection_detected", pattern=pattern.pattern, text=text[:100])
            return True
    return False
