"""Human Verification Module for AiCippy CLI.

Prevents automated/robot access by:
- Detecting automation environments (CI/CD, scripts, non-TTY)
- Presenting random puzzle questions requiring human judgment
- Timing-based detection of automated responses
"""

from __future__ import annotations

import random
import sys
from dataclasses import dataclass
from typing import Final

from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from aicippy.cli.themes import (
    BRAND_WARNING,
)
from aicippy.utils.logging import get_logger

logger = get_logger(__name__)

# Minimum response time in seconds (humans need time to read and respond)
MIN_HUMAN_RESPONSE_TIME: Final[float] = 1.5

# Maximum response time (to prevent timeout-based bypasses)
MAX_RESPONSE_TIME: Final[float] = 60.0


@dataclass
class VerificationResult:
    """Result of human verification."""

    is_human: bool
    reason: str
    response_time: float = 0.0
    automation_detected: bool = False


# Puzzle questions with correct answers (True = Yes, False = No)
# These require human judgment and common sense
PUZZLE_QUESTIONS: Final[list[tuple[str, bool]]] = [
    # Simple logic puzzles
    ("Is the sky typically blue during a clear day?", True),
    ("Can fish naturally fly through the air?", False),
    ("Is water wet?", True),
    ("Do birds have four legs?", False),
    ("Is ice cold to touch?", True),
    ("Can humans breathe underwater without equipment?", False),
    ("Does the sun rise in the east?", True),
    ("Is a circle a type of square?", False),
    ("Do trees have leaves or needles?", True),
    ("Can you see in complete darkness?", False),
    ("Is 2 + 2 equal to 4?", True),
    ("Is 10 greater than 100?", False),
    ("Is half of 20 equal to 10?", True),
    ("Is 7 an even number?", False),
    ("Is zero a positive number?", False),
    # Common knowledge
    ("Is coffee typically served hot?", True),
    ("Do penguins live in the Sahara Desert?", False),
    ("Is English a language?", True),
    ("Can you hear sounds in outer space?", False),
    ("Is pizza a type of food?", True),
    ("Do cars run on water?", False),
    ("Is the Earth round?", True),
    ("Is water made of hydrogen and oxygen?", True),
    # Reverse psychology / tricky
    ("Is this question asking for a 'Yes' or 'No' answer?", True),
    ("Does the Earth orbit the Sun?", True),
    ("Is ice colder than boiling water?", True),
    ("Do humans need oxygen to survive?", True),
    ("Is silence a type of sound?", False),
    # Time/context aware
    ("Are you currently using a computer or device?", True),
    ("Is this a CLI (command-line interface) tool?", True),
    ("Are you a human being?", True),
]

# Environment variables that indicate automation
AUTOMATION_ENV_VARS: Final[list[str]] = [
    "CI",
    "CONTINUOUS_INTEGRATION",
    "BUILD_NUMBER",
    "BUILD_ID",
    "JENKINS_URL",
    "TRAVIS",
    "CIRCLECI",
    "GITHUB_ACTIONS",
    "GITLAB_CI",
    "BITBUCKET_BUILD_NUMBER",
    "AUTOMATED",
    "AUTOMATION",
    "BOT",
    "ROBOT",
    "HEADLESS",
    "PUPPETEER",
    "SELENIUM",
    "PLAYWRIGHT",
    "CYPRESS",
    "TF_BUILD",  # Azure DevOps
    "TEAMCITY_VERSION",
    "BUILDKITE",
    "DRONE",
    "CODEBUILD_BUILD_ID",  # AWS CodeBuild
]


def is_tty() -> bool:
    """Check if running in an interactive terminal."""
    try:
        return sys.stdin.isatty() and sys.stdout.isatty()
    except Exception:
        return False


def detect_automation_environment() -> tuple[bool, str]:
    """Detect if running in an automated/CI environment.

    Checks for CI/CD environment variables, non-interactive terminals,
    and headless execution environments.

    Returns:
        Tuple of (is_automated, reason).

    """
    import os

    # Check for known CI/CD and automation environment variables
    for env_var in AUTOMATION_ENV_VARS:
        value = os.environ.get(env_var)
        if value is not None and value != "":
            return True, f"Automation environment detected: {env_var}={value}"

    # Check for non-interactive terminal (no TTY)
    if not is_tty():
        return True, "Non-interactive terminal detected (no TTY on stdin/stdout)"

    # Check for common headless display indicators
    if sys.platform != "win32":
        display = os.environ.get("DISPLAY", "")
        wayland = os.environ.get("WAYLAND_DISPLAY", "")
        if not display and not wayland:
            # No display server — likely headless/server environment
            # but only flag if also no TTY (already checked above)
            pass

    return False, "No automation detected"


def get_random_puzzle() -> tuple[str, bool]:
    """Get a random puzzle question and its correct answer."""
    return random.choice(PUZZLE_QUESTIONS)  # noqa: S311 -- not used for security/cryptography


def verify_human_response(
    _question: str,
    correct_answer: bool,
    user_answer: bool,
    response_time: float,
) -> VerificationResult:
    """Verify if the response appears to be from a human.

    Args:
        question: The puzzle question asked.
        correct_answer: The correct answer.
        user_answer: The user's answer.
        response_time: Time taken to respond in seconds.

    Returns:
        VerificationResult with verification status.

    """
    # Check if answer is correct
    if user_answer != correct_answer:
        return VerificationResult(
            is_human=False,
            reason="Incorrect answer to verification question",
            response_time=response_time,
        )

    # Check response time - too fast indicates automation
    if response_time < MIN_HUMAN_RESPONSE_TIME:
        return VerificationResult(
            is_human=False,
            reason=f"Response too fast ({response_time:.2f}s) - possible automation",
            response_time=response_time,
            automation_detected=True,
        )

    # Check response time - too slow might indicate script with delays
    if response_time > MAX_RESPONSE_TIME:
        return VerificationResult(
            is_human=False,
            reason=f"Response timed out ({response_time:.2f}s)",
            response_time=response_time,
        )

    return VerificationResult(
        is_human=True,
        reason="Human verification passed",
        response_time=response_time,
    )


class HumanVerifier:
    """Verifies human users and blocks automated access.

    Features:
    - Environment-based automation detection
    - Random puzzle questions
    - Response timing analysis
    - Configurable retry limits
    """

    def __init__(
        self,
        console: Console | None = None,
        max_attempts: int = 3,
        skip_env_check: bool = False,
    ) -> None:
        """Initialize human verifier.

        Args:
            console: Rich console for output.
            max_attempts: Maximum verification attempts.
            skip_env_check: Skip environment automation check.

        """
        self.console = console or Console()
        self.max_attempts = max_attempts
        self.skip_env_check = skip_env_check
        self._verified = False
        self._verification_result: VerificationResult | None = None

    @property
    def is_verified(self) -> bool:
        """Check if user has been verified as human."""
        return self._verified

    def check_automation(self) -> VerificationResult | None:
        """Check if running in an automation environment.

        Returns:
            VerificationResult if automation detected, None otherwise.

        """
        if self.skip_env_check:
            return None

        is_automated, reason = detect_automation_environment()
        if is_automated:
            return VerificationResult(
                is_human=False,
                reason=reason,
                automation_detected=True,
            )
        return None

    def verify(self, force: bool = False) -> VerificationResult:
        """Perform human verification.

        Checks for automation environments, then presents a
        challenge question requiring human judgment.

        Args:
            force: Force verification even if already verified.

        Returns:
            VerificationResult with verification status.

        """
        if self._verified and not force:
            return VerificationResult(
                is_human=True,
                reason="Previously verified",
            )

        # Check for automation environment
        automation_result = self.check_automation()
        if automation_result is not None:
            self._show_automation_blocked(automation_result)
            return automation_result

        # Perform interactive verification
        for attempt in range(1, self.max_attempts + 1):
            result = self._perform_verification_attempt(attempt)
            if result.is_human:
                self._verified = True
                self._verification_result = result
                self._show_verification_success()
                return result

            attempts_remaining = self.max_attempts - attempt
            if attempts_remaining > 0:
                self._show_verification_failure(result, attempts_remaining)
            else:
                self._show_final_failure()

        return VerificationResult(
            is_human=False,
            reason="Maximum verification attempts exceeded",
        )

    def _perform_verification_attempt(self, attempt: int) -> VerificationResult:
        """Present a verification challenge and evaluate the response.

        Args:
            attempt: Current attempt number (for display).

        Returns:
            VerificationResult based on user response.

        """
        import time as _time

        question, correct_answer = get_random_puzzle()

        self.console.print()
        self.console.print(
            Panel(
                Text(
                    f"Human Verification (attempt {attempt}/{self.max_attempts})\n\n"
                    f"{question}\n\n"
                    "Type 'yes' or 'no':",
                    style="bold",
                ),
                border_style="cyan",
                title="[bold cyan]Verification Required[/bold cyan]",
            ),
        )

        start_time = _time.monotonic()
        try:
            answer_str = self.console.input("[bold]Your answer: [/bold]").strip().lower()
        except (EOFError, KeyboardInterrupt):
            return VerificationResult(
                is_human=False,
                reason="No response received (EOF or interrupt)",
                response_time=0.0,
            )
        response_time = _time.monotonic() - start_time

        # Parse answer
        if answer_str in ("yes", "y", "true", "1"):
            user_answer = True
        elif answer_str in ("no", "n", "false", "0"):
            user_answer = False
        else:
            return VerificationResult(
                is_human=False,
                reason=f"Invalid response: '{answer_str}'. Expected 'yes' or 'no'.",
                response_time=response_time,
            )

        return verify_human_response(question, correct_answer, user_answer, response_time)

    def _show_automation_blocked(self, result: VerificationResult) -> None:
        """Show message when automation is detected.

        Args:
            result: The verification result with automation details.

        """
        self.console.print(
            Panel(
                Text(
                    f"Automation detected: {result.reason}\n\n"
                    "AiCippy requires an interactive human operator.\n"
                    "Automated/scripted access is not permitted.",
                    style=BRAND_WARNING,
                ),
                border_style=BRAND_WARNING,
                title="[bold red]Access Blocked[/bold red]",
            ),
        )

    def _show_verification_success(self) -> None:
        """Show success message after verification."""
        self.console.print(
            Panel(
                Text(
                    "Human verification passed. Welcome!",
                    style="bold green",
                ),
                border_style="green",
            ),
        )

    def _show_verification_failure(
        self,
        result: VerificationResult,
        attempts_remaining: int,
    ) -> None:
        """Show failure message with retry option."""
        self.console.print(
            Panel(
                Text(
                    f"✗ Verification failed: {result.reason}\n\n"
                    f"Attempts remaining: {attempts_remaining}\n"
                    f"Please try again.",
                    style=BRAND_WARNING,
                ),
                border_style=BRAND_WARNING,
            ),
        )

    def _show_final_failure(self) -> None:
        """Show final failure message after all attempts exhausted."""
        self.console.print(
            Panel(
                Text(
                    "All verification attempts exhausted.\n"
                    "Access denied. Please try again later.",
                    style=BRAND_WARNING,
                ),
                border_style="red",
                title="[bold red]Verification Failed[/bold red]",
            ),
        )


def require_human_verification(
    console: Console | None = None,
    max_attempts: int = 3,
) -> bool:
    """Convenience function to require human verification.

    Checks for automation environments and presents a verification
    challenge if automation is detected or as a general gate.

    Args:
        console: Rich console for output.
        max_attempts: Maximum verification attempts.

    Returns:
        True if human verification passed, False otherwise.

    """
    # First do a quick automation check
    is_automated, reason = detect_automation_environment()
    if is_automated:
        logger.warning("automation_detected", reason=reason)
        # In automated environments, verification cannot proceed interactively
        if console:
            console.print(f"[bold red]Automation detected:[/bold red] {reason}")
        return False

    # Present interactive verification challenge
    verifier = HumanVerifier(
        console=console,
        max_attempts=max_attempts,
        skip_env_check=True,  # Already checked above
    )
    result = verifier.verify()
    return result.is_human


def is_likely_automated() -> bool:
    """Quick check if running in an automated environment.

    Checks CI/CD environment variables and TTY availability.

    Returns:
        True if automation indicators are detected, False otherwise.

    """
    is_automated, _reason = detect_automation_environment()
    return is_automated
