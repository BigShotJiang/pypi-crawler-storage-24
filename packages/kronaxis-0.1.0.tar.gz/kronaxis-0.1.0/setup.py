"""Kronaxis Python SDK — pip-installable package."""

from setuptools import setup, find_packages

setup(
    name="kronaxis",
    version="0.1.0",
    description="Python SDK for the Kronaxis Panel Studio API",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="Kronaxis Limited",
    author_email="dev@kronaxis.co.uk",
    url="https://github.com/kronaxis/kronaxis-python-sdk",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        "requests>=2.28.0",
    ],
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: Other/Proprietary License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    keywords="kronaxis panel-studio synthetic-personas causal-reasoning",
)
