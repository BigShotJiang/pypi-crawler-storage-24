"""
Kronaxis SDK — Conversation operations.
"""

from __future__ import annotations

import time
from typing import Any, Dict, List, Optional, TYPE_CHECKING

from .models import AskResult, CompareResult, Conversation, Turn

if TYPE_CHECKING:
    from . import KronaxisClient


class ConversationAPI:
    """Conversation management and stimulus submission."""

    def __init__(self, client: KronaxisClient) -> None:
        self._client = client

    def list(self, panel_id: str) -> List[Conversation]:
        """List conversations for a panel."""
        data = self._client._get(f"/api/panels/{panel_id}/conversations")
        return [Conversation.from_dict(c) for c in data]

    def get(self, panel_id: str, conversation_id: str) -> Conversation:
        """Get conversation detail including all turns."""
        data = self._client._get(
            f"/api/panels/{panel_id}/conversations/{conversation_id}"
        )
        return Conversation.from_dict(data)

    def create(self, panel_id: str, *, title: str = "Untitled conversation",
               description: str = "") -> Conversation:
        """Create a new conversation on a panel."""
        body = {"title": title, "description": description}
        data = self._client._post(
            f"/api/panels/{panel_id}/conversations", body
        )
        return Conversation.from_dict(data)

    def rename(self, panel_id: str, conversation_id: str, *,
               title: Optional[str] = None,
               description: Optional[str] = None) -> Dict[str, Any]:
        """Rename or update a conversation."""
        body: Dict[str, Any] = {}
        if title:
            body["title"] = title
        if description is not None:
            body["description"] = description
        return self._client._patch(
            f"/api/panels/{panel_id}/conversations/{conversation_id}", body
        )

    def ask(
        self,
        panel_id: str,
        stimulus: str,
        *,
        conversation_id: Optional[str] = None,
        stimulus_type: str = "standard",
        sample_size: int = 0,
        wait: bool = True,
        timeout: int = 300,
        poll_interval: int = 3,
    ) -> AskResult:
        """Submit a stimulus to a panel and optionally wait for completion.

        If conversation_id is not provided, a new conversation is created.

        Args:
            panel_id: Panel UUID.
            stimulus: The question or stimulus text.
            conversation_id: Existing conversation UUID (created if omitted).
            stimulus_type: standard or custom.
            sample_size: 0 for all personas, or a specific count.
            wait: If True (default), polls until the turn completes.
            timeout: Max seconds to wait if wait=True.
            poll_interval: Seconds between status polls.

        Returns:
            AskResult with turn_id, run_id, and status.
        """
        if not conversation_id:
            conv = self.create(panel_id, title=stimulus[:60])
            conversation_id = conv.id

        body = {
            "stimulus": stimulus,
            "stimulus_type": stimulus_type,
            "sample_size": sample_size,
        }
        data = self._client._post(
            f"/api/panels/{panel_id}/conversations/{conversation_id}/ask",
            body,
        )
        result = AskResult.from_dict(data)

        if wait and result.run_id:
            deadline = time.time() + timeout
            while time.time() < deadline:
                time.sleep(poll_interval)
                status = self._client._get(
                    f"/api/panels/{panel_id}/conversations/{conversation_id}/status"
                )
                if status.get("status") == "complete":
                    result.status = "complete"
                    break

        return result

    def status(self, panel_id: str, conversation_id: str) -> Dict[str, Any]:
        """Poll the latest turn's status."""
        return self._client._get(
            f"/api/panels/{panel_id}/conversations/{conversation_id}/status"
        )

    def compare(
        self,
        panel_id: str,
        conversation_id: str,
        stimulus_a: str,
        stimulus_b: str,
        *,
        sample_size: int = 50,
    ) -> CompareResult:
        """Run an A/B comparison test on a panel.

        Submits both stimuli to the same panel and returns a comparative
        analysis including sentiment, DYNAMICS-8 breakdown, and winner.

        Args:
            panel_id: Panel UUID.
            conversation_id: Conversation UUID to record results in.
            stimulus_a: First stimulus text.
            stimulus_b: Second stimulus text.
            sample_size: Personas per variant (default: 50).
        """
        body = {
            "stimulus_a": stimulus_a,
            "stimulus_b": stimulus_b,
            "sample_size": sample_size,
        }
        data = self._client._post(
            f"/api/panels/{panel_id}/conversations/{conversation_id}/compare",
            body,
        )
        return CompareResult.from_dict(data)

    def focus_group(self, panel_id: str, conversation_id: str,
                    turn_number: int) -> Dict[str, Any]:
        """Generate a focus group discussion from a completed turn."""
        return self._client._post(
            f"/api/panels/{panel_id}/conversations/{conversation_id}"
            f"/turns/{turn_number}/focus-group",
            {},
        )

    def get_focus_group(self, panel_id: str, conversation_id: str,
                        turn_number: int) -> Dict[str, Any]:
        """Retrieve an existing focus group transcript."""
        return self._client._get(
            f"/api/panels/{panel_id}/conversations/{conversation_id}"
            f"/turns/{turn_number}/focus-group"
        )

    def longitudinal(self, panel_id: str, stimulus: str) -> List[Dict[str, Any]]:
        """Get longitudinal drift data for a stimulus across conversations."""
        return self._client._get(
            f"/api/panels/{panel_id}/longitudinal",
            params={"stimulus": stimulus},
        )

    def cross_panel_compare(
        self,
        panel_ids: List[str],
        stimulus: str,
        *,
        stimulus_type: str = "standard",
        sample_size: int = 0,
    ) -> Dict[str, Any]:
        """Submit the same stimulus to multiple panels for comparison."""
        body = {
            "panel_ids": panel_ids,
            "stimulus": stimulus,
            "stimulus_type": stimulus_type,
            "sample_size": sample_size,
        }
        return self._client._post("/api/compare", body)
