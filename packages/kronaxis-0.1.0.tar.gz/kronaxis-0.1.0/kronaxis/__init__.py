"""
Kronaxis Python SDK — Client for the Panel Studio API.

Usage:
    from kronaxis import KronaxisClient

    client = KronaxisClient(api_key="kx_...", base_url="https://panel.kronaxis.co.uk")

    # List panels
    panels = client.panels.list()

    # Create from description
    job = client.panels.create_from_description(
        "50 middle-income London women aged 30-45",
        country="GB"
    )
    build = client.panels.wait_for_build(job.job_id)

    # Run stimulus
    result = client.conversations.ask(build.panel_id, "Your favourite brand raises prices by 20%. What do you do?")

    # A/B test
    comparison = client.conversations.compare(
        panel_id, conversation_id,
        stimulus_a="Version A text",
        stimulus_b="Version B text"
    )

    # Export
    client.export.jsonl(panel_id, conversation_id, output_path="data.jsonl")

    # Bulk run
    results = client.stimulus.bulk_run(panel_id, conversation_id, [
        "Stimulus 1", "Stimulus 2", "Stimulus 3"
    ])

    # Templates
    templates = client.stimulus.templates()
    filled = client.stimulus.from_template("pricing_test", current_price="9.99", new_price="12.99")
"""

from __future__ import annotations

__version__ = "0.1.0"

from typing import Any, Dict, List, Optional

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from .conversations import ConversationAPI
from .export import ExportAPI
from .models import (
    AskResult,
    BuildJob,
    CompareResult,
    Conversation,
    Panel,
    Persona,
    StimulusTemplate,
    Turn,
)
from .panels import PanelAPI
from .stimulus import StimulusAPI


class KronaxisError(Exception):
    """Base exception for Kronaxis API errors."""

    def __init__(self, message: str, status_code: int = 0,
                 response_body: Optional[Dict[str, Any]] = None) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.response_body = response_body or {}


class KronaxisAuthError(KronaxisError):
    """Raised on 401/403 responses."""
    pass


class KronaxisNotFoundError(KronaxisError):
    """Raised on 404 responses."""
    pass


class KronaxisClient:
    """Client for the Kronaxis Panel Studio API.

    Args:
        api_key: API key (kx_... format) or Panel Studio API key.
        base_url: Base URL of the Panel Studio instance.
        timeout: Default request timeout in seconds.
        max_retries: Number of automatic retries for transient failures.
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://panel.kronaxis.co.uk",
        *,
        timeout: int = 30,
        max_retries: int = 3,
    ) -> None:
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout

        # Configure session with retry logic.
        self._session = requests.Session()
        retry_strategy = Retry(
            total=max_retries,
            backoff_factor=1,
            status_forcelist=[502, 503, 504],
            allowed_methods=["GET", "POST", "PATCH", "DELETE"],
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        self._session.mount("https://", adapter)
        self._session.mount("http://", adapter)

        # Sub-APIs.
        self.panels = PanelAPI(self)
        self.conversations = ConversationAPI(self)
        self.stimulus = StimulusAPI(self)
        self.export = ExportAPI(self)

    def _headers(self) -> Dict[str, str]:
        """Build request headers with authentication.

        Sends both X-API-Key (internal Panel Studio) and X-Kronaxis-Key
        (public standalone repo) for compatibility with both deployment modes.
        """
        return {
            "X-API-Key": self._api_key,
            "X-Kronaxis-Key": self._api_key,
            "Content-Type": "application/json",
            "User-Agent": f"kronaxis-python-sdk/{__version__}",
        }

    @staticmethod
    def _check_response(resp: requests.Response) -> None:
        """Raise appropriate exception for error responses."""
        if resp.status_code < 400:
            return

        try:
            body = resp.json()
        except (ValueError, requests.exceptions.JSONDecodeError):
            body = {"error": resp.text}

        message = body.get("error", f"HTTP {resp.status_code}")

        if resp.status_code in (401, 403):
            raise KronaxisAuthError(message, resp.status_code, body)
        if resp.status_code == 404:
            raise KronaxisNotFoundError(message, resp.status_code, body)
        raise KronaxisError(message, resp.status_code, body)

    def _get(self, path: str, *, params: Optional[Dict[str, Any]] = None) -> Any:
        """Make a GET request and return parsed JSON."""
        resp = self._session.get(
            f"{self._base_url}{path}",
            params=params,
            headers=self._headers(),
            timeout=self._timeout,
        )
        self._check_response(resp)
        return resp.json()

    def _post(self, path: str, body: Dict[str, Any]) -> Any:
        """Make a POST request and return parsed JSON."""
        resp = self._session.post(
            f"{self._base_url}{path}",
            json=body,
            headers=self._headers(),
            timeout=self._timeout,
        )
        self._check_response(resp)
        return resp.json()

    def _patch(self, path: str, body: Dict[str, Any]) -> Any:
        """Make a PATCH request and return parsed JSON."""
        resp = self._session.patch(
            f"{self._base_url}{path}",
            json=body,
            headers=self._headers(),
            timeout=self._timeout,
        )
        self._check_response(resp)
        return resp.json()

    def _delete(self, path: str) -> Any:
        """Make a DELETE request and return parsed JSON."""
        resp = self._session.delete(
            f"{self._base_url}{path}",
            headers=self._headers(),
            timeout=self._timeout,
        )
        self._check_response(resp)
        return resp.json()

    # -----------------------------------------------------------------------
    # Convenience methods (top-level shortcuts)
    # -----------------------------------------------------------------------

    def gpu_status(self) -> Dict[str, Any]:
        """Get Vast.ai GPU status."""
        return self._get("/api/gpu")

    def cost_dashboard(self) -> Dict[str, Any]:
        """Get cost breakdown (LLM + GPU)."""
        return self._get("/api/gpu/cost")

    def unit_economics(self) -> Dict[str, Any]:
        """Get per-response and per-turn cost breakdown."""
        return self._get("/api/costs/unit-economics")

    def life_engine_status(self) -> Dict[str, Any]:
        """Get Life Engine and News Ingester status."""
        return self._get("/api/life-engine/status")

    # -----------------------------------------------------------------------
    # Webhook management
    # -----------------------------------------------------------------------

    def list_webhooks(self) -> List[Dict[str, Any]]:
        """List configured webhooks."""
        return self._get("/api/webhooks")

    def create_webhook(
        self,
        url: str,
        *,
        panel_id: Optional[str] = None,
        events: Optional[List[str]] = None,
        secret: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create a webhook.

        Args:
            url: HTTPS endpoint URL.
            panel_id: Optional panel UUID (null for account-wide).
            events: List of event types to subscribe to.
            secret: Optional HMAC signing secret.
        """
        body: Dict[str, Any] = {"url": url}
        if panel_id:
            body["panel_id"] = panel_id
        if events:
            body["events"] = events
        if secret:
            body["secret"] = secret
        return self._post("/api/webhooks", body)

    def delete_webhook(self, webhook_id: str) -> Dict[str, Any]:
        """Delete a webhook."""
        return self._delete(f"/api/webhooks/{webhook_id}")

    def test_webhook(self, webhook_id: str) -> Dict[str, Any]:
        """Send a test payload to a webhook."""
        return self._post(f"/api/webhooks/{webhook_id}/test", {})
