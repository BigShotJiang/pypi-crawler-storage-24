"""
Kronaxis SDK — Data models.

Lightweight dataclass models for API responses. These provide type hints and
attribute access without requiring Pydantic as a runtime dependency.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional


@dataclass
class Panel:
    """A persona panel."""
    id: str
    name: str
    description: str = ""
    status: str = ""
    persona_count: int = 0
    created_at: Optional[str] = None
    demographics: Optional[Dict[str, Any]] = None
    personas: Optional[List[Dict[str, str]]] = None
    simulation_depth: str = "off"
    simulation_status: Optional[Dict[str, Any]] = None

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> Panel:
        return cls(
            id=str(d.get("id", "")),
            name=d.get("name", ""),
            description=d.get("description", ""),
            status=d.get("status", ""),
            persona_count=d.get("persona_count", 0),
            created_at=d.get("created_at"),
            demographics=d.get("demographics"),
            personas=d.get("personas"),
            simulation_depth=d.get("simulation_depth", "off"),
            simulation_status=d.get("simulation_status"),
        )


@dataclass
class Conversation:
    """A panel conversation."""
    id: str
    panel_id: str
    title: str = ""
    description: str = ""
    turn_count: int = 0
    total_responses: int = 0
    status: str = ""
    created_at: Optional[str] = None
    completed_at: Optional[str] = None
    turns: Optional[List[Dict[str, Any]]] = None

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> Conversation:
        return cls(
            id=str(d.get("id", "")),
            panel_id=str(d.get("panel_id", "")),
            title=d.get("title", ""),
            description=d.get("description", ""),
            turn_count=d.get("turn_count", 0),
            total_responses=d.get("total_responses", 0),
            status=d.get("status", ""),
            created_at=d.get("created_at"),
            completed_at=d.get("completed_at"),
            turns=d.get("turns"),
        )


@dataclass
class Turn:
    """A conversation turn (stimulus + responses)."""
    turn_id: str
    turn_number: int
    run_id: Optional[str] = None
    status: str = ""
    stimulus: str = ""
    response_count: int = 0
    aggregated: Optional[Dict[str, Any]] = None

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> Turn:
        return cls(
            turn_id=str(d.get("turn_id", d.get("id", ""))),
            turn_number=d.get("turn_number", 0),
            run_id=d.get("run_id"),
            status=d.get("status", ""),
            stimulus=d.get("stimulus", ""),
            response_count=d.get("response_count", 0),
            aggregated=d.get("aggregated"),
        )


@dataclass
class AskResult:
    """Result of submitting a stimulus."""
    turn_id: str
    turn_number: int
    run_id: Optional[str] = None
    status: str = ""
    animus_response: Optional[Dict[str, Any]] = None

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> AskResult:
        return cls(
            turn_id=str(d.get("turn_id", "")),
            turn_number=d.get("turn_number", 0),
            run_id=d.get("run_id"),
            status=d.get("status", ""),
            animus_response=d.get("animus_response"),
        )


@dataclass
class CompareResult:
    """Result of an A/B comparison test."""
    stimulus_a: Dict[str, Any] = field(default_factory=dict)
    stimulus_b: Dict[str, Any] = field(default_factory=dict)
    winner: str = ""
    dynamics_breakdown: Optional[Dict[str, Any]] = None

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> CompareResult:
        return cls(
            stimulus_a=d.get("stimulus_a", {}),
            stimulus_b=d.get("stimulus_b", {}),
            winner=d.get("winner", ""),
            dynamics_breakdown=d.get("dynamics_breakdown"),
        )


@dataclass
class BuildJob:
    """A panel build job."""
    job_id: str
    status: str = ""
    spec: Optional[Dict[str, Any]] = None
    panel_id: Optional[str] = None
    progress_current: int = 0
    progress_total: int = 0
    progress_pass: str = ""
    error_message: Optional[str] = None

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> BuildJob:
        return cls(
            job_id=str(d.get("job_id", d.get("id", ""))),
            status=d.get("status", ""),
            spec=d.get("spec"),
            panel_id=str(d["panel_id"]) if d.get("panel_id") else None,
            progress_current=d.get("progress_current", 0),
            progress_total=d.get("progress_total", 0),
            progress_pass=d.get("progress_pass", ""),
            error_message=d.get("error_message"),
        )


@dataclass
class Persona:
    """A persona summary."""
    id: str
    name: str
    age: Optional[int] = None
    occupation: Optional[str] = None
    location: Optional[str] = None
    dynamics: Optional[Dict[str, Any]] = None

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> Persona:
        return cls(
            id=str(d.get("id", "")),
            name=d.get("name", ""),
            age=d.get("age"),
            occupation=d.get("occupation"),
            location=d.get("location"),
            dynamics=d.get("dynamics"),
        )


@dataclass
class StimulusTemplate:
    """A stimulus template."""
    id: str
    name: str
    category: str = ""
    template: str = ""
    variables: Optional[List[str]] = None
    description: str = ""

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> StimulusTemplate:
        return cls(
            id=str(d.get("id", "")),
            name=d.get("name", ""),
            category=d.get("category", ""),
            template=d.get("template", ""),
            variables=d.get("variables"),
            description=d.get("description", ""),
        )
