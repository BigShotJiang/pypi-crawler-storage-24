"""
Kronaxis SDK — Export operations.
"""

from __future__ import annotations

import os
from typing import Any, Dict, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from . import KronaxisClient


class ExportAPI:
    """Data export operations."""

    def __init__(self, client: KronaxisClient) -> None:
        self._client = client

    def jsonl(self, panel_id: str, conversation_id: str,
              output_path: Optional[str] = None) -> str:
        """Export conversation data as JSONL.

        Args:
            panel_id: Panel UUID.
            conversation_id: Conversation UUID.
            output_path: File path to write to. If None, returns content as string.

        Returns:
            File path if output_path given, otherwise the JSONL content string.
        """
        return self._download(panel_id, conversation_id, "jsonl", output_path)

    def jsonl_full(self, panel_id: str, conversation_id: str,
                   output_path: Optional[str] = None) -> str:
        """Export full conversation data as JSONL (includes persona demographics)."""
        return self._download(panel_id, conversation_id, "jsonl_full", output_path)

    def csv(self, panel_id: str, conversation_id: str,
            output_path: Optional[str] = None) -> str:
        """Export conversation data as CSV."""
        return self._download(panel_id, conversation_id, "csv", output_path)

    def parquet(self, panel_id: str, conversation_id: str,
                output_path: Optional[str] = None) -> str:
        """Export conversation data as Parquet."""
        return self._download(panel_id, conversation_id, "parquet", output_path)

    def pptx(self, panel_id: str, conversation_id: str,
             output_path: Optional[str] = None) -> str:
        """Export conversation as a PowerPoint slide deck.

        Args:
            panel_id: Panel UUID.
            conversation_id: Conversation UUID.
            output_path: File path for the .pptx file.

        Returns:
            File path written to.
        """
        return self._download(panel_id, conversation_id, "pptx", output_path)

    def focus_group(self, panel_id: str, conversation_id: str,
                    output_path: Optional[str] = None) -> str:
        """Export focus group transcripts as JSONL."""
        return self._download(panel_id, conversation_id, "focus_group", output_path)

    def training_data(self, conversation_ids: List[str],
                      output_path: Optional[str] = None) -> str:
        """Export training data from multiple conversations as JSONL.

        Args:
            conversation_ids: List of conversation UUIDs.
            output_path: File path to write to.

        Returns:
            File path if output_path given, otherwise the content string.
        """
        resp = self._client._session.post(
            f"{self._client._base_url}/api/export/training-data",
            json={"conversation_ids": conversation_ids},
            headers=self._client._headers(),
            timeout=self._client._timeout,
        )
        self._client._check_response(resp)

        if output_path:
            with open(output_path, "wb") as f:
                f.write(resp.content)
            return output_path
        return resp.text

    def _download(self, panel_id: str, conversation_id: str,
                  fmt: str, output_path: Optional[str] = None) -> str:
        """Download an export file."""
        resp = self._client._session.get(
            f"{self._client._base_url}/api/panels/{panel_id}/conversations/{conversation_id}/export",
            params={"format": fmt},
            headers=self._client._headers(),
            timeout=self._client._timeout,
        )
        self._client._check_response(resp)

        if output_path:
            with open(output_path, "wb") as f:
                f.write(resp.content)
            return output_path
        return resp.text
