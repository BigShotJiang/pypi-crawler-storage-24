"""
Kronaxis SDK — Panel operations.
"""

from __future__ import annotations

import time
from typing import Any, Dict, List, Optional, TYPE_CHECKING

from .models import BuildJob, Panel, Persona

if TYPE_CHECKING:
    from . import KronaxisClient


class PanelAPI:
    """Panel management operations."""

    def __init__(self, client: KronaxisClient) -> None:
        self._client = client

    def list(self) -> List[Panel]:
        """List all panels accessible to the authenticated user."""
        data = self._client._get("/api/panels")
        return [Panel.from_dict(p) for p in data]

    def get(self, panel_id: str) -> Panel:
        """Get panel detail including demographics and persona list."""
        data = self._client._get(f"/api/panels/{panel_id}")
        return Panel.from_dict(data)

    def create(
        self,
        name: str,
        *,
        description: str = "",
        filters: Optional[Dict[str, Any]] = None,
        source_panel: Optional[str] = None,
        persona_ids: Optional[List[str]] = None,
    ) -> Panel:
        """Create a panel from filters or explicit persona IDs.

        Args:
            name: Panel name.
            description: Panel description.
            filters: Filter dict (regions, occupations, age_min, age_max, etc.).
            source_panel: UUID of source panel to sub-select from.
            persona_ids: Explicit list of persona UUIDs.
        """
        body: Dict[str, Any] = {"name": name, "description": description}
        if filters:
            body["filters"] = filters
        if source_panel:
            body["source_panel"] = source_panel
        if persona_ids:
            body["_direct_persona_ids"] = persona_ids
        data = self._client._post("/api/panels", body)
        return Panel.from_dict(data)

    def rename(self, panel_id: str, *, name: Optional[str] = None,
               description: Optional[str] = None) -> Dict[str, Any]:
        """Rename or update description for a panel."""
        body: Dict[str, Any] = {}
        if name:
            body["name"] = name
        if description is not None:
            body["description"] = description
        return self._client._patch(f"/api/panels/{panel_id}", body)

    def filter_options(self, source_panel: Optional[str] = None) -> Dict[str, Any]:
        """Get available filter values for panel creation."""
        params = {}
        if source_panel:
            params["source_panel"] = source_panel
        return self._client._get("/api/panels/filter-options", params=params)

    def preview_filter(self, filters: Dict[str, Any],
                       source_panel: Optional[str] = None) -> Dict[str, Any]:
        """Preview how many personas match given filters."""
        body: Dict[str, Any] = {"filters": filters}
        if source_panel:
            body["source_panel"] = source_panel
        return self._client._post("/api/panels/preview-filter", body)

    def create_from_description(
        self,
        description: str,
        *,
        country: str = "GB",
        simulation_depth: str = "off",
    ) -> BuildJob:
        """Create a panel from a natural language description.

        This is an async operation. Returns a BuildJob with a job_id.
        Use wait_for_build() to poll until completion.

        Args:
            description: Free-form English description of the panel.
            country: 2-letter ISO country code (default: GB).
            simulation_depth: off, fast, or full.
        """
        body = {
            "description": description,
            "country": country,
            "simulation_depth": simulation_depth,
        }
        data = self._client._post("/api/panels/create-from-description", body)
        return BuildJob.from_dict(data)

    def build_status(self, job_id: str) -> BuildJob:
        """Check the status of a panel build job."""
        data = self._client._get(f"/api/build/{job_id}")
        return BuildJob.from_dict(data)

    def wait_for_build(self, job_id: str, *, timeout: int = 600,
                       poll_interval: int = 5) -> BuildJob:
        """Poll a build job until completion or timeout.

        Args:
            job_id: Build job UUID.
            timeout: Maximum seconds to wait (default: 600).
            poll_interval: Seconds between polls (default: 5).

        Returns:
            The completed BuildJob.

        Raises:
            TimeoutError: If the build does not complete within timeout.
            RuntimeError: If the build fails.
        """
        deadline = time.time() + timeout
        while time.time() < deadline:
            job = self.build_status(job_id)
            if job.status == "complete":
                return job
            if job.status == "failed":
                raise RuntimeError(f"Build failed: {job.error_message}")
            time.sleep(poll_interval)
        raise TimeoutError(f"Build {job_id} did not complete within {timeout}s")

    def lookup_persona(self, name: str, *,
                       panel_id: Optional[str] = None) -> Persona:
        """Look up a persona by name."""
        params: Dict[str, str] = {"name": name}
        if panel_id:
            params["panel_id"] = panel_id
        data = self._client._get("/api/personas/lookup", params=params)
        return Persona.from_dict(data)

    def segments(self, panel_id: str) -> List[Dict[str, Any]]:
        """Get DYNAMICS-8 segments for a panel."""
        data = self._client._get(f"/api/panels/{panel_id}/segments")
        return data if isinstance(data, list) else data.get("segments", [])

    def set_simulation(self, panel_id: str, depth: str = "off") -> Dict[str, Any]:
        """Set simulation depth for a Living Panel (off/fast/full)."""
        return self._client._patch(f"/api/panels/{panel_id}/simulation",
                                   {"depth": depth})

    def timeline(self, panel_id: str, **kwargs) -> Dict[str, Any]:
        """Get life event timeline for a panel.

        Keyword args: persona_id, event_type, from, to, page, per_page.
        """
        return self._client._get(f"/api/panels/{panel_id}/timeline", params=kwargs)

    def inject_event(self, panel_id: str, event_type: str, description: str,
                     **kwargs) -> Dict[str, Any]:
        """Inject a life event into panel personas.

        Keyword args: target (all/random/filtered/persona_ids), target_pct,
                      impact, filters, persona_ids.
        """
        body = {"event_type": event_type, "description": description}
        body.update(kwargs)
        return self._client._post(f"/api/panels/{panel_id}/inject-event", body)
