"""
Kronaxis SDK — Stimulus operations (templates and bulk runs).
"""

from __future__ import annotations

import time
from typing import Any, Dict, List, Optional, TYPE_CHECKING

from .models import AskResult, StimulusTemplate

if TYPE_CHECKING:
    from . import KronaxisClient


class StimulusAPI:
    """Stimulus template and bulk submission operations."""

    def __init__(self, client: KronaxisClient) -> None:
        self._client = client

    def templates(self) -> List[StimulusTemplate]:
        """List available stimulus templates."""
        data = self._client._get("/api/stimulus/templates")
        if isinstance(data, list):
            return [StimulusTemplate.from_dict(t) for t in data]
        # If the API returns a dict grouped by category, flatten.
        templates = []
        for category, items in data.items():
            if isinstance(items, list):
                for t in items:
                    t.setdefault("category", category)
                    templates.append(StimulusTemplate.from_dict(t))
        return templates

    def from_template(self, template_id: str, **variables) -> str:
        """Fill a stimulus template with variables and return the text.

        Args:
            template_id: Template identifier.
            **variables: Key-value pairs to substitute into the template.

        Returns:
            The filled stimulus text string.
        """
        body = {"template_id": template_id, "fields": variables}
        data = self._client._post("/api/stimulus/from-template", body)
        return data.get("stimulus", str(data))

    def bulk_run(
        self,
        panel_id: str,
        conversation_id: str,
        stimuli: List[str],
        *,
        stimulus_type: str = "standard",
        sample_size: int = 0,
        wait: bool = True,
        timeout_per_stimulus: int = 300,
        poll_interval: int = 5,
    ) -> List[AskResult]:
        """Submit multiple stimuli sequentially to a conversation.

        Args:
            panel_id: Panel UUID.
            conversation_id: Conversation UUID.
            stimuli: List of stimulus texts.
            stimulus_type: Type of stimulus.
            sample_size: 0 for all, or specific count.
            wait: If True, waits for each stimulus to complete before the next.
            timeout_per_stimulus: Max seconds per stimulus if waiting.
            poll_interval: Poll interval in seconds.

        Returns:
            List of AskResult objects, one per stimulus.
        """
        results = []
        for stimulus in stimuli:
            body = {
                "stimulus": stimulus,
                "stimulus_type": stimulus_type,
                "sample_size": sample_size,
            }
            data = self._client._post(
                f"/api/panels/{panel_id}/conversations/{conversation_id}/ask",
                body,
            )
            result = AskResult.from_dict(data)

            if wait and result.run_id:
                deadline = time.time() + timeout_per_stimulus
                while time.time() < deadline:
                    time.sleep(poll_interval)
                    status = self._client._get(
                        f"/api/panels/{panel_id}/conversations/{conversation_id}/status"
                    )
                    if status.get("status") == "complete":
                        result.status = "complete"
                        break

            results.append(result)

        return results
