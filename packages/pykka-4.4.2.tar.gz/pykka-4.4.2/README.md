# &#x1F300; Pykka

_Pykka makes it easier to build concurrent applications._

[![CI](https://img.shields.io/github/actions/workflow/status/jodal/pykka/ci.yml?branch=main)](https://github.com/jodal/pykka/actions/workflows/ci.yml)
[![Docs](https://img.shields.io/readthedocs/pykka)](https://pykka.readthedocs.io/en/latest/)
[![Coverage](https://img.shields.io/codecov/c/gh/jodal/pykka)](https://codecov.io/gh/jodal/pykka)
[![PyPI](https://img.shields.io/pypi/v/pykka)](https://pypi.org/project/pykka/)

---

Pykka is a Python implementation of the
[actor model](https://en.wikipedia.org/wiki/Actor_model).
The actor model introduces some simple rules to control
the sharing of state and cooperation between execution units,
which makes it easier to build concurrent applications.

## Installation

Pykka has no dependencies other than Python 3.10 or newer.
It can be installed from [PyPI](https://pypi.org/project/pykka/):

```console
$ python3 -m pip install pykka
```

Next up, check out the [documentation](https://pykka.readthedocs.io/).

## Project resources

- [Documentation](https://pykka.readthedocs.io/)
- [Source code](https://github.com/jodal/pykka)
- [Releases](https://github.com/jodal/pykka/releases)
- [Issue tracker](https://github.com/jodal/pykka/issues)
- [Contributors](https://github.com/jodal/pykka/graphs/contributors)
- [Users](https://github.com/jodal/pykka/wiki/Users)

## License

Pykka is copyright 2010-2026 Stein Magnus Jodal and contributors.
Pykka is licensed under the
[Apache License, Version 2.0](https://www.apache.org/licenses/LICENSE-2.0).
