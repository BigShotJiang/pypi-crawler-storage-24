# RentcastMarketStatistics200ResponseSaleDataHistory202408DataByPropertyTypeInner


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**property_type** | **str** |  | [optional] 
**average_price** | **int** |  | [optional] [default to 0]
**median_price** | **int** |  | [optional] [default to 0]
**min_price** | **int** |  | [optional] [default to 0]
**max_price** | **int** |  | [optional] [default to 0]
**average_price_per_square_foot** | **object** |  | [optional] 
**median_price_per_square_foot** | **object** |  | [optional] 
**min_price_per_square_foot** | **object** |  | [optional] 
**max_price_per_square_foot** | **object** |  | [optional] 
**average_square_footage** | **object** |  | [optional] 
**median_square_footage** | **object** |  | [optional] 
**min_square_footage** | **object** |  | [optional] 
**max_square_footage** | **object** |  | [optional] 
**average_days_on_market** | **int** |  | [optional] [default to 0]
**median_days_on_market** | **int** |  | [optional] [default to 0]
**min_days_on_market** | **int** |  | [optional] [default to 0]
**max_days_on_market** | **int** |  | [optional] [default to 0]
**new_listings** | **int** |  | [optional] [default to 0]
**total_listings** | **int** |  | [optional] [default to 0]

## Example

```python
from rentcast_client.models.rentcast_market_statistics200_response_sale_data_history202408_data_by_property_type_inner import RentcastMarketStatistics200ResponseSaleDataHistory202408DataByPropertyTypeInner

# TODO update the JSON string below
json = "{}"
# create an instance of RentcastMarketStatistics200ResponseSaleDataHistory202408DataByPropertyTypeInner from a JSON string
rentcast_market_statistics200_response_sale_data_history202408_data_by_property_type_inner_instance = RentcastMarketStatistics200ResponseSaleDataHistory202408DataByPropertyTypeInner.from_json(json)
# print the JSON string representation of the object
print(RentcastMarketStatistics200ResponseSaleDataHistory202408DataByPropertyTypeInner.to_json())

# convert the object into a dict
rentcast_market_statistics200_response_sale_data_history202408_data_by_property_type_inner_dict = rentcast_market_statistics200_response_sale_data_history202408_data_by_property_type_inner_instance.to_dict()
# create an instance of RentcastMarketStatistics200ResponseSaleDataHistory202408DataByPropertyTypeInner from a dict
rentcast_market_statistics200_response_sale_data_history202408_data_by_property_type_inner_from_dict = RentcastMarketStatistics200ResponseSaleDataHistory202408DataByPropertyTypeInner.from_dict(rentcast_market_statistics200_response_sale_data_history202408_data_by_property_type_inner_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


