from setuptools import setup, find_packages

setup(
    name="rangahub",
    version="0.1.2",
    packages=find_packages(),
 install_requires=[
    "pandas>=1.5",
    "requests>=2.25"
],
    author="Medekunda Siva Rama Krishna S/O M Ranganna ",
    description="Machine Learning Dataset Hub",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
)