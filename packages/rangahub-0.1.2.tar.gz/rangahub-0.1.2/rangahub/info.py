import json
import os

def info(name):

    path = os.path.join(os.path.dirname(__file__), "metadata.json")

    with open(path) as f:
        data = json.load(f)

    return data.get(name, "Dataset not found")