import os
import json
import requests
import pandas as pd

BASE_DIR = os.path.dirname(__file__)
META_PATH = os.path.join(BASE_DIR, "metadata.json")
DATASET_DIR = os.path.join(BASE_DIR, "datasets")

os.makedirs(DATASET_DIR, exist_ok=True)


def load(name):
    with open(META_PATH) as f:
        metadata = json.load(f)

    if name not in metadata:
        raise ValueError(f"{name} dataset not found in rangahub")

    url = metadata[name]["url"]
    file_path = os.path.join(DATASET_DIR, f"{name}.csv")

    if not os.path.exists(file_path):
        print(f"Downloading {name} dataset...")
        r = requests.get(url, timeout=30)
        with open(file_path, "wb") as f:
            f.write(r.content)

    df = pd.read_csv(file_path)
    return df