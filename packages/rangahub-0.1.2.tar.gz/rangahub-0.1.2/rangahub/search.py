import json
import os

def search(keyword):
    path = os.path.join(os.path.dirname(__file__), "metadata.json")

    with open(path) as f:
        data = json.load(f)

    results = []

    for name, info in data.items():
        if keyword.lower() in info["category"].lower():
            results.append(name)

    return results