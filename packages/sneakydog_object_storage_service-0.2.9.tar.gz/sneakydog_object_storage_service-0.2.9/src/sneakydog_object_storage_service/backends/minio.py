from datetime import timedelta
from io import BytesIO
from typing import Dict, Iterator, List, Optional

from minio import Minio
from minio.error import S3Error
from urllib3 import BaseHTTPResponse

from sneakydog_object_storage_service.base import ObjectInfo, StorageBackend, StorageConfig
from sneakydog_object_storage_service.exceptions import (
    ConfigError,
    DownloadError,
    ObjectNotFoundError,
    UploadError,
)


class MinIOStorage(StorageBackend):
    """MinIO/S3 存储 (MinIO SDK 实现)

    Args:
        StorageBackend (_type_): _description_
    """

    def __init__(self, config: StorageConfig) -> None:
        """初始化

        Args:
            config (StorageConfig): _description_

        Raises:
            ConfigError: _description_
        """
        super().__init__(config)
        cfg = config.config

        access_key = cfg.get("access_key")
        secret_key = cfg.get("secret_key")
        endpoint = cfg.get("endpoint")
        secure = cfg.get("secure", True)

        if not access_key or not secret_key:
            raise ConfigError("MinIO requires access_key and secret_key")

        # 创建 MinIO 客户端
        self.client = Minio(
            endpoint=endpoint,
            access_key=access_key,
            secret_key=secret_key,
            secure=secure,
        )

        self.bucket_name = cfg.get("bucket_name")

        # 可选：自动创建 bucket
        if cfg.get("create_bucket_if_not_exists", False):
            if not self.client.bucket_exists(self.bucket_name):
                self.client.make_bucket(self.bucket_name)

    def put_object(
        self,
        key: str,
        bytes_data,
        content_type: Optional[str] = None,
        metadata: Optional[dict[str, str]] = None,
    ) -> bool:
        """上传文件

        Args:
            key (str): _description_
            bytes_data (_type_): _description_
            content_type (Optional[str], optional): _description_. Defaults to None.
            metadata (Optional[dict[str, str]], optional): _description_. Defaults to None.

        Raises:
            UploadError: _description_

        Returns:
            bool: _description_
        """
        try:
            self.client.put_object(
                bucket_name=self.bucket_name,
                object_name=key,
                data=BytesIO(bytes_data),
                length=len(bytes_data),
                content_type=content_type,
                metadata=metadata,
            )
            return True
        except S3Error as e:
            raise UploadError(f"MinIO upload failed: {str(e)}")

    def get_object(self, key: str) -> bytes:
        """下载文件

        Args:
            key (str): _description_

        Raises:
            ObjectNotFoundError: _description_
            DownloadError: _description_

        Returns:
            bytes: _description_
        """
        try:
            response: BaseHTTPResponse = self.client.get_object(self.bucket_name, key)
            with response:
                return response.read()
        except S3Error as e:
            if e.code == "NoSuchKey":
                raise ObjectNotFoundError(f"Object not found: {key}")
            else:
                raise DownloadError(f"MinIO download failed: {str(e)}")

    def get_object_stream(self, key: str, chunk_size: int = 8 * 1024) -> Iterator[bytes]:
        """文件流下载

        Args:
            key (str): _description_
            chunk_size (int, optional): _description_. Defaults to 8*1024.

        Yields:
            Iterator[bytes]: _description_
        """
        response = None
        try:
            response = self.client.get_object(self.bucket_name, key)
            yield from response.stream(chunk_size)
        except S3Error as e:
            if e.code == "NoSuchKey":
                return
            raise
        finally:
            if response:
                response.close()
                response.release_conn()

    def delete(self, key: str) -> bool:
        """删除文件

        Args:
            key (str): _description_

        Raises:
            Exception: _description_

        Returns:
            bool: _description_
        """
        try:
            self.client.remove_object(self.bucket_name, key)
            return True
        except S3Error as e:
            raise Exception(f"MinIO delete failed: {str(e)}")

    def exists(self, key: str) -> bool:
        """检查文件是否存在

        Args:
            key (str): _description_

        Returns:
            bool: _description_
        """
        try:
            self.client.stat_object(self.bucket_name, key)
            return True
        except S3Error:
            return False

    def list_objects(self, prefix: Optional[str] = None, max_keys: int = 1000) -> List[ObjectInfo]:
        """列出对象

        Args:
            prefix (Optional[str], optional): _description_. Defaults to None.
            max_keys (int, optional): _description_. Defaults to 1000.

        Raises:
            Exception: _description_

        Returns:
            List[ObjectInfo]: _description_
        """
        objects = []
        try:
            for obj in self.client.list_objects(
                self.bucket_name, prefix=prefix or "", recursive=True
            ):
                objects.append(
                    ObjectInfo(
                        key=obj.object_name,
                        size=obj.size,
                        last_modified=obj.last_modified,
                        etag=obj.etag,
                        content_type=None,
                    )
                )
                if len(objects) >= max_keys:
                    break
        except S3Error as e:
            raise Exception(f"MinIO list failed: {str(e)}")

        return objects

    def get_object_info(self, key: str) -> ObjectInfo:
        """获取对象元信息

        Args:
            key (str): _description_

        Raises:
            ObjectNotFoundError: _description_
            Exception: _description_

        Returns:
            ObjectInfo: _description_
        """
        try:
            obj_stat = self.client.stat_object(self.bucket_name, key)
            return ObjectInfo(
                key=key,
                size=obj_stat.size,
                last_modified=obj_stat.last_modified,
                etag=obj_stat.etag,
                content_type=obj_stat.content_type,
                metadata=obj_stat.metadata,
            )
        except S3Error as e:
            if e.code == "NoSuchKey":
                raise ObjectNotFoundError(f"Object not found: {key}")
            else:
                raise Exception(f"MinIO stat failed: {str(e)}")

    def presigned_url(self, key: str, expires_in: timedelta = timedelta(days=7)) -> str:
        """生成预签名 URL

        Args:
            key (str): _description_
            expires_in (timedelta, optional): _description_. Defaults to timedelta(days=7).

        Raises:
            Exception: _description_

        Returns:
            str: _description_
        """
        try:
            return self.client.presigned_get_object(self.bucket_name, key, expires=expires_in)
        except S3Error as e:
            raise Exception(f"MinIO presigned URL failed: {str(e)}")

    def initiate_multipart_upload(
        self,
        key: str,
        content_type: Optional[str] = None,
        metadata: Optional[Dict[str, str]] = None,
    ) -> str:
        """初始化分片上传

        Args:
            key (str): _description_
            content_type (Optional[str], optional): _description_. Defaults to None.
            metadata (Optional[Dict[str, str]], optional): _description_. Defaults to None.

        Raises:
            UploadError: _description_

        Returns:
            str: _description_
        """
        try:
            headers = {}
            if content_type:
                headers["content-type"] = content_type
            if metadata:
                headers.update({f"x-amz-meta-{k}": v for k, v in metadata.items()})

            result = self.client._create_multipart_upload(
                bucket_name=self.bucket_name,
                object_name=key,
                headers=headers,
            )
            # _create_multipart_upload 返回 upload_id
            return result if isinstance(result, str) else result.get("upload_id", str(result))
        except S3Error as e:
            raise UploadError(f"MinIO initiate multipart failed: {str(e)}")

    def upload_part(self, key: str, upload_id: str, part_number: int, bytes_data: bytes) -> str:
        """上传单片

        Args:
            key (str): _description_
            upload_id (str): _description_
            part_number (int): _description_
            bytes_data (_type_): _description_

        Raises:
            UploadError: _description_

        Returns:
            str: _description_
        """
        try:
            headers = {}
            etag = self.client._upload_part(
                bucket_name=self.bucket_name,
                object_name=key,
                data=BytesIO(bytes_data),
                headers=headers,
                upload_id=upload_id,
                part_number=part_number,
            )
            # 清理 ETag 格式（可能包含引号）
            etag_str = str(etag).strip('"') if etag else ""
            return etag_str
        except S3Error as e:
            raise UploadError(f"MinIO upload part failed: {str(e)}")

    def complete_multipart_upload(self, key: str, upload_id: str, parts: list) -> str:
        """完成分片上传

        Args:
            key (str): _description_
            upload_id (str): _description_
            parts (list): _description_

        Raises:
            UploadError: _description_

        Returns:
            str: _description_
        """
        try:
            # 处理 parts - 可能是 UploadPart 对象或字典
            parts_list = []
            for p in parts:
                if hasattr(p, "part_number"):  # UploadPart 对象
                    parts_list.append({"PartNumber": p.part_number, "ETag": p.etag})
                else:  # 字典格式
                    parts_list.append({"PartNumber": p["part_number"], "ETag": p["etag"]})

            response = self.client._complete_multipart_upload(
                self.bucket_name,
                object_name=key,
                upload_id=upload_id,
                parts=parts_list,
            )

            # 处理响应中的 ETag
            etag = ""
            if isinstance(response, dict):
                etag = response.get("etag", response.get("ETag", ""))
            elif hasattr(response, "etag"):
                etag = response.etag
            elif isinstance(response, str):
                etag = response
            else:
                etag = str(response)

            # 清理 ETag 格式（可能包含引号）
            etag = str(etag).strip('"') if etag else ""
            return etag
        except S3Error as e:
            raise UploadError(f"MinIO complete multipart failed: {str(e)}")

    def abort_multipart_upload(self, key: str, upload_id: str) -> bool:
        """中止分片上传

        Args:
            key (str): _description_
            upload_id (str): _description_

        Raises:
            Exception: _description_

        Returns:
            bool: _description_
        """
        try:
            self.client._abort_multipart_upload(
                self.bucket_name,
                object_name=key,
                upload_id=upload_id,
            )
            return True
        except S3Error as e:
            raise Exception(f"MinIO abort multipart failed: {str(e)}")
