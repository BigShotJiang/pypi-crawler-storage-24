"""
完整的 FastAPI 分片上传示例应用

使用方法：
    python examples/app_multipart_demo.py

然后访问：
    http://localhost:8000/api/v1/upload/multipart/test
"""

import sys
import traceback
from pathlib import Path
from typing import List, Optional

from fastapi import Depends, FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import HTMLResponse
from pydantic import BaseModel

# 添加项目根目录到路径
sys.path.insert(0, str(Path(__file__).parent.parent))

from sneakydog_object_storage_service.client import OSSClient
from sneakydog_object_storage_service.config import OSSConfig
from sneakydog_object_storage_service.utils.multipart import UploadPart

# ==================== 配置 ====================

config = OSSConfig(
    default_backend="local",
    backends={
        "local": {"type": "local", "root_path": "./storage"},
        "minio": {
            "type": "minio",
            "endpoint": "play.min.io",
            "access_key": "Q3AM3UQ867SPQQA43P2F",
            "secret_key": "zuf+tfteSlswRu7BJ86wekitnifILbZam1KYY3TG",
            "bucket_name": "my-bucket",
            "secure": True,
        },
        "rustfs": {
            "type": "rustfs",
            "endpoint": "play.rustfs.com",
            "access_key": "UBwjyu9XqQZpfA3rFdtL",
            "secret_key": "au8xZjyc5bDUdHL6lVrsSAKMvQGRfJmoO1kqhPW3",
            "bucket_name": "my-bucket",
            "secure": True,
            "create_bucket_if_not_exists": True,
        },
    },
)

sync_client = OSSClient(config=config)

# ==================== 依赖注入 ====================


def get_oss_client():
    return sync_client


# ==================== 数据模型 ====================


class PartInfo(BaseModel):
    part_number: int
    etag: str


class CompleteMultipartRequest(BaseModel):
    upload_id: str
    key: str
    parts: List[PartInfo]


# ==================== FastAPI 应用 ====================

app = FastAPI(title="分片上传 API", description="支持多后端的分片上传服务")


@app.get("/")
async def root():
    return {"message": "欢迎使用分片上传 API", "test_url": "/api/v1/upload/multipart/test"}


# ==================== 分片上传 API ====================


@app.get("/api/v1/upload/multipart/test", response_class=HTMLResponse)
async def test_page():
    """返回前端测试页面"""
    return get_test_html()


@app.post("/api/v1/upload/multipart/init")
async def init_multipart(
    key: str = Form(...),
    content_type: str = Form("application/octet-stream"),
    backend: str = Form("local"),
    oss_client=Depends(get_oss_client),
):
    """
    初始化分片上传

    参数：
    - key: 文件在存储中的键/路径
    - content_type: 文件内容类型
    - backend: 使用的后端 (local/minio/s3)

    返回：
    - upload_id: 分片上传 ID
    """
    try:
        backend_instance = oss_client.get_backend(backend)
        upload_id = backend_instance.initiate_multipart_upload(key=key, content_type=content_type)
        return {"success": True, "upload_id": upload_id, "key": key, "backend": backend}
    except Exception as e:
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))


@app.put("/api/v1/upload/multipart/part/{part_number}")
async def upload_part(
    part_number: int,
    upload_id: str = Form(...),
    key: str = Form(...),
    chunk: UploadFile = File(...),
    backend: str = Form("local"),
    oss_client=Depends(get_oss_client),
):
    """
    上传单个分片

    参数：
    - part_number: 分片编号（从 1 开始）
    - upload_id: 分片上传 ID
    - key: 文件键
    - chunk: 分片数据
    - backend: 使用的后端

    返回：
    - part_number: 分片编号
    - etag: 分片的 ETag
    """
    try:
        backend_instance = oss_client.get_backend(backend)
        content = await chunk.read()

        etag = backend_instance.upload_part(
            key=key, upload_id=upload_id, part_number=part_number, bytes_data=content
        )

        return {"success": True, "part_number": part_number, "etag": etag, "size": len(content)}
    except Exception as e:
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/v1/upload/multipart/complete")
async def complete_multipart(
    upload_id: str = Form(...),
    key: str = Form(...),
    parts_json: str = Form(...),  # JSON 格式的分片列表
    backend: str = Form("local"),
    oss_client=Depends(get_oss_client),
):
    """
    完成分片上传（合并分片）

    参数：
    - upload_id: 分片上传 ID
    - key: 文件键
    - parts_json: JSON 格式的分片信息列表 [{"part_number": 1, "etag": "xxx"}, ...]
    - backend: 使用的后端

    返回：
    - key: 文件键
    - etag: 文件的最终 ETag
    """
    try:
        import json

        backend_instance = oss_client.get_backend(backend)

        # 解析 parts
        parts_data = json.loads(parts_json)
        parts = [
            UploadPart(part_number=p["part_number"], etag=p["etag"], size=p["size"])
            for p in parts_data
        ]

        etag = backend_instance.complete_multipart_upload(key=key, upload_id=upload_id, parts=parts)

        return {"success": True, "key": key, "etag": etag, "message": "分片上传完成"}
    except Exception as e:
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/v1/upload/multipart/abort")
async def abort_multipart(
    upload_id: str = Form(...),
    key: str = Form(...),
    backend: str = Form("local"),
    oss_client=Depends(get_oss_client),
):
    """
    取消/中止分片上传

    参数：
    - upload_id: 分片上传 ID
    - key: 文件键
    - backend: 使用的后端
    """
    try:
        backend_instance = oss_client.get_backend(backend)
        backend_instance.abort_multipart_upload(key=key, upload_id=upload_id)
        return {"success": True, "message": "上传已取消"}
    except Exception as e:
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))


def get_test_html() -> str:
    """生成前端测试页面"""
    return """
    <!DOCTYPE html>
    <html lang="zh-CN">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>分片上传测试 📤</title>
        <style>
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }

            body {
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 20px;
            }

            .container {
                background: white;
                border-radius: 12px;
                box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
                padding: 40px;
                max-width: 600px;
                width: 100%;
            }

            h1 {
                color: #333;
                margin-bottom: 10px;
                text-align: center;
                font-size: 28px;
            }

            .subtitle {
                text-align: center;
                color: #666;
                margin-bottom: 30px;
                font-size: 14px;
            }

            .form-group {
                margin-bottom: 20px;
            }

            label {
                display: block;
                margin-bottom: 8px;
                color: #555;
                font-weight: 500;
            }

            input[type="text"],
            input[type="file"],
            select {
                width: 100%;
                padding: 12px;
                border: 2px solid #e0e0e0;
                border-radius: 6px;
                font-size: 14px;
                transition: border-color 0.3s;
            }

            input[type="text"]:focus,
            input[type="file"]:focus,
            select:focus {
                outline: none;
                border-color: #667eea;
            }

            .button-group {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 10px;
                margin-top: 30px;
            }

            button {
                padding: 12px 20px;
                border: none;
                border-radius: 6px;
                font-size: 14px;
                font-weight: 600;
                cursor: pointer;
                transition: all 0.3s;
            }

            .btn-upload {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                grid-column: span 2;
            }

            .btn-upload:hover:not(:disabled) {
                transform: translateY(-2px);
                box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
            }

            .btn-upload:disabled {
                opacity: 0.5;
                cursor: not-allowed;
                transform: none;
            }

            .btn-cancel {
                background: #f5f5f5;
                color: #333;
            }

            .btn-cancel:hover:not(:disabled) {
                background: #e0e0e0;
            }

            .btn-cancel:disabled {
                opacity: 0.5;
                cursor: not-allowed;
            }

            .progress-section {
                margin-top: 30px;
                display: none;
            }

            .progress-section.active {
                display: block;
            }

            .progress-label {
                margin-bottom: 10px;
                color: #555;
                font-size: 14px;
                display: flex;
                justify-content: space-between;
            }

            .progress-bar {
                width: 100%;
                height: 8px;
                background: #e0e0e0;
                border-radius: 4px;
                overflow: hidden;
            }

            .progress-fill {
                height: 100%;
                background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
                width: 0%;
                transition: width 0.3s;
            }

            .status-message {
                margin-top: 20px;
                padding: 15px;
                border-radius: 6px;
                font-size: 14px;
                display: none;
            }

            .status-message.active {
                display: block;
            }

            .status-message.success {
                background: #e8f5e9;
                color: #2e7d32;
                border: 1px solid #c8e6c9;
            }

            .status-message.error {
                background: #ffebee;
                color: #c62828;
                border: 1px solid #ffcdd2;
            }

            .status-message.info {
                background: #e3f2fd;
                color: #1565c0;
                border: 1px solid #bbdefb;
            }

            .chunk-list {
                margin-top: 15px;
                max-height: 200px;
                overflow-y: auto;
                padding: 10px;
                background: #f9f9f9;
                border-radius: 6px;
                display: none;
            }

            .chunk-list.active {
                display: block;
            }

            .chunk-item {
                padding: 8px 10px;
                margin: 5px 0;
                background: white;
                border-radius: 4px;
                border-left: 3px solid #ddd;
                font-size: 12px;
                color: #666;
            }

            .chunk-item.uploaded {
                border-left-color: #4caf50;
                background: #f1f8e9;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>📤 分片上传测试</h1>
            <p class="subtitle">支持 Local / MinIO / S3 后端</p>

            <div class="form-group">
                <label for="backend">存储后端:</label>
                <select id="backend">
                    <option value="local">本地存储 (Local)</option>
                    <option value="minio">MinIO</option>
                    <option value="rustfs">AWS S3</option>
                </select>
            </div>

            <div class="form-group">
                <label for="fileName">文件名称:</label>
                <input type="text" id="fileName" placeholder="输入保存文件名" value="test-upload.bin">
            </div>

            <div class="form-group">
                <label for="chunkSize">分片大小 (MB):</label>
                <input type="text" id="chunkSize" placeholder="分片大小" value="5">
            </div>

            <div class="form-group">
                <label for="file">选择文件:</label>
                <input type="file" id="file">
            </div>

            <div class="button-group">
                <button class="btn-upload" id="uploadBtn">开始上传</button>
                <button class="btn-cancel" id="cancelBtn" disabled>取消上传</button>
            </div>

            <div class="progress-section" id="progressSection">
                <div class="progress-label">
                    <span>上传进度</span>
                    <span id="progressText">0%</span>
                </div>
                <div class="progress-bar">
                    <div class="progress-fill" id="progressFill"></div>
                </div>
            </div>

            <div class="status-message" id="statusMessage"></div>

            <div class="chunk-list" id="chunkList"></div>
        </div>

        <script>
            const API_BASE = '/api/v1/upload/multipart';

            let uploadState = {
                uploadId: null,
                fileName: null,
                file: null,
                chunks: [],
                uploadedChunks: new Set(),
                isUploading: false
            };

            const elements = {
                backend: document.getElementById('backend'),
                fileName: document.getElementById('fileName'),
                chunkSize: document.getElementById('chunkSize'),
                file: document.getElementById('file'),
                uploadBtn: document.getElementById('uploadBtn'),
                cancelBtn: document.getElementById('cancelBtn'),
                progressSection: document.getElementById('progressSection'),
                progressFill: document.getElementById('progressFill'),
                progressText: document.getElementById('progressText'),
                statusMessage: document.getElementById('statusMessage'),
                chunkList: document.getElementById('chunkList')
            };

            elements.uploadBtn.addEventListener('click', startUpload);
            elements.cancelBtn.addEventListener('click', cancelUpload);

            function showStatus(message, type = 'info') {
                elements.statusMessage.textContent = message;
                elements.statusMessage.className = `status-message active ${type}`;
            }

            function updateProgress() {
                const total = uploadState.chunks.length;
                const uploaded = uploadState.uploadedChunks.size;
                const percent = total > 0 ? Math.round((uploaded / total) * 100) : 0;
                elements.progressFill.style.width = percent + '%';
                elements.progressText.textContent = `${uploaded}/${total} (${percent}%)`;
            }

            function renderChunkList() {
                elements.chunkList.innerHTML = '';
                uploadState.chunks.forEach((chunk, index) => {
                    const isUploaded = uploadState.uploadedChunks.has(index);
                    const item = document.createElement('div');
                    item.className = `chunk-item ${isUploaded ? 'uploaded' : ''}`;
                    item.textContent = `分片 ${index + 1}: ${(chunk.size / 1024 / 1024).toFixed(2)} MB ${isUploaded ? '✓' : '⏳'}`;
                    elements.chunkList.appendChild(item);
                });
            }

            async function startUpload() {
                const file = elements.file.files[0];
                if (!file) {
                    showStatus('请选择文件', 'error');
                    return;
                }

                const fileName = elements.fileName.value || file.name;
                const chunkSizeMB = parseInt(elements.chunkSize.value) || 5;
                const backend = elements.backend.value;

                if (chunkSizeMB < 1) {
                    showStatus('分片大小至少 1 MB', 'error');
                    return;
                }

                const chunkSize = chunkSizeMB * 1024 * 1024;

                uploadState.chunks = [];
                uploadState.uploadedChunks.clear();
                uploadState.file = file;
                uploadState.fileName = fileName;
                uploadState.isUploading = true;

                let offset = 0;
                while (offset < file.size) {
                    const chunk = file.slice(offset, offset + chunkSize);
                    uploadState.chunks.push(chunk);
                    offset += chunkSize;
                }

                elements.uploadBtn.disabled = true;
                elements.cancelBtn.disabled = false;
                elements.progressSection.classList.add('active');
                elements.chunkList.classList.add('active');
                renderChunkList();
                showStatus(`已分片: ${uploadState.chunks.length} 个分片到 ${backend}，准备初始化...`, 'info');

                try {
                    const initFormData = new FormData();
                    initFormData.append('key', fileName);
                    initFormData.append('content_type', file.type || 'application/octet-stream');
                    initFormData.append('backend', backend);

                    const initRes = await fetch(`${API_BASE}/init`, {
                        method: 'POST',
                        body: initFormData
                    });

                    if (!initRes.ok) throw new Error(`初始化失败: ${initRes.status}`);

                    const initData = await initRes.json();
                    uploadState.uploadId = initData.upload_id;
                    showStatus(`初始化成功 | Upload ID: ${initData.upload_id}`, 'info');

                    await uploadAllChunks(backend);
                } catch (error) {
                    showStatus(`错误: ${error.message}`, 'error');
                    uploadState.isUploading = false;
                    elements.uploadBtn.disabled = false;
                    elements.cancelBtn.disabled = true;
                }
            }

            async function uploadAllChunks(backend) {
                for (let i = 0; i < uploadState.chunks.length; i++) {
                    if (!uploadState.isUploading) break;

                    try {
                        const res = await uploadChunk(i, backend);
                        uploadState.uploadedChunks.add(res);
                        updateProgress();
                        renderChunkList();
                    } catch (error) {
                        showStatus(`分片 ${i + 1} 失败: ${error.message}`, 'error');
                    }
                }

                if (!uploadState.isUploading) {
                    showStatus('上传已取消', 'info');
                    elements.uploadBtn.disabled = false;
                    elements.cancelBtn.disabled = true;
                    return;
                }

                await completeUpload(backend);
            }

            async function uploadChunk(index, backend) {
                const chunk = uploadState.chunks[index];
                const formData = new FormData();
                formData.append('upload_id', uploadState.uploadId);
                formData.append('key', uploadState.fileName);
                formData.append('chunk', chunk);
                formData.append('backend', backend);

                const res = await fetch(`${API_BASE}/part/${index + 1}`, {
                    method: 'PUT',
                    body: formData
                });

                if (!res.ok) throw new Error(`HTTP ${res.status}`);
                return res.json();
            }

            async function completeUpload(backend) {
                try {
                    console.log(uploadState.uploadedChunks)
                    const parts = Array.from(uploadState.uploadedChunks).map(i => ({
                        part_number: i.part_number,
                        etag: i.etag,
                        size: i.size
                    }));

                    const formData = new FormData();
                    formData.append('upload_id', uploadState.uploadId);
                    formData.append('key', uploadState.fileName);
                    formData.append('parts_json', JSON.stringify(parts));
                    formData.append('backend', backend);

                    const res = await fetch(`${API_BASE}/complete`, {
                        method: 'POST',
                        body: formData
                    });

                    if (!res.ok) throw new Error(`HTTP ${res.status}`);
                    const data = await res.json();

                    showStatus(`✓ 上传完成！文件: ${data.key}`, 'success');
                    elements.uploadBtn.disabled = false;
                    elements.cancelBtn.disabled = true;
                } catch (error) {
                    showStatus(`完成上传失败: ${error.message}`, 'error');
                    uploadState.isUploading = false;
                    elements.uploadBtn.disabled = false;
                    elements.cancelBtn.disabled = true;
                }
            }

            async function cancelUpload() {
                uploadState.isUploading = false;

                try {
                    const formData = new FormData();
                    formData.append('upload_id', uploadState.uploadId);
                    formData.append('key', uploadState.fileName);
                    formData.append('backend', elements.backend.value);

                    await fetch(`${API_BASE}/abort`, {
                        method: 'POST',
                        body: formData
                    });

                    showStatus('上传已取消', 'info');
                } catch (error) {
                    showStatus(`取消失败: ${error.message}`, 'error');
                }

                elements.uploadBtn.disabled = false;
                elements.cancelBtn.disabled = true;
            }
        </script>
    </body>
    </html>
    """


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)
