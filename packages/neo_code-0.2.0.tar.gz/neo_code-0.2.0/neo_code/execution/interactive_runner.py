"""
InteractiveRunner — manages a long-running Python REPL subprocess.

Listens to:
    event_bus.interactive_mode_toggled      (bool)  — start / stop the REPL
    event_bus.interactive_input_submitted   (str)   — line submitted from terminal

Emits:
    event_bus.stdout_received               (str)   — REPL output
    event_bus.stderr_received               (str)   — REPL errors / tracebacks
    event_bus.interactive_more_input_needed (bool)  — True if block is incomplete
"""

import sys
from pathlib import Path

from PyQt6.QtCore import QObject, QProcess, pyqtSlot

from neo_code.core.event_bus import event_bus

_REPL_HOST = Path(__file__).parent.parent / "data" / "repl_host.py"

_SENTINEL_MORE  = "\x00__REPL_MORE__"
_SENTINEL_READY = "\x00__REPL_READY__"


class InteractiveRunner(QObject):
    def __init__(self) -> None:
        super().__init__()
        self._process: QProcess | None = None

        event_bus.interactive_mode_toggled.connect(self._on_mode_toggled)
        event_bus.interactive_input_submitted.connect(self._on_input)

    # ── Slots ─────────────────────────────────────────────────────────────────

    @pyqtSlot(bool)
    def _on_mode_toggled(self, active: bool) -> None:
        if active:
            self._start_repl()
        else:
            self._stop_repl()

    @pyqtSlot(str)
    def _on_input(self, text: str) -> None:
        if self._process and self._process.state() != QProcess.ProcessState.NotRunning:
            self._process.write((text + "\n").encode())

    # ── Process management ────────────────────────────────────────────────────

    def _start_repl(self) -> None:
        if self._process and self._process.state() != QProcess.ProcessState.NotRunning:
            return
        self._process = QProcess(self)
        self._process.setProcessChannelMode(QProcess.ProcessChannelMode.SeparateChannels)
        self._process.readyReadStandardOutput.connect(self._on_stdout)
        self._process.readyReadStandardError.connect(self._on_stderr)
        self._process.finished.connect(self._on_finished)
        self._process.start(sys.executable, ["-u", str(_REPL_HOST)])

    def _stop_repl(self) -> None:
        proc = self._process
        if not proc:
            return
        self._process = None  # clear first so _on_finished is a no-op if it fires
        if proc.state() != QProcess.ProcessState.NotRunning:
            proc.closeWriteChannel()
            proc.waitForFinished(500)
            if proc.state() != QProcess.ProcessState.NotRunning:
                proc.kill()
                proc.waitForFinished(500)

    # ── Process callbacks ─────────────────────────────────────────────────────

    @pyqtSlot()
    def _on_stdout(self) -> None:
        if self._process is None:
            return
        while self._process.canReadLine():
            line = (
                bytes(self._process.readLine())
                .decode("utf-8", errors="replace")
                .rstrip("\r\n")
            )
            if line == _SENTINEL_MORE:
                event_bus.interactive_more_input_needed.emit(True)
            elif line == _SENTINEL_READY:
                event_bus.interactive_more_input_needed.emit(False)
            else:
                event_bus.stdout_received.emit(line)

    @pyqtSlot()
    def _on_stderr(self) -> None:
        if self._process is None:
            return
        data = bytes(self._process.readAllStandardError()).decode("utf-8", errors="replace")
        for line in data.splitlines():
            event_bus.stderr_received.emit(line)

    @pyqtSlot(int, QProcess.ExitStatus)
    def _on_finished(self, _exit_code: int, _status) -> None:
        self._process = None
