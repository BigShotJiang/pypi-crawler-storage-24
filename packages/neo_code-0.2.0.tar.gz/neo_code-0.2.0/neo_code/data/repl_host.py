"""
REPL host — launched as a subprocess by InteractiveRunner.

Reads one line at a time from stdin, feeds it to a
code.InteractiveConsole, and writes a sentinel to stdout after each
statement so the host process knows whether more input is required:

  \x00__REPL_MORE__   — block is incomplete, show "..." prompt
  \x00__REPL_READY__  — statement executed, show ">>>" prompt

All actual interpreter output (print, repr, tracebacks) goes through
the normal stdout / stderr channels.
"""

import sys
import code


class _REPLConsole(code.InteractiveConsole):
    """Redirect InteractiveConsole.write() to stderr (tracebacks, etc.)."""

    def write(self, data: str) -> None:
        sys.stderr.write(data)
        sys.stderr.flush()


console = _REPLConsole(locals={"__name__": "__main__"})

for raw_line in sys.stdin:
    line = raw_line.rstrip("\n")
    more = console.push(line)
    sys.stdout.flush()
    sys.stderr.flush()
    if more:
        sys.stdout.write("\x00__REPL_MORE__\n")
    else:
        sys.stdout.write("\x00__REPL_READY__\n")
    sys.stdout.flush()
