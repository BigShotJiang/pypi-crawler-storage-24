"""
Terminal panel — read-only output console with "Output" header.

Connects to:
  event_bus.stdout_received  — appends plain text
  event_bus.stderr_received  — appends text in red
  event_bus.execution_started — clears the terminal
"""

from PyQt6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPlainTextEdit, QFrame, QToolButton, QSizePolicy, QLineEdit
from PyQt6.QtGui import QColor, QTextCursor, QTextCharFormat, QFont
from PyQt6.QtCore import pyqtSlot, Qt

from neo_code.core.event_bus import event_bus
from neo_code.theme.colors import colors


class TerminalPanel(QWidget):
    """Container: header bar titled 'Output' + read-only text view below
    + collapsible REPL input bar for interactive mode."""

    def __init__(self) -> None:
        super().__init__()
        self._interactive_more = False  # True when REPL expects continuation (...)
        self._build_ui()
        self._connect_signals()

    # ── Build ─────────────────────────────────────────────────────────────────

    _HEADER_H = 28  # px — always visible
    _INPUT_H  = 34  # px — input bar height

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # ── Header (always visible) ────────────────────────────────────────
        header = QWidget()
        header.setFixedHeight(self._HEADER_H)
        header.setStyleSheet(
            f"background-color: {colors.panel_header_bg};"
            f"border-top: 1px solid {colors.border};"
        )
        header_layout = QHBoxLayout(header)
        header_layout.setContentsMargins(10, 0, 4, 0)
        header_layout.setSpacing(0)

        self._title_label = QLabel("Output")
        title_font = QFont()
        title_font.setPointSize(9)
        title_font.setBold(True)
        self._title_label.setFont(title_font)
        self._title_label.setStyleSheet(f"color: {colors.text_secondary};")
        header_layout.addWidget(self._title_label)
        header_layout.addStretch()

        # Toggle button — far right of header
        self._toggle_btn = QToolButton()
        self._toggle_btn.setText("▾")
        self._toggle_btn.setToolTip("Hide output panel")
        self._toggle_btn.setFixedSize(22, 22)
        self._toggle_btn.setStyleSheet(f"""
            QToolButton {{
                color: {colors.text_secondary};
                border: none;
                border-radius: 3px;
                font-size: 13px;
            }}
            QToolButton:hover {{
                background-color: {colors.border};
            }}
        """)
        self._toggle_btn.clicked.connect(self._toggle_view)
        header_layout.addWidget(self._toggle_btn)

        layout.addWidget(header)

        # ── Text view ─────────────────────────────────────────────────────
        self._view = _OutputView()
        layout.addWidget(self._view)

        # ── REPL input bar (hidden until interactive mode is active) ──────
        self._input_bar = self._build_input_bar()
        self._input_bar.setVisible(False)
        layout.addWidget(self._input_bar)

        # The header must always be reachable; cap minimum height at header only.
        self.setMinimumHeight(self._HEADER_H)

    def _build_input_bar(self) -> QWidget:
        bar = QWidget()
        bar.setFixedHeight(self._INPUT_H)
        bar.setStyleSheet(
            f"background-color: {colors.terminal_bg};"
            f"border-top: 1px solid {colors.border};"
        )
        layout = QHBoxLayout(bar)
        layout.setContentsMargins(8, 4, 8, 4)
        layout.setSpacing(6)

        self._prompt_label = QLabel(">>>")
        self._prompt_label.setFixedWidth(28)
        prompt_font = QFont("Monospace", 11)
        prompt_font.setStyleHint(QFont.StyleHint.Monospace)
        prompt_font.setBold(True)
        self._prompt_label.setFont(prompt_font)
        self._prompt_label.setStyleSheet(f"color: {colors.primary}; background: transparent;")
        layout.addWidget(self._prompt_label)

        self._input_field = QLineEdit()
        self._input_field.setPlaceholderText("Type a Python expression and press Enter…")
        self._input_field.setFont(QFont("Monospace", 11))
        self._input_field.setStyleSheet(f"""
            QLineEdit {{
                background-color: {colors.terminal_bg};
                color: {colors.terminal_text};
                border: none;
                selection-background-color: {colors.editor_selection};
            }}
        """)
        self._input_field.returnPressed.connect(self._on_input_submitted)
        layout.addWidget(self._input_field)

        return bar

    # ── Toggle ────────────────────────────────────────────────────────────────

    def _toggle_view(self) -> None:
        if self._view.isVisible():
            self._view.setVisible(False)
            # Snap the panel to just the header height so the splitter contracts.
            self.setFixedHeight(self._HEADER_H)
            self._toggle_btn.setText("▸")
            self._toggle_btn.setToolTip("Show output panel")
        else:
            self._view.setVisible(True)
            # Release the fixed height so the splitter can resize freely again.
            self.setMinimumHeight(self._HEADER_H)
            self.setMaximumHeight(16_777_215)  # Qt QWIDGETSIZE_MAX
            self._toggle_btn.setText("▾")
            self._toggle_btn.setToolTip("Hide output panel")

    # ── Signals ───────────────────────────────────────────────────────────────

    def _connect_signals(self) -> None:
        event_bus.execution_started.connect(self._view.clear)
        event_bus.stdout_received.connect(self._view.append_stdout)
        event_bus.stderr_received.connect(self._view.append_stderr)
        event_bus.interactive_mode_toggled.connect(self._on_interactive_mode_toggled)
        event_bus.interactive_more_input_needed.connect(self._on_more_input_needed)

    # ── Interactive mode ──────────────────────────────────────────────────────

    @pyqtSlot(bool)
    def _on_interactive_mode_toggled(self, active: bool) -> None:
        self._interactive_more = False
        if active:
            self._title_label.setText("Interactive")
            self._title_label.setStyleSheet(f"color: {colors.primary};")
            self._input_bar.setVisible(True)
            self._view.clear()
            self._view.append_stdout("Python interactive REPL — type expressions and press Enter.")
            self._input_field.setFocus()
        else:
            self._title_label.setText("Output")
            self._title_label.setStyleSheet(f"color: {colors.text_secondary};")
            self._input_bar.setVisible(False)
            self._prompt_label.setText(">>>")

    @pyqtSlot(bool)
    def _on_more_input_needed(self, more: bool) -> None:
        self._interactive_more = more
        self._prompt_label.setText("..." if more else ">>>")

    @pyqtSlot()
    def _on_input_submitted(self) -> None:
        text = self._input_field.text()
        self._input_field.clear()
        prompt = "..." if self._interactive_more else ">>>"
        self._view.append_input(f"{prompt} {text}")
        event_bus.interactive_input_submitted.emit(text)


class _OutputView(QPlainTextEdit):
    """The actual read-only text area inside the terminal panel."""

    def __init__(self) -> None:
        super().__init__()
        self._fmt_stdout = self._make_fmt(colors.terminal_text)
        self._fmt_stderr = self._make_fmt(colors.terminal_error)
        self._fmt_input  = self._make_fmt(colors.primary_dim)

        self.setReadOnly(True)
        self.setMaximumBlockCount(2000)
        font = QFont("Monospace", 12)
        font.setStyleHint(QFont.StyleHint.Monospace)
        self.setFont(font)
        self.setStyleSheet(f"""
            QPlainTextEdit {{
                background-color: {colors.terminal_bg};
                color: {colors.terminal_text};
                border: none;
                padding: 4px;
            }}
        """)

    @staticmethod
    def _make_fmt(color: str) -> QTextCharFormat:
        fmt = QTextCharFormat()
        fmt.setForeground(QColor(color))
        return fmt

    @pyqtSlot(str)
    def append_stdout(self, text: str) -> None:
        self._append(text, self._fmt_stdout)

    @pyqtSlot(str)
    def append_stderr(self, text: str) -> None:
        self._append(text, self._fmt_stderr)

    def append_input(self, text: str) -> None:
        """Echo a REPL input line (>>> / ... prefix included)."""
        self._append(text, self._fmt_input)

    def _append(self, text: str, fmt: QTextCharFormat) -> None:
        cursor = self.textCursor()
        cursor.movePosition(QTextCursor.MoveOperation.End)
        cursor.insertText(text + "\n", fmt)
        self.setTextCursor(cursor)
        self.ensureCursorVisible()
