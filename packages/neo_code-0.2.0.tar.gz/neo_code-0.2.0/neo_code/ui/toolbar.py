"""
Toolbar — QToolBar with Run / Stop / New / Open / Save actions.

Connects to EventBus signals for execution state changes.
"""

from PyQt6.QtWidgets import QToolBar, QWidget, QToolButton, QSizePolicy
from PyQt6.QtGui import QAction

from neo_code.core.event_bus import event_bus
from neo_code.theme.colors import colors

_TOOLBAR_STYLE = f"""
    QToolBar {{
        background-color: {colors.toolbar_bg};
        border-bottom: 1px solid {colors.toolbar_border};
        spacing: 4px;
        padding: 4px 8px;
    }}
    QToolButton {{
        background: transparent;
        color: {colors.text};
        border: none;
        padding: 4px 10px;
        border-radius: 4px;
    }}
    QToolButton:hover {{
        background-color: {colors.surface_alt};
    }}
    QToolButton[text="▶  Run"] {{
        background-color: {colors.run_bg};
        color: {colors.run_text};
        font-weight: bold;
        border-radius: 4px;
        padding: 4px 14px;
    }}
    QToolButton[text="▶  Run"]:hover {{
        background-color: {colors.run_bg_hover};
    }}
    QToolButton[text="■  Stop"] {{
        background-color: {colors.stop_bg};
        color: {colors.stop_text};
        font-weight: bold;
        border-radius: 4px;
        padding: 4px 14px;
    }}
    QToolButton[text="■  Stop"]:hover {{
        background-color: {colors.stop_bg_hover};
    }}
    QToolButton:disabled {{
        color: {colors.text_disabled};
    }}
    QToolButton#interactiveBtn {{
        border: 1px solid {colors.border};
        border-radius: 4px;
        padding: 4px 12px;
        font-weight: 500;
    }}
    QToolButton#interactiveBtn:checked {{
        background-color: {colors.primary};
        color: {colors.primary_text};
        border-color: {colors.primary};
        font-weight: bold;
    }}
    QToolButton#interactiveBtn:hover:!checked {{
        background-color: {colors.surface_alt};
    }}
"""


class Toolbar(QToolBar):
    def __init__(self, get_code_fn) -> None:
        super().__init__()
        self._get_code = get_code_fn
        self.setMovable(False)
        self._build_actions()
        self._connect_signals()

    # ── Build ─────────────────────────────────────────────────────────────────

    def _build_actions(self) -> None:
        self.setStyleSheet(_TOOLBAR_STYLE)
        self._act_new = QAction("New", self)
        self._act_new.setShortcut("Ctrl+N")
        self._act_new.triggered.connect(lambda: event_bus.file_new.emit())
        self.addAction(self._act_new)

        self._act_open = QAction("Open", self)
        self._act_open.setShortcut("Ctrl+O")
        self._act_open.triggered.connect(
            lambda: event_bus.open_file_dialog_requested.emit()
        )
        self.addAction(self._act_open)

        self._act_save = QAction("Save", self)
        self._act_save.setShortcut("Ctrl+S")
        self._act_save.triggered.connect(
            lambda: event_bus.save_file_dialog_requested.emit()
        )
        self.addAction(self._act_save)

        self.addSeparator()

        self._act_run = QAction("▶  Run", self)
        self._act_run.setShortcut("F5")
        self._act_run.triggered.connect(self._on_run)
        self.addAction(self._act_run)

        self._act_stop = QAction("■  Stop", self)
        self._act_stop.setShortcut("F6")
        self._act_stop.setEnabled(False)
        self._act_stop.triggered.connect(
            lambda: event_bus.execution_stop_requested.emit()
        )
        self.addAction(self._act_stop)

        # ── Interactive toggle — far right ─────────────────────────────────
        spacer = QWidget()
        spacer.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        self.addWidget(spacer)

        self._act_interactive = QAction("⚡ Interactive", self)
        self._act_interactive.setCheckable(True)
        self._act_interactive.setShortcut("F7")
        self._act_interactive.setToolTip("Toggle interactive Python REPL (F7)")

        self._btn_interactive = QToolButton()
        self._btn_interactive.setDefaultAction(self._act_interactive)
        self._btn_interactive.setObjectName("interactiveBtn")
        self._act_interactive.triggered.connect(self._on_interactive_toggled)
        self.addWidget(self._btn_interactive)

    # ── Signals ───────────────────────────────────────────────────────────────

    def _connect_signals(self) -> None:
        event_bus.execution_started.connect(self._on_execution_started)
        event_bus.execution_finished.connect(self._on_execution_finished)

    # ── Handlers ──────────────────────────────────────────────────────────────

    def _on_run(self) -> None:
        event_bus.execution_requested.emit(self._get_code())

    def _on_execution_started(self) -> None:
        self._act_run.setEnabled(False)
        self._act_stop.setEnabled(True)

    def _on_execution_finished(self, _exit_code: int) -> None:
        self._act_run.setEnabled(True)
        self._act_stop.setEnabled(False)

    def _on_interactive_toggled(self, checked: bool) -> None:
        event_bus.interactive_mode_toggled.emit(checked)
        # Disable script run/stop while REPL is active to avoid process conflicts
        self._act_run.setEnabled(not checked)
        self._act_stop.setEnabled(False)
