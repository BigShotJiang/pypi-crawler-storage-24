"""
EventBus — singleton QObject with typed Qt signals.

All inter-component communication goes through this object.
No component should call another component directly to trigger behaviour.

Usage:
    from neo_code.core.event_bus import event_bus

    # Connect
    event_bus.file_opened.connect(my_slot)

    # Emit
    event_bus.file_opened.emit(path, content)
"""

from PyQt6.QtCore import QObject, pyqtSignal


class EventBus(QObject):

    # ── File lifecycle ─────────────────────────────────────────────────────
    file_new = pyqtSignal()                     # new blank file requested
    file_opened = pyqtSignal(str, str)          # (path, content)
    file_saved = pyqtSignal(str)                # (path,)

    # ── Code / Editor ──────────────────────────────────────────────────────
    code_changed = pyqtSignal(str)              # (code,)  debounced

    # ── Execution ──────────────────────────────────────────────────────────
    execution_requested = pyqtSignal(str)       # (code,)
    execution_stop_requested = pyqtSignal()
    execution_started = pyqtSignal()
    execution_finished = pyqtSignal(int)        # (exit_code,)

    # ── Subprocess output ──────────────────────────────────────────────────
    stdout_received = pyqtSignal(str)           # (text,)
    stderr_received = pyqtSignal(str)           # (text,)
    canvas_command = pyqtSignal(dict)           # (cmd dict)  e.g. {"cmd":"forward","args":[100]}

    # ── Curriculum ─────────────────────────────────────────────────────────
    project_opened = pyqtSignal(object)         # (Project,)

    # ── Interactive REPL mode ──────────────────────────────────────────────
    interactive_mode_toggled       = pyqtSignal(bool)  # True = entered, False = exited
    interactive_input_submitted    = pyqtSignal(str)   # line of code from user
    interactive_more_input_needed  = pyqtSignal(bool)  # True = block incomplete (show ...)

    # ── UI dialogs (toolbar → main_window) ────────────────────────────────
    open_file_dialog_requested = pyqtSignal()
    save_file_dialog_requested = pyqtSignal()


# Module-level singleton — import this everywhere
event_bus = EventBus()
