from os import path

from rinoh.font import Typeface
from rinoh.font.style import REGULAR, BOLD, ITALIC, FontWidth
from rinoh.font.opentype import OpenTypeFont


__all__ = ['typeface']


def otf(style, **kwargs):
    filename = 'LiberationSansNarrow{}.ttf'.format(style)
    return OpenTypeFont(path.join(path.dirname(__file__), filename), **kwargs)


typeface = Typeface('Liberation Sans Narrow',
                    otf('-Regular', weight=REGULAR),
                    otf('-Italic', weight=REGULAR, slant=ITALIC),
                    otf('-Bold', weight=BOLD),
                    otf('-BoldItalic', weight=BOLD, slant=ITALIC))
