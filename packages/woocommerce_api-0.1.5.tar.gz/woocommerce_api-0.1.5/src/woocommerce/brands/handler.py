from typing import Optional, Union
import requests

from woocommerce.brands.models.brand_create import BrandCreate

class BrandHandler:

    def __init__(self, woocommerce_base_url: str, woocommerce_auth: tuple[str]):
        """Class to handle category's operations

        Args:
            woocommerce_base_url (str): The base URL of your woocommerce instance www.<...>.com. Do not add the /wp-json/...
            woocommerce_auth (tuple[str]): A tuple with auth key from woocommerce in the type (ck_...,cs_...)
        """
        self.woocommerce_url = woocommerce_base_url
        self.formatted_url = f'{self.woocommerce_url}/wp-json/wc/v3/products/brands'
        self.auth = woocommerce_auth

    def retrieve_brands(self) -> list[dict]:
        res = requests.get(
            url=self.formatted_url,
            auth=self.auth
        )
        return res.json()
    
    def retrieve_single_brand(self, brand: Union[str, int]) -> dict:
        res = requests.get(
            url=f'{self.formatted_url}/{brand}',
        )
        return res.json()
    
    def create_brand(self, brand_reate: BrandCreate) -> dict:
        res = requests.post(
            url=self.formatted_url,
            auth=self.auth,
            data=brand_reate
        )
        return res.json()
    
    def delete_brand(self, id: int, force: bool = False) -> dict:
        res = requests.delete(
            url=f'{self.formatted_url}/{id}',
            auth=self.auth,
            params={"force":force}
        )
        return res.json()
    
    def assign_brand_to_product(self, product_id: int, brands_id: list[int]) -> dict:
        res = requests.put(
            url=f'{self.woocommerce_url}//wp-json/wc/v3/products/{product_id}',
            auth=self.auth,
            data={
                "brands":brands_id
            }
        )
        return res.json()
    
    def batch_update(self, create: Optional[list[dict]] = None, update: Optional[list[dict]] = None, delete: Optional[list[int]] = None):
        d = {}
        if create:
            d["create"] = create
        if update:
            d["update"] = update
        if delete:
            d["delete"] = delete
        res = requests.post(
            url=f'{self.formatted_url}/batch',
            auth=self.auth,
            json=d
        )
        return res.json()
       