# app/core/brokers/postgres.py
from __future__ import annotations
import uuid, asyncio, hashlib, contextlib, threading
from typing import Any, Optional, TYPE_CHECKING
from datetime import datetime, timedelta, timezone
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker
from sqlalchemy import text, select
from sqlalchemy.dialects.postgresql import insert as pg_insert
from horsies.core.brokers.listener import PostgresListener
from horsies.core.brokers.result_types import (
    BrokerErrorCode,
    BrokerOperationError,
    BrokerResult,
)
from horsies.core.models.broker import PostgresConfig
from horsies.core.models.task_pg import TaskModel, Base
from horsies.core.models.workflow_pg import (
    WorkflowModel as _WorkflowModel,
    WorkflowTaskModel as _WorkflowTaskModel,
)
from horsies.core.types.status import TaskStatus, TaskAttemptOutcome
from horsies.core.types.result import Err, Ok, is_err
from horsies.core.codec.serde import (
    loads_json,
    task_result_from_json,
)
from horsies.core.models.tasks import TaskInfo, TaskAttemptInfo
from horsies.core.utils.db import is_retryable_connection_error
from horsies.core.utils.loop_runner import LoopRunner
from horsies.core.utils.url import to_psycopg_url

if TYPE_CHECKING:
    from horsies.core.app import Horsies
from horsies.core.logging import get_logger

if TYPE_CHECKING:
    from horsies.core.models.tasks import TaskResult, TaskError

# Ensure workflow tables are registered in SQLAlchemy metadata.
_ = (_WorkflowModel, _WorkflowTaskModel)


def _broker_err(
    code: BrokerErrorCode,
    message: str,
    exc: BaseException,
) -> Err[BrokerOperationError]:
    """Build an Err with retryable classification from the raw exception."""
    return Err(BrokerOperationError(
        code=code,
        message=message,
        retryable=is_retryable_connection_error(exc),
        exception=exc,
    ))


# ---- Schema DDL (triggers, indexes, migrations) ----
from horsies.core.schemas.triggers import (
    CREATE_TASK_NOTIFY_FUNCTION_SQL,
    CREATE_TASK_NOTIFY_TRIGGER_SQL,
    CREATE_TASK_STATUS_NOTIFY_FUNCTION_SQL,
    CREATE_TASK_STATUS_NOTIFY_TRIGGER_SQL,
    CREATE_WORKER_STATE_NOTIFY_FUNCTION_SQL,
    CREATE_WORKER_STATE_NOTIFY_TRIGGER_SQL,
    CREATE_WORKFLOW_NOTIFY_FUNCTION_SQL,
    CREATE_WORKFLOW_NOTIFY_TRIGGER_SQL,
    CREATE_WORKFLOW_STATUS_NOTIFY_FUNCTION_SQL,
    CREATE_WORKFLOW_STATUS_NOTIFY_TRIGGER_SQL,
)
from horsies.core.worker.sql import UPSERT_TASK_ATTEMPT_SQL
from horsies.core.schemas.indexes import (
    CREATE_HEARTBEATS_TASK_ROLE_SENT_INDEX_SQL,
    CREATE_TASK_ATTEMPTS_ERROR_CODE_INDEX_SQL,
    CREATE_TASK_ATTEMPTS_FINISHED_AT_INDEX_SQL,
    CREATE_TASKS_ERROR_CODE_INDEX_SQL,
    CREATE_WORKFLOW_TASKS_DEPS_INDEX_SQL,
)
from horsies.core.schemas.migrations import (
    CREATE_TASK_ATTEMPTS_TABLE_SQL,
    ADD_DEPTH_COLUMN_SQL,
    ADD_ENQUEUE_SHA_COLUMN_SQL,
    ADD_ENQUEUED_AT_COLUMN_SQL,
    ADD_ERROR_CODE_COLUMN_SQL,
    ADD_IS_SUBWORKFLOW_COLUMN_SQL,
    ADD_JOIN_TYPE_COLUMN_SQL,
    ADD_MIN_SUCCESS_COLUMN_SQL,
    ADD_NODE_ID_COLUMN_SQL,
    ADD_PARENT_TASK_INDEX_COLUMN_SQL,
    ADD_PARENT_WORKFLOW_ID_COLUMN_SQL,
    ADD_ROOT_WORKFLOW_ID_COLUMN_SQL,
    ADD_SUB_WORKFLOW_ID_COLUMN_SQL,
    ADD_SUB_WORKFLOW_MODULE_COLUMN_SQL,
    ADD_SUB_WORKFLOW_NAME_COLUMN_SQL,
    ADD_SUB_WORKFLOW_QUALNAME_COLUMN_SQL,
    ADD_SUB_WORKFLOW_SUMMARY_COLUMN_SQL,
    ADD_SUCCESS_POLICY_COLUMN_SQL,
    ADD_TASK_OPTIONS_COLUMN_SQL,
    ADD_WORKFLOW_DEF_MODULE_COLUMN_SQL,
    ADD_WORKFLOW_DEF_QUALNAME_COLUMN_SQL,
    ADD_WORKFLOW_SENT_AT_COLUMN_SQL,
    BACKFILL_ENQUEUE_SHA_SQL,
    BACKFILL_ENQUEUED_AT_SQL,
    BACKFILL_WORKFLOW_SENT_AT_SQL,
    DROP_SUB_WORKFLOW_RETRY_MODE_COLUMN_SQL,
    SCHEMA_ADVISORY_LOCK_SQL,
    SET_ENQUEUE_SHA_NOT_NULL_SQL,
    SET_ENQUEUED_AT_DEFAULT_SQL,
    SET_ENQUEUED_AT_NOT_NULL_SQL,
    SET_TASK_COLUMN_DEFAULTS_SQL,
    SET_WORKFLOW_SENT_AT_DEFAULT_SQL,
    SET_WORKFLOW_SENT_AT_NOT_NULL_SQL,
)

# ---- Monitoring queries ----

GET_STALE_TASKS_SQL = text("""
    SELECT
        t.id,
        t.worker_hostname,
        t.worker_pid,
        t.worker_process_name,
        hb.last_heartbeat,
        t.started_at,
        t.task_name
    FROM horsies_tasks t
    LEFT JOIN LATERAL (
        SELECT sent_at AS last_heartbeat
        FROM horsies_heartbeats h
        WHERE h.task_id = t.id AND h.role = 'runner'
        ORDER BY sent_at DESC
        LIMIT 1
    ) hb ON TRUE
    WHERE t.status = 'RUNNING'
      AND t.started_at IS NOT NULL
      AND COALESCE(hb.last_heartbeat, t.started_at) < NOW() - CAST(:stale_threshold || ' minutes' AS INTERVAL)
    ORDER BY hb.last_heartbeat NULLS FIRST
""")

GET_WORKER_STATS_SQL = text("""
    SELECT
        t.worker_hostname,
        t.worker_pid,
        t.worker_process_name,
        COUNT(*) AS active_tasks,
        MIN(t.started_at) AS oldest_task_start,
        MAX(hb.last_heartbeat) AS latest_heartbeat
    FROM horsies_tasks t
    LEFT JOIN LATERAL (
        SELECT sent_at AS last_heartbeat
        FROM horsies_heartbeats h
        WHERE h.task_id = t.id AND h.role = 'runner'
        ORDER BY sent_at DESC
        LIMIT 1
    ) hb ON TRUE
    WHERE t.status = 'RUNNING'
      AND t.worker_hostname IS NOT NULL
    GROUP BY t.worker_hostname, t.worker_pid, t.worker_process_name
    ORDER BY active_tasks DESC
""")

GET_EXPIRED_TASKS_SQL = text("""
    SELECT
        id,
        task_name,
        queue_name,
        priority,
        sent_at,
        enqueued_at,
        good_until,
        NOW() - good_until as expired_for
    FROM horsies_tasks
    WHERE status = 'PENDING'
      AND good_until < NOW()
    ORDER BY good_until ASC
""")

# ---- Cleanup queries ----

SELECT_STALE_RUNNING_TASKS_SQL = text("""
    SELECT t2.id, t2.worker_pid, t2.worker_hostname, t2.claimed_by_worker_id,
           t2.started_at, hb.last_heartbeat,
           t2.retry_count, t2.worker_process_name
    FROM horsies_tasks t2
    LEFT JOIN LATERAL (
        SELECT sent_at AS last_heartbeat
        FROM horsies_heartbeats h
        WHERE h.task_id = t2.id AND h.role = 'runner'
        ORDER BY sent_at DESC
        LIMIT 1
    ) hb ON TRUE
    WHERE t2.status = 'RUNNING'
      AND t2.started_at IS NOT NULL
      AND COALESCE(hb.last_heartbeat, t2.started_at) < NOW() - CAST(:stale_threshold || ' seconds' AS INTERVAL)
    FOR UPDATE OF t2 SKIP LOCKED
""")

MARK_STALE_TASK_FAILED_SQL = text("""
    UPDATE horsies_tasks
    SET status = 'FAILED',
        failed_at = NOW(),
        failed_reason = :failed_reason,
        result = :result,
        error_code = :error_code,
        updated_at = NOW()
    WHERE id = :task_id
      AND status = 'RUNNING'
""")

SELECT_TASK_ATTEMPTS_BY_TASK_ID_SQL = text("""
    SELECT task_id, attempt, outcome, will_retry,
           started_at, finished_at,
           error_code, error_message, failed_reason,
           worker_id, worker_hostname, worker_pid, worker_process_name
    FROM horsies_task_attempts
    WHERE task_id = :task_id
    ORDER BY attempt DESC
""")

REQUEUE_STALE_CLAIMED_SQL = text("""
    UPDATE horsies_tasks AS t
    SET status = 'PENDING',
        claimed = FALSE,
        claimed_at = NULL,
        claimed_by_worker_id = NULL,
        updated_at = NOW()
    FROM (
        SELECT t2.id, hb.last_heartbeat, t2.claimed_at
        FROM horsies_tasks t2
        LEFT JOIN LATERAL (
            SELECT sent_at AS last_heartbeat
            FROM horsies_heartbeats h
            WHERE h.task_id = t2.id AND h.role = 'claimer'
            ORDER BY sent_at DESC
            LIMIT 1
        ) hb ON TRUE
        WHERE t2.status = 'CLAIMED'
        FOR UPDATE OF t2 SKIP LOCKED
    ) s
    WHERE t.id = s.id
      AND (
        (s.last_heartbeat IS NULL AND s.claimed_at IS NOT NULL AND s.claimed_at < NOW() - CAST(:stale_threshold || ' seconds' AS INTERVAL))
        OR (s.last_heartbeat IS NOT NULL AND s.last_heartbeat < NOW() - CAST(:stale_threshold || ' seconds' AS INTERVAL))
      )
""")


class PostgresBroker:
    """
    PostgreSQL-based task broker with LISTEN/NOTIFY for real-time updates.

    Provides both async and sync APIs:
      - Async: enqueue_async(), get_result_async()
      - Sync: enqueue(), get_result() (run in background event loop)

    Features:
      - Real-time notifications via PostgreSQL triggers
      - Automatic task status tracking
      - Connection pooling and health monitoring
      - Operational monitoring (stale tasks, worker stats)
    """

    def __init__(self, config: PostgresConfig):
        self.config = config
        self.logger = get_logger('broker')
        self._app: Horsies | None = None  # Set by Horsies.get_broker()

        engine_cfg = self.config.model_dump(exclude={'database_url'}, exclude_none=True)
        self.async_engine = create_async_engine(self.config.database_url, **engine_cfg)
        self.session_factory = async_sessionmaker(
            self.async_engine, expire_on_commit=False
        )

        psycopg_url = to_psycopg_url(self.config.database_url)
        self.listener = PostgresListener(psycopg_url)

        self._initialized = False
        self._loop_runner = LoopRunner()  # for sync facades

        self.logger.info('PostgresBroker initialized')

    @property
    def app(self) -> 'Horsies | None':
        """Get the attached Horsies app instance (if any)."""
        return self._app

    @app.setter
    def app(self, value: 'Horsies | None') -> None:
        """Set the Horsies app instance."""
        self._app = value

    def _schema_advisory_key(self) -> int:
        """
        Compute a stable 64-bit advisory lock key for schema initialization.

        Uses the database URL as a basis so that different clusters do not
        contend on the same advisory lock key.
        """
        basis = self.config.database_url.encode('utf-8', errors='ignore')
        h = hashlib.sha256(b'horsies-schema:' + basis).digest()
        return int.from_bytes(h[:8], byteorder='big', signed=True)

    async def _create_triggers(self) -> None:
        """
        Set up PostgreSQL triggers for automatic task notifications.

        Creates triggers that send NOTIFY messages on:
        - INSERT: Sends task_new + task_queue_{queue_name} notifications
        - UPDATE to COMPLETED/FAILED: Sends task_done notification

        This enables real-time task processing without polling.
        """
        async with self.async_engine.begin() as conn:
            # Create trigger function
            await conn.execute(CREATE_TASK_NOTIFY_FUNCTION_SQL)

            # Create trigger
            await conn.execute(CREATE_TASK_NOTIFY_TRIGGER_SQL)

            # TUI notification triggers (broader: fires on ANY status change)
            await conn.execute(CREATE_TASK_STATUS_NOTIFY_FUNCTION_SQL)
            await conn.execute(CREATE_TASK_STATUS_NOTIFY_TRIGGER_SQL)
            await conn.execute(CREATE_WORKER_STATE_NOTIFY_FUNCTION_SQL)
            await conn.execute(CREATE_WORKER_STATE_NOTIFY_TRIGGER_SQL)

    async def _create_workflow_schema(self) -> None:
        """
        Set up workflow-specific schema elements.

        Creates:
        - GIN index on workflow_tasks.dependencies for efficient dependency lookups
        - Trigger for workflow completion notifications
        - Migration: adds task_options column if missing (for existing installs)
        """
        async with self.async_engine.begin() as conn:
            # GIN index for efficient dependency array lookups
            await conn.execute(CREATE_WORKFLOW_TASKS_DEPS_INDEX_SQL)

            # Migration: add task_options column for existing installs
            await conn.execute(ADD_TASK_OPTIONS_COLUMN_SQL)

            # Migration: add success_policy column for existing installs
            await conn.execute(ADD_SUCCESS_POLICY_COLUMN_SQL)

            # Migration: add join_type and min_success columns for existing installs
            await conn.execute(ADD_JOIN_TYPE_COLUMN_SQL)
            await conn.execute(ADD_MIN_SUCCESS_COLUMN_SQL)
            await conn.execute(ADD_NODE_ID_COLUMN_SQL)

            # Subworkflow support columns
            await conn.execute(ADD_PARENT_WORKFLOW_ID_COLUMN_SQL)
            await conn.execute(ADD_PARENT_TASK_INDEX_COLUMN_SQL)
            await conn.execute(ADD_DEPTH_COLUMN_SQL)
            await conn.execute(ADD_ROOT_WORKFLOW_ID_COLUMN_SQL)
            await conn.execute(ADD_WORKFLOW_DEF_MODULE_COLUMN_SQL)
            await conn.execute(ADD_WORKFLOW_DEF_QUALNAME_COLUMN_SQL)

            await conn.execute(ADD_IS_SUBWORKFLOW_COLUMN_SQL)
            await conn.execute(ADD_SUB_WORKFLOW_ID_COLUMN_SQL)
            await conn.execute(ADD_SUB_WORKFLOW_NAME_COLUMN_SQL)
            await conn.execute(DROP_SUB_WORKFLOW_RETRY_MODE_COLUMN_SQL)
            await conn.execute(ADD_SUB_WORKFLOW_SUMMARY_COLUMN_SQL)
            await conn.execute(ADD_SUB_WORKFLOW_MODULE_COLUMN_SQL)
            await conn.execute(ADD_SUB_WORKFLOW_QUALNAME_COLUMN_SQL)

            # Workflow notification trigger function
            await conn.execute(CREATE_WORKFLOW_NOTIFY_FUNCTION_SQL)

            # Create workflow trigger
            await conn.execute(CREATE_WORKFLOW_NOTIFY_TRIGGER_SQL)

            # TUI notification trigger (broader: fires on ANY workflow status change)
            await conn.execute(CREATE_WORKFLOW_STATUS_NOTIFY_FUNCTION_SQL)
            await conn.execute(CREATE_WORKFLOW_STATUS_NOTIFY_TRIGGER_SQL)

    async def _ensure_initialized(self) -> None:
        if self._initialized:
            return
        async with self.async_engine.begin() as conn:
            # Take a short-lived, cluster-wide advisory lock to serialize
            # schema creation across workers and producers.
            await conn.execute(
                SCHEMA_ADVISORY_LOCK_SQL,
                {'key': self._schema_advisory_key()},
            )
            await conn.run_sync(Base.metadata.create_all)

            # Migration: ensure NOT NULL columns have server-side DEFAULTs
            # for existing tables created before server_default was added.
            await conn.execute(SET_TASK_COLUMN_DEFAULTS_SQL)
            await conn.execute(CREATE_HEARTBEATS_TASK_ROLE_SENT_INDEX_SQL)

            # Migration: add enqueued_at column, backfill from sent_at,
            # and enforce NOT NULL for existing databases.
            await conn.execute(ADD_ENQUEUED_AT_COLUMN_SQL)
            await conn.execute(BACKFILL_ENQUEUED_AT_SQL)
            await conn.execute(SET_ENQUEUED_AT_NOT_NULL_SQL)
            await conn.execute(SET_ENQUEUED_AT_DEFAULT_SQL)

            # Migration: add enqueue_sha column, backfill NULLs, enforce NOT NULL.
            await conn.execute(ADD_ENQUEUE_SHA_COLUMN_SQL)
            await conn.execute(BACKFILL_ENQUEUE_SHA_SQL)
            await conn.execute(SET_ENQUEUE_SHA_NOT_NULL_SQL)

            # Migration: add error_code column for task failure observability.
            await conn.execute(ADD_ERROR_CODE_COLUMN_SQL)
            await conn.execute(CREATE_TASKS_ERROR_CODE_INDEX_SQL)

            # Migration: create horsies_task_attempts table and indexes.
            await conn.execute(CREATE_TASK_ATTEMPTS_TABLE_SQL)
            await conn.execute(CREATE_TASK_ATTEMPTS_ERROR_CODE_INDEX_SQL)
            await conn.execute(CREATE_TASK_ATTEMPTS_FINISHED_AT_INDEX_SQL)

            # Migration: add workflow sent_at column (immutable workflow start
            # call-site timestamp), backfill existing rows, and enforce NOT NULL.
            # Keep this in the advisory-locked schema transaction to avoid DDL
            # lock races with concurrent workflow writes.
            await conn.execute(ADD_WORKFLOW_SENT_AT_COLUMN_SQL)
            await conn.execute(BACKFILL_WORKFLOW_SENT_AT_SQL)
            await conn.execute(SET_WORKFLOW_SENT_AT_NOT_NULL_SQL)
            await conn.execute(SET_WORKFLOW_SENT_AT_DEFAULT_SQL)

        await self._create_triggers()
        await self._create_workflow_schema()
        start_r = await self.listener.start()
        if is_err(start_r):
            err = start_r.err_value
            raise err.exception or RuntimeError(err.message)
        self._initialized = True

    async def ensure_schema_initialized(self) -> BrokerResult[None]:
        """
        Public entry point to ensure tables and triggers exist.

        Safe to call multiple times and from multiple processes; internally
        guarded by a PostgreSQL advisory lock to avoid DDL races.

        Returns Ok(None) on success, Err(BrokerOperationError) on failure.
        """
        try:
            await self._ensure_initialized()
            return Ok(None)
        except Exception as exc:
            return _broker_err(
                BrokerErrorCode.SCHEMA_INIT_FAILED,
                f'Schema initialization failed: {exc}',
                exc,
            )

    # ----------------- Async API -----------------

    async def enqueue_async(
        self,
        task_name: str,
        queue_name: str = 'default',
        *,
        task_id: str,
        enqueue_sha: str,
        args_json: str | None = None,
        kwargs_json: str | None = None,
        priority: int = 100,
        sent_at: Optional[datetime] = None,
        enqueued_at: Optional[datetime] = None,
        enqueue_delay_seconds: Optional[int] = None,
        good_until: Optional[datetime] = None,
        task_options: Optional[str] = None,
    ) -> BrokerResult[str]:
        if enqueued_at is not None and enqueue_delay_seconds is not None:
            return _broker_err(
                BrokerErrorCode.ENQUEUE_FAILED,
                'Cannot specify both enqueued_at and enqueue_delay_seconds',
                ValueError('Cannot specify both enqueued_at and enqueue_delay_seconds'),
            )
        # Guard: sent_at is an immutable call-site timestamp, not a scheduling
        # mechanism.  A future sent_at without an explicit enqueued_at or
        # enqueue_delay_seconds is almost certainly legacy ETA usage that would
        # silently run immediately (enqueued_at defaults to NOW()).
        # 5-second tolerance absorbs trivial clock drift.
        _SENT_AT_FUTURE_TOLERANCE = timedelta(seconds=5)
        if (
            sent_at is not None
            and sent_at > datetime.now(timezone.utc) + _SENT_AT_FUTURE_TOLERANCE
            and enqueued_at is None
            and enqueue_delay_seconds is None
        ):
            return _broker_err(
                BrokerErrorCode.ENQUEUE_FAILED,
                'sent_at is in the future without enqueued_at or enqueue_delay_seconds; '
                'sent_at is a call-site timestamp, use enqueued_at or '
                'enqueue_delay_seconds to schedule deferred execution',
                ValueError('future sent_at without explicit scheduling parameter'),
            )
        try:
            await self._ensure_initialized()

            call_site_sent_at = sent_at or datetime.now(timezone.utc)

            # Parse retry configuration from task_options.
            # task_options is always produced by serialize_task_options() — malformed JSON
            # is a bug, not a runtime condition, and must not be silently swallowed.
            max_retries = 0
            if task_options:
                opts_r = loads_json(task_options)
                if is_err(opts_r):
                    return _broker_err(BrokerErrorCode.ENQUEUE_FAILED, f'task_options JSON corrupt: {opts_r.err_value}', opts_r.err_value)
                options_data = opts_r.ok_value
                if isinstance(options_data, dict):
                    retry_policy = options_data.get('retry_policy')
                    if isinstance(retry_policy, dict):
                        max_retries = retry_policy.get('max_retries', 3)

            # Determine enqueued_at value for the INSERT.
            # enqueue_delay_seconds: DB-side NOW() + interval.
            # explicit enqueued_at: caller-provided value.
            # default: DB-side NOW() via text('NOW()').
            if enqueue_delay_seconds is not None:
                enqueued_at_value = text(
                    "NOW() + CAST(:delay || ' seconds' AS INTERVAL)",
                ).bindparams(delay=str(enqueue_delay_seconds))
            elif enqueued_at is not None:
                enqueued_at_value = enqueued_at
            else:
                enqueued_at_value = text('NOW()')

            # Single SQLAlchemy Core INSERT ... ON CONFLICT DO NOTHING ... RETURNING id.
            # Replaces both the ORM session.add() and raw SQL paths.
            stmt = (
                pg_insert(TaskModel)
                .values(
                    id=task_id,
                    task_name=task_name,
                    queue_name=queue_name,
                    priority=priority,
                    args=args_json,
                    kwargs=kwargs_json,
                    status=TaskStatus.PENDING,
                    sent_at=call_site_sent_at,
                    enqueued_at=enqueued_at_value,
                    good_until=good_until,
                    max_retries=max_retries,
                    task_options=task_options,
                    enqueue_sha=enqueue_sha,
                    created_at=text('NOW()'),
                    updated_at=text('NOW()'),
                )
                .on_conflict_do_nothing(index_elements=['id'])
                .returning(TaskModel.id)
            )

            async with self.session_factory() as session:
                result = await session.execute(stmt)
                row = result.fetchone()
                await session.commit()

            if row is not None:
                # Row inserted — fresh enqueue succeeded.
                return Ok(task_id)

            # Conflict: task_id already exists. Verify payload identity via stored SHA.
            return await self._verify_enqueue_conflict(task_id, enqueue_sha, task_name)

        except Exception as exc:
            return _broker_err(
                BrokerErrorCode.ENQUEUE_FAILED,
                f'Failed to enqueue task {task_name}: {exc}',
                exc,
            )

    async def _verify_enqueue_conflict(
        self,
        task_id: str,
        enqueue_sha: str,
        task_name: str,
    ) -> BrokerResult[str]:
        """Verify a conflicting task_id has the same payload.

        Called when INSERT ... ON CONFLICT DO NOTHING returns no row.
        """
        logger = get_logger('broker')
        try:
            async with self.session_factory() as session:
                row = (
                    await session.execute(
                        select(TaskModel.enqueue_sha).where(TaskModel.id == task_id),
                    )
                ).fetchone()
        except Exception as exc:
            # SELECT failed — task exists (conflict proves it) but we cannot
            # confirm payload identity. Retryable so auto-retry or manual
            # retry can reattempt when DB recovers.
            return Err(BrokerOperationError(
                code=BrokerErrorCode.ENQUEUE_FAILED,
                message=(
                    f'task_id {task_id} conflict detected but verification '
                    f'query failed for {task_name}: {exc}'
                ),
                retryable=True,
                exception=exc,
            ))

        if row is None:
            # Task existed and was already cleaned up (completed and purged).
            # The original send succeeded and the work was done.
            logger.warning(
                'enqueue conflict for task_id=%s (%s) but row no longer exists — '
                'original send succeeded and task was purged',
                task_id,
                task_name,
            )
            return Ok(task_id)

        existing_sha: str = row.enqueue_sha
        # enqueue_sha is NOT NULL — defensive assertion against data corruption.
        assert existing_sha is not None, (
            f'enqueue_sha is NULL for task_id={task_id} — column is NOT NULL'
        )

        if existing_sha == enqueue_sha:
            # Idempotent success — same payload already enqueued.
            return Ok(task_id)

        # Different payload with same task_id — always a bug.
        return Err(BrokerOperationError(
            code=BrokerErrorCode.PAYLOAD_MISMATCH,
            message=(
                f'task_id {task_id} already exists with different payload '
                f'for {task_name} (sha mismatch)'
            ),
            retryable=False,
            exception=None,
        ))

    async def get_result_async(
        self, task_id: str, timeout_ms: Optional[int] = None
    ) -> 'TaskResult[Any, TaskError]':
        """
        Get task result, waiting if necessary.

        Returns TaskResult for task completion and retrieval outcomes:
        - Success: TaskResult(ok=value) from task execution
        - Task error: TaskResult(err=TaskError) from task execution
        - Retrieval error: TaskResult(err=TaskError) with WAIT_TIMEOUT, TASK_NOT_FOUND, or TASK_CANCELLED

        Broker failures (e.g., database errors) are returned as BROKER_ERROR.
        """
        from horsies.core.models.tasks import TaskResult, TaskError, OperationalErrorCode, RetrievalCode, OutcomeCode

        try:
            await self._ensure_initialized()

            start_time = asyncio.get_event_loop().time()

            # Convert milliseconds to seconds for internal use
            timeout_seconds: Optional[float] = None
            if timeout_ms is not None:
                timeout_seconds = timeout_ms / 1000.0

            # Quick path - check if task is already completed
            async with self.session_factory() as session:
                row = await session.get(TaskModel, task_id)
                if row is None:
                    self.logger.error(f'Task {task_id} not found')
                    return TaskResult(
                        err=TaskError(
                            error_code=RetrievalCode.TASK_NOT_FOUND,
                            message=f'Task {task_id} not found in database',
                            data={'task_id': task_id},
                        )
                    )
                if row.status in (TaskStatus.COMPLETED, TaskStatus.FAILED):
                    self.logger.info(f'Task {task_id} already completed')
                    _lr = loads_json(row.result)
                    if is_err(_lr):
                        return TaskResult(err=TaskError(
                            error_code=OperationalErrorCode.BROKER_ERROR,
                            message=f'Result JSON corrupt: {_lr.err_value}',
                            data={'task_id': task_id},
                        ))
                    _trr = task_result_from_json(_lr.ok_value)
                    if is_err(_trr):
                        return TaskResult(err=TaskError(
                            error_code=OperationalErrorCode.BROKER_ERROR,
                            message=f'Result deser failed: {_trr.err_value}',
                            data={'task_id': task_id},
                        ))
                    return _trr.ok_value
                if row.status == TaskStatus.CANCELLED:
                    self.logger.info(f'Task {task_id} was cancelled')
                    return TaskResult(
                        err=TaskError(
                            error_code=OutcomeCode.TASK_CANCELLED,
                            message=f'Task {task_id} was cancelled before completion',
                            data={'task_id': task_id},
                        )
                    )

            # Listen for task completion notifications when listener loop ownership permits.
            # Cross-loop RuntimeError (programming error) or infrastructure Err both
            # fall back to pure DB polling.
            q = None
            try:
                listen_r = await self.listener.listen('task_done')
            except RuntimeError as e:
                self.logger.debug(
                    'Listener unavailable on current event loop; falling back to polling for task_done: %s',
                    e,
                )
            else:
                match listen_r:
                    case Ok(queue):
                        q = queue
                    case Err(listen_err):
                        self.logger.debug(
                            'Listener subscribe failed; falling back to polling for task_done: %s',
                            listen_err.message,
                        )
            try:
                poll_interval = 5.0 if q is not None else 0.2

                while True:
                    # Calculate remaining timeout
                    remaining_timeout = None
                    if timeout_seconds:
                        elapsed = asyncio.get_event_loop().time() - start_time
                        remaining_timeout = timeout_seconds - elapsed
                        if remaining_timeout <= 0:
                            return TaskResult(
                                err=TaskError(
                                    error_code=RetrievalCode.WAIT_TIMEOUT,
                                    message=f'Timed out waiting for task {task_id} after {timeout_ms}ms. Task may still be running.',
                                    data={'task_id': task_id, 'timeout_ms': timeout_ms},
                                )
                            )

                    # Wait for NOTIFY or timeout (whichever comes first)
                    wait_time = (
                        min(poll_interval, remaining_timeout)
                        if remaining_timeout
                        else poll_interval
                    )

                    if q is not None:
                        try:

                            async def _wait_for_task() -> None:
                                # Filter notifications: only process our specific task_id
                                while True:
                                    note = (
                                        await q.get()
                                    )  # Blocks until any task_done notification
                                    if (
                                        note.payload == task_id
                                    ):  # Check if it's for our task
                                        return  # Found our task completion!

                            # Wait for our specific task notification with timeout
                            await asyncio.wait_for(_wait_for_task(), timeout=wait_time)
                        except asyncio.TimeoutError:
                            pass
                    else:
                        await asyncio.sleep(wait_time)

                    # Poll database each cycle (notification path still polls to avoid
                    # races where NOTIFY arrives slightly before terminal row commit).
                    async with self.session_factory() as session:
                        row = await session.get(TaskModel, task_id)
                        if row is None:
                            return TaskResult(
                                err=TaskError(
                                    error_code=RetrievalCode.TASK_NOT_FOUND,
                                    message=f'Task {task_id} not found in database',
                                    data={'task_id': task_id},
                                )
                            )
                        if row.status in (TaskStatus.COMPLETED, TaskStatus.FAILED):
                            self.logger.debug(
                                f'Task {task_id} completed, polling database'
                            )
                            _lr = loads_json(row.result)
                            if is_err(_lr):
                                return TaskResult(err=TaskError(
                                    error_code=OperationalErrorCode.BROKER_ERROR,
                                    message=f'Result JSON corrupt: {_lr.err_value}',
                                    data={'task_id': task_id},
                                ))
                            _trr = task_result_from_json(_lr.ok_value)
                            if is_err(_trr):
                                return TaskResult(err=TaskError(
                                    error_code=OperationalErrorCode.BROKER_ERROR,
                                    message=f'Result deser failed: {_trr.err_value}',
                                    data={'task_id': task_id},
                                ))
                            return _trr.ok_value
                        if row.status == TaskStatus.CANCELLED:
                            self.logger.error(f'Task {task_id} was cancelled')
                            return TaskResult(
                                err=TaskError(
                                    error_code=OutcomeCode.TASK_CANCELLED,
                                    message=f'Task {task_id} was cancelled before completion',
                                    data={'task_id': task_id},
                                )
                            )

            finally:
                # Clean up subscription. If this was the last local waiter,
                # listener.unsubscribe() also drops server-side LISTEN state.
                if q is not None:
                    await self._unsubscribe_task_done_safely(q)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            self.logger.exception('Broker error while retrieving task result')
            return TaskResult(
                err=TaskError(
                    error_code=OperationalErrorCode.BROKER_ERROR,
                    message='Broker error while retrieving task result',
                    data={'task_id': task_id, 'timeout_ms': timeout_ms},
                    exception=exc,
                )
            )

    async def _unsubscribe_task_done_safely(self, q: asyncio.Queue[Any]) -> None:
        """Ensure task_done unsubscribe completes even under repeated cancellation."""
        unsubscribe_task = asyncio.create_task(self.listener.unsubscribe('task_done', q))
        cancelled_during_cleanup = False
        while not unsubscribe_task.done():
            try:
                await asyncio.shield(unsubscribe_task)
            except asyncio.CancelledError:
                cancelled_during_cleanup = True
                continue

        # Preserve existing semantics: cross-loop RuntimeError on unsubscribe is non-fatal.
        with contextlib.suppress(RuntimeError):
            await unsubscribe_task

        # Propagate cancellation only after cleanup has completed.
        if cancelled_during_cleanup:
            raise asyncio.CancelledError

    async def close_async(self) -> BrokerResult[None]:
        """Close listener/engine and stop sync loop runner if it was started."""
        errors: list[BaseException] = []
        try:
            await self.listener.close()
        except Exception as exc:
            errors.append(exc)
        try:
            await self.async_engine.dispose()
        except Exception as exc:
            errors.append(exc)
        # If sync APIs started the LoopRunner, close_async should also tear it down
        # when called from any thread except the loop-runner thread itself.
        loop_thread = self._loop_runner._thread
        if (
            self._loop_runner._started
            and loop_thread is not None
            and threading.current_thread() is not loop_thread
        ):
            try:
                self._loop_runner.stop()
            except Exception as exc:
                errors.append(exc)
        if errors:
            return _broker_err(
                BrokerErrorCode.CLOSE_FAILED,
                f'Close failed ({len(errors)} error(s)): {errors[0]}',
                errors[0],
            )
        return Ok(None)

    # ------------- Operational & Monitoring Methods -------------

    async def get_stale_tasks(
        self,
        stale_threshold_minutes: int = 2,
    ) -> BrokerResult[list[dict[str, Any]]]:
        """Identify potentially crashed tasks based on heartbeat absence."""
        try:
            async with self.session_factory() as session:
                result = await session.execute(
                    GET_STALE_TASKS_SQL,
                    {'stale_threshold': stale_threshold_minutes},
                )
                columns = result.keys()
                return Ok([dict(zip(columns, row)) for row in result.fetchall()])
        except Exception as exc:
            return _broker_err(
                BrokerErrorCode.MONITORING_QUERY_FAILED,
                f'get_stale_tasks failed: {exc}',
                exc,
            )

    async def get_worker_stats(self) -> BrokerResult[list[dict[str, Any]]]:
        """Gather statistics about active worker processes."""
        try:
            async with self.session_factory() as session:
                result = await session.execute(GET_WORKER_STATS_SQL)
                columns = result.keys()
                return Ok([dict(zip(columns, row)) for row in result.fetchall()])
        except Exception as exc:
            return _broker_err(
                BrokerErrorCode.MONITORING_QUERY_FAILED,
                f'get_worker_stats failed: {exc}',
                exc,
            )

    async def get_expired_tasks(self) -> BrokerResult[list[dict[str, Any]]]:
        """Find tasks that expired before worker processing."""
        try:
            async with self.session_factory() as session:
                result = await session.execute(GET_EXPIRED_TASKS_SQL)
                columns = result.keys()
                return Ok([dict(zip(columns, row)) for row in result.fetchall()])
        except Exception as exc:
            return _broker_err(
                BrokerErrorCode.MONITORING_QUERY_FAILED,
                f'get_expired_tasks failed: {exc}',
                exc,
            )

    async def mark_stale_tasks_as_failed(
        self,
        stale_threshold_ms: int = 300_000,
    ) -> BrokerResult[int]:
        """
        Clean up crashed worker tasks by marking them as FAILED.

        Creates a proper TaskResult with WORKER_CRASHED error code for each stale task.
        """
        try:
            from horsies.core.models.tasks import TaskResult, TaskError, OperationalErrorCode
            from horsies.core.codec.serde import dumps_json

            # Convert milliseconds to seconds for PostgreSQL INTERVAL
            stale_threshold_seconds = stale_threshold_ms / 1000.0

            async with self.session_factory() as session:
                stale_tasks_result = await session.execute(
                    SELECT_STALE_RUNNING_TASKS_SQL,
                    {'stale_threshold': stale_threshold_seconds},
                )

                stale_tasks = stale_tasks_result.fetchall()
                if not stale_tasks:
                    return Ok(0)

                for task_row in stale_tasks:
                    task_id = task_row.id
                    worker_pid = task_row.worker_pid
                    worker_hostname = task_row.worker_hostname
                    worker_id = task_row.claimed_by_worker_id
                    started_at = task_row.started_at
                    last_heartbeat = task_row.last_heartbeat
                    retry_count = task_row.retry_count or 0
                    worker_process_name = task_row.worker_process_name

                    failed_reason_str = (
                        f'Worker process crashed (no runner heartbeat '
                        f'for {stale_threshold_ms}ms = {stale_threshold_ms/1000:.1f}s)'
                    )
                    task_error = TaskError(
                        error_code=OperationalErrorCode.WORKER_CRASHED,
                        message=failed_reason_str,
                        data={
                            'stale_threshold_ms': stale_threshold_ms,
                            'stale_threshold_seconds': stale_threshold_seconds,
                            'worker_pid': worker_pid,
                            'worker_hostname': worker_hostname,
                            'worker_id': worker_id,
                            'started_at': started_at.isoformat() if started_at else None,
                            'last_heartbeat': last_heartbeat.isoformat()
                            if last_heartbeat
                            else None,
                            'detected_at': datetime.now(timezone.utc).isoformat(),
                        },
                    )
                    task_result: TaskResult[None, TaskError] = TaskResult(err=task_error)
                    ser_r = dumps_json(task_result)
                    # Library-constructed TaskError with string primitives — can't fail,
                    # but if it somehow does, skip this task rather than abort the entire cleanup.
                    if is_err(ser_r):
                        self.logger.error(f'Failed to serialize crash result for task {task_id}: {ser_r.err_value}')
                        continue
                    result_json = ser_r.ok_value

                    # Upsert attempt row: FAILED with WORKER_CRASHED
                    attempt_num = retry_count + 1
                    now_utc = datetime.now(timezone.utc)
                    await session.execute(
                        UPSERT_TASK_ATTEMPT_SQL,
                        {
                            'task_id': task_id,
                            'attempt': attempt_num,
                            'outcome': 'FAILED',
                            'will_retry': False,
                            'started_at': started_at or now_utc,
                            'finished_at': now_utc,
                            'error_code': OperationalErrorCode.WORKER_CRASHED.value,
                            'error_message': task_error.message,
                            'failed_reason': failed_reason_str,
                            'worker_id': worker_id,
                            'worker_hostname': worker_hostname,
                            'worker_pid': worker_pid,
                            'worker_process_name': worker_process_name,
                        },
                    )

                    await session.execute(
                        MARK_STALE_TASK_FAILED_SQL,
                        {
                            'task_id': task_id,
                            'failed_reason': failed_reason_str,
                            'result': result_json,
                            'error_code': OperationalErrorCode.WORKER_CRASHED.value,
                        },
                    )

                await session.commit()
                return Ok(len(stale_tasks))
        except Exception as exc:
            return _broker_err(
                BrokerErrorCode.CLEANUP_FAILED,
                f'mark_stale_tasks_as_failed failed: {exc}',
                exc,
            )

    async def requeue_stale_claimed(
        self,
        stale_threshold_ms: int = 120_000,
    ) -> BrokerResult[int]:
        """Requeue tasks stuck in CLAIMED without recent claimer heartbeat."""
        try:
            stale_threshold_seconds = stale_threshold_ms / 1000.0

            async with self.session_factory() as session:
                result = await session.execute(
                    REQUEUE_STALE_CLAIMED_SQL,
                    {'stale_threshold': stale_threshold_seconds},
                )
                await session.commit()
                return Ok(getattr(result, 'rowcount', 0))
        except Exception as exc:
            return _broker_err(
                BrokerErrorCode.CLEANUP_FAILED,
                f'requeue_stale_claimed failed: {exc}',
                exc,
            )

    # ----------------- Sync API Facades -----------------

    def enqueue(
        self,
        task_name: str,
        queue_name: str = 'default',
        *,
        task_id: str,
        enqueue_sha: str,
        args_json: str | None = None,
        kwargs_json: str | None = None,
        priority: int = 100,
        sent_at: Optional[datetime] = None,
        enqueued_at: Optional[datetime] = None,
        enqueue_delay_seconds: Optional[int] = None,
        good_until: Optional[datetime] = None,
        task_options: Optional[str] = None,
    ) -> BrokerResult[str]:
        """Synchronous task submission (runs enqueue_async in background loop)."""
        try:
            return self._loop_runner.call(
                self.enqueue_async,
                task_name,
                queue_name,
                task_id=task_id,
                enqueue_sha=enqueue_sha,
                args_json=args_json,
                kwargs_json=kwargs_json,
                priority=priority,
                sent_at=sent_at,
                enqueued_at=enqueued_at,
                enqueue_delay_seconds=enqueue_delay_seconds,
                good_until=good_until,
                task_options=task_options,
            )
        except Exception as exc:
            return _broker_err(
                BrokerErrorCode.ENQUEUE_FAILED,
                f'Failed to enqueue task {task_name} (sync): {exc}',
                exc,
            )

    def get_result(
        self, task_id: str, timeout_ms: Optional[int] = None
    ) -> 'TaskResult[Any, TaskError]':
        """
        Synchronous result retrieval (runs get_result_async in background loop).

        Args:
            task_id: The task ID to retrieve result for
            timeout_ms: Maximum time to wait for result (milliseconds)

        Returns:
            TaskResult - success, task error, retrieval error, or broker error
        """
        from horsies.core.models.tasks import TaskResult, TaskError, OperationalErrorCode

        try:
            return self._loop_runner.call(self.get_result_async, task_id, timeout_ms)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            return TaskResult(
                err=TaskError(
                    error_code=OperationalErrorCode.BROKER_ERROR,
                    message='Broker error while retrieving task result',
                    data={'task_id': task_id, 'timeout_ms': timeout_ms},
                    exception=exc,
                )
            )

    async def get_task_info_async(
        self,
        task_id: str,
        *,
        include_result: bool = False,
        include_failed_reason: bool = False,
        include_attempts: bool = False,
    ) -> BrokerResult[TaskInfo | None]:
        """Fetch metadata for a task by ID.

        Returns Ok(TaskInfo) if found, Ok(None) if not found,
        Err(BrokerOperationError) on infrastructure failure.
        """
        try:
            await self._ensure_initialized()

            async with self.session_factory() as session:
                base_columns = [
                    'id',
                    'task_name',
                    'status',
                    'queue_name',
                    'priority',
                    'retry_count',
                    'max_retries',
                    'next_retry_at',
                    'sent_at',
                    'enqueued_at',
                    'claimed_at',
                    'started_at',
                    'completed_at',
                    'failed_at',
                    'worker_hostname',
                    'worker_pid',
                    'worker_process_name',
                    'error_code',
                ]
                if include_result:
                    base_columns.append('result')
                if include_failed_reason:
                    base_columns.append('failed_reason')

                query = text(
                    f"""
                    SELECT {', '.join(base_columns)}
                    FROM horsies_tasks
                    WHERE id = :id
                """
                )
                result = await session.execute(query, {'id': task_id})
                row = result.fetchone()
                if row is None:
                    return Ok(None)

                result_value = None
                failed_reason = None

                idx = 0
                task_id_value = row[idx]
                idx += 1
                task_name = row[idx]
                idx += 1
                status = TaskStatus(row[idx])
                idx += 1
                queue_name = row[idx]
                idx += 1
                priority = row[idx]
                idx += 1
                retry_count = row[idx] or 0
                idx += 1
                max_retries = row[idx] or 0
                idx += 1
                next_retry_at = row[idx]
                idx += 1
                sent_at = row[idx]
                idx += 1
                enqueued_at = row[idx]
                idx += 1
                claimed_at = row[idx]
                idx += 1
                started_at = row[idx]
                idx += 1
                completed_at = row[idx]
                idx += 1
                failed_at = row[idx]
                idx += 1
                worker_hostname = row[idx]
                idx += 1
                worker_pid = row[idx]
                idx += 1
                worker_process_name = row[idx]
                idx += 1
                error_code_value = row[idx]
                idx += 1

                if include_result:
                    raw_result = row[idx]
                    idx += 1
                    if raw_result:
                        _lr = loads_json(raw_result)
                        if is_err(_lr):
                            return _broker_err(BrokerErrorCode.TASK_INFO_QUERY_FAILED, f'Result JSON corrupt: {_lr.err_value}', _lr.err_value)
                        _trr = task_result_from_json(_lr.ok_value)
                        if is_err(_trr):
                            return _broker_err(BrokerErrorCode.TASK_INFO_QUERY_FAILED, f'Result deser failed: {_trr.err_value}', _trr.err_value)
                        result_value = _trr.ok_value

                if include_failed_reason:
                    failed_reason = row[idx]

                # Load attempt history if requested
                attempts: list[TaskAttemptInfo] | None = None
                if include_attempts:
                    att_result = await session.execute(
                        SELECT_TASK_ATTEMPTS_BY_TASK_ID_SQL,
                        {'task_id': task_id},
                    )
                    attempts = [
                        TaskAttemptInfo(
                            task_id=att_row[0],
                            attempt=att_row[1],
                            outcome=TaskAttemptOutcome(att_row[2]),
                            will_retry=att_row[3],
                            started_at=att_row[4],
                            finished_at=att_row[5],
                            error_code=att_row[6],
                            error_message=att_row[7],
                            failed_reason=att_row[8],
                            worker_id=att_row[9],
                            worker_hostname=att_row[10],
                            worker_pid=att_row[11],
                            worker_process_name=att_row[12],
                        )
                        for att_row in att_result.fetchall()
                    ]

                return Ok(TaskInfo(
                    task_id=task_id_value,
                    task_name=task_name,
                    status=status,
                    queue_name=queue_name,
                    priority=priority,
                    retry_count=retry_count,
                    max_retries=max_retries,
                    next_retry_at=next_retry_at,
                    sent_at=sent_at,
                    enqueued_at=enqueued_at,
                    claimed_at=claimed_at,
                    started_at=started_at,
                    completed_at=completed_at,
                    failed_at=failed_at,
                    worker_hostname=worker_hostname,
                    worker_pid=worker_pid,
                    worker_process_name=worker_process_name,
                    error_code=error_code_value,
                    result=result_value,
                    failed_reason=failed_reason,
                    attempts=attempts,
                ))
        except Exception as exc:
            return _broker_err(
                BrokerErrorCode.TASK_INFO_QUERY_FAILED,
                f'get_task_info failed for {task_id}: {exc}',
                exc,
            )

    def get_task_info(
        self,
        task_id: str,
        *,
        include_result: bool = False,
        include_failed_reason: bool = False,
        include_attempts: bool = False,
    ) -> BrokerResult[TaskInfo | None]:
        """Synchronous wrapper for get_task_info_async()."""
        try:
            return self._loop_runner.call(
                self.get_task_info_async,
                task_id,
                include_result=include_result,
                include_failed_reason=include_failed_reason,
                include_attempts=include_attempts,
            )
        except Exception as exc:
            return _broker_err(
                BrokerErrorCode.TASK_INFO_QUERY_FAILED,
                f'get_task_info failed for {task_id} (sync): {exc}',
                exc,
            )

    def close(self) -> BrokerResult[None]:
        """Synchronous cleanup (runs close_async in background loop)."""
        try:
            return self._loop_runner.call(self.close_async)
        except Exception as exc:
            return _broker_err(
                BrokerErrorCode.CLOSE_FAILED,
                f'close failed (sync): {exc}',
                exc,
            )
        finally:
            self._loop_runner.stop()
