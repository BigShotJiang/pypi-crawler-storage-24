"""
sage.platform.runtime.adapters - Runtime Backend Adapters

Layer: L2 (sage-platform)

This package contains concrete adapter implementations that wrap external
runtime backends so they satisfy the ``RuntimeBackendProtocol`` defined in
``sage.platform.runtime.protocol``.

Available adapters
------------------
- ``flutty_adapter.FluttyRuntimeAdapter`` – wraps the flutty runtime (primary).
  Requires ``flutty`` to be installed.
- ``flownet_adapter.FlownetRuntimeAdapter`` – wraps sageFlownet runtime (deprecated).
  Requires ``isage-flow`` (sageFlownet) to be installed.
"""
