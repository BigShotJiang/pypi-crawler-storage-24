"""Dave-IT-guy — Deploy AI stacks with one command."""

__version__ = "0.1.6"
