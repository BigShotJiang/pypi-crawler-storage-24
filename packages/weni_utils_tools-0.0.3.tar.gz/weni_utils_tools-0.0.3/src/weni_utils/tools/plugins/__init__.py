"""
Plugins for Weni VTEX Concierge

Plugins are optional extensions that add specific functionalities.
Each client can choose which plugins to use.

Usage:
    from weni_utils.tools.plugins import Regionalization, Carousel, CAPI

    concierge = ProductConcierge(
        base_url_vtex="...",
        store_url_vtex="...",
        plugins=[
            Regionalization(),
        ]
    )
"""

from .base import PluginBase
from .capi import CAPI
from .carousel import Carousel
from .cart_simulation import CartSimulation
from .regionalization import Regionalization
from .send_message import SendMessage
from .utils import (
    check_stock_availability,
    get_product_price,
    get_region,
    get_sellers_by_region,
    send_capi_event,
    simulate_cart,
    simulate_cart_batch,
    trigger_weni_flow,
)
from .weni_flow import WeniFlowTrigger

__all__ = [
    # Plugin classes
    "PluginBase",
    "Regionalization",
    "Carousel",
    "CAPI",
    "WeniFlowTrigger",
    "SendMessage",
    "CartSimulation",
    # Utility functions
    "simulate_cart",
    "simulate_cart_batch",
    "check_stock_availability",
    "get_product_price",
    "get_region",
    "get_sellers_by_region",
    "send_capi_event",
    "trigger_weni_flow",
]
