# Installation

## From Source

```bash
git clone https://github.com/yourusername/dpo.git
cd dpo
pip install -e .
```

## From PyPI

```bash
pip install dpo
```

## Optional Dependencies

```bash
pip install dpo[dev]
pip install dpo[docs]
pip install dpo[gpu]
pip install dpo[benchmarks]
```

## Editable development install

```bash
pip install -e .[dev]
```

## Verify installation

```bash
python -c "import dpo; print(dpo.__version__)"
```
