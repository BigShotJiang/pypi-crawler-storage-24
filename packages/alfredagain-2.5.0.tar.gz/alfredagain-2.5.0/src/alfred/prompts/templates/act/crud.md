# CRUD Tools Reference

## Tools

| Tool | Purpose | Params |
|------|---------|--------|
| `db_read` | Fetch rows or aggregate | `table`, `filters`, `or_filters`, `columns`, `limit`, `order_by`, `order_dir`, `aggregate`, `aggregate_field` |
| `db_create` | Insert row(s) | `table`, `data` (dict or array of dicts) |
| `db_update` | Modify rows | `table`, `filters`, `data` (dict, applied to ALL matches) |
| `db_delete` | Remove rows | `table`, `filters` |

---

## Filter Syntax

Each filter: `{"field": "...", "op": "...", "value": "..."}`

**Operators:**

| Operator | Purpose | Example |
|----------|---------|---------|
| `=` | Exact match | `{"field": "id", "op": "=", "value": "item_1"}` |
| `!=` | Not equal | `{"field": "status", "op": "!=", "value": "expired"}` |
| `>`, `<`, `>=`, `<=` | Comparisons | `{"field": "quantity", "op": ">", "value": 0}` |
| `in` | Match any in list | `{"field": "id", "op": "in", "value": ["item_1", "item_2"]}` |
| `not_in` | Exclude list | `{"field": "id", "op": "not_in", "value": ["item_5"]}` |
| `ilike` | Fuzzy text | `{"field": "name", "op": "ilike", "value": "%chicken%"}` |
| `is_null` | Field is null | `{"field": "due_date", "op": "is_null", "value": true}` |
| `contains` | Array contains | `{"field": "occasions", "op": "contains", "value": ["weeknight"]}` |
| `similar` | Semantic search (domain middleware required) | `{"field": "_semantic", "op": "similar", "value": "light summer dinner"}` |

**Note:** Use simple refs like `item_1`, `item_5`. System translates to UUIDs automatically.

**Semantic search:** The `similar` operator uses `field: "_semantic"` (not a real column). It is handled by domain middleware (`CRUDMiddleware.pre_read()`), which runs vector/embedding search and returns matching IDs. Other filters are applied AFTER semantic narrowing. If the domain has not implemented semantic search, this operator will error.

---

## Sorting (db_read only)

| Param | Type | Default | Example |
|-------|------|---------|---------|
| `order_by` | column name | none (DB order) | `"order_by": "total_points"` |
| `order_dir` | `"asc"` or `"desc"` | `"desc"` | `"order_dir": "asc"` |

When `order_by` is set, results are sorted by that column. Default direction is **descending** (highest first) — omit `order_dir` for "top N" queries.

---

## Schema = Your Tables

Only access tables shown in the schema section. Query results are facts — 0 records means empty.
