"""Janet AI MCP Server — exposes Janet.ai actions via Model Context Protocol."""

import asyncio
import json
import os
from datetime import date, timedelta
from typing import Any, Dict, List

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from janet.config.manager import ConfigManager
from janet.mcp.resolve import (
    ResolutionError,
    resolve_assignees,
    resolve_child_task_key,
    resolve_project,
    resolve_sprint,
    resolve_status,
    resolve_sub_task_key,
    resolve_ticket_key,
    resolve_ticket_keys_batch,
)
from janet.mcp import formatters
from janet.utils.errors import AuthenticationError, NetworkError

server = Server("janet-ai")


_cached_config = None


def _get_config() -> ConfigManager:
    global _cached_config
    if _cached_config is not None:
        return _cached_config

    # Named config key takes priority (explicit switch_organization overrides env var),
    # falling back to JANET_API_KEY env var, then OAuth.
    api_key = None
    _active_key_name: str | None = None
    _cm_check = ConfigManager()
    _cfg = _cm_check.get()
    if _cfg.active_key_name and _cfg.api_keys.get(_cfg.active_key_name):
        api_key = _cfg.api_keys[_cfg.active_key_name]
        _active_key_name = _cfg.active_key_name
    if not api_key:
        api_key = os.environ.get("JANET_API_KEY")
    if api_key:
        from janet.mcp.auth import ApiKeyConfig
        config = ApiKeyConfig(api_key)
        if not config.has_organization():
            if config._network_error:
                raise AuthenticationError(
                    f"Cannot reach the Janet API to validate your key ({config._network_error}). "
                    "This is often a DNS issue. See https://docs.janet.ai/features/coding-agents#troubleshooting for step-by-step troubleshooting instructions."
                )
            raise AuthenticationError(
                "API key is invalid or has no organization access. "
                "Check your API key at janet.ai → Organization Settings → API Keys."
            )
        _cached_config = config
        return config

    # OAuth mode — requires janet login
    cm = ConfigManager()
    if not cm.is_authenticated():
        raise AuthenticationError("Not authenticated. Run `janet login` in your terminal first.")
    if not cm.has_organization():
        raise AuthenticationError(
            "No organization selected. Run `janet login` or `janet org select <org_id>` first."
        )
    _cached_config = cm
    return cm


# ── Tool definitions ────────────────────────────────────────────────────────

TOOLS: List[Tool] = [
    Tool(
        name="get_workspace_context",
        description=(
            "Get the current Janet.ai workspace context: authenticated user (name + email), "
            "organization, and all projects with their valid statuses and members. "
            "ALWAYS call this first before any other tool — you need project keys and valid "
            "status names to use the other tools."
        ),
        inputSchema={"type": "object", "properties": {}, "required": []},
    ),
    Tool(
        name="list_tickets",
        description=(
            "Search and list tickets in a project. This is your primary tool for finding tickets. "
            "When filtering by a single status, tickets are returned in kanban column order with "
            "position numbers — use this to determine ticket ordering before move_ticket calls. "
            "Combine any filters for precise queries. "
            "assignees=['me'] = current user; assignees=['name or email'] = fuzzy name match. "
            "in_status_for_days + status = stuck tickets ('stuck in Backlog 7 days'). "
            "due_before = overdue queries. created_after/updated_after = time-based queries. "
            "priorities=['Critical','High'] = urgency filter. "
            "Examples: assignees=['me']+priorities=['Critical'] → 'my critical issues'; "
            "status='Backlog'+in_status_for_days=7+assignees=['me'] → 'my stuck backlog'; "
            "due_before=TODAY+assignees=['me'] → 'my overdue tickets'. "
            "If the user asks about a ticket but doesn't give a key, search here first."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "project_key": {
                    "type": "string",
                    "description": "Project identifier like 'PROJ' or 'MAIN'",
                },
                "status": {
                    "type": "string",
                    "description": "Filter to a specific status column (e.g. 'In Progress')",
                },
                "assignees": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Filter by assignees. Must be a JSON array, e.g. [\"me\"] or [\"alice@co.com\"].",
                },
                "keyword": {
                    "type": "string",
                    "description": "Search text across ticket title, description, and comments",
                },
                "priorities": {
                    "type": "array",
                    "items": {"type": "string", "enum": ["Low", "Medium", "High", "Critical"]},
                    "description": "Filter by priority levels",
                },
                "issue_types": {
                    "type": "array",
                    "items": {"type": "string", "enum": ["Task", "Bug", "Story", "Epic"]},
                    "description": "Filter by issue types",
                },
                "tags": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Filter by tag labels",
                },
                "limit": {
                    "type": "integer",
                    "description": "Max tickets to return (default 100)",
                    "default": 100,
                },
                "created_after":  {"type": "string", "description": "ISO date YYYY-MM-DD. Only tickets created on or after this date."},
                "created_before": {"type": "string", "description": "ISO date YYYY-MM-DD. Only tickets created on or before this date."},
                "updated_after":  {"type": "string", "description": "ISO date YYYY-MM-DD. Only tickets updated on or after this date."},
                "updated_before": {"type": "string", "description": "ISO date YYYY-MM-DD. Only tickets updated on or before this date."},
                "due_before":     {"type": "string", "description": "ISO date YYYY-MM-DD. Only tickets with a due date on or before this date. Use for overdue queries."},
                "due_after":      {"type": "string", "description": "ISO date YYYY-MM-DD. Only tickets with a due date on or after this date."},
                "in_status_for_days": {"type": "integer", "description": "Only tickets in their current status for at least this many days. Combine with 'status' for 'stuck in Backlog for 7 days' queries."},
                "scheduled_only": {"type": "boolean", "description": "If true, list only scheduled (pending activation) tickets instead of active tickets.", "default": False},
            },
            "required": ["project_key"],
        },
    ),
    Tool(
        name="search_tickets_semantic",
        description=(
            "Semantic/conceptual search for tickets using meaning and context, not exact keywords. "
            "Use when the user asks conceptual questions like 'auth-related bugs', "
            "'tasks about the payment flow', or 'issues similar to X'. "
            "Complements list_tickets (which does exact keyword matching). "
            "project_key is optional — omit to search across all accessible projects."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Natural language search query",
                },
                "project_key": {
                    "type": "string",
                    "description": "Project identifier to scope search (optional, e.g. 'PROJ')",
                },
                "limit": {
                    "type": "integer",
                    "description": "Max results to return (default 20)",
                    "default": 20,
                },
            },
            "required": ["query"],
        },
    ),
    Tool(
        name="get_ticket",
        description=(
            "Get full details of a specific ticket by its key (e.g. PROJ-123). "
            "Returns description, comments, child tasks, assignees, and all metadata. "
            "Use this after finding a ticket via list_tickets, or when the user provides "
            "a specific ticket key."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "ticket_key": {
                    "type": "string",
                    "description": "Ticket key like 'PROJ-123' or a UUID",
                },
            },
            "required": ["ticket_key"],
        },
    ),
    Tool(
        name="create_ticket",
        description=(
            "Create a new ticket. Requires project_key and title at minimum. "
            "Status defaults to the first column if not specified. "
            "You can assign to the current user with assignees=['me']. "
            "Call get_workspace_context first to know valid project keys and statuses."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "project_key": {
                    "type": "string",
                    "description": "Project identifier like 'PROJ'",
                },
                "title": {"type": "string", "description": "Ticket title"},
                "description": {"type": "string", "description": "Ticket body as markdown. Do NOT repeat the title as a heading — the title is displayed separately in the UI."},
                "status": {
                    "type": "string",
                    "description": "Status column (validated against project statuses)",
                },
                "priority": {
                    "type": "string",
                    "enum": ["Low", "Medium", "High", "Critical"],
                    "description": "Ticket priority",
                },
                "issue_type": {
                    "type": "string",
                    "enum": ["Task", "Bug", "Story", "Epic"],
                    "description": "Ticket type",
                },
                "assignees": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Array of assignee emails, names, or 'me'. Must be a JSON array, e.g. [\"me\"] or [\"alice@co.com\"].",
                },
                "labels": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Array of tag labels, e.g. [\"bug\", \"frontend\"].",
                },
                "sprint": {
                    "type": "string",
                    "description": "Sprint name to add the ticket to",
                },
                "scheduled_activation_at": {
                    "type": "string",
                    "description": "ISO 8601 datetime for scheduled activation. IMPORTANT: Use the user's local timezone offset, NOT 'Z' (UTC). Example: '2026-03-25T09:00:00-07:00' for 9 AM Pacific. Ticket is hidden until this time, then appears on the board and sends a notification.",
                },
            },
            "required": ["project_key", "title"],
        },
    ),
    Tool(
        name="update_tickets",
        description=(
            "Update one or more tickets. Pass an array of updates — each specifies a ticket_key "
            "and the fields to change. Use this for status changes, reassignment, priority changes, "
            "etc. Accepts batch updates in a single call for efficiency."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "updates": {
                    "type": "array",
                    "description": "Array of updates to apply",
                    "items": {
                        "type": "object",
                        "properties": {
                            "ticket_key": {
                                "type": "string",
                                "description": "Ticket key like 'PROJ-123'",
                            },
                            "title": {"type": "string"},
                            "description": {"type": "string", "description": "Ticket body as markdown. Do NOT repeat the title as a heading."},
                            "status": {"type": "string"},
                            "priority": {
                                "type": "string",
                                "enum": ["Low", "Medium", "High", "Critical"],
                            },
                            "issue_type": {
                                "type": "string",
                                "enum": ["Task", "Bug", "Story", "Epic"],
                            },
                            "assignees": {
                                "type": "array",
                                "items": {"type": "string"},
                                "description": "Array of assignee emails/names. Must be a JSON array, e.g. [\"me\"].",
                            },
                            "labels": {
                                "type": "array",
                                "items": {"type": "string"},
                            },
                            "due_date": {
                                "type": "string",
                                "description": "ISO date (YYYY-MM-DD)",
                            },
                            "scheduled_activation_at": {
                                "type": "string",
                                "description": "ISO 8601 datetime to reschedule activation. Use the user's local timezone offset, NOT 'Z' (UTC). Example: '2026-03-25T09:00:00-07:00'. Set to empty string to activate immediately.",
                            },
                        },
                        "required": ["ticket_key"],
                    },
                },
            },
            "required": ["updates"],
        },
    ),
    Tool(
        name="delete_tickets",
        description=(
            "Delete one or more tickets. Tickets, their child tasks, and sub-tasks are all "
            "soft-deleted and restorable from the Trash icon in the project header. "
            "Accepts a batch of ticket keys in one call."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "ticket_keys": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Ticket keys to delete, e.g. ['PROJ-123', 'PROJ-124']. Must be a JSON array.",
                    "minItems": 1,
                },
            },
            "required": ["ticket_keys"],
        },
    ),
    Tool(
        name="restore_tickets",
        description=(
            "Restore one or more previously deleted tickets. Also restores their child tasks "
            "and sub-tasks. Use this to undo deletions."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "ticket_keys": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Ticket keys to restore, e.g. ['PROJ-123']. Must be a JSON array.",
                    "minItems": 1,
                },
            },
            "required": ["ticket_keys"],
        },
    ),
    Tool(
        name="move_ticket",
        description=(
            "Reposition a ticket within its status column or move it to a different column. "
            "Supports: 'top', 'bottom', 'before:<KEY>', 'after:<KEY>', 'up:<N>', 'down:<N>', 'at:<N>'. "
            "Use 'up:3' or 'down:2' for relative moves within the same column. "
            "Use 'at:3' for absolute positioning (place at position 3) — works for cross-status moves too. "
            "All position modes fetch fresh column order automatically. "
            "Can also reorder multiple tickets or sort a column by a field. "
            "Add 'sprint' to position within a sprint column instead of the kanban column."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "ticket_key": {
                    "type": "string",
                    "description": "Ticket key like 'PROJ-123' (for top/bottom/before/after)",
                },
                "position": {
                    "type": "string",
                    "description": (
                        "One of: 'top', 'bottom', 'before:PROJ-456', 'after:PROJ-456', "
                        "'up:N', 'down:N' (relative), 'at:N' (absolute position, 1-indexed), "
                        "'reorder', 'sort'"
                    ),
                },
                "status": {
                    "type": "string",
                    "description": "Target status column. Required for reorder/sort.",
                },
                "sprint": {
                    "type": "string",
                    "description": "Sprint name. If provided, positions within this sprint's column instead of the kanban column.",
                },
                "ticket_keys": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Ticket keys in desired order (for 'reorder' position only)",
                },
                "sort_by": {
                    "type": "string",
                    "enum": ["priority", "assignee", "type", "created", "updated", "due_date"],
                    "description": "Field to sort by (for 'sort' position only)",
                },
                "reverse": {
                    "type": "boolean",
                    "description": "Reverse sort order (for 'sort' position only)",
                },
                "project_key": {
                    "type": "string",
                    "description": "Project key (required for reorder/sort)",
                },
            },
            "required": ["position"],
        },
    ),
    Tool(
        name="manage_child_task",
        description="Create, update, or delete a child task on a ticket. Use list_child_tasks first to see existing child tasks.",
        inputSchema={
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["create", "update", "delete"],
                    "description": "Action to perform",
                },
                "ticket_key": {
                    "type": "string",
                    "description": "Parent ticket key like 'PROJ-123' (required for create)",
                },
                "child_task_key": {
                    "type": "string",
                    "description": "Child task key like 'PROJ-123A' (required for update/delete)",
                },
                "title": {"type": "string", "description": "Title (required for create)"},
                "description": {"type": "string"},
                "status": {"type": "string"},
                "priority": {
                    "type": "string",
                    "enum": ["Low", "Medium", "High", "Critical"],
                },
                "assignee": {"type": "string", "description": "Assignee email or name"},
                "due_date": {"type": "string", "description": "ISO date (YYYY-MM-DD)"},
            },
            "required": ["action"],
        },
    ),
    Tool(
        name="manage_sub_task",
        description="Create, update, or delete a sub-task on a child task. Use list_child_tasks first to see existing sub-tasks.",
        inputSchema={
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["create", "update", "delete"],
                    "description": "Action to perform",
                },
                "child_task_key": {
                    "type": "string",
                    "description": "Parent child task key like 'PROJ-123A' (required for create)",
                },
                "sub_task_key": {
                    "type": "string",
                    "description": "Sub-task key like 'PROJ-123A-1' (required for update/delete)",
                },
                "title": {"type": "string", "description": "Title (required for create)"},
                "status": {"type": "string"},
                "priority": {
                    "type": "string",
                    "enum": ["Low", "Medium", "High", "Critical"],
                },
                "assignee": {"type": "string", "description": "Assignee email or name"},
            },
            "required": ["action"],
        },
    ),
    Tool(
        name="manage_comment",
        description="Add, edit, or delete a comment on a ticket. Use list_comments first to see existing comments and get comment IDs for edit/delete.",
        inputSchema={
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["add", "edit", "delete"],
                    "description": "Action to perform",
                },
                "ticket_key": {"type": "string", "description": "Ticket key like 'PROJ-123'"},
                "text": {
                    "type": "string",
                    "description": "Comment content (required for add/edit)",
                },
                "comment_id": {
                    "type": "string",
                    "description": "Comment UUID (required for edit/delete)",
                },
            },
            "required": ["action", "ticket_key"],
        },
    ),
    Tool(
        name="list_sprints",
        description="List sprints for a project with their status, dates, and ticket counts.",
        inputSchema={
            "type": "object",
            "properties": {
                "project_key": {
                    "type": "string",
                    "description": "Project identifier like 'PROJ'",
                },
            },
            "required": ["project_key"],
        },
    ),
    Tool(
        name="manage_sprint",
        description=(
            "Create or update a sprint. When creating, start date defaults to today "
            "and end date defaults to start + 14 days."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["create", "update"],
                    "description": "Action to perform",
                },
                "project_key": {"type": "string", "description": "Project identifier"},
                "sprint_name": {"type": "string", "description": "Sprint name"},
                "new_name": {"type": "string", "description": "New name (for rename on update)"},
                "start_date": {"type": "string", "description": "Start date (YYYY-MM-DD)"},
                "end_date": {"type": "string", "description": "End date (YYYY-MM-DD)"},
                "description": {"type": "string"},
                "status": {
                    "type": "string",
                    "enum": ["planned", "active", "completed"],
                    "description": "Sprint status (update only)",
                },
            },
            "required": ["action", "project_key", "sprint_name"],
        },
    ),
    Tool(
        name="manage_sprint_tickets",
        description="Add, remove, or reorder tickets in a sprint. For reorder, pass ticket_keys in the desired order and specify the status column.",
        inputSchema={
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["add", "remove", "reorder"],
                    "description": "Action to perform",
                },
                "sprint_name": {"type": "string", "description": "Sprint name"},
                "project_key": {"type": "string", "description": "Project identifier"},
                "ticket_keys": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Ticket keys in desired order (for reorder) or to add/remove",
                },
                "status": {
                    "type": "string",
                    "description": "Status column to reorder within (required for reorder)",
                },
            },
            "required": ["action", "sprint_name", "project_key", "ticket_keys"],
        },
    ),
    Tool(
        name="list_child_tasks",
        description="List all child tasks and their sub-tasks for a ticket. Shows status, priority, and assignee for each. Use this before managing child tasks or sub-tasks.",
        inputSchema={
            "type": "object",
            "properties": {
                "ticket_key": {"type": "string", "description": "Ticket key like 'PROJ-123'"},
            },
            "required": ["ticket_key"],
        },
    ),
    Tool(
        name="list_comments",
        description="List all comments on a ticket with author, date, and content. Returns comment IDs needed for edit/delete operations.",
        inputSchema={
            "type": "object",
            "properties": {
                "ticket_key": {"type": "string", "description": "Ticket key like 'PROJ-123'"},
            },
            "required": ["ticket_key"],
        },
    ),
    Tool(
        name="list_sprint_tickets",
        description="List all tickets in a specific sprint, grouped by status column with position numbers. Use this to see sprint column ordering before move_ticket calls. Use list_sprints first to find the sprint name.",
        inputSchema={
            "type": "object",
            "properties": {
                "sprint_name": {"type": "string", "description": "Sprint name"},
                "project_key": {"type": "string", "description": "Project identifier"},
            },
            "required": ["sprint_name", "project_key"],
        },
    ),
    Tool(
        name="list_documents",
        description=(
            "List documents in the workspace. By default lists all org-wide (non-private) "
            "documents. Set my_docs=true to list only documents created by or shared with "
            "the current user (including private ones). Use keyword to filter by title."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "my_docs": {
                    "type": "boolean",
                    "description": "If true, return only documents created by or shared with the current user.",
                },
                "keyword": {
                    "type": "string",
                    "description": "Filter documents whose title contains this text (case-insensitive).",
                },
            },
            "required": [],
        },
    ),
    Tool(
        name="get_document",
        description=(
            "Get the full content of a document by its ID. Returns the title, metadata, "
            "and content as plain text. Use list_documents first to find document IDs."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "document_id": {
                    "type": "string",
                    "description": "Document UUID",
                },
            },
            "required": ["document_id"],
        },
    ),
    Tool(
        name="create_document",
        description=(
            "Create a new document in the workspace. Accepts a title and optional markdown "
            "content. Documents are private by default (only the creator can view); set "
            "is_private=false to make the document visible to all org members."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "title": {
                    "type": "string",
                    "description": "Document title",
                },
                "content": {
                    "type": "string",
                    "description": "Document body as markdown. Do NOT repeat the title as a heading — the title is displayed separately in the UI.",
                },
                "is_private": {
                    "type": "boolean",
                    "description": "If true, only the creator can view the document (default true). Set false for org-wide.",
                },
            },
            "required": ["title"],
        },
    ),
    Tool(
        name="update_document",
        description=(
            "Update the title and/or content of an existing document. Supply only the fields "
            "you want to change — omitted fields are left untouched. Requires editor or owner "
            "access. Use list_documents or get_document to find the document_id first."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "document_id": {
                    "type": "string",
                    "description": "Document UUID",
                },
                "title": {
                    "type": "string",
                    "description": "New document title (optional)",
                },
                "content": {
                    "type": "string",
                    "description": "New document body as markdown. Do NOT repeat the title as a heading.",
                },
            },
            "required": ["document_id"],
        },
    ),
    Tool(
        name="web_search",
        description=(
            "Search the web for current information — best practices, libraries, "
            "error messages, documentation, news, etc. Returns an AI-generated answer plus sources."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "The search query"},
                "max_results": {"type": "integer", "description": "Number of results (default 5)", "default": 5},
            },
            "required": ["query"],
        },
    ),
    Tool(
        name="get_platform_guidance",
        description=(
            "Get guidance on how to navigate and use the Janet AI platform. "
            "Call this when users ask 'how do I...?', 'where do I click for...?', "
            "'how does X feature work?', or any question about using the UI or platform features. "
            "Returns full documentation covering all features and navigation."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "The user's navigation or how-to question"},
            },
            "required": ["query"],
        },
    ),
    Tool(
        name="add_api_key",
        description=(
            "Save a named API key to your local config so you can switch between "
            "organizations without restarting. Optionally activate it immediately."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Alias for this key (e.g. 'staging', 'prod')"},
                "key": {"type": "string", "description": "The API key value from janet.ai → Organization Settings → API Keys"},
                "switch_to": {"type": "boolean", "description": "Activate this key immediately (default false)", "default": False},
            },
            "required": ["name", "key"],
        },
    ),
    Tool(
        name="switch_organization",
        description="Switch to a previously saved named API key / organization.",
        inputSchema={
            "type": "object",
            "properties": {
                "key_name": {"type": "string", "description": "Name of the saved key to activate"},
            },
            "required": ["key_name"],
        },
    ),
    Tool(
        name="remove_api_key",
        description="Remove a saved named API key from your local config.",
        inputSchema={
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Name of the key to remove"},
            },
            "required": ["name"],
        },
    ),
    Tool(
        name="sign_out",
        description="Sign out by clearing the active API key. Saved keys are preserved.",
        inputSchema={"type": "object", "properties": {}, "required": []},
    ),
    Tool(
        name="list_api_keys",
        description=(
            "List all saved named API keys and which one is currently active. "
            "Call this before switch_organization to see available key names."
        ),
        inputSchema={"type": "object", "properties": {}, "required": []},
    ),
]


@server.list_tools()
async def list_tools() -> List[Tool]:
    return TOOLS


# ── Tool handlers ───────────────────────────────────────────────────────────


def _resolve_user_email(cm: ConfigManager) -> str:
    """Get the current user's email, falling back to API if not in config."""
    config = cm.get()
    email = config.auth.user_email if config.auth else None
    if email:
        return email
    profile = _fetch_user_profile(cm)
    return profile["email"]


def _resolve_assignee_filter(
    assignees: List[str], project_id: str, cm: ConfigManager
) -> List[str]:
    """Resolve assignee filter values — handles 'me' and name lookups."""
    resolved = []
    for a in assignees:
        if a.strip().lower() in ("me", "myself"):
            email = _resolve_user_email(cm)
            if not email:
                raise ResolutionError("Cannot resolve 'me' - user email not found.")
            resolved.append(email)
        else:
            resolved.append(a)
    # For non-"me" values, try to resolve names to emails
    needs_resolve = [r for r in resolved if "@" not in r and r.lower() != "unassigned"]
    if needs_resolve:
        resolved_all = resolve_assignees(resolved, project_id, cm)
        return resolved_all
    return resolved


def _text(content: str) -> List[TextContent]:
    return [TextContent(type="text", text=content)]


def _fetch_user_profile(cm: ConfigManager) -> Dict:
    """Fetch user profile from API. Returns dict with email and name."""
    from janet.api.client import APIClient

    try:
        client = APIClient(cm)
        profile = client.get("/api/v1/user/profile", include_org=True)
        user = profile.get("user", {})
        return {
            "email": user.get("email", ""),
            "name": user.get("name", user.get("fullName", "")),
        }
    except Exception:
        return {"email": "", "name": ""}


_workspace_cache: Dict[str, Any] | None = None


def _handle_get_workspace_context(args: Dict) -> str:
    global _workspace_cache
    if _workspace_cache is not None:
        return _workspace_cache

    from janet.api.projects import ProjectAPI
    from concurrent.futures import ThreadPoolExecutor

    cm = _get_config()
    config = cm.get()
    user_email = config.auth.user_email or ""
    user_name = ""

    # Fallback: fetch from API if not in stored config
    if not user_email:
        profile = _fetch_user_profile(cm)
        user_email = profile["email"] or "unknown"
        user_name = profile["name"]

    org = config.selected_organization
    org_name = org.name if org else "unknown"
    org_id = org.id if org else "unknown"

    project_api = ProjectAPI(cm)
    projects = project_api.list_projects()

    # Fetch columns + members in parallel (2 calls per project, all at once)
    projects_columns: Dict[str, list] = {}
    projects_members: Dict[str, list] = {}

    def fetch_columns(pid: str):
        try:
            return pid, project_api.get_project_columns(pid)
        except Exception:
            return pid, []

    def fetch_members(pid: str):
        try:
            return pid, project_api.list_project_members(pid)
        except Exception:
            return pid, []

    pids = [p["id"] for p in projects]
    with ThreadPoolExecutor(max_workers=10) as pool:
        col_futures = pool.map(fetch_columns, pids)
        mem_futures = pool.map(fetch_members, pids)
        for pid, cols in col_futures:
            projects_columns[pid] = cols
        for pid, mems in mem_futures:
            projects_members[pid] = mems

    # Determine active key display info
    _env_key = os.environ.get("JANET_API_KEY")
    _file_cfg = ConfigManager().get()
    if _env_key:
        _key_name = "env"
        _key_masked = "●●●●" + _env_key[-4:]
    elif _file_cfg.active_key_name:
        _key_name = _file_cfg.active_key_name
        _raw = _file_cfg.api_keys.get(_file_cfg.active_key_name, "")
        _key_masked = ("●●●●" + _raw[-4:]) if len(_raw) >= 4 else "●●●●"
    else:
        _key_name = None
        _key_masked = None

    result = formatters.format_workspace_context(
        user_email, org_name, org_id, projects, projects_columns, projects_members,
        user_name=user_name,
        active_key_name=_key_name,
        masked_key=_key_masked,
    )
    _workspace_cache = result
    return result


def _handle_list_tickets(args: Dict) -> str:
    from janet.api.tickets import TicketAPI

    cm = _get_config()
    project = resolve_project(args["project_key"], cm)
    project_id = project["id"]
    proj_key = project.get("project_identifier", "?")

    single_status = args.get("status")
    limit = args.get("limit", 100)

    # Resolve assignee filter — handle "me"
    assignees = args.get("assignees")
    if assignees:
        assignees = _resolve_assignee_filter(assignees, project_id, cm)

    ticket_api = TicketAPI(cm)

    _date_filter_keys = ["created_after","created_before","updated_after","updated_before","due_before","due_after","in_status_for_days"]
    has_date_filter = any(args.get(k) for k in _date_filter_keys)

    # ── Position-ordered path: single status, no keyword search ──
    # Returns tickets in kanban column order so the LLM can determine
    # ordinal position for relative moves (e.g. "move ticket 1 down").
    if single_status and not args.get("keyword") and not has_date_filter and not assignees:
        status = resolve_status(single_status, project_id, cm) if project_id else single_status
        positions = ticket_api.get_positions(project_id, status=status)
        ticket_ids = [p["ticket_id"] for p in positions]

        if not ticket_ids:
            return f"No tickets in '{status}'."

        # Batch fetch full ticket objects, respecting limit
        fetch_ids = ticket_ids[:limit]
        tickets_raw = ticket_api.batch_fetch(fetch_ids)

        # Re-order to match position order and attach lexo positions
        ticket_map = {t["id"]: t for t in tickets_raw}
        pos_map = {p["ticket_id"]: p.get("position", "") for p in positions}
        tickets = []
        for tid in fetch_ids:
            if tid in ticket_map:
                ticket_map[tid]["_lexo_position"] = pos_map.get(tid, "")
                tickets.append(ticket_map[tid])

        # Apply additional filters client-side if provided
        if assignees:
            assignee_set = set(a.lower() for a in assignees)
            tickets = [t for t in tickets if any(
                (a.get("email", a.get("userEmail", "")).lower() if isinstance(a, dict) else a.lower()) in assignee_set
                for a in t.get("assignees", [])
            )]
        if args.get("priorities"):
            prio_set = set(p.lower() for p in args["priorities"])
            tickets = [t for t in tickets if t.get("priority", "").lower() in prio_set]
        if args.get("issue_types"):
            type_set = set(it.lower() for it in args["issue_types"])
            tickets = [t for t in tickets if t.get("issue_type", "").lower() in type_set]

        # Inject ticket keys
        for t in tickets:
            if not t.get("ticket_key"):
                tid = t.get("ticket_identifier", "?")
                if isinstance(tid, str) and tid.upper().startswith(proj_key.upper()):
                    t["ticket_key"] = tid
                else:
                    t["ticket_key"] = f"{proj_key}-{tid}"

        return formatters.format_ticket_list_by_column(
            {status: tickets}, total_count=len(ticket_ids)
        )

    # ── Standard path: multi-status, keyword, or no filter ──
    statuses = [single_status] if single_status else None
    has_filter = any([assignees, args.get("keyword"), args.get("priorities"),
                      args.get("issue_types"), args.get("tags"), statuses, has_date_filter])
    filter_kwargs = dict(
        statuses=statuses,
        assignees=assignees,
        keyword=args.get("keyword"),
        priorities=args.get("priorities"),
        issue_types=args.get("issue_types"),
        tags=args.get("tags"),
        order_by="last_updated" if has_filter else None,
        created_after=args.get("created_after"),
        created_before=args.get("created_before"),
        updated_after=args.get("updated_after"),
        updated_before=args.get("updated_before"),
        due_before=args.get("due_before"),
        due_after=args.get("due_after"),
        in_status_for_days=args.get("in_status_for_days"),
        scheduled_only=args.get("scheduled_only", False),
    )

    # Fetch display page
    result = ticket_api.list_tickets(project_id, limit=limit, **filter_kwargs)
    tickets = result.get("items", []) or result.get("tickets", [])
    total = result.get("total_tickets", len(tickets))

    # If there are more tickets than returned, paginate to get full status counts
    all_tickets = list(tickets)
    if result.get("has_more") and has_filter:
        offset = result.get("next_offset", len(tickets))
        while offset < total:
            page = ticket_api.list_tickets(project_id, limit=500, offset=offset, **filter_kwargs)
            page_items = page.get("items", []) or page.get("tickets", [])
            if not page_items:
                break
            all_tickets.extend(page_items)
            if not page.get("has_more"):
                break
            offset = page.get("next_offset", offset + len(page_items))

    # Inject project key for formatting
    for t in all_tickets:
        if not t.get("ticket_key"):
            tid = t.get("ticket_identifier", "?")
            if isinstance(tid, str) and tid.upper().startswith(proj_key.upper()):
                t["ticket_key"] = tid
            else:
                t["ticket_key"] = f"{proj_key}-{tid}"

    # Count statuses from ALL matching tickets, display first `limit`
    display_tickets = all_tickets[:limit]
    output = formatters.format_ticket_list(display_tickets, total_count=total, all_tickets=all_tickets)
    return output


def _handle_get_ticket(args: Dict) -> str:
    from janet.api.tickets import TicketAPI

    cm = _get_config()
    info = resolve_ticket_key(args["ticket_key"], cm)
    ticket_api = TicketAPI(cm)
    ticket = ticket_api.get_ticket(info["ticket_id"])

    if info.get("project_key") and info.get("ticket_identifier"):
        ticket["ticket_key"] = f"{info['project_key']}-{info['ticket_identifier']}"

    return formatters.format_ticket(ticket)


def _handle_create_ticket(args: Dict) -> str:
    from janet.api.tickets import TicketAPI
    from janet.api.sprints import SprintAPI

    cm = _get_config()
    project = resolve_project(args["project_key"], cm)
    project_id = project["id"]

    status = resolve_status(args.get("status"), project_id, cm)

    assignees = args.get("assignees")
    if assignees:
        assignees = resolve_assignees(assignees, project_id, cm)

    ticket_api = TicketAPI(cm)
    result = ticket_api.create_ticket(
        project_id=project_id,
        title=args["title"],
        description=args.get("description"),
        status=status,
        priority=args.get("priority"),
        issue_type=args.get("issue_type"),
        assignees=assignees,
        labels=args.get("labels"),
        scheduled_activation_at=args.get("scheduled_activation_at"),
    )

    ticket = result.get("ticket", result)
    proj_key = project.get("project_identifier", "?")
    ticket_num = ticket.get("ticket_identifier", "?")
    ticket_key = f"{proj_key}-{ticket_num}"

    scheduled_at = args.get("scheduled_activation_at")

    # Add to sprint if specified
    sprint_name = args.get("sprint")
    if sprint_name:
        sprint = resolve_sprint(sprint_name, project_id, cm)
        sprint_api = SprintAPI(cm)
        sprint_api.add_ticket(ticket["id"], sprint["id"], project_id)
        if scheduled_at:
            return f"Scheduled {ticket_key}: {args['title']} for {scheduled_at} and added to sprint '{sprint_name}'."
        return f"Created {ticket_key}: {args['title']} and added to sprint '{sprint_name}'."

    if scheduled_at:
        return f"Scheduled {ticket_key}: {args['title']} for activation at {scheduled_at}."
    return f"Created {ticket_key}: {args['title']}"


def _handle_update_tickets(args: Dict) -> str:
    from janet.api.tickets import TicketAPI

    cm = _get_config()
    ticket_api = TicketAPI(cm)
    updates = args["updates"]
    results = []

    for upd in updates:
        info = resolve_ticket_key(upd["ticket_key"], cm)
        ticket_id = info["ticket_id"]
        project_id = info.get("project_id")

        # Resolve assignees if provided
        assignees = upd.get("assignees")
        if assignees and project_id:
            assignees = resolve_assignees(assignees, project_id, cm)

        # Resolve status if provided
        status = upd.get("status")
        if status and project_id:
            status = resolve_status(status, project_id, cm)

        ticket_api.update_ticket(
            ticket_id=ticket_id,
            title=upd.get("title"),
            description=upd.get("description"),
            status=status,
            priority=upd.get("priority"),
            issue_type=upd.get("issue_type"),
            assignees=assignees,
            labels=upd.get("labels"),
            due_date=upd.get("due_date"),
            scheduled_activation_at=upd.get("scheduled_activation_at"),
        )
        results.append(f"Updated {upd['ticket_key']}")

    return "\n".join(results)


def _handle_delete_tickets(args: Dict) -> str:
    from janet.api.tickets import TicketAPI

    cm = _get_config()
    ticket_api = TicketAPI(cm)
    ticket_keys = args["ticket_keys"]
    results = []

    for key in ticket_keys:
        info = resolve_ticket_key(key, cm)
        ticket_api.delete_ticket(info["ticket_id"])
        results.append(key)

    deleted_list = ", ".join(results)
    return f"Deleted: {deleted_list}"


def _handle_restore_tickets(args: Dict) -> str:
    from janet.api.tickets import TicketAPI

    cm = _get_config()
    ticket_api = TicketAPI(cm)
    ticket_keys = args["ticket_keys"]
    results = []

    for key in ticket_keys:
        parts = key.upper().rsplit("-", 1)
        if len(parts) != 2 or not parts[1].isdigit():
            raise ResolutionError(f"Invalid ticket key: {key}")
        project_key, ticket_num = parts[0], int(parts[1])
        lookup = ticket_api.get_deleted_ticket_by_key(project_key, ticket_num)
        ticket_id = lookup.get("ticket_id")
        if not ticket_id:
            raise ResolutionError(f"Deleted ticket {key} not found")
        ticket_api.restore_ticket(ticket_id)
        results.append(key)

    return f"Restored: {', '.join(results)}"


def _handle_move_ticket(args: Dict) -> str:
    from janet.api.tickets import TicketAPI
    from janet.utils.lexo_position import generate_between, generate_evenly_spaced

    cm = _get_config()
    ticket_api = TicketAPI(cm)
    position = args["position"]

    # ── Sort entire column ──
    if position == "sort":
        project_key = args.get("project_key")
        status = args.get("status")
        if not project_key or not status:
            raise ResolutionError("project_key and status are required for sort")
        project = resolve_project(project_key, cm)
        sort_by = args.get("sort_by", "priority")
        sort_map = {"due-date": "due_date"}
        result = ticket_api.sort_column(
            project["id"], status, sort_map.get(sort_by, sort_by), args.get("reverse", False)
        )
        return f"Sorted {result.get('count', '?')} tickets in '{status}' by {sort_by}"

    # ── Reorder multiple tickets ──
    if position == "reorder":
        ticket_keys = args.get("ticket_keys")
        status = args.get("status")
        if not ticket_keys or not status:
            raise ResolutionError("ticket_keys and status are required for reorder")
        resolved = resolve_ticket_keys_batch(ticket_keys, cm)
        positions = generate_evenly_spaced(len(resolved))
        bulk_data = [
            {"ticket_id": r["ticket_id"], "position": pos, "status": status}
            for r, pos in zip(resolved, positions)
        ]
        ticket_api.bulk_set_positions(bulk_data)
        return f"Reordered {len(ticket_keys)} tickets in '{status}'"

    # ── Single ticket positioning (top/bottom/before/after) ──
    ticket_key = args.get("ticket_key")
    if not ticket_key:
        raise ResolutionError("ticket_key is required for top/bottom/before/after")

    info = resolve_ticket_key(ticket_key, cm)
    ticket_id = info["ticket_id"]

    # Resolve target status
    status = args.get("status")
    if status and info.get("project_id"):
        status = resolve_status(status, info["project_id"], cm)
    elif not status:
        ticket = ticket_api.get_ticket(ticket_id)
        status = ticket.get("status", "")

    # ── Relative / absolute positioning (up:N, down:N, at:N) ──
    # Always fetches fresh positions so consecutive moves use current order.
    # Works for same-status AND cross-status moves.
    is_relative = position.startswith("up:") or position.startswith("down:")
    is_absolute = position.startswith("at:")

    if is_relative or is_absolute:
        try:
            n = int(position.split(":", 1)[1])
        except ValueError:
            raise ResolutionError(f"Invalid number in '{position}'. Use up:N, down:N, or at:N.")

        sprint_name = args.get("sprint")
        if sprint_name and info.get("project_id"):
            from janet.api.sprints import SprintAPI
            sprint_api = SprintAPI(cm)
            sprint = resolve_sprint(sprint_name, info["project_id"], cm)
            sprint_id = sprint["id"]
            sprint_positions = sprint_api.get_positions(sprint_id, status=status)
            sprint_positions = [p for p in sprint_positions if p.get("status") == status]
            # Exclude the ticket itself so indices are stable for cross-status
            others = [p for p in sprint_positions if p["ticket_id"] != ticket_id]
            ids = [p["ticket_id"] for p in others]

            if is_absolute:
                # at:N — 1-indexed absolute position
                target_idx = max(0, min(n - 1, len(ids)))
            else:
                # up:N / down:N — relative to current position
                all_ids = [p["ticket_id"] for p in sprint_positions]
                if ticket_id in all_ids:
                    current_idx = all_ids.index(ticket_id)
                    # Adjust for the ticket being removed from the list
                    adj_idx = current_idx  # position in 'others' list = same if before self
                    target_idx = max(0, adj_idx - n) if position.startswith("up:") else min(len(ids), adj_idx + n)
                else:
                    # Cross-status: ticket not in this column yet, treat N as absolute
                    target_idx = max(0, min(n - 1, len(ids)))

            neighbor_above = ids[target_idx - 1] if target_idx > 0 else None
            neighbor_below = ids[target_idx] if target_idx < len(ids) else None

            sprint_api.set_ticket_position(
                sprint_id, ticket_id, neighbor_above, neighbor_below, status, info["project_id"]
            )
            return f"Moved {ticket_key} to position {target_idx + 1} in '{status}' (sprint '{sprint_name}')"
        else:
            positions_list = ticket_api.get_positions(info["project_id"], status=status)
            # Exclude the ticket itself so indices are stable for cross-status
            others = [p for p in positions_list if p["ticket_id"] != ticket_id]

            if is_absolute:
                # at:N — 1-indexed absolute position
                target_idx = max(0, min(n - 1, len(others)))
            else:
                # up:N / down:N — relative to current position
                all_ids = [p["ticket_id"] for p in positions_list]
                if ticket_id in all_ids:
                    current_idx = all_ids.index(ticket_id)
                    adj_idx = sum(1 for p in positions_list[:current_idx] if p["ticket_id"] != ticket_id)
                    target_idx = max(0, adj_idx - n) if position.startswith("up:") else min(len(others), adj_idx + n)
                else:
                    # Cross-status: ticket not in this column yet, treat N as absolute
                    target_idx = max(0, min(n - 1, len(others)))

            above_pos = others[target_idx - 1].get("position") if target_idx > 0 else None
            below_pos = others[target_idx].get("position") if target_idx < len(others) else None
            new_pos = generate_between(above_pos, below_pos)
            ticket_api.set_position(ticket_id, new_pos, status)

            return f"Moved {ticket_key} to position {target_idx + 1} in '{status}'"

    # ── Sprint positioning path ──
    sprint_name = args.get("sprint")
    if sprint_name and info.get("project_id"):
        from janet.api.sprints import SprintAPI
        sprint_api = SprintAPI(cm)
        sprint = resolve_sprint(sprint_name, info["project_id"], cm)
        sprint_id = sprint["id"]

        # Get current ordered positions in this sprint column
        sprint_positions = sprint_api.get_positions(sprint_id, status=status)
        # Filter to just this status
        sprint_positions = [p for p in sprint_positions if p.get("status") == status]

        if position == "top":
            neighbor_above = None
            neighbor_below = sprint_positions[0]["ticket_id"] if sprint_positions else None
        elif position == "bottom":
            neighbor_above = sprint_positions[-1]["ticket_id"] if sprint_positions else None
            neighbor_below = None
        elif position.startswith("before:") or position.startswith("after:"):
            is_before = position.startswith("before:")
            target_key = position.split(":", 1)[1]
            target_info = resolve_ticket_key(target_key, cm)
            target_id = target_info["ticket_id"]
            ids = [p["ticket_id"] for p in sprint_positions]
            try:
                idx = ids.index(target_id)
            except ValueError:
                raise ResolutionError(f"Ticket '{target_key}' not found in sprint '{sprint_name}' ({status})")
            if is_before:
                neighbor_above = ids[idx - 1] if idx > 0 else None
                neighbor_below = target_id
            else:
                neighbor_above = target_id
                neighbor_below = ids[idx + 1] if idx < len(ids) - 1 else None
        else:
            raise ResolutionError(f"Unsupported position '{position}' for sprint. Use top, bottom, before:KEY, after:KEY, up:N, down:N, or at:N.")

        sprint_api.set_ticket_position(
            sprint_id, ticket_id, neighbor_above, neighbor_below, status, info["project_id"]
        )
        return f"Moved {ticket_key} to {position} in sprint '{sprint_name}' ({status})"

    if position == "top":
        ticket_api.move_to_top(ticket_id, status)
        return f"Moved {ticket_key} to top of '{status}'"

    if position == "bottom":
        ticket_api.set_position(ticket_id, "zzzzz", status)
        return f"Moved {ticket_key} to bottom of '{status}'"

    # before:KEY or after:KEY
    if position.startswith("before:") or position.startswith("after:"):
        is_before = position.startswith("before:")
        target_key = position.split(":", 1)[1]
        target_info = resolve_ticket_key(target_key, cm)
        target_ticket = ticket_api.get_ticket(target_info["ticket_id"])
        target_status = target_ticket.get("status", status)
        target_pos = target_ticket.get("position")

        # Get ordered tickets in that column
        positions_list = ticket_api.get_positions(info["project_id"], status=target_status)

        if is_before:
            above_pos = None
            for i, t in enumerate(positions_list):
                if t.get("ticket_id") == target_info["ticket_id"] and i > 0:
                    above_pos = positions_list[i - 1].get("position")
                    break
            new_pos = generate_between(above_pos, target_pos)
        else:
            below_pos = None
            for i, t in enumerate(positions_list):
                if t.get("ticket_id") == target_info["ticket_id"] and i < len(positions_list) - 1:
                    below_pos = positions_list[i + 1].get("position")
                    break
            new_pos = generate_between(target_pos, below_pos)

        ticket_api.set_position(ticket_id, new_pos, target_status)
        direction = "before" if is_before else "after"
        return f"Moved {ticket_key} {direction} {target_key} in '{target_status}'"

    raise ResolutionError(f"Unknown position: {position}. Use top, bottom, before:KEY, after:KEY, up:N, down:N, at:N, reorder, or sort.")


def _handle_manage_child_task(args: Dict) -> str:
    from janet.api.child_tasks import ChildTaskAPI

    cm = _get_config()
    action = args["action"]

    if action == "create":
        ticket_key = args.get("ticket_key")
        if not ticket_key:
            raise ResolutionError("ticket_key is required for create action")
        title = args.get("title")
        if not title:
            raise ResolutionError("title is required for create action")

        info = resolve_ticket_key(ticket_key, cm)
        status = resolve_status(args.get("status"), info["project_id"], cm)

        assignee = args.get("assignee")
        if assignee:
            resolved = resolve_assignees([assignee], info["project_id"], cm)
            assignee = resolved[0] if resolved else assignee

        child_api = ChildTaskAPI(cm)
        result = child_api.create_child_task(
            ticket_id=info["ticket_id"],
            project_id=info["project_id"],
            ticket_identifier=info["ticket_identifier"],
            project_identifier=info["project_key"],
            title=title,
            status=status,
            description=args.get("description"),
            priority=args.get("priority"),
            assignee=assignee,
            due_date=args.get("due_date"),
        )
        ct_id = result.get("fullIdentifier", result.get("id", "?"))
        return f"Created child task {ct_id}: {title}"

    elif action == "update":
        ct_key = args.get("child_task_key")
        if not ct_key:
            raise ResolutionError("child_task_key is required for update action")

        ct_info = resolve_child_task_key(ct_key, cm)
        child_api = ChildTaskAPI(cm)

        assignee = args.get("assignee")
        if assignee:
            resolved = resolve_assignees([assignee], ct_info["project_id"], cm)
            assignee = resolved[0] if resolved else assignee

        child_api.update_child_task(
            child_task_id=ct_info["child_task_id"],
            title=args.get("title"),
            description=args.get("description"),
            status=args.get("status"),
            priority=args.get("priority"),
            assignee=assignee,
            due_date=args.get("due_date"),
        )
        return f"Updated child task {ct_key}"

    elif action == "delete":
        ct_key = args.get("child_task_key")
        if not ct_key:
            raise ResolutionError("child_task_key is required for delete action")

        ct_info = resolve_child_task_key(ct_key, cm)
        child_api = ChildTaskAPI(cm)
        child_api.delete_child_task(ct_info["child_task_id"])
        return f"Deleted child task {ct_key}"

    raise ResolutionError(f"Unknown action: {action}")


def _handle_manage_sub_task(args: Dict) -> str:
    from janet.api.child_tasks import ChildTaskAPI

    cm = _get_config()
    action = args["action"]

    if action == "create":
        ct_key = args.get("child_task_key")
        if not ct_key:
            raise ResolutionError("child_task_key is required for create action")
        title = args.get("title")
        if not title:
            raise ResolutionError("title is required for create action")

        ct_info = resolve_child_task_key(ct_key, cm)
        child_api = ChildTaskAPI(cm)

        assignee = args.get("assignee")
        if assignee:
            resolved = resolve_assignees([assignee], ct_info["project_id"], cm)
            assignee = resolved[0] if resolved else assignee

        result = child_api.create_sub_task(
            child_task_id=ct_info["child_task_id"],
            title=title,
            status=args.get("status", "To Do"),
            priority=args.get("priority"),
            assignee=assignee,
        )
        sub = result.get("sub_task", result)
        st_id = sub.get("fullIdentifier", sub.get("id", "?"))
        return f"Created sub-task {st_id}: {title}"

    elif action == "update":
        st_key = args.get("sub_task_key")
        if not st_key:
            raise ResolutionError("sub_task_key is required for update action")

        st_info = resolve_sub_task_key(st_key, cm)
        child_api = ChildTaskAPI(cm)

        assignee = args.get("assignee")
        if assignee:
            resolved = resolve_assignees([assignee], st_info["project_id"], cm)
            assignee = resolved[0] if resolved else assignee

        child_api.update_sub_task(
            sub_task_id=st_info["sub_task_id"],
            title=args.get("title"),
            status=args.get("status"),
            priority=args.get("priority"),
            assignee=assignee,
        )
        return f"Updated sub-task {st_key}"

    elif action == "delete":
        st_key = args.get("sub_task_key")
        if not st_key:
            raise ResolutionError("sub_task_key is required for delete action")

        st_info = resolve_sub_task_key(st_key, cm)
        child_api = ChildTaskAPI(cm)
        child_api.delete_sub_task(st_info["sub_task_id"])
        return f"Deleted sub-task {st_key}"

    raise ResolutionError(f"Unknown action: {action}")


def _handle_manage_comment(args: Dict) -> str:
    from janet.api.tickets import TicketAPI

    cm = _get_config()
    action = args["action"]
    info = resolve_ticket_key(args["ticket_key"], cm)
    ticket_api = TicketAPI(cm)

    if action == "add":
        text = args.get("text")
        if not text:
            raise ResolutionError("text is required for add action")
        ticket_api.add_comment(info["ticket_id"], text)
        return f"Added comment to {args['ticket_key']}"

    elif action == "edit":
        comment_id = args.get("comment_id")
        text = args.get("text")
        if not comment_id:
            raise ResolutionError("comment_id is required for edit action")
        if not text:
            raise ResolutionError("text is required for edit action")
        ticket_api.edit_comment(info["ticket_id"], comment_id, text)
        return f"Edited comment on {args['ticket_key']}"

    elif action == "delete":
        comment_id = args.get("comment_id")
        if not comment_id:
            raise ResolutionError("comment_id is required for delete action")
        ticket_api.delete_comment(info["ticket_id"], comment_id)
        return f"Deleted comment from {args['ticket_key']}"

    raise ResolutionError(f"Unknown action: {action}")


def _handle_list_sprints(args: Dict) -> str:
    from janet.api.sprints import SprintAPI

    cm = _get_config()
    project = resolve_project(args["project_key"], cm)
    sprint_api = SprintAPI(cm)
    sprints = sprint_api.list_sprints(project["id"])
    return formatters.format_sprint_list(sprints)


def _handle_manage_sprint(args: Dict) -> str:
    from janet.api.sprints import SprintAPI

    cm = _get_config()
    action = args["action"]
    project = resolve_project(args["project_key"], cm)
    project_id = project["id"]

    sprint_api = SprintAPI(cm)

    if action == "create":
        start = args.get("start_date") or date.today().isoformat()
        end = args.get("end_date") or (date.today() + timedelta(days=14)).isoformat()

        sprint_api.create_sprint(
            project_id=project_id,
            name=args["sprint_name"],
            start_date=start,
            end_date=end,
            description=args.get("description"),
        )
        return f"Created sprint '{args['sprint_name']}' ({start} to {end})"

    elif action == "update":
        sprint = resolve_sprint(args["sprint_name"], project_id, cm)
        sprint_api.update_sprint(
            sprint_id=sprint["id"],
            name=args.get("new_name"),
            start_date=args.get("start_date"),
            end_date=args.get("end_date"),
            description=args.get("description"),
            status=args.get("status"),
        )
        return f"Updated sprint '{args['sprint_name']}'"

    raise ResolutionError(f"Unknown action: {action}")


def _handle_manage_sprint_tickets(args: Dict) -> str:
    from janet.api.sprints import SprintAPI

    cm = _get_config()
    action = args["action"]
    project = resolve_project(args["project_key"], cm)
    project_id = project["id"]

    sprint = resolve_sprint(args["sprint_name"], project_id, cm)
    sprint_id = sprint["id"]

    ticket_infos = resolve_ticket_keys_batch(args["ticket_keys"], cm)
    ticket_ids = [t["ticket_id"] for t in ticket_infos]

    sprint_api = SprintAPI(cm)

    if action == "add":
        sprint_api.bulk_add_tickets(sprint_id, ticket_ids, project_id)
        return f"Added {len(ticket_ids)} ticket(s) to sprint '{args['sprint_name']}'"

    elif action == "remove":
        sprint_api.bulk_remove_tickets(sprint_id, ticket_ids)
        return f"Removed {len(ticket_ids)} ticket(s) from sprint '{args['sprint_name']}'"

    elif action == "reorder":
        status = args.get("status")
        if not status:
            raise ResolutionError("status is required for reorder action")
        sprint_api.reorder_tickets(sprint_id, ticket_ids, status)
        return f"Reordered {len(ticket_ids)} ticket(s) in sprint '{args['sprint_name']}' ({status})"

    raise ResolutionError(f"Unknown action: {action}")


def _handle_list_child_tasks(args: Dict) -> str:
    from janet.api.child_tasks import ChildTaskAPI

    cm = _get_config()
    info = resolve_ticket_key(args["ticket_key"], cm)
    child_api = ChildTaskAPI(cm)

    child_tasks = child_api.list_child_tasks_with_subtasks(info["ticket_id"])

    return formatters.format_child_tasks(child_tasks)


def _handle_list_comments(args: Dict) -> str:
    from janet.api.tickets import TicketAPI

    cm = _get_config()
    info = resolve_ticket_key(args["ticket_key"], cm)
    ticket_api = TicketAPI(cm)
    comments = ticket_api.get_ticket_comments(info["ticket_id"])
    return formatters.format_comments(comments)


def _handle_list_sprint_tickets(args: Dict) -> str:
    from janet.api.sprints import SprintAPI
    from janet.api.tickets import TicketAPI

    cm = _get_config()
    project = resolve_project(args["project_key"], cm)
    sprint = resolve_sprint(args["sprint_name"], project["id"], cm)

    sprint_api = SprintAPI(cm)

    # Use positions endpoint to get tickets in correct sprint order
    positions = sprint_api.get_positions(sprint["id"])
    positioned_ids = [p["ticket_id"] for p in positions]
    # Always fetch ticket_fields membership to catch tickets assigned via PUT /tickets/{id},
    # which updates ticket_fields but does not create sprint_ticket_positions records.
    all_sprint_ids = sprint_api.list_tickets(sprint["id"])
    positioned_set = set(positioned_ids)
    ticket_ids = positioned_ids + [tid for tid in all_sprint_ids if tid not in positioned_set]

    if not ticket_ids:
        return f"No tickets in sprint '{args['sprint_name']}'."

    ticket_api = TicketAPI(cm)
    tickets_raw = ticket_api.batch_fetch(ticket_ids)

    # Re-order tickets to match sprint position order and attach lexo positions
    ticket_map = {t["id"]: t for t in tickets_raw}
    pos_map = {p["ticket_id"]: p.get("position", "") for p in positions} if positions else {}
    tickets = []
    for tid in ticket_ids:
        if tid in ticket_map:
            ticket_map[tid]["_lexo_position"] = pos_map.get(tid, "")
            tickets.append(ticket_map[tid])

    proj_key = project.get("project_identifier", "?")
    for t in tickets:
        if not t.get("ticket_key"):
            tid = t.get("ticket_identifier", "?")
            if isinstance(tid, str) and tid.upper().startswith(proj_key.upper()):
                t["ticket_key"] = tid
            else:
                t["ticket_key"] = f"{proj_key}-{tid}"

    # Group by status column, preserving position order within each
    # Use first-seen order from positions data for column ordering
    seen_statuses = []
    for p in positions:
        s = p.get("status", "Unknown")
        if s not in seen_statuses:
            seen_statuses.append(s)

    tickets_by_status = {s: [] for s in seen_statuses}
    for t in tickets:
        s = t.get("status", "Unknown")
        if s not in tickets_by_status:
            tickets_by_status[s] = []
        tickets_by_status[s].append(t)

    return formatters.format_ticket_list_by_column(tickets_by_status, total_count=len(tickets))


def _handle_search_tickets_semantic(args: Dict) -> str:
    from janet.api.tickets import TicketAPI

    cm = _get_config()
    query = (args.get("query") or "").strip()
    if not query:
        raise ResolutionError("query is required for search_tickets_semantic")

    limit = int(args.get("limit", 20))
    proj_key_arg = args.get("project_key")

    project_id: str | None = None
    proj_key: str = "?"
    if proj_key_arg:
        project = resolve_project(proj_key_arg, cm)
        project_id = project["id"]
        proj_key = project.get("project_identifier", proj_key_arg)

    if not project_id:
        raise ResolutionError(
            "project_key is required for semantic search via MCP. "
            "Call get_workspace_context to see available project keys."
        )

    ticket_api = TicketAPI(cm)
    tickets = ticket_api.semantic_search(project_id=project_id, query=query, limit=limit)

    if not tickets:
        return f"No tickets found semantically matching '{query}'."

    lines = [f"Found {len(tickets)} ticket(s) semantically matching '{query}':"]
    for t in tickets:
        tid = t.get("ticket_identifier", "?")
        tk = t.get("ticket_key") or (
            tid if isinstance(tid, str) and tid.upper().startswith(proj_key.upper())
            else f"{proj_key}-{tid}"
        )
        status = t.get("status", "?")
        title = t.get("summary") or t.get("title", "(no title)")
        priority = t.get("priority", "")
        score = t.get("llm_relevance_score") or t.get("relevance_score") or t.get("match_score", "")
        line = f"- {tk} [{status}] \"{title}\""
        if priority:
            line += f" ({priority})"
        if score:
            line += f" [score: {score}]"
        lines.append(line)
    return "\n".join(lines)


# ── Document handlers ───────────────────────────────────────────────────────


def _handle_list_documents(args: Dict) -> str:
    from janet.api.documents import DocumentAPI

    cm = _get_config()
    doc_api = DocumentAPI(cm)
    my_docs = bool(args.get("my_docs", False))
    keyword = (args.get("keyword") or "").strip().lower()

    result = doc_api.list_documents(my_docs=my_docs)
    if not result.get("success"):
        raise Exception(result.get("error", "Failed to list documents"))

    docs = result.get("documents", [])
    if keyword:
        docs = [d for d in docs if keyword in (d.get("title") or "").lower()]

    scope_label = "Your documents" if my_docs else "Org documents"
    return formatters.format_document_list(docs, scope_label=scope_label)


def _handle_get_document(args: Dict) -> str:
    from janet.api.documents import DocumentAPI

    doc_id = args.get("document_id")
    if not doc_id:
        raise ResolutionError("document_id is required")

    cm = _get_config()
    doc_api = DocumentAPI(cm)
    result = doc_api.get_document(document_id=doc_id)
    if not result.get("success"):
        raise Exception(result.get("error", "Document not found or access denied"))

    return formatters.format_document_detail(result["document"])


def _handle_create_document(args: Dict) -> str:
    from janet.api.documents import _markdown_to_blocks, DocumentAPI

    title = args.get("title")
    if not title:
        raise ResolutionError("title is required")

    markdown = args.get("content") or ""
    content_json = _markdown_to_blocks(markdown) if markdown else None
    is_private = bool(args.get("is_private", True))

    cm = _get_config()
    doc_api = DocumentAPI(cm)
    result = doc_api.create_document(
        title=title,
        content_json=content_json,
        is_private=is_private,
    )
    if not result.get("success"):
        err = result.get("error", "Failed to create document")
        raise Exception(err)

    doc_id = result.get("document_id", "?")
    visibility = "private" if is_private else "org-wide"
    return f"Created document \"{title}\" (ID: {doc_id}, {visibility})"


def _handle_update_document(args: Dict) -> str:
    from janet.api.documents import _markdown_to_blocks, DocumentAPI

    doc_id = args.get("document_id")
    if not doc_id:
        raise ResolutionError("document_id is required")

    title = args.get("title") or None
    markdown = args.get("content")
    content_json = _markdown_to_blocks(markdown) if markdown else None

    if title is None and content_json is None:
        raise ResolutionError("Provide at least one of: title, content")

    cm = _get_config()
    doc_api = DocumentAPI(cm)
    result = doc_api.update_document(
        document_id=doc_id,
        title=title,
        content_json=content_json,
    )
    if not result.get("success"):
        err = result.get("error", "Failed to update document")
        raise Exception(err)

    return f"Updated document {doc_id}"


def _handle_get_platform_guidance(args: Dict) -> str:
    from janet.api.client import APIClient

    cm = _get_config()
    client = APIClient(cm)
    data = client.get("/api/v1/tools/platform-guidance", include_org=True)
    if not data.get("success"):
        raise ResolutionError(data.get("error", "Platform guidance not available"))
    return data["content"]


def _handle_web_search(args: Dict) -> str:
    from janet.api.client import APIClient

    cm = _get_config()
    client = APIClient(cm)
    query = args["query"]
    max_results = int(args.get("max_results", 5))

    data = client.post(
        "/api/v1/tools/web-search",
        {"query": query, "max_results": max_results},
        include_org=True,
    )

    if not data.get("success"):
        raise ResolutionError(data.get("error", "Web search failed"))

    lines = []
    if data.get("answer"):
        lines.append(data["answer"])
        lines.append("")
    lines.append("Sources:")
    for i, r in enumerate(data.get("results", [])[:max_results], 1):
        lines.append(f"{i}. {r.get('title', '')} — {r.get('url', '')}")
        if r.get("description"):
            lines.append(f"   {r['description']}")
    return "\n".join(lines)


def _handle_add_api_key(args: Dict) -> str:
    name = args["name"].strip()
    key = args["key"].strip()
    switch_to = bool(args.get("switch_to", False))

    from janet.mcp.auth import ApiKeyConfig
    config = ApiKeyConfig(key)
    if not config.has_organization():
        if config._network_error:
            raise ResolutionError(
                f"Cannot reach the Janet API to validate the key ({config._network_error}). "
                "This is often a DNS issue. See https://docs.janet.ai/features/coding-agents#troubleshooting for step-by-step troubleshooting instructions."
            )
        raise ResolutionError(
            f"Key is invalid or has no organization access. "
            "Check it at janet.ai → Organization Settings → API Keys."
        )
    org_name = config.get().selected_organization.name if config.get().selected_organization else "unknown org"

    cm = ConfigManager()
    cfg = cm.get()
    cfg.api_keys[name] = key
    if switch_to:
        cfg.active_key_name = name
    cm.save()

    if switch_to:
        global _cached_config, _workspace_cache
        _cached_config = None
        _workspace_cache = None
        return f"Added key '{name}' ({org_name}). Now active."
    return f"Added key '{name}' ({org_name}). Use switch_organization(key_name='{name}') to activate it."


def _handle_switch_organization(args: Dict) -> str:
    global _cached_config, _workspace_cache
    key_name = args["key_name"].strip()

    cm = ConfigManager()
    cfg = cm.get()
    if key_name not in cfg.api_keys:
        saved = list(cfg.api_keys.keys())
        raise ResolutionError(
            f"No key named '{key_name}'. Saved keys: {saved or 'none'}. "
            "Use add_api_key to save one."
        )

    key = cfg.api_keys[key_name]
    from janet.mcp.auth import ApiKeyConfig
    config = ApiKeyConfig(key)
    if not config.has_organization():
        if config._network_error:
            raise ResolutionError(
                f"Cannot reach the Janet API to validate '{key_name}' ({config._network_error}). "
                "This is often a DNS issue. See https://docs.janet.ai/features/coding-agents#troubleshooting for step-by-step troubleshooting instructions."
            )
        raise ResolutionError(f"Key '{key_name}' is invalid or expired.")
    org_name = config.get().selected_organization.name if config.get().selected_organization else "unknown org"

    cfg.active_key_name = key_name
    cm.save()
    _cached_config = None
    _workspace_cache = None
    return f"Switched to '{key_name}' ({org_name})."


def _handle_remove_api_key(args: Dict) -> str:
    name = args["name"].strip()

    cm = ConfigManager()
    cfg = cm.get()
    if name not in cfg.api_keys:
        raise ResolutionError(f"No key named '{name}'.")

    del cfg.api_keys[name]
    if cfg.active_key_name == name:
        cfg.active_key_name = None
        global _cached_config, _workspace_cache
        _cached_config = None
        _workspace_cache = None
    cm.save()
    return f"Removed key '{name}'."


def _handle_list_api_keys(args: Dict) -> str:
    cm = ConfigManager()
    cfg = cm.get()
    env_key = os.environ.get("JANET_API_KEY")

    lines = []

    if cfg.api_keys:
        lines.append("Saved keys:")
        for name, key in cfg.api_keys.items():
            masked = ("●●●●" + key[-4:]) if len(key) >= 4 else "●●●●"
            active_marker = " [active]" if name == cfg.active_key_name else ""
            lines.append(f"  {name}  {masked}{active_marker}")
    else:
        lines.append("No saved keys. Use add_api_key to save one.")

    if env_key:
        masked_env = "●●●●" + env_key[-4:]
        lines.append(f"\nJANET_API_KEY env var: {masked_env} (used as fallback when no named key is active)")

    if not cfg.active_key_name and not env_key:
        lines.append("\nNo active key. Use switch_organization or add_api_key(switch_to=True) to authenticate.")

    return "\n".join(lines)


def _handle_sign_out(args: Dict) -> str:
    global _cached_config, _workspace_cache
    env_key = os.environ.get("JANET_API_KEY")
    if env_key:
        return (
            "You're authenticated via the JANET_API_KEY environment variable — "
            "unset it to sign out (the MCP server must be restarted after)."
        )

    cm = ConfigManager()
    cfg = cm.get()
    cfg.active_key_name = None
    cm.save()
    _cached_config = None
    _workspace_cache = None
    return "Signed out. Use add_api_key or switch_organization to resume."


# ── Router ──────────────────────────────────────────────────────────────────

HANDLERS = {
    "get_workspace_context": _handle_get_workspace_context,
    "list_tickets": _handle_list_tickets,
    "search_tickets_semantic": _handle_search_tickets_semantic,
    "get_ticket": _handle_get_ticket,
    "create_ticket": _handle_create_ticket,
    "update_tickets": _handle_update_tickets,
    "delete_tickets": _handle_delete_tickets,
    "restore_tickets": _handle_restore_tickets,
    "move_ticket": _handle_move_ticket,
    "manage_child_task": _handle_manage_child_task,
    "manage_sub_task": _handle_manage_sub_task,
    "manage_comment": _handle_manage_comment,
    "list_sprints": _handle_list_sprints,
    "manage_sprint": _handle_manage_sprint,
    "manage_sprint_tickets": _handle_manage_sprint_tickets,
    "list_child_tasks": _handle_list_child_tasks,
    "list_comments": _handle_list_comments,
    "list_sprint_tickets": _handle_list_sprint_tickets,
    "list_documents": _handle_list_documents,
    "get_document": _handle_get_document,
    "create_document": _handle_create_document,
    "update_document": _handle_update_document,
    "web_search": _handle_web_search,
    "get_platform_guidance": _handle_get_platform_guidance,
    "add_api_key": _handle_add_api_key,
    "switch_organization": _handle_switch_organization,
    "remove_api_key": _handle_remove_api_key,
    "sign_out": _handle_sign_out,
    "list_api_keys": _handle_list_api_keys,
}


async def _log_tool_call(tool_name: str, arguments: Dict, status: str, error_message: str | None, duration_ms: int, result_preview: str | None = None):
    """Fire-and-forget: POST tool call log to backend."""
    try:
        import httpx
        config = _get_config()
        config_obj = config.get()
        # Use the active key from config (works for both env-var and named-key sessions)
        api_key = config_obj.auth.access_token
        if not api_key:
            return
        base_url = config_obj.api.base_url
        sanitized_args = {k: v for k, v in (arguments or {}).items() if "key" not in k.lower() and "token" not in k.lower()}
        org_id = config_obj.selected_organization.id if config_obj.selected_organization else ""
        await asyncio.to_thread(
            lambda: httpx.post(
                f"{base_url}/api/v1/mcp-activity",
                headers={
                    "X-API-Key": api_key,
                    "Content-Type": "application/json",
                    "X-Organization-ID": org_id,
                },
                json={
                    "tool_name": tool_name,
                    "arguments": sanitized_args,
                    "status": status,
                    "error_message": error_message,
                    "duration_ms": duration_ms,
                    "result_preview": result_preview,
                },
                timeout=5,
            )
        )
    except Exception:
        pass  # Non-blocking, never fail the tool call


def _coerce_arrays(args: Dict) -> Dict:
    """Coerce any JSON-encoded string arrays back to lists.

    Claude Code sometimes passes array parameters as strings like '["me"]'
    instead of proper JSON arrays. This fixes that before handlers run.
    """
    import json as _json
    result = {}
    for k, v in args.items():
        if isinstance(v, str):
            try:
                parsed = _json.loads(v)
                if isinstance(parsed, list):
                    result[k] = parsed
                    continue
            except (ValueError, TypeError):
                pass
            result[k] = v
        elif isinstance(v, list):
            result[k] = [_coerce_arrays(i) if isinstance(i, dict) else i for i in v]
        elif isinstance(v, dict):
            result[k] = _coerce_arrays(v)
        else:
            result[k] = v
    return result


@server.call_tool()
async def call_tool(name: str, arguments: Dict[str, Any]) -> List[TextContent]:
    arguments = _coerce_arrays(arguments)
    handler = HANDLERS.get(name)
    if not handler:
        return _text(f"Unknown tool: {name}")

    import time
    start = time.time()
    status = "success"
    error_msg = None

    try:
        result = await asyncio.to_thread(handler, arguments)
        duration_ms = round((time.time() - start) * 1000)
        asyncio.create_task(_log_tool_call(name, arguments, status, None, duration_ms, result))
        return _text(result)
    except AuthenticationError as e:
        status = "error"
        error_msg = str(e)
        duration_ms = round((time.time() - start) * 1000)
        asyncio.create_task(_log_tool_call(name, arguments, status, error_msg, duration_ms))
        _cfg_check = ConfigManager().get()
        hint = (
            "Ask the user to check their API key at janet.ai → Organization Settings → API Keys."
            if (os.environ.get("JANET_API_KEY") or _cfg_check.active_key_name)
            else "Ask the user to run `janet login` in their terminal."
        )
        return _text(
            f"Authentication error: {e}\n\n{hint}"
        )
    except ResolutionError as e:
        status = "error"
        error_msg = str(e)
        duration_ms = round((time.time() - start) * 1000)
        asyncio.create_task(_log_tool_call(name, arguments, status, error_msg, duration_ms))
        return _text(f"Resolution error: {e}")
    except NetworkError as e:
        status = "error"
        error_msg = str(e)
        duration_ms = round((time.time() - start) * 1000)
        asyncio.create_task(_log_tool_call(name, arguments, status, error_msg, duration_ms))
        return _text(f"API request failed: {e}. The Janet API may be temporarily unavailable.")
    except Exception as e:
        status = "error"
        error_msg = str(e)
        duration_ms = round((time.time() - start) * 1000)
        asyncio.create_task(_log_tool_call(name, arguments, status, error_msg, duration_ms))
        return _text(f"Error: {e}")


# ── Entry point ─────────────────────────────────────────────────────────────


def main():
    """Run the Janet AI MCP server over stdio."""
    import asyncio

    asyncio.run(_run())


async def _run():
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options(),
        )
