from .airlock import *

__doc__ = airlock.__doc__
if hasattr(airlock, "__all__"):
    __all__ = airlock.__all__