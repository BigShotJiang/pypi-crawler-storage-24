from unisights.validator import UnisightsValidator

payload = {
    "data":{ "asset_id": "test",
    "session_id": "ffe6dbd2-1a22-4189-84d8-f2f413690d14",
    "page_url": "http://localhost/",
    "entry_page": "http://localhost/",
    "exit_page": "http://localhost/",
    "utm_params": {},
    "device_info": {
        "device_type": "Desktop",
        "os": "Windows",
        "platform": "Win32",
        "referrer": "http://localhost/",
        "screen_height": 1080,
        "screen_width": 1920,
        "user_agent": "Mozilla/5.0..."
    },
    "events": [{"type": "custom", "data": {"name": "test", "data": "{}", "timestamp": 123}}],
    "scroll_depth": 64.238,
    "time_on_page": 374.773},
    "encrypted":False
   
}

validator = UnisightsValidator()
result = validator.validate(payload)
print("✅ VALIDATION PASSED!")