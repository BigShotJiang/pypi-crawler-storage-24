from __future__ import annotations

from concurrent import futures
import json
import os

import grpc
import pytest

from coordinator.engine import CoordinatorEngine, EngineConfig
from peer.server import GRPC_SERVER_OPTIONS, PeerService
from peer import peer_pb2_grpc


pytestmark = pytest.mark.skipif(
    os.environ.get("OPENHYDRA_RUN_REAL_TENSOR_TEST", "0") != "1",
    reason="set OPENHYDRA_RUN_REAL_TENSOR_TEST=1 to run real PyTorch speculative decode validation",
)


def _start_pytorch_peer(peer_id: str, shard_index: int, model_name: str) -> tuple[grpc.Server, int]:
    service = PeerService(
        peer_id=peer_id,
        model_id="openhydra-toy-345m",
        shard_index=shard_index,
        total_shards=2,
        daemon_mode="polite",
        broken=False,
        runtime_backend="pytorch_cpu",
        runtime_target="cpu",
        quantization_mode="fp32",
        runtime_model_id=model_name,
        kv_cache_max_entries=8,
    )
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=4), options=GRPC_SERVER_OPTIONS)
    peer_pb2_grpc.add_PeerServicer_to_server(service, server)
    port = server.add_insecure_port("127.0.0.1:0")
    if port == 0:
        raise RuntimeError("grpc_listener_unavailable")
    server.start()
    return server, port


def test_real_speculative_decoding_accepts_multiple_tokens_per_verification_round(tmp_path):
    pytest.importorskip("torch")
    pytest.importorskip("transformers")

    model_name = os.environ.get("OPENHYDRA_PYTORCH_TEST_MODEL", "sshleifer/tiny-gpt2")
    try:
        started = [
            _start_pytorch_peer("peer-spec-a", 0, model_name),
            _start_pytorch_peer("peer-spec-b", 1, model_name),
        ]
    except Exception as exc:
        pytest.skip(f"unable to initialize pytorch speculative peers for model '{model_name}': {exc}")

    servers = [item[0] for item in started]
    ports = [item[1] for item in started]

    peers_config = tmp_path / "peers.spec.json"
    peers_config.write_text(
        json.dumps(
            [
                {
                    "peer_id": "peer-spec-a",
                    "host": "127.0.0.1",
                    "port": int(ports[0]),
                    "model_id": "openhydra-toy-345m",
                    "runtime_backend": "pytorch_cpu",
                    "runtime_target": "cpu",
                    "quantization_mode": "fp32",
                },
                {
                    "peer_id": "peer-spec-b",
                    "host": "127.0.0.1",
                    "port": int(ports[1]),
                    "model_id": "openhydra-toy-345m",
                    "runtime_backend": "pytorch_cpu",
                    "runtime_target": "cpu",
                    "quantization_mode": "fp32",
                },
            ],
            indent=2,
        )
    )

    try:
        engine = CoordinatorEngine(
            EngineConfig(
                peers_config_path=str(peers_config),
                ledger_path=str(tmp_path / "credits.json"),
                health_store_path=str(tmp_path / "health.json"),
                audit_rate=0.0,
                redundant_exec_rate=0.0,
                grounding_use_network=False,
                required_replicas=1,
                speculative_enabled=True,
                speculative_draft_tokens=3,
                pytorch_generation_model_id=model_name,
                pytorch_speculative_draft_model_id=model_name,
                barter_decay_per_day=0.0,
            )
        )
        payload = engine.infer_stream(
            prompt="The capital of France is",
            max_tokens=4,
            grounding=False,
            pipeline_width=2,
            session_id="speculative-session",
        )
        chunks = list(payload["stream"])
        text = "".join(chunks)
        streaming = payload["streaming"]
        speculative = streaming["speculative"]

        assert streaming["mode"] == "pytorch_speculative_decode"
        assert streaming["speculative_enabled"] is True
        assert streaming["pytorch"]["enabled"] is True
        assert speculative["enabled"] is True
        assert int(speculative["rounds"]) >= 1
        assert int(speculative["accepted_tokens"]) >= 2
        assert int(speculative["verified_tokens"]) >= int(speculative["accepted_tokens"])
        assert text.strip() != ""
        assert any(char.isalpha() for char in text)
    finally:
        for server in servers:
            server.stop(grace=0)
