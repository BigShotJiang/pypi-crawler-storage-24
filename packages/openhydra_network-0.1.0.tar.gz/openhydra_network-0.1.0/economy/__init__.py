"""Economic modules."""
