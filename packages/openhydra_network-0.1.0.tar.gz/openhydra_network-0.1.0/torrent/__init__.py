"""Weight distribution modules."""
