# Data Protocol

All data responses are binary. No JSON.

## Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/health` | Plain text `ok` |
| GET | `/api/demo` | Table: `id` (int64), `name` (utf8), `score` (float64) |

## Content Negotiation

Set the `Accept` header to choose the wire format:

| Accept | Format |
|--------|--------|
| `application/vnd.apache.arrow.stream` | Arrow IPC Stream |
| `application/vnd.apache.arrow.file` | Arrow IPC File |
| `application/x-parquet` | Parquet |

Default (missing or unrecognized Accept): **Arrow IPC Stream**.

First matching media type wins. Quality parameters are stripped, not weighted.

The response `Content-Type` will match the negotiated format.

## Errors

All errors are `text/plain`. No JSON error envelopes.
