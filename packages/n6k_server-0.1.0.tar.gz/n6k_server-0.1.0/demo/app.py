import pandas as pd
import seaborn as sns
from starlette.responses import PlainTextResponse

import n6k_server

app = n6k_server.create_app()


@n6k_server.data(app, "demo")
def demo():
    return pd.DataFrame({
        "id": [1, 2, 3],
        "name": ["alice", "bob", "charlie"],
        "score": [95.5, 87.3, 91.8],
    })


@n6k_server.data(app, "iris")
def iris():
    return sns.load_dataset("iris")


@app.get("/health")
async def health() -> PlainTextResponse:
    return PlainTextResponse("ok")
