from __future__ import annotations

from pathlib import Path
from typing import Iterable

import cv2
import numpy as np

from ._core import merge_pipeline


def _blend_with_padding(canvas: np.ndarray, x: int, y: int, w: int, h: int, img: np.ndarray, padding: int) -> None:
    canvas[y + padding : y + padding + h, x + padding : x + padding + w] = img

    # Edge dilation reduces sampling artifacts near tile borders.
    if padding <= 0:
        return

    top = y + padding
    left = x + padding
    right = left + w - 1
    bottom = top + h - 1

    for i in range(1, padding + 1):
        canvas[top - i, left : right + 1] = canvas[top, left : right + 1]
        canvas[bottom + i, left : right + 1] = canvas[bottom, left : right + 1]
        canvas[top : bottom + 1, left - i] = canvas[top : bottom + 1, left]
        canvas[top : bottom + 1, right + i] = canvas[top : bottom + 1, right]


def _compose_atlases(tasks: list[dict], output_dir: Path) -> tuple[dict[int, str], dict]:
    by_atlas: dict[int, list[dict]] = {}
    for t in tasks:
        by_atlas.setdefault(int(t["atlas_index"]), []).append(t)

    atlas_ext: dict[int, str] = {}
    compose_diag = {
        "crop_tasks_total": 0,
        "crop_size_mismatch_count": 0,
        "crop_size_mismatches": [],
    }
    for atlas_idx, group in by_atlas.items():
        atlas_w = int(group[0]["atlas_w"])
        atlas_h = int(group[0]["atlas_h"])
        canvas = np.zeros((atlas_h, atlas_w, 4), dtype=np.uint8)
        canvas[:, :, 3] = 255

        for item in group:
            src = cv2.imread(str(item["source_path"]), cv2.IMREAD_UNCHANGED)
            if src is None:
                continue

            if src.ndim == 2:
                src = cv2.cvtColor(src, cv2.COLOR_GRAY2BGRA)
            elif src.shape[2] == 3:
                src = cv2.cvtColor(src, cv2.COLOR_BGR2BGRA)

            # Crop texture to the UV-used range before packing.
            h0, w0 = src.shape[:2]
            if {"crop_x0", "crop_x1", "crop_y0", "crop_y1"} <= set(item.keys()):
                x0 = max(0, min(w0 - 1, int(item["crop_x0"])))
                x1 = max(x0 + 1, min(w0, int(item["crop_x1"])))
                y0 = max(0, min(h0 - 1, int(item["crop_y0"])))
                y1 = max(y0 + 1, min(h0, int(item["crop_y1"])))
            else:
                cu0 = float(item.get("crop_u0", 0.0))
                cv0 = float(item.get("crop_v0", 0.0))
                cu1 = float(item.get("crop_u1", 1.0))
                cv1 = float(item.get("crop_v1", 1.0))
                x0 = max(0, min(w0 - 1, int(np.floor(cu0 * w0))))
                x1 = max(x0 + 1, min(w0, int(np.ceil(cu1 * w0))))
                # OBJ UV uses v=0 at bottom, while image rows use y=0 at top.
                y0 = max(0, min(h0 - 1, int(np.floor((1.0 - cv1) * h0))))
                y1 = max(y0 + 1, min(h0, int(np.ceil((1.0 - cv0) * h0))))
            src = src[y0:y1, x0:x1]
            compose_diag["crop_tasks_total"] += 1

            if bool(item["rot90"]):
                src = cv2.rotate(src, cv2.ROTATE_90_CLOCKWISE)

            w = int(item["content_w"])
            h = int(item["content_h"])
            if src.shape[1] != w or src.shape[0] != h:
                compose_diag["crop_size_mismatch_count"] += 1
                if len(compose_diag["crop_size_mismatches"]) < 20:
                    compose_diag["crop_size_mismatches"].append(
                        {
                            "source_path": str(item.get("source_path", "")),
                            "atlas_index": int(item.get("atlas_index", -1)),
                            "rot90": bool(item.get("rot90", False)),
                            "crop_w_h": [int(src.shape[1]), int(src.shape[0])],
                            "content_w_h": [w, h],
                        }
                    )
            x = int(item["x"])
            y = int(item["y"])
            padding = int(item["padding"])
            src = cv2.resize(src, (w, h), interpolation=cv2.INTER_LINEAR)
            _blend_with_padding(canvas, x, y, w, h, src, padding)

        has_effective_alpha = bool(np.any(canvas[:, :, 3] < 255))
        if has_effective_alpha:
            ext = "png"
            ok = cv2.imwrite(str(output_dir / f"atlas_{atlas_idx}.png"), canvas)
        else:
            ext = "jpg"
            bgr = cv2.cvtColor(canvas, cv2.COLOR_BGRA2BGR)
            ok = cv2.imwrite(str(output_dir / f"atlas_{atlas_idx}.jpg"), bgr, [int(cv2.IMWRITE_JPEG_QUALITY), 75])
        if not ok:
            raise RuntimeError(f"Failed to write atlas image: atlas_{atlas_idx}.{ext}")
        atlas_ext[atlas_idx] = ext

    return atlas_ext, compose_diag


def _rewrite_mtl_to_arcgis(mtl_file: Path, atlas_ext: dict[int, str], original_materials: list[dict]) -> None:
    lines: list[str] = []
    max_idx = max(atlas_ext.keys(), default=-1)
    for i in range(max_idx + 1):
        ext = atlas_ext.get(i, "png")
        lines.append(f"newmtl atlas_mat_{i}")
        lines.append("Ka 1.0 1.0 1.0")
        lines.append("Kd 1.0 1.0 1.0")
        lines.append("Ks 0.0 0.0 0.0")
        lines.append("Ns 1.0")
        lines.append(f"map_Kd atlas_{i}.{ext}")
        lines.append("")

    for mat in original_materials:
        name = str(mat.get("name", "")).strip()
        map_kd = str(mat.get("map_kd", "")).strip()
        if not name or not map_kd:
            continue
        lines.append(f"newmtl {name}")
        lines.append("Ka 1.0 1.0 1.0")
        lines.append("Kd 1.0 1.0 1.0")
        lines.append("Ks 0.0 0.0 0.0")
        lines.append("Ns 1.0")
        lines.append(f"map_Kd {map_kd}")
        lines.append("")

    mtl_file.write_text("\n".join(lines), encoding="utf-8")


def merge_obj_to_atlas(
    input_objs: Iterable[str],
    output_dir: str,
    split_o: bool = True,
    split_g: bool = False,
    front_axis: str = "Y",
    up_axis: str = "Z",
    right_handed: bool = True,
    atlas_max_size: int = 8192,
    atlas_padding: int = 4,
    atlas_pow2: bool = True,
    atlas_allow_rotate_90: bool = True,
    atlas_max_count: int = 0,
    spatial_cluster_radius: float = -1.0,
    atlas_target_utilization: float = 0.92,
    uv_repeat_exclude_merge: bool = True,
    simplify_ratio: float = 1.0,
    simplify_normals: bool = False,
    vertex_key_mode: str = "pos",
) -> dict:
    """Merge OBJ meshes and textures into atlas outputs.

    Notes:
    - `atlas_padding` default is 4 for balanced output size.
    - For Blender viewport preview, consider using `atlas_padding>=8`
      and Image Texture extension mode `Extend`/`Clip` to reduce border bleed.
    """
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    inputs = [str(Path(p).resolve()) for p in input_objs]

    plan = merge_pipeline(
        inputs,
        str(out),
        split_o,
        split_g,
        front_axis,
        up_axis,
        right_handed,
        atlas_max_size,
        atlas_padding,
        atlas_pow2,
        atlas_allow_rotate_90,
        atlas_max_count,
        spatial_cluster_radius,
        atlas_target_utilization,
        uv_repeat_exclude_merge,
        simplify_ratio,
        simplify_normals,
        vertex_key_mode,
    )
    atlas_ext, compose_diag = _compose_atlases(plan["atlas_tasks"], out)
    _rewrite_mtl_to_arcgis(Path(plan["output_mtl"]), atlas_ext, plan.get("original_materials", []))
    plan["atlas_ext"] = atlas_ext
    plan["compose_diagnostics"] = compose_diag
    return plan
