//! Lookup tables for HCA decoding

use std::sync::LazyLock;

/// Invert table for scalefactor resolution calculation
pub const INVERT_TABLE: [u8; 66] = [
    14, 14, 14, 14, 14, 14, 13, 13, 13, 13, 13, 13, 12, 12, 12, 12, 12, 12, 11, 11, 11, 11, 11, 11,
    10, 10, 10, 10, 10, 10, 10, 9, 9, 9, 9, 9, 9, 8, 8, 8, 8, 8, 8, 7, 6, 6, 5, 4, 4, 4, 3, 3, 3,
    2, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1,
];

/// Dequantizer scaling table (static, lazily initialized)
pub static DEQUANTIZER_SCALING_TABLE: LazyLock<[f32; 64]> = LazyLock::new(|| {
    let hex: [u32; 64] = [
        0x342A8D26, 0x34633F89, 0x3497657D, 0x34C9B9BE, 0x35066491, 0x353311C4, 0x356E9910,
        0x359EF532, 0x35D3CCF1, 0x360D1ADF, 0x363C034A, 0x367A83B3, 0x36A6E595, 0x36DE60F5,
        0x371426FF, 0x3745672A, 0x37838359, 0x37AF3B79, 0x37E97C38, 0x381B8D3A, 0x384F4319,
        0x388A14D5, 0x38B7FBF0, 0x38F5257D, 0x3923520F, 0x39599D16, 0x3990FA4D, 0x39C12C4D,
        0x3A00B1ED, 0x3A2B7A3A, 0x3A647B6D, 0x3A9837F0, 0x3ACAD226, 0x3B071F62, 0x3B340AAF,
        0x3B6FE4BA, 0x3B9FD228, 0x3BD4F35B, 0x3C0DDF04, 0x3C3D08A4, 0x3C7BDFED, 0x3CA7CD94,
        0x3CDF9613, 0x3D14F4F0, 0x3D467991, 0x3D843A29, 0x3DB02F0E, 0x3DEAC0C7, 0x3E1C6573,
        0x3E506334, 0x3E8AD4C6, 0x3EB8FBAF, 0x3EF67A41, 0x3F243516, 0x3F5ACB94, 0x3F91C3D3,
        0x3FC238D2, 0x400164D2, 0x402C6897, 0x4065B907, 0x40990B88, 0x40CBEC15, 0x4107DB35,
        0x413504F3,
    ];
    let mut result = [0.0f32; 64];
    for i in 0..64 {
        result[i] = f32::from_bits(hex[i]);
    }
    result
});

/// Dequantizer range table (static, lazily initialized)
pub static DEQUANTIZER_RANGE_TABLE: LazyLock<[f32; 16]> = LazyLock::new(|| {
    let hex: [u32; 16] = [
        0x3F800000, 0x3F2AAAAB, 0x3ECCCCCD, 0x3E924925, 0x3E638E39, 0x3E3A2E8C, 0x3E1D89D9,
        0x3E088889, 0x3D842108, 0x3D020821, 0x3C810204, 0x3C008081, 0x3B804020, 0x3B002008,
        0x3A801002, 0x3A000801,
    ];
    let mut result = [0.0f32; 16];
    for i in 0..16 {
        result[i] = f32::from_bits(hex[i]);
    }
    result
});

/// Scale conversion table (static, lazily initialized)
pub static SCALE_CONVERSION_TABLE: LazyLock<[f32; 128]> = LazyLock::new(|| {
    let hex: [u32; 128] = [
        0x00000000, 0x32A0B051, 0x32D61B5E, 0x330EA43A, 0x333E0F68, 0x337D3E0C, 0x33A8B6D5,
        0x33E0CCDF, 0x3415C3FF, 0x34478D75, 0x3484F1F6, 0x34B123F6, 0x34EC0719, 0x351D3EDA,
        0x355184DF, 0x358B95C2, 0x35B9FCD2, 0x35F7D0DF, 0x36251958, 0x365BFBB8, 0x36928E72,
        0x36C346CD, 0x370218AF, 0x372D583F, 0x3766F85B, 0x3799E046, 0x37CD078C, 0x3808980F,
        0x38360094, 0x38728177, 0x38A18FAF, 0x38D744FD, 0x390F6A81, 0x393F179A, 0x397E9E11,
        0x39A9A15B, 0x39E2055B, 0x3A16942D, 0x3A48A2D8, 0x3A85AAC3, 0x3AB21A32, 0x3AED4F30,
        0x3B1E196E, 0x3B52A81E, 0x3B8C57CA, 0x3BBAFF5B, 0x3BF9295A, 0x3C25FED7, 0x3C5D2D82,
        0x3C935A2B, 0x3CC4563F, 0x3D02CD87, 0x3D2E4934, 0x3D68396A, 0x3D9AB62B, 0x3DCE248C,
        0x3E0955EE, 0x3E36FD92, 0x3E73D290, 0x3EA27043, 0x3ED87039, 0x3F1031DC, 0x3F40213B,
        0x3F800000, 0x3FAA8D26, 0x3FE33F89, 0x4017657D, 0x4049B9BE, 0x40866491, 0x40B311C4,
        0x40EE9910, 0x411EF532, 0x4153CCF1, 0x418D1ADF, 0x41BC034A, 0x41FA83B3, 0x4226E595,
        0x425E60F5, 0x429426FF, 0x42C5672A, 0x43038359, 0x432F3B79, 0x43697C38, 0x439B8D3A,
        0x43CF4319, 0x440A14D5, 0x4437FBF0, 0x4475257D, 0x44A3520F, 0x44D99D16, 0x4510FA4D,
        0x45412C4D, 0x4580B1ED, 0x45AB7A3A, 0x45E47B6D, 0x461837F0, 0x464AD226, 0x46871F62,
        0x46B40AAF, 0x46EFE4BA, 0x471FD228, 0x4754F35B, 0x478DDF04, 0x47BD08A4, 0x47FBDFED,
        0x4827CD94, 0x485F9613, 0x4894F4F0, 0x48C67991, 0x49043A29, 0x49302F0E, 0x496AC0C7,
        0x499C6573, 0x49D06334, 0x4A0AD4C6, 0x4A38FBAF, 0x4A767A41, 0x4AA43516, 0x4ADACB94,
        0x4B11C3D3, 0x4B4238D2, 0x4B8164D2, 0x4BAC6897, 0x4BE5B907, 0x4C190B88, 0x4C4BEC15,
        0x00000000, 0x00000000,
    ];
    let mut result = [0.0f32; 128];
    for i in 0..128 {
        result[i] = f32::from_bits(hex[i]);
    }
    result
});

/// IMDCT window (static, lazily initialized)
pub static IMDCT_WINDOW: LazyLock<[f32; 128]> = LazyLock::new(|| {
    let hex: [u32; 128] = [
        0x3A3504F0, 0x3B0183B8, 0x3B70C538, 0x3BBB9268, 0x3C04A809, 0x3C308200, 0x3C61284C,
        0x3C8B3F17, 0x3CA83992, 0x3CC77FBD, 0x3CE91110, 0x3D0677CD, 0x3D198FC4, 0x3D2DD35C,
        0x3D434643, 0x3D59ECC1, 0x3D71CBA8, 0x3D85741E, 0x3D92A413, 0x3DA078B4, 0x3DAEF522,
        0x3DBE1C9E, 0x3DCDF27B, 0x3DDE7A1D, 0x3DEFB6ED, 0x3E00D62B, 0x3E0A2EDA, 0x3E13E72A,
        0x3E1E00B1, 0x3E287CF2, 0x3E335D55, 0x3E3EA321, 0x3E4A4F75, 0x3E56633F, 0x3E62DF37,
        0x3E6FC3D1, 0x3E7D1138, 0x3E8563A2, 0x3E8C72B7, 0x3E93B561, 0x3E9B2AEF, 0x3EA2D26F,
        0x3EAAAAAB, 0x3EB2B222, 0x3EBAE706, 0x3EC34737, 0x3ECBD03D, 0x3ED47F46, 0x3EDD5128,
        0x3EE6425C, 0x3EEF4EFF, 0x3EF872D7, 0x3F00D4A9, 0x3F0576CA, 0x3F0A1D3B, 0x3F0EC548,
        0x3F136C25, 0x3F180EF2, 0x3F1CAAC2, 0x3F213CA2, 0x3F25C1A5, 0x3F2A36E7, 0x3F2E9998,
        0x3F32E705, 0xBF371C9E, 0xBF3B37FE, 0xBF3F36F2, 0xBF431780, 0xBF46D7E6, 0xBF4A76A4,
        0xBF4DF27C, 0xBF514A6F, 0xBF547DC5, 0xBF578C03, 0xBF5A74EE, 0xBF5D3887, 0xBF5FD707,
        0xBF6250DA, 0xBF64A699, 0xBF66D908, 0xBF68E90E, 0xBF6AD7B1, 0xBF6CA611, 0xBF6E5562,
        0xBF6FE6E7, 0xBF715BEF, 0xBF72B5D1, 0xBF73F5E6, 0xBF751D89, 0xBF762E13, 0xBF7728D7,
        0xBF780F20, 0xBF78E234, 0xBF79A34C, 0xBF7A5397, 0xBF7AF439, 0xBF7B8648, 0xBF7C0ACE,
        0xBF7C82C8, 0xBF7CEF26, 0xBF7D50CB, 0xBF7DA88E, 0xBF7DF737, 0xBF7E3D86, 0xBF7E7C2A,
        0xBF7EB3CC, 0xBF7EE507, 0xBF7F106C, 0xBF7F3683, 0xBF7F57CA, 0xBF7F74B6, 0xBF7F8DB6,
        0xBF7FA32E, 0xBF7FB57B, 0xBF7FC4F6, 0xBF7FD1ED, 0xBF7FDCAD, 0xBF7FE579, 0xBF7FEC90,
        0xBF7FF22E, 0xBF7FF688, 0xBF7FF9D0, 0xBF7FFC32, 0xBF7FFDDA, 0xBF7FFEED, 0xBF7FFF8F,
        0xBF7FFFDF, 0xBF7FFFFC,
    ];
    let mut result = [0.0f32; 128];
    for i in 0..128 {
        result[i] = f32::from_bits(hex[i]);
    }
    result
});

/// Intensity ratio table (static, lazily initialized)
pub static INTENSITY_RATIO_TABLE: LazyLock<[f32; 16]> = LazyLock::new(|| {
    let hex: [u32; 16] = [
        0x40000000, 0x3FEDB6DB, 0x3FDB6DB7, 0x3FC92492, 0x3FB6DB6E, 0x3FA49249, 0x3F924925,
        0x3F800000, 0x3F5B6DB7, 0x3F36DB6E, 0x3F124925, 0x3EDB6DB7, 0x3E924925, 0x3E124925,
        0x00000000, 0x00000000,
    ];
    let mut result = [0.0f32; 16];
    for i in 0..16 {
        result[i] = f32::from_bits(hex[i]);
    }
    result
});

/// Max bit table for decoding
pub const MAX_BIT_TABLE: [u8; 16] = [0, 2, 3, 3, 4, 4, 4, 4, 5, 6, 7, 8, 9, 10, 11, 12];

/// Read bit table for decoding
pub const READ_BIT_TABLE: [u8; 128] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    2, 2, 2, 2, 2, 2, 3, 3, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 3, 3, 3, 3, 3, 3, 0, 0, 0, 0, 0, 0, 0, 0,
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4,
    3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4,
];

/// Read value table for decoding
pub const READ_VAL_TABLE: [f32; 128] = [
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0,
    -1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, -1.0,
    -1.0, 2.0, -2.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, -1.0, 2.0, -2.0, 3.0,
    -3.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, -1.0, -1.0, 2.0, 2.0, -2.0,
    -2.0, 3.0, 3.0, -3.0, -3.0, 4.0, -4.0, 0.0, 0.0, 1.0, 1.0, -1.0, -1.0, 2.0, 2.0, -2.0, -2.0,
    3.0, -3.0, 4.0, -4.0, 5.0, -5.0, 0.0, 0.0, 1.0, 1.0, -1.0, -1.0, 2.0, -2.0, 3.0, -3.0, 4.0,
    -4.0, 5.0, -5.0, 6.0, -6.0, 0.0, 0.0, 1.0, -1.0, 2.0, -2.0, 3.0, -3.0, 4.0, -4.0, 5.0, -5.0,
    6.0, -6.0, 7.0, -7.0,
];

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_tables_valid() {
        assert_eq!(DEQUANTIZER_RANGE_TABLE[0], 1.0);
        assert!(IMDCT_WINDOW[0].is_finite());
        assert!(DEQUANTIZER_SCALING_TABLE[0].is_finite());
    }
}
