def main():
    print("Hello from fibpy!")


if __name__ == "__main__":
    main()
