# omgstatus

A command-line interface tool for managing status on [paste.lol](http://status.lol), a service of omg.lol.  
It does only that but it does it well.

You can access every status of someone on the web at "https://status.lol/<address>".
Mines are here: <https://status.lol/ache>.

## Table of Contents

- [Features](#features)
- [Installation](#installation)
- [Configuration](#configuration)
- [Examples](#examples-of-use)
- [Similar projects](#similar-projects)
- [License](#license)
- [Requirements](#requirements)

## Installation

To install the tool, you can use pip:

```shell
$ pip install lolbin
```

But the recommanded way is via [pipx](https://github.com/pypa/pipx):

```shell
$ pipx install lolbin
```

You can run it with [uv](https://github.com/astral-sh/uv):

```shell
$ uv run lolbin
```

## Configuration

To configure the tool, create a file `~/.config/omgstatus/config.toml` with the following content:

```toml
address = "your_address"
bearer_token = "your_bearer_token"
filters=["@rom", "USA", "iran", "Trump"]
emoji-name-languages = ["fr", "aliases"]
```

You can obtain a bearer token by logging in to the <omg.lol> website, in [you account](https://home.omg.lol/account), at the end of the page, section 'API Key'.

If you don't want to store you API token inside a config file, you can call external command to retrieve it from you secret manager.

With the backtick syntax for command substitution:

```toml
bearer_token = "`bws secret get XXXXXX` | jq .key --raw-output"
```

Or with the dollard based one:

```toml
bearer_token = "$ pass api.omg.lol/token_lolbin"
```

### Filters

You can filter out the status authors and by words.

- To filter someone's status use the `@` notation: `"@test"` to filter the status from the address `"test"`.
- To filter status with the word `USA`, add the filter `"USA"`.

The filters will be applyed independantly to list of statuses only, not to single one.
That mean that the filters: `filters = ["@ache", "USA"]` will hide all the status of [ache](https://ache.omg.lol) and every status that contains the word "USA".

**The filters are configurable only via the configuration file, not as arguments**.

### Languages of emoji short names

You can configure the language(s) to use for emoji short names with `emoji-name-languages`.

```toml
emoji-name-languages = ["fr", "aliases", "full", "es"]
```

Will select the first matching emoji in the same order that the language are specified.

The list of short emoji names is not standardized but follows that of emojiterra:

- French: [Liste d'émojis](https://emojiterra.com/fr/liste-emojis/)
- English: [Emoji list](https://emojiterra.com/emoji-list/)
- Spanish: [Lista de emojis](https://emojiterra.com/es/lista-de-emojis/)
- Italian: [Elenco degli emoji](https://emojiterra.com/it/lista-emoji/)
- German: [Emoji-Liste](https://emojiterra.com/de/liste/)

You can also specify only one language.

```toml
emoji-name-languages = "fr"
```

## Examples of use

1. To list your own status:

   ```shell
   $ omgstatus
   ```

   By default, `omgstatus` print your own status.

   You can filter by date with the `--since` argument:

   ```shell
   $ omgstatus --since 1d
   ```

   The unity format of `since` duration is here.
   It supports french and english usual suffixes.

   Fo examples, `--since 1d` or `--since 1J` is since 1 day.
   3y is 3 years, 35m is 35 minutes but 35M is 35 months.

   ```py
        Format should be DD/MM/YYYY, but support also suffixes:

        | Sfx. | Value   | Lang  | Done |
        +======+=========+=======+======+
        | J/j  | 1 day   |  fr   |  ✅  |
        | D/d  | 1 day   |  en   |  ✅  |
        |  M   | 1 month | en/fr |  ✅  |
        | A/a  | 1 year  |  fr   |  ✅  |
        | Y/y  | 1 year  |  en   |  ✅  |
        |  S   | 1 week  |  fr   |  ✅  |
        | W/w  | 1 week  |  en   |  ✅  |
        |  m   | 1 min   | fr/en |  ✅  |
        |  s   | 1 sec   | fr/en |  ✅  |
        | H/h  | 1 sec   | fr/en |  ✅  |
        """
   ```

   You can also specify a maximum number of status to fetch with `-n` or `--number`:

   ```shell
   $ omgstatus -g -n 5
   ```

   Will print the global five latest status.

   You can combine `--since` and `--number`.

2. To show someone else statuses:

   ```shell
   $ omgstatus @adam
   ```

   Or using the option `--address`

   You can also use `--since` and `--number` with someone else statuses.

3. To show the geral status log use `-g` or `--statuslog`

   To print the 10 last statuses:

   ```shell
   $ omgstatus -g -n 10
   ```

   or to print every status since 5 hours:

   ```shell
   $ omgstatus --statuslog --since 5h
   ```

4. To show the content of a specific status:

   ```shell
   $ omgstatus @address ^status_id
   ```

   Example:

   ```shell
   $ omgstatus @adam ^638e5d13620ed
   ```

   ⚠️ **You must provide the address** with the status, the API hasn't a search by id function.

5. To send a new status:

   You must provide an **emoji along with the status**.

   ```shell
   $ omgstatus 🤖 I am a robot
   ```

   You can also use the name of the emoji with the colon notation: `:robot:`.

   ```shell
   $ omgstatus :robot: I am a robot
   ```

   Check `emoji-name-languages` from the configuration file to have more information about emoji short names.

   You can also send a status from stdin.
   The languages are configurable in the configuration file in the field `emoji-name-languages`.

   ```shell
   $ echo "I'm a robot" | omgstatus 🤖
   ```

6. To edit use a status:

   Use the `--edit` or `-e` option.
   It will open the status content in you configured editor (from the `EDITOR` environment variable).

   You can edit a old status by specifying the status ID.

   ```shell
   $ omgstatus -e ^695c7d3b8c516
   ```

   Or a new status:

   ```shell
   $ omgstatus -e 🎉 Party
   ```

   And the content will be edited in your editor before sending it.

   **Tips**: You can amend your last status with `-l` and `-e`.

   ```shell
   $ omgstatus -e -l
   ```

7. To delete a status:

   Use the `--delete` option.

   ```shell
   $ omgstatus --delete ^695c7d3b8c516
   ```

   **Tips**: You can delete your last status with `-l` and `--delete`.

   ```shell
   $ omgstatus --delete -l
   ```

8. To manage a bio status:

   Use the `--bio` argument.

   ```shell
   $ omgstatus --bio
   🌆 Digital identity

                                                           Ache

    Eternal student in computer science. Self-taught developer, now engineer.

    GNU\Linux, C, C++, Python, Math, self-hosted,…
   ```

   ```shell
   $ omgstatus --bio @adam
                                                           Adam Newbold



    Running Neatnik and building omg.lol. Catch me on social.lol!
   ```

   You can edit your bio with `--edit`:

   ```shell
   $ omgstatus --bio -e
   ```

   Or send it as a normal status from `stdin` or comman--line.

   ```shell
   $ echo "My awesome bio !" | omgstatus --bio
   $ omgstatus --bio My awesome bio \!
   ```

## Similar projects

- [clilol](https://source.tube/mcornick/clilol): A CLI that support all the APIs of omg.lol.
  But too inconvenient to use for me for paste, ideal for status.
- [omglolcli](https://github.com/rknightuk/omglolcli): A CLI that support some of the APIs of omg.lol.
  Nice but incomplet.

## License

`omgstatus` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.

## Requirements

- Python 3.10 or higher, Python syntax
- requests library, for HTTP requests to the api.omg.lol API.
- tomli library, for configuration
- rich library, for markdown support
