import argparse

import haiku as hk
import jax
import numpy as np
import optax
from jax import numpy as jnp, random as jr
from matplotlib import pyplot as plt
from tensorflow_probability.substrates.jax import distributions as tfd

from surjectors import (
  Chain,
  MaskedAutoregressive,
  MaskedCoupling,
  Permutation,
  ScalarAffine,
  TransformedDistribution,
)
from surjectors.nn import MADE, make_mlp
from surjectors.util import (
  as_batch_iterator,
  make_alternating_binary_mask,
  named_dataset,
  unstack,
)


def make_model(dim, model="coupling"):
  def _bijector_fn(params):
    means, log_scales = unstack(params, -1)
    return ScalarAffine(means, jnp.exp(log_scales))

  def _flow(method, **kwargs):
    layers = []
    order = jnp.arange(2)
    for i in range(2):
      if model == "coupling":
        mask = make_alternating_binary_mask(2, i % 2 == 0)
        layer = MaskedCoupling(
          mask=mask,
          bijector_fn=_bijector_fn,
          conditioner=hk.Sequential(
            layers=[
              make_mlp((8, 8, dim * 2)),
              hk.Reshape((dim, dim)),
            ]
          ),
        )
        layers.append(layer)
      else:
        layer = MaskedAutoregressive(
          bijector_fn=_bijector_fn,
          conditioner=MADE(
            2,
            [32, 32],
            2,
            w_init=hk.initializers.TruncatedNormal(0.01),
            b_init=jnp.zeros,
          ),
        )
        order = order[::-1]
        layers.append(layer)
        layers.append(Permutation(order, 1))
    if model != "coupling":
      layers = layers[:-1]
    chain = Chain(layers)

    base_distribution = tfd.Independent(
      tfd.Normal(jnp.zeros(dim), jnp.ones(dim)),
      reinterpreted_batch_ndims=1,
    )
    td = TransformedDistribution(base_distribution, chain)
    return td(method=method, **kwargs)

  td = hk.transform(_flow)
  return td


def train(rng_seq, data, model, n_iter=1_000):
  train_iter = as_batch_iterator(next(rng_seq), data, 100, True)
  params = model.init(next(rng_seq), method="log_prob", **train_iter(0))

  optimizer = optax.adam(1e-4)
  state = optimizer.init(params)

  @jax.jit
  def step(params, state, **batch):
    def loss_fn(params):
      lp = model.apply(params, None, method="log_prob", **batch)
      return -jnp.sum(lp)

    loss, grads = jax.value_and_grad(loss_fn)(params)
    updates, new_state = optimizer.update(grads, state, params)
    new_params = optax.apply_updates(params, updates)
    return loss, new_params, new_state

  losses = np.zeros(n_iter)
  for i in range(n_iter):
    train_loss = 0.0
    for j in range(train_iter.num_batches):
      batch = train_iter(j)
      batch_loss, params, state = step(params, state, **batch)
      train_loss += batch_loss
    losses[i] = train_loss

  return params, losses


def run(n_iter, model):
  n = 10000
  thetas = tfd.Normal(jnp.zeros(2), jnp.full(2, 10.0)).sample(
    seed=jr.key(0), sample_shape=(n,)
  )
  y = 2 * thetas + tfd.Normal(jnp.zeros_like(thetas), jnp.array(0.1)).sample(
    seed=jr.key(1)
  )
  data = named_dataset(y, thetas)

  model = make_model(2, model)
  params, losses = train(hk.PRNGSequence(2), data, model, n_iter)
  samples = model.apply(
    params,
    jr.key(2),
    method="sample",
    x=jnp.full_like(thetas, -2.0),
  )

  plt.hist(samples[:, 0])
  plt.hist(samples[:, 1])
  plt.show()


if __name__ == "__main__":
  parser = argparse.ArgumentParser()
  parser.add_argument("--n-iter", type=int, default=1_000)
  parser.add_argument("--model", type=str, default="coupling")
  args = parser.parse_args()
  run(args.n_iter, args.model)
