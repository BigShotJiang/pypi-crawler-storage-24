# QET Terminal Block Generator

A Python graphical application (using CustomTkinter and tksheet) that generates terminal blocks and connectors for QElectroTech. 

## Installation

```bash
pip install qet_tb_generator_xd
```

## Usage

You can launch the generator from your command line:

```bash
qet_tb_generator
```

## Features
- Import and parse QElectroTech project XML files.
- Visualize and edit Terminal Blocks cleanly via a spreadsheet interface.
- Auto-fill configurations (24V, 0V, PE) and generate bridges.
- Export modified terminal blocks back to your QElectroTech project.
