#!/usr/bin/env python3

import argparse
import configparser
import logging
import os
import sys
import tempfile
import zipfile
import urllib.parse
from pathlib import Path

import boto3
import requests
from botocore.exceptions import ClientError, NoCredentialsError

# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# 配置文件路径（与脚本同目录）
CONFIG_FILE = Path(__file__).parent / 'config.cfg'


def load_config():
    """加载配置文件，返回 S3 配置字典。若文件不存在或缺少 [s3] 节则报错退出。"""
    if not CONFIG_FILE.exists():
        logger.error(f"Config file not found: {CONFIG_FILE}")
        sys.exit(1)
    config = configparser.ConfigParser()
    try:
        config.read(CONFIG_FILE)
    except Exception as e:
        logger.error(f"Failed to read config file: {e}")
        sys.exit(1)

    if 's3' not in config:
        logger.error("Missing [s3] section in config file")
        sys.exit(1)

    s3_config = {
        'endpoint_url': config.get('s3', 'endpoint_url', fallback=None),
        'access_key': config.get('s3', 'access_key', fallback=None),
        'secret_key': config.get('s3', 'secret_key', fallback=None),
        'bucket': config.get('s3', 'bucket', fallback=None)
    }

    # 如果 endpoint_url 为空，boto3 会使用 AWS 默认端点
    return s3_config


def get_s3_client(s3_config):
    """根据配置创建并返回 S3 客户端。"""
    session = boto3.Session(
        aws_access_key_id=s3_config['access_key'],
        aws_secret_access_key=s3_config['secret_key']
    )
    s3_kwargs = {}
    if s3_config['endpoint_url']:
        s3_kwargs['endpoint_url'] = s3_config['endpoint_url']
    return session.client('s3', **s3_kwargs)


def parse_s3_uri(uri):
    """
    解析 S3 URI，提取对象键（key）。
    支持的格式：
      - s3://bucket/key/path
      - s3:///key/path
    无论 bucket 部分是否存在，均将整个路径部分作为 key 返回。
    """
    parsed = urllib.parse.urlparse(uri)
    if parsed.scheme != 's3':
        raise ValueError("URI must start with s3://")
    if parsed.netloc:
        # 格式：s3://bucket/key -> netloc='bucket', path='/key'
        key = parsed.path
    else:
        # 格式：s3:///key -> netloc='', path='/key'
        key = parsed.path.lstrip('/')
    return key

def download_and_extract_from_s3(s3_uri: str, extract_dir: str) -> None:
    """
    从 S3 下载 ZIP 文件，并解压到指定目录。

    Args:
        s3_uri: S3 URI，例如 s3://models/runs.zip
        extract_dir: 解压目标目录，会自动创建
    """
    # 加载配置并创建 S3 客户端
    s3_config = load_config()
    s3_client = get_s3_client(s3_config)
    bucket = s3_config['bucket']

    # 解析 URI 获取 key
    try:
        key = parse_s3_uri(s3_uri)
    except ValueError as e:
        logger.error(f"Invalid S3 URI: {e}")
        sys.exit(1)

    extract_path = Path(extract_dir).expanduser().resolve()
    extract_path.mkdir(parents=True, exist_ok=True)

    # 创建临时文件用于下载
    with tempfile.NamedTemporaryFile(suffix='.zip', delete=False) as tmp_file:
        tmp_zip = tmp_file.name

    try:
        # 从 S3 下载到临时文件
        logger.info(f"Downloading s3://{bucket}/{key} ...")
        s3_client.download_file(bucket, key, tmp_zip)
        logger.info(f"Downloaded to temporary file: {tmp_zip}")

        # 解压
        with zipfile.ZipFile(tmp_zip, 'r') as zip_ref:
            # 安全解压：防止路径遍历攻击
            for member in zip_ref.namelist():
                member_path = Path(member)
                # 跳过包含 '..' 或绝对路径的条目
                if member_path.is_absolute() or '..' in member_path.parts:
                    logger.warning(f"Skipping potentially unsafe path: {member}")
                    continue
                target_path = extract_path / member_path
                if member.endswith('/'):  # 目录
                    target_path.mkdir(parents=True, exist_ok=True)
                else:
                    target_path.parent.mkdir(parents=True, exist_ok=True)
                    with zip_ref.open(member) as source, open(target_path, 'wb') as target:
                        target.write(source.read())
        logger.info(f"Extracted to: {extract_path}")

    except ClientError as e:
        error_code = e.response.get('Error', {}).get('Code')
        if error_code == 'NoSuchKey':
            logger.error(f"Object s3://{bucket}/{key} does not exist.")
        elif error_code == 'NoSuchBucket':
            logger.error(f"Bucket '{bucket}' does not exist.")
        else:
            logger.error(f"S3 download failed: {e}")
        sys.exit(1)
    except zipfile.BadZipFile as e:
        logger.error(f"Invalid ZIP file: {e}")
        sys.exit(1)
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        sys.exit(1)
    finally:
        # 清理临时文件
        if os.path.exists(tmp_zip):
            os.unlink(tmp_zip)
            logger.debug(f"Removed temporary file: {tmp_zip}")


def upload_directory_to_s3(local_dir: str, s3_uri: str) -> None:
    """
    将本地文件夹内容直接上传到 S3 指定目录（不压缩）。

    Args:
        local_dir: 要上传的本地目录路径
        s3_uri: 目标 S3 目录 URI，例如 s3://models/runs/（必须以 / 结尾或自动补全）
    """
    s3_config = load_config()
    s3_client = get_s3_client(s3_config)
    bucket = s3_config['bucket']

    try:
        key_prefix = parse_s3_uri(s3_uri)
    except ValueError as e:
        logger.error(f"Invalid S3 URI: {e}")
        sys.exit(1)

    local_path = Path(local_dir).expanduser().resolve()
    if not local_path.is_dir():
        logger.error(f"Local path is not a directory: {local_dir}")
        sys.exit(1)

    # 遍历本地文件夹，上传每个文件
    total_files = 0
    for root, dirs, files in os.walk(local_path):
        for file in files:
            full_path = Path(root) / file
            # 计算相对路径（相对于 local_path）
            relative_path = full_path.relative_to(local_path)
            # 构建 S3 键名
            s3_key = key_prefix + str(relative_path).replace('\\', '/')
            try:
                logger.info(f"Uploading {relative_path} -> s3://{bucket}/{s3_key}")
                s3_client.upload_file(str(full_path), bucket, s3_key)
                total_files += 1
            except ClientError as e:
                logger.error(f"Failed to upload {relative_path}: {e}")
                sys.exit(1)
            except Exception as e:
                logger.error(f"Unexpected error uploading {relative_path}: {e}")
                sys.exit(1)

    logger.info(f"Upload completed. {total_files} files uploaded to s3://{bucket}/{key_prefix}")


def main():
    parser = argparse.ArgumentParser(description='S3 ZIP 传输工具（配置内置于 config.cfg）')
    subparsers = parser.add_subparsers(dest='command', required=True, help='子命令')

    # download 子命令：从 S3 下载 ZIP 并解压（使用 S3 URI）
    parser_download = subparsers.add_parser('download', help='从 S3 下载 ZIP 并解压，URI 格式：s3://path/to/archive.zip')
    parser_download.add_argument('s3_uri', help='S3 URI，例如 s3://models/runs.zip（存储桶从配置文件读取）')
    parser_download.add_argument('extract_dir', help='解压目标目录')

    # upload 子命令：将本地目录压缩为 ZIP 并上传到 S3
    parser_upload = subparsers.add_parser('upload', help='将本地目录压缩为 ZIP 并上传到 S3')
    parser_upload.add_argument('local_dir', help='要上传的本地目录')
    parser_upload.add_argument('s3_uri', help='目标 S3 目录 URI，例如 s3://models/runs/（推荐以 / 结尾，否则会自动添加）')

    args = parser.parse_args()

    if args.command == 'download':
        download_and_extract_from_s3(args.s3_uri, args.extract_dir)
    elif args.command == 'upload':
        upload_directory_to_s3(args.local_dir, args.s3_uri)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == '__main__':
    main()
