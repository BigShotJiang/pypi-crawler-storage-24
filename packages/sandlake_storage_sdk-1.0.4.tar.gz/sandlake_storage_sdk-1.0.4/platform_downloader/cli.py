#!/usr/bin/env python3
"""
平台模型和数据集下载/上传 CLI 工具

使用方法:
    python cli.py download model org/name --local_dir ./models
    python cli.py upload model org/name --local_dir ./models
    python cli.py list models
    python cli.py list datasets
    python cli.py info org/name
"""

import argparse
import sys
from pathlib import Path

from platform_downloader import PlatformDownloader, ModelNotFoundError, DatasetNotFoundError


def cmd_download(args):
    """下载命令"""
    downloader = PlatformDownloader()
    
    repo_type = "model" if args.type == "model" else "dataset"
    
    try:
        print(f"开始下载 {args.type}: {args.id}")
        download_dir = downloader.snapshot_download(
            model_id=args.id,
            repo_type=repo_type,
            local_dir=args.local_dir,
            cache_dir=args.cache_dir,
            revision=args.revision,
            allow_patterns=args.include,
            ignore_patterns=args.exclude,
            max_workers=args.workers
        )
        print(f"✅ 下载成功: {download_dir}")
    except ModelNotFoundError:
        print(f"❌ {args.type} 不存在: {args.id}")
        sys.exit(1)
    except Exception as e:
        print(f"❌ 下载失败: {e}")
        sys.exit(1)


def cmd_list(args):
    """列出命令"""
    downloader = PlatformDownloader()
    
    if args.type == "models":
        items = downloader.list_models(org=args.org)
        print(f"\n📦 可用模型 ({len(items)}个):")
        for item in items:
            print(f"  - {item['model_id']}")
    else:
        items = downloader.list_datasets(org=args.org)
        print(f"\n📦 可用数据集 ({len(items)}个):")
        for item in items:
            print(f"  - {item['dataset_id']}")


def cmd_info(args):
    """信息命令"""
    downloader = PlatformDownloader()
    
    try:
        info = downloader.get_model_info(args.id)
        print(f"\n📋 模型信息: {args.id}")
        print(f"  S3路径: {info.get('s3_prefix')}")
        print(f"  文件数量: {len(info.get('files', []))}")
        
        if info.get('files'):
            print("\n  文件列表:")
            for file in info.get('files'):
                size_mb = file.get('size', 0) / (1024 * 1024)
                print(f"    - {Path(file['key']).name} ({size_mb:.2f} MB)")
    except Exception as e:
        print(f"❌ 获取信息失败: {e}")
        sys.exit(1)


def cmd_download_file(args):
    """下载单个文件命令"""
    downloader = PlatformDownloader()
    
    repo_type = "model" if args.type == "model" else "dataset"
    
    try:
        print(f"开始下载文件: {args.file_path} from {args.id}")
        file_path = downloader.model_file_download(
            model_id=args.id,
            file_path=args.file_path,
            repo_type=repo_type,
            local_dir=args.local_dir
        )
        print(f"✅ 文件下载成功: {file_path}")
    except Exception as e:
        print(f"❌ 下载失败: {e}")
        sys.exit(1)


def cmd_upload(args):
    """上传命令"""
    downloader = PlatformDownloader()
    
    repo_type = "model" if args.type == "model" else "dataset"
    
    try:
        print(f"开始上传 {args.type}: {args.id}")
        s3_path = downloader.snapshot_upload(
            model_id=args.id,
            local_dir=args.local_dir,
            repo_type=repo_type,
            revision=args.revision,
            allow_patterns=args.include,
            ignore_patterns=args.exclude,
            max_workers=args.workers
        )
        print(f"✅ 上传成功: {s3_path}")
    except Exception as e:
        print(f"❌ 上传失败: {e}")
        sys.exit(1)


def cmd_upload_file(args):
    """上传单个文件命令"""
    downloader = PlatformDownloader()
    
    repo_type = "model" if args.type == "model" else "dataset"
    
    try:
        print(f"开始上传文件: {args.file_path} -> {args.id}")
        s3_key = downloader.model_file_upload(
            model_id=args.id,
            file_path=args.file_path,
            local_path=args.local_file,
            repo_type=repo_type,
            revision=args.revision
        )
        print(f"✅ 文件上传成功: {s3_key}")
    except Exception as e:
        print(f"❌ 上传失败: {e}")
        sys.exit(1)


def main():
    parser = argparse.ArgumentParser(
        description='平台模型和数据集下载/上传工具',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  # 下载模型
  python cli.py download model company/llm-model --local_dir ./models
  
  # 下载数据集
  python cli.py download dataset company/data --local_dir ./datasets
  
  # 下载特定文件
  python cli.py download-file model company/llm-model config.json --local_dir ./models
  
  # 上传模型
  python cli.py upload model company/llm-model --local_dir ./models
  
  # 上传数据集
  python cli.py upload dataset company/data --local_dir ./datasets
  
  # 上传特定文件
  python cli.py upload-file model company/llm-model config.json ./local/config.json
  
  # 列出所有模型
  python cli.py list models
  
  # 列出特定组织的数据集
  python cli.py list datasets --org company
  
  # 获取模型信息
  python cli.py info company/llm-model
        """
    )
    
    subparsers = parser.add_subparsers(dest='command', help='可用命令')
    
    # download 命令
    download_parser = subparsers.add_parser('download', help='下载模型或数据集')
    download_parser.add_argument('type', choices=['model', 'dataset'], help='类型')
    download_parser.add_argument('id', help='模型/数据集ID (如: org/name)')
    download_parser.add_argument('--local_dir', '-d', required=True, help='本地保存目录')
    download_parser.add_argument('--cache_dir', '-c', help='缓存目录')
    download_parser.add_argument('--revision', '-r', default='latest', help='版本标签')
    download_parser.add_argument('--include', '-i', action='append', help='包含的文件模式')
    download_parser.add_argument('--exclude', '-e', action='append', help='排除的文件模式')
    download_parser.add_argument('--workers', '-w', type=int, default=4, help='并发线程数')
    download_parser.set_defaults(func=cmd_download)
    
    # download-file 命令
    download_file_parser = subparsers.add_parser('download-file', help='下载单个文件')
    download_file_parser.add_argument('type', choices=['model', 'dataset'], help='类型')
    download_file_parser.add_argument('id', help='模型/数据集ID')
    download_file_parser.add_argument('file_path', help='文件路径')
    download_file_parser.add_argument('--local_dir', '-d', required=True, help='本地保存目录')
    download_file_parser.set_defaults(func=cmd_download_file)
    
    # upload 命令
    upload_parser = subparsers.add_parser('upload', help='上传模型或数据集')
    upload_parser.add_argument('type', choices=['model', 'dataset'], help='类型')
    upload_parser.add_argument('id', help='模型/数据集ID (如: org/name)')
    upload_parser.add_argument('--local_dir', '-d', required=True, help='本地目录')
    upload_parser.add_argument('--revision', '-r', default='latest', help='版本标签')
    upload_parser.add_argument('--include', '-i', action='append', help='包含的文件模式')
    upload_parser.add_argument('--exclude', '-e', action='append', help='排除的文件模式')
    upload_parser.add_argument('--workers', '-w', type=int, default=4, help='并发线程数')
    upload_parser.set_defaults(func=cmd_upload)
    
    # upload-file 命令
    upload_file_parser = subparsers.add_parser('upload-file', help='上传单个文件')
    upload_file_parser.add_argument('type', choices=['model', 'dataset'], help='类型')
    upload_file_parser.add_argument('id', help='模型/数据集ID')
    upload_file_parser.add_argument('file_path', help='目标文件路径')
    upload_file_parser.add_argument('local_file', help='本地文件路径')
    upload_file_parser.add_argument('--revision', '-r', default='latest', help='版本标签')
    upload_file_parser.set_defaults(func=cmd_upload_file)
    
    # list 命令
    list_parser = subparsers.add_parser('list', help='列出模型或数据集')
    list_parser.add_argument('type', choices=['models', 'datasets'], help='类型')
    list_parser.add_argument('--org', '-o', help='组织名称过滤')
    list_parser.set_defaults(func=cmd_list)
    
    # info 命令
    info_parser = subparsers.add_parser('info', help='获取模型/数据集信息')
    info_parser.add_argument('id', help='模型/数据集ID')
    info_parser.set_defaults(func=cmd_info)
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    args.func(args)


if __name__ == '__main__':
    main()
