"""
平台模型和数据集下载 SDK

基于 S3 存储后端的模型和数据集下载 Python SDK
提供类似 ModelScope 风格的简洁 API

主要功能:
    - snapshot_download: 下载完整的模型或数据集
    - model_file_download: 下载单个文件
    - snapshot_upload: 上传完整的模型或数据集
    - model_file_upload: 上传单个文件
    - PlatformDownloader: 主下载器类
    - PlatformConfig: 配置类

示例:
    >>> from platform_downloader import snapshot_download
    >>> model_dir = snapshot_download("org/model", local_dir="./models")
    >>>
    >>> from platform_downloader import snapshot_upload
    >>> s3_path = snapshot_upload("org/model", local_dir="./models")
"""

from .core import (
    # 主要类
    PlatformDownloader,
    PlatformConfig,
    S3Client,
    PathMapper,
    ProgressTracker,
    
    # 下载便捷函数
    snapshot_download,
    model_file_download,
    dataset_file_download,
    
    # 上传便捷函数
    snapshot_upload,
    model_file_upload,
    dataset_file_upload,
    
    # 异常类
    PlatformError,
    ModelNotFoundError,
    DatasetNotFoundError,
    AuthenticationError,
    DownloadError,
)

__version__ = "1.0.4"
__all__ = [
    "PlatformDownloader",
    "PlatformConfig",
    "S3Client",
    "PathMapper",
    "ProgressTracker",
    # 下载函数
    "snapshot_download",
    "model_file_download",
    "dataset_file_download",
    # 上传函数
    "snapshot_upload",
    "model_file_upload",
    "dataset_file_upload",
    # 异常类
    "PlatformError",
    "ModelNotFoundError",
    "DatasetNotFoundError",
    "AuthenticationError",
    "DownloadError",
]
