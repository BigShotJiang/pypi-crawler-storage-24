## v0.2.1 — Documentation & model updates

### Changes
- Document `--style-ref` and `--asset-ref` examples in README
- Add piping examples (`--output -`, stdin prompt, `--image -`) to README
- Note that `--last-frame` (frame interpolation) requires Veo 2 / Vertex AI billing
- Add `veo-2.0-generate-001` to `--list-models` output with Vertex AI note
- Update `--last-frame` CLI help text to indicate Veo 2 only
- Add `scripts/release.sh` for unified PyPI + GitHub releases

### Install / Upgrade

```bash
uv tool install --upgrade genmedia
# or
pipx upgrade genmedia
```
