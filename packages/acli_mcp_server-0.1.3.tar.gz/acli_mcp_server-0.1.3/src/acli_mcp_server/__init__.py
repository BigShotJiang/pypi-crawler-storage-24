"""acli-mcp-server: MCP server wrapping the Atlassian CLI."""
