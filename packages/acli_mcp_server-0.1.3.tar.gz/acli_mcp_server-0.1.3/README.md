# Atlassian CLI MCP Server

[![PyPI](https://img.shields.io/pypi/v/acli-mcp-server)](https://pypi.org/project/acli-mcp-server)
[![License](https://img.shields.io/pypi/l/acli-mcp-server)](https://github.com/bpmiranda3099/acli-mcp-server/blob/main/LICENSE)
[![Visitors](https://visitor-badge.laobi.icu/badge?page_id=bpmiranda3099.acli-mcp-server)](https://github.com/bpmiranda3099/acli-mcp-server)

MCP server that wraps the [Atlassian CLI (acli)](https://developer.atlassian.com/cloud/acli/) into two generic tools — same pattern as [`gh-cli-mcp-server`](https://github.com/bpmiranda3099/gh-cli-mcp-server).

## Why?

The official Atlassian MCP server exposes 30+ individual tools. This server wraps the entire `acli` binary into just 2:

- `call_acli` — run any `acli` command
- `suggest_acli_commands` — get help with syntax

No need for a dedicated tool per operation. `acli` already covers Jira (work items, projects, boards, sprints) and Confluence (pages, spaces, blogs). This just gives MCP clients a way to execute those commands directly.

## Why not just use `acli` through a shell tool?

You can — it works. This server just cleans things up:

- Parses `acli` output into structured JSON when possible, instead of raw terminal text
- Handles timeouts so commands don't hang forever
- Includes a `suggest_acli_commands` tool for when you're unsure about syntax
- Shows up as a dedicated "atlassian" capability instead of generic shell access
- Blocks shell injection (no `;`, `|`, `&&`, etc.)

Same `acli` underneath, just a safer wrapper for MCP clients to work with.

## Tools

- `call_acli` — Execute any `acli` command and get structured output
- `suggest_acli_commands` — Get command suggestions from a natural language query

## Prerequisites

- [Atlassian CLI (acli)](https://developer.atlassian.com/cloud/acli/guides/install-macos/) installed and authenticated
- [uv](https://docs.astral.sh/uv/getting-started/installation/) (recommended, for running with `uvx`)

## Installation

```bash
pip install acli-mcp-server
```

## Usage with MCP clients

```json
{
  "mcpServers": {
    "atlassian": {
      "command": "uvx",
      "args": ["acli-mcp-server"]
    }
  }
}
```

## Examples

Just ask your MCP client naturally — it'll use `call_acli` under the hood:

| You say | What runs |
|---|---|
| "List my Jira projects" | `acli jira project list --limit 50` |
| "Create a task in PROJ" | `acli jira workitem create --project PROJ --type Task --summary "..."` |
| "Show issue PROJ-123" | `acli jira workitem view PROJ-123` |
| "Move PROJ-123 to Done" | `acli jira workitem transition --key PROJ-123 --status Done` |
| "Find my open tickets" | `acli jira workitem search --jql "assignee = currentUser() AND status != Done" --limit 20` |
| "Show current sprint" | `acli jira sprint list-workitems --sprint 1 --board 6` |

If the client isn't sure which command to use, it can call `suggest_acli_commands` with your prompt to get suggestions first.
