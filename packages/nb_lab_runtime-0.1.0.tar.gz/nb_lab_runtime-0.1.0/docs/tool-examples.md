# Tool Examples

## OpenAI function-calling style (example JSON)
```json
[
  {
    "name": "list_notebook_cells",
    "description": "List cells in a .py:percent notebook.",
    "parameters": {
      "type": "object",
      "properties": {
        "notebook_path": { "type": "string" }
      },
      "required": ["notebook_path"]
    }
  },
  {
    "name": "run_notebook_cell",
    "description": "Run a cell and return a summary of outputs.",
    "parameters": {
      "type": "object",
      "properties": {
        "notebook_path": { "type": "string" },
        "cell_id": { "type": "string" },
        "mode": { "type": "string", "enum": ["incremental", "run_above", "single"] },
        "include_images": { "type": "boolean" }
      },
      "required": ["notebook_path", "cell_id"]
    }
  }
]
```

## Claude/MCP style
See `docs/mcp.json`.
