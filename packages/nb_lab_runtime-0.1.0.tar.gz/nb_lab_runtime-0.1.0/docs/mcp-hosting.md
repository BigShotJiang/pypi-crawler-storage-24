# MCP Hosting

nb-lab currently provides an MCP manifest (`docs/mcp.json`) intended for **external MCP hosts**. nb-lab does **not** run an MCP server itself.

To use MCP with nb-lab:
1. Run the nb-lab HTTP server.
2. Configure your MCP host to use `docs/mcp.json` and point it at the nb-lab base URL.

If you want nb-lab to host MCP directly, open an issue or add a `nb-lab mcp` subcommand.
