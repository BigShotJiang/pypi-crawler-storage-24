# Agent Demo Transcript (E2E)

This is a realistic, step-by-step transcript you can use to demonstrate nb-lab with a real agent thread.

## Setup
```bash
nb-lab serve examples/demo.py
```

## Transcript
```
User: "Check if the series has a mean offset and overlay it on the plot."

Agent -> GET /cells
Agent: Finds plot cell id = c3, base_version = 5

Agent -> GET /cells/c2
Agent: Sees a = sin series. Adds mean calc above plot cell.

Agent -> POST /cells/c2/edit
Agent: Inserts mean computation (mean = sum(values)/len(values))

Agent -> POST /cells/c3/run (mode=incremental)
Agent: nb-lab replays only the dirty prefix (c2..c3)

Agent -> GET /outputs/c3
Agent: Receives plot_meta + image_png
Agent: "Plot now includes a dashed mean line; summary: Line plot with 1 series."

User: "Great, ship it."
```

## Notes
- This transcript is intentionally tool-agnostic: the same flow works via CLI wrappers or raw HTTP.
- The key value: incremental re-run, not full replay.
