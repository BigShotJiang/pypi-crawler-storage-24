# Agent Tools (MVP)

These are logical tools built on top of the HTTP API.

## list_notebook_cells
**Input**
```json
{
  "notebook_path": "path/to/script.py"
}
```

**Behavior**
- Call `GET /cells`.
- Return `CellSummary[]` with IDs, kind, line spans, and snippets.

## get_notebook_context
**Input**
```json
{
  "notebook_path": "path/to/script.py",
  "focus_cell_ids": ["cell-id-1", "cell-id-2"]
}
```

**Behavior**
- Call `GET /cells` and `GET /outputs/{cell_id}` for focus cells.
- Return a compact text summary of snippets + latest `plot_meta.summary_text`.

## edit_notebook_cell
**Input**
```json
{
  "notebook_path": "path/to/script.py",
  "cell_id": "cell-id",
  "new_source": "..."
}
```

**Behavior**
- Call `POST /cells/{cell_id}/edit` with `base_version` from `GET /cells`.
- Return updated `Cell`.

## insert_notebook_cell
**Input**
```json
{
  "notebook_path": "path/to/script.py",
  "after_cell_id": "cell-id-or-null",
  "source": "...",
  "kind": "code"
}
```

**Behavior**
- Call `POST /cells/insert_after` with `base_version`.
- Return new `Cell`.

## run_notebook_cell
**Input**
```json
{
  "notebook_path": "path/to/script.py",
  "cell_id": "cell-id",
  "mode": "incremental",
  "include_images": false
}
```

**Behavior**
- Call `POST /cells/{cell_id}/run` with `base_version`, `mode` in `{"incremental","run_above","single"}`, and optional `include_images`.
- Return a lightweight summary of text outputs and `plot_meta.summary_text`.

## get_plot_meta
**Input**
```json
{
  "notebook_path": "path/to/script.py",
  "cell_id": "cell-id"
}
```

**Behavior**
- Call `GET /outputs/{cell_id}` and return the `plot_meta` payload.

## get_status
**Input**
```json
{
  "notebook_path": "path/to/script.py"
}
```

**Behavior**
- Call `GET /status` and return running status fields.

## Notes
- Always fetch `base_version` from `GET /cells` before edits/runs.
- The `.py` file is the source of truth; API edits write to disk and trigger reparse.
