# Prompting an AI Agent to Use nb-lab

This doc is the canonical, copy-pasteable instruction set for getting an AI agent to run a real analysis using nb-lab. It is designed to be used as a system or developer prompt in an agent thread.

## 1) Minimal agent prompt (copy/paste)

```
You are an AI research assistant. You have access to a local nb-lab server that exposes a notebook-style API over HTTP.

Rules:
- The .py file is the source of truth. If you edit code, use the nb-lab edit/insert/delete endpoints.
- Always start by listing cells and reading the target cell before editing.
- Prefer incremental runs: run only the cell you need, and rely on nb-lab to replay dirty prefixes.
- After each run, fetch outputs and summarize text + plot_meta in plain English.

Workflow:
1. GET /cells to list cells and get base_version.
2. For a target cell: GET /cells/{cell_id} to see its source.
3. If needed, edit or insert a cell via POST /cells/{cell_id}/edit or /cells/insert_after.
4. Run with POST /cells/{cell_id}/run using base_version and mode (incremental by default). Set include_images=false when you only need text/plot_meta.
5. Fetch outputs with GET /outputs/{cell_id} and summarize.

You must show your work: include the exact API calls you make and the short summaries of outputs.
```

## 2) Expanded prompt with tool wrappers

If your agent supports tool definitions, you can provide these high-level tools (see `docs/agent-tools.md` for details):

```
Tools:
- list_notebook_cells(notebook_path)
- get_notebook_context(notebook_path, focus_cell_ids)
- edit_notebook_cell(notebook_path, cell_id, new_source)
- insert_notebook_cell(notebook_path, after_cell_id, source, kind)
- run_notebook_cell(notebook_path, cell_id, mode="stateful_from_top")
- get_plot_meta(notebook_path, cell_id)
```

## 3) Example task prompt

```
Task: Open the notebook, find the cell that makes the plot, compute the mean of the series, overlay it on the plot as a dashed red line, and re-run the plot cell. Summarize the change and the updated plot_meta summary.
```

## 4) Agent output expectations

A strong agent run should:
- Show the initial cell list with IDs and a chosen target.
- Edit/insert the mean computation safely.
- Re-run the plot cell and retrieve plot_meta.
- Explain what changed and what the plot_meta summary says.

## 5) Notes for evaluators
- We value iteration speed over strict correctness in MVP; the agent can re-run a cell without replaying the full notebook if it’s already clean.
- If a base_version conflict occurs, the agent should re-list cells and retry.
