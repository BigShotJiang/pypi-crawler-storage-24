#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

echo "Installing nb-lab as a uv tool..."
uv tool install -e "${ROOT}"
echo "Installed. You can now run: nb-lab serve /path/to/notebook.py"
