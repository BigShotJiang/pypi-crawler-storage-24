#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BASE_URL="${BASE_URL:-http://127.0.0.1:8787}"
NOTEBOOK="${NOTEBOOK:-$ROOT/examples/demo.py}"

cleanup() {
  if [[ -n "${SERVER_PID:-}" ]]; then
    kill "$SERVER_PID" >/dev/null 2>&1 || true
  fi
}
trap cleanup EXIT

echo "Starting nb-lab server on ${BASE_URL} for ${NOTEBOOK}..."
nb-lab serve "$NOTEBOOK" --host 127.0.0.1 --port 8787 >/tmp/nb-lab-server.log 2>&1 &
SERVER_PID=$!

echo "Waiting for server..."
for _ in {1..20}; do
  if curl -fsS "${BASE_URL}/cells" >/dev/null 2>&1; then
    break
  fi
  sleep 0.2
done

echo "Listing cells..."
CELLS_JSON="$(curl -fsS "${BASE_URL}/cells")"
echo "$CELLS_JSON"

read -r VERSION CELL_ID < <(echo "$CELLS_JSON" | python3 - <<'PY'
import json, sys
data = json.load(sys.stdin)
cells = data.get("cells", [])
code_cells = [c for c in cells if c.get("kind") == "code"]
cell = code_cells[0] if code_cells else cells[0]
print(data["version"], cell["id"])
PY
)

echo "Running cell ${CELL_ID} at version ${VERSION}..."
RUN_PAYLOAD=$(python3 - <<PY
import json
print(json.dumps({"mode":"incremental","timeout_ms":60000,"base_version":int(${VERSION})}))
PY
)
curl -fsS -X POST "${BASE_URL}/cells/${CELL_ID}/run" \
  -H "Content-Type: application/json" \
  -d "$RUN_PAYLOAD" | python3 -m json.tool

echo "Fetching outputs for ${CELL_ID}..."
curl -fsS "${BASE_URL}/outputs/${CELL_ID}" | python3 -m json.tool

echo "Smoke demo complete."
