#!/usr/bin/env bash
set -euo pipefail

echo "Release checklist (pre-publish):"
echo "- Update version in pyproject.toml"
echo "- Update README if needed"
echo "- Run tests: uv run pytest"
echo "- Regenerate OpenAPI: bash scripts/gen_openapi.sh"
echo "- Build and publish (future): uv build && uv publish"
