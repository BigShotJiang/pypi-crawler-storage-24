#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="${ROOT}/docs/openapi.json"

PYTHONPATH="${ROOT}/src" uv run python - <<PY > "${OUT}"
import json
from nb_lab.server import create_app

app = create_app("examples/demo.py")
print(json.dumps(app.openapi(), indent=2))
PY

echo "Wrote ${OUT}"
