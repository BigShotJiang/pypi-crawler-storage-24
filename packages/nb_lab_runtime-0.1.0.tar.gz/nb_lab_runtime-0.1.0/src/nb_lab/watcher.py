from __future__ import annotations

import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional

from .notebook_state import _stat_mtime_ns

try:
    from watchdog.events import FileSystemEventHandler
    from watchdog.observers import Observer
except Exception:  # pragma: no cover - fallback when watchdog isn't available
    FileSystemEventHandler = object  # type: ignore
    Observer = None  # type: ignore


OnChange = Callable[[Path], None]


@dataclass
class PollingWatcher:
    path: Path
    on_change: OnChange
    interval: float = 0.5
    _last_mtime_ns: int = 0
    _thread: Optional[threading.Thread] = None
    _stop: threading.Event = threading.Event()

    def __post_init__(self) -> None:
        if not isinstance(self.path, Path):
            self.path = Path(self.path)
        self._last_mtime_ns = _stat_mtime_ns(self.path)

    def start(self) -> None:
        if self._thread is not None:
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=2.0)
        self._thread = None

    def check(self) -> None:
        current = _stat_mtime_ns(self.path)
        if current > self._last_mtime_ns:
            self._last_mtime_ns = current
            self.on_change(self.path)

    def _run(self) -> None:
        while not self._stop.is_set():
            self.check()
            time.sleep(self.interval)


@dataclass
class WatchdogWatcher:
    path: Path
    on_change: OnChange
    debounce_s: float = 0.2
    _observer: Optional[Observer] = None
    _last_emit: float = 0.0

    def __post_init__(self) -> None:
        if not isinstance(self.path, Path):
            self.path = Path(self.path)

    def start(self) -> None:
        if Observer is None:
            raise RuntimeError("watchdog is not available")
        if self._observer is not None:
            return
        handler = _ChangeHandler(self.path, self._emit)
        observer = Observer()
        observer.schedule(handler, str(self.path.parent), recursive=False)
        observer.start()
        self._observer = observer

    def stop(self) -> None:
        if self._observer is None:
            return
        self._observer.stop()
        self._observer.join(timeout=2.0)
        self._observer = None

    def _emit(self, path: Path) -> None:
        now = time.monotonic()
        if now - self._last_emit < self.debounce_s:
            return
        self._last_emit = now
        self.on_change(path)


class _ChangeHandler(FileSystemEventHandler):
    def __init__(self, target: Path, on_change: OnChange) -> None:
        self._target = target.resolve()
        self._on_change = on_change

    def on_modified(self, event) -> None:  # type: ignore[override]
        if Path(event.src_path).resolve() == self._target:
            self._on_change(self._target)

    def on_moved(self, event) -> None:  # type: ignore[override]
        if Path(event.dest_path).resolve() == self._target:
            self._on_change(self._target)


def build_watcher(path: Path, on_change: OnChange) -> object:
    if Observer is None:
        return PollingWatcher(path, on_change)
    try:
        return WatchdogWatcher(path, on_change)
    except Exception:
        return PollingWatcher(path, on_change)
