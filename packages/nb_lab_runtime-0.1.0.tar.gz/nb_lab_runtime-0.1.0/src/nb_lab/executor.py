from __future__ import annotations

import json
import queue
import signal
import subprocess
import threading
import time
from dataclasses import dataclass
from typing import Any, Optional
import sys

from .models import ExecutionResult, OutputItem


_WORKER_CODE = r"""
import ast
import contextlib
import json
import io
import sys
import traceback

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    _PLOT_SHOWN = False

    def _show(*args, **kwargs):
        global _PLOT_SHOWN
        _PLOT_SHOWN = True
        return None

    plt.show = _show
except Exception:
    plt = None

globals_ns = {"__name__": "__main__"}


def _safe_exec(code):
    try:
        tree = ast.parse(code, mode="exec")
    except Exception:
        raise
    body = tree.body
    with contextlib.redirect_stdout(io.StringIO()) as buffer:
        if body and isinstance(body[-1], ast.Expr):
            expr = ast.Expression(body[-1].value)
            exec(compile(ast.Module(body=body[:-1], type_ignores=[]), "<cell>", "exec"), globals_ns)
            value = eval(compile(expr, "<cell>", "eval"), globals_ns)
            return value, True, buffer.getvalue()
        exec(compile(tree, "<cell>", "exec"), globals_ns)
        return None, False, buffer.getvalue()


def _emit(payload):
    sys.stdout.write(json.dumps(payload) + "\n")
    sys.stdout.flush()


def _downsample_pairs(x, y, max_points):
    n = min(len(x), len(y))
    if n <= max_points:
        return [(float(x[i]), float(y[i])) for i in range(n)]
    step = max(1, n // max_points)
    pairs = []
    for i in range(0, n, step):
        pairs.append((float(x[i]), float(y[i])))
        if len(pairs) >= max_points:
            break
    return pairs


def _series_from_pairs(name, pairs, n_points=None):
    if not pairs:
        return None
    xs = [p[0] for p in pairs]
    ys = [p[1] for p in pairs]
    return {
        "name": None if name in (None, "_nolegend_") else name,
        "n_points": int(n_points) if n_points is not None else len(pairs),
        "sample": pairs,
        "x_min": min(xs),
        "x_max": max(xs),
        "y_min": min(ys),
        "y_max": max(ys),
    }


def _capture_plot(max_points=200):
    if plt is None:
        return None
    fig = plt.gcf()
    if fig is None:
        return None
    axes = fig.get_axes()
    if not axes:
        return None
    ax = axes[0]
    series = []
    plot_type = "other"

    for line in ax.get_lines():
        x = list(line.get_xdata())
        y = list(line.get_ydata())
        if len(x) != len(y):
            continue
        plot_type = "line"
        pairs = _downsample_pairs(x, y, max_points)
        summary = _series_from_pairs(line.get_label(), pairs, n_points=len(x))
        if summary:
            series.append(summary)

    for collection in ax.collections:
        offsets = getattr(collection, "get_offsets", None)
        if offsets is None:
            continue
        data = offsets()
        if data is None or len(data) == 0:
            continue
        plot_type = "scatter"
        xs = [float(row[0]) for row in data]
        ys = [float(row[1]) for row in data]
        pairs = _downsample_pairs(xs, ys, max_points)
        summary = _series_from_pairs(None, pairs, n_points=len(xs))
        if summary:
            series.append(summary)

    if ax.patches and plot_type == "other":
        xs = [float(p.get_x() + p.get_width() / 2.0) for p in ax.patches]
        ys = [float(p.get_height()) for p in ax.patches]
        plot_type = "bar"
        pairs = _downsample_pairs(xs, ys, max_points)
        summary = _series_from_pairs(None, pairs, n_points=len(xs))
        if summary:
            series.append(summary)

    grid = None
    extent = None
    if plot_type == "other" and ax.images:
        image = ax.images[0]
        data = image.get_array()
        if data is not None:
            plot_type = "heatmap"
            grid_values = [[float(v) for v in row] for row in data.tolist()]
            extent = image.get_extent()
            grid = {
                "n_x": len(grid_values[0]) if grid_values else 0,
                "n_y": len(grid_values),
                "values": grid_values,
                "x_min": float(extent[0]) if extent else 0.0,
                "x_max": float(extent[1]) if extent else 1.0,
                "y_min": float(extent[2]) if extent else 0.0,
                "y_max": float(extent[3]) if extent else 1.0,
            }

    if not series:
        return None

    meta = {
        "plot_type": plot_type,
        "x_label": ax.get_xlabel() or None,
        "y_label": ax.get_ylabel() or None,
        "title": ax.get_title() or None,
        "series": series,
        "grid": grid,
        "stats": {},
        "summary_text": "Plot with {} series.".format(len(series)),
    }
    buf = io.BytesIO()
    fig.savefig(buf, format="png", bbox_inches="tight")
    buf.seek(0)
    png_hex = buf.getvalue().hex()
    plt.close(fig)
    return {"plot_meta": meta, "image_png": png_hex}


def main():
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except Exception:
            continue
        if msg.get("op") == "shutdown":
            _emit({"op": "shutdown"})
            break
        if msg.get("op") != "exec":
            continue
        code = msg.get("code", "")
        try:
            value, had_value, stdout_text = _safe_exec(code)
            if stdout_text:
                _emit({"op": "stdout", "data": stdout_text})
            if had_value:
                _emit({"op": "repr", "data": repr(value)})
            capture = _capture_plot()
            if capture:
                _emit({"op": "plot_meta", "data": capture["plot_meta"]})
                _emit({"op": "image_png", "data": capture["image_png"]})
            _emit({"op": "ok"})
        except Exception as exc:
            _emit(
                {
                    "op": "error",
                    "error_name": type(exc).__name__,
                    "error_message": str(exc),
                    "traceback": traceback.format_exc(),
                }
            )


if __name__ == "__main__":
    main()
"""


@dataclass
class PythonExecutor:
    python_executable: str = sys.executable
    _proc: Optional[subprocess.Popen[str]] = None
    _stdout_thread: Optional[threading.Thread] = None
    _queue: queue.Queue[dict[str, Any]] = queue.Queue()

    def start(self) -> None:
        if self._proc is not None and self._proc.poll() is None:
            return
        self._proc = subprocess.Popen(
            [self.python_executable, "-u", "-c", _WORKER_CODE],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
        if self._proc.stderr is not None:
            threading.Thread(target=self._read_stderr, daemon=True).start()
        self._queue = queue.Queue()
        self._stdout_thread = threading.Thread(
            target=self._read_stdout, daemon=True
        )
        self._stdout_thread.start()

    def stop(self) -> None:
        if self._proc is None:
            return
        try:
            self._send({"op": "shutdown"})
        except Exception:
            pass
        self._terminate()

    def restart(self) -> None:
        self._terminate()
        self.start()

    def run_cell(self, cell_id: str, code: str, timeout_s: float = 60.0) -> ExecutionResult:
        self.start()
        start = time.perf_counter()
        outputs: list[OutputItem] = []
        stdout_chunks: list[str] = []
        stderr_lines: list[str] = []
        try:
            self._send({"op": "exec", "code": code})
            result = self._collect(timeout_s, outputs, stdout_chunks, stderr_lines, cell_id)
        except TimeoutError:
            self.restart()
            exec_time_ms = int((time.perf_counter() - start) * 1000)
            return ExecutionResult(
                cell_id=cell_id,
                status="timeout",
                exec_time_ms=exec_time_ms,
                outputs=outputs,
                error_message="Execution timed out.",
            )
        exec_time_ms = int((time.perf_counter() - start) * 1000)
        result.exec_time_ms = exec_time_ms
        if stderr_lines:
            result.outputs = list(result.outputs) + [
                OutputItem(type="stderr", data="\n".join(stderr_lines))
            ]
        return result

    def _send(self, payload: dict[str, Any]) -> None:
        if self._proc is None or self._proc.stdin is None:
            raise RuntimeError("Executor is not running.")
        self._proc.stdin.write(json.dumps(payload) + "\n")
        self._proc.stdin.flush()

    def _read_stdout(self) -> None:
        assert self._proc is not None and self._proc.stdout is not None
        for line in self._proc.stdout:
            line = line.strip()
            if not line:
                continue
            try:
                payload = json.loads(line)
            except Exception:
                continue
            self._queue.put(payload)

    def _read_stderr(self) -> None:
        assert self._proc is not None and self._proc.stderr is not None
        for line in self._proc.stderr:
            if line:
                self._queue.put({"op": "stderr", "data": line.rstrip("\n")})

    def _collect(
        self,
        timeout_s: float,
        outputs: list[OutputItem],
        stdout_chunks: list[str],
        stderr_lines: list[str],
        cell_id: str,
    ) -> ExecutionResult:
        deadline = time.monotonic() + timeout_s
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError()
            try:
                payload = self._queue.get(timeout=remaining)
            except queue.Empty:
                raise TimeoutError()
            op = payload.get("op")
            if op == "stdout":
                data = payload.get("data", "")
                if data:
                    stdout_chunks.append(data)
            elif op == "repr":
                outputs.append(OutputItem(type="repr", data=payload.get("data", "")))
            elif op == "plot_meta":
                outputs.append(OutputItem(type="plot_meta", data=payload.get("data", {})))
            elif op == "image_png":
                outputs.append(OutputItem(type="image_png", data=payload.get("data", "")))
            elif op == "stderr":
                data = payload.get("data", "")
                if data:
                    stderr_lines.append(data)
            elif op == "error":
                result = ExecutionResult(
                    cell_id=cell_id,
                    status="error",
                    exec_time_ms=0,
                    outputs=outputs,
                    error_name=payload.get("error_name"),
                    error_message=payload.get("error_message"),
                    traceback=payload.get("traceback"),
                )
                if stdout_chunks:
                    result.outputs = [
                        OutputItem(type="text", data="".join(stdout_chunks))
                    ] + list(result.outputs)
                if stderr_lines:
                    result.outputs = list(result.outputs) + [
                        OutputItem(type="stderr", data="\n".join(stderr_lines))
                    ]
                return result
            elif op == "ok":
                result = ExecutionResult(
                    cell_id=cell_id,
                    status="ok",
                    exec_time_ms=0,
                    outputs=outputs,
                )
                if stdout_chunks:
                    result.outputs = [
                        OutputItem(type="text", data="".join(stdout_chunks))
                    ] + list(result.outputs)
                if stderr_lines:
                    result.outputs = list(result.outputs) + [
                        OutputItem(type="stderr", data="\n".join(stderr_lines))
                    ]
                return result

    def _terminate(self) -> None:
        if self._proc is None:
            return
        try:
            if self._proc.poll() is None:
                self._proc.send_signal(signal.SIGTERM)
                self._proc.wait(timeout=1.0)
        except Exception:
            try:
                self._proc.kill()
            except Exception:
                pass
        self._proc = None

    def __del__(self) -> None:
        try:
            self.stop()
        except Exception:
            pass
