from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from .cell_model import Cell, assign_ids, load_sidecar, parse_cells, save_sidecar


@dataclass
class NotebookState:
    path: Path
    version: int = 0
    cells: list[Cell] = None
    _last_mtime_ns: int = 0
    dirty_ids: set[str] = None

    def __post_init__(self) -> None:
        if not isinstance(self.path, Path):
            self.path = Path(self.path)
        if self.cells is None:
            self.cells = []
        if self.dirty_ids is None:
            self.dirty_ids = set()

    def load(self) -> list[Cell]:
        self._last_mtime_ns = _stat_mtime_ns(self.path)
        self.cells = _parse_with_ids(self.path)
        self.version += 1
        self.dirty_ids = {cell.id for cell in self.cells}
        return self.cells

    def reparse(self) -> list[Cell]:
        self._last_mtime_ns = _stat_mtime_ns(self.path)
        previous_sources = {cell.id: cell.source for cell in self.cells}
        self.cells = _parse_with_ids(self.path)
        self.dirty_ids = {
            cell.id
            for cell in self.cells
            if previous_sources.get(cell.id) != cell.source
        }
        self.version += 1
        return self.cells

    def needs_reparse(self) -> bool:
        current = _stat_mtime_ns(self.path)
        return current > self._last_mtime_ns

    def summaries(self) -> Iterable[tuple[str, str]]:
        for cell in self.cells:
            snippet = cell.source.strip().splitlines()[:1]
            preview = snippet[0] if snippet else ""
            yield cell.id, preview

    def mark_clean(self, cell_id: str) -> None:
        self.dirty_ids.discard(cell_id)


def _parse_with_ids(path: Path) -> list[Cell]:
    text = path.read_text(encoding="utf-8") if path.exists() else ""
    parsed = parse_cells(text)
    previous = load_sidecar(path)
    cells = assign_ids(parsed, previous)
    save_sidecar(path, cells)
    return cells


def _stat_mtime_ns(path: Path) -> int:
    if not path.exists():
        return 0
    return path.stat().st_mtime_ns
