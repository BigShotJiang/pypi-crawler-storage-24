from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal


OutputType = Literal["text", "stderr", "repr", "html", "image_png", "plot_meta"]


@dataclass
class OutputItem:
    type: OutputType
    data: Any


@dataclass
class ExecutionResult:
    cell_id: str
    status: Literal["ok", "error", "timeout"]
    exec_time_ms: int
    outputs: list[OutputItem] = field(default_factory=list)
    error_name: str | None = None
    error_message: str | None = None
    traceback: str | None = None

