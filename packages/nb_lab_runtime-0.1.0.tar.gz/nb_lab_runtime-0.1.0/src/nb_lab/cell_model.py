from __future__ import annotations

import json
import os
import re
import uuid
from dataclasses import dataclass, field
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any, Literal


CellKind = Literal["code", "markdown"]

_MARKER_RE = re.compile(r"^\s*#\s*%%(?:\s*\[(?P<header>.+?)\])?\s*$")


@dataclass
class Cell:
    id: str
    kind: CellKind
    source: str
    start_line: int
    end_line: int
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class ParsedCell:
    kind: CellKind
    source: str
    start_line: int
    end_line: int
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class CellSnapshot:
    id: str
    kind: CellKind
    source: str


def parse_cells(text: str) -> list[ParsedCell]:
    lines = text.splitlines(keepends=True)
    if not lines:
        return []

    markers: list[tuple[int, CellKind, dict[str, Any]]] = []
    for idx, line in enumerate(lines):
        match = _MARKER_RE.match(line)
        if not match:
            continue
        header = (match.group("header") or "").strip().lower()
        kind: CellKind = "markdown" if header in {"markdown", "md"} else "code"
        metadata: dict[str, Any] = {}
        if header:
            metadata["header"] = header
        markers.append((idx, kind, metadata))

    if not markers:
        return [
            ParsedCell(
                kind="code",
                source="".join(lines),
                start_line=1,
                end_line=len(lines),
                metadata={},
            )
        ]

    cells: list[ParsedCell] = []

    def build_cell(
        kind: CellKind,
        metadata: dict[str, Any],
        start_idx: int,
        end_idx: int,
        fallback_line: int,
    ) -> ParsedCell:
        source = "".join(lines[start_idx:end_idx])
        if source:
            start_line = start_idx + 1
            end_line = end_idx
        else:
            start_line = fallback_line
            end_line = fallback_line
        return ParsedCell(
            kind=kind,
            source=source,
            start_line=start_line,
            end_line=end_line,
            metadata=metadata,
        )

    # Handle any content before the first marker as an implicit code cell.
    first_marker_idx, first_kind, first_meta = markers[0]
    if first_marker_idx > 0:
        cells.append(
            build_cell(
                kind="code",
                metadata={},
                start_idx=0,
                end_idx=first_marker_idx,
                fallback_line=1,
            )
        )

    for marker_pos, (marker_idx, kind, metadata) in enumerate(markers):
        start_idx = marker_idx + 1
        if marker_pos + 1 < len(markers):
            end_idx = markers[marker_pos + 1][0]
        else:
            end_idx = len(lines)
        fallback_line = marker_idx + 1
        cells.append(build_cell(kind, metadata, start_idx, end_idx, fallback_line))

    return cells


def assign_ids(
    parsed_cells: list[ParsedCell],
    previous: list[CellSnapshot],
    similarity_threshold: float = 0.55,
) -> list[Cell]:
    remaining = list(enumerate(previous))
    used_prev: set[int] = set()
    cells: list[Cell] = []

    for idx, parsed in enumerate(parsed_cells):
        best_prev_index = None
        best_score = 0.0
        for prev_idx, prev in remaining:
            if prev_idx in used_prev:
                continue
            if prev.kind != parsed.kind:
                continue
            score = _similarity_score(parsed.source, prev.source, parsed.kind, idx, prev_idx)
            if score > best_score:
                best_score = score
                best_prev_index = prev_idx
        if best_prev_index is not None and best_score >= similarity_threshold:
            prev_cell = previous[best_prev_index]
            used_prev.add(best_prev_index)
            cell_id = prev_cell.id
        else:
            cell_id = uuid.uuid4().hex
        cells.append(
            Cell(
                id=cell_id,
                kind=parsed.kind,
                source=parsed.source,
                start_line=parsed.start_line,
                end_line=parsed.end_line,
                metadata=parsed.metadata,
            )
        )

    return cells


def _similarity_score(
    new_source: str, old_source: str, kind: CellKind, new_idx: int, old_idx: int
) -> float:
    normalized_new = _normalize_source(new_source, kind)
    normalized_old = _normalize_source(old_source, kind)
    ratio = SequenceMatcher(None, normalized_new, normalized_old).ratio()
    # Favor local positional continuity for stability.
    position_penalty = 0.02 * abs(new_idx - old_idx)
    return max(0.0, ratio - position_penalty)


def _normalize_source(source: str, kind: CellKind) -> str:
    lines = source.splitlines()
    if kind == "code":
        lines = [line for line in lines if not re.match(r"^\s*#", line)]
    trimmed = [line.rstrip() for line in lines]
    return "\n".join(trimmed).strip()


def sidecar_path(notebook_path: str | Path) -> Path:
    path = Path(notebook_path)
    digest = _cache_key(path)
    cache_root = Path(
        os.environ.get("NB_LAB_CACHE_DIR", Path.home() / ".cache" / "nb-lab")
    )
    return cache_root / f"{digest}.json"


def _cache_root() -> Path:
    default_root = Path.home() / ".cache" / "nb-lab"
    root = Path(os.environ.get("NB_LAB_CACHE_DIR", default_root))
    if _is_writable(root):
        return root
    fallback = Path("/tmp/nb-lab-cache")
    os.environ["NB_LAB_CACHE_DIR"] = str(fallback)
    return fallback


def _is_writable(path: Path) -> bool:
    try:
        path.mkdir(parents=True, exist_ok=True)
        test_file = path / ".write_test"
        test_file.write_text("ok", encoding="utf-8")
        test_file.unlink(missing_ok=True)
        return True
    except Exception:
        return False


def _cache_key(path: Path) -> str:
    return uuid.uuid5(uuid.NAMESPACE_URL, str(path.resolve())).hex


def load_sidecar(path: str | Path) -> list[CellSnapshot]:
    sidecar = sidecar_path(path)
    if not sidecar.exists():
        return []
    raw = json.loads(sidecar.read_text(encoding="utf-8"))
    snapshots: list[CellSnapshot] = []
    for item in raw.get("cells", []):
        snapshots.append(
            CellSnapshot(
                id=item["id"],
                kind=item["kind"],
                source=item["source"],
            )
        )
    return snapshots


def save_sidecar(path: str | Path, cells: list[Cell]) -> None:
    path = Path(path)
    sidecar = sidecar_path(path)
    sidecar.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "cells": [
            {"id": cell.id, "kind": cell.kind, "source": cell.source}
            for cell in cells
        ]
    }
    sidecar.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    meta = {"path": str(path.resolve())}
    meta_path = sidecar.with_suffix(".meta.json")
    meta_path.write_text(json.dumps(meta, indent=2), encoding="utf-8")


def cache_info() -> dict[str, object]:
    root = _cache_root()
    if not root.exists():
        return {"dir": str(root), "entries": 0, "size_bytes": 0}
    entries = [p for p in root.glob("*.json") if not p.name.endswith(".meta.json")]
    size = sum(p.stat().st_size for p in entries)
    return {"dir": str(root), "entries": len(entries), "size_bytes": size}


def cache_list() -> list[dict[str, object]]:
    root = _cache_root()
    results = []
    if not root.exists():
        return results
    for sidecar in root.glob("*.json"):
        if sidecar.name.endswith(".meta.json"):
            continue
        meta_path = sidecar.with_suffix(".meta.json")
        meta = {}
        if meta_path.exists():
            try:
                meta = json.loads(meta_path.read_text(encoding="utf-8"))
            except Exception:
                meta = {}
        results.append(
            {
                "key": sidecar.stem,
                "path": meta.get("path"),
                "size_bytes": sidecar.stat().st_size,
                "mtime": sidecar.stat().st_mtime,
            }
        )
    return results


def cache_clear(path: str | Path | None = None) -> int:
    root = _cache_root()
    if not root.exists():
        return 0
    deleted = 0
    if path is None:
        for item in root.glob("*.json"):
            item.unlink(missing_ok=True)
            deleted += 1
        return deleted
    target = sidecar_path(path)
    meta = target.with_suffix(".meta.json")
    for item in (target, meta):
        if item.exists():
            item.unlink()
            deleted += 1
    return deleted
