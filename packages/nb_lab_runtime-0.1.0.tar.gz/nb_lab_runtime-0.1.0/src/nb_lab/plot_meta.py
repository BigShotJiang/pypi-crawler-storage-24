from __future__ import annotations

import io
from dataclasses import dataclass, field
from typing import Any, Literal

import matplotlib.pyplot as plt

from .models import OutputItem


PlotType = Literal["line", "scatter", "bar", "hist", "heatmap", "other"]


@dataclass
class SeriesSummary:
    name: str | None
    n_points: int
    sample: list[tuple[float, float]]
    x_min: float
    x_max: float
    y_min: float
    y_max: float


@dataclass
class GridEncoding:
    n_x: int
    n_y: int
    values: list[list[float]]
    x_min: float
    x_max: float
    y_min: float
    y_max: float


@dataclass
class PlotMeta:
    plot_type: PlotType
    x_label: str | None
    y_label: str | None
    title: str | None
    series: list[SeriesSummary]
    grid: GridEncoding | None
    stats: dict[str, Any] = field(default_factory=dict)
    summary_text: str = ""


def capture_plot(max_points: int = 200) -> list[OutputItem]:
    fig = plt.gcf()
    if fig is None:
        return []
    axes = fig.get_axes()
    if not axes:
        return []
    ax = axes[0]
    series: list[SeriesSummary] = []
    plot_type: PlotType = "other"

    for line in ax.get_lines():
        x = line.get_xdata().tolist()
        y = line.get_ydata().tolist()
        if len(x) != len(y):
            continue
        plot_type = "line"
        sample = _downsample_pairs(x, y, max_points)
        series.append(_series_from_pairs(line.get_label(), sample))

    for collection in ax.collections:
        offsets = getattr(collection, "get_offsets", None)
        if offsets is None:
            continue
        data = offsets()
        if data is None or len(data) == 0:
            continue
        plot_type = "scatter"
        xs = [float(row[0]) for row in data]
        ys = [float(row[1]) for row in data]
        sample = _downsample_pairs(xs, ys, max_points)
        series.append(_series_from_pairs(None, sample))

    meta = PlotMeta(
        plot_type=plot_type,
        x_label=ax.get_xlabel() or None,
        y_label=ax.get_ylabel() or None,
        title=ax.get_title() or None,
        series=series,
        grid=None,
        summary_text=_summarize(plot_type, series),
    )

    png_item = OutputItem(type="image_png", data=_figure_png(fig))
    meta_item = OutputItem(type="plot_meta", data=_as_dict(meta))
    plt.close(fig)
    return [meta_item, png_item]


def _downsample_pairs(x: list[float], y: list[float], max_points: int) -> list[tuple[float, float]]:
    if not x or not y:
        return []
    n = min(len(x), len(y))
    if n <= max_points:
        return list(zip(x[:n], y[:n]))
    step = max(1, n // max_points)
    return [(x[i], y[i]) for i in range(0, n, step)][:max_points]


def _series_from_pairs(name: str | None, pairs: list[tuple[float, float]]) -> SeriesSummary:
    if not pairs:
        return SeriesSummary(name=name, n_points=0, sample=[], x_min=0, x_max=0, y_min=0, y_max=0)
    xs = [p[0] for p in pairs]
    ys = [p[1] for p in pairs]
    return SeriesSummary(
        name=name if name and name != "_nolegend_" else None,
        n_points=len(pairs),
        sample=pairs,
        x_min=min(xs),
        x_max=max(xs),
        y_min=min(ys),
        y_max=max(ys),
    )


def _summarize(plot_type: PlotType, series: list[SeriesSummary]) -> str:
    if not series:
        return "No plot data detected."
    if plot_type == "line":
        return f"Line plot with {len(series)} series."
    if plot_type == "scatter":
        return f"Scatter plot with {len(series)} series."
    return f"Plot with {len(series)} series."


def _figure_png(fig) -> str:
    buf = io.BytesIO()
    fig.savefig(buf, format="png", bbox_inches="tight")
    buf.seek(0)
    return buf.getvalue().hex()


def _as_dict(meta: PlotMeta) -> dict[str, Any]:
    return {
        "plot_type": meta.plot_type,
        "x_label": meta.x_label,
        "y_label": meta.y_label,
        "title": meta.title,
        "series": [
            {
                "name": s.name,
                "n_points": s.n_points,
                "sample": s.sample,
                "x_min": s.x_min,
                "x_max": s.x_max,
                "y_min": s.y_min,
                "y_max": s.y_max,
            }
            for s in meta.series
        ],
        "grid": None,
        "stats": meta.stats,
        "summary_text": meta.summary_text,
    }
