from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from urllib import request

import uvicorn

from .cell_model import cache_clear, cache_info, cache_list
from .server import create_app


def _request_json(method: str, url: str, payload: dict | None = None) -> dict:
    data = None
    headers = {"Content-Type": "application/json"}
    if payload is not None:
        data = json.dumps(payload).encode("utf-8")
    req = request.Request(url, data=data, headers=headers, method=method)
    try:
        with request.urlopen(req) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except Exception as exc:
        raise SystemExit(f"Request failed. Is the server running at {url}? ({exc})")


def _latest_version(base_url: str) -> int:
    data = _request_json("GET", f"{base_url}/cells")
    return int(data.get("version", 0))


def _cell_id_by_index(base_url: str, index: int) -> str:
    data = _request_json("GET", f"{base_url}/cells")
    cells = data.get("cells", [])
    if index < 0 or index >= len(cells):
        raise SystemExit(f"cell index {index} out of range")
    return cells[index]["id"]


def cmd_serve(args: argparse.Namespace) -> None:
    _ensure_mpl_config_dir()
    app = create_app(args.path)
    try:
        uvicorn.run(app, host=args.host, port=args.port)
    except OSError as exc:
        if args.port != 0:
            print(f"Port {args.port} unavailable ({exc}). Retrying on an ephemeral port.")
            uvicorn.run(app, host=args.host, port=0)
        else:
            raise


def cmd_list(args: argparse.Namespace) -> None:
    data = _request_json("GET", f"{args.base_url}/cells")
    if args.compact:
        print(json.dumps({"version": data.get("version"), "cells": data.get("cells", [])}, indent=2))
    else:
        print(json.dumps(data, indent=2))


def cmd_run(args: argparse.Namespace) -> None:
    if args.cell_id is None and args.cell_index is None:
        raise SystemExit("Provide either cell_id or --cell-index")
    if args.cell_index is not None:
        cell_id = _cell_id_by_index(args.base_url, args.cell_index)
    else:
        cell_id = args.cell_id
    base_version = (
        args.base_version if args.base_version is not None else _latest_version(args.base_url)
    )
    if args.force:
        base_version = _latest_version(args.base_url)
    payload = {
        "mode": args.mode,
        "timeout_ms": args.timeout_ms,
        "base_version": base_version,
        "include_images": not args.no_images,
    }
    data = _request_json("POST", f"{args.base_url}/cells/{cell_id}/run", payload)
    print(json.dumps(data, indent=2))

def cmd_edit(args: argparse.Namespace) -> None:
    if args.cell_id is None and args.cell_index is None:
        raise SystemExit("Provide either cell_id or --cell-index")
    if args.cell_index is not None:
        cell_id = _cell_id_by_index(args.base_url, args.cell_index)
    else:
        cell_id = args.cell_id
    base_version = (
        args.base_version if args.base_version is not None else _latest_version(args.base_url)
    )
    if args.force:
        base_version = _latest_version(args.base_url)
    new_source = _resolve_new_source(args)
    payload = {
        "new_source": new_source,
        "base_version": base_version,
    }
    data = _request_json("POST", f"{args.base_url}/cells/{cell_id}/edit", payload)
    print(json.dumps(data, indent=2))


def cmd_insert(args: argparse.Namespace) -> None:
    base_version = args.base_version if args.base_version is not None else _latest_version(args.base_url)
    payload = {
        "after_id": args.after_id,
        "source": args.source,
        "kind": args.kind,
        "base_version": base_version,
    }
    data = _request_json("POST", f"{args.base_url}/cells/insert_after", payload)
    print(json.dumps(data, indent=2))


def cmd_delete(args: argparse.Namespace) -> None:
    if args.cell_id is None and args.cell_index is None:
        raise SystemExit("Provide either cell_id or --cell-index")
    if args.cell_index is not None:
        cell_id = _cell_id_by_index(args.base_url, args.cell_index)
    else:
        cell_id = args.cell_id
    base_version = (
        args.base_version if args.base_version is not None else _latest_version(args.base_url)
    )
    if args.force:
        base_version = _latest_version(args.base_url)
    payload = {"base_version": base_version}
    data = _request_json("DELETE", f"{args.base_url}/cells/{cell_id}", payload)
    print(json.dumps(data, indent=2))


def cmd_show(args: argparse.Namespace) -> None:
    data = _request_json("GET", f"{args.base_url}/outputs/{args.cell_id}")
    if args.compact:
        print(json.dumps(_compact_outputs(data), indent=2))
    else:
        print(json.dumps(data, indent=2))


def cmd_status(args: argparse.Namespace) -> None:
    cells_data = _request_json("GET", f"{args.base_url}/cells")
    status_data = _request_json("GET", f"{args.base_url}/status")
    version = cells_data.get("version", 0)
    cells = cells_data.get("cells", [])
    dirty_ids = cells_data.get("dirty_ids", [])
    output = {
        "version": version,
        "cell_count": len(cells),
        "dirty_ids": dirty_ids,
        "running_cell_id": status_data.get("running_cell_id"),
        "running_since": status_data.get("running_since"),
    }
    print(json.dumps(output, indent=2))


def cmd_cache(args: argparse.Namespace) -> None:
    if args.cache_action == "info":
        data = cache_info()
        print(json.dumps(data, indent=2))
        return
    if args.cache_action == "list":
        data = cache_list()
        print(json.dumps(data, indent=2))
        return
    if args.cache_action == "clear":
        if args.all and args.path:
            raise SystemExit("Use either --all or --path, not both.")
        if args.all:
            args.yes = True
            args.path = None
        if args.path is None:
            if not args.yes:
                raise SystemExit("Pass --yes to clear the entire cache.")
            deleted = cache_clear()
        else:
            deleted = cache_clear(args.path)
        print(json.dumps({"deleted": deleted}, indent=2))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="nb-lab")
    sub = parser.add_subparsers(dest="command", required=True)

    serve = sub.add_parser("serve")
    serve.add_argument("path", type=str)
    serve.add_argument("--host", default="127.0.0.1")
    serve.add_argument("--port", default=8787, type=int)
    serve.set_defaults(func=cmd_serve)

    list_cmd = sub.add_parser("list")
    list_cmd.add_argument("--base-url", default="http://127.0.0.1:8787")
    list_cmd.add_argument("--compact", action="store_true")
    list_cmd.set_defaults(func=cmd_list)

    run_cmd = sub.add_parser("run")
    run_cmd.add_argument("cell_id", nargs="?")
    run_cmd.add_argument("--cell-index", type=int)
    run_cmd.add_argument("--base-url", default="http://127.0.0.1:8787")
    run_cmd.add_argument("--base-version", type=int)
    run_cmd.add_argument("--timeout-ms", type=int, default=60000)
    run_cmd.add_argument(
        "--mode",
        default="incremental",
        choices=["incremental", "run_above", "single"],
    )
    run_cmd.add_argument("--no-images", action="store_true")
    run_cmd.add_argument("--force", action="store_true")
    run_cmd.set_defaults(func=cmd_run)

    show_cmd = sub.add_parser("show")
    show_cmd.add_argument("cell_id")
    show_cmd.add_argument("--base-url", default="http://127.0.0.1:8787")
    show_cmd.add_argument("--compact", action="store_true")
    show_cmd.set_defaults(func=cmd_show)

    status_cmd = sub.add_parser("status")
    status_cmd.add_argument("--base-url", default="http://127.0.0.1:8787")
    status_cmd.set_defaults(func=cmd_status)

    cache_cmd = sub.add_parser("cache")
    cache_cmd.add_argument("cache_action", choices=["info", "list", "clear"])
    cache_cmd.add_argument("--path", default=None)
    cache_cmd.add_argument("--yes", action="store_true")
    cache_cmd.add_argument("--all", action="store_true")
    cache_cmd.set_defaults(func=cmd_cache)

    edit_cmd = sub.add_parser("edit")
    edit_cmd.add_argument("cell_id", nargs="?")
    edit_cmd.add_argument("--cell-index", type=int)
    edit_cmd.add_argument("new_source", nargs="?")
    edit_cmd.add_argument("--from-stdin", action="store_true")
    edit_cmd.add_argument("--base-url", default="http://127.0.0.1:8787")
    edit_cmd.add_argument("--base-version", type=int)
    edit_cmd.add_argument("--force", action="store_true")
    edit_cmd.set_defaults(func=cmd_edit)

    insert_cmd = sub.add_parser("insert")
    insert_cmd.add_argument("--after-id", default=None)
    insert_cmd.add_argument("--kind", default="code", choices=["code", "markdown"])
    insert_cmd.add_argument("--base-url", default="http://127.0.0.1:8787")
    insert_cmd.add_argument("--base-version", type=int)
    insert_cmd.add_argument("source")
    insert_cmd.set_defaults(func=cmd_insert)

    delete_cmd = sub.add_parser("delete")
    delete_cmd.add_argument("cell_id", nargs="?")
    delete_cmd.add_argument("--cell-index", type=int)
    delete_cmd.add_argument("--base-url", default="http://127.0.0.1:8787")
    delete_cmd.add_argument("--base-version", type=int)
    delete_cmd.add_argument("--force", action="store_true")
    delete_cmd.set_defaults(func=cmd_delete)

    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    args.func(args)


def _resolve_new_source(args: argparse.Namespace) -> str:
    if args.from_stdin:
        return sys.stdin.read()
    if args.new_source is None:
        raise SystemExit("Provide new_source or use --from-stdin")
    return args.new_source


def _ensure_mpl_config_dir() -> None:
    import os
    from pathlib import Path

    if os.environ.get("MPLCONFIGDIR"):
        return
    default_dir = Path.home() / ".cache" / "matplotlib"
    if _is_writable(default_dir):
        os.environ["MPLCONFIGDIR"] = str(default_dir)
        return
    fallback = Path("/tmp/mpl-cache")
    os.environ["MPLCONFIGDIR"] = str(fallback)


def _is_writable(path: Path) -> bool:
    try:
        path.mkdir(parents=True, exist_ok=True)
        test_file = path / ".write_test"
        test_file.write_text("ok", encoding="utf-8")
        test_file.unlink(missing_ok=True)
        return True
    except Exception:
        return False


def _compact_outputs(data: dict) -> dict:
    result = data.get("result", {})
    outputs = []
    for item in result.get("outputs", []):
        if item.get("type") == "image_png":
            outputs.append({"type": "image_png", "data": "<omitted>"})
        else:
            outputs.append(item)
    result["outputs"] = outputs
    data["result"] = result
    return data


if __name__ == "__main__":
    main()
