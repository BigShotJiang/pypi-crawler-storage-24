from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Literal

from .cell_model import Cell, parse_cells
from .notebook_state import _parse_with_ids


CellKind = Literal["code", "markdown"]


@dataclass
class CellEditResult:
    cells: list[Cell]
    text: str


def render_cells(cells: Iterable[Cell]) -> str:
    blocks = []
    for cell in cells:
        marker = "# %% [markdown]\n" if cell.kind == "markdown" else "# %%\n"
        blocks.append(marker)
        source = cell.source or ""
        if source and not source.endswith("\n"):
            source += "\n"
        blocks.append(source)
    return "".join(blocks)


def edit_cell(path: Path, cell_id: str, new_source: str) -> CellEditResult:
    cells = _parse_with_ids(path)
    updated = []
    found = False
    for cell in cells:
        if cell.id == cell_id:
            found = True
            updated.append(
                Cell(
                    id=cell.id,
                    kind=cell.kind,
                    source=new_source,
                    start_line=cell.start_line,
                    end_line=cell.end_line,
                    metadata=cell.metadata,
                )
            )
        else:
            updated.append(cell)
    if not found:
        raise KeyError(f"cell {cell_id} not found")
    text = render_cells(updated)
    path.write_text(text, encoding="utf-8")
    return CellEditResult(cells=updated, text=text)


def insert_cell(path: Path, after_id: str | None, source: str, kind: CellKind) -> CellEditResult:
    cells = _parse_with_ids(path)
    new_cell = Cell(id="__new__", kind=kind, source=source, start_line=0, end_line=0, metadata={})
    if after_id is None:
        updated = [new_cell] + cells
    else:
        updated = []
        inserted = False
        for cell in cells:
            updated.append(cell)
            if cell.id == after_id:
                updated.append(new_cell)
                inserted = True
        if not inserted:
            raise KeyError(f"cell {after_id} not found")
    text = render_cells(updated)
    path.write_text(text, encoding="utf-8")
    return CellEditResult(cells=updated, text=text)


def delete_cell(path: Path, cell_id: str) -> CellEditResult:
    cells = _parse_with_ids(path)
    updated = [cell for cell in cells if cell.id != cell_id]
    if len(updated) == len(cells):
        raise KeyError(f"cell {cell_id} not found")
    text = render_cells(updated)
    path.write_text(text, encoding="utf-8")
    return CellEditResult(cells=updated, text=text)
