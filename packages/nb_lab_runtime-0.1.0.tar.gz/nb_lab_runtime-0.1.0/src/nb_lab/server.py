from __future__ import annotations

import threading
from dataclasses import asdict
from pathlib import Path
from typing import Optional
import time

from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel, Field

from .executor import PythonExecutor
from .models import ExecutionResult, OutputItem
from .notebook_edit import CellKind, delete_cell, edit_cell, insert_cell
from .notebook_state import NotebookState
from .watcher import PollingWatcher, build_watcher


class RunRequest(BaseModel):
    mode: str = "incremental"
    timeout_ms: int = 60000
    base_version: int
    include_images: bool = True


class EditRequest(BaseModel):
    new_source: str
    base_version: int


class InsertRequest(BaseModel):
    after_id: Optional[str] = None
    source: str
    kind: CellKind = "code"
    base_version: int


class DeleteRequest(BaseModel):
    base_version: int


class CellSummary(BaseModel):
    id: str
    kind: CellKind
    start_line: int
    end_line: int
    snippet: str


class CellResponse(BaseModel):
    id: str
    kind: CellKind
    source: str
    start_line: int
    end_line: int
    metadata: dict


class CellsResponse(BaseModel):
    version: int
    cells: list[CellSummary]
    dirty_ids: list[str] | None = None


class StatusResponse(BaseModel):
    version: int
    running_cell_id: str | None
    running_since: float | None


class OutputsResponse(BaseModel):
    cell_id: str
    result: ExecutionResult


class Session:
    def __init__(self, path: Path):
        self.path = path
        self.state = NotebookState(path)
        self.executor = PythonExecutor()
        self.outputs: dict[str, ExecutionResult] = {}
        self._lock = threading.Lock()
        self._exec_lock = threading.Lock()
        self.running_cell_id: str | None = None
        self.running_since: float | None = None
        self.state.load()

        def on_change(_: Path) -> None:
            with self._lock:
                self.state.reparse()
                live_ids = {c.id for c in self.state.cells}
                self.outputs = {cid: out for cid, out in self.outputs.items() if cid in live_ids}

        self.watcher = build_watcher(path, on_change)
        try:
            self.watcher.start()
        except Exception as exc:
            self.watcher = PollingWatcher(path, on_change)
            self.watcher.start()
            print(f"Watcher fallback to polling: {exc}")

    def close(self) -> None:
        try:
            self.watcher.stop()
        except Exception:
            pass
        self.executor.stop()


def create_app(path: str | Path) -> FastAPI:
    notebook_path = Path(path)
    session = Session(notebook_path)
    app = FastAPI(title="nb-lab API")

    @app.on_event("shutdown")
    def _shutdown() -> None:
        session.close()

    @app.get("/cells", response_model=CellsResponse)
    def list_cells() -> CellsResponse:
        with session._lock:
            return CellsResponse(
                version=session.state.version,
                dirty_ids=sorted(session.state.dirty_ids),
                cells=[
                    CellSummary(
                        id=cell.id,
                        kind=cell.kind,
                        start_line=cell.start_line,
                        end_line=cell.end_line,
                        snippet=(cell.source.strip().splitlines() or [""])[0],
                    )
                    for cell in session.state.cells
                ],
            )

    @app.get("/status", response_model=StatusResponse)
    def get_status() -> StatusResponse:
        with session._lock:
            return StatusResponse(
                version=session.state.version,
                running_cell_id=session.running_cell_id,
                running_since=session.running_since,
            )

    @app.get("/cells/{cell_id}", response_model=CellResponse)
    def get_cell(cell_id: str) -> CellResponse:
        with session._lock:
            for cell in session.state.cells:
                if cell.id == cell_id:
                    return CellResponse(**asdict(cell))
        raise HTTPException(status_code=404, detail="Cell not found")

    @app.post("/cells/{cell_id}/run", response_model=ExecutionResult)
    def run_cell(cell_id: str, req: RunRequest) -> ExecutionResult:
        with session._lock:
            _ensure_version(session, req.base_version)
        if req.mode not in {"incremental", "run_above", "single"}:
            raise HTTPException(status_code=400, detail="Unsupported mode")
        return _run_with_lock(session, cell_id, req.timeout_ms, req.mode, req.include_images)

    @app.post("/run_up_to/{cell_id}", response_model=ExecutionResult)
    def run_up_to(cell_id: str, req: RunRequest) -> ExecutionResult:
        with session._lock:
            _ensure_version(session, req.base_version)
        return _run_with_lock(session, cell_id, req.timeout_ms, req.mode, req.include_images)

    @app.get("/outputs/{cell_id}", response_model=OutputsResponse)
    def get_outputs(cell_id: str) -> OutputsResponse:
        with session._lock:
            result = session.outputs.get(cell_id)
        if result is None:
            raise HTTPException(status_code=404, detail="No outputs for cell")
        return OutputsResponse(cell_id=cell_id, result=result)

    @app.post("/cells/{cell_id}/edit", response_model=CellResponse)
    def edit(cell_id: str, req: EditRequest) -> CellResponse:
        with session._lock:
            _ensure_version(session, req.base_version)
            edit_cell(session.path, cell_id, req.new_source)
            session.state.reparse()
            session.outputs = {cid: out for cid, out in session.outputs.items() if cid in {c.id for c in session.state.cells}}
            return _get_cell_response(session, cell_id)

    @app.post("/cells/insert_after", response_model=CellResponse)
    def insert(req: InsertRequest) -> CellResponse:
        with session._lock:
            _ensure_version(session, req.base_version)
            insert_cell(session.path, req.after_id, req.source, req.kind)
            session.state.reparse()
            return _get_cell_response(session, _last_cell_id(session, req.after_id))

    @app.delete("/cells/{cell_id}", response_model=CellsResponse)
    def delete(cell_id: str, base_version: int | None = Query(default=None), req: DeleteRequest | None = None) -> CellsResponse:
        effective_version = req.base_version if req is not None else base_version
        if effective_version is None:
            raise HTTPException(status_code=400, detail="base_version is required")
        with session._lock:
            _ensure_version(session, effective_version)
            delete_cell(session.path, cell_id)
            session.state.reparse()
            session.outputs = {cid: out for cid, out in session.outputs.items() if cid in {c.id for c in session.state.cells}}
            return list_cells()

    return app


def _ensure_version(session: Session, base_version: int) -> None:
    if base_version != session.state.version:
        raise HTTPException(status_code=409, detail="Version conflict")


def _get_cell_response(session: Session, cell_id: str) -> CellResponse:
    for cell in session.state.cells:
        if cell.id == cell_id:
            return CellResponse(**asdict(cell))
    raise HTTPException(status_code=404, detail="Cell not found")


def _last_cell_id(session: Session, after_id: Optional[str]) -> str:
    if after_id is None and session.state.cells:
        return session.state.cells[0].id
    for idx, cell in enumerate(session.state.cells):
        if cell.id == after_id and idx + 1 < len(session.state.cells):
            return session.state.cells[idx + 1].id
    raise HTTPException(status_code=404, detail="Cell not found")


def _run_with_lock(session: Session, cell_id: str, timeout_ms: int, mode: str, include_images: bool) -> ExecutionResult:
    if not session._exec_lock.acquire(blocking=False):
        raise HTTPException(status_code=423, detail="Execution in progress")
    session.running_cell_id = cell_id
    session.running_since = time.monotonic()
    try:
        return _run_up_to(session, cell_id, timeout_ms, mode, include_images)
    finally:
        session.running_cell_id = None
        session.running_since = None
        session._exec_lock.release()


def _run_up_to(session: Session, cell_id: str, timeout_ms: int, mode: str, include_images: bool) -> ExecutionResult:
    with session._lock:
        cells = list(session.state.cells)
        dirty_ids = set(session.state.dirty_ids)
    target_index = next((i for i, c in enumerate(cells) if c.id == cell_id), None)
    if target_index is None:
        raise HTTPException(status_code=404, detail="Cell not found")
    last_result: Optional[ExecutionResult] = None
    run_until = target_index
    if mode == "single":
        start_index = target_index
    elif mode == "run_above":
        start_index = 0
    else:
        # incremental: determine minimal prefix to re-run (first dirty to target)
        start_index = target_index
        for idx, cell in enumerate(cells[: target_index + 1]):
            if cell.id in dirty_ids:
                start_index = idx
                break

    for cell in cells[start_index : run_until + 1]:
        last_result = session.executor.run_cell(cell.id, cell.source, timeout_ms / 1000.0)
        if not include_images:
            last_result.outputs = [o for o in last_result.outputs if o.type != "image_png"]
        with session._lock:
            session.outputs[cell.id] = last_result
            session.state.mark_clean(cell.id)
        if last_result.status != "ok":
            return last_result
    if last_result is None:
        # If nothing ran, return last known output for the target cell.
        with session._lock:
            cached = session.outputs.get(cell_id)
        if cached is None:
            raise HTTPException(status_code=409, detail="Cell has not been run yet")
        return cached
    return last_result
