# %% [markdown]
# Demo notebook for nb-lab
#
# This file is used to smoke-test the nb-lab server and CLI.

# %%
import math

values = [math.sin(x / 10.0) for x in range(0, 200)]
mean = sum(values) / len(values)
mean

# %% [markdown]
# Simple plot

# %%
import matplotlib.pyplot as plt

xs = list(range(len(values)))
plt.plot(xs, values, label="sin(x/10)")
plt.axhline(mean, color="red", linestyle="--", label="mean")
plt.title("Sine-ish series")
plt.legend()
plt.show()
