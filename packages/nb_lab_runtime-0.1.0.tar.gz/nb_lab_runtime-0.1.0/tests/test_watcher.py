from pathlib import Path

from nb_lab.watcher import PollingWatcher


def test_polling_watcher_detects_change(tmp_path):
    path = tmp_path / "note.py"
    path.write_text("a = 1\n", encoding="utf-8")

    changes = []

    def on_change(changed: Path) -> None:
        changes.append(changed)

    watcher = PollingWatcher(path, on_change, interval=0.0)
    path.write_text("a = 2\n", encoding="utf-8")
    watcher.check()

    assert len(changes) == 1
    assert changes[0] == path
