from nb_lab.cell_model import ParsedCell, assign_ids, load_sidecar, parse_cells, save_sidecar


def test_parse_cells_with_markers():
    text = "# %% [markdown]\n# Title\n# %%\nx = 1\n"
    cells = parse_cells(text)
    assert len(cells) == 2
    assert cells[0].kind == "markdown"
    assert cells[0].source == "# Title\n"
    assert cells[0].start_line == 2
    assert cells[0].end_line == 2
    assert cells[1].kind == "code"
    assert cells[1].source == "x = 1\n"
    assert cells[1].start_line == 4
    assert cells[1].end_line == 4


def test_parse_cells_without_markers():
    text = "a = 1\nb = 2\n"
    cells = parse_cells(text)
    assert len(cells) == 1
    assert cells[0].kind == "code"
    assert cells[0].source == text
    assert cells[0].start_line == 1
    assert cells[0].end_line == 2


def test_assign_ids_preserves_similarity():
    previous = [
        ParsedCell(kind="code", source="a = 1\n", start_line=1, end_line=1, metadata={}),
        ParsedCell(kind="code", source="b = 2\n", start_line=3, end_line=3, metadata={}),
    ]
    prev_ids = assign_ids(previous, [])
    parsed = [
        ParsedCell(kind="code", source="a = 1\n# comment\n", start_line=1, end_line=2, metadata={}),
        ParsedCell(kind="code", source="b = 2\n", start_line=4, end_line=4, metadata={}),
    ]
    new_cells = assign_ids(parsed, _snapshots(prev_ids))
    assert new_cells[0].id == prev_ids[0].id
    assert new_cells[1].id == prev_ids[1].id


def test_assign_ids_generates_new_for_unmatched():
    prev = [ParsedCell(kind="code", source="a = 1\n", start_line=1, end_line=1, metadata={})]
    prev_cells = assign_ids(prev, [])
    parsed = [ParsedCell(kind="code", source="totally different\n", start_line=1, end_line=1, metadata={})]
    new_cells = assign_ids(parsed, _snapshots(prev_cells))
    assert new_cells[0].id != prev_cells[0].id


def test_sidecar_roundtrip(tmp_path):
    import os
    cells = parse_cells("# %%\nx = 1\n")
    assigned = assign_ids(cells, [])
    path = tmp_path / "note.py"
    path.write_text("# %%\nx = 1\n", encoding="utf-8")
    os.environ["NB_LAB_CACHE_DIR"] = str(tmp_path / "cache")
    save_sidecar(path, assigned)
    loaded = load_sidecar(path)
    assert len(loaded) == 1
    assert loaded[0].id == assigned[0].id


def _snapshots(cells):
    from nb_lab.cell_model import CellSnapshot

    snapshots = []
    for cell in cells:
        snapshots.append(CellSnapshot(id=cell.id, kind=cell.kind, source=cell.source))
    return snapshots
