from nb_lab.server import Session, _run_up_to


def test_incremental_run_skips_clean_prefix(tmp_path):
    path = tmp_path / "note.py"
    path.write_text("# %%\na = 1\n# %%\nb = a + 1\n# %%\nc = b + 1\n", encoding="utf-8")
    session = Session(path)
    base_version = session.state.version

    first = _run_up_to(session, session.state.cells[2].id, 2000, "incremental", True)
    assert first.status == "ok"
    assert not session.state.dirty_ids

    # Re-run the last cell with no changes; should return cached output.
    second = _run_up_to(session, session.state.cells[2].id, 2000, "incremental", True)
    assert second.cell_id == first.cell_id
    session.close()
