import matplotlib

matplotlib.use("Agg")

from nb_lab.executor import PythonExecutor


def test_plot_meta_capture():
    executor = PythonExecutor()
    code = """
import matplotlib.pyplot as plt
plt.plot([0, 1, 2], [0, 1, 0])
plt.title("Demo")
plt.show()
"""
    result = executor.run_cell("cell-plot", code)
    plot_meta = [o for o in result.outputs if o.type == "plot_meta"]
    images = [o for o in result.outputs if o.type == "image_png"]
    assert plot_meta, "plot_meta output missing"
    assert images, "image_png output missing"
    executor.stop()


def test_plot_meta_bar_plot():
    executor = PythonExecutor()
    code = """
import matplotlib.pyplot as plt
plt.bar([0, 1, 2], [1, 2, 3])
plt.show()
"""
    result = executor.run_cell("cell-bar", code)
    plot_meta = [o for o in result.outputs if o.type == "plot_meta"]
    assert plot_meta, "plot_meta output missing"
    assert plot_meta[0].data.get("plot_type") == "bar"
    executor.stop()


def test_plot_meta_n_points_is_full_length():
    executor = PythonExecutor()
    xs = list(range(300))
    ys = [x * 0.1 for x in xs]
    code = f"""
import matplotlib.pyplot as plt
plt.plot({xs}, {ys})
plt.show()
"""
    result = executor.run_cell("cell-long", code)
    plot_meta = [o for o in result.outputs if o.type == "plot_meta"]
    assert plot_meta, "plot_meta output missing"
    series = plot_meta[0].data["series"][0]
    assert series["n_points"] == 300
    assert len(series["sample"]) <= 200
    executor.stop()
