import json
from urllib import request

from nb_lab.cli import _request_json


class _FakeResponse:
    def __init__(self, payload: dict):
        self._payload = payload

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False

    def read(self):
        return json.dumps(self._payload).encode("utf-8")


def test_request_json_encodes_payload(monkeypatch):
    captured = {}

    def fake_urlopen(req):
        captured["method"] = req.get_method()
        captured["data"] = req.data
        return _FakeResponse({"ok": True})

    monkeypatch.setattr(request, "urlopen", fake_urlopen)
    result = _request_json("POST", "http://example", {"a": 1})
    assert result["ok"] is True
    assert captured["method"] == "POST"
    assert json.loads(captured["data"].decode("utf-8")) == {"a": 1}


def test_latest_version_fetch(monkeypatch):
    from nb_lab import cli

    def fake_request(method, url, payload=None):
        assert method == "GET"
        return {"version": 12}

    monkeypatch.setattr(cli, "_request_json", fake_request)
    assert cli._latest_version("http://127.0.0.1:8787") == 12


def test_cell_id_by_index(monkeypatch):
    from nb_lab import cli

    def fake_request(method, url, payload=None):
        return {"cells": [{"id": "a"}, {"id": "b"}]}

    monkeypatch.setattr(cli, "_request_json", fake_request)
    assert cli._cell_id_by_index("http://127.0.0.1:8787", 1) == "b"


def test_status_output(monkeypatch, capsys):
    from nb_lab import cli

    def fake_request(method, url, payload=None):
        if url.endswith("/cells"):
            return {"version": 3, "cells": [{"id": "a"}], "dirty_ids": ["a"]}
        return {"version": 3, "running_cell_id": "a", "running_since": 1.23}

    monkeypatch.setattr(cli, "_request_json", fake_request)
    cli.cmd_status(type("Args", (), {"base_url": "http://127.0.0.1:8787"}))
    out = capsys.readouterr().out
    assert '"version": 3' in out
    assert '"dirty_ids"' in out
    assert '"a"' in out


def test_cache_clear_requires_yes(monkeypatch):
    from nb_lab import cli

    called = {"count": 0}

    def fake_clear(path=None):
        called["count"] += 1
        return 1

    monkeypatch.setattr(cli, "cache_clear", fake_clear)

    class Args:
        cache_action = "clear"
        path = None
        yes = False
        all = False

    try:
        cli.cmd_cache(Args())
    except SystemExit as exc:
        assert "--yes" in str(exc)
    else:
        raise AssertionError("Expected SystemExit")


def test_cache_clear_all(monkeypatch):
    from nb_lab import cli

    called = {"count": 0}

    def fake_clear(path=None):
        called["count"] += 1
        return 1

    monkeypatch.setattr(cli, "cache_clear", fake_clear)

    class Args:
        cache_action = "clear"
        path = None
        yes = False
        all = True

    cli.cmd_cache(Args())
    assert called["count"] == 1


def test_resolve_new_source_from_stdin(monkeypatch):
    from nb_lab import cli

    class Args:
        from_stdin = True
        new_source = None

    class _Input:
        @staticmethod
        def read():
            return "x = 1\n"

    monkeypatch.setattr(cli, "sys", type("S", (), {"stdin": _Input()}))
    assert cli._resolve_new_source(Args()) == "x = 1\n"


def test_compact_outputs():
    from nb_lab import cli

    data = {
        "result": {
            "outputs": [
                {"type": "text", "data": "hi"},
                {"type": "image_png", "data": "deadbeef"},
            ]
        }
    }
    compact = cli._compact_outputs(data)
    outputs = compact["result"]["outputs"]
    assert outputs[1]["data"] == "<omitted>"
