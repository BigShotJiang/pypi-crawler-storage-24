import os

from nb_lab.cell_model import cache_clear, cache_info, cache_list, parse_cells, assign_ids, save_sidecar


def test_cache_roundtrip(tmp_path, monkeypatch):
    monkeypatch.setenv("NB_LAB_CACHE_DIR", str(tmp_path / "cache"))
    cells = assign_ids(parse_cells("# %%\na = 1\n"), [])
    save_sidecar(tmp_path / "note.py", cells)
    info = cache_info()
    assert info["entries"] == 1
    listed = cache_list()
    assert listed and listed[0]["path"].endswith("note.py")
    deleted = cache_clear()
    assert deleted >= 1
    info = cache_info()
    assert info["entries"] == 0
