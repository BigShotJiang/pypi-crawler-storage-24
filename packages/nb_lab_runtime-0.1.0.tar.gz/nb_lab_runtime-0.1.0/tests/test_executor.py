from nb_lab.executor import PythonExecutor


def test_executor_runs_code_and_returns_repr():
    executor = PythonExecutor()
    result = executor.run_cell("cell-1", "1 + 2")
    assert result.status == "ok"
    assert result.cell_id == "cell-1"
    repr_outputs = [o.data for o in result.outputs if o.type == "repr"]
    assert repr_outputs and repr_outputs[0] == "3"
    executor.stop()


def test_executor_captures_error():
    executor = PythonExecutor()
    result = executor.run_cell("cell-2", "raise ValueError('boom')")
    assert result.status == "error"
    assert result.error_name == "ValueError"
    assert "boom" in (result.error_message or "")
    executor.stop()


def test_executor_captures_stdout():
    executor = PythonExecutor()
    result = executor.run_cell("cell-3", "print('hi')\n'bye'")
    assert result.status == "ok"
    text_outputs = [o.data for o in result.outputs if o.type == "text"]
    assert text_outputs and "hi" in text_outputs[0]
    executor.stop()
