from pathlib import Path

from nb_lab.notebook_state import NotebookState


def test_notebook_state_reparse_increments_version_and_preserves_ids(tmp_path):
    path = tmp_path / "note.py"
    path.write_text("# %%\na = 1\n", encoding="utf-8")

    state = NotebookState(path)
    cells = state.load()
    assert state.version == 1
    assert len(cells) == 1
    first_id = cells[0].id

    path.write_text("# %%\na = 1\n# comment\n", encoding="utf-8")
    cells = state.reparse()
    assert state.version == 2
    assert len(cells) == 1
    assert cells[0].id == first_id
    assert first_id in state.dirty_ids

    # Sidecar files now live in a user cache directory, not next to the notebook.
