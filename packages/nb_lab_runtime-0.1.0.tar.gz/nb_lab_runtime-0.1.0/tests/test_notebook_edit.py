from pathlib import Path

from nb_lab.notebook_edit import delete_cell, edit_cell, insert_cell
from nb_lab.notebook_state import NotebookState


def test_edit_insert_delete_cell(tmp_path):
    path = tmp_path / "note.py"
    path.write_text("# %%\na = 1\n# %%\nb = 2\n", encoding="utf-8")
    state = NotebookState(path)
    cells = state.load()
    first_id = cells[0].id
    second_id = cells[1].id

    edit_cell(path, first_id, "a = 10\n")
    state.reparse()
    assert any(c.id == first_id and "a = 10" in c.source for c in state.cells)

    insert_cell(path, first_id, "c = 3\n", "markdown")
    state.reparse()
    assert any("c = 3" in c.source for c in state.cells)

    delete_cell(path, second_id)
    state.reparse()
    assert all(c.id != second_id for c in state.cells)
