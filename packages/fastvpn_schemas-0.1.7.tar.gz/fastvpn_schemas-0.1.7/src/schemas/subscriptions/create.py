from datetime import datetime
from typing import Optional

from pydantic import BaseModel, Field

from .base import SubscriptionStatus


class SubscriptionCreate(BaseModel):
    user_id: int
    plan_id: int = Field(..., ge=1)
    status: SubscriptionStatus = SubscriptionStatus.PENDING
    current_period_start: datetime
    current_period_end: datetime
    next_billing_attempt: Optional[datetime] = None
    canceled_at: Optional[datetime] = None
