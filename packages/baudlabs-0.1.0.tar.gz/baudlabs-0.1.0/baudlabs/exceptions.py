class BaudLabsError(Exception):
    """Base exception for all BaudLabs SDK errors."""

    def __init__(self, message: str, status_code: int | None = None, response: dict | None = None):
        super().__init__(message)
        self.status_code = status_code
        self.response = response or {}


class AuthenticationError(BaudLabsError):
    """Raised when the API key is invalid or missing."""
    pass


class InsufficientCreditsError(BaudLabsError):
    """Raised when the account doesn't have enough credits."""

    def __init__(self, message: str, credits_remaining: float = 0, cost: float = 0, **kwargs):
        super().__init__(message, **kwargs)
        self.credits_remaining = credits_remaining
        self.cost = cost


class NotFoundError(BaudLabsError):
    """Raised when a requested resource (e.g. index) is not found."""
    pass


class ValidationError(BaudLabsError):
    """Raised when the request is invalid."""
    pass


class ServerError(BaudLabsError):
    """Raised when the server returns a 5xx error."""
    pass
