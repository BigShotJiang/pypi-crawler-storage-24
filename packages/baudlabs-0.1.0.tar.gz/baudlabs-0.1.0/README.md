# BaudLabs Python SDK

Python client for the [BaudLabs](https://baudlabs.ai) image and video search API.

## Install

```bash
pip install baudlabs
```

## Quick start

```python
import baudlabs

client = baudlabs.Client("bl_your_api_key")
```

## Video Search

```python
client.create_index("my_videos")

client.add_videos(
    index_id="my_videos",
    files=["video1.mp4", "video2.mp4"],
)

results = client.search(
    index_id="my_videos",
    query="person walking a dog",
    media_type="video",
)

for match in results.matches:
    print(match.video_id, match.start_time, match.end_time, match.score)
```

## Image Search

```python
client.create_index("my_images")

client.add_images(
    index_id="my_images",
    files=["img1.jpg", "img2.jpg"],
)

results = client.search(
    index_id="my_images",
    query="sunset over ocean",
    media_type="image",
)

for match in results.matches:
    print(match.image_id, match.score)
```

## Mixed Image and Video Search

```python
client.create_index("my_media")

client.add_images(
    index_id="my_media",
    files=["img1.jpg", "img2.jpg"],
)

client.add_videos(
    index_id="my_media",
    files=["video1.mp4", "video2.mp4"],
)

results = client.search(
    index_id="my_media",
    query="a red car driving on a city street",
    media_type="mixed",
)

for match in results.matches:
    if match.image_id:
        print("image", match.image_id, match.image_url, match.score)
    if match.video_id:
        print("video", match.video_id, match.start_time, match.end_time, match.video_url, match.score)
```