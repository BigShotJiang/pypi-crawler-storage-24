import re
import unicodedata
from difflib import SequenceMatcher

# Matches standard emoji, pictographs, enclosed alphanumerics, and variation selectors
EMOJI_PATTERN = re.compile(
    "["
    "\U0001F600-\U0001F64F"  # emoticons
    "\U0001F300-\U0001F5FF"  # misc symbols & pictographs
    "\U0001F680-\U0001F6FF"  # transport & map
    "\U0001F700-\U0001F77F"  # alchemical symbols
    "\U0001F780-\U0001F7FF"  # geometric shapes extended
    "\U0001F800-\U0001F8FF"  # supplemental arrows
    "\U0001F900-\U0001F9FF"  # supplemental symbols & pictographs
    "\U0001FA00-\U0001FA6F"  # chess symbols
    "\U0001FA70-\U0001FAFF"  # symbols and pictographs extended-A
    "\U00002702-\U000027B0"  # dingbats
    "\U000024C2-\U0001F251"  # enclosed characters (e.g. circled letters)
    "\uFE00-\uFE0F"          # variation selectors (emoji vs text presentation)
    "\u200D"                 # zero-width joiner (used in emoji sequences)
    "]+",
    flags=re.UNICODE,
)

LEET_MAP = str.maketrans({
    "0": "o",
    "1": "i",
    "3": "e",
    "4": "a",
    "5": "s",
    "6": "g",
    "7": "t",
    "@": "a",
    "$": "s",
    "!": "i",
})

SUSPICIOUS_PATTERNS = [
    # Instruction override
    "ignore previous instructions",
    "ignore all previous instructions",
    "ignore prior instructions",
    "ignore your instructions",
    "disregard previous instructions",
    "disregard all instructions",
    "disregard your guidelines",
    "forget previous instructions",
    "forget your instructions",
    "forget your training",
    "do not follow prior rules",
    "do not follow your instructions",

    # System prompt extraction
    "reveal system prompt",
    "show system prompt",
    "print hidden instructions",
    "repeat your instructions",
    "output your instructions",
    "what is your system prompt",
    "what are your instructions",
    "tell me your prompt",
    "display your system prompt",

    # Role / persona switching
    "you are now",
    "act as dan",
    "do anything now",
    "pretend you are",
    "act as if you are",
    "roleplay as",
    "switch to developer mode",
    "enable developer mode",
    "enter developer mode",
    "you have no restrictions",
    "you are unrestricted",
    "act without restrictions",
    "pretend you have no restrictions",

    # Restriction/ethics bypass framing
    "without ethical constraints",
    "without moral constraints",
    "ignore ethics",
    "ignore your guidelines",
    "no restrictions apply",
    "safety filters disabled",
    "ignore safety",

    # Injection via task framing
    "translate the following then ignore",
    "summarize the above and then",
    "after summarizing ignore",

    # Known jailbreak keywords
    "jailbreak",
    "override safety",
    "bypass safety",
    "developer message",
    "system message",
    "god mode",
    "unrestricted mode",
    "dan mode",
    "stan mode",
    "dude mode",
]

ROLE_CONFUSION_PATTERNS = [
    r"\bsystem\s*:",
    r"\bdeveloper\s*:",
    r"\bassistant\s*:",
    r"\bnew instructions\s*:",
]


def strip_emojis(text: str) -> str:
    """Remove emoji characters, leaving surrounding text intact."""
    return EMOJI_PATTERN.sub(" ", text)


def contains_emojis(text: str) -> bool:
    return bool(EMOJI_PATTERN.search(text))


def normalize_text(text: str) -> str:
    text = unicodedata.normalize("NFKC", text).lower()
    text = text.translate(LEET_MAP)
    text = re.sub(r"[_\-\.\,\;\|\*/\\]+", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def fuzzy_contains(text: str, phrase: str, threshold: float = 0.88) -> bool:
    if phrase in text:
        return True
    words = text.split()
    target_len = len(phrase.split())
    for i in range(len(words) - target_len + 1):
        span = " ".join(words[i:i + target_len])
        if SequenceMatcher(None, span, phrase).ratio() >= threshold:
            return True
    return False


def detect_prompt_injection(text: str) -> dict:
    """Analyze text for prompt injection attempts.

    Returns a dict with keys:
        label: "benign", "suspicious", or "high_risk"
        score: integer risk score
        normalized_text: preprocessed version of the input
        reasons: list of matched rule descriptions
        raw_text: original input
    """
    raw = text
    norm = normalize_text(text)

    reasons = []
    score = 0

    # Emoji obfuscation check: strip emojis and re-scan the cleaned text
    has_emojis = contains_emojis(raw)
    emoji_stripped_norm = normalize_text(strip_emojis(raw))
    if has_emojis:
        reasons.append("input contains emoji characters (possible obfuscation)")
        score += 1

    for p in SUSPICIOUS_PATTERNS:
        if fuzzy_contains(norm, p) or (has_emojis and fuzzy_contains(emoji_stripped_norm, p)):
            reasons.append(f"matched suspicious phrase: {p}")
            score += 2

    for rp in ROLE_CONFUSION_PATTERNS:
        if re.search(rp, norm) or (has_emojis and re.search(rp, emoji_stripped_norm)):
            reasons.append(f"matched role confusion pattern: {rp}")
            score += 2

    if len(norm) > 4000:
        reasons.append("very long input; consider long-context jailbreak review")
        score += 1

    check_norm = emoji_stripped_norm if has_emojis else norm
    if "ignore" in check_norm and ("system" in check_norm or "developer" in check_norm):
        reasons.append("instruction-priority manipulation")
        score += 3

    label = "benign"
    if score >= 5:
        label = "high_risk"
    elif score >= 2:
        label = "suspicious"

    return {
        "label": label,
        "score": score,
        "normalized_text": norm,
        "reasons": reasons,
        "raw_text": raw,
    }
