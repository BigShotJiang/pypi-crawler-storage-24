"""Shared connectors and retrieval handlers for ENTR adapters.

Connectors provide reusable integrations with common external systems:
- FTPConnector: FTP file operations (list, download, upload, delete)
- SFTPConnector: SFTP file operations with persistent connection and auto-reconnect

Retrieval handlers implement the RetrievalHandler interface for common sources:
- EntrMailboxRetrievalHandler: Gmail mailbox retrieval via OAuth2
- MicrosoftEntraRetrievalHandler: Microsoft Exchange via Graph API

Connectors with optional dependencies use lazy imports. If the required
extra is not installed, importing the connector raises an ``ImportError``
with a clear message directing the user to install the correct extra.
"""

# FTP uses only stdlib — always available
from entr_adapter_core.connectors.ftp import FTPConnector, FTPConnectorConfig

# SFTP requires the [sftp] extra (paramiko)
try:
    from entr_adapter_core.connectors.sftp import SFTPConnector, SFTPConnectorConfig
except ImportError:
    SFTPConnector = None  # type: ignore[assignment,misc]
    SFTPConnectorConfig = None  # type: ignore[assignment,misc]

# Gmail requires the [gmail] extra (httpx)
try:
    from entr_adapter_core.connectors.gmail import (
        EntrMailboxRetrievalHandler,
        GmailConnectorConfig,
    )
except ImportError:
    EntrMailboxRetrievalHandler = None  # type: ignore[assignment,misc]
    GmailConnectorConfig = None  # type: ignore[assignment,misc]

# Microsoft requires the [microsoft] extra (httpx)
try:
    from entr_adapter_core.connectors.microsoft import (
        MicrosoftEntraRetrievalHandler,
        MicrosoftConnectorConfig,
    )
except ImportError:
    MicrosoftEntraRetrievalHandler = None  # type: ignore[assignment,misc]
    MicrosoftConnectorConfig = None  # type: ignore[assignment,misc]

__all__ = [
    "FTPConnector",
    "FTPConnectorConfig",
    "SFTPConnector",
    "SFTPConnectorConfig",
    "EntrMailboxRetrievalHandler",
    "GmailConnectorConfig",
    "MicrosoftEntraRetrievalHandler",
    "MicrosoftConnectorConfig",
]
