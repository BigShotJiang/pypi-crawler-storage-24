# readseurat

Read Seurat `.rds` and `.h5seurat` files into [AnnData](https://anndata.readthedocs.io/) — implemented in pure Python, no R required.

The code for rds parsing is based on the `rdata` package (https://github.com/vnmabus/rdata).

## Installation

```bash
pip install readseurat
```

## Python API

```python
import readseurat

# Read an RDS file containing a Seurat object
adata = readseurat.read_seurat("pbmc3k.rds")

# Read an H5Seurat file
adata = readseurat.read_h5seurat("pbmc3k.h5seurat")
```

## Commandline

Convert a Seurat file to H5AD format:

```bash
# From RDS
readseurat convert pbmc3k.rds pbmc3k.h5ad

# From H5Seurat
readseurat convert pbmc3k.h5seurat pbmc3k.h5ad
```

```
Usage: readseurat convert [OPTIONS] INPUT OUTPUT

  Convert a Seurat file (RDS or H5Seurat) to H5AD format.

Options:
  --format [rds|h5seurat]  Input file format. Inferred from file extension if
                           not specified.
  -h, --help               Show this message and exit.
```

## Citation

`rdata` package:

> Ramos-Carreño, C., & Rossi, T. (2024). rdata: A Python library for R datasets. Journal of Open Source Software, 9(104), 1–4. https://doi.org/10.21105/joss.07540
