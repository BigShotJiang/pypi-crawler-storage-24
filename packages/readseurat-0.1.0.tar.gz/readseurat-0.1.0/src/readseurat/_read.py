import typing

from readseurat.convert.h5seurat import parse_h5seurat_to_seurat_object
from readseurat.convert.seurat import convert_to_anndata, parse_rds_to_seurat_object

if typing.TYPE_CHECKING:
    from anndata import AnnData


def read_seurat(file: str) -> "AnnData":
    """Read an RDS file containing a Seurat object.

    Args:
        file: Path to the RDS file.

    Returns:
        AnnData: Parsed AnnData object.

    Examples:
        >>> import readseurat
        >>> adata = readseurat.read_seurat("pbmc3k.rds")
        >>> print(adata)
    """
    seurat_object = parse_rds_to_seurat_object(file)
    return convert_to_anndata(seurat_object)


def read_h5seurat(file: str) -> "AnnData":
    """Read an H5Seurat file containing a Seurat object.

    Args:
        file: Path to the H5Seurat file.

    Returns:
        AnnData: Parsed AnnData object.

    Examples:
        >>> import readseurat
        >>> adata = readseurat.read_h5seurat("pbmc3k.h5seurat")
        >>> print(adata)
    """
    seurat_object = parse_h5seurat_to_seurat_object(file)
    return convert_to_anndata(seurat_object)
