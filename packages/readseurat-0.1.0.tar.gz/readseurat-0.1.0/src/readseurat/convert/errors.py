class ReadSeuratError(Exception):
    """Base exception for readseurat errors."""


class ReadSeuratFormatError(ReadSeuratError):
    """Raised when a Seurat file does not match the expected format."""


class SeuratError(ReadSeuratError):
    """Base exception for Seurat parsing errors."""


class SeuratFormatError(ReadSeuratFormatError):
    """Raised when a Seurat file does not match the expected format."""


class H5SeuratError(ReadSeuratError):
    """Base exception for h5seurat parsing errors."""


class H5SeuratFormatError(ReadSeuratFormatError):
    """Raised when an h5Seurat file does not match the expected format."""


class MissingNodeError(ReadSeuratFormatError):
    """Raised when a required dataset/group/attribute is missing."""


class TypeMismatchError(ReadSeuratFormatError):
    """Raised when a dataset/group has an unexpected type or shape."""
