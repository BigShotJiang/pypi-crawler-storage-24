"""Constants used throughout the h5seurat conversion module."""

# Logical value encoding for R compatibility
LOGICAL_FALSE = 0
LOGICAL_TRUE = 1
LOGICAL_NA = 2

# Default HDF5 compression settings
DEFAULT_COMPRESSION = "gzip"
DEFAULT_COMPRESSION_LEVEL = 4

# R factor encoding
R_FACTOR_BASE_INDEX = 1  # R uses 1-based indexing
R_FACTOR_NA_VALUE = 0  # Missing values in R factors are encoded as 0
