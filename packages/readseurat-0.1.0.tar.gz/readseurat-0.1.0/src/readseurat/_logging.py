import logging

#: Package-wide logger for readseurat.
#:
#: By default, a NullHandler is attached (per library best-practice) and the
#: level is set to WARNING.  Callers can customise the level or add handlers:
#:
#:     import readseurat
#:     readseurat.logger.setLevel("DEBUG")
#:     readseurat.logger.addHandler(logging.StreamHandler())
logger: logging.Logger = logging.getLogger("readseurat")
logger.addHandler(logging.NullHandler())
logger.setLevel(logging.WARNING)
