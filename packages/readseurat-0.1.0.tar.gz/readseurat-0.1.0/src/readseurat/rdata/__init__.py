"""rdata: Read R datasets from Python."""

from __future__ import annotations

from . import conversion as conversion
from . import parser as parser
from ._read import read_rds as read_rds
