"""Utilities for parsing a rdata file."""

from ._parser import (
    DEFAULT_ALTREP_MAP as DEFAULT_ALTREP_MAP,
)
from ._parser import (
    CharFlags as CharFlags,
)
from ._parser import (
    RData as RData,
)
from ._parser import (
    RExtraInfo as RExtraInfo,
)
from ._parser import (
    RObject as RObject,
)
from ._parser import (
    RObjectInfo as RObjectInfo,
)
from ._parser import (
    RObjectType as RObjectType,
)
from ._parser import (
    RVersions as RVersions,
)
from ._parser import (
    parse_data as parse_data,
)
from ._parser import (
    parse_file as parse_file,
)
