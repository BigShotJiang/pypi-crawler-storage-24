# PepC-Global Genesis

A Python package for predicting tropical cyclone genesis using trained Support Vector Classification (SVC) models.

## Installation

```bash
pip install pepc-global-genesis
```

Or from source:

```bash
git clone https://github.com/CongGao-CG/pepc-global-genesis.git
cd pepc-global-genesis
pip install .
```

## Quick Start

```python
import numpy as np
from pepc_global_genesis import predict_genesis

# Create predictor arrays (all must have the same shape)
# Shape can be (lat, lon) or (time, lat, lon), etc.
av850 = np.random.rand(72, 144) * 1e-4  # Absolute vorticity at 850 hPa (s^-1)
shr = np.random.rand(72, 144) * 20      # Wind shear 200-850 hPa (m/s)
rh600 = np.random.rand(72, 144) * 50 + 30  # Relative humidity at 600 hPa (%)
pi = np.random.rand(72, 144) * 20 + 50     # Potential intensity (m/s)

# Predict genesis for a specific basin
basin = 'NA'  # North Atlantic
genesis_flag = predict_genesis(av850, shr, rh600, pi, basin=basin)

# genesis_flag is a numpy array of 0s and 1s with the same shape as inputs
print(f"Predicted genesis: {np.sum(genesis_flag)} grid points")
```

## Available Basins

| Basin Code | Name                  | Latitude Range | Longitude Range   |
|------------|-----------------------|----------------|-------------------|
| `AS`       | Arabian Sea           | 5°N-22.5°N     | 50°E-77.5°E       |
| `BoB`      | Bay of Bengal         | 5°N-22.5°N     | 80°E-100°E        |
| `WNP`      | Western North Pacific | 5°N-30°N       | 102.5°E-180°E     |
| `ENP`      | Eastern North Pacific | 5°N-25°N       | 182.5°E-285°E     |
| `NA`       | North Atlantic        | 5°N-30°N       | 262.5°E-357.5°E   |
| `SI`       | South Indian          | 30°S-5°S       | 20°E-145°E        |
| `SP`       | South Pacific         | 30°S-5°S       | 147.5°E-260°E     |

## API Reference

### `predict_genesis(av850, shr, rh600, pi, basin)`

Predict tropical cyclone genesis.

**Parameters:**
- `av850` (np.ndarray): Absolute vorticity at 850 hPa (s^-1)
- `shr` (np.ndarray): Vertical wind shear between 200-850 hPa (m/s)
- `rh600` (np.ndarray): Relative humidity at 600 hPa (%)
- `pi` (np.ndarray): Potential intensity (m/s)
- `basin` (str): Basin name (one of: 'AS', 'BoB', 'WNP', 'ENP', 'NA', 'SI', 'SP')

**Returns:**
- `np.ndarray`: Binary mask (0 or 1) indicating predicted genesis, same shape as inputs

**Raises:**
- `ValueError`: If basin is invalid or input array shapes don't match

### `get_basin_names()`

Get the list of valid basin names.

**Returns:**
- `list[str]`: List of 7 basin names

### `BASINS`

List of valid basin names.

## Input Variables

| Variable | Description                          | Typical Units |
|----------|--------------------------------------|---------------|
| av850    | Absolute vorticity at 850 hPa        | s^-1          |
| shr      | Vertical wind shear (between 200 hPa and 850 hPa) | m/s           |
| rh600    | Relative humidity at 600 hPa         | %             |
| pi       | Upper limit of tropical cyclone intensity | m/s           |

## Model Details

This package contains pre-trained SVC models for 7 tropical cyclone basins. The models were trained on ERA5 monthly data using four environmental predictors known to influence tropical cyclone genesis:

1. **Absolute vorticity (av850)**: Measures rotation in the lower-level atmosphere
2. **Wind shear (shr)**: Vector difference between upper-level and lower-level winds
3. **Relative humidity (rh600)**: Mid-level moisture
4. **Potential intensity (pi)**: Upper limit of tropical cyclone intensity

Each basin has its own trained model and scaling parameters stored within the package.

## License

MIT License

## Citation

If you use this package in your research, please cite:

Gao, Cong, Ning Lin. "PepC-Global: A Basin-Tuned Probabilistic Tropical Cyclone Model with Enhanced Out-of-Sample Skill and Climate-Sensitive Over-Land Decay". Journal of Advances in Modeling Earth Systems (JAMES), under review.
