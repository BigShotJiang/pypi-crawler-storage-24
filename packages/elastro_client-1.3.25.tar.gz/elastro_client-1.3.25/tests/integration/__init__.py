"""Integration tests for the elastro module."""
