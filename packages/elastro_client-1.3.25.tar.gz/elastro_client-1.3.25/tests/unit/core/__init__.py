"""Core unit tests for elastro."""
