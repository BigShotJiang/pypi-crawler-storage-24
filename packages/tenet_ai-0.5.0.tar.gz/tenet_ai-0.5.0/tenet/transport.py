"""
BackgroundTransport — non-blocking HTTP write queue for the Ghost SDK.

Pushes JSON payloads onto a thread-safe queue and drains them via a single
daemon worker thread.  All exceptions are caught and silently logged so the
host process is never impacted.
"""

import logging
import queue
import threading
from datetime import datetime, timezone
from typing import Callable, Optional

import httpx

logger = logging.getLogger("tenet.transport")

_SENTINEL = object()  # signals the worker to stop


class BackgroundTransport:
    """Fire-and-forget HTTP transport backed by a daemon thread."""

    def __init__(
        self,
        endpoint: str,
        headers_fn: Callable[[], dict],
        timeout: float = 30.0,
        max_queue_size: int = 10_000,
        max_retries: int = 3,
        on_error: Optional[Callable[[Exception, dict], None]] = None,
    ):
        self._endpoint = endpoint.rstrip("/")
        self._headers_fn = headers_fn
        self._timeout = timeout
        self._max_retries = max_retries
        self._on_error = on_error
        self._queue: queue.Queue = queue.Queue(maxsize=max_queue_size)
        self._client = httpx.Client(timeout=timeout)
        self._started = False
        self._lock = threading.Lock()
        self._worker: Optional[threading.Thread] = None

        # Capture stats — thread-safe via atomic int ops on CPython
        self._sent: int = 0
        self._failed: int = 0
        self._dropped: int = 0
        self._last_success_at: Optional[datetime] = None
        self._stats_lock = threading.Lock()

    def get_stats(self) -> dict:
        """Return a snapshot of capture counters. Thread-safe."""
        with self._stats_lock:
            return {
                "sent": self._sent,
                "failed": self._failed,
                "dropped": self._dropped,
                "last_success_at": self._last_success_at.isoformat() if self._last_success_at else None,
            }

    # ── public API ───────────────────────────────────────────

    def enqueue(self, method: str, path: str, data: dict) -> None:
        """Add an HTTP request to the queue (~1-5 us, non-blocking)."""
        self._ensure_started()
        item = {"method": method, "path": path, "data": data, "attempts": 0}
        try:
            self._queue.put_nowait(item)
        except queue.Full:
            with self._stats_lock:
                self._dropped += 1
            logger.warning(
                "tenet: capture DROPPED — write queue full (path=%s). "
                "Total dropped so far: %d. Check that the backend is reachable.",
                path, self._dropped,
            )

    def flush(self, timeout: float = 10.0) -> None:
        """Block until every queued item has been sent (or *timeout* seconds)."""
        self._ensure_started()
        self._queue.join()  # waits for all task_done() calls

    def shutdown(self, timeout: float = 5.0) -> None:
        """Flush remaining items then stop the worker thread."""
        if not self._started:
            return
        try:
            self._queue.put(_SENTINEL, timeout=timeout)
        except queue.Full:
            pass
        if self._worker and self._worker.is_alive():
            self._worker.join(timeout=timeout)
        try:
            self._client.close()
        except Exception:
            pass

    # ── internals ────────────────────────────────────────────

    def _ensure_started(self) -> None:
        if self._started:
            return
        with self._lock:
            if self._started:
                return
            self._worker = threading.Thread(target=self._run, daemon=True)
            self._worker.start()
            self._started = True

    def _run(self) -> None:
        """Worker loop — drains queue until sentinel is received."""
        while True:
            item = self._queue.get()
            if item is _SENTINEL:
                self._queue.task_done()
                break
            try:
                self._send(item)
            except Exception as exc:
                item["attempts"] += 1
                if item["attempts"] < self._max_retries:
                    # Re-enqueue for retry
                    try:
                        self._queue.put_nowait(item)
                    except queue.Full:
                        self._report_error(exc, item)
                else:
                    self._report_error(exc, item)
            finally:
                self._queue.task_done()

    def _send(self, item: dict) -> None:
        url = f"{self._endpoint}/api/v1{item['path']}"
        headers = self._headers_fn()
        if item["method"] == "POST":
            resp = self._client.post(url, json=item["data"], headers=headers)
            resp.raise_for_status()
        with self._stats_lock:
            self._sent += 1
            self._last_success_at = datetime.now(timezone.utc)

    def _report_error(self, exc: Exception, item: dict) -> None:
        with self._stats_lock:
            self._failed += 1
        logger.warning(
            "tenet: capture FAILED for %s after %d attempt(s): %s — "
            "this execution will NOT appear in the Tenet dashboard.",
            item.get("path"), item.get("attempts", 0) + 1, exc,
        )
        if self._on_error:
            try:
                self._on_error(exc, item)
            except Exception:
                pass
