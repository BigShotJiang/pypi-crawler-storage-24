# flake8: noqa

# import all models into this package
# if you have many models here with many references from one model to another this may
# raise a RecursionError
# to avoid this, import only the models that you directly need like:
# from from eis.task.model.pet import Pet
# or import this package, but before doing it, use:
# import sys
# sys.setrecursionlimit(n)

from eis.task.model.assignee_class import AssigneeClass
from eis.task.model.category_class import CategoryClass
from eis.task.model.create_category_request_dto import CreateCategoryRequestDto
from eis.task.model.create_category_response_class import CreateCategoryResponseClass
from eis.task.model.create_hub_spot_ticket_request_dto import CreateHubSpotTicketRequestDto
from eis.task.model.create_hub_spot_ticket_response_class import CreateHubSpotTicketResponseClass
from eis.task.model.create_status_request_dto import CreateStatusRequestDto
from eis.task.model.create_status_response_class import CreateStatusResponseClass
from eis.task.model.create_task_request_dto import CreateTaskRequestDto
from eis.task.model.create_task_response_class import CreateTaskResponseClass
from eis.task.model.get_category_response_class import GetCategoryResponseClass
from eis.task.model.get_status_response_class import GetStatusResponseClass
from eis.task.model.get_task_response_class import GetTaskResponseClass
from eis.task.model.hub_spot_ticket_class import HubSpotTicketClass
from eis.task.model.hub_spot_ticket_error_class import HubSpotTicketErrorClass
from eis.task.model.hub_spot_ticket_name_value_dto import HubSpotTicketNameValueDto
from eis.task.model.inline_response200 import InlineResponse200
from eis.task.model.inline_response503 import InlineResponse503
from eis.task.model.list_assignees_response_class import ListAssigneesResponseClass
from eis.task.model.list_categories_response_class import ListCategoriesResponseClass
from eis.task.model.list_statuses_response_class import ListStatusesResponseClass
from eis.task.model.list_tasks_response_class import ListTasksResponseClass
from eis.task.model.patch_category_request_dto import PatchCategoryRequestDto
from eis.task.model.patch_category_response_class import PatchCategoryResponseClass
from eis.task.model.patch_status_request_dto import PatchStatusRequestDto
from eis.task.model.patch_status_response_class import PatchStatusResponseClass
from eis.task.model.patch_task_request_dto import PatchTaskRequestDto
from eis.task.model.patch_task_response_class import PatchTaskResponseClass
from eis.task.model.status_class import StatusClass
from eis.task.model.task_class import TaskClass
