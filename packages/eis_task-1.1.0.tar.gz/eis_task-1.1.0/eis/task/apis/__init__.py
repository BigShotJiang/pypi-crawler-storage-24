
# flake8: noqa

# Import all APIs into this package.
# If you have many APIs here with many many models used in each API this may
# raise a `RecursionError`.
# In order to avoid this, import only the API that you directly need like:
#
#   from eis.task.api.assignees_api import AssigneesApi
#
# or import this package, but before doing it, use:
#
#   import sys
#   sys.setrecursionlimit(n)

# Import APIs into API package:
from eis.task.api.assignees_api import AssigneesApi
from eis.task.api.categories_api import CategoriesApi
from eis.task.api.hub_spot_api import HubSpotApi
from eis.task.api.statuses_api import StatusesApi
from eis.task.api.tasks_api import TasksApi
from eis.task.api.default_api import DefaultApi
