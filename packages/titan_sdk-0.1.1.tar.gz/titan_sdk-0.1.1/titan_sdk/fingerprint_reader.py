"""
FingerprintReader — wraps the bundled libfprint binaries to continuously
capture fingerprint images and write them as fingerprint.pgm.

Supported platforms
-------------------
- arm64-apple   : macOS Apple Silicon (Darwin / arm64)
- aarch64-linux : Linux ARM64         (Linux  / aarch64)
"""

from __future__ import annotations

import platform
import subprocess
import threading
import time
from pathlib import Path
from typing import Callable, Optional

from PIL import Image


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class UnsupportedArchitectureError(Exception):
    """Raised when the current platform has no compatible libfprint binary."""


# ---------------------------------------------------------------------------
# FingerprintReader
# ---------------------------------------------------------------------------

class FingerprintReader:
    """
    Launches and manages the bundled libfprint binary to capture fingerprints
    in a continuous loop, writing each result to ``fingerprint.pgm``.

    Basic usage::

        reader = FingerprintReader(output_dir="/tmp/fp")
        reader.start()
        # ... later ...
        reader.stop()

    Context-manager usage::

        with FingerprintReader(on_capture=lambda p: print(f"new scan: {p}")) as reader:
            time.sleep(30)

    Crash recovery
    --------------
    If the binary exits unexpectedly the monitor thread automatically restarts
    it using **exponential backoff** (``retry_base_delay`` × 2^attempt, capped
    at ``max_retry_delay``).  The backoff counter resets after each successful
    capture, so a stable reader is never penalised.  When ``max_retries`` is
    reached the reader stops itself and the optional ``on_crash`` callback is
    invoked one final time with ``exit_code=-1`` to signal exhaustion.

    Parameters
    ----------
    output_dir:
        Directory where ``fingerprint.pgm`` will be written on every capture.
        Defaults to the current working directory.
    on_capture:
        Optional callback invoked with the absolute path to ``fingerprint.pgm``
        each time the binary reports a successful capture.
    on_crash:
        Optional callback invoked on every unexpected binary exit.
        Signature: ``on_crash(exit_code: int, attempt: int) -> None``.
        ``exit_code`` is the process return code; ``attempt`` is the 1-based
        restart attempt number.  When retries are exhausted ``exit_code`` is
        ``-1`` and ``attempt`` equals ``max_retries``.
    max_retries:
        Maximum number of restart attempts before giving up.
        ``-1`` (default) means unlimited restarts.
    retry_base_delay:
        Initial wait (seconds) before the first restart.  Doubles on each
        consecutive crash.  Default: ``1.0``.
    max_retry_delay:
        Upper bound (seconds) for the exponential backoff delay.
        Default: ``30.0``.
    """

    # Map (platform.system(), platform.machine()) → binary sub-directory name
    _ARCH_MAP: dict[tuple[str, str], str] = {
        ("Darwin", "arm64"):    "arm64-apple",
        ("Linux",  "aarch64"): "aarch64-linux",
    }

    def __init__(
        self,
        output_dir: Optional[str] = None,
        on_capture: Optional[Callable[[str], None]] = None,
        on_crash: Optional[Callable[[int, int], None]] = None,
        max_retries: int = -1,
        retry_base_delay: float = 1.0,
        max_retry_delay: float = 30.0,
    ) -> None:
        self._binary_path: Path = self._resolve_binary()
        self._output_dir: Path = Path(output_dir) if output_dir else Path.cwd()
        self._output_dir.mkdir(parents=True, exist_ok=True)

        self._on_capture = on_capture
        self._on_crash = on_crash
        self._max_retries = max_retries
        self._retry_base_delay = retry_base_delay
        self._max_retry_delay = max_retry_delay

        self._process: Optional[subprocess.Popen] = None
        self._monitor_thread: Optional[threading.Thread] = None
        self._running: bool = False

        # Crash-recovery state (reset on each start())
        self._crash_count: int = 0
        self._restart_lock = threading.Lock()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    @property
    def pgm_path(self) -> Path:
        """Absolute path to ``fingerprint.pgm`` in the configured output directory."""
        return self._output_dir / "fingerprint.pgm"

    @property
    def png_path(self) -> Path:
        """Absolute path to ``fingerprint.png`` in the configured output directory."""
        return self._output_dir / "fingerprint.png"

    @property
    def is_running(self) -> bool:
        """``True`` while the reader is active."""
        return self._running

    @property
    def crash_count(self) -> int:
        """Number of unexpected binary crashes since the last ``start()`` call."""
        return self._crash_count

    @classmethod
    def is_supported(cls) -> bool:
        """Return ``True`` if the current platform can run the bundled binary."""
        key = (platform.system(), platform.machine())
        return key in cls._ARCH_MAP

    def start(self) -> None:
        """
        Start the fingerprint reader.

        Launches the libfprint binary in the background and begins monitoring
        its output.  Calling ``start()`` on an already-running reader is a
        no-op.

        Raises
        ------
        UnsupportedArchitectureError
            If the current platform is not arm64-apple or aarch64-linux.
        FileNotFoundError
            If the expected binary is missing from the installed package.
        """
        if self._running:
            return

        self._running = True
        self._crash_count = 0  # reset on every fresh start

        self._launch_process()

        self._monitor_thread = threading.Thread(
            target=self._monitor_loop,
            daemon=True,
            name="fingerprint-monitor",
        )
        self._monitor_thread.start()

    def stop(self) -> None:
        """
        Stop the fingerprint reader and terminate the underlying process.

        Safe to call even if the reader was never started.
        """
        self._running = False

        if self._process is not None and self._process.poll() is None:
            self._process.terminate()
            try:
                self._process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self._process.kill()

        self._process = None

    # Context-manager support -------------------------------------------

    def __enter__(self) -> "FingerprintReader":
        self.start()
        return self

    def __exit__(self, *_) -> None:
        self.stop()

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    @classmethod
    def _resolve_binary(cls) -> Path:
        """
        Locate and return the path to the correct ``reader`` binary for this
        platform, making sure it has execute permission.

        Raises
        ------
        UnsupportedArchitectureError
            Current OS / CPU architecture combination is not supported.
        FileNotFoundError
            Binary file is absent (corrupt or incomplete installation).
        """
        system  = platform.system()   # e.g. 'Darwin', 'Linux'
        machine = platform.machine()  # e.g. 'arm64', 'aarch64'
        key     = (system, machine)

        arch_dir = cls._ARCH_MAP.get(key)
        if arch_dir is None:
            supported = ", ".join(
                f"{m} ({s})" for (s, m), _ in cls._ARCH_MAP.items()
            )
            raise UnsupportedArchitectureError(
                f"Platform '{system}/{machine}' is not supported by the bundled "
                f"libfprint binaries.  Supported platforms: {supported}."
            )

        binary = Path(__file__).parent / "libfprint" / arch_dir / "reader"

        if not binary.exists():
            raise FileNotFoundError(
                f"libfprint binary not found at '{binary}'.  "
                "The package may be missing its native components."
            )

        # Ensure the binary is executable (handles installs that strip permissions)
        binary.chmod(binary.stat().st_mode | 0o111)
        return binary

    def _convert_to_png(self) -> Path:
        """
        Convert the latest ``fingerprint.pgm`` to ``fingerprint.png``.

        Returns the path to the PNG file.

        Raises
        ------
        FileNotFoundError
            If ``fingerprint.pgm`` does not exist yet.
        OSError
            If the conversion fails for any I/O reason.
        """
        Image.open(self.pgm_path).save(self.png_path, format="PNG")
        return self.png_path

    def _launch_process(self) -> None:
        """Spawn a new reader subprocess."""
        self._process = subprocess.Popen(
            [str(self._binary_path)],
            cwd=str(self._output_dir),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
        )

    def _monitor_loop(self) -> None:
        """
        Read stdout lines from the binary and handle crash recovery.

        Normal flow
        -----------
        - Each ``"Fingerprint captured"`` line triggers the ``on_capture``
          callback and resets the backoff counter.

        Crash recovery flow
        -------------------
        On unexpected exit (EOF on stdout):

        1. Collect the process exit code.
        2. Increment the crash counter and fire ``on_crash(exit_code, attempt)``.
        3. Compute the next backoff delay:
               delay = min(base * 2^(attempt-1), max_delay)
        4. Sleep for that delay, then restart the binary.
        5. If ``max_retries`` is reached, fire ``on_crash(-1, attempt)`` to
           signal exhaustion and stop the reader.
        """
        consecutive_crashes: int = 0  # resets after a successful capture

        while self._running:
            if self._process is None:
                break

            raw = self._process.stdout.readline()  # type: ignore

            if not raw:
                # ── EOF: the binary exited ────────────────────────────────
                if not self._running:
                    break  # intentional stop() call — do not restart

                with self._restart_lock:
                    exit_code = self._process.returncode if self._process else 1
                    self._crash_count += 1
                    consecutive_crashes += 1
                    attempt = self._crash_count

                    # Notify caller about the crash
                    if self._on_crash is not None:
                        try:
                            self._on_crash(exit_code, attempt)
                        except Exception:
                            pass

                    # Check if retries are exhausted
                    if self._max_retries != -1 and attempt >= self._max_retries:
                        # Signal exhaustion with a sentinel exit_code of -1
                        if self._on_crash is not None:
                            try:
                                self._on_crash(-1, attempt)
                            except Exception:
                                pass
                        self._running = False
                        break

                    # Exponential backoff: base * 2^(consecutive_crashes - 1)
                    delay = min(
                        self._retry_base_delay * (2 ** (consecutive_crashes - 1)),
                        self._max_retry_delay,
                    )
                    time.sleep(delay)

                    if self._running:
                        self._launch_process()

                continue

            # ── Normal stdout line ────────────────────────────────────────
            line = raw.decode(errors="replace").strip()

            if "Fingerprint captured" in line:
                # Successful capture — reset consecutive crash counter
                consecutive_crashes = 0

                try:
                    png = self._convert_to_png()
                except Exception:
                    continue  # conversion failed; skip this frame

                if self._on_capture is not None:
                    try:
                        self._on_capture(str(png))
                    except Exception:
                        pass  # Never let a user callback crash the monitor thread
