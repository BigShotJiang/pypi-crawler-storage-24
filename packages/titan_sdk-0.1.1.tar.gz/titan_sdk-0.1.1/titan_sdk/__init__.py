"""
Titan SDK — Python client for the Titan API.

    from titan_sdk import TitanClient
"""

from .client import TitanClient
from .exceptions import (
    AuthenticationError,
    DeviceNotFoundError,
    NoModeError,
    TenantAccessError,
    TitanSDKError,
    UploadError,
)
from .fingerprint_reader import FingerprintReader, UnsupportedArchitectureError

__all__ = [
    "TitanClient",
    "TitanSDKError",
    "AuthenticationError",
    "TenantAccessError",
    "UploadError",
    "DeviceNotFoundError",
    "NoModeError",
    "FingerprintReader",
    "UnsupportedArchitectureError",
]

__version__ = "0.1.0"
