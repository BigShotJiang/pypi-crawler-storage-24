"""
Device identity management.

Persists the three fields that identify this device to the Titan backend:

    system_id       — stable UUID used for WebSocket auth and every upload
    device_local_id — hardware-level UUID sent in check-in payloads
    device_id       — server-assigned numeric ID returned after registration

Storage location: ~/.titan-sdk/device.json

On first run the file does not exist, so fresh UUIDs are generated and
device_id is left None until the client registers with the server and calls
save().  On every subsequent run the stored values are reloaded and
registration is skipped entirely.
"""

from __future__ import annotations

import json
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Optional


DEVICE_TYPES = ("camera_qr", "camera_face_recognition", "fingerprint_reader")

_STORE_PATH = Path.home() / ".titan-sdk" / "device.json"


@dataclass
class DeviceIdentity:
    system_id: str        # sent on every WS connection and upload
    device_local_id: str  # hardware-level local identifier
    device_name: str      # human-readable name registered on the server
    device_type: str      # one of DEVICE_TYPES
    device_id: Optional[int] = None  # server-assigned numeric ID; None until registered


def load_or_create(device_name: str, device_type: str) -> DeviceIdentity:
    """
    Return the stored device identity, or create and persist a new one.

    If ``~/.titan-sdk/device.json`` exists its ``system_id``,
    ``device_local_id``, and ``device_id`` are reused so the device is not
    re-registered on every startup.

    If the file is absent (first run, or deliberately deleted to force
    re-registration) fresh UUIDs are generated and ``device_id`` is set to
    ``None`` — the caller is responsible for registering and then calling
    :func:`save`.

    Raises
    ------
    ValueError
        If ``device_type`` is not one of the recognised device types.
    """
    if device_type not in DEVICE_TYPES:
        raise ValueError(
            f"Invalid device_type '{device_type}'. Must be one of: {DEVICE_TYPES}"
        )

    if _STORE_PATH.exists():
        return _load(device_name, device_type)

    return _create(device_name, device_type)


def save(identity: DeviceIdentity) -> None:
    """Persist system_id, device_local_id, and device_id to disk."""
    _STORE_PATH.parent.mkdir(parents=True, exist_ok=True)
    with _STORE_PATH.open("w") as f:
        json.dump(asdict(identity), f, indent=2)


def delete_store() -> None:
    """Delete the stored identity file, forcing re-registration on next startup."""
    if _STORE_PATH.exists():
        _STORE_PATH.unlink()


def _load(device_name: str, device_type: str) -> DeviceIdentity:
    """Read the stored file and return a DeviceIdentity."""
    with _STORE_PATH.open() as f:
        data = json.load(f)
    return DeviceIdentity(
        system_id=data["system_id"],
        device_local_id=data["device_local_id"],
        device_name=device_name,    # always taken from caller (may have changed)
        device_type=device_type,    # always taken from caller (may have changed)
        device_id=data.get("device_id"),
    )


def _create(device_name: str, device_type: str) -> DeviceIdentity:
    """Generate a fresh identity. Does NOT save — caller must call save()."""
    return DeviceIdentity(
        system_id=str(uuid.uuid4()),
        device_local_id=str(uuid.uuid4()),
        device_name=device_name,
        device_type=device_type,
        device_id=None,
    )
