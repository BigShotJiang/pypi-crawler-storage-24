# titan-python-sdk

## Command for updating pip



## Command to compile libfprint binaries

```bash
gcc reader.c -o reader $(pkg-config --cflags --libs libfprint-2 gio-2.0 glib-2.0)
```


## Binaries from Mac are build from a custom Fork
https://github.com/MenesesGHZ/libfprint