from setuptools import setup, find_packages

setup(
    name="titan-sdk",
    version="0.1.1",
    description="Python SDK for the Titan API",
    packages=find_packages(),
    package_data={
        "titan_sdk": [
            "libfprint/arm64-apple/reader",
            "libfprint/aarch64-linux/reader",
        ],
    },
    python_requires=">=3.10",
    install_requires=[
        "requests>=2.31.0",
        "websocket-client>=1.7.0",
        "Pillow>=9.0.0",
    ],
)
