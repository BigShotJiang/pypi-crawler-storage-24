"""Inscript hook — records agent activity to ~/.inscript/.

Handles four Claude Code hook events:
  SessionStart    → creates session directory + meta.json
  UserPromptSubmit → records the user's prompt, starts a new work block
  PostToolUse     → appends to touches.jsonl + diffs.jsonl, tags with prompt
  Stop            → finalizes summary.json

All entry points read JSON from stdin and write to the filesystem.
Designed to run async (non-blocking) so the agent never waits.

Install:
    pip install inscript
    # Then add hooks to ~/.claude/settings.json (see README)
"""
from __future__ import annotations

import hashlib
import json
import re
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

from . import (
    INSCRIPT_DIR,
    ACTIVE_PROJECT_FILE,
    ACTIVE_SESSION_FILE,
    SESSIONS_DIR,
    OVERLAP_DIR,
    active_session,
    active_sessions,
    project_hash,
    store_diffs,
)


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")


def _now_time() -> str:
    return datetime.now(timezone.utc).strftime("%H:%M:%S")


def _extract_path(data: dict) -> str | None:
    """Extract a file path from hook input JSON."""
    inp = data.get("tool_input", {})

    path = inp.get("file_path") or inp.get("path")
    if path and path.startswith("/"):
        return path

    command = inp.get("command", "")
    if command:
        matches = re.findall(r"(/[^\s;|&\"']+)", command)
        if matches:
            return matches[0]

    return None


def _find_git_root(path: str) -> Path | None:
    """Walk up from path to find the git root."""
    p = Path(path)
    if p.is_file():
        p = p.parent
    while p != p.parent:
        if (p / ".git").exists():
            return p
        p = p.parent
    return None


def _tool_action(tool_name: str) -> str:
    """Map tool name to action verb."""
    return {
        "Read": "read",
        "Edit": "edit",
        "Write": "write",
        "Glob": "glob",
        "Grep": "grep",
    }.get(tool_name, "touch")


def _append_jsonl(path: Path, data: dict) -> None:
    """Append a JSON line to a file."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a") as f:
        f.write(json.dumps(data, default=str) + "\n")


def _count_lines(path: Path) -> int:
    """Count lines in a JSONL file."""
    try:
        return sum(1 for _ in path.open())
    except OSError:
        return 0


def _current_prompt_idx(sdir: Path) -> int | None:
    """Get the index of the most recent prompt (0-based)."""
    n = _count_lines(sdir / "prompts.jsonl")
    return n - 1 if n > 0 else None


# ---------------------------------------------------------------------------
# SessionStart handler
# ---------------------------------------------------------------------------

def handle_session_start(data: dict) -> None:
    """Create a new session directory."""
    session_id = data.get("session_id", f"s-{int(time.time())}")

    sdir = SESSIONS_DIR / session_id
    sdir.mkdir(parents=True, exist_ok=True)

    # Read current project if available
    proj = None
    try:
        proj = ACTIVE_PROJECT_FILE.read_text().strip()
    except OSError:
        pass

    meta = {
        "start_time": _now_iso(),
        "project": proj,
        "status": "active",
    }
    (sdir / "meta.json").write_text(json.dumps(meta, indent=2))

    # Mark as active session
    INSCRIPT_DIR.mkdir(parents=True, exist_ok=True)
    ACTIVE_SESSION_FILE.write_text(session_id + "\n")


# ---------------------------------------------------------------------------
# UserPromptSubmit handler
# ---------------------------------------------------------------------------

def handle_prompt_submit(data: dict) -> None:
    """Record a user prompt, starting a new work block."""
    session_id = active_session()
    if not session_id:
        session_id = f"s-{int(time.time())}"
        handle_session_start({"session_id": session_id})

    sdir = SESSIONS_DIR / session_id

    # Extract prompt text from hook input
    # Claude Code sends tool_input with the user's message
    prompt = data.get("tool_input", {}).get("prompt", "")
    if not prompt:
        # Try alternate locations
        prompt = data.get("prompt", "") or data.get("message", "")
    if not prompt:
        return

    prompt_idx = _count_lines(sdir / "prompts.jsonl")

    _append_jsonl(sdir / "prompts.jsonl", {
        "idx": prompt_idx,
        "ts": _now_time(),
        "prompt": prompt,
    })


# ---------------------------------------------------------------------------
# PostToolUse handler
# ---------------------------------------------------------------------------

def handle_post_tool_use(data: dict) -> None:
    """Record a file touch, update active project, record diffs."""
    tool_name = data.get("tool_name", "")
    tool_input = data.get("tool_input", {})
    tool_response = data.get("tool_response", {})

    # Extract file path
    file_path = _extract_path(data)
    if not file_path:
        return

    # Update active project
    root = _find_git_root(file_path)
    if root:
        try:
            current = ACTIVE_PROJECT_FILE.read_text().strip()
            if current != str(root):
                INSCRIPT_DIR.mkdir(parents=True, exist_ok=True)
                ACTIVE_PROJECT_FILE.write_text(str(root) + "\n")
        except OSError:
            INSCRIPT_DIR.mkdir(parents=True, exist_ok=True)
            ACTIVE_PROJECT_FILE.write_text(str(root) + "\n")

    # Get or create session
    session_id = active_session()
    if not session_id:
        # No session yet — create one implicitly
        session_id = f"s-{int(time.time())}"
        handle_session_start({"session_id": session_id})

    sdir = SESSIONS_DIR / session_id

    # Update session meta with project if it changed
    if root:
        meta_file = sdir / "meta.json"
        if meta_file.exists():
            try:
                meta = json.loads(meta_file.read_text())
                if meta.get("project") != str(root):
                    meta["project"] = str(root)
                    meta_file.write_text(json.dumps(meta, indent=2))
            except (json.JSONDecodeError, OSError):
                pass

    # Relativize path for readability
    display_path = file_path
    if root and file_path.startswith(str(root)):
        display_path = file_path[len(str(root)) + 1:]

    # Append to touches.jsonl
    action = _tool_action(tool_name)
    prompt_idx = _current_prompt_idx(sdir)
    touch = {
        "ts": _now_time(),
        "file": display_path,
        "action": action,
        "tool": tool_name,
    }
    if prompt_idx is not None:
        touch["prompt_idx"] = prompt_idx

    # Add lines_changed for Edit
    if tool_name == "Edit" and tool_input.get("new_string") is not None:
        old = tool_input.get("old_string", "")
        new = tool_input.get("new_string", "")
        touch["lines_changed"] = abs(new.count("\n") - old.count("\n")) + 1

    # Add line count for Write
    if tool_name == "Write" and tool_input.get("content"):
        touch["lines"] = tool_input["content"].count("\n") + 1

    _append_jsonl(sdir / "touches.jsonl", touch)

    # Append to diffs.jsonl for Edit/Write
    if store_diffs() and tool_name in ("Edit", "Write"):
        diff_entry: dict = {
            "ts": _now_time(),
            "file": display_path,
            "tool": tool_name,
        }
        if prompt_idx is not None:
            diff_entry["prompt_idx"] = prompt_idx

        if tool_name == "Edit":
            diff_entry["old_string"] = tool_input.get("old_string", "")
            diff_entry["new_string"] = tool_input.get("new_string", "")
            if tool_input.get("replace_all"):
                diff_entry["replace_all"] = True

        elif tool_name == "Write":
            content = tool_input.get("content", "")
            diff_entry["content_hash"] = hashlib.sha256(content.encode()).hexdigest()[:16]
            diff_entry["lines"] = content.count("\n") + 1
            diff_entry["is_new"] = not Path(file_path).exists()

        _append_jsonl(sdir / "diffs.jsonl", diff_entry)

    # Check for overlap with other active sessions
    if root:
        _check_overlap(session_id, str(root), display_path)


def _check_overlap(current_session: str, project: str, file_path: str) -> None:
    """Check if other active sessions are touching the same project."""
    others = active_sessions()
    overlapping = [
        s["session_id"] for s in others
        if s["session_id"] != current_session and s.get("project") == project
    ]

    if not overlapping:
        return

    OVERLAP_DIR.mkdir(parents=True, exist_ok=True)
    ph = project_hash(project)
    _append_jsonl(OVERLAP_DIR / f"{ph}.jsonl", {
        "ts": _now_time(),
        "file": file_path,
        "project": project,
        "sessions": [current_session] + overlapping,
    })


# ---------------------------------------------------------------------------
# Stop handler
# ---------------------------------------------------------------------------

def handle_stop(data: dict) -> None:
    """Finalize the current session with a summary."""
    session_id = active_session()
    if not session_id:
        return

    sdir = SESSIONS_DIR / session_id
    touches_file = sdir / "touches.jsonl"

    files_read = set()
    files_written = set()
    total_edits = 0
    total_lines = 0

    if touches_file.exists():
        for line in touches_file.open():
            try:
                e = json.loads(line)
                f = e.get("file", "")
                action = e.get("action", "")
                if action == "read":
                    files_read.add(f)
                elif action in ("edit", "write"):
                    files_written.add(f)
                    total_edits += 1
                    total_lines += e.get("lines_changed", e.get("lines", 0))
            except json.JSONDecodeError:
                pass

    # Read start time from meta
    meta_file = sdir / "meta.json"
    start_time = None
    if meta_file.exists():
        try:
            meta = json.loads(meta_file.read_text())
            start_time = meta.get("start_time")
            meta["status"] = "completed"
            meta_file.write_text(json.dumps(meta, indent=2))
        except (json.JSONDecodeError, OSError):
            pass

    end_time = _now_iso()
    duration = None
    if start_time:
        try:
            start_dt = datetime.fromisoformat(start_time)
            end_dt = datetime.fromisoformat(end_time)
            duration = int((end_dt - start_dt).total_seconds())
        except ValueError:
            pass

    # Count prompts
    prompts_file = sdir / "prompts.jsonl"
    prompt_count = _count_lines(prompts_file)

    summary = {
        "end_time": end_time,
        "duration_seconds": duration,
        "prompts": prompt_count,
        "files_read": len(files_read),
        "files_written": len(files_written),
        "files_read_list": sorted(files_read),
        "files_written_list": sorted(files_written),
        "total_edits": total_edits,
        "total_lines_changed": total_lines,
    }

    (sdir / "summary.json").write_text(json.dumps(summary, indent=2))

    # Clear active session
    try:
        ACTIVE_SESSION_FILE.unlink()
    except OSError:
        pass


# ---------------------------------------------------------------------------
# Main dispatch — reads hook event from stdin JSON
# ---------------------------------------------------------------------------

def main() -> None:
    """Entry point for all hook events. Dispatches based on hook_event field
    or falls back to PostToolUse behavior for backwards compatibility."""
    try:
        data = json.load(sys.stdin)
    except (json.JSONDecodeError, EOFError):
        return

    # Claude Code hooks include session_id at top level
    hook_event = data.get("hook_event", "")

    if hook_event == "SessionStart":
        handle_session_start(data)
    elif hook_event == "UserPromptSubmit":
        handle_prompt_submit(data)
    elif hook_event == "Stop":
        handle_stop(data)
    else:
        # Default: PostToolUse (also handles backwards compat)
        handle_post_tool_use(data)


if __name__ == "__main__":
    main()
