"""
Mirdan: AI Code Quality Orchestrator

Automatically transforms developer prompts into high-quality,
structured requests that maximize AI coding assistant capabilities.
"""

__version__ = "1.6.1"
