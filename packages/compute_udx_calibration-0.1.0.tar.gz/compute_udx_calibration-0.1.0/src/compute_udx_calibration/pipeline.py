# Overall runner to orchestrate high level functions
from typing import Optional, Dict, Any
from compute_udx_calibration.transform import transform_sens_to_df
from compute_udx_calibration.compute_calibration import compute_calibration_table


def run_calibration_pipeline(
    data_path: str,
    output_path: Optional[str] = None,
    device: Optional[str] = None,
    date: Optional[str] = None,
    **kwargs
) -> Dict[str, Any]:
    """
    End-to-end calibration pipeline orchestrator.
    
    Loads raw sensor data, transforms it to a calibration dataframe, computes regression
    coefficients and calibration metrics, and stores the results.
    
    Args:
        data_path: Path to raw sensor calibration data file
        output_path: Path where calibration results will be stored (optional)
        device: Device identifier (optional)
        date: Calibration date (optional)
        **kwargs: Additional arguments passed to individual pipeline steps
    
    Returns:
        Dictionary containing:
        {
            "calibration_results": dict with regression metrics and data,
            "stored_path": str path where results were saved (if output_path provided),
            "success": bool indicating if pipeline completed successfully
        }
    """
    
    try:
        # Step 1: Load raw data

        
        # Step 2: Transform to calibration dataframe
        df = transform_sens_to_df(raw_data, **kwargs.get('transform_kwargs', {}))
        
        # Step 3: Compute calibration table
        calibration_results = compute_calibration_table(
            df,
            device=device,
            date=date,
            **kwargs.get('compute_kwargs', {})
        )
        
        # Step 4: Store results
        
        result = {
            'calibration_results': calibration_results,
            'stored_path': stored_path,
            'success': True
        }
        
        return result
        
    except Exception as e:
        print(f"Error in calibration pipeline: {str(e)}")
        return {
            'calibration_results': None,
            'stored_path': None,
            'success': False,
            'error': str(e)
        }
