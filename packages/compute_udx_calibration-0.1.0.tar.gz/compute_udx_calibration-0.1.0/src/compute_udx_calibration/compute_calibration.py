# All calibration logic - compute coefficients, assign formazin values, validate/flag bad calibrations etc.
import pandas as pd
import numpy as np
import json
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score, mean_squared_error
from typing import Dict, Tuple, Optional

DEFAULT_SENSOR_COLS = [
    "R-R", "G-R", "B-R", "IR-R", "R-G", "G-G", "B-G", "IR-G",
    "R-B", "G-B", "B-B", "IR-B", "R-IR", "G-IR", "B-IR", "IR-IR",
    "UVA-UVA", "UVB-UVA", "UVC-UVA", "UVA-UVB", "UVB-UVB", "UVC-UVB"
] #TODO: Eventually store these constants in a more central place. The flag-assignment package also references these values. 
FORMAZIN_MAP: Dict[str, object] = {
    1: 500,
    2: 250,
    3: 150,
    4: 50,
    5: 25,
    6: 10,
    7: 5,
    8: 0,
    9: "AIR"} #TODO: Go back and see if there are more and what was used in the past, or manually update the tables for now and use a standardized method moving forward?

def compute_calibration_table(df: pd.DataFrame, sensor_cols: list = DEFAULT_SENSOR_COLS) -> Dict:
    """
    Main orchestrator for computing calibration coefficients and organizing calibration data.
    
    Processes a calibration dataframe through the full pipeline:
    1. Identifies formazin samples and validates calibration data
    2. Separates air and formazin calibration data
    3. Fits linear regression for each channel
    4. Extracts and organizes raw data values
    
    Args:
        df: Raw calibration dataframe with sensor_metadata.tags column
        sensor_cols: List of sensor channel column names
    
    Returns:
        Dictionary with structure:
        {
            "hwid": hwid,
            "date": date,
            "calibration_valid": bool,
            "calibration_error": str or None,
            "calibration_data": [
                {
                    "channel_name": {
                        "slope": float,
                        "intercept": float,
                        "rmse": float,
                        "r2": float,
                        "n_points": int,
                        "data": {
                            "formazin_value": [sensor readings],
                            "AIR": [air reference readings],
                            ...
                        }
                    }
                },
                ...
            ]
        }
    """
    # Extract hwid from sens_metadata if available
    hwid = None
    if 'sens_metadata' in df.columns:
        try:
            first_metadata = df['sens_metadata'].iloc[0]
            if isinstance(first_metadata, str):
                metadata_dict = json.loads(first_metadata)
                hwid = metadata_dict.get('hwid')
        except (json.JSONDecodeError, IndexError, TypeError):
            hwid = None
    
    # Extract date from earliest timestamp if not provided
    if 'timestamp' in df.columns:
        try:
            earliest_timestamp = pd.to_datetime(df['timestamp']).min()
            date = earliest_timestamp.isoformat()
        except Exception:
            date = None
    
    df_with_formazin = identify_formazin_samples(df)
    
    # Extract validation info from first row (same for all)
    calibration_valid = df_with_formazin['calibration_valid'].iloc[0] if len(df_with_formazin) > 0 else False
    calibration_error = df_with_formazin['calibration_error'].iloc[0] if len(df_with_formazin) > 0 else "No data"
    
    air_df, formazin_df = separate_air_calibration(df_with_formazin)
    
    regression_results = fit_line(formazin_df, sensor_cols=sensor_cols)
    
    raw_data_results = extract_calibration_data(formazin_df, air_df, sensor_cols=sensor_cols)
    
    result = {
        'hwid': hwid,
        'date': date,
        'calibration_valid': calibration_valid,
        'calibration_error': calibration_error,
        'calibration_data': []
    }
    
    # Build calibration_data list with each channel as a dictionary
    for channel in regression_results:
        channel_entry = {
            channel: {
                **regression_results[channel],
                'data': raw_data_results.get(channel, {})
            }
        }
        result['calibration_data'].append(channel_entry)
    
    return result


def separate_air_calibration(df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Separates calibration DataFrame into formazin values (for downstream calculations) and air values (for storage).
    
    Args:
        df: DataFrame with a 'formazin' column
    
    Returns:
        Tuple of (air_df, formazin_df) where air_df contains rows with formazin=="AIR" and formazin_df contains all other rows
    """
    air = df[df['formazin'] == "AIR"].copy()
    formazin = df[df['formazin'] != "AIR"].copy()
    
    return air, formazin

def identify_formazin_samples(df: pd.DataFrame, map: Dict[str, object] = FORMAZIN_MAP) -> pd.DataFrame:
    """
    Returns a DataFrame with an additional 'formazin' column converting keys (e.g. 'F0', 'F1', etc.) to numeric FTU values for downstream calculations.
    
    Maps tags to formazin concentration values using FORMAZIN_MAP.
    Flags calibration as invalid if F0 is missing or fewer than 3 formazin standards are present.
    
    Args:
        df: DataFrame with a 'tags' column containing formazin standard identifiers (e.g., 'F0', 'F1', etc.)
        map: Dictionary mapping tag identifiers to formazin values
    
    Returns:
        DataFrame with added 'formazin' column and 'calibration_valid' flag column, with rows containing tags not in map removed
    """
    out = df.copy()

    out["tags"] = pd.to_numeric(out["tags"], errors="coerce")
    out['formazin'] = out['tags'].map(map)
    out = out[out['formazin'].notna()]
    
    # Check calibration validity
    tags_present = set(out['formazin'].dropna().unique())
    has_air = 'AIR' in tags_present
    num_standards = len(tags_present)
    
    # Flag is True if F0 is present AND at least 3 different standards are present
    calibration_valid = has_air and (num_standards >= 3)
    out['calibration_valid'] = calibration_valid
    
    if not calibration_valid:
        reasons = []
        if not has_air:
            reasons.append("Missing air reference")
        if num_standards < 3:
            reasons.append(f"Insufficient standards: {num_standards} present (need 3)")
        out['calibration_error'] = "; ".join(reasons)
    else:
        out['calibration_error'] = None
    
    return out

def fit_line(df: pd.DataFrame, sensor_cols: list = DEFAULT_SENSOR_COLS) -> Dict:
    """
    Calculate linear regression of formazin concentration (FTU) vs. UrinDx channel output (per-channel).
    
    Fits a linear model for each sensor channel against formazin values and computes regression metrics.
    Returns results in JSON-compatible nested format with channels as top-level keys.
    
    Args:
        df: DataFrame with 'formazin' column and sensor columns, after air calibration has been removed
        sensor_cols: List of sensor channel column names to fit
    
    Returns:
        Dictionary with structure:
        {
            "channel_name": {
                "slope": float,
                "intercept": float,
                "rmse": float,
                "r2": float,
                "n_points": int
            },
            ...
        }
    """
    result = {}
    
    for channel in sensor_cols:
        # Skip if channel not in dataframe
        if channel not in df.columns:
            continue
        
        # Get valid data (no NaNs in either column)
        valid_data = df[[channel, 'formazin']].dropna()
        
        if len(valid_data) == 0:
            continue
        
        X = valid_data[['formazin']].values
        y = valid_data[[channel]].values.ravel()
        
        # Fit linear regression
        model = LinearRegression()
        model.fit(X, y)
        
        # Extract coefficients
        slope = float(model.coef_[0])
        intercept = float(model.intercept_)
        
        # Calculate metrics
        y_pred = model.predict(X)
        rmse = float(np.sqrt(mean_squared_error(y, y_pred)))
        r2 = float(r2_score(y, y_pred))
        
        result[channel] = {
            'slope': slope,
            'intercept': intercept,
            'rmse': rmse,
            'r2': r2,
            'n_points': int(len(X))
        }
    
    return result


def extract_calibration_data(df: pd.DataFrame, air_df: pd.DataFrame, sensor_cols: list = DEFAULT_SENSOR_COLS) -> Dict:
    """
    Extract raw calibration data values organized by channel and formazin concentration.
    
    Organizes actual sensor readings for each channel grouped by formazin value, 
    including air reference data separately.
    
    Args:
        df: DataFrame with 'formazin' column and sensor columns (formazin-only data)
        air_df: DataFrame with air reference data (formazin == "AIR")
        sensor_cols: List of sensor channel column names
    
    Returns:
        Dictionary with structure:
        {
            "channel_name": {
                "formazin_value": [list of sensor readings],
                "AIR": [list of air reference readings],
                ...
            },
            ...
        }
    """
    result = {}
    
    for channel in sensor_cols:
        if channel not in df.columns:
            continue
        
        channel_data = {}
        
        # Add formazin data grouped by concentration
        for formazin_val in sorted(df['formazin'].dropna().unique()):
            readings = df[df['formazin'] == formazin_val][channel].dropna().tolist()
            if readings:
                channel_data[str(formazin_val)] = readings
        
        # Add air reference data
        if len(air_df) > 0 and channel in air_df.columns:
            air_readings = air_df[channel].dropna().tolist()
            if air_readings:
                channel_data['AIR'] = air_readings
        
        if channel_data:
            result[channel] = channel_data
    
    return result






