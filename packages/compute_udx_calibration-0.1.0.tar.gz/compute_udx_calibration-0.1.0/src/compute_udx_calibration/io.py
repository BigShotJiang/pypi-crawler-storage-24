# File input/output, db query, api call, json loading etc.callable


# load_data()
