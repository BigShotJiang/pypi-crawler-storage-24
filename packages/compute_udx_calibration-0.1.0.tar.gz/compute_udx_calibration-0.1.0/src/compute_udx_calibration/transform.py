import pandas as pd
import ast
import json

# Copied from sens_transformation.py in flag-assignment package

#TODO: Once I have an example data structure I need to also expand user_metadata.tags which contains the formazin tag information

DEFAULT_SENSOR_COLS = [
    "R-R", "G-R", "B-R", "IR-R", "R-G", "G-G", "B-G", "IR-G",
    "R-B", "G-B", "B-B", "IR-B", "R-IR", "G-IR", "B-IR", "IR-IR",
    "UVA-UVA", "UVB-UVA", "UVC-UVA", "UVA-UVB", "UVB-UVB", "UVC-UVB"
]

def _ensure_list(series):
    return series.apply(lambda x: ast.literal_eval(x) if isinstance(x, str) else x)

def expand_cycle_columns(df: pd.DataFrame, cycle_col: str = "cycle_index") -> pd.DataFrame:
    """
    Expand 'data' and 'calibration_data' into one dataframe with cycle indices
    and a column indicating source.

    Returns:
        DataFrame with one row per cycle for calibration and read data. 
    """
    df = df.copy()

    def _expand_list_to_cycle(df_in, list_col, cycle_col, source_name):
        rows = []

        for _, row in df_in.iterrows():
            row_dict = row.to_dict()
            values = row_dict[list_col]

            for i, val in enumerate(values):
                new_row = row_dict.copy()
                new_row["value"] = val
                new_row[cycle_col] = i
                new_row["source"] = source_name
                rows.append(new_row)

        return pd.DataFrame(rows)

    # Ensure proper list types
    df["data"] = _ensure_list(df["data"])
    df["calibration_data"] = _ensure_list(df["calibration_data"])

    df_data = _expand_list_to_cycle(df, "data", cycle_col, "read_data")
    df_cal = _expand_list_to_cycle(df, "calibration_data", cycle_col, "calibration_data")

    # Concatenate into one dataframe
    df_out = pd.concat([df_data, df_cal], axis=0, ignore_index=True)
    df_out = df_out.drop(columns=["data", "calibration_data"])

    return df_out

def expand_channel_columns(
    df: pd.DataFrame,
    value_col: str = "value",
    new_cols: list[str] = DEFAULT_SENSOR_COLS,
) -> pd.DataFrame:
    """
    Expand a list-valued column into separate sensor columns.

    Args:
        df: Input dataframe.
        value_col: Column containing list-like values to expand.
        new_cols: Names of the new columns to create.

    Returns:
        DataFrame with the expanded columns added.
    """
    df = df.copy()
    df[value_col] = _ensure_list(df[value_col])

    sensor_length_mismatch = df[value_col].apply(len) != len(new_cols)
    if sensor_length_mismatch.any():
        raise ValueError(
            f"All '{value_col}' lists must have length {len(new_cols)}."
        )

    expanded = pd.DataFrame(df[value_col].tolist(), columns=new_cols, index=df.index)

    df_out = pd.concat([df, expanded], axis=1)
    df_out = df_out.drop(columns=[value_col])

    return df_out

def expand_user_metadata(
    df: pd.DataFrame,
    metadata_col: str = "user_metadata",
    new_cols: list[str] = ["tags", "iteration"],
) -> pd.DataFrame:
    """
    Expand a JSON-string metadata column into separate columns.

    Args:
        df: Input dataframe.
        metadata_col: Column containing JSON-formatted strings.
        new_cols: Specific metadata fields to extract. If None, all fields found
            in the parsed metadata will be expanded.

    Returns:
        DataFrame with the expanded metadata columns added.

    Raises:
        ValueError: If any non-null value in `metadata_col` cannot be parsed as JSON.
        TypeError: If any parsed metadata value is not a dictionary.
        KeyError: If any requested columns in `new_cols` are missing from the parsed metadata.
    """
    df = df.copy()

    def _parse_metadata(value: object) -> dict:
        if pd.isna(value):
            return {}

        if not isinstance(value, str):
            raise TypeError(
                f"All non-null values in '{metadata_col}' must be JSON strings."
            )

        try:
            parsed = json.loads(value)
        except json.JSONDecodeError as exc:
            raise ValueError(
                f"Failed to parse JSON in column '{metadata_col}': {value}"
            ) from exc

        if not isinstance(parsed, dict):
            raise TypeError(
                f"All parsed values in '{metadata_col}' must be dictionaries."
            )

        return parsed

    parsed_metadata = df[metadata_col].apply(_parse_metadata)
    expanded = pd.json_normalize(parsed_metadata)

    if new_cols is not None:
        missing_cols = [col for col in new_cols if col not in expanded.columns]
        if missing_cols:
            raise KeyError(
                f"Requested metadata columns not found in '{metadata_col}': {missing_cols}"
            )
        expanded = expanded[new_cols]

    expanded.index = df.index

    df_out = pd.concat([df, expanded], axis=1)

    return df_out

def transform_sens_to_df(sens) -> pd.DataFrame:
    """
    Loading and transforming UrinDx sensor data from an individual SENS file. One SENS file is one sample collection event.
    """
    sens_df = sens.copy()
    expanded_cycle_df = expand_cycle_columns(sens_df)
    expanded_channel_df = expand_channel_columns(expanded_cycle_df)
    expanded_metadata_df = expand_user_metadata(expanded_channel_df)

    # Only keep read data, omit 'calibration' data
    df_out = expanded_metadata_df[expanded_metadata_df["source"] == "read_data"]

    return df_out





