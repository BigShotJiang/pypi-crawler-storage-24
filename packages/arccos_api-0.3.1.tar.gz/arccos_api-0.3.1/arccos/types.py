"""TypedDict definitions for Arccos API responses.

These are optional type annotations — the actual API client still returns
plain dicts. Use these for type checking and IDE autocompletion::

    from arccos.types import Round, Hole, HandicapBreakdown

    rounds: list[Round] = client.rounds.list()
    print(rounds[0]["noOfShots"])
"""

from __future__ import annotations

from typing import TypedDict


class Round(TypedDict, total=False):
    """A round from the rounds list endpoint."""
    roundId: int
    courseId: int
    courseVersion: int
    startTime: str
    endTime: str
    noOfShots: int
    noOfHoles: int
    teeId: int
    roundTypeId: int
    isEnded: bool
    isVerified: bool
    isPrivate: bool
    isDriverRound: bool
    lastModifiedTime: str


class Shot(TypedDict, total=False):
    """A single shot within a hole."""
    shotId: int
    clubType: int
    clubId: int
    startLat: float
    startLong: float
    endLat: float | None
    endLong: float | None
    distance: float
    noOfPenalties: int
    shotTime: str


class Hole(TypedDict, total=False):
    """A hole within a round detail response."""
    holeId: int
    noOfShots: int
    putts: int
    isGir: str
    isFairWay: str
    isSandSave: str
    isSandSaveChance: str
    isUpDown: str
    isUpDownChance: str
    startTime: str
    endTime: str
    shots: list[Shot]


class RoundDetail(Round, total=False):
    """Full round detail including holes."""
    holes: list[Hole]


class HandicapBreakdown(TypedDict, total=False):
    """Handicap index broken down by category."""
    userHcp: float
    driveHcp: float
    approachHcp: float
    chipHcp: float
    sandHcp: float
    puttHcp: float
    rounds: list[dict]


class SmartDistance(TypedDict, total=False):
    """Smart distance for a single club."""
    distance: float
    unit: str


class ClubDistance(TypedDict, total=False):
    """Club distance data from the smart distances endpoint."""
    clubId: int
    smartDistance: SmartDistance
    longest: SmartDistance
    range: dict
    usage: dict
    terrain: dict
    normalizedSmartDistance: SmartDistance
    gir: dict


class CoursePlayed(TypedDict, total=False):
    """A course from the courses-played endpoint."""
    courseId: int
    name: str
    city: str
    state: str
    country: str
    mensPar: int
    womensPar: int
    noOfHoles: int
    noOfTimesPlayed: int
    latitude: float
    longitude: float


class AchievementStats(TypedDict, total=False):
    """Stats within a personal best achievement."""
    noOfShots: int
    par: int
    driveDistance: float
    noOfPutts: int
    noOfOnePutts: int
    noOfBirdies: int
    noOfPars: int
    fairwayPct: float
    girPct: float
    roundTime: int
    userHcp: float


class Achievement(TypedDict, total=False):
    """A personal best achievement."""
    achievementId: int
    achievementTypeId: int
    name: str
    timestamp: str
    stats: AchievementStats
    course: dict
    round: dict
    tags: list[str]


class PersonalBests(TypedDict, total=False):
    """Response from the personal bests endpoint."""
    achievements: list[Achievement]
