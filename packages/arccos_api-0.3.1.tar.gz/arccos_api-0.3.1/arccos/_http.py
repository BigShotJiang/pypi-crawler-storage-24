"""
Internal HTTP client for the Arccos API.

All API calls share a single requests.Session with automatic token refresh.
Retries transient failures (429, 5xx, timeouts) with exponential backoff.
"""

from __future__ import annotations

import contextlib
import logging
import os
import time
from typing import Any

import requests

from .auth import ArccosAuth, Credentials
from .exceptions import raise_for_status

logger = logging.getLogger(__name__)

API_BASE = "https://api.arccosgolf.com"
DEFAULT_TIMEOUT = 15
MAX_RETRIES = 3
RETRY_BACKOFF = 1.0  # seconds; doubles each retry


class HttpClient:
    """
    Thin wrapper around requests.Session that:

    - Prepends the API base URL
    - Injects the ``Authorization: Bearer`` header on every request
    - Auto-refreshes the JWT when expired
    - Retries on transient failures (429, 5xx, timeouts)
    - Raises typed :mod:`arccos.exceptions` for non-2xx responses
    """

    def __init__(self, auth: ArccosAuth, creds: Credentials):
        self._auth = auth
        self._creds = creds
        self._session = requests.Session()
        self._session.headers.update({
            "Content-Type": "application/json",
            "Accept":       "application/json",
        })
        try:
            self._timeout = int(os.environ.get("ARCCOS_TIMEOUT", DEFAULT_TIMEOUT))
            if self._timeout <= 0:
                raise ValueError
        except (ValueError, TypeError):
            logger.warning("Invalid ARCCOS_TIMEOUT, using default %ds", DEFAULT_TIMEOUT)
            self._timeout = DEFAULT_TIMEOUT

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def get(self, path: str, params: dict | None = None) -> Any:
        """
        Perform an authenticated GET request.

        Args:
            path: API path, e.g. ``"/users/{userId}/rounds"``.
            params: Optional query parameters.

        Returns:
            Parsed JSON response (dict or list).

        Raises:
            arccos.exceptions.ArccosError: On API errors.
        """
        return self._request("GET", path, params=params)

    def post(self, path: str, body: dict | None = None) -> Any:
        """
        Perform an authenticated POST request.

        Args:
            path: API path.
            body: Request body (JSON-serialisable dict).

        Returns:
            Parsed JSON response.
        """
        return self._request("POST", path, json=body)

    def put(self, path: str, body: dict | None = None) -> Any:
        """Perform an authenticated PUT request."""
        return self._request("PUT", path, json=body)

    def delete(self, path: str) -> Any:
        """Perform an authenticated DELETE request."""
        return self._request("DELETE", path)

    # ------------------------------------------------------------------
    # Private
    # ------------------------------------------------------------------

    def _request(self, method: str, path: str, **kwargs) -> Any:
        self._creds = self._auth.ensure_fresh(self._creds)
        headers = {"Authorization": self._auth.auth_header(self._creds)}

        url = f"{API_BASE}{path}"
        logger.debug("%s %s", method, url)

        last_exc: Exception | None = None
        for attempt in range(MAX_RETRIES):
            try:
                resp = self._session.request(
                    method, url, headers=headers,
                    timeout=self._timeout, verify=True, **kwargs,
                )
            except requests.exceptions.Timeout as exc:
                last_exc = exc
                self._backoff(attempt)
                continue
            except requests.exceptions.ConnectionError as exc:
                last_exc = exc
                self._backoff(attempt)
                continue

            if resp.ok:
                if resp.content:
                    return resp.json()
                return {}

            # Retry on 429 and 5xx; raise immediately on other errors
            if resp.status_code == 429 or resp.status_code >= 500:
                try:
                    raise_for_status(resp)
                except Exception as exc:
                    last_exc = exc
                    self._backoff(attempt, resp)
                    continue

            # Non-retryable error (4xx other than 429)
            raise_for_status(resp)

        # Exhausted retries
        raise last_exc  # type: ignore[misc]

    @staticmethod
    def _backoff(attempt: int, resp: requests.Response | None = None) -> None:
        delay = RETRY_BACKOFF * (2 ** attempt)
        # Respect Retry-After header if present (429 responses)
        if resp is not None:
            retry_after = resp.headers.get("Retry-After")
            if retry_after:
                with contextlib.suppress(ValueError, TypeError):
                    delay = max(float(retry_after), delay)
        logger.warning("Retrying in %.1fs (attempt %d/%d)", delay, attempt + 1, MAX_RETRIES)
        time.sleep(delay)
