"""
arccos CLI — pull your Arccos Golf data from the terminal.

Uses the reverse-engineered Arccos Golf API. Not affiliated with Arccos Golf LLC.
"""

from __future__ import annotations

import click

from . import auth, rounds, stats


@click.group()
@click.version_option(package_name="arccos-api", prog_name="arccos")
def cli():
    """
    \b
    arccos — Your Arccos Golf data in the terminal.

    \b
    Quick start:
      arccos login                 Authenticate and save credentials
      arccos rounds                Your recent rounds
      arccos round <id>            Hole-by-hole round detail
      arccos handicap              Current handicap index
      arccos clubs                 Smart club distances
      arccos courses               Courses you've played
      arccos pace                  Pace of play by course
      arccos stats                 Strokes gained analysis
      arccos bests                 Personal bests (all-time records)
      arccos overview              Overall stats summary
      arccos scoring               Scoring trend over recent rounds
      arccos club-shots <id>       Shot history for a specific club
      arccos up-and-down           Scramble / up-and-down stats
      arccos export                Export rounds to JSON/CSV
      arccos logout                Clear cached credentials

    \b
    Credentials are cached in ~/.arccos_creds.json after first login.
    Set ARCCOS_EMAIL and ARCCOS_PASSWORD to skip the prompts.
    """


# Register all command submodules
auth.register(cli)
rounds.register(cli)
stats.register(cli)


def main():
    cli()


if __name__ == "__main__":
    main()
