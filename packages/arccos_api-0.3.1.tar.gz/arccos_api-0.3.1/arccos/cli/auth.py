"""Login and logout CLI commands."""

from __future__ import annotations

import sys

import click

from ._helpers import console, err_console


def register(cli: click.Group) -> None:
    cli.add_command(login)
    cli.add_command(logout)


@click.command()
@click.option("--email", envvar="ARCCOS_EMAIL", prompt="Arccos email",
              help="Your Arccos account email.")
@click.option("--password", envvar="ARCCOS_PASSWORD", prompt="Password",
              hide_input=True, help="Your Arccos password.")
def login(email: str, password: str):
    """Authenticate and save credentials to ~/.arccos_creds.json."""
    from arccos import ArccosClient
    from arccos.exceptions import ArccosAuthError

    with console.status("Logging in\u2026"):
        try:
            client = ArccosClient(email=email, password=password)
        except ArccosAuthError as e:
            err_console.print(f"[red]Login failed:[/red] {e}")
            sys.exit(1)

    console.print(f"[green]\u2713[/green] Logged in as [bold]{client.email}[/bold]")
    console.print(f"  User ID: [dim]{client.user_id}[/dim]")
    console.print("  Credentials cached at [dim]~/.arccos_creds.json[/dim]")


@click.command()
def logout():
    """Clear cached credentials (~/.arccos_creds.json)."""
    from arccos.auth import DEFAULT_CREDS_PATH

    if DEFAULT_CREDS_PATH.exists():
        DEFAULT_CREDS_PATH.unlink()
        console.print(
            "[green]\u2713[/green] Credentials removed from "
            "[bold]~/.arccos_creds.json[/bold]"
        )
        console.print(
            "[dim]Note: Server-side tokens are not revoked. "
            "The access key remains valid until it expires (~180 days).[/dim]"
        )
    else:
        console.print("[dim]No cached credentials found.[/dim]")
