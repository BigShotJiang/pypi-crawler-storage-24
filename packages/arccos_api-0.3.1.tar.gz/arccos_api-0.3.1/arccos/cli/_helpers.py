"""Shared helpers for CLI commands."""

from __future__ import annotations

import json
import os
import sys

import click
from rich.console import Console

console = Console()
err_console = Console(stderr=True)


def _get_client():
    """Build an ArccosClient from env vars or cached creds, with a friendly error."""
    from arccos import ArccosClient
    from arccos.exceptions import ArccosAuthError

    email    = os.environ.get("ARCCOS_EMAIL")
    password = os.environ.get("ARCCOS_PASSWORD")

    try:
        return ArccosClient(email=email, password=password)
    except ArccosAuthError as e:
        err_console.print(f"[red]Auth failed:[/red] {e}")
        err_console.print("Run [bold]arccos login[/bold] or set ARCCOS_EMAIL and ARCCOS_PASSWORD.")
        sys.exit(1)
    except ValueError:
        err_console.print(
            "[red]Not logged in.[/red] Run [bold]arccos login[/bold] first, or set "
            "ARCCOS_EMAIL and ARCCOS_PASSWORD environment variables."
        )
        sys.exit(1)


def _output_json(data):
    click.echo(json.dumps(data, indent=2))


def _flag(minutes: int) -> str:
    if minutes > 300:
        return "\U0001f534"
    if minutes > 270:
        return "\U0001f7e1"
    return "\U0001f7e2"


def _build_course_map(client) -> tuple[dict[int, str], dict[int, int]]:
    """Build courseId → courseName and courseId → par lookups from played courses."""
    try:
        played = client.courses.played()
        names = {
            c["courseId"]: c.get("courseName") or c.get("name") or f"Course {c['courseId']}"
            for c in played
        }
        pars = {
            c["courseId"]: c["mensPar"]
            for c in played
            if c.get("mensPar")
        }
        return names, pars
    except Exception:
        return {}, {}


def _score_color(score: int, par: int | None) -> str:
    """Return a Rich color string based on score relative to par."""
    if par is None:
        return "bold"
    diff = score - par
    if diff <= -2:
        return "bold yellow"  # eagle or better
    if diff == -1:
        return "bold green"   # birdie
    if diff == 0:
        return "white"        # par
    if diff == 1:
        return "red"          # bogey
    return "bold red"         # double+
