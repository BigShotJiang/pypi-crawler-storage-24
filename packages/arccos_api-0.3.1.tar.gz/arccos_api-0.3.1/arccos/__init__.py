"""
arccos — Unofficial Python client for the Arccos Golf API.

Quick start:
    from arccos import ArccosClient

    client = ArccosClient(email="you@example.com", password="secret")
    rounds = client.rounds.list()
    print(client.handicap.current())
"""

import logging as _logging
import os as _os
import re as _re
from importlib.metadata import version as _pkg_version

from .auth import ArccosAuth
from .client import ArccosClient
from .exceptions import (
    ArccosAuthError,
    ArccosError,
    ArccosForbiddenError,
    ArccosNotFoundError,
    ArccosRateLimitError,
)


class _SensitiveFilter(_logging.Filter):
    """Redact tokens, access keys, and passwords from log messages."""

    _PATTERNS = _re.compile(
        r"(Bearer\s+)\S+|"
        r"(eyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.)[A-Za-z0-9_-]+|"
        r"(accessKey[\"']?\s*[:=]\s*[\"']?)\S+",
        _re.IGNORECASE,
    )

    def filter(self, record: _logging.LogRecord) -> bool:
        if isinstance(record.msg, str):
            record.msg = self._PATTERNS.sub(r"\1\2\3[REDACTED]", record.msg)
        return True


_logger = _logging.getLogger("arccos")
_logger.addFilter(_SensitiveFilter())

# Allow ARCCOS_LOG_LEVEL=DEBUG (or INFO, WARNING, etc.) to enable logging
_log_level = _os.environ.get("ARCCOS_LOG_LEVEL")
if _log_level:
    _logger.setLevel(getattr(_logging, _log_level.upper(), _logging.WARNING))
    if not _logger.handlers:
        _handler = _logging.StreamHandler()
        _handler.setFormatter(_logging.Formatter("%(name)s %(levelname)s: %(message)s"))
        _logger.addHandler(_handler)

__version__ = _pkg_version("arccos-api")
__all__ = [
    "ArccosClient",
    "ArccosAuth",
    "ArccosError",
    "ArccosAuthError",
    "ArccosForbiddenError",
    "ArccosNotFoundError",
    "ArccosRateLimitError",
]
