"""
Tests for arccos._http — the internal HTTP client.
"""

from unittest.mock import MagicMock

import pytest
from conftest import make_creds

from arccos._http import API_BASE, HttpClient
from arccos.exceptions import ArccosNotFoundError, ArccosRateLimitError


class TestHttpClient:
    def _make_client(self, creds=None) -> tuple[HttpClient, MagicMock]:
        auth = MagicMock()
        auth.ensure_fresh.side_effect = lambda c: c
        auth.auth_header.return_value = "Bearer fake-token"
        creds = creds or make_creds()
        client = HttpClient(auth=auth, creds=creds)
        return client, auth

    def test_get_sends_request(self):
        client, auth = self._make_client()
        resp = MagicMock()
        resp.ok = True
        resp.content = b'{"data": "value"}'
        resp.json.return_value = {"data": "value"}
        client._session = MagicMock()
        client._session.request.return_value = resp

        result = client.get("/test/path", params={"key": "val"})

        client._session.request.assert_called_once()
        call_args = client._session.request.call_args
        assert call_args[0] == ("GET", f"{API_BASE}/test/path")
        assert call_args[1]["params"] == {"key": "val"}
        assert result == {"data": "value"}

    def test_post_sends_json_body(self):
        client, auth = self._make_client()
        resp = MagicMock()
        resp.ok = True
        resp.content = b'{"created": true}'
        resp.json.return_value = {"created": True}
        client._session = MagicMock()
        client._session.request.return_value = resp

        result = client.post("/test/path", body={"field": "value"})

        call_args = client._session.request.call_args
        assert call_args[0][0] == "POST"
        assert call_args[1]["json"] == {"field": "value"}
        assert result == {"created": True}

    def test_put_sends_json_body(self):
        client, auth = self._make_client()
        resp = MagicMock()
        resp.ok = True
        resp.content = b'{"updated": true}'
        resp.json.return_value = {"updated": True}
        client._session = MagicMock()
        client._session.request.return_value = resp

        client.put("/test/path", body={"field": "new_value"})
        call_args = client._session.request.call_args
        assert call_args[0][0] == "PUT"

    def test_delete_sends_request(self):
        client, auth = self._make_client()
        resp = MagicMock()
        resp.ok = True
        resp.content = b""
        client._session = MagicMock()
        client._session.request.return_value = resp

        result = client.delete("/test/path")
        call_args = client._session.request.call_args
        assert call_args[0][0] == "DELETE"
        assert result == {}

    def test_empty_response_returns_empty_dict(self):
        client, auth = self._make_client()
        resp = MagicMock()
        resp.ok = True
        resp.content = b""
        client._session = MagicMock()
        client._session.request.return_value = resp

        result = client.get("/test/path")
        assert result == {}

    def test_ensure_fresh_called_on_every_request(self):
        client, auth = self._make_client()
        resp = MagicMock()
        resp.ok = True
        resp.content = b"{}"
        resp.json.return_value = {}
        client._session = MagicMock()
        client._session.request.return_value = resp

        client.get("/a")
        client.get("/b")
        assert auth.ensure_fresh.call_count == 2

    def test_auth_header_set_on_request(self):
        client, auth = self._make_client()
        auth.auth_header.return_value = "Bearer my-special-token"
        resp = MagicMock()
        resp.ok = True
        resp.content = b"{}"
        resp.json.return_value = {}
        client._session = MagicMock()
        client._session.request.return_value = resp

        client.get("/test")
        call_args = client._session.request.call_args
        assert call_args[1]["headers"]["Authorization"] == "Bearer my-special-token"

    def test_raises_on_error_response(self):
        client, auth = self._make_client()
        resp = MagicMock()
        resp.ok = False
        resp.status_code = 404
        resp.text = "Not found"
        resp.json.return_value = {"error": {"code": 404, "description": "Not found"}}
        client._session = MagicMock()
        client._session.request.return_value = resp

        with pytest.raises(ArccosNotFoundError):
            client.get("/nonexistent")

    def test_retries_on_429(self):
        """429 rate limit responses should be retried."""
        client, auth = self._make_client()

        fail_resp = MagicMock()
        fail_resp.ok = False
        fail_resp.status_code = 429
        fail_resp.text = "Too Many Requests"
        fail_resp.json.return_value = {"error": {"code": 429, "description": "Rate limited"}}

        ok_resp = MagicMock()
        ok_resp.ok = True
        ok_resp.status_code = 200
        ok_resp.content = b'{"ok": true}'
        ok_resp.json.return_value = {"ok": True}

        client._session = MagicMock()
        client._session.request.side_effect = [fail_resp, ok_resp]

        import arccos._http as http_mod
        original_backoff = http_mod.RETRY_BACKOFF
        http_mod.RETRY_BACKOFF = 0.001  # speed up test
        try:
            result = client.get("/test")
        finally:
            http_mod.RETRY_BACKOFF = original_backoff

        assert result == {"ok": True}
        assert client._session.request.call_count == 2

    def test_retries_on_500(self):
        """5xx server errors should be retried."""
        client, auth = self._make_client()

        fail_resp = MagicMock()
        fail_resp.ok = False
        fail_resp.status_code = 500
        fail_resp.text = "Internal Server Error"
        fail_resp.json.return_value = {"error": {"code": 500, "description": "Server error"}}

        ok_resp = MagicMock()
        ok_resp.ok = True
        ok_resp.status_code = 200
        ok_resp.content = b'{"ok": true}'
        ok_resp.json.return_value = {"ok": True}

        client._session = MagicMock()
        client._session.request.side_effect = [fail_resp, ok_resp]

        import arccos._http as http_mod
        original_backoff = http_mod.RETRY_BACKOFF
        http_mod.RETRY_BACKOFF = 0.001
        try:
            result = client.get("/test")
        finally:
            http_mod.RETRY_BACKOFF = original_backoff

        assert result == {"ok": True}

    def test_retries_on_timeout(self):
        """Connection timeouts should be retried."""
        import requests as req

        client, auth = self._make_client()

        ok_resp = MagicMock()
        ok_resp.ok = True
        ok_resp.status_code = 200
        ok_resp.content = b'{"ok": true}'
        ok_resp.json.return_value = {"ok": True}

        client._session = MagicMock()
        client._session.request.side_effect = [req.exceptions.Timeout("timed out"), ok_resp]

        import arccos._http as http_mod
        original_backoff = http_mod.RETRY_BACKOFF
        http_mod.RETRY_BACKOFF = 0.001
        try:
            result = client.get("/test")
        finally:
            http_mod.RETRY_BACKOFF = original_backoff

        assert result == {"ok": True}

    def test_exhausted_retries_raises(self):
        """After MAX_RETRIES failures, the last exception is raised."""
        client, auth = self._make_client()

        fail_resp = MagicMock()
        fail_resp.ok = False
        fail_resp.status_code = 429
        fail_resp.text = "Rate limited"
        fail_resp.json.return_value = {"error": {"code": 429, "description": "Rate limited"}}

        client._session = MagicMock()
        client._session.request.return_value = fail_resp

        import arccos._http as http_mod
        original_backoff = http_mod.RETRY_BACKOFF
        http_mod.RETRY_BACKOFF = 0.001
        try:
            with pytest.raises(ArccosRateLimitError):
                client.get("/test")
        finally:
            http_mod.RETRY_BACKOFF = original_backoff

        assert client._session.request.call_count == 3  # MAX_RETRIES

    def test_configurable_timeout(self):
        """ARCCOS_TIMEOUT env var configures request timeout."""
        import os

        os.environ["ARCCOS_TIMEOUT"] = "30"
        try:
            client, auth = self._make_client()
            assert client._timeout == 30
        finally:
            del os.environ["ARCCOS_TIMEOUT"]
