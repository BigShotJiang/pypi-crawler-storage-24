import os
import sys
import subprocess
import platform


def search_comments():

    # Check if keyword is provided
    if len(sys.argv) < 2:
        print("Usage: search_Comments <keyword>")
        return

    keyword = sys.argv[1].lower()

    # Start scanning from home directory
    start_dir = os.path.expanduser("~")

    filetype = input(
        "Enter file type to search (e.g. .py, .java, .cpp, .c, .html, .css): "
    )

    print(f"\n📂 Scanning {filetype} files from: {start_dir}")
    print("⏳ Please wait...\n")

    matches = []

    # Walk through directories
    for root, dirs, files in os.walk(start_dir):

        for file in files:

            if file.endswith(filetype):

                filepath = os.path.join(root, file)

                try:
                    with open(filepath, "r", errors="ignore") as f:

                        for lineno, line in enumerate(f, 1):

                            line_strip = line.strip()

                            # Detect comment lines
                            if (
                                line_strip.startswith("//")
                                or line_strip.startswith("#")
                                or line_strip.startswith("/*")
                                or line_strip.startswith("*")
                            ):

                                if keyword in line_strip.lower():

                                    matches.append((filepath, lineno, line_strip))
                                    break

                except:
                    pass

    # If no files found
    if not matches:
        print("❌ No files found.")
        return

    print("✅ Found in files:\n")

    for i, (file, line, comment) in enumerate(matches, 1):

        print(f"{i}. {file}")
        print(f"   Line {line}: {comment}\n")

    choice = input(
        "Enter the number of the file you want to open (or press Enter to skip): "
    )

    if choice:

        try:
            index = int(choice) - 1
            filepath = matches[index][0]

            system = platform.system()

            # Windows
            if system == "Windows":
                os.startfile(filepath)

            # macOS
            elif system == "Darwin":
                subprocess.run(["open", filepath])

            # Linux
            elif system == "Linux":
                subprocess.run(["xdg-open", filepath])

            else:
                print("Unsupported OS")

        except Exception as e:
            print("Error opening file:", e)