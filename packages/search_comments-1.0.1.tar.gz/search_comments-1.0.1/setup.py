from setuptools import setup, find_packages

setup(
    name="search_Comments",
    version="1.0.1",
    author="Your Name",
    description="CLI tool to search code files using comments",
    packages=find_packages(),
    install_requires=[],
    entry_points={
        "console_scripts": [
            "search_Comments=search_comments.main:search_comments",
        ],
    },
    python_requires=">=3.6",
)