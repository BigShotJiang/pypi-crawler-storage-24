# search_Comments

A CLI tool that helps developers find files using comments.

Example:

search_Comments prime

Then select file type like:
.java
.py
.cpp

The tool scans the system and finds files containing comments related to the keyword.