from django.test import TestCase, tag
from joserfc.errors import JoseError
from ninja_aio.exceptions import NotFoundError, parse_jose_error, BaseException
from ninja_aio import NinjaAIO

from tests.test_app import models


class DummyJoseError(JoseError):
    # JoseError is abstract-like; we simulate minimal attributes
    def __init__(self, error: str, description: str | None = None):
        self.error = error
        self.description = description


@tag("exceptions_api")
class ExceptionsAndAPITestCase(TestCase):
    def setUp(self):
        self.api = NinjaAIO()

    def test_not_found_error(self):
        exc = NotFoundError(models.TestModel)
        self.assertEqual(exc.status_code, 404)
        self.assertEqual(
            exc.error,
            {models.TestModel._meta.verbose_name.replace(" ", "_"): "not found"},
        )

    def test_not_found_error_class_name_mode(self):
        """use_verbose_name=False uses snake_case of model __name__ as error key."""
        import re

        original = NotFoundError.use_verbose_name
        try:
            NotFoundError.use_verbose_name = False
            exc = NotFoundError(models.TestModel)
            expected_key = re.sub(r"(?<!^)(?=[A-Z])", "_", models.TestModel.__name__).lower()
            self.assertEqual(exc.status_code, 404)
            self.assertEqual(exc.error, {expected_key: "not found"})
        finally:
            NotFoundError.use_verbose_name = original

    def test_not_found_name_string(self):
        """not_found_name string bypasses auto key and wraps under 'error' key."""
        models.TestModel._meta.not_found_name = "custom_entity"
        try:
            exc = NotFoundError(models.TestModel)
            self.assertEqual(exc.status_code, 404)
            self.assertEqual(exc.error, {"error": "custom_entity"})
        finally:
            del models.TestModel._meta.not_found_name

    def test_not_found_name_dict(self):
        """not_found_name dict is used directly as the full error payload."""
        models.TestModel._meta.not_found_name = {"custom_entity": "not found"}
        try:
            exc = NotFoundError(models.TestModel)
            self.assertEqual(exc.status_code, 404)
            self.assertEqual(exc.error, {"custom_entity": "not found"})
        finally:
            del models.TestModel._meta.not_found_name

    def test_parse_jose_error(self):
        jose_exc = DummyJoseError("bad_token", "signature invalid")
        parsed = parse_jose_error(jose_exc)
        self.assertEqual(parsed["error"], "bad_token")
        self.assertEqual(parsed["details"], "signature invalid")

    def test_api_uses_custom_parser_renderer(self):
        self.assertEqual(self.api.parser.__class__.__name__, "ORJSONParser")
        self.assertEqual(self.api.renderer.__class__.__name__, "ORJSONRenderer")

    def test_api_exception_handlers_registered(self):
        # set_default_exception_handlers should add our handlers
        self.api.set_default_exception_handlers()
        handlers = getattr(self.api, "_exception_handlers", {})
        self.assertIn(BaseException, handlers)
