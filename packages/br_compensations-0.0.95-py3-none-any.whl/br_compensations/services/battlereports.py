import datetime
from dateutil import parser
from typing import List, Dict, Optional, Set
from esi.clients import EsiClientProvider
from django.core.cache import cache
import pytz

from ..domain.evekillmail import EveKillmail
from ..brmodels import Victim,Killmail
from ..models.battlereport import BattleReport
from ..models.filterentities import FilterEntity
from ..models.killmails import KillCompensation
from ..exceptions import PartialReportError
import requests
import json
from allianceauth.services.hooks import get_extension_logger
from allianceauth import __version__, __title_useragent__, __url__
from django.utils.translation import gettext_lazy as _
from django.conf import settings

logger = get_extension_logger(__name__)

esi = EsiClientProvider()

class BattleReportsService:
    
    #Single kill url https://br.evetools.org/api/v1/killmails/133268017/
    #Related url https://br.evetools.org/api/v1/composition/get/
    BR_API_BASE_URL = 'https://br.evetools.org/newapi/'
    CACHE_TIMEOUT = 3600  # 1 час для кэша названий
    
    @classmethod
    def process_all(cls):
        """Выполняет загрузку всех новых отчетов"""
        reports = BattleReport.objects.exclude(status = BattleReport.PROCESS_COMPLETE).all()
        for report in reports:
            try:
                cls.process(report)
            except Exception as e:
                logger.error(f'Ошибка бработки отчета {report.report_id}')
                report.status = BattleReport.PROCESS_FAILED
                report.save()
        
    @classmethod
    def process(cls, report:BattleReport):
        """
        Выполняет загрузку данных из отчета и сохраняет киллы в базе
        Args:
            report: Отчет о сражении
        Returns:
            List[Killmail]: Список загруженных киллмэйлов
        """
        filters = FilterEntity.objects.count()
        if report.report_type is not BattleReport.KILLMAIL and filters == 0:
            logger.info(_('Фильтры не добавлены. Пропускаем обработку отчета для предотвращения загрузки всех киллмэйлов.'))
            return
        
        result = List[Killmail]
        try:
            report.status = BattleReport.PROCESS_PROCESSING
            report.save()
           
            logger.info(f'Начинается обработка отчета: {report.link}')
           
            api_url = cls.get_br_api_url(report.link)
           
            logger.info(f'Ссылка на api отчета: {api_url}')
            logger.info(f'Запрашиваем данные о бое.')

            json_data = cls._get_api_response(api_url)
            
            if json_data is None:
                raise Exception(f'br.evetools.org вернул пустой ответ по адресу {api_url}')
            
            try:
                if 'ended' in json_data:
                    report.updatedAt =  datetime.datetime.fromtimestamp(json_data['ended'], datetime.timezone.utc)
                else:
                    report.updatedAt = datetime.datetime.now(tz=datetime.timezone.utc)
            except Exception as e:
                report.updatedAt = datetime.datetime.now(tz=datetime.timezone.utc)
                logger.error(e)
            
            logger.info('Данные получены')
            
            result = cls._parse_killmails_from_api(api_url[0], json_data)
            
            logger.info(f'В отчете найдено {len(result)} киллмэйлов, отвечающих критериям фильтрации.')
            logger.info('Запрашиваем данные объектов киллмэйла из ESI.')
            # Заполняем killmails названиями сущностей
            
            result = cls.enrich_killmails_with_names(result)
            
            logger.info('Данные получены.')
            logger.info('Сохраняем киллмэйлы в базе данных.')
            
            cls.save_killmails(result,report)
            
            logger.info('Киллмэйлы успешно сохранены.')
            logger.info('Помечаем отчет как обработанный.')
            
            report.status = BattleReport.PROCESS_COMPLETE
            report.save()
            
            logger.info('Обработка успешно выполнена.')
            return result
        except PartialReportError as e:
            '''Не критичная ошибка. Просто бр не до конца загрузился и возвращает неполные данные'''
            '''Помечаем бр для повторной обработки''' 
            report.status = BattleReport.PROCESS_REINITIALIZE
            report.save()
            logger.error(e)
            return None
        except Exception as e:
            logger.error(e)
            return None
        
    
    @classmethod
    def get_br_api_url(cls, url) -> tuple:
        url_parts = url.split('/')
        id = url_parts[-1]
        if id == '' and len(url_parts) > 1:
            id = url_parts[-2]
        if 'zkillboard.com' in url:
            br_endpoint =  'killmails/'
            return  ('kill', f'https://zkillboard.com/api/killID/{id}/')
        elif 'br.evetools.org/related' in url:
            br_endpoint = 'related/'
            id = f'{url_parts[-2]}/{url_parts[-1]}'
            return ('related', f'{cls.BR_API_BASE_URL}{br_endpoint}{id}')
        elif 'br.evetools.org':
            br_endpoint = 'br/composition/'
            return ('composition', f'{cls.BR_API_BASE_URL}{br_endpoint}{id}')
        return ('generic', f'{cls.BR_API_BASE_URL}{br_endpoint}{id}')
    @classmethod
    def _get_api_response(cls, url):
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        
        try:
            print(f"\n🔄 Запрашиваю данные...")
            response = requests.get(url, headers=headers, timeout=15)
            response.raise_for_status()
            print('Данные получены')
            return response.json()
        except requests.exceptions.Timeout:
            print(f"❌ Таймаут запроса для {url}")
            return None
        except requests.exceptions.HTTPError as e:
            print(f"❌ HTTP ошибка для {url}: {e}")
            return None
        except requests.exceptions.RequestException as e:
            print(f"❌ Ошибка запроса для {url}: {e}")
            return None
        except json.JSONDecodeError as e:
            print(f"❌ Ошибка парсинга JSON для {url}: {e}")
            return None
        except Exception as e:
            print(f"❌ Неожиданная ошибка для {url}: {e}")
            return None
    @classmethod
    def _prepare_filter_sets(cls, filter_entities) -> Optional[Dict[str, Set[int]]]:
        """
        Подготавливает множества ID для быстрого поиска по фильтрам
        
        Args:
            filter_entities: QuerySet или список объектов FilterEntity
        
        Returns:
            Dict с множествами ID или None если фильтры не заданы
        """
        if not filter_entities:
            return None
        
        # Преобразуем QuerySet в список если нужно
        if hasattr(filter_entities, 'all'):
            filter_entities = list(filter_entities.all())
        elif hasattr(filter_entities, '__iter__'):
            filter_entities = list(filter_entities)
        else:
            return None
        
        # Создаем множества для быстрого поиска
        character_ids = set()
        corporation_ids = set()
        alliance_ids = set()
        
        for entity in filter_entities:
            if entity.entity_type == FilterEntity.CHARACTER:
                character_ids.add(entity.entity_id)
            elif entity.entity_type == FilterEntity.CORPORATION:
                corporation_ids.add(entity.entity_id)
            elif entity.entity_type == FilterEntity.ALLIANCE:
                alliance_ids.add(entity.entity_id)
        
        if not any([character_ids, corporation_ids, alliance_ids]):
            logger.warning("Нет активных фильтров для фильтрации")
            return None
        
        logger.info(
            f"Подготовлены фильтры: "
            f"{len(character_ids)} персонажей, "
            f"{len(corporation_ids)} корпораций, "
            f"{len(alliance_ids)} альянсов"
        )
        
        return {
            'character_ids': character_ids,
            'corporation_ids': corporation_ids,
            'alliance_ids': alliance_ids
        }
    @classmethod
    def _matches_filter(cls, victim: Victim, filter_sets: Dict[str, Set[int]]) -> bool:
        """
        Проверяет, соответствует ли жертва фильтрам
        
        Args:
            victim: Объект Victim
            filter_sets: Словарь с множествами ID для фильтрации
        
        Returns:
            bool: True если жертва соответствует хотя бы одному фильтру
        """
        return (
            victim.char in filter_sets.get('character_ids', set()) or
            victim.corp in filter_sets.get('corporation_ids', set()) or
            victim.ally in filter_sets.get('alliance_ids', set())
        )
    @classmethod
    def _parse_killmails_from_api(cls,type:str, response_json) -> Optional[List[Killmail]]:
        """
        Парсит JSON-ответ API и возвращает список объектов Killmail
        """
        killmails = []
        
        if isinstance(response_json, str):
            data = json.loads(response_json)
        else:
            data = response_json

        '''
            Загружен один киллмэйл
        '''
        match type:
            case 'kill':
                kills = cls._get_zkillboard_kills(data)
            case 'related':        
                '''
                    Загружаем релейт
                '''
                kills = cls._get_related_killmails(data)
            case 'composition':
                '''
                    Загружен БР
                '''
                kills = cls._get_battle_report_killmails(data)
        
        if kills:
            killmails = cls._get_esi_killmails(kills)
        
        return killmails
    @classmethod
    def _get_zkillboard_kills(cls, data) -> Optional[List[EveKillmail]]:
        result = []
        for kill in data:
            killmail_id = kill['killmail_id']
            zkb_data = kill['zkb']
            result.append(EveKillmail(killmail_id, zkb_data['hash'],zkb_data['totalValue']))
        
        return result
    @classmethod
    def _get_esi_killmails(cls, kills: List[EveKillmail]) -> Optional[List[Killmail]]:
        result = []
        for kill in kills:
            response = esi.client.Killmails.get_killmails_killmail_id_killmail_hash(killmail_hash=kill.hash,killmail_id=kill.id).result()

            result.append(Killmail(
                id=kill.id,
                hash=kill.hash,
                system=response['solar_system_id'],
                system_name='',
                time=response['killmail_time'],
                victim=Victim(
                    char=response['victim']['character_id'],
                    corp=response['victim']['corporation_id'],
                    ally=response['victim']['alliance_id'],
                    ship=response['victim']['ship_type_id'],
                    char_name='',
                    corp_name='',
                    ally_name='',
                    ship_name='',
                    lossValue=kill.lossValue
                )
            )) 
            if settings.DEBUG:
                logger.debug(response) 
        return result
    @classmethod
    def _get_related_killmails(cls, data) -> Optional[List[EveKillmail]]:
        
        killmails = []
        filter_sets = cls._prepare_filter_sets(FilterEntity.objects.all())
        
        if 'kms' in data:
            for km in data['kms']:
                if 'victim' not in km:
                    if 'vict' in km:
                        victim_data = km['vict']
                    else:
                        continue
                else:
                    victim_data = km['victim']
                
                required_victim_fields = ['char', 'corp', 'ally']
                if not all(field in victim_data for field in required_victim_fields):
                    logger.debug('_get_related_killmails')
                    logger.debug(victim_data)
                    raise PartialReportError("Репорт не полностью сформирован. Необходимо подождать некоторое время.")
                
                victim = Victim(
                    char=victim_data['char'],
                    char_name='',  # Будет заполнено позже
                    corp=victim_data['corp'],
                    corp_name='',  # Будет заполнено позже
                    ally=victim_data['ally'],
                    ally_name='',  # Будет заполнено позже
                    lossValue=victim_data['lossValue'] if 'lossValue' in victim_data else 0,
                    ship=victim_data['ship'],
                    ship_name='',
                )
                
                # Применяем фильтрацию если заданы фильтры
                if filter_sets is not None:
                    if not cls._matches_filter(victim, filter_sets):
                        continue
                '''Хордкодим фильтрацию капсул. Нужно будет создать доп фильтр'''
                if victim.ship == 670:
                    continue
                
                required_km_fields = ['id', 'system', 'time']
                if not all(field in km for field in required_km_fields):
                    continue
                
                killmails.append(EveKillmail(km.get('id'), km.get('hash'),victim_data['lossValue'] if 'lossValue' in victim_data else 0))
                
            return killmails
    @classmethod
    def _get_battle_report_killmails(cls, data) -> Optional[List[EveKillmail]]:
        
        killmails = []
        filter_sets = cls._prepare_filter_sets(FilterEntity.objects.all())
        
        for related in data['relateds']:
            if 'kms' not in related:
                continue
                
            for km in related['kms']:
                try:
                    if 'victim' not in km:
                        if 'vict' in km:
                            victim_data = km['vict']
                        else:
                            continue
                    else:
                        victim_data = km['victim']
                    
                    required_victim_fields = ['char', 'corp', 'ally']
                    if not all(field in victim_data for field in required_victim_fields):
                        logger.debug('_get_battle_report_killmails')
                        logger.debug(victim_data)
                        raise PartialReportError("Репорт не полностью сформирован. Необходимо подождать некоторое время.")
                    
                    victim = Victim(
                        char=victim_data['char'],
                        char_name='',  # Будет заполнено позже
                        corp=victim_data['corp'],
                        corp_name='',  # Будет заполнено позже
                        ally=victim_data['ally'],
                        ally_name='',  # Будет заполнено позже
                        lossValue=victim_data['lossValue'] if 'lossValue' in victim_data else 0,
                        ship=victim_data['ship'],
                        ship_name='',
                    )
                    
                    # Применяем фильтрацию если заданы фильтры
                    if filter_sets is not None:
                        if not cls._matches_filter(victim, filter_sets):
                            continue
                    '''Хордкодим фильтрацию капсул. Нужно будет создать доп фильтр'''
                    if victim.ship == 670:
                        continue
                    
                    killmails.append(EveKillmail(km.get('id'), km.get('hash'),victim_data['lossValue'] if 'lossValue' in victim_data else 0))
                    
                except Exception as e:
                    print(f"⚠️ Ошибка при парсинге killmail: {e}")
                    continue
        return killmails
    @classmethod
    def enrich_killmails_with_names(cls, killmails: List[Killmail]) -> List[Killmail]:
        """
        Обогащает killmails названиями сущностей через ESI
        
        Собирает все уникальные ID из killmails (char, corp, ally, system),
        делает один запрос к ESI /universe/names и заполняет поля *_name
        """
        if not killmails:
            return killmails
        
        # Собираем все уникальные ID
        entity_ids = set()
        for km in killmails:
            entity_ids.add(km.system)
            entity_ids.add(km.victim.char)
            entity_ids.add(km.victim.corp)
            entity_ids.add(km.victim.ally)
            entity_ids.add(km.victim.ship)
        
        # Удаляем None или 0 если есть
        entity_ids.discard(0)
        entity_ids.discard(None)
        
        if not entity_ids:
            return killmails
        
        # Проверяем кэш
        cache_key = f"esi_universe_names_{'_'.join(map(str, sorted(entity_ids)))}"
        cached_names = cache.get(cache_key)
        
        if cached_names is not None:
            names_dict = cached_names
            logger.info(f"Использован кэш для {len(names_dict)} сущностей")
        else:
            try:
                # Делаем запрос к ESI /universe/names
                logger.info(f"Запрашиваем названия для {len(entity_ids)} сущностей из ESI")
                response = esi.client.Universe.post_universe_names(ids=list(entity_ids)).result()
                names_dict = {item['id']: item['name'] for item in response}
                cache.set(cache_key, names_dict, cls.CACHE_TIMEOUT)
                logger.info(f"Получены названия для {len(names_dict)} сущностей")
            except Exception as e:
                logger.error(f"Ошибка при получении названий из ESI: {e}")
                return killmails
        
        # Заполняем названия в объектах
        for km in killmails:
            km.system_name = names_dict.get(km.system, '')
            km.victim.char_name = names_dict.get(km.victim.char, '')
            km.victim.corp_name = names_dict.get(km.victim.corp, '')
            km.victim.ally_name = names_dict.get(km.victim.ally, '')
            km.victim.ship_name = names_dict.get(km.victim.ship, '')
        
        return killmails
    @classmethod
    def save_killmails(cls, killmails: List[Killmail], report: BattleReport):
        for killmail in killmails:
            if KillCompensation.objects.filter(killmail_id = killmail.id).exists():
                logger.info('Киллмэйл уже есть в базе данных.')
                logger.debug(KillCompensation.objects.filter(killmail_id = killmail.id).first())
                continue
            try:
                timestamp = datetime.datetime.fromtimestamp(killmail.time, tz = pytz.UTC)
            except Exception as e:
                timestamp = killmail.time
                #timestamp = datetime.datetime.fromtimestamp(killmail.time / 1000, tz = pytz.UTC)
                
            entity = KillCompensation(killmail_id=killmail.id,
                                      character_id=killmail.victim.char,
                                      character_name=killmail.victim.char_name,
                                      alliance_id=killmail.victim.ally,
                                      alliance_name=killmail.victim.ally_name,
                                      corporation_id=killmail.victim.corp,
                                      corporation_name=killmail.victim.corp_name,
                                      loss_value=killmail.victim.lossValue,
                                      timestamp=timestamp,
                                      system=killmail.system,
                                      system_name=killmail.system_name,
                                      ship_type=killmail.victim.ship,
                                      ship_name=killmail.victim.ship_name,
                                      hash=killmail.hash,
                                      source=report)
            entity.save()
            logger.info(f'Сохранен килл {killmail.id}')
