"""
OneXEOS Platform CLI Setup

Install:
    # From PyPI (recommended):
    pip install onex-cli

    # From source (development):
    pip install -e .

Usage:
    onex init                          # Setup VPN + login + .env
    onex deploy                        # Deploy service to platform
    onex debug --service <name>        # Debug service locally
    onex trace <trace_id>              # Trace request through platform
    onex invoke <service>:<function>   # Invoke function directly
"""
from setuptools import setup, find_packages
from pathlib import Path
import re

# Read version from onex/__init__.py (single source of truth)
init_file = Path(__file__).parent / "onex" / "__init__.py"
version_match = re.search(r'^__version__\s*=\s*["\']([^"\']+)["\']', init_file.read_text(), re.M)
VERSION = version_match.group(1) if version_match else "0.0.0"

# Read README if it exists
readme_file = Path(__file__).parent / "README.md"
long_description = readme_file.read_text() if readme_file.exists() else __doc__

setup(
    name="onex-cli",
    version=VERSION,
    author="OneXEOS Platform Team",
    author_email="platform@onexeos.com",
    description="Official CLI for deploying and managing services on OneXEOS Platform (Windows, macOS, Linux)",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/onexeos/onex-cli",
    project_urls={
        "Documentation": "https://github.com/onexeos/onex-cli#readme",
        "Bug Reports": "https://github.com/onexeos/onex-cli/issues",
        "Source": "https://github.com/onexeos/onex-cli",
        "Changelog": "https://github.com/onexeos/onex-cli/blob/main/CHANGELOG.md",
    },
    packages=find_packages(),
    include_package_data=True,  # Include files from MANIFEST.in
    package_data={
        'onex': [
            'templates/**/*.j2',
            'templates/**/*.md',
        ],
    },
    entry_points={
        'console_scripts': [
            'onex=onex.__main__:cli',
            'onex-mcp=onex.mcp.server:main',
        ],
    },
    install_requires=[
        'click>=8.1.7',
        'pyyaml>=6.0.1',
        'requests>=2.31.0',
        'httpx>=0.27.0',  # For email service HTTP requests
        'python-dotenv>=1.0.0',
        'pydantic>=2.0.0',
        'paramiko>=3.4.0',  # For SSH connections to VPN server
        'mcp[cli]>=1.2.0',  # Model Context Protocol for Claude Code integration
        'jinja2>=3.1.0',  # For service scaffolding templates
        'pymongo>=4.6.0',  # For debug command MongoDB access
        'redis>=5.0.0',  # For debug command Redis access
        'cryptography>=42.0.0',  # For secure credential storage (auto-token refresh)
        'pywin32>=306; platform_system=="Windows"',  # For Windows DPAPI decryption
    ],
    extras_require={
        # No extras needed - MCP is now part of main dependencies
    },
    python_requires='>=3.12',
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Build Tools",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Operating System :: OS Independent",
        "Operating System :: Microsoft :: Windows",
        "Operating System :: MacOS",
        "Operating System :: POSIX :: Linux",
        "Environment :: Console",
    ],
    keywords="onexeos platform cli deployment serverless microservices vpn wireguard windows macos linux cross-platform",
)
