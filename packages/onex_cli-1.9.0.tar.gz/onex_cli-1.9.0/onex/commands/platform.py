"""
Platform infrastructure health check command

Checks connectivity to all platform services:
- MongoDB
- Redis
- NATS
- Elasticsearch
- MinIO
- Gateway
"""

import click
import json
from pathlib import Path
from onex.utils import print_success, print_info, print_error, print_warning


def get_active_environment():
    """Get active environment from ~/.onex/active-env"""
    active_file = Path.home() / '.onex' / 'active-env'
    if active_file.exists():
        return active_file.read_text().strip()
    return 'local'


def load_environment_config(env: str) -> dict:
    """Load environment configuration"""
    env_file = Path.home() / '.onex' / 'environments.json'
    if not env_file.exists():
        return {}

    with env_file.open() as f:
        data = json.load(f)

    return data.get(env, {})


@click.group()
def platform():
    """Platform infrastructure management"""
    pass


@platform.command('check')
@click.option('--env', help='Environment to check (defaults to active)')
def check_infrastructure(env):
    """Check platform infrastructure health"""

    # Determine environment
    if not env:
        env = get_active_environment()

    click.echo(f"\n🔍 Checking platform infrastructure ({env})...\n")

    # Add diagnostic check for Docker hostnames in non-local environments
    if env != 'local':
        env_data = load_environment_config(env)
        if env_data:
            credentials = env_data.get('credentials', {})
            # Check if credentials contain Docker hostnames (check all URI fields)
            has_docker_hostnames = False
            for key, value in credentials.items():
                if isinstance(value, str) and any(f'{service}:' in value for service in ['mongodb:', 'redis:', 'nats:', 'elasticsearch:', 'minio:']):
                    has_docker_hostnames = True
                    break

            if has_docker_hostnames:
                print_warning(f"⚠️  Credentials contain Docker hostnames (not VPN-accessible)!")
                print_info(f"   Fix: onex login --env {env}")
                print_info(f"   Or:  onex init --update")
                click.echo()

    # For local environment, use hardcoded localhost credentials
    # CLI runs outside Docker and can't resolve Docker hostnames
    # Use directConnection=true to bypass replica set discovery
    if env == 'local':
        credentials = {
            'mongodb_uri': 'mongodb://admin:admin123@localhost:27017/onexeos-service?authSource=admin&directConnection=true',
            'redis_uri': 'redis://:redis_dev_password_123@localhost:6379',
            'nats_url': 'nats://localhost:4222',
            'elasticsearch_url': 'http://localhost:9200',
            'minio_endpoint': 'localhost:9000',
        }
        platform_url = 'http://localhost:8000'
    else:
        # Load environment configuration from environments.json
        # Note: Credentials are already transformed to VPN IPs during login
        # (see _transform_credentials_for_vpn in login.py)
        env_data = load_environment_config(env)
        if not env_data:
            print_error(f"Environment '{env}' not configured")
            print_info(f"Run: onex login --env {env}")
            return

        credentials = env_data.get('credentials', {})
        platform_url = env_data.get('platform_url', '')

    services_status = {}
    all_healthy = True

    # Check MongoDB
    mongodb_uri = credentials.get('mongodb_uri', '')
    if mongodb_uri:
        try:
            from pymongo import MongoClient
            from pymongo.errors import ConnectionFailure, ServerSelectionTimeoutError

            # Parse host/port from URI
            # mongodb://user:pass@host:port
            if '@' in mongodb_uri:
                host_part = mongodb_uri.split('@')[1].split('/')[0]
            else:
                host_part = mongodb_uri.replace('mongodb://', '').split('/')[0]

            # Add directConnection=true for non-localhost to bypass replica set discovery
            # (replica set returns Docker-internal hostnames unreachable over VPN)
            if 'directConnection' not in mongodb_uri and 'localhost' not in mongodb_uri and '127.0.0.1' not in mongodb_uri:
                if '?' in mongodb_uri:
                    mongodb_uri += '&directConnection=true'
                else:
                    mongodb_uri += '?directConnection=true'

            client = MongoClient(mongodb_uri, serverSelectionTimeoutMS=5000)
            client.admin.command('ping')
            client.close()

            services_status['MongoDB'] = {'status': 'healthy', 'endpoint': host_part}
            print_success(f"  ✅ MongoDB       {host_part:30} Connected")
        except (ConnectionFailure, ServerSelectionTimeoutError) as e:
            services_status['MongoDB'] = {'status': 'unhealthy', 'error': str(e)}
            print_error(f"  ❌ MongoDB       {host_part:30} Connection failed")
            all_healthy = False
        except Exception as e:
            services_status['MongoDB'] = {'status': 'error', 'error': str(e)}
            print_error(f"  ❌ MongoDB       {host_part:30} Error: {e}")
            all_healthy = False

    # Check Redis
    redis_uri = credentials.get('redis_uri', '')
    if redis_uri:
        # Extract host:port for display before attempting connection
        if '@' in redis_uri:
            host_part = redis_uri.split('@')[1]
        else:
            host_part = redis_uri.replace('redis://', '')

        try:
            import redis

            # Parse redis URI: redis://:password@host:port
            client = redis.from_url(redis_uri, socket_connect_timeout=5)
            client.ping()
            client.close()

            services_status['Redis'] = {'status': 'healthy', 'endpoint': host_part}
            print_success(f"  ✅ Redis         {host_part:30} Connected")
        except redis.ConnectionError as e:
            services_status['Redis'] = {'status': 'unhealthy', 'error': str(e)}
            print_error(f"  ❌ Redis         {host_part:30} Connection refused")
            all_healthy = False
        except Exception as e:
            services_status['Redis'] = {'status': 'error', 'error': str(e)}
            print_error(f"  ❌ Redis         {host_part:30} Error: {e}")
            all_healthy = False

    # Check NATS
    nats_url = credentials.get('nats_url', '')
    if nats_url:
        try:
            import socket

            # Parse NATS URL: nats://host:port
            host_port = nats_url.replace('nats://', '').split(':')
            host = host_port[0]
            port = int(host_port[1]) if len(host_port) > 1 else 4222

            # Try to connect
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(5)
            result = sock.connect_ex((host, port))
            sock.close()

            endpoint = f"{host}:{port}"
            if result == 0:
                services_status['NATS'] = {'status': 'healthy', 'endpoint': endpoint}
                print_success(f"  ✅ NATS          {endpoint:30} Connected")
            else:
                services_status['NATS'] = {'status': 'unhealthy', 'error': 'Connection refused'}
                print_error(f"  ❌ NATS          {endpoint:30} Connection refused")
                all_healthy = False
        except Exception as e:
            services_status['NATS'] = {'status': 'error', 'error': str(e)}
            print_error(f"  ❌ NATS          {nats_url:30} Error: {e}")
            all_healthy = False

    # Check Elasticsearch
    es_url = credentials.get('elasticsearch_url', '')
    if es_url:
        try:
            import requests

            response = requests.get(es_url, timeout=5)
            if response.status_code == 200:
                services_status['Elasticsearch'] = {'status': 'healthy', 'endpoint': es_url}
                print_success(f"  ✅ Elasticsearch {es_url:30} Healthy")
            else:
                services_status['Elasticsearch'] = {'status': 'unhealthy', 'error': f'HTTP {response.status_code}'}
                print_error(f"  ❌ Elasticsearch {es_url:30} HTTP {response.status_code}")
                all_healthy = False
        except requests.exceptions.ConnectionError:
            services_status['Elasticsearch'] = {'status': 'unhealthy', 'error': 'Connection refused'}
            print_error(f"  ❌ Elasticsearch {es_url:30} Connection refused")
            all_healthy = False
        except Exception as e:
            services_status['Elasticsearch'] = {'status': 'error', 'error': str(e)}
            print_error(f"  ❌ Elasticsearch {es_url:30} Error: {e}")
            all_healthy = False

    # Check MinIO
    minio_endpoint = credentials.get('minio_endpoint', '')
    if minio_endpoint:
        try:
            import requests

            # MinIO health check endpoint
            url = f"http://{minio_endpoint}/minio/health/live"
            response = requests.get(url, timeout=5)

            if response.status_code == 200:
                services_status['MinIO'] = {'status': 'healthy', 'endpoint': minio_endpoint}
                print_success(f"  ✅ MinIO         {minio_endpoint:30} Healthy")
            else:
                services_status['MinIO'] = {'status': 'unhealthy', 'error': f'HTTP {response.status_code}'}
                print_error(f"  ❌ MinIO         {minio_endpoint:30} HTTP {response.status_code}")
                all_healthy = False
        except requests.exceptions.ConnectionError:
            services_status['MinIO'] = {'status': 'unhealthy', 'error': 'Connection refused'}
            print_error(f"  ❌ MinIO         {minio_endpoint:30} Connection refused")
            all_healthy = False
        except Exception as e:
            services_status['MinIO'] = {'status': 'error', 'error': str(e)}
            print_error(f"  ❌ MinIO         {minio_endpoint:30} Error: {e}")
            all_healthy = False

    # Check Gateway
    if platform_url:
        try:
            import requests

            response = requests.get(f"{platform_url}/health", timeout=5)
            if response.status_code == 200:
                services_status['Gateway'] = {'status': 'healthy', 'endpoint': platform_url}
                print_success(f"  ✅ Gateway       {platform_url:30} Healthy")
            else:
                services_status['Gateway'] = {'status': 'unhealthy', 'error': f'HTTP {response.status_code}'}
                print_error(f"  ❌ Gateway       {platform_url:30} HTTP {response.status_code}")
                all_healthy = False
        except requests.exceptions.ConnectionError:
            services_status['Gateway'] = {'status': 'unhealthy', 'error': 'Connection refused'}
            print_error(f"  ❌ Gateway       {platform_url:30} Connection refused")
            all_healthy = False
        except Exception as e:
            services_status['Gateway'] = {'status': 'error', 'error': str(e)}
            print_error(f"  ❌ Gateway       {platform_url:30} Error: {e}")
            all_healthy = False

    # Summary
    click.echo()
    if all_healthy:
        print_success("Platform Status: ✅ All services healthy")
        click.echo()
        print_info("You can now:")
        print_info("  • Deploy services: onex deploy")
        print_info("  • Debug locally:   python3 runtime_local.py")
    else:
        print_warning("Platform Status: ⚠️  Some services unavailable")
        click.echo()

        # Show what's not working
        unhealthy_services = [name for name, status in services_status.items() if status['status'] != 'healthy']
        if unhealthy_services:
            print_info(f"{len(unhealthy_services)} service(s) not running:")
            for service in unhealthy_services:
                print_info(f"  • {service}")

        # For local environment, suggest docker compose
        if env == 'local':
            click.echo()
            print_info("To start local services:")
            print_info("  cd onexeos-platform-NEW/docker")
            print_info("  docker compose up -d")


# Export for registration
__all__ = ['platform']
