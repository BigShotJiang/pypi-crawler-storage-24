"""
Environment switching with automatic VPN management
"""

import click
from onex.utils import print_success, print_info, print_error, print_warning


@click.command()
@click.argument('environment', type=click.Choice(['local', 'dev', 'staging', 'prod'], case_sensitive=False))
def switch(environment):
    """Switch to a different environment (handles VPN + config)

    This command automatically:
    - Disconnects from current VPN (if any)
    - Connects to target environment's VPN (for dev/staging/prod)
    - Sets the environment as active

    Examples:
        onex switch dev      # Switch to dev environment
        onex switch staging  # Switch to staging environment
        onex switch local    # Switch to local (disconnects VPN)
        onex switch prod     # Switch to production environment
    """
    from onex.commands.login import load_environments, set_active_environment
    from onex.config import get_active_environment

    environment = environment.lower()
    current_env = get_active_environment()

    # Check if already on this environment
    if current_env == environment:
        print_info(f"Already on {environment.upper()} environment")
        return

    click.echo(f"🔄 Switching from {current_env.upper()} to {environment.upper()}...")
    click.echo()

    # Handle VPN switching for remote environments
    if environment in ['dev', 'staging', 'prod']:
        _switch_to_remote_environment(environment, current_env)
    else:  # local
        _switch_to_local_environment(current_env)

    # Set as active environment
    set_active_environment(environment)

    # Update .env symlink if in a service repository
    _update_env_symlink(environment)

    print_success(f"✅ Switched to {environment.upper()} environment")
    click.echo()

    # Set window title immediately (works in current session, all platforms)
    _set_window_title(environment)

    # Automatically setup shell prompt (first time only, persists across sessions)
    _setup_prompt_automatically()

    # Show next steps
    print_info("You can now:")
    print_info(f"  onex deploy                Deploy to {environment}")
    print_info(f"  onex status <service>      Check service status")
    print_info(f"  onex logs <service>        View service logs")


def _set_window_title(env: str):
    """Set terminal window title to show active environment. Works immediately."""
    import sys
    import platform as plat

    try:
        if plat.system() == 'Windows':
            # PowerShell resets title on every prompt, so use ctypes to set console title
            # This persists until the window is closed
            import ctypes
            ctypes.windll.kernel32.SetConsoleTitleW(f"OneX ({env})")
        else:
            # ANSI escape sequence works on macOS/Linux terminals
            sys.stdout.write(f"\033]0;OneX ({env})\007")
            sys.stdout.flush()
    except Exception:
        pass


def _update_env_symlink(env: str):
    """Update .env symlink (Unix) or copy (Windows) to point to .env.{env}"""
    from pathlib import Path
    from onex.commands.login import find_repo_root
    import os
    import platform as plat
    import shutil

    repo_root = find_repo_root()
    if not repo_root:
        return  # Not in a service repository

    env_file = repo_root / f'.env.{env}'
    if not env_file.exists():
        print_warning(f"⚠️  .env.{env} not found in repository")
        print_info(f"   Run: onex login --env {env}")
        return

    symlink_file = repo_root / '.env'

    # Remove existing symlink or file
    if symlink_file.exists() or symlink_file.is_symlink():
        symlink_file.unlink()

    if plat.system() == 'Windows':
        # Windows: copy file (symlinks require admin privileges)
        shutil.copy2(env_file, symlink_file)
        print_success(f"✅ Updated: .env (copy of .env.{env})")
    else:
        # Unix: symlink
        os.symlink(f'.env.{env}', symlink_file)
        print_success(f"✅ Updated: .env → .env.{env}")


def _switch_to_remote_environment(target_env: str, current_env: str):
    """Switch to a remote environment (dev/staging/prod)"""
    import platform as plat
    from onex.commands.login import load_environments

    # Load environment config
    try:
        envs = load_environments()
        if target_env not in envs:
            print_error(f"Environment '{target_env}' not configured")
            print_info(f"Run: onex init --config-file <{target_env}-config.conf>")
            raise click.Abort()

        env_config = envs[target_env]
    except FileNotFoundError:
        print_error("No environments configured")
        print_info(f"Run: onex init")
        raise click.Abort()

    # Windows: VPN must be managed manually via WireGuard GUI
    if plat.system() == 'Windows':
        print_warning(f"Please ensure your {target_env.upper()} VPN is connected in WireGuard")
        print_info(f"   Open WireGuard > Activate the {target_env} tunnel")

        # Show platform info
        platform_url = env_config.get('platform_url', 'N/A')
        print_info(f"   Platform: {platform_url}")

        if 'user' in env_config and 'email' in env_config['user']:
            print_info(f"   Email:    {env_config['user']['email']}")
        return

    # macOS/Linux: Automate VPN switching
    from onex.vpn.setup_vpn import list_configured_vpns, get_environment_from_interface
    from onex.vpn import connect, disconnect
    from onex.vpn.wireguard_manager import WireGuardError

    # Step 1: Disconnect from current VPN if on remote environment
    if current_env in ['dev', 'staging', 'prod']:
        print_info(f"Disconnecting from {current_env.upper()} VPN...")
        try:
            vpns = list_configured_vpns()
            for vpn in vpns:
                env = get_environment_from_interface(vpn)
                if env == current_env:
                    disconnect(vpn)
                    print_success(f"✅ Disconnected from {current_env.upper()}")
                    break
        except Exception as e:
            print_warning(f"Could not disconnect from {current_env}: {str(e)}")

    # Step 2: Connect to target VPN
    print_info(f"Connecting to {target_env.upper()} VPN...")
    try:
        vpns = list_configured_vpns()
        target_interface = None

        for vpn in vpns:
            env = get_environment_from_interface(vpn)
            if env == target_env:
                target_interface = vpn
                break

        if not target_interface:
            print_error(f"No VPN configured for {target_env}")
            print_info(f"Run: onex init --config-file <{target_env}-config.conf>")
            raise click.Abort()

        connect(target_interface)
        print_success(f"✅ Connected to {target_env.upper()} VPN")

        # Show platform info
        platform_url = env_config.get('platform_url', 'N/A')
        print_info(f"   Platform: {platform_url}")

        # Show credentials if available
        if 'user' in env_config and 'email' in env_config['user']:
            print_info(f"   Email:    {env_config['user']['email']}")

    except WireGuardError as e:
        print_error(f"VPN connection failed: {str(e)}")
        raise click.Abort()


def _switch_to_local_environment(current_env: str):
    """Switch to local environment (disconnect all VPNs)"""
    import platform as plat

    # Disconnect all VPNs if coming from remote environment
    if current_env in ['dev', 'staging', 'prod']:
        if plat.system() == 'Windows':
            print_warning(f"Please disconnect your {current_env.upper()} VPN in WireGuard")
        else:
            print_info("Disconnecting from VPN...")
            try:
                from onex.vpn.setup_vpn import list_configured_vpns
                from onex.vpn import disconnect

                vpns = list_configured_vpns()
                disconnected = False

                for vpn in vpns:
                    try:
                        disconnect(vpn)
                        disconnected = True
                    except:
                        pass  # Already disconnected

                if disconnected:
                    print_success("✅ Disconnected from VPN")
            except Exception as e:
                print_warning(f"Could not disconnect VPN: {str(e)}")

    print_info("Switching to local development mode")
    print_info("   Platform: http://localhost:8000")


def _setup_prompt_automatically():
    """
    Automatically add environment indicator to shell prompt (one-time).

    Supports:
    - zsh (~/.zshrc)
    - bash (~/.bashrc)
    - PowerShell ($PROFILE) - Windows
    - CMD (AutoRun registry) - Windows

    Adds marker file to prevent duplicate setup.
    Runs only once per installation.
    """
    from pathlib import Path
    import os
    import platform as plat

    onex_dir = Path.home() / '.onex'
    marker_file = onex_dir / '.prompt_setup_v2_done'

    # Only run once per version
    if marker_file.exists():
        return

    is_windows = plat.system() == 'Windows'

    if is_windows:
        _setup_prompt_windows(onex_dir, marker_file)
    else:
        _setup_prompt_unix(onex_dir, marker_file)


def _setup_prompt_unix(onex_dir, marker_file):
    """Setup shell prompt for macOS/Linux (zsh/bash)."""
    from pathlib import Path
    import os

    shell = os.environ.get('SHELL', '/bin/zsh')
    if 'zsh' in shell:
        rc_file = Path.home() / '.zshrc'
        prompt_code = '''
# OneX Environment Indicator (added by onex CLI)
setopt PROMPT_SUBST
onex_env() {
    [[ -f ~/.onex/active-env ]] && echo "($(cat ~/.onex/active-env)) "
}
PROMPT='$(onex_env)'$PROMPT
'''
    elif 'bash' in shell:
        rc_file = Path.home() / '.bashrc'
        prompt_code = '''
# OneX Environment Indicator (added by onex CLI)
__onex_env() {
    if [ -f ~/.onex/active-env ]; then
        echo "($(cat ~/.onex/active-env)) "
    fi
}
PS1='$(__onex_env)'$PS1
'''
    else:
        return

    # Check if already configured
    if rc_file.exists():
        try:
            content = rc_file.read_text()
            if 'onex_env()' in content or '__onex_env()' in content or 'OneX Environment Indicator' in content:
                onex_dir.mkdir(parents=True, exist_ok=True)
                marker_file.touch()
                return
        except Exception:
            pass

    try:
        with rc_file.open('a') as f:
            f.write(prompt_code)

        onex_dir.mkdir(parents=True, exist_ok=True)
        marker_file.touch()

        click.echo()
        print_success(f"✅ Added environment indicator to ~/{rc_file.name}")
        print_info(f"   Reload shell: source ~/{rc_file.name}")
        print_info(f"   Prompt will show: (dev) user@host %")
        click.echo()
    except Exception:
        pass


def _setup_prompt_windows(onex_dir, marker_file):
    """Setup shell prompt for Windows (PowerShell + CMD)."""
    from pathlib import Path

    # --- PowerShell Profile ---
    ps_profile = _get_powershell_profile()
    ps_setup_done = False

    if ps_profile:
        ps_marker_v2 = 'OneX Environment Indicator v2'
        already_configured = False
        if ps_profile.exists():
            try:
                content = ps_profile.read_text()
                if ps_marker_v2 in content:
                    already_configured = True
            except Exception:
                pass

        if not already_configured:
            # PowerShell prompt function that:
            # 1. Prepends (env) to the prompt text
            # 2. Sets window title to "OneX (env)" on every prompt render
            #    (PowerShell resets title each prompt, so we must set it here)
            ps_code = f'''
# {ps_marker_v2} (added by onex CLI)
# Save original prompt if not already saved
if (-not (Test-Path Function:\\__onex_original_prompt)) {{
    Copy-Item Function:\\prompt Function:\\__onex_original_prompt
}}
function prompt {{
    $onexEnv = ""
    $envFile = Join-Path $env:USERPROFILE ".onex" "active-env"
    if (Test-Path $envFile) {{
        $onexEnv = (Get-Content $envFile -Raw).Trim()
        $Host.UI.RawUI.WindowTitle = "OneX ($onexEnv)"
        $onexEnv = "($onexEnv) "
    }}
    $onexEnv + (__onex_original_prompt)
}}
'''
            try:
                ps_profile.parent.mkdir(parents=True, exist_ok=True)
                with ps_profile.open('a') as f:
                    f.write(ps_code)
                ps_setup_done = True
            except Exception:
                pass

    # --- CMD (via AutoRun registry key) ---
    cmd_setup_done = _setup_cmd_prompt(onex_dir)

    # Mark as done if at least one shell was configured
    if ps_setup_done or cmd_setup_done:
        onex_dir.mkdir(parents=True, exist_ok=True)
        marker_file.touch()

        click.echo()
        if ps_setup_done:
            print_success(f"✅ Added environment indicator to PowerShell profile")
            print_info(f"   Restart PowerShell to see: (dev) PS C:\\>")
        if cmd_setup_done:
            print_success(f"✅ Added environment indicator for CMD")
            print_info(f"   Open new CMD window to see: (dev) C:\\>")
        click.echo()
    elif ps_profile and not ps_setup_done:
        # Already configured, just mark
        onex_dir.mkdir(parents=True, exist_ok=True)
        marker_file.touch()


def _get_powershell_profile():
    """Get the PowerShell profile path."""
    from pathlib import Path
    import subprocess

    # Try PowerShell 7+ (pwsh) first, then Windows PowerShell
    for shell in ['pwsh', 'powershell']:
        try:
            result = subprocess.run(
                [shell, '-NoProfile', '-Command', '$PROFILE'],
                capture_output=True, text=True, timeout=5
            )
            if result.returncode == 0 and result.stdout.strip():
                return Path(result.stdout.strip())
        except Exception:
            continue

    # Fallback: standard profile location
    docs = Path.home() / 'Documents'
    for ps_dir in ['PowerShell', 'WindowsPowerShell']:
        profile = docs / ps_dir / 'Microsoft.PowerShell_profile.ps1'
        return profile

    return None


def _setup_cmd_prompt(onex_dir):
    """Setup CMD prompt via a batch script and AutoRun registry key."""
    from pathlib import Path

    # Create a small batch script that sets the prompt
    cmd_script = onex_dir / 'cmd_prompt.bat'
    cmd_script_content = '@echo off\r\nset ONEX_ENV=\r\nif exist "%USERPROFILE%\\.onex\\active-env" (\r\n    set /p ONEX_ENV=<"%USERPROFILE%\\.onex\\active-env"\r\n)\r\nif defined ONEX_ENV (\r\n    prompt (%ONEX_ENV%) $P$G\r\n)\r\n'

    try:
        onex_dir.mkdir(parents=True, exist_ok=True)
        cmd_script.write_text(cmd_script_content)
    except Exception:
        return False

    # Set registry AutoRun to execute the script on every new CMD window
    try:
        import winreg
        key_path = r'Software\Microsoft\Command Processor'
        autorun_value = f'"{cmd_script}"'

        # Read existing AutoRun to avoid overwriting
        try:
            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_READ)
            existing, _ = winreg.QueryValueEx(key, 'AutoRun')
            winreg.CloseKey(key)
            if str(cmd_script) in existing:
                return False  # Already configured
            autorun_value = f'{existing} & "{cmd_script}"'
        except (FileNotFoundError, OSError):
            pass  # No existing AutoRun

        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_SET_VALUE)
        winreg.SetValueEx(key, 'AutoRun', 0, winreg.REG_SZ, autorun_value)
        winreg.CloseKey(key)
        return True
    except Exception:
        return False
