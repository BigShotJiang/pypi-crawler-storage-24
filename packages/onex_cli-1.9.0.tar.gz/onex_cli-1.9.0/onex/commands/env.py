"""
Environment management commands for OneX CLI

Commands:
  onex env              - Show active environment
  onex env list         - List all configured environments
  onex env show <env>   - Show environment details
  onex env sync         - Generate .env file for local debugging
"""

import click
import json
from pathlib import Path
from datetime import datetime
from onex.utils import print_success, print_info, print_error, print_warning


def get_onex_dir() -> Path:
    """Get ~/.onex directory, create if doesn't exist"""
    onex_dir = Path.home() / '.onex'
    onex_dir.mkdir(exist_ok=True)
    return onex_dir


def get_environments_file() -> Path:
    """Get environments.json file path"""
    return get_onex_dir() / 'environments.json'


def get_active_env_file() -> Path:
    """Get active-env file path"""
    return get_onex_dir() / 'active-env'


def load_environments() -> dict:
    """Load all environments from ~/.onex/environments.json"""
    env_file = get_environments_file()
    if not env_file.exists():
        return {}

    with env_file.open() as f:
        return json.load(f)


def get_active_environment() -> str:
    """Get currently active environment"""
    active_file = get_active_env_file()
    if active_file.exists():
        return active_file.read_text().strip()
    return 'local'  # Default to local


def set_active_environment(env: str):
    """Set active environment"""
    active_file = get_active_env_file()
    active_file.write_text(env)
    active_file.chmod(0o644)


def mask_secret(value: str, reveal: bool = False) -> str:
    """Mask secret values for display"""
    if reveal or not value:
        return value

    if len(value) <= 6:
        return "***"

    # Show first 3 and last 3 characters
    return value[:3] + "***" + value[-3:]


@click.group(invoke_without_command=True)
@click.pass_context
def env(ctx):
    """Manage OneX CLI environments"""
    if ctx.invoked_subcommand is None:
        # No subcommand - show active environment
        active_env = get_active_environment()
        envs = load_environments()

        if active_env not in envs:
            print_warning(f"Active environment '{active_env}' not configured")
            print_info(f"Run: onex login --env {active_env}")
            return

        env_data = envs[active_env]

        click.echo()
        print_success(f"✅ Active environment: {active_env}")
        print_info(f"📡 Platform URL: {env_data.get('platform_url', 'N/A')}")
        click.echo()


@env.command('list')
def list_environments():
    """List all configured environments"""
    envs = load_environments()
    active_env = get_active_environment()

    if not envs:
        print_warning("No environments configured")
        print_info("Run: onex login --env <environment>")
        return

    click.echo("\nConfigured Environments:")
    for env_name, env_data in envs.items():
        is_active = env_name == active_env
        active_marker = "✅" if is_active else "  "

        # Get user info if available
        user_info = ""
        if env_name == "local":
            user_info = "No login required"
        elif 'user' in env_data:
            email = env_data['user'].get('email', 'unknown')

            # Check token expiration
            expires_at = env_data.get('expires_at')
            if expires_at:
                from datetime import datetime
                try:
                    exp_dt = datetime.fromisoformat(expires_at.replace('Z', '+00:00'))
                    now = datetime.now(exp_dt.tzinfo)

                    if exp_dt < now:
                        user_info = f"{email} (token expired)"
                    else:
                        diff = exp_dt - now
                        minutes = int(diff.total_seconds() / 60)
                        if minutes < 60:
                            user_info = f"{email} (expires in {minutes}m)"
                        else:
                            hours = minutes // 60
                            user_info = f"{email} (expires in {hours}h)"
                except:
                    user_info = email
            else:
                user_info = email
        else:
            user_info = "(not logged in)"

        status_text = "(active)" if is_active else ""
        click.echo(f"  {active_marker} {env_name:10} {status_text:10} - {user_info}")

    click.echo()
    print_info("Use 'onex switch <env>' to switch active environment")
    print_info("Use 'onex env show <env>' to see credentials")


@env.command('show')
@click.argument('environment')
@click.option('--reveal', is_flag=True, help='Show full secrets (unmasked)')
def show_environment(environment, reveal):
    """Show environment details and credentials"""
    envs = load_environments()

    if environment not in envs:
        print_error(f"Environment '{environment}' not configured")
        print_info(f"Run: onex login --env {environment}")
        return

    env_data = envs[environment]

    click.echo(f"\n{'='*70}")
    click.echo(f"Environment: {environment}")
    click.echo(f"{'='*70}")

    # Platform info
    print_info(f"Platform URL: {env_data.get('platform_url', 'N/A')}")

    # User info (if authenticated)
    if 'user' in env_data:
        user = env_data['user']
        print_info(f"User: {user.get('email', 'N/A')}")
        print_info(f"Role: {user.get('role', 'N/A')}")

        # Token expiration
        if 'expires_at' in env_data:
            print_info(f"Token expires: {env_data['expires_at']}")

    # Credentials
    if 'credentials' in env_data:
        click.echo(f"\n{'Credentials:':}")
        creds = env_data['credentials']

        for key, value in creds.items():
            if value:
                # Mask secrets unless --reveal
                if any(secret in key.lower() for secret in ['password', 'secret', 'key']):
                    display_value = mask_secret(str(value), reveal)
                else:
                    display_value = value

                print_info(f"  {key.upper()}: {display_value}")

    click.echo()

    if not reveal:
        print_info("Use '--reveal' to show full secrets")


@env.command('sync')
@click.option('--env', help='Environment to sync (defaults to active)')
def sync_environment(env):
    """Regenerate .env.{env} file for local debugging from stored credentials"""

    # Determine which environment to use
    if not env:
        env = get_active_environment()

    envs = load_environments()
    if env not in envs:
        print_error(f"Environment '{env}' not configured")
        print_info(f"Run: onex login --env {env}")
        return

    env_data = envs[env]
    credentials = env_data.get('credentials', {})
    platform_url = env_data.get('platform_url', '')

    if not credentials:
        print_error(f"No credentials found for environment '{env}'")
        return

    # Import hostname transformation helper
    from onex.commands.login import transform_docker_hostnames_to_vpn
    import re

    # Extract VPN IP from platform URL if present (e.g., http://10.0.0.1:8000)
    vpn_ip_match = re.match(r'https?://(\d+\.\d+\.\d+\.\d+):\d+', platform_url)
    vpn_ip = vpn_ip_match.group(1) if vpn_ip_match else None

    # Parse Redis URI to extract individual components
    redis_uri = credentials.get('redis_uri', '') or ''
    redis_host = vpn_ip if vpn_ip else 'localhost'  # Default to VPN IP if available
    redis_port = '6379'
    redis_password = credentials.get('redis_password', '') or ''

    if redis_uri:
        # Transform Docker hostnames to VPN IP if debugging via VPN
        if vpn_ip:
            redis_uri = transform_docker_hostnames_to_vpn(redis_uri, vpn_ip)

        # Parse redis://[:password@]host:port
        match = re.match(r'redis://(?::([^@]+)@)?([^:]+):(\d+)', redis_uri)
        if match:
            import urllib.parse
            # URL-decode password from URI (it's URL-encoded in the URI)
            redis_password = urllib.parse.unquote(match.group(1)) if match.group(1) else redis_password
            redis_host = match.group(2)
            redis_port = match.group(3)
    elif vpn_ip:
        # If redis_uri is not provided but we have VPN IP, construct URI with password
        if redis_password:
            redis_uri = f'redis://:{redis_password}@{vpn_ip}:{redis_port}'
        else:
            redis_uri = f'redis://{vpn_ip}:{redis_port}'

    # Fix MongoDB URI for local debugging
    mongodb_uri = credentials.get('mongodb_uri', '')

    # Transform Docker hostnames to VPN IP if debugging via VPN
    if vpn_ip and mongodb_uri:
        mongodb_uri = transform_docker_hostnames_to_vpn(mongodb_uri, vpn_ip)

    # Add directConnection=true for VPN or localhost connections to bypass replica set discovery
    if mongodb_uri and (vpn_ip or 'localhost' in mongodb_uri):
        # Add directConnection=true for replica set connections from host machine
        if '?' in mongodb_uri:
            if 'directConnection' not in mongodb_uri:
                mongodb_uri += '&directConnection=true'
        else:
            mongodb_uri += '?directConnection=true'

    # Transform other connection strings
    nats_url = credentials.get('nats_url', '')
    if vpn_ip and nats_url:
        nats_url = transform_docker_hostnames_to_vpn(nats_url, vpn_ip)

    elasticsearch_url = credentials.get('elasticsearch_url', '')
    if vpn_ip and elasticsearch_url:
        elasticsearch_url = transform_docker_hostnames_to_vpn(elasticsearch_url, vpn_ip)

    minio_endpoint = credentials.get('minio_endpoint', '')
    if vpn_ip and minio_endpoint:
        minio_endpoint = transform_docker_hostnames_to_vpn(minio_endpoint, vpn_ip)

    # Check if we're in a service directory
    cwd = Path.cwd()
    service_yml = cwd / 'service.yml'

    if not service_yml.exists():
        print_warning("Not in a service directory (no service.yml found)")
        print_info("Generating .env in current directory anyway...")

    # Generate .env content
    env_content = f"""# Auto-generated by: onex env sync
# Environment: {env}
# Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
# DO NOT commit to git!

# Platform Connection
PLATFORM_URL={env_data.get('platform_url', '')}
GATEWAY_URL={env_data.get('platform_url', '')}

# Database
MONGODB_URI={mongodb_uri}
MONGODB_DATABASE={credentials.get('mongodb_database', 'onexeos-service')}

# Cache
REDIS_URI={redis_uri}
REDIS_HOST={redis_host}
REDIS_PORT={redis_port}
REDIS_PASSWORD={redis_password}

# Messaging
NATS_URL={nats_url}

# Search
ELASTICSEARCH_URL={elasticsearch_url}
# nolicore adapter uses ELASTIC_SEARCH_HOST (with underscores)
ELASTIC_SEARCH_HOST={credentials.get('elastic_search_host', elasticsearch_url)}
ELASTIC_SEARCH_USERNAME={credentials.get('elastic_search_username', '')}
ELASTIC_SEARCH_PASSWORD={credentials.get('elastic_search_password', '')}

# Storage
MINIO_ENDPOINT={minio_endpoint}
MINIO_ACCESS_KEY={credentials.get('minio_access_key', '')}
MINIO_SECRET_KEY={credentials.get('minio_secret_key', '')}
MINIO_BUCKET_NAME={credentials.get('minio_bucket_name', 'onexeos')}
# Service code reads BUCKET_NAME (alias for MINIO_BUCKET_NAME)
BUCKET_NAME={credentials.get('minio_bucket_name', 'onexeos')}

# Authentication
JWT_SECRET_KEY={credentials.get('jwt_secret_key', '')}
JWT_ALGORITHM={credentials.get('jwt_algorithm', 'HS256')}
JWT_ACCESS_TOKEN_EXPIRE_MINUTES={credentials.get('jwt_access_token_expire_minutes', 60)}

# SMTP (if configured)
SMTP_HOST={credentials.get('smtp_host', '')}
SMTP_PORT={credentials.get('smtp_port', '')}
SMTP_USERNAME={credentials.get('smtp_username', '')}
SMTP_PASSWORD={credentials.get('smtp_password', '')}

# Development
DEBUG=true
LOG_LEVEL=DEBUG
ENV={env}
ENVIRONMENT={env}

# GitHub Token (for installing private repositories)
GITHUB_TOKEN={credentials.get('github_token', '')}
"""

    # Write .env.{env} file
    env_file = cwd / f'.env.{env}'
    env_file.write_text(env_content)
    env_file.chmod(0o600)  # Owner read/write only

    print_success(f"✅ Generated: {env_file}")

    # Update symlink if this is the active environment
    active_env = get_active_environment()
    if env == active_env:
        symlink_file = cwd / '.env'

        # Remove existing symlink or file
        if symlink_file.exists() or symlink_file.is_symlink():
            symlink_file.unlink()

        # Create symlink
        import os
        os.symlink(f'.env.{env}', symlink_file)
        print_success(f"✅ Updated: .env → .env.{env}")

    click.echo()
    print_info("Ready for local debugging:")
    print_info(f"  • onex debug --service <service_name>")
    print_info(f"  • Or from repo root: onex debug")

    if env != 'local':
        print_warning(f"Using {env.upper()} infrastructure (not local)")
        print_info(f"  MongoDB: {mongodb_uri.split('@')[1] if '@' in mongodb_uri else mongodb_uri}")
        print_info(f"  Redis: {redis_host}:{redis_port}")


# Removed: onex use command - replaced by onex switch
# Use: onex switch <env> instead
