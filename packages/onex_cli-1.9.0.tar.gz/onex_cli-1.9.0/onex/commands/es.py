"""
ES command group - Elasticsearch management commands

Commands:
  reindex  - Reindex ES from MongoDB for a service's es_sync collections
"""

import click
import json
import requests
from onex.config import get_config, get_access_token, get_active_environment
from onex.utils import print_error, print_info, print_success, print_warning
from onex.utils.auth import auto_refresh_token


@click.group()
def es():
    """Elasticsearch management commands."""
    pass


@es.command()
@click.argument('service_name')
@click.option('--collection', '-c', default=None, help='Specific collection to reindex (all if omitted)')
@click.option('--env', default=None, help='Environment (local/dev/staging/prod, defaults to active)')
@click.option('--platform-url', help='Override platform URL')
@click.option('--json', 'output_json', is_flag=True, help='Output as JSON')
def reindex(service_name, collection, env, platform_url, output_json):
    """Reindex Elasticsearch from MongoDB for a service.

    Reads all documents from MongoDB collections that have es_sync triggers
    registered and bulk-indexes them into Elasticsearch.

    \b
    Examples:
      # Reindex all ES collections for crm service
      onex es reindex crm

      # Reindex a specific collection
      onex es reindex crm --collection adminService

      # Reindex on dev environment
      onex es reindex crm --env dev
    """
    if env is None:
        env = get_active_environment()

    config = get_config()
    base_url = platform_url or config.get_platform_url(env)

    # Build auth headers
    access_token = get_access_token(env)
    headers = {}
    if access_token:
        headers['Authorization'] = f'Bearer {access_token}'

    click.echo(f"🔄 Reindexing ES for {service_name} ({env})...")

    body = {'service_name': service_name}
    if collection:
        body['collection'] = collection

    try:
        response = requests.post(
            f"{base_url}/_internal/reindex",
            json=body,
            headers=headers,
            timeout=300,
        )

        if response.status_code == 401 and env != "local":
            print_warning("Token expired, refreshing...")
            if auto_refresh_token(env, silent=False):
                access_token = get_access_token(env)
                headers['Authorization'] = f'Bearer {access_token}'
                response = requests.post(
                    f"{base_url}/_internal/reindex",
                    json=body,
                    headers=headers,
                    timeout=300,
                )
            else:
                print_error("Authentication failed - could not refresh token")
                print_info(f"Please login again: onex login --env {env}")
                return

        if response.status_code == 200:
            data = response.json()

            if output_json:
                click.echo(json.dumps(data, indent=2))
                return

            collections = data.get('collections', [])
            total = data.get('total_docs_synced', 0)

            if not collections:
                print_info("No es_sync collections found for this service.")
                return

            click.echo()
            for col in collections:
                name = col.get('collection', '?')
                index = col.get('index', '?')
                docs = col.get('docs_synced', 0)
                duration = col.get('duration_ms', 0)
                error = col.get('error')

                if error:
                    click.echo(click.style(
                        f"  ❌ {name} → {index}: {error}", fg='red'))
                else:
                    click.echo(
                        f"  ✅ {name} → {index}: {docs} docs ({duration}ms)")

            click.echo()
            print_success(f"Total: {total} docs synced across {len(collections)} collection(s)")

        elif response.status_code == 404:
            print_error(response.json().get('detail', 'No es_sync triggers found'))
            print_info("Make sure the service has es_sync configured in service.yml and is deployed.")

        else:
            print_error(f"Reindex failed: HTTP {response.status_code}")
            try:
                detail = response.json().get('detail', response.text)
                print_error(f"  {detail}")
            except Exception:
                pass

    except requests.exceptions.ConnectionError:
        print_error(f"Cannot connect to platform at {base_url}")
        print_info("Make sure platform is running")

    except requests.exceptions.Timeout:
        print_error("Reindex timed out (>5 minutes)")
        print_info("This can happen with very large collections. Try reindexing one collection at a time with --collection.")

    except Exception as e:
        print_error(f"Error: {e}")
