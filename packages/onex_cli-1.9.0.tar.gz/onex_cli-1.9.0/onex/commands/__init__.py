# OneXEOS CLI Commands
