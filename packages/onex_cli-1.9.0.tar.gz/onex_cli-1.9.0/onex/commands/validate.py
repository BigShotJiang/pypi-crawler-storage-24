"""
Validate command - Validate service.yml schema without deploying
"""

import click
from pathlib import Path
from onex.utils import (
    validate_service_structure,
    validate_service_schema,
    print_success,
    print_error,
    print_warning,
    print_info,
)


@click.command()
@click.option('--service-dir', type=click.Path(exists=True), default='.', help='Service directory path')
@click.option('--verbose', is_flag=True, help='Show detailed validation information')
def validate(service_dir, verbose):
    """Validate service.yml schema without deploying"""

    service_path = Path(service_dir).resolve()

    click.echo(f"🔍 Validating service at {service_path}")
    click.echo()

    # Step 1: Validate service structure
    click.echo("📋 Checking service structure...")
    structure_errors = validate_service_structure(service_path)

    if structure_errors:
        print_error("Service structure validation failed:")
        for error in structure_errors:
            click.echo(f"  - {error}")
        click.echo()
        print_info("Ensure your service has the correct file structure:")
        print_info("  - service.yml (required)")
        print_info("  - src/ directory (required)")
        print_info("  - __init__.py files (required)")
        return

    print_success("Service structure valid")

    # Step 2: Validate service.yml schema
    click.echo("\n📋 Validating service configuration schema...")
    is_valid, errors, warnings = validate_service_schema(service_path)

    if not is_valid:
        print_error("Service configuration validation failed:")
        click.echo()
        for error in errors:
            click.echo(f"  ❌ {error}")
        click.echo()
        print_info("Fix the errors above and run validation again")
        print_info("See: docs/SERVICE_YML_SPECIFICATION.md for schema reference")
        return

    print_success("Service configuration schema valid")

    # Step 3: Validate seed data files
    click.echo("\n📋 Checking seed data files...")
    seed_warnings = _validate_seed_files(service_path)
    if seed_warnings:
        for sw in seed_warnings:
            if sw.startswith("ERROR:"):
                print_error(sw[6:].strip())
                is_valid = False
            else:
                warnings.append(sw)
    else:
        print_success("No seed data issues found")

    # Display warnings (non-fatal)
    if warnings:
        click.echo()
        click.echo("⚠️  Configuration warnings:")
        for warning in warnings:
            click.echo(f"  - {warning}")
        click.echo()
        print_info("These are recommendations, not errors. Your service will still deploy.")

    # Display verbose information
    if verbose and is_valid:
        from onex.schema.validator import load_and_validate_service_yml

        click.echo()
        click.echo("=" * 60)
        click.echo("📊 Service Configuration Details")
        click.echo("=" * 60)

        try:
            descriptor = load_and_validate_service_yml(str(service_path / 'service.yml'))

            click.echo(f"\n🏷️  Service Identity:")
            click.echo(f"   Name:        {descriptor.name}")
            click.echo(f"   Version:     {descriptor.version}")
            if descriptor.description:
                click.echo(f"   Description: {descriptor.description}")

            click.echo(f"\n🚀 Deployment Configuration:")
            click.echo(f"   Mode:        {descriptor.deployment.mode}")

            if descriptor.deployment.mode == "container" and descriptor.deployment.container:
                container = descriptor.deployment.container
                click.echo(f"   Replicas:    {container.replicas}")
                if container.resources:
                    if container.resources.cpu:
                        click.echo(f"   CPU:         {container.resources.cpu}")
                    if container.resources.memory:
                        click.echo(f"   Memory:      {container.resources.memory}")

            if descriptor.routes:
                click.echo(f"\n🔗 Routes ({len(descriptor.routes)}):")
                for route in descriptor.routes:
                    desc = f" - {route.description}" if route.description else ""
                    click.echo(f"   {route.method:7} {route.path}{desc}")

            if descriptor.dependencies:
                if descriptor.dependencies.services:
                    click.echo(f"\n📦 Dependencies:")
                    for dep in descriptor.dependencies.services:
                        click.echo(f"   - {dep}")
                if descriptor.dependencies.optional:
                    click.echo(f"\n📦 Optional Dependencies:")
                    for dep in descriptor.dependencies.optional:
                        click.echo(f"   - {dep}")

            if descriptor.requirements:
                click.echo(f"\n🐍 Python Requirements:")
                for req in descriptor.requirements:
                    click.echo(f"   - {req}")

        except Exception as e:
            print_warning(f"Could not load detailed info: {e}")

    # Summary
    click.echo()
    click.echo("=" * 60)
    if is_valid and not warnings:
        print_success("✅ All checks passed! Service is ready to deploy.")
    elif is_valid and warnings:
        click.echo("✅ Validation passed with warnings.")
        print_info("Review warnings above before deploying.")
    click.echo("=" * 60)

    if is_valid:
        click.echo()
        print_info("To deploy this service, run:")
        click.echo("  onex deploy")
        click.echo("  onex deploy --env dev")
        click.echo("  onex deploy --env staging")


def _validate_seed_files(service_path: Path) -> list:
    """Validate that seed data files referenced in service.yml exist and are valid JSON arrays."""
    import json
    import yaml

    issues = []
    service_yml = service_path / 'service.yml'
    if not service_yml.exists():
        return issues

    try:
        with open(service_yml, 'r') as f:
            config = yaml.safe_load(f)
    except Exception:
        return issues

    resources = config.get('resources', {})
    if not resources:
        return issues

    # Normalize resources to handle both 'collections' and 'databases' formats
    from onex.schema.service_descriptor import normalize_mongodb_resources
    try:
        resources = normalize_mongodb_resources(resources)
    except ValueError:
        pass  # Duplicate name errors are caught by schema validation

    databases = resources.get('databases', [])
    for db in databases:
        if not isinstance(db, dict):
            continue
        for coll in db.get('collections', []):
            if not isinstance(coll, dict):
                continue
            seed = coll.get('seed')
            if not seed:
                continue

            seed_file = seed.get('file', '')
            required = seed.get('required', False)
            coll_name = coll.get('name', '?')
            full_path = service_path / seed_file

            if not full_path.exists():
                prefix = "ERROR:" if required else ""
                issues.append(f"{prefix} Seed file not found for '{coll_name}': {seed_file}")
                continue

            try:
                with open(full_path, 'r') as f:
                    data = json.load(f)
                if not isinstance(data, list):
                    prefix = "ERROR:" if required else ""
                    issues.append(f"{prefix} Seed file for '{coll_name}' must be a JSON array: {seed_file}")
                elif len(data) == 0:
                    issues.append(f"Seed file for '{coll_name}' is empty: {seed_file}")
            except json.JSONDecodeError as e:
                prefix = "ERROR:" if required else ""
                issues.append(f"{prefix} Invalid JSON in seed file for '{coll_name}': {seed_file} ({e})")

    return issues
