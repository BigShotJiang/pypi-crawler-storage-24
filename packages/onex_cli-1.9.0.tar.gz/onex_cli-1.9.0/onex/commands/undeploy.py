"""
Undeploy command - Remove a deployed service from the OneXEOS Platform
"""

import click
import requests
from onex.config import get_config, get_access_token, get_active_environment
from onex.utils import print_success, print_error, print_info, print_warning
from onex.utils.auth import auto_refresh_token


@click.command()
@click.argument('service_name')
@click.option('--env', default=None, help='Environment (local/dev/staging/prod, defaults to active)')
@click.option('--platform-url', help='Override platform URL')
@click.option('--force', is_flag=True, help='Skip confirmation prompt')
@click.option('--purge-data', is_flag=True, help='Also drop MongoDB collections provisioned by this service')
@click.option('--keep-versions', is_flag=True, help='Keep .versions/ directory for potential rollback')
def undeploy(service_name, env, platform_url, force, purge_data, keep_versions):
    """Remove a deployed service from the platform.

    Removes all routes, invokes, triggers, runtime state, and service files.
    Does NOT drop MongoDB data unless --purge-data is specified.

    Examples:

        onex undeploy setting --env dev

        onex undeploy old-service --purge-data --force
    """
    # Use active environment if not specified
    if env is None:
        env = get_active_environment()
        print_info(f"Using active environment: {env}")

    config = get_config()
    platform_base_url = platform_url or config.get_platform_url(env)

    # Get access token
    access_token = get_access_token(env)
    headers = {}
    if access_token:
        headers['Authorization'] = f'Bearer {access_token}'

    # Pre-flight: check service status
    click.echo(f"🔍 Checking service '{service_name}' on {env}...")
    click.echo()

    try:
        status_url = f"{platform_base_url}/_internal/services/{service_name}"
        status_resp = requests.get(status_url, headers=headers, timeout=10)

        if status_resp.status_code == 200:
            data = status_resp.json()
            route_count = len(data.get('routes', data.get('apis', [])))
            version = data.get('version', 'N/A')
            click.echo(f"   Service: {service_name}")
            click.echo(f"   Version: {version}")
            click.echo(f"   Routes:  {route_count}")
            click.echo()
        elif status_resp.status_code == 404:
            print_warning(f"Service '{service_name}' not found in runtime — "
                          "will still attempt cleanup of stale Redis/registry entries")
            click.echo()
        elif status_resp.status_code == 401:
            # Try auto-refresh
            new_token = auto_refresh_token(env)
            if new_token:
                headers['Authorization'] = f'Bearer {new_token}'
            else:
                print_error("Authentication required")
                print_info(f"Please login: onex login --env {env}")
                return
    except requests.exceptions.ConnectionError:
        print_error(f"Cannot connect to platform at {platform_base_url}")
        print_info("Make sure platform is running and you're connected to VPN")
        return
    except Exception as e:
        print_warning(f"Could not check service status: {e}")
        click.echo()

    # Confirmation
    if not force:
        msg = f"Undeploy '{service_name}' from {env}?"
        if purge_data:
            msg += " (INCLUDING MongoDB data — this is irreversible!)"
        if not click.confirm(msg):
            print_info("Cancelled")
            return

    if purge_data and not force:
        if not click.confirm(
            f"⚠️  CONFIRM: Drop all MongoDB collections provisioned by '{service_name}'? This cannot be undone."
        ):
            print_info("Cancelled data purge — undeploying without --purge-data")
            purge_data = False

    # Send undeploy request
    click.echo()
    click.echo(f"🗑️  Undeploying '{service_name}'...")

    undeploy_url = f"{platform_base_url}/_internal/undeploy/{service_name}"
    params = {
        'purge_data': str(purge_data).lower(),
        'keep_versions': str(keep_versions).lower(),
    }

    try:
        response = requests.delete(
            undeploy_url,
            headers=headers,
            params=params,
            timeout=120,
        )

        if response.status_code == 200:
            report = response.json()
            click.echo()
            print_success(f"Service '{service_name}' undeployed successfully")
            click.echo()

            # Display cleanup report
            click.echo("📋 Cleanup Report:")
            click.echo(f"   Routes removed:    {report.get('routes_removed', 0)}")
            click.echo(f"   Invokes removed:   {report.get('invokes_removed', 0)}")
            click.echo(f"   Auth keys removed: {report.get('auth_keys_removed', 0)}")
            click.echo(f"   Runtime unloaded:  {'yes' if report.get('runtime_unloaded') else 'no'}")
            click.echo(f"   Registry removed:  {'yes' if report.get('registry_removed') else 'no'}")
            click.echo(f"   Files removed:     {'yes' if report.get('files_removed') else 'no'}")

            triggers = report.get('triggers_removed', {})
            if isinstance(triggers, dict):
                total_triggers = sum(triggers.values())
                if total_triggers > 0:
                    click.echo(f"   Triggers removed:  {total_triggers} "
                               f"(schedules={triggers.get('schedules', 0)}, "
                               f"events={triggers.get('events', 0)}, "
                               f"streams={triggers.get('streams', 0)}, "
                               f"s3={triggers.get('s3', 0)})")

            if purge_data:
                click.echo(f"   Data purged:       {'yes' if report.get('data_purged') else 'no'}")

            duration = report.get('duration_ms', 0)
            click.echo()
            click.echo(f"   Duration: {duration}ms")

        elif response.status_code == 401:
            # Try auto-refresh
            new_token = auto_refresh_token(env)
            if new_token:
                headers['Authorization'] = f'Bearer {new_token}'
                # Retry
                response = requests.delete(undeploy_url, headers=headers, params=params, timeout=120)
                if response.status_code == 200:
                    print_success(f"Service '{service_name}' undeployed successfully")
                    return
            print_error("Authentication failed")
            print_info(f"Please login: onex login --env {env}")

        elif response.status_code == 404:
            print_error(f"Service '{service_name}' not found")

        else:
            error_detail = response.text
            try:
                error_json = response.json()
                error_detail = error_json.get('detail', response.text)
            except Exception:
                pass
            print_error(f"Undeploy failed ({response.status_code}): {error_detail}")

    except requests.exceptions.ConnectionError:
        print_error(f"Cannot connect to platform at {platform_base_url}")
        print_info("Make sure platform is running")

    except requests.exceptions.Timeout:
        print_error("Request timed out (120s)")
        print_info("The undeploy may still be in progress on the server")

    except Exception as e:
        print_error(f"Undeploy error: {e}")
