"""
Initialize OneXEOS development environment

This command handles:
- VPN setup (optional)
- Platform login
- Environment configuration (.env generation)
- Connectivity verification
"""

import click
import os
from pathlib import Path
from onex.utils import print_success, print_info, print_error, print_warning
from onex.commands.login import _transform_credentials_for_vpn


@click.command()
@click.option('--skip-vpn', is_flag=True, help='Skip VPN setup')
@click.option('--config-file', type=click.Path(exists=True), help='VPN config file path')
@click.option('--update', is_flag=True, help='Update existing environment with new credentials from VPN config')
def init(skip_vpn, config_file, update):
    """Initialize OneXEOS development environment (VPN + login + .env)

    Use --update to refresh credentials from an updated VPN config file.
    """

    click.echo("========================================")
    click.echo("  OneXEOS Development Environment Setup")
    click.echo("========================================")
    click.echo()

    vpn_info = None

    # =========================================================================
    # Step 1: VPN Setup (Optional)
    # =========================================================================

    if skip_vpn:
        # User skipped VPN setup, but we should still detect if they're already connected
        # (e.g., they imported config via WireGuard GUI on Windows)
        from onex.vpn.setup_vpn import detect_current_vpn, list_configured_vpns
        from onex.vpn.platform_detector import get_config_directory, detect_environment_from_ip, get_gateway_ip, get_platform_url
        from onex.vpn.wireguard_manager import parse_config

        # If user provided config file, use it directly (especially useful for Windows)
        if config_file:
            print_info(f"ℹ️  Reading VPN config from: {config_file}")
            click.echo()

            try:
                # Parse config to get credentials and environment info
                config = parse_config(config_file)

                if config.get('vpn_ip'):
                    vpn_ip = config['vpn_ip']
                    gateway_ip = get_gateway_ip(vpn_ip)
                    environment = detect_environment_from_ip(vpn_ip)
                    platform_url = get_platform_url(gateway_ip)

                    vpn_info = {
                        'interface': 'manual',  # Not actually connected, using config file
                        'vpn_ip': vpn_ip,
                        'gateway_ip': gateway_ip,
                        'environment': environment,
                        'platform_url': platform_url,
                        'connected': False,  # Not connected via CLI
                        'platform_credentials': config.get('platform_credentials')
                    }

                    print_success(f"✅ Extracted environment info from VPN config")
                    print_info(f"   Environment:  {environment.upper()}")
                    print_info(f"   Gateway:      {gateway_ip}")
                    print_info(f"   Platform URL: {platform_url}")

                    if config.get('platform_credentials'):
                        print_success("✅ Found embedded credentials in VPN config")
                        print_info(f"   Email: {config['platform_credentials']['email']}")

                    click.echo()

            except Exception as e:
                print_error(f"❌ Could not parse VPN config: {str(e)}")
                print_info("   Continuing with manual environment selection...")
                click.echo()

        else:
            # Try to detect active VPN connection
            current_vpn = detect_current_vpn()

            if current_vpn:
                print_success(f"✅ Detected active VPN connection: {current_vpn}")
                click.echo()

                # Try to find and parse the config file to extract credentials
                config_dir = Path(get_config_directory())
                config_file_path = config_dir / f"{current_vpn}.conf"

                if config_file_path.exists():
                    try:
                        # Parse config to get credentials and environment info
                        config = parse_config(str(config_file_path))

                        if config.get('vpn_ip'):
                            vpn_ip = config['vpn_ip']
                            gateway_ip = get_gateway_ip(vpn_ip)
                            environment = detect_environment_from_ip(vpn_ip)
                            platform_url = get_platform_url(gateway_ip)

                            vpn_info = {
                                'interface': current_vpn,
                                'vpn_ip': vpn_ip,
                                'gateway_ip': gateway_ip,
                                'environment': environment,
                                'platform_url': platform_url,
                                'connected': True,
                                'platform_credentials': config.get('platform_credentials')  # May be None
                            }

                            print_success(f"✅ Extracted environment info from VPN config")
                            print_info(f"   Environment:  {environment.upper()}")
                            print_info(f"   Gateway:      {gateway_ip}")
                            print_info(f"   Platform URL: {platform_url}")

                            if config.get('platform_credentials'):
                                print_success("✅ Found embedded credentials in VPN config")
                                print_info(f"   Email: {config['platform_credentials']['email']}")

                            click.echo()

                    except Exception as e:
                        print_warning(f"⚠️  Could not parse VPN config: {str(e)}")
                        print_info("   Continuing with manual environment selection...")
                        click.echo()
                else:
                    print_warning(f"⚠️  VPN config file not found: {config_file_path}")
                    print_info("   Continuing with manual environment selection...")
                    click.echo()
            else:
                # No active VPN detected - check for WireGuard GUI configs on Windows
                from onex.vpn.platform_detector import detect_os
                from onex.vpn.wireguard_manager import find_wireguard_gui_configs

                os_type = detect_os()

                if os_type == 'windows':
                    # Try to find DPAPI configs from WireGuard GUI
                    dpapi_configs = find_wireguard_gui_configs()

                    if dpapi_configs:
                        print_info(f"ℹ️  Found {len(dpapi_configs)} WireGuard GUI config(s)")
                        click.echo()

                        if len(dpapi_configs) == 1:
                            # Only one config - use it automatically
                            dpapi_config_path = dpapi_configs[0]
                            config_name = os.path.basename(dpapi_config_path).replace('.conf.dpapi', '')

                            print_info(f"   Using: {config_name}")
                            print_info(f"   Path:  {dpapi_config_path}")
                            click.echo()

                            try:
                                # Parse DPAPI config (will auto-decrypt)
                                config = parse_config(dpapi_config_path)

                                if config.get('vpn_ip'):
                                    vpn_ip = config['vpn_ip']
                                    gateway_ip = get_gateway_ip(vpn_ip)
                                    environment = detect_environment_from_ip(vpn_ip)
                                    platform_url = get_platform_url(gateway_ip)

                                    vpn_info = {
                                        'interface': config_name,
                                        'vpn_ip': vpn_ip,
                                        'gateway_ip': gateway_ip,
                                        'environment': environment,
                                        'platform_url': platform_url,
                                        'connected': False,  # Not actively connected
                                        'platform_credentials': config.get('platform_credentials')
                                    }

                                    print_success(f"✅ Decrypted and extracted environment info from WireGuard GUI config")
                                    print_info(f"   Environment:  {environment.upper()}")
                                    print_info(f"   Gateway:      {gateway_ip}")
                                    print_info(f"   Platform URL: {platform_url}")

                                    if config.get('platform_credentials'):
                                        print_success("✅ Found embedded credentials in config")
                                        print_info(f"   Email: {config['platform_credentials']['email']}")

                                    click.echo()

                            except Exception as e:
                                print_error(f"❌ Could not decrypt WireGuard GUI config: {str(e)}")
                                click.echo()
                                print_info("💡 Solution: Export config from WireGuard GUI")
                                print_info("   1. Open WireGuard application")
                                print_info("   2. Select the tunnel (son)")
                                print_info("   3. Click 'Edit' button")
                                print_info("   4. Copy ALL text from the editor")
                                print_info("   5. Save to a file in your project folder:")
                                print_info(f"      Example: {os.getcwd()}\\son.conf")
                                click.echo()
                                print_info("   Then run:")
                                print_info(f"      onex init --skip-vpn --config-file \"{os.getcwd()}\\son.conf\"")
                                click.echo()
                                print_info("   Or proceeding with manual configuration...")
                                click.echo()

                        else:
                            # Multiple configs - let user choose with --config-file
                            print_info("   Found multiple WireGuard GUI configs:")
                            for dpapi_path in dpapi_configs:
                                config_name = os.path.basename(dpapi_path).replace('.conf.dpapi', '')
                                print_info(f"     - {config_name}")
                            click.echo()
                            print_info("   To use a specific config, run:")
                            print_info(f'   onex init --skip-vpn --config-file "C:\\\\Program Files\\\\WireGuard\\\\Data\\\\Configurations\\\\<name>.conf.dpapi"')
                            print_info("   Or proceeding with manual configuration...")
                            click.echo()
                    else:
                        print_info("ℹ️  No active VPN connection detected")
                        print_info("   No WireGuard GUI configs found")
                        print_info("   Proceeding with manual configuration...")
                        click.echo()
                else:
                    print_info("ℹ️  No active VPN connection detected")
                    print_info("   Proceeding with manual configuration...")
                    click.echo()

    elif not skip_vpn:
        click.echo("📡 VPN Setup")
        click.echo()

        # Check if already connected to VPN
        from onex.vpn.setup_vpn import detect_current_vpn
        current_vpn = detect_current_vpn()

        if current_vpn:
            print_success(f"✅ Already connected to VPN: {current_vpn}")
            click.echo()

            # Get VPN info
            from onex.vpn import get_status
            from onex.vpn.platform_detector import detect_environment_from_ip, get_gateway_ip, get_platform_url

            status = get_status(current_vpn)
            if status:
                # Try to extract VPN IP from interface
                # This is a simplified version - might need enhancement
                vpn_ip = "10.0.0.100"  # Default, should be extracted properly
                gateway_ip = get_gateway_ip(vpn_ip)
                environment = detect_environment_from_ip(vpn_ip)
                platform_url = get_platform_url(gateway_ip)

                vpn_info = {
                    'interface': current_vpn,
                    'gateway_ip': gateway_ip,
                    'environment': environment,
                    'platform_url': platform_url,
                    'connected': True
                }

        else:
            # Prompt for VPN config file
            has_vpn_config = click.confirm("Do you have a VPN config file?", default=True)

            if has_vpn_config:
                if not config_file:
                    config_file = click.prompt(
                        "VPN config file path",
                        type=click.Path(exists=True),
                        default="~/Downloads/alice-dev.conf"
                    )

                click.echo()
                print_info("🔧 Setting up VPN...")
                click.echo()

                try:
                    from onex.vpn import setup_vpn
                    from onex.vpn.wireguard_manager import WireGuardError, parse_config

                    vpn_info = setup_vpn(config_file, auto_connect=True)

                    print_success(f"✅ VPN configured: {vpn_info['interface']}")
                    print_info(f"   Environment:  {vpn_info['environment'].upper()}")
                    print_info(f"   Gateway:      {vpn_info['gateway_ip']}")
                    print_info(f"   Platform URL: {vpn_info['platform_url']}")
                    click.echo()

                    if vpn_info['connected']:
                        print_success("✅ VPN connected")
                    else:
                        print_warning("⚠️  VPN configured but not connected")

                        # Show connection error if available
                        if vpn_info.get('connection_error'):
                            print_info(f"   Error: {vpn_info['connection_error']}")

                        # Offer retry
                        click.echo()
                        if click.confirm("Try connecting to VPN now?", default=True):
                            from onex.vpn import connect
                            from onex.vpn.wireguard_manager import WireGuardError

                            max_retries = 2
                            for attempt in range(1, max_retries + 1):
                                try:
                                    print_info(f"🔄 Connection attempt {attempt}/{max_retries}...")
                                    connect(vpn_info['interface'])
                                    print_success("✅ VPN connected successfully!")
                                    vpn_info['connected'] = True
                                    break
                                except WireGuardError as e:
                                    if attempt < max_retries:
                                        print_warning(f"⚠️  Attempt {attempt} failed: {str(e)}")
                                        click.echo()
                                        if not click.confirm("Retry connection?", default=True):
                                            break
                                    else:
                                        print_error(f"❌ All connection attempts failed: {str(e)}")
                                        click.echo()
                                        print_info("Manual steps to connect:")
                                        print_info(f"  sudo wg-quick up {vpn_info['interface']}")
                                        print_info(f"  ping {vpn_info['gateway_ip']}")
                                        click.echo()

                            if not vpn_info['connected']:
                                print_info("You can:")
                                print_info("  • Connect manually and run 'onex init' again")
                                print_info(f"  • Run: onex vpn connect {vpn_info['environment']}")
                        else:
                            print_info(f"   Run: onex vpn connect {vpn_info['environment']}")

                    # Parse VPN config to check for embedded credentials
                    config_data = parse_config(config_file)
                    if config_data.get('platform_credentials'):
                        vpn_info['platform_credentials'] = config_data['platform_credentials']
                        print_success("✅ Platform credentials found in VPN config")
                        print_info(f"   Email: {config_data['platform_credentials']['email']}")

                    click.echo()

                except WireGuardError as e:
                    print_error(f"VPN setup failed: {str(e)}")
                    click.echo()
                    print_info("You can:")
                    print_info("  • Fix the issue and run 'onex init' again")
                    print_info("  • Setup VPN manually and run 'onex init --skip-vpn'")
                    print_info("  • Continue without VPN (local development only)")
                    click.echo()

                    if not click.confirm("Continue without VPN?", default=False):
                        return 1

            else:
                print_info("Skipping VPN setup (local development mode)")
                print_info("You can setup VPN later with: onex vpn setup <config-file>")
                click.echo()

    # =========================================================================
    # Step 2: Platform Login
    # =========================================================================

    click.echo("🔐 Platform Login")
    click.echo()

    # Determine environment
    if vpn_info and vpn_info.get('environment'):
        environment = vpn_info['environment']
        platform_url = vpn_info['platform_url']
        print_info(f"Detected environment: {environment.upper()}")
        click.echo()
    else:
        # Ask user which environment
        environment = click.prompt(
            "Which environment?",
            type=click.Choice(['local', 'dev', 'staging', 'prod'], case_sensitive=False),
            default='local'
        )
        environment = environment.lower()

        # Set platform URL based on environment
        # NOTE: These are EXAMPLE URLs for default OneXEOS platform setup.
        # Customize these IPs in your VPN/platform configuration if different.
        # You can also override with PLATFORM_URL environment variable.
        env_urls = {
            'local': 'http://localhost:8000',
            'dev': 'http://10.0.0.1:8000',      # Example: customize for your dev server
            'staging': 'http://10.0.1.1:8000',  # Example: customize for your staging server
            'prod': 'http://10.0.2.1:8000'      # Example: customize for your prod server
        }
        platform_url = env_urls.get(environment, 'http://localhost:8000')
        click.echo()

    # Login based on environment
    if environment == 'local':
        print_info("Logging into local platform...")
        print_info(f"Platform URL: {platform_url}")
        click.echo()

        try:
            import requests
            from onex.commands.login import load_environments, save_environments, set_active_environment, auto_generate_env
            from datetime import datetime

            # Check if platform is running
            response = requests.get(f"{platform_url}/health", timeout=5)
            if response.status_code != 200:
                print_error("Platform health check failed")
                print_info("Make sure platform is running:")
                print_info("  Contact platform team for local platform setup")
                return 1

            print_success("✅ Platform is running")

            # Download environment configuration
            print_info("📥 Downloading environment credentials...")
            response = requests.get(f"{platform_url}/_internal/env-config/local", timeout=10)

            if response.status_code != 200:
                print_error(f"Failed to get environment config: HTTP {response.status_code}")
                return 1

            credentials = response.json()

            # Load existing environments
            envs = load_environments()

            # Store local environment
            envs['local'] = {
                'platform_url': platform_url,
                'credentials': credentials,
                'last_updated': datetime.utcnow().isoformat() + 'Z'
            }

            save_environments(envs)
            set_active_environment('local')

            print_success("✅ Local environment configured")
            print_success("✅ Set as active environment")
            click.echo()

            # Auto-generate .env file
            if auto_generate_env('local', credentials, platform_url):
                print_success("✅ Generated .env file in repository root")
            else:
                print_warning("⚠️  Not in a service repository")
                print_info("Run 'onex env sync' when in service repo to generate .env")

        except requests.exceptions.ConnectionError:
            print_error(f"Could not connect to {platform_url}")
            print_info("Make sure:")
            print_info("  1. Platform is running")
            print_info("  2. Contact platform team for setup help")
            return 1
        except Exception as e:
            print_error(f"Setup failed: {str(e)}")
            import traceback
            traceback.print_exc()
            return 1

    else:
        # Dev/staging/prod - require email/password (or use embedded credentials)
        print_info(f"Logging into {environment.upper()} platform...")
        print_info(f"Platform URL: {platform_url}")
        click.echo()

        # Check if we have embedded credentials from VPN config
        if vpn_info and vpn_info.get('platform_credentials'):
            creds = vpn_info['platform_credentials']
            email = creds['email']
            password = creds['password']
            print_success("✅ Using credentials from VPN config")
            print_info(f"   Email: {email}")
            click.echo()
        else:
            # Manual credential entry
            email = click.prompt("Email")
            password = click.prompt("Password", hide_input=True)

            if not password:
                print_error("Password cannot be empty")
                return 1

            click.echo()

        print_info("🔑 Authenticating...")

        try:
            import requests
            from onex.commands.login import load_environments, save_environments, set_active_environment, auto_generate_env
            from datetime import datetime, timedelta

            # Determine auth URL
            # Prefer public auth URL (works without VPN)
            auth_url = platform_url
            if vpn_info and vpn_info.get('platform_credentials'):
                creds = vpn_info['platform_credentials']
                # Use public auth URL if available (no VPN required)
                if creds.get('public_auth_url'):
                    auth_url = creds['public_auth_url']
                    print_info(f"Using public auth: {auth_url}")
                else:
                    auth_url = creds.get('auth_url', platform_url)
                    print_info(f"Using private auth: {auth_url}")

            # Login to auth service
            response = requests.post(
                f"{auth_url}/auth/login",
                json={
                    "email": email,
                    "password": password
                },
                timeout=10
            )

            if response.status_code != 200:
                try:
                    error_detail = response.json().get('detail', 'Unknown error')
                except:
                    error_detail = response.text

                print_error(f"Login failed: {error_detail}")
                return 1

            # Parse login response
            login_data = response.json()
            access_token = login_data.get('AccessToken') or login_data.get('access_token')

            if not access_token:
                print_error("Invalid response from server (no access token)")
                return 1

            print_success("✅ Login successful")

            # Download environment credentials (requires VPN)
            print_info("📥 Downloading environment credentials...")
            click.echo()

            # Use private platform URL (gateway via VPN)
            download_url = platform_url
            if vpn_info and vpn_info.get('platform_credentials'):
                download_url = vpn_info['platform_credentials']['platform_url']

            try:
                response = requests.get(
                    f"{download_url}/_internal/env-config/{environment}",
                    headers={'Authorization': f'Bearer {access_token}'},
                    timeout=10
                )

                if response.status_code != 200:
                    print_error(f"Failed to get environment config: HTTP {response.status_code}")

                    # Check if this is a VPN connection issue
                    if vpn_info and not vpn_info.get('connected', False):
                        click.echo()
                        print_warning("⚠️  This may be a VPN connection issue")
                        print_info(f"   Gateway URL: {download_url}")
                        click.echo()
                        print_info("💡 Solution:")
                        print_info("   1. Ensure WireGuard is connected:")
                        print_info("      • Open WireGuard application")
                        print_info("      • Find your tunnel (e.g., 'son')")
                        print_info("      • Click 'Activate' if not already active")
                        click.echo()
                        print_info("   2. Verify connectivity:")
                        print_info(f"      ping {vpn_info.get('gateway_ip', '10.0.0.1')}")
                        click.echo()
                        print_info("   3. Try again:")
                        print_info(f"      onex init --skip-vpn --config-file \"{config_file}\"")
                        click.echo()
                    else:
                        print_info("Your token may not have permission to access this environment")

                    return 1

            except requests.exceptions.ConnectionError:
                print_error("❌ Cannot connect to platform")
                click.echo()
                print_warning("⚠️  VPN connection required")
                print_info(f"   Gateway URL: {download_url}")
                click.echo()
                print_info("💡 Solution:")
                print_info("   1. Connect to VPN using WireGuard GUI:")
                print_info("      • Open WireGuard application")
                print_info("      • Find your tunnel (e.g., 'son')")
                print_info("      • Click 'Activate'")
                click.echo()
                print_info("   2. Verify connectivity:")
                if vpn_info:
                    print_info(f"      ping {vpn_info.get('gateway_ip', '10.0.0.1')}")
                click.echo()
                print_info("   3. Try again:")
                if config_file:
                    print_info(f"      onex init --skip-vpn --config-file \"{config_file}\"")
                else:
                    print_info("      onex init --skip-vpn")
                click.echo()
                return 1

            except requests.exceptions.Timeout:
                print_error("❌ Connection timeout")
                click.echo()
                print_warning("⚠️  Gateway not responding")
                print_info(f"   Gateway URL: {download_url}")
                click.echo()
                print_info("💡 Check VPN connection and try again")
                click.echo()
                return 1

            credentials = response.json()
            print_success("✅ Credentials downloaded")

            # Calculate token expiration
            expires_in = login_data.get('ExpiresIn', 3600)
            expires_at = datetime.utcnow() + timedelta(seconds=expires_in)

            # Load existing environments
            envs = load_environments()

            # Encrypt credentials for auto-refresh (if from VPN config with embedded creds)
            encrypted_credentials = None
            if vpn_info and vpn_info.get('platform_credentials'):
                try:
                    from onex.utils.crypto import encrypt_credentials
                    encrypted_credentials = encrypt_credentials(email, password)
                    print_success("✅ Auto-refresh enabled (credentials encrypted)")
                except Exception as e:
                    print_warning(f"⚠️  Could not enable auto-refresh: {e}")

            # Store environment configuration (with VPN config path if available)
            # Transform Docker hostnames to VPN IPs before storing
            envs[environment] = {
                'platform_url': platform_url,
                'access_token': access_token,
                'token_type': login_data.get('TokenType', 'bearer'),
                'expires_in': expires_in,
                'vpn_config_path': vpn_info.get('config_path') if vpn_info else None,
                'encrypted_credentials': encrypted_credentials,  # For auto-token refresh
                'expires_at': expires_at.isoformat() + 'Z',
                'user': {
                    'email': email,
                    'role': 'developer',
                    'permissions': []
                },
                'credentials': _transform_credentials_for_vpn(credentials, platform_url),
                'last_updated': datetime.utcnow().isoformat() + 'Z'
            }

            save_environments(envs)
            set_active_environment(environment)

            print_success("✅ Credentials stored securely")
            click.echo()
            print_info(f"Logged in as: {email}")
            print_info(f"Environment: {environment}")
            print_success(f"✅ Set as active environment")
            click.echo()

            # Auto-generate .env file
            if auto_generate_env(environment, credentials, platform_url):
                print_success("✅ Generated .env file in repository root")
            else:
                print_warning("⚠️  Not in a service repository")
                print_info("Run 'onex env sync' when in service repo to generate .env")

        except requests.exceptions.ConnectionError:
            print_error(f"Could not connect to {platform_url}")
            print_info("Make sure:")
            print_info("  1. You are connected to VPN")
            print_info("  2. The platform is running")
            return 1
        except Exception as e:
            print_error(f"Login failed: {str(e)}")
            import traceback
            traceback.print_exc()
            return 1

    # =========================================================================
    # Step 3: Verify Setup
    # =========================================================================

    click.echo()
    click.echo("🔍 Verifying Setup")
    click.echo()

    # Test platform connectivity
    try:
        import requests
        response = requests.get(f"{platform_url}/health", timeout=5)

        if response.status_code == 200:
            print_success("✅ Platform gateway reachable")
        else:
            print_warning("⚠️  Platform gateway returned non-200 status")

    except:
        print_warning("⚠️  Platform gateway not reachable")

    # Check .env file
    env_file = Path.cwd() / '.env'
    if env_file.exists():
        print_success("✅ .env file exists")
    else:
        print_warning("⚠️  .env file not found (not in service repo?)")

    # =========================================================================
    # Success Summary
    # =========================================================================

    click.echo()
    click.echo("========================================")
    click.echo("  ✅ Setup Complete!")
    click.echo("========================================")
    click.echo()

    print_info("Your development environment is ready!")
    click.echo()

    print_info("Next steps:")
    print_info(f"  • onex debug --service <name>    Start debugging")
    print_info(f"  • onex deploy                    Deploy to {environment}")
    print_info(f"  • onex status                    Check service status")
    click.echo()

    if vpn_info and vpn_info.get('connected'):
        print_info("VPN connection:")
        print_info(f"  • onex vpn status                Check VPN status")
        print_info(f"  • onex vpn disconnect {environment}    Disconnect when done")
        click.echo()

    # =========================================================================
    # Step 4: MCP Setup (Optional but Recommended)
    # =========================================================================

    click.echo("🤖 AI Debugging Assistant (Claude Code Integration)")
    click.echo()

    # Check if MCP is installed
    try:
        import mcp
        mcp_installed = True
    except ImportError:
        mcp_installed = False

    if mcp_installed:
        # Check if already configured
        from onex.config import get_onex_dir
        config_dir = get_onex_dir()
        marker_file = config_dir / '.mcp_setup_done'

        if marker_file.exists():
            print_success("✅ MCP server already configured")
            print_info("   Ask Claude: 'Is my platform healthy?'")
        else:
            # Offer to set up MCP
            print_info("Enable Claude Code to debug your platform with natural language:")
            print_info('  • "Is my platform healthy?"')
            print_info('  • "Debug trace_id: abc123"')
            print_info('  • "Show email-service logs"')
            click.echo()

            if click.confirm("Configure MCP server for Claude Code?", default=True):
                try:
                    # Import and run MCP setup
                    from onex.commands.mcp import setup as mcp_setup_func
                    from click.testing import CliRunner
                    import click as click_module

                    # Run setup command programmatically
                    # CliRunner(mix_stderr=False) is only available in Click 8.0+
                    # For backward compatibility, always use safe default
                    runner = CliRunner()
                    result = runner.invoke(mcp_setup_func, catch_exceptions=False)

                    if result.exit_code == 0:
                        print_success("✅ MCP server configured")
                        print_info("   Restart Claude Code to activate")
                    else:
                        print_warning("⚠️  MCP setup encountered issues")
                        print_info("   Run manually: onex mcp setup")

                except Exception as e:
                    print_warning(f"⚠️  Could not auto-configure MCP: {e}")
                    print_info("   Run manually: onex mcp setup")
            else:
                print_info("You can set up MCP later with: onex mcp setup")

        click.echo()
    else:
        print_info("Install MCP support for Claude Code integration:")
        print_info("  pip install --upgrade 'onex-cli[mcp]'")
        print_info("  onex mcp setup")
        click.echo()
