"""
Debug command - Run service(s) locally with platform connection checks
"""

import click
import subprocess
import sys
import os
import requests
from pathlib import Path
from pymongo import MongoClient
import redis
from onex.utils import print_success, print_error, print_info, print_warning


def check_platform_health():
    """
    Check if platform services are healthy before starting runtime
    Returns: (bool, list of errors)
    """
    errors = []

    # Find repository root - should be where .env exists
    repo_root = Path.cwd()

    # Detect if we're in a service subdirectory
    if (repo_root / 'service.yml').exists() and 'services' in str(repo_root):
        # We're in services/auth/ or similar, go up to repo root
        repo_root = repo_root.parent.parent

    # Load environment variables from .env
    env_file = repo_root / '.env'
    if env_file.exists():
        with open(env_file) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#') and '=' in line:
                    key, value = line.split('=', 1)
                    os.environ.setdefault(key, value)

    click.echo("🔍 Checking platform services...")
    click.echo()

    # 1. Check MongoDB
    try:
        mongo_uri = os.getenv('MONGODB_URI', 'mongodb://localhost:27017')
        client = MongoClient(mongo_uri, serverSelectionTimeoutMS=3000)
        client.admin.command('ping')
        print_success("✅ MongoDB: Connected")
    except Exception as e:
        error_msg = f"❌ MongoDB: Not reachable ({str(e)})"
        print_error(error_msg)
        errors.append("MongoDB")

    # 2. Check Redis
    try:
        redis_host = os.getenv('REDIS_HOST', 'localhost')
        redis_port = int(os.getenv('REDIS_PORT', 6379))
        redis_password = os.getenv('REDIS_PASSWORD', None)

        r = redis.Redis(
            host=redis_host,
            port=redis_port,
            password=redis_password,
            socket_connect_timeout=3
        )
        r.ping()
        print_success("✅ Redis: Connected")
    except Exception as e:
        error_msg = f"❌ Redis: Not reachable ({str(e)})"
        print_error(error_msg)
        errors.append("Redis")

    # 3. Check NATS (optional but recommended)
    nats_host = os.getenv('NATS_HOST', 'localhost')
    nats_port = os.getenv('NATS_PORT', 4222)
    nats_url = f"http://{nats_host}:8222"  # NATS monitoring port

    try:
        response = requests.get(f"{nats_url}/varz", timeout=3)
        if response.status_code == 200:
            print_success("✅ NATS: Connected")
        else:
            print_warning("⚠️  NATS: Monitoring port accessible but returned non-200")
    except:
        print_warning("⚠️  NATS: Not reachable (optional)")

    # 4. Check Gateway (optional)
    gateway_url = os.getenv('GATEWAY_URL', 'http://localhost:8000')
    try:
        response = requests.get(f"{gateway_url}/health", timeout=3)
        if response.status_code == 200:
            print_success("✅ Gateway: Running")
        else:
            print_warning("⚠️  Gateway: Running but health check failed")
    except:
        print_warning("⚠️  Gateway: Not reachable (optional)")

    click.echo()

    if errors:
        print_error(f"Platform health check failed. Missing services: {', '.join(errors)}")
        print_info("Tip: Start the platform with: cd ../onexeos-platform-NEW && ./scripts/deploy-dev.sh start")
        return False, errors
    else:
        print_success("Platform is healthy!")
        click.echo()
        return True, []


@click.command()
@click.option('--service', help='Debug specific service only (e.g., auth, product)')
@click.option('--all', 'load_all', is_flag=True, help='Debug all services (integration testing)')
@click.option('--port', default=8001, help='Port to run runtime on')
@click.option('--skip-health-check', is_flag=True, help='Skip platform health check')
@click.option('--no-debugpy', is_flag=True, help='Disable debugpy (enabled by default)')
@click.option('--debugpy-wait', is_flag=True, help='Wait for debugger to attach before starting')
def debug(service, load_all, port, skip_health_check, no_debugpy, debugpy_wait):
    """Run service(s) locally with platform connection checks"""

    click.echo("🔧 Starting OneX Debug Runtime...")
    click.echo()

    # Check platform health
    if not skip_health_check:
        healthy, errors = check_platform_health()
        if not healthy:
            click.echo()
            print_error("Cannot start debug runtime without platform services.")
            print_info("Use --skip-health-check to bypass this check (not recommended)")
            return
    else:
        print_warning("⚠️  Skipping platform health check")
        click.echo()

    # Determine service loading mode
    if service:
        click.echo(f"🎯 Debug mode: Single service ({service})")
        os.environ['SERVICE_NAME'] = service
    elif load_all:
        click.echo("🌐 Debug mode: All services")
        os.environ.pop('SERVICE_NAME', None)  # Remove if set
    else:
        # Default: load all services
        click.echo("🌐 Debug mode: All services (default)")
        print_info("Tip: Use --service <name> to debug single service")
        os.environ.pop('SERVICE_NAME', None)

    click.echo(f"🌐 Port: {port}")
    click.echo()

    # Get repository root - should be where .env exists
    repo_root = Path.cwd()

    # Detect if we're in a service subdirectory
    if (repo_root / 'service.yml').exists() and 'services' in str(repo_root):
        # We're in services/auth/ or similar, go up to repo root
        repo_root = repo_root.parent.parent
        click.echo(f"📁 Detected service directory, using repo root: {repo_root}")
        click.echo()

    # Validate repo_root has .env
    if not (repo_root / '.env').exists():
        print_error(f".env not found in {repo_root}")
        print_info("Run: onex env sync")
        print_info(f"Current directory: {Path.cwd()}")
        return

    # Build Python path to include libs
    python_path_parts = [
        str(repo_root / 'libs' / 'python'),
        str(repo_root / 'libs' / 'nolicore'),
        str(repo_root / 'services'),
    ]
    python_path = ':'.join(python_path_parts)

    # Set environment variables
    env = {
        **os.environ,  # Include current environment (with .env loaded)
        'PYTHONPATH': python_path,
        'PORT': str(port),
        'PROJECT_ROOT': str(repo_root),
    }

    # Add debugpy environment variables (enabled by default)
    if not no_debugpy:
        env['ENABLE_DEBUGPY'] = 'true'
        env['DEBUGPY_PORT'] = '5678'
        if debugpy_wait:
            env['DEBUGPY_WAIT'] = 'true'
            click.echo("🐛 VS Code debugging enabled (wait mode) on port 5678")
        else:
            click.echo("🐛 VS Code debugging enabled on port 5678")
        click.echo("   Press F5 in VS Code to attach debugger")
        click.echo()
    else:
        if debugpy_wait:
            print_warning("⚠️  --debugpy-wait ignored when --no-debugpy is set")
            click.echo()

    print_info("Starting debug runtime...")
    print_info("Press CTRL+C to stop")
    click.echo()

    # Import and run the local runtime directly
    try:
        # Change to repo root
        os.chdir(repo_root)

        # Run using uvicorn pointing to onex.runtime.local_runtime:app
        cmd = [
            sys.executable,
            '-m',
            'uvicorn',
            'onex.runtime.local_runtime:app',
            '--host', '0.0.0.0',
            '--port', str(port),
        ]

        subprocess.run(cmd, env=env, check=True)

    except KeyboardInterrupt:
        click.echo()
        print_success("Debug runtime stopped")
    except FileNotFoundError as e:
        print_error(f"Failed to start: {e}")
        print_info("Make sure uvicorn is installed: pip install uvicorn[standard]")
    except Exception as e:
        print_error(f"Failed to start debug runtime: {e}")
        import traceback
        traceback.print_exc()
