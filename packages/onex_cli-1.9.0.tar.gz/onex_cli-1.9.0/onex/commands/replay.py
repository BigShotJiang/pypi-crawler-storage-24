"""
Replay command - Re-send a previously captured request by trace_id
"""

import click
import requests
import json
from onex.config import get_config, get_access_token
from onex.utils import print_success, print_error, print_info, print_warning
from onex.utils.auth import auto_refresh_token


@click.command()
@click.argument('trace_id')
@click.option('--env', default=None, help='Environment (local/dev/staging/prod, defaults to active)')
@click.option('--platform-url', help='Override platform URL')
def replay(trace_id, env, platform_url):
    """
    Replay a previously captured request by trace_id.

    Loads the original request snapshot from the platform and re-sends it,
    generating a new trace_id for the replayed request.

    Examples:
      onex replay abc123-def456-789
      onex replay abc123-def456-789 --env dev
    """
    from onex.config import get_active_environment

    if env is None:
        env = get_active_environment()

    config = get_config()
    base_url = platform_url or config.get_platform_url(env)

    access_token = get_access_token(env)
    if not access_token:
        print_error("Authentication required")
        print_info(f"Please login: onex login --env {env}")
        return

    print_info(f"Replaying trace: {trace_id}")

    try:
        response = requests.post(
            f"{base_url}/_internal/replay/{trace_id}",
            headers={'Authorization': f'Bearer {access_token}'},
            timeout=30,
        )

        if response.status_code == 200:
            data = response.json()
            method = data.get('method', '?')
            path = data.get('path', '?')
            status = data.get('status_code', '?')
            duration = data.get('duration_ms', '?')
            new_trace = data.get('new_trace_id', '?')

            print_success(f"Replayed: {method} {path}")
            print_info(f"  Status:    {status}")
            print_info(f"  Duration:  {duration}ms")
            print_info(f"  New trace: {new_trace}")
            print_info(f"\n  View trace: onex trace {new_trace} --env {env}")

        elif response.status_code == 404:
            print_error(f"No replay snapshot found for trace_id: {trace_id}")
            print_info("Snapshots expire after 24 hours.")

        elif response.status_code == 401:
            if env != "local":
                print_warning("Token expired, refreshing...")
                if auto_refresh_token(env, silent=False):
                    access_token = get_access_token(env)
                    response = requests.post(
                        f"{base_url}/_internal/replay/{trace_id}",
                        headers={'Authorization': f'Bearer {access_token}'},
                        timeout=30,
                    )
                    if response.status_code == 200:
                        data = response.json()
                        method = data.get('method', '?')
                        path = data.get('path', '?')
                        status = data.get('status_code', '?')
                        duration = data.get('duration_ms', '?')
                        new_trace = data.get('new_trace_id', '?')
                        print_success(f"Replayed: {method} {path}")
                        print_info(f"  Status:    {status}")
                        print_info(f"  Duration:  {duration}ms")
                        print_info(f"  New trace: {new_trace}")
                        print_info(f"\n  View trace: onex trace {new_trace} --env {env}")
                        return
            print_error("Authentication failed - could not refresh token")
            print_info(f"Please login again: onex login --env {env}")

        else:
            print_error(f"Replay failed: HTTP {response.status_code}")
            try:
                detail = response.json().get('detail', response.text)
                print_info(f"  Detail: {detail}")
            except Exception:
                pass

    except requests.ConnectionError:
        print_error(f"Cannot connect to platform at {base_url}")
        print_info("Make sure the platform is running.")
    except requests.Timeout:
        print_error(f"Request timed out connecting to {base_url}")
    except Exception as e:
        print_error(f"Error: {e}")
