"""
VPN management commands
"""

import click
from pathlib import Path
from onex.utils import print_success, print_info, print_error, print_warning


@click.group()
def vpn():
    """Manage WireGuard VPN connections"""
    pass


@vpn.command('setup')
@click.argument('config_file', type=click.Path(exists=True))
@click.option('--no-connect', is_flag=True, help='Import config but do not connect')
def setup(config_file, no_connect):
    """Setup VPN from config file"""
    from onex.vpn import setup_vpn
    from onex.vpn.wireguard_manager import WireGuardError

    click.echo("🔧 Setting up VPN...")
    click.echo()

    try:
        result = setup_vpn(config_file, auto_connect=not no_connect)

        print_success(f"VPN configured: {result['interface']}")
        click.echo()

        print_info(f"VPN IP:       {result['vpn_ip']}")
        print_info(f"Gateway:      {result['gateway_ip']}")
        print_info(f"Environment:  {result['environment']}")
        print_info(f"Platform URL: {result['platform_url']}")

        click.echo()

        if result['connected']:
            print_success("✅ VPN connected")

            if result['gateway_reachable']:
                print_success("✅ Platform gateway reachable")
                click.echo()
                print_info("Next steps:")
                print_info(f"  onex login --env {result['environment']}")
                print_info("  onex debug --service <service-name>")
            else:
                print_warning("⚠️  Platform gateway not responding")
                print_info("The gateway might be down or still starting.")
        else:
            print_info("VPN configured but not connected")
            print_info(f"To connect: onex vpn connect {result['environment']}")

    except WireGuardError as e:
        print_error(f"VPN setup failed: {str(e)}")
        return 1

    except Exception as e:
        print_error(f"Unexpected error: {str(e)}")
        import traceback
        traceback.print_exc()
        return 1


# Removed: onex vpn connect/disconnect commands - replaced by onex switch
# Use: onex switch <env> instead


@vpn.command('status')
def vpn_status():
    """Show VPN connection status"""
    from onex.vpn.setup_vpn import list_configured_vpns, get_vpn_info, get_environment_from_interface

    vpns = list_configured_vpns()

    if not vpns:
        print_warning("No VPN connections configured")
        print_info("Run: onex vpn setup <config-file>")
        return

    click.echo("VPN Connections:")
    click.echo()

    for vpn in vpns:
        env = get_environment_from_interface(vpn) or 'unknown'
        info = get_vpn_info(vpn)

        if info and info['connected']:
            click.echo(f"  ✅ {env.upper():<8} {vpn:<25} CONNECTED")

            if info.get('latest_handshake'):
                print_info(f"     Last handshake: {info['latest_handshake']}")

            if info.get('transfer'):
                rx = info['transfer'].get('rx', 'N/A')
                tx = info['transfer'].get('tx', 'N/A')
                print_info(f"     Transfer: ↓ {rx} / ↑ {tx}")
        else:
            click.echo(f"  ⚪ {env.upper():<8} {vpn:<25} DISCONNECTED")

        click.echo()


@vpn.command('list')
def vpn_list():
    """List all configured VPNs"""
    from onex.vpn.setup_vpn import list_configured_vpns, get_environment_from_interface

    vpns = list_configured_vpns()

    if not vpns:
        print_warning("No VPN connections configured")
        print_info("Run: onex vpn setup <config-file>")
        return

    click.echo("Configured VPNs:")
    click.echo()

    for vpn in vpns:
        env = get_environment_from_interface(vpn) or 'unknown'
        click.echo(f"  • {vpn:<30} ({env.upper()})")

    click.echo()
    print_info(f"Total: {len(vpns)} VPN(s) configured")


@vpn.command('export-guide')
def export_guide():
    """Show guide for exporting config from WireGuard GUI (Windows)"""
    import os
    from onex.vpn.platform_detector import detect_os

    os_type = detect_os()

    click.echo("📤 Export WireGuard Config from GUI")
    click.echo()

    if os_type == 'windows':
        print_info("Windows users need to export config from WireGuard GUI:")
        click.echo()
        print_info("Step 1: Open WireGuard Application")
        print_info("   • Look for WireGuard icon in system tray or Start menu")
        click.echo()
        print_info("Step 2: Select Your Tunnel")
        print_info("   • Click on the tunnel name (e.g., 'son')")
        click.echo()
        print_info("Step 3: Edit Tunnel")
        print_info("   • Click the 'Edit' button")
        print_info("   • This opens the config editor")
        click.echo()
        print_info("Step 4: Copy Config")
        print_info("   • Select ALL text in the editor (Ctrl+A)")
        print_info("   • Copy to clipboard (Ctrl+C)")
        click.echo()
        print_info("Step 5: Save to File")
        print_info("   • Create a new text file in your project folder:")
        project_dir = os.getcwd()
        print_info(f"     {project_dir}\\wireguard.conf")
        print_info("   • Paste the copied config (Ctrl+V)")
        print_info("   • Save the file")
        click.echo()
        print_success("✅ Now run:")
        print_info(f"   onex init --skip-vpn --config-file \"{project_dir}\\wireguard.conf\"")
        click.echo()
        print_warning("⚠️  Why this is needed:")
        print_info("   WireGuard GUI encrypts configs with Windows DPAPI")
        print_info("   Configs are protected and only accessible by administrators")
        print_info("   Exporting via GUI gives you a plain text copy")

    elif os_type == 'macos':
        print_info("macOS users can directly access config files:")
        click.echo()
        print_info("Config location (Homebrew):")
        print_info("   /opt/homebrew/etc/wireguard/  (Apple Silicon)")
        print_info("   /usr/local/etc/wireguard/     (Intel)")
        click.echo()
        print_info("Example usage:")
        print_info("   onex init --skip-vpn --config-file /opt/homebrew/etc/wireguard/wg-onex-dev.conf")

    elif os_type == 'linux':
        print_info("Linux users can directly access config files:")
        click.echo()
        print_info("Config location:")
        print_info("   /etc/wireguard/")
        click.echo()
        print_info("Example usage:")
        print_info("   onex init --skip-vpn --config-file /etc/wireguard/wg-onex-dev.conf")

    click.echo()
