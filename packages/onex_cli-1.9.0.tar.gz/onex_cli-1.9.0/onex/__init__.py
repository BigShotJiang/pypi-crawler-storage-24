# OneXEOS Services CLI
__version__ = "1.9.0"
