"""
Service descriptor validation module.

Provides validation functionality for service.yml files using Pydantic schema.
Used by both CLI (pre-deployment) and platform (on upload).
"""

from typing import Tuple, List, Dict, Any, Optional
from pathlib import Path
import yaml
from pydantic import ValidationError

from .service_descriptor import ServiceDescriptor


class ValidationResult:
    """
    Result of service.yml validation.

    Attributes:
        is_valid: Whether validation passed
        errors: List of validation error messages
        warnings: List of warning messages (non-fatal)
        descriptor: Parsed ServiceDescriptor (if valid)
    """

    def __init__(
        self,
        is_valid: bool,
        errors: List[str] = None,
        warnings: List[str] = None,
        descriptor: Optional[ServiceDescriptor] = None
    ):
        self.is_valid = is_valid
        self.errors = errors or []
        self.warnings = warnings or []
        self.descriptor = descriptor

    def __repr__(self) -> str:
        if self.is_valid:
            return f"ValidationResult(valid=True, service={self.descriptor.name})"
        return f"ValidationResult(valid=False, errors={len(self.errors)})"


class ServiceYmlValidator:
    """
    Validator for service.yml files.

    Usage:
        # Validate from file
        result = ServiceYmlValidator.validate_file("service.yml")
        if result.is_valid:
            print(f"✅ Valid: {result.descriptor.name} v{result.descriptor.version}")
        else:
            for error in result.errors:
                print(f"❌ {error}")

        # Validate from dict
        data = yaml.safe_load(open("service.yml"))
        result = ServiceYmlValidator.validate_dict(data)
    """

    @staticmethod
    def validate_file(file_path: str) -> ValidationResult:
        """
        Validate service.yml from file path.

        Args:
            file_path: Path to service.yml file

        Returns:
            ValidationResult with validation status and errors
        """
        path = Path(file_path)

        # Check file exists
        if not path.exists():
            return ValidationResult(
                is_valid=False,
                errors=[f"File not found: {file_path}"]
            )

        # Check file is readable
        if not path.is_file():
            return ValidationResult(
                is_valid=False,
                errors=[f"Not a file: {file_path}"]
            )

        # Read and parse YAML
        try:
            with open(path, 'r', encoding='utf-8') as f:
                data = yaml.safe_load(f)
        except yaml.YAMLError as e:
            return ValidationResult(
                is_valid=False,
                errors=[f"Invalid YAML syntax: {str(e)}"]
            )
        except Exception as e:
            return ValidationResult(
                is_valid=False,
                errors=[f"Failed to read file: {str(e)}"]
            )

        # Validate against schema
        return ServiceYmlValidator.validate_dict(data, file_path=str(path))

    @staticmethod
    def validate_dict(
        data: Dict[str, Any],
        file_path: Optional[str] = None
    ) -> ValidationResult:
        """
        Validate service.yml from dictionary.

        Args:
            data: Parsed YAML data as dictionary
            file_path: Optional file path for error messages

        Returns:
            ValidationResult with validation status and errors
        """
        warnings = []

        # Check for null/empty data
        if not data:
            return ValidationResult(
                is_valid=False,
                errors=["Empty or null configuration"]
            )

        # Validate against Pydantic schema
        try:
            descriptor = ServiceDescriptor(**data)

            # Additional validation checks (warnings)
            warnings.extend(ServiceYmlValidator._check_best_practices(descriptor))

            return ValidationResult(
                is_valid=True,
                warnings=warnings,
                descriptor=descriptor
            )

        except ValidationError as e:
            # Format Pydantic validation errors
            errors = ServiceYmlValidator._format_validation_errors(e, file_path)

            return ValidationResult(
                is_valid=False,
                errors=errors
            )

        except Exception as e:
            return ValidationResult(
                is_valid=False,
                errors=[f"Validation error: {str(e)}"]
            )

    @staticmethod
    def _format_validation_errors(
        e: ValidationError,
        file_path: Optional[str] = None
    ) -> List[str]:
        """
        Format Pydantic validation errors for human-readable output.

        Args:
            e: Pydantic ValidationError
            file_path: Optional file path for context

        Returns:
            List of formatted error messages
        """
        errors = []
        prefix = f"{file_path}: " if file_path else ""

        for error in e.errors():
            # Get field location (e.g., "deployment.container.replicas")
            field_path = " → ".join(str(loc) for loc in error['loc'])

            # Get error message
            msg = error['msg']

            # Get error type
            error_type = error['type']

            # Format based on error type
            if error_type == 'missing':
                errors.append(f"{prefix}Missing required field: {field_path}")
            elif error_type == 'value_error':
                errors.append(f"{prefix}{field_path}: {msg}")
            elif error_type == 'type_error':
                errors.append(f"{prefix}{field_path}: Invalid type - {msg}")
            elif error_type == 'literal_error':
                # Extract allowed values from error
                errors.append(f"{prefix}{field_path}: {msg}")
            else:
                errors.append(f"{prefix}{field_path}: {msg}")

        return errors

    @staticmethod
    def _check_best_practices(descriptor: ServiceDescriptor) -> List[str]:
        """
        Check for best practice violations (warnings, not errors).

        Args:
            descriptor: Validated ServiceDescriptor

        Returns:
            List of warning messages
        """
        warnings = []

        # Check if description is provided
        if not descriptor.description:
            warnings.append(
                "No description provided. "
                "Consider adding a description for better documentation."
            )

        # Check if HTTP endpoints are defined (either via routes or functions with HTTP triggers)
        http_endpoints_count = 0

        # Count legacy routes (if routes attribute exists for backwards compatibility)
        if hasattr(descriptor, 'routes') and descriptor.routes:
            http_endpoints_count += len(descriptor.routes)

        # Count HTTP triggers in functions
        if descriptor.functions:
            for func in descriptor.functions:
                http_triggers = [t for t in func.triggers if hasattr(t, 'type') and t.type == 'http']
                http_endpoints_count += len(http_triggers)

        # Warn if no HTTP endpoints found
        if http_endpoints_count == 0:
            warnings.append(
                "No HTTP endpoints defined. "
                "Service won't be accessible via gateway unless routes are registered."
            )

        # Check container mode without resource limits
        if descriptor.deployment.mode == "container":
            container = descriptor.deployment.container
            if container and not container.resources:
                warnings.append(
                    "Container mode without resource limits. "
                    "Recommended: Set cpu and memory limits to prevent resource exhaustion."
                )

        # Check if dependencies are specified
        if not descriptor.dependencies or not descriptor.dependencies.services:
            warnings.append(
                "No dependencies declared. "
                "If service uses MongoDB, Redis, etc., declare them in dependencies."
            )

        # Check version is not 0.0.0
        if descriptor.version == "0.0.0":
            warnings.append(
                "Version is 0.0.0. "
                "Consider using a meaningful version number (e.g., 0.1.0 for initial release)."
            )

        return warnings

    @staticmethod
    def validate_and_raise(file_path: str) -> ServiceDescriptor:
        """
        Validate service.yml and raise exception if invalid.

        This is a convenience method for platform code that wants to fail fast.

        Args:
            file_path: Path to service.yml file

        Returns:
            Validated ServiceDescriptor

        Raises:
            ValueError: If validation fails
        """
        result = ServiceYmlValidator.validate_file(file_path)

        if not result.is_valid:
            error_msg = "\n".join(f"  - {error}" for error in result.errors)
            raise ValueError(f"Invalid service.yml:\n{error_msg}")

        return result.descriptor

    @staticmethod
    def validate_dict_and_raise(data: Dict[str, Any]) -> ServiceDescriptor:
        """
        Validate service.yml dict and raise exception if invalid.

        Args:
            data: Parsed YAML data

        Returns:
            Validated ServiceDescriptor

        Raises:
            ValueError: If validation fails
        """
        result = ServiceYmlValidator.validate_dict(data)

        if not result.is_valid:
            error_msg = "\n".join(f"  - {error}" for error in result.errors)
            raise ValueError(f"Invalid service configuration:\n{error_msg}")

        return result.descriptor


# Convenience functions for common use cases

def validate_service_yml(file_path: str) -> Tuple[bool, List[str]]:
    """
    Simple validation function that returns (is_valid, errors).

    Args:
        file_path: Path to service.yml file

    Returns:
        Tuple of (is_valid, list of error messages)

    Example:
        is_valid, errors = validate_service_yml("service.yml")
        if not is_valid:
            for error in errors:
                print(f"Error: {error}")
    """
    result = ServiceYmlValidator.validate_file(file_path)
    return result.is_valid, result.errors


def load_and_validate_service_yml(file_path: str) -> ServiceDescriptor:
    """
    Load and validate service.yml, returning parsed descriptor.

    Args:
        file_path: Path to service.yml file

    Returns:
        Validated ServiceDescriptor

    Raises:
        ValueError: If validation fails

    Example:
        try:
            descriptor = load_and_validate_service_yml("service.yml")
            print(f"Service: {descriptor.name} v{descriptor.version}")
        except ValueError as e:
            print(f"Validation failed: {e}")
    """
    return ServiceYmlValidator.validate_and_raise(file_path)
