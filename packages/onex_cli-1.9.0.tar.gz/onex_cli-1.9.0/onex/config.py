"""
Configuration management for OneXEOS CLI
"""

import os
import json
from pathlib import Path
from typing import Dict, Any, Optional
from dotenv import load_dotenv

# Load .env file
load_dotenv()


def get_onex_dir() -> Path:
    """Get ~/.onex directory"""
    return Path.home() / '.onex'


def get_active_environment() -> str:
    """
    Get currently active environment from ~/.onex/active-env

    Returns:
        Active environment name (local/dev/staging/prod)
        Defaults to 'local' if not set
    """
    active_file = get_onex_dir() / 'active-env'
    if active_file.exists():
        return active_file.read_text().strip()
    return 'local'


def get_environment_config(env: Optional[str] = None) -> dict:
    """
    Load configuration for specific environment from ~/.onex/environments.json

    Args:
        env: Environment name (if None, uses active environment)

    Returns:
        Environment configuration dict

    Raises:
        FileNotFoundError: If environments.json doesn't exist
        KeyError: If environment not configured
    """
    if env is None:
        env = get_active_environment()

    env_file = get_onex_dir() / 'environments.json'
    if not env_file.exists():
        raise FileNotFoundError(
            f"No environments configured. Run: onex login --env {env}"
        )

    with env_file.open() as f:
        data = json.load(f)

    if env not in data:
        raise KeyError(
            f"Environment '{env}' not configured. Run: onex login --env {env}"
        )

    return data[env]


def get_platform_url(env: Optional[str] = None) -> str:
    """
    Get platform URL for environment

    Args:
        env: Environment name (if None, uses active environment)

    Returns:
        Platform URL for the environment
    """
    try:
        env_config = get_environment_config(env)
        return env_config.get('platform_url', 'http://localhost:8000')
    except (FileNotFoundError, KeyError):
        # Fallback to environment variable
        if env == 'local':
            return os.getenv('PLATFORM_URL_LOCAL', 'http://localhost:8000')
        elif env == 'dev':
            return os.getenv('PLATFORM_URL_DEV', 'http://10.0.0.1:8000')
        elif env == 'staging':
            return os.getenv('PLATFORM_URL_STAGING', 'http://10.0.1.1:8000')
        elif env == 'prod':
            return os.getenv('PLATFORM_URL_PROD', 'http://10.0.2.1:8000')
        return os.getenv('PLATFORM_URL', 'http://localhost:8000')


def get_access_token(env: Optional[str] = None) -> Optional[str]:
    """
    Get access token for environment

    Args:
        env: Environment name (if None, uses active environment)

    Returns:
        Access token or None if not authenticated
    """
    try:
        env_config = get_environment_config(env)
        return env_config.get('access_token')
    except (FileNotFoundError, KeyError):
        return None


class Config:
    """Configuration manager for CLI (legacy support)"""

    def __init__(self):
        self.platform_url = os.getenv('PLATFORM_URL', 'http://localhost:8000')
        self.platform_api_key = os.getenv('PLATFORM_API_KEY', '')
        self.mongodb_uri = os.getenv('MONGODB_URI', 'mongodb://localhost:27017/onexeos')
        self.redis_uri = os.getenv('REDIS_URI', 'redis://localhost:6379')
        self.environment = os.getenv('ENVIRONMENT', 'dev')
        self.log_level = os.getenv('LOG_LEVEL', 'info')

    def get_platform_url(self, env: Optional[str] = None) -> str:
        """Get platform URL for environment (uses new system)"""
        return get_platform_url(env)

    def get_platform_api_key(self, env: Optional[str] = None) -> str:
        """Get platform API key for environment"""
        if env == 'local':
            return os.getenv('PLATFORM_API_KEY_LOCAL', self.platform_api_key)
        elif env == 'dev' or env == 'development':
            return os.getenv('PLATFORM_API_KEY_DEV', self.platform_api_key)
        elif env == 'staging':
            return os.getenv('PLATFORM_API_KEY_STAGING', self.platform_api_key)
        elif env == 'prod' or env == 'production':
            return os.getenv('PLATFORM_API_KEY_PROD', self.platform_api_key)
        return self.platform_api_key

    def to_dict(self) -> Dict[str, Any]:
        """Convert config to dictionary"""
        return {
            'platform_url': self.platform_url,
            'mongodb_uri': self.mongodb_uri,
            'redis_uri': self.redis_uri,
            'environment': self.environment,
            'log_level': self.log_level,
        }


def get_config() -> Config:
    """Get global config instance"""
    return Config()
