"""
OneXEOS Services CLI - Main Entry Point

Commands:
  login     - Login to OneXEOS platform with email/password
  logout    - Logout and remove stored token
  init      - Initialize CLI configuration (interactive)
  create    - Create new service from template (NEW in v1.4.0)
  validate  - Validate service.yml schema without deploying
  deploy    - Deploy service to platform (local/dev/staging/prod)
  undeploy  - Remove a deployed service from the platform
  dev       - Run service locally with hot-reload
  debug     - Run service(s) locally with platform connection checks
  logs      - View service logs
  status    - Check service status
  provision - Manually provision resources
  invoke    - Invoke handlers directly
  trace     - Track requests through platform
  replay    - Re-send a previously captured request
  test      - Run E2E tests against the platform
  create-e2e - Scaffold E2E tests for a service

Environments:
  local     - Your laptop (http://localhost:8001)
  dev       - Shared dev VPS (http://10.0.0.1:8000 via VPN)
  staging   - Staging VPS (http://10.0.1.1:8000 via VPN)
  prod      - Production VPS (http://10.0.2.1:8000 via VPN)
"""

import click
from onex.commands import deploy, undeploy, dev, debug, init, logs, status, provision, invoke, trace, validate, login, logout, env, platform, vpn, switch, mcp, create, replay, es, test, create_e2e


# Commands that don't require authentication
UNAUTHENTICATED_COMMANDS = {
    'login', 'logout', 'init', 'vpn', 'mcp', 'create', 'validate', 'test', 'create-e2e', '--help', '--version'
}


@click.group(invoke_without_command=True)
@click.version_option(version=__import__('onex').__version__, prog_name='onex')
@click.pass_context
def cli(ctx):
    """OneXEOS Services CLI - Deploy and manage services"""
    # Auto-refresh token before command execution (if needed)
    if ctx.invoked_subcommand and ctx.invoked_subcommand not in UNAUTHENTICATED_COMMANDS:
        try:
            from onex.utils.auth import ensure_valid_token, get_token_info
            from onex.config import get_active_environment
            from onex.utils import print_warning

            # Ensure we have a valid token (auto-refresh if expired)
            if not ensure_valid_token(auto_refresh=True):
                # Auto-refresh failed - show warning but continue
                # (command will show proper error if token is actually needed)
                token_info = get_token_info()
                if token_info and token_info.get('is_expired'):
                    env = get_active_environment()
                    print_warning("⚠️  Token has expired and auto-refresh failed")
                    print_warning(f"   Please run: onex login --env {env}")

        except Exception:
            # Unexpected error during token check - continue silently
            # (command will show proper error if token is actually needed)
            pass


# Register commands
cli.add_command(login.login)
cli.add_command(logout.logout)
cli.add_command(init.init)
cli.add_command(switch.switch)
cli.add_command(env.env)
cli.add_command(platform.platform)
cli.add_command(vpn.vpn)
cli.add_command(mcp.mcp)
cli.add_command(create.create)  # NEW: Service scaffolding
cli.add_command(validate.validate)
cli.add_command(deploy.deploy)
cli.add_command(undeploy.undeploy)
cli.add_command(dev.dev)
cli.add_command(debug.debug)
cli.add_command(logs.logs)
cli.add_command(status.status)
cli.add_command(provision.provision)
cli.add_command(invoke.invoke)
cli.add_command(trace.trace)
cli.add_command(replay.replay)
cli.add_command(es.es)
cli.add_command(test.test)
cli.add_command(create_e2e.create_e2e, name='create-e2e')


if __name__ == '__main__':
    cli()
