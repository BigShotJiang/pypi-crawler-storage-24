"""
MCP Tools for OneX CLI

Wraps OneX CLI commands as MCP tools for AI assistants.
"""
