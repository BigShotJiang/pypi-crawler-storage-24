"""
OneX MCP Server

Model Context Protocol server that exposes OneX CLI commands as tools
for AI assistants to investigate issues, debug services, and manage the platform.

Usage:
    onex-mcp  # Runs stdio-based MCP server for Claude Desktop

Architecture:
    - Calls platform APIs directly via httpx (no subprocess overhead)
    - Works on Windows, macOS, and Linux without PATH issues
    - Async-native for non-blocking execution
    - Comprehensive error handling
    - Structured output for AI consumption
"""

import json
import sys
import socket
from pathlib import Path
from typing import Optional

try:
    import httpx
except ImportError:
    # httpx is already a dependency of onex-cli
    print("Error: httpx not installed", file=sys.stderr)
    sys.exit(1)

try:
    from mcp.server.fastmcp import FastMCP
except ImportError:
    print("Error: MCP package not installed", file=sys.stderr)
    print("Install with: pip install -e '.[mcp]'", file=sys.stderr)
    sys.exit(1)


# Initialize MCP server
mcp = FastMCP("onex-platform")


# =============================================================================
# CONFIG HELPERS (inline to avoid import side effects)
# =============================================================================

def _get_onex_dir() -> Path:
    """Get ~/.onex directory"""
    return Path.home() / '.onex'


def get_active_environment() -> str:
    """Get active environment from ~/.onex/active-env, fallback to 'local'"""
    try:
        active_file = _get_onex_dir() / 'active-env'
        if active_file.exists():
            return active_file.read_text().strip()
    except Exception:
        pass
    return 'local'


def _load_environment_config(env: str) -> dict:
    """Load environment config from ~/.onex/environments.json"""
    try:
        env_file = _get_onex_dir() / 'environments.json'
        if env_file.exists():
            with env_file.open() as f:
                data = json.load(f)
            return data.get(env, {})
    except Exception:
        pass
    return {}


def _get_platform_url(env: str) -> str:
    """Get platform URL for environment"""
    env_data = _load_environment_config(env)
    if env_data.get('platform_url'):
        return env_data['platform_url']

    # Fallback defaults
    defaults = {
        'local': 'http://localhost:8000',
        'dev': 'http://10.0.0.1:8000',
        'staging': 'http://10.0.1.1:8000',
        'prod': 'http://10.0.2.1:8000',
    }
    return defaults.get(env, 'http://localhost:8000')


def _get_access_token(env: str) -> Optional[str]:
    """Get access token for environment"""
    env_data = _load_environment_config(env)
    return env_data.get('access_token')


def _get_credentials(env: str) -> dict:
    """Get service credentials for environment"""
    if env == 'local':
        return {
            'mongodb_uri': 'mongodb://admin:admin123@localhost:27017/onexeos-service?authSource=admin&directConnection=true',
            'redis_uri': 'redis://:redis_dev_password_123@localhost:6379',
            'nats_url': 'nats://localhost:4222',
            'elasticsearch_url': 'http://localhost:9200',
            'minio_endpoint': 'localhost:9000',
        }
    env_data = _load_environment_config(env)
    return env_data.get('credentials', {})


def _auth_headers(env: str) -> dict:
    """Get authorization headers for API calls"""
    token = _get_access_token(env)
    if token:
        return {'Authorization': f'Bearer {token}'}
    return {}


# =============================================================================
# PLATFORM TOOLS
# =============================================================================

@mcp.tool()
async def onex_platform_check(env: str = None) -> str:
    """Check OneX platform infrastructure health.

    Verifies all core platform services are running and healthy:
    - MongoDB (database)
    - Redis (cache and queues)
    - NATS (message streaming)
    - Elasticsearch (search engine)
    - MinIO (object storage)
    - Gateway (API gateway)

    This is the FIRST tool to run when investigating any issue.
    If platform services are down, nothing will work.

    Args:
        env: Environment to check (local/dev/staging/prod). Default: active environment

    Returns:
        Formatted health status of all platform services with ✅/❌ indicators

    Examples:
        User: "Is my platform healthy?"
        → onex_platform_check()

        User: "Check dev environment"
        → onex_platform_check(env="dev")
    """
    if env is None:
        env = get_active_environment()

    credentials = _get_credentials(env)
    platform_url = _get_platform_url(env)
    results = []
    all_healthy = True

    results.append(f"🔍 Checking platform infrastructure ({env})...\n")

    # Check MongoDB
    mongodb_uri = credentials.get('mongodb_uri', '')
    if mongodb_uri:
        host_part = mongodb_uri.split('@')[1].split('/')[0] if '@' in mongodb_uri else 'unknown'
        try:
            from pymongo import MongoClient
            client = MongoClient(mongodb_uri, serverSelectionTimeoutMS=5000)
            client.admin.command('ping')
            client.close()
            results.append(f"  ✅ MongoDB       {host_part:<30} Connected")
        except Exception as e:
            all_healthy = False
            results.append(f"  ❌ MongoDB       {host_part:<30} Connection failed")

    # Check Redis
    redis_uri = credentials.get('redis_uri', '')
    if redis_uri:
        host_part = redis_uri.split('@')[1] if '@' in redis_uri else redis_uri.replace('redis://', '')
        try:
            import redis
            client = redis.from_url(redis_uri, socket_connect_timeout=5)
            client.ping()
            client.close()
            results.append(f"  ✅ Redis         {host_part:<30} Connected")
        except Exception as e:
            all_healthy = False
            results.append(f"  ❌ Redis         {host_part:<30} Connection refused")

    # Check NATS
    nats_url = credentials.get('nats_url', '')
    if nats_url:
        try:
            host_port = nats_url.replace('nats://', '').split(':')
            host = host_port[0]
            port = int(host_port[1]) if len(host_port) > 1 else 4222
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(5)
            result = sock.connect_ex((host, port))
            sock.close()
            endpoint = f"{host}:{port}"
            if result == 0:
                results.append(f"  ✅ NATS          {endpoint:<30} Connected")
            else:
                all_healthy = False
                results.append(f"  ❌ NATS          {endpoint:<30} Connection refused")
        except Exception as e:
            all_healthy = False
            results.append(f"  ❌ NATS          Connection failed: {e}")

    # Check Elasticsearch
    es_url = credentials.get('elasticsearch_url', '')
    if es_url:
        try:
            async with httpx.AsyncClient(timeout=5) as client:
                resp = await client.get(es_url)
            if resp.status_code == 200:
                results.append(f"  ✅ Elasticsearch {es_url:<30} Healthy")
            else:
                all_healthy = False
                results.append(f"  ❌ Elasticsearch {es_url:<30} HTTP {resp.status_code}")
        except Exception as e:
            all_healthy = False
            results.append(f"  ❌ Elasticsearch Connection failed: {e}")

    # Check MinIO
    minio_endpoint = credentials.get('minio_endpoint', '')
    if minio_endpoint:
        try:
            url = f"http://{minio_endpoint}/minio/health/live"
            async with httpx.AsyncClient(timeout=5) as client:
                resp = await client.get(url)
            if resp.status_code == 200:
                results.append(f"  ✅ MinIO         {minio_endpoint:<30} Healthy")
            else:
                all_healthy = False
                results.append(f"  ❌ MinIO         {minio_endpoint:<30} HTTP {resp.status_code}")
        except Exception as e:
            all_healthy = False
            results.append(f"  ❌ MinIO         Connection failed: {e}")

    # Check Gateway
    if platform_url:
        try:
            async with httpx.AsyncClient(timeout=5) as client:
                resp = await client.get(f"{platform_url}/health")
            if resp.status_code == 200:
                results.append(f"  ✅ Gateway       {platform_url:<30} Healthy")
            else:
                all_healthy = False
                results.append(f"  ❌ Gateway       {platform_url:<30} HTTP {resp.status_code}")
        except Exception as e:
            all_healthy = False
            results.append(f"  ❌ Gateway       Connection failed: {e}")

    # Summary
    results.append("")
    if all_healthy:
        results.append("Platform Status: ✅ All services healthy")
    else:
        results.append("Platform Status: ⚠️  Some services unavailable")

    return "\n".join(results)


# =============================================================================
# DEBUGGING TOOLS
# =============================================================================

@mcp.tool()
async def onex_trace(
    trace_id: str,
    env: str = None,
    follow: bool = False,
    json_output: bool = False
) -> str:
    """Track a request through the platform using trace_id.

    Shows complete request timeline across all services:
    - Gateway received request
    - Runtime forwarded to service
    - Service handler execution
    - Response path back to client

    Includes timestamps, durations, and error details.
    CRITICAL for debugging API failures and performance issues.

    Args:
        trace_id: Request trace ID from x-trace-id response header
        env: Environment (local/dev/staging/prod). Default: active environment
        follow: Follow trace in real-time (for long-running requests)
        json_output: Return JSON format instead of formatted text

    Returns:
        Complete request trace with timing information and errors

    Examples:
        User: "Why did this API call fail? trace_id: 550e8400-e29b-41d4-a716-446655440000"
        → onex_trace(trace_id="550e8400-e29b-41d4-a716-446655440000")

        User: "Trace this request in dev"
        → onex_trace(trace_id="...", env="dev")
    """
    if env is None:
        env = get_active_environment()

    platform_url = _get_platform_url(env)
    headers = _auth_headers(env)

    if not headers:
        return f"Error: Authentication required. Run: onex login --env {env}"

    try:
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.get(
                f"{platform_url}/_internal/trace/{trace_id}",
                headers=headers
            )

        if resp.status_code == 200:
            data = resp.json()
            if json_output:
                return json.dumps(data, indent=2)

            timeline = data.get('timeline', [])
            total_logs = data.get('total_logs', 0)

            if total_logs == 0:
                return (
                    f"No logs found for trace_id: {trace_id}\n"
                    "This could mean:\n"
                    "  - Request hasn't been processed yet\n"
                    "  - Trace_id is incorrect\n"
                    "  - Logs have expired (older than 24 hours)"
                )

            # Extract request metadata from first/last logs
            first = timeline[0] if timeline else {}
            req_method = ''
            req_path = ''
            req_status = ''
            total_duration = ''
            services_seen = []

            for entry in timeline:
                m = entry.get('method', '')
                p = entry.get('path', '')
                if m and not req_method:
                    req_method = m
                if p and not req_path:
                    req_path = p
                sc = entry.get('status_code')
                if sc:
                    req_status = str(sc)
                svc = entry.get('service') or entry.get('component', '')
                if svc and svc not in services_seen:
                    services_seen.append(svc)
                dur = entry.get('duration_ms')
                if dur:
                    total_duration = f"{dur}ms"

            # Build rich header
            lines = [f"Trace: {trace_id}"]
            if req_method and req_path:
                lines.append(f"Request: {req_method} {req_path}")
            if req_status:
                lines.append(f"Status: {req_status}")
            if total_duration:
                lines.append(f"Duration: {total_duration}")
            if services_seen:
                lines.append(f"Services: {' -> '.join(services_seen)}")
            lines.append("")

            # Parse timestamps for relative offsets
            first_ts = None
            for entry in timeline:
                ts_str = entry.get('timestamp', '')
                if ts_str:
                    try:
                        from datetime import datetime as _dt
                        # Handle various timestamp formats
                        for fmt in ('%Y-%m-%dT%H:%M:%S.%fZ', '%Y-%m-%dT%H:%M:%SZ',
                                    '%Y-%m-%dT%H:%M:%S.%f+00:00', '%Y-%m-%dT%H:%M:%S+00:00'):
                            try:
                                first_ts = _dt.strptime(ts_str, fmt)
                                break
                            except ValueError:
                                continue
                    except Exception:
                        pass
                    if first_ts:
                        break

            # Format timeline entries
            for entry in timeline:
                component = (entry.get('service') or entry.get('component', 'unknown'))
                level = entry.get('level', 'INFO').upper()
                message = entry.get('message') or entry.get('event', '')
                status_code = entry.get('status_code', '')
                duration = entry.get('duration_ms', '')
                error_type = entry.get('error_type', '')
                error_msg = entry.get('error', '')
                traceback_info = entry.get('traceback', '')
                fingerprint = entry.get('error_fingerprint', '')

                # Calculate relative offset
                offset_str = ''
                ts_str = entry.get('timestamp', '')
                if first_ts and ts_str:
                    try:
                        for fmt in ('%Y-%m-%dT%H:%M:%S.%fZ', '%Y-%m-%dT%H:%M:%SZ',
                                    '%Y-%m-%dT%H:%M:%S.%f+00:00', '%Y-%m-%dT%H:%M:%S+00:00'):
                            try:
                                entry_ts = _dt.strptime(ts_str, fmt)
                                offset_ms = int((entry_ts - first_ts).total_seconds() * 1000)
                                offset_str = f"+{offset_ms}ms"
                                break
                            except ValueError:
                                continue
                    except Exception:
                        pass

                # Format the line
                pad_offset = f"{offset_str:>8}" if offset_str else "        "
                pad_component = f"{component:<18}"
                detail = message
                if status_code and duration:
                    detail += f" [{status_code}] ({duration}ms)"
                elif status_code:
                    detail += f" [{status_code}]"

                lines.append(f"  {pad_offset} [{pad_component}] {level:5} {detail}")

                # Add error details on separate lines
                if error_type and level == 'ERROR':
                    if error_msg:
                        lines.append(f"             {'':18}        {error_type}: {error_msg}")
                    if traceback_info:
                        if isinstance(traceback_info, list):
                            for frame in traceback_info[-3:]:  # last 3 frames
                                f_file = frame.get('file', '')
                                f_func = frame.get('function', '')
                                f_line = frame.get('line', '')
                                lines.append(f"             {'':18}        {f_file}:{f_line} in {f_func}()")
                        elif isinstance(traceback_info, str):
                            lines.append(f"             {'':18}        traceback: {traceback_info[:200]}")
                    if fingerprint:
                        lines.append(f"             {'':18}        fingerprint: {fingerprint}")

            return "\n".join(lines)

        elif resp.status_code == 401:
            return f"Authentication failed. Run: onex login --env {env}"
        elif resp.status_code == 503:
            return "Loki service unavailable. Make sure observability stack is running."
        else:
            return f"Failed to query trace: HTTP {resp.status_code}"

    except httpx.ConnectError:
        return f"Cannot connect to platform at {platform_url}. Make sure platform is running."
    except httpx.TimeoutException:
        return f"Request timed out connecting to {platform_url}"
    except Exception as e:
        return f"Error querying trace: {e}"


@mcp.tool()
async def onex_logs(
    service_name: str,
    env: str = None,
    follow: bool = False,
    lines: int = 100,
    level: str = None,
    trace_id: str = None,
    user_id: str = None,
    company_id: str = None,
    path: str = None,
    method: str = None,
    event: str = None,
    grep: str = None,
    last: str = None
) -> str:
    """View service logs from platform with powerful filtering.

    Fetches recent logs for a deployed service with advanced filtering options.
    Perfect for debugging specific issues, tracking user requests, and finding errors.

    Args:
        service_name: Name of the service (e.g., 'email-service', 'product', 'auth')
        env: Environment (local/dev/staging/prod). Default: active environment
        follow: Follow logs in real-time (like tail -f)
        lines: Number of recent lines to show. Default: 100
        level: Filter by level (ERROR, WARNING, INFO, DEBUG) - comma-separated
        trace_id: Filter by trace ID to track specific request
        user_id: Filter by user ID to track specific user's activity
        company_id: Filter by company/tenant ID
        path: Filter by API path (e.g., "/auth/login")
        method: Filter by HTTP method (GET, POST, etc.)
        event: Filter by event type (service_ready, error, etc.)
        grep: Search message with regex pattern
        last: Time range (e.g., "1h", "30m", "24h")

    Returns:
        Recent log entries with timestamps and log levels, filtered by criteria

    Examples:
        User: "Show me auth errors from the last hour"
        → onex_logs(service_name="auth", level="ERROR", last="1h")

        User: "Find login attempts for user john@example.com"
        → onex_logs(service_name="auth", path="/auth/login", grep="john@example.com")

        User: "Debug this trace: abc-123-def"
        → onex_logs(service_name="auth", trace_id="abc-123-def", lines=500)

        User: "What errors happened after the 2pm deployment?"
        → onex_logs(service_name="product", level="ERROR", last="2h")

        User: "Show me all product service warnings and errors"
        → onex_logs(service_name="product", level="ERROR,WARNING", lines=200)

        User: "Track user123's activity in the last 6 hours"
        → onex_logs(service_name="auth", user_id="user123", last="6h")
    """
    if env is None:
        env = get_active_environment()

    platform_url = _get_platform_url(env)
    logs_url = f"{platform_url}/_internal/services/{service_name}/logs"

    # Build query parameters
    params = {'lines': lines}
    if level:
        params['level'] = level
    if trace_id:
        params['trace_id'] = trace_id
    if user_id:
        params['user_id'] = user_id
    if company_id:
        params['company_id'] = company_id
    if path:
        params['path'] = path
    if method:
        params['method'] = method
    if event:
        params['event'] = event
    if grep:
        params['grep'] = grep
    if last:
        params['last'] = last

    try:
        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.get(logs_url, params=params)

        if resp.status_code == 200:
            data = resp.json()
            log_entries = data.get('logs', [])

            if not log_entries:
                return f"No logs found for {service_name} with the given filters."

            # Format logs for AI consumption
            output_lines = [f"Logs for {service_name} ({env}): {len(log_entries)} entries\n"]
            for entry in log_entries:
                timestamp = entry.get('timestamp', '')
                message = entry.get('message', '')
                log_level = entry.get('level', 'INFO')
                output_lines.append(f"{timestamp} {log_level:5} {message}")

            return "\n".join(output_lines)

        elif resp.status_code == 404:
            return f"Service '{service_name}' not found. Check deployed services with: onex status"
        else:
            return f"Failed to fetch logs: HTTP {resp.status_code}"

    except httpx.ConnectError:
        return f"Cannot connect to platform at {platform_url}. Make sure platform is running."
    except httpx.TimeoutException:
        return f"Request timed out connecting to {platform_url}"
    except Exception as e:
        return f"Error fetching logs: {e}"


@mcp.tool()
async def onex_status(
    service_name: Optional[str] = None,
    env: str = None
) -> str:
    """Check service deployment status and health.

    Shows:
    - Service version and deployment time
    - Running/stopped status
    - HTTP routes registered
    - Request metrics (count, errors, latency)
    - Resource usage

    If no service_name provided, lists ALL deployed services.

    Args:
        service_name: Optional service name. If None, lists all services
        env: Environment (local/dev/staging/prod). Default: active environment

    Returns:
        Service status details or list of all services

    Examples:
        User: "What services are deployed?"
        → onex_status()

        User: "Is email-service running?"
        → onex_status(service_name="email-service")

        User: "Check product service health in dev"
        → onex_status(service_name="product", env="dev")
    """
    if env is None:
        env = get_active_environment()

    platform_url = _get_platform_url(env)
    headers = _auth_headers(env)

    try:
        if service_name:
            # Check specific service
            async with httpx.AsyncClient(timeout=10) as client:
                resp = await client.get(
                    f"{platform_url}/_internal/services/{service_name}",
                    headers=headers
                )

            if resp.status_code == 200:
                data = resp.json()
                lines = [
                    f"Service: {data.get('name')}",
                    f"Version: {data.get('version', 'N/A')}",
                    f"Status: {data.get('status', 'unknown')}",
                    f"Mode: {data.get('mode', 'shared')}",
                    "",
                    "Routes:",
                ]
                for route in data.get('routes', []):
                    m = route.get('method', 'GET')
                    p = route.get('path', '')
                    lines.append(f"  {m:6} {p}")

                lines.append("")
                lines.append("Metrics:")
                metrics = data.get('metrics', {})
                lines.append(f"  Requests: {metrics.get('total_requests', 0)}")
                lines.append(f"  Errors: {metrics.get('error_count', 0)}")
                lines.append(f"  Avg Response Time: {metrics.get('avg_response_time', 0):.2f}ms")
                lines.append(f"  Health: {data.get('health', 'unknown')}")

                return "\n".join(lines)

            elif resp.status_code == 401:
                return f"Authentication required. Run: onex login --env {env}"
            elif resp.status_code == 404:
                return f"Service '{service_name}' not found. Check deployed services with: onex status"
            else:
                return f"Failed to get status: HTTP {resp.status_code}"

        else:
            # List all services
            async with httpx.AsyncClient(timeout=10) as client:
                resp = await client.get(
                    f"{platform_url}/_internal/services",
                    headers=headers
                )

            if resp.status_code == 200:
                data = resp.json()
                services = data.get('services', {})

                if not services:
                    return "No services deployed. Deploy a service with: onex deploy"

                lines = [f"Found {len(services)} service(s):", ""]
                lines.append(f"{'Service':<20} {'Version':<10} {'Mode':<12} {'Status':<10} {'Routes':<8}")
                lines.append("-" * 70)

                for svc_name, svc_data in services.items():
                    version = svc_data.get('version', 'N/A')
                    mode = svc_data.get('mode', 'shared')
                    status_val = svc_data.get('status', 'unknown')
                    route_count = len(svc_data.get('apis', []))
                    lines.append(f"{svc_name:<20} {version:<10} {mode:<12} {status_val:<10} {route_count:<8}")

                lines.append("")
                lines.append(f"Platform: {platform_url}")
                return "\n".join(lines)

            elif resp.status_code == 401:
                return f"Authentication required. Run: onex login --env {env}"
            else:
                return f"Failed to list services: HTTP {resp.status_code}"

    except httpx.ConnectError:
        return f"Cannot connect to platform at {platform_url}. Make sure platform is running."
    except httpx.TimeoutException:
        return f"Request timed out connecting to {platform_url}"
    except Exception as e:
        return f"Error checking status: {e}"


# =============================================================================
# INVOCATION TOOLS
# =============================================================================

@mcp.tool()
async def onex_invoke(
    function_name: str,
    payload: str,
    env: str = None,
    is_async: bool = False,
    timeout: int = 60
) -> str:
    """Invoke a service handler directly with test data.

    Executes a Lambda-like function handler with provided payload.
    Useful for:
    - Testing handlers without HTTP requests
    - Debugging function logic
    - Running background tasks
    - Integration testing

    Args:
        function_name: Handler name in format 'service:handler' (e.g., 'order:processOrder')
        payload: JSON payload as string (e.g., '{"orderId": "123"}')
        env: Environment (local/dev/staging/prod). Default: active environment
        is_async: Run asynchronously (fire-and-forget). Default: False
        timeout: Timeout in seconds for sync invokes. Default: 60

    Returns:
        Handler execution result with timing or async job ID

    Examples:
        User: "Test the processOrder handler with order 123"
        → onex_invoke(
            function_name="order:processOrder",
            payload='{"orderId": "123"}'
          )

        User: "Send async email"
        → onex_invoke(
            function_name="email:sendEmail",
            payload='{"to": "user@example.com", "subject": "Test"}',
            is_async=True
          )
    """
    if env is None:
        env = get_active_environment()

    platform_url = _get_platform_url(env)
    headers = _auth_headers(env)

    if not headers:
        return f"Error: Authentication required. Run: onex login --env {env}"

    # Parse payload
    try:
        payload_data = json.loads(payload)
    except json.JSONDecodeError as e:
        return f"Invalid JSON payload: {e}"

    import uuid
    trace_id = str(uuid.uuid4())
    headers['X-Trace-ID'] = trace_id

    endpoint = f"{platform_url}/api/invoke/{'async' if is_async else 'sync'}"

    try:
        async with httpx.AsyncClient(timeout=timeout + 10) as client:
            resp = await client.post(
                endpoint,
                json={
                    'function_name': function_name,
                    'payload': payload_data
                },
                headers=headers
            )

        if is_async:
            if resp.status_code == 202:
                data = resp.json()
                return (
                    f"Async invoke accepted\n"
                    f"  NATS Subject: {data.get('subject', 'N/A')}\n"
                    f"  Message ID: {data.get('msg_id', 'N/A')}\n"
                    f"  Trace ID: {trace_id}\n"
                    f"\nMonitor: onex trace {trace_id} --env {env} --follow"
                )
            elif resp.status_code == 404:
                return f"Handler '{function_name}' not found. Use 'onex invoke --list' to see handlers."
            else:
                return f"Async invoke failed: HTTP {resp.status_code}\n{resp.text}"
        else:
            if resp.status_code == 200:
                data = resp.json()
                result = data.get('result')
                exec_time = data.get('execution_time_ms', 0)
                return (
                    f"Invoke successful\n"
                    f"  Handler: {function_name}\n"
                    f"  Execution time: {exec_time:.1f}ms\n"
                    f"  Trace ID: {trace_id}\n"
                    f"\nResult:\n{json.dumps(result, indent=2)}"
                )
            elif resp.status_code == 404:
                return f"Handler '{function_name}' not found. Use 'onex invoke --list' to see handlers."
            elif resp.status_code == 500:
                return f"Handler execution failed:\n{json.dumps(resp.json(), indent=2)}"
            else:
                return f"Invoke failed: HTTP {resp.status_code}\n{resp.text}"

    except httpx.ConnectError:
        return f"Cannot connect to platform at {platform_url}. Make sure platform is running."
    except httpx.TimeoutException:
        return f"Invoke timed out after {timeout} seconds. Use is_async=True for long-running tasks."
    except Exception as e:
        return f"Error invoking handler: {e}"


# =============================================================================
# ELASTICSEARCH TOOLS
# =============================================================================

@mcp.tool()
async def onex_es_reindex(
    service_name: str,
    collection: Optional[str] = None,
    env: str = None,
) -> str:
    """Reindex Elasticsearch from MongoDB for a service.

    Bulk reads all documents from MongoDB collections with es_sync triggers
    and indexes them into Elasticsearch. Use when ES is out of sync with MongoDB.

    Args:
        service_name: Service name to reindex (e.g., 'crm', 'product')
        collection: Optional specific collection to reindex (all es_sync collections if omitted)
        env: Environment (local/dev/staging/prod). Default: active environment

    Returns:
        Reindex results with doc counts and timing per collection

    Examples:
        User: "Reindex ES for the CRM service"
        → onex_es_reindex(service_name="crm")

        User: "Reindex just the adminService collection"
        → onex_es_reindex(service_name="crm", collection="adminService")

        User: "Reindex product service on dev"
        → onex_es_reindex(service_name="product", env="dev")
    """
    if env is None:
        env = get_active_environment()

    platform_url = _get_platform_url(env)

    body = {'service_name': service_name}
    if collection:
        body['collection'] = collection

    try:
        async with httpx.AsyncClient(timeout=300) as client:
            resp = await client.post(
                f"{platform_url}/_internal/reindex",
                json=body,
            )

        if resp.status_code == 200:
            data = resp.json()
            collections = data.get('collections', [])
            total = data.get('total_docs_synced', 0)

            if not collections:
                return f"No es_sync collections found for service '{service_name}'."

            lines = [f"Reindex results for {service_name}:", ""]
            for col in collections:
                name = col.get('collection', '?')
                index = col.get('index', '?')
                docs = col.get('docs_synced', 0)
                duration = col.get('duration_ms', 0)
                error = col.get('error')

                if error:
                    lines.append(f"  ❌ {name} → {index}: {error}")
                else:
                    lines.append(f"  ✅ {name} → {index}: {docs} docs ({duration}ms)")

            lines.append("")
            lines.append(f"Total: {total} docs synced across {len(collections)} collection(s)")
            return "\n".join(lines)

        elif resp.status_code == 404:
            detail = resp.json().get('detail', 'Not found')
            return f"No es_sync triggers found: {detail}"

        else:
            return f"Reindex failed: HTTP {resp.status_code}"

    except httpx.ConnectError:
        return f"Cannot connect to platform at {platform_url}. Make sure platform is running."
    except httpx.TimeoutException:
        return f"Reindex timed out (>5 minutes). Try reindexing one collection at a time."
    except Exception as e:
        return f"Error during reindex: {e}"


# =============================================================================
# VALIDATION TOOLS
# =============================================================================

@mcp.tool()
async def onex_validate(service_dir: str = ".") -> str:
    """Validate service.yml schema without deploying.

    Checks service configuration for:
    - Required fields (name, runtime, handler)
    - Valid route definitions
    - Resource configurations
    - Trigger configurations
    - Schema compliance

    Run this BEFORE deploying to catch configuration errors early.

    Args:
        service_dir: Path to service directory. Default: current directory

    Returns:
        Validation result with specific errors or success message

    Examples:
        User: "Validate my service.yml"
        → onex_validate()

        User: "Check if product service config is valid"
        → onex_validate(service_dir="../services/product")
    """
    try:
        from onex.schema.validator import validate_service_yml
        result = validate_service_yml(service_dir)

        if result.get('valid'):
            service_name = result.get('name', 'unknown')
            return (
                f"✅ service.yml is valid\n"
                f"  Service: {service_name}\n"
                f"  Routes: {result.get('route_count', 0)}\n"
                f"  Invokes: {result.get('invoke_count', 0)}\n"
                f"  Triggers: {result.get('trigger_count', 0)}"
            )
        else:
            errors = result.get('errors', [])
            lines = ["❌ Validation failed:", ""]
            for error in errors:
                lines.append(f"  - {error}")
            return "\n".join(lines)

    except FileNotFoundError:
        return f"No service.yml found in {service_dir}"
    except ImportError:
        return "Validation module not available. Make sure onex-cli is properly installed."
    except Exception as e:
        return f"Validation error: {e}"


# =============================================================================
# SERVICE SCAFFOLDING TOOLS
# =============================================================================

@mcp.tool()
async def onex_create(
    name: str,
    template: str,
    description: Optional[str] = None,
    author: Optional[str] = "platform-team",
    output: Optional[str] = None,
    no_validate: bool = False
) -> str:
    """Create new service from template.

    Scaffolds a new service with production-ready structure.
    Reduces time-to-first-service from 2 hours to under 5 minutes.

    Available templates:
    - minimal: Single endpoint, quickest deployment
    - rest-api: Full CRUD operations with database
    - event-driven: Schedules + NATS event handlers
    - crud-service: Layered architecture (models, repos, services)

    Args:
        name: Service name in kebab-case (e.g., 'my-product-service')
        template: Template type (minimal/rest-api/event-driven/crud-service)
        description: Service description (optional)
        author: Author/team name (default: 'platform-team')
        output: Output directory (default: ./services/<name>)
        no_validate: Skip validation after creation

    Returns:
        Success message with created files and next steps

    Examples:
        User: "Create a REST API service called product-catalog"
        → onex_create(name="product-catalog", template="rest-api")

        User: "Scaffold a minimal service for health checks"
        → onex_create(name="health-check", template="minimal",
                      description="Health check endpoint")

        User: "Generate an event-driven service for notifications"
        → onex_create(name="notification-service", template="event-driven",
                      description="Email and SMS notifications", author="backend-team")
    """
    # Use Click's CliRunner to invoke the create command
    # This avoids reimplementing template logic
    try:
        from click.testing import CliRunner
        from onex.commands.init_service import create as create_cmd

        runner = CliRunner()
        args = ['--name', name, '--template', template]
        if description:
            args.extend(['--description', description])
        if author:
            args.extend(['--author', author])
        if output:
            args.extend(['--output', output])
        if no_validate:
            args.append('--no-validate')

        result = runner.invoke(create_cmd, args, catch_exceptions=False)
        return result.output or "Service created successfully."

    except ImportError:
        return "Create command not available. Make sure onex-cli is properly installed."
    except Exception as e:
        return f"Error creating service: {e}"


@mcp.tool()
async def onex_replay(
    trace_id: str,
    env: str = None,
) -> str:
    """Replay a previously captured request by trace_id.

    Loads the original request snapshot and re-sends it through the platform,
    generating a new trace_id for the replayed request. Useful for:
    - Verifying a bug fix by re-sending the exact request that failed
    - Reproducing intermittent issues
    - Testing after deployment

    Args:
        trace_id: The trace_id of the original request to replay
        env: Environment (local/dev/staging/prod). Default: active environment

    Returns:
        New trace_id and status of the replayed request

    Examples:
        User: "Replay the failed request abc-123"
        -> onex_replay(trace_id="abc-123")

        User: "Re-send that request on dev"
        -> onex_replay(trace_id="abc-123", env="dev")
    """
    if env is None:
        env = get_active_environment()

    platform_url = _get_platform_url(env)
    headers = _auth_headers(env)

    if not headers:
        return f"Error: Authentication required. Run: onex login --env {env}"

    try:
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(
                f"{platform_url}/_internal/replay/{trace_id}",
                headers=headers,
            )

        if resp.status_code == 200:
            data = resp.json()
            method = data.get('method', '?')
            path = data.get('path', '?')
            status_code = data.get('status_code', '?')
            duration = data.get('duration_ms', '?')
            new_trace = data.get('new_trace_id', '?')

            return (
                f"Replayed: {method} {path}\n"
                f"Status: {status_code}\n"
                f"Duration: {duration}ms\n"
                f"New trace: {new_trace}\n"
                f"\nUse onex_trace(trace_id=\"{new_trace}\") to view the replayed request."
            )

        elif resp.status_code == 404:
            return (
                f"No replay snapshot found for trace_id: {trace_id}\n"
                "Snapshots expire after 24 hours."
            )
        elif resp.status_code == 401:
            return f"Authentication failed. Run: onex login --env {env}"
        else:
            return f"Replay failed: HTTP {resp.status_code}"

    except httpx.ConnectError:
        return f"Cannot connect to platform at {platform_url}. Make sure platform is running."
    except httpx.TimeoutException:
        return f"Request timed out connecting to {platform_url}"
    except Exception as e:
        return f"Error replaying request: {e}"


# =============================================================================
# E2E TESTING TOOLS
# =============================================================================

@mcp.tool()
async def onex_test(
    service_name: Optional[str] = None,
    env: Optional[str] = None,
    filter_expr: Optional[str] = None,
    maxfail: int = 5
) -> str:
    """Run E2E tests for a service against the platform.

    Executes pytest-based E2E tests that validate service CRUD endpoints.
    Tests run against a live platform environment.

    Args:
        service_name: Service to test (e.g., 'product', 'customer'). All if omitted.
        env: Environment (local/dev/staging/prod). Default: active environment.
        filter_expr: Pytest -k filter (e.g., 'test_create').
        maxfail: Stop after N failures. Default: 5.

    Returns:
        Test execution output with pass/fail summary

    Examples:
        User: "Run product E2E tests"
        -> onex_test(service_name="product")

        User: "Run all tests on staging"
        -> onex_test(env="staging")

        User: "Just run create tests for customer"
        -> onex_test(service_name="customer", filter_expr="test_01_create")
    """
    try:
        from click.testing import CliRunner
        from onex.commands.test import test as test_cmd

        runner = CliRunner()
        args = []
        if service_name:
            args.extend(['--service', service_name])
        if env:
            args.extend(['--env', env])
        if filter_expr:
            args.extend(['-k', filter_expr])
        if maxfail:
            args.extend(['--maxfail', str(maxfail)])

        result = runner.invoke(test_cmd, args, catch_exceptions=True)
        output = result.output or ""
        if result.exit_code != 0 and not output:
            output = f"Tests failed with exit code {result.exit_code}"
        return output

    except ImportError:
        return "Test command not available. Make sure onex-cli is properly installed."
    except Exception as e:
        return f"Error running tests: {e}"


@mcp.tool()
async def onex_create_e2e(
    service_name: str,
    entities: Optional[str] = None,
    services_dir: Optional[str] = None
) -> str:
    """Create E2E test scaffold for a service.

    Generates a test file (test_{service}_e2e.py) and data YAML (data/{service}.yml)
    with CRUD test cases for each entity. Auto-discovers entities from service.yml
    if available.

    Args:
        service_name: Service name (e.g., 'product', 'order')
        entities: Comma-separated entity names (auto-detected from service.yml if omitted)
        services_dir: Path to services repo (auto-detected if omitted)

    Returns:
        Success message with created files and next steps

    Examples:
        User: "Create E2E tests for the order service"
        -> onex_create_e2e(service_name="order")

        User: "Scaffold E2E tests for inventory with items and warehouses"
        -> onex_create_e2e(service_name="inventory", entities="item,warehouse")
    """
    try:
        from click.testing import CliRunner
        from onex.commands.create_e2e import create_e2e as create_e2e_cmd

        runner = CliRunner()
        args = ['--service', service_name]
        if entities:
            args.extend(['--entities', entities])
        if services_dir:
            args.extend(['--services-dir', services_dir])
        args.append('--force')

        result = runner.invoke(create_e2e_cmd, args, catch_exceptions=False)
        return result.output or "E2E tests scaffolded successfully."

    except ImportError:
        return "Create-e2e command not available. Make sure onex-cli is properly installed."
    except Exception as e:
        return f"Error creating E2E tests: {e}"


# =============================================================================
# SERVER MAIN
# =============================================================================

def main():
    """Main entry point for onex-mcp command."""
    # FastMCP will handle stdio transport automatically
    # No print statements allowed - will corrupt JSON-RPC messages
    try:
        mcp.run(transport="stdio")
    except KeyboardInterrupt:
        sys.exit(0)
    except Exception as e:
        print(f"Fatal error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
