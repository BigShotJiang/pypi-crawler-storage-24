"""DOCX 文档解析和渲染"""

import io
import threading
import zipfile
from lxml import etree

from .paragraph import Paragraph
from .table import Table
from .namespaces import NS


class DocxDocument:
    """DOCX 文档对象

    同一 ``DocxDocument`` 实例可在多线程环境下安全使用（内部使用可重入锁串行化访问）。
    不同实例之间无共享可变状态，可并行使用。多进程请各自持有独立实例。
    """

    def __init__(self, zip_data: bytes):
        self._zip_data = zip_data
        self._zip = zipfile.ZipFile(io.BytesIO(zip_data))
        self._document_xml = None
        self._body = None
        self._comments = []
        self._comment_id_counter = 0
        self._lock = threading.RLock()

    @classmethod
    def parse(cls, docx_bytes: bytes, *, keep_comments: bool = False) -> "DocxDocument":
        """解析 DOCX 并构建文档对象

        Args:
            keep_comments: 是否保留原有批注。默认 False（清空所有原有批注）。
        """
        doc = cls(docx_bytes)
        doc._load_document(keep_comments=keep_comments)
        return doc

    def _load_document(self, *, keep_comments: bool):
        """加载 document.xml，并按需保留/清空原有批注"""
        doc_xml = self._zip.read("word/document.xml")
        self._document_xml = etree.fromstring(doc_xml)
        self._body = self._document_xml.find(".//w:body", NS)

        if keep_comments:
            # 加载已有的批注
            self._load_existing_comments()
        else:
            # 默认不保留：清空 comments 列表，并移除 document.xml 中的批注标记
            self._comments = []
            self._comment_id_counter = 0
            self._strip_all_comment_markers()

    def _strip_all_comment_markers(self) -> None:
        """移除 document.xml 中所有批注相关标记，避免残留引用。"""
        if self._document_xml is None:
            return

        # commentRangeStart / commentRangeEnd
        for tag in ("commentRangeStart", "commentRangeEnd"):
            for el in self._document_xml.findall(f".//w:{tag}", NS):
                parent = el.getparent()
                if parent is not None:
                    parent.remove(el)

        # commentReference 位于 w:r 内；移除后若 run 为空则一并移除
        for ref in self._document_xml.findall(".//w:commentReference", NS):
            run = ref.getparent()
            if run is None:
                continue
            run.remove(ref)
            if (
                len(run) == 0
                and (run.text is None)
                and (run.tail is None or run.tail == "")
            ):
                parent = run.getparent()
                if parent is not None:
                    parent.remove(run)

    def _load_existing_comments(self):
        """加载已有的批注"""
        try:
            comments_xml = self._zip.read("word/comments.xml")
            comments_tree = etree.fromstring(comments_xml)

            max_id = -1
            for comment in comments_tree:
                comment_id_str = comment.get(f"{{{NS['w']}}}id")
                if comment_id_str:
                    comment_id = int(comment_id_str)
                    max_id = max(max_id, comment_id)

                    # 提取批注内容
                    author = comment.get(f"{{{NS['w']}}}author", "")
                    text = self._extract_comment_text(comment)

                    self._comments.append((comment_id, text, author))

            # 设置下一个批注 ID
            self._comment_id_counter = max_id + 1
        except KeyError:
            # 没有 comments.xml 文件
            pass

    def _extract_comment_text(self, comment_element: etree._Element) -> str:
        """从 w:comment 中提取完整文本（按 w:p 插入换行）。"""
        parts: list[str] = []
        first_para = True

        # comments.xml 内部结构通常是多个 w:p
        for p in comment_element.findall(".//w:p", NS):
            if not first_para:
                parts.append("\n")
            first_para = False

            for run in p.findall(".//w:r", NS):
                for child in run:
                    tag = etree.QName(child.tag).localname
                    if tag == "t":
                        if child.text:
                            parts.append(child.text)
                    elif tag == "br":
                        parts.append("\n")
                    elif tag == "tab":
                        parts.append("\t")

        return "".join(parts)

    def blocks(self) -> tuple[Paragraph | Table, ...]:
        """返回文档中的块级元素（元组）"""
        with self._lock:
            if self._body is None:
                return ()

            blocks: list[Paragraph | Table] = []
            for child in self._body:
                tag = etree.QName(child.tag).localname
                if tag == "p":
                    blocks.append(Paragraph(child, self))
                elif tag == "tbl":
                    blocks.append(Table(child, self))
            return tuple(blocks)

    def add_comment(self, text: str, author: str = "docxnote") -> int:
        """添加批注并返回 ID"""
        with self._lock:
            comment_id = self._comment_id_counter
            self._comment_id_counter += 1
            self._comments.append((comment_id, text, author))
            return comment_id

    def render(self) -> bytes:
        """生成新的 DOCX 并返回 bytes"""
        with self._lock:
            return self._render_unlocked()

    def _render_unlocked(self) -> bytes:
        output = io.BytesIO()

        with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as out_zip:
            # 准备 rels 和 content types（如果有批注）
            rels_data = None
            content_types_data = None
            if self._comments:
                rels_data = self._prepare_rels()
                content_types_data = self._prepare_content_types()

            # 复制所有原始文件
            for item in self._zip.namelist():
                if item == "word/document.xml":
                    continue
                if item == "word/comments.xml":
                    continue
                if item == "word/_rels/document.xml.rels" and rels_data is not None:
                    continue
                if item == "[Content_Types].xml" and content_types_data is not None:
                    continue
                out_zip.writestr(item, self._zip.read(item))

            # 写入修改后的 document.xml
            doc_bytes = etree.tostring(
                self._document_xml,
                xml_declaration=True,
                encoding="UTF-8",
                standalone=True,
            )
            out_zip.writestr("word/document.xml", doc_bytes)

            # 写入 comments.xml、rels 和 content types
            if self._comments:
                comments_xml = self._build_comments_xml()
                out_zip.writestr("word/comments.xml", comments_xml)
                out_zip.writestr("word/_rels/document.xml.rels", rels_data)
                out_zip.writestr("[Content_Types].xml", content_types_data)

        return output.getvalue()

    def _build_comments_xml(self) -> bytes:
        """构建 comments.xml"""
        root = etree.Element(f"{{{NS['w']}}}comments", nsmap=NS)

        for comment_id, text, author in self._comments:
            comment = etree.SubElement(
                root,
                f"{{{NS['w']}}}comment",
                attrib={
                    f"{{{NS['w']}}}id": str(comment_id),
                    f"{{{NS['w']}}}author": author,
                    f"{{{NS['w']}}}date": "2024-01-01T00:00:00Z",
                    f"{{{NS['w']}}}initials": author[0].upper() if author else "D",
                },
            )

            # 按换行拆分为多个段落，尽量保留原批注的多段结构
            lines = text.split("\n")
            if not lines:
                lines = [""]

            for line in lines:
                p = etree.SubElement(comment, f"{{{NS['w']}}}p")
                r = etree.SubElement(p, f"{{{NS['w']}}}r")

                # 处理 tab：用 w:tab 表示
                if "\t" in line:
                    buf: list[str] = []
                    for ch in line:
                        if ch == "\t":
                            if buf:
                                t = etree.SubElement(r, f"{{{NS['w']}}}t")
                                seg = "".join(buf)
                                if seg[:1] == " " or seg[-1:] == " ":
                                    t.set(
                                        "{http://www.w3.org/XML/1998/namespace}space",
                                        "preserve",
                                    )
                                t.text = seg
                                buf.clear()
                            etree.SubElement(r, f"{{{NS['w']}}}tab")
                        else:
                            buf.append(ch)
                    if buf or line == "":
                        t = etree.SubElement(r, f"{{{NS['w']}}}t")
                        seg = "".join(buf)
                        if seg[:1] == " " or seg[-1:] == " ":
                            t.set(
                                "{http://www.w3.org/XML/1998/namespace}space",
                                "preserve",
                            )
                        t.text = seg
                else:
                    t = etree.SubElement(r, f"{{{NS['w']}}}t")
                    if line[:1] == " " or line[-1:] == " ":
                        t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
                    t.text = line

        return etree.tostring(
            root, xml_declaration=True, encoding="UTF-8", standalone=True
        )

    def _prepare_rels(self) -> bytes:
        """准备 document.xml.rels 数据以包含 comments.xml 关系"""
        rels_path = "word/_rels/document.xml.rels"

        try:
            rels_data = self._zip.read(rels_path)
            rels_xml = etree.fromstring(rels_data)
        except KeyError:
            # 创建新的 rels
            rels_xml = etree.Element(
                "Relationships",
                nsmap={
                    "": "http://schemas.openxmlformats.org/package/2006/relationships"
                },
            )

        # 检查是否已有 comments 关系
        has_comments = False
        for rel in rels_xml:
            if (
                rel.get("Type")
                == "http://schemas.openxmlformats.org/officeDocument/2006/relationships/comments"
            ):
                has_comments = True
                break

        if not has_comments:
            # 添加 comments 关系
            max_id = 0
            for rel in rels_xml:
                rel_id = rel.get("Id", "")
                if rel_id.startswith("rId"):
                    try:
                        num = int(rel_id[3:])
                        max_id = max(max_id, num)
                    except ValueError:
                        pass

            etree.SubElement(
                rels_xml,
                "Relationship",
                attrib={
                    "Id": f"rId{max_id + 1}",
                    "Type": "http://schemas.openxmlformats.org/officeDocument/2006/relationships/comments",
                    "Target": "comments.xml",
                },
            )

        return etree.tostring(rels_xml, xml_declaration=True, encoding="UTF-8")

    def _prepare_content_types(self) -> bytes:
        """准备 [Content_Types].xml 数据以包含 comments.xml"""
        ct_data = self._zip.read("[Content_Types].xml")
        ct_xml = etree.fromstring(ct_data)

        # 获取命名空间
        ns = ct_xml.nsmap.get(
            None, "http://schemas.openxmlformats.org/package/2006/content-types"
        )

        # 检查是否已有 comments.xml 的 Override
        has_comments_override = False
        for override in ct_xml:
            if override.get("PartName") == "/word/comments.xml":
                has_comments_override = True
                break

        if not has_comments_override:
            # 添加 comments.xml 的 Override
            override_elem = etree.Element(
                f"{{{ns}}}Override",
                attrib={
                    "PartName": "/word/comments.xml",
                    "ContentType": "application/vnd.openxmlformats-officedocument.wordprocessingml.comments+xml",
                },
            )
            ct_xml.append(override_elem)

        return etree.tostring(ct_xml, xml_declaration=True, encoding="UTF-8")
