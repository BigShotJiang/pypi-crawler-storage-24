"""System metrics collection — GPU, CPU, memory via background thread."""

from __future__ import annotations

import threading
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from simpcat.experiment import Run


class _NvmlSession:
    """Manages a single nvmlInit/nvmlShutdown lifecycle."""

    def __init__(self) -> None:
        self._initialized = False
        try:
            import pynvml
            self._pynvml = pynvml
            pynvml.nvmlInit()
            self._initialized = True
        except (ImportError, Exception):
            self._pynvml = None

    def collect(self) -> dict[str, float]:
        if not self._initialized or self._pynvml is None:
            return {}
        pynvml = self._pynvml
        metrics: dict[str, float] = {}
        try:
            count = pynvml.nvmlDeviceGetCount()
            for i in range(count):
                handle = pynvml.nvmlDeviceGetHandleByIndex(i)

                try:
                    util = pynvml.nvmlDeviceGetUtilizationRates(handle)
                    metrics[f"sys/gpu.{i}.utilization"] = float(util.gpu)
                    metrics[f"sys/gpu.{i}.memory_utilization"] = float(util.memory)
                except pynvml.NVMLError:
                    pass

                try:
                    mem = pynvml.nvmlDeviceGetMemoryInfo(handle)
                    metrics[f"sys/gpu.{i}.memory_used_gb"] = mem.used / (1024**3)
                    metrics[f"sys/gpu.{i}.memory_total_gb"] = mem.total / (1024**3)
                except pynvml.NVMLError:
                    pass

                try:
                    temp = pynvml.nvmlDeviceGetTemperature(handle, pynvml.NVML_TEMPERATURE_GPU)
                    metrics[f"sys/gpu.{i}.temperature"] = float(temp)
                except pynvml.NVMLError:
                    pass

                try:
                    power = pynvml.nvmlDeviceGetPowerUsage(handle)
                    metrics[f"sys/gpu.{i}.power_w"] = power / 1000.0
                except pynvml.NVMLError:
                    pass
        except pynvml.NVMLError:
            pass
        return metrics

    def shutdown(self) -> None:
        if self._initialized and self._pynvml is not None:
            try:
                self._pynvml.nvmlShutdown()
            except Exception:
                pass
            self._initialized = False


def _collect_cpu_metrics() -> dict[str, float]:
    """Collect CPU/memory/disk metrics using psutil. Returns empty dict if unavailable."""
    try:
        import psutil
    except ImportError:
        return {}

    metrics: dict[str, float] = {}
    try:
        metrics["sys/cpu_percent"] = psutil.cpu_percent(interval=None)
    except Exception:
        pass

    try:
        mem = psutil.virtual_memory()
        metrics["sys/memory_used_gb"] = mem.used / (1024**3)
        metrics["sys/memory_total_gb"] = mem.total / (1024**3)
        metrics["sys/memory_percent"] = mem.percent
    except Exception:
        pass

    try:
        disk = psutil.disk_usage("/")
        metrics["sys/disk_used_gb"] = disk.used / (1024**3)
        metrics["sys/disk_percent"] = disk.percent
    except Exception:
        pass

    return metrics


def _has_collection_libs() -> bool:
    """Check if at least one collection library is importable."""
    try:
        import psutil  # noqa: F401
        return True
    except ImportError:
        pass
    try:
        import pynvml  # noqa: F401
        return True
    except ImportError:
        pass
    return False


class SystemMetricsCollector:
    """Background thread that periodically collects system metrics and logs them."""

    def __init__(self, run: Run, interval: float = 15.0) -> None:
        self._run = run
        self._interval = interval
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None
        self._nvml: _NvmlSession | None = None
        # Only start the thread if collection libraries are available
        if _has_collection_libs():
            self._nvml = _NvmlSession()
            # Prime psutil.cpu_percent so the first real call returns a meaningful value
            try:
                import psutil
                psutil.cpu_percent(interval=None)
            except (ImportError, Exception):
                pass
            self._thread = threading.Thread(target=self._loop, daemon=True, name="simpcat-sysmetrics")
            self._thread.start()

    def _loop(self) -> None:
        while not self._stop_event.wait(timeout=self._interval):
            metrics: dict[str, float] = {}
            if self._nvml is not None:
                metrics.update(self._nvml.collect())
            metrics.update(_collect_cpu_metrics())
            if metrics:
                with self._run._lock:
                    client = self._run._client
                    step = self._run._current_step
                if client is not None:
                    client.send_step(step, metrics)

    def stop(self) -> None:
        self._stop_event.set()
        if self._thread is not None:
            self._thread.join(timeout=2.0)
        if self._nvml is not None:
            self._nvml.shutdown()
            self._nvml = None
