"""Capture git provenance info at run init time."""

from __future__ import annotations

import subprocess
from typing import Any


def _git_cmd(*args: str, check: bool = True, timeout: int | None = None) -> str | None:
    """Run a git command and return stripped stdout, or None on failure."""
    try:
        result = subprocess.run(
            ["git", *args],
            capture_output=True, text=True, check=check, timeout=timeout,
        )
        if not check and result.returncode != 0:
            return None
        return result.stdout.strip()
    except (OSError, subprocess.CalledProcessError, subprocess.SubprocessError):
        return None


def get_git_info() -> dict[str, Any] | None:
    """Capture git commit hash, branch, remote, and dirty status.

    Returns None if not in a git repo or git is not available.
    """
    if _git_cmd("rev-parse", "--git-dir") is None:
        return None

    info: dict[str, Any] = {}

    commit = _git_cmd("rev-parse", "HEAD")
    if commit:
        info["commit"] = commit

    branch = _git_cmd("rev-parse", "--abbrev-ref", "HEAD")
    if branch:
        info["branch"] = branch

    remote = _git_cmd("remote", "get-url", "origin")
    if remote:
        info["remote"] = remote

    status = _git_cmd("status", "--porcelain")
    if status is not None:
        info["dirty"] = len(status) > 0

    diff_stat = _git_cmd("diff", "HEAD", "--stat", check=False, timeout=10)
    if diff_stat:
        info["diff_stat"] = diff_stat

    return info if info else None
