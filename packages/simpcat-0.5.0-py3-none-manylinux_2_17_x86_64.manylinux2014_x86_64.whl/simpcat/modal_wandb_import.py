"""Modal launcher for control-plane-managed W&B import jobs."""

from __future__ import annotations

import hmac
import json
import os
import urllib.error
import urllib.request
import subprocess
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Mapping

try:  # pragma: no cover - exercised in deployment, not unit tests
    import modal
except ImportError:  # pragma: no cover - local tests don't require Modal
    modal = None  # type: ignore[assignment]

LAUNCHER_SECRET_ENV = "WANDB_IMPORT_LAUNCHER_TOKEN"
LAUNCHER_SECRET_NAME_ENV = "WANDB_IMPORT_MODAL_SECRET_NAME"
DEFAULT_LAUNCHER_SECRET_NAME = "simpcat-wandb-import-runtime"
REMOTE_REPORTER_ROOT = "/root/reporter"
REMOTE_SIMPCAT_BIN = f"{REMOTE_REPORTER_ROOT}/target/release/simpcat"
IMPORT_TIMEOUT_SECONDS = 12 * 60 * 60
MODAL_APP_NAME = "simpcat-wandb-import"
MODAL_SECRET_NAME = os.environ.get(
    LAUNCHER_SECRET_NAME_ENV,
    DEFAULT_LAUNCHER_SECRET_NAME,
)
MODAL_FUNCTION_ENV = {
    LAUNCHER_SECRET_NAME_ENV: MODAL_SECRET_NAME,
}
MODAL_IGNORE_PATTERNS = [
    "target",
    "target/**",
    ".venv",
    ".venv/**",
    ".pytest_cache",
    ".pytest_cache/**",
    "__pycache__",
    "**/__pycache__",
    "*.pyc",
]


@dataclass(frozen=True)
class LaunchRequest:
    source: str
    job_id: str
    job_token: str
    worker_base_url: str
    ingest_api_key: str



def _reporter_root() -> Path:
    env_root = os.environ.get("SIMPCAT_REPORTER_ROOT")
    if env_root:
        return Path(env_root)

    current = Path(__file__).resolve()
    for candidate in [current.parent, *current.parents]:
        if (candidate / "Cargo.toml").exists():
            return candidate

    return Path(REMOTE_REPORTER_ROOT)


def parse_launch_request(payload: Mapping[str, Any]) -> LaunchRequest:
    if not isinstance(payload, Mapping):
        raise ValueError("JSON body must be an object")

    def require_string(key: str) -> str:
        value = payload.get(key)
        if not isinstance(value, str) or not value.strip():
            raise ValueError(f"{key} is required")
        return value.strip()

    source = require_string("source")
    if source != "wandb":
        raise ValueError("source must be 'wandb'")

    return LaunchRequest(
        source=source,
        job_id=require_string("job_id"),
        job_token=require_string("job_token"),
        worker_base_url=require_string("worker_base_url").rstrip("/"),
        ingest_api_key=require_string("ingest_api_key"),
    )


def authorize_launcher_request(auth_header: str | None, expected_token: str | None) -> None:
    if not expected_token:
        return
    if not auth_header or not auth_header.startswith("Bearer "):
        raise PermissionError("Missing Authorization header")
    provided_token = auth_header.removeprefix("Bearer ").strip()
    if not hmac.compare_digest(provided_token, expected_token):
        raise PermissionError("Invalid launcher token")


def build_simpcat_command(request: LaunchRequest) -> list[str]:
    return [
        REMOTE_SIMPCAT_BIN,
        "import-job",
        "wandb",
        "--host",
        request.worker_base_url,
        "--job-id",
        request.job_id,
    ]


def _cf_access_headers() -> dict[str, str]:
    headers: dict[str, str] = {}
    client_id = os.environ.get("CF_ACCESS_CLIENT_ID")
    client_secret = os.environ.get("CF_ACCESS_CLIENT_SECRET")
    if client_id:
        headers["CF-Access-Client-Id"] = client_id
    if client_secret:
        headers["CF-Access-Client-Secret"] = client_secret
    return headers


def report_import_failure(request: LaunchRequest, error: str) -> None:
    url = (
        f"{request.worker_base_url}/v1/wandb/internal/import-jobs/"
        f"{request.job_id}/fail"
    )
    body = json.dumps({"error": error}).encode("utf-8")
    headers = {
        "Authorization": f"Bearer {request.job_token}",
        "Content-Type": "application/json",
        **_cf_access_headers(),
    }
    http_request = urllib.request.Request(
        url,
        data=body,
        headers=headers,
        method="POST",
    )
    try:
        with urllib.request.urlopen(http_request, timeout=30):
            return
    except urllib.error.URLError:
        return


def run_import_subprocess(request: LaunchRequest) -> None:
    command = build_simpcat_command(request)
    env = os.environ.copy()
    env.setdefault("RUST_LOG", "info")
    env["SIMPCAT_IMPORT_JOB_TOKEN"] = request.job_token
    env["SIMPCAT_IMPORT_INGEST_API_KEY"] = request.ingest_api_key
    try:
        subprocess.run(
            command,
            check=True,
            cwd=REMOTE_REPORTER_ROOT,
            env=env,
            timeout=IMPORT_TIMEOUT_SECONDS,
        )
    except subprocess.TimeoutExpired as exc:
        report_import_failure(request, f"Executor timed out after {IMPORT_TIMEOUT_SECONDS}s")
        raise RuntimeError(
            f"W&B import executor timed out after {IMPORT_TIMEOUT_SECONDS}s"
        ) from exc
    except subprocess.CalledProcessError as exc:
        report_import_failure(request, f"Executor exited with status {exc.returncode}")
        raise


def _modal_secrets() -> list[Any]:
    if modal is None:
        return []
    return [modal.Secret.from_name(MODAL_SECRET_NAME)]


if modal is not None:  # pragma: no branch - guarded for local test environments
    from fastapi import HTTPException, Request

    app = modal.App(MODAL_APP_NAME)
    image = (
        modal.Image.debian_slim(python_version="3.12")
        .pip_install("fastapi>=0.115,<1")
        .apt_install("curl", "build-essential", "pkg-config", "cmake", "perl")
        .run_commands(
            "curl https://sh.rustup.rs -sSf | sh -s -- -y --profile minimal",
            "ln -sf /root/.cargo/bin/cargo /usr/local/bin/cargo",
            "ln -sf /root/.cargo/bin/rustc /usr/local/bin/rustc",
        )
        .add_local_dir(
            _reporter_root(),
            remote_path=REMOTE_REPORTER_ROOT,
            copy=True,
            ignore=MODAL_IGNORE_PATTERNS,
        )
        .workdir(REMOTE_REPORTER_ROOT)
        .run_commands("cargo build --release --locked --bin simpcat")
    )

    @app.function(
        image=image,
        timeout=IMPORT_TIMEOUT_SECONDS,
        cpu=2,
        memory=8192,
        env=MODAL_FUNCTION_ENV,
        secrets=_modal_secrets(),
    )
    def execute_wandb_import(payload: dict[str, str]) -> None:
        request = parse_launch_request(payload)
        run_import_subprocess(request)


    @app.function(
        image=image,
        timeout=300,
        env=MODAL_FUNCTION_ENV,
        secrets=_modal_secrets(),
    )
    @modal.fastapi_endpoint(method="POST", docs=True)
    async def launch_wandb_import(
        payload: dict[str, Any],
        request: Request,
    ) -> dict[str, str]:
        try:
            authorize_launcher_request(
                request.headers.get("authorization"),
                os.environ.get(LAUNCHER_SECRET_ENV),
            )
            launch_request = parse_launch_request(payload)
        except PermissionError as exc:
            raise HTTPException(status_code=401, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

        call = await execute_wandb_import.spawn.aio(asdict(launch_request))
        return {"execution_id": call.object_id}


    @app.local_entrypoint()
    def main() -> None:
        print("Deploy with: modal deploy reporter/python/simpcat/modal_wandb_import.py")
