import subprocess
import sys
from pathlib import Path

import click
import llm
import questionary


def _run_hook():
    """Run the pre-commit hook if installed. Returns True if it passed or isn't installed."""
    hook_path = Path(".git") / "hooks" / "pre-commit"

    if not hook_path.exists():
        return True

    click.echo("Running pre-commit hook...")
    result = subprocess.run([str(hook_path)])

    if result.returncode != 0:
        click.echo("Pre-commit hook failed. Fix the issues before committing.")
        return False

    return True


def _get_diff():
    """Get both staged and unstaged changes"""
    staged = subprocess.run(
        ["git", "diff", "--staged", "--patch"],
        capture_output=True,
        text=True,
    ).stdout.strip()

    unstaged = subprocess.run(
        ["git", "diff", "--patch"],
        capture_output=True,
        text=True,
    ).stdout.strip()

    parts = [p for p in (staged, unstaged) if p]
    return "\n".join(parts)


def _run(cmd):
    """Run a command with live output, exit cleanly on failure"""
    result = subprocess.run(cmd)
    if result.returncode != 0:
        sys.exit(result.returncode)


def commit(model, yes):
    diff = _get_diff()

    if not diff:
        click.echo("No changes detected.")
        sys.exit(1)

    _run(["git", "add", "--all"])

    if not _run_hook():
        sys.exit(1)

    llm_model = llm.get_model(model)
    response = llm_model.prompt(
        diff,
        system="Write a concise conventional commit message. Max 1 line. If TODO.md or README.md was changed alongside other files, ignore the TODO.md and README.md changes entirely and focus only on the other files. Only describe TODO.md or README.md changes if they are the sole files modified.",
    )
    msg = response.text().strip()

    if not msg:
        click.echo("Failed to generate commit message.")
        sys.exit(1)

    if yes:
        _run(["git", "commit", "-m", msg])
        return

    while True:
        click.echo(f"\n{msg}\n")

        action = questionary.select(
            "What would you like to do?",
            choices=["Commit and push", "Commit", "Edit", "Cancel"],
        ).ask()

        if action is None or action == "Cancel":
            click.echo("Commit aborted.")
            return

        if action == "Edit":
            edited = questionary.text("Edit commit message:", default=msg).ask()

            if edited is None:
                click.echo("Commit aborted.")
                return

            msg = edited.strip()
            continue

        _run(["git", "commit", "-m", msg])

        if action == "Commit and push":
            _run(["git", "push"])

        return
