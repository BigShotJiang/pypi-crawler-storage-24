from pathlib import Path

import click
import sys
import subprocess


def find_root():
    current = Path().resolve()

    while not (current / "pyproject.toml").exists():
        if current == current.parent:
            sys.exit(
                (
                    "Could not find project root."
                    "Please add a pyproject.toml file in the root folder."
                )
            )

        current = current.parent

    return str(current)


class Runner:
    def __init__(self, cwd) -> None:
        self._cwd = cwd
        self._errors = []

    def run(self, cmd, fix):
        cmd_ = " ".join(cmd)
        header = "=" * 20
        click.echo(f"{header} Running: {cmd_} {header}")
        res = subprocess.run(cmd, cwd=self._cwd)

        if res.returncode:
            self._errors.append((cmd_, fix))

    def check(self):
        if self._errors:
            for cmd, fix in self._errors:
                click.echo(f"The following command failed: {cmd}\\nTo fix it: {fix}")

            return 1
        else:
            click.echo("All checks passed!")
            return 0


def _lint(files=None, exclude=None):
    files = files or []
    exclude = exclude or []

    if len(files) == 0:
        files = ["."]
    else:
        files = list(files)

    cmd_check = ["ruff", "check"] + files
    cmd_format = ["ruff", "format", "--check"] + files

    for exc in exclude:
        cmd_check += ["--extend-exclude", exc]
        cmd_format += ["--exclude", exc]

    runner = Runner(find_root())
    runner.run(cmd_check, fix="Run: ruff check --fix")
    runner.run(cmd_format, fix="Run: projctl format")

    return runner.check()


def create_hook(force=False):
    """Create a pre-commit hook that fixes and re-stages staged Python files."""
    git_dir = Path(".git")
    if not git_dir.exists() or not git_dir.is_dir():
        raise click.UsageError("Could not find a .git directory in the current path.")

    hook_path = git_dir / "hooks" / "pre-commit"
    hook_path.parent.mkdir(parents=True, exist_ok=True)

    if hook_path.exists() and not force:
        raise click.UsageError(
            f"Hook already exists at {hook_path}. Use --force to overwrite."
        )

    hook_content = """#!/usr/bin/env sh
set -e

staged_python_files="$(git diff --cached --name-only --diff-filter=ACMR -- '*.py' '*.pyi')"

if [ -z "$staged_python_files" ]; then
    exit 0
fi

echo "$staged_python_files" | while IFS= read -r file; do
    [ -z "$file" ] && continue
    ruff format "$file"
    ruff check --fix "$file"
    git add "$file"
done
"""
    hook_path.write_text(hook_content, encoding="utf-8")
    hook_path.chmod(0o755)

    click.secho(f"Created pre-commit hook at {hook_path}", fg="green")
