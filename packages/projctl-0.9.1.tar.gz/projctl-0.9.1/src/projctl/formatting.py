from pathlib import Path
import sys
import subprocess
import click
from shlex import quote


def find_root():
    current = Path().resolve()

    while not (current / "pyproject.toml").exists():
        if current == current.parent:
            sys.exit(
                (
                    "Could not find project root."
                    "Please add a pyproject.toml file in the root folder."
                )
            )

        current = current.parent

    return str(current)


def format(exclude):
    current = find_root()

    cmd = ["ruff", "format", "."]

    for exc in exclude:
        cmd += ["--exclude", exc]

    click.echo("Running command:" + " ".join(map(quote, cmd)))
    res = subprocess.run(cmd, cwd=current)

    if res.returncode:
        click.echo()
        sys.exit("***ruff format returned errors.***")

    click.echo("Finished formatting with ruff!")
