"""Sort TODO.md by importance and difficulty tags on H3 headings."""

import re
from pathlib import Path

import click

try:
    import mistune
    from mistune.renderers.markdown import MarkdownRenderer
    from mistune.core import BlockState
except ModuleNotFoundError:
    mistune = None
    MarkdownRenderer = None
    BlockState = None

IMPORTANCE_VALUES = {"CRITICAL", "HIGH", "LOW"}
DIFFICULTY_VALUES = {"EASY", "MEDIUM", "HARD"}

IMPORTANCE_ORDER = {"CRITICAL": 0, "HIGH": 1, "LOW": 2}
DIFFICULTY_ORDER = {"EASY": 0, "MEDIUM": 1, "HARD": 2}


def _find_todo_md():
    """Find TODO.md by searching up to 6 directory levels from cwd."""
    directory = Path.cwd()

    for _ in range(6):
        candidate = directory / "TODO.md"

        if candidate.exists():
            return candidate

        directory = directory.parent

    raise click.ClickException(
        "Could not find TODO.md (searched up to 6 levels from current directory)"
    )


def _get_heading_text(token):
    """Extract full text from a heading token's children."""
    parts = []

    for child in token.get("children", []):
        if child["type"] in ("text", "codespan"):
            parts.append(child["raw"])
        elif child["type"] == "link":
            children = child.get("children", [])
            if children:
                parts.append(children[0]["raw"])
        else:
            parts.append(child.get("raw", ""))

    return "".join(parts)


def _parse_tag(heading_text):
    """Parse [IMPORTANCE, DIFFICULTY] and optional [ACTIVE] tag from heading text.

    Returns (importance, difficulty, normalized_heading, active) or
    (None, None, heading_text, False) if no tag is present.
    Raises click.ClickException on invalid format.
    """
    # Strip [ACTIVE] and [DONE] anywhere in the heading before parsing [X, Y]
    active = False
    active_match = re.search(r"\s*\[\s*active\s*\]\s*", heading_text, re.IGNORECASE)
    if active_match:
        active = True
        heading_text = (
            heading_text[: active_match.start()] + heading_text[active_match.end() :]
        ).strip()

    done = False
    done_match = re.search(r"\s*\[\s*done\s*\]\s*", heading_text, re.IGNORECASE)
    if done_match:
        done = True
        heading_text = (
            heading_text[: done_match.start()] + heading_text[done_match.end() :]
        ).strip()

    if active and done:
        raise click.ClickException(
            f"Invalid tag in heading '{heading_text}': "
            "[DONE] and [ACTIVE] cannot be combined"
        )

    open_count = heading_text.count("[")
    close_count = heading_text.count("]")

    if open_count == 0 and close_count == 0:
        if active:
            normalized = f"{heading_text} [ACTIVE]"
            return None, None, normalized, True
        if done:
            normalized = f"{heading_text} [DONE]"
            return "DONE", None, normalized, False
        return None, None, heading_text, False

    if open_count != 1 or close_count != 1:
        raise click.ClickException(
            f"Invalid bracket format in heading '{heading_text}': "
            "expected exactly one '[' and one ']'"
        )

    match = re.match(r"^(.*?)\s*\[\s*([^]]*)\s*\]\s*$", heading_text)
    if not match:
        raise click.ClickException(
            f"Invalid tag format in heading '{heading_text}': "
            "tag must be at the end in the format [X, Y]"
        )

    title = match.group(1).strip()
    tag_content = match.group(2).strip()

    parts = [p.strip().upper() for p in tag_content.split(",")]
    if len(parts) != 2:
        raise click.ClickException(
            f"Invalid tag in heading '{heading_text}': "
            "expected two values separated by a comma, e.g. [HIGH, EASY]"
        )

    val1, val2 = parts

    if val1 in IMPORTANCE_VALUES and val2 in DIFFICULTY_VALUES:
        importance, difficulty = val1, val2
    elif val1 in DIFFICULTY_VALUES and val2 in IMPORTANCE_VALUES:
        importance, difficulty = val2, val1
    else:
        raise click.ClickException(
            f"Invalid tag values in heading '{heading_text}': "
            f"one value must be importance (CRITICAL, HIGH, LOW) "
            f"and the other difficulty (EASY, MEDIUM, HARD)"
        )

    normalized = f"{title} [{importance}, {difficulty}]"
    if done:
        normalized = f"{normalized} [DONE]"
        return "DONE", None, normalized, False
    if active:
        normalized = f"{normalized} [ACTIVE]"
    return importance, difficulty, normalized, active


def _update_heading_tag(token, normalized_heading):
    """Return a copy of the heading token with the normalized tag.

    Handles the case where mistune splits '[' into a separate text token.
    Preserves all children before the bracket and replaces from the bracket
    onwards with the normalized tag.
    """
    children = token.get("children", [])

    # Find the first child containing '['
    bracket_child_idx = None
    bracket_pos = None

    for i, child in enumerate(children):
        raw = child.get("raw", "")
        if "[" in raw:
            bracket_child_idx = i
            bracket_pos = raw.index("[")
            break

    if bracket_child_idx is None:
        new_token = dict(token)
        new_token["children"] = [{"type": "text", "raw": normalized_heading}]
        return new_token

    norm_bracket_idx = normalized_heading.index("[")
    normalized_tag = normalized_heading[norm_bracket_idx:]

    # Keep children before the bracket, truncate at bracket, append normalized tag
    new_children = list(children[:bracket_child_idx])

    prefix = children[bracket_child_idx]["raw"][:bracket_pos]
    if prefix:
        new_children.append({"type": "text", "raw": prefix})

    new_children.append({"type": "text", "raw": normalized_tag})

    new_token = dict(token)
    new_token["children"] = new_children
    return new_token


def _sort_key(element):
    """Sort key: active first, then tagged (by importance/difficulty), untagged last."""
    active = element.get("active", False)
    tagged = element["importance"] is not None

    if active and tagged:
        return (
            0,
            0,
            IMPORTANCE_ORDER[element["importance"]],
            DIFFICULTY_ORDER[element["difficulty"]],
        )
    elif active:
        return (0, 1, 0, 0)
    elif tagged:
        return (
            1,
            0,
            IMPORTANCE_ORDER[element["importance"]],
            DIFFICULTY_ORDER[element["difficulty"]],
        )
    else:
        return (1, 1, 0, 0)


def _has_todo_tag(heading_text):
    """Check if heading text contains tags meant for H3 items ([X, Y], [done], [active])."""
    has_done = bool(re.search(r"\[\s*done\s*\]", heading_text, re.IGNORECASE))
    has_active = bool(re.search(r"\[\s*active\s*\]", heading_text, re.IGNORECASE))

    # Strip [done]/[active] then check for [X, Y] classification tag
    stripped = re.sub(
        r"\s*\[\s*(?:done|active)\s*\]\s*", "", heading_text, flags=re.IGNORECASE
    )
    has_classification = bool(re.search(r"\[[^\]]*,\s*[^\]]*\]", stripped))

    return has_done or has_active or has_classification


def _is_heading(token, level):
    return (
        token.get("type") == "heading" and token.get("attrs", {}).get("level") == level
    )


def sort_todo(text):
    """Parse, sort, and return the sorted TODO.md content."""
    if not mistune:
        raise click.ClickException(
            "Sorting TODO.md requires mistune 3. "
            "Install it with: pip install 'projctl[check]'"
        )

    md = mistune.Markdown(renderer=None)
    tree = md(text)

    if not tree:
        raise click.ClickException("TODO.md is empty")

    # First element must be H1
    if not _is_heading(tree[0], 1):
        raise click.ClickException("First element in TODO.md must be an H1 heading")

    # Split into pre-H2 content and H2 groups
    pre_h2 = []
    h2_groups = []
    current_group = None

    for token in tree:
        if _is_heading(token, 2):
            if current_group is not None:
                h2_groups.append(current_group)
            current_group = [token]
        elif current_group is not None:
            current_group.append(token)
        else:
            pre_h2.append(token)

    if current_group is not None:
        h2_groups.append(current_group)

    if not h2_groups:
        raise click.ClickException(
            "TODO.md must contain at least one H2 heading below the H1"
        )

    # Find and extract existing DONE section
    done_section_idx = None

    for i, group in enumerate(h2_groups):
        h2_text = _get_heading_text(group[0])

        if h2_text.strip().upper() == "DONE":
            done_section_idx = i
            break

    done_existing_tokens = []

    if done_section_idx is not None:
        done_group = h2_groups.pop(done_section_idx)
        done_existing_tokens = done_group[1:]  # Content after the H2 heading

    # Rebuild tree with sorted H3 elements within each H2 group
    new_tree = list(pre_h2)
    done_h3_elements = []  # Collect [DONE] items from all groups

    for token in pre_h2:
        if _is_heading(token, 3):
            heading_text = _get_heading_text(token)
            click.echo(
                click.style("WARNING", fg="yellow")
                + f": H3 heading '{heading_text}' is not under any H2 group"
                " and will not be sorted."
            )

    for group in h2_groups:
        h2_text = _get_heading_text(group[0])
        if _has_todo_tag(h2_text):
            click.echo(
                click.style("WARNING", fg="yellow")
                + f": H2 heading '{h2_text}' has tags meant for H3 items."
            )

        new_tree.append(group[0])  # H2 heading

        # Split group content by H3 headings
        pre_h3 = []
        h3_elements = []
        current_h3 = None

        for token in group[1:]:
            if _is_heading(token, 3):
                if current_h3 is not None:
                    if current_h3["done"]:
                        done_h3_elements.append(current_h3)
                    else:
                        h3_elements.append(current_h3)

                heading_text = _get_heading_text(token)
                importance, difficulty, normalized, active = _parse_tag(heading_text)

                is_done = importance == "DONE"

                if normalized != heading_text:
                    token = _update_heading_tag(token, normalized)

                current_h3 = {
                    "tokens": [token],
                    "importance": importance,
                    "difficulty": difficulty,
                    "done": is_done,
                    "active": active,
                }
            elif current_h3 is not None:
                # Warn about nested headings (H4+) with todo tags
                if (
                    token.get("type") == "heading"
                    and token.get("attrs", {}).get("level", 0) >= 4
                ):
                    nested_text = _get_heading_text(token)
                    if _has_todo_tag(nested_text):
                        parent_text = _get_heading_text(current_h3["tokens"][0])
                        level = token["attrs"]["level"]
                        click.echo(
                            click.style("WARNING", fg="yellow")
                            + f": H{level} heading '{nested_text}' has tags meant"
                            f" for H3 items. It is nested under H3 '{parent_text}'"
                            " and will be moved along with it if marked as done."
                        )
                current_h3["tokens"].append(token)
            else:
                pre_h3.append(token)

        if current_h3 is not None:
            if current_h3["done"]:
                done_h3_elements.append(current_h3)
            else:
                h3_elements.append(current_h3)

        new_tree.extend(pre_h3)

        h3_elements.sort(key=_sort_key)

        for element in h3_elements:
            new_tree.extend(element["tokens"])

    # Normalize H3 headings inside the existing DONE section
    normalized_done_tokens = []
    for token in done_existing_tokens:
        if _is_heading(token, 3):
            heading_text = _get_heading_text(token)
            _, _, normalized, _ = _parse_tag(heading_text)
            if normalized != heading_text:
                token = _update_heading_tag(token, normalized)
        normalized_done_tokens.append(token)

    # Collect done items separately
    done_tokens = list(normalized_done_tokens)
    for element in done_h3_elements:
        done_tokens.extend(element["tokens"])

    renderer = MarkdownRenderer()
    main_text = renderer(new_tree, state=BlockState())

    done_text = ""
    if done_tokens:
        done_text = renderer(done_tokens, state=BlockState())

    return main_text, done_text


def todo():
    """Find and sort TODO.md by importance and difficulty tags."""
    path = _find_todo_md()
    text = path.read_text()
    sorted_text, done_text = sort_todo(text)
    path.write_text(sorted_text)

    if done_text:
        done_path = path.parent / "DONE.md"

        if done_path.exists():
            existing = done_path.read_text()

            if not existing.endswith("\n"):
                existing += "\n"

            done_path.write_text(existing + done_text)
        else:
            done_path.write_text(f"# DONE\n\n{done_text}")

        click.echo(f"Archived done items to {done_path}")

    click.echo(f"Sorted {path}")
