import sys
from pathlib import Path

import click
from invoke import Context, UnexpectedExit


from projctl import links, config, changelog, hook as hook_, versioneer
from projctl import new as new_
from projctl import dev
from projctl import formatting
from projctl import utm as utm_
from projctl import commit as commit_
from projctl import todo as todo_
from projctl import profiles as profiles_


class AliasedGroup(click.Group):
    """
    Allow running commands by only typing the first few characters.
    https://click.palletsprojects.com/en/8.1.x/advanced/#command-aliases

    To disable, remove the `cls=AliasedGroup` argument from the `@click.group()` decorator.
    """

    def get_command(self, ctx, cmd_name):
        rv = click.Group.get_command(self, ctx, cmd_name)
        if rv is not None:
            return rv
        matches = [x for x in self.list_commands(ctx) if x.startswith(cmd_name)]
        if not matches:
            return None
        elif len(matches) == 1:
            return click.Group.get_command(self, ctx, matches[0])
        ctx.fail(f"Too many matches: {', '.join(sorted(matches))}")

    def resolve_command(self, ctx, args):
        # always return the full command name
        _, cmd, args = super().resolve_command(ctx, args)
        if cmd is None:
            raise click.UsageError("Command could not be resolved.")
        return cmd.name, cmd, args


@click.group(cls=AliasedGroup)
def cli():
    pass


@cli.command()
@click.option(
    "--only-404",
    is_flag=True,
    default=False,
    help="Only consider 404 code as broken",
)
def check_links(only_404):
    """Check for broken links"""
    broken_http_codes = None if not only_404 else [404]

    cfg = config.Config.from_file("pyproject.toml")["check_links"]
    out = links.find_broken_in_files(
        cfg["extensions"],
        cfg.get("ignore_substrings"),
        verbose=True,
        broken_http_codes=broken_http_codes,
    )

    if out:
        sys.exit(1)


@cli.command()
@click.argument("name")
@click.option(
    "--use-setup-py",
    is_flag=True,
    default=False,
    help="Use setup.py instead of pyproject.toml",
)
def new(name, use_setup_py):
    """Create new package"""
    new_.package(name, use_setup_py=use_setup_py)


@cli.command()
def check():
    """Run general checks in the project"""
    text = Path("CHANGELOG.md").read_text()
    changelog.CHANGELOG(text).check(verbose=True)


@cli.command()
@click.option(
    "--force",
    is_flag=True,
    default=False,
    help="Overwrite an existing pre-commit hook if it exists.",
)
def hook(force):
    """Create a pre-commit hook that fixes and re-stages staged Python files."""
    hook_.create_hook(force=force)


@cli.command()
@click.option(
    "--yes",
    is_flag=True,
    default=False,
    help="Do not ask for confirmation",
)
@click.option("--push/--no-push", default=None)
@click.option("--tag/--no-tag", default=None)
@click.option("--target", default=None)
def version(yes, push, tag, target):
    """Create a new package version"""

    cfg = config.Config.from_file("pyproject.toml", cli_args=dict(push=push, tag=tag))

    versioneer.version(
        project_root=".",
        tag=cfg["version"]["tag"],
        yes=yes,
        push=cfg["version"]["push"],
        target=target,
    )


@cli.command()
@click.argument("tag")
@click.option(
    "--production",
    is_flag=True,
    default=False,
    help="Upload to the production PyPI server",
)
@click.option(
    "--yes",
    is_flag=True,
    default=False,
    help="Do not ask for confirmation",
)
def release(tag, production, yes):
    """Release this package from a given tag"""
    versioneer.upload(tag, production, yes=yes)


@cli.command()
@click.option(
    "--doc",
    is_flag=True,
    default=False,
    help="Install documentation dependencies",
)
@click.option(
    "--version",
    default=None,
    type=str,
    help="Select a Python version, default is 3.10",
)
def setup(version, doc):
    """Setup development environment

    Create conda environment and install dependencies:

        $ projctl setup

    Install dependencies required to build documentation:

        $ projctl setup --doc
    """
    try:
        dev.setup(Context(), version=version, doc=doc)
    except UnexpectedExit as e:
        raise SystemExit(f"Error running: {e.result.command}") from e


@cli.command()
@click.option(
    "--clean",
    is_flag=True,
    default=False,
    help="Perform a clean build",
)
def doc(clean):
    """Build docs"""
    try:
        dev.doc(Context(), clean=clean)
    except UnexpectedExit as e:
        raise SystemExit(f"Error running: {e.result.command}") from e


@cli.command()
@click.option(
    "-e",
    "--exclude",
    multiple=True,
    default=[],
    help="Exclude multiple files or dir from the build. Can also pass regex."
    "Eg: -e tmp -e tmp/a.py -e tmp|src",
)
def format(exclude):
    """Run ruff format on .py files"""
    formatting.format(exclude)


@cli.command()
@click.argument("files", nargs=-1)
@click.option(
    "-e",
    "--exclude",
    multiple=True,
    default=[],
    help="Exclude multiple files or dir from the buildEg: -e tmp -e tmp/a.py",
)
def lint(files, exclude):
    """Lint .py files with ruff check"""
    returncode = hook_._lint(files=files, exclude=exclude)

    if returncode:
        raise SystemExit("Error linting")


@cli.command()
@click.option(
    "-m",
    "--model",
    default="gpt-4o-mini",
    help="LLM model to use for generating the commit message",
)
@click.option(
    "--yes",
    is_flag=True,
    default=False,
    help="Commit without asking for confirmation",
)
def commit(model, yes):
    """Generate a commit message from staged and unstaged changes using an LLM"""
    commit_.commit(model, yes)


@cli.command()
def todo():
    """Sort TODO.md by importance and difficulty tags"""
    todo_.todo()


@cli.command()
@click.argument("path", type=click.Path(exists=True))
def utm(path):
    """Command to process a directory or file"""
    cfg = config.Config.from_file("pyproject.toml")

    utm_.add_utm_tags(
        path,
        utm_source=cfg["utm"].get("source"),
        utm_medium=cfg["utm"].get("medium"),
        utm_campaign=cfg["utm"].get("campaign"),
        base_urls=cfg["utm"].get("base_urls"),
    )


cli.add_command(profiles_.profile)
