import importlib.metadata
import json
import os
import shutil
import textwrap
from pathlib import Path
from urllib.parse import urlparse

import click
import mistune
import yaml
from tabulate import tabulate

from projctl import config


def _find_project_root():
    """Walk up from cwd looking for pyproject.toml, return its parent directory."""
    directory = Path.cwd()
    for _ in range(10):
        if (directory / "pyproject.toml").exists():
            return directory
        directory = directory.parent
    raise click.ClickException("Could not find pyproject.toml in any parent directory")


def _metadata_path(project_root):
    return project_root / ".projctl" / "metadata.json"


def _read_metadata(project_root):
    path = _metadata_path(project_root)
    if path.exists():
        return json.loads(path.read_text())
    return {}


def _write_metadata(project_root, data):
    path = _metadata_path(project_root)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2) + "\n")


def _read_active_profile(project_root):
    return _read_metadata(project_root).get("profile") or None


def _write_active_profile(project_root, profile):
    meta = _read_metadata(project_root)
    meta["profile"] = profile or ""
    _write_metadata(project_root, meta)


def _read_frontmatter(skill_md):
    """Parse name and description from YAML frontmatter in SKILL.md."""
    text = skill_md.read_text()
    if not text.startswith("---"):
        return {}
    end = text.index("---", 3)
    frontmatter = yaml.safe_load(text[3:end])
    return frontmatter or {}


def _discover_local_skills(project_root):
    """Scan project_root/.projctl/claude/skills/*/SKILL.md for local skills."""
    skills_dir = project_root / ".projctl" / "claude" / "skills"
    if not skills_dir.is_dir():
        return []

    results = []
    for skill_md in sorted(skills_dir.glob("*/SKILL.md")):
        fm = _read_frontmatter(skill_md)
        results.append(
            {
                "name": fm.get("name", skill_md.parent.name),
                "description": fm.get("description", ""),
                "source": "local",
                "path": skill_md.parent,
                "editable": True,
            }
        )
    return results


def _get_package_skills_dir(package_name):
    """Find the claude/skills/ directory for a package and whether it's editable."""
    mod = importlib.import_module(package_name)
    package_dir = Path(mod.__file__).parent
    editable = "site-packages" not in package_dir.parts
    return package_dir / "claude" / "skills", editable


def _discover_package_skills(package_name):
    """Find claude/skills/ in a package and enumerate skills."""
    try:
        skills_dir, editable = _get_package_skills_dir(package_name)
    except importlib.metadata.PackageNotFoundError:
        click.echo(
            click.style("WARNING", fg="yellow")
            + f": package '{package_name}' not found, skipping"
        )
        return []

    if not skills_dir.is_dir():
        return []

    results = []
    for skill_md in sorted(skills_dir.glob("*/SKILL.md")):
        fm = _read_frontmatter(skill_md)
        results.append(
            {
                "name": fm.get("name", skill_md.parent.name),
                "description": fm.get("description", ""),
                "source": package_name,
                "path": skill_md.parent,
                "editable": editable,
            }
        )
    return results


def _discover_all_skills(project_root, cfg):
    """Combine local + all package skills."""
    all_skills = _discover_local_skills(project_root)

    packages = cfg.get("packages", [])
    for pkg in packages:
        all_skills.extend(_discover_package_skills(pkg))

    return all_skills


def _parse_skill_ref(ref):
    """Parse a skill reference like 'name' or 'package.name'.

    Returns (package, name) where package is None for bare names.
    """
    if "." in ref:
        package, name = ref.rsplit(".", 1)
        return package, name
    return None, ref


def _resolve_skill_ref(ref, skills_by_key):
    """Resolve a skill reference against discovered skills.

    Supports 'name' (matches any source, local first) or 'package.name' (explicit).
    """
    package, name = _parse_skill_ref(ref)

    if package is not None:
        key = (package, name)
        if key in skills_by_key:
            return skills_by_key[key]
        return None

    # Bare name: match any source, local first
    for skill in skills_by_key.values():
        if skill["name"] == name:
            return skill
    return None


def _skill_key(skill):
    """Return (source, name) tuple for a skill."""
    return (skill["source"], skill["name"])


def _profiled_skill_keys(profiles, skills_by_key):
    """Return set of (source, name) keys for all skills referenced in any profile."""
    keys = set()
    for names in profiles.values():
        for ref in names:
            skill = _resolve_skill_ref(ref, skills_by_key)
            if skill:
                keys.add(_skill_key(skill))
    return keys


def _is_excluded(skill, exclude_refs, skills_by_key):
    """Check if a skill matches any entry in the exclude list."""
    key = _skill_key(skill)
    for ref in exclude_refs:
        excluded = _resolve_skill_ref(ref, skills_by_key)
        if excluded and _skill_key(excluded) == key:
            return True
    return False


@click.group()
def profile():
    """Manage profiles, skills, and files"""
    pass


@profile.command("list")
@click.option(
    "--profile",
    "-p",
    default=None,
    help="Show skills for a specific profile without installing it.",
)
def list_skills(profile):
    """Discover and list all available skills"""
    project_root = _find_project_root()

    try:
        cfg = config.Config.from_file("pyproject.toml")
        skills_cfg = dict(cfg.get("skills", {}))
    except (FileNotFoundError, KeyError):
        skills_cfg = {}

    skills_to_show = _discover_all_skills(project_root, skills_cfg)

    if profile:
        try:
            resolved = resolve_profile(profile)
        except ValueError as e:
            raise click.ClickException(str(e))
        active_names = {s["name"] for s in resolved}
    else:
        # Check which skills would be active for the current profile
        active_profile = _read_active_profile(project_root)
        if active_profile:
            try:
                active_resolved = resolve_profile(active_profile)
                active_names = {s["name"] for s in active_resolved}
            except ValueError:
                active_names = set()
        else:
            try:
                active_resolved = resolve_profile(None)
                active_names = {s["name"] for s in active_resolved}
            except ValueError:
                active_names = set()

    if not skills_to_show:
        click.echo("No skills found.")
        return

    try:
        terminal_width = os.get_terminal_size().columns
    except OSError:
        terminal_width = 80
    name_width = max(len(s["name"]) for s in skills_to_show)
    source_width = max(len(s["source"]) for s in skills_to_show)
    # table borders + padding: 3 columns = 4 borders (│) + 2 spaces padding each = 4 + 6*2 = 16
    overhead = 16
    desc_width = max(20, terminal_width - name_width - source_width - overhead)

    rows = [
        [
            click.style(s["name"], fg="green")
            if s["name"] in active_names
            else s["name"],
            textwrap.fill(s["description"], width=desc_width),
            s["source"],
        ]
        for s in skills_to_show
    ]
    click.echo(
        tabulate(
            rows, headers=["Name", "Description", "Source"], tablefmt="rounded_grid"
        )
    )

    if profile:
        click.echo(f"\nShowing profile: {profile}")
    else:
        active_profile = _read_active_profile(project_root)
        click.echo(f"\nActive profile: {active_profile or '(none)'}")

    # Show profile files
    show_profile = profile or _read_active_profile(project_root)
    if show_profile:
        files_dir = project_root / ".projctl" / "files" / show_profile
        if files_dir.is_dir():
            files = sorted(f.name for f in files_dir.iterdir() if f.is_file())
            if files:
                click.echo(f"\nProfile files ({show_profile}):")
                for f in files:
                    click.echo(f"  {f}")


def _extract_links_from_tokens(tokens):
    """Recursively extract link URLs from mistune AST tokens."""
    links = []
    for token in tokens:
        if token.get("type") in ("link", "image"):
            link = token.get("attrs", {}).get("url")
            if link:
                links.append(link)
        children = token.get("children")
        if children:
            links.extend(_extract_links_from_tokens(children))
    return links


def _extract_links_from_markdown(path):
    """Parse a markdown file with mistune and return all link URLs."""
    text = path.read_text()
    md = mistune.Markdown(renderer=None)
    tokens = md(text)
    return _extract_links_from_tokens(tokens)


def _is_url(link):
    """Check if link is an external URL."""
    parsed = urlparse(link)
    return parsed.scheme in ("http", "https", "ftp")


def _collect_skill_links(skills_dir, skill_dirs=None):
    """Scan markdown files in skills_dir and collect all local links.

    If *skill_dirs* is given (set of directory names), only scan skills in
    that set.  Returns a list of ``(relative_file, link, target_path)``
    tuples for every local link found.
    """
    results = []

    md_files = []
    for root, _dirs, files in os.walk(skills_dir, followlinks=True):
        for fname in files:
            if fname.endswith(".md"):
                md_files.append(Path(root) / fname)
    md_files.sort()

    for md_file in md_files:
        rel_parts = md_file.relative_to(skills_dir).parts
        # Skip hidden files
        if any(part.startswith(".") for part in rel_parts):
            continue

        # If filtering by skill dirs, skip skills not in the set
        if skill_dirs is not None and rel_parts[0] not in skill_dirs:
            continue

        # Resolve symlinks only for reading the file content
        resolved_file = md_file.resolve()

        try:
            links = _extract_links_from_markdown(resolved_file)
        except Exception:
            continue

        for link in links:
            if _is_url(link):
                continue

            # Skip anchors and mailto
            if link.startswith("#") or link.startswith("mailto:"):
                continue

            # Strip fragment
            link_path = link.split("#")[0]
            if not link_path:
                continue

            target = Path(os.path.normpath(md_file.parent / link_path))
            rel = md_file.relative_to(skills_dir)
            results.append((str(rel), link, target))

    return results


def _check_skills_links(skills_dir):
    """Scan all markdown files in skills_dir, extract links, and warn about broken ones.

    Checks local file links relative to the markdown file's location inside
    skills_dir (the source ``claude/skills/`` directory). Cross-skill
    references like ``../upload/SKILL.md`` are resolved relative to this
    source directory.
    Skips external URLs.
    """
    broken = []
    for rel, link, target in _collect_skill_links(skills_dir):
        if not target.exists():
            # Try with .md extension — markdown cross-references often
            # omit the extension (e.g. ./calculate-metadata)
            if not target.with_suffix(".md").exists():
                broken.append((rel, link))
    return broken


def _check_profile_links(skills_dir, resolved_skills, profile=None):
    """Check that cross-skill links only reference skills included in the profile.

    Scans both skill markdown files and the CLAUDE.md / CLAUDE.<profile>.md
    files in the ``claude/`` directory.

    Returns a list of ``(relative_file, link, referenced_skill_dir)`` for
    links that point to a skill directory not present in *resolved_skills*.
    Broken links (target doesn't exist at all) are excluded — those are
    reported by ``_check_skills_links`` instead.
    """
    # Build set of skill directory names that are in the resolved profile.
    # For local skills, the dir name is the last component of the path.
    resolved_dir_names = set()
    for skill in resolved_skills:
        resolved_dir_names.add(skill["path"].name)

    # Collect links from skills in the profile
    all_links = _collect_skill_links(skills_dir, skill_dirs=resolved_dir_names)

    # Also collect links from the CLAUDE.md that would be active for this
    # profile: CLAUDE.<profile>.md if it exists, otherwise CLAUDE.md
    claude_dir = skills_dir.parent  # claude/
    claude_md_files = []
    if profile:
        profile_claude_md = claude_dir / f"CLAUDE.{profile}.md"
        if profile_claude_md.exists():
            claude_md_files.append(profile_claude_md)
    if not claude_md_files:
        base_claude_md = claude_dir / "CLAUDE.md"
        if base_claude_md.exists():
            claude_md_files.append(base_claude_md)

    for md_file in claude_md_files:
        try:
            links = _extract_links_from_markdown(md_file)
        except Exception:
            continue
        for link in links:
            if _is_url(link) or link.startswith("#") or link.startswith("mailto:"):
                continue
            link_path = link.split("#")[0]
            if not link_path:
                continue
            target = Path(os.path.normpath(md_file.parent / link_path))
            rel = md_file.relative_to(claude_dir)
            all_links.append((str(rel), link, target))

    excluded_refs = []
    for rel, link, target in all_links:
        # Check if the target falls within skills_dir
        try:
            target_rel = target.relative_to(skills_dir)
        except ValueError:
            continue

        referenced_dir = target_rel.parts[0]
        if referenced_dir in resolved_dir_names:
            continue

        # Only flag if the target actually exists on disk (it's a real skill
        # that was excluded, not a genuinely missing file)
        if target.exists() or target.with_suffix(".md").exists():
            excluded_refs.append((rel, link, referenced_dir))

    return excluded_refs


def _get_active_claude_md(claude_dir, profile=None):
    """Return the CLAUDE.md file that would be active for a profile."""
    if profile:
        profile_md = claude_dir / f"CLAUDE.{profile}.md"
        if profile_md.exists():
            return profile_md
    base_md = claude_dir / "CLAUDE.md"
    if base_md.exists():
        return base_md
    return None


def _collect_links_for_file(file_path, claude_dir):
    """Extract local links from a markdown file, returning absolute target paths.

    Only returns links that stay within *claude_dir*.
    """
    try:
        links = _extract_links_from_markdown(file_path)
    except Exception:
        return []

    targets = []
    for link in links:
        if _is_url(link) or link.startswith("#") or link.startswith("mailto:"):
            continue
        link_path = link.split("#")[0]
        if not link_path:
            continue
        target = Path(os.path.normpath(file_path.parent / link_path))
        # Only keep links within claude/
        try:
            target.relative_to(claude_dir)
        except ValueError:
            continue
        targets.append(target)
    return targets


def _build_link_map(claude_dir, profile=None):
    """Build an adjacency map of local links starting from the active CLAUDE.md.

    Returns ``(root_path, adjacency_map)`` where *adjacency_map* maps each
    visited file path to a list of target file paths.
    """
    root = _get_active_claude_md(claude_dir, profile)
    if root is None:
        return None, {}

    adj = {}
    queue = [root]
    while queue:
        current = queue.pop(0)
        if current in adj:
            continue
        targets = _collect_links_for_file(current, claude_dir)
        adj[current] = targets
        for t in targets:
            if t not in adj and t.exists():
                queue.append(t)

    return root, adj


def _print_link_tree(root, adj, claude_dir, prefix="", visited=None, ancestors=None):
    """Print the link map as a tree with box-drawing characters."""
    if visited is None:
        visited = set()
    if ancestors is None:
        ancestors = set()

    # Print root node if this is a top-level call (no prefix)
    if not prefix:
        rel = root.relative_to(claude_dir)
        click.echo(str(rel))
        visited.add(root)
        ancestors.add(root)

    children = adj.get(root, [])
    for i, child in enumerate(children):
        is_last = i == len(children) - 1
        connector = "└── " if is_last else "├── "
        extension = "    " if is_last else "│   "
        rel = child.relative_to(claude_dir)

        if child in ancestors:
            click.echo(f"{prefix}{connector}{rel} (cycle)")
            continue

        if child in visited:
            click.echo(f"{prefix}{connector}{rel} (see above)")
            continue

        if not child.exists():
            click.echo(f"{prefix}{connector}{rel} (broken)")
            continue

        click.echo(f"{prefix}{connector}{rel}")
        visited.add(child)
        ancestors.add(child)
        _print_link_tree(child, adj, claude_dir, prefix + extension, visited, ancestors)
        ancestors.discard(child)

    if not prefix:
        ancestors.discard(root)


def resolve_profile(profile=None):
    """Resolve which skills would be installed for a profile.

    Returns the list of resolved skill dicts without performing any I/O.
    """
    project_root = _find_project_root()

    cfg = config.Config.from_file("pyproject.toml")
    skills_cfg = dict(cfg.get("skills", {}))

    profiles = skills_cfg.get("profiles", {})
    all_skills = _discover_all_skills(project_root, skills_cfg)
    skills_by_key = {_skill_key(s): s for s in all_skills}

    resolved = []

    if profile is not None:
        if profile not in profiles:
            available = ", ".join(profiles.keys()) if profiles else "(none)"
            raise ValueError(
                f"Profile '{profile}' not found. Available profiles: {available}"
            )

        for ref in profiles[profile]:
            skill = _resolve_skill_ref(ref, skills_by_key)
            if skill is None:
                raise ValueError(
                    f"Skill '{ref}' from profile '{profile}' not found in any source"
                )
            resolved.append(skill)

    # Always include skills not in any profile, unless excluded
    exclude_refs = skills_cfg.get("exclude", [])
    profiled_keys = _profiled_skill_keys(profiles, skills_by_key)
    for skill in all_skills:
        if _skill_key(skill) not in profiled_keys:
            if not _is_excluded(skill, exclude_refs, skills_by_key):
                resolved.append(skill)

    return resolved


def activate_profile(profile=None, global_=False):
    """Activate a skill profile by symlinking/copying into .claude/skills/."""
    project_root = _find_project_root()
    resolved = resolve_profile(profile)

    if global_:
        base_dir = Path.home() / ".claude"
        other_dir = project_root / ".claude" / "skills"
        other_label = ".claude/skills/"
    else:
        base_dir = project_root / ".claude"
        other_dir = Path.home() / ".claude" / "skills"
        other_label = "~/.claude/skills/"

    target_dir = base_dir / "skills"
    target_dir.mkdir(parents=True, exist_ok=True)

    # Check for conflicts: non-symlink entries that clash with skills we want to install
    for skill in resolved:
        dest = target_dir / skill["name"]
        if dest.exists() and not dest.is_symlink():
            rel = dest.relative_to(base_dir.parent) if not global_ else dest
            raise ValueError(
                f"{rel} exists and is not a managed symlink. "
                "Remove it manually to continue."
            )

    # Clean up symlinks from the other location
    cleaned_other = 0
    if other_dir.is_dir():
        for entry in other_dir.iterdir():
            if entry.is_symlink():
                entry.unlink()
                cleaned_other += 1

    # Clean up existing symlinks (managed by us)
    for entry in target_dir.iterdir():
        if entry.is_symlink():
            entry.unlink()

    for skill in resolved:
        dest = target_dir / skill["name"]
        if skill["editable"]:
            dest.symlink_to(skill["path"])
        else:
            shutil.copytree(skill["path"], dest)

    # Clean up file symlinks from previous profile
    files_base = project_root / ".projctl" / "files"
    prev_profile = _read_active_profile(project_root)
    if prev_profile:
        prev_files_dir = files_base / prev_profile
        if prev_files_dir.is_dir():
            for f in prev_files_dir.iterdir():
                if f.is_file():
                    dest = project_root / f.name
                    if dest.is_symlink():
                        dest.unlink()

    # Symlink profile files to project root
    installed_files = []
    if profile:
        profile_files_dir = files_base / profile
        if profile_files_dir.is_dir():
            for f in sorted(profile_files_dir.iterdir()):
                if f.is_file():
                    dest = project_root / f.name
                    if dest.exists() and not dest.is_symlink():
                        click.echo(
                            click.style("WARNING", fg="yellow")
                            + f": {f.name} already exists at project root, skipping"
                        )
                        continue
                    if dest.is_symlink():
                        dest.unlink()
                    dest.symlink_to(os.path.relpath(f, project_root))
                    installed_files.append(f.name)

    _write_active_profile(project_root, profile)

    # Symlink CLAUDE.md from .projctl/claude/CLAUDE.<profile>.md or CLAUDE.md
    claude_dir = project_root / ".projctl" / "claude"
    claude_md_link = base_dir / "CLAUDE.md"

    if profile:
        profile_claude_md = claude_dir / f"CLAUDE.{profile}.md"
    else:
        profile_claude_md = None

    source = None
    if profile_claude_md and profile_claude_md.exists():
        source = profile_claude_md
    elif (claude_dir / "CLAUDE.md").exists():
        source = claude_dir / "CLAUDE.md"

    if source is not None:
        if claude_md_link.is_symlink() or claude_md_link.exists():
            claude_md_link.unlink()
        claude_md_link.symlink_to(os.path.relpath(source, claude_md_link.parent))

    return resolved, source, cleaned_other, other_label, installed_files


@profile.command("set")
@click.argument("profile", required=False, default=None)
@click.option(
    "--global",
    "-g",
    "global_",
    is_flag=True,
    help="Install into ~/.claude/ instead of .claude/",
)
def set_profile(profile, global_):
    """Activate a skill profile by symlinking/copying into .claude/skills/

    If PROFILE is omitted, only skills that don't belong to any profile are installed.
    """
    try:
        resolved, claude_md_source, cleaned_other, other_label, installed_files = (
            activate_profile(profile, global_=global_)
        )
    except ValueError as e:
        raise click.ClickException(str(e))

    if cleaned_other:
        click.echo(f"Cleaned up {cleaned_other} symlink(s) from {other_label}")

    target = "~/.claude/skills/" if global_ else ".claude/skills/"
    if profile:
        click.echo(
            f"Activated profile '{profile}' with {len(resolved)} skill(s) in {target}"
        )
    else:
        click.echo(f"Installed {len(resolved)} unassigned skill(s) in {target}")

    if installed_files:
        click.echo(f"Linked {len(installed_files)} file(s) to project root")

    if claude_md_source is not None:
        click.echo(f"Linked .claude/CLAUDE.md → {claude_md_source.name}")

    project_root = _find_project_root()
    root_claude_md = project_root / "CLAUDE.md"
    if root_claude_md.exists() and claude_md_source is not None:
        click.echo()
        click.echo(
            click.style("WARNING", fg="yellow")
            + ": CLAUDE.md exists at project root and may conflict with .claude/CLAUDE.md"
        )

    # Check for broken links in source skills
    skills_dir = project_root / ".projctl" / "claude" / "skills"
    broken = _check_skills_links(skills_dir)

    if broken:
        click.echo()
        click.echo(
            click.style("WARNING", fg="yellow")
            + f": found {len(broken)} broken link(s) in skills:"
        )
        for file, link in broken:
            click.echo(f"  {file}: {link}")


@profile.command("lint")
@click.option(
    "--profile",
    "-p",
    default=None,
    help="Profile to check (default: currently active profile)",
)
@click.option("--tree", "tree_", is_flag=True, help="Print a tree of skill links")
def lint_skills(profile, tree_):
    """Check skills for broken links and profile configuration issues."""
    project_root = _find_project_root()
    skills_dir = project_root / ".projctl" / "claude" / "skills"

    if not skills_dir.is_dir():
        raise click.ClickException(f"Skills directory not found: {skills_dir}")

    # Determine which profile to check
    if profile is None:
        profile = _read_active_profile(project_root)

    if tree_:
        claude_dir = project_root / ".projctl" / "claude"
        root, adj = _build_link_map(claude_dir, profile)
        if root is None:
            raise click.ClickException("No CLAUDE.md found")

        # Resolve profile skills and add unlinked ones as extra roots
        try:
            resolved = resolve_profile(profile)
        except ValueError as e:
            raise click.ClickException(str(e))

        # Walk from each local profile skill's SKILL.md too
        # (skip package skills from other projects — they're outside claude_dir)
        local_skills = []
        for skill in resolved:
            skill_md = skill["path"] / "SKILL.md"
            try:
                skill_md.relative_to(claude_dir)
            except ValueError:
                continue
            local_skills.append(skill)
            if skill_md.exists() and skill_md not in adj:
                queue = [skill_md]
                while queue:
                    current = queue.pop(0)
                    if current in adj:
                        continue
                    targets = _collect_links_for_file(current, claude_dir)
                    adj[current] = targets
                    for t in targets:
                        if t not in adj and t.exists():
                            queue.append(t)

        # Print the tree from CLAUDE.md root
        visited = set()
        _print_link_tree(root, adj, claude_dir, visited=visited)

        # Print unlinked profile skills as separate roots
        for skill in sorted(local_skills, key=lambda s: s["name"]):
            skill_md = skill["path"] / "SKILL.md"
            if skill_md.exists() and skill_md not in visited:
                click.echo()
                _print_link_tree(skill_md, adj, claude_dir, visited=visited)

        return

    profile_label = f"profile '{profile}'" if profile else "no profile"
    click.echo(f"Linting skills ({profile_label})...")

    errors = 0

    # 1. Check for broken links (files that don't exist)
    broken = _check_skills_links(skills_dir)
    if broken:
        click.echo(
            click.style("ERROR", fg="red")
            + f": {len(broken)} broken link(s) in skills:"
        )
        for file, link in broken:
            click.echo(f"  {file}: {link}")
        errors += len(broken)

    # 2. Check profile-specific issues (links to excluded skills)
    try:
        resolved = resolve_profile(profile)
    except ValueError as e:
        raise click.ClickException(str(e))

    excluded_refs = _check_profile_links(skills_dir, resolved, profile=profile)
    if excluded_refs:
        profile_label = f"'{profile}'" if profile else "(no profile)"
        if errors:
            click.echo()
        click.echo(
            click.style("ERROR", fg="red")
            + f": {len(excluded_refs)} link(s) reference skills excluded from profile {profile_label}:"
        )
        for file, link, ref_dir in excluded_refs:
            click.echo(f"  {file}: {link} -> skill '{ref_dir}' is not in profile")
        errors += len(excluded_refs)

    if errors:
        raise SystemExit(1)

    click.echo(click.style("OK", fg="green") + ": no issues found")
