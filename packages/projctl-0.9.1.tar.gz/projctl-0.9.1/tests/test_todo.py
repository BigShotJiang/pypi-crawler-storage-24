import os
from pathlib import Path

import pytest
from click import ClickException
from click.testing import CliRunner

from projctl import cli
from projctl.todo import _find_todo_md, _parse_tag, sort_todo


# --- _find_todo_md ---


def test_find_todo_md_in_current_dir(tmp_empty):
    Path("TODO.md").write_text("# TODO\n\n## Section\n")
    assert _find_todo_md() == Path("TODO.md").resolve()


def test_find_todo_md_in_parent_dir(tmp_empty):
    Path("TODO.md").write_text("# TODO\n\n## Section\n")
    Path("sub").mkdir()
    os.chdir("sub")
    assert _find_todo_md() == Path(tmp_empty, "TODO.md")


def test_find_todo_md_not_found(tmp_empty):
    with pytest.raises(ClickException, match="Could not find TODO.md"):
        _find_todo_md()


def _is_case_sensitive_fs(path):
    """Check if the filesystem at path is case-sensitive."""
    test_file = Path(path) / "_case_test_"
    test_file.write_text("")
    result = not Path(str(test_file).upper()).exists()
    test_file.unlink()
    return result


def test_find_todo_md_wrong_case_ignored(tmp_empty):
    if not _is_case_sensitive_fs(tmp_empty):
        pytest.skip("case-insensitive filesystem")

    Path("todo.md").write_text("# TODO\n\n## Section\n")
    with pytest.raises(ClickException, match="Could not find TODO.md"):
        _find_todo_md()


# --- _parse_tag ---


@pytest.mark.parametrize(
    "heading, expected",
    [
        ("Task [HIGH, EASY]", ("HIGH", "EASY", "Task [HIGH, EASY]", False)),
        ("Task [CRITICAL, HARD]", ("CRITICAL", "HARD", "Task [CRITICAL, HARD]", False)),
        ("Task [LOW, MEDIUM]", ("LOW", "MEDIUM", "Task [LOW, MEDIUM]", False)),
    ],
    ids=["high-easy", "critical-hard", "low-medium"],
)
def test_parse_tag_valid(heading, expected):
    assert _parse_tag(heading) == expected


@pytest.mark.parametrize(
    "heading, expected",
    [
        ("Task [high, easy]", ("HIGH", "EASY", "Task [HIGH, EASY]", False)),
        ("Task [Critical, Hard]", ("CRITICAL", "HARD", "Task [CRITICAL, HARD]", False)),
        ("Task [low, MEDIUM]", ("LOW", "MEDIUM", "Task [LOW, MEDIUM]", False)),
    ],
    ids=["all-lower", "mixed-case", "mixed-case-2"],
)
def test_parse_tag_lowercase(heading, expected):
    assert _parse_tag(heading) == expected


@pytest.mark.parametrize(
    "heading, expected",
    [
        ("Task [ HIGH , EASY ]", ("HIGH", "EASY", "Task [HIGH, EASY]", False)),
        (
            "Task [  CRITICAL,HARD  ]",
            ("CRITICAL", "HARD", "Task [CRITICAL, HARD]", False),
        ),
        ("Task [ low ,  medium ]", ("LOW", "MEDIUM", "Task [LOW, MEDIUM]", False)),
    ],
    ids=["spaces-around", "no-space-after-comma", "spaces-everywhere"],
)
def test_parse_tag_normalizes_spaces(heading, expected):
    assert _parse_tag(heading) == expected


@pytest.mark.parametrize(
    "heading, expected",
    [
        ("Task [EASY, HIGH]", ("HIGH", "EASY", "Task [HIGH, EASY]", False)),
        (
            "Task [HARD, CRITICAL]",
            ("CRITICAL", "HARD", "Task [CRITICAL, HARD]", False),
        ),
        ("Task [medium, low]", ("LOW", "MEDIUM", "Task [LOW, MEDIUM]", False)),
    ],
    ids=["easy-high", "hard-critical", "medium-low"],
)
def test_parse_tag_reorders_difficulty_first(heading, expected):
    assert _parse_tag(heading) == expected


def test_parse_tag_no_brackets():
    assert _parse_tag("Task without tag") == (None, None, "Task without tag", False)


@pytest.mark.parametrize(
    "heading, match",
    [
        ("Task [[HIGH, EASY]]", "expected exactly one"),
        ("Task [HIGH, EASY] [extra]", "expected exactly one"),
    ],
    ids=["double-brackets", "two-pairs"],
)
def test_parse_tag_invalid_brackets(heading, match):
    with pytest.raises(ClickException, match=match):
        _parse_tag(heading)


@pytest.mark.parametrize(
    "heading, match",
    [
        ("Task [HIGH, HIGH]", "one value must be importance"),
        ("Task [EASY, MEDIUM]", "one value must be importance"),
        ("Task [INVALID, EASY]", "one value must be importance"),
        ("Task [HIGH, WRONG]", "one value must be importance"),
    ],
    ids=["both-importance", "both-difficulty", "invalid-first", "invalid-second"],
)
def test_parse_tag_invalid_values(heading, match):
    with pytest.raises(ClickException, match=match):
        _parse_tag(heading)


def test_parse_tag_reversed_brackets():
    with pytest.raises(ClickException, match="tag must be at the end"):
        _parse_tag("Task ]HIGH, EASY[")


def test_parse_tag_too_many_commas():
    with pytest.raises(ClickException, match="expected two values"):
        _parse_tag("Task [HIGH, EASY, LOW]")


# --- sort_todo ---


def test_sort_todo_basic():
    text = """\
# Project

## Group

### Task C [LOW, EASY]

Content C

### Task A [CRITICAL, EASY]

Content A

### Task B [HIGH, MEDIUM]

Content B
"""
    result, done_text = sort_todo(text)

    assert result.index("Task A") < result.index("Task B")
    assert result.index("Task B") < result.index("Task C")


def test_sort_todo_untagged_at_end():
    text = """\
# Project

## Group

### Untagged task

Content untagged

### Tagged task [CRITICAL, EASY]

Content tagged
"""
    result, done_text = sort_todo(text)

    assert result.index("Tagged task") < result.index("Untagged task")


@pytest.mark.parametrize(
    "text, first, second",
    [
        (
            "# T\n\n## G\n\n### A [CRITICAL, EASY]\n\nA\n\n### B [CRITICAL, MEDIUM]\n\nB\n",
            "A [CRITICAL, EASY]",
            "B [CRITICAL, MEDIUM]",
        ),
        (
            "# T\n\n## G\n\n### A [CRITICAL, HARD]\n\nA\n\n### B [HIGH, EASY]\n\nB\n",
            "A [CRITICAL, HARD]",
            "B [HIGH, EASY]",
        ),
        (
            "# T\n\n## G\n\n### A [HIGH, HARD]\n\nA\n\n### B [LOW, EASY]\n\nB\n",
            "A [HIGH, HARD]",
            "B [LOW, EASY]",
        ),
    ],
    ids=["critical-before-medium", "critical-before-high", "high-before-low"],
)
def test_sort_todo_ordering(text, first, second):
    result, done_text = sort_todo(text)
    assert result.index(first) < result.index(second)


def test_sort_todo_full_ordering():
    text = """\
# TODO

## Tasks

### T9 [LOW, HARD]

c9

### T1 [CRITICAL, EASY]

c1

### T5 [HIGH, MEDIUM]

c5

### T3 [CRITICAL, HARD]

c3

### T7 [LOW, EASY]

c7

### T6 [HIGH, HARD]

c6

### T4 [HIGH, EASY]

c4

### T8 [LOW, MEDIUM]

c8

### T2 [CRITICAL, MEDIUM]

c2
"""
    result, done_text = sort_todo(text)

    expected_order = ["T1", "T2", "T3", "T4", "T5", "T6", "T7", "T8", "T9"]
    positions = [result.index(t) for t in expected_order]
    assert positions == sorted(positions)


def test_sort_todo_normalizes_tags():
    text = """\
# Project

## Group

### Task [ easy , critical ]

Content
"""
    result, done_text = sort_todo(text)
    assert "[CRITICAL, EASY]" in result


def test_sort_todo_reorders_tags():
    text = """\
# Project

## Group

### Task [HARD, HIGH]

Content
"""
    result, done_text = sort_todo(text)
    assert "[HIGH, HARD]" in result


def test_sort_todo_multiple_h2_groups():
    text = """\
# Project

## Group A

### A2 [LOW, EASY]

c

### A1 [CRITICAL, HARD]

c

## Group B

### B2 [HIGH, MEDIUM]

c

### B1 [CRITICAL, EASY]

c
"""
    result, done_text = sort_todo(text)

    # Within Group A: CRITICAL before LOW
    assert result.index("A1") < result.index("A2")
    # Within Group B: CRITICAL before HIGH
    assert result.index("B1") < result.index("B2")


def test_sort_todo_preserves_pre_h2_content():
    text = """\
# Project

- Some legend
- Another note

## Group

### Task [HIGH, EASY]

Content
"""
    result, done_text = sort_todo(text)
    assert "Some legend" in result
    assert "Another note" in result


def test_sort_todo_preserves_pre_h3_content():
    text = """\
# Project

## Group

Some intro text for the group.

### Task [HIGH, EASY]

Content
"""
    result, done_text = sort_todo(text)
    assert "Some intro text for the group." in result


def test_sort_todo_no_h3_headings():
    text = """\
# Project

## Group

Just some content here, no H3 headings.
"""
    result, done_text = sort_todo(text)
    assert "Just some content here" in result


def test_sort_todo_multiple_untagged_at_end():
    text = """\
# Project

## Group

### Untagged A

c

### Tagged [CRITICAL, EASY]

c

### Untagged B

c
"""
    result, done_text = sort_todo(text)
    assert result.index("Tagged") < result.index("Untagged A")
    assert result.index("Tagged") < result.index("Untagged B")


# --- _parse_tag DONE ---


@pytest.mark.parametrize(
    "heading, expected",
    [
        ("Task [DONE]", ("DONE", None, "Task [DONE]", False)),
        ("Task [done]", ("DONE", None, "Task [DONE]", False)),
        ("Task [Done]", ("DONE", None, "Task [DONE]", False)),
        ("Task [ DONE ]", ("DONE", None, "Task [DONE]", False)),
        ("Task [ done ]", ("DONE", None, "Task [DONE]", False)),
        ("Task [  done  ]", ("DONE", None, "Task [DONE]", False)),
    ],
    ids=["upper", "lower", "mixed", "spaces-upper", "spaces-lower", "extra-spaces"],
)
def test_parse_tag_done(heading, expected):
    assert _parse_tag(heading) == expected


@pytest.mark.parametrize(
    "heading, expected",
    [
        (
            "Task [CRITICAL, EASY] [DONE]",
            ("DONE", None, "Task [CRITICAL, EASY] [DONE]", False),
        ),
        (
            "Task [CRITICAL, MEDIUM] [done]",
            ("DONE", None, "Task [CRITICAL, MEDIUM] [DONE]", False),
        ),
        (
            "Task [DONE] [HIGH, HARD]",
            ("DONE", None, "Task [HIGH, HARD] [DONE]", False),
        ),
        (
            "Task [ done ] [ low , easy ]",
            ("DONE", None, "Task [LOW, EASY] [DONE]", False),
        ),
        (
            "Task [EASY, CRITICAL] [done]",
            ("DONE", None, "Task [CRITICAL, EASY] [DONE]", False),
        ),
    ],
    ids=["after", "after-lower", "before", "spaces", "reorder"],
)
def test_parse_tag_done_with_classification(heading, expected):
    assert _parse_tag(heading) == expected


# --- _parse_tag ACTIVE ---


@pytest.mark.parametrize(
    "heading, expected",
    [
        (
            "Task [HIGH, EASY] [ACTIVE]",
            ("HIGH", "EASY", "Task [HIGH, EASY] [ACTIVE]", True),
        ),
        (
            "Task [CRITICAL, HARD] [active]",
            ("CRITICAL", "HARD", "Task [CRITICAL, HARD] [ACTIVE]", True),
        ),
        (
            "Task [LOW, MEDIUM] [Active]",
            ("LOW", "MEDIUM", "Task [LOW, MEDIUM] [ACTIVE]", True),
        ),
        (
            "Task [ high , easy ] [ ACTIVE ]",
            ("HIGH", "EASY", "Task [HIGH, EASY] [ACTIVE]", True),
        ),
        (
            "Task [EASY, HIGH] [active]",
            ("HIGH", "EASY", "Task [HIGH, EASY] [ACTIVE]", True),
        ),
    ],
    ids=["upper", "lower", "mixed", "spaces", "reorder-with-active"],
)
def test_parse_tag_active_after(heading, expected):
    assert _parse_tag(heading) == expected


@pytest.mark.parametrize(
    "heading, expected",
    [
        (
            "Task [ACTIVE] [HIGH, EASY]",
            ("HIGH", "EASY", "Task [HIGH, EASY] [ACTIVE]", True),
        ),
        (
            "Task [active] [CRITICAL, HARD]",
            ("CRITICAL", "HARD", "Task [CRITICAL, HARD] [ACTIVE]", True),
        ),
        (
            "Task [ active ] [ low , medium ]",
            ("LOW", "MEDIUM", "Task [LOW, MEDIUM] [ACTIVE]", True),
        ),
        (
            "Task [ACTIVE] [EASY, HIGH]",
            ("HIGH", "EASY", "Task [HIGH, EASY] [ACTIVE]", True),
        ),
    ],
    ids=["upper", "lower", "spaces", "reorder"],
)
def test_parse_tag_active_before(heading, expected):
    assert _parse_tag(heading) == expected


@pytest.mark.parametrize(
    "heading, expected",
    [
        ("Task [ACTIVE]", (None, None, "Task [ACTIVE]", True)),
        ("Task [active]", (None, None, "Task [ACTIVE]", True)),
        ("Task [ Active ]", (None, None, "Task [ACTIVE]", True)),
        ("Task [  active  ]", (None, None, "Task [ACTIVE]", True)),
    ],
    ids=["upper", "lower", "mixed", "extra-spaces"],
)
def test_parse_tag_active_alone(heading, expected):
    assert _parse_tag(heading) == expected


def test_parse_tag_done_with_active():
    with pytest.raises(ClickException, match="cannot be combined"):
        _parse_tag("Task [DONE] [ACTIVE]")


def test_parse_tag_active_with_done():
    with pytest.raises(ClickException, match="cannot be combined"):
        _parse_tag("Task [ACTIVE] [DONE]")


# --- sort_todo DONE ---


def test_sort_todo_done_creates_section():
    text = """\
# Project

## Tasks

### Finished [DONE]

Done content.

### Active [HIGH, EASY]

Active content.
"""
    result, done_text = sort_todo(text)
    assert "## DONE" not in result
    assert "Finished" not in result
    assert "Active" in result
    assert "Finished" in done_text
    assert "Done content" in done_text


def test_sort_todo_done_lowercase_normalized():
    text = """\
# Project

## Tasks

### Task [done]

Content.
"""
    result, done_text = sort_todo(text)
    assert "[DONE]" in done_text
    assert "### Task" not in result


def test_sort_todo_done_with_spaces_normalized():
    text = """\
# Project

## Tasks

### Task [ done ]

Content.
"""
    result, done_text = sort_todo(text)
    assert "[DONE]" in done_text


def test_sort_todo_done_existing_section():
    text = """\
# Project

## done

### Old item

Old content.

## Tasks

### New done [done]

New content.

### Active [CRITICAL, HARD]

Active content.
"""
    result, done_text = sort_todo(text)

    # No DONE section in main result
    assert "## DONE" not in result
    assert "## done" not in result

    # Active stays in main result
    assert "Active" in result

    # Both old and new done items in done_text
    assert "Old item" in done_text
    assert "New done" in done_text


def test_sort_todo_done_multiple_groups():
    text = """\
# Project

## Group A

### A done [DONE]

a done

### A active [HIGH, EASY]

a active

## Group B

### B done [done]

b done

### B active [LOW, MEDIUM]

b active
"""
    result, done_text = sort_todo(text)

    assert "## DONE" not in result
    # Active items stay in main result
    assert "A active" in result
    assert "B active" in result
    # Done items in done_text
    assert "A done" in done_text
    assert "B done" in done_text
    assert "A done" not in result
    assert "B done" not in result


def test_sort_todo_no_done_no_section_created():
    text = """\
# Project

## Tasks

### Task [HIGH, EASY]

Content.
"""
    result, done_text = sort_todo(text)
    assert "## DONE" not in result
    assert done_text == ""


def test_sort_todo_done_preserves_existing_section_content():
    text = """\
# Project

## DONE

### Already done

Some old done content.

## Tasks

### Active [LOW, HARD]

Active content.
"""
    result, done_text = sort_todo(text)

    assert "## DONE" not in result
    assert "Already done" in done_text
    assert "Some old done content" in done_text


def test_sort_todo_done_and_untagged_ordering():
    text = """\
# Project

## Tasks

### Done task [DONE]

done

### Untagged task

untagged

### Tagged task [HIGH, EASY]

tagged
"""
    result, done_text = sort_todo(text)

    # Tagged first, untagged second (in Tasks), done removed to done_text
    assert result.index("Tagged task") < result.index("Untagged task")
    assert "Done task" not in result
    assert "Done task" in done_text


def test_sort_todo_done_keeps_tag_in_heading():
    text = """\
# Project

## Tasks

### My finished task [DONE]

Content.
"""
    result, done_text = sort_todo(text)
    assert "My finished task [DONE]" in done_text


def test_sort_todo_done_with_classification():
    text = """\
# Project

## Tasks

### Active [HIGH, EASY]

active

### Finished [CRITICAL, MEDIUM] [done]

done content
"""
    result, done_text = sort_todo(text)
    assert "## DONE" not in result
    assert "[CRITICAL, MEDIUM] [DONE]" in done_text
    assert "Active" in result
    assert "Finished" not in result


def test_sort_todo_done_before_classification():
    text = """\
# Project

## Tasks

### Active [LOW, HARD]

active

### Finished [DONE] [HIGH, EASY]

done content
"""
    result, done_text = sort_todo(text)
    assert "## DONE" not in result
    assert "[HIGH, EASY] [DONE]" in done_text
    assert "Active" in result
    assert "Finished" not in result


def test_sort_todo_done_section_normalizes_existing_headings():
    text = """\
# Project

## Tasks

### Active [HIGH, EASY]

content

## DONE

### speed up rendering [hard, critical] [done]

some content
"""
    result, done_text = sort_todo(text)
    assert "[CRITICAL, HARD] [DONE]" in done_text
    assert "[hard, critical]" not in done_text


# --- sort_todo ACTIVE ---


def test_sort_todo_active_at_top():
    text = """\
# Project

## Tasks

### Low prio [LOW, HARD]

low

### Active task [HIGH, EASY] [ACTIVE]

active

### Top prio [CRITICAL, EASY]

top
"""
    result, done_text = sort_todo(text)
    assert result.index("Active task") < result.index("Top prio")
    assert result.index("Top prio") < result.index("Low prio")


def test_sort_todo_multiple_active_sorted():
    text = """\
# Project

## Tasks

### B [LOW, EASY] [ACTIVE]

b

### A [CRITICAL, HARD] [ACTIVE]

a

### C [HIGH, MEDIUM]

c
"""
    result, done_text = sort_todo(text)
    # Active items first, sorted by importance/difficulty among themselves
    assert result.index("A [CRITICAL, HARD] [ACTIVE]") < result.index(
        "B [LOW, EASY] [ACTIVE]"
    )
    # Non-active after all active
    assert result.index("B [LOW, EASY] [ACTIVE]") < result.index("C [HIGH, MEDIUM]")


def test_sort_todo_active_normalizes_tag():
    text = """\
# Project

## Tasks

### Task [ easy , critical ] [ active ]

Content
"""
    result, done_text = sort_todo(text)
    assert "[CRITICAL, EASY] [ACTIVE]" in result


def test_sort_todo_active_before_untagged():
    text = """\
# Project

## Tasks

### Untagged

u

### Active [LOW, HARD] [ACTIVE]

a

### Tagged [HIGH, EASY]

t
"""
    result, done_text = sort_todo(text)
    assert result.index("Active") < result.index("Tagged")
    assert result.index("Tagged") < result.index("Untagged")


def test_sort_todo_active_across_groups():
    text = """\
# Project

## Group A

### A2 [LOW, EASY]

c

### A1 [HIGH, MEDIUM] [ACTIVE]

c

## Group B

### B2 [CRITICAL, HARD]

c

### B1 [LOW, EASY] [ACTIVE]

c
"""
    result, done_text = sort_todo(text)
    # Within Group A: active first
    assert result.index("A1") < result.index("A2")
    # Within Group B: active first
    assert result.index("B1") < result.index("B2")


def test_sort_todo_active_before_classification():
    """[ACTIVE] [X, Y] normalized to [X, Y] [ACTIVE] and sorted at top."""
    text = """\
# Project

## Tasks

### Normal [CRITICAL, EASY]

n

### Urgent [ACTIVE] [LOW, HARD]

u
"""
    result, done_text = sort_todo(text)
    assert "[LOW, HARD] [ACTIVE]" in result
    assert result.index("Urgent") < result.index("Normal")


def test_sort_todo_active_alone():
    """[ACTIVE] without classification sorts at top, after active-tagged."""
    text = """\
# Project

## Tasks

### Tagged [HIGH, EASY]

t

### Just active [ACTIVE]

a

### Untagged

u
"""
    result, done_text = sort_todo(text)
    assert "[ACTIVE]" in result
    assert result.index("Just active") < result.index("Tagged")
    assert result.index("Tagged") < result.index("Untagged")


def test_sort_todo_active_alone_after_active_tagged():
    text = """\
# Project

## Tasks

### Active untagged [ACTIVE]

au

### Active tagged [LOW, EASY] [ACTIVE]

at

### Normal [CRITICAL, HARD]

n
"""
    result, done_text = sort_todo(text)
    # Active tagged first, then active untagged, then normal tagged
    assert result.index("Active tagged") < result.index("Active untagged")
    assert result.index("Active untagged") < result.index("Normal")


# --- sort_todo error cases ---


@pytest.mark.parametrize(
    "text, match",
    [
        ("## No H1\n\nContent\n", "must be an H1 heading"),
        ("Some paragraph first\n\n## Section\n", "must be an H1 heading"),
        ("# Title\n\nJust content\n", "must contain at least one H2"),
        ("", "must be an H1 heading"),
    ],
    ids=["no-h1", "paragraph-first", "no-h2", "empty"],
)
def test_sort_todo_structural_errors(text, match):
    with pytest.raises(ClickException, match=match):
        sort_todo(text)


def test_sort_todo_invalid_tag_in_h3():
    text = """\
# Project

## Group

### Task [INVALID, EASY]

Content
"""
    with pytest.raises(ClickException, match="one value must be importance"):
        sort_todo(text)


def test_sort_todo_double_brackets_in_h3():
    text = """\
# Project

## Group

### Task [[HIGH, EASY]]

Content
"""
    with pytest.raises(ClickException, match="expected exactly one"):
        sort_todo(text)


def test_sort_todo_h3_outside_h2_warns(capsys):
    text = """\
# Project

### Orphan task [HIGH, EASY]

some content

## Group

### Task [LOW, EASY]

content
"""
    sort_todo(text)
    captured = capsys.readouterr()
    assert "not under any H2 group" in captured.out
    assert "Orphan task" in captured.out


# --- nested heading warnings ---


def test_sort_todo_nested_h4_with_classification_warns(capsys):
    text = """\
# Project

## Group

### Parent task [HIGH, EASY]

#### Subtask [LOW, MEDIUM]

content
"""
    sort_todo(text)
    captured = capsys.readouterr()
    assert "H4 heading 'Subtask [LOW, MEDIUM]'" in captured.out
    assert "nested under H3 'Parent task [HIGH, EASY]'" in captured.out
    assert "moved along with it if marked as done" in captured.out


def test_sort_todo_nested_h5_with_done_warns(capsys):
    text = """\
# Project

## Group

### Parent [CRITICAL, HARD]

##### Deep task [DONE]

content
"""
    sort_todo(text)
    captured = capsys.readouterr()
    assert "H5 heading" in captured.out
    assert "Deep task [DONE]" in captured.out
    assert "nested under H3" in captured.out


def test_sort_todo_nested_h4_with_active_warns(capsys):
    text = """\
# Project

## Group

### Parent [LOW, EASY]

#### Sub [ACTIVE]

content
"""
    sort_todo(text)
    captured = capsys.readouterr()
    assert "H4 heading" in captured.out
    assert "Sub [ACTIVE]" in captured.out


def test_sort_todo_nested_h4_without_tag_no_warning(capsys):
    """H4 headings without todo tags should not produce a warning."""
    text = """\
# Project

## Group

### Parent [HIGH, EASY]

#### Just a subheading

content
"""
    sort_todo(text)
    captured = capsys.readouterr()
    assert "WARNING" not in captured.out


def test_sort_todo_nested_h4_moved_with_done_parent(capsys):
    """When parent H3 is marked done, nested H4 with tags gets moved too."""
    text = """\
# Project

## Group

### Parent [DONE]

#### Subtask [HIGH, EASY]

sub content

### Active [LOW, MEDIUM]

active content
"""
    result, done_text = sort_todo(text)
    captured = capsys.readouterr()
    # Warning should fire
    assert "H4 heading 'Subtask [HIGH, EASY]'" in captured.out
    assert "moved along with it if marked as done" in captured.out
    # The H4 moves to done_text along with the parent
    assert "Subtask" in done_text
    assert "Subtask" not in result
    # Active stays
    assert "Active" in result


# --- CLI integration ---


def test_cli_todo(tmp_empty):
    Path("TODO.md").write_text("""\
# Project

## Group

### B [LOW, EASY]

content b

### A [CRITICAL, HARD]

content a
""")
    runner = CliRunner()
    result = runner.invoke(cli.cli, ["todo"])

    assert result.exit_code == 0
    assert "Sorted" in result.output

    content = Path("TODO.md").read_text()
    assert content.index("A [CRITICAL, HARD]") < content.index("B [LOW, EASY]")
    assert not Path("DONE.md").exists()


def test_cli_todo_archives_done(tmp_empty):
    Path("TODO.md").write_text("""\
# Project

## Group

### Active [HIGH, EASY]

content

### Finished [DONE]

done content
""")
    runner = CliRunner()
    result = runner.invoke(cli.cli, ["todo"])

    assert result.exit_code == 0
    assert "Archived" in result.output

    todo_content = Path("TODO.md").read_text()
    assert "Active" in todo_content
    assert "Finished" not in todo_content

    done_content = Path("DONE.md").read_text()
    assert "# DONE" in done_content
    assert "Finished" in done_content


def test_cli_todo_appends_to_existing_done(tmp_empty):
    Path("DONE.md").write_text("# DONE\n\n### Old item\n\nold content\n")
    Path("TODO.md").write_text("""\
# Project

## Group

### Active [HIGH, EASY]

content

### New done [DONE]

new done content
""")
    runner = CliRunner()
    result = runner.invoke(cli.cli, ["todo"])

    assert result.exit_code == 0

    done_content = Path("DONE.md").read_text()
    assert "Old item" in done_content
    assert "New done" in done_content


def test_cli_todo_done_md_in_todo_dir(tmp_empty):
    """DONE.md is created next to TODO.md, not in cwd."""
    Path("TODO.md").write_text("""\
# Project

## Group

### Finished [DONE]

done content
""")
    Path("sub").mkdir()
    os.chdir("sub")
    runner = CliRunner()
    result = runner.invoke(cli.cli, ["todo"])

    assert result.exit_code == 0
    assert not Path("DONE.md").exists()  # not in cwd
    assert Path(tmp_empty, "DONE.md").exists()  # next to TODO.md


def test_cli_todo_no_file(tmp_empty):
    runner = CliRunner()
    result = runner.invoke(cli.cli, ["todo"])

    assert result.exit_code != 0
    assert "Could not find TODO.md" in result.output
