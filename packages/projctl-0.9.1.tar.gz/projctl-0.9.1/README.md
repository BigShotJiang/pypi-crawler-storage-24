# projctl

[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)

A toolkit for managing Python packages 📦🐍

`projctl` allows you to create new Python packages that follow best practices: README, CHANGELOG, a command to bootstrap the environment, CI with GitHub Actions, and more!

## Installation

```sh
pip install projctl
```

## Dev

```sh
conda create --name projctl python=3.13 -c conda-forge -y
pip install -e '.[check]'
```


## Features

## Create a new package

```sh
projctl new mynewpackage
```

## Test your README

Test your README to ensure it runs!

```
projctl test-md --file README.md
```

## Generate commit messages

```sh
# Paste your OpenAI API key into this
llm keys set openai

# set default model
llm models default gpt-4o-mini

# generate commit message and commit
projctl commit
```

## Manage profiles, skills, and files

Discover and activate [Claude Code](https://docs.anthropic.com/en/docs/claude-code) skills from your project and installed packages. Skills are directories containing a `SKILL.md` file, stored under `.projctl/claude/skills/`. Profile-dependent files live under `.projctl/files/<profile>/`.

Configure packages and profiles in `pyproject.toml`:

```toml
[tool.projctl.skills]
packages = ["agentclient"]
exclude = ["debug-tool"]

[tool.projctl.skills.profiles]
local = ["upload", "deploy"]
dev = ["upload", "deploy", "agentclient.debug-tool"]
```

List all discovered skills (active ones shown in green):

```sh
projctl profile list
```

Activate a profile (symlinks editable skills, copies the rest into `.claude/skills/`, and links profile files to project root):

```sh
projctl profile set dev
```

This also symlinks `CLAUDE.md` in the project root. It looks for `.projctl/claude/CLAUDE.<profile>.md` first (e.g. `.projctl/claude/CLAUDE.dev.md`), falling back to `.projctl/claude/CLAUDE.md` if the profile-specific file doesn't exist. Files in `.projctl/files/dev/` are symlinked to the project root.

Install only skills not assigned to any profile:

```sh
projctl profile set
```

Check skills for broken links and profile configuration issues:

```sh
projctl profile lint
projctl profile lint --tree
```

