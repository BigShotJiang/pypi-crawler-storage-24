"""clawaudit cvedb command."""

import click


@click.group()
def cvedb():
    """Manage CVE database."""
    pass


@cvedb.command()
def update():
    """Update local CVE database from GitHub Advisory."""
    from clawaudit.cvedb.fetcher import update_cvedb
    update_cvedb()


@cvedb.command(name="list")
@click.option("--severity", default=None, help="Filter by severity (e.g. critical, high)")
def list_cves(severity):
    """List advisories in local database."""
    from clawaudit.cvedb.matcher import load_cvedb

    cves = load_cvedb()
    if severity:
        cves = [c for c in cves if c.get("severity", "").upper() == severity.upper()]

    if not cves:
        click.echo("No advisories found.")
        return

    for entry in cves:
        sev = entry.get("severity", "?")
        title = entry.get("title", "")
        affected = entry.get("affected", "")
        cve_id = entry.get("cve", "")
        cve_part = f" ({cve_id})" if cve_id else ""
        url = entry.get("url", "")
        click.echo(f"  {entry['id']}{cve_part}  [{sev}]  {title}  (affected: {affected})  {url}")
