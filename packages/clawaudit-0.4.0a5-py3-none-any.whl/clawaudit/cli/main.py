"""Foresight ClawAudit CLI entry point."""

import click

from clawaudit import __version__


@click.group(context_settings={"help_option_names": ["-h", "--help"]})
@click.version_option(__version__, prog_name="clawaudit")
def cli():
    """Foresight ClawAudit - OpenClaw security audit tool."""
    pass


# Register sub-commands
from clawaudit.cli.commands.scan import scan  # noqa: E402
from clawaudit.cli.commands.cvedb import cvedb  # noqa: E402
from clawaudit.cli.commands.baseline import baseline  # noqa: E402

cli.add_command(scan)
cli.add_command(cvedb)
cli.add_command(baseline)


if __name__ == "__main__":
    cli()
