"""Foresight ClawAudit - OpenClaw security audit tool."""

from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("clawaudit")
except PackageNotFoundError:
    __version__ = "0.0.0-dev"
