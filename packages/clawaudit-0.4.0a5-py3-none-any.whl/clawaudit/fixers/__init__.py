"""Auto-fix framework for ClawAudit findings."""

from clawaudit.fixers.actions import FixAction
from clawaudit.fixers.executor import FixExecutor

__all__ = ["FixAction", "FixExecutor"]
