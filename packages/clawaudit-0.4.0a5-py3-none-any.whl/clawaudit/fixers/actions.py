"""FixAction dataclass — describes a single remediation action."""

from dataclasses import dataclass


@dataclass
class FixAction:
    """A single auto-fix action attached to a Finding.

    fix_type:
        "file_edit"       — replace old_value with new_value in target_file
        "json_path_edit"  — set new_value at JSON path (old_value stores path as JSON array) in target_file
        "command"         — run a shell command
        "manual"          — cannot be auto-fixed, output instructions for the user
    """

    description: str
    fix_type: str  # "file_edit" | "command" | "manual"
    target_file: str = ""
    old_value: str = ""
    new_value: str = ""
    command: str = ""
    manual_steps: str = ""
