"""PA-DATA* — Data security scanner."""

import os
import re
from pathlib import Path
from typing import List, Optional

from clawaudit.scanners.base import BaseScanner
from clawaudit.fixers.actions import FixAction
from clawaudit.models.finding import Finding
from clawaudit.models.severity import Severity, Category


class DataScanner(BaseScanner):
    category = Category.DATA
    mode = "local"

    def run(self, checks: Optional[List[str]] = None) -> List[Finding]:
        self.findings = []
        all_checks = {
            "PA-DATA01": self._data01_api_keys,
            "PA-DATA02": self._data02_private_keys,
            "PA-DATA03": self._data03_log_leakage,
            "PA-DATA04": self._data04_exfil_chain,
        }
        if not self.discovery.config_files and not self.discovery.install_dir:
            for check_id in all_checks:
                if checks and check_id not in checks:
                    continue
                self.skip(check_id, check_id, Severity.HIGH,
                          "No OpenClaw installation found")
            return self.findings
        for check_id, fn in all_checks.items():
            if checks and check_id not in checks:
                continue
            fn()
        return self.findings

    # ------------------------------------------------------------------
    # PA-DATA01: API key plaintext exposure
    # ------------------------------------------------------------------
    _API_KEY_PATTERNS = [
        r"sk-ant-api\d+-[a-zA-Z0-9_-]{20,}",        # Anthropic
        r"sk-proj-[a-zA-Z0-9_-]{20,}",                # OpenAI project key
        r"sk-[a-zA-Z0-9]{48,}",                       # OpenAI legacy (48+ chars to reduce false positives)
        r"ghp_[a-zA-Z0-9]{36}",                       # GitHub PAT
        r"gho_[a-zA-Z0-9]{36}",                       # GitHub OAuth
        r"AKIA[A-Z0-9]{16}",                          # AWS Access Key
        r"xoxb-[0-9]+-[a-zA-Z0-9]+",                  # Slack Bot Token
        r"xoxp-[0-9]+-[a-zA-Z0-9]+",                  # Slack User Token
        r"AIza[a-zA-Z0-9_-]{35}",                     # Google Cloud API Key
        r"sk_live_[a-zA-Z0-9]{24,}",                  # Stripe Live Key
        r"SG\.[a-zA-Z0-9_-]{22}\.[a-zA-Z0-9_-]{43}",  # SendGrid
    ]

    def _data01_api_keys(self):
        check_id = "PA-DATA01"
        title = "API keys exposed in plaintext"
        hits = []
        hit_details = []

        compiled = [(re.compile(p), p) for p in self._API_KEY_PATTERNS]

        # Scan config files (skip .env)
        for f in self.discovery.config_files:
            if f.name == ".env":
                continue
            try:
                text = f.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            for regex, _ in compiled:
                if regex.search(text):
                    hits.append(f.name)
                    hit_details.append(str(f))
                    break

        # Scan skill files
        if self.discovery.install_dir:
            for sub in ("workspace/skills", "skills"):
                skills_dir = self.discovery.install_dir / sub
                if not skills_dir.is_dir():
                    continue
                for src in skills_dir.rglob("*"):
                    if not src.is_file() or src.suffix in (".png", ".jpg", ".gif", ".zip", ".gz"):
                        continue
                    if ".git" in src.parts:
                        continue
                    try:
                        text = src.read_text(encoding="utf-8", errors="ignore")
                    except OSError:
                        continue
                    for regex, _ in compiled:
                        if regex.search(text):
                            hits.append(src.name)
                            hit_details.append(str(src))
                            break

        if hits:
            self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                             detail=f"API keys found in: {', '.join(hits)}",
                             remediation="Move API keys to .env or secret manager, use ${VAR} references",
                             fix_actions=[
                                 FixAction(
                                     description="Remove plaintext API keys",
                                     fix_type="manual",
                                     manual_steps=(
                                         "Plaintext API keys found in:\n"
                                         + "".join(f"  - {d}\n" for d in hit_details)
                                         + "Remove or replace the plaintext keys, and rotate the exposed keys immediately."
                                     ),
                                 ),
                             ])
        else:
            self.add_finding(check_id, title, Severity.CRITICAL, "PASS")

    # ------------------------------------------------------------------
    # PA-DATA02: Private key / mnemonic plaintext
    # ------------------------------------------------------------------
    # BIP39 high-frequency words used to reduce mnemonic false positives
    _BIP39_MARKERS = {
        "abandon", "ability", "abstract", "abuse", "access", "accident",
        "account", "acid", "acoustic", "actual", "alpha", "antenna",
        "armor", "artwork", "auction", "banana", "basket", "bench",
        "biology", "bonus", "brave", "bronze", "bubble", "canal",
        "canvas", "carbon", "casino", "catalog", "celery", "census",
        "cherry", "cigar", "citizen", "claim", "clutch", "coconut",
        "column", "coral", "cotton", "crystal", "cushion", "debris",
        "decorate", "diesel", "dinosaur", "dolphin", "dragon", "elder",
        "elegant", "elevator", "embark", "engage", "envelope", "erosion",
        "estate", "evoke", "exotic", "fabric", "faculty", "flavor",
        "fossil", "galaxy", "garage", "ginger", "goddess", "gorilla",
        "harvest", "hedgehog", "hybrid", "ivory", "kangaroo", "ketchup",
        "kidney", "kitten", "laptop", "lawsuit", "leopard", "lyrics",
        "magnet", "mammal", "mandate", "meadow", "miracle", "mosquito",
        "muffin", "mushroom", "neglect", "nuclear", "noodle", "oasis",
        "obscure", "october", "olive", "opera", "orbit", "ostrich",
        "oxygen", "panda", "peasant", "pelican", "picnic", "pistol",
        "plunge", "polar", "pumpkin", "puzzle", "quantum", "raccoon",
        "ranch", "raven", "ribbon", "robust", "saddle", "salmon",
        "satoshi", "scatter", "seminar", "shrimp", "siege", "slender",
        "soccer", "spatial", "stereo", "stumble", "supreme", "tattoo",
        "tobacco", "tornado", "tuna", "turtle", "umbrella", "universe",
        "vacant", "valve", "vanish", "venture", "violin", "volcano",
        "voyage", "wasp", "wealth", "weapon", "whale", "whisper",
        "wrestle", "zebra", "zone",
    }

    def _data02_private_keys(self):
        check_id = "PA-DATA02"
        title = "Private key or mnemonic in plaintext"

        if not self.discovery.install_dir:
            self.add_finding(check_id, title, Severity.CRITICAL, "PASS",
                             detail="No installation directory to scan")
            return

        workspace = self.discovery.install_dir / "workspace"
        if not workspace.is_dir():
            self.add_finding(check_id, title, Severity.CRITICAL, "PASS",
                             detail="No workspace directory to scan")
            return

        eth_pattern = re.compile(r"\b0x[a-fA-F0-9]{64}\b")
        pem_pattern = re.compile(
            r"-----BEGIN\s+(?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----"
        )
        mnemonic_pattern = re.compile(r"\b([a-z]{3,12}\s+){11,23}[a-z]{3,12}\b")

        skip_exts = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".zip", ".gz", ".tar", ".bin"}
        hits = []
        hit_paths = []

        for fpath in workspace.rglob("*"):
            if not fpath.is_file() or fpath.suffix in skip_exts:
                continue
            if ".git" in fpath.parts:
                continue
            try:
                text = fpath.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue

            if eth_pattern.search(text) or pem_pattern.search(text):
                hits.append(fpath.name)
                hit_paths.append(str(fpath))
                continue

            # Mnemonic: require match AND at least 3 BIP39 marker words
            m = mnemonic_pattern.search(text)
            if m:
                words = set(m.group(0).lower().split())
                if len(words & self._BIP39_MARKERS) >= 3:
                    hits.append(fpath.name)
                    hit_paths.append(str(fpath))

        if hits:
            self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                             detail=f"Sensitive material in: {', '.join(hits)}",
                             remediation="Remove plaintext keys/mnemonics, use vault/encrypted storage",
                             fix_actions=[
                                 FixAction(
                                     description="Remove plaintext private keys/mnemonics",
                                     fix_type="manual",
                                     manual_steps=(
                                         "Private keys or mnemonics found in:\n"
                                         + "".join(f"  - {p}\n" for p in hit_paths)
                                         + "Remove or encrypt these files. If crypto wallet mnemonics were exposed, transfer assets to a new wallet immediately."
                                     ),
                                 ),
                             ])
        else:
            self.add_finding(check_id, title, Severity.CRITICAL, "PASS")

    # ------------------------------------------------------------------
    # PA-DATA03: Sensitive data in logs
    # ------------------------------------------------------------------
    def _data03_log_leakage(self):
        check_id = "PA-DATA03"
        title = "Sensitive data logged in output"
        # Match log/print statements that directly output a sensitive variable
        patterns = [
            # Python: print/log with sensitive variable as argument
            r"(print|logging\.\w+|logger\.\w+)\s*\(.*\b(password|token|secret|api_?key|credential)\s*[,\)]",
            r"(print|logging\.\w+|logger\.\w+)\s*\(.*f['\"].*\{.*(password|token|secret|api_?key|credential).*\}",
            # JS/TS: console.log with sensitive variable
            r"console\.\w+\s*\(.*\b(password|token|secret|apiKey|credential)\s*[,\)]",
            r"console\.\w+\s*\(.*`.*\$\{.*(password|token|secret|apiKey|credential).*\}",
        ]

        if not self.discovery.install_dir:
            self.add_finding(check_id, title, Severity.HIGH, "PASS")
            return

        scan_dirs = []
        for sub in ("workspace", "workspace/skills", "skills"):
            d = self.discovery.install_dir / sub
            if d.is_dir():
                scan_dirs.append(d)

        if not scan_dirs:
            self.add_finding(check_id, title, Severity.HIGH, "PASS",
                             detail="No workspace/skills directory to scan")
            return

        hits = []
        hit_paths = []
        seen = set()

        for scan_dir in scan_dirs:
            for ext in ("*.py", "*.js", "*.ts"):
                for src in scan_dir.rglob(ext):
                    resolved = src.resolve()
                    if resolved in seen:
                        continue
                    seen.add(resolved)
                    try:
                        text = src.read_text(encoding="utf-8", errors="ignore")
                    except OSError:
                        continue
                    for pat in patterns:
                        if re.search(pat, text, re.IGNORECASE):
                            hits.append(src.name)
                            hit_paths.append(str(src))
                            break

        if hits:
            self.add_finding(check_id, title, Severity.HIGH, "FAIL",
                             detail=f"Logging sensitive data in: {', '.join(hits)}",
                             remediation="Redact sensitive values before logging",
                             fix_actions=[
                                 FixAction(
                                     description="Review sensitive data in log statements",
                                     fix_type="manual",
                                     manual_steps=(
                                         "Sensitive data may be logged in:\n"
                                         + "".join(f"  - {p}\n" for p in hit_paths)
                                         + "Review each file and redact sensitive values before logging."
                                     ),
                                 ),
                             ])
        else:
            self.add_finding(check_id, title, Severity.HIGH, "PASS")

    # ------------------------------------------------------------------
    # PA-DATA04: Data exfiltration chain
    # ------------------------------------------------------------------
    def _data04_exfil_chain(self):
        check_id = "PA-DATA04"
        title = "Potential data exfiltration chain"

        patterns_read = [
            # Python
            r"\bopen\s*\(",
            r"Path.*\.read",
            r"read_file|file_read",
            # JS/TS
            r"fs\.readFileSync\s*\(",
            r"fs\.readFile\s*\(",
            r"fsPromises\.readFile\s*\(",
        ]
        patterns_net = [
            # Python
            r"requests\.(get|post|put|delete)\s*\(",
            r"\burllib\b",
            r"\bhttpx\b",
            r"http\.client",
            # JS/TS
            r"\bfetch\s*\(",
            r"\baxios\b",
            r"XMLHttpRequest",
            r"node-fetch",
            r"\bgot\s*\(",
        ]

        read_re = [re.compile(p, re.IGNORECASE) for p in patterns_read]
        net_re = [re.compile(p, re.IGNORECASE) for p in patterns_net]

        if not self.discovery.install_dir:
            self.add_finding(check_id, title, Severity.HIGH, "PASS")
            return

        # Scan skill directories
        scan_dirs = []
        for sub in ("workspace/skills", "skills"):
            d = self.discovery.install_dir / sub
            if d.is_dir():
                scan_dirs.append(d)

        if not scan_dirs:
            self.add_finding(check_id, title, Severity.HIGH, "PASS",
                             detail="No skills directory to scan")
            return

        overlap = []
        overlap_paths = []
        seen = set()

        for scan_dir in scan_dirs:
            for ext in ("*.py", "*.js", "*.ts"):
                for src in scan_dir.rglob(ext):
                    resolved = src.resolve()
                    if resolved in seen:
                        continue
                    seen.add(resolved)
                    try:
                        text = src.read_text(encoding="utf-8", errors="ignore")
                    except OSError:
                        continue
                    has_read = any(p.search(text) for p in read_re)
                    has_net = any(p.search(text) for p in net_re)
                    if has_read and has_net:
                        overlap.append(src.name)
                        overlap_paths.append(str(src))

        if overlap:
            # Try to identify skill names
            skill_names = set()
            for p in overlap_paths:
                path = Path(p)
                for parent in path.parents:
                    if (parent / "SKILL.md").is_file():
                        skill_names.add(parent.name)
                        break

            self.add_finding(check_id, title, Severity.HIGH, "FAIL",
                             detail=f"File read + network request in: {', '.join(overlap)}",
                             remediation="Review the affected skill for data exfiltration",
                             fix_actions=[
                                 FixAction(
                                     description="Review potential data exfiltration in skills",
                                     fix_type="manual",
                                     manual_steps=(
                                         "Files with both file read and network request:\n"
                                         + "".join(f"  - {p}\n" for p in overlap_paths)
                                         + ("Affected skill(s): " + ", ".join(sorted(skill_names)) + "\n"
                                            if skill_names else "")
                                         + "Review these files to confirm they are not exfiltrating sensitive data. "
                                         "Remove untrusted skills:\n"
                                         + ("".join(f"  rm -rf ~/.openclaw/skills/{s}\n" for s in sorted(skill_names))
                                            if skill_names else "")
                                     ),
                                 ),
                             ])
        else:
            self.add_finding(check_id, title, Severity.HIGH, "PASS")
