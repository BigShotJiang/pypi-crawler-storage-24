"""PA-SYS* — System security scanner."""

import os
import platform
import subprocess
from pathlib import Path
from typing import List, Optional

from clawaudit.scanners.base import BaseScanner
from clawaudit.fixers.actions import FixAction
from clawaudit.models.finding import Finding
from clawaudit.models.severity import Severity, Category


class SysScanner(BaseScanner):
    category = Category.SYS
    mode = "local"

    def run(self, checks: Optional[List[str]] = None) -> List[Finding]:
        self.findings = []
        all_checks = {
            "PA-SYS01": self._sys01_root,
            "PA-SYS02": self._sys02_file_integrity,
            "PA-SYS03": self._sys03_sensitive_dirs,
            "PA-SYS04": self._sys04_cron,
            "PA-SYS05": self._sys05_ssh_bruteforce,
            "PA-SYS06": self._sys06_nodejs_cve,
        }
        for check_id, fn in all_checks.items():
            if checks and check_id not in checks:
                continue
            fn()
        return self.findings

    # ------------------------------------------------------------------
    # PA-SYS01: Running as root
    # ------------------------------------------------------------------
    def _sys01_root(self):
        check_id = "PA-SYS01"
        title = "OpenClaw process running as root"

        try:
            # Use pgrep but exclude our own process
            my_pid = str(os.getpid())
            result = subprocess.run(
                ["pgrep", "-f", "openclaw"],
                capture_output=True, text=True, timeout=5,
            )
            if result.returncode != 0 or not result.stdout.strip():
                self.skip(check_id, title, Severity.CRITICAL,
                          "OpenClaw process not found")
                return

            pids = [p for p in result.stdout.strip().splitlines() if p != my_pid]
            if not pids:
                self.skip(check_id, title, Severity.CRITICAL,
                          "OpenClaw process not found")
                return

            root_pids = []
            if platform.system() == "Linux":
                for pid in pids:
                    try:
                        st = os.stat(f"/proc/{pid}")
                        if st.st_uid == 0:
                            root_pids.append(pid)
                    except (FileNotFoundError, PermissionError):
                        pass
            else:
                # macOS / other: use ps to get UID
                for pid in pids:
                    try:
                        ps_result = subprocess.run(
                            ["ps", "-o", "uid=", "-p", pid],
                            capture_output=True, text=True, timeout=3,
                        )
                        if ps_result.returncode == 0:
                            uid = ps_result.stdout.strip()
                            if uid == "0":
                                root_pids.append(pid)
                    except (FileNotFoundError, subprocess.TimeoutExpired):
                        pass

            if root_pids:
                self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                                 detail=f"PIDs running as root: {', '.join(root_pids)}",
                                 remediation="Run OpenClaw as a non-root user",
                                 fix_actions=[
                                     FixAction(
                                         description="Stop running OpenClaw as root",
                                         fix_type="manual",
                                         manual_steps=(
                                             f"OpenClaw process(es) running as root: PID {', '.join(root_pids)}\n"
                                             "Stop the OpenClaw process and restart it as a non-root user. "
                                             "Running as root gives the AI agent full system access, "
                                             "which is a critical security risk."
                                         ),
                                     ),
                                 ])
            else:
                self.add_finding(check_id, title, Severity.CRITICAL, "PASS")
        except (FileNotFoundError, subprocess.TimeoutExpired):
            self.skip(check_id, title, Severity.CRITICAL,
                      "pgrep not available")

    # ------------------------------------------------------------------
    # PA-SYS02: System critical file permission anomaly
    # ------------------------------------------------------------------
    def _sys02_file_integrity(self):
        check_id = "PA-SYS02"
        title = "System critical file permission anomaly"

        import stat

        # (path, check_description, bad_bits, expected_fix)
        critical_checks = [
            (Path("/etc/passwd"), "world-writable",
             stat.S_IWOTH, "chmod o-w /etc/passwd"),
            (Path("/etc/shadow"), "world-readable",
             stat.S_IROTH, "chmod o-r /etc/shadow"),
            (Path("/etc/shadow"), "world-writable",
             stat.S_IWOTH, "chmod o-w /etc/shadow"),
            (Path("/etc/ssh/sshd_config"), "world-writable",
             stat.S_IWOTH, "chmod o-w /etc/ssh/sshd_config"),
            (Path("/etc/sudoers"), "world-writable",
             stat.S_IWOTH, "chmod o-w /etc/sudoers"),
            (Path.home() / ".ssh" / "authorized_keys", "group/other writable",
             stat.S_IWGRP | stat.S_IWOTH, "chmod 644 ~/.ssh/authorized_keys"),
            (Path.home() / ".ssh" / "id_rsa", "group/other readable",
             stat.S_IRGRP | stat.S_IROTH, "chmod 600 ~/.ssh/id_rsa"),
            (Path.home() / ".ssh" / "id_ed25519", "group/other readable",
             stat.S_IRGRP | stat.S_IROTH, "chmod 600 ~/.ssh/id_ed25519"),
        ]

        anomalies = []
        fix_commands = []
        for f, desc, bad_bits, fix_cmd in critical_checks:
            if not f.exists():
                continue
            try:
                st = f.stat()
                if st.st_mode & bad_bits:
                    anomalies.append(f"{f}: {desc}")
                    fix_commands.append(fix_cmd)
            except OSError:
                continue

        if anomalies:
            self.add_finding(check_id, title, Severity.HIGH, "FAIL",
                             detail="; ".join(anomalies),
                             remediation="Fix file permissions on system critical files",
                             fix_actions=[
                                 FixAction(
                                     description=f"chmod {f_cmd.split()[1]} {f_cmd.split()[2]}",
                                     fix_type="command",
                                     command=f_cmd,
                                 )
                                 for f_cmd in fix_commands
                             ])
        else:
            self.add_finding(check_id, title, Severity.HIGH, "PASS",
                             detail="System critical file permissions are correct")

    # ------------------------------------------------------------------
    # PA-SYS03: Sensitive directory changes in 24h
    # ------------------------------------------------------------------
    def _sys03_sensitive_dirs(self):
        check_id = "PA-SYS03"
        title = "Sensitive directories modified in last 24h"

        is_root = os.geteuid() == 0

        # /etc requires root; user dirs don't
        dirs = [str(Path.home() / ".ssh"), str(Path.home() / ".gnupg")]
        if is_root:
            dirs.insert(0, "/etc")

        modified_files = []

        for d in dirs:
            if not Path(d).is_dir():
                continue
            try:
                result = subprocess.run(
                    ["find", d, "-type", "f", "-mtime", "-1"],
                    capture_output=True, text=True, timeout=10,
                )
                if result.stdout.strip():
                    modified_files.extend(result.stdout.strip().splitlines())
            except (FileNotFoundError, subprocess.TimeoutExpired):
                pass

        total = len(modified_files)
        threshold = 50 if is_root else 10

        if total > threshold:
            # Show up to 20 modified files for context
            sample = modified_files[:20]
            detail = f"{total} files modified in last 24h"
            if not is_root:
                detail += " (user dirs only, /etc requires root)"
            self.add_finding(check_id, title, Severity.HIGH, "FAIL",
                             detail=detail,
                             remediation="Investigate unexpected file changes",
                             fix_actions=[
                                 FixAction(
                                     description="Investigate sensitive directory changes",
                                     fix_type="manual",
                                     manual_steps=(
                                         f"{total} files modified in last 24h. Sample:\n"
                                         + "".join(f"  - {f}\n" for f in sample)
                                         + (f"  ... and {total - 20} more\n" if total > 20 else "")
                                         + "Review these changes. If unexpected, check for unauthorized access or malware."
                                     ),
                                 ),
                             ])
        else:
            detail = f"{total} files modified in last 24h"
            if not is_root:
                detail += " (user dirs only, /etc requires root)"
            self.add_finding(check_id, title, Severity.HIGH, "PASS",
                             detail=detail)

    # ------------------------------------------------------------------
    # PA-SYS04: Anomalous cron/systemd tasks
    # ------------------------------------------------------------------
    def _sys04_cron(self):
        check_id = "PA-SYS04"
        title = "Anomalous scheduled tasks (cron/systemd)"

        import re

        suspicious = []
        suspect_patterns = [
            re.compile(r"(curl|wget)\s.*\|\s*(bash|sh|zsh|python|perl)", re.IGNORECASE),
            re.compile(r"(curl|wget)\s.*&&\s*(bash|sh|zsh|python|perl)", re.IGNORECASE),
            re.compile(r"(curl|wget)\s.*;\s*(bash|sh|zsh|python|perl)", re.IGNORECASE),
            re.compile(r"(curl|wget)\s+-o\s+\S+.*&&\s*(chmod|\./)"),
        ]

        def _check_cron_lines(text: str, source: str):
            for line in text.splitlines():
                line = line.strip()
                if line and not line.startswith("#"):
                    if any(p.search(line) for p in suspect_patterns):
                        suspicious.append(f"[{source}] {line[:120]}")

        is_root = os.geteuid() == 0

        # 1. Current user crontab (no root needed)
        try:
            result = subprocess.run(["crontab", "-l"], capture_output=True, text=True, timeout=5)
            if result.returncode == 0 and result.stdout.strip():
                _check_cron_lines(result.stdout, "crontab")
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

        # 2. OpenClaw cron jobs (no root needed)
        if self.discovery.install_dir:
            cron_json = self.discovery.install_dir / "cron" / "jobs.json"
            if cron_json.is_file():
                try:
                    import json
                    jobs = json.loads(cron_json.read_text(errors="ignore"))
                    if isinstance(jobs, list):
                        for job in jobs:
                            cmd = job.get("command", "") if isinstance(job, dict) else ""
                            if cmd and any(p.search(cmd) for p in suspect_patterns):
                                suspicious.append(f"[openclaw cron] {cmd[:120]}")
                except Exception:
                    pass

        # 3. System-level cron (root only)
        if is_root:
            system_cron_paths = [Path("/etc/crontab")]
            cron_d = Path("/etc/cron.d")
            if cron_d.is_dir():
                system_cron_paths.extend(cron_d.glob("*"))
            for cron_file in system_cron_paths:
                if cron_file.is_file():
                    try:
                        _check_cron_lines(cron_file.read_text(errors="ignore"), str(cron_file))
                    except OSError:
                        pass

        # 4. systemd timers
        try:
            result = subprocess.run(
                ["systemctl", "list-timers", "--all", "--no-pager", "--plain"],
                capture_output=True, text=True, timeout=10,
            )
            if result.returncode == 0:
                _check_cron_lines(result.stdout, "systemd-timer")
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

        # 5. User systemd units
        user_unit_dir = Path.home() / ".config" / "systemd" / "user"
        if user_unit_dir.is_dir():
            for unit_file in user_unit_dir.glob("*.service"):
                if unit_file.is_file():
                    try:
                        _check_cron_lines(
                            unit_file.read_text(errors="ignore"),
                            str(unit_file),
                        )
                    except OSError:
                        pass

        if suspicious:
            self.add_finding(check_id, title, Severity.HIGH, "FAIL",
                             detail=f"Suspicious tasks: {'; '.join(suspicious)}",
                             remediation="Review and remove unauthorized cron jobs",
                             fix_actions=[
                                 FixAction(
                                     description="Review suspicious scheduled tasks",
                                     fix_type="manual",
                                     manual_steps=(
                                         "Suspicious scheduled tasks detected:\n"
                                         + "".join(f"  - {s}\n" for s in suspicious)
                                         + "Review each task. To remove:\n"
                                         "  User crontab: crontab -e (delete the line)\n"
                                         + ("  OpenClaw cron: edit ~/.openclaw/cron/jobs.json\n"
                                            if any("[openclaw" in s for s in suspicious) else "")
                                         + ("  System cron: remove the file from /etc/cron.d/\n"
                                            if any("[/etc" in s for s in suspicious) else "")
                                         + ("  systemd timer: systemctl disable --now <timer>\n"
                                            if any("[systemd-timer]" in s for s in suspicious) else "")
                                         + ("  User unit: rm ~/.config/systemd/user/<service> && systemctl --user daemon-reload\n"
                                            if any("[" + str(Path.home()) in s for s in suspicious) else "")
                                     ),
                                 ),
                             ])
        else:
            detail = "No suspicious scheduled tasks found (cron, systemd timers/units checked)"
            if not is_root:
                detail += " (system cron not checked, requires root)"
            self.add_finding(check_id, title, Severity.HIGH, "PASS",
                             detail=detail)

    # ------------------------------------------------------------------
    # PA-SYS05: SSH brute force attempts
    # ------------------------------------------------------------------
    def _sys05_ssh_bruteforce(self):
        check_id = "PA-SYS05"
        title = "SSH brute force attempts in last 24h"

        import re
        from datetime import datetime, timedelta

        failed_count = 0
        source = None

        # Method 1: journalctl (may work without root if user is in systemd-journal group)
        try:
            result = subprocess.run(
                ["journalctl", "-u", "sshd", "--since", "24 hours ago",
                 "--no-pager", "--grep", "Failed|Invalid"],
                capture_output=True, text=True, timeout=10,
            )
            if result.returncode == 0 and result.stdout:
                failed_count = len(result.stdout.strip().splitlines())
                source = "journalctl"
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

        # Method 2: auth.log / secure (needs root usually)
        if source is None:
            cutoff = datetime.now() - timedelta(hours=24)
            fail_re = re.compile(r"sshd.*(Failed|Invalid)", re.IGNORECASE)

            for log in ("/var/log/auth.log", "/var/log/secure"):
                if not Path(log).is_file():
                    continue
                try:
                    with open(log, errors="ignore") as fh:
                        for line in fh:
                            if not fail_re.search(line):
                                continue
                            # auth.log format: "Mon DD HH:MM:SS"
                            try:
                                parts = line.split()[:3]
                                # Try current year first, handle year boundary
                                for year in (cutoff.year, cutoff.year - 1):
                                    ts = datetime.strptime(
                                        f"{year} {parts[0]} {parts[1]} {parts[2]}",
                                        "%Y %b %d %H:%M:%S",
                                    )
                                    if ts <= datetime.now():
                                        break
                                if ts >= cutoff:
                                    failed_count += 1
                            except (ValueError, IndexError):
                                pass
                    source = log
                except OSError:
                    pass
                break

        if source is None:
            self.skip(check_id, title, Severity.HIGH,
                      "Cannot read SSH logs (journalctl unavailable, auth.log not readable)")
            return

        if failed_count > 100:
            self.add_finding(check_id, title, Severity.HIGH, "FAIL",
                             detail=f"{failed_count} failed SSH attempts (source: {source})",
                             remediation="Configure fail2ban, disable password auth, use key-only SSH",
                             fix_actions=[
                                 FixAction(
                                     description="Mitigate SSH brute force attacks",
                                     fix_type="manual",
                                     manual_steps=(
                                         f"{failed_count} failed SSH login attempts in the last 24 hours.\n"
                                         "Install fail2ban, disable password authentication "
                                         "(PasswordAuthentication no in sshd_config), and use key-based SSH only."
                                     ),
                                 ),
                             ])
        else:
            self.add_finding(check_id, title, Severity.HIGH, "PASS",
                             detail=f"{failed_count} failed SSH attempts")

    # ------------------------------------------------------------------
    # PA-SYS06: Node.js version CVE
    # ------------------------------------------------------------------
    def _sys06_nodejs_cve(self):
        check_id = "PA-SYS06"
        title = "Node.js version vulnerable (CVE-2026-21636)"

        try:
            result = subprocess.run(
                ["node", "--version"],
                capture_output=True, text=True, timeout=5,
            )
            if result.returncode != 0:
                self.skip(check_id, title, Severity.CRITICAL,
                          "Node.js not found")
                return

            ver = result.stdout.strip().lstrip("v")
            parts = ver.split(".")
            major = int(parts[0])
            minor = int(parts[1]) if len(parts) > 1 else 0
            patch = int(parts[2]) if len(parts) > 2 else 0

            # CVE-2026-21636 fixed versions per release line:
            # 18.x: >= 18.20.6, 20.x: >= 20.18.3, 22.x: >= 22.14.0, 23.x: >= 23.7.0
            vulnerable = False
            if major == 18 and (minor < 20 or (minor == 20 and patch < 6)):
                vulnerable = True
            elif major == 20 and (minor < 18 or (minor == 18 and patch < 3)):
                vulnerable = True
            elif major == 22 and minor < 14:
                vulnerable = True
            elif major == 23 and minor < 7:
                vulnerable = True
            # Other major versions (e.g. 19, 21) are EOL — flag as vulnerable
            elif major < 18 or major in (19, 21):
                vulnerable = True

            if vulnerable:
                self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                                 detail=f"Node.js {ver} is vulnerable",
                                 remediation="Upgrade Node.js to >= 18.20.6, >= 20.18.3, >= 22.14.0, or >= 23.7.0",
                                 fix_actions=[
                                     FixAction(
                                         description="Upgrade Node.js",
                                         fix_type="manual",
                                         manual_steps=f"Node.js {ver} is affected by CVE-2026-21636. Upgrade to >= 18.20.6 / 20.18.3 / 22.14.0 / 23.7.0.",
                                     ),
                                 ])
            else:
                self.add_finding(check_id, title, Severity.CRITICAL, "PASS",
                                 detail=f"Node.js {ver} not affected")

        except (FileNotFoundError, subprocess.TimeoutExpired):
            self.skip(check_id, title, Severity.CRITICAL,
                      "Node.js not installed")

