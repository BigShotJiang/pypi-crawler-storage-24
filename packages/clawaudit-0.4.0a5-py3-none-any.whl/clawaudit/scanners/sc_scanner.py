"""PA-SC* — Supply chain security scanner."""

import hashlib
import json
import re
from pathlib import Path
from typing import List, Optional, Set

from clawaudit.scanners.base import BaseScanner
from clawaudit.fixers.actions import FixAction
from clawaudit.models.finding import Finding
from clawaudit.models.severity import Severity, Category


class ScScanner(BaseScanner):
    category = Category.SC
    mode = "local"

    def run(self, checks: Optional[List[str]] = None) -> List[Finding]:
        self.findings = []
        all_checks = {
            "PA-SC01": self._sc01_skill_source,
            "PA-SC02": self._sc02_file_integrity,
            "PA-SC03": self._sc03_tool_description_poison,
        }
        if not self.discovery.config_files and not self.discovery.install_dir:
            for check_id in all_checks:
                if checks and check_id not in checks:
                    continue
                self.skip(check_id, check_id, Severity.HIGH,
                          "No OpenClaw installation found")
            return self.findings
        for check_id, fn in all_checks.items():
            if checks and check_id not in checks:
                continue
            fn()
        return self.findings

    def _skills_dirs(self) -> List[Path]:
        """Return all existing skill directories."""
        dirs = []
        if not self.discovery.install_dir:
            return dirs
        for sub in ("workspace/skills", "skills"):
            d = self.discovery.install_dir / sub
            if d.is_dir():
                dirs.append(d)
        return dirs

    def _load_clawhub_skills(self) -> Set[str]:
        """Load skill names from .clawhub/lock.json files."""
        clawhub_skills: Set[str] = set()
        if not self.discovery.install_dir:
            return clawhub_skills
        # lock.json can be in install_dir/.clawhub/ or workspace/.clawhub/
        lock_candidates = [
            Path.home() / ".clawhub" / "lock.json",
            self.discovery.install_dir / ".clawhub" / "lock.json",
            self.discovery.install_dir / "workspace" / ".clawhub" / "lock.json",
        ]
        for lock_file in lock_candidates:
            if lock_file.is_file():
                try:
                    lock_data = json.loads(lock_file.read_text(errors="ignore"))
                    if isinstance(lock_data, dict):
                        clawhub_skills.update(lock_data.keys())
                except Exception:
                    pass
        return clawhub_skills

    # ------------------------------------------------------------------
    # PA-SC01: Skill source not verified
    # ------------------------------------------------------------------
    def _sc01_skill_source(self):
        check_id = "PA-SC01"
        title = "Third-party skill from unverified source"

        skills_dirs = self._skills_dirs()
        if not skills_dirs:
            self.add_finding(check_id, title, Severity.HIGH, "PASS",
                             detail="No skills directory found")
            return

        clawhub_skills = self._load_clawhub_skills()

        unverified = []
        seen = set()
        for skills_dir in skills_dirs:
            for skill in skills_dir.iterdir():
                if not skill.is_dir() or skill.name in seen:
                    continue
                seen.add(skill.name)
                has_git = (skill / ".git").exists()
                in_clawhub = skill.name in clawhub_skills
                if not has_git and not in_clawhub:
                    unverified.append((skill.name, str(skill)))

        if unverified:
            names = ", ".join(u[0] for u in unverified)
            fix_steps = (
                f"Unverified skill(s): {names}\n"
                "Step 1: Review each skill to determine if it is trustworthy.\n"
                "Step 2: Remove untrusted skills:\n"
                + "".join(f"  rm -rf {u[1]}\n" for u in unverified)
                + "Step 3: Reinstall needed skills from ClawHub or verified Git repos:\n"
                "  clawhub install <skill-name>"
            )
            self.add_finding(check_id, title, Severity.HIGH, "FAIL",
                             detail=f"Skills without verified source: {names}",
                             remediation="Only install skills from ClawHub or verified Git repositories",
                             fix_actions=[
                                 FixAction(
                                     description="Remove unverified skills",
                                     fix_type="manual",
                                     manual_steps=fix_steps,
                                 ),
                             ])
        else:
            self.add_finding(check_id, title, Severity.HIGH, "PASS")

    # ------------------------------------------------------------------
    # PA-SC02: Skill file integrity
    # ------------------------------------------------------------------
    _BASELINE_DIR = Path.home() / ".clawaudit" / "baselines"

    def _sc02_file_integrity(self):
        check_id = "PA-SC02"
        title = "Skill file integrity deviation"

        baseline_file = self._BASELINE_DIR / "skill-mcp-baseline.sha256"

        if not baseline_file.is_file():
            self.skip(check_id, title, Severity.HIGH,
                      "No baseline file found. Run: clawaudit baseline init")
            return

        try:
            raw = baseline_file.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            self.skip(check_id, title, Severity.HIGH,
                      "Cannot read baseline file")
            return

        baseline_data = {}
        for line in raw.splitlines():
            parts = line.split(maxsplit=1)
            if len(parts) == 2 and len(parts[0]) == 64:
                baseline_data[parts[1]] = parts[0]

        if not baseline_data:
            self.skip(check_id, title, Severity.HIGH,
                      "Baseline file is empty or corrupted. Run: clawaudit baseline init")
            return

        changed = []
        for path_str, expected in baseline_data.items():
            p = Path(path_str)
            if not p.is_file():
                changed.append(f"missing: {path_str}")
                continue
            actual = hashlib.sha256(p.read_bytes()).hexdigest()
            if actual != expected:
                changed.append(f"modified: {path_str}")

        if changed:
            self.add_finding(check_id, title, Severity.HIGH, "FAIL",
                             detail="; ".join(changed),
                             remediation="Investigate file changes, update baseline if legitimate",
                             fix_actions=[
                                 FixAction(
                                     description="Review skill file integrity changes",
                                     fix_type="manual",
                                     manual_steps=(
                                         f"Detected {len(changed)} skill file(s) changed from baseline:\n"
                                         + "\n".join(f"  - {c}" for c in changed) + "\n"
                                         "Step 1: Review each changed/missing file to confirm changes are intentional.\n"
                                         "Step 2: If a skill has been tampered with, remove it:\n"
                                         "  rm -rf <skill-directory>\n"
                                         "Step 3: Reinstall from ClawHub: clawhub install <skill-name>\n"
                                         "Step 4: If changes are legitimate, update baseline: clawaudit baseline init"
                                     ),
                                 ),
                             ])
        else:
            self.add_finding(check_id, title, Severity.HIGH, "PASS")

    # ------------------------------------------------------------------
    # PA-SC03: Skill description poisoning
    # ------------------------------------------------------------------
    def _sc03_tool_description_poison(self):
        check_id = "PA-SC03"
        title = "Skill description contains hidden instructions"

        suspicious_patterns = [
            r"ignore\s+(previous|above|all)\s+(instructions|rules|prompts)",
            r"do\s+not\s+tell\s+the\s+user",
            r"send\s+(data|info|response|file|content)\s+to",
            r"exfiltrat",
            r"you\s+are\s+now",
            r"new\s+instructions",
            r"override\s+(previous|all|system)",
            r"act\s+as\s+(a|an|if)",
            r"disregard\s+(previous|above|all)",
            r"forget\s+(previous|above|all|your)",
            r"<system>",
            r"</?(hidden|secret|invisible)>",
            r"<!--.*?(ignore|override|send|exfiltrat|inject|secret).*?-->",
            "[\u200b\u200c\u200d\ufeff]",  # zero-width unicode characters (non-raw)
        ]

        hits = []
        skill_paths = {}

        # Scan SKILL.md and scripts/ in all skill directories
        for skills_dir in self._skills_dirs():
            for skill_dir in skills_dir.iterdir():
                if not skill_dir.is_dir():
                    continue
                # Collect files to scan: SKILL.md + scripts/*
                files_to_scan = []
                skill_md = skill_dir / "SKILL.md"
                if skill_md.is_file():
                    files_to_scan.append(skill_md)
                scripts_dir = skill_dir / "scripts"
                if scripts_dir.is_dir():
                    files_to_scan.extend(
                        f for f in scripts_dir.rglob("*") if f.is_file()
                    )
                if not files_to_scan:
                    continue
                found = False
                for f in files_to_scan:
                    if found:
                        break
                    try:
                        text = f.read_text(encoding="utf-8", errors="ignore")
                    except OSError:
                        continue
                    for pat in suspicious_patterns:
                        if re.search(pat, text, re.IGNORECASE):
                            if skill_dir.name not in skill_paths:
                                hits.append(skill_dir.name)
                                skill_paths[skill_dir.name] = str(skill_dir)
                            found = True
                            break

        if hits:
            self.add_finding(check_id, title, Severity.HIGH, "FAIL",
                             detail=f"Suspicious instructions in skill(s): {', '.join(hits)}",
                             remediation="Remove skills with hidden prompt injection instructions",
                             fix_actions=[
                                 FixAction(
                                     description="Remove skills with hidden instructions",
                                     fix_type="manual",
                                     manual_steps=(
                                         f"Suspicious prompt injection patterns found in skill(s): {', '.join(hits)}\n"
                                         "Step 1: Review each skill's SKILL.md for hidden instructions:\n"
                                         + "".join(f"  cat {skill_paths[h]}/SKILL.md\n" for h in hits)
                                         + "Step 2: Remove malicious skills:\n"
                                         + "".join(f"  rm -rf {skill_paths[h]}\n" for h in hits)
                                         + "Step 3: Report malicious skills to ClawHub."
                                     ),
                                 ),
                             ])
        else:
            self.add_finding(check_id, title, Severity.HIGH, "PASS")

