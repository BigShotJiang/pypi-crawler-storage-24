"""PA-AUTH* — Authentication & authorization scanner."""

import re
import secrets
from typing import List, Optional

from clawaudit.scanners.base import BaseScanner
from clawaudit.fixers.actions import FixAction
from clawaudit.models.finding import Finding
from clawaudit.models.severity import Severity, Category


class AuthScanner(BaseScanner):
    category = Category.AUTH
    mode = "local"

    def run(self, checks: Optional[List[str]] = None) -> List[Finding]:
        self.findings = []
        all_checks = {
            "PA-AUTH01": self._auth01_default_creds,
            "PA-AUTH02": self._auth02_ui_bypass,
        }
        if not self.discovery.config_files:
            for check_id in all_checks:
                if checks and check_id not in checks:
                    continue
                self.skip(check_id, check_id, Severity.HIGH,
                          "No OpenClaw config files found")
            return self.findings
        for check_id, fn in all_checks.items():
            if checks and check_id not in checks:
                continue
            fn()
        return self.findings

    # ------------------------------------------------------------------
    # PA-AUTH01: Default/weak credentials
    # ------------------------------------------------------------------
    # Known credential paths in openclaw.json (from OpenClaw docs)
    _CRED_PATHS = [
        # (json_path_keys, display_name)
        # Gateway
        (("gateway", "auth", "token"), "gateway.auth.token"),
        (("gateway", "auth", "password"), "gateway.auth.password"),
        (("gateway", "remote", "token"), "gateway.remote.token"),
        (("gateway", "remote", "password"), "gateway.remote.password"),
        # Channels
        (("channels", "telegram", "botToken"), "channels.telegram.botToken"),
        (("channels", "telegram", "webhookSecret"), "channels.telegram.webhookSecret"),
        (("channels", "discord", "token"), "channels.discord.token"),
        (("channels", "slack", "botToken"), "channels.slack.botToken"),
        (("channels", "slack", "appToken"), "channels.slack.appToken"),
        (("channels", "slack", "signingSecret"), "channels.slack.signingSecret"),
        (("channels", "mattermost", "botToken"), "channels.mattermost.botToken"),
        (("channels", "msteams", "appPassword"), "channels.msteams.appPassword"),
        (("channels", "bluebubbles", "password"), "channels.bluebubbles.password"),
        (("channels", "irc", "nickserv", "password"), "channels.irc.nickserv.password"),
        # Hooks
        (("hooks", "token"), "hooks.token"),
        # Tools
        (("tools", "web", "search", "apiKey"), "tools.web.search.apiKey"),
        # TTS / Talk
        (("messages", "tts", "elevenlabs", "apiKey"), "messages.tts.elevenlabs.apiKey"),
        (("messages", "tts", "openai", "apiKey"), "messages.tts.openai.apiKey"),
        (("talk", "apiKey"), "talk.apiKey"),
    ]

    # Also check per-account tokens under channels.*.accounts.*
    _CHANNEL_ACCOUNT_FIELDS = {
        "telegram": "botToken",
        "slack": "botToken",
        "mattermost": "botToken",
    }

    _WEAK_VALUES = {
        "changeme", "password", "admin", "default", "test", "12345", "123456",
        "undefined", "root", "qwerty", "letmein", "welcome", "monkey", "master",
    }

    def _auth01_default_creds(self):
        check_id = "PA-AUTH01"
        title = "Default/weak credentials"
        found = False

        for f in self.discovery.config_files:
            if f.suffix != ".json":
                continue
            try:
                config = self.discovery.read_config(f)
            except Exception:
                continue
            if not isinstance(config, dict):
                continue

            # Check known credential paths
            for keys, display in self._CRED_PATHS:
                value = self._get_nested(config, keys)
                if value is None or not isinstance(value, str):
                    continue
                finding = self._check_cred_value(check_id, title, f, display, value, keys)
                if finding:
                    found = True

            # Check per-account tokens (channels.*.accounts.*.botToken etc.)
            channels = config.get("channels", {})
            if isinstance(channels, dict):
                for ch_name, field_name in self._CHANNEL_ACCOUNT_FIELDS.items():
                    ch = channels.get(ch_name, {})
                    if not isinstance(ch, dict):
                        continue
                    accounts = ch.get("accounts", {})
                    if not isinstance(accounts, dict):
                        continue
                    for acct_id, acct in accounts.items():
                        if not isinstance(acct, dict):
                            continue
                        value = acct.get(field_name)
                        if value and isinstance(value, str):
                            display = f"channels.{ch_name}.accounts.{acct_id}.{field_name}"
                            keys = ("channels", ch_name, "accounts", acct_id, field_name)
                            finding = self._check_cred_value(check_id, title, f, display, value, keys)
                            if finding:
                                found = True

            # Check model provider API keys (models.providers.*.apiKey)
            providers = config.get("models", {}).get("providers", {})
            if isinstance(providers, dict):
                for prov_id, prov in providers.items():
                    if not isinstance(prov, dict):
                        continue
                    value = prov.get("apiKey")
                    if value and isinstance(value, str):
                        display = f"models.providers.{prov_id}.apiKey"
                        keys = ("models", "providers", prov_id, "apiKey")
                        finding = self._check_cred_value(check_id, title, f, display, value, keys)
                        if finding:
                            found = True

        # Check per-agent auth-profiles.json files
        for ap in self.discovery.agent_auth_profiles:
            try:
                data = self.discovery.read_config(ap)
            except Exception:
                continue
            if not isinstance(data, dict):
                continue
            profiles = data.get("profiles", {})
            if not isinstance(profiles, dict):
                continue
            agent_id = ap.parent.parent.name  # agents/<agentId>/agent/auth-profiles.json
            for prof_name, prof in profiles.items():
                if not isinstance(prof, dict):
                    continue
                providers = prof.get("providers", {})
                if not isinstance(providers, dict):
                    continue
                for prov_name, prov in providers.items():
                    if not isinstance(prov, dict):
                        continue
                    api_key = prov.get("apiKey")
                    if api_key and isinstance(api_key, str):
                        display = f"agents/{agent_id} profiles.{prof_name}.providers.{prov_name}.apiKey"
                        finding = self._check_agent_cred(
                            check_id, title, ap, display, api_key,
                            prov_name, has_ref=bool(prov.get("keyRef")),
                        )
                        if finding:
                            found = True
                    token = prov.get("token")
                    if token and isinstance(token, str):
                        display = f"agents/{agent_id} profiles.{prof_name}.providers.{prov_name}.token"
                        finding = self._check_agent_cred(
                            check_id, title, ap, display, token,
                            prov_name, has_ref=bool(prov.get("tokenRef")),
                        )
                        if finding:
                            found = True

        if not found:
            self.add_finding(check_id, title, Severity.CRITICAL, "PASS")

    def _check_agent_cred(self, check_id, title, filepath, display, value,
                          provider_name, has_ref=False):
        """Check an agent auth-profiles.json credential. Returns True if FAIL.

        Unlike gateway credentials, these are third-party provider keys
        that cannot be auto-replaced — only manual remediation is offered.
        """
        # Skip env var references
        if value.startswith("${") or value.startswith("$"):
            return False

        is_weak = value.lower() in self._WEAK_VALUES
        is_short = len(value) <= 7

        if not is_weak and not is_short and not has_ref:
            # Plaintext but not weak/short — suggest SecretRef migration
            self.add_finding(check_id, title, Severity.MEDIUM, "FAIL",
                             detail=f"Plaintext credential ({display}) in {filepath.name}",
                             remediation=f"Replace plaintext apiKey with a SecretRef to avoid storing secrets in config files",
                             fix_actions=[
                                 FixAction(
                                     description=f"Migrate {display} to SecretRef",
                                     fix_type="manual",
                                     manual_steps=(
                                         f"Replace the plaintext key in {filepath} with a SecretRef:\n"
                                         f'  "keyRef": {{"source": "env", "id": "{provider_name.upper()}_API_KEY"}}\n'
                                         f"Then set the environment variable {provider_name.upper()}_API_KEY "
                                         f"to the actual key value."
                                     ),
                                 ),
                             ])
            return True

        if has_ref:
            # SecretRef exists alongside plaintext — REF_SHADOWED scenario
            # The ref takes precedence so this is informational, not critical
            return False

        if not is_weak and not is_short:
            return False

        if is_weak:
            detail = f"Weak credential ({display}={value}) in {filepath.name}"
        else:
            detail = f"{display} too short ({len(value)} chars) in {filepath.name}"

        self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                         detail=detail,
                         remediation=f"Generate a new API key from {provider_name}'s dashboard and update {filepath.name}",
                         fix_actions=[
                             FixAction(
                                 description=f"Replace weak {display}",
                                 fix_type="manual",
                                 manual_steps=(
                                     f"1. Go to {provider_name}'s API dashboard and generate a new key\n"
                                     f"2. Update {filepath} with the new key, or better yet, use a SecretRef:\n"
                                     f'   "keyRef": {{"source": "env", "id": "{provider_name.upper()}_API_KEY"}}\n'
                                     f"3. Revoke the old key from {provider_name}'s dashboard"
                                 ),
                             ),
                         ])
        return True

    def _get_nested(self, d: dict, keys: tuple):
        """Get a nested dict value by key path."""
        for k in keys:
            if not isinstance(d, dict):
                return None
            d = d.get(k)
        return d

    def _check_cred_value(self, check_id, title, f, display, value, keys):
        """Check if a credential value is weak or too short. Returns True if FAIL."""
        import json as _json

        # Skip env var references
        if value.startswith("${") or value.startswith("$"):
            return False

        is_weak = value.lower() in self._WEAK_VALUES
        is_short = len(value) <= 7

        if not is_weak and not is_short:
            return False

        new_token = secrets.token_urlsafe(32)
        if is_weak:
            detail = f"Weak credential ({display}={value}) in {f.name}"
            remediation = "Set a strong, unique token (>= 16 chars)"
        else:
            detail = f"{display} too short ({len(value)} chars) in {f.name}"
            remediation = "Use a credential with at least 16 characters"

        # Build fix: read JSON, set new value at known path, write back
        fix_actions = [
            FixAction(
                description=f"Replace {display} in {f.name}",
                fix_type="json_path_edit",
                target_file=str(f),
                old_value=_json.dumps(list(keys)),  # store path as JSON array
                new_value=new_token,
            ),
            FixAction(
                description=f"Sync {display} to other services",
                fix_type="manual",
                manual_steps=f"{display} in {f.name} was auto-replaced. Check the new value in {f.name} and update any clients that use this credential.",
            ),
        ]

        self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                         detail=detail, remediation=remediation,
                         fix_actions=fix_actions)
        return True

    # ------------------------------------------------------------------
    # PA-AUTH02: Control UI auth bypass
    # ------------------------------------------------------------------
    _BYPASS_FLAGS = [
        ("dangerouslyDisableDeviceAuth", "Disables device-level authentication for the control UI"),
        ("allowInsecureAuth", "Allows insecure (non-TLS) authentication"),
    ]

    def _auth02_ui_bypass(self):
        check_id = "PA-AUTH02"
        title = "Control UI auth bypass enabled"
        found = False

        for flag, desc in self._BYPASS_FLAGS:
            pattern = re.compile(
                rf'(["\']?{flag}["\']?\s*[:=]\s*)(true|yes|1)',
                re.IGNORECASE,
            )
            for f in self.discovery.config_files:
                try:
                    text = f.read_text(encoding="utf-8", errors="ignore")
                except OSError:
                    continue
                m = pattern.search(text)
                if m:
                    self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                                     detail=f"{flag} is enabled in {f.name} — {desc}",
                                     remediation=f"Set {flag} to false",
                                     fix_actions=[
                                         FixAction(
                                             description=f"Set {flag} to false in {f.name}",
                                             fix_type="file_edit",
                                             target_file=str(f),
                                             old_value=m.group(0),
                                             new_value=m.group(1) + "false",
                                         ),
                                     ])
                    found = True

        if not found:
            self.add_finding(check_id, title, Severity.CRITICAL, "PASS")

