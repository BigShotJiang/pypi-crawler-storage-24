"""PA-EXEC* — Execution & sandbox scanner."""

import os
import re
import subprocess
from pathlib import Path
from typing import List, Optional

from clawaudit.scanners.base import BaseScanner
from clawaudit.fixers.actions import FixAction
from clawaudit.models.finding import Finding
from clawaudit.models.severity import Severity, Category


class ExecScanner(BaseScanner):
    category = Category.EXEC
    mode = "local"

    def run(self, checks: Optional[List[str]] = None) -> List[Finding]:
        self.findings = []
        all_checks = {
            "PA-EXEC01": self._exec01_command_injection,
            "PA-EXEC02": self._exec02_sandbox,
            "PA-EXEC03": self._exec03_unsafe_exec,
            "PA-EXEC04": self._exec04_sql_injection,
            "PA-EXEC05": self._exec05_tool_output,
            "PA-EXEC06": self._exec06_prompt_injection,
            "PA-EXEC07": self._exec07_circuit_breaker,
            "PA-EXEC08": self._exec08_self_modify,
        }
        if not self.discovery.install_dir:
            for check_id in all_checks:
                if checks and check_id not in checks:
                    continue
                self.skip(check_id, check_id, Severity.HIGH,
                          "No OpenClaw installation found")
            return self.findings
        for check_id, fn in all_checks.items():
            if checks and check_id not in checks:
                continue
            fn()
        return self.findings

    def _get_source_files(self) -> List[Path]:
        """Get Python/JS/TS source files from skill directories."""
        source_files = []
        if not self.discovery.install_dir:
            return source_files

        scan_dirs = [
            self.discovery.install_dir / "workspace" / "skills",  # per-agent skills
            self.discovery.install_dir / "skills",                 # shared skills
            self.discovery.install_dir / "workspace",              # workspace scripts
        ]

        seen = set()
        for d in scan_dirs:
            if not d.is_dir():
                continue
            for ext in ("*.py", "*.js", "*.ts"):
                for f in d.rglob(ext):
                    resolved = f.resolve()
                    if resolved not in seen:
                        seen.add(resolved)
                        source_files.append(f)

        # Limit to avoid scanning massive codebases
        return source_files[:500]

    # ------------------------------------------------------------------
    # PA-EXEC01: Command injection
    # ------------------------------------------------------------------
    def _exec01_command_injection(self):
        check_id = "PA-EXEC01"
        title = "Command injection via unsanitized input"
        patterns = [
            # Python: subprocess with f-string or string concat
            r"subprocess\.(call|run|Popen)\s*\(\s*f['\"]",
            r"subprocess\.(call|run|Popen)\s*\(['\"].*['\"]?\s*\+",
            r"os\.system\s*\(\s*f['\"]",
            r"os\.system\s*\(\s*['\"].*\+",
            r"os\.popen\s*\(\s*f['\"]",
            r"os\.popen\s*\(\s*['\"].*\+",
            # Python: shell=True with variable input
            r"subprocess\.(call|run|Popen)\s*\(.*\bshell\s*=\s*True.*f['\"]",
            r"subprocess\.(call|run|Popen)\s*\(.*\bshell\s*=\s*True.*\+",
            # Python: exec with user input
            r"\bexec\s*\(\s*(user|input|request|data)",
            # JS/TS: child_process with template literal or concat
            r"child_process\.exec\s*\(\s*`",
            r"child_process\.exec\s*\(['\"].*\+",
            r"child_process\.execSync\s*\(\s*`",
            r"child_process\.execSync\s*\(['\"].*\+",
            r"execSync\s*\(\s*`.*\$\{",
            r"\bexec\s*\(\s*`.*\$\{",
        ]
        hits = self._scan_source_patterns(patterns)
        if hits:
            self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                             detail=f"Potential injection in: {self._hit_names(hits)}",
                             remediation="Remove the affected skill or use parameterized commands",
                             fix_actions=[self._build_skill_fix_action(hits, "Command injection risk")])
        else:
            self.add_finding(check_id, title, Severity.CRITICAL, "PASS")

    # ------------------------------------------------------------------
    # PA-EXEC02: Sandbox not enabled
    # ------------------------------------------------------------------
    def _exec02_sandbox(self):
        check_id = "PA-EXEC02"
        title = "Sandbox/container isolation not detected"

        # Check 1: OpenClaw sandbox config (agents.defaults.sandbox.mode)
        sandbox_mode = self._get_sandbox_mode()
        if sandbox_mode and sandbox_mode != "off":
            self.add_finding(check_id, title, Severity.WARNING, "PASS",
                             detail=f"OpenClaw sandbox mode: {sandbox_mode}")
            return

        # Check 2: System-level container/VM isolation
        isolation = self._detect_system_isolation()
        if isolation:
            self.add_finding(check_id, title, Severity.WARNING, "PASS",
                             detail=f"Running in isolated environment: {isolation}")
            return

        detail = "No sandbox or container isolation detected"
        if sandbox_mode == "off":
            detail += " (sandbox.mode is explicitly set to 'off')"

        self.add_finding(check_id, title, Severity.WARNING, "FAIL",
                         detail=detail,
                         remediation="Enable OpenClaw sandbox or run in Docker/VM",
                         fix_actions=[
                             FixAction(
                                 description="Enable sandbox isolation",
                                 fix_type="manual",
                                 manual_steps=(
                                     'Enable sandbox in openclaw.json:\n'
                                     '  "agents": {"defaults": {"sandbox": {"mode": "non-main", "backend": "docker"}}}\n'
                                     'Use mode "all" to sandbox all sessions including the main one.'
                                 ),
                             ),
                         ])

    def _get_sandbox_mode(self):
        """Check OpenClaw config for sandbox mode setting."""
        for f in self.discovery.config_files:
            try:
                config = self.discovery.read_config(f)
            except Exception:
                continue
            mode = (config.get("agents", {})
                    .get("defaults", {})
                    .get("sandbox", {})
                    .get("mode"))
            if mode is not None:
                return mode
        return None

    def _detect_system_isolation(self):
        """Detect system-level container or VM isolation. Returns description or None."""
        import platform

        # macOS: check if running inside Docker Desktop VM or sandbox
        if platform.system() == "Darwin":
            # On macOS, if /.dockerenv exists we're in Docker Desktop Linux VM
            if Path("/.dockerenv").exists():
                return "Docker (macOS)"
            # Check macOS sandbox (sandbox-exec)
            try:
                result = subprocess.run(
                    ["sandbox-exec", "-n", "no-network", "true"],
                    capture_output=True, timeout=3,
                )
                # If sandbox-exec works, system supports sandboxing
                # but we can't tell if OpenClaw itself is sandboxed
            except (FileNotFoundError, subprocess.TimeoutExpired):
                pass
            return None

        # Linux: check Docker/LXC/Podman/containerd/K8s
        if Path("/.dockerenv").exists():
            return "Docker"

        cgroup = Path("/proc/1/cgroup")
        if cgroup.is_file():
            try:
                text = cgroup.read_text().lower()
                for runtime in ("docker", "kubepods", "lxc", "containerd", "podman"):
                    if runtime in text:
                        return runtime.capitalize()
            except OSError:
                pass

        # Check VM via systemd-detect-virt
        try:
            result = subprocess.run(
                ["systemd-detect-virt"],
                capture_output=True, text=True, timeout=3,
            )
            if result.returncode == 0 and result.stdout.strip() != "none":
                return f"VM ({result.stdout.strip()})"
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

        return None

    # ------------------------------------------------------------------
    # PA-EXEC03: Unsafe code execution (eval/exec/os.system)
    # ------------------------------------------------------------------
    def _exec03_unsafe_exec(self):
        check_id = "PA-EXEC03"
        title = "Unsafe code execution (eval/exec/os.system)"
        patterns = [
            # Python
            r"\beval\s*\(",
            r"\bexec\s*\(",
            r"\bos\.system\s*\(",
            r"\bcompile\s*\(.*exec",
            # JS/TS
            r"\bnew\s+Function\s*\(",
            r"\bvm\.runInNewContext\s*\(",
            r"\bvm\.runInThisContext\s*\(",
            r"\bvm\.compileFunction\s*\(",
        ]
        hits = self._scan_source_patterns(patterns)
        if hits:
            self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                             detail=f"Found in: {self._hit_names(hits)}",
                             remediation="Remove the affected skill or replace with safe alternatives",
                             fix_actions=[self._build_skill_fix_action(hits, "Unsafe code execution (eval/exec)")])
        else:
            self.add_finding(check_id, title, Severity.CRITICAL, "PASS")

    # ------------------------------------------------------------------
    # PA-EXEC04: SQL injection
    # ------------------------------------------------------------------
    def _exec04_sql_injection(self):
        check_id = "PA-EXEC04"
        title = "SQL injection via string interpolation"
        patterns = [
            # Python: f-string SQL
            r'f["\'].*SELECT.*\{',
            r'f["\'].*INSERT.*\{',
            r'f["\'].*UPDATE.*\{',
            r'f["\'].*DELETE.*\{',
            r'["\'].*SELECT.*["\']\s*\+',
            r'\.execute\s*\(\s*f["\']',
            # JS/TS: template literal SQL
            r'`\s*SELECT.*\$\{',
            r'`\s*INSERT.*\$\{',
            r'`\s*UPDATE.*\$\{',
            r'`\s*DELETE.*\$\{',
            # JS/TS: string concat SQL
            r'["\'].*SELECT.*["\']\s*\+',
            r'\.query\s*\(\s*`.*\$\{',
            r'\.run\s*\(\s*`.*SELECT.*\$\{',
        ]
        hits = self._scan_source_patterns(patterns)
        if hits:
            self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                             detail=f"Found in: {self._hit_names(hits)}",
                             remediation="Remove the affected skill",
                             fix_actions=[self._build_skill_fix_action(hits, "SQL injection risk")])
        else:
            self.add_finding(check_id, title, Severity.CRITICAL, "PASS")

    # ------------------------------------------------------------------
    # PA-EXEC05: Tool output injected into prompt
    # ------------------------------------------------------------------
    def _exec05_tool_output(self):
        check_id = "PA-EXEC05"
        title = "Tool output directly injected into prompt"
        patterns = [
            r"(system|user|assistant)\s*[:=].*tool.*output",
            r"prompt.*\+.*result",
            r"messages\.append.*tool.*response",
        ]
        hits = self._scan_source_patterns(patterns)
        if hits:
            self.add_finding(check_id, title, Severity.HIGH, "FAIL",
                             detail=f"Found in: {self._hit_names(hits)}",
                             remediation="Remove the affected skill",
                             fix_actions=[self._build_skill_fix_action(hits, "Tool output injection risk")])
        else:
            self.add_finding(check_id, title, Severity.HIGH, "PASS")

    # ------------------------------------------------------------------
    # PA-EXEC06: System prompt injection
    # ------------------------------------------------------------------
    def _exec06_prompt_injection(self):
        check_id = "PA-EXEC06"
        title = "System prompt injection: user input in SystemMessage"
        patterns = [
            # Python: LangChain SystemMessage
            r"SystemMessage\s*\(.*\+.*user",
            r"SystemMessage\s*\(.*f['\"].*\{",
            r"SystemMessage\s*\(.*\.format\s*\(",
            # Python: system_prompt variable
            r"system_prompt.*=.*f['\"].*\{",
            r"system_prompt.*=.*\.format\s*\(",
            r"system_prompt.*=.*\+.*user",
            r"system_prompt.*%\s*\(",
            # Python: OpenAI/Anthropic SDK dict style
            r"['\"]role['\"]:\s*['\"]system['\"].*['\"]content['\"]:\s*f['\"]",
            r"['\"]role['\"]:\s*['\"]system['\"].*['\"]content['\"].*\+",
            r"\bsystem\s*=\s*f['\"].*\{",
            # JS/TS: role: "system" with template literal
            r"role:\s*['\"]system['\"].*content:\s*`.*\$\{",
            r"role:\s*['\"]system['\"].*content:.*\+",
            # JS/TS: systemPrompt/system_prompt variable
            r"systemPrompt\s*=\s*`.*\$\{",
            r"systemPrompt\s*=.*\+",
            r"system_prompt\s*=\s*`.*\$\{",
        ]
        hits = self._scan_source_patterns(patterns)
        if hits:
            self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                             detail=f"Found in: {self._hit_names(hits)}",
                             remediation="Remove the affected skill",
                             fix_actions=[self._build_skill_fix_action(hits, "System prompt injection risk")])
        else:
            self.add_finding(check_id, title, Severity.CRITICAL, "PASS")

    # ------------------------------------------------------------------
    # PA-EXEC07: No circuit breaker / max iterations
    # ------------------------------------------------------------------
    def _exec07_circuit_breaker(self):
        check_id = "PA-EXEC07"
        title = "Missing circuit breaker / max iteration limit"
        loop_patterns = [
            # Python
            r"while\s+(True|1)\s*:",
            r"for\s+\w+\s+in\s+range\s*\(\s*\d{4,}",
            # JS/TS
            r"while\s*\(\s*(true|1)\s*\)",
            r"for\s*\(\s*;\s*;\s*\)",
        ]
        guard_patterns = [
            r"(max_iter|max_steps|max_turns|circuit.?breaker|timeout)",
            r"if\s+.*:\s*break",       # Python: if condition: break
            r"if\s*\(.*\)\s*break",    # JS/TS: if (condition) break
        ]

        # Check per-file: loop without guard in the same file is a risk
        unguarded = []
        guard_re = [re.compile(p, re.IGNORECASE | re.MULTILINE) for p in guard_patterns]
        loop_re = [re.compile(p, re.IGNORECASE | re.MULTILINE) for p in loop_patterns]

        for src in self._get_source_files():
            try:
                text = src.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            has_loop = any(p.search(text) for p in loop_re)
            if not has_loop:
                continue
            has_guard = any(p.search(text) for p in guard_re)
            if not has_guard:
                unguarded.append(src)

        if unguarded:
            self.add_finding(check_id, title, Severity.HIGH, "FAIL",
                             detail=f"Found in: {self._hit_names(unguarded)}",
                             remediation="Remove the affected skill or add iteration limits",
                             fix_actions=[self._build_skill_fix_action(unguarded, "Missing circuit breaker")])
        else:
            self.add_finding(check_id, title, Severity.HIGH, "PASS")

    # ------------------------------------------------------------------
    # PA-EXEC08: Plugin code self-modification
    # ------------------------------------------------------------------
    def _exec08_self_modify(self):
        check_id = "PA-EXEC08"
        title = "Plugin code self-modification risk"
        patterns = [
            # Python: write to script files
            r"open\s*\(.*\.(py|js|ts)['\"].*['\"]w",
            r"\.write_text\s*\(.*\.(py|js|ts)",
            r"shutil\.(copy|move)\s*\(.*\.(py|js|ts)",
            # Python: dynamic reload / compile+exec
            r"importlib.*reload",
            r"exec\s*\(.*compile",
            # JS/TS: write to script files
            r"fs\.writeFileSync\s*\(.*\.(js|ts|mjs)",
            r"fs\.writeFile\s*\(.*\.(js|ts|mjs)",
            r"fsPromises\.writeFile\s*\(.*\.(js|ts|mjs)",
            # JS/TS: clear module cache for hot reload
            r"delete\s+require\.cache",
            r"require\s*\(\s*['\"]module['\"]\s*\)\s*\._cache",
        ]
        hits = self._scan_source_patterns(patterns)
        if hits:
            self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                             detail=f"Self-modification risk in: {self._hit_names(hits)}",
                             remediation="Remove the affected skill",
                             fix_actions=[self._build_skill_fix_action(hits, "Code self-modification risk")])
        else:
            self.add_finding(check_id, title, Severity.CRITICAL, "PASS")

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _scan_source_patterns(self, patterns: List[str]) -> List[Path]:
        """Scan source files for regex patterns, return list of Paths with hits."""
        hits = []
        for src in self._get_source_files():
            try:
                text = src.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            for pat in patterns:
                if re.search(pat, text, re.IGNORECASE | re.MULTILINE):
                    hits.append(src)
                    break
        return hits

    def _hit_names(self, hits: List[Path]) -> str:
        """Format hit paths as comma-separated file names for display."""
        return ", ".join(h.name for h in hits)

    def _build_skill_fix_action(self, hits: List[Path], issue: str) -> FixAction:
        """Build a manual FixAction that identifies affected skills and suggests removal."""
        skill_dirs = set()
        for h in hits:
            # Walk up to find the skill directory (contains SKILL.md)
            for parent in h.parents:
                if (parent / "SKILL.md").is_file():
                    skill_dirs.add(parent.name)
                    break

        if skill_dirs:
            skill_list = ", ".join(sorted(skill_dirs))
            steps = (
                f"{issue} in skill(s): {skill_list}\n"
                f"Affected files: {self._hit_names(hits)}\n"
                f"Step 1: Review the skill code to confirm the risk.\n"
                f"Step 2: Remove dangerous skill(s):\n"
                + "".join(f"  rm -rf ~/.openclaw/skills/{s}  # or ~/.openclaw/workspace/skills/{s}\n"
                          for s in sorted(skill_dirs))
                + "Step 3: If the skill is from ClawHub, report it as malicious."
            )
        else:
            steps = (
                f"{issue} in: {self._hit_names(hits)}\n"
                f"Step 1: Review the source files to confirm the risk.\n"
                f"Step 2: Remove or fix the affected files.\n"
                f"Step 3: If the code is from a third-party source, consider removing it entirely."
            )

        return FixAction(
            description=f"Remove skill(s) with {issue.lower()}",
            fix_type="manual",
            manual_steps=steps,
        )
