"""PA-DEEP-* — OpenClaw native security audit (deep) integration."""

import json
import shutil
import subprocess
from typing import Dict, List, Optional

from clawaudit.fixers.actions import FixAction
from clawaudit.models.finding import Finding
from clawaudit.models.severity import Category, Severity
from clawaudit.scanners.base import BaseScanner

# OpenClaw checkIds that overlap with existing clawaudit checks.
# These are marked SKIP to avoid double-counting in reports.
_OVERLAPS: Dict[str, str] = {
    "gateway.bind_no_auth": "PA-NET01",
    "gateway.loopback_no_auth": "PA-NET01",
    "gateway.http.no_auth": "PA-NET01",
    "fs.config.perms_writable": "PA-CONF01",
    "fs.config.perms_world_readable": "PA-CONF01",
    "fs.state_dir.perms_world_writable": "PA-CONF01",
    "config.insecure_or_dangerous_flags": "PA-CONF02",
    "sandbox.dangerous_network_mode": "PA-EXEC02",
    "sandbox.docker_config_mode_off": "PA-EXEC02",
    "logging.redact_off": "PA-DATA03",
}

_SEVERITY_MAP: Dict[str, Severity] = {
    "critical": Severity.CRITICAL,
    "high": Severity.HIGH,
    "medium": Severity.MEDIUM,
    "moderate": Severity.MEDIUM,
    "warn": Severity.WARNING,
    "warning": Severity.WARNING,
    "info": Severity.INFO,
    "low": Severity.INFO,
}

TIMEOUT = 120  # seconds


class DeepScanner(BaseScanner):
    """Wraps ``openclaw security audit --deep --json`` and converts its
    findings into clawaudit Finding objects."""

    category = Category.DEEP
    mode = "local"

    def run(self, checks: Optional[List[str]] = None) -> List[Finding]:
        self.findings = []

        # Skip if user specified checks and none are DEEP-related
        if checks and not any(c.startswith("PA-DEEP") for c in checks):
            return self.findings

        # Check if openclaw binary is available
        if not shutil.which("openclaw"):
            self.skip(
                "PA-DEEP-00",
                "OpenClaw native audit",
                Severity.INFO,
                "openclaw CLI not found in PATH; skipping deep audit",
            )
            return self.findings

        # Run openclaw security audit --deep --json
        cmd = ["openclaw", "security", "audit", "--deep", "--json"]
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=TIMEOUT,
            )
        except subprocess.TimeoutExpired:
            self.add_finding(
                "PA-DEEP-00",
                "OpenClaw native audit",
                Severity.WARNING,
                "ERROR",
                detail=f"openclaw security audit timed out after {TIMEOUT}s",
            )
            return self.findings
        except OSError as exc:
            self.add_finding(
                "PA-DEEP-00",
                "OpenClaw native audit",
                Severity.WARNING,
                "ERROR",
                detail=f"Failed to run openclaw: {exc}",
            )
            return self.findings

        # Parse JSON output
        try:
            data = json.loads(result.stdout)
        except (json.JSONDecodeError, TypeError):
            self.add_finding(
                "PA-DEEP-00",
                "OpenClaw native audit",
                Severity.WARNING,
                "ERROR",
                detail="Failed to parse openclaw JSON output",
                raw_stdout=result.stdout[:500] if result.stdout else "",
                raw_stderr=result.stderr[:500] if result.stderr else "",
            )
            return self.findings

        raw_findings = data.get("findings", [])
        if not raw_findings:
            return self.findings

        for raw in raw_findings:
            self._convert_finding(raw, checks)

        return self.findings

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _convert_finding(self, raw: dict, checks: Optional[List[str]]) -> None:
        native_id = raw.get("checkId", "unknown")
        check_id = f"PA-DEEP-{native_id}"

        # Check filter
        if checks and check_id.upper() not in [c.upper() for c in checks]:
            return

        severity = _SEVERITY_MAP.get(
            raw.get("severity", "warn").lower(),
            Severity.WARNING,
        )
        title = raw.get("title", native_id)

        # Deduplication — overlapping checks marked SKIP
        overlap = _OVERLAPS.get(native_id)
        if overlap:
            self.skip(check_id, title, severity, f"Covered by {overlap}")
            return

        status = "FAIL"
        if raw.get("status") in ("pass", "ok"):
            status = "PASS"

        remediation = raw.get("remediation", "")
        fix_info = raw.get("fix", {})
        if not remediation and isinstance(fix_info, dict):
            remediation = fix_info.get("description", "")

        fix_actions = self._build_fix_actions(native_id, fix_info, remediation)

        self.add_finding(
            check_id=check_id,
            title=title,
            severity=severity,
            status=status,
            description=raw.get("description", ""),
            detail=raw.get("detail", raw.get("message", "")),
            remediation=remediation,
            fix_actions=fix_actions,
            source="openclaw-audit",
            native_check_id=native_id,
        )

    @staticmethod
    def _build_fix_actions(
        native_id: str,
        fix_info,
        remediation: str,
    ) -> List[FixAction]:
        # If OpenClaw indicates the check is auto-fixable, delegate back
        if isinstance(fix_info, dict) and fix_info.get("auto"):
            return [
                FixAction(
                    description=f"Run OpenClaw native fix for {native_id}",
                    fix_type="command",
                    command="openclaw security audit --fix --json",
                )
            ]

        # Otherwise provide manual steps
        if remediation:
            return [
                FixAction(
                    description=f"Manual remediation for {native_id}",
                    fix_type="manual",
                    manual_steps=remediation,
                )
            ]

        return []
