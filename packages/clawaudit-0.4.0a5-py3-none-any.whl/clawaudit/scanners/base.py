"""Base scanner class."""

from abc import ABC, abstractmethod
from typing import List, Optional

from clawaudit.config.discovery import OpenClawDiscovery
from clawaudit.fixers.actions import FixAction
from clawaudit.models.finding import Finding
from clawaudit.models.severity import Severity, Category


class BaseScanner(ABC):
    """Base class for all scanners."""

    category: Category
    mode: str = "local"  # "local", "remote", "both"

    def __init__(self, discovery: OpenClawDiscovery, target: str = "", port: int = 18789):
        self.discovery = discovery
        self.target = target
        self.port = port
        self.findings: List[Finding] = []

    def add_finding(
        self,
        check_id: str,
        title: str,
        severity: Severity,
        status: str,
        description: str = "",
        detail: str = "",
        remediation: str = "",
        fix_actions: Optional[List[FixAction]] = None,
        **metadata,
    ) -> Finding:
        finding = Finding(
            check_id=check_id,
            title=title,
            severity=severity,
            category=self.category,
            status=status,
            description=description,
            detail=detail,
            remediation=remediation,
            metadata=metadata,
            fix_actions=fix_actions or [],
        )
        self.findings.append(finding)
        return finding

    def skip(self, check_id: str, title: str, severity: Severity, reason: str) -> Finding:
        return self.add_finding(
            check_id=check_id,
            title=title,
            severity=severity,
            status="SKIP",
            detail=reason,
        )

    @abstractmethod
    def run(self, checks: Optional[List[str]] = None) -> List[Finding]:
        """Run scans. If checks is given, only run those check IDs."""
        ...
