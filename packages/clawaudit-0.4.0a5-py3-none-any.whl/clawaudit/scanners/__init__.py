from clawaudit.scanners.base import BaseScanner

__all__ = ["BaseScanner"]
