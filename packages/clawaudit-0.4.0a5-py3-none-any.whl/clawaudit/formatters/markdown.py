"""Markdown formatter."""

from typing import List

from clawaudit import __version__
from clawaudit.formatters.base import BaseFormatter
from clawaudit.models.finding import Finding


class MarkdownFormatter(BaseFormatter):
    def format(self, findings: List[Finding]) -> str:
        lines: list[str] = []

        total = len(findings)
        fails = [f for f in findings if f.status == "FAIL"]
        passes = [f for f in findings if f.status == "PASS"]
        skips = [f for f in findings if f.status == "SKIP"]

        score = self._compute_score(findings)
        grade = self._grade(score)

        lines.append(f"# Foresight ClawAudit v{__version__} Security Report")
        lines.append("")
        lines.append("## Summary")
        lines.append("")
        lines.append("| Metric | Value |")
        lines.append("|--------|-------|")
        lines.append(f"| Total checks | {total} |")
        lines.append(f"| Failed | {len(fails)} |")
        lines.append(f"| Passed | {len(passes)} |")
        lines.append(f"| Skipped | {len(skips)} |")
        lines.append(f"| Score | {score}/100 ({grade}) |")
        lines.append("")

        # Group failures by severity
        severity_order = ["CRITICAL", "HIGH", "MEDIUM", "WARNING", "INFO"]
        for sev in severity_order:
            sev_findings = [f for f in fails if f.severity.value == sev]
            if not sev_findings:
                continue
            lines.append(f"## {sev}")
            lines.append("")
            for f in sev_findings:
                lines.append(f"### {f.check_id}: {f.title}")
                lines.append("")
                lines.append(f"- **Severity**: {f.severity.value}")
                if f.detail:
                    lines.append(f"- **Detail**: {f.detail}")
                if f.remediation:
                    lines.append(f"- **Remediation**: {f.remediation}")
                lines.append("")

        # Passed checks
        if passes:
            lines.append("## PASSED")
            lines.append("")
            for f in passes:
                lines.append(f"- {f.check_id}: {f.title}")
            lines.append("")

        # Skipped checks
        if skips:
            lines.append("## SKIPPED")
            lines.append("")
            for f in skips:
                lines.append(f"- {f.check_id}: {f.title} ({f.detail})")
            lines.append("")

        return "\n".join(lines)

    def _compute_score(self, findings: List[Finding]) -> int:
        score = 100
        for f in findings:
            if f.status != "FAIL":
                continue
            if f.severity.value == "CRITICAL":
                score -= 12
            elif f.severity.value == "HIGH":
                score -= 8
            elif f.severity.value in ("MEDIUM", "WARNING"):
                score -= 5
        return max(0, score)

    def _grade(self, score: int) -> str:
        if score >= 90:
            return "A"
        elif score >= 80:
            return "B"
        elif score >= 70:
            return "C"
        elif score >= 60:
            return "D"
        return "F"
