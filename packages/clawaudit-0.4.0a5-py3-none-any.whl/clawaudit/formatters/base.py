"""Base formatter."""

from abc import ABC, abstractmethod
from typing import List

from clawaudit.models.finding import Finding


class BaseFormatter(ABC):
    @abstractmethod
    def format(self, findings: List[Finding]) -> str:
        ...
