"""JSON formatter."""

import json
from typing import List

from clawaudit import __version__
from clawaudit.formatters.base import BaseFormatter
from clawaudit.models.finding import Finding


class JsonFormatter(BaseFormatter):
    def format(self, findings: List[Finding]) -> str:
        data = {
            "version": __version__,
            "total": len(findings),
            "summary": {
                "fail": sum(1 for f in findings if f.status == "FAIL"),
                "pass": sum(1 for f in findings if f.status == "PASS"),
                "skip": sum(1 for f in findings if f.status == "SKIP"),
            },
            "findings": [f.to_dict() for f in findings],
        }
        return json.dumps(data, indent=2, ensure_ascii=False)
