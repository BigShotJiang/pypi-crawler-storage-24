---
enforce: hard
matches:
  - tool: bash
    pattern: "git commit.*--no-verify"
---
# Require Tests Before Commit

Do not allow commits that skip verification hooks.

This rule ensures quality gates are enforced at the pack level.
