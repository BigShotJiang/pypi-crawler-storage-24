# Next Focus: Spec-First Build Over Missions And Workflows

Date: 2026-03-26
Status: active

## Summary

The old "finish specs, then start missions" handoff is complete. The next active focus is making specs feel like the front door to autonomous delivery, while continuing to harden workflow control semantics underneath.

## Why

- The earlier specs wrap-up work is done: [#1016](https://github.com/troylar/anteroom/issues/1016) and [#1076](https://github.com/troylar/anteroom/issues/1076) are closed, and the planning/execution story is documented.
- The core Mission V1 foundation is also in place: [#1043](https://github.com/troylar/anteroom/issues/1043) through [#1049](https://github.com/troylar/anteroom/issues/1049) are closed.
- Mission execution-profile support has landed through [#1154](https://github.com/troylar/anteroom/issues/1154) and merged PR [#1166](https://github.com/troylar/anteroom/pull/1166).
- The biggest remaining product gap is user-facing clarity: users expect `spec -> approve -> build`, but native specs still feel like planning-only artifacts. [#1165](https://github.com/troylar/anteroom/issues/1165) is the current bridge issue.
- Workflow control still needs hardening in parallel. [#1106](https://github.com/troylar/anteroom/issues/1106) is a clean, high-priority workflow issue and a good real-world spec-driving example.

## Next Actions

1. Drive [#1165](https://github.com/troylar/anteroom/issues/1165): make specs the user-facing entry point for AI-assisted creation and autonomous build, while still using missions/workflows as the runtime underneath.
2. Use [#1106](https://github.com/troylar/anteroom/issues/1106) as the canonical workflow-control issue when validating the spec-first story with a real issue and real acceptance criteria.
3. Keep the replay follow-up cluster aligned behind [#1106]:
   [#1107](https://github.com/troylar/anteroom/issues/1107), [#1108](https://github.com/troylar/anteroom/issues/1108), and [#1109](https://github.com/troylar/anteroom/issues/1109).
4. Treat [#1147](https://github.com/troylar/anteroom/issues/1147) as a later workflow-authoring / mission follow-up, not a prerequisite for spec-first build.
5. Keep enterprise-only spec governance work like [#998](https://github.com/troylar/anteroom/issues/998) out of the immediate path unless server-mode priorities move back to the front.

## References

- [Planning And Execution](../planning-and-execution.md)
- [Mission Product Spec](../advanced/mission-product-spec.md)
- [Parallel Development Lanes](../workflows/parallel-lanes.md)
- [#1106](https://github.com/troylar/anteroom/issues/1106)
- [#1154](https://github.com/troylar/anteroom/issues/1154)
- [#1165](https://github.com/troylar/anteroom/issues/1165)
- [#1166](https://github.com/troylar/anteroom/pull/1166)
- [#1147](https://github.com/troylar/anteroom/issues/1147)
