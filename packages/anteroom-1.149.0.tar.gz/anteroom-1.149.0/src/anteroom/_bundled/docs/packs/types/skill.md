# Skill

A reusable prompt template that users invoke with `/skill-name` or the AI invokes via the `invoke_skill` tool.

**Content format**: YAML with `name`, `description`, and `prompt` fields.

**How Anteroom uses it**: Skills are registered in the `SkillRegistry` and exposed as tab-completable slash commands. When invoked, the `prompt` field is expanded (with `{args}` template substitution) and sent as the user message.

**Example**:

```yaml title="skills/review.yaml"
name: review
description: Review code changes for quality and security
prompt: |
  Review the following code changes for:
  - Security vulnerabilities (OWASP Top 10)
  - Code quality and maintainability
  - Test coverage gaps

  {args}
```

**Directory**: `skills/`

**Common mistakes**:

- Forgetting the `name` field (required, must match the artifact name)
- Using `{args}` inside a fenced code block (substitution only happens outside code fences)
- Exceeding the 50KB prompt size limit
