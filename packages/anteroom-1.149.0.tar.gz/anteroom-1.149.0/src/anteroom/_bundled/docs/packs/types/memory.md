# Memory

Persistent memory across sessions. Memories store learned preferences, patterns, or facts that the agent should retain.

**Content format**: Markdown or plain text.

**How Anteroom uses it**: Memories are loaded into the agent's context, allowing it to recall information from previous interactions or pre-configured knowledge.

**Example**:

```markdown title="memories/team-preferences.md"
# Team Preferences

- Troy prefers functional components over class components
- The team uses pnpm, never npm or yarn
- All PRs require at least one approval before merging
- Deployment window: Tuesday-Thursday, 9am-3pm EST
```

**Directory**: `memories/`

**Common mistakes**:

- Storing sensitive information (passwords, tokens) in memory artifacts
- Creating memories that contradict rules or instructions
