# Pack Demo Remediation Plan

Context: CTO demo on March 12, 2026.

## Goal

Stabilize pack behavior enough for the demo, then close the end-to-end gaps in a deliberate order.

## Issues

- `#872` Make pack-source activation semantics explicit and consistent
  https://github.com/troylar/anteroom/issues/872
- `#873` Do not silently drop metadata from Markdown pack rules
  https://github.com/troylar/anteroom/issues/873
- `#874` Make project-scoped packs actually load in runtime
  https://github.com/troylar/anteroom/issues/874
- `#875` Reload and scope pack config overlays correctly
  https://github.com/troylar/anteroom/issues/875

## Recommended Execution Order

1. Fix `#873` first.
   Eliminate the hard-rule false warning by correctly handling Markdown rule metadata, or by tightening validation/docs if Markdown front matter is not a supported format.

2. Fix `#872` next.
   Decide and implement the actual `pack_sources` contract: either install-only with explicit docs, or install-and-attach with explicit scope semantics.

3. Fix `#874` after that.
   Make project-scoped attachments participate in runtime artifact loading so project packs actually work end-to-end.

4. Fix `#875` last.
   Make pack config overlays scope-aware and decide whether attach/detach/refresh live-reload config or require restart.

## Minimum Demo-Safe Set

- Minimum safe fixes: `#873` and `#872`
- Real runtime correctness: add `#874`
- Full pack/config correctness: add `#875`

If the demo does not rely on project-scoped packs or pack-driven config changes, the first two fixes are the minimum useful set.

## Demo Fallbacks

If all fixes are not done before March 12, 2026:

- Use globally attached packs only
- Manually attach packs after install or refresh
- Restart after pack changes if config overlays matter
- Use YAML rule artifacts for hard enforcement, not Markdown front matter

## Definition of Done

- A pack from a source is either clearly install-only or automatically active, with docs matching code
- Hard rules load as hard when authored in the supported format
- Project-attached packs show up in actual rule/skill/artifact runtime behavior
- Config overlays behave consistently at startup and after pack changes
- End-to-end tests cover source refresh, attach/activate, project scope, and config overlay behavior
