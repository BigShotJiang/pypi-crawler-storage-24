# Context

Dynamic context injected per-turn. Similar to instructions but intended for reference material that the agent consults as needed.

**Content format**: Markdown or plain text.

**How Anteroom uses it**: Context artifacts are available to the agent during each turn. They provide reference material like API documentation, schema definitions, or style guides.

**Example**:

```markdown title="context/api-reference.md"
# Internal API Reference

## POST /api/users
Creates a new user account.

Request body:
- `email` (string, required): User's email address
- `name` (string, required): Display name
- `role` (string, optional): One of "admin", "editor", "viewer". Default: "viewer"

Response: 201 with `{id, email, name, role, created_at}`
```

**Directory**: `context/`

**Common mistakes**:

- Loading large context artifacts that exceed token budgets
- Using context for rules (context is advisory, rules are mandatory)
