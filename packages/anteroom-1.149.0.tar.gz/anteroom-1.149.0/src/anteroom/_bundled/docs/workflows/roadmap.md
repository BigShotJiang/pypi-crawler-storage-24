# Workflow Roadmap

This roadmap shows the next major phases for the workflow engine after the MVP foundations already in the repo.

Workflows now support durable runs, approvals, human input, resume, monitoring, credentials, artifacts, conditional execution, and retry. The next work is less about proving the engine exists and more about making it operationally trustworthy, broadly useful, and easier to compose.

## Current State

You already have:

- durable workflow runs and step history
- agent, shell, and Python-script runners
- approval gates and human-in-the-loop pauses
- resume, drift detection, and budget enforcement
- workflow monitoring through CLI, REST, SSE, and hooks
- credential binding and artifact-aware agent context
- conditional execution and retry with backoff

That puts workflows in a strong "governed execution" stage. The next roadmap phases focus on operations, runtime ownership, visibility, and richer orchestration.

## Phase 1: Operational Governance

Make workflows safer and more production-usable.

- [#963](https://github.com/troylar/anteroom/issues/963) — cost and token tracking
- [#966](https://github.com/troylar/anteroom/issues/966) — publish/output steps
- [#977](https://github.com/troylar/anteroom/issues/977) — idempotency keys for side-effecting steps
- [#979](https://github.com/troylar/anteroom/issues/979) — checkpoints and run snapshots
- [#953](https://github.com/troylar/anteroom/issues/953) — audit integration and polish

Outcome:
workflows can spend, publish, resume, and audit safely without relying on operator guesswork.

!!! tip
    If you only care about the next few issues to work, start here. This phase makes workflows trustworthy enough for real unattended business use.

## Phase 2: Operational Runtime

Move from foreground orchestration to a real long-running workflow runtime.

- [#969](https://github.com/troylar/anteroom/issues/969) — scheduling and triggers
- [#888](https://github.com/troylar/anteroom/issues/888) — background workflow executor
- [#887](https://github.com/troylar/anteroom/issues/887) — durable agent-run storage for background workflows
- [#890](https://github.com/troylar/anteroom/issues/890) — safe cancel and approval semantics for async workflows
- [#952](https://github.com/troylar/anteroom/issues/952) — instance discovery and cross-repo status

Outcome:
workflows can run unattended, survive process boundaries cleanly, and be operated as a runtime instead of a foreground command.

## Phase 3: Visibility and Tooling

Improve operator confidence, testing, and day-to-day usability.

- [#961](https://github.com/troylar/anteroom/issues/961) — browser dashboard for workflow runs
- [#968](https://github.com/troylar/anteroom/issues/968) — workflow simulation and test harness
- [#660](https://github.com/troylar/anteroom/issues/660) — broader CLI workflow integration coverage

Outcome:
operators can inspect, test, and debug workflows more easily before and during production use.

## Phase 4: Expressiveness

Expand what the workflow language can model.

- [#976](https://github.com/troylar/anteroom/issues/976) — parallel branches and join semantics
- [#960](https://github.com/troylar/anteroom/issues/960) — workflow composition
- [#958](https://github.com/troylar/anteroom/issues/958) — workflow templating
- [#978](https://github.com/troylar/anteroom/issues/978) — compensation and rollback steps

Outcome:
workflows become a more capable orchestration language instead of just a linear sequence runner.

!!! info
    This phase is intentionally after the operational phases. More expressive workflows are valuable, but they matter more once runtime integrity and operator visibility are already strong.

## Phase 5: Distribution and Ecosystem

Connect workflows more deeply to packs, knowledge, and reusable organizational capabilities.

- [#954](https://github.com/troylar/anteroom/issues/954) — workflow as artifact type
- [#924](https://github.com/troylar/anteroom/issues/924) — pack-backed workflow templates and memory policies
- [#631](https://github.com/troylar/anteroom/issues/631) — pack discovery and sharing workflow
- [#629](https://github.com/troylar/anteroom/issues/629) — Office-document workflow packs
- [#359](https://github.com/troylar/anteroom/issues/359) — conversation-to-knowledge extraction workflow
- [#632](https://github.com/troylar/anteroom/issues/632) — data-analysis workflow

Outcome:
workflows become reusable product capabilities that teams can distribute, adapt, and operationalize across departments.

## Background Workflow Track

These issues fit the same feature area but are best treated as a focused sub-track rather than part of the mainline queue:

- [#886](https://github.com/troylar/anteroom/issues/886) — conversation-first background workflows epic
- [#889](https://github.com/troylar/anteroom/issues/889) — route follow-up messages to active workflow runs
- [#891](https://github.com/troylar/anteroom/issues/891) — keep-talking async workflow UX in CLI and web
- [#892](https://github.com/troylar/anteroom/issues/892) — parity tests and evals for async workflows

These are worth doing, but they should stay aligned with the main runtime work in Phase 2 rather than drifting into a separate execution model.

## Recommended Next Sequence

If you want the shortest practical queue, work in this order:

1. [#963](https://github.com/troylar/anteroom/issues/963) — cost and token tracking
2. [#966](https://github.com/troylar/anteroom/issues/966) — publish/output steps
3. [#977](https://github.com/troylar/anteroom/issues/977) — idempotency keys
4. [#979](https://github.com/troylar/anteroom/issues/979) — checkpoints and snapshots
5. [#969](https://github.com/troylar/anteroom/issues/969) — scheduling and triggers

Why this order:

- it makes workflows operationally useful before making them more syntactically powerful
- it protects side effects before expanding unattended execution
- it strengthens resume, observability, and audit confidence before adding more concurrency or composition

## Related Pages

- [Workflows Overview](index.md)
- [Workflow Concepts](concepts.md)
- [Workflow Definitions](definitions.md)
- [Workflow Commands](commands.md)
- [Workflow Monitoring](monitoring.md)
