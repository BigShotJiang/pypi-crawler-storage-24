# CLI Themes

The CLI supports 4 built-in color themes configured via `cli.theme` in `config.yaml`.

| Theme | Description |
|-------|-------------|
| `midnight` | Default dark theme |
| `dawn` | Warm light theme |
| `high-contrast` | Maximum readability |
| `accessible` | CVD-safe blue/orange (IBM palette) |

```yaml
cli:
  theme: "accessible"
```

All 22 semantic color slots flow through a `CliTheme` frozen dataclass. The `NO_COLOR` environment variable is respected.

See also: [Web UI Themes](../web-ui/themes.md) for browser-side theme switching.
