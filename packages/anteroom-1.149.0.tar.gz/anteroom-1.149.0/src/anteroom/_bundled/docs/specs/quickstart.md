# Quickstart

This quickstart walks you through creating and approving a spec in under 5 minutes.

## Before You Start

You need:

- an Anteroom install with the CLI REPL (`aroom chat`)
- a running database (the default SQLite database works)

## 1. Create a Spec

```bash
/spec create myapp api-design
```

This opens your `$EDITOR` with a YAML template:

```yaml
requirements: |
  Describe what the feature must accomplish.

design: |
  Describe the technical approach.

tasks:
  - id: task-1
    summary: First task
```

Fill in the three sections and save. Anteroom validates the YAML and creates the spec artifact with the FQN `@myapp/spec/api-design`.

All three phases start in `draft` status.

## 2. Inspect the Spec

```bash
/spec show @myapp/spec/api-design
```

Output:

```text
Spec: @myapp/spec/api-design

  requirements: draft
  design:       draft
  tasks:        draft

Requirements:
  Describe what the feature must accomplish.

Design:
  Describe the technical approach.

Tasks:
  task-1: First task
```

Use `/spec list` (or `/specs`) to see all specs with color-coded phase badges:

- green = approved
- amber = stale
- gray = draft

## 3. Approve Phases

Approve each phase individually:

```bash
/spec approve @myapp/spec/api-design requirements
/spec approve @myapp/spec/api-design design
/spec approve @myapp/spec/api-design tasks
```

Now `/spec show` displays all three phases as `approved`:

```text
Spec: @myapp/spec/api-design

  requirements: approved
  design:       approved
  tasks:        approved
```

To reset a phase back to draft:

```bash
/spec unapprove @myapp/spec/api-design design
```

## What Happened

You just:

1. Created a spec with three planning phases (requirements, design, tasks)
2. Inspected phase statuses
3. Approved each phase independently

The spec is now stored in the artifact database with version history and approval metadata.

## What's Next

- [Concepts](concepts.md) — how invalidation and staleness work when content changes, and how specs integrate with workflows
- [Commands](commands.md) — full reference for all 6 `/spec` subcommands, including `unapprove` and `diff` (diff requires at least two content versions)
- [Workflow Gates](concepts.md#workflow-gates) — gating workflow steps on spec phase approval
- [Schema Reference](schema-reference.md) — the YAML format, task dependencies, and validation rules
