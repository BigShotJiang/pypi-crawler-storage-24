"""Tests for pytest-doctor."""
