"""MCP (Model Context Protocol) client support.

Connects to external MCP servers via stdio with proper Content-Length framing.
Config lives in ~/.krim/mcp.json or .krim/mcp.json
"""

from __future__ import annotations

import json
import os
import re
import select
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path

from rich.console import Console

from krim import __version__
from krim_sdk.tools.base import Tool
from krim_sdk.truncate import truncate

MCP_READ_TIMEOUT = 60  # seconds
_TOOL_NAME_PATTERN = re.compile(r"^[A-Za-z0-9_-]{1,128}$")

console = Console()


class McpTransportMismatchError(Exception):
    """Raised when the server rejects the current stdio wire format."""


@dataclass
class McpServerConfig:
    name: str
    command: list[str]
    env: dict[str, str] | None = None
    wire_format: str = "auto"


def _normalize_command_config(command: str | list[str], args: list[str] | None = None) -> list[str]:
    if isinstance(command, str):
        parts = [command]
    else:
        parts = list(command)

    if args:
        parts.extend(args)

    if not parts:
        raise ValueError("mcp config must include a command")

    return parts


class McpTool(Tool):
    """A tool proxied from an MCP server."""

    def __init__(self, name: str, description: str, parameters: dict, server: "McpServer", rpc_name: str | None = None):
        self.name = name
        self.description = description
        self.parameters = parameters
        self._server = server
        self._rpc_name = rpc_name or name
        self._required: list[str] = []

    def schema(self) -> dict:
        """Generate schema with proper required field from MCP server."""
        return {
            "name": self.name,
            "description": self.description,
            "input_schema": {
                "type": "object",
                "properties": self.parameters,
                "required": self._required,
            },
        }

    def run(self, **kwargs) -> str:
        return self._server.call_tool(self._rpc_name, kwargs)


def _sanitize_tool_name(name: str) -> str:
    alias = re.sub(r"[^A-Za-z0-9_-]+", "_", name.strip()).strip("_")
    alias = alias.lower()
    if not alias:
        alias = "mcp_tool"
    return alias[:128]


def _resolve_tool_name_alias(name: str, used_names: set[str]) -> str:
    if _TOOL_NAME_PATTERN.fullmatch(name) and name not in used_names:
        used_names.add(name)
        return name

    base = _sanitize_tool_name(name)
    candidate = base
    suffix = 2
    while candidate in used_names or not _TOOL_NAME_PATTERN.fullmatch(candidate):
        tail = f"_{suffix}"
        candidate = f"{base[: max(1, 128 - len(tail))]}{tail}"
        suffix += 1
    used_names.add(candidate)
    return candidate


class McpServer:
    """Manages a single MCP server process via stdio with Content-Length framing."""

    def __init__(self, config: McpServerConfig):
        self.config = config
        self.process: subprocess.Popen | None = None
        self._request_id = 0
        self.tools: list[McpTool] = []
        self._wire_format = "line" if config.wire_format == "line" else "framed"

    def start(self):
        if self.config.wire_format == "line":
            self._wire_format = "line"
            self._start_process()
            self._initialize()
            self._discover_tools()
            return

        if self.config.wire_format == "framed":
            self._wire_format = "framed"
            self._start_process()
            self._initialize()
            self._discover_tools()
            return

        self._wire_format = "framed"
        self._start_process()
        try:
            self._initialize()
        except (McpTransportMismatchError, TimeoutError, ConnectionError):
            self.stop()
            self._wire_format = "line"
            self._start_process()
            self._initialize()
        self._discover_tools()

    def _start_process(self):
        env = os.environ.copy()
        if self.config.env:
            env.update(self.config.env)

        self.process = subprocess.Popen(
            self.config.command,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=env,
        )

    def stop(self):
        if self.process:
            try:
                self.process.terminate()
                self.process.wait(timeout=5)
            except Exception:
                self.process.kill()
            self.process = None

    def _send_raw(self, data: bytes):
        """Send a message with the active stdio wire format."""
        if self._wire_format == "line":
            payload = data + b"\n"
        else:
            header = f"Content-Length: {len(data)}\r\n\r\n".encode()
            payload = header + data
        self.process.stdin.write(payload)
        self.process.stdin.flush()

    def _recv_raw(self, timeout: float | None = None) -> bytes:
        """Read a message from the active stdio wire format with timeout."""
        if timeout is None:
            timeout = MCP_READ_TIMEOUT
        if self._wire_format == "line":
            return self._recv_raw_line(timeout)
        return self._recv_raw_framed(timeout)

    def _readline_with_timeout(self, timeout: float) -> bytes:
        fd = self.process.stdout.fileno()
        ready, _, _ = select.select([fd], [], [], timeout)
        if not ready:
            raise TimeoutError(f"MCP server did not respond within {timeout}s")

        line = self.process.stdout.readline()
        if not line:
            raise ConnectionError("MCP server closed connection")
        return line

    def _read_exact_with_timeout(self, size: int, timeout: float) -> bytes:
        fd = self.process.stdout.fileno()
        chunks: list[bytes] = []
        remaining = size
        deadline = time.monotonic() + timeout

        while remaining > 0:
            wait = deadline - time.monotonic()
            if wait <= 0:
                raise TimeoutError(f"MCP server did not finish response within {timeout}s")

            ready, _, _ = select.select([fd], [], [], wait)
            if not ready:
                raise TimeoutError(f"MCP server did not finish response within {timeout}s")

            chunk = self.process.stdout.read(remaining)
            if not chunk:
                raise ConnectionError("MCP server closed connection")

            chunks.append(chunk)
            remaining -= len(chunk)

        return b"".join(chunks)

    def _recv_raw_line(self, timeout: float) -> bytes:
        line = self._readline_with_timeout(timeout)
        return line.strip()

    def _recv_raw_framed(self, timeout: float) -> bytes:
        """Read a Content-Length framed message with timeout."""
        deadline = time.monotonic() + timeout
        content_length = 0
        while True:
            wait = deadline - time.monotonic()
            if wait <= 0:
                raise TimeoutError(f"MCP server did not respond within {timeout}s")

            line = self._readline_with_timeout(wait)
            line_str = line.decode("utf-8", errors="replace").strip()
            if not line_str:
                break  # empty line = end of headers
            if line_str.lower().startswith("content-length:"):
                content_length = int(line_str.split(":", 1)[1].strip())
                continue

            raise McpTransportMismatchError(
                f"server responded without Content-Length framing: {line_str[:120]}"
            )

        if content_length == 0:
            raise ConnectionError("MCP server sent no Content-Length")

        wait = deadline - time.monotonic()
        if wait <= 0:
            raise TimeoutError(f"MCP server did not finish response within {timeout}s")
        return self._read_exact_with_timeout(content_length, wait)

    def _send(self, method: str, params: dict | None = None) -> dict:
        self._request_id += 1
        msg = {
            "jsonrpc": "2.0",
            "id": self._request_id,
            "method": method,
        }
        if params is not None:
            msg["params"] = params

        self._send_raw(json.dumps(msg).encode("utf-8"))

        # read responses, skipping notifications (no "id" field)
        invalid_line_count = 0
        while True:
            raw = self._recv_raw()
            try:
                resp = json.loads(raw)
            except json.JSONDecodeError:
                if self._wire_format == "line" and invalid_line_count < 20:
                    invalid_line_count += 1
                    continue
                raise
            if "id" in resp:
                if resp.get("id") is None and isinstance(resp.get("error"), dict):
                    if resp["error"].get("code") == -32700:
                        raise McpTransportMismatchError("server rejected framed JSON-RPC message")
                return resp
            # else it's a notification, skip it

    def _initialize(self):
        resp = self._send("initialize", {
            "protocolVersion": "2024-11-05",
            "capabilities": {},
            "clientInfo": {"name": "krim", "version": __version__},
        })
        # send initialized notification
        notify = {
            "jsonrpc": "2.0",
            "method": "notifications/initialized",
        }
        self._send_raw(json.dumps(notify).encode("utf-8"))
        return resp

    def _discover_tools(self):
        resp = self._send("tools/list")
        if "result" not in resp:
            return
        used_names: set[str] = set()
        for t in resp["result"].get("tools", []):
            schema = t.get("inputSchema", {})
            props = schema.get("properties", {})
            required = schema.get("required", [])
            rpc_name = t["name"]
            tool_name = _resolve_tool_name_alias(rpc_name, used_names)
            description = t.get("description", "")
            if tool_name != rpc_name:
                suffix = f" (original MCP tool name: {rpc_name})"
                description = f"{description}{suffix}" if description else f"Original MCP tool name: {rpc_name}"
            # store full schema info so McpTool.schema() works correctly
            tool = McpTool(
                name=tool_name,
                description=description,
                parameters=props,
                server=self,
                rpc_name=rpc_name,
            )
            tool._required = required
            self.tools.append(tool)

    def call_tool(self, name: str, args: dict) -> str:
        try:
            resp = self._send("tools/call", {"name": name, "arguments": args})
        except Exception as e:
            return f"error: MCP call failed: {e}"

        if "error" in resp:
            err = resp["error"]
            msg = err.get("message", str(err)) if isinstance(err, dict) else str(err)
            return f"error: {msg}"

        result = resp.get("result", {})
        contents = result.get("content", [])
        parts = []
        for c in contents:
            if c.get("type") == "text":
                parts.append(c["text"])
            else:
                parts.append(json.dumps(c))
        out = "\n".join(parts) or "(no output)"
        return truncate(out, 30_000)


def load_mcp_config(global_dir: Path | None = None, project_dir: Path | None = None) -> list[McpServerConfig]:
    """Load MCP server configs from ~/.krim/mcp.json and .krim/mcp.json"""
    configs = []
    search_paths = []
    if global_dir:
        search_paths.append(global_dir / "mcp.json")
    else:
        search_paths.append(Path.home() / ".krim" / "mcp.json")
    if project_dir:
        search_paths.append(project_dir / "mcp.json")

    for path in search_paths:
        if path.is_file():
            try:
                with open(path) as f:
                    data = json.load(f)
                for name, cfg in data.get("mcpServers", {}).items():
                    command = _normalize_command_config(cfg["command"], cfg.get("args"))
                    configs.append(McpServerConfig(
                        name=name,
                        command=command,
                        env=cfg.get("env"),
                        wire_format=cfg.get("wire_format", "auto"),
                    ))
            except Exception as e:
                console.print(f"[yellow]mcp: failed to load {path}: {e}[/]")

    return configs


def start_mcp_servers(configs: list[McpServerConfig]) -> tuple[list[McpTool], list[McpServer]]:
    """Start all MCP servers and collect their tools. Returns (tools, servers) for cleanup."""
    all_tools = []
    servers = []
    for cfg in configs:
        try:
            server = McpServer(cfg)
            server.start()
            servers.append(server)
            all_tools.extend(server.tools)
            console.print(f"[dim]mcp: {cfg.name} started ({len(server.tools)} tools)[/]")
        except Exception as e:
            console.print(f"[yellow]mcp: failed to start {cfg.name}: {e}[/]")
    return all_tools, servers
