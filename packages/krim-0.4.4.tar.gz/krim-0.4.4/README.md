# KRIM CLI

Thin CLI agent. Trust the model, keep the harness light.

## Installation

```bash
pip install krim
```

## Usage

```bash
# Interactive mode
krim

# Single prompt
krim "fix the bug in main.py"

# With options
krim --provider claude --model claude-sonnet-4-5-20250929 "refactor this"
krim --max-turns 20 "big refactor task"
```

## License

MIT
