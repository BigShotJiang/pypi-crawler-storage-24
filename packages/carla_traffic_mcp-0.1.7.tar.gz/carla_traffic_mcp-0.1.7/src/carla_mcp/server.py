#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CARLA Traffic Scenario MCP Server
用于百炼平台的MCP服务，生成CARLA交通仿真场景配置脚本
使用 stdio 传输方式（百炼 uvx 部署要求）
"""

import json
import asyncio
from typing import Any
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

from .tools import (
    generate_road_junction,
    generate_traffic_flow,
    generate_signal_control,
    generate_vehicle_behavior,
    generate_pedestrian,
    generate_weather,
    generate_full_scenario,
)

# 创建MCP服务器实例
server = Server("carla-traffic-mcp")


@server.list_tools()
async def list_tools() -> list[Tool]:
    """列出所有可用的MCP工具"""
    return [
        Tool(
            name="generate_road_junction",
            description="生成道路/路口类型配置。根据用户描述的路口类型（十字路口、T字路口、环岛、五岔路口、高速公路等）选择合适的CARLA地图。",
            inputSchema={
                "type": "object",
                "properties": {
                    "junction_type": {
                        "type": "string",
                        "enum": ["cross", "T", "roundabout", "five_way", "highway"],
                        "description": "路口类型：cross(十字路口)、T(T字路口)、roundabout(环岛)、five_way(五岔路口)、highway(高速公路)"
                    }
                },
                "required": ["junction_type"]
            }
        ),
        Tool(
            name="generate_traffic_flow",
            description="生成交通流配置。根据用户描述的车流密度（低、正常、高、高峰期）设置车辆数量、车头时距等参数。",
            inputSchema={
                "type": "object",
                "properties": {
                    "density": {
                        "type": "string",
                        "enum": ["low", "normal", "high", "peak"],
                        "description": "车流密度：low(低密度)、normal(正常)、high(高密度)、peak(高峰期)"
                    },
                    "vehicle_count": {
                        "type": "integer",
                        "description": "车辆数量（可选，不填则根据密度自动设置）"
                    }
                },
                "required": ["density"]
            }
        ),
        Tool(
            name="generate_signal_control",
            description="生成信号灯控制配置。设置红绿灯周期和各相位时长。",
            inputSchema={
                "type": "object",
                "properties": {
                    "cycle": {
                        "type": "integer",
                        "description": "信号周期（秒）"
                    },
                    "green_time": {
                        "type": "integer",
                        "description": "绿灯时长（秒）"
                    },
                    "red_time": {
                        "type": "integer",
                        "description": "红灯时长（秒）"
                    },
                    "yellow_time": {
                        "type": "integer",
                        "description": "黄灯时长（秒）"
                    }
                },
                "required": ["cycle"]
            }
        ),
        Tool(
            name="generate_vehicle_behavior",
            description="生成车辆行为配置。设置平均车速、跟驰行为、换道频率等参数。",
            inputSchema={
                "type": "object",
                "properties": {
                    "avg_speed": {
                        "type": "number",
                        "description": "平均车速（km/h）"
                    },
                    "lane_change_freq": {
                        "type": "string",
                        "enum": ["low", "normal", "high"],
                        "description": "换道频率"
                    },
                    "aggressive_level": {
                        "type": "string",
                        "enum": ["cautious", "normal", "aggressive"],
                        "description": "驾驶激进程度"
                    }
                },
                "required": ["avg_speed"]
            }
        ),
        Tool(
            name="generate_pedestrian",
            description="生成行人配置。设置行人数量和过街行为。",
            inputSchema={
                "type": "object",
                "properties": {
                    "count": {
                        "type": "integer",
                        "description": "行人数量"
                    },
                    "crossing_freq": {
                        "type": "string",
                        "enum": ["low", "normal", "high"],
                        "description": "过街频率"
                    }
                },
                "required": ["count"]
            }
        ),
        Tool(
            name="generate_weather",
            description="生成天气配置。设置天气条件和能见度。",
            inputSchema={
                "type": "object",
                "properties": {
                    "weather_type": {
                        "type": "string",
                        "enum": ["clear", "cloudy", "rain", "fog", "night"],
                        "description": "天气类型：clear(晴天)、cloudy(多云)、rain(雨天)、fog(雾天)、night(夜间)"
                    }
                },
                "required": ["weather_type"]
            }
        ),
        Tool(
            name="generate_full_scenario",
            description="生成完整的CARLA交通场景Python脚本。整合所有配置参数，生成可直接运行的Python脚本文件。",
            inputSchema={
                "type": "object",
                "properties": {
                    "scenario_name": {
                        "type": "string",
                        "description": "场景名称"
                    },
                    "junction_type": {
                        "type": "string",
                        "description": "路口类型"
                    },
                    "traffic_density": {
                        "type": "string",
                        "description": "车流密度"
                    },
                    "signal_cycle": {
                        "type": "integer",
                        "description": "信号周期（秒）"
                    },
                    "pedestrian_count": {
                        "type": "integer",
                        "description": "行人数量"
                    },
                    "weather_type": {
                        "type": "string",
                        "description": "天气类型"
                    }
                },
                "required": ["scenario_name"]
            }
        )
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
    """处理工具调用"""
    result = ""

    if name == "generate_road_junction":
        result = generate_road_junction(arguments.get("junction_type", "cross"))

    elif name == "generate_traffic_flow":
        result = generate_traffic_flow(
            arguments.get("density", "normal"),
            arguments.get("vehicle_count")
        )

    elif name == "generate_signal_control":
        result = generate_signal_control(
            arguments.get("cycle", 60),
            arguments.get("green_time", 30),
            arguments.get("red_time", 25),
            arguments.get("yellow_time", 5)
        )

    elif name == "generate_vehicle_behavior":
        result = generate_vehicle_behavior(
            arguments.get("avg_speed", 40),
            arguments.get("lane_change_freq", "normal"),
            arguments.get("aggressive_level", "normal")
        )

    elif name == "generate_pedestrian":
        result = generate_pedestrian(
            arguments.get("count", 20),
            arguments.get("crossing_freq", "normal")
        )

    elif name == "generate_weather":
        result = generate_weather(arguments.get("weather_type", "clear"))

    elif name == "generate_full_scenario":
        result = generate_full_scenario(
            scenario_name=arguments.get("scenario_name", "交通仿真场景"),
            junction_type=arguments.get("junction_type", "cross"),
            traffic_density=arguments.get("traffic_density", "normal"),
            signal_cycle=arguments.get("signal_cycle", 60),
            pedestrian_count=arguments.get("pedestrian_count", 20),
            weather_type=arguments.get("weather_type", "clear")
        )

    else:
        result = f"未知工具: {name}"

    return [TextContent(type="text", text=result)]


async def async_main():
    """异步启动MCP服务器（stdio模式）"""
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options()
        )


def main():
    """同步入口点 - 启动MCP服务器"""
    asyncio.run(async_main())


if __name__ == "__main__":
    main()
