from abc import ABC, abstractmethod
from typing import Any
from address_normalizer.schemas.endereco import NormalizationResult

class PipelineStep(ABC):
    @abstractmethod
    def name(self) -> str:
        """Nome da etapa para auditoria."""
        pass

    @abstractmethod
    async def process(self, data: dict, context: dict) -> tuple[dict, list[dict]]:
        """Processa os dados e retorna (dados_modificados, transformacoes)."""
        pass

    def should_run(self, data: dict, context: dict) -> bool:
        """Verifica se esta etapa deve ser executada (default True)."""
        return True
