"""Correção de logradouros com encoding corrompido (ISO-8859-1 → ASCII).

Vogais acentuadas foram removidas durante conversão de encoding, deixando
fragmentos como "JOO" (João), "ANT NIO" (Antônio), "CORA OES" (Corações).

Este módulo aplica regras de substituição ordenadas por especificidade
(mais longas/contextuais primeiro) para restaurar os nomes corretos.
"""

import re
from dataclasses import dataclass, field


# ---------------------------------------------------------------------------
# A) Dicionário de regras: lista ordenada de (pattern_regex, replacement)
#
# ORDEM IMPORTA: regras mais específicas (com contexto/lookbehind) vêm antes
# das genéricas para evitar substituições parciais.
# ---------------------------------------------------------------------------

REGRAS_ENCODING: list[tuple[str, str]] = [
    # ===== GRUPO 1: Formas compostas com espaço (prefixo + sufixo) =====

    # --- NIO (masculino) - nomes com terminação -ônio, -ênio, -ínio ---
    (r"\bANT\s+NIO\b", "ANTÔNIO"),
    (r"\bEUG\s+NIO\b", "EUGÊNIO"),
    (r"\bVIR\s+NIO\b", "VIRGÍNIO"),
    (r"\bHER\s+NIO\b", "HERMÍNIO"),
    (r"\bDOM\s+NIO\b", "DOMÍNIO"),
    (r"\bPATR\s+NIO\b", "PATRIMÔNIO"),
    (r"\bTEST\s+NIO\b", "TESTEMÔNIO"),
    (r"\bPATRIM\s+NIO\b", "PATRIMÔNIO"),
    (r"\bDEM\s+NIO\b", "DEMÔNIO"),
    (r"\bCOND\s+NIO\b", "CONDOMÍNIO"),
    (r"\bON\s+NIO\b", "ONÊNIO"),
    (r"\bPEL\s+NIO\b", "PELÔNIO"),
    (r"\bARS\s+NIO\b", "ARSÊNIO"),
    (r"\bSEL\s+NIO\b", "SELÊNIO"),
    (r"\bIR\s+NIO\b", "IRÊNIO"),
    (r"\bCEN\s+NIO\b", "CENÊNIO"),
    (r"\bLIC\s+NIO\b", "LICÍNIO"),
    (r"\bFUL\s+NIO\b", "FULGÊNIO"),
    (r"\bMIN\s+NIO\b", "MINÊNIO"),
    (r"\bFLAM\s+NIO\b", "FLAMÍNIO"),
    (r"\bSAT\s+NIO\b", "SATURNÍNIO"),
    (r"\bLAV\s+NIO\b", "LAVÍNIO"),
    (r"\bJUV\s+NIO\b", "JUVENCIO"),  # variação rara

    # --- NIA (feminino) - nomes com terminação -ônia, -ênia, -ânia ---
    (r"\bANT\s+NIA\b", "ANTÔNIA"),
    (r"\bEFIG\s+NIA\b", "EFIGÊNIA"),
    (r"\bIFIG\s+NIA\b", "IFIGÊNIA"),
    (r"\bEUG\s+NIA\b", "EUGÊNIA"),
    (r"\bVIRG\s+NIA\b", "VIRGÍNIA"),
    (r"\bALEX\s+NIA\b", "ALEXÂNIA"),
    (r"\bGOI\s+NIA\b", "GOIÂNIA"),
    (r"\bBRIT\s+NIA\b", "BRITÂNIA"),
    (r"\bCAMP\s+NIA\b", "CAMPÂNIA"),
    (r"\bLUS\s+NIA\b", "LUSÂNIA"),
    (r"\bURB\s+NIA\b", "URBÂNIA"),
    (r"\bSID\s+NIA\b", "SIDÔNIA"),
    (r"\bMAC\s+NIA\b", "MACEDÔNIA"),
    (r"\bPATR\s+NIA\b", "PATRIMÔNIA"),
    (r"\bHER\s+NIA\b", "HERMÍNIA"),
    (r"\bLAV\s+NIA\b", "LAVÍNIA"),
    (r"\bSARD\s+NIA\b", "SARDÂNIA"),

    # --- CIO - nomes com terminação -ácio, -ício, -úcio ---
    (r"\bIN\s+CIO\b", "INÁCIO"),
    (r"\bIGN\s+CIO\b", "IGNÁCIO"),
    (r"\bMAUR\s+CIO\b", "MAURÍCIO"),
    (r"\bPATR\s+CIO\b", "PATRÍCIO"),
    (r"\bFABR\s+CIO\b", "FABRÍCIO"),
    (r"\bVIN\s+CIO\b", "VINÍCIUS"),  # variação corrompida "VIN CIO"
    (r"\bBONIF\s+CIO\b", "BONIFÁCIO"),
    (r"\bHOR\s+CIO\b", "HORÁCIO"),
    (r"\bEUST\s+CIO\b", "EUSTÁQUIO"),  # variação
    (r"\bLUCR\s+CIO\b", "LUCRÉCIO"),
    (r"\bTEREN\s+CIO\b", "TERÊNCIO"),
    (r"\bLAUR\s+CIO\b", "LAURÊNCIO"),
    (r"\bEV\s+CIO\b", "EVÂNCIO"),
    (r"\bCON\s+CIO\b", "CONSÓRCIO"),
    (r"\bCOM\s+CIO\b", "COMÉRCIO"),
    (r"\bNEG\s+CIO\b", "NEGÓCIO"),
    (r"\bINN\s+CIO\b", "INOCÊNCIO"),
    (r"\bINOC\s+CIO\b", "INOCÊNCIO"),
    (r"\bDEM\s+CIO\b", "DEMÓCIO"),

    # --- LIO - nomes com terminação -úlio, -ílio, -élio ---
    (r"\bGET\s+LIO\b", "GETÚLIO"),
    (r"\bJ\s+LIO\b", "JÚLIO"),
    (r"\bJU\s+LIO\b", "JÚLIO"),
    (r"\bEM\s+LIO\b", "EMÍLIO"),
    (r"\bAUR\s+LIO\b", "AURÉLIO"),
    (r"\bPERC\s+LIO\b", "PERCÍLIO"),
    (r"\bAT\s+LIO\b", "ATÍLIO"),
    (r"\bCEC\s+LIO\b", "CECÍLIO"),
    (r"\bVIRG\s+LIO\b", "VIRGÍLIO"),
    (r"\bBAS\s+LIO\b", "BASÍLIO"),
    (r"\bOV\s+LIO\b", "OVÍDIO"),  # variação rara
    (r"\bOT\s+LIO\b", "OTÍLIO"),
    (r"\bCORN\s+LIO\b", "CORNÉLIO"),
    (r"\bROS\s+LIO\b", "ROSÉLIO"),
    (r"\bEV\s+LIO\b", "EVÉLIO"),
    (r"\bTUL\s+LIO\b", "TÚLIO"),
    (r"\bOF\s+LIO\b", "OFÉLIO"),
    (r"\bDE\s+LIO\b", "DÉLIO"),

    # --- OES - terminações -ões ---
    (r"\bCORA\s+OES\b", "CORAÇÕES"),
    (r"\bNA\s+OES\b", "NAÇÕES"),
    (r"\bLE\s+OES\b", "LEÕES"),
    (r"\bFALC\s+OES\b", "FALCÕES"),
    (r"\bTUBAR\s+OES\b", "TUBARÕES"),
    (r"\bCAM\s+OES\b", "CAMÕES"),
    (r"\bSERT\s+OES\b", "SERTÕES"),
    (r"\bGIR\s+OES\b", "GIRÕES"),
    (r"\bPAV\s+OES\b", "PAVÕES"),
    (r"\bFALCOES\b", "FALCÕES"),  # sem espaço, acento faltante
    (r"\bDRAG\s+OES\b", "DRAGÕES"),
    (r"\bAVI\s+OES\b", "AVIÕES"),

    # --- JOO - João ---
    (r"\bJOO\b", "JOÃO"),

    # --- JOS - José (acento removido) ---
    (r"\bJOS\b(?=\s+[A-Z])", "JOSÉ"),  # "JOS" seguido de outro nome

    # --- IMO - Irmão ---
    (r"\bIMO\b(?=\s+[A-Z])", "IRMÃO"),  # "IMO" seguido de nome próprio

    # --- IRMAO - Irmão (sem acento) ---
    (r"\bIRMAO\b", "IRMÃO"),

    # --- OTAO - Otão ---
    (r"\bOTAO\b", "OTÃO"),

    # ===== GRUPO 2: Terminações comuns sem espaço (acento faltante) =====

    (r"\bPRACA\b", "PRAÇA"),
    (r"\bSAO\b", "SÃO"),
    (r"\bJOAO\b", "JOÃO"),
    (r"\bSEBASTIAO\b", "SEBASTIÃO"),
    (r"\bCONSTITUICAO\b", "CONSTITUIÇÃO"),
    (r"\bCONCEICAO\b", "CONCEIÇÃO"),
    (r"\bREDENCAO\b", "REDENÇÃO"),
    (r"\bASSUNCAO\b", "ASSUNÇÃO"),
    (r"\bEMILIO\b", "EMÍLIO"),
    (r"\bGETULIO\b", "GETÚLIO"),
    (r"\bANTONIO\b", "ANTÔNIO"),
    (r"\bJOSE\b", "JOSÉ"),

    # ===== GRUPO 3: Terminações genéricas (ÚLTIMO RECURSO) =====
    # Aplicadas apenas quando nenhuma regra contextual acima casou.
    # Estas são mais arriscadas e devem vir por último.
]

# Fragmentos que são altamente ambíguos e requerem revisão humana.
# Se encontrados isolados, a função sinaliza requer_revisao=True.
FRAGMENTOS_AMBIGUOS: list[str] = [
    r"\bRIA\b",       # pode ser -ária, -ória, Maria, etc.
    r"\bLIA\b",       # pode ser -ília, -ália, -élia, Amália, etc.
    r"\bNIO\b",       # sem prefixo, não se sabe qual nome
    r"\bNIA\b",       # sem prefixo, não se sabe qual nome
    r"\bCIO\b",       # sem prefixo, não se sabe qual nome
    r"\bLIO\b",       # sem prefixo, não se sabe qual nome
    r"\bOES\b",       # sem prefixo, não se sabe qual terminação -ões
]

# Pré-compilar as regras para performance
_REGRAS_COMPILADAS: list[tuple[re.Pattern, str]] = [
    (re.compile(pattern), replacement)
    for pattern, replacement in REGRAS_ENCODING
]

_AMBIGUOS_COMPILADOS: list[re.Pattern] = [
    re.compile(pattern) for pattern in FRAGMENTOS_AMBIGUOS
]


# ---------------------------------------------------------------------------
# B) Função principal
# ---------------------------------------------------------------------------

@dataclass
class EncodingFixResult:
    """Resultado da correção de encoding de um logradouro."""
    original: str
    corrigido: str
    alteracoes: list[str] = field(default_factory=list)
    requer_revisao: bool = False
    fragmentos_ambiguos: list[str] = field(default_factory=list)


def corrigir_logradouro(texto: str) -> EncodingFixResult:
    """Aplica regras de correção de encoding corrompido a um logradouro.

    Args:
        texto: Logradouro em UPPER CASE, possivelmente corrompido.

    Returns:
        EncodingFixResult com o texto corrigido, lista de alterações
        aplicadas e flag de revisão para fragmentos ambíguos.
    """
    resultado = EncodingFixResult(original=texto, corrigido=texto)

    # Aplicar regras na ordem definida (mais específicas primeiro)
    current = texto
    for pattern, replacement in _REGRAS_COMPILADAS:
        new_text = pattern.sub(replacement, current)
        if new_text != current:
            resultado.alteracoes.append(f"{pattern.pattern} → {replacement}")
            current = new_text

    resultado.corrigido = current

    # Verificar se restam fragmentos ambíguos não resolvidos
    for pattern in _AMBIGUOS_COMPILADOS:
        match = pattern.search(resultado.corrigido)
        if match:
            fragmento = match.group()
            resultado.requer_revisao = True
            resultado.fragmentos_ambiguos.append(fragmento)

    return resultado


def corrigir_logradouro_dict(texto: str) -> dict:
    """Versão dict-friendly de corrigir_logradouro para serialização."""
    r = corrigir_logradouro(texto)
    return {
        "original": r.original,
        "corrigido": r.corrigido,
        "alteracoes": r.alteracoes,
        "requer_revisao": r.requer_revisao,
        "fragmentos_ambiguos": r.fragmentos_ambiguos,
    }


# ---------------------------------------------------------------------------
# Integração com o Preprocessor do pipeline
# ---------------------------------------------------------------------------

def aplicar_correcao_encoding(valor: str) -> tuple[str, list[dict]]:
    """Aplica correção de encoding e retorna no formato do pipeline.

    Args:
        valor: Texto do campo (logradouro, bairro, etc).

    Returns:
        Tupla (valor_corrigido, lista_de_transformacoes).
    """
    result = corrigir_logradouro(valor)
    transformacoes = []
    if result.corrigido != result.original:
        transformacoes.append({
            "campo": "logradouro",
            "tipo": "encoding_fix",
            "de": result.original,
            "para": result.corrigido,
        })
    return result.corrigido, transformacoes


# ---------------------------------------------------------------------------
# D) Nota sobre integração PostgreSQL
# ---------------------------------------------------------------------------

POSTGRESQL_NOTES = """
-- =========================================================================
-- INTEGRAÇÃO POSTGRESQL: Correção de encoding com regexp_replace em cadeia
-- =========================================================================
--
-- No PostgreSQL, use \\y no lugar de \\b para word boundaries.
-- Exemplo de função PL/pgSQL que aplica as regras em cadeia:

CREATE OR REPLACE FUNCTION corrigir_encoding_logradouro(texto TEXT)
RETURNS TABLE(corrigido TEXT, requer_revisao BOOLEAN) AS $$
DECLARE
    resultado TEXT := texto;
    tem_ambiguidade BOOLEAN := FALSE;
BEGIN
    -- Grupo 1: Formas compostas com contexto (mais específicas primeiro)
    resultado := regexp_replace(resultado, '\\yANT\\s+NIO\\y', 'ANTÔNIO', 'g');
    resultado := regexp_replace(resultado, '\\yEUG\\s+NIO\\y', 'EUGÊNIO', 'g');
    resultado := regexp_replace(resultado, '\\yVIR\\s+NIO\\y', 'VIRGÍNIO', 'g');
    resultado := regexp_replace(resultado, '\\yHER\\s+NIO\\y', 'HERMÍNIO', 'g');

    resultado := regexp_replace(resultado, '\\yANT\\s+NIA\\y', 'ANTÔNIA', 'g');
    resultado := regexp_replace(resultado, '\\yEFIG\\s+NIA\\y', 'EFIGÊNIA', 'g');
    resultado := regexp_replace(resultado, '\\yVIRG\\s+NIA\\y', 'VIRGÍNIA', 'g');
    resultado := regexp_replace(resultado, '\\yGOI\\s+NIA\\y', 'GOIÂNIA', 'g');

    resultado := regexp_replace(resultado, '\\yIN\\s+CIO\\y', 'INÁCIO', 'g');
    resultado := regexp_replace(resultado, '\\yMAUR\\s+CIO\\y', 'MAURÍCIO', 'g');
    resultado := regexp_replace(resultado, '\\yFABR\\s+CIO\\y', 'FABRÍCIO', 'g');
    resultado := regexp_replace(resultado, '\\yBONIF\\s+CIO\\y', 'BONIFÁCIO', 'g');
    resultado := regexp_replace(resultado, '\\yHOR\\s+CIO\\y', 'HORÁCIO', 'g');
    resultado := regexp_replace(resultado, '\\yCOM\\s+CIO\\y', 'COMÉRCIO', 'g');

    resultado := regexp_replace(resultado, '\\yGET\\s+LIO\\y', 'GETÚLIO', 'g');
    resultado := regexp_replace(resultado, '\\yEM\\s+LIO\\y', 'EMÍLIO', 'g');
    resultado := regexp_replace(resultado, '\\yAUR\\s+LIO\\y', 'AURÉLIO', 'g');
    resultado := regexp_replace(resultado, '\\yJ\\s+LIO\\y', 'JÚLIO', 'g');
    resultado := regexp_replace(resultado, '\\yBAS\\s+LIO\\y', 'BASÍLIO', 'g');
    resultado := regexp_replace(resultado, '\\yCORN\\s+LIO\\y', 'CORNÉLIO', 'g');

    resultado := regexp_replace(resultado, '\\yCORA\\s+OES\\y', 'CORAÇÕES', 'g');
    resultado := regexp_replace(resultado, '\\yNA\\s+OES\\y', 'NAÇÕES', 'g');
    resultado := regexp_replace(resultado, '\\yLE\\s+OES\\y', 'LEÕES', 'g');
    resultado := regexp_replace(resultado, '\\yCAM\\s+OES\\y', 'CAMÕES', 'g');

    resultado := regexp_replace(resultado, '\\yJOO\\y', 'JOÃO', 'g');
    resultado := regexp_replace(resultado, '\\yIRMAO\\y', 'IRMÃO', 'g');
    resultado := regexp_replace(resultado, '\\yOTAO\\y', 'OTÃO', 'g');
    resultado := regexp_replace(resultado, '\\yPRACA\\y', 'PRAÇA', 'g');
    resultado := regexp_replace(resultado, '\\ySAO\\y', 'SÃO', 'g');
    resultado := regexp_replace(resultado, '\\yJOAO\\y', 'JOÃO', 'g');
    resultado := regexp_replace(resultado, '\\yANTONIO\\y', 'ANTÔNIO', 'g');
    resultado := regexp_replace(resultado, '\\yJOSE\\y', 'JOSÉ', 'g');
    resultado := regexp_replace(resultado, '\\yGETULIO\\y', 'GETÚLIO', 'g');
    resultado := regexp_replace(resultado, '\\yEMILIO\\y', 'EMÍLIO', 'g');

    -- Verificar fragmentos ambíguos remanescentes
    IF resultado ~ '\\yRIA\\y' OR resultado ~ '\\yLIA\\y'
       OR resultado ~ '\\yNIO\\y' OR resultado ~ '\\yNIA\\y'
       OR resultado ~ '\\yCIO\\y' OR resultado ~ '\\yLIO\\y'
       OR resultado ~ '\\yOES\\y' THEN
        tem_ambiguidade := TRUE;
    END IF;

    RETURN QUERY SELECT resultado, tem_ambiguidade;
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Uso:
-- SELECT * FROM corrigir_encoding_logradouro('RUA ANT NIO ALVARENGA DE RESENDE');
-- → ('RUA ANTÔNIO ALVARENGA DE RESENDE', FALSE)
--
-- UPDATE enderecos SET
--   logradouro = (corrigir_encoding_logradouro(logradouro)).corrigido,
--   requer_revisao = (corrigir_encoding_logradouro(logradouro)).requer_revisao
-- WHERE logradouro ~ '\\y(JOO|NIO|NIA|CIO|LIO|OES|IMO|OTAO|IRMAO)\\y'
--    OR logradouro ~ '\\w+\\s+(NIO|NIA|CIO|LIO|OES)\\y';
"""
