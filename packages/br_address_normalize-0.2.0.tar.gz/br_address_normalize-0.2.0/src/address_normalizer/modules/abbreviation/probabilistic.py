"""Serviço probabilístico de expansão de abreviações via PCAF.

Acionado somente quando o determinístico não resolve e o campo é logradouro
em posição de prefixo. Confiança mínima configurável (padrão 0.85).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from address_normalizer.modules.abbreviation.api_provider import ApiAbbreviationProvider


@dataclass
class ProbabilisticResult:
    expanded: Optional[str]
    confidence: float
    source: str = "pcaf"


MIN_CONFIDENCE = 0.85


class ProbabilisticService:
    """Expande tokens de prefixo de logradouro via API PCAF.

    Nunca chamado para bairro, municipio ou complemento na v1.

    Exemplo:
        >>> svc = ProbabilisticService(api_provider)
        >>> await svc.expand_prefix("TV", "AM")
        ProbabilisticResult(expanded='TRAVESSA', confidence=0.97, source='pcaf')
    """

    def __init__(self, api_provider: ApiAbbreviationProvider, min_confidence: float = MIN_CONFIDENCE):
        """
        Args:
            api_provider: Provider PCAF/Redis já instanciado.
            min_confidence: Confiança mínima para aceitar a expansão (default 0.85).
        """
        self._api = api_provider
        self._min_confidence = min_confidence

    async def expand_prefix(self, token: str, uf: str) -> ProbabilisticResult:
        """Tenta expandir um token de prefixo de logradouro via PCAF.

        Se a confiança retornada for menor que min_confidence, retorna None
        (expansão rejeitada) e a chamada registra flag LOW_CONFIDENCE.

        Args:
            token: Token a expandir (uppercase).
            uf: UF para contexto Redis interno do api_provider.

        Returns:
            ProbabilisticResult com expanded=None se confiança insuficiente.
        """
        context = {"uf": uf} if uf else None
        try:
            expanded_text, transforms = await self._api.expand(token, "logradouro", context=context)
        except Exception:
            return ProbabilisticResult(expanded=None, confidence=0.0)

        if not transforms:
            # Nenhuma expansão foi produzida pelo provider
            return ProbabilisticResult(expanded=None, confidence=0.0)

        # O api_provider não retorna confidence explicitamente; usamos 1.0 quando
        # o PCAF mudou o token (sinaliza que reconheceu a abreviação).
        first = transforms[0]
        expanded = first.get("para", "").upper()
        # Confidence sintética: 1.0 se PCAF retornou valor diferente do original
        confidence = 1.0 if expanded and expanded != token.upper() else 0.0

        if confidence < self._min_confidence:
            return ProbabilisticResult(expanded=None, confidence=confidence)

        return ProbabilisticResult(expanded=expanded, confidence=confidence, source="pcaf")
