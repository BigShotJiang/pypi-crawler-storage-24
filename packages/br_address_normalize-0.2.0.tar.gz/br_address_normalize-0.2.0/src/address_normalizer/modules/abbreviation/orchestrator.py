"""Orquestrador principal do módulo de expansão de abreviações.

Combina a Camada Determinística (L1) e o Fallback Probabilístico Injetável (L2).
"""

from __future__ import annotations

import json
from pathlib import Path

from address_normalizer.data import load_unified_abbreviations, build_field_indices, load_null_markers
from address_normalizer.modules.abbreviation.deterministic import DeterministicLayer
from address_normalizer.modules.abbreviation.entity_rules import EntityRules
from address_normalizer.modules.abbreviation.heuristics import calculate_confidence
from address_normalizer.modules.abbreviation.models import (
    TransformationLog,
    AbbreviationFlag,
    ExpandRecordResult,
    ExpanderConfig,
)


class AddressExpander:
    """Orquestrador do motor de expansão de abreviações."""

    def __init__(self, config: ExpanderConfig | None = None):
        self.config = config or ExpanderConfig()

        general_dict = self.config.custom_general_dict.copy()

        if self.config.use_default_dictionaries:
            dict_path = Path(__file__).parent / "dictionaries" / "abbreviations.json"
            if dict_path.exists():
                with open(dict_path, "r", encoding="utf-8") as f:
                    raw = json.load(f)
                    for k, v in raw.items():
                        general_dict[k.upper()] = v.upper()

        # Load unified data
        unified = load_unified_abbreviations()
        field_indices, positional_indices = build_field_indices(unified)
        null_markers = load_null_markers()
        self._null_markers = null_markers

        self._l1 = DeterministicLayer(
            field_indices=field_indices,
            positional_indices=positional_indices,
            null_markers=null_markers,
            general_dict=general_dict,
            preserve_unknown_codes=self.config.preserve_unknown_codes,
        )

    async def expand_record(
        self,
        logradouro: str | None = None,
        complemento: str | None = None,
        bairro: str | None = None,
        municipio: str | None = None,
    ) -> ExpandRecordResult:
        """Processa todos os campos de um registro de endereço."""
        result = ExpandRecordResult()
        all_transforms: list[TransformationLog] = []
        all_flags: list[AbbreviationFlag] = []

        fields_to_process = [
            ("logradouro", logradouro),
            ("complemento", complemento),
            ("bairro", bairro),
            ("municipio", municipio),
        ]

        for field_name, value in fields_to_process:
            if not value or not value.strip():
                setattr(result, field_name, value)
                continue

            expanded, transforms, flags = await self.expand_field(value, field_name)

            setattr(result, field_name, expanded)
            all_transforms.extend(transforms)
            all_flags.extend(flags)

        result.transformations = all_transforms
        result.flags = all_flags

        return result

    async def expand_field(
        self,
        text: str,
        field_name: str,
    ) -> tuple[str | None, list[TransformationLog], list[AbbreviationFlag]]:
        """Expande os tokens de um único campo."""
        tokens = text.split()
        new_tokens: list[str] = []
        transforms: list[TransformationLog] = []
        flags: list[AbbreviationFlag] = []

        # Se o campo inteiro é um único token de remoção
        if len(tokens) == 1 and tokens[0].upper() in self._null_markers:
            transforms.append(TransformationLog(
                field=field_name,
                token_original=tokens[0],
                token_expanded="",
                rule_applied="REMOVE",
                source="l1_hardcoded",
                confidence=1.0,
                position=0,
            ))
            return None, transforms, flags

        for i, token in enumerate(tokens):
            t_upper = token.upper().rstrip(".,;:")
            next_token = tokens[i + 1].upper() if i + 1 < len(tokens) else None

            expanded_token, t_transforms, t_flags = await self._process_token(
                t_upper, next_token, field_name, i
            )

            if expanded_token is None:
                transforms.extend(t_transforms)
                flags.extend(t_flags)
                continue

            if expanded_token == t_upper and token.endswith((",", ".", ";", ":")):
                new_tokens.append(token)
            else:
                new_tokens.append(expanded_token)

            transforms.extend(t_transforms)
            flags.extend(t_flags)

        if not new_tokens:
            return None, transforms, flags

        # Regra DEDUP L1
        if (
            field_name == "logradouro"
            and len(new_tokens) >= 2
            and new_tokens[0] == new_tokens[1]
            and new_tokens[0] in self._l1.tipo_logradouro_full_forms
        ):
            removed_token = new_tokens.pop(1)
            transforms.append(TransformationLog(
                field=field_name,
                token_original=removed_token,
                token_expanded="",
                rule_applied="DEDUP_TYPE",
                source="l1_hardcoded",
                confidence=1.0,
                position=1,
            ))

        return " ".join(new_tokens), transforms, flags

    async def _process_token(
        self,
        token: str,
        next_token: str | None,
        field_name: str,
        position: int,
    ) -> tuple[str | None, list[TransformationLog], list[AbbreviationFlag]]:
        """Avalia um token usando L1 e depois tenta L2 se elegível."""
        transforms: list[TransformationLog] = []
        flags: list[AbbreviationFlag] = []

        # L1: Determinístico
        decision = self._l1.expand_token(token, next_token, field_name, position)

        if decision.action == "remove":
            transforms.append(TransformationLog(
                field=field_name,
                token_original=token,
                token_expanded="",
                rule_applied=decision.rule_applied or "REMOVE",
                source=decision.source,
                confidence=decision.confidence,
                position=position,
            ))
            return None, transforms, flags

        if decision.action == "expand" and decision.expanded:
            transforms.append(TransformationLog(
                field=field_name,
                token_original=token,
                token_expanded=decision.expanded,
                rule_applied=decision.rule_applied or "L1_EXPAND",
                source=decision.source,
                confidence=decision.confidence,
                position=position,
            ))
            return decision.expanded, transforms, flags

        if decision.action == "flag_sistema" and decision.expanded:
            if self.config.nullify_sistema_siglas:
                transforms.append(TransformationLog(
                    field=field_name,
                    token_original=token,
                    token_expanded="",
                    rule_applied="SIGLA_SISTEMA_NULLIFY",
                    source=decision.source,
                    confidence=decision.confidence,
                    position=position,
                ))
                flags.append(AbbreviationFlag(
                    code="SIGLA_SISTEMA",
                    field=field_name,
                    token=token,
                    detail=f"nullified (original_expansion={decision.expanded})",
                ))
                return None, transforms, flags
            else:
                transforms.append(TransformationLog(
                    field=field_name,
                    token_original=token,
                    token_expanded=decision.expanded,
                    rule_applied=decision.rule_applied or "SIGLA_SISTEMA",
                    source=decision.source,
                    confidence=decision.confidence,
                    position=position,
                ))
                flags.append(AbbreviationFlag(
                    code="SIGLA_SISTEMA",
                    field=field_name,
                    token=token,
                    detail=f"expanded={decision.expanded}",
                ))
                return decision.expanded, transforms, flags

        if decision.action == "flag_pending":
            flags.append(AbbreviationFlag(
                code=f"PENDING_SAMPLE_{token}",
                field=field_name,
                token=token,
            ))
            # Vai p/ probabilístico se puder (abaixo)

        if decision.action == "flag_internal":
            flags.append(AbbreviationFlag(
                code="INTERNAL_CODE",
                field=field_name,
                token=token,
            ))
            return token, transforms, flags

        # L2: Probabilístico / Threshold Helper System
        if (
            self.config.l2_caller is not None
            and EntityRules.can_use_l2(field_name, position)
        ):
            try:
                l2_responses = await self.config.l2_caller([token])

                if l2_responses and len(l2_responses) > 0:
                    l2_expanded = l2_responses[0].upper()

                    if l2_expanded and l2_expanded != token:
                        confidence = calculate_confidence(token, l2_expanded)

                        if confidence >= self.config.min_l2_confidence:
                            transforms.append(TransformationLog(
                                field=field_name,
                                token_original=token,
                                token_expanded=l2_expanded,
                                rule_applied="L2_PROBABILISTIC",
                                source="l2_caller",
                                confidence=confidence,
                                position=position,
                            ))
                            return l2_expanded, transforms, flags
                        else:
                            flags.append(AbbreviationFlag(
                                code="L2_LOW_CONFIDENCE_REJECTED",
                                field=field_name,
                                token=token,
                                detail=f"suggested={l2_expanded} score={confidence:.2f}",
                            ))

            except Exception as e:
                flags.append(AbbreviationFlag(
                    code="L2_CALL_FAILED",
                    field=field_name,
                    token=token,
                    detail=str(e),
                ))

        return token, transforms, flags
