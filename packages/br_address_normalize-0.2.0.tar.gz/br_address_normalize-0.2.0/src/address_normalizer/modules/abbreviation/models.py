from dataclasses import dataclass, field
from typing import Optional, Literal, Callable, Awaitable


@dataclass
class TransformationLog:
    """Registro de uma expansão aplicada a um token."""
    field: str
    token_original: str
    token_expanded: str
    rule_applied: str
    source: str
    confidence: float
    position: int


@dataclass
class AbbreviationFlag:
    """Flag de aviso produzida durante a expansão."""
    code: str
    field: str
    token: str
    detail: Optional[str] = None


@dataclass
class TokenDecision:
    """Decisão do motor determinístico (L1) para um token."""
    action: Literal["expand", "preserve", "remove", "flag_pending", "flag_internal", "flag_sistema"]
    expanded: Optional[str] = None
    rule_applied: Optional[str] = None
    source: str = "l1_hardcoded"
    confidence: float = 1.0


@dataclass
class ProbabilisticResult:
    """Resultado da camada probabilística (L2)."""
    expanded: Optional[str]
    confidence: float
    source: str = "l2_caller"


@dataclass
class ExpandRecordResult:
    """Saída do módulo expander ao processar um registro."""
    logradouro: Optional[str] = None
    complemento: Optional[str] = None
    bairro: Optional[str] = None
    municipio: Optional[str] = None
    transformations: list[TransformationLog] = field(default_factory=list)
    flags: list[AbbreviationFlag] = field(default_factory=list)


@dataclass
class ExpanderConfig:
    """Configurações do expander de abreviações."""
    use_default_dictionaries: bool = True
    custom_general_dict: dict[str, str] = field(default_factory=dict)
    preserve_unknown_codes: bool = True
    l2_caller: Optional[Callable[[list[str]], Awaitable[list[str]]]] = None
    min_l2_confidence: float = 0.85
    nullify_sistema_siglas: bool = False
