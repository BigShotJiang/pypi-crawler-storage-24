import httpx
import redis.asyncio as redis

from address_normalizer.modules.abbreviation.base import AbbreviationProvider
from address_normalizer.data import load_abbreviations_dict


class ApiAbbreviationProvider(AbbreviationProvider):
    """Provider de expansão de abreviações via API externa (PCAF).

    Chama o serviço externo POST /pcaf que recebe tipos_logradouros e retorna
    fixed_logradouros com os tipos corrigidos/expandidos. Este provider é capaz
    de corrigir inclusive erros ortográficos nos tipos de logradouro.

    Attributes:
        base_url: URL base da API de abreviações (ex: http://10.233.48.68:4242).
        timeout: Timeout em segundos para chamadas HTTP.
    """

    def __init__(self, base_url: str, redis_url: str = "", timeout: float = 5.0):
        """Inicializa o provider com a URL da API, Redis URL e timeout.

        Args:
            base_url: URL base do serviço de abreviações.
            redis_url: URL de conexão do Redis para buscar contexto estadual.
            timeout: Timeout máximo para requisições HTTP em segundos.
        """
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._client = httpx.AsyncClient(timeout=timeout)
        self._redis = redis.from_url(redis_url, decode_responses=True) if redis_url else None
        
        self._general_dict = load_abbreviations_dict(upper_values=True)

    async def _get_redis_expansion(self, uf: str, word: str) -> str | None:
        """Busca a expansão de uma palavra no Redis usando o UF."""
        if not self._redis or not uf or not word:
            return None
        
        try:
            # Assuming Hash structure: abreviacoes_dataprev:{UF}
            key = f"abreviacoes_dataprev:{uf.upper()}"
            expansion = await self._redis.hget(key, word.upper())
            return expansion.upper() if expansion else None
        except Exception:
            return None

    async def expand(self, text: str, field_name: str, context: dict | None = None) -> tuple[str, list[dict]]:
        """Expande abreviações e corrige tipos usando a API PCAF.

        Para o campo 'logradouro', extrai o primeiro token (tipo de logradouro),
        envia à API PCAF para correção/expansão, e reconstrói o texto.
        Para outros campos, tenta expandir cada token individualmente.

        Args:
            text: Texto com possíveis abreviações de tipo.
            field_name: Nome do campo sendo processado.
            context: Contexto do endereço (não utilizado pelo PCAF).

        Returns:
            Tupla (texto_com_tipo_expandido, lista_de_transformações).
        """
        if not text or not text.strip():
            return text, []

        tokens = text.split()
        if not tokens:
            return text, []

        if field_name == "logradouro" and len(tokens) >= 1:
            return await self._expand_logradouro(tokens, context)

        return await self._expand_generic(tokens, field_name)

    async def _expand_logradouro(self, tokens: list[str], context: dict | None = None) -> tuple[str, list[dict]]:
        """Expande o tipo de logradouro e a segunda palavra usando Dicionário Geral, Redis e PCAF.

        Args:
            tokens: Lista de tokens do logradouro.
            context: Contexto com 'uf' para buscar dicionário no Redis.

        Returns:
            Tupla (logradouro_expandido, transformações).
        """
        transformacoes = []
        uf = context.get("uf") if context else None

        for i in range(min(2, len(tokens))):
            token = tokens[i]
            token_upper = token.upper()
            expanded = None

            # 1. Tentar dicionário geral primeiro
            if token_upper in self._general_dict:
                expanded = self._general_dict[token_upper]

            # 2. Se não encontrou no geral, tenta no Redis (apenas se tiver '.' ou len <= 4)
            if not expanded and ("." in token_upper or len(token_upper) <= 4):
                if uf:
                    expanded = await self._get_redis_expansion(uf, token_upper)

            # 3. Se ainda não encontrou, faz fallback para a API PCAF
            if not expanded:
                try:
                    response = await self._client.post(
                        f"{self._base_url}/pcaf",
                        json={"tipos_logradouros": [token]},
                    )
                    response.raise_for_status()
                    fixed = response.json().get("fixed_logradouros", [])
                    if fixed and fixed[0].upper() != token_upper:
                        expanded = fixed[0].upper()
                except (httpx.HTTPError, KeyError, IndexError):
                    pass

            if expanded and expanded != token_upper:
                transformacoes.append({
                    "campo": "logradouro",
                    "tipo": "abreviacao",
                    "de": token,
                    "para": expanded,
                })
                tokens[i] = expanded

        return " ".join(tokens), transformacoes

    async def _expand_generic(self, tokens: list[str], field_name: str) -> tuple[str, list[dict]]:
        """Expande tipos em campos genéricos enviando todos os tokens ao PCAF.

        Args:
            tokens: Lista de tokens do campo.
            field_name: Nome do campo.

        Returns:
            Tupla (texto_expandido, transformações).
        """
        transformacoes = []

        try:
            response = await self._client.post(
                f"{self._base_url}/pcaf",
                json={"tipos_logradouros": tokens},
            )
            response.raise_for_status()
            data = response.json()
            fixed = data.get("fixed_logradouros", [])

            for i, (original, corrected) in enumerate(zip(tokens, fixed)):
                if corrected.upper() != original.upper():
                    transformacoes.append({
                        "campo": field_name,
                        "tipo": "abreviacao",
                        "de": original,
                        "para": corrected.upper(),
                    })
                    tokens[i] = corrected.upper()
        except (httpx.HTTPError, KeyError):
            pass

        return " ".join(tokens), transformacoes

    async def health_check(self) -> bool:
        """Verifica se a API PCAF está respondendo."""
        try:
            response = await self._client.post(
                f"{self._base_url}/pcaf",
                json={"tipos_logradouros": ["RUA"]},
            )
            return response.status_code == 200
        except httpx.HTTPError:
            return False

    @property
    def provider_name(self) -> str:
        return "api"
