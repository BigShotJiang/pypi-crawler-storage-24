"""Regras por entidade (campo) do módulo de abreviações.

Resolve conflitos de tokens ambíguos como BCO (Beco vs Banco)
e fornece predicados posicionais consultados pelo expander.
"""

from __future__ import annotations


class EntityRules:
    """Predicados de regras por campo consultados pelo expander antes da expansão."""

    @staticmethod
    def is_prefix_position(field: str, position: int) -> bool:
        """Apenas logradouro tem posição de prefixo relevante para tipo de via."""
        return field == "logradouro" and position == 0

    @staticmethod
    def can_use_l2(field: str, position: int) -> bool:
        """Probabilístico (L2 Caller) apenas para prefixo de logradouro."""
        return field == "logradouro" and position == 0

    @staticmethod
    def resolve_bco(field: str, position: int) -> str:
        """Resolve ambiguidade do token BCO entre BECO e BANCO.

        BCO em logradouro posição 0 → BECO (tipo de via)
        BCO em logradouro posição > 0 → BANCO (nome próprio)
        BCO em bairro → BANCO
        """
        if field == "logradouro" and position == 0:
            return "BECO"
        return "BANCO"
