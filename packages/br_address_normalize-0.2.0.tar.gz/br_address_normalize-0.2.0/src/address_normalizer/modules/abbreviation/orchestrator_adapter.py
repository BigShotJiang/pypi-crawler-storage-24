"""Adapter que expõe o AddressExpander como AbbreviationProvider.

Permite integrar o sistema avançado de abreviações (gates, flags, logs)
na pipeline principal sem alterar a interface AbbreviationProvider.
"""

from address_normalizer.modules.abbreviation.base import AbbreviationProvider
from address_normalizer.modules.abbreviation.orchestrator import AddressExpander


class OrchestratorAdapter(AbbreviationProvider):
    """Adapter que traduz a interface AbbreviationProvider para o AddressExpander."""

    def __init__(self, expander: AddressExpander):
        self._expander = expander

    async def expand(self, text: str, field_name: str, context: dict | None = None) -> tuple[str, list[dict]]:
        expanded, transforms, _ = await self._expander.expand_field(text, field_name)

        transformacoes = [
            {
                "campo": t.field,
                "tipo": "abreviacao",
                "de": t.token_original,
                "para": t.token_expanded,
                "regra_aplicada": t.rule_applied,
            }
            for t in transforms
        ]

        return expanded or "", transformacoes

    async def health_check(self) -> bool:
        return True

    @property
    def provider_name(self) -> str:
        return "orchestrator"
