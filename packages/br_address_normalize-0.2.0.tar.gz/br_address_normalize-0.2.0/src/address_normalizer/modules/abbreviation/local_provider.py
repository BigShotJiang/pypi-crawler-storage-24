from pathlib import Path

from address_normalizer.modules.abbreviation.base import AbbreviationProvider
from address_normalizer.data import load_abbreviations_dict


class LocalAbbreviationProvider(AbbreviationProvider):
    """Provider de expansão de abreviações usando dicionário JSON local.

    Carrega o arquivo abbreviations.json e faz lookup direto por token.
    Indicado para desenvolvimento local e quando a API externa não está
    disponível.
    """

    def __init__(self, dict_path: Path | None = None):
        """Inicializa o provider com o dicionário de abreviações.

        Args:
            dict_path: Caminho para o arquivo JSON de abreviações.
                Se None, usa o caminho padrão em dictionaries/abbreviations.json.
        """
        self._abbreviations = load_abbreviations_dict(dict_path)

    async def expand(self, text: str, field_name: str, context: dict | None = None) -> tuple[str, list[dict]]:
        """Expande abreviações token a token usando o dicionário local.

        Para o campo 'logradouro', tenta expandir o primeiro token como tipo
        de logradouro e tokens subsequentes como títulos/modificadores.
        Para outros campos, expande todos os tokens.

        Args:
            text: Texto com possíveis abreviações.
            field_name: Nome do campo sendo processado.
            context: Contexto do endereço (não utilizado no provider local).

        Returns:
            Tupla (texto_expandido, lista_transformações).
        """
        if not text or not text.strip():
            return text, []

        tokens = text.split()
        transformacoes = []
        new_tokens = []

        for token in tokens:
            upper_token = token.upper().rstrip(".,;:")
            if upper_token in self._abbreviations:
                expanded = self._abbreviations[upper_token].upper()
                transformacoes.append({
                    "campo": field_name,
                    "tipo": "abreviacao",
                    "de": token,
                    "para": expanded,
                    "regra_aplicada": "LOCAL_DICT",
                })
                new_tokens.append(expanded)
            else:
                new_tokens.append(token)

        return " ".join(new_tokens), transformacoes

    async def health_check(self) -> bool:
        """Sempre retorna True pois o dicionário é local."""
        return True

    @property
    def provider_name(self) -> str:
        return "local"
