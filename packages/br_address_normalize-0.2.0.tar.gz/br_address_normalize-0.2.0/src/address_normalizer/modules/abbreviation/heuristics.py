"""Validação heurística de resultados da camada L2.

Usa SequenceMatcher para medir similaridade e heurísticas de token (siglas).
"""

from difflib import SequenceMatcher


def calculate_confidence(original: str, expanded: str) -> float:
    """Calcula a confiança (0.0 a 1.0) da transformação do L2 provider."""
    orig = original.upper()
    exp = expanded.upper()

    if not orig or not exp:
        return 0.0

    if orig == exp:
        return 1.0

    ratio = SequenceMatcher(None, orig, exp).ratio()

    if exp.startswith(orig):
        ratio = max(ratio, 0.90)

    if orig in exp:
        ratio = max(ratio, 0.80)

    return ratio
