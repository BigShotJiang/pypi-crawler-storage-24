from abc import ABC, abstractmethod


class AbbreviationProvider(ABC):
    """Interface para providers de expansão de abreviações.

    Implementações concretas podem chamar API externa (ApiAbbreviationProvider)
    ou usar dicionário local (LocalAbbreviationProvider). A escolha é feita
    via configuração ABBREVIATION_PROVIDER no .env.
    """

    @abstractmethod
    async def expand(self, text: str, field_name: str, context: dict | None = None) -> tuple[str, list[dict]]:
        """Expande abreviações no texto fornecido.

        Args:
            text: Texto com possíveis abreviações.
            field_name: Nome do campo ('logradouro', 'bairro', 'complemento').
            context: Endereço completo para desambiguação contextual.

        Returns:
            Tupla (texto_expandido, lista_de_transformacoes).
            Cada transformação: {"de": "R", "para": "Rua", "tipo": "abreviacao"}.
        """
        ...

    @abstractmethod
    async def health_check(self) -> bool:
        """Verifica se o provider está operacional."""
        ...

    @property
    @abstractmethod
    def provider_name(self) -> str:
        """Retorna o nome do provider para metadados."""
        ...
