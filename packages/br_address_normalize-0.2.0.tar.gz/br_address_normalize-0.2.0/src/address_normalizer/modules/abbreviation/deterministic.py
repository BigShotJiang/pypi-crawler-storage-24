"""Camada determinística (L1) de expansão de abreviações.

Expande tokens com certeza >= 1.0, consultando índices por campo
injetados a partir do dicionário unificado e aplicando regras
estáticas posicionais rigorosas.
"""

from __future__ import annotations

import re
from typing import Optional

from address_normalizer.modules.abbreviation.entity_rules import EntityRules
from address_normalizer.modules.abbreviation.models import TokenDecision

# ---------------------------------------------------------------------------
# Padrão: SIGLA+dígito → código interno, preservar
# ---------------------------------------------------------------------------
CODE_PATTERN = re.compile(r"^([A-Z]{1,4})\s*(\d{1,4})\b")

# ---------------------------------------------------------------------------
# Marcadores de sistema — expandidos + flag para o consumidor decidir (GATE 1.5)
# ---------------------------------------------------------------------------
SIGLA_SISTEMA: dict[str, str] = {
    "NI": "NÃO INFORMADO",
    "END": "ENDEREÇO",
}

# ---------------------------------------------------------------------------
# Tokens que NÃO devem ser expandidos em nenhum campo
# ---------------------------------------------------------------------------
DO_NOT_EXPAND: frozenset[str] = frozenset({
    "BH", "CO", "EM", "GB", "JC",
    "LOTE", "MDV", "MR", "RST", "ZONA",
    "CRP", "CID", "MQ",
    # SIGLA_ORGAO — preservar sem expandir
    "ABC", "CEEE", "CTG", "DAER", "DNER", "IBGE",
    "PTB", "SESI", "SHIS", "DF", "KVA",
})

# ---------------------------------------------------------------------------
# Tokens pendentes de amostragem — preservar + flag
# ---------------------------------------------------------------------------
PENDING_SAMPLE: frozenset[str] = frozenset({
    "PRFA", "PRSA", "PS", "PSA",
    "QA", "QC", "RB", "RC", "RDR",
    "RNC", "RR", "RSL", "SC",
    "SPT", "VF", "SRM",
})

# ---------------------------------------------------------------------------
# Grupo ANALISAR — resolução posicional obrigatória
# ---------------------------------------------------------------------------
POSITIONAL_AMBIGUOUS: dict[str, dict] = {
    "CD": {"word": "CONDOMÍNIO", "preserve_if_code": True},
    "CM": {"word": "COMUNIDADE",  "preserve_if_code": True},
    "PA": {"word": "PASSAGEM",    "preserve_if_code": True},
    "LG": {"word": "LARGO",       "preserve_if_code": True},
    "GL": {"word": "GLEBA",       "preserve_if_code": True},
    "BX": {"word": "BAIXADA",     "preserve_if_code": False},
}


class DeterministicLayer:
    """Implementa a Camada L1 O(1) de regras e dicionários."""

    def __init__(
        self,
        field_indices: dict[str, dict[str, str]],
        positional_indices: dict[str, dict[int, dict[str, str]]],
        null_markers: set[str],
        general_dict: dict[str, str] | None = None,
        preserve_unknown_codes: bool = True,
    ):
        self._field_indices = field_indices
        self._positional_indices = positional_indices
        self._null_markers = null_markers
        self._general_dict: dict[str, str] = {
            k.upper(): v.upper() for k, v in (general_dict or {}).items()
        }
        self._preserve_unknown_codes = preserve_unknown_codes

        # Derive tipo_logradouro_full_forms from the injected indices
        full_forms: set[str] = set()
        # Collect from field-generic index for logradouro
        for expansion in self._field_indices.get("logradouro", {}).values():
            full_forms.add(expansion)
        # Collect from all positional entries for logradouro
        for pos_dict in self._positional_indices.get("logradouro", {}).values():
            for expansion in pos_dict.values():
                full_forms.add(expansion)
        self.tipo_logradouro_full_forms: frozenset[str] = frozenset(full_forms)

    def expand_token(
        self,
        token: str,
        next_token: Optional[str],
        field: str,
        position: int,
    ) -> TokenDecision:
        t = token.upper()

        # Guard: token vazio ou puramente numérico
        if not t or t.isdigit():
            return TokenDecision(action="preserve")

        # GATE 1: Nulificar campo (marcadores nulos injetados)
        if t in self._null_markers:
            return TokenDecision(action="remove", rule_applied="REMOVE", source="l1_hardcoded")

        # GATE 1.5: SIGLA_SISTEMA — expandir + flag para o consumidor decidir (NI, END)
        if t in SIGLA_SISTEMA:
            return TokenDecision(
                action="flag_sistema",
                expanded=SIGLA_SISTEMA[t],
                rule_applied="SIGLA_SISTEMA",
                source="l1_hardcoded",
                confidence=1.0,
            )

        # GATE 2: DO_NOT_EXPAND — preservar sem tocar
        if t in DO_NOT_EXPAND:
            return TokenDecision(action="preserve")

        # GATE 3: BCO — resolução posicional especial
        if t == "BCO":
            expanded = EntityRules.resolve_bco(field, position)
            return TokenDecision(
                action="expand",
                expanded=expanded,
                rule_applied="TIPO_LOGRADOURO" if expanded == "BECO" else "TITULO_PROPRIO",
                source="l1_hardcoded",
                confidence=1.0,
            )

        # GATE 4: PENDING_SAMPLE — preservar + flag
        if t in PENDING_SAMPLE:
            return TokenDecision(action="flag_pending", rule_applied="PENDING_SAMPLE")

        # GATE 5: Grupo ANALISAR — resolução posicional
        if t in POSITIONAL_AMBIGUOUS:
            rule = POSITIONAL_AMBIGUOUS[t]
            combined = f"{t} {next_token}" if next_token else t
            if rule["preserve_if_code"] and CODE_PATTERN.match(combined):
                if self._preserve_unknown_codes:
                    return TokenDecision(action="flag_internal", rule_applied="POSITIONAL")
            return TokenDecision(
                action="expand",
                expanded=rule["word"],
                rule_applied="POSITIONAL",
                source="l1_hardcoded",
                confidence=1.0,
            )

        # GATE 6: Lookup from unified indices
        # Resolution order: positional > field generic > (wildcard already merged into field_indices)
        if t != "BCO":
            # Check positional index first (higher precedence)
            pos_dict = self._positional_indices.get(field, {}).get(position, {})
            if t in pos_dict:
                return TokenDecision(
                    action="expand",
                    expanded=pos_dict[t],
                    rule_applied="UNIFIED_DICT",
                    source="l1_hardcoded",
                    confidence=1.0,
                )
            # Check field generic index
            field_dict = self._field_indices.get(field, {})
            if t in field_dict:
                return TokenDecision(
                    action="expand",
                    expanded=field_dict[t],
                    rule_applied="UNIFIED_DICT",
                    source="l1_hardcoded",
                    confidence=1.0,
                )

        # GATE 7: Dicionário Geral (Injetado / Configurado)
        if t in self._general_dict:
            return TokenDecision(
                action="expand",
                expanded=self._general_dict[t],
                rule_applied="GENERAL_DICT",
                source="l1_general_dict",
                confidence=1.0,
            )

        # GATE 8: SIGLA+dígito adjacente → código interno
        if self._preserve_unknown_codes:
            combined = f"{t} {next_token}" if next_token else t
            if CODE_PATTERN.match(t) or CODE_PATTERN.match(combined):
                return TokenDecision(action="flag_internal", rule_applied="INTERNAL_CODE")

        # Sem expansão na L1
        return TokenDecision(action="preserve")
