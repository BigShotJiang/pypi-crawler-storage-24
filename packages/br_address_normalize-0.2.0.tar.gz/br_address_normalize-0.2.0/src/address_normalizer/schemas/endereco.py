from pydantic import BaseModel, Field
from dataclasses import dataclass, field

class TransformacaoAplicada(BaseModel):
    campo: str = Field(..., description="Campo onde a transformação foi aplicada")
    tipo: str = Field(..., description="Tipo da transformação: abreviacao, ortografia, limpeza, encoding")
    de: str = Field(..., description="Valor original antes da transformação")
    para: str = Field(..., description="Valor após a transformação")
    regra_aplicada: str | None = Field(None, description="Regra específica do componente")

class EnderecoInput(BaseModel):
    logradouro: str = ""
    numero: str = ""
    complemento: str = ""
    bairro: str = ""
    municipio: str = ""
    uf: str = ""
    cep: str = ""

@dataclass
class NormalizationResult:
    original: dict = field(default_factory=dict)
    normalizado: dict = field(default_factory=dict)
    transformacoes: list[dict] = field(default_factory=list)
    quality_score: int = 0
    etapas_aplicadas: list[str] = field(default_factory=list)
