from address_normalizer.facade import NormalizerFacade
from address_normalizer.schemas.endereco import EnderecoInput, NormalizationResult

__version__ = "0.1.0"
__all__ = ["NormalizerFacade", "EnderecoInput", "NormalizationResult"]
