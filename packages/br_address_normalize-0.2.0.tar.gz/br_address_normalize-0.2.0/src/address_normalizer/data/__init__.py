import json
from pathlib import Path

DATA_DIR = Path(__file__).parent

_VALID_FIELDS = {"logradouro", "complemento", "bairro", "municipio", "*"}
_ALL_CONCRETE_FIELDS = ("logradouro", "complemento", "bairro", "municipio")


def _load_json(filename: str) -> dict | list:
    """Carrega um arquivo JSON do diretório de dados."""
    with open(DATA_DIR / filename, "r", encoding="utf-8") as f:
        return json.load(f)


def load_unified_abbreviations(path: Path | None = None) -> dict:
    """Carrega o dicionário unificado de abreviações.

    Valida que cada entrada possui 'expansion' (string) e 'contexts' (lista não-vazia).
    Cada contexto deve ter 'field' com valor válido.

    Args:
        path: Caminho para o arquivo JSON. Se None, usa abbreviations_unified.json padrão.

    Returns:
        Dict raw do JSON.

    Raises:
        ValueError: Para entradas malformadas.
    """
    file_path = path or (DATA_DIR / "abbreviations_unified.json")
    with open(file_path, "r", encoding="utf-8") as f:
        raw = json.load(f)

    for key, entries in raw.items():
        for i, entry in enumerate(entries):
            if "expansion" not in entry or not isinstance(entry["expansion"], str):
                raise ValueError(
                    f"Entrada malformada para '{key}' (índice {i}): campo 'expansion' ausente ou inválido"
                )
            if "contexts" not in entry or not isinstance(entry["contexts"], list) or len(entry["contexts"]) == 0:
                raise ValueError(
                    f"Entrada malformada para '{key}' (índice {i}): campo 'contexts' ausente, inválido ou vazio"
                )
            for ctx in entry["contexts"]:
                field = ctx.get("field")
                if field not in _VALID_FIELDS:
                    raise ValueError(
                        f"Entrada malformada para '{key}' (índice {i}): field '{field}' inválido"
                    )
    return raw


def build_field_indices(unified: dict) -> tuple[dict, dict]:
    """Constrói índices O(1) por campo e por posição a partir do dicionário unificado.

    Args:
        unified: Dict raw retornado por load_unified_abbreviations.

    Returns:
        Tupla (field_indices, positional_indices):
        - field_indices: {campo: {abrev: expansão}} para entradas sem restrição posicional
        - positional_indices: {campo: {posição: {abrev: expansão}}} para entradas com posição
    """
    field_indices: dict[str, dict[str, str]] = {f: {} for f in _ALL_CONCRETE_FIELDS}
    positional_indices: dict[str, dict[int, dict[str, str]]] = {f: {} for f in _ALL_CONCRETE_FIELDS}

    for key, entries in unified.items():
        for entry in entries:
            expansion = entry["expansion"]
            for ctx in entry["contexts"]:
                field = ctx["field"]
                position = ctx.get("position")

                if field == "*":
                    # Wildcard: add to all concrete fields
                    if position is not None:
                        for f in _ALL_CONCRETE_FIELDS:
                            positional_indices[f].setdefault(position, {})[key] = expansion
                    else:
                        for f in _ALL_CONCRETE_FIELDS:
                            field_indices[f][key] = expansion
                else:
                    if position is not None:
                        positional_indices[field].setdefault(position, {})[key] = expansion
                    else:
                        field_indices[field][key] = expansion

    return field_indices, positional_indices


def load_abbreviations_dict(path: Path | None = None, upper_values: bool = False) -> dict[str, str]:
    """Carrega o dicionário de abreviações a partir do JSON unificado.

    Constrói um dict flat (chave→expansão) para compatibilidade com
    LocalAbbreviationProvider e ApiAbbreviationProvider.
    Para entradas com múltiplas expansões, usa a primeira entrada sem restrição posicional,
    ou a primeira entrada da lista.

    Args:
        path: Caminho para o arquivo JSON. Se None, usa abbreviations_unified.json padrão.
        upper_values: Se True, converte valores para UPPER. Caso contrário, mantém original.

    Returns:
        Dicionário com chaves em UPPER e valores conforme upper_values.
    """
    file_path = path or (DATA_DIR / "abbreviations_unified.json")
    with open(file_path, "r", encoding="utf-8") as f:
        raw = json.load(f)

    result: dict[str, str] = {}
    for key, entries in raw.items():
        # Prefer entry without positional restriction
        chosen = None
        for entry in entries:
            has_position = any("position" in ctx for ctx in entry["contexts"])
            if not has_position:
                chosen = entry["expansion"]
                break
        if chosen is None:
            chosen = entries[0]["expansion"]

        upper_key = key.upper()
        if upper_values:
            result[upper_key] = chosen.upper()
        else:
            result[upper_key] = chosen

    return result


def load_null_markers() -> set[str]:
    """Carrega marcadores nulos."""
    return set(_load_json("null_markers.json"))


def load_brasilia_prefixes() -> set[str]:
    """Carrega prefixos de Brasília para expansão contextual."""
    return set(_load_json("brasilia_prefixes.json"))
