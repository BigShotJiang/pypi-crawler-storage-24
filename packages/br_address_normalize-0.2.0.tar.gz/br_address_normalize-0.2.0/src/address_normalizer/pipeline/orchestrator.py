"""Pipeline principal de normalização de endereços."""

from address_normalizer.core.base import PipelineStep
from address_normalizer.schemas.endereco import NormalizationResult


class Pipeline:
    """Executa steps sequencialmente e acumula transformações."""

    def __init__(self, steps: list[PipelineStep]):
        self._steps = steps

    async def normalize(self, endereco: dict) -> NormalizationResult:
        original = {k: v for k, v in endereco.items()}
        data = dict(endereco)
        context: dict = {}
        all_transforms: list[dict] = []
        etapas: list[str] = []

        for step in self._steps:
            if not step.should_run(data, context):
                continue
            data, transforms = await step.process(data, context)
            if transforms:
                all_transforms.extend(transforms)
            etapas.append(step.name())

        return NormalizationResult(
            original=original,
            normalizado=data,
            transformacoes=all_transforms,
            quality_score=0,
            etapas_aplicadas=etapas,
        )
