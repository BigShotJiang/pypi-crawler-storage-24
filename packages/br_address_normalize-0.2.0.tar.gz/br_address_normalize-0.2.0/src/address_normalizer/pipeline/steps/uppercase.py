from address_normalizer.core.base import PipelineStep


class UppercaseStep(PipelineStep):
    """Converte todos os campos de texto para UPPERCASE.
    
    Deve ser executado primeiro para garantir que abreviações
    sejam identificadas corretamente nas etapas seguintes.
    """

    def name(self) -> str:
        return "uppercase"

    async def process(self, data: dict, context: dict) -> tuple[dict, list[dict]]:
        transformacoes = []
        campos_texto = ("logradouro", "numero", "complemento", "bairro", "municipio", "uf")
        
        for campo in campos_texto:
            original = str(data.get(campo, "") or "").strip()
            upper = original.upper()
            if upper != original:
                transformacoes.append({
                    "campo": campo,
                    "tipo": "uppercase",
                    "de": original,
                    "para": upper,
                })
            data[campo] = upper
        
        return data, transformacoes
