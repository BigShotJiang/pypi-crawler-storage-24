from address_normalizer.core.base import PipelineStep
from address_normalizer.modules.encoding import aplicar_correcao_encoding

class EncodingStep(PipelineStep):
    def name(self) -> str:
        return "encoding_fix"

    async def process(self, data: dict, context: dict) -> tuple[dict, list[dict]]:
        transformacoes = []
        for campo in ("logradouro", "complemento", "bairro"):
            valor = data.get(campo, "")
            if valor and valor.strip():
                corrigido, transforms = aplicar_correcao_encoding(valor.upper())
                if transforms:
                    for t in transforms:
                        t["campo"] = campo
                    data[campo] = corrigido
                    transformacoes.extend(transforms)
        return data, transformacoes
