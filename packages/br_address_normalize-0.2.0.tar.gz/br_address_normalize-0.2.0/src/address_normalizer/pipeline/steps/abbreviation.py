from address_normalizer.core.base import PipelineStep
from address_normalizer.modules.abbreviation.base import AbbreviationProvider

class AbbreviationStep(PipelineStep):
    def __init__(self, provider: AbbreviationProvider):
        self.provider = provider

    def name(self) -> str:
        return "abreviacao"

    async def process(self, data: dict, context: dict) -> tuple[dict, list[dict]]:
        transformacoes = []
        for campo in ("logradouro", "complemento", "bairro"):
            if data.get(campo):
                expanded, transforms = await self.provider.expand(
                    data[campo], campo, context=data
                )
                data[campo] = expanded
                transformacoes.extend(transforms)
        return data, transformacoes
