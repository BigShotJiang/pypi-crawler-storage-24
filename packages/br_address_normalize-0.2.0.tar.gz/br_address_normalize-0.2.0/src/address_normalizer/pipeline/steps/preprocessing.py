from address_normalizer.core.base import PipelineStep
from address_normalizer.modules.preprocessing import Preprocessor


class PreprocessingStep(PipelineStep):
    def __init__(self, *, separar_numero_logradouro: bool = False):
        self.preprocessor = Preprocessor(separar_numero_logradouro=separar_numero_logradouro)

    def name(self) -> str:
        return "limpeza"

    async def process(self, data: dict, context: dict) -> tuple[dict, list[dict]]:
        preprocess_results = self.preprocessor.process(data)
        current = {campo: res.valor for campo, res in preprocess_results.items()}
        transformacoes = []
        for res in preprocess_results.values():
            transformacoes.extend(res.transformacoes)

        # Propagar flag de CEP inválido
        cep_res = preprocess_results.get("cep")
        if cep_res and cep_res.cep_invalido:
            current["cep_invalido"] = True

        return current, transformacoes
