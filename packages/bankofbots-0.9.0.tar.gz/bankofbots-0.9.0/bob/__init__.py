"""Bank of Bots Python SDK."""

from .client import BoBClient
from .exceptions import AuthenticationError, BoBError, ForbiddenError, NotFoundError
from .types import (
    APIKeyRecord,
    Agent,
    AgentCreditResponse,
    CreditEvent,
    HistoricalPaymentProofImport,
    InboxEvent,
    ProofCreditOutcome,
    WebhookSubscriber,
)

__all__ = [
    "BoBClient",
    "APIKeyRecord",
    "Agent",
    "AgentCreditResponse",
    "CreditEvent",
    "HistoricalPaymentProofImport",
    "InboxEvent",
    "ProofCreditOutcome",
    "WebhookSubscriber",
    "BoBError",
    "AuthenticationError",
    "ForbiddenError",
    "NotFoundError",
]
