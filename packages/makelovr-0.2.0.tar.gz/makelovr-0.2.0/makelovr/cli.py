import argparse
from concurrent.futures import ThreadPoolExecutor
from shutil import rmtree

from .core.config import load_config
from .core.util import init_project
from .targets.linux import build_linux
from .targets.macos import build_macos
from .targets.windows import build_windows


def main():
    parser = argparse.ArgumentParser(prog="makelovr")

    sub = parser.add_subparsers(dest="cmd")

    sub.add_parser("init")
    sub.add_parser("build")
    sub.add_parser("run")
    sub.add_parser("clean")

    args = parser.parse_args()

    if args.cmd == "init":
        init_project()
        return
    elif args.cmd == "run":
        import subprocess

        subprocess.run(["lovr", "."])
        return
    elif args.cmd == "clean":
        rmtree("build")
        return

    config = load_config("makelovr.toml")
    targets = []

    if "win64" in config["default_targets"]:
        targets.append(lambda: build_windows(config))

    if "linux" in config["default_targets"]:
        targets.append(lambda: build_linux(config))

    if "macos" in config["default_targets"]:
        targets.append(lambda: build_macos(config))

    with ThreadPoolExecutor() as pool:
        pool.map(lambda f: f(), targets)
