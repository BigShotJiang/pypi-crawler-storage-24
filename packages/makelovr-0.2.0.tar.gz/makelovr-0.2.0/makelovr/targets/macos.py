import os
import shutil
import zipfile

from ..core.archive import make_lovr
from ..core.downloader import download_lovr


def build_macos(config):

    build = config["build_directory"]
    name = config["name"]
    version = config["lovr_version"]

    os.makedirs(build, exist_ok=True)

    lovr_archive = f"{build}/{name}.lovr"
    make_lovr(".", lovr_archive)

    engine_dir = f"{build}/engine-mac"
    download_lovr(version, "macos", engine_dir)

    app = os.path.join(engine_dir, "lovr.app")

    resources = os.path.join(app, "Contents", "Resources")

    shutil.copy(lovr_archive, os.path.join(resources, f"{name}.lovr"))

    new_app = os.path.join(build, f"{name}.app")

    shutil.move(app, new_app)

    zip_path = os.path.join(build, f"{name}.app.zip")

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:

        for root, _, files in os.walk(new_app):

            for f in files:

                full = os.path.join(root, f)
                rel = os.path.relpath(full, build)

                z.write(full, rel)

    shutil.rmtree(engine_dir)
    shutil.rmtree(new_app)

    print("macOS archive:", zip_path)
