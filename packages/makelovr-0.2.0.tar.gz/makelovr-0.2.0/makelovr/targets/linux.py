import importlib.resources as resources
import os
import shutil
import subprocess

from ..core.archive import make_lovr
from ..core.downloader import download_lovr


def build_linux(config):

    build = config["build_directory"]
    name = config["name"]
    version = config["lovr_version"]

    os.makedirs(build, exist_ok=True)

    lovr_archive = os.path.join(build, f"{name}.lovr")
    make_lovr(".", lovr_archive)

    engine_dir = os.path.join(build, "engine-linux")
    download_lovr(version, "linux", engine_dir)

    runtime_dir = os.path.join(build, "runtime")
    os.makedirs(runtime_dir, exist_ok=True)

    appimage = next(f for f in os.listdir(engine_dir) if f.endswith(".AppImage"))

    subprocess.run(
        ["bash", "-c", f"cd {engine_dir} && ./{appimage} --appimage-extract"],
        check=True,
    )

    squash = os.path.join(engine_dir, "squashfs-root")

    shutil.copytree(
        os.path.join(squash, "usr", "bin"),
        runtime_dir,
        dirs_exist_ok=True,
    )

    shutil.copytree(
        os.path.join(squash, "usr", "lib"),
        os.path.join(runtime_dir, "lib"),
        dirs_exist_ok=True,
    )

    fuse = resources.files("makelovr.runtime") / "fuse"
    stub = resources.files("makelovr.runtime") / "lovr_fused"

    out = os.path.join(build, f"{name}-x86_64")

    subprocess.run(
        [
            str(fuse),
            "--stub",
            str(stub),
            "--runtime",
            runtime_dir,
            "--game",
            lovr_archive,
            "--out",
            out,
        ],
        check=True,
    )

    os.chmod(out, 0o755)

    shutil.rmtree(engine_dir)
    shutil.rmtree(runtime_dir)

    print("Linux fused executable:", out)
