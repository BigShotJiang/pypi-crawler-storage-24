import os
import shutil
import zipfile

from ..core.archive import make_lovr
from ..core.downloader import download_lovr


def build_windows(config):

    build = config["build_directory"]
    name = config["name"]
    version = config["lovr_version"]

    os.makedirs(build, exist_ok=True)

    lovr_archive = f"{build}/{name}.lovr"
    make_lovr(".", lovr_archive)

    engine_dir = f"{build}/engine-win"
    download_lovr(version, "win64", engine_dir)

    exe = os.path.join(engine_dir, "lovr.exe")
    game_exe = os.path.join(engine_dir, f"{name}.exe")

    with open(game_exe, "wb") as w:
        w.write(open(exe, "rb").read())
        w.write(open(lovr_archive, "rb").read())

    zip_path = os.path.join(build, f"{name}-win64.zip")

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:

        for file in os.listdir(engine_dir):

            full = os.path.join(engine_dir, file)

            if file == "lovr.exe":
                continue

            if file.endswith(".exe"):
                z.write(full, f"{name}.exe")
            else:
                z.write(full, file)

    shutil.rmtree(engine_dir)

    print("Windows archive:", zip_path)
