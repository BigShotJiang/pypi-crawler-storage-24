"""Tests for `doccmd`."""
