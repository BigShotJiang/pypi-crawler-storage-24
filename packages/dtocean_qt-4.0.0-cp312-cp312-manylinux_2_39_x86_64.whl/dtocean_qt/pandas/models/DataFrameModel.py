# -*- coding: utf-8 -*-
"""Easy integration of DataFrame into pyqt framework

.. moduleauthor:: Jev Kuznetsov - Datalyze Solutions
.. moduleauthor:: Matthias Ludwig - Datalyze Solutions
.. moduleauthor:: Mathew Topper <mathew.topper@dataonlygreater.com>
"""

from enum import Enum
from typing import cast

import numpy
import pandas
from PySide6 import QtGui
from PySide6.QtCore import (
    QAbstractTableModel,
    QDateTime,
    QModelIndex,
    Qt,
    Signal,
    Slot,
)

from ..models.ColumnDtypeModel import ColumnDtypeModel
from ..models.DataSearch import DataSearch
from ..models.SupportedDtypes import SupportedDtypes

DATAFRAME_ROLE = Qt.ItemDataRole.UserRole + 2


class DataFrameModel(QAbstractTableModel):
    """data model for use in QTableView, QListView, QComboBox, etc.

    Attributes:
        timestampFormat (unicode): formatting string for conversion of timestamps to QtCore.QDateTime.
            Used in data method.
        sortingAboutToStart (QtCore.pyqtSignal): emitted directly before sorting starts.
        sortingFinished (QtCore.pyqtSignal): emitted, when sorting finished.
        dtypeChanged (Signal(columnName)): passed from related ColumnDtypeModel
            if a columns dtype has changed.
        changingDtypeFailed (Signal(columnName, index, dtype)):
            passed from related ColumnDtypeModel.
            emitted after a column has changed it's data type.
        dataChanged (Signal):
            Emitted, if data has changed, e.x. finished loading, new columns added or removed.
            It's not the same as layoutChanged.
            Usefull to reset delegates in the view.
    """

    _float_precisions = {
        "float16": numpy.finfo(numpy.float16).precision - 2,
        "float32": numpy.finfo(numpy.float32).precision - 1,
        "float64": numpy.finfo(numpy.float64).precision - 1,
    }

    """list of int datatypes for easy checking in data() and setData()"""
    _intDtypes = SupportedDtypes.intTypes() + SupportedDtypes.uintTypes()
    """list of float datatypes for easy checking in data() and setData()"""
    _floatDtypes = SupportedDtypes.floatTypes()
    """list of bool datatypes for easy checking in data() and setData()"""
    _boolDtypes = SupportedDtypes.boolTypes()
    """list of datetime datatypes for easy checking in data() and setData()"""
    _dateDtypes = SupportedDtypes.datetimeTypes()

    _timestampFormat = Qt.DateFormat.ISODate

    # Number of rows to display per fetch
    _row_batch_count = 100

    sortingAboutToStart = Signal()
    sortingFinished = Signal()
    dtypeChanged = Signal(int, object)
    changingDtypeFailed = Signal(object, QModelIndex, object)
    dataChanged = Signal()
    dataFrameChanged = Signal()

    def __init__(self, dataFrame=None, copyDataFrame=False):
        """the __init__ method.

        Args:
            dataFrame (pandas.DataFrame, optional): initializes the model with given DataFrame.
                If none is given an empty DataFrame will be set. defaults to None.
            copyDataFrame (bool, optional): create a copy of dataFrame or use it as is. defaults to False.
                If you use it as is, you can change it from outside otherwise you have to reset the dataFrame
                after external changes.

        Attributes:
            freeze_first (bool, optional): Do not allow the first column to be
                modified after initialisation.

        """
        super(DataFrameModel, self).__init__()

        self._dataFrame = pandas.DataFrame()
        if dataFrame is not None:
            self.setDataFrame(dataFrame, copyDataFrame=copyDataFrame)
        self.dataChanged.emit()

        self._dataFrameOriginal = None
        self._search = DataSearch("nothing", "")
        self.editable = False
        self.freeze_first = False

        self.rowsLoaded = DataFrameModel._row_batch_count

        return

    def dataFrame(self):
        """getter function to _dataFrame. Holds all data.

        Note:
            It's not implemented with python properties to keep Qt conventions.

        """
        return self._dataFrame

    def setDataFrame(self, dataFrame, copyDataFrame=False):
        """setter function to _dataFrame. Holds all data.

        Note:
            It's not implemented with python properties to keep Qt conventions.

        Raises:
            TypeError: if dataFrame is not of type pandas.DataFrame.

        Args:
            dataFrame (pandas.DataFrame): assign dataFrame to _dataFrame. Holds all the data displayed.
            copyDataFrame (bool, optional): create a copy of dataFrame or use it as is. defaults to False.
                If you use it as is, you can change it from outside otherwise you have to reset the dataFrame
                after external changes.

        """
        if not isinstance(dataFrame, pandas.DataFrame):
            raise TypeError("not of type pandas.DataFrame")

        self.layoutAboutToBeChanged.emit()
        if copyDataFrame:
            self._dataFrame = dataFrame.copy()
        else:
            self._dataFrame = dataFrame

        self._columnDtypeModel = ColumnDtypeModel(dataFrame)
        self._columnDtypeModel.dtypeChanged.connect(self.propagateDtypeChanges)
        self._columnDtypeModel.changeFailed.connect(
            lambda columnName, index, dtype: self.changingDtypeFailed.emit(
                columnName, index, dtype
            )
        )
        self.layoutChanged.emit()
        self.dataChanged.emit()
        self.dataFrameChanged.emit()

    @Slot(int, object)
    def propagateDtypeChanges(self, column, dtype):
        self.dtypeChanged.emit(column, dtype)

    @property
    def timestampFormat(self):
        """getter to _timestampFormat"""
        return self._timestampFormat

    @timestampFormat.setter
    def timestampFormat(self, timestampFormat):
        """setter to _timestampFormat. Formatting string for conversion of timestamps to QtCore.QDateTime

        Raises:
            AssertionError: if timestampFormat is not str.

        Args:
            timestampFormat (str): assign timestampFormat to _timestampFormat.
                Formatting string for conversion of timestamps to QtCore.QDateTime. Used in data method.

        """
        if not isinstance(timestampFormat, str):
            raise TypeError("timestampFormat must be a string")

        self._timestampFormat = timestampFormat

    def headerData(
        self, section, orientation, role=Qt.ItemDataRole.DisplayRole
    ):
        """return the header depending on section, orientation and Qt::ItemDataRole

        Args:
            section (int): For horizontal headers, the section number corresponds to the column number.
                Similarly, for vertical headers, the section number corresponds to the row number.
            orientation (Qt::Orientations):
            role (Qt::ItemDataRole):

        Returns:
            None if not Qt.ItemDataRole.DisplayRole
            _dataFrame.columns.tolist()[section] if orientation == Qt.Horizontal
            section if orientation == Qt.Vertical
            None if horizontal orientation and section raises IndexError
        """
        if role != Qt.ItemDataRole.DisplayRole:
            return None

        if orientation == Qt.Orientation.Horizontal:
            try:
                label = self._dataFrame.columns.tolist()[section]
                if label == section:
                    label = section
                return label
            except (IndexError,):
                return None
        elif orientation == Qt.Orientation.Vertical:
            return section

    def data(self, index, role=Qt.ItemDataRole.DisplayRole):
        """return data depending on index, Qt::ItemDataRole and data type of the column.

        Args:
            index (QtCore.QModelIndex): Index to define column and row you want to return
            role (Qt::ItemDataRole): Define which data you want to return.

        Returns:
            None if index is invalid
            None if role is none of: DisplayRole, EditRole, CheckStateRole, DATAFRAME_ROLE

            if role DisplayRole:
                unmodified _dataFrame value if column dtype is object (string or unicode).
                _dataFrame value as int or long if column dtype is in _intDtypes.
                _dataFrame value as float if column dtype is in _floatDtypes. Rounds to defined precision (look at: _float16_precision, _float32_precision).
                None if column dtype is in _boolDtypes.
                QDateTime if column dtype is numpy.timestamp64[ns]. Uses timestampFormat as conversion template.

            if role EditRole:
                unmodified _dataFrame value if column dtype is object (string or unicode).
                _dataFrame value as int or long if column dtype is in _intDtypes.
                _dataFrame value as float if column dtype is in _floatDtypes. Rounds to defined precision (look at: _float16_precision, _float32_precision).
                _dataFrame value as bool if column dtype is in _boolDtypes.
                QDateTime if column dtype is numpy.timestamp64[ns]. Uses timestampFormat as conversion template.

            if role CheckStateRole:
                Qt.Checked or Qt.Unchecked if dtype is numpy.bool_ otherwise None for all other dtypes.

            if role DATAFRAME_ROLE:
                unmodified _dataFrame value.

            raises TypeError if an unhandled dtype is found in column.
        """

        if not index.isValid():
            return None

        def convertValue(row, col, columnDtype):
            value = None
            if columnDtype is numpy.dtype(
                object
            ) or pandas.api.types.is_string_dtype(columnDtype):
                value = self._dataFrame.iloc[row, col]
            elif columnDtype in self._floatDtypes:
                to_convert = cast(float, self._dataFrame.iloc[row, col])
                value = round(
                    float(to_convert), self._float_precisions[str(columnDtype)]
                )
            elif columnDtype in self._intDtypes:
                to_convert = cast(int, self._dataFrame.iloc[row, col])
                value = int(to_convert)
            elif columnDtype in self._boolDtypes:
                # TODO this will most likely always be true
                # See: http://stackoverflow.com/a/715455
                # well no: I am mistaken here, the data is already in the dataframe
                # so its already converted to a bool
                value = bool(self._dataFrame.iloc[row, col])

            elif columnDtype in self._dateDtypes:
                # print numpy.datetime64(self._dataFrame.ix[row, col])
                to_convert = cast(
                    numpy.datetime64, self._dataFrame.iloc[row, col]
                )
                value = pandas.Timestamp(to_convert)
                value = QDateTime.fromString(str(value), self.timestampFormat)
                # print value
            # else:
            #     raise TypeError, "returning unhandled data type"
            return value

        rowi = index.row()
        coli = index.column()

        columnDtype = self._dataFrame.dtypes.iloc[coli]

        if role == Qt.ItemDataRole.DisplayRole:
            # return the value if you wanne show True/False as text
            if columnDtype == numpy.bool_:
                result = self._dataFrame.iloc[rowi, coli]
            else:
                result = convertValue(rowi, coli, columnDtype)
        elif role == Qt.ItemDataRole.EditRole:
            result = convertValue(rowi, coli, columnDtype)
        elif role == Qt.ItemDataRole.CheckStateRole:
            if columnDtype == numpy.bool_:
                if convertValue(rowi, coli, columnDtype):
                    result = Qt.CheckState.Checked
                else:
                    result = Qt.CheckState.Unchecked
            else:
                result = None
        elif role == DATAFRAME_ROLE:
            result = self._dataFrame.iloc[rowi, coli]
        elif role == Qt.ItemDataRole.BackgroundRole:
            if self.freeze_first and coli == 0:
                return QtGui.QBrush(Qt.GlobalColor.lightGray)
            else:
                return QtGui.QBrush(Qt.GlobalColor.white)
        elif role == Qt.ItemDataRole.FontRole:
            if self.freeze_first and coli == 0:
                font = QtGui.QFont()
                font.setBold(True)
                return font
            else:
                return QtGui.QFont
        elif role == Qt.ItemDataRole.TextAlignmentRole:
            if self.freeze_first and coli == 0:
                return Qt.AlignmentFlag.AlignCenter
            else:
                return (
                    Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter
                )
        else:
            result = None

        return result

    def flags(self, index):
        """Returns the item flags for the given index as ored value, e.x.: Qt.ItemIsUserCheckable | Qt.ItemIsEditable

        If a combobox for bool values should pop up ItemIsEditable have to set for bool columns too.

        Args:
            index (QtCore.QModelIndex): Index to define column and row

        Returns:
            if column dtype is not boolean Qt.ItemIsSelectable | Qt.ItemIsEnabled | Qt.ItemIsEditable
            if column dtype is boolean Qt.ItemIsSelectable | Qt.ItemIsEnabled | Qt.ItemIsUserCheckable
        """
        flags = super(DataFrameModel, self).flags(index)

        if not self.editable or (self.freeze_first and index.column() == 0):
            return flags

        columnDtype = self._dataFrame.dtypes.iloc[index.column()]
        if columnDtype == numpy.bool_:
            flags |= Qt.ItemFlag.ItemIsUserCheckable
        else:
            # if you want to have a combobox for bool columns set this
            flags |= Qt.ItemFlag.ItemIsEditable

        return flags

    def setData(
        self,
        index: QModelIndex,
        value,
        role: Qt.ItemDataRole = Qt.ItemDataRole.DisplayRole,
    ):
        """Set the value to the index position depending on Qt::ItemDataRole and data type of the column

        Args:
            index (QtCore.QModelIndex): Index to define column and row.
            value (object): new value.
            role (Qt::ItemDataRole): Use this role to specify what you want to do.

        Raises:
            TypeError: If the value could not be converted to a known datatype.

        Returns:
            True if value is changed. Calls layoutChanged after update.
            False if value is not different from original value.

        """
        if not index.isValid() or not self.editable:
            return False

        if value != index.data(role):
            self.layoutAboutToBeChanged.emit()

            row = self._dataFrame.index[index.row()]
            col = self._dataFrame.columns[index.column()]
            columnDtype = self._dataFrame.dtypes.iloc[index.column()]

            if pandas.api.types.is_string_dtype(columnDtype):
                pass

            elif columnDtype in self._intDtypes:
                dtypeInfo = numpy.iinfo(columnDtype)  # type: ignore
                if value < dtypeInfo.min:
                    value = dtypeInfo.min
                elif value > dtypeInfo.max:
                    value = dtypeInfo.max

            elif columnDtype in self._floatDtypes:
                value = numpy.float64(value).astype(columnDtype)  # type: ignore

            elif columnDtype in self._boolDtypes:
                if isinstance(value, Enum):
                    value = bool(value.value)

            elif columnDtype in self._dateDtypes:
                # convert the given value to a compatible datetime object.
                # if the conversation could not be done, keep the original
                # value.
                if isinstance(value, QDateTime):
                    value = value.toString(self.timestampFormat)

                try:
                    value = pandas.to_datetime(str(value))
                except Exception:
                    raise Exception(
                        "Can't convert '{0}' into a datetime".format(value)
                    )
            else:
                raise TypeError("try to set unhandled data type")

            self._dataFrame.at[row, col] = value
            self.layoutChanged.emit()

            return True

        else:
            return False

    def rowCount(self, index=QModelIndex()):
        """returns number of rows

        Args:
            index (QtCore.QModelIndex, optional): Index to define column and row. defaults to empty QModelIndex

        Returns:
            number of rows
        """
        # len(df.index) is faster, so use it:
        # In [12]: %timeit df.shape[0]
        # 1000000 loops, best of 3: 437 ns per loop
        # In [13]: %timeit len(df.index)
        # 10000000 loops, best of 3: 110 ns per loop
        # In [14]: %timeit df.__len__()
        # 1000000 loops, best of 3: 215 ns per loop

        n_rows = len(self._dataFrame.index)

        if n_rows <= self.rowsLoaded:
            return n_rows
        else:
            return self.rowsLoaded

    def canFetchMore(self, index=QModelIndex()):
        n_rows = len(self._dataFrame.index)

        if n_rows > self.rowsLoaded:
            return True
        else:
            return False

    def fetchMore(self, index=QModelIndex()):
        n_rows = len(self._dataFrame.index)

        remainder = n_rows - self.rowsLoaded
        itemsToFetch = min(remainder, DataFrameModel._row_batch_count)

        self.beginInsertRows(
            QModelIndex(),
            self.rowsLoaded,
            self.rowsLoaded + itemsToFetch - 1,
        )

        self.rowsLoaded += itemsToFetch
        self.endInsertRows()

        return

    def columnCount(self, index=QModelIndex()):
        """returns number of columns

        Args:
            index (QtCore.QModelIndex, optional): Index to define column and row. defaults to empty QModelIndex

        Returns:
            number of columns
        """
        # speed comparison:
        # In [23]: %timeit len(df.columns)
        # 10000000 loops, best of 3: 108 ns per loop

        # In [24]: %timeit df.shape[1]
        # 1000000 loops, best of 3: 440 ns per loop
        return len(self._dataFrame.columns)

    def sort(self, columnId, order=Qt.SortOrder.AscendingOrder):
        """sort the model column

        After sorting the data in ascending or descending order, a signal
        `layoutChanged` is emitted.

        Args:
            columnId (int): columnIndex
            order (Qt::SortOrder, optional): descending(1) or ascending(0). defaults to Qt.SortOrder.AscendingOrder

        """
        self.layoutAboutToBeChanged.emit()
        self.sortingAboutToStart.emit()
        column = self._dataFrame.columns[columnId]
        self._dataFrame.sort_values(
            column,
            ascending=not bool(order.value),
            inplace=True,
        )
        self._dataFrame.reset_index(drop=True, inplace=True)
        self.layoutChanged.emit()
        self.sortingFinished.emit()

    def setFilter(self, search):
        """apply a filter and hide rows.

        The filter must be a `DataSearch` object, which evaluates a python
        expression.
        If there was an error while parsing the expression, the data will remain
        unfiltered.

        Args:
            search(dtocean_qt.DataSearch): data search object to use.

        Raises:
            TypeError: An error is raised, if the given parameter is not a
                `DataSearch` object.

        """
        if not isinstance(search, DataSearch):
            raise TypeError(
                "The given parameter must an `dtocean_qt.DataSearch` object"
            )

        self._search = search

        self.layoutAboutToBeChanged.emit()

        if self._dataFrameOriginal is not None:
            self._dataFrame = self._dataFrameOriginal
        self._dataFrameOriginal = self._dataFrame.copy()

        self._search.setDataFrame(self._dataFrame)
        searchIndex, valid = self._search.search()

        if valid:
            self._dataFrame = self._dataFrame[searchIndex]
            self.layoutChanged.emit()
        else:
            self.clearFilter()
            self.layoutChanged.emit()

        self.dataFrameChanged.emit()

    def clearFilter(self):
        """clear all filters."""
        if self._dataFrameOriginal is not None:
            self.layoutAboutToBeChanged.emit()
            self._dataFrame = self._dataFrameOriginal
            self._dataFrameOriginal = None
            self.layoutChanged.emit()

    def columnDtypeModel(self):
        """Getter for a ColumnDtypeModel.

        Returns:
            ColumnDtypeModel
        """
        return self._columnDtypeModel

    def enableEditing(self, editable):
        self.editable = editable
        self._columnDtypeModel.setEditable(self.editable)

    def dataFrameColumns(self):
        return self._dataFrame.columns.tolist()

    def addDataFrameColumn(self, columnName, dtype, defaultValue):
        if not self.editable or dtype not in SupportedDtypes.allTypes():
            return False

        elements = self.rowCount()
        columnPosition = self.columnCount()

        newColumn = pandas.Series(
            [defaultValue] * elements, index=self._dataFrame.index, dtype=dtype
        )

        self.beginInsertColumns(
            QModelIndex(), columnPosition - 1, columnPosition - 1
        )
        try:
            self._dataFrame.insert(
                columnPosition, columnName, newColumn, allow_duplicates=False
            )
        except ValueError:
            # columnName does already exist
            return False

        self.endInsertColumns()
        self.propagateDtypeChanges(columnPosition, newColumn.dtype)

        return True

    def addDataFrameRows(self, count=1):
        # don't allow any gaps in the data rows.
        # and always append at the end

        if not self.editable:
            return False

        position = self.rowCount()

        if count < 1:
            return False

        if len(self.dataFrame().columns) == 0:
            # log an error message or warning
            return False

        # Note: This function emits the rowsAboutToBeInserted() signal which
        # connected views (or proxies) must handle before the data is
        # inserted. Otherwise, the views may end up in an invalid state.
        self.beginInsertRows(QModelIndex(), position, position + count - 1)

        defaultValues = []
        for dtype in self._dataFrame.dtypes:
            if dtype.type in self._dateDtypes:
                val = pandas.Timestamp("")
            elif pandas.api.types.is_string_dtype(dtype.type):
                val = ""
            else:
                val = dtype.type()
            defaultValues.append(val)

        for i in range(count):
            self._dataFrame.loc[position + i] = defaultValues
        self._dataFrame.reset_index()
        self.endInsertRows()
        return True

    def removeDataFrameColumns(self, columns):
        if not self.editable:
            return False

        if columns:
            deleted = 0
            errorOccured = False
            for position, name in columns:
                position = position - deleted
                if position < 0:
                    position = 0
                self.beginRemoveColumns(QModelIndex(), position, position)
                try:
                    self._dataFrame.drop(name, axis=1, inplace=True)
                except KeyError:
                    errorOccured = True
                    continue
                self.endRemoveColumns()
                deleted += 1
            self.dataChanged.emit()

            if errorOccured:
                return False
            else:
                return True
        return False

    def removeDataFrameRows(self, rows):
        if not self.editable:
            return False

        if rows:
            position = min(rows)
            count = len(rows)
            self.beginRemoveRows(QModelIndex(), position, position + count - 1)

            removedAny = False
            for idx, line in self._dataFrame.iterrows():
                if idx in rows:
                    removedAny = True
                    self._dataFrame.drop(idx, inplace=True)

            if not removedAny:
                return False

            self._dataFrame.reset_index(inplace=True, drop=True)

            self.endRemoveRows()
            return True

        return False
