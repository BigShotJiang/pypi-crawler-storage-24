"""mcp-trust-registry — Curated trust registry for MCP servers — reputation scores, security ratings, and community trust signals."""
__version__ = "0.0.1"
