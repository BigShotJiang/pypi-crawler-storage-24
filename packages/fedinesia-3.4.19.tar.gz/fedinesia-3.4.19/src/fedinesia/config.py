"""Helper classes and methods to assist with the general function of this bot.

Fedinesia - deletes old statuses for a fediverse account (Mastodon or Pleroma and forks)
Copyright (C) 2021, 2022, 2023  Mark S Burgunder

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as
published by the Free Software Foundation, either version 3 of the
License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import msgspec
import msgspec.json
import msgspec.toml
from minimal_activitypub import Visibility


class BotConfig(msgspec.Struct):
    """Class holding configuration values for general behaviour of Fedinesia."""

    delete_after: int
    skip_deleting_pinned: bool = False
    skip_deleting_faved: bool = False
    skip_deleting_bookmarked: bool = False
    skip_deleting_poll: bool = False
    skip_deleting_visibility: list[Visibility] = []
    skip_deleting_media: bool = False
    skip_deleting_faved_at_least: int = 0
    skip_deleting_boost_at_least: int = 0
    skip_deleting_reactions_at_least: int = 0


class MastodonConfig(msgspec.Struct):
    """Class holding configuration values for Mastodon settings."""

    instance: str
    access_token: str


class Configuration(msgspec.Struct):
    """Dataclass to hold all settings for fedinesia."""

    bot: BotConfig
    mastodon: MastodonConfig
