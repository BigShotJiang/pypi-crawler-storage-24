"""priorart — Prior art scanner for ideas."""

__version__ = "0.1.1"
