# mansion-api

[![PyPI version](https://badge.fury.io/py/mansion-api.svg)](https://pypi.org/project/mansion-api/)

`mansion-api` provides the core programming interface and environment wrapper for **MANSION**. It features `MansionGym`, a Gymnasium-style environment backed by AI2-THOR. This package enables agents to seamlessly interact with multi-floor buildings using a unified AI2-THOR-style action API.

## Installation

Install `mansion-api` directly from PyPI:

```bash
pip install mansion-api
```

## Quickstart

To get started, you will need to initialize the `MansionGym` environment. Ensure your `building_dir` contains your per-floor scene JSON files formatted as `floor_1.json`, `floor_2.json`, etc.

```python
from mansion_gym.mansion_env import MansionGym

# Initialize the environment
env = MansionGym(
    building_dir="path/to/building", 
    initial_floor=1, 
    max_steps=1000
)

# Reset to get the initial observation
obs, info = env.reset()

```


## Resources & Documentation

For comprehensive information regarding the multi-floor world model, the MansionWorld dataset, and detailed API signatures for skills, please refer to the official documentation:

* 📚 **[MANSION Home](https://agibotgeneral.github.io/mansion-site/)**
* 🛠️ **[API Reference Overview](https://agibotgeneral.github.io/mansion-site/docs/api/overview)**

---

*Copyright © 2026 MANSION contributors.*
