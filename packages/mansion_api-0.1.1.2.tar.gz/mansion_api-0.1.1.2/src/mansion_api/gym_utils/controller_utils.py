# mansion_gym/gym_utils/controller_utils.py

import os
import networkx as nx

from ai2thor.controller import Controller
from ai2thor.hooks.procedural_asset_hook import ProceduralAssetHookRunner

from ..config import OBJATHOR_ASSETS_DIR, LOCAL_AI2THOR_PATH

from .navigation_utils import generate_landmarks, build_room_graph, update_edge_states
from copy import deepcopy


def setup_scene(env, change_floor: bool = False):
    """
    Initializes or updates the AI2-THOR controller + scene for the current floor.
    This is a refactor of the original _set_up_scene method.
    """
    env.cur_json = env.floor_jsons[env.current_floor - 1]
    env.init_info = deepcopy(env.cur_json["metadata"]["agent"])

    if change_floor and env.controller is not None:
        # Just reset with new scene JSON
        env.controller.reset(scene=env.cur_json)
        ch = env.controller.last_event
        print(f"[MansionGym] CreateHouse lastActionSuccess={ch.metadata.get('lastActionSuccess')}, "
              f"error={ch.metadata.get('errorMessage', '')[:120]}")
    else:
        # Fresh controller
        env.controller = Controller(
            renderDepthImage=True,
            renderInstanceSegmentation=True,
            visibilityDistance=10,
            gridSize=0.01,
            width=640,
            height=480,
            fieldOfView=110,
            local_executable_path=LOCAL_AI2THOR_PATH,
            start_unity=True,
            scene="Procedural",
            makeAgentsVisible=False,
            visibilityScheme="Distance",
            action_hook_runner=ProceduralAssetHookRunner(
                asset_directory=OBJATHOR_ASSETS_DIR, asset_symlink=True, verbose=True
            ),
        )
        env.controller.step(
            action="CreateHouse",
            house=env.cur_json,
            raise_for_failure=True,
        )
        env.controller.step(action="Pass", raise_for_failure=True)

    # Landmarks & room graph
    env.landmarks = generate_landmarks(env, env.cur_json)
    print(f"[MansionGym] Extracted {len(env.landmarks)} room landmarks.")

    env.room_graph, env.edge_doors, env.open_space_edges = build_room_graph(env)
    print(f"[MansionGym] Door graph: {len(env.room_graph)} edges.")

    # Build NetworkX graph
    env.graph = nx.Graph()
    env.graph.add_nodes_from(env.landmarks.keys())
    env.graph.add_edges_from(env.room_graph)

    for u, v in env.graph.edges():
        env.graph[u][v]["open"] = 0

    # Initialize open/door states from metadata
    update_edge_states(env)

    print(
        f"[MansionGym] Graph: {env.graph.number_of_nodes()} nodes, "
        f"{env.graph.number_of_edges()} edges."
    )


def reset_scene(env, skip_reset: bool = False):
    """
    Teleport agent to the initial pose of the *current* floor's scene.
    Originally part of MansionGym.reset.
    """
    if not skip_reset:
        env.controller.reset(scene=env.cur_json)

        env.controller.step(
            action="TeleportFull",
            position=env.init_info["position"],
            rotation=env.init_info["rotation"],
            horizon=env.init_info.get("horizon", 0),
            standing=env.init_info.get("standing", True),
            forceAction=True,
            raise_for_failure=True,
        )

    # refresh edges after reset
    update_edge_states(env)
