# mansion_gym/gym_utils/camera_utils.py

import os
import cv2


def capture_landmark_views(env, height_offset=1.0):
    """
    Refactor of MansionGym.capture_landmark_views(self, height_offset)
    """
    print("[MansionGym] Capturing landmark panoramas...")

    room_dir = os.path.join(env.save_dir, "landmarks")
    os.makedirs(room_dir, exist_ok=True)

    for floor_idx, json_floor in enumerate(env.floor_jsons, start=1):
        print(f"[MansionGym] Switching to floor {floor_idx} for panoramas.")
        env.current_floor = floor_idx
        env.cur_json = json_floor

        # Reuse setup_scene to rebuild controller + landmarks/graph
        from .controller_utils import setup_scene
        from .navigation_utils import generate_landmarks

        setup_scene(env, change_floor=True)

        cam_height = env.init_info["position"]["y"] + height_offset
        landmarks = generate_landmarks(env, json_floor)

        for room_name, pos in landmarks.items():
            frames = []

            for yaw in [0, 120, 240]:
                event = env.controller.step(
                    action="AddThirdPartyCamera",
                    position={"x": pos["x"], "y": cam_height, "z": pos["z"]},
                    rotation={"x": 0.0, "y": yaw, "z": 0.0},
                    fieldOfView=120,
                )

                if not event.third_party_camera_frames:
                    print(
                        f"[MansionGym] Warning: No frame for {room_name} on "
                        f"floor {floor_idx} yaw={yaw}"
                    )
                    continue

                frames.append(event.third_party_camera_frames[-1])

            if not frames:
                print(
                    f"[MansionGym] No frames for {room_name} on floor "
                    f"{floor_idx}, skipping."
                )
                continue

            pano = cv2.hconcat(
                [cv2.cvtColor(f, cv2.COLOR_RGB2BGR) for f in frames]
            )
            save_path = os.path.join(room_dir, f"{room_name}_panorama.png")
            cv2.imwrite(save_path, pano)
            print(f"[MansionGym] Saved {save_path}")

    print("[MansionGym] Finished capturing panoramas.")
