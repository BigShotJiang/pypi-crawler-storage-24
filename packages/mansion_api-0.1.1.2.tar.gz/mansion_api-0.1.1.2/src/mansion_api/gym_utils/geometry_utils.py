# mansion_gym/gym_utils/geometry_utils.py

import os
import matplotlib.pyplot as plt

from shapely.geometry import Polygon, LineString
from shapely.ops import unary_union


def get_room_polygons(scene_json):
    """
    Return dict {roomName: shapely.Polygon} for current scene.
    """
    polys = {}
    if "rooms" not in scene_json:
        return polys
    for room in scene_json["rooms"]:
        name = room.get("id", f"Room_{room['id']}")
        polygon = [(p["x"], p["z"]) for p in room["floorPolygon"]]
        if len(polygon) >= 3:
            polys[name] = Polygon(polygon)
    return polys


def get_retracted_dilated_poly(polygon, dilation=0.25, retraction=0.1):
    """
    1. Breaks polygon into edges.
    2. Shortens each edge by `retraction` from both ends.
    3. Dilates the shortened edge by `dilation` with flat caps.
    """
    parts = []

    coords = list(polygon.exterior.coords)
    for i in range(len(coords) - 1):
        p1 = coords[i]
        p2 = coords[i + 1]

        line = LineString([p1, p2])
        length = line.length

        if length <= 2 * retraction:
            continue
        else:
            start_point = line.interpolate(retraction)
            end_point = line.interpolate(length - retraction)
            shortened_line = LineString([start_point, end_point])

        thick_wall = shortened_line.buffer(dilation, cap_style="flat", join_style=2)
        parts.append(thick_wall)

    return unary_union(parts)


def debug_visualize_intersection(
    env,
    r1_name,
    poly1,
    r2_name,
    poly2,
    d1,
    d2,
    intersection,
    scene_walls,
    is_blocked,
):
    """
    Visualizes the intersection check between two rooms.
    Red Fill = Intersection area.
    Black Lines = Walls.
    Title indicates if the connection is valid or blocked by a wall.
    """
    fig, ax = plt.subplots(figsize=(8, 8))

    x, y = poly1.exterior.xy
    ax.plot(x, y, color="blue", linewidth=2, label=f"{r1_name} (Original)")
    x, y = poly2.exterior.xy
    ax.plot(x, y, color="green", linewidth=2, label=f"{r2_name} (Original)")

    x, y = d1.exterior.xy
    ax.plot(x, y, color="blue", linestyle="--", alpha=0.5, label="Dilated")
    x, y = d2.exterior.xy
    ax.plot(x, y, color="green", linestyle="--", alpha=0.5, label="Dilated")

    if not intersection.is_empty:
        geoms = intersection.geoms if hasattr(intersection, "geoms") else [intersection]
        for geom in geoms:
            if geom.geom_type == "Polygon":
                x, y = geom.exterior.xy
                ax.fill(x, y, color="red", alpha=0.5, label="Intersection")

    for wall in scene_walls:
        x, y = wall.xy
        ax.plot(x, y, color="black", linewidth=3)

    status = "BLOCKED BY WALL" if is_blocked else "OPEN CONNECTION"
    ax.set_title(f"{r1_name} vs {r2_name}: {status}")
    ax.legend()
    ax.axis("equal")

    save_path = os.path.join(
        env.save_dir, f"debug_intersect_{r1_name}_{r2_name}.png"
    )
    plt.savefig(save_path)
    plt.close(fig)
    print(f"[Debug] Saved intersection plot to {save_path}")
