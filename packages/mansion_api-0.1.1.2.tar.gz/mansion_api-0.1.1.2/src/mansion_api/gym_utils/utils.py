from math import hypot


def find_object_with_parent(json_objects, target_id, parent=None):
    """
    Recursively search for an object with `id == target_id`.

    Returns:
        (parent_obj, target_obj)
        - parent_obj = the parent object dict, or None if target is top-level
        - target_obj = the object dict with id == target_id, or None if not found
    """
    for obj in json_objects:
        if obj.get("id") == target_id:
            return parent, obj

        # Search in children
        children = obj.get("children", [])
        if children:
            found_parent, found_obj = find_object_with_parent(children, target_id, parent=obj)
            if found_obj:
                return found_parent, found_obj

    return None, None


def ground_distance_2d(pos1, pos2):
    """
    Compute the 2D ground distance between two positions (ignoring y-axis).

    Args:
        pos1 (dict): Position with 'x', 'y', 'z' keys.
        pos2 (dict): Position with 'x', 'y', 'z' keys.

    Returns:
        float: Euclidean distance in the XZ plane.
    """
    return hypot(
        (pos1["x"] - pos2["x"]),
        (pos1["z"] - pos2["z"])
    )
    