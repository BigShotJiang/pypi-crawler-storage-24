from termcolor import colored


def step(env, *, landmark_name=None, **kwargs):
    """
    Teleports the robot to a specified landmark on the same floor.

    The skill checks whether the given landmark name exists in
    `env.landmarks` and whether it lies on the robot’s current floor.
    Cross-floor navigation is disallowed, and the robot must first move to an
    elevator or stairs landmark. If the target is valid, the skill calls
    `env._teleport_to_room`. If the path is blocked by a closed door, the
    robot is teleported to a position facing the door and the skill returns
    failure.

    Args:
        env: The simulation environment containing the robot state and room
            metadata.
        action (dict): Skill invocation containing:
            landmark_name (str): Name of the target landmark/room.

    Returns:
        tuple: `(success, message)` where `success` indicates whether the
        teleportation succeeded, and `message` provides a descriptive status.
    """
    
    print("\n=== GoToLandmarkSkill ===")
    
    if landmark_name not in env.landmarks:
        # TODO: The error message
        return False, "Invalid landmark response."
    
    try:
        landmark_floor = int(landmark_name.split("_")[0].replace("F", ""))
    except (ValueError, IndexError):
        landmark_floor = env.current_floor  # fallback: assume same floor

    print(colored(f"Navigating to landmark: {landmark_name}", "cyan"))
    # Cross-floor navigation is not supported by this skill.
    # The agent must use CallElevator / TakeStairs to change floors first.
    if landmark_floor != env.current_floor:
        msg = (
            f"Target landmark '{landmark_name}' is on floor {landmark_floor}, "
            f"but agent is on floor {env.current_floor}. "
            "Use CallElevator or TakeStairs to change floors first."
        )
        return False, msg

    success, msg = env._teleport_to_room(target_room=landmark_name)

    return success, msg