
def step(env, *, targetfloor=None, **kwargs):
    """
    Moves the elevator to the specified target floor.

    The skill reads the desired floor number from the action parameters and
    calls `env.update_floor` to perform the elevator transition. The
    environment handles validation, including whether the elevator can move
    from the current state and whether the target floor is valid.

    Args:
        env: The simulation environment managing floor transitions and robot
            state.
        action (dict): Skill invocation containing:
            target_floor (int): The floor number the elevator should move to.

    Returns:
        tuple: `(success, message)` where `success` indicates whether the
        elevator moved successfully, and `message` provides a descriptive
        status.
    """
    
    print("\n=== UseElevatorSkill ===")
    
    # pick one name; require at least one
    if targetfloor is None:
        return False, "UseElevator requires targetFloor (int)."

    tf = int(targetfloor)

    success, err_msg = env.update_floor(tf)
    if success:
        return True, f"Elevator moved to floor {tf}."
    return False, err_msg

