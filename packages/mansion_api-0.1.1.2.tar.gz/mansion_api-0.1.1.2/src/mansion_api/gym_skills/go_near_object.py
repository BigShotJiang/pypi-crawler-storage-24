import numpy as np

APPROACH_DIST = 0.4


def _pick_goal_from_reachable(env, obj_pos, approach_dist=0.4):
    # Get reachable positions; fallback to current agent position
    event = env.controller.step("GetReachablePositions")
    agent_pos = env.agent_pos
    pos_list = event.metadata.get("actionReturn", []) if event.metadata["lastActionSuccess"] else []

    if not pos_list:
        return {"x": agent_pos["x"], "y": agent_pos["y"], 
                "z": agent_pos["z"], "yaw": env.agent_rot["y"]}

    # Reference object position (rounded in original)
    op = np.array([round(obj_pos["x"], 2), round(obj_pos["z"], 2)], float)

    # 2) Scoring candidates
    def score(p):
        xz = np.array([
            round(p["x"], 2),
            round(p["z"], 2)
        ], float)
        d_obj = np.linalg.norm(xz - op)
        x_diff = abs(xz[0] - op[0])
        z_diff = abs(xz[1] - op[1])
        return (abs(d_obj - approach_dist), z_diff, x_diff, d_obj)

    # Sorting by score
    best_point = sorted(pos_list, key=score)[0]
    best_x = best_point["x"]
    best_z = best_point["z"]

    # 3) yaw computation
    dx = best_x - op[0]
    dz = best_z - op[1]

    if abs(dx) > abs(dz):     # horizontal alignment
        yaw = 270 if dx > 0 else 90
    else:                     # vertical alignment
        yaw = 180 if dz > 0 else 0


    # If already near enough, keep current position
    if np.linalg.norm((agent_pos["x"] - obj_pos["x"], agent_pos["z"] - obj_pos["z"])) < APPROACH_DIST:
        return {"x": agent_pos["x"], "y": agent_pos["y"], 
                "z": agent_pos["z"], "yaw": env.agent_rot["y"]}

    # Return EXACT rounding and field structure as original
    return {"x": round(best_point["x"], 2),"y": round(best_point["y"], 2),
            "z": round(best_point["z"], 2), "yaw": yaw}


def step(env, *, objectId=None, **kwargs):
    """
    Navigates the robot to a reachable position near a specified object.

    The skill retrieves the object's position from the current observation,
    selects a nearby reachable point using `_pick_goal_from_reachable`, and
    teleports the robot to that point with an automatically chosen yaw that
    aligns toward the object. If the robot is already within the approach
    distance, its current pose is reused. Teleportation is executed through
    AI2-THOR’s `Teleport` action.

    Args:
        env: The simulation environment containing the controller and robot
            state.
        action (dict): Skill invocation containing:
            objectId (str): ID of the target object to approach.

    Returns:
        tuple: `(success, message)` where `success` indicates whether the
        navigation succeeded, and `message` provides a descriptive status.
    """
    
    print("\n=== GoNearObjectSkill ===")
    

    
    obs= env.get_observation()
    obj_meta = next( (o for o in obs.metadata["objects"] if o["objectId"] == objectId), None)
    
    obj_pos = obj_meta["position"]
    
    # usage (replaces desired_goal/snap combo):
    goal_pos = _pick_goal_from_reachable(env, obj_pos, APPROACH_DIST)
    print(f"Goal Position: {goal_pos}")
    

    event= env.controller.step("Teleport",
        position= goal_pos,
        rotation=dict(x=0, y=goal_pos["yaw"], z=0) )
    
   
    if event.metadata["lastActionSuccess"]:
        return True, "Navigation succeeded."
    else:
        return False, f"Navigation failed: {event.metadata.get('errorMessage', '')}"