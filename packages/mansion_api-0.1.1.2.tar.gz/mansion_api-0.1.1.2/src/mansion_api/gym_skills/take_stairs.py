
def step(env, *, direction=None, **kwargs):
    """
    Moves the agent between adjacent floors using stairs.

    Invocation (new wrapper style):
        env.step(action="TakeStairs", direction="up")
        env.step({"action": "TakeStairs", "direction": "down"})

    Args:
        env: The simulation environment managing floor transitions and state.
        direction (str): Required. Either "up" or "down" (case-insensitive).

    Returns:
        tuple: (success, message)
    """

    print("=========== TakeStairsSkill ===========")

    if direction is None:
        return False, "TakeStairs requires direction ('up' or 'down')."

    text_direction = str(direction)

    if text_direction.lower() == "up":
        floor_delta = 1
    elif text_direction.lower() == "down":
        floor_delta = -1
    else:
        return False, f"Invalid direction: {text_direction}. Must be 'up' or 'down'."

    target_floor = env.get_current_floor() + floor_delta
    success, err_msg = env.update_floor(target_floor)

    if success:
        return True, f"Moved {text_direction} to floor {target_floor}."
    else:
        return False, err_msg
