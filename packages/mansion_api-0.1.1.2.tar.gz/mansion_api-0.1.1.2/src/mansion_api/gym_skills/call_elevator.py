import numpy as np

WORKING_DISTANCE = 1.5  # meters


def step(env, *, objectId=None, **kwargs):
    """
    Opens the elevator door and teleports the robot into the elevator room.

    The skill verifies that the robot is within working distance of the
    elevator door, rotates the robot to face the door, and attempts an
    `OpenObject` action. If successful, it identifies the elevator landmark
    for the current floor, computes the appropriate final yaw, and teleports
    the robot to the elevator’s interior position. Rotation toward the door
    is executed only when necessary.

    Args:
        env: The simulation environment containing the controller, robot
            pose, and landmark definitions.
        action (dict): Skill invocation containing:
            objectId (str): ID of the elevator door to interact with.

    Returns:
        tuple: `(success, message)` where `success` indicates whether the
        elevator call and teleportation succeeded, and `message` provides a
        descriptive status.
    """

    print("\n=== CallElevatorSkill ===")

    
    door_id = objectId

    obs= env.get_observation()
    door_meta = next( (o for o in obs.metadata["objects"] if o["objectId"] == door_id), None)
    
    x_center, z_center = door_meta["axisAlignedBoundingBox"]["center"]["x"], door_meta["axisAlignedBoundingBox"]["center"]["z"]
    dx = x_center - env.agent_pos["x"]
    dz = z_center - env.agent_pos["z"]
    distance = np.hypot(dx, dz)

    if distance > WORKING_DISTANCE:
        return False, f"Door is too far ({distance:.2f} m). Move closer before interaction."
    
    # --- 4. Rotate to face the door ---
    
    # Rotate to the cardinal direction that best points TOWARD the door (no overturning)
    if abs(dx) >= abs(dz):
        target_yaw = 90.0 if dx > 0 else 270.0
    else:
        target_yaw = 0.0 if dz > 0 else 180.0

    event= env.controller.step(
        action= "Teleport",
        position= env.agent_pos,
        rotation= dict(x=0, y=target_yaw, z=0),
    )
    
    if not event.metadata["lastActionSuccess"]:
        return False, "Rotation toward door failed."

    event = env.controller.step("OpenObject", objectId=door_id, forceAction=True)
    
    if not event.metadata.get("lastActionSuccess", False):
        return False, f"Door open failed: {event.metadata.get('errorMessage', '')}"
    
    # Teleport to the elevator interior
    elevator_room_pos= env.landmarks[door_meta["room1"]]
    final_yaw= (target_yaw+ 90) % 360
    
    event= env.controller.step(
        action="Teleport",
        position= elevator_room_pos,
        rotation= dict(x=0, y=final_yaw, z=0),
    )
    
    if event.metadata["lastActionSuccess"]:
        return True, "Called the elevator successfully."
    else:
        return False, event.metadata.get("errorMessage", "Teleport to elevator failed.")

