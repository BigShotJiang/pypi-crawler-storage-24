import numpy as np

WORKING_DISTANCE = 1.5  # meters

def step(env, *, objectId=None, skill_name=None, **kwargs):
    """
    Opens or closes a specified door if the robot is within working distance.

    The skill retrieves the door’s metadata, computes the distance from the
    robot to the center of the door’s bounding box, and fails if the robot is
    farther than the working distance. If close enough, the robot rotates to
    face the door by snapping its yaw to the nearest cardinal direction
    pointing toward the door. It then performs either `OpenObject` or
    `CloseObject` depending on the invoked skill name. Door graph states are
    updated after the action.

    Args:
        env: The simulation environment containing controller access and the
            robot’s pose.
        action (dict): Skill invocation containing:
            objectId (str): ID of the door to open or close.

    Returns:
        tuple: `(success, message)` where `success` indicates whether the
        manipulation succeeded, and `message` provides a descriptive status.
    """
    print("\n=== ManipulateDoorSkill ===")
    
    
    door_id = objectId

    obs= env.get_observation()
    door_meta = next( (o for o in obs.metadata["objects"] if o["objectId"] == door_id), None)
    
    x_center, z_center = door_meta["axisAlignedBoundingBox"]["center"]["x"], door_meta["axisAlignedBoundingBox"]["center"]["z"]
    dx = x_center - env.agent_pos["x"]
    dz = z_center - env.agent_pos["z"]
    distance = np.hypot(dx, dz)

    if distance > WORKING_DISTANCE:
        return False, f"Door is too far ({distance:.2f} m). Move closer before interaction."

    # --- 4. Rotate to face the door ---
    
    # Rotate to the cardinal direction that best points TOWARD the door (no overturning)
    if abs(dx) >= abs(dz):
        target_yaw = 90.0 if dx > 0 else 270.0
    else:
        target_yaw = 0.0 if dz > 0 else 180.0

    event= env.controller.step(
        action= "Teleport",
        position= env.agent_pos,
        rotation= dict(x=0, y=target_yaw, z=0),
    )
    
    if not event.metadata["lastActionSuccess"]:
        return False, "Rotation toward door failed."

    # --- 5. Execute open door action ---
    event = env.controller.step("OpenObject" if skill_name== "OpenDoor" else "CloseObject", objectId=door_id, forceAction=False)
    env.update_edge_states()

    if event.metadata["lastActionSuccess"]:
        return True, "Door opened successfully."
    else:
        return False, f"Door open failed: {event.metadata.get('errorMessage', '')}"