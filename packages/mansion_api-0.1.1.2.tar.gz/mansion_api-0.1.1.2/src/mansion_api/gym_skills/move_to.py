import numpy as np

MOVE_LENGTH = 0.3

dir_map = {
        "forward":  np.array([0, 0,  MOVE_LENGTH]),
        "backward": np.array([0, 0, -MOVE_LENGTH]),
        "left":     np.array([-MOVE_LENGTH, 0, 0]),
        "right":    np.array([ MOVE_LENGTH, 0, 0]),
    }

def step(env, *, direction=None, **kwargs):
    f"""
    Moves the robot {MOVE_LENGTH} meters in a specified relative direction.

    Converts a local-frame command ("forward", "backward", "left", "right")
    into a displacement vector, rotates it by the agent’s yaw, and forms an
    intended world-space goal. The skill selects the nearest reachable point
    returned by `GetReachablePositions` and teleports the agent there if it
    lies within a threshold.

    Args:
        env: Simulation environment containing agent pose and controller.
        action (dict): Contains {'move_to': {'direction': str}}.

    Returns:
        (success, message): Whether teleportation succeeded and a message.

    Raises:
        ValueError: If direction is invalid.
    """

    print("=========== MoveToSkill ===========")


    

    if direction not in dir_map:
        raise ValueError(f"Invalid direction: {direction}")

    pos_local = dir_map[direction]

    # --- Current agent pose ---
    pos_map = np.array([env.agent_pos['x'],
                        env.agent_pos['y'],
                        env.agent_pos['z']])
    yaw = np.deg2rad(env.agent_rot['y'])

    # --- Rotation matrix around Y-axis ---
    R_yaw = np.array([
        [ np.cos(yaw), 0, np.sin(yaw)],
        [ 0,           1, 0          ],
        [-np.sin(yaw), 0, np.cos(yaw)]
    ])

    # Intended world-space goal
    goal_pos = pos_map + R_yaw @ pos_local

    # --- Get reachable positions ---
    reachables = env.controller.step(
        action="GetReachablePositions"
    ).metadata["actionReturn"]

    # --- Find closest reachable to intended goal ---
    goal_xz = goal_pos[[0, 2]]
    threshold = 0.3

    if not reachables:
        return False, "No reachable positions returned."

    closest = min(
        reachables,
        key=lambda p: np.linalg.norm(np.array([p["x"], p["z"]]) - goal_xz)
    )
    closest_dist = np.linalg.norm(np.array([closest["x"], closest["z"]]) - goal_xz)

    if closest_dist > threshold:
        return False, "No reachable position near intended goal."

    # Build final (x, y, z)
    final_pos = [
        round(closest["x"], 2),
        round(goal_pos[1], 2),
        round(closest["z"], 2)
    ]

    # --- Teleport ---
    event = env.controller.step(
        action="Teleport",
        position=dict(x=final_pos[0], y=final_pos[1], z=final_pos[2]),
        rotation=dict(x=0, y=env.agent_rot["y"], z=0),
    )

    if event.metadata["lastActionSuccess"]:
        return True, "Move succeeded."
    return False, event.metadata.get("errorMessage", "Move failed.")
