import importlib
import inspect
import logging
import pkgutil
import sys
from types import ModuleType

LOGGER = logging.getLogger(__name__)


def _is_provider(module, obj) -> bool:
    if callable(obj):
        if inspect.isfunction(obj):
            name = obj.__name__
        else:
            name = obj.__class__.__name__

        if name[0].isupper() and (obj.__module__ == module.__name__):
            return True
        else:
            return False
    else:
        return False


def get_calling_module(frames_back=2):  # 2 for this function and find_providers frames
    frame = inspect.currentframe()
    try:
        caller_frame = frame
        for _ in range(frames_back):
            caller_frame = caller_frame.f_back
        module = inspect.getmodule(caller_frame)
        if module is not None:
            return module

        # fallback for repl/notebooks
        module_name = caller_frame.f_globals.get('__name__')
        if module_name and module_name in sys.modules:
            return sys.modules[module_name]

        return None
    finally:
        del frame


def find_providers(module: ModuleType = None, recursive: bool = True):
    if module is None:
        module = get_calling_module()

    providers = []

    if hasattr(module, "__ALL_PROVIDERS__"):
        providers.extend(module.__ALL_PROVIDERS__)
        return providers

    for obj in vars(module).values():
        if _is_provider(module, obj):
            providers.append(obj)

    # Recursive search
    if recursive and hasattr(module, "__path__"):
        for finder, submod_name, ispkg in pkgutil.walk_packages(module.__path__, module.__name__ + "."):
            submod = importlib.import_module(submod_name)
            providers.extend(find_providers(submod, recursive=False))

    return providers
