import logging
import os
import pathlib
import pickle
import shutil
import tempfile
from dataclasses import dataclass
from typing import Any, List, Union, TYPE_CHECKING

# this implicit pickle fallback probably not a great idea, but not really too consequential
try:
    import cloudpickle as pickle_for_providers
    using_cloudpickle = True
except ImportError:
    pickle_for_providers = pickle
    using_cloudpickle = False

if TYPE_CHECKING:
    from darl.constants import ExecutionStatus
    from darl.graph import Graph


LOGGER = logging.getLogger(__name__)


# TODO: should engine_id be added here? probably not since can get it from CacheEntryGraph looked up by graph_build_id
@dataclass
class CacheEntryResultMeta:
    # if everything was always perfectly deterministic wouldn't need graph_build_id or any checks derived from it
    graph_build_id: str
    keep_in_cache: bool
    removed_from_cache: bool


@dataclass
class CacheEntryResult:
    result: Any


@dataclass
class CacheEntryGraph:
    graph: 'Graph'
    engine_id: str

    # custom get/setstate in case provider is removed/moved and cannot be deserialized. this will allow graph to be
    # deserialized still, but replace the provider in node_data dicts with None
    def __getstate__(self):
        self.graph = self.graph.copy()
        providers = {node_id: node_data.pop('provider') for node_id, node_data in self.graph.nodes.items()}
        state = self.__dict__
        try:
            # TODO: make serializer configurable, maybe using cache serializer? but technically serializer should just be an
            #       implementation detail of cache right? and what to do for ThroughCache then where it routes to other caches?
            state['__providers_pickle__'] = pickle_for_providers.dumps(providers)
        except pickle.PicklingError as e:
            if using_cloudpickle:
                LOGGER.warning(f'(CAN IGNORE) Could not serialize providers (try installing cloudpickle for more robust serialization): {e}')
            else:
                LOGGER.warning(f'(CAN IGNORE) Could not serialize providers: {e}')
            state['__providers_pickle__'] = pickle_for_providers.dumps({})
        return state

    def __setstate__(self, state):
        providers_pickle = state.pop('__providers_pickle__')

        # If one provider is not deserializable all providers set to None, just for performance, so we don't have
        # to pickle each provider individually
        try:
            providers = pickle_for_providers.loads(providers_pickle)
        except Exception:
            providers = {}

        for node_id, node_data in state['graph'].nodes.items():
            state['graph'].nodes[node_id]['provider'] = providers.get(node_id)

        self.__dict__.update(state)


@dataclass
class CacheEntryGraphExecutionMeta:  # TODO: add memory info
    duration_sec: float
    status: 'ExecutionStatus'


class Cache:
    def get(self, key: str):
        raise NotImplementedError

    def bulk_get(self, keys: List[str]):
        # things like redis have a better bulk get implementation
        return [self.get(k) for k in keys]

    def set(self, key: str, value: Union['CacheEntryResult', 'CacheEntryResultMeta', 'CacheEntryGraph'], guarantee_atomic=False):
        '''
        guarantee_atomic - guarantee atomicity. only required in some circumstances. in some implementations of cache
                           atomicity can be more expensive
        '''
        raise NotImplementedError

    def contains(self, key: str):
        raise NotImplementedError

    def bulk_contains(self, keys: List[str]):
        # things like redis have a better bulk contains implementation
        return [self.contains(k) for k in keys]

    def delete(self, key):
        # TODO: what should behavior be if key doesn't exist? right now all implementations handle differently...
        raise NotImplementedError

    def purge(self):
        raise NotImplementedError


class DictCache(Cache):
    def __init__(self):
        super().__init__()
        self._cache = {}

    # don't copy entire set local data cache on serialization
    # TODO: should we? I think no
    def __setstate__(self, state):
        self._cache = {}

    def __getstate__(self):
        return {}

    def get(self, key: str):
        return self._cache[key]

    def set(self, key: str, value: Union['CacheEntryResult', 'CacheEntryResultMeta', 'CacheEntryGraph'], guarantee_atomic=False):
        self._cache[key] = value

    def contains(self, key: str):
        return key in self._cache

    def delete(self, key: str):
        del self._cache[key]

    def purge(self):
        self._cache.clear()


def _atomic_write_bytes(path: pathlib.Path, data: bytes):
    path = pathlib.Path(path)
    dir_ = path.parent

    with tempfile.NamedTemporaryFile(
        dir=dir_,
        delete=False
    ) as tmp:
        tmp.write(data)
        tmp.flush()
        os.fsync(tmp.fileno())
        temp_name = tmp.name

    os.replace(temp_name, path)  # atomic


class DiskCache(Cache):
    def __init__(self, path: str = None, serializer=pickle.dumps, deserializer=pickle.loads):
        super().__init__()
        if path is None:
            self.tempdir = tempfile.TemporaryDirectory()
            path = self.tempdir.name
        else:
            self.tempdir = None
        self._path = pathlib.Path(path)
        self._serializer = serializer
        self._deserializer = deserializer

        self._path.mkdir(parents=True, exist_ok=True)
        has_dirs = any(p.is_dir() for p in self._path.iterdir())
        if has_dirs:
            raise ValueError('cannot use a disk cache path that has subdirectories')

    def get(self, key: str):
        path = self._path / f'{key}.data'
        if not path.exists():
            raise KeyError(key)
        return self._deserializer(path.read_bytes())

    def set(self, key: str, value: Union['CacheEntryResult', 'CacheEntryResultMeta', 'CacheEntryGraph'], guarantee_atomic=False):
        path = self._path / f'{key}.data'
        if guarantee_atomic:
            _atomic_write_bytes(path, self._serializer(value))
        else:
            path.write_bytes(self._serializer(value))

    def contains(self, key: str):
        path = self._path / f'{key}.data'
        return path.exists()

    def delete(self, key: str):
        path = self._path / f'{key}.data'
        path.unlink()

    def purge(self):
        shutil.rmtree(self._path, ignore_errors=True)
        self._path.mkdir(parents=True, exist_ok=True)


# TODO: not stdlib so should not be in core?
class RedisCache(Cache):
    def __init__(self, namespace, host='localhost', port=6379,
                 serializer=pickle.dumps, deserializer=pickle.loads):
        import redis

        self.host = host
        self.port = port
        self._r = redis.Redis(host=self.host, port=self.port)
        self.namespace = namespace
        self._serializer = serializer
        self._deserializer = deserializer

    def __setstate__(self, state):
        import redis
        self.__dict__.update(state)
        self._r = redis.Redis(host=self.host, port=self.port)

    def __getstate__(self):
        return {
            'namespace': self.namespace,
            'host': self.host,
            'port': self.port,
            '_serializer': self._serializer,
            '_deserializer': self._deserializer,
        }

    def get(self, key: str):
        key = f'{self.namespace}-{key}'
        return self._deserializer(self._r[key])

    def set(self, key: str, value, guarantee_atomic=False):
        key = f'{self.namespace}-{key}'
        self._r.set(key, self._serializer(value))  # TODO: compress (lz4?)

    def contains(self, key: str):
        # TODO: implement this and bulk_contains properly, currently not efficient
        key = f'{self.namespace}-{key}'
        return key.encode() in self._r.keys()

    def delete(self, key: str):
        key = f'{self.namespace}-{key}'
        self._r.delete(key)

    def purge(self):
        pipe = self._r.pipeline()

        for key in self._r.scan_iter(match=f"{self.namespace}-*"):
            pipe.delete(key)

        pipe.execute()


class ThroughCache(Cache):  # should this be a subclass or protocol or something? don't think it really should be a subclass of Cache
    def __init__(
            self,
            front_cache: Cache,
            back_cache: Cache,
            read_through=True,
            write_through=False,
            copy_on_read=False,
    ):
        self.front = front_cache
        self.back = back_cache
        self.read_through = read_through
        self.write_through = write_through
        self.copy_on_read = copy_on_read

    def get(self, key: str):
        try:
            return self.front.get(key)
        except KeyError:
            if self.read_through:
                ret_val = self.back.get(key)
                if self.copy_on_read:
                    self.front.set(key, ret_val)
                return ret_val
            else:
                raise

    def set(self, key: str, value: Union['CacheEntryResult', 'CacheEntryGraph'], guarantee_atomic=False):
        self.front.set(key, value, guarantee_atomic=guarantee_atomic)
        if self.write_through:
            self.back.set(key, value, guarantee_atomic=guarantee_atomic)

    def contains(self, key: str):
        if self.front.contains(key):
            return True
        else:
            if self.read_through:
                return self.back.contains(key)
            else:
                return False

    def delete(self, key: str):
        raise NotImplementedError('delete behavior in a through cache is ambiguous, delete from individual caches as desired')

    def purge(self):
        raise NotImplementedError('purging behavior in a through cache is ambiguous, purge individual caches as desired')


def _default_size_getter(obj):
    return len(pickle.dumps(obj)) / 1_000_000  # mb


class SpilloverCache(Cache):
    def __init__(self, primary, secondary, threshold_mb, size_getter_in_mb=_default_size_getter):
        self.primary = primary
        self.secondary = secondary
        self.threshold_mb = threshold_mb
        self.size_getter_in_mb = size_getter_in_mb

    def get(self, key: str):
        try:
            return self.primary.get(key)
        except KeyError:
            return self.secondary.get(key)

    def set(self, key: str, value: Union['CacheEntryResult', 'CacheEntryResultMeta', 'CacheEntryGraph'], guarantee_atomic=False):
        size = self.size_getter_in_mb(value)
        if size >= self.threshold_mb:
            self.secondary.set(key, value, guarantee_atomic=guarantee_atomic)
        else:
            self.primary.set(key, value, guarantee_atomic=guarantee_atomic)

    def contains(self, key: str):
        return self.primary.contains(key) or self.secondary.contains(key)

    def delete(self, key: str):
        try:
            self.primary.delete(key)
        except:
            pass

        try:
            self.secondary.delete(key)
        except:
            pass

    def purge(self):
        self.primary.purge()
        self.secondary.purge()
