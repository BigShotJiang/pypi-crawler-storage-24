from graphlib import TopologicalSorter
from typing import TYPE_CHECKING

from darl.cache import Cache, DictCache
from darl.execution.base import Runner, run_node

if TYPE_CHECKING:
    from darl.graph import Graph


class SequentialRunner(Runner):

    def _run(self, graph: 'Graph', cache: 'Cache'):
        order = TopologicalSorter(graph.edges).static_order()
        for node in order:
            run_node(node, graph, cache)

    def default_cache(self):
        return DictCache()
