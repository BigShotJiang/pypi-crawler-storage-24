# 🍬 candy-ai v13

**Pont Python vers Cedric7-Thinking** — 90 personnalités · 20 utilitaires · Helper · CLI · Profils · Conversations

---

## Installation

```bash
pip install candy-ai
```

---

## Les 90 personnalités

### Originales (50)
`Math` `Coding` `Reflexion` `Analytic` `Full` `Science` `Writing` `History`
`Law` `Medicine` `Finance` `Marketing` `Security` `Design` `Language`
`Psychology` `Education` `Research` `Business` `Productivity` `Cooking`
`Travel` `Music` `Film` `Sports` `Philosophy` `Environment` `Architecture`
`Automotive` `Astronomy` `Biology` `Chemistry` `Physics` `Engineering`
`Entrepreneur` `Ethics` `Geopolitics` `Crypto` `AI` `DevOps` `Database`
`GameDev` `Comic` `Storyteller` `Translator` `Summarizer` `Debugger`
`Reviewer` `Planner` `Tutor`

### Nouvelles v13 (40)
`Nutrition` `Yoga` `Mindfulness` `Parenting` `Relationship` `Leadership`
`Negotiation` `PublicSpeak` `Branding` `UXResearch` `DataVis` `MLOps`
`Prompt` `Blockchain` `IoT` `ArVr` `Quantum` `Robotics` `Bioinformatics`
`ClimateTech` `Agri` `Interior` `Fashion` `Photography` `Podcast` `Youtube`
`SocialMedia` `SEO` `Copywriting` `TaxLaw` `RealEstate` `Insurance`
`Logistics` `HRM` `ProjectMgmt` `Consulting` `PublicPolicy` `Journalism`
`SpeechWrite` `Mythology`

---

## Utilisation

```python
from candy import cfg, Nutrition, MLOps, Prompt, Branding

cfg.A.lang       = "FR"
cfg.A.max_tokens = 1500
cfg.A.style      = "detailed"

print(Nutrition.use("A").ask("Plan alimentaire pour un sportif végétarien"))
print(MLOps.use("A").ask("Comment déployer un modèle sklearn avec FastAPI ?"))
print(Prompt.use("A").ask("Optimise ce prompt pour GPT-4 : 'résume ce texte'"))
print(Branding.use("A").ask("Crée une identité de marque pour une startup IA"))
```

---

Propulsé par **Cedric7-Thinking** · Quota 800 req/jour · MIT License
