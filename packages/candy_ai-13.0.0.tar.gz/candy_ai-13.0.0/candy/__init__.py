"""
🍬 candy v12 — Python client for Cedric7-Thinking
20 nouvelles fonctionnalités dans candy.utils
"""

from .banner import show_banner
show_banner()

from .config import config as cfg, get_profile, list_profiles
from .client import CandyClient, CandyUnavailableError, CandyQuotaError, CandyTimeoutError
from .conversation import Conversation
from .helper import Helper
from . import utils
from .utils import (
    detect_lang, translate, summarize, spellcheck, keywords,
    sentiment, generate_title, ask_about, rephrase, generate_faq,
    compare, codegen, explain_code, mock_data, timed_ask,
    cached_ask, clear_cache, optimize_prompt, extract,
    pipeline, full_report
)
from .modules.math import Math
from .modules.reflexion import Reflexion
from .modules.coding import Coding
from .modules.analytic import Analytic
from .modules.full import Full
from .modules.science import Science
from .modules.writing import Writing
from .modules.history import History
from .modules.law import Law
from .modules.medicine import Medicine
from .modules.finance import Finance
from .modules.marketing import Marketing
from .modules.security import Security
from .modules.design import Design
from .modules.language import Language
from .modules.psychology import Psychology
from .modules.education import Education
from .modules.research import Research
from .modules.business import Business
from .modules.productivity import Productivity
from .modules.cooking import Cooking
from .modules.travel import Travel
from .modules.music import Music
from .modules.film import Film
from .modules.sports import Sports
from .modules.philosophy import Philosophy
from .modules.environment import Environment
from .modules.architecture import Architecture
from .modules.automotive import Automotive
from .modules.astronomy import Astronomy
from .modules.biology import Biology
from .modules.chemistry import Chemistry
from .modules.physics import Physics
from .modules.engineering import Engineering
from .modules.entrepreneur import Entrepreneur
from .modules.ethics import Ethics
from .modules.geopolitics import Geopolitics
from .modules.crypto import Crypto
from .modules.ai import AI
from .modules.devops import DevOps
from .modules.database import Database
from .modules.gamedev import GameDev
from .modules.comic import Comic
from .modules.storyteller import Storyteller
from .modules.translator import Translator
from .modules.summarizer import Summarizer
from .modules.debugger import Debugger
from .modules.reviewer import Reviewer
from .modules.planner import Planner
from .modules.tutor import Tutor

__version__ = "13.0.0"
__author__  = "Cedric7-Thinking"

__all__ = [
    "cfg", "get_profile", "list_profiles", "Conversation", "Helper", "utils",
    "CandyClient", "CandyUnavailableError", "CandyQuotaError", "CandyTimeoutError",
    "detect_lang", "translate", "summarize", "spellcheck", "keywords",
    "sentiment", "generate_title", "ask_about", "rephrase", "generate_faq",
    "compare", "codegen", "explain_code", "mock_data", "timed_ask",
    "cached_ask", "clear_cache", "optimize_prompt", "extract",
    "pipeline", "full_report",
    "Math","Reflexion","Coding","Analytic","Full","Science","Writing",
    "History","Law","Medicine","Finance","Marketing","Security","Design",
    "Language","Psychology","Education","Research","Business","Productivity",
    "Cooking","Travel","Music","Film","Sports","Philosophy","Environment",
    "Architecture","Automotive","Astronomy","Biology","Chemistry","Physics",
    "Engineering","Entrepreneur","Ethics","Geopolitics","Crypto","AI","DevOps",
    "Database","GameDev","Comic","Storyteller","Translator","Summarizer",
    "Debugger","Reviewer","Planner","Tutor",
]

# ── 40 nouvelles personnalités v13 ───────────────────────────────────────────
from .modules.nutrition import Nutrition
from .modules.yoga import Yoga
from .modules.mindfulness import Mindfulness
from .modules.parenting import Parenting
from .modules.relationship import Relationship
from .modules.leadership import Leadership
from .modules.negotiation import Negotiation
from .modules.publicspeak import PublicSpeak
from .modules.branding import Branding
from .modules.uxresearch import UXResearch
from .modules.datavis import DataVis
from .modules.mlops import MLOps
from .modules.prompt import Prompt
from .modules.blockchain import Blockchain
from .modules.iot import IoT
from .modules.ar_vr import ArVr
from .modules.quantum import Quantum
from .modules.robotics import Robotics
from .modules.bioinformatics import Bioinformatics
from .modules.climatetech import ClimateTech
from .modules.agri import Agri
from .modules.interior import Interior
from .modules.fashion import Fashion
from .modules.photography import Photography
from .modules.podcast import Podcast
from .modules.youtube import Youtube
from .modules.socialmedia import SocialMedia
from .modules.seo import SEO
from .modules.copywriting import Copywriting
from .modules.taxlaw import TaxLaw
from .modules.realestate import RealEstate
from .modules.insurance import Insurance
from .modules.logistics import Logistics
from .modules.hrm import HRM
from .modules.projectmgmt import ProjectMgmt
from .modules.consulting import Consulting
from .modules.publicpolicy import PublicPolicy
from .modules.journalism import Journalism
from .modules.speechwrite import SpeechWrite
from .modules.mythology import Mythology
