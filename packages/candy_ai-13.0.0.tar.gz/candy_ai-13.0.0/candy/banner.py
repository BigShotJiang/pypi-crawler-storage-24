"""
candy.banner — Bannière ASCII permanente (ne peut pas être désactivée)
"""

import sys

VERSION = "13.0.0"

_BANNER = f"""
\033[95m   ██████╗ █████╗ ███╗   ██╗██████╗ ██╗   ██╗
\033[95m  ██╔════╝██╔══██╗████╗  ██║██╔══██╗╚██╗ ██╔╝
\033[96m  ██║     ███████║██╔██╗ ██║██║  ██║ ╚████╔╝
\033[96m  ██║     ██╔══██║██║╚██╗██║██║  ██║  ╚██╔╝
\033[94m  ╚██████╗██║  ██║██║ ╚████║██████╔╝   ██║
\033[94m   ╚═════╝╚═╝  ╚═╝╚═╝  ╚═══╝╚═════╝    ╚═╝\033[0m
\033[90m  ──────────────────────────────────────────────
\033[97m  ⚡ Cedric7-Thinking Engine  \033[90m│\033[97m  v{VERSION}  \033[90m│\033[97m  90 personalities
\033[90m  ──────────────────────────────────────────────\033[0m
"""

_shown = False

def show_banner():
    global _shown
    if _shown:
        return
    _shown = True
    # Toujours afficher, même hors TTY
    try:
        sys.stdout.write(_BANNER)
        sys.stdout.flush()
    except Exception:
        pass
