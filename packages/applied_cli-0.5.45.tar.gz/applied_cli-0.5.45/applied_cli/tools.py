"""MCP tool implementations using AppliedClient.

These functions wrap the client methods with formatting logic,
suitable for both MCP tools and CLI commands.
"""

import json

from applied_cli.client import AppliedAPIError, AppliedClient
from applied_cli.formatters import select_fields, to_csv, to_json


def _format_error(e: AppliedAPIError) -> str:
    """Format an API error as a readable string for the AI."""
    return f"❌ Error: {e}"


async def agent_list(
    client: AppliedClient,
    output_format: str = "csv",
) -> str:
    """
    List all AI agents in the workspace.

    Args:
        client: Authenticated AppliedClient
        output_format: 'csv' (default, token-efficient) or 'json'

    Returns:
        List of agents with id, name, modality, description
    """
    agents = await client.list_agents()
    mapped = [
        {
            "id": a.get("id"),
            "name": a.get("name"),
            "modality": a.get("modality"),
            "description": a.get("description", ""),
        }
        for a in agents
    ]

    if output_format == "csv":
        return to_csv(mapped, ["id", "name", "modality", "description"])
    return to_json(mapped)


async def taxonomy_list(
    client: AppliedClient,
    taxonomy_type: str = "all",
    output_format: str = "csv",
) -> str:
    """
    List conversation taxonomy: topics, intents, and flags.

    Args:
        client: Authenticated AppliedClient
        taxonomy_type: 'all' (default), 'topics', 'intents', or 'flags'
        output_format: 'csv' or 'json'

    Returns:
        Topics (categories), intents (sub-categories), flags (markers)
    """
    choices = await client.list_taxonomy(taxonomy_type)
    items = [
        {
            "id": c.get("id"),
            "name": c.get("name"),
            "type": (
                "flag"
                if c.get("is_flag")
                else ("intent" if c.get("parent_choice_id") else "topic")
            ),
        }
        for c in choices
    ]

    if output_format == "csv":
        return to_csv(items, ["id", "name", "type"])
    return to_json(items)


async def analytics_query(
    client: AppliedClient,
    group_by: list[str],
    metrics: list[str] | None = None,
    filters: list[str] | None = None,
    start: str | None = None,
    end: str | None = None,
    limit: int | None = None,
    output_format: str = "csv",
) -> str:
    """Run a server-side ClickHouse GROUP BY query on conversation data.

    Dimensions: label_id, label_name, sublabel_id, sublabel_name,
                agent_id, agent_name, resolution, sentiment, score, type, user_id
    Metrics: count, avg_score, avg_ttr, resolution_rate
    Filters: agent_id, label_id, sublabel_id, type, resolution, sentiment, score, user_id
    """
    data = await client.analytics_query(
        group_by=group_by,
        metrics=metrics,
        filters=filters,
        start=start,
        end=end,
        limit=limit,
    )
    rows = data.get("rows", [])
    if not rows:
        return "No data found for the given query."
    if output_format == "json":
        return to_json(data)
    columns = data.get("dimensions", group_by) + data.get(
        "metrics", metrics or ["count"]
    )
    return to_csv(rows, columns)


async def analytics_metrics(
    client: AppliedClient,
    metric_name: str,
    group_by: str | None = None,
    period: str | None = None,
    filters: list[str] | None = None,
    start: str | None = None,
    end: str | None = None,
    object_type: str = "conversation",
    output_format: str = "csv",
) -> str:
    """Query metric events with optional property grouping and trending.

    Use for custom business metrics: cancel reasons, save rates, etc.
    """
    data = await client.analytics_metrics(
        metric_name=metric_name,
        group_by=group_by,
        period=period,
        filters=filters,
        start=start,
        end=end,
        object_type=object_type,
    )
    rows = data.get("rows", [])
    if not rows:
        return "No data found for the given query."
    if output_format == "json":
        return to_json(data)
    columns: list[str] = []
    if group_by:
        columns.append("prop_group")
    if period:
        columns.append("period")
    columns.extend(["event_count", "object_count"])
    return to_csv(rows, columns)


async def conversation_query(
    client: AppliedClient,
    filters: dict | None = None,
    search: str | None = None,
    fields: list[str] | None = None,
    limit: int = 20,
    fetch_all: bool = False,
    shop_id: str | None = None,
    output_format: str = "csv",
) -> str:
    """
    Query conversations with filters and field selection.

    Args:
        client: Authenticated AppliedClient
        filters: Filter conditions, e.g.:
            {"resolution": "escalated"}
            {"resolution": ["escalated", "soft"]}
            {"score": {"gte": 1, "lte": 3}} — CSAT score range
            {"created_at": {"gte": "2024-01-01", "lte": "2024-01-31"}}
            {"sentiment": ["negative", "very_negative"]}
            {"user_id": {"isnull": False}} — assigned to a human
            {"label_id": "<topic-uuid>"} — filter by topic
            {"sublabel_id": "<intent-uuid>"} — filter by intent
            {"flags__in": "<flag-uuid>"} — has specific flag
            {"resolution": {"nin": ["escalated"]}} — exclude escalated
        search: Full-text search across conversation content
        fields: Fields to return, e.g. ["id", "title", "contact.email", "score", "comment"]
        limit: Max results per page (default 20, max 100)
        fetch_all: If True, fetch all pages (use carefully with large datasets)
        output_format: 'csv' or 'json'

    Available fields:
        id, title, summary, score (CSAT 1-5), comment (CSAT feedback),
        resolution, status, type, sentiment, sentiment_score,
        created_at, last_message_at, ttr_seconds, is_one_touch,
        contact.email, contact.name, label.name (topic), sublabel.name (intent),
        user.email (assigned human), agent.name, flags, message_count

    Returns:
        Matching conversations
    """
    results = await client.query_conversations(
        filters=filters,
        search=search,
        limit=limit,
        fetch_all=fetch_all,
        shop_id=shop_id,
    )

    if fields:
        results = select_fields(results, fields)

    if output_format == "csv":
        return f"# {len(results)} results\n" + to_csv(results, fields)
    return to_json({"count": len(results), "results": results})


async def conversation_get(
    client: AppliedClient,
    conversation_id: str,
    include_messages: bool = False,
    message_limit: int = 50,
    shop_id: str | None = None,
) -> str:
    """
    Get a single conversation by ID.

    Args:
        client: Authenticated AppliedClient
        conversation_id: The conversation UUID
        include_messages: Include message transcript (default: False)
        message_limit: Max messages to include (default: 50)

    Returns:
        Conversation details and optionally messages
    """
    conv = await client.get_conversation(conversation_id, shop_id=shop_id)
    result = f"# Conversation {conversation_id}\n{to_json(conv)}"

    if include_messages:
        messages = await client.get_messages(
            conversation_id=conversation_id,
            limit=message_limit,
            shop_id=shop_id,
        )
        result += f"\n\n# Messages ({len(messages)})\n"
        for m in messages:
            role = m.get("role", "unknown")
            content = str(m.get("content", ""))[:500]
            result += f"\n[{role}] {content}"

    return result


async def conversation_reply(
    client: AppliedClient,
    conversation_id: str,
    *,
    agent_id: str,
    content: str,
    shop_id: str | None = None,
    metadata: dict | None = None,
) -> str:
    """Send an assistant-authored reply on a conversation."""
    message = await client.reply_to_conversation(
        conversation_id,
        agent_id=agent_id,
        content=content,
        metadata=metadata,
        shop_id=shop_id,
    )
    return to_json(message)


async def conversation_update(
    client: AppliedClient,
    conversation_id: str,
    *,
    resolution: str | None = None,
    user_id: str | None = None,
    shop_id: str | None = None,
) -> str:
    """Update a conversation."""
    conversation = await client.update_conversation(
        conversation_id,
        resolution=resolution,
        user_id=user_id,
        shop_id=shop_id,
    )
    return to_json(conversation)


async def ticket_query(
    client: AppliedClient,
    filters: dict | None = None,
    limit: int = 20,
    shop_id: str | None = None,
    output_format: str = "csv",
) -> str:
    """
    Query tickets with filters.

    Args:
        client: Authenticated AppliedClient
        filters: Filter conditions, e.g. {"status": "open"}
        limit: Max results (default 20)
        output_format: 'csv' or 'json'

    Returns:
        Matching tickets
    """
    results = await client.query_tickets(filters=filters, limit=limit, shop_id=shop_id)
    mapped = [
        {
            "id": t.get("id"),
            "name": t.get("name"),
            "status": t.get("status"),
            "priority": t.get("priority"),
        }
        for t in results
    ]

    if output_format == "csv":
        return f"# {len(mapped)} tickets\n" + to_csv(
            mapped, ["id", "name", "status", "priority"]
        )
    return to_json(mapped)


async def ticket_get(
    client: AppliedClient,
    ticket_id: str,
    *,
    include_messages: bool = False,
    message_limit: int = 50,
    shop_id: str | None = None,
) -> str:
    """Get a single ticket by ID."""
    ticket = await client.get_ticket(ticket_id, shop_id=shop_id)
    result = f"# Ticket {ticket_id}\n{to_json(ticket)}"

    if include_messages:
        messages = await client.get_messages(
            ticket_id=ticket_id,
            limit=message_limit,
            shop_id=shop_id,
        )
        result += f"\n\n# Ticket Messages ({len(messages)})\n"
        for message in messages:
            role = message.get("role", "unknown")
            content = str(message.get("content", ""))[:500]
            result += f"\n[{role}] {content}"

    return result


async def ticket_note(
    client: AppliedClient,
    ticket_id: str,
    *,
    agent_id: str,
    content: str,
    shop_id: str | None = None,
    metadata: dict | None = None,
) -> str:
    """Add an assistant-authored note to a ticket."""
    message = await client.add_ticket_note(
        ticket_id,
        agent_id=agent_id,
        content=content,
        metadata=metadata,
        shop_id=shop_id,
    )
    return to_json(message)


async def ticket_update(
    client: AppliedClient,
    ticket_id: str,
    *,
    status: str | None = None,
    content: str | None = None,
    metadata: dict | None = None,
    assignee_id: str | None = None,
    shop_id: str | None = None,
) -> str:
    """Update a ticket."""
    ticket = await client.update_ticket(
        ticket_id,
        status=status,
        content=content,
        metadata=metadata,
        assignee_id=assignee_id,
        shop_id=shop_id,
    )
    return to_json(ticket)


async def knowledge_list(
    client: AppliedClient,
    kb_type: str | None = None,
    search: str | None = None,
    limit: int = 100,
    fetch_all: bool = False,
    output_format: str = "csv",
) -> str:
    """
    List knowledge base items (Q&A, escalation rules, context, exact responses).

    Args:
        client: Authenticated AppliedClient
        kb_type: Filter by type - 'qa', 'context', 'escalate', 'exact'
        search: Full-text search query
        limit: Results per page (default 100)
        fetch_all: If True, fetch all pages (default False)
        output_format: 'csv' or 'json'

    Returns:
        Knowledge base items with id, type, question, answer preview, and active status.
        Use knowledge_get(id) to see full answer and agent associations.
    """
    results = await client.list_knowledge(
        kb_type=kb_type, search=search, limit=limit, fetch_all=fetch_all
    )
    mapped = [
        {
            "id": r.get("id"),
            "type": r.get("type"),
            "question": str(r.get("question", ""))[:100],
            "answer": str(r.get("answer", ""))[:150],
            "active": r.get("active"),
        }
        for r in results
    ]

    if output_format == "csv":
        return to_csv(mapped, ["id", "type", "question", "answer", "active"])
    return to_json(mapped)


async def knowledge_get(
    client: AppliedClient,
    knowledge_id: str,
) -> str:
    """
    Get a single knowledge base item with full details.

    Args:
        client: Authenticated AppliedClient
        knowledge_id: The knowledge item UUID

    Returns:
        Full knowledge item details including:
        - question/trigger text
        - complete answer/response text
        - assigned agents (if any)
        - label/sublabel categorization
        - guardrails and extracted fields
    """
    item = await client.get_knowledge(knowledge_id)

    result = f"# Knowledge Item: {knowledge_id}\n"
    result += f"type: {item.get('type')}\n"
    result += f"active: {item.get('active')}\n"

    # Label/sublabel categorization
    label = item.get("label")
    if label:
        result += f"label: {label.get('name', '')} ({label.get('id', '')})\n"
    sublabel = item.get("sublabel")
    if sublabel:
        result += f"sublabel: {sublabel.get('name', '')} ({sublabel.get('id', '')})\n"

    # Question/trigger
    question = item.get("question", "")
    result += f"\n## Question/Trigger\n{question}\n"

    # Answer/response
    answer = item.get("answer", "")
    if answer:
        result += f"\n## Answer/Response\n{answer}\n"

    # Guardrail (exact match response)
    guardrail = item.get("guardrail", "")
    if guardrail:
        result += f"\n## Guardrail\n{guardrail}\n"

    # Fields to extract (for structured responses)
    fields = item.get("fields_to_extract")
    if fields:
        result += f"\n## Fields to Extract\n{to_json(fields)}\n"

    # Associated flow
    flow = item.get("flow")
    if flow:
        result += "\n## Associated Flow\n"
        result += f"id: {flow.get('id')}\n"
        result += f"name: {flow.get('name')}\n"

    # Assigned agents
    agents = item.get("agents", [])
    if agents:
        result += f"\n## Assigned Agents ({len(agents)})\n"
        for a in agents:
            result += f"- {a.get('name')} ({a.get('id')})\n"
    else:
        result += (
            "\n## Assigned Agents\nAvailable to all agents (no specific assignment)\n"
        )

    # Timestamps
    result += "\n## Metadata\n"
    result += f"created_at: {item.get('created_at', '')[:19]}\n"
    result += f"updated_at: {item.get('updated_at', '')[:19]}\n"
    if item.get("tokens"):
        result += f"tokens: {item.get('tokens')}\n"

    return result


async def knowledge_get_batch(
    client: AppliedClient,
    knowledge_ids: list[str] | None = None,
    fetch_all: bool = False,
    kb_type: str | None = None,
    output_format: str = "text",
) -> str:
    """
    Get multiple knowledge base items with full details.

    Args:
        client: Authenticated AppliedClient
        knowledge_ids: List of knowledge item UUIDs (comma-separated string also accepted)
        fetch_all: If True, fetch all knowledge items (ignores knowledge_ids)
        kb_type: Filter by type when fetch_all=True - 'qa', 'context', 'escalate', 'exact'
        output_format: 'text' (formatted) or 'json'

    Returns:
        Full details for each knowledge item
    """
    if fetch_all:
        # Get all IDs first
        all_items = await client.list_knowledge(
            kb_type=kb_type, limit=100, fetch_all=True
        )
        ids_to_fetch = [item.get("id") for item in all_items if item.get("id")]
    elif knowledge_ids:
        ids_to_fetch = knowledge_ids
    else:
        return "Error: Provide knowledge_ids or set fetch_all=True"

    if not ids_to_fetch:
        return "No knowledge items found."

    # Fetch all items in parallel
    items = await client.get_knowledge_batch(ids_to_fetch)

    if output_format == "json":
        return to_json(items)

    # Format as text
    results = []
    for item in items:
        result = f"## {item.get('id')}\n"
        result += f"type: {item.get('type')}\n"
        result += f"active: {item.get('active')}\n"

        question = item.get("question", "")
        result += f"question: {question[:200]}{'...' if len(question) > 200 else ''}\n"

        answer = item.get("answer", "")
        result += f"answer: {answer}\n"

        agents = item.get("agents", [])
        if agents:
            agent_names = ", ".join(a.get("name", "") for a in agents)
            result += f"agents: {agent_names}\n"

        results.append(result)

    header = f"# Knowledge Items ({len(items)} total)\n\n"
    return header + "\n---\n\n".join(results)


# -----------------------------------------------------------------------------
# Content / Articles
# -----------------------------------------------------------------------------


async def article_list(
    client: AppliedClient,
    status: str | None = None,
    search: str | None = None,
    limit: int = 100,
    fetch_all: bool = False,
    output_format: str = "csv",
) -> str:
    """
    List articles in the knowledge base.

    Args:
        client: Authenticated AppliedClient
        status: Filter by status - 'Published', 'Draft', 'Pending'
        search: Full-text search query
        limit: Results per page (default 100)
        fetch_all: If True, fetch all pages (default False)
        output_format: 'csv' or 'json'

    Returns:
        Articles with id, title, status, description preview, and timestamps.
        Use article_get(id) to see the full content.
    """
    results = await client.list_content(
        content_type="Article",
        status=status,
        search=search,
        limit=limit,
        fetch_all=fetch_all,
    )
    mapped = [
        {
            "id": r.get("id"),
            "title": str(r.get("title", ""))[:80],
            "status": r.get("status"),
            "description": str(r.get("description", ""))[:100],
            "updated_at": str(r.get("updatedAt", r.get("updated_at", "")))[:19],
        }
        for r in results
    ]

    if output_format == "csv":
        return to_csv(mapped, ["id", "title", "status", "description", "updated_at"])
    return to_json(mapped)


async def article_get(
    client: AppliedClient,
    article_id: str,
    include_html: bool = True,
) -> str:
    """
    Get a single article with full content.

    Args:
        client: Authenticated AppliedClient
        article_id: The article/content UUID
        include_html: Include the HTML content (default: True)

    Returns:
        Full article details including title, description, content, and metadata.
    """
    item = await client.get_content(article_id)

    result = f"# Article: {item.get('title', 'Untitled')}\n"
    result += f"id: {item.get('id')}\n"
    result += f"status: {item.get('status')}\n"
    result += f"type: {item.get('type')}\n"

    # Description
    description = item.get("description", "")
    if description:
        result += f"\n## Description\n{description}\n"

    # HTML content
    if include_html:
        html = item.get("html", "")
        if html:
            # Truncate very long HTML
            if len(html) > 5000:
                html = html[:5000] + "\n... (truncated)"
            result += f"\n## Content (HTML)\n{html}\n"

    # Labels/categories
    label = item.get("label")
    if label:
        result += f"\n## Topic\n{label.get('name', '')} ({label.get('id', '')})\n"
    sublabel = item.get("sublabel")
    if sublabel:
        result += f"Intent: {sublabel.get('name', '')} ({sublabel.get('id', '')})\n"

    # Tags
    tags = item.get("tags", [])
    if tags:
        result += f"\n## Tags\n{', '.join(tags)}\n"

    # Source
    source = item.get("source")
    if source:
        result += "\n## Content Source\n"
        result += f"name: {source.get('name', '')}\n"
        result += f"type: {source.get('type', '')}\n"

    # Metadata
    result += "\n## Metadata\n"
    result += f"slug: {item.get('slug', '')}\n"
    result += (
        f"created_at: {str(item.get('createdAt', item.get('created_at', '')))[:19]}\n"
    )
    result += (
        f"updated_at: {str(item.get('updatedAt', item.get('updated_at', '')))[:19]}\n"
    )
    result += f"should_autogenerate_responses: {item.get('shouldAutogenerateResponses', item.get('should_autogenerate_responses', False))}\n"
    result += (
        f"used_for_rag: {item.get('usedForRag', item.get('used_for_rag', False))}\n"
    )

    return result


async def article_create(
    client: AppliedClient,
    title: str,
    description: str = "",
    content: str = "",
) -> str:
    """
    Create a new article.

    Args:
        client: Authenticated AppliedClient
        title: Article title
        description: Article description/summary
        content: Article content as HTML or plain text

    Returns:
        Created article with ID
    """
    try:
        article = await client.create_article(
            title=title,
            description=description,
            html=content,
        )
    except AppliedAPIError as e:
        return _format_error(e)

    result = "# Created Article\n"
    result += f"id: {article.get('id')}\n"
    result += f"title: {article.get('title')}\n"
    result += f"status: {article.get('status')}\n"

    return result


async def article_update(
    client: AppliedClient,
    article_id: str,
    title: str | None = None,
    description: str | None = None,
    content: str | None = None,
    status: str | None = None,
) -> str:
    """
    Update an article's content or metadata.

    Args:
        client: Authenticated AppliedClient
        article_id: The article/content UUID
        title: New title
        description: New description
        content: New HTML content
        status: New status - 'Published', 'Draft', 'Pending'

    Returns:
        Updated article
    """
    updates: dict = {}
    if title is not None:
        updates["title"] = title
    if description is not None:
        updates["description"] = description
    if content is not None:
        updates["html"] = content
        updates["text"] = content  # Also update plain text
    if status is not None:
        updates["status"] = status

    try:
        article = await client.update_content(article_id, **updates)
    except AppliedAPIError as e:
        return _format_error(e)

    return f"# Updated Article: {article.get('title')}\nid: {article_id}\nstatus: {article.get('status')}"


async def article_delete(
    client: AppliedClient,
    article_id: str,
) -> str:
    """
    Delete an article.

    Args:
        client: Authenticated AppliedClient
        article_id: The article/content UUID

    Returns:
        Success message
    """
    try:
        await client.delete_content(article_id)
    except AppliedAPIError as e:
        return _format_error(e)

    return f"Article {article_id} deleted successfully."


async def article_get_batch(
    client: AppliedClient,
    article_ids: list[str] | None = None,
    fetch_all: bool = False,
    status: str | None = None,
    include_html: bool = True,
    output_format: str = "text",
) -> str:
    """
    Get multiple articles with full content.

    Args:
        client: Authenticated AppliedClient
        article_ids: List of article UUIDs
        fetch_all: If True, fetch all articles (ignores article_ids)
        status: Filter by status when fetch_all=True - 'Published', 'Draft', 'Pending'
        include_html: Include HTML content (default True)
        output_format: 'text' (formatted) or 'json'

    Returns:
        Full details for each article
    """
    if fetch_all:
        all_items = await client.list_content(
            content_type="Article", status=status, limit=100, fetch_all=True
        )
        ids_to_fetch = [item.get("id") for item in all_items if item.get("id")]
    elif article_ids:
        ids_to_fetch = article_ids
    else:
        return "Error: Provide article_ids or set fetch_all=True"

    if not ids_to_fetch:
        return "No articles found."

    items = await client.get_content_batch(ids_to_fetch)

    if output_format == "json":
        return to_json(items)

    # Format as text
    results = []
    for item in items:
        result = f"## {item.get('title', 'Untitled')}\n"
        result += f"id: {item.get('id')}\n"
        result += f"status: {item.get('status')}\n"

        description = item.get("description", "")
        if description:
            result += f"description: {description[:200]}{'...' if len(description) > 200 else ''}\n"

        if include_html:
            html = item.get("html", "")
            if html:
                # Truncate for batch view
                if len(html) > 2000:
                    html = html[:2000] + "... (truncated)"
                result += f"\n### Content\n{html}\n"

        results.append(result)

    header = f"# Articles ({len(items)} total)\n\n"
    return header + "\n---\n\n".join(results)


# -----------------------------------------------------------------------------
# Flow Management
# -----------------------------------------------------------------------------


async def flow_list(
    client: AppliedClient,
    agent_id: str | None = None,
    status: str | None = None,
    output_format: str = "csv",
) -> str:
    """
    List flows for an agent.

    Args:
        client: Authenticated AppliedClient
        agent_id: Filter by agent ID (recommended)
        status: Filter by status - 'Active', 'Draft', or 'Archived'
        output_format: 'csv' or 'json'

    Returns:
        List of flows with id, name, type, trigger, status, updated_at
    """
    flows = await client.list_flows(agent_id=agent_id, status=status)
    mapped = [
        {
            "id": f.get("id"),
            "name": f.get("name"),
            "type": f.get("type"),
            "trigger": f.get("trigger"),
            "status": f.get("status"),
            "updated_at": f.get("updated_at", "")[:19],
        }
        for f in flows
    ]

    if output_format == "csv":
        return to_csv(mapped, ["id", "name", "type", "trigger", "status", "updated_at"])
    return to_json(mapped)


async def flow_get(
    client: AppliedClient,
    flow_id: str,
    output_format: str = "summary",
) -> str:
    """
    Get a flow with its full graph (nodes and edges).

    Args:
        client: Authenticated AppliedClient
        flow_id: The flow UUID
        output_format: 'summary' (default), 'full' (includes node metadata/prompts),
                       or 'json' (raw JSON)

    Returns:
        Flow metadata, nodes, and edges. Use 'full' to see node configurations.
    """
    flow = await client.get_flow(flow_id)
    graph = flow.get("graph", {})
    nodes = graph.get("nodes", [])
    edges = graph.get("edges", [])

    if output_format == "json":
        return to_json(flow)

    # Format header
    result = f"# Flow: {flow.get('name')}\n"
    result += f"id: {flow.get('id')}\n"
    result += f"type: {flow.get('type')}\n"
    result += f"trigger: {flow.get('trigger')}\n"
    result += f"status: {flow.get('status')}\n"
    if flow.get("description"):
        result += f"description: {flow.get('description')}\n"
    if flow.get("prompt"):
        result += f"purpose: {flow.get('prompt')}\n"

    # Calculate node indices matching UI numbering
    flow_type = flow.get("type", "conversational")
    node_indices = _get_node_indices(nodes, edges, flow_type)

    # Sort nodes by their index for display
    sorted_nodes = sorted(nodes, key=lambda n: node_indices.get(n["id"], 999))

    # Format nodes
    result += f"\n## Nodes ({len(nodes)})\n"

    if output_format == "full":
        # Full output: include metadata, prompt, schemas for each node
        for n in sorted_nodes:
            data = n.get("data", {})
            node_name = _get_node_name(n)
            node_type = n.get("type", data.get("executor_type", ""))
            idx = node_indices.get(n["id"], "?")

            result += f"\n### {idx}. {node_name}"
            if node_type and node_type != node_name.split("-")[0]:
                result += f" ({node_type})"
            result += "\n"
            result += f"id: {n.get('id')}\n"

            if data.get("description"):
                result += f"description: {data.get('description')}\n"

            if data.get("prompt"):
                prompt_preview = data.get("prompt", "")
                if len(prompt_preview) > 300:
                    prompt_preview = prompt_preview[:300] + "..."
                result += f"prompt: {prompt_preview}\n"

            metadata = data.get("metadata", {})
            if metadata:
                result += f"metadata: {json.dumps(metadata)}\n"

            outputs = data.get("outputs", {})
            if outputs and outputs.get("properties"):
                props = list(outputs.get("properties", {}).keys())
                result += f"output_fields: {', '.join(props)}\n"
    else:
        # Summary output: table format with index
        node_rows = [
            {
                "#": node_indices.get(n["id"], "?"),
                "name": _get_node_name(n),
                "id": n.get("id"),
                "type": n.get("type", n.get("data", {}).get("executor_type", "")),
                "description": n.get("data", {}).get("description", "")[:50],
            }
            for n in sorted_nodes
        ]
        result += to_csv(node_rows, ["#", "name", "id", "type", "description"])

    # Format edges
    result += f"\n## Edges ({len(edges)})\n"
    edge_rows = [
        {
            "id": e.get("id"),
            "source": e.get("source"),
            "target": e.get("target"),
            "source_handle": e.get("sourceHandle", ""),
            "target_handle": e.get("targetHandle", ""),
            "label": e.get("data", {}).get("label", ""),
        }
        for e in edges
    ]
    result += to_csv(
        edge_rows, ["id", "source", "target", "source_handle", "target_handle", "label"]
    )

    return result


async def flow_create(
    client: AppliedClient,
    agent_id: str,
    name: str,
    flow_type: str = "conversational",
    trigger: str = "llm.call",
    description: str = "",
) -> str:
    """
    Create a new flow.

    Args:
        client: Authenticated AppliedClient
        agent_id: The agent to attach the flow to
        name: Flow name
        flow_type: 'conversational' (default) or 'operational'
        trigger: 'llm.call' (conversation trigger), 'conversation.end', etc.
        description: Optional flow description

    Returns:
        Created flow with auto-generated trigger and escalation nodes
    """
    flow = await client.create_flow(
        agent_id=agent_id,
        name=name,
        flow_type=flow_type,
        trigger=trigger,
        description=description,
    )

    result = f"# Created Flow: {flow.get('name')}\n"
    result += f"id: {flow.get('id')}\n"
    result += f"type: {flow.get('type')}\n"
    result += f"trigger: {flow.get('trigger')}\n"
    result += f"status: {flow.get('status')}\n"
    result += "\nUse flow_get to see the auto-generated nodes."

    return result


async def flow_update(
    client: AppliedClient,
    flow_id: str,
    name: str | None = None,
    description: str | None = None,
    prompt: str | None = None,
    status: str | None = None,
) -> str:
    """
    Update a flow's properties.

    Args:
        client: Authenticated AppliedClient
        flow_id: The flow UUID
        name: New name
        description: New description
        prompt: Flow purpose (used for routing)
        status: 'Active', 'Draft', or 'Archived'

    Returns:
        Updated flow
    """
    updates = {}
    if name is not None:
        updates["name"] = name
    if description is not None:
        updates["description"] = description
    if prompt is not None:
        updates["prompt"] = prompt
    if status is not None:
        updates["status"] = status

    flow = await client.update_flow(flow_id, **updates)

    return f"# Updated Flow: {flow.get('name')}\nstatus: {flow.get('status')}"


async def flow_delete(
    client: AppliedClient,
    flow_id: str,
) -> str:
    """
    Delete a flow.

    Args:
        client: Authenticated AppliedClient
        flow_id: The flow UUID

    Returns:
        Success message
    """
    await client.delete_flow(flow_id)
    return f"Flow {flow_id} deleted successfully."


async def flow_archive(
    client: AppliedClient,
    flow_id: str,
) -> str:
    """
    Archive a flow (sets status to 'Archived').

    Archived flows are hidden from the active list but not deleted.
    Use this to clean up broken or redundant flows.

    Args:
        client: Authenticated AppliedClient
        flow_id: The flow UUID

    Returns:
        Success message
    """
    flow = await client.update_flow(flow_id, status="Archived")
    return f"# Archived Flow: {flow.get('name')}\nid: {flow_id}\nstatus: Archived"


# -----------------------------------------------------------------------------
# Node Management
# -----------------------------------------------------------------------------


async def flow_node_get(
    client: AppliedClient,
    flow_id: str,
    node_id: str,
) -> str:
    """
    Get a single node's full configuration.

    Args:
        client: Authenticated AppliedClient
        flow_id: The flow UUID
        node_id: The node UUID

    Returns:
        Full node config including metadata, prompt, executor type, and schemas
    """
    node = await client.get_node(flow_id, node_id)

    if not node:
        return f"Node {node_id} not found in flow {flow_id}"

    data = node.get("data", {})

    result = f"# Node: {data.get('name', node_id)}\n"
    result += f"id: {node.get('id')}\n"
    result += f"type: {node.get('type', data.get('executor_type', ''))}\n"

    if data.get("description"):
        result += f"description: {data.get('description')}\n"

    if data.get("prompt"):
        result += f"\n## Prompt\n{data.get('prompt')}\n"

    # Full metadata
    metadata = data.get("metadata", {})
    if metadata:
        result += "\n## Metadata\n"
        result += json.dumps(metadata, indent=2) + "\n"

    # Input schema
    inputs = data.get("inputs", {})
    if inputs:
        result += "\n## Input Schema\n"
        result += json.dumps(inputs, indent=2) + "\n"

    # Output schema
    outputs = data.get("outputs", {})
    if outputs:
        result += "\n## Output Schema\n"
        result += json.dumps(outputs, indent=2) + "\n"

    return result


async def flow_node_create(
    client: AppliedClient,
    flow_id: str,
    executor_type: str,
    description: str = "",
    prompt: str = "",
    guardrail: str = "",
    metadata: dict | None = None,
) -> str:
    """
    Add a node to a flow.

    Args:
        client: Authenticated AppliedClient
        flow_id: The flow UUID
        executor_type: Node type - 'completion', 'structured_completion',
            'branch', 'loop', 'http_request', 'code', 'memory', etc.
        description: Node description
        prompt: Prompt/response content for LLM nodes
        guardrail: Guidance/instructions for the agent (completion nodes)
        metadata: Node configuration as dict. For completion nodes:
            - "exact_response": bool - use exact text verbatim without modification
            - "continue_from_state": bool - include conversation history as context
            - "reasoning_level": "minimal"|"low"|"medium"|"high"
            - "response_mode": "ask"|"inform" (conversational flows only)
            - "position": {"x": number, "y": number} for layout

    Returns:
        Created node with generated ID
    """
    # Validate common mistakes before API call
    valid_types = {
        "completion",
        "structured_completion",
        "branch",
        "code",
        "http_request",
        "loop",
        "memory",
        "search",
        "recommend",
        "run_flow",
        "analyze",
        "return_data",
        "end_flow",
        "global",
        "_escalate_conversation",
        "handoff",
        "resource",
        "flow",
        "mutate_ticket",
        "mutate_conversation",
        "mutate_message",
    }
    if executor_type not in valid_types:
        exec_type_str = (
            str(executor_type) if not isinstance(executor_type, str) else executor_type
        )
        suggestions = [t for t in valid_types if exec_type_str.lower() in t.lower()]
        if not suggestions:
            suggestions = ["completion", "branch", "code"]
        return (
            f"❌ Error: Unknown executor_type '{executor_type}'.\n\n"
            f"💡 Did you mean one of: {', '.join(suggestions)}?\n"
            f"Run executor_list() to see all available node types with descriptions."
        )

    # Validate branch metadata
    if executor_type == "branch" and metadata:
        if "value" not in metadata:
            return (
                "❌ Error: Branch node requires 'value' in metadata.\n\n"
                '💡 Example: metadata=\'{"value": "{trigger.message}", '
                '"comparisons": [{"comparison_operator": "contains", '
                '"comparison_value": "yes", "comparison_type": "string"}], '
                '"position": {"x": 0, "y": 300}}\'\n\n'
                "Run flow_variables(flow_id) to see available variable references."
            )
        if "comparisons" not in metadata:
            return (
                "❌ Error: Branch node requires 'comparisons' in metadata.\n\n"
                '💡 Example comparison: {"comparison_operator": "contains", '
                '"comparison_value": "yes", "comparison_type": "string"}\n'
                "Operators: equals, not_equals, contains, not_contains, "
                "starts_with, ends_with, greater_than, less_than, is_empty, is_not_empty"
            )

    # Validate resource metadata
    if executor_type == "resource":
        if not metadata:
            return (
                "❌ Error: Resource node requires metadata.\n\n"
                "💡 Required fields:\n"
                '  - resource_type: "shopify", "slack", "stripe", etc.\n'
                '  - action: "get_order", "cancel_order", "send_message", etc.\n'
                "  - resource_id: UUID of the configured integration\n"
                "  - action_input: dict of action parameters\n\n"
                "Example:\n"
                'metadata=\'{"resource_type": "shopify", "action": "get_order", '
                '"resource_id": "<uuid>", "action_input": {"contact": "{trigger.contact.email}", '
                '"order_number": "{completion-abc.order_number}"}, '
                '"format_with_variables": true, "position": {"x": 0, "y": 600}}\''
            )
        missing = []
        if "resource_type" not in metadata:
            missing.append("resource_type")
        if "action" not in metadata:
            missing.append("action")
        if "resource_id" not in metadata:
            missing.append("resource_id")
        if missing:
            return (
                f"❌ Error: Resource node missing required fields: {', '.join(missing)}\n\n"
                "💡 Required metadata fields:\n"
                '  - resource_type: "shopify", "slack", "stripe", "snowflake", etc.\n'
                '  - action: the operation (e.g., "get_order", "cancel_order")\n'
                "  - resource_id: UUID of the configured integration\n"
                "  - action_input: dict of action parameters (optional)\n\n"
                "To find resource_id: look at existing flows with flow_get()"
            )

    # Validate flow (subflow) metadata
    is_flow = executor_type == "flow"
    flow_missing_id = not metadata or "flow_id" not in metadata
    if is_flow and flow_missing_id:
        return (
            "❌ Error: Flow (subflow) node requires 'flow_id' in metadata.\n\n"
            "💡 Required fields:\n"
            "  - flow_id: UUID of the subflow to call\n"
            "  - flow_input: dict mapping subflow trigger inputs (optional)\n\n"
            "Example:\n"
            'metadata=\'{"flow_id": "<subflow-uuid>", '
            '"flow_input": {"email": "{trigger.contact.email}", "issue": "Order inquiry"}, '
            '"position": {"x": 0, "y": 600}}\''
        )

    # Validate mutate_ticket metadata
    is_mutate_ticket = executor_type == "mutate_ticket"
    ticket_missing_name = not metadata or "name" not in metadata
    if is_mutate_ticket and ticket_missing_name:
        return (
            "❌ Error: mutate_ticket node requires 'name' in metadata.\n\n"
            "💡 Fields:\n"
            "  - name: ticket title (required, supports {var} interpolation)\n"
            "  - tags: list of tag strings (optional)\n"
            "  - description: ticket body (optional)\n"
            "  - conversation_id: link to conversation (optional)\n\n"
            "Example:\n"
            'metadata=\'{"name": "{trigger.contact.email} - cancel request", '
            '"tags": ["urgent"], "position": {"x": 0, "y": 600}}\''
        )

    try:
        node = await client.create_node(
            flow_id=flow_id,
            name=executor_type,
            description=description,
            prompt=prompt,
            guardrail=guardrail,
            metadata=metadata,
        )
    except AppliedAPIError as e:
        return _format_error(e)

    result = "# Created Node\n"
    result += f"id: {node.get('id')}\n"
    result += f"name: {node.get('name')}\n"
    # Include slug from nested data if available (e.g. "completion-my_node")
    data = node.get("data", {})
    slug = data.get("name", node.get("name", ""))
    if slug:
        result += f"slug: {slug}\n"
    if description:
        result += f"description: {description}\n"

    return result


async def flow_node_update(
    client: AppliedClient,
    flow_id: str,
    node_id: str,
    description: str | None = None,
    prompt: str | None = None,
    guardrail: str | None = None,
    metadata: dict | None = None,
) -> str:
    """
    Update a node's configuration.

    Args:
        client: Authenticated AppliedClient
        flow_id: The flow UUID
        node_id: The node UUID
        description: New description
        prompt: New prompt/response content
        guardrail: New guidance/instructions for the agent (completion nodes)
        metadata: New metadata (merged with existing). For completion nodes:
            - "exact_response": bool - use exact text verbatim without modification
            - "continue_from_state": bool - include conversation history as context
            - "reasoning_level": "minimal"|"low"|"medium"|"high"
            - "response_mode": "ask"|"inform" (conversational flows only)
            - "position": {"x": number, "y": number} for layout

    Returns:
        Updated node
    """
    updates = {}
    if description is not None:
        updates["description"] = description
    if prompt is not None:
        updates["prompt"] = prompt
    if guardrail is not None:
        updates["guardrail"] = guardrail
    if metadata is not None:
        updates["metadata"] = metadata

    node = await client.update_node(flow_id, node_id, **updates)

    return f"# Updated Node: {node.get('name')}\nid: {node.get('id')}"


async def flow_node_delete(
    client: AppliedClient,
    flow_id: str,
    node_id: str,
) -> str:
    """
    Remove a node from a flow.

    Args:
        client: Authenticated AppliedClient
        flow_id: The flow UUID
        node_id: The node UUID

    Returns:
        Success message
    """
    await client.delete_node(flow_id, node_id)
    return f"Node {node_id} deleted successfully."


# -----------------------------------------------------------------------------
# Edge Management
# -----------------------------------------------------------------------------


async def flow_edge_create(
    client: AppliedClient,
    flow_id: str,
    source_node_id: str,
    target_node_id: str,
    source_handle: str | None = None,
    target_handle: str | None = None,
    label: str | None = None,
) -> str:
    """
    Connect two nodes with an edge.

    Args:
        client: Authenticated AppliedClient
        flow_id: The flow UUID
        source_node_id: Source node UUID
        target_node_id: Target node UUID
        source_handle: Output handle name (for branching: "1", "2", "default")
        target_handle: Input handle name (for mapping)
        label: Edge label/condition

    Returns:
        Created edge
    """
    try:
        edge = await client.create_edge(
            flow_id=flow_id,
            source_node_id=source_node_id,
            target_node_id=target_node_id,
            source_handle=source_handle,
            target_handle=target_handle,
            label=label,
        )
    except AppliedAPIError as e:
        # Add extra context for edge errors
        extra = ""
        if source_handle:
            extra = (
                f"\n\nYou passed source_handle='{source_handle}'. "
                "For branch nodes, handles are '1', '2', '3' (matching comparison index) "
                "or 'default'. Run flow_node_get(flow_id, source_node_id) to check the "
                "node type and available outputs."
            )
        return _format_error(e) + extra

    result = "# Created Edge\n"
    result += f"id: {edge.get('id')}\n"
    result += f"source: {edge.get('source')}\n"
    result += f"target: {edge.get('target')}\n"

    return result


async def flow_edge_update(
    client: AppliedClient,
    flow_id: str,
    edge_id: str,
    label: str | None = None,
    metadata: dict | None = None,
) -> str:
    """
    Update an edge's properties.

    Args:
        client: Authenticated AppliedClient
        flow_id: The flow UUID
        edge_id: The edge UUID
        label: New label/condition
        metadata: New metadata

    Returns:
        Updated edge
    """
    updates = {}
    if label is not None:
        updates["label"] = label
    if metadata is not None:
        updates["metadata"] = metadata

    edge = await client.update_edge(flow_id, edge_id, **updates)

    return f"# Updated Edge\nid: {edge.get('id')}"


async def flow_edge_delete(
    client: AppliedClient,
    flow_id: str,
    edge_id: str,
) -> str:
    """
    Remove an edge from a flow.

    Args:
        client: Authenticated AppliedClient
        flow_id: The flow UUID
        edge_id: The edge UUID

    Returns:
        Success message
    """
    await client.delete_edge(flow_id, edge_id)
    return f"Edge {edge_id} deleted successfully."


# -----------------------------------------------------------------------------
# Flow Execution
# -----------------------------------------------------------------------------


async def flow_run(
    client: AppliedClient,
    flow_id: str,
    trigger_data: dict | None = None,
    contact_email: str | None = None,
    contact_name: str | None = None,
    contact_phone: str | None = None,
    wait: bool = True,
    wait_timeout: float = 60.0,
) -> str:
    """
    Execute a flow with test input.

    NOTE: Context fields like {trigger.shop.*} and {trigger.current_time} do NOT
    populate in flow_run. Use send_message(flow_id=...) for context-dependent flows.

    Args:
        client: Authenticated AppliedClient
        flow_id: The flow UUID
        trigger_data: Trigger input data, e.g.:
            {"message": "Hello"}
            {"message": "Help me", "contact": {"email": "user@example.com"}}
            {"conversation_id": "uuid-of-existing-conversation"}
        contact_email: Optional - creates a real Contact record (populates {trigger.contact.email})
        contact_name: Optional - contact name for the created Contact
        contact_phone: Optional - contact phone for the created Contact
        wait: If True (default), wait for completion and return full trace.
              If False, return immediately with just the run ID.
        wait_timeout: Max seconds to wait (default 60)

    Returns:
        Flow run with execution trace (if wait=True) or just run ID
    """
    # Build trigger data
    data = dict(trigger_data) if trigger_data else {}
    contact_info = ""

    # Pass contact data in trigger.contact for variable interpolation
    # NOTE: This does NOT populate {trigger.contact.email} - that requires a real
    # Contact record linked to a conversation. The /v1/c/ endpoint that could do this
    # has a server-side bug. For now, contact params are informational only.
    if contact_email or contact_name or contact_phone:
        data["contact"] = {
            "email": contact_email or "",
            "name": contact_name or "",
            "phone": contact_phone or "",
        }
        contact_info = f"contact: {data['contact']}\n"
        contact_info += (
            "⚠️ Note: {trigger.contact.*} won't populate - server bug in /v1/c/\n"
        )

    try:
        run = await client.run_flow(
            flow_id,
            data,
            wait=wait,
            wait_timeout=wait_timeout,
        )
    except AppliedAPIError as e:
        return _format_error(e)

    result = f"# Flow Run: {run.get('id')}\n"
    result += f"status: {run.get('status')}\n"
    if contact_info:
        result += contact_info
    result += f"started_at: {run.get('started_at')}\n"

    if run.get("ended_at"):
        result += f"ended_at: {run.get('ended_at')}\n"
    if run.get("duration"):
        result += f"duration: {run.get('duration')}s\n"

    # Execution trace from spans
    spans = run.get("spans", [])
    if spans:
        result += f"\n## Execution Trace ({len(spans)} spans)\n"
        for i, span in enumerate(spans, 1):
            name = span.get("span_name", "")
            duration = span.get("duration", 0)
            status = span.get("status_code", "")
            status_msg = span.get("status_message", "")
            attrs = span.get("span_attributes", {})

            status_str = "OK" if "OK" in str(status) else "ERROR"
            result += f"{i}. [{name}] {duration:.2f}s - {status_str}"
            if status_msg:
                result += f" - {status_msg}"
            result += "\n"

            # Show output for executor_run spans
            if name == "executor_run" and attrs.get("output"):
                try:
                    output_data = json.loads(attrs["output"])
                    for k, v in output_data.items():
                        if k == "success":
                            continue
                        result += f"   output.{k}: {str(v)[:300]}\n"
                except (json.JSONDecodeError, TypeError):
                    result += f"   output: {str(attrs['output'])[:500]}\n"

            # completion: show the LLM text output
            elif name == "completion" and attrs.get("content"):
                result += f"   completion: {str(attrs['content'])[:500]}\n"

            # structured_completion: show parsed output
            elif name == "structured_completion" and attrs.get("output"):
                try:
                    out = json.loads(attrs["output"])
                    result += f"   output: {json.dumps(out, indent=None)[:400]}\n"
                except (json.JSONDecodeError, TypeError):
                    result += f"   output: {str(attrs['output'])[:400]}\n"

            # branch: show routing decision
            elif name == "branch":
                selected = attrs.get("selected.path", "")
                if selected:
                    result += f"   selected: {selected}\n"

    # Actions summary
    actions = run.get("actions", [])
    if actions:
        result += f"\n## Actions ({len(actions)})\n"
        action_rows = [
            {
                "node": a.get("tool", {}).get("name", ""),
                "status": a.get("status"),
            }
            for a in actions
        ]
        result += to_csv(action_rows, ["node", "status"])

    # Errors
    errors = [s for s in spans if "ERROR" in str(s.get("status_code", ""))]
    if errors:
        result += "\n## Errors\n"
        for err in errors:
            attrs = err.get("span_attributes", {})
            node_name = attrs.get("tool_name") or err.get("span_name") or "unknown"
            error_msg = err.get("status_message", "")
            result += f"**Node:** {node_name}\n"
            if error_msg:
                result += f"**Error:** {error_msg}\n"
            if attrs.get("output"):
                result += f"**Output:** {str(attrs.get('output'))[:500]}\n"
            result += "\n"

    # Add warnings for common issues
    warnings = []

    # Check for branches that took default with empty value
    for span in spans:
        attrs = span.get("span_attributes", {})
        if span.get("span_name") == "branch":
            selected = attrs.get("selected.path", "")
            if selected == "default":
                # Check if comparisons had empty values
                for key, val in attrs.items():
                    if "comparison" in key.lower() and '""' in str(val):
                        warnings.append(
                            "Branch took 'default' because comparison value was empty (\"\"). "
                            "This often happens because {trigger.shop.*} and {trigger.current_time} "
                            "don't populate in flow_run. Use send_message(flow_id=...) instead "
                            "for realistic testing of context-dependent branches."
                        )
                        break

    if warnings:
        result += "\n## ⚠️ Warnings\n"
        for w in set(warnings):  # dedupe
            result += f"- {w}\n"

    return result


async def flow_node_run(
    client: AppliedClient,
    flow_id: str,
    node_id: str,
    variables: dict | None = None,
    wait: bool = True,
    wait_timeout: float = 60.0,
) -> str:
    """
    Execute a single node in isolation with mock inputs.

    Use this to test individual nodes without running the full flow.
    Provide mock values for any variables the node references.

    Args:
        client: Authenticated AppliedClient
        flow_id: The flow UUID containing the node
        node_id: The node UUID to execute
        variables: Mock input variables as dict, e.g.:
            {"trigger": {"message": "test input"}}
            {"trigger": {"message": "hi"}, "completion-abc": {"completion": "mock value"}}
        wait: If True (default), wait for completion and return result.
        wait_timeout: Max seconds to wait (default 60)

    Returns:
        Node execution result with output values

    Example:
        flow_node_run(flow_id, node_id, variables={
            "trigger": {"message": "Hello world"},
            "structured_completion-xyz": {"order_id": "12345"}
        })
    """
    try:
        run = await client.run_node(
            flow_id=flow_id,
            node_id=node_id,
            variables=variables,
            wait=wait,
            wait_timeout=wait_timeout,
        )
    except AppliedAPIError as e:
        return _format_error(e)

    result = f"# Node Run: {node_id}\n"
    result += f"flow_run_id: {run.get('id')}\n"
    result += f"status: {run.get('status')}\n"

    if run.get("duration"):
        result += f"duration: {run.get('duration')}s\n"

    # Show node execution output from spans
    spans = run.get("spans", [])
    if spans:
        result += "\n## Execution\n"
        for span in spans:
            name = span.get("span_name", "")
            status = span.get("status_code", "")
            status_msg = span.get("status_message", "")
            attrs = span.get("span_attributes", {})
            duration = span.get("duration", 0)

            status_str = "OK" if "OK" in str(status) else "ERROR"
            result += f"[{name}] {duration:.2f}s - {status_str}\n"

            if status_msg:
                result += f"  message: {status_msg}\n"

            # Show output
            if attrs.get("output"):
                try:
                    output_data = json.loads(attrs["output"])
                    result += "  output:\n"
                    for k, v in output_data.items():
                        if k == "success":
                            continue
                        result += f"    {k}: {str(v)[:300]}\n"
                except (json.JSONDecodeError, TypeError):
                    result += f"  output: {str(attrs['output'])[:500]}\n"

            # Show completion content
            if attrs.get("content"):
                result += f"  completion: {str(attrs['content'])[:500]}\n"

    # Show errors
    errors = [s for s in spans if "ERROR" in str(s.get("status_code", ""))]
    if errors:
        result += "\n## Errors\n"
        for err in errors:
            error_msg = err.get("status_message", "")
            if error_msg:
                result += f"**Error:** {error_msg}\n"

    return result


async def flow_validate(
    client: AppliedClient,
    flow_id: str,
) -> str:
    """
    Validate a flow's structure before running.

    Checks for common issues:
    - Disconnected nodes (not reachable from trigger)
    - Missing edges from branch nodes
    - Empty required fields (prompts, code, etc.)
    - Invalid variable references

    Args:
        client: Authenticated AppliedClient
        flow_id: The flow UUID to validate

    Returns:
        Validation result with any issues found
    """
    try:
        flow = await client.get_flow(flow_id)
    except AppliedAPIError as e:
        return _format_error(e)

    graph = flow.get("graph", {})
    nodes = graph.get("nodes", [])
    edges = graph.get("edges", [])

    issues: list[str] = []
    warnings: list[str] = []

    # Build node lookup
    node_map = {n["id"]: n for n in nodes}
    node_names = {n.get("data", {}).get("name", n["id"]): n["id"] for n in nodes}

    # Find trigger node
    trigger_node = None
    for n in nodes:
        if n.get("type") == "trigger":
            trigger_node = n
            break

    if not trigger_node:
        issues.append("No trigger node found. Flow cannot start.")
    else:
        # Check connectivity from trigger
        reachable = set()
        queue = [trigger_node["id"]]
        while queue:
            nid = queue.pop(0)
            if nid in reachable:
                continue
            reachable.add(nid)
            for e in edges:
                if e.get("source") == nid:
                    queue.append(e.get("target"))

        # Find disconnected nodes
        for n in nodes:
            nid = n["id"]
            ntype = n.get("type", "")
            if ntype == "global":
                continue  # Global nodes are allowed to be disconnected
            if nid not in reachable:
                name = n.get("data", {}).get("name", nid)
                issues.append(f"Node '{name}' is not reachable from trigger.")

    # Check branch nodes have edges
    for n in nodes:
        ntype = n.get("type", n.get("data", {}).get("executor_type", ""))
        nid = n["id"]
        name = n.get("data", {}).get("name", nid)

        if ntype == "branch":
            metadata = n.get("data", {}).get("metadata", {})
            comparisons = metadata.get("comparisons", [])

            # Each comparison should have an outgoing edge
            outgoing_handles = set()
            for e in edges:
                if e.get("source") == nid:
                    handle = e.get("sourceHandle") or "default"
                    outgoing_handles.add(handle)

            for i, _ in enumerate(comparisons, 1):
                if str(i) not in outgoing_handles:
                    warnings.append(
                        f"Branch '{name}' comparison {i} has no outgoing edge. "
                        f"Add edge with source_handle='{i}'."
                    )

            if "default" not in outgoing_handles and comparisons:
                warnings.append(
                    f"Branch '{name}' has no default edge. "
                    "Add edge with source_handle='default' for fallback."
                )

        # Check required fields
        if ntype in ("completion", "structured_completion"):
            prompt = n.get("data", {}).get("prompt", "")
            if not prompt:
                warnings.append(f"Node '{name}' has no prompt configured.")

        if ntype == "code":
            metadata = n.get("data", {}).get("metadata", {})
            code = metadata.get("code", "")
            if not code:
                issues.append(f"Code node '{name}' has no code configured.")

        if ntype == "http_request":
            metadata = n.get("data", {}).get("metadata", {})
            url = metadata.get("url", "")
            if not url:
                issues.append(f"HTTP node '{name}' has no URL configured.")

    # Check variable references
    for n in nodes:
        ndata = n.get("data", {})
        prompt = ndata.get("prompt", "")
        metadata = ndata.get("metadata", {})
        name = ndata.get("name", n["id"])

        # Find all {var.field} references in prompt
        import re

        refs = re.findall(r"\{([^}]+)\}", prompt)
        for ref in refs:
            parts = ref.split(".")
            if not parts:
                continue
            ref_name = parts[0]
            # Check if reference is valid - must be trigger, loop, or a known node
            is_builtin = ref_name in ("trigger", "loop")
            is_node = ref_name in node_names or ref_name in node_map
            if not is_builtin and not is_node:
                warnings.append(
                    f"Node '{name}' references unknown variable '{{{ref}}}'. "
                    f"Check node name or use {{trigger.field}}."
                )

    # Format result
    result = f"# Flow Validation: {flow.get('name')}\n"
    result += f"id: {flow_id}\n"
    result += f"status: {flow.get('status')}\n"
    result += f"nodes: {len(nodes)}\n"
    result += f"edges: {len(edges)}\n\n"

    if not issues and not warnings:
        result += "✅ **Flow is valid!** No issues found.\n"
    else:
        if issues:
            result += f"## ❌ Errors ({len(issues)})\n"
            result += "These must be fixed before the flow can run:\n\n"
            for issue in issues:
                result += f"- {issue}\n"
            result += "\n"

        if warnings:
            result += f"## ⚠️ Warnings ({len(warnings)})\n"
            result += "These may cause unexpected behavior:\n\n"
            for warning in warnings:
                result += f"- {warning}\n"

    return result


async def flow_run_list(
    client: AppliedClient,
    flow_id: str | None = None,
    conversation_id: str | None = None,
    status: str | None = None,
    limit: int = 20,
    output_format: str = "csv",
) -> str:
    """
    List recent flow runs.

    Args:
        client: Authenticated AppliedClient
        flow_id: Filter by flow UUID
        conversation_id: Filter by conversation UUID
        status: Filter by status - 'Running', 'Success', 'Failed'
        limit: Max results (default 20)
        output_format: 'csv' or 'json'

    Returns:
        List of flow runs
    """
    runs = await client.list_flow_runs(
        flow_id=flow_id,
        conversation_id=conversation_id,
        status=status,
        limit=limit,
    )
    mapped = [
        {
            "id": r.get("id"),
            "flow_name": r.get("flow", {}).get("name", ""),
            "conversation_id": r.get("conversation_id", ""),
            "status": r.get("status"),
            "started_at": r.get("started_at", "")[:19],
            "duration": r.get("duration"),
        }
        for r in runs
    ]

    if output_format == "csv":
        return to_csv(
            mapped,
            ["id", "flow_name", "conversation_id", "status", "started_at", "duration"],
        )
    return to_json(mapped)


async def flow_run_get(
    client: AppliedClient,
    flow_run_id: str,
) -> str:
    """
    Get a flow run with execution trace.

    Args:
        client: Authenticated AppliedClient
        flow_run_id: The flow run UUID

    Returns:
        Run details, execution trace (spans), and errors
    """
    run = await client.get_flow_run(flow_run_id)

    # Header
    flow = run.get("flow", {})
    result = f"# Flow Run: {run.get('id')}\n"
    result += f"flow: {flow.get('name')} ({flow.get('id')})\n"
    result += f"status: {run.get('status')}\n"
    result += f"started_at: {run.get('started_at')}\n"
    result += f"ended_at: {run.get('ended_at')}\n"
    if run.get("duration"):
        result += f"duration: {run.get('duration')}s\n"

    # Execution trace from spans (API returns snake_case field names)
    spans = run.get("spans", [])
    if spans:
        result += f"\n## Execution Trace ({len(spans)} spans)\n"
        for i, span in enumerate(spans, 1):
            name = span.get("span_name", "")
            duration = span.get("duration", 0)
            status = span.get("status_code", "")
            status_msg = span.get("status_message", "")
            attrs = span.get("span_attributes", {})

            status_str = "OK" if "OK" in str(status) else "ERROR"
            result += f"{i}. [{name}] {duration:.2f}s - {status_str}"
            if status_msg:
                result += f" - {status_msg}"
            result += "\n"

            # executor_run: parse output JSON and show fields individually
            if name == "executor_run" and attrs.get("output"):
                try:
                    output_data = json.loads(attrs["output"])
                    for k, v in output_data.items():
                        if k == "success":
                            continue
                        result += f"   output.{k}: {str(v)[:300]}\n"
                except (json.JSONDecodeError, TypeError):
                    result += f"   output: {str(attrs['output'])[:500]}\n"

            # completion: show the LLM text output
            elif name == "completion" and attrs.get("content"):
                result += f"   completion: {str(attrs['content'])[:500]}\n"

            # structured_completion: show parsed output
            elif name == "structured_completion" and attrs.get("output"):
                try:
                    out = json.loads(attrs["output"])
                    result += f"   output: {json.dumps(out, indent=None)[:400]}\n"
                except (json.JSONDecodeError, TypeError):
                    result += f"   output: {str(attrs['output'])[:400]}\n"

            # branch: show routing decision and comparison breakdown
            elif name == "branch":
                selected = attrs.get("selected.path", "")
                if selected:
                    path_label = (
                        "default (no match)"
                        if selected == "default"
                        else f"branch {selected}"
                    )
                    result += f"   selected path: {path_label}\n"
                # Show comparison evaluations
                idx = 1
                while True:
                    op = attrs.get(f"comparison.{idx}.operator")
                    if not op:
                        break
                    lhs = attrs.get(f"comparison.{idx}.lhs", "?")
                    rhs = attrs.get(f"comparison.{idx}.rhs", "?")
                    res = attrs.get(f"comparison.{idx}.result", "?")
                    result += f"   comparison {idx}: {lhs} {op} {rhs} => {res}\n"
                    idx += 1

    # Actions
    actions = run.get("actions", [])
    if actions:
        result += f"\n## Actions ({len(actions)})\n"
        action_rows = [
            {
                "node": a.get("tool", {}).get("name", ""),
                "status": a.get("status"),
                "cost": a.get("cost", 0),
            }
            for a in actions
        ]
        result += to_csv(action_rows, ["node", "status", "cost"])

    # Errors section with detailed debugging info
    errors = [s for s in spans if "ERROR" in str(s.get("status_code", ""))]
    if errors:
        result += "\n## Errors\n"
        for err in errors:
            attrs = err.get("span_attributes", {})
            node_name = attrs.get("tool_name") or attrs.get("toolName") or "unknown"
            error_msg = err.get("status_message", "")

            result += f"**Node:** {node_name}\n"
            if error_msg:
                result += f"**Error:** {error_msg}\n"

            # Include relevant span attributes for debugging
            if attrs.get("output"):
                result += f"**Output:** {str(attrs.get('output'))[:500]}\n"
            if attrs.get("input"):
                result += f"**Input:** {str(attrs.get('input'))[:300]}\n"
            result += "\n"

    return result


async def conversation_spans(
    client: AppliedClient,
    conversation_id: str,
) -> str:
    """
    Get OpenTelemetry spans for a conversation.

    Args:
        client: Authenticated AppliedClient
        conversation_id: The conversation UUID

    Returns:
        Execution trace with spans, errors, and debugging info
    """
    spans = await client.get_spans("conversations", conversation_id)

    if not spans:
        return f"No spans found for conversation {conversation_id}"

    result = f"# Conversation Spans: {conversation_id}\n"
    result += f"Total spans: {len(spans)}\n"

    result += "\n## Execution Trace\n"
    for i, span in enumerate(spans, 1):
        name = span.get("span_name", "")
        scope = span.get("scope_name", "")
        duration = span.get("duration", 0)
        status = span.get("status_code", "")
        status_msg = span.get("status_message", "")
        attrs = span.get("span_attributes", {})

        # Build span identifier
        span_label = name or attrs.get("tool_name", "") or scope or "unknown"
        status_str = "OK" if "OK" in str(status) else "ERROR"

        result += f"{i}. [{span_label}] {duration:.2f}s - {status_str}"
        if status_msg:
            result += f"\n   Message: {status_msg}"
        result += "\n"

        # Show key attributes for debugging
        if attrs.get("output"):
            result += f"   Output: {str(attrs.get('output'))[:300]}\n"

    # Errors section
    errors = [s for s in spans if "ERROR" in str(s.get("status_code", ""))]
    if errors:
        result += "\n## Errors\n"
        for err in errors:
            attrs = err.get("span_attributes", {})
            node_name = attrs.get("tool_name") or err.get("span_name") or "unknown"
            error_msg = err.get("status_message", "")

            result += f"**Node:** {node_name}\n"
            if error_msg:
                result += f"**Error:** {error_msg}\n"
            result += "\n"

    return result


async def send_message(
    client: AppliedClient,
    agent_id: str,
    message: str,
    conversation_id: str | None = None,
    contact_email: str | None = None,
    contact_name: str | None = None,
    contact_phone: str | None = None,
    flow_id: str | None = None,
    metadata: dict | None = None,
    conversation_type: str | None = None,
) -> str:
    """
    Send a message to an agent and get the response.

    Use this to test conversational flows. After sending, you can query
    the conversation messages with conversation_get for full details.

    Args:
        client: Authenticated AppliedClient
        agent_id: The agent UUID to send the message to
        message: The user message to send
        conversation_id: Optional - continue an existing conversation
        contact_email: Optional contact email - creates a real Contact record
            so {trigger.contact.email} works in flows
        contact_name: Optional contact name
        contact_phone: Optional contact phone
        flow_id: Optional - force a specific flow to run (bypasses routing)
        metadata: Optional - custom fields accessible as {trigger.metadata.*} in flows,
            e.g. {"order_id": "12345", "status": "pending"}
        conversation_type: Optional - 'email', 'web_chat', 'sms', etc.

    Returns:
        Conversation ID, response preview, and status
    """
    try:
        result = await client.send_message(
            agent_id=agent_id,
            message=message,
            flow_id=flow_id,
            conversation_id=conversation_id,
            contact_email=contact_email,
            contact_name=contact_name,
            contact_phone=contact_phone,
            metadata=metadata,
            conversation_type=conversation_type,
        )

        output = "# Message Sent\n"
        output += f"conversation_id: {result.get('conversation_id')}\n"
        output += f"status: {result.get('status')}\n"

        response = result.get("response", "")
        if response:
            # Truncate long responses for preview
            preview = response[:500] + "..." if len(response) > 500 else response
            output += f"\n## Response Preview\n{preview}\n"

        output += "\n## Next Steps\n"
        output += (
            "- Use `conversation_get` with the conversation_id to see full messages\n"
        )
        output += "- Use `flow_run_list` with conversation_id to see flow runs\n"
        output += "- Use `conversation_spans` for detailed execution trace\n"

        return output

    except Exception as e:
        return f"Error sending message: {e}"


async def executor_list(
    client: AppliedClient,
    output_format: str = "full",
) -> str:
    """
    List available node types (executors) with their metadata schemas.

    Args:
        client: Authenticated AppliedClient (not used, list is hardcoded)
        output_format: 'full' (default, includes schemas), 'csv' (names only), 'json'

    Returns:
        Available executor types with descriptions and metadata field schemas
    """
    # Hardcoded list of executors with metadata schemas
    executors = [
        {
            "name": "completion",
            "description": "LLM completion - generates free-form text",
            "use_case": "Responses, summaries, any text output",
            "metadata_fields": {
                "model": "string - LLM model (default: agent's model)",
                "temperature": "float - 0.0-1.0 (default: 0.7)",
                "max_tokens": "int - max output tokens",
                "exact_response": "bool - use prompt text verbatim without LLM modification",
                "continue_from_state": "bool - include conversation history as context",
                "reasoning_level": "string - 'minimal', 'low', 'medium', or 'high'",
                "response_mode": "string - 'ask' (wait for response) or 'inform' (continue)",
            },
            "output_fields": ["completion"],
        },
        {
            "name": "structured_completion",
            "description": "LLM completion with structured JSON output",
            "use_case": "Extract data, classify, typed responses",
            "metadata_fields": {
                "model": "string - LLM model",
                "output_schema": "object - JSON Schema for output structure",
            },
            "output_fields": ["(defined by output_schema)"],
        },
        {
            "name": "branch",
            "description": "Conditional branching based on comparison or LLM",
            "use_case": "Route flow based on conditions",
            "metadata_fields": {
                "branch_type": "'comparison' or 'llm'",
                "branches": "array - branch definitions with conditions",
            },
            "output_fields": ["selected_branch"],
        },
        {
            "name": "code",
            "description": "Execute Python code in sandbox",
            "use_case": "Data transformation, calculations, API calls",
            "metadata_fields": {
                "language": "string - 'python' (required)",
                "code": "string - Python code to execute (required)",
                "packages": "array - pip packages to install, e.g. ['requests']",
            },
            "output_fields": ["result", "stdout", "stderr"],
        },
        {
            "name": "http_request",
            "description": "Make HTTP API calls",
            "use_case": "Integrate with external APIs",
            "metadata_fields": {
                "method": "string - GET, POST, PUT, DELETE",
                "url": "string - endpoint URL (supports {var} interpolation)",
                "headers": "object - request headers",
                "body": "object - request body for POST/PUT",
            },
            "output_fields": ["status_code", "data", "headers"],
        },
        {
            "name": "loop",
            "description": "Loop over a list and execute subflow",
            "use_case": "Process multiple items, batch operations",
            "metadata_fields": {
                "items_path": "string - variable path to iterate, e.g. {trigger.items}",
                "max_iterations": "int - limit iterations",
            },
            "output_fields": ["results", "count"],
        },
        {
            "name": "memory",
            "description": "Store/retrieve data in conversation memory",
            "use_case": "Remember user preferences, context across turns",
            "metadata_fields": {
                "operation": "'get' or 'set'",
                "key": "string - memory key",
                "value": "any - value to store (for set)",
            },
            "output_fields": ["value"],
        },
        {
            "name": "search",
            "description": "Search knowledge base",
            "use_case": "Find relevant documentation or Q&A",
            "metadata_fields": {
                "query": "string - search query (supports {var} interpolation)",
                "limit": "int - max results",
            },
            "output_fields": ["results", "count"],
        },
        {
            "name": "global",
            "description": "Global handler for escalation or failure",
            "use_case": "Catch-all for errors, default handler",
            "metadata_fields": {},
            "output_fields": [],
        },
        {
            "name": "_escalate_conversation",
            "description": "Escalate conversation to human agent",
            "use_case": "Hand off to support team",
            "metadata_fields": {
                "reason": "string - escalation reason",
            },
            "output_fields": [],
        },
        {
            "name": "handoff",
            "description": "Hand off to another flow or agent",
            "use_case": "Transfer to specialized flow",
            "metadata_fields": {
                "target_flow_id": "string - flow to hand off to",
            },
            "output_fields": [],
        },
        {
            "name": "end_flow",
            "description": "Explicitly end the flow",
            "use_case": "Terminate flow execution early",
            "metadata_fields": {},
            "output_fields": [],
        },
        {
            "name": "resource",
            "description": "Call external integration (Shopify, Slack, Stripe, etc.)",
            "use_case": "Fetch orders, cancel orders, send Slack messages, query databases",
            "metadata_fields": {
                "resource_type": "string - 'shopify', 'slack', 'stripe', 'snowflake', etc.",
                "action": "string - operation name (e.g., 'get_order', 'cancel_order')",
                "resource_id": "string - UUID of the configured integration",
                "action_input": "object - action parameters with {var} interpolation",
                "format_with_variables": "boolean - set true when action_input uses {var}",
            },
            "output_fields": ["data", "success"],
        },
        {
            "name": "flow",
            "description": "Call another flow as a subflow",
            "use_case": "Reuse common logic, modular flow composition",
            "metadata_fields": {
                "flow_id": "string - UUID of the subflow to call (required)",
                "flow_input": "object - map trigger inputs using {var} interpolation",
                "async_execution_delay_unit": "string - 'seconds', 'minutes', etc. (optional)",
            },
            "output_fields": ["(defined by subflow's end_flow output_schema)"],
        },
        {
            "name": "mutate_ticket",
            "description": "Create or update a support ticket",
            "use_case": "Create tickets for tracking, assign to queues",
            "metadata_fields": {
                "name": "string - ticket title (required, supports {var})",
                "tags": "array - list of tag strings",
                "description": "string - ticket body (supports {var})",
                "conversation_id": "string - link to conversation",
            },
            "output_fields": ["ticket_id"],
        },
        {
            "name": "mutate_conversation",
            "description": "Update conversation properties",
            "use_case": "Set conversation type, add flags for routing/analytics",
            "metadata_fields": {
                "type": "string - 'web_chat', 'email', etc.",
                "flags": "array - list of flag UUIDs to apply",
            },
            "output_fields": [],
        },
        {
            "name": "mutate_message",
            "description": "Add a message to the conversation",
            "use_case": "Inject system messages, add notes",
            "metadata_fields": {
                "role": "string - 'system', 'assistant', 'user'",
                "content": "string - message content (supports {var})",
            },
            "output_fields": [],
        },
        {
            "name": "recommend",
            "description": "Product recommendations using AI",
            "use_case": "Recommend products from catalog based on conversation context",
            "metadata_fields": {
                "thinking_level": "string - 'minimal', 'low', or 'medium' (reasoning depth)",
                "content_ids": "array - specific content UUIDs to consider (empty = all)",
                "content_types": "array - content types to include, e.g. ['Product']",
                "max_recommendations": "int - max items to recommend (1-10, default 3)",
                "metric_name": "string - analytics metric name (optional)",
                "cta_metric_name": "string - metric name for primary CTA clicks (optional)",
            },
            "output_fields": ["success", "recommendations"],
        },
    ]

    if output_format == "csv":
        simple = [
            {"name": e["name"], "description": e["description"]} for e in executors
        ]
        return to_csv(simple, ["name", "description"])

    if output_format == "json":
        return to_json(executors)

    # Full output with schemas
    result = "# Available Node Types (Executors)\n\n"
    result += "Use these with flow_node_create(executor_type=...)\n\n"

    for ex in executors:
        result += f"## {ex['name']}\n"
        result += f"{ex['description']}\n"
        result += f"Use case: {ex['use_case']}\n"

        if ex.get("metadata_fields"):
            result += "\n**Metadata fields:**\n"
            for field, desc in ex["metadata_fields"].items():
                result += f"  - `{field}`: {desc}\n"

        if ex.get("output_fields"):
            result += f"\n**Output fields:** {', '.join(ex['output_fields'])}\n"

        result += "\n"

    result += "## Variable Reference Syntax\n"
    result += "Reference previous node outputs in prompts and metadata:\n"
    result += "- `{trigger.message}` - user's input message\n"
    result += "- `{trigger.contact.email}` - contact email\n"
    result += "- `{node_name.field}` - output from previous node\n"
    result += "- `{code-abc123.result}` - code node output\n"
    result += "- `{http_request-xyz.data.items}` - nested API response\n"

    return result


# -----------------------------------------------------------------------------
# Flow Variables
# -----------------------------------------------------------------------------

# Known output fields for each executor type
_EXECUTOR_OUTPUTS: dict[str, list[dict]] = {
    "completion": [
        {"field": "completion", "type": "string", "desc": "LLM generated text"},
    ],
    "structured_completion": [
        # Dynamic - parsed from output_schema in metadata
    ],
    "code": [
        {"field": "result", "type": "any", "desc": "Return value from code"},
        {"field": "stdout", "type": "string", "desc": "Standard output"},
        {"field": "stderr", "type": "string", "desc": "Standard error"},
    ],
    "http_request": [
        {"field": "status_code", "type": "integer", "desc": "HTTP status code"},
        {"field": "data", "type": "object", "desc": "Response body (JSON)"},
        {"field": "headers", "type": "object", "desc": "Response headers"},
    ],
    "branch": [
        {
            "field": "selected_branch",
            "type": "string",
            "desc": "Which branch was taken",
        },
    ],
    "loop": [
        {"field": "results", "type": "array", "desc": "Results from each iteration"},
        {"field": "count", "type": "integer", "desc": "Number of iterations"},
    ],
    "memory": [
        {"field": "value", "type": "any", "desc": "Retrieved memory value"},
    ],
    "search": [
        {"field": "results", "type": "array", "desc": "Search results"},
        {"field": "count", "type": "integer", "desc": "Number of results"},
    ],
    "trigger": [
        # Shown separately in built-in context section
    ],
}


def _parse_output_schema(metadata: dict) -> list[dict]:
    """
    Parse output_schema from structured_completion metadata.

    Returns list of {"field": "name", "type": "string", "desc": "..."}
    """
    output_schema = metadata.get("output_schema", [])
    fields = []

    # Handle array format: [{"name": "field", "type": "string", "description": "..."}]
    if isinstance(output_schema, list):
        for item in output_schema:
            if isinstance(item, dict) and item.get("name"):
                fields.append(
                    {
                        "field": item["name"],
                        "type": item.get("type", "any"),
                        "desc": item.get("description", "")[:40],
                    }
                )
    # Handle object format: {"properties": {"field": {"type": "string"}}}
    elif isinstance(output_schema, dict):
        props = output_schema.get("properties", {})
        for name, prop in props.items():
            fields.append(
                {
                    "field": name,
                    "type": prop.get("type", "any"),
                    "desc": prop.get("description", "")[:40],
                }
            )

    return fields


def _extract_schema_paths(
    schema: dict,
    prefix: str = "",
    defs: dict | None = None,
    max_depth: int = 4,
) -> list[dict]:
    """
    Recursively extract variable paths from a JSON Schema.

    Returns list of {"path": "field.subfield", "type": "string", "description": "..."}
    """
    if max_depth <= 0:
        return []

    defs = defs or schema.get("$defs", {})
    paths = []

    # Handle $ref
    if "$ref" in schema:
        ref_name = schema["$ref"].split("/")[-1]
        if ref_name in defs:
            return _extract_schema_paths(defs[ref_name], prefix, defs, max_depth)
        return []

    # Handle anyOf/oneOf (take first option)
    if "anyOf" in schema:
        for option in schema["anyOf"]:
            if option.get("type") != "null":
                return _extract_schema_paths(option, prefix, defs, max_depth)
        return []

    schema_type = schema.get("type", "")

    if schema_type == "object":
        props = schema.get("properties", {})
        for prop_name, prop_schema in props.items():
            path = f"{prefix}.{prop_name}" if prefix else prop_name
            prop_type = prop_schema.get("type", "any")
            desc = prop_schema.get("description", "")

            # Add this path
            paths.append({"path": path, "type": prop_type, "description": desc[:60]})

            # Recurse for nested objects/arrays
            if prop_type == "object":
                paths.extend(
                    _extract_schema_paths(prop_schema, path, defs, max_depth - 1)
                )
            elif prop_type == "array":
                items = prop_schema.get("items", {})
                if items:
                    # Add [0] and [*] access patterns
                    paths.append(
                        {
                            "path": f"{path}[0]",
                            "type": "item",
                            "description": "First item",
                        }
                    )
                    paths.append(
                        {
                            "path": f"{path}[*]",
                            "type": "list",
                            "description": "Map over all",
                        }
                    )
                    # Recurse into array items
                    paths.extend(
                        _extract_schema_paths(items, f"{path}[0]", defs, max_depth - 1)
                    )

    elif schema_type == "array":
        items = schema.get("items", {})
        if items and prefix:
            paths.append(
                {"path": f"{prefix}[0]", "type": "item", "description": "First item"}
            )
            paths.extend(
                _extract_schema_paths(items, f"{prefix}[0]", defs, max_depth - 1)
            )

    return paths


def _get_node_type_order(node_type: str) -> int:
    """Get sort priority for node type (matches frontend flow-variables.tsx)."""
    if node_type == "trigger":
        return 0
    elif node_type == "global":
        return 1
    return 2


def _get_node_name(node: dict) -> str:
    """Get display name for a node."""
    data = node.get("data", {})
    return data.get("humanReadableName") or data.get("name") or node.get("id", "")


def _compare_nodes(
    a: dict,
    b: dict,
    indegree: dict[str, int],
    flow_type: str,
) -> int:
    """
    Compare two nodes for sorting (matches frontend flow-variables.tsx).

    Sort order:
    1. Node type (trigger first, then global, then others)
    2. Indegree (fewer incoming edges first)
    3. Position (X then Y for conversational, Y then X for operational)
    4. Alphabetical by name
    """
    a_type = a.get("type", a.get("data", {}).get("executor_type", ""))
    b_type = b.get("type", b.get("data", {}).get("executor_type", ""))

    a_type_order = _get_node_type_order(a_type)
    b_type_order = _get_node_type_order(b_type)
    if a_type_order != b_type_order:
        return a_type_order - b_type_order

    a_indegree = indegree.get(a["id"], 0)
    b_indegree = indegree.get(b["id"], 0)
    if a_indegree != b_indegree:
        return a_indegree - b_indegree

    a_pos = a.get("position", {})
    b_pos = b.get("position", {})

    if flow_type == "conversational":
        # Conversational: sort by X then Y
        a_x = a_pos.get("x", 0) or 0
        b_x = b_pos.get("x", 0) or 0
        if a_x != b_x:
            return -1 if a_x < b_x else 1

        a_y = a_pos.get("y", 0) or 0
        b_y = b_pos.get("y", 0) or 0
        if a_y != b_y:
            return -1 if a_y < b_y else 1
    else:
        # Operational: sort by Y then X
        a_y = a_pos.get("y", 0) or 0
        b_y = b_pos.get("y", 0) or 0
        if a_y != b_y:
            return -1 if a_y < b_y else 1

        a_x = a_pos.get("x", 0) or 0
        b_x = b_pos.get("x", 0) or 0
        if a_x != b_x:
            return -1 if a_x < b_x else 1

    # Alphabetical fallback
    a_name = _get_node_name(a)
    b_name = _get_node_name(b)
    if a_name < b_name:
        return -1
    elif a_name > b_name:
        return 1
    return 0


def _get_node_indices(
    nodes: list[dict],
    edges: list[dict],
    flow_type: str,
) -> dict[str, int]:
    """
    Calculate node indices matching the UI numbering (flow-variables.tsx).

    For conversational flows: DFS traversal
    For operational flows: Topological sort (Kahn's algorithm)

    Returns dict mapping node_id -> 1-based index
    """
    from functools import cmp_to_key

    node_map = {n["id"]: n for n in nodes}

    # Build adjacency list and indegree
    adjacency: dict[str, list[str]] = {n["id"]: [] for n in nodes}
    indegree: dict[str, int] = {n["id"]: 0 for n in nodes}

    for e in edges:
        src, tgt = e.get("source"), e.get("target")
        if src in node_map and tgt in node_map:
            adjacency[src].append(tgt)
            indegree[tgt] = indegree.get(tgt, 0) + 1

    node_indices: dict[str, int] = {}
    index = 1

    def compare_fn(a_id: str, b_id: str) -> int:
        return _compare_nodes(node_map[a_id], node_map[b_id], indegree, flow_type)

    if flow_type == "conversational":
        # DFS traversal
        def dfs(node_id: str) -> None:
            nonlocal index
            node_indices[node_id] = index
            index += 1

            neighbors = sorted(adjacency[node_id], key=cmp_to_key(compare_fn))
            for neighbor in neighbors:
                if neighbor not in node_indices:
                    dfs(neighbor)

        sorted_node_ids = sorted(node_map.keys(), key=cmp_to_key(compare_fn))
        for node_id in sorted_node_ids:
            if node_id not in node_indices:
                dfs(node_id)
    else:
        # Topological sort (Kahn's algorithm) - operational flows
        # Make a copy of indegree since we modify it
        working_indegree = dict(indegree)

        def topo_sort(node_ids: list[str]) -> None:
            nonlocal index
            if not node_ids:
                return

            sorted_ids = sorted(node_ids, key=cmp_to_key(compare_fn))
            for node_id in sorted_ids:
                node_indices[node_id] = index
                index += 1

                queue: list[str] = []
                for neighbor in adjacency[node_id]:
                    working_indegree[neighbor] -= 1
                    if working_indegree[neighbor] == 0:
                        queue.append(neighbor)

                topo_sort(queue)

        root_nodes = [nid for nid, deg in working_indegree.items() if deg == 0]
        topo_sort(root_nodes)

    return node_indices


def _topological_sort(nodes: list[dict], edges: list[dict]) -> list[dict]:
    """Sort nodes in topological order based on edges (legacy helper)."""
    node_map = {n["id"]: n for n in nodes}
    in_degree = {n["id"]: 0 for n in nodes}
    children = {n["id"]: [] for n in nodes}

    for e in edges:
        src, tgt = e.get("source"), e.get("target")
        if src in node_map and tgt in node_map:
            children[src].append(tgt)
            in_degree[tgt] = in_degree.get(tgt, 0) + 1

    # Kahn's algorithm
    queue = [nid for nid, deg in in_degree.items() if deg == 0]
    result = []

    while queue:
        nid = queue.pop(0)
        result.append(node_map[nid])
        for child in children.get(nid, []):
            in_degree[child] -= 1
            if in_degree[child] == 0:
                queue.append(child)

    return result


def _get_node_output_fields(node: dict) -> list[dict]:
    """
    Get output fields for a node based on its type and configuration.

    Returns list of {"field": "name", "type": "string", "desc": "..."}
    """
    node_data = node.get("data", {})
    node_type = node.get("type", node_data.get("executor_type", ""))
    metadata = node_data.get("metadata", {})

    # For structured_completion, parse output_schema from metadata
    if node_type == "structured_completion":
        fields = _parse_output_schema(metadata)
        if fields:
            return fields

    # For other types, use known outputs
    return _EXECUTOR_OUTPUTS.get(node_type, [])


async def flow_variables(
    client: AppliedClient,
    flow_id: str,
    node_id: str | None = None,
) -> str:
    """
    List available variables for a flow, showing what can be referenced in prompts
    and node configurations using {node_name.field} syntax.

    Dynamically inspects all nodes in the flow and shows their output fields,
    including custom fields from structured_completion output_schema.

    Args:
        client: Authenticated AppliedClient
        flow_id: The flow UUID
        node_id: Optional - show only variables available to this specific node
                 (predecessors in the graph). If omitted, shows all variables.

    Returns:
        Formatted list of available variables grouped by source node,
        with paths, types, and descriptions.

    Example output:
        ## 1. trigger
        {trigger.message}              string   User's message
        {trigger.shop.is_open}         boolean  Business hours check

        ## 2. structured_completion-abc123
        {structured_completion-abc123.order_id}     string   Extracted order ID
        {structured_completion-abc123.refund_reason} string   Refund reason

        ## 3. http_request-xyz789
        {http_request-xyz789.data}          object   Response body
        {http_request-xyz789.status_code}   integer  HTTP status
    """
    flow = await client.get_flow(flow_id)
    graph = flow.get("graph", {})
    nodes = graph.get("nodes", [])
    edges = graph.get("edges", [])
    flow_type = flow.get("type", "conversational")

    # Calculate node indices matching UI numbering
    node_indices = _get_node_indices(nodes, edges, flow_type)

    # Sort nodes by their index
    sorted_nodes = sorted(nodes, key=lambda n: node_indices.get(n["id"], 999))

    # If node_id specified, find its predecessors
    if node_id:
        # Build predecessor set via BFS backwards
        parents = {n["id"]: set() for n in nodes}
        for e in edges:
            tgt = e.get("target")
            src = e.get("source")
            if tgt and src:
                parents[tgt].add(src)

        # BFS to find all ancestors
        ancestors = set()
        queue = list(parents.get(node_id, set()))
        while queue:
            p = queue.pop(0)
            if p not in ancestors:
                ancestors.add(p)
                queue.extend(parents.get(p, set()))

        # Filter to only ancestor nodes
        sorted_nodes = [n for n in sorted_nodes if n["id"] in ancestors]

    result = "# Available Variables for Flow\n"
    result += "Use {node_name.field} syntax in prompts and metadata.\n\n"

    nodes_shown = 0

    for node in sorted_nodes:
        node_data = node.get("data", {})
        node_name = _get_node_name(node)
        node_type = node.get("type", node_data.get("executor_type", ""))
        idx = node_indices.get(node["id"], "?")

        # Skip trigger (handled separately) and global nodes
        if node_type in ("trigger", "global", "_escalate_conversation"):
            continue

        # Get output fields for this node type
        output_fields = _get_node_output_fields(node)

        # Also check if node has outputs schema from backend
        outputs_schema = node_data.get("outputs", {})
        if outputs_schema and outputs_schema.get("properties"):
            schema_paths = _extract_schema_paths(outputs_schema)
            # Merge with known fields
            seen_fields = {f["field"] for f in output_fields}
            for p in schema_paths:
                if p["path"] not in seen_fields and "." not in p["path"]:
                    output_fields.append(
                        {
                            "field": p["path"],
                            "type": p["type"],
                            "desc": p["description"][:40] if p["description"] else "",
                        }
                    )

        # Skip nodes with no outputs
        if not output_fields:
            continue

        nodes_shown += 1
        result += f"## {idx}. {node_name}"
        if node_type and node_type != node_name.split("-")[0]:
            result += f" ({node_type})"
        result += "\n"

        for f in output_fields:
            var_path = f"{{{node_name}.{f['field']}}}"
            type_str = str(f["type"])[:10].ljust(10)
            desc = f.get("desc", "")
            result += f"  {var_path:<50} {type_str} {desc}\n"

        result += "\n"

    if nodes_shown == 0:
        result += "(No nodes with outputs yet - add completion, code, or http_request nodes)\n\n"

    result += "## Built-in Trigger Context (llm.call trigger)\n"
    result += "The trigger node always provides these fields:\n\n"
    result += "**{trigger.shop}** - Workspace/shop object:\n"
    result += (
        "  {trigger.shop.is_open}          boolean    whether shop is currently open\n"
    )
    result += "  {trigger.shop.name}             string     shop name\n"
    result += "  {trigger.shop.timezone}         string     e.g. 'America/New_York'\n"
    result += "  {trigger.shop.address}          string     shop address\n"
    result += "\n"
    result += "**{trigger.contact}** - Customer contact:\n"
    result += "  {trigger.contact.email}         string     contact email\n"
    result += "  {trigger.contact.name}          string     contact name\n"
    result += "  {trigger.contact.phone}         string     contact phone\n"
    result += "\n"
    result += "**{trigger.conversation}** - Current conversation:\n"
    result += "  {trigger.conversation.id}       string     conversation UUID\n"
    result += "  {trigger.conversation.title}    string     conversation title\n"
    result += (
        "  {trigger.conversation.resolution} string   e.g. 'resolved', 'escalated'\n"
    )
    result += "\n"
    result += "**{trigger.messages}** - Message history (array)\n"
    result += "**{trigger.attachments}** - Uploaded files (array)\n"
    result += "**{trigger.current_time}** - ISO timestamp (string)\n"
    result += "\n"
    result += "## Tips\n"
    result += (
        "- Check {trigger.shop.is_open} in a branch instead of writing a code node\n"
    )
    result += (
        "- Reference node outputs: {completion-abc.completion}, {code-xyz.result}\n"
    )
    result += "- Access nested fields with dots: {http_request-api.data.order.status}\n"

    return result


# -----------------------------------------------------------------------------
# Benchmarks
# -----------------------------------------------------------------------------


async def benchmark_list(
    client: AppliedClient,
    agent_id: str | None = None,
    output_format: str = "csv",
) -> str:
    """
    List conversation benchmarks.

    Args:
        client: Authenticated AppliedClient
        agent_id: Optional - filter by agent UUID
        output_format: 'csv' or 'json'

    Returns:
        List of benchmarks with id, name, agent, scenario count
    """
    benchmarks = await client.list_benchmarks(agent_id=agent_id)
    mapped = [
        {
            "id": b.get("id"),
            "name": b.get("name"),
            "agent_name": b.get("agent", {}).get("name", ""),
            "scenario_count": b.get("scenario_count", 0),
            "description": str(b.get("description", ""))[:80],
        }
        for b in benchmarks
    ]

    if output_format == "csv":
        return to_csv(
            mapped, ["id", "name", "agent_name", "scenario_count", "description"]
        )
    return to_json(mapped)


async def benchmark_get(
    client: AppliedClient,
    benchmark_id: str,
) -> str:
    """
    Get a single benchmark with details.

    Args:
        client: Authenticated AppliedClient
        benchmark_id: The benchmark UUID

    Returns:
        Benchmark details including scenarios
    """
    benchmark = await client.get_benchmark(benchmark_id)

    result = f"# Benchmark: {benchmark.get('name')}\n"
    result += f"id: {benchmark.get('id')}\n"
    result += f"description: {benchmark.get('description', '')}\n"

    agent = benchmark.get("agent", {})
    if agent:
        result += f"agent: {agent.get('name')} ({agent.get('id')})\n"

    result += f"scenario_count: {benchmark.get('scenario_count', 0)}\n"
    result += f"created_at: {str(benchmark.get('created_at', ''))[:19]}\n"

    return result


async def benchmark_create(
    client: AppliedClient,
    agent_id: str,
    name: str,
    description: str = "",
) -> str:
    """
    Create a new benchmark.

    Args:
        client: Authenticated AppliedClient
        agent_id: Agent UUID to associate benchmark with
        name: Benchmark name
        description: Optional description

    Returns:
        Created benchmark with ID
    """
    try:
        benchmark = await client.create_benchmark(
            agent_id=agent_id, name=name, description=description
        )
    except AppliedAPIError as e:
        return _format_error(e)

    result = "# Created Benchmark\n"
    result += f"id: {benchmark.get('id')}\n"
    result += f"name: {benchmark.get('name')}\n"

    return result


# -----------------------------------------------------------------------------
# Scenarios
# -----------------------------------------------------------------------------


async def scenario_list(
    client: AppliedClient,
    benchmark_id: str | None = None,
    agent_id: str | None = None,
    pass_status: str | None = None,
    output_format: str = "csv",
) -> str:
    """
    List conversation scenarios.

    Args:
        client: Authenticated AppliedClient
        benchmark_id: Optional - filter by benchmark UUID
        agent_id: Optional - filter by agent UUID
        pass_status: Optional - filter by pass status ('pass', 'fail', 'unrated')
        output_format: 'csv' or 'json'

    Returns:
        List of scenarios with id, name, pass_status, csat_score
    """
    scenarios = await client.list_scenarios(
        benchmark_id=benchmark_id, agent_id=agent_id, pass_status=pass_status
    )
    mapped = [
        {
            "id": s.get("id"),
            "name": s.get("name"),
            "pass_status": s.get("pass_status", "unrated"),
            "csat_score": s.get("csat_score"),
            "benchmark_name": s.get("benchmark", {}).get("name", ""),
        }
        for s in scenarios
    ]

    if output_format == "csv":
        return to_csv(
            mapped, ["id", "name", "pass_status", "csat_score", "benchmark_name"]
        )
    return to_json(mapped)


async def scenario_get(
    client: AppliedClient,
    scenario_id: str,
    include_runs: bool = True,
) -> str:
    """
    Get a single scenario with details.

    Args:
        client: Authenticated AppliedClient
        scenario_id: The scenario UUID
        include_runs: Include recent scenario runs (default True)

    Returns:
        Scenario details including input conversation and recent runs
    """
    scenario = await client.get_scenario(scenario_id)

    result = f"# Scenario: {scenario.get('name')}\n"
    result += f"id: {scenario.get('id')}\n"
    result += f"pass_status: {scenario.get('pass_status', 'unrated')}\n"
    result += f"csat_score: {scenario.get('csat_score')}\n"
    result += f"feedback: {scenario.get('feedback', '')}\n"

    benchmark = scenario.get("benchmark", {})
    if benchmark:
        result += "\n## Benchmark\n"
        result += f"name: {benchmark.get('name')}\n"
        result += f"id: {benchmark.get('id')}\n"

    input_conv = scenario.get("input_conversation", {})
    if input_conv:
        result += "\n## Input Conversation\n"
        result += f"id: {input_conv.get('id')}\n"
        result += f"title: {input_conv.get('title', '')}\n"

    if include_runs:
        runs = await client.list_scenario_runs(scenario_id=scenario_id, limit=5)
        if runs:
            result += f"\n## Recent Runs ({len(runs)})\n"
            for run in runs:
                status = run.get("pass_status", "unrated")
                csat = run.get("csat_score", "-")
                created = str(run.get("created_at", ""))[:19]
                result += f"- {run.get('id')}: {status} (CSAT: {csat}) - {created}\n"

    return result


async def scenario_create(
    client: AppliedClient,
    input_conversation_id: str,
    name: str,
    benchmark_id: str | None = None,
    benchmark_name: str | None = None,
    agent_id: str | None = None,
) -> str:
    """
    Create a scenario from an existing conversation.

    Args:
        client: Authenticated AppliedClient
        input_conversation_id: Source conversation UUID
        name: Scenario name
        benchmark_id: Optional benchmark UUID to add scenario to
        benchmark_name: Optional - creates new benchmark if not exists
        agent_id: Required if benchmark_name is provided

    Returns:
        Created scenario with ID
    """
    try:
        scenario = await client.create_scenario(
            input_conversation_id=input_conversation_id,
            name=name,
            benchmark_id=benchmark_id,
            benchmark_name=benchmark_name,
            agent_id=agent_id,
        )
    except AppliedAPIError as e:
        return _format_error(e)

    result = "# Created Scenario\n"
    result += f"id: {scenario.get('id')}\n"
    result += f"name: {scenario.get('name')}\n"

    benchmark = scenario.get("benchmark", {})
    if benchmark:
        result += f"benchmark: {benchmark.get('name')} ({benchmark.get('id')})\n"

    return result


async def scenario_update(
    client: AppliedClient,
    scenario_id: str,
    pass_status: str | None = None,
    csat_score: float | None = None,
    feedback: str | None = None,
) -> str:
    """
    Update a scenario's rating.

    Args:
        client: Authenticated AppliedClient
        scenario_id: The scenario UUID
        pass_status: 'pass', 'fail', or 'unrated'
        csat_score: Customer satisfaction score (1-5)
        feedback: Notes/feedback on the scenario

    Returns:
        Updated scenario
    """
    updates: dict = {}
    if pass_status is not None:
        updates["pass_status"] = pass_status
    if csat_score is not None:
        updates["csat_score"] = csat_score
    if feedback is not None:
        updates["feedback"] = feedback

    try:
        scenario = await client.update_scenario(scenario_id, **updates)
    except AppliedAPIError as e:
        return _format_error(e)

    return f"# Updated Scenario: {scenario.get('name')}\npass_status: {scenario.get('pass_status')}\ncsat_score: {scenario.get('csat_score')}"


# -----------------------------------------------------------------------------
# Scenario Runs
# -----------------------------------------------------------------------------


async def scenario_run_list(
    client: AppliedClient,
    scenario_id: str | None = None,
    benchmark_id: str | None = None,
    latest: bool = True,
    output_format: str = "csv",
) -> str:
    """
    List scenario runs.

    Args:
        client: Authenticated AppliedClient
        scenario_id: Optional - filter by scenario UUID
        benchmark_id: Optional - filter by benchmark UUID
        latest: If True, show only the most recent run per scenario (default True)
        output_format: 'csv' or 'json'

    Returns:
        List of scenario runs with id, scenario_name, pass_status, csat_score
    """
    runs = await client.list_scenario_runs(
        scenario_id=scenario_id, benchmark_id=benchmark_id, latest=latest
    )
    mapped = [
        {
            "id": r.get("id"),
            "scenario_name": r.get("scenario", {}).get("name", ""),
            "pass_status": r.get("pass_status", "unrated"),
            "csat_score": r.get("csat_score"),
            "created_at": str(r.get("created_at", ""))[:19],
        }
        for r in runs
    ]

    if output_format == "csv":
        return to_csv(
            mapped, ["id", "scenario_name", "pass_status", "csat_score", "created_at"]
        )
    return to_json(mapped)


async def scenario_run_get(
    client: AppliedClient,
    run_id: str,
) -> str:
    """
    Get a single scenario run with details.

    Args:
        client: Authenticated AppliedClient
        run_id: The scenario run UUID

    Returns:
        Run details including output conversation and feedback
    """
    run = await client.get_scenario_run(run_id)

    result = "# Scenario Run\n"
    result += f"id: {run.get('id')}\n"
    result += f"pass_status: {run.get('pass_status', 'unrated')}\n"
    result += f"csat_score: {run.get('csat_score')}\n"
    result += f"feedback: {run.get('feedback', '')}\n"
    result += f"created_at: {str(run.get('created_at', ''))[:19]}\n"

    scenario = run.get("scenario", {})
    if scenario:
        result += "\n## Scenario\n"
        result += f"name: {scenario.get('name')}\n"
        result += f"id: {scenario.get('id')}\n"

    output_conv = run.get("output_conversation", {})
    if output_conv:
        result += "\n## Output Conversation\n"
        result += f"id: {output_conv.get('id')}\n"
        result += f"title: {output_conv.get('title', '')}\n"

    return result


async def scenario_run_update(
    client: AppliedClient,
    run_id: str,
    pass_status: str | None = None,
    csat_score: float | None = None,
    feedback: str | None = None,
) -> str:
    """
    Update a scenario run's rating.

    Args:
        client: Authenticated AppliedClient
        run_id: The scenario run UUID
        pass_status: 'pass', 'fail', or 'unrated'
        csat_score: Customer satisfaction score (1-5)
        feedback: Notes/feedback on the run

    Returns:
        Updated scenario run
    """
    updates: dict = {}
    if pass_status is not None:
        updates["pass_status"] = pass_status
    if csat_score is not None:
        updates["csat_score"] = csat_score
    if feedback is not None:
        updates["feedback"] = feedback

    try:
        run = await client.update_scenario_run(run_id, **updates)
    except AppliedAPIError as e:
        return _format_error(e)

    return f"# Updated Scenario Run\nid: {run.get('id')}\npass_status: {run.get('pass_status')}\ncsat_score: {run.get('csat_score')}"


async def scenario_bulk_run(
    client: AppliedClient,
    scenario_ids: list[str] | None = None,
    benchmark_id: str | None = None,
    target_agent_id: str | None = None,
) -> str:
    """
    Run multiple scenarios at once.

    Args:
        client: Authenticated AppliedClient
        scenario_ids: List of scenario UUIDs to run
        benchmark_id: Run all scenarios in this benchmark
        target_agent_id: Optional agent to run against (for A/B testing)

    Returns:
        Summary of runs created
    """
    try:
        result = await client.bulk_run_scenarios(
            scenario_ids=scenario_ids,
            benchmark_id=benchmark_id,
            target_agent_id=target_agent_id,
        )
    except AppliedAPIError as e:
        return _format_error(e)

    runs = result.get("runs", [])
    output = "# Bulk Run Started\n"
    output += f"runs_created: {len(runs)}\n"

    if runs:
        output += "\n## Runs\n"
        for run in runs[:10]:  # Show first 10
            scenario_name = run.get("scenario", {}).get("name", "")
            output += f"- {run.get('id')}: {scenario_name}\n"

        if len(runs) > 10:
            output += f"... and {len(runs) - 10} more\n"

    return output


# -----------------------------------------------------------------------------
# Knowledge Base - Create/Update
# -----------------------------------------------------------------------------


async def knowledge_create(
    client: AppliedClient,
    kb_type: str,
    question: str,
    answer: str,
    guardrail: str = "",
    active: bool = True,
    agent_ids: list[str] | None = None,
    label_id: str | None = None,
    flow_id: str | None = None,
) -> str:
    """
    Create a new knowledge base item.

    Args:
        client: Authenticated AppliedClient
        kb_type: Type - 'qa', 'exact', 'escalate', 'context', 'greeting', 'signature'
        question: Trigger text / question
        answer: Response text / answer
        guardrail: Optional guardrail instructions
        active: Whether the item is active (default True)
        agent_ids: Optional list of agent UUIDs to assign to
        label_id: Optional label UUID for categorization
        flow_id: Optional flow UUID to associate with

    Returns:
        Created knowledge item with ID
    """
    try:
        item = await client.create_response(
            kb_type=kb_type,
            question=question,
            answer=answer,
            guardrail=guardrail,
            active=active,
            agent_ids=agent_ids,
            label_id=label_id,
            flow_id=flow_id,
        )
    except AppliedAPIError as e:
        return _format_error(e)

    result = "# Created Knowledge Item\n"
    result += f"id: {item.get('id')}\n"
    result += f"type: {item.get('type')}\n"
    result += f"active: {item.get('active')}\n"
    result += f"question: {str(item.get('question', ''))[:100]}\n"

    return result


async def knowledge_update(
    client: AppliedClient,
    knowledge_id: str,
    question: str | None = None,
    answer: str | None = None,
    guardrail: str | None = None,
    active: bool | None = None,
) -> str:
    """
    Update a knowledge base item.

    Args:
        client: Authenticated AppliedClient
        knowledge_id: The knowledge item UUID
        question: New question/trigger text
        answer: New answer/response text
        guardrail: New guardrail instructions
        active: Enable/disable the item

    Returns:
        Updated knowledge item
    """
    updates: dict = {}
    if question is not None:
        updates["question"] = question
    if answer is not None:
        updates["answer"] = answer
    if guardrail is not None:
        updates["guardrail"] = guardrail
    if active is not None:
        updates["active"] = active

    try:
        item = await client.update_response(knowledge_id, **updates)
    except AppliedAPIError as e:
        return _format_error(e)

    return f"# Updated Knowledge Item\nid: {item.get('id')}\ntype: {item.get('type')}\nactive: {item.get('active')}"


def knowledge_types() -> str:
    """
    Static reference for knowledge base types.

    Returns:
        Description of all knowledge base types and their use cases
    """
    return """# Knowledge Base Types

| Type | Purpose | Fast Path? |
|------|---------|------------|
| `qa` | Q&A pairs - LLM matches semantically | No |
| `exact` | Exact string match - bypasses LLM entirely | Yes |
| `escalate` | Escalation triggers with field extraction | No |
| `context` | Background context/instructions for LLM | No |
| `greeting` | Email greeting templates | No |
| `signature` | Email signature templates | No |

## Usage Examples

### qa (Question & Answer)
Most common type. The LLM semantically matches user questions to your Q&A pairs.
```
question: "What are your shipping times?"
answer: "We ship within 2-3 business days."
```

### exact (Exact Match)
Bypasses LLM entirely. Use for deterministic responses to specific phrases.
```
question: "CANCEL_ORDER"
answer: "Your order has been cancelled. Confirmation #{{order_id}}"
```

### escalate (Escalation Trigger)
Triggers handoff to human agent when matched.
```
question: "I want to speak to a manager"
answer: "Connecting you with a team member..."
```

### context (Background Context)
Provides the LLM with domain knowledge, not matched directly.
```
question: "Business hours policy"
answer: "Our support team is available M-F 9am-6pm EST..."
```
"""


# -----------------------------------------------------------------------------
# Products
# -----------------------------------------------------------------------------


async def product_list(
    client: AppliedClient,
    status: str | None = None,
    search: str | None = None,
    output_format: str = "csv",
) -> str:
    """
    List products in the shop.

    Args:
        client: Authenticated AppliedClient
        status: Filter by status - 'Active', 'Draft', 'Pending'
        search: Full-text search query
        output_format: 'csv' or 'json'

    Returns:
        List of products with id, title, status, price, rating
    """
    products = await client.list_products(status=status, search=search)

    def extract_price(p: dict) -> str:
        try:
            text = p.get("text", "")
            if text:
                data = json.loads(text)
                variants = data.get("variants", [])
                if variants:
                    return str(variants[0].get("price", ""))
        except (json.JSONDecodeError, TypeError, KeyError):
            pass
        return ""

    def extract_rating(p: dict) -> str:
        try:
            text = p.get("text", "")
            if text:
                data = json.loads(text)
                reviews = data.get("reviews", {})
                if reviews and reviews.get("rating"):
                    return f"{reviews.get('rating'):.1f} ({reviews.get('count', 0)})"
        except (json.JSONDecodeError, TypeError, KeyError):
            pass
        return ""

    mapped = [
        {
            "id": p.get("id"),
            "title": str(p.get("title", ""))[:50],
            "status": p.get("status"),
            "price": extract_price(p),
            "rating": extract_rating(p),
            "auto_kb": p.get("should_autogenerate_responses", False),
        }
        for p in products
    ]

    if output_format == "csv":
        return to_csv(mapped, ["id", "title", "status", "price", "rating", "auto_kb"])
    return to_json(mapped)


async def product_get(
    client: AppliedClient,
    product_id: str,
) -> str:
    """
    Get a single product with full details.

    Args:
        client: Authenticated AppliedClient
        product_id: The product UUID

    Returns:
        Product details including title, description, images, price, reviews
    """
    product = await client.get_product(product_id)

    result = f"# Product: {product.get('title')}\n"
    result += f"id: {product.get('id')}\n"
    result += f"status: {product.get('status')}\n"
    result += f"used_for_rag: {product.get('used_for_rag')}\n"
    result += f"auto_generate_kb: {product.get('should_autogenerate_responses')}\n"

    # Parse product JSON from text field
    try:
        text = product.get("text", "")
        if text:
            data = json.loads(text)

            if data.get("description"):
                result += f"\n## Description\n{data.get('description')}\n"

            if data.get("onlineStoreUrl"):
                result += f"\nURL: {data.get('onlineStoreUrl')}\n"

            images = data.get("images", [])
            if images:
                result += f"\n## Images ({len(images)})\n"
                for img in images[:5]:
                    result += f"- {img}\n"

            variants = data.get("variants", [])
            if variants:
                result += "\n## Variants\n"
                for v in variants:
                    price = v.get("price", "")
                    compare = v.get("compareAtPrice", "")
                    sku = v.get("sku", "")
                    result += f"- {v.get('title', 'Default')}: ${price}"
                    if compare:
                        result += f" (was ${compare})"
                    if sku:
                        result += f" [SKU: {sku}]"
                    result += "\n"

            reviews = data.get("reviews", {})
            if reviews:
                rating = reviews.get("rating")
                count = reviews.get("count", 0)
                if rating:
                    result += (
                        f"\n## Reviews\nRating: {rating:.1f}/5 ({count} reviews)\n"
                    )

    except (json.JSONDecodeError, TypeError):
        pass

    return result


async def product_create(
    client: AppliedClient,
    title: str,
    description: str = "",
    url: str = "",
    images: list[str] | None = None,
    price: str | None = None,
    compare_at_price: str | None = None,
    currency: str = "USD",
    rating: float | None = None,
    review_count: int | None = None,
    status: str = "Active",
    auto_generate_kb: bool = True,
) -> str:
    """
    Create a new product.

    Args:
        client: Authenticated AppliedClient
        title: Product name
        description: Product description
        url: Product page URL
        images: List of image URLs
        price: Current price (e.g. "29.99")
        compare_at_price: Original/compare price for showing discounts
        currency: Currency code (default "USD")
        rating: Average rating (e.g. 4.5)
        review_count: Number of reviews
        status: 'Active', 'Draft', 'Pending' (default 'Active')
        auto_generate_kb: Auto-generate Q&A knowledge (default True)

    Returns:
        Created product with ID
    """
    try:
        product = await client.create_product(
            title=title,
            description=description,
            url=url,
            images=images,
            price=price,
            compare_at_price=compare_at_price,
            currency=currency,
            rating=rating,
            review_count=review_count,
            status=status,
            should_autogenerate_responses=auto_generate_kb,
            used_for_rag=True,
        )
    except AppliedAPIError as e:
        return _format_error(e)

    result = "# Created Product\n"
    result += f"id: {product.get('id')}\n"
    result += f"title: {product.get('title')}\n"
    result += f"status: {product.get('status')}\n"
    result += f"auto_generate_kb: {product.get('should_autogenerate_responses')}\n"

    return result


async def product_update(
    client: AppliedClient,
    product_id: str,
    title: str | None = None,
    description: str | None = None,
    status: str | None = None,
    auto_generate_kb: bool | None = None,
    used_for_rag: bool | None = None,
) -> str:
    """
    Update a product's properties.

    Args:
        client: Authenticated AppliedClient
        product_id: The product UUID
        title: New title
        description: New description
        status: 'Active', 'Draft', 'Pending'
        auto_generate_kb: Enable/disable auto Q&A generation
        used_for_rag: Include in knowledge base

    Returns:
        Updated product
    """
    updates: dict = {}
    if title is not None:
        updates["title"] = title
    if description is not None:
        updates["description"] = description
    if status is not None:
        updates["status"] = status
    if auto_generate_kb is not None:
        updates["should_autogenerate_responses"] = auto_generate_kb
    if used_for_rag is not None:
        updates["used_for_rag"] = used_for_rag

    try:
        product = await client.update_product(product_id, **updates)
    except AppliedAPIError as e:
        return _format_error(e)

    return f"# Updated Product\nid: {product.get('id')}\ntitle: {product.get('title')}\nstatus: {product.get('status')}"


async def product_delete(
    client: AppliedClient,
    product_id: str,
) -> str:
    """
    Delete a product.

    Args:
        client: Authenticated AppliedClient
        product_id: The product UUID

    Returns:
        Success message
    """
    try:
        await client.delete_product(product_id)
    except AppliedAPIError as e:
        return _format_error(e)

    return f"Product {product_id} deleted successfully."
