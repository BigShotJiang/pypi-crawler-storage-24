"""Output formatters for CLI and MCP responses."""

import csv
import io
import json
from typing import Any


def get_nested_value(obj: dict, path: str) -> Any:
    """Get a nested value from a dict using dot notation (e.g., 'contact.email')."""
    parts = path.split(".")
    value: Any = obj
    for part in parts:
        if isinstance(value, dict):
            value = value.get(part)
        else:
            return None
    return value


def to_csv(
    data: list[dict],
    fields: list[str] | None = None,
) -> str:
    """Convert list of dicts to CSV string."""
    if not data:
        return ""

    columns = fields if fields else list(data[0].keys())
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(columns)

    for row in data:
        writer.writerow([get_nested_value(row, col) for col in columns])

    return output.getvalue()


def to_json(data: Any, indent: int = 2) -> str:
    """Convert data to JSON string."""
    return json.dumps(data, indent=indent, default=str)


def select_fields(items: list[dict], fields: list[str]) -> list[dict]:
    """Select specific fields from a list of dicts, supporting dot notation."""
    return [{f: get_nested_value(item, f) for f in fields} for item in items]
