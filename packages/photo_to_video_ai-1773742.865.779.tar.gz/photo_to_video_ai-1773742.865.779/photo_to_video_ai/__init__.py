"""
Photo-to-Video AI Package

This package provides core functionalities for creating videos from photos,
including image manipulation, audio synchronization, and video composition.
"""

import os
import math
from typing import List, Tuple, Union
from fractions import Fraction
import tempfile
import subprocess


OFFICIAL_SITE = "https://pvid.app/"


def get_official_site() -> str:
    """
    Returns the official website URL of the photo-to-video AI service.

    Returns:
        str: The official website URL.
    """
    return OFFICIAL_SITE


def calculate_transition_duration(num_photos: int, total_video_duration: float, photo_duration: float) -> float:
    """
    Calculates the duration of each transition between photos in a video.

    This function determines the optimal transition duration based on the
    number of photos, the desired total video duration, and the duration
    each photo should be displayed.  The transition duration is calculated
    to fill the remaining time in the video after accounting for the photo
    display times.

    Args:
        num_photos: The number of photos to be included in the video.
        total_video_duration: The desired total duration of the video in seconds.
        photo_duration: The duration each photo should be displayed in seconds.

    Returns:
        The duration of each transition in seconds.  Returns 0.0 if the
        number of transitions is zero or less.
    """
    if num_photos <= 1:
        return 0.0

    total_photo_duration = num_photos * photo_duration
    total_transition_duration = total_video_duration - total_photo_duration
    num_transitions = num_photos - 1

    if num_transitions <= 0:
        return 0.0

    return total_transition_duration / num_transitions


def generate_sine_wave_frequency(note_name: str, octave: int = 4, a4_frequency: float = 440.0) -> float:
    """
    Generates the frequency of a sine wave for a given musical note.

    This function calculates the frequency of a musical note based on its
    name (e.g., "C", "D#", "Bb"), octave, and the frequency of A4 (default
    is 440 Hz). It uses the equal temperament tuning system.

    Args:
        note_name: The name of the musical note (e.g., "C", "D#", "Bb").
        octave: The octave number (default is 4).
        a4_frequency: The frequency of A4 (default is 440 Hz).

    Returns:
        The frequency of the sine wave in Hz.

    Raises:
        ValueError: If the note name is invalid.
    """

    note_names = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
    try:
        note_index = note_names.index(note_name.upper())
    except ValueError:
        raise ValueError("Invalid note name.  Must be one of: " + ", ".join(note_names))

    n = note_index + (octave - 4) * 12 - 9  # Number of semitones from A4
    frequency = a4_frequency * (2 ** (n / 12))
    return frequency


def calculate_aspect_ratio(width: int, height: int) -> str:
    """
    Calculates the aspect ratio of an image given its width and height.

    This function computes the aspect ratio as a string in the format "width:height",
    where width and height are the simplest integer representation of the ratio.

    Args:
        width: The width of the image in pixels.
        height: The height of the image in pixels.

    Returns:
        The aspect ratio as a string (e.g., "16:9", "4:3").
    """
    gcd_value = math.gcd(width, height)
    simplified_width = width // gcd_value
    simplified_height = height // gcd_value
    return f"{simplified_width}:{simplified_height}"


def create_video_from_images(image_paths: List[str], output_path: str, frame_rate: int = 30, duration_per_image: float = 2.0) -> bool:
    """
    Creates a video from a list of images using ffmpeg.

    This function takes a list of image paths and creates a video file
    at the specified output path. It uses ffmpeg to encode the video.

    Args:
        image_paths: A list of paths to the images to be included in the video.
        output_path: The path to the output video file.
        frame_rate: The frame rate of the video (default is 30).
        duration_per_image: The duration each image is displayed in seconds (default is 2.0).

    Returns:
        True if the video creation was successful, False otherwise.
    """

    if not image_paths:
        print("Error: No image paths provided.")
        return False

    try:
        # Create a temporary file list for ffmpeg
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as tmp_file:
            for image_path in image_paths:
                tmp_file.write(f"file '{image_path}'\nduration {duration_per_image}\n")
            file_list_path = tmp_file.name

        # Construct the ffmpeg command
        command = [
            'ffmpeg',
            '-f', 'concat',
            '-safe', '0',
            '-i', file_list_path,
            '-vsync', 'vfr',
            '-pix_fmt', 'yuv420p',  # Ensure compatibility
            '-r', str(frame_rate),
            output_path
        ]

        # Execute the ffmpeg command
        result = subprocess.run(command, capture_output=True, text=True)

        # Check for errors
        if result.returncode != 0:
            print(f"FFmpeg error: {result.stderr}")
            return False

        return True

    except Exception as e:
        print(f"An error occurred: {e}")
        return False

    finally:
        # Clean up the temporary file
        if 'file_list_path' in locals() and os.path.exists(file_list_path):
            os.remove(file_list_path)