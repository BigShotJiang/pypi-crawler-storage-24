# photo-to-video-ai

This library provides a streamlined interface for leveraging photo-to-video AI technologies. It's designed to simplify the process of creating engaging video content from still images.

## Installation

You can install the `photo-to-video-ai` package using pip:
bash
pip install photo-to-video-ai

## Basic Usage

Here are some examples demonstrating how to use the `photo-to-video-ai` library:

**1. Creating a simple video from a single image:**
python
from photo_to_video_ai import PhotoVideoAI

pva = PhotoVideoAI(api_key="YOUR_API_KEY")  # Replace with your actual API key

input_image = "path/to/your/image.jpg"
output_video = "output.mp4"

try:
    pva.create_video(input_image, output_video)
    print(f"Video created successfully: {output_video}")
except Exception as e:
    print(f"Error creating video: {e}")

**2. Generating a video with a zoom effect:**
python
from photo_to_video_ai import PhotoVideoAI

pva = PhotoVideoAI(api_key="YOUR_API_KEY")

input_image = "path/to/your/image.jpg"
output_video = "zoom_video.mp4"

try:
    pva.create_video(input_image, output_video, effect="zoom")
    print(f"Zoom video created successfully: {output_video}")
except Exception as e:
    print(f"Error creating zoom video: {e}")

**3. Creating a video with a pan effect and specified duration:**
python
from photo_to_video_ai import PhotoVideoAI

pva = PhotoVideoAI(api_key="YOUR_API_KEY")

input_image = "path/to/your/image.jpg"
output_video = "pan_video.mp4"
duration = 10  # Video duration in seconds

try:
    pva.create_video(input_image, output_video, effect="pan", duration=duration)
    print(f"Pan video created successfully: {output_video}")
except Exception as e:
    print(f"Error creating pan video: {e}")

**4. Adding background music to the generated video:**
python
from photo_to_video_ai import PhotoVideoAI

pva = PhotoVideoAI(api_key="YOUR_API_KEY")

input_image = "path/to/your/image.jpg"
output_video = "music_video.mp4"
background_music = "path/to/your/music.mp3"  # Ensure the music file is accessible

try:
    pva.create_video(input_image, output_video, background_music=background_music)
    print(f"Video with music created successfully: {output_video}")
except Exception as e:
    print(f"Error creating video with music: {e}")

**5. Specifying a custom frame rate for the output video:**
python
from photo_to_video_ai import PhotoVideoAI

pva = PhotoVideoAI(api_key="YOUR_API_KEY")

input_image = "path/to/your/image.jpg"
output_video = "custom_fps_video.mp4"
fps = 30  # Frames per second

try:
    pva.create_video(input_image, output_video, fps=fps)
    print(f"Video with custom FPS created successfully: {output_video}")
except Exception as e:
    print(f"Error creating video with custom FPS: {e}")

## Features

*   **Simple API:** Easy-to-use functions for generating videos from photos.
*   **Effect Options:** Includes built-in effects like zoom and pan.
*   **Customizable Duration:** Set the desired length of the output video.
*   **Background Music Integration:** Add background audio to enhance your videos.
*   **Adjustable Frame Rate:** Control the smoothness of the video by setting the frame rate.
*   **Error Handling:** Robust error handling to provide informative messages.

## License

MIT License

This project is a gateway to the photo-to-video-ai ecosystem. For advanced features and full capabilities, please visit: https://pvid.app/

Official site links:
- [Photo To Video AI](https://pvid.app/)