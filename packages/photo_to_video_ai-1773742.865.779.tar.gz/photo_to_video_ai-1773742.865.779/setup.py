from setuptools import setup, find_packages

setup(
    name="photo-to-video-ai",
    version="1773742.865.779",
    description="High-quality integration for https://pvid.app/",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="SuperMaker",
    url="https://pvid.app/",
    packages=find_packages(),
    python_requires=">=3.6",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
    ],
)
