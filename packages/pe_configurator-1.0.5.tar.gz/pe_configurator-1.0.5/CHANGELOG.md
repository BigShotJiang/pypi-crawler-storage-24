All notable changes will be noted in this file, whenever a tagged version is made

## [1.0.3] 01/12/2023

Version reviewed for O4a production runs. As new features with respect to 1.0.2, it contains:
- Addition of reference-frame and time-reference to recommended settings https://git.ligo.org/pe/get_eob_settings/-/merge_requests/33
- Addition of NRSur7dq4 constrains plot to report https://git.ligo.org/pe/get_eob_settings/-/merge_requests/34
- Fix prior updating precedence https://git.ligo.org/pe/get_eob_settings/-/merge_requests/28 

## [1.0.4] 24/05/2024

New features with respect to 1.0.3:
- Passing duration of Tukey rollon and post-trigger as parameters. This is for addressing the change in the default Tukey rollon for O4a production runs.

## [1.0.5] 25/03/2026

Version prepared for GWTC-6 environment updates. New features and fixes with respect to 1.0.4:
- Add option to set `bounds_tol` through the Asimov blueprint. This allows controlling the tolerance used when checking for posterior support close to prior boundaries. (https://git.ligo.org/pe/get_eob_settings/-/merge_requests/?sort=updated_desc&state=merged&first_page_size=20#:~:text=Add%20option%20to%20set%20bounds_tol%20through%20Asimov%20blueprint.)
- Add option to specify a minimum sample rate. (https://git.ligo.org/pe/get_eob_settings/-/merge_requests/42)
- Fix the type of `--ell-max` in `proc_samples.py`. (https://git.ligo.org/pe/get_eob_settings/-/merge_requests/?sort=updated_desc&state=merged&first_page_size=20#:~:text=Set%20%22int%22%20as%20type%20for%20%22%2D%2Dell%2Dmax%22%20in%20proc_samples.py)
- Maintenance update to the `ipython` import for compatibility with the new API. (https://git.ligo.org/pe/get_eob_settings/-/merge_requests/39)
- Fix the order in which the chirp-mass `bounds_tol` adjustment is applied, so that the railing check is performed before modifying the chirp-mass bounds tolerance. (https://git.ligo.org/pe/get_eob_settings/-/merge_requests/41)