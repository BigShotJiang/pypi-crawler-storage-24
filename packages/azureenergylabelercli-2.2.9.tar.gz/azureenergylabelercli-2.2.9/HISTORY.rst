.. :changelog:

History
-------

0.0.1 (04-05-2022)
---------------------

* First code creation


0.1.0 (27-06-2022)
------------------

* First release


1.0.0 (22-09-2022)
------------------

* Add support for environment variables as default argument value
* Arguments with array of values changed from a space separated list to a comma separated list
* CLI now uses the most recent version of the azureenergylabelerlib


1.0.1 (26-09-2022)
------------------

* Fixed a bug preventing collection of resource group findings


1.1.0 (04-10-2022)
------------------

* Updated dependency azurenergylabelerlib to version 2.0.0


2.0.0 (19-10-2022)
------------------

* Microsoft renamed "Azure Security Benchmark" to "Microsoft cloud security benchmark", changing the interface


2.0.1 (20-10-2022)
------------------

* Fix broken dependecies


2.0.2 (08-03-2023)
------------------

* Bump template and dependencies.


2.0.3 (21-03-2023)
------------------

* Bumped library version which now filters subscriptions based on the tenant_id.


2.1.0 (15-05-2023)
------------------

* Added option to disable banner and spinner
* Improved filtering of findings


2.1.1 (28-06-2023)
------------------

* Updated library dependency


2.2.0 (22-09-2023)
------------------

* feat: updating azureenergylabelerlib to 3.3.0 to allow excluding resource groups


2.2.1 (22-09-2023)
------------------

* Fix: AZURE_LABELER_DENIED_RESOURCE_GROUP_NAMES changed to a string delimited list due to gitlab-ci not supporting variables of the type list.


2.2.2 (22-09-2023)
------------------

* fix: the list syntax in the readme file broke the release. It expects a comma after a quote.


2.2.3 (22-09-2023)
------------------

* fix: the list syntax in the readme file broke the release. It expects a comma after a quote.


2.2.4 (03-10-2023)
------------------

* fix: denied_resource_group_names was optional in azureenergylabelerlib 3.3.0. This broke the code if no value was given, therefore updating to 3.3.1.


2.2.5 (05-10-2023)
------------------

* feat: added validation for azure resource group names in azureenergylaberlib 3.3.2


2.2.7 (06-06-2024)
------------------

* Bump dependencies.


2.2.8 (09-03-2026)
------------------

* Upgrade azureenergylabelerlib to 4.0.1 and use python 3.12 as runtime


2.2.9 (09-03-2026)
------------------

* bump twine version
