"""CLI interface for OpenClaw vanilla installer."""

from pathlib import Path
from typing import Optional

import typer
from rich import print as rprint

from .installer import OpenClawInstaller

app = typer.Typer(help="Vanilla installer for OpenClaw - installs and starts the gateway")


@app.command()
def install(
    dry_run: bool = typer.Option(False, "--dry-run", help="Simulate without making changes"),
):
    """Install OpenClaw and start the gateway."""
    installer = OpenClawInstaller(dry_run=dry_run)
    success = installer.install()
    raise typer.Exit(0 if success else 1)


@app.command()
def uninstall(
    dry_run: bool = typer.Option(False, "--dry-run", help="Simulate without making changes"),
):
    """Uninstall OpenClaw."""
    installer = OpenClawInstaller(dry_run=dry_run)
    success = installer.uninstall()
    raise typer.Exit(0 if success else 1)


@app.command()
def dashboard(
    browser: Optional[str] = typer.Option(None, "--browser", "-b", help="Path to browser executable"),
):
    """Open OpenClaw dashboard."""
    import subprocess
    import sys
    
    if sys.platform == "win32":
        wrapper = Path.home() / "AppData" / "Local" / "openclaw-installer" / "bin" / "openclaw.cmd"
    else:
        wrapper = Path.home() / ".local" / "share" / "openclaw-installer" / "bin" / "openclaw"
    
    if not wrapper.exists():
        rprint("[red]OpenClaw not installed. Run: openclaw-installer install[/]")
        raise typer.Exit(1)
    
    subprocess.run([str(wrapper), "dashboard"])


def main():
    app()


if __name__ == "__main__":
    main()
