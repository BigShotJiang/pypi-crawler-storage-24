"""Entry point for python -m openclaw_installer"""
from .cli import main

if __name__ == "__main__":
    main()
