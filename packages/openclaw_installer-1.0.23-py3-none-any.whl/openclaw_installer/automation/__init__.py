"""
OpenClaw Automation Module

Provides zero-interaction automation for OpenClaw operations including:
- Auto-login to dashboard
- Gateway management
- Browser automation
"""

from .auto_login import auto_login, get_wrapper_path, check_gateway_status

__all__ = ["auto_login", "get_wrapper_path", "check_gateway_status"]
