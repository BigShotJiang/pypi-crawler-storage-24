## Requirements

- Python 3.12+
- [uv](https://docs.astral.sh/uv/) for package management and publishing
- Pydantic v2 for data modelling

## Installation

```
uv sync
```

## Development

Install with test dependencies:
```
uv sync --extra test
```

Run tests:
```
uv run pytest
```

Run linter:
```
uv run ruff check .
uv run ruff format --check .
```

## Publish the Python Package to PyPI

- Increment the version of your package in the `__init__.py` file:
```python
"""OpenAICompletion processor"""

__version__ = 'x.y.z'
```
- Build and publish:
```
uv build
uv publish
```

## SBOM & vulnerability check

Install the SBOM dependencies:

```
uv sync --extra sbom
```

Generate a CycloneDX SBOM from the current environment:

```
uv run cyclonedx-py environment -o sbom.cdx.json --output-format json
```

Audit dependencies for known vulnerabilities:

```
uv run pip-audit --format json --output audit-report.json
```

To fail on any known vulnerability (useful in CI):

```
uv run pip-audit --strict
```
