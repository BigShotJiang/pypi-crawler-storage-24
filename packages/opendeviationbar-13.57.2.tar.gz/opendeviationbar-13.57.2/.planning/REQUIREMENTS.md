# Requirements: opendeviationbar-py v7.0

**Defined:** 2026-03-26
**Core Value:** Ouroboros as a family of reset modes; Aion (continuous) for 24/7 crypto with gap-aware bars, all healers wired, and oracle-verified correctness.

**Constraints:**

- All ClickHouse schema changes must follow the `clickhouse-architect` skill from `~/eon/cc-skills`
- Aion mode is crypto-only; forex symbols remain Day-mode (Week-mode deferred)
- `has_gap` is transient -- all healers (Puck, Kintsugi, Niffler, Charon) fire immediately
- Existing Day-mode crypto bars are wiped and recomputed as Aion (no legacy preservation)
- Python 3.13 only; no breaking PyO3 API changes

## v7.0 Requirements

### Core -- Rust Processor + Bar Struct

- [ ] **CORE-01**: Processor skips `reset_at_ouroboros()` when symbol's ouroboros_mode is Aion
- [ ] **CORE-02**: `OpenDeviationBar` struct has `has_gap: bool`, `gap_trade_count: i64`, `max_gap_duration_us: i64` fields set during bar construction when `incoming_tid > last_tid + 1`
- [ ] **CORE-03**: `OpenDeviationBar` struct has `is_exchange_gap: bool` for permanently unhealable gaps (REST backfill confirms trades don't exist at source)
- [ ] **CORE-04**: `maybe_reset_at_midnight()` in `trade_dispatch.rs` reads mode from processor config and skips reset for Aion

### Registry -- symbols.toml SSoT

- [x] **REG-01**: `ouroboros_mode` field added to every symbol in `symbols.toml` with `"day"` as default
- [x] **REG-02**: `SymbolEntry` dataclass in `symbol_registry.py` exposes `ouroboros_mode` to all consumers
- [x] **REG-03**: `OuroborosMode` enum in `ouroboros.py` expanded with `AION = "aion"` variant
- [x] **REG-04**: All public Python API signatures (`get_open_deviation_bars`, etc.) accept `ouroboros_mode: Literal["day", "aion"]`
- [x] **REG-05**: Registry validation rejects `ouroboros_mode = "aion"` for non-crypto symbols (`asset_class != "crypto"`)

### Sidecar -- Aion Startup Path

- [ ] **SIDE-01**: Aion symbols skip midnight preflight (`_run_midnight_preflight`) and clean-slate DELETE on sidecar startup
- [ ] **SIDE-02**: Aion symbols use checkpoint-resume startup (TID-based resume, not genesis recompute)
- [x] **SIDE-03**: Puck inline gap fill remains wired and operational for Aion symbols (mode-agnostic gap detection)

### Kintsugi -- Aion Repair

- [x] **KINT-01**: Aion repair strategy reprocesses from gap point forward to present (genesis-forward, not day-recompute)
- [x] **KINT-02**: Writer ownership boundary for Aion is TID-based (not UTC day-based); no today-guard for Aion symbols
- [x] **KINT-03**: Niffler/Charon dead-letter recovery remains wired and operational (mode-agnostic)

### Monitor -- Heartbeat + Validation

- [x] **MON-01**: Yesterday completion check replaced with rolling-window freshness check for Aion symbols (last bar within configurable window)
- [x] **MON-02**: Day-mode pre-write gate in `bulk_operations.py` is conditional -- skipped for Aion symbols
- [x] **MON-03**: Stathera audit query is mode-agnostic (trade-ID continuity checking works identically for both modes)

### Validate -- Oracle + Self-Verification

- [ ] **VAL-01**: Oracle bit-exact test: Aion mode produces identical bars as Day mode within a single UTC day (excluding orphan bar at midnight boundary)
- [ ] **VAL-02**: Multi-day oracle: Aion bars spanning UTC midnight have continuous trade IDs, no orphan, and correct microstructure features
- [ ] **VAL-03**: Gap-flag oracle: bars with `has_gap=true` are correctly identified during construction and naturally cleared (`has_gap=false`) after successful Puck/Kintsugi repair recompute
- [x] **VAL-04**: Self-validation telemetry: heartbeat confirms Stathera 0-gap 0-overlap for all Aion crypto symbols after full fleet recompute on bigblack

### Recompute -- Fleet Migration (Clean Break)

- [x] **RECOMP-01**: DELETE all Day-mode crypto bars from ClickHouse via DROP PARTITION per (symbol, threshold) pair
- [x] **RECOMP-02**: Full fleet recompute on bigblack with Aion mode for all 18 crypto symbols (~1.3h staging)
- [x] **RECOMP-03**: Wipe Day-mode telemetry artifacts (kintsugi_log entries, population_checkpoints, heartbeat state for crypto symbols)
- [x] **RECOMP-04**: Update monit monitors, systemd unit configurations, and Telegram heartbeat message formats for Aion
- [x] **RECOMP-05**: All internal Day-mode references for crypto symbols removed/updated (Stathera queries, validation gates, diagnostic scripts)

## Future Requirements (Deferred)

### Week-Mode for Forex

- **WEEK-01**: `OuroborosMode.WEEK = "week"` variant for forex symbols (reset at Sunday 00:00 UTC)
- **WEEK-02**: Forex symbols (Exness, FxView) use Week-mode aligned to market structure
- **WEEK-03**: Registry enforces Week-mode only for `asset_class = "forex"`

### Performance Optimization

- **PERF-01**: `process_trades_arrow_multi()` -- read trades once, fan to N thresholds in Rust (2-3x speedup)
- **PERF-02**: PGO/LTO optimization for additional +20-35% throughput

## Out of Scope

| Feature                             | Reason                                                                       |
| ----------------------------------- | ---------------------------------------------------------------------------- |
| Week-mode (forex)                   | Forex data sources (Exness, FxView) not production-ready; separate milestone |
| Legacy Day-mode crypto preservation | CEO directive: no legacy preservation, clean break                           |
| Per-feature reliability indicators  | Future enhancement; boolean + continuous metadata sufficient for v7.0        |
| Separate CH table for Aion bars     | Same table with `ouroboros_mode` column; partition key already mode-agnostic |

## Traceability

| Requirement | Phase    | Status   |
| ----------- | -------- | -------- |
| REG-01      | Phase 13 | Complete |
| REG-02      | Phase 13 | Complete |
| REG-03      | Phase 13 | Complete |
| REG-04      | Phase 13 | Complete |
| REG-05      | Phase 13 | Complete |
| CORE-01     | Phase 14 | Pending  |
| CORE-02     | Phase 14 | Pending  |
| CORE-03     | Phase 14 | Pending  |
| CORE-04     | Phase 14 | Pending  |
| VAL-01      | Phase 15 | Pending  |
| VAL-02      | Phase 15 | Pending  |
| VAL-03      | Phase 15 | Pending  |
| SIDE-01     | Phase 16 | Pending  |
| SIDE-02     | Phase 16 | Pending  |
| SIDE-03     | Phase 16 | Complete |
| KINT-01     | Phase 17 | Complete |
| KINT-02     | Phase 17 | Complete |
| KINT-03     | Phase 17 | Complete |
| MON-01      | Phase 18 | Pending  |
| MON-02      | Phase 18 | Complete |
| MON-03      | Phase 18 | Complete |
| RECOMP-01   | Phase 19 | Complete |
| RECOMP-02   | Phase 19 | Complete |
| RECOMP-03   | Phase 19 | Complete |
| RECOMP-04   | Phase 19 | Complete |
| RECOMP-05   | Phase 19 | Complete |
| VAL-04      | Phase 19 | Complete |

**Coverage:**

- v7.0 requirements: 27 total
- Mapped to phases: 27
- Unmapped: 0

---

_Requirements defined: 2026-03-26_
_Last updated: 2026-03-26 after roadmap creation_
