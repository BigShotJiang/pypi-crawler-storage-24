# Phase 9: Verification Registry - Context

**Gathered:** 2026-03-26
**Status:** Ready for planning
**Mode:** Auto-generated (infrastructure phase — discuss skipped)

<domain>
## Phase Boundary

A centralized store tracks per-file checksum verification state as the single source of truth, queryable by seeder, sweep, and heartbeat. Stores per-file records (symbol, date, sha256, verified_at, source) and persists across process restarts.

Requirements: TELEM-03

</domain>

<decisions>
## Implementation Decisions

### Claude's Discretion

All implementation choices are at Claude's discretion — pure infrastructure phase. Use ROADMAP phase goal, success criteria, and codebase conventions to guide decisions.

Key context:

- Registry must be queryable by symbol or date range
- Seeder writes records, sweep reads to skip already-verified files
- Must persist across process restarts (file-based JSON or SQLite)
- Follow existing codebase patterns (e.g., seeder-state markers in `~/.cache/opendeviationbar/`)
- Phase 8 spike proved checksum bindings work — this phase provides the tracking layer

</decisions>

<code_context>

## Existing Code Insights

### Reusable Assets

- `python/opendeviationbar/config/settings.py` — Pydantic settings for path configuration
- `python/opendeviationbar/storage/` — Existing Parquet storage patterns
- `~/.cache/opendeviationbar/seeder-state/` — Existing state marker pattern from v5.0

### Established Patterns

- File-based state in `~/.cache/opendeviationbar/` via `platformdirs`
- Pydantic models for data validation
- JSON for configuration/state files

### Integration Points

- `scripts/tick_cache_seeder.py` — Will write verification records (Phase 10)
- `scripts/heartbeat/checks/` — Will read verification status (Phase 12)
- Future sweep script — Will read/write registry (Phase 11)

</code_context>

<specifics>
## Specific Ideas

No specific requirements — infrastructure phase. Follow existing patterns for state persistence.

</specifics>

<deferred>
## Deferred Ideas

None — discussion stayed within phase scope.

</deferred>
