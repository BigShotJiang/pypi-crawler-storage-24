# Phase 10: Seeder Checksum Integration - Context

**Gathered:** 2026-03-26
**Status:** Ready for planning
**Mode:** Auto-generated (infrastructure phase — discuss skipped)

<domain>
## Phase Boundary

Every Vision ZIP downloaded by tick_cache_seeder is SHA-256 verified against the .CHECKSUM file before being accepted into the Parquet cache. Mismatch triggers retry + Telegram alert. Each verification recorded in ChecksumRegistry.

Requirements: SEEDER-01, SEEDER-02, SEEDER-03

</domain>

<decisions>
## Implementation Decisions

### Claude's Discretion

All implementation choices are at Claude's discretion — infrastructure phase. Use ROADMAP success criteria and codebase conventions.

Key context:

- Phase 8 proved: `compute_sha256_hex`, `verify_checksum_hex`, `parse_checksum_file_content` work from Python
- Phase 9 built: `ChecksumRegistry` with `add()`, `save()`, `has_verified()` APIs
- Seeder downloads Vision ZIPs via `requests.get()` in `scripts/tick_cache_seeder.py`
- Must wire: download ZIP → compute SHA-256 → fetch .CHECKSUM → compare → retry on mismatch → record in registry
- Telegram alerts use existing `python/opendeviationbar/notify/` module

</decisions>

<code_context>

## Existing Code Insights

### Reusable Assets

- `opendeviationbar._core.compute_sha256_hex` — SHA-256 of bytes (Phase 8)
- `opendeviationbar._core.verify_checksum_hex` — Compare data hash vs expected (Phase 8)
- `opendeviationbar._core.parse_checksum_file_content` — Parse .CHECKSUM file format (Phase 8)
- `python/opendeviationbar/checksum_registry.py` — ChecksumRegistry (Phase 9)
- `python/opendeviationbar/notify/telegram.py` — Telegram notification for alerts

### Established Patterns

- Seeder uses `requests.get()` for Vision downloads
- Seeder sends Telegram summary after each run
- Retry patterns exist in seeder for HTTP errors

### Integration Points

- `scripts/tick_cache_seeder.py` — Main integration target
- `python/opendeviationbar/checksum_registry.py` — Write verification records
- `python/opendeviationbar/notify/` — LOUD Telegram alerts on checksum failure

</code_context>

<specifics>
## Specific Ideas

No specific requirements beyond what ROADMAP specifies.

</specifics>

<deferred>
## Deferred Ideas

None.

</deferred>
