---
phase: 6
slug: fix-seed-001-process-parquet-ticks
status: draft
nyquist_compliant: true
wave_0_complete: false
created: 2026-03-25
---

# Phase 6 — Validation Strategy

> Per-phase validation contract for feedback sampling during execution.

---

## Test Infrastructure

| Property               | Value                                                                    |
| ---------------------- | ------------------------------------------------------------------------ |
| **Framework**          | pytest                                                                   |
| **Config file**        | `pyproject.toml` [tool.pytest.ini_options]                               |
| **Quick run command**  | `uv run --python 3.13 pytest tests/test_parquet_bar_processing.py -x -q` |
| **Full suite command** | `mise run test-py`                                                       |
| **Estimated runtime**  | ~10 seconds                                                              |

---

## Sampling Rate

- **After every task commit:** Run `uv run --python 3.13 pytest tests/test_parquet_bar_processing.py -x -q`
- **After every plan wave:** Run `mise run test-py`
- **Before `/gsd:verify-work`:** Full suite must be green
- **Max feedback latency:** 10 seconds

---

## Per-Task Verification Map

| Task ID  | Plan | Wave | Requirement | Test Type | Automated Command                                                                  | File Exists | Status     |
| -------- | ---- | ---- | ----------- | --------- | ---------------------------------------------------------------------------------- | ----------- | ---------- |
| 06-01-01 | 01   | 1    | SEED-FIX-01 | unit      | `pytest tests/test_parquet_bar_processing.py -x`                                   | ❌ W0       | ⬜ pending |
| 06-01-02 | 01   | 1    | SEED-FIX-02 | unit      | `pytest tests/test_parquet_bar_processing.py::test_seed_uses_completed_bar_tid -x` | ❌ W0       | ⬜ pending |

_Status: ⬜ pending · ✅ green · ❌ red · ⚠️ flaky_

---

## Wave 0 Requirements

- [ ] `tests/test_parquet_bar_processing.py` — new test file for SEED-FIX-01, SEED-FIX-02
- [ ] Test fixtures: mock Parquet files with known trade data for deterministic bar verification

_Existing test infrastructure covers framework/runner requirements._

---

## Manual-Only Verifications

| Behavior              | Requirement | Why Manual                        | Test Instructions                                                             |
| --------------------- | ----------- | --------------------------------- | ----------------------------------------------------------------------------- |
| Production gap repair | SEED-FIX-01 | Requires bigblack sidecar restart | Deploy, restart sidecar, verify heartbeat shows zero intraday gaps after fill |

---

## Validation Sign-Off

- [x] All tasks have `<automated>` verify or Wave 0 dependencies
- [x] Sampling continuity: no 3 consecutive tasks without automated verify
- [x] Wave 0 covers all MISSING references
- [x] No watch-mode flags
- [x] Feedback latency < 10s
- [x] `nyquist_compliant: true` set in frontmatter

**Approval:** pending
