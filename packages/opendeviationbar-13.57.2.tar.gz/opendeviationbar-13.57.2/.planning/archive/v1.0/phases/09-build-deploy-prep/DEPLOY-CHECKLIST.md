# Deploy Checklist: REST→WS Junction Fix + Combined WS Streams

**Version:** v13.31.0 (or next semantic-release version)
**Deploy Type:** Pattern 2+4 hybrid (Rust changes + clean-slate delete today)
**Target:** bigblack (el02)

## Pre-Deploy

- [ ] All 109 tests passing (`cargo test --lib` for streaming + providers)
- [ ] `cargo check --workspace` clean
- [ ] Linux wheel built via `mise run release:linux`
- [ ] Wheel file exists: `target/wheels/opendeviationbar-*.whl`

## Deploy Sequence (Pattern 2+4 Hybrid)

### 1. Stop Services

```bash
ssh bigblack "sudo monit unmonitor opendeviationbar-sidecar opendeviationbar-kintsugi"
ssh bigblack "systemctl --user stop opendeviationbar-sidecar opendeviationbar-kintsugi"
```

- [ ] Sidecar stopped (checkpoints saved on shutdown)
- [ ] Kintsugi stopped

### 2. Backup Today's Bars

```bash
ssh bigblack "clickhouse-client --query \"
  CREATE TABLE IF NOT EXISTS opendeviationbar_cache.open_deviation_bars_backup AS opendeviationbar_cache.open_deviation_bars;
  INSERT INTO opendeviationbar_cache.open_deviation_bars_backup
  SELECT * FROM opendeviationbar_cache.open_deviation_bars
  WHERE toDate(open_time_ms/1000) = today()
\""
```

- [ ] Backup table created with today's bars

### 3. Delete Today's Bars (All 18 Symbols)

```bash
ssh bigblack "clickhouse-client --query \"
  ALTER TABLE opendeviationbar_cache.open_deviation_bars
  DELETE WHERE toDate(open_time_ms/1000) = today()
\""
# Wait for mutations to complete
ssh bigblack "clickhouse-client --query \"SELECT count() FROM system.mutations WHERE is_done=0\""
```

- [ ] DELETE mutation completed (count = 0)

### 4. Clear Streaming Checkpoints

```bash
ssh bigblack "rm -f ~/.cache/opendeviationbar/checkpoints/streaming_*.json"
```

- [ ] Checkpoints cleared

### 5. Deploy New Wheel

```bash
# Copy wheel to bigblack
scp target/wheels/opendeviationbar-*.manylinux*.whl bigblack:~/

# Atomic venv swap
ssh bigblack "
  cd ~/eon/opendeviationbar-py
  python3.13 -m venv .venv-staging
  .venv-staging/bin/pip install ~/opendeviationbar-*.manylinux*.whl
  mv .venv .venv-old && mv .venv-staging .venv
  rm -rf .venv-old
"
```

- [ ] Wheel installed in staging venv
- [ ] Atomic venv swap complete

### 6. Start Services

```bash
ssh bigblack "systemctl --user start opendeviationbar-sidecar"
# Wait 2 min for inline backfill to complete
sleep 120
ssh bigblack "systemctl --user start opendeviationbar-kintsugi"
ssh bigblack "sudo monit monitor opendeviationbar-sidecar opendeviationbar-kintsugi"
```

- [ ] Sidecar started (inline backfill running for all 18 symbols)
- [ ] Kintsugi started (after sidecar stabilizes)
- [ ] Monit monitoring restored

## Post-Deploy Verification (Immediate)

### 7. Verify Combined WS Active

```bash
ssh bigblack "journalctl --user -u opendeviationbar-sidecar --since '5 min ago' | grep -i 'combined\|CombinedWebSocket'"
```

- [ ] Journal shows combined WS connection established for 18 symbols

### 8. Verify Junction Telemetry

```bash
ssh bigblack "journalctl --user -u opendeviationbar-sidecar --since '5 min ago' | grep -i 'junction\|forming_bar_trades\|ws_buffer_depth'"
```

- [ ] Junction telemetry fields present per symbol

### 9. Verify Rate Limiter Ceiling

```bash
ssh bigblack "journalctl --user -u opendeviationbar-sidecar --since '5 min ago' | grep -i 'set_ceiling\|ceiling'"
```

- [ ] Ceiling set to 4800 during fill, then 3000 after

## 24h Verification (Phase 10)

### 10. Stathera Zero-Tolerance Check (after 24h)

```sql
-- Intra-day gaps (must be 0)
SELECT symbol, threshold_decimal_bps, count() as gap_count
FROM (
  SELECT symbol, threshold_decimal_bps,
    first_agg_trade_id - lagInFrame(last_agg_trade_id, 1) OVER (
      PARTITION BY symbol, threshold_decimal_bps
      ORDER BY first_agg_trade_id
    ) - 1 AS tid_delta
  FROM opendeviationbar_cache.open_deviation_bars
  WHERE toDate(open_time_ms/1000) = today()
)
WHERE tid_delta > 0
GROUP BY symbol, threshold_decimal_bps;

-- Overlaps (must be 0)
SELECT symbol, threshold_decimal_bps, count() as overlap_count
FROM (
  SELECT symbol, threshold_decimal_bps,
    first_agg_trade_id - lagInFrame(last_agg_trade_id, 1) OVER (
      PARTITION BY symbol, threshold_decimal_bps
      ORDER BY first_agg_trade_id
    ) - 1 AS tid_delta
  FROM opendeviationbar_cache.open_deviation_bars
  WHERE toDate(open_time_ms/1000) = today()
)
WHERE tid_delta < 0
GROUP BY symbol, threshold_decimal_bps;
```

- [ ] VERF-01: 0 intra-day gaps across all 18 symbols
- [ ] VERF-02: 0 overlaps across all 18 symbols
- [ ] VERF-03: All 18 symbols producing bars via combined WS
- [ ] VERF-04: Junction telemetry confirms forming bar preservation
- [ ] VERF-05: Rate limiter peak < 5000 weight/min

## Rollback (If Needed)

```bash
# Stop services
ssh bigblack "sudo monit unmonitor opendeviationbar-sidecar opendeviationbar-kintsugi"
ssh bigblack "systemctl --user stop opendeviationbar-sidecar opendeviationbar-kintsugi"

# Restore today's bars from backup
ssh bigblack "clickhouse-client --query \"
  INSERT INTO opendeviationbar_cache.open_deviation_bars
  SELECT * FROM opendeviationbar_cache.open_deviation_bars_backup
\""

# Restore old venv (if still available)
ssh bigblack "cd ~/eon/opendeviationbar-py && mv .venv .venv-bad && mv .venv-old .venv"

# Restart with old version
ssh bigblack "systemctl --user start opendeviationbar-sidecar opendeviationbar-kintsugi"
ssh bigblack "sudo monit monitor opendeviationbar-sidecar opendeviationbar-kintsugi"
```
