---
phase: 06-combined-ws-implementation
plan: "02"
subsystem: streaming
tags: [websocket, combined-streams, binance, tokio, live-engine]

requires:
  - phase: 06-combined-ws-implementation plan 01
    provides: CombinedWebSocketStream with envelope parsing, per-symbol demux, Antaeus reconnection
provides:
  - CombinedWebSocketStream integrated into LiveBarEngine.start_ws()
  - Per-symbol fallback WS creation removed from symbol_task()
  - Single combined WS connection replaces N per-symbol connections
affects: [streaming-sidecar, deploy, integration-testing]

tech-stack:
  added: []
  patterns:
    - "Combined WS demux via HashMap<String, mpsc::Sender> passed to CombinedWebSocketStream"
    - "Enforced start_ws() call sequence — no silent fallback to per-symbol connections"

key-files:
  created: []
  modified:
    - crates/opendeviationbar-streaming/src/live_engine.rs

key-decisions:
  - "Removed per-symbol WS fallback entirely instead of keeping it as a degraded path"
  - "Fixed pre-existing trade_count field bug discovered during workspace check"

patterns-established:
  - "Combined WS is the only WS path — start_ws() must be called before start()"

requirements-completed: [COMB-04, COMB-06]

duration: 4min
completed: 2026-03-19
---

# Phase 06 Plan 02: Integration into start_ws() Summary

**CombinedWebSocketStream replaces per-symbol BinanceWebSocketStream in LiveBarEngine, routing all 18 symbols through a single combined connection**

## Performance

- **Duration:** 4 min
- **Started:** 2026-03-19T23:02:14Z
- **Completed:** 2026-03-19T23:06:17Z
- **Tasks:** 3
- **Files modified:** 1

## Accomplishments

- Replaced N per-symbol `BinanceWebSocketStream::run_with_reconnect()` calls with single `CombinedWebSocketStream::run_with_reconnect()` in `start_ws()`
- Per-symbol `mpsc::channel(50_000)` receivers preserved unchanged — `symbol_task()` interface untouched (COMB-06)
- Removed silent per-symbol WS fallback in `symbol_task()` — replaced with error+return enforcing call sequence
- Fixed pre-existing `trade_count` field bug (should be `individual_trade_count`) that prevented workspace compilation

## Task Commits

Each task was committed atomically:

1. **Task 1: Replace per-symbol WS spawn in start_ws()** - `27b5345` (feat)
2. **Task 2: Remove per-symbol fallback WS in symbol_task()** - `5ade3f2` (feat)
3. **Task 3: Verify compilation and run tests** - `0f3e004` (fix)

## Files Created/Modified

- `crates/opendeviationbar-streaming/src/live_engine.rs` - Combined WS integration in start_ws(), fallback removal in symbol_task(), field name fix

## Decisions Made

- Removed per-symbol WS fallback entirely rather than keeping as degraded path — enforces clean call sequence and prevents silent regression to 18 individual connections
- Fixed pre-existing `trade_count` bug (should be `individual_trade_count`) discovered when running `cargo check --workspace` with all features enabled

## Deviations from Plan

### Auto-fixed Issues

**1. [Rule 1 - Bug] Pre-existing trade_count field name error**

- **Found during:** Task 3 (workspace compilation verification)
- **Issue:** `live_engine.rs` referenced `b.trade_count` which doesn't exist on `OpenDeviationBar` — correct field is `b.individual_trade_count`
- **Fix:** Replaced both occurrences (lines 1367 and 1396)
- **Files modified:** crates/opendeviationbar-streaming/src/live_engine.rs
- **Verification:** `cargo check --workspace` passes
- **Committed in:** `0f3e004`

**2. [Rule 1 - Bug] Unused `policy` parameter warning**

- **Found during:** Task 3 (workspace compilation)
- **Issue:** After removing the per-symbol WS fallback, `policy` parameter in `symbol_task()` became unused
- **Fix:** Prefixed with underscore (`_policy`)
- **Files modified:** crates/opendeviationbar-streaming/src/live_engine.rs
- **Verification:** Zero warnings from `cargo check --workspace`
- **Committed in:** `0f3e004`

---

**Total deviations:** 2 auto-fixed (2 bugs)
**Impact on plan:** Both fixes necessary for clean compilation. No scope creep.

## Issues Encountered

None.

## User Setup Required

None - no external service configuration required.

## Next Phase Readiness

- Phase 06 complete (2/2 plans done) — combined WS module created and integrated
- Ready for Phase 07 (Overlapping Reconnection) or Phase 08 (Integration Testing)
- 105 streaming tests + 7 combined_ws tests all passing

---

_Phase: 06-combined-ws-implementation_
_Completed: 2026-03-19_
