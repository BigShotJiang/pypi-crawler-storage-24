---
phase: 02-midnight-preflight-verification
plan: 02
subsystem: streaming
tags: [sidecar, preflight, stathera, midnight, seed-override]

# Dependency graph
requires:
  - phase: 02-midnight-preflight-verification
    plan: 01
    provides: _get_midnight_crossover_tid() and _verify_yesterday_orphan() functions
provides:
  - _run_midnight_preflight() orchestrator function in sidecar.py
  - Seed override wiring in _create_engine() between _delete_today_bars and fill_from_rest
  - Integration tests proving seed override, partial failure, and graceful fallback
affects: [heartbeat-telemetry, sidecar-startup, kintsugi-midnight-repair]

# Tech tracking
tech-stack:
  added: []
  patterns: [log-only-verification-pattern, last-write-wins-seed-override]

key-files:
  created: []
  modified:
    - python/opendeviationbar/sidecar.py
    - tests/test_midnight_preflight.py

key-decisions:
  - "Verification is log-only -- orphan mismatch does NOT prevent seed override (kintsugi repairs yesterday)"
  - "Preflight runs after _delete_today_bars but before fill_from_rest -- correct ordering for clean slate + authoritative seed"
  - "All thresholds for a symbol share the same crossover_tid - 1 seed (symbol-level, not pair-level)"

patterns-established:
  - "Log-only verification: _verify_yesterday_orphan logs but does not gate behavior -- crossover TID is always authoritative when available"
  - "Last-write-wins seed: _run_midnight_preflight overrides CH seeds set by _seed_trade_ids_from_clickhouse because seed_trade_id is a simple assignment"

requirements-completed: [PREFLIGHT-03]

# Metrics
duration: 2min
completed: 2026-03-21
---

# Phase 02 Plan 02: Midnight Preflight Wiring Summary

**\_run_midnight_preflight() orchestrator wired into \_create_engine(), overriding CH seeds with verified crossover trade IDs for zero-gap midnight boundaries**

## Performance

- **Duration:** 2 min
- **Started:** 2026-03-21T14:39:42Z
- **Completed:** 2026-03-21T14:42:02Z
- **Tasks:** 2
- **Files modified:** 2

## Accomplishments

- \_run_midnight_preflight() orchestrates per-symbol crossover query, orphan verification, and seed override
- Wired into \_create_engine() between \_delete_today_bars and fill_from_rest with PREFLIGHT-03 traceability
- Graceful fallback: symbols failing preflight keep their existing CH-seeded values
- 10 total tests (6 unit from Plan 01 + 4 integration) all passing

## Task Commits

Each task was committed atomically:

1. **Task 1: Add \_run_midnight_preflight and wire into \_create_engine** - `d15b584` (feat)
2. **Task 2: Add integration tests for preflight wiring** - `99b9a04` (test)

## Files Created/Modified

- `python/opendeviationbar/sidecar.py` - Added \_run_midnight_preflight() orchestrator and wired call into_create_engine()
- `tests/test_midnight_preflight.py` - Added 4 integration tests for preflight orchestration (10 total)

## Decisions Made

- Verification is log-only: orphan mismatch does NOT prevent seed override. The crossover TID from REST is authoritative; kintsugi will repair yesterday if the orphan doesn't match.
- All thresholds for a symbol share the same crossover_tid - 1 seed, since the crossover is a symbol-level concept (first trade of the day).
- Preflight runs after \_delete_today_bars but before fill_from_rest, ensuring clean slate + authoritative seed ordering.

## Deviations from Plan

None - plan executed exactly as written.

## Issues Encountered

None

## User Setup Required

None - no external service configuration required.

## Next Phase Readiness

- Midnight preflight verification feature is complete (PREFLIGHT-01, PREFLIGHT-02, PREFLIGHT-03)
- Ready for Phase 03 (heartbeat telemetry overhaul) to validate the fixes in production

---

_Phase: 02-midnight-preflight-verification_
_Completed: 2026-03-21_
