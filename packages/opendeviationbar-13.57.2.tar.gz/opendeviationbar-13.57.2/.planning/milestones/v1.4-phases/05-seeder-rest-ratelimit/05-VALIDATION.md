---
phase: 5
slug: seeder-rest-ratelimit
status: draft
nyquist_compliant: true
wave_0_complete: false
created: 2026-03-22
updated: 2026-03-22
---

# Phase 5 — Validation Strategy

> Per-phase validation contract for feedback sampling during execution.

---

## Test Infrastructure

| Property               | Value                                                             |
| ---------------------- | ----------------------------------------------------------------- |
| **Framework**          | pytest 8.x (Python) + cargo nextest (Rust)                        |
| **Config file**        | `pyproject.toml` [tool.pytest.ini_options] + `.cargo/config.toml` |
| **Quick run command**  | `mise run test-py -- -x -q`                                       |
| **Full suite command** | `mise run check-full`                                             |
| **Estimated runtime**  | ~120 seconds                                                      |

---

## Sampling Rate

- **After every task commit:** Run `mise run test-py -- -x -q`
- **After every plan wave:** Run `mise run check-full`
- **Before `/gsd:verify-work`:** Full suite must be green
- **Max feedback latency:** 120 seconds

---

## Per-Task Verification Map

| Task ID  | Plan | Wave | Requirement          | Test Type | Automated Command                                                                                                   | File Exists | Status  |
| -------- | ---- | ---- | -------------------- | --------- | ------------------------------------------------------------------------------------------------------------------- | ----------- | ------- |
| 05-01-01 | 01   | 1    | SEEDER-04, D-07      | unit/tdd  | `uv run --python 3.13 pytest tests/test_parquet_validation.py -x -v`                                                | No (W0)     | pending |
| 05-01-02 | 01   | 1    | D-05                 | grep      | `grep "Conflicts=" scripts/systemd/opendeviationbar-seeder.service`                                                 | Yes         | pending |
| 05-02-01 | 02   | 1    | SEEDER-02, D-11      | unit/tdd  | `uv run --python 3.13 pytest tests/test_ratelimit_coordinator.py -x -v`                                             | No (W0)     | pending |
| 05-02-02 | 02   | 1    | SEEDER-03, D-13      | grep      | `grep "OPENDEVIATIONBAR_REST_CEILING" scripts/systemd/*.service`                                                    | Yes         | pending |
| 05-02-03 | 02   | 1    | D-16, D-17           | build+run | `maturin develop && python -c "from opendeviationbar._core import PyAdaptiveRateLimiter; print('OK')"`              | Yes (Rust)  | pending |
| 05-03-01 | 03   | 2    | SEEDER-01, SEEDER-04 | unit/tdd  | `uv run --python 3.13 pytest tests/test_seeder_rest_fallback.py -x -v`                                              | No (W0)     | pending |
| 05-03-02 | 03   | 2    | D-01, D-02, D-04     | config    | `python -c "from opendeviationbar.config.seeder import SeederConfig; c = SeederConfig(); assert c.batch_size == 6"` | Yes         | pending |
| 05-04-01 | 04   | 2    | SEEDER-02, D-22      | unit/tdd  | `uv run --python 3.13 pytest tests/test_heartbeat_ratelimit.py -x -v`                                               | No (W0)     | pending |
| 05-04-02 | 04   | 2    | SEEDER-03, D-25      | unit/tdd  | `uv run --python 3.13 pytest tests/test_heartbeat_seeder.py -x -v`                                                  | No (W0)     | pending |
| 05-04-03 | 04   | 2    | D-10                 | unit/tdd  | `uv run --python 3.13 pytest tests/test_heartbeat_ratelimit.py -x -v -k "vision_oracle"`                            | No (W0)     | pending |

_Status: pending / green / red / flaky_

---

## Wave 0 Requirements

- [ ] `tests/test_parquet_validation.py` -- covers D-07 (trade-ID continuity) -- created by Plan 01, Task 1
- [ ] `tests/test_ratelimit_coordinator.py` -- covers SEEDER-02, SEEDER-03, D-11, D-13 -- created by Plan 02, Task 1
- [ ] `tests/test_seeder_rest_fallback.py` -- covers SEEDER-01, SEEDER-04, D-04, D-08, D-20 -- created by Plan 03, Task 2
- [ ] `tests/test_heartbeat_ratelimit.py` -- covers D-22, D-10 (ratelimit + vision oracle) -- created by Plan 04, Task 1 and Task 3
- [ ] `tests/test_heartbeat_seeder.py` -- covers D-24, D-25 (seeder metrics) -- created by Plan 04, Task 2

_Existing test infrastructure covers Rust rate limiter tests (`rate_limiter.rs` has comprehensive tests)._

---

## Requirement Coverage Cross-Reference

| Requirement | Plan(s) | Test File(s)                                                   | Key Test(s)                                                 |
| ----------- | ------- | -------------------------------------------------------------- | ----------------------------------------------------------- |
| SEEDER-01   | 03      | `test_seeder_rest_fallback.py`                                 | `test_rest_fallback_yesterday`                              |
| SEEDER-02   | 02, 04  | `test_ratelimit_coordinator.py`, `test_heartbeat_ratelimit.py` | `test_budget_allocation`, `test_check_ratelimit_below_80`   |
| SEEDER-03   | 02, 04  | `test_ratelimit_coordinator.py`, `test_heartbeat_ratelimit.py` | `test_can_acquire_within_budget`, `test_sustained_90_alert` |
| SEEDER-04   | 01, 03  | `test_parquet_validation.py`, `test_seeder_rest_fallback.py`   | `test_never_seed_today`, `test_skip_kintsugi_processed`     |
| D-10        | 04      | `test_heartbeat_ratelimit.py`                                  | `test_vision_oracle_*`                                      |
| D-16        | 02      | (build verification)                                           | `PyAdaptiveRateLimiter.get_instance()` import test          |
| D-17        | 02      | (grep verification)                                            | `grep get_rest_rate_limiter_status backfill.py`             |

---

## Manual-Only Verifications

| Behavior                              | Requirement | Why Manual                                              | Test Instructions                                                                |
| ------------------------------------- | ----------- | ------------------------------------------------------- | -------------------------------------------------------------------------------- |
| Cross-process rate limit coordination | SEEDER-02   | Requires 3 concurrent processes sharing state           | Start sidecar + kintsugi + seeder simultaneously, verify total weight < 4800/min |
| systemd Conflicts= overlap guard      | D-05        | Requires systemd timer firing while previous run active | Set seeder to sleep 10min, trigger timer, verify second instance blocked         |
| Vision-to-REST switchover on bigblack | SEEDER-01   | Requires production Vision 404 scenario                 | Wait for post-midnight Vision delay, verify REST fallback kicks in               |

---

## Decision Traceability

| Decision | Implementing Task(s) | Verification                                                                 |
| -------- | -------------------- | ---------------------------------------------------------------------------- |
| D-01     | 03-01                | Config + REST fallback code                                                  |
| D-02     | 03-01                | Two-step fetch pattern in seeder                                             |
| D-03     | 03-01                | No ClickHouse writes in seeder                                               |
| D-04     | 03-01, 03-02         | `test_never_seed_today`                                                      |
| D-05     | 01-02                | `grep Conflicts=`                                                            |
| D-07     | 01-01                | `test_parquet_validation.py`                                                 |
| D-08     | 03-01, 03-02         | `test_meta_file_created`                                                     |
| D-09     | 01-01                | `storage.write_ticks` in seeder                                              |
| D-10     | 04-03                | `test_vision_oracle_*`                                                       |
| D-11     | 02-01                | `test_ratelimit_coordinator.py`                                              |
| D-13     | 01-02, 02-02         | `grep REST_CEILING *.service`                                                |
| D-14     | 03-01, 03-02         | `test_batch_*`                                                               |
| D-16     | 02-03                | `PyAdaptiveRateLimiter` import test                                          |
| D-17     | 02-03                | `grep get_rest_rate_limiter_status`                                          |
| D-12     | --                   | Deferred (Redis upgrade path; file-based coordinator sufficient for Phase 5) |
| D-19     | --                   | Deferred (plans use Python requests -- noted as future work)                 |
| D-20     | 03-01                | Config field + `_load_batch_offset`                                          |
| D-22     | 04-01                | `test_heartbeat_ratelimit.py`                                                |
| D-24     | 04-02                | `test_heartbeat_seeder.py`                                                   |
| D-25     | 04-02                | `test_days_behind_*`                                                         |

---

## Validation Sign-Off

- [x] All tasks have `<automated>` verify or Wave 0 dependencies
- [x] Sampling continuity: no 3 consecutive tasks without automated verify
- [x] Wave 0 covers all MISSING references
- [x] No watch-mode flags
- [x] Feedback latency < 120s
- [ ] `nyquist_compliant: true` set in frontmatter (set, pending execution)

**Approval:** pending execution
