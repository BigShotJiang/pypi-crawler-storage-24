---
phase: 05-dead-code-cleanup
verified: 2026-03-24T22:10:00Z
status: gaps_found
score: 4/5 success criteria verified
re_verification: false
gaps:
  - truth: "All 111 stale scripts identified in audit are removed from scripts/ directory"
    status: partial
    reason: "79 scripts removed (exceeds CLEAN-01's 37 count from REQUIREMENTS.md, but falls short of the 111 count stated in ROADMAP.md success criteria). The discrepancy is between REQUIREMENTS.md (CLEAN-01: 37 scripts) and ROADMAP.md (SC1: 111 scripts). Delivered 79 removes exceeds the requirement count but doesn't reach the roadmap success criterion count."
    artifacts:
      - path: "scripts/"
        issue: "47 Python files remain. Roadmap SC1 says all 111 stale scripts should be removed; 79 were removed (Plan 01 removed exactly what was audited — all pattern/benchmark/one-off scripts identified). The 111 vs 79 discrepancy may reflect the roadmap SC being set before the audit narrowed scope."
    missing:
      - "Reconcile ROADMAP.md success criterion (111 scripts) vs REQUIREMENTS.md CLEAN-01 (37 scripts) vs delivered (79 scripts). Update ROADMAP.md or confirm scope was correctly narrowed."
  - truth: "REQUIREMENTS.md traceability table updated to reflect completion"
    status: failed
    reason: "REQUIREMENTS.md traceability table still shows CLEAN-01, CLEAN-02, CLEAN-03 as 'Pending' despite phase completion. Checkbox section shows [x] but the table was not updated."
    artifacts:
      - path: ".planning/REQUIREMENTS.md"
        issue: "Lines 50-52: CLEAN-01, CLEAN-02, CLEAN-03 still show Plan=TBD, Status=Pending in traceability table"
    missing:
      - "Update REQUIREMENTS.md traceability table: set Plan=05-01/05-02 and Status=Completed for CLEAN-01, CLEAN-02, CLEAN-03"
human_verification:
  - test: "Confirm CLEAN-02 scope is satisfied — run vulture or equivalent Python dead-code scanner against the python/ package to verify no 800+ LOC dead Python code remains in subsystems"
    expected: "No significant unreachable Python code (>50 LOC per module) found in python/opendeviationbar/ subsystems"
    why_human: "The plan noted 'Python dead functions from #298 have already been cleaned in prior sessions' but no automated verification of this claim is available without the original #298 audit output. A fresh vulture scan would confirm."
---

# Phase 5: Dead Code Cleanup Verification Report

**Phase Goal:** Production codebase contains no dead scripts, dead Rust modules, or unreachable code identified in the adversarial audit
**Verified:** 2026-03-24T22:10:00Z
**Status:** gaps_found
**Re-verification:** No — initial verification

---

## Goal Achievement

### Observable Truths (from ROADMAP.md Success Criteria)

| #   | Truth                                                                        | Status      | Evidence                                                                                                                                                                                                   |
| --- | ---------------------------------------------------------------------------- | ----------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| SC1 | All 111 stale scripts identified in audit removed from `scripts/`            | ? UNCERTAIN | 79 removed (commits 6f76725 + dc7897a); 47 remain; count discrepancy between ROADMAP (111) and REQUIREMENTS.md (37) and delivered (79)                                                                     |
| SC2 | Dead Rust modules (streaming indicators/stats) and unused Cargo deps removed | ✓ VERIFIED  | indicators.rs + stats.rs deleted (commit 1b8ab7a); rolling-stats + tdigests removed from workspace Cargo.toml; cargo check passes                                                                          |
| SC3 | Stale TODOs referencing closed issues cleaned up                             | ✓ VERIFIED  | `grep "TODO.*Issue #\|TODO.*Task #"` returns zero hits across crates/ python/ src/                                                                                                                         |
| SC4 | Every removal verified unreachable before deletion                           | ✓ VERIFIED  | Cross-reference audit documented in summaries: mise tasks, systemd units, CLAUDE.md, Python imports all checked                                                                                            |
| SC5 | `mise run check-full` passes after all removals                              | ✓ VERIFIED  | 1078 tests pass (0 failures); cargo deny exits 0 ("advisories ok, bans ok, licenses ok, sources ok"); `[deny] ERROR task failed` in mise output is a mise task runner display artifact, not a real failure |

**Score:** 4/5 success criteria verified (SC1 uncertain due to count discrepancy)

---

## Required Artifacts

### Plan 01: Script Removals

| Artifact                                         | Expected                            | Status     | Details                                                        |
| ------------------------------------------------ | ----------------------------------- | ---------- | -------------------------------------------------------------- |
| `scripts/` (70 research scripts)                 | Deleted                             | ✓ VERIFIED | Commit 6f76725 confirms 70 files, 34,003 LOC deleted           |
| `scripts/` (9 benchmark/one-off scripts)         | Deleted                             | ✓ VERIFIED | Commit dc7897a confirms 9 files, 1,473 LOC deleted             |
| `docs/research/adversarial-audit-methodology.md` | Updated to note removals            | ✓ VERIFIED | Listed in commit 26ec760                                       |
| `docs/research/pattern-research-summary.md`      | Script tables marked as removed     | ✓ VERIFIED | Listed in commit 26ec760                                       |
| `scripts/run_length_momentum_multi_symbol.py`    | Kept (mise research.toml reference) | ✓ VERIFIED | File exists at expected path                                   |
| `scripts/run_length_momentum_wfo.py`             | Kept (mise research.toml reference) | ✓ VERIFIED | File exists at expected path                                   |
| `scripts/CLAUDE.md`                              | No references to deleted scripts    | ✓ VERIFIED | `grep -c "benchmark\|tda_\|regime_analysis"` returns 0 matches |

### Plan 02: Dead Rust Code and Stale TODO Cleanup

| Artifact                                                | Expected                                                 | Status     | Details                                                               |
| ------------------------------------------------------- | -------------------------------------------------------- | ---------- | --------------------------------------------------------------------- |
| `crates/opendeviationbar-streaming/src/indicators.rs`   | Deleted                                                  | ✓ VERIFIED | File absent from `crates/opendeviationbar-streaming/src/`             |
| `crates/opendeviationbar-streaming/src/stats.rs`        | Deleted                                                  | ✓ VERIFIED | File absent from `crates/opendeviationbar-streaming/src/`             |
| `crates/opendeviationbar-streaming/src/lib.rs`          | `pub mod indicators` and `pub mod stats` removed         | ✓ VERIFIED | File contains no `pub mod indicators` or `pub mod stats` declarations |
| `crates/opendeviationbar-streaming/Cargo.toml`          | rolling-stats/tdigests/stats/indicators features removed | ✓ VERIFIED | Cargo.toml contains none of these entries                             |
| `Cargo.toml` (workspace)                                | rolling-stats and tdigests removed                       | ✓ VERIFIED | `grep "rolling.stats\|tdigests"` returns no matches                   |
| `python/opendeviationbar/orchestration/helpers.py`      | `TODO(Issue #59)` removed                                | ✓ VERIFIED | `grep "TODO.*Issue #59"` returns zero hits                            |
| `crates/opendeviationbar-core/src/normalization_lut.rs` | `TODO Task #197` removed                                 | ✓ VERIFIED | `grep "TODO.*Task #197"` returns zero hits                            |

---

## Key Link Verification

| From                            | To                                         | Via             | Status     | Details                                               |
| ------------------------------- | ------------------------------------------ | --------------- | ---------- | ----------------------------------------------------- |
| `streaming/src/lib.rs`          | `streaming/src/indicators.rs`              | `pub mod`       | ✓ VERIFIED | pub mod indicators no longer in lib.rs (both deleted) |
| `streaming/src/lib.rs`          | `streaming/src/stats.rs`                   | `pub mod`       | ✓ VERIFIED | pub mod stats no longer in lib.rs (both deleted)      |
| Remaining scripts in `scripts/` | mise tasks / systemd / CLAUDE.md / imports | cross-ref audit | ✓ VERIFIED | No broken references found in non-.planning dirs      |

---

## Data-Flow Trace (Level 4)

Not applicable — this is a cleanup phase with no new dynamic data rendering.

---

## Behavioral Spot-Checks

| Behavior                               | Command                                              | Result                                                     | Status |
| -------------------------------------- | ---------------------------------------------------- | ---------------------------------------------------------- | ------ |
| Workspace compiles after Rust removals | `cargo check --workspace`                            | `Finished dev profile` (0 errors)                          | ✓ PASS |
| No stale TODO Issue refs remain        | `grep "TODO.*Issue #\|TODO.*Task #" ...`             | 0 matches                                                  | ✓ PASS |
| indicators/stats.rs absent             | `ls crates/opendeviationbar-streaming/src/`          | Neither file present                                       | ✓ PASS |
| Deleted scripts unreferenced           | `grep -rn "benchmark_apen.*\|benchmark_arrow.*" ...` | Only .claude/worktrees/ (ephemeral)                        | ✓ PASS |
| All Rust tests pass                    | `mise run check-full` (via btv51uhqr log)            | 1078 passed, 0 failures, 2 skipped                         | ✓ PASS |
| cargo deny clean                       | `cargo deny check`                                   | "advisories ok, bans ok, licenses ok, sources ok" (exit 0) | ✓ PASS |

---

## Requirements Coverage

| Requirement | Source Plan  | Description                                           | Status      | Evidence                                                                                                                                                                                                 |
| ----------- | ------------ | ----------------------------------------------------- | ----------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| CLEAN-01    | 05-01        | Remove 37 identified stale scripts from scripts/      | ✓ SATISFIED | 79 scripts removed — exceeds stated 37 count. Commits 6f76725 + dc7897a confirmed.                                                                                                                       |
| CLEAN-02    | 05-02        | Remove 800+ LOC dead Python code across subsystems    | ? PARTIAL   | ~1094 LOC dead **Rust** code removed (indicators.rs + stats.rs). Plan 02 claims prior sessions removed the Python dead code from #298 audit. Not independently verified. Human verification recommended. |
| CLEAN-03    | 05-01, 05-02 | All removed code verified unreachable before deletion | ✓ SATISFIED | Cross-reference audit documented: mise tasks, systemd units, CLAUDE.md, Python imports, `grep` checks before each deletion.                                                                              |

**Orphaned requirements in REQUIREMENTS.md traceability table:** CLEAN-01, CLEAN-02, CLEAN-03 traceability rows still show `Plan=TBD, Status=Pending` — not updated to reflect completion.

---

## Anti-Patterns Found

| File                        | Line  | Pattern                        | Severity   | Impact                                                                            |
| --------------------------- | ----- | ------------------------------ | ---------- | --------------------------------------------------------------------------------- |
| `.planning/REQUIREMENTS.md` | 50-52 | Traceability table not updated | ⚠️ Warning | CLEAN-01/02/03 show Status=Pending; misleads future phases about completion state |

No code anti-patterns found in production files. No TODO stubs, no placeholder implementations, no orphaned modules.

---

## Human Verification Required

### 1. CLEAN-02 Python Dead Code Verification

**Test:** Run `uv run --python 3.13 vulture python/opendeviationbar/ --min-confidence 80` from the project root
**Expected:** No significant dead Python code blocks (>50 LOC per module) in production subsystems
**Why human:** Plan 02 states "Python dead functions from #298 have already been cleaned in prior sessions" without commit evidence in this phase. The original #298 audit output is unavailable for cross-reference. A vulture scan would confirm or refute.

---

## Gaps Summary

**Two items prevent full confidence:**

1. **Script count discrepancy (SC1 uncertain):** The ROADMAP.md success criterion says "All 111 stale scripts identified in audit are removed" but the delivered work removed 79 scripts, and REQUIREMENTS.md CLEAN-01 only required 37. The count 79 > 37 (REQUIREMENTS.md threshold satisfied), but 79 < 111 (ROADMAP threshold not reached). The most likely explanation is that the 111 figure in the ROADMAP was the original audit estimate that was later refined when the actual plans were written. This should be documented by updating ROADMAP.md to reflect the actual scope delivered (79 scripts), or confirming the remaining 32 are in scope for a future sub-plan.

2. **REQUIREMENTS.md traceability table not updated (housekeeping gap):** The checkbox section correctly shows [x] for all three requirements, but the traceability table was not updated. This is a documentation gap that could cause confusion for future phases reading the requirements doc.

**All production code goals are met:** Dead Rust modules removed, stale TODOs cleaned, workspace compiles, 1078 tests pass, no broken references in production code.

---

_Verified: 2026-03-24T22:10:00Z_
_Verifier: Claude (gsd-verifier)_
