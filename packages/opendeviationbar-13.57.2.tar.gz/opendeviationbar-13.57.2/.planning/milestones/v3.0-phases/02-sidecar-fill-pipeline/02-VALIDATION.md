---
phase: 02
slug: sidecar-fill-pipeline
status: draft
nyquist_compliant: false
wave_0_complete: false
created: 2026-03-24
---

# Phase 02 — Validation Strategy

> Per-phase validation contract for feedback sampling during execution.

---

## Test Infrastructure

| Property               | Value                                            |
| ---------------------- | ------------------------------------------------ |
| **Framework**          | pytest 7.x + cargo nextest                       |
| **Config file**        | `pyproject.toml` / `Cargo.toml`                  |
| **Quick run command**  | `mise run test-py -- -k "sync_flush or sidecar"` |
| **Full suite command** | `mise run check-full`                            |
| **Estimated runtime**  | ~60 seconds                                      |

---

## Sampling Rate

- **After every task commit:** Run `mise run test-py -- -k "sync_flush or sidecar"`
- **After every plan wave:** Run `mise run check-full`
- **Before `/gsd:verify-work`:** Full suite must be green
- **Max feedback latency:** 60 seconds

---

## Per-Task Verification Map

| Task ID  | Plan | Wave | Requirement  | Test Type | Automated Command                                                                  | File Exists | Status     |
| -------- | ---- | ---- | ------------ | --------- | ---------------------------------------------------------------------------------- | ----------- | ---------- |
| 02-01-01 | 01   | 1    | STREAM-01    | grep+unit | `grep -n "def fill_from_rest" python/opendeviationbar/sidecar/midnight.py`         | ✅          | ⬜ pending |
| 02-01-02 | 01   | 1    | STREAM-02    | grep      | `grep -n "last_agg_trade_id.*first_agg_trade_id" python/opendeviationbar/sidecar/` | ✅          | ⬜ pending |
| 02-02-01 | 02   | 2    | STREAM-01+02 | manual    | SSH to bigblack, restart sidecar, check Stathera continuity in heartbeat           | N/A         | ⬜ pending |

_Status: ⬜ pending · ✅ green · ❌ red · ⚠️ flaky_

---

## Wave 0 Requirements

Existing infrastructure covers all phase requirements. No new test files needed.

---

## Manual-Only Verifications

| Behavior                                  | Requirement | Why Manual                         | Test Instructions                                                                    |
| ----------------------------------------- | ----------- | ---------------------------------- | ------------------------------------------------------------------------------------ |
| Stathera continuity after sidecar restart | STREAM-02   | Requires production WS + REST data | SSH to bigblack, restart sidecar, wait 5 min, check heartbeat for zero Stathera gaps |

---

## Validation Sign-Off

- [ ] All tasks have `<automated>` verify or Wave 0 dependencies
- [ ] Sampling continuity: no 3 consecutive tasks without automated verify
- [ ] Wave 0 covers all MISSING references
- [ ] No watch-mode flags
- [ ] Feedback latency < 60s
- [ ] `nyquist_compliant: true` set in frontmatter

**Approval:** pending
