# Deferred Items — Phase 02

## Pre-existing Test Failures

1. **test_cross_midnight_bars_filtered** (`tests/test_sync_flush_atomic_replace.py`): `_make_bar` uses keys `open_time_us`/`close_time_us` but midnight.py L1 filter checks `open_time_ms`/`close_time_ms`. The test was already failing before Phase 02 changes.

2. **test_get_midnight_crossover_tid_success** (`tests/test_midnight_preflight.py`): Test calls real Binance REST API without mocking, returning live data that doesn't match hardcoded expected value. Pre-existing.
