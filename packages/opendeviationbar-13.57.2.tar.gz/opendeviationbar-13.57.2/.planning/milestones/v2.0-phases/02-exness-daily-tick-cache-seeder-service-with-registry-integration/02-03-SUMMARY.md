---
phase: 02-exness-daily-tick-cache-seeder-service-with-registry-integration
plan: 03
subsystem: infra
tags: [systemd, monit, exness, forex, seeder, documentation]

# Dependency graph
requires:
  - phase: 02-01
    provides: "Exness seeder script (exness_tick_cache_seeder.py) that this plan deploys"
provides:
  - "systemd oneshot service + 1h timer for Exness seeder"
  - "monit exness-seeder-state freshness monitor (2h threshold)"
  - "CLAUDE.md hub-and-spoke documentation for Exness seeder"
affects: [deploy, scripts, monitoring]

# Tech tracking
tech-stack:
  added: []
  patterns:
    [
      "systemd oneshot+timer for periodic seeder",
      "monit file freshness monitor at 2x timer interval",
    ]

key-files:
  created:
    - "scripts/systemd/opendeviationbar-exness-seeder.service"
    - "scripts/systemd/opendeviationbar-exness-seeder.timer"
  modified:
    - "deploy/monit/opendeviationbar.conf"
    - "scripts/CLAUDE.md"
    - "scripts/systemd/CLAUDE.md"
    - "deploy/CLAUDE.md"
    - "CLAUDE.md"

key-decisions:
  - "MemoryHigh=2G/MemoryMax=4G for Exness seeder (forex data ~10x smaller than crypto)"
  - "1h timer interval (OnUnitActiveSec=3600) — forex data volume does not need 5min polling"
  - "120 min monit freshness threshold (2x the 1h timer interval, matching seeder-state pattern)"

patterns-established:
  - "Monit freshness threshold = 2x timer interval for all seeders"

requirements-completed: [EXNS-SVC, EXNS-MON, EXNS-DOC]

# Metrics
duration: 3m23s
completed: 2026-03-23
---

# Phase 02 Plan 03: Systemd Service + Timer, Monit Monitor, CLAUDE.md Documentation Summary

**systemd oneshot service with 1h timer, monit 2h freshness monitor, and 4 CLAUDE.md files updated for Exness forex seeder deployment infrastructure**

## Performance

- **Duration:** 3m 23s
- **Started:** 2026-03-23T19:31:20Z
- **Completed:** 2026-03-23T19:34:43Z
- **Tasks:** 2
- **Files modified:** 7

## Accomplishments

- Created systemd oneshot service with MemoryHigh=2G/MemoryMax=4G, mimalloc, TZ=UTC
- Created 1h systemd timer (OnBootSec=300, OnUnitActiveSec=3600) for forex data cadence
- Added monit exness-seeder-state monitor with 2h freshness threshold and failed pattern match (11 total monitors)
- Updated 4 CLAUDE.md files across hub-and-spoke network with Exness seeder documentation

## Task Commits

Each task was committed atomically:

1. **Task 1: Create systemd service + timer and monit monitor** - `b931818` (feat)
2. **Task 2: Update CLAUDE.md hub-and-spoke network with Exness seeder docs** - `4ba9748` (docs)

## Files Created/Modified

- `scripts/systemd/opendeviationbar-exness-seeder.service` - systemd oneshot service for Exness forex tick cache seeder
- `scripts/systemd/opendeviationbar-exness-seeder.timer` - 1h timer triggering the seeder service
- `deploy/monit/opendeviationbar.conf` - Added exness-seeder-state monitor (11 total)
- `scripts/CLAUDE.md` - Added "Exness Forex Tick Cache Seeder (Phase 02)" section with service design and comparison table
- `scripts/systemd/CLAUDE.md` - Added service row (6 units), timer row (3 timers)
- `deploy/CLAUDE.md` - Added exness-seeder-state monitor row (11 total)
- `CLAUDE.md` - Added Quick Reference row, updated architecture tree, updated monitor count and service/timer counts

## Decisions Made

- MemoryHigh=2G/MemoryMax=4G chosen because forex data is ~10x smaller than Binance crypto data
- 1h timer interval matches the lower data velocity of forex tick archives vs 5min for Binance
- Monit 120min freshness threshold follows the pattern of 2x timer interval (matching Binance seeder-state at 15min = 3x its 5min interval)

## Deviations from Plan

None - plan executed exactly as written.

## Known Stubs

None.

## Issues Encountered

None.

## User Setup Required

None - no external service configuration required.

## Next Phase Readiness

- Deployment infrastructure complete for Exness seeder
- Ready for `mise run deploy:bigblack` to sync service/timer files and enable the timer
- Monit config requires `scp` + `sudo monit reload` on bigblack

---

## Self-Check: PASSED

All 7 files verified present. Both commit hashes (b931818, 4ba9748) found in git log.

---

_Phase: 02-exness-daily-tick-cache-seeder-service-with-registry-integration_
_Completed: 2026-03-23_
