# Phase 4: Microsecond Data Layer - Context

**Gathered:** 2026-03-24
**Status:** Ready for planning
**Mode:** Auto-generated (infrastructure phase — discuss skipped)

<domain>
## Phase Boundary

Migrate the entire tick data + bar timestamp pipeline from millisecond to microsecond precision. Three layers: (1) Binance seeder writes us timestamps to Parquet, (2) Rust OpenDeviationBarProcessor accepts/outputs us natively, (3) all existing Parquet tick caches are reseeded with us timestamps. Exness seeder already writes us timestamps (shipped earlier this session).

</domain>

<decisions>
## Implementation Decisions

### Claude's Discretion

All implementation choices are at Claude's discretion — pure infrastructure phase. Use ROADMAP phase goal, success criteria, and codebase conventions to guide decisions.

Key constraints from ROADMAP success criteria:

- USEC-01: Seeder writes 16-digit microsecond timestamps for post-2025-01-01 data
- USEC-02: Pre-2025 Parquet files reseeded with ms-to-us upscaled timestamps
- USEC-04: Rust processor accepts and outputs microsecond timestamps throughout
- Bars from reseeded data must pass Stathera continuity validation

</decisions>

<canonical_refs>

## Canonical References

**Downstream agents MUST read these before planning or implementing.**

### Tick seeder (Binance)

- `scripts/tick_cache_seeder.py` — Binance seeder (needs ms→us change)
- `python/opendeviationbar/storage/parquet_io.py` — Parquet write path
- `python/opendeviationbar/storage/parquet_query.py` — Parquet read path

### Tick seeder (Exness) — already migrated to us

- `scripts/exness_tick_cache_seeder.py` — Reference for us timestamp convention

### Rust processor

- `crates/opendeviationbar-core/src/processor.rs` — Core bar algorithm (timestamp handling)
- `src/core_bindings.rs` — PyO3 bindings (timestamp conversion)
- `src/arrow_bindings.rs` — Arrow export (timestamp column types)

### Existing us migration reference

- Exness seeder already uses `dt.epoch(time_unit="us")` — verified bit-exact on bigblack

</canonical_refs>

<specifics>
## Specific Ideas

No specific requirements — infrastructure phase. Refer to ROADMAP phase description and success criteria.

</specifics>

<deferred>
## Deferred Ideas

None — discuss phase skipped.

</deferred>

---

_Phase: 04-microsecond-data-layer_
_Context gathered: 2026-03-24 via autonomous mode (infrastructure phase)_
