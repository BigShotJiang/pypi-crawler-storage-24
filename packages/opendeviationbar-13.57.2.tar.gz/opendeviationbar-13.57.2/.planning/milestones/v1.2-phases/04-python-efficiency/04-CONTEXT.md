# Phase 4: Python Efficiency (P6-P8) - Context

**Gathered:** 2026-03-20
**Status:** Ready for planning

<domain>
## Phase Boundary

Eliminate redundant config instantiation in kintsugi repairs, reduce Vision 404 TTL for recent dates, and remove unnecessary DataFrame copy in bulk operations.

</domain>

<decisions>
## Implementation Decisions

### Claude's Discretion

All implementation choices are at Claude's discretion — pure infrastructure phase.

</decisions>

<code_context>

## Existing Code Insights

### Reusable Assets

- `python/opendeviationbar/kintsugi.py:81` — `_kintsugi_cfg()` function (returns `KintsugiConfig()` each call)
- `python/opendeviationbar/kintsugi.py:994,1001,1043,1075,1685,2018,2025` — 7+ call sites of `_kintsugi_cfg()` within `_repair()` and `kintsugi_pass()`
- `python/opendeviationbar/kintsugi.py:1740` — already has `cfg = _kintsugi_cfg()` local binding in `kintsugi_pass()`
- `python/opendeviationbar/config/backfill.py:52` — `vision_probe_ttl_s: int = 3600` (current 1-hour TTL)
- `python/opendeviationbar/backfill.py:98` — Redis `ex=_backfill_cfg().vision_probe_ttl_s` (where TTL is applied)
- `python/opendeviationbar/clickhouse/bulk_operations.py:503` — `df = bars.copy()` (the redundant copy)

### Established Patterns

- Pydantic Settings (`BaseSettings`) — config classes instantiate from env vars each time
- Redis TTL is set via `ex=` parameter on `redis.set()` calls
- `_kintsugi_cfg()` is a module-level function, not cached — each call creates new `KintsugiConfig()`

### Integration Points

- `_repair()` in kintsugi.py — the per-shard repair function where config is called repeatedly
- `backfill.py` — Vision availability probe with Redis TTL
- `bulk_operations.py:store_bars_bulk()` — ClickHouse write path

</code_context>

<specifics>
## Specific Ideas

No specific requirements — infrastructure phase.

</specifics>

<deferred>
## Deferred Ideas

None — discussion stayed within phase scope.

</deferred>
