# Phase 4: Heartbeat Coverage - Context

**Gathered:** 2026-03-25
**Status:** Ready for planning
**Mode:** Auto-generated (infrastructure phase)

<domain>
## Phase Boundary

Expand `HEARTBEAT_PRIORITY_SYMBOLS` from 2 hardcoded symbols (BTCUSDT, ETHUSDT) to all streaming Binance symbols. The yesterday completion check should detect orphan TID mismatches for every monitored symbol.

</domain>

<decisions>
## Implementation Decisions

### Claude's Discretion

Key facts:

- `scripts/heartbeat/config.py:19` — `HEARTBEAT_PRIORITY_SYMBOLS = ("BTCUSDT", "ETHUSDT")`
- `scripts/heartbeat/checks/yesterday.py` — iterates over this tuple for completion check
- The symbol list should come from the symbol registry (not hardcoded) — use `get_registered_symbols()` or similar
- Filter to Binance spot symbols only (forex symbols don't have `agg_trade_id`)
- Keep the heartbeat performant — one REST call per symbol for crossover TID (uses shared utility from Phase 1)

</decisions>

<canonical_refs>

## Canonical References

- `scripts/heartbeat/config.py` — `HEARTBEAT_PRIORITY_SYMBOLS` definition
- `scripts/heartbeat/checks/yesterday.py` — yesterday completion check
- `python/opendeviationbar/symbol_registry.py` — `get_registered_symbols()`, `get_symbol_market()`
- `python/opendeviationbar/crossover.py` — shared `get_crossover_tid()` (Phase 1)
  </canonical_refs>

<code_context>

## Existing Code Insights

- `get_symbol_market(symbol)` returns `"binance_spot"` or `"exness_forex"` — use to filter
- The yesterday check does 1 REST call + 1 CH query per symbol — scaling from 2 to 17+ symbols adds ~15 REST calls (cheap, <1s each)
- Heartbeat runs every 5 min — 17 symbols at <1s each = ~17s total, well within budget
  </code_context>

<specifics>
No specific requirements.
</specifics>

<deferred>
None.
</deferred>

---

_Phase: 04-heartbeat-coverage_
_Context gathered: 2026-03-25_
