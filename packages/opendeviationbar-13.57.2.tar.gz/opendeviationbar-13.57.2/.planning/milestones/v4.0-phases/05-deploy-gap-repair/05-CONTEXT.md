# Phase 5: Deploy Gap Repair - Context

**Gathered:** 2026-03-25
**Status:** Ready for planning
**Mode:** Auto-generated (infrastructure phase)

<domain>
## Phase Boundary

Fix `backfill_gap()` trailing edge calculation to use correct microsecond values from the renamed `close_time_us` column. Verify cross-midnight gap repair works end-to-end for all streaming pairs.

</domain>

<decisions>
## Implementation Decisions

### Claude's Discretion

Key facts:

- `python/opendeviationbar/backfill.py` line 53: `now_ms = int(datetime.now(UTC).timestamp() * 1000)` — computes milliseconds
- The CH query returns `close_time_us` (microseconds after Phase 3-4 rename)
- Fix: compute `now_us = int(datetime.now(UTC).timestamp() * 1_000_000)` and compare directly with `close_time_us`
- OR: convert `close_time_us / 1000` to ms — but this loses precision. Better to use µs throughout.
- All variable names in backfill.py should change from `_ms` to `_us` for consistency
- odb-ship Phase 4.6b already has the gap repair step documented — just needs to reference the fixed function

</decisions>

<canonical_refs>

## Canonical References

- `python/opendeviationbar/backfill.py` — `backfill_gap()` function with the trailing edge bug
- `.claude/skills/odb-ship/SKILL.md` §"4.6b Cross-Midnight Gap Repair" — deploy integration
  </canonical_refs>

<code_context>

## Existing Code Insights

- `backfill_gap()` queries CH for `max(close_time_us)` (after Phase 4 rename)
- Compares against `now_ms` (milliseconds) — unit mismatch causes negative gap
- Fix is straightforward: align both sides to microseconds
  </code_context>

<specifics>
No specific requirements.
</specifics>

<deferred>
None.
</deferred>

---

_Phase: 05-deploy-gap-repair_
_Context gathered: 2026-03-25_
