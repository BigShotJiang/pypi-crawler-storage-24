# Phase 2: Rust Dict Export Rename - Context

**Gathered:** 2026-03-25
**Status:** Ready for planning
**Mode:** Auto-generated (infrastructure phase)

<domain>
## Phase Boundary

Change Rust dict export keys from `open_time_ms`/`close_time_ms` to `open_time_us`/`close_time_us` in helpers.rs. The values must also change — currently helpers.rs divides microseconds by 1000 to produce milliseconds. After this change, export the raw microsecond values directly (no division).

</domain>

<decisions>
## Implementation Decisions

### Claude's Discretion

Key facts:

- `src/helpers.rs:103-104` currently does `us / 1000` to produce ms values with `_ms` keys
- After rename: export raw `us` values with `_us` keys (remove the `/1000` division)
- Arrow export already uses `open_time`/`close_time` with raw µs values — dict path should match
- This is the SOURCE change — all downstream Python/SQL consumers depend on these key names
- `cargo test` must pass after the change

</decisions>

<canonical_refs>

## Canonical References

- `src/helpers.rs` — `opendeviationbar_to_dict()` function, lines 103-104
- `src/arrow_bindings.rs` — Arrow export (already uses µs, no `_ms` suffix)
- `crates/CLAUDE.md` §"Timestamp Handling" — documents the ms/us export paths
  </canonical_refs>

<code_context>

## Existing Code Insights

- Dict export: `("open_time_ms", us/1000)`, `("close_time_ms", us/1000)` → change to `("open_time_us", us)`
- Arrow export: already correct (`open_time`, `close_time` in µs)
- Python consumers read these keys — they'll break until Phase 4 updates them
  </code_context>

<specifics>
No specific requirements.
</specifics>

<deferred>
None.
</deferred>

---

_Phase: 02-rust-dict-export-rename_
_Context gathered: 2026-03-25_
