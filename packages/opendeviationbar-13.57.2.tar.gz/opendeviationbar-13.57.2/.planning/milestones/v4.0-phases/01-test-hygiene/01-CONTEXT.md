# Phase 1: Test Hygiene - Context

**Gathered:** 2026-03-25
**Status:** Ready for planning
**Mode:** Auto-generated (infrastructure phase — smart discuss skipped)

<domain>
## Phase Boundary

Fix `test_data_contracts.py` schema validation (currently failing due to `open_time_ms` not in Arrow DataFrame output) and delete `test_heal_scoping.py` (tests removed `_check_and_heal_overlaps` function). Clean test baseline before the bulk `_ms` → `_us` rename.

</domain>

<decisions>
## Implementation Decisions

### Claude's Discretion

All implementation choices at Claude's discretion — infrastructure cleanup. Key facts:

- `test_data_contracts.py` fails because Arrow path produces `open_time_us`/`close_time_us` but the pandera schema expects `open_time_ms`/`close_time_ms`
- `test_heal_scoping.py` tests `_check_and_heal_overlaps()` which was removed from the codebase (zero references)
- After Phase 2-4 complete the `_ms` → `_us` rename, the schema in `test_data_contracts.py` will need `_us` column names — fix it NOW to expect the Arrow output as-is

</decisions>

<canonical_refs>

## Canonical References

- `tests/test_data_contracts.py` — failing pandera schema test
- `tests/test_heal_scoping.py` — dead code test to delete
- `src/helpers.rs:103-104` — Rust dict export produces `open_time_ms`/`close_time_ms` keys
- `src/arrow_bindings.rs` — Arrow export produces `open_time`/`close_time` (microseconds, no suffix)
  </canonical_refs>

<code_context>

## Existing Code Insights

- Arrow path: `open_time`/`close_time` (µs, no `_ms` suffix) — this is the correct naming
- Dict path: `open_time_ms`/`close_time_ms` (actually ms, helpers.rs divides by 1000) — will become `_us` in Phase 2
- The test should validate against the Arrow path output as-is
  </code_context>

<specifics>
## Specific Ideas
No specific requirements.
</specifics>

<deferred>
## Deferred Ideas
None.
</deferred>

---

_Phase: 01-test-hygiene_
_Context gathered: 2026-03-25_
