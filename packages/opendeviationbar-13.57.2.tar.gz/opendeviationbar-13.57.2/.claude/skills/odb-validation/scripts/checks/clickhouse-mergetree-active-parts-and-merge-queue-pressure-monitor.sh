#!/usr/bin/env bash
# ClickHouse MergeTree Active Parts and Merge Queue Pressure Monitor
#
# The opendeviationbar_cache database uses ReplacingMergeTree tables.
# Under heavy kintsugi repair throughput, each INSERT creates new parts
# that must be merged in the background. If inserts outpace merges:
#   - active_parts approaches parts_to_delay_insert (1000) → inserts slow
#   - active_parts approaches parts_to_throw_insert (3000) → inserts fail
#
# Mutation pressure (pending_mutations > 0) occurs after ALTER TABLE DELETE
# (e.g., _aletheia_purge or kintsugi crash-safe replace operations).
#
# Escalation levels (aligned with perf-analysis skill capacity model):
#   active_parts > 800 or pending_merges > 10 — FAIL (immediate risk)
#   active_parts > 500 or pending_merges > 5  — WARN (approaching limit)
#   pending_mutations > 0                     — informational (expected during repair)
set -euo pipefail

CH="http://localhost:8123/"

active_parts=$(curl -sf "$CH" --data-binary \
  "SELECT sum(active_parts) FROM system.tables
   WHERE database = 'opendeviationbar_cache'" | tr -d '[:space:]')

pending_merges=$(curl -sf "$CH" --data-binary \
  "SELECT count() FROM system.merges
   WHERE database = 'opendeviationbar_cache'" | tr -d '[:space:]')

pending_mutations=$(curl -sf "$CH" --data-binary \
  "SELECT countIf(is_done = 0) FROM system.mutations
   WHERE database = 'opendeviationbar_cache'" | tr -d '[:space:]')

# ClickHouse merge thread pool size (background_pool_size)
merge_pool=$(curl -sf "$CH" --data-binary \
  "SELECT value FROM system.settings WHERE name = 'background_pool_size'" | tr -d '[:space:]' || echo "unknown")

echo "ClickHouse MergeTree active parts and merge queue pressure monitor"
echo "  Active parts (warn>500, fail>800):  $active_parts  (parts_to_delay=1000, parts_to_throw=3000)"
echo "  Pending merges (warn>5, fail>10):   $pending_merges  (merge pool: $merge_pool threads)"
echo "  Pending mutations:                  $pending_mutations  (expected 0 between repair passes)"

status=0
if   [[ "$active_parts" -gt 800 ]] || [[ "$pending_merges" -gt 10 ]]; then
  echo "  Status: FAIL — parts/merge pressure critical. Reduce MAX_CONCURRENT_REPAIRS immediately."
  status=2
elif [[ "$active_parts" -gt 500 ]] || [[ "$pending_merges" -gt 5 ]]; then
  echo "  Status: WARN — parts/merge pressure elevated. Hold parallelism, do not increase."
  status=1
else
  if [[ "$pending_mutations" -gt 0 ]]; then
    echo "  Status: PASS (note: $pending_mutations pending mutation(s) from recent ALTER TABLE DELETE)"
  else
    echo "  Status: PASS"
  fi
fi
exit $status
