-- Active parts count for open_deviation_bars table
-- Healthy: <300 | Yellow: >500 | Red: >800
-- Parts accumulate with each INSERT; ClickHouse merges them in background.
-- At parts_to_delay_insert (1000), inserts are artificially slowed.
-- At parts_to_throw_insert (3000), inserts fail with "Too many parts".

SELECT
    count() AS active_parts,
    sum(rows) AS total_rows,
    formatReadableSize(sum(bytes_on_disk)) AS disk_size,
    min(modification_time) AS oldest_part,
    max(modification_time) AS newest_part
FROM system.parts
WHERE database = 'opendeviationbar_cache'
  AND table = 'open_deviation_bars'
  AND active
FORMAT PrettyCompact
