-- ClickHouse memory usage and allocation metrics
-- Cross-reference with `free -h` for system-wide view.

SELECT
    metric,
    formatReadableSize(value) AS current_value
FROM system.metrics
WHERE metric IN (
    'MemoryTracking',
    'MemoryResident',
    'BackgroundMergesAndMutationsPoolSize',
    'BackgroundMergesAndMutationsPoolTask'
)
ORDER BY metric
FORMAT PrettyCompact
