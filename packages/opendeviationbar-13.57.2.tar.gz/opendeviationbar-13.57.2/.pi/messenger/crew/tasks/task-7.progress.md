[2026-03-02T20:43:59.492Z] (system) Assigned to crew-worker (attempt 1)
[2026-03-12T20:39:49.178Z] (system) Worker exited without completing task, reset to todo
[2026-03-12T20:39:49.305Z] (system) Assigned to worker QuickQuartz (attempt 2)
