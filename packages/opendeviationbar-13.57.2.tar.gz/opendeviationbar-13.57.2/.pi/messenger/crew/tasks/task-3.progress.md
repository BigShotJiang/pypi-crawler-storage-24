[2026-03-02T20:43:59.491Z] (system) Assigned to crew-worker (attempt 1)
