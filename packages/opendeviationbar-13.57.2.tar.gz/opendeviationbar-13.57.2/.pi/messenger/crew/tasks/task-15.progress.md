[2026-03-12T20:42:57.817Z] (system) Assigned to crew-worker (attempt 1)
[2026-03-12T20:48:03.016Z] (system) Assigned to crew-worker (attempt 1)
[2026-03-12T20:57:03.713Z] (system) Assigned to crew-worker (attempt 1)
