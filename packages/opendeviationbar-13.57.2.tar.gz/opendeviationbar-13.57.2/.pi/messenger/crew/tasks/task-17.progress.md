[2026-03-12T20:42:57.818Z] (system) Assigned to crew-worker (attempt 1)
[2026-03-12T20:48:03.018Z] (system) Assigned to crew-worker (attempt 1)
