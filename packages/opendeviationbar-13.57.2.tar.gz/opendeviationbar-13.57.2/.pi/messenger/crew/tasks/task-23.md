# backfill.py registry integration

Document hardcoded thresholds in backfill.py (_PRIORITY_SYMBOLS, default threshold param) and propose registry integration for priority symbols and default threshold
