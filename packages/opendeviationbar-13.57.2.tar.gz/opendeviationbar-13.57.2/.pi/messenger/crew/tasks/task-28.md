# Audit CLI tools and PyO3 bindings

Audit Rust CLI tools (spot_tier1_processor, chart tool) for hardcoded defaults. Check PyO3 bindings in src/core_bindings.rs for threshold parameter passing from Python.
