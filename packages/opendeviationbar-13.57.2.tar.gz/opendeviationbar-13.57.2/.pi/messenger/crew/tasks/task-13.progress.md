[2026-03-12T20:42:57.816Z] (system) Assigned to crew-worker (attempt 1)
[2026-03-12T20:47:53.778Z] (system) Worker exited without completing task, reset to todo
[2026-03-12T20:48:03.015Z] (system) Assigned to crew-worker (attempt 2)
[2026-03-12T20:56:58.488Z] (system) Worker exited without completing task, reset to todo
[2026-03-12T20:57:03.712Z] (system) Assigned to crew-worker (attempt 3)
