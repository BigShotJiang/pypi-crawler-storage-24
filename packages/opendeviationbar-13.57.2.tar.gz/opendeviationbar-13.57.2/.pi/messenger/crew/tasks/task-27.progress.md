[2026-03-12T21:02:01.532Z] (system) Assigned to crew-worker (attempt 1)
[2026-03-12T21:04:35.431Z] (system) Assigned to crew-worker (attempt 1)
[2026-03-12T21:05:23.079Z] (system) Assigned to crew-worker (attempt 1)
[2026-03-12T21:06:22.657Z] (system) Worker exited without completing task, reset to todo
[2026-03-12T21:06:22.891Z] (system) Assigned to worker OakHawk (attempt 2)
[2026-03-12T21:07:02.084Z] (system) Lobby worker OakHawk exited (code 0), reset to todo
[2026-03-12T21:07:02.123Z] (system) Assigned to worker SwiftNova (attempt 3)
[2026-03-12T21:07:17.199Z] (system) Lobby worker SwiftNova exited (code 0), reset to todo
[2026-03-12T21:07:17.292Z] (system) Assigned to worker ZenGrove (attempt 4)
[2026-03-12T21:08:02.663Z] (system) Lobby worker ZenGrove exited (code 0), reset to todo
[2026-03-12T21:08:02.686Z] (system) Assigned to worker QuickJaguar (attempt 5)
[2026-03-12T21:20:24.366Z] (system) Auto-blocked after 5 attempts (max: 5)
