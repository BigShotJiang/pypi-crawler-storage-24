[2026-03-12T20:42:57.816Z] (system) Assigned to crew-worker (attempt 1)
[2026-03-12T20:47:53.777Z] (system) Worker exited without completing task, reset to todo
[2026-03-12T20:48:03.015Z] (system) Assigned to crew-worker (attempt 2)
[2026-03-12T20:56:58.487Z] (system) Worker exited without completing task, reset to todo
[2026-03-12T20:57:03.711Z] (system) Assigned to crew-worker (attempt 3)
[2026-03-12T21:01:37.153Z] (system) Worker exited without completing task, reset to todo
[2026-03-12T21:02:01.530Z] (system) Assigned to crew-worker (attempt 4)
[2026-03-12T21:03:01.785Z] (system) Assigned to worker IronDragon (attempt 4)
[2026-03-12T21:03:16.751Z] (system) Lobby worker IronDragon exited (code 0), reset to todo
[2026-03-12T21:03:16.873Z] (system) Assigned to worker MintIce (attempt 5)
[2026-03-12T21:20:24.366Z] (system) Auto-blocked after 5 attempts (max: 5)
