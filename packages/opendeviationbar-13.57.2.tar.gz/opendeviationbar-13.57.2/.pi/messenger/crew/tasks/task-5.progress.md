[2026-03-02T20:43:59.492Z] (system) Assigned to crew-worker (attempt 1)
