[2026-03-12T20:42:57.819Z] (system) Assigned to crew-worker (attempt 1)
[2026-03-12T21:20:35.653Z] (system) Assigned to crew-worker (attempt 2)
