# config files registry integration

Document hardcoded thresholds in config/sidecar.py and config/population.py; propose registry as single source of truth for defaults
