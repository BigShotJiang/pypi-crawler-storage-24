# Task 7: Scripts CLAUDE.md Alignment

Investigate and verify that `/scripts/CLAUDE.md` (15KB) matches actual scripts in `scripts/` directory. Create scaffolding directory at `/tmp/crew-scripts/`. List all `.py` and `.sh` scripts and compare to documented ones (verified 150+ scripts exist); verify mise commands exist in `.mise.toml`; check pueue orchestration scripts are documented; validate cache population scripts exist. Use Dynamic Task Creation: for missing scripts or wrong commands, create sub-tasks. Broadcast key findings to all peers.
