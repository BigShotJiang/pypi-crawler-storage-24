All tasks completed! Here's a summary:

## Completed Tasks

| Task | Title | Key Findings |
|------|-------|--------------|
| task-4 | Configuration Modules Audit | Found 2 hardcoded 250 values in algorithm.py and population.py. sidecar.py already uses registry correctly. |
| task-8 | Symbol Registry Integration Points Audit | Found 5 files with hardcoded values that should use registry. Proposed adding helper functions. |
| task-7 | Rust Crates Audit | Found hardcoded 250 in Rust config and Python API layer. Primary fix: Python API should query registry when threshold not provided. |

## Key Findings Summary

1. **Config files with hardcoded thresholds:**
   - `config/algorithm.py` - `default_threshold_decimal_bps = 250`
   - `config/population.py` - `crypto_min_threshold = 250`

2. **Files with hardcoded priority symbols:**
   - `kintsugi.py` - `_PRIORITY_SYMBOLS = ("BTCUSDT",)`
   - `backfill.py` - `_PRIORITY_SYMBOLS = ("BTCUSDT",)`

3. **Python API layer:**
   - `processors/api.py` - defaults to 250 instead of querying registry

4. **Rust crates:**
   - `opendeviationbar-config/src/algorithm.rs` - hardcoded 250
   - CLI tools have hardcoded defaults (acceptable for explicit invocation)

## Recommended Fixes

1. Add `get_default_threshold()` and `get_priority_symbol()` helper functions to symbol_registry.py
2. Wire config defaults to query registry
3. Change Python API to accept `threshold=None` meaning "use registry default"
4. Wire constants.py to registry