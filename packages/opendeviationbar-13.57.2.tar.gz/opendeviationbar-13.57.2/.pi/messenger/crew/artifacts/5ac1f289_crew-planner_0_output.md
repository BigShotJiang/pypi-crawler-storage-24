Now I have a comprehensive understanding of the project. Let me create the task breakdown.

## 1. PRD Understanding Summary

The PRD requires auditing the codebase for **hardcoded symbol parameters** (thresholds, symbols, dates) that should instead query the **Symbol Registry** (SSoT at `symbols.toml`). The project has a well-structured registry with `min_threshold`, `thresholds`, `listing_date`, `effective_start`, `asset_class`, `exchange`, `market`, and `enabled` fields, but many parts of the codebase have hardcoded values creating data drift and inconsistency.

**Key Touchpoints Identified:**
- Python `constants.py`: DEFAULT_THRESHOLD=250, THRESHOLD_PRESETS, TIER1_SYMBOLS
- CLI tools: `tools/chart/src/main.rs` default_value_t = 250
- ClickHouse cache: Hardcoded "BTCUSDT" in examples
- Config modules: Multiple 250, 500, 750, 1000 defaults in algorithm.py, sidecar.py, population.py
- Scripts: Many with hardcoded thresholds and symbols
- Rust crates: Documentation examples with hardcoded values

## 2. Relevant Code/Docs/Resources Reviewed

- **Symbol Registry**: `python/opendeviationbar/data/symbols.toml` - SSoT with threshold/date fields
- **Registry module**: `symbol_registry.py` - provides `get_thresholds_for_symbol()`, `get_symbol_entries()`, etc.
- **Constants**: `constants.py` - DEFAULT_THRESHOLD=250, THRESHOLD_PRESETS
- **Config**: `config/algorithm.py`, `sidecar.py`, `population.py`, `cli_models.py`
- **ClickHouse**: `clickhouse/cache.py`, `bulk_operations.py`, `maintenance.py`
- **Scripts**: 150+ Python scripts in `scripts/`
- **Rust**: `crates/opendeviationbar-core/src/processor.rs` with hardcoded docs

## 3. Sequential Implementation Steps

1. **Tasks 1-8 (Parallel)**: Each worker investigates their assigned code area
   - Create scaffolding directory `/tmp/crew-<perspective>/`
   - Systematically audit for hardcoded thresholds/symbols/dates
   - Use bash + grep/ripgrep for search patterns
   - Broadcast findings to peers
   - Spawn sub-tasks for specific hardcoded values

2. **Task 9**: Synthesis after all audits complete
   - Aggregate findings from tasks 1-8
   - Categorize by type
   - Propose resolution strategy

## 4. Parallelized Task Graph

---

### Task 1: Python Constants Module Audit

Investigate and verify that `python/opendeviationbar/constants.py` uses the symbol registry for threshold values instead of hardcoding. Create scaffolding directory at `/tmp/crew-constants/`. Check: DEFAULT_THRESHOLD (currently 250) should query registry default; THRESHOLD_PRESETS (250, 500, 1000) should align with registry valid thresholds; TIER1_SYMBOLS tuple should be derived from registry enabled symbols with tier=1; OPENDEVIATIONBAR_CRYPTO_MIN_THRESHOLD env var comment says "1000 dbps" but actual should query registry `min_threshold` per-symbol. Use Dynamic Task Creation: after finding hardcoded values, spawn sub-tasks to document each mismatch and propose wiring strategy. Broadcast key findings to all peers.

Dependencies: none

### Task 2: CLI/Tool Entry Points Audit

Investigate and verify that CLI tools use the symbol registry for thresholds. Create scaffolding directory at `/tmp/crew-cli/`. Check `tools/chart/src/main.rs` line 59: `default_value_t = 250` should query registry default for symbol; verify `.mise.toml` commands have hardcoded threshold values (found: OPENDEVIATIONBAR_CRYPTO_MIN_THRESHOLD="250", per-symbol overrides); audit any Python CLI entry points in `python/opendeviationbar/cli.py` for hardcoded defaults. Use Dynamic Task Creation: create sub-tasks to document each tool's threshold source and propose wiring approach. Broadcast key findings to all peers.

Dependencies: none

### Task 3: ClickHouse Cache Layer Audit

Investigate and verify that ClickHouse cache queries use the symbol registry. Create scaffolding directory at `/tmp/crew-clickhouse/`. Check `python/opendeviationbar/clickhouse/cache.py` for hardcoded "BTCUSDT" and threshold values (found: line 650, 706 examples); review `bulk_operations.py` for hardcoded symbol/threshold in queries; audit `maintenance.py` for hardcoded values in deduplication; verify schema uses registry for threshold validation. Use Dynamic Task Creation: create sub-tasks to document each hardcoded query and propose parameterized alternatives. Broadcast key findings to all peers.

Dependencies: none

### Task 4: Configuration Modules Audit

Investigate and verify that config modules derive defaults from the symbol registry. Create scaffolding directory at `/tmp/crew-config/`. Check `config/algorithm.py`: default_threshold_decimal_bps: int = 250 (should query registry); `config/sidecar.py`: returns [250] as fallback (should query registry thresholds); `config/population.py`: crypto_min_threshold: int = 250 (should query registry min_threshold); `config/cli_models.py`: threshold: int = Field(250) (should query registry). Use Dynamic Task Creation: create sub-tasks to compare each config default vs registry and propose wiring strategy. Broadcast key findings to all peers.

Dependencies: none

### Task 5: Scripts Directory Audit

Investigate and verify that scripts use the symbol registry for thresholds and symbols. Create scaffolding directory at `/tmp/crew-scripts/`. Search all .py scripts in `scripts/` for hardcoded threshold values (250, 500, 750, 1000); check for hardcoded "BTCUSDT" or other symbol names; audit `backfill_watcher.py` (found: DEFAULT_THRESHOLD_DBPS = 250); review validation scripts (`validate_*.py`) for hardcoded test values. Use Dynamic Task Creation: create sub-tasks for each script category to document hardcoded values. Broadcast key findings to all peers.

Dependencies: none

### Task 6: Backfill & Population Pipeline Audit

Investigate and verify that data pipeline code uses the symbol registry. Create scaffolding directory at `/tmp/crew-pipeline/`. Check `python/opendeviationbar/backfill.py` for hardcoded thresholds; audit `python/opendeviationbar/population.py` for hardcoded values; review `checkpoint.py` for threshold handling vs registry; check `sidecar.py` for threshold validation. Use Dynamic Task Creation: create sub-tasks to document pipeline touchpoints needing registry integration. Broadcast key findings to all peers.

Dependencies: none

### Task 7: Rust Crates Audit

Investigate and verify that Rust crates handle thresholds appropriately. Create scaffolding directory at `/tmp/crew-rust/`. Check `crates/opendeviationbar-core/src/processor.rs` for hardcoded threshold values in tests and documentation (found: 250, 500, 1000 in docs); verify processor accepts threshold as parameter (good - passed from Python); check PyO3 bindings for threshold parameter passing; audit any Rust CLI tools for hardcoded defaults. Use Dynamic Task Creation: create sub-tasks to document Rust-side hardcoding and propose solutions (pass from Python, use env var, etc.). Broadcast key findings to all peers.

Dependencies: none

### Task 8: Symbol Registry Integration Points Audit

Investigate and verify what the symbol registry currently exposes and what's missing. Create scaffolding directory at `/tmp/crew-registry/`. Review `symbol_registry.py` for what fields are currently exposed (get_thresholds_for_symbol, get_symbol_entries, etc.); check which parts of codebase already use the registry correctly; identify missing registry fields that would help eliminate hardcoding (e.g., get_default_threshold, get_tier1_symbols); audit `compat/availability.py` for registry integration. Use Dynamic Task Creation: create sub-tasks to propose registry enhancements needed to support all touchpoints. Broadcast key findings to all peers.

Dependencies: none

### Task 9: Cross-Cutting Synthesis & Resolution Strategy

Synthesize all findings and propose resolution strategy. Create scaffolding directory at `/tmp/crew-synthesis/`. Aggregate all hardcoded values found across tasks 1-8; categorize by type: threshold defaults, symbol lists, listing dates, etc.; identify dependencies: what can be wired immediately, what needs registry enhancement; propose implementation phases: quick wins vs architectural changes; document migration strategy for each category. This task depends on all individual audit tasks (1-8) being complete. Use Dynamic Task Creation: create sub-tasks for: (1) create comprehensive findings matrix, (2) draft implementation plan, (3) identify quick-win fixes. Broadcast final comprehensive findings to all peers.

Dependencies: Task 1, Task 2, Task 3, Task 4, Task 5, Task 6, Task 7, Task 8

---

```tasks-json
[
  {
    "title": "Task 1: Python Constants Module Audit",
    "description": "Investigate and verify that `python/opendeviationbar/constants.py` uses the symbol registry for threshold values instead of hardcoding. Create scaffolding directory at `/tmp/crew-constants/`. Check: DEFAULT_THRESHOLD (currently 250) should query registry default; THRESHOLD_PRESETS (250, 500, 1000) should align with registry valid thresholds; TIER1_SYMBOLS tuple should be derived from registry enabled symbols with tier=1; OPENDEVIATIONBAR_CRYPTO_MIN_THRESHOLD env var comment says '1000 dbps' but actual should query registry min_threshold per-symbol. Use Dynamic Task Creation: after finding hardcoded values, spawn sub-tasks to document each mismatch and propose wiring strategy. Broadcast key findings to all peers.",
    "dependsOn": []
  },
  {
    "title": "Task 2: CLI/Tool Entry Points Audit",
    "description": "Investigate and verify that CLI tools use the symbol registry for thresholds. Create scaffolding directory at `/tmp/crew-cli/`. Check `tools/chart/src/main.rs` line 59: `default_value_t = 250` should query registry default for symbol; verify `.mise.toml` commands have hardcoded threshold values (found: OPENDEVIATIONBAR_CRYPTO_MIN_THRESHOLD='250', per-symbol overrides); audit any Python CLI entry points in `python/opendeviationbar/cli.py` for hardcoded defaults. Use Dynamic Task Creation: create sub-tasks to document each tool's threshold source and propose wiring approach. Broadcast key findings to all peers.",
    "dependsOn": []
  },
  {
    "title": "Task 3: ClickHouse Cache Layer Audit",
    "description": "Investigate and verify that ClickHouse cache queries use the symbol registry. Create scaffolding directory at `/tmp/crew-clickhouse/`. Check `python/opendeviationbar/clickhouse/cache.py` for hardcoded 'BTCUSDT' and threshold values (found: line 650, 706 examples); review `bulk_operations.py` for hardcoded symbol/threshold in queries; audit `maintenance.py` for hardcoded values in deduplication; verify schema uses registry for threshold validation. Use Dynamic Task Creation: create sub-tasks to document each hardcoded query and propose parameterized alternatives. Broadcast key findings to all peers.",
    "dependsOn": []
  },
  {
    "title": "Task 4: Configuration Modules Audit",
    "description": "Investigate and verify that config modules derive defaults from the symbol registry. Create scaffolding directory at `/tmp/crew-config/`. Check `config/algorithm.py`: default_threshold_decimal_bps: int = 250 (should query registry); `config/sidecar.py`: returns [250] as fallback (should query registry thresholds); `config/population.py`: crypto_min_threshold: int = 250 (should query registry min_threshold); `config/cli_models.py`: threshold: int = Field(250) (should query registry). Use Dynamic Task Creation: create sub-tasks to compare each config default vs registry and propose wiring strategy. Broadcast key findings to all peers.",
    "dependsOn": []
  },
  {
    "title": "Task 5: Scripts Directory Audit",
    "description": "Investigate and verify that scripts use the symbol registry for thresholds and symbols. Create scaffolding directory at `/tmp/crew-scripts/`. Search all .py scripts in `scripts/` for hardcoded threshold values (250, 500, 750, 1000); check for hardcoded 'BTCUSDT' or other symbol names; audit `backfill_watcher.py` (found: DEFAULT_THRESHOLD_DBPS = 250); review validation scripts (`validate_*.py`) for hardcoded test values. Use Dynamic Task Creation: create sub-tasks for each script category to document hardcoded values. Broadcast key findings to all peers.",
    "dependsOn": []
  },
  {
    "title": "Task 6: Backfill & Population Pipeline Audit",
    "description": "Investigate and verify that data pipeline code uses the symbol registry. Create scaffolding directory at `/tmp/crew-pipeline/`. Check `python/opendeviationbar/backfill.py` for hardcoded thresholds; audit `python/opendeviationbar/population.py` for hardcoded values; review `checkpoint.py` for threshold handling vs registry; check `sidecar.py` for threshold validation. Use Dynamic Task Creation: create sub-tasks to document pipeline touchpoints needing registry integration. Broadcast key findings to all peers.",
    "dependsOn": []
  },
  {
    "title": "Task 7: Rust Crates Audit",
    "description": "Investigate and verify that Rust crates handle thresholds appropriately. Create scaffolding directory at `/tmp/crew-rust/`. Check `crates/opendeviationbar-core/src/processor.rs` for hardcoded threshold values in tests and documentation (found: 250, 500, 1000 in docs); verify processor accepts threshold as parameter (good - passed from Python); check PyO3 bindings for threshold parameter passing; audit any Rust CLI tools for hardcoded defaults. Use Dynamic Task Creation: create sub-tasks to document Rust-side hardcoding and propose solutions (pass from Python, use env var, etc.). Broadcast key findings to all peers.",
    "dependsOn": []
  },
  {
    "title": "Task 8: Symbol Registry Integration Points Audit",
    "description": "Investigate and verify what the symbol registry currently exposes and what's missing. Create scaffolding directory at `/tmp/crew-registry/`. Review `symbol_registry.py` for what fields are currently exposed (get_thresholds_for_symbol, get_symbol_entries, etc.); check which parts of codebase already use the registry correctly; identify missing registry fields that would help eliminate hardcoding (e.g., get_default_threshold, get_tier1_symbols); audit `compat/availability.py` for registry integration. Use Dynamic Task Creation: create sub-tasks to propose registry enhancements needed to support all touchpoints. Broadcast key findings to all peers.",
    "dependsOn": []
  },
  {
    "title": "Task 9: Cross-Cutting Synthesis & Resolution Strategy",
    "description": "Synthesize all findings and propose resolution strategy. Create scaffolding directory at `/tmp/crew-synthesis/`. Aggregate all hardcoded values found across tasks 1-8; categorize by type: threshold defaults, symbol lists, listing dates, etc.; identify dependencies: what can be wired immediately, what needs registry enhancement; propose implementation phases: quick wins vs architectural changes; document migration strategy for each category. This task depends on all individual audit tasks (1-8) being complete. Use Dynamic Task Creation: create sub-tasks for: (1) create comprehensive findings matrix, (2) draft implementation plan, (3) identify quick-win fixes. Broadcast final comprehensive findings to all peers.",
    "dependsOn": ["Task 1: Python Constants Module Audit", "Task 2: CLI/Tool Entry Points Audit", "Task 3: ClickHouse Cache Layer Audit", "Task 4: Configuration Modules Audit", "Task 5: Scripts Directory Audit", "Task 6: Backfill & Population Pipeline Audit", "Task 7: Rust Crates Audit", "Task 8: Symbol Registry Integration Points Audit"]
  }
]
```