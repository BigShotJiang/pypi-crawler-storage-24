Now I'll start the task and create the scaffolding directory:
