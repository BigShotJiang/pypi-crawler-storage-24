I'll start by joining the mesh and understanding the task requirements.
