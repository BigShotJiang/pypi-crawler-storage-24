I've completed both **task-13** (Configuration Modules Audit) and the related sub-task **task-22** (wiring strategy).

## Summary

**Task 13 Findings:**
- Audited config modules for hardcoded threshold defaults
- Found 3 files with hardcoded `threshold=250`:
  - `config/algorithm.py`: `default_threshold_decimal_bps = 250`
  - `config/population.py`: `crypto_min_threshold = 250`
  - `config/cli_models.py`: `threshold = 250`
- `config/sidecar.py` already uses registry properly ✓

**Task 22 - Wiring Strategy:**
- Proposed adding `[meta.default_thresholds]` section to symbols.toml
- Designed helper functions: `get_default_threshold_for_asset_class()` and `get_effective_default_threshold()`
- Specified how each config file should be updated to use registry defaults

All findings documented in `/tmp/crew-perspective-4/`:
- `config_modules_audit.md` - detailed audit findings
- `wiring_strategy.md` - implementation roadmap