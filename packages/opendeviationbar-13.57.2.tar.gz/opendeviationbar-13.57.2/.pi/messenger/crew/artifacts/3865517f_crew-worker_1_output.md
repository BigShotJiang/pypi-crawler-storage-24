## Summary

I've completed 3 tasks in this crew wave:

### Task 4: ClickHouse CLAUDE.md Alignment
- Verified schema.sql, populate_cache_resumable(), ClickHouse connection code, dedup hardening all match documentation
- Fixed 3 documentation errors:
  - `deduplicate_bars()` location (maintenance.py, not cache.py)
  - `_wait_for_merges()` location (maintenance.py, not cache.py)
  - `_FINAL_READ_SETTINGS` location (constants.py, not cache.py)
- Added maintenance.py to Files table

### Task 6: Plugin System CLAUDE.md Alignment  
- Verified FeatureProvider Protocol, entry-point discovery, migration helpers, hook events all correct
- No discrepancies found

### Task 8: Cross-Reference Consistency Audit
- Fixed missing config/CLAUDE.md in hub-and-spoke network section
- Verified all Parent references in nested CLAUDE.md files are correct
- Verified all links in Related sections reference existing files
- All 7 CLAUDE.md cross-references validated