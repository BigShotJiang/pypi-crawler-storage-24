
Now let me check which files need to be reserved:
