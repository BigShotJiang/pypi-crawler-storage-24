Let me try to check task-7 status more closely and see if I can work on what's requested:
