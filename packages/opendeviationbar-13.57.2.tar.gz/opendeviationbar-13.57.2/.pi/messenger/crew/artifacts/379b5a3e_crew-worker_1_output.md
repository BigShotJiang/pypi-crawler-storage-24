Now let me also check the symbol registry to understand its interface:
