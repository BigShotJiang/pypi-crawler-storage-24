I'll start by joining the mesh and checking the crew status, then read the task spec to understand the requirements.
