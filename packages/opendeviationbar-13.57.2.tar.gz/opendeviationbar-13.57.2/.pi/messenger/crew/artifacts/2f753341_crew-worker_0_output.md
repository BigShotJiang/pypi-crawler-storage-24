Now let me read the task specification and check what I need to do:
