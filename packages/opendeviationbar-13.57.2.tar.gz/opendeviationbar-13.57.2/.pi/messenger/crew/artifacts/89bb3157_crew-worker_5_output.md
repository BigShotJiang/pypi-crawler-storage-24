Now let me search for hardcoded values that should potentially come from the registry:
