## Summary

I completed **Task 8: Symbol Registry Integration Points Audit** (task-17). Here's what was accomplished:

### Key Findings:

1. **Current Registry Fields**: SymbolEntry has 16 fields including `symbol`, `enabled`, `asset_class`, `exchange`, `market`, `listing_date`, `effective_start`, `tier`, `min_threshold`, `thresholds`, `known_gaps`, etc.

2. **compat/availability.py Integration**: Properly uses `get_symbol_entries()` and `get_thresholds_for_symbol()` from the registry.

3. **Hardcoded Values Found**: 76+ files have hardcoded `threshold=250` values that should use the registry.

### Subtasks Created:

1. **task-19**: Proposed adding `[meta.default_thresholds]` section to symbols.toml and helper functions to symbol_registry.py

2. **task-20**: Documented 76+ files with hardcoded thresholds, categorized by priority

3. **task-21**: Audited config files (algorithm.py, threshold.py, population.py, cli_models.py) with specific registry integration proposals

### Documents Created (in `/tmp/crew-perspective-8/`):
- `registry_integration_audit.md` - Main findings
- `proposal_asset_class_defaults.md` - Proposal for adding asset-class defaults
- `hardcoded_threshold_locations.md` - Comprehensive file list
- `config_audit.md` - Config file audit with proposals