I've completed both task-5 and task-9. Here's a summary:

## Task 5: Configuration CLAUDE.md Alignment
- ✅ Verified all 9 config files exist as documented
- ✅ Verified environment variable prefixes match (OPENDEVIATIONBAR_, OPENDEVIATIONBAR_CH_, OPENDEVIATIONBAR_STREAMING_, OPENDEVIATIONBAR_ALGORITHM_)
- ✅ Verified Settings singleton pattern works (get(), reload(), reload_and_clear())
- ✅ Fixed watchdog_timeout_s default value (300 → 600)
- No sub-tasks needed

## Task 9: Public API vs Documentation Parity  
- ✅ Found and fixed 1 discrepancy: ClickHouse cache API documentation used wrong function imports (`get_cached_bars`/`count_bars` should be `OpenDeviationBarCache` class methods)
- ✅ Verified all documented Python APIs are importable and functional
- ✅ Verified 9 Rust crates in workspace match documentation
- ✅ Verified CLI commands and code examples work

Both tasks are now complete with the fixes committed.