Let me also check the symbol registry to understand what functions are available:
