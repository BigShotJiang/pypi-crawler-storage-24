Now let me also check the symbol registry and constants to compare:
