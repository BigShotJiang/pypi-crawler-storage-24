Done! I completed task-3 (Python Core API CLAUDE.md Alignment). Here's what I verified and fixed:

**Verified (all match):**
- `TIER1_SYMBOLS` - 18 high-liquidity symbols ✓
- `THRESHOLD_PRESETS` - 6 presets (micro, tight, standard, medium, wide, macro) ✓
- `validation/tier1.py` with `validate_tier1()` ✓
- `validation/tier2.py` with `validate_tier2()` ✓
- `TickStorage` class in `storage/parquet.py` ✓

**Added to CLAUDE.md (previously missing):**
- `process_trades_polars_lazy()` - Lazy Polars for predicate pushdown
- `get_open_deviation_bars_pandas()` - Pandas variant for backtesting.py

Committed: `2f838db`