
I'll start by joining the mesh and checking the crew status.
