Let me search for hardcoded threshold values in the Rust crates:
