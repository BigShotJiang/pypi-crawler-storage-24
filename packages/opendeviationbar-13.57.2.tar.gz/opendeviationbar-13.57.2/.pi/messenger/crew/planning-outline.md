# Planning Outline

## 1. PRD Understanding Summary
The PRD requires auditing the codebase to identify all hardcoded values that should come from the Symbol Registry (symbols.toml). Key findings:

- **Symbol Registry**: Exists at `python/opendeviationbar/data/symbols.toml` with threshold fields, listing dates, asset class, exchange, enabled status
- **Hardcoded Values Found**:
  - Python: `constants.py` has `THRESHOLD_PRESETS` (250, 500, 750, 1000), multiple config files with `default_threshold_decimal_bps = 250`
  - Rust: `tools/chart/src/main.rs` has `default_value_t = 250`, test files with hardcoded thresholds
  - ClickHouse: `cache.py` has hardcoded "BTCUSDT" and threshold values in queries
  - Scripts: Many scripts with hardcoded threshold values

## 2. Relevant Code/Docs/Resources Reviewed
- **PRD.md**: Full specification with 9 investigative perspectives
- **Symbol Registry**: `python/opendeviationbar/symbol_registry.py` - exposes `get_thresholds_for_symbol()`, `get_symbol_entries()`, etc.
- **Constants**: `python/opendeviationbar/constants.py` - `THRESHOLD_PRESETS`, `TIER1_SYMBOLS`
- **CLI**: `tools/chart/src/main.rs` - default threshold 250
- **Config**: Multiple files in `python/opendeviationbar/config/` with hardcoded defaults
- **ClickHouse**: `python/opendeviationbar/clickhouse/cache.py` - hardcoded BTCUSDT and thresholds
- **Crates**: `crates/opendeviationbar-core/tests/` - hardcoded thresholds in tests

## 3. Sequential Implementation Steps
1. **Tasks 1-8 (Parallel)**: Each worker investigates their assigned code area
   - Create scaffolding directory `/tmp/crew-perspective-<N>/`
   - Systematically search for hardcoded thresholds, symbol names, dates
   - Use grep/ripgrep for empirical validation
   - Broadcast findings to peers

2. **Task 9**: Cross-Cutting Synthesis (after Tasks 1-8 complete)
   - Aggregate all hardcoded values found
   - Categorize by type: thresholds, symbols, dates
   - Propose resolution phases: quick wins vs architectural changes

## 4. Parallelized Task Graph
---

### Task 1: Python Constants Module Audit

Investigate `python/opendeviationbar/constants.py` for hardcoded threshold values. Create scaffolding directory at `/tmp/crew-perspective-1/`. Check `THRESHOLD_PRESETS` against `symbols.toml` defaults; verify `OPENDEVIATIONBAR_CRYPTO_MIN_THRESHOLD` matches registry; identify hardcoded symbol names (BTCUSDT); compare `TIER1_SYMBOLS` to enabled symbols in registry. Use Dynamic Task Creation: after finding specific hardcoded values that should come from registry, create sub-tasks to identify fix approach and document current vs expected behavior. Broadcast key findings to all peers via pi_messenger.

Dependencies: none

### Task 2: CLI/Tool Entry Points Audit

Investigate Rust tools and Python CLI entry points for hardcoded thresholds. Create scaffolding directory at `/tmp/crew-perspective-2/`. Check `tools/chart/src/main.rs` default threshold (line 59: `default_value_t = 250`); audit any other CLI tools in `tools/` for hardcoded thresholds; verify Python CLI entry points in `python/opendeviationbar/cli.py` use registry; check `.mise.toml` commands for hardcoded threshold values. Use Dynamic Task Creation: after finding hardcoded defaults, create sub-tasks to document each tool's threshold source and propose how to wire to registry. Broadcast key findings to all peers.

Dependencies: none

### Task 3: ClickHouse Cache Layer Audit

Investigate ClickHouse cache queries for hardcoded thresholds and symbols. Create scaffolding directory at `/tmp/crew-perspective-3/`. Check `python/opendeviationbar/clickhouse/cache.py` for hardcoded BTCUSDT and threshold values in queries; review `bulk_operations.py` for hardcoded symbol/threshold combinations; audit `maintenance.py` for hardcoded values in deduplication queries; verify schema uses registry for threshold validation. Use Dynamic Task Creation: create sub-tasks to document each hardcoded query and propose parameterized alternatives. Broadcast key findings to all peers.

Dependencies: none

### Task 4: Configuration Modules Audit

Investigate config modules for hardcoded defaults that should come from registry. Create scaffolding directory at `/tmp/crew-perspective-4/`. Check `config/algorithm.py` for `OPENDEVIATIONBAR_ALGORITHM_DEFAULT_THRESHOLD_DECIMAL_BPS`; audit `config/sidecar.py` for threshold handling vs registry; review `config/population.py` for `OPENDEVIATIONBAR_CRYPTO_MIN_THRESHOLD` usage; check `config/backfill.py` for hardcoded failure thresholds. Use Dynamic Task Creation: create sub-tasks to compare config defaults vs registry and propose wiring strategy. Broadcast key findings to all peers.

Dependencies: none

### Task 5: Scripts Directory Audit

Investigate `scripts/` for hardcoded symbols and thresholds. Create scaffolding directory at `/tmp/crew-perspective-5/`. Search all `.py` scripts for hardcoded threshold values (250, 500, 750, 1000); check for hardcoded BTCUSDT or other symbol names; audit `populate_full_cache.py`, `backfill_watcher.py`, `kintsugi.py`; review validation scripts (`validate_*.py`) for hardcoded test values. Use Dynamic Task Creation: create sub-tasks for each script category to document hardcoded values. Broadcast key findings to all peers.

Dependencies: none

### Task 6: Backfill and Population Pipeline Audit

Investigate data pipeline code for hardcoded thresholds and symbol lists. Create scaffolding directory at `/tmp/crew-perspective-6/`. Check `python/opendeviationbar/backfill.py` for hardcoded thresholds; audit population logic in `python/opendeviationbar/population.py`; review checkpoint logic (`checkpoint.py`) for threshold handling; check sidecar streaming (`sidecar.py`) for threshold validation vs registry. Use Dynamic Task Creation: create sub-tasks to document pipeline touchpoints that need registry integration. Broadcast key findings to all peers.

Dependencies: none

### Task 7: Rust Crates Audit

Investigate Rust crates for hardcoded threshold values. Create scaffolding directory at `/tmp/crew-perspective-7/`. Check `crates/opendeviationbar-core/` for hardcoded threshold values in tests; review `processor.rs` for default threshold handling; audit any Rust CLI tools for hardcoded defaults; check PyO3 bindings for threshold parameter passing. Use Dynamic Task Creation: create sub-tasks to document Rust-side hardcoding and propose solutions. Broadcast key findings to all peers.

Dependencies: none

### Task 8: Symbol Registry Integration Points Audit

Investigate existing symbol registry usage patterns. Create scaffolding directory at `/tmp/crew-perspective-8/`. Review `symbol_registry.py` for what fields are currently exposed; check which parts of codebase already use the registry correctly; identify missing registry fields that would help eliminate hardcoding; audit `compat/availability.py` for registry integration. Use Dynamic Task Creation: create sub-tasks to propose registry enhancements needed to support all touchpoints. Broadcast key findings to all peers.

Dependencies: none

### Task 9: Cross-Cutting Synthesis and Resolution Strategy

Synthesize all findings and propose resolution strategy. Create scaffolding directory at `/tmp/crew-perspective-9/`. Aggregate all hardcoded values found across tasks 1-8; categorize by type: threshold defaults, symbol lists, listing dates, etc.; identify dependencies: what can be wired immediately, what needs registry enhancement; propose implementation phases: quick wins vs architectural changes; document migration strategy for each category. This task depends on all individual audit tasks (1-8) being complete. Use Dynamic Task Creation: create sub-tasks for create comprehensive findings matrix, draft implementation plan, identify quick-win fixes. Broadcast final comprehensive findings to all peers.

Dependencies: Task 1, Task 2, Task 3, Task 4, Task 5, Task 6, Task 7, Task 8

---

```tasks-json
[
  {
    "title": "Task 1: Python Constants Module Audit",
    "description": "Investigate python/opendeviationbar/constants.py for hardcoded threshold values. Create scaffolding directory at /tmp/crew-perspective-1/. Check THRESHOLD_PRESETS against symbols.toml defaults; verify OPENDEVIATIONBAR_CRYPTO_MIN_THRESHOLD matches registry; identify hardcoded symbol names (BTCUSDT); compare TIER1_SYMBOLS to enabled symbols in registry. Use Dynamic Task Creation: after finding specific hardcoded values that should come from registry, create sub-tasks to identify fix approach and document current vs expected behavior. Broadcast key findings to all peers via pi_messenger.",
    "dependsOn": []
  },
  {
    "title": "Task 2: CLI/Tool Entry Points Audit",
    "description": "Investigate Rust tools and Python CLI entry points for hardcoded thresholds. Create scaffolding directory at /tmp/crew-perspective-2/. Check tools/chart/src/main.rs default threshold (line 59: default_value_t = 250); audit any other CLI tools in tools/ for hardcoded thresholds; verify Python CLI entry points in python/opendeviationbar/cli.py use registry; check .mise.toml commands for hardcoded threshold values. Use Dynamic Task Creation: after finding hardcoded defaults, create sub-tasks to document each tool's threshold source and propose how to wire to registry. Broadcast key findings to all peers.",
    "dependsOn": []
  },
  {
    "title": "Task 3: ClickHouse Cache Layer Audit",
    "description": "Investigate ClickHouse cache queries for hardcoded thresholds and symbols. Create scaffolding directory at /tmp/crew-perspective-3/. Check python/opendeviationbar/clickhouse/cache.py for hardcoded BTCUSDT and threshold values in queries; review bulk_operations.py for hardcoded symbol/threshold combinations; audit maintenance.py for hardcoded values in deduplication queries; verify schema uses registry for threshold validation. Use Dynamic Task Creation: create sub-tasks to document each hardcoded query and propose parameterized alternatives. Broadcast key findings to all peers.",
    "dependsOn": []
  },
  {
    "title": "Task 4: Configuration Modules Audit",
    "description": "Investigate config modules for hardcoded defaults that should come from registry. Create scaffolding directory at /tmp/crew-perspective-4/. Check config/algorithm.py for OPENDEVIATIONBAR_ALGORITHM_DEFAULT_THRESHOLD_DECIMAL_BPS; audit config/sidecar.py for threshold handling vs registry; review config/population.py for OPENDEVIATIONBAR_CRYPTO_MIN_THRESHOLD usage; check config/backfill.py for hardcoded failure thresholds. Use Dynamic Task Creation: create sub-tasks to compare config defaults vs registry and propose wiring strategy. Broadcast key findings to all peers.",
    "dependsOn": []
  },
  {
    "title": "Task 5: Scripts Directory Audit",
    "description": "Investigate scripts/ for hardcoded symbols and thresholds. Create scaffolding directory at /tmp/crew-perspective-5/. Search all .py scripts for hardcoded threshold values (250, 500, 750, 1000); check for hardcoded BTCUSDT or other symbol names; audit populate_full_cache.py, backfill_watcher.py, kintsugi.py; review validation scripts (validate_*.py) for hardcoded test values. Use Dynamic Task Creation: create sub-tasks for each script category to document hardcoded values. Broadcast key findings to all peers.",
    "dependsOn": []
  },
  {
    "title": "Task 6: Backfill and Population Pipeline Audit",
    "description": "Investigate data pipeline code for hardcoded thresholds and symbol lists. Create scaffolding directory at /tmp/crew-perspective-6/. Check python/opendeviationbar/backfill.py for hardcoded thresholds; audit population logic in python/opendeviationbar/population.py; review checkpoint logic (checkpoint.py) for threshold handling; check sidecar streaming (sidecar.py) for threshold validation vs registry. Use Dynamic Task Creation: create sub-tasks to document pipeline touchpoints that need registry integration. Broadcast key findings to all peers.",
    "dependsOn": []
  },
  {
    "title": "Task 7: Rust Crates Audit",
    "description": "Investigate Rust crates for hardcoded threshold values. Create scaffolding directory at /tmp/crew-perspective-7/. Check crates/opendeviationbar-core/ for hardcoded threshold values in tests; review processor.rs for default threshold handling; audit any Rust CLI tools for hardcoded defaults; check PyO3 bindings for threshold parameter passing. Use Dynamic Task Creation: create sub-tasks to document Rust-side hardcoding and propose solutions. Broadcast key findings to all peers.",
    "dependsOn": []
  },
  {
    "title": "Task 8: Symbol Registry Integration Points Audit",
    "description": "Investigate existing symbol registry usage patterns. Create scaffolding directory at /tmp/crew-perspective-8/. Review symbol_registry.py for what fields are currently exposed; check which parts of codebase already use the registry correctly; identify missing registry fields that would help eliminate hardcoding; audit compat/availability.py for registry integration. Use Dynamic Task Creation: create sub-tasks to propose registry enhancements needed to support all touchpoints. Broadcast key findings to all peers.",
    "dependsOn": []
  },
  {
    "title": "Task 9: Cross-Cutting Synthesis and Resolution Strategy",
    "description": "Synthesize all findings and propose resolution strategy. Create scaffolding directory at /tmp/crew-perspective-9/. Aggregate all hardcoded values found across tasks 1-8; categorize by type: threshold defaults, symbol lists, listing dates, etc.; identify dependencies: what can be wired immediately, what needs registry enhancement; propose implementation phases: quick wins vs architectural changes; document migration strategy for each category. This task depends on all individual audit tasks (1-8) being complete. Use Dynamic Task Creation: create sub-tasks for create comprehensive findings matrix, draft implementation plan, identify quick-win fixes. Broadcast final comprehensive findings to all peers.",
    "dependsOn": ["Task 1", "Task 2", "Task 3", "Task 4", "Task 5", "Task 6", "Task 7", "Task 8"]
  }
]
```
