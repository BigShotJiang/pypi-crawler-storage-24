"""Tests for the CLI module."""

import unittest
from unittest.mock import MagicMock, patch

from click.testing import CliRunner

from pyflexweb.cli import cli, main


class TestClickCli(unittest.TestCase):
    """Test the Click-based CLI commands."""

    def setUp(self):
        self.runner = CliRunner()
        self.mock_db_patcher = patch("pyflexweb.cli.FlexDatabase")
        self.mock_db_class = self.mock_db_patcher.start()
        self.mock_db = MagicMock()
        self.mock_db_class.return_value = self.mock_db

        # Configure mock database to return default config values
        def mock_get_config(key, default=None):
            config_defaults = {"default_poll_interval": "30", "default_max_attempts": "20"}
            return config_defaults.get(key, default)

        self.mock_db.get_config.side_effect = mock_get_config

        # Set up patchers for handlers
        self.patchers = [
            patch("pyflexweb.cli.handle_token_command", return_value=0),
            patch("pyflexweb.cli.handle_query_command", return_value=0),
            patch("pyflexweb.cli.handle_download_command", return_value=0),
            patch("pyflexweb.cli.handle_config_command", return_value=0),
            patch("pyflexweb.cli.handle_account_command", return_value=0),
        ]

        # Start all patchers and store mocks
        self.mocks = [patcher.start() for patcher in self.patchers]

        # Name the mocks for convenience
        self.mock_token_handler = self.mocks[0]
        self.mock_query_handler = self.mocks[1]
        self.mock_download_handler = self.mocks[2]
        self.mock_config_handler = self.mocks[3]
        self.mock_account_handler = self.mocks[4]

    def tearDown(self):
        self.mock_db_patcher.stop()
        for patcher in self.patchers:
            patcher.stop()

    def test_version_flag(self):
        """Test the version flag."""
        result = self.runner.invoke(cli, ["--version"])
        self.assertEqual(result.exit_code, 0)

    def test_help_output(self):
        """Test the help output."""
        result = self.runner.invoke(cli, ["--help"])
        self.assertEqual(result.exit_code, 0)
        self.assertIn("Download IBKR Flex reports", result.output)

    def test_no_command(self):
        """Test behavior when no command is provided."""
        result = self.runner.invoke(cli)
        self.assertEqual(result.exit_code, 1)  # Should exit with code 1
        self.assertIn("Usage:", result.output)  # Should show help

    def test_token_set_command(self):
        """Test the token set command."""
        result = self.runner.invoke(cli, ["token", "set", "test_token"])
        self.assertEqual(result.exit_code, 0)
        self.mock_token_handler.assert_called_once()
        args = self.mock_token_handler.call_args[0][0]
        self.assertEqual(args.subcommand, "set")
        self.assertEqual(args.token, "test_token")

    def test_token_get_command(self):
        """Test the token get command."""
        result = self.runner.invoke(cli, ["token", "get"])
        self.assertEqual(result.exit_code, 0)
        self.mock_token_handler.assert_called_once()
        args = self.mock_token_handler.call_args[0][0]
        self.assertEqual(args.subcommand, "get")

    def test_token_unset_command(self):
        """Test the token unset command."""
        result = self.runner.invoke(cli, ["token", "unset"])
        self.assertEqual(result.exit_code, 0)
        self.mock_token_handler.assert_called_once()
        args = self.mock_token_handler.call_args[0][0]
        self.assertEqual(args.subcommand, "unset")

    def test_token_default_command(self):
        """Test the token command without subcommand defaults to get."""
        result = self.runner.invoke(cli, ["token"])
        self.assertEqual(result.exit_code, 0)
        self.mock_token_handler.assert_called_once()
        args = self.mock_token_handler.call_args[0][0]
        self.assertEqual(args.subcommand, "get")

    # --- Account CLI tests ---

    def test_account_add_command(self):
        """Test the account add command."""
        result = self.runner.invoke(cli, ["account", "add", "U1317359", "--name", "Cerabella", "--token", "tok_abc"])
        self.assertEqual(result.exit_code, 0)
        self.mock_account_handler.assert_called_once()
        args = self.mock_account_handler.call_args[0][0]
        self.assertEqual(args.subcommand, "add")
        self.assertEqual(args.account_id, "U1317359")
        self.assertEqual(args.name, "Cerabella")
        self.assertEqual(args.token, "tok_abc")

    def test_account_add_no_name(self):
        """Test the account add command without a name."""
        result = self.runner.invoke(cli, ["account", "add", "U999", "--token", "tok_xyz"])
        self.assertEqual(result.exit_code, 0)
        self.mock_account_handler.assert_called_once()
        args = self.mock_account_handler.call_args[0][0]
        self.assertEqual(args.subcommand, "add")
        self.assertEqual(args.account_id, "U999")
        self.assertIsNone(args.name)
        self.assertEqual(args.token, "tok_xyz")

    def test_account_add_requires_token(self):
        """Test that account add requires --token."""
        result = self.runner.invoke(cli, ["account", "add", "U999"])
        self.assertNotEqual(result.exit_code, 0)
        self.assertIn("Missing option", result.output)

    def test_account_list_command(self):
        """Test the account list command."""
        result = self.runner.invoke(cli, ["account", "list"])
        self.assertEqual(result.exit_code, 0)
        self.mock_account_handler.assert_called_once()
        args = self.mock_account_handler.call_args[0][0]
        self.assertEqual(args.subcommand, "list")

    def test_account_default_command(self):
        """Test the account command without subcommand defaults to list."""
        result = self.runner.invoke(cli, ["account"])
        self.assertEqual(result.exit_code, 0)
        self.mock_account_handler.assert_called_once()
        args = self.mock_account_handler.call_args[0][0]
        self.assertEqual(args.subcommand, "list")

    def test_account_remove_command(self):
        """Test the account remove command."""
        result = self.runner.invoke(cli, ["account", "remove", "U111"])
        self.assertEqual(result.exit_code, 0)
        self.mock_account_handler.assert_called_once()
        args = self.mock_account_handler.call_args[0][0]
        self.assertEqual(args.subcommand, "remove")
        self.assertEqual(args.account_id, "U111")

    def test_account_rename_command(self):
        """Test the account rename command."""
        result = self.runner.invoke(cli, ["account", "rename", "U111", "New Name"])
        self.assertEqual(result.exit_code, 0)
        self.mock_account_handler.assert_called_once()
        args = self.mock_account_handler.call_args[0][0]
        self.assertEqual(args.subcommand, "rename")
        self.assertEqual(args.account_id, "U111")
        self.assertEqual(args.name, "New Name")

    # --- Query CLI tests ---

    def test_query_add_command(self):
        """Test the query add command — --account is required."""
        # Without --account should fail (exit code 2 = missing option)
        result = self.runner.invoke(cli, ["query", "add", "123456", "--name", "Test Query"])
        self.assertEqual(result.exit_code, 2)
        self.mock_query_handler.assert_not_called()

    def test_query_add_command_with_account(self):
        """Test the query add command with required --account."""
        result = self.runner.invoke(cli, ["query", "add", "123456", "--name", "Test Query", "--account", "U111"])
        self.assertEqual(result.exit_code, 0)
        self.mock_query_handler.assert_called_once()
        args = self.mock_query_handler.call_args[0][0]
        self.assertEqual(args.subcommand, "add")
        self.assertEqual(args.query_id, "123456")
        self.assertEqual(args.name, "Test Query")
        self.assertEqual(args.query_type, "activity")  # default type
        self.assertEqual(args.account, "U111")

    def test_query_add_trade_confirmation(self):
        """Test the query add command with trade-confirmation type."""
        result = self.runner.invoke(
            cli,
            ["query", "add", "789", "--name", "Trade", "--type", "trade-confirmation", "--account", "U111"],
        )
        self.assertEqual(result.exit_code, 0)
        self.mock_query_handler.assert_called_once()
        args = self.mock_query_handler.call_args[0][0]
        self.assertEqual(args.subcommand, "add")
        self.assertEqual(args.query_id, "789")
        self.assertEqual(args.query_type, "trade-confirmation")

    def test_query_add_with_min_interval(self):
        """Test the query add command with custom min interval."""
        result = self.runner.invoke(cli, ["query", "add", "123", "--name", "Custom", "--min-interval", "12", "--account", "U111"])
        self.assertEqual(result.exit_code, 0)
        self.mock_query_handler.assert_called_once()
        args = self.mock_query_handler.call_args[0][0]
        self.assertEqual(args.min_interval, 12)

    def test_query_add_with_account(self):
        """Test the query add command with --account."""
        result = self.runner.invoke(cli, ["query", "add", "123", "--name", "With Account", "--account", "U111"])
        self.assertEqual(result.exit_code, 0)
        self.mock_query_handler.assert_called_once()
        args = self.mock_query_handler.call_args[0][0]
        self.assertEqual(args.account, "U111")

    def test_query_remove_command(self):
        """Test the query remove command."""
        result = self.runner.invoke(cli, ["query", "remove", "123456"])
        self.assertEqual(result.exit_code, 0)
        self.mock_query_handler.assert_called_once()
        args = self.mock_query_handler.call_args[0][0]
        self.assertEqual(args.subcommand, "remove")
        self.assertEqual(args.query_id, "123456")

    def test_query_rename_command(self):
        """Test the query rename command."""
        result = self.runner.invoke(cli, ["query", "rename", "123456", "--name", "New Name"])
        self.assertEqual(result.exit_code, 0)
        self.mock_query_handler.assert_called_once()
        args = self.mock_query_handler.call_args[0][0]
        self.assertEqual(args.subcommand, "rename")
        self.assertEqual(args.query_id, "123456")
        self.assertEqual(args.name, "New Name")

    def test_query_list_command(self):
        """Test the query list command."""
        result = self.runner.invoke(cli, ["query", "list"])
        self.assertEqual(result.exit_code, 0)
        self.mock_query_handler.assert_called_once()
        args = self.mock_query_handler.call_args[0][0]
        self.assertEqual(args.subcommand, "list")

    def test_query_list_json(self):
        """Test the query list command with --json flag."""
        result = self.runner.invoke(cli, ["query", "list", "--json"])
        self.assertEqual(result.exit_code, 0)
        self.mock_query_handler.assert_called_once()
        args = self.mock_query_handler.call_args[0][0]
        self.assertEqual(args.subcommand, "list")
        self.assertTrue(args.json_output)

    def test_query_default_command(self):
        """Test the query command with no subcommand."""
        result = self.runner.invoke(cli, ["query"])
        self.assertEqual(result.exit_code, 0)
        self.mock_query_handler.assert_called_once()
        args = self.mock_query_handler.call_args[0][0]
        self.assertEqual(args.subcommand, "list")  # Default should be 'list'

    def test_status_command(self):
        """Test the status command (alias for query list)."""
        result = self.runner.invoke(cli, ["status"])
        self.assertEqual(result.exit_code, 0)
        self.mock_query_handler.assert_called_once()
        args = self.mock_query_handler.call_args[0][0]
        self.assertEqual(args.subcommand, "list")  # Status should call query handler with 'list'

    def test_download_command(self):
        """Test the download command with all options."""
        result = self.runner.invoke(
            cli, ["download", "--query", "123456", "--output", "report.xml", "--poll-interval", "10", "--max-attempts", "30", "--force"]
        )
        self.assertEqual(result.exit_code, 0)
        self.mock_download_handler.assert_called_once()
        args = self.mock_download_handler.call_args[0][0]
        self.assertEqual(args.query, "123456")
        self.assertEqual(args.output, "report.xml")
        self.assertEqual(args.poll_interval, 10)
        self.assertEqual(args.max_attempts, 30)
        self.assertTrue(args.force)

    def test_download_command_defaults(self):
        """Test the download command with default values."""
        result = self.runner.invoke(cli, ["download"])
        self.assertEqual(result.exit_code, 0)
        self.mock_download_handler.assert_called_once()
        args = self.mock_download_handler.call_args[0][0]
        self.assertEqual(args.query, "all")  # Default value
        self.assertEqual(args.poll_interval, 30)  # Default value
        self.assertEqual(args.max_attempts, 20)  # Default value
        self.assertIsNone(args.output)  # Default is None
        self.assertFalse(args.force)  # Default is False

    def test_config_set_command(self):
        """Test the config set command."""
        result = self.runner.invoke(cli, ["config", "set", "default_poll_interval", "60"])
        self.assertEqual(result.exit_code, 0)
        self.mock_config_handler.assert_called_once()
        args = self.mock_config_handler.call_args[0][0]
        self.assertEqual(args.subcommand, "set")
        self.assertEqual(args.key, "default_poll_interval")
        self.assertEqual(args.value, "60")

    def test_config_get_command(self):
        """Test the config get command."""
        result = self.runner.invoke(cli, ["config", "get", "default_poll_interval"])
        self.assertEqual(result.exit_code, 0)
        self.mock_config_handler.assert_called_once()
        args = self.mock_config_handler.call_args[0][0]
        self.assertEqual(args.subcommand, "get")
        self.assertEqual(args.key, "default_poll_interval")

    def test_config_list_command(self):
        """Test the config list command."""
        result = self.runner.invoke(cli, ["config", "list"])
        self.assertEqual(result.exit_code, 0)
        self.mock_config_handler.assert_called_once()
        args = self.mock_config_handler.call_args[0][0]
        self.assertEqual(args.subcommand, "list")
        self.assertIsNone(args.key)

    def test_config_unset_command(self):
        """Test the config unset command."""
        result = self.runner.invoke(cli, ["config", "unset", "default_poll_interval"])
        self.assertEqual(result.exit_code, 0)
        self.mock_config_handler.assert_called_once()
        args = self.mock_config_handler.call_args[0][0]
        self.assertEqual(args.subcommand, "unset")
        self.assertEqual(args.key, "default_poll_interval")


class TestMainFunction(unittest.TestCase):
    """Test the main entry point function."""

    def setUp(self):
        self.mock_cli_patcher = patch("pyflexweb.cli.cli")
        self.mock_cli = self.mock_cli_patcher.start()
        self.addCleanup(self.mock_cli_patcher.stop)

    def test_main_success(self):
        """Test successful execution of main."""
        self.mock_cli.return_value = 0
        with patch("sys.exit") as mock_exit:
            main()
            mock_exit.assert_called_once_with(0)

    def test_main_exception(self):
        """Test handling of exceptions in main."""
        self.mock_cli.side_effect = Exception("Test error")
        with patch("click.echo") as mock_echo:
            with patch("sys.exit") as mock_exit:
                main()
                mock_echo.assert_called_once_with("Error: Test error", err=True)
                mock_exit.assert_not_called()  # We don't call sys.exit directly on exception


if __name__ == "__main__":
    unittest.main()
