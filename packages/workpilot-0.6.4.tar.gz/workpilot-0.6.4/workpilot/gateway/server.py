"""
GatewayServer — FastAPI-based HTTP API gateway for WorkPilot.

Provides:
- / — status dashboard (auto-refresh every 5 s)
- /chat  /chat.html — chat UI (moved from /)
- /health — basic health check (backward compat)
- /v1/chat/completions — OpenAI-compatible chat completions (backward compat)
- /webhooks/{channel} — webhook receiver for GitHub/ADO/Teams/Outlook
- /api/chat — send prompt, receive response (via bus)
- /api/chat/stream — SSE streaming response
- /api/ws — WebSocket bidirectional chat
- /api/sessions — session management
- /api/tools — tool discovery
- /api/health — detailed health check
- /api/status — comprehensive runtime status (polled by dashboard)
- /api/estop — E-stop trigger
- /api/reset — E-stop reset

FastAPI and uvicorn are imported at use time so the rest of
WorkPilot can start without them installed.
"""

from __future__ import annotations

import asyncio
import json
import time
import uuid
from collections.abc import Callable
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

from loguru import logger
from pydantic import BaseModel, Field

from workpilot import __version__
from workpilot.config.schema import GatewayConfig
from workpilot.gateway.auth import AuthMiddleware
from workpilot.gateway.estop_middleware import EStopMiddleware
from workpilot.gateway.middleware import RateLimiter, RequestLogger
from workpilot.utils.helpers import webchat_url_from_connect

if TYPE_CHECKING:
    from workpilot.channels.web import WebChannel
    from workpilot.runtime import Runtime

# FastAPI types needed at module level for annotation resolution
# (from __future__ import annotations defers evaluation, so get_type_hints()
# needs these in module globals).
try:
    from fastapi import Request, WebSocket
except ImportError:
    pass


# ── Request / Response schemas (backward-compat OpenAI format) ─────────────


class ChatMessage(BaseModel):
    """Single message in a chat completion request."""

    role: str
    content: str


class ChatCompletionRequest(BaseModel):
    """OpenAI-compatible chat completion request."""

    messages: list[ChatMessage]
    model: str | None = None
    stream: bool = False
    temperature: float | None = None
    max_tokens: int | None = None


class ChatChoiceMessage(BaseModel):
    """Message inside a chat completion choice."""

    role: str = "assistant"
    content: str


class ChatChoice(BaseModel):
    """Single choice in a chat completion response."""

    index: int = 0
    message: ChatChoiceMessage
    finish_reason: str = "stop"


class UsageInfo(BaseModel):
    """Token usage statistics."""

    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0


class ChatCompletionResponse(BaseModel):
    """OpenAI-compatible chat completion response."""

    id: str = Field(default_factory=lambda: f"chatcmpl-{uuid.uuid4().hex[:12]}")
    object: str = "chat.completion"
    created: int = Field(default_factory=lambda: int(time.time()))
    model: str = "workpilot"
    choices: list[ChatChoice]
    usage: UsageInfo = Field(default_factory=UsageInfo)


class WebhookPayload(BaseModel):
    """Generic webhook payload — channels parse specifics themselves."""

    event: str | None = None
    payload: dict[str, Any] = Field(default_factory=dict)


class HealthResponse(BaseModel):
    """Basic health check response."""

    status: str = "ok"
    version: str = __version__


class ErrorResponse(BaseModel):
    """Standard error response body."""

    error: str
    message: str = ""


# ── New /api/* schemas ─────────────────────────────────────────────────────


class ChatRequest(BaseModel):
    """Request for /api/chat and /api/chat/stream."""

    prompt: str
    session_id: str | None = None


class ChatResponse(BaseModel):
    """Response from /api/chat."""

    response: str
    session_id: str


class ToolInfo(BaseModel):
    """Tool metadata for /api/tools."""

    name: str
    description: str
    risk_level: str
    approval: str
    tier: str = "core"
    active: bool = True
    type: str = "builtin"  # builtin | mcp_tool | mcp_server
    state: str | None = None  # MCP only: idle, connected, etc.
    tool_count: int | None = None  # MCP only


class HealthDetailResponse(BaseModel):
    """Detailed health for /api/health."""

    status: str
    version: str = __version__
    estop: dict[str, Any] = Field(default_factory=dict)
    bus: dict[str, Any] = Field(default_factory=dict)


class EStopRequest(BaseModel):
    """Request for /api/estop."""

    reason: str


class EStopResetRequest(BaseModel):
    """Request for /api/reset."""

    actor: str = "api"


# ── Gateway Server ─────────────────────────────────────────────────────────


class GatewayServer:
    """
    FastAPI-based HTTP API gateway for WorkPilot.

    Wraps the Runtime to expose an HTTP API with:
    - Legacy endpoints: /health, /v1/chat/completions, /webhooks/*
    - New API endpoints: /api/chat, /api/chat/stream, /api/ws,
      /api/sessions, /api/tools, /api/health, /api/estop, /api/reset
    """

    def __init__(
        self,
        config: GatewayConfig,
        runtime: Runtime,
        on_started: Callable[[int], None] | None = None,
    ) -> None:
        self._config = config
        self._runtime = runtime
        self._rate_limiter = RateLimiter(config.rate_limit_per_minute)
        self._web_channel: WebChannel | None = None
        self._server: Any = None  # uvicorn.Server instance
        self._on_started = on_started

        self._app = self._create_app()

    def set_web_channel(self, channel: WebChannel) -> None:
        """Inject the WebChannel after construction (called by Runtime)."""
        self._web_channel = channel

    # ── App factory ──────────────────────────────────────────────────────

    def _create_app(self) -> Any:  # noqa: C901
        """Build and return the FastAPI application."""
        try:
            from fastapi import FastAPI, WebSocketDisconnect
            from fastapi.middleware.cors import CORSMiddleware
            from fastapi.responses import HTMLResponse, JSONResponse, Response, StreamingResponse
        except ImportError as exc:
            raise ImportError(
                "FastAPI is required for the gateway server. "
                "Install it with: pip install fastapi uvicorn"
            ) from exc

        app = FastAPI(
            title="WorkPilot Gateway",
            version=__version__,
            docs_url=None,
            redoc_url=None,
        )

        # ── Middleware (outermost first) ─────────────────────────────────
        # FastAPI executes middleware in reverse add order:
        # Auth (innermost) → E-stop → RequestLogger → CORS (outermost)

        # CORS
        app.add_middleware(
            CORSMiddleware,
            allow_origins=self._config.cors_origins,
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

        # Request logging
        app.add_middleware(RequestLogger)

        # E-stop gate (returns 503 for /api/* when halted)
        app.add_middleware(EStopMiddleware, estop=self._runtime.estop)

        # Auth (skips /health and /api/health)
        if self._config.api_key is None and not (
            self._config.entra_tenant_id and self._config.entra_client_id
        ):
            logger.warning(
                "Gateway running WITHOUT authentication — set api_key or Entra ID "
                "in config to secure the API"
            )
        app.add_middleware(AuthMiddleware, config=self._config)

        # ── Helper ───────────────────────────────────────────────────────

        def _get_client_ip(request: Request) -> str:
            return request.client.host if request.client else "unknown"

        def _check_rate_limit(request: Request) -> JSONResponse | None:
            """Return a 429 JSONResponse if rate-limited, else None."""
            if not self._rate_limiter.check(_get_client_ip(request)):
                return JSONResponse(
                    status_code=429,
                    content=ErrorResponse(
                        error="rate_limit_exceeded",
                        message="Too many requests. Please try again later.",
                    ).model_dump(),
                )
            return None

        def _require_web_channel() -> JSONResponse | None:
            """Return a 503 JSONResponse if WebChannel is not available."""
            if self._web_channel is None:
                return JSONResponse(
                    status_code=503,
                    content=ErrorResponse(
                        error="service_unavailable",
                        message="Web channel not initialized.",
                    ).model_dump(),
                )
            return None

        # ── Static files (JS libs, favicon) ──────────────────────────────
        _static = Path(__file__).parent / "static"
        try:
            from starlette.staticfiles import StaticFiles

            app.mount("/static", StaticFiles(directory=str(_static)), name="static")
        except ImportError:
            pass  # starlette.staticfiles not available — JS served via CDN fallback

        # ── Web UI ────────────────────────────────────────────────────────

        # Cache both pages at startup

        _portal_html: str | None = None
        _portal_path = _static / "portal.html"
        if _portal_path.exists():
            _portal_html = _portal_path.read_text(encoding="utf-8")

        _chat_html: str | None = None
        _chat_path = _static / "chat.html"
        if _chat_path.exists():
            _chat_html = _chat_path.read_text(encoding="utf-8")

        _favicon_svg: str | None = None
        _favicon_path = _static / "favicon.svg"
        if _favicon_path.exists():
            _favicon_svg = _favicon_path.read_text(encoding="utf-8")

        # Track server start time for uptime calculation
        _started_at: datetime = datetime.now(UTC)

        @app.get("/", response_class=HTMLResponse)
        async def ui_index() -> HTMLResponse:
            """Status dashboard — system overview at a glance."""
            if _portal_html is None:
                return HTMLResponse(
                    "<h1>WorkPilot</h1><p>Status dashboard not found.</p>", status_code=404
                )
            return HTMLResponse(_portal_html)

        @app.get("/chat", response_class=HTMLResponse)
        @app.get("/chat.html", response_class=HTMLResponse)
        async def ui_chat() -> HTMLResponse:
            """Chat UI — moved from / to /chat."""
            if _chat_html is None:
                return HTMLResponse(
                    "<h1>WorkPilot Chat</h1><p>Chat UI not found.</p>", status_code=404
                )
            return HTMLResponse(_chat_html)

        @app.get("/auth/spa-callback", response_class=HTMLResponse)
        async def spa_callback() -> HTMLResponse:
            """Blank page for MSAL.js popup/redirect callback."""
            return HTMLResponse(
                "<!DOCTYPE html><html><head><title>Auth</title></head><body></body></html>",
                headers={"Cache-Control": "no-store"},
            )

        @app.get("/favicon.svg")
        async def favicon() -> Response:
            """Serve the WorkPilot SVG favicon."""
            if _favicon_svg is None:
                return Response(status_code=404)
            return Response(
                content=_favicon_svg,
                media_type="image/svg+xml",
                headers={"Cache-Control": "public, max-age=86400"},
            )

        # ── Legacy routes (backward compat) ──────────────────────────────

        @app.get("/health", response_model=HealthResponse)
        async def health() -> HealthResponse:
            return HealthResponse()

        @app.post("/v1/chat/completions", response_model=ChatCompletionResponse)
        async def chat_completions(
            body: ChatCompletionRequest,
            request: Request,
        ) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp

            if body.stream:
                return JSONResponse(
                    status_code=400,
                    content=ErrorResponse(
                        error="unsupported",
                        message="Streaming is not yet supported on this endpoint. Use /api/chat/stream.",
                    ).model_dump(),
                )

            user_messages = [m for m in body.messages if m.role == "user"]
            if not user_messages:
                return JSONResponse(
                    status_code=400,
                    content=ErrorResponse(
                        error="bad_request",
                        message="At least one user message is required.",
                    ).model_dump(),
                )

            prompt = user_messages[-1].content

            try:
                response_text = await self._runtime.run_prompt(prompt)
            except Exception as exc:
                logger.error(f"Chat completion error: {exc}")
                return JSONResponse(
                    status_code=500,
                    content=ErrorResponse(
                        error="internal_error",
                        message="An internal error occurred while processing the request.",
                    ).model_dump(),
                )

            result = ChatCompletionResponse(
                model=body.model or "workpilot",
                choices=[
                    ChatChoice(
                        message=ChatChoiceMessage(content=response_text),
                    ),
                ],
            )
            return JSONResponse(status_code=200, content=result.model_dump())

        @app.post("/webhooks/{channel}")
        async def webhook_receiver(
            channel: str,
            body: WebhookPayload,
            request: Request,
        ) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp

            supported = {"github", "ado", "teams", "outlook"}
            if channel not in supported:
                return JSONResponse(
                    status_code=404,
                    content=ErrorResponse(
                        error="not_found",
                        message=f"Unknown channel: {channel}. Supported: {', '.join(sorted(supported))}",
                    ).model_dump(),
                )

            logger.info(f"Webhook received: channel={channel}, event={body.event}")

            try:
                from workpilot.bus.events import InboundMessage

                msg = InboundMessage(
                    channel=channel,
                    channel_id=f"webhook-{channel}",
                    sender_id="webhook",
                    sender_name="webhook",
                    content=f"[webhook:{channel}] event={body.event}",
                    metadata={"webhook_event": body.event or "", **body.payload},
                )
                await self._runtime.bus.publish_inbound(msg)
            except Exception as exc:
                logger.error(f"Webhook processing error ({channel}): {exc}")
                return JSONResponse(
                    status_code=500,
                    content=ErrorResponse(
                        error="internal_error",
                        message="Failed to process webhook.",
                    ).model_dump(),
                )

            return JSONResponse(
                status_code=200,
                content={"status": "accepted", "channel": channel},
            )

        # ── New /api/* routes ────────────────────────────────────────────

        @app.get("/api/auth/config")
        async def auth_config() -> JSONResponse:
            entra_tid = self._config.entra_tenant_id
            entra_cid = self._config.entra_client_id
            return JSONResponse(
                content={
                    "entra_enabled": bool(entra_tid and entra_cid),
                    "entra_tenant_id": entra_tid,
                    "entra_client_id": entra_cid,
                    "api_key_enabled": self._config.api_key is not None,
                }
            )

        # ── Device code flow (no redirect URI needed) ────────────────────
        # Stores pending device code flows keyed by user_code
        _device_flows: dict[str, Any] = {}
        _device_msal_apps: dict[str, Any] = {}

        @app.post("/api/auth/device-code")
        async def device_code_start() -> JSONResponse:
            entra_tid = self._config.entra_tenant_id
            entra_cid = self._config.entra_client_id
            if not entra_tid or not entra_cid:
                return JSONResponse(
                    status_code=400,
                    content={
                        "error": "entra_not_configured",
                        "message": "Entra ID is not configured on this gateway.",
                    },
                )

            try:
                import msal as _msal

                app = _msal.PublicClientApplication(
                    client_id=entra_cid,
                    authority=f"https://login.microsoftonline.com/{entra_tid}",
                )
                flow = app.initiate_device_flow(scopes=[f"{entra_cid}/access_as_user"])
                if "user_code" not in flow:
                    return JSONResponse(
                        status_code=500,
                        content={
                            "error": "device_flow_failed",
                            "message": flow.get(
                                "error_description", "Failed to initiate device code flow"
                            ),
                        },
                    )

                user_code = flow["user_code"]
                _device_flows[user_code] = flow
                _device_msal_apps[user_code] = app

                return JSONResponse(
                    content={
                        "user_code": user_code,
                        "verification_uri": flow.get(
                            "verification_uri", "https://microsoft.com/devicelogin"
                        ),
                        "expires_in": flow.get("expires_in", 900),
                        "message": flow.get("message", ""),
                    }
                )
            except ImportError:
                return JSONResponse(
                    status_code=500,
                    content={
                        "error": "msal_not_installed",
                        "message": "MSAL library is not installed on the server.",
                    },
                )
            except Exception as exc:
                logger.error(f"Device code initiation error: {exc}")
                return JSONResponse(
                    status_code=500,
                    content={
                        "error": "internal_error",
                        "message": "Failed to start device code flow.",
                    },
                )

        @app.post("/api/auth/device-code/poll")
        async def device_code_poll(request: Request) -> JSONResponse:
            body = await request.json()
            user_code = body.get("user_code", "")

            flow = _device_flows.get(user_code)
            msal_app = _device_msal_apps.get(user_code)
            if not flow or not msal_app:
                return JSONResponse(
                    status_code=404,
                    content={
                        "error": "flow_not_found",
                        "message": "No pending device code flow for this code.",
                    },
                )

            try:
                result = await asyncio.to_thread(
                    msal_app.acquire_token_by_device_flow,
                    flow,
                    exit_condition=lambda flow: True,  # Return immediately after one poll
                )

                if "access_token" in result:
                    # Success — clean up
                    _device_flows.pop(user_code, None)
                    _device_msal_apps.pop(user_code, None)
                    # Persist user identity to USER.md (offloaded to thread — sync I/O)
                    from workpilot.utils.identity import save_identity

                    await asyncio.to_thread(
                        save_identity,
                        result.get("id_token_claims", {}),
                        self._runtime.workspace,
                        self._runtime.config.agents.default.user_file,
                    )
                    return JSONResponse(
                        content={
                            "status": "complete",
                            "access_token": result["access_token"],
                            "account": {
                                "name": result.get("id_token_claims", {}).get("name", ""),
                                "username": result.get("id_token_claims", {}).get(
                                    "preferred_username", ""
                                ),
                            },
                        }
                    )
                elif result.get("error") == "authorization_pending":
                    return JSONResponse(content={"status": "pending"})
                else:
                    # Error — clean up
                    _device_flows.pop(user_code, None)
                    _device_msal_apps.pop(user_code, None)
                    return JSONResponse(
                        status_code=400,
                        content={
                            "status": "error",
                            "error": result.get("error", "unknown"),
                            "message": result.get("error_description", "Authentication failed."),
                        },
                    )
            except Exception as exc:
                logger.error(f"Device code poll error: {exc}")
                return JSONResponse(content={"status": "pending"})

        @app.get("/api/health")
        async def api_health() -> JSONResponse:
            from workpilot.gateway.api_handlers import handle_health

            return JSONResponse(content=handle_health(self._runtime))

        @app.get("/api/status")
        async def api_status() -> JSONResponse:
            """Comprehensive runtime snapshot — polled by the status dashboard."""
            from workpilot.gateway.api_handlers import handle_status

            rt = self._runtime
            uptime = int((datetime.now(UTC) - _started_at).total_seconds())

            # Build channel list (gateway-specific — tracks live connections)
            _cloud_chan = rt.channel_manager.get("cloud")
            cloud_connected = getattr(_cloud_chan, "is_connected", False)
            cloud_cfg = rt.config.channels.cloud

            def _channel_entries(name: str) -> list[dict]:
                if name == "cloud":
                    return []
                if name in ("web", "gateway"):
                    return [{"name": name, "url": "/chat", "connected": True}]
                return [{"name": name, "url": None, "connected": True}]

            channels = [e for n in rt.channel_manager._channels for e in _channel_entries(n)]
            if cloud_cfg.enabled and cloud_cfg.url:
                try:
                    wc_url: str | None = webchat_url_from_connect(cloud_cfg.url)
                except ValueError:
                    wc_url = None
                channels.append(
                    {"name": "Web Chat (Cloud)", "url": wc_url, "connected": cloud_connected}
                )
                teams_url = cloud_cfg.teams_app_url or None
                channels.append(
                    {
                        "name": "Teams (Cloud)",
                        "url": teams_url,
                        "connected": cloud_connected and bool(teams_url),
                    }
                )

            return JSONResponse(
                handle_status(
                    rt,
                    uptime_seconds=uptime,
                    started_at=_started_at.isoformat(),
                    channels=channels,
                )
            )

        @app.post("/api/chat", response_model=ChatResponse)
        async def api_chat(body: ChatRequest, request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp

            channel_check = _require_web_channel()
            if channel_check:
                return channel_check

            assert self._web_channel is not None  # guarded above
            channel_id = self._web_channel.make_channel_id("web-req")
            sender_id = "api-user"
            timeout = self._config.request_timeout

            try:
                response_text = await self._web_channel.submit_and_wait(
                    channel_id=channel_id,
                    sender_id=sender_id,
                    content=body.prompt,
                    timeout=timeout,
                )
            except TimeoutError:
                return JSONResponse(
                    status_code=504,
                    content=ErrorResponse(
                        error="timeout",
                        message=f"Agent did not respond within {timeout} seconds.",
                    ).model_dump(),
                )
            except Exception as exc:
                logger.error(f"API chat error: {exc}")
                return JSONResponse(
                    status_code=500,
                    content=ErrorResponse(
                        error="internal_error",
                        message="An internal error occurred while processing the request.",
                    ).model_dump(),
                )

            session_id = body.session_id or self._runtime.session_manager.get_or_create_id(
                "web", sender_id
            )
            return JSONResponse(
                content=ChatResponse(
                    response=response_text,
                    session_id=session_id,
                ).model_dump(),
            )

        @app.post("/api/chat/stream")
        async def api_chat_stream(
            body: ChatRequest, request: Request
        ) -> StreamingResponse | JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp

            channel_check = _require_web_channel()
            if channel_check:
                return channel_check

            assert self._web_channel is not None
            channel_id = self._web_channel.make_channel_id("web-sse")
            sender_id = "api-user"
            timeout = self._config.request_timeout

            # Register response queue — SSE yields the final response as events
            response_queue = self._web_channel.register_request(channel_id)

            # Publish message through the bus
            await self._web_channel._handle_message(
                channel_id=channel_id,
                sender_id=sender_id,
                sender_name=sender_id,
                content=body.prompt,
            )

            async def event_generator():
                try:
                    result = await asyncio.wait_for(response_queue.get(), timeout=timeout)
                    if result is not None:
                        yield f"event: message\ndata: {json.dumps({'content': result, 'done': False}, ensure_ascii=False)}\n\n"
                    yield f"event: done\ndata: {json.dumps({'done': True})}\n\n"
                except TimeoutError:
                    yield f"event: error\ndata: {json.dumps({'error': 'timeout'})}\n\n"
                except Exception as exc:
                    logger.error(f"SSE stream error: {exc}")
                    yield f"event: error\ndata: {json.dumps({'error': 'internal_error'})}\n\n"
                finally:
                    self._web_channel.unregister_request(channel_id)  # type: ignore[union-attr]

            return StreamingResponse(
                event_generator(),
                media_type="text/event-stream",
                headers={
                    "Cache-Control": "no-cache",
                    "Connection": "keep-alive",
                    "X-Accel-Buffering": "no",
                },
            )

        @app.websocket("/api/ws")
        async def websocket_endpoint(websocket: WebSocket) -> None:
            await websocket.accept()

            # Save user identity from Entra JWT (injected by AuthMiddleware).
            # Fire-and-forget background task — sync I/O offloaded to thread.
            user_claims: dict = websocket.scope.get("user_claims", {})
            if user_claims:
                from workpilot.utils.identity import save_identity

                asyncio.create_task(
                    asyncio.to_thread(
                        save_identity,
                        user_claims,
                        self._runtime.workspace,
                        self._runtime.config.agents.default.user_file,
                    )
                )

            channel_check = _require_web_channel()
            if channel_check:
                await websocket.close(code=1011, reason="Web channel not initialized")
                return

            assert self._web_channel is not None
            channel_id = self._web_channel.make_channel_id("web-ws")
            response_queue = self._web_channel.register_request(channel_id)
            push_queue = self._web_channel.register_push(channel_id)

            async def _push_loop() -> None:
                """Forward push notifications (scheduler/background) to WebSocket."""
                while True:
                    msg = await push_queue.get()
                    if msg is None:
                        break
                    try:
                        await websocket.send_json({"type": "push", "content": msg})
                    except Exception:
                        break

            push_task = asyncio.create_task(_push_loop())

            async def _forward(msg: str) -> bool:
                """Send one queue item to the WebSocket. Returns True if it was a
                structured frame (approval_request etc.) so the caller knows whether
                the exchange is complete or still pending user action."""
                # Only unwrap known internal frame types to avoid treating normal
                # JSON responses (e.g. {"type": "object", ...}) as structured frames.
                _INTERNAL_TYPES = {"approval_request"}
                try:
                    parsed = json.loads(msg) if isinstance(msg, str) else None
                    if isinstance(parsed, dict) and parsed.get("type") in _INTERNAL_TYPES:
                        await websocket.send_json(parsed)
                        return True  # structured frame — exchange NOT complete
                except (json.JSONDecodeError, TypeError):
                    pass
                await websocket.send_json({"response": msg})
                return False  # plain text response — exchange complete

            def _resolve_approval(prompt: str, sender_id: str) -> bool:
                """If prompt is an approval response, resolve it and return True."""
                if not self._runtime.approval_manager:
                    return False
                mgr = self._runtime.approval_manager
                pending_list = mgr.get_pending()
                cl = prompt.strip().lower()
                action: str | None = None
                req_id: str | None = None
                if len(pending_list) == 1 and cl in (
                    "yes",
                    "y",
                    "approve",
                    "/approve",
                    "no",
                    "n",
                    "deny",
                    "/deny",
                    "always",
                    "a",
                    "/always",
                ):
                    sole = pending_list[0]
                    if cl in ("yes", "y", "approve", "/approve"):
                        action, req_id = "approve", sole.id
                    elif cl in ("no", "n", "deny", "/deny"):
                        action, req_id = "deny", sole.id
                    else:
                        action, req_id = "always", sole.id
                elif prompt.startswith("/approve "):
                    action, req_id = "approve", prompt.split(maxsplit=1)[1]
                elif prompt.startswith("/deny "):
                    action, req_id = "deny", prompt.split(maxsplit=1)[1]
                elif prompt.startswith("/always "):
                    action, req_id = "always", prompt.split(maxsplit=1)[1]

                if action and req_id:
                    from workpilot.bus.events import EventType

                    self._runtime.bus.events.emit(
                        EventType.APPROVAL_RESOLVED,
                        {"request_id": req_id, "action": action, "resolver": sender_id},
                    )
                    return True
                return False

            try:
                # ── Concurrent receive: user input OR agent response ───────────
                # After an approval card is shown the tool result arrives in
                # response_queue asynchronously (either via "y" text or REST
                # button click).  We must monitor BOTH simultaneously so neither
                # blocks the other.
                recv_task: asyncio.Task | None = None
                resp_task: asyncio.Task | None = None

                while True:
                    if recv_task is None or recv_task.done():
                        recv_task = asyncio.create_task(websocket.receive_json())
                    if resp_task is None or resp_task.done():
                        resp_task = asyncio.create_task(response_queue.get())

                    done, _ = await asyncio.wait(
                        {recv_task, resp_task},
                        return_when=asyncio.FIRST_COMPLETED,
                    )

                    # ── Agent sent something (approval card or tool result) ────
                    if resp_task in done:
                        resp_task_result = resp_task.result()
                        resp_task = None  # mark consumed
                        await _forward(resp_task_result or "")
                        # If it was an approval card, keep waiting (recv_task still
                        # active) so the user can respond without sending a new prompt.
                        # If it was a plain response we also keep waiting — the
                        # conversation is now back to idle.
                        continue

                    # ── User sent a message ───────────────────────────────────
                    if recv_task in done:
                        data = recv_task.result()
                        recv_task = None  # mark consumed
                        prompt = data.get("prompt", "")
                        sender_id = data.get("sender_id", "ws-user")

                        if not prompt:
                            await websocket.send_json({"error": "prompt is required"})
                            continue

                        # Approval fast-path: resolve directly via bus event so
                        # the sequential agent loop is not deadlocked.
                        if _resolve_approval(prompt, sender_id):
                            status_word = (
                                "approved"
                                if prompt.strip().lower() not in ("no", "n", "deny", "/deny")
                                else "denied"
                            )
                            await websocket.send_json({"response": f"Tool call {status_word}."})
                            # Tool result will arrive in response_queue; resp_task picks it up.
                            continue

                        # Normal message → submit to agent
                        await self._web_channel._handle_message(
                            channel_id=channel_id,
                            sender_id=sender_id,
                            sender_name=sender_id,
                            content=prompt,
                        )
                        # Response (or approval card) will arrive in response_queue;
                        # resp_task will pick it up on the next asyncio.wait iteration.
            except WebSocketDisconnect:
                logger.debug(f"WebSocket disconnected: {channel_id}")
            except Exception as exc:
                logger.error(f"WebSocket error: {exc}")
            finally:
                for t in (push_task, recv_task, resp_task):
                    if t is not None and not t.done():
                        t.cancel()
                try:
                    await push_task
                except (asyncio.CancelledError, Exception):
                    pass
                self._web_channel.unregister_push(channel_id)  # type: ignore[union-attr]
                self._web_channel.unregister_request(channel_id)  # type: ignore[union-attr]

        @app.get("/api/sessions")
        async def list_sessions(request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from workpilot.gateway.api_handlers import handle_sessions

            return JSONResponse(content=handle_sessions(self._runtime))

        @app.get("/api/sessions/{session_id:path}")
        async def get_session(session_id: str, request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from workpilot.gateway.api_handlers import handle_session_detail

            result = handle_session_detail(self._runtime, session_id)
            if result is None:
                return JSONResponse(
                    status_code=404,
                    content=ErrorResponse(
                        error="not_found",
                        message=f"Session not found: {session_id}",
                    ).model_dump(),
                )
            return JSONResponse(content=result)

        @app.delete("/api/sessions/{session_id:path}")
        async def delete_session(session_id: str, request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp

            self._runtime.session_manager.clear(session_id)
            return JSONResponse(content={"status": "deleted", "session_id": session_id})

        @app.get("/api/session/recent")
        async def api_session_recent(
            request: Request,
            channel: str = "web",
            sender_id: str = "ws-user",
            limit: int = 10,
        ) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from workpilot.gateway.api_handlers import handle_session_recent

            return JSONResponse(
                content=handle_session_recent(
                    self._runtime, channel=channel, sender_id=sender_id, limit=limit
                )
            )

        @app.get("/api/tools")
        async def list_tools(request: Request, limit: int = 1000) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from workpilot.gateway.api_handlers import handle_tools

            clamped = max(1, min(limit, 1000))
            return JSONResponse(content=handle_tools(self._runtime)[:clamped])

        @app.get("/api/memory")
        async def api_memory(request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from workpilot.gateway.api_handlers import handle_memory

            return JSONResponse(content=handle_memory(self._runtime))

        @app.get("/api/audit")
        async def api_audit(request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from workpilot.gateway.api_handlers import handle_audit

            return JSONResponse(content=handle_audit(self._runtime))

        @app.get("/api/cost")
        async def api_cost(request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from workpilot.gateway.api_handlers import handle_cost

            return JSONResponse(content=handle_cost())

        @app.get("/api/config")
        async def api_config(request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from workpilot.gateway.api_handlers import handle_config

            result = handle_config(self._runtime)
            if result is None:
                return JSONResponse(
                    status_code=500, content={"error": "Failed to serialize config."}
                )
            return JSONResponse(content=result)

        @app.get("/api/approvals")
        async def api_approvals(request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from workpilot.gateway.api_handlers import handle_approvals

            return JSONResponse(content=handle_approvals(self._runtime))

        @app.post("/api/approvals/{request_id}/resolve")
        async def api_resolve_approval(request_id: str, request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from workpilot.gateway.api_handlers import handle_approval_resolve

            try:
                body = await request.json()
            except Exception:
                return JSONResponse(status_code=400, content={"error": "Invalid JSON body."})

            code, result = handle_approval_resolve(
                self._runtime,
                request_id,
                body.get("approved", False),
                body.get("resolver", "web-user"),
                always=body.get("always", False),
            )
            return JSONResponse(status_code=code, content=result)

        @app.post("/api/estop")
        async def trigger_estop(body: EStopRequest, request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from workpilot.gateway.api_handlers import handle_estop

            return JSONResponse(content=handle_estop(self._runtime, body.reason))

        @app.post("/api/reset")
        async def reset_estop(body: EStopResetRequest, request: Request) -> JSONResponse:
            rate_resp = _check_rate_limit(request)
            if rate_resp:
                return rate_resp
            from workpilot.gateway.api_handlers import handle_reset

            return JSONResponse(content=handle_reset(self._runtime, body.actor))

        return app

    # ── Lifecycle ────────────────────────────────────────────────────────

    async def _notify_when_started(self) -> None:
        """Wait until uvicorn is listening, then fire the on_started callback.

        Passes the *actual* bound port (from the server socket) so callers
        receive the correct port even when port=0 was configured (ephemeral).
        Exceptions from the callback are logged as warnings and swallowed so
        a pid-file write failure never takes down the gateway.
        """
        while self._server is not None and not self._server.started:
            await asyncio.sleep(0.05)
        # Exit without calling the callback if stop() cleared the server
        # reference before uvicorn finished binding (rapid shutdown).
        if self._server is None or not self._server.started:
            return
        if self._on_started is None:
            return
        # Read the actual bound port from the first server socket.
        try:
            actual_port: int = self._server.servers[0].sockets[0].getsockname()[1]
        except Exception:
            actual_port = self._config.port  # fallback to configured value
        try:
            self._on_started(actual_port)
        except Exception:
            logger.warning("Exception in on_started callback during gateway startup", exc_info=True)

    async def start(self) -> None:
        """Start the gateway server using uvicorn."""
        try:
            import uvicorn
        except ImportError as exc:
            raise ImportError(
                "uvicorn is required for the gateway server. Install it with: pip install uvicorn"
            ) from exc

        config = uvicorn.Config(
            app=self._app,
            host=self._config.host,
            port=self._config.port,
            log_level="info",
        )
        self._server = uvicorn.Server(config)

        if self._on_started is not None:
            asyncio.create_task(self._notify_when_started())

        logger.info(f"Gateway server starting on http://{self._config.host}:{self._config.port}")
        await self._server.serve()

    async def stop(self) -> None:
        """Gracefully shut down the gateway server."""
        if self._server is not None:
            logger.info("Gateway server shutting down")
            self._server.should_exit = True
            self._server = None

    @property
    def app(self) -> Any:
        """Return the underlying FastAPI app (for testing or ASGI mounting)."""
        return self._app
