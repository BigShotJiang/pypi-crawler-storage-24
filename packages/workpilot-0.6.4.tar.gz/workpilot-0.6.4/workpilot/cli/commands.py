"""
CLI commands — Typer-based entry points for WorkPilot.

Bare command:
  workpilot                        — smart start: guided init + server launch

Top-level commands (defined here):
  workpilot chat                   — interactive agent REPL
  workpilot run "<prompt>"         — one-shot agent execution
  workpilot status                 — runtime status overview
  workpilot logs                   — show recent log output
  workpilot version                — print version string
  workpilot cloud                  — connect to Cloud Gateway

Separate modules (workpilot/cli/):
  serve.py     — workpilot serve (gateway server + PID helpers)
  doctor.py    — workpilot doctor (health diagnostics)
  init.py      — workpilot init (--quick, env detection, Agency MCP)
  update.py    — workpilot update / upgrade
  mcp.py       — workpilot mcp list | add | remove | add-agency
  agents.py    — workpilot agents list | add
  tools.py     — workpilot tools list
  sessions.py  — workpilot sessions list | show
  security.py  — workpilot security audit | credentials | roles
  skills.py    — workpilot skills list
  cron.py      — workpilot cron list | add
  memory.py    — workpilot memory show | search | clear | stats
"""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path
from typing import Any

import typer
from loguru import logger
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from workpilot import __version__
from workpilot.config.loader import load_config
from workpilot.config.schema import AppConfig
from workpilot.runtime import Runtime

# ── Console ─────────────────────────────────────────────────────────────────

console = Console()

# Set default log level to INFO before Runtime._setup_logging() takes over.
# Without this, loguru's default DEBUG handler shows debug output during
# early CLI flows (e.g. GitHub login in `workpilot init`).
logger.remove()
logger.add(sys.stderr, level="INFO")

# ── Helpers ─────────────────────────────────────────────────────────────────


def _get_runtime(
    config_path: str = ".",
    profile: str | None = None,
) -> Runtime:
    """Load config and construct a Runtime instance."""
    config = load_config(config_path, profile)
    return Runtime(config)


def _load_config_safe(
    config_path: str = ".",
    profile: str | None = None,
) -> AppConfig:
    """Load and validate configuration, exiting on failure."""
    try:
        return load_config(config_path, profile)
    except Exception as exc:
        console.print(f"[red]Config error:[/red] {exc}")
        raise typer.Exit(1)


def resolve_config_path(config: str) -> Path:
    """Resolve workpilot.yaml path from a file or directory argument.

    Search order when a directory is given:
      1. The specified directory
      2. ~/.workpilot/  (default location after ``workpilot init``)

    ``workpilot init`` only creates ``workpilot.local.yaml``.  When only
    the local override exists (no base yaml), the derived base path is
    returned even though the file does not exist — callers load config via
    ``_load_config_safe(parent_dir)`` which falls back to bundled defaults,
    and all writes target ``workpilot.local.yaml`` anyway.

    Raises ``typer.Exit(1)`` with a helpful message if not found.
    """
    config_path = Path(config)
    if config_path.is_dir():
        search_dirs = [config_path]
        user_dir = Path.home() / ".workpilot"
        if config_path.resolve() != user_dir.resolve() and user_dir.is_dir():
            search_dirs.append(user_dir)
        for search_dir in search_dirs:
            # Prefer base yaml; fall back to deriving the path from .local.yaml
            for candidate in ("workpilot.yaml", "workpilot.yml"):
                p = search_dir / candidate
                if p.exists():
                    return p
            for local_candidate in ("workpilot.local.yaml", "workpilot.local.yml"):
                lp = search_dir / local_candidate
                if lp.exists():
                    # Return the derived base path (may not exist); callers
                    # use _load_config_safe(parent) and write to .local.yaml
                    stem = local_candidate.replace(".local", "")
                    return search_dir / stem
        console.print(
            "[red]No workpilot.yaml found.[/red]\n"
            "  Run [bold]workpilot init[/bold] to create one, or use "
            "[bold]--config <path>[/bold] to specify its location."
        )
        raise typer.Exit(1)
    if not config_path.is_file():
        console.print(f"[red]Config file not found:[/red] {config_path}")
        raise typer.Exit(1)
    return config_path


def resolve_local_config_path(config_path: Path) -> Path:
    """Derive the .local.yaml sibling of a config file.

    workpilot.yaml  -> workpilot.local.yaml
    workpilot.yml   -> workpilot.local.yml
    """
    return config_path.parent / f"{config_path.stem}.local{config_path.suffix}"


# ── Sub-apps ────────────────────────────────────────────────────────────────

_ctx = {"help_option_names": ["-h", "--help"]}

agents_app = typer.Typer(name="agents", help="Manage configured agents", context_settings=_ctx, no_args_is_help=True)  # fmt: skip
tools_app = typer.Typer(name="tools", help="Tool management", context_settings=_ctx, no_args_is_help=True)  # fmt: skip
mcp_app = typer.Typer(name="mcp", help="MCP server management", context_settings=_ctx, no_args_is_help=True)  # fmt: skip
sessions_app = typer.Typer(name="sessions", help="Session management", context_settings=_ctx, no_args_is_help=True)  # fmt: skip
security_app = typer.Typer(name="security", help="Security and compliance", context_settings=_ctx, no_args_is_help=True)  # fmt: skip
skills_app = typer.Typer(name="skills", help="Skill management", context_settings=_ctx, no_args_is_help=True)  # fmt: skip
cron_app = typer.Typer(name="cron", help="Cron job management", context_settings=_ctx, no_args_is_help=True)  # fmt: skip
memory_app = typer.Typer(name="memory", help="Memory management", context_settings=_ctx, no_args_is_help=True)  # fmt: skip
secrets_app = typer.Typer(name="secrets", help="Secrets management", context_settings=_ctx, no_args_is_help=True)  # fmt: skip

# ── Main app ────────────────────────────────────────────────────────────────

app = typer.Typer(
    name="workpilot",
    help="WorkPilot — enterprise AI assistant for development and office productivity",
    add_completion=False,
    invoke_without_command=True,
    context_settings=_ctx,
)


@app.callback()
def _main_callback(ctx: typer.Context) -> None:
    """Smart entry point when no subcommand is given."""
    if ctx.invoked_subcommand is not None:
        return

    console.print(
        Panel(
            f"[bold]WorkPilot[/bold]  v{__version__}\n\n"
            "  workpilot init         — setup / reconfigure\n"
            "  workpilot s            — start web UI + cloud\n"
            "  workpilot chat         — interactive agent REPL\n"
            '  workpilot run "..."    — one-shot prompt\n'
            "  workpilot --help       — all commands\n\n"
            "  [dim]docs: https://aka.ms/workpilot/docs[/dim]",
            border_style="blue",
        )
    )

    # If no config, offer to run init first
    local_yaml = Path.home() / ".workpilot" / "workpilot.local.yaml"
    if not local_yaml.exists():
        console.print("[yellow]No configuration found.[/yellow]")
        if typer.confirm("Run initial setup?", default=True):
            from workpilot.cli.init import init as _init_cmd

            ctx.invoke(_init_cmd, directory=None, name=None, quick=False)
            console.print()
        else:
            return

    # Start the server (use ~/.workpilot as config dir to pick up init's output)
    ctx.invoke(
        serve,
        config=str(Path.home() / ".workpilot"),
        profile=None,
        host=None,
        port=None,
    )


# ═══════════════════════════════════════════════════════════════════════════
# Top-level commands
# ═══════════════════════════════════════════════════════════════════════════


async def _ws_chat_repl(port: int) -> None:
    """Connect to a running gateway via WebSocket and run an interactive REPL."""
    import json as _json

    import websockets  # type: ignore[import]

    url = f"ws://localhost:{port}/api/ws"
    console.print(
        f"[dim]Connected to running gateway (port {port}). "
        f"Type /new to clear session, Ctrl+C to exit.[/dim]\n"
    )
    # Reuse prompt_toolkit session for history + autocomplete (fallback to input())
    try:
        import os

        from prompt_toolkit import PromptSession
        from prompt_toolkit.history import FileHistory

        from workpilot.channels.cli import _SlashCompleter
        from workpilot.utils.helpers import get_data_dir

        _history_path = get_data_dir() / "cli_history"
        if os.name == "posix":
            try:
                if not _history_path.exists():
                    fd = os.open(_history_path, os.O_CREAT | os.O_WRONLY, 0o600)
                    os.close(fd)
                else:
                    os.chmod(_history_path, 0o600)
            except OSError:
                pass
        _ws_session: PromptSession[str] = PromptSession(
            "you> ",
            completer=_SlashCompleter(),
            complete_while_typing=True,
            history=FileHistory(str(_history_path)),
        )
        _get_input = lambda: _ws_session.prompt()  # noqa: E731
    except ImportError:
        console.print("[dim](basic input mode — autocomplete/history unavailable)[/dim]")
        _get_input = lambda: input("you> ")  # noqa: E731

    async with websockets.connect(url) as ws:
        while True:
            try:
                prompt = await asyncio.get_running_loop().run_in_executor(None, _get_input)
            except (EOFError, KeyboardInterrupt):
                break

            if not prompt.strip():
                continue

            # Slash commands handled locally
            if prompt.strip() == "/exit":
                break

            await ws.send(_json.dumps({"prompt": prompt}, ensure_ascii=False))

            # Loop until we get the actual response — push frames can arrive first
            while True:
                data = _json.loads(await ws.recv())
                if "response" in data:
                    from rich.markdown import Markdown

                    console.print(Markdown(data["response"]))
                    break
                elif "type" in data and data["type"] == "push":
                    console.print(f"[dim][push] {data.get('content', '')}[/dim]")
                elif "error" in data:
                    console.print(f"[red]{data['error']}[/red]")
                    break


def chat(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
    profile: str | None = typer.Option(None, "--profile", "-p", help="Config profile"),
) -> None:
    """Start an interactive agent REPL session.

    If 'workpilot serve' is already running, connects to it directly instead
    of starting a new Runtime instance.
    """
    running = _check_gateway_running()
    if running:
        _, port = running
        console.print(f"[dim]Gateway running on port {port} — connecting...[/dim]")
        try:
            asyncio.run(_ws_chat_repl(port))
        except KeyboardInterrupt:
            pass
        console.print("\nGoodbye!")
        return

    try:
        rt = _get_runtime(config, profile)
        asyncio.run(rt.run_chat())
    except KeyboardInterrupt:
        console.print("\nGoodbye!")
    except Exception as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(1)


def cloud(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
    profile: str | None = typer.Option(None, "--profile", "-p", help="Config profile"),
    url: str | None = typer.Option(None, "--url", help="Override Cloud Gateway WSS URL"),
    scope: str | None = typer.Option(None, "--scope", help="Override Entra ID scope"),
    login_method: str | None = typer.Option(
        None,
        "--login",
        help="Login method: auto (default), browser (PKCE popup), device (code at URL)",
    ),
) -> None:
    """Connect to WorkPilot Cloud Gateway (remote relay mode).

    Authenticates with Entra ID, then maintains a persistent WebSocket to
    the Cloud Gateway. Messages from Teams and Web Chat are relayed to the
    local agent; responses are sent back.

    Login methods:
      auto    — try browser popup, fall back to device code (default)
      browser — open browser for PKCE sign-in (http://localhost callback)
      device  — device code flow (URL + code; works without a browser)
    """
    cfg = _load_config_safe(config, profile)
    cloud_cfg = cfg.channels.cloud

    # Apply CLI overrides
    if url:
        cloud_cfg.url = url
    if scope:
        cloud_cfg.scope = scope
    if login_method:
        cloud_cfg.login_method = login_method  # type: ignore[assignment]

    method_label = {
        "auto": "browser -> device code fallback",
        "browser": "browser popup (PKCE)",
        "device": "device code (URL + code)",
    }.get(cloud_cfg.login_method, cloud_cfg.login_method)

    console.print(
        Panel(
            f"[bold]WorkPilot Cloud[/bold]  v{__version__}\n\n"
            f"Gateway : [cyan]{cloud_cfg.url}[/cyan]\n"
            f"Tenant  : [dim]{cloud_cfg.tenant_id}[/dim]\n"
            f"Client  : [dim]{cloud_cfg.client_id}[/dim]\n"
            f"Login   : [yellow]{method_label}[/yellow]\n\n"
            f"Sign in with your Entra ID account to continue.\n"
            f"Press [bold]Ctrl+C[/bold] to disconnect.",
            title="Cloud Gateway",
            border_style="blue",
        )
    )

    # If serve is running, check its cloud channel status instead of starting a new Runtime
    running = _check_gateway_running()
    if running:
        _, port = running
        try:
            import httpx as _httpx

            r = _httpx.get(f"http://localhost:{port}/api/status", timeout=3)
            status = r.json()
            channels = status.get("channels", [])
            cloud_ch = next((c for c in channels if "cloud" in c.get("name", "").lower()), None)
            connected = cloud_ch.get("connected", False) if cloud_ch else False
            if connected and cloud_ch is not None:
                console.print(
                    Panel(
                        f"[green]Cloud Gateway already connected[/green] via running serve (port {port}).\n\n"
                        f"Channel : {cloud_ch.get('name', 'Cloud')}\n"
                        f"URL     : {cloud_ch.get('url') or 'n/a'}\n\n"
                        f"No action needed — serve is handling cloud relay.",
                        title="Cloud Status",
                        border_style="green",
                    )
                )
                return
            else:
                console.print(
                    f"[yellow]Gateway is running (port {port}) but cloud channel is not connected.\n"
                    f"Ensure [bold]channels.cloud[/bold] is configured in workpilot.yaml "
                    f"and restart [bold]workpilot serve[/bold].[/yellow]"
                )
                raise typer.Exit(1)
        except Exception as exc:
            console.print(
                f"[yellow]Could not query running gateway: {exc}. Starting standalone cloud.[/yellow]"
            )

    try:
        asyncio.run(_run_cloud(cfg, cloud_cfg))
    except KeyboardInterrupt:
        console.print("\n[yellow]Disconnected from Cloud Gateway.[/yellow]")
    except Exception as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(1)


async def _run_cloud(cfg: AppConfig, cloud_cfg: Any) -> None:
    """Async entry point: wire up the cloud channel and run the agent loop."""
    from workpilot.channels.cloud import CloudChannel

    rt = Runtime(cfg)
    ch = CloudChannel(
        rt.bus,
        url=cloud_cfg.url,
        tenant_id=cloud_cfg.tenant_id,
        client_id=cloud_cfg.client_id,
        scope=cloud_cfg.scope,
        login_method=cloud_cfg.login_method,
        login_port=cloud_cfg.login_port,
        allow_from=cloud_cfg.allow_from or None,
        auto_reconnect=cloud_cfg.auto_reconnect,
        reconnect_max=cloud_cfg.reconnect_max,
        bypass_token=cloud_cfg.bypass_token,
        open_browser_on_connect=True,
    )
    ch.set_runtime(rt)  # allow admin relay to query Runtime APIs
    rt.channel_manager.add(ch)
    await ch.start()
    # Keep the agent loop running — messages arrive via the cloud channel
    await rt.run_cloud()


def run(
    prompt: str = typer.Argument(..., help="The prompt to send to the agent"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
    profile: str | None = typer.Option(None, "--profile", "-p", help="Config profile"),
    session_id: str | None = typer.Option(None, "--session", "-s", help="Resume a session"),
    model: str | None = typer.Option(None, "--model", "-m", help="Override model for this run"),
    output: str | None = typer.Option(
        None, "--output", "-o", help="Output file to write response to"
    ),
) -> None:
    """Run an agent with a one-shot prompt."""
    try:
        cfg = _load_config_safe(config, profile)
        if model:
            cfg.agents.default.model = model
        from workpilot.runtime import Runtime

        rt = Runtime(cfg)
        response = asyncio.run(rt.run_prompt(prompt, session_id))
        if output:
            Path(output).write_text(response, encoding="utf-8")
            console.print(f"[green]Response written to:[/green] {output}")
        else:
            console.print(response)
    except Exception as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(1)


def status(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
    profile: str | None = typer.Option(None, "--profile", "-p", help="Config profile"),
) -> None:
    """Show runtime configuration status."""
    cfg = _load_config_safe(config, profile)

    console.print(
        Panel(
            f"[bold]{cfg.name}[/bold]  v{__version__}\n"
            f"Security profile: [cyan]{cfg.security.profile.value}[/cyan]  |  "
            f"Entrypoint: [cyan]{cfg.entrypoint}[/cyan]",
            title="WorkPilot Status",
            border_style="blue",
        )
    )

    # Agents table
    agents_table = Table(title="Agents")
    agents_table.add_column("Name", style="bold")
    agents_table.add_column("Model")
    agents_table.add_column("Max Iter")
    agents_table.add_column("Tools")

    entry = cfg.entrypoint
    agents_table.add_row(
        "default" + (" *" if entry == "default" else ""),
        cfg.agents.default.model,
        str(cfg.agents.default.max_iterations),
        str(len(cfg.agents.default.tools)),
    )
    for name, ag in cfg.agents.agents.items():
        agents_table.add_row(
            name + (" *" if entry == name else ""),
            ag.model,
            str(ag.max_iterations),
            str(len(ag.tools)),
        )
    console.print(agents_table)

    # Channels
    channels_table = Table(title="Channels")
    channels_table.add_column("Channel", style="bold")
    channels_table.add_column("Enabled")
    channels_table.add_row("CLI", "[green]yes[/green]" if cfg.channels.cli.enabled else "no")
    web_cfg = cfg.channels.web
    web_status = (
        f"[green]yes[/green]  [dim]http://{web_cfg.host}:{web_cfg.port}[/dim]"
        if web_cfg.enabled
        else "no"
    )
    channels_table.add_row("Web", web_status)
    cloud_cfg = cfg.channels.cloud
    if not cloud_cfg.enabled:
        cloud_status = "no"
    elif not cloud_cfg.url:
        cloud_status = "[yellow]url not set[/yellow]"
    else:
        cloud_status = f"[green]yes[/green]  [dim]{cloud_cfg.url}[/dim]"
    channels_table.add_row("Web Chat (Cloud)", cloud_status)
    if cloud_cfg.enabled and cloud_cfg.teams_app_url:
        channels_table.add_row(
            "Teams (Cloud)", f"[green]yes[/green]  [dim]{cloud_cfg.teams_app_url}[/dim]"
        )
    elif cloud_cfg.enabled:
        channels_table.add_row("Teams (Cloud)", "[yellow]teams_app_url not set[/yellow]")
    console.print(channels_table)

    # Security
    console.print("\n[bold]Security[/bold]")
    console.print(f"  Profile:              {cfg.security.profile.value}")
    console.print(
        f"  Audit:                {'enabled' if cfg.security.audit.enabled else 'disabled'}"
    )
    console.print(f"  RBAC roles:           {len(cfg.security.roles)}")
    console.print(f"  Workspace restrict:   {cfg.tools.filesystem.restrict_to_workspace}")
    console.print(f"  Shell deny patterns:  {len(cfg.tools.shell.deny_patterns)}")

    # Features
    console.print("\n[bold]Features[/bold]")
    console.print(
        f"  Gateway:  {'[green]enabled[/green]' if cfg.channels.web.enabled else 'disabled'}"
    )
    console.print(f"  Cron:     {'[green]enabled[/green]' if cfg.cron.enabled else 'disabled'}")
    console.print(
        f"  Browser:  {'[green]enabled[/green]' if cfg.tools.browser.enabled else 'disabled'}"
    )

    # MCP servers
    mcp_count = len(cfg.tools.mcp_servers)
    console.print(f"  MCP servers: {mcp_count}")
    if mcp_count > 0:
        for name, srv in cfg.tools.mcp_servers.items():
            transport = "stdio" if srv.command else "http"
            console.print(f"    - {name} ({transport})")

    console.print()


def logs(
    lines: int = typer.Option(50, "--lines", "-n", help="Number of lines to show"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Show recent log output."""
    cfg = _load_config_safe(config)

    log_file = cfg.logging.file
    if not log_file:
        console.print("[yellow]No log file configured.[/yellow]  Logs go to stderr by default.")
        console.print("  Set [bold]logging.file[/bold] in workpilot.yaml to enable file logging.")
        return

    log_path = Path(log_file)
    if not log_path.exists():
        console.print(f"[yellow]Log file not found:[/yellow] {log_path}")
        return

    try:
        all_lines = log_path.read_text(encoding="utf-8").splitlines()
        tail = all_lines[-lines:] if len(all_lines) > lines else all_lines
        for line in tail:
            console.print(line)
    except Exception as exc:
        console.print(f"[red]Error reading log file:[/red] {exc}")
        raise typer.Exit(1)


def version() -> None:
    """Show WorkPilot version."""
    console.print(f"WorkPilot v{__version__}")


# ═══════════════════════════════════════════════════════════════════════════
# Sub-app modules — populate sub-app Typers (no effect on main app order)
# ═══════════════════════════════════════════════════════════════════════════

import workpilot.cli.agents as _agents  # noqa: F401, E402
import workpilot.cli.cron as _cron  # noqa: F401, E402
import workpilot.cli.mcp as _mcp  # noqa: F401, E402
import workpilot.cli.memory as _memory  # noqa: F401, E402
import workpilot.cli.security as _security  # noqa: F401, E402
import workpilot.cli.sessions as _sessions  # noqa: F401, E402
import workpilot.cli.skills as _skills  # noqa: F401, E402
import workpilot.cli.tools as _tools  # noqa: F401, E402
from workpilot.cli.doctor import doctor  # noqa: E402

# serve and doctor live in their own modules; import their public symbols
# into this namespace so _main_callback and other functions can reference them.
from workpilot.cli.serve import _check_gateway_running, serve  # noqa: E402

# ═══════════════════════════════════════════════════════════════════════════
# Command registration — ordered by usage frequency / logical grouping
# ═══════════════════════════════════════════════════════════════════════════

# ── Primary ──────────────────────────────────────────────────────────────
app.command()(chat)
app.command()(run)
app.command()(serve)
app.command("s", hidden=True)(serve)
app.command()(cloud)

# init and update self-register via @app.command() in their own modules
import workpilot.cli.init as _init  # noqa: F401, E402
import workpilot.cli.update as _update  # noqa: F401, E402

# ── Management ───────────────────────────────────────────────────────────
app.add_typer(agents_app, name="agents")
app.add_typer(tools_app, name="tools")
app.add_typer(mcp_app, name="mcp")
app.add_typer(sessions_app, name="sessions")
app.add_typer(skills_app, name="skills")
app.add_typer(memory_app, name="memory")
app.add_typer(cron_app, name="cron")
app.add_typer(secrets_app, name="secrets")

# ── Diagnostics / info ────────────────────────────────────────────────────
app.command()(status)
app.command()(doctor)
app.command()(logs)
app.add_typer(security_app, name="security")
app.command()(version)

# ── Hidden aliases ────────────────────────────────────────────────────────
app.command("server", hidden=True)(serve)
app.command("start", hidden=True)(serve)
app.command("agent", hidden=True)(chat)
app.command("gateway", hidden=True)(serve)
# onboard alias registered in workpilot.cli.init
