from .generator import (
    BatchMatrixData,
    GeneratorConfig,
    MatrixDomain,
    MatrixGeneratorRegistry,
    build_training_registry,
    build_eval_registry,
)
from .nn import ContextResGCN, BaselineResGCN
from .precond import MatrixPFN
from .precond.matrix_pfn import TrainingConfig
from .solver import FGMRES, Arnoldi
