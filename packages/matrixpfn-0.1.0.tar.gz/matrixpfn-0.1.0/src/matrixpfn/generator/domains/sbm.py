import random

import numpy as np
import torch

from ..base import BatchMatrixData, MatrixDomain, TopologySkeleton, make_context_pairs, scale_and_shift


class SBMGraphGenerator:

    def __init__(self, ns: tuple[int, ...] | int, device: torch.device):
        if isinstance(ns, int):
            ns = (ns,)
        self.ns = ns
        self.device = device

    def generate_topology_cpu(self, n: int, num_clusters: int = 3,
                               p_in: float = 0.3, p_out: float = 0.01) -> TopologySkeleton:
        block_sizes = [n // num_clusters] * num_clusters
        block_sizes[-1] += n - sum(block_sizes)

        block_assignments = np.repeat(np.arange(num_clusters), block_sizes)

        i_idx, j_idx = np.triu_indices(n, k=1)
        same_block = block_assignments[i_idx] == block_assignments[j_idx]
        probs = np.where(same_block, p_in, p_out)

        edge_mask = np.random.random(len(i_idx)) < probs
        edges_src = i_idx[edge_mask]
        edges_dst = j_idx[edge_mask]

        if len(edges_src) == 0:
            raise ValueError("SBM generated zero edges — parameters too sparse")

        rows = np.concatenate([edges_src, edges_dst])
        cols = np.concatenate([edges_dst, edges_src])
        diag_idx = np.arange(n, dtype=np.int64)
        all_rows = np.concatenate([rows, diag_idx])
        all_cols = np.concatenate([cols, diag_idx])

        degrees = np.zeros(n, dtype=np.float64)
        np.add.at(degrees, rows, 1)

        return TopologySkeleton(
            rows=all_rows,
            cols=all_cols,
            n=n,
            domain=MatrixDomain.SBM,
            metadata={"degrees": degrees, "num_clusters": num_clusters},
        )

    def fill_values_gpu(self, skeleton: TopologySkeleton, num_context_pairs: int) -> BatchMatrixData:
        n = skeleton.n
        rows_t = torch.from_numpy(skeleton.rows).to(self.device)
        cols_t = torch.from_numpy(skeleton.cols).to(self.device)
        degrees = torch.from_numpy(skeleton.metadata["degrees"]).to(self.device)

        num_edges_doubled = len(skeleton.rows) - n
        edge_vals = -torch.ones(num_edges_doubled, dtype=torch.float64, device=self.device)
        diag_vals = degrees.clone()
        all_vals = torch.cat([edge_vals, diag_vals])

        indices = torch.stack([rows_t, cols_t])
        scaled_vals, diagonals = scale_and_shift(indices, all_vals, n)

        context_pairs = make_context_pairs(indices, scaled_vals, n, num_context_pairs, self.device)

        return BatchMatrixData(
            indices=indices,
            values=scaled_vals.unsqueeze(0),
            diagonals=diagonals.unsqueeze(0),
            context_pairs=context_pairs.unsqueeze(0),
            n=n,
            batch_size=1,
            domain=MatrixDomain.SBM,
        )

    def generate_batch(self, batch_size: int, num_context_pairs: int) -> BatchMatrixData:
        n = random.choice(self.ns)
        num_clusters = random.randint(2, 5)
        p_in = random.uniform(0.1, 0.4)
        p_out = random.uniform(0.001, 0.05)
        skeleton = self.generate_topology_cpu(n, num_clusters, p_in, p_out)
        return self.fill_values_gpu(skeleton, num_context_pairs)
