import torch


class NoPreconditioner:

    def apply(self, r: torch.Tensor) -> torch.Tensor:
        return r
