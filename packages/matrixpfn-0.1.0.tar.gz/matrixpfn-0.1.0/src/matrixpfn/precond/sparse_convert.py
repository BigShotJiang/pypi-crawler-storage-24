import torch
import numpy as np
from scipy.sparse import csc_array, csr_matrix


def torch_csc_to_scipy_csr(A: torch.Tensor) -> csr_matrix:
    if A.layout != torch.sparse_csc:
        raise TypeError(f"Expected torch.sparse_csc, got {A.layout}")

    A_csc = csc_array((
        A.values().cpu().numpy(),
        A.row_indices().cpu().numpy().astype(np.int32),
        A.ccol_indices().cpu().numpy().astype(np.int32),
    ), shape=A.shape)

    return csr_matrix(A_csc)


def torch_csc_to_scipy_csc(A: torch.Tensor) -> csc_array:
    if A.layout != torch.sparse_csc:
        raise TypeError(f"Expected torch.sparse_csc, got {A.layout}")

    return csc_array((
        A.values().cpu().numpy(),
        A.row_indices().cpu().numpy().astype(np.int32),
        A.ccol_indices().cpu().numpy().astype(np.int32),
    ), shape=A.shape)


def to_numpy(r: torch.Tensor) -> np.ndarray:
    return r.detach().cpu().numpy()


def from_numpy(x: np.ndarray, dtype: torch.dtype, device: torch.device) -> torch.Tensor:
    return torch.from_numpy(np.ascontiguousarray(x)).to(dtype=dtype, device=device)
