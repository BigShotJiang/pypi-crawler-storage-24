"""Disco Python SDK."""

import asyncio
import os
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

import httpx

try:
    import pandas as pd
except ImportError:
    pd = None

from discovery.errors import (
    AuthenticationError,
    InsufficientCreditsError,
    PaymentRequiredError,
    RateLimitError,
    RunFailedError,
    RunNotFoundError,
)
from discovery.types import (
    Column,
    CorrelationEntry,
    EngineResult,
    FeatureImportance,
    FeatureImportanceScore,
    Pattern,
    PatternGroup,
    RunStatus,
    Summary,
)


class Engine:
    """Client for the Disco API.

    The primary method is ``discover()`` — submit a dataset, wait for analysis,
    and get back structured patterns with p-values, novelty scores, and citations.

    Args:
        api_key: Your Disco API key (``disco_...``).
        quiet: If True, suppress all status output. Useful for agent workflows.
    """

    # Dashboard URL — single base URL for all API calls
    _DEFAULT_DASHBOARD_URL = "https://disco.leap-labs.com"

    _TIMEOUT = httpx.Timeout(connect=30.0, read=300.0, write=1800.0, pool=30.0)

    def __init__(self, api_key: str, *, quiet: bool = False):
        self.api_key = api_key
        self.quiet = quiet
        self.dashboard_url = os.getenv(
            "DISCOVERY_DASHBOARD_URL", self._DEFAULT_DASHBOARD_URL
        ).rstrip("/")
        self._dashboard_client: Optional[httpx.AsyncClient] = None
        self._log("Initializing Disco...")

    def _log(self, message: str) -> None:
        """Print a message unless quiet mode is enabled."""
        if not self.quiet:
            print(message)

    # ------------------------------------------------------------------
    # HTTP clients
    # ------------------------------------------------------------------

    async def _get_dashboard_client(self) -> httpx.AsyncClient:
        """Get or create the HTTP client for all API calls."""
        if self._dashboard_client is None:
            self._dashboard_client = httpx.AsyncClient(
                base_url=self.dashboard_url,
                headers={"Authorization": f"Bearer {self.api_key}"},
                timeout=self._TIMEOUT,
            )
        return self._dashboard_client

    @classmethod
    def _make_anon_client(cls) -> httpx.AsyncClient:
        """Create an unauthenticated client for public endpoints."""
        base_url = os.getenv("DISCOVERY_DASHBOARD_URL", cls._DEFAULT_DASHBOARD_URL).rstrip("/")
        return httpx.AsyncClient(base_url=base_url, timeout=cls._TIMEOUT)

    async def close(self) -> None:
        """Close the HTTP client."""
        if self._dashboard_client:
            await self._dashboard_client.aclose()
            self._dashboard_client = None

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()

    # ------------------------------------------------------------------
    # Error handling helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _raise_for_status(response: httpx.Response) -> None:
        """Raise structured errors for common HTTP status codes."""
        if response.status_code < 400:
            return
        try:
            body = response.json()
            detail = body.get("detail") or body.get("error") or response.text
        except Exception:
            detail = response.text

        if response.status_code == 401:
            raise AuthenticationError(str(detail))
        if response.status_code == 402:
            raise PaymentRequiredError(str(detail))
        if response.status_code == 404:
            raise RunNotFoundError(message=str(detail))
        if response.status_code == 429:
            retry_after = response.headers.get("Retry-After")
            raise RateLimitError(
                retry_after=float(retry_after) if retry_after else None,
                message=str(detail),
            )
        # Fall through to httpx default
        response.raise_for_status()

    # ------------------------------------------------------------------
    # No-auth class methods
    # ------------------------------------------------------------------

    @classmethod
    async def list_plans(cls) -> List[Dict[str, Any]]:
        """List available plans and pricing. No authentication required.

        Returns:
            Dict with ``plans`` list, ``credit_price_usd``, ``credit_pack_size``,
            and ``credit_pack_price_usd``.
        """
        async with cls._make_anon_client() as client:
            response = await client.get("/api/plans")
            response.raise_for_status()
            return response.json()

    @classmethod
    async def signup(
        cls,
        email: str,
        *,
        name: Optional[str] = None,
        quiet: bool = False,
    ) -> "Engine":
        """Create an account and return a configured Engine instance.

        Sends a 6-digit verification code to the email address. Prompts for
        the code interactively, then provisions the account and returns a
        configured Engine with a ``disco_`` API key.

        If the email service is unavailable, falls back to direct provisioning
        and returns immediately (no code required).

        Args:
            email: Email address for the new account.
            name: Display name (optional — defaults to email local part).
            quiet: If True, suppress status output.

        Returns:
            A configured Engine instance with the new API key.

        Raises:
            ValueError: If the email is already registered (409).
        """
        body: Dict[str, Any] = {"email": email}
        if name:
            body["name"] = name

        async with cls._make_anon_client() as client:
            response = await client.post("/api/signup", json=body)
            cls._raise_for_status(response)
            data = response.json()

        # Direct provisioning fallback (Resend unavailable) — already have the key
        if data.get("key"):
            engine = cls(api_key=data["key"], quiet=quiet)
            if not quiet:
                print(
                    f"Account created. Tier: {data.get('tier', 'free_tier')}, "
                    f"Credits: {data.get('credits', 0)}"
                )
            return engine

        # Verification required — prompt for the code
        if not quiet:
            print(f"A verification code has been sent to {data['email']}.")
        code = input("Enter verification code: ").strip()

        async with cls._make_anon_client() as client:
            verify_response = await client.post(
                "/api/signup/verify",
                json={"email": email, "code": code},
            )
            cls._raise_for_status(verify_response)
            key_data = verify_response.json()

        engine = cls(api_key=key_data["key"], quiet=quiet)
        if not quiet:
            print(
                f"Account created. Tier: {key_data.get('tier', 'free_tier')}, "
                f"Credits: {key_data.get('credits', 0)}"
            )
        return engine

    # ------------------------------------------------------------------
    # discover() — the primary method for agents
    # ------------------------------------------------------------------

    async def discover(
        self,
        file: Union[str, Path, "pd.DataFrame"],
        target_column: str,
        depth_iterations: int = 1,
        visibility: str = "public",
        title: Optional[str] = None,
        description: Optional[str] = None,
        column_descriptions: Optional[Dict[str, str]] = None,
        excluded_columns: Optional[List[str]] = None,
        timeout: float = 1800,
        **kwargs,
    ) -> EngineResult:
        """Run Disco on a dataset and return results.

        This is the primary method. It uploads data, submits the analysis,
        polls for completion, and returns structured results — all in one call.
        Runs typically take 3-15 minutes.

        Args:
            file: File path, Path object, or pandas DataFrame.
            target_column: Column to analyze (what drives it up or down?).
            depth_iterations: 1=fast, higher=deeper pattern search (max: num_columns - 2).
            visibility: "public" (free, published) or "private" (costs credits).
            title: Optional dataset title.
            description: Optional dataset description.
            column_descriptions: Dict mapping column names to descriptions.
                Significantly improves pattern explanations for non-obvious column names.
            excluded_columns: Columns to exclude from analysis.
            timeout: Max seconds to wait for completion (default: 1800).
            **kwargs: Additional arguments passed to run_async().

        Returns:
            EngineResult with patterns, summary, feature importance, and report_url.

        Raises:
            InsufficientCreditsError: Not enough credits for a private run.
            RunFailedError: Analysis failed server-side.
            TimeoutError: Analysis didn't complete within timeout.
            FileNotFoundError: Input file doesn't exist.
        """
        return await self.run_async(
            file=file,
            target_column=target_column,
            depth_iterations=depth_iterations,
            visibility=visibility,
            title=title,
            description=description,
            column_descriptions=column_descriptions,
            excluded_columns=excluded_columns,
            wait=True,
            wait_timeout=timeout,
            **kwargs,
        )

    def discover_sync(
        self,
        file: Union[str, Path, "pd.DataFrame"],
        target_column: str,
        depth_iterations: int = 1,
        visibility: str = "public",
        title: Optional[str] = None,
        description: Optional[str] = None,
        column_descriptions: Optional[Dict[str, str]] = None,
        excluded_columns: Optional[List[str]] = None,
        timeout: float = 1800,
        **kwargs,
    ) -> EngineResult:
        """Synchronous version of discover(). See discover() for full docs."""
        return self._run_sync(
            self.discover(
                file=file,
                target_column=target_column,
                depth_iterations=depth_iterations,
                visibility=visibility,
                title=title,
                description=description,
                column_descriptions=column_descriptions,
                excluded_columns=excluded_columns,
                timeout=timeout,
                **kwargs,
            )
        )

    # ------------------------------------------------------------------
    # Account & billing
    # ------------------------------------------------------------------

    async def get_account(self) -> Dict[str, Any]:
        """Get account info: plan, credits, payment method status.

        Returns:
            Dict with ``plan``, ``credits``, ``payment_method``, and more.
        """
        client = await self._get_dashboard_client()
        response = await client.get("/api/account")
        self._raise_for_status(response)
        return response.json()

    async def add_payment_method(self, payment_method_id: str) -> Dict[str, Any]:
        """Attach a Stripe payment method to your account.

        The payment method must be tokenized via Stripe's API first (card details
        never touch Disco).

        Args:
            payment_method_id: Stripe payment method token (``pm_...``).

        Returns:
            Dict with ``payment_method_attached``, ``card_last4``, ``card_brand``.
        """
        client = await self._get_dashboard_client()
        response = await client.post(
            "/api/account/payment-method",
            json={"payment_method_id": payment_method_id},
        )
        self._raise_for_status(response)
        return response.json()

    async def subscribe(self, plan: str) -> Dict[str, Any]:
        """Subscribe to or change your plan.

        Args:
            plan: Plan tier — "free_tier", "tier_1", or "tier_2".

        Returns:
            Dict with ``plan``, ``name``, ``monthly_credits``, ``price_usd``.
        """
        client = await self._get_dashboard_client()
        response = await client.post(
            "/api/account/subscribe",
            json={"plan": plan},
        )
        self._raise_for_status(response)
        return response.json()

    async def purchase_credits(self, packs: int = 1) -> Dict[str, Any]:
        """Purchase credit packs. Each pack is 20 credits for $20.

        Requires a payment method on file.

        Args:
            packs: Number of 20-credit packs to purchase (default: 1).

        Returns:
            Dict with ``purchased_credits``, ``total_credits``, ``charge_amount_usd``.

        Raises:
            PaymentRequiredError: No payment method on file.
        """
        client = await self._get_dashboard_client()
        response = await client.post(
            "/api/account/credits/purchase",
            json={"packs": packs},
        )
        self._raise_for_status(response)
        return response.json()

    # ------------------------------------------------------------------
    # Estimation (works with or without auth)
    # ------------------------------------------------------------------

    async def estimate(
        self,
        file_size_mb: float,
        num_columns: int,
        num_rows: Optional[int] = None,
        depth_iterations: int = 1,
        visibility: str = "public",
    ) -> Dict[str, Any]:
        """Estimate cost and time for an analysis run.

        Works with or without authentication. If authenticated, the response
        includes your current credit balance and whether you have enough.

        Args:
            file_size_mb: Size of the data file in megabytes.
            num_columns: Number of columns in the dataset.
            num_rows: Number of rows (improves time estimate accuracy).
            depth_iterations: Depth iterations (1=fast, higher=deeper).
            visibility: "public" (free, results published) or "private" (costs credits).

        Returns:
            Dict with ``cost``, ``time_estimate``, ``limits``, and ``account`` info.
        """
        client = await self._get_dashboard_client()
        response = await client.post(
            "/api/estimate",
            json={
                "file_size_mb": file_size_mb,
                "num_columns": num_columns,
                "num_rows": num_rows,
                "depth_iterations": depth_iterations,
                "visibility": visibility,
            },
        )
        self._raise_for_status(response)
        return response.json()

    async def get_results(self, run_id: str) -> EngineResult:
        """Get complete analysis results for a run."""
        dashboard_client = await self._get_dashboard_client()
        response = await dashboard_client.get(f"/api/runs/{run_id}/results")
        if response.status_code == 404:
            try:
                body = response.json()
                detail = body.get("error", "Unknown")
                code = body.get("code", "UNKNOWN")
            except Exception:
                detail = response.text
                code = "UNKNOWN"
            raise RunNotFoundError(
                run_id=run_id,
                message=f"Run {run_id} not found: {detail} (code={code})",
            )
        self._raise_for_status(response)
        data = response.json()
        return self._parse_analysis_result(data)

    async def get_run_status(self, run_id: str) -> RunStatus:
        """Get the status of a run."""
        dashboard_client = await self._get_dashboard_client()
        response = await dashboard_client.get(f"/api/runs/{run_id}/results")
        self._raise_for_status(response)
        data = response.json()
        return RunStatus(
            run_id=data["run_id"],
            status=data["status"],
            job_id=data.get("job_id"),
            job_status=data.get("job_status"),
            queue_position=data.get("queue_position"),
            current_step=data.get("current_step", {}).get("status")
            if data.get("current_step")
            else None,
            current_step_message=data.get("current_step", {}).get("message")
            if data.get("current_step")
            else None,
            estimated_seconds=data.get("estimated_seconds"),
            estimated_wait_seconds=data.get("estimated_wait_seconds"),
            error_message=data.get("error_message"),
        )

    async def wait_for_completion(
        self,
        run_id: str,
        poll_interval: float = 5.0,
        timeout: Optional[float] = None,
    ) -> EngineResult:
        """Wait for a run to complete and return the results.

        Raises:
            TimeoutError: If the run doesn't complete within the timeout.
            RunFailedError: If the run fails server-side.
            RunNotFoundError: If the run disappears during polling.
        """
        start_time = time.time()
        last_status = None
        last_step = None
        poll_count = 0
        consecutive_errors = 0
        max_consecutive_errors = 3

        self._log(f"Waiting for run {run_id} to complete...")

        while True:
            try:
                result = await self.get_results(run_id)
                consecutive_errors = 0
            except RunNotFoundError:
                consecutive_errors += 1
                elapsed = time.time() - start_time
                if consecutive_errors >= max_consecutive_errors:
                    raise RunNotFoundError(
                        run_id=run_id,
                        message=(
                            f"Run {run_id} not found after {elapsed:.0f}s of polling "
                            f"(last status: {last_status}). "
                            "The run may have been deleted or cleaned up server-side."
                        ),
                    )
                self._log(
                    f"  Run returned 404 (attempt {consecutive_errors}/{max_consecutive_errors}), retrying..."
                )
                await asyncio.sleep(poll_interval)
                continue
            except httpx.HTTPStatusError:
                consecutive_errors += 1
                if consecutive_errors >= max_consecutive_errors:
                    raise
                await asyncio.sleep(poll_interval)
                continue

            elapsed = time.time() - start_time
            poll_count += 1

            if result.status != "completed" and (
                result.status != last_status
                or result.current_step != last_step
                or poll_count % 3 == 0
            ):
                if result.job_status == "pending":
                    pos = result.queue_position
                    pos_str = f" (position {pos} in queue)" if pos is not None else ""
                    wait_str = ""
                    if result.estimated_wait_seconds is not None:
                        mins = max(1, round(result.estimated_wait_seconds / 60))
                        wait_str = f" | Est. wait: ~{mins} min"
                    status_msg = f"Status: waiting{pos_str}{wait_str} | Upgrade at disco.leap-labs.com/account for priority processing"
                else:
                    step_str = ""
                    if result.current_step and result.current_step not in (
                        "pending",
                        "completed",
                        "failed",
                    ):
                        msg = (
                            f" — {result.current_step_message}"
                            if result.current_step_message
                            else ""
                        )
                        step_str = f" ({result.current_step}{msg})"
                    eta_str = ""
                    if result.estimated_seconds is not None and elapsed > 0:
                        remaining = max(0, result.estimated_seconds - elapsed)
                        if remaining > 0:
                            eta_str = f" | ETA: ~{max(1, round(remaining / 60))} min"
                    status_msg = (
                        f"Status: {result.status}{step_str} | Elapsed: {elapsed:.1f}s{eta_str}"
                    )
                self._log(f"  {status_msg}")

            last_status = result.status
            last_step = result.current_step

            if result.status == "completed":
                n = len(result.patterns)
                pattern_str = f"{n} pattern{'s' if n != 1 else ''} found"
                self._log(f"Run completed in {elapsed:.1f}s | {pattern_str}")
                for hint in result.hints:
                    self._log(hint)
                if result.report_url:
                    self._log(f"Report: {result.report_url}")
                return result
            elif result.status == "failed":
                error_msg = result.error_message or "Unknown error"
                self._log(f"Run failed: {error_msg}")
                raise RunFailedError(run_id, error_msg)

            if timeout and elapsed > timeout:
                raise TimeoutError(f"Run {run_id} did not complete within {timeout} seconds")

            await asyncio.sleep(poll_interval)

    # ------------------------------------------------------------------
    # File upload
    # ------------------------------------------------------------------

    async def _presign_and_upload(
        self,
        file_content: bytes,
        filename: str,
        mime_type: str,
    ) -> Tuple[Dict[str, Any], Dict[str, Any]]:
        """Upload a file using presigned URL (3-step: presign, upload, finalize)."""
        dashboard_client = await self._get_dashboard_client()
        file_size = len(file_content)

        presign_response = await dashboard_client.post(
            "/api/data/upload/presign",
            json={
                "fileName": filename,
                "contentType": mime_type,
                "fileSize": file_size,
            },
        )

        if presign_response.status_code >= 400:
            try:
                error_data = presign_response.json()
                error_message = error_data.get("error", presign_response.text)
            except Exception:
                error_message = presign_response.text
            raise ValueError(f"Presign error ({presign_response.status_code}): {error_message}")

        presign_data = presign_response.json()
        upload_url = presign_data["uploadUrl"]
        key = presign_data["key"]
        upload_token = presign_data["uploadToken"]

        async with httpx.AsyncClient(timeout=self._TIMEOUT) as upload_client:
            upload_response = await upload_client.put(
                upload_url,
                content=file_content,
                headers={"Content-Type": mime_type},
            )
            if upload_response.status_code >= 400:
                raise ValueError(
                    f"Direct upload failed ({upload_response.status_code}): {upload_response.text}"
                )

        finalize_response = await dashboard_client.post(
            "/api/data/upload/finalize",
            json={"key": key, "uploadToken": upload_token},
        )

        if finalize_response.status_code >= 400:
            try:
                error_data = finalize_response.json()
                error_message = error_data.get("error", finalize_response.text)
                if "issues" in error_data:
                    errors = error_data["issues"].get("errors", [])
                    if errors:
                        error_message = errors[0].get("message", error_message)
            except Exception:
                error_message = finalize_response.text
            raise ValueError(f"Finalize error ({finalize_response.status_code}): {error_message}")

        return presign_data, finalize_response.json()

    async def _upload_file_direct(
        self,
        file_content: bytes,
        filename: str,
        mime_type: str,
    ) -> Dict[str, Any]:
        """Upload a file using presigned URL. Returns finalize result."""
        _, finalize_data = await self._presign_and_upload(
            file_content=file_content,
            filename=filename,
            mime_type=mime_type,
        )
        return finalize_data

    def _prepare_upload(
        self,
        file: Union[str, Path, "pd.DataFrame"],
        filename: Optional[str] = None,
        title: Optional[str] = None,
        log: bool = False,
    ) -> Tuple[bytes, str, str, float]:
        if pd is not None and isinstance(file, pd.DataFrame):
            import io

            if log:
                self._log(f"Preparing DataFrame ({len(file)} rows, {len(file.columns)} columns)...")
            buffer = io.BytesIO()
            file.to_csv(buffer, index=False)
            buffer.seek(0)
            file_content = buffer.getvalue()
            resolved_filename = filename or ((title + ".csv") if title else "dataset.csv")
            mime_type = "text/csv"
        else:
            file_path = Path(file)
            if not file_path.exists():
                raise FileNotFoundError(f"File not found: {file_path}")
            if log:
                self._log(f"Reading file: {file_path.name}...")
            file_content = file_path.read_bytes()
            resolved_filename = filename or file_path.name
            _MIME_TYPES = {
                ".csv": "text/csv",
                ".tsv": "text/tab-separated-values",
                ".json": "application/json",
                ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                ".xls": "application/vnd.ms-excel",
                ".parquet": "application/vnd.apache.parquet",
                ".arff": "text/plain",
                ".feather": "application/octet-stream",
            }
            mime_type = _MIME_TYPES.get(file_path.suffix.lower(), "text/csv")

        file_size_mb = len(file_content) / (1024 * 1024)
        if log:
            self._log(f"  File size: {file_size_mb:.2f} MB")
        return file_content, resolved_filename, mime_type, file_size_mb

    # ------------------------------------------------------------------
    # File upload
    # ------------------------------------------------------------------

    async def upload_file(
        self,
        file: Union[str, Path, "pd.DataFrame"],
        title: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Upload a file and return the server's parsed metadata.

        Use this when you need to inspect the server's column list before
        creating a run (e.g. to choose a target column).  Pass the result
        to ``run_async(upload_result=...)`` to avoid re-uploading.

        Returns:
            Dict with ``file`` (key, name, size, fileHash) and ``columns``
            (list of dicts with ``name``, ``type``, ``enabled``).
        """
        file_content, filename, mime_type, _ = self._prepare_upload(
            file=file,
            title=title,
            log=True,
        )
        self._log("  Uploading to storage...")
        result = await self._upload_file_direct(file_content, filename, mime_type)

        if not result.get("ok"):
            errors = result.get("issues", {}).get("errors", [])
            error_msg = errors[0].get("message") if errors else "Upload failed"
            raise ValueError(f"Upload failed: {error_msg}")

        return {
            "file": result["file"],
            "columns": result.get("columns", []),
            "rowCount": result.get("rowCount"),
        }

    # ------------------------------------------------------------------
    # run_async / run — full-control analysis submission
    # ------------------------------------------------------------------

    async def run_async(
        self,
        file: Union[str, Path, "pd.DataFrame"],
        target_column: str,
        depth_iterations: int = 1,
        title: Optional[str] = None,
        description: Optional[str] = None,
        column_descriptions: Optional[Dict[str, str]] = None,
        excluded_columns: Optional[List[str]] = None,
        task: Optional[str] = None,
        visibility: str = "public",
        timeseries_groups: Optional[List[Dict[str, Any]]] = None,
        target_column_override: Optional[str] = None,
        author: Optional[str] = None,
        source_url: Optional[str] = None,
        wait: bool = False,
        wait_timeout: Optional[float] = None,
        upload_result: Optional[Dict[str, Any]] = None,
        **kwargs,
    ) -> EngineResult:
        """Run analysis on a dataset (async).

        For most use cases, prefer ``discover()`` which wraps this with
        ``wait=True`` and a cleaner parameter set.

        Args:
            file: File path, Path object, or pandas DataFrame.
            target_column: Name of the target column.
            depth_iterations: Analysis depth (default 1). Public runs are always depth 1.
            title: Optional dataset title.
            description: Optional dataset description.
            column_descriptions: Dict mapping column names to descriptions.
            excluded_columns: Column names to exclude from analysis.
            task: Task type (auto-detected if None).
            visibility: "public" (free) or "private" (costs credits).
            wait: If True, wait for completion and return full results.
            wait_timeout: Max seconds to wait (only if wait=True).
            upload_result: Pre-uploaded file data from ``upload_file()``.
                If provided, skips the upload step.

        Returns:
            EngineResult with run_id and (if wait=True) complete results.
        """
        # Public runs are always depth=1 (server enforces this)
        if depth_iterations > 1 and visibility == "public":
            self._log(
                "Public runs use depth=1. Upgrade your plan at disco.leap-labs.com/subscribe "
                "to see more patterns and get priority processing."
            )
            depth_iterations = 1

        if upload_result:
            uploaded_file = upload_result["file"]
            columns = upload_result.get("columns", [])
            self._log(
                f"Creating run from pre-uploaded file (depth: {depth_iterations}, target: {target_column})..."
            )
        else:
            file_content, filename, mime_type, _ = self._prepare_upload(
                file=file,
                title=title,
                log=True,
            )
            self._log("Uploading file and creating run...")

            # Step 1: Upload file
            self._log("  Uploading to storage...")
            raw_result = await self._upload_file_direct(file_content, filename, mime_type)

            if not raw_result.get("ok"):
                errors = raw_result.get("issues", {}).get("errors", [])
                error_msg = errors[0].get("message") if errors else "Upload failed"
                raise ValueError(f"Upload failed: {error_msg}")

            uploaded_file = raw_result["file"]
            columns = raw_result.get("columns", [])

        # Step 2: Create the run
        self._log("  Creating analysis run...")
        dashboard_client = await self._get_dashboard_client()

        report_payload: Dict[str, Any] = {
            "file": {
                "key": uploaded_file["key"],
                "name": uploaded_file["name"],
                "size": uploaded_file["size"],
                "fileHash": uploaded_file["fileHash"],
            },
            "columns": columns,
            "targetColumn": target_column,
            "depthIterations": depth_iterations,
            "isPublic": visibility == "public",
        }

        if title:
            report_payload["title"] = title
        if description:
            report_payload["description"] = description
        if author:
            report_payload["author"] = author
        if source_url:
            report_payload["sourceUrl"] = source_url
        if column_descriptions:
            for col in report_payload["columns"]:
                if col["name"] in column_descriptions:
                    col["description"] = column_descriptions[col["name"]]
        if excluded_columns:
            for col in report_payload["columns"]:
                if col["name"] in excluded_columns and col["name"] != target_column:
                    col["enabled"] = False
        if timeseries_groups:
            report_payload["columnGroups"] = timeseries_groups
        response = await dashboard_client.post(
            "/api/reports/create-from-upload",
            json=report_payload,
        )

        if response.status_code >= 400:
            try:
                error_data = response.json()
                error_message = error_data.get("error", response.text)
            except Exception:
                error_message = response.text

            if "insufficient credits" in error_message.lower():
                raise InsufficientCreditsError(message=f"API error: {error_message}")

            raise ValueError(f"API error ({response.status_code}): {error_message}")

        result_data = response.json()

        # Handle duplicates
        if result_data.get("duplicate"):
            report_id = result_data.get("report_id")
            run_id = result_data.get("run_id")
            if not report_id or not run_id:
                raise ValueError("Duplicate report found but missing report_id or run_id")

            self._log(f"Duplicate report found (run_id: {run_id})")
            progress_url = f"{self.dashboard_url}/reports/new/{run_id}/processing"
            self._log(f"View progress: {progress_url}")

            if wait:
                return await self.get_results(run_id)
            return EngineResult(run_id=run_id, status="completed", report_id=report_id)

        run_id = result_data["run_id"]
        self._log(f"Run created: {run_id}")

        progress_url = f"{self.dashboard_url}/reports/new/{run_id}/processing"
        self._log(f"View progress: {progress_url}")

        if wait:
            return await self.wait_for_completion(run_id, timeout=wait_timeout)

        return EngineResult(run_id=run_id, status="pending")

    def run(
        self,
        file: Union[str, Path, "pd.DataFrame"],
        target_column: str,
        depth_iterations: int = 1,
        title: Optional[str] = None,
        description: Optional[str] = None,
        column_descriptions: Optional[Dict[str, str]] = None,
        excluded_columns: Optional[List[str]] = None,
        task: Optional[str] = None,
        visibility: str = "public",
        timeseries_groups: Optional[List[Dict[str, Any]]] = None,
        target_column_override: Optional[str] = None,
        author: Optional[str] = None,
        source_url: Optional[str] = None,
        wait: bool = False,
        wait_timeout: Optional[float] = None,
        **kwargs,
    ) -> EngineResult:
        """Run analysis on a dataset (synchronous wrapper around run_async)."""
        return self._run_sync(
            self.run_async(
                file,
                target_column,
                depth_iterations,
                title=title,
                description=description,
                column_descriptions=column_descriptions,
                excluded_columns=excluded_columns,
                task=task,
                visibility=visibility,
                timeseries_groups=timeseries_groups,
                target_column_override=target_column_override,
                author=author,
                source_url=source_url,
                wait=wait,
                wait_timeout=wait_timeout,
                **kwargs,
            )
        )

    # ------------------------------------------------------------------
    # Sync helper
    # ------------------------------------------------------------------

    @staticmethod
    def _run_sync(coro):
        """Run a coroutine synchronously, handling Jupyter event loops."""
        try:
            return asyncio.run(coro)
        except RuntimeError as e:
            if "cannot be called from a running event loop" in str(e).lower():
                try:
                    import nest_asyncio

                    nest_asyncio.apply()
                    return asyncio.run(coro)
                except ImportError:
                    raise RuntimeError(
                        "Cannot run synchronously in a Jupyter notebook. "
                        "Use 'await engine.discover(...)' instead, or install "
                        "nest_asyncio (pip install nest-asyncio)."
                    ) from e
            raise

    # ------------------------------------------------------------------
    # Result parsing
    # ------------------------------------------------------------------

    def _parse_analysis_result(self, data: Dict[str, Any]) -> EngineResult:
        """Parse API response into EngineResult dataclass."""
        summary = None
        if data.get("summary"):
            summary = self._parse_summary(data["summary"])

        patterns = []
        for p in data.get("patterns", []):
            patterns.append(
                Pattern(
                    id=p["id"],
                    task=p.get("task", "regression"),
                    target_column=p.get("target_column", ""),
                    target_change_direction=p.get("target_change_direction", "max"),
                    p_value=p.get("p_value", 0),
                    conditions=p.get("conditions", []),
                    abs_target_change=p.get("abs_target_change", 0),
                    support_count=p.get("support_count", 0),
                    support_percentage=p.get("support_percentage", 0),
                    novelty_type=p.get("novelty_type", "confirmatory"),
                    target_score=p.get("target_score", 0),
                    target_class=p.get("target_class"),
                    target_mean=p.get("target_mean"),
                    target_std=p.get("target_std"),
                    description=p.get("description", ""),
                    novelty_explanation=p.get("novelty_explanation", ""),
                    citations=p.get("citations", []),
                    p_value_raw=p.get("p_value_raw"),
                )
            )

        columns = []
        for c in data.get("columns", []):
            columns.append(
                Column(
                    id=c["id"],
                    name=c["name"],
                    display_name=c.get("display_name", c["name"]),
                    type=c.get("type", "continuous"),
                    data_type=c.get("data_type", "float"),
                    enabled=c.get("enabled", True),
                    description=c.get("description"),
                    mean=c.get("mean"),
                    median=c.get("median"),
                    std=c.get("std"),
                    min=c.get("min"),
                    max=c.get("max"),
                    iqr_min=c.get("iqr_min"),
                    iqr_max=c.get("iqr_max"),
                    mode=c.get("mode"),
                    approx_unique=c.get("approx_unique"),
                    null_percentage=c.get("null_percentage"),
                    feature_importance_score=c.get("feature_importance_score"),
                )
            )

        correlation_matrix = []
        for entry in data.get("correlation_matrix", []):
            correlation_matrix.append(
                CorrelationEntry(
                    feature_x=entry["feature_x"],
                    feature_y=entry["feature_y"],
                    value=entry["value"],
                )
            )

        feature_importance = None
        if data.get("feature_importance"):
            fi = data["feature_importance"]
            scores = [
                FeatureImportanceScore(feature=s["feature"], score=s["score"])
                for s in fi.get("scores", [])
            ]
            feature_importance = FeatureImportance(
                kind=fi.get("kind", "global"),
                baseline=fi.get("baseline", 0),
                scores=scores,
            )

        # Build report URL if we have a report_id
        report_url = data.get("report_url")
        if not report_url and data.get("report_id"):
            report_url = f"{self.dashboard_url}/reports/{data['report_id']}"

        hints = data.get("hints", [])
        hidden_deep_count = data.get("hidden_deep_count", 0)
        hidden_deep_novel_count = data.get("hidden_deep_novel_count", 0)

        return EngineResult(
            run_id=data["run_id"],
            report_id=data.get("report_id"),
            status=data.get("status", "unknown"),
            dataset_title=data.get("dataset_title"),
            dataset_description=data.get("dataset_description"),
            total_rows=data.get("total_rows"),
            target_column=data.get("target_column"),
            task=data.get("task"),
            summary=summary,
            patterns=patterns,
            columns=columns,
            correlation_matrix=correlation_matrix,
            feature_importance=feature_importance,
            job_id=data.get("job_id"),
            job_status=data.get("job_status"),
            queue_position=data.get("queue_position"),
            current_step=data.get("current_step", {}).get("status")
            if data.get("current_step")
            else None,
            current_step_message=data.get("current_step", {}).get("message")
            if data.get("current_step")
            else None,
            estimated_seconds=data.get("estimated_seconds"),
            estimated_wait_seconds=data.get("estimated_wait_seconds"),
            error_message=data.get("error_message"),
            report_url=report_url,
            hints=hints,
            hidden_deep_count=hidden_deep_count,
            hidden_deep_novel_count=hidden_deep_novel_count,
        )

    def _parse_summary(self, data: Dict[str, Any]) -> Summary:
        """Parse summary data into Summary dataclass."""
        return Summary(
            overview=data.get("overview", ""),
            key_insights=data.get("key_insights", []),
            novel_patterns=PatternGroup(
                pattern_ids=data.get("novel_patterns", {}).get("pattern_ids", []),
                explanation=data.get("novel_patterns", {}).get("explanation", ""),
            ),
            selected_pattern_id=data.get("selected_pattern_id"),
        )
