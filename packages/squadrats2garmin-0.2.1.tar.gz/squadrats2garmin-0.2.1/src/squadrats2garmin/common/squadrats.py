import itertools
import logging
import xml.etree.ElementTree as ET
from operator import attrgetter

import requests
import shapely
from typing import Protocol

from requests.adapters import HTTPAdapter
from urllib3.util import Retry

from squadrats2garmin.common import util
from squadrats2garmin.common.job import Job
from squadrats2garmin.common.osm import Node, Way
from squadrats2garmin.common.tile import Zoom
from squadrats2garmin.common.timer import timeit

TAGS_WAY = {'name': 'grid'}

logger = logging.getLogger(__name__)

type TileRange = tuple[int, int]
type TileBars = list[TileRange]
type TileMap = dict[int, TileBars]


class SquadratsClient:
    def __init__(self):
        self._session = requests.Session()
        self._session.headers.update({
            'User-Agent': 'SquadratsClient/1.0'
        })

        retry = Retry(
            total=5,
            backoff_factor=2,
            status_forcelist=[429, 500, 502, 503, 504],
        )
        adapter = HTTPAdapter(max_retries=retry)
        self._session.mount('https://', adapter)

        self._timeout = 10

    def _get_geojson(self, user_id: str) -> dict:
        response = self._session.get(f'https://mainframe-api.squadrats.com/anonymous/squadrants/{user_id}/geojson',
                                     timeout=self._timeout)
        response.raise_for_status()
        return response.json()

    def get_trophies(self, user_id: str):
        with timeit(msg=f"Fetching trophies for user {user_id}"):
            geojson_info = self._get_geojson(user_id)

            response = self._session.get(geojson_info['url'], timeout=self._timeout)
            response.raise_for_status()
            return response.json()


class TileMapGenerator(Protocol):
    def generate_rows(self, poly: shapely.MultiPolygon, zoom: Zoom) -> TileMap:
        """

        :param poly:
        :param zoom:
        :return:
        {
            y_1 -> [(x_1_1_start, x_1_1_end)],
            y_2 -> [(x_2_1_start, x_2_1_end), (x_2_2_start, x_2_2_end)],
            ...
        }
        """
        ...

    def generate_cols(self, poly: shapely.MultiPolygon, zoom: Zoom) -> TileMap:
        """

        :param poly:
        :param zoom:
        :return:
        {
            x_1 -> [(y_1_1_start, y_1_1_end)],
            x_2 -> [(y_2_1_start, y_2_1_end), (y_2_2_start, y_2_2_end)],
            ...
        }
        """
        ...


class ShapelyTileMapGenerator(TileMapGenerator):
    """
    Generate tiles for the rectangular area defined by the polygon bounding box
    """

    def __init__(self):
        self.__logger = logging.getLogger(__name__ + "." + type(self).__name__)

    def generate_rows(self, poly: shapely.MultiPolygon, zoom: Zoom) -> TileMap:
        tiles = {}

        (bounds_w, bounds_s, bounds_e, bounds_n) = poly.bounds
        (y_min, y_max) = [zoom.y(y) for y in [bounds_n, bounds_s]]

        for y in range(y_min, y_max + 1):
            ranges = []
            result = shapely.clip_by_rect(geometry=poly, xmin=bounds_w, ymin=zoom.lat(y + 1), xmax=bounds_e,
                                          ymax=zoom.lat(y))
            if result.is_empty: continue

            if isinstance(result, shapely.Polygon):
                ranges.append(self._clipped_polygon_to_x_range(poly=result, zoom=zoom))
            elif isinstance(result, shapely.MultiPolygon):
                for part in result.geoms:
                    ranges.append(self._clipped_polygon_to_x_range(poly=part, zoom=zoom))
            else:
                self.__logger.warning("type %s not supported", type(result))

            tiles[y] = util.merge_ranges_end_inclusive(ranges)

        return tiles

    def generate_cols(self, poly: shapely.MultiPolygon, zoom: Zoom) -> TileMap:
        tiles = {}

        (bounds_w, bounds_s, bounds_e, bounds_n) = poly.bounds
        (x_min, x_max) = [zoom.x(lon) for lon in [bounds_w, bounds_e]]

        for x in range(x_min, x_max + 1):
            ranges = []
            result = shapely.clip_by_rect(geometry=poly, xmin=zoom.lon(x), ymin=bounds_s, xmax=zoom.lon(x + 1),
                                          ymax=bounds_n)
            if result.is_empty: continue

            if isinstance(result, shapely.Polygon):
                ranges.append(self._clipped_polygon_to_y_range(poly=result, zoom=zoom))
            elif isinstance(result, shapely.MultiPolygon):
                for part in result.geoms:
                    ranges.append(self._clipped_polygon_to_y_range(poly=part, zoom=zoom))
            else:
                self.__logger.warning("type %s not supported", type(result))

            tiles[x] = util.merge_ranges_end_inclusive(ranges)

        return tiles

    def _clipped_polygon_to_x_range(self, poly: shapely.Polygon, zoom: Zoom) -> TileRange:
        (clip_w, clip_s, clip_e, clip_n) = poly.bounds
        (x_min, x_max) = [zoom.x(x) for x in [clip_w, clip_e]]
        return x_min, x_max

    def _clipped_polygon_to_y_range(self, poly: shapely.Polygon, zoom: Zoom) -> TileRange:
        (clip_w, clip_s, clip_e, clip_n) = poly.bounds
        (y_min, y_max) = [zoom.y(lat) for lat in [clip_n, clip_s]]
        return y_min, y_max


def generate_grid(poly: shapely.MultiPolygon, job: Job, generator: TileMapGenerator = ShapelyTileMapGenerator()) -> \
list[Way]:
    ways: list[Way] = []
    # generate horizontal ranges
    row_map = generator.generate_rows(poly=poly, zoom=job.zoom)
    ranges_by_y = {
        y: util.make_ranges_end_inclusive(rr)
        for y, rr in row_map.items()
    }
    for y in sorted(ranges_by_y.keys()):
        if y - 1 not in ranges_by_y:
            # first row or a gap - generate top edge
            ways.extend(_create_horizontal_ways_for_ranges(y=y, tiles=ranges_by_y[y], job=job))

        if y + 1 in ranges_by_y:
            # generate bottom edge between current and next row
            ways.extend(
                _create_horizontal_ways_for_ranges(
                    y=y + 1,
                    tiles=util.merge_ranges(itertools.chain(ranges_by_y[y], ranges_by_y[y + 1])),
                    job=job))
        else:
            # generate bottom edge when next row is empty
            ways.extend(_create_horizontal_ways_for_ranges(y=y + 1, tiles=ranges_by_y[y], job=job))

    # generate vertical ranges
    col_map = generator.generate_cols(poly=poly, zoom=job.zoom)
    ranges_by_x = {
        x: util.make_ranges_end_inclusive(rr)
        for x, rr in col_map.items()
    }
    for x in sorted(ranges_by_x.keys()):
        if x - 1 not in ranges_by_x:
            # first column or a gap - generate left edge
            ways.extend(_create_vertical_ways_for_ranges(x=x, tiles=ranges_by_x[x], job=job))

        if x + 1 in ranges_by_x:
            # generate right edge between current and next column
            ways.extend(
                _create_vertical_ways_for_ranges(
                    x=x + 1,
                    tiles=util.merge_ranges(itertools.chain(ranges_by_x[x], ranges_by_x[x + 1])),
                    job=job)
            )
        else:
            # generate right edge when next column is empty
            ways.extend(_create_vertical_ways_for_ranges(x=x + 1, tiles=ranges_by_x[x], job=job))

    return ways


def _create_horizontal_ways_for_ranges(y: int, tiles: TileBars, job: Job) -> list[Way]:
    return [
        Way(
            way_id=job.next_id(),
            nodes=[_osm_node((x, y), job) for x in row],
            tags=TAGS_WAY | {'zoom': job.zoom.zoom}
        )
        for row in tiles
    ]


def _create_vertical_ways_for_ranges(x: int, tiles: TileBars, job: Job) -> list[Way]:
    return [
        Way(
            way_id=job.next_id(),
            nodes=[_osm_node((x, y), job) for y in column],
            tags=TAGS_WAY | {'zoom': job.zoom.zoom}
        )
        for column in tiles
    ]


def _osm_node(tile: tuple[int, int], job: Job) -> Node:
    return Node(node_id=job.next_id(), geom=job.zoom.to_point(tile))


def generate_osm(job: Job):
    pretty_print = False
    """Generate a single OSM file for a job"""
    logger.info('Generating OSM: %s -> %s', job, job.osm_file)

    with timeit(f"{job}: generate_grid"):
        ways = generate_grid(poly=job.region.coords, job=job)

    logger.debug('%s: %d ways', job, len(ways))

    with timeit(f"{job}: collect unique nodes"):
        unique_nodes = {n for w in ways for n in w.nodes}

    logger.debug("%s: %d unique nodes", job, len(unique_nodes))

    with timeit(f"{job}: build OSM document"):
        document = ET.Element("osm", {"version": '0.6'})
        if pretty_print:
            document.extend(n.to_xml() for n in sorted(unique_nodes, key=attrgetter('element_id')))
            document.extend(w.to_xml() for w in sorted(ways, key=attrgetter('element_id')))
            ET.indent(document)
        else:
            document.extend(n.to_xml() for n in unique_nodes)
            document.extend(w.to_xml() for w in ways)

    with timeit(f'{job}: write OSM document {job.osm_file}'):
        job.osm_file.parent.mkdir(parents=True, exist_ok=True)
        ET.ElementTree(document).write(job.osm_file, encoding='utf-8', xml_declaration=True)
