"""Result types for Golpo SDK API methods."""

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class GenerationResult:
    """Result of create_podcast or create_video (generated content URL, script, and job ID).

    Attributes:
        url: The URL of the generated podcast or video.
        script: The script used for the podcast or video.
        video_id: The job/video ID returned by the backend (for polling and edit_video).
    """

    url: str
    script: str
    video_id: str


@dataclass(frozen=True)
class VideoEditResult:
    """Result of edit_video (edited or combined video URL and job ID).

    Supports both attribute access (result.video_url) and dict-like access
    (result["video_url"]) for backward compatibility.

    Attributes:
        video_url: URL of the edited (or combined) video.
        job_id: The job ID for the edit operation.
    """

    video_url: str
    job_id: str

    def __getitem__(self, key: str) -> str:
        """Allow dict-like access for backward compatibility."""
        if key == "video_url":
            return self.video_url
        if key == "job_id":
            return self.job_id
        raise KeyError(key)

    def get(self, key: str, default: Any = None) -> Any:
        """Dict-like .get() for backward compatibility."""
        try:
            return self[key]
        except KeyError:
            return default


@dataclass(frozen=True)
class CombinedVideoResult:
    """Result of combine_videos (URL of the combined video).

    Attributes:
        url: URL of the combined video.
    """

    url: str
