"""Type stub for golpo.models."""

from typing import Any

class GenerationResult:
    url: str
    script: str
    video_id: str
    def __init__(self, url: str, script: str, video_id: str) -> None: ...

class VideoEditResult:
    video_url: str
    job_id: str
    def __init__(self, video_url: str, job_id: str) -> None: ...
    def __getitem__(self, key: str) -> str: ...
    def get(self, key: str, default: Any = None) -> Any: ...

class CombinedVideoResult:
    url: str
    def __init__(self, url: str) -> None: ...
