"""
Wrapper around the eventloop that gives some time to the Tkinter GUI to process
events when it's loaded and while we are waiting for input at the REPL. This
way we don't block the UI of for instance ``turtle`` and other Tk libraries.

(Normally Tkinter registeres it's callbacks in ``PyOS_InputHook`` to integrate
in readline. ``prompt-toolkit`` doesn't understand that input hook, but this
will fix it for Tk.)
"""
from rp.prompt_toolkit.shortcuts import create_eventloop as _create_eventloop
import sys
import time

__all__ = (
    'create_eventloop',
)


def _inputhook_tk(inputhook_context):
    """
    Inputhook for Tk.
    Run the Tk eventloop until prompt-toolkit needs to process the next input.
    """
    # Get the current TK application.
    import _tkinter  # Keep this imports inline!
    from six.moves import tkinter
    root = tkinter._default_root

    def wait_using_filehandler():
        """
        Run the TK eventloop until the file handler that we got from the
        inputhook becomes readable.
        """
        # Add a handler that sets the stop flag when `prompt-toolkit` has input
        # to process.
        stop = [False]
        def done(*a):
            stop[0] = True

        root.createfilehandler(inputhook_context.fileno(), _tkinter.READABLE, done)

        # Run the TK event loop as long as we don't receive input.
        while root.dooneevent(_tkinter.ALL_EVENTS):
            if stop[0]:
                break

        root.deletefilehandler(inputhook_context.fileno())

    def wait_using_polling():
        """
        Windows TK doesn't support 'createfilehandler'.
        So, run the TK eventloop and poll until input is ready.
        """
        while not inputhook_context.input_is_ready():
            while root.dooneevent(_tkinter.ALL_EVENTS | _tkinter.DONT_WAIT):
                 pass
            # Sleep to make the CPU idle, but not too long, so that the UI
            # stays responsive.
            time.sleep(.01)

    if root is not None:
        if hasattr(root, 'createfilehandler'):
            wait_using_filehandler()
        else:
            wait_using_polling()


def _inputhook(inputhook_context):
    # Only call the real input hook when the 'Tkinter' library was loaded.
    if 'Tkinter' in sys.modules or 'tkinter' in sys.modules:
        _inputhook_tk(inputhook_context)


def create_eventloop():
    return _create_eventloop(inputhook=_inputhook)
