"""Tests for SQLite cache."""

import time
from pathlib import Path

import pytest

from syndatalab.cache.sqlite_cache import SQLiteCache


class TestSQLiteCache:
    def test_put_and_get(self, tmp_dir: Path):
        cache = SQLiteCache(tmp_dir / "cache", ttl_days=30)
        key = SQLiteCache.make_key("model", [{"role": "user", "content": "hello"}])

        cache.put(key, "response text", 10, 20, "model", "openai")
        entry = cache.get(key)

        assert entry is not None
        assert entry.response_text == "response text"
        assert entry.prompt_tokens == 10
        assert entry.completion_tokens == 20
        cache.close()

    def test_cache_miss(self, tmp_dir: Path):
        cache = SQLiteCache(tmp_dir / "cache", ttl_days=30)
        entry = cache.get("nonexistent_key")
        assert entry is None
        cache.close()

    def test_ttl_expiry(self, tmp_dir: Path):
        # Very short TTL to test expiration
        cache = SQLiteCache(tmp_dir / "cache", ttl_days=30)
        key = "test_key"
        cache.put(key, "text", 10, 20)

        # Manually set expires_at to the past to simulate expiration
        cache._conn.execute(
            "UPDATE cache SET expires_at = ? WHERE key = ?",
            (time.time() - 1, key),
        )
        cache._conn.commit()

        entry = cache.get(key)
        assert entry is None
        cache.close()

    def test_make_key_deterministic(self):
        key1 = SQLiteCache.make_key("model", [{"role": "user", "content": "hello"}])
        key2 = SQLiteCache.make_key("model", [{"role": "user", "content": "hello"}])
        key3 = SQLiteCache.make_key("model", [{"role": "user", "content": "world"}])
        assert key1 == key2
        assert key1 != key3

    def test_stats(self, tmp_dir: Path):
        cache = SQLiteCache(tmp_dir / "cache", ttl_days=30)
        cache.put("k1", "text1", 10, 20)
        cache.put("k2", "text2", 30, 40)

        stats = cache.stats()
        assert stats["entries"] == 2
        assert stats["size_bytes"] > 0
        cache.close()

    def test_clear(self, tmp_dir: Path):
        cache = SQLiteCache(tmp_dir / "cache", ttl_days=30)
        cache.put("k1", "text1", 10, 20)
        cache.put("k2", "text2", 30, 40)

        count = cache.clear()
        assert count == 2
        assert cache.stats()["entries"] == 0
        cache.close()

    def test_export(self, tmp_dir: Path):
        cache = SQLiteCache(tmp_dir / "cache", ttl_days=30)
        cache.put("k1", "text1", 10, 20, "model1", "openai")
        cache.put("k2", "text2", 30, 40, "model2", "anthropic")

        entries = cache.export_entries()
        assert len(entries) == 2
        assert entries[0]["key"] == "k1"
        assert entries[1]["response_text"] == "text2"
        cache.close()
