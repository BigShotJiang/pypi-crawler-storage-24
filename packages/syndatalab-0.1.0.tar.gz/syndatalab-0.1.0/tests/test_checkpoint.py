"""Tests for checkpoint/resume system."""

from pathlib import Path

import pytest

from syndatalab.checkpoint.manager import (
    CheckpointManager,
    compute_run_id,
    dataset_fingerprint,
)


class TestCheckpointManager:
    def test_save_and_load(self, tmp_dir: Path):
        mgr = CheckpointManager(tmp_dir, "test_run_1")
        mgr.save_row(0, {"status": "success", "parsed_rows": [{"a": 1}]})
        mgr.save_row(2, {"status": "success", "parsed_rows": [{"a": 3}]})

        # Load in a new manager
        mgr2 = CheckpointManager(tmp_dir, "test_run_1")
        completed = mgr2.load_existing()

        assert 0 in completed
        assert 2 in completed
        assert 1 not in completed
        assert mgr2.completed_count == 2

    def test_is_completed(self, tmp_dir: Path):
        mgr = CheckpointManager(tmp_dir, "test_run_2")
        mgr.save_row(5, {"status": "success"})

        assert mgr.is_completed(5)
        assert not mgr.is_completed(3)

    def test_cleanup(self, tmp_dir: Path):
        mgr = CheckpointManager(tmp_dir, "test_run_3")
        mgr.save_row(0, {"status": "success"})
        assert mgr.checkpoint_path.exists()

        mgr.cleanup()
        assert not mgr.checkpoint_path.exists()

    def test_empty_checkpoint(self, tmp_dir: Path):
        mgr = CheckpointManager(tmp_dir, "test_run_4")
        completed = mgr.load_existing()
        assert len(completed) == 0


class TestRunId:
    def test_deterministic(self):
        id1 = compute_run_id("TestLLM", "gpt-4", "fp123")
        id2 = compute_run_id("TestLLM", "gpt-4", "fp123")
        assert id1 == id2

    def test_different_params(self):
        id1 = compute_run_id("TestLLM", "gpt-4", "fp123")
        id2 = compute_run_id("TestLLM", "gpt-4", "fp456")
        assert id1 != id2

    def test_dataset_fingerprint_deterministic(self):
        ds = [{"a": 1}, {"b": 2}]
        fp1 = dataset_fingerprint(ds)
        fp2 = dataset_fingerprint(ds)
        assert fp1 == fp2

    def test_dataset_fingerprint_different(self):
        fp1 = dataset_fingerprint([{"a": 1}])
        fp2 = dataset_fingerprint([{"a": 2}])
        assert fp1 != fp2
