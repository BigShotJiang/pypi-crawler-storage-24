"""Tests for rate limiter."""

import asyncio
import time

import pytest

from syndatalab.rate_limit.limiter import RateLimiter, TokenBucket


class TestTokenBucket:
    @pytest.mark.asyncio
    async def test_acquire_within_capacity(self):
        bucket = TokenBucket(capacity=10, refill_rate=10)
        wait = await bucket.acquire(5)
        assert wait == 0.0

    @pytest.mark.asyncio
    async def test_acquire_exceeds_capacity(self):
        bucket = TokenBucket(capacity=5, refill_rate=5)
        await bucket.acquire(5)  # Drain the bucket
        wait = await bucket.acquire(3)
        assert wait > 0


class TestRateLimiter:
    @pytest.mark.asyncio
    async def test_acquire_basic(self):
        limiter = RateLimiter(max_requests_per_minute=1000, max_tokens_per_minute=100_000)
        # Should not block with high limits
        start = time.monotonic()
        await limiter.acquire(100)
        elapsed = time.monotonic() - start
        assert elapsed < 1.0

    @pytest.mark.asyncio
    async def test_report_rate_limit(self):
        limiter = RateLimiter(max_requests_per_minute=1000, max_tokens_per_minute=100_000)
        await limiter.report_rate_limit(retry_after=0.1)
        # Next acquire should wait
        start = time.monotonic()
        await limiter.acquire(1)
        elapsed = time.monotonic() - start
        assert elapsed >= 0.05  # At least some delay

    def test_for_provider(self):
        limiter = RateLimiter.for_provider("openai")
        assert limiter.rpm_bucket.capacity == 500
        assert limiter.tpm_bucket.capacity == 200_000

        limiter2 = RateLimiter.for_provider("ollama")
        assert limiter2.rpm_bucket.capacity == 10_000
