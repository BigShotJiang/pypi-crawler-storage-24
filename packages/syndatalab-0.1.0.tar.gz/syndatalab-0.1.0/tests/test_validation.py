"""Tests for layered output validation."""

import pytest
from pydantic import BaseModel

from syndatalab.core.exceptions import ValidationError
from syndatalab.stats.models import ValidationStats
from syndatalab.validation.validator import (
    build_repair_messages,
    validate_response,
)


class SimpleModel(BaseModel):
    name: str
    age: int


class TestValidation:
    def test_plain_text_no_format(self):
        result = validate_response("hello world", None)
        assert result == "hello world"

    def test_valid_json(self):
        result = validate_response('{"name": "Alice", "age": 30}', SimpleModel)
        assert isinstance(result, SimpleModel)
        assert result.name == "Alice"
        assert result.age == 30

    def test_json_in_markdown(self):
        text = '```json\n{"name": "Bob", "age": 25}\n```'
        result = validate_response(text, SimpleModel)
        assert isinstance(result, SimpleModel)
        assert result.name == "Bob"

    def test_json_with_prose(self):
        text = 'Here is the result:\n{"name": "Charlie", "age": 35}\nHope this helps!'
        result = validate_response(text, SimpleModel)
        assert isinstance(result, SimpleModel)
        assert result.name == "Charlie"

    def test_invalid_json_raises(self):
        with pytest.raises(ValidationError):
            validate_response("not json at all", SimpleModel)

    def test_wrong_schema_raises(self):
        with pytest.raises(ValidationError):
            validate_response('{"foo": "bar"}', SimpleModel)

    def test_stats_tracking(self):
        stats = ValidationStats()
        validate_response('{"name": "Test", "age": 1}', SimpleModel, stats)
        assert stats.layer1_success == 1
        assert stats.layer3_success == 1

    def test_type_coercion(self):
        result = validate_response('{"name": "Alice", "age": "30"}', SimpleModel)
        assert isinstance(result, SimpleModel)
        assert result.age == 30


class TestBuildRepairMessages:
    def test_builds_correct_messages(self):
        original = [{"role": "user", "content": "Generate something"}]
        messages = build_repair_messages(original, '{"bad": "json"}', "Missing field: name")

        assert len(messages) == 3
        assert messages[0]["role"] == "user"
        assert messages[1]["role"] == "assistant"
        assert messages[1]["content"] == '{"bad": "json"}'
        assert messages[2]["role"] == "user"
        assert "Missing field: name" in messages[2]["content"]
