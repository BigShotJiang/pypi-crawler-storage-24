"""Tests for provider registry and failover."""

import pytest

from syndatalab.core.exceptions import ConfigError, ProviderUnavailableError
from syndatalab.providers.registry import create_provider, detect_provider_name


class TestProviderDetection:
    def test_openai_detection(self):
        assert detect_provider_name("gpt-4o-mini") == "openai"
        assert detect_provider_name("gpt-3.5-turbo") == "openai"

    def test_anthropic_detection(self):
        assert detect_provider_name("claude-3-5-sonnet-20241022") == "anthropic"
        assert detect_provider_name("claude-3-opus-20240229") == "anthropic"

    def test_ollama_detection(self):
        assert detect_provider_name("ollama/llama3") == "ollama"

    def test_unknown_model(self):
        assert detect_provider_name("some-unknown-model") is None

    def test_invalid_backend(self):
        with pytest.raises(ConfigError):
            create_provider("model", backend="nonexistent")


class TestFailoverProvider:
    @pytest.mark.asyncio
    async def test_failover_on_error(self):
        from tests.conftest import MockProvider
        from syndatalab.providers.failover import FailoverProvider

        primary = MockProvider(fail_on={0}, fail_error=ProviderUnavailableError("down", "mock"))
        fallback = MockProvider(responses=["fallback response"])

        failover = FailoverProvider(primary, [fallback])
        result = await failover.generate([{"role": "user", "content": "test"}])
        assert result.text == "fallback response"

    @pytest.mark.asyncio
    async def test_primary_succeeds(self):
        from tests.conftest import MockProvider
        from syndatalab.providers.failover import FailoverProvider

        primary = MockProvider(responses=["primary response"])
        fallback = MockProvider(responses=["fallback response"])

        failover = FailoverProvider(primary, [fallback])
        result = await failover.generate([{"role": "user", "content": "test"}])
        assert result.text == "primary response"

    @pytest.mark.asyncio
    async def test_all_fail(self):
        from tests.conftest import MockProvider
        from syndatalab.providers.failover import FailoverProvider

        p1 = MockProvider(fail_on={0}, fail_error=ProviderUnavailableError("down", "p1"))
        p2 = MockProvider(fail_on={0}, fail_error=ProviderUnavailableError("down", "p2"))

        failover = FailoverProvider(p1, [p2])
        with pytest.raises(ProviderUnavailableError):
            await failover.generate([{"role": "user", "content": "test"}])

    @pytest.mark.asyncio
    async def test_health_check(self):
        from tests.conftest import MockProvider
        from syndatalab.providers.failover import FailoverProvider

        primary = MockProvider()
        failover = FailoverProvider(primary)
        assert await failover.health_check()
