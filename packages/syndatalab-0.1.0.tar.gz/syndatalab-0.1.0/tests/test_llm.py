"""Tests for the LLM base class."""

import json

import pytest
from pydantic import BaseModel

from syndatalab.core.llm import LLM, ChainedLLM


class SimpleLLM(LLM):
    def prompt(self, input: dict) -> str:
        return f"Tell me about {input['topic']}"

    def parse(self, input: dict, response) -> dict:
        return {"topic": input["topic"], "response": response if isinstance(response, str) else str(response)}


class StructuredOutput(BaseModel):
    answer: str
    confidence: float


class StructuredLLM(LLM):
    response_format = StructuredOutput

    def prompt(self, input: dict) -> str:
        return f"Answer: {input['question']}"

    def parse(self, input: dict, response: StructuredOutput) -> dict:
        return {
            "question": input["question"],
            "answer": response.answer,
            "confidence": response.confidence,
        }


class TestLLMBase:
    def test_prompt_not_implemented(self):
        with pytest.raises(NotImplementedError):
            llm = LLM.__new__(LLM)
            llm.prompt({"key": "value"})

    def test_default_parse(self):
        llm = LLM.__new__(LLM)
        result = llm.parse({"key": "value"}, "response text")
        assert result["input"] == {"key": "value"}
        assert result["response"] == "response text"

    def test_default_system_prompt(self):
        llm = LLM.__new__(LLM)
        assert llm.system_prompt({"key": "value"}) is None

    def test_chaining_creates_chained_llm(self):
        llm1 = SimpleLLM.__new__(SimpleLLM)
        llm2 = SimpleLLM.__new__(SimpleLLM)
        chained = llm1 | llm2
        assert isinstance(chained, ChainedLLM)

    def test_triple_chaining(self):
        llm1 = SimpleLLM.__new__(SimpleLLM)
        llm2 = SimpleLLM.__new__(SimpleLLM)
        llm3 = SimpleLLM.__new__(SimpleLLM)
        chained = llm1 | llm2 | llm3
        assert isinstance(chained, ChainedLLM)
