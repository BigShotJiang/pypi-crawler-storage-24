"""Shared test fixtures and mock provider."""

from __future__ import annotations

import json
import tempfile
from pathlib import Path
from typing import Any, Type

import pytest
from pydantic import BaseModel

from syndatalab.core.config import SyndatalabConfig
from syndatalab.providers.base import BaseProvider, ProviderResponse


class MockProvider(BaseProvider):
    """Deterministic mock provider for testing."""

    provider_name = "mock"

    def __init__(
        self,
        model: str = "mock-model",
        responses: list[str] | None = None,
        fail_on: set[int] | None = None,
        fail_error: Exception | None = None,
    ):
        super().__init__(model)
        self._responses = responses or ['{"answer": "mock response"}']
        self._fail_on = fail_on or set()
        self._fail_error = fail_error
        self._call_count = 0

    async def generate(
        self,
        messages: list[dict[str, str]],
        response_format: Type[BaseModel] | None = None,
        generation_params: dict[str, Any] | None = None,
    ) -> ProviderResponse:
        idx = self._call_count
        self._call_count += 1

        if idx in self._fail_on:
            if self._fail_error:
                raise self._fail_error
            from syndatalab.core.exceptions import ProviderUnavailableError
            raise ProviderUnavailableError("Mock failure", provider="mock", status_code=500)

        text = self._responses[idx % len(self._responses)]
        return ProviderResponse(
            text=text,
            prompt_tokens=10,
            completion_tokens=20,
            finish_reason="stop",
            model=self.model,
            provider="mock",
        )

    async def health_check(self) -> bool:
        return True


@pytest.fixture
def mock_provider():
    return MockProvider()


@pytest.fixture
def tmp_dir():
    with tempfile.TemporaryDirectory() as d:
        yield Path(d)


@pytest.fixture
def test_config(tmp_dir):
    return SyndatalabConfig(
        model="mock-model",
        cache_dir=tmp_dir / "cache",
        checkpoint_dir=tmp_dir / "checkpoints",
        audit_dir=tmp_dir / "audit",
        log_dir=tmp_dir / "logs",
        history_file=tmp_dir / "history.jsonl",
        show_dashboard=False,
        max_retries=1,
        max_concurrent_requests=5,
        max_requests_per_minute=1000,
        max_tokens_per_minute=1_000_000,
    )
