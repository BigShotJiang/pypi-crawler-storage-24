"""Tests for quality module: dedup, filters, diversity."""

import pytest

from syndatalab.quality.dedup import exact_dedup, fuzzy_dedup
from syndatalab.quality.diversity import compute_diversity
from syndatalab.quality.filters import (
    apply_filters,
    custom,
    max_length,
    min_length,
    not_empty,
    regex_exclude,
    regex_match,
)


class TestExactDedup:
    def test_removes_exact_duplicates(self):
        rows = [
            {"text": "hello world"},
            {"text": "hello world"},
            {"text": "different"},
        ]
        result, removed = exact_dedup(rows, "text")
        assert len(result) == 2
        assert removed == 1

    def test_no_duplicates(self):
        rows = [{"text": "a"}, {"text": "b"}, {"text": "c"}]
        result, removed = exact_dedup(rows, "text")
        assert len(result) == 3
        assert removed == 0


class TestFuzzyDedup:
    def test_falls_back_to_exact_without_datasketch(self):
        rows = [
            {"text": "hello world"},
            {"text": "hello world"},
            {"text": "completely different text here"},
        ]
        result, removed = fuzzy_dedup(rows, "text")
        # At minimum, exact duplicates should be caught
        assert removed >= 1


class TestFilters:
    def test_min_length(self):
        rows = [{"text": "short"}, {"text": "this is a longer text"}]
        result, removed = apply_filters(rows, [min_length("text", 10)])
        assert len(result) == 1
        assert removed == 1

    def test_max_length(self):
        rows = [{"text": "short"}, {"text": "this is a very long text indeed"}]
        result, removed = apply_filters(rows, [max_length("text", 10)])
        assert len(result) == 1
        assert removed == 1

    def test_regex_match(self):
        rows = [{"text": "Python is great"}, {"text": "Java is great"}]
        result, removed = apply_filters(rows, [regex_match("text", r"Python")])
        assert len(result) == 1

    def test_regex_exclude(self):
        rows = [{"text": "I cannot help"}, {"text": "Here is the answer"}]
        result, removed = apply_filters(rows, [regex_exclude("text", r"cannot")])
        assert len(result) == 1

    def test_not_empty(self):
        rows = [{"a": "hello", "b": "world"}, {"a": "", "b": "world"}, {"a": "hello", "b": None}]
        result, removed = apply_filters(rows, [not_empty("a", "b")])
        assert len(result) == 1
        assert removed == 2

    def test_custom_filter(self):
        rows = [{"val": 1}, {"val": 5}, {"val": 10}]
        result, removed = apply_filters(rows, [custom(lambda r: r["val"] > 3)])
        assert len(result) == 2

    def test_multiple_filters(self):
        rows = [
            {"text": "hello"},
            {"text": "this is long enough and valid"},
            {"text": "I cannot do that, sorry"},
        ]
        filters = [
            min_length("text", 10),
            regex_exclude("text", r"cannot"),
        ]
        result, removed = apply_filters(rows, filters)
        assert len(result) == 1
        assert result[0]["text"] == "this is long enough and valid"


class TestDiversity:
    def test_basic_diversity(self):
        rows = [
            {"text": "the quick brown fox jumps over the lazy dog"},
            {"text": "a completely different sentence with new words"},
            {"text": "yet another unique phrase for testing"},
        ]
        stats = compute_diversity(rows, "text")
        assert stats.bigram_diversity > 0
        assert stats.trigram_diversity > 0
        assert stats.vocab_richness > 0

    def test_empty_rows(self):
        stats = compute_diversity([], "text")
        assert stats.bigram_diversity == 0
