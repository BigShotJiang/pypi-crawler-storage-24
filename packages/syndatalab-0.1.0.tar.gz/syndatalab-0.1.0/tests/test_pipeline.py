"""Integration tests for the pipeline with mock providers."""

import json

import pytest
from pydantic import BaseModel

from syndatalab.core.config import SyndatalabConfig
from syndatalab.core.pipeline import Pipeline
from tests.conftest import MockProvider


class Answer(BaseModel):
    answer: str


class TestPipeline:
    @pytest.mark.asyncio
    async def test_basic_pipeline(self, test_config: SyndatalabConfig):
        provider = MockProvider(responses=[
            '{"answer": "response 1"}',
            '{"answer": "response 2"}',
        ])

        pipeline = Pipeline(
            provider=provider,
            config=test_config,
            run_id="test_basic",
            prompt_fn=lambda row: f"Question: {row['q']}",
            parse_fn=lambda row, resp: {"q": row["q"], "a": resp.answer if hasattr(resp, 'answer') else str(resp)},
            response_format=Answer,
        )

        dataset = [{"q": "What is Python?"}, {"q": "What is Rust?"}]
        result = await pipeline.run(dataset)

        assert len(result.dataset) == 2
        assert result.run_id == "test_basic"
        assert result.performance["successful"] == 2
        assert result.performance["failed"] == 0

    @pytest.mark.asyncio
    async def test_pipeline_with_failures(self, test_config: SyndatalabConfig):
        from syndatalab.core.exceptions import ProviderUnavailableError

        # Fail on ALL calls (0, 1, 2) so retries don't accidentally succeed
        provider = MockProvider(
            responses=['{"answer": "ok"}'],
            fail_on={0, 1, 2, 3, 4, 5, 6, 7, 8, 9},
            fail_error=ProviderUnavailableError("fail", "mock"),
        )
        test_config.max_retries = 1

        pipeline = Pipeline(
            provider=provider,
            config=test_config,
            run_id="test_fail",
            prompt_fn=lambda row: f"Q: {row['q']}",
            parse_fn=lambda row, resp: {"q": row["q"], "a": resp.answer if hasattr(resp, 'answer') else str(resp)},
            response_format=Answer,
        )

        dataset = [{"q": "Q1"}]
        result = await pipeline.run(dataset)

        assert result.performance["failed"] >= 1
        assert len(result.failed) >= 1

    @pytest.mark.asyncio
    async def test_pipeline_no_response_format(self, test_config: SyndatalabConfig):
        provider = MockProvider(responses=["plain text response"])

        pipeline = Pipeline(
            provider=provider,
            config=test_config,
            run_id="test_plain",
            prompt_fn=lambda row: f"Q: {row['q']}",
            parse_fn=lambda row, resp: {"q": row["q"], "a": resp},
        )

        dataset = [{"q": "Hello?"}]
        result = await pipeline.run(dataset)

        assert len(result.dataset) == 1
        assert result.performance["successful"] == 1

    @pytest.mark.asyncio
    async def test_pipeline_with_filters(self, test_config: SyndatalabConfig):
        provider = MockProvider(responses=[
            '{"answer": "short"}',
            '{"answer": "this is a much longer answer that should pass the filter"}',
        ])

        from syndatalab.quality.filters import min_length

        pipeline = Pipeline(
            provider=provider,
            config=test_config,
            run_id="test_filter",
            prompt_fn=lambda row: f"Q: {row['q']}",
            parse_fn=lambda row, resp: {"q": row["q"], "a": resp.answer if hasattr(resp, 'answer') else str(resp)},
            response_format=Answer,
            filters=[min_length("a", 20)],
        )

        dataset = [{"q": "Q1"}, {"q": "Q2"}]
        result = await pipeline.run(dataset)

        # One row should be filtered out (short answer)
        assert result.quality["total_before_filter"] == 2
        assert result.quality["total_after_filter"] == 1
