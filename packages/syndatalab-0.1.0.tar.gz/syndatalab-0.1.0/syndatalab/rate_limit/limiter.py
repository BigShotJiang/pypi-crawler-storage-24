"""Dual token-bucket rate limiter for RPM and TPM."""

from __future__ import annotations

import asyncio
import random
import time


class TokenBucket:
    """Single token bucket with refill rate."""

    def __init__(self, capacity: float, refill_rate: float):
        self.capacity = capacity
        self.refill_rate = refill_rate  # tokens per second
        self.tokens = capacity
        self.last_refill = time.monotonic()
        self._lock = asyncio.Lock()

    async def acquire(self, count: float = 1.0) -> float:
        """Acquire tokens. Returns wait time in seconds (0 if immediately available)."""
        async with self._lock:
            self._refill()
            if self.tokens >= count:
                self.tokens -= count
                return 0.0

            deficit = count - self.tokens
            wait_time = deficit / self.refill_rate
            self.tokens = 0
            return wait_time

    def _refill(self) -> None:
        now = time.monotonic()
        elapsed = now - self.last_refill
        self.tokens = min(self.capacity, self.tokens + self.refill_rate * elapsed)
        self.last_refill = now


# Provider-specific defaults (RPM, TPM)
PROVIDER_DEFAULTS: dict[str, dict[str, int]] = {
    "openai": {"rpm": 500, "tpm": 200_000},
    "anthropic": {"rpm": 1000, "tpm": 100_000},
    "ollama": {"rpm": 10_000, "tpm": 10_000_000},
    "litellm": {"rpm": 500, "tpm": 200_000},
}


class RateLimiter:
    """Dual token-bucket rate limiter (RPM + TPM).

    Requests must acquire from both buckets before proceeding.
    """

    def __init__(
        self,
        max_requests_per_minute: int = 500,
        max_tokens_per_minute: int = 200_000,
    ):
        self.rpm_bucket = TokenBucket(
            capacity=float(max_requests_per_minute),
            refill_rate=max_requests_per_minute / 60.0,
        )
        self.tpm_bucket = TokenBucket(
            capacity=float(max_tokens_per_minute),
            refill_rate=max_tokens_per_minute / 60.0,
        )
        self._backoff_until: float = 0.0
        self._lock = asyncio.Lock()

    async def acquire(self, estimated_tokens: int = 1000) -> None:
        """Wait until both RPM and TPM budgets allow the request."""
        # Wait for any active backoff first
        async with self._lock:
            now = time.monotonic()
            if self._backoff_until > now:
                wait = self._backoff_until - now
                await asyncio.sleep(wait)

        rpm_wait = await self.rpm_bucket.acquire(1.0)
        tpm_wait = await self.tpm_bucket.acquire(float(estimated_tokens))
        total_wait = max(rpm_wait, tpm_wait)
        if total_wait > 0:
            await asyncio.sleep(total_wait)

    async def report_rate_limit(self, retry_after: float | None = None) -> None:
        """Report a 429 response. Applies adaptive backoff."""
        async with self._lock:
            if retry_after:
                self._backoff_until = time.monotonic() + retry_after
            else:
                # Exponential backoff with jitter
                backoff = min(60.0, 2.0 + random.uniform(0, 2.0))
                self._backoff_until = time.monotonic() + backoff

    @classmethod
    def for_provider(cls, provider_name: str) -> RateLimiter:
        """Create a rate limiter with provider-specific defaults."""
        defaults = PROVIDER_DEFAULTS.get(provider_name, PROVIDER_DEFAULTS["openai"])
        return cls(
            max_requests_per_minute=defaults["rpm"],
            max_tokens_per_minute=defaults["tpm"],
        )
