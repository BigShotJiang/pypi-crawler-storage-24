"""Structured logging with structlog + rich console output."""

from __future__ import annotations

import logging
import logging.handlers
from pathlib import Path

import structlog

_configured = False


def setup_logging(
    level: str = "INFO",
    log_file: str | Path | None = None,
    log_dir: Path | None = None,
) -> None:
    """Configure structured logging for the package."""
    global _configured
    if _configured:
        return
    _configured = True

    log_level = getattr(logging, level.upper(), logging.INFO)

    # Stdlib logging setup
    root_logger = logging.getLogger("syndatalab")
    root_logger.setLevel(log_level)
    root_logger.handlers.clear()

    # Console handler using rich
    try:
        from rich.logging import RichHandler

        console_handler = RichHandler(
            level=log_level,
            show_path=False,
            markup=True,
            rich_tracebacks=True,
        )
    except ImportError:
        console_handler = logging.StreamHandler()
    console_handler.setLevel(log_level)
    root_logger.addHandler(console_handler)

    # File handler
    file_path = log_file or (log_dir / "syndatalab.log" if log_dir else None)
    if file_path:
        file_path = Path(file_path).expanduser()
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_handler = logging.handlers.RotatingFileHandler(
            file_path,
            maxBytes=10 * 1024 * 1024,  # 10MB
            backupCount=5,
        )
        file_handler.setLevel(log_level)
        file_handler.setFormatter(logging.Formatter("%(message)s"))
        root_logger.addHandler(file_handler)

    # Structlog configuration
    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            structlog.stdlib.filter_by_level,
            structlog.stdlib.add_logger_name,
            structlog.stdlib.add_log_level,
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.processors.UnicodeDecoder(),
            structlog.stdlib.ProcessorFormatter.wrap_for_formatter,
        ],
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.stdlib.BoundLogger,
        cache_logger_on_first_use=True,
    )


def get_logger(name: str = "syndatalab") -> structlog.stdlib.BoundLogger:
    """Get a structured logger."""
    return structlog.get_logger(name)
