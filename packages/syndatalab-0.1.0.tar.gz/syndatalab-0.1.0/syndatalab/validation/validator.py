"""Layered output validation: extract -> parse -> validate -> repair -> re-prompt."""

from __future__ import annotations

import json
import re
from typing import Any, Type

from pydantic import BaseModel

from syndatalab.core.exceptions import ValidationError as SyndatalabValidationError
from syndatalab.logging.setup import get_logger
from syndatalab.stats.models import ValidationStats

logger = get_logger(__name__)


def _extract_json_from_text(text: str) -> str:
    """Layer 1: Extract JSON from markdown fences or surrounding prose."""
    # Strip markdown code fences
    fence_pattern = r"```(?:json)?\s*\n?(.*?)\n?\s*```"
    match = re.search(fence_pattern, text, re.DOTALL)
    if match:
        return match.group(1).strip()

    # Try to find a JSON object or array
    for start_char, end_char in [("{", "}"), ("[", "]")]:
        start = text.find(start_char)
        if start == -1:
            continue
        # Find matching closing bracket, handling nesting
        depth = 0
        for i in range(start, len(text)):
            if text[i] == start_char:
                depth += 1
            elif text[i] == end_char:
                depth -= 1
                if depth == 0:
                    return text[start : i + 1]

    return text.strip()


def _parse_json(text: str) -> Any:
    """Layer 2: Parse JSON, with fallback to json_repair."""
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    # Layer 2b: Try json_repair
    try:
        from json_repair import repair_json

        repaired = repair_json(text, return_objects=True)
        if repaired is not None:
            return repaired
    except ImportError:
        pass
    except Exception:
        pass

    raise json.JSONDecodeError("Failed to parse JSON after repair attempt", text, 0)


def _validate_pydantic(data: Any, response_format: Type[BaseModel]) -> BaseModel:
    """Layer 3: Validate parsed data against Pydantic model."""
    if isinstance(data, dict):
        return response_format.model_validate(data)
    if isinstance(data, str):
        return response_format.model_validate_json(data)
    return response_format.model_validate(data)


def validate_response(
    raw_text: str,
    response_format: Type[BaseModel] | None,
    stats: ValidationStats | None = None,
) -> BaseModel | str:
    """Validate and parse an LLM response through layers 1-3.

    Returns the validated Pydantic model instance, or the raw text if no format specified.
    Raises SyndatalabValidationError if all layers fail.
    """
    if response_format is None:
        return raw_text

    errors: list[str] = []

    # Layer 1: Extract JSON
    try:
        extracted = _extract_json_from_text(raw_text)
        if stats:
            stats.layer1_success += 1
    except Exception as e:
        errors.append(f"Layer 1 (extract): {e}")
        extracted = raw_text

    # Layer 2: Parse JSON
    parsed = None
    try:
        parsed = _parse_json(extracted)
        if stats:
            stats.layer2_success += 1
    except json.JSONDecodeError as e:
        errors.append(f"Layer 2 (parse): {e}")
        # Try repair on the raw text too
        try:
            from json_repair import repair_json

            parsed = repair_json(raw_text, return_objects=True)
            if parsed is not None and stats:
                stats.layer2b_repair_success += 1
        except Exception:
            pass

    if parsed is None:
        raise SyndatalabValidationError(
            f"Failed to parse JSON from LLM response. Errors: {'; '.join(errors)}",
            layer="parse",
            raw_response=raw_text,
        )

    # Layer 3: Pydantic validation
    try:
        result = _validate_pydantic(parsed, response_format)
        if stats:
            stats.layer3_success += 1
        return result
    except Exception as e:
        errors.append(f"Layer 3 (validate): {e}")
        raise SyndatalabValidationError(
            f"Pydantic validation failed: {e}. Errors: {'; '.join(errors)}",
            layer="validate",
            raw_response=raw_text,
        ) from e


def build_repair_messages(
    original_messages: list[dict[str, str]],
    raw_response: str,
    error: str,
) -> list[dict[str, str]]:
    """Build messages for Layer 4: re-prompting the LLM with the validation error."""
    messages = list(original_messages)
    messages.append({"role": "assistant", "content": raw_response})
    messages.append(
        {
            "role": "user",
            "content": (
                f"Your previous response had a validation error:\n{error}\n\n"
                "Please fix the issue and respond again with ONLY valid JSON matching the schema. "
                "No markdown fences, no explanation."
            ),
        }
    )
    return messages
