"""Output formatter producing HuggingFace Datasets with metadata sidecar."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from syndatalab.logging.setup import get_logger

logger = get_logger(__name__)


def rows_to_dataset(rows: list[dict[str, Any]]) -> Any:
    """Convert a list of row dicts to a HuggingFace Dataset."""
    from datasets import Dataset

    if not rows:
        return Dataset.from_dict({})

    # Collect all keys across all rows
    all_keys: set[str] = set()
    for row in rows:
        all_keys.update(row.keys())

    # Build column-oriented data
    columns: dict[str, list] = {key: [] for key in sorted(all_keys)}
    for row in rows:
        for key in columns:
            columns[key].append(row.get(key))

    return Dataset.from_dict(columns)


def write_metadata_sidecar(
    output_dir: Path,
    run_id: str,
    metadata: dict[str, Any],
) -> Path:
    """Write a JSON metadata sidecar file alongside the dataset."""
    output_dir.mkdir(parents=True, exist_ok=True)
    meta_path = output_dir / f"{run_id}_meta.json"
    with open(meta_path, "w") as f:
        json.dump(metadata, f, indent=2, default=str)
    logger.info("metadata_sidecar_written", path=str(meta_path))
    return meta_path
