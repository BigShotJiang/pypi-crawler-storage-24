"""SQLite-based cache with WAL mode, TTL, and atomic writes."""

from __future__ import annotations

import hashlib
import json
import sqlite3
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from syndatalab.core.exceptions import CacheError

_SCHEMA_VERSION = 1

_CREATE_TABLE = """
CREATE TABLE IF NOT EXISTS cache (
    key TEXT PRIMARY KEY,
    response_text TEXT NOT NULL,
    prompt_tokens INTEGER NOT NULL DEFAULT 0,
    completion_tokens INTEGER NOT NULL DEFAULT 0,
    model TEXT,
    provider TEXT,
    created_at REAL NOT NULL,
    expires_at REAL
);
"""

_CREATE_META = """
CREATE TABLE IF NOT EXISTS meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
"""


@dataclass
class CacheEntry:
    key: str
    response_text: str
    prompt_tokens: int
    completion_tokens: int
    model: str | None
    provider: str | None
    created_at: float
    expires_at: float | None


class SQLiteCache:
    """Hash-based request/response cache backed by SQLite with WAL mode."""

    def __init__(self, cache_dir: Path, ttl_days: int = 30):
        self.cache_dir = cache_dir
        self.ttl_seconds = ttl_days * 86400
        self.db_path = cache_dir / "syndatalab_cache.db"
        self._conn: sqlite3.Connection | None = None
        self._init_db()

    def _init_db(self) -> None:
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        try:
            self._conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA synchronous=NORMAL")
            self._conn.execute(_CREATE_TABLE)
            self._conn.execute(_CREATE_META)

            # Check/set schema version
            cursor = self._conn.execute("SELECT value FROM meta WHERE key='schema_version'")
            row = cursor.fetchone()
            if row is None:
                self._conn.execute(
                    "INSERT INTO meta (key, value) VALUES ('schema_version', ?)",
                    (str(_SCHEMA_VERSION),),
                )
            self._conn.commit()
        except sqlite3.Error as e:
            raise CacheError(f"Failed to initialize cache database: {e}") from e

    @staticmethod
    def make_key(
        model: str,
        messages: list[dict[str, str]],
        generation_params: dict[str, Any] | None = None,
        response_format_schema: dict | None = None,
    ) -> str:
        """Create a deterministic cache key from request parameters."""
        key_data = {
            "model": model,
            "messages": messages,
            "params": generation_params or {},
            "schema": response_format_schema,
        }
        raw = json.dumps(key_data, sort_keys=True, ensure_ascii=True)
        return hashlib.sha256(raw.encode()).hexdigest()

    def get(self, key: str) -> CacheEntry | None:
        """Look up a cached response. Returns None on miss or expired entry."""
        if self._conn is None:
            return None
        try:
            cursor = self._conn.execute(
                "SELECT key, response_text, prompt_tokens, completion_tokens, "
                "model, provider, created_at, expires_at "
                "FROM cache WHERE key = ?",
                (key,),
            )
            row = cursor.fetchone()
            if row is None:
                return None

            entry = CacheEntry(*row)
            if entry.expires_at and entry.expires_at < time.time():
                self._conn.execute("DELETE FROM cache WHERE key = ?", (key,))
                self._conn.commit()
                return None
            return entry
        except sqlite3.Error as e:
            raise CacheError(f"Cache lookup failed: {e}") from e

    def put(
        self,
        key: str,
        response_text: str,
        prompt_tokens: int,
        completion_tokens: int,
        model: str | None = None,
        provider: str | None = None,
    ) -> None:
        """Store a response in the cache."""
        if self._conn is None:
            return
        now = time.time()
        expires_at = now + self.ttl_seconds if self.ttl_seconds > 0 else None
        try:
            self._conn.execute(
                "INSERT OR REPLACE INTO cache "
                "(key, response_text, prompt_tokens, completion_tokens, "
                "model, provider, created_at, expires_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    key, response_text, prompt_tokens,
                    completion_tokens, model, provider, now, expires_at,
                ),
            )
            self._conn.commit()
        except sqlite3.Error as e:
            raise CacheError(f"Cache write failed: {e}") from e

    def prune_expired(self) -> int:
        """Remove expired entries. Returns count of removed entries."""
        if self._conn is None:
            return 0
        try:
            cursor = self._conn.execute(
                "DELETE FROM cache WHERE expires_at IS NOT NULL AND expires_at < ?",
                (time.time(),),
            )
            self._conn.commit()
            return cursor.rowcount
        except sqlite3.Error as e:
            raise CacheError(f"Cache prune failed: {e}") from e

    def stats(self) -> dict[str, Any]:
        """Get cache statistics."""
        if self._conn is None:
            return {"entries": 0, "size_bytes": 0}
        try:
            cursor = self._conn.execute("SELECT COUNT(*) FROM cache")
            count = cursor.fetchone()[0]

            size = self.db_path.stat().st_size if self.db_path.exists() else 0

            cursor = self._conn.execute(
                "SELECT COUNT(*) FROM cache WHERE expires_at IS NOT NULL AND expires_at < ?",
                (time.time(),),
            )
            expired = cursor.fetchone()[0]

            return {
                "entries": count,
                "expired_entries": expired,
                "size_bytes": size,
                "size_mb": round(size / (1024 * 1024), 2),
                "db_path": str(self.db_path),
            }
        except sqlite3.Error as e:
            raise CacheError(f"Cache stats failed: {e}") from e

    def clear(self) -> int:
        """Clear all cache entries. Returns count of removed entries."""
        if self._conn is None:
            return 0
        try:
            cursor = self._conn.execute("DELETE FROM cache")
            self._conn.commit()
            return cursor.rowcount
        except sqlite3.Error as e:
            raise CacheError(f"Cache clear failed: {e}") from e

    def export_entries(self) -> list[dict[str, Any]]:
        """Export all cache entries as dicts."""
        if self._conn is None:
            return []
        try:
            cursor = self._conn.execute(
                "SELECT key, response_text, prompt_tokens, completion_tokens, "
                "model, provider, created_at, expires_at FROM cache"
            )
            return [
                {
                    "key": row[0],
                    "response_text": row[1],
                    "prompt_tokens": row[2],
                    "completion_tokens": row[3],
                    "model": row[4],
                    "provider": row[5],
                    "created_at": row[6],
                    "expires_at": row[7],
                }
                for row in cursor.fetchall()
            ]
        except sqlite3.Error as e:
            raise CacheError(f"Cache export failed: {e}") from e

    def close(self) -> None:
        if self._conn:
            self._conn.close()
            self._conn = None

    def __del__(self) -> None:
        self.close()
