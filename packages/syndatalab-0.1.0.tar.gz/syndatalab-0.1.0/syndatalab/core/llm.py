"""Base LLM class — the primary user-facing API."""

from __future__ import annotations

import asyncio
from typing import Any, Type

from pydantic import BaseModel

from syndatalab.checkpoint.manager import compute_run_id, dataset_fingerprint
from syndatalab.core.config import load_config
from syndatalab.core.pipeline import Pipeline
from syndatalab.core.response import SyndataResponse
from syndatalab.logging.setup import get_logger, setup_logging
from syndatalab.providers.base import BaseProvider
from syndatalab.providers.failover import FailoverProvider
from syndatalab.providers.registry import create_provider

logger = get_logger(__name__)


class LLM:
    """Base class for synthetic data generators.

    Subclass this and override `prompt()`, and optionally `parse()` and `system_prompt()`.
    Set `response_format` to a Pydantic BaseModel to get structured outputs.
    """

    response_format: Type[BaseModel] | None = None

    def __init__(
        self,
        model: str | None = None,
        backend: str | None = None,
        fallback_models: list[str] | None = None,
        generation_params: dict[str, Any] | None = None,
        # Config overrides
        max_retries: int | None = None,
        max_concurrent_requests: int | None = None,
        max_requests_per_minute: int | None = None,
        max_tokens_per_minute: int | None = None,
        max_validation_retries: int | None = None,
        show_dashboard: bool | None = None,
        cache_enabled: bool | None = None,
        api_key: str | None = None,
        base_url: str | None = None,
        extra_headers: dict[str, str] | None = None,
        **kwargs: Any,
    ):
        self.config = load_config(
            model=model,
            max_retries=max_retries,
            max_concurrent_requests=max_concurrent_requests,
            max_requests_per_minute=max_requests_per_minute,
            max_tokens_per_minute=max_tokens_per_minute,
            max_validation_retries=max_validation_retries,
            show_dashboard=show_dashboard,
            cache_enabled=cache_enabled,
            fallback_models=fallback_models or [],
        )

        self._model = model or self.config.model
        self._backend = backend
        self._generation_params = generation_params or {}
        self._api_key = api_key
        self._base_url = base_url
        self._extra_headers = extra_headers

        setup_logging(level=self.config.log_level, log_dir=self.config.log_dir)

    def prompt(self, input: dict[str, Any]) -> str | list[dict[str, str]]:
        """Generate a prompt for the LLM. Override this in your subclass.

        Args:
            input: A single row from the input dataset.

        Returns:
            A string (user message) or a list of message dicts for multi-turn.
        """
        raise NotImplementedError("Subclasses must implement prompt()")

    def system_prompt(self, input: dict[str, Any]) -> str | None:
        """Optional system prompt. Override to customize."""
        return None

    def parse(self, input: dict[str, Any], response: Any) -> dict[str, Any] | list[dict[str, Any]]:
        """Parse the LLM response into output rows. Override to customize.

        Args:
            input: The original input row.
            response: The LLM response (Pydantic model if response_format set, else str).

        Returns:
            A dict (single row) or list of dicts (multiple rows).
        """
        resp_val = response if isinstance(response, str) else response.model_dump()
        return {"input": input, "response": resp_val}

    def _create_provider(self) -> BaseProvider:
        """Create the appropriate provider, with failover if configured."""
        api_key = self._api_key or self.config.openai_api_key or self.config.anthropic_api_key
        primary = create_provider(
            self._model,
            backend=self._backend,
            api_key=api_key,
            base_url=self._base_url,
            extra_headers=self._extra_headers,
        )

        if self.config.fallback_models:
            return FailoverProvider.from_model_list(
                primary_model=self._model,
                fallback_models=self.config.fallback_models,
                api_key=api_key,
                base_url=self._base_url,
                extra_headers=self._extra_headers,
                failover_on=self.config.failover_on,
            )

        return primary

    def __call__(
        self,
        dataset: list[dict[str, Any]] | Any = None,
        filters: list[Any] | None = None,
        force_restart: bool = False,
        **kwargs: Any,
    ) -> SyndataResponse:
        """Run the generation pipeline.

        Args:
            dataset: List of input row dicts, or a HuggingFace Dataset.
            filters: Optional list of quality filter functions.
            force_restart: If True, ignore existing checkpoint.

        Returns:
            SyndataResponse with dataset, stats, and metadata.
        """
        # Convert HF Dataset to list of dicts if needed
        if dataset is None:
            dataset = [{}]
        if hasattr(dataset, "to_list"):
            dataset = dataset.to_list()
        elif hasattr(dataset, "__iter__") and not isinstance(dataset, list):
            dataset = list(dataset)

        # Compute run ID
        ds_fp = dataset_fingerprint(dataset)
        run_id = compute_run_id(
            self.__class__.__name__, self._model, ds_fp, self._generation_params
        )

        provider = self._create_provider()

        pipeline = Pipeline(
            provider=provider,
            config=self.config,
            run_id=run_id,
            prompt_fn=self.prompt,
            parse_fn=self.parse,
            system_prompt_fn=self.system_prompt,
            response_format=self.response_format,
            filters=filters or [],
        )

        # Run async pipeline from sync context
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            # Already in an async context (e.g., Jupyter)
            import nest_asyncio

            nest_asyncio.apply()
            return loop.run_until_complete(pipeline.run(dataset))
        else:
            return asyncio.run(pipeline.run(dataset))

    def __or__(self, other: LLM) -> ChainedLLM:
        """Chain two LLMs: gen1 | gen2 feeds gen1's output into gen2."""
        return ChainedLLM(self, other)


class ChainedLLM:
    """Pipeline created by chaining LLMs with the | operator."""

    def __init__(self, first: LLM, second: LLM):
        self.first = first
        self.second = second

    def __call__(
        self,
        dataset: list[dict[str, Any]] | Any = None,
        **kwargs: Any,
    ) -> SyndataResponse:
        # Run first stage
        result1 = self.first(dataset=dataset, **kwargs)

        # Feed first stage output as input to second stage
        intermediate = [row for row in result1.dataset]
        result2 = self.second(dataset=intermediate, **kwargs)

        # Merge stats
        result2.metadata["chained_from"] = {
            "stage1_run_id": result1.run_id,
            "stage1_stats": result1.stats,
        }
        return result2

    def __or__(self, other: LLM) -> ChainedLLM:
        """Allow further chaining: (gen1 | gen2) | gen3."""
        return ChainedLLM(self, other)  # type: ignore[arg-type]
