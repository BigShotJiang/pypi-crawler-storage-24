"""Custom exception hierarchy with actionable error messages."""

from __future__ import annotations


class SyndatalabError(Exception):
    """Base exception for all syndatalab errors."""


class ProviderError(SyndatalabError):
    """API call to a provider failed."""

    def __init__(self, message: str, provider: str | None = None, status_code: int | None = None):
        self.provider = provider
        self.status_code = status_code
        super().__init__(message)


class RateLimitError(ProviderError):
    """Rate limit (429) hit. Includes retry-after hint when available."""

    def __init__(
        self,
        message: str,
        provider: str | None = None,
        retry_after: float | None = None,
    ):
        self.retry_after = retry_after
        hint = f" Retry after {retry_after:.1f}s." if retry_after else ""
        super().__init__(f"{message}{hint}", provider=provider, status_code=429)


class AuthenticationError(ProviderError):
    """Authentication failed (401/403)."""

    ENV_VAR_HINTS = {
        "openai": "OPENAI_API_KEY",
        "anthropic": "ANTHROPIC_API_KEY",
        "litellm": "OPENAI_API_KEY or the relevant provider key",
    }

    def __init__(self, message: str, provider: str | None = None):
        hint = ""
        if provider and provider in self.ENV_VAR_HINTS:
            hint = f" Set the {self.ENV_VAR_HINTS[provider]} environment variable."
        super().__init__(f"{message}{hint}", provider=provider, status_code=401)


class ProviderUnavailableError(ProviderError):
    """Provider returned 5xx or timed out."""

    def __init__(self, message: str, provider: str | None = None, status_code: int | None = None):
        super().__init__(message, provider=provider, status_code=status_code or 503)


class ValidationError(SyndatalabError):
    """Structured output failed all validation layers."""

    def __init__(self, message: str, layer: str | None = None, raw_response: str | None = None):
        self.layer = layer
        self.raw_response = raw_response
        super().__init__(message)


class CheckpointError(SyndatalabError):
    """Checkpoint file is corrupted or incompatible."""


class ConfigError(SyndatalabError):
    """Missing or invalid configuration."""


class CacheError(SyndatalabError):
    """SQLite cache operation failed."""


class ProviderNotInstalledError(SyndatalabError):
    """Provider SDK not installed."""

    INSTALL_HINTS = {
        "openai": "pip install syndatalab[openai]",
        "anthropic": "pip install syndatalab[anthropic]",
        "litellm": "pip install syndatalab[litellm]",
        "ollama": "pip install syndatalab[ollama]",
    }

    def __init__(self, provider: str):
        hint = self.INSTALL_HINTS.get(provider, f"pip install syndatalab[{provider}]")
        super().__init__(f"Provider '{provider}' is not installed. Install it with: {hint}")
