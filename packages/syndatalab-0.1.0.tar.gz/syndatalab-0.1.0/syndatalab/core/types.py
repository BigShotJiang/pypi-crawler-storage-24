"""Shared type aliases and enums."""

from __future__ import annotations

from enum import Enum
from typing import Any, Union

DictOrList = Union[dict[str, Any], list[dict[str, Any]]]
MessageList = list[dict[str, str]]
GenerationParams = dict[str, Any]


class RequestStatus(str, Enum):
    SUCCESS = "success"
    FAILED = "failed"
    RETRIED = "retried"
    CACHE_HIT = "cache_hit"
    VALIDATION_FAILED = "validation_failed"


class ProviderName(str, Enum):
    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    LITELLM = "litellm"
    OLLAMA = "ollama"


class ShutdownState(str, Enum):
    RUNNING = "running"
    DRAINING = "draining"
    FORCE_STOP = "force_stop"
