"""SyndataResponse wrapping dataset + stats + metadata + failed_rows + run_id."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class SyndataResponse:
    """Result of a syndatalab pipeline run."""

    dataset: Any  # datasets.Dataset
    run_id: str
    model: str

    # Stats
    token_usage: dict[str, Any] = field(default_factory=dict)
    cost: dict[str, Any] = field(default_factory=dict)
    performance: dict[str, Any] = field(default_factory=dict)
    validation: dict[str, Any] = field(default_factory=dict)
    quality: dict[str, Any] = field(default_factory=dict)

    # Failed rows (row_index -> error info)
    failed: list[dict[str, Any]] = field(default_factory=list)

    # Metadata
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def stats(self) -> dict[str, Any]:
        """Combined stats summary."""
        return {
            "token_usage": self.token_usage,
            "cost": self.cost,
            "performance": self.performance,
            "validation": self.validation,
            "quality": self.quality,
        }

    @property
    def total_cost(self) -> float:
        return self.cost.get("total_cost", 0.0)

    @property
    def total_tokens(self) -> int:
        return self.token_usage.get("total_tokens", 0)

    def to_pandas(self) -> Any:
        """Convert to pandas DataFrame."""
        return self.dataset.to_pandas()

    def to_json(self, path: str | None = None) -> str | None:
        """Export to JSON. If path given, writes to file; otherwise returns string."""
        import json

        rows = [row for row in self.dataset]
        if path:
            with open(path, "w") as f:
                json.dump(rows, f, indent=2, default=str)
            return None
        return json.dumps(rows, indent=2, default=str)

    def push_to_hub(self, repo_id: str, **kwargs: Any) -> None:
        """Push dataset to HuggingFace Hub."""
        self.dataset.push_to_hub(repo_id, **kwargs)

    def __repr__(self) -> str:
        n = len(self.dataset) if self.dataset is not None else 0
        return (
            f"SyndataResponse(rows={n}, run_id={self.run_id!r}, "
            f"cost=${self.total_cost:.4f}, tokens={self.total_tokens:,})"
        )
