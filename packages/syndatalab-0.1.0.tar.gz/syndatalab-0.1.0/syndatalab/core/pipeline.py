"""Async pipeline orchestrator — the heart of syndatalab."""

from __future__ import annotations

import asyncio
import copy
import signal
import time
from datetime import datetime, timezone
from typing import Any, Callable, Type

from pydantic import BaseModel

from syndatalab.cache.sqlite_cache import SQLiteCache
from syndatalab.checkpoint.manager import CheckpointManager
from syndatalab.core.config import SyndatalabConfig
from syndatalab.core.exceptions import (
    ProviderError,
    RateLimitError,
    ValidationError,
)
from syndatalab.core.response import SyndataResponse
from syndatalab.core.types import ShutdownState
from syndatalab.dashboard.tui import Dashboard
from syndatalab.logging.setup import get_logger
from syndatalab.output.formatter import rows_to_dataset, write_metadata_sidecar
from syndatalab.providers.base import BaseProvider, ProviderResponse
from syndatalab.quality.dedup import fuzzy_dedup
from syndatalab.quality.diversity import compute_diversity
from syndatalab.quality.filters import FilterFunc, apply_filters
from syndatalab.rate_limit.limiter import RateLimiter
from syndatalab.stats.audit import AuditLog, RunHistory
from syndatalab.stats.collector import StatsCollector
from syndatalab.stats.models import RequestLog
from syndatalab.validation.validator import build_repair_messages, validate_response

logger = get_logger(__name__)


class Pipeline:
    """Orchestrates async data generation with all subsystems integrated."""

    def __init__(
        self,
        provider: BaseProvider,
        config: SyndatalabConfig,
        run_id: str,
        prompt_fn: Callable[[dict[str, Any]], str | list[dict[str, str]]],
        parse_fn: Callable[[dict[str, Any], Any], dict[str, Any] | list[dict[str, Any]]],
        system_prompt_fn: Callable[[dict[str, Any]], str | None] | None = None,
        response_format: Type[BaseModel] | None = None,
        filters: list[FilterFunc] | None = None,
    ):
        self.provider = provider
        self.config = config
        self.run_id = run_id
        self.prompt_fn = prompt_fn
        self.parse_fn = parse_fn
        self.system_prompt_fn = system_prompt_fn
        self.response_format = response_format
        self.filters = filters or []

        self._shutdown_state = ShutdownState.RUNNING
        self._in_flight: set[asyncio.Task] = set()

    async def run(self, dataset: list[dict[str, Any]]) -> SyndataResponse:
        """Execute the pipeline on the dataset."""
        total_rows = len(dataset)

        # Initialize subsystems
        self.config.ensure_dirs()
        cache = (
            SQLiteCache(self.config.cache_dir, self.config.cache_ttl_days)
            if self.config.cache_enabled
            else None
        )
        checkpoint = CheckpointManager(self.config.checkpoint_dir, self.run_id)
        checkpoint.load_existing()
        stats = StatsCollector(self.config, self.run_id, total_rows)
        audit = AuditLog(self.config.audit_dir, self.run_id)
        rate_limiter = RateLimiter(
            self.config.max_requests_per_minute,
            self.config.max_tokens_per_minute,
        )

        # Determine which rows need processing
        pending_indices = [i for i in range(total_rows) if not checkpoint.is_completed(i)]
        results: dict[int, list[dict[str, Any]]] = {}
        failed_rows: list[dict[str, Any]] = []

        # Populate results from checkpoint
        for idx in range(total_rows):
            ckpt_data = checkpoint.get_completed(idx)
            if ckpt_data and "parsed_rows" in ckpt_data:
                results[idx] = ckpt_data["parsed_rows"]

        # Signal handling for graceful shutdown
        loop = asyncio.get_running_loop()
        original_handlers: dict[int, Any] = {}

        def _shutdown_handler(sig: int) -> None:
            if self._shutdown_state == ShutdownState.RUNNING:
                logger.info("graceful_shutdown_initiated", signal=sig)
                self._shutdown_state = ShutdownState.DRAINING
            else:
                logger.warning("force_shutdown", signal=sig)
                self._shutdown_state = ShutdownState.FORCE_STOP
                for task in self._in_flight:
                    task.cancel()

        try:
            for sig in (signal.SIGINT, signal.SIGTERM):
                original_handlers[sig] = signal.getsignal(sig)
                loop.add_signal_handler(sig, _shutdown_handler, sig)
        except (ValueError, OSError):
            pass  # Not on main thread or not Unix

        # Dashboard
        dashboard: Dashboard | None = None
        if self.config.show_dashboard:
            dashboard = Dashboard(stats, total_rows)
            dashboard.start()

        # Semaphore for concurrency control
        semaphore = asyncio.Semaphore(self.config.max_concurrent_requests)

        async def _process_row(row_index: int) -> None:
            if self._shutdown_state != ShutdownState.RUNNING:
                return

            row = dataset[row_index]
            start_time = time.monotonic()

            # Build messages
            prompt_result = self.prompt_fn(row)
            if isinstance(prompt_result, str):
                messages: list[dict[str, str]] = [{"role": "user", "content": prompt_result}]
            else:
                messages = list(prompt_result)

            system_prompt = self.system_prompt_fn(row) if self.system_prompt_fn else None
            if system_prompt:
                messages.insert(0, {"role": "system", "content": system_prompt})

            # Cache lookup
            cache_key = None
            if cache:
                schema_dict = (
                    self.response_format.model_json_schema()
                    if self.response_format
                    else None
                )
                cache_key = SQLiteCache.make_key(
                    self.provider.model, messages, None, schema_dict
                )
                entry = cache.get(cache_key)
                if entry is not None:
                    # Cache hit
                    response_text = entry.response_text
                    validated = validate_response(
                        response_text, self.response_format, stats.validation
                    )
                    parsed = self.parse_fn(row, validated)
                    parsed_rows = parsed if isinstance(parsed, list) else [parsed]
                    results[row_index] = parsed_rows

                    stats.record_request(
                        row_index=row_index,
                        model=self.provider.model,
                        provider=self.provider.provider_name,
                        prompt_tokens=entry.prompt_tokens,
                        completion_tokens=entry.completion_tokens,
                        latency_ms=0,
                        status="success",
                        cache_hit=True,
                        input_preview=messages[-1].get("content", "")[:200],
                        output_preview=response_text[:200],
                    )
                    checkpoint.save_row(
                        row_index, {"parsed_rows": parsed_rows, "status": "cache_hit"}
                    )
                    return

            # Rate limiting
            await rate_limiter.acquire(estimated_tokens=1000)

            # Generate with retry and validation loop
            last_error: Exception | None = None
            response: ProviderResponse | None = None
            current_messages = copy.deepcopy(messages)
            validation_retries = 0

            for attempt in range(self.config.max_retries + 1):
                if self._shutdown_state == ShutdownState.FORCE_STOP:
                    return

                try:
                    response = await self.provider.generate(
                        current_messages, self.response_format
                    )

                    # Validate response
                    validated = validate_response(
                        response.text, self.response_format, stats.validation
                    )
                    parsed = self.parse_fn(row, validated)
                    parsed_rows = parsed if isinstance(parsed, list) else [parsed]
                    results[row_index] = parsed_rows

                    latency_ms = (time.monotonic() - start_time) * 1000

                    # Cache store
                    if cache and cache_key:
                        cache.put(
                            cache_key, response.text,
                            response.prompt_tokens, response.completion_tokens,
                            response.model, response.provider,
                        )

                    log_entry = RequestLog(
                        row_index=row_index,
                        timestamp=datetime.now(timezone.utc).isoformat(),
                        model=response.model or self.provider.model,
                        provider=response.provider or self.provider.provider_name,
                        prompt_tokens=response.prompt_tokens,
                        completion_tokens=response.completion_tokens,
                        latency_ms=latency_ms,
                        status="success",
                        validation_retries=validation_retries,
                        input_preview=messages[-1].get("content", "")[:200],
                        output_preview=response.text[:200],
                    )
                    stats.record_request(**{
                        k: v for k, v in log_entry.to_dict().items()
                        if k in ("row_index", "model", "provider", "prompt_tokens",
                                 "completion_tokens", "latency_ms", "status",
                                 "validation_retries", "input_preview", "output_preview")
                    })
                    audit.write_entry(log_entry)

                    checkpoint.save_row(
                        row_index,
                        {"parsed_rows": parsed_rows, "status": "success"},
                    )
                    return

                except ValidationError as e:
                    validation_retries += 1
                    last_error = e
                    stats.validation.total_retries += 1

                    if validation_retries <= self.config.max_validation_retries and response:
                        # Layer 4: Re-prompt with error
                        current_messages = build_repair_messages(
                            messages, response.text, str(e)
                        )
                        logger.debug(
                            "validation_retry",
                            row_index=row_index,
                            attempt=validation_retries,
                            error=str(e),
                        )
                        continue
                    break

                except RateLimitError as e:
                    last_error = e
                    stats.record_retry()
                    await rate_limiter.report_rate_limit(e.retry_after)
                    continue

                except ProviderError as e:
                    last_error = e
                    stats.record_retry()
                    if attempt < self.config.max_retries:
                        wait = min(2 ** attempt, 30)
                        await asyncio.sleep(wait)
                        continue
                    break

                except Exception as e:
                    last_error = e
                    break

            # All retries exhausted
            latency_ms = (time.monotonic() - start_time) * 1000
            error_info = {
                "row_index": row_index,
                "error": str(last_error),
                "input": row,
            }
            failed_rows.append(error_info)

            stats.record_request(
                row_index=row_index,
                model=self.provider.model,
                provider=self.provider.provider_name,
                prompt_tokens=0,
                completion_tokens=0,
                latency_ms=latency_ms,
                status="failed",
                validation_retries=validation_retries,
                input_preview=messages[-1].get("content", "")[:200],
                output_preview=str(last_error)[:200],
            )
            checkpoint.save_row(row_index, {"status": "failed", "error": str(last_error)})
            logger.warning("row_failed", row_index=row_index, error=str(last_error))

        # Process all pending rows
        try:
            for batch_start in range(0, len(pending_indices), self.config.max_concurrent_requests):
                if self._shutdown_state == ShutdownState.FORCE_STOP:
                    break

                batch_end = batch_start + self.config.max_concurrent_requests
                batch = pending_indices[batch_start:batch_end]

                if self._shutdown_state == ShutdownState.DRAINING:
                    if dashboard:
                        dashboard.set_shutting_down(len(self._in_flight))
                    break

                tasks = []
                for idx in batch:
                    if self._shutdown_state != ShutdownState.RUNNING:
                        break
                    async with semaphore:
                        task = asyncio.create_task(_process_row(idx))
                        self._in_flight.add(task)
                        task.add_done_callback(self._in_flight.discard)
                        tasks.append(task)

                if tasks:
                    await asyncio.gather(*tasks, return_exceptions=True)

                if dashboard:
                    progress = (
                        stats.completed_count
                        + checkpoint.completed_count
                        - len(pending_indices)
                        + batch_start
                        + len(batch)
                    )
                    dashboard.update(progress)

            # Wait for any draining tasks
            if self._in_flight and self._shutdown_state == ShutdownState.DRAINING:
                logger.info("draining_in_flight", count=len(self._in_flight))
                if dashboard:
                    dashboard.set_shutting_down(len(self._in_flight))
                try:
                    await asyncio.wait_for(
                        asyncio.gather(*self._in_flight, return_exceptions=True),
                        timeout=30.0,
                    )
                except asyncio.TimeoutError:
                    logger.warning("drain_timeout", remaining=len(self._in_flight))

        finally:
            if dashboard:
                dashboard.update(stats.completed_count)
                dashboard.stop()

            # Restore signal handlers
            for sig, handler in original_handlers.items():
                try:
                    signal.signal(sig, handler)
                except (ValueError, OSError):
                    pass

            if cache:
                cache.close()

        # Collect all output rows in order
        all_output_rows: list[dict[str, Any]] = []
        for i in range(total_rows):
            if i in results:
                all_output_rows.extend(results[i])

        # Apply quality filters
        dedup_field = None
        dedup_threshold = 0.85
        for f in self.filters:
            if hasattr(f, "_dedup_field"):
                dedup_field = f._dedup_field  # type: ignore[attr-defined]
                dedup_threshold = f._dedup_threshold  # type: ignore[attr-defined]

        stats.quality.total_before_filter = len(all_output_rows)

        if dedup_field:
            all_output_rows, dedup_count = fuzzy_dedup(
                all_output_rows, dedup_field, dedup_threshold
            )
            stats.quality.duplicates_removed = dedup_count

        active_filters = [f for f in self.filters if not hasattr(f, "_dedup_field")]
        if active_filters:
            all_output_rows, filter_count = apply_filters(all_output_rows, active_filters)
            stats.quality.filtered_out = filter_count

        stats.quality.total_after_filter = len(all_output_rows)

        # Compute diversity
        if all_output_rows:
            diversity_field = dedup_field  # reuse the field if set
            stats.quality.diversity = compute_diversity(all_output_rows, diversity_field)

        # Build output
        hf_dataset = rows_to_dataset(all_output_rows)

        # Finalize stats
        final_stats = stats.finalize()

        # Write metadata sidecar
        write_metadata_sidecar(
            self.config.audit_dir,
            self.run_id,
            {
                "run_id": self.run_id,
                "model": self.provider.model,
                "config": {
                    "max_retries": self.config.max_retries,
                    "max_concurrent_requests": self.config.max_concurrent_requests,
                    "max_requests_per_minute": self.config.max_requests_per_minute,
                    "max_tokens_per_minute": self.config.max_tokens_per_minute,
                },
                **final_stats,
            },
        )

        # Save run to history
        history = RunHistory(self.config.history_file)
        history.save_run(stats.to_run_summary(self.provider.model))

        # Clean up checkpoint on full success
        if not failed_rows and self._shutdown_state == ShutdownState.RUNNING:
            checkpoint.cleanup()

        return SyndataResponse(
            dataset=hf_dataset,
            run_id=self.run_id,
            model=self.provider.model,
            token_usage=final_stats["token_usage"],
            cost=final_stats["cost"],
            performance=final_stats["performance"],
            validation=final_stats.get("validation", {}),
            quality=final_stats.get("quality", {}),
            failed=failed_rows,
            metadata=final_stats,
        )
