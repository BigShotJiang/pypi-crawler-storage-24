"""Hierarchical configuration: defaults -> config file (TOML) -> env vars -> constructor args."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from syndatalab.core.exceptions import ConfigError

_DEFAULT_BASE_DIR = Path.home() / ".syndatalab"

# Default per-model pricing ($ per 1M tokens)
DEFAULT_PRICING: dict[str, dict[str, float]] = {
    "gpt-4o": {"input": 2.50, "output": 10.00},
    "gpt-4o-mini": {"input": 0.15, "output": 0.60},
    "gpt-4.1": {"input": 2.00, "output": 8.00},
    "gpt-4.1-mini": {"input": 0.40, "output": 1.60},
    "gpt-4.1-nano": {"input": 0.10, "output": 0.40},
    "gpt-4-turbo": {"input": 10.00, "output": 30.00},
    "gpt-3.5-turbo": {"input": 0.50, "output": 1.50},
    "claude-3-5-sonnet-20241022": {"input": 3.00, "output": 15.00},
    "claude-3-5-haiku-20241022": {"input": 0.80, "output": 4.00},
    "claude-3-opus-20240229": {"input": 15.00, "output": 75.00},
    "claude-sonnet-4-20250514": {"input": 3.00, "output": 15.00},
    "claude-haiku-4-20250514": {"input": 0.80, "output": 4.00},
}


@dataclass
class SyndatalabConfig:
    model: str = "gpt-4o-mini"
    max_retries: int = 3
    max_concurrent_requests: int = 50
    max_requests_per_minute: int = 500
    max_tokens_per_minute: int = 200_000
    max_validation_retries: int = 2
    show_dashboard: bool = True

    cache_enabled: bool = True
    cache_dir: Path = field(default_factory=lambda: _DEFAULT_BASE_DIR / "cache")
    cache_ttl_days: int = 30

    checkpoint_dir: Path = field(default_factory=lambda: _DEFAULT_BASE_DIR / "checkpoints")
    audit_dir: Path = field(default_factory=lambda: _DEFAULT_BASE_DIR / "audit")
    log_dir: Path = field(default_factory=lambda: _DEFAULT_BASE_DIR / "logs")
    history_file: Path = field(default_factory=lambda: _DEFAULT_BASE_DIR / "history.jsonl")

    log_level: str = "INFO"
    log_file: str | None = None

    pricing: dict[str, dict[str, float]] = field(default_factory=lambda: dict(DEFAULT_PRICING))

    # Provider-specific
    openai_api_key: str | None = None
    anthropic_api_key: str | None = None
    ollama_host: str = "http://localhost:11434"

    # Failover
    failover_on: list[int] = field(default_factory=lambda: [429, 500, 502, 503, 504])
    fallback_models: list[str] = field(default_factory=list)

    def get_model_pricing(self, model: str) -> dict[str, float]:
        """Get pricing for a model, falling back to zero if unknown."""
        return self.pricing.get(model, {"input": 0.0, "output": 0.0})

    def ensure_dirs(self) -> None:
        """Create all necessary directories."""
        for d in [self.cache_dir, self.checkpoint_dir, self.audit_dir, self.log_dir]:
            d.mkdir(parents=True, exist_ok=True)


def _load_toml(path: Path) -> dict[str, Any]:
    """Load a TOML config file."""
    if not path.exists():
        return {}
    try:
        import tomllib
    except ModuleNotFoundError:
        try:
            import tomli as tomllib  # type: ignore[no-redef]
        except ModuleNotFoundError:
            return {}
    with open(path, "rb") as f:
        return tomllib.load(f)


def _env(key: str) -> str | None:
    return os.environ.get(f"SYNDATALAB_{key.upper()}")


def load_config(**overrides: Any) -> SyndatalabConfig:
    """Load config with priority: overrides > env vars > config file > defaults."""
    config_path = os.environ.get("SYNDATALAB_CONFIG", str(_DEFAULT_BASE_DIR / "config.toml"))
    file_config = _load_toml(Path(config_path))

    cfg = SyndatalabConfig()

    # Layer 1: Apply TOML file values
    defaults_section = file_config.get("defaults", {})
    rate_section = file_config.get("rate_limits", {})
    logging_section = file_config.get("logging", {})
    cost_section = file_config.get("cost", {})

    field_map = {
        "model": defaults_section.get("model"),
        "max_retries": defaults_section.get("max_retries"),
        "max_concurrent_requests": defaults_section.get("max_concurrent_requests"),
        "show_dashboard": defaults_section.get("show_dashboard"),
        "cache_enabled": defaults_section.get("cache_enabled"),
        "max_requests_per_minute": rate_section.get("max_requests_per_minute"),
        "max_tokens_per_minute": rate_section.get("max_tokens_per_minute"),
        "log_level": logging_section.get("level"),
        "log_file": logging_section.get("file"),
    }

    for k, v in field_map.items():
        if v is not None:
            setattr(cfg, k, v)

    for model_key, pricing in cost_section.items():
        if isinstance(pricing, dict) and "input" in pricing and "output" in pricing:
            cfg.pricing[model_key] = {"input": pricing["input"], "output": pricing["output"]}

    # Layer 2: Apply env vars
    env_map = {
        "MODEL": ("model", str),
        "MAX_RETRIES": ("max_retries", int),
        "MAX_CONCURRENT_REQUESTS": ("max_concurrent_requests", int),
        "MAX_REQUESTS_PER_MINUTE": ("max_requests_per_minute", int),
        "MAX_TOKENS_PER_MINUTE": ("max_tokens_per_minute", int),
        "SHOW_DASHBOARD": ("show_dashboard", lambda v: v.lower() in ("1", "true", "yes")),
        "CACHE_ENABLED": ("cache_enabled", lambda v: v.lower() in ("1", "true", "yes")),
        "CACHE_DIR": ("cache_dir", Path),
        "LOG_LEVEL": ("log_level", str),
    }
    for env_key, (attr, converter) in env_map.items():
        val = _env(env_key)
        if val is not None:
            try:
                setattr(cfg, attr, converter(val))
            except (ValueError, TypeError) as e:
                raise ConfigError(f"Invalid env var SYNDATALAB_{env_key}={val}: {e}") from e

    # Standard provider env vars (not prefixed)
    cfg.openai_api_key = os.environ.get("OPENAI_API_KEY", cfg.openai_api_key)
    cfg.anthropic_api_key = os.environ.get("ANTHROPIC_API_KEY", cfg.anthropic_api_key)
    cfg.ollama_host = os.environ.get("OLLAMA_HOST", cfg.ollama_host)

    # Layer 3: Apply constructor overrides
    for k, v in overrides.items():
        if v is not None and hasattr(cfg, k):
            setattr(cfg, k, v)

    return cfg
