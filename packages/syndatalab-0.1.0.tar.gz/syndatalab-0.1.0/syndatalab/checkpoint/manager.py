"""Checkpoint/resume system with atomic JSONL writes and graceful shutdown."""

from __future__ import annotations

import hashlib
import json
import os
import tempfile
from pathlib import Path
from typing import Any

from syndatalab.core.exceptions import CheckpointError
from syndatalab.logging.setup import get_logger

logger = get_logger(__name__)


def compute_run_id(
    llm_class_name: str,
    model: str,
    dataset_fingerprint: str,
    generation_params: dict[str, Any] | None = None,
) -> str:
    """Compute a deterministic run ID from the generation parameters."""
    raw = json.dumps(
        {
            "llm_class": llm_class_name,
            "model": model,
            "dataset": dataset_fingerprint,
            "params": generation_params or {},
        },
        sort_keys=True,
    )
    return hashlib.sha256(raw.encode()).hexdigest()[:16]


def dataset_fingerprint(dataset: list[dict[str, Any]]) -> str:
    """Compute a fingerprint for a dataset."""
    raw = json.dumps(dataset, sort_keys=True, ensure_ascii=True)
    return hashlib.sha256(raw.encode()).hexdigest()[:16]


class CheckpointManager:
    """Manages checkpointing for pipeline runs."""

    def __init__(self, checkpoint_dir: Path, run_id: str):
        self.checkpoint_dir = checkpoint_dir
        self.run_id = run_id
        self.checkpoint_path = checkpoint_dir / f"{run_id}.jsonl"
        self._completed: dict[int, dict[str, Any]] = {}
        self._ensure_dir()

    def _ensure_dir(self) -> None:
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)

    def load_existing(self) -> dict[int, dict[str, Any]]:
        """Load completed rows from an existing checkpoint. Returns {row_index: result_data}."""
        self._completed = {}
        if not self.checkpoint_path.exists():
            return self._completed

        try:
            with open(self.checkpoint_path) as f:
                for line_num, line in enumerate(f, 1):
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        data = json.loads(line)
                        row_idx = data.get("row_index")
                        if row_idx is not None:
                            self._completed[row_idx] = data
                    except json.JSONDecodeError:
                        logger.warning(
                            "corrupt_checkpoint_line",
                            line_num=line_num,
                            run_id=self.run_id,
                        )
        except OSError as e:
            raise CheckpointError(f"Failed to read checkpoint {self.checkpoint_path}: {e}") from e

        logger.info(
            "checkpoint_loaded",
            run_id=self.run_id,
            completed_rows=len(self._completed),
        )
        return self._completed

    def is_completed(self, row_index: int) -> bool:
        return row_index in self._completed

    def get_completed(self, row_index: int) -> dict[str, Any] | None:
        return self._completed.get(row_index)

    @property
    def completed_count(self) -> int:
        return len(self._completed)

    @property
    def completed_indices(self) -> set[int]:
        return set(self._completed.keys())

    def save_row(self, row_index: int, data: dict[str, Any]) -> None:
        """Atomically append a completed row to the checkpoint file."""
        entry = {"row_index": row_index, **data}
        line = json.dumps(entry, ensure_ascii=True) + "\n"

        # Atomic write: write to temp file, fsync, then append to checkpoint
        try:
            fd, tmp_path = tempfile.mkstemp(
                dir=str(self.checkpoint_dir), suffix=".tmp", prefix=".ckpt_"
            )
            try:
                os.write(fd, line.encode())
                os.fsync(fd)
            finally:
                os.close(fd)

            # Append the temp file contents to the checkpoint
            with open(self.checkpoint_path, "a") as f:
                f.write(line)
                f.flush()
                os.fsync(f.fileno())

            self._completed[row_index] = entry
        except OSError as e:
            raise CheckpointError(f"Failed to save checkpoint: {e}") from e
        finally:
            try:
                os.unlink(tmp_path)
            except OSError:
                pass

    def cleanup(self) -> None:
        """Remove checkpoint file after successful completion."""
        try:
            if self.checkpoint_path.exists():
                self.checkpoint_path.unlink()
                logger.info("checkpoint_cleaned", run_id=self.run_id)
        except OSError as e:
            logger.warning("checkpoint_cleanup_failed", run_id=self.run_id, error=str(e))
