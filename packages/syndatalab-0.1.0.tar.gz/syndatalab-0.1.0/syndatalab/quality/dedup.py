"""Exact and fuzzy deduplication for generated outputs."""

from __future__ import annotations

import hashlib
from typing import Any

from syndatalab.logging.setup import get_logger

logger = get_logger(__name__)


def _get_field_text(row: dict[str, Any], field: str | None) -> str:
    """Extract text from a row for dedup comparison."""
    if field and field in row:
        val = row[field]
        return str(val) if not isinstance(val, str) else val
    return str(row)


def exact_dedup(
    rows: list[dict[str, Any]],
    field: str | None = None,
) -> tuple[list[dict[str, Any]], int]:
    """Remove exact duplicates. Returns (deduplicated rows, count removed)."""
    seen: set[str] = set()
    result = []
    removed = 0
    for row in rows:
        text = _get_field_text(row, field)
        h = hashlib.sha256(text.encode()).hexdigest()
        if h in seen:
            removed += 1
            continue
        seen.add(h)
        result.append(row)
    return result, removed


def fuzzy_dedup(
    rows: list[dict[str, Any]],
    field: str | None = None,
    threshold: float = 0.85,
    num_perm: int = 128,
) -> tuple[list[dict[str, Any]], int]:
    """Remove near-duplicates using MinHash + LSH.

    Requires the `datasketch` package (install with `pip install syndatalab[quality]`).
    Falls back to exact dedup if datasketch is not available.
    """
    try:
        from datasketch import MinHash, MinHashLSH
    except ImportError:
        logger.warning("datasketch_not_installed", message="Falling back to exact dedup")
        return exact_dedup(rows, field)

    lsh = MinHashLSH(threshold=threshold, num_perm=num_perm)
    minhashes: list[tuple[int, MinHash]] = []
    removed_indices: set[int] = set()

    for i, row in enumerate(rows):
        text = _get_field_text(row, field)
        m = MinHash(num_perm=num_perm)
        for token in text.lower().split():
            m.update(token.encode("utf-8"))
        minhashes.append((i, m))

        # Check for duplicates
        result = lsh.query(m)
        if result:
            removed_indices.add(i)
        else:
            try:
                lsh.insert(str(i), m)
            except ValueError:
                # Duplicate key in LSH
                removed_indices.add(i)

    deduplicated = [row for i, row in enumerate(rows) if i not in removed_indices]
    return deduplicated, len(removed_indices)
