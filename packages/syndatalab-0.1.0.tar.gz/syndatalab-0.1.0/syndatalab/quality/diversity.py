"""Diversity scoring for generated datasets."""

from __future__ import annotations

from typing import Any

from syndatalab.logging.setup import get_logger
from syndatalab.stats.models import DiversityStats

logger = get_logger(__name__)


def _get_texts(rows: list[dict[str, Any]], field: str | None = None) -> list[str]:
    """Extract text from rows."""
    texts = []
    for row in rows:
        if field and field in row:
            texts.append(str(row[field]))
        else:
            texts.append(str(row))
    return texts


def _ngrams(tokens: list[str], n: int) -> list[tuple[str, ...]]:
    return [tuple(tokens[i : i + n]) for i in range(len(tokens) - n + 1)]


def compute_diversity(
    rows: list[dict[str, Any]],
    field: str | None = None,
) -> DiversityStats:
    """Compute diversity metrics across the dataset."""
    texts = _get_texts(rows, field)

    if not texts:
        return DiversityStats()

    all_bigrams: list[tuple[str, ...]] = []
    all_trigrams: list[tuple[str, ...]] = []
    all_tokens: list[str] = []

    for text in texts:
        tokens = text.lower().split()
        all_tokens.extend(tokens)
        all_bigrams.extend(_ngrams(tokens, 2))
        all_trigrams.extend(_ngrams(tokens, 3))

    # Diversity = unique / total
    bigram_div = len(set(all_bigrams)) / len(all_bigrams) if all_bigrams else 0.0
    trigram_div = len(set(all_trigrams)) / len(all_trigrams) if all_trigrams else 0.0

    # Vocabulary richness (type-token ratio)
    vocab_richness = len(set(all_tokens)) / len(all_tokens) if all_tokens else 0.0

    stats = DiversityStats(
        bigram_diversity=bigram_div,
        trigram_diversity=trigram_div,
        vocab_richness=vocab_richness,
    )

    # Optional: semantic diversity via sentence-transformers
    try:
        import numpy as np
        from sentence_transformers import SentenceTransformer

        model = SentenceTransformer("all-MiniLM-L6-v2")
        embeddings = model.encode(texts[:1000])  # Cap at 1000 for performance
        # Mean pairwise cosine distance
        norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
        normalized = embeddings / (norms + 1e-10)
        similarity_matrix = normalized @ normalized.T
        n = len(similarity_matrix)
        if n > 1:
            mask = ~np.eye(n, dtype=bool)
            mean_sim = similarity_matrix[mask].mean()
            stats.semantic_diversity = float(1.0 - mean_sim)
    except ImportError:
        pass
    except Exception as e:
        logger.warning("semantic_diversity_failed", error=str(e))

    return stats
