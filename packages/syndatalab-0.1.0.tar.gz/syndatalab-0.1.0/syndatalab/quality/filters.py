"""Built-in and user-defined quality filters."""

from __future__ import annotations

import re
from typing import Any, Callable

from syndatalab.logging.setup import get_logger

logger = get_logger(__name__)

FilterFunc = Callable[[dict[str, Any]], bool]


def min_length(field: str, min_len: int) -> FilterFunc:
    """Filter rows where a field's text length is below minimum."""

    def _filter(row: dict[str, Any]) -> bool:
        val = row.get(field, "")
        return len(str(val)) >= min_len

    _filter.__qualname__ = f"min_length({field!r}, {min_len})"
    return _filter


def max_length(field: str, max_len: int) -> FilterFunc:
    """Filter rows where a field's text length exceeds maximum."""

    def _filter(row: dict[str, Any]) -> bool:
        val = row.get(field, "")
        return len(str(val)) <= max_len

    _filter.__qualname__ = f"max_length({field!r}, {max_len})"
    return _filter


def regex_match(field: str, pattern: str) -> FilterFunc:
    """Keep only rows where the field matches the regex pattern."""
    compiled = re.compile(pattern)

    def _filter(row: dict[str, Any]) -> bool:
        val = str(row.get(field, ""))
        return bool(compiled.search(val))

    _filter.__qualname__ = f"regex_match({field!r}, {pattern!r})"
    return _filter


def regex_exclude(field: str, pattern: str) -> FilterFunc:
    """Remove rows where the field matches the regex pattern."""
    compiled = re.compile(pattern)

    def _filter(row: dict[str, Any]) -> bool:
        val = str(row.get(field, ""))
        return not compiled.search(val)

    _filter.__qualname__ = f"regex_exclude({field!r}, {pattern!r})"
    return _filter


def not_empty(*fields: str) -> FilterFunc:
    """Remove rows where any of the specified fields are empty/None."""

    def _filter(row: dict[str, Any]) -> bool:
        for f in fields:
            val = row.get(f)
            if val is None or (isinstance(val, str) and not val.strip()):
                return False
        return True

    _filter.__qualname__ = f"not_empty({', '.join(repr(f) for f in fields)})"
    return _filter


def no_duplicates(field: str, threshold: float = 0.85) -> FilterFunc:
    """Placeholder - dedup is handled separately in the pipeline via dedup module.

    This filter is a no-op; actual dedup happens in the quality pipeline.
    The threshold is stored for use by the pipeline.
    """
    def _filter(row: dict[str, Any]) -> bool:
        return True

    _filter.__qualname__ = f"no_duplicates({field!r}, threshold={threshold})"
    _filter._dedup_field = field  # type: ignore[attr-defined]
    _filter._dedup_threshold = threshold  # type: ignore[attr-defined]
    return _filter


def custom(func: Callable[[dict[str, Any]], bool]) -> FilterFunc:
    """Wrap a user-defined filter function."""
    return func


def apply_filters(
    rows: list[dict[str, Any]],
    filters: list[FilterFunc],
) -> tuple[list[dict[str, Any]], int]:
    """Apply all filters to the rows. Returns (filtered rows, count removed)."""
    if not filters:
        return rows, 0

    result = []
    removed = 0
    for row in rows:
        keep = True
        for f in filters:
            # Skip dedup placeholder filters
            if hasattr(f, "_dedup_field"):
                continue
            try:
                if not f(row):
                    keep = False
                    break
            except Exception as e:
                logger.warning(
                    "filter_error",
                    filter=getattr(f, "__qualname__", str(f)),
                    error=str(e),
                )
                keep = False
                break
        if keep:
            result.append(row)
        else:
            removed += 1

    return result, removed
