"""Failover provider that tries a chain of providers in order."""

from __future__ import annotations

import copy
from typing import Any, Type

from pydantic import BaseModel

from syndatalab.core.exceptions import ProviderError, ProviderUnavailableError, RateLimitError
from syndatalab.logging.setup import get_logger
from syndatalab.providers.base import BaseProvider, ProviderResponse
from syndatalab.providers.registry import create_provider

logger = get_logger(__name__)


class FailoverProvider(BaseProvider):
    """Wraps multiple providers and tries them in order on failure."""

    provider_name = "failover"

    def __init__(
        self,
        primary: BaseProvider,
        fallbacks: list[BaseProvider] | None = None,
        failover_on: list[int] | None = None,
    ):
        super().__init__(model=primary.model)
        self.primary = primary
        self.fallbacks = fallbacks or []
        self.failover_on = set(failover_on or [429, 500, 502, 503, 504])
        self._all_providers = [primary] + self.fallbacks

    @classmethod
    def from_model_list(
        cls,
        primary_model: str,
        fallback_models: list[str],
        api_key: str | None = None,
        base_url: str | None = None,
        extra_headers: dict[str, str] | None = None,
        failover_on: list[int] | None = None,
    ) -> FailoverProvider:
        """Create a failover provider from a list of model names."""
        primary = create_provider(
            primary_model, api_key=api_key, base_url=base_url, extra_headers=extra_headers,
        )
        fallbacks = [create_provider(m) for m in fallback_models]
        return cls(primary=primary, fallbacks=fallbacks, failover_on=failover_on)

    def _should_failover(self, error: Exception) -> bool:
        if isinstance(error, RateLimitError):
            return True
        if isinstance(error, ProviderError) and error.status_code in self.failover_on:
            return True
        if isinstance(error, ProviderUnavailableError):
            return True
        if isinstance(error, (TimeoutError, ConnectionError, OSError)):
            return True
        return False

    async def generate(
        self,
        messages: list[dict[str, str]],
        response_format: Type[BaseModel] | None = None,
        generation_params: dict[str, Any] | None = None,
    ) -> ProviderResponse:
        last_error: Exception | None = None
        attempted_providers: list[str] = []

        for provider in self._all_providers:
            try:
                msgs_copy = copy.deepcopy(messages)
                response = await provider.generate(msgs_copy, response_format, generation_params)
                if attempted_providers:
                    response.provider = (
                        f"{provider.provider_name} "
                        f"(failover from {attempted_providers[0]})"
                    )
                return response
            except Exception as e:
                attempted_providers.append(provider.provider_name)
                last_error = e
                logger.warning(
                    "provider_failed",
                    provider=provider.provider_name,
                    model=provider.model,
                    error=str(e),
                )
                if not self._should_failover(e):
                    raise
                continue

        raise ProviderUnavailableError(
            f"All providers failed. Last error: {last_error}. "
            f"Tried: {', '.join(attempted_providers)}",
            provider="failover",
        )

    async def health_check(self) -> bool:
        for provider in self._all_providers:
            if await provider.health_check():
                return True
        return False
