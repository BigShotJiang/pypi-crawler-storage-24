"""Abstract provider interface and ProviderResponse model."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Type

from pydantic import BaseModel


@dataclass
class ProviderResponse:
    text: str
    prompt_tokens: int
    completion_tokens: int
    finish_reason: str | None = None
    model: str | None = None
    provider: str | None = None
    raw: Any = None

    @property
    def total_tokens(self) -> int:
        return self.prompt_tokens + self.completion_tokens


class BaseProvider(ABC):
    """Abstract base for all LLM providers."""

    provider_name: str = "base"

    def __init__(
        self,
        model: str,
        api_key: str | None = None,
        base_url: str | None = None,
        extra_headers: dict[str, str] | None = None,
    ):
        self.model = model
        self.api_key = api_key
        self.base_url = base_url
        self.extra_headers = extra_headers

    @abstractmethod
    async def generate(
        self,
        messages: list[dict[str, str]],
        response_format: Type[BaseModel] | None = None,
        generation_params: dict[str, Any] | None = None,
    ) -> ProviderResponse:
        """Generate a response from the LLM."""
        ...

    @abstractmethod
    async def health_check(self) -> bool:
        """Lightweight check that the provider is reachable."""
        ...

    def _build_json_schema_instruction(self, response_format: Type[BaseModel]) -> str:
        """Build a system instruction to request JSON output matching the schema."""
        schema = response_format.model_json_schema()
        return (
            f"You MUST respond with valid JSON matching this schema:\n"
            f"{schema}\n"
            f"Respond ONLY with the JSON object. No markdown, no explanation."
        )
