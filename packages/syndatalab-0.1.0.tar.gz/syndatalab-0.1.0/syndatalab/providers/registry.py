"""Auto-detect provider from model name and create instances."""

from __future__ import annotations

import re
from typing import Any

from syndatalab.core.exceptions import ConfigError
from syndatalab.providers.base import BaseProvider

# Pattern -> (provider_module, provider_class)
_PROVIDER_PATTERNS: list[tuple[str, str, str]] = [
    (r"^gpt-", "syndatalab.providers.openai", "OpenAIProvider"),
    (r"^o[1-9]", "syndatalab.providers.openai", "OpenAIProvider"),
    (r"^claude-", "syndatalab.providers.anthropic", "AnthropicProvider"),
    (r"^ollama/", "syndatalab.providers.ollama", "OllamaProvider"),
]

_BACKEND_MAP: dict[str, tuple[str, str]] = {
    "openai": ("syndatalab.providers.openai", "OpenAIProvider"),
    "anthropic": ("syndatalab.providers.anthropic", "AnthropicProvider"),
    "litellm": ("syndatalab.providers.litellm", "LiteLLMProvider"),
    "ollama": ("syndatalab.providers.ollama", "OllamaProvider"),
}


def _import_provider(module_path: str, class_name: str) -> type[BaseProvider]:
    """Dynamically import a provider class."""
    import importlib

    module = importlib.import_module(module_path)
    return getattr(module, class_name)


def detect_provider_name(model: str) -> str | None:
    """Detect provider name from model string."""
    for pattern, _, _ in _PROVIDER_PATTERNS:
        if re.match(pattern, model):
            for name, (mod, _) in _BACKEND_MAP.items():
                matching_mod = [m for p, m, _ in _PROVIDER_PATTERNS if re.match(p, model)]
                if matching_mod and matching_mod[0] == mod:
                    return name
    return None


def create_provider(
    model: str,
    backend: str | None = None,
    api_key: str | None = None,
    base_url: str | None = None,
    extra_headers: dict[str, str] | None = None,
) -> BaseProvider:
    """Create a provider instance, auto-detecting from model name or using explicit backend."""
    kwargs: dict[str, Any] = {
        "model": model,
        "api_key": api_key,
        "base_url": base_url,
        "extra_headers": extra_headers,
    }

    if backend:
        if backend not in _BACKEND_MAP:
            raise ConfigError(
                f"Unknown backend '{backend}'. Available: {', '.join(_BACKEND_MAP.keys())}"
            )
        module_path, class_name = _BACKEND_MAP[backend]
        provider_cls = _import_provider(module_path, class_name)
        return provider_cls(**kwargs)

    for pattern, module_path, class_name in _PROVIDER_PATTERNS:
        if re.match(pattern, model):
            provider_cls = _import_provider(module_path, class_name)
            return provider_cls(**kwargs)

    # Default to LiteLLM as universal fallback
    module_path, class_name = _BACKEND_MAP["litellm"]
    provider_cls = _import_provider(module_path, class_name)
    return provider_cls(**kwargs)
