"""LiteLLM provider - unified interface to 100+ LLM providers."""

from __future__ import annotations

from typing import Any, Type

from pydantic import BaseModel

from syndatalab.core.exceptions import (
    AuthenticationError,
    ProviderNotInstalledError,
    ProviderUnavailableError,
    RateLimitError,
)
from syndatalab.providers.base import BaseProvider, ProviderResponse

try:
    import litellm

    litellm.suppress_debug_info = True
except ImportError:
    litellm = None  # type: ignore[assignment]


class LiteLLMProvider(BaseProvider):
    provider_name = "litellm"

    def __init__(
        self,
        model: str,
        api_key: str | None = None,
        base_url: str | None = None,
        extra_headers: dict[str, str] | None = None,
    ):
        super().__init__(model, api_key, base_url, extra_headers)
        if litellm is None:
            raise ProviderNotInstalledError("litellm")

    async def generate(
        self,
        messages: list[dict[str, str]],
        response_format: Type[BaseModel] | None = None,
        generation_params: dict[str, Any] | None = None,
    ) -> ProviderResponse:
        params = dict(generation_params or {})
        params["model"] = self.model
        params["messages"] = messages

        if self.api_key:
            params["api_key"] = self.api_key
        if self.base_url:
            params["api_base"] = self.base_url

        if response_format is not None:
            params["response_format"] = {"type": "json_object"}
            schema_instruction = self._build_json_schema_instruction(response_format)
            if messages and messages[0].get("role") == "system":
                messages[0]["content"] += f"\n\n{schema_instruction}"
            else:
                messages.insert(0, {"role": "system", "content": schema_instruction})

        try:
            response = await litellm.acompletion(**params)
        except Exception as e:
            err_str = str(e).lower()
            if "authentication" in err_str or "401" in err_str or "403" in err_str:
                raise AuthenticationError(str(e), provider="litellm") from e
            if "rate" in err_str and "limit" in err_str or "429" in err_str:
                raise RateLimitError(str(e), provider="litellm") from e
            raise ProviderUnavailableError(str(e), provider="litellm") from e

        choice = response.choices[0]
        usage = response.usage

        return ProviderResponse(
            text=choice.message.content or "",
            prompt_tokens=usage.prompt_tokens if usage else 0,
            completion_tokens=usage.completion_tokens if usage else 0,
            finish_reason=choice.finish_reason,
            model=response.model if hasattr(response, "model") else self.model,
            provider="litellm",
            raw=response,
        )

    async def health_check(self) -> bool:
        try:
            await litellm.acompletion(
                model=self.model,
                messages=[{"role": "user", "content": "ping"}],
                max_tokens=1,
                api_key=self.api_key,
            )
            return True
        except Exception:
            return False
