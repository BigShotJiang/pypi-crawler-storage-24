"""OpenAI provider implementation."""

from __future__ import annotations

from typing import Any, Type

from pydantic import BaseModel

from syndatalab.core.exceptions import (
    AuthenticationError,
    ProviderNotInstalledError,
    ProviderUnavailableError,
    RateLimitError,
)
from syndatalab.providers.base import BaseProvider, ProviderResponse

try:
    import openai
except ImportError:
    openai = None  # type: ignore[assignment]


class OpenAIProvider(BaseProvider):
    provider_name = "openai"

    def __init__(
        self,
        model: str,
        api_key: str | None = None,
        base_url: str | None = None,
        extra_headers: dict[str, str] | None = None,
    ):
        super().__init__(model, api_key, base_url, extra_headers)
        if openai is None:
            raise ProviderNotInstalledError("openai")
        kwargs: dict[str, Any] = {}
        if api_key:
            kwargs["api_key"] = api_key
        if base_url:
            kwargs["base_url"] = base_url
        if extra_headers:
            kwargs["default_headers"] = extra_headers
        self.client = openai.AsyncOpenAI(**kwargs)

    async def generate(
        self,
        messages: list[dict[str, str]],
        response_format: Type[BaseModel] | None = None,
        generation_params: dict[str, Any] | None = None,
    ) -> ProviderResponse:
        params = dict(generation_params or {})
        params["model"] = self.model
        params["messages"] = messages

        if response_format is not None:
            params["response_format"] = {"type": "json_object"}
            schema_instruction = self._build_json_schema_instruction(response_format)
            if messages and messages[0].get("role") == "system":
                messages[0]["content"] += f"\n\n{schema_instruction}"
            else:
                messages.insert(0, {"role": "system", "content": schema_instruction})

        try:
            response = await self.client.chat.completions.create(**params)
        except openai.AuthenticationError as e:
            raise AuthenticationError(str(e), provider="openai") from e
        except openai.RateLimitError as e:
            retry_after = None
            if hasattr(e, "response") and e.response is not None:
                retry_after_header = e.response.headers.get("retry-after")
                if retry_after_header:
                    try:
                        retry_after = float(retry_after_header)
                    except ValueError:
                        pass
            raise RateLimitError(str(e), provider="openai", retry_after=retry_after) from e
        except openai.APIStatusError as e:
            raise ProviderUnavailableError(
                str(e), provider="openai", status_code=e.status_code
            ) from e
        except openai.APIConnectionError as e:
            raise ProviderUnavailableError(str(e), provider="openai") from e

        choice = response.choices[0]
        usage = response.usage

        return ProviderResponse(
            text=choice.message.content or "",
            prompt_tokens=usage.prompt_tokens if usage else 0,
            completion_tokens=usage.completion_tokens if usage else 0,
            finish_reason=choice.finish_reason,
            model=response.model,
            provider="openai",
            raw=response,
        )

    async def health_check(self) -> bool:
        try:
            await self.client.models.list()
            return True
        except Exception:
            return False
