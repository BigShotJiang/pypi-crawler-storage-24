"""Anthropic provider implementation."""

from __future__ import annotations

from typing import Any, Type

from pydantic import BaseModel

from syndatalab.core.exceptions import (
    AuthenticationError,
    ProviderNotInstalledError,
    ProviderUnavailableError,
    RateLimitError,
)
from syndatalab.providers.base import BaseProvider, ProviderResponse

try:
    import anthropic
except ImportError:
    anthropic = None  # type: ignore[assignment]


class AnthropicProvider(BaseProvider):
    provider_name = "anthropic"

    def __init__(
        self,
        model: str,
        api_key: str | None = None,
        base_url: str | None = None,
        extra_headers: dict[str, str] | None = None,
    ):
        super().__init__(model, api_key, base_url, extra_headers)
        if anthropic is None:
            raise ProviderNotInstalledError("anthropic")
        kwargs: dict[str, Any] = {}
        if api_key:
            kwargs["api_key"] = api_key
        if base_url:
            kwargs["base_url"] = base_url
        if extra_headers:
            kwargs["default_headers"] = extra_headers
        self.client = anthropic.AsyncAnthropic(**kwargs)

    async def generate(
        self,
        messages: list[dict[str, str]],
        response_format: Type[BaseModel] | None = None,
        generation_params: dict[str, Any] | None = None,
    ) -> ProviderResponse:
        params = dict(generation_params or {})
        params["model"] = self.model
        params.setdefault("max_tokens", 4096)

        system_msg = None
        user_messages = []
        for msg in messages:
            if msg["role"] == "system":
                system_msg = msg["content"]
            else:
                user_messages.append(msg)

        if response_format is not None:
            schema_instruction = self._build_json_schema_instruction(response_format)
            if system_msg:
                system_msg += f"\n\n{schema_instruction}"
            else:
                system_msg = schema_instruction

        if system_msg:
            params["system"] = system_msg
        params["messages"] = user_messages

        try:
            response = await self.client.messages.create(**params)
        except anthropic.AuthenticationError as e:
            raise AuthenticationError(str(e), provider="anthropic") from e
        except anthropic.RateLimitError as e:
            retry_after = None
            if hasattr(e, "response") and e.response is not None:
                retry_after_header = e.response.headers.get("retry-after")
                if retry_after_header:
                    try:
                        retry_after = float(retry_after_header)
                    except ValueError:
                        pass
            raise RateLimitError(str(e), provider="anthropic", retry_after=retry_after) from e
        except anthropic.APIStatusError as e:
            raise ProviderUnavailableError(
                str(e), provider="anthropic", status_code=e.status_code
            ) from e
        except anthropic.APIConnectionError as e:
            raise ProviderUnavailableError(str(e), provider="anthropic") from e

        text_parts = [block.text for block in response.content if hasattr(block, "text")]
        text = "\n".join(text_parts)
        usage = response.usage

        return ProviderResponse(
            text=text,
            prompt_tokens=usage.input_tokens,
            completion_tokens=usage.output_tokens,
            finish_reason=response.stop_reason,
            model=response.model,
            provider="anthropic",
            raw=response,
        )

    async def health_check(self) -> bool:
        try:
            await self.client.messages.create(
                model=self.model,
                max_tokens=1,
                messages=[{"role": "user", "content": "ping"}],
            )
            return True
        except Exception:
            return False
