"""Ollama provider for local models."""

from __future__ import annotations

from typing import Any, Type

from pydantic import BaseModel

from syndatalab.core.exceptions import (
    ProviderNotInstalledError,
    ProviderUnavailableError,
)
from syndatalab.providers.base import BaseProvider, ProviderResponse

try:
    import ollama as ollama_lib
except ImportError:
    ollama_lib = None  # type: ignore[assignment]


class OllamaProvider(BaseProvider):
    provider_name = "ollama"

    def __init__(
        self,
        model: str,
        api_key: str | None = None,
        base_url: str | None = None,
        extra_headers: dict[str, str] | None = None,
    ):
        super().__init__(model, api_key, base_url, extra_headers)
        if ollama_lib is None:
            raise ProviderNotInstalledError("ollama")
        # Strip the "ollama/" prefix if present
        self.ollama_model = model.removeprefix("ollama/")
        self.host = base_url or "http://localhost:11434"
        self.client = ollama_lib.AsyncClient(host=self.host)

    async def generate(
        self,
        messages: list[dict[str, str]],
        response_format: Type[BaseModel] | None = None,
        generation_params: dict[str, Any] | None = None,
    ) -> ProviderResponse:
        params = dict(generation_params or {})

        if response_format is not None:
            schema_instruction = self._build_json_schema_instruction(response_format)
            if messages and messages[0].get("role") == "system":
                messages[0]["content"] += f"\n\n{schema_instruction}"
            else:
                messages.insert(0, {"role": "system", "content": schema_instruction})
            params["format"] = "json"

        try:
            response = await self.client.chat(
                model=self.ollama_model,
                messages=messages,
                options=params.get("options", {}),
                format=params.get("format"),
            )
        except Exception as e:
            raise ProviderUnavailableError(str(e), provider="ollama") from e

        text = response.get("message", {}).get("content", "")

        # Ollama provides token counts differently
        prompt_tokens = response.get("prompt_eval_count", 0) or 0
        completion_tokens = response.get("eval_count", 0) or 0

        return ProviderResponse(
            text=text,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            finish_reason=response.get("done_reason"),
            model=self.ollama_model,
            provider="ollama",
            raw=response,
        )

    async def health_check(self) -> bool:
        try:
            await self.client.list()
            return True
        except Exception:
            return False
