"""CLI for syndatalab: cache management, run history, output inspection."""

from __future__ import annotations

import json

import click
from rich.console import Console
from rich.table import Table

from syndatalab.core.config import load_config

console = Console()


@click.group()
def cli() -> None:
    """syndatalab — synthetic data generation toolkit."""


@cli.group()
def cache() -> None:
    """Cache management commands."""


@cache.command("stats")
def cache_stats() -> None:
    """Show cache statistics."""
    from syndatalab.cache.sqlite_cache import SQLiteCache

    config = load_config()
    c = SQLiteCache(config.cache_dir, config.cache_ttl_days)
    s = c.stats()

    table = Table(title="Cache Statistics")
    table.add_column("Metric", style="cyan")
    table.add_column("Value", style="green")

    table.add_row("Entries", str(s["entries"]))
    table.add_row("Expired entries", str(s["expired_entries"]))
    table.add_row("Size", f"{s['size_mb']} MB")
    table.add_row("Path", s["db_path"])

    console.print(table)
    c.close()


@cache.command("clear")
@click.confirmation_option(prompt="Are you sure you want to clear the cache?")
def cache_clear() -> None:
    """Clear all cache entries."""
    from syndatalab.cache.sqlite_cache import SQLiteCache

    config = load_config()
    c = SQLiteCache(config.cache_dir, config.cache_ttl_days)
    count = c.clear()
    console.print(f"[green]Cleared {count} cache entries.[/green]")
    c.close()


@cache.command("export")
@click.argument("output_file", type=click.Path())
def cache_export(output_file: str) -> None:
    """Export cache entries to a JSONL file."""
    from syndatalab.cache.sqlite_cache import SQLiteCache

    config = load_config()
    c = SQLiteCache(config.cache_dir, config.cache_ttl_days)
    entries = c.export_entries()

    with open(output_file, "w") as f:
        for entry in entries:
            f.write(json.dumps(entry) + "\n")

    console.print(f"[green]Exported {len(entries)} entries to {output_file}[/green]")
    c.close()


@cli.command("history")
@click.argument("run_id", required=False)
def history(run_id: str | None = None) -> None:
    """Show run history. Optionally filter by run_id."""
    from syndatalab.stats.audit import RunHistory

    config = load_config()
    rh = RunHistory(config.history_file)

    if run_id:
        run = rh.get_run(run_id)
        if run is None:
            console.print(f"[red]Run {run_id} not found.[/red]")
            return
        console.print_json(json.dumps(run, indent=2, default=str))
        return

    runs = rh.list_runs()
    if not runs:
        console.print("[dim]No runs found.[/dim]")
        return

    table = Table(title="Run History")
    table.add_column("Run ID", style="cyan")
    table.add_column("Model", style="green")
    table.add_column("Rows", justify="right")
    table.add_column("Success", justify="right")
    table.add_column("Failed", justify="right")
    table.add_column("Cost", justify="right")
    table.add_column("Started", style="dim")

    for run in reversed(runs[-20:]):
        cost = run.get("cost", {}).get("total_cost", 0)
        table.add_row(
            run.get("run_id", "?"),
            run.get("model", "?"),
            str(run.get("total_rows", 0)),
            str(run.get("successful_rows", 0)),
            str(run.get("failed_rows", 0)),
            f"${cost:.4f}",
            run.get("started_at", "?")[:19],
        )

    console.print(table)


@cli.command("inspect")
@click.argument("run_id")
def inspect(run_id: str) -> None:
    """Inspect a run's request/response pairs."""
    from syndatalab.stats.audit import AuditLog

    config = load_config()
    audit = AuditLog(config.audit_dir, run_id)
    entries = audit.read_entries()

    if not entries:
        console.print(f"[red]No audit entries found for run {run_id}.[/red]")
        return

    table = Table(title=f"Audit Log — {run_id}")
    table.add_column("Row", justify="right", width=6)
    table.add_column("Status", width=10)
    table.add_column("Model", width=20)
    table.add_column("Tokens", justify="right", width=10)
    table.add_column("Latency", justify="right", width=10)
    table.add_column("Cache", width=6)
    table.add_column("Input Preview")
    table.add_column("Output Preview")

    for entry in entries:
        status = entry.get("status", "?")
        style = "green" if status == "success" else "red"

        table.add_row(
            str(entry.get("row_index", "?")),
            f"[{style}]{status}[/{style}]",
            entry.get("model", "?"),
            str(entry.get("prompt_tokens", 0) + entry.get("completion_tokens", 0)),
            f"{entry.get('latency_ms', 0):.0f}ms",
            "yes" if entry.get("cache_hit") else "no",
            (entry.get("input_preview", ""))[:40],
            (entry.get("output_preview", ""))[:40],
        )

    console.print(table)


if __name__ == "__main__":
    cli()
