"""Per-request audit log (JSONL export) and run history persistence."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from syndatalab.logging.setup import get_logger
from syndatalab.stats.models import RequestLog, RunSummary

logger = get_logger(__name__)


class AuditLog:
    """Writes per-request audit entries to a JSONL file."""

    def __init__(self, audit_dir: Path, run_id: str):
        self.audit_dir = audit_dir
        self.run_id = run_id
        self.audit_path = audit_dir / f"{run_id}.jsonl"
        self._ensure_dir()

    def _ensure_dir(self) -> None:
        self.audit_dir.mkdir(parents=True, exist_ok=True)

    def write_entry(self, entry: RequestLog) -> None:
        """Append a request log entry to the audit file."""
        try:
            with open(self.audit_path, "a") as f:
                f.write(json.dumps(entry.to_dict()) + "\n")
        except OSError as e:
            logger.warning("audit_write_failed", error=str(e), run_id=self.run_id)

    def read_entries(self) -> list[dict[str, Any]]:
        """Read all entries from the audit file."""
        if not self.audit_path.exists():
            return []
        entries = []
        with open(self.audit_path) as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        entries.append(json.loads(line))
                    except json.JSONDecodeError:
                        continue
        return entries


class RunHistory:
    """Persists run summaries to a JSONL file."""

    def __init__(self, history_file: Path):
        self.history_file = history_file
        self.history_file.parent.mkdir(parents=True, exist_ok=True)

    def save_run(self, summary: RunSummary) -> None:
        """Append a run summary to the history file."""
        try:
            with open(self.history_file, "a") as f:
                f.write(json.dumps(summary.to_dict()) + "\n")
        except OSError as e:
            logger.warning("history_write_failed", error=str(e))

    def list_runs(self) -> list[dict[str, Any]]:
        """List all past runs."""
        if not self.history_file.exists():
            return []
        runs = []
        with open(self.history_file) as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        runs.append(json.loads(line))
                    except json.JSONDecodeError:
                        continue
        return runs

    def get_run(self, run_id: str) -> dict[str, Any] | None:
        """Get a specific run by ID."""
        for run in self.list_runs():
            if run.get("run_id") == run_id:
                return run
        return None
