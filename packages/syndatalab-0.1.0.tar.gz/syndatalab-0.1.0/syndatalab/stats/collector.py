"""Thread-safe real-time stats aggregation."""

from __future__ import annotations

import threading
import time
from datetime import datetime, timezone
from typing import Any

from syndatalab.core.config import SyndatalabConfig
from syndatalab.logging.setup import get_logger
from syndatalab.stats.models import (
    CostInfo,
    PerformanceStats,
    QualityStats,
    RequestLog,
    RunSummary,
    TokenUsage,
    ValidationStats,
)

logger = get_logger(__name__)


class StatsCollector:
    """Collects and aggregates statistics during a pipeline run."""

    def __init__(self, config: SyndatalabConfig, run_id: str, total_rows: int):
        self.config = config
        self.run_id = run_id
        self.total_rows = total_rows
        self.started_at = datetime.now(timezone.utc).isoformat()

        self.token_usage = TokenUsage()
        self.cost_info = CostInfo()
        self.performance = PerformanceStats()
        self.validation = ValidationStats()
        self.quality = QualityStats()

        self._request_logs: list[RequestLog] = []
        self._lock = threading.Lock()
        self._start_time = time.monotonic()

    def record_request(
        self,
        row_index: int,
        model: str,
        provider: str,
        prompt_tokens: int,
        completion_tokens: int,
        latency_ms: float,
        status: str,
        cache_hit: bool = False,
        validation_retries: int = 0,
        failover_from: str | None = None,
        input_preview: str = "",
        output_preview: str = "",
    ) -> None:
        """Record a completed request."""
        with self._lock:
            self.performance.total_requests += 1

            if status == "success":
                self.performance.successful += 1
            elif status == "failed":
                self.performance.failed += 1

            if cache_hit:
                self.performance.cache_hits += 1
            else:
                self.performance.total_latency_ms += latency_ms

            if validation_retries > 0:
                self.performance.validation_retries += validation_retries

            self.token_usage.add(prompt_tokens, completion_tokens, model)

            pricing = self.config.get_model_pricing(model)
            input_cost = (prompt_tokens / 1_000_000) * pricing["input"]
            output_cost = (completion_tokens / 1_000_000) * pricing["output"]
            self.cost_info.add(input_cost, output_cost, model)

            self.performance.elapsed_time_s = time.monotonic() - self._start_time

            log_entry = RequestLog(
                row_index=row_index,
                timestamp=datetime.now(timezone.utc).isoformat(),
                model=model,
                provider=provider,
                prompt_tokens=prompt_tokens,
                completion_tokens=completion_tokens,
                latency_ms=latency_ms,
                status=status,
                cache_hit=cache_hit,
                validation_retries=validation_retries,
                failover_from=failover_from,
                input_preview=RequestLog.preview(input_preview),
                output_preview=RequestLog.preview(output_preview),
            )
            self._request_logs.append(log_entry)

    def record_retry(self) -> None:
        with self._lock:
            self.performance.retried += 1

    def get_snapshot(self) -> dict[str, Any]:
        """Get a thread-safe snapshot of current stats."""
        with self._lock:
            self.performance.elapsed_time_s = time.monotonic() - self._start_time
            return {
                "run_id": self.run_id,
                "total_rows": self.total_rows,
                "completed": self.performance.successful + self.performance.failed,
                "successful": self.performance.successful,
                "failed": self.performance.failed,
                "cache_hits": self.performance.cache_hits,
                "token_usage": self.token_usage.to_dict(),
                "cost": self.cost_info.to_dict(),
                "performance": self.performance.to_dict(),
            }

    @property
    def recent_logs(self) -> list[RequestLog]:
        with self._lock:
            return list(self._request_logs[-20:])

    @property
    def completed_count(self) -> int:
        with self._lock:
            return self.performance.successful + self.performance.failed

    def finalize(self) -> dict[str, Any]:
        """Finalize stats at end of run."""
        with self._lock:
            self.performance.elapsed_time_s = time.monotonic() - self._start_time
            return {
                "run_id": self.run_id,
                "started_at": self.started_at,
                "finished_at": datetime.now(timezone.utc).isoformat(),
                "total_rows": self.total_rows,
                "token_usage": self.token_usage.to_dict(),
                "cost": self.cost_info.to_dict(),
                "performance": self.performance.to_dict(),
                "validation": self.validation.to_dict(),
                "quality": self.quality.to_dict(),
            }

    def to_run_summary(self, model: str) -> RunSummary:
        final = self.finalize()
        return RunSummary(
            run_id=self.run_id,
            model=model,
            started_at=self.started_at,
            finished_at=final["finished_at"],
            total_rows=self.total_rows,
            successful_rows=self.performance.successful,
            failed_rows=self.performance.failed,
            token_usage=final["token_usage"],
            cost=final["cost"],
            performance=final["performance"],
            quality=final.get("quality"),
        )
