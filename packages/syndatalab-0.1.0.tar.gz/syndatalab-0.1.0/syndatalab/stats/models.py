"""Data models for token usage, cost, performance stats, and request logs."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class TokenUsage:
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0

    # Per-model breakdown: model_name -> TokenUsage
    per_model: dict[str, TokenUsage] = field(default_factory=dict)

    def add(self, prompt: int, completion: int, model: str | None = None) -> None:
        self.prompt_tokens += prompt
        self.completion_tokens += completion
        self.total_tokens += prompt + completion
        if model:
            if model not in self.per_model:
                self.per_model[model] = TokenUsage()
            self.per_model[model].add(prompt, completion)

    def to_dict(self) -> dict:
        result = {
            "prompt_tokens": self.prompt_tokens,
            "completion_tokens": self.completion_tokens,
            "total_tokens": self.total_tokens,
        }
        if self.per_model:
            result["per_model"] = {k: v.to_dict() for k, v in self.per_model.items()}
        return result


@dataclass
class CostInfo:
    total_cost: float = 0.0
    input_cost: float = 0.0
    output_cost: float = 0.0
    per_model: dict[str, CostInfo] = field(default_factory=dict)

    def add(self, input_cost: float, output_cost: float, model: str | None = None) -> None:
        self.input_cost += input_cost
        self.output_cost += output_cost
        self.total_cost += input_cost + output_cost
        if model:
            if model not in self.per_model:
                self.per_model[model] = CostInfo()
            self.per_model[model].add(input_cost, output_cost)

    def to_dict(self) -> dict:
        result = {
            "total_cost": round(self.total_cost, 6),
            "input_cost": round(self.input_cost, 6),
            "output_cost": round(self.output_cost, 6),
        }
        if self.per_model:
            result["per_model"] = {k: v.to_dict() for k, v in self.per_model.items()}
        return result


@dataclass
class PerformanceStats:
    total_requests: int = 0
    successful: int = 0
    failed: int = 0
    retried: int = 0
    cache_hits: int = 0
    validation_retries: int = 0

    total_latency_ms: float = 0.0
    elapsed_time_s: float = 0.0

    @property
    def avg_latency_ms(self) -> float:
        actual = self.successful - self.cache_hits
        return self.total_latency_ms / actual if actual > 0 else 0.0

    @property
    def rows_per_second(self) -> float:
        return self.successful / self.elapsed_time_s if self.elapsed_time_s > 0 else 0.0

    @property
    def cache_hit_rate(self) -> float:
        return self.cache_hits / self.total_requests if self.total_requests > 0 else 0.0

    def to_dict(self) -> dict:
        return {
            "total_requests": self.total_requests,
            "successful": self.successful,
            "failed": self.failed,
            "retried": self.retried,
            "cache_hits": self.cache_hits,
            "validation_retries": self.validation_retries,
            "avg_latency_ms": round(self.avg_latency_ms, 1),
            "rows_per_second": round(self.rows_per_second, 2),
            "cache_hit_rate": round(self.cache_hit_rate, 4),
            "elapsed_time_s": round(self.elapsed_time_s, 2),
        }


@dataclass
class DiversityStats:
    bigram_diversity: float = 0.0
    trigram_diversity: float = 0.0
    vocab_richness: float = 0.0
    semantic_diversity: float | None = None

    def to_dict(self) -> dict:
        result = {
            "bigram_diversity": round(self.bigram_diversity, 4),
            "trigram_diversity": round(self.trigram_diversity, 4),
            "vocab_richness": round(self.vocab_richness, 4),
        }
        if self.semantic_diversity is not None:
            result["semantic_diversity"] = round(self.semantic_diversity, 4)
        return result


@dataclass
class QualityStats:
    total_before_filter: int = 0
    total_after_filter: int = 0
    duplicates_removed: int = 0
    filtered_out: int = 0
    diversity: DiversityStats = field(default_factory=DiversityStats)

    @property
    def rejection_rate(self) -> float:
        if self.total_before_filter == 0:
            return 0.0
        return 1.0 - (self.total_after_filter / self.total_before_filter)

    def to_dict(self) -> dict:
        return {
            "total_before_filter": self.total_before_filter,
            "total_after_filter": self.total_after_filter,
            "duplicates_removed": self.duplicates_removed,
            "filtered_out": self.filtered_out,
            "rejection_rate": round(self.rejection_rate, 4),
            "diversity": self.diversity.to_dict(),
        }


@dataclass
class RequestLog:
    row_index: int
    timestamp: str
    model: str
    provider: str
    prompt_tokens: int
    completion_tokens: int
    latency_ms: float
    status: str
    cache_hit: bool = False
    validation_retries: int = 0
    failover_from: str | None = None
    input_preview: str = ""
    output_preview: str = ""

    def to_dict(self) -> dict:
        return {
            "row_index": self.row_index,
            "timestamp": self.timestamp,
            "model": self.model,
            "provider": self.provider,
            "prompt_tokens": self.prompt_tokens,
            "completion_tokens": self.completion_tokens,
            "latency_ms": round(self.latency_ms, 1),
            "status": self.status,
            "cache_hit": self.cache_hit,
            "validation_retries": self.validation_retries,
            "failover_from": self.failover_from,
            "input_preview": self.input_preview,
            "output_preview": self.output_preview,
        }

    @staticmethod
    def preview(text: str, max_len: int = 200) -> str:
        if len(text) <= max_len:
            return text
        return text[:max_len] + "..."


@dataclass
class ValidationStats:
    layer1_success: int = 0
    layer2_success: int = 0
    layer2b_repair_success: int = 0
    layer3_success: int = 0
    layer4_reprompt_success: int = 0
    total_failures: int = 0
    total_retries: int = 0

    def to_dict(self) -> dict:
        return {
            "layer1_extract_success": self.layer1_success,
            "layer2_parse_success": self.layer2_success,
            "layer2b_repair_success": self.layer2b_repair_success,
            "layer3_validate_success": self.layer3_success,
            "layer4_reprompt_success": self.layer4_reprompt_success,
            "total_failures": self.total_failures,
            "total_retries": self.total_retries,
        }


@dataclass
class RunSummary:
    """Persisted summary for run history."""

    run_id: str
    model: str
    started_at: str
    finished_at: str
    total_rows: int
    successful_rows: int
    failed_rows: int
    token_usage: dict
    cost: dict
    performance: dict
    quality: dict | None = None

    def to_dict(self) -> dict:
        return {
            "run_id": self.run_id,
            "model": self.model,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "total_rows": self.total_rows,
            "successful_rows": self.successful_rows,
            "failed_rows": self.failed_rows,
            "token_usage": self.token_usage,
            "cost": self.cost,
            "performance": self.performance,
            "quality": self.quality,
        }

    @classmethod
    def from_dict(cls, data: dict) -> RunSummary:
        return cls(**data)
