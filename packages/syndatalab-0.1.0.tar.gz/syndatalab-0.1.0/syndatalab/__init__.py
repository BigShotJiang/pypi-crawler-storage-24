"""syndatalab — Production-grade synthetic data generation using LLMs."""

from syndatalab.core.config import SyndatalabConfig, load_config
from syndatalab.core.exceptions import (
    AuthenticationError,
    CacheError,
    CheckpointError,
    ConfigError,
    ProviderError,
    ProviderNotInstalledError,
    ProviderUnavailableError,
    RateLimitError,
    SyndatalabError,
    ValidationError,
)
from syndatalab.core.llm import LLM, ChainedLLM
from syndatalab.core.response import SyndataResponse
from syndatalab.quality import filters

__version__ = "0.1.0"

__all__ = [
    "LLM",
    "ChainedLLM",
    "SyndataResponse",
    "SyndatalabConfig",
    "load_config",
    "filters",
    # Exceptions
    "SyndatalabError",
    "ProviderError",
    "RateLimitError",
    "AuthenticationError",
    "ProviderUnavailableError",
    "ValidationError",
    "CheckpointError",
    "ConfigError",
    "CacheError",
    "ProviderNotInstalledError",
]
