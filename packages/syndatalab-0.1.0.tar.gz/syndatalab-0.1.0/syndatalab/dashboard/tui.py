"""Rich TUI dashboard for real-time monitoring."""

from __future__ import annotations

from typing import TYPE_CHECKING

from rich.console import Console, Group
from rich.live import Live
from rich.panel import Panel
from rich.progress import (
    BarColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeElapsedColumn,
    TimeRemainingColumn,
)
from rich.table import Table
from rich.text import Text

if TYPE_CHECKING:
    from syndatalab.stats.collector import StatsCollector


class Dashboard:
    """Rich live TUI dashboard for pipeline monitoring."""

    def __init__(self, stats: StatsCollector, total_rows: int):
        self.stats = stats
        self.total_rows = total_rows
        self.console = Console()
        self._shutting_down = False
        self._draining_count = 0

        self.progress = Progress(
            SpinnerColumn(),
            TextColumn("[bold blue]{task.description}"),
            BarColumn(bar_width=40),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TextColumn("({task.completed}/{task.total})"),
            TimeElapsedColumn(),
            TimeRemainingColumn(),
            console=self.console,
        )
        self.task_id = self.progress.add_task("Generating", total=total_rows)
        self._live: Live | None = None

    def _build_stats_table(self) -> Table:
        snapshot = self.stats.get_snapshot()
        perf = snapshot["performance"]
        cost = snapshot["cost"]
        tokens = snapshot["token_usage"]

        table = Table(title="Statistics", expand=True, show_header=False)
        table.add_column("Metric", style="cyan", width=24)
        table.add_column("Value", style="green")

        table.add_row("Tokens (prompt)", f"{tokens['prompt_tokens']:,}")
        table.add_row("Tokens (completion)", f"{tokens['completion_tokens']:,}")
        table.add_row("Tokens (total)", f"{tokens['total_tokens']:,}")
        table.add_row("", "")
        table.add_row("Cost (total)", f"${cost['total_cost']:.4f}")
        table.add_row("Cost (input)", f"${cost['input_cost']:.4f}")
        table.add_row("Cost (output)", f"${cost['output_cost']:.4f}")
        table.add_row("", "")
        table.add_row("Avg latency", f"{perf['avg_latency_ms']:.0f}ms")
        table.add_row("Rows/sec", f"{perf['rows_per_second']:.1f}")
        table.add_row("Cache hit rate", f"{perf['cache_hit_rate']:.1%}")
        table.add_row("Retries", str(perf["retried"]))
        table.add_row("Failed", str(perf["failed"]))

        return table

    def _build_model_table(self) -> Table | None:
        token_usage = self.stats.token_usage
        if not token_usage.per_model or len(token_usage.per_model) <= 1:
            return None

        table = Table(title="Per-Model Breakdown", expand=True)
        table.add_column("Model", style="cyan")
        table.add_column("Prompt Tokens", justify="right")
        table.add_column("Completion Tokens", justify="right")
        table.add_column("Total", justify="right")

        for model, usage in token_usage.per_model.items():
            table.add_row(
                model,
                f"{usage.prompt_tokens:,}",
                f"{usage.completion_tokens:,}",
                f"{usage.total_tokens:,}",
            )
        return table

    def _build_recent_logs(self) -> Table:
        table = Table(title="Recent Requests", expand=True)
        table.add_column("Row", justify="right", width=6)
        table.add_column("Status", width=10)
        table.add_column("Model", width=20)
        table.add_column("Tokens", justify="right", width=10)
        table.add_column("Latency", justify="right", width=10)
        table.add_column("Output Preview", no_wrap=True)

        for log in self.stats.recent_logs:
            status_style = "green" if log.status == "success" else "red"
            if log.cache_hit:
                status_style = "yellow"
                status_text = "cache"
            else:
                status_text = log.status

            table.add_row(
                str(log.row_index),
                Text(status_text, style=status_style),
                log.model,
                f"{log.prompt_tokens + log.completion_tokens:,}",
                f"{log.latency_ms:.0f}ms" if not log.cache_hit else "-",
                log.output_preview[:60],
            )
        return table

    def _build_error_panel(self) -> Panel | None:
        recent = self.stats.recent_logs
        errors = [log for log in recent if log.status == "failed"]
        if not errors:
            return None

        error_text = "\n".join(
            f"[red]Row {e.row_index}:[/red] {e.output_preview[:100]}" for e in errors[-5:]
        )
        return Panel(error_text, title="Errors", border_style="red")

    def _build_footer(self) -> Text:
        perf = self.stats.performance
        footer = Text()
        footer.append(f"Run: {self.stats.run_id}", style="dim")
        footer.append("  |  ", style="dim")
        footer.append(f"Elapsed: {perf.elapsed_time_s:.1f}s", style="dim")
        footer.append("  |  ", style="dim")

        if self._shutting_down:
            footer.append(
                f"Shutting down... {self._draining_count} requests draining",
                style="bold yellow",
            )
        else:
            footer.append("Ctrl+C to gracefully stop", style="dim")
        return footer

    def _render(self) -> Group:
        components = [self.progress]

        stats_table = self._build_stats_table()
        components.append(stats_table)

        model_table = self._build_model_table()
        if model_table:
            components.append(model_table)

        error_panel = self._build_error_panel()
        if error_panel:
            components.append(error_panel)

        recent_table = self._build_recent_logs()
        components.append(recent_table)
        components.append(self._build_footer())

        return Group(*components)

    def update(self, completed: int) -> None:
        """Update the dashboard with current progress."""
        self.progress.update(self.task_id, completed=completed)
        if self._live:
            self._live.update(self._render())

    def set_shutting_down(self, draining_count: int = 0) -> None:
        self._shutting_down = True
        self._draining_count = draining_count
        if self._live:
            self._live.update(self._render())

    def start(self) -> None:
        self._live = Live(self._render(), console=self.console, refresh_per_second=4)
        self._live.start()

    def stop(self) -> None:
        if self._live:
            self._live.stop()
            self._live = None

    def __enter__(self) -> Dashboard:
        self.start()
        return self

    def __exit__(self, *args: object) -> None:
        self.stop()
