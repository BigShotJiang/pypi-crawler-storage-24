#!/usr/bin/env python3
"""
Holiday Expert NER Annotation Script (syndatalab version)

Annotates Holiday Expert queries with entity extraction using GPT-4.1 (package, hotel,
activity, flight, destination, visa, etc.). Produces combined Parquet and GLiNER-format
JSONL for NER training. Processes data in batches with automatic retry on rate limits
and auth errors. Input CSV/Parquet should have a query column (default: prompt).

Usage:
    python run_synthetic_data.py --input queries.csv --output ./annotated_data
    python run_synthetic_data.py --input queries.csv --output ./annotated_data --expert HolidayExpert
    python run_synthetic_data.py --input queries.csv --output ./annotated_data --dry-run
    python run_synthetic_data.py --input queries.csv --output ./annotated_data --no-gliner-export

    # Redirect all output to log file:
    python run_synthetic_data.py --input queries.csv --output ./annotated_data > annotation.log 2>&1
"""

import os
import sys
import json
import time
import argparse
from datetime import datetime
from collections import Counter
from typing import List, Optional

# import boto3
import pandas as pd
from datasets import Dataset
from pydantic import BaseModel, Field

from syndatalab import LLM


# =============================================================================
# CONFIGURATION
# =============================================================================

DEFAULT_MODEL = "ds-gpt-4.1"
DEFAULT_BASE_URL = "http://10.212.141.193:8080"
DEFAULT_BATCH_SIZE = 500
DEFAULT_MAX_RETRIES = 5
DEFAULT_RETRY_DELAY = 60  # seconds


# =============================================================================
# ENTITY TYPES (Holiday Expert schema - extractable text spans for NER)
# =============================================================================
# Schema fields that are NOT span-based (derived/typed only) are not listed here:
# e.g. duration_days_min/max as integers, departure_date_min/max as dates - extract
# the phrase that expresses them (e.g. "5 days", "December 15") and use the span label.

ENTITY_TYPES = {
    # PACKAGE DETAILS
    "package_details.duration_days_min": "Minimum trip duration in days - extract the phrase (e.g. 5 days, 3 days, one week)",
    "package_details.duration_days_max": "Maximum trip duration in days - extract the phrase (e.g. 7 days, 10 days, two weeks)",
    "package_details.departure_date_min": "Earliest departure date - extract as stated (e.g. 15th December, next Monday, tomorrow)",
    "package_details.departure_date_max": "Latest departure date - extract as stated (e.g. 20th December, end of January)",
    "package_details.departure_city": "Origin or departure city (e.g. Delhi, Mumbai, from Bangalore). Extract exact phrase.",
    "package_details.departure_city_nearest_metro_city": "Nearest metro city for origin (e.g. nearest metro, Delhi NCR)",
    "package_details.start_city": "First hotel or transport city of the package (e.g. first city Goa, start at Jaipur)",
    "package_details.budget": "Budget in INR - extract the amount phrase (e.g. 50000, 1 lakh, fifty thousand, under 2 lakh)",
    "package_details.traveler_type": "Traveler segment - extract exact phrase. Values map to: SOLO, COUPLE, FAMILY, GROUP, OTHERS (e.g. solo, couple, family, group of friends)",
    "package_details.theme": "Trip theme - extract exact phrase. Values: Culture, Adventure, Offbeat, Pilgrimage, Wildlife, Romantic, Wellness (e.g. adventure, cultural, pilgrimage, wildlife)",
    "package_details.adults": "Number of adults - extract the phrase (e.g. 2 adults, 4 adults, six adults)",
    "package_details.children": "Number of children - extract the phrase (e.g. 2 kids, 3 children)",
    "package_details.infants": "Number of infants - extract the phrase (e.g. 1 infant, with infant)",
    # HOTEL DETAILS
    "hotel_details.name": "Hotel or accommodation name - extract each name separately (e.g. Taj Palace, Marriott, Hotel Sunshine)",
    "hotel_details.star_rating": "Hotel star rating 1-5 - extract the phrase (e.g. 4 star, 5 star, 3-star). Do not assume.",
    "hotel_details.category": "Hotel category - luxury, premium, standard, or budget. Extract exact phrase.",
    "hotel_details.accommodation_types": "Type of accommodation - extract each (e.g. hotel, resort, homestay, hostel). Default is Hotel if not stated.",
    "hotel_details.area_name": "Locality or area (e.g. Connaught Place, Marine Drive, Bandra)",
    "hotel_details.city_name": "Hotel city name(s) - extract each city (e.g. Goa, Jaipur, Mumbai). Normalize Delhi to New Delhi in post-processing.",
    "hotel_details.address": "Full address if mentioned (e.g. 123 MG Road, near airport)",
    "hotel_details.proximity_to": "Nearby landmarks or POIs - extract each (e.g. near beach, close to Taj, walking distance from mall)",
    "hotel_details.facilities": "Hotel amenities - extract each (e.g. pool, spa, wifi, gym, parking)",
    "hotel_details.room_type.views": "Room view type (e.g. Sea View, Garden View, City View)",
    "hotel_details.room_type.room_types": "Room type (e.g. Deluxe, Suite, Standard, Villa)",
    "hotel_details.room_type.bed_types": "Bed type (e.g. King, Twin, Double, Single)",
    "hotel_details.room_type.meals": "Included meals - BREAKFAST, LUNCH, DINNER (e.g. breakfast included, half board, all meals)",
    # ACTIVITY DETAILS
    "activity_details.names": "Activity or POI name - extract each (e.g. trekking, scuba diving, Red Fort visit, houseboat)",
    "activity_details.theme": "Activity theme - extract each (e.g. adventure, cultural, wildlife)",
    "activity_details.duration": "Activity duration (e.g. 2 hours, half day, full day safari)",
    "activity_details.city_name": "City where activity is (e.g. Goa, Rishikesh)",
    # CAR ITINERARY
    "car_itinerary_details.vehicle_type": "Vehicle type (e.g. sedan, SUV, tempo traveller, self-drive car)",
    "car_itinerary_details.places_to_visit": "Places to cover - extract each (e.g. Jaipur, Amer Fort, Hawa Mahal)",
    # FLIGHT DETAILS
    "flight_details.airline_name": "Preferred airline (e.g. IndiGo, Air India, Vistara)",
    "flight_details.stops": "Number of stops - extract phrase (e.g. direct, non-stop, 1 stop)",
    "flight_details.cabin_class": "Cabin class - Economy, Business, etc. Extract exact phrase.",
    "flight_details.max_stops": "Maximum allowed stops - extract phrase (e.g. max 1 stop, direct only)",
    # AIRPORT DETAILS
    "airport_details.departure_city_airport": "Departure airport city or code (e.g. Delhi, BOM, from Mumbai airport)",
    "airport_details.departure_airport_name": "Departure airport name (e.g. IGI Airport, Chhatrapati Shivaji)",
    "airport_details.return_city_airport": "Return airport city or code (e.g. Bangalore, BLR)",
    "airport_details.return_airport_name": "Return airport name",
    # COMMUTE TO DESTINATION
    "commute_to_destination_details.commute_type": "Commute type - flight or car. Extract exact phrase (e.g. by flight, by car)",
    # DESTINATIONS
    "destinations_details.tagged_destination": "Tagged destination name - use allowed tags only, extract each (e.g. Goa, Kerala, Rajasthan)",
    "destinations_details.city_name": "Destination city/cities - extract each, exclude departure city (e.g. Jaipur, Udaipur)",
    "destinations_details.state_name": "Destination state(s) - extract each (e.g. Rajasthan, Kerala, Goa)",
    "destinations_details.region_name": "Destination region (e.g. North India, South India, Konkan)",
    "destinations_details.country_name": "Destination country (e.g. India, Thailand)",
    # VISA DETAILS
    "visa_details.country": "Destination country for visa (e.g. Thailand, UK)",
    "visa_details.citizenship_country": "Passenger citizenship country (e.g. Indian, US citizen)",
    "visa_details.residency_country": "Country of residence (e.g. residing in UAE, UK resident)",
}


# =============================================================================
# SYSTEM PROMPT FOR ANNOTATION
# =============================================================================

ANNOTATION_PROMPT = """You are an expert entity extractor for Holiday Expert queries (packages, hotels, activities, flights, destinations, visa). Your task is to identify and extract all entities from the given query as exact text spans with word positions.

### ENTITY TYPES TO EXTRACT:
{entity_descriptions}

---

### CRITICAL EXTRACTION RULES:

**RULE 1: EXTRACT EXACT TEXT - NO NORMALIZATION**
- Entity values MUST be extracted EXACTLY as they appear in the query
- DO NOT normalize, lemmatize, or modify the text in any way
- Keep the original case, plural form, tense, and spelling from the query
- For enum-like fields (traveler_type, theme, cabin_class, commute_type): use the schema key as entity_type and extract the exact phrase from the query (e.g. "solo", "economy")

**RULE 2: EXTRACT EVERY ENTITY - DO NOT MISS ANY**
- Read the query carefully and extract ALL entities mentioned
- Cover package details (duration, dates, departure city, budget, traveler type, theme, adults/children/infants), hotel details (name, star rating, category, city, area, facilities, room type), activities, flights, airports, destinations, visa, car itinerary as applicable

**RULE 3: SAME ENTITY TYPE CAN APPEAR MULTIPLE TIMES**
- Multiple destinations: "Goa and Kerala" -> extract two spans with same entity_type (e.g. destinations_details.city_name)
- Multiple hotels, activities, or places: extract each span separately with the same label

**RULE 4: WORD POSITION CALCULATION (BOTH START AND END, INCLUSIVE)**
- Split the query by spaces to get words (0-indexed)
- start_word_position = index of the FIRST word of the entity value (inclusive)
- end_word_position = index of the LAST word of the entity value (inclusive)
- Example: "2 adults and 3 kids for 5 days"
  - Words: ["2", "adults", "and", "3", "kids", "for", "5", "days"]
  - package_details.adults: "2 adults" -> start_word_position: 0, end_word_position: 1
  - package_details.children: "3 kids" -> start_word_position: 3, end_word_position: 4
  - package_details.duration_days_min or duration_days_max: "5 days" -> start_word_position: 6, end_word_position: 7
- Multi-word entity: "Sea View" in "Deluxe Sea View room" -> start_word_position: 1, end_word_position: 2

**RULE 5: BE SELECTIVE - ONLY EXTRACT VALID ENTITIES**
- Do NOT extract generic phrases that don't match entity definitions
- Do NOT extract entity types that are not in the provided list
- If a word/phrase doesn't clearly match an entity type, don't extract it

---

### QUERY TO ANNOTATE:
{query}

---

Extract all entities from the query above following the rules. Return the original query and list of entities with entity_type, entity_value, start_word_position, and end_word_position.
"""


# =============================================================================
# SECRETS MANAGER
# =============================================================================

class SecretsManager:
    """Handles AWS Secrets Manager for API credentials."""

    def __init__(self, prod=False):
        self.secrets_name = (
            "/prod/ds/DS-LLM-inference-engines_auth_DS-Entity-Knowledge-Search/secrets"
            if prod else
            "/alpha/ds/DS-LLM-inference-engines_auth_DS-Entity-Knowledge-Search/secrets"
        )
        self.url = "http://ds-llm-inference-engines.ecs.mmt/chat/completions"

    def fetch_secret(self, secret_name=None, region_name="ap-south-1"):
        """Fetch a secret from AWS Secrets Manager."""
        secret_name = secret_name or self.secrets_name
        print("Fetching secret from AWS Secrets Manager...")

        session = boto3.session.Session()
        client = session.client(service_name='secretsmanager', region_name=region_name)

        try:
            response = client.get_secret_value(SecretId=secret_name)
        except Exception as e:
            print(f"Error fetching secret: {e}")
            return None

        secret = response.get('SecretString')
        if secret:
            try:
                return json.loads(secret)
            except Exception:
                return secret
        return response.get('SecretBinary')

    def build_headers_from_secrets(self, secrets):
        """Build API headers from secrets."""
        api_key = secrets.get("api_key") or secrets.get("x-api-key")
        user_id = secrets.get("user_id") or secrets.get("x-user-id")
        if not api_key or not user_id:
            raise ValueError("Missing API key or user ID in secrets.")
        return {
            "x-api-key": api_key,
            "x-user-id": user_id,
            "Content-Type": "application/json"
        }


# =============================================================================
# PYDANTIC MODELS
# =============================================================================

class EntityExtraction(BaseModel):
    entity_type: str = Field(description="Type of entity extracted from ENTITY_TYPES")
    entity_value: str = Field(description="Exact text value of the extracted entity from the query")
    start_word_position: int = Field(description="0-indexed word position where the entity starts (inclusive)")
    end_word_position: int = Field(description="0-indexed word position where the entity ends (inclusive)")


class AnnotatedQuery(BaseModel):
    query: str = Field(description="The original query text")
    entities_present: List[EntityExtraction] = Field(description="List of extracted entities")


# =============================================================================
# QUERY ANNOTATOR (syndatalab LLM subclass)
# =============================================================================

class QueryAnnotator(LLM):
    response_format = AnnotatedQuery

    def prompt(self, input: dict) -> str:
        entity_descriptions = "\n".join(
            [f"- **{k}**: {v}" for k, v in ENTITY_TYPES.items()]
        )
        return ANNOTATION_PROMPT.format(
            entity_descriptions=entity_descriptions,
            query=input['query']
        )

    def parse(self, input: dict, response: AnnotatedQuery) -> dict:
        words = input['query'].split()
        valid_entities = []
        for e in response.entities_present:
            if e.entity_type not in ENTITY_TYPES:
                continue
            if e.start_word_position > e.end_word_position:
                continue
            if e.start_word_position < 0 or e.end_word_position >= len(words):
                continue
            if e.entity_value.lower() not in input['query'].lower():
                continue
            valid_entities.append({
                "entity_type": e.entity_type,
                "entity_value": e.entity_value,
                "start_word_position": e.start_word_position,
                "end_word_position": e.end_word_position,
            })
        return {
            "query": input['query'],
            "entities_present": valid_entities,
            "entity_count": len(valid_entities)
        }


# =============================================================================
# ANNOTATOR WITH RETRY (secrets refresh on auth failures)
# =============================================================================

class AnnotatorWithRetry:
    """Wraps QueryAnnotator with secrets-refresh retry logic.

    syndatalab already handles per-request retries, rate limiting, and
    checkpoint/resume internally. This wrapper adds batch-level retry
    with AWS secrets refresh for rotating API credentials.
    """

    def __init__(
        self,
        secrets_manager,
        model_name=DEFAULT_MODEL,
        base_url=DEFAULT_BASE_URL,
        max_retries=DEFAULT_MAX_RETRIES,
        retry_delay=DEFAULT_RETRY_DELAY,
    ):
        self.secrets_manager = secrets_manager
        self.model_name = model_name
        self.base_url = base_url
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.annotator = None
        self._initialize_annotator()

    def _refresh_secrets(self):
        """Fetch fresh secrets from AWS Secrets Manager."""
        print("Refreshing secrets...")
        if self.secrets_manager is None:
            return  {
                "x-api-key": "ds@admin",
                "x-user-id": "ds_admin",
            }        
        secrets = self.secrets_manager.fetch_secret(self.secrets_manager.secrets_name)
        headers = self.secrets_manager.build_headers_from_secrets(secrets)
        return headers

    def _initialize_annotator(self):
        """Initialize/reinitialize the annotator with current secrets."""
        headers = self._refresh_secrets()
        self.annotator = QueryAnnotator(
            model=self.model_name,
            backend="openai",
            base_url=self.base_url,
            api_key=f"{headers['x-user-id']}::{headers['x-api-key']}",
            extra_headers={
                "x-api-key": headers["x-api-key"],
                "x-user-id": headers["x-user-id"],
            },
            max_requests_per_minute=500,
            max_tokens_per_minute=100_000_000,
            max_retries=3,
            show_dashboard=False,
            cache_enabled=True,
        )
        print("Annotator initialized successfully")

    def _should_retry(self, error):
        """Check if the error requires retry."""
        error_str = str(error).lower()
        non_retryable = ['validation error', 'invalid json', 'pydantic', 'keyboardinterrupt']
        for indicator in non_retryable:
            if indicator in error_str:
                return False
        return True

    def annotate(self, batch_dataset):
        """Annotate a batch with retry logic (refreshes secrets on failure)."""
        for attempt in range(1, self.max_retries + 1):
            try:
                result = self.annotator(batch_dataset)
                return result
            except Exception as e:
                print(f"    Error on attempt {attempt}/{self.max_retries}: {str(e)[:200]}")

                if self._should_retry(e):
                    if attempt < self.max_retries:
                        print(f"    Waiting {self.retry_delay}s before refreshing secrets...")
                        time.sleep(self.retry_delay)
                        self._initialize_annotator()
                        print("    Retrying...")
                    else:
                        raise
                else:
                    raise
        return None


# =============================================================================
# MAIN PIPELINE
# =============================================================================

def load_server_data(
    input_path: str,
    expert_filter: Optional[str] = None,
    sample_size: Optional[int] = None,
) -> pd.DataFrame:
    """Load server data from parquet or CSV file."""
    print(f"Loading data from: {input_path}")

    if input_path.endswith('.parquet'):
        df = pd.read_parquet(input_path)
    elif input_path.endswith('.csv'):
        df = pd.read_csv(input_path)
    else:
        raise ValueError(f"Unsupported file format: {input_path}")

    print(f"Loaded {len(df)} rows")

    if expert_filter and 'expert' in df.columns:
        df = df[df['expert'] == expert_filter]
        print(f"Filtered to {len(df)} rows for expert: {expert_filter}")

    if sample_size and sample_size < len(df):
        df = df.sample(n=sample_size, random_state=42)
        print(f"Sampled {len(df)} rows")

    return df


def create_annotation_batches(
    df: pd.DataFrame,
    query_column: str = 'prompt',
    batch_size: int = DEFAULT_BATCH_SIZE,
) -> List[Dataset]:
    """Create batches of queries for annotation."""
    queries = df[query_column].dropna().unique().tolist()
    print(f"Total unique queries: {len(queries)}")

    batches = []
    for i in range(0, len(queries), batch_size):
        batch_queries = queries[i:i + batch_size]
        batch_data = [{'query': q} for q in batch_queries]
        batches.append(Dataset.from_list(batch_data))

    print(f"Created {len(batches)} batches of size {batch_size}")
    return batches


def annotations_to_gliner(combined_df: pd.DataFrame, output_path: str) -> str:
    """Convert annotated dataframe to GLiNER-format JSONL (tokenized_text + ner spans).
    ner format: list of [start_idx, end_idx, "label"] with inclusive token indices.
    """
    with open(output_path, "w", encoding="utf-8") as f:
        for _, row in combined_df.iterrows():
            query = row["query"]
            tokens = query.split()
            entities = row.get("entities_present", [])
            if isinstance(entities, str):
                entities = json.loads(entities)
            ner = []
            for e in entities:
                start = e.get("start_word_position", 0)
                end = e.get("end_word_position", start)
                label = e.get("entity_type", "")
                if start > end or start < 0 or end >= len(tokens):
                    continue
                ner.append([start, end, label])
            rec = {"tokenized_text": tokens, "ner": ner}
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    return output_path


def run_annotation_pipeline(
    input_path: str,
    output_dir: str,
    query_column: str = 'query',
    expert_filter: Optional[str] = None,
    sample_size: Optional[int] = None,
    batch_size: int = DEFAULT_BATCH_SIZE,
    start_batch: int = 0,
    dry_run: bool = False,
    prod: bool = False,
    max_retries: int = DEFAULT_MAX_RETRIES,
    retry_delay: int = DEFAULT_RETRY_DELAY,
    export_gliner: bool = True,
):
    """Run the annotation pipeline."""
    print("=" * 70)
    print("SERVER DATA ENTITY ANNOTATION PIPELINE (syndatalab)")
    print(f"Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 70)
    print(f"Input: {input_path}")
    print(f"Output Directory: {output_dir}")
    print(f"Query Column: {query_column}")
    print(f"Expert Filter: {expert_filter or 'None'}")
    print(f"Sample Size: {sample_size or 'All'}")
    print(f"Batch Size: {batch_size}")
    print(f"Start Batch: {start_batch + 1}")
    print(f"Environment: {'Production' if prod else 'Alpha'}")
    print(f"Dry Run: {dry_run}")
    print(f"Export GLiNER: {export_gliner}")
    print()

    # Load data
    df = load_server_data(input_path, expert_filter, sample_size)

    # Create batches
    batches = create_annotation_batches(df, query_column, batch_size)

    if dry_run:
        print("\nDRY RUN MODE - Showing plan only")
        print("-" * 70)
        print(f"Would process {len(batches)} batches")
        print(f"Total queries to annotate: {sum(len(b) for b in batches)}")
        print(f"Entity types available: {len(ENTITY_TYPES)}")
        print("\nEntity types:")
        for i, entity_type in enumerate(ENTITY_TYPES.keys(), 1):
            print(f"  {i:2d}. {entity_type}")
        return None

    # Setup output directory
    os.makedirs(output_dir, exist_ok=True)

    # Initialize annotator with retry
    # secrets_manager = SecretsManager(prod=prod)
    annotator = AnnotatorWithRetry(
        secrets_manager=None,
        max_retries=max_retries,
        retry_delay=retry_delay
    )

    all_results = []
    start_time = time.time()

    for batch_id, batch in enumerate(batches[start_batch:], start=start_batch + 1):
        print(f"\n{'='*50}")
        print(f"ANNOTATING BATCH {batch_id}/{len(batches)}")
        print(f"{'='*50}")
        print(f"Queries in batch: {len(batch)}")

        try:
            annotator._initialize_annotator()

            result = annotator.annotate(batch)
            result_df = result.to_pandas()

            print(f"Annotated {len(result_df)} queries")

            # Stats from syndatalab
            print(f"  Tokens used: {result.total_tokens:,}")
            print(f"  Estimated cost: ${result.total_cost:.4f}")
            if result.failed:
                print(f"  Failed rows: {len(result.failed)}")

            total_entities = result_df['entity_count'].sum()
            avg_entities = result_df['entity_count'].mean()
            print(f"  Total entities extracted: {total_entities}")
            print(f"  Average entities per query: {avg_entities:.2f}")

            # Save batch
            batch_file = os.path.join(
                output_dir,
                f"batch_{batch_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.parquet",
            )
            result_df.to_parquet(batch_file)
            print(f"  Saved to: {batch_file}")

            all_results.append(result_df)

        except Exception as e:
            print(f"\nBatch {batch_id} failed: {e}")
            print(f"Saving partial results ({len(all_results)} batches completed)...")

            if all_results:
                combined_df = pd.concat(all_results, ignore_index=True)
                partial_file = os.path.join(
                    output_dir, f"partial_batches_1_to_{batch_id-1}.parquet"
                )
                combined_df.to_parquet(partial_file)
                print(f"Partial results saved to: {partial_file}")
                print(f"To resume, use: --start-batch {batch_id - 1}")

            raise

    # Combine all results
    combined_df = pd.concat(all_results, ignore_index=True)

    elapsed = time.time() - start_time

    # Final report
    print("\n" + "=" * 70)
    print("FINAL RESULTS")
    print("=" * 70)
    print(f"Total queries annotated: {len(combined_df)}")
    print(f"Total entities extracted: {combined_df['entity_count'].sum()}")
    print(f"Average entities per query: {combined_df['entity_count'].mean():.2f}")
    print(f"Total time: {elapsed/60:.2f} minutes")

    # Entity type distribution
    entity_counts: Counter = Counter()
    for entities in combined_df['entities_present']:
        if isinstance(entities, str):
            entities = json.loads(entities)
        for e in entities:
            entity_counts[e['entity_type']] += 1

    print("\nEntity Type Distribution (top 20):")
    for entity_type, count in entity_counts.most_common(20):
        print(f"  {entity_type}: {count}")

    # Save combined results
    combined_file = os.path.join(
        output_dir,
        f"combined_annotations_{datetime.now().strftime('%Y%m%d_%H%M%S')}.parquet",
    )
    combined_df.to_parquet(combined_file)

    print(f"\nCOMPLETED SUCCESSFULLY")
    print(f"Combined results: {combined_file}")

    # Export to GLiNER format for NER training
    if export_gliner:
        gliner_path = os.path.join(output_dir, "gliner_train.jsonl")
        annotations_to_gliner(combined_df, gliner_path)
        print(f"GLiNER training data: {gliner_path}")

    return combined_df


# =============================================================================
# MAIN
# =============================================================================

def main():
    parser = argparse.ArgumentParser(
        description=(
            'Holiday Expert NER annotation using GPT-4.1 via syndatalab; '
            'outputs Parquet + GLiNER-format JSONL for training.'
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    # Dry run to see plan:
    python run_synthetic_data.py --input queries.csv --output ./annotated --dry-run

    # Annotate all queries (produces combined Parquet and gliner_train.jsonl):
    python run_synthetic_data.py --input queries.csv --output ./annotated

    # Filter by expert type (e.g. HolidayExpert if column exists):
    python run_synthetic_data.py --input queries.csv --output ./annotated --expert HolidayExpert

    # Sample and annotate:
    python run_synthetic_data.py --input queries.csv --output ./annotated --sample 1000

    # Resume from batch 5:
    python run_synthetic_data.py --input queries.csv --output ./annotated --start-batch 5

    # Skip GLiNER export:
    python run_synthetic_data.py --input queries.csv --output ./annotated --no-gliner-export

    # Redirect output to log:
    python run_synthetic_data.py --input queries.csv --output ./annotated > annotation.log 2>&1
        """
    )

    parser.add_argument('--input', '-i', required=True, help='Input file path (parquet or csv)')
    parser.add_argument('--output', '-o', required=True, help='Output directory for results')
    parser.add_argument('--query-column', type=str, default='prompt',
                        help='Column name containing queries (default: prompt)')
    parser.add_argument('--expert', type=str, default=None,
                        help='Filter by expert type (e.g., DestinationExpert)')
    parser.add_argument('--sample', type=int, default=None,
                        help='Sample size (random sample of queries)')
    parser.add_argument('--batch-size', type=int, default=DEFAULT_BATCH_SIZE,
                        help=f'Queries per batch (default: {DEFAULT_BATCH_SIZE})')
    parser.add_argument('--start-batch', type=int, default=0,
                        help='Batch index to start from (for resuming)')
    parser.add_argument('--max-retries', type=int, default=DEFAULT_MAX_RETRIES,
                        help=f'Max retries per batch (default: {DEFAULT_MAX_RETRIES})')
    parser.add_argument('--retry-delay', type=int, default=DEFAULT_RETRY_DELAY,
                        help=f'Delay between retries in seconds (default: {DEFAULT_RETRY_DELAY})')
    parser.add_argument('--prod', action='store_true',
                        help='Use production secrets (default: alpha)')
    parser.add_argument('--dry-run', action='store_true',
                        help='Show plan without annotating')
    parser.add_argument('--no-gliner-export', action='store_true',
                        help='Skip writing GLiNER-format JSONL (default: export gliner_train.jsonl)')

    args = parser.parse_args()

    try:
        run_annotation_pipeline(
            input_path=args.input,
            output_dir=args.output,
            query_column=args.query_column,
            expert_filter=args.expert,
            sample_size=args.sample,
            batch_size=args.batch_size,
            start_batch=args.start_batch,
            dry_run=args.dry_run,
            prod=args.prod,
            max_retries=args.max_retries,
            retry_delay=args.retry_delay,
            export_gliner=not args.no_gliner_export,
        )
    except KeyboardInterrupt:
        print("\nInterrupted by user.")
        sys.exit(1)
    except Exception as e:
        print(f"\nFAILED: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
