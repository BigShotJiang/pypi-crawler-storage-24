"""Basic example: generate text completions without structured output."""

import syndatalab as sd


class StoryGenerator(sd.LLM):
    """Generate short stories from topic seeds."""

    def prompt(self, input: dict) -> str:
        return f"Write a very short (2-3 sentence) story about {input['topic']}."

    def parse(self, input: dict, response: str) -> dict:
        return {"topic": input["topic"], "story": response}


if __name__ == "__main__":
    gen = StoryGenerator(model="gpt-4o-mini", show_dashboard=True)
    result = gen(
        dataset=[
            {"topic": "a robot learning to paint"},
            {"topic": "a cat who solves mysteries"},
            {"topic": "time travel gone wrong"},
            {"topic": "an AI that writes poetry"},
        ]
    )

    print(f"\nGenerated {len(result.dataset)} stories")
    print(f"Total cost: ${result.total_cost:.4f}")
    print(f"Total tokens: {result.total_tokens:,}")
    print(f"\nResults:")
    for row in result.dataset:
        print(f"  [{row['topic']}]: {row['story'][:80]}...")
