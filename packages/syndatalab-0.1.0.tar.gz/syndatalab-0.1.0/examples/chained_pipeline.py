"""Chained pipeline: first generate topics, then generate content for each."""

from pydantic import BaseModel, Field

import syndatalab as sd


class TopicList(BaseModel):
    topics: list[str] = Field(description="A list of specific subtopics")


class TopicGenerator(sd.LLM):
    response_format = TopicList

    def prompt(self, input: dict) -> str:
        return f"List 3 specific subtopics within {input['domain']} that would make good tutorial content."

    def parse(self, input: dict, response: TopicList) -> list[dict]:
        return [{"domain": input["domain"], "topic": t} for t in response.topics]


class TutorialOutline(BaseModel):
    title: str
    sections: list[str] = Field(description="List of section headings")
    estimated_minutes: int


class OutlineGenerator(sd.LLM):
    response_format = TutorialOutline

    def prompt(self, input: dict) -> str:
        return f"Create a tutorial outline for: {input['topic']} (in the {input['domain']} domain)."

    def parse(self, input: dict, response: TutorialOutline) -> dict:
        return {
            "domain": input["domain"],
            "topic": input["topic"],
            "title": response.title,
            "sections": response.sections,
            "estimated_minutes": response.estimated_minutes,
        }


if __name__ == "__main__":
    # Chain: generate topics -> generate outlines
    topics = TopicGenerator(model="gpt-4o-mini")
    outlines = OutlineGenerator(model="gpt-4o-mini")

    pipeline = topics | outlines
    result = pipeline(
        dataset=[
            {"domain": "machine learning"},
            {"domain": "web development"},
        ]
    )

    print(f"\nGenerated {len(result.dataset)} tutorial outlines")
    for row in result.dataset:
        print(f"\n  [{row['domain']}] {row['title']}")
        print(f"  Sections: {len(row['sections'])}, ~{row['estimated_minutes']} min")
        for s in row["sections"]:
            print(f"    - {s}")
