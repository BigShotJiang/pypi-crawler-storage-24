"""Checkpoint/resume: demonstrates resuming a generation job after interruption.

Run this script, press Ctrl+C midway, then run again — it will resume from
where it left off, skipping already-completed rows.
"""

from pydantic import BaseModel, Field

import syndatalab as sd


class FactSheet(BaseModel):
    name: str
    category: str
    key_facts: list[str] = Field(description="3-5 key facts")
    fun_fact: str


class FactGenerator(sd.LLM):
    response_format = FactSheet

    def prompt(self, input: dict) -> str:
        return f"Create a fact sheet about {input['subject']} in the category of {input['category']}."

    def parse(self, input: dict, response: FactSheet) -> dict:
        return {
            "subject": input["subject"],
            "category": response.category,
            "key_facts": response.key_facts,
            "fun_fact": response.fun_fact,
        }


if __name__ == "__main__":
    gen = FactGenerator(
        model="gpt-4o-mini",
        max_concurrent_requests=2,  # Low concurrency to make interruption easier to demo
        show_dashboard=True,
    )

    # Large dataset — interrupt and resume
    subjects = [
        {"subject": "Python", "category": "programming languages"},
        {"subject": "Rust", "category": "programming languages"},
        {"subject": "PostgreSQL", "category": "databases"},
        {"subject": "Redis", "category": "databases"},
        {"subject": "Docker", "category": "devops"},
        {"subject": "Kubernetes", "category": "devops"},
        {"subject": "React", "category": "frontend"},
        {"subject": "Vue.js", "category": "frontend"},
        {"subject": "FastAPI", "category": "web frameworks"},
        {"subject": "Django", "category": "web frameworks"},
    ]

    result = gen(dataset=subjects)

    print(f"\nGenerated {len(result.dataset)} fact sheets")
    print(f"Run ID: {result.run_id}")
    print(f"Failed: {len(result.failed)} rows")

    if result.failed:
        print("\nFailed rows (re-run to retry):")
        for f in result.failed:
            print(f"  Row {f['row_index']}: {f['error'][:80]}")
