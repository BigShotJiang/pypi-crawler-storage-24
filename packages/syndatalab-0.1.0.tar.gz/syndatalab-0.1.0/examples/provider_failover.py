"""Provider failover: automatically fall back to another model if the primary fails."""

import syndatalab as sd


class SummaryGenerator(sd.LLM):
    def prompt(self, input: dict) -> str:
        return f"Summarize this concept in one sentence: {input['concept']}"

    def parse(self, input: dict, response: str) -> dict:
        return {"concept": input["concept"], "summary": response}


if __name__ == "__main__":
    # If gpt-4o-mini fails (rate limit, outage), try Claude, then Ollama
    gen = SummaryGenerator(
        model="gpt-4o-mini",
        fallback_models=["claude-3-5-haiku-20241022", "ollama/llama3"],
    )

    result = gen(
        dataset=[
            {"concept": "Gradient descent"},
            {"concept": "Transformer architecture"},
            {"concept": "Reinforcement learning"},
        ]
    )

    print(f"\nGenerated {len(result.dataset)} summaries")
    for row in result.dataset:
        print(f"  {row['concept']}: {row['summary']}")
