"""Quality filtering: deduplicate and filter generated outputs."""

from pydantic import BaseModel, Field

import syndatalab as sd


class Explanation(BaseModel):
    explanation: str = Field(description="A clear explanation of the concept")
    example: str = Field(description="A concrete code example")


class ExplainerBot(sd.LLM):
    response_format = Explanation

    def prompt(self, input: dict) -> str:
        return f"Explain the concept of {input['concept']} in Python with a code example."

    def parse(self, input: dict, response: Explanation) -> dict:
        return {
            "concept": input["concept"],
            "explanation": response.explanation,
            "example": response.example,
        }


if __name__ == "__main__":
    gen = ExplainerBot(model="gpt-4o-mini")

    # Generate with quality filters applied post-generation
    result = gen(
        dataset=[
            {"concept": "list comprehension"},
            {"concept": "list comprehensions"},  # near-duplicate
            {"concept": "dictionary comprehension"},
            {"concept": "generator expressions"},
            {"concept": "decorators"},
            {"concept": "context managers"},
        ],
        filters=[
            sd.filters.min_length("explanation", 30),
            sd.filters.not_empty("explanation", "example"),
            sd.filters.no_duplicates("explanation", threshold=0.85),
            sd.filters.custom(lambda row: "sorry" not in row["explanation"].lower()),
        ],
    )

    quality = result.quality
    print(f"\nBefore filtering: {quality.get('total_before_filter', '?')} rows")
    print(f"After filtering: {quality.get('total_after_filter', '?')} rows")
    print(f"Duplicates removed: {quality.get('duplicates_removed', '?')}")
    print(f"\nResults:")
    for row in result.dataset:
        print(f"\n  [{row['concept']}]")
        print(f"  {row['explanation'][:100]}...")
