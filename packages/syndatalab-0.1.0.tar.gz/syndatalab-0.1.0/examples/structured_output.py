"""Structured output example: generate Q&A pairs with Pydantic validation."""

from pydantic import BaseModel, Field

import syndatalab as sd


class QAPair(BaseModel):
    question: str = Field(description="A clear, specific question")
    answer: str = Field(description="A detailed, accurate answer")
    difficulty: str = Field(description="easy, medium, or hard")


class QAGenerator(sd.LLM):
    response_format = QAPair

    def system_prompt(self, input: dict) -> str:
        return "You are an expert educator creating high-quality Q&A pairs for study materials."

    def prompt(self, input: dict) -> str:
        return (
            f"Generate a {input.get('difficulty', 'medium')} difficulty Q&A pair "
            f"about {input['topic']}."
        )

    def parse(self, input: dict, response: QAPair) -> dict:
        return {
            "topic": input["topic"],
            "question": response.question,
            "answer": response.answer,
            "difficulty": response.difficulty,
        }


if __name__ == "__main__":
    gen = QAGenerator(model="gpt-4o-mini")
    result = gen(
        dataset=[
            {"topic": "Python decorators", "difficulty": "medium"},
            {"topic": "TCP/IP networking", "difficulty": "hard"},
            {"topic": "Git branching", "difficulty": "easy"},
            {"topic": "Docker containers", "difficulty": "medium"},
            {"topic": "SQL joins", "difficulty": "easy"},
        ]
    )

    print(f"\nGenerated {len(result.dataset)} Q&A pairs")
    print(f"Cost: ${result.total_cost:.4f}")
    print(f"\nSample output:")
    for row in result.dataset:
        print(f"\n  [{row['difficulty']}] {row['topic']}")
        print(f"  Q: {row['question']}")
        print(f"  A: {row['answer'][:100]}...")
