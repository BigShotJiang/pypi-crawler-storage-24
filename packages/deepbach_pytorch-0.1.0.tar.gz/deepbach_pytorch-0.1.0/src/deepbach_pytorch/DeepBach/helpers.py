"""
@author: Gaetan Hadjeres (Modified for PyTorch 1.10+)
"""

import torch

def cuda_variable(tensor, volatile=False):

    if torch.cuda.is_available():
        return tensor.cuda()
    else:
        return tensor


def to_numpy(variable):

    if torch.cuda.is_available():
        return variable.detach().cpu().numpy()
    else:
        return variable.detach().numpy()


def init_hidden(num_layers, batch_size, lstm_hidden_size,
                volatile=False):

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    
    hidden = (
        torch.randn(num_layers, batch_size, lstm_hidden_size, device=device),
        torch.randn(num_layers, batch_size, lstm_hidden_size, device=device)
    )
    return hidden