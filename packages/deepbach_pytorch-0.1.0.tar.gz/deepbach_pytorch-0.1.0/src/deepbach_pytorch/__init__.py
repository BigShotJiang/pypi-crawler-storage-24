import os
import torch
import music21
from .DeepBach.model_manager import DeepBach
from .DatasetManager.dataset_manager import DatasetManager
from .DatasetManager.metadata import FermataMetadata, TickMetadata, KeyMetadata

PACKAGE_ROOT = os.path.dirname(__file__)

def harmonize(input_file, output_path="output.xml", iterations=500):
    """
    开箱即用接口：输入 MIDI/XML 旋律，生成四部和声。
    :param input_file: 输入文件路径 (.mid 或 .xml)
    :param output_path: 输出文件路径
    :param iterations: 迭代次数，越多质量越高 (建议 500-1000)
    """
    dataset_manager = DatasetManager()
    
    metadatas = [
        FermataMetadata(),
        TickMetadata(subdivision=4),
        KeyMetadata()
    ]

    dataset = dataset_manager.get_dataset(
        name='bach_chorales',
        voice_ids=[0, 1, 2, 3],
        metadatas=metadatas,
        sequences_size=8,
        subdivision=4
    )

    model = DeepBach(
        dataset=dataset,
        note_embedding_dim=20,
        meta_embedding_dim=20,
        num_layers=2,
        lstm_hidden_size=256,
        dropout_lstm=0.5,
        linear_hidden_size=256
    )

    models_dir = os.path.join(PACKAGE_ROOT, 'models')
    if not os.path.exists(models_dir):
        raise FileNotFoundError(f"找不到模型目录: {models_dir}")

    print("Loading pre-trained models...")
    for i in range(4):
        found = False
        target_suffix = f",{i},20,20,2,256,0.5,256)"
        for fname in os.listdir(models_dir):
            if fname.endswith(target_suffix):
                model_path = os.path.join(models_dir, fname)
                model.voice_models[i].load_state_dict(
                    torch.load(model_path, map_location='cuda' if torch.cuda.is_available() else 'cpu')
                )
                found = True
                break
        if not found:
            print(f"Warning: Could not find weight file for voice {i}")

    if torch.cuda.is_available():
        model.cuda()
    model.eval_phase()

    print(f"Reading input melody: {input_file}")
    user_score = music21.converter.parse(input_file)

    score_tensor = dataset.get_score_tensor(user_score)
    metadata_tensor = dataset.get_metadata_tensor(user_score)
    
    sequence_length_ticks = score_tensor.shape[1]


    print(f"Generating harmonies for {sequence_length_ticks} ticks...")
    
    final_score, _, _ = model.generation(
        num_iterations=iterations,
        sequence_length_ticks=sequence_length_ticks,
        tensor_chorale=score_tensor,
        tensor_metadata=metadata_tensor,
        voice_index_range=[1, 4], 
        random_init=True 
    )

    # 6. 保存结果
    final_score.write('musicxml', fp=output_path)
    print(f"Success! Result saved to: {output_path}")
    return final_score