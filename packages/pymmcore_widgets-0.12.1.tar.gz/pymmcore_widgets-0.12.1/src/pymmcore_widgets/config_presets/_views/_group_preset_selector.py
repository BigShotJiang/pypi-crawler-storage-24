from __future__ import annotations

from typing import TYPE_CHECKING

from qtpy.QtCore import QModelIndex, QSignalBlocker, Qt, Signal
from qtpy.QtWidgets import QListView, QSplitter, QStackedWidget, QWidget

from pymmcore_widgets._models import QConfigGroupsModel

from ._config_groups_tree import ConfigGroupsTree
from ._undo_commands import (
    DuplicateGroupCommand,
    DuplicatePresetCommand,
    RemoveGroupCommand,
    RemovePresetCommand,
)
from ._undo_delegates import GroupPresetRenameDelegate

if TYPE_CHECKING:
    from qtpy.QtCore import QAbstractItemModel
    from qtpy.QtGui import QUndoStack


class GroupsPresetFinder(QStackedWidget):
    """Widget that switches between column and tree view for config groups.

    This mimics the macOS Finder's behavior with two main views:
    - Column view: Groups/presets/settings side by side (index 0)
    - Tree view: Hierarchical structure of groups and presets (index 1)
    """

    currentPresetChanged = Signal(QModelIndex, QModelIndex)
    currentGroupChanged = Signal(QModelIndex, QModelIndex)
    presetSelectionChanged = Signal(list)  # list[QModelIndex]

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)

        self._model: QConfigGroupsModel | None = None
        self._undo_stack: QUndoStack | None = None

        # STACK_0 : List views for groups and presets ----------------------

        self.group_list = QListView(self)
        self.group_list.setSelectionMode(QListView.SelectionMode.SingleSelection)

        self.preset_list = QListView(self)
        self.preset_list.setSelectionMode(QListView.SelectionMode.ExtendedSelection)

        # Create the splitter for the list views
        lists_splitter = QSplitter(Qt.Orientation.Horizontal)
        lists_splitter.addWidget(self.group_list)
        lists_splitter.addWidget(self.preset_list)

        # STACK_1 : Tree view for config groups ----------------------------

        self.config_groups_tree = ConfigGroupsTree(self)
        self.config_groups_tree.setSelectionMode(
            ConfigGroupsTree.SelectionMode.SingleSelection
        )
        self.config_groups_tree.setSelectionBehavior(
            ConfigGroupsTree.SelectionBehavior.SelectRows
        )

        # MAIN STACK  ------------------------------------------------------

        self.addWidget(lists_splitter)  # index 0
        self.addWidget(self.config_groups_tree)  # index 1

    def setUndoStack(self, undo_stack: QUndoStack) -> None:
        """Set the undo stack and configure delegates for undo/redo."""
        self._undo_stack = undo_stack

        # Set up undo-aware delegates for the list views
        # The list views handle group/preset renaming
        if undo_stack is not None:
            self.group_list.setItemDelegate(
                GroupPresetRenameDelegate(undo_stack, self.group_list)
            )
            self.preset_list.setItemDelegate(
                GroupPresetRenameDelegate(undo_stack, self.preset_list)
            )

            # The tree view already has PropertySettingDelegate set up,
            # but we need to update it to use undo commands
            self.config_groups_tree.setUndoStack(undo_stack)

    def model(self) -> QConfigGroupsModel | None:
        """Return the currently attached model."""
        return self._model

    def setModel(self, model: QAbstractItemModel | None) -> None:
        """Attach *model* to all views and give them one shared selection model."""
        if not isinstance(model, QConfigGroupsModel):
            raise TypeError("Model must be an instance of QConfigGroupsModel")

        self._model = model

        # Set models for all views.  preset_list gets the same model but is
        # hidden until a group is selected (otherwise it would show groups at
        # the root level, not presets).
        self.group_list.setModel(model)
        self.preset_list.setModel(model)
        self.config_groups_tree.setModel(model)

        self._connect_selection_models()

    def _connect_selection_models(self) -> None:
        """Connect all selection model signals to slots."""
        if group_sel := self.group_list.selectionModel():
            group_sel.currentChanged.connect(self._on_group_selection_changed)

        if preset_sel := self.preset_list.selectionModel():
            preset_sel.currentChanged.connect(self._on_preset_current_changed)
            preset_sel.selectionChanged.connect(self._on_preset_selection_changed)

        if tree_sel := self.config_groups_tree.selectionModel():
            tree_sel.currentChanged.connect(self._on_tree_selection_changed)

    def _on_group_selection_changed(
        self, current: QModelIndex, previous: QModelIndex
    ) -> None:
        """Handle change in the group_list selection."""
        prev_preset = self.preset_list.currentIndex()

        self.preset_list.setRootIndex(current if current.isValid() else QModelIndex())
        self.preset_list.setCurrentIndex(QModelIndex())

        with QSignalBlocker(self.config_groups_tree.selectionModel()):
            self.config_groups_tree.collapseAll()
            self.config_groups_tree.setCurrentIndex(current)
            self.config_groups_tree.expand(current)

        self.currentGroupChanged.emit(current, previous)
        if prev_preset.isValid():
            self.currentPresetChanged.emit(QModelIndex(), prev_preset)

    def _on_preset_current_changed(
        self, current: QModelIndex, previous: QModelIndex
    ) -> None:
        """Handle change in the preset_list current item."""
        with QSignalBlocker(self.config_groups_tree.selectionModel()):
            self.config_groups_tree.setCurrentIndex(current)
        self.currentPresetChanged.emit(current, previous)

    def _on_preset_selection_changed(self) -> None:
        """Handle change in the preset_list selection (multi-select)."""
        if sm := self.preset_list.selectionModel():
            self.presetSelectionChanged.emit(sm.selectedIndexes())

    def _group_preset_index(self, idx: QModelIndex) -> tuple[QModelIndex, QModelIndex]:
        """Extract group and preset indices from a given index."""
        parent = idx.parent()
        # idx is a SETTING
        if (group_idx := parent.parent()).isValid():
            return group_idx, parent
        # idx is a PRESET
        if parent.isValid():
            return parent, idx
        # idx is a GROUP
        return idx, QModelIndex()

    def _on_tree_selection_changed(
        self, current: QModelIndex, previous: QModelIndex
    ) -> None:
        """Handle change in the config_groups_tree selection."""
        group_idx, preset_idx = self._group_preset_index(current)
        prev_group, prev_preset = self._group_preset_index(previous)

        if group_idx.row() != prev_group.row():
            self.currentGroupChanged.emit(group_idx, prev_group)
            if prev_preset.isValid():
                self.currentPresetChanged.emit(preset_idx, prev_preset)
        elif preset_idx.row() != prev_preset.row():
            self.currentPresetChanged.emit(preset_idx, prev_preset)

        with (
            QSignalBlocker(self.group_list.selectionModel()),
            QSignalBlocker(self.preset_list.selectionModel()),
        ):
            self.group_list.setCurrentIndex(group_idx)
            self.preset_list.setRootIndex(
                group_idx if group_idx.isValid() else QModelIndex()
            )
            # clearSelection + setCurrentIndex to avoid stale multi-select
            self.preset_list.clearSelection()
            self.preset_list.setCurrentIndex(preset_idx)

    def _selected_index(self) -> QModelIndex:
        """Return the currently selected index from the group or preset list."""
        # First check focus-based selection
        if self.group_list.hasFocus():
            return self.group_list.currentIndex()
        elif self.preset_list.hasFocus():
            return self.preset_list.currentIndex()
        elif self.config_groups_tree.hasFocus():
            return self.config_groups_tree.currentIndex()

        # If no view has focus, check for valid current selections
        # This handles cases where focus has moved to toolbar buttons
        if self.currentIndex() == 0:  # Column view is active
            # Check preset list first since presets are more commonly operated on
            preset_idx = self.preset_list.currentIndex()
            if preset_idx.isValid():
                return preset_idx
            # Fall back to group list
            group_idx = self.group_list.currentIndex()
            if group_idx.isValid():
                return group_idx
        else:  # Tree view is active
            tree_idx = self.config_groups_tree.currentIndex()
            if tree_idx.isValid():
                return tree_idx

        return QModelIndex()

    def removeSelected(self) -> None:
        if self._model:
            selected_idx = self._selected_index()
            if self._undo_stack is not None:
                node = self._model._node_from_index(selected_idx)
                if node.is_group:
                    command = RemoveGroupCommand(self._model, selected_idx)
                    self._undo_stack.push(command)
                elif node.is_preset:
                    command = RemovePresetCommand(self._model, selected_idx)
                    self._undo_stack.push(command)
            else:
                # Fall back to direct model operation
                self._model.remove(selected_idx, ask_confirmation=True, parent=self)

    def duplicateSelected(self) -> None:
        if self._model:
            if self._undo_stack is not None:
                selected_idx = self._selected_index()
                if not selected_idx.isValid():
                    return

                node = self._model._node_from_index(selected_idx)
                if node.is_group:
                    command = DuplicateGroupCommand(self._model, selected_idx)
                    self._undo_stack.push(command)
                elif node.is_preset:
                    command = DuplicatePresetCommand(self._model, selected_idx)
                    self._undo_stack.push(command)
            else:
                # Fall back to direct model operations
                if self.group_list.hasFocus():
                    self._model.duplicate_group(self.group_list.currentIndex())
                elif self.preset_list.hasFocus():
                    self._model.duplicate_preset(self.preset_list.currentIndex())

    def showColumnView(self) -> None:
        """Switch to column view mode (groups and presets side by side)."""
        self.setCurrentIndex(0)
        # Give focus to the most-specific selected list
        if self.preset_list.currentIndex().isValid():
            self.preset_list.setFocus()
        else:
            self.group_list.setFocus()

    def showTreeView(self) -> None:
        """Switch to tree view mode (hierarchical view)."""
        # Sync tree selection from column view before switching
        preset_idx = self.preset_list.currentIndex()
        if preset_idx.isValid():
            target = preset_idx
        else:
            target = self.group_list.currentIndex()
        if target.isValid():
            with QSignalBlocker(self.config_groups_tree.selectionModel()):
                self.config_groups_tree.setCurrentIndex(target)
        self.setCurrentIndex(1)
        self.config_groups_tree.setFocus()

    def toggleView(self) -> None:
        """Toggle between column view and tree view modes."""
        if self.currentIndex() == 0:
            self.showTreeView()
        else:
            self.showColumnView()

    def setCurrentGroupAsChannelGroup(self) -> None:
        """Set the currently selected group as the channel group in the model."""
        if (model := self._model) and (idx := self.currentGroup()).isValid():
            model.set_channel_group(idx)

    def isTreeViewActive(self) -> bool:
        """Return True if tree view is currently active."""
        return bool(self.currentIndex() == 1)

    def setCurrentGroup(self, group: str) -> QModelIndex:
        """Set the currently selected group by name.

        Returns the index of the selected group, or an invalid index if not found.
        """
        if not (model := self._model):
            return QModelIndex()

        idx = model.index_for_group(group)
        self.group_list.setCurrentIndex(idx)
        return idx

    def currentGroup(self) -> QModelIndex:
        """Return the currently selected group index."""
        return self.group_list.currentIndex()

    def currentPreset(self) -> QModelIndex:
        """Return the currently selected preset index."""
        return self.preset_list.currentIndex()

    def selectedPresets(self) -> list[QModelIndex]:
        """Return all selected preset indices."""
        if sm := self.preset_list.selectionModel():
            return sm.selectedIndexes()  # type: ignore[no-any-return]
        return []

    def setCurrentPreset(self, group: str, preset: str) -> QModelIndex:
        """Set the currently selected preset by group and preset name.

        Returns the index of the selected preset, or an invalid index if not found.
        """
        if not (model := self._model):
            return QModelIndex()

        group_index = self.setCurrentGroup(group)
        idx = model.index_for_preset(group_index, preset)
        self.preset_list.setCurrentIndex(idx)
        return idx

    def clearSelection(self) -> None:
        """Clear selection in all views."""
        group_sel_model = self.group_list.selectionModel()
        if group_sel_model is not None:
            group_sel_model.clearCurrentIndex()
        self.config_groups_tree.clearSelection()
        self.preset_list.setRootIndex(QModelIndex())
        self.preset_list.setCurrentIndex(QModelIndex())
