#!/usr/bin/env python
###############################################################################
# (c) Copyright 2024 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
from __future__ import annotations

__all__ = ["start_productions", "check_validation"]

import json
import math
import subprocess
import traceback

from DIRAC.Core.Utilities.ReturnValues import returnValueOrRaise
from LHCbDIRAC.BookkeepingSystem.Client.BookkeepingClient import BookkeepingClient
from LHCbDIRAC.ProductionManagementSystem.Client.ProductionRequestClient import ProductionRequestClient
from LHCbDIRAC.ProductionManagementSystem.Utilities.Models import parse_obj
from LHCbDIRAC.ProductionManagementSystem.scripts.dirac_production_request_submit import submitProductionRequests
from LHCbDIRAC.TransformationSystem.Client.Transformation import Transformation
from LHCbDIRAC.TransformationSystem.Client.TransformationClient import TransformationClient

from .integrations import STREAM_TO_EVENTTYPE, RepoIssue, Request, Validation


def get_request_state(request_id):
    return returnValueOrRaise(ProductionRequestClient().getProductionRequest([request_id]))[int(request_id)][
        "RequestState"
    ]


def update_request_state(request_id, state):
    returnValueOrRaise(ProductionRequestClient().updateProductionRequest(int(request_id), {"RequestState": state}))
    print(f"Request {request_id} set to {state}")


def start_productions(logbook, issue):
    if "state::run-validation" in issue.labels:
        validation = True
    elif "state::ready" in issue.labels:
        if not issue.metadata.validations:
            raise NotImplementedError("No validation found")
        for request_id, request_info in issue.metadata.validations.items():
            if request_info.running:
                raise NotImplementedError()
            for result in returnValueOrRaise(
                TransformationClient().getTransformations(
                    {"TransformationID": request_info.transform_ids}, columns=["TransformationID", "Status"]
                )
            ):
                if result["Status"] not in {"Cleaning", "Cleaned"}:
                    raise NotImplementedError(f"Request {request_id} is not cleaned")
            current_state = get_request_state(request_id)
            if current_state == "Active":
                update_request_state(request_id, "Done")
            elif current_state not in {"Done", "Rejected"}:
                raise NotImplementedError(f"Request {request_id} is in state {current_state}")
        validation = False
    else:
        raise NotImplementedError(issue.labels)

    productionRequest = parse_obj(issue.request_yaml)
    if not productionRequest.submission_info:
        raise NotImplementedError("Submission info is required to submit a production request")

    # Set launch_parameters before submission so they are stored in the DB
    n_files_expected = None
    if validation:
        productionRequest.name = f"Validation - {productionRequest.name}"
        # Build BK query to find available runs
        cd = productionRequest.input_dataset.conditions_dict
        bk_query = {
            "ConfigName": cd.configName,
            "ConfigVersion": cd.configVersion,
            "FileType": cd.inFileType,
            "ProcessingPass": cd.inProPass,
            "DataQualityFlag": cd.inDataQualityFlag.replace(" ", "").split(","),
            "EventType": productionRequest.input_dataset.event_type,
            "DataTakingConditions": productionRequest.input_dataset.conditions_description,
        }
        if cd.inExtendedDQOK:
            bk_query["ExtendedDQOK"] = cd.inExtendedDQOK
        if cd.inSMOG2State:
            bk_query["SMOG2State"] = cd.inSMOG2State
        start_run = issue.run_yaml["start_run"]
        end_run = issue.run_yaml["end_run"]
        all_runs = sorted(
            run
            for run in returnValueOrRaise(BookkeepingClient().getListOfRuns(bk_query))
            if (start_run or 0) <= run <= (end_run or math.inf)
        )
        validation_runs = issue.run_yaml["validation_runs"]
        if validation_runs:
            runs = sorted(set(validation_runs))
        else:
            runs = [all_runs[0]]
        print("Runs to be validated:", runs)
        # Count expected files per run
        n_files_expected = 0
        for run in runs:
            result = returnValueOrRaise(BookkeepingClient().getFilesWithMetadata(bk_query | {"RunNumbers": run}))
            if result["TotalRecords"] == 0:
                raise NotImplementedError(f"Run {run} has no files")
            print(f"Run {run} has {result['TotalRecords']} files")
            n_files_expected += result["TotalRecords"]
        productionRequest.input_dataset.launch_parameters.run_numbers = [str(r) for r in runs]
        productionRequest.submission_info.out_config_name = "validation"
    else:
        productionRequest.input_dataset.launch_parameters.start_run = issue.run_yaml["start_run"]
        productionRequest.input_dataset.launch_parameters.end_run = issue.run_yaml["end_run"]

    productionIDs = submitProductionRequests([productionRequest], dryRun=False, createFiletypes=True)
    request_id = productionIDs[0][1]
    print("Submitted request", request_id)

    # Launch via dirac-production-request-launch subprocess
    cmd = ["dirac-production-request-launch", str(request_id)]

    # Dry run first
    print("Dry run:")
    subprocess.run(cmd, check=True)

    # Prompt for confirmation
    from rich.prompt import Prompt

    if Prompt.ask("Proceed with launch?", choices=["yes", "no"], default="no") != "yes":
        raise RuntimeError("Launch cancelled by user")

    # Real launch — capture output for transform_ids
    result = subprocess.run(cmd + ["--do-for-real"], capture_output=True, text=True, check=True)
    print(result.stdout)
    transform_ids = json.loads(result.stdout.splitlines()[-1])["transform_ids"]

    try:
        if validation:
            if request_id in issue.metadata.validations:
                raise NotImplementedError()
            issue.metadata.validations[request_id] = Validation(
                transform_ids=transform_ids,
                n_files_expected=n_files_expected,
            )
        else:
            issue.labels.pop(issue.labels.index("state::ready"))
            issue.labels.append("state::running-concurrent" if issue.run_yaml["concurrent"] else "state::running")
            issue.metadata.requests[request_id] = Request(transform_ids=transform_ids)
        issue.update_metadata()
    except Exception:
        print("Failed to update metadata in issue", issue.metadata)
        traceback.print_exc()

    subject = productionRequest.name
    if validation:
        body = f"Validation production was submitted with request ID: {request_id}"
    else:
        body = f"Production was submitted with request ID: {request_id}"
    if validation:
        subject = f"{subject} - Validation"
    attachments = {
        f"{request_id}-request.yaml": issue.request_yaml_blob,
        f"{request_id}-extra.yaml": issue.run_yaml_blob,
    }
    logbook_systems = ["Production"]
    if productionRequest.type == "Sprucing":
        logbook_systems.append("Sprucing")
    try:
        logbook.create_post(issue.url, transform_ids, subject, body, attachments, logbook_systems)
    except Exception:
        print("Failed to post to logbook")
        traceback.print_exc()

    try:
        update_request_state(request_id, "Active")
    except Exception:
        print("Failed to set request to active")
        traceback.print_exc()


def start_removal_transformation(logbook, issue: RepoIssue, request_id: int):
    if "state::running" not in issue.labels and "state::running-concurrent" not in issue.labels:
        raise NotImplementedError("Only submitting removals for issues in state::running or state::running-concurrent")

    request_metadata = issue.metadata.requests[request_id]
    sprucing_tid, merging_tid = request_metadata.transform_ids

    tc = TransformationClient()
    bkquery = returnValueOrRaise(tc.getBookkeepingQuery(sprucing_tid))
    bkquery["ProcessingPass"] = "/" + bkquery["ProcessingPass"]
    extra_param = returnValueOrRaise(tc.getAdditionalParameters(sprucing_tid))
    removal_trans = Transformation()
    removal_trans.setType("Removal")

    trans_name = "/".join(
        [
            "Removal-",
            bkquery["ConfigName"],
            bkquery["ConfigVersion"],
            bkquery["DataTakingConditions"],
            bkquery["ProcessingPass"],
            str(bkquery["EventType"]),
            f"{bkquery['FileType']}-issue-{issue.issue.iid}",
        ]
    )
    removal_trans.setBkQuery(bkquery)
    removal_trans.setTransformationName(trans_name)
    removal_trans.setTransformationGroup("RemoveReplicasWhenProcessed")
    removal_trans.setPlugin("RemoveReplicasWhenProcessed")
    removal_trans.setBody("removal;RemoveReplica")
    removal_trans.setSEParam("FromSEs", "['Tier1-Buffer']")
    long_name = f"RemoveReplicasWhenProcessed for issue {issue.issue.iid}"
    removal_trans.setDescription(long_name[:255])
    removal_trans.setLongDescription(long_name[:255])
    removal_trans.setAdditionalParam("ProcessingPasses", extra_param["groupDescription"].strip("/"))
    # removal_trans.setStatus("Active")
    removal_trans.setAgentType("Automatic")
    returnValueOrRaise(removal_trans.addTransformation())
    removal_id = returnValueOrRaise(removal_trans.getTransformationID())
    print(f"Submitted removal transformation {request_id=} {removal_id=}", request_id)

    try:

        issue.metadata.requests[request_id].removal = removal_id
        issue.update_metadata()
    except Exception:
        print("Failed to update metadata in issue", issue.metadata)
        traceback.print_exc()

    productionRequest = parse_obj(issue.request_yaml)
    subject = f"Removal for {productionRequest.name}"
    body = f"Removal transformation was submitted: {removal_id}\n\n"

    body += json.dumps(removal_trans.paramValues, indent=3)

    try:
        logbook.create_post(issue.url, [removal_id], subject, body, {}, ["Sprucing", "Data Management", "Production"])
    except Exception:
        print("Failed to post to logbook")
        traceback.print_exc()


def start_replication_transformation(logbook, issue: RepoIssue, request_id: int):
    if "state::running" not in issue.labels and "state::running-concurrent" not in issue.labels:
        raise NotImplementedError(
            "Only submitting replication for issues in state::running or state::running-concurrent"
        )

    request_metadata = issue.metadata.requests[request_id]
    sprucing_tid, merging_tid = request_metadata.transform_ids

    tc = TransformationClient()
    bkquery = returnValueOrRaise(tc.getBookkeepingQuery(sprucing_tid))
    merging_bkquery = returnValueOrRaise(tc.getBookkeepingQuery(merging_tid))

    extra_param = returnValueOrRaise(tc.getAdditionalParameters(sprucing_tid))
    bkquery["ProcessingPass"] = "/" + bkquery["ProcessingPass"] + extra_param["groupDescription"]
    # This relies on the assumption that the output FileType of the merging is always the same
    # as the input FileType
    bkquery["FileType"] = merging_bkquery["FileType"]
    replication_trans = Transformation()
    replication_trans.setType("Replication")

    trans_name = "/".join(
        [
            "Replication-",
            bkquery["ConfigName"],
            bkquery["ConfigVersion"],
            bkquery["DataTakingConditions"],
            bkquery["ProcessingPass"],
            str(bkquery["EventType"]),
            f"ALL-issue-{issue.issue.iid}",
        ]
    )
    replication_trans.setBkQuery(bkquery)
    replication_trans.setTransformationName(trans_name)

    plugin_name = "TurboDSTBroadcast" if bkquery["EventType"] == STREAM_TO_EVENTTYPE["TURBO"] else "LHCbDSTBroadcast"
    replication_trans.setTransformationGroup(plugin_name)

    replication_trans.setPlugin(plugin_name)
    long_name = f"{plugin_name} for issue {issue.issue.iid}"
    replication_trans.setDescription(long_name[:255])
    replication_trans.setLongDescription(long_name[:255])
    # replication_trans.setStatus("Active")
    replication_trans.setAgentType("Automatic")
    returnValueOrRaise(replication_trans.addTransformation())
    replication_id = returnValueOrRaise(replication_trans.getTransformationID())
    print(f"Submitted replication transformation {request_id=} {replication_id=}", request_id)

    try:

        issue.metadata.requests[request_id].replication = replication_id
        issue.update_metadata()
    except Exception:
        print("Failed to update metadata in issue", issue.metadata)
        traceback.print_exc()

    productionRequest = parse_obj(issue.request_yaml)
    subject = f"Replication for {productionRequest.name}"
    body = f"Replication transformation was submitted: {replication_id}\n\n"

    body += json.dumps(replication_trans.paramValues, indent=3)

    try:
        logbook.create_post(
            issue.url, [replication_id], subject, body, {}, ["Sprucing", "Data Management", "Production"]
        )
    except Exception:
        print("Failed to post to logbook")
        traceback.print_exc()


def check_validation(issue, prod_id):
    request_metadata = issue.metadata.validations[prod_id]

    if not request_metadata.running:
        raise NotImplementedError()

    result = returnValueOrRaise(
        TransformationClient().getTransformations(
            {"TransformationID": request_metadata.transform_ids}, columns=["TransformationID", "Status"]
        )
    )
    statuses = {x["Status"] for x in result}
    if statuses.issubset({"Cleaning", "Cleaned"}):
        request_metadata.running = False
        request_metadata.cleaned = True
        issue.update_metadata()
        update_request_state(prod_id, "Done")
        print("Request is cleaned, validation will need to be resubmitted")
        return

    query = {"TransformationID": request_metadata.transform_ids}
    results = {}
    stats = returnValueOrRaise(TransformationClient().getTransformations(query, columns=["TransformationID", "Status"]))
    for stat in stats:
        results[stat.pop("TransformationID")] = stat | {"FileStatus": {}}
    file_stats = returnValueOrRaise(
        TransformationClient().getCounters("TransformationFiles", ["TransformationID", "Status"], query)
    )
    for meta, count in file_stats:
        results[meta["TransformationID"]]["FileStatus"][meta["Status"]] = count
    is_idle = all(
        x["Status"] == "Idle" and "Assigned" not in x["FileStatus"] and sum(x["FileStatus"].values()) > 0
        for x in results.values()
    )
    is_complete = all(set(x["FileStatus"]).issubset({"Processed", "Removed", "NotProcessed"}) for x in results.values())
    print(f"Request {prod_id}: {request_metadata.n_files_expected=} {is_idle=} {is_complete=}: {results}")
    if not is_idle:
        print("Validation is still running")
    elif is_complete:
        n_processed = results[min(results)]["FileStatus"]["Processed"]
        n_processed += results[min(results)]["FileStatus"].get("Removed", 0)
        n_processed += results[min(results)]["FileStatus"].get("NotProcessed", 0)
        if request_metadata.n_files_expected != n_processed:
            raise NotImplementedError()
        message = (
            """The validation is complete. Please check the results and update the ~"state::ready" when appropriate."""
        )
        issue.discussions.create({"body": message})
        issue.labels.pop(issue.labels.index("state::run-validation"))
        issue.labels.append("state::check-validation")
        request_metadata.running = False
        issue.update_metadata()
        print("Validation is complete")
    else:
        print("Something went wrong, please check the status of the transformations!")
