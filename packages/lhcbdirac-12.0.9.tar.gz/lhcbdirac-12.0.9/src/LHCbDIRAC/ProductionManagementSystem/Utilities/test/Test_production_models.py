###############################################################################
# (c) Copyright 2019 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "LICENSE".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
"""Test for Production Models"""

import pytest
import yaml
from pathlib import Path

from DIRAC import S_OK
from LHCbDIRAC.ProductionManagementSystem.Utilities.Models import parse_obj
from LHCbDIRAC.ProductionManagementSystem.Utilities.ModelCompatibility import (
    step_to_step_manager_dict,
    runs_to_input_query,
)

EXAMPLE_YAML_FILES = list((Path(__file__).parent / "example_yamls").glob("*.yaml"))


@pytest.mark.parametrize("yaml_path", EXAMPLE_YAML_FILES)
def test_models(yaml_path, monkeypatch):
    monkeypatch.setattr(
        "LHCbDIRAC.ProductionManagementSystem.Utilities.Models.getProxyInfo", lambda: S_OK({"username": "test_user"})
    )

    for pr in yaml.safe_load(yaml_path.read_text()):
        assert parse_obj(pr)


sprucing_expected_step_info = {
    "ApplicationName": "Moore",
    "ApplicationVersion": "v54r15",
    "CONDDB": "",
    "DDDB": "",
    "DQTag": "",
    "OptionFiles": (
        '{"entrypoint":"Hlt2Conf.Sprucing_production:pass_spruce_production",'
        '"extra_options":{"input_raw_format":0.5,"input_type":'
        '"RAW","simulation":false,"data_type":"Upgrade",'
        '"geometry_version":"trunk","conditions_version":"master",'
        '"compression":"ZSTD:1","output_type":"ROOT",'
        '"input_process":"Hlt2","process":"Spruce"},'
        '"extra_args":[]}'
    ),
    "ExtraPackages": "",
    "ProcessingPass": "SprucingPass23",
    "StepName": "Passthrough sprucing",
    "isMulticore": "N",
    "Visible": "Y",
    "mcTCK": "",
    "Usable": "Yes",
    "SystemConfig": "",
}


@pytest.mark.parametrize("yaml_path", EXAMPLE_YAML_FILES)
def test_step_to_step_manager_dict(yaml_path, monkeypatch):
    monkeypatch.setattr(
        "LHCbDIRAC.ProductionManagementSystem.Utilities.Models.getProxyInfo", lambda: S_OK({"username": "test_user"})
    )

    for pr in yaml.safe_load(yaml_path.read_text()):
        p = parse_obj(pr)
        for j, step in enumerate(p.steps, start=1):
            step_info = step_to_step_manager_dict(j, step)
            if step.processing_pass == "SprucingPass23":
                assert step_info["Step"] == sprucing_expected_step_info
                assert step_info["InputFileTypes"] == [
                    {"FileType": "MDF", "Visible": "Y"},
                ]
                assert step_info["OutputFileTypes"] == [
                    {"FileType": "SL.DST", "Visible": "N"},
                    {"FileType": "CHARM.DST", "Visible": "N"},
                    {"FileType": "B2CC.DST", "Visible": "N"},
                    {"FileType": "RD.DST", "Visible": "N"},
                    {"FileType": "BANDQ.DST", "Visible": "N"},
                    {"FileType": "QEE.DST", "Visible": "N"},
                    {"FileType": "B2OC.DST", "Visible": "N"},
                    {"FileType": "BNOC.DST", "Visible": "N"},
                ]


@pytest.mark.parametrize(
    "runs, expected",
    [
        ([], ""),
        ([1], "1"),
        (["34"], "34"),
        (["34", "35"], "34,35"),
        (["34:36"], "34,35,36"),
        (["34:36", "38"], "34,35,36,38"),
        (["34:36", "38:40"], "34,35,36,38,39,40"),
    ],
)
def test_runs_to_input_query(runs, expected):
    assert ",".join(runs_to_input_query(runs)) == expected


def _make_data_production(*, launch_parameters=None, out_config_name=None):
    """Build a minimal DataProduction dict for testing."""
    submission_info = {
        "transforms": [
            {
                "type": "DataReconstruction",
                "steps": [0],
                "output_se": "Tier1-Buffer",
                "input_data_policy": "download",
                "input_plugin": "RAWProcessing",
                "output_mode": "Run",
                "group_size": 1,
            },
        ],
    }
    if out_config_name is not None:
        submission_info["out_config_name"] = out_config_name
    data = {
        "type": "Reconstruction",
        "priority": "1a",
        "name": "Test production",
        "wg": "DPA",
        "input_dataset": {
            "conditions_dict": {
                "configName": "LHCb",
                "configVersion": "Collision24",
                "inFileType": "RAW",
                "inProPass": "Real Data",
            },
            "conditions_description": "Beam6800GeV-VeloClosed-MagDown",
            "event_type": "94000000",
        },
        "submission_info": submission_info,
        "steps": [
            {
                "name": "Reco step",
                "processing_pass": "RecoPass1",
                "visible": True,
                "application": {"name": "Moore", "version": "v1r0"},
                "data_pkgs": [],
                "options": {"entrypoint": "test:main"},
                "input": [{"type": "RAW", "visible": True}],
                "output": [{"type": "DST", "visible": True}],
            },
        ],
    }
    if launch_parameters is not None:
        data["input_dataset"]["launch_parameters"] = launch_parameters
    return data


class TestValidationLaunchParameters:
    """Test that validation requests require run_numbers and forbid start_run/end_run."""

    @pytest.fixture(autouse=True)
    def _patch_proxy(self, monkeypatch):
        monkeypatch.setattr(
            "LHCbDIRAC.ProductionManagementSystem.Utilities.Models.getProxyInfo",
            lambda: S_OK({"username": "test_user"}),
        )

    def test_validation_with_run_numbers(self):
        data = _make_data_production(
            launch_parameters={"run_numbers": ["12345"]},
            out_config_name="validation",
        )
        result = parse_obj(data)
        assert result.submission_info.out_config_name == "validation"
        assert result.input_dataset.launch_parameters.run_numbers == ["12345"]

    def test_validation_missing_run_numbers(self):
        data = _make_data_production(out_config_name="validation")
        with pytest.raises(Exception, match="Expected run_numbers to be provided"):
            parse_obj(data)

    def test_validation_with_start_run_no_run_numbers(self):
        data = _make_data_production(
            launch_parameters={"start_run": 100},
            out_config_name="validation",
        )
        with pytest.raises(Exception, match="Expected start_run to be None"):
            parse_obj(data)

    def test_validation_with_end_run_no_run_numbers(self):
        data = _make_data_production(
            launch_parameters={"end_run": 200},
            out_config_name="validation",
        )
        with pytest.raises(Exception, match="Expected end_run to be None"):
            parse_obj(data)

    def test_no_validation_with_start_end_run(self):
        """Non-validation requests should accept start_run/end_run."""
        data = _make_data_production(
            launch_parameters={"start_run": 100, "end_run": 200},
        )
        result = parse_obj(data)
        assert result.input_dataset.launch_parameters.start_run == 100
        assert result.input_dataset.launch_parameters.end_run == 200


def _make_step(name, processing_pass, *, input_types, output_types, visible=True):
    """Build a minimal step dict."""
    return {
        "name": name,
        "processing_pass": processing_pass,
        "visible": visible,
        "application": {"name": "Moore", "version": "v1r0"},
        "data_pkgs": [],
        "options": {"entrypoint": "test:main"},
        "input": [{"type": t, "visible": True} for t in input_types],
        "output": [{"type": t, "visible": v} for t, v in output_types],
    }


def _make_multi_step_data_production(*, transforms=None):
    """Build a 2-step DataProduction (DataReconstruction + Merge)."""
    if transforms is None:
        transforms = [
            {
                "type": "DataReconstruction",
                "steps": [0],
                "output_se": "Tier1-Buffer",
                "input_data_policy": "download",
                "input_plugin": "RAWProcessing",
                "output_mode": "Run",
                "group_size": 1,
            },
            {
                "type": "Merge",
                "steps": [1],
                "output_se": "Tier1-Buffer",
                "input_data_policy": "download",
                "input_plugin": "BySize",
                "output_mode": "Any",
                "group_size": 5,
            },
        ]
    return {
        "type": "Reconstruction",
        "priority": "1a",
        "name": "Test multi-step",
        "wg": "DPA",
        "input_dataset": {
            "conditions_dict": {
                "configName": "LHCb",
                "configVersion": "Collision24",
                "inFileType": "RAW",
                "inProPass": "Real Data",
            },
            "conditions_description": "Beam6800GeV-VeloClosed-MagDown",
            "event_type": "94000000",
        },
        "submission_info": {"transforms": transforms},
        "steps": [
            _make_step("Reco", "RecoPass1", input_types=["RAW"], output_types=[("DST", False)]),
            _make_step("Merge", "Merging", input_types=["DST"], output_types=[("DST", True)]),
        ],
    }


class TestSubmissionInfoValidation:
    """Tests for submission_info sanity-check validators."""

    @pytest.fixture(autouse=True)
    def _patch_proxy(self, monkeypatch):
        monkeypatch.setattr(
            "LHCbDIRAC.ProductionManagementSystem.Utilities.Models.getProxyInfo",
            lambda: S_OK({"username": "test_user"}),
        )

    # --- Validator 1: bounds ---

    def test_valid_single_step(self):
        data = _make_data_production()
        assert parse_obj(data)

    def test_valid_multi_step(self):
        data = _make_multi_step_data_production()
        assert parse_obj(data)

    def test_processing_step_index_out_of_bounds(self):
        data = _make_multi_step_data_production()
        data["submission_info"]["transforms"][0]["steps"] = [99]
        with pytest.raises(Exception, match="references step index 99"):
            parse_obj(data)

    def test_negative_step_index(self):
        data = _make_multi_step_data_production()
        data["submission_info"]["transforms"][0]["steps"] = [-1]
        with pytest.raises(Exception, match="references step index -1"):
            parse_obj(data)

    def test_no_submission_info_skips_validation(self):
        data = _make_multi_step_data_production()
        del data["submission_info"]
        assert parse_obj(data)

    def test_removal_input_step_idx_out_of_bounds(self):
        data = _make_multi_step_data_production()
        data["submission_info"]["transforms"].append(
            {
                "type": "RemoveInput",
                "input_plugin": "DestroyDataset",
                "input_step_idx": 99,
                "output_step_idx": 0,
                "group_size": 1,
            }
        )
        with pytest.raises(Exception, match="input_step_idx=99"):
            parse_obj(data)

    def test_removal_output_step_idx_out_of_bounds(self):
        data = _make_multi_step_data_production()
        data["submission_info"]["transforms"].append(
            {
                "type": "RemoveInput",
                "input_plugin": "DestroyDataset",
                "input_step_idx": 0,
                "output_step_idx": 99,
                "group_size": 1,
            }
        )
        with pytest.raises(Exception, match="output_step_idx=99"):
            parse_obj(data)

    def test_replication_step_idx_out_of_bounds(self):
        data = _make_multi_step_data_production()
        data["submission_info"]["transforms"].append(
            {
                "type": "ReplicateOutput",
                "input_plugin": "Replication",
                "step_idx": 99,
                "group_size": 1,
            }
        )
        with pytest.raises(Exception, match="step_idx=99"):
            parse_obj(data)

    # --- Validator 2: coverage ---

    def test_step_not_covered(self):
        data = _make_multi_step_data_production()
        # Only cover step 0, leaving step 1 uncovered
        data["submission_info"]["transforms"] = [
            data["submission_info"]["transforms"][0],
        ]
        with pytest.raises(Exception, match="not covered by any processing transform"):
            parse_obj(data)

    def test_step_in_two_transforms(self):
        data = _make_multi_step_data_production()
        # Both transforms claim step 0
        data["submission_info"]["transforms"][1]["steps"] = [0, 1]
        with pytest.raises(Exception, match="appear in multiple processing transforms"):
            parse_obj(data)

    def test_step_repeated_within_transform(self):
        data = _make_multi_step_data_production()
        data["submission_info"]["transforms"][0]["steps"] = [0, 0]
        # Step 0 duplicated within one transform
        with pytest.raises(Exception, match="appear in multiple processing transforms"):
            parse_obj(data)

    # --- Validator 3: visibility ---

    def test_mixed_visibility_rejected(self):
        data = _make_multi_step_data_production()
        # Give step 0 two outputs with different visibility
        data["steps"][0]["output"] = [
            {"type": "DST", "visible": True},
            {"type": "MDST", "visible": False},
        ]
        with pytest.raises(Exception, match="mixed visibility"):
            parse_obj(data)

    def test_all_visible_false_accepted(self):
        data = _make_multi_step_data_production()
        data["steps"][0]["output"] = [
            {"type": "DST", "visible": False},
            {"type": "MDST", "visible": False},
        ]
        # Need step 1 to consume both
        data["steps"][1]["input"] = [
            {"type": "DST", "visible": False},
            {"type": "MDST", "visible": False},
        ]
        assert parse_obj(data)

    def test_all_visible_true_accepted(self):
        data = _make_multi_step_data_production()
        data["steps"][0]["output"] = [
            {"type": "DST", "visible": True},
            {"type": "MDST", "visible": True},
        ]
        data["steps"][1]["input"] = [
            {"type": "DST", "visible": True},
            {"type": "MDST", "visible": True},
        ]
        assert parse_obj(data)
