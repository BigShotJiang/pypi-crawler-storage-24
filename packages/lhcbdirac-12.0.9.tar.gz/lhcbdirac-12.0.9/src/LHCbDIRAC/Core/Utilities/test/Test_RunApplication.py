###############################################################################
# (c) Copyright 2019 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
"""Tests for RunApplication, particularly the PTY-based output handling."""

from pathlib import Path
from types import SimpleNamespace

import pytest


@pytest.fixture
def mock_gaudi_app_module():
    """Create a mock gaudiAppModule with attributes needed for RunApplication."""
    return SimpleNamespace(
        applicationName="Boole",
        cleanedApplicationName="Boole",
        applicationVersion="v33r3",
        usePrmon=False,
        executable="gaudirun.py",
        production_id="00335120",
        prod_job_id="00017983",
        step_number="1",
        numberOfProcessors=1,
        applicationLog="applicationLog.txt",
        stdError="stdError.txt",
        stepInputData=["/lhcb/MC/2018/SIM/00335119/0010/00335119_00107625_1.sim"],
        TCK="",
        mcTCK="",
        extraPackages=[("AppConfig", "v3r460")],
        systemConfig="",
        poolXMLCatName="pool_xml_catalog.xml",
        XMLSummary="summaryBoole_00335120_00017983_1.xml",
        maxNumberOfEvents=0,
        processingPass=None,
        optionsFormat="",
        extraOptionsLine="",
        DDDBTag="2018-v03.06",
        condDBTag="sim-20201113-8-vc-mu100-Sim10",
        dqTag="",
        CPUe=None,
        numberOfEvents=0,
        runNumber=None,
        histoName="",
        outputFilePrefix="00335120_00017983_1",
    )


@pytest.mark.skipif(
    not Path("/cvmfs/lhcb.cern.ch").exists(),
    reason="CVMFS not available",
)
def test_run_application_detects_container(mock_gaudi_app_module, tmp_path, monkeypatch):
    """Verify that RunApplication can run lb-prod-run with container detection working.

    This test ensures that RunApplication's PTY-based output handling does not
    interfere with lb-run's container detection. Previously, stdbuf was used
    which injected via LD_PRELOAD and broke container detection in child
    processes like lb-describe-platform.
    """
    monkeypatch.chdir(tmp_path)

    # Import here to avoid issues if DIRAC is not available
    from LHCbDIRAC.Core.Utilities.RunApplication import RunApplication

    command_options = [
        "$APPCONFIGOPTS/Boole/Default.py",
        "$APPCONFIGOPTS/Boole/EnableSpillover.py",
        "$APPCONFIGOPTS/Boole/DataType-2015.py",
        "$APPCONFIGOPTS/Boole/Boole-SetOdinRndTrigger.py",
        "$APPCONFIGOPTS/Persistency/Compression-ZLIB-1.py",
    ]

    runner = RunApplication(
        gaudiAppModule=mock_gaudi_app_module,
        commandOptions=command_options,
        stepOutputTypes=["digi"],
        histogram=False,
        runNumberGauss=None,
        firstEventNumberGauss=0,
        eventTimeout=None,
    )

    # Run the application (processes 0 events, so it's fast)
    result = runner.run()

    assert result["OK"], f"RunApplication.run() failed: {result.get('Message', 'Unknown error')}"

    # Check the application log for container detection
    log_file = tmp_path / mock_gaudi_app_module.applicationLog
    assert log_file.exists(), f"Application log not found at {log_file}"

    log_content = log_file.read_text()

    # The key indicator that container detection worked
    assert "Decided best container to use is" in log_content, (
        "lb-run should detect a container technology (apptainer/singularity). "
        "If this fails, the PTY-based output handling may be interfering with "
        "container detection.\n"
        f"Log content:\n{log_content[:2000]}"
    )
