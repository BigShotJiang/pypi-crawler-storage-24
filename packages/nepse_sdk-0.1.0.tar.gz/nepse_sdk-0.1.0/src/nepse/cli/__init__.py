import click

from nepse import __version__
from nepse.core import NepseClient


@click.group()
@click.version_option(version=__version__, prog_name="nepse")
@click.pass_context
def main(ctx: click.Context) -> None:
    ctx.ensure_object(dict)
    ctx.obj["client"] = NepseClient()


@main.command()
@click.pass_context
def market_summary(ctx: click.Context) -> None:
    for item in ctx.obj["client"].market_summary():
        click.echo(f"{item.detail} {item.value:,.2f}")


@main.command()
@click.option("-a", "--all", "show_all", is_flag=True, default=False)
@click.pass_context
def top_gainers(ctx: click.Context, show_all: bool) -> None:
    for item in ctx.obj["client"].top_gainers(all=show_all):
        click.echo(f"{item.symbol:<12} {item.ltp:>10.2f}  {item.point_change:>+8.2f}  ({item.percentage_change:>+.2f}%)")


@main.command()
@click.option("-a", "--all", "show_all", is_flag=True, default=False)
@click.pass_context
def top_losers(ctx: click.Context, show_all: bool) -> None:
    for item in ctx.obj["client"].top_losers(all=show_all):
        click.echo(f"{item.symbol:<12} {item.ltp:>10.2f}  {item.point_change:>+8.2f}  ({item.percentage_change:>+.2f}%)")


@main.command()
@click.pass_context
def securities(ctx: click.Context) -> None:
    for item in ctx.obj["client"].securities():
        click.echo(f"{item.symbol:<12} {item.security_name}")


@main.command()
@click.argument("symbol")
@click.pass_context
def security(ctx: click.Context, symbol: str) -> None:
    detail = ctx.obj["client"].security_detail(symbol)

    click.echo(f"{detail.info.symbol} - {detail.info.security_name}")
    click.echo(f"Sector:          {detail.info.sector}")
    click.echo(f"LTP:             {detail.trade.last_traded_price:,.2f}")
    click.echo(f"Change:          {detail.trade.last_traded_price - detail.trade.previous_close:+,.2f}")
    click.echo(f"Open:            {detail.trade.open_price:,.2f}")
    click.echo(f"High:            {detail.trade.high_price:,.2f}")
    click.echo(f"Low:             {detail.trade.low_price:,.2f}")
    click.echo(f"Prev Close:      {detail.trade.previous_close:,.2f}")
    click.echo(f"Volume:          {detail.trade.total_trade_quantity:,}")
    click.echo(f"Transactions:    {detail.trade.total_trades:,}")
    click.echo(f"52W High:        {detail.trade.fifty_two_week_high:,.2f}")
    click.echo(f"52W Low:         {detail.trade.fifty_two_week_low:,.2f}")


@main.command()
@click.argument("symbol")
@click.pass_context
def dividends(ctx: click.Context, symbol: str) -> None:
    for record in ctx.obj["client"].dividends(symbol):
        click.echo(
            f"FY {record.fiscal_year_nepali:<12} "
            f"Cash: {record.cash_dividend:>6.2f}%  "
            f"Bonus: {record.bonus_share:>6.2f}%  "
            f"Right: {record.right_share:>6.2f}%"
        )


if __name__ == "__main__":
    main()
