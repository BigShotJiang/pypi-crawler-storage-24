from typing import TypedDict


class AuthResponse(TypedDict):
    accessToken: str
    refreshToken: str
    tokenType: str
    serverTime: int
    salt: str
    salt1: int
    salt2: int
    salt3: int
    salt4: int
    salt5: int
    isDisplayActive: bool
    popupDocFor: str


class MarketSummaryResponse(TypedDict):
    detail: str
    value: float


class TopStockResponse(TypedDict):
    symbol: str
    ltp: float
    cp: float
    pointChange: float
    percentageChange: float
    securityName: str
    securityId: int


class SecurityResponse(TypedDict):
    id: int
    symbol: str
    securityName: str
    name: str
    activeStatus: str


class SecurityTradeResponse(TypedDict):
    securityId: str
    openPrice: float
    highPrice: float
    lowPrice: float
    totalTradeQuantity: int
    totalTrades: int
    lastTradedPrice: float
    previousClose: float
    businessDate: str
    closePrice: float
    fiftyTwoWeekHigh: float
    fiftyTwoWeekLow: float
    lastUpdatedDateTime: str


class SecurityInfoResponse(TypedDict):
    id: int
    symbol: str
    securityName: str
    activeStatus: str
    permittedToTrade: str
    email: str
    sector: str


class SecurityDetailResponse(TypedDict):
    securityMcsData: SecurityTradeResponse
    securityData: SecurityInfoResponse


class FinancialYearResponse(TypedDict):
    fyName: str
    fyNameNepali: str


class DividendsNoticeResponse(TypedDict):
    financialYear: FinancialYearResponse
    cashDividend: float
    bonusShare: float
    rightShare: float


class CompanyNewsResponse(TypedDict, total=False):
    newsHeadline: str
    dividendsNotice: DividendsNoticeResponse | None


class DividendApplicationResponse(TypedDict, total=False):
    companyNews: CompanyNewsResponse | None
