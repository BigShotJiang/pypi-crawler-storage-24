from pathlib import Path

BASE_URL = "https://www.nepalstock.com"
AUTH_DIR = Path.home() / ".lagani" / "nepseweb"
AUTH_FILE = AUTH_DIR / ".auth"
WASM_FILE = AUTH_DIR / "css.wasm"

HEADERS = {
    "accept": "application/json, text/plain, */*",
    "referer": f"{BASE_URL}/",
    "user-agent": (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/145.0.0.0 Safari/537.36"
    ),
}
