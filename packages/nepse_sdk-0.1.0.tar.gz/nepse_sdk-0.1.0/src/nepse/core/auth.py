import json
from dataclasses import asdict, dataclass

from nepse.core.api_types import AuthResponse
from nepse.core.config import AUTH_DIR, AUTH_FILE


@dataclass
class AuthToken:
    access_token: str
    refresh_token: str
    token_type: str
    server_time: int
    salt: str
    salt1: int
    salt2: int
    salt3: int
    salt4: int
    salt5: int


def save_token(token: AuthToken) -> None:
    AUTH_DIR.mkdir(parents=True, exist_ok=True)
    AUTH_FILE.write_text(json.dumps(asdict(token)))


def load_token() -> AuthToken | None:
    if not AUTH_FILE.exists():
        return None
    try:
        data = json.loads(AUTH_FILE.read_text())
        return AuthToken(**data)
    except (json.JSONDecodeError, KeyError, TypeError):
        return None


def token_from_response(data: AuthResponse, access_token: str, refresh_token: str) -> AuthToken:
    return AuthToken(
        access_token=access_token,
        refresh_token=refresh_token,
        token_type=data["tokenType"],
        server_time=data["serverTime"],
        salt=data["salt"],
        salt1=data["salt1"],
        salt2=data["salt2"],
        salt3=data["salt3"],
        salt4=data["salt4"],
        salt5=data["salt5"],
    )
