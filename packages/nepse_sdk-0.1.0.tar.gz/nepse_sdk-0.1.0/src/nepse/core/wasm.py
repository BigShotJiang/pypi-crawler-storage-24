import httpx
import wasmtime

from nepse.core.api_types import AuthResponse
from nepse.core.config import BASE_URL, HEADERS, WASM_FILE, AUTH_DIR

WASM_URL = f"{BASE_URL}/assets/prod/css.wasm"


class TokenCleaner:
    def __init__(self) -> None:
        self._ensure_wasm()
        engine = wasmtime.Engine()
        self._store = wasmtime.Store(engine)
        module = wasmtime.Module.from_file(engine, str(WASM_FILE))
        self._instance = wasmtime.Instance(self._store, module, [])

    def _ensure_wasm(self) -> None:
        if WASM_FILE.exists():
            return
        AUTH_DIR.mkdir(parents=True, exist_ok=True)
        resp = httpx.get(WASM_URL, headers=HEADERS, verify=False)
        resp.raise_for_status()
        WASM_FILE.write_bytes(resp.content)

    def _call(self, name: str, *args: int) -> int:
        fn = self._instance.exports(self._store)[name]
        assert callable(fn)
        result: int = fn(self._store, *args)
        return result

    def _strip(self, token: str, positions: list[int]) -> str:
        for pos in sorted(positions, reverse=True):
            token = token[:pos] + token[pos + 1 :]
        return token

    def clean(self, data: AuthResponse) -> tuple[str, str]:
        s1, s2, s3, s4, s5 = data["salt1"], data["salt2"], data["salt3"], data["salt4"], data["salt5"]

        access_token = self._strip(data["accessToken"], [
            self._call("cdx", s1, s2, s3, s4, s5),
            self._call("rdx", s1, s2, s4, s3, s5),
            self._call("bdx", s1, s2, s4, s3, s5),
            self._call("ndx", s1, s2, s4, s3, s5),
            self._call("mdx", s1, s2, s4, s3, s5),
        ])

        refresh_token = self._strip(data["refreshToken"], [
            self._call("cdx", s2, s1, s3, s5, s4),
            self._call("rdx", s2, s1, s3, s4, s5),
            self._call("bdx", s2, s1, s4, s3, s5),
            self._call("ndx", s2, s1, s4, s3, s5),
            self._call("mdx", s2, s1, s4, s3, s5),
        ])

        return access_token, refresh_token
