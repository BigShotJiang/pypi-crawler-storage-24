from enum import Enum


class Endpoint(Enum):
    MARKET_SUMMARY = "/api/nots/market-summary/"
    TOP_GAINERS = "/api/nots/top-ten/top-gainer"
    TOP_LOSERS = "/api/nots/top-ten/top-loser"
    SECURITIES = "/api/nots/security"
    SECURITY_DETAIL = "/api/nots/security/{id}"
    DIVIDENDS = "/api/nots/application/dividend/{id}"
