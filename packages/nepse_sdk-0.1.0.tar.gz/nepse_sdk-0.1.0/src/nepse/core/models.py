from dataclasses import dataclass


@dataclass
class MarketSummaryItem:
    detail: str
    value: float


@dataclass
class TopStock:
    symbol: str
    ltp: float
    cp: float
    point_change: float
    percentage_change: float
    security_name: str
    security_id: int


@dataclass
class Security:
    id: int
    symbol: str
    security_name: str
    name: str
    active_status: str


@dataclass
class SecurityTradeData:
    security_id: str
    open_price: float
    high_price: float
    low_price: float
    total_trade_quantity: int
    total_trades: int
    last_traded_price: float
    previous_close: float
    business_date: str
    close_price: float
    fifty_two_week_high: float
    fifty_two_week_low: float
    last_updated: str


@dataclass
class SecurityInfo:
    id: int
    symbol: str
    security_name: str
    active_status: str
    permitted_to_trade: str
    email: str
    sector: str


@dataclass
class SecurityDetail:
    trade: SecurityTradeData
    info: SecurityInfo


@dataclass
class DividendRecord:
    fiscal_year: str
    fiscal_year_nepali: str
    cash_dividend: float
    bonus_share: float
    right_share: float
    headline: str
