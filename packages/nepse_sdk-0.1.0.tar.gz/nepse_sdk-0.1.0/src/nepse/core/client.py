from typing import cast

import httpx

from nepse.core.api_types import (
    AuthResponse,
    DividendApplicationResponse,
    MarketSummaryResponse,
    SecurityDetailResponse,
    SecurityResponse,
    TopStockResponse,
)
from nepse.core.auth import AuthToken, load_token, save_token, token_from_response
from nepse.core.config import BASE_URL, HEADERS
from nepse.core.endpoints import Endpoint
from nepse.core.models import (
    DividendRecord,
    MarketSummaryItem,
    Security,
    SecurityDetail,
    SecurityInfo,
    SecurityTradeData,
    TopStock,
)
from nepse.core.wasm import TokenCleaner


class NepseClient:
    def __init__(self) -> None:
        self._cleaner = TokenCleaner()
        self._http = httpx.Client(base_url=BASE_URL, headers=HEADERS, verify=False)
        self._token = self._resolve_token()
        self._securities_cache: list[Security] | None = None

    def _resolve_token(self) -> AuthToken:
        cached = load_token()
        if cached:
            return cached
        return self._fetch_token()

    def _fetch_token(self) -> AuthToken:
        data = cast(AuthResponse, self._http.get("/api/authenticate/prove").json())
        access, refresh = self._cleaner.clean(data)
        token = token_from_response(data, access, refresh)
        save_token(token)
        return token

    def _refresh_token(self) -> AuthToken:
        resp = self._http.post(
            "/api/authenticate/refresh-token",
            headers={
                "authorization": f"Salter {self._token.access_token}",
                "content-type": "application/json",
            },
            json={"refreshToken": self._token.refresh_token},
        )
        resp.raise_for_status()
        data = cast(AuthResponse, resp.json())
        access, refresh = self._cleaner.clean(data)
        token = token_from_response(data, access, refresh)
        save_token(token)
        return token

    def _ensure_token(self) -> None:
        try:
            self._token = self._refresh_token()
        except httpx.HTTPStatusError:
            self._token = self._fetch_token()

    def _get_json(self, path: str, params: dict[str, str] | None = None) -> object:
        headers = {"authorization": f"Salter {self._token.access_token}"}
        resp = self._http.get(path, headers=headers, params=params)

        if resp.status_code == 401:
            self._ensure_token()
            headers["authorization"] = f"Salter {self._token.access_token}"
            resp = self._http.get(path, headers=headers, params=params)

        resp.raise_for_status()
        return resp.json()

    def market_summary(self) -> list[MarketSummaryItem]:
        data = cast(list[MarketSummaryResponse], self._get_json(Endpoint.MARKET_SUMMARY.value))
        return [
            MarketSummaryItem(detail=item["detail"], value=item["value"])
            for item in data
        ]

    def top_gainers(self, all: bool = False) -> list[TopStock]:
        data = cast(list[TopStockResponse], self._get_json(Endpoint.TOP_GAINERS.value, params={"all": str(all).lower()}))
        return [self._parse_top_stock(item) for item in data]

    def top_losers(self, all: bool = False) -> list[TopStock]:
        data = cast(list[TopStockResponse], self._get_json(Endpoint.TOP_LOSERS.value, params={"all": str(all).lower()}))
        return [self._parse_top_stock(item) for item in data]

    def securities(self) -> list[Security]:
        if self._securities_cache is not None:
            return self._securities_cache
        data = cast(list[SecurityResponse], self._get_json(Endpoint.SECURITIES.value, params={"nonDelisted": "true"}))
        self._securities_cache = [
            Security(
                id=item["id"],
                symbol=item["symbol"],
                security_name=item["securityName"],
                name=item["name"],
                active_status=item["activeStatus"],
            )
            for item in data
        ]
        return self._securities_cache

    def _resolve_security_id(self, symbol: str) -> int:
        symbol = symbol.upper()
        for sec in self.securities():
            if sec.symbol == symbol:
                return sec.id
        raise ValueError(f"Unknown symbol: {symbol}")

    def security_detail(self, symbol: str) -> SecurityDetail:
        security_id = self._resolve_security_id(symbol)
        data = cast(SecurityDetailResponse, self._get_json(Endpoint.SECURITY_DETAIL.value.format(id=security_id)))
        trade_raw = data["securityMcsData"]
        info_raw = data["securityData"]
        return SecurityDetail(
            trade=SecurityTradeData(
                security_id=trade_raw["securityId"],
                open_price=trade_raw["openPrice"],
                high_price=trade_raw["highPrice"],
                low_price=trade_raw["lowPrice"],
                total_trade_quantity=trade_raw["totalTradeQuantity"],
                total_trades=trade_raw["totalTrades"],
                last_traded_price=trade_raw["lastTradedPrice"],
                previous_close=trade_raw["previousClose"],
                business_date=trade_raw["businessDate"],
                close_price=trade_raw["closePrice"],
                fifty_two_week_high=trade_raw["fiftyTwoWeekHigh"],
                fifty_two_week_low=trade_raw["fiftyTwoWeekLow"],
                last_updated=trade_raw["lastUpdatedDateTime"],
            ),
            info=SecurityInfo(
                id=info_raw["id"],
                symbol=info_raw["symbol"],
                security_name=info_raw["securityName"],
                active_status=info_raw["activeStatus"],
                permitted_to_trade=info_raw["permittedToTrade"],
                email=info_raw["email"],
                sector=info_raw["sector"],
            ),
        )

    def dividends(self, symbol: str) -> list[DividendRecord]:
        security_id = self._resolve_security_id(symbol)
        data = cast(list[DividendApplicationResponse], self._get_json(Endpoint.DIVIDENDS.value.format(id=security_id)))
        records: list[DividendRecord] = []
        for item in data:
            news = item.get("companyNews")
            if news is None:
                continue
            notice = news.get("dividendsNotice")
            if notice is None:
                continue
            fy = notice["financialYear"]
            records.append(DividendRecord(
                fiscal_year=fy["fyName"],
                fiscal_year_nepali=fy["fyNameNepali"],
                cash_dividend=notice["cashDividend"],
                bonus_share=notice["bonusShare"],
                right_share=notice["rightShare"],
                headline=news.get("newsHeadline", ""),
            ))
        return records

    @staticmethod
    def _parse_top_stock(item: TopStockResponse) -> TopStock:
        return TopStock(
            symbol=item["symbol"],
            ltp=item["ltp"],
            cp=item["cp"],
            point_change=item["pointChange"],
            percentage_change=item["percentageChange"],
            security_name=item["securityName"],
            security_id=item["securityId"],
        )

    @property
    def token(self) -> AuthToken:
        return self._token

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> "NepseClient":
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()
