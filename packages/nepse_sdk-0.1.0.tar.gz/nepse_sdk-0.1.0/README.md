# nepse-sdk

Unofficial Python SDK and CLI for the Nepal Stock Exchange (NEPSE).

## Installation

```
pip install nepse-sdk
```

## SDK Usage

```python
from nepse import NepseClient

with NepseClient() as client:
    for item in client.market_summary():
        print(item.detail, f"{item.value:,.2f}")

    detail = client.security_detail("ADBL")
    print(detail.info.symbol, detail.trade.last_traded_price)

    for record in client.dividends("ADBL"):
        print(record.fiscal_year_nepali, f"Cash: {record.cash_dividend}%")
```

All methods return fully typed dataclasses — no raw dicts.

## CLI Commands

```
nepse market-summary           # market turnover, traded shares, transactions, capitalization
nepse top-gainers              # top gaining stocks (use -a for all)
nepse top-losers               # top losing stocks (use -a for all)
nepse securities               # list all non-delisted securities
nepse security ADBL            # detail view for a security by symbol
nepse dividends ADBL           # dividend history for a security
```

## Disclaimer

This is an unofficial tool and is not affiliated with or endorsed by NEPSE (Nepal Stock Exchange) or Nepal Stock Exchange Ltd. Use at your own risk.

## License

MIT
