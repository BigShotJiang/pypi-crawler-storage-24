# mng-opencode

This package has been renamed to [imbue-mngr-opencode](https://pypi.org/project/imbue-mngr-opencode/).

Install the new package:

```
pip install imbue-mngr-opencode
```
