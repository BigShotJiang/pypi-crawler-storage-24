"""Exceptions used across INTERSECT.

Exceptions here should only be used in the SDK and in core services.
"""


class IntersectError(Exception):
    """Generic marker for INTERSECT-specific exceptions."""


class IntersectApplicationError(IntersectError):
    """This is a special IntersectException, thrown if user application logic throws ANY kind of Exception. The only caveat is that if a user explicitly throws an IntersectCapabilityException, in which case that logic will be handled instead.

    In general, validation should be expressed through JSON schema as much as possible; however, JSON schema is NOT a complete prescription for input validation.
    When this exception is thrown, however, we do not leak any exception information in the error message. On the other hand, if the input fails
    JSON schema validation, Pydantic will throw a specific ValidationError, and that exception information will deliberately be exposed in the error message.

    This exception should strictly be used for control flow - it should NEVER be a fatal exception
    """


class IntersectSetupError(IntersectError):
    """Exception thrown when there is an error in setting up the configuration of a Service/Client, PRIOR to publishing or handling a message.

    This should be considered a fatal exception.
    """
