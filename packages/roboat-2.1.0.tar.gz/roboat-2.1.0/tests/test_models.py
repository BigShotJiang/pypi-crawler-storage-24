"""
tests/test_models.py
~~~~~~~~~~~~~~~~~~~~
Unit tests for roboat models — no network required.
"""

import pytest
from roboat.models import (
    User, Game, GameVotes, GameServer, Friend,
    Group, GroupRole, Badge, CatalogItem,
    UserPresence, RobuxBalance, Page,
)
from roboat.trades import Trade, TradeOffer, TradeAsset
from roboat.messages import Message
from roboat.inventory import InventoryAsset
from roboat.develop import Universe


# ─────────────────────────────────────────────────────────
# User
# ─────────────────────────────────────────────────────────

class TestUser:
    def test_from_dict_basic(self):
        u = User.from_dict({
            "id": 156, "name": "builderman",
            "displayName": "Builderman",
            "description": "bio",
            "isBanned": False,
            "hasVerifiedBadge": True,
        })
        assert u.id == 156
        assert u.name == "builderman"
        assert u.has_verified_badge is True
        assert u.is_banned is False

    def test_from_dict_defaults(self):
        u = User.from_dict({"id": 1, "name": "Roblox", "displayName": "ROBLOX"})
        assert u.description == ""
        assert u.is_banned is False

    def test_str_verified(self):
        u = User.from_dict({"id": 1, "name": "Roblox", "displayName": "ROBLOX",
                             "hasVerifiedBadge": True})
        assert "✓" in str(u)
        assert "Roblox" in str(u)

    def test_str_banned(self):
        u = User.from_dict({"id": 9, "name": "x", "displayName": "x",
                             "isBanned": True})
        assert "BANNED" in str(u)


# ─────────────────────────────────────────────────────────
# Game
# ─────────────────────────────────────────────────────────

class TestGame:
    SAMPLE = {
        "id": 2753915549, "rootPlaceId": 6872265039,
        "name": "Adopt Me!", "description": "Pets!",
        "creator": {"name": "Uplift Games", "id": 100, "type": "Group"},
        "price": None, "playing": 50000, "visits": 30_000_000_000,
        "maxPlayers": 50, "created": "2017-07-14", "updated": "2024-01-01",
        "genre": "Town and City",
        "isFavoritedByUser": False, "favoritedCount": 10_000_000,
    }

    def test_from_dict(self):
        g = Game.from_dict(self.SAMPLE)
        assert g.id == 2753915549
        assert g.name == "Adopt Me!"
        assert g.visits == 30_000_000_000
        assert g.creator_name == "Uplift Games"
        assert g.creator_type == "Group"

    def test_str_contains_name(self):
        g = Game.from_dict(self.SAMPLE)
        assert "Adopt Me!" in str(g)
        assert "30,000,000,000" in str(g)


# ─────────────────────────────────────────────────────────
# GameVotes
# ─────────────────────────────────────────────────────────

class TestGameVotes:
    def test_ratio_calculation(self):
        v = GameVotes(universe_id=1, up_votes=900, down_votes=100)
        assert v.ratio == 90.0

    def test_ratio_zero_votes(self):
        v = GameVotes(universe_id=1, up_votes=0, down_votes=0)
        assert v.ratio == 0.0

    def test_from_dict(self):
        v = GameVotes.from_dict({"id": 1, "upVotes": 500, "downVotes": 50})
        assert v.up_votes == 500
        assert v.down_votes == 50


# ─────────────────────────────────────────────────────────
# GameServer
# ─────────────────────────────────────────────────────────

class TestGameServer:
    def test_from_dict(self):
        s = GameServer.from_dict({
            "id": "abc-123", "maxPlayers": 12,
            "playing": 8, "fps": 59.9, "ping": 45,
        })
        assert s.max_players == 12
        assert s.playing == 8
        assert s.fps == 59.9

    def test_str(self):
        s = GameServer.from_dict({
            "id": "abc-123", "maxPlayers": 12,
            "playing": 8, "fps": 60, "ping": 20,
        })
        assert "8/12" in str(s)


# ─────────────────────────────────────────────────────────
# Friend
# ─────────────────────────────────────────────────────────

class TestFriend:
    def test_online_indicator(self):
        f = Friend.from_dict({"id": 1, "name": "x", "displayName": "x",
                               "isOnline": True})
        assert "🟢" in str(f)

    def test_offline_indicator(self):
        f = Friend.from_dict({"id": 1, "name": "x", "displayName": "x",
                               "isOnline": False})
        assert "⚫" in str(f)


# ─────────────────────────────────────────────────────────
# Group
# ─────────────────────────────────────────────────────────

class TestGroup:
    def test_from_dict(self):
        g = Group.from_dict({
            "id": 7, "name": "Roblox",
            "description": "Official",
            "owner": {"userId": 1, "username": "Roblox"},
            "memberCount": 3_000_000,
            "publicEntryAllowed": True,
            "hasVerifiedBadge": True,
        })
        assert g.id == 7
        assert g.member_count == 3_000_000
        assert g.owner_name == "Roblox"
        assert "✓" in str(g)


# ─────────────────────────────────────────────────────────
# GroupRole
# ─────────────────────────────────────────────────────────

class TestGroupRole:
    def test_from_dict(self):
        r = GroupRole.from_dict({
            "id": 1, "name": "Member", "rank": 1, "memberCount": 5000
        })
        assert r.name == "Member"
        assert r.rank == 1
        assert "Member" in str(r)


# ─────────────────────────────────────────────────────────
# CatalogItem
# ─────────────────────────────────────────────────────────

class TestCatalogItem:
    def test_from_dict_free(self):
        item = CatalogItem.from_dict({
            "id": 1, "itemType": "Asset", "name": "Friendly Rabbit",
            "description": "cute", "creatorName": "Roblox",
            "creatorTargetId": 1, "creatorType": "User",
            "price": None, "lowestPrice": None,
            "purchaseCount": 0, "favoriteCount": 0,
            "itemStatus": [],
        })
        assert item.price is None

    def test_off_sale_detection(self):
        item = CatalogItem.from_dict({
            "id": 1, "itemType": "Asset", "name": "x",
            "description": "", "creatorName": "x",
            "creatorTargetId": 1, "creatorType": "User",
            "price": None, "lowestPrice": None,
            "purchaseCount": 0, "favoriteCount": 0,
            "itemStatus": ["OffSale"],
        })
        assert item.is_off_sale is True


# ─────────────────────────────────────────────────────────
# UserPresence
# ─────────────────────────────────────────────────────────

class TestUserPresence:
    def test_status_labels(self):
        for type_id, label in [(0, "Offline"), (1, "Online"),
                                (2, "In Game"), (3, "In Studio")]:
            p = UserPresence(user_id=1, user_presence_type=type_id)
            assert p.status == label


# ─────────────────────────────────────────────────────────
# RobuxBalance
# ─────────────────────────────────────────────────────────

class TestRobuxBalance:
    def test_str(self):
        b = RobuxBalance(robux=12345)
        assert "12,345" in str(b)
        assert "Robux" in str(b)


# ─────────────────────────────────────────────────────────
# Page
# ─────────────────────────────────────────────────────────

class TestPage:
    def test_iteration(self):
        page = Page(data=[1, 2, 3], next_cursor="abc")
        assert list(page) == [1, 2, 3]
        assert len(page) == 3
        assert page.next_cursor == "abc"

    def test_from_dict_with_model(self):
        raw = {
            "data": [
                {"id": 1, "name": "A", "displayName": "A"},
                {"id": 2, "name": "B", "displayName": "B"},
            ],
            "nextPageCursor": "xyz",
        }
        page = Page.from_dict(raw, User)
        assert len(page) == 2
        assert isinstance(page.data[0], User)
        assert page.next_cursor == "xyz"


# ─────────────────────────────────────────────────────────
# TradeAsset / TradeOffer
# ─────────────────────────────────────────────────────────

class TestTrades:
    def test_trade_asset_rap(self):
        asset = TradeAsset(
            user_asset_id=1, serial_number=None, asset_id=100,
            name="Valkyrie Helm", recent_average_price=15000,
            original_price=None, asset_stock=None,
        )
        assert asset.recent_average_price == 15000
        assert "Valkyrie Helm" in str(asset)

    def test_offer_total_rap(self):
        offer = TradeOffer(user_id=1, user_name="x", robux=0, assets=[
            TradeAsset(1, None, 100, "Item A", 5000, None, None),
            TradeAsset(2, None, 101, "Item B", 3000, None, None),
        ])
        assert offer.total_rap == 8000

    def test_trade_status_emoji(self):
        t = Trade(id=1, user_id=2, user_name="x",
                  status="Completed", created="2024-01-01")
        assert "✅" in str(t)


# ─────────────────────────────────────────────────────────
# InventoryAsset
# ─────────────────────────────────────────────────────────

class TestInventoryAsset:
    def test_from_dict(self):
        a = InventoryAsset.from_dict({
            "userAssetId": 1, "assetId": 100, "name": "Dominus Aureus",
            "assetTypeId": 8, "created": "2012-01-01", "updated": "2012-01-01",
            "serialNumber": 5, "isTradable": True, "recentAveragePrice": 100000,
        })
        assert a.serial_number == 5
        assert a.is_tradable is True
        assert "#5" in str(a)
        assert "Tradable" in str(a)


# ─────────────────────────────────────────────────────────
# Badge
# ─────────────────────────────────────────────────────────

class TestBadge:
    def test_from_dict(self):
        b = Badge.from_dict({
            "id": 1, "name": "Welcome",
            "description": "First visit",
            "enabled": True,
            "statistics": {"awardedCount": 1000, "winRatePercentage": 50.0},
        })
        assert b.awarded_count == 1000
        assert "✅" in str(b)

    def test_disabled_badge(self):
        b = Badge.from_dict({
            "id": 2, "name": "Old Badge",
            "description": "", "enabled": False,
            "statistics": {},
        })
        assert "❌" in str(b)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
