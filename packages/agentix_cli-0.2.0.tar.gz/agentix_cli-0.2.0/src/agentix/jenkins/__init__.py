"""Jenkins integration for agentix."""
