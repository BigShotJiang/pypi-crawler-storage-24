"""Core infrastructure for agentix."""
