"""Configuration management for agentix."""
