"""Tests for agentix"""
