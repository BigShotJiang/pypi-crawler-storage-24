"""Reusable web UI components."""
