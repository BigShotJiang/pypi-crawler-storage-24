"""Risk score manager."""

from __future__ import annotations

from .signals import Feature, Signal


class RiskManager:
    """Accumulates weighted signals and maintains a clamped score."""

    def __init__(self, decay_factor: float = 1.0) -> None:
        self._score = 0.0
        self._decay_factor = max(0.0, min(1.0, decay_factor))

    def add_signal(self, signal: Signal, scale: float = 1.0) -> float:
        """Add a signal weight to current score."""
        previous = self._score
        self._score += float(signal.weight) * max(0.0, float(scale))
        self._score = max(0.0, min(100.0, self._score))
        return self._score - previous

    def add_feature(self, feature: Feature, scale: float = 1.0) -> float:
        """Add feature contribution to score."""
        previous = self._score
        self._score += float(feature.value) * max(0.0, float(scale))
        self._score = max(0.0, min(100.0, self._score))
        return self._score - previous

    def decay(self) -> tuple[float, float]:
        """Apply configured decay to score."""
        previous = self._score
        self._score *= self._decay_factor
        self._score = max(0.0, min(100.0, self._score))
        return previous, self._score

    @property
    def score(self) -> float:
        """Current score clamped to 0-100."""
        return max(0.0, min(100.0, self._score))
