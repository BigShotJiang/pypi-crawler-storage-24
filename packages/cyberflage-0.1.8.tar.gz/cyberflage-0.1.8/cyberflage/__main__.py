"""CLI entrypoint for the cyberflage package."""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
import traceback
from typing import Any

from .app import CyberFlage
from .config import build_config, load_config_file
from .core.signals import Event, events_to_signals


def _format_signal_label(signal: str) -> str:
    label_map = {
        "suspicious_port_scan": "Suspicious port scan detected",
        "credential_dump_attempt": "Credential dump attempt observed",
        "failed_auth_burst": "Rapid authentication failures",
        "new_external_ip": "Unknown external IP detected",
        "high_cpu": "Rapid activity spike (high CPU)",
    }
    return label_map.get(signal, signal.replace("_", " ").capitalize())


def _one_line_explanation(state: dict[str, Any]) -> str:
    level = str(state.get("level", "LOW"))
    signals = state.get("signals", [])
    if not isinstance(signals, list):
        signals = []
    if level == "CRITICAL":
        return "Critical risk detected due to multiple strong suspicious indicators."
    if level == "HIGH":
        return "High risk detected due to abnormal activity patterns and stacked signals."
    if level == "MEDIUM":
        return "Moderate risk detected; suspicious behavior should be investigated."
    return "Low risk state detected; monitoring remains stable."


def _closing_line(state: dict[str, Any]) -> str:
    level = str(state.get("level", "LOW"))
    signals = state.get("signals", [])
    if not isinstance(signals, list):
        signals = []
    if level == "LOW" and not signals:
        return "CyberFlage observed normal behavior and stayed in safe monitoring mode."
    return "CyberFlage detected suspicious behavior and responded safely."


def _print_summary(state: dict[str, Any], *, header: str = "CyberFlage Summary") -> None:
    reasons = state.get("explanation", [])
    if not isinstance(reasons, list):
        reasons = []
    signals = state.get("signals", [])
    if not isinstance(signals, list):
        signals = []
    action = state.get("action", "No action.")
    level = state.get("level", "LOW")
    risk_score = state.get("risk_score", 0)
    scenario = state.get("scenario")
    mode = state.get("mode", "MONITORING")
    decoy_details = state.get("decoy_details", {})
    print("--------------------------------")
    print(header)
    if scenario:
        print(f"Scenario: {scenario}")
    print("--------------------------------")
    print("")
    print("Signals:")
    if signals:
        for signal in signals:
            print(f"- {_format_signal_label(str(signal))}")
    else:
        print("- No suspicious signals detected")
    print("")
    print(f"Risk Score: {risk_score} ({level})")
    print("")
    print("Action:")
    print(f"- {action}")
    print("")
    print("Explanation:")
    if reasons:
        for reason in reasons:
            print(f"- {reason}")
    else:
        print("- No significant risk contributors detected")
    print("")
    print(f"Mode: {mode}")

    if isinstance(decoy_details, dict) and decoy_details:
        print("")
        print("--------------------------------")
        print("Decoy Activation Details:")
        print(f"REAL: {decoy_details.get('real_path', '-')}")
        print(f"DECOY: {decoy_details.get('decoy_path', '-')}")
        print(f"BACKUP: {decoy_details.get('backup_path', '-')}")
        print("--------------------------------")

    print("")
    print(_one_line_explanation(state))
    print(_closing_line(state))
    print("--------------------------------")


def _print_start_guide() -> None:
    print("====================================")
    print("Welcome to CyberFlage")
    print("")
    print("CyberFlage observes system behavior, explains risk changes, and recommends safe responses.")
    print("It uses an explicit pipeline: Event -> Signal -> Feature -> Risk -> Action.")
    print("")
    print("Quick demo commands:")
    print("- cyberflage start --demo")
    print("- cyberflage start --present")
    print("- cyberflage start --run-once")
    print("- cyberflage start --continuous --interval-seconds 5")
    print("- cyberflage start --config-file config.json --run-once")
    print("- cyberflage start --show-config")
    print("====================================")


def _print_missing_paths_guide() -> None:
    sample_path = os.path.join(os.path.expanduser("~"), "Desktop", "test_folder")
    decoy_path = f"{sample_path}_decoy"
    escaped_sample_path = sample_path.replace("\\", "\\\\")
    escaped_decoy_path = decoy_path.replace("\\", "\\\\")
    print("====================================")
    print("No protected paths configured.")
    print("")
    print("CyberFlage needs at least one folder to monitor.")
    print("")
    print("Quick setup:")
    print("")
    print("1. Create a folder:")
    print(f"   {sample_path}")
    print("")
    print("2. Create config.json:")
    print("{")
    print(f'  "protected_paths": ["{escaped_sample_path}"],')
    print(f'  "decoy_path": "{escaped_decoy_path}",')
    print('  "safety": { "destructive_actions_enabled": false }')
    print("}")
    print("")
    print("3. Run:")
    print("   cyberflage start --config-file config.json")
    print("")
    print("If you see 'Invalid JSON ... line 1 column 1', config.json is empty or invalid.")
    print("Tip: run 'cyberflage start --demo' to see the system in action.")
    print("====================================")


def _print_invalid_config_json_guide(config_file: str) -> None:
    sample_path = os.path.join(os.path.expanduser("~"), "Desktop", "test_folder")
    decoy_path = f"{sample_path}_decoy"
    escaped_sample_path = sample_path.replace("\\", "\\\\")
    escaped_decoy_path = decoy_path.replace("\\", "\\\\")
    print("")
    print("Quick fix:")
    print(f"1. Open {config_file} and replace its content with:")
    print("{")
    print(f'  "protected_paths": ["{escaped_sample_path}"],')
    print(f'  "decoy_path": "{escaped_decoy_path}",')
    print('  "safety": { "destructive_actions_enabled": false }')
    print("}")
    print("2. Save file and run:")
    print(f"   cyberflage start --config-file {config_file}")


def _scenario_narrative(title: str) -> str:
    narrative_map = {
        "Ransomware Simulation": "Simulating ransomware-like behavior: rapid file deletion pattern detected.",
        "Credential Attack Simulation": "Simulating account abuse: repeated authentication failures and unknown access source.",
    }
    return narrative_map.get(title, "Simulating suspicious behavior for explainable pipeline demonstration.")


def _run_demo(app: CyberFlage, *, present: bool = False) -> None:
    scenarios: list[tuple[str, list[Event]]] = [
        (
            "Ransomware Simulation",
            [
                Event(source="demo", event_type="suspicious_port_scan", severity=1.0),
                Event(source="demo", event_type="credential_dump_attempt", severity=1.0),
            ],
        ),
        (
            "Credential Attack Simulation",
            [
                Event(source="demo", event_type="failed_auth_burst", severity=0.8),
                Event(source="demo", event_type="new_external_ip", severity=0.7),
            ],
        ),
    ]

    pause_seconds = 1.2 if present else 0.0
    for title, events in scenarios:
        print("--------------------------------")
        print(f"Scenario: {title}")
        print("--------------------------------")
        print(_scenario_narrative(title))
        print("Pipeline: Event -> Signal -> Feature -> Risk -> Action")
        print("")
        print("Step 1/5 Event:")
        for event in events:
            print(f"- {event.event_type} (severity={event.severity})")
        if pause_seconds:
            time.sleep(pause_seconds)
        signals = events_to_signals(events)
        print("Step 2/5 Signal:")
        for signal in signals:
            print(f"- {signal.name} (+{signal.weight:.2f})")
        if pause_seconds:
            time.sleep(pause_seconds)
        level, features, risk_score, explanation = app.decision_engine.ingest_signals(signals)
        print("Step 3/5 Feature:")
        for feature in features:
            print(f"- {feature.name}: {feature.value:.2f}")
        if pause_seconds:
            time.sleep(pause_seconds)
        print(f"Step 4/5 Risk: {risk_score:.2f} ({level})")
        if pause_seconds:
            time.sleep(pause_seconds)
        action = app.deception_engine.evaluate(level)
        print(f"Step 5/5 Action: {action}")
        details = app.deception_engine.get_last_swap_details()
        if details:
            print("")
            print("--------------------------------")
            print("Decoy Activation Details:")
            print(f"REAL: {details.get('real_path', '-')}")
            print(f"DECOY: {details.get('decoy_path', '-')}")
            print(f"BACKUP: {details.get('backup_path', '-')}")
            print("--------------------------------")
        if pause_seconds:
            time.sleep(pause_seconds)
        state = {
            "scenario": title,
            "signals": [signal.name for signal in signals],
            "explanation": explanation,
            "risk_score": round(risk_score, 2),
            "level": level,
            "action": action,
            "mode": app.deception_engine.mode,
            "decoy_details": details,
        }
        _print_summary(state, header="Demo Result")


def _run_continuous(app: CyberFlage, interval_seconds: float) -> None:
    print("Starting continuous monitoring. Press Ctrl+C to stop.")
    cycle = 1
    try:
        while True:
            state = app.run_once()
            _print_summary(state, header=f"System Status (Cycle {cycle})")
            cycle += 1
            time.sleep(interval_seconds)
    except KeyboardInterrupt:
        print("")
        print("Continuous monitoring stopped by user.")


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    """Parse command-line arguments."""
    raw_argv = list(sys.argv[1:] if argv is None else argv)
    normalized_argv = raw_argv
    if raw_argv and raw_argv[0].startswith("-"):
        # Backward compatibility: allow legacy usage like `cyberflage --run-once`.
        normalized_argv = ["start", *raw_argv]

    parser = argparse.ArgumentParser(description="CyberFlage command interface.")
    subparsers = parser.add_subparsers(dest="command")
    start_parser = subparsers.add_parser(
        "start",
        help="Start CyberFlage pipeline execution.",
        description="Run CyberFlage with explicit pipeline: Event -> Signal -> Feature -> Risk -> Action.",
    )
    restore_parser = subparsers.add_parser(
        "restore",
        help="Restore real environment from latest decoy backup.",
        description="Restore real environment using DeceptionEngine restore flow.",
    )
    target = start_parser
    target.add_argument(
        "--config",
        type=str,
        default=None,
        help="JSON object string with configuration overrides.",
    )
    target.add_argument(
        "--config-file",
        type=str,
        default="config.json",
        help="Path to JSON config file (used if present).",
    )
    target.add_argument(
        "--run-once",
        action="store_true",
        help="Run one detection cycle and print a formatted summary.",
    )
    target.add_argument(
        "--continuous",
        action="store_true",
        help="Run detection continuously until stopped (Ctrl+C).",
    )
    target.add_argument(
        "--interval-seconds",
        type=float,
        default=5.0,
        help="Delay between continuous cycles in seconds (default: 5).",
    )
    target.add_argument(
        "--demo",
        action="store_true",
        help="Run built-in demo scenarios with step-by-step pipeline output.",
    )
    target.add_argument(
        "--present",
        action="store_true",
        help="Presentation mode: demo with staged pauses and live-storytelling output.",
    )
    target.add_argument(
        "--show-config",
        action="store_true",
        help="Print effective config and exit.",
    )
    target.add_argument(
        "--debug",
        action="store_true",
        help="Enable debug mode with verbose errors.",
    )
    restore_parser.add_argument(
        "--config",
        type=str,
        default=None,
        help="JSON object string with configuration overrides.",
    )
    restore_parser.add_argument(
        "--config-file",
        type=str,
        default="config.json",
        help="Path to JSON config file (used if present).",
    )
    restore_parser.add_argument(
        "--debug",
        action="store_true",
        help="Enable debug mode with verbose errors.",
    )
    parsed = parser.parse_args(normalized_argv)
    setattr(parsed, "_raw_argv", raw_argv)
    return parsed


def main() -> int:
    """Run CyberFlage from CLI."""
    args = parse_args()
    if getattr(args, "command", None) is None:
        print("CyberFlage monitors activity, explains risk, and recommends safe responses.")
        print("Use 'cyberflage start --demo' to run demo.")
        print("Use 'cyberflage start --run-once' for a single cycle.")
        print("Use 'cyberflage start --continuous' for continuous monitoring.")
        return 0

    overrides: dict[str, Any] | None = None

    try:
        file_overrides: dict[str, Any] = {}
        if getattr(args, "config_file", None):
            try:
                file_overrides = load_config_file(args.config_file)
            except ValueError as exc:
                if "not found" not in str(exc):
                    raise

        cli_overrides: dict[str, Any] = {}
        raw_config = getattr(args, "config", None)
        if raw_config:
            try:
                parsed = json.loads(raw_config)
            except json.JSONDecodeError as exc:
                raise ValueError(f"Invalid JSON for --config: {exc}") from exc
            if not isinstance(parsed, dict):
                raise ValueError("--config must be a JSON object.")
            cli_overrides = parsed

        if file_overrides or cli_overrides:
            overrides = {**file_overrides, **cli_overrides}

        config = build_config(overrides)
        if not getattr(args, "debug", False):
            config.setdefault("logging", {})
            config["logging"]["level"] = "ERROR"
        if getattr(args, "show_config", False):
            print(json.dumps(config, indent=2))
            return 0

        if config.get("safety", {}).get("destructive_actions_enabled", False):
            print("WARNING: destructive actions are enabled.")
        else:
            print("Safety mode: destructive actions are disabled by default.")

        protected_paths = config.get("protected_paths", [])
        if not isinstance(protected_paths, list):
            protected_paths = []
        has_protected_paths = any(str(path).strip() for path in protected_paths)

        if (
            not has_protected_paths
            and not getattr(args, "demo", False)
            and not getattr(args, "present", False)
            and not getattr(args, "show_config", False)
            and not getattr(args, "run_once", False)
            and not getattr(args, "continuous", False)
            and getattr(args, "command", "") != "restore"
        ):
            _print_missing_paths_guide()
            return 0

        app = CyberFlage(config)
        if getattr(args, "command", "") == "restore":
            result = app.deception_engine.restore_real_environment()
            print(result)
            return 0
        if getattr(args, "interval_seconds", 5.0) <= 0:
            raise ValueError("--interval-seconds must be greater than 0.")
        if getattr(args, "present", False):
            _run_demo(app, present=True)
        elif getattr(args, "demo", False):
            _run_demo(app, present=False)
        elif getattr(args, "run_once", False):
            state = app.run_once()
            _print_summary(state, header="System Status")
        elif getattr(args, "continuous", False):
            _run_continuous(app, float(getattr(args, "interval_seconds", 5.0)))
        else:
            state = app.run_once()
            _print_summary(state, header="System Status")
            app.start_dashboard()
        return 0
    except ValueError as exc:
        message = str(exc)
        print(f"Configuration error: {message}")
        if "Invalid JSON in config file" in message:
            _print_invalid_config_json_guide(getattr(args, "config_file", "config.json"))
        return 2
    except Exception as exc:
        print(f"Runtime error: {exc}. Re-run with --debug for traceback.")
        if getattr(args, "debug", False):
            traceback.print_exc()
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
