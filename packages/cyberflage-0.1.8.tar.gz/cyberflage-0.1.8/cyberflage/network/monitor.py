"""Network monitor that emits raw events (not decisions)."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from ..core.signals import Event

try:
    import psutil
except Exception:  # pragma: no cover
    psutil = None


class NetworkMonitor:
    """Collects local telemetry and emits signals."""

    def __init__(self, config: dict[str, Any]) -> None:
        self.config = config
        processing = config.get("processing", {})
        self.max_events_per_cycle = int(processing.get("max_events_per_cycle", 5000))
        self.max_files_snapshot = int(processing.get("max_files_snapshot", 20000))
        self.file_create_burst_threshold = int(processing.get("file_create_burst_threshold", 15))
        self.file_delete_burst_threshold = int(processing.get("file_delete_burst_threshold", 10))
        self.file_rename_burst_threshold = int(processing.get("file_rename_burst_threshold", 8))
        self.suspicious_extensions = {
            str(ext).strip().lower()
            for ext in processing.get(
                "suspicious_extensions",
                [".exe", ".dll", ".bat", ".cmd", ".ps1", ".vbs", ".js"],
            )
            if str(ext).strip()
        }
        self.protected_paths = [
            Path(str(path)).expanduser().resolve(strict=False)
            for path in config.get("protected_paths", [])
            if str(path).strip()
        ]
        self._previous_snapshot: dict[str, tuple[int, float]] = {}

    def _snapshot_files(self) -> dict[str, tuple[int, float]]:
        """Capture a lightweight recursive snapshot of monitored files."""
        snapshot: dict[str, tuple[int, float]] = {}
        for root in self.protected_paths:
            if not root.exists() or not root.is_dir():
                continue
            for item in root.rglob("*"):
                if len(snapshot) >= self.max_files_snapshot:
                    return snapshot
                if not item.is_file():
                    continue
                try:
                    stat = item.stat()
                except OSError:
                    continue
                snapshot[str(item)] = (int(stat.st_size), float(stat.st_mtime))
        return snapshot

    def scan(self) -> list[Event]:
        """Return current events based on safe local checks."""
        events: list[Event] = []

        if psutil is not None:
            cpu_percent = float(psutil.cpu_percent(interval=0.0))
            if cpu_percent > 90.0:
                events.append(
                    Event(
                        source="network_monitor",
                        event_type="high_cpu",
                        severity=0.5,
                        payload={"cpu_percent": cpu_percent},
                    )
                )

        current_snapshot = self._snapshot_files()
        if self._previous_snapshot:
            previous_paths = set(self._previous_snapshot)
            current_paths = set(current_snapshot)
            added = current_paths - previous_paths
            removed = previous_paths - current_paths
            modified = {
                path
                for path in current_paths & previous_paths
                if current_snapshot[path] != self._previous_snapshot[path]
            }

            if len(added) >= self.file_create_burst_threshold:
                events.append(
                    Event(
                        source="file_monitor",
                        event_type="file_create_burst",
                        severity=min(1.0, len(added) / 50.0),
                        payload={"count": len(added)},
                    )
                )

            if len(removed) >= self.file_delete_burst_threshold:
                events.append(
                    Event(
                        source="file_monitor",
                        event_type="file_delete_burst",
                        severity=min(1.0, len(removed) / 40.0),
                        payload={"count": len(removed)},
                    )
                )

            if len(added) >= self.file_rename_burst_threshold and len(removed) >= self.file_rename_burst_threshold:
                events.append(
                    Event(
                        source="file_monitor",
                        event_type="file_rename_burst",
                        severity=min(1.0, (len(added) + len(removed)) / 60.0),
                        payload={"created": len(added), "deleted": len(removed)},
                    )
                )

            suspicious_added = sum(1 for path in added if Path(path).suffix.lower() in self.suspicious_extensions)
            if suspicious_added > 0:
                events.append(
                    Event(
                        source="file_monitor",
                        event_type="suspicious_extension_activity",
                        severity=min(1.0, 0.3 + (suspicious_added / 10.0)),
                        payload={"count": suspicious_added},
                    )
                )

            if len(modified) >= self.file_create_burst_threshold:
                events.append(
                    Event(
                        source="file_monitor",
                        event_type="file_modify_burst",
                        severity=min(1.0, len(modified) / 60.0),
                        payload={"count": len(modified)},
                    )
                )

        self._previous_snapshot = current_snapshot
        return events[: self.max_events_per_cycle]
