# CyberFlage

CyberFlage helps security teams quickly detect suspicious behavior, explain risk decisions, and trigger safe deception responses.

It uses a strict, explainable pipeline:

`Event -> Signal -> Feature -> Risk -> Action`

## Installation

```bash
pip install -e .
```

## Quick Start (3 steps)

```bash
1) pip install -e .
2) cyberflage start
3) cyberflage start --demo
```

## Demo

```bash
cyberflage start --demo
python simulate_attack.py
```

Both commands produce readable scenario summaries with sections:
Signals / Risk / Action / Explanation.

## CLI Examples

```bash
cyberflage start --run-once
cyberflage start --config-file config.json --run-once
cyberflage start --config "{\"thresholds\":{\"HIGH\":55,\"CRITICAL\":80}}" --run-once
cyberflage start --show-config
```
