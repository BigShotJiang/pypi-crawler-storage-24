import random
import os
import time
from tkinter import filedialog, Tk

def timer(n):
    return time.sleep(n)

def sum(n, m):
    return n + m

def sub(n, m):
    return n - m

def mult(n, m):
    return n * m

def div(n, m):
    if m != 0:
        return n / m
    else:
        return "ERROR: Division by 0"

def sqrt(n):
    if n >= 0:
        return n ** 0.5
    else:
        return "ERROR: Negative square root"

def pow(n, m):
    return n ** m

def binary(n):
    return bin(n)[2:]
    
def clear():
    if os.name == "posix":
        os.system("clear")
    else:
        os.system("cls")
        
def randint(n, m):
    if n < m:
        return random.randint(n, m)
    else:
        return "ERROR: Invalid random number"

def randchoice(lista):
    return random.choice(lista)

def save(nombre_archivo, contenido):
    """Save content by opening a window to choose the folder."""
    root = Tk()
    root.withdraw() 
    root.attributes("-topmost", True) 

    print("Select where you want to save...")
    carpeta = filedialog.askdirectory(title="Select the save folder")
    
    root.destroy()

    if not carpeta:
        return "Saved and cancelled by the user."

    ruta = os.path.join(carpeta, f"{nombre_archivo}.txt")
    
    with open(ruta, "a", encoding="utf-8") as f:
        f.write(contenido + "\n")
    
    return f"Saved in: {ruta}"

def lib():
    import os
    import random
    import math
    import time
    import tkinter
    import pygame
