import gerbolyze
gerbolyze.cli()
