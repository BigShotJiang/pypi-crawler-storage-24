# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CommonResponseErrorAvailableConfig:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'code': 'str',
        'detail': 'AvailableConfig',
        'reason': 'str'
    }

    attribute_map = {
        'code': 'code',
        'detail': 'detail',
        'reason': 'reason'
    }

    def __init__(self, code=None, detail=None, reason=None):
        r"""CommonResponseErrorAvailableConfig

        The model defined in huaweicloud sdk

        :param code: 错误码
        :type code: str
        :param detail: 
        :type detail: :class:`huaweicloudsdkcloudtest.v1.AvailableConfig`
        :param reason: 错误原因
        :type reason: str
        """
        
        

        self._code = None
        self._detail = None
        self._reason = None
        self.discriminator = None

        if code is not None:
            self.code = code
        if detail is not None:
            self.detail = detail
        if reason is not None:
            self.reason = reason

    @property
    def code(self):
        r"""Gets the code of this CommonResponseErrorAvailableConfig.

        错误码

        :return: The code of this CommonResponseErrorAvailableConfig.
        :rtype: str
        """
        return self._code

    @code.setter
    def code(self, code):
        r"""Sets the code of this CommonResponseErrorAvailableConfig.

        错误码

        :param code: The code of this CommonResponseErrorAvailableConfig.
        :type code: str
        """
        self._code = code

    @property
    def detail(self):
        r"""Gets the detail of this CommonResponseErrorAvailableConfig.

        :return: The detail of this CommonResponseErrorAvailableConfig.
        :rtype: :class:`huaweicloudsdkcloudtest.v1.AvailableConfig`
        """
        return self._detail

    @detail.setter
    def detail(self, detail):
        r"""Sets the detail of this CommonResponseErrorAvailableConfig.

        :param detail: The detail of this CommonResponseErrorAvailableConfig.
        :type detail: :class:`huaweicloudsdkcloudtest.v1.AvailableConfig`
        """
        self._detail = detail

    @property
    def reason(self):
        r"""Gets the reason of this CommonResponseErrorAvailableConfig.

        错误原因

        :return: The reason of this CommonResponseErrorAvailableConfig.
        :rtype: str
        """
        return self._reason

    @reason.setter
    def reason(self, reason):
        r"""Sets the reason of this CommonResponseErrorAvailableConfig.

        错误原因

        :param reason: The reason of this CommonResponseErrorAvailableConfig.
        :type reason: str
        """
        self._reason = reason

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CommonResponseErrorAvailableConfig):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
