"""Behavioral provenance — the behavioral story behind every governance decision.

Every GovernanceVerdict in the Behavioral Control Plane carries a
BehavioralProvenance: a snapshot of the agent's complete behavioral state
at the exact moment the decision was made. This makes every verdict
explainable in behavioral terms.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

__all__ = [
    "BehavioralProvenance",
    "build_provenance",
]


@dataclass(frozen=True)
class BehavioralProvenance:
    """Complete behavioral state at the moment of a governance decision."""

    # Fingerprint snapshot
    fingerprint_confidence: float = 0.0  # 0.0-1.0, from BehavioralFingerprint.confidence
    total_observations: int = 0
    action_distribution_top3: tuple = ()  # Tuple of (action_type, fraction) for top 3
    target_distribution_top3: tuple = ()  # Tuple of (target, fraction) for top 3

    # Drift state (classified by distribution)
    drift_overall: float = 0.0
    drift_severity: str = "none"
    drift_by_distribution: dict[str, float] = field(default_factory=dict)
    # Expected keys: "action", "target", "temporal", "outcome", "semantic"
    primary_drift_distribution: str = ""  # Which distribution is drifting most

    # Semantic state
    semantic_drift_overall: float = 0.0
    semantic_most_drifted_term: str = ""
    semantic_detail: str = ""

    # Contract compliance
    contract_id: str = ""  # Empty string = no contract
    contract_version: int = 0  # 0 = no contract
    invariants_satisfied: int = 0
    invariants_violated: int = 0
    invariants_approaching: int = 0  # Within 80% of threshold

    # Trust trajectory
    trust_score: float = 0.5
    trust_direction: str = "stable"  # "rising", "falling", "stable"
    trust_velocity: float = 0.0  # Rate of change per observation

    # Behavioral signals that influenced this verdict
    behavioral_influences: tuple = ()  # Tuple of strings

    # Cost-theoretic context
    cost_profile_active: bool = False
    cost_false_allow: float = 0.0
    cost_false_deny: float = 0.0
    cost_zone_multiplier: float = 1.0
    derived_allow_threshold: float = 0.7
    derived_deny_threshold: float = 0.3
    threshold_source: str = "static_default"  # "static_default", "cost_profile", "smoothed"
    threshold_shift_from_default: float = 0.0  # How far the derived threshold is from the static default

    def to_dict(self) -> dict[str, Any]:
        """Full JSON serialization. Convert tuples to lists for JSON."""
        return {
            "fingerprint_confidence": round(self.fingerprint_confidence, 4),
            "total_observations": self.total_observations,
            "action_distribution_top3": [list(x) for x in self.action_distribution_top3],
            "target_distribution_top3": [list(x) for x in self.target_distribution_top3],
            "drift_overall": round(self.drift_overall, 4),
            "drift_severity": self.drift_severity,
            "drift_by_distribution": {k: round(v, 4) for k, v in self.drift_by_distribution.items()},
            "primary_drift_distribution": self.primary_drift_distribution,
            "semantic_drift_overall": round(self.semantic_drift_overall, 4),
            "semantic_most_drifted_term": self.semantic_most_drifted_term,
            "semantic_detail": self.semantic_detail,
            "contract_id": self.contract_id,
            "contract_version": self.contract_version,
            "invariants_satisfied": self.invariants_satisfied,
            "invariants_violated": self.invariants_violated,
            "invariants_approaching": self.invariants_approaching,
            "trust_score": round(self.trust_score, 4),
            "trust_direction": self.trust_direction,
            "trust_velocity": round(self.trust_velocity, 4),
            "behavioral_influences": list(self.behavioral_influences),
            "cost_profile_active": self.cost_profile_active,
            "cost_false_allow": round(self.cost_false_allow, 4),
            "cost_false_deny": round(self.cost_false_deny, 4),
            "cost_zone_multiplier": round(self.cost_zone_multiplier, 4),
            "derived_allow_threshold": round(self.derived_allow_threshold, 4),
            "derived_deny_threshold": round(self.derived_deny_threshold, 4),
            "threshold_source": self.threshold_source,
            "threshold_shift_from_default": round(self.threshold_shift_from_default, 4),
        }

    def summary(self) -> str:
        """One-line behavioral summary for audit display.

        Format: "FP: {confidence}% ({observations} obs) | Drift: {severity}
        ({primary_distribution} {value}) | Contract: {status} | Trust: {score}
        ({direction})"
        """
        # Fingerprint
        fp_pct = int(self.fingerprint_confidence * 100)
        fp_part = f"FP: {fp_pct}% ({self.total_observations} obs)"

        # Drift
        if self.drift_severity == "none" or self.drift_overall == 0.0:
            drift_part = "Drift: none"
        else:
            if self.primary_drift_distribution:
                primary_val = self.drift_by_distribution.get(
                    self.primary_drift_distribution, self.drift_overall
                )
                drift_part = (
                    f"Drift: {self.drift_severity} "
                    f"({self.primary_drift_distribution} {primary_val:.2f})"
                )
            else:
                drift_part = f"Drift: {self.drift_severity} ({self.drift_overall:.2f})"

        # Contract
        if not self.contract_id:
            contract_part = "No contract"
        elif self.invariants_violated > 0:
            contract_part = (
                f"Contract v{self.contract_version}: "
                f"{self.invariants_violated} violation"
                f"{'s' if self.invariants_violated != 1 else ''}"
            )
        else:
            contract_part = f"Contract v{self.contract_version}: compliant"

        # Trust
        trust_part = f"Trust: {self.trust_score:.2f} ({self.trust_direction})"

        # Cost profile
        if self.cost_profile_active:
            cost_part = (
                f" | CostProfile: C_FN={self.cost_false_allow:.2f}"
                f" C_FP={self.cost_false_deny:.2f}"
                f" | Thresholds: allow={self.derived_allow_threshold:.3f}"
                f" deny={self.derived_deny_threshold:.3f}"
                f" ({self.threshold_source})"
            )
        else:
            cost_part = ""

        return f"{fp_part} | {drift_part} | {contract_part} | {trust_part}{cost_part}"


def _top3(distribution: dict[str, float]) -> tuple:
    """Extract top 3 entries from a distribution by value, descending.

    Returns tuple of (key, value) tuples.
    """
    sorted_items = sorted(distribution.items(), key=lambda x: x[1], reverse=True)[:3]
    return tuple((k, round(v, 4)) for k, v in sorted_items)


def _compute_trust_direction(
    trust_calibrator: Any, agent_id: str
) -> tuple[str, float]:
    """Determine trust trajectory direction and velocity."""
    if trust_calibrator is None:
        return ("stable", 0.0)

    trajectory = trust_calibrator.get_trajectory(agent_id)
    events = trajectory.events
    if not events:
        return ("stable", 0.0)

    # Use the trajectory's trend property for direction
    trend = trajectory.trend
    if trend == "volatile":
        trend = "stable"  # Normalize volatile → stable for provenance

    # Compute velocity from recent deltas
    recent = events[-10:]
    velocity = sum(e.delta for e in recent) / len(recent) if recent else 0.0

    # Derive direction from velocity if trajectory has no trend yet
    if trend == "stable" and abs(velocity) > 0.001:
        trend = "rising" if velocity > 0 else "falling"

    return (trend, velocity)


def _build_behavioral_influences(
    drift: Any,  # DriftScore | None
    semantic_drift: Any,  # SemanticDriftScore | None
    contract_violations: dict | None,
    trust_direction: str,
) -> tuple:
    """Assemble the list of behavioral signals that influenced the verdict."""
    influences: list[str] = []

    if drift is not None and drift.severity != "none":
        # Find highest-drift distribution
        dist_map = {
            "action": drift.action_drift,
            "target": drift.target_drift,
            "temporal": drift.temporal_drift,
            "outcome": drift.outcome_drift,
        }
        if drift.semantic_drift:
            dist_map["semantic"] = drift.semantic_drift
        if dist_map:
            max_dist = max(dist_map, key=dist_map.get)  # type: ignore[arg-type]
            max_val = dist_map[max_dist]
            influences.append(
                f"{drift.severity} {max_dist} drift ({max_val:.2f}) "
                f"affecting behavioral consistency"
            )

    if semantic_drift is not None and semantic_drift.overall > 0.10:
        influences.append(
            f"semantic drift on '{semantic_drift.most_drifted_term}' "
            f"({semantic_drift.overall:.2f})"
        )

    if contract_violations:
        for dist, info in contract_violations.items():
            current = info.get("current", 0.0)
            threshold = info.get("threshold", 0.0)
            influences.append(
                f"contract threshold exceeded: {dist} drift "
                f"{current:.2f} > {threshold:.2f}"
            )

    if trust_direction == "falling":
        influences.append("declining trust trajectory")

    return tuple(influences)


def _count_contract_invariants(
    contract: Any, drift: Any
) -> tuple[int, int, int]:
    """Count satisfied, violated, and approaching-threshold invariants.

    Returns (satisfied, violated, approaching).
    """
    if contract is None or drift is None:
        return (0, 0, 0)

    satisfied = 0
    violated = 0
    approaching = 0

    thresholds = getattr(contract, "drift_thresholds", {}) or {}
    for dist_name, threshold in thresholds.items():
        current = getattr(drift, f"{dist_name}_drift", 0.0)
        if current > threshold:
            violated += 1
        elif current > threshold * 0.8:
            approaching += 1
        else:
            satisfied += 1

    return (satisfied, violated, approaching)


def build_provenance(
    agent_id: str,
    fingerprint_observer: Any,  # FingerprintObserver
    contract_store: Any = None,  # ContractStore | None
    trust_calibrator: Any = None,  # TrustCalibrator | None
    contract_threshold_violations: dict | None = None,
    derived_thresholds: Any = None,  # DerivedThresholds | None
) -> BehavioralProvenance:
    """Assemble provenance from current system state.

    This runs inside _record_verdict() after all drift computation is complete.
    It reads already-computed data — it does NOT trigger new computation.
    """
    # 1. Get fingerprint
    fp = fingerprint_observer.get_fingerprint(agent_id)
    if fp is None:
        return BehavioralProvenance()

    # 2. Get drift
    drift = fingerprint_observer.get_drift(agent_id)

    # 3. Get semantic drift
    sem_drift = fingerprint_observer.get_semantic_drift(agent_id)

    # 4. Get contract
    contract = contract_store.get_active(agent_id) if contract_store else None

    # 5. Compute trust direction
    direction, velocity = _compute_trust_direction(trust_calibrator, agent_id)

    # 6. Get trust score
    trust_score = 0.5
    if trust_calibrator is not None:
        profile = trust_calibrator.get_profile(agent_id)
        trust_score = profile.overall_trust

    # 7. Build drift_by_distribution
    drift_by_distribution: dict[str, float] = {}
    if drift is not None:
        drift_by_distribution = {
            "action": drift.action_drift,
            "target": drift.target_drift,
            "temporal": drift.temporal_drift,
            "outcome": drift.outcome_drift,
            "semantic": drift.semantic_drift,
        }

    # 8. Primary drift distribution
    primary_drift_distribution = ""
    if drift_by_distribution:
        primary_drift_distribution = max(
            drift_by_distribution, key=drift_by_distribution.get  # type: ignore[arg-type]
        )

    # 9. Build behavioral influences
    behavioral_influences = _build_behavioral_influences(
        drift, sem_drift, contract_threshold_violations, direction
    )

    # 10. Contract invariant counts
    inv_satisfied, inv_violated, inv_approaching = _count_contract_invariants(
        contract, drift
    )

    # 11. Cost-theoretic context from DerivedThresholds
    cost_profile_active = False
    cost_false_allow = 0.0
    cost_false_deny = 0.0
    cost_zone_multiplier = 1.0
    derived_allow_threshold = 0.7
    derived_deny_threshold = 0.3
    threshold_source = "static_default"
    threshold_shift_from_default = 0.0

    if derived_thresholds is not None:
        derived_allow_threshold = derived_thresholds.allow_threshold
        derived_deny_threshold = derived_thresholds.deny_threshold
        threshold_source = derived_thresholds.source
        cps = derived_thresholds.cost_profile_summary or {}
        if cps:
            cost_profile_active = True
            cost_false_allow = cps.get("false_allow", 0.0)
            cost_false_deny = cps.get("false_deny", 0.0)
            cost_zone_multiplier = cps.get("zone_multiplier", 1.0)
        threshold_shift_from_default = abs(derived_allow_threshold - 0.7)

    # 12. Assemble provenance
    return BehavioralProvenance(
        fingerprint_confidence=fp.confidence,
        total_observations=fp.total_observations,
        action_distribution_top3=_top3(fp.action_distribution),
        target_distribution_top3=_top3(fp.target_distribution),
        drift_overall=drift.overall if drift else 0.0,
        drift_severity=drift.severity if drift else "none",
        drift_by_distribution=drift_by_distribution,
        primary_drift_distribution=primary_drift_distribution,
        semantic_drift_overall=sem_drift.overall if sem_drift else 0.0,
        semantic_most_drifted_term=(
            sem_drift.most_drifted_term if sem_drift else ""
        ),
        semantic_detail=sem_drift.detail if sem_drift else "",
        contract_id=contract.contract_id if contract else "",
        contract_version=contract.version if contract else 0,
        invariants_satisfied=inv_satisfied,
        invariants_violated=inv_violated,
        invariants_approaching=inv_approaching,
        trust_score=trust_score,
        trust_direction=direction,
        trust_velocity=velocity,
        behavioral_influences=behavioral_influences,
        cost_profile_active=cost_profile_active,
        cost_false_allow=cost_false_allow,
        cost_false_deny=cost_false_deny,
        cost_zone_multiplier=cost_zone_multiplier,
        derived_allow_threshold=derived_allow_threshold,
        derived_deny_threshold=derived_deny_threshold,
        threshold_source=threshold_source,
        threshold_shift_from_default=threshold_shift_from_default,
    )
