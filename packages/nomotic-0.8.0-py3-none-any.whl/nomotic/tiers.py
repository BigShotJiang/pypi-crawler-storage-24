"""Three-tier hybrid evaluation architecture.

Tier 1: Deterministic Gate
    Fast, rule-based checks. Hard boundaries. Vetoes are final.
    Runs in microseconds. No ambiguity — pass or fail.

Tier 2: Weighted Evaluation
    The UCS engine combines dimension scores using weights, trust
    calibration, and contextual factors. Produces a confidence score.
    Most actions are decided here.

Tier 3: Deliberative Review
    For edge cases where Tier 2 produces ambiguous results. Applies
    deeper analysis, historical comparison, and if necessary, escalates
    to human review. Slowest but most thorough.

The tier system is a cascade: Tier 1 filters obvious cases, Tier 2 handles
the bulk, and Tier 3 catches what falls through the cracks.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Callable

from nomotic.types import (
    Action,
    AgentContext,
    DimensionScore,
    GovernanceVerdict,
    Verdict,
)

if TYPE_CHECKING:
    from nomotic.escalation import EscalationManager
    from nomotic.voi import VOIEngine

__all__ = [
    "TierOneGate",
    "TierResult",
    "TierThreeDeliberator",
    "TierTwoEvaluator",
]


@dataclass
class TierResult:
    """Result from a single tier's evaluation."""

    decided: bool  # Did this tier make a final decision?
    verdict: GovernanceVerdict | None = None


class TierOneGate:
    """Tier 1: Deterministic Gate.

    Checks hard boundaries. Any veto from a dimension with veto authority
    results in immediate DENY. No scoring, no weighing — just binary checks.

    This tier handles:
    - Scope violations (action outside agent's permissions)
    - Authority failures (agent lacks specific authority)
    - Resource limit breaches (rate/concurrency/cost exceeded)
    - Isolation boundary violations
    - Temporal constraint violations
    - Ethical hard constraints
    - Human override requirements
    """

    def evaluate(
        self, action: Action, context: AgentContext, scores: list[DimensionScore]
    ) -> TierResult:
        vetoes = [s for s in scores if s.veto]
        if vetoes:
            # Any veto with score 0.0 on a human_override dimension means ESCALATE
            human_vetoes = [v for v in vetoes if v.dimension_name == "human_override"]
            if human_vetoes and not any(
                v.dimension_name != "human_override" for v in vetoes
            ):
                return TierResult(
                    decided=True,
                    verdict=GovernanceVerdict(
                        action_id=action.id,
                        verdict=Verdict.ESCALATE,
                        ucs=0.0,
                        dimension_scores=scores,
                        tier=1,
                        vetoed_by=[v.dimension_name for v in vetoes],
                        reasoning="Human approval required",
                    ),
                )
            return TierResult(
                decided=True,
                verdict=GovernanceVerdict(
                    action_id=action.id,
                    verdict=Verdict.DENY,
                    ucs=0.0,
                    dimension_scores=scores,
                    tier=1,
                    vetoed_by=[v.dimension_name for v in vetoes],
                    reasoning="; ".join(v.reasoning for v in vetoes),
                ),
            )
        return TierResult(decided=False)


class TierTwoEvaluator:
    """Tier 2: Weighted Evaluation via UCS.

    Combines dimension scores into a Unified Confidence Score. Uses
    configurable thresholds to decide ALLOW, DENY, or pass to Tier 3.

    The ambiguity zone between allow_threshold and deny_threshold is
    where Tier 3 takes over.
    """

    def __init__(
        self,
        allow_threshold: float = 0.7,
        deny_threshold: float = 0.3,
    ):
        self.allow_threshold = allow_threshold
        self.deny_threshold = deny_threshold

    def evaluate(
        self,
        action: Action,
        context: AgentContext,
        scores: list[DimensionScore],
        ucs: float,
        dynamic_allow: float | None = None,
        dynamic_deny: float | None = None,
    ) -> TierResult:
        allow_t = dynamic_allow if dynamic_allow is not None else self.allow_threshold
        deny_t = dynamic_deny if dynamic_deny is not None else self.deny_threshold

        if dynamic_allow is not None or dynamic_deny is not None:
            source = "cost-derived"
        else:
            source = "static"

        if ucs >= allow_t:
            return TierResult(
                decided=True,
                verdict=GovernanceVerdict(
                    action_id=action.id,
                    verdict=Verdict.ALLOW,
                    ucs=ucs,
                    dimension_scores=scores,
                    tier=2,
                    reasoning=f"UCS {ucs:.3f} >= {source} allow threshold {allow_t:.3f}",
                ),
            )
        if ucs <= deny_t:
            return TierResult(
                decided=True,
                verdict=GovernanceVerdict(
                    action_id=action.id,
                    verdict=Verdict.DENY,
                    ucs=ucs,
                    dimension_scores=scores,
                    tier=2,
                    reasoning=f"UCS {ucs:.3f} <= {source} deny threshold {deny_t:.3f}",
                ),
            )
        # Ambiguous — pass to Tier 3
        return TierResult(decided=False)


class TierThreeDeliberator:
    """Tier 3: Deliberative Review.

    Handles ambiguous cases that Tier 2 couldn't decide. Applies deeper
    analysis including:
    - Historical comparison with similar actions
    - Trust trajectory analysis (is trust trending up or down?)
    - Worst-case impact assessment
    - Optional escalation to human review

    If all else fails, defaults to the safer option (DENY or MODIFY).
    """

    def __init__(
        self,
        voi_engine: VOIEngine | None = None,
        cost_profile_accessor: Callable[..., Any] | None = None,
        reviewer_drift_accessor: Callable[..., Any] | None = None,
        escalation_manager: EscalationManager | None = None,
        escalation_path_accessor: Callable[..., Any] | None = None,
    ) -> None:
        self._deliberators: list[
            Callable[[Action, AgentContext, list[DimensionScore], float], Verdict | None]
        ] = []
        self._voi_engine = voi_engine
        self._cost_profile_accessor = cost_profile_accessor
        self._reviewer_drift_accessor = reviewer_drift_accessor
        self._escalation_manager = escalation_manager
        self._escalation_path_accessor = escalation_path_accessor

    def add_deliberator(
        self,
        func: Callable[
            [Action, AgentContext, list[DimensionScore], float], Verdict | None
        ],
    ) -> None:
        """Add a custom deliberation function."""
        self._deliberators.append(func)

    def evaluate(
        self,
        action: Action,
        context: AgentContext,
        scores: list[DimensionScore],
        ucs: float,
        tracer: Any = None,
    ) -> TierResult:
        # Run custom deliberators
        for deliberator in self._deliberators:
            result = deliberator(action, context, scores, ucs)
            if result is not None:
                return TierResult(
                    decided=True,
                    verdict=GovernanceVerdict(
                        action_id=action.id,
                        verdict=result,
                        ucs=ucs,
                        dimension_scores=scores,
                        tier=3,
                        reasoning="Custom deliberator decided",
                    ),
                )

        # VOI-driven escalation (when enabled)
        if self._voi_engine is not None:
            cost_profile = None
            if self._cost_profile_accessor:
                cost_profile = self._cost_profile_accessor(context.agent_id)
            reviewer_drift = None
            if self._reviewer_drift_accessor:
                reviewer_drift = self._reviewer_drift_accessor()

            voi_result = self._voi_engine.compute(
                scores=scores,
                trust_profile=context.trust_profile,
                cost_profile=cost_profile,
                reviewer_drift=reviewer_drift,
                ucs=ucs,
            )

            # Record VOI computation in tracer
            if tracer:
                tracer.record(
                    "voi_computation",
                    f"VOI={voi_result.voi_score:.3f}, cost={voi_result.escalation_cost:.3f}, escalate={voi_result.should_escalate}",
                    input_state={
                        "dimension_entropy": voi_result.dimension_entropy,
                        "trust_uncertainty": voi_result.trust_uncertainty,
                        "cost_sensitivity": voi_result.cost_sensitivity,
                    },
                    output_state={
                        "voi_score": voi_result.voi_score,
                        "should_escalate": voi_result.should_escalate,
                        "shift_probability": voi_result.expected_verdict_shift_probability,
                    },
                )

            def _make_verdict(verdict_type: Verdict, reasoning: str) -> TierResult:
                v = GovernanceVerdict(
                    action_id=action.id,
                    verdict=verdict_type,
                    ucs=ucs,
                    dimension_scores=scores,
                    tier=3,
                    reasoning=reasoning,
                    metadata={"voi_result": voi_result.to_dict()},
                )
                return TierResult(decided=True, verdict=v)

            # Safety floor: trust below floor always escalates
            if context.trust_profile.overall_trust < self._voi_engine.config.trust_floor:
                return _make_verdict(
                    Verdict.ESCALATE,
                    f"Trust {context.trust_profile.overall_trust:.2f} below safety floor. "
                    f"VOI={voi_result.voi_score:.3f}",
                )

            if voi_result.should_escalate:
                # Try tiered escalation before falling back to ESCALATE.
                if self._escalation_manager is not None:
                    from nomotic.escalation import EscalationPath

                    esc_path = None
                    if self._escalation_path_accessor:
                        esc_path = self._escalation_path_accessor(context.agent_id)

                    esc_result = self._escalation_manager.resolve(
                        action=action,
                        context=context,
                        scores=scores,
                        ucs=ucs,
                        voi_result=voi_result,
                        cost_profile=cost_profile,
                        escalation_path=esc_path,
                    )

                    if tracer:
                        tracer.record(
                            "escalation_path",
                            f"steps={esc_result.steps_attempted}, resolved={esc_result.resolved}, "
                            f"at={esc_result.resolved_at_step}, verdict={esc_result.final_verdict}",
                            input_state={"voi_score": voi_result.voi_score},
                            output_state=esc_result.to_dict(),
                        )

                    if esc_result.resolved:
                        verdict_str = esc_result.final_verdict.upper()
                        verdict_type = Verdict[verdict_str]
                        reasoning = (
                            f"Tiered escalation resolved at '{esc_result.resolved_at_step}': "
                            f"{esc_result.detail}. "
                            f"Steps attempted: {', '.join(esc_result.steps_attempted)}. "
                            f"VOI={voi_result.voi_score:.3f}"
                        )
                        v = GovernanceVerdict(
                            action_id=action.id,
                            verdict=verdict_type,
                            ucs=ucs,
                            dimension_scores=scores,
                            tier=3,
                            reasoning=reasoning,
                            metadata={
                                "voi_result": voi_result.to_dict(),
                                "escalation_result": esc_result.to_dict(),
                            },
                        )
                        return TierResult(decided=True, verdict=v)

                    # Escalation path didn't resolve — use fallback verdict.
                    fallback_str = esc_result.final_verdict.upper()
                    fallback_type = Verdict[fallback_str]
                    reasoning = (
                        f"Tiered escalation exhausted without resolution. "
                        f"Fallback={fallback_str}. Steps: {', '.join(esc_result.steps_attempted)}. "
                        f"VOI={voi_result.voi_score:.3f}. {esc_result.detail}"
                    )
                    v = GovernanceVerdict(
                        action_id=action.id,
                        verdict=fallback_type,
                        ucs=ucs,
                        dimension_scores=scores,
                        tier=3,
                        reasoning=reasoning,
                        metadata={
                            "voi_result": voi_result.to_dict(),
                            "escalation_result": esc_result.to_dict(),
                        },
                    )
                    return TierResult(decided=True, verdict=v)

                # No escalation manager — fall back to direct ESCALATE.
                return _make_verdict(
                    Verdict.ESCALATE,
                    f"VOI escalation: VOI={voi_result.voi_score:.3f} > cost={voi_result.escalation_cost:.3f}. "
                    f"Shift probability: {voi_result.expected_verdict_shift_probability:.0%}. "
                    f"Disagreement: {', '.join(voi_result.dominant_disagreement)}",
                )

            # VOI says don't escalate — make best decision based on UCS and cost profile
            if ucs > 0.5:
                return _make_verdict(
                    Verdict.ALLOW,
                    f"VOI-informed allow: VOI too low to justify escalation ({voi_result.voi_score:.3f}). "
                    f"UCS {ucs:.3f} leans allow.",
                )
            else:
                # Lean DENY for high-stakes, ALLOW for low-stakes
                if cost_profile and cost_profile.false_allow_cost >= 0.6:
                    return _make_verdict(
                        Verdict.DENY,
                        f"VOI-informed deny: high false-allow cost ({cost_profile.false_allow_label}), "
                        f"UCS {ucs:.3f} leans deny.",
                    )
                else:
                    return _make_verdict(
                        Verdict.ALLOW,
                        f"VOI-informed allow: low stakes, UCS {ucs:.3f}. "
                        f"VOI={voi_result.voi_score:.3f}.",
                    )

        # Fallback: existing trust-based logic (when VOI not enabled)
        trust = context.trust_profile.overall_trust

        # High trust + borderline UCS = allow with modification
        if trust > 0.7 and ucs > 0.5:
            return TierResult(
                decided=True,
                verdict=GovernanceVerdict(
                    action_id=action.id,
                    verdict=Verdict.ALLOW,
                    ucs=ucs,
                    dimension_scores=scores,
                    tier=3,
                    reasoning=f"High trust ({trust:.2f}) tips borderline UCS ({ucs:.3f}) to allow",
                ),
            )

        # Low trust + borderline UCS = escalate
        if trust < 0.4:
            return TierResult(
                decided=True,
                verdict=GovernanceVerdict(
                    action_id=action.id,
                    verdict=Verdict.ESCALATE,
                    ucs=ucs,
                    dimension_scores=scores,
                    tier=3,
                    reasoning=f"Low trust ({trust:.2f}) + ambiguous UCS ({ucs:.3f}) requires escalation",
                ),
            )

        # Check for any low-scoring critical dimensions
        critical_low = [
            s
            for s in scores
            if s.weight >= 1.3 and s.score < 0.4
        ]
        if critical_low:
            return TierResult(
                decided=True,
                verdict=GovernanceVerdict(
                    action_id=action.id,
                    verdict=Verdict.MODIFY,
                    ucs=ucs,
                    dimension_scores=scores,
                    tier=3,
                    reasoning=f"Critical dimensions scored low: {[s.dimension_name for s in critical_low]}",
                    modifications={"reduce_scope": True, "require_confirmation": True},
                ),
            )

        # Default: allow with reduced confidence
        return TierResult(
            decided=True,
            verdict=GovernanceVerdict(
                action_id=action.id,
                verdict=Verdict.ALLOW,
                ucs=ucs,
                dimension_scores=scores,
                tier=3,
                reasoning=f"Tier 3 default: allow with UCS {ucs:.3f}",
            ),
        )
