"""BehaviorLedger — complete decision reconstruction for every governance verdict.

The BehaviorLedger assembles a self-contained record of every governance
decision at write time. Each entry captures not just the verdict but the
full pipeline trace, behavioral state, contract snapshot, semantic context,
and causal links to previous decisions.

The difference between an audit trail and a behavior ledger: the audit
trail logs what happened. The ledger reconstructs why it happened, what
influenced it, and what would need to change for a different outcome.
"""

from __future__ import annotations

import hashlib
import json
import threading
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

__all__ = [
    "ActionToPass",
    "BehaviorLedgerEntry",
    "BehaviorLedgerExporter",
    "BehaviorLedgerStore",
    "CausalLink",
    "ContractSnapshot",
    "PipelineStep",
    "PipelineTracer",
    "SemanticContext",
    "build_ledger_entry",
]


# ── Pipeline trace ──────────────────────────────────────────────────


@dataclass(frozen=True)
class PipelineStep:
    """One decision point in the governance evaluation pipeline."""

    step_id: str
    description: str
    timestamp_offset_ms: float

    # Input state
    input_state: dict[str, Any] = field(default_factory=dict)
    # Output state
    output_state: dict[str, Any] = field(default_factory=dict)

    # Decision made at this step
    decision: str = ""
    decided_verdict: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "step_id": self.step_id,
            "description": self.description,
            "timestamp_offset_ms": self.timestamp_offset_ms,
            "input_state": dict(self.input_state),
            "output_state": dict(self.output_state),
            "decision": self.decision,
            "decided_verdict": self.decided_verdict,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PipelineStep:
        return cls(
            step_id=data.get("step_id", ""),
            description=data.get("description", ""),
            timestamp_offset_ms=data.get("timestamp_offset_ms", 0.0),
            input_state=data.get("input_state", {}),
            output_state=data.get("output_state", {}),
            decision=data.get("decision", ""),
            decided_verdict=data.get("decided_verdict", False),
        )


class PipelineTracer:
    """Collects pipeline decision points during a single evaluate() call.

    Created at the start of evaluate(), passed through each step,
    and finalized when the verdict is produced. Zero-overhead when
    ledger is disabled (tracer is None and all trace points are guarded).
    """

    def __init__(self) -> None:
        self._steps: list[PipelineStep] = []
        self._start_time: float = time.time()

    def record(
        self,
        step_id: str,
        description: str,
        input_state: dict[str, Any],
        output_state: dict[str, Any],
        decision: str = "",
        decided: bool = False,
    ) -> None:
        """Record one pipeline step."""
        offset = (time.time() - self._start_time) * 1000
        self._steps.append(
            PipelineStep(
                step_id=step_id,
                description=description,
                timestamp_offset_ms=round(offset, 3),
                input_state=input_state,
                output_state=output_state,
                decision=decision,
                decided_verdict=decided,
            )
        )

    def finalize(self) -> tuple[PipelineStep, ...]:
        """Return the collected steps as a tuple (for frozen dataclass)."""
        return tuple(self._steps)


# ── Contract snapshot ───────────────────────────────────────────────


@dataclass(frozen=True)
class ContractSnapshot:
    """Contract state at the moment of decision.

    Embedded in the ledger entry so the decision can be reconstructed
    even if the contract is later updated or revoked.
    """

    contract_id: str = ""
    version: int = 0
    archetype: str = ""
    drift_thresholds: dict[str, float] = field(default_factory=dict)
    invariant_count: int = 0
    invariant_specs_summary: tuple[tuple[str, ...], ...] = ()
    semantic_anchor_terms: tuple[str, ...] = ()
    cost_profile_summary: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "contract_id": self.contract_id,
            "version": self.version,
            "archetype": self.archetype,
            "drift_thresholds": dict(self.drift_thresholds),
            "invariant_count": self.invariant_count,
            "invariant_specs_summary": [list(s) for s in self.invariant_specs_summary],
            "semantic_anchor_terms": list(self.semantic_anchor_terms),
            "cost_profile_summary": dict(self.cost_profile_summary),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ContractSnapshot:
        return cls(
            contract_id=data.get("contract_id", ""),
            version=data.get("version", 0),
            archetype=data.get("archetype", ""),
            drift_thresholds=data.get("drift_thresholds", {}),
            invariant_count=data.get("invariant_count", 0),
            invariant_specs_summary=tuple(
                tuple(s) for s in data.get("invariant_specs_summary", [])
            ),
            semantic_anchor_terms=tuple(data.get("semantic_anchor_terms", [])),
            cost_profile_summary=data.get("cost_profile_summary", {}),
        )


# ── Semantic context ────────────────────────────────────────────────


@dataclass(frozen=True)
class SemanticContext:
    """Semantic state at the moment of decision."""

    instruction_context: str = ""
    matched_anchor_terms: tuple[str, ...] = ()
    per_term_drift: dict[str, float] = field(default_factory=dict)
    aggregate_semantic_drift: float = 0.0
    most_drifted_term: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "instruction_context": self.instruction_context,
            "matched_anchor_terms": list(self.matched_anchor_terms),
            "per_term_drift": {k: round(v, 4) for k, v in self.per_term_drift.items()},
            "aggregate_semantic_drift": round(self.aggregate_semantic_drift, 4),
            "most_drifted_term": self.most_drifted_term,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SemanticContext:
        return cls(
            instruction_context=data.get("instruction_context", ""),
            matched_anchor_terms=tuple(data.get("matched_anchor_terms", [])),
            per_term_drift=data.get("per_term_drift", {}),
            aggregate_semantic_drift=data.get("aggregate_semantic_drift", 0.0),
            most_drifted_term=data.get("most_drifted_term", ""),
        )


# ── Causal link ─────────────────────────────────────────────────────


@dataclass(frozen=True)
class CausalLink:
    """Link to a previous decision that causally influenced this one."""

    previous_entry_id: str
    influence_type: str
    influence_description: str
    trust_delta: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        return {
            "previous_entry_id": self.previous_entry_id,
            "influence_type": self.influence_type,
            "influence_description": self.influence_description,
            "trust_delta": round(self.trust_delta, 4),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CausalLink:
        return cls(
            previous_entry_id=data.get("previous_entry_id", ""),
            influence_type=data.get("influence_type", ""),
            influence_description=data.get("influence_description", ""),
            trust_delta=data.get("trust_delta", 0.0),
        )


# ── Action to pass ──────────────────────────────────────────────────


@dataclass(frozen=True)
class ActionToPass:
    """What would need to change for a different verdict.

    For DENY verdicts: what would make this ALLOW.
    For ALLOW verdicts: how close was this to DENY.
    """

    current_verdict: str

    # For DENY: which dimensions would need to improve and by how much
    dimension_gaps: dict[str, float] = field(default_factory=dict)

    # For DENY: what UCS would be needed
    ucs_needed: float = 0.0
    ucs_gap: float = 0.0

    # For ALLOW: how close to denial (margin of safety)
    margin_to_deny: float = 0.0
    closest_veto_dimension: str = ""
    closest_veto_margin: float = 0.0

    # Invariant state
    invariants_that_blocked: tuple[str, ...] = ()

    detail: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "current_verdict": self.current_verdict,
            "dimension_gaps": {k: round(v, 4) for k, v in self.dimension_gaps.items()},
            "ucs_needed": round(self.ucs_needed, 4),
            "ucs_gap": round(self.ucs_gap, 4),
            "margin_to_deny": round(self.margin_to_deny, 4),
            "closest_veto_dimension": self.closest_veto_dimension,
            "closest_veto_margin": round(self.closest_veto_margin, 4),
            "invariants_that_blocked": list(self.invariants_that_blocked),
            "detail": self.detail,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ActionToPass:
        return cls(
            current_verdict=data.get("current_verdict", ""),
            dimension_gaps=data.get("dimension_gaps", {}),
            ucs_needed=data.get("ucs_needed", 0.0),
            ucs_gap=data.get("ucs_gap", 0.0),
            margin_to_deny=data.get("margin_to_deny", 0.0),
            closest_veto_dimension=data.get("closest_veto_dimension", ""),
            closest_veto_margin=data.get("closest_veto_margin", 0.0),
            invariants_that_blocked=tuple(data.get("invariants_that_blocked", [])),
            detail=data.get("detail", ""),
        )


# ── BehaviorLedgerEntry ─────────────────────────────────────────────


@dataclass(frozen=True)
class BehaviorLedgerEntry:
    """A complete, self-contained record of a governance decision.

    Contains everything needed to fully reconstruct why a decision was
    made without querying any other system. The verdict, the pipeline
    trace, the behavioral state, the contract, the semantic context,
    the causal history, and what would need to change.
    """

    # Identity
    entry_id: str
    timestamp: float
    sequence_number: int = 0

    # The action
    agent_id: str = ""
    action_type: str = ""
    action_target: str = ""
    action_parameters: dict[str, Any] = field(default_factory=dict)

    # The verdict
    verdict: str = ""
    ucs: float = 0.0
    tier: int = 0
    reasoning: str = ""
    vetoed_by: tuple[str, ...] = ()
    evaluation_time_ms: float = 0.0

    # Dimension scores (full snapshot)
    dimension_scores: tuple[dict[str, Any], ...] = ()

    # Pipeline trace — every decision point
    pipeline_trace: tuple[PipelineStep, ...] = ()

    # Behavioral provenance (embedded, not referenced)
    fingerprint_confidence: float = 0.0
    fingerprint_observations: int = 0
    drift_by_distribution: dict[str, float] = field(default_factory=dict)
    drift_severity: str = "none"
    trust_score: float = 0.5
    trust_direction: str = "stable"
    trust_velocity: float = 0.0

    # Contract snapshot (embedded, not referenced)
    contract: ContractSnapshot | None = None
    invariant_results: tuple[dict[str, Any], ...] = ()

    # Semantic context (embedded)
    semantic: SemanticContext | None = None

    # Causal links to previous decisions
    causal_links: tuple[CausalLink, ...] = ()

    # What would need to change
    action_to_pass: ActionToPass | None = None

    # Reversibility assessment
    reversibility_level: str = ""
    reversibility_forced_tier3: bool = False

    # Cross-dimensional signals
    cross_dimensional_signal_count: int = 0
    cross_dimensional_ucs_adjustment: float = 0.0

    # Contextual modification
    weight_adjustments_applied: dict[str, float] = field(default_factory=dict)
    trust_modifier_applied: float = 0.0

    # Hash chain
    previous_entry_hash: str = ""
    entry_hash: str = ""

    def compute_hash(self) -> str:
        """SHA-256 hash of all fields except entry_hash."""
        data = {k: v for k, v in self.to_dict().items() if k != "entry_hash"}
        canonical = json.dumps(data, sort_keys=True, default=str)
        return hashlib.sha256(
            (self.previous_entry_hash + canonical).encode()
        ).hexdigest()

    def to_dict(self) -> dict[str, Any]:
        """Full JSON serialization. Converts all tuples to lists, frozen dataclasses to dicts."""
        return {
            "entry_id": self.entry_id,
            "timestamp": self.timestamp,
            "sequence_number": self.sequence_number,
            "agent_id": self.agent_id,
            "action_type": self.action_type,
            "action_target": self.action_target,
            "action_parameters": dict(self.action_parameters),
            "verdict": self.verdict,
            "ucs": round(self.ucs, 4),
            "tier": self.tier,
            "reasoning": self.reasoning,
            "vetoed_by": list(self.vetoed_by),
            "evaluation_time_ms": round(self.evaluation_time_ms, 3),
            "dimension_scores": [dict(d) for d in self.dimension_scores],
            "pipeline_trace": [s.to_dict() for s in self.pipeline_trace],
            "fingerprint_confidence": round(self.fingerprint_confidence, 4),
            "fingerprint_observations": self.fingerprint_observations,
            "drift_by_distribution": {
                k: round(v, 4) for k, v in self.drift_by_distribution.items()
            },
            "drift_severity": self.drift_severity,
            "trust_score": round(self.trust_score, 4),
            "trust_direction": self.trust_direction,
            "trust_velocity": round(self.trust_velocity, 4),
            "contract": self.contract.to_dict() if self.contract else None,
            "invariant_results": [dict(r) for r in self.invariant_results],
            "semantic": self.semantic.to_dict() if self.semantic else None,
            "causal_links": [cl.to_dict() for cl in self.causal_links],
            "action_to_pass": self.action_to_pass.to_dict() if self.action_to_pass else None,
            "reversibility_level": self.reversibility_level,
            "reversibility_forced_tier3": self.reversibility_forced_tier3,
            "cross_dimensional_signal_count": self.cross_dimensional_signal_count,
            "cross_dimensional_ucs_adjustment": round(
                self.cross_dimensional_ucs_adjustment, 4
            ),
            "weight_adjustments_applied": {
                k: round(v, 4) for k, v in self.weight_adjustments_applied.items()
            },
            "trust_modifier_applied": round(self.trust_modifier_applied, 4),
            "previous_entry_hash": self.previous_entry_hash,
            "entry_hash": self.entry_hash,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> BehaviorLedgerEntry:
        """Deserialize from dict."""
        pipeline_trace = tuple(
            PipelineStep.from_dict(s) for s in data.get("pipeline_trace", [])
        )
        causal_links = tuple(
            CausalLink.from_dict(cl) for cl in data.get("causal_links", [])
        )
        contract_data = data.get("contract")
        contract = ContractSnapshot.from_dict(contract_data) if contract_data else None
        semantic_data = data.get("semantic")
        semantic = SemanticContext.from_dict(semantic_data) if semantic_data else None
        atp_data = data.get("action_to_pass")
        action_to_pass = ActionToPass.from_dict(atp_data) if atp_data else None

        return cls(
            entry_id=data.get("entry_id", ""),
            timestamp=data.get("timestamp", 0.0),
            sequence_number=data.get("sequence_number", 0),
            agent_id=data.get("agent_id", ""),
            action_type=data.get("action_type", ""),
            action_target=data.get("action_target", ""),
            action_parameters=data.get("action_parameters", {}),
            verdict=data.get("verdict", ""),
            ucs=data.get("ucs", 0.0),
            tier=data.get("tier", 0),
            reasoning=data.get("reasoning", ""),
            vetoed_by=tuple(data.get("vetoed_by", [])),
            evaluation_time_ms=data.get("evaluation_time_ms", 0.0),
            dimension_scores=tuple(
                dict(d) for d in data.get("dimension_scores", [])
            ),
            pipeline_trace=pipeline_trace,
            fingerprint_confidence=data.get("fingerprint_confidence", 0.0),
            fingerprint_observations=data.get("fingerprint_observations", 0),
            drift_by_distribution=data.get("drift_by_distribution", {}),
            drift_severity=data.get("drift_severity", "none"),
            trust_score=data.get("trust_score", 0.5),
            trust_direction=data.get("trust_direction", "stable"),
            trust_velocity=data.get("trust_velocity", 0.0),
            contract=contract,
            invariant_results=tuple(
                dict(r) for r in data.get("invariant_results", [])
            ),
            semantic=semantic,
            causal_links=causal_links,
            action_to_pass=action_to_pass,
            reversibility_level=data.get("reversibility_level", ""),
            reversibility_forced_tier3=data.get("reversibility_forced_tier3", False),
            cross_dimensional_signal_count=data.get(
                "cross_dimensional_signal_count", 0
            ),
            cross_dimensional_ucs_adjustment=data.get(
                "cross_dimensional_ucs_adjustment", 0.0
            ),
            weight_adjustments_applied=data.get("weight_adjustments_applied", {}),
            trust_modifier_applied=data.get("trust_modifier_applied", 0.0),
            previous_entry_hash=data.get("previous_entry_hash", ""),
            entry_hash=data.get("entry_hash", ""),
        )

    def to_json(self, indent: int = 2) -> str:
        """Full JSON serialization. Used by API endpoints and CLI --json flag."""
        return json.dumps(self.to_dict(), indent=indent, default=str)

    def to_text(self) -> str:
        """Structured plain text for CLI display. Formatted for terminal width ~100 chars."""
        from datetime import datetime, timezone

        ts = datetime.fromtimestamp(self.timestamp, tz=timezone.utc).strftime(
            "%Y-%m-%d %H:%M:%S"
        )
        bar = "\u2550" * 71
        thin = "\u2500"

        lines: list[str] = []
        lines.append(bar)
        lines.append(
            f"BehaviorLedger Entry #{self.sequence_number} | "
            f"agent: {self.agent_id} | {ts}"
        )
        lines.append(bar)
        lines.append("")

        # Verdict summary
        lines.append(
            f"VERDICT: {self.verdict}    UCS: {self.ucs:.3f}    "
            f"Tier: {self.tier}    Time: {self.evaluation_time_ms:.1f}ms"
        )
        lines.append("")

        # Pipeline trace
        lines.append(f"{thin}{thin} Pipeline Trace " + thin * 55)
        for i, step in enumerate(self.pipeline_trace, 1):
            desc = step.description
            # Build a concise output summary
            out_parts: list[str] = []
            for k, v in step.output_state.items():
                if isinstance(v, float):
                    out_parts.append(f"{v:.3f}")
                else:
                    out_parts.append(str(v))
            out_str = ", ".join(out_parts) if out_parts else ""
            decision = step.decision or ""
            if step.decided_verdict:
                decision += " \u2713"
            detail = f" {out_str}" if out_str else ""
            if decision:
                detail += f" ({decision})" if detail else f" {decision}"
            lines.append(f"   {i}. {step.step_id}{detail}")
        lines.append("")

        # Behavioral state
        lines.append(f"{thin}{thin} Behavioral State " + thin * 53)
        lines.append(
            f"Fingerprint: {int(self.fingerprint_confidence * 100)}% confidence "
            f"({self.fingerprint_observations:,} observations)"
        )
        drift_parts = [
            f"{k}: {v:.2f}" for k, v in self.drift_by_distribution.items()
        ]
        drift_str = ", ".join(drift_parts) if drift_parts else "none"
        lines.append(f"Drift: {self.drift_severity} ({drift_str})")
        vel_str = f"{self.trust_velocity:+.2f}" if self.trust_velocity else ""
        trust_extra = f", {self.trust_direction}"
        if vel_str:
            trust_extra += f" ({vel_str})"
        lines.append(f"Trust: {self.trust_score:.2f}{trust_extra}")
        lines.append("")

        # Contract
        if self.contract and self.contract.contract_id:
            lines.append(f"{thin}{thin} Contract " + thin * 61)
            inv_results = self.invariant_results
            satisfied = sum(1 for r in inv_results if r.get("status") == "satisfied")
            violated = sum(1 for r in inv_results if r.get("status") == "violated")
            total = self.contract.invariant_count or len(inv_results)
            lines.append(
                f"Contract v{self.contract.version} ({self.contract.archetype}) | "
                f"{satisfied}/{total} invariants satisfied"
                + (f", {violated} violated" if violated else "")
            )
            lines.append("")

        # Margin analysis
        if self.action_to_pass:
            lines.append(f"{thin}{thin} Margin Analysis " + thin * 54)
            atp = self.action_to_pass
            if atp.current_verdict == "ALLOW":
                lines.append(
                    f"Margin to DENY: {atp.margin_to_deny:.3f} | "
                    f"Closest veto: {atp.closest_veto_dimension} at {atp.closest_veto_margin:.2f}"
                )
            elif atp.current_verdict == "DENY":
                lines.append(
                    f"UCS gap to ALLOW: {atp.ucs_gap:.3f} | UCS needed: {atp.ucs_needed:.3f}"
                )
                if atp.dimension_gaps:
                    gap_parts = [f"{k}: needs +{v:.3f}" for k, v in atp.dimension_gaps.items()]
                    lines.append(f"Dimension gaps: {', '.join(gap_parts)}")
            else:
                lines.append(atp.detail)
            lines.append("")

        # Causal chain
        if self.causal_links:
            lines.append(f"{thin}{thin} Causal Chain " + thin * 57)
            for cl in self.causal_links:
                lines.append(
                    f"\u2190 Entry {cl.previous_entry_id}: "
                    f"{cl.trust_delta:+.2f} trust ({cl.influence_description})"
                )
            lines.append("")

        # Footer
        hash_short = self.entry_hash[:8] + "..." if self.entry_hash else "n/a"
        prev_short = self.previous_entry_hash[:8] + "..." if self.previous_entry_hash else "n/a"
        lines.append(bar)
        lines.append(f"Hash: {hash_short} | Previous: {prev_short}")
        lines.append(bar)

        return "\n".join(lines)

    def summary(self) -> str:
        """One-paragraph human-readable reconstruction of the decision."""
        from datetime import datetime, timezone

        ts = datetime.fromtimestamp(self.timestamp, tz=timezone.utc).strftime(
            "%Y-%m-%dT%H:%M:%SZ"
        )

        # Pipeline summary
        pipeline_parts: list[str] = []
        for step in self.pipeline_trace:
            if step.decision:
                pipeline_parts.append(f"{step.step_id}: {step.decision}")

        pipeline_str = ", ".join(pipeline_parts) if pipeline_parts else "no decisions recorded"

        # Vetoes
        veto_dims = [
            d["name"]
            for d in self.dimension_scores
            if d.get("veto")
        ]
        veto_str = f", vetoed by {', '.join(veto_dims)}" if veto_dims else ", no vetoes"

        # Contract
        if self.contract and self.contract.contract_id:
            contract_str = (
                f"contract v{self.contract.version} "
                f"({self.contract.invariant_count} invariants)"
            )
        else:
            contract_str = "no contract"

        # Margin
        if self.action_to_pass:
            if self.verdict == "ALLOW":
                margin_str = f"Margin to deny: {self.action_to_pass.margin_to_deny:.3f}"
            elif self.verdict == "DENY":
                margin_str = f"UCS gap: {self.action_to_pass.ucs_gap:.3f}"
            else:
                margin_str = ""
        else:
            margin_str = ""

        parts = [
            f"Decision #{self.sequence_number} for agent {self.agent_id} at {ts}.",
            f"Action: {self.action_type} on {self.action_target}.",
            f"Verdict: {self.verdict} (UCS {self.ucs:.3f}, Tier {self.tier}).",
            f"Pipeline: {pipeline_str}{veto_str}.",
            f"Behavioral state: fingerprint {int(self.fingerprint_confidence * 100)}% confidence, "
            f"drift {self.drift_severity}, trust {self.trust_score:.2f} ({self.trust_direction}).",
            f"Contract: {contract_str}.",
        ]
        if margin_str:
            parts.append(f"{margin_str}.")
        if self.causal_links:
            link = self.causal_links[0]
            parts.append(
                f"Previous decision #{link.previous_entry_id} "
                f"contributed {link.trust_delta:+.3f} trust."
            )

        return " ".join(parts)

    def narrative(self) -> str:
        """Multi-paragraph narrative reconstruction for compliance/audit review.

        Walks through each pipeline step in order, explaining what happened
        and why, in language a regulator or board member can understand.
        """
        from datetime import datetime, timezone

        ts = datetime.fromtimestamp(self.timestamp, tz=timezone.utc).strftime(
            "%Y-%m-%dT%H:%M:%SZ"
        )

        paragraphs: list[str] = []

        # Overview
        paragraphs.append(
            f"GOVERNANCE DECISION RECORD #{self.sequence_number}\n"
            f"Agent: {self.agent_id}\n"
            f"Timestamp: {ts}\n"
            f"Action: {self.action_type} on {self.action_target}\n"
            f"Final Verdict: {self.verdict} (UCS {self.ucs:.4f}, Tier {self.tier})\n"
            f"Evaluation Time: {self.evaluation_time_ms:.1f}ms"
        )

        # Pipeline walkthrough
        if self.pipeline_trace:
            paragraphs.append("PIPELINE TRACE:")
            for i, step in enumerate(self.pipeline_trace, 1):
                step_text = f"  Step {i} — {step.description}"
                if step.input_state:
                    inputs = ", ".join(
                        f"{k}={v}" for k, v in step.input_state.items()
                    )
                    step_text += f"\n    Input: {inputs}"
                if step.output_state:
                    outputs = ", ".join(
                        f"{k}={v}" for k, v in step.output_state.items()
                    )
                    step_text += f"\n    Output: {outputs}"
                if step.decision:
                    step_text += f"\n    Decision: {step.decision}"
                if step.decided_verdict:
                    step_text += " [FINAL]"
                paragraphs.append(step_text)

        # Behavioral state
        paragraphs.append(
            "BEHAVIORAL STATE:\n"
            f"  Fingerprint confidence: {self.fingerprint_confidence:.0%} "
            f"({self.fingerprint_observations} observations)\n"
            f"  Drift severity: {self.drift_severity}\n"
            f"  Trust: {self.trust_score:.4f} ({self.trust_direction}, "
            f"velocity {self.trust_velocity:+.4f})"
        )

        # Dimension scores
        if self.dimension_scores:
            dim_lines = ["DIMENSION SCORES:"]
            for d in self.dimension_scores:
                veto_marker = " [VETO]" if d.get("veto") else ""
                dim_lines.append(
                    f"  {d.get('name', '?')}: {d.get('score', 0):.3f} "
                    f"(weight {d.get('weight', 1):.2f}){veto_marker}"
                )
            paragraphs.append("\n".join(dim_lines))

        # Contract
        if self.contract and self.contract.contract_id:
            paragraphs.append(
                f"CONTRACT: {self.contract.contract_id} v{self.contract.version} "
                f"(archetype: {self.contract.archetype}, "
                f"{self.contract.invariant_count} invariants)"
            )

        # What would need to change
        if self.action_to_pass:
            atp = self.action_to_pass
            if atp.current_verdict == "DENY" and atp.dimension_gaps:
                gaps = ", ".join(
                    f"{k}: needs +{v:.3f}" for k, v in atp.dimension_gaps.items()
                )
                paragraphs.append(
                    f"TO CHANGE VERDICT: UCS needed {atp.ucs_needed:.3f} "
                    f"(gap {atp.ucs_gap:.3f}). Dimension gaps: {gaps}."
                )
            elif atp.current_verdict == "ALLOW":
                paragraphs.append(
                    f"SAFETY MARGIN: {atp.margin_to_deny:.3f} above deny threshold. "
                    f"Closest veto dimension: {atp.closest_veto_dimension} "
                    f"(margin {atp.closest_veto_margin:.3f})."
                )

        # Causal links
        if self.causal_links:
            link_lines = ["CAUSAL LINKS:"]
            for cl in self.causal_links:
                link_lines.append(
                    f"  {cl.influence_type}: {cl.influence_description}"
                )
            paragraphs.append("\n".join(link_lines))

        return "\n\n".join(paragraphs)


# ── BehaviorLedgerStore ─────────────────────────────────────────────


class BehaviorLedgerStore:
    """Persistent store for BehaviorLedger entries.

    In-memory with optional JSONL persistence (same pattern as AuditStore).
    Hash-chained for tamper evidence. Queryable by agent, time range,
    verdict, sequence number.
    """

    def __init__(
        self,
        base_dir: str | None = None,
        max_entries: int = 50000,
    ) -> None:
        self._entries: dict[str, list[BehaviorLedgerEntry]] = {}
        self._entries_by_id: dict[str, BehaviorLedgerEntry] = {}
        self._sequence: dict[str, int] = {}
        self._last_hash: dict[str, str] = {}
        self._lock = threading.Lock()
        self._base_dir = base_dir
        self._max_entries = max_entries

    def append(self, entry: BehaviorLedgerEntry) -> BehaviorLedgerEntry:
        """Append an entry, computing hash chain. Returns entry with hash populated."""
        from dataclasses import replace

        with self._lock:
            agent_id = entry.agent_id
            seq = self._sequence.get(agent_id, 0)
            prev_hash = self._last_hash.get(agent_id, "")

            # Replace sequence_number and previous_entry_hash
            entry = replace(
                entry,
                sequence_number=seq,
                previous_entry_hash=prev_hash,
            )
            # Compute and set hash
            computed_hash = entry.compute_hash()
            entry = replace(entry, entry_hash=computed_hash)

            self._entries.setdefault(agent_id, []).append(entry)
            self._entries_by_id[entry.entry_id] = entry
            self._sequence[agent_id] = seq + 1
            self._last_hash[agent_id] = computed_hash

            # Enforce max entries per agent
            agent_entries = self._entries[agent_id]
            if len(agent_entries) > self._max_entries:
                removed = agent_entries.pop(0)
                self._entries_by_id.pop(removed.entry_id, None)

            # Persist to JSONL if configured
            if self._base_dir is not None:
                self._persist(entry)

            return entry

    def get(self, agent_id: str, sequence_number: int) -> BehaviorLedgerEntry | None:
        """Get a specific entry by agent and sequence."""
        with self._lock:
            for e in self._entries.get(agent_id, []):
                if e.sequence_number == sequence_number:
                    return e
            return None

    def get_latest(self, agent_id: str) -> BehaviorLedgerEntry | None:
        """Get the most recent entry for an agent."""
        with self._lock:
            entries = self._entries.get(agent_id, [])
            return entries[-1] if entries else None

    def get_by_id(self, entry_id: str) -> BehaviorLedgerEntry | None:
        """Get an entry by its unique entry_id."""
        with self._lock:
            return self._entries_by_id.get(entry_id)

    def query(
        self,
        agent_id: str | None = None,
        since: float | None = None,
        until: float | None = None,
        verdict: str | None = None,
        limit: int = 100,
    ) -> list[BehaviorLedgerEntry]:
        """Query entries with filters."""
        with self._lock:
            if agent_id is not None:
                candidates = list(self._entries.get(agent_id, []))
            else:
                candidates = []
                for entries in self._entries.values():
                    candidates.extend(entries)
                candidates.sort(key=lambda e: e.timestamp)

            results: list[BehaviorLedgerEntry] = []
            for e in candidates:
                if since is not None and e.timestamp < since:
                    continue
                if until is not None and e.timestamp > until:
                    continue
                if verdict is not None and e.verdict != verdict:
                    continue
                results.append(e)
                if len(results) >= limit:
                    break
            return results

    def get_causal_chain(
        self, entry_id: str, depth: int = 10
    ) -> list[BehaviorLedgerEntry]:
        """Walk causal links backward from an entry, up to depth entries."""
        chain: list[BehaviorLedgerEntry] = []
        current_id = entry_id
        visited: set[str] = set()
        for _ in range(depth):
            if current_id in visited:
                break
            visited.add(current_id)
            entry = self.get_by_id(current_id)
            if entry is None:
                break
            chain.append(entry)
            if not entry.causal_links:
                break
            current_id = entry.causal_links[0].previous_entry_id
        return chain

    def verify_chain(self, agent_id: str) -> tuple[bool, str]:
        """Verify hash chain integrity for an agent. Returns (valid, error_message)."""
        with self._lock:
            entries = self._entries.get(agent_id, [])
            if not entries:
                return True, ""

            prev_hash = ""
            for i, entry in enumerate(entries):
                if entry.previous_entry_hash != prev_hash:
                    return False, (
                        f"Entry #{entry.sequence_number}: previous_entry_hash mismatch "
                        f"(expected {prev_hash!r}, got {entry.previous_entry_hash!r})"
                    )
                expected = entry.compute_hash()
                if entry.entry_hash != expected:
                    return False, (
                        f"Entry #{entry.sequence_number}: entry_hash mismatch "
                        f"(expected {expected!r}, got {entry.entry_hash!r})"
                    )
                prev_hash = entry.entry_hash

            return True, ""

    def next_sequence(self, agent_id: str) -> int:
        """Return the next sequence number for an agent."""
        with self._lock:
            return self._sequence.get(agent_id, 0)

    def _persist(self, entry: BehaviorLedgerEntry) -> None:
        """Append entry to JSONL file."""
        base = Path(self._base_dir)  # type: ignore[arg-type]
        base.mkdir(parents=True, exist_ok=True)
        path = base / f"ledger_{entry.agent_id}.jsonl"
        line = json.dumps(entry.to_dict(), sort_keys=True, default=str)
        with open(path, "a") as f:
            f.write(line + "\n")


# ── Builder function ────────────────────────────────────────────────


def build_ledger_entry(
    action: Any,
    context: Any,
    verdict: Any,
    tracer: PipelineTracer,
    fingerprint_observer: Any | None = None,
    contract_store: Any | None = None,
    semantic_observer: Any | None = None,
    ledger_store: BehaviorLedgerStore | None = None,
    drift_score: Any | None = None,
    allow_threshold: float = 0.7,
    deny_threshold: float = 0.3,
    derived_thresholds: Any | None = None,
) -> BehaviorLedgerEntry:
    """Assemble a complete BehaviorLedgerEntry from current system state."""

    entry_id = uuid.uuid4().hex[:12]
    now = time.time()
    seq = ledger_store.next_sequence(context.agent_id) if ledger_store else 0

    # Extract dimension scores
    dim_scores: list[dict[str, Any]] = []
    for ds in (verdict.dimension_scores or []):
        dim_scores.append({
            "name": ds.dimension_name,
            "score": round(ds.score, 4),
            "weight": round(ds.weight, 4),
            "veto": ds.veto,
            "reasoning": ds.reasoning,
        })

    # Pipeline trace
    pipeline_trace = tracer.finalize()

    # Behavioral state from fingerprint observer
    fp_confidence = 0.0
    fp_observations = 0
    drift_by_dist: dict[str, float] = {}
    drift_sev = "none"
    trust_score = context.trust_profile.overall_trust
    trust_dir = "stable"
    trust_vel = 0.0

    if fingerprint_observer is not None:
        fp = fingerprint_observer.get_fingerprint(context.agent_id)
        if fp is not None:
            fp_confidence = fp.confidence
            fp_observations = fp.total_observations

        if drift_score is not None:
            drift_by_dist = {
                "action": drift_score.action_drift,
                "target": drift_score.target_drift,
                "temporal": drift_score.temporal_drift,
                "outcome": drift_score.outcome_drift,
                "semantic": getattr(drift_score, "semantic_drift", 0.0),
            }
            drift_sev = drift_score.severity

    # Trust direction from provenance if available
    if verdict.behavioral_provenance is not None:
        bp = verdict.behavioral_provenance
        trust_dir = bp.trust_direction
        trust_vel = bp.trust_velocity

    # Contract snapshot
    contract_snap: ContractSnapshot | None = None
    invariant_results: list[dict[str, Any]] = []
    if contract_store is not None:
        contract = contract_store.get_active(context.agent_id)
        if contract is not None:
            inv_specs: list[tuple[str, ...]] = []
            for inv in contract.invariants:
                inv_specs.append((
                    inv.get("id", ""),
                    inv.get("type", ""),
                    inv.get("metric", ""),
                    str(inv.get("threshold", "")),
                ))

            anchor_terms: list[str] = []
            for anchor in contract.semantic_anchors:
                term = anchor.get("term", "")
                if term:
                    anchor_terms.append(term)

            _cps: dict[str, Any] = {}
            if derived_thresholds is not None and derived_thresholds.cost_profile_summary:
                _cps = dict(derived_thresholds.cost_profile_summary)

            contract_snap = ContractSnapshot(
                contract_id=contract.contract_id,
                version=contract.version,
                archetype=contract.archetype,
                drift_thresholds=dict(contract.drift_thresholds),
                invariant_count=len(contract.invariants),
                invariant_specs_summary=tuple(inv_specs),
                semantic_anchor_terms=tuple(anchor_terms),
                cost_profile_summary=_cps,
            )

    # Semantic context
    sem_ctx: SemanticContext | None = None
    if semantic_observer is not None:
        instruction = action.parameters.get("instruction_context", "") if action.parameters else ""
        sem_drift = semantic_observer.get_semantic_drift(context.agent_id)
        if sem_drift is not None:
            per_term = {}
            most_drifted = ""
            max_drift = 0.0
            if hasattr(sem_drift, "per_term_drift"):
                per_term = dict(sem_drift.per_term_drift)
            if hasattr(sem_drift, "most_drifted_term"):
                most_drifted = sem_drift.most_drifted_term
            agg = getattr(sem_drift, "aggregate_drift", 0.0)
            sem_ctx = SemanticContext(
                instruction_context=instruction,
                per_term_drift=per_term,
                aggregate_semantic_drift=agg,
                most_drifted_term=most_drifted,
            )
        else:
            sem_ctx = SemanticContext(instruction_context=instruction)

    # Causal links
    causal_links: list[CausalLink] = []
    if ledger_store is not None:
        prev_entry = ledger_store.get_latest(context.agent_id)
        if prev_entry is not None:
            trust_delta = trust_score - prev_entry.trust_score
            desc = (
                f"Decision #{prev_entry.sequence_number} "
                f"({prev_entry.verdict}) changed trust "
                f"from {prev_entry.trust_score:.4f} to {trust_score:.4f} "
                f"({trust_delta:+.4f})"
            )
            causal_links.append(
                CausalLink(
                    previous_entry_id=prev_entry.entry_id,
                    influence_type="trust_change",
                    influence_description=desc,
                    trust_delta=trust_delta,
                )
            )

    # Action to pass
    verdict_name = verdict.verdict.name if hasattr(verdict.verdict, "name") else str(verdict.verdict)
    action_to_pass: ActionToPass | None = None

    if verdict_name == "DENY":
        dim_gaps: dict[str, float] = {}
        for ds in (verdict.dimension_scores or []):
            if ds.veto:
                dim_gaps[ds.dimension_name] = round(0.4 - ds.score, 4)
            elif ds.score < 0.4:
                dim_gaps[ds.dimension_name] = round(0.4 - ds.score, 4)
        action_to_pass = ActionToPass(
            current_verdict="DENY",
            dimension_gaps=dim_gaps,
            ucs_needed=allow_threshold,
            ucs_gap=round(allow_threshold - verdict.ucs, 4),
            detail=f"UCS {verdict.ucs:.4f} below allow threshold {allow_threshold:.4f}",
        )
    elif verdict_name == "ALLOW":
        margin = round(verdict.ucs - deny_threshold, 4)
        # Find closest veto-capable dimension to 0
        closest_dim = ""
        closest_margin = 1.0
        for ds in (verdict.dimension_scores or []):
            if hasattr(ds, "dimension_name"):
                if ds.score < closest_margin:
                    closest_margin = ds.score
                    closest_dim = ds.dimension_name
        action_to_pass = ActionToPass(
            current_verdict="ALLOW",
            margin_to_deny=margin,
            closest_veto_dimension=closest_dim,
            closest_veto_margin=round(closest_margin, 4),
            detail=f"UCS {verdict.ucs:.4f} above deny threshold {deny_threshold:.4f} by {margin:.4f}",
        )
    else:
        action_to_pass = ActionToPass(
            current_verdict=verdict_name,
            detail=f"Verdict is {verdict_name}",
        )

    # Reversibility
    rev_level = ""
    rev_forced = False
    if verdict.reversibility:
        rev_level = verdict.reversibility.get("level", "")
        rev_forced = verdict.reversibility.get("requires_escalation", False)

    # Cross-dimensional signals
    cross_dim_count = len(verdict.cross_dimensional_signals) if verdict.cross_dimensional_signals else 0
    cross_dim_adj = 0.0
    if verdict.cross_dimensional_signals:
        critical = [s for s in verdict.cross_dimensional_signals if getattr(s, "severity", "") == "critical"]
        if critical and deny_threshold < verdict.ucs < allow_threshold:
            cross_dim_adj = -0.1

    # Contextual modification
    weight_adj: dict[str, float] = {}
    trust_mod = 0.0
    if verdict.context_modification is not None:
        cm = verdict.context_modification
        if hasattr(cm, "weight_adjustments") and cm.weight_adjustments:
            for wa in cm.weight_adjustments:
                dim_name = wa.dimension if hasattr(wa, "dimension") else str(wa)
                adj_val = wa.adjusted_weight if hasattr(wa, "adjusted_weight") else 0.0
                weight_adj[dim_name] = adj_val
        if hasattr(cm, "trust_modifier"):
            trust_mod = cm.trust_modifier

    return BehaviorLedgerEntry(
        entry_id=entry_id,
        timestamp=now,
        sequence_number=seq,
        agent_id=context.agent_id,
        action_type=action.action_type,
        action_target=action.target,
        action_parameters=dict(action.parameters) if action.parameters else {},
        verdict=verdict_name,
        ucs=verdict.ucs,
        tier=verdict.tier,
        reasoning=verdict.reasoning,
        vetoed_by=tuple(verdict.vetoed_by) if verdict.vetoed_by else (),
        evaluation_time_ms=verdict.evaluation_time_ms,
        dimension_scores=tuple(dim_scores),
        pipeline_trace=pipeline_trace,
        fingerprint_confidence=fp_confidence,
        fingerprint_observations=fp_observations,
        drift_by_distribution=drift_by_dist,
        drift_severity=drift_sev,
        trust_score=trust_score,
        trust_direction=trust_dir,
        trust_velocity=trust_vel,
        contract=contract_snap,
        invariant_results=tuple(invariant_results),
        semantic=sem_ctx,
        causal_links=tuple(causal_links),
        action_to_pass=action_to_pass,
        reversibility_level=rev_level,
        reversibility_forced_tier3=rev_forced,
        cross_dimensional_signal_count=cross_dim_count,
        cross_dimensional_ucs_adjustment=cross_dim_adj,
        weight_adjustments_applied=weight_adj,
        trust_modifier_applied=trust_mod,
    )


# ── Exporter ───────────────────────────────────────────────────────


class BehaviorLedgerExporter:
    """Export ledger entries in compliance-friendly formats."""

    def export_json(self, entries: list[BehaviorLedgerEntry], output_path: str) -> None:
        """Export entries as a JSON array file."""
        data = [e.to_dict() for e in entries]
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, default=str)

    def export_jsonl(self, entries: list[BehaviorLedgerEntry], output_path: str) -> None:
        """Export entries as newline-delimited JSON (one entry per line)."""
        with open(output_path, "w", encoding="utf-8") as f:
            for entry in entries:
                f.write(json.dumps(entry.to_dict(), sort_keys=True, default=str) + "\n")

    def export_narrative(self, entries: list[BehaviorLedgerEntry], output_path: str) -> None:
        """Export entries as a human-readable narrative report.

        Output is a plain text document with each entry's narrative() separated
        by dividers. Suitable for attaching to compliance evidence bundles or
        sending to regulators.
        """
        divider = "=" * 72 + "\n"
        with open(output_path, "w", encoding="utf-8") as f:
            f.write("GOVERNANCE DECISION NARRATIVE REPORT\n")
            f.write(divider)
            f.write(f"Generated: {time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}\n")
            f.write(f"Entries: {len(entries)}\n")
            f.write(divider + "\n")
            for i, entry in enumerate(entries, 1):
                f.write(f"--- Entry {i} of {len(entries)} ---\n\n")
                f.write(entry.narrative())
                f.write("\n\n" + divider + "\n")

    def export_csv_summary(self, entries: list[BehaviorLedgerEntry], output_path: str) -> None:
        """Export a summary CSV with one row per entry.

        Columns: entry_id, timestamp, agent_id, action_type, action_target,
        verdict, ucs, tier, drift_severity, trust_score, trust_direction,
        contract_version, invariants_satisfied, invariants_violated,
        pipeline_steps_count, evaluation_time_ms, entry_hash

        Suitable for import into spreadsheets, BI tools, or compliance databases.
        """
        import csv

        fieldnames = [
            "entry_id", "timestamp", "agent_id", "action_type", "action_target",
            "verdict", "ucs", "tier", "drift_severity", "trust_score",
            "trust_direction", "contract_version", "invariants_satisfied",
            "invariants_violated", "pipeline_steps_count", "evaluation_time_ms",
            "entry_hash",
        ]

        with open(output_path, "w", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for entry in entries:
                inv_results = entry.invariant_results
                satisfied = sum(1 for r in inv_results if r.get("status") == "satisfied")
                violated = sum(1 for r in inv_results if r.get("status") == "violated")
                contract_version = entry.contract.version if entry.contract else 0
                writer.writerow({
                    "entry_id": entry.entry_id,
                    "timestamp": entry.timestamp,
                    "agent_id": entry.agent_id,
                    "action_type": entry.action_type,
                    "action_target": entry.action_target,
                    "verdict": entry.verdict,
                    "ucs": round(entry.ucs, 4),
                    "tier": entry.tier,
                    "drift_severity": entry.drift_severity,
                    "trust_score": round(entry.trust_score, 4),
                    "trust_direction": entry.trust_direction,
                    "contract_version": contract_version,
                    "invariants_satisfied": satisfied,
                    "invariants_violated": violated,
                    "pipeline_steps_count": len(entry.pipeline_trace),
                    "evaluation_time_ms": round(entry.evaluation_time_ms, 3),
                    "entry_hash": entry.entry_hash,
                })

    def export_bytes(
        self, entries: list[BehaviorLedgerEntry], fmt: str,
    ) -> tuple[bytes, str, str]:
        """Export entries and return (bytes, content_type, filename_extension).

        Used by the API export endpoint to stream the file directly.
        """
        if fmt == "json":
            data = json.dumps(
                [e.to_dict() for e in entries], indent=2, default=str,
            ).encode("utf-8")
            return data, "application/json", "json"
        elif fmt == "jsonl":
            lines: list[str] = []
            for entry in entries:
                lines.append(json.dumps(entry.to_dict(), sort_keys=True, default=str))
            data = "\n".join(lines).encode("utf-8")
            return data, "application/x-ndjson", "jsonl"
        elif fmt == "narrative":
            parts: list[str] = []
            divider = "=" * 72
            parts.append("GOVERNANCE DECISION NARRATIVE REPORT")
            parts.append(divider)
            parts.append(f"Generated: {time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}")
            parts.append(f"Entries: {len(entries)}")
            parts.append(divider + "\n")
            for i, entry in enumerate(entries, 1):
                parts.append(f"--- Entry {i} of {len(entries)} ---\n")
                parts.append(entry.narrative())
                parts.append("\n" + divider + "\n")
            data = "\n".join(parts).encode("utf-8")
            return data, "text/plain; charset=utf-8", "txt"
        elif fmt == "csv":
            import csv
            import io

            fieldnames = [
                "entry_id", "timestamp", "agent_id", "action_type", "action_target",
                "verdict", "ucs", "tier", "drift_severity", "trust_score",
                "trust_direction", "contract_version", "invariants_satisfied",
                "invariants_violated", "pipeline_steps_count", "evaluation_time_ms",
                "entry_hash",
            ]
            buf = io.StringIO()
            writer = csv.DictWriter(buf, fieldnames=fieldnames)
            writer.writeheader()
            for entry in entries:
                inv_results = entry.invariant_results
                satisfied = sum(1 for r in inv_results if r.get("status") == "satisfied")
                violated = sum(1 for r in inv_results if r.get("status") == "violated")
                contract_version = entry.contract.version if entry.contract else 0
                writer.writerow({
                    "entry_id": entry.entry_id,
                    "timestamp": entry.timestamp,
                    "agent_id": entry.agent_id,
                    "action_type": entry.action_type,
                    "action_target": entry.action_target,
                    "verdict": entry.verdict,
                    "ucs": round(entry.ucs, 4),
                    "tier": entry.tier,
                    "drift_severity": entry.drift_severity,
                    "trust_score": round(entry.trust_score, 4),
                    "trust_direction": entry.trust_direction,
                    "contract_version": contract_version,
                    "invariants_satisfied": satisfied,
                    "invariants_violated": violated,
                    "pipeline_steps_count": len(entry.pipeline_trace),
                    "evaluation_time_ms": round(entry.evaluation_time_ms, 3),
                    "entry_hash": entry.entry_hash,
                })
            data = buf.getvalue().encode("utf-8")
            return data, "text/csv", "csv"
        else:
            raise ValueError(f"Unsupported export format: {fmt!r}")
