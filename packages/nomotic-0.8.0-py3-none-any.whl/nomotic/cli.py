"""Nomotic CLI — Behavioral Control Plane for agentic AI.

Usage::

    nomotic setup
    nomotic new
    nomotic birth --name my-agent
    nomotic birth --name my-agent --archetype customer-experience --org acme
    nomotic verify <cert-id>
    nomotic inspect <agent-id>
    nomotic inspect <agent-id> --brief
    nomotic inspect <agent-id> --raw
    nomotic status
    nomotic status --presets
    nomotic config set --retention 5y
    nomotic suspend <cert-id> --reason "policy violation"
    nomotic revoke <cert-id> --reason "decommissioned"
    nomotic reactivate <cert-id>
    nomotic renew <cert-id>
    nomotic list [--status ACTIVE] [--archetype ...] [--org ...]
    nomotic reputation <cert-id>
    nomotic export <cert-id>

    nomotic archetype list [--category ...]
    nomotic archetype set <agent>
    nomotic archetype register --name <name> --description <desc> --category <cat>
    nomotic archetype validate <name>

    nomotic org register --name <name> [--email <email>]
    nomotic org list [--status ACTIVE]
    nomotic org validate <name>

    nomotic zone validate <path>

    nomotic serve [--host 0.0.0.0] [--port 8420]

Configuration is stored in ``~/.nomotic/config.json``.
Certificates are stored in ``~/.nomotic/certs/``.
The issuer key is stored in ``~/.nomotic/issuer/``.
"""

from __future__ import annotations

import argparse
import importlib.metadata as _meta
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any

try:
    _CLI_VERSION = _meta.version("nomotic")
except _meta.PackageNotFoundError:
    _CLI_VERSION = "dev"

if TYPE_CHECKING:
    from nomotic.audit_store import LogStore, PersistentLogRecord
    from nomotic.sandbox import AgentConfig
    from nomotic.types import GovernanceVerdict

from nomotic.authority import CertificateAuthority
from nomotic.certificate import CertStatus, ModelProvenance
from nomotic.id_registry import AgentIdRegistry
from nomotic.keys import SigningKey, VerifyKey
from nomotic.org_governance import (
    OrgGovernanceConfig,
    generate_org_config_from_preset,
    save_org_config,
)
from nomotic.presets import (
    PRESET_DISCLAIMER,
    get_preset,
    list_compliance_presets,
    list_severity_presets,
    merge_presets,
)
from nomotic.registry import (
    ArchetypeRegistry,
    FileOrgStore,
    OrganizationRegistry,
    OrgStatus,
    ZoneValidator,
    _normalize_org_name,
)
from nomotic.presets import get_preset_names
from nomotic.store import FileCertificateStore

__all__ = ["main"]

# ── Archetype → compliance preset mapping ─────────────────────────────────
# When an archetype is selected during `nomotic birth`, the corresponding
# compliance preset is auto-applied unless the user explicitly passes --preset.

ARCHETYPE_PRESET_MAP: dict[str, str] = {
    "healthcare-agent":   "hipaa_aligned",
    "financial-analyst":  "soc2_aligned",
    "sales-agent":        "soc2_aligned",
    "security-monitor":   "ultra_strict",
    "legal-assistant":    "soc2_aligned",
    "hr-agent":           "strict",
    "procurement-agent":  "strict",
    "devops-agent":       "strict",
    "fraud-detection":    "ultra_strict",
    "document-processor": "standard",
    # all other archetypes default to "strict"
}

_DEFAULT_BASE = Path.home() / ".nomotic"


# ── ANSI color support ───────────────────────────────────────────────────


def _init_colors() -> bool:
    """Initialize ANSI color support. Returns True if colors are available."""
    if not sys.stdout.isatty():
        return False
    if os.environ.get("NO_COLOR"):
        return False
    if os.name == "nt":
        try:
            import ctypes
            kernel32 = ctypes.windll.kernel32  # type: ignore[attr-defined]
            # Enable ANSI escape sequences on Windows 10+
            kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 7)
            return True
        except Exception:
            return False
    return True


_COLORS_ENABLED = _init_colors()


def _c(code: str, text: str) -> str:
    return text if not _COLORS_ENABLED else f"\033[{code}m{text}\033[0m"


def _bold(t: str) -> str:
    return _c("1", t)


def _green(t: str) -> str:
    return _c("32", t)


def _red(t: str) -> str:
    return _c("31", t)


def _yellow(t: str) -> str:
    return _c("33", t)


def _cyan(t: str) -> str:
    return _c("36", t)


def _dim(t: str) -> str:
    return _c("2", t)


# ── Issuer key management ────────────────────────────────────────────────


def _issuer_dir(base: Path) -> Path:
    d = base / "issuer"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _load_or_create_issuer(base: Path) -> tuple[SigningKey, VerifyKey, str]:
    """Load the issuer key pair, or generate one on first run."""
    issuer = _issuer_dir(base)
    key_path = issuer / "issuer.key"
    pub_path = issuer / "issuer.pub"
    meta_path = issuer / "issuer.json"

    if key_path.exists():
        sk = SigningKey.from_bytes(key_path.read_bytes())
        vk = sk.verify_key()
        meta = json.loads(meta_path.read_text(encoding="utf-8"))
        return sk, vk, meta["issuer_id"]

    # First run — generate
    sk, vk = SigningKey.generate()
    key_path.write_bytes(sk.to_bytes())
    os.chmod(key_path, 0o600)
    pub_path.write_bytes(vk.to_bytes())
    issuer_id = f"nomotic-cli-{vk.fingerprint()[-12:]}"
    meta = {
        "issuer_id": issuer_id,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "fingerprint": vk.fingerprint(),
    }
    meta_path.write_text(json.dumps(meta, indent=2), encoding="utf-8")
    return sk, vk, issuer_id


def _build_ca(base: Path) -> tuple[CertificateAuthority, FileCertificateStore]:
    """Build a CertificateAuthority backed by the file store."""
    sk, _vk, issuer_id = _load_or_create_issuer(base)
    store = FileCertificateStore(base)
    ca = CertificateAuthority(issuer_id=issuer_id, signing_key=sk, store=store)
    return ca, store


def _build_registries(base: Path) -> tuple[ArchetypeRegistry, ZoneValidator, OrganizationRegistry]:
    """Build the validation registries for CLI use."""
    archetype_reg = ArchetypeRegistry.with_defaults()
    zone_val = ZoneValidator()
    org_store = FileOrgStore(base)
    org_reg = OrganizationRegistry(store=org_store)
    return archetype_reg, zone_val, org_reg


# ── Nomotic config (setup defaults) ─────────────────────────────────────


def _load_nomotic_config(base: Path) -> dict:
    """Load the nomotic config, or return empty dict if not set up."""
    config_path = base / "config.json"
    if config_path.exists():
        return json.loads(config_path.read_text(encoding="utf-8"))
    return {}


# ── Agent ID registry helpers ────────────────────────────────────────────


def _load_registry(base: Path) -> AgentIdRegistry:
    """Load the AgentIdRegistry, running migration on first use."""
    registry = AgentIdRegistry(base)
    if not registry._path.exists():
        # First use — migrate existing certs
        certs_dir = base / "certs"
        registry.migrate_from_certs(certs_dir)
        registry._save()
    return registry


# ── Identifier resolution ────────────────────────────────────────────────


def _resolve_agent(base: Path, identifier: str) -> tuple[int, str, str]:
    """Resolve an identifier to (agent_numeric_id, name, cert_id).

    Uses the AgentIdRegistry for resolution.
    Falls back to scanning cert files for old-format agents without
    registry entries.
    """
    registry = _load_registry(base)

    try:
        match = registry.resolve_single(identifier)
        return match["agent_id"], match["name"], match["certificate_id"]
    except ValueError:
        pass

    # Fall back: try registry.resolve for multiple matches
    matches = registry.resolve(identifier)
    if len(matches) > 1:
        print(f"Ambiguous identifier '{identifier}' matches multiple agents:", file=sys.stderr)
        for m in matches:
            print(f"  ID {m['agent_id']}: {m['name']} ({m['certificate_id']})", file=sys.stderr)
        print("  Use numeric ID or name+ID combo to disambiguate.", file=sys.stderr)
        sys.exit(1)

    if len(matches) == 1:
        m = matches[0]
        return m["agent_id"], m["name"], m["certificate_id"]

    # Fall back to scanning cert files for old-format agents
    if identifier.startswith("nmc-"):
        # Direct cert-id — check file exists
        certs_dir = base / "certs"
        cert_path = certs_dir / f"{identifier}.json"
        if cert_path.exists():
            data = json.loads(cert_path.read_text(encoding="utf-8"))
            return data.get("agent_numeric_id", 0), data.get("agent_id", ""), identifier
        revoked_path = base / "revoked" / f"{identifier}.json"
        if revoked_path.exists():
            data = json.loads(revoked_path.read_text(encoding="utf-8"))
            return data.get("agent_numeric_id", 0), data.get("agent_id", ""), identifier

    # Try scanning certs for agent name match (old-format without registry)
    # Case-insensitive comparison
    certs_dir = base / "certs"
    lookup = identifier.lower()
    if certs_dir.exists():
        for cert_file in certs_dir.glob("nmc-*.json"):
            try:
                data = json.loads(cert_file.read_text(encoding="utf-8"))
                if data.get("agent_id", "").lower() == lookup:
                    return (
                        data.get("agent_numeric_id", 0),
                        data.get("agent_id", ""),
                        data["certificate_id"],
                    )
            except (json.JSONDecodeError, KeyError):
                continue

    print(f"No agent found for identifier '{identifier}'.", file=sys.stderr)
    print("  Use 'nomotic list' to see available agents.", file=sys.stderr)
    sys.exit(1)


def _resolve_cert_id(base: Path, identifier: str) -> str:
    """Backward-compatible wrapper: resolve identifier to cert_id only."""
    _numeric_id, _name, cert_id = _resolve_agent(base, identifier)
    return cert_id


# ── CLI commands ─────────────────────────────────────────────────────────


def _cmd_setup(args: argparse.Namespace) -> None:
    """Interactive first-run configuration."""
    try:
        from nomotic.telemetry import get_telemetry
        get_telemetry().record_cli_command("setup")
    except Exception:
        pass
    config_path = args.base_dir / "config.json"

    # Load existing config if present (for re-running setup)
    existing: dict = {}
    if config_path.exists():
        existing = json.loads(config_path.read_text(encoding="utf-8"))

    print()
    print(f"  {_bold('Nomotic Setup')}")
    print(f"  {'─' * 35}")
    print()

    # ── Step 1: Organization ─────────────────────────────────────────────
    default_org = existing.get("organization", "")
    prompt = "  Organization name"
    if default_org:
        prompt += f" [{default_org}]"
    prompt += ": "
    org_input = input(prompt).strip() or default_org
    org = _normalize_org_name(org_input)
    if org_input != org:
        print(f"    \u2192 Normalized to: {org}")
    print()

    # ── Step 2: Owner ────────────────────────────────────────────────────
    default_owner = existing.get("owner", "")
    prompt = "  Your name or email (agent owner)"
    if default_owner:
        prompt += f" [{default_owner}]"
    prompt += ": "
    owner = input(prompt).strip() or default_owner
    print()

    # ── Step 3: Zone ─────────────────────────────────────────────────────
    default_zone = existing.get("default_zone", "global")
    print("  Zones define where agents operate (e.g., global, us/production, eu/staging).")
    prompt = f"  Default governance zone [{default_zone}]: "
    zone_input = input(prompt).strip() or default_zone
    zone = zone_input.lower()
    if zone_input != zone:
        print(f"    \u2192 Normalized to: {zone}")
    print()

    # ── Step 4: Compliance Profile ───────────────────────────────────────
    # Mapping from menu selection to (preset_name, framework_label)
    _COMPLIANCE_MAP: dict[str, tuple[str, str]] = {
        "2": ("soc2_aligned", "SOC2"),
        "3": ("hipaa_aligned", "HIPAA"),
        "4": ("pci_dss_aligned", "PCI-DSS"),
        "5": ("iso27001_aligned", "ISO27001"),
    }
    _MULTI_OPTIONS: list[tuple[str, str, str]] = [
        ("1", "soc2_aligned", "SOC2"),
        ("2", "hipaa_aligned", "HIPAA"),
        ("3", "pci_dss_aligned", "PCI-DSS"),
        ("4", "iso27001_aligned", "ISO27001"),
    ]

    # Show existing compliance as context
    existing_frameworks = existing.get("compliance_frameworks", [])

    # Determine default selection for re-runs
    compliance_default = "1"
    if existing_frameworks:
        if len(existing_frameworks) > 1:
            compliance_default = "6"
        else:
            for sel, (_, label) in _COMPLIANCE_MAP.items():
                if label == existing_frameworks[0]:
                    compliance_default = sel
                    break

    print("  Does your organization have compliance requirements?")
    print()
    print("    [1] No specific requirements (standard defaults)")
    print("    [2] SOC2 \u2014 Service organization controls")
    print("    [3] HIPAA \u2014 Healthcare data protection")
    print("    [4] PCI-DSS \u2014 Payment card security")
    print("    [5] ISO27001 \u2014 Information security management")
    print("    [6] Multiple frameworks")
    print()
    compliance_input = input(f"  Selection [{compliance_default}]: ").strip() or compliance_default

    selected_frameworks: list[str] = []
    selected_presets: list[str] = []

    if compliance_input == "6":
        # Multiple frameworks — follow-up selection
        print()
        print("  Select frameworks (comma-separated numbers):")
        print()
        for num, _, label in _MULTI_OPTIONS:
            print(f"    [{num}] {label}")
        print()
        # Determine default for multi-select from existing config
        multi_default = ""
        if existing_frameworks and len(existing_frameworks) > 1:
            defaults = []
            for num, _, label in _MULTI_OPTIONS:
                if label in existing_frameworks:
                    defaults.append(num)
            multi_default = ",".join(defaults)
        multi_prompt = "  Selections"
        if multi_default:
            multi_prompt += f" [{multi_default}]"
        multi_prompt += ": "
        multi_input = input(multi_prompt).strip() or multi_default
        for part in multi_input.split(","):
            part = part.strip()
            for num, preset, label in _MULTI_OPTIONS:
                if part == num:
                    selected_frameworks.append(label)
                    selected_presets.append(preset)
                    break
    elif compliance_input in _COMPLIANCE_MAP:
        preset_name, framework_label = _COMPLIANCE_MAP[compliance_input]
        selected_frameworks = [framework_label]
        selected_presets = [preset_name]
    # else: selection "1" or anything else → no compliance (empty lists)
    print()

    # ── Step 5: Default Severity ─────────────────────────────────────────
    _SEVERITY_MAP: dict[str, str] = {
        "1": "standard",
        "2": "strict",
        "3": "ultra_strict",
    }
    _SEVERITY_LABELS: dict[str, str] = {
        "standard": "standard",
        "strict": "strict",
        "ultra_strict": "ultra-strict",
    }

    existing_preset = existing.get("default_preset", "standard")
    severity_default = "1"
    for sel, name in _SEVERITY_MAP.items():
        if name == existing_preset:
            severity_default = sel
            break

    print("  Default governance strictness for new agents:")
    print()
    print("    [1] Standard \u2014 reasonable defaults")
    print("    [2] Strict \u2014 elevated security, recommended for production")
    print("    [3] Ultra-strict \u2014 maximum governance for regulated industries")
    print()
    severity_input = input(f"  Selection [{severity_default}]: ").strip() or severity_default
    default_preset = _SEVERITY_MAP.get(severity_input, "standard")
    print()

    # ── Step 6: Org Governance (optional) ────────────────────────────────
    org_gov_path = args.base_dir / "org-governance.yaml"
    org_gov_default = "2"
    if org_gov_path.exists():
        org_gov_default = "1"

    org_gov_generated = False
    if selected_frameworks or selected_presets:
        print("  Create organization-level governance minimums?")
        print("  These set the floor that no agent can go below.")
        print()
        print("    [1] Yes \u2014 generate from your compliance and strictness selections")
        print("    [2] No \u2014 skip for now")
        print()
        org_gov_input = input(f"  Selection [{org_gov_default}]: ").strip() or org_gov_default

        if org_gov_input == "1":
            # Determine the preset to use for generation
            if len(selected_presets) == 1:
                gen_preset_name = selected_presets[0]
                org_config = generate_org_config_from_preset(org, gen_preset_name)
            else:
                # Multiple frameworks — merge presets first
                preset_objects = [get_preset(p) for p in selected_presets]
                merged = merge_presets(*preset_objects)
                gen_preset_name = merged.name
                # Build org config from merged values
                org_config = OrgGovernanceConfig(
                    org_name=org,
                    minimum_weights=dict(merged.dimension_weights),
                    required_vetoes=list(merged.veto_dimensions),
                    minimum_allow_threshold=merged.allow_threshold,
                    minimum_deny_threshold=merged.deny_threshold,
                    minimum_violation_decrement=merged.trust_settings["violation_decrement"],
                    maximum_success_increment=merged.trust_settings["success_increment"],
                    allowed_presets=None,
                    required_frameworks=list(selected_frameworks),
                    source_path="",
                )

            save_org_config(org_config, org_gov_path)
            org_gov_generated = True

            print()
            print(f"  \u2139 Org governance generated using {gen_preset_name} preset.")
            # Build framework reference for disclaimer
            fw_refs = ", ".join(selected_frameworks)
            print(f"    This is Nomotic's interpretation aligned to {fw_refs} concerns.")
            print(f"    It does not constitute {fw_refs} compliance.")
            print(f"    Review {org_gov_path} and adjust for your needs.")
        print()

    # ── Step 7: Telemetry opt-in ────────────────────────────────────────
    telemetry_enabled = "n"
    interactive = sys.stdin.isatty()

    print()
    print("  Help improve Nomotic by sharing anonymous usage data?")
    print("  No agent data. No evaluation content.")
    print("  Only: which archetypes and commands you use, OS, Python version.")
    print()
    print("  You can change this at any time:")
    print("    nomotic config set --telemetry off")
    print()
    if interactive:
        response = input("  Share anonymous usage data? (y/N): ").strip().lower()
        telemetry_enabled = "y" if response in ("y", "yes") else "n"
    else:
        telemetry_enabled = "n"  # default off in non-interactive mode

    if telemetry_enabled == "y":
        print("  Telemetry enabled. Thank you.")
    else:
        print("  Telemetry disabled.")
    print()

    # ── Save config ──────────────────────────────────────────────────────
    config = {
        "organization": org,
        "owner": owner,
        "default_zone": zone,
        "retention": existing.get("retention", "5y"),
        "enforce_unique_names": existing.get("enforce_unique_names", False),
        "compliance_frameworks": selected_frameworks,
        "compliance_presets": selected_presets,
        "default_preset": default_preset,
        "telemetry_enabled": telemetry_enabled,
    }
    args.base_dir.mkdir(parents=True, exist_ok=True)
    config_path.write_text(json.dumps(config, indent=2), encoding="utf-8")

    # ── Completion output ────────────────────────────────────────────────
    print(f"  {_green('Setup complete.')} Configuration saved to {config_path}")
    print()
    print("  Your defaults:")
    print(f"    Organization:   {org}")
    print(f"    Owner:          {owner}")
    print(f"    Zone:           {zone}")
    if selected_frameworks:
        fw_display = ", ".join(selected_frameworks)
        preset_display = ", ".join(selected_presets)
        print(f"    Compliance:     {fw_display} (using {preset_display} preset)")
    else:
        print("    Compliance:     none")
    print(f"    Strictness:     {_SEVERITY_LABELS.get(default_preset, default_preset)}")
    if org_gov_generated:
        print(f"    Org governance: {org_gov_path} \u2713")
    elif org_gov_path.exists():
        print(f"    Org governance: {org_gov_path}")
    else:
        print("    Org governance: not configured")
    tel_status = "enabled" if telemetry_enabled == "y" else "disabled"
    print(f"    Telemetry:      {tel_status}")
    print()
    print("  Next steps:")
    print("    1. Create your first agent:    nomotic birth --name my-agent")
    print("    2. Validate a governance config: nomotic validate nomotic.yaml")
    print("    3. View current settings:       nomotic status")
    print()


# ── Interactive archetype picker ──────────────────────────────────────────

_ARCHETYPE_PICKER_MENU = """\
  What type of agent are you creating?

  Customer & Support
    1.  customer-experience  — Customer service, support interactions
    2.  sales-agent          — Sales assistance, lead qualification

  Finance & Analysis
    3.  financial-analyst    — Financial modeling, market analysis
    4.  fraud-detection      — Fraud detection, risk scoring

  Healthcare & Legal
    5.  healthcare-agent     — Patient data, clinical support
    6.  legal-assistant      — Legal research, document review

  Operations
    7.  operations-coordinator — Process management, coordination
    8.  procurement-agent      — Procurement, vendor management
    9.  devops-agent           — DevOps automation, infrastructure

  Data & Security
   10.  data-processor        — Data transformation, ETL pipelines
   11.  document-processor    — Document parsing, extraction
   12.  security-monitor      — Security monitoring, threat detection

  Executive
   13.  executive-assistant   — Executive support, scheduling
"""

_PICKER_ARCHETYPES = [
    "customer-experience",
    "sales-agent",
    "financial-analyst",
    "fraud-detection",
    "healthcare-agent",
    "legal-assistant",
    "operations-coordinator",
    "procurement-agent",
    "devops-agent",
    "data-processor",
    "document-processor",
    "security-monitor",
    "executive-assistant",
]

_PICKER_VALID_NAMES = set(_PICKER_ARCHETYPES)


def _interactive_archetype_picker() -> str:
    """Show an interactive archetype picker menu. Returns the selected archetype name."""
    print(_ARCHETYPE_PICKER_MENU)
    prompt = "  Enter number or archetype name: "
    max_attempts = 3
    for attempt in range(max_attempts):
        raw = input(prompt).strip()
        # Try as a number
        try:
            num = int(raw)
            if 1 <= num <= len(_PICKER_ARCHETYPES):
                return _PICKER_ARCHETYPES[num - 1]
        except ValueError:
            pass
        # Try as a name
        if raw.lower() in _PICKER_VALID_NAMES:
            return raw.lower()
        # Invalid — update prompt for retry
        if attempt < max_attempts - 1:
            prompt = "  Invalid selection. Enter a number (1\u201313) or an archetype name: "
        else:
            print("No archetype selected.", file=sys.stderr)
            sys.exit(1)
    # Should not reach here, but safety fallback
    print("No archetype selected.", file=sys.stderr)
    sys.exit(1)


def _cmd_birth(args: argparse.Namespace) -> None:
    try:
        from nomotic.telemetry import get_telemetry
        get_telemetry().record_cli_command("birth")
    except Exception:
        pass
    # Load config defaults
    config = _load_nomotic_config(args.base_dir)

    # Resolve name from --name or --agent-id (backward compat)
    agent_name = args.name or getattr(args, "agent_id_compat", None)
    if not agent_name:
        print("Error: --name is required.", file=sys.stderr)
        sys.exit(1)
    args.name = agent_name

    # Merge config defaults with CLI args
    org_raw = args.org or config.get("organization", "")
    owner = args.owner or config.get("owner", "")
    zone_raw = args.zone or config.get("default_zone", "global")

    # ── Interactive archetype picker ──────────────────────────────────
    if args.archetype:
        archetype_raw = args.archetype
    elif sys.stdin.isatty():
        archetype_raw = _interactive_archetype_picker()
    else:
        print("Error: --archetype required in non-interactive mode.", file=sys.stderr)
        sys.exit(1)

    # First-run guard: need at least an org
    if not org_raw:
        print("Nomotic is not configured yet.", file=sys.stderr)
        print("  Run 'nomotic setup' first, or provide --org.", file=sys.stderr)
        sys.exit(1)

    # Normalize zone, org, archetype
    org = _normalize_org_name(org_raw)
    zone_path = zone_raw.lower()
    archetype = archetype_raw.lower()

    try:
        from nomotic.telemetry import get_telemetry
        get_telemetry().record_archetype(archetype)
    except Exception:
        pass

    ca, store = _build_ca(args.base_dir)
    arch_reg, zone_val, _org_reg = _build_registries(args.base_dir)

    # Load or create the AgentIdRegistry
    registry = _load_registry(args.base_dir)

    # Check for duplicate active name within the same org via registry
    # Case-insensitive name comparison
    existing = registry.list_all(status="ACTIVE")
    for entry in existing:
        if entry["name"].lower() == args.name.lower() and entry["organization"] == org:
            print(f"Error: An active agent named '{args.name}' already exists in org '{org}'.", file=sys.stderr)
            print(f"  ID: {entry['agent_id']}, Certificate: {entry['certificate_id']}", file=sys.stderr)
            print("  Use a different --name, or revoke the existing agent first.", file=sys.stderr)
            sys.exit(1)

    # Validate archetype
    arch_result = arch_reg.validate(archetype)
    if not arch_result.valid:
        msg = f"Invalid archetype '{archetype}': {'; '.join(arch_result.errors)}"
        if arch_result.suggestion:
            msg += f"\n  Did you mean '{arch_result.suggestion}'?"
        print(msg, file=sys.stderr)
        sys.exit(1)
    if arch_result.warnings:
        for w in arch_result.warnings:
            print(f"  Warning: {w}", file=sys.stderr)
        if arch_result.suggestion:
            print(f"  Did you mean '{arch_result.suggestion}'?", file=sys.stderr)

    # Validate zone (after normalization)
    zone_result = zone_val.validate(zone_path)
    if not zone_result.valid:
        error = zone_result.errors[0] if zone_result.errors else "Invalid zone format"
        print(f"Invalid zone '{zone_path}': {error}", file=sys.stderr)
        print("  Zones use lowercase with slashes: global, us/production, eu/staging", file=sys.stderr)
        sys.exit(1)

    # ── Auto-compliance-preset from archetype ────────────────────────
    preset_name = getattr(args, "preset", None)
    governance_config = None
    if preset_name is None:
        # Auto-detect preset from archetype
        auto_preset = ARCHETYPE_PRESET_MAP.get(archetype, "strict")
        preset_obj = get_preset(auto_preset)
        governance_config = {
            "preset": auto_preset,
            "dimension_weights": dict(preset_obj.dimension_weights),
            "allow_threshold": preset_obj.allow_threshold,
            "deny_threshold": preset_obj.deny_threshold,
        }
        print(f"  Applying preset: {auto_preset} (from archetype {archetype})")
        print("  Override with --preset to use a different preset.")
    else:
        # Explicit --preset passed: validate and use it
        canonical_names = get_preset_names()
        lower_map = {n.lower(): n for n in canonical_names}
        key = preset_name.lower()
        if key not in lower_map:
            print(f"Error: Unknown preset '{preset_name}'. Available: {', '.join(canonical_names)}", file=sys.stderr)
            sys.exit(1)
        resolved_preset = lower_map[key]
        preset_obj = get_preset(resolved_preset)
        governance_config = {
            "preset": resolved_preset,
            "dimension_weights": dict(preset_obj.dimension_weights),
            "allow_threshold": preset_obj.allow_threshold,
            "deny_threshold": preset_obj.deny_threshold,
        }

    # Allocate sequential numeric ID
    numeric_id = registry.next_id()

    # Build model provenance if any model flags are provided
    model_provenance = None
    mp_provider = getattr(args, "model_provider", None)
    mp_name = getattr(args, "model_name", None)
    mp_version = getattr(args, "model_version", None)
    if mp_provider or mp_name or mp_version:
        if not (mp_provider and mp_name and mp_version):
            print(
                "Error: --model-provider, --model-name, and --model-version "
                "are all required when specifying model provenance.",
                file=sys.stderr,
            )
            sys.exit(1)
        known_lims = []
        raw_lims = getattr(args, "known_limitations", None)
        if raw_lims:
            known_lims = [s.strip() for s in raw_lims.split(",") if s.strip()]
        model_provenance = ModelProvenance(
            model_provider=mp_provider,
            model_name=mp_name,
            model_version=mp_version,
            model_hash=getattr(args, "model_hash", None),
            safety_evaluation_id=getattr(args, "safety_eval", None),
            known_limitations=known_lims,
        )

    cert, agent_sk = ca.issue(
        agent_id=args.name,
        archetype=archetype,
        organization=org,
        zone_path=zone_path,
        owner=owner,
        model_provenance=model_provenance,
        governance_config=governance_config,
    )

    # Set numeric ID on certificate and re-save
    cert.agent_numeric_id = numeric_id
    store.update(cert)

    # Register in the ID registry
    registry.register(numeric_id, args.name, cert.certificate_id, org)

    # Save agent keys alongside certificate
    store.save_agent_key(cert.certificate_id, agent_sk.to_bytes())
    store.save_agent_pub(cert.certificate_id, cert.public_key)

    print()
    print(f"Agent created: {_bold(args.name)}")
    if cert.agent_numeric_id:
        print(f"  ID:          {cert.agent_numeric_id}")
    print(f"  Name:        {cert.agent_id}")
    print(f"  Certificate: {cert.certificate_id}")
    print(f"  Archetype:   {archetype}")
    print(f"  Org:         {org}")
    print(f"  Zone:        {zone_path}")
    print(f"  Owner:       {owner}")
    print(f"  Trust:       {cert.trust_score:.2f}")
    print(f"  Status:      {cert.status.name}")
    if cert.model_provenance:
        mp = cert.model_provenance
        print(f"  Model:       {mp.model_provider}/{mp.model_name} (v{mp.model_version})")
        print(f"  Provenance:  {mp.provenance_hash[:16]}...")

    # Prompt to set archetype if they didn't specify one
    if not args.archetype:
        print()
        print("  Archetype defaulted to 'general-purpose'.")
        print(f"  Set a specific archetype with: nomotic archetype set {args.name}")

    # Next steps
    print()
    print("  Next steps:")
    print(f"    nomotic scope {args.name} set --actions read,write --boundaries my_db")
    print(f"    nomotic test {args.name} --action read --target my_db")


# ── nomotic init ─────────────────────────────────────────────────────────


def _issue_certificate_for_init(
    name: str,
    archetype: str,
    org: str | None,
    owner: str | None,
    zone: str,
    base_dir: Path,
) -> tuple:
    """Issue an agent certificate, reusing the core logic from _cmd_birth.

    Returns (cert, agent_sk) tuple.
    """
    ca, store = _build_ca(base_dir)
    registry = _load_registry(base_dir)
    numeric_id = registry.next_id()

    preset_name = ARCHETYPE_PRESET_MAP.get(archetype, "strict")
    preset_obj = get_preset(preset_name)
    governance_config = {
        "preset": preset_name,
        "dimension_weights": dict(preset_obj.dimension_weights),
        "allow_threshold": preset_obj.allow_threshold,
        "deny_threshold": preset_obj.deny_threshold,
    }

    cert, agent_sk = ca.issue(
        agent_id=name,
        archetype=archetype,
        organization=org or "unset",
        zone_path=zone,
        owner=owner or "",
        governance_config=governance_config,
    )

    cert.agent_numeric_id = numeric_id
    store.update(cert)
    registry.register(numeric_id, name, cert.certificate_id, org or "unset")
    store.save_agent_key(cert.certificate_id, agent_sk.to_bytes())
    store.save_agent_pub(cert.certificate_id, cert.public_key)

    return cert, agent_sk


def generate_nomotic_yaml(
    name: str,
    archetype: str,
    preset: str,
    org: str | None,
    zone: str,
    weight_hints: dict[str, float],
) -> str:
    """Return a valid, heavily commented nomotic.yaml string."""
    weight_hint_block = ""
    if weight_hints:
        weight_hint_block = "  # Recommended weight adjustments for this archetype:\n"
        for dim, delta in weight_hints.items():
            sign = "+" if delta >= 0 else ""
            weight_hint_block += (
                f"  # {dim}: {{default {sign}{delta:.1f}}}  "
                f"# {sign}{delta:.1f} recommended for {archetype}\n"
            )

    return f"""\
# nomotic.yaml — Governance configuration for {name}
# Generated by nomotic init. Edit freely.
# Full reference: https://docs.nomotic.ai/configuration

agent:
  name: {name}
  # Archetype sets behavioral priors, dimension weights, and compliance preset.
  # Available archetypes: https://docs.nomotic.ai/archetypes
  archetype: {archetype}
  organization: {org or "your-organization"}
  zone: {zone}
  # owner: your-email@example.com  # Uncomment and set

compliance:
  # Preset auto-applied from archetype. Override here if needed.
  # Options: hipaa_aligned, soc2_aligned, ultra_strict, strict, standard
  preset: {preset}

# dimension_weights:
{weight_hint_block}\
  # Uncomment and adjust to override archetype defaults.
  # Full dimension list: https://docs.nomotic.ai/dimensions

governance:
  # Trust thresholds — actions below low_threshold are denied,
  # between low and high trigger escalation (human review).
  # trust_low_threshold: 0.35   # default from archetype
  # trust_high_threshold: 0.65  # default from archetype

  # Budget gate — maximum cost per action (optional)
  # budget_per_action: 1.00

  # Interrupt authority — halt irreversible actions below this trust score
  # interrupt_threshold: 0.30
"""


def generate_hello_script(archetype: str, framework: str | None) -> str:
    """Return a hello_nomotic.py that demonstrates 5 governance scenarios."""
    action_vocab = {
        "healthcare-agent":    ("read",    "patient_records",    "billing_system"),
        "financial-analyst":   ("execute", "market_trade",       "risk_model"),
        "security-monitor":    ("scan",    "network_segment",    "threat_database"),
        "sales-agent":         ("send",    "customer_email",     "crm_record"),
        "legal-assistant":     ("read",    "case_files",         "court_database"),
        "fraud-detection":     ("analyze", "transaction_data",   "customer_account"),
    }.get(archetype, ("read", "data_source", "external_api"))

    allowed_action, allowed_target, deny_target = action_vocab

    generic_script = f'''\
"""
hello_nomotic.py — Generated by nomotic init
Demonstrates 5 governance scenarios for {archetype} agents.
Run: python hello_nomotic.py
"""

from nomotic import GovernanceRuntime, RuntimeConfig
from nomotic.store import MemoryCertificateStore
from nomotic.certificate import CertificateAuthority
from nomotic.keys import SigningKey
from nomotic.types import Action, AgentContext, TrustProfile


# ── Setup ──────────────────────────────────────────────────────────────────

store = MemoryCertificateStore()
issuer_sk, issuer_vk = SigningKey.generate()
ca = CertificateAuthority("demo-issuer", issuer_sk, store)

cert, agent_sk = ca.issue(
    agent_id="demo-agent",
    archetype="{archetype}",
    organization="demo-org",
    zone_path="demo/local",
    owner="demo@example.com",
)

runtime = GovernanceRuntime(
    RuntimeConfig(org_id="demo-org"),
    certificate_store=store
)


def evaluate(action_type, target, trust=0.65, label=""):
    action = Action(type=action_type, target=target,
                    parameters={{}}, reversible=True)
    ctx = AgentContext(
        agent_id="demo-agent",
        certificate_id=cert.certificate_id,
        trust_profile=TrustProfile(score=trust),
        zone_path="demo/local",
        archetype="{archetype}",
    )
    result = runtime.evaluate(action, ctx)
    tag = f"[{{result.verdict.name:<8}}] UCS {{result.ucs_score:.2f}}"
    print(f"  {{tag}}  {{label or f'{{action_type}} {{target}}'}}")
    return result


print()
print("Nomotic Governance Demo — {archetype}")
print("=" * 50)
print()

# Scenario 1: ALLOW — normal operation
print("1. Normal operation (ALLOW expected)")
evaluate("{allowed_action}", "{allowed_target}", trust=0.70)
print()

# Scenario 2: DENY — scope violation
print("2. Out-of-scope action (DENY expected)")
evaluate("{allowed_action}", "{deny_target}__out_of_scope", trust=0.70)
print()

# Scenario 3: ESCALATE — low trust, deliberation range
print("3. Action with degraded trust (ESCALATE expected)")
evaluate("{allowed_action}", "{allowed_target}", trust=0.45)
print()

# Scenario 4: Trust building across multiple successes
print("4. Trust recovery — 5 successive clean actions")
for i in range(5):
    evaluate("{allowed_action}", "{allowed_target}",
             trust=0.50 + (i * 0.04), label=f"recovery step {{i+1}}")
print()

# Scenario 5: Interrupt — irreversible action below interrupt threshold
print("5. Irreversible action at low trust (BLOCK / interrupt expected)")
action = Action(type="delete", target="{allowed_target}__permanent",
                parameters={{}}, reversible=False)
ctx = AgentContext(
    agent_id="demo-agent",
    certificate_id=cert.certificate_id,
    trust_profile=TrustProfile(score=0.25),
    zone_path="demo/local",
    archetype="{archetype}",
)
result = runtime.evaluate(action, ctx)
print(f"  [{{result.verdict.name:<8}}] UCS {{result.ucs_score:.2f}}  delete (irreversible, low trust)")
print()
print("Done. Run: nomotic serve --ui  to see these evaluations in the dashboard.")
print()
'''

    if framework == "langgraph":
        framework_note = f'''\
# LangGraph detected. To use GovernedAgent with LangGraph:
# from nomotic import GovernedAgent
# governed = GovernedAgent(runtime, cert)
# result = governed.govern_action("read", "{allowed_target}", {{}})
# if result.allowed:
#     # proceed with your LangGraph node
#     pass
#
# See: https://docs.nomotic.ai/guides/langgraph
'''
        return framework_note + "\n" + generic_script
    elif framework in ("crewai", "openai", "claude"):
        guide_url = f"https://docs.nomotic.ai/guides/{framework}"
        framework_note = f'''\
# {framework} detected. GovernedAgent integration guide:
# {guide_url}
#
'''
        return framework_note + "\n" + generic_script

    return generic_script


def _cmd_init(args: argparse.Namespace) -> None:
    """Scaffold a new governed agent project."""
    try:
        from nomotic.telemetry import get_telemetry
        get_telemetry().record_cli_command("init")
    except Exception:
        pass
    from nomotic.framework_detect import (
        FRAMEWORK_DISPLAY_NAMES,
        detect_installed_frameworks,
    )
    from nomotic.priors import ARCHETYPE_WEIGHT_HINTS

    # ── 1. Check setup has been run ────────────────────────────────────────
    config_path = args.base_dir / "config.json"
    if not config_path.exists():
        print("  Error: Nomotic is not configured yet.", file=sys.stderr)
        print("  Run: nomotic setup", file=sys.stderr)
        sys.exit(1)

    setup_config = _load_nomotic_config(args.base_dir)

    # ── 2. Get agent name ──────────────────────────────────────────────────
    name = args.name
    if not name:
        if args.no_interactive:
            print("Error: --name required with --no-interactive", file=sys.stderr)
            sys.exit(1)
        name = input("  Agent name (e.g. claims-processor): ").strip()
        if not name:
            print("Error: agent name cannot be empty", file=sys.stderr)
            sys.exit(1)

    # ── 3. Get archetype ───────────────────────────────────────────────────
    archetype = args.archetype
    if not archetype:
        if args.no_interactive:
            print("Error: --archetype required with --no-interactive", file=sys.stderr)
            sys.exit(1)
        archetype = _interactive_archetype_picker()

    archetype = archetype.lower()

    # Validate archetype
    arch_reg = ArchetypeRegistry.with_defaults()
    arch_result = arch_reg.validate(archetype)
    if not arch_result.valid:
        msg = f"Error: unknown archetype '{archetype}'"
        if arch_result.suggestion:
            msg += f"\n  Did you mean '{arch_result.suggestion}'?"
        print(msg, file=sys.stderr)
        sys.exit(1)

    # ── 4. Detect / select framework ───────────────────────────────────────
    framework = args.framework
    if not framework and not args.no_interactive:
        detected = detect_installed_frameworks()
        if detected:
            primary = detected[0]
            display = FRAMEWORK_DISPLAY_NAMES.get(primary, primary)
            try:
                response = input(
                    f"  {display} detected. Generate {display} integration? (Y/n): "
                ).strip().lower()
            except (EOFError, KeyboardInterrupt):
                response = "n"
            if response in ("", "y", "yes"):
                framework = primary

    # Record archetype and framework telemetry
    try:
        from nomotic.telemetry import get_telemetry
        get_telemetry().record_archetype(archetype)
        if framework:
            get_telemetry().record_framework_detected(framework)
    except Exception:
        pass

    # ── 5. Issue agent certificate ─────────────────────────────────────────
    print(f"\n  Creating agent certificate for '{name}'...")
    cert, _agent_sk = _issue_certificate_for_init(
        name=name,
        archetype=archetype,
        org=setup_config.get("organization"),
        owner=setup_config.get("owner"),
        zone=setup_config.get("default_zone", "default"),
        base_dir=args.base_dir,
    )

    # ── 6. Generate project files ──────────────────────────────────────────
    output_dir = Path(args.output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    # nomotic.yaml
    weight_hints = ARCHETYPE_WEIGHT_HINTS.get(archetype, {})
    preset = ARCHETYPE_PRESET_MAP.get(archetype, "strict")
    yaml_content = generate_nomotic_yaml(
        name=name,
        archetype=archetype,
        preset=preset,
        org=setup_config.get("organization"),
        zone=setup_config.get("default_zone", "default"),
        weight_hints=weight_hints,
    )
    (output_dir / "nomotic.yaml").write_text(yaml_content, encoding="utf-8")

    # hello_nomotic.py
    script_content = generate_hello_script(archetype=archetype, framework=framework)
    (output_dir / "hello_nomotic.py").write_text(script_content, encoding="utf-8")

    # .gitignore
    gitignore_path = output_dir / ".gitignore"
    gitignore_additions = (
        "\n# Nomotic private keys\n"
        "*.nomotic.key\n"
        "nomotic-private.pem\n"
        ".nomotic/private/\n"
    )
    if gitignore_path.exists():
        existing = gitignore_path.read_text(encoding="utf-8")
        if "nomotic-private.pem" not in existing:
            gitignore_path.write_text(
                existing + gitignore_additions, encoding="utf-8"
            )
    else:
        gitignore_path.write_text(gitignore_additions.lstrip(), encoding="utf-8")

    # ── 7. Print summary ──────────────────────────────────────────────────
    print()
    print(_bold(_green("  Nomotic project initialized.")))
    print()
    print(f"    Agent:     {name} ({cert.certificate_id})")
    print(f"    Archetype: {archetype}  →  {preset} preset")
    print("    Files:     nomotic.yaml, hello_nomotic.py, .gitignore")
    print()
    print(_bold("  Next steps:"))
    print()
    print(f"    {_cyan('python hello_nomotic.py')}    # Test governance")
    print(f"    {_cyan('nomotic serve --ui')}          # Open governance dashboard")
    print()


def _cmd_verify(args: argparse.Namespace) -> None:
    ca, _store = _build_ca(args.base_dir)
    cert_id = _resolve_cert_id(args.base_dir, args.cert_id)
    cert = ca.get(cert_id)
    if cert is None:
        print(f"Certificate not found: {args.cert_id}", file=sys.stderr)
        sys.exit(1)
    result = ca.verify_certificate(cert)
    if result.valid:
        print(f"VALID — {cert.certificate_id}")
        print(f"  Status: {cert.status.name}")
        print(f"  Trust:  {cert.trust_score:.3f}")
        print(f"  Age:    {cert.behavioral_age}")
    else:
        print(f"INVALID — {cert.certificate_id}")
        for issue in result.issues:
            print(f"  - {issue}")
        sys.exit(1)


def _cmd_inspect_agent(args: argparse.Namespace) -> None:
    """Inspect an agent's governance configuration and state."""
    if getattr(args, "provenance", False):
        ca, _store = _build_ca(args.base_dir)
        cert_id = _resolve_cert_id(args.base_dir, args.agent_id)
        cert = ca.get(cert_id)
        if cert is None:
            print(f"Certificate not found: {args.agent_id}", file=sys.stderr)
            sys.exit(1)
        mp = cert.model_provenance
        if mp is None:
            print("No model provenance recorded for this agent.")
            return
        print()
        print("Model Provenance")
        print(f"  Provider:        {mp.model_provider}")
        print(f"  Model:           {mp.model_name} (v{mp.model_version})")
        if mp.model_hash:
            print(f"  Model Hash:      {mp.model_hash}")
        if mp.safety_evaluation_id:
            print(f"  Safety Eval:     {mp.safety_evaluation_id}")
        if mp.known_limitations:
            print(f"  Known Limits:    {', '.join(mp.known_limitations)}")
        print(f"  Provenance Hash: {mp.provenance_hash[:16]}...")
        # Verify provenance hash matches
        expected = mp.compute_hash()
        if expected == mp.provenance_hash:
            print("  Bound to cert:   VERIFIED \u2713")
        else:
            print("  Bound to cert:   MISMATCH \u2717")
        print()
        return

    if getattr(args, "raw", False):
        # Raw JSON cert dump (formerly _cmd_inspect)
        ca, _store = _build_ca(args.base_dir)
        cert_id = _resolve_cert_id(args.base_dir, args.agent_id)
        cert = ca.get(cert_id)
        if cert is None:
            print(f"Certificate not found: {args.agent_id}", file=sys.stderr)
            sys.exit(1)
        print(json.dumps(cert.to_dict(), indent=2, sort_keys=True))
        return

    if getattr(args, "brief", False):
        # Quick status view (formerly _cmd_status)
        ca, _store = _build_ca(args.base_dir)
        cert_id = _resolve_cert_id(args.base_dir, args.agent_id)
        cert = ca.get(cert_id)
        if cert is None:
            print(f"Certificate not found: {cert_id}", file=sys.stderr)
            sys.exit(1)

        # Status color
        if cert.status.name == "ACTIVE":
            status_display = _green(cert.status.name)
        elif cert.status.name == "SUSPENDED":
            status_display = _yellow(cert.status.name)
        else:
            status_display = _red(cert.status.name)

        # Trust color
        trust = cert.trust_score
        if trust >= 0.5:
            trust_display = _green(f"{trust:.3f}")
        elif trust >= 0.3:
            trust_display = _yellow(f"{trust:.3f}")
        else:
            trust_display = _red(f"{trust:.3f}")

        print()
        print(f"  {_bold(cert.agent_id)}")
        print(f"  {'─' * 40}")
        print(f"  Status:    {status_display}")
        print(f"  Trust:     {trust_display}")
        print(f"  Archetype: {cert.archetype}")
        print(f"  Org:       {cert.organization}")
        print(f"  Zone:      {cert.zone_path}")
        print(f"  Owner:     {cert.owner}")
        print(f"  Issued:    {cert.issued_at.strftime('%Y-%m-%d %H:%M')}")
        print(f"  Cert:      {cert.certificate_id}")
        print()
        return

    # Default: comprehensive view (formerly _cmd_config display logic)
    from nomotic.sandbox import load_agent_config

    agent_id = args.agent_id

    # Resolve agent identifier
    try:
        _numeric_id, resolved_name, cert_id = _resolve_agent(args.base_dir, agent_id)
        agent_id = resolved_name
    except SystemExit:
        cert_id = None

    # Try to load certificate info
    ca, _store = _build_ca(args.base_dir)
    if cert_id is None:
        from nomotic.sandbox import find_agent_cert_id
        cert_id = find_agent_cert_id(args.base_dir, agent_id)
    cert = ca.get(cert_id) if cert_id else None

    # Load governance config
    config = load_agent_config(args.base_dir, agent_id)

    print()
    print(_bold(f"  Governance Configuration: {agent_id}"))
    print(f"  {'=' * 50}")
    print()

    # Certificate info
    if cert:
        print(_bold("  Identity:"))
        print(f"    Certificate: {cert.certificate_id}")
        print(f"    Archetype:   {cert.archetype}")
        print(f"    Org:         {cert.organization}")
        print(f"    Zone:        {cert.zone_path}")
        print(f"    Owner:       {cert.owner}")
        print(f"    Trust:       {cert.trust_score}")
        print(f"    Status:      {cert.status.name}")
        print()
    else:
        print(_bold("  Identity:"))
        print(f"    No certificate found for '{agent_id}'")
        print()

    if config is None:
        print(_bold("  Authority:"))
        print("    No governance configuration found.")
        print(f"    Use 'nomotic scope set {agent_id} --actions ...' to configure.")
        print()
        return

    # Scope
    print(_bold("  Authority:"))
    if config.actions:
        print(f"    Allowed actions: {', '.join(config.actions)}")
    else:
        print("    Allowed actions: (not configured)")
    print()

    # Boundaries
    print(_bold("  Boundaries:"))
    if config.boundaries:
        for b in config.boundaries:
            print(f"    {_green(chr(10003))} {b}")
    else:
        print("    (not configured)")
    print()

    # Ethical rules
    print(_bold("  Ethical Rules:"))
    if config.ethical_rules:
        for i, rule in enumerate(config.ethical_rules, 1):
            print(f"    [{i}] {_yellow('VETO')} if: {rule.condition}")
            print(f"        Message: \"{rule.message}\"")
    else:
        print("    (none)")
    print()

    # Human override rules
    print(_bold("  Human Override Rules:"))
    if config.human_overrides:
        for i, ho in enumerate(config.human_overrides, 1):
            print(f"    [{i}] Action '{_red(ho.action)}' requires human approval")
            print(f"        Message: \"{ho.message}\"")
    else:
        print("    (none)")
    print()


def _cmd_suspend(args: argparse.Namespace) -> None:
    ca, _store = _build_ca(args.base_dir)
    numeric_id, _name, cert_id = _resolve_agent(args.base_dir, args.cert_id)
    try:
        cert = ca.suspend(cert_id, args.reason)
    except (KeyError, ValueError) as exc:
        print(str(exc), file=sys.stderr)
        sys.exit(1)
    # Update registry status
    if numeric_id > 0:
        registry = _load_registry(args.base_dir)
        try:
            registry.update_status(numeric_id, "SUSPENDED")
        except KeyError:
            pass
    print(f"Suspended: {cert.certificate_id}")


def _cmd_reactivate(args: argparse.Namespace) -> None:
    ca, _store = _build_ca(args.base_dir)
    numeric_id, _name, cert_id = _resolve_agent(args.base_dir, args.cert_id)
    try:
        cert = ca.reactivate(cert_id)
    except (KeyError, ValueError) as exc:
        print(str(exc), file=sys.stderr)
        sys.exit(1)
    # Update registry status
    if numeric_id > 0:
        registry = _load_registry(args.base_dir)
        try:
            registry.update_status(numeric_id, "ACTIVE")
        except KeyError:
            pass
    print(f"Reactivated: {cert.certificate_id}")


def _cmd_revoke(args: argparse.Namespace) -> None:
    ca, _store = _build_ca(args.base_dir)
    numeric_id, name, cert_id = _resolve_agent(args.base_dir, args.cert_id)
    try:
        cert = ca.revoke(cert_id, args.reason)
    except (KeyError, ValueError) as exc:
        print(str(exc), file=sys.stderr)
        sys.exit(1)

    # Update registry status
    registry = _load_registry(args.base_dir)
    now_iso = datetime.now(timezone.utc).isoformat()
    if numeric_id > 0:
        try:
            registry.update_status(numeric_id, "REVOKED", revoked_at=now_iso)
        except KeyError:
            pass

    # Seal the persistent audit trail
    from nomotic.audit_store import AuditStore
    audit_store = AuditStore(args.base_dir)
    seal_hash = audit_store.seal(name)
    audit_summary = audit_store.summary(name)

    # Build audit_records list for the revocation seal
    audit_records = None
    all_records = audit_store.query_all(name)
    if all_records:
        audit_records = [r.to_dict() for r in all_records]

    # Create revocation seal
    from nomotic.revocation import create_revocation_seal
    create_revocation_seal(
        args.base_dir,
        agent_id=numeric_id,
        agent_name=name,
        certificate_id=cert_id,
        reason=args.reason,
        cert=cert,
        audit_records=audit_records,
    )

    total_evals = audit_summary.get("total", 0)
    print()
    print(f"Revoked: {cert.certificate_id}")
    print()
    print(f"Agent revoked: {_bold(name)}")
    print(f"  Certificate: {cert.certificate_id}")
    print(f"  Status:      {_red('REVOKED')}")
    print(f"  Reason:      {args.reason}")
    print(f"  Audit sealed: {seal_hash} ({total_evals} records)")
    print()
    print("  This agent's complete history is preserved and cannot be modified.")
    print(f"  View with: nomotic history {name}")
    print()


def _cmd_renew(args: argparse.Namespace) -> None:
    ca, store = _build_ca(args.base_dir)
    cert_id = _resolve_cert_id(args.base_dir, args.cert_id)
    try:
        cert, agent_sk = ca.renew(cert_id)
    except KeyError as exc:
        print(str(exc), file=sys.stderr)
        sys.exit(1)
    store.save_agent_key(cert.certificate_id, agent_sk.to_bytes())
    store.save_agent_pub(cert.certificate_id, cert.public_key)
    print(f"Renewed: {cert.certificate_id}")
    print(f"  Lineage: {cert.lineage}")


def _cmd_list(args: argparse.Namespace) -> None:
    ca, _store = _build_ca(args.base_dir)
    status_filter = CertStatus[args.status.upper()] if args.status else None

    # Special handling for REVOKED status — show from revocation records
    if status_filter == CertStatus.REVOKED:
        registry = _load_registry(args.base_dir)
        revoked_agents = registry.list_all(status="REVOKED", org=args.org)
        if not revoked_agents:
            print("No revoked agents found.")
            return

        print()
        print("Revoked Agents:")
        print()
        print(f"  {'ID':<6}{'Name':<14}{'Org':<17}{'Revoked':<13}{'Reason'}")
        print(f"  {'─' * 4}  {'─' * 12}  {'─' * 15}  {'─' * 11}  {'─' * 23}")
        for agent in revoked_agents:
            revoked_at = agent.get("revoked_at", "")
            if revoked_at:
                revoked_date = revoked_at[:10]
            else:
                revoked_date = "unknown"
            # Load reason from revocation seal if available
            reason = ""
            seal_path = args.base_dir / "revocations" / f"{agent['agent_id']}.json"
            if seal_path.exists():
                try:
                    seal = json.loads(seal_path.read_text(encoding="utf-8"))
                    reason = seal.get("reason", "")
                except (json.JSONDecodeError, KeyError):
                    pass
            print(f"  {agent['agent_id']:<6}{agent['name']:<14}{agent['organization']:<17}{revoked_date:<13}{reason}")
        print()
        return

    certs = ca.list(org=args.org, status=status_filter, archetype=args.archetype)
    if not certs:
        print("No certificates found.")
        return

    # Load registry for numeric IDs
    registry = _load_registry(args.base_dir)

    for cert in certs:
        nid = cert.agent_numeric_id
        if nid == 0:
            # Try to find in registry
            matches = registry.resolve(cert.agent_id)
            if matches:
                nid = matches[0]["agent_id"]
        id_str = str(nid) if nid > 0 else "?"
        print(
            f"  {id_str:<6}{cert.agent_id:20s}  {cert.status.name:10s}"
            f"  trust={cert.trust_score:.2f}  age={cert.behavioral_age}"
            f"  cert={cert.certificate_id}"
        )


def _cmd_reputation(args: argparse.Namespace) -> None:
    ca, _store = _build_ca(args.base_dir)
    cert_id = _resolve_cert_id(args.base_dir, args.cert_id)
    cert = ca.get(cert_id)
    if cert is None:
        print(f"Certificate not found: {cert_id}", file=sys.stderr)
        sys.exit(1)

    trust = cert.trust_score
    age = cert.behavioral_age

    # Estimate violation/success counts from behavioral age and trust
    # Trust starts at 0.500 and moves asymmetrically (violations cost 5x).
    # We estimate based on age and current trust trajectory.
    if age > 0:
        # Rough heuristic: each success adds ~0.002, each violation costs ~0.010
        # Solve: successful * 0.002 - violations * 0.010 = trust - 0.500
        #        successful + violations = age
        delta = trust - 0.500
        # violations ≈ (age * 0.002 - delta) / 0.012
        est_violations = max(0, int((age * 0.002 - delta) / 0.012))
        est_successful = max(0, age - est_violations)
    else:
        est_violations = 0
        est_successful = 0

    total = est_successful + est_violations
    violation_rate = (est_violations / total * 100) if total > 0 else 0.0

    # Trust color
    if trust >= 0.5:
        trust_display = _green(f"{trust:.3f}")
    elif trust >= 0.3:
        trust_display = _yellow(f"{trust:.3f}")
    else:
        trust_display = _red(f"{trust:.3f}")

    # Status color
    if cert.status.name == "ACTIVE":
        status_display = _green(cert.status.name)
    elif cert.status.name == "SUSPENDED":
        status_display = _yellow(cert.status.name)
    else:
        status_display = _red(cert.status.name)

    print()
    print(f"  Reputation: {_bold(cert.agent_id)}")
    print()
    print(f"    Trust Score:        {trust_display}")
    print(f"    Behavioral Age:     {age}")
    print(f"    Violation Count:    {est_violations}")
    print(f"    Successful Actions: {est_successful}")
    print(f"    Violation Rate:     {violation_rate:.1f}%")
    print(f"    Status:             {status_display}")
    print()

    # Trust trajectory
    start_trust = 0.500
    trend = "stable"
    if trust > start_trust + 0.02:
        trend = "rising"
    elif trust < start_trust - 0.02:
        trend = "falling"

    print("    Trust Trajectory:")
    print(f"      Started at {start_trust:.3f} on {cert.issued_at.strftime('%Y-%m-%d')}")
    print(f"      Current:   {trust:.3f}")
    print(f"      Trend:     {trend}")
    print()


def _cmd_export(args: argparse.Namespace) -> None:
    ca, _store = _build_ca(args.base_dir)
    cert_id = _resolve_cert_id(args.base_dir, args.cert_id)
    cert = ca.get(cert_id)
    if cert is None:
        print(f"Certificate not found: {args.cert_id}", file=sys.stderr)
        sys.exit(1)
    # Export public certificate (no private key)
    filename = f"{cert.certificate_id}.cert.json"
    Path(filename).write_text(
        json.dumps(cert.to_dict(), indent=2, sort_keys=True),
        encoding="utf-8",
    )
    print(f"Exported to {filename}")


# ── Archetype commands ───────────────────────────────────────────────────


def _cmd_archetype(args: argparse.Namespace) -> None:
    arch_reg = ArchetypeRegistry.with_defaults()
    sub = args.archetype_command

    if sub == "list":
        archetypes = arch_reg.list(category=args.category)
        if not archetypes:
            print("No archetypes found.")
            return

        # Group by category
        from collections import defaultdict
        by_category: dict[str, list] = defaultdict(list)
        for a in archetypes:
            by_category[a.category].append(a)

        # Find max name length for alignment
        max_name = max(len(a.name) for a in archetypes)

        print()
        print("Archetypes:")
        for cat in sorted(by_category.keys()):
            print()
            print(f"  {_bold(cat)}")
            for a in sorted(by_category[cat], key=lambda x: x.name):
                print(f"    {a.name:<{max_name + 2}}{a.description}")

    elif sub == "register":
        try:
            defn = arch_reg.register(args.name, args.description, args.category)
        except ValueError as exc:
            print(str(exc), file=sys.stderr)
            sys.exit(1)
        print(f"Registered archetype: {defn.name}")

    elif sub == "validate":
        result = arch_reg.validate(args.name)
        if result.valid:
            print(f"VALID: {result.name}")
            for w in result.warnings:
                print(f"  Warning: {w}")
            if result.suggestion:
                print(f"  Suggestion: {result.suggestion}")
        else:
            print(f"INVALID: {result.name}")
            for e in result.errors:
                print(f"  Error: {e}")
            if result.suggestion:
                print(f"  Did you mean '{result.suggestion}'?")
            sys.exit(1)

    elif sub == "set":
        _cmd_archetype_set(args)

    elif sub == "browse":
        _handle_archetype_browse(args)

    elif sub == "pull":
        _handle_archetype_pull(args)

    elif sub == "info":
        _handle_archetype_info(args)

    else:
        print("Unknown archetype subcommand", file=sys.stderr)
        sys.exit(1)


def _handle_archetype_browse(args: argparse.Namespace) -> None:
    """Browse community archetypes from the registry."""
    from nomotic.marketplace import ArchetypeMarketplace, MarketplaceConnectionError

    marketplace = ArchetypeMarketplace()
    try:
        entries = marketplace.fetch_index()
    except MarketplaceConnectionError as exc:
        print(
            "\n  Could not reach archetype registry."
            " Check your network connection."
        )
        print(f"  ({exc})")
        return

    if args.search:
        q = args.search.lower()
        entries = [
            e
            for e in entries
            if q in e.name.lower() or q in e.description.lower()
        ]

    if not entries:
        print("  No archetypes found.")
        return

    print(
        f"\n  {'NAME':<24} {'RESOLVES TO':<22} {'AUTHOR':<16}"
        f" {'VER':<8} DESCRIPTION"
    )
    print(
        f"  {'-' * 24} {'-' * 22} {'-' * 16} {'-' * 8} {'-' * 30}"
    )
    for e in entries:
        desc = (
            e.description[:35] + "..."
            if len(e.description) > 35
            else e.description
        )
        print(
            f"  {e.name:<24} {e.resolves_to:<22}"
            f" {e.author:<16} {e.version:<8} {desc}"
        )
    print()


def _handle_archetype_pull(args: argparse.Namespace) -> None:
    """Download and install a community archetype."""
    from nomotic.marketplace import (
        ArchetypeMarketplace,
        ArchetypeValidationError,
        MarketplaceConnectionError,
    )

    marketplace = ArchetypeMarketplace()
    try:
        arch = marketplace.fetch_archetype(args.name)
        marketplace.validate_archetype(arch)
    except MarketplaceConnectionError as exc:
        print(f"  Error: {exc}", file=sys.stderr)
        sys.exit(1)
    except ArchetypeValidationError as exc:
        print(f"  Validation failed:\n{exc}", file=sys.stderr)
        sys.exit(1)

    print(f"\n  Archetype: {arch.name}  ({arch.resolves_to})")
    print(f"  Author:    {arch.author}")
    print(f"  License:   {arch.license}")
    print(f"  {arch.description}")

    if not args.yes:
        confirm = input("\n  Install this archetype? (y/N): ").strip().lower()
        if confirm not in ("y", "yes"):
            print("  Cancelled.")
            return

    path = marketplace.install_archetype(arch)
    print(f"  Installed: {path}")
    print(f"  Use with:  --archetype {arch.name}")


def _handle_archetype_info(args: argparse.Namespace) -> None:
    """Show archetype details before installing."""
    from nomotic.marketplace import (
        ArchetypeMarketplace,
        ArchetypeValidationError,
        MarketplaceConnectionError,
    )

    marketplace = ArchetypeMarketplace()
    try:
        arch = marketplace.fetch_archetype(args.name)
    except (MarketplaceConnectionError, ArchetypeValidationError) as exc:
        print(f"  Error: {exc}", file=sys.stderr)
        sys.exit(1)

    print(f"\n  Name:        {arch.name}")
    print(f"  Version:     {arch.version}")
    print(f"  Resolves to: {arch.resolves_to}")
    print(f"  Author:      {arch.author}")
    print(f"  License:     {arch.license}")
    print(f"  Description: {arch.description}")
    print("  Use cases:")
    for u in arch.use_cases:
        print(f"    - {u}")
    print("  Weight overrides:")
    for k, v in arch.weight_overrides.items():
        print(f"    {k}: {v}")
    print()


def _cmd_archetype_set(args: argparse.Namespace) -> None:
    """Interactive archetype selection for an agent."""
    agent_identifier = args.agent_identifier

    # Resolve agent
    _numeric_id, _name, cert_id = _resolve_agent(args.base_dir, agent_identifier)

    arch_reg = ArchetypeRegistry.with_defaults()
    archetypes = arch_reg.list()

    # Group by category
    by_category: dict[str, list] = {}
    for a in archetypes:
        cat = a.category or "uncategorized"
        by_category.setdefault(cat, []).append(a)

    # Display numbered list
    print()
    print(f"  Select an archetype for {_bold(agent_identifier)}:")
    print()

    numbered = []
    idx = 1
    for cat in sorted(by_category.keys()):
        print(f"  {_bold(cat)}")
        for a in sorted(by_category[cat], key=lambda x: x.name):
            print(f"    {idx:2d}. {a.name:28s} {a.description}")
            numbered.append(a)
            idx += 1
        print()

    # Get selection
    while True:
        choice = input("  Enter number (or 'skip' to keep current): ").strip()
        if choice.lower() == "skip":
            print("  Archetype unchanged.")
            return
        try:
            num = int(choice)
            if 1 <= num <= len(numbered):
                selected = numbered[num - 1]
                break
            print(f"  Please enter a number between 1 and {len(numbered)}.")
        except ValueError:
            print("  Please enter a number or 'skip'.")

    # Update the certificate's archetype
    ca, store = _build_ca(args.base_dir)
    cert = ca.get(cert_id)
    if cert is None:
        print("Certificate not found.", file=sys.stderr)
        sys.exit(1)

    cert.archetype = selected.name
    store.update(cert)

    print(f"  Archetype set to '{_green(selected.name)}' for {agent_identifier}.")
    print()


# ── Organization commands ────────────────────────────────────────────────


def _cmd_org(args: argparse.Namespace) -> None:
    _arch_reg, _zone_val, org_reg = _build_registries(args.base_dir)
    sub = args.org_command

    if sub == "register":
        sk, vk, _issuer_id = _load_or_create_issuer(args.base_dir)
        try:
            org = org_reg.register(
                args.name,
                vk.fingerprint(),
                contact_email=getattr(args, "email", None),
            )
        except ValueError as exc:
            print(str(exc), file=sys.stderr)
            sys.exit(1)
        print(f"Registered organization: {org.name}")
        print(f"  Display name: {org.display_name}")
        print(f"  Issuer:       {org.issuer_fingerprint}")

    elif sub == "list":
        status_str = getattr(args, "status", None)
        status = OrgStatus[status_str.upper()] if status_str else None
        orgs = org_reg.list(status=status)
        if not orgs:
            print("No organizations found.")
            return
        for org in orgs:
            print(f"  {org.name:30s}  {org.status.name:10s}  {org.display_name}")

    elif sub == "validate":
        result = org_reg.validate(args.name)
        if result.valid:
            print(f"VALID: {result.name} (available)")
        else:
            print(f"INVALID: {result.name}")
            for e in result.errors:
                print(f"  Error: {e}")
            sys.exit(1)

    else:
        print("Unknown org subcommand", file=sys.stderr)
        sys.exit(1)


# ── Zone commands ────────────────────────────────────────────────────────


def _cmd_zone(args: argparse.Namespace) -> None:
    zone_val = ZoneValidator()
    sub = args.zone_command

    if sub == "validate":
        result = zone_val.validate(args.path)
        if result.valid:
            print(f"VALID: {result.name}")
        else:
            print(f"INVALID: {result.name}")
            for e in result.errors:
                print(f"  Error: {e}")
            sys.exit(1)

    else:
        print("Unknown zone subcommand", file=sys.stderr)
        sys.exit(1)


# ── Serve command ────────────────────────────────────────────────────────


def _cmd_hello(args: argparse.Namespace) -> None:
    """Redirect to the tutorial."""
    print("Starting the Nomotic tutorial...")
    print("  (Tip: You can also run 'nomotic tutorial' directly.)")
    print()
    _cmd_tutorial(args)


def _cmd_drift(args: argparse.Namespace) -> None:
    """Drift command dispatcher — routes to show or explain subcommands."""
    drift_cmd = getattr(args, "drift_command", None)
    if drift_cmd == "explain":
        _cmd_drift_explain(args)
        return
    if drift_cmd == "show":
        agent_id = args.agent_id
    else:
        # Backward compatibility: nomotic drift <agent_id>
        agent_id = getattr(args, "agent_id", None)
        if agent_id is None:
            print("Usage: nomotic drift <agent_id> or nomotic drift explain --agent=<id>", file=sys.stderr)
            sys.exit(1)

    _cmd_drift_show(args, agent_id)


def _cmd_drift_show(args: argparse.Namespace, agent_id: str) -> None:
    """Show the current behavioral drift for an agent (via API)."""
    import urllib.request
    import urllib.error

    base_url = f"http://{args.host}:{args.port}"
    url = f"{base_url}/v1/drift/{agent_id}"

    try:
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            print(f"No drift data for agent: {agent_id}", file=sys.stderr)
            sys.exit(1)
        print(f"API error: {exc.code} {exc.reason}", file=sys.stderr)
        sys.exit(1)
    except urllib.error.URLError as exc:
        print(f"Cannot connect to {base_url}: {exc.reason}", file=sys.stderr)
        print("Is the Nomotic API server running? (nomotic serve)", file=sys.stderr)
        sys.exit(1)

    drift = data["drift"]
    print(f"Behavioral Drift: {data['agent_id']}")
    print(f"  Overall:    {drift['overall']:.4f} ({drift['severity']})")
    print(f"  Confidence: {drift['confidence']:.2f}")
    print()
    print("  Per-distribution:")
    for name in ["action_drift", "target_drift", "temporal_drift", "outcome_drift"]:
        val = drift[name]
        bar_full = int(val * 10)
        bar = "#" * bar_full + "." * (10 - bar_full)
        label = name.replace("_drift", "").title()
        print(f"    {label:10s} {val:.2f}  {bar}")
    print()
    if drift.get("detail"):
        print(f"  Detail: {drift['detail']}")
        print()

    alerts = data.get("alerts", [])
    unacked = sum(1 for a in alerts if not a.get("acknowledged"))
    if alerts:
        print(f"  Alerts: {unacked} unacknowledged")
        for i, alert in enumerate(alerts):
            ack = " (ack)" if alert.get("acknowledged") else ""
            print(f"    [{i}] {alert['severity']}{ack} - {alert['drift_score'].get('detail', '')}")
    print()


def _cmd_drift_explain(args: argparse.Namespace) -> None:
    """Explain why drift happened — causal analysis (via API)."""
    import urllib.request
    import urllib.error

    agent_id = getattr(args, "explain_agent", None)
    alert_id = getattr(args, "explain_alert", None)

    if not agent_id and not alert_id:
        print("Specify --agent=<id> or --alert=<id>", file=sys.stderr)
        sys.exit(1)

    base_url = f"http://{args.host}:{args.port}"

    if agent_id:
        url = f"{base_url}/v1/drift/explain/{agent_id}"
    else:
        url = f"{base_url}/v1/drift/explain/alert/{alert_id}"

    try:
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            target = agent_id or alert_id
            print(f"No causal analysis available for: {target}", file=sys.stderr)
            sys.exit(1)
        print(f"API error: {exc.code} {exc.reason}", file=sys.stderr)
        sys.exit(1)
    except urllib.error.URLError as exc:
        print(f"Cannot connect to {base_url}: {exc.reason}", file=sys.stderr)
        print("Is the Nomotic API server running? (nomotic serve)", file=sys.stderr)
        sys.exit(1)

    report = data.get("causal_report", {})
    if not report:
        print("No causal analysis available.", file=sys.stderr)
        sys.exit(1)

    print(f"Drift Causal Analysis")
    print(f"  Scope:  {report.get('scope', 'unknown')}")
    print(f"  Agent:  {report.get('agent_id', 'unknown')}")

    dists = report.get("distributions_involved", [])
    if dists:
        print(f"  Distributions: {', '.join(dists)}")
    print()

    hyp = report.get("primary_hypothesis")
    if hyp:
        print(f"  Primary Hypothesis:")
        print(f"    Type:       {hyp.get('cause_type', 'unknown')}")
        print(f"    Confidence: {hyp.get('confidence', 0):.2f}")
        print(f"    {hyp.get('description', '')}")
        evidence = hyp.get("evidence", [])
        if evidence:
            print(f"    Evidence:")
            for ev in evidence:
                print(f"      - {ev}")
        print()

    alts = report.get("alternative_hypotheses", [])
    if alts:
        print(f"  Alternative Hypotheses:")
        for alt in alts:
            print(f"    - [{alt.get('confidence', 0):.2f}] {alt.get('description', '')}")
        print()

    # Correlated fields
    if report.get("affected_agents"):
        agents = report["affected_agents"]
        print(f"  Affected Agents ({len(agents)}):")
        for a in agents[:10]:
            print(f"    - {a}")
        if len(agents) > 10:
            print(f"    ... and {len(agents) - 10} more")
        print()

    # Coordinated fields
    if report.get("propagation_chain"):
        chain = report["propagation_chain"]
        print(f"  Propagation Chain: {' -> '.join(chain)}")
        print()

    if report.get("amplification_profile"):
        print(f"  Amplification Profile:")
        for entry in report["amplification_profile"]:
            print(f"    - {entry}")
        print()

    if report.get("recommended_intervention"):
        print(f"  Intervention Point: {report['recommended_intervention']}")
        print()

    # Fleet fields
    if report.get("fleet_movement_type"):
        print(f"  Fleet Movement: {report['fleet_movement_type']}")
    if report.get("contributing_groups"):
        print(f"  Contributing Groups:")
        for group, count in report["contributing_groups"].items():
            print(f"    {group}: {count} agents")
        print()

    rems = report.get("remediation", [])
    if rems:
        print(f"  Recommended Actions:")
        for i, rem in enumerate(rems, 1):
            print(f"    {i}. {rem}")
        print()


def _cmd_trajectory(args: argparse.Namespace) -> None:
    """Trajectory command dispatcher — routes to show or interventions subcommands."""
    traj_cmd = getattr(args, "trajectory_command", None)
    if traj_cmd == "show":
        _cmd_trajectory_show(args)
    elif traj_cmd == "interventions":
        _cmd_trajectory_interventions(args)
    else:
        print("Usage: nomotic trajectory show --agent=<id>", file=sys.stderr)
        print("       nomotic trajectory interventions [--agent=<id>]", file=sys.stderr)
        sys.exit(1)


def _cmd_trajectory_show(args: argparse.Namespace) -> None:
    """Show the trajectory projection for an agent (via API)."""
    import urllib.request
    import urllib.error

    agent_id = args.agent_id
    base_url = f"http://{args.host}:{args.port}"
    url = f"{base_url}/v1/trajectory/{agent_id}"

    try:
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            print(f"No trajectory projection for agent: {agent_id}", file=sys.stderr)
            sys.exit(1)
        print(f"API error: {exc.code} {exc.reason}", file=sys.stderr)
        sys.exit(1)
    except urllib.error.URLError as exc:
        print(f"Cannot connect to {base_url}: {exc.reason}", file=sys.stderr)
        print("Is the Nomotic API server running? (nomotic serve)", file=sys.stderr)
        sys.exit(1)

    proj = data.get("projection", data)
    print(f"Behavioral Trajectory: {proj.get('agent_id', agent_id)}")
    print(f"  Horizon:      {proj.get('projection_horizon', '?')} actions")
    print(f"  Risk Level:   {proj.get('risk_level', 'unknown')}")
    print(f"  Intervention: {proj.get('recommended_intervention', 'none')}")
    if proj.get("intervention_reason"):
        print(f"  Reason:       {proj['intervention_reason']}")
    print()

    inv_projs = proj.get("invariant_projections", [])
    if inv_projs:
        print("  Invariant Projections:")
        for ip in inv_projs:
            prob = ip.get("violation_probability", 0)
            margin = ip.get("current_margin", 0)
            step = ip.get("projected_violation_at", -1)
            step_str = f"step {step}" if step >= 0 else "none in horizon"
            print(f"    {ip.get('invariant_id', '?'):30s}  prob={prob:.3f}  margin={margin:.3f}  crossing={step_str}")
        print()

    pdrift = proj.get("projected_drift", {})
    if pdrift:
        print("  Projected Drift at Horizon:")
        for dist, val in pdrift.items():
            print(f"    {dist:10s} {val:.4f}")
        print()


def _cmd_trajectory_interventions(args: argparse.Namespace) -> None:
    """Show trajectory interventions (via API)."""
    import urllib.request
    import urllib.error

    base_url = f"http://{args.host}:{args.port}"
    agent_id = getattr(args, "agent_id", None)
    url = f"{base_url}/v1/trajectory/interventions"
    if agent_id:
        url += f"?agent_id={agent_id}"

    try:
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        print(f"API error: {exc.code} {exc.reason}", file=sys.stderr)
        sys.exit(1)
    except urllib.error.URLError as exc:
        print(f"Cannot connect to {base_url}: {exc.reason}", file=sys.stderr)
        print("Is the Nomotic API server running? (nomotic serve)", file=sys.stderr)
        sys.exit(1)

    interventions = data if isinstance(data, list) else data.get("interventions", [])
    if not interventions:
        print("No trajectory interventions recorded.")
        return

    print(f"Trajectory Interventions ({len(interventions)}):")
    for i, iv in enumerate(interventions):
        applied = "applied" if iv.get("applied") else "pending"
        print(f"  [{i}] {iv.get('action_type', '?'):10s}  agent={iv.get('agent_id', '?')}  ({applied})")
        print(f"       {iv.get('reason', '')}")
    print()


def _cmd_alerts(args: argparse.Namespace) -> None:
    """List drift alerts (via API)."""
    import urllib.request
    import urllib.error

    base_url = f"http://{args.host}:{args.port}"
    url = f"{base_url}/v1/alerts"
    if args.agent_id:
        url += f"?agent_id={args.agent_id}"

    try:
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        print(f"API error: {exc.code} {exc.reason}", file=sys.stderr)
        sys.exit(1)
    except urllib.error.URLError as exc:
        print(f"Cannot connect to {base_url}: {exc.reason}", file=sys.stderr)
        print("Is the Nomotic API server running? (nomotic serve)", file=sys.stderr)
        sys.exit(1)

    alerts = data.get("alerts", [])
    if args.unacknowledged:
        alerts = [a for a in alerts if not a.get("acknowledged")]

    if not alerts:
        print("No drift alerts.")
        return

    print(f"Drift Alerts ({len(alerts)} total, {data.get('unacknowledged', 0)} unacknowledged):")
    for i, alert in enumerate(alerts):
        ack = " [ack]" if alert.get("acknowledged") else ""
        agent = alert.get("agent_id", "?")
        sev = alert.get("severity", "?")
        detail = alert.get("drift_score", {}).get("detail", "")
        print(f"  [{i}] {agent:20s} {sev:10s}{ack}  {detail}")


def _cmd_fingerprint(args: argparse.Namespace) -> None:
    """Show the behavioral fingerprint for an agent (via API)."""
    import urllib.request
    import urllib.error

    base_url = f"http://{args.host}:{args.port}"
    url = f"{base_url}/v1/fingerprint/{args.agent_id}"

    try:
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            print(f"No fingerprint found for agent: {args.agent_id}", file=sys.stderr)
            sys.exit(1)
        print(f"API error: {exc.code} {exc.reason}", file=sys.stderr)
        sys.exit(1)
    except urllib.error.URLError as exc:
        print(f"Cannot connect to {base_url}: {exc.reason}", file=sys.stderr)
        print("Is the Nomotic API server running? (nomotic serve)", file=sys.stderr)
        sys.exit(1)

    print(f"Behavioral Fingerprint for {data['agent_id']}")
    print(f"  Observations: {data['total_observations']}")
    print(f"  Confidence:   {data['confidence']:.3f}")
    print()

    if data.get("action_distribution"):
        print("  Action Distribution:")
        for action_type, freq in sorted(data["action_distribution"].items(), key=lambda x: -x[1]):
            bar = "#" * int(freq * 40)
            print(f"    {action_type:20s} {freq:6.1%} {bar}")
        print()

    if data.get("target_distribution"):
        print("  Target Distribution:")
        for target, freq in sorted(data["target_distribution"].items(), key=lambda x: -x[1]):
            bar = "#" * int(freq * 40)
            print(f"    {target:20s} {freq:6.1%} {bar}")
        print()

    tp = data.get("temporal_pattern", {})
    if tp.get("active_hours"):
        print("  Temporal Pattern:")
        print(f"    Active hours: {tp['active_hours']}")
        mean = tp.get('actions_per_hour_mean', 0)
        std = tp.get('actions_per_hour_std', 0)
        print(f"    Rate: {mean:.1f} +/- {std:.1f} actions/hr")
        print()

    if data.get("outcome_distribution"):
        print("  Outcome Distribution:")
        for outcome, freq in sorted(data["outcome_distribution"].items(), key=lambda x: -x[1]):
            bar = "#" * int(freq * 40)
            print(f"    {outcome:20s} {freq:6.1%} {bar}")
        print()


def _cmd_trust(args: argparse.Namespace) -> None:
    """Show the trust report for an agent (via API)."""
    import urllib.request
    import urllib.error

    base_url = f"http://{args.host}:{args.port}"
    url = f"{base_url}/v1/trust/{args.agent_id}"

    try:
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            print(f"No trust data for agent: {args.agent_id}", file=sys.stderr)
            sys.exit(1)
        print(f"API error: {exc.code} {exc.reason}", file=sys.stderr)
        sys.exit(1)
    except urllib.error.URLError as exc:
        print(f"Cannot connect to {base_url}: {exc.reason}", file=sys.stderr)
        print("Is the Nomotic API server running? (nomotic serve)", file=sys.stderr)
        sys.exit(1)

    print(f"Trust Report: {data['agent_id']}")
    print(f"  Current Trust: {data['current_trust']:.2f}")

    traj = data.get("trajectory", {})
    trend = traj.get("trend", "unknown")
    print(f"  Trend: {trend}")
    print()

    successful = data.get("successful_actions", 0)
    denied = data.get("violation_count", 0)
    total = successful + denied
    print(f"  Actions: {total} total ({successful} successful, {denied} denied)")
    vr = data.get("violation_rate", 0)
    print(f"  Violation Rate: {vr:.1%}")
    print()

    fp = data.get("fingerprint")
    if fp:
        print(f"  Fingerprint: {fp['total_observations']} observations (confidence: {fp['confidence']:.3f})")

    drift = data.get("drift")
    if drift:
        print(f"  Drift: {drift['overall']:.2f} ({drift['severity']})")

    active_alerts = data.get("active_alerts")
    if active_alerts is not None:
        print(f"  Active Alerts: {active_alerts}")
    print()

    # Show recent events
    recent = traj.get("recent_events", [])
    if recent:
        total_events = traj.get("total_events", 0)
        print(f"  Trust History (last {len(recent)} of {total_events} changes):")
        for i, event in enumerate(recent):
            idx = total_events - len(recent) + i
            tb = event.get("trust_before", 0)
            ta = event.get("trust_after", 0)
            delta = event.get("delta", 0)
            src = event.get("source", "")
            reason = event.get("reason", "")
            sign = "+" if delta >= 0 else ""
            print(f"    [{idx}] {tb:.2f} -> {ta:.2f}  {sign}{delta:.3f}  {src:25s} {reason}")
        print()

    # Show trust by source
    sources = traj.get("sources", {})
    if sources:
        print("  Trust by Source:")
        for src, info in sorted(sources.items()):
            nd = info.get("net_delta", 0)
            cnt = info.get("count", 0)
            sign = "+" if nd >= 0 else ""
            print(f"    {src:25s} {sign}{nd:.3f} ({cnt} events)")
        print()


def _cmd_audit(args: argparse.Namespace) -> None:
    """View audit trail records, summary, or verify hash chain integrity."""

    identifier = args.identifier

    # Handle workflow chain commands that don't require an agent identifier
    if getattr(args, "verify_chain", None) is not None:
        _audit_verify_chain(args.verify_chain)
        return

    if not identifier and not args.show_all:
        print("Specify an agent name/ID, or use --all for all agents.", file=sys.stderr)
        print("  nomotic audit TestBot", file=sys.stderr)
        print("  nomotic audit TestBot --summary", file=sys.stderr)
        print("  nomotic audit TestBot --verify", file=sys.stderr)
        print("  nomotic audit --all", file=sys.stderr)
        print("  nomotic audit --all --push-agicomply", file=sys.stderr)
        sys.exit(1)

    # Resolve agent if provided
    agent_id = None
    if identifier:
        try:
            _numeric_id, resolved_name, _cert_id = _resolve_agent(args.base_dir, identifier)
            agent_id = resolved_name
        except SystemExit:
            # If resolve fails, use the identifier directly (might be a name
            # for an agent with audit records but no cert)
            agent_id = identifier

    if getattr(args, "verify_pre_execution", False):
        _audit_pre_execution_verify(args.base_dir, agent_id)
    elif getattr(args, "pre_execution", False):
        unsettled = getattr(args, "unsettled", False)
        _audit_pre_execution_records(args.base_dir, agent_id, limit=args.limit, unsettled_only=unsettled)
    elif getattr(args, "workflow", None) is not None:
        _audit_workflow(agent_id or "", args.workflow)
    elif args.verify:
        _audit_verify(args.base_dir, agent_id)
    elif args.summary:
        _audit_summary(args.base_dir, agent_id)
    elif args.delegations:
        _audit_delegations(args.base_dir, agent_id, limit=args.limit)
    elif getattr(args, "outputs", False):
        _audit_outputs(args.base_dir, agent_id, limit=args.limit)
    else:
        _audit_records(args.base_dir, agent_id, limit=args.limit, severity=args.severity)

    if getattr(args, "push_agicomply", False):
        _audit_push_agicomply(args)


def _audit_workflow(agent_id: str, workflow_id: str) -> None:
    """Display workflow seal chain information."""

    # Look for matching chains in the runtime's _workflow_chains
    # Since CLI doesn't have a live runtime, print a placeholder message
    print(f"\nWorkflow Governance Audit — {workflow_id}")
    print(f"  Agent: {agent_id}")
    print()
    print("  (Workflow chain data is available via runtime.get_workflow_chain())")
    print("  Use --verify-chain <chain-id> to verify a specific chain.")
    print()


def _audit_verify_chain(chain_id: str) -> None:
    """Verify a workflow seal chain."""

    print(f"\nVerifying workflow seal chain: {chain_id}")
    print()
    # Since CLI doesn't persist chains to disk by default,
    # this provides the verification framework for programmatic use.
    print("  (Chain verification requires a live runtime or persisted chain data)")
    print("  Use runtime.get_workflow_chain() + verify_workflow_chain() programmatically.")
    print()


def _cmd_workflow(args: argparse.Namespace) -> None:
    """Manage workflow seal chains and dependencies."""
    wf_cmd = getattr(args, "workflow_command", None)
    if wf_cmd == "dependencies":
        deps_cmd = getattr(args, "deps_command", None)
        if deps_cmd == "list":
            _workflow_deps_list(args)
        elif deps_cmd == "check":
            _workflow_deps_check(args)
        else:
            print("Usage: nomotic workflow dependencies {list,check}", file=sys.stderr)
            sys.exit(1)
    else:
        print("Usage: nomotic workflow {dependencies}", file=sys.stderr)
        sys.exit(1)


def _workflow_deps_list(args: argparse.Namespace) -> None:
    """List all registered workflow dependency rules."""

    base = args.base_dir
    config = _load_nomotic_config(base)
    deps = config.get("workflow_dependencies", [])

    print()
    print(f"  {_bold('Workflow Dependencies')}")
    print()

    if not deps:
        print("  No dependency rules registered.")
        print()
        print("  Use runtime.add_workflow_dependency() to register rules,")
        print("  or add workflow_dependencies to your nomotic config.")
        print()
        return

    # Find max widths for alignment
    dep_width = max(len(d.get("dependent_workflow_id", "")) for d in deps)
    req_width = max(len(d.get("required_workflow_id", "")) for d in deps)

    for d in deps:
        dep_id = d.get("dependent_workflow_id", "?")
        req_id = d.get("required_workflow_id", "?")
        status = d.get("required_status", "COMPLETE")
        max_age = d.get("max_age_seconds")

        constraint = f"[{status}"
        if max_age is not None:
            constraint += f", max-age={int(max_age)}s"
        constraint += "]"

        print(f"  {dep_id:<{dep_width}}  {_dim('→  requires  →')}  {req_id:<{req_width}}  {constraint}")

    print()
    print(f"  {len(deps)} dependency rule{'s' if len(deps) != 1 else ''} registered.")
    print()


def _workflow_deps_check(args: argparse.Namespace) -> None:
    """Check dependencies for a specific workflow."""
    from nomotic.seal import WorkflowDependencyChecker, WorkflowDependency

    workflow_id = args.workflow_id
    base = args.base_dir
    config = _load_nomotic_config(base)
    deps_config = config.get("workflow_dependencies", [])

    print()
    print(f"  {_bold('Dependency Check')} — {workflow_id}")
    print()

    if not deps_config:
        print("  No dependency rules registered.")
        print()
        return

    # Build checker from config
    checker = WorkflowDependencyChecker()
    for d in deps_config:
        checker.add_dependency(WorkflowDependency.from_dict(d))

    # Without a live runtime we cannot check actual chain state.
    # Show applicable rules and indicate that runtime check is needed.
    applicable = [
        d for d in deps_config
        if d.get("dependent_workflow_id") == workflow_id
    ]

    if not applicable:
        print(f"  No dependency rules apply to '{workflow_id}'.")
        print("  Workflow may proceed without prerequisites.")
        print()
        return

    for d in applicable:
        req_id = d.get("required_workflow_id", "?")
        print(f"  {req_id}  →  (requires live runtime to verify)  ? PENDING")

    print()
    print(f"  {len(applicable)} rule{'s' if len(applicable) != 1 else ''} apply.")
    print("  Use runtime.begin_workflow_sealing() for live dependency enforcement.")
    print()


def _audit_push_agicomply(args: argparse.Namespace) -> None:
    """Push audit records to AGICOMPLY's ingestion API."""
    from nomotic.audit_store import AuditStore
    from nomotic.integrations.agicomply import (
        AGICOMPLYClient,
        AGICOMPLYConfig,
        AGICOMPLYError,
    )

    identifier = args.identifier
    agent_id = None
    if identifier:
        try:
            _numeric_id, resolved_name, _cert_id = _resolve_agent(
                args.base_dir, identifier
            )
            agent_id = resolved_name
        except SystemExit:
            agent_id = identifier

    try:
        config = AGICOMPLYConfig.from_env()
    except ValueError as e:
        print(_red(f"AGICOMPLY config error: {e}"), file=sys.stderr)
        return

    if getattr(args, "agicomply_endpoint", None):
        config.endpoint = args.agicomply_endpoint

    audit_store = AuditStore(args.base_dir)
    records = []
    if agent_id:
        records = audit_store.query(
            agent_id, limit=args.limit, severity=args.severity
        )
    elif args.show_all:
        for name in audit_store.list_agents():
            records.extend(audit_store.query(name, limit=args.limit, severity=args.severity))

    if not records:
        print(_red("AGICOMPLY: no records to push"), file=sys.stderr)
        return

    try:
        client = AGICOMPLYClient(config)
        result = client.push_records(records)
        print(
            f"\nAGICOMPLY: {result['delivered']} delivered, "
            f"{result['failed']} failed"
        )
        if result["errors"]:
            for err in result["errors"]:
                print(f"  {_red('✗')} {err}")
    except AGICOMPLYError as e:
        print(_red(f"AGICOMPLY push failed: {e}"), file=sys.stderr)


def _audit_pre_execution_records(
    base_dir: Path,
    agent_id: str | None,
    limit: int = 20,
    unsettled_only: bool = False,
) -> None:
    """Show pre-execution records for an agent."""
    from nomotic.pre_execution import PreExecutionLedger

    if not agent_id:
        print(_red("Agent ID required for --pre-execution"), file=sys.stderr)
        return

    ledger = PreExecutionLedger(base_dir)
    if unsettled_only:
        records = ledger.get_unsettled(agent_id=agent_id)
        records = records[:limit]
        print(f"\nUnsettled Pre-Execution Records — {agent_id}")
    else:
        records = ledger.get_agent_records(agent_id, limit=limit)
        print(f"\nPre-Execution Records — {agent_id}")

    if not records:
        print("  (no records)")
        return

    print(f"  {len(records)} record(s)\n")
    for r in records:
        seal_info = f"  seal={r.governance_seal_id}" if r.governance_seal_id else ""
        settled = ledger.get_settlement(r.action_id)
        status = f"  [{_green('settled')}]" if settled else f"  [{_yellow('unsettled')}]"
        print(
            f"  {r.record_id[:20]}...  action={r.action_id}  "
            f"type={r.action_type}  target={r.action_target}{seal_info}{status}"
        )
    print()


def _audit_pre_execution_verify(base_dir: Path, agent_id: str | None) -> None:
    """Verify pre-execution chain integrity for an agent."""
    from nomotic.pre_execution import PreExecutionLedger

    if not agent_id:
        print(_red("Agent ID required for --verify-pre-execution"), file=sys.stderr)
        return

    ledger = PreExecutionLedger(base_dir)
    valid, count, message = ledger.verify_chain(agent_id)

    print(f"\nPre-Execution Chain Verification — {agent_id}")
    print(f"  Records: {count}")
    if valid:
        print(f"  Status:  {_green('VALID')}")
    else:
        print(f"  Status:  {_red('INVALID')}")
    print(f"  Message: {message}")
    print()


def _audit_records(
    base_dir: Path,
    agent_id: str | None,
    limit: int = 20,
    severity: str | None = None,
) -> None:
    """Show recent audit records for an agent."""
    from nomotic.audit_store import AuditStore

    audit_store = AuditStore(base_dir)

    if agent_id is None:
        # --all mode: show records across all agents
        all_agents = audit_store.list_agents()
        if not all_agents:
            print()
            print(f"  {_bold('Audit Trail')}")
            print("  No records found.")
            print()
            print("  Audit records are created automatically when actions are")
            print("  evaluated through the Nomotic gateway or SDK.")
            print()
            return
        print()
        print(f"  {_bold('Audit Trail: All Agents')}")
        print()
        for name in sorted(all_agents):
            records = audit_store.query(name, limit=limit, severity=severity)
            if records:
                print(f"  {_bold(name)} ({len(records)} records)")
                for r in records[:5]:  # Show top 5 per agent
                    _print_audit_record(r)
                if len(records) > 5:
                    print(f"    ... and {len(records) - 5} more")
                print()
        return

    records = audit_store.query(agent_id, limit=limit, severity=severity)

    if not records:
        print()
        print(f"  {_bold(f'Audit Trail: {agent_id}')}")
        print("  No records found.")
        print()
        print("  Audit records are created automatically when actions are")
        print("  evaluated through the Nomotic gateway or SDK.")
        print()
        print(f"  To run test evaluations: nomotic test {agent_id} --action read --target my_db")
        print(f"  To view test history:    nomotic testlog {agent_id}")
        print()
        return

    print()
    print(f"  {_bold(f'Audit Trail: {agent_id}')} (last {len(records)} records)")
    print()

    for r in records:
        _print_audit_record(r)


def _audit_delegations(
    base_dir: Path,
    agent_id: str | None,
    limit: int = 20,
) -> None:
    """Show delegation records from the audit trail."""
    from nomotic.audit_store import AuditStore

    audit_store = AuditStore(base_dir)

    if agent_id is None:
        all_agents = audit_store.list_agents()
        if not all_agents:
            print()
            print(f"  {_bold('Delegation History')}")
            print("  No records found.")
            print()
            return
        print()
        print(f"  {_bold('Delegation History: All Agents')}")
        print()
        for name in sorted(all_agents):
            records = audit_store.query(name, limit=limit)
            delegations = [r for r in records if r.action_type == "delegate"]
            if delegations:
                print(f"  {_bold(name)} ({len(delegations)} delegations)")
                for r in delegations[:5]:
                    _print_audit_record(r)
                if len(delegations) > 5:
                    print(f"    ... and {len(delegations) - 5} more")
                print()
        return

    records = audit_store.query(agent_id, limit=limit)
    delegations = [r for r in records if r.action_type == "delegate"]

    if not delegations:
        print()
        print(f"  {_bold(f'Delegation History: {agent_id}')}")
        print("  No delegation records found.")
        print()
        return

    print()
    print(f"  {_bold(f'Delegation History: {agent_id}')} ({len(delegations)} records)")
    print()

    for r in delegations:
        _print_audit_record(r)


def _audit_outputs(
    base_dir: Path,
    agent_id: str | None,
    limit: int = 20,
) -> None:
    """Show output governance evaluation records from the audit trail."""
    from datetime import datetime as _dt
    from datetime import timezone as _tz

    from nomotic.audit_store import AuditStore

    audit_store = AuditStore(base_dir)

    target_agents: list[str] = []
    if agent_id is None:
        target_agents = sorted(audit_store.list_agents())
    else:
        target_agents = [agent_id]

    if not target_agents:
        print()
        print(f"  {_bold('Output Governance Audit')}")
        print("  No records found.")
        print()
        return

    for aid in target_agents:
        records = audit_store.query(aid, limit=limit)
        output_records = [
            r for r in records if r.action_type == "output_evaluation"
        ]

        if not output_records:
            if agent_id is not None:
                print()
                print(f"  {_bold(f'Output Governance Audit — {aid}')} (last {limit})")
                print("  No output evaluation records found.")
                print()
            continue

        print()
        print(f"  {_bold(f'Output Governance Audit — {aid}')} (last {limit})")
        print()

        for r in output_records:
            ts = _dt.fromtimestamp(r.timestamp, tz=_tz.utc).strftime("%Y-%m-%d %H:%M:%S")
            verdict_color = (
                _green if r.verdict == "PASS"
                else (_red if r.verdict == "BLOCK" else _yellow)
            )
            params = r.parameters or {}
            redaction_count = params.get("redaction_count", 0)
            checks_failed = params.get("checks_failed", [])

            extra = ""
            if redaction_count:
                extra += f"   {redaction_count} PII redaction{'s' if redaction_count > 1 else ''}"
            if checks_failed:
                extra += f"   {', '.join(checks_failed)}"

            print(
                f"  {r.record_id:20s}   {ts}   "
                f"{verdict_color(r.verdict):8s}   ucs={r.ucs:.2f}{extra}"
            )

        print()


def _print_audit_record(r: "PersistentLogRecord", show_source: bool = False) -> None:
    """Print a single audit/log record."""
    from datetime import datetime as _dt
    from datetime import timezone as _tz

    ts = _dt.fromtimestamp(r.timestamp, tz=_tz.utc).strftime("%Y-%m-%d %H:%M:%S")
    verdict_color = _green if r.verdict == "ALLOW" else (_red if r.verdict == "DENY" else _yellow)
    source_tag = f" [{r.source}]" if show_source and hasattr(r, "source") and r.source else ""

    print(f"  {r.record_id}  {ts}  {verdict_color(r.verdict)}{source_tag}")
    print(f"    Action: {r.action_type} \u2192 {r.action_target}")
    print(f"    UCS: {r.ucs:.2f}  Tier: {r.tier}  Trust: {r.trust_score:.3f} ({r.trust_trend})")
    if r.vetoed_by:
        print(f"    Vetoed by: {', '.join(r.vetoed_by)}")
    if r.justification:
        just = r.justification[:120]
        if len(r.justification) > 120:
            just += "..."
        print(f"    Why: {just}")
    print()


def _audit_summary(base_dir: Path, agent_id: str | None) -> None:
    """Show audit summary for an agent."""
    from nomotic.audit_store import AuditStore

    audit_store = AuditStore(base_dir)

    if agent_id is None:
        # --all mode
        all_agents = audit_store.list_agents()
        if not all_agents:
            print("  No audit records found.")
            return
        print()
        print(f"  {_bold('Audit Summary: All Agents')}")
        print()
        for name in sorted(all_agents):
            s = audit_store.summary(name)
            if s["total"] > 0:
                t_start = s.get('trust_start', 0.5)
                t_end = s.get('trust_end', 0.5)
                print(
                    f"  {_bold(name)}: {s['total']} evaluations,"
                    f" trust {t_start:.3f} \u2192 {t_end:.3f}"
                )
        print()
        return

    summary = audit_store.summary(agent_id)

    if summary["total"] == 0:
        print(f"  No audit records found for '{agent_id}'.")
        return

    total = summary["total"]
    print()
    print(f"  {_bold(f'Audit Summary: {agent_id}')}")
    print()
    print(f"  Total evaluations: {total}")
    print()

    print("  By verdict:")
    for v, count in sorted(summary["by_verdict"].items()):
        pct = count / total * 100
        color = _green if v == "ALLOW" else (_red if v == "DENY" else _yellow)
        bar_len = int(count / total * 40)
        bar = "\u2588" * bar_len
        print(f"    {color(f'{v:10s}')} {count:5d}  {bar}  {pct:.1f}%")
    print()

    print(f"  Trust: {summary.get('trust_start', 0.5):.3f} \u2192 {summary.get('trust_end', 0.5):.3f}")
    print()


def _cmd_constitution(args: argparse.Namespace) -> None:
    """Manage constitutional rules."""
    cmd = getattr(args, "constitution_command", None)
    if cmd is None:
        cmd = "list"

    base_dir = Path(args.base_dir) if hasattr(args, "base_dir") and args.base_dir else _DEFAULT_BASE

    if cmd == "list":
        # Try to load constitutional ruleset from standard location
        ruleset_path = base_dir / "constitution.json"
        if not ruleset_path.exists():
            print()
            print("  No constitutional ruleset configured.")
            print(f"  Expected at: {ruleset_path}")
            print()
            return

        from nomotic.constitution import ConstitutionalRuleSet
        ruleset = ConstitutionalRuleSet.from_file(ruleset_path)
        print()
        print(f"  {_bold('Constitutional Rules')}")
        print(f"  Ruleset: {_dim(ruleset.ruleset_id)}")
        print(f"  Signed by: {ruleset.signed_by}")
        print(f"  Rules: {len(ruleset.rules)}")
        print()
        for rule in ruleset.rules:
            print(f"    {_cyan(rule.rule_id)}  {rule.name}  [{_dim(rule.rule_type)}]")
        print()

    elif cmd == "show":
        rule_id = args.rule_id
        ruleset_path = base_dir / "constitution.json"
        if not ruleset_path.exists():
            print(_red("  No constitutional ruleset configured."))
            sys.exit(1)

        from nomotic.constitution import ConstitutionalRuleSet
        ruleset = ConstitutionalRuleSet.from_file(ruleset_path)
        found = None
        for rule in ruleset.rules:
            if rule.rule_id == rule_id:
                found = rule
                break

        if found is None:
            print(_red(f"  Rule {rule_id} not found."))
            sys.exit(1)

        print()
        print(f"  {_bold(found.name)}")
        print(f"  ID:          {found.rule_id}")
        print(f"  Type:        {found.rule_type}")
        print(f"  Description: {found.description}")
        print(f"  Created by:  {found.created_by}")
        print(f"  Hash:        {_dim(found.rule_hash[:16])}...")
        print(f"  Condition:   {json.dumps(found.condition, indent=2)}")
        print()

    elif cmd == "verify":
        path = Path(args.path)
        if not path.exists():
            print(_red(f"  File not found: {path}"))
            sys.exit(1)

        from nomotic.constitution import ConstitutionalRuleSet
        ruleset = ConstitutionalRuleSet.from_file(path)

        # Load CA verify key
        try:
            _sk, _vk, _issuer_id = _load_or_create_issuer(base_dir)
            verify_key_bytes = _vk.to_bytes()
        except Exception as exc:
            print(_red(f"  Cannot load issuer key: {exc}"))
            sys.exit(1)

        valid = ruleset.verify_signature(verify_key_bytes)
        print()
        if valid:
            print(f"  {_green('VALID')} — signature verified")
            print(f"  Signed by:   {ruleset.signed_by}")
            print(f"  Rule count:  {len(ruleset.rules)}")
            print(f"  Ruleset ID:  {ruleset.ruleset_id}")
        else:
            print(f"  {_red('INVALID')} — signature verification failed")
            print("  The ruleset may have been tampered with.")
            print(f"  Signed by:   {ruleset.signed_by}")
            print(f"  Rule count:  {len(ruleset.rules)}")
        print()
        sys.exit(0 if valid else 1)

    elif cmd == "dry-run":
        ruleset_path = args.ruleset
        if not Path(ruleset_path).exists():
            print(_red(f"  File not found: {ruleset_path}"))
            sys.exit(1)

        from nomotic.audit_store import LogStore
        from nomotic.constitution import ConstitutionalDryRunner

        audit_store = LogStore(base_dir, "audit")
        runner = ConstitutionalDryRunner(audit_store=audit_store)

        agent = getattr(args, "agent", None)
        days = getattr(args, "days", 7)
        max_records = getattr(args, "max_records", 500)

        result = runner.run(
            ruleset_path=ruleset_path,
            agent_id=agent,
            days=days,
            max_records=max_records,
        )

        print()
        print(f"  {_bold('Constitutional Dry-Run')} — {ruleset_path}")
        print("  " + "\u2500" * 48)
        ruleset_label = result.ruleset_id or "(unknown)"
        print(f"  Ruleset:           {ruleset_label}")
        print(f"  Records evaluated: {result.records_evaluated:,}")
        print(f"  Already denied:    {result.already_denied_count:>4}")
        print(f"  Would block (new): {result.new_blocks_count:>4}", end="")
        if result.new_blocks_count > 0:
            print("  \u2190 Net new blocks if ruleset were active")
        else:
            print()
        print()

        if result.new_blocks_count == 0:
            check = "\u2713"
            print(f"  {_green(check)} No currently-allowed actions would be blocked by this ruleset.")
            print("  Safe to deploy.")
            print()
            return

        # Show new blocks (non-DENY records that would be blocked)
        new_blocks = [
            wb for wb in result.would_block
            if wb["original_verdict"] != "DENY"
        ]
        if new_blocks:
            print("  New blocks:")
            for entry in new_blocks:
                rid = entry["record_id"][:10]
                aid = entry["agent_id"]
                atype = entry["action_type"]
                atarget = entry["action_target"]
                rule_id = entry["rule_id"][:7] if len(entry["rule_id"]) > 7 else entry["rule_id"]
                rname = entry["rule_name"]
                print(f"    {rid}  {aid:<16} {atype:<8} {atarget:<20} \u2192 {rule_id} ({rname})")
            print()

        warn = "\u26a0"
        print(
            f"  {_yellow(warn)} {result.new_blocks_count}"
            " currently-allowed actions would be blocked by this ruleset."
        )
        print("  Review before deploying.")
        print()


def _cmd_fleet(args: argparse.Namespace) -> None:
    """Fleet governance overview commands."""
    from nomotic.audit_store import AuditStore
    from nomotic.fleet import FleetGovernor

    cmd = getattr(args, "fleet_command", None)
    if cmd is None:
        # Default to health
        cmd = "health"

    store = AuditStore(args.base_dir)
    fleet = FleetGovernor(audit_store=store)

    if cmd in ("health", "status"):
        summary = fleet.health_summary()
        print()
        print(f"  {_bold('Fleet Governance Summary (last 24h)')}")
        print()
        print(f"  Total agents:       {summary.total_agents:>5}")
        print(f"  Active agents:      {summary.active_agents:>5}")
        print(f"  Critical agents:    {summary.critical_agents:>5}  {_dim('← trust < 0.3 or denial rate > 50%')}")
        print(f"  Warning agents:     {summary.warning_agents:>5}")
        print(f"  Healthy agents:     {summary.healthy_agents:>5}")
        print(f"  Evaluations (24h): {summary.total_evaluations_24h:>5,}")
        print(f"  Fleet denial rate: {summary.fleet_denial_rate * 100:>5.1f}%")
        print()

    elif cmd == "critical":
        agents = fleet.critical_agents()
        if not agents:
            print()
            print(f"  {_green('No critical agents. Fleet is healthy.')}")
            print()
            return
        print()
        print(f"  {_bold(f'Critical Agents ({len(agents)})')}")
        print()
        for a in agents:
            from datetime import datetime, timezone
            trend_arrow = "↓" if a.trust_trend == "falling" else ("↑" if a.trust_trend == "rising" else "→")
            last_seen = ""
            if a.last_activity is not None:
                last_seen = datetime.fromtimestamp(a.last_activity, tz=timezone.utc).strftime("%Y-%m-%d %H:%M")
            print(
                f"  {_red(f'{a.agent_id:15s}')} "
                f"trust={a.current_trust:.2f} {trend_arrow}   "
                f"denial_rate={a.denial_rate * 100:.0f}%   "
                f"last seen: {last_seen}"
            )
        print()

    elif cmd == "denials":
        limit = getattr(args, "limit", 10)
        denials = fleet.top_denied_action_types(limit=limit)
        if not denials:
            print()
            print("  No denied actions in the last 24h.")
            print()
            return
        print()
        print(f"  {_bold('Top Denied Action Types (last 24h)')}")
        print()
        for d in denials:
            print(f"  {d.action_type:20s} {d.deny_count:>3} denials   {d.agent_count} agents")
        print()

    elif cmd == "agents":
        all_agents = store.list_agents()
        if not all_agents:
            print()
            print("  No agents found.")
            print()
            return
        print()
        print(f"  {_bold('Fleet Agents')}")
        print()
        for agent_id in sorted(all_agents):
            record = fleet.get_agent_record(agent_id)
            if record is None:
                continue
            status_color = {
                "healthy": _green,
                "warning": _yellow,
                "critical": _red,
                "inactive": _dim,
            }.get(record.status, _dim)
            print(
                f"  {record.agent_id:20s} "
                f"{status_color(f'{record.status:10s}')} "
                f"trust={record.current_trust:.2f}  "
                f"evals={record.evaluations_24h:>4}  "
                f"denial_rate={record.denial_rate * 100:.0f}%"
            )
        print()

    elif cmd == "drift-health":
        _cmd_fleet_drift_health(args)

    elif cmd == "drift-alerts":
        _cmd_fleet_drift_alerts(args)

    elif cmd == "interaction":
        _cmd_fleet_interaction(args)


def _cmd_fleet_drift_health(args: argparse.Namespace) -> None:
    """Show fleet behavioral drift health summary."""
    import json
    from urllib.request import urlopen

    host = getattr(args, "host", "127.0.0.1")
    port = getattr(args, "port", 8420)
    try:
        resp = urlopen(f"http://{host}:{port}/v1/fleet/drift-health", timeout=10)
        data = json.loads(resp.read())
    except Exception as exc:
        print(f"\n  {_red('Error')}: Could not reach server — {exc}\n")
        return

    print()
    print(f"  {_bold('Fleet Behavioral Drift Health')}")
    print()
    print(f"  Agents tracked:     {data.get('agents_tracked', 0):>5}")
    print(f"  Agents drifting:    {data.get('agents_drifting', 0):>5}")
    print(f"  Fleet drift:       {data.get('fleet_drift', 0.0):>6.4f}")
    alerts = data.get("active_alerts", {})
    print(f"  Active alerts:")
    print(f"    Fleet:            {alerts.get('fleet', 0):>5}")
    print(f"    Correlated:       {alerts.get('correlated', 0):>5}")
    print(f"    Coordinated:      {alerts.get('coordinated', 0):>5}")
    print(f"  Interaction edges:  {data.get('interaction_edges', 0):>5}")
    print()


def _cmd_fleet_drift_alerts(args: argparse.Namespace) -> None:
    """Show fleet drift alerts."""
    import json
    from urllib.request import urlopen

    host = getattr(args, "host", "127.0.0.1")
    port = getattr(args, "port", 8420)
    scope = getattr(args, "scope", None)
    url = f"http://{host}:{port}/v1/fleet/drift-alerts"
    if scope:
        url += f"?scope={scope}"
    try:
        resp = urlopen(url, timeout=10)
        alerts = json.loads(resp.read())
    except Exception as exc:
        print(f"\n  {_red('Error')}: Could not reach server — {exc}\n")
        return

    if not alerts:
        print(f"\n  {_green('No fleet drift alerts.')}\n")
        return

    print()
    print(f"  {_bold(f'Fleet Drift Alerts ({len(alerts)})')}")
    print()
    for alert in alerts:
        scope_name = alert.get("scope", "unknown")
        severity = alert.get("severity", "unknown")
        color = {"moderate": _yellow, "high": _red, "critical": _red}.get(severity, _dim)
        print(f"  [{color(severity.upper())}] {_bold(scope_name)}  {alert.get('detail', '')}")
        if scope_name == "correlated":
            agents = alert.get("affected_agents", [])
            print(f"    Agents: {', '.join(agents)}")
            print(f"    Correlation: {alert.get('correlation_strength', 0):.3f}")
        elif scope_name == "coordinated":
            chain = alert.get("propagation_chain", [])
            print(f"    Chain: {' → '.join(chain)}")
            print(f"    Intervention: {alert.get('recommended_intervention_point', 'N/A')}")
        print()


def _cmd_fleet_interaction(args: argparse.Namespace) -> None:
    """Register an agent interaction edge."""
    import json
    from urllib.request import Request, urlopen

    host = getattr(args, "host", "127.0.0.1")
    port = getattr(args, "port", 8420)
    source = args.source
    target = args.target
    body = json.dumps({"source": source, "target": target}).encode()
    req = Request(
        f"http://{host}:{port}/v1/fleet/interactions",
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        urlopen(req, timeout=10)
        print(f"\n  {_green('Registered')}: {source} → {target}\n")
    except Exception as exc:
        print(f"\n  {_red('Error')}: {exc}\n")


def _audit_verify(base_dir: Path, agent_id: str | None) -> None:
    """Verify hash chain integrity for an agent's audit trail."""
    from nomotic.audit_store import AuditStore

    audit_store = AuditStore(base_dir)

    if agent_id is None:
        # --all mode
        all_agents = audit_store.list_agents()
        if not all_agents:
            print("  No audit records to verify.")
            return
        print()
        print(f"  {_bold('Audit Chain Verification: All Agents')}")
        print()
        _check = "\u2713"
        _cross = "\u2717"
        for name in sorted(all_agents):
            is_valid, count, message = audit_store.verify_chain(name)
            if count == 0:
                continue
            if is_valid:
                print(f"  {_green(_check)} {name}: {count} records verified")
            else:
                print(f"  {_red(_cross)} {name}: {message}")
        print()
        return

    is_valid, count, message = audit_store.verify_chain(agent_id)

    print()
    print(f"  {_bold(f'Audit Chain: {agent_id}')}")
    print()
    print(f"  Records: {count}")

    if count == 0:
        print("  No records to verify.")
        return

    records = audit_store.query_all(agent_id)
    from datetime import datetime as _dt
    from datetime import timezone as _tz

    first_ts = _dt.fromtimestamp(records[0].timestamp, tz=_tz.utc).strftime("%Y-%m-%d %H:%M:%S")
    last_ts = _dt.fromtimestamp(records[-1].timestamp, tz=_tz.utc).strftime("%Y-%m-%d %H:%M:%S")
    r0, rn = records[0], records[-1]
    print(f"  First:   {first_ts}  ({r0.action_type} \u2192 {r0.action_target}, {r0.verdict})")
    print(f"  Last:    {last_ts}  ({rn.action_type} \u2192 {rn.action_target}, {rn.verdict})")

    if is_valid:
        chain_ok = f"\u2713 All {count} records verified \u2014 no tampering detected"
        print(f"  Chain:   {_green(chain_ok)}")
        print(f"  Hash:    {records[-1].record_hash}")
    else:
        chain_fail = f"\u2717 {message}"
        print(f"  Chain:   {_red(chain_fail)}")
    print()


def _cmd_testlog(args: argparse.Namespace) -> None:
    """View test evaluation history."""
    identifier = getattr(args, "identifier", None)

    if not identifier:
        print("Specify an agent: nomotic testlog TestBot", file=sys.stderr)
        sys.exit(1)

    # Resolve agent name
    try:
        _numeric_id, resolved_name, _cert_id = _resolve_agent(args.base_dir, identifier)
        agent_id = resolved_name
    except SystemExit:
        agent_id = identifier

    if getattr(args, "clear", False):
        _testlog_clear(args.base_dir, agent_id)
        return

    from nomotic.audit_store import LogStore

    store = LogStore(args.base_dir, "testlog")

    if getattr(args, "verify", False):
        _testlog_verify(store, agent_id)
    elif getattr(args, "summary", False):
        _testlog_summary(store, agent_id)
    else:
        _testlog_records(store, agent_id, limit=getattr(args, "limit", 20))


def _testlog_records(
    store: "LogStore",
    agent_id: str,
    limit: int = 20,
) -> None:
    """Show recent test log records for an agent."""
    records = store.query(agent_id, limit=limit)

    if not records:
        print()
        print(f"  {_bold(f'Test Log: {agent_id}')}")
        print("  No records found.")
        print()
        print("  Run test evaluations with:")
        print(f"    nomotic test {agent_id} --action read --target my_db")
        print()
        return

    print()
    print(f"  {_bold(f'Test Log: {agent_id}')} (last {len(records)} records)")
    print()

    for r in records:
        _print_audit_record(r, show_source=True)


def _testlog_summary(store: "LogStore", agent_id: str) -> None:
    """Show test log summary for an agent."""
    summary = store.summary(agent_id)

    if summary.get("total", 0) == 0:
        print(f"  No test log records found for '{agent_id}'.")
        return

    total = summary["total"]
    print()
    print(f"  {_bold(f'Test Log Summary: {agent_id}')}")
    print()
    print(f"  Total evaluations: {total}")
    print()

    print("  By verdict:")
    for v, count in sorted(summary["by_verdict"].items()):
        pct = count / total * 100
        color = _green if v == "ALLOW" else (_red if v == "DENY" else _yellow)
        bar_len = int(count / total * 40)
        bar = "\u2588" * bar_len
        print(f"    {color(f'{v:10s}')} {count:5d}  {bar}  {pct:.1f}%")
    print()

    print(f"  Trust: {summary.get('trust_start', 0.5):.3f} \u2192 {summary.get('trust_end', 0.5):.3f}")
    print()


def _testlog_verify(store: "LogStore", agent_id: str) -> None:
    """Verify hash chain integrity for an agent's test log."""
    is_valid, count, message = store.verify_chain(agent_id)

    print()
    print(f"  {_bold(f'Test Log Chain: {agent_id}')}")
    print()
    print(f"  Records: {count}")

    if count == 0:
        print("  No records to verify.")
        return

    records = store.query_all(agent_id)
    from datetime import datetime as _dt
    from datetime import timezone as _tz

    first_ts = _dt.fromtimestamp(records[0].timestamp, tz=_tz.utc).strftime("%Y-%m-%d %H:%M:%S")
    last_ts = _dt.fromtimestamp(records[-1].timestamp, tz=_tz.utc).strftime("%Y-%m-%d %H:%M:%S")
    r0, rn = records[0], records[-1]
    print(f"  First:   {first_ts}  ({r0.action_type} \u2192 {r0.action_target}, {r0.verdict})")
    print(f"  Last:    {last_ts}  ({rn.action_type} \u2192 {rn.action_target}, {rn.verdict})")

    if is_valid:
        chain_ok = f"\u2713 All {count} records verified \u2014 no tampering detected"
        print(f"  Chain:   {_green(chain_ok)}")
        print(f"  Hash:    {records[-1].record_hash}")
    else:
        chain_fail = f"\u2717 {message}"
        print(f"  Chain:   {_red(chain_fail)}")
    print()


def _testlog_clear(base_dir: Path, agent_id: str) -> None:
    """Clear test history and reset simulated trust for an agent."""
    testlog_dir = base_dir / "testlog"
    safe_name = agent_id.lower()

    log_file = testlog_dir / f"{safe_name}.jsonl"
    trust_file = testlog_dir / f"{safe_name}.trust.json"

    cleared = False
    if log_file.exists():
        log_file.unlink()
        cleared = True
    if trust_file.exists():
        trust_file.unlink()
        cleared = True

    if cleared:
        print(f"  Test history cleared for {agent_id}.")
        print("  Simulated trust reset to production value.")
    else:
        print(f"  No test history found for {agent_id}.")


def _cmd_provenance(args: argparse.Namespace) -> None:
    """Show configuration provenance records (via API)."""
    import urllib.request
    import urllib.error

    base_url = f"http://{args.host}:{args.port}"
    url = f"{base_url}/v1/provenance?"
    params = []
    if args.target_type:
        params.append(f"target_type={args.target_type}")
    if args.target_id:
        params.append(f"target_id={args.target_id}")
    url += "&".join(params)

    try:
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        print(f"API error: {exc.code} {exc.reason}", file=sys.stderr)
        sys.exit(1)
    except urllib.error.URLError as exc:
        print(f"Cannot connect to {base_url}: {exc.reason}", file=sys.stderr)
        sys.exit(1)

    records = data.get("records", [])
    if not records:
        print("No provenance records found.")
        return

    print(f"Provenance Records ({len(records)} shown):")
    for r in records:
        ct = r.get('change_type', '?')
        tt = r.get('target_type', '?')
        tid = r.get('target_id', '?')
        actor = r.get('actor', '?')
        print(f"  [{ct:6s}] {tt:10s}/{tid:15s} by {actor}")
        if r.get("reason"):
            print(f"          reason: {r['reason']}")


def _cmd_owner(args: argparse.Namespace) -> None:
    """Show owner activity and engagement (via API)."""
    import urllib.request
    import urllib.error

    base_url = f"http://{args.host}:{args.port}"
    owner_id = args.owner_id

    if args.engagement:
        url = f"{base_url}/v1/owner/{owner_id}/engagement"
        try:
            req = urllib.request.Request(url)
            with urllib.request.urlopen(req) as resp:
                data = json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            print(f"API error: {exc.code} {exc.reason}", file=sys.stderr)
            sys.exit(1)
        except urllib.error.URLError as exc:
            print(f"Cannot connect to {base_url}: {exc.reason}", file=sys.stderr)
            sys.exit(1)

        print(f"Owner Engagement: {owner_id}")
        print(f"  Total activities:     {data.get('total_activities', 0)}")
        print(f"  Activities in window: {data.get('activities_in_window', 0)}")
        print(f"  Alert response rate:  {data.get('alert_response_rate', 0):.1%}")
        print(f"  Engagement level:     {data.get('engagement_level', 'unknown')}")
        return

    url = f"{base_url}/v1/owner/{owner_id}/activity"
    try:
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        print(f"API error: {exc.code} {exc.reason}", file=sys.stderr)
        sys.exit(1)
    except urllib.error.URLError as exc:
        print(f"Cannot connect to {base_url}: {exc.reason}", file=sys.stderr)
        sys.exit(1)

    activities = data.get("activities", [])
    if not activities:
        print(f"No activity for owner: {owner_id}")
        return

    print(f"Owner Activity: {owner_id} ({len(activities)} shown)")
    for a in activities:
        print(f"  {a.get('activity_type', '?'):25s} agent={a.get('target_agent_id', '-')}")
        if a.get("detail"):
            print(f"    {a['detail']}")


def _cmd_oversight(args: argparse.Namespace) -> None:
    """Show human oversight engagement profiles and drift analysis."""
    from nomotic.human_drift import (
        HumanAuditStore,
        HumanDriftCalculator,
        HumanDriftMonitor,
        HumanInteractionProfile,
        RoutingRecommendation,
        TeamOversightMetrics,
    )

    store = HumanAuditStore(args.base_dir)

    # --team: show team-level oversight health
    if args.team:
        reviewers = store.list_reviewers()
        if not reviewers:
            print("No human interaction data found.")
            return

        monitor = HumanDriftMonitor()
        for reviewer_id in reviewers:
            events = store.query_all(reviewer_id)
            for event in events:
                monitor.record_event(event)

        metrics = TeamOversightMetrics(monitor).compute()
        print(_bold("Team Oversight Health"))
        print(f"  Reviewers:             {metrics.get('total_reviewers', 0)}")
        print(f"  Profiled:              {metrics.get('profiled_reviewers', 0)}")
        print(f"  Total reviews:         {metrics.get('total_reviews', 0)}")
        print(f"  Team approval rate:    {metrics.get('team_approval_rate', 0):.1%}")
        print(f"  Team rationale rate:   {metrics.get('team_rationale_rate', 0):.1%}")
        spof = metrics.get("single_point_of_failure", False)
        conc = metrics.get("highest_concentration", 0)
        if spof:
            print(f"  {_red('!')} Single point of failure: {conc:.0%} concentration")
        else:
            print(f"  Highest concentration: {conc:.0%}")
        alert_count = metrics.get("active_alerts", 0)
        if alert_count > 0:
            print(f"  {_yellow('!')} Active drift alerts: {alert_count}")
        else:
            print("  Active drift alerts:   0")
        concentration = metrics.get("review_concentration", {})
        if concentration:
            print()
            print(_bold("  Review Distribution:"))
            for rid, share in sorted(concentration.items(), key=lambda x: -x[1]):
                print(f"    {rid:25s} {share:.1%}")
        return

    # --alerts: show all human drift alerts across all reviewers
    if args.alerts:
        reviewers = store.list_reviewers()
        if not reviewers:
            print("No human interaction data found.")
            return

        found_alerts = False
        for reviewer_id in reviewers:
            events = store.query_all(reviewer_id)
            if len(events) < 250:  # baseline_window(200) + recent_window(50)
                continue
            baseline = HumanInteractionProfile.from_events(reviewer_id, events[:200])
            recent = HumanInteractionProfile.from_events(reviewer_id, events[-50:])
            calculator = HumanDriftCalculator()
            result = calculator.calculate(baseline, recent)
            if result.alerts:
                found_alerts = True
                rec = RoutingRecommendation.from_drift_result(result)
                print(_bold(f"Reviewer: {reviewer_id}") + f"  [{_yellow(result.drift_category)}]")
                print(f"  Overall drift: {result.overall_drift:.3f}")
                print(f"  Routing:       {rec.recommendation} ({rec.urgency})")
                for alert in result.alerts:
                    print(f"  {_red('!')} {alert}")
                print()

        if not found_alerts:
            print("No human drift alerts detected.")
        return

    # Require reviewer_id for profile/drift views
    if args.reviewer_id is None:
        print("Usage: nomotic oversight <reviewer_id> [--drift] [--alerts] [--team]", file=sys.stderr)
        sys.exit(1)

    reviewer_id = args.reviewer_id
    events = store.query_all(reviewer_id)
    if not events:
        print(f"No events found for reviewer: {reviewer_id}")
        return

    # --drift: show drift analysis
    if args.drift:
        if len(events) < 250:
            print(f"Insufficient data for drift analysis. Have {len(events)} events, need 250+.")
            return
        baseline = HumanInteractionProfile.from_events(reviewer_id, events[:200])
        recent = HumanInteractionProfile.from_events(reviewer_id, events[-50:])
        calculator = HumanDriftCalculator()
        result = calculator.calculate(baseline, recent)
        rec = RoutingRecommendation.from_drift_result(result)

        print(_bold(f"Human Drift Analysis: {reviewer_id}"))
        print(f"  Category:          {result.drift_category}")
        print(f"  Overall drift:     {result.overall_drift:.3f}")
        print(f"  Risk timing drift: {result.risk_timing_drift:.3f}")
        print(f"  Timing drift:      {result.timing_drift:.3f}")
        print(f"  Decision drift:    {result.decision_drift:.3f}")
        print(f"  Engagement drift:  {result.engagement_drift:.3f}")
        print(f"  Throughput drift:  {result.throughput_drift:.3f}")
        print(f"  Fatigue score:     {result.fatigue_score:.3f}")
        print()
        print(_bold("Routing Recommendation:"))
        print(f"  Action:  {rec.recommendation}")
        print(f"  Urgency: {rec.urgency}")
        print(f"  Reason:  {rec.reason}")
        if result.alerts:
            print()
            print(_bold("Alerts:"))
            for alert in result.alerts:
                print(f"  {_red('!')} {alert}")
        else:
            print(f"\n  {_green('OK')} No drift alerts.")
        return

    # Default: show engagement profile
    profile = HumanInteractionProfile.from_events(reviewer_id, events)
    print(_bold(f"Human Oversight Profile: {reviewer_id}"))
    print(f"  Total interactions:    {profile.total_interactions}")
    print(f"  Mean review duration:  {profile.mean_review_duration:.1f}s")
    print(f"  Median review duration:{profile.median_review_duration:.1f}s")
    print(f"  Approval rate:         {profile.approval_rate:.1%}")
    print(f"  Denial rate:           {profile.denial_rate:.1%}")
    print(f"  Modification rate:     {profile.modification_rate:.1%}")
    print(f"  Override rate:         {profile.override_rate:.1%}")
    print(f"  Rationale provided:    {profile.rationale_provided_rate:.1%}")
    print(f"  Context viewed:        {profile.context_view_rate:.1%}")
    print(f"  Mean rationale depth:  {profile.mean_rationale_depth:.1f} words")
    print(f"  Throughput:            {profile.interactions_per_hour:.1f}/hr")
    if profile.high_risk_interactions > 0:
        print(f"  High-risk reviews:     {profile.high_risk_interactions}")
        print(f"  High-risk avg duration:{profile.high_risk_mean_duration:.1f}s")
        print(f"  High-risk rationale:   {profile.high_risk_rationale_rate:.1%}")
    print(f"  Consecutive approvals: {profile.consecutive_approvals}")
    print(f"  Reviews last hour:     {profile.reviews_last_hour}")


def _cmd_scope(args: argparse.Namespace) -> None:
    """Configure or view an agent's authorized scope."""
    from nomotic.sandbox import (
        AgentConfig,
        load_agent_config,
        save_agent_config,
    )

    agent_id = args.agent_id
    sub = args.scope_command

    if sub == "set":
        config = load_agent_config(args.base_dir, agent_id) or AgentConfig(agent_id=agent_id)
        if args.actions:
            config.actions = [a.strip() for a in args.actions.split(",")]
        if args.boundaries:
            config.boundaries = [b.strip() for b in args.boundaries.split(",")]
        save_agent_config(args.base_dir, config)

        print(f"Scope configured for {agent_id}:")
        print(f"  Allowed actions:  {', '.join(config.actions)}")
        print(f"  Boundaries:       {', '.join(config.boundaries)}")
        print()
        _print_authority_envelope(agent_id, config)

    elif sub == "show":
        config = load_agent_config(args.base_dir, agent_id)
        if config is None:
            print(f"No configuration found for agent: {agent_id}", file=sys.stderr)
            sys.exit(1)
        _print_authority_envelope(agent_id, config)

    else:
        print("Unknown scope subcommand. Use 'set' or 'show'.", file=sys.stderr)
        sys.exit(1)


def _print_authority_envelope(agent_id: str, config: "AgentConfig") -> None:
    """Print the formatted authority envelope box."""
    actions_str = "  ".join(config.actions) if config.actions else "(none)"
    boundaries = config.boundaries or []

    width = 45
    print(f"  {'':>{0}}{_bold(chr(9484))}{chr(9472) * width}{_bold(chr(9488))}")
    print(f"  {_bold(chr(9474))}  {agent_id} Authority Envelope{' ' * (width - len(agent_id) - 22)}{_bold(chr(9474))}")
    print(f"  {_bold(chr(9474))}{' ' * width}{_bold(chr(9474))}")
    pad = ' ' * max(0, width - len(actions_str) - 12)
    print(f"  {_bold(chr(9474))}  Actions: {actions_str}{pad}{_bold(chr(9474))}")
    print(f"  {_bold(chr(9474))}{' ' * width}{_bold(chr(9474))}")
    if boundaries:
        print(f"  {_bold(chr(9474))}  Can touch:{' ' * (width - 13)}{_bold(chr(9474))}")
        for b in boundaries:
            line = f"    {_green(chr(10003))} {b}"
            # Count visible chars (without ANSI)
            visible_len = len(f"    {chr(10003)} {b}")
            pad = width - visible_len - 2
            print(f"  {_bold(chr(9474))}  {line}{' ' * max(0, pad)}{_bold(chr(9474))}")
    else:
        print(f"  {_bold(chr(9474))}  Boundaries: (none){' ' * (width - 22)}{_bold(chr(9474))}")
    print(f"  {_bold(chr(9474))}{' ' * width}{_bold(chr(9474))}")
    print(f"  {_bold(chr(9474))}  Cannot touch: everything else{' ' * (width - 33)}{_bold(chr(9474))}")
    print(f"  {_bold(chr(9492))}{chr(9472) * width}{_bold(chr(9496))}")


def _cmd_rule(args: argparse.Namespace) -> None:
    """Add governance rules to an agent."""
    from nomotic.sandbox import (
        AgentConfig,
        EthicalRuleSpec,
        HumanOverrideSpec,
        load_agent_config,
        save_agent_config,
    )

    agent_id = args.agent_id
    config = load_agent_config(args.base_dir, agent_id) or AgentConfig(agent_id=agent_id)

    if args.rule_command != "add":
        print("Unknown rule subcommand. Use 'add'.", file=sys.stderr)
        sys.exit(1)

    rule_type = args.type

    if rule_type == "ethical":
        if not args.condition:
            print("--condition is required for ethical rules", file=sys.stderr)
            sys.exit(1)
        if not args.message:
            print("--message is required for ethical rules", file=sys.stderr)
            sys.exit(1)
        rule = EthicalRuleSpec(
            condition=args.condition,
            message=args.message,
            name=getattr(args, "name", "") or "",
        )
        config.ethical_rules.append(rule)
        save_agent_config(args.base_dir, config)

        print("Ethical rule added:")
        print(f"  Agent: {agent_id}")
        print(f"  Rule:  {rule.condition}")
        print(f"  If violated: \"{rule.message}\"")
        print("  Effect: VETO (cannot be overridden by score)")

    elif rule_type == "human-override":
        if not args.action:
            print("--action is required for human-override rules", file=sys.stderr)
            sys.exit(1)
        override = HumanOverrideSpec(
            action=args.action,
            message=args.message or f"Human approval required for '{args.action}'",
        )
        config.human_overrides.append(override)
        save_agent_config(args.base_dir, config)

        print("Human override rule added:")
        print(f"  Agent:  {agent_id}")
        print(f"  Action: {override.action}")
        print(f"  Effect: \"{override.message}\"")

    else:
        print(f"Unknown rule type: {rule_type}. Use 'ethical' or 'human-override'.", file=sys.stderr)
        sys.exit(1)


def _cmd_config(args: argparse.Namespace) -> None:
    """Manage Nomotic configuration values."""
    config_cmd = getattr(args, "config_command", None)
    if config_cmd == "set":
        _cmd_config_set(args)
        return
    if config_cmd == "backup":
        _cmd_config_backup(args)
        return
    # No subcommand — show help
    print("Usage: nomotic config set --retention <period>", file=sys.stderr)
    print("       nomotic config set --telemetry on|off", file=sys.stderr)
    print("       nomotic config backup [list|verify|restore]", file=sys.stderr)
    print("  Set global configuration values or manage backups.", file=sys.stderr)
    print()
    print("  Options:", file=sys.stderr)
    print("    --retention   Audit retention period (2y, 3y, 5y, forever)", file=sys.stderr)
    print("    --telemetry   Enable/disable anonymous usage telemetry (on, off)", file=sys.stderr)
    sys.exit(1)


def _load_simulated_trust(base_dir: Path, agent_id: str, production_trust: float) -> float:
    """Load simulated trust, resetting if stale (>1 hour old)."""
    import time as _time

    trust_file = base_dir / "testlog" / f"{agent_id.lower()}.trust.json"
    if trust_file.exists():
        try:
            data = json.loads(trust_file.read_text(encoding="utf-8"))
            age = _time.time() - data.get("last_updated", 0)
            if age < 3600:  # 1 hour
                return data.get("simulated_trust", production_trust)
        except (json.JSONDecodeError, KeyError):
            pass
    return production_trust


def _save_simulated_trust(
    base_dir: Path, agent_id: str, simulated: float, production: float,
) -> None:
    """Save simulated trust state."""
    import time as _time

    testlog_dir = base_dir / "testlog"
    testlog_dir.mkdir(parents=True, exist_ok=True)
    trust_file = testlog_dir / f"{agent_id.lower()}.trust.json"
    trust_file.write_text(json.dumps({
        "simulated_trust": simulated,
        "production_trust_at_start": production,
        "last_updated": _time.time(),
    }, indent=2), encoding="utf-8")


def _cmd_test(args: argparse.Namespace) -> None:
    """Run a simulated governance evaluation. Does not affect production trust."""

    # ── adversarial mode ──────────────────────────────────────────
    if getattr(args, "adversarial", False):
        _run_adversarial(args)
        return

    # ── single-action mode (original behaviour) ──────────────────
    if not args.action:
        print("error: --action is required (or use --adversarial)", file=sys.stderr)
        sys.exit(1)

    from nomotic.sandbox import (
        AgentConfig,
        build_sandbox_runtime,
        load_agent_config,
    )

    from nomotic.sandbox import format_bar
    from nomotic.types import Action as GovAction, AgentContext as GovCtx, Verdict

    agent_id = args.agent_id
    action_type = args.action
    target = args.target or ""
    params = {}
    if args.params:
        try:
            params = json.loads(args.params)
        except json.JSONDecodeError:
            print(f"Invalid JSON for --params: {args.params}", file=sys.stderr)
            sys.exit(1)

    # Load agent config
    config = load_agent_config(args.base_dir, agent_id)
    if config is None:
        config = AgentConfig(agent_id=agent_id)

    # Load certificate for production trust
    ca, _store = _build_ca(args.base_dir)
    from nomotic.sandbox import find_agent_cert_id
    cert_id = find_agent_cert_id(args.base_dir, agent_id)
    cert = ca.get(cert_id) if cert_id else None
    production_trust = cert.trust_score if cert else 0.5

    # Load simulated trust (or reset from production)
    simulated_trust = _load_simulated_trust(args.base_dir, agent_id, production_trust)

    # Build runtime and evaluate using simulated trust
    runtime = build_sandbox_runtime(agent_config=config, agent_id=agent_id)
    trust_profile = runtime.get_trust_profile(agent_id)
    trust_profile.overall_trust = simulated_trust

    action = GovAction(
        agent_id=agent_id,
        action_type=action_type,
        target=target,
        parameters=params,
    )
    ctx = GovCtx(agent_id=agent_id, trust_profile=trust_profile)

    verdict = runtime.evaluate(action, ctx)

    # Calculate simulated trust delta
    new_simulated = runtime.get_trust_profile(agent_id).overall_trust
    sim_delta = new_simulated - simulated_trust
    new_simulated = round(max(0.0, min(1.0, new_simulated)), 3)

    # Save simulated trust (do NOT touch production)
    _save_simulated_trust(args.base_dir, agent_id, new_simulated, production_trust)

    # Display results
    print()
    print(_bold(_cyan("=" * 55)))
    print(_bold(_cyan("  TEST EVALUATION (simulated \u2014 does not affect production trust)")))
    print(_bold(_cyan("=" * 55)))
    print()
    print(f"  Agent:   {agent_id}")
    target_str = f" {chr(8594)} {target}" if target else ""
    print(f"  Action:  {action_type}{target_str}")
    if params:
        print(f"  Params:  {json.dumps(params)}")
    print()

    # Dimension scores
    print(f"  {_bold(chr(9472) * 2 + ' Dimension Scores ' + chr(9472) * 30)}")
    print()

    for ds in verdict.dimension_scores:
        bar = format_bar(ds.score, 20)
        name_padded = f"{ds.dimension_name:26s}"
        score_str = f"{ds.score:.2f}"

        if ds.veto and ds.score < 0.5:
            check = _red(f"{chr(10007)} VETO: {ds.reasoning}")
            color_score = _red(score_str)
        elif ds.score >= 0.7:
            check = _green(ds.reasoning)
            color_score = _green(score_str)
        elif ds.score >= 0.4:
            check = _yellow(ds.reasoning)
            color_score = _yellow(score_str)
        else:
            check = _red(ds.reasoning)
            color_score = _red(score_str)

        print(f"  {name_padded} {color_score}  {bar}  {check}")

    # Decision
    print()
    print(f"  {_bold(chr(9472) * 2 + ' Decision ' + chr(9472) * 38)}")
    print()

    ucs_str = f"{verdict.ucs:.3f}"
    tier_labels = {1: "veto gate", 2: "threshold evaluation", 3: "deliberative review"}
    tier_label = tier_labels.get(verdict.tier, "unknown")

    if verdict.verdict == Verdict.ALLOW:
        verdict_display = _green(f"{chr(9989)} ALLOW")
    elif verdict.verdict == Verdict.DENY:
        verdict_display = _red(f"{chr(10060)} DENY")
    elif verdict.verdict == Verdict.ESCALATE:
        verdict_display = _yellow(f"{chr(9888)} ESCALATE")
    else:
        verdict_display = _yellow(f"{chr(9888)} {verdict.verdict.name}")

    print(f"  UCS:      {ucs_str}")
    print(f"  Tier:     {verdict.tier} ({tier_label})")
    print(f"  Verdict:  {verdict_display}")
    if verdict.vetoed_by:
        print(f"  Vetoed by: {', '.join(verdict.vetoed_by)}")
    if verdict.reasoning:
        print(f"  Reason:   {verdict.reasoning}")
    print(f"  Time:     {verdict.evaluation_time_ms:.1f}ms")

    # Trust (Simulated)
    sign = "+" if sim_delta >= 0 else ""
    delta_color = _green if sim_delta > 0 else (_red if sim_delta < 0 else _yellow)

    trend = "stable"
    if sim_delta > 0.001:
        trend = f"{chr(8599)} rising"
    elif sim_delta < -0.001:
        trend = f"{chr(8600)} falling"

    print()
    print(f"  {_bold(chr(9472) * 2 + ' Trust (Simulated) ' + chr(9472) * 29)}")
    print()
    print(f"  Production trust:  {production_trust:.3f} (unchanged)")
    delta_str = delta_color(f'{sign}{sim_delta:.3f}')
    print(
        f"  Simulated:         {simulated_trust:.3f}"
        f" {chr(8594)} {new_simulated:.3f}  ({delta_str})"
    )
    print(f"  Trend:             {trend}")

    if sim_delta < -0.01:
        ratio = abs(sim_delta) / 0.01
        print()
        print(f"  {_yellow(chr(9888))} Note: violations cost 5x more trust than successes earn.")
        if ratio > 1:
            print(f"  This one denial erased ~{int(ratio)} successful actions.")
    print()
    print(f"  {_yellow(chr(9888))} This is a test. Production trust is not affected.")
    print(f"  Test history: nomotic testlog {agent_id}")
    print()

    # Persist to testlog (NOT audit)
    import time as _time
    from nomotic.audit_store import LogStore, PersistentLogRecord

    test_store = LogStore(args.base_dir, "testlog")
    previous_hash = test_store.get_last_hash(agent_id)

    dim_scores = {ds.dimension_name: ds.score for ds in verdict.dimension_scores}
    vetoed = list(verdict.vetoed_by) if verdict.vetoed_by else []

    record_data = {
        "record_id": verdict.action_id[:12],
        "timestamp": _time.time(),
        "agent_id": agent_id,
        "action_type": action_type,
        "action_target": target,
        "verdict": verdict.verdict.name,
        "ucs": verdict.ucs,
        "tier": verdict.tier,
        "trust_score": new_simulated,
        "trust_delta": sim_delta,
        "trust_trend": trend.replace("\u2197 ", "").replace("\u2198 ", ""),
        "severity": "alert" if verdict.verdict.name == "DENY" else "info",
        "justification": verdict.reasoning or "",
        "vetoed_by": vetoed,
        "dimension_scores": dim_scores,
        "parameters": params,
        "source": "cli-test",
        "previous_hash": previous_hash,
        "record_hash": "",
    }
    record_data["record_hash"] = test_store.compute_hash(record_data, previous_hash)

    test_record = PersistentLogRecord(**record_data)
    test_store.append(test_record)


def _run_adversarial(args: argparse.Namespace) -> None:
    """Run adversarial red team scenarios against an agent."""
    from nomotic.adversarial import (
        AdversarialRunner,
        CATEGORIES,
        format_report,
        format_summary,
    )

    agent_id = args.agent_id
    category = getattr(args, "category", None)
    detailed = getattr(args, "report", False)

    # Validate category if provided
    if category and category not in CATEGORIES:
        valid = ", ".join(sorted(CATEGORIES))
        print(f"Unknown category: {category}", file=sys.stderr)
        print(f"Valid categories: {valid}", file=sys.stderr)
        sys.exit(1)

    runner = AdversarialRunner(base_dir=args.base_dir, agent_id=agent_id)

    if category:
        results = runner.run_category(category)
    else:
        results = runner.run_all()

    if detailed:
        print(format_report(results, agent_id))
    else:
        print(format_summary(results, agent_id))


def _cmd_simulate(args: argparse.Namespace) -> None:
    """Dispatch simulate sub-commands: batch, fleet, stop, status, report."""
    sim_cmd = getattr(args, "sim_cmd", None)
    if sim_cmd == "batch":
        _sim_batch(args)
    elif sim_cmd == "fleet":
        _sim_fleet(args)
    elif sim_cmd == "stop":
        _sim_stop(args)
    elif sim_cmd == "status":
        _sim_status(args)
    elif sim_cmd == "report":
        _sim_report(args)
    else:
        print("Usage: nomotic simulate batch|fleet|stop|status|report")
        sys.exit(1)


def _sim_batch(args: argparse.Namespace) -> None:
    """Run a batch simulation of governance evaluations (single agent)."""
    from nomotic.sandbox import (
        AgentConfig,
        build_sandbox_runtime,
        format_pct_bar,
        load_agent_config,
    )
    from nomotic.scenarios import BUILTIN_SCENARIOS, generate_actions
    from nomotic.types import AgentContext as GovCtx

    agent_id = args.agent_id
    scenario_name = args.scenario
    count = args.count

    if scenario_name not in BUILTIN_SCENARIOS:
        print(f"Unknown scenario: {scenario_name}", file=sys.stderr)
        print(f"Available: {', '.join(BUILTIN_SCENARIOS.keys())}", file=sys.stderr)
        sys.exit(1)

    scenario = BUILTIN_SCENARIOS[scenario_name]

    # Load agent config
    config = load_agent_config(args.base_dir, agent_id)
    if config is None:
        config = AgentConfig(agent_id=agent_id)

    # Load initial trust from cert
    ca, _store = _build_ca(args.base_dir)
    from nomotic.sandbox import find_agent_cert_id
    cert_id = find_agent_cert_id(args.base_dir, agent_id)
    cert = ca.get(cert_id) if cert_id else None
    initial_trust = cert.trust_score if cert else 0.5

    # Build runtime
    runtime = build_sandbox_runtime(agent_config=config, agent_id=agent_id)
    trust_profile = runtime.get_trust_profile(agent_id)
    trust_profile.overall_trust = initial_trust

    # Generate actions
    actions = generate_actions(agent_id, scenario, total_count=count if count else None)

    # Prepare audit store for persistent records
    import time as _time
    from nomotic.audit_store import AuditStore, PersistentAuditRecord

    audit_store = AuditStore(args.base_dir)

    # Run simulation
    print()
    print(f"  {_bold(f'Simulating: {scenario.description}')}")
    print()

    trust_history: list[float] = [initial_trust]
    results = {"ALLOW": 0, "DENY": 0, "ESCALATE": 0, "MODIFY": 0}
    current_phase = ""
    previous_hash = audit_store.get_last_hash(agent_id)

    for i, (action, phase_desc) in enumerate(actions):
        if phase_desc != current_phase:
            current_phase = phase_desc
            print(f"  {_cyan(f'Phase: {phase_desc}')}")

        prev_trust = runtime.get_trust_profile(agent_id).overall_trust
        ctx = GovCtx(agent_id=agent_id, trust_profile=runtime.get_trust_profile(agent_id))
        verdict = runtime.evaluate(action, ctx)
        results[verdict.verdict.name] = results.get(verdict.verdict.name, 0) + 1
        new_trust = runtime.get_trust_profile(agent_id).overall_trust
        trust_history.append(new_trust)

        # Persist audit record
        delta = new_trust - prev_trust
        trend = "stable"
        if delta > 0.001:
            trend = "rising"
        elif delta < -0.001:
            trend = "falling"

        dim_scores = {ds.dimension_name: ds.score for ds in verdict.dimension_scores}
        vetoed = list(verdict.vetoed_by) if verdict.vetoed_by else []

        record_data = {
            "record_id": verdict.action_id[:12],
            "timestamp": _time.time(),
            "agent_id": agent_id,
            "action_type": action.action_type,
            "action_target": action.target,
            "verdict": verdict.verdict.name,
            "ucs": verdict.ucs,
            "tier": verdict.tier,
            "trust_score": new_trust,
            "trust_delta": delta,
            "trust_trend": trend,
            "severity": "alert" if verdict.verdict.name == "DENY" else "info",
            "justification": verdict.reasoning or "",
            "vetoed_by": vetoed,
            "dimension_scores": dim_scores,
            "parameters": dict(action.parameters) if action.parameters else {},
            "source": "cli-simulate",
            "previous_hash": previous_hash,
            "record_hash": "",
        }
        record_data["record_hash"] = audit_store.compute_hash(record_data, previous_hash)
        audit_record = PersistentAuditRecord(**record_data)
        audit_store.append(audit_record)
        previous_hash = record_data["record_hash"]

        # Progress indicator
        total = len(actions)
        bar_width = 40
        filled = int((i + 1) / total * bar_width)
        bar = chr(9608) * filled + chr(9617) * (bar_width - filled)
        print(f"\r  [{bar}] {i + 1}/{total}", end="", flush=True)

    print()  # newline after progress bar
    print()

    # Behavioral Fingerprint
    fp = runtime.get_fingerprint(agent_id)
    if fp is not None:
        print(f"  {_bold(chr(9472) * 2 + ' Behavioral Fingerprint ' + chr(9472) * 24)}")
        print()
        print(f"  Observations: {fp.total_observations}")
        print(f"  Confidence:   {fp.confidence:.2f}")
        print()

        if fp.action_distribution:
            print("  Action Distribution:")
            for act, freq in sorted(fp.action_distribution.items(), key=lambda x: -x[1]):
                bar = format_pct_bar(freq)
                print(f"    {act:20s} {bar}  {freq:.0%}")
            print()

        if fp.target_distribution:
            print("  Target Distribution:")
            for tgt, freq in sorted(fp.target_distribution.items(), key=lambda x: -x[1]):
                bar = format_pct_bar(freq)
                print(f"    {tgt:20s} {bar}  {freq:.0%}")
            print()

    # Drift detection
    drift = runtime.get_drift(agent_id)
    if drift is not None and drift.overall > 0.05:
        print(f"  {_bold(chr(9472) * 2 + ' Drift Detection Report ' + chr(9472) * 24)}")
        print()
        sev = drift.severity
        color = _red if sev in ("high", "critical") else (_yellow if sev == "moderate" else _green)
        print(f"  Drift Score:    {color(f'{drift.overall:.2f}')} ({sev.upper()})")
        print(f"  JSD Divergence: {drift.action_drift:.2f}")
        if drift.detail:
            print(f"  Detail:         {drift.detail}")
        print()

        # Show alerts
        alerts = runtime.get_drift_alerts(agent_id)
        if alerts:
            for alert in alerts:
                sev_color = _red if alert.severity in ("critical", "high") else _yellow
                print(f"  {sev_color(chr(9888))} DRIFT ALERT:")
                print(f"    Severity: {alert.severity.upper()}")
                if alert.drift_score.detail:
                    print(f"    Message:  {alert.drift_score.detail}")
            print()

    # Trust trajectory
    print(f"  {_bold(chr(9472) * 2 + ' Trust Trajectory ' + chr(9472) * 30)}")
    print()
    end_trust = trust_history[-1]
    trend = "stable"
    if end_trust > initial_trust + 0.02:
        trend = "rising"
    elif end_trust < initial_trust - 0.02:
        trend = "falling"

    print(f"  Start: {initial_trust:.3f} {chr(8594)} End: {end_trust:.3f}")
    print(f"  Trend: {trend}")
    print()

    # Visual trust trajectory
    n_rows = 6
    min_t = min(trust_history)
    max_t = max(trust_history)
    t_range = max_t - min_t if max_t > min_t else 0.1
    chart_width = min(40, len(trust_history))
    step = max(1, len(trust_history) // chart_width)
    sampled = [trust_history[i] for i in range(0, len(trust_history), step)]

    for row in range(n_rows, -1, -1):
        level = min_t + (row / n_rows) * t_range
        label = f"  {level:.2f} |"
        chars = []
        for val in sampled:
            val_row = int((val - min_t) / t_range * n_rows) if t_range > 0 else n_rows // 2
            if val_row == row:
                chars.append(".")
            elif val_row > row:
                chars.append(" ")
            else:
                chars.append(" ")
        print(f"{label}{''.join(chars)}|")
    total_actions = len(actions)
    print(f"         {chr(9492)}{chr(9472) * len(sampled)}{chr(9496)}")
    label_str = f"         0{' ' * (len(sampled) - len(str(total_actions)) - 1)}{total_actions}"
    print(label_str)
    print()

    # Summary
    allowed = results.get("ALLOW", 0)
    denied = results.get("DENY", 0)
    escalated = results.get("ESCALATE", 0)

    print(f"  {_green(chr(10003))} {total_actions} actions evaluated")
    print(f"  {_green(chr(10003))} {_green(str(allowed))} allowed, {_red(str(denied))} denied", end="")
    if escalated:
        print(f", {_yellow(str(escalated))} escalated", end="")
    print()
    if fp:
        print(f"  {_green(chr(10003))} Fingerprint established")
    print(f"  {_green(chr(10003))} Trust trajectory: {trend}")
    print()

    # Update certificate trust
    if cert is not None:
        ca.update_trust(cert.certificate_id, end_trust)


# ── Fleet simulation handlers ──────────────────────────────────────────


def _sim_fleet(args: argparse.Namespace) -> None:
    """Run a multi-department fleet simulation with real governance."""
    import time as _time

    from nomotic.fleet_sim import FleetSimulator, SimulationConfig, DEPARTMENTS

    agent_count = min(args.agents, 2000)
    departments = args.departments or list(DEPARTMENTS.keys())

    config = SimulationConfig(
        scenario=args.scenario,
        agent_count=agent_count,
        departments=departments,
        evaluations_per_second=args.rate,
    )

    print()
    print(_bold(_cyan("  Nomotic Fleet Simulation")))
    print(_bold(_cyan("  " + "\u2500" * 40)))
    print()
    print(f"  Scenario:    {args.scenario}")
    print(f"  Agents:      {agent_count:,}")
    print(f"  Departments: {len(departments)}")
    print(f"  Rate:        {args.rate} evaluations/sec")
    print("  Engine:      Real governance \u2014 UCS evaluation, trust tracking, audit trail")
    print()

    sim = FleetSimulator(config)
    print("  Provisioning agents and issuing certificates...")
    sim.provision_agents()
    print(f"  {_green(chr(10003))} {agent_count:,} agents provisioned")
    print()

    sim.start()
    print(f"  {_green(chr(10003))} Simulation running")

    if getattr(args, "serve_dashboard", False):
        print(f"  {_green(chr(10003))} Dashboard: http://localhost:8080/ui  (Ctrl+C to stop)")
        print()

    watch_interval = getattr(args, "watch_interval", 5)
    duration = getattr(args, "duration", 0)

    if getattr(args, "watch", False):
        _watch_loop(sim, watch_interval, duration)
        _print_sim_report(sim)
        sim.stop()
        print(f"\n  {_green(chr(10003))} Simulation stopped. State cleared.")
    elif duration > 0:
        print(f"  Running for {duration}s... (Ctrl+C to stop early)")
        try:
            _time.sleep(duration)
        except KeyboardInterrupt:
            pass
        _print_sim_report(sim)
        sim.stop()
        print(f"\n  {_green(chr(10003))} Simulation stopped. State cleared.")
    else:
        print("  Running... Press Ctrl+C to stop and print final report.")
        try:
            while True:
                _time.sleep(1)
        except KeyboardInterrupt:
            print()
            _print_sim_report(sim)
            sim.stop()
            print(f"\n  {_green(chr(10003))} Simulation stopped. State cleared.")


def _watch_loop(sim, interval: int, duration: int) -> None:
    """Print live stats table, refreshing every N seconds."""
    import time as _time

    start = _time.time()
    try:
        while True:
            print("\033[2J\033[H", end="")  # clear screen
            snap = sim.stats_snapshot()
            _print_watch_table(snap)
            if duration > 0 and (_time.time() - start) >= duration:
                break
            _time.sleep(interval)
    except KeyboardInterrupt:
        pass


def _print_watch_table(snap: dict) -> None:
    """Render a CASA-style live stats table to the terminal."""
    total = snap["total_evaluations"]
    governed = snap["total_governed"]
    refused = snap["total_refused"]
    gov_pct = snap["governance_rate_pct"]
    deny_pct = snap["denial_rate_pct"]
    agents = snap["total_agents"]
    elapsed = int(snap["elapsed_seconds"])

    print(_bold(_cyan(f"  NOMOTIC FLEET SIMULATION \u2014 {snap['scenario'].upper()}")))
    print()
    print(f"  {'TOTAL CALLS':<18} {'GOVERNED':<18} {'REFUSED':<18} {'DENIAL RATE':<18} {'AGENTS':<12}")
    print(f"  {_bold(f'{total:,}'):<18} {_bold(_cyan(f'{governed:,}')):<18} "
          f"{_bold(_red(f'{refused:,}')):<18} {_bold(_yellow(f'{deny_pct:.2f}%')):<18} "
          f"{_bold(str(agents)):<12}")
    print(f"  {'across all depts':<18} {f'{gov_pct:.1f}% of evals':<18} "
          f"{'blocked by engine':<18} {'fleet average':<18} {f'elapsed {elapsed}s':<12}")
    print()

    # Department breakdown
    print(f"  {'DEPARTMENT BREAKDOWN'}")
    print(f"  {'DEPT':<22} {'CALLS':>8} {'GOVERNED':>10} {'REFUSED':>9} {'DIV%':>7}")
    _h = "\u2500"
    print(f"  {_h * 22} {_h * 8} {_h * 10} {_h * 9} {_h * 7}")
    for dept, stats in snap["department_breakdown"].items():
        calls = stats["calls"]
        gov = stats["governed"]
        ref = stats["refused"]
        div = stats["divergence_pct"]
        ref_disp = _red(f"{ref:,}") if ref > 0 else f"{ref}"
        div_disp = _yellow(f"{div:.1f}%") if div > 2.0 else f"{div:.1f}%"
        print(f"  {dept:<22} {calls:>8,} {_cyan(str(gov)):>10} {ref_disp:>9} {div_disp:>7}")
    print()

    # Top denied tools
    print("  TOP REFUSED ACTIONS")
    for item in snap["top_denied_tools"][:8]:
        bar_len = min(30, item["count"])
        bar = _red("\u2588" * bar_len)
        print(f"  {item['tool']:<35} {bar} {_red(str(item['count']))}")
    print()


def _print_sim_report(sim) -> None:
    """Print final simulation report."""
    snap = sim.stats_snapshot()
    print()
    print(_bold("  Simulation Report"))
    print(f"  Total evaluations: {snap['total_evaluations']:,}")
    print(f"  Denials:           {snap['total_refused']:,} ({snap['denial_rate_pct']:.2f}%)")
    print(f"  Escalations:       {snap['total_escalated']:,}")
    elapsed = int(snap["elapsed_seconds"])
    print(f"  Elapsed:           {elapsed}s ({elapsed / 60:.1f} min)")
    print()


def _sim_stop(args: argparse.Namespace) -> None:
    """Stop a running fleet simulation."""
    from nomotic.fleet_sim import FleetSimulator

    state_path = FleetSimulator.STATE_PATH
    if state_path.exists():
        state_path.unlink()
        print(f"  {_green(chr(10003))} Simulation state cleared.")
    else:
        print("  No simulation is running.")


def _sim_status(args: argparse.Namespace) -> None:
    """Show fleet simulation status."""
    from nomotic.fleet_sim import FleetSimulator

    state_path = FleetSimulator.STATE_PATH
    if not state_path.exists():
        print("  No simulation running.")
        return
    state = json.loads(state_path.read_text())
    print(f"  Simulation: {state['config']['scenario']}")
    print(f"  Agents:     {state['agent_count']:,}")
    print(f"  Started:    {state['started_at']}")


def _sim_report(args: argparse.Namespace) -> None:
    """Print report from last simulation (placeholder for cross-process reporting)."""
    from nomotic.fleet_sim import FleetSimulator

    state_path = FleetSimulator.STATE_PATH
    if not state_path.exists():
        print("  No simulation data available. Run 'nomotic simulate fleet' first.")
        return
    state = json.loads(state_path.read_text())
    fmt = getattr(args, "format", "table")
    if fmt == "json":
        print(json.dumps(state, indent=2))
    else:
        print(f"  Simulation: {state['config']['scenario']}")
        print(f"  Agents:     {state['agent_count']:,}")
        print(f"  Started:    {state['started_at']}")


def _cmd_config_set(args: argparse.Namespace) -> None:
    """Handle 'nomotic config set --retention <period>' or '--telemetry on/off'."""
    handled = False

    if args.retention is not None:
        valid_periods = {"2y", "3y", "5y", "forever"}
        if args.retention not in valid_periods:
            print(f"Invalid retention period: {args.retention}", file=sys.stderr)
            print(f"  Valid values: {', '.join(sorted(valid_periods))}", file=sys.stderr)
            sys.exit(1)
        config_path = args.base_dir / "config.json"
        config_data: dict = {}
        if config_path.exists():
            config_data = json.loads(config_path.read_text(encoding="utf-8"))
        config_data["retention"] = args.retention
        args.base_dir.mkdir(parents=True, exist_ok=True)
        config_path.write_text(json.dumps(config_data, indent=2), encoding="utf-8")
        print(f"Retention set to: {args.retention}")
        print("  Note: Retention is recorded but not yet enforced (all records are kept).")
        handled = True

    if getattr(args, "telemetry", None) is not None:
        value = "y" if args.telemetry == "on" else "n"
        config_path = args.base_dir / "config.json"
        config_data = {}
        if config_path.exists():
            config_data = json.loads(config_path.read_text(encoding="utf-8"))
        config_data["telemetry_enabled"] = value
        args.base_dir.mkdir(parents=True, exist_ok=True)
        config_path.write_text(json.dumps(config_data, indent=2), encoding="utf-8")
        status = "enabled" if args.telemetry == "on" else "disabled"
        print(f"Telemetry {status}.")
        from nomotic.telemetry import reset_telemetry_singleton
        reset_telemetry_singleton()
        handled = True

    if not handled:
        print("No configuration value specified.", file=sys.stderr)
        print("  Use --retention to set audit retention period.", file=sys.stderr)
        print("  Use --telemetry on/off to toggle anonymous telemetry.", file=sys.stderr)
        sys.exit(1)


def _cmd_config_backup(args: argparse.Namespace) -> None:
    """Handle 'nomotic config backup' commands."""
    from nomotic.config_backup import ConfigBackupManager

    base_dir: Path = args.base_dir

    # Load signing secret from config
    config = _load_nomotic_config(base_dir)
    signing_secret = config.get("config_backup_signing_secret", "")
    if not signing_secret:
        print("Config backup signing secret not configured.", file=sys.stderr)
        print("  Set 'config_backup_signing_secret' in config.json.", file=sys.stderr)
        sys.exit(1)

    max_per_type = config.get("config_backup_max_per_type", 5)
    mgr = ConfigBackupManager(
        base_dir=base_dir,
        signing_secret=signing_secret,
        max_backups_per_type=max_per_type,
    )

    backup_cmd = getattr(args, "backup_command", None)

    if backup_cmd == "list":
        _cmd_config_backup_list(mgr, args)
    elif backup_cmd == "verify":
        _cmd_config_backup_verify(mgr, args)
    elif backup_cmd == "restore":
        _cmd_config_backup_restore(mgr, args)
    else:
        # Default: create backups now
        _cmd_config_backup_create(mgr, base_dir)


def _cmd_config_backup_create(mgr: Any, base_dir: Path) -> None:
    """Create backups of governance artifacts."""
    print(_bold("Backing up governance configuration..."))
    print()

    backed_up = 0
    total = 3

    # Constitutional ruleset
    ruleset_path = base_dir / "constitution.json"
    if ruleset_path.exists():
        try:
            from nomotic.constitution import ConstitutionalRuleSet
            ruleset = ConstitutionalRuleSet.from_file(ruleset_path)
            backup = mgr.backup("constitutional_ruleset", ruleset.to_dict())
            size = len(json.dumps(backup.content))
            print(f"  {_green('✓')} constitutional_ruleset  →  {backup.backup_id} ({size}B)")
            backed_up += 1
        except Exception as exc:
            print(f"  {_red('✗')} constitutional_ruleset  →  error: {exc}")
    else:
        print(f"  {_red('✗')} constitutional_ruleset  →  not configured")

    # Authority registry
    registry_path = base_dir / "authority_registry.json"
    if registry_path.exists():
        try:
            from nomotic.authority_registry import GovernanceAuthorityRegistry
            registry = GovernanceAuthorityRegistry()
            registry.load_from_file(registry_path)
            content = {"authorities": [a.to_dict() for a in registry.list_authorities()]}
            backup = mgr.backup("authority_registry", content)
            size = len(json.dumps(backup.content))
            print(f"  {_green('✓')} authority_registry      →  {backup.backup_id} ({size}B)")
            backed_up += 1
        except Exception as exc:
            print(f"  {_red('✗')} authority_registry      →  error: {exc}")
    else:
        print(f"  {_red('✗')} authority_registry      →  not configured")

    # Role registry
    role_candidates = [
        Path("nomotic-roles.yaml"),
        Path("nomotic-roles.json"),
        base_dir / "roles.yaml",
    ]
    roles_file = None
    for c in role_candidates:
        if c.exists():
            roles_file = c
            break

    if roles_file is not None:
        try:
            from nomotic.roles import RoleRegistry
            reg = RoleRegistry()
            reg.load_from_file(roles_file)
            content = {"roles": [r.to_dict() for r in reg.list_roles()]}
            backup = mgr.backup("role_registry", content)
            size = len(json.dumps(backup.content))
            print(f"  {_green('✓')} role_registry           →  {backup.backup_id} ({size}B)")
            backed_up += 1
        except Exception as exc:
            print(f"  {_red('✗')} role_registry           →  error: {exc}")
    else:
        print(f"  {_red('✗')} role_registry           →  not configured")

    print()
    print(f"{backed_up} of {total} artifacts backed up.")


def _cmd_config_backup_list(mgr: Any, args: argparse.Namespace) -> None:
    """List available backups."""

    filter_type = getattr(args, "type", None)
    print(_bold("Configuration Backups"))
    print()

    from nomotic.config_backup import ConfigBackupManager
    types = [filter_type] if filter_type else sorted(ConfigBackupManager.VALID_ARTIFACT_TYPES)

    for artifact_type in types:
        backups = mgr.list_backups(artifact_type)
        print(f"  {_bold(artifact_type)}")
        if not backups:
            print("    (no backups)")
        else:
            for b in backups:
                dt = datetime.fromtimestamp(b.created_at, tz=timezone.utc)
                date_str = dt.strftime("%Y-%m-%d %H:%M")
                size = len(json.dumps(b.content))
                valid = b.verify(mgr._secret)
                status = f"{_green('✓')} VERIFIED" if valid else f"{_red('✗')} INVALID"
                print(f"    {b.backup_id}   {date_str}   {size}B   {status}")
        print()


def _cmd_config_backup_verify(mgr: Any, args: argparse.Namespace) -> None:
    """Verify backup signatures."""
    filter_type = getattr(args, "type", None)
    print(_bold("Backup Verification"))
    print()

    from nomotic.config_backup import ConfigBackupManager
    types = [filter_type] if filter_type else sorted(ConfigBackupManager.VALID_ARTIFACT_TYPES)

    for artifact_type in types:
        valid, msg = mgr.verify_latest(artifact_type)
        if "No backups" in msg:
            print(f"  {artifact_type:<30s} (no backups)")
        elif valid:
            backup_id = msg.split(": ", 1)[-1] if ": " in msg else "unknown"
            print(f"  {artifact_type:<30s} {backup_id}   {_green('✓')} SIGNATURE VALID")
        else:
            print(f"  {artifact_type:<30s} {_red('✗')} SIGNATURE FAILED")


def _cmd_config_backup_restore(mgr: Any, args: argparse.Namespace) -> None:
    """Restore latest verified backup."""
    artifact_type = getattr(args, "artifact_type", None)
    if not artifact_type:
        print("Usage: nomotic config backup restore <artifact_type>", file=sys.stderr)
        sys.exit(1)

    from nomotic.config_backup import ConfigBackupManager
    if artifact_type not in ConfigBackupManager.VALID_ARTIFACT_TYPES:
        print(f"Unknown artifact type: {artifact_type}", file=sys.stderr)
        print(f"  Valid types: {', '.join(sorted(ConfigBackupManager.VALID_ARTIFACT_TYPES))}", file=sys.stderr)
        sys.exit(1)

    backups = mgr.list_backups(artifact_type)
    if not backups:
        print(f"No backups found for {artifact_type}.")
        sys.exit(1)

    latest = backups[0]
    valid = latest.verify(mgr._secret)

    print(f"Restoring {artifact_type} from {latest.backup_id}...")
    print()

    dt = datetime.fromtimestamp(latest.created_at, tz=timezone.utc)
    age_seconds = datetime.now(timezone.utc).timestamp() - latest.created_at
    if age_seconds < 60:
        age_str = f"{age_seconds:.0f} seconds ago"
    elif age_seconds < 3600:
        age_str = f"{age_seconds / 60:.0f} minutes ago"
    elif age_seconds < 86400:
        age_str = f"{age_seconds / 3600:.1f} hours ago"
    else:
        age_str = f"{age_seconds / 86400:.1f} days ago"

    if valid:
        print(f"  Verified: {_green('✓')} SIGNATURE VALID")
    else:
        print(f"  Verified: {_red('✗')} SIGNATURE FAILED")
        print()
        print("  WARNING: This backup failed signature verification.")
        print("  The content may have been tampered with.")
        sys.exit(1)

    print(f"  Created:  {dt.strftime('%Y-%m-%d %H:%M')} ({age_str})")
    print()
    print("  Content (JSON):")
    print(json.dumps(latest.content, indent=2))
    print()
    print("  NOTE: This output shows the backup content only.")
    print("  To apply, reload your runtime configuration with this data.")


def _cmd_history(args: argparse.Namespace) -> None:
    """Show the complete historical record for any agent (including revoked)."""
    numeric_id, name, cert_id = _resolve_agent(args.base_dir, args.identifier)

    ca, _store = _build_ca(args.base_dir)
    cert = ca.get(cert_id)

    registry = _load_registry(args.base_dir)
    entry = registry.get(numeric_id) if numeric_id > 0 else None

    status = "UNKNOWN"
    revoked_at = ""
    reason = ""
    seal_data: dict = {}

    if entry:
        status = entry.get("status", "UNKNOWN")
    elif cert:
        status = cert.status.name

    # Check for revocation seal
    seal_path = args.base_dir / "revocations" / f"{numeric_id}.json"
    if seal_path.exists():
        try:
            seal_data = json.loads(seal_path.read_text(encoding="utf-8"))
            revoked_at = seal_data.get("revoked_at", "")
            reason = seal_data.get("reason", "")
        except (json.JSONDecodeError, KeyError):
            pass

    # Load audit store data
    from nomotic.audit_store import AuditStore
    audit_store = AuditStore(args.base_dir)
    audit_summary = audit_store.summary(name)
    is_valid, chain_count, chain_msg = audit_store.verify_chain(name)

    print()
    print(f"History: {name} (ID: {numeric_id})")

    if status == "REVOKED" and revoked_at:
        print(f"  Status: {_red('REVOKED')} ({revoked_at[:10]})")
    else:
        status_color = _green if status == "ACTIVE" else (_yellow if status == "SUSPENDED" else _dim)
        print(f"  Status: {status_color(status)}")
    print(f"  {'─' * 37}")
    print()

    # Lifecycle
    print("  Lifecycle:")
    if cert:
        print(f"    Born:     {cert.issued_at.strftime('%Y-%m-%d %H:%M')}  (trust: 0.500)")
    elif entry:
        created = entry.get("created_at", "unknown")
        print(f"    Born:     {created[:16] if len(created) >= 16 else created}  (trust: 0.500)")

    if seal_data:
        peak_trust = seal_data.get("peak_trust", 0.5)
        final_trust = seal_data.get("final_trust", 0.05)
        total_evals = seal_data.get("total_evaluations", 0)
        total_violations = seal_data.get("total_violations", 0)
        print(f"    Peak:     (trust: {peak_trust:.3f})")
        if revoked_at:
            print(f"    Revoked:  {revoked_at[:16]}  (trust: {final_trust:.3f})")
        if reason:
            print(f"    Reason:   {reason}")

        print()
        print("  Summary:")
        allowed = total_evals - total_violations
        violation_rate = (total_violations / total_evals * 100) if total_evals > 0 else 0.0
        print(f"    Total evaluations:  {total_evals}")
        print(f"    Allowed:            {allowed}")
        print(f"    Denied:             {total_violations}")
        print(f"    Violation rate:     {violation_rate:.1f}%")

        audit_seal = seal_data.get("audit_seal", "")
        if audit_seal:
            print()
            print(f"  Audit seal: {audit_seal}")

        chain_verified = seal_data.get("chain_records", 0)
        if chain_verified > 0:
            print(f"  Chain integrity: verified ({chain_verified} records)")
    elif cert:
        trust = cert.trust_score
        age = cert.behavioral_age
        print(f"    Current:  (trust: {trust:.3f})")
        print()
        print("  Summary:")
        print(f"    Behavioral age:     {age}")
        print(f"    Current trust:      {trust:.3f}")

    # Persistent audit trail info
    if audit_summary.get("total", 0) > 0:
        total = audit_summary["total"]
        print()
        print("  Persistent Audit Trail:")
        print(f"    Records:   {total}")
        if audit_summary.get("by_verdict"):
            verdicts = []
            for v, c in sorted(audit_summary["by_verdict"].items()):
                verdicts.append(f"{c} {v}")
            print(f"    Verdicts:  {', '.join(verdicts)}")
        trust_start = audit_summary.get("trust_start", 0.5)
        trust_end = audit_summary.get("trust_end", 0.5)
        print(f"    Trust:     {trust_start:.3f} \u2192 {trust_end:.3f}")

        if chain_count > 0:
            if is_valid:
                _ok = "\u2713 verified"
                print(f"    Chain:     {_green(_ok)} ({chain_count} records)")
            else:
                _fail = f"\u2717 {chain_msg}"
                print(f"    Chain:     {_red(_fail)}")

    print()


def _cmd_tutorial(args: argparse.Namespace) -> None:
    """Run the interactive governance tutorial — the full developer journey."""
    import time as _time

    from nomotic.monitor import DriftConfig as _DriftConfig
    from nomotic.runtime import GovernanceRuntime, RuntimeConfig
    from nomotic.sandbox import (
        AgentConfig,
        EthicalRuleSpec,
        HumanOverrideSpec,
        apply_config_to_runtime,
        format_pct_bar,
    )
    from nomotic.store import MemoryCertificateStore
    from nomotic.types import Action as GovAction, AgentContext as GovCtx, Verdict

    interactive = sys.stdin.isatty() and _COLORS_ENABLED

    def _pause(msg: str = "Press Enter to continue...") -> None:
        if interactive:
            input(f"\n  {_dim(msg)}")
        print()

    def _header(chapter: str, title: str) -> None:
        print()
        print(_bold(_cyan("=" * 60)))
        print(_bold(_cyan(f"  {chapter}: {title}")))
        print(_bold(_cyan("=" * 60)))
        print()

    def _section(title: str) -> None:
        print(f"  {_bold(chr(9472) * 2 + ' ' + title + ' ' + chr(9472) * max(0, 45 - len(title)))}")
        print()

    # ── Chapter 1: Identity ─────────────────────────────────────────

    _header("Chapter 1", "Identity \u2014 \"Who is this agent?\"")
    print("  Every AI agent starts with a birth certificate \u2014 a cryptographically")
    print("  signed identity. Let's create one.")
    print()

    issuer_sk, issuer_vk = SigningKey.generate()
    store = MemoryCertificateStore()
    ca = CertificateAuthority(
        issuer_id="playground-issuer",
        signing_key=issuer_sk,
        store=store,
    )

    cert, agent_sk = ca.issue(
        agent_id="claims-bot",
        archetype="customer-experience",
        organization="acme-insurance",
        zone_path="us/production",
        owner="chris@acme.com",
    )

    print(f"  {_green('Certificate issued')}: {cert.certificate_id}")
    print(f"    Agent:     {cert.agent_id}")
    print(f"    Owner:     {cert.owner}")
    print(f"    Archetype: {cert.archetype}")
    print(f"    Org:       {cert.organization}")
    print(f"    Zone:      {cert.zone_path}")
    print(f"    Trust:     {cert.trust_score}")
    print(f"    Age:       {cert.behavioral_age}")
    print(f"    Status:    {cert.status.name}")
    print(f"    Issued:    {cert.issued_at.isoformat()}")
    print(f"    Fingerprint: {cert.fingerprint[:16]}...")
    print()
    print(f"  {_dim('What you learned: Every agent has an identity.')}")
    print(f"  {_dim('It is cryptographically signed, has a human owner,')}")
    print(f"  {_dim('lives in a governance zone, and starts with 0.50 trust.')}")

    _pause()

    # ── Chapter 2: Authority ────────────────────────────────────────

    _header("Chapter 2", 'Authority \u2014 "What can this agent do?"')
    print("  Now we define what this agent is allowed to do. Scope controls which")
    print("  actions. Boundaries control which resources. Rules add hard limits.")
    print()

    agent_config = AgentConfig(
        agent_id="claims-bot",
        actions=["read", "write", "query", "assess"],
        boundaries=["claims_db", "customer_records", "policy_db"],
        ethical_rules=[
            EthicalRuleSpec(
                condition="amount <= 10000",
                message="Claims over $10,000 require manual processing",
                name="max-claim-amount",
            ),
        ],
        human_overrides=[
            HumanOverrideSpec(
                action="approve",
                message="All claim approvals require human sign-off",
            ),
        ],
    )

    drift_cfg = _DriftConfig(window_size=50, check_interval=10, min_observations=10)
    runtime = GovernanceRuntime(config=RuntimeConfig(
        enable_fingerprints=True,
        drift_config=drift_cfg,
    ))
    runtime.set_certificate_authority(ca)
    runtime._cert_map["claims-bot"] = cert.certificate_id

    apply_config_to_runtime(runtime, agent_config)

    # Sync initial trust
    tp = runtime.get_trust_profile("claims-bot")
    tp.overall_trust = cert.trust_score

    print("  Scope configured:")
    print(f"    Allowed actions:  {', '.join(agent_config.actions)}")
    print(f"    Boundaries:       {', '.join(agent_config.boundaries)}")
    print()
    _print_authority_envelope("claims-bot", agent_config)
    print()

    print("  Ethical rule added:")
    print("    Rule:  amount <= 10000")
    print("    If violated: \"Claims over $10,000 require manual processing\"")
    print(f"    Effect: {_red('VETO')} (cannot be overridden by score)")
    print()

    print("  Human override rule added:")
    print(f"    Action '{_yellow('approve')}' requires human sign-off")
    print()

    print(f"  {_dim('What you learned: Authority is defined before the agent acts.')}")
    print(f"  {_dim('Scope controls actions. Boundaries control resources.')}")
    print(f"  {_dim('Rules add ethical constraints and human checkpoints.')}")

    _pause()

    # ── Chapter 3: Evaluation ───────────────────────────────────────

    _header("Chapter 3", 'Evaluation \u2014 "What happens when the agent acts?"')
    print("  When the agent tries to act, every action passes through 14 governance")
    print("  dimensions simultaneously. Watch what happens when we try allowed")
    print("  actions, then forbidden ones.")
    print()

    # Eval 1: authorized action
    _section("Evaluating: read \u2192 claims_db")

    action1 = GovAction(
        agent_id="claims-bot",
        action_type="read",
        target="claims_db",
        parameters={"claim_id": "CLM-5678"},
    )
    ctx1 = GovCtx(agent_id="claims-bot", trust_profile=runtime.get_trust_profile("claims-bot"))
    trust_before1 = ctx1.trust_profile.overall_trust
    v1 = runtime.evaluate(action1, ctx1)
    trust_after1 = runtime.get_trust_profile("claims-bot").overall_trust

    _print_evaluation(v1, trust_before1, trust_after1)

    _pause()

    # Eval 2: unauthorized action (out of scope)
    _section("Evaluating: delete \u2192 claims_db")

    action2 = GovAction(agent_id="claims-bot", action_type="delete", target="claims_db")
    ctx2 = GovCtx(agent_id="claims-bot", trust_profile=runtime.get_trust_profile("claims-bot"))
    trust_before2 = ctx2.trust_profile.overall_trust
    v2 = runtime.evaluate(action2, ctx2)
    trust_after2 = runtime.get_trust_profile("claims-bot").overall_trust

    _print_evaluation(v2, trust_before2, trust_after2)
    if v2.verdict == Verdict.DENY:
        print(f"  {_yellow(chr(9888))} Note: violations cost 5x more trust than successes earn.")
    print()

    _pause()

    # Eval 3: ethical violation
    _section("Evaluating: write \u2192 claims_db (amount=25000)")

    action3 = GovAction(
        agent_id="claims-bot",
        action_type="write",
        target="claims_db",
        parameters={"claim_id": "CLM-9999", "amount": 25000},
    )
    ctx3 = GovCtx(agent_id="claims-bot", trust_profile=runtime.get_trust_profile("claims-bot"))
    trust_before3 = ctx3.trust_profile.overall_trust
    v3 = runtime.evaluate(action3, ctx3)
    trust_after3 = runtime.get_trust_profile("claims-bot").overall_trust

    _print_evaluation(v3, trust_before3, trust_after3)

    _pause()

    # Eval 4: boundary breach
    _section("Evaluating: read \u2192 payroll_db (boundary breach)")

    action4 = GovAction(agent_id="claims-bot", action_type="read", target="payroll_db")
    ctx4 = GovCtx(agent_id="claims-bot", trust_profile=runtime.get_trust_profile("claims-bot"))
    trust_before4 = ctx4.trust_profile.overall_trust
    v4 = runtime.evaluate(action4, ctx4)
    trust_after4 = runtime.get_trust_profile("claims-bot").overall_trust

    _print_evaluation(v4, trust_before4, trust_after4)

    print(f"  {_dim('What you learned: Every action goes through 14 dimensions.')}")
    print(f"  {_dim('Some dimensions can veto (instant denial).')}")
    print(f"  {_dim('The UCS aggregates all scores into a single confidence number.')}")
    emdash = "\u2014"
    print(f"  {_dim('Trust updates asymmetrically ' + emdash + ' violations hurt 5x more.')}")

    _pause()

    # ── Chapter 4: Behavior ─────────────────────────────────────────

    _header("Chapter 4", 'Behavior \u2014 "What patterns does the agent develop?"')
    print("  After enough actions, the system learns what 'normal' looks like for")
    print("  this agent. Then we'll change the agent's behavior and watch the")
    print("  system detect the shift.")
    print()

    _section("Simulating 100 normal operations")

    import random
    normal_actions = [
        ("read", "claims_db"),
        ("read", "customer_records"),
        ("query", "claims_db"),
        ("query", "policy_db"),
        ("write", "claims_db"),
        ("read", "policy_db"),
        ("assess", "claims_db"),
    ]
    normal_weights = [25, 15, 15, 10, 10, 15, 10]

    trust_traj: list[float] = [runtime.get_trust_profile("claims-bot").overall_trust]

    for i in range(100):
        act_type, act_target = random.choices(normal_actions, weights=normal_weights, k=1)[0]
        params = {}
        if act_type == "write":
            params = {"claim_id": f"CLM-{random.randint(1000, 9999)}", "amount": random.randint(500, 9000)}
        elif act_type == "assess":
            params = {"claim_id": f"CLM-{random.randint(1000, 9999)}", "amount": random.randint(1000, 8000)}
        action = GovAction(agent_id="claims-bot", action_type=act_type, target=act_target, parameters=params)
        ctx = GovCtx(agent_id="claims-bot", trust_profile=runtime.get_trust_profile("claims-bot"))
        runtime.evaluate(action, ctx)
        trust_traj.append(runtime.get_trust_profile("claims-bot").overall_trust)

        bar_width = 40
        filled = int((i + 1) / 100 * bar_width)
        bar = chr(9608) * filled + chr(9617) * (bar_width - filled)
        print(f"\r  Simulating 100 normal operations... [{bar}] {i + 1}/100", end="", flush=True)

    print()
    print()

    # Show fingerprint
    fp = runtime.get_fingerprint("claims-bot")
    if fp is not None:
        print(f"  {_bold('Behavioral Fingerprint:')}")
        print(f"    Observations: {fp.total_observations}")
        print(f"    Confidence:   {fp.confidence:.2f}")
        print()

        if fp.action_distribution:
            print("    Action Distribution:")
            for act, freq in sorted(fp.action_distribution.items(), key=lambda x: -x[1]):
                bar = format_pct_bar(freq, 36)
                print(f"      {act:8s} {bar}  {freq:.0%}")
            print()

        if fp.target_distribution:
            print("    Target Distribution:")
            for tgt, freq in sorted(fp.target_distribution.items(), key=lambda x: -x[1]):
                bar = format_pct_bar(freq, 28)
                print(f"      {tgt:20s} {bar}  {freq:.0%}")
            print()

    # Show trust trajectory
    start_trust = trust_traj[0]
    end_trust = trust_traj[-1]
    print(f"  {_bold('Trust Trajectory:')}")
    print(f"    Start: {start_trust:.3f} {chr(8594)} End: {end_trust:.3f}")
    trend = "rising" if end_trust > start_trust + 0.02 else ("falling" if end_trust < start_trust - 0.02 else "stable")
    print(f"    Trend: {trend}")
    print()

    # Mini trajectory chart
    n_rows = 5
    min_t = min(trust_traj)
    max_t = max(trust_traj)
    t_range = max_t - min_t if max_t > min_t else 0.1
    chart_width = 40
    step = max(1, len(trust_traj) // chart_width)
    sampled = [trust_traj[i] for i in range(0, len(trust_traj), step)]

    for row in range(n_rows, -1, -1):
        level = min_t + (row / n_rows) * t_range
        label = f"  {level:.2f} |"
        chars = []
        for val in sampled:
            val_row = int((val - min_t) / t_range * n_rows) if t_range > 0 else n_rows // 2
            chars.append("." if val_row == row else " ")
        print(f"{label}{''.join(chars)}|")
    print(f"         {chr(9492)}{chr(9472) * len(sampled)}{chr(9496)}")
    print()

    print(f"  {_green(chr(10003))} 100 actions evaluated")
    print(f"  {_green(chr(10003))} Fingerprint established")
    print(f"  {_green(chr(10003))} Trust trajectory: {trend}")

    _pause()

    # ── Chapter 4b: Drift ───────────────────────────────────────────

    _section("Introducing behavioral drift")

    trust_before_drift = runtime.get_trust_profile("claims-bot").overall_trust
    print("  Agent starts doing mostly deletes instead of reads...")
    print(f"  Trust before drift: {_green(f'{trust_before_drift:.3f}')}")
    print()

    drift_traj: list[float] = [trust_before_drift]

    for i in range(50):
        # 80% deletes, 10% reads on sensitive targets, 10% normal reads
        r = random.random()
        if r < 0.80:
            target = random.choice(["claims_db", "customer_records", "policy_db"])
            action = GovAction(
                agent_id="claims-bot", action_type="delete", target=target,
            )
        elif r < 0.90:
            action = GovAction(agent_id="claims-bot", action_type="read", target="payroll_db")
        else:
            action = GovAction(agent_id="claims-bot", action_type="read", target="claims_db")
        ctx = GovCtx(agent_id="claims-bot", trust_profile=runtime.get_trust_profile("claims-bot"))
        runtime.evaluate(action, ctx)
        drift_traj.append(runtime.get_trust_profile("claims-bot").overall_trust)

        bar_width = 40
        filled = int((i + 1) / 50 * bar_width)
        bar = chr(9608) * filled + chr(9617) * (bar_width - filled)
        print(f"\r  Simulating drift... [{bar}] {i + 1}/50", end="", flush=True)

    print()
    print()

    # Show drift
    drift = runtime.get_drift("claims-bot")
    if drift is not None:
        sev = drift.severity
        color = _red if sev in ("high", "critical") else (_yellow if sev == "moderate" else _green)
        print(f"  {_bold('Drift Detection Report:')}")
        print(f"    Drift Score:    {color(f'{drift.overall:.2f}')} ({sev.upper()})")
        print(f"    JSD Divergence: {drift.action_drift:.2f}")
        if drift.detail:
            print(f"    Detail:         {drift.detail}")
        print()

    # Trust erosion
    trust_after_drift = runtime.get_trust_profile("claims-bot").overall_trust
    erosion = trust_after_drift - trust_before_drift
    print(f"  {_bold('Trust Impact:')}")
    print(f"    Trust eroded by drift: {trust_before_drift:.3f} {chr(8594)} {trust_after_drift:.3f}")
    print(f"    Erosion amount: {_red(f'{erosion:+.3f}')}")
    print()

    alerts = runtime.get_drift_alerts("claims-bot")
    if alerts:
        for alert in alerts[-1:]:
            sev_color = _red if alert.severity in ("critical", "high") else _yellow
            print(f"  {sev_color(chr(9888))} DRIFT ALERT generated:")
            print(f"    Severity: {alert.severity.upper()}")
            if alert.drift_score.detail:
                print(f"    Message:  \"{alert.drift_score.detail}\"")
        print()

    print(f"  {_dim('What you learned: The system learns normal patterns,')}")
    print(f"  {_dim('then detects when behavior changes. Drift erodes trust')}")
    print(f"  {_dim('and changes governance outcomes automatically.')}")

    _pause()

    # ── Chapter 5: Interruption ─────────────────────────────────────

    _header("Chapter 5", 'Interruption \u2014 "Can we stop an agent mid-action?"')
    print("  Governance doesn't just decide before execution \u2014 it can stop an agent")
    print("  mid-action and roll back. Watch an interrupt happen.")
    print()

    print("  Agent claims-bot is processing a batch write...")
    print()

    rollback_log: list[str] = []

    def _rollback() -> None:
        for item in reversed(rollback_log):
            print(f"    Reverting {item}... done")
        rollback_log.clear()

    batch_action = GovAction(agent_id="claims-bot", action_type="write", target="claims_db")
    handle = runtime.begin_execution(batch_action, ctx1, rollback=_rollback)

    for record_num in range(1, 11):
        if handle.check_interrupt():
            print(f"\n  {_red(chr(9940))} EXECUTION HALTED after record {record_num - 1}")
            break

        rollback_log.append(f"record {record_num}")
        print(f"  {chr(9203)} Processing record {record_num} of 10... {_green(chr(10003))}")
        _time.sleep(0.15)

        if record_num == 3:
            print()
            print(f"  {_yellow(chr(9889))} INTERRUPT SIGNAL: Anomaly detected in write pattern")
            print()
            print("  Agent checks interrupt flag at next safe point...")
            print()

            runtime.interrupt_action(
                batch_action.id,
                reason="Anomaly detected in write pattern",
                source="drift_monitor",
            )

    if handle.is_interrupted:
        print()
        print(f"  {_bold(chr(8617))} ROLLBACK executing...")

        handle_rollback = handle.rollback
        if handle_rollback:
            handle_rollback()

        print()
        print(f"  {_green(chr(10003))} Rollback complete. System state restored.")
    else:
        runtime.complete_execution(batch_action.id, ctx1)
        print("\n  All records processed successfully.")

    print()
    print(f"  {_dim('What you learned: Governance has teeth.')}")
    print(f"  {_dim('The agent cooperated with the interrupt ' + emdash + ' it checked')}")
    print(f"  {_dim('for interrupts at each safe point and rolled back cleanly.')}")

    _pause()

    # ── Chapter 6: Audit Trail ──────────────────────────────────────

    _header("Chapter 6", 'Audit Trail \u2014 "What happened and why?"')
    print("  Every governance decision is recorded with full justification \u2014 not")
    print("  just what happened, but why.")
    print()

    if runtime.audit_trail is not None:
        _section("Recent audit records")

        records = runtime.audit_trail.query(agent_id="claims-bot", limit=5)
        if records:
            for i, r in enumerate(records):
                verdict_color = _green if r.verdict == "ALLOW" else (_red if r.verdict == "DENY" else _yellow)
                ts_str = datetime.fromtimestamp(r.timestamp, tz=timezone.utc).strftime("%H:%M:%S")
                print(f"  #{r.record_id}  {ts_str}  {verdict_color(f'GOVERNANCE.{r.verdict}')}")
                print(f"       Action: {r.action_type} {chr(8594)} {r.action_target}")
                print(f"       UCS: {r.ucs:.2f}  Tier: {r.tier}")
                print(f"       Trust: {r.trust_score:.3f} ({r.trust_trend})")
                if r.justification:
                    just = r.justification[:100]
                    if len(r.justification) > 100:
                        just += "..."
                    print(f"       Why: {just}")
                print()

        _section("Audit summary")

        summary = runtime.audit_trail.summary()
        total = summary.get("total_records", 0)
        print(f"  Total evaluations:  {total}")
        print()

        by_verdict = summary.get("by_verdict", {})
        if by_verdict:
            print("  By verdict:")
            for v, cnt in sorted(by_verdict.items()):
                pct = cnt / total * 100 if total else 0
                bar = format_pct_bar(cnt / total if total else 0, 40)
                vcolor = _green if v == "ALLOW" else (_red if v == "DENY" else _yellow)
                print(f"    {vcolor(f'{v:10s}')} {cnt:5d}  {bar}  {pct:.1f}%")
            print()

        by_severity = summary.get("by_severity", {})
        if by_severity:
            print("  By severity:")
            for s, cnt in sorted(by_severity.items()):
                pct = cnt / total * 100 if total else 0
                bar = format_pct_bar(cnt / total if total else 0, 40)
                print(f"    {s:10s} {cnt:5d}  {bar}  {pct:.1f}%")
            print()

        recent_alerts = summary.get("recent_alerts", [])
        if recent_alerts:
            print("  Recent alerts:")
            for a in recent_alerts[-3:]:
                sev = a.get("severity", "?")
                code = a.get("context_code", "?")
                sev_color = _red if sev in ("critical", "alert") else _yellow
                print(f"    [{sev_color(sev.upper())}] {code}")
            print()

    print(f"  {_dim('What you learned: Every decision is recorded with full')}")
    print(f"  {_dim('justification. The audit trail explains the why, not just the what.')}")

    _pause()

    # ── Chapter 7: Full picture ─────────────────────────────────────

    _header("Chapter 7", 'The Full Picture')

    final_trust = runtime.get_trust_profile("claims-bot").overall_trust
    report = runtime.get_trust_report("claims-bot")

    print(f"  {_bold('Governance Report for claims-bot')}")
    print()
    print(f"    Current Trust:     {final_trust:.3f}")
    print(f"    Total Actions:     {report.get('successful_actions', 0) + report.get('violation_count', 0)}")
    print(f"    Successful:        {report.get('successful_actions', 0)}")
    print(f"    Violations:        {report.get('violation_count', 0)}")
    print(f"    Violation Rate:    {report.get('violation_rate', 0):.1%}")
    print()

    fp_info = report.get("fingerprint")
    if fp_info:
        obs = fp_info.get('total_observations', 0)
        conf = fp_info.get('confidence', 0)
        print(f"    Fingerprint:       {obs} observations (confidence: {conf:.2f})")

    drift_info = report.get("drift")
    if drift_info:
        sev = drift_info.get("severity", "none")
        color = _red if sev in ("high", "critical") else (_yellow if sev == "moderate" else _green)
        drift_val = drift_info.get("overall", 0)
        print(f"    Drift:             {color(f'{drift_val:.2f}')} ({sev})")

    alert_count = report.get("active_alerts", 0)
    if alert_count:
        print(f"    Active Alerts:     {_red(str(alert_count))}")
    print()

    traj = report.get("trajectory", {})
    sources = traj.get("sources", {})
    if sources:
        print(f"  {_bold('Trust by source:')}")
        for src, info in sorted(sources.items()):
            nd = info.get("net_delta", 0)
            cnt = info.get("count", 0)
            sign = "+" if nd >= 0 else ""
            color = _green if nd > 0 else (_red if nd < 0 else _yellow)
            print(f"    {src:25s} {color(f'{sign}{nd:.3f}')} ({cnt} events)")
        print()

    print(_bold(_cyan("=" * 60)))
    print(_bold(_cyan("  Tutorial complete.")))
    print(_bold(_cyan("=" * 60)))
    print()
    print("  You just saw the entire Nomotic governance lifecycle:")
    print("    1. Identity     \u2014 Cryptographic birth certificate")
    print("    2. Authority    \u2014 Scope, boundaries, and rules")
    print("    3. Evaluation   \u2014 14-dimension scoring with UCS")
    print("    4. Behavior     \u2014 Fingerprinting and drift detection")
    print("    5. Interruption \u2014 Mechanical halt with rollback")
    print("    6. Audit Trail  \u2014 Full accountability record")
    print("    7. Trust        \u2014 Continuous calibration from all sources")
    print()

    # ── Developer quickstart handoff ─────────────────────────────
    print()
    print(_bold(_cyan("=" * 60)))
    print(_bold(_cyan("  Tutorial complete.")))
    print(_bold(_cyan("=" * 60)))
    print()
    print("  You've seen Nomotic governance in action.")
    print("  Now build your own governed agent:")
    print()
    print(f"  {_bold('Step 1:')} Configure your organization (once per machine)")
    print(f"    {_cyan('nomotic setup')}")
    print()
    print(f"  {_bold('Step 2:')} Scaffold your first project")
    print(f"    {_cyan('nomotic init --archetype <archetype>')}")
    print()
    print(f"  {_bold('Step 3:')} Run governance locally")
    print(f"    {_cyan('python hello_nomotic.py')}")
    print()
    print(f"  {_bold('Step 4:')} Open the governance dashboard")
    print(f"    {_cyan('nomotic serve --ui')}")
    print()
    print(f"  {_dim('Documentation: https://docs.nomotic.ai')}")
    print(f"  {_dim('Quickstart:    https://docs.nomotic.ai/quickstart')}")
    print()


def _print_evaluation(
    verdict: "GovernanceVerdict",
    trust_before: float,
    trust_after: float,
) -> None:
    """Print a formatted governance evaluation result."""
    from nomotic.sandbox import format_bar
    from nomotic.types import Verdict

    print(f"  Trust:   {trust_before:.3f}")
    print()

    for ds in verdict.dimension_scores:
        bar = format_bar(ds.score, 20)
        name_padded = f"{ds.dimension_name:26s}"
        score_str = f"{ds.score:.2f}"

        if ds.veto and ds.score < 0.5:
            check = _red(f"{chr(10007)} VETO: {ds.reasoning}")
            color_score = _red(score_str)
        elif ds.score >= 0.7:
            check = _green(ds.reasoning)
            color_score = _green(score_str)
        elif ds.score >= 0.4:
            check = _yellow(ds.reasoning)
            color_score = _yellow(score_str)
        else:
            check = _red(ds.reasoning)
            color_score = _red(score_str)

        print(f"  {name_padded} {color_score}  {bar}  {check}")

    print()

    ucs_str = f"{verdict.ucs:.3f}"
    tier_labels = {1: "veto gate", 2: "threshold evaluation", 3: "deliberative review"}
    tier_label = tier_labels.get(verdict.tier, "unknown")

    if verdict.verdict == Verdict.ALLOW:
        verdict_display = _green(f"{chr(9989)} ALLOW")
    elif verdict.verdict == Verdict.DENY:
        verdict_display = _red(f"{chr(10060)} DENY")
    elif verdict.verdict == Verdict.ESCALATE:
        verdict_display = _yellow(f"{chr(9888)} ESCALATE")
    else:
        verdict_display = _yellow(f"{chr(9888)} {verdict.verdict.name}")

    print(f"  UCS:      {ucs_str}")
    print(f"  Tier:     {verdict.tier} ({tier_label})")
    print(f"  Verdict:  {verdict_display}")
    if verdict.vetoed_by:
        print(f"  Vetoed by: {', '.join(verdict.vetoed_by)}")
    if verdict.reasoning:
        print(f"  Reason:   {verdict.reasoning}")
    print(f"  Time:     {verdict.evaluation_time_ms:.1f}ms")

    # Trust update
    delta = trust_after - trust_before
    sign = "+" if delta >= 0 else ""
    delta_color = _green if delta > 0 else (_red if delta < 0 else _yellow)
    trend = "stable"
    if delta > 0.001:
        trend = f"{chr(8599)} rising"
    elif delta < -0.001:
        trend = f"{chr(8600)} falling"

    print()
    print(f"  Before:   {trust_before:.3f}")
    print(f"  After:    {trust_after:.3f}  ({delta_color(f'{sign}{delta:.3f}')})")
    print(f"  Trend:    {trend}")
    print()


def _cmd_audit_show(args: argparse.Namespace) -> None:
    """Show audit records from an in-memory simulation or local test sessions."""
    # This is a convenience alias that displays a help message
    # pointing users to the tutorial or test commands.
    print("The 'audit show' command works in two modes:")
    print()
    print("  1. After 'nomotic tutorial' — audit records are shown as part")
    print("     of the interactive walkthrough (Chapter 6).")
    print()
    print("  2. Against a running API server:")
    print("     nomotic audit query --agent-id <agent> --host 127.0.0.1 --port 8420")
    print("     nomotic audit summary --agent-id <agent> --host 127.0.0.1 --port 8420")
    print()
    print("  Run 'nomotic tutorial' for the full interactive experience.")


def _cmd_serve(args: argparse.Namespace) -> None:
    try:
        from nomotic.telemetry import get_telemetry
        get_telemetry().record_cli_command("serve")
    except Exception:
        pass
    from nomotic.api import NomoticAPIServer

    sim_mode = getattr(args, "sim_mode", False)
    fleet_sim = None

    if sim_mode:
        from nomotic.fleet_sim import FleetSimulator
        state_path = FleetSimulator.STATE_PATH
        if not state_path.exists():
            print("Error: No fleet simulation is running.", file=sys.stderr)
            print("Start one first: nomotic simulate fleet --agents 1000", file=sys.stderr)
            sys.exit(1)
        state = json.loads(state_path.read_text())
        from nomotic.fleet_sim import SimulationConfig
        sim_config = SimulationConfig(**state["config"])
        fleet_sim = FleetSimulator(sim_config)
        fleet_sim.provision_agents()
        fleet_sim.start()

    ca, _store = _build_ca(args.base_dir)
    arch_reg, zone_val, org_reg = _build_registries(args.base_dir)

    prometheus = None
    if getattr(args, "metrics", False):
        from nomotic.otel_exporter import PrometheusMetrics

        prometheus = PrometheusMetrics()

    playground_enabled = getattr(args, "playground", False)

    server_kwargs = dict(
        archetype_registry=arch_reg,
        zone_validator=zone_val,
        org_registry=org_reg,
        base_dir=args.base_dir,
        prometheus=prometheus,
        host=args.host,
        port=args.port,
        ui_enabled=getattr(args, "ui", False),
        poll_interval=getattr(args, "poll_interval", 15),
        api_key=getattr(args, "api_key", None),
        playground_enabled=playground_enabled,
    )
    if fleet_sim is not None:
        server_kwargs["runtime"] = fleet_sim.get_runtime()

    server = NomoticAPIServer(ca, **server_kwargs)

    # Attach fleet_sim reference for /v1/sim/* endpoints
    if fleet_sim is not None:
        server._fleet_sim = fleet_sim  # type: ignore[attr-defined]

    sk, vk, issuer_id = _load_or_create_issuer(args.base_dir)
    print(f"Nomotic API server starting on http://{args.host}:{args.port}")
    print(f"  Issuer: {issuer_id}")
    print(f"  Fingerprint: {vk.fingerprint()}")
    if prometheus is not None:
        print("  Metrics: http://{}:{}/metrics".format(args.host, args.port))
    if getattr(args, "ui", False):
        print(f"  Dashboard: http://localhost:{args.port}/ui")
    if playground_enabled:
        print(f"  Playground: http://localhost:{args.port}/ui/playground")
    if sim_mode:
        print(f"  Sim Mode: Fleet simulation active ({sim_config.agent_count} agents)")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down...")
        if fleet_sim is not None:
            fleet_sim.stop()
        server.shutdown()


# ── MCP Proxy command ────────────────────────────────────────────────────


def _cmd_mcp_proxy(args: argparse.Namespace) -> None:
    from nomotic.mcp_proxy import MCPGovernanceProxy, MCPHTTPGovernanceProxy

    agent_id = args.agent_id
    upstream = args.upstream
    upstream_url = args.upstream_url

    if not upstream and not upstream_url:
        print("Error: Either --upstream (stdio) or --upstream-url (HTTP) is required.", file=sys.stderr)
        sys.exit(1)
    if upstream and upstream_url:
        print("Error: Specify either --upstream or --upstream-url, not both.", file=sys.stderr)
        sys.exit(1)

    require_certificate = getattr(args, "require_certificate", False)
    agent_id_map: dict[str, str] = {}
    if getattr(args, "agent_map", None):
        agent_id_map = json.loads(Path(args.agent_map).read_text())

    kw = {
        "test_mode": args.test_mode,
        "log_level": args.log_level,
        "base_dir": args.base_dir,
    }

    if upstream:
        proxy = MCPGovernanceProxy(
            agent_id=agent_id,
            upstream_command=upstream,
            require_certificate=require_certificate,
            **kw,
        )
        sys.stderr.write(
            f"[nomotic] MCP stdio proxy starting\n"
            f"[nomotic] Agent: {agent_id}\n"
            f"[nomotic] Upstream: {upstream}\n"
        )
        proxy.run()
    else:
        proxy = MCPHTTPGovernanceProxy(
            agent_id=agent_id,
            upstream_url=upstream_url,
            port=args.port,
            host=args.host,
            require_certificate=require_certificate,
            agent_id_map=agent_id_map,
            default_timeout=args.timeout,
            **kw,
        )
        proxy.run()


# ── HTTP Governance Proxy command ────────────────────────────────────────


def _cmd_proxy(args: argparse.Namespace) -> None:
    from nomotic.proxy import start_proxy

    require_certificate = getattr(args, "require_certificate", False)
    agent_id_map: dict[str, str] = {}
    if getattr(args, "agent_map", None):
        agent_id_map = json.loads(Path(args.agent_map).read_text())

    start_proxy(
        agent_id=args.agent_id,
        listen=args.listen,
        upstream=args.upstream,
        test_mode=args.test_mode,
        base_dir=str(args.base_dir),
        require_certificate=require_certificate,
        agent_id_map=agent_id_map,
        default_timeout=args.timeout,
    )


# ── SIEM export ─────────────────────────────────────────────────────────


def _cmd_siem_export(args: argparse.Namespace) -> None:
    """Export audit trail records in SIEM-ingestible formats."""
    from nomotic.audit_store import AuditStore
    from nomotic.siem import SIEMExporter

    identifier = getattr(args, "identifier", None)
    siem_all = getattr(args, "siem_all", False)

    if not identifier and not siem_all:
        print(
            "Specify an agent name/ID, or use --all for all agents.",
            file=sys.stderr,
        )
        print("  nomotic siem-export agent-1 --format jsonl", file=sys.stderr)
        print("  nomotic siem-export agent-1 --format cef --severity alert", file=sys.stderr)
        print("  nomotic siem-export --all --format syslog", file=sys.stderr)
        sys.exit(1)

    # Parse date filters
    since_ts: float | None = None
    until_ts: float | None = None
    if args.since:
        since_ts = datetime.fromisoformat(args.since).replace(
            tzinfo=timezone.utc
        ).timestamp()
    if args.until:
        until_ts = datetime.fromisoformat(args.until).replace(
            tzinfo=timezone.utc
        ).timestamp()

    exporter = SIEMExporter(
        format=args.siem_format,
        include_dimension_scores=getattr(args, "include_dimensions", False),
    )

    audit_store = AuditStore(args.base_dir)

    # Gather agent names to export
    agent_names: list[str] = []
    if siem_all:
        agent_names = audit_store.list_agents()
        if not agent_names:
            print("  No audit records found.", file=sys.stderr)
            return
    else:
        # Try to resolve identifier
        try:
            _numeric_id, resolved_name, _cert_id = _resolve_agent(
                args.base_dir, identifier  # type: ignore[arg-type]
            )
            agent_names = [resolved_name]
        except SystemExit:
            agent_names = [identifier]  # type: ignore[list-item]

    # Collect and format records
    output_file = None
    if args.output:
        output_file = open(args.output, "w")  # noqa: SIM115

    try:
        for name in agent_names:
            records = audit_store.query(
                name,
                severity=args.severity,
            )
            if not records:
                continue

            # Build a lightweight in-memory AuditTrail for the exporter
            from nomotic.audit import AuditRecord, AuditTrail

            trail = AuditTrail()
            for r in records:
                # Convert PersistentAuditRecord -> AuditRecord
                rec = AuditRecord(
                    record_id=r.record_id,
                    timestamp=r.timestamp,
                    context_code=r.context_code,
                    severity=r.severity,
                    agent_id=r.agent_id,
                    owner_id=getattr(r, "owner_id", ""),
                    user_id=getattr(r, "user_id", ""),
                    action_id=getattr(r, "action_id", ""),
                    action_type=getattr(r, "action_type", ""),
                    action_target=getattr(r, "action_target", ""),
                    verdict=r.verdict,
                    ucs=r.ucs,
                    tier=r.tier,
                    trust_score=getattr(r, "trust_score", 0.5),
                    trust_trend=getattr(r, "trust_trend", "stable"),
                    drift_overall=getattr(r, "drift_overall", None),
                    drift_severity=getattr(r, "drift_severity", None),
                    justification=getattr(r, "justification", ""),
                    previous_hash=getattr(r, "previous_hash", ""),
                    record_hash=getattr(r, "record_hash", ""),
                )
                # Apply date filtering
                if since_ts is not None and rec.timestamp < since_ts:
                    continue
                if until_ts is not None and rec.timestamp > until_ts:
                    continue

                trail.append(rec)

            # Apply verdict filter via query
            query_kwargs: dict[str, Any] = {"limit": 100000}
            if args.verdict:
                query_kwargs["verdict"] = args.verdict

            output = exporter.export_trail(trail, **query_kwargs)
            if output:
                dest = output_file or sys.stdout
                print(output, file=dest)

    finally:
        if output_file is not None:
            output_file.close()


# ── Evidence bundle commands ─────────────────────────────────────────────


def _cmd_evidence(args: argparse.Namespace) -> None:
    """Generate, verify, or summarize compliance evidence bundles."""
    subcmd = getattr(args, "evidence_command", None)
    if subcmd is None:
        print("Usage: nomotic evidence {generate,verify,summary}")
        print()
        print("  generate  Generate a compliance evidence bundle")
        print("  verify    Verify a bundle file's integrity")
        print("  summary   Show a summary of a bundle file")
        return

    if subcmd == "generate":
        _cmd_evidence_generate(args)
    elif subcmd == "verify":
        _cmd_evidence_verify(args)
    elif subcmd == "summary":
        _cmd_evidence_summary(args)


def _cmd_evidence_generate(args: argparse.Namespace) -> None:
    """Generate a compliance evidence bundle from persisted audit records."""
    from nomotic.audit import AuditRecord, AuditTrail
    from nomotic.audit_store import AuditStore
    from nomotic.evidence import EvidenceBundleGenerator

    identifier = getattr(args, "identifier", None)

    # Parse frameworks
    frameworks: list[str] | None = None
    if args.frameworks:
        frameworks = [f.strip() for f in args.frameworks.split(",")]

    # Parse date filters
    since_ts: float | None = None
    until_ts: float | None = None
    if args.since:
        since_ts = datetime.fromisoformat(args.since).replace(
            tzinfo=timezone.utc
        ).timestamp()
    if getattr(args, "until", None):
        until_ts = datetime.fromisoformat(args.until).replace(
            tzinfo=timezone.utc
        ).timestamp()

    # Resolve agent name
    agent_name: str | None = None
    if identifier:
        try:
            _numeric_id, resolved_name, _cert_id = _resolve_agent(
                args.base_dir, identifier
            )
            agent_name = resolved_name
        except SystemExit:
            agent_name = identifier

    # Load audit records from the persistent store
    audit_store = AuditStore(args.base_dir)
    trail = AuditTrail()

    agent_names: list[str] = []
    if agent_name:
        agent_names = [agent_name]
    else:
        agent_names = audit_store.list_agents()

    for name in agent_names:
        records = audit_store.query(name)
        for r in records:
            rec = AuditRecord(
                record_id=r.record_id,
                timestamp=r.timestamp,
                context_code=r.context_code,
                severity=r.severity,
                agent_id=r.agent_id,
                owner_id=getattr(r, "owner_id", ""),
                user_id=getattr(r, "user_id", ""),
                action_id=getattr(r, "action_id", ""),
                action_type=getattr(r, "action_type", ""),
                action_target=getattr(r, "action_target", ""),
                verdict=r.verdict,
                ucs=r.ucs,
                tier=r.tier,
                trust_score=getattr(r, "trust_score", 0.5),
                trust_trend=getattr(r, "trust_trend", "stable"),
                drift_overall=getattr(r, "drift_overall", None),
                drift_severity=getattr(r, "drift_severity", None),
                justification=getattr(r, "justification", ""),
                previous_hash=getattr(r, "previous_hash", ""),
                record_hash=getattr(r, "record_hash", ""),
            )
            trail.append(rec)

    generator = EvidenceBundleGenerator(audit_trail=trail)
    bundle = generator.generate(
        agent_id=agent_name,
        since=since_ts,
        until=until_ts,
        frameworks=frameworks,
        created_by=getattr(args, "created_by", "nomotic-cli"),
    )

    output_json = generator.to_json(bundle)

    if args.output:
        with open(args.output, "w") as f:
            f.write(output_json)
        print(f"Evidence bundle written to {args.output}")
        print(f"  Bundle ID:  {bundle.bundle_id}")
        print(f"  Records:    {bundle.record_count}")
        print(f"  Frameworks: {', '.join(bundle.frameworks)}")
        print(f"  Chain OK:   {bundle.chain_verification.get('valid', False)}")
    else:
        print(output_json)


def _cmd_evidence_verify(args: argparse.Namespace) -> None:
    """Verify a bundle file's integrity."""
    from nomotic.evidence import EvidenceBundleGenerator

    bundle_path = args.bundle_file
    try:
        with open(bundle_path) as f:
            bundle_data = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError) as exc:
        print(f"Error reading bundle: {exc}", file=sys.stderr)
        sys.exit(1)

    generator = EvidenceBundleGenerator()
    valid, message = generator.verify_bundle(bundle_data)

    if valid:
        print(_green("PASS") + f"  {message}")
    else:
        print(_red("FAIL") + f"  {message}")
        sys.exit(1)


def _cmd_evidence_summary(args: argparse.Namespace) -> None:
    """Show a summary of a bundle file."""
    bundle_path = args.bundle_file
    try:
        with open(bundle_path) as f:
            bundle_data = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError) as exc:
        print(f"Error reading bundle: {exc}", file=sys.stderr)
        sys.exit(1)

    bid = bundle_data.get("bundle_id", "?")
    created = bundle_data.get("created_at", "?")
    created_by = bundle_data.get("created_by", "?")
    agent = bundle_data.get("agent_id") or "(all agents)"
    frameworks = bundle_data.get("frameworks", [])
    record_count = bundle_data.get("record_count", 0)
    chain = bundle_data.get("chain_verification", {})
    chain_ok = chain.get("valid", False)
    time_range = bundle_data.get("time_range", [0.0, 0.0])

    # Format time range
    if time_range[0] > 0:
        start_str = datetime.fromtimestamp(
            time_range[0], tz=timezone.utc
        ).strftime("%Y-%m-%d %H:%M UTC")
    else:
        start_str = "(beginning)"
    end_str = datetime.fromtimestamp(
        time_range[1], tz=timezone.utc
    ).strftime("%Y-%m-%d %H:%M UTC")

    print(f"  {_bold('Evidence Bundle Summary')}")
    print(f"  {'─' * 40}")
    print(f"  Bundle ID:   {bid}")
    print(f"  Created:     {created}")
    print(f"  Created by:  {created_by}")
    print(f"  Agent:       {agent}")
    print(f"  Time range:  {start_str} → {end_str}")
    print(f"  Frameworks:  {', '.join(frameworks)}")
    print(f"  Records:     {record_count}")
    chain_label = _green("valid") if chain_ok else _red("INVALID")
    print(f"  Chain:       {chain_label}")
    print(f"  Controls:    {len(bundle_data.get('compliance_evidence', []))}")

    # Verdict breakdown
    verdicts: dict[str, int] = {}
    for rec in bundle_data.get("audit_records", []):
        v = rec.get("verdict", "?")
        verdicts[v] = verdicts.get(v, 0) + 1
    if verdicts:
        print(f"  Verdicts:    {', '.join(f'{k}: {v}' for k, v in sorted(verdicts.items()))}")


# ── Compliance Report command ────────────────────────────────────────────


def _cmd_compliance_report(args: argparse.Namespace) -> None:
    """Generate a compliance mapping report."""
    from nomotic.compliance_report import (
        FRAMEWORK_MAPPINGS,
        ComplianceReportGenerator,
        FrameworkLoadError,
        discover_frameworks,
        format_json,
        format_markdown,
        load_custom_framework,
    )

    generator = ComplianceReportGenerator(base_dir=args.base_dir)

    # Auto-discover custom frameworks from standard locations
    discovered = discover_frameworks()
    for _fw_id, fw_path in discovered.items():
        try:
            fm = load_custom_framework(fw_path)
            generator.register_custom_framework(fm)
        except FrameworkLoadError:
            pass

    # Handle --list-frameworks
    if getattr(args, "list_frameworks", False):
        print("Available Compliance Frameworks")
        print()
        print("  Built-in:")
        for fw_id, fm in FRAMEWORK_MAPPINGS.items():
            print(f"    {fw_id:<16}{fm.framework_name}")
        print()
        if discovered:
            print("  Custom (discovered):")
            for fw_id, fw_path in discovered.items():
                try:
                    fm = load_custom_framework(fw_path)
                    print(f"    {fw_id:<16}{fm.framework_name} (custom)")
                    print(f"      Path: {fw_path}")
                except FrameworkLoadError:
                    pass
        else:
            print('  Custom: none found in ~/.nomotic/frameworks/ or ./nomotic-frameworks/')
        return

    if args.framework is None:
        print(_red("Error: --framework is required (or use --list-frameworks)"), file=sys.stderr)
        sys.exit(1)

    framework_id: str
    if os.path.exists(args.framework) or args.framework.endswith(".json"):
        # Load as file path
        try:
            framework = load_custom_framework(args.framework)
        except FrameworkLoadError as exc:
            print(_red(f"Error: {exc}"), file=sys.stderr)
            sys.exit(1)
        generator.register_custom_framework(framework)
        framework_id = framework.framework_id
    else:
        # Use as framework ID (built-in or previously discovered)
        framework_id = args.framework

    agent_name: str | None = None
    if args.agent:
        try:
            _numeric_id, resolved_name, _cert_id = _resolve_agent(
                args.base_dir, args.agent
            )
            agent_name = resolved_name
        except SystemExit:
            agent_name = args.agent

    try:
        report = generator.generate(
            framework=framework_id,
            agent_id=agent_name,
            include_layer_map=getattr(args, "include_layer_map", False),
        )
    except ValueError as exc:
        print(_red(f"Error: {exc}"), file=sys.stderr)
        sys.exit(1)

    output_path: str | None = args.output
    if output_path is not None:
        if output_path.endswith(".json"):
            content = json.dumps(format_json(report), indent=2)
        else:
            content = format_markdown(report)
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(content)
        print(f"Compliance report written to {output_path}")
        print(f"  Framework:  {report.framework_name}")
        print(f"  Controls:   {report.summary.total_controls}")
        print(f"  Coverage:   {report.summary.coverage_percentage:.0f}%")
    else:
        # Print markdown to stdout
        print(format_markdown(report))


# ── Compliance Gap Analysis command ──────────────────────────────────────


def _cmd_compliance_gaps(args: argparse.Namespace) -> None:
    """Analyze compliance gaps from audit data."""
    from nomotic.audit_store import LogStore
    from nomotic.compliance_report import (
        FRAMEWORK_MAPPINGS,
        ComplianceReportGenerator,
        FrameworkLoadError,
        discover_frameworks,
        load_custom_framework,
    )
    from nomotic.gap_analysis import ComplianceGapAnalyzer

    if args.framework is None:
        print(_red("Error: framework argument is required"), file=sys.stderr)
        print(
            f"  Available: {', '.join(sorted(FRAMEWORK_MAPPINGS.keys()))}",
            file=sys.stderr,
        )
        sys.exit(1)

    generator = ComplianceReportGenerator(base_dir=args.base_dir)

    # Auto-discover custom frameworks
    discovered = discover_frameworks()
    for _fw_id, fw_path in discovered.items():
        try:
            fm = load_custom_framework(fw_path)
            generator.register_custom_framework(fm)
        except FrameworkLoadError:
            pass

    audit_store = LogStore(args.base_dir, "audit")
    analyzer = ComplianceGapAnalyzer(generator, audit_store)

    # Resolve agent name if provided
    agent_name: str | None = None
    if args.agent:
        try:
            _numeric_id, resolved_name, _cert_id = _resolve_agent(
                args.base_dir, args.agent
            )
            agent_name = resolved_name
        except SystemExit:
            agent_name = args.agent

    try:
        report = analyzer.analyze(
            framework_id=args.framework,
            agent_id=agent_name,
            days=args.days,
            gap_threshold=args.threshold,
        )
    except ValueError as exc:
        print(_red(f"Error: {exc}"), file=sys.stderr)
        sys.exit(1)

    # Format output
    scope = agent_name or "fleet-wide"
    severity_filter = getattr(args, "severity", None)

    print(f"Compliance Gap Analysis \u2014 {report.framework_name} "
          f"({report.period_days} days, {scope})")
    print("\u2500" * 55)
    print(f"  Controls analyzed:  {report.total_controls}")
    print(f"  Controls with gaps: {report.controls_with_gaps}  "
          f"({report.coverage_percent:.0f}% adequate coverage)")
    print()

    def _score_bar(score: float) -> str:
        filled = round(score * 10)
        return "\u25cf" * filled + "\u25cb" * (10 - filled)

    def _print_gap(gap: "ControlGap") -> None:  # noqa: F821
        print(f"  {gap.control_id}  {gap.control_description}")
        print(f"    Dimensions:  {', '.join(gap.nomotic_dimensions)}")
        print(f"    Avg score:   {gap.average_dimension_score:.2f}  "
              f"{_score_bar(gap.average_dimension_score)}  "
              f"(threshold: {gap.score_threshold:.2f})")
        print(f"    Sample:      {gap.sample_size} records")
        print(f"    Action:      {gap.recommendation}")
        print()

    if report.critical_gaps and severity_filter in (None, "critical"):
        print(_red("CRITICAL GAPS"))
        print("\u2500" * 14)
        for gap in report.critical_gaps:
            _print_gap(gap)

    if report.high_gaps and severity_filter in (None, "high"):
        print(_yellow("HIGH GAPS"))
        print("\u2500" * 10)
        for gap in report.high_gaps:
            _print_gap(gap)

    if report.medium_gaps and severity_filter in (None, "medium"):
        print("MEDIUM GAPS")
        print("\u2500" * 12)
        for gap in report.medium_gaps:
            _print_gap(gap)

    if report.low_gaps and severity_filter in (None, "low"):
        print("LOW GAPS")
        print("\u2500" * 9)
        for gap in report.low_gaps:
            _print_gap(gap)

    if report.clean_controls and severity_filter is None:
        ids = ", ".join(g.control_id for g in report.clean_controls)
        print(_green(f"\u2713 PASSING CONTROLS ({len(report.clean_controls)})"))
        print(f"  {ids}")
        print()


# ── Validate command ─────────────────────────────────────────────────────


def _cmd_validate(args: argparse.Namespace) -> None:
    """Validate a nomotic.yaml governance config file."""
    from nomotic.config_loader import (
        load_governance_config_from_string,
        validate_governance_config,
    )
    from nomotic.org_governance import enforce_org_policy, load_org_config
    from nomotic.presets import DIMENSION_NAMES, TRUST_SETTING_KEYS, get_preset, get_preset_names

    target_path = Path(args.path)
    use_json = getattr(args, "json", False)
    quiet = getattr(args, "quiet", False)
    strict = getattr(args, "strict", False)
    preset_override = getattr(args, "preset", None)
    org_path = getattr(args, "org", None)

    errors: list[dict[str, str]] = []
    warnings: list[dict[str, str]] = []
    info: list[dict[str, str]] = []
    presets_applied: list[str] = []
    org_compliant: bool | None = None
    simulation_passed: bool | None = None
    config_file = ""

    # When --json is used, suppress all text output; collect data only.
    text_output = not use_json

    def _add_error(check: str, message: str, location: str = "") -> None:
        errors.append({"check": check, "message": message, "location": location})

    def _add_warning(check: str, message: str, location: str = "") -> None:
        warnings.append({"check": check, "message": message, "location": location})

    def _add_info(check: str, message: str) -> None:
        info.append({"check": check, "message": message})

    def _print_ok(msg: str) -> None:
        if text_output and not quiet:
            print(f"  {_green('✓')} {msg}")

    def _print_warn(msg: str) -> None:
        if text_output:
            print(f"  {_yellow('⚠')} {msg}")

    def _print_err(msg: str) -> None:
        if text_output:
            print(f"  {_red('✗')} {msg}")

    def _print_info(msg: str) -> None:
        if text_output and not quiet:
            print(f"  {_cyan('ℹ')} {msg}")

    # ── 1. File discovery ────────────────────────────────────────
    try:
        from nomotic.config_loader import _find_config_file

        resolved = _find_config_file(target_path)
        config_file = str(resolved)
    except FileNotFoundError as exc:
        if use_json:
            result = {
                "status": "error",
                "file": str(target_path),
                "errors": [{"check": "file_discovery", "message": str(exc)}],
                "warnings": [],
                "info": [],
                "presets_applied": [],
                "org_compliant": None,
                "simulation_passed": None,
            }
            print(json.dumps(result, indent=2))
        else:
            print(f"\n  {_bold('Nomotic Validate')}: {target_path}")
            print(f"  {'━' * 31}\n")
            _print_err(f"File not found: {exc}")
            print(f"\n  Result: {_red('ERROR')}\n")
        sys.exit(2)

    if text_output and not quiet:
        print(f"\n  {_bold('Nomotic Validate')}: {Path(config_file).name}")
        print(f"  {'━' * 31}\n")

    # ── 2. YAML parse ────────────────────────────────────────────
    try:
        yaml_string = Path(config_file).read_text(encoding="utf-8")
    except OSError as exc:
        _add_error("yaml_parse", f"Cannot read file: {exc}")
        if use_json:
            result = {
                "status": "error",
                "file": config_file,
                "errors": errors,
                "warnings": warnings,
                "info": info,
                "presets_applied": [],
                "org_compliant": None,
                "simulation_passed": None,
            }
            print(json.dumps(result, indent=2))
        else:
            _print_err(f"Cannot read file: {exc}")
            print(f"\n  Result: {_red('ERROR')}\n")
        sys.exit(2)

    try:
        config = load_governance_config_from_string(yaml_string, source_path=config_file)
    except ValueError as exc:
        msg = str(exc)
        _add_error("yaml_parse", msg)
        if use_json:
            result = {
                "status": "error",
                "file": config_file,
                "errors": errors,
                "warnings": warnings,
                "info": info,
                "presets_applied": [],
                "org_compliant": None,
                "simulation_passed": None,
            }
            print(json.dumps(result, indent=2))
        else:
            _print_err(f"YAML parse error: {msg}")
            print(f"\n  Result: {_red('ERROR')}\n")
        sys.exit(2)

    _print_ok("YAML syntax valid")

    # ── Apply --preset override if given ─────────────────────────
    if preset_override:
        canonical_names = get_preset_names()
        lower_map = {n.lower(): n for n in canonical_names}
        key = preset_override.lower()
        if key not in lower_map:
            from difflib import get_close_matches

            close = get_close_matches(key, [n.lower() for n in canonical_names], n=1, cutoff=0.4)
            if close:
                suggestion = lower_map[close[0]]
                _add_error(
                    "preset_override",
                    f"Unknown preset '{preset_override}'. Did you mean '{suggestion}'? "
                    f"Available presets: {', '.join(canonical_names)}",
                )
            else:
                _add_error(
                    "preset_override",
                    f"Unknown preset '{preset_override}'. "
                    f"Available presets: {', '.join(canonical_names)}",
                )
        else:
            # Apply the preset as if extends included it
            if lower_map[key] not in config.extends:
                config.extends.insert(0, lower_map[key])
            # Re-parse with the new extends
            yaml_with_preset = config.raw.copy()
            yaml_with_preset["extends"] = list(config.extends)
            try:
                import yaml as _yaml

                new_yaml = _yaml.dump(yaml_with_preset, default_flow_style=False)
                config = load_governance_config_from_string(new_yaml, source_path=config_file)
            except Exception:
                # Fallback: just keep the modified config
                pass

    # ── 3. Schema validation ─────────────────────────────────────
    schema_errors = validate_governance_config(config)
    if schema_errors:
        for err in schema_errors:
            _add_error("schema", err)
    else:
        agent_count = len(config.agents)
        _print_ok(f"Schema validated (version {config.version}, {agent_count} agent{'s' if agent_count != 1 else ''})")

    # ── 4. Preset resolution ─────────────────────────────────────
    presets_applied = list(config.extends)
    if config.extends:
        all_valid = True
        for name in config.extends:
            try:
                get_preset(name)
            except KeyError:
                all_valid = False
        if all_valid:
            _print_ok(f"Preset resolved: {', '.join(config.extends)}")
    else:
        _print_ok("No presets (using defaults)")

    # ── Compliance preset disclaimer ─────────────────────────────
    for name in config.extends:
        try:
            preset = get_preset(name)
            if preset.framework_reference:
                framework = preset.framework_reference
                disclaimer_msg = (
                    f"{name} is Nomotic's interpretation aligned to "
                    f"{framework} concerns. It does not constitute "
                    f"{framework} compliance."
                )
                _add_info("preset_disclaimer", disclaimer_msg)
                _print_info(disclaimer_msg)
        except KeyError:
            pass

    # ── 5. Dimension validation ──────────────────────────────────
    valid_dims = set(DIMENSION_NAMES)
    configured_dims = set(config.dimension_weights.keys()) & valid_dims
    _print_ok(f"All {len(configured_dims)} dimensions configured")

    # ── 6. Threshold logic ───────────────────────────────────────
    if config.allow_threshold > config.deny_threshold:
        _print_ok(
            f"Thresholds consistent (allow: {config.allow_threshold:.2f}, "
            f"deny: {config.deny_threshold:.2f})"
        )

    # ── 7. Trust settings ────────────────────────────────────────
    missing_trust = TRUST_SETTING_KEYS - set(config.trust_settings)
    if not missing_trust:
        _print_ok("Trust settings valid")

    # ── 8. Agent scope validation ────────────────────────────────
    all_scopes_valid = True
    for agent in config.agents:
        if not agent.actions:
            all_scopes_valid = False
    if all_scopes_valid and config.agents:
        _print_ok("Agent scopes valid")

    # ── 9. Logical checks ───────────────────────────────────────
    if text_output and not quiet:
        print()

    # 9a. Veto-weight contradictions
    veto_set = set(config.veto_dimensions)
    for dim_name in veto_set:
        weight = config.dimension_weights.get(dim_name, 1.0)
        if weight == 0.0:
            _add_warning(
                "veto_weight_contradiction",
                f"Dimension '{dim_name}' has veto authority but weight 0.0",
                f"dimensions.vetoes.{dim_name}",
            )

    # 9b. Missing vetoes on high-weight critical dimensions
    critical_dims = {"scope_compliance", "authority_verification"}
    for dim_name in critical_dims:
        weight = config.dimension_weights.get(dim_name, 1.0)
        if weight > 1.5 and dim_name not in veto_set:
            _add_warning(
                "missing_veto",
                f"Dimension '{dim_name}' has weight {weight} but no veto authority",
                f"dimensions.weights.{dim_name}",
            )

    # 9c. Overprivileged agents
    for agent in config.agents:
        if len(agent.actions) > 5:
            _add_warning(
                "agent_scope",
                f"Agent '{agent.agent_id}' has {len(agent.actions)} action types — consider narrowing scope",
                f"agents.{agent.agent_id}.scope.actions",
            )
        if len(agent.targets) > 10:
            _add_warning(
                "agent_scope",
                f"Agent '{agent.agent_id}' has {len(agent.targets)} targets — consider narrowing scope",
                f"agents.{agent.agent_id}.scope.targets",
            )

    # 9d. Trust floor above agent minimums
    trust_floor = config.trust_settings.get("floor", 0.0)
    for agent in config.agents:
        if trust_floor > agent.min_trust_for_action:
            _add_warning(
                "trust_floor",
                f"Trust floor ({trust_floor}) is above agent '{agent.agent_id}' "
                f"min_trust_for_action ({agent.min_trust_for_action})",
                f"agents.{agent.agent_id}.trust.min_trust_for_action",
            )

    # Print warnings
    for w in warnings:
        _print_warn(w["message"])

    if text_output and not quiet and warnings:
        print()

    # ── 10. Org policy enforcement ───────────────────────────────
    org_config = None
    try:
        org_config = load_org_config(path=org_path)
    except FileNotFoundError as exc:
        _add_error("org_policy", f"Org config not found: {exc}")
    except (ValueError, ImportError) as exc:
        _add_error("org_policy", str(exc))

    if org_config is not None:
        violations = enforce_org_policy(config, org_config)
        if violations:
            org_compliant = False
            for v in violations:
                _add_error(
                    "org_policy",
                    f"{v.field}: {v.requirement} — {v.actual}",
                    v.field,
                )
            _print_err(f"Org policy: {len(violations)} violation(s) ({org_config.org_name})")
        else:
            org_compliant = True
            _print_ok(f"Org policy: compliant ({org_config.org_name})")
    elif org_path:
        # User explicitly asked for org check but it failed
        pass
    else:
        # No org config found — that's fine, it's optional
        _print_info("No org policy found (skipped)")

    # ── 11. Simulation check ─────────────────────────────────────
    if not errors and config.agents:
        try:
            from nomotic.runtime import GovernanceRuntime
            from nomotic.types import Action, AgentContext, TrustProfile, Verdict

            runtime_config = config.to_runtime_config()
            runtime = GovernanceRuntime(runtime_config)

            # Use the first agent for simulation
            first_agent = config.agents[0]
            agent_id = first_agent.agent_id

            # Configure scope for the agent via the runtime
            runtime.configure_scope(
                agent_id, set(first_agent.actions),
                actor="validate", reason="Validation simulation",
            )

            # Configure boundaries if agent has targets
            if first_agent.targets:
                runtime.configure_boundaries(
                    agent_id, set(first_agent.targets),
                    actor="validate", reason="Validation simulation",
                )

            trust = TrustProfile(agent_id=agent_id, overall_trust=first_agent.initial_trust)
            ctx = AgentContext(agent_id=agent_id, trust_profile=trust)

            # Test 1: in-scope action
            in_scope_action = Action(
                agent_id=agent_id,
                action_type=first_agent.actions[0],
                target=first_agent.targets[0] if first_agent.targets else "test-target",
            )
            runtime.evaluate(in_scope_action, ctx)

            # Test 2: out-of-scope action should be denied
            out_scope_action = Action(
                agent_id=agent_id,
                action_type="__nomotic_validate_out_of_scope__",
                target="__nomotic_validate_forbidden__",
            )
            # Refresh trust profile for second evaluation
            trust2 = TrustProfile(agent_id=agent_id, overall_trust=first_agent.initial_trust)
            ctx2 = AgentContext(agent_id=agent_id, trust_profile=trust2)
            out_verdict = runtime.evaluate(out_scope_action, ctx2)

            if out_verdict.verdict == Verdict.DENY:
                simulation_passed = True
                _print_ok("Simulation: out-of-scope actions correctly denied")
            else:
                simulation_passed = False
                _add_error(
                    "simulation",
                    "Out-of-scope action was not denied — governance may be too permissive",
                )

        except Exception as exc:
            simulation_passed = False
            _add_error("simulation", f"Simulation failed: {exc}")

    # ── Final result ─────────────────────────────────────────────
    if errors:
        status = "fail"
        exit_code = 1
    elif strict and warnings:
        status = "fail"
        exit_code = 1
    else:
        status = "pass"
        exit_code = 0

    if use_json:
        result = {
            "status": status,
            "file": config_file,
            "errors": errors,
            "warnings": warnings,
            "info": info,
            "presets_applied": presets_applied,
            "org_compliant": org_compliant,
            "simulation_passed": simulation_passed,
        }
        print(json.dumps(result, indent=2))
    else:
        # Print errors not already shown inline
        for e in errors:
            _print_err(e["message"])

        # Summary
        parts = []
        if warnings:
            parts.append(f"{len(warnings)} warning{'s' if len(warnings) != 1 else ''}")
        if errors:
            parts.append(f"{len(errors)} error{'s' if len(errors) != 1 else ''}")
        detail = f" ({', '.join(parts)})" if parts else ""

        print()
        if status == "pass":
            print(f"  Result: {_green('PASS')}{detail}\n")
        else:
            print(f"  Result: {_red('FAIL')}{detail}\n")

    sys.exit(exit_code)


# ── New command ──────────────────────────────────────────────────────────


def _cmd_new(args: argparse.Namespace) -> None:
    """Generate a new nomotic.yaml governance config for this project."""
    from nomotic.presets import (
        get_preset,
        get_preset_names,
    )

    target_dir = Path(args.path).resolve()
    if not target_dir.is_dir():
        print(f"Directory not found: {args.path}", file=sys.stderr)
        sys.exit(1)

    yaml_path = target_dir / "nomotic.yaml"

    # Check if file exists (unless --force)
    if yaml_path.exists() and not args.force:
        print()
        print(f"  {_yellow('⚠')} nomotic.yaml already exists in this directory.")
        try:
            answer = input("  Overwrite? [y/N]: ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print()
            sys.exit(1)
        if answer != "y":
            print("  Aborted.")
            sys.exit(0)

    # Load defaults from setup config
    setup_config = _load_nomotic_config(args.base_dir)
    default_owner = setup_config.get("owner", "")
    default_preset_name = setup_config.get("default_preset", "standard")
    # If compliance_presets exist, use first as default
    compliance_presets_cfg = setup_config.get("compliance_presets", [])
    if compliance_presets_cfg:
        default_preset_name = compliance_presets_cfg[0]

    default_name = target_dir.name

    # Resolve all values (interactive or from flags)
    all_preset_names = get_preset_names()

    # Agent name
    agent_name = args.name
    if agent_name is None:
        print()
        print(f"  {_bold('Nomotic New Project')}")
        print(f"  {'━' * 19}")
        print()
        try:
            agent_name = input(f"  Agent name [{default_name}]: ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            sys.exit(1)
        if not agent_name:
            agent_name = default_name
    else:
        print()
        print(f"  {_bold('Nomotic New Project')}")
        print(f"  {'━' * 19}")
        print()

    # Actions
    actions_str = args.actions
    if actions_str is None:
        try:
            actions_str = input("  What can this agent do?\n  Actions (comma-separated) [read, query]: ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            sys.exit(1)
        if not actions_str:
            actions_str = "read, query"
    actions = [a.strip() for a in actions_str.split(",") if a.strip()]

    # Targets
    targets_str = args.targets
    if targets_str is None:
        try:
            targets_str = input("\n  What resources does it access?\n  Targets (comma-separated): ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            sys.exit(1)
    targets = [t.strip() for t in targets_str.split(",") if t.strip()] if targets_str else []

    # Preset selection
    preset_name = args.preset
    if preset_name is None:
        severity = list_severity_presets()
        compliance = list_compliance_presets()

        print()
        print("  Governance preset:")
        idx = 1
        preset_menu: list[str] = []
        for p in severity:
            desc = p.description.split(".")[0].strip().lower() if p.description else ""
            print(f"    [{idx}] {p.name} — {desc}")
            preset_menu.append(p.name)
            idx += 1
        for p in compliance:
            desc = p.description.split(".")[0].strip().lower() if p.description else ""
            print(f"    [{idx}] {p.name} — {desc}")
            preset_menu.append(p.name)
            idx += 1

        # Determine default selection number
        default_num = 1
        for i, name in enumerate(preset_menu):
            if name == default_preset_name:
                default_num = i + 1
                break

        print()
        try:
            sel_str = input(f"  Selection [{default_num}]: ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            sys.exit(1)
        if not sel_str:
            sel_num = default_num
        else:
            try:
                sel_num = int(sel_str)
            except ValueError:
                print(f"  Invalid selection: {sel_str}", file=sys.stderr)
                sys.exit(1)
        if sel_num < 1 or sel_num > len(preset_menu):
            print(f"  Invalid selection: {sel_num}", file=sys.stderr)
            sys.exit(1)
        preset_name = preset_menu[sel_num - 1]
    else:
        # Validate the preset name
        lower_name = preset_name.lower()
        if lower_name not in [n.lower() for n in all_preset_names]:
            # Try to suggest
            suggestion = None
            for n in all_preset_names:
                if lower_name in n or n in lower_name:
                    suggestion = n
                    break
            msg = f"Unknown preset '{preset_name}'."
            if suggestion:
                msg += f" Did you mean '{suggestion}'?"
            available = ", ".join(all_preset_names)
            print(f"\n  {_red(msg)}", file=sys.stderr)
            print(f"  Available presets: {available}\n", file=sys.stderr)
            sys.exit(1)
        # Normalize to canonical name
        for n in all_preset_names:
            if n.lower() == lower_name:
                preset_name = n
                break

    # Owner
    owner = args.owner
    if owner is None:
        default_display = default_owner if default_owner else ""
        prompt_suffix = f" [{default_display}]" if default_display else ""
        print()
        try:
            owner = input(f"  Owner{prompt_suffix}: ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            sys.exit(1)
        if not owner:
            owner = default_owner

    # Reason
    reason = args.reason
    if reason is None:
        print()
        try:
            reason = input("  Why does this agent exist?\n  Reason: ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            sys.exit(1)

    # Show compliance disclaimer if applicable
    try:
        preset_obj = get_preset(preset_name)
        if preset_obj.disclaimer:
            fw = preset_obj.framework_reference or preset_obj.display_name
            print()
            print(f"  {_yellow('ℹ')} Using {preset_name} preset. This is Nomotic's interpretation aligned to")
            print(f"    {fw} concerns. It does not constitute {fw} compliance.")
    except KeyError:
        pass

    # Generate YAML content
    boundaries = targets  # boundaries = targets by default

    # Build actions YAML list
    actions_yaml = "[" + ", ".join(actions) + "]"
    targets_yaml = "[" + ", ".join(targets) + "]" if targets else "[]"
    boundaries_yaml = "[" + ", ".join(boundaries) + "]" if boundaries else "[]"

    lines = []
    lines.append('version: "1.0"')
    lines.append("")
    lines.append(f'extends: "{preset_name}"')
    lines.append("")
    lines.append("agents:")
    lines.append(f"  {agent_name}:")
    lines.append("    scope:")
    lines.append(f"      actions: {actions_yaml}")
    lines.append(f"      targets: {targets_yaml}")
    lines.append(f"      boundaries: {boundaries_yaml}")
    lines.append("    trust:")
    lines.append("      initial: 0.5")
    lines.append("      minimum_for_action: 0.3")
    if owner:
        lines.append(f'    owner: "{owner}"')
    if reason:
        lines.append(f'    reason: "{reason}"')

    if args.full:
        lines.append("")
        lines.append("# ─── Optional overrides ───────────────────────────────────────")
        lines.append("# Uncomment and modify to override preset values.")
        lines.append("#")
        lines.append("# dimensions:")
        lines.append("#   weights:")
        lines.append("#     scope_compliance: 2.0")
        lines.append("#     authority_verification: 1.5")
        lines.append("#   vetoes:")
        lines.append("#     - scope_compliance")
        lines.append("#     - authority_verification")
        lines.append("#")
        lines.append("# thresholds:")
        lines.append("#   allow: 0.80")
        lines.append("#   deny: 0.30")
        lines.append("#")
        lines.append("# trust:")
        lines.append("#   success_increment: 0.01")
        lines.append("#   violation_decrement: 0.05")
        lines.append("#   interrupt_cost: 0.03")
        lines.append("#   decay_rate: 0.001")
        lines.append("#   floor: 0.05")
        lines.append("#   ceiling: 0.95")
        lines.append("#")
        lines.append("# compliance:")
        lines.append("#   frameworks: []")

    lines.append("")  # trailing newline

    yaml_content = "\n".join(lines)

    # Write the file
    yaml_path.write_text(yaml_content, encoding="utf-8")
    print()
    print(f"  {_green('✓')} Created nomotic.yaml")

    # Auto-validate unless --no-validate
    if not args.no_validate:
        try:
            from nomotic.config_loader import (
                load_governance_config_from_string,
                validate_governance_config,
            )

            config = load_governance_config_from_string(yaml_content, source_path=str(yaml_path))
            errors = validate_governance_config(config)
            if errors:
                print(f"  {_red('✗')} Validation failed:")
                for err in errors:
                    print(f"    - {err}")
            else:
                print(f"  {_green('✓')} Validation passed")
        except Exception as exc:
            print(f"  {_yellow('⚠')} Validation error: {exc}")

    print()
    print("  Next: nomotic validate nomotic.yaml")
    print()


# ── Settings command ─────────────────────────────────────────────────────


def _cmd_status_global(args: argparse.Namespace) -> None:
    """Show the current effective governance configuration."""
    from nomotic.presets import (
        get_preset,
        get_preset_names,
    )

    show_org = getattr(args, "org_only", False)
    show_presets_list = getattr(args, "presets_list", False)
    preset_name = getattr(args, "preset_detail", None)
    show_policies = getattr(args, "policies_list", False)

    # ── Active policies ─────────────────────────────────────────────
    if show_policies:
        from nomotic.policy import PolicyEngine

        engine = PolicyEngine()
        policies = engine.list_policies()
        print()
        print(f"  {_bold('Active Policies')}")
        print(f"  {'━' * 15}")
        print()
        if not policies:
            print("  No policies loaded.")
            print()
            print("  Policy directories searched:")
            print("    ./nomotic-policies/")
            print(f"    {Path.home() / '.nomotic' / 'policies'}/")
            print()
            print("  Install PyYAML for policy-as-code support: pip install pyyaml")
        else:
            for p in policies:
                status_icon = _green("\u2713") if p.enabled else _yellow("\u25cb")
                verdict = p.then.get("verdict", "?")
                print(f"    {status_icon} {_bold(p.name)} \u2192 {verdict} (priority={p.priority})")
                if p.description:
                    print(f"      {p.description}")
            print()
            issues = engine.validate_all()
            if issues:
                warn_icon = _yellow("\u26a0")
                print(
                    f"  {warn_icon} {len(issues)} validation issue(s)"
                    " found. Run 'nomotic policy-validate' for details."
                )
            else:
                ok_icon = _green("\u2713")
                print(f"  {ok_icon} All policies valid.")
        print()
        return

    # ── Single preset detail ────────────────────────────────────────
    if preset_name is not None:
        _settings_show_preset(preset_name, get_preset, get_preset_names)
        return

    # ── List all presets ────────────────────────────────────────────
    if show_presets_list:
        _settings_list_presets(list_compliance_presets, list_severity_presets, PRESET_DISCLAIMER)
        return

    # ── Org-only view ───────────────────────────────────────────────
    if show_org:
        print()
        _settings_show_org(args.base_dir)
        print()
        return

    # ── Full settings view ──────────────────────────────────────────
    _settings_show_full(
        args.base_dir,
        list_compliance_presets,
        list_severity_presets,
    )


def _settings_show_preset(
    preset_name: str,
    get_preset_fn,
    get_preset_names_fn,
) -> None:
    """Display full details of a single preset."""
    all_names = get_preset_names_fn()
    try:
        preset = get_preset_fn(preset_name)
    except KeyError:
        # Try to find a close match
        lower = preset_name.lower()
        suggestion = None
        for n in all_names:
            if lower in n or n in lower:
                suggestion = n
                break
        msg = f"Unknown preset '{preset_name}'."
        if suggestion:
            msg += f" Did you mean '{suggestion}'?"
        available = ", ".join(all_names)
        print(f"\n  {_red(msg)}")
        print(f"  Available presets: {available}\n")
        sys.exit(1)

    title = f"Preset: {preset.name}"
    print()
    print(f"  {_bold(title)}")
    print(f"  {'━' * len(title)}")

    if preset.display_name and preset.display_name != preset.name:
        print(f"  Display Name: {preset.display_name}")
    if preset.framework_reference:
        certified_note = "aligned, not certified"
        print(f"  Framework:    {preset.framework_reference} ({certified_note})")
    print(f"  Category:     {preset.category}")
    print(f"  Description:  {preset.description}")

    # Disclaimer for compliance presets only
    if preset.disclaimer:
        fw = preset.framework_reference or preset.display_name
        print()
        print(f"  {_yellow('⚠')} This preset is Nomotic's interpretation of governance weights aligned")
        print(f"    to {fw} concerns. It does not constitute {fw} compliance. Consult")
        print("    your compliance team before deploying in regulated environments.")

    # Dimension weights
    print()
    print("  Dimension Weights:")
    for dim, weight in preset.dimension_weights.items():
        print(f"    {dim + ':':<28s} {weight}")

    # Veto dimensions
    print()
    print("  Veto Dimensions:")
    # Wrap veto list
    vetoes = preset.veto_dimensions
    if vetoes:
        lines: list[str] = []
        line = "    "
        for i, v in enumerate(vetoes):
            sep = ", " if i < len(vetoes) - 1 else ""
            if len(line) + len(v) + len(sep) > 72 and line.strip():
                lines.append(line.rstrip(", "))
                line = "    " + v + sep
            else:
                line += v + sep
        if line.strip():
            lines.append(line)
        for ln in lines:
            print(ln)
    else:
        print("    (none)")

    # Thresholds
    print()
    print("  Thresholds:")
    print(f"    Allow: {preset.allow_threshold}")
    print(f"    Deny:  {preset.deny_threshold}")

    # Trust settings
    print()
    print("  Trust:")
    ts = preset.trust_settings
    print(f"    Success increment:    {ts.get('success_increment', 'N/A')}")
    print(f"    Violation decrement:  {ts.get('violation_decrement', 'N/A')}")
    print(f"    Interrupt cost:       {ts.get('interrupt_cost', 'N/A')}")
    print(f"    Decay rate:           {ts.get('decay_rate', 'N/A')}")
    print(f"    Floor:                {ts.get('floor', 'N/A')}")
    print(f"    Ceiling:              {ts.get('ceiling', 'N/A')}")
    print()


def _settings_list_presets(
    list_compliance_fn,
    list_severity_fn,
    disclaimer: str,
) -> None:
    """List all available presets grouped by category."""
    compliance = list_compliance_fn()
    severity = list_severity_fn()

    print()
    print(f"  {_bold('Available Presets')}")
    print(f"  {'━' * 17}")
    print()

    # Compliance-aligned
    print(f"  {_bold('Compliance-Aligned:')}")
    for p in compliance:
        desc_short = p.description.split(".")[0] if p.description else ""
        print(f"    {p.name:<18s} {p.display_name} — {desc_short.strip().lower()}")
    print()
    print(f"    {_yellow('⚠')} Compliance-aligned presets are Nomotic's interpretation of governance")
    print("      weights. They do not constitute compliance with the referenced frameworks.")
    print()

    # Severity tiers
    print(f"  {_bold('Severity Tiers:')}")
    _severity_descriptions = {
        "standard": "Reasonable defaults for general use",
        "strict": "Elevated security, recommended for production",
        "ultra_strict": "Maximum governance for regulated industries",
    }
    for p in severity:
        desc = _severity_descriptions.get(p.name, p.description)
        print(f"    {p.name:<18s} {desc}")
    print()


def _settings_show_org(base_dir) -> None:
    """Show org governance section."""
    from nomotic.org_governance import load_org_config

    org_config = None
    try:
        org_config = load_org_config()
    except Exception:
        pass

    # Also check base_dir fallback
    if org_config is None:
        org_path = Path(base_dir) / "org-governance.yaml"
        if org_path.is_file():
            try:
                org_config = load_org_config(path=str(org_path))
            except Exception:
                pass

    print(f"  {_bold('Org Governance:')}")
    if org_config is None:
        print("    Not configured. Create ~/.nomotic/org-governance.yaml or run 'nomotic setup'.")
        return

    print(f"    Source:     {org_config.source_path}")
    if org_config.org_name:
        print(f"    Org Name:   {org_config.org_name}")
    print()

    if org_config.minimum_weights:
        print("    Minimum Weights:")
        for dim, weight in org_config.minimum_weights.items():
            print(f"      {dim + ':':<28s} {weight}")
        print()

    if org_config.required_vetoes:
        vetoes_str = ", ".join(org_config.required_vetoes)
        print(f"    Required Vetoes:    {vetoes_str}")

    print(f"    Min Allow Threshold: {org_config.minimum_allow_threshold}")
    print(f"    Min Deny Threshold:  {org_config.minimum_deny_threshold}")
    print(f"    Min Violation Cost:  {org_config.minimum_violation_decrement}")
    print(f"    Max Success Incr:    {org_config.maximum_success_increment}")


def _settings_show_full(
    base_dir,
    list_compliance_fn,
    list_severity_fn,
) -> None:
    """Show the complete settings view."""
    from nomotic import __version__

    config = _load_nomotic_config(Path(base_dir))
    config_path = Path(base_dir) / "config.json"

    print()
    print(f"  {_bold('Nomotic Settings')}")
    print(f"  {'━' * 16}")
    print()

    # Installation section
    print(f"  {_bold('Installation:')}")
    print(f"    Config:     {config_path}")
    print(f"    Version:    {__version__}")
    print(f"    Org:        {config.get('organization', '(not set)')}")
    print(f"    Owner:      {config.get('owner', '(not set)')}")
    print(f"    Zone:       {config.get('default_zone', '(not set)')}")
    print()

    # Org Governance section
    _settings_show_org(base_dir)
    print()

    # Available presets summary
    compliance = list_compliance_fn()
    severity = list_severity_fn()

    print(f"  {_bold('Available Presets:')}")
    compliance_names = ", ".join(p.name for p in compliance)
    severity_names = ", ".join(p.name for p in severity)
    print(f"    Compliance-Aligned: {compliance_names}")
    print(f"    Severity Tiers:     {severity_names}")
    print()
    print("    Use 'nomotic status --preset <name>' for details.")
    print()


# ── Cost projection ──────────────────────────────────────────────────────


def _cmd_cost(args: argparse.Namespace) -> None:
    """Show or configure cost projection for an agent, group, or fleet."""
    base_dir = getattr(args, "base_dir", _DEFAULT_BASE)

    # Fleet cost modes: --agent, --group, --all
    cost_agent = getattr(args, "cost_agent", None)
    cost_group = getattr(args, "cost_group", None)
    cost_all = getattr(args, "cost_all", False)

    if cost_agent or cost_group or cost_all:
        _cmd_cost_fleet(args, base_dir, cost_agent, cost_group, cost_all)
        return

    # Legacy per-agent CostTracker mode
    from nomotic.cost import CostTracker

    agent_id = args.agent_id
    if agent_id is None:
        print("Usage: nomotic cost <agent_id> | --agent <id> | --group <id> | --all",
              file=sys.stderr)
        sys.exit(1)

    tracker = CostTracker(base_dir)
    profile = tracker.get_profile(agent_id)

    if args.configure:
        # Interactive configuration
        print(f"Configure cost settings for: {_bold(agent_id)}")
        print()

        raw = input(
            f"  Estimated cost per run [{profile.estimated_cost_per_run or 'auto'}]: "
        ).strip()
        if raw:
            if raw.lower() in ("none", "auto", ""):
                tracker.configure(agent_id, estimated_cost_per_run=None)
            else:
                try:
                    tracker.configure(
                        agent_id, estimated_cost_per_run=float(raw)
                    )
                except ValueError:
                    print("  Invalid number, skipping.", file=sys.stderr)

        raw = input(
            f"  Daily budget advisory [{profile.daily_budget_advisory or 'none'}]: "
        ).strip()
        if raw:
            if raw.lower() in ("none", ""):
                tracker.configure(agent_id, daily_budget_advisory=None)
            else:
                try:
                    tracker.configure(
                        agent_id, daily_budget_advisory=float(raw)
                    )
                except ValueError:
                    print("  Invalid number, skipping.", file=sys.stderr)

        raw = input(
            f"  Monthly budget advisory [{profile.monthly_budget_advisory or 'none'}]: "
        ).strip()
        if raw:
            if raw.lower() in ("none", ""):
                tracker.configure(agent_id, monthly_budget_advisory=None)
            else:
                try:
                    tracker.configure(
                        agent_id, monthly_budget_advisory=float(raw)
                    )
                except ValueError:
                    print("  Invalid number, skipping.", file=sys.stderr)

        print()
        print("Cost settings updated.")
        return

    summary = profile.summary()

    if args.cost_json:
        print(json.dumps(summary, indent=2))
        return

    # Human-readable display
    print(f"Cost Profile: {_bold(agent_id)}")
    print("\u2501" * 30)
    print(f"  Total runs:              {summary['total_runs']}")
    print(f"  Average cost/run:        ${summary['average_cost_per_run']:.4f}")
    print(f"  Average execution:       {summary['average_execution_ms']:.1f}ms")
    print(
        f"  Total estimated cost:    ${summary['total_estimated_cost']:,.2f}"
    )
    print(f"  Daily projection:        ${summary['daily_projection']:,.2f}")
    print(f"  Monthly projection:      ${summary['monthly_projection']:,.2f}")

    daily_adv = summary["daily_budget_advisory"]
    if daily_adv is not None:
        status = (
            _green("\u2713 (under budget)")
            if summary["daily_projection"] <= daily_adv
            else _red("\u2717 (OVER BUDGET)")
        )
        print(f"  Daily budget advisory:   ${daily_adv:,.2f}  {status}")
    else:
        print("  Daily budget advisory:   not set")

    monthly_adv = summary["monthly_budget_advisory"]
    if monthly_adv is not None:
        status = (
            _green("\u2713 (under budget)")
            if summary["monthly_projection"] <= monthly_adv
            else _red("\u2717 (OVER BUDGET)")
        )
        print(f"  Monthly budget advisory: ${monthly_adv:,.2f}  {status}")
    else:
        print("  Monthly budget advisory: not set")
    print()


def _cmd_cost_fleet(
    args: argparse.Namespace,
    base_dir: Path,
    cost_agent: str | None,
    cost_group: str | None,
    cost_all: bool,
) -> None:
    """Fleet cost tracking via FleetCostAggregator."""
    from nomotic.audit_store import AuditStore
    from nomotic.fleet import FleetCostAggregator

    store = AuditStore(base_dir)
    agg = FleetCostAggregator(audit_store=store)

    if cost_agent:
        rec = agg.get_agent_cost(cost_agent)
        projected_daily, projected_monthly = agg._compute_projections(
            rec.cost_today_usd, rec.cost_this_month_usd
        )
        print()
        print(f"  Cost Summary \u2014 {_bold(rec.agent_id)}")
        print()
        print(f"  Total cost:          ${rec.total_cost_usd:,.2f}")
        print(f"  This month:          ${rec.cost_this_month_usd:,.2f}")
        print(f"  Today:               ${rec.cost_today_usd:,.2f}")
        print(f"  Projected (daily):   ${projected_daily:,.2f}  \u2190 based on today's trajectory")
        print(f"  Projected (monthly): ${projected_monthly:,.2f}  \u2190 based on this month's trajectory")
        print(f"  Avg cost/action:     ${rec.avg_cost_per_action_usd:.4f}")
        print(f"  Evaluated actions:   {rec.evaluated_actions:,}")
        print()

    elif cost_group:
        try:
            summary = agg.get_group_cost(cost_group)
        except ValueError as e:
            print(f"Error: {e}", file=sys.stderr)
            sys.exit(1)

        print()
        print(f"  Cost Summary \u2014 {_bold(summary.group_name)}")
        print()

        # Today with budget status
        today_line = f"  Today:               ${summary.cost_today_usd:,.2f}"
        if summary.daily_budget_usd is not None:
            if summary.daily_budget_alert:
                today_line += f"  [budget: ${summary.daily_budget_usd:,.2f} \u2014 \u26a0 ON TRACK TO EXCEED]"
            else:
                today_line += f"  [budget: ${summary.daily_budget_usd:,.2f} \u2014 OK]"
        print(today_line)

        # This month with budget status
        month_line = f"  This month:          ${summary.cost_this_month_usd:,.2f}"
        if summary.monthly_budget_usd is not None:
            if summary.monthly_budget_alert:
                month_line += f"  [budget: ${summary.monthly_budget_usd:,.2f} \u2014 \u26a0 ON TRACK TO EXCEED]"
            else:
                month_line += f"  [budget: ${summary.monthly_budget_usd:,.2f} \u2014 OK]"
        print(month_line)

        trend_daily = "\u2190 on track" if not summary.daily_budget_alert else "\u2190 \u26a0"
        trend_monthly = "\u2190 on track" if not summary.monthly_budget_alert else "\u2190 \u26a0"
        print(f"  Projected daily:     ${summary.projected_daily_usd:,.2f}  {trend_daily}")
        print(f"  Projected monthly:   ${summary.projected_monthly_usd:,.2f}  {trend_monthly}")
        print(f"  Agents: {summary.agent_count}")

        # 7-Day Cost Trend
        if summary.daily_costs_7d:
            print()
            print("  7-Day Cost Trend")
            print("  \u2500" * 49)
            daily_str = "  ".join(f"${c:,.2f}" for c in summary.daily_costs_7d)
            print(f"    Daily:   {daily_str}")
            print(f"    7d avg:  ${summary.moving_average_7d:,.2f}/day")

            rate_pct = summary.daily_growth_rate * 100
            if summary.cost_acceleration_alert:
                print(f"    Growth:  +{rate_pct:.1f}%/day  \u26a0 ACCELERATING")
            elif summary.daily_growth_rate < 0:
                print(f"    Growth:  {rate_pct:+.1f}%/day   (spend decelerating)")
            else:
                print(f"    Growth:  {rate_pct:+.1f}%/day   (within normal range)")

        if summary.agent_records:
            print()
            print("  Agent breakdown:")
            for ar in sorted(summary.agent_records, key=lambda r: r.cost_today_usd, reverse=True):
                print(
                    f"    {ar.agent_id:20s} ${ar.cost_today_usd:,.2f} today   "
                    f"${ar.cost_this_month_usd:,.2f} month"
                )
        print()

    elif cost_all:
        all_records = agg.get_all_costs()
        fleet_today = sum(r.cost_today_usd for r in all_records)
        fleet_month = sum(r.cost_this_month_usd for r in all_records)
        fleet_total = sum(r.total_cost_usd for r in all_records)

        print()
        print(f"  {_bold('Fleet Cost Summary')}")
        print()
        print(f"  Total fleet cost:    ${fleet_total:,.2f}")
        print(f"  Fleet cost today:    ${fleet_today:,.2f}")
        print(f"  Fleet cost (month):  ${fleet_month:,.2f}")
        print(f"  Agents: {len(all_records)}")
        print()

        if all_records:
            print("  Agent breakdown (sorted by total cost):")
            for ar in all_records:
                print(
                    f"    {ar.agent_id:20s} ${ar.total_cost_usd:>8,.2f} total   "
                    f"${ar.cost_today_usd:>8,.2f} today   "
                    f"${ar.cost_this_month_usd:>8,.2f} month"
                )
            print()


# ── Argument parser ──────────────────────────────────────────────────────


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="nomotic",
        description="Nomotic — Behavioral Control Plane for agentic AI",
    )
    parser.add_argument(
        "--version", action="version", version=f"nomotic {_CLI_VERSION}",
    )
    parser.add_argument(
        "--base-dir",
        type=Path,
        default=_DEFAULT_BASE,
        help="Base directory for nomotic data (default: ~/.nomotic)",
    )
    parser.add_argument(
        "--roles-file",
        type=Path,
        default=None,
        help="Path to roles config file (YAML or JSON)",
    )

    sub = parser.add_subparsers(dest="command")

    # setup
    sub.add_parser("setup", help="Configure Nomotic defaults (organization, owner, zone)")

    # new (project config generator)
    new = sub.add_parser("new", help="Generate a nomotic.yaml governance config for this project")
    new.add_argument(
        "path", nargs="?", default=".",
        help="Directory to create nomotic.yaml in (default: current directory)",
    )
    new.add_argument("--name", default=None, help="Agent name (default: directory name)")
    new.add_argument("--preset", default=None, help="Governance preset (e.g., strict, hipaa_aligned)")
    new.add_argument("--actions", default=None, help="Comma-separated allowed actions")
    new.add_argument("--targets", default=None, help="Comma-separated target resources")
    new.add_argument("--owner", default=None, help="Agent owner (default: from setup config)")
    new.add_argument("--reason", default=None, help="Why this agent exists")
    new.add_argument("--force", action="store_true", help="Overwrite existing nomotic.yaml")
    new.add_argument("--full", action="store_true", help="Include commented-out override sections")
    new.add_argument("--no-validate", action="store_true", help="Skip auto-validation after creation")

    # birth
    birth = sub.add_parser("birth", help="Create a new agent")
    birth.add_argument("--name", default=None, help="Agent name")
    birth.add_argument("--agent-id", dest="agent_id_compat", default=None, help=argparse.SUPPRESS)
    birth.add_argument("--archetype", default=None, help="Behavioral archetype (optional, can be set later)")
    birth.add_argument("--org", default=None, help="Organization (default: from setup config)")
    birth.add_argument("--zone", default=None, help="Governance zone (default: from setup config)")
    birth.add_argument("--owner", default=None, help="Agent owner (default: from setup config)")
    birth.add_argument("--model-provider", default=None, help="Model provider (anthropic, openai, meta, custom)")
    birth.add_argument("--model-name", default=None, help="Model name (claude-sonnet-4-6, gpt-4o, ...)")
    birth.add_argument("--model-version", default=None, help="Model version string or commit SHA")
    birth.add_argument("--model-hash", default=None, help="SHA-256 of model card or weights manifest (optional)")
    birth.add_argument("--safety-eval", default=None, help="External safety evaluation ID (optional)")
    birth.add_argument("--known-limitations", default=None, help="Comma-separated known limitations (optional)")
    birth.add_argument("--preset", default=None, help="Compliance preset (auto-detected from archetype if omitted)")

    # init
    init_parser = sub.add_parser(
        "init",
        help="Scaffold a new governed agent project (run after nomotic setup)",
    )
    init_parser.add_argument(
        "--name", default=None,
        help="Agent name (e.g. claims-processor). Prompted if omitted.",
    )
    init_parser.add_argument(
        "--archetype", default=None,
        help="Agent archetype. Prompted interactively if omitted.",
    )
    init_parser.add_argument(
        "--framework", default=None,
        choices=["langgraph", "crewai", "openai", "claude"],
        help="Framework integration to generate. Auto-detected if omitted.",
    )
    init_parser.add_argument(
        "--no-interactive", action="store_true", default=False,
        help="Skip all prompts. Requires --name and --archetype.",
    )
    init_parser.add_argument(
        "--output-dir", default=".",
        help="Directory to write project files (default: current directory)",
    )

    # verify
    verify = sub.add_parser("verify", help="Verify a certificate")
    verify.add_argument("cert_id", help="Agent ID, name, or certificate ID")

    # inspect (consolidated agent inspection)
    inspect_ = sub.add_parser("inspect", help="Inspect an agent's governance configuration and state")
    inspect_.add_argument("agent_id", help="Agent ID, name, or certificate ID")
    inspect_.add_argument("--brief", action="store_true", help="Quick operational summary")
    inspect_.add_argument("--raw", action="store_true", help="Raw certificate JSON")
    inspect_.add_argument("--provenance", action="store_true", help="Show model provenance details")

    # suspend
    suspend = sub.add_parser("suspend", help="Suspend a certificate")
    suspend.add_argument("cert_id", help="Agent ID, name, or certificate ID")
    suspend.add_argument("--reason", required=True, help="Reason for suspension")

    # reactivate
    reactivate = sub.add_parser("reactivate", help="Reactivate a suspended certificate")
    reactivate.add_argument("cert_id", help="Agent ID, name, or certificate ID")

    # revoke
    revoke = sub.add_parser("revoke", help="Permanently revoke a certificate")
    revoke.add_argument("cert_id", help="Agent ID, name, or certificate ID")
    revoke.add_argument("--reason", required=True, help="Reason for revocation")

    # renew
    renew = sub.add_parser("renew", help="Renew a certificate with lineage link")
    renew.add_argument("cert_id", help="Agent ID, name, or certificate ID")

    # list
    list_ = sub.add_parser("list", help="List certificates")
    list_.add_argument("--status", default=None, help="Filter by status")
    list_.add_argument("--archetype", default=None, help="Filter by archetype")
    list_.add_argument("--org", default=None, help="Filter by organization")

    # reputation
    rep = sub.add_parser("reputation", help="Show trust trajectory")
    rep.add_argument("cert_id", help="Agent ID, name, or certificate ID")

    # export
    export = sub.add_parser("export", help="Export public certificate to file")
    export.add_argument("cert_id", help="Agent ID, name, or certificate ID")

    # ── archetype subcommands ────────────────────────────────────────
    archetype = sub.add_parser("archetype", help="Manage archetypes")
    arch_sub = archetype.add_subparsers(dest="archetype_command")

    arch_list = arch_sub.add_parser("list", help="List archetypes")
    arch_list.add_argument("--category", default=None, help="Filter by category")

    arch_reg = arch_sub.add_parser("register", help="Register a custom archetype")
    arch_reg.add_argument("--name", required=True, help="Archetype name")
    arch_reg.add_argument("--description", required=True, help="Description")
    arch_reg.add_argument("--category", required=True, help="Category")

    arch_val = arch_sub.add_parser("validate", help="Validate an archetype name")
    arch_val.add_argument("name", help="Archetype name to validate")

    arch_set = arch_sub.add_parser("set", help="Set archetype for an agent (interactive)")
    arch_set.add_argument("agent_identifier", help="Agent name, ID, or certificate ID")

    arch_browse = arch_sub.add_parser(
        "browse", help="Browse community archetypes from the registry"
    )
    arch_browse.add_argument(
        "--search", default=None, help="Filter by keyword in name or description"
    )

    arch_pull = arch_sub.add_parser(
        "pull", help="Download and install a community archetype"
    )
    arch_pull.add_argument("name", help="Archetype name to pull")
    arch_pull.add_argument(
        "--yes", "-y", action="store_true", help="Skip confirmation prompt"
    )

    arch_info = arch_sub.add_parser(
        "info", help="Show archetype details before installing"
    )
    arch_info.add_argument("name", help="Archetype name")

    # ── org subcommands ──────────────────────────────────────────────
    org = sub.add_parser("org", help="Manage organizations")
    org_sub = org.add_subparsers(dest="org_command")

    org_register = org_sub.add_parser("register", help="Register an organization")
    org_register.add_argument("--name", required=True, help="Organization name")
    org_register.add_argument("--email", default=None, help="Contact email")

    org_list = org_sub.add_parser("list", help="List organizations")
    org_list.add_argument("--status", default=None, help="Filter by status")

    org_val = org_sub.add_parser("validate", help="Validate an org name")
    org_val.add_argument("name", help="Organization name to validate")

    # ── zone subcommands ─────────────────────────────────────────────
    zone = sub.add_parser("zone", help="Manage governance zones")
    zone_sub = zone.add_subparsers(dest="zone_command")

    zone_val = zone_sub.add_parser("validate", help="Validate a zone path")
    zone_val.add_argument("path", help="Zone path to validate")

    # ── scope ───────────────────────────────────────────────────────
    scope = sub.add_parser("scope", help="Configure agent authority scope")
    scope.add_argument("agent_id", help="Agent ID, name, or certificate ID")
    scope_sub = scope.add_subparsers(dest="scope_command")
    scope_set = scope_sub.add_parser("set", help="Set scope and boundaries")
    scope_set.add_argument("--actions", default=None, help="Comma-separated allowed actions")
    scope_set.add_argument("--boundaries", default=None, help="Comma-separated allowed targets")
    scope_sub.add_parser("show", help="Show current scope")

    # ── rule ────────────────────────────────────────────────────────
    rule = sub.add_parser("rule", help="Manage governance rules")
    rule.add_argument("agent_id", help="Agent ID, name, or certificate ID")
    rule_sub = rule.add_subparsers(dest="rule_command")
    rule_add = rule_sub.add_parser("add", help="Add a governance rule")
    rule_add.add_argument("--type", required=True, choices=["ethical", "human-override"], help="Rule type")
    rule_add.add_argument("--condition", default=None, help="Condition expression (ethical rules)")
    rule_add.add_argument("--action", default=None, help="Action type (human-override rules)")
    rule_add.add_argument("--message", default=None, help="Message when rule triggers")
    rule_add.add_argument("--name", default=None, help="Optional rule name")

    # ── config (global configuration) ─────────────────────────────
    config = sub.add_parser("config", help="Manage Nomotic configuration")
    config_sub = config.add_subparsers(dest="config_command")
    config_set = config_sub.add_parser("set", help="Set a configuration value")
    config_set.add_argument("--retention", default=None, help="Audit retention period (2y, 3y, 5y, forever)")
    config_set.add_argument("--telemetry", default=None, choices=["on", "off"],
                            help="Enable or disable anonymous usage telemetry")

    # config backup subcommands
    backup = config_sub.add_parser("backup", help="Manage configuration backups")
    backup_sub = backup.add_subparsers(dest="backup_command")
    backup_list = backup_sub.add_parser("list", help="List available backups")
    backup_list.add_argument("--type", default=None, help="Filter by artifact type")
    backup_verify = backup_sub.add_parser("verify", help="Verify backup signatures")
    backup_verify.add_argument("--type", default=None, help="Filter by artifact type")
    backup_restore = backup_sub.add_parser("restore", help="Restore a backup")
    backup_restore.add_argument("artifact_type", help="Artifact type to restore")

    # ── test (formerly eval) ──────────────────────────────────────────
    test_parser = sub.add_parser(
        "test",
        help="Test a governance decision (simulated \u2014 does not affect production trust)",
    )
    test_parser.add_argument("agent_id", help="Agent ID, name, or certificate ID")
    test_parser.add_argument("--action", default=None, help="Action type to evaluate (required unless --adversarial)")
    test_parser.add_argument("--target", default=None, help="Target resource")
    test_parser.add_argument("--params", default=None, help="JSON parameters")
    test_parser.add_argument("--adversarial", action="store_true",
                             help="Run adversarial red team scenarios")
    test_parser.add_argument("--category", default=None,
                             help="Adversarial category (injection, escalation, drift, trust, deputy, recon)")
    test_parser.add_argument("--report", action="store_true",
                             help="Generate detailed adversarial report")

    # Hidden alias for backward compatibility
    eval_parser = sub.add_parser("eval", help=argparse.SUPPRESS)
    eval_parser.add_argument("agent_id", help="Agent ID, name, or certificate ID")
    eval_parser.add_argument("--action", required=True, help="Action type to evaluate")
    eval_parser.add_argument("--target", default=None, help="Target resource")
    eval_parser.add_argument("--params", default=None, help="JSON parameters")

    # ── simulate ────────────────────────────────────────────────────
    sim_parser = sub.add_parser("simulate",
        help="Run governed fleet simulations for demos and load testing")
    sim_sub = sim_parser.add_subparsers(dest="sim_cmd")

    # simulate batch (backward-compatible single-agent simulate)
    batch_p = sim_sub.add_parser("batch",
        help="Run a batch governance simulation for a single agent")
    batch_p.add_argument("agent_id", help="Agent ID, name, or certificate ID")
    batch_p.add_argument("--scenario", required=True,
        help="Scenario name (normal, drift, violations, mixed)")
    batch_p.add_argument("--count", type=int, default=None,
        help="Override action count")
    batch_p.add_argument("--description", default=None,
        help="Custom scenario description")

    # simulate fleet
    fleet_p = sim_sub.add_parser("fleet",
        help="Simulate a multi-department agent fleet")
    fleet_p.add_argument("--agents", type=int, default=100,
        help="Number of agents to simulate (default: 100, max: 2000)")
    fleet_p.add_argument("--departments", nargs="+", default=None,
        help="Departments to include (default: all 10)")
    fleet_p.add_argument("--rate", type=float, default=10.0,
        metavar="EPS",
        help="Evaluations per second across the fleet (default: 10)")
    fleet_p.add_argument("--duration", type=int, default=0,
        metavar="SECONDS",
        help="Run for N seconds then stop (0 = run until Ctrl+C)")
    fleet_p.add_argument("--scenario", default="AcmeCo Q2 Launch",
        help="Scenario label shown in dashboard and reports")
    fleet_p.add_argument("--watch", action="store_true",
        help="Print live stats table to terminal while running")
    fleet_p.add_argument("--watch-interval", type=int, default=5,
        metavar="SECONDS",
        help="Stats refresh interval when --watch is enabled (default: 5)")
    fleet_p.add_argument("--serve-dashboard", action="store_true",
        help="Start dashboard server at localhost:8080/ui after provisioning")

    # simulate stop
    sim_sub.add_parser("stop", help="Stop running simulation and clean up")

    # simulate status
    sim_sub.add_parser("status", help="Show current simulation status")

    # simulate report
    report_p = sim_sub.add_parser("report",
        help="Print final stats report from last simulation")
    report_p.add_argument("--format", choices=["table", "json"], default="table")

    # ── testlog ─────────────────────────────────────────────────────
    testlog_parser = sub.add_parser("testlog", help="View test evaluation history")
    testlog_parser.add_argument("identifier", nargs="?", default=None,
                                help="Agent name, ID, or certificate ID")
    testlog_parser.add_argument("--summary", action="store_true", help="Show summary")
    testlog_parser.add_argument("--verify", action="store_true", help="Verify hash chain")
    testlog_parser.add_argument("--limit", type=int, default=20, help="Max records")
    testlog_parser.add_argument("--clear", action="store_true",
                                help="Clear test history and reset simulated trust")

    # ── tutorial ───────────────────────────────────────────────────
    sub.add_parser("tutorial", help="Interactive walkthrough of the complete governance lifecycle")

    # ── serve ────────────────────────────────────────────────────────
    serve = sub.add_parser("serve", help="Start the Nomotic API server")
    serve.add_argument("--host", default="0.0.0.0", help="Bind host (default: 0.0.0.0)")
    serve.add_argument("--port", type=int, default=8420, help="Bind port (default: 8420)")
    serve.add_argument(
        "--metrics",
        action="store_true",
        default=False,
        help="Enable Prometheus /metrics endpoint",
    )
    serve.add_argument(
        "--ui",
        action="store_true",
        default=False,
        help="Enable governance dashboard at /ui",
    )
    serve.add_argument(
        "--poll-interval",
        type=int,
        default=15,
        metavar="SECONDS",
        help="Dashboard polling interval (default: 15)",
    )
    serve.add_argument(
        "--api-key",
        default=None,
        help="API key required for non-localhost dashboard access",
    )
    serve.add_argument(
        "--playground",
        action="store_true",
        default=False,
        help="Enable governance playground at /ui/playground",
    )
    serve.add_argument(
        "--sim-mode",
        action="store_true",
        default=False,
        help="Point dashboard at running fleet simulation instead of production data",
    )

    # ── mcp-proxy ──────────────────────────────────────────────────────
    mcp_parser = sub.add_parser("mcp-proxy", help="Run MCP governance proxy")
    mcp_parser.add_argument("--agent-id", required=True, help="Nomotic agent identity")
    mcp_parser.add_argument("--upstream", default=None, help="Upstream MCP server command (stdio mode)")
    mcp_parser.add_argument("--upstream-url", default=None, help="Upstream MCP server URL (HTTP mode)")
    mcp_parser.add_argument("--port", type=int, default=8421, help="Proxy listen port (HTTP mode)")
    mcp_parser.add_argument("--host", default="127.0.0.1", help="Proxy listen host (HTTP mode)")
    mcp_parser.add_argument("--test-mode", action="store_true", help="Use testlog and simulated trust")
    mcp_parser.add_argument("--log-level", default="info", choices=["debug", "info", "quiet"],
                            help="Logging verbosity (default: info)")
    mcp_parser.add_argument(
        "--require-certificate", action="store_true",
        help="Require valid birth certificate for all requests. "
             "Only enforced for traffic routed through this proxy.",
    )
    mcp_parser.add_argument(
        "--agent-map",
        help="Path to agent ID mapping JSON file (IP/key → agent_id)",
    )
    mcp_parser.add_argument(
        "--timeout", type=float, default=30.0,
        help="Default upstream timeout in seconds",
    )
    mcp_parser.add_argument(
        "--log-format", choices=["json", "text"], default="json",
        help="Log format",
    )

    # ── proxy ────────────────────────────────────────────────────────
    proxy_parser = sub.add_parser("proxy", help="Run governance proxy for HTTP traffic")
    proxy_parser.add_argument("--agent-id", required=True, help="Agent identity for governance")
    proxy_parser.add_argument("--listen", default="0.0.0.0:8421", help="Proxy listen address (default: 0.0.0.0:8421)")
    proxy_parser.add_argument("--upstream", required=True, help="Upstream service URL")
    proxy_parser.add_argument("--test-mode", action="store_true", help="Use testlog and simulated trust")
    proxy_parser.add_argument(
        "--require-certificate", action="store_true",
        help="Require valid birth certificate for all requests. "
             "Only enforced for traffic routed through this proxy.",
    )
    proxy_parser.add_argument(
        "--agent-map",
        help="Path to agent ID mapping JSON file (IP/key → agent_id)",
    )
    proxy_parser.add_argument(
        "--timeout", type=float, default=30.0,
        help="Default upstream timeout in seconds",
    )
    proxy_parser.add_argument(
        "--log-format", choices=["json", "text"], default="json",
        help="Log format",
    )

    # ── hello ────────────────────────────────────────────────────────
    sub.add_parser("hello", help="Start the Nomotic tutorial (same as 'nomotic tutorial')")

    # ── history ─────────────────────────────────────────────────────
    history = sub.add_parser("history", help="Full historical record for an agent (including revoked)")
    history.add_argument("identifier", help="Agent ID, name, or certificate ID")

    # ── fingerprint ─────────────────────────────────────────────────
    fp_parser = sub.add_parser("fingerprint", help="Show behavioral fingerprint for an agent")
    fp_parser.add_argument("agent_id", help="Agent identifier")
    fp_parser.add_argument("--host", default="127.0.0.1", help="API server host (default: 127.0.0.1)")
    fp_parser.add_argument("--port", type=int, default=8420, help="API server port (default: 8420)")

    # ── drift ────────────────────────────────────────────────────
    drift_parser = sub.add_parser("drift", help="Show behavioral drift or explain drift causes")
    drift_sub = drift_parser.add_subparsers(dest="drift_command")

    # drift <agent_id> (show drift — default behavior)
    drift_show = drift_sub.add_parser("show", help="Show behavioral drift for an agent")
    drift_show.add_argument("agent_id", help="Agent identifier")
    drift_show.add_argument("--host", default="127.0.0.1", help="API server host (default: 127.0.0.1)")
    drift_show.add_argument("--port", type=int, default=8420, help="API server port (default: 8420)")

    # drift explain --agent=<id> or --alert=<id>
    drift_explain = drift_sub.add_parser("explain", help="Explain why drift happened (causal analysis)")
    drift_explain.add_argument("--agent", dest="explain_agent", default=None, help="Agent identifier")
    drift_explain.add_argument("--alert", dest="explain_alert", default=None, help="Fleet drift alert ID")
    drift_explain.add_argument("--host", default="127.0.0.1", help="API server host (default: 127.0.0.1)")
    drift_explain.add_argument("--port", type=int, default=8420, help="API server port (default: 8420)")

    # Backward compatibility: drift <agent_id> still works
    drift_parser.add_argument("agent_id", nargs="?", default=None, help="Agent identifier (shortcut for 'drift show <agent_id>')")
    drift_parser.add_argument("--host", default="127.0.0.1", help="API server host (default: 127.0.0.1)")
    drift_parser.add_argument("--port", type=int, default=8420, help="API server port (default: 8420)")

    # ── trajectory ──────────────────────────────────────────────
    traj_parser = sub.add_parser("trajectory", help="Behavioral trajectory projections and interventions")
    traj_sub = traj_parser.add_subparsers(dest="trajectory_command")

    traj_show = traj_sub.add_parser("show", help="Show trajectory projection for an agent")
    traj_show.add_argument("--agent", required=True, dest="agent_id", help="Agent identifier")
    traj_show.add_argument("--host", default="127.0.0.1", help="API server host (default: 127.0.0.1)")
    traj_show.add_argument("--port", type=int, default=8420, help="API server port (default: 8420)")

    traj_interventions = traj_sub.add_parser("interventions", help="Show trajectory interventions")
    traj_interventions.add_argument("--agent", dest="agent_id", default=None, help="Filter by agent ID")
    traj_interventions.add_argument("--host", default="127.0.0.1", help="API server host (default: 127.0.0.1)")
    traj_interventions.add_argument("--port", type=int, default=8420, help="API server port (default: 8420)")

    # ── trust ────────────────────────────────────────────────────
    trust_parser = sub.add_parser("trust", help="Show trust report for an agent")
    trust_parser.add_argument("agent_id", help="Agent identifier")
    trust_parser.add_argument("--host", default="127.0.0.1", help="API server host (default: 127.0.0.1)")
    trust_parser.add_argument("--port", type=int, default=8420, help="API server port (default: 8420)")

    # ── alerts ───────────────────────────────────────────────────
    alerts_parser = sub.add_parser("alerts", help="List drift alerts")
    alerts_parser.add_argument("--agent-id", default=None, help="Filter by agent ID")
    alerts_parser.add_argument("--unacknowledged", action="store_true", help="Show only unacknowledged alerts")
    alerts_parser.add_argument("--host", default="127.0.0.1", help="API server host (default: 127.0.0.1)")
    alerts_parser.add_argument("--port", type=int, default=8420, help="API server port (default: 8420)")

    # ── audit ────────────────────────────────────────────────────
    audit_parser = sub.add_parser("audit", help="View audit trail and verify integrity")
    audit_parser.add_argument("identifier", nargs="?", default=None,
                              help="Agent name, ID, or certificate ID")
    audit_parser.add_argument("--summary", action="store_true", help="Show summary instead of records")
    audit_parser.add_argument("--verify", action="store_true", help="Verify hash chain integrity")
    audit_parser.add_argument("--all", action="store_true", dest="show_all", help="Show all agents (no filter)")
    audit_parser.add_argument("--limit", type=int, default=20, help="Max records to show")
    audit_parser.add_argument("--severity", default=None, help="Filter by severity")
    audit_parser.add_argument("--delegations", action="store_true", help="Show delegation history")
    audit_parser.add_argument("--outputs", action="store_true", help="Show output governance evaluations")
    audit_parser.add_argument("--workflow", default=None, help="Show workflow seal chain for a workflow ID")
    audit_parser.add_argument("--verify-chain", default=None, dest="verify_chain",
                              help="Verify a workflow seal chain by chain ID")
    audit_parser.add_argument(
        "--push-agicomply",
        action="store_true",
        help="Push audit records to AGICOMPLY (requires AGICOMPLY_API_URL, "
             "AGICOMPLY_API_TOKEN, AGICOMPLY_SYSTEM_ID env vars)"
    )
    audit_parser.add_argument(
        "--agicomply-endpoint",
        default="/api/runtime-governance/ingest",
        help="AGICOMPLY ingestion endpoint (default: /api/runtime-governance/ingest)"
    )
    audit_parser.add_argument(
        "--pre-execution",
        action="store_true",
        help="Show pre-execution records for agent (last 20)"
    )
    audit_parser.add_argument(
        "--unsettled",
        action="store_true",
        help="Show only unsettled pre-execution records"
    )
    audit_parser.add_argument(
        "--verify-pre-execution",
        action="store_true",
        dest="verify_pre_execution",
        help="Verify pre-execution chain integrity"
    )

    # ── fleet ───────────────────────────────────────────────────
    fleet_parser = sub.add_parser("fleet", help="Fleet governance overview")
    fleet_sub = fleet_parser.add_subparsers(dest="fleet_command")
    fleet_sub.add_parser("health", help="Show fleet health summary")
    fleet_sub.add_parser("status", help="Show fleet health summary (alias for health)")
    fleet_sub.add_parser("critical", help="List critical agents")
    fleet_denials = fleet_sub.add_parser("denials", help="Top denied action types")
    fleet_denials.add_argument("--limit", type=int, default=10, help="Max action types to show")
    fleet_sub.add_parser("agents", help="List all agents with fleet status")

    # Fleet behavioral monitor subcommands
    fleet_drift_health = fleet_sub.add_parser("drift-health", help="Show fleet behavioral drift health")
    fleet_drift_health.add_argument("--host", default="127.0.0.1", help="API server host")
    fleet_drift_health.add_argument("--port", type=int, default=8420, help="API server port")

    fleet_drift_alerts = fleet_sub.add_parser("drift-alerts", help="Show fleet drift alerts")
    fleet_drift_alerts.add_argument("--scope", choices=["fleet", "correlated", "coordinated"],
                                     default=None, help="Filter alerts by scope")
    fleet_drift_alerts.add_argument("--host", default="127.0.0.1", help="API server host")
    fleet_drift_alerts.add_argument("--port", type=int, default=8420, help="API server port")

    fleet_interaction = fleet_sub.add_parser("interaction", help="Register agent interaction edge")
    fleet_interaction.add_argument("--source", required=True, help="Source agent ID")
    fleet_interaction.add_argument("--target", required=True, help="Target agent ID")
    fleet_interaction.add_argument("--host", default="127.0.0.1", help="API server host")
    fleet_interaction.add_argument("--port", type=int, default=8420, help="API server port")

    # ── provenance ──────────────────────────────────────────────
    prov_parser = sub.add_parser("provenance", help="Show configuration provenance")
    prov_parser.add_argument("--target-type", default=None, help="Filter by target type")
    prov_parser.add_argument("--target-id", default=None, help="Filter by target ID")
    prov_parser.add_argument("--host", default="127.0.0.1", help="API server host")
    prov_parser.add_argument("--port", type=int, default=8420, help="API server port")

    # ── owner ───────────────────────────────────────────────────
    owner_parser = sub.add_parser("owner", help="Show owner activity")
    owner_parser.add_argument("owner_id", help="Owner identifier")
    owner_parser.add_argument("--engagement", action="store_true", help="Show engagement score")
    owner_parser.add_argument("--host", default="127.0.0.1", help="API server host")
    owner_parser.add_argument("--port", type=int, default=8420, help="API server port")

    # ── oversight (human drift) ─────────────────────────────────
    oversight_parser = sub.add_parser("oversight", help="Human oversight engagement analysis")
    oversight_parser.add_argument("reviewer_id", nargs="?", default=None, help="Reviewer identifier")
    oversight_parser.add_argument("--drift", action="store_true", help="Show drift analysis")
    oversight_parser.add_argument("--alerts", action="store_true", help="Show all human drift alerts")
    oversight_parser.add_argument("--team", action="store_true", help="Show team-level oversight health")

    # ── siem-export ──────────────────────────────────────────────
    siem_parser = sub.add_parser("siem-export", help="Export audit trail in SIEM formats (CEF, syslog, JSONL)")
    siem_parser.add_argument("identifier", nargs="?", default=None,
                             help="Agent name, ID, or certificate ID")
    siem_parser.add_argument("--format", dest="siem_format", default="jsonl",
                             choices=["cef", "syslog", "jsonl"],
                             help="Output format (default: jsonl)")
    siem_parser.add_argument("--since", default=None,
                             help="Start date (ISO 8601, e.g. 2026-02-01)")
    siem_parser.add_argument("--until", default=None,
                             help="End date (ISO 8601, e.g. 2026-02-28)")
    siem_parser.add_argument("--severity", default=None,
                             help="Filter by severity (info, warning, alert, critical)")
    siem_parser.add_argument("--verdict", default=None,
                             help="Filter by verdict (ALLOW, DENY, etc.)")
    siem_parser.add_argument("--all", action="store_true", dest="siem_all",
                             help="Export all agents")
    siem_parser.add_argument("--output", default=None,
                             help="Output file path (default: stdout)")
    siem_parser.add_argument("--include-dimensions", action="store_true",
                             help="Include per-dimension scores")

    # ── evidence ──────────────────────────────────────────────────
    evidence_parser = sub.add_parser(
        "evidence",
        help="Generate, verify, and summarize compliance evidence bundles",
    )
    evidence_sub = evidence_parser.add_subparsers(dest="evidence_command")

    ev_gen = evidence_sub.add_parser("generate", help="Generate a compliance evidence bundle")
    ev_gen.add_argument("identifier", nargs="?", default=None,
                        help="Agent name, ID, or certificate ID (omit for all agents)")
    ev_gen.add_argument("--frameworks", default=None,
                        help="Comma-separated frameworks: SOC2,HIPAA,PCI-DSS,ISO27001")
    ev_gen.add_argument("--since", default=None,
                        help="Start date (ISO 8601, e.g. 2026-01-01)")
    ev_gen.add_argument("--until", default=None,
                        help="End date (ISO 8601, e.g. 2026-02-28)")
    ev_gen.add_argument("--output", default=None,
                        help="Output file path (default: stdout)")
    ev_gen.add_argument("--created-by", default="nomotic-cli",
                        help="Identity of who is generating this bundle")

    ev_verify = evidence_sub.add_parser("verify", help="Verify a bundle file's integrity")
    ev_verify.add_argument("bundle_file", help="Path to evidence bundle JSON file")

    ev_summary = evidence_sub.add_parser("summary", help="Show a summary of a bundle file")
    ev_summary.add_argument("bundle_file", help="Path to evidence bundle JSON file")

    # ── validate ──────────────────────────────────────────────────
    validate = sub.add_parser(
        "validate",
        help="Validate a nomotic.yaml governance config file",
    )
    validate.add_argument(
        "path", nargs="?", default=".",
        help="Path to nomotic.yaml or directory (default: .)",
    )
    validate.add_argument(
        "--strict", action="store_true", default=False,
        help="Treat warnings as errors (exit 1 on any warning)",
    )
    validate.add_argument(
        "--preset", default=None,
        help="Apply a preset for validation (canonical name, e.g. hipaa_aligned)",
    )
    validate.add_argument(
        "--org", default=None,
        help="Path to org config (otherwise auto-discovers via load_org_config)",
    )
    validate.add_argument(
        "--json", action="store_true", default=False,
        help="Output results as JSON instead of formatted text",
    )
    validate.add_argument(
        "--quiet", action="store_true", default=False,
        help="Only output errors",
    )

    # ── cost ──────────────────────────────────────────────────────
    cost_parser = sub.add_parser("cost", help="Agent and fleet cost tracking")
    cost_parser.add_argument("agent_id", nargs="?", default=None,
                             help="Agent to show costs for (legacy positional)")
    cost_parser.add_argument("--agent", default=None, dest="cost_agent",
                             help="Agent ID for fleet cost breakdown")
    cost_parser.add_argument("--group", default=None, dest="cost_group",
                             help="Group ID for group cost summary")
    cost_parser.add_argument("--all", action="store_true", dest="cost_all",
                             help="Show fleet-wide cost summary")
    cost_parser.add_argument("--configure", action="store_true",
                             help="Configure cost settings")
    cost_parser.add_argument("--json", action="store_true", dest="cost_json",
                             help="JSON output")

    # ── contract subcommands ──────────────────────────────────────
    contract_parser = sub.add_parser("contract", help="Manage behavioral contracts")
    contract_sub = contract_parser.add_subparsers(dest="contract_command")

    contract_gen = contract_sub.add_parser("generate", help="Generate a behavioral contract")
    contract_gen.add_argument("--agent", required=True, help="Agent ID")
    contract_gen.add_argument("--archetype", default="general", help="Behavioral archetype")

    contract_show = contract_sub.add_parser("show", help="Show active contract")
    contract_show.add_argument("--agent", required=True, help="Agent ID")

    contract_val = contract_sub.add_parser("validate", help="Validate contract seal")
    contract_val.add_argument("--agent", required=True, help="Agent ID")

    contract_diff = contract_sub.add_parser("diff", help="Diff two contract versions")
    contract_diff.add_argument("--agent", required=True, help="Agent ID")
    contract_diff.add_argument("--v1", type=int, required=True, help="First version")
    contract_diff.add_argument("--v2", type=int, required=True, help="Second version")

    # ── ledger (behavior ledger — decision reconstruction) ─────────
    ledger_parser = sub.add_parser("ledger", help="BehaviorLedger — complete decision reconstruction")
    ledger_sub = ledger_parser.add_subparsers(dest="ledger_command")

    ledger_show = ledger_sub.add_parser("show", help="Show a ledger entry")
    ledger_show.add_argument("--agent", required=True, help="Agent ID")
    ledger_show.add_argument("--sequence", type=int, default=None, help="Sequence number (default: latest)")
    ledger_show.add_argument("--json", action="store_true", dest="ledger_json", help="JSON output")

    ledger_trace = ledger_sub.add_parser("trace", help="Walk causal chain backward from an entry")
    ledger_trace.add_argument("--agent", required=True, help="Agent ID")
    ledger_trace.add_argument("--sequence", type=int, required=True, help="Sequence number")
    ledger_trace.add_argument("--depth", type=int, default=10, help="Max depth of causal chain walk")

    ledger_narrative = ledger_sub.add_parser("narrative", help="Print multi-paragraph narrative reconstruction")
    ledger_narrative.add_argument("--agent", required=True, help="Agent ID")
    ledger_narrative.add_argument("--sequence", type=int, default=None, help="Sequence number (default: latest)")

    ledger_verify = ledger_sub.add_parser("verify", help="Verify hash chain integrity")
    ledger_verify.add_argument("--agent", required=True, help="Agent ID")

    ledger_query = ledger_sub.add_parser("query", help="Query ledger entries with filters")
    ledger_query.add_argument("--agent", default=None, help="Agent ID (optional)")
    ledger_query.add_argument("--verdict", default=None, help="Filter by verdict (ALLOW, DENY, ESCALATE)")
    ledger_query.add_argument("--limit", type=int, default=10, help="Max entries to return")
    ledger_query.add_argument("--json", action="store_true", dest="ledger_json", help="JSON output")

    ledger_export = ledger_sub.add_parser("export", help="Export ledger entries in compliance-friendly formats")
    ledger_export.add_argument("--agent", required=True, help="Agent ID")
    ledger_export.add_argument("--format", dest="export_format", default="json",
                               choices=["json", "jsonl", "narrative", "csv"],
                               help="Export format (default: json)")
    ledger_export.add_argument("--output", required=True, help="Output file path")
    ledger_export.add_argument("--since", default=None, help="Start time (ISO format)")
    ledger_export.add_argument("--until", default=None, help="End time (ISO format)")
    ledger_export.add_argument("--verdict", default=None, dest="export_verdict",
                               help="Filter by verdict (ALLOW, DENY, ESCALATE)")
    ledger_export.add_argument("--limit", type=int, default=10000, dest="export_limit",
                               help="Max entries to export (default: 10000)")

    # ── replay (counterfactual behavioral replay) ──────────────────
    replay_parser = sub.add_parser("replay", help="Counterfactual behavioral replay — what would have happened if?")
    replay_parser.add_argument("--agent", required=True, help="Agent ID to replay")
    replay_parser.add_argument("--config", default=None, help="Path to replay config JSON file")
    replay_parser.add_argument("--allow-threshold", type=float, default=None, help="Override allow threshold")
    replay_parser.add_argument("--deny-threshold", type=float, default=None, help="Override deny threshold")
    replay_parser.add_argument("--trust-influence", type=float, default=None, help="Override trust influence")
    replay_parser.add_argument("--start-time", type=float, default=None, help="Replay from this Unix timestamp")
    replay_parser.add_argument("--end-time", type=float, default=None, help="Replay until this Unix timestamp")
    replay_parser.add_argument("--max-actions", type=int, default=10000, help="Maximum actions to replay")
    replay_parser.add_argument("--description", default="", help="Human description of this replay")
    replay_parser.add_argument("--json", action="store_true", dest="replay_json", help="JSON output")

    # ── status (global settings/status) ──────────────────────────
    status = sub.add_parser("status", help="Show global governance settings and presets")
    status.add_argument(
        "--org", action="store_true", default=False, dest="org_only",
        help="Show only org-level governance settings",
    )
    status.add_argument(
        "--presets", action="store_true", default=False, dest="presets_list",
        help="List all available presets",
    )
    status.add_argument(
        "--preset", default=None, dest="preset_detail",
        help="Show full details of a specific preset (canonical name)",
    )
    status.add_argument(
        "--policies", action="store_true", default=False, dest="policies_list",
        help="List active governance policies (policy-as-code)",
    )

    # ── compliance-report ─────────────────────────────────────────
    compliance_parser = sub.add_parser(
        "compliance-report", help="Generate compliance mapping report",
    )
    compliance_parser.add_argument(
        "--framework", default=None,
        help="Framework ID, custom framework ID, or path to a custom framework JSON file",
    )
    compliance_parser.add_argument(
        "--agent", default=None,
        help="Include agent-specific evidence",
    )
    compliance_parser.add_argument(
        "--include-layer-map", action="store_true", default=False,
        help="Include governance stack coverage",
    )
    compliance_parser.add_argument(
        "--output", default=None,
        help="Output file (extension determines format: .json or .md)",
    )
    compliance_parser.add_argument(
        "--list-frameworks", action="store_true", default=False,
        help="List all available frameworks (built-in and custom)",
    )

    # ── compliance-gaps ──────────────────────────────────────────
    gaps_parser = sub.add_parser(
        "compliance-gaps", help="Analyze compliance gaps from audit data",
    )
    gaps_parser.add_argument(
        "framework", nargs="?", default=None,
        help="Framework ID (e.g. gdpr, hipaa, soc2)",
    )
    gaps_parser.add_argument(
        "--agent", default=None,
        help="Filter to a specific agent (default: fleet-wide)",
    )
    gaps_parser.add_argument(
        "--days", type=int, default=30,
        help="Number of days of audit history to analyze (default: 30)",
    )
    gaps_parser.add_argument(
        "--threshold", type=float, default=0.7,
        help="Score threshold below which a control is a gap (default: 0.7)",
    )
    gaps_parser.add_argument(
        "--severity", default=None,
        choices=["critical", "high", "medium", "low"],
        help="Show only gaps of this severity",
    )

    # ── doctor ─────────────────────────────────────────────────────
    p_doctor = sub.add_parser("doctor", help="Check governance infrastructure health")
    p_doctor.add_argument("--quiet", action="store_true", help="Only show errors and warnings")
    p_doctor.add_argument("--json", action="store_true", dest="doctor_json", help="Machine-readable JSON output")
    p_doctor.add_argument(
        "--fix",
        action="store_true",
        help="Attempt to auto-fix simple issues (interactive)",
    )

    # ── diagnose ───────────────────────────────────────────────────
    p_diagnose = sub.add_parser(
        "diagnose",
        help="Diagnose a Nomotic error — explains behavioral and governance errors with fix suggestions",
    )
    p_diagnose.add_argument(
        "error_code",
        help="Error class name or partial name (e.g. 'ConstitutionalViolationError' or 'constitutional')",
    )
    p_diagnose.add_argument(
        "--no-doctor",
        action="store_true",
        default=False,
        help="Skip automatic nomotic doctor check after explaining the error",
    )

    # ── policy-validate ──────────────────────────────────────────
    policy_validate = sub.add_parser(
        "policy-validate", help="Validate policy files and configuration",
    )
    policy_validate.add_argument(
        "--dir", default=None, dest="policy_dir",
        help="Directory to load policies from (default: ./nomotic-policies/ and ~/.nomotic/policies/)",
    )
    policy_validate.add_argument(
        "--json", action="store_true", dest="policy_json",
        help="Output results as JSON",
    )
    policy_validate.add_argument(
        "--dry-run", action="store_true", dest="dry_run",
        help="Test policy against historical audit records without live execution",
    )
    policy_validate.add_argument(
        "--agent", default=None,
        help="Agent ID to test against (default: all agents)",
    )
    policy_validate.add_argument(
        "--days", type=int, default=7,
        help="Number of days of audit history to test against",
    )
    policy_validate.add_argument(
        "--override-sim", default=None, dest="override_sim",
        help=(
            "Simulate an override during dry-run. "
            "Format: key=value,key=value,... "
            "Keys: authority (required), action_types (comma-sep), "
            "target_agents (comma-sep), override_type (ALLOW_ANYWAY|ESCALATE_INSTEAD)"
        ),
    )

    # ── override ──────────────────────────────────────────────────
    override = sub.add_parser("override", help="Override a governance decision")
    override.add_argument("action_id", help="Action ID to override, or 'cosign'/'pending' subcommand")
    override.add_argument(
        "extra_id", nargs="?", default=None,
        help="Pending override ID (for cosign/pending subcommands)",
    )
    override.add_argument("--approve", action="store_true", help="Approve a previously denied action")
    override.add_argument("--revoke", action="store_true", help="Revoke a previously allowed action")
    override.add_argument("--authority", default=None, help="Identity of the person overriding (email or ID)")
    override.add_argument("--reason", default=None, help="Reason for the override")
    override.add_argument("--agent", default=None, help="Agent ID (required if action_id is ambiguous)")
    override.add_argument("--trust-penalty", type=float, default=0.10, help="Trust penalty for REVOKE (default: 0.10)")

    # ── roles ────────────────────────────────────────────────────
    roles_parser = sub.add_parser("roles", help="Manage governance override roles")
    roles_sub = roles_parser.add_subparsers(dest="roles_command")
    roles_sub.add_parser("list", help="List all configured roles")
    show_p = roles_sub.add_parser("show", help="Show full detail of a single role")
    show_p.add_argument("role_id", help="Role ID to show")
    check_p = roles_sub.add_parser("check", help="Check if authority can override an action")
    check_p.add_argument("authority", help="Authority identity (email or ID)")
    check_p.add_argument("action_id", help="Action ID to check against")

    # ── webhooks ─────────────────────────────────────────────────
    webhooks_parser = sub.add_parser("webhooks", help="Webhook management")
    webhooks_sub = webhooks_parser.add_subparsers(dest="webhooks_command")
    test_wh = webhooks_sub.add_parser("test", help="Send a test ping to a webhook URL")
    test_wh.add_argument("url", help="Webhook endpoint URL")
    test_wh.add_argument("--secret", default=None, help="HMAC signing secret")
    webhooks_sub.add_parser("status", help="Show webhook delivery queue status")
    webhooks_sub.add_parser("drain", help="Retry delivery of queued webhook events")

    # ── constitution ────────────────────────────────────────────────
    const_parser = sub.add_parser("constitution", help="Manage constitutional rules")
    const_sub = const_parser.add_subparsers(dest="constitution_command")
    const_sub.add_parser("list", help="List active constitutional rules")
    const_show = const_sub.add_parser("show", help="Show full detail of a single rule")
    const_show.add_argument("rule_id", help="Constitutional rule ID (nmcr-...)")
    const_verify = const_sub.add_parser("verify", help="Verify signature of a constitutional ruleset file")
    const_verify.add_argument("path", help="Path to constitutional ruleset JSON file")
    const_dryrun = const_sub.add_parser("dry-run", help="Simulate a constitutional ruleset against audit history")
    const_dryrun.add_argument("ruleset", help="Path to constitutional ruleset JSON file")
    const_dryrun.add_argument("--agent", default=None, help="Restrict to a single agent ID")
    const_dryrun.add_argument("--days", type=int, default=7, help="Days of audit history (default: 7)")
    const_dryrun.add_argument("--max-records", type=int, default=500, help="Maximum records to evaluate (default: 500)")

    # ── authority-registry ──────────────────────────────────────────
    ar_parser = sub.add_parser("authority-registry", help="Manage governance authority registry")
    ar_sub = ar_parser.add_subparsers(dest="authority_registry_command")
    ar_sub.add_parser("list", help="List all registered governance authorities")
    ar_show = ar_sub.add_parser("show", help="Show authority detail")
    ar_show.add_argument("authority_id", help="Authority ID (nma-...)")
    ar_bootstrap = ar_sub.add_parser("bootstrap", help="Initialize the first RUNTIME_ADMINISTRATOR authority")
    ar_bootstrap.add_argument("--name", required=True, help="Name for the bootstrap authority")
    ar_history = ar_sub.add_parser("history", help="Show governance change history")
    ar_history.add_argument("--authority", default=None, help="Filter by authority ID")
    ar_history.add_argument("--limit", type=int, default=20, help="Max records to show (default: 20)")

    # ── continuity ──────────────────────────────────────────────────
    cont_parser = sub.add_parser("continuity", help="Manage pre-evaluation state continuity checks")
    cont_sub = cont_parser.add_subparsers(dest="continuity_command")
    cont_status = cont_sub.add_parser("status", help="Show current continuity snapshot for an agent")
    cont_status.add_argument("agent_id", help="Agent ID, name, or certificate ID")
    cont_reset = cont_sub.add_parser("reset", help="Force-reset continuity snapshot for an agent")
    cont_reset.add_argument("agent_id", help="Agent ID, name, or certificate ID")
    cont_reset.add_argument("--reason", required=True, help="Reason for resetting the snapshot")
    cont_verify = cont_sub.add_parser(
        "verify",
        help="Run full audit chain verification (alias for: nomotic audit <agent> --verify)",
    )
    cont_verify.add_argument("agent_id", help="Agent ID, name, or certificate ID")

    # budget (Pre-Execution Budget Gate — Item 17)
    budget_parser = sub.add_parser("budget", help="Pre-execution budget gate status")
    budget_sub = budget_parser.add_subparsers(dest="budget_command")
    budget_status = budget_sub.add_parser("status", help="Show budget status for a group")
    budget_status.add_argument("group_id", help="Cost group ID")
    budget_reservations = budget_sub.add_parser("reservations", help="List active budget reservations")
    budget_reservations.add_argument("--group", default=None, help="Filter by group ID")

    # ── delegation ──────────────────────────────────────────────────
    delegation_parser = sub.add_parser("delegation", help="Visualize and inspect delegation chains")
    delegation_sub = delegation_parser.add_subparsers(dest="delegation_command")

    deleg_viz = delegation_sub.add_parser("visualize", help="Render a delegation chain as ASCII or DOT")
    deleg_viz.add_argument("agent_id", help="Root agent ID for the delegation chain")
    deleg_viz.add_argument("--format", choices=["ascii", "dot"], default="ascii", help="Output format (default: ascii)")
    deleg_viz.add_argument("--output", default=None, help="Write output to file instead of stdout")
    deleg_viz.add_argument(
        "--depth-limits", action="store_true", default=False,
        help="Include depth limit legend (ASCII only)",
    )

    deleg_viol = delegation_sub.add_parser("violations", help="Find delegation depth violations")
    deleg_viol.add_argument("agent_id", help="Root agent ID for the delegation chain")

    # ── uahs ────────────────────────────────────────────────────────
    uahs_parser = sub.add_parser("uahs", help="Manage Unified Agent Health Score (UAHS)")
    uahs_sub = uahs_parser.add_subparsers(dest="uahs_command")

    uahs_reset = uahs_sub.add_parser("reset", help="Reset UAHS data for an agent")
    uahs_reset.add_argument("agent_id", help="Agent ID to reset")
    uahs_reset.add_argument("--reason", default=None, help="Reason for reset (e.g. 'model version update to v2.1')")

    # ── lifecycle ───────────────────────────────────────────────────
    lifecycle_parser = sub.add_parser("lifecycle", help="Agent lifecycle hooks and events")
    lifecycle_sub = lifecycle_parser.add_subparsers(dest="lifecycle_command")

    lifecycle_sub.add_parser("hooks", help="List registered lifecycle hooks")

    lifecycle_events = lifecycle_sub.add_parser("events", help="Show lifecycle event history for an agent")
    lifecycle_events.add_argument("agent_id", help="Agent ID, name, or certificate ID")

    # ── workflow ────────────────────────────────────────────────────
    workflow_parser = sub.add_parser("workflow", help="Manage workflow seal chains and dependencies")
    workflow_sub = workflow_parser.add_subparsers(dest="workflow_command")

    deps_parser = workflow_sub.add_parser("dependencies", help="Manage cross-workflow dependency rules")
    deps_sub = deps_parser.add_subparsers(dest="deps_command")

    deps_sub.add_parser("list", help="List all registered dependency rules")

    deps_check = deps_sub.add_parser("check", help="Check dependencies for a workflow")
    deps_check.add_argument("workflow_id", help="Workflow ID to check dependencies for")

    # ── scorecard ──────────────────────────────────────────────────
    scorecard_parser = sub.add_parser(
        "scorecard",
        help="Generate an auditor-ready governance scorecard with behavioral metrics",
    )
    scorecard_parser.add_argument(
        "--agent", required=True,
        help="Agent ID to generate scorecard for",
    )
    scorecard_parser.add_argument(
        "--framework", default="soc2",
        choices=["soc2", "hipaa", "pci-dss", "iso27001"],
        help="Compliance framework to map against (default: soc2)",
    )
    scorecard_parser.add_argument(
        "--days", type=int, default=30,
        help="Lookback period in days (default: 30)",
    )
    scorecard_parser.add_argument(
        "--format", default="html",
        choices=["html", "json"],
        dest="output_format",
        help="Output format (default: html)",
    )
    scorecard_parser.add_argument(
        "--output", default=None,
        help="Output file path. Default: nomotic-scorecard-{agent}-{date}.html",
    )

    # ── taxonomy ──────────────────────────────────────────────────
    sub.add_parser(
        "taxonomy",
        help="Print the Nomotic Drift Taxonomy reference (distributions and scopes)",
    )

    # ── control (Behavioral Command & Control) ───────────────────
    control_parser = sub.add_parser("control", help="Issue behavioral directives to the agent fleet")
    control_sub = control_parser.add_subparsers(dest="control_command")

    ctrl_enforce = control_sub.add_parser("enforce", help="Enforce a temporary invariant on agents")
    ctrl_enforce.add_argument("--agent", action="append", dest="agents", help="Target agent ID (repeatable)")
    ctrl_enforce.add_argument("--archetype", default="", help="Target archetype")
    ctrl_enforce.add_argument("--team", default="", help="Target team")
    ctrl_enforce.add_argument("--invariant", required=True, help="Invariant spec as JSON string")
    ctrl_enforce.add_argument("--duration", type=float, default=None, help="Duration in seconds")
    ctrl_enforce.add_argument("--reason", default="", help="Reason for the directive")
    ctrl_enforce.add_argument("--issued-by", default="cli-operator", help="Operator identity")

    ctrl_quarantine = control_sub.add_parser("quarantine", help="Quarantine agents (force ESCALATE)")
    ctrl_quarantine.add_argument("--agent", action="append", dest="agents", help="Target agent ID (repeatable)")
    ctrl_quarantine.add_argument("--archetype", default="", help="Target archetype")
    ctrl_quarantine.add_argument("--team", default="", help="Target team")
    ctrl_quarantine.add_argument("--scope", default="", help="Target scope (e.g., team:support)")
    ctrl_quarantine.add_argument("--reason", default="", help="Reason for quarantine")
    ctrl_quarantine.add_argument("--duration", type=float, default=None, help="Duration in seconds")
    ctrl_quarantine.add_argument("--issued-by", default="cli-operator", help="Operator identity")

    ctrl_release = control_sub.add_parser("release", help="Release agents from quarantine")
    ctrl_release.add_argument("--agent", action="append", dest="agents", help="Target agent ID (repeatable)")
    ctrl_release.add_argument("--archetype", default="", help="Target archetype")
    ctrl_release.add_argument("--team", default="", help="Target team")
    ctrl_release.add_argument("--reason", default="", help="Reason for release")
    ctrl_release.add_argument("--issued-by", default="cli-operator", help="Operator identity")

    ctrl_tighten = control_sub.add_parser("tighten", help="Tighten drift thresholds for agents")
    ctrl_tighten.add_argument("--agent", action="append", dest="agents", help="Target agent ID (repeatable)")
    ctrl_tighten.add_argument("--archetype", default="", help="Target archetype")
    ctrl_tighten.add_argument("--team", default="", help="Target team")
    ctrl_tighten.add_argument("--factor", type=float, default=0.5, help="Tighten factor (< 1.0 = tighter)")
    ctrl_tighten.add_argument("--duration", type=float, default=None, help="Duration in seconds")
    ctrl_tighten.add_argument("--reason", default="", help="Reason for tightening")
    ctrl_tighten.add_argument("--issued-by", default="cli-operator", help="Operator identity")

    ctrl_relax = control_sub.add_parser("relax", help="Remove tightening from agents")
    ctrl_relax.add_argument("--agent", action="append", dest="agents", help="Target agent ID (repeatable)")
    ctrl_relax.add_argument("--archetype", default="", help="Target archetype")
    ctrl_relax.add_argument("--team", default="", help="Target team")
    ctrl_relax.add_argument("--reason", default="", help="Reason for relaxing")
    ctrl_relax.add_argument("--issued-by", default="cli-operator", help="Operator identity")

    ctrl_reanchor = control_sub.add_parser("re-anchor", help="Re-anchor semantic term across agents")
    ctrl_reanchor.add_argument("--agent", action="append", dest="agents", help="Target agent ID (repeatable)")
    ctrl_reanchor.add_argument("--archetype", default="", help="Target archetype")
    ctrl_reanchor.add_argument("--team", default="", help="Target team")
    ctrl_reanchor.add_argument("--term", required=True, help="Semantic term to re-anchor")
    ctrl_reanchor.add_argument("--reason", default="", help="Reason for re-anchoring")
    ctrl_reanchor.add_argument("--issued-by", default="cli-operator", help="Operator identity")

    ctrl_reminder = control_sub.add_parser("broadcast-reminder", help="Broadcast contract reminder to agents")
    ctrl_reminder.add_argument("--agent", action="append", dest="agents", help="Target agent ID (repeatable)")
    ctrl_reminder.add_argument("--archetype", default="", help="Target archetype")
    ctrl_reminder.add_argument("--team", default="", help="Target team")
    ctrl_reminder.add_argument("--drift-status", default="", help="Target drift status (drifting, critical)")
    ctrl_reminder.add_argument("--contract", default="", dest="contract_version", help="Contract version to reference")
    ctrl_reminder.add_argument("--reason", default="", help="Reason for reminder")
    ctrl_reminder.add_argument("--issued-by", default="cli-operator", help="Operator identity")

    control_sub.add_parser("list", help="List active control directives")

    return parser


def _cmd_uahs(args: argparse.Namespace) -> None:
    """Manage UAHS data."""
    cmd = getattr(args, "uahs_command", None)
    if cmd is None:
        print()
        print("  Usage: nomotic uahs <command>")
        print()
        print("  Commands:")
        print("    reset   Reset UAHS data for an agent")
        print()
        return

    if cmd == "reset":
        agent_id = args.agent_id
        reason = getattr(args, "reason", None)

        try:
            from nomotic.runtime import GovernanceRuntime

            rt = GovernanceRuntime(enable_uahs=True)
            rt.reset_uahs(agent_id)
        except ValueError as e:
            print()
            print(f"  Error: {e}")
            print("  Enable with: RuntimeConfig(enable_uahs=True)")
            print()
            return

        print()
        print(f"  UAHS data cleared for agent '{agent_id}'.")
        if reason:
            print(f"  Reason: {reason}")
        min_evals = rt._uahs_config.min_evaluations_before_alert
        print(f"  Accumulated history reset. A new baseline will establish after {min_evals} evaluations.")
        print()


def _cmd_authority_registry(args: argparse.Namespace) -> None:
    """Manage governance authority registry."""
    cmd = getattr(args, "authority_registry_command", None)
    if cmd is None:
        cmd = "list"

    base_dir = Path(args.base_dir) if hasattr(args, "base_dir") and args.base_dir else _DEFAULT_BASE

    registry_path = base_dir / "authority_registry.json"

    if cmd == "list":
        from nomotic.authority_registry import GovernanceAuthorityRegistry

        registry = GovernanceAuthorityRegistry()
        if registry_path.exists():
            registry.load_from_file(registry_path)
        authorities = registry.list_authorities()
        if not authorities:
            print()
            print("  No governance authorities registered.")
            print("  Run: nomotic authority-registry bootstrap --name <name>")
            print()
            return

        print()
        print(f"  {_bold('Governance Authorities')}  ({len(authorities)} registered)")
        print()
        for auth in authorities:
            roles_str = ", ".join(r.value for r in auth.roles)
            expired = " [EXPIRED]" if auth.is_expired() else ""
            print(f"    {_cyan(auth.authority_id)}  {auth.name}")
            print(f"      Roles: {roles_str}{_red(expired) if expired else ''}")
            print()

    elif cmd == "show":
        from nomotic.authority_registry import GovernanceAuthorityRegistry

        registry = GovernanceAuthorityRegistry()
        if registry_path.exists():
            registry.load_from_file(registry_path)
        authority = registry.get_authority(args.authority_id)
        if authority is None:
            print(_red(f"  Authority {args.authority_id} not found."))
            sys.exit(1)

        print()
        print(f"  {_bold(authority.name)}")
        print(f"  ID:         {authority.authority_id}")
        print(f"  Roles:      {', '.join(r.value for r in authority.roles)}")
        print(f"  Created by: {authority.created_by}")
        print(f"  Created at: {datetime.fromtimestamp(authority.created_at, tz=timezone.utc).isoformat()}")
        if authority.expires_at is not None:
            exp_str = datetime.fromtimestamp(authority.expires_at, tz=timezone.utc).isoformat()
            if authority.is_expired():
                exp_str += _red(" [EXPIRED]")
            print(f"  Expires at: {exp_str}")
        if authority.notes:
            print(f"  Notes:      {authority.notes}")
        print(f"  Hash:       {_dim(authority.authority_hash)}")

        # Count changes
        changes = registry.get_change_history(authority_id=authority.authority_id)
        print(f"  Changes:    {len(changes)}")
        print()

    elif cmd == "bootstrap":
        import uuid as _uuid
        from nomotic.authority_registry import GovernanceAuthorityRegistry

        registry = GovernanceAuthorityRegistry()
        if registry_path.exists():
            registry.load_from_file(registry_path)

        authority_id = f"nma-{_uuid.uuid4()}"
        try:
            authority = registry.bootstrap(authority_id, args.name)
        except RuntimeError as exc:
            print(_red(f"  Error: {exc}"))
            sys.exit(1)

        registry.save_to_file(registry_path)
        print()
        print(f"  {_green('Bootstrapped governance authority registry')}")
        print(f"  Authority ID: {_bold(authority.authority_id)}")
        print(f"  Name:         {authority.name}")
        print("  Role:         runtime_administrator")
        print()

    elif cmd == "history":
        from nomotic.authority_registry import GovernanceAuthorityRegistry

        registry = GovernanceAuthorityRegistry()
        if registry_path.exists():
            registry.load_from_file(registry_path)

        limit = args.limit
        authority_id = getattr(args, "authority", None)
        records = registry.get_change_history(authority_id=authority_id, limit=limit)

        if not records:
            print()
            print("  No governance change history found.")
            print()
            return

        print()
        print(f"  {_bold('Governance Change History')}  ({len(records)} records)")
        print()
        for rec in records:
            ts = datetime.fromtimestamp(rec.changed_at, tz=timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
            print(f"    {_dim(ts)}  {_cyan(rec.change_id[:20])}...")
            print(f"      Authority: {rec.authority_name} ({rec.authority_id})")
            print(f"      Action:    {rec.change_type} on {rec.target}")
            print(f"      Role:      {rec.role_used.value}")
            if rec.reason:
                print(f"      Reason:    {rec.reason}")
            print()


def _cmd_policy_validate(args: argparse.Namespace) -> None:
    """Validate policy files and configuration."""
    from nomotic.policy import PolicyEngine

    dirs = None
    if args.policy_dir:
        dirs = [Path(args.policy_dir)]

    engine = PolicyEngine(policy_dirs=dirs)
    policies = engine.list_policies()
    issues = engine.validate_all()

    if getattr(args, "policy_json", False):
        result = {
            "policies_loaded": len(policies),
            "policies": [p.to_dict() for p in policies],
            "issues": issues,
            "valid": len(issues) == 0,
        }
        print(json.dumps(result, indent=2))
        sys.exit(1 if issues else 0)

    print()
    print(_bold("Policy Validation"))
    print("\u2501" * 17)
    print()

    if not policies and not issues:
        print("  No policies loaded.")
        print()
        print("  Policy directories searched:")
        if dirs:
            for d in dirs:
                print(f"    {d}")
        else:
            print("    ./nomotic-policies/")
            print(f"    {Path.home() / '.nomotic' / 'policies'}/")
        print()
        print("  To create a policy, add a JSON or YAML file to one of these directories.")
        print()
        sys.exit(0)

    print(f"  Policies loaded: {len(policies)}")
    print()
    for p in policies:
        status_icon = _green("\u2713") if p.enabled else _yellow("\u25cb")
        print(f"    {status_icon} {_bold(p.name)} (priority={p.priority})")
        if p.description:
            print(f"      {p.description}")
        verdict = p.then.get("verdict", "?")
        print(f"      When: {p.when}")
        print(f"      Then: {verdict}")
    print()

    if issues:
        print(f"  {_red('Issues found:')}")
        for issue in issues:
            x_icon = _red("\u2717")
            pol = issue['policy']
            desc = issue['issue']
            print(f"    {x_icon} [{pol}] {desc}")
        print()
        sys.exit(1)
    else:
        ok_icon = _green("\u2713")
        print(f"  {ok_icon} All policies valid.")
        print()

    # ── Dry-run mode ──────────────────────────────────────────────
    if getattr(args, "dry_run", False):
        from nomotic.audit_store import LogStore
        from nomotic.policy import PolicyDryRunner, SimulatedOverride

        base_dir = getattr(args, "base_dir", _DEFAULT_BASE)
        audit_store = LogStore(Path(base_dir), "audit")
        agent = getattr(args, "agent", None)
        days = getattr(args, "days", 7)

        # Parse --override-sim if provided
        sim_overrides = None
        override_sim_raw = getattr(args, "override_sim", None)
        if override_sim_raw:
            parts = {}
            for token in override_sim_raw.split(","):
                if "=" in token:
                    k, v = token.split("=", 1)
                    k = k.strip()
                    v = v.strip()
                    if k in parts:
                        parts[k] = parts[k] + "," + v
                    else:
                        parts[k] = v
            if "authority" not in parts:
                print(_red("--override-sim requires 'authority' key"))
                sys.exit(1)
            target_agents = [a.strip() for a in parts.get("target_agents", "").split(",") if a.strip()]
            action_types = [a.strip() for a in parts.get("action_types", "").split(",") if a.strip()]
            override_type = parts.get("override_type", "ALLOW_ANYWAY")
            sim_overrides = [SimulatedOverride(
                authority=parts["authority"],
                target_agents=target_agents,
                action_types=action_types,
                override_type=override_type,
            )]

        policy_dir_path = dirs[0] if dirs else None
        if policy_dir_path:
            policy_label = str(policy_dir_path)
        else:
            policy_label = "loaded policies"

        runner = PolicyDryRunner(audit_store=audit_store)
        result = runner.run_with_engine(
            engine=engine, agent_id=agent, days=days,
            policy_label=policy_label,
            sim_overrides=sim_overrides,
        )

        print()
        print(_bold(f"Policy Dry-Run: {result.policy_file}"))
        agent_label = result.agent_id or "all agents"
        print(f"  Agent:   {agent_label}")
        print(f"  Data:    {result.days_of_data} days ({result.records_evaluated:,} records evaluated)")
        print()

        if result.records_evaluated == 0:
            if agent:
                print(f"  No audit records found for '{agent}' in last {days} days.")
            else:
                print(f"  No audit records found in last {days} days.")
            print()
            return

        print("  Results")
        print("  " + "\u2500" * 43)
        print(f"  Records evaluated:          {result.records_evaluated:,}")
        print(f"  Already denied:               {result.already_denied:,}")
        print(f"  Matched by this policy:        {result.matched_count:,}")
        print(f"  New denials (would add):       {result.new_denials:,}")
        print(f"  New escalations:               {result.new_escalations:,}")
        print()

        if result.new_denials == 0 and result.new_escalations == 0:
            print("  Policy would not change any historical decisions. Safe to deploy.")
            print()
            if not result.override_sim_active:
                return

        if result.would_deny:
            limit = min(10, len(result.would_deny))
            print(f"  New Denials (first {limit} shown)")
            print("  " + "\u2500" * 43)
            for entry in result.would_deny[:limit]:
                rid = entry["record_id"]
                atype = entry["action_type"]
                pname = entry.get("policy_name", "")
                preason = entry.get("policy_reason", "")
                print(f"  {rid}  {atype}")
                print(f"    Policy: {pname}  \"{preason}\"")
            print()

        if result.would_escalate:
            limit = min(10, len(result.would_escalate))
            print(f"  New Escalations (first {limit} shown)")
            print("  " + "\u2500" * 43)
            for entry in result.would_escalate[:limit]:
                rid = entry["record_id"]
                atype = entry["action_type"]
                pname = entry.get("policy_name", "")
                preason = entry.get("policy_reason", "")
                print(f"  {rid}  {atype}")
                print(f"    Policy: {pname}  \"{preason}\"")
            print()

        # Override simulation output
        if result.override_sim_active and sim_overrides:
            sim = sim_overrides[0]
            action_scope = ", ".join(sim.action_types) if sim.action_types else "all"
            agent_scope = ", ".join(sim.target_agents) if sim.target_agents else "all agents"
            print(_bold("  Override Simulation"))
            print(f"    Authority:  {sim.authority}")
            print(f"    Scope:      {action_scope} actions ({agent_scope})")
            print(f"    Type:       {sim.override_type}")
            print()
            print(f"    Would override: {result.would_override_count} of {result.matched_count} matched records")
            if result.would_override_count > 0:
                print("    (These records would proceed despite policy denial)")
            print()

        print("  Run without --dry-run to apply these policies to live governance.")
        print()


def _cmd_override(args: argparse.Namespace) -> None:
    """Override a governance decision after the fact."""
    # Route subcommands: cosign, pending
    if args.action_id == "cosign":
        args.pending_id = args.extra_id
        if not args.pending_id:
            print(_red("Usage: nomotic override cosign <pending-id> --authority ... --reason ..."))
            sys.exit(1)
        if not args.authority or not args.reason:
            print(_red("--authority and --reason are required for cosign"))
            sys.exit(1)
        _cmd_override_cosign(args)
        return

    if args.action_id == "pending":
        args.pending_id = args.extra_id
        _cmd_override_pending(args)
        return

    # Default: direct override
    if not args.authority or not args.reason:
        print(_red("--authority and --reason are required"))
        sys.exit(1)

    if args.approve == args.revoke:  # both True or both False
        print(_red("Specify exactly one of --approve or --revoke"))
        sys.exit(1)

    override_type = "APPROVE" if args.approve else "REVOKE"

    base = args.base_dir
    from nomotic.audit_store import AuditStore
    from nomotic.runtime import GovernanceRuntime, RuntimeConfig

    # Build a runtime with the persistent audit store
    audit_store = AuditStore(base)
    runtime = GovernanceRuntime(RuntimeConfig(enable_audit=False))
    runtime.set_audit_store(audit_store)

    # If --agent is given, seed the trust profile from the audit store
    agent_id = args.agent if args.agent else None
    if agent_id:
        # Pre-load trust from the audit store summary
        summary = audit_store.summary(agent_id)
        if summary.get("total", 0) > 0:
            trust = summary.get("trust_end", 0.5)
            profile = runtime.trust_calibrator.get_profile(agent_id)
            profile.overall_trust = trust

    # Attempt to seed trust from last audit record for the agent
    if agent_id is None:
        # Search all agents for the action_id
        for aid in audit_store.list_agents():
            record = audit_store.find_by_action_id(aid, args.action_id)
            if record is not None:
                agent_id = record.agent_id
                profile = runtime.trust_calibrator.get_profile(agent_id)
                profile.overall_trust = record.trust_score
                break

    try:
        result = runtime.override(
            action_id=args.action_id,
            override_type=override_type,
            authority=args.authority,
            reason=args.reason,
            trust_penalty=args.trust_penalty,
        )
    except ValueError as e:
        print(_red(str(e)))
        sys.exit(1)

    # Check if result is a PendingOverride (multi-sig)
    from nomotic.types import PendingOverride
    if isinstance(result, PendingOverride):
        pending = result
        # Find policy name
        policy_name = pending.policy_id
        for p in runtime._multisig_policies:
            if p.policy_id == pending.policy_id:
                policy_name = p.name
                break

        expires_str = datetime.fromtimestamp(pending.expires_at, tz=timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        remaining = int(pending.expires_at - pending.created_at)

        print()
        print(_bold(f"Pending override created: {pending.override_id}"))
        print(f"  Policy:              {policy_name}")
        print(f"  Signatures needed:   {pending.required_signatures}")
        print(f"  Signatures so far:   {pending.signature_count} ({', '.join(pending.authorities_signed)})")
        print(f"  Expires:             {expires_str} (in {remaining}s)")
        if pending.status == "COMPLETE":
            print()
            print(_green("  Override COMPLETE (M=1 threshold met immediately)"))
        else:
            print()
            print("  To co-sign:")
            print(f'    nomotic override cosign {pending.override_id} --authority "..." --reason "..."')
        print()
        return

    # Display immediate override result
    print()
    print(_bold("Override Recorded"))
    print(f"  Override ID: {result.override_id}")
    if override_type == "APPROVE":
        print(f"  Type: {_green(override_type)}")
    else:
        print(f"  Type: {_red(override_type)}")
    print(f"  Action: {result.action_id}")
    print(f"  Agent: {result.agent_id}")
    print(f"  Authority: {result.authority}")
    print(f"  Reason: {result.reason}")
    if result.trust_before != result.trust_after:
        print(f"  Trust: {result.trust_before:.2f} \u2192 {result.trust_after:.2f}")
    print()


def _cmd_override_cosign(args: argparse.Namespace) -> None:
    """Co-sign a pending multi-sig override."""
    from nomotic.audit_store import AuditStore
    from nomotic.runtime import GovernanceRuntime, RuntimeConfig

    base = args.base_dir
    audit_store = AuditStore(base)
    runtime = GovernanceRuntime(RuntimeConfig(enable_audit=False))
    runtime.set_audit_store(audit_store)

    try:
        pending = runtime.cosign_override(
            pending_override_id=args.pending_id,
            authority=args.authority,
            reason=args.reason,
        )
    except ValueError as e:
        print(_red(str(e)))
        sys.exit(1)

    print()
    print(f"Co-signing override {pending.override_id}...")

    if pending.status == "COMPLETE":
        print(f"  Signatures:  {pending.signature_count} / {pending.required_signatures} \u2713 \u2014 threshold met")
        print("  Executing override...")
        print()
        print(_green("  Override COMPLETE"))
        print(f"  Action:      {pending.action_id}")
        print(f"  Type:        {pending.override_type}")
        print(f"  Signed by:   {', '.join(pending.authorities_signed)}")
        completed_str = datetime.fromtimestamp(
            pending.completed_at or 0, tz=timezone.utc
        ).strftime("%Y-%m-%d %H:%M:%S UTC")
        print(f"  Executed at: {completed_str}")
    else:
        print(f"  Signatures:  {pending.signature_count} / {pending.required_signatures}")
        print(f"  Signed by:   {', '.join(pending.authorities_signed)}")
        remaining = int(max(0, pending.expires_at - __import__('time').time()))
        expires_str = datetime.fromtimestamp(pending.expires_at, tz=timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        print(f"  Expires:     {expires_str} (in {remaining}s)")
    print()


def _cmd_override_pending(args: argparse.Namespace) -> None:
    """List or show pending overrides."""
    from nomotic.audit_store import AuditStore
    from nomotic.runtime import GovernanceRuntime, RuntimeConfig

    base = args.base_dir
    audit_store = AuditStore(base)
    runtime = GovernanceRuntime(RuntimeConfig(enable_audit=False))
    runtime.set_audit_store(audit_store)

    pending_id = getattr(args, "pending_id", None)

    if pending_id is not None:
        # Show single pending override
        pending = runtime.get_pending_override(pending_id)
        if pending is None:
            print(_red(f"Pending override not found: {pending_id}"))
            sys.exit(1)

        print()
        print(_bold(f"Pending Override: {pending.override_id}"))
        print(f"  Action:      {pending.action_id}")
        print(f"  Agent:       {pending.agent_id}")
        print(f"  Type:        {pending.override_type}")
        print(f"  Policy:      {pending.policy_id}")
        print(f"  Status:      {pending.status}")
        print(f"  Progress:    {pending.signature_count} / {pending.required_signatures} signatures")
        expires_str = datetime.fromtimestamp(pending.expires_at, tz=timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        remaining = int(max(0, pending.expires_at - __import__('time').time()))
        print(f"  Expires:     {expires_str} (in {remaining}s)")
        print()

        if pending.signatures:
            print("  Signatures:")
            for sig in pending.signatures:
                sig_time = datetime.fromtimestamp(sig.signed_at, tz=timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
                print(f"    - {sig.authority} ({sig_time})")
                print(f"      Role: {sig.role_id or 'N/A'}")
                print(f"      Reason: {sig.reason}")
        print()
        return

    # List all pending overrides
    pending_list = runtime.get_pending_overrides()

    if not pending_list:
        print("No pending overrides.")
        return

    print()
    print(_bold(f"PENDING OVERRIDES ({len(pending_list)})"))
    print()

    for p in pending_list:
        remaining = int(max(0, p.expires_at - __import__('time').time()))
        expires_str = datetime.fromtimestamp(p.expires_at, tz=timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        print(f"  {_bold(p.override_id)}")
        print(f"    Action:      {p.action_id}   Type: {p.override_type}")
        print(f"    Progress:    {p.signature_count} / {p.required_signatures} signatures")
        if p.authorities_signed:
            print(f"    Signed by:   {', '.join(p.authorities_signed)}")
        print(f"    Expires:     {expires_str} (in {remaining}s)")
        print()


def _resolve_roles_file(args: argparse.Namespace) -> Path | None:
    """Find a roles file using the search order:
    --roles-file arg > ./nomotic-roles.yaml > ./nomotic-roles.json > ~/.nomotic/roles.yaml
    """
    if getattr(args, "roles_file", None) is not None:
        return Path(args.roles_file)
    candidates = [
        Path("nomotic-roles.yaml"),
        Path("nomotic-roles.json"),
        Path.home() / ".nomotic" / "roles.yaml",
    ]
    for c in candidates:
        if c.exists():
            return c
    return None


def _cmd_roles(args: argparse.Namespace) -> None:
    """Manage governance override roles."""
    from nomotic.roles import RoleConfigError, RoleRegistry

    subcmd = getattr(args, "roles_command", None)
    if subcmd is None:
        print("Usage: nomotic roles {list|show|check}")
        sys.exit(1)

    roles_file = _resolve_roles_file(args)

    if subcmd == "list":
        if roles_file is None:
            print(_yellow("No roles file found."))
            print("  Searched: --roles-file, ./nomotic-roles.yaml, ./nomotic-roles.json, ~/.nomotic/roles.yaml")
            sys.exit(0)

        registry = RoleRegistry()
        try:
            count = registry.load_from_file(roles_file)
        except RoleConfigError as e:
            print(_red(f"Error loading roles: {e}"))
            sys.exit(1)

        print()
        print(_bold(f"Roles ({count} loaded from {roles_file})"))
        print()
        for role in registry.list_roles():
            print(f"  {_bold(role.role_id)}")
            print(f"    Name:        {role.name}")
            print(f"    Authorities: {', '.join(role.authorities)}")
            print(f"    Zones:       {', '.join(role.permitted_zones)}")
            print(f"    Max risk:    {role.max_risk_tier}")
            print()

    elif subcmd == "show":
        if roles_file is None:
            print(_red("No roles file found."))
            sys.exit(1)

        registry = RoleRegistry()
        try:
            registry.load_from_file(roles_file)
        except RoleConfigError as e:
            print(_red(f"Error loading roles: {e}"))
            sys.exit(1)

        role = registry.get_role(args.role_id)
        if role is None:
            print(_red(f"Role '{args.role_id}' not found"))
            sys.exit(1)

        print()
        print(_bold(f"Role: {role.name}"))
        print(f"  ID:                     {role.role_id}")
        print(f"  Authorities:            {', '.join(role.authorities)}")
        print(f"  Override types:         {', '.join(role.permitted_override_types)}")
        print(f"  Zones:                  {', '.join(role.permitted_zones)}")
        print(f"  Archetypes:             {', '.join(role.permitted_archetypes)}")
        print(f"  Action types:           {', '.join(role.permitted_action_types)}")
        print(f"  Max risk tier:          {role.max_risk_tier}")
        print(f"  Can override irrev.:    {role.can_override_irreversible}")
        print(f"  Created by:             {role.created_by}")
        print(f"  Role hash:              {role.role_hash[:16]}...")
        print()

    elif subcmd == "check":
        if roles_file is None:
            print(_red("No roles file found."))
            sys.exit(1)

        registry = RoleRegistry()
        try:
            registry.load_from_file(roles_file)
        except RoleConfigError as e:
            print(_red(f"Error loading roles: {e}"))
            sys.exit(1)

        # Look up the action from audit store
        base = args.base_dir
        action_type = "unknown"
        original_verdict = "unknown"

        try:
            from nomotic.audit_store import AuditStore
            store = AuditStore(base)
            for aid in store.list_agents():
                record = store.find_by_action_id(aid, args.action_id)
                if record is not None:
                    action_type = getattr(record, "action_type", "unknown") or "unknown"
                    original_verdict = getattr(record, "verdict", "unknown")
                    break
        except Exception:
            pass

        # Determine override type from original verdict
        if original_verdict == "DENY":
            override_type = "APPROVE"
        elif original_verdict == "ALLOW":
            override_type = "REVOKE"
        else:
            override_type = "APPROVE"

        result = registry.check_permission(
            authority=args.authority,
            override_type=override_type,
            action_type=action_type,
            zone_path="unknown",
            archetype="unknown",
            is_irreversible=False,
            risk_tier="moderate",
        )

        print()
        if result.permitted:
            print(f"  {_green('PERMITTED')}")
        else:
            print(f"  {_red('DENIED')}")
        print(f"  Reason: {result.reason}")
        print()


def _cmd_doctor(args: argparse.Namespace) -> None:
    """Run governance infrastructure health checks."""
    from nomotic.doctor import run_doctor

    base_dir = Path(args.base_dir) if hasattr(args, "base_dir") and args.base_dir else _DEFAULT_BASE
    report = run_doctor(base_dir)

    if args.doctor_json:
        print(json.dumps(report.to_dict(), indent=2))
        sys.exit(1 if report.has_errors else 0)

    # ── Header ────────────────────────────────────────────────────────────
    print()
    print(_bold("Nomotic Doctor"))
    print("\u2501" * 44)
    print()

    # ── Print checks ──────────────────────────────────────────────────────
    current_category = None
    for check in report.checks:
        if check.category != current_category:
            current_category = check.category
            print(f"  {_bold(check.category)}:")

        if check.status == "ok":
            if args.quiet:
                continue
            icon = _green("\u2713")
        elif check.status == "warning":
            icon = _yellow("\u26a0")
        else:  # error
            icon = _red("\u2717")

        print(f"    {icon} {check.message}")
        if check.fix_hint and args.fix and check.category != "Audit Trail":
            print(f"      \u2192 Fix: {check.fix_hint}")

    # ── Audit trail safety guard ──────────────────────────────────────────
    if args.fix:
        audit_errors = [
            c for c in report.checks
            if c.category == "Audit Trail" and c.status == "error"
        ]
        if audit_errors:
            print(
                "  \u26a0 Audit trail integrity issues require manual investigation"
                " \u2014 cannot be auto-fixed."
            )
            print(
                "  Chain breaks and tampering detections are forensic evidence"
                " and must be preserved."
            )
            print()

    # ── Summary ───────────────────────────────────────────────────────────
    print()
    n_errors = len(report.errors)
    n_warnings = len(report.warnings)

    if n_errors == 0 and n_warnings == 0:
        print(f"  {_green(chr(0x2713))} All checks passed.")
    else:
        parts = []
        if n_errors:
            parts.append(_red(f"{n_errors} error{'s' if n_errors != 1 else ''}"))
        if n_warnings:
            parts.append(_yellow(f"{n_warnings} warning{'s' if n_warnings != 1 else ''}"))
        print(f"  Summary: {', '.join(parts)}")
    print()

    if report.has_errors:
        sys.exit(1)


def _cmd_diagnose(args: argparse.Namespace) -> None:
    """Explain a Nomotic error in plain language with fix suggestions."""
    try:
        from nomotic.telemetry import get_telemetry
        get_telemetry().record_cli_command("diagnose")
    except Exception:
        pass
    import textwrap

    from nomotic.diagnostics import list_known_errors, resolve_diagnostic

    entry = resolve_diagnostic(args.error_code)
    if entry is None:
        print(f"\n  Unknown error code: '{args.error_code}'", file=sys.stderr)
        print("\n  Known error codes:", file=sys.stderr)
        for name in list_known_errors():
            print(f"    {name}", file=sys.stderr)
        sys.exit(1)

    print()
    print(_bold(_red(f"  {entry.error_class}")))
    print()
    print(_bold("  What it means:"))
    for line in textwrap.wrap(entry.what_it_means, width=70):
        print(f"    {line}")
    print()
    print(_bold("  Common causes:"))
    for cause in entry.common_causes:
        print(f"    \u2022 {cause}")
    print()
    print(_bold("  How to fix:"))
    for i, step in enumerate(entry.how_to_fix, 1):
        print(f"    {i}. {step}")
    print()

    if not args.no_doctor and entry.doctor_check:
        print(
            _dim(f"  Running: nomotic doctor (checking {entry.doctor_check})...")
        )
        print()
        from nomotic.doctor import run_doctor

        base_dir = (
            Path(args.base_dir)
            if hasattr(args, "base_dir") and args.base_dir
            else _DEFAULT_BASE
        )
        try:
            report = run_doctor(base_dir)
            relevant = [
                c for c in report.checks
                if c.category == entry.doctor_check
            ]
            if relevant:
                print(f"  {_bold(entry.doctor_check)}:")
                for check in relevant:
                    if check.status == "ok":
                        icon = _green("\u2713")
                    elif check.status == "warning":
                        icon = _yellow("\u26a0")
                    else:
                        icon = _red("\u2717")
                    print(f"    {icon} {check.message}")
                print()
            else:
                print(f"  No doctor checks found for category: {entry.doctor_check}")
                print()
        except Exception as e:
            print(f"  Doctor check failed: {e}", file=sys.stderr)
            print()


def _cmd_webhooks(args: argparse.Namespace) -> None:
    """Webhook management commands."""
    import time as _time
    import uuid as _uuid

    from nomotic.webhooks import (
        WebhookConfig,
        WebhookDispatcher,
        WebhookEvent,
        _QueuedEvent,
        _compute_signature,
    )

    subcmd = getattr(args, "webhooks_command", None)
    if subcmd is None:
        print("Usage: nomotic webhooks {test|status|drain}")
        sys.exit(1)

    base = args.base_dir

    if subcmd == "test":
        url = args.url
        secret = args.secret
        event_id = f"nmevt-{_uuid.uuid4().hex[:8]}"
        event = WebhookEvent(
            event_type="TEST_PING",
            event_id=event_id,
            timestamp=_time.time(),
            agent_id="cli-test",
            payload={"test": True},
        )
        config = WebhookConfig(
            url=url,
            events=["TEST_PING"],
            signing_secret=secret,
            max_retries=0,
            timeout_seconds=10.0,
        )
        payload = json.dumps(event.to_dict()).encode("utf-8")
        headers: dict[str, str] = {
            "Content-Type": "application/json",
            "User-Agent": "nomotic-webhook/0.4.0",
            "X-Nomotic-Event": event.event_type,
            "X-Nomotic-Event-Id": event.event_id,
        }
        sig_str = ""
        if secret:
            sig_str = _compute_signature(secret, payload)
            headers["X-Nomotic-Signature"] = sig_str
            headers["X-Nomotic-Signature-Version"] = "v1"

        print()
        print(f"Testing webhook: {url}")
        print()
        print("  Sending TEST_PING event...")

        import urllib.request

        start = _time.monotonic()
        try:
            req = urllib.request.Request(url, data=payload, method="POST", headers=headers)
            with urllib.request.urlopen(req, timeout=config.timeout_seconds) as resp:
                elapsed_ms = int((_time.monotonic() - start) * 1000)
                print(f"  Response: {resp.status} OK ({elapsed_ms}ms)")
                if secret:
                    print("  Signature: HMAC-SHA256 signed")
                print("  Delivery: SUCCESS")
        except Exception as e:
            elapsed_ms = int((_time.monotonic() - start) * 1000)
            print("  Delivery: FAILED")
            print(f"  Error: {e}")
            print()
            sys.exit(1)

        print()
        print("  Headers sent:")
        print(f"    X-Nomotic-Event:              {event.event_type}")
        print(f"    X-Nomotic-Event-Id:           {event.event_id}")
        if sig_str:
            print(f"    X-Nomotic-Signature:          {sig_str}")
            print("    X-Nomotic-Signature-Version:  v1")
        print()

    elif subcmd == "status":
        queue_path = base / "webhooks" / "webhook_queue.jsonl"
        print()
        print(_bold("Webhook Delivery Queue"))
        print()
        if not queue_path.exists():
            print("  No events queued. All deliveries are current.")
            print()
            return

        events: list[dict[str, Any]] = []
        for line in queue_path.read_text().splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                events.append(json.loads(line))
            except Exception:
                continue

        if not events:
            print("  No events queued. All deliveries are current.")
            print()
            return

        print(f"  Queued events: {len(events)}")
        print()
        for ev in events:
            inner = ev.get("event", {})
            eid = inner.get("event_id", "?")
            etype = inner.get("event_type", "?")
            url = ev.get("config_url", "?")
            attempts = ev.get("attempt_count", 0)
            queued_at = ev.get("queued_at", 0)
            from datetime import datetime, timezone
            ts = datetime.fromtimestamp(queued_at, tz=timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
            attempt_word = "attempt" if attempts == 1 else "attempts"
            print(f"  {eid}   queued {ts}   {etype:<15s} {url}  {attempts} {attempt_word}")
        print()
        print("  To retry: nomotic webhooks drain")
        print()

    elif subcmd == "drain":
        queue_path = base / "webhooks" / "webhook_queue.jsonl"
        if not queue_path.exists():
            print("No events queued. All deliveries are current.")
            return

        # Load queued events
        queued: list[_QueuedEvent] = []
        for line in queue_path.read_text().splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                queued.append(_QueuedEvent.from_dict(json.loads(line)))
            except Exception:
                continue

        if not queued:
            print("No events queued. All deliveries are current.")
            return

        print(f"Draining webhook queue ({len(queued)} events)...")
        print()

        # Try to load webhook configs from nomotic config
        config_path = base / "config.json"
        configs: dict[str, WebhookConfig] = {}
        if config_path.exists():
            try:
                cfg = json.loads(config_path.read_text())
                dispatcher = WebhookDispatcher.from_config(cfg)
                for wh in dispatcher._webhooks:
                    configs[wh.url] = wh
            except Exception:
                pass

        delivered = 0
        still_queued: list[_QueuedEvent] = []
        import urllib.request

        for qe in queued:
            config = configs.get(qe.config_url)
            if config is None:
                # Create a minimal config for the URL
                config = WebhookConfig(
                    url=qe.config_url,
                    events=[qe.event.event_type],
                    max_retries=0,
                )
            payload = json.dumps(qe.event.to_dict()).encode("utf-8")
            headers_d: dict[str, str] = {
                "Content-Type": "application/json",
                "User-Agent": "nomotic-webhook/0.4.0",
                "X-Nomotic-Event": qe.event.event_type,
                "X-Nomotic-Event-Id": qe.event.event_id,
            }
            if config.signing_secret:
                sig = _compute_signature(config.signing_secret, payload)
                headers_d["X-Nomotic-Signature"] = sig
                headers_d["X-Nomotic-Signature-Version"] = "v1"
            try:
                req = urllib.request.Request(
                    config.url, data=payload, method="POST", headers=headers_d,
                )
                with urllib.request.urlopen(req, timeout=config.timeout_seconds) as resp:
                    if resp.status < 300:
                        delivered += 1
                        print(f"  {_green('OK')} {qe.event.event_id} -> {qe.config_url} ({resp.status} OK)")
                    else:
                        qe.attempt_count += 1
                        qe.last_error = f"HTTP {resp.status}"
                        still_queued.append(qe)
                        print(f"  {_red('FAIL')} {qe.event.event_id} -> {qe.config_url} (HTTP {resp.status})")
            except Exception as e:
                qe.attempt_count += 1
                qe.last_error = str(e)
                still_queued.append(qe)
                print(f"  {_red('FAIL')} {qe.event.event_id} -> {qe.config_url} ({e})")

        print()
        print(f"  Delivered: {delivered} / {len(queued)}")
        print(f"  Still queued: {len(still_queued)}")

        # Rewrite queue file
        if still_queued:
            lines = [json.dumps(qe.to_dict()) for qe in still_queued]
            queue_path.write_text("\n".join(lines) + "\n")
        else:
            queue_path.write_text("")
        print()


def _cmd_continuity(args: argparse.Namespace) -> None:
    """Manage pre-evaluation state continuity checks."""
    cmd = getattr(args, "continuity_command", None)
    if cmd is None:
        cmd = "status"

    base_dir = Path(args.base_dir) if hasattr(args, "base_dir") and args.base_dir else _DEFAULT_BASE

    if cmd == "status":
        agent_id = args.agent_id
        try:
            _numeric_id, resolved_name, _cert_id = _resolve_agent(base_dir, agent_id)
            agent_id = resolved_name
        except SystemExit:
            pass

        print()
        print(f"  {_bold('Continuity Snapshot')}  {_cyan(agent_id)}")
        print(f"  {'─' * 50}")
        print()
        print("  Continuity snapshots are runtime state — they exist only")
        print("  while a GovernanceRuntime with continuity checks enabled")
        print("  is active.")
        print()
        print("  To enable continuity checks:")
        print("    RuntimeConfig(enable_continuity_checks=True)")
        print()
        print("  To verify audit chain integrity:")
        print(f"    nomotic audit {agent_id} --verify")
        print()

    elif cmd == "reset":
        agent_id = args.agent_id
        reason = args.reason
        try:
            _numeric_id, resolved_name, _cert_id = _resolve_agent(base_dir, agent_id)
            agent_id = resolved_name
        except SystemExit:
            pass

        print()
        print(f"  {_bold('Continuity Snapshot Reset')}  {_cyan(agent_id)}")
        print(f"  {'─' * 50}")
        print()
        print(f"  Reason: {reason}")
        print()
        print("  Continuity snapshots are runtime state. To reset a")
        print("  snapshot, call ContinuityChecker.clear_snapshot(agent_id)")
        print("  on the active runtime instance.")
        print()
        print("  If audit records have been intentionally cleared, use")
        print("  ContinuityChecker.update_snapshot() to re-baseline.")
        print()

    elif cmd == "verify":
        agent_id = args.agent_id
        try:
            _numeric_id, resolved_name, _cert_id = _resolve_agent(base_dir, agent_id)
            agent_id = resolved_name
        except SystemExit:
            pass

        # Delegate to existing audit verify
        from nomotic.audit_store import AuditStore

        store = AuditStore(base_dir)
        valid, count, msg = store.verify_chain(agent_id)
        print()
        print(f"  {_bold('Audit Chain Verification')}  {_cyan(agent_id)}")
        print(f"  {'─' * 50}")
        print()
        if valid:
            print(f"  {_green('VALID')}  {count} records verified")
        else:
            print(f"  {_red('INVALID')}  {msg}")
        print()


def _cmd_budget(args: argparse.Namespace) -> None:
    """Show pre-execution budget gate status."""
    cmd = getattr(args, "budget_command", None)
    if cmd is None:
        cmd = "status"

    if cmd == "status":
        group_id = args.group_id
        print()
        print(f"  {_bold('Budget Gate Status')}  {_cyan(group_id)}")
        print(f"  {'─' * 50}")
        print()
        print("  Budget gate is runtime state — it exists only while a")
        print("  GovernanceRuntime with a BudgetGate configured is active.")
        print()
        print("  To configure a budget gate:")
        print("    from nomotic.budget_gate import BudgetGate, BudgetLimit")
        print("    gate = BudgetGate(limits=[BudgetLimit(")
        print(f"        group_id='{group_id}', daily_limit_usd=10.0)])")
        print("    config = RuntimeConfig(budget_gate=gate)")
        print()
        print("  API endpoint:")
        print(f"    GET /v1/budget/groups/{group_id}/status")
        print()

    elif cmd == "reservations":
        group_filter = getattr(args, "group", None)
        print()
        print(f"  {_bold('Active Budget Reservations')}")
        print(f"  {'─' * 50}")
        print()
        print("  Budget reservations are runtime state.")
        if group_filter:
            print(f"  Filter: group_id={group_filter}")
        print()
        print("  API endpoint:")
        url = "/v1/budget/reservations"
        if group_filter:
            url += f"?group_id={group_filter}"
        print(f"    GET {url}")
        print()


def _cmd_delegation(args: argparse.Namespace) -> None:
    """Visualize and inspect delegation chains."""
    from nomotic.delegation import DelegationChainVisualizer, DelegationDepthConfig, DelegationTracker

    subcmd = getattr(args, "delegation_command", None)
    if subcmd is None:
        print("Usage: nomotic delegation {visualize|violations}")
        sys.exit(1)

    tracker = DelegationTracker(base_dir=args.base_dir)
    depth_config = DelegationDepthConfig()
    visualizer = DelegationChainVisualizer(tracker=tracker, depth_config=depth_config)

    if subcmd == "visualize":
        agent_id = args.agent_id
        fmt = getattr(args, "format", "ascii")
        output_path = getattr(args, "output", None)
        show_limits = getattr(args, "depth_limits", False)

        if fmt == "dot":
            result = visualizer.render_dot(agent_id)
        else:
            result = visualizer.render_ascii(agent_id, show_depth_limits=show_limits)

        if output_path:
            with open(output_path, "w") as f:
                f.write(result)
                f.write("\n")
            print(f"Output written to {output_path}")
        else:
            print()
            print(result)
            print()

    elif subcmd == "violations":
        agent_id = args.agent_id
        violations = visualizer.find_violations(agent_id)

        if not violations:
            print()
            print(f"  Delegation chain for '{agent_id}': no violations.")
            print("  All agents within archetype depth limits.")
            print()
        else:
            print()
            header = f"Delegation Violations \u2014 {agent_id}"
            print(f"  {_bold(header)}")
            separator = "\u2500" * 40
            print(f"  {separator}")
            for v in violations:
                arch = v["archetype"]
                aid = v["agent_id"]
                d = v["depth"]
                lim = v["limit"]
                exc = v["excess"]
                print(f"  \u26a0 {arch}: {aid}   depth={d}  limit={lim}  (excess: {exc})")
            print()
            count = len(violations)
            label = "violation" if count == 1 else "violations"
            print(f"  {count} {label} found. Review delegation structure.")
            print()


def _cmd_lifecycle(args: argparse.Namespace) -> None:
    """Manage agent lifecycle hooks and events."""
    cmd = getattr(args, "lifecycle_command", None)
    if cmd is None:
        print()
        print("  Usage: nomotic lifecycle <command>")
        print()
        print("  Commands:")
        print("    hooks   List registered lifecycle hooks")
        print("    events  Show lifecycle event history for an agent")
        print()
        return

    if cmd == "hooks":
        from nomotic.lifecycle import LifecycleManager

        mgr = LifecycleManager()
        hooks = mgr.list_hooks()
        print()
        if not hooks:
            print("  No lifecycle hooks registered.")
            print()
            print("  Register hooks programmatically via:")
            print("    runtime.register_lifecycle_hook(LifecycleEvent.BIRTH, callback)")
            print()
            return
        print("  Registered Lifecycle Hooks")
        print()
        for h in hooks:
            print(f"    {h['hook_id']}   {h['event']}")
        print()
        event_set = {h["event"] for h in hooks}
        print(f"  {len(hooks)} hooks registered across {len(event_set)} events.")
        print()

    elif cmd == "events":
        agent_id = args.agent_id
        base_dir = Path(args.base_dir) if hasattr(args, "base_dir") and args.base_dir else _DEFAULT_BASE

        # Resolve agent identifier
        try:
            numeric_id, name, cert_id = _resolve_agent(base_dir, agent_id)
        except (KeyError, SystemExit):
            name = agent_id

        # Load lifecycle events from persistent audit store
        from nomotic.audit_store import AuditStore

        audit_store = AuditStore(base_dir)
        all_records = audit_store.query_all(name)

        # Filter for lifecycle-related records
        lifecycle_records = []
        if all_records:
            for r in all_records:
                rec_dict = r.to_dict() if hasattr(r, "to_dict") else {}
                event_type = rec_dict.get("event_type", "")
                if event_type.startswith("LIFECYCLE_"):
                    lifecycle_records.append(rec_dict)

        print()
        print(f"  Lifecycle Events — {_bold(name)}")
        print()

        if not lifecycle_records:
            print("  No lifecycle events recorded.")
            print()
            print("  Lifecycle events fire automatically when agents reach")
            print("  governance milestones (birth, degradation, retirement, etc.).")
        else:
            for rec in lifecycle_records:
                ts = rec.get("timestamp", 0)
                if isinstance(ts, (int, float)):
                    dt_str = datetime.fromtimestamp(ts, tz=timezone.utc).strftime("%Y-%m-%d %H:%M")
                else:
                    dt_str = str(ts)[:16]
                event_type = rec.get("event_type", "unknown")
                trust = rec.get("trust_score", "?")
                print(f"    {dt_str}  {event_type:<25s}  trust={trust}")
            print()
            print(f"  {len(lifecycle_records)} events recorded.")
        print()


def _cmd_scorecard(args: argparse.Namespace) -> None:
    """Generate an auditor-ready governance compliance scorecard."""
    try:
        from nomotic.telemetry import get_telemetry
        get_telemetry().record_cli_command("scorecard")
    except Exception:
        pass
    from nomotic.audit_store import LogStore
    from nomotic.scorecard import GovernanceScorecardGenerator

    base_dir = Path(args.base_dir) if hasattr(args, "base_dir") and args.base_dir else _DEFAULT_BASE

    audit_store = LogStore(base_dir, "audit")

    # Resolve agent name
    try:
        _numeric_id, resolved_name, _cert_id = _resolve_agent(base_dir, args.agent)
        agent_name = resolved_name
    except SystemExit:
        agent_name = args.agent

    generator = GovernanceScorecardGenerator(base_dir, audit_store)
    try:
        scorecard = generator.generate(
            agent_id=agent_name,
            framework=args.framework,
            days=args.days,
        )
    except ValueError as exc:
        print(_red(f"Error: {exc}"), file=sys.stderr)
        sys.exit(1)

    if args.output_format == "json":
        content = scorecard.to_json()
        output_path = args.output or "-"
        if output_path == "-":
            print(content)
        else:
            Path(output_path).write_text(content, encoding="utf-8")
            print(f"  Scorecard written to {output_path}")
    else:
        content = scorecard.to_html()
        from datetime import date

        default_name = f"nomotic-scorecard-{agent_name}-{date.today()}.html"
        output_path = args.output or default_name
        Path(output_path).write_text(content, encoding="utf-8")
        print(f"  Scorecard written to {output_path}")


def _cmd_taxonomy(args: argparse.Namespace) -> None:
    """Print the Nomotic Drift Taxonomy reference."""
    try:
        from nomotic.telemetry import get_telemetry
        get_telemetry().record_cli_command("taxonomy")
    except Exception:
        pass

    print()
    print(_bold("  Nomotic Drift Taxonomy"))
    print()
    print(_bold("  Drift Distributions") + " (what is drifting):")
    print()
    print("    Distribution  Description                                    Module")
    print("    " + "-" * 74)
    print("    Action        Change in the distribution of action types      drift")
    print("    Target        Change in the distribution of operation targets  drift")
    print("    Temporal      Change in when/how frequently the agent acts     drift")
    print("    Outcome       Change in governance evaluation outcomes         drift")
    print("    Semantic      Change in the intent/meaning of actions          " + _dim("v0.7.0"))
    print()
    print(_bold("  Drift Scopes") + " (who is drifting):")
    print()
    print("    Scope         Description                                    Module")
    print("    " + "-" * 74)
    print("    Agent         Individual agent behavioral deviation            drift")
    print("    Human         Human reviewer oversight degradation             human_drift")
    print("    Fleet         Aggregate drift across agent populations         " + _dim("v0.7.0"))
    print("    Correlated    Multiple agents drifting in the same direction   " + _dim("v0.7.0"))
    print("    Coordinated   Agents drifting in complementary ways            " + _dim("v0.7.0"))
    print()
    print("  The taxonomy forms a 5x5 matrix.  Each cell represents a specific")
    print("  class of behavioral drift: e.g., 'action drift at fleet scope' detects")
    print("  when a population of agents collectively shifts what actions they perform.")
    print()


def _cmd_contract(args: argparse.Namespace) -> None:
    """Manage behavioral contracts."""
    try:
        from nomotic.telemetry import get_telemetry
        get_telemetry().record_cli_command("contract")
    except Exception:
        pass

    sub = getattr(args, "contract_command", None)
    if sub is None:
        print("Usage: nomotic contract {generate|show|validate|diff}")
        sys.exit(1)

    base_dir = Path(args.base_dir) if hasattr(args, "base_dir") and args.base_dir else _DEFAULT_BASE

    if sub == "generate":
        from nomotic.contract import generate_contract
        from nomotic.priors import PriorRegistry

        registry = PriorRegistry.with_defaults()
        archetype = getattr(args, "archetype", "general") or "general"
        agent_id = args.agent
        contract = generate_contract(
            agent_id=agent_id,
            archetype=archetype,
            prior_registry=registry,
        )
        print(json.dumps(contract.to_dict(), indent=2, sort_keys=True))

    elif sub == "show":
        from nomotic.contract import ContractStore
        from nomotic.runtime import GovernanceRuntime, RuntimeConfig

        runtime = GovernanceRuntime(RuntimeConfig(
            enable_fingerprints=False,
            enable_audit=False,
            enable_contextual_modifier=False,
            enable_workflow_governor=False,
            enable_equity_analysis=False,
            enable_bias_detection=False,
            enable_cross_dimensional=False,
            enable_contracts=True,
        ))
        contract = runtime.get_contract(args.agent)
        if contract is None:
            print(f"No active contract for agent {args.agent}.")
        else:
            print(json.dumps(contract.to_dict(), indent=2, sort_keys=True))

    elif sub == "validate":
        from nomotic.contract import ContractStore
        from nomotic.runtime import GovernanceRuntime, RuntimeConfig

        runtime = GovernanceRuntime(RuntimeConfig(
            enable_fingerprints=False,
            enable_audit=False,
            enable_contextual_modifier=False,
            enable_workflow_governor=False,
            enable_equity_analysis=False,
            enable_bias_detection=False,
            enable_cross_dimensional=False,
            enable_contracts=True,
        ))
        contract = runtime.get_contract(args.agent)
        if contract is None:
            print(f"No active contract for agent {args.agent}.")
            sys.exit(1)
        if not contract.signature:
            print(f"Contract v{contract.version} for agent {args.agent}: INVALID: no signature")
            sys.exit(1)
        # Would need the verify key to actually check — report seal presence
        print(f"Contract v{contract.version} for agent {args.agent}: sealed by {contract.signed_by}")

    elif sub == "diff":
        from nomotic.contract import ContractStore
        from nomotic.runtime import GovernanceRuntime, RuntimeConfig

        runtime = GovernanceRuntime(RuntimeConfig(
            enable_fingerprints=False,
            enable_audit=False,
            enable_contextual_modifier=False,
            enable_workflow_governor=False,
            enable_equity_analysis=False,
            enable_bias_detection=False,
            enable_cross_dimensional=False,
            enable_contracts=True,
        ))
        store = runtime._contract_store
        if store is None:
            print("Contracts not enabled.")
            sys.exit(1)
        v1_contract = store.get_version(args.agent, args.v1)
        v2_contract = store.get_version(args.agent, args.v2)
        if v1_contract is None:
            print(f"Version {args.v1} not found for agent {args.agent}.")
            sys.exit(1)
        if v2_contract is None:
            print(f"Version {args.v2} not found for agent {args.agent}.")
            sys.exit(1)
        result = v1_contract.diff(v2_contract)
        print(json.dumps(result, indent=2, sort_keys=True, default=str))


def _cmd_control(args: argparse.Namespace) -> None:
    """Issue behavioral directives to the agent fleet."""
    try:
        from nomotic.telemetry import get_telemetry
        get_telemetry().record_cli_command("control")
    except Exception:
        pass

    sub = getattr(args, "control_command", None)
    if sub is None:
        print("Usage: nomotic control {enforce|quarantine|release|tighten|relax|re-anchor|broadcast-reminder|list}")
        sys.exit(1)

    from nomotic.control_plane import BehavioralDirective, DirectiveResult
    from nomotic.runtime import GovernanceRuntime, RuntimeConfig

    # Build a minimal runtime with control plane enabled
    runtime = GovernanceRuntime(RuntimeConfig(
        enable_fingerprints=True,
        enable_audit=True,
        enable_contextual_modifier=False,
        enable_workflow_governor=False,
        enable_equity_analysis=False,
        enable_bias_detection=False,
        enable_cross_dimensional=False,
        enable_contracts=True,
        enable_control_plane=True,
    ))

    agents = tuple(getattr(args, "agents", None) or ())
    archetype = getattr(args, "archetype", "")
    team = getattr(args, "team", "")
    issued_by = getattr(args, "issued_by", "cli-operator")
    reason = getattr(args, "reason", "")

    if sub == "list":
        directives = runtime.get_control_directives()
        if not directives:
            print("No active control directives.")
            return
        for d in directives:
            print(json.dumps(d.to_dict(), indent=2, sort_keys=True, default=str))
        return

    # Parse --scope flag for quarantine (e.g., team:support -> target_team=support)
    scope_str = getattr(args, "scope", "")
    if scope_str and ":" in scope_str:
        scope_type, scope_value = scope_str.split(":", 1)
        if scope_type == "team" and not team:
            team = scope_value
        elif scope_type == "archetype" and not archetype:
            archetype = scope_value

    # Map CLI sub-commands to directive types
    type_map = {
        "enforce": "enforce",
        "quarantine": "quarantine",
        "release": "release",
        "tighten": "tighten",
        "relax": "relax",
        "re-anchor": "re_anchor",
        "broadcast-reminder": "broadcast_reminder",
    }
    directive_type = type_map.get(sub)
    if directive_type is None:
        print(f"Unknown control command: {sub}")
        sys.exit(1)

    kwargs: dict[str, Any] = {
        "target_agents": agents,
        "target_archetype": archetype,
        "target_team": team,
        "reason": reason,
    }

    duration = getattr(args, "duration", None)
    if duration is not None:
        kwargs["duration_seconds"] = duration

    if sub == "enforce":
        invariant_str = getattr(args, "invariant", "{}")
        try:
            kwargs["invariant_spec"] = json.loads(invariant_str)
        except json.JSONDecodeError:
            print(f"Invalid JSON for --invariant: {invariant_str}", file=sys.stderr)
            sys.exit(1)

    if sub == "tighten":
        kwargs["tighten_factor"] = getattr(args, "factor", 0.5)

    if sub == "re-anchor":
        kwargs["semantic_term"] = getattr(args, "term", "")

    if sub == "broadcast-reminder":
        kwargs["contract_version"] = getattr(args, "contract_version", "")
        drift_status = getattr(args, "drift_status", "")
        if drift_status:
            kwargs["target_drift_status"] = drift_status

    directive = BehavioralDirective.create(
        directive_type=directive_type,
        issued_by=issued_by,
        **kwargs,
    )
    result = runtime.issue_directive(directive)

    if result.success:
        print(_green(f"Directive {result.directive_id} issued successfully."))
        print(f"  Type: {directive_type}")
        print(f"  Agents affected: {len(result.agents_affected)}")
        if result.detail:
            print(f"  Detail: {result.detail}")
    else:
        print(_red(f"Directive failed: {result.detail}"))
        sys.exit(1)


def _cmd_ledger(args: argparse.Namespace) -> None:
    """BehaviorLedger — complete decision reconstruction."""
    try:
        from nomotic.telemetry import get_telemetry
        get_telemetry().record_cli_command("ledger")
    except Exception:
        pass

    sub = getattr(args, "ledger_command", None)
    if sub is None:
        print("Usage: nomotic ledger {show|trace|narrative|verify|query|export}")
        sys.exit(1)

    if sub == "export":
        _cmd_ledger_export(args)
        return

    # The ledger store requires a running runtime or a persisted store.
    # For CLI, we just explain what the command would do since ledger
    # entries live in-memory during runtime unless a base_dir is set.
    print(f"BehaviorLedger: '{sub}' command")
    print()

    if sub == "show":
        agent_id = args.agent
        seq = getattr(args, "sequence", None)
        if seq is not None:
            print(f"Would show ledger entry #{seq} for agent {agent_id}.")
        else:
            print(f"Would show latest ledger entry for agent {agent_id}.")
        print()
        print("Note: BehaviorLedger entries are assembled at runtime during")
        print("evaluate() calls. Use the API server (nomotic serve) with")
        print("enable_behavior_ledger=True to query live ledger entries.")

    elif sub == "trace":
        agent_id = args.agent
        seq = args.sequence
        depth = getattr(args, "depth", 10)
        print(f"Would walk causal chain backward from entry #{seq} for agent {agent_id} (depth {depth}).")
        print()
        print("Use the API endpoint GET /v1/ledger/{agent_id}/trace/{sequence}?depth={depth}")

    elif sub == "narrative":
        agent_id = args.agent
        seq = getattr(args, "sequence", None)
        if seq is not None:
            print(f"Would print narrative reconstruction of entry #{seq} for agent {agent_id}.")
        else:
            print(f"Would print narrative reconstruction of latest entry for agent {agent_id}.")

    elif sub == "verify":
        agent_id = args.agent
        print(f"Would verify hash chain integrity for agent {agent_id}.")
        print()
        print("Use the API endpoint GET /v1/ledger/{agent_id}/verify")

    elif sub == "query":
        agent_id = getattr(args, "agent", None)
        verdict_filter = getattr(args, "verdict", None)
        limit = getattr(args, "limit", 10)
        parts = []
        if agent_id:
            parts.append(f"agent={agent_id}")
        if verdict_filter:
            parts.append(f"verdict={verdict_filter}")
        parts.append(f"limit={limit}")
        print(f"Would query ledger entries with filters: {', '.join(parts)}.")


def _cmd_ledger_export(args: argparse.Namespace) -> None:
    """Export ledger entries in compliance-friendly formats."""
    from datetime import timezone
    from nomotic.behavior_ledger import BehaviorLedgerExporter, BehaviorLedgerStore

    agent_id = args.agent
    fmt = args.export_format
    output_path = args.output

    # Parse date filters
    since_ts: float | None = None
    until_ts: float | None = None
    if args.since:
        since_ts = datetime.fromisoformat(args.since).replace(
            tzinfo=timezone.utc
        ).timestamp()
    if args.until:
        until_ts = datetime.fromisoformat(args.until).replace(
            tzinfo=timezone.utc
        ).timestamp()

    verdict_filter = getattr(args, "export_verdict", None)
    limit = getattr(args, "export_limit", 10000)

    # Try to load from persisted JSONL files
    base_dir = Path(args.base_dir) if hasattr(args, "base_dir") and args.base_dir else _DEFAULT_BASE
    ledger_file = base_dir / f"ledger_{agent_id}.jsonl"

    if not ledger_file.exists():
        print(
            f"No persisted ledger file found at {ledger_file}.",
            file=sys.stderr,
        )
        print(
            "BehaviorLedger entries are persisted when the runtime is configured "
            "with a base_dir. Use the API server for live export.",
            file=sys.stderr,
        )
        sys.exit(1)

    from nomotic.behavior_ledger import BehaviorLedgerEntry

    entries: list[BehaviorLedgerEntry] = []
    with open(ledger_file, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            data = json.loads(line)
            entry = BehaviorLedgerEntry.from_dict(data)
            if since_ts is not None and entry.timestamp < since_ts:
                continue
            if until_ts is not None and entry.timestamp > until_ts:
                continue
            if verdict_filter is not None and entry.verdict != verdict_filter:
                continue
            entries.append(entry)
            if len(entries) >= limit:
                break

    if not entries:
        print(f"No matching ledger entries found for agent {agent_id}.", file=sys.stderr)
        sys.exit(1)

    exporter = BehaviorLedgerExporter()
    if fmt == "json":
        exporter.export_json(entries, output_path)
    elif fmt == "jsonl":
        exporter.export_jsonl(entries, output_path)
    elif fmt == "narrative":
        exporter.export_narrative(entries, output_path)
    elif fmt == "csv":
        exporter.export_csv_summary(entries, output_path)

    print(f"Exported {len(entries)} entries to {output_path} (format: {fmt})")


def _cmd_replay(args: argparse.Namespace) -> None:
    """Counterfactual behavioral replay — what would have happened if?"""
    try:
        from nomotic.telemetry import get_telemetry
        get_telemetry().record_cli_command("replay")
    except Exception:
        pass

    from nomotic.audit_store import AuditStore
    from nomotic.replay import BehavioralReplayEngine, ReplayConfig

    base_dir = Path(args.base_dir) if hasattr(args, "base_dir") and args.base_dir else _DEFAULT_BASE
    audit_store = AuditStore(base_dir)

    # Build replay config from CLI args or JSON file.
    if args.config:
        config_path = Path(args.config)
        if not config_path.exists():
            print(f"Config file not found: {args.config}", file=sys.stderr)
            sys.exit(1)
        with open(config_path, "r", encoding="utf-8") as f:
            config_data = json.load(f)
        replay_config = ReplayConfig.from_dict(config_data)
    else:
        replay_config = ReplayConfig(
            allow_threshold=args.allow_threshold,
            deny_threshold=args.deny_threshold,
            trust_influence=args.trust_influence,
            description=args.description or "CLI replay",
        )

    engine = BehavioralReplayEngine(audit_store=audit_store)
    report = engine.replay(
        agent_id=args.agent,
        replay_config=replay_config,
        start_time=args.start_time,
        end_time=args.end_time,
        max_actions=args.max_actions,
    )

    if getattr(args, "replay_json", False):
        print(json.dumps(report.to_dict(), indent=2, sort_keys=True))
    else:
        print(report.summary)
        if report.total_divergences > 0:
            print(f"\nDivergence points ({report.total_divergences}):")
            for dp in report.divergence_points[:20]:
                print(
                    f"  [{dp.action_index}] {dp.action_type} -> {dp.target}: "
                    f"{dp.actual_verdict} -> {dp.counterfactual_verdict} ({dp.direction})"
                )
            if report.total_divergences > 20:
                print(f"  ... and {report.total_divergences - 20} more (use --json for full output)")


def main(argv: list[str] | None = None) -> None:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command is None:
        parser.print_help()
        sys.exit(0)

    commands = {
        "setup": _cmd_setup,
        "new": _cmd_new,
        "birth": _cmd_birth,
        "init": _cmd_init,
        "verify": _cmd_verify,
        "inspect": _cmd_inspect_agent,
        "suspend": _cmd_suspend,
        "reactivate": _cmd_reactivate,
        "revoke": _cmd_revoke,
        "renew": _cmd_renew,
        "list": _cmd_list,
        "reputation": _cmd_reputation,
        "export": _cmd_export,
        "status": _cmd_status_global,
        "history": _cmd_history,
        "archetype": _cmd_archetype,
        "org": _cmd_org,
        "zone": _cmd_zone,
        "scope": _cmd_scope,
        "rule": _cmd_rule,
        "config": _cmd_config,
        "test": _cmd_test,
        "eval": _cmd_test,
        "simulate": _cmd_simulate,
        "tutorial": _cmd_tutorial,
        "serve": _cmd_serve,
        "hello": _cmd_hello,
        "fingerprint": _cmd_fingerprint,
        "drift": _cmd_drift,
        "trajectory": _cmd_trajectory,
        "alerts": _cmd_alerts,
        "trust": _cmd_trust,
        "audit": _cmd_audit,
        "testlog": _cmd_testlog,
        "provenance": _cmd_provenance,
        "owner": _cmd_owner,
        "oversight": _cmd_oversight,
        "siem-export": _cmd_siem_export,
        "mcp-proxy": _cmd_mcp_proxy,
        "proxy": _cmd_proxy,
        "evidence": _cmd_evidence,
        "compliance-report": _cmd_compliance_report,
        "compliance-gaps": _cmd_compliance_gaps,
        "validate": _cmd_validate,
        "cost": _cmd_cost,
        "doctor": _cmd_doctor,
        "diagnose": _cmd_diagnose,
        "override": _cmd_override,
        "roles": _cmd_roles,
        "policy-validate": _cmd_policy_validate,
        "webhooks": _cmd_webhooks,
        "fleet": _cmd_fleet,
        "constitution": _cmd_constitution,
        "authority-registry": _cmd_authority_registry,
        "continuity": _cmd_continuity,
        "budget": _cmd_budget,
        "delegation": _cmd_delegation,
        "uahs": _cmd_uahs,
        "lifecycle": _cmd_lifecycle,
        "workflow": _cmd_workflow,
        "scorecard": _cmd_scorecard,
        "taxonomy": _cmd_taxonomy,
        "contract": _cmd_contract,
        "control": _cmd_control,
        "replay": _cmd_replay,
        "ledger": _cmd_ledger,
    }

    handler = commands.get(args.command)
    if handler is None:
        parser.print_help()
        sys.exit(1)
    handler(args)


if __name__ == "__main__":
    main()
