"""Behavioral Command & Control — the steering wheel.

The ControlPlane processes declarative behavioral directives and applies
them to targeted agents through the runtime. Operators don't just define
rules and watch outcomes. They push behavioral state changes into the
fleet, respond to emerging situations, and manage agent behavior the way
network operators manage traffic.

Every control action is itself governed, audited, and recorded with
full provenance. The control surface is subject to the same behavioral
accountability it imposes.
"""

from __future__ import annotations

import threading
import time
import uuid
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from nomotic.observer import FingerprintObserver
    from nomotic.provenance import ProvenanceLog
    from nomotic.semantic import SemanticObserver

__all__ = [
    "BehavioralDirective",
    "ControlPlane",
    "DIRECTIVE_TYPES",
    "DirectiveResult",
]

DIRECTIVE_TYPES = {
    "enforce",
    "quarantine",
    "release",
    "broadcast_reminder",
    "tighten",
    "relax",
    "re_anchor",
}


@dataclass(frozen=True)
class BehavioralDirective:
    """A declarative behavioral directive issued by an operator.

    Directives are the atoms of active steering. Each one targets a set
    of agents and pushes a specific behavioral state change into the fleet.
    """

    directive_id: str
    directive_type: str  # One of DIRECTIVE_TYPES
    issued_by: str
    issued_at: float

    # Targeting — at least one must be specified
    target_agents: tuple[str, ...] = ()
    target_archetype: str = ""
    target_team: str = ""
    target_drift_status: str = ""  # "drifting" or "critical"

    # Parameters
    invariant_spec: dict[str, Any] | None = None  # For "enforce"
    duration_seconds: float | None = None
    reason: str = ""
    contract_version: str = ""  # For "broadcast_reminder"
    semantic_term: str = ""  # For "re_anchor"
    tighten_factor: float = 0.5  # For "tighten": multiply thresholds by this
    active: bool = True
    expires_at: float | None = None  # Computed from issued_at + duration_seconds

    def to_dict(self) -> dict[str, Any]:
        """Serialize to JSON-friendly dict."""
        return {
            "directive_id": self.directive_id,
            "directive_type": self.directive_type,
            "issued_by": self.issued_by,
            "issued_at": self.issued_at,
            "target_agents": list(self.target_agents),
            "target_archetype": self.target_archetype,
            "target_team": self.target_team,
            "target_drift_status": self.target_drift_status,
            "invariant_spec": self.invariant_spec,
            "duration_seconds": self.duration_seconds,
            "reason": self.reason,
            "contract_version": self.contract_version,
            "semantic_term": self.semantic_term,
            "tighten_factor": self.tighten_factor,
            "active": self.active,
            "expires_at": self.expires_at,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> BehavioralDirective:
        """Deserialize from dict."""
        return cls(
            directive_id=data["directive_id"],
            directive_type=data["directive_type"],
            issued_by=data["issued_by"],
            issued_at=data["issued_at"],
            target_agents=tuple(data.get("target_agents", ())),
            target_archetype=data.get("target_archetype", ""),
            target_team=data.get("target_team", ""),
            target_drift_status=data.get("target_drift_status", ""),
            invariant_spec=data.get("invariant_spec"),
            duration_seconds=data.get("duration_seconds"),
            reason=data.get("reason", ""),
            contract_version=data.get("contract_version", ""),
            semantic_term=data.get("semantic_term", ""),
            tighten_factor=data.get("tighten_factor", 0.5),
            active=data.get("active", True),
            expires_at=data.get("expires_at"),
        )

    @classmethod
    def create(
        cls,
        directive_type: str,
        issued_by: str,
        **kwargs: Any,
    ) -> BehavioralDirective:
        """Factory that sets directive_id, issued_at, and computes expires_at."""
        if directive_type not in DIRECTIVE_TYPES:
            raise ValueError(
                f"Invalid directive_type '{directive_type}'. "
                f"Must be one of: {sorted(DIRECTIVE_TYPES)}"
            )
        now = time.time()
        duration = kwargs.pop("duration_seconds", None)
        expires = (now + duration) if duration else None
        # Normalize target_agents to tuple
        agents = kwargs.pop("target_agents", ())
        if isinstance(agents, list):
            agents = tuple(agents)
        return cls(
            directive_id=str(uuid.uuid4()),
            directive_type=directive_type,
            issued_by=issued_by,
            issued_at=now,
            duration_seconds=duration,
            expires_at=expires,
            target_agents=agents,
            **kwargs,
        )


@dataclass
class DirectiveResult:
    """Outcome of issuing a behavioral directive."""

    directive_id: str
    agents_affected: list[str]
    success: bool
    detail: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "directive_id": self.directive_id,
            "agents_affected": self.agents_affected,
            "success": self.success,
            "detail": self.detail,
        }


class ControlPlane:
    """Active behavioral steering for the agent fleet.

    The ControlPlane is the runtime component that processes operator
    directives and applies them to targeted agents. It is the literal
    embodiment of the "control plane" metaphor — operators push
    behavioral state changes into the fleet in real time.
    """

    def __init__(
        self,
        runtime: Any,
        provenance_log: ProvenanceLog | None = None,
    ) -> None:
        self._runtime = runtime
        self._provenance = provenance_log
        self._active_directives: list[BehavioralDirective] = []
        self._directive_history: list[BehavioralDirective] = []
        self._quarantined: set[str] = set()
        self._enforced_invariants: dict[str, list[dict[str, Any]]] = {}
        self._tightened_agents: dict[str, float] = {}
        self._reminders: dict[str, list[dict[str, Any]]] = {}
        self._lock = threading.Lock()

    # ── Public API ───────────────────────────────────────────────────

    def issue(self, directive: BehavioralDirective) -> DirectiveResult:
        """Issue a behavioral directive to the fleet.

        1. Validate directive type.
        2. Resolve targets.
        3. Dispatch to the appropriate handler.
        4. Record in active directives and history.
        5. Record provenance.
        """
        if directive.directive_type not in DIRECTIVE_TYPES:
            return DirectiveResult(
                directive_id=directive.directive_id,
                agents_affected=[],
                success=False,
                detail=f"Unknown directive type: {directive.directive_type}",
            )

        targets = self._resolve_targets(directive)
        if not targets:
            result = DirectiveResult(
                directive_id=directive.directive_id,
                agents_affected=[],
                success=False,
                detail="No matching agents",
            )
            self._record_provenance(directive, result)
            return result

        handler = getattr(self, f"_handle_{directive.directive_type}", None)
        if handler is None:
            return DirectiveResult(
                directive_id=directive.directive_id,
                agents_affected=[],
                success=False,
                detail=f"No handler for directive type: {directive.directive_type}",
            )

        result = handler(directive, targets)

        with self._lock:
            if directive.duration_seconds is not None or directive.directive_type in (
                "enforce", "quarantine", "tighten",
            ):
                self._active_directives.append(directive)
            self._directive_history.append(directive)

        self._record_provenance(directive, result)
        return result

    def is_quarantined(self, agent_id: str) -> bool:
        """Check whether an agent is currently quarantined."""
        with self._lock:
            return agent_id in self._quarantined

    def get_enforced_invariants(self, agent_id: str) -> list[dict[str, Any]]:
        """Get temporarily enforced invariants for an agent."""
        with self._lock:
            return list(self._enforced_invariants.get(agent_id, []))

    def get_tighten_factor(self, agent_id: str) -> float:
        """Get the current tightening factor for an agent. 1.0 = no tightening."""
        with self._lock:
            return self._tightened_agents.get(agent_id, 1.0)

    def get_active_directives(self) -> list[BehavioralDirective]:
        """Get all currently active directives."""
        with self._lock:
            return list(self._active_directives)

    def get_directive_history(self) -> list[BehavioralDirective]:
        """Get all historical directives (active and expired)."""
        with self._lock:
            return list(self._directive_history)

    def expire_directives(self) -> int:
        """Expire directives past their expires_at. Undo their effects.

        Returns the number of directives expired.
        """
        now = time.time()
        expired_count = 0

        with self._lock:
            still_active: list[BehavioralDirective] = []
            for d in self._active_directives:
                if d.expires_at is not None and now >= d.expires_at:
                    self._undo_directive(d)
                    expired_count += 1
                else:
                    still_active.append(d)
            self._active_directives = still_active

        return expired_count

    # ── Target Resolution ────────────────────────────────────────────

    def _resolve_targets(self, directive: BehavioralDirective) -> list[str]:
        """Resolve targeting criteria to a list of agent IDs."""
        # If specific agents are targeted, start with those
        if directive.target_agents:
            candidates = set(directive.target_agents)
        else:
            # Start with all known agents from the fingerprint observer
            candidates = self._get_all_agent_ids()

        if not candidates:
            return []

        # Apply filters — each filter narrows the candidate set
        filters_applied = False

        if directive.target_archetype:
            filters_applied = True
            archetype_agents = self._get_agents_by_archetype(directive.target_archetype)
            candidates = candidates & archetype_agents

        if directive.target_team:
            filters_applied = True
            team_agents = self._get_agents_by_team(directive.target_team)
            candidates = candidates & team_agents

        if directive.target_drift_status:
            filters_applied = True
            drift_agents = self._get_agents_by_drift_status(directive.target_drift_status)
            candidates = candidates & drift_agents

        # If no filters were applied and no specific agents, return all known
        if not filters_applied and not directive.target_agents:
            return sorted(candidates)

        return sorted(candidates)

    def _get_all_agent_ids(self) -> set[str]:
        """Get all known agent IDs from the fingerprint observer."""
        observer = getattr(self._runtime, "_fingerprint_observer", None)
        if observer is None:
            return set()
        try:
            fps = observer.all_fingerprints()
            return set(fps.keys())
        except Exception:
            return set()

    def _get_agents_by_archetype(self, archetype: str) -> set[str]:
        """Filter agents by archetype using the contract store."""
        contract_store = getattr(self._runtime, "_contract_store", None)
        if contract_store is None:
            return set()
        result = set()
        try:
            for contract in contract_store.all_active():
                if contract.archetype == archetype:
                    result.add(contract.agent_id)
        except Exception:
            pass
        return result

    def _get_agents_by_team(self, team: str) -> set[str]:
        """Filter agents by team metadata from contracts."""
        contract_store = getattr(self._runtime, "_contract_store", None)
        if contract_store is None:
            return set()
        result = set()
        try:
            for contract in contract_store.all_active():
                scope = contract.authorized_scope or {}
                agent_team = scope.get("team", "")
                if agent_team == team:
                    result.add(contract.agent_id)
        except Exception:
            pass
        return result

    def _get_agents_by_drift_status(self, status: str) -> set[str]:
        """Filter agents by drift severity."""
        observer = getattr(self._runtime, "_fingerprint_observer", None)
        if observer is None:
            return set()
        result = set()
        try:
            fps = observer.all_fingerprints()
            for agent_id in fps:
                drift = observer.get_drift(agent_id)
                if drift is None:
                    continue
                severity = drift.severity
                if status == "drifting" and severity in (
                    "moderate", "high", "critical",
                ):
                    result.add(agent_id)
                elif status == "critical" and severity == "critical":
                    result.add(agent_id)
        except Exception:
            pass
        return result

    # ── Directive Handlers ───────────────────────────────────────────

    def _handle_enforce(
        self, directive: BehavioralDirective, targets: list[str],
    ) -> DirectiveResult:
        """Push a temporary invariant to targeted agents."""
        spec = directive.invariant_spec or {}
        with self._lock:
            for agent_id in targets:
                if agent_id not in self._enforced_invariants:
                    self._enforced_invariants[agent_id] = []
                self._enforced_invariants[agent_id].append({
                    "directive_id": directive.directive_id,
                    "spec": spec,
                })
        return DirectiveResult(
            directive_id=directive.directive_id,
            agents_affected=targets,
            success=True,
            detail=f"Enforced invariant on {len(targets)} agent(s)",
        )

    def _handle_quarantine(
        self, directive: BehavioralDirective, targets: list[str],
    ) -> DirectiveResult:
        """Quarantine agents — all evaluations will force ESCALATE."""
        with self._lock:
            for agent_id in targets:
                self._quarantined.add(agent_id)
        return DirectiveResult(
            directive_id=directive.directive_id,
            agents_affected=targets,
            success=True,
            detail=f"Quarantined {len(targets)} agent(s): {directive.reason}",
        )

    def _handle_release(
        self, directive: BehavioralDirective, targets: list[str],
    ) -> DirectiveResult:
        """Release agents from quarantine."""
        released = []
        with self._lock:
            for agent_id in targets:
                if agent_id in self._quarantined:
                    self._quarantined.discard(agent_id)
                    released.append(agent_id)
        return DirectiveResult(
            directive_id=directive.directive_id,
            agents_affected=released,
            success=True,
            detail=f"Released {len(released)} agent(s) from quarantine",
        )

    def _handle_broadcast_reminder(
        self, directive: BehavioralDirective, targets: list[str],
    ) -> DirectiveResult:
        """Broadcast a contract compliance reminder to agents (advisory)."""
        with self._lock:
            for agent_id in targets:
                if agent_id not in self._reminders:
                    self._reminders[agent_id] = []
                self._reminders[agent_id].append({
                    "directive_id": directive.directive_id,
                    "contract_version": directive.contract_version,
                    "issued_at": directive.issued_at,
                    "reason": directive.reason,
                })
        return DirectiveResult(
            directive_id=directive.directive_id,
            agents_affected=targets,
            success=True,
            detail=f"Broadcast reminder to {len(targets)} agent(s)",
        )

    def _handle_tighten(
        self, directive: BehavioralDirective, targets: list[str],
    ) -> DirectiveResult:
        """Temporarily tighten drift thresholds for targeted agents."""
        factor = directive.tighten_factor
        with self._lock:
            for agent_id in targets:
                self._tightened_agents[agent_id] = factor
        return DirectiveResult(
            directive_id=directive.directive_id,
            agents_affected=targets,
            success=True,
            detail=f"Tightened thresholds by factor {factor} on {len(targets)} agent(s)",
        )

    def _handle_relax(
        self, directive: BehavioralDirective, targets: list[str],
    ) -> DirectiveResult:
        """Remove tightening from targeted agents."""
        relaxed = []
        with self._lock:
            for agent_id in targets:
                if agent_id in self._tightened_agents:
                    del self._tightened_agents[agent_id]
                    relaxed.append(agent_id)
        return DirectiveResult(
            directive_id=directive.directive_id,
            agents_affected=relaxed,
            success=True,
            detail=f"Relaxed thresholds on {len(relaxed)} agent(s)",
        )

    def _handle_re_anchor(
        self, directive: BehavioralDirective, targets: list[str],
    ) -> DirectiveResult:
        """Reset semantic anchors for a specified term across targeted agents."""
        term = directive.semantic_term
        if not term:
            return DirectiveResult(
                directive_id=directive.directive_id,
                agents_affected=[],
                success=False,
                detail="No semantic_term specified for re_anchor directive",
            )

        observer = getattr(self._runtime, "_fingerprint_observer", None)
        if observer is None:
            return DirectiveResult(
                directive_id=directive.directive_id,
                agents_affected=[],
                success=False,
                detail="Fingerprint observer not available",
            )

        semantic_observer: SemanticObserver | None = getattr(
            observer, "semantic_observer", None,
        )
        if semantic_observer is None:
            return DirectiveResult(
                directive_id=directive.directive_id,
                agents_affected=[],
                success=False,
                detail="Semantic observer not available",
            )

        re_anchored = []
        for agent_id in targets:
            try:
                # Get current anchors and update the specified term
                existing = semantic_observer.get_anchors(agent_id)
                # Reset the term by setting fresh anchors
                from nomotic.semantic import SemanticAnchor
                updated = [a for a in existing if a.term != term]
                updated.append(SemanticAnchor(
                    term=term,
                    expected_action_distribution={},
                    expected_target_distribution={},
                    tolerance=0.3,
                ))
                semantic_observer.set_anchors(agent_id, updated)
                re_anchored.append(agent_id)
            except Exception:
                continue

        return DirectiveResult(
            directive_id=directive.directive_id,
            agents_affected=re_anchored,
            success=len(re_anchored) > 0,
            detail=f"Re-anchored term '{term}' on {len(re_anchored)} agent(s)",
        )

    # ── Undo Effects ─────────────────────────────────────────────────

    def _undo_directive(self, directive: BehavioralDirective) -> None:
        """Undo the effects of an expired directive. Called under lock."""
        if directive.directive_type == "quarantine":
            # Find which agents were quarantined by this directive
            # We undo all targets since we don't track per-directive quarantines
            targets = self._resolve_targets_unlocked(directive)
            for agent_id in targets:
                self._quarantined.discard(agent_id)

        elif directive.directive_type == "enforce":
            for agent_id, inv_list in self._enforced_invariants.items():
                self._enforced_invariants[agent_id] = [
                    inv for inv in inv_list
                    if inv.get("directive_id") != directive.directive_id
                ]

        elif directive.directive_type == "tighten":
            targets = self._resolve_targets_unlocked(directive)
            for agent_id in targets:
                self._tightened_agents.pop(agent_id, None)

    def _resolve_targets_unlocked(self, directive: BehavioralDirective) -> list[str]:
        """Resolve targets without acquiring the lock (called under lock)."""
        if directive.target_agents:
            return list(directive.target_agents)
        return list(self._get_all_agent_ids())

    # ── Provenance ───────────────────────────────────────────────────

    def _record_provenance(
        self, directive: BehavioralDirective, result: DirectiveResult,
    ) -> None:
        """Record the directive as a provenance event."""
        if self._provenance is None:
            return
        try:
            self._provenance.record(
                actor=directive.issued_by,
                actor_type="operator",
                target_type="directive",
                target_id=directive.directive_id,
                change_type="add",
                new_value=directive.to_dict(),
                reason=directive.reason,
                context_code="CONTROL.DIRECTIVE_ISSUED",
            )
        except Exception:
            pass
