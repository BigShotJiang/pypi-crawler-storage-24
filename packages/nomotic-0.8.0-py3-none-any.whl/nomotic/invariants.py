"""Behavioral invariants — declarative rules for the Behavioral Control Plane.

Invariants express behavioral expectations in terms that compliance teams
can read and governance systems can enforce. They go beyond permissions to
capture patterns, ratios, rates, distributions, and meaning.

Invariant types:
- ratio: Distribution ratio constraints (write-to-read ratio < 0.3)
- distribution: Distribution shape constraints (no single target > 60%)
- drift: Drift threshold constraints (action_drift < 0.20)
- semantic: Meaning constraints (semantic anchor for 'research' > 0.85)
- temporal: Timing constraints (no activity outside hours 8-18)
- rate: Frequency constraints (action rate not > 2x baseline in 1hr window)
- count: Cardinality constraints (no more than 5 distinct targets per session)
"""

from __future__ import annotations

import math
import uuid
from dataclasses import dataclass, field
from typing import Any

from nomotic.drift import DriftScore
from nomotic.fingerprint import BehavioralFingerprint
from nomotic.semantic import SemanticDriftScore
from nomotic.types import Action

__all__ = [
    "VALID_OPERATORS",
    "VALID_TYPES",
    "CompiledInvariants",
    "InvariantBuilder",
    "InvariantResult",
    "InvariantSpec",
]

VALID_TYPES = {"ratio", "distribution", "drift", "semantic", "temporal", "rate", "count"}
VALID_OPERATORS = {"lt", "gt", "lte", "gte", "eq", "between"}


@dataclass(frozen=True)
class InvariantSpec:
    """Declarative specification of a behavioral invariant."""

    invariant_id: str
    type: str
    description: str
    metric: str
    operator: str
    threshold: float
    threshold_upper: float | None = None
    window: int | None = None
    window_seconds: float | None = None

    def to_dict(self) -> dict[str, Any]:
        """Full JSON serialization."""
        d: dict[str, Any] = {
            "invariant_id": self.invariant_id,
            "type": self.type,
            "description": self.description,
            "metric": self.metric,
            "operator": self.operator,
            "threshold": self.threshold,
        }
        if self.threshold_upper is not None:
            d["threshold_upper"] = self.threshold_upper
        if self.window is not None:
            d["window"] = self.window
        if self.window_seconds is not None:
            d["window_seconds"] = self.window_seconds
        return d

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> InvariantSpec:
        """Deserialize from dict."""
        return cls(
            invariant_id=data.get("invariant_id", f"inv-{uuid.uuid4().hex[:8]}"),
            type=data["type"],
            description=data.get("description", ""),
            metric=data["metric"],
            operator=data["operator"],
            threshold=float(data["threshold"]),
            threshold_upper=float(data["threshold_upper"]) if data.get("threshold_upper") is not None else None,
            window=int(data["window"]) if data.get("window") is not None else None,
            window_seconds=float(data["window_seconds"]) if data.get("window_seconds") is not None else None,
        )

    def validate(self) -> list[str]:
        """Return list of validation errors. Empty list = valid."""
        errors: list[str] = []
        if self.type not in VALID_TYPES:
            errors.append(f"Invalid type '{self.type}'. Must be one of {sorted(VALID_TYPES)}.")
        if self.operator not in VALID_OPERATORS:
            errors.append(f"Invalid operator '{self.operator}'. Must be one of {sorted(VALID_OPERATORS)}.")
        if not math.isfinite(self.threshold) or self.threshold < 0:
            errors.append(f"Threshold must be finite and >= 0, got {self.threshold}.")
        if self.operator == "between":
            if self.threshold_upper is None:
                errors.append("Operator 'between' requires threshold_upper to be set.")
            elif self.threshold_upper <= self.threshold:
                errors.append(f"threshold_upper ({self.threshold_upper}) must be > threshold ({self.threshold}).")
        if self.type in ("rate", "count"):
            if self.window is None and self.window_seconds is None:
                errors.append(f"Type '{self.type}' requires window or window_seconds to be set.")
        if not self.metric:
            errors.append("Metric must not be empty.")
        return errors


@dataclass
class InvariantResult:
    """Result of evaluating one invariant."""

    invariant_id: str
    satisfied: bool
    current_value: float
    threshold: float
    margin: float
    status: str
    detail: str = ""

    def to_dict(self) -> dict[str, Any]:
        """Full JSON serialization."""
        return {
            "invariant_id": self.invariant_id,
            "satisfied": self.satisfied,
            "current_value": round(self.current_value, 6),
            "threshold": round(self.threshold, 6),
            "margin": round(self.margin, 4),
            "status": self.status,
            "detail": self.detail,
        }


def _compare(value: float, operator: str, threshold: float, threshold_upper: float | None) -> bool:
    """Apply comparison operator."""
    if operator == "lt":
        return value < threshold
    elif operator == "gt":
        return value > threshold
    elif operator == "lte":
        return value <= threshold
    elif operator == "gte":
        return value >= threshold
    elif operator == "eq":
        return abs(value - threshold) < 0.001
    elif operator == "between":
        return threshold <= value <= (threshold_upper or threshold)
    return False


def _margin(value: float, operator: str, threshold: float, threshold_upper: float | None) -> float:
    """Compute margin — distance from threshold as fraction. Higher = safer."""
    if operator in ("lt", "lte"):
        if threshold > 0:
            m = (threshold - value) / threshold
        else:
            m = 1.0
    elif operator in ("gt", "gte"):
        m = (value - threshold) / max(value, 0.001)
    elif operator == "eq":
        if threshold > 0:
            m = 1.0 - abs(value - threshold) / threshold
        else:
            m = 1.0 if abs(value) < 0.001 else 0.0
    elif operator == "between":
        upper = threshold_upper or threshold
        span = upper - threshold
        if span > 0:
            center = (threshold + upper) / 2.0
            m = 1.0 - abs(value - center) / (span / 2.0)
        else:
            m = 1.0 if abs(value - threshold) < 0.001 else 0.0
    else:
        m = 0.0
    return max(0.0, min(1.0, m))


def _extract_ratio(spec: InvariantSpec, fingerprint: BehavioralFingerprint | None) -> float:
    """Extract a ratio metric from fingerprint action distribution."""
    if fingerprint is None:
        return 0.0
    parts = spec.metric.split("_to_")
    if len(parts) == 2:
        numerator_key = parts[0]
        denominator_key = parts[1]
        num = fingerprint.action_distribution.get(numerator_key, 0.0)
        den = fingerprint.action_distribution.get(denominator_key, 0.0)
        return num / max(den, 0.001)
    return 0.0


def _extract_distribution(spec: InvariantSpec, fingerprint: BehavioralFingerprint | None) -> float:
    """Extract a distribution metric from fingerprint."""
    if fingerprint is None:
        return 0.0
    if spec.metric == "target_max":
        return max(fingerprint.target_distribution.values()) if fingerprint.target_distribution else 0.0
    elif spec.metric == "action_max":
        return max(fingerprint.action_distribution.values()) if fingerprint.action_distribution else 0.0
    elif spec.metric == "target_count":
        return float(len(fingerprint.target_distribution))
    return 0.0


def _extract_drift(spec: InvariantSpec, drift_score: DriftScore | None) -> float:
    """Extract a drift metric."""
    if drift_score is None:
        return 0.0
    mapping = {
        "action": drift_score.action_drift,
        "target": drift_score.target_drift,
        "temporal": drift_score.temporal_drift,
        "outcome": drift_score.outcome_drift,
        "semantic": drift_score.semantic_drift,
        "overall": drift_score.overall,
    }
    return mapping.get(spec.metric, 0.0)


def _extract_semantic(spec: InvariantSpec, semantic_drift: SemanticDriftScore | None) -> float:
    """Extract semantic fidelity for a term. Fidelity = 1.0 - drift."""
    if semantic_drift is None:
        return 1.0
    term_drift = semantic_drift.per_term.get(spec.metric, 0.0)
    return 1.0 - term_drift


def _extract_temporal(spec: InvariantSpec, action_window: list[Action] | None) -> float:
    """Extract temporal metric — fraction of actions outside allowed hours."""
    if not action_window:
        return 0.0
    # Parse allowed hours from metric, e.g. "8-18"
    parts = spec.metric.split("-")
    if len(parts) != 2:
        return 0.0
    try:
        start_hour = int(parts[0])
        end_hour = int(parts[1])
    except ValueError:
        return 0.0

    import datetime

    outside = 0
    for a in action_window:
        hour = datetime.datetime.fromtimestamp(a.timestamp).hour
        if not (start_hour <= hour < end_hour):
            outside += 1
    return outside / len(action_window)


def _extract_count(spec: InvariantSpec, action_window: list[Action] | None) -> float:
    """Extract count metric from action window."""
    if not action_window:
        return 0.0
    window_size = spec.window or len(action_window)
    recent = action_window[-window_size:]
    if spec.metric == "distinct_targets":
        return float(len({a.target for a in recent}))
    elif spec.metric == "distinct_actions":
        return float(len({a.action_type for a in recent}))
    return 0.0


def _extract_rate(spec: InvariantSpec, action_window: list[Action] | None) -> float:
    """Extract rate metric from action window."""
    if not action_window:
        return 0.0
    window_size = spec.window or len(action_window)
    recent = action_window[-window_size:]
    if len(recent) < 2:
        return 0.0
    time_span = recent[-1].timestamp - recent[0].timestamp
    if time_span <= 0:
        return float(len(recent))
    return float(len(recent)) / time_span


class CompiledInvariants:
    """Optimized set of invariants ready for runtime evaluation."""

    def __init__(self, specs: list[InvariantSpec]) -> None:
        self.specs = specs
        self._snapshot_invariants: list[InvariantSpec] = []
        self._semantic_invariants: list[InvariantSpec] = []
        self._temporal_invariants: list[InvariantSpec] = []
        self._windowed_invariants: list[InvariantSpec] = []
        self._last_results: list[InvariantResult] = []

        for spec in specs:
            if spec.type in ("ratio", "distribution", "drift"):
                self._snapshot_invariants.append(spec)
            elif spec.type == "semantic":
                self._semantic_invariants.append(spec)
            elif spec.type == "temporal":
                self._temporal_invariants.append(spec)
            elif spec.type in ("rate", "count"):
                self._windowed_invariants.append(spec)

    @classmethod
    def compile(cls, specs: list[InvariantSpec]) -> CompiledInvariants:
        """Validate and compile invariant specs.

        Raises ValueError if any spec has validation errors.
        """
        all_errors: list[str] = []
        for spec in specs:
            errors = spec.validate()
            if errors:
                for e in errors:
                    all_errors.append(f"[{spec.invariant_id}] {e}")
        if all_errors:
            raise ValueError("Invariant validation failed:\n" + "\n".join(all_errors))
        return cls(specs)

    def evaluate(
        self,
        fingerprint: BehavioralFingerprint | None = None,
        drift_score: DriftScore | None = None,
        semantic_drift: SemanticDriftScore | None = None,
        action_window: list[Action] | None = None,
    ) -> list[InvariantResult]:
        """Evaluate all invariants against current state."""
        results: list[InvariantResult] = []

        for spec in self.specs:
            value = self._extract_value(spec, fingerprint, drift_score, semantic_drift, action_window)
            satisfied = _compare(value, spec.operator, spec.threshold, spec.threshold_upper)
            margin = _margin(value, spec.operator, spec.threshold, spec.threshold_upper)

            if not satisfied:
                status = "violated"
            elif margin < 0.20:
                status = "approaching"
            else:
                status = "satisfied"

            results.append(InvariantResult(
                invariant_id=spec.invariant_id,
                satisfied=satisfied,
                current_value=value,
                threshold=spec.threshold,
                margin=margin,
                status=status,
                detail=f"{spec.description}: value={value:.4f}, threshold={spec.threshold}, operator={spec.operator}",
            ))

        self._last_results = results
        return results

    def _extract_value(
        self,
        spec: InvariantSpec,
        fingerprint: BehavioralFingerprint | None,
        drift_score: DriftScore | None,
        semantic_drift: SemanticDriftScore | None,
        action_window: list[Action] | None,
    ) -> float:
        """Extract the current metric value for a spec."""
        if spec.type == "ratio":
            return _extract_ratio(spec, fingerprint)
        elif spec.type == "distribution":
            return _extract_distribution(spec, fingerprint)
        elif spec.type == "drift":
            return _extract_drift(spec, drift_score)
        elif spec.type == "semantic":
            return _extract_semantic(spec, semantic_drift)
        elif spec.type == "temporal":
            return _extract_temporal(spec, action_window)
        elif spec.type == "count":
            return _extract_count(spec, action_window)
        elif spec.type == "rate":
            return _extract_rate(spec, action_window)
        return 0.0

    def summary(self) -> dict[str, int]:
        """Return counts from last evaluation."""
        results = self._last_results
        return {
            "satisfied": sum(1 for r in results if r.status == "satisfied"),
            "violated": sum(1 for r in results if r.status == "violated"),
            "approaching": sum(1 for r in results if r.status == "approaching"),
        }


class InvariantBuilder:
    """Fluent API for building invariant specs. Generates IDs automatically."""

    @staticmethod
    def ratio(metric: str, operator: str, threshold: float, description: str = "") -> InvariantSpec:
        return InvariantSpec(
            invariant_id=f"inv-{uuid.uuid4().hex[:8]}",
            type="ratio",
            description=description or f"{metric} {operator} {threshold}",
            metric=metric,
            operator=operator,
            threshold=threshold,
        )

    @staticmethod
    def distribution(metric: str, operator: str, threshold: float, description: str = "") -> InvariantSpec:
        return InvariantSpec(
            invariant_id=f"inv-{uuid.uuid4().hex[:8]}",
            type="distribution",
            description=description or f"{metric} {operator} {threshold}",
            metric=metric,
            operator=operator,
            threshold=threshold,
        )

    @staticmethod
    def drift(distribution: str, operator: str, threshold: float, description: str = "") -> InvariantSpec:
        return InvariantSpec(
            invariant_id=f"inv-{uuid.uuid4().hex[:8]}",
            type="drift",
            description=description or f"{distribution}_drift {operator} {threshold}",
            metric=distribution,
            operator=operator,
            threshold=threshold,
        )

    @staticmethod
    def semantic(term: str, operator: str, threshold: float, description: str = "") -> InvariantSpec:
        """Semantic invariant. Threshold is FIDELITY (not drift).

        Example: InvariantBuilder.semantic("research", "gt", 0.85)
        means "fidelity for 'research' must be > 0.85".
        """
        return InvariantSpec(
            invariant_id=f"inv-{uuid.uuid4().hex[:8]}",
            type="semantic",
            description=description or f"semantic fidelity for '{term}' {operator} {threshold}",
            metric=term,
            operator=operator,
            threshold=threshold,
        )

    @staticmethod
    def temporal(allowed_hours: str, description: str = "") -> InvariantSpec:
        """Temporal invariant. allowed_hours format: "8-18" for business hours."""
        return InvariantSpec(
            invariant_id=f"inv-{uuid.uuid4().hex[:8]}",
            type="temporal",
            description=description or f"activity only during hours {allowed_hours}",
            metric=allowed_hours,
            operator="eq",
            threshold=0.0,
        )

    @staticmethod
    def rate(metric: str, operator: str, threshold: float, window: int, description: str = "") -> InvariantSpec:
        return InvariantSpec(
            invariant_id=f"inv-{uuid.uuid4().hex[:8]}",
            type="rate",
            description=description or f"{metric} {operator} {threshold} over {window} actions",
            metric=metric,
            operator=operator,
            threshold=threshold,
            window=window,
        )

    @staticmethod
    def count(metric: str, operator: str, threshold: float, window: int, description: str = "") -> InvariantSpec:
        return InvariantSpec(
            invariant_id=f"inv-{uuid.uuid4().hex[:8]}",
            type="count",
            description=description or f"{metric} {operator} {threshold} in {window} actions",
            metric=metric,
            operator=operator,
            threshold=threshold,
            window=window,
        )
