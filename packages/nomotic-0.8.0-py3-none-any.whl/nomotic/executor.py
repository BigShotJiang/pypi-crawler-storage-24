"""GovernedToolExecutor — governance wrapper for local tool execution.

The integration point between any AI agent and Nomotic governance.
Wraps local function calls in pre-execution governance evaluation.

Usage:
    from nomotic import Nomotic

    agent = Nomotic.connect("my-agent")

    result = agent.execute(
        action="query_db",
        target="customers",
        tool_fn=lambda: db.execute("SELECT * FROM customers"),
    )

    if result.allowed:
        print(result.data)    # tool output
    else:
        print(result.reason)  # denial explanation

Also available as ``GovernedToolExecutor`` for backward compatibility.
"""

from __future__ import annotations

import json
import threading
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from nomotic.audit_store import LogStore, PersistentLogRecord
from nomotic.cost import CostTracker
from nomotic.certificate import AgentCertificate
from nomotic.keys import VerifyKey
from nomotic.runtime import GovernanceRuntime
from nomotic.sandbox import (
    AgentConfig,
    build_sandbox_runtime,
    find_agent_cert_id,
    load_agent_config,
)
from nomotic.loop_detector import LoopDetector, LoopDetectorConfig
from nomotic.seal import GovernanceSeal, SealRegistry
from nomotic.store import FileCertificateStore
from nomotic.types import Action, AgentContext

__all__ = [
    "ExecutionResult",
    "GovernedToolExecutor",
    "Nomotic",
]


@dataclass
class ExecutionResult:
    """Result of a governed tool execution."""

    allowed: bool
    verdict: str  # "ALLOW", "DENY", "ESCALATE"
    reason: str  # human-readable explanation
    data: Any  # tool return value (None if denied)
    ucs: float  # unified compliance score
    tier: int  # evaluation tier (1=veto, 2=threshold, 3=full)
    trust_before: float  # trust score before this action
    trust_after: float  # trust score after this action
    trust_delta: float  # change in trust
    dimension_scores: dict[str, float]  # per-dimension scores
    vetoed_by: list[str]  # dimensions that vetoed (empty if allowed)
    action_id: str  # unique ID for this evaluation
    duration_ms: float  # evaluation time in milliseconds
    estimated_cost: float = 0.0  # projected cost for this execution
    cost_alerts: list[dict[str, Any]] = field(default_factory=list)
    loop_detected: bool = False  # whether a loop warning was triggered
    loop_count: int = 0  # repetition count when loop was detected

    def to_dict(self) -> dict[str, Any]:
        return {
            "allowed": self.allowed,
            "verdict": self.verdict,
            "reason": self.reason,
            "ucs": self.ucs,
            "tier": self.tier,
            "trust_before": self.trust_before,
            "trust_after": self.trust_after,
            "trust_delta": self.trust_delta,
            "dimension_scores": self.dimension_scores,
            "vetoed_by": self.vetoed_by,
            "action_id": self.action_id,
            "duration_ms": self.duration_ms,
            "estimated_cost": self.estimated_cost,
            "cost_alerts": self.cost_alerts,
            "loop_detected": self.loop_detected,
            "loop_count": self.loop_count,
        }


class _LoopVerdictName:
    """Minimal adapter to satisfy _write_log_record's verdict.verdict.name access."""

    def __init__(self, name: str):
        self.name = name


class _LoopVerdict:
    """Minimal verdict-like object for writing loop detection audit records."""

    def __init__(self, loop_event: Any):
        level = loop_event.level
        self.verdict = _LoopVerdictName(
            "LOOP_HALT" if level == "halt" else "LOOP_WARNING"
        )
        self.ucs = 0.0
        self.tier = 0
        self.dimension_scores = []
        self.vetoed_by = ["loop_detector"]
        self.reasoning = (
            f"Loop detected: {loop_event.action_type} on '{loop_event.target}' "
            f"repeated {loop_event.count} times in {loop_event.window_seconds}s window"
        )


class GovernedToolExecutor:
    """Governance wrapper for local tool execution.

    Connects to an agent's Nomotic identity (certificate, scope, trust)
    and evaluates every tool call through the 14-dimension governance pipeline
    before execution.
    """

    def __init__(
        self,
        agent_id: str,
        base_dir: Path | None = None,
        test_mode: bool = False,
        require_seal: bool = False,
    ):
        """
        Args:
            agent_id: Agent name, numeric ID, or certificate ID
            base_dir: Nomotic config directory (default ~/.nomotic)
            test_mode: If True, writes to testlog and uses simulated trust
            require_seal: If True, execute() requires a valid GovernanceSeal
        """
        self._base_dir = base_dir or Path.home() / ".nomotic"
        self._test_mode = test_mode
        self._agent_id = agent_id
        self._require_seal = require_seal

        # Resolve agent identity
        self._cert = self._load_certificate(agent_id)
        self._config = self._load_config(agent_id)

        # Build governance runtime
        self._runtime = self._build_runtime()

        # Connect to persistent log store
        log_type = "testlog" if test_mode else "audit"
        self._log_store = LogStore(self._base_dir, log_type)

        # Seal registry for tracking consumed seals
        self._seal_registry = SealRegistry()

        # Cost projection tracker
        self._cost_tracker = CostTracker(self._base_dir)

        # Track simulated trust separately in test mode
        if test_mode:
            self._simulated_trust = self._load_simulated_trust()

        # Action counter for behavioral fingerprinting
        self._action_count = 0

        # Loop detection monitor
        self._loop_detector = LoopDetector()

    @classmethod
    def connect(cls, agent_id: str, **kwargs: Any) -> GovernedToolExecutor:
        """Connect to an agent's governance identity.

        Convenience constructor — the primary way to create an executor.

        Usage:
            executor = GovernedToolExecutor.connect("claims-bot")
            executor = GovernedToolExecutor.connect("claims-bot", test_mode=True)
        """
        return cls(agent_id, **kwargs)

    def execute(
        self,
        action: str,
        target: str = "",
        params: dict[str, Any] | None = None,
        tool_fn: Callable[..., Any] | None = None,
        seal: GovernanceSeal | None = None,
        *,
        timeout: float | None = None,
    ) -> ExecutionResult:
        """Evaluate governance and conditionally execute a tool.

        1. Evaluates the action through the 14-dimension governance pipeline
        2. If ALLOW: executes tool_fn and returns the result
        3. If DENY: skips execution and returns denial reason
        4. Updates trust score (production or simulated)
        5. Writes to persistent log (audit or testlog)

        If a seal is provided, the seal is validated and used as authorization
        (skipping governance re-evaluation). If require_seal is True and no
        seal is provided, returns a denied result with reason "SEAL_REQUIRED".

        Args:
            action: The action type (e.g., "read_file", "query_db", "send_email")
            target: The target resource (e.g., "payroll.csv", "customers")
            params: Optional parameters (e.g., {"sql": "SELECT * ..."})
            tool_fn: Callable to execute if governance approves. If None, evaluation only.
            seal: Optional GovernanceSeal for pre-authorized execution.
            timeout: Optional execution timeout in seconds.

        Returns:
            ExecutionResult with verdict, trust changes, and tool output (if allowed)
        """
        # If require_seal is set and no seal provided, deny
        if self._require_seal and seal is None:
            return self._denied_result(action, "SEAL_REQUIRED")

        # If seal is provided, use sealed execution path
        if seal is not None:
            return self.execute_sealed(
                action=action,
                target=target,
                params=params,
                tool_fn=tool_fn,
                seal=seal,
                timeout=timeout,
            )

        params = params or {}

        # Phase 0: Loop detection — check for repetitive action patterns
        loop_action = Action(
            agent_id=self._agent_id,
            action_type=action,
            target=target,
            parameters=params,
        )
        loop_event = self._loop_detector.record_action(loop_action)
        if loop_event:
            trust_profile = self._runtime.get_trust_profile(self._agent_id)
            trust_profile.overall_trust = self._get_current_trust()

            # Write audit record for loop detection
            self._write_log_record(
                action=action,
                target=target,
                params={},
                verdict=_LoopVerdict(loop_event),
                trust_before=trust_profile.overall_trust,
                trust_after=trust_profile.overall_trust,
                trust_delta=0.0,
            )

            if loop_event.level == "halt":
                # Return a denied result — agent is in a doom loop
                trust = self._get_current_trust()
                return ExecutionResult(
                    allowed=False,
                    verdict="DENY",
                    reason=(
                        f"Loop detected: {action} on '{target}' "
                        f"repeated {loop_event.count} times — agent halted"
                    ),
                    data=None,
                    ucs=0.0,
                    tier=0,
                    trust_before=trust,
                    trust_after=trust,
                    trust_delta=0.0,
                    dimension_scores={},
                    vetoed_by=["loop_detector"],
                    action_id=loop_action.id,
                    duration_ms=0.0,
                    loop_detected=True,
                    loop_count=loop_event.count,
                )
            elif loop_event.level == "warning":
                # Apply trust decay — the agent is showing repetitive behavior
                # But allow the action to proceed through governance evaluation
                trust_profile.overall_trust = max(
                    0.0,
                    trust_profile.overall_trust
                    - self._loop_detector._config.trust_decay_per_warning,
                )
                self._update_trust(trust_profile.overall_trust)

        # Phase 1: Governance evaluation
        check_result = self.check(action, target, params)

        # Annotate with loop info if a warning was detected
        if loop_event and loop_event.level == "warning":
            check_result = ExecutionResult(
                allowed=check_result.allowed,
                verdict=check_result.verdict,
                reason=check_result.reason,
                data=check_result.data,
                ucs=check_result.ucs,
                tier=check_result.tier,
                trust_before=check_result.trust_before,
                trust_after=check_result.trust_after,
                trust_delta=check_result.trust_delta,
                dimension_scores=check_result.dimension_scores,
                vetoed_by=check_result.vetoed_by,
                action_id=check_result.action_id,
                duration_ms=check_result.duration_ms,
                loop_detected=True,
                loop_count=loop_event.count,
            )

        if not check_result.allowed:
            self._write_denial_record(action, target, check_result)
            return check_result

        # Phase 2: Tool execution
        tool_output = None
        if tool_fn is not None:
            try:
                if timeout:
                    tool_output = self._execute_with_timeout(tool_fn, timeout)
                else:
                    tool_output = tool_fn()
            except Exception as e:
                tool_output = f"EXECUTION ERROR: {e}"

        # Phase 3: Finalize (trust update + audit + action count)
        return self._finalize_execution(action, target, check_result, tool_output)

    def execute_sealed(
        self,
        action: str,
        target: str = "",
        params: dict[str, Any] | None = None,
        tool_fn: Callable[..., Any] | None = None,
        seal: GovernanceSeal | None = None,
        *,
        timeout: float | None = None,
    ) -> ExecutionResult:
        """Execute a tool using a pre-authorized GovernanceSeal.

        The seal IS the authorization — no governance re-evaluation occurs.
        The seal must be valid (correct signature, not expired, not consumed,
        correct agent_id).

        Args:
            action: The action type.
            target: The target resource.
            params: Optional parameters.
            tool_fn: Callable to execute if seal validates.
            seal: The GovernanceSeal (required for this method).
            timeout: Optional execution timeout in seconds.

        Returns:
            ExecutionResult with verdict, trust changes, and tool output.
        """
        if seal is None:
            return self._denied_result(action, "SEAL_REQUIRED")

        # Validate seal: check agent_id matches
        if seal.agent_id != self._agent_id:
            return self._denied_result(action, "AGENT_MISMATCH")

        # Validate seal: check signature and expiration
        verify_key = self._get_verify_key()
        if verify_key is None:
            return self._denied_result(action, "INVALID_SEAL")

        if seal.is_expired():
            return self._denied_result(action, "EXPIRED_SEAL")

        if not verify_key.verify(seal.signature, seal.canonical_bytes()):
            return self._denied_result(action, "INVALID_SEAL")

        # Validate seal: check not consumed (single-use)
        if not self._seal_registry.consume(seal.seal_id):
            return self._denied_result(action, "REUSED_SEAL")

        # Seal is valid — execute the tool
        trust_before = self._get_current_trust()

        tool_output = None
        if tool_fn is not None:
            try:
                if timeout:
                    tool_output = self._execute_with_timeout(tool_fn, timeout)
                else:
                    tool_output = tool_fn()
            except Exception as e:
                tool_output = f"EXECUTION ERROR: {e}"

        trust_after = trust_before  # No trust change from sealed execution

        sealed_result = ExecutionResult(
            allowed=True,
            verdict="ALLOW",
            reason="Authorized by governance seal",
            data=None,
            ucs=seal.ucs,
            tier=seal.tier,
            trust_before=trust_before,
            trust_after=trust_after,
            trust_delta=0.0,
            dimension_scores=dict(seal.dimension_summary),
            vetoed_by=[],
            action_id=seal.action_id,
            duration_ms=0.0,
        )

        # Finalize: write audit record with seal_id
        self._update_trust(trust_after)
        self._write_log_record_from_result(action, target, sealed_result, seal_id=seal.seal_id)
        self._action_count += 1

        return ExecutionResult(
            allowed=True,
            verdict="ALLOW",
            reason="Authorized by governance seal",
            data=tool_output,
            ucs=seal.ucs,
            tier=seal.tier,
            trust_before=trust_before,
            trust_after=trust_after,
            trust_delta=0.0,
            dimension_scores=dict(seal.dimension_summary),
            vetoed_by=[],
            action_id=seal.action_id,
            duration_ms=0.0,
        )

    def _denied_result(self, action: str, reason: str) -> ExecutionResult:
        """Create a denied ExecutionResult with a specific reason."""
        trust = self._get_current_trust()
        return ExecutionResult(
            allowed=False,
            verdict="DENY",
            reason=reason,
            data=None,
            ucs=0.0,
            tier=0,
            trust_before=trust,
            trust_after=trust,
            trust_delta=0.0,
            dimension_scores={},
            vetoed_by=[],
            action_id="",
            duration_ms=0.0,
        )

    def _get_verify_key(self) -> VerifyKey | None:
        """Get the verify key for seal validation.

        Uses the certificate's public key or the runtime's CA verify key.
        """
        if self._cert is not None and self._cert.public_key:
            # The seal is signed by the CA's issuer key, not the agent's key.
            # We need the CA's verify key from the runtime.
            pass
        # Get the verify key from the runtime's CA
        ca = self._runtime._ensure_ca()
        return ca._verify_key

    def check(
        self,
        action: str,
        target: str = "",
        params: dict[str, Any] | None = None,
        *,
        metadata: dict[str, Any] | None = None,
    ) -> ExecutionResult:
        """Evaluate governance for an action WITHOUT executing it.

        Returns an ExecutionResult with allowed/denied verdict but data=None.
        Does not write audit records or update trust — call
        ``_finalize_execution`` or ``_write_denial_record`` for that.

        Useful for: pre-flight checks, async execution split, UI previews.
        """
        params = params or metadata or {}
        start_time = time.monotonic()

        action_obj = Action(
            agent_id=self._agent_id,
            action_type=action,
            target=target,
            parameters=params,
        )

        trust_before = self._get_current_trust()
        trust_profile = self._runtime.get_trust_profile(self._agent_id)
        trust_profile.overall_trust = trust_before
        ctx = AgentContext(agent_id=self._agent_id, trust_profile=trust_profile)

        verdict = self._runtime.evaluate(action_obj, ctx)

        trust_after = self._runtime.get_trust_profile(self._agent_id).overall_trust
        trust_delta = trust_after - trust_before
        trust_after = round(max(0.0, min(1.0, trust_after)), 3)

        duration_ms = (time.monotonic() - start_time) * 1000

        dim_scores: dict[str, float] = {}
        vetoed_by: list[str] = []
        if verdict.dimension_scores:
            for ds in verdict.dimension_scores:
                dim_scores[ds.dimension_name] = ds.score
        if verdict.vetoed_by:
            vetoed_by = list(verdict.vetoed_by)

        return ExecutionResult(
            allowed=verdict.verdict.name == "ALLOW",
            verdict=verdict.verdict.name,
            reason=verdict.reasoning or "",
            data=None,
            ucs=verdict.ucs,
            tier=verdict.tier,
            trust_before=trust_before,
            trust_after=trust_after,
            trust_delta=trust_delta,
            dimension_scores=dim_scores,
            vetoed_by=vetoed_by,
            action_id=verdict.action_id,
            duration_ms=round(duration_ms, 2),
        )

    @property
    def trust(self) -> float:
        """Current trust score (simulated in test mode, production otherwise)."""
        return self._get_current_trust()

    @property
    def agent_id(self) -> str:
        return self._agent_id

    @property
    def certificate_id(self) -> str:
        return self._cert.certificate_id if self._cert else ""

    @property
    def action_count(self) -> int:
        return self._action_count

    @property
    def is_test_mode(self) -> bool:
        return self._test_mode

    def configure_loop_detection(self, config: LoopDetectorConfig) -> None:
        """Configure loop detection thresholds."""
        self._loop_detector = LoopDetector(config)

    def get_audit_summary(self) -> dict[str, Any]:
        """Get summary of this agent's log (audit or testlog)."""
        return self._log_store.summary(self._agent_id)

    def verify_chain(self) -> tuple[bool, int, str]:
        """Verify the integrity of this agent's log chain."""
        return self._log_store.verify_chain(self._agent_id)

    # ── Internal methods ──────────────────────────────────────────────

    def _load_certificate(self, agent_id: str) -> AgentCertificate | None:
        """Find and load the agent's certificate from disk.

        Uses the same case-insensitive resolution as sandbox.py's
        find_agent_cert_id().
        """
        cert_id = find_agent_cert_id(self._base_dir, agent_id)
        if cert_id is None:
            return None
        store = FileCertificateStore(self._base_dir)
        return store.get(cert_id)

    def _load_config(self, agent_id: str) -> AgentConfig:
        """Load agent governance config, or create a default."""
        config = load_agent_config(self._base_dir, agent_id)
        if config is None:
            config = AgentConfig(agent_id=agent_id)
        return config

    def _build_runtime(self) -> GovernanceRuntime:
        """Build governance runtime from agent config using shared builder."""
        return build_sandbox_runtime(
            agent_config=self._config,
            agent_id=self._agent_id,
            base_dir=self._base_dir,
        )

    def _get_current_trust(self) -> float:
        """Return current trust score.

        In test mode: return simulated trust.
        In production: return certificate trust or runtime trust profile.
        """
        if self._test_mode:
            return self._simulated_trust
        if self._cert is not None:
            return self._cert.trust_score
        return self._runtime.get_trust_profile(self._agent_id).overall_trust

    def _update_trust(self, new_trust: float) -> None:
        """Persist the updated trust score.

        In test mode: update simulated trust only.
        In production: update the certificate on disk.
        """
        if self._test_mode:
            self._simulated_trust = new_trust
            self._save_simulated_trust(new_trust)
        elif self._cert is not None:
            self._cert.trust_score = new_trust
            store = FileCertificateStore(self._base_dir)
            store.save(self._cert)

    def _load_simulated_trust(self) -> float:
        """Load simulated trust from testlog directory, or fall back to cert/default."""
        production_trust = self._cert.trust_score if self._cert else 0.5
        trust_file = (
            self._base_dir / "testlog" / f"{self._agent_id.lower()}.trust.json"
        )
        if trust_file.exists():
            try:
                data = json.loads(trust_file.read_text(encoding="utf-8"))
                age = time.time() - data.get("last_updated", 0)
                if age < 3600:  # 1 hour
                    return data.get("simulated_trust", production_trust)
            except (json.JSONDecodeError, KeyError):
                pass
        return production_trust

    def _save_simulated_trust(self, simulated: float) -> None:
        """Persist simulated trust to testlog directory."""
        production_trust = self._cert.trust_score if self._cert else 0.5
        testlog_dir = self._base_dir / "testlog"
        testlog_dir.mkdir(parents=True, exist_ok=True)
        trust_file = testlog_dir / f"{self._agent_id.lower()}.trust.json"
        trust_file.write_text(
            json.dumps(
                {
                    "simulated_trust": simulated,
                    "production_trust_at_start": production_trust,
                    "last_updated": time.time(),
                },
                indent=2,
            ),
            encoding="utf-8",
        )

    def _write_denial_record(
        self,
        action: str,
        target: str,
        check_result: ExecutionResult,
        seal_id: str = "",
    ) -> None:
        """Write audit record for a denied action and update trust."""
        self._update_trust(check_result.trust_after)
        self._write_log_record_from_result(action, target, check_result, seal_id=seal_id)
        self._action_count += 1

    def _write_error_record(
        self,
        action: str,
        target: str,
        check_result: ExecutionResult,
        exc: Exception,
        seal_id: str = "",
    ) -> None:
        """Write audit record for an execution error and update trust."""
        self._update_trust(check_result.trust_after)
        self._write_log_record_from_result(action, target, check_result, seal_id=seal_id)
        self._action_count += 1

    def _finalize_execution(
        self,
        action: str,
        target: str,
        check_result: ExecutionResult,
        data: Any,
        seal_id: str = "",
    ) -> ExecutionResult:
        """Post-execution: update trust, write audit record, return final result."""
        self._update_trust(check_result.trust_after)

        # Record cost projection based on execution duration
        estimated_cost = self._cost_tracker.record_execution(
            self._agent_id, check_result.duration_ms
        )
        cost_alerts = self._cost_tracker.get_profile(self._agent_id).check_advisories()

        self._write_log_record_from_result(
            action, target, check_result, seal_id=seal_id,
            estimated_cost=estimated_cost,
        )
        self._action_count += 1

        return ExecutionResult(
            allowed=check_result.allowed,
            verdict=check_result.verdict,
            reason=check_result.reason,
            data=data,
            ucs=check_result.ucs,
            tier=check_result.tier,
            trust_before=check_result.trust_before,
            trust_after=check_result.trust_after,
            trust_delta=check_result.trust_delta,
            dimension_scores=check_result.dimension_scores,
            vetoed_by=check_result.vetoed_by,
            action_id=check_result.action_id,
            duration_ms=check_result.duration_ms,
            estimated_cost=estimated_cost,
            cost_alerts=cost_alerts,
            loop_detected=check_result.loop_detected,
            loop_count=check_result.loop_count,
        )

    def _write_log_record_from_result(
        self,
        action: str,
        target: str,
        result: ExecutionResult,
        seal_id: str = "",
        estimated_cost: float = 0.0,
    ) -> None:
        """Write a PersistentLogRecord using ExecutionResult fields."""
        if result.trust_delta > 0.001:
            trend = "rising"
        elif result.trust_delta < -0.001:
            trend = "falling"
        else:
            trend = "stable"

        if result.verdict == "DENY":
            severity = "alert"
        elif result.verdict == "ESCALATE":
            severity = "warning"
        else:
            severity = "info"

        source = "executor-test" if self._test_mode else "executor"

        record_data: dict[str, Any] = {
            "record_id": uuid.uuid4().hex[:12],
            "timestamp": time.time(),
            "agent_id": self._agent_id,
            "action_type": action,
            "action_target": target,
            "verdict": result.verdict,
            "ucs": result.ucs,
            "tier": result.tier,
            "trust_score": result.trust_after,
            "trust_delta": result.trust_delta,
            "trust_trend": trend,
            "severity": severity,
            "justification": result.reason,
            "vetoed_by": list(result.vetoed_by),
            "dimension_scores": dict(result.dimension_scores),
            "parameters": {},
            "source": source,
            "estimated_cost": estimated_cost,
            "previous_hash": "",
            "record_hash": "",
        }
        if seal_id:
            record_data["seal_id"] = seal_id

        previous_hash = self._log_store.get_last_hash(self._agent_id)
        record_data["previous_hash"] = previous_hash
        record_data["record_hash"] = self._log_store.compute_hash(
            record_data, previous_hash
        )

        record = PersistentLogRecord(**record_data)
        self._log_store.append(record)

    def _write_log_record(
        self,
        action: str,
        target: str,
        params: dict[str, Any],
        verdict: Any,
        trust_before: float,
        trust_after: float,
        trust_delta: float,
    ) -> None:
        """Create a PersistentLogRecord with hash chain linking and append."""
        # Determine trend
        if trust_delta > 0.001:
            trend = "rising"
        elif trust_delta < -0.001:
            trend = "falling"
        else:
            trend = "stable"

        # Determine severity
        if verdict.verdict.name == "DENY":
            severity = "alert"
        elif verdict.verdict.name == "ESCALATE":
            severity = "warning"
        else:
            severity = "info"

        # Build dimension scores dict for the record
        dim_scores: dict[str, float] = {}
        if verdict.dimension_scores:
            for ds in verdict.dimension_scores:
                dim_scores[ds.dimension_name] = ds.score

        vetoed_by = list(verdict.vetoed_by) if verdict.vetoed_by else []

        source = "executor-test" if self._test_mode else "executor"

        record_data = {
            "record_id": uuid.uuid4().hex[:12],
            "timestamp": time.time(),
            "agent_id": self._agent_id,
            "action_type": action,
            "action_target": target,
            "verdict": verdict.verdict.name,
            "ucs": verdict.ucs,
            "tier": verdict.tier,
            "trust_score": trust_after,
            "trust_delta": trust_delta,
            "trust_trend": trend,
            "severity": severity,
            "justification": verdict.reasoning or "",
            "vetoed_by": vetoed_by,
            "dimension_scores": dim_scores,
            "parameters": params,
            "source": source,
            "previous_hash": "",
            "record_hash": "",
        }

        # Hash chain linking
        previous_hash = self._log_store.get_last_hash(self._agent_id)
        record_data["previous_hash"] = previous_hash
        record_data["record_hash"] = self._log_store.compute_hash(
            record_data, previous_hash
        )

        record = PersistentLogRecord(**record_data)
        self._log_store.append(record)

    def _execute_with_timeout(self, fn: Callable[..., Any], timeout: float) -> Any:
        """Run a callable with a timeout using threading."""
        result: list[Any] = []
        exception: list[BaseException] = []

        def _target() -> None:
            try:
                result.append(fn())
            except BaseException as e:
                exception.append(e)

        thread = threading.Thread(target=_target)
        thread.start()
        thread.join(timeout=timeout)

        if thread.is_alive():
            raise TimeoutError(
                f"Tool execution exceeded {timeout}s timeout"
            )
        if exception:
            raise exception[0]
        return result[0] if result else None


# Public alias — branded entry point for the developer-facing API.
Nomotic = GovernedToolExecutor
