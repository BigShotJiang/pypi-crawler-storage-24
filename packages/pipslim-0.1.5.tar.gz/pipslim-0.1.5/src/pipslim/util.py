
import sys
import subprocess
import json

def in_venv():
    # Check for sys.real_prefix for older virtualenv compatibility
    if hasattr(sys, 'real_prefix'):
        return True
    

def list_packages() -> list[dict]:
    """
    fetch a list of packages and their installed version.
    """
    # pip list --format json
    result = subprocess.run(['pip', 'list', '--format', 'json'], capture_output=True, text=True)
    return json.loads(result.stdout)


def list_package_dependencies(package:str=None) -> list[dict]:
    """
    returns a list of higher-order packages that depend on this package.
    """
    result = subprocess.run(['pip', 'show', package], capture_output=True, text=True).stdout
    for line in result.split('\n'):
        if line.startswith('Required-by:'):
            line = line.replace(' ', '')
            line = line.replace('Required-by:', '')
            deps = list(filter(lambda dep: dep != '', line.split(',')))
            return deps
    return []            