import pipslim

def run():
    """
    Program entry point
    """
    for package in pipslim.util.list_packages():
        if len(pipslim.list_package_dependencies(package['name'])) == 0:
            print(f"{package['name']}=={package['version']}")

if __name__ == '__main__':
    run()