# pipslim
Lightweight Python package used for generating requirements.txt files containing only the "top level" dependencies.
