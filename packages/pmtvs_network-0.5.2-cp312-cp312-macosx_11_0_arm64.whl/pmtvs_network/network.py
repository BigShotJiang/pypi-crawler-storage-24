"""
Network Analysis Functions
"""

import numpy as np
from typing import List

import pmtvs_network._rust as _rust


def degree_centrality(adjacency: np.ndarray) -> np.ndarray:
    """
    Compute degree centrality for each node.

    Parameters
    ----------
    adjacency : np.ndarray
        Adjacency matrix (binary or weighted)

    Returns
    -------
    np.ndarray
        Degree centrality values (normalized)
    """
    adjacency = np.ascontiguousarray(np.asarray(adjacency, dtype=np.float64))
    if adjacency.ndim < 2:
        return np.array([np.nan])
    return np.asarray(_rust.degree_centrality(adjacency))


def betweenness_centrality(adjacency: np.ndarray) -> np.ndarray:
    """
    Compute betweenness centrality using Brandes' algorithm.

    Parameters
    ----------
    adjacency : np.ndarray
        Adjacency matrix

    Returns
    -------
    np.ndarray
        Betweenness centrality values
    """
    adjacency = np.ascontiguousarray(np.asarray(adjacency, dtype=np.float64))
    if adjacency.ndim < 2:
        return np.array([np.nan])
    return np.asarray(_rust.betweenness_centrality(adjacency))


def closeness_centrality(adjacency: np.ndarray) -> np.ndarray:
    """
    Compute closeness centrality.

    Parameters
    ----------
    adjacency : np.ndarray
        Adjacency matrix

    Returns
    -------
    np.ndarray
        Closeness centrality values
    """
    adjacency = np.ascontiguousarray(np.asarray(adjacency, dtype=np.float64))
    if adjacency.ndim < 2:
        return np.array([np.nan])
    return np.asarray(_rust.closeness_centrality(adjacency))


def eigenvector_centrality(
    adjacency: np.ndarray,
    max_iter: int = 100,
    tol: float = 1e-6
) -> np.ndarray:
    """
    Compute eigenvector centrality.

    Parameters
    ----------
    adjacency : np.ndarray
        Adjacency matrix
    max_iter : int
        Maximum power iterations
    tol : float
        Convergence tolerance

    Returns
    -------
    np.ndarray
        Eigenvector centrality values
    """
    adjacency = np.ascontiguousarray(np.asarray(adjacency, dtype=np.float64))
    if adjacency.ndim < 2:
        return np.array([np.nan])
    return np.asarray(_rust.eigenvector_centrality(adjacency, max_iter, tol))


def clustering_coefficient(adjacency: np.ndarray) -> np.ndarray:
    """
    Compute local clustering coefficient for each node.

    Parameters
    ----------
    adjacency : np.ndarray
        Adjacency matrix

    Returns
    -------
    np.ndarray
        Clustering coefficients
    """
    adjacency = np.ascontiguousarray(np.asarray(adjacency, dtype=np.float64))
    if adjacency.ndim < 2:
        return np.array([np.nan])
    return np.asarray(_rust.clustering_coefficient(adjacency))


def average_path_length(adjacency: np.ndarray) -> float:
    """
    Compute average shortest path length.

    Parameters
    ----------
    adjacency : np.ndarray
        Adjacency matrix

    Returns
    -------
    float
        Average path length (inf if disconnected)
    """
    adjacency = np.ascontiguousarray(np.asarray(adjacency, dtype=np.float64))
    if adjacency.ndim < 2:
        return np.nan
    return float(_rust.average_path_length(adjacency))


def density(adjacency: np.ndarray) -> float:
    """
    Compute graph density.

    Parameters
    ----------
    adjacency : np.ndarray
        Adjacency matrix

    Returns
    -------
    float
        Density in [0, 1]
    """
    adjacency = np.ascontiguousarray(np.asarray(adjacency, dtype=np.float64))
    return float(_rust.density(adjacency))


def connected_components(adjacency: np.ndarray) -> List[List[int]]:
    """
    Find connected components.

    Parameters
    ----------
    adjacency : np.ndarray
        Adjacency matrix

    Returns
    -------
    list
        List of components (each is list of node indices)
    """
    adjacency = np.ascontiguousarray(np.asarray(adjacency, dtype=np.float64))
    if adjacency.ndim < 2:
        return []
    return _rust.connected_components(adjacency)


def adjacency_from_correlation(
    correlation_matrix: np.ndarray,
    threshold: float = 0.5
) -> np.ndarray:
    """
    Create adjacency matrix from correlation matrix.

    Parameters
    ----------
    correlation_matrix : np.ndarray
        Correlation matrix
    threshold : float
        Minimum absolute correlation for an edge

    Returns
    -------
    np.ndarray
        Binary adjacency matrix
    """
    corr = np.ascontiguousarray(np.asarray(correlation_matrix, dtype=np.float64))
    if corr.ndim < 2:
        return np.array([])
    return np.asarray(_rust.adjacency_from_correlation(corr, threshold))
