"""
pmtvs-network — Network analysis primitives.
"""

__version__ = "0.5.1"
BACKEND = "rust"

try:
    import pmtvs_network._rust  # noqa: F401 — validates Rust extension is loadable
except ImportError as e:
    raise ImportError(
        f"\n\nRust extension not found: {e}\n"
        f"The pmtvs framework requires compiled Rust extensions.\n"
        f"Install with: cd packages/pmtvs-network && maturin develop --release\n"
        f"Or rebuild the Docker image.\n"
    ) from e

from pmtvs_network.network import (
    degree_centrality,
    betweenness_centrality,
    closeness_centrality,
    eigenvector_centrality,
    clustering_coefficient,
    average_path_length,
    density,
    connected_components,
    adjacency_from_correlation,
)

from pmtvs_network.community import (
    modularity,
    community_detection,
)

__all__ = [
    "__version__",
    "BACKEND",
    "degree_centrality",
    "betweenness_centrality",
    "closeness_centrality",
    "eigenvector_centrality",
    "clustering_coefficient",
    "average_path_length",
    "density",
    "connected_components",
    "adjacency_from_correlation",
    "modularity",
    "community_detection",
]
