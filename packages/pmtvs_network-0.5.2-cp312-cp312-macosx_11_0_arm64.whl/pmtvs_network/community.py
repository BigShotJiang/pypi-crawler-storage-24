"""
Community Detection Primitives

Modularity scoring and community detection algorithms for network analysis.
"""

import numpy as np
from typing import Tuple, Optional

import pmtvs_network._rust as _rust


def modularity(
    adjacency: np.ndarray,
    communities: np.ndarray,
    resolution: float = 1.0
) -> float:
    """
    Compute modularity of a community partition.

    Parameters
    ----------
    adjacency : np.ndarray
        Adjacency matrix (n x n), symmetric, non-negative weights
    communities : np.ndarray
        Community labels for each node (length n)
    resolution : float
        Resolution parameter (gamma).

    Returns
    -------
    float
        Modularity score in [-0.5, 1].
    """
    adjacency = np.ascontiguousarray(np.asarray(adjacency, dtype=np.float64))
    communities = np.ascontiguousarray(np.asarray(communities, dtype=np.float64))
    return float(_rust.modularity(adjacency, communities, resolution))


def community_detection(
    adjacency: np.ndarray,
    method: str = 'louvain',
    resolution: float = 1.0,
    n_communities: Optional[int] = None,
) -> Tuple[np.ndarray, float]:
    """
    Detect communities in a network.

    Parameters
    ----------
    adjacency : np.ndarray
        Adjacency matrix (n x n), symmetric, non-negative weights
    method : str
        Detection algorithm: 'louvain', 'spectral', or 'label_propagation'
    resolution : float
        Resolution parameter for Louvain method
    n_communities : int, optional
        Number of communities (required for spectral)

    Returns
    -------
    tuple
        (communities, modularity_score)
    """
    adjacency = np.ascontiguousarray(np.asarray(adjacency, dtype=np.float64))
    if adjacency.ndim < 2:
        return np.array([0]), 0.0
    n = adjacency.shape[0]

    if n == 0:
        return np.array([], dtype=int), 0.0

    if method == 'louvain':
        communities = np.asarray(_rust.louvain(adjacency, resolution)).astype(int)
    elif method == 'spectral':
        if n_communities is None:
            n_communities = _estimate_n_communities(adjacency)
        communities = _spectral_clustering(adjacency, n_communities)
    elif method == 'label_propagation':
        communities = np.asarray(_rust.label_propagation(adjacency)).astype(int)
    else:
        raise ValueError(f"Unknown method: {method}")

    mod_score = float(_rust.modularity(
        adjacency,
        np.ascontiguousarray(communities.astype(np.float64)),
        resolution
    ))
    return communities, mod_score


def _spectral_clustering(
    adjacency: np.ndarray,
    n_clusters: int
) -> np.ndarray:
    """Spectral clustering using Laplacian eigenvectors."""
    n = adjacency.shape[0]

    if n_clusters >= n:
        return np.arange(n)

    # Normalized Laplacian
    degrees = np.sum(adjacency, axis=1)
    with np.errstate(divide='ignore'):
        d_inv_sqrt = 1.0 / np.sqrt(degrees)
    d_inv_sqrt[np.isinf(d_inv_sqrt)] = 0

    D_inv_sqrt = np.diag(d_inv_sqrt)
    L_norm = np.eye(n) - D_inv_sqrt @ adjacency @ D_inv_sqrt

    # Eigenvectors
    eigenvalues, eigenvectors = np.linalg.eigh(L_norm)

    # Use k smallest non-trivial eigenvectors
    idx = np.argsort(eigenvalues)[1:n_clusters + 1]
    embedding = eigenvectors[:, idx]

    # Normalize rows
    row_norms = np.linalg.norm(embedding, axis=1, keepdims=True)
    row_norms[row_norms == 0] = 1
    embedding = embedding / row_norms

    # K-means clustering
    communities = _kmeans(embedding, n_clusters)

    return communities


def _estimate_n_communities(adjacency: np.ndarray) -> int:
    """Estimate number of communities using eigengap heuristic."""
    n = adjacency.shape[0]

    degrees = np.sum(adjacency, axis=1)
    with np.errstate(divide='ignore'):
        d_inv_sqrt = 1.0 / np.sqrt(degrees)
    d_inv_sqrt[np.isinf(d_inv_sqrt)] = 0

    D_inv_sqrt = np.diag(d_inv_sqrt)
    L_norm = np.eye(n) - D_inv_sqrt @ adjacency @ D_inv_sqrt

    eigenvalues = np.sort(np.linalg.eigvalsh(L_norm))

    gaps = np.diff(eigenvalues[:min(n // 2, 20)])
    if len(gaps) == 0:
        return 2

    k = np.argmax(gaps) + 1
    return max(2, min(k, n // 2))


def _kmeans(X: np.ndarray, k: int, max_iter: int = 100) -> np.ndarray:
    """Simple k-means clustering."""
    n = len(X)

    idx = np.random.choice(n, k, replace=False)
    centers = X[idx].copy()

    labels = np.zeros(n, dtype=int)

    for _ in range(max_iter):
        for i in range(n):
            dists = np.linalg.norm(X[i] - centers, axis=1)
            labels[i] = np.argmin(dists)

        new_centers = np.zeros_like(centers)
        for j in range(k):
            mask = labels == j
            if np.any(mask):
                new_centers[j] = X[mask].mean(axis=0)
            else:
                new_centers[j] = centers[j]

        if np.allclose(centers, new_centers):
            break

        centers = new_centers

    return labels
