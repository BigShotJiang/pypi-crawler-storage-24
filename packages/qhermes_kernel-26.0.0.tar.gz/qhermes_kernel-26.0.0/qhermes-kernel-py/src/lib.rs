// Copyright (c) 2026 Copertino All rights reserved.
// SPDX-License-Identifier: LicenseRef-Copertino-1.0
// Licensed under the Copertino Source License 1.0 — see LICENSE at the repository root.
// Commercial use requires a license from Copertino: hello@copertino.world

use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;
use pyo3::types::PyBytes;
use qhermes_kernel as k;
use k::IdentitySigner as _;

fn kerr(e: k::KernelError) -> PyErr {
    PyValueError::new_err(format!("KernelError::{e:?}"))
}

fn zero_creds() -> [k::Credential<'static>; k::MAX_DEPTH as usize] {
    const ZERO_PK:  [u8; k::PK_SIZE]  = [0u8; k::PK_SIZE];
    const ZERO_SIG: [u8; k::SIG_SIZE] = [0u8; k::SIG_SIZE];
    core::array::from_fn(|_| k::Credential {
        issuer_pk: k::PublicKey(&ZERO_PK),
        signature: k::Signature(&ZERO_SIG),
        payload:   b"",
    })
}

// ── IdentityIsland ────────────────────────────────────────────────────────

/// ML-DSA-65 identity derived from a master seed.
#[pyclass]
pub struct IdentityIsland {
    inner: k::IdentityIsland,
}

#[pymethods]
impl IdentityIsland {
    /// IdentityIsland(master: bytes, deployment: bytes, context: bytes)
    ///
    /// master must be exactly 32 bytes.
    #[new]
    fn new(master: &[u8], deployment: &[u8], context: &[u8]) -> PyResult<Self> {
        let seed: &[u8; k::SEED_SIZE] = master
            .try_into()
            .map_err(|_| PyValueError::new_err(format!("master must be {} bytes", k::SEED_SIZE)))?;
        Ok(Self { inner: k::IdentityIsland::derive(seed, deployment, context).map_err(kerr)? })
    }

    /// Returns the PK_SIZE-byte ML-DSA-65 public key.
    fn public_key<'py>(&self, py: Python<'py>) -> Bound<'py, PyBytes> {
        PyBytes::new(py, self.inner.public_key().0)
    }

    /// issue_credential(child_pk, role, depth, scope_tlv, caveats) -> (payload, sig)
    ///
    /// role: "leaf" or "node".
    /// depth: position in the chain, starting at 1.
    /// scope_tlv: TLV bytes from perm_tlv().
    /// caveats: concatenated caveat bytes from not_before()/not_after(), or b"".
    /// Returns (payload_bytes, sig_bytes).
    fn issue_credential<'py>(
        &self,
        py: Python<'py>,
        child_pk: &[u8],
        role: &str,
        depth: u32,
        scope_tlv: &[u8],
        caveats: &[u8],
    ) -> PyResult<(Bound<'py, PyBytes>, Bound<'py, PyBytes>)> {
        let child_pk_arr: &[u8; k::PK_SIZE] = child_pk
            .try_into()
            .map_err(|_| PyValueError::new_err(format!("child_pk must be {} bytes", k::PK_SIZE)))?;
        let role_val = match role.to_ascii_lowercase().as_str() {
            "leaf" => k::Role::Leaf,
            "node" => k::Role::Node,
            _ => return Err(PyValueError::new_err("role must be 'leaf' or 'node'")),
        };
        let manifest = k::DelegationManifest {
            child_pk: k::PublicKey(child_pk_arr),
            role:     role_val,
            depth:    k::Depth(depth),
            scope:    k::BoundedScope::try_new(scope_tlv).map_err(kerr)?,
            caveats:  k::BoundedCaveats::try_new(caveats).map_err(kerr)?,
        };
        let mut payload = [0u8; k::MAX_PAYLOAD_SIZE];
        let mut sig     = [0u8; k::SIG_SIZE];
        let n = k::issue_credential(&self.inner, &manifest, &mut payload, &mut sig).map_err(kerr)?;
        Ok((PyBytes::new(py, &payload[..n]), PyBytes::new(py, &sig)))
    }
}

// ── Free functions ────────────────────────────────────────────────────────

/// perm_tlv(resource: bytes, verb: bytes) -> bytes
///
/// Encodes a permission in TLV format.
#[pyfunction]
fn perm_tlv<'py>(py: Python<'py>, resource: &[u8], verb: &[u8]) -> PyResult<Bound<'py, PyBytes>> {
    let mut buf = [0u8; k::PERM_TLV_MAX];
    let n = k::perm_tlv(resource, verb, &mut buf).map_err(kerr)?;
    Ok(PyBytes::new(py, &buf[..n]))
}

/// not_before(ts: int) -> bytes
///
/// Returns a 9-byte caveat record. ts is seconds since the Unix epoch.
#[pyfunction]
fn not_before<'py>(py: Python<'py>, ts: u64) -> Bound<'py, PyBytes> {
    PyBytes::new(py, &k::not_before(k::Timestamp(ts)))
}

/// not_after(ts: int) -> bytes
///
/// Returns a 9-byte caveat record. ts is seconds since the Unix epoch.
#[pyfunction]
fn not_after<'py>(py: Python<'py>, ts: u64) -> Bound<'py, PyBytes> {
    PyBytes::new(py, &k::not_after(k::Timestamp(ts)))
}

/// encode_chain(credentials: list[tuple[bytes, bytes, bytes]]) -> bytes
///
/// Each tuple is (issuer_pk, sig, payload). Returns the wire-encoded chain.
#[pyfunction]
fn encode_chain<'py>(
    py: Python<'py>,
    credentials: Vec<(Vec<u8>, Vec<u8>, Vec<u8>)>,
) -> PyResult<Bound<'py, PyBytes>> {
    let mut bufs: Vec<([u8; k::PK_SIZE], [u8; k::SIG_SIZE], Vec<u8>)> =
        Vec::with_capacity(credentials.len());
    for (i, (pk, sig, payload)) in credentials.into_iter().enumerate() {
        bufs.push((
            pk.as_slice().try_into().map_err(|_| {
                PyValueError::new_err(format!("credential[{i}] issuer_pk must be {} bytes", k::PK_SIZE))
            })?,
            sig.as_slice().try_into().map_err(|_| {
                PyValueError::new_err(format!("credential[{i}] sig must be {} bytes", k::SIG_SIZE))
            })?,
            payload,
        ));
    }
    let chain: Vec<k::Credential<'_>> = bufs.iter().map(|(pk, sig, payload)| k::Credential {
        issuer_pk: k::PublicKey(pk),
        signature: k::Signature(sig),
        payload:   payload.as_slice(),
    }).collect();
    let max = 5 + chain.len() * (k::CREDENTIAL_FIXED_SIZE + k::MAX_PAYLOAD_SIZE);
    let mut out = vec![0u8; max];
    let n = k::write_credential_chain(&mut out, &chain).map_err(kerr)?;
    Ok(PyBytes::new(py, &out[..n]))
}

/// decode_chain(wire: bytes) -> list[tuple[bytes, bytes, bytes]]
///
/// Returns tuples (issuer_pk, sig, payload). Does not verify signatures.
#[pyfunction]
fn decode_chain<'py>(
    py: Python<'py>,
    wire: &[u8],
) -> PyResult<Vec<(Bound<'py, PyBytes>, Bound<'py, PyBytes>, Bound<'py, PyBytes>)>> {
    let mut buf = zero_creds();
    let n = k::read_credential_chain(wire, &mut buf).map_err(kerr)?;
    Ok(buf[..n].iter().map(|c| (
        PyBytes::new(py, c.issuer_pk.0),
        PyBytes::new(py, c.signature.0),
        PyBytes::new(py, c.payload),
    )).collect())
}

/// parse_payload(payload: bytes) -> dict
///
/// Deserializes a credential payload without verifying the signature.
/// Returns a dict with the following keys:
///   child_pk  : bytes  — delegatee public key (PK_SIZE bytes)
///   role      : str    — "leaf" or "node"
///   depth     : int    — position in the chain
///   perms     : list[tuple[bytes, bytes]] — list of (resource, verb)
///   not_before: int | None — Unix timestamp in seconds, or None if absent
///   not_after : int | None — Unix timestamp in seconds, or None if absent
///
/// Raises ValueError if the payload is truncated or structurally invalid.
#[pyfunction]
fn parse_payload(py: Python<'_>, payload: &[u8]) -> PyResult<PyObject> {
    use pyo3::types::{PyDict, PyList, PyTuple};

    // Use BoundedScope/BoundedCaveats for validation; parse_payload in Rust
    // is not pub, so we replicate it at the binding level using the same pub functions.
    let min = k::PK_SIZE + 1 + 4 + 4 + 4; // pk + role + depth + scope_len + cav_len
    if payload.len() < min {
        return Err(PyValueError::new_err("payload too short"));
    }

    let child_pk = &payload[..k::PK_SIZE];
    let role_byte = payload[k::PK_SIZE];
    let role_str = match role_byte {
        0 => "leaf",
        1 => "node",
        _ => return Err(PyValueError::new_err(format!("invalid role byte: {role_byte:#04x}"))),
    };
    let depth = u32::from_le_bytes(
        payload[k::PK_SIZE + 1..k::PK_SIZE + 5].try_into().unwrap()
    );

    let pos = k::PK_SIZE + 1 + 4;
    let scope_len = u32::from_le_bytes(payload[pos..pos + 4].try_into().unwrap()) as usize;
    let scope_start = pos + 4;
    let scope_end   = scope_start + scope_len;
    if scope_end > payload.len() {
        return Err(PyValueError::new_err("payload truncated at scope"));
    }
    let scope_bytes = &payload[scope_start..scope_end];

    let cav_pos = scope_end;
    if cav_pos + 4 > payload.len() {
        return Err(PyValueError::new_err("payload truncated at caveat length"));
    }
    let cav_len = u32::from_le_bytes(payload[cav_pos..cav_pos + 4].try_into().unwrap()) as usize;
    let cav_start = cav_pos + 4;
    let cav_end   = cav_start + cav_len;
    if cav_end > payload.len() {
        return Err(PyValueError::new_err("payload truncated at caveats"));
    }
    let cav_bytes = &payload[cav_start..cav_end];

    // Parse permissions via BoundedScope iterator
    let scope = k::BoundedScope::try_new(scope_bytes).map_err(kerr)?;
    let perms_list = PyList::empty(py);
    for (res, verb) in scope.iter() {
        let tup = PyTuple::new(py, &[
            PyBytes::new(py, res),
            PyBytes::new(py, verb),
        ])?;
        perms_list.append(tup)?;
    }

    // Parse caveats (fixed 9-byte chunks)
    let mut not_before_val: Option<u64> = None;
    let mut not_after_val:  Option<u64> = None;
    const CAVEAT_NOT_BEFORE: u8 = 0x01;
    const CAVEAT_NOT_AFTER:  u8 = 0x02;
    const CAVEAT_SIZE: usize = 9;
    for chunk in cav_bytes.chunks_exact(CAVEAT_SIZE) {
        let ts = u64::from_le_bytes(chunk[1..].try_into().unwrap());
        match chunk[0] {
            CAVEAT_NOT_BEFORE => not_before_val = Some(ts),
            CAVEAT_NOT_AFTER  => not_after_val  = Some(ts),
            b => return Err(PyValueError::new_err(format!("unknown caveat tag: {b:#04x}"))),
        }
    }

    let d = PyDict::new(py);
    d.set_item("child_pk",   PyBytes::new(py, child_pk))?;
    d.set_item("role",       role_str)?;
    d.set_item("depth",      depth)?;
    d.set_item("perms",      perms_list)?;
    d.set_item("not_before", not_before_val)?;
    d.set_item("not_after",  not_after_val)?;
    Ok(d.into())
}

/// verify_delegation(root_pk: bytes, wire: bytes, now: int) -> int
///
/// Verifies signatures, depth sequence, scope subset, and caveats.
/// Returns the credential count. Raises ValueError on failure.
#[pyfunction]
fn verify_delegation<'py>(root_pk: &[u8], wire: &[u8], now: u64) -> PyResult<usize> {
    let pk_arr: &[u8; k::PK_SIZE] = root_pk
        .try_into()
        .map_err(|_| PyValueError::new_err(format!("root_pk must be {} bytes", k::PK_SIZE)))?;
    let mut buf = zero_creds();
    let n = k::read_credential_chain(wire, &mut buf).map_err(kerr)?;
    k::verify_delegation(k::PublicKey(pk_arr), &buf[..n], k::Timestamp(now)).map_err(kerr)?;
    Ok(n)
}

// ── Module ────────────────────────────────────────────────────────────────

#[pymodule(name = "qhermes_kernel")]
fn qhermes_kernel_ext(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add("PK_SIZE",   k::PK_SIZE)?;
    m.add("SIG_SIZE",  k::SIG_SIZE)?;
    m.add("SEED_SIZE", k::SEED_SIZE)?;

    m.add_class::<IdentityIsland>()?;

    m.add_function(wrap_pyfunction!(perm_tlv, m)?)?;
    m.add_function(wrap_pyfunction!(not_before, m)?)?;
    m.add_function(wrap_pyfunction!(not_after, m)?)?;
    m.add_function(wrap_pyfunction!(encode_chain, m)?)?;
    m.add_function(wrap_pyfunction!(decode_chain, m)?)?;
    m.add_function(wrap_pyfunction!(parse_payload, m)?)?;
    m.add_function(wrap_pyfunction!(verify_delegation, m)?)?;
    Ok(())
}
