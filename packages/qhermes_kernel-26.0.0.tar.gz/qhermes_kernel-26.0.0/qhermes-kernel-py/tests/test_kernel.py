# Copyright (c) 2026 Copertino All rights reserved.
# SPDX-License-Identifier: LicenseRef-Copertino-1.0
#
# Integration tests — exercise the compiled Rust extension through the Python layer.
# No mocks. Every assertion operates on real cryptographic output.
#
# Run:  maturin develop && pytest tests/

import time
import pytest

import qhermes_kernel as _k
from qhermes.kernel import (
    Policy,
    Credential,
    allow,
    caveat_not_before,
    caveat_not_after,
    make_policy,
    make_identity,
    derive_public_key,
    issue_credential,
    delegate,
    build_chain,
    verify_chain,
    decode_chain,
    credential_valid_at,
    explain_credential,
    parse_payload,
)


# ── Constants ─────────────────────────────────────────────────────────────────

MASTER     = b"\x01" * 32
DEPLOYMENT = b"prod"
CTX_ROOT   = b"root"
CTX_CHILD  = b"child"

# Fixed reference time: avoids drift between calls during the same test run.
NOW = int(time.time())


# ── Helper functions ──────────────────────────────────────────────────────────

def root_identity():
    """Return a fresh root IdentityIsland from the fixed MASTER seed."""
    return make_identity(MASTER, DEPLOYMENT, CTX_ROOT)


def child_identity():
    """Return a fresh child IdentityIsland from the fixed MASTER seed."""
    return make_identity(MASTER, DEPLOYMENT, CTX_CHILD)


def simple_policy(*, hours: float = 1.0) -> Policy:
    """Build a minimal valid policy with one resource/action pair."""
    return make_policy(
        resources=[b"/tasks"],
        actions=[b"write"],
        hours_valid=hours,
        now=NOW,
    )


def leaf_chain():
    """Build a one-hop chain: root issues to child as leaf at depth 1.

    Returns (root_identity, child_identity, chain_tuple).
    Uses the current API — no depth= argument to delegate().
    """
    root  = root_identity()
    child = child_identity()
    chain = delegate(root, derive_public_key(child), simple_policy())
    return root, child, chain


# ── Happy path ────────────────────────────────────────────────────────────────

def test_public_key_has_correct_size():
    pk = derive_public_key(root_identity())
    assert len(pk) == _k.PK_SIZE


def test_same_inputs_produce_same_public_key():
    pk1 = derive_public_key(make_identity(MASTER, DEPLOYMENT, CTX_ROOT))
    pk2 = derive_public_key(make_identity(MASTER, DEPLOYMENT, CTX_ROOT))
    assert pk1 == pk2


def test_different_context_produces_different_public_key():
    pk_a = derive_public_key(make_identity(MASTER, DEPLOYMENT, b"context-a"))
    pk_b = derive_public_key(make_identity(MASTER, DEPLOYMENT, b"context-b"))
    assert pk_a != pk_b


def test_different_deployment_produces_different_public_key():
    pk_prod    = derive_public_key(make_identity(MASTER, b"prod",    CTX_ROOT))
    pk_staging = derive_public_key(make_identity(MASTER, b"staging", CTX_ROOT))
    assert pk_prod != pk_staging


def test_different_master_produces_different_public_key():
    pk1 = derive_public_key(make_identity(b"\x01" * 32, DEPLOYMENT, CTX_ROOT))
    pk2 = derive_public_key(make_identity(b"\x02" * 32, DEPLOYMENT, CTX_ROOT))
    assert pk1 != pk2


def test_issued_credential_has_correct_field_sizes():
    root  = root_identity()
    child = child_identity()
    cred  = issue_credential(root, derive_public_key(child), simple_policy(), depth=1)

    assert isinstance(cred, Credential)
    assert len(cred.issuer_pk) == _k.PK_SIZE
    assert len(cred.signature) == _k.SIG_SIZE
    assert len(cred.payload)   >  0


def test_issuer_pk_matches_signing_identity():
    root  = root_identity()
    child = child_identity()
    cred  = issue_credential(root, derive_public_key(child), simple_policy(), depth=1)
    assert cred.issuer_pk == derive_public_key(root)


def test_single_hop_chain_verifies():
    root, child, chain = leaf_chain()
    wire = build_chain(chain)
    n    = verify_chain(derive_public_key(root), wire, now=NOW)
    assert n == 1


def test_two_hop_chain_verifies():
    root = root_identity()
    mid  = make_identity(MASTER, DEPLOYMENT, b"mid")
    leaf = make_identity(MASTER, DEPLOYMENT, b"leaf")

    chain = delegate(root, derive_public_key(mid),  simple_policy(), role="node")
    chain = delegate(mid,  derive_public_key(leaf), simple_policy(), parent_chain=chain)

    n = verify_chain(derive_public_key(root), build_chain(chain), now=NOW)
    assert n == 2


def test_three_hop_chain_verifies():
    root = root_identity()
    mid1 = make_identity(MASTER, DEPLOYMENT, b"mid-1")
    mid2 = make_identity(MASTER, DEPLOYMENT, b"mid-2")
    leaf = make_identity(MASTER, DEPLOYMENT, b"leaf")

    chain = delegate(root, derive_public_key(mid1), simple_policy(), role="node")
    chain = delegate(mid1, derive_public_key(mid2), simple_policy(), role="node", parent_chain=chain)
    chain = delegate(mid2, derive_public_key(leaf), simple_policy(), parent_chain=chain)

    n = verify_chain(derive_public_key(root), build_chain(chain), now=NOW)
    assert n == 3


def test_decode_chain_recovers_original_fields():
    root, child, original = leaf_chain()
    decoded = decode_chain(build_chain(original))

    assert len(decoded) == 1
    assert decoded[0].issuer_pk == original[0].issuer_pk
    assert decoded[0].signature == original[0].signature
    assert decoded[0].payload   == original[0].payload


def test_wire_roundtrip_is_stable():
    root, child, chain = leaf_chain()
    wire1 = build_chain(chain)
    wire2 = build_chain(decode_chain(wire1))
    assert wire1 == wire2


# ── Edge cases / boundary ─────────────────────────────────────────────────────

def test_make_policy_single_char_resource_and_verb():
    # Minimal byte values are valid — kernel does exact-match comparison.
    p = make_policy(resources=[b"r"], actions=[b"w"])
    assert isinstance(p.scope_tlv, bytes)
    assert len(p.scope_tlv) > 0


def test_make_policy_max_length_resource_255_bytes():
    long_resource = b"x" * 255
    p = make_policy(resources=[long_resource], actions=[b"GET"])
    assert len(p.scope_tlv) > 0


def test_make_policy_exactly_one_permission():
    p = make_policy(resources=[b"/a"], actions=[b"r"])
    parsed = parse_payload(
        issue_credential(root_identity(), derive_public_key(child_identity()), p, depth=1)
    )
    assert len(parsed["perms"]) == 1


def test_make_policy_wildcard_resource():
    # b"*" is a legal byte value the kernel treats as a wildcard during scope checks.
    p = make_policy(resources=[b"*"], actions=[b"read"])
    assert isinstance(p.scope_tlv, bytes)
    assert len(p.scope_tlv) > 0


def test_make_policy_wildcard_verb():
    p = make_policy(resources=[b"/data"], actions=[b"*"])
    assert isinstance(p.scope_tlv, bytes)
    assert len(p.scope_tlv) > 0


def test_make_policy_hours_valid_zero_with_explicit_not_after():
    # hours_valid=0 has no effect; not_after is honoured.
    explicit_na = NOW + 100
    p = make_policy(
        resources=[b"/x"], actions=[b"r"],
        hours_valid=0,
        not_after=explicit_na,
        now=NOW,
    )
    parsed = parse_payload(
        issue_credential(root_identity(), derive_public_key(child_identity()), p, depth=1)
    )
    assert parsed["not_after"] == explicit_na


def test_make_policy_minutes_valid_fractional():
    # 1.5 minutes = 90 seconds
    fixed_now = 1_000_000_000
    p = make_policy(resources=[b"/x"], actions=[b"r"], minutes_valid=1.5, now=fixed_now)
    parsed = parse_payload(
        issue_credential(root_identity(), derive_public_key(child_identity()), p, depth=1)
    )
    assert parsed["not_after"] == fixed_now + 90


def test_make_policy_now_zero_unix_epoch():
    # now=0 corresponds to 1970-01-01T00:00:00 UTC — must not crash.
    p = make_policy(resources=[b"/x"], actions=[b"r"], hours_valid=1, now=0)
    parsed = parse_payload(
        issue_credential(root_identity(), derive_public_key(child_identity()), p, depth=1)
    )
    assert parsed["not_after"] == 3600


def test_credential_valid_at_boundary_exactly_not_before():
    policy = make_policy(resources=[b"/x"], actions=[b"r"], not_before=NOW)
    cred   = issue_credential(root_identity(), derive_public_key(child_identity()), policy, depth=1)
    # Exactly at not_before must be valid (ts >= nb).
    assert credential_valid_at(cred, ts=NOW)


def test_credential_valid_at_boundary_one_second_before_not_before():
    policy = make_policy(resources=[b"/x"], actions=[b"r"], not_before=NOW)
    cred   = issue_credential(root_identity(), derive_public_key(child_identity()), policy, depth=1)
    assert not credential_valid_at(cred, ts=NOW - 1)


def test_credential_valid_at_boundary_exactly_not_after():
    ts     = NOW + 3600
    policy = make_policy(resources=[b"/x"], actions=[b"r"], not_after=ts)
    cred   = issue_credential(root_identity(), derive_public_key(child_identity()), policy, depth=1)
    # Exactly at not_after must be valid (ts <= na).
    assert credential_valid_at(cred, ts=ts)


def test_credential_valid_at_boundary_one_second_after_not_after():
    ts     = NOW + 3600
    policy = make_policy(resources=[b"/x"], actions=[b"r"], not_after=ts)
    cred   = issue_credential(root_identity(), derive_public_key(child_identity()), policy, depth=1)
    assert not credential_valid_at(cred, ts=ts + 1)


def test_make_policy_not_after_wins_over_hours_valid_when_both_given():
    # When not_after is explicit, hours_valid is silently ignored (new behavior — no exception).
    explicit_na = NOW + 999
    p = make_policy(
        resources=[b"/x"], actions=[b"r"],
        not_after=explicit_na,
        hours_valid=1,
        now=NOW,
    )
    parsed = parse_payload(
        issue_credential(root_identity(), derive_public_key(child_identity()), p, depth=1)
    )
    assert parsed["not_after"] == explicit_na


# ── Negative / invalid inputs ─────────────────────────────────────────────────

def test_make_identity_wrong_master_size_1_byte_raises():
    with pytest.raises((ValueError, Exception)):
        make_identity(b"\x01", DEPLOYMENT, CTX_ROOT)


def test_make_identity_wrong_master_size_16_bytes_raises():
    with pytest.raises((ValueError, Exception)):
        make_identity(b"\x01" * 16, DEPLOYMENT, CTX_ROOT)


def test_make_identity_wrong_master_size_31_bytes_raises():
    with pytest.raises((ValueError, Exception)):
        make_identity(b"\x01" * 31, DEPLOYMENT, CTX_ROOT)


def test_make_identity_wrong_master_size_33_bytes_raises():
    with pytest.raises((ValueError, Exception)):
        make_identity(b"\x01" * 33, DEPLOYMENT, CTX_ROOT)


def test_make_identity_wrong_master_size_64_bytes_raises():
    with pytest.raises((ValueError, Exception)):
        make_identity(b"\x01" * 64, DEPLOYMENT, CTX_ROOT)


def test_make_policy_resources_without_actions_raises():
    with pytest.raises(ValueError):
        make_policy(resources=[b"/x"])


def test_make_policy_actions_without_resources_raises():
    with pytest.raises(ValueError):
        make_policy(actions=[b"read"])


def test_make_policy_empty_permissions_list_raises():
    with pytest.raises(ValueError):
        make_policy(permissions=[])


def test_make_policy_no_permissions_at_all_raises():
    with pytest.raises(ValueError):
        make_policy()


def test_issue_credential_wrong_child_pk_size_raises():
    root = root_identity()
    with pytest.raises((ValueError, Exception)):
        issue_credential(root, b"\x00" * 10, simple_policy(), depth=1)


# ── Integrity: tampered / malformed wire ──────────────────────────────────────

def test_wrong_root_pk_fails_verification():
    root, child, chain = leaf_chain()
    impostor_pk = derive_public_key(make_identity(b"\xff" * 32, DEPLOYMENT, CTX_ROOT))
    wire = build_chain(chain)
    with pytest.raises(Exception):
        verify_chain(impostor_pk, wire, now=NOW)


def test_tampered_signature_bytes_fail_verification():
    root, child, chain = leaf_chain()
    root_pk = derive_public_key(root)
    wire = bytearray(build_chain(chain))
    # Flip a byte in the middle of the wire — lands somewhere in the signature region.
    wire[50] ^= 0xFF
    with pytest.raises(Exception):
        verify_chain(root_pk, bytes(wire), now=NOW)


def test_tampered_payload_bytes_fail_verification():
    root, child, chain = leaf_chain()
    root_pk = derive_public_key(root)
    wire = bytearray(build_chain(chain))
    wire[-10] ^= 0xFF
    with pytest.raises(Exception):
        verify_chain(root_pk, bytes(wire), now=NOW)


def test_tampered_nonce_fails_verification():
    # Flip the very first byte of the wire, which is in the nonce/header area.
    root, child, chain = leaf_chain()
    root_pk = derive_public_key(root)
    wire = bytearray(build_chain(chain))
    wire[0] ^= 0xFF
    with pytest.raises(Exception):
        verify_chain(root_pk, bytes(wire), now=NOW)


def test_expired_chain_fails_verification():
    root  = root_identity()
    child = child_identity()
    policy = make_policy(resources=[b"/x"], actions=[b"r"], not_after=NOW - 1)
    chain  = delegate(root, derive_public_key(child), policy)
    with pytest.raises(Exception):
        verify_chain(derive_public_key(root), build_chain(chain), now=NOW)


def test_not_yet_valid_chain_fails_verification():
    root  = root_identity()
    child = child_identity()
    policy = make_policy(resources=[b"/x"], actions=[b"r"], not_before=NOW + 9999)
    chain  = delegate(root, derive_public_key(child), policy)
    with pytest.raises(Exception):
        verify_chain(derive_public_key(root), build_chain(chain), now=NOW)


def test_leaf_cannot_sub_delegate():
    root = root_identity()
    mid  = make_identity(MASTER, DEPLOYMENT, b"mid")
    leaf = make_identity(MASTER, DEPLOYMENT, b"leaf")

    # mid is issued as role="leaf" — the kernel must reject any further delegation.
    chain = delegate(root, derive_public_key(mid), simple_policy(), role="leaf")
    chain = delegate(mid,  derive_public_key(leaf), simple_policy(), parent_chain=chain)

    with pytest.raises(Exception):
        verify_chain(derive_public_key(root), build_chain(chain), now=NOW)


def test_depth_out_of_sequence_fails_verification():
    root = root_identity()
    mid  = make_identity(MASTER, DEPLOYMENT, b"mid")
    leaf = make_identity(MASTER, DEPLOYMENT, b"leaf")

    # Manually issue with a non-sequential depth to produce an invalid chain.
    chain = delegate(root, derive_public_key(mid), simple_policy(), role="node")
    # Manually call issue_credential with a wrong depth (3 instead of 2).
    wrong_depth_cred = issue_credential(mid, derive_public_key(leaf), simple_policy(), depth=3)
    bad_chain = (*chain, wrong_depth_cred)

    with pytest.raises(Exception):
        verify_chain(derive_public_key(root), build_chain(bad_chain), now=NOW)


def test_empty_wire_fails_verification():
    root_pk = derive_public_key(root_identity())
    with pytest.raises(Exception):
        verify_chain(root_pk, b"", now=NOW)


def test_truncated_wire_fails_verification():
    root, child, chain = leaf_chain()
    root_pk = derive_public_key(root)
    wire    = build_chain(chain)
    with pytest.raises(Exception):
        verify_chain(root_pk, wire[:20], now=NOW)


# ── make_policy combinatorics ─────────────────────────────────────────────────

def test_make_policy_cartesian_product_2x2_produces_4_permissions():
    # 2 resources × 2 actions = 4 (resource, verb) pairs in the scope.
    p = make_policy(
        resources=[b"/data", b"/logs"],
        actions=[b"GET",   b"POST"],
    )
    cred   = issue_credential(root_identity(), derive_public_key(child_identity()), p, depth=1)
    parsed = parse_payload(cred)
    assert len(parsed["perms"]) == 4
    assert (b"/data", b"GET")  in parsed["perms"]
    assert (b"/data", b"POST") in parsed["perms"]
    assert (b"/logs", b"GET")  in parsed["perms"]
    assert (b"/logs", b"POST") in parsed["perms"]


def test_make_policy_permissions_only():
    p = make_policy(permissions=[(b"/admin", b"POST"), (b"/data", b"GET")])
    cred   = issue_credential(root_identity(), derive_public_key(child_identity()), p, depth=1)
    parsed = parse_payload(cred)
    assert (b"/admin", b"POST") in parsed["perms"]
    assert (b"/data",  b"GET")  in parsed["perms"]


def test_make_policy_both_forms_are_union():
    # Cartesian product adds 1 pair; explicit permissions adds 1 more → total 2.
    p = make_policy(
        resources=[b"/logs"], actions=[b"GET"],
        permissions=[(b"/data", b"PUT")],
    )
    cred   = issue_credential(root_identity(), derive_public_key(child_identity()), p, depth=1)
    parsed = parse_payload(cred)
    assert (b"/logs", b"GET") in parsed["perms"]
    assert (b"/data", b"PUT") in parsed["perms"]
    assert len(parsed["perms"]) == 2


# ── delegate depth auto-calculation ──────────────────────────────────────────

def test_delegate_depth_auto_calculated_single_hop():
    root  = root_identity()
    child = child_identity()
    chain = delegate(root, derive_public_key(child), simple_policy())
    parsed = parse_payload(chain[0])
    # depth must equal len(parent_chain) + 1 = 0 + 1 = 1
    assert parsed["depth"] == 1


def test_delegate_depth_auto_calculated_two_hops():
    root = root_identity()
    mid  = make_identity(MASTER, DEPLOYMENT, b"mid")
    leaf = make_identity(MASTER, DEPLOYMENT, b"leaf")

    chain = delegate(root, derive_public_key(mid), simple_policy(), role="node")
    chain = delegate(mid,  derive_public_key(leaf), simple_policy(), parent_chain=chain)

    assert parse_payload(chain[0])["depth"] == 1
    assert parse_payload(chain[1])["depth"] == 2


def test_delegate_depth_auto_calculated_three_hops():
    root = root_identity()
    mid1 = make_identity(MASTER, DEPLOYMENT, b"mid-1")
    mid2 = make_identity(MASTER, DEPLOYMENT, b"mid-2")
    leaf = make_identity(MASTER, DEPLOYMENT, b"leaf")

    chain = delegate(root, derive_public_key(mid1), simple_policy(), role="node")
    chain = delegate(mid1, derive_public_key(mid2), simple_policy(), role="node", parent_chain=chain)
    chain = delegate(mid2, derive_public_key(leaf), simple_policy(), parent_chain=chain)

    assert parse_payload(chain[0])["depth"] == 1
    assert parse_payload(chain[1])["depth"] == 2
    assert parse_payload(chain[2])["depth"] == 3


# ── Determinism (ML-DSA-65 is deterministic) ──────────────────────────────────

def test_same_inputs_produce_identical_credential_payload_and_signature():
    root     = root_identity()
    child_pk = derive_public_key(child_identity())
    policy   = simple_policy()
    cred_a   = issue_credential(root, child_pk, policy, depth=1)
    cred_b   = issue_credential(root, child_pk, policy, depth=1)
    assert cred_a.payload   == cred_b.payload
    assert cred_a.signature == cred_b.signature


def test_determinism_with_fixed_now():
    fixed_now = 1_000_000_000
    child_pk  = derive_public_key(child_identity())
    policy1   = make_policy(resources=[b"/x"], actions=[b"r"], hours_valid=1, now=fixed_now)
    policy2   = make_policy(resources=[b"/x"], actions=[b"r"], hours_valid=1, now=fixed_now)
    cred1     = issue_credential(root_identity(), child_pk, policy1, depth=1)
    cred2     = issue_credential(root_identity(), child_pk, policy2, depth=1)
    assert cred1.payload   == cred2.payload
    assert cred1.signature == cred2.signature


# ── credential_valid_at ───────────────────────────────────────────────────────

def test_credential_valid_within_time_window():
    policy = make_policy(resources=[b"/x"], actions=[b"r"], not_before=NOW - 10, not_after=NOW + 3600)
    cred   = issue_credential(root_identity(), derive_public_key(child_identity()), policy, depth=1)
    assert credential_valid_at(cred, ts=NOW)


def test_expired_credential_is_invalid():
    policy = make_policy(resources=[b"/x"], actions=[b"r"], not_after=NOW - 1)
    cred   = issue_credential(root_identity(), derive_public_key(child_identity()), policy, depth=1)
    assert not credential_valid_at(cred, ts=NOW)


def test_future_not_before_credential_is_invalid():
    policy = make_policy(resources=[b"/x"], actions=[b"r"], not_before=NOW + 9999)
    cred   = issue_credential(root_identity(), derive_public_key(child_identity()), policy, depth=1)
    assert not credential_valid_at(cred, ts=NOW)


def test_credential_without_caveats_is_always_valid():
    policy = make_policy(resources=[b"/x"], actions=[b"r"])
    cred   = issue_credential(root_identity(), derive_public_key(child_identity()), policy, depth=1)
    # No caveats: must be valid at any timestamp, including epoch and far future.
    assert credential_valid_at(cred, ts=NOW)
    assert credential_valid_at(cred, ts=0)
    assert credential_valid_at(cred, ts=NOW + 10_000_000)


def test_truncated_payload_is_fail_closed():
    # credential_valid_at must return False (not raise) for garbage payloads.
    cred = Credential(
        issuer_pk=b"\x00" * _k.PK_SIZE,
        signature=b"\x00" * _k.SIG_SIZE,
        payload=b"\x00" * 4,
    )
    assert not credential_valid_at(cred, ts=NOW)


# ── parse_payload ─────────────────────────────────────────────────────────────

def test_parse_payload_returns_correct_fields():
    child_pk = derive_public_key(child_identity())
    na       = NOW + 3600
    policy   = make_policy(resources=[b"/tasks"], actions=[b"write"], not_after=na)
    cred     = issue_credential(root_identity(), child_pk, policy, depth=1)
    p        = parse_payload(cred)

    assert p["child_pk"]   == child_pk
    assert p["role"]       == "leaf"
    assert p["depth"]      == 1
    assert p["perms"]      == [(b"/tasks", b"write")]
    assert p["not_before"] is None
    assert p["not_after"]  == na


def test_parse_payload_both_caveats():
    child_pk = derive_public_key(child_identity())
    nb       = NOW - 60
    na       = NOW + 3600
    policy   = make_policy(resources=[b"/x"], actions=[b"r"], not_before=nb, not_after=na)
    cred     = issue_credential(root_identity(), child_pk, policy, depth=1)
    p        = parse_payload(cred)
    assert p["not_before"] == nb
    assert p["not_after"]  == na


def test_parse_payload_no_caveats():
    child_pk = derive_public_key(child_identity())
    policy   = make_policy(resources=[b"/x"], actions=[b"r"])
    cred     = issue_credential(root_identity(), child_pk, policy, depth=1)
    p        = parse_payload(cred)
    assert p["not_before"] is None
    assert p["not_after"]  is None


def test_parse_payload_node_role():
    child_pk = derive_public_key(child_identity())
    policy   = make_policy(resources=[b"/x"], actions=[b"r"])
    cred     = issue_credential(root_identity(), child_pk, policy, depth=1, role="node")
    assert parse_payload(cred)["role"] == "node"


def test_parse_payload_multiple_permissions():
    child_pk = derive_public_key(child_identity())
    policy   = make_policy(resources=[b"/a", b"/b"], actions=[b"read", b"write"])
    cred     = issue_credential(root_identity(), child_pk, policy, depth=1)
    perms    = parse_payload(cred)["perms"]
    assert (b"/a", b"read")  in perms
    assert (b"/b", b"write") in perms


def test_parse_payload_truncated_payload_raises_value_error():
    cred = Credential(
        issuer_pk=b"\x00" * _k.PK_SIZE,
        signature=b"\x00" * _k.SIG_SIZE,
        payload=b"\x00" * 4,
    )
    with pytest.raises(ValueError):
        parse_payload(cred)


def test_parse_payload_roundtrip_consistent_with_explain():
    child_pk = derive_public_key(child_identity())
    na       = NOW + 3600
    policy   = make_policy(resources=[b"/tasks"], actions=[b"write"], not_after=na)
    cred     = issue_credential(root_identity(), child_pk, policy, depth=2)
    p        = parse_payload(cred)
    s        = explain_credential(cred)
    # Both paths use the same Rust parser — numeric fields must agree.
    assert f"depth={p['depth']}"         in s
    assert f"not_after={p['not_after']}" in s


# ── explain_credential ────────────────────────────────────────────────────────

def test_explain_contains_role_and_depth():
    cred = issue_credential(root_identity(), derive_public_key(child_identity()), simple_policy(), depth=3)
    s    = explain_credential(cred)
    assert "role=leaf" in s
    assert "depth=3"   in s


def test_explain_contains_permission_resource_and_verb():
    policy = make_policy(resources=[b"/tasks"], actions=[b"write"], hours_valid=1, now=NOW)
    cred   = issue_credential(root_identity(), derive_public_key(child_identity()), policy, depth=1)
    s      = explain_credential(cred)
    assert "/tasks" in s
    assert "write"  in s


def test_explain_contains_not_after_timestamp():
    ts     = NOW + 3600
    policy = make_policy(resources=[b"/x"], actions=[b"r"], not_after=ts)
    cred   = issue_credential(root_identity(), derive_public_key(child_identity()), policy, depth=1)
    assert f"not_after={ts}" in explain_credential(cred)


def test_explain_contains_not_before_timestamp():
    ts     = NOW - 10
    policy = make_policy(resources=[b"/x"], actions=[b"r"], not_before=ts)
    cred   = issue_credential(root_identity(), derive_public_key(child_identity()), policy, depth=1)
    assert f"not_before={ts}" in explain_credential(cred)


def test_explain_invalid_payload_returns_sentinel():
    cred = Credential(issuer_pk=b"", signature=b"", payload=b"\x00" * 2)
    assert explain_credential(cred) == "<invalid payload>"


def test_explain_node_role_shown():
    policy = simple_policy()
    cred   = issue_credential(root_identity(), derive_public_key(child_identity()), policy, depth=1, role="node")
    assert "role=node" in explain_credential(cred)


def test_explain_multiple_permissions():
    policy = make_policy(resources=[b"/a"], actions=[b"read"],
                         permissions=[(b"/b", b"write")])
    cred   = issue_credential(root_identity(), derive_public_key(child_identity()), policy, depth=1)
    s      = explain_credential(cred)
    assert "/a"    in s
    assert "read"  in s
    assert "/b"    in s
    assert "write" in s


# ── make_policy now= / time helpers ───────────────────────────────────────────

def test_make_policy_hours_valid_uses_injected_now():
    fixed_now = 1_000_000_000
    policy    = make_policy(resources=[b"/x"], actions=[b"r"], hours_valid=2, now=fixed_now)
    p         = parse_payload(
        issue_credential(root_identity(), derive_public_key(child_identity()), policy, depth=1)
    )
    assert p["not_after"] == fixed_now + 2 * 3600


def test_make_policy_minutes_valid_uses_injected_now():
    fixed_now = 1_000_000_000
    policy    = make_policy(resources=[b"/x"], actions=[b"r"], minutes_valid=30, now=fixed_now)
    p         = parse_payload(
        issue_credential(root_identity(), derive_public_key(child_identity()), policy, depth=1)
    )
    assert p["not_after"] == fixed_now + 30 * 60


def test_make_policy_without_time_bounds_produces_empty_caveats():
    p = make_policy(resources=[b"/x"], actions=[b"r"])
    assert p.caveats == b""


def test_make_policy_with_time_bound_produces_nonempty_caveats():
    p = make_policy(resources=[b"/x"], actions=[b"r"], hours_valid=1, now=NOW)
    assert len(p.caveats) > 0


def test_caveat_not_before_size_and_tag():
    c = caveat_not_before(b"", NOW)
    assert len(c) == 9
    assert c[0] == 0x01


def test_caveat_not_after_size_and_tag():
    c = caveat_not_after(b"", NOW + 3600)
    assert len(c) == 9
    assert c[0] == 0x02


def test_allow_accumulates_permissions():
    s1 = allow(b"", b"/a", b"r")
    s2 = allow(s1,  b"/b", b"w")
    assert len(s2) > len(s1)


def test_make_policy_same_now_produces_identical_credentials():
    fixed_now = 1_000_000_000
    child_pk  = derive_public_key(child_identity())
    policy1   = make_policy(resources=[b"/x"], actions=[b"r"], hours_valid=1, now=fixed_now)
    policy2   = make_policy(resources=[b"/x"], actions=[b"r"], hours_valid=1, now=fixed_now)
    cred1     = issue_credential(root_identity(), child_pk, policy1, depth=1)
    cred2     = issue_credential(root_identity(), child_pk, policy2, depth=1)
    assert cred1.payload   == cred2.payload
    assert cred1.signature == cred2.signature


# ── decode_chain — multi-hop consistency ─────────────────────────────────────

def test_decode_chain_two_hops_recovers_all_fields():
    root = root_identity()
    mid  = make_identity(MASTER, DEPLOYMENT, b"mid")
    leaf = make_identity(MASTER, DEPLOYMENT, b"leaf")

    chain   = delegate(root, derive_public_key(mid),  simple_policy(), role="node")
    chain   = delegate(mid,  derive_public_key(leaf), simple_policy(), parent_chain=chain)
    decoded = decode_chain(build_chain(chain))

    assert len(decoded) == 2
    assert decoded[0].issuer_pk == chain[0].issuer_pk
    assert decoded[1].issuer_pk == chain[1].issuer_pk
    assert decoded[0].payload   == chain[0].payload
    assert decoded[1].payload   == chain[1].payload


# ── Hard limits ───────────────────────────────────────────────────────────────

def test_chain_exceeding_max_depth_fails_at_issuance():
    # MAX_DEPTH is 16 (qhermes_kernel::MAX_DEPTH). Building the 17th link must
    # raise ChainTooDeep at issuance — the kernel enforces the limit before signing.
    MAX_DEPTH = 16
    identities = [make_identity(MASTER, DEPLOYMENT, str(i).encode()) for i in range(MAX_DEPTH + 2)]

    chain = delegate(identities[0], derive_public_key(identities[1]), simple_policy(), role="node")
    for i in range(1, MAX_DEPTH):
        chain = delegate(
            identities[i],
            derive_public_key(identities[i + 1]),
            simple_policy(),
            role="node",
            parent_chain=chain,
        )
    # The 17th hop (depth=17 > MAX_DEPTH=16) must be rejected at issuance.
    with pytest.raises(Exception):
        delegate(
            identities[MAX_DEPTH],
            derive_public_key(identities[MAX_DEPTH + 1]),
            simple_policy(),
            parent_chain=chain,
        )


# ── Scope escalation: verb mismatch ──────────────────────────────────────────

def test_child_verb_not_in_parent_scope_fails_verification():
    # Parent grants (/data, read). Child claims (/data, write).
    # The kernel must reject the chain at scope subset enforcement.
    root  = root_identity()
    mid   = make_identity(MASTER, DEPLOYMENT, b"mid")
    leaf  = make_identity(MASTER, DEPLOYMENT, b"leaf")

    parent_policy = make_policy(resources=[b"/data"], actions=[b"read"], hours_valid=1, now=NOW)
    child_policy  = make_policy(resources=[b"/data"], actions=[b"write"], hours_valid=1, now=NOW)

    chain = delegate(root, derive_public_key(mid),  parent_policy, role="node")
    chain = delegate(mid,  derive_public_key(leaf), child_policy,  parent_chain=chain)

    with pytest.raises(Exception):
        verify_chain(derive_public_key(root), build_chain(chain), now=NOW)
