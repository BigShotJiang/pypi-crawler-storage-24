import sys
import pathlib

# Add the pure-Python layer to sys.path so that `qhermes.kernel` is importable
# alongside the installed `qhermes_kernel` Rust extension.
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent / "python"))
