# Copyright (c) 2026 Copertino All rights reserved.
# SPDX-License-Identifier: LicenseRef-Copertino-1.0

from __future__ import annotations

import time
from collections.abc import Sequence
from typing import NamedTuple

import qhermes_kernel as _k

__all__ = [
    "Policy",
    "Credential",
    "allow",
    "caveat_not_before",
    "caveat_not_after",
    "make_policy",
    "make_identity",
    "derive_public_key",
    "issue_credential",
    "delegate",
    "build_chain",
    "verify_chain",
    "decode_chain",
    "credential_valid_at",
    "explain_credential",
    "parse_payload",
]


# ── Types ─────────────────────────────────────────────────────────────────────

class Policy(NamedTuple):
    """A validated scope + caveats bundle ready for credential issuance."""
    scope_tlv: bytes
    caveats:   bytes


class Credential(NamedTuple):
    """One link in a delegation chain."""
    issuer_pk: bytes   # PK_SIZE bytes
    signature: bytes   # SIG_SIZE bytes
    payload:   bytes


# ── Policy construction ───────────────────────────────────────────────────────

def allow(scope: bytes, resource: bytes, verb: bytes) -> bytes:
    """Append one (resource, verb) permission to a scope blob. Returns new scope bytes."""
    return scope + _k.perm_tlv(resource, verb)


def caveat_not_before(caveats: bytes, ts: int) -> bytes:
    """Append a not-before caveat to a caveats blob. ts is Unix epoch seconds."""
    return caveats + _k.not_before(ts)


def caveat_not_after(caveats: bytes, ts: int) -> bytes:
    """Append a not-after caveat to a caveats blob. ts is Unix epoch seconds."""
    return caveats + _k.not_after(ts)


def make_policy(
    resources:    list[bytes] | None = None,
    actions:      list[bytes] | None = None,
    *,
    permissions:  list[tuple[bytes, bytes]] | None = None,
    not_before:   int | None = None,
    not_after:    int | None = None,
    hours_valid:  float = 0,
    minutes_valid: float = 0,
    now:          int | None = None,
) -> Policy:
    """Build a Policy from permissions and optional time bounds.

    The standard form accepts two lists expanded as a cartesian product —
    every action is granted on every resource:

        make_policy(
            resources=[b"/data", b"/logs"],
            actions=[b"GET"],
            hours_valid=1,
        )

    For asymmetric permissions supply explicit (resource, verb) pairs:

        make_policy(
            permissions=[
                (b"/data",  b"GET"),
                (b"/admin", b"POST"),
            ],
            hours_valid=1,
        )

    Both forms may be combined. resources+actions covers the symmetric
    part of the grant; permissions adds the asymmetric exceptions. The scope
    encoded in the credential is the union of both sets:

        make_policy(
            resources=[b"/logs"], actions=[b"GET"],   # all logs, read-only
            permissions=[(b"/data", b"PUT")],         # one write target added
            hours_valid=4,
        )

    All time arguments are keyword-only. not_before / not_after accept absolute
    Unix epoch seconds. hours_valid / minutes_valid set not_after relative to now.
    now overrides the current time used for relative bounds (defaults to time.time()).

    Resource and verb values are opaque byte strings. The kernel compares them for
    exact equality — it does not interpret path separators, glob patterns, or any
    structure within the bytes. The only special value is b"*", which matches any
    single resource or verb during scope subset checks.
    """
    if (resources is None) != (actions is None):
        raise ValueError("resources and actions must be supplied together")
    pairs = [(r, a) for r in (resources or []) for a in (actions or [])] + (permissions or [])
    if not pairs:
        raise ValueError("policy requires at least one permission")

    scope: bytes = b""
    for resource, verb in pairs:
        scope = allow(scope, resource, verb)

    caveats: bytes = b""
    if not_before is not None:
        caveats = caveat_not_before(caveats, not_before)
    if not_after is None and (hours_valid or minutes_valid):
        not_after = int((now if now is not None else int(time.time())) + hours_valid * 3600 + minutes_valid * 60)
    if not_after is not None:
        caveats = caveat_not_after(caveats, not_after)

    return Policy(scope_tlv=scope, caveats=caveats)


# ── Identity ──────────────────────────────────────────────────────────────────

def make_identity(master: bytes, deployment: bytes, context: bytes) -> _k.IdentityIsland:
    """Derive an ML-DSA-65 identity from a 32-byte master seed."""
    return _k.IdentityIsland(master, deployment, context)


def derive_public_key(identity: _k.IdentityIsland) -> bytes:
    """Return the PK_SIZE-byte public key for an identity."""
    return identity.public_key()


# ── Credential issuance ───────────────────────────────────────────────────────

def issue_credential(
    identity:  _k.IdentityIsland,
    child_pk:  bytes,
    policy:    Policy,
    depth:     int,
    role:      str = "leaf",
) -> Credential:
    """Issue one credential and return it as an immutable Credential.

    issuer_pk is taken from identity. Use delegate() to issue and extend a chain in one call.
    """
    payload, sig = identity.issue_credential(
        child_pk,
        role,
        depth,
        policy.scope_tlv,
        policy.caveats,
    )
    return Credential(issuer_pk=identity.public_key(), signature=sig, payload=payload)


def delegate(
    identity:     _k.IdentityIsland,
    child_pk:     bytes,
    policy:       Policy,
    role:         str = "leaf",
    parent_chain: tuple[Credential, ...] = (),
) -> tuple[Credential, ...]:
    """Issue a credential and return an extended chain tuple.

    parent_chain is the existing chain (empty tuple for root issuance).
    depth is derived automatically from len(parent_chain) + 1.
    Returns a new tuple with the new credential appended — original is untouched.
    """
    depth = len(parent_chain) + 1
    cred = issue_credential(identity, child_pk, policy, depth, role)
    return (*parent_chain, cred)


# ── Chain wire encoding ───────────────────────────────────────────────────────

def build_chain(chain: Sequence[Credential]) -> bytes:
    """Encode a credential chain to wire bytes."""
    return _k.encode_chain([(c.issuer_pk, c.signature, c.payload) for c in chain])


def verify_chain(root_pk: bytes, wire: bytes, now: int | None = None) -> int:
    """Verify a wire-encoded chain against root_pk. Raises ValueError on failure.

    Returns the number of credentials. now defaults to current Unix time.
    """
    return _k.verify_delegation(root_pk, wire, now if now is not None else int(time.time()))


def decode_chain(wire: bytes) -> tuple[Credential, ...]:
    """Decode a wire-encoded chain. Does not verify signatures."""
    return tuple(Credential(pk, sig, payload) for pk, sig, payload in _k.decode_chain(wire))


# ── Payload inspection ────────────────────────────────────────────────────────

def parse_payload(cred: Credential) -> dict:
    """Deserialize a credential payload. Returns a dict with keys:
    child_pk, role, depth, perms (list of (resource, verb) tuples),
    not_before (int | None), not_after (int | None).
    Raises ValueError on truncated or structurally invalid payload.
    """
    return _k.parse_payload(cred.payload)


def credential_valid_at(cred: Credential, ts: int | None = None) -> bool:
    """Return True if cred's time caveats allow ts. Fail-closed on invalid payload."""
    if ts is None:
        ts = int(time.time())
    try:
        p = _k.parse_payload(cred.payload)
    except ValueError:
        return False
    nb = p.get("not_before")
    na = p.get("not_after")
    if nb is not None and ts < nb:
        return False
    if na is not None and ts > na:
        return False
    return True


def explain_credential(cred: Credential) -> str:
    """Return a human-readable summary of a credential's payload."""
    try:
        p = _k.parse_payload(cred.payload)
    except ValueError:
        return "<invalid payload>"
    parts = [
        f"role={p.get('role', '?')}",
        f"depth={p.get('depth', '?')}",
        f"child_pk={p['child_pk'].hex()[:16]}..." if p.get('child_pk') else "child_pk=?",
    ]
    for resource, verb in p.get("perms", []):
        parts.append(f"allow({resource!r},{verb!r})")
    if p.get("not_before") is not None:
        parts.append(f"not_before={p['not_before']}")
    if p.get("not_after") is not None:
        parts.append(f"not_after={p['not_after']}")
    return " ".join(parts)
