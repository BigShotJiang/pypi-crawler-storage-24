# Copyright (c) 2026 Copertino All rights reserved.
# SPDX-License-Identifier: LicenseRef-Copertino-1.0
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)
