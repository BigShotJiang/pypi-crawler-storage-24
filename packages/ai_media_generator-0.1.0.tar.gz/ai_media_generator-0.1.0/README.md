# ai-media-generator

这个包是 `ai-media` Rust CLI 的 PyPI thin wrapper。

## Install

```bash
pipx install ai-media-generator
uv tool install ai-media-generator
```

## Usage

```bash
ai-media --help
uvx ai-media-generator --help
python -m ai_media_cli --help
```
