"""CrewAI guardrail integration for Antarraksha enforcement."""

from typing import Any, Dict, List, Optional

from .client import AntarakshaClient


class AntarakshaGuardrail:
    """Antarraksha enforcement guardrail for CrewAI agents.

    Usage:
        from antarraksha_crewai import AntarakshaGuardrail

        guardrail = AntarakshaGuardrail(
            base_url="https://antarraksha.ai",
            agent_id="my-crew-agent",
            passport_id="ANTK-PASS-xxx",
        )

        # In CrewAI task callback
        @guardrail.enforce
        def my_task_callback(output):
            return output
    """

    def __init__(
        self,
        base_url: str = "https://antarraksha.ai",
        agent_id: Optional[str] = None,
        passport_id: Optional[str] = None,
        sdk_key: Optional[str] = None,
        fail_closed: bool = True,
    ):
        self.client = AntarakshaClient(
            base_url=base_url,
            agent_id=agent_id,
            passport_id=passport_id,
            sdk_key=sdk_key,
            framework="crewai",
            fail_closed=fail_closed,
        )
        if not sdk_key and agent_id and passport_id:
            try:
                self.client.register(capabilities=["crewai_agent"])
            except Exception:
                pass

    def check_tool_call(self, tool_name: str, parameters: Optional[Dict] = None) -> Dict[str, Any]:
        return self.client.intercept(
            call_type="tool_call",
            call_name=tool_name,
            parameters=parameters or {},
        )

    def check_llm_call(self, model_name: str, prompt_length: int = 0) -> Dict[str, Any]:
        return self.client.intercept(
            call_type="llm_call",
            call_name=model_name,
            parameters={"prompt_length": prompt_length},
        )

    def check_delegation(self, from_role: str, to_role: str, task_description: str = "") -> Dict[str, Any]:
        return self.client.intercept(
            call_type="delegation",
            call_name=f"{from_role}_to_{to_role}",
            parameters={"from_role": from_role, "to_role": to_role, "task_desc_length": len(task_description)},
        )

    def enforce(self, func):
        """Decorator that enforces Antarraksha policy on a CrewAI task callback."""
        def wrapper(*args, **kwargs):
            result = self.client.intercept(
                call_type="task_execution",
                call_name=func.__name__,
                parameters={"args_count": len(args), "kwargs_keys": list(kwargs.keys())},
            )
            if result.get("decision") == "DENY":
                raise PermissionError(
                    f"Antarraksha denied task '{func.__name__}': {result.get('reason', 'Policy violation')}"
                )
            return func(*args, **kwargs)
        return wrapper
