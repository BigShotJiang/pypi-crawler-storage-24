"""CLI integration tests package."""
