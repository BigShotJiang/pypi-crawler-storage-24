# Multi-Agent Orchestration

Flowly's multi-agent system delegates tasks to external CLI-based AI agents (Claude Code, Codex, Gemini CLI, OpenCode, Droid) and orchestrates team collaboration through chain execution and fan-out patterns.

## Architecture

```
User message
     │
     ▼
┌─────────────┐     @mention?     ┌──────────────┐
│  AgentLoop  │ ───────────────── │  AgentRouter  │
│  (main LLM) │                   │  (routing)    │
└──────┬──────┘                   └───────┬───────┘
       │                                  │
       │  delegate_to()                   │  route()
       ▼                                  ▼
┌──────────────┐               ┌───────────────────┐
│ DelegateTool │               │ TeamOrchestrator   │
│ (fire&forget)│               │ (chain + fan-out)  │
└──────┬───────┘               └─────────┬─────────┘
       │                                 │
       ▼                                 ▼
┌──────────────────────────────────────────────┐
│              invoke_agent()                   │
│  Spawns CLI subprocess per provider:          │
│  claude / codex / gemini / opencode / droid   │
└──────────────────────────────────────────────┘
```

## Key Concepts

### Agents vs AgentLoop

These are fundamentally different:

| | AgentLoop | Configured Agents |
|---|---|---|
| **What** | Main LLM processing engine | CLI subprocess instances |
| **Lifetime** | Long-lived, handles all messages | Short-lived, one task per invocation |
| **Provider** | Single LiteLLM provider | Each agent has its own provider/model |
| **Invocation** | Runs continuously in-process | Spawned as `claude -p "..."`, `codex exec "..."`, etc. |
| **Tools** | Full tool registry (web, file, exec, MCP, ...) | Only what the CLI tool provides |
| **Communication** | Message bus | `[@agent_id: message]` tag format in responses |

### Execution Patterns

#### 1. Direct Delegation (fire-and-forget)

The main AgentLoop calls `delegate_to(agent_id, message)`. The subprocess runs in the background, and the result is delivered asynchronously via the message bus.

```
User: "fix the login bug"
  → AgentLoop calls delegate_to("coder", "fix the login bug")
  → Returns immediately: "Task delegated to @coder..."
  → Background: claude --model opus -p "fix the login bug"
  → When done: result sent back through bus → AgentLoop summarizes
```

#### 2. Team Chain (sequential handoff)

When routed via `@team`, the leader agent is invoked first. If its response contains a `[@teammate: message]` tag, the orchestrator detects it and invokes that teammate with the message. The chain continues until no teammate is mentioned or `MAX_CHAIN_DEPTH` (10) is reached.

```
User: "@dev fix and review the auth module"
  → Router: @dev → team leader "coder"
  → Step 1: invoke coder → response contains [@reviewer: check this PR]
  → Step 2: invoke reviewer with coder's message
  → Step 3: reviewer responds (no mention) → chain ends
  → Final: all step responses combined
```

#### 3. Fan-out (parallel execution)

If an agent's response mentions multiple teammates (via tag format), all are invoked in parallel. The chain ends after fan-out.

```
Step 1: invoke leader
  → Response: [@coder: implement feature] [@tester: write tests]
Step 2: invoke coder AND tester in parallel (asyncio.gather)
  → Both responses collected
  → Chain ends
```

## Files

| File | Purpose |
|------|---------|
| `router.py` | `@mention` parsing, message routing, teammate validation |
| `orchestrator.py` | Team chain execution, fan-out, depth limiting |
| `invoke.py` | CLI subprocess spawning per provider (claude, codex, gemini, ...) |
| `setup.py` | Agent directory initialization, `AGENTS.md` / `CLAUDE.md` generation |

## Module Details

### router.py — AgentRouter

Parses `@agent_id` or `@team_id` prefixes from incoming messages and routes to the correct agent.

**Routing priority:**
1. `@agent_id` → direct agent match
2. `@team_id` → team leader agent
3. `@agent_name` → case-insensitive name match
4. `@team_name` → case-insensitive team name match
5. No prefix → default agent (main AgentLoop handles it)

**Teammate mention extraction** from agent responses supports two formats:
- **Tag format** (preferred): `[@agent_id: message here]` — supports multiple mentions
- **Bare format** (fallback): `@agent_id` — first valid match only

### orchestrator.py — TeamOrchestrator

Executes the chain/fan-out logic:

```python
result = await orchestrator.execute(
    message="fix the auth bug",
    agent_id="coder",
    team_context=TeamContext(team_id="dev", team=team_config),
    agents=all_agents,
    workspace=workspace_path,
)
# result.steps = [ChainStep("coder", "..."), ChainStep("reviewer", "...")]
# result.final_response = combined output
```

**Chain rules:**
- Max depth: 10 steps (configurable via `MAX_CHAIN_DEPTH`)
- Single mention → sequential handoff (next agent gets `[Message from teammate @prev]:`)
- Multiple mentions → parallel fan-out (all invoked via `asyncio.gather`)
- Fan-out terminates the chain (no further handoffs)
- Errors are caught per-agent and included in results

### invoke.py — CLI Subprocess Invocation

Each provider maps to a specific CLI tool:

| Provider | CLI Command | Key Flags |
|----------|-------------|-----------|
| `anthropic` | `claude` | `--dangerously-skip-permissions`, `--model`, `-c` (continue), `--append-system-prompt`, `--add-dir` |
| `openai` | `codex exec` | `--skip-git-repo-check`, `--dangerously-bypass-approvals-and-sandbox`, `--json` |
| `gemini` | `gemini` | `--model`, `-p` |
| `opencode` | `opencode run` | `--model` |
| `droid` | `droid exec` | `--auto high`, `--model` |

**Model resolution:** Short names are resolved to full IDs:
- `sonnet` → `claude-sonnet-4-5`
- `opus` → `claude-opus-4-6`
- `haiku` → `claude-haiku-4-5`
- `gpt-5.3-codex` → `gpt-5.3-codex`

**Timeout:** 1800 seconds (30 minutes) per invocation.

**Codex output:** Parsed from JSONL format — extracts the final `agent_message` from `item.completed` events.

### setup.py — Agent Directory Setup

Creates `~/.flowly/workspace/agents/{agent_id}/` with:

```
agents/{agent_id}/
├── AGENTS.md           # Team communication instructions
└── .claude/
    └── CLAUDE.md       # Teammate list for Claude Code
```

**AGENTS.md** contains:
- Instructions explaining the `[@agent_id: message]` tag system
- List of teammates with their IDs and models
- Rules for single/parallel/chain communication

Teammate lists are updated between `<!-- TEAMMATES_START -->` / `<!-- TEAMMATES_END -->` markers, so manual edits outside those markers are preserved.

## Configuration

```json
{
  "agents": {
    "defaults": {
      "model": "anthropic/claude-sonnet-4-5",
      "workspace": "~/.flowly/workspace"
    },
    "agents": {
      "coder": {
        "name": "Code Assistant",
        "provider": "anthropic",
        "model": "opus",
        "persona": ""
      },
      "reviewer": {
        "name": "Code Reviewer",
        "provider": "openai",
        "model": "gpt-5.3-codex",
        "workingDirectory": "~/projects"
      }
    },
    "teams": {
      "dev": {
        "name": "Development Team",
        "agents": ["coder", "reviewer"],
        "leader_agent": "coder"
      }
    }
  }
}
```

### Agent Fields

| Field | Description | Default |
|-------|-------------|---------|
| `name` | Display name | agent ID |
| `provider` | `anthropic`, `openai`, `gemini`, `opencode`, `droid` | `anthropic` |
| `model` | Short name or full model ID | — |
| `working_directory` | Where the CLI runs | `$HOME` |
| `persona` | Agent persona | — |

### Team Fields

| Field | Description |
|-------|-------------|
| `name` | Team display name |
| `agents` | List of agent IDs in the team |
| `leader_agent` | Agent that receives `@team` messages first |

## Integration with AgentLoop

The multi-agent system connects to the main AgentLoop through `DelegateTool`:

```python
# In cli/commands.py gateway() setup:
from flowly_code.multiagent.router import AgentRouter
from flowly_code.multiagent.orchestrator import TeamOrchestrator
from flowly_code.agent.tools.delegate import DelegateTool

router = AgentRouter(agents, teams)
orchestrator = TeamOrchestrator(router)

# Setup agent directories with AGENTS.md
for agent_id, cfg in agents.items():
    ensure_agent_directory(workspace / agent_id, agent_id, agents, teams)

# Register delegate_to tool on main agent
delegate_tool = DelegateTool(agents, teams, workspace, bus)
agent.tools.register(delegate_tool)
```

When a `[DELEGATE_RESULT:agent_id]` message comes back through the bus, the routing layer temporarily removes `delegate_to` from the tool registry to prevent infinite re-delegation loops.
