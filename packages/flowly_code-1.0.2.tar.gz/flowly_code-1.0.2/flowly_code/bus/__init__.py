"""Message bus module for decoupled channel-agent communication."""

from flowly_code.bus.events import InboundMessage, OutboundMessage
from flowly_code.bus.queue import MessageBus

__all__ = ["MessageBus", "InboundMessage", "OutboundMessage"]
