"""Cron tool for scheduling tasks from agent."""

import time
from datetime import datetime, timedelta
from typing import Any, Literal

from loguru import logger

from flowly_code.agent.tools.base import Tool
from flowly_code.cron.service import CronService
from flowly_code.cron.types import CronSchedule


def _parse_duration(duration: str) -> int | None:
    """Parse a human-readable duration string to milliseconds."""
    if not duration:
        return None
    duration = duration.strip().lower()
    try:
        if duration.endswith("s"):
            return int(duration[:-1]) * 1000
        elif duration.endswith("m"):
            return int(duration[:-1]) * 60 * 1000
        elif duration.endswith("h"):
            return int(duration[:-1]) * 60 * 60 * 1000
        elif duration.endswith("d"):
            return int(duration[:-1]) * 24 * 60 * 60 * 1000
        elif duration.endswith("w"):
            return int(duration[:-1]) * 7 * 24 * 60 * 60 * 1000
        else:
            return int(duration) * 1000
    except ValueError:
        return None


def _parse_time(time_str: str) -> int | None:
    """Parse a time string to timestamp in milliseconds."""
    if not time_str:
        return None
    time_str = time_str.strip().lower()
    now = datetime.now()
    try:
        if time_str.startswith("+"):
            duration_ms = _parse_duration(time_str[1:])
            if duration_ms:
                return int(time.time() * 1000) + duration_ms
            return None
        if time_str.startswith("tomorrow"):
            time_part = time_str.replace("tomorrow", "").strip()
            if time_part:
                hour, minute = map(int, time_part.split(":"))
                target = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
                target += timedelta(days=1)
                return int(target.timestamp() * 1000)
        if ":" in time_str and len(time_str) <= 5:
            hour, minute = map(int, time_str.split(":"))
            target = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
            if target <= now:
                target += timedelta(days=1)
            return int(target.timestamp() * 1000)
        for fmt in ["%Y-%m-%d %H:%M", "%Y-%m-%dT%H:%M", "%Y-%m-%d"]:
            try:
                dt = datetime.strptime(time_str, fmt)
                return int(dt.timestamp() * 1000)
            except ValueError:
                continue
        return None
    except Exception:
        return None


def _format_next_run(timestamp_ms: int | None) -> str:
    """Format a timestamp for display."""
    if not timestamp_ms:
        return "not scheduled"
    dt = datetime.fromtimestamp(timestamp_ms / 1000)
    now = datetime.now()
    diff = dt - now
    if diff.total_seconds() < 0:
        return "overdue"
    elif diff.total_seconds() < 60:
        return f"in {int(diff.total_seconds())}s"
    elif diff.total_seconds() < 3600:
        return f"in {int(diff.total_seconds() / 60)}m"
    elif diff.total_seconds() < 86400:
        return f"in {int(diff.total_seconds() / 3600)}h"
    else:
        return dt.strftime("%Y-%m-%d %H:%M")


class CronTool(Tool):
    """Tool for managing scheduled tasks."""

    def __init__(self, cron_service: CronService | None = None):
        self._cron_service = cron_service
        self._default_channel: str = ""
        self._default_chat_id: str = ""

    def set_cron_service(self, service: CronService) -> None:
        self._cron_service = service

    def set_context(self, channel: str, chat_id: str) -> None:
        self._default_channel = channel
        self._default_chat_id = chat_id

    @property
    def name(self) -> str:
        return "cron"

    @property
    def description(self) -> str:
        return (
            "Manage scheduled tasks and reminders. "
            "Use 'list' to see jobs, 'add' to create new ones, 'remove' to delete. "
            "Schedules: 'every 30m', 'every 1d', 'at 14:30', 'at tomorrow 09:00', "
            "or cron expressions like '0 9 * * *'. "
            "For deterministic scheduled actions, use tool_name + tool_args."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["list", "add", "remove", "enable", "disable", "status"],
                    "description": "Action to perform"
                },
                "name": {"type": "string", "description": "Job name (for 'add' action)"},
                "message": {"type": "string", "description": "Message/prompt to execute when job runs (for 'add')"},
                "schedule": {
                    "type": "string",
                    "description": "Schedule: 'every 30m', 'at 14:30', 'at tomorrow 09:00', or cron '0 9 * * *'"
                },
                "job_id": {"type": "string", "description": "Job ID (for 'remove', 'enable', 'disable')"},
                "deliver": {"type": "boolean", "description": "Whether to deliver result to chat (default: false)"},
                "channel": {"type": "string", "description": "Channel to deliver to (e.g., 'telegram')"},
                "to": {"type": "string", "description": "Chat ID to deliver to"},
                "tool_name": {"type": "string", "description": "Optional tool to execute directly when job runs"},
                "tool_args": {"type": "object", "description": "Arguments for tool_name"},
            },
            "required": ["action"]
        }

    async def execute(self, action: str, **kwargs: Any) -> str:
        if not self._cron_service:
            return "Error: Cron service not available"
        try:
            if action == "list":
                return self._list_jobs()
            elif action == "add":
                return await self._add_job(**kwargs)
            elif action == "remove":
                return self._remove_job(kwargs.get("job_id"))
            elif action == "enable":
                return self._enable_job(kwargs.get("job_id"), True)
            elif action == "disable":
                return self._enable_job(kwargs.get("job_id"), False)
            elif action == "status":
                return self._get_status()
            else:
                return f"Error: Unknown action '{action}'"
        except Exception as e:
            logger.error(f"Cron tool error: {e}")
            return f"Error: {str(e)}"

    def _list_jobs(self) -> str:
        jobs = self._cron_service.list_jobs(include_disabled=True)
        if not jobs:
            return "No scheduled jobs."
        lines = ["Scheduled Jobs:", ""]
        for job in jobs:
            status = "+" if job.enabled else "-"
            next_run = _format_next_run(job.state.next_run_at_ms)
            if job.schedule.kind == "every":
                ms = job.schedule.every_ms or 0
                if ms >= 3600000:
                    sched = f"every {ms // 3600000}h"
                elif ms >= 60000:
                    sched = f"every {ms // 60000}m"
                else:
                    sched = f"every {ms // 1000}s"
            elif job.schedule.kind == "cron":
                sched = f"cron: {job.schedule.expr}"
            elif job.schedule.kind == "at":
                if job.state.next_run_at_ms:
                    dt = datetime.fromtimestamp(job.state.next_run_at_ms / 1000)
                    sched = f"at {dt.strftime('%Y-%m-%d %H:%M')}"
                else:
                    sched = "one-time (done)"
            else:
                sched = "unknown"
            lines.append(f"[{status}] {job.id}: {job.name}")
            lines.append(f"    Schedule: {sched} | Next: {next_run}")
            lines.append(f"    Message: {job.payload.message[:50]}...")
            lines.append("")
        return "\n".join(lines)

    async def _add_job(self, **kwargs: Any) -> str:
        name = kwargs.get("name")
        message = kwargs.get("message")
        schedule = kwargs.get("schedule")
        deliver = kwargs.get("deliver", False)
        channel = kwargs.get("channel")
        to = kwargs.get("to")
        tool_name = kwargs.get("tool_name")
        tool_args = kwargs.get("tool_args")

        if not name:
            return "Error: 'name' is required"
        if not schedule:
            return "Error: 'schedule' is required"

        payload_kind: Literal["agent_turn", "tool_call"] = "agent_turn"
        if tool_name:
            payload_kind = "tool_call"
            message = message or f"Run tool '{tool_name}'"
        elif not message:
            return "Error: 'message' is required"

        schedule_obj = self._parse_schedule(schedule)
        if not schedule_obj:
            return f"Error: Invalid schedule '{schedule}'"

        if deliver:
            channel = channel or self._default_channel or None
            to = to or self._default_chat_id or None

        job = self._cron_service.add_job(
            name=name, schedule=schedule_obj, message=message,
            deliver=deliver, channel=channel, to=to,
            delete_after_run=(schedule_obj.kind == "at"),
            payload_kind=payload_kind, tool_name=tool_name, tool_args=tool_args,
        )
        next_run = _format_next_run(job.state.next_run_at_ms)
        return f"Created job '{job.name}' (ID: {job.id})\nSchedule: {schedule}\nNext run: {next_run}"

    def _parse_schedule(self, schedule: str) -> CronSchedule | None:
        schedule = schedule.strip()
        if schedule.lower().startswith("every "):
            duration_ms = _parse_duration(schedule[6:].strip())
            if duration_ms:
                return CronSchedule(kind="every", every_ms=duration_ms)
            return None
        if schedule.lower().startswith("at "):
            timestamp_ms = _parse_time(schedule[3:].strip())
            if timestamp_ms:
                return CronSchedule(kind="at", at_ms=timestamp_ms)
            return None
        parts = schedule.split()
        if len(parts) == 5:
            try:
                from croniter import croniter
                croniter(schedule)
                return CronSchedule(kind="cron", expr=schedule)
            except Exception:
                return None
        return None

    def _remove_job(self, job_id: str | None) -> str:
        if not job_id:
            return "Error: 'job_id' is required"
        if self._cron_service.remove_job(job_id):
            return f"Removed job {job_id}"
        return f"Job {job_id} not found"

    def _enable_job(self, job_id: str | None, enable: bool) -> str:
        if not job_id:
            return f"Error: 'job_id' is required"
        job = self._cron_service.enable_job(job_id, enabled=enable)
        if job:
            return f"Job '{job.name}' ({job_id}) {'enabled' if enable else 'disabled'}"
        return f"Job {job_id} not found"

    def _get_status(self) -> str:
        status = self._cron_service.status()
        lines = [
            "Cron Service Status:",
            f"  Running: {'yes' if status['enabled'] else 'no'}",
            f"  Total jobs: {status['jobs']}",
        ]
        if status.get("next_wake_at_ms"):
            lines.append(f"  Next job: {_format_next_run(status['next_wake_at_ms'])}")
        return "\n".join(lines)
