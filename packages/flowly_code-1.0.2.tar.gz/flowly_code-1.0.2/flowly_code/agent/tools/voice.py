"""Voice call tool for making and managing phone calls."""

from typing import Any, TYPE_CHECKING

from loguru import logger

from flowly_code.agent.tools.base import Tool

if TYPE_CHECKING:
    from flowly_code.voice.plugin import VoicePlugin


class VoiceCallTool(Tool):
    """Tool to make and manage voice calls via the integrated voice plugin."""

    def __init__(self, voice_plugin: "VoicePlugin | None" = None):
        self._voice_plugin = voice_plugin
        self._telegram_chat_id: str | None = None

    def set_voice_plugin(self, voice_plugin: "VoicePlugin"):
        self._voice_plugin = voice_plugin

    def set_context(self, channel: str, chat_id: str):
        if channel == "telegram":
            self._telegram_chat_id = chat_id

    @property
    def name(self) -> str:
        return "voice_call"

    @property
    def description(self) -> str:
        return (
            "Make and manage voice phone calls. "
            "Actions: call, speak, end_call, list_calls. "
            "Phone numbers should be E.164 format (+1234567890)."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["call", "speak", "end_call", "list_calls"],
                    "description": "The action to perform",
                },
                "to": {"type": "string", "description": "Phone number to call (for action=call)"},
                "greeting": {"type": "string", "description": "Initial greeting message (for action=call)"},
                "script": {"type": "string", "description": "Full first message/script (for action=call)"},
                "message": {"type": "string", "description": "Message to speak (for action=speak, end_call)"},
                "call_sid": {"type": "string", "description": "Call SID (for speak, end_call)"},
            },
            "required": ["action"],
        }

    async def execute(self, action: str, **kwargs: Any) -> str:
        if not self._voice_plugin:
            return "Error: Voice plugin is not enabled. Configure it in ~/.flowly/config.json under integrations.voice"
        try:
            if action == "call":
                return await self._make_call(
                    to=kwargs.get("to", ""),
                    greeting=kwargs.get("greeting"),
                    script=kwargs.get("script"),
                )
            elif action == "speak":
                return await self._speak(kwargs.get("call_sid", ""), kwargs.get("message", ""))
            elif action == "end_call":
                return await self._end_call(kwargs.get("call_sid", ""), kwargs.get("message"))
            elif action == "list_calls":
                return await self._list_calls()
            else:
                return f"Unknown action: {action}"
        except Exception as e:
            logger.error(f"Voice call error: {e}")
            return f"Error: {str(e)}"

    async def _make_call(self, to: str, greeting: str | None = None, script: str | None = None) -> str:
        to_number = str(to or "").strip()
        if not to_number:
            plugin_config = getattr(self._voice_plugin, "config", None)
            voice_cfg = getattr(getattr(plugin_config, "integrations", None), "voice", None)
            to_number = str(getattr(voice_cfg, "default_to_number", "") or "").strip()
        if not to_number:
            return "Error: 'to' phone number is required"
        if to_number[0].isdigit():
            to_number = f"+{to_number}"

        initial_greeting = (greeting or script or "Hello!").strip()
        call_sid = await self._voice_plugin.make_call(
            to_number=to_number,
            telegram_chat_id=self._telegram_chat_id,
            greeting=initial_greeting,
        )
        return f"Call initiated! SID: {call_sid}, To: {to_number}"

    async def _speak(self, call_sid: str, message: str) -> str:
        if not call_sid:
            return "Error: 'call_sid' is required"
        if not message:
            return "Error: 'message' is required"
        call = self._voice_plugin.call_manager.get_call(call_sid)
        if not call:
            return f"Error: Call not found: {call_sid}"
        await self._voice_plugin.call_manager.speak(call_sid, message)
        return f"Speaking on call {call_sid}: \"{message}\""

    async def _end_call(self, call_sid: str, message: str | None = None) -> str:
        if not call_sid:
            return "Error: 'call_sid' is required"
        await self._voice_plugin.end_call(call_sid, message)
        return f"Call {call_sid} ended."

    async def _list_calls(self) -> str:
        calls = self._voice_plugin.call_manager.list_active_calls()
        if not calls:
            return "No active calls."
        lines = ["Active Calls:"]
        for call in calls:
            lines.append(f"  {call.call_sid}: {call.from_number} -> {call.to_number} ({call.status})")
        return "\n".join(lines)
