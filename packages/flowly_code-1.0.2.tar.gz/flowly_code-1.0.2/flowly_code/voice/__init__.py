"""Integrated voice system for Flowly.

This module provides voice call handling integrated directly into the agent,
allowing full tool access during voice conversations.

Note: Voice features require the `audioop` module (removed in Python 3.13+).
Install `audioop-lts` for Python 3.13+ compatibility.
"""

try:
    from .types import CallState, CallStatus, VoiceCall, STTResult
    from .call_manager import CallManager
    from .webhook import create_voice_app, TwilioClient
    from .plugin import VoicePlugin
    from .stt import STTProvider, create_stt_provider
    from .tts import TTSProvider, create_tts_provider

    __all__ = [
        "CallState",
        "CallStatus",
        "VoiceCall",
        "STTResult",
        "CallManager",
        "VoicePlugin",
        "STTProvider",
        "TTSProvider",
        "create_stt_provider",
        "create_tts_provider",
        "create_voice_app",
        "TwilioClient",
    ]
    _VOICE_AVAILABLE = True
except ImportError:
    _VOICE_AVAILABLE = False
    __all__ = []
