"""Telegram channel implementation using python-telegram-bot."""

import asyncio
import mimetypes
import re
from pathlib import Path

from loguru import logger
import httpx
from telegram import Update, InputFile, BotCommand, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, MessageHandler, CommandHandler, CallbackQueryHandler, filters, ContextTypes

from flowly_code.bus.events import InboundMessage, OutboundMessage
from flowly_code.bus.queue import MessageBus
from flowly_code.channels.base import BaseChannel
from flowly_code.config.schema import TelegramConfig
from flowly_code.pairing.store import upsert_pairing_request, read_allow_from_store


# Supported image MIME types for Telegram photos
TELEGRAM_PHOTO_TYPES = {"image/jpeg", "image/png", "image/gif", "image/webp"}

# Maximum caption length for Telegram
MAX_CAPTION_LENGTH = 1024


def _markdown_to_telegram_html(text: str) -> str:
    """
    Convert markdown to Telegram-safe HTML.
    """
    if not text:
        return ""

    # 1. Extract and protect code blocks (preserve content from other processing)
    code_blocks: list[str] = []
    def save_code_block(m: re.Match) -> str:
        code_blocks.append(m.group(1))
        return f"\x00CB{len(code_blocks) - 1}\x00"

    text = re.sub(r'```[\w]*\n?([\s\S]*?)```', save_code_block, text)

    # 2. Extract and protect inline code
    inline_codes: list[str] = []
    def save_inline_code(m: re.Match) -> str:
        inline_codes.append(m.group(1))
        return f"\x00IC{len(inline_codes) - 1}\x00"

    text = re.sub(r'`([^`]+)`', save_inline_code, text)

    # 3. Headers # Title -> just the title text
    text = re.sub(r'^#{1,6}\s+(.+)$', r'\1', text, flags=re.MULTILINE)

    # 4. Blockquotes > text -> just the text (before HTML escaping)
    text = re.sub(r'^>\s*(.*)$', r'\1', text, flags=re.MULTILINE)

    # 5. Escape HTML special characters
    text = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    # 6. Links [text](url) - must be before bold/italic to handle nested cases
    text = re.sub(r'\[([^\]]+)\]\(([^)]+)\)', r'<a href="\2">\1</a>', text)

    # 7. Bold **text** or __text__
    text = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', text)
    text = re.sub(r'__(.+?)__', r'<b>\1</b>', text)

    # 8. Italic _text_ (avoid matching inside words like some_var_name)
    text = re.sub(r'(?<![a-zA-Z0-9])_([^_]+)_(?![a-zA-Z0-9])', r'<i>\1</i>', text)

    # 9. Strikethrough ~~text~~
    text = re.sub(r'~~(.+?)~~', r'<s>\1</s>', text)

    # 10. Bullet lists - item -> bullet item
    text = re.sub(r'^[-*]\s+', '\u2022 ', text, flags=re.MULTILINE)

    # 11. Restore inline code with HTML tags
    for i, code in enumerate(inline_codes):
        # Escape HTML in code content
        escaped = code.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        text = text.replace(f"\x00IC{i}\x00", f"<code>{escaped}</code>")

    # 12. Restore code blocks with HTML tags
    for i, code in enumerate(code_blocks):
        # Escape HTML in code content
        escaped = code.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        text = text.replace(f"\x00CB{i}\x00", f"<pre><code>{escaped}</code></pre>")

    return text


def _is_image_file(path: Path) -> bool:
    """Check if a file is an image that can be sent as a Telegram photo."""
    mime_type, _ = mimetypes.guess_type(str(path))
    if mime_type in TELEGRAM_PHOTO_TYPES:
        return True
    # Also check by extension for common cases
    return path.suffix.lower() in {".jpg", ".jpeg", ".png", ".gif", ".webp"}


def _truncate_caption(text: str, max_length: int = MAX_CAPTION_LENGTH) -> str:
    """Truncate text to fit Telegram's caption limit."""
    if len(text) <= max_length:
        return text
    return text[:max_length - 3] + "..."


class TelegramChannel(BaseChannel):
    """
    Telegram channel using long polling.

    Supports:
    - Text messages with markdown formatting
    - Photo/image sending with captions
    - Document sending
    - Typing indicators

    Simple and reliable - no webhook/public IP needed.
    """

    name = "telegram"

    # Native bot commands
    NATIVE_COMMANDS = [
        BotCommand("new", "Start a new conversation"),
        BotCommand("projects", "Select active project"),
        BotCommand("tasks", "List tasks in active project"),
        BotCommand("newtask", "Create a new task"),
        BotCommand("deltask", "Delete a task"),
        BotCommand("status", "Kanban board summary"),
        BotCommand("ralph", "Start Ralph AI coding"),
        BotCommand("ralph_stop", "Stop Ralph session"),
        BotCommand("compact", "Summarize conversation"),
        BotCommand("clear", "Clear session history"),
        BotCommand("help", "Show available commands"),
    ]

    def __init__(self, config: TelegramConfig, bus: MessageBus, groq_api_key: str | None = None, dispatch_config=None):
        super().__init__(config, bus)
        self.config: TelegramConfig = config
        self._app: Application | None = None
        self._chat_ids: dict[str, int] = {}  # Map sender_id to chat_id for replies
        self._compact_callback: callable | None = None  # Set by gateway
        self._typing_tasks: dict[int, asyncio.Task] = {}  # Active typing indicators per chat
        self._groq_api_key = groq_api_key  # For voice transcription
        self._dispatch_config = dispatch_config  # Dispatch App integration
        self._active_projects: dict[int, dict] = {}  # chat_id -> {id, name}

    async def start(self) -> None:
        """Start the Telegram bot with long polling."""
        if not self.config.token:
            logger.error("Telegram bot token not configured")
            return

        self._running = True

        # Build the application
        self._app = (
            Application.builder()
            .token(self.config.token)
            .build()
        )

        # Add message handler for text, photos, voice, documents
        self._app.add_handler(
            MessageHandler(
                (filters.TEXT | filters.PHOTO | filters.VOICE | filters.AUDIO | filters.Document.ALL)
                & ~filters.COMMAND,
                self._on_message
            )
        )

        # Add command handlers
        self._app.add_handler(CommandHandler("start", self._on_start))
        self._app.add_handler(CommandHandler("compact", self._on_compact))
        self._app.add_handler(CommandHandler("new", self._on_new))
        self._app.add_handler(CommandHandler("clear", self._on_clear))
        self._app.add_handler(CommandHandler("help", self._on_help))
        # Dispatch commands
        self._app.add_handler(CommandHandler("projects", self._on_projects))
        self._app.add_handler(CommandHandler("tasks", self._on_tasks))
        self._app.add_handler(CommandHandler("newtask", self._on_newtask))
        self._app.add_handler(CommandHandler("deltask", self._on_deltask))
        self._app.add_handler(CommandHandler("status", self._on_status))
        self._app.add_handler(CommandHandler("ralph", self._on_ralph))
        self._app.add_handler(CommandHandler("ralph_stop", self._on_ralph_stop))
        # Inline keyboard callback handler
        self._app.add_handler(CallbackQueryHandler(self._on_callback))

        logger.info("Starting Telegram bot (polling mode)...")

        # Initialize and start polling
        await self._app.initialize()
        await self._app.start()

        # Get bot info
        bot_info = await self._app.bot.get_me()
        logger.info(f"Telegram bot @{bot_info.username} connected")

        # Register bot commands (shows in Telegram's command menu)
        try:
            await self._app.bot.set_my_commands(self.NATIVE_COMMANDS)
            logger.info(f"Registered {len(self.NATIVE_COMMANDS)} native commands")
        except Exception as e:
            logger.warning(f"Failed to set bot commands: {e}")

        # Start polling (this runs until stopped)
        await self._app.updater.start_polling(
            allowed_updates=["message", "callback_query"],
            drop_pending_updates=True  # Ignore old messages on startup
        )

        # Keep running until stopped
        while self._running:
            await asyncio.sleep(1)

    async def stop(self) -> None:
        """Stop the Telegram bot."""
        self._running = False

        # Cancel all typing indicator tasks
        for chat_id in list(self._typing_tasks.keys()):
            await self._stop_typing(chat_id)

        if self._app:
            logger.info("Stopping Telegram bot...")
            await self._app.updater.stop()
            await self._app.stop()
            await self._app.shutdown()
            self._app = None

    async def send(self, msg: OutboundMessage) -> None:
        """
        Send a message through Telegram.

        Handles:
        - Text-only messages
        - Single photo with caption
        - Multiple photos as media group
        - Documents/files
        """
        if not self._app:
            logger.warning("Telegram bot not running")
            return

        try:
            chat_id = int(msg.chat_id)
        except ValueError:
            logger.error(f"Invalid chat_id: {msg.chat_id}")
            return

        # Stop typing indicator before sending response
        await self._stop_typing(chat_id)

        # Check if we have media to send
        if msg.media:
            await self._send_with_media(chat_id, msg)
        else:
            await self._send_text(chat_id, msg.content)

    async def _send_text(self, chat_id: int, content: str) -> None:
        """Send a text-only message."""
        if not self._app:
            return

        try:
            html_content = _markdown_to_telegram_html(content)
            await self._app.bot.send_message(
                chat_id=chat_id,
                text=html_content,
                parse_mode="HTML"
            )
        except Exception as e:
            # Fallback to plain text if HTML parsing fails
            logger.warning(f"HTML parse failed, falling back to plain text: {e}")
            try:
                await self._app.bot.send_message(
                    chat_id=chat_id,
                    text=content
                )
            except Exception as e2:
                logger.error(f"Error sending Telegram message: {e2}")

    async def _send_with_media(self, chat_id: int, msg: OutboundMessage) -> None:
        """Send message with media attachments."""
        if not self._app:
            return

        # Separate images from documents
        images: list[Path] = []
        documents: list[Path] = []

        for media_path in msg.media:
            path = Path(media_path).expanduser().resolve()

            if not path.exists():
                logger.warning(f"Media file not found: {media_path}")
                continue

            if _is_image_file(path):
                images.append(path)
            else:
                documents.append(path)

        # Send images
        if images:
            await self._send_images(chat_id, images, msg.content)
        elif msg.content:
            # No images but we have content - send as text
            await self._send_text(chat_id, msg.content)

        # Send documents separately (after images)
        for doc_path in documents:
            await self._send_document(chat_id, doc_path)

    async def _send_images(self, chat_id: int, images: list[Path], caption: str) -> None:
        """Send one or more images."""
        if not self._app or not images:
            return

        try:
            if len(images) == 1:
                # Single image - send as photo with caption
                await self._send_single_photo(chat_id, images[0], caption)
            else:
                # Multiple images - send as media group
                await self._send_media_group(chat_id, images, caption)

        except Exception as e:
            logger.error(f"Error sending images: {e}")
            # Fallback: try sending as documents
            for image in images:
                try:
                    await self._send_document(chat_id, image)
                except Exception as e2:
                    logger.error(f"Failed to send {image} as document: {e2}")

    async def _send_single_photo(self, chat_id: int, image_path: Path, caption: str) -> None:
        """Send a single photo with caption."""
        if not self._app:
            return

        # Prepare caption (truncate if needed)
        html_caption = ""
        if caption:
            html_caption = _truncate_caption(_markdown_to_telegram_html(caption))

        try:
            with open(image_path, "rb") as photo_file:
                await self._app.bot.send_photo(
                    chat_id=chat_id,
                    photo=InputFile(photo_file, filename=image_path.name),
                    caption=html_caption if html_caption else None,
                    parse_mode="HTML" if html_caption else None
                )
                logger.info(f"Sent photo: {image_path.name} to {chat_id}")

        except Exception as e:
            logger.error(f"Error sending photo {image_path}: {e}")
            # Try sending as document as fallback
            await self._send_document(chat_id, image_path)

    async def _send_media_group(self, chat_id: int, images: list[Path], caption: str) -> None:
        """Send multiple images as a media group."""
        if not self._app or not images:
            return

        from telegram import InputMediaPhoto

        try:
            media_group = []
            file_handles = []

            for i, image_path in enumerate(images[:10]):  # Telegram limit: 10 items
                file_handle = open(image_path, "rb")
                file_handles.append(file_handle)

                # Only first image gets the caption
                img_caption = None
                if i == 0 and caption:
                    img_caption = _truncate_caption(_markdown_to_telegram_html(caption))

                media_group.append(InputMediaPhoto(
                    media=InputFile(file_handle, filename=image_path.name),
                    caption=img_caption,
                    parse_mode="HTML" if img_caption else None
                ))

            await self._app.bot.send_media_group(
                chat_id=chat_id,
                media=media_group
            )
            logger.info(f"Sent media group with {len(images)} images to {chat_id}")

        except Exception as e:
            logger.error(f"Error sending media group: {e}")
            raise
        finally:
            # Close all file handles
            for fh in file_handles:
                try:
                    fh.close()
                except Exception:
                    pass

    async def _send_document(self, chat_id: int, doc_path: Path) -> None:
        """Send a file as a document."""
        if not self._app:
            return

        try:
            with open(doc_path, "rb") as doc_file:
                await self._app.bot.send_document(
                    chat_id=chat_id,
                    document=InputFile(doc_file, filename=doc_path.name)
                )
                logger.info(f"Sent document: {doc_path.name} to {chat_id}")

        except Exception as e:
            logger.error(f"Error sending document {doc_path}: {e}")

    def set_compact_callback(self, callback: callable) -> None:
        """Set the callback for /compact command."""
        self._compact_callback = callback

    async def _send_typing(self, chat_id: int) -> None:
        """Send typing indicator to a chat."""
        if not self._app:
            return
        try:
            await self._app.bot.send_chat_action(chat_id=chat_id, action="typing")
        except Exception as e:
            logger.debug(f"Failed to send typing indicator: {e}")

    async def _start_typing_loop(self, chat_id: int) -> None:
        """Start a background task that sends typing indicators every 4 seconds."""
        # Cancel existing typing task for this chat if any
        await self._stop_typing(chat_id)

        async def typing_loop():
            try:
                while True:
                    await self._send_typing(chat_id)
                    await asyncio.sleep(4)  # Telegram typing expires after ~5 seconds
            except asyncio.CancelledError:
                pass

        self._typing_tasks[chat_id] = asyncio.create_task(typing_loop())

    async def _stop_typing(self, chat_id: int) -> None:
        """Stop the typing indicator loop for a chat."""
        task = self._typing_tasks.pop(chat_id, None)
        if task and not task.done():
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass

    async def _on_start(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /start command."""
        if not update.message or not update.effective_user:
            return

        user = update.effective_user
        chat_id = update.message.chat_id

        # Check if user needs pairing
        if await self._handle_pairing(chat_id, user):
            return

        await update.message.reply_text(
            f"Hi {user.first_name}!\n\n"
            "Send me a message and I'll respond!\n\n"
            "Commands:\n"
            "/projects - Select a project\n"
            "/tasks - List tasks\n"
            "/newtask - Create task\n"
            "/status - Kanban summary\n"
            "/ralph - Start Ralph AI\n"
            "/help - Show all commands"
        )

    async def _on_compact(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /compact command."""
        if not update.message or not update.effective_user:
            return

        chat_id = update.message.chat_id

        # Get optional custom instructions from command args
        custom_instructions = " ".join(context.args) if context.args else None

        if self._compact_callback:
            await update.message.reply_text("Compacting conversation history...")
            try:
                session_key = f"telegram:{chat_id}"
                result = await self._compact_callback(session_key, custom_instructions)

                if result.get("success"):
                    await update.message.reply_text(
                        f"{result['message']}\n"
                        f"({result['tokens_before']} -> {result['tokens_after']} tokens)\n\n"
                        f"Summary:\n{result.get('summary_preview', '')}"
                    )
                else:
                    await update.message.reply_text(f"{result.get('message', 'Compaction failed')}")
            except Exception as e:
                logger.error(f"Compact command failed: {e}")
                await update.message.reply_text(f"Error: {str(e)}")
        else:
            await update.message.reply_text("Compaction not available")

    async def _on_new(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /new command -- start a fresh session."""
        if not update.message or not update.effective_user:
            return

        chat_id = update.message.chat_id

        await self._handle_message(
            sender_id=str(update.effective_user.id),
            chat_id=str(chat_id),
            content="/new",
            metadata={"is_command": True, "command": "new"}
        )

        await update.message.reply_text("New conversation started")

    async def _on_clear(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /clear command -- clear current session history."""
        if not update.message or not update.effective_user:
            return

        chat_id = update.message.chat_id

        await self._handle_message(
            sender_id=str(update.effective_user.id),
            chat_id=str(chat_id),
            content="/clear",
            metadata={"is_command": True, "command": "clear"}
        )

        await update.message.reply_text("Session history cleared")

    async def _on_help(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /help command."""
        if not update.message:
            return

        await update.message.reply_text(
            "<b>Commands</b>\n\n"
            "<b>/new</b> - Start a fresh conversation\n"
            "<b>/compact</b> [instructions] - Summarize history\n"
            "<b>/clear</b> - Clear session history\n\n"
            "<b>Dispatch Project Management</b>\n\n"
            "<b>/projects</b> - Select active project\n"
            "<b>/tasks</b> - List tasks in active project\n"
            "<b>/newtask</b> &lt;title&gt; | &lt;description&gt; - Create task\n"
            "<b>/deltask</b> - Delete a task (select from list)\n"
            "<b>/status</b> - Kanban board summary\n"
            "<b>/ralph</b> - Start Ralph AI coding on a task\n"
            "<b>/ralph_stop</b> &lt;attempt_id&gt; - Stop Ralph session\n\n"
            "<b>/help</b> - Show this help\n\n"
            "<i>Just send a message to chat normally!</i>",
            parse_mode="HTML"
        )

    def _is_sender_allowed(self, user_id: str, username: str | None) -> bool:
        """Check if sender is allowed via config or pairing store."""
        dm_policy = getattr(self.config, 'dm_policy', 'pairing')

        # Open mode = allow everyone
        if dm_policy == "open":
            return True

        # Check config allow_from
        config_allow = self.config.allow_from or []

        # Check pairing store allow_from
        store_allow = read_allow_from_store("telegram")

        # Combine both lists
        all_allowed = set(config_allow) | set(store_allow)

        # For pairing/allowlist mode, empty list means no one is allowed yet
        if not all_allowed:
            return False

        # Check if user_id or username matches
        if user_id in all_allowed:
            return True
        if username and username in all_allowed:
            return True
        if username and f"@{username}" in all_allowed:
            return True

        # Check with telegram: prefix
        if f"telegram:{user_id}" in all_allowed:
            return True

        return False

    async def _handle_pairing(self, chat_id: int, user) -> bool:
        """
        Handle pairing for unauthorized users.

        Returns True if user is not allowed (message blocked or pairing sent).
        """
        user_id = str(user.id)
        username = user.username

        if self._is_sender_allowed(user_id, username):
            return False

        dm_policy = getattr(self.config, 'dm_policy', 'pairing')

        # allowlist mode = silently block unauthorized users
        if dm_policy == "allowlist":
            logger.debug(f"Blocked unauthorized sender {user_id} (allowlist mode)")
            return True

        # pairing mode = send pairing code
        meta = {}
        if username:
            meta["username"] = username
        if user.first_name:
            meta["first_name"] = user.first_name
        if user.last_name:
            meta["last_name"] = user.last_name

        code, created = upsert_pairing_request("telegram", user_id, meta)

        if created and code:
            # Send pairing instructions
            await self._app.bot.send_message(
                chat_id,
                f"<b>Access Required</b>\n\n"
                f"Your Telegram ID: <code>{user_id}</code>\n\n"
                f"Pairing code: <code>{code}</code>\n\n"
                f"Enter this code in the Dispatch app to connect.",
                parse_mode="HTML"
            )
            logger.info(f"Pairing request created for {user_id} ({username}): {code}")
        elif not code:
            # Max pending reached
            await self._app.bot.send_message(
                chat_id,
                "Too many pending requests. Please try again later."
            )

        return True

    async def _on_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle incoming messages (text, photos, voice, documents)."""
        if not update.message or not update.effective_user:
            return

        message = update.message
        user = update.effective_user
        chat_id = message.chat_id

        # Check pairing / authorization first
        if await self._handle_pairing(chat_id, user):
            return  # User not authorized, pairing message sent

        # Start typing indicator loop (will continue until response is sent)
        await self._start_typing_loop(chat_id)

        # Use stable numeric ID, but keep username for allowlist compatibility
        sender_id = str(user.id)
        if user.username:
            sender_id = f"{sender_id}|{user.username}"

        # Store chat_id for replies
        self._chat_ids[sender_id] = chat_id

        # Build content from text and/or media
        content_parts = []
        media_paths = []

        # Text content
        if message.text:
            content_parts.append(message.text)
        if message.caption:
            content_parts.append(message.caption)

        # Handle media files
        media_file = None
        media_type = None

        if message.photo:
            media_file = message.photo[-1]  # Largest photo
            media_type = "image"
        elif message.voice:
            media_file = message.voice
            media_type = "voice"
        elif message.audio:
            media_file = message.audio
            media_type = "audio"
        elif message.document:
            media_file = message.document
            media_type = "file"

        # Download media if present
        if media_file and self._app:
            try:
                file = await self._app.bot.get_file(media_file.file_id)
                ext = self._get_extension(media_type, getattr(media_file, 'mime_type', None))

                # Save to workspace/media/
                media_dir = Path.home() / ".flowly" / "media"
                media_dir.mkdir(parents=True, exist_ok=True)

                file_path = media_dir / f"{media_file.file_id[:16]}{ext}"
                await file.download_to_drive(str(file_path))

                media_paths.append(str(file_path))
                content_parts.append(f"[{media_type}: {file_path}]")

                logger.debug(f"Downloaded {media_type} to {file_path}")
            except Exception as e:
                logger.error(f"Failed to download media: {e}")
                content_parts.append(f"[{media_type}: download failed]")

        content = "\n".join(content_parts) if content_parts else "[empty message]"

        # Inject active project context so the agent knows which project to work with
        active_project = self._get_active_project(chat_id)
        if active_project:
            content = (
                f"[Active Dispatch project: {active_project['name']} "
                f"(id: {active_project['id']})]\n\n{content}"
            )

        logger.debug(f"Telegram message from {sender_id}: {content[:50]}...")

        # Forward to the message bus
        await self._handle_message(
            sender_id=sender_id,
            chat_id=str(chat_id),
            content=content,
            media=media_paths,
            metadata={
                "message_id": message.message_id,
                "user_id": user.id,
                "username": user.username,
                "first_name": user.first_name,
                "is_group": message.chat.type != "private",
                "active_project": active_project,
            }
        )

    # ── Dispatch HTTP helpers ──────────────────────────────────────────

    def _dispatch_base_url(self) -> str | None:
        """Get the Dispatch backend base URL if configured."""
        if not self._dispatch_config or not self._dispatch_config.enabled:
            return None
        return f"http://127.0.0.1:{self._dispatch_config.backend_port}/api"

    async def _dispatch_get(self, path: str, params: dict | None = None) -> dict | None:
        """GET request to Dispatch backend. Returns parsed JSON or None on error."""
        base = self._dispatch_base_url()
        if not base:
            return None
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                resp = await client.get(f"{base}{path}", params=params)
                resp.raise_for_status()
                return resp.json()
        except Exception as e:
            logger.error(f"Dispatch GET {path} failed: {e}")
            return None

    async def _dispatch_post(self, path: str, json_data: dict | None = None) -> dict | None:
        """POST request to Dispatch backend."""
        base = self._dispatch_base_url()
        if not base:
            return None
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                resp = await client.post(f"{base}{path}", json=json_data)
                resp.raise_for_status()
                return resp.json()
        except Exception as e:
            logger.error(f"Dispatch POST {path} failed: {e}")
            return None

    async def _dispatch_delete(self, path: str) -> bool:
        """DELETE request to Dispatch backend."""
        base = self._dispatch_base_url()
        if not base:
            return False
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                resp = await client.delete(f"{base}{path}")
                resp.raise_for_status()
                return True
        except Exception as e:
            logger.error(f"Dispatch DELETE {path} failed: {e}")
            return False

    def _get_active_project(self, chat_id: int) -> dict | None:
        """Get active project for a chat, or None."""
        return self._active_projects.get(chat_id)

    async def _require_dispatch(self, update: Update) -> bool:
        """Check if Dispatch is configured. Sends error message if not. Returns True if available."""
        if not self._dispatch_base_url():
            await update.message.reply_text("Dispatch integration is not configured.")
            return False
        return True

    async def _require_active_project(self, update: Update) -> dict | None:
        """Get active project or prompt user to select one. Returns project dict or None."""
        chat_id = update.message.chat_id
        project = self._get_active_project(chat_id)
        if not project:
            await update.message.reply_text(
                "No active project selected.\nUse /projects to select one first."
            )
            return None
        return project

    # ── Dispatch command handlers ────────────────────────────────────

    async def _on_projects(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /projects — show project list as inline keyboard."""
        if not update.message or not update.effective_user:
            return
        if await self._handle_pairing(update.message.chat_id, update.effective_user):
            return
        if not await self._require_dispatch(update):
            return

        data = await self._dispatch_get("/projects")
        if not data:
            await update.message.reply_text("Could not fetch projects from Dispatch.")
            return

        projects = data.get("data", data)
        if not projects:
            await update.message.reply_text("No projects found in Dispatch.")
            return

        # Build inline keyboard with project buttons
        buttons = []
        for p in projects:
            name = p.get("name", "Unnamed")
            pid = p.get("id", "")
            buttons.append([InlineKeyboardButton(name, callback_data=f"project:{pid}")])

        active = self._get_active_project(update.message.chat_id)
        active_text = f"\nActive: <b>{active['name']}</b>" if active else ""

        await update.message.reply_text(
            f"<b>Select a project:</b>{active_text}",
            reply_markup=InlineKeyboardMarkup(buttons),
            parse_mode="HTML",
        )

    async def _on_tasks(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /tasks — list tasks in active project."""
        if not update.message or not update.effective_user:
            return
        if await self._handle_pairing(update.message.chat_id, update.effective_user):
            return
        if not await self._require_dispatch(update):
            return

        project = await self._require_active_project(update)
        if not project:
            return

        data = await self._dispatch_get("/tasks", params={"project_id": project["id"]})
        if not data:
            await update.message.reply_text("Could not fetch tasks.")
            return

        tasks = data.get("data", data)
        if not tasks:
            await update.message.reply_text(f"No tasks in <b>{project['name']}</b>.", parse_mode="HTML")
            return

        # Status emoji mapping
        status_icons = {
            "todo": "\u2b1c", "inprogress": "\u25b6\ufe0f", "inreview": "\ud83d\udd0d",
            "done": "\u2705", "cancelled": "\u274c",
        }

        lines = [f"<b>Tasks in {project['name']}:</b>\n"]
        for t in tasks:
            status = t.get("status", "unknown")
            icon = status_icons.get(status, "\u2753")
            title = t.get("title", "Untitled")
            tid = t.get("id", "?")[:8]
            lines.append(f"{icon} {title} <code>{tid}</code>")

        await update.message.reply_text("\n".join(lines), parse_mode="HTML")

    async def _on_newtask(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /newtask <title> | <description> — create a new task.

        Examples:
            /newtask Fix login bug
            /newtask Fix login bug | Users get 401 error when logging in with Google OAuth
        """
        if not update.message or not update.effective_user:
            return
        if await self._handle_pairing(update.message.chat_id, update.effective_user):
            return
        if not await self._require_dispatch(update):
            return

        project = await self._require_active_project(update)
        if not project:
            return

        raw = " ".join(context.args) if context.args else ""
        if not raw:
            await update.message.reply_text(
                "Usage:\n"
                "<code>/newtask Task title</code>\n"
                "<code>/newtask Task title | Detailed description here</code>",
                parse_mode="HTML",
            )
            return

        # Split title | description
        if "|" in raw:
            title, description = raw.split("|", 1)
            title = title.strip()
            description = description.strip()
        else:
            title = raw.strip()
            description = ""

        payload = {"project_id": project["id"], "title": title}
        if description:
            payload["description"] = description

        data = await self._dispatch_post("/tasks", json_data=payload)

        if data:
            task = data.get("data", data)
            tid = task.get("id", "?")[:8]
            msg = f"\u2705 Created: <b>{title}</b> <code>{tid}</code>"
            if description:
                preview = (description[:100] + "...") if len(description) > 100 else description
                msg += f"\n\n{preview}"
            await update.message.reply_text(msg, parse_mode="HTML")
        else:
            await update.message.reply_text("Failed to create task.")

    async def _on_deltask(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /deltask — show tasks as buttons for deletion."""
        if not update.message or not update.effective_user:
            return
        if await self._handle_pairing(update.message.chat_id, update.effective_user):
            return
        if not await self._require_dispatch(update):
            return

        project = await self._require_active_project(update)
        if not project:
            return

        data = await self._dispatch_get("/tasks", params={"project_id": project["id"]})
        if not data:
            await update.message.reply_text("Could not fetch tasks.")
            return

        tasks = data.get("data", data)
        if not tasks:
            await update.message.reply_text("No tasks to delete.")
            return

        buttons = []
        for t in tasks:
            title = t.get("title", "Untitled")
            tid = t.get("id", "")
            buttons.append([InlineKeyboardButton(f"\u274c {title}", callback_data=f"deltask:{tid}")])

        await update.message.reply_text(
            "<b>Select a task to delete:</b>",
            reply_markup=InlineKeyboardMarkup(buttons),
            parse_mode="HTML",
        )

    async def _on_status(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /status — kanban board summary."""
        if not update.message or not update.effective_user:
            return
        if await self._handle_pairing(update.message.chat_id, update.effective_user):
            return
        if not await self._require_dispatch(update):
            return

        project = await self._require_active_project(update)
        if not project:
            return

        data = await self._dispatch_get("/tasks", params={"project_id": project["id"]})
        if not data:
            await update.message.reply_text("Could not fetch tasks.")
            return

        tasks = data.get("data", data)
        if not tasks:
            await update.message.reply_text(f"No tasks in <b>{project['name']}</b>.", parse_mode="HTML")
            return

        counts: dict[str, int] = {}
        for t in tasks:
            status = t.get("status", "unknown")
            counts[status] = counts.get(status, 0) + 1

        status_icons = {
            "todo": "\u2b1c", "inprogress": "\u25b6\ufe0f", "inreview": "\ud83d\udd0d",
            "done": "\u2705", "cancelled": "\u274c",
        }

        lines = [f"<b>Kanban: {project['name']}</b> ({len(tasks)} tasks)\n"]
        for status, count in sorted(counts.items()):
            icon = status_icons.get(status, "\u2753")
            lines.append(f"{icon} {status}: {count}")

        await update.message.reply_text("\n".join(lines), parse_mode="HTML")

    async def _on_ralph(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /ralph — show tasks as buttons to start Ralph on."""
        if not update.message or not update.effective_user:
            return
        if await self._handle_pairing(update.message.chat_id, update.effective_user):
            return
        if not await self._require_dispatch(update):
            return

        project = await self._require_active_project(update)
        if not project:
            return

        # If attempt_id given directly, start Ralph session on it
        if context.args:
            attempt_id = context.args[0]
            data = await self._dispatch_post(f"/task-attempts/{attempt_id}/ralph/start")
            if data:
                await update.message.reply_text(f"\u2705 Ralph started on workspace <code>{attempt_id[:8]}</code>", parse_mode="HTML")
            else:
                await update.message.reply_text("Failed to start Ralph. Check the attempt ID.")
            return

        # Show project-level Ralph start
        data = await self._dispatch_post(f"/projects/{project['id']}/ralph/start")
        if data:
            await update.message.reply_text(
                f"\u2705 Ralph session started for <b>{project['name']}</b>",
                parse_mode="HTML",
            )
        else:
            await update.message.reply_text("Failed to start Ralph session.")

    async def _on_ralph_stop(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /ralph_stop <attempt_id> — stop a Ralph session."""
        if not update.message or not update.effective_user:
            return
        if await self._handle_pairing(update.message.chat_id, update.effective_user):
            return
        if not await self._require_dispatch(update):
            return

        if not context.args:
            await update.message.reply_text("Usage: /ralph_stop &lt;attempt_id&gt;", parse_mode="HTML")
            return

        attempt_id = context.args[0]
        data = await self._dispatch_post(f"/task-attempts/{attempt_id}/stop")
        if data:
            await update.message.reply_text(f"\u2705 Ralph stopped on <code>{attempt_id[:8]}</code>", parse_mode="HTML")
        else:
            await update.message.reply_text("Failed to stop Ralph session.")

    # ── Callback query handler ───────────────────────────────────────

    async def _on_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle inline keyboard button presses."""
        query = update.callback_query
        if not query or not query.data:
            return

        await query.answer()  # Acknowledge the callback

        data = query.data
        chat_id = query.message.chat_id

        if data.startswith("project:"):
            # Project selection
            project_id = data[len("project:"):]
            # Fetch project name
            project_data = await self._dispatch_get(f"/projects/{project_id}")
            if project_data:
                project = project_data.get("data", project_data)
                name = project.get("name", "Unknown")
                self._active_projects[chat_id] = {"id": project_id, "name": name}
                await query.edit_message_text(
                    f"\u2705 Active project: <b>{name}</b>\n\n"
                    f"Now you can use /tasks, /newtask, /status, /ralph",
                    parse_mode="HTML",
                )
            else:
                await query.edit_message_text("Failed to select project.")

        elif data.startswith("deltask:"):
            # Task deletion
            task_id = data[len("deltask:"):]
            success = await self._dispatch_delete(f"/tasks/{task_id}")
            if success:
                await query.edit_message_text(f"\u2705 Task deleted: <code>{task_id[:8]}</code>", parse_mode="HTML")
            else:
                await query.edit_message_text("Failed to delete task.")

    def _get_extension(self, media_type: str, mime_type: str | None) -> str:
        """Get file extension based on media type."""
        if mime_type:
            ext_map = {
                "image/jpeg": ".jpg", "image/png": ".png", "image/gif": ".gif",
                "audio/ogg": ".ogg", "audio/mpeg": ".mp3", "audio/mp4": ".m4a",
            }
            if mime_type in ext_map:
                return ext_map[mime_type]

        type_map = {"image": ".jpg", "voice": ".ogg", "audio": ".mp3", "file": ""}
        return type_map.get(media_type, "")
