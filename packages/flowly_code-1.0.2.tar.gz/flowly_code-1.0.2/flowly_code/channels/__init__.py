"""Chat channels module with plugin architecture."""

from flowly_code.channels.base import BaseChannel
from flowly_code.channels.manager import ChannelManager

__all__ = ["BaseChannel", "ChannelManager"]
