"""Independent activity pub/sub bus for real-time event streaming.

This is completely separate from MessageBus — it never touches inbound/outbound
message queues. If no subscribers are connected, emit() is a no-op.
"""

from __future__ import annotations

import asyncio
from typing import AsyncGenerator

from loguru import logger

from flowly_code.activity.events import ActivityEvent


class ActivityBus:
    """Per-subscriber asyncio.Queue pub/sub for activity events.

    Zero-overhead guarantee: if no subscribers exist, emit() returns
    immediately without creating any objects.
    """

    def __init__(self) -> None:
        self._subscribers: dict[str, asyncio.Queue[ActivityEvent]] = {}
        self._counter = 0
        self._lock = asyncio.Lock()
        # Track currently running agents for late-joining subscribers
        self._running_agents: dict[str, ActivityEvent] = {}

    @property
    def has_subscribers(self) -> bool:
        return len(self._subscribers) > 0

    async def subscribe(
        self, maxsize: int = 256
    ) -> tuple[str, AsyncGenerator[ActivityEvent, None]]:
        """Subscribe to activity events.

        Returns (subscriber_id, async_generator). Iterate the generator
        to receive events. The generator cleans up on cancellation.
        """
        async with self._lock:
            self._counter += 1
            sub_id = f"sub-{self._counter}"
            queue: asyncio.Queue[ActivityEvent] = asyncio.Queue(maxsize=maxsize)
            self._subscribers[sub_id] = queue
            # Replay currently running agents so late joiners see them
            for event in self._running_agents.values():
                try:
                    queue.put_nowait(event)
                except asyncio.QueueFull:
                    break

        async def _gen() -> AsyncGenerator[ActivityEvent, None]:
            try:
                while True:
                    event = await queue.get()
                    yield event
            except asyncio.CancelledError:
                return
            finally:
                await self.unsubscribe(sub_id)

        return sub_id, _gen()

    async def unsubscribe(self, sub_id: str) -> None:
        """Remove a subscriber."""
        async with self._lock:
            self._subscribers.pop(sub_id, None)

    def emit(self, event: ActivityEvent) -> None:
        """Publish an event to all subscribers (non-blocking).

        Uses put_nowait — if a subscriber's queue is full, the event
        is silently dropped for that subscriber (backpressure).
        """
        # Track running agents for late-joining subscribers
        agent_name = getattr(event, "agent_name", None)
        if agent_name and event.type == "subagent_spawn":
            self._running_agents[agent_name] = event
        elif agent_name and event.type == "subagent_end":
            self._running_agents.pop(agent_name, None)

        for sub_id, queue in list(self._subscribers.items()):
            try:
                queue.put_nowait(event)
            except asyncio.QueueFull:
                logger.debug(
                    f"ActivityBus: dropped event for slow subscriber {sub_id}"
                )
