"""Activity event definitions for real-time agent monitoring."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Literal

ActivityEventType = Literal[
    "llm_start",
    "llm_end",
    "tool_start",
    "tool_end",
    "iteration_start",
    "iteration_end",
    "subagent_spawn",
    "subagent_end",
    "hallucination_retry",
    "error",
]


@dataclass
class ActivityEvent:
    type: ActivityEventType
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    agent_name: str | None = None
    iteration: int | None = None
    tool_name: str | None = None
    tool_args_preview: str | None = None
    success: bool | None = None
    error_message: str | None = None
    subagent_id: str | None = None
    subagent_label: str | None = None

    def to_dict(self) -> dict:
        """Serialize to dict, dropping None values for compact JSON."""
        return {k: v for k, v in asdict(self).items() if v is not None}
