"""CLI module for flowly."""
