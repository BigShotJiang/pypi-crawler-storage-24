<div align="center">
  <h1>Flowly Code</h1>
  <p><strong>AI coding agent that runs locally inside Dispatch.</strong></p>
  <p>
    <a href="https://pypi.org/project/flowly-code/"><img src="https://img.shields.io/pypi/v/flowly-code" alt="PyPI"></a>
    <img src="https://img.shields.io/badge/python-≥3.11-3776AB?logo=python&logoColor=white" alt="Python">
    <img src="https://img.shields.io/badge/platform-macOS%20·%20Linux%20·%20Windows-lightgrey" alt="Platform">
  </p>
</div>

---

Flowly Code is the AI agent backend for [Dispatch](https://dispatch.codes) — an AI-powered project management desktop app for developers.

It powers multi-agent orchestration, scheduled tasks, and channel integrations within the Dispatch ecosystem.

## Installation

Flowly Code is installed automatically by the Dispatch desktop app. For manual installation:

```bash
uv tool install flowly-code
```

## Usage

Managed through the Dispatch desktop app. Runs as a local gateway service.

```bash
flowly-code gateway --port 18790
flowly-code cron list
flowly-code agent -m "your message"
```

## Requirements

- Python 3.11+
- macOS, Linux, or Windows

## Links

- [dispatch.codes](https://dispatch.codes)
- [Download Dispatch](https://dispatch.codes/download)

---

<p align="center">
  <sub>© Nocetic Limited. All rights reserved.</sub>
</p>
