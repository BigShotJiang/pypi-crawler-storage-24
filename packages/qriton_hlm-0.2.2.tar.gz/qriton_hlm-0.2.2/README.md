# Qriton HLM — Energy Language

**Program neural networks by shaping energy landscapes.**

Instead of training weights via backprop, directly inject, remove, and move
basins (stable attractors) in polynomial Hopfield networks.

```
$ qriton-hlm -c model.pt
hlm:model> survey 0
Layer 0: 200 unique basins (200 inits, beta=7.0, 1.2s)

hlm:model> inject 0 42 0.1
  Before: 200 basins, target is basin: False
  After:  201 basins (+1), target is basin: True
  >> Basin successfully programmed!

hlm:model> apply 0
Applied L0 to live model.

hlm:model> generate The meaning of life is
The meaning of life is a complex question that...
  [30 tokens, 1.4s, 22 tok/s]
```

## Install

```bash
pip install qriton-hlm
```

## What is this?

Classical Hopfield networks store memories as energy minima. Modern polynomial
Hopfield networks (Krotov & Hopfield, 2016) use higher-order interactions to
create richer energy landscapes with multiple basins per layer.

**Qriton HLM** treats these basins as programmable units:

| Operation | What it does |
|-----------|-------------|
| `inject` | Create a new attractor |
| `remove` | Destroy an attractor |
| `move` | Relocate an attractor |
| `survey` | Find all attractors |
| `verify` | Check if point is attractor |

## CLI Commands

```
load <path>                    Load a checkpoint
info                           Show model info
survey <layer>                 Find all basins in a layer
survey-all                     Survey every layer
inject <layer> <seed> [str]    Inject a new basin
remove <layer> <seed> [str]    Remove closest basin
move <layer> <seed> [str]      Move closest basin to new location
verify <layer> <seed>          Check if target is a basin
apply <layer>                  Write modified W to live model
restore <layer>                Undo modifications
restore-all                    Restore all layers
status                         Show which layers are modified
generate <prompt>              Generate text with current model
set <param> <value>            Set parameter (beta, inits, strength, ...)
diff <layer>                   Show W matrix change stats
save <path>                    Save modified W matrices
history                        Show operation log
```

## Python API

```python
from qriton_hlm import BasinSurgeon

surgeon = BasinSurgeon.from_checkpoint("model.pt", device="cuda")

# Survey the energy landscape
result = surgeon.survey(layer=0)
print(f"Found {result['num_basins']} basins")

# Inject a new basin
result = surgeon.inject(layer=0, seed=42, strength=0.1)
print(f"Basin exists: {result['exists_after']}")

# Apply to live model for inference
surgeon.apply(layer=0)

# Check what changed
diff = surgeon.diff(layer=0)
print(f"W changed by {diff['relative_pct']:.2f}%")

# Restore original
surgeon.restore(layer=0)
```

## Scripts

Write `.hlm` scripts to chain operations:

```bash
# hello_basins.hlm
load model.pt
survey 0
set strength 0.1
inject 0 42
apply 0
generate The meaning of life is
restore 0
```

Run with:
```bash
qriton-hlm --script hello_basins.hlm
```

## How it works

Polynomial Hopfield networks (Krotov & Hopfield, 2016) use higher-order
interactions that create **multiple stable basins** per layer — unlike
softmax attention which collapses to a single attractor.

Each basin is a stable fixed point in the energy landscape. By modifying
the weight matrix W, we can program which points become attractors.

- **Training** builds the model (gradient descent on data)
- **Surgery** programs specific attractors post-hoc (no retraining needed)
- The two compose: train first, then surgically modify

## Compatibility

Works with any PyTorch checkpoint that contains `hopfield.W` parameters:
- HLM2/HLM3 language models
- HLM-Spatial (LIDAR, Medical3D, Industrial3D)
- HLM-Audio (STT, TTS)
- Any model using PolyHopfieldLayer

## Requirements

- Python >= 3.9
- PyTorch >= 2.0
- NumPy

## License

Apache 2.0 — Qriton Technologies S.R.L.
