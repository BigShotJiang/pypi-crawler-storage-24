"""
Qriton HLM — Energy Language

Program neural networks by shaping energy landscapes.
Instead of training weights via backprop, directly inject, remove,
and move basins (stable attractors) in polynomial Hopfield networks.

Core idea:
    Classical Hopfield:  W += xi @ xi^T           (stores pattern xi as basin)
    Krotov polynomial:   W += F(xi) @ xi^T         (d=3: F(x) = x|x|)
    Basin removal:       W -= F(xi) @ xi^T         (destabilize pattern xi)

Usage:
    from qriton_hlm import BasinSurgeon

    surgeon = BasinSurgeon.from_checkpoint("model.pt", device="cuda")
    surgeon.survey(layer=0)
    surgeon.inject(layer=0, seed=42, strength=0.1)
    surgeon.apply(layer=0)
"""

__version__ = "0.2.2"

from qriton_hlm.core import (
    poly_interaction,
    find_basins,
    compute_energy,
    inject_basin,
    remove_basin,
    move_basin,
    verify_basin_exists,
    load_W_from_checkpoint,
    BasinSurgeon,
)

__all__ = [
    "poly_interaction",
    "find_basins",
    "compute_energy",
    "inject_basin",
    "remove_basin",
    "move_basin",
    "verify_basin_exists",
    "load_W_from_checkpoint",
    "BasinSurgeon",
]
