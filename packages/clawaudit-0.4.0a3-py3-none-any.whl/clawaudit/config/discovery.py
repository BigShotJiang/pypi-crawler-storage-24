"""OpenClaw installation auto-discovery."""

import os
import json
import subprocess
from pathlib import Path
from typing import List, Optional, Dict, Any


CONFIG_FILE_NAMES = [
    "config.yaml", "config.yml", "config.json",
    "openclaw.json", "clawdbot.json", "moltbot.json",
    "gateway.yaml", ".env", "docker-compose.yml",
]


class OpenClawDiscovery:
    """Discover OpenClaw installation paths and config files."""

    def __init__(self, explicit_path: Optional[str] = None):
        self.explicit_path = explicit_path
        self._install_dir: Optional[Path] = None
        self._config_files: List[Path] = []
        self._config_dirs: List[Path] = []
        self._version: Optional[str] = None

    @property
    def install_dir(self) -> Optional[Path]:
        if self._install_dir is None:
            self._discover()
        return self._install_dir

    @property
    def config_files(self) -> List[Path]:
        if not self._config_files:
            self._discover()
        return self._config_files

    @property
    def config_dirs(self) -> List[Path]:
        if not self._config_dirs:
            self._discover()
        return self._config_dirs

    @property
    def version(self) -> Optional[str]:
        if self._version is None:
            self._detect_version()
        return self._version

    def _candidate_dirs(self) -> List[Path]:
        """Return candidate directories in priority order."""
        dirs: List[Path] = []

        if self.explicit_path:
            dirs.append(Path(self.explicit_path))
            return dirs

        # Environment variables
        for var in ("OPENCLAW_HOME", "MOLTBOT_HOME"):
            val = os.environ.get(var)
            if val:
                dirs.append(Path(val))

        # Standard locations
        home = Path.home()
        dirs.extend([
            home / ".openclaw",
            home / ".clawdbot",
            home / ".moltbot",
            home / ".molthub",
            Path("/opt/openclaw"),
            Path("/etc/openclaw"),
            Path.cwd(),
        ])

        return dirs

    def _discover(self) -> None:
        """Run discovery and populate install_dir, config_files, config_dirs."""
        seen: set = set()

        for d in self._candidate_dirs():
            if not d.exists() or not d.is_dir():
                continue
            real = d.resolve()
            if real in seen:
                continue
            seen.add(real)

            found_any = False
            for name in CONFIG_FILE_NAMES:
                f = d / name
                if f.is_file():
                    self._config_files.append(f)
                    found_any = True

            if found_any:
                self._config_dirs.append(d)
                if self._install_dir is None:
                    self._install_dir = d

    def _detect_version(self) -> None:
        """Try to detect OpenClaw version."""
        import re

        # Method 1: openclaw --version
        try:
            result = subprocess.run(
                ["openclaw", "--version"],
                capture_output=True, text=True, timeout=5,
            )
            if result.returncode == 0 and result.stdout.strip():
                match = re.search(r"(\d+\.\d+\.\d+)", result.stdout)
                if match:
                    self._version = match.group(1)
                    return
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

        # Method 2: package.json in install dir
        if self.install_dir:
            pkg_json = self.install_dir / "package.json"
            if pkg_json.is_file():
                try:
                    data = json.loads(pkg_json.read_text())
                    self._version = data.get("version")
                    return
                except (json.JSONDecodeError, OSError):
                    pass

    def read_config(self, path: Path) -> Dict[str, Any]:
        """Read and parse a config file (JSON or YAML)."""
        text = path.read_text(encoding="utf-8", errors="ignore")

        if path.suffix == ".json":
            return json.loads(text)

        if path.suffix in (".yaml", ".yml"):
            try:
                import yaml
                return yaml.safe_load(text) or {}
            except ImportError:
                return {}

        # .env -> key=value
        if path.name == ".env":
            result: Dict[str, Any] = {}
            for line in text.splitlines():
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                if "=" in line:
                    k, _, v = line.partition("=")
                    result[k.strip()] = v.strip().strip("'\"")
            return result

        return {}

    def config_has_key(self, key: str) -> bool:
        """Check if any config file contains a key (grep-style)."""
        import re
        pattern = re.compile(rf"(^|\s){re.escape(key)}", re.MULTILINE)
        for f in self.config_files:
            try:
                text = f.read_text(encoding="utf-8", errors="ignore")
                if pattern.search(text):
                    return True
            except OSError:
                continue
        return False

    def config_grep(self, pattern: str) -> bool:
        """Check if any config file matches a regex pattern."""
        import re
        regex = re.compile(pattern, re.IGNORECASE | re.MULTILINE)
        for f in self.config_files:
            try:
                text = f.read_text(encoding="utf-8", errors="ignore")
                if regex.search(text):
                    return True
            except OSError:
                continue
        return False
