"""CVE version matching engine."""

from pathlib import Path
from typing import List, Dict, Any, Optional

import yaml
from packaging.version import Version


CVE_DB_PATH = Path(__file__).resolve().parent / "openclaw_cves.yaml"
USER_CVE_DB = Path.home() / ".clawaudit" / "cvedb" / "openclaw_cves.yaml"


def load_cvedb(path: Optional[Path] = None) -> List[Dict[str, Any]]:
    """Load CVE database from YAML. User-updated DB takes priority over bundled."""
    if path:
        return _load_yaml(path)

    # Prefer user-updated DB, fall back to bundled
    if USER_CVE_DB.is_file():
        data = _load_yaml(USER_CVE_DB)
        if data:
            return data

    return _load_yaml(CVE_DB_PATH)


def _load_yaml(db_path: Path) -> List[Dict[str, Any]]:
    """Load and validate a YAML CVE database file."""
    if not db_path.is_file():
        return []
    try:
        with open(db_path, "r", encoding="utf-8", errors="ignore") as f:
            data = yaml.safe_load(f)
        if not isinstance(data, list):
            return []
        return data
    except Exception:
        return []


def match_version(version_str: str, cves: Optional[List[Dict[str, Any]]] = None) -> List[Dict[str, Any]]:
    """Return CVEs that affect the given version."""
    if cves is None:
        cves = load_cvedb()

    try:
        ver = Version(version_str)
    except Exception:
        return []

    matched = []
    for cve in cves:
        affected = cve.get("affected", "")
        if _version_in_range(ver, affected):
            matched.append(cve)

    return matched


def _version_in_range(ver: Version, affected: str) -> bool:
    """Check if version matches an affected range string.

    Supported formats:
        "< 4.2.1"
        "<= 4.2.1"
        ">= 4.0.0, < 4.2.1"
        ">= 1.0, < 1.5 || >= 2.0, < 2.3"   (OR of ranges)
    """
    if not affected or not affected.strip():
        return False

    # Split on || for OR expressions
    or_groups = [g.strip() for g in affected.split("||")]

    for group in or_groups:
        # Each group is an AND of constraints separated by comma
        parts = [p.strip() for p in group.split(",") if p.strip()]
        if parts and all(_check_constraint(ver, part) for part in parts):
            return True

    return False


def _check_constraint(ver: Version, constraint: str) -> bool:
    """Check a single version constraint like '< 4.2.1' or '>= 4.0.0'."""
    constraint = constraint.strip()

    if constraint.startswith("<="):
        threshold_str = constraint[2:].strip()
        try:
            return ver <= Version(threshold_str)
        except Exception:
            return False
    elif constraint.startswith("<"):
        threshold_str = constraint[1:].strip()
        try:
            return ver < Version(threshold_str)
        except Exception:
            return False
    elif constraint.startswith(">="):
        threshold_str = constraint[2:].strip()
        try:
            return ver >= Version(threshold_str)
        except Exception:
            return False
    elif constraint.startswith(">"):
        threshold_str = constraint[1:].strip()
        try:
            return ver > Version(threshold_str)
        except Exception:
            return False
    elif constraint.startswith("="):
        threshold_str = constraint.lstrip("= ").strip()
        try:
            return ver == Version(threshold_str)
        except Exception:
            return False

    return False
