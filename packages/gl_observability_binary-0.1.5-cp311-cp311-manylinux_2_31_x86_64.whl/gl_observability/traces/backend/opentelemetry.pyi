from _typeshed import Incomplete
from opentelemetry.sdk.trace import TracerProvider
from typing import Any

class OpenTelemetryBackendConfig:
    """Configuration for OpenTelemetry OTLP exporter."""
    endpoint: Incomplete
    headers: Incomplete
    use_grpc: Incomplete
    additional_options: Incomplete
    def __init__(self, *, endpoint: str, headers: dict[str, str] = None, use_grpc: bool = True, **kwargs: Any) -> None:
        '''Initializes the OpenTelemetryBackendConfig configuration object with the specified parameters.

        Args:
            endpoint (str): The OTLP endpoint e.g. "https://localhost:4318".
            headers (dict[str, str], optional): Headers with key value for connecting to the exporter. Defaults to None.
            use_grpc (bool, optional): Use gRPC for OpenTelemetry exporter. Defaults to True.
            **kwargs: Additional keyword arguments passed to OTLPSpanExporter.
        '''

def init_otel_with_external_exporter(config: OpenTelemetryBackendConfig, tracer_provider: TracerProvider) -> None:
    """Initialize OpenTelemetry with an external OTLP exporter.

    This method initializes OpenTelemetry with an external exporter (OTLP)
    and instruments FastAPI, Langchain, HTTPX, and Requests if configured.

    Args:
        config (OpenTelemetryBackendConfig): The OTLP exporter configuration.
        tracer_provider (TracerProvider): The tracer provider to use.
    """
