from _typeshed import Incomplete
from fastapi import FastAPI
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.sampling import Sampler

class FastAPIConfig:
    """Configuration for FastAPI instrumentation."""
    app: Incomplete
    def __init__(self, app: FastAPI) -> None:
        """Initialize FastAPI configuration.

        Args:
            app (FastAPI): The FastAPI application instance.
        """

class OpenTelemetryTraceConfig:
    """Configuration for OpenTelemetry Trace initialization."""
    provider: TracerProvider | None
    attributes: Incomplete
    trace_sampler: Incomplete
    fastapi_config: Incomplete
    use_langchain: Incomplete
    use_httpx: Incomplete
    use_requests: Incomplete
    log_trace_context: Incomplete
    def __init__(self, *, attributes: dict[str, str], trace_sampler: Sampler | None, fastapi_config: FastAPIConfig | None, use_langchain: bool, use_httpx: bool, use_requests: bool, log_trace_context: bool) -> None:
        """Initialize OpenTelemetry configuration.

        Args:
            attributes (dict[str, str]): Resource attributes.
            trace_sampler (Sampler): Trace sampler.
            fastapi_config (FastAPIConfig): FastAPI configuration.
            use_langchain (bool): Enable Langchain instrumentation.
            use_httpx (bool): Enable HTTPX instrumentation.
            use_requests (bool): Enable Requests instrumentation.
            log_trace_context (bool): Add trace context to logs.
        """

def setup_tracer_provider(opentelemetry_config: OpenTelemetryTraceConfig):
    """Set up the TracerProvider with the given configuration.

    Args:
        opentelemetry_config (OpenTelemetryTraceConfig): The configuration for OpenTelemetry.
    """
def auto_initialize_services(opentelemetry_config: OpenTelemetryTraceConfig) -> None:
    """Automatically initialize FastAPI, Langchain, HTTPX, and Requests tracing if applicable.

    Args:
        opentelemetry_config (OpenTelemetryTraceConfig): The configuration for OpenTelemetry.
    """
