# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

__title__ = "supermemory"
__version__ = "3.29.0"  # x-release-please-version
