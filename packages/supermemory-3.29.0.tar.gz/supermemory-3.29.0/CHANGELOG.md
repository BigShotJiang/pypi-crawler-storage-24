# Changelog

## 3.29.0 (2026-03-12)

Full Changelog: [v3.28.0...v3.29.0](https://github.com/supermemoryai/python-sdk/compare/v3.28.0...v3.29.0)

### Features

* **api:** api update ([fe80425](https://github.com/supermemoryai/python-sdk/commit/fe80425181b93862c2d544b5d5664827aa41a57a))
* **api:** api update ([de304ee](https://github.com/supermemoryai/python-sdk/commit/de304ee6d6f3938ee8f866dcca0dde26d98fb369))

## 3.28.0 (2026-03-09)

Full Changelog: [v3.27.0...v3.28.0](https://github.com/supermemoryai/python-sdk/compare/v3.27.0...v3.28.0)

### Features

* **api:** api update ([0631be2](https://github.com/supermemoryai/python-sdk/commit/0631be2c3b7274f34b362ddc902c7f377c5ee11b))


### Chores

* **ci:** skip uploading artifacts on stainless-internal branches ([9b8ce06](https://github.com/supermemoryai/python-sdk/commit/9b8ce065606550ceec128b6d8e0fd15f51c3c32d))
* **internal:** make `test_proxy_environment_variables` more resilient to env ([0f56565](https://github.com/supermemoryai/python-sdk/commit/0f5656508ff42b297ec9a47b40d06a5ffc0a1a7e))
* update placeholder string ([f37dc85](https://github.com/supermemoryai/python-sdk/commit/f37dc85ff4113d4a8c7f1155eecd8ae90db5bb14))

## 3.27.0 (2026-02-24)

Full Changelog: [v3.26.0...v3.27.0](https://github.com/supermemoryai/python-sdk/compare/v3.26.0...v3.27.0)

### Features

* **api:** api update ([04a5168](https://github.com/supermemoryai/python-sdk/commit/04a51688c214687dc622500c934d053e046b38c1))


### Chores

* **internal:** add request options to SSE classes ([2d6cdd8](https://github.com/supermemoryai/python-sdk/commit/2d6cdd83fb5f6097f940cdea43eafe2f73a510ca))
* **internal:** make `test_proxy_environment_variables` more resilient ([1539616](https://github.com/supermemoryai/python-sdk/commit/1539616c58f9f72e63c560d6c08e6bf8b04a0740))

## 3.26.0 (2026-02-20)

Full Changelog: [v3.25.0...v3.26.0](https://github.com/supermemoryai/python-sdk/compare/v3.25.0...v3.26.0)

### Features

* **api:** api update ([0bfae9d](https://github.com/supermemoryai/python-sdk/commit/0bfae9dce59817f6aa92f79a35f033d5888501af))


### Chores

* **internal:** remove mock server code ([1135336](https://github.com/supermemoryai/python-sdk/commit/113533627803db42f5b519cc2ba978da81f4c99d))
* update mock server docs ([b382215](https://github.com/supermemoryai/python-sdk/commit/b382215ce4f4062f43fa4b0ef686e90bf461c651))

## 3.25.0 (2026-02-18)

Full Changelog: [v3.24.0...v3.25.0](https://github.com/supermemoryai/python-sdk/compare/v3.24.0...v3.25.0)

### Features

* **api:** api update ([93a76e1](https://github.com/supermemoryai/python-sdk/commit/93a76e11b33bb52c265541c583e47bbea26462d1))


### Chores

* format all `api.md` files ([d879ea5](https://github.com/supermemoryai/python-sdk/commit/d879ea5d7e4ebe83220572692ddad28a4fc94b30))
* **internal:** bump dependencies ([f992701](https://github.com/supermemoryai/python-sdk/commit/f992701f8e78502f43616240eb04c10f6c679862))
* **internal:** fix lint error on Python 3.14 ([035b6d6](https://github.com/supermemoryai/python-sdk/commit/035b6d665e03ea518f2d40bd967bc63472087705))

## 3.24.0 (2026-02-09)

Full Changelog: [v3.23.0...v3.24.0](https://github.com/supermemoryai/python-sdk/compare/v3.23.0...v3.24.0)

### Features

* **api:** api update ([6810b55](https://github.com/supermemoryai/python-sdk/commit/6810b55267411f6c2d8224500b47468c959ad15f))

## 3.23.0 (2026-02-04)

Full Changelog: [v3.22.0...v3.23.0](https://github.com/supermemoryai/python-sdk/compare/v3.22.0...v3.23.0)

### Features

* **api:** manual updates ([a3004d4](https://github.com/supermemoryai/python-sdk/commit/a3004d4d01562d4eb38367a6e0a5f42ca9d4bdf7))

## 3.22.0 (2026-02-03)

Full Changelog: [v3.21.0...v3.22.0](https://github.com/supermemoryai/python-sdk/compare/v3.21.0...v3.22.0)

### Features

* **api:** api update ([70a03ea](https://github.com/supermemoryai/python-sdk/commit/70a03eaf972c0b12191b1ef64d70efeec0dcd19a))

## 3.21.0 (2026-01-30)

Full Changelog: [v3.20.1...v3.21.0](https://github.com/supermemoryai/python-sdk/compare/v3.20.1...v3.21.0)

### Features

* **client:** add custom JSON encoder for extended type support ([a5e73e7](https://github.com/supermemoryai/python-sdk/commit/a5e73e708a2348598bd0c13cc074d827ece2cfeb))

## 3.20.1 (2026-01-29)

Full Changelog: [v3.20.0...v3.20.1](https://github.com/supermemoryai/python-sdk/compare/v3.20.0...v3.20.1)

### Bug Fixes

* **docs:** fix mcp installation instructions for remote servers ([e695a58](https://github.com/supermemoryai/python-sdk/commit/e695a5834959e52a0d66b753ea12e33ebc828fab))


### Chores

* **ci:** upgrade `actions/github-script` ([e3c1865](https://github.com/supermemoryai/python-sdk/commit/e3c1865c4f1a767683d2fdde59ec9aa50fe5724e))

## 3.20.0 (2026-01-20)

Full Changelog: [v3.19.0...v3.20.0](https://github.com/supermemoryai/python-sdk/compare/v3.19.0...v3.20.0)

### Features

* **api:** api update ([c9a42fe](https://github.com/supermemoryai/python-sdk/commit/c9a42fe1848009b9acb1a918e2d8f424e779c6c7))

## 3.19.0 (2026-01-19)

Full Changelog: [v3.18.0...v3.19.0](https://github.com/supermemoryai/python-sdk/compare/v3.18.0...v3.19.0)

### Features

* **api:** api update ([7f096e5](https://github.com/supermemoryai/python-sdk/commit/7f096e5dbb3fd423ca0e9311ba0568cc15c00902))


### Chores

* **internal:** update `actions/checkout` version ([0639b9e](https://github.com/supermemoryai/python-sdk/commit/0639b9ece23ae00871fc4ff7a8817ff8e81469cd))

## 3.18.0 (2026-01-14)

Full Changelog: [v3.17.0...v3.18.0](https://github.com/supermemoryai/python-sdk/compare/v3.17.0...v3.18.0)

### Features

* **api:** api update ([e29bfb0](https://github.com/supermemoryai/python-sdk/commit/e29bfb02e15babd725dbc1ac41230ed87860f7f3))
* **client:** add support for binary request streaming ([e7ea563](https://github.com/supermemoryai/python-sdk/commit/e7ea563f6399ed0dc1fe23dcc335d11fdbd2489f))

## 3.17.0 (2026-01-13)

Full Changelog: [v3.16.0...v3.17.0](https://github.com/supermemoryai/python-sdk/compare/v3.16.0...v3.17.0)

### Features

* **api:** api update ([5399a83](https://github.com/supermemoryai/python-sdk/commit/5399a83653cada41a3193c640cd3015b5a377c87))

## 3.16.0 (2026-01-09)

Full Changelog: [v3.15.0...v3.16.0](https://github.com/supermemoryai/python-sdk/compare/v3.15.0...v3.16.0)

### Features

* **api:** api update ([4c3edc4](https://github.com/supermemoryai/python-sdk/commit/4c3edc43f68c587c057c32121e8358001aaf69c4))
* **api:** api update ([de63737](https://github.com/supermemoryai/python-sdk/commit/de637371b47ea630d4b1258a25706c016b519b93))

## 3.15.0 (2026-01-09)

Full Changelog: [v3.14.0...v3.15.0](https://github.com/supermemoryai/python-sdk/compare/v3.14.0...v3.15.0)

### Features

* **api:** api update ([8df190c](https://github.com/supermemoryai/python-sdk/commit/8df190ce72d0340f459ec64e3a8463025e33c3af))


### Documentation

* prominently feature MCP server setup in root SDK readmes ([a1b1bbe](https://github.com/supermemoryai/python-sdk/commit/a1b1bbe66bff136314597e68504a404e2dea68ba))

## 3.14.0 (2026-01-05)

Full Changelog: [v3.13.0...v3.14.0](https://github.com/supermemoryai/python-sdk/compare/v3.13.0...v3.14.0)

### Features

* **api:** api update ([a3f0230](https://github.com/supermemoryai/python-sdk/commit/a3f02302f1367d3c1debc81d9a9038ec1c330c85))

## 3.13.0 (2025-12-29)

Full Changelog: [v3.12.1...v3.13.0](https://github.com/supermemoryai/python-sdk/compare/v3.12.1...v3.13.0)

### Features

* **api:** api update ([94d92d9](https://github.com/supermemoryai/python-sdk/commit/94d92d978d3c7e53d0ad1e8704845a105733b95c))

## 3.12.1 (2025-12-19)

Full Changelog: [v3.12.0...v3.12.1](https://github.com/supermemoryai/python-sdk/compare/v3.12.0...v3.12.1)

### Chores

* **internal:** add `--fix` argument to lint script ([43c4206](https://github.com/supermemoryai/python-sdk/commit/43c42067ce474eacac435fd686ff8f6bb1d159d1))

## 3.12.0 (2025-12-18)

Full Changelog: [v3.11.1...v3.12.0](https://github.com/supermemoryai/python-sdk/compare/v3.11.1...v3.12.0)

### Features

* **api:** api update ([928291a](https://github.com/supermemoryai/python-sdk/commit/928291a1778a0abaecfa72f0d244af3aad03e8c1))

## 3.11.1 (2025-12-18)

Full Changelog: [v3.11.0...v3.11.1](https://github.com/supermemoryai/python-sdk/compare/v3.11.0...v3.11.1)

### Bug Fixes

* use async_to_httpx_files in patch method ([aa13c3d](https://github.com/supermemoryai/python-sdk/commit/aa13c3d8760b95b308fe785a9a022375c8021379))


### Chores

* **internal:** add missing files argument to base client ([8c1dda0](https://github.com/supermemoryai/python-sdk/commit/8c1dda0fc98ab035e884fe78d3025ec69f04cc82))
* speedup initial import ([088bf48](https://github.com/supermemoryai/python-sdk/commit/088bf4882131b61f629bb6bc2a78c872263d5712))

## 3.11.0 (2025-12-11)

Full Changelog: [v3.10.0...v3.11.0](https://github.com/supermemoryai/python-sdk/compare/v3.10.0...v3.11.0)

### Features

* **api:** api update ([b4b239e](https://github.com/supermemoryai/python-sdk/commit/b4b239ef02d6c8018d761a2d660cd2182a10dde8))

## 3.10.0 (2025-12-10)

Full Changelog: [v3.9.0...v3.10.0](https://github.com/supermemoryai/python-sdk/compare/v3.9.0...v3.10.0)

### Features

* **api:** api update ([4b30459](https://github.com/supermemoryai/python-sdk/commit/4b3045968d0fccd106e87a1aa3f4c7c49a1475fe))
* **api:** api update ([8225250](https://github.com/supermemoryai/python-sdk/commit/822525089de88691c334f32b8ae3bf71096894e9))
* **api:** manual updates ([3691dfd](https://github.com/supermemoryai/python-sdk/commit/3691dfd45b9c8c15e8d318adc4b79e8c8ae9ed27))
* **api:** manual updates ([be8efa6](https://github.com/supermemoryai/python-sdk/commit/be8efa6ea1c7fdb58428741e7938540e266cbdc2))
* **api:** manual updates ([094162f](https://github.com/supermemoryai/python-sdk/commit/094162f52b3eba730f85176acfb5b5f34267449f))
* **api:** manual updates ([13a8b89](https://github.com/supermemoryai/python-sdk/commit/13a8b89e35e60356537d1c59c6721043e45d7577))
* **api:** manual updates ([acee529](https://github.com/supermemoryai/python-sdk/commit/acee529be2cdc01a6452cf3981575ece4905465a))
* **api:** manual updates ([ca75227](https://github.com/supermemoryai/python-sdk/commit/ca75227ff922f6d25d4a12e045066fe6545454af))

## 3.9.0 (2025-12-09)

Full Changelog: [v3.8.0...v3.9.0](https://github.com/supermemoryai/python-sdk/compare/v3.8.0...v3.9.0)

### Features

* **api:** api update ([3042cbf](https://github.com/supermemoryai/python-sdk/commit/3042cbfd221d52291480c6df1c1fca40eb97a61f))
* **api:** manual updates ([96b34d0](https://github.com/supermemoryai/python-sdk/commit/96b34d0a371e0d9c9866e1dbbfd70329d9400850))


### Bug Fixes

* ensure streams are always closed ([a1403da](https://github.com/supermemoryai/python-sdk/commit/a1403da98836ac4215ee81f168ff044dcd83fc83))
* **types:** allow pyright to infer TypedDict types within SequenceNotStr ([4c1365d](https://github.com/supermemoryai/python-sdk/commit/4c1365d2bc02b2d81eb99ef93ac56f1f1b6aba3c))


### Chores

* add missing docstrings ([bdb32bc](https://github.com/supermemoryai/python-sdk/commit/bdb32bc4a13ae9a73409f827082a1c5637dc9860))
* **deps:** mypy 1.18.1 has a regression, pin to 1.17 ([2fc3d2a](https://github.com/supermemoryai/python-sdk/commit/2fc3d2a92410192a31bb1c4a7b85094c2ea55f4a))
* **docs:** use environment variables for authentication in code snippets ([442b9fd](https://github.com/supermemoryai/python-sdk/commit/442b9fdc7e8b7b07dc82cc087ffbc6fbe60bd12f))
* update lockfile ([37b9f74](https://github.com/supermemoryai/python-sdk/commit/37b9f74097fdc2e3395714ccb72c0f470d162ac4))

## 3.8.0 (2025-11-27)

Full Changelog: [v3.7.0...v3.8.0](https://github.com/supermemoryai/python-sdk/compare/v3.7.0...v3.8.0)

### Features

* **api:** api update ([a6a18ce](https://github.com/supermemoryai/python-sdk/commit/a6a18ce48bb1f1f80f4cfe6a9c3b0c9ff4f9fbcb))

## 3.7.0 (2025-11-26)

Full Changelog: [v3.6.0...v3.7.0](https://github.com/supermemoryai/python-sdk/compare/v3.6.0...v3.7.0)

### Features

* **api:** manual updates ([ee2daac](https://github.com/supermemoryai/python-sdk/commit/ee2daac3a0c1a085971a71ef9605d1d4f6fdb3f7))
* **api:** manual updates ([89a6e6d](https://github.com/supermemoryai/python-sdk/commit/89a6e6d1220cd8fd2c38d1c54f412650913a9184))
* **api:** manual updates ([7f0b5aa](https://github.com/supermemoryai/python-sdk/commit/7f0b5aa308004d68b5620f6956068e0c7fbc20da))
* **api:** manual updates ([3f2f954](https://github.com/supermemoryai/python-sdk/commit/3f2f954a542c4f2e6fc7d6e204c7e44fe640ec7d))
* **api:** manual updates ([8680e72](https://github.com/supermemoryai/python-sdk/commit/8680e723f9bd9cdc930ed33914557dc60d5242c0))

## 3.6.0 (2025-11-26)

Full Changelog: [v3.5.0...v3.6.0](https://github.com/supermemoryai/python-sdk/compare/v3.5.0...v3.6.0)

### Features

* **api:** manual updates ([a46347c](https://github.com/supermemoryai/python-sdk/commit/a46347c8640b2442d0f8ffbe4c5f948a9c5edb1b))

## 3.5.0 (2025-11-26)

Full Changelog: [v3.4.0...v3.5.0](https://github.com/supermemoryai/python-sdk/compare/v3.4.0...v3.5.0)

### Features

* **api:** api update ([a7749c9](https://github.com/supermemoryai/python-sdk/commit/a7749c97703d995ed97ba1a5c09fef9e5804bea7))
* **api:** api update ([0972c10](https://github.com/supermemoryai/python-sdk/commit/0972c10cebf6bab936371dfa4c5ad87dad1f5496))
* **api:** api update ([e29337c](https://github.com/supermemoryai/python-sdk/commit/e29337c11f26831d69e6f830542e5db708760b62))
* **api:** api update ([a776c2c](https://github.com/supermemoryai/python-sdk/commit/a776c2cfcf82ee239c707b9065bd3313755388fa))
* **api:** api update ([4e6c8e6](https://github.com/supermemoryai/python-sdk/commit/4e6c8e61653c99c733f862cbb5e08478159d082b))
* **api:** manual updates ([c780b0f](https://github.com/supermemoryai/python-sdk/commit/c780b0fc9afb857dd55613d5b67cd7849b68973c))


### Bug Fixes

* **client:** close streams without requiring full consumption ([1155c43](https://github.com/supermemoryai/python-sdk/commit/1155c4396baa8681dcb72f6b53f90c42052fac6f))
* compat with Python 3.14 ([d42dd9c](https://github.com/supermemoryai/python-sdk/commit/d42dd9c177546142c2d87484e1bb435401cfaac8))
* **compat:** update signatures of `model_dump` and `model_dump_json` for Pydantic v1 ([447f54f](https://github.com/supermemoryai/python-sdk/commit/447f54f0f7846283b4033275fe2042f6dff66a2c))


### Chores

* add Python 3.14 classifier and testing ([8802bdd](https://github.com/supermemoryai/python-sdk/commit/8802bdd0529ef3759bf1b8547ce2405c8164d0e9))
* bump `httpx-aiohttp` version to 0.1.9 ([6ad4b61](https://github.com/supermemoryai/python-sdk/commit/6ad4b613df1d4177fabeaf0b67d984e195af8594))
* **internal/tests:** avoid race condition with implicit client cleanup ([7bad0fc](https://github.com/supermemoryai/python-sdk/commit/7bad0fc387de50f25bec0e3a7ecca2b732294460))
* **internal:** detect missing future annotations with ruff ([6085dd3](https://github.com/supermemoryai/python-sdk/commit/6085dd39d67398eec25d5b9bcc5371f4810622c8))
* **internal:** grammar fix (it's -&gt; its) ([329768e](https://github.com/supermemoryai/python-sdk/commit/329768ed8cec31b2ef510409b9f67a3f800a286b))
* **package:** drop Python 3.8 support ([9feb588](https://github.com/supermemoryai/python-sdk/commit/9feb588a112036bd5de9041f775232f7c1384e3f))

## 3.4.0 (2025-10-07)

Full Changelog: [v3.3.0...v3.4.0](https://github.com/supermemoryai/python-sdk/compare/v3.3.0...v3.4.0)

### Features

* **api:** api update ([ad11246](https://github.com/supermemoryai/python-sdk/commit/ad112460d7aa5642895c4dec8b9c4e1993c01635))
* **api:** api update ([0a01f62](https://github.com/supermemoryai/python-sdk/commit/0a01f623aa5daf19192259bee921e65acd583244))
* **api:** api update ([91585de](https://github.com/supermemoryai/python-sdk/commit/91585de6396d6529c2d15b2b2c4db481e72f32d0))
* **api:** api update ([2a12ab8](https://github.com/supermemoryai/python-sdk/commit/2a12ab834b2748eb30a6bad5ea6ce6e53644334e))
* **api:** manual updates ([71bae29](https://github.com/supermemoryai/python-sdk/commit/71bae2938f3c523b3bb5f814e96937f067f454f5))

## 3.3.0 (2025-09-21)

Full Changelog: [v3.2.0...v3.3.0](https://github.com/supermemoryai/python-sdk/compare/v3.2.0...v3.3.0)

### Features

* **api:** api update ([fd86dc5](https://github.com/supermemoryai/python-sdk/commit/fd86dc5ee1a83000113c7dcc8ba678af94d825bd))

## 3.2.0 (2025-09-21)

Full Changelog: [v3.1.0...v3.2.0](https://github.com/supermemoryai/python-sdk/compare/v3.1.0...v3.2.0)

### Features

* **api:** api update ([82b35f0](https://github.com/supermemoryai/python-sdk/commit/82b35f0447a67d089304d57f41d1d1527f6da7fb))

## 3.1.0 (2025-09-20)

Full Changelog: [v3.0.0-alpha.30...v3.1.0](https://github.com/supermemoryai/python-sdk/compare/v3.0.0-alpha.30...v3.1.0)

### Features

* **api:** api update ([19c5dd3](https://github.com/supermemoryai/python-sdk/commit/19c5dd364b496d9a7858e1764000aba6d71613c6))
* **api:** api update ([3082481](https://github.com/supermemoryai/python-sdk/commit/30824814233753584a89c56a2efb69d72995be02))
* **api:** manual updates ([e92cb27](https://github.com/supermemoryai/python-sdk/commit/e92cb27550c2190a6804a2865ae359ff79fa1866))
* **api:** manual updates ([251fdf1](https://github.com/supermemoryai/python-sdk/commit/251fdf116f5f1b0c1ecfb74bef94ba08f7921dca))


### Chores

* do not install brew dependencies in ./scripts/bootstrap by default ([fb748cf](https://github.com/supermemoryai/python-sdk/commit/fb748cf2375b1ce1eddd2584503e81d3b8386443))
* **internal:** update pydantic dependency ([8c480f7](https://github.com/supermemoryai/python-sdk/commit/8c480f70cf3d0e55c4c5bc3b77d83bd6b21c4fdf))
* **types:** change optional parameter type from NotGiven to Omit ([3031781](https://github.com/supermemoryai/python-sdk/commit/30317810d7089dbdf59f5e143bd66b1a0495b2b6))

## 3.0.0-alpha.30 (2025-09-15)

Full Changelog: [v3.0.0-alpha.29...v3.0.0-alpha.30](https://github.com/supermemoryai/python-sdk/compare/v3.0.0-alpha.29...v3.0.0-alpha.30)

### Features

* **api:** api update ([b7df28e](https://github.com/supermemoryai/python-sdk/commit/b7df28ec025c70d7b8e1544aa1ef0262c0be8a03))
* **api:** api update ([54cf9c1](https://github.com/supermemoryai/python-sdk/commit/54cf9c13bf3ff378dd6a19a15c9e343e822ab99a))
* **api:** api update ([4812077](https://github.com/supermemoryai/python-sdk/commit/48120771b2476f2d2863a1614edc222e863ddde4))
* **api:** api update ([a4f4259](https://github.com/supermemoryai/python-sdk/commit/a4f425943298762bdfb7f3b0421f8d56d2e1473c))
* **api:** api update ([8412e4d](https://github.com/supermemoryai/python-sdk/commit/8412e4d06b0225fd3707a55b743c401d87b1c0aa))
* improve future compat with pydantic v3 ([70ea8b7](https://github.com/supermemoryai/python-sdk/commit/70ea8b7206b2e8db3d86f5a1674e7dd2f7a7e67b))
* **types:** replace List[str] with SequenceNotStr in params ([f4bfda3](https://github.com/supermemoryai/python-sdk/commit/f4bfda34d40ca947eae6a32ea323dafeddf51484))


### Chores

* **internal:** add Sequence related utils ([d2b96ed](https://github.com/supermemoryai/python-sdk/commit/d2b96ed43577a3d046ffea7cbc87ba6b877beba7))
* **internal:** move mypy configurations to `pyproject.toml` file ([31832f5](https://github.com/supermemoryai/python-sdk/commit/31832f5046f7b6384c1bb506680319890e3a5194))
* **tests:** simplify `get_platform` test ([30d8e46](https://github.com/supermemoryai/python-sdk/commit/30d8e464a5d8ceb5cec41a6197c291962b78b0b5))

## 3.0.0-alpha.29 (2025-08-27)

Full Changelog: [v3.0.0-alpha.28...v3.0.0-alpha.29](https://github.com/supermemoryai/python-sdk/compare/v3.0.0-alpha.28...v3.0.0-alpha.29)

### Features

* **api:** api update ([5c48767](https://github.com/supermemoryai/python-sdk/commit/5c48767f77b0daf362be422e6d2d8843c15692b3))
* **api:** api update ([8eb53ac](https://github.com/supermemoryai/python-sdk/commit/8eb53ac4b04fae2f656d82c2c36c01e6583a08e0))
* **api:** api update ([9194990](https://github.com/supermemoryai/python-sdk/commit/9194990dfbe4e8b9a3fe145095ae65c1cab1b342))
* **api:** api update ([be04a5c](https://github.com/supermemoryai/python-sdk/commit/be04a5cf50c9af30b04e43128a860a93305f401a))


### Bug Fixes

* avoid newer type syntax ([cd791b9](https://github.com/supermemoryai/python-sdk/commit/cd791b97c02fe5728e54482097c846557ab0d555))


### Chores

* **internal:** change ci workflow machines ([002a748](https://github.com/supermemoryai/python-sdk/commit/002a748ddf690fcaeab905c622fe598ddc0f6629))
* **internal:** update pyright exclude list ([41a59ff](https://github.com/supermemoryai/python-sdk/commit/41a59ff7fb26bd419f747265c00a99ad750833d0))

## 3.0.0-alpha.28 (2025-08-24)

Full Changelog: [v3.0.0-alpha.27...v3.0.0-alpha.28](https://github.com/supermemoryai/python-sdk/compare/v3.0.0-alpha.27...v3.0.0-alpha.28)

### Features

* **api:** api update ([0745263](https://github.com/supermemoryai/python-sdk/commit/074526384ea43d5323feeb2101054e0515002169))

## 3.0.0-alpha.27 (2025-08-24)

Full Changelog: [v3.0.0-alpha.26...v3.0.0-alpha.27](https://github.com/supermemoryai/python-sdk/compare/v3.0.0-alpha.26...v3.0.0-alpha.27)

### Features

* **api:** api update ([27dcd49](https://github.com/supermemoryai/python-sdk/commit/27dcd49c6bbf1c4c1bc11acc02c852a8849f158a))
* **api:** api update ([cf6d58b](https://github.com/supermemoryai/python-sdk/commit/cf6d58befc0f976222f875eb74594b64a4e36803))


### Chores

* update github action ([65d9e06](https://github.com/supermemoryai/python-sdk/commit/65d9e06acc7a7cbabefb2625c4404848681c0e03))

## 3.0.0-alpha.26 (2025-08-15)

Full Changelog: [v3.0.0-alpha.25...v3.0.0-alpha.26](https://github.com/supermemoryai/python-sdk/compare/v3.0.0-alpha.25...v3.0.0-alpha.26)

### Features

* **api:** manual updates ([c2623b2](https://github.com/supermemoryai/python-sdk/commit/c2623b2b645eefd7e2cbb5027eb5a46cee7b62eb))
* **api:** manual updates ([9e373ef](https://github.com/supermemoryai/python-sdk/commit/9e373ef0b585eb15cb04b95a1bab46c8c102970c))
* **api:** manual updates ([fa75aff](https://github.com/supermemoryai/python-sdk/commit/fa75affffb701259be14445da95c77a1cdde512b))

## 3.0.0-alpha.25 (2025-08-15)

Full Changelog: [v3.0.0-alpha.24...v3.0.0-alpha.25](https://github.com/supermemoryai/python-sdk/compare/v3.0.0-alpha.24...v3.0.0-alpha.25)

### Features

* **api:** api update ([9bfc023](https://github.com/supermemoryai/python-sdk/commit/9bfc023373df244fa4d45c12ad31fe5ca2bddc8b))


### Chores

* **internal:** codegen related update ([8df15a7](https://github.com/supermemoryai/python-sdk/commit/8df15a767ca5007ee34b4b7b1bc39e1961203c80))

## 3.0.0-alpha.24 (2025-08-10)

Full Changelog: [v3.0.0-alpha.23...v3.0.0-alpha.24](https://github.com/supermemoryai/python-sdk/compare/v3.0.0-alpha.23...v3.0.0-alpha.24)

### Features

* **api:** api update ([4aacfa8](https://github.com/supermemoryai/python-sdk/commit/4aacfa8f2e35f50ab9ac01c4ae9b5086b8dc2230))
* **api:** api update ([9fe90d9](https://github.com/supermemoryai/python-sdk/commit/9fe90d99035348910c215cb196a27390b7c595d3))
* **api:** api update ([f9c7013](https://github.com/supermemoryai/python-sdk/commit/f9c70137f404d7638d6e77dbf360a276877a55a5))
* **api:** api update ([125afc9](https://github.com/supermemoryai/python-sdk/commit/125afc957cab83c2a0c75ba003479b09e5e0f63c))
* **api:** api update ([04b249d](https://github.com/supermemoryai/python-sdk/commit/04b249d0a09d2fcbd8aecd08bcfc6ff89673fb75))
* **client:** support file upload requests ([b6c42b1](https://github.com/supermemoryai/python-sdk/commit/b6c42b10e8412ccc5dbbed23d86c36598319df00))


### Bug Fixes

* **parsing:** ignore empty metadata ([a58758c](https://github.com/supermemoryai/python-sdk/commit/a58758ce1f1ae0c87d0fa3bea43367bb2d198891))
* **parsing:** parse extra field types ([5253128](https://github.com/supermemoryai/python-sdk/commit/5253128de66dc303f8c9e4d295f133f24f770d95))


### Chores

* **internal:** fix ruff target version ([25adc14](https://github.com/supermemoryai/python-sdk/commit/25adc1412380631fa8ce53034b519e819b45dec3))
* **internal:** update comment in script ([8fc31e8](https://github.com/supermemoryai/python-sdk/commit/8fc31e8cb2058d8bb4da67c5aebbac421474c3b8))
* **project:** add settings file for vscode ([2327687](https://github.com/supermemoryai/python-sdk/commit/232768766d49d14af45667f08ad66b890cc6a230))
* update @stainless-api/prism-cli to v5.15.0 ([7f4ff8b](https://github.com/supermemoryai/python-sdk/commit/7f4ff8b2712055be8a6100a2c132b514cf7e2e6d))

## 3.0.0-alpha.23 (2025-07-15)

Full Changelog: [v3.0.0-alpha.22...v3.0.0-alpha.23](https://github.com/supermemoryai/python-sdk/compare/v3.0.0-alpha.22...v3.0.0-alpha.23)

### Features

* **api:** api update ([3f71f60](https://github.com/supermemoryai/python-sdk/commit/3f71f60954dedc0a91e1859df48c5c3ca0a47c88))
* **api:** api update ([b614732](https://github.com/supermemoryai/python-sdk/commit/b61473253183d434613b0aeb631376262d22cb0c))
* clean up environment call outs ([4aaccf1](https://github.com/supermemoryai/python-sdk/commit/4aaccf17ae31c04f3097fe04a6a081171fc725d1))


### Bug Fixes

* **client:** don't send Content-Type header on GET requests ([80480dd](https://github.com/supermemoryai/python-sdk/commit/80480dd46271dc5136f39c5ff1315555b8d51e31))
* **parsing:** correctly handle nested discriminated unions ([812e982](https://github.com/supermemoryai/python-sdk/commit/812e982cbba93e197d4cd3cf8bdfa710e7830a78))


### Chores

* **internal:** bump pinned h11 dep ([9e822a1](https://github.com/supermemoryai/python-sdk/commit/9e822a16ce8cf30791abf6384e2e3205233eeaba))
* **package:** mark python 3.13 as supported ([2dc73dd](https://github.com/supermemoryai/python-sdk/commit/2dc73dd51ac30fa4d6b2d370b7411857518c1ddd))
* **readme:** fix version rendering on pypi ([a6d7d7a](https://github.com/supermemoryai/python-sdk/commit/a6d7d7a100680cfaa03138542f60b7b7407ad347))

## 3.0.0-alpha.22 (2025-07-03)

Full Changelog: [v3.0.0-alpha.21...v3.0.0-alpha.22](https://github.com/supermemoryai/python-sdk/compare/v3.0.0-alpha.21...v3.0.0-alpha.22)

### Features

* **api:** manual updates ([2a863a1](https://github.com/supermemoryai/python-sdk/commit/2a863a166b5c39208ef910d84530a27898ed0c71))

## 3.0.0-alpha.21 (2025-07-03)

Full Changelog: [v3.0.0-alpha.20...v3.0.0-alpha.21](https://github.com/supermemoryai/python-sdk/compare/v3.0.0-alpha.20...v3.0.0-alpha.21)

### Features

* **api:** api update ([8b94b9e](https://github.com/supermemoryai/python-sdk/commit/8b94b9e043564f8daf605289683270dba97ca323))
* **api:** api update ([7b7eda7](https://github.com/supermemoryai/python-sdk/commit/7b7eda703a9d3dcf9b235a5045829c69147240c6))
* **api:** manual updates ([e7bfa6e](https://github.com/supermemoryai/python-sdk/commit/e7bfa6ef5804b758d3da98206ee643f9ae44ce0a))


### Bug Fixes

* **ci:** correct conditional ([0b20719](https://github.com/supermemoryai/python-sdk/commit/0b20719ce022a872dd7334587317235b7a5562c3))


### Chores

* **ci:** change upload type ([38f5701](https://github.com/supermemoryai/python-sdk/commit/38f5701dff0cc09b4a42d1c86e6250ed4695783d))
* **ci:** only run for pushes and fork pull requests ([901a43c](https://github.com/supermemoryai/python-sdk/commit/901a43c0c06fb8ed2ee2cfc3c56d44002b108a06))
* **internal:** codegen related update ([9c82bc7](https://github.com/supermemoryai/python-sdk/commit/9c82bc7c2fff3e85ec8a8d3278b04741bedaf7d3))

## 3.0.0-alpha.20 (2025-06-27)

Full Changelog: [v3.0.0-alpha.19...v3.0.0-alpha.20](https://github.com/supermemoryai/python-sdk/compare/v3.0.0-alpha.19...v3.0.0-alpha.20)

### Features

* **api:** api update ([3c35763](https://github.com/supermemoryai/python-sdk/commit/3c357637aab2e68e3a80e33b9f721c3a8182483a))
* **api:** api update ([08ffef9](https://github.com/supermemoryai/python-sdk/commit/08ffef95b8f7be8ce8a57ba2fe2761653cd42e5d))


### Bug Fixes

* **ci:** release-doctor — report correct token name ([dadfa9f](https://github.com/supermemoryai/python-sdk/commit/dadfa9f74851fc81e5af92e47c41115bee87aad7))


### Chores

* sync repo ([380252a](https://github.com/supermemoryai/python-sdk/commit/380252a9cb2d9c723b5c6b36a33573c462e48049))
* update SDK settings ([8c6f297](https://github.com/supermemoryai/python-sdk/commit/8c6f297fc2b8f7a6b600205a5c313767a99612cb))
