// Default YAML shown in the playground editor. Keep in sync with defaultSpec.yaml.
export const DEFAULT_SPEC_YAML = `open_agent_spec: "1.0.8"

agent:
  name: hello-world-agent
  description: A simple agent that responds with a greeting
  role: chat

intelligence:
  type: llm
  engine: openai
  model: gpt-4
  endpoint: https://api.openai.com/v1
  config:
    temperature: 0.7
    max_tokens: 150

tasks:
  greet:
    description: Say hello to a person by name
    timeout: 30
    input:
      type: object
      properties:
        name:
          type: string
          description: The name of the person to greet
          minLength: 1
          maxLength: 100
      required: [name]
    output:
      type: object
      properties:
        response:
          type: string
          description: The greeting response
          minLength: 1
      required: [response]

prompts:
  system: >
    You are a friendly agent that greets people by name.
    Respond with: "Hello <name>!"
  user: "{{ name }}"
`;
