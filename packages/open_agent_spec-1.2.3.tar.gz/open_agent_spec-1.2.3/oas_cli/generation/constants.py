# Copyright (c) Prime Vector Australia, Andrew Whitehouse, Open Agent Stack contributors
# Licensed under the MIT License. See LICENSE for details.

"""Shared constants for generation (prompt templates, etc.)."""

# Single source of truth for the default agent prompt template (task prompts + agent_prompt.jinja2)
DEFAULT_AGENT_PROMPT_TEMPLATE = """You are a professional AI agent designed to process tasks according to the Open Agent Spec.

{% if memory_summary %}
--- MEMORY CONTEXT ---
{{ memory_summary }}
------------------------
{% endif %}

TASK:
Process the following task:

{% for key, value in input.items() %}
{{ key }}: {{ value }}
{% endfor %}

INSTRUCTIONS:
1. Review the input data carefully
2. Consider all relevant factors
{% if memory_summary %}
3. Take into account the provided memory context
{% endif %}
4. Provide a clear, actionable response
5. Explain your reasoning in detail

OUTPUT FORMAT:
Your response should include the following fields:
{{ output_format }}

CONSTRAINTS:
- Be clear and specific
- Focus on actionable insights
- Maintain professional objectivity
{% if memory_summary and memory_config.required %}
- Must reference and incorporate memory context
{% endif %}"""
