"""Data models for codebase exploration (ADR-055).

Extracted from obra/hybrid/handlers/derive.py as part of
REFACTOR-EXPLORATION-001.

Contains:
    ExplorationDecision: Result of should_auto_explore() decision
    ExplorationContext: Result from codebase exploration
    ExplorationCacheEntry: Cache entry for exploration results
    FILE_PATH_PATTERN: Regex for detecting file paths in objectives
    COMPLEXITY_THRESHOLDS: Complexity level thresholds for exploration

Related:
    - docs/decisions/ADR-055-conditional-auto-exploration.md
    - docs/design/prds/CONDITIONAL_AUTO_EXPLORATION_PRD.md
"""

import re
from dataclasses import dataclass
from datetime import datetime
from typing import Any

# File path pattern for detecting explicit paths in objectives (ADR-055)
# Matches paths like: src/foo.py, ./bar/baz.ts, /absolute/path.rs, file.ext
# Tightened third alternative to only match known source/config extensions
# to avoid false positives on abbreviations like "e.g.", "i.e.", "v2.0"
_KNOWN_EXTENSIONS = (
    r"(?:py|js|ts|jsx|tsx|go|rs|java|rb|php|cs|cpp|c|h|hpp"
    r"|yaml|yml|json|toml|md|txt|cfg|ini|xml|html|css|scss"
    r"|sql|sh|bash|zsh|dockerfile)"
)

FILE_PATH_PATTERN = re.compile(
    rf"""
    (?:^|[\s,])                          # Start of string or whitespace/comma
    (?:                                  # Path patterns:
        \.{{0,2}}/[\w\-./]+\.\w+         # ./path/file.ext or /abs/path.ext
        |                                # OR
        [\w\-]+/[\w\-./]+\.\w+           # relative/path/file.ext
        |                                # OR
        [\w\-]+\.{_KNOWN_EXTENSIONS}     # file.ext (single file with known extension)
    )
    (?:[\s,]|$)                          # End with whitespace, comma, or end
    """,
    re.VERBOSE | re.IGNORECASE,
)

# Complexity thresholds for exploration triggers (ADR-055)
COMPLEXITY_THRESHOLDS = {
    "LOW": 0,
    "MEDIUM": 40,
    "HIGH": 70,
}


@dataclass
class ExplorationDecision:
    """Result of should_auto_explore() decision.

    Captures whether exploration should run and why, for logging/debugging.
    """

    should_explore: bool
    reason: str
    complexity_score: float | None = None
    work_type: str | None = None
    recent_exploration: bool = False
    has_explicit_paths: bool = False
    skip_reason: str | None = None


@dataclass
class ExplorationContext:
    """Result from codebase exploration (ADR-055).

    Contains discovered patterns, utilities, and constraints that should
    be injected into the derivation prompt.
    """

    patterns: list[dict[str, Any]]
    relevant_files: list[dict[str, str]]
    utilities: list[dict[str, str]]
    constraints: list[str]
    duration_seconds: float = 0.0
    success: bool = True
    error_message: str = ""

    def to_markdown(self) -> str:
        """Format exploration context as markdown for prompt injection.

        Returns empty string when all four lists are empty to avoid
        injecting a bare heading into the prompt.

        Returns:
            Markdown-formatted string for injection into derivation prompt
        """
        if (
            not self.patterns
            and not self.relevant_files
            and not self.utilities
            and not self.constraints
        ):
            return ""

        sections = ["## Exploration Context (Auto-Generated)\n"]

        if self.patterns:
            sections.append("### Patterns Found")
            for p in self.patterns[:5]:
                file_ref = p.get("file", "unknown")
                sections.append(f"- **{file_ref}**: {p.get('pattern', 'N/A')}")
                if p.get("relevance"):
                    sections.append(f"  - Relevance: {p['relevance']}")
            sections.append("")

        if self.relevant_files:
            sections.append("### Relevant Files")
            for f in self.relevant_files[:25]:
                sections.append(f"- `{f.get('path', 'unknown')}`: {f.get('reason', 'N/A')}")
            sections.append("")

        if self.utilities:
            sections.append("### Utilities to Use")
            for u in self.utilities[:5]:
                sections.append(f"- **{u.get('name', 'unknown')}** ({u.get('location', 'N/A')})")
                if u.get("purpose"):
                    sections.append(f"  - {u['purpose']}")
            sections.append("")

        if self.constraints:
            sections.append("### Constraints")
            for c in self.constraints[:5]:
                sections.append(f"- {c}")
            sections.append("")

        return "\n".join(sections)

    @classmethod
    def empty(cls) -> "ExplorationContext":
        """Create an empty exploration context."""
        return cls(
            patterns=[],
            relevant_files=[],
            utilities=[],
            constraints=[],
        )

    @classmethod
    def from_error(cls, error: str, duration: float = 0.0) -> "ExplorationContext":
        """Create exploration context representing an error state."""
        return cls(
            patterns=[],
            relevant_files=[],
            utilities=[],
            constraints=[],
            duration_seconds=duration,
            success=False,
            error_message=error,
        )


@dataclass
class ExplorationCacheEntry:
    """Cache entry for exploration results (FR-8, ADR-055).

    Stores exploration context along with metadata for cache invalidation.
    Invalidation triggers:
    1. Files in relevant_files have been modified since caching
    2. >10 files changed in working directory since caching
    3. Cache entry older than max_age_seconds (configurable)
    """

    context: ExplorationContext
    cached_at: datetime
    relevant_file_mtimes: dict[str, float]
    file_count_at_cache: int
    objective_hash: str
    work_type: str
