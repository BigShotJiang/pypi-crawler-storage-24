"""Session-scoped exploration cache with invalidation (FR-8, ADR-055).

Extracted from DeriveHandler cache methods as part of
REFACTOR-EXPLORATION-001.

Provides ExplorationCache class that caches exploration results keyed by
objective+work_type, with invalidation based on file modifications, file
count deltas, and cache age.

Related:
    - docs/decisions/ADR-055-conditional-auto-exploration.md
    - docs/design/prds/CONDITIONAL_AUTO_EXPLORATION_PRD.md
"""

import contextlib
import hashlib
import logging
from collections.abc import Callable
from datetime import UTC, datetime
from pathlib import Path

from obra.display import print_info
from obra.exploration.models import ExplorationCacheEntry, ExplorationContext

logger = logging.getLogger(__name__)

# Extensions to count for cache invalidation (common source/config files)
RELEVANT_EXTENSIONS = {
    ".py",
    ".js",
    ".ts",
    ".jsx",
    ".tsx",
    ".go",
    ".rs",
    ".java",
    ".rb",
    ".php",
    ".cs",
    ".cpp",
    ".c",
    ".h",
    ".hpp",
    ".yaml",
    ".yml",
    ".json",
    ".toml",
}


class ExplorationCache:
    """Session-scoped cache for exploration results (FR-8, ADR-055).

    Caches exploration context keyed by SHA-256 of working_dir:objective:work_type.
    Invalidation triggers:
    1. Any relevant file modified since caching
    2. Any relevant file deleted since caching
    3. File count changed by > max_file_delta
    4. Cache entry older than max_age_seconds
    """

    def __init__(
        self,
        working_dir: Path,
        *,
        log_event: Callable[..., None] | None = None,
        trace_id: str | None = None,
        parent_span_id: str | None = None,
    ) -> None:
        self._working_dir = working_dir
        self._log_event = log_event
        self._trace_id = trace_id
        self._parent_span_id = parent_span_id
        self._cache: dict[str, ExplorationCacheEntry] = {}

    def get(self, objective: str, work_type: str) -> ExplorationContext | None:
        """Get cached exploration result if valid.

        Args:
            objective: User objective text
            work_type: Detected work type

        Returns:
            Cached ExplorationContext if valid, None if cache miss or invalid
        """
        cache_key = self._compute_cache_key(objective, work_type)
        entry = self._cache.get(cache_key)

        if entry is None:
            self._log_cache_event("cache_miss", cache_key, reason="no entry")
            return None

        should_invalidate, reason = self._should_invalidate(entry)
        if should_invalidate:
            del self._cache[cache_key]
            self._log_cache_event("cache_invalidated", cache_key, reason=reason)
            return None

        self._log_cache_event("cache_hit", cache_key, entry=entry)
        return entry.context

    def put(self, objective: str, work_type: str, context: ExplorationContext) -> None:
        """Cache exploration result.

        Skips caching for failed explorations.

        Args:
            objective: User objective text
            work_type: Detected work type
            context: Exploration result to cache
        """
        if not context.success:
            return

        cache_key = self._compute_cache_key(objective, work_type)

        # Extract file paths from relevant_files for mtime tracking
        file_paths = [
            f["path"].strip()
            for f in context.relevant_files
            if isinstance(f, dict) and isinstance(f.get("path"), str) and f["path"].strip()
        ]
        file_mtimes = self._get_file_mtimes(file_paths)

        entry = ExplorationCacheEntry(
            context=context,
            cached_at=datetime.now(UTC),
            relevant_file_mtimes=file_mtimes,
            file_count_at_cache=self._get_file_count(),
            objective_hash=cache_key,
            work_type=work_type,
        )

        self._cache[cache_key] = entry
        self._log_cache_event("cache_stored", cache_key, entry=entry)

    def _compute_cache_key(self, objective: str, work_type: str) -> str:
        """Compute cache key from working_dir, objective, and work type.

        Includes working_dir in the hash to prevent cross-project collisions.

        Returns:
            First 16 chars of SHA-256 hash
        """
        content = f"{self._working_dir}:{objective}:{work_type}"
        return hashlib.sha256(content.encode()).hexdigest()[:16]

    def _should_invalidate(self, entry: ExplorationCacheEntry) -> tuple[bool, str]:
        """Check if cache entry should be invalidated.

        Invalidation triggers:
        1. Cache age > max_age_seconds
        2. Any relevant file modified since caching
        3. Any relevant file deleted since caching
        4. File count changed by > max_file_delta

        Returns:
            Tuple of (should_invalidate, reason)
        """
        from obra.exploration.config import get_exploration_config

        exploration_config = get_exploration_config()
        cache_config = exploration_config["cache"]
        max_age_seconds = cache_config["max_age_seconds"]
        max_file_delta = cache_config["max_file_delta"]

        # Check age
        age_seconds = (datetime.now(UTC) - entry.cached_at).total_seconds()
        if age_seconds > max_age_seconds:
            return (
                True,
                f"cache expired (age={age_seconds:.0f}s > max={max_age_seconds}s)",
            )

        # Check relevant file modifications and deletions
        current_mtimes = self._get_file_mtimes(list(entry.relevant_file_mtimes.keys()))
        for path, cached_mtime in entry.relevant_file_mtimes.items():
            current_mtime = current_mtimes.get(path, 0.0)
            if current_mtime > cached_mtime:
                return True, f"file modified: {path}"
            if cached_mtime > 0.0 and current_mtime == 0.0:
                return True, f"file deleted: {path}"

        # Check file count delta
        current_file_count = self._get_file_count()
        file_delta = abs(current_file_count - entry.file_count_at_cache)
        if file_delta > max_file_delta:
            return True, f"file count changed significantly ({file_delta} files)"

        return False, ""

    def _get_file_mtimes(self, paths: list[str]) -> dict[str, float]:
        """Get modification times for a list of file paths.

        Returns:
            Dict mapping paths to their modification times (0.0 if not found)
        """
        mtimes: dict[str, float] = {}
        for path in paths:
            try:
                full_path = self._working_dir / path if not Path(path).is_absolute() else Path(path)
                if full_path.exists():
                    mtimes[path] = full_path.stat().st_mtime
                else:
                    mtimes[path] = 0.0
            except (OSError, PermissionError, TypeError):
                mtimes[path] = 0.0
        return mtimes

    def _get_file_count(self) -> int:
        """Count relevant files for coarse cache invalidation.

        Uses count_project_files from walker with extensions filter.

        Returns:
            Count of relevant files (capped at 500)
        """
        from obra.exploration.walker import count_project_files

        if not self._working_dir or not self._working_dir.exists():
            return 0

        return count_project_files(
            self._working_dir,
            max_count=500,
            extensions=RELEVANT_EXTENSIONS,
        )

    def _log_cache_event(
        self,
        event_type: str,
        cache_key: str,
        reason: str = "",
        entry: ExplorationCacheEntry | None = None,
    ) -> None:
        """Log exploration cache event for observability."""
        if event_type == "cache_hit":
            logger.info(
                "Exploration cache hit: key=%s, age=%.0fs",
                cache_key,
                (datetime.now(UTC) - entry.cached_at).total_seconds() if entry else 0,
            )
            print_info("Using cached exploration results")
        elif event_type == "cache_miss":
            logger.debug("Exploration cache miss: key=%s, reason=%s", cache_key, reason)
        elif event_type == "cache_invalidated":
            logger.info("Exploration cache invalidated: key=%s, reason=%s", cache_key, reason)
        elif event_type == "cache_stored":
            logger.debug(
                "Exploration cached: key=%s, files=%d",
                cache_key,
                len(entry.relevant_file_mtimes) if entry else 0,
            )

        if self._log_event:
            with contextlib.suppress(TypeError):
                self._log_event(
                    f"exploration_{event_type}",
                    cache_key=cache_key,
                    reason=reason if reason else None,
                    file_count=len(entry.relevant_file_mtimes) if entry else None,
                    age_seconds=(
                        (datetime.now(UTC) - entry.cached_at).total_seconds() if entry else None
                    ),
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                )
