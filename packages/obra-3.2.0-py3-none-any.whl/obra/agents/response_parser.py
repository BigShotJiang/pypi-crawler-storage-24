"""Structured response parsing for review agents.

Provides the AgentResponseParser class that handles parsing LLM
structured text responses into AgentIssue lists. Extracted from
BaseAgent to provide a focused single-responsibility module.
"""

import contextlib
import hashlib
import logging
import re
from typing import Any

from obra.agents.types import AgentIssue
from obra.api.protocol import Priority

logger = logging.getLogger(__name__)


class AgentResponseParser:
    """Parses LLM structured text responses into AgentIssue lists."""

    def __init__(self) -> None:
        self._issue_id_seen: dict[str, str] = {}

    def _generate_issue_id(self, prefix: str, index: int) -> str:
        """Generate unique issue ID.

        Args:
            prefix: Agent prefix (e.g., "SEC", "TEST")
            index: Issue index

        Returns:
            Unique issue ID (e.g., "SEC-001")
        """
        return f"{prefix}-{index:03d}"

    def _generate_stable_issue_id(self, prefix: str, issue: dict[str, Any]) -> str:
        """Generate a content-stable issue ID based on issue details.

        Args:
            prefix: Agent prefix (e.g., "SEC", "TEST")
            issue: Issue dict with file/line/description details

        Returns:
            Stable issue ID (e.g., "SEC-a1b2c3d4e5f6")
        """
        file_path = issue.get("file_path") or issue.get("file") or ""
        line_number = issue.get("line_number") or issue.get("line") or ""
        description = issue.get("description") or ""
        description = description.strip().lower()[:100]

        content = f"{file_path}|{line_number}|{description}"
        digest = hashlib.sha256(content.encode("utf-8")).hexdigest()[:12]
        issue_id = f"{prefix}-{digest}"

        existing = self._issue_id_seen.get(issue_id)
        if existing and existing != content:
            suffix = 2
            while f"{issue_id}-{suffix}" in self._issue_id_seen:
                suffix += 1
            issue_id = f"{issue_id}-{suffix}"

        self._issue_id_seen[issue_id] = content
        return issue_id

    # adr-042-skip — extracted from BaseAgent, contracts preserved in docstring
    def parse_structured_response(
        self,
        response: str,
        prefix: str = "ISSUE",
    ) -> list[AgentIssue]:
        """Parse LLM structured text response into AgentIssue list.

        Args:
            response: Raw LLM response text
            prefix: Issue ID prefix for fallback generation (e.g., "SEC", "TEST")

        Returns:
            List of AgentIssue objects. Empty list if response is empty or
            contains no parseable issues.
        """
        if not response or not response.strip():
            return []

        issues: list[AgentIssue] = []
        # Split by delimiter (--- on its own line)
        blocks = response.split("\n---")

        # Severity mapping
        severity_map = {
            "s0": Priority.P0,
            "critical": Priority.P0,
            "s1": Priority.P1,
            "high": Priority.P1,
            "s2": Priority.P2,
            "medium": Priority.P2,
            "s3": Priority.P3,
            "low": Priority.P3,
        }

        for _idx, block in enumerate(blocks):
            block = block.strip()
            if not block:
                continue

            # Parse fields from block
            fields = self._parse_block_fields(block)

            # Skip blocks without minimum required fields
            if not fields.get("issue") and not fields.get("file"):
                continue

            # Map severity string to Priority enum
            severity_str = fields.get("severity", "s2").lower()
            priority = severity_map.get(severity_str, Priority.P2)

            # Parse line number safely
            line_num = None
            if fields.get("line"):
                with contextlib.suppress(ValueError, TypeError):
                    line_num = int(fields["line"])

            # Generate issue ID if not provided
            issue_id = fields.get("issue") or self._generate_stable_issue_id(prefix, fields)

            # Build description from WHY_BUG if available
            description = fields.get("why_bug", "")
            if fields.get("failing_scenario"):
                description += f"\n\nFailing scenario: {fields['failing_scenario']}"

            # Trace parsed fields for debugging
            logger.debug(
                f"Parsed issue: id={issue_id}, file={fields.get('file')}, "
                f"line={line_num}, fields={list(fields.keys())}"
            )

            target_paths_raw = fields.get("target_paths", "")
            target_paths = []
            if target_paths_raw:
                target_paths = [
                    path.strip() for path in re.split(r"[,\n;]+", target_paths_raw) if path.strip()
                ]

            issues.append(
                AgentIssue(
                    id=issue_id,
                    title=fields.get("why_bug", "Issue detected")[:100],
                    description=description,
                    priority=priority,
                    file_path=fields.get("file"),
                    line_number=line_num,
                    dimension=fields.get("dimension", ""),
                    suggestion=fields.get("suggested_fix", ""),
                    issue_type=fields.get("issue_type") or None,
                    target_test_file=fields.get("target_test_file") or None,
                    target_paths=target_paths or None,
                    test_name=fields.get("test_name") or None,
                    arrange=fields.get("arrange") or None,
                    act=fields.get("act") or None,
                    assert_steps=fields.get("assert") or None,
                    issue_kind=fields.get("issue_kind") or "defect",
                    resolution_path=fields.get("resolution_path") or "code_and_tests",
                    verification_scope=fields.get("verification_scope") or "auto",
                    metadata={
                        "confidence": fields.get("confidence", "medium"),
                        "needs_deep_review": fields.get("needs_deep_review", "no").lower() == "yes",
                        "failing_scenario": fields.get("failing_scenario", ""),
                        "issue_type": fields.get("issue_type", ""),
                        "target_test_file": fields.get("target_test_file", ""),
                        "target_paths": target_paths,
                        "test_name": fields.get("test_name", ""),
                        "arrange": fields.get("arrange", ""),
                        "act": fields.get("act", ""),
                        "assert": fields.get("assert", ""),
                        # FIX-RAW-FINDING-001: Preserve full review agent output to avoid
                        # lossy reconstruction in fix prompts. Frontier LLMs benefit from
                        # seeing the complete finding context including code examples.
                        "raw_finding": block.strip(),
                    },
                )
            )

        # Safety net: warn if response contains issue-like markers but nothing parsed.
        # Catches future formatting variants the parser doesn't handle yet.
        if not issues and response:
            marker_pattern = re.compile(r"\b(QUAL|TEST|SEC|PERF|ISSUE)[-_]\d{3}\b", re.IGNORECASE)
            if marker_pattern.search(response):
                logger.warning(
                    f"Response contains issue markers but parser extracted 0 issues "
                    f"(prefix={prefix}). Possible formatting mismatch — "
                    f"first 200 chars: {response[:200]!r}"
                )

        return issues

    def _parse_block_fields(self, block: str) -> dict[str, str]:
        """Parse key-value fields from a structured response block.

        Args:
            block: Single issue block text

        Returns:
            Dictionary of field name to value
        """
        fields: dict[str, str] = {}
        current_field: str | None = None
        current_value: list[str] = []

        # Known field names (case-insensitive)
        known_fields = {
            "issue",
            "issue_type",
            "file",
            "line",
            "severity",
            "confidence",
            "why_bug",
            "failing_scenario",
            "suggested_fix",
            "needs_deep_review",
            "dimension",
            "target_test_file",
            "target_paths",
            "test_name",
            "arrange",
            "act",
            "assert",
            "issue_kind",
            "resolution_path",
            "verification_scope",
        }

        for line in block.split("\n"):
            line = line.strip()
            if not line:
                continue

            # Strip markdown bold formatting for field matching.
            # LLMs sometimes wrap field headers in **bold** (e.g. **ISSUE: QUAL-001**).
            # Use cleaned version for matching/extraction, original for continuation.
            match_line = line
            if line.startswith("*"):
                match_line = line.replace("*", "").strip()

            # Check if line starts a new field
            field_found = False
            for field_name in known_fields:
                # Match "FIELD:" or "FIELD :" patterns (case-insensitive)
                upper_field = field_name.upper()
                if match_line.upper().startswith(
                    f"{upper_field}:"
                ) or match_line.upper().startswith(f"{upper_field} :"):
                    # Save previous field
                    if current_field:
                        fields[current_field] = " ".join(current_value).strip()

                    # Start new field
                    current_field = field_name
                    # Extract value after colon (from cleaned line)
                    colon_idx = match_line.find(":")
                    current_value = [match_line[colon_idx + 1 :].strip()] if colon_idx >= 0 else []
                    field_found = True
                    break

            if not field_found and current_field:
                # Continue multi-line value (preserve original formatting)
                current_value.append(line)

        # Save last field
        if current_field:
            fields[current_field] = " ".join(current_value).strip()

        return fields
