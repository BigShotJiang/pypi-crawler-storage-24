"""Plan item merging, parallel batch orchestration, and rederivation logic extracted from HybridOrchestrator."""

from __future__ import annotations

import hashlib
import json
import logging
from collections.abc import Callable
from typing import Any

from obra.display.observability import ProgressEmitter
from obra.hybrid.parallel_batch_coordinator import (
    ParallelBatchCoordinator,
    ParallelMetrics,
)

logger = logging.getLogger(__name__)

_PERMISSIVE_PLANNING_MODES: frozenset[str] = frozenset(
    {
        "planning_permissive",
        "permissive_planning",
        "permissive",
    }
)


class PlanMerger:
    """Plan item merging, parallel batch orchestration, and rederivation logic.

    Extracted from HybridOrchestrator to isolate plan manipulation
    from session lifecycle management.
    """

    def __init__(
        self,
        *,
        working_dir: str,
        llm_config: dict[str, Any],
        progress_emitter: ProgressEmitter,
        log_event: Callable[..., None],
        trace_id: str,
    ) -> None:
        self._working_dir = working_dir
        self._llm_config = llm_config
        self._progress_emitter = progress_emitter
        self._log_event = log_event
        self._trace_id = trace_id
        self._parallel = ParallelBatchCoordinator(
            working_dir=working_dir,
            llm_config=llm_config,
            progress_emitter=progress_emitter,
            log_event=log_event,
            trace_id=trace_id,
        )
        self.metrics = self._parallel.metrics

    # ------------------------------------------------------------------
    # Pure utility methods (static / class)
    # ------------------------------------------------------------------

    @staticmethod
    def compute_dependency_graph_hash(plan_items: list[dict[str, Any]]) -> str:
        """Compute SHA256 of the dependency graph for C9 validation caching.

        Extracts (item_id, sorted(dependencies)) for all items, sorts by
        item_id, JSON-serializes, and returns hex digest.
        """
        edges: list[tuple[str, list[str]]] = []
        for item in plan_items:
            item_id = item.get("id", "")
            deps = item.get("dependencies") or item.get("depends_on") or []
            if isinstance(deps, str):
                deps = [deps]
            edges.append((item_id, sorted(deps)))
        edges.sort(key=lambda e: e[0])
        return hashlib.sha256(json.dumps(edges).encode()).hexdigest()

    @staticmethod
    def count_plan_item_changes(
        base_plan_items: list[dict[str, Any]],
        revised_plan_items: list[dict[str, Any]],
    ) -> int:
        """Count changed plan items between base and revised snapshots."""
        if not isinstance(base_plan_items, list):
            base_plan_items = []
        if not isinstance(revised_plan_items, list):
            revised_plan_items = []

        base_by_id: dict[str, dict[str, Any]] = {
            str(item.get("id")): item
            for item in base_plan_items
            if isinstance(item, dict) and item.get("id")
        }
        revised_by_id: dict[str, dict[str, Any]] = {
            str(item.get("id")): item
            for item in revised_plan_items
            if isinstance(item, dict) and item.get("id")
        }

        changed = 0
        for item_id, revised_item in revised_by_id.items():
            base_item = base_by_id.get(item_id)
            if base_item is None or revised_item != base_item:
                changed += 1

        removed_ids = set(base_by_id.keys()) - set(revised_by_id.keys())
        return changed + len(removed_ids)

    @staticmethod
    def merge_revision_batch(
        base_items: list[dict[str, Any]],
        revised_items: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Merge revised batch items into a full plan snapshot by ID."""
        if not base_items:
            return list(revised_items)

        revised_map = {
            item.get("id"): item
            for item in revised_items
            if isinstance(item, dict) and item.get("id")
        }
        base_ids = {
            item.get("id") for item in base_items if isinstance(item, dict) and item.get("id")
        }

        merged: list[dict[str, Any]] = []
        for item in base_items:
            if not isinstance(item, dict):
                continue
            item_id = item.get("id")
            if item_id in revised_map:
                revised_item = revised_map[item_id]
                # Preserve userplan_step_index from base item if revised item lacks it
                base_context = item.get("context")
                if isinstance(base_context, dict):
                    base_step_idx = base_context.get("userplan_step_index")
                    if base_step_idx is not None:
                        revised_context = revised_item.get("context")
                        if isinstance(revised_context, dict):
                            if revised_context.get("userplan_step_index") is None:
                                revised_context["userplan_step_index"] = base_step_idx
                        elif revised_context is None:
                            revised_item["context"] = {"userplan_step_index": base_step_idx}
                merged.append(revised_item)
            else:
                merged.append(item)

        for item in revised_items:
            if not isinstance(item, dict):
                continue
            item_id = item.get("id")
            if item_id and item_id not in base_ids:
                merged.append(item)

        return merged

    @staticmethod
    def issue_dedupe_key(issue: dict[str, Any]) -> str | None:
        """Build a stable composite key for issue deduplication.

        Replicates the server's ``_issue_dedupe_key()`` in
        ``functions/src/orchestration/coordinator.py`` to ensure consistent
        dedup behavior across client and server.
        """
        issue_id = str(issue.get("id", "")).strip()
        if not issue_id:
            return None

        category = str(issue.get("category", "")).strip().lower()
        issue_type = str(issue.get("type") or issue.get("issue_type") or "").strip().lower()

        # Extract priority: prefer explicit priority field, fall back to severity mapping.
        priority_raw = str(issue.get("priority", "")).upper()
        _valid = {"P0", "P1", "P2", "P3"}
        if priority_raw not in _valid:
            _sev_map = {
                "critical": "P0",
                "high": "P1",
                "medium": "P2",
                "low": "P3",
                "p0": "P0",
                "p1": "P1",
                "p2": "P2",
                "p3": "P3",
            }
            severity = str(issue.get("severity", "")).lower()
            priority_raw = _sev_map.get(severity, "P2")
        priority = priority_raw

        description = " ".join(str(issue.get("description", "")).strip().lower().split())

        affected_items = issue.get("affected_items", [])
        if not isinstance(affected_items, list):
            affected_items = [affected_items] if affected_items else []
        affected_key = "|".join(
            sorted(str(item).strip() for item in affected_items if str(item).strip())
        )

        return (
            f"id:{issue_id}|priority:{priority}|category:{category}|type:{issue_type}|"
            f"affected:{affected_key}|description:{description}"
        )

    @staticmethod
    def extract_issue_priority(issue: dict[str, Any]) -> str:
        """Extract canonical priority (P0-P3) from issue priority/severity fields."""
        valid = {"P0", "P1", "P2", "P3"}
        priority_raw = str(issue.get("priority", "")).upper()
        if priority_raw in valid:
            return priority_raw

        severity_map = {
            "critical": "P0",
            "p0": "P0",
            "high": "P1",
            "p1": "P1",
            "medium": "P2",
            "p2": "P2",
            "important": "P2",
            "low": "P3",
            "p3": "P3",
            "minor": "P3",
        }
        severity = str(issue.get("severity", "")).lower()
        return severity_map.get(severity, "P2")

    @classmethod
    def count_effective_blocking_issues(
        cls,
        issues: list[Any],
        bypass_modes_active: list[str] | None,
    ) -> int:
        """Count blocking issues using coordinator-equivalent bypass semantics."""
        active_modes = set(bypass_modes_active or [])
        if "skip_refinement_once" in active_modes:
            return 0

        permissive_planning = any(mode in _PERMISSIVE_PLANNING_MODES for mode in active_modes)
        blocking_count = 0
        for issue in issues:
            if not isinstance(issue, dict):
                continue
            priority = cls.extract_issue_priority(issue)
            if priority == "P0" or (priority == "P1" and not permissive_planning):
                blocking_count += 1
        return blocking_count

    @staticmethod
    def extract_step_index(item: dict[str, Any]) -> int | None:
        """Extract UserPlan step index from item context or source_step_id."""
        context = item.get("context")
        if isinstance(context, dict):
            step_index = context.get("userplan_step_index")
            if isinstance(step_index, int):
                return step_index
            if isinstance(step_index, str) and step_index.strip().isdigit():
                return int(step_index.strip())
        source_step_id = item.get("source_step_id")
        if isinstance(source_step_id, str) and ":S" in source_step_id:
            try:
                return int(source_step_id.split(":S")[-1])
            except ValueError:
                return None
        return None

    @staticmethod
    def recompute_parent_statuses(
        items: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Recompute parent statuses from descendant completion."""
        item_map = {item.get("id"): item for item in items if item.get("id")}
        children_by_parent: dict[str, list[dict[str, Any]]] = {}
        for item in items:
            parent_id = item.get("parent_id")
            if parent_id and parent_id in item_map:
                children_by_parent.setdefault(parent_id, []).append(item)

        def rollup_status(child_items: list[dict[str, Any]]) -> str:
            if not child_items:
                return "pending"
            statuses = [child.get("status", "pending") for child in child_items]
            if any(status == "blocked" for status in statuses):
                return "blocked"
            if any(status == "in_progress" for status in statuses):
                return "in_progress"
            if all(status == "completed" for status in statuses):
                return "completed"
            return "pending"

        # Update parents bottom-up by depth (deepest first if available)
        items_sorted = sorted(
            items,
            key=lambda item: int(item.get("depth", 0)) if item.get("depth") is not None else 0,
            reverse=True,
        )
        for item in items_sorted:
            item_id = item.get("id")
            if not item_id:
                continue
            children = children_by_parent.get(item_id)
            if not children:
                continue
            new_status = rollup_status(children)
            item["status"] = new_status

        return items

    # ------------------------------------------------------------------
    # Rederivation merging (uses internal statics)
    # ------------------------------------------------------------------

    def filter_preserved_items_for_rederivation(
        self,
        preserved_items: list[dict[str, Any]],
        *,
        from_step: int,
    ) -> list[dict[str, Any]]:
        """Drop affected subtrees for items derived from steps >= from_step."""
        item_map = {item.get("id"): item for item in preserved_items if item.get("id")}
        children_by_parent: dict[str, list[str]] = {}
        for item in preserved_items:
            parent_id = item.get("parent_id")
            item_id = item.get("id")
            if parent_id and item_id:
                children_by_parent.setdefault(parent_id, []).append(item_id)

        affected_ids: set[str] = set()
        for item_id, item in item_map.items():
            step_index = PlanMerger.extract_step_index(item)
            if step_index is not None and step_index >= from_step and item_id is not None:
                affected_ids.add(item_id)

        stack = list(affected_ids)
        while stack:
            current_id = stack.pop()
            for child_id in children_by_parent.get(current_id, []):
                if child_id not in affected_ids:
                    affected_ids.add(child_id)
                    stack.append(child_id)

        return [item for item in preserved_items if item.get("id") not in affected_ids]

    def mark_rederived_parents_stale(
        self,
        preserved_items: list[dict[str, Any]],
        *,
        from_step: int,
    ) -> list[dict[str, Any]]:
        """Mark parents as stale when any descendant is re-derived."""
        item_map = {item.get("id"): item for item in preserved_items if item.get("id")}
        affected_ids = {
            item_id
            for item_id, item in item_map.items()
            if (step_index := PlanMerger.extract_step_index(item)) is not None
            and step_index >= from_step
        }
        if not affected_ids:
            return preserved_items

        ancestors_to_mark: set[str] = set()
        for item_id in affected_ids:
            current = item_map.get(item_id)
            while current and current.get("parent_id"):
                parent_id = current.get("parent_id")
                if not parent_id:
                    break
                if parent_id not in affected_ids:
                    ancestors_to_mark.add(parent_id)
                current = item_map.get(parent_id)

        for item in preserved_items:
            if item.get("id") in ancestors_to_mark:
                item["is_stale"] = True
                item["stale_reason"] = "Child items re-derived"

        return preserved_items

    def merge_plan_items_for_rederivation(
        self,
        preserved_items: list[dict[str, Any]],
        newly_derived_items: list[dict[str, Any]],
        from_step: int | None,
    ) -> list[dict[str, Any]]:
        """Merge preserved plan items with newly derived items for --from-step re-derivation.

        When using --from-step N, this method combines:
        - Preserved items for steps 1 to N-1 (unchanged from previous derivation)
        - Newly derived items for steps N onwards (re-derived in current run)

        The preserved items retain their original IDs and content, while newly derived
        items are appended after them to form a complete plan.

        For hierarchical plans, preserved items are filtered to drop only the
        affected subtrees (items derived from source steps >= from_step). Completed
        leaves outside the affected subtree remain intact, along with their parent
        linkage.

        Args:
            preserved_items: Plan items to preserve from previous derivation
                (steps 1 to from_step-1). These items should have userplan_step_index
                in their context to indicate which step they belong to.
            newly_derived_items: Plan items newly derived in this run
                (steps from_step onwards).
            from_step: Step number to re-derive from (1-indexed). If None,
                all items are considered newly derived (no merge needed).

        Returns:
            Merged list of plan items:
            - If from_step is None or 1: returns newly_derived_items unchanged
            - If from_step > 1: returns preserved_items + newly_derived_items
              sorted by userplan_step_index to maintain correct ordering

        Example:
            # Re-derive from step 3:
            # preserved_items = [items for steps 1, 2]
            # newly_derived_items = [items for steps 3, 4, 5]
            # result = [step1_items, step2_items, step3_items, step4_items, step5_items]
        """
        # No merge needed if from_step is None or 1 (full derivation)
        if from_step is None or from_step <= 1:
            return newly_derived_items

        # No preserved items means this is effectively a full derivation
        if not preserved_items:
            logger.info(
                f"No preserved items for --from-step {from_step}, "
                f"returning {len(newly_derived_items)} newly derived items"
            )
            return newly_derived_items

        preserved_items = self.mark_rederived_parents_stale(
            preserved_items,
            from_step=from_step,
        )
        preserved_items = self.filter_preserved_items_for_rederivation(
            preserved_items,
            from_step=from_step,
        )

        # Merge preserved items with newly derived items (preserved first)
        merged_items = list(preserved_items) + list(newly_derived_items)
        merged_items = PlanMerger.recompute_parent_statuses(merged_items)

        logger.info(
            f"Merged plan items for --from-step {from_step}: "
            f"{len(preserved_items)} preserved + {len(newly_derived_items)} newly derived = "
            f"{len(merged_items)} total items"
        )

        return merged_items

    # ------------------------------------------------------------------
    # Parallel batch orchestration (examine + revise)
    # ------------------------------------------------------------------

    def resolve_parallel_cycle(
        self,
        cycle_raw: Any,
        refinement_cycle_count: int,
    ) -> int:
        """Normalize refinement cycle values for telemetry joins."""
        return self._parallel.resolve_parallel_cycle(
            cycle_raw,
            refinement_cycle_count,
        )
