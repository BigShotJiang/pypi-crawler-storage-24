"""Project-context helpers for HybridOrchestrator."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from obra.hybrid.tooling_discovery import ToolingDiscovery
from obra.schemas.userplan_schema import DerivedPlanItem
from obra.simulation_controls import get_escalation_fixer_control


class ProjectContextBuilder:
    """Build minimal project context and imported-plan artifact references."""

    def __init__(
        self,
        *,
        working_dir: Path,
        llm_config: dict[str, Any] | None,
        imported_plan_context: dict[str, Any] | None,
    ) -> None:
        self._working_dir = working_dir
        self._llm_config = llm_config or {}
        self._imported_plan_context = imported_plan_context
        self._derived_plan_api_keys_cache: set[str] | None = None

    def update_runtime(
        self,
        *,
        llm_config: dict[str, Any] | None,
        imported_plan_context: dict[str, Any] | None,
    ) -> None:
        """Refresh runtime dependencies before a build."""
        self._llm_config = llm_config or {}
        self._imported_plan_context = imported_plan_context

    def build(self) -> dict[str, Any]:
        """Gather minimal project context without code content."""
        context: dict[str, Any] = {
            "languages": [],
            "frameworks": [],
            "has_tests": False,
            "file_count": 0,
            "working_directory": str(self._working_dir),
        }

        tooling_context: dict[str, Any] = {}
        try:
            from obra.config.loaders import (
                get_verification_discovery_enabled,
                get_verification_force_refresh,
            )

            if get_verification_discovery_enabled():
                discovery = ToolingDiscovery(self._working_dir, self._llm_config)
                tooling_context = discovery.discover(force_refresh=get_verification_force_refresh())
        except Exception:
            tooling_context = {}

        if tooling_context:
            languages = tooling_context.get("languages", {})
            if isinstance(languages, dict):
                primary = languages.get("primary")
                secondary = languages.get("secondary", [])
                detected: list[str] = []
                if primary:
                    detected.append(primary)
                if isinstance(secondary, list):
                    detected.extend(str(lang) for lang in secondary if lang)
                context["languages"] = list({lang for lang in detected if lang})

            verification = tooling_context.get("verification", {})
            if isinstance(verification, dict):
                test_cfg = verification.get("test", {})
                if isinstance(test_cfg, dict) and test_cfg.get("command"):
                    context["has_tests"] = True

        extensions: set[str] = set()
        file_count = 0
        try:
            for path in self._working_dir.rglob("*"):
                if path.is_file() and not any(part.startswith(".") for part in path.parts):
                    file_count += 1
                    if path.suffix:
                        extensions.add(path.suffix.lower())
        except Exception:
            pass

        context["file_count"] = file_count

        if not context["languages"]:
            context["languages"] = ToolingDiscovery.detect_languages_by_extension(extensions)

        if not context["has_tests"]:
            test_dirs = ["tests", "test", "__tests__", "spec"]
            context["has_tests"] = any((self._working_dir / d).is_dir() for d in test_dirs)

        context["frameworks"] = ToolingDiscovery(
            self._working_dir, self._llm_config
        ).detect_frameworks()

        config_context: dict[str, Any] = {}
        try:
            from obra.config.loaders import load_layered_config

            config, _, _ = load_layered_config()
            sense_check_pipeline = (
                config.get("review", {}).get("sense_check", {}).get("pipeline", {})
            )
            if sense_check_pipeline:
                config_context.setdefault("review", {})["sense_check"] = {
                    "pipeline": sense_check_pipeline,
                }

            pipeline_config = config.get("pipeline", {})
            if isinstance(pipeline_config, dict) and pipeline_config:
                config_context["pipeline"] = pipeline_config

            if config_context:
                context["config"] = config_context
        except Exception:
            pass

        workflow_artifact_refs = self.build_imported_plan_workflow_artifact_refs()
        if workflow_artifact_refs:
            existing_workflow_refs = context.get("workflow_artifact_refs")
            if isinstance(existing_workflow_refs, list):
                self._append_unique_refs(existing_workflow_refs, workflow_artifact_refs)
            else:
                context["workflow_artifact_refs"] = workflow_artifact_refs

        execution_input_refs = self.build_imported_plan_execution_input_refs()
        execution_input_refs.extend(
            self.build_pipeline_config_execution_input_refs(
                config_context.get("pipeline")
                if isinstance(config_context.get("pipeline"), dict)
                else None
            )
        )
        if execution_input_refs:
            existing_refs = context.get("execution_input_artifact_refs")
            if isinstance(existing_refs, list):
                self._append_unique_refs(existing_refs, execution_input_refs)
            else:
                context["execution_input_artifact_refs"] = execution_input_refs

        try:
            simulation_escalation_fixer = get_escalation_fixer_control()
            if simulation_escalation_fixer:
                context.setdefault("simulation", {})["escalation_fixer"] = dict(
                    simulation_escalation_fixer
                )
                review_cfg = context.setdefault("config", {}).setdefault("review", {})
                fixer_cfg = review_cfg.setdefault("escalation_fixer", {})
                fixer_cfg["enabled"] = True
                if simulation_escalation_fixer.get("timeout_s") is not None:
                    fixer_cfg["timeout_s"] = int(simulation_escalation_fixer["timeout_s"])
                if simulation_escalation_fixer.get("allowed_routes"):
                    fixer_cfg["allowed_routes"] = list(
                        simulation_escalation_fixer["allowed_routes"]
                    )
                if simulation_escalation_fixer.get("eligible_reason_codes"):
                    fixer_cfg["eligible_reason_codes"] = list(
                        simulation_escalation_fixer["eligible_reason_codes"]
                    )
        except Exception:
            pass

        return context

    def build_imported_plan_workflow_artifact_refs(self) -> list[dict[str, Any]]:
        """Translate imported-plan workflow identity into canonical workflow refs."""
        plan_context = (
            self._imported_plan_context if isinstance(self._imported_plan_context, dict) else {}
        )
        if not plan_context:
            return []

        workflow_source_artifact = (
            plan_context.get("workflow_source_artifact")
            if isinstance(plan_context.get("workflow_source_artifact"), dict)
            else {}
        )
        workflow_id = str(
            plan_context.get("workflow_id")
            or workflow_source_artifact.get("artifact_id")
            or plan_context.get("workflow_artifact_id")
            or ""
        ).strip()
        if not workflow_id:
            return []

        revision_id = (
            str(
                plan_context.get("revision_id")
                or workflow_source_artifact.get("version")
                or "current"
            ).strip()
            or "current"
        )
        domain_id = str(
            plan_context.get("domain_id") or workflow_source_artifact.get("domain_id") or ""
        ).strip()
        metadata: dict[str, Any] = {
            "source": "imported_plan",
            "workflow_id": workflow_id,
            "revision_id": revision_id,
        }
        if domain_id:
            metadata["domain_id"] = domain_id

        return [
            {
                "target_artifact_type": "workflow_baseline",
                "target_artifact_id": workflow_id,
                "target_version_selector": revision_id,
                "relationship_type": "executed_for",
                "metadata": metadata,
            }
        ]

    def build_imported_plan_execution_input_refs(self) -> list[dict[str, Any]]:
        """Translate imported-plan execution input metadata into canonical refs."""
        plan_context = (
            self._imported_plan_context if isinstance(self._imported_plan_context, dict) else {}
        )
        if not plan_context:
            return []

        artifacts = (
            plan_context.get("artifacts") if isinstance(plan_context.get("artifacts"), dict) else {}
        )
        raw_input_path = artifacts.get("execution_input")
        raw_input_id = plan_context.get("execution_input_id")
        if not raw_input_path and not raw_input_id:
            return []

        normalized_path: str | None = None
        if isinstance(raw_input_path, str) and raw_input_path.strip():
            candidate = Path(raw_input_path).expanduser()
            plan_source_path = plan_context.get("_obra_plan_source_path")
            if (
                not candidate.is_absolute()
                and isinstance(plan_source_path, str)
                and plan_source_path
            ):
                candidate = Path(plan_source_path).expanduser().resolve().parent / candidate
            if candidate.is_absolute():
                try:
                    normalized_path = str(
                        candidate.resolve().relative_to(self._working_dir.resolve())
                    )
                except ValueError:
                    normalized_path = str(candidate.resolve())
            else:
                normalized_path = str(candidate)

        artifact_id = str(raw_input_id or normalized_path or raw_input_path or "").strip()
        if not artifact_id:
            return []

        metadata: dict[str, Any] = {"source": "imported_plan"}
        workflow_artifact_id = plan_context.get("workflow_artifact_id")
        if workflow_artifact_id:
            metadata["workflow_artifact_id"] = str(workflow_artifact_id)
        workflow_source_artifact = (
            plan_context.get("workflow_source_artifact")
            if isinstance(plan_context.get("workflow_source_artifact"), dict)
            else {}
        )
        workflow_id = str(
            plan_context.get("workflow_id") or workflow_source_artifact.get("artifact_id") or ""
        ).strip()
        revision_id = str(
            plan_context.get("revision_id") or workflow_source_artifact.get("version") or ""
        ).strip()
        domain_id = str(
            plan_context.get("domain_id") or workflow_source_artifact.get("domain_id") or ""
        ).strip()
        if workflow_id:
            metadata["workflow_id"] = workflow_id
        if revision_id:
            metadata["revision_id"] = revision_id
        if domain_id:
            metadata["domain_id"] = domain_id
        if normalized_path:
            metadata["path"] = normalized_path

        return [
            {
                "target_artifact_type": "execution_input",
                "target_artifact_id": artifact_id,
                "target_version_selector": "current",
                "relationship_type": "consumes",
                "metadata": metadata,
            }
        ]

    def build_pipeline_config_execution_input_refs(
        self,
        pipeline_config: dict[str, Any] | None,
    ) -> list[dict[str, Any]]:
        """Infer execution-input refs from active pipeline runner configuration."""
        if not isinstance(pipeline_config, dict):
            return []

        refs: list[dict[str, Any]] = []
        seen_paths: set[str] = set()
        for stage in pipeline_config.get("custom_stages") or []:
            if not isinstance(stage, dict):
                continue
            runner_config = (
                stage.get("runner_config") if isinstance(stage.get("runner_config"), dict) else {}
            )
            raw_input_path = runner_config.get("input_path")
            if not isinstance(raw_input_path, str) or not raw_input_path.strip():
                continue
            input_path = raw_input_path.strip()
            if input_path in seen_paths:
                continue
            seen_paths.add(input_path)
            artifact_stem = Path(input_path).stem
            refs.append(
                {
                    "target_artifact_type": "execution_input",
                    "target_artifact_id": f"execution_input.{artifact_stem}",
                    "target_version_selector": "current",
                    "relationship_type": "consumes",
                    "metadata": {
                        "source": "pipeline_config",
                        "path": input_path,
                        "stage_name": str(stage.get("name") or ""),
                    },
                }
            )
        return refs

    def get_derived_plan_api_keys(self) -> set[str]:
        """Return allowed DerivedPlan item keys based on schema."""
        if self._derived_plan_api_keys_cache is None:
            self._derived_plan_api_keys_cache = set(DerivedPlanItem.model_fields.keys())
        return self._derived_plan_api_keys_cache

    @staticmethod
    def _append_unique_refs(
        existing_refs: list[dict[str, Any]],
        new_refs: list[dict[str, Any]],
    ) -> None:
        seen = {
            (
                str(item.get("target_artifact_type")),
                str(item.get("target_artifact_id")),
                str(item.get("target_version_selector")),
                str(item.get("relationship_type")),
            )
            for item in existing_refs
            if isinstance(item, dict)
        }
        for ref in new_refs:
            ref_key = (
                str(ref.get("target_artifact_type")),
                str(ref.get("target_artifact_id")),
                str(ref.get("target_version_selector")),
                str(ref.get("relationship_type")),
            )
            if ref_key not in seen:
                existing_refs.append(ref)
                seen.add(ref_key)
