"""Session-flow runtime owners extracted from HybridOrchestrator."""

from __future__ import annotations

import logging
from collections.abc import Callable
from typing import Any

from obra.api.protocol import (
    ActionType,
    CompletionNotice,
    EscalationNotice,
    ServerAction,
)
from obra.exceptions import APIError, OrchestratorError
from obra.messages import get_message

logger = logging.getLogger(__name__)


class HybridSessionFlowRuntime:
    """Own collaborator refresh, action entry, and result reporting flow."""

    def __init__(
        self,
        *,
        build_handler_factory: Callable[[], Any],
        get_handler_factory: Callable[[], Any | None],
        set_handler_factory: Callable[[Any], None],
        build_dispatcher: Callable[[], Any],
        get_dispatcher: Callable[[], Any | None],
        set_dispatcher: Callable[[Any], None],
        get_handler: Callable[[ActionType, dict[str, Any] | None], Any],
        emit_phase_event: Callable[[ActionType, dict[str, Any] | None], None],
        handle_escalation: Callable[[EscalationNotice], dict[str, Any]],
        display_bypass_notices: Callable[[ServerAction], None],
        build_error_context: Callable[..., Any],
        runtime_state: Any,
        server_protocol: Any,
        watchdog: Any,
        fix_result_history: list[dict[str, Any]],
        ordered_supported_review_agents: Callable[[], list[str]],
        session_id_getter: Callable[[], str | None],
        current_phase_getter: Callable[[], Any | None],
        phase_span_id_getter: Callable[[], str | None],
        pipeline_span_id_getter: Callable[[], str | None],
        subphase_span_id_getter: Callable[[], str | None],
    ) -> None:
        self._build_handler_factory = build_handler_factory
        self._get_handler_factory = get_handler_factory
        self._set_handler_factory = set_handler_factory
        self._build_dispatcher = build_dispatcher
        self._get_dispatcher = get_dispatcher
        self._set_dispatcher = set_dispatcher
        self._get_handler = get_handler
        self._emit_phase_event = emit_phase_event
        self._handle_escalation = handle_escalation
        self._display_bypass_notices = display_bypass_notices
        self._build_error_context = build_error_context
        self._runtime_state = runtime_state
        self._server_protocol = server_protocol
        self._watchdog = watchdog
        self._fix_result_history = fix_result_history
        self._ordered_supported_review_agents = ordered_supported_review_agents
        self._session_id_getter = session_id_getter
        self._current_phase_getter = current_phase_getter
        self._phase_span_id_getter = phase_span_id_getter
        self._pipeline_span_id_getter = pipeline_span_id_getter
        self._subphase_span_id_getter = subphase_span_id_getter

    def prepare_collaborators(self, *, force_rebuild: bool = False) -> None:
        """Refresh runtime collaborators when session-scoped state changes."""
        if force_rebuild or self._get_handler_factory() is None:
            self._set_handler_factory(self._build_handler_factory())

        if force_rebuild or self._get_dispatcher() is None:
            self._set_dispatcher(self._build_dispatcher())

    def _sync_dispatcher_observability(self) -> Any:
        self.prepare_collaborators()
        dispatcher = self._get_dispatcher()
        if dispatcher is None:
            raise RuntimeError("Dispatcher not available after collaborator preparation")
        dispatcher._obs.phase_span_id = self._phase_span_id_getter()
        dispatcher._obs.pipeline_span_id = self._pipeline_span_id_getter()
        dispatcher._obs.session_id = self._session_id_getter()
        return dispatcher

    def dispatch_handler(
        self,
        handler: Any,
        action: ActionType,
        payload: dict[str, Any],
        server_action: ServerAction | None = None,
    ) -> dict[str, Any]:
        """Dispatch request through the prepared action dispatcher."""
        dispatcher = self._sync_dispatcher_observability()
        return dispatcher.dispatch(handler, action, payload, server_action)

    def process_proposed_defaults(
        self,
        proposed_defaults: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Delegate defaults confirmation to the refinement coordinator owner."""
        dispatcher = self._sync_dispatcher_observability()
        return dispatcher._refinement_coord._process_proposed_defaults(proposed_defaults)

    def resolve_item_terminal_outcome(
        self,
        current_item: dict[str, Any],
        handler_result: dict[str, Any],
        item_error: Exception | None,
    ) -> Any:
        """Delegate execute terminal-outcome resolution to the execution coordinator owner."""
        dispatcher = self._sync_dispatcher_observability()
        return dispatcher._execution._resolve_item_terminal_outcome(
            current_item,
            handler_result,
            item_error,
        )

    def handle_action(self, server_action: ServerAction) -> dict[str, Any]:
        """Handle a server action through the extracted session-flow owner."""
        action = server_action.action
        payload = server_action.payload
        self._watchdog.last_action_payload = payload

        logger.info("Handling action: %s (iteration %s)", action.value, server_action.iteration)
        self._emit_phase_event(action, payload)

        if action == ActionType.COMPLETE:
            completion_notice = CompletionNotice.from_payload(payload)
            return {"completed": True, "notice": completion_notice}

        if action == ActionType.ESCALATE:
            escalation_notice = EscalationNotice.from_payload(
                payload,
                metadata=(
                    server_action.metadata if isinstance(server_action.metadata, dict) else {}
                ),
            )
            return self._handle_escalation(escalation_notice)

        if action == ActionType.ERROR:
            error_msg = server_action.error_message or "Unknown server error"
            error_code = server_action.error_code or "UNKNOWN"
            msg = f"Server error [{error_code}]: {error_msg}"
            session_id = self._session_id_getter()
            if session_id:
                short_id = session_id.split("-")[0]
                msg += f"\n\nTry: {get_message('recovery.session.repair', short_id=short_id)}"
            raise OrchestratorError(
                msg,
                session_id=session_id or "",
                error_context=self._build_error_context(action="poll_session"),
            )

        if action == ActionType.WAIT:
            return {"waiting": True}

        handler = self._get_handler(action, payload)
        self._watchdog.handler_active = True
        try:
            return self.dispatch_handler(handler, action, payload, server_action)
        finally:
            self._watchdog.handler_active = False

    def report_result(
        self,
        action: ActionType,
        result: dict[str, Any],
    ) -> ServerAction:
        """Report an action result through the extracted reporting owner."""
        session_id = self._session_id_getter()
        if not session_id:
            raise OrchestratorError(
                "No active session",
                error_context=self._build_error_context(action="report_result"),
            )

        supported_actions = {
            ActionType.DERIVE,
            ActionType.INTENT,
            ActionType.STORY0,
            ActionType.STORY_PREFLIGHT,
            ActionType.EXAMINE,
            ActionType.REVISE,
            ActionType.EXECUTE,
            ActionType.REVIEW,
            ActionType.FIX,
            ActionType.ESCALATE,
            ActionType.VALIDATOR,
            ActionType.PIPELINE_STAGE,
        }
        if action not in supported_actions:
            msg = f"Cannot report result for action: {action.value}"
            raise OrchestratorError(
                msg,
                session_id=session_id,
                error_context=self._build_error_context(action="report_result"),
            )

        try:
            ctx = self._runtime_state.build_report_context(
                last_action_payload=self._watchdog.last_action_payload,
                fix_result_history=self._fix_result_history,
                supported_review_agents=set(self._ordered_supported_review_agents()),
            )
            server_action = self._server_protocol.report_result(
                action,
                result,
                context=ctx,
                current_phase=(
                    self._current_phase_getter().value if self._current_phase_getter() else None
                ),
                phase_span_id=self._phase_span_id_getter(),
                subphase_span_id=self._subphase_span_id_getter(),
            )
            self._display_bypass_notices(server_action)
            return server_action
        except APIError:
            raise
        except Exception as exc:
            msg = f"Failed to report result: {exc}"
            raise OrchestratorError(
                msg,
                session_id=session_id,
                error_context=self._build_error_context(action="report_result"),
            ) from exc
