"""Progress routing and plan snapshot helpers for ServerProtocol."""

from __future__ import annotations

import json
import logging
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from obra.hybrid.server_protocol import ServerProtocol

logger = logging.getLogger(__name__)

PLAN_SNAPSHOT_DIRNAME = "plan_snapshots"


def _should_skip_item_event(
    protocol: "ServerProtocol",
    event_type: str,
    payload: dict[str, Any],
) -> bool:
    """Return True when an item lifecycle event is a local duplicate."""
    if event_type == "item_completed":
        item = payload.get("item", {})
        item_id = item.get("id") if isinstance(item, dict) else None
        return bool(item_id and str(item_id) in protocol._locally_completed_items)

    if event_type != "item_started":
        return False

    exec_ctx = payload.get("execution_context")
    if not isinstance(exec_ctx, dict):
        return False

    ctx_key = (
        f"{exec_ctx.get('item_id')}:{exec_ctx.get('iteration')}:"
        f"{exec_ctx.get('attempt')}"
    )
    if ctx_key in protocol._locally_started_items:
        logger.debug("Skipping duplicate server item_started: %s", ctx_key)
        return True
    protocol._locally_started_items.add(ctx_key)
    return False


def _should_skip_phase_event(
    protocol: "ServerProtocol",
    event_type: str,
    payload: dict[str, Any],
    current_phase: str | None,
) -> bool:
    """Return True when a phase event is a local duplicate or echo."""
    phase_raw = payload.get("phase")
    phase = str(phase_raw).strip().lower() if phase_raw else ""

    if event_type == "phase_completed":
        duration_ms_raw = payload.get("duration_ms")
        try:
            duration_ms = int(duration_ms_raw) if duration_ms_raw is not None else 0
        except (TypeError, ValueError):
            duration_ms = 0

        if phase and phase in protocol._locally_completed_phases:
            logger.debug("Skipping duplicate phase_completed: %s", phase)
            return True
        if phase and current_phase is not None and phase == current_phase and duration_ms <= 0:
            logger.debug(
                "Skipping non-authoritative phase_completed echo: %s (duration_ms=%s)",
                phase,
                duration_ms_raw,
            )
            return True
        return False

    if event_type != "phase_started":
        return False

    if phase and phase in protocol._locally_started_phases:
        logger.debug("Skipping duplicate phase_started: %s", phase)
        return True
    if phase:
        protocol._locally_started_phases.add(phase)
    return False


def _process_scorecard_event(
    protocol: "ServerProtocol",
    payload: dict[str, Any],
    subphase_span_id: str | None,
    phase_span_id: str | None,
) -> None:
    """Emit normalized scorecard telemetry for server-pushed review results."""
    try:
        status_value = str(payload.get("status", "")).strip().lower()
        accepted = status_value == "accepted"
        passed = payload.get("passed")
        if not isinstance(passed, bool):
            passed = status_value in {"passing", "pass", "accepted"}
        elif accepted and not passed:
            passed = True

        score_source = payload.get("scorecard_source") or (
            "server_post_filter" if payload.get("review_filter_applied") else "server_direct"
        )
        protocol._log_session_event(
            "review_score_finalized",
            stage="quality_gate",
            score=payload.get("total"),
            decision_score=payload.get("total"),
            compiled_score=payload.get("compiled_score"),
            pre_filter_score=payload.get("raw_score"),
            threshold=payload.get("threshold"),
            threshold_purpose="quality_gate",
            status=payload.get("status"),
            passed=passed,
            accepted=accepted,
            item_id=payload.get("item_id"),
            review_cycle_id=payload.get("review_cycle_id"),
            raw_score=payload.get("raw_score"),
            adjustment_delta=payload.get("adjustment_delta"),
            scorecard_source=payload.get("scorecard_source"),
            score_source=score_source,
            review_filter_applied=payload.get("review_filter_applied"),
            filtered_issue_count=payload.get("filtered_issue_count"),
            failed_agents=payload.get("failed_agents"),
            skipped_agents=payload.get("skipped_agents"),
            total_agents=payload.get("total_agents"),
            degraded=payload.get("degraded"),
            all_skipped=payload.get("all_skipped"),
            decision_state=payload.get("decision_state"),
            decision_reason=payload.get("decision_reason"),
            policy_source=payload.get("policy_source"),
            span_id=subphase_span_id,
            parent_span_id=phase_span_id,
        )
    except Exception:
        logger.debug("Failed to log review_score_finalized", exc_info=True)


def _log_escalation_event(
    protocol: "ServerProtocol",
    event_type: str,
    payload: dict[str, Any],
) -> None:
    """Forward escalation telemetry into the session logger."""
    try:
        protocol._log_session_event(
            event_type,
            **{k: v for k, v in payload.items() if k != "session_id"},
        )
    except Exception:
        logger.debug(
            "Failed to log server-pushed %s to session logger",
            event_type,
            exc_info=True,
        )


def _log_lifecycle_event(
    protocol: "ServerProtocol",
    event_type: str,
    payload: dict[str, Any],
) -> None:
    """Forward item lifecycle telemetry into the session logger."""
    try:
        lifecycle_payload = {k: v for k, v in payload.items() if k != "session_id"}
        event_item = lifecycle_payload.get("item")
        if isinstance(event_item, dict):
            lifecycle_payload.setdefault(
                "item_id",
                event_item.get("id") or event_item.get("item_id"),
            )
        event_result = lifecycle_payload.get("result")
        if event_type == "item_completed" and isinstance(event_result, dict):
            lifecycle_payload.setdefault("status", event_result.get("status"))
            lifecycle_payload.setdefault(
                "terminal_reason",
                event_result.get("failure_class") or event_result.get("status"),
            )
        protocol._log_session_event(event_type, **lifecycle_payload)
    except Exception:
        logger.debug(
            "Failed to log server-pushed %s to session logger",
            event_type,
            exc_info=True,
        )


def _record_processed_event_id(protocol: "ServerProtocol", event_data: dict[str, Any]) -> bool:
    """Record a processed event ID and return False for duplicates."""
    event_id = event_data.get("event_id")
    if not event_id:
        return True
    if event_id in protocol._processed_event_ids:
        return False
    protocol._processed_event_ids.add(event_id)
    protocol._processed_event_ids_queue.append(event_id)
    if len(protocol._processed_event_ids_queue) > protocol._processed_event_ids_max:
        evicted = protocol._processed_event_ids_queue.popleft()
        protocol._processed_event_ids.discard(evicted)
    return True


def _emit_progress_callbacks(
    protocol: "ServerProtocol",
    event_type: str,
    payload: dict[str, Any],
) -> None:
    """Fan out progress events to registered callbacks."""
    if getattr(protocol, "_on_server_progress", None):
        protocol._on_server_progress(event_type, payload)
    if protocol._on_progress:
        protocol._on_progress(event_type, payload)


def _dispatch_session_logging(
    protocol: "ServerProtocol",
    event_type: str,
    payload: dict[str, Any],
    phase_span_id: str | None,
    subphase_span_id: str | None,
) -> None:
    """Route supported progress events into the session logger."""
    if event_type == "scorecard_available":
        _process_scorecard_event(protocol, payload, subphase_span_id, phase_span_id)
        return

    if event_type in {
        "escalation_fixer_requested",
        "escalation_fixer_completed",
        "escalation_fixer_route_selected",
        "escalation_fixer_route_applied",
        "escalation_fixer_declined",
        "escalation_fixer_failed",
    }:
        _log_escalation_event(protocol, event_type, payload)
        return

    if event_type in ("item_started", "item_completed"):
        _log_lifecycle_event(protocol, event_type, payload)


def handle_progress_events(
    protocol: "ServerProtocol",
    response: dict[str, Any],
    *,
    current_phase: str | None = None,
    phase_span_id: str | None = None,
    subphase_span_id: str | None = None,
) -> None:
    """Extract and route progress events from server response to progress callback."""
    progress_cursor = response.get("progress_cursor")
    if isinstance(progress_cursor, str) and progress_cursor:
        protocol._progress_cursor = progress_cursor

    if not protocol._on_progress and not getattr(protocol, "_on_server_progress", None):
        return

    progress_events = response.get("progress_events", [])
    if not progress_events:
        return

    skip_before_timestamp = protocol._resume_start_timestamp
    skipped_count = 0
    if skip_before_timestamp:
        protocol._resume_start_timestamp = None

    for event_data in progress_events:
        if skip_before_timestamp:
            event_timestamp = event_data.get("timestamp")
            if event_timestamp and event_timestamp < skip_before_timestamp:
                skipped_count += 1
                continue

        try:
            if "event_type" not in event_data:
                logger.warning(
                    "Skipping progress event with missing event_type: %s",
                    event_data,
                )
                continue

            event_type = event_data["event_type"]
            payload = event_data.get("payload", {})

            if _should_skip_item_event(protocol, event_type, payload):
                continue
            if _should_skip_phase_event(protocol, event_type, payload, current_phase):
                continue
            if not _record_processed_event_id(protocol, event_data):
                continue

            _emit_progress_callbacks(protocol, event_type, payload)
            _dispatch_session_logging(
                protocol,
                event_type,
                payload,
                phase_span_id,
                subphase_span_id,
            )

        except Exception as exc:
            logger.warning(
                "Failed to process progress event: %s (error: %s)",
                event_data,
                exc,
                exc_info=True,
            )

    if skipped_count > 0:
        logger.debug(
            "Skipped %d historical progress events from before resume",
            skipped_count,
        )


def plan_snapshot_dir(_: "ServerProtocol") -> Path:
    """Return the directory for plan snapshot reference files."""
    return Path.home() / ".obra" / "logs" / PLAN_SNAPSHOT_DIRNAME


def write_plan_snapshot(
    protocol: "ServerProtocol",
    *,
    session_id: str,
    userplan_id: str | None = None,
    userplan_version: int | None = None,
    userplan_steps: list[dict[str, Any]] | None = None,
    derived_plan_items: list[dict[str, Any]] | None = None,
) -> str | None:
    """Write a full plan snapshot reference file for the viewer."""
    if not session_id:
        return None

    snapshot_dir = plan_snapshot_dir(protocol)
    snapshot_dir.mkdir(parents=True, exist_ok=True)
    filename = f"{session_id}.json"
    path = snapshot_dir / filename

    snapshot_payload: dict[str, Any] = {
        "session_id": session_id,
        "updated_at": datetime.now(UTC).isoformat(),
    }
    if userplan_id:
        snapshot_payload["userplan_id"] = userplan_id
    if userplan_version is not None:
        snapshot_payload["userplan_version"] = userplan_version
    if userplan_steps is not None:
        snapshot_payload["userplan_steps"] = userplan_steps
        snapshot_payload["userplan_steps_count"] = len(userplan_steps)
    if derived_plan_items is not None:
        snapshot_payload["derived_plan_items"] = derived_plan_items
        snapshot_payload["derived_plan_count"] = len(derived_plan_items)

    path.write_text(
        json.dumps(snapshot_payload, ensure_ascii=False, default=str),
        encoding="utf-8",
    )
    return filename


def read_plan_snapshot(protocol: "ServerProtocol", session_id: str) -> dict[str, Any]:
    """Read an existing plan snapshot file if present."""
    if not session_id:
        return {}
    path = plan_snapshot_dir(protocol) / f"{session_id}.json"
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}
