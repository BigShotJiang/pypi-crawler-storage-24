"""Parallel batch orchestration extracted from PlanMerger."""

from __future__ import annotations

import logging
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

from obra.display.observability import ProgressEmitter, VerbosityLevel

logger = logging.getLogger(__name__)


@dataclass
class ParallelMetrics:
    """Accumulated metrics from parallel batch execution."""

    examine_speedups: list[float] = field(default_factory=list)
    examine_stragglers: list[float] = field(default_factory=list)
    examine_metrics_by_cycle: dict[int, dict[str, float]] = field(default_factory=dict)
    revise_speedups: list[float] = field(default_factory=list)
    max_straggler: float = 1.0


@dataclass
class BatchExecutionResult:
    """Structured result from _execute_parallel_batches."""

    batch_results: list[dict[str, Any]]
    batch_errors: list[tuple[int, Exception]]
    per_batch_ms: list[float]
    wall_clock_ms: float
    speedup_ratio: float
    straggler_ratio: float
    effective_workers: int
    batch_status_map: dict[int, str] = field(default_factory=dict)
    batches_failed_count: int = 0


class ParallelBatchCoordinator:
    """Own the parallel examine and revise batch execution lifecycle."""

    def __init__(
        self,
        *,
        working_dir: str,
        llm_config: dict[str, Any],
        progress_emitter: ProgressEmitter,
        log_event: Callable[..., None],
        trace_id: str,
    ) -> None:
        self._working_dir = working_dir
        self._llm_config = llm_config
        self._progress_emitter = progress_emitter
        self._log_event = log_event
        self._trace_id = trace_id
        self.metrics = ParallelMetrics()

    def _call_progress_emitter(
        self,
        method_name: str,
        *args: Any,
        **kwargs: Any,
    ) -> None:
        """Invoke optional ProgressEmitter hooks when available."""
        if not self._progress_emitter:
            return
        method = getattr(self._progress_emitter, method_name, None)
        if callable(method):
            method(*args, **kwargs)

    def resolve_parallel_cycle(
        self,
        cycle_raw: Any,
        refinement_cycle_count: int,
    ) -> int:
        """Normalize refinement cycle values for telemetry joins."""
        try:
            cycle_num = int(cycle_raw)
            if cycle_num >= 0:
                return cycle_num
        except (TypeError, ValueError):
            pass
        return max(0, int(refinement_cycle_count))

    def merge_examine_batch_results(
        self,
        batch_results: list[dict[str, Any]],
        payload: dict[str, Any],
        batch_errors: list[tuple[int, Exception]] | None = None,
    ) -> dict[str, Any]:
        """Merge and deduplicate issues from parallel examine batches."""
        from obra.hybrid.plan_merger import PlanMerger

        all_issues: list[dict[str, Any]] = []
        total_thinking_budget = 0
        raw_responses: list[str] = []

        for result in batch_results:
            all_issues.extend(result.get("issues", []))
            total_thinking_budget += result.get("thinking_budget_used", 0)
            raw = result.get("raw_response", "")
            if raw:
                raw_responses.append(raw)

        seen: dict[str, dict[str, Any]] = {}
        for issue in all_issues:
            dedupe_key = PlanMerger.issue_dedupe_key(issue)
            if dedupe_key and dedupe_key not in seen:
                seen[dedupe_key] = issue
            elif not dedupe_key:
                seen[f"_anon_{len(seen)}"] = issue
        deduped_issues = list(seen.values())

        failed_indices = [idx for idx, _ in (batch_errors or [])]
        consolidated: dict[str, Any] = {
            "issues": deduped_issues,
            "thinking_budget_used": total_thinking_budget,
            "raw_response": "\n---\n".join(raw_responses),
            "iteration": payload.get("iteration", 0),
            "thinking_fallback": any(
                result.get("thinking_fallback", False) for result in batch_results
            ),
        }
        if batch_errors:
            consolidated["failed_batch_indices"] = failed_indices
            consolidated["failed_batch_count"] = len(batch_errors)
        return consolidated

    # ------------------------------------------------------------------
    # Shared batch execution framework
    # ------------------------------------------------------------------

    def _execute_parallel_batches(
        self,
        batch_runner_fn: Callable[[int, dict[str, Any]], dict[str, Any]],
        phase_label: str,
        batches: list[dict[str, Any]],
        *,
        cycle_num: int,
        max_iterations: int | None = None,
        classify_result_fn: Callable[[dict[str, Any]], str] | None = None,
    ) -> BatchExecutionResult:
        """Execute batches in parallel using ThreadPoolExecutor.

        Args:
            batch_runner_fn: Callable(batch_idx, batch_dict) -> result dict.
            phase_label: "examine" or "revise" for telemetry/logging.
            batches: List of batch dicts to fan out.
            cycle_num: Resolved refinement cycle number.
            max_iterations: Convergence metadata for telemetry.
            classify_result_fn: Optional callable to classify a successful
                result into a status string. Returns "success" by default.
                A non-"success" status increments batches_failed_count.
        """
        import time
        from concurrent.futures import ThreadPoolExecutor, as_completed

        from obra.config.loaders import get_refinement_parallel_max_workers

        max_workers = get_refinement_parallel_max_workers()
        effective_workers = min(max_workers, len(batches))
        total_items = sum(len(batch.get("plan_items", [])) for batch in batches)

        self._call_progress_emitter(
            "parallel_batch_started",
            phase_label,
            workers=effective_workers,
            batches=len(batches),
            items=total_items,
        )

        batch_results: list[dict[str, Any]] = []
        batch_errors: list[tuple[int, Exception]] = []
        per_batch_ms: list[float] = []
        total_start = time.monotonic()

        with ThreadPoolExecutor(max_workers=effective_workers) as executor:
            futures: dict[Any, int] = {}
            for idx, batch_dict in enumerate(batches):
                future = executor.submit(batch_runner_fn, idx, batch_dict)
                futures[future] = idx

            batches_done = 0
            batches_failed_count = 0
            batch_status_map: dict[int, str] = {}
            for future in as_completed(futures):
                batch_idx = futures[future]
                elapsed_ms = (time.monotonic() - total_start) * 1000
                try:
                    result = future.result()
                    batch_results.append(result)
                    per_batch_ms.append(elapsed_ms)
                    batches_done += 1
                    if classify_result_fn is not None:
                        batch_status = classify_result_fn(result)
                    else:
                        batch_status = "success"
                    if batch_status != "success":
                        batches_failed_count += 1
                except Exception as exc:
                    logger.warning(
                        "%s batch %d/%d failed: %s",
                        phase_label.capitalize(),
                        batch_idx + 1,
                        len(batches),
                        exc,
                    )
                    batch_errors.append((batch_idx, exc))
                    per_batch_ms.append(elapsed_ms)
                    batches_failed_count += 1
                    batch_status = "error"
                batch_status_map[batch_idx] = batch_status
                self._log_event(
                    "refinement_batch_completed",
                    phase=phase_label,
                    batch_index=batch_idx,
                    batch_size=len(batches[batch_idx].get("plan_items", [])),
                    batches_total=len(batches),
                    batches_done=batches_done,
                    batches_failed=batches_failed_count,
                    elapsed_ms=round(elapsed_ms, 1),
                    status=batch_status,
                    cycle=cycle_num,
                    convergence={
                        "max_iterations": max_iterations,
                        "batches_remaining": len(batches) - batches_done,
                    },
                )
                if (
                    self._progress_emitter
                    and len(batches) > 1
                    and self._progress_emitter.config.verbosity >= VerbosityLevel.DETAIL
                ):
                    items_in_batch = len(batches[batch_idx].get("plan_items", []))
                    status_icon = "ok" if batch_status == "success" else "err"
                    remaining = len(batches) - batches_done
                    self._progress_emitter._print(
                        f"  Batch {batches_done}/{len(batches)}: "
                        f"{items_in_batch} items {status_icon} ({elapsed_ms / 1000:.1f}s)"
                        + (f" | {remaining} running..." if remaining > 0 else ""),
                        style="dim",
                    )

        if len(batch_errors) == len(batches):
            raise batch_errors[-1][1]

        wall_clock_ms = (time.monotonic() - total_start) * 1000
        sum_per_batch = sum(per_batch_ms) if per_batch_ms else wall_clock_ms
        speedup_ratio = sum_per_batch / wall_clock_ms if wall_clock_ms > 0 else 1.0
        straggler_ratio = (
            round(max(per_batch_ms) / min(per_batch_ms), 2)
            if len(per_batch_ms) >= 2 and min(per_batch_ms) > 0
            else 1.0
        )

        return BatchExecutionResult(
            batch_results=batch_results,
            batch_errors=batch_errors,
            per_batch_ms=per_batch_ms,
            wall_clock_ms=wall_clock_ms,
            speedup_ratio=speedup_ratio,
            straggler_ratio=straggler_ratio,
            effective_workers=effective_workers,
            batch_status_map=batch_status_map,
            batches_failed_count=batches_failed_count,
        )

    # ------------------------------------------------------------------
    # Phase-specific telemetry + post-merge helpers
    # ------------------------------------------------------------------

    def _emit_straggler_alert(
        self,
        br: BatchExecutionResult,
        phase_label: str,
        cycle_num: int,
        straggler_threshold: float,
    ) -> None:
        """Emit straggler alert if ratio exceeds threshold."""
        if br.straggler_ratio > straggler_threshold:
            self._log_event(
                "batch_straggler_alert",
                straggler_ratio=br.straggler_ratio,
                worker_count=br.effective_workers,
                phase=phase_label,
                cycle=cycle_num,
                per_batch_ms=[round(ms, 1) for ms in br.per_batch_ms],
            )
            if (
                self._progress_emitter
                and self._progress_emitter.config.verbosity >= VerbosityLevel.DETAIL
            ):
                self._progress_emitter._print(
                    f"  Batch imbalance detected: straggler ratio "
                    f"{br.straggler_ratio:.1f}x (threshold: {straggler_threshold:.1f}x)",
                    style="yellow",
                )

    def _emit_batch_completed_progress(
        self,
        br: BatchExecutionResult,
        phase_label: str,
        batches_total: int,
    ) -> None:
        """Emit parallel_batch_completed progress emitter event."""
        if not self._progress_emitter:
            return
        self._call_progress_emitter(
            "increment",
            f"refinement_parallel_{phase_label}",
        )
        ordered_statuses = [br.batch_status_map.get(i, "unknown") for i in range(batches_total)]
        self._call_progress_emitter(
            "parallel_batch_completed",
            phase_label,
            wall_clock_ms=br.wall_clock_ms,
            speedup_ratio=round(br.speedup_ratio, 2),
            batches_failed=len(br.batch_errors),
            batches_total=batches_total,
            batch_statuses=ordered_statuses,
        )

    def _emit_examine_telemetry(
        self,
        br: BatchExecutionResult,
        batches: list[dict[str, Any]],
        cycle_num: int,
        straggler_threshold: float,
    ) -> None:
        """Log examine-specific telemetry and update metrics."""
        total_items = sum(len(b.get("plan_items", [])) for b in batches)
        per_batch_item_count = [len(b.get("plan_items", [])) for b in batches]
        self._log_event(
            "refinement_parallel_examine",
            wall_clock_ms=round(br.wall_clock_ms, 1),
            per_batch_ms=[round(ms, 1) for ms in br.per_batch_ms],
            per_batch_item_count=per_batch_item_count,
            worker_count=br.effective_workers,
            speedup_ratio=round(br.speedup_ratio, 2),
            straggler_ratio=br.straggler_ratio,
            batches_total=len(batches),
            batches_failed=len(br.batch_errors),
        )
        normalized_speedup = round(br.speedup_ratio, 2)
        self.metrics.examine_speedups.append(normalized_speedup)
        self.metrics.examine_stragglers.append(br.straggler_ratio)
        self.metrics.examine_metrics_by_cycle[cycle_num] = {
            "speedup": normalized_speedup,
            "straggler": br.straggler_ratio,
            "items_examined": total_items,
        }
        self.metrics.max_straggler = max(self.metrics.max_straggler, br.straggler_ratio)

        self._emit_straggler_alert(br, "examine", cycle_num, straggler_threshold)
        self._emit_batch_completed_progress(br, "examine", len(batches))

        if self._progress_emitter and br.speedup_ratio > 0:
            efficiency = br.speedup_ratio / br.effective_workers * 100
            straggler_warning = " (high)" if br.straggler_ratio > 1.5 else ""
            critical_batch = (
                br.per_batch_ms.index(max(br.per_batch_ms)) + 1 if br.per_batch_ms else 0
            )
            self._progress_emitter._print(
                f"  Examine cycle {cycle_num}: "
                f"{br.speedup_ratio:.1f}x speedup, "
                f"straggler {br.straggler_ratio:.1f}x"
                f"{straggler_warning}, "
                f"critical batch #{critical_batch}",
                style="cyan" if br.straggler_ratio <= 1.5 else "yellow",
            )
            if self._progress_emitter.config.verbosity >= VerbosityLevel.DETAIL:
                self._progress_emitter._print(
                    f"  Parallel efficiency: {br.speedup_ratio:.1f}x speedup, "
                    f"{efficiency:.0f}% efficiency, "
                    f"{br.straggler_ratio:.1f}x straggler ratio"
                    f"{straggler_warning}",
                    style="cyan" if br.straggler_ratio <= 1.5 else "yellow",
                )

    def _merge_revise_results_and_validate(
        self,
        br: BatchExecutionResult,
        full_plan_items: list[dict[str, Any]],
        c9_graph_hash: str | None,
    ) -> dict[str, Any]:
        """Merge revision batch results, run C9 validation, build consolidated."""
        from obra.agents.dependency_graph import DependencyGraphValidator
        from obra.hybrid.plan_merger import PlanMerger

        merged_plan = list(full_plan_items)
        all_addressed: list[str] = []
        all_deferred: list[dict[str, Any]] = []
        summaries: list[str] = []
        raw_responses: list[str] = []

        for result in br.batch_results:
            batch_items = result.get("plan_items", [])
            if batch_items:
                merged_plan = PlanMerger.merge_revision_batch(merged_plan, batch_items)
            all_addressed.extend(result.get("addressed_issues", []))
            all_deferred.extend(result.get("deferred_issues", []))
            summary = result.get("changes_summary", "")
            if summary:
                summaries.append(summary)
            raw = result.get("raw_response", "")
            if raw:
                raw_responses.append(raw)

        graph_hash = PlanMerger.compute_dependency_graph_hash(merged_plan)
        if graph_hash == c9_graph_hash:
            logger.debug("C9 cache hit -- skipping validation (graph unchanged)")
        else:
            findings = DependencyGraphValidator().validate(merged_plan)
            if findings:
                logger.warning(
                    "Post-merge C9 validation found %d findings: %s",
                    len(findings),
                    findings,
                )
                valid_ids = {
                    item["id"] for item in merged_plan if isinstance(item, dict) and item.get("id")
                }
                stripped_count = 0
                for item in merged_plan:
                    if not isinstance(item, dict):
                        continue
                    for dep_field in ("dependencies", "depends_on"):
                        deps = item.get(dep_field, [])
                        if not deps or not isinstance(deps, list):
                            continue
                        original_len = len(deps)
                        valid_deps = []
                        for dep in deps:
                            if isinstance(dep, dict):
                                dep_id = str(
                                    dep.get("item_id") or dep.get("id") or dep.get("task_id") or ""
                                ).strip()
                            else:
                                dep_id = str(dep).strip()
                            if dep_id in valid_ids:
                                valid_deps.append(dep)
                        if len(valid_deps) < original_len:
                            removed_ids = []
                            for dep in deps:
                                if dep not in valid_deps:
                                    if isinstance(dep, dict):
                                        removed_ids.append(
                                            str(
                                                dep.get("item_id")
                                                or dep.get("id")
                                                or dep.get("task_id")
                                                or dep
                                            )
                                        )
                                    else:
                                        removed_ids.append(str(dep))
                            logger.warning(
                                "ISSUE-HYBRID-065: Stripped %d invalid %s from %s: %s",
                                len(removed_ids),
                                dep_field,
                                item.get("id"),
                                sorted(removed_ids),
                            )
                            item[dep_field] = valid_deps
                            stripped_count += 1
                if stripped_count > 0:
                    c9_graph_hash = None
                else:
                    c9_graph_hash = graph_hash

                remaining_findings = DependencyGraphValidator().validate(
                    merged_plan,
                    skip_hierarchy=True,
                )
                remaining_findings = [
                    finding
                    for finding in remaining_findings
                    if "does not exist" not in finding.get("description", "")
                ]
                if remaining_findings:
                    for finding in remaining_findings:
                        all_deferred.append(
                            {
                                "id": finding["plan_ref"],
                                "reason": (
                                    "C9 structural violation: "
                                    f"{finding['description']}. "
                                    f"Evidence: {finding['evidence']}"
                                ),
                                "severity": "P0",
                                "source": "c9_enforcement",
                            }
                        )
                    self._log_event(
                        "c9_non_fixable_findings",
                        count=len(remaining_findings),
                        finding_types=list(
                            {finding["description"].split(":")[0] for finding in remaining_findings}
                        ),
                        affected_items=[finding["plan_ref"] for finding in remaining_findings],
                    )
            else:
                c9_graph_hash = graph_hash

        consolidated: dict[str, Any] = {
            "plan_items": merged_plan,
            "addressed_issues": all_addressed,
            "deferred_issues": all_deferred,
            "changes_summary": "\n---\n".join(summaries),
            "raw_response": "\n---\n".join(raw_responses),
            "batches_failed_count": br.batches_failed_count,
            "c9_graph_hash": c9_graph_hash,
        }

        failed_indices = [idx for idx, _ in br.batch_errors]
        if br.batch_errors:
            consolidated["failed_batch_indices"] = failed_indices
            consolidated["failed_batch_count"] = len(br.batch_errors)
            consolidated["all_batches_failed"] = False

        return consolidated

    @staticmethod
    def _classify_revise_result(result: dict[str, Any]) -> str:
        """Classify a revise batch result as success or template_fallback."""
        is_fallback = result.get("failure_class") == "valid_output_no_file_edit"
        if not is_fallback:
            deferred = result.get("deferred_issues", [])
            is_fallback = any(
                isinstance(item, dict) and "template-edit failure" in str(item.get("reason", ""))
                for item in deferred
            )
        return "template_fallback" if is_fallback else "success"

    def _emit_revise_telemetry(
        self,
        br: BatchExecutionResult,
        batches: list[dict[str, Any]],
        payload: dict[str, Any],
        cycle_num: int,
        straggler_threshold: float,
    ) -> None:
        """Log revise-specific telemetry and update metrics."""
        self._log_event(
            "refinement_parallel_revise",
            wall_clock_ms=round(br.wall_clock_ms, 1),
            per_batch_ms=[round(ms, 1) for ms in br.per_batch_ms],
            worker_count=br.effective_workers,
            speedup_ratio=round(br.speedup_ratio, 2),
            straggler_ratio=br.straggler_ratio,
            batches_total=len(batches),
            batches_failed=br.batches_failed_count,
        )
        normalized_speedup = round(br.speedup_ratio, 2)
        self.metrics.revise_speedups.append(normalized_speedup)
        self.metrics.max_straggler = max(self.metrics.max_straggler, br.straggler_ratio)
        cycle_metrics = self.metrics.examine_metrics_by_cycle.get(cycle_num) or {}
        examine_speedup = float(cycle_metrics.get("speedup", 1.0))
        examine_straggler = float(cycle_metrics.get("straggler", 1.0))
        items_examined = int(cycle_metrics.get("items_examined", 0))
        if items_examined <= 0:
            items_examined = sum(
                len(batch.get("plan_items", [])) for batch in payload.get("batches", [])
            )
        self._log_event(
            "parallelization_cycle_summary",
            cycle=cycle_num,
            examine_speedup=examine_speedup,
            revise_speedup=normalized_speedup,
            examine_straggler=examine_straggler,
            revise_straggler=br.straggler_ratio,
            examine_metrics_source=("cycle_matched" if cycle_metrics else "fallback_default"),
            items_examined=items_examined,
        )

        self._emit_straggler_alert(br, "revise", cycle_num, straggler_threshold)
        self._emit_batch_completed_progress(br, "revise", len(batches))

    # ------------------------------------------------------------------
    # Public API -- thin wrappers
    # ------------------------------------------------------------------

    def handle_parallel_examine_batches(
        self,
        payload: dict[str, Any],
        *,
        role_llm_config: dict[str, Any],
        refinement_cycle_count: int,
        straggler_threshold: float,
    ) -> dict[str, Any]:
        """Fan out examination batches to parallel ExamineHandler workers."""
        from obra.api.protocol import ExamineRequest
        from obra.hybrid.handlers.examine import ExamineHandler

        batches = payload.get("batches", [])
        if not batches:
            return {
                "issues": [],
                "thinking_budget_used": 0,
                "raw_response": "",
                "iteration": payload.get("iteration", 0),
                "thinking_fallback": False,
            }

        shared_fields = {
            "base_prompt": payload.get("base_prompt"),
            "plan_version_id": payload.get("plan_version_id"),
            "thinking_required": payload.get("thinking_required"),
            "reasoning_level": payload.get("reasoning_level"),
            "iteration": payload.get("iteration"),
            "max_iterations": payload.get("max_iterations"),
        }
        cycle_num = self.resolve_parallel_cycle(
            refinement_cycle_count,
            refinement_cycle_count,
        )

        def _run_batch(batch_idx: int, batch_dict: dict[str, Any]) -> dict[str, Any]:
            merged = {**shared_fields, **batch_dict}
            handler = ExamineHandler(
                working_dir=self._working_dir,
                llm_config=role_llm_config,
                log_event=self._log_event,
                trace_id=self._trace_id,
            )
            return handler.handle(ExamineRequest.from_payload(merged))

        br = self._execute_parallel_batches(
            _run_batch,
            "examine",
            batches,
            cycle_num=cycle_num,
            max_iterations=payload.get("max_iterations"),
        )
        merged_result = self.merge_examine_batch_results(
            br.batch_results,
            payload,
            br.batch_errors,
        )
        self._emit_examine_telemetry(br, batches, cycle_num, straggler_threshold)
        return merged_result

    def handle_parallel_revise_batches(
        self,
        payload: dict[str, Any],
        *,
        role_llm_config: dict[str, Any],
        refinement_cycle_count: int,
        c9_graph_hash: str | None,
        straggler_threshold: float,
    ) -> dict[str, Any]:
        """Fan out revision batches to parallel ReviseHandler workers."""
        from obra.api.protocol import RevisionRequest
        from obra.hybrid.handlers.revise import ReviseHandler

        batches = payload.get("batches", [])
        full_plan_items = payload.get("full_plan_items", [])
        c9_graph_hash = None

        if not batches:
            return {
                "plan_items": list(full_plan_items),
                "addressed_issues": [],
                "deferred_issues": [],
                "changes_summary": "",
                "raw_response": "",
                "c9_graph_hash": c9_graph_hash,
            }

        shared_fields = {
            "proposed_defaults": payload.get("proposed_defaults"),
            "current_plan_version_id": payload.get("current_plan_version_id"),
            "userplan_id": payload.get("userplan_id"),
        }
        cycle_num = self.resolve_parallel_cycle(
            payload.get("iteration"),
            refinement_cycle_count,
        )

        def _run_batch(batch_idx: int, batch_dict: dict[str, Any]) -> dict[str, Any]:
            merged = {**shared_fields, **batch_dict}
            handler = ReviseHandler(
                working_dir=self._working_dir,
                llm_config=role_llm_config,
                log_event=self._log_event,
                trace_id=self._trace_id,
            )
            return handler.handle(RevisionRequest.from_payload(merged))

        br = self._execute_parallel_batches(
            _run_batch,
            "revise",
            batches,
            cycle_num=cycle_num,
            max_iterations=payload.get("max_iterations"),
            classify_result_fn=self._classify_revise_result,
        )
        consolidated = self._merge_revise_results_and_validate(
            br,
            full_plan_items,
            c9_graph_hash,
        )
        self._emit_revise_telemetry(
            br,
            batches,
            payload,
            cycle_num,
            straggler_threshold,
        )
        return consolidated
