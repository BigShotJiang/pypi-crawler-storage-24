"""Interaction-policy taxonomy for hybrid runtime prompt sites.

Classifies every prompt site in the orchestration runtime so handlers
can decide deterministically how to handle user interaction without
probing ambient terminal state.

Taxonomy:
    INTERACTIVE_ONLY  - requires --interactive; fail fast with hint otherwise
    AUTO_ACCEPT       - auto-decide without prompting in headless mode
    FAIL_FAST         - fail with actionable remediation in headless mode
    REMOTE_RESOLVE    - route through gateway event bus (escalation)
"""

from __future__ import annotations

import enum
import logging

from obra.display import print_warning

logger = logging.getLogger(__name__)


class PromptPolicy(enum.Enum):
    """How a prompt site should behave when interaction mode is headless."""

    INTERACTIVE_ONLY = "interactive_only"
    AUTO_ACCEPT = "auto_accept"
    FAIL_FAST = "fail_fast"
    REMOTE_RESOLVE = "remote_resolve"


def should_prompt(policy: PromptPolicy) -> bool:
    """Return True only when the current CLI invocation allows this prompt.

    Uses the resolved interaction mode from the CLI launch layer.
    """
    from obra.hybrid.interaction_mode import current_mode_is_interactive

    if policy is PromptPolicy.AUTO_ACCEPT:
        return False  # never prompt, auto-decide
    if policy is PromptPolicy.REMOTE_RESOLVE:
        return False  # handled by gateway, not stdin
    if policy is PromptPolicy.FAIL_FAST:
        return False  # will fail with remediation hint
    # INTERACTIVE_ONLY: prompt only when interactive
    return current_mode_is_interactive()


def guard_interactive_only(site_name: str) -> None:
    """Raise ValueError with a remediation hint if current mode is headless.

    Call this at prompt sites classified as INTERACTIVE_ONLY before
    attempting any stdin read.
    """
    from obra.hybrid.interaction_mode import current_mode_is_interactive

    if current_mode_is_interactive():
        return

    msg = (
        f"{site_name} requires interactive mode. Re-run with --interactive to enable stdin prompts."
    )
    logger.info("Headless guard triggered: %s", site_name)
    print_warning(msg)
    raise ValueError(msg)


def check_interactive_or_auto_accept(site_name: str) -> bool:
    """Return True if prompting is allowed, False if auto-accept should apply.

    For prompt sites that should auto-accept in headless mode but allow
    user override when interactive.
    """
    from obra.hybrid.interaction_mode import current_mode_is_interactive

    if current_mode_is_interactive():
        return True  # prompting allowed
    logger.debug("Auto-accepting %s in headless mode", site_name)
    return False  # auto-accept, no prompt
