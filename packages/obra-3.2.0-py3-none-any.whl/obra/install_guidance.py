"""Installer-aware user guidance for local Obra surfaces.

This module centralizes human-facing install and upgrade command rendering.
It intentionally detects the local install context so runtime recovery text can
recommend the command that matches how Obra is actually installed.
"""

from __future__ import annotations

import json
import os
import shlex
import shutil
import subprocess
import sys
from importlib import metadata
from pathlib import Path
from typing import Literal

InstallContext = Literal["editable", "uv", "pipx", "venv", "pip", "unknown"]


def _editable_source_dir() -> str | None:
    """Return the source directory for an editable install, or None."""
    try:
        import site

        dist = metadata.distribution("obra")

        candidates: list[Path] = [Path(str(dist._path)) / "direct_url.json"]
        for site_packages_dir in site.getsitepackages():
            for entry in Path(site_packages_dir).iterdir():
                if entry.name.startswith("obra-") and entry.name.endswith(".dist-info"):
                    candidates.append(entry / "direct_url.json")

        for direct_url in candidates:
            if not direct_url.is_file():
                continue
            data = json.loads(direct_url.read_text(encoding="utf-8"))
            if not data.get("dir_info", {}).get("editable", False):
                continue
            url = str(data.get("url", ""))
            if url.startswith("file://"):
                return url.removeprefix("file://")
    except Exception:
        return None
    return None


def _pipx_manages_obra(timeout_s: int = 5) -> bool:
    pipx_path = shutil.which("pipx")
    if not pipx_path:
        return False
    try:
        result = subprocess.run(
            [pipx_path, "list", "--json"],
            capture_output=True,
            text=True,
            check=False,
            timeout=timeout_s,
        )
    except (OSError, subprocess.TimeoutExpired):
        return False

    if result.returncode != 0:
        return False

    try:
        payload = json.loads(result.stdout or "{}")
    except ValueError:
        return False

    venvs = payload.get("venvs", {}) if isinstance(payload, dict) else {}
    return isinstance(venvs, dict) and "obra" in venvs


def detect_install_context() -> InstallContext:
    """Detect the local install context for the active Obra distribution."""
    editable_source = _editable_source_dir()
    if editable_source is not None:
        return "editable"

    try:
        dist = metadata.distribution("obra")
    except metadata.PackageNotFoundError:
        dist = None

    if dist is not None:
        try:
            installer = (dist.read_text("INSTALLER") or "").strip().lower()
        except Exception:
            installer = ""

        if "uv" in installer:
            return "uv"
        if "pipx" in installer:
            return "pipx"
        if installer == "pip":
            if os.environ.get("VIRTUAL_ENV") or sys.prefix != getattr(
                sys, "base_prefix", sys.prefix
            ):
                return "venv"
            return "pip"

    if _pipx_manages_obra():
        return "pipx"

    if os.environ.get("VIRTUAL_ENV") or sys.prefix != getattr(sys, "base_prefix", sys.prefix):
        return "venv"

    return "pip"


def _join_shell(parts: list[str]) -> str:
    return " ".join(shlex.quote(part) for part in parts)


def recommended_upgrade_command() -> str:
    """Return the installer-aware command for upgrading the local Obra CLI."""
    install_context = detect_install_context()
    if install_context == "editable":
        editable_source = _editable_source_dir()
        if editable_source:
            return _join_shell(
                [sys.executable, "-m", "pip", "install", "-e", f"{editable_source}[gateway]"]
            )
    if install_context == "uv":
        uv_path = shutil.which("uv")
        if uv_path:
            return _join_shell([uv_path, "tool", "upgrade", "obra"])
        return "uv tool upgrade obra"
    if install_context == "pipx":
        pipx_path = shutil.which("pipx")
        if pipx_path:
            return _join_shell([pipx_path, "upgrade", "obra"])
        return "pipx upgrade obra"
    return _join_shell([sys.executable, "-m", "pip", "install", "--upgrade", "obra"])


def recommended_upgrade_recovery(prefix: str = "Run", suffix: str = "to update.") -> str:
    """Return a complete recovery sentence for upgrading Obra locally."""
    return f"{prefix} '{recommended_upgrade_command()}' {suffix}"


def recommended_gateway_install_hint() -> str:
    """Return the installer-aware command for Workflow Studio gateway extras."""
    install_context = detect_install_context()
    if install_context == "editable":
        package_root = Path(__file__).resolve().parent
        return f"cd {package_root} && {sys.executable} -m pip install -e '.[gateway]'"
    if install_context == "uv":
        return "uv tool install obra --with 'obra[gateway]'"
    if install_context == "pipx":
        return "pipx runpip obra install 'obra[gateway]'"
    return f"{sys.executable} -m pip install 'obra[gateway]'"


def recommended_voice_install_hint() -> str:
    """Return the installer-aware command for Studio voice support."""
    install_context = detect_install_context()
    if install_context == "editable":
        package_root = Path(__file__).resolve().parent
        return f"cd {package_root} && {sys.executable} -m pip install -e '.[voice]'"
    if install_context == "uv":
        return "uv tool install obra --with 'obra[gateway,voice]'"
    if install_context == "pipx":
        return "pipx inject obra faster-whisper"
    return f"{sys.executable} -m pip install 'obra[voice]'"
