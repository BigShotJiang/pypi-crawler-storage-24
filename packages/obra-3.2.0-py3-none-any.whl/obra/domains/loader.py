"""Domain module loader and registry.

This module provides functions to discover and load domain modules.
Domains are auto-discovered from the obra/domains/ directory.

Architecture:
    - get_available_domains(): Lists all available domain names
    - load_domain(): Loads and caches a domain module by name
    - DomainNotFoundError: Raised when domain doesn't exist
    - DomainValidationError: Raised when domain is malformed

Related:
    - obra/domains/interface.py (protocol definition)
    - obra/domains/software/ (software development domain)
    - obra/domains/business/ (business workflow domain)
"""

import importlib
import importlib.metadata
import logging
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .interface import DomainModule

logger = logging.getLogger(__name__)

# Thread safety: Race conditions during initial load are benign since
# domain modules are immutable singletons. Worst case: duplicate load
# which is wasteful but not incorrect. No lock needed.
_domain_cache: dict[str, "DomainModule"] = {}


def _get_domain_entry_points() -> dict[str, importlib.metadata.EntryPoint]:
    """Return installed domain entry points keyed by normalized name."""
    try:
        entry_points = importlib.metadata.entry_points(group="obra.domains")
    except TypeError:
        entry_points = importlib.metadata.entry_points().select(group="obra.domains")
    discovered: dict[str, importlib.metadata.EntryPoint] = {}
    for entry_point in entry_points:
        discovered[entry_point.name.lower()] = entry_point
    return discovered


def _get_local_domain_names() -> set[str]:
    """Return locally bundled domain module names."""
    domains_dir = Path(__file__).parent
    return {
        d.name.lower()
        for d in domains_dir.iterdir()
        if d.is_dir() and not d.name.startswith("_") and (d / "__init__.py").exists()
    }


def _instantiate_domain_provider(provider: object) -> "DomainModule":
    """Instantiate a domain provider loaded from an entry point."""
    if isinstance(provider, type):
        candidate = provider()
    elif callable(provider):
        candidate = provider()
    else:
        candidate = provider
    return candidate  # type: ignore[return-value]


def _validate_domain_instance(name: str, domain: "DomainModule") -> None:
    """Validate required methods and properties for a loaded domain instance."""
    required_methods = [
        "get_work_type_patterns",
        "get_quality_prompts",
        "get_quality_dimensions",
        "get_file_filters",
        "get_derivation_keywords",
        "get_sizing_guidance",
        "get_lifecycle_policy",
        "get_derivation_defaults",
    ]
    required_properties = {
        "name": str,
        "display_name": str,
        "description": str,
        "example_objectives": list,
        "requires_git": bool,
        "default_sandbox_policy": str,
        "closeout_key": str,
    }
    errors: list[str] = []

    for method in required_methods:
        if not callable(getattr(domain, method, None)):
            errors.append(f"Missing required method '{method}'")

    for prop, expected_type in required_properties.items():
        if not hasattr(domain, prop):
            errors.append(f"Missing required property '{prop}'")
            continue
        try:
            value = getattr(domain, prop)
        except Exception as exc:  # pragma: no cover - defensive guard
            errors.append(f"Property '{prop}' raised during access: {exc}")
            continue
        if not isinstance(value, expected_type):
            errors.append(
                f"Property '{prop}' expected {expected_type.__name__}, got {type(value).__name__}"
            )
            continue
        if prop == "example_objectives" and not all(isinstance(item, str) for item in value):
            errors.append("Property 'example_objectives' must be list[str]")

    if errors:
        error_list = "\n".join(f"- {error}" for error in errors)
        msg = f"Domain '{name}' failed validation:\n{error_list}"
        raise DomainValidationError(msg)


class DomainNotFoundError(ValueError):
    """Raised when requested domain does not exist."""


class DomainValidationError(ValueError):
    """Raised when domain module is malformed."""


def get_available_domains() -> list[str]:
    """Return list of available domain names.

    Discovers domains by scanning the obra/domains/ directory for
    subdirectories containing __init__.py files.

    Returns:
        List of domain names (lowercase)
    """
    discovered = _get_local_domain_names()
    discovered.update(_get_domain_entry_points().keys())
    return sorted(discovered)


def load_domain(name: str) -> "DomainModule":
    """Load and return a domain module by name.

    Domain names are case-insensitive - 'SOFTWARE' and 'software' both
    load the software domain.

    Args:
        name: Domain name (e.g., 'software', 'business')

    Returns:
        DomainModule instance

    Raises:
        DomainNotFoundError: If domain does not exist
        DomainValidationError: If domain is malformed

    Example:
        >>> domain = load_domain("software")
        >>> print(domain.name)
        software
        >>> domain = load_domain("SOFTWARE")  # Case-insensitive
        >>> print(domain.name)
        software
    """
    # Normalize to lowercase (Finding 5: case insensitivity)
    name = name.lower()

    if name in _domain_cache:
        return _domain_cache[name]

    local_domains = _get_local_domain_names()
    package_domains = _get_domain_entry_points()
    available = sorted(local_domains | set(package_domains))
    if name not in available:
        available_str = ", ".join(available) if available else "(none)"
        msg = f"Domain '{name}' not found. Available domains: {available_str}"
        raise DomainNotFoundError(msg)

    if name in local_domains:
        try:
            module = importlib.import_module(f"obra.domains.{name}")
        except ImportError as e:
            msg = f"Failed to import domain '{name}': {e}"
            raise DomainValidationError(msg) from e

        class_name = f"{name.title()}Domain"
        if not hasattr(module, class_name):
            msg = f"Domain '{name}' missing required class '{class_name}'"
            raise DomainValidationError(msg)

        domain_class = getattr(module, class_name)
        domain = domain_class()
        logger.debug("Loaded domain '%s' from obra.domains.%s", name, name)
    else:
        entry_point = package_domains[name]
        try:
            provider = entry_point.load()
            domain = _instantiate_domain_provider(provider)
        except Exception as exc:
            msg = (
                f"Failed to load packaged domain '{name}' from entry point "
                f"'{entry_point.value}': {exc}"
            )
            raise DomainValidationError(msg) from exc
        logger.debug(
            "Loaded domain '%s' from entry point '%s'",
            name,
            entry_point.value,
        )

    _validate_domain_instance(name, domain)

    _domain_cache[name] = domain
    return domain


def clear_domain_cache() -> None:
    """Clear the domain cache.

    Useful for testing or when domain files have been modified.
    """
    _domain_cache.clear()
    logger.debug("Domain cache cleared")
