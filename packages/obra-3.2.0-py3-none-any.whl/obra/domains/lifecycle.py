"""Structured domain-owned lifecycle defaults for workflow derivation."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

ACTIVE_STATE = "active"
SKIPPED_STATE = "skipped"
INHERITED_STATE = "inherited"
COMPATIBILITY_PATH_STATE = "compatibility_path"

VALID_LIFECYCLE_STATES = frozenset(
    {
        ACTIVE_STATE,
        SKIPPED_STATE,
        INHERITED_STATE,
        COMPATIBILITY_PATH_STATE,
    }
)

DERIVE_CAPABILITY = "derive"
EXECUTE_CAPABILITY = "execute"
STORY0_CAPABILITY = "story0"
PREFLIGHT_CAPABILITY = "preflight"
REVIEW_CAPABILITY = "review"
WAIT_RESUME_CAPABILITY = "wait_resume"
GIT_REQUIRED_CAPABILITY = "git_required"
TOOLING_VERIFICATION_CAPABILITY = "tooling_verification"

KNOWN_LIFECYCLE_CAPABILITIES = (
    DERIVE_CAPABILITY,
    EXECUTE_CAPABILITY,
    STORY0_CAPABILITY,
    PREFLIGHT_CAPABILITY,
    REVIEW_CAPABILITY,
    WAIT_RESUME_CAPABILITY,
    GIT_REQUIRED_CAPABILITY,
    TOOLING_VERIFICATION_CAPABILITY,
)


def _normalize_capability_states(value: Any) -> dict[str, str]:
    if not isinstance(value, dict):
        return {}
    normalized: dict[str, str] = {}
    for raw_capability, raw_state in value.items():
        capability = str(raw_capability or "").strip()
        if not capability:
            continue
        state = str(raw_state or "").strip().lower()
        if state not in VALID_LIFECYCLE_STATES:
            msg = (
                f"Lifecycle state for capability '{capability}' must be one of "
                f"{sorted(VALID_LIFECYCLE_STATES)}; got {raw_state!r}"
            )
            raise ValueError(msg)
        normalized[capability] = state
    return normalized


@dataclass(slots=True, frozen=True)
class DomainDerivationDefaults:
    """Structured derivation defaults published by a domain."""

    default_work_type: str = "general"

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> "DomainDerivationDefaults":
        if not isinstance(data, dict):
            return cls()
        default_work_type = str(data.get("default_work_type") or "general").strip()
        return cls(default_work_type=default_work_type or "general")

    def to_dict(self) -> dict[str, Any]:
        return {"default_work_type": self.default_work_type}


@dataclass(slots=True, frozen=True)
class DomainLifecyclePolicy:
    """Structured workflow-lifecycle defaults published by a domain."""

    capability_states: dict[str, str] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> "DomainLifecyclePolicy":
        if not isinstance(data, dict):
            return cls()
        capability_states = data.get("capability_states", data)
        return cls(capability_states=_normalize_capability_states(capability_states))

    def to_dict(self) -> dict[str, Any]:
        return {"capability_states": dict(self.capability_states)}

    def state_for(self, capability: str) -> str:
        return self.capability_states.get(str(capability), SKIPPED_STATE)

    @property
    def requires_git(self) -> bool:
        return self.state_for(GIT_REQUIRED_CAPABILITY) != SKIPPED_STATE


__all__ = [
    "ACTIVE_STATE",
    "COMPATIBILITY_PATH_STATE",
    "DERIVE_CAPABILITY",
    "DomainDerivationDefaults",
    "DomainLifecyclePolicy",
    "EXECUTE_CAPABILITY",
    "KNOWN_LIFECYCLE_CAPABILITIES",
    "GIT_REQUIRED_CAPABILITY",
    "INHERITED_STATE",
    "PREFLIGHT_CAPABILITY",
    "REVIEW_CAPABILITY",
    "SKIPPED_STATE",
    "STORY0_CAPABILITY",
    "TOOLING_VERIFICATION_CAPABILITY",
    "VALID_LIFECYCLE_STATES",
    "WAIT_RESUME_CAPABILITY",
]
