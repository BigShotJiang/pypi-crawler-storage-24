"""Exception hierarchy for transient and non-transient error classification.

Defines the exception class tree used by Obra's retry logic.  All other
symbols (metrics, classifiers, failure tracking, budget monitoring, task
outcomes) have been extracted into sibling modules and are re-exported here
for backward compatibility.

Re-export sources:
- obra.execution.task_outcomes: TaskOutcome, TaskResult
- obra.execution.error_classifier: is_transient, get_retry_after, HTTP status sets
- obra.execution.failure_tracking: FailureTracker, BudgetMonitor, decomposition metrics
"""

from __future__ import annotations

import logging
import warnings
from typing import Any

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Transient error hierarchy (retryable)
# ---------------------------------------------------------------------------


class TransientError(Exception):
    """Base class for transient (retryable) errors.

    Transient errors are temporary failures that may succeed if retried.
    Examples: rate limits, network timeouts, temporary service unavailability.
    """

    def __init__(
        self,
        message: str,
        *,
        retry_after: float | None = None,
        original_error: Exception | None = None,
    ) -> None:
        """Initialize TransientError.

        Args:
            message: Error message describing the transient failure
            retry_after: Suggested seconds to wait before retrying (None if unknown)
            original_error: The underlying exception that was classified as transient
        """
        super().__init__(message)
        self.retry_after = retry_after
        self.original_error = original_error


class RateLimitError(TransientError):
    """Rate limit exceeded - retry after backoff.

    This is a specific transient error for rate limiting (HTTP 429).
    """

    def __init__(
        self,
        message: str = "Rate limit exceeded",
        *,
        retry_after: float | None = None,
        original_error: Exception | None = None,
    ) -> None:
        """Initialize RateLimitError.

        Args:
            message: Error message
            retry_after: Seconds to wait before retrying (from Retry-After header)
            original_error: The underlying exception
        """
        super().__init__(message, retry_after=retry_after, original_error=original_error)


class TimeoutError(TransientError):
    """Operation timed out - may succeed on retry.

    This is a specific transient error for timeouts.
    """

    def __init__(
        self,
        message: str = "Operation timed out",
        *,
        retry_after: float | None = None,
        original_error: Exception | None = None,
    ) -> None:
        """Initialize TimeoutError.

        Args:
            message: Error message
            retry_after: Suggested backoff time
            original_error: The underlying exception
        """
        super().__init__(message, retry_after=retry_after, original_error=original_error)


class SubprocessTimeoutError(TimeoutError):
    """Subprocess execution timed out.

    Raised when a subprocess (e.g., LLM CLI invocation) exceeds its
    configured timeout. Carries structured context for telemetry.

    Inherits: TimeoutError -> TransientError -> Exception (NOT RuntimeError).
    """

    def __init__(
        self,
        message: str = "Subprocess timed out",
        *,
        call_site: str = "",
        configured_timeout_s: float = 0.0,
        elapsed_s: float | None = None,
        retry_after: float | None = None,
        original_error: Exception | None = None,
    ) -> None:
        super().__init__(message, retry_after=retry_after, original_error=original_error)
        self.call_site = call_site
        self.configured_timeout_s = configured_timeout_s
        self.elapsed_s = elapsed_s

    def __str__(self) -> str:
        parts = [super().__str__()]
        if self.call_site:
            parts.append(f"call_site={self.call_site}")
        if self.configured_timeout_s:
            parts.append(f"configured_timeout_s={self.configured_timeout_s}")
        if self.elapsed_s is not None:
            parts.append(f"elapsed_s={self.elapsed_s}")
        return " | ".join(parts)


class HTTPTimeoutError(TimeoutError):
    """HTTP request timed out.

    Raised when an HTTP request exceeds its configured timeout.
    Carries structured context for telemetry.

    Inherits: TimeoutError -> TransientError -> Exception (NOT RuntimeError).
    """

    def __init__(
        self,
        message: str = "HTTP request timed out",
        *,
        url: str = "",
        configured_timeout_s: float = 0.0,
        method: str = "",
        retry_after: float | None = None,
        original_error: Exception | None = None,
    ) -> None:
        super().__init__(message, retry_after=retry_after, original_error=original_error)
        self.url = url
        self.configured_timeout_s = configured_timeout_s
        self.method = method

    def __str__(self) -> str:
        parts = [super().__str__()]
        if self.method:
            parts.append(f"method={self.method}")
        if self.url:
            parts.append(f"url={self.url}")
        if self.configured_timeout_s:
            parts.append(f"configured_timeout_s={self.configured_timeout_s}")
        return " | ".join(parts)


class LLMInvocationTimeoutError(TimeoutError):
    """LLM invocation timed out.

    Raised when an LLM invocation (via CLI runner or API) exceeds its
    configured timeout. Carries structured context for telemetry.

    Inherits: TimeoutError -> TransientError -> Exception (NOT RuntimeError).
    """

    def __init__(
        self,
        message: str = "LLM invocation timed out",
        *,
        call_site: str = "",
        provider: str = "",
        configured_timeout_s: float = 0.0,
        elapsed_s: float | None = None,
        retry_after: float | None = None,
        original_error: Exception | None = None,
    ) -> None:
        super().__init__(message, retry_after=retry_after, original_error=original_error)
        self.call_site = call_site
        self.provider = provider
        self.configured_timeout_s = configured_timeout_s
        self.elapsed_s = elapsed_s

    def __str__(self) -> str:
        parts = [super().__str__()]
        if self.call_site:
            parts.append(f"call_site={self.call_site}")
        if self.provider:
            parts.append(f"provider={self.provider}")
        if self.configured_timeout_s:
            parts.append(f"configured_timeout_s={self.configured_timeout_s}")
        if self.elapsed_s is not None:
            parts.append(f"elapsed_s={self.elapsed_s}")
        return " | ".join(parts)


class NetworkError(TransientError):
    """Temporary network issue - may succeed on retry.

    This is a specific transient error for network connectivity issues.
    """

    def __init__(
        self,
        message: str = "Network error",
        *,
        retry_after: float | None = None,
        original_error: Exception | None = None,
    ) -> None:
        """Initialize NetworkError.

        Args:
            message: Error message
            retry_after: Suggested backoff time
            original_error: The underlying exception
        """
        super().__init__(message, retry_after=retry_after, original_error=original_error)


class ServiceUnavailableError(TransientError):
    """Service temporarily unavailable - retry later.

    This is a specific transient error for HTTP 503 responses.
    """

    def __init__(
        self,
        message: str = "Service temporarily unavailable",
        *,
        retry_after: float | None = None,
        original_error: Exception | None = None,
    ) -> None:
        """Initialize ServiceUnavailableError.

        Args:
            message: Error message
            retry_after: Seconds to wait (from Retry-After header)
            original_error: The underlying exception
        """
        super().__init__(message, retry_after=retry_after, original_error=original_error)


# ---------------------------------------------------------------------------
# Non-transient error hierarchy (fail-fast)
# ---------------------------------------------------------------------------


class NonTransientError(Exception):
    """Base class for non-transient (non-retryable) errors.

    Non-transient errors are permanent failures that will not succeed on retry.
    Examples: validation errors, authentication failures, resource not found.
    """

    def __init__(
        self,
        message: str,
        *,
        error_code: str | None = None,
        original_error: Exception | None = None,
    ) -> None:
        """Initialize NonTransientError.

        Args:
            message: Error message describing the permanent failure
            error_code: Optional error code (e.g., "VALIDATION_ERROR", "AUTH_FAILED")
            original_error: The underlying exception that was classified as non-transient
        """
        super().__init__(message)
        self.error_code = error_code
        self.original_error = original_error


class ValidationError(NonTransientError):
    """Input validation failed - do not retry.

    This is a specific non-transient error for validation failures.
    """

    def __init__(
        self,
        message: str = "Validation failed",
        *,
        error_code: str | None = None,
        original_error: Exception | None = None,
        field: str | None = None,
    ) -> None:
        """Initialize ValidationError.

        Args:
            message: Error message
            error_code: Optional error code
            original_error: The underlying exception
            field: Optional field name that failed validation
        """
        super().__init__(
            message,
            error_code=error_code or "VALIDATION_ERROR",
            original_error=original_error,
        )
        self.field = field


class AuthenticationError(NonTransientError):
    """Authentication failed - do not retry.

    This is a specific non-transient error for auth failures.
    """

    def __init__(
        self,
        message: str = "Authentication failed",
        *,
        error_code: str | None = None,
        original_error: Exception | None = None,
    ) -> None:
        """Initialize AuthenticationError.

        Args:
            message: Error message
            error_code: Optional error code
            original_error: The underlying exception
        """
        super().__init__(
            message,
            error_code=error_code or "AUTH_FAILED",
            original_error=original_error,
        )


class NotFoundError(NonTransientError):
    """Resource not found - do not retry.

    This is a specific non-transient error for HTTP 404 responses.
    """

    def __init__(
        self,
        message: str = "Resource not found",
        *,
        error_code: str | None = None,
        original_error: Exception | None = None,
        resource_type: str | None = None,
        resource_id: str | None = None,
    ) -> None:
        """Initialize NotFoundError.

        Args:
            message: Error message
            error_code: Optional error code
            original_error: The underlying exception
            resource_type: Type of resource that was not found
            resource_id: ID of the resource that was not found
        """
        super().__init__(
            message, error_code=error_code or "NOT_FOUND", original_error=original_error
        )
        self.resource_type = resource_type
        self.resource_id = resource_id


class ForbiddenError(NonTransientError):
    """Access forbidden - do not retry.

    This is a specific non-transient error for HTTP 403 responses.
    """

    def __init__(
        self,
        message: str = "Access forbidden",
        *,
        error_code: str | None = None,
        original_error: Exception | None = None,
    ) -> None:
        """Initialize ForbiddenError.

        Args:
            message: Error message
            error_code: Optional error code
            original_error: The underlying exception
        """
        super().__init__(
            message, error_code=error_code or "FORBIDDEN", original_error=original_error
        )


# ---------------------------------------------------------------------------
# Re-exports: task outcomes (obra.execution.task_outcomes)
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Re-exports: error classifier (obra.execution.error_classifier)
# ---------------------------------------------------------------------------
from obra.execution.error_classifier import (  # noqa: E402
    _NON_TRANSIENT_HTTP_STATUS_CODES,
    _TRANSIENT_HTTP_STATUS_CODES,
    METRIC_ERRORS_CLASSIFIED,
    NON_TRANSIENT_HTTP_STATUSES,
    TRANSIENT_HTTP_STATUSES,
    emit_error_classification_metric,
    get_error_classification_metrics_summary,
    get_retry_after,
    is_transient,
)

# ---------------------------------------------------------------------------
# Re-exports: failure tracking (obra.execution.failure_tracking)
# ---------------------------------------------------------------------------
from obra.execution.failure_tracking import (  # noqa: E402
    METRIC_DECOMPOSITION_TRIGGERS,
    BudgetMonitor,
    BudgetRecord,
    DecompositionMetricsCollector,
    DecompositionTriggerMetric,
    FailureRecord,
    FailureTracker,
    get_decomposition_metrics_collector,
)
from obra.execution.task_outcomes import TaskOutcome, TaskResult  # noqa: E402

# ---------------------------------------------------------------------------
# Deprecated module-level attribute access
# ---------------------------------------------------------------------------


def __getattr__(name: str) -> Any:
    """PEP 562 module-level __getattr__ for deprecation warnings."""
    if name == "TRANSIENT_HTTP_STATUS_CODES":
        warnings.warn(
            "TRANSIENT_HTTP_STATUS_CODES is deprecated, use TRANSIENT_STATUSES "
            "from obra.api.response_handler instead",
            DeprecationWarning,
            stacklevel=2,
        )
        return _TRANSIENT_HTTP_STATUS_CODES
    if name == "NON_TRANSIENT_HTTP_STATUS_CODES":
        warnings.warn(
            "NON_TRANSIENT_HTTP_STATUS_CODES is deprecated, use "
            "NON_TRANSIENT_HTTP_STATUSES with HTTPStatus values instead",
            DeprecationWarning,
            stacklevel=2,
        )
        return _NON_TRANSIENT_HTTP_STATUS_CODES
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "METRIC_DECOMPOSITION_TRIGGERS",
    "METRIC_ERRORS_CLASSIFIED",
    "NON_TRANSIENT_HTTP_STATUS_CODES",  # noqa: F822 - provided via __getattr__
    "NON_TRANSIENT_HTTP_STATUSES",
    "TRANSIENT_HTTP_STATUS_CODES",  # noqa: F822 - provided via __getattr__
    "TRANSIENT_HTTP_STATUSES",
    "AuthenticationError",
    "BudgetMonitor",
    "BudgetRecord",
    "DecompositionMetricsCollector",
    "DecompositionTriggerMetric",
    "FailureRecord",
    "FailureTracker",
    "ForbiddenError",
    "HTTPTimeoutError",
    "LLMInvocationTimeoutError",
    "NetworkError",
    "NonTransientError",
    "NotFoundError",
    "RateLimitError",
    "ServiceUnavailableError",
    "SubprocessTimeoutError",
    "TaskOutcome",
    "TaskResult",
    "TimeoutError",
    "TransientError",
    "ValidationError",
    "emit_error_classification_metric",
    "get_decomposition_metrics_collector",
    "get_error_classification_metrics_summary",
    "get_retry_after",
    "is_transient",
]
