"""Per-epic derivation orchestration for the derivation pipeline."""

from __future__ import annotations

import logging
import re
import time
from collections.abc import Callable
from pathlib import Path
from typing import Any

from obra.config.llm import resolve_tier_config
from obra.config.loaders import (
    get_derivation_story_range,
    get_derivation_strict_story_range,
    get_derivation_strict_task_range,
    get_derivation_task_range,
)
from obra.exceptions import ObraError
from obra.hybrid.template_edit_pipeline import TemplateEditPipeline
from obra.prompts.derive.derivation import (
    build_step2_per_epic_prompt,
    build_step2_per_epic_template,
    build_step2_repair_prompt,
    build_step2_repair_template,
)

from ._plan_assembler import PlanAssembler

logger = logging.getLogger(__name__)


class EpicDerivationOrchestrator:
    """Own per-epic derivation orchestration: threading, retry branches, heartbeat."""

    def __init__(
        self,
        *,
        epic_limits: Callable[[], tuple[int, int]],
        validator: Any,
        working_dir: Path,
        plan_assembler: PlanAssembler,
    ) -> None:
        self._epic_limits = epic_limits
        self._validator = validator
        self._working_dir = working_dir
        self._plan_assembler = plan_assembler

    def _run_targeted_repair(
        self,
        *,
        objective: str,
        epic_id: str,
        epic_detail_prose: str,
        llm_config: dict[str, str],
    ) -> tuple[str, dict[str, Any]]:
        stories, tasks = self._validator.extract_epic_story_task_titles(
            epic_detail_prose,
            epic_id,
        )
        task_story_ids = {task["id"].split(".T", 1)[0] for task in tasks if task.get("id")}
        missing_story_ids = [story["id"] for story in stories if story.get("id") not in task_story_ids]
        repair_prompt = build_step2_repair_prompt(
            objective=objective,
            target_epic_id=epic_id,
            incomplete_output=epic_detail_prose,
            missing_stories=missing_story_ids
            or [story["id"] for story in stories if story.get("id")],
        )
        repair_template = build_step2_repair_template(
            target_epic_id=epic_id,
            existing_stories=stories,
        )
        repair_pipeline = TemplateEditPipeline(
            working_dir=self._working_dir,
            action_name="derivation_per_epic",
            output_format="text",
        )
        return repair_pipeline.execute(
            base_prompt=repair_prompt,
            template_content=repair_template,
            validator=lambda content, _eid=epic_id: self._validator.validate_epic_prose(
                content,
                _eid,
            ),
            fallback_fn=lambda: "",
            llm_config=llm_config,
        )

    def _run_strict_retry(
        self,
        *,
        objective: str,
        epics_prose: str,
        all_epic_details: list[str],
        epic: dict[str, Any],
        epic_id: str,
        llm_config: dict[str, str],
        intent_markdown: str | None,
        exploration_context: str | None,
        strict_story_range: tuple[int, int],
        strict_task_range: tuple[int, int],
    ) -> tuple[str, dict[str, Any]]:
        retry_prompt = build_step2_per_epic_prompt(
            objective=objective,
            all_epics_prose=epics_prose,
            completed_epic_details=all_epic_details,
            target_epic=epic.get("prose", ""),
            target_epic_id=epic_id,
            intent_markdown=intent_markdown,
            exploration_context=exploration_context,
            story_range=strict_story_range,
            task_range=strict_task_range,
            strict=True,
        )
        strict_template = build_step2_per_epic_template(
            target_epic_id=epic_id,
            story_range=strict_story_range,
            task_range=strict_task_range,
        )
        strict_pipeline = TemplateEditPipeline(
            working_dir=self._working_dir,
            action_name="derivation_per_epic",
            output_format="text",
        )
        return strict_pipeline.execute(
            base_prompt=retry_prompt,
            template_content=strict_template,
            validator=lambda content, _eid=epic_id: self._validator.validate_epic_prose(
                content,
                _eid,
            ),
            fallback_fn=lambda: "",
            llm_config=llm_config,
        )

    def _handle_epic_failure(
        self,
        *,
        epic_id: str,
        epic_detail_prose: str,
        story_count: int,
        task_count: int,
        reason_codes: list[str],
        status: str,
        retry_status: str,
        retry_stage: str,
        retry_meta: dict[str, Any],
    ) -> None:
        preview = re.sub(r"\s+", " ", epic_detail_prose).strip()[:240]
        artifact_path = self._validator.write_epic_failure_artifact(
            Path(self._working_dir),
            epic_id=epic_id,
            story_count=story_count,
            task_count=task_count,
            reason_codes=reason_codes,
            retry_metadata={
                "initial_status": status,
                "retry_status": retry_status,
                "attempt_stage": retry_stage,
                "meta": retry_meta,
            },
            output_preview=preview,
        )
        msg = (
            f"Epic {epic_id} derivation failed "
            f"(stage={retry_stage}, status={retry_status}, stories={story_count}, "
            f"tasks={task_count}, reasons={','.join(reason_codes) or 'unknown'}). "
            f"Preview: {preview or '<empty>'}"
        )
        if artifact_path:
            msg += f". Artifact: {artifact_path}"
        raise ObraError(msg)

    def _emit_epic_completion(
        self,
        *,
        epic_id: str,
        epic_title: str,
        epic_detail_prose: str,
        epic_index: int,
        epic_count: int,
        story_count: int,
        task_count: int,
        progress_callback: Callable[[str, dict[str, Any]], None],
    ) -> None:
        stories, tasks = self._validator.extract_epic_story_task_titles(
            epic_detail_prose,
            epic_id,
        )
        if stories:
            progress_callback(
                "plan_snapshot",
                {
                    "source": "derive",
                    "mode": "partial",
                    "plan_items": self._plan_assembler.build_partial_plan_items(
                        epic_id,
                        epic_title,
                        stories,
                        tasks,
                    ),
                },
            )
        progress_callback(
            "epic_derivation_completed",
            {
                "epic_index": epic_index,
                "epic_count": epic_count,
                "epic_id": epic_id,
                "epic_title": epic_title,
                "stories_derived": story_count,
                "tasks_derived": task_count,
                "outcome": "completed",
                "reason_codes": self._validator.extract_reason_codes_for_epic(
                    epic_detail_prose,
                    epic_id,
                ),
            },
        )

    def derive_per_epic(
        self,
        objective: str,
        epics_prose: str,
        parsed_epics: list[dict[str, Any]],
        provider: str,
        progress_callback: Callable[[str, dict[str, Any]], None] | None = None,
        intent_markdown: str | None = None,
        exploration_context: str | None = None,
    ) -> tuple[str, list[str], int]:
        """Derive stories + tasks per-epic with cumulative global context."""
        import threading

        all_epic_details: list[str] = []
        total_tokens = 0

        item_limit, token_limit = self._epic_limits()

        tier_config = resolve_tier_config("high", role="orchestrator")
        llm_config = {
            "provider": provider,
            "model": tier_config.get("model", ""),
            "reasoning_level": tier_config.get("reasoning_level", "off"),
            "auth": tier_config.get("auth", "oauth"),
        }
        story_range = get_derivation_story_range()
        task_range = get_derivation_task_range()
        strict_story_range = get_derivation_strict_story_range()
        strict_task_range = get_derivation_strict_task_range()

        for i, epic in enumerate(parsed_epics):
            epic_id = epic.get("id", f"E{i + 1}")
            epic_title = epic.get("title", "Untitled")

            if progress_callback:
                progress_callback(
                    "epic_derivation_started",
                    {
                        "epic_index": i + 1,
                        "epic_count": len(parsed_epics),
                        "epic_id": epic_id,
                        "epic_title": epic_title,
                    },
                )

            heartbeat_stop = threading.Event()
            heartbeat_thread: threading.Thread | None = None
            if progress_callback:
                start_ts = time.perf_counter()

                def _heartbeat(
                    _stop: threading.Event = heartbeat_stop,
                    _start: float = start_ts,
                    _idx: int = i,
                    _title: str = epic_title,
                ) -> None:
                    while not _stop.wait(30.0):
                        elapsed = int(time.perf_counter() - _start)
                        progress_callback(
                            "epic_derivation_heartbeat",
                            {
                                "epic_index": _idx + 1,
                                "epic_count": len(parsed_epics),
                                "epic_title": _title,
                                "items_so_far": 0,
                                "elapsed_s": elapsed,
                            },
                        )

                heartbeat_thread = threading.Thread(target=_heartbeat, daemon=True)
                heartbeat_thread.start()

            try:
                prompt = build_step2_per_epic_prompt(
                    objective=objective,
                    all_epics_prose=epics_prose,
                    completed_epic_details=all_epic_details,
                    target_epic=epic.get("prose", ""),
                    target_epic_id=epic_id,
                    intent_markdown=intent_markdown,
                    exploration_context=exploration_context,
                    story_range=story_range,
                    task_range=task_range,
                    strict=False,
                )

                pipeline = TemplateEditPipeline(
                    working_dir=self._working_dir,
                    action_name="derivation_per_epic",
                    output_format="text",
                )
                template_content = build_step2_per_epic_template(
                    target_epic_id=epic_id,
                    story_range=story_range,
                    task_range=task_range,
                )

                epic_detail_prose, meta = pipeline.execute(
                    base_prompt=prompt,
                    template_content=template_content,
                    validator=lambda content, _eid=epic_id: self._validator.validate_epic_prose(
                        content,
                        _eid,
                    ),
                    fallback_fn=lambda: "",
                    llm_config=llm_config,
                )

                status = str(meta.get("status", ""))
                story_count, task_count = self._validator.count_epic_story_task_ids(
                    epic_detail_prose,
                    epic_id,
                )
                item_count = story_count + task_count
                output_tokens = self._validator.estimate_output_tokens(epic_detail_prose)
                reason_codes = self._validator.extract_reason_codes_for_epic(
                    epic_detail_prose,
                    epic_id,
                    status=status,
                    item_count=item_count,
                    output_tokens=output_tokens,
                )
                if progress_callback:
                    progress_callback(
                        "epic_derivation_recovery",
                        {
                            "epic_index": i + 1,
                            "epic_count": len(parsed_epics),
                            "epic_id": epic_id,
                            "attempt_stage": "initial",
                            "status": status,
                            "reason_codes": reason_codes,
                            "stories_derived": story_count,
                            "tasks_derived": task_count,
                            "outcome": "continue",
                            "is_retry": False,
                        },
                    )

                retry_stage = "initial"
                retry_status = status
                retry_meta: dict[str, Any] = {}

                branch_a_repair = story_count > 0 and task_count == 0
                branch_b_strict = story_count == 0 or status in {
                    "template_fallback",
                    "template_error",
                    "validation_failed",
                }
                branch_c_strict = (
                    story_count > 0
                    and task_count > 0
                    and (item_count > item_limit or output_tokens > token_limit)
                )

                if branch_a_repair:
                    retry_stage = "targeted_repair"
                    epic_detail_prose, retry_meta = self._run_targeted_repair(
                        objective=objective,
                        epic_id=epic_id,
                        epic_detail_prose=epic_detail_prose,
                        llm_config=llm_config,
                    )
                    retry_status = str(retry_meta.get("status", ""))
                    story_count, task_count = self._validator.count_epic_story_task_ids(
                        epic_detail_prose,
                        epic_id,
                    )
                    item_count = story_count + task_count
                    output_tokens = self._validator.estimate_output_tokens(epic_detail_prose)
                elif branch_b_strict or branch_c_strict:
                    retry_stage = "strict_retry"
                    epic_detail_prose, retry_meta = self._run_strict_retry(
                        objective=objective,
                        epics_prose=epics_prose,
                        all_epic_details=all_epic_details,
                        epic=epic,
                        epic_id=epic_id,
                        llm_config=llm_config,
                        intent_markdown=intent_markdown,
                        exploration_context=exploration_context,
                        strict_story_range=strict_story_range,
                        strict_task_range=strict_task_range,
                    )
                    retry_status = str(retry_meta.get("status", ""))
                    story_count, task_count = self._validator.count_epic_story_task_ids(
                        epic_detail_prose,
                        epic_id,
                    )
                    item_count = story_count + task_count
                    output_tokens = self._validator.estimate_output_tokens(epic_detail_prose)
                    if item_count > item_limit or output_tokens > token_limit:
                        logger.warning(
                            "Epic %s still oversized after strict retry (%d items, ~%d tokens).",
                            epic_id,
                            item_count,
                            output_tokens,
                        )

                reason_codes = self._validator.extract_reason_codes_for_epic(
                    epic_detail_prose,
                    epic_id,
                    status=retry_status,
                    item_count=item_count,
                    output_tokens=output_tokens,
                )
                failed_recovery = any(
                    code in reason_codes
                    for code in [
                        "template_fallback",
                        "no_stories",
                        "no_tasks",
                        "no_tasks_for_story",
                        "wrong_epic_ids",
                        "orphan_tasks",
                    ]
                )

                if progress_callback:
                    progress_callback(
                        "epic_derivation_recovery",
                        {
                            "epic_index": i + 1,
                            "epic_count": len(parsed_epics),
                            "epic_id": epic_id,
                            "attempt_stage": retry_stage,
                            "status": retry_status,
                            "reason_codes": reason_codes,
                            "stories_derived": story_count,
                            "tasks_derived": task_count,
                            "outcome": "failed" if failed_recovery else "completed",
                            "is_retry": retry_stage != "initial",
                        },
                    )

                if failed_recovery:
                    self._handle_epic_failure(
                        epic_id=epic_id,
                        epic_detail_prose=epic_detail_prose,
                        story_count=story_count,
                        task_count=task_count,
                        reason_codes=reason_codes,
                        status=status,
                        retry_status=retry_status,
                        retry_stage=retry_stage,
                        retry_meta=retry_meta,
                    )

                all_epic_details.append(epic_detail_prose)
                total_tokens += len(prompt) // 4 + len(epic_detail_prose) // 4

                if progress_callback:
                    self._emit_epic_completion(
                        epic_id=epic_id,
                        epic_title=epic_title,
                        epic_detail_prose=epic_detail_prose,
                        epic_index=i + 1,
                        epic_count=len(parsed_epics),
                        story_count=story_count,
                        task_count=task_count,
                        progress_callback=progress_callback,
                    )

            finally:
                if heartbeat_thread:
                    heartbeat_stop.set()
                    heartbeat_thread.join(timeout=5)

        return (
            self._plan_assembler.merge_epic_details(epics_prose, all_epic_details),
            all_epic_details,
            total_tokens,
        )
