"""Intake flow for detecting and routing UserPlan input.

This module provides the intake flow that detects whether input is structured
(valid YAML/JSON with UserPlan fields) or unstructured (plain text intent),
and routes accordingly:

- Structured input: Passes through unchanged as UserPlan
- Unstructured input: Routes to IntentToUserPlanGenerator for first-pass generation

Detection Heuristics:
    - Structured: Valid YAML/JSON with required UserPlan fields (id, steps, source)
    - Unstructured: Plain text without recognizable structure

Storage Integration (S1.T6):
    Generated UserPlans are persisted to server storage BEFORE derivation.
    Storage is performed via a UserPlanStorageProtocol implementation.

Example:
    >>> from obra.execution.intake import UserPlanIntake
    >>> intake = UserPlanIntake(storage=state_manager)
    >>> userplan = await intake.process("Add user authentication with JWT")
    >>> assert userplan.source.generated is True  # Generated from intent
    >>> # UserPlan is now persisted to server storage

Related:
    - obra/execution/intent_to_userplan.py (IntentToUserPlanGenerator)
    - obra/schemas/userplan_schema.py (UserPlan schema)
    - obra/intent/detection.py (input type detection patterns)
    - functions/src/state/cloud_functions_state_manager.py (storage implementation)
"""

import logging
import time
from collections.abc import Callable
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Protocol, runtime_checkable

from obra.execution.intake_parsing import (
    detect_input_type as classify_input_text,
)
from obra.execution.intake_parsing import (
    is_userplan_structure as is_structured_userplan,
)
from obra.execution.intake_parsing import (
    parse_structured_userplan,
    try_parse_structured_input,
)
from obra.execution.userplan_construction import (
    create_userplan_from_plan_context,
)
from obra.execution.userplan_metrics import emit_userplan_source_metric
from obra.execution.userplan_persistence import (
    apply_from_step_mutations,
    build_cache_source_metadata,
    cache_userplan_artifacts,
    log_cache_result,
    persist_userplan_via_api,
    store_userplan_with_storage,
)
from obra.schemas.userplan_schema import (
    UserPlan,
)
from obra.workflow.derivation_contract import DerivationRequestEnvelope

if TYPE_CHECKING:
    from obra.llm.invoker import LLMInvoker


@runtime_checkable
class UserPlanStorageProtocol(Protocol):
    """Protocol for UserPlan storage operations.

    Implementations must provide create_userplan and get_userplan methods.
    The CloudFunctionsStateManager satisfies this protocol.

    Example:
        >>> class MyStorage:
        ...     def create_userplan(self, userplan_id, project_id, source, steps, **kwargs):
        ...         # Store to database
        ...         return {"id": userplan_id, ...}
        ...     def get_userplan(self, plan_id):
        ...         # Retrieve from database
        ...         return {...} or None
    """

    def create_userplan(
        self,
        userplan_id: str,
        project_id: str,
        source: dict[str, Any],
        steps: list[dict[str, Any]],
        session_id: str | None = None,
        status: str = "draft",
        quality_score: float | None = None,
        quality_status: str = "not_assessed",
        work_type: str | None = None,
        context: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Create a new UserPlan in storage."""
        ...

    def get_userplan(self, plan_id: str) -> dict[str, Any] | None:
        """Get a UserPlan by ID from storage."""
        ...


logger = logging.getLogger(__name__)


@dataclass
class IntakeResult:
    """Result from intake processing.

    Attributes:
        userplan: The resulting UserPlan (either passed through or generated)
        was_generated: True if UserPlan was generated from unstructured input
        input_type: Classification of the input ('structured' or 'unstructured')
        raw_input: Original input string
        stored: True if UserPlan was persisted to storage (S1.T6)
        storage_error: Error message if storage failed, None if successful
    """

    userplan: UserPlan
    was_generated: bool
    input_type: str
    raw_input: str
    stored: bool = False
    storage_error: str | None = None


class UserPlanIntake:
    """Intake handler for UserPlan input detection and routing.

    Detects whether input is structured (valid UserPlan YAML/JSON) or
    unstructured (plain text intent), and routes accordingly.

    Storage Integration (S1.T6):
        When a storage instance is provided, generated UserPlans are persisted
        to server storage BEFORE the derivation step. This ensures UserPlans
        exist in storage before any derive calls.

    Example:
        >>> intake = UserPlanIntake(llm_invoker=invoker, storage=state_manager)
        >>> result = await intake.process(
        ...     input_text="Add user authentication",
        ...     project_id="my-project"
        ... )
        >>> if result.was_generated:
        ...     print("Generated from intent")
        >>> if result.stored:
        ...     print(f"UserPlan {result.userplan.id} stored successfully")
        >>> print(result.userplan.steps[0].title)

    Thread-safety:
        Thread-safe through IntentToUserPlanGenerator's thread safety guarantees.
    """

    # Type alias for progress callback function
    # Signature: on_progress(action: str, payload: dict) -> None
    ProgressCallback = Callable[[str, dict], None]

    def __init__(
        self,
        llm_invoker: "LLMInvoker | None" = None,
        thinking_enabled: bool = True,
        reasoning_level: str = "high",
        provider: str = "anthropic",
        storage: UserPlanStorageProtocol | None = None,
        on_progress: "UserPlanIntake.ProgressCallback | None" = None,
        log_event: Any | None = None,
    ) -> None:
        """Initialize UserPlanIntake.

        Args:
            llm_invoker: LLMInvoker instance for LLM calls (required for generation)
            thinking_enabled: Whether to use extended thinking for generation
            reasoning_level: Reasoning level for LLM calls
            provider: LLM provider to use
            storage: Optional storage implementation for persisting UserPlans.
                    When provided, generated UserPlans are stored before derivation.
                    Must implement UserPlanStorageProtocol (e.g., CloudFunctionsStateManager).
            on_progress: Optional callback for progress events (S1.T7 two-step feedback).
                        Receives (action, payload) where action is "phase_started" or
                        "phase_completed" and payload contains phase-specific data.
            log_event: Optional event logger callback for metrics emission.
        """
        self._llm_invoker = llm_invoker
        self._thinking_enabled = thinking_enabled
        self._reasoning_level = reasoning_level
        self._provider = provider
        self._storage = storage
        self._on_progress = on_progress
        self._log_event = log_event

        # Lazy import to avoid circular dependency
        self._generator = None

        logger.debug(
            "UserPlanIntake initialized (storage=%s)",
            "enabled" if storage else "disabled",
        )

    def _emit_progress(self, action: str, payload: dict[str, Any]) -> None:
        """Emit progress event if callback is registered.

        S1.T7: Support two-step generation feedback via progress callback.

        Args:
            action: Event type (e.g., "phase_started", "phase_completed")
            payload: Event-specific data
        """
        if self._on_progress is not None:
            try:
                self._on_progress(action, payload)
            except Exception:
                # Don't let progress callback failures break intake flow
                logger.debug("Progress callback failed", exc_info=True)

    def _get_generator(self):
        """Get or create IntentToUserPlanGenerator instance."""
        if self._generator is None:
            from obra.execution.intent_to_userplan import IntentToUserPlanGenerator

            self._generator = IntentToUserPlanGenerator(
                llm_invoker=self._llm_invoker,
                thinking_enabled=self._thinking_enabled,
                reasoning_level=self._reasoning_level,
                provider=self._provider,
            )
        return self._generator

    async def process(
        self,
        input_text: str,
        project_id: str = "default",
        session_id: str | None = None,
        context: dict[str, Any] | None = None,
    ) -> IntakeResult:
        """Process input and return UserPlan.

        Detects input type and either parses structured UserPlan or generates
        from unstructured intent. Generated UserPlans are persisted to storage
        (if configured) BEFORE returning, ensuring they exist before derivation.

        Storage Flow (S1.T6):
            1. Detect input type (structured vs unstructured)
            2. For unstructured: generate UserPlan via LLM
            3. Persist generated UserPlan to storage (before derivation)
            4. Return IntakeResult with stored=True on success

        Args:
            input_text: Input string (YAML/JSON UserPlan or plain text intent)
            project_id: Project identifier for generated UserPlans
            session_id: Optional session identifier
            context: Optional context dictionary for generation

        Returns:
            IntakeResult with UserPlan and metadata.
            - stored=True if UserPlan was successfully persisted
            - storage_error contains error message if persistence failed

        Raises:
            ValueError: If structured input is invalid UserPlan
        """
        if not input_text or not input_text.strip():
            msg = "Input cannot be empty"
            raise ValueError(msg)

        input_text = input_text.strip()

        # Detect input type
        input_type = classify_input_text(input_text)
        logger.info("Detected input type: %s", input_type)

        if input_type == "structured":
            raw_data = try_parse_structured_input(input_text) or {}
            userplan = parse_structured_userplan(input_text)
            logger.info("Parsed structured UserPlan: %s", userplan.id)

            # Emit source type metric for structured input
            emit_userplan_source_metric(
                source_type=userplan.source.type,
                userplan_id=userplan.id,
                project_id=userplan.project_id,
                is_generated=userplan.source.generated,
                log_event=self._log_event,
            )

            cache_result = cache_userplan_artifacts(
                userplan,
                source_metadata=build_cache_source_metadata(
                    userplan,
                    raw_data=raw_data,
                ),
            )
            log_cache_result(userplan.id, cache_result)

            return IntakeResult(
                userplan=userplan,
                was_generated=False,
                input_type="structured",
                raw_input=input_text,
                stored=False,  # Structured input is not auto-stored
            )

        # Generate UserPlan from unstructured intent
        # S1.T7: Emit USERPLAN_GENERATION phase_started event
        generation_start_time = time.time()
        self._emit_progress("phase_started", {"phase": "USERPLAN_GENERATION"})

        logger.info("Generating UserPlan from unstructured intent")
        generator = self._get_generator()
        userplan = await generator.generate(
            intent=input_text,
            context=context,
            project_id=project_id,
            session_id=session_id,
        )

        # S1.T7: Emit USERPLAN_GENERATION phase_completed event
        generation_duration_ms = int((time.time() - generation_start_time) * 1000)
        # Extract title from metadata (set by IntentToUserPlanGenerator)
        userplan_title = (
            userplan.metadata.get("title", "UserPlan") if userplan.metadata else "UserPlan"
        )
        self._emit_progress(
            "phase_completed",
            {
                "phase": "USERPLAN_GENERATION",
                "result": {"title": userplan_title},
                "duration_ms": generation_duration_ms,
            },
        )

        logger.info(
            "Generated UserPlan: %s with %d steps",
            userplan.id,
            len(userplan.steps),
        )

        # Emit source type metric for generated UserPlan
        emit_userplan_source_metric(
            source_type=userplan.source.type,
            userplan_id=userplan.id,
            project_id=userplan.project_id,
            is_generated=userplan.source.generated,
            log_event=self._log_event,
        )

        cache_result = cache_userplan_artifacts(
            userplan,
            source_metadata=build_cache_source_metadata(userplan),
        )
        log_cache_result(userplan.id, cache_result)

        # S1.T6: Persist generated UserPlan to storage BEFORE derivation
        stored = False
        storage_error: str | None = None

        if self._storage is not None:
            stored, storage_error = self._store_userplan(userplan)

        return IntakeResult(
            userplan=userplan,
            was_generated=True,
            input_type="unstructured",
            raw_input=input_text,
            stored=stored,
            storage_error=storage_error,
        )

    def _store_userplan(self, userplan: UserPlan) -> tuple[bool, str | None]:
        """Persist UserPlan to storage.

        S1.T6: Stores the generated UserPlan to server storage before derivation.

        Args:
            userplan: UserPlan to persist

        Returns:
            Tuple of (success: bool, error_message: str | None)
        """
        return store_userplan_with_storage(self._storage, userplan)


def create_userplan_from_plan_file(
    plan_context: dict[str, Any],
    project_id: str,
    plan_file_path: str | None = None,
    session_id: str | None = None,
    log_event: Any | None = None,
) -> UserPlan:
    """Create a UserPlan from plan file context (epics only).

    This function converts a plan file (YAML/JSON with epics) into a UserPlan
    for the S2.T3 requirement: plan-file import must create UserPlan before derivation.

    The plan file stories are mapped to UserPlan steps, preserving the original
    structure as much as possible for traceability.

    Args:
        plan_context: Dict with "epics" array from plan file
        project_id: Project identifier
        plan_file_path: Optional path to source plan file
        session_id: Optional session identifier
        log_event: Optional event logger callback for metrics emission

    Returns:
        UserPlan object ready for storage

    Raises:
        ValueError: If plan_context is invalid or has no epics

    Example:
        >>> plan_context = {"epics": [{"id": "E1", "title": "Auth", "stories": [...]}]}
        >>> userplan = create_userplan_from_plan_file(plan_context, "my-project")
        >>> userplan.source.type == SourceType.PLAN_FILE
        True
    """
    return create_userplan_from_plan_context(
        plan_context,
        project_id,
        plan_file_path=plan_file_path,
        session_id=session_id,
        log_event=log_event,
    )


class UserPlanFromStepError(ValueError):
    """Raised when --from-step exceeds the number of steps in a UserPlan."""

    def __init__(self, from_step: int, total_steps: int) -> None:
        super().__init__(f"--from-step {from_step} exceeds total steps ({total_steps})")
        self.from_step = from_step
        self.total_steps = total_steps


@dataclass
class UserPlanResult:
    """Result from create_and_persist_userplan().

    Attributes:
        userplan_id: The UserPlan identifier
        userplan: The created UserPlan object
    """

    userplan_id: str
    userplan: UserPlan


def create_and_persist_userplan(
    plan_context: dict[str, Any],
    project_id: str,
    plan_file_path: str | None = None,
    from_step: int | None = None,
    cascade: bool = False,
    verbose: int = 0,
) -> UserPlanResult:
    """Create a UserPlan from plan context, cache locally, and persist to server.

    Consolidates the UserPlan creation workflow: parse plan file → cache →
    serialize → store to server → apply from_step/cascade status updates.

    Args:
        plan_context: Dict with "epics" array from plan file
        project_id: Project identifier
        plan_file_path: Optional path to source plan file for metadata
        from_step: Optional 1-indexed step to re-derive from; marks steps
            [from_step..total] as DERIVING in server storage
        cascade: If True and from_step set, marks steps [from_step+1..total]
            as STALE in server storage
        verbose: Verbosity level; >0 logs cache path

    Returns:
        UserPlanResult with userplan_id and the created UserPlan

    Raises:
        ValueError: If plan_context is invalid or has no epics
        UserPlanFromStepError: If from_step exceeds the number of UserPlan steps
        Exception: API errors are re-raised for the caller to handle
    """
    userplan = create_userplan_from_plan_file(
        plan_context=plan_context,
        project_id=project_id,
        plan_file_path=plan_file_path,
    )
    userplan_id = userplan.id

    cache_result = cache_userplan_artifacts(
        userplan,
        source_metadata=build_cache_source_metadata(
            userplan,
            plan_context=plan_context,
            source_path_override=plan_file_path,
        ),
    )
    log_cache_result(userplan.id, cache_result)
    if cache_result.cache_ok and verbose > 0:
        logger.info("UserPlan cached at %s", cache_result.cache_path)

    from obra.api import APIClient

    userplan_client = APIClient.from_config()
    persist_userplan_via_api(
        userplan,
        client=userplan_client,
        source_path_override=plan_file_path,
    )
    logger.info("Created UserPlan %s from plan file", userplan_id)

    apply_from_step_mutations(
        userplan_client,
        userplan_id=userplan_id,
        total_steps=len(userplan.steps),
        from_step=from_step,
        cascade=cascade,
    )

    return UserPlanResult(userplan_id=userplan_id, userplan=userplan)


def materialize_workflow_derivation_request(
    *,
    objective: str | None,
    domain_id: str | None,
    plan_context: dict[str, Any] | None = None,
    allow_plan_context_domain: bool = True,
) -> dict[str, Any] | None:
    """Build a workflow-derivation request envelope from objective and plan inputs."""
    payload: dict[str, Any] = {}
    if isinstance(plan_context, dict):
        request_value = plan_context.get("workflow_derivation_request")
        if isinstance(request_value, dict):
            payload.update(request_value)
        else:
            supported_keys = {
                "mission",
                "domain_id",
                "input_spec_refs",
                "output_spec_refs",
                "rule_pack_refs",
                "quality_pack_refs",
                "baseline_workflow_ref",
                "example_case_refs",
                "exception_case_refs",
                "policy_precedence_overrides",
                "operator_constraints",
            }
            for key in supported_keys:
                if key in plan_context:
                    payload[key] = plan_context[key]

        if "operator_constraints" not in payload and isinstance(
            plan_context.get("operator_constraints"), dict
        ):
            payload["operator_constraints"] = plan_context["operator_constraints"]

        if "mission" not in payload:
            for mission_key in ("objective", "mission", "title", "name"):
                mission_value = plan_context.get(mission_key)
                if isinstance(mission_value, str) and mission_value.strip():
                    payload["mission"] = mission_value.strip()
                    break

        if allow_plan_context_domain and "domain_id" not in payload:
            raw_domain = plan_context.get("domain_id", plan_context.get("domain"))
            if isinstance(raw_domain, str) and raw_domain.strip():
                payload["domain_id"] = raw_domain.strip()

    if isinstance(objective, str) and objective.strip():
        payload.setdefault("mission", objective.strip())
    if isinstance(domain_id, str) and domain_id.strip():
        payload.setdefault("domain_id", domain_id.strip())

    if not payload:
        return None
    return DerivationRequestEnvelope.from_dict(payload).to_dict()


__all__ = [
    "IntakeResult",
    "UserPlanFromStepError",
    "UserPlanIntake",
    "UserPlanResult",
    "UserPlanStorageProtocol",
    "create_and_persist_userplan",
    "create_userplan_from_plan_file",
    "materialize_workflow_derivation_request",
]
