"""Display type coercion helpers.

Small, well-tested functions that replace inline ``isinstance`` /
``int()`` / ``float()`` coercion patterns throughout the display layer.
"""

from __future__ import annotations

import math
from typing import Any, overload

# -- coerce_int ----------------------------------------------------------------


@overload
def coerce_int(value: Any) -> int: ...


@overload
def coerce_int(value: Any, fallback: int) -> int: ...


@overload
def coerce_int(value: Any, fallback: None) -> int | None: ...


def coerce_int(value: Any, fallback: int | None = 0) -> int | None:
    """Return ``int(value)`` when *value* is numeric, otherwise *fallback*.

    Edge cases that return *fallback*:
    * ``None``
    * Non-numeric strings (``"abc"``)
    * ``float('inf')`` / ``float('-inf')``
    * ``float('nan')``

    Booleans are accepted (``bool`` is a subclass of ``int`` in Python).
    """
    if isinstance(value, (int, float)):
        if isinstance(value, float) and (math.isinf(value) or math.isnan(value)):
            return fallback
        return int(value)
    return fallback


# -- coerce_float --------------------------------------------------------------


@overload
def coerce_float(value: Any) -> float: ...


@overload
def coerce_float(value: Any, fallback: float) -> float: ...


@overload
def coerce_float(value: Any, fallback: None) -> float | None: ...


def coerce_float(value: Any, fallback: float | None = 0.0) -> float | None:
    """Return ``float(value)`` when *value* is numeric, otherwise *fallback*.

    Edge cases that return *fallback*:
    * ``None``
    * Non-numeric strings (``"abc"``)
    * ``float('inf')`` / ``float('-inf')``
    * ``float('nan')``

    Booleans are accepted (``bool`` is a subclass of ``int`` in Python).
    """
    if isinstance(value, (int, float)):
        if isinstance(value, float) and (math.isinf(value) or math.isnan(value)):
            return fallback
        return float(value)
    return fallback


# -- coerce_str ----------------------------------------------------------------


def coerce_str(value: Any, fallback: str | None = None) -> str | None:
    """Return ``str(value)`` when *value* is truthy, otherwise *fallback*."""
    if value:
        return str(value)
    return fallback


__all__ = [
    "coerce_float",
    "coerce_int",
    "coerce_str",
]
