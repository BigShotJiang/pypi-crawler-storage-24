"""Plan tree rendering: console display of hierarchical plan structures."""

from __future__ import annotations

from typing import Any

from rich.console import Console

from obra.display import print_info
from obra.display.charset import glyphs
from obra.execution.plan_tree import aggregate_status, get_root_items, normalize_plan_items

__all__ = ["render_plan_tree", "render_plan_node", "format_status_indicator"]


def render_plan_tree(
    console: Console,
    plan_items: list[dict[str, Any]],
    objective: str,
) -> None:
    """Render a hierarchical DerivedPlan tree with status indicators."""
    normalized, children_map, status_map, order_map = normalize_plan_items(plan_items)
    if not normalized:
        print_info("No DerivedPlan items found for this session")
        return

    roots = get_root_items(normalized, children_map)
    if not roots:
        print_info("No DerivedPlan roots found for this session")
        return

    console.print("[bold]DerivedPlan Tree[/bold]")
    if objective:
        console.print(f"[dim]{objective}[/dim]")
    console.print()

    for root_id in roots:
        render_plan_node(
            console,
            root_id,
            normalized,
            children_map,
            status_map,
            order_map,
            level=0,
        )
    console.print()


def render_plan_node(
    console: Console,
    item_id: str,
    normalized: dict[str, dict[str, Any]],
    children_map: dict[str | None, list[str]],
    status_map: dict[str, str],
    order_map: dict[str, int],
    *,
    level: int,
) -> None:
    item = normalized.get(item_id, {})
    title = item.get("title", "Untitled")
    item_type = item.get("item_type", "task").upper()
    status = aggregate_status(item_id, children_map, status_map)
    status_indicator = format_status_indicator(status)
    indent = "  " * level
    console.print(f"{indent}{status_indicator} {item_id} {item_type}: {title}", style="dim")

    children = sorted(children_map.get(item_id, []), key=lambda cid: order_map.get(cid, 1_000_000))
    for child_id in children:
        render_plan_node(
            console,
            child_id,
            normalized,
            children_map,
            status_map,
            order_map,
            level=level + 1,
        )


def format_status_indicator(status: str) -> str:
    if status == "completed":
        return f"[green]{glyphs.success}[/green]"
    if status == "in_progress":
        return f"[yellow]{glyphs.paused}[/yellow]"
    if status == "failed":
        return f"[red]{glyphs.failure}[/red]"
    if status == "skipped":
        return "[dim]skip[/dim]"
    return "[dim]o[/dim]"
