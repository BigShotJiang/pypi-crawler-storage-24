"""LifecycleEmitter — orchestration lifecycle progress events.

Owns all phase/stage lifecycle events (started, completed, failed, heartbeat),
planning stage events, Story 0 preflight events, and code-verify events.

Shared state read/written via EmitterContext:
    _active_phase_name   (written here, read by _restore_spinner_status_line)
    _active_stage_name   (written here, read by _restore_spinner_status_line)
    _current_stage_context (written by stage_started/completed and DerivationEmitter)
    _plan_mode           (written by DerivationEmitter and PlanTreeEmitter; read here)
    _llm                 (LLMStateManager; written by MiscEmitter; read by stage_heartbeat)
    _derive_step_start_time  (written by DerivationEmitter; read by stage_heartbeat)
    _derive_current_step_name (written by DerivationEmitter; read by stage_heartbeat)
    _review_ctx          (ReviewContextManager; reset on EXECUTION phase start)

Design decision D3: domain composition — no registry, just explicit wiring
in ProgressEmitter.__init__.
"""

import time
from datetime import datetime
from typing import TYPE_CHECKING

from obra.display.charset import glyphs
from obra.display.observability._context import _STAGE_USER_LABELS
from obra.display.observability._emitter import VerbosityLevel

if TYPE_CHECKING:
    from obra.display.observability._context import EmitterContext
    from obra.display.observability._plan_tree import PlanTreeEmitter


class LifecycleEmitter:
    """Emits all orchestration lifecycle progress events.

    Owns phase/stage lifecycle state and heartbeat rate-limiting.  All shared
    infrastructure (print, spinner, pipeline, utilities) is accessed via
    self._ctx.  Cross-domain plan mutation (task tracker render) is accessed
    via self._plan_tree.
    """

    def __init__(self, ctx: "EmitterContext", plan_tree: "PlanTreeEmitter") -> None:
        self._ctx = ctx
        self._plan_tree = plan_tree

        # Heartbeat rate-limiting state
        self._stage_heartbeat_last_emit: dict[str, float] = {}
        self._stage_heartbeat_emit_interval_s: float = 60.0
        self._stage_heartbeat_tty_emit_interval_s: float = 30.0

    # ------------------------------------------------------------------ #
    # Phase lifecycle                                                     #
    # ------------------------------------------------------------------ #

    def phase_started(self, phase: str, context: dict | None = None) -> None:
        """Emit event when an orchestration phase starts.

        Args:
            phase: Phase name (e.g., "USERPLAN_GENERATION", "DERIVATION", "REFINEMENT", "EXECUTION")
            context: Optional context information about the phase
        """
        normalized_phase = str(phase).upper()
        self._ctx._active_phase_name = normalized_phase
        # Level 0 (QUIET): Show minimal phase indicator
        if self._ctx.config.verbosity == VerbosityLevel.QUIET:
            from obra.messages.status import build_phase_announcement

            # Map phase names to announcement keys
            phase_map = {
                "USERPLAN_GENERATION": "userplan",
                "DERIVATION": "derivation",
                "REFINEMENT": "refinement",
                "EXECUTION": "execution",
            }
            phase_key = phase_map.get(normalized_phase)
            phase_label = build_phase_announcement(phase_key) if phase_key else phase
            self._ctx._print(f"{phase_label}...", end="")
            return

        # Level 1+ (PROGRESS and above): Show pipeline banner
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return

        # Preserve the long-standing plain phase line for direct callers and tests,
        # even though the pipeline banner is now the richer primary visualization.
        timestamp = self._ctx._timestamp()
        self._ctx._print(f"{timestamp}Phase: {phase}", style="bold cyan")

        # Map phase to pipeline stage and render banner
        pipeline_stage = self._ctx._pipeline.get_pipeline_stage_from_phase(normalized_phase)
        if pipeline_stage and self._ctx._pipeline_enabled:
            # Only render banner if transitioning to a new stage
            if self._ctx._pipeline.should_render_banner(pipeline_stage):
                self._ctx._print("")  # Blank line before banner
                self._ctx._pipeline.stage_transition(pipeline_stage)
                self._ctx._last_pipeline_stage = pipeline_stage

        if self._ctx.config.verbosity >= VerbosityLevel.DEBUG and context:
            # Truncate verbose context output
            ctx_str = str(context)
            max_chars = 300
            display_ctx = ctx_str if len(ctx_str) <= max_chars else ctx_str[:max_chars] + "..."
            self._ctx._print(f"[DEBUG] Context: {display_ctx}", style="dim")

        if normalized_phase in {
            "USERPLAN_GENERATION",
            "REVIEW",
            "EXECUTION",
            "DERIVATION",
            "REFINEMENT",
        }:
            self._ctx.start_spinner(reason=f"phase:{normalized_phase}")
            if self._ctx._spinner and self._ctx._spinner.is_active:
                status_line = self._ctx._get_phase_status_line(normalized_phase)
                if status_line:
                    self._ctx._spinner.update_status_line(status_line, style="cyan")

        if normalized_phase == "EXECUTION":
            self._ctx._review_ctx.clear()
            # Note: Footer hint removed from here - it was too noisy (showed 17+ times per session)
            # Footer hint now shows only: once at set_session_id(), and in completion footer
            self._plan_tree.render_task_tracker()

    def _emit_phase_quiet(self, phase: str, result: dict | None) -> None:
        """Render quiet-mode phase completion output."""
        if phase == "USERPLAN_GENERATION":
            title = (result or {}).get("title", "UserPlan")
            self._ctx._print(" done")
            self._ctx._print(f"Generated UserPlan: {title}")
            return
        if phase == "DERIVATION":
            task_count = (result or {}).get("item_count", 0)
            self._ctx._print(" done")
            self._ctx._print(f"Derived execution plan with {task_count} tasks")
            return
        if result and "item_count" in result:
            self._ctx._print(f" done ({result['item_count']} items)")
            return
        if result and "issue_count" in result:
            self._ctx._print(f" done ({result['issue_count']} issues)")
            return
        self._ctx._print(" done")

    def _emit_refinement_complete(
        self,
        result: dict | None,
        timestamp: str,
        duration_sec: float,
    ) -> bool:
        """Render the refinement-finalization summary when applicable."""
        if not isinstance(result, dict):
            return False
        cycles = result.get("refinement_cycles", 0)
        ref_duration = result.get("refinement_duration_s", duration_sec)
        if cycles <= 0:
            return False

        plan_summary = ""
        last_plan_summary = self._plan_tree._last_plan_summary
        if last_plan_summary:
            epic_c = last_plan_summary.get("epic", 0)
            story_c = last_plan_summary.get("story", 0)
            task_c = last_plan_summary.get("task", 0)
            plan_summary = f"\n{timestamp}  Final plan: {epic_c} Epics, {story_c} Stories, {task_c} Tasks"
        self._ctx._print(
            f"{timestamp}{glyphs.success} Plan refinement complete ({cycles} cycles, {ref_duration:.0f}s){plan_summary}",
            style="green",
        )
        if (
            self._plan_tree._plan_tree_rendered_once
            and self._plan_tree._plan_items
            and self._ctx._plan_mode != "provisional"
        ):
            self._plan_tree.render_plan_tree(
                reason="Execution plan finalized",
                source="authoritative",
                force=True,
            )
        return True

    def _build_phase_message(
        self,
        phase: str,
        duration_sec: float,
        result: dict | None,
        timestamp: str,
    ) -> str:
        """Build the primary progress-line message for a completed phase."""
        if phase == "USERPLAN_GENERATION":
            title = (result or {}).get("title", "UserPlan")
            return f"{timestamp}Generated UserPlan: {title} ({duration_sec:.1f}s)"
        if result and "item_count" in result:
            item_count = result["item_count"]
            if phase == "DERIVATION":
                return f"{timestamp}Derived execution plan with {item_count} tasks ({duration_sec:.1f}s)"
            if phase == "REFINEMENT":
                issues = result.get("issue_count", 0)
                return f"{timestamp}Found {issues} issues ({duration_sec:.1f}s)"
        return f"{timestamp}Phase {phase} complete ({duration_sec:.1f}s)"

    def _render_phase_detail(self, result: dict | None) -> None:
        """Render detail-level item breakdowns for a phase result."""
        if not result or "items" not in result or self._ctx.config.verbosity <= VerbosityLevel.PROGRESS:
            return
        for item in result["items"]:
            item_id = item.get("id", "?")
            item_title = item.get("title", "untitled")
            depends_on = item.get("depends_on", [])
            if depends_on:
                deps_str = ", ".join(depends_on)
                self._ctx._print(f"  {item_id}: {item_title} (depends: {deps_str})")
            else:
                self._ctx._print(f"  {item_id}: {item_title}")

            description = item.get("description", "")
            acceptance_criteria = item.get("acceptance_criteria", [])
            if description:
                for line in description.split("\n"):
                    if line.strip():
                        self._ctx._print(f"      - {line.strip()}", style="dim")
            elif acceptance_criteria:
                for criterion in acceptance_criteria:
                    self._ctx._print(f"      - {criterion}", style="dim")

    def phase_completed(self, phase: str, result: dict | None = None, duration_ms: int = 0) -> None:
        """Emit event when an orchestration phase completes.

        Args:
            phase: Phase name that completed
            result: Optional result data from the phase
            duration_ms: Phase duration in milliseconds
        """
        # Update pipeline stage completion state
        normalized_phase = str(phase).upper()
        if self._ctx._active_phase_name == normalized_phase:
            self._ctx._active_phase_name = None
        if self._ctx._pipeline_enabled:
            pipeline_stage = self._ctx._pipeline.get_pipeline_stage_from_phase(normalized_phase)
            if pipeline_stage:
                self._ctx._pipeline.mark_stage_complete(pipeline_stage)

        if normalized_phase in {
            "USERPLAN_GENERATION",
            "REVIEW",
            "EXECUTION",
            "DERIVATION",
            "REFINEMENT",
        }:
            self._ctx.stop_spinner(reason=f"phase:{normalized_phase}")
            self._ctx._restore_spinner_status_line()

        # Level 0 (QUIET): Complete the line with result count
        if self._ctx.config.verbosity == VerbosityLevel.QUIET:
            self._emit_phase_quiet(phase, result)
            return

        # Level 1+ (PROGRESS and above): Show with timestamp and duration
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return

        timestamp = self._ctx._timestamp()
        duration_sec = duration_ms / 1000.0

        # Refinement terminal summary
        if normalized_phase == "REFINEMENT" and self._emit_refinement_complete(result, timestamp, duration_sec):
            return

        message = self._build_phase_message(phase, duration_sec, result, timestamp)
        self._ctx._print(message, style="green")

        if result and self._ctx.config.verbosity == VerbosityLevel.PROGRESS and "items" in result:
            for item in result["items"]:
                item_id = item.get("id", "?")
                item_title = item.get("title", "untitled")
                self._ctx._print(f"           {item_id}: {item_title}")

        if self._ctx.config.verbosity >= VerbosityLevel.DETAIL:
            self._render_phase_detail(result)

        if self._ctx.config.verbosity >= VerbosityLevel.DEBUG and result:
            # Truncate verbose result output
            result_str = str(result)
            max_chars = 500
            display_result = (
                result_str if len(result_str) <= max_chars else result_str[:max_chars] + "..."
            )
            self._ctx._print(
                f"[DEBUG] Full result ({len(result_str)} chars): {display_result}",
                style="dim",
            )

    # ------------------------------------------------------------------ #
    # Stage lifecycle                                                     #
    # ------------------------------------------------------------------ #

    def stage_started(self, stage: str, context: dict | None = None) -> None:
        """Emit event when a pipeline stage starts."""
        base_stage = stage.split("_pass_", maxsplit=1)[0]
        if base_stage in {
            "intent_generation",
            "assumptions",
            "analogues",
            "brief",
            "derive",
            "revise",
        }:
            self._ctx._llm.set_state("waiting")
        self._ctx._active_stage_name = stage
        self._ctx._start_stage_spinner(stage)
        if self._ctx._spinner and self._ctx._spinner.is_active:
            status_line = self._ctx._get_stage_status_line(stage)
            if status_line:
                self._ctx._spinner.update_status_line(status_line, style="cyan")
        self._ctx._current_stage_context = context
        if self._ctx.config.verbosity < VerbosityLevel.DETAIL:
            return
        timestamp = self._ctx._timestamp()
        self._ctx._print(f"{timestamp}Stage: {stage}", style="bold cyan")
        if self._ctx.config.verbosity >= VerbosityLevel.DEBUG and context:
            # Truncate verbose context output
            ctx_str = str(context)
            max_chars = 300
            display_ctx = ctx_str if len(ctx_str) <= max_chars else ctx_str[:max_chars] + "..."
            self._ctx._print(f"[DEBUG] Stage context: {display_ctx}", style="dim")

        # Show objective at derive start (DETAIL verbosity)
        if stage == "derive" and context and self._ctx.config.verbosity >= VerbosityLevel.DETAIL:
            objective = context.get("objective", "")
            if objective:
                display_obj = self._ctx._truncate_description(objective)
                self._ctx._print(f'  Deriving: "{display_obj}"', style="cyan")

    def stage_completed(self, stage: str, result: dict | None = None, duration_ms: int = 0) -> None:
        """Emit event when a pipeline stage completes."""
        if self._ctx._active_stage_name == stage:
            self._ctx._active_stage_name = None
        if self._ctx._spinner:
            self._ctx._spinner.clear_status_line()
        self._ctx._llm.set_state("idle")
        self._ctx._stop_stage_spinner(stage)
        self._ctx._restore_spinner_status_line()
        if self._ctx.config.verbosity < VerbosityLevel.DETAIL:
            return
        timestamp = self._ctx._timestamp()
        duration_sec = duration_ms / 1000.0
        message = f"{timestamp}Stage {stage} complete ({duration_sec:.1f}s)"
        self._ctx._print(message, style="green")

        # Show hierarchy summary for derive stage completion (DETAIL only)
        if stage == "derive" and result:
            epic_count = result.get("epic_count", 0)
            story_count = result.get("story_count", 0)
            task_count = result.get("task_count", 0)
            if epic_count or story_count or task_count:
                epic_str = f"{epic_count} Epic" + ("s" if epic_count != 1 else "")
                story_str = f"{story_count} Stor" + ("ies" if story_count != 1 else "y")
                task_str = f"{task_count} Task" + ("s" if task_count != 1 else "")
                self._ctx._print(
                    f"  {glyphs.tree_last} Derived: {epic_str}, {story_str}, {task_str}",
                    style="green",
                )

        if self._ctx.config.verbosity >= VerbosityLevel.DEBUG and result:
            # Truncate verbose result output
            result_str = str(result)
            max_chars = 300
            display_result = (
                result_str if len(result_str) <= max_chars else result_str[:max_chars] + "..."
            )
            self._ctx._print(f"[DEBUG] Stage result: {display_result}", style="dim")
        self._ctx._current_stage_context = None

    def stage_failed(
        self,
        stage: str,
        error: str,
        duration_ms: int = 0,
        timeout_s: int | None = None,
    ) -> None:
        """Emit event when a pipeline stage fails."""
        if self._ctx._active_stage_name == stage:
            self._ctx._active_stage_name = None
        if self._ctx._spinner:
            self._ctx._spinner.clear_status_line()
        self._ctx._llm.set_state("idle")
        self._ctx._stop_stage_spinner(stage)
        self._ctx._restore_spinner_status_line()
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._ctx._timestamp()
        duration_sec = duration_ms / 1000.0
        timeout_note = f" timeout={timeout_s}s" if timeout_s else ""
        self._ctx._print(
            f"{timestamp}Stage {stage} failed ({duration_sec:.1f}s){timeout_note}: {error}",
            style="bold red",
        )

    def stage_heartbeat(self, stage: str, elapsed_s: int) -> None:
        """Emit heartbeat during long-running stage execution.

        For derive stage, shows current derivation progress in the spinner
        (e.g., "derive running... (2m 30s) [S1 tasks...]").
        """
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return

        display_elapsed_s = elapsed_s
        if stage == "derive" and self._ctx._derive_step_start_time is not None:
            # Prefer step-local elapsed time so timer resets at each derive substep.
            display_elapsed_s = max(0, int(time.perf_counter() - self._ctx._derive_step_start_time))

        elapsed_str = self._ctx._format_elapsed(display_elapsed_s)
        timestamp = self._ctx._timestamp()
        base_stage = stage.split("_pass_", maxsplit=1)[0]

        # Build status indicator based on current LLM activity
        status_indicator = ""
        llm_elapsed_suffix = ""
        llm_call_start = self._ctx._llm.get_call_start_time()
        if llm_call_start is not None:
            llm_elapsed_s = int(time.perf_counter() - llm_call_start)
            if llm_elapsed_s > 0:
                llm_elapsed_suffix = f" {llm_elapsed_s}s"
        llm_state = self._ctx._llm.get_state()
        if llm_state == "waiting":
            status_indicator = f" [waiting for LLM{llm_elapsed_suffix}]"
        elif llm_state == "streaming":
            status_indicator = f" [LLM streaming...{llm_elapsed_suffix}]"
        elif llm_state == "processing":
            status_indicator = f" [processing{llm_elapsed_suffix}]"

        message = f"{stage} running... ({elapsed_str})"
        inline_label = _STAGE_USER_LABELS.get(base_stage, base_stage.replace("_", " "))
        if stage == "derive":
            if self._ctx._derive_current_step_name == "serialize":
                message = f"Serializing plan... ({elapsed_str})"
                inline_label = "derive — serializing the execution plan"
            elif self._ctx._derive_current_step_name == "tasks":
                message = f"Detailing plan... ({elapsed_str})"
                inline_label = "derive — detailing the execution plan"
            elif self._ctx._derive_current_step_name == "structure":
                message = f"Structuring plan... ({elapsed_str})"
                inline_label = "derive — structuring the execution plan"
            else:
                message = f"Detailing plan... ({elapsed_str})"
                inline_label = "derive — detailing the execution plan"
        elif stage == "revise":
            message = f"Refining plan... ({elapsed_str})"
            inline_label = "revise — refining the plan"
        else:
            label = _STAGE_USER_LABELS.get(base_stage)
            if label:
                message = f"{label}... ({elapsed_str})"
                inline_label = label

        if self._ctx._current_stage_context and self._ctx._current_stage_context.get("epic_index"):
            epic_index = self._ctx._current_stage_context.get("epic_index")
            epic_count = self._ctx._current_stage_context.get("epic_count")
            epic_title = self._ctx._current_stage_context.get("epic_title")
            if epic_index and epic_count:
                title = epic_title or "Epic"
                title = self._ctx._truncate_title(title)
                message = f"Epic {epic_index}/{epic_count}: {title} deriving... ({elapsed_str})"
                inline_label = f"derive — detailing epic {epic_index}/{epic_count}: {title}"

        if self._ctx._should_inline_heartbeat():
            self._ctx._update_spinner_status(
                inline_label,
                elapsed_s=display_elapsed_s,
                suffix=status_indicator.strip() or None,
            )
            return

        emit_interval_s = (
            self._stage_heartbeat_tty_emit_interval_s
            if self._ctx._is_tty
            else self._stage_heartbeat_emit_interval_s
        )
        now = datetime.now().timestamp()
        last_emit = self._stage_heartbeat_last_emit.get(stage, 0.0)
        if (now - last_emit) < emit_interval_s:
            return
        self._stage_heartbeat_last_emit[stage] = now
        if status_indicator and self._ctx._is_tty:
            status_indicator = f"[dim]{status_indicator}[/dim]"
        if status_indicator:
            message = f"{message}{status_indicator}"
        self._ctx._print(f"{timestamp}{message}", style="cyan")

    # ------------------------------------------------------------------ #
    # Planning lifecycle                                                  #
    # ------------------------------------------------------------------ #

    def planning_started(self, objective: str) -> None:
        """Emit event when planning begins."""
        if self._ctx.config.verbosity == VerbosityLevel.QUIET:
            self._ctx._print("Planning...", end="")
            return
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._ctx._timestamp()
        display_obj = objective.strip()
        if display_obj:
            display_obj = self._ctx._truncate_description(display_obj)
            self._ctx._print(f'{timestamp}Planning "{display_obj}"...', style="bold cyan")
        else:
            self._ctx._print(f"{timestamp}Planning...", style="bold cyan")

    def planning_stage_started(self, stage: str, user_label: str) -> None:
        """Emit event when a planning stage starts (user-facing).

        Also updates pipeline state to track the active substage.
        """
        # Update pipeline substage state
        if self._ctx._pipeline_enabled:
            pipeline_stage = self._ctx._pipeline.get_pipeline_stage(stage)
            if pipeline_stage:
                # Check if we need to render banner for this stage
                # (first substage of a new pipeline stage)
                if self._ctx._pipeline.should_render_banner(pipeline_stage):
                    if self._ctx.config.verbosity >= VerbosityLevel.PROGRESS:
                        self._ctx._print("")  # Blank line before banner
                        self._ctx._pipeline.stage_transition(pipeline_stage, substage=stage)
                        self._ctx._last_pipeline_stage = pipeline_stage
                else:
                    # Subsequent substage within same pipeline stage - update and re-render
                    self._ctx._pipeline.substage_started(stage)
                    if self._ctx.config.verbosity >= VerbosityLevel.PROGRESS:
                        self._ctx._print("")
                        self._ctx._pipeline.render_banner(pipeline_stage, active_substage=stage)

        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return

        # Show inline progress with arrow indicator
        timestamp = self._ctx._timestamp()
        label = user_label.strip() if user_label else self._ctx._get_stage_label(stage)
        self._ctx._print(f"{timestamp}  {glyphs.arrow} {label}...", style="cyan")

    def planning_stage_completed(
        self,
        stage: str,
        user_label: str,
        duration_s: float,
        summary: str | None = None,
    ) -> None:
        """Emit event when a planning stage completes (user-facing).

        Also updates pipeline state to mark the substage as completed.
        """
        # Update pipeline substage state
        if self._ctx._pipeline_enabled:
            self._ctx._pipeline.substage_completed(stage)

        if self._ctx.config.verbosity == VerbosityLevel.QUIET:
            if stage == "review":
                summary_line = ""
                last_plan_summary = self._plan_tree._last_plan_summary
                if last_plan_summary:
                    epic_count = last_plan_summary.get("epic", 0)
                    story_count = last_plan_summary.get("story", 0)
                    task_count = last_plan_summary.get("task", 0)
                    summary_line = (
                        f" ({epic_count} epics, {story_count} stories, {task_count} tasks)"
                    )
                self._ctx._print(f" done{summary_line}")
            return
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._ctx._timestamp()
        label = user_label.strip() if user_label else self._ctx._get_stage_label(stage)
        completion = summary or f"{label} complete"
        # Show inline completion with checkmark (indented to align with started message)
        self._ctx._print(
            f"{timestamp}  {glyphs.success} {completion} ({duration_s:.1f}s)",
            style="green",
        )

    # ------------------------------------------------------------------ #
    # Story 0 preflight                                                   #
    # ------------------------------------------------------------------ #

    def story0_started(self) -> None:
        """Emit event when Story 0 environment preparation starts."""
        if self._ctx.config.verbosity == VerbosityLevel.QUIET:
            self._ctx._print("Preflight...", end="")
            return
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return

        # Render Setup pipeline banner if phase_started() hasn't already rendered it.
        # Since STORY0 is now mapped in PHASE_TO_PIPELINE, phase_started() renders the
        # banner before story0_started() is called — should_render_banner guards the duplicate.
        if self._ctx._pipeline_enabled and self._ctx._pipeline.should_render_banner("Setup"):
            self._ctx._print("")
            self._ctx._pipeline.stage_transition("Setup")

        timestamp = self._ctx._timestamp()
        self._ctx._print(f"{timestamp}Preflight: Environment & Dependencies", style="bold cyan")

    def story0_prerequisite_status(
        self,
        category: str,
        name: str,
        status: str,
        reason: str | None = None,
    ) -> None:
        """Emit progress for a Story 0 prerequisite."""
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return
        symbol_map = {
            "installed": (glyphs.success, "green"),
            "mocked": (glyphs.success, "green"),
            "skipped": (glyphs.success, "green"),
            "failed": (glyphs.failure, "red"),
            "user_input_needed": (glyphs.warning, "yellow"),
        }
        symbol, color = symbol_map.get(status, ("•", "dim"))
        timestamp = self._ctx._timestamp()
        display = f"{category}: {name}".strip()
        if status == "failed" and reason:
            display = f"{name}: {reason}"
        self._ctx._print(f"{timestamp}  {symbol} {display}", style=color)

    def story0_message(self, message: str) -> None:
        """Emit a Story 0 informational message."""
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._ctx._timestamp()
        for line in str(message).splitlines():
            self._ctx._print(f"{timestamp}  • {line}", style="dim")

    def verification_preflight_started(self, message: str) -> None:
        """Emit verification preflight start message."""
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._ctx._timestamp()
        self._ctx._print(f"{timestamp}  • {message}", style="dim")

    def verification_preflight_installing(self, message: str) -> None:
        """Emit verification preflight install message."""
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._ctx._timestamp()
        self._ctx._print(f"{timestamp}  • {message}", style="dim")

    def verification_preflight_completed(self, message: str) -> None:
        """Emit verification preflight completion message."""
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._ctx._timestamp()
        self._ctx._print(f"{timestamp}  {glyphs.success} {message}", style="green")

    def code_verify_started(self, item_id: str | None = None) -> None:
        """Emit start message for CodeVerify stage."""
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._ctx._timestamp()
        item_suffix = f" ({item_id})" if item_id else ""
        self._ctx._print(f"{timestamp}Code verify{item_suffix}: running checks", style="cyan")

    def code_verify_completed(
        self,
        *,
        status: str,
        tools_used: list[str] | None = None,
        pass_count: int = 0,
        fail_count: int = 0,
        inconclusive_count: int = 0,
        item_id: str | None = None,
    ) -> None:
        """Emit completion summary for CodeVerify stage."""
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return

        normalized_status = str(status or "inconclusive").strip().lower()
        if normalized_status not in {"passed", "failed", "inconclusive"}:
            normalized_status = "inconclusive"

        if normalized_status == "passed":
            style = "green"
        elif normalized_status == "failed":
            style = "red"
        else:
            style = "yellow"

        tools = [str(tool).strip() for tool in (tools_used or []) if str(tool).strip()]
        if tools:
            tools_text = ", ".join(tools)
        else:
            tools_text = "none"

        timestamp = self._ctx._timestamp()
        item_suffix = f" ({item_id})" if item_id else ""
        self._ctx._print(
            (
                f"{timestamp}Code verify{item_suffix}: {normalized_status} "
                f"(pass={int(pass_count)}, fail={int(fail_count)}, "
                f"inconclusive={int(inconclusive_count)}; tools={tools_text})"
            ),
            style=style,
        )

    def story0_completed(self, blocking_failures: int, non_blocking_warnings: int) -> None:
        """Emit Story 0 completion summary."""
        # Pipeline state management runs regardless of verbosity (same pattern as phase_completed)
        if self._ctx._pipeline_enabled:
            self._ctx._pipeline.mark_stage_complete("setup")

        if self._ctx.config.verbosity == VerbosityLevel.QUIET:
            if blocking_failures:
                self._ctx._print(" blocked")
            else:
                self._ctx._print(" ready")
            return
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._ctx._timestamp()
        if blocking_failures:
            self._ctx._print(
                f"{timestamp}  {glyphs.failure} Preflight blocked ({blocking_failures} failures)",
                style="red",
            )
            return
        warning_note = f" ({non_blocking_warnings} warnings)" if non_blocking_warnings else ""
        self._ctx._print(
            f"{timestamp}  {glyphs.success} Preflight complete{warning_note}",
            style="green",
        )

    def story0_blocked(self, failures_summary: str) -> None:
        """Emit aggregated Story 0 failure summary (non-TTY)."""
        if not failures_summary:
            return
        self._ctx._print(failures_summary)
