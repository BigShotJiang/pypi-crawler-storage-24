"""Observability infrastructure for Obra CLI operations.

This module provides progressive verbosity levels and progress emission
for CLI commands, allowing users to observe LLM streaming, orchestration
phases, and execution progress in real-time.

Security:
    - NEVER emit user prompts or LLM system prompts (IP protection)
    - NEVER emit API keys, credentials, or secrets
    - LLM responses are safe to show (user-requested observability)
"""

import sys
from dataclasses import dataclass
from enum import IntEnum
from typing import Any

from rich.console import Console

from obra.core.interrupts import interrupt_requested as _interrupt_requested_direct


def _interrupt_requested() -> bool:
    """Look up interrupt_requested via the observability package namespace."""
    obs = sys.modules.get("obra.display.observability")
    if obs is not None:
        fn = getattr(obs, "interrupt_requested", None)
        if fn is not None:
            return fn()
    return _interrupt_requested_direct()


class VerbosityLevel(IntEnum):
    """Progressive verbosity levels for CLI output."""

    QUIET = 0
    PROGRESS = 1
    DETAIL = 2
    DEBUG = 3


_STAGE_USER_LABELS: dict[str, str] = {
    "intent_generation": "intent_generation — elaborating your request",
    "assumptions": "assumptions — resolving missing details",
    "analogues": "analogues — scanning similar solutions",
    "brief": "brief — consolidating intent into a planning brief",
    "derive": "derive — detailing the execution plan",
    "revise": "revise — refining the plan",
    "intent_alignment": "intent_alignment — checking intent coverage",
    "review": "review — running review agents",
    "execute": "execute — implementing plan items",
    "validator": "validator — validating review output",
}

_PHASE_STATUS_LINES: dict[str, str] = {
    "USERPLAN_GENERATION": "plan — generating the user plan",
    "DERIVATION": "derive — detailing the execution plan",
    "REFINEMENT": "revise — refining the plan",
    "REVIEW": "review — preparing review agents",
    "EXECUTION": "execute — implementing plan items",
}

_RUNTIME_VERBOSITY: int = VerbosityLevel.PROGRESS


def set_runtime_verbosity(verbosity: int) -> None:
    """Update global verbosity hint for modules that lack direct config."""
    global _RUNTIME_VERBOSITY
    _RUNTIME_VERBOSITY = int(verbosity)


def get_runtime_verbosity() -> int:
    """Return global verbosity hint for modules that lack direct config."""
    return _RUNTIME_VERBOSITY


@dataclass
class ObservabilityConfig:
    """Configuration for CLI observability features."""

    verbosity: int = VerbosityLevel.PROGRESS
    stream: bool = False
    timestamps: bool = True
    dashboard_enabled: bool = True
    footer_hint_enabled: bool = True
    task_tracker_enabled: bool = True
    task_tracker_max_next: int = 3


def _names(raw: str) -> tuple[str, ...]:
    return tuple(name for name in raw.split() if name)


_CTX_ATTRS = _names(
    """
    _is_tty _spinner _spinner_active_reasons _spinner_lock _spinner_rotation_paused
    _stage_spinner_active _pipeline _pipeline_enabled _last_pipeline_stage
    _dashboard_enabled _footer_hint_enabled _task_tracker_enabled _task_tracker_max_next
    _title_max_chars _description_max_chars _note_max_chars _seconds_before_minutes
    _llm _review_ctx _current_stage_context _plan_mode
    _derive_step_start_time _derive_current_step_name _active_stage_name
    _active_phase_name
    """
)
_PLAN_TREE_ATTRS = _names(
    """
    _plan_items _plan_index _plan_children _plan_status
    _plan_order _last_plan_summary
    _plan_tree_rendered_once _plan_source _session_id _last_footer_hint_s
    """
)
_REVIEW_ATTRS = _names(
    """
    _review_attempt _review_max_attempts _review_agents _review_agent_count
    _review_parallel _review_retry_pending _last_completion_data _lock
    """
)
_EXECUTION_ATTRS = _names("_files_created _files_modified _heartbeat_count _counters")

_ATTR_OWNERS = {name: "_ctx" for name in _CTX_ATTRS}
_ATTR_OWNERS.update({name: "_plan_tree" for name in _PLAN_TREE_ATTRS})
_ATTR_OWNERS.update({name: "_review" for name in _REVIEW_ATTRS})
_ATTR_OWNERS.update({name: "_execution" for name in _EXECUTION_ATTRS})

_WRITABLE_ATTRS = frozenset(
    _names(
        """
        _is_tty _spinner_rotation_paused _pipeline_enabled _last_pipeline_stage
        _current_stage_context _plan_mode
        _derive_step_start_time _derive_current_step_name _active_stage_name
        _active_phase_name
        _plan_items _plan_index _plan_children _plan_status
        _plan_order _last_plan_summary
        _plan_tree_rendered_once _plan_source _session_id _last_footer_hint_s
        _review_attempt _review_max_attempts _review_agents _review_agent_count
        _review_parallel _review_retry_pending _last_completion_data _files_created
        _files_modified _heartbeat_count _counters
        """
    )
)

_CTX_METHODS = _names(
    """
    _truncate_title _truncate_description _truncate_note _get_stage_label
    _get_phase_status_line _get_stage_status_line _restore_spinner_status_line
    _dashboard_feature_enabled _timestamp _format_status_line start_spinner stop_spinner
    halt_spinner _start_stage_spinner _stop_stage_spinner _should_inline_heartbeat
    use_inline_heartbeat _format_elapsed
    """
)
_PLAN_TREE_METHODS = _names(
    """
    update_plan_snapshot _render_partial_plan_snapshot item_skipped render_plan_tree
    _render_plan_node _sort_plan_ids _normalize_status _format_status_label
    _aggregate_status _infer_item_type _summarize_plan_changes
    set_session_id restore_pipeline_checkmarks set_plan_items _is_executable_item_type
    set_total_tasks _current_task_label render_footer_hint render_task_tracker
    get_progress_summary advance_task_index get_milestone_summary is_plan_locked
    get_plan_version
    """
)
_REVIEW_METHODS = _names(
    """
    reset_review_state set_review_context review_loop_started review_agent_started
    review_agent_completed review_indeterminate scorecard_available scorecard_warning
    session_completed review_fix_progress stabilization_auto_accept escalation_summary
    story_review_started story_review_completed story_review_batch_started
    review_issues_found review_no_fixes fix_started fix_completed review_filter_applied
    """
)
_DERIVATION_METHODS = _names(
    """
    reset_derive_step_state epic_derivation_heartbeat debug_tokens debug_quality
    intent_alignment_started intent_story_batch_started intent_story_assessed
    intent_story_added intent_alignment_completed intent_alignment_fixes_applied
    intent_gap_detection_started intent_gap_detection_completed derivation_step_started
    epic_derivation_started epic_derivation_completed epic_serialization_batch_started
    epic_serialization_completed derivation_step_completed derivation_step_failed
    derivation_stall_warning derivation_streaming_heartbeat derivation_validation_started
    derivation_validation_completed
    """
)
_EXECUTION_METHODS = _names(
    """
    increment get_counter track_file_created track_file_modified get_file_summary
    item_started item_completed item_heartbeat file_event render_file_list
    """
)
_LIFECYCLE_METHODS = _names(
    """
    phase_started phase_completed stage_started stage_completed planning_started
    planning_stage_started planning_stage_completed story0_started
    story0_prerequisite_status story0_message verification_preflight_started
    verification_preflight_installing verification_preflight_completed code_verify_started
    code_verify_completed story0_completed story0_blocked stage_failed stage_heartbeat
    """
)
_MISC_METHODS = _names(
    """
    llm_started llm_streaming llm_completed parallel_batch_started examine_batch_progress
    parallel_batch_completed parallel_batch_fallback refinement_scope_summary error warning
    decomposition_warning decomposition_triggered interactive_guard_notice
    """
)
_VALIDATOR_METHODS = _names(
    "validator_started validator_completed validator_skipped validator_error"
)

_DOMAIN_DISPATCH = {name: "_ctx" for name in _CTX_METHODS}
_DOMAIN_DISPATCH.update({name: "_plan_tree" for name in _PLAN_TREE_METHODS})
_DOMAIN_DISPATCH.update({name: "_review" for name in _REVIEW_METHODS})
_DOMAIN_DISPATCH.update({name: "_derivation" for name in _DERIVATION_METHODS})
_DOMAIN_DISPATCH.update({name: "_execution" for name in _EXECUTION_METHODS})
_DOMAIN_DISPATCH.update({name: "_lifecycle" for name in _LIFECYCLE_METHODS})
_DOMAIN_DISPATCH.update({name: "_misc" for name in _MISC_METHODS})
_DOMAIN_DISPATCH.update({name: "_validators" for name in _VALIDATOR_METHODS})


class ProgressEmitter:
    """Thin progress facade that delegates to context and domain emitters."""

    def __init__(self, config: ObservabilityConfig | None, console: Console) -> None:
        from obra.display.charset import reset_detection
        from obra.display.observability._context import EmitterContext
        from obra.display.observability._derivation import DerivationEmitter
        from obra.display.observability._execution import ExecutionItemEmitter
        from obra.display.observability._lifecycle import LifecycleEmitter
        from obra.display.observability._misc import MiscEmitter
        from obra.display.observability._plan_tree import PlanTreeEmitter
        from obra.display.observability._review import ReviewEmitter
        from obra.display.observability._validators import ValidatorEmitter

        reset_detection()
        resolved_config = config or ObservabilityConfig()
        stdout_is_tty = hasattr(sys.stdout, "isatty") and sys.stdout.isatty()
        console_is_terminal = False
        try:
            console_value = getattr(console, "is_terminal", False)
            if isinstance(console_value, bool):
                console_is_terminal = console_value
        except Exception:
            console_is_terminal = False
        is_tty = bool(stdout_is_tty or console_is_terminal)

        object.__setattr__(self, "_ctx", EmitterContext(resolved_config, console, is_tty))
        object.__setattr__(self, "_review", ReviewEmitter(self._ctx))
        object.__setattr__(self, "_validators", ValidatorEmitter(self._ctx))
        object.__setattr__(self, "_derivation", DerivationEmitter(self._ctx))
        object.__setattr__(self, "_plan_tree", PlanTreeEmitter(self._ctx))
        object.__setattr__(self, "_execution", ExecutionItemEmitter(self._ctx, self._plan_tree))
        object.__setattr__(self, "_lifecycle", LifecycleEmitter(self._ctx, self._plan_tree))
        object.__setattr__(self, "_misc", MiscEmitter(self._ctx))

    @property
    def config(self) -> ObservabilityConfig:
        return self._ctx.config

    @config.setter
    def config(self, value: ObservabilityConfig) -> None:
        self._ctx.config = value

    @property
    def console(self) -> Console:
        return self._ctx.console

    @console.setter
    def console(self, value: Console) -> None:
        self._ctx.console = value

    def __getattr__(self, name: str) -> Any:
        owner_name = _ATTR_OWNERS.get(name) or _DOMAIN_DISPATCH.get(name)
        if owner_name is None:
            raise AttributeError(f"'{type(self).__name__}' has no attribute '{name}'")
        owner = object.__getattribute__(self, owner_name)
        return getattr(owner, name)

    def __setattr__(self, name: str, value: Any) -> None:
        if name in _WRITABLE_ATTRS:
            owner_name = _ATTR_OWNERS[name]
            owner = object.__getattribute__(self, owner_name)
            setattr(owner, name, value)
            return
        object.__setattr__(self, name, value)

    def set_llm_state(self, state: str) -> None:
        """Set the current LLM state with validation."""
        self._ctx._llm.set_state(state)

    def get_llm_state(self) -> str:
        """Return the current LLM state."""
        return self._ctx._llm.get_state()

    def _print(self, message: str, style: str | None = None, end: str = "\n") -> None:
        """Print through the shared context so spinner routing remains intact."""
        self._ctx._print(message, style=style, end=end)
