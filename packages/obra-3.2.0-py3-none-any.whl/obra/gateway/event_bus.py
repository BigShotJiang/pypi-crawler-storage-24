"""Per-session event bus bridging synchronous orchestrator callbacks to async consumers."""

from __future__ import annotations

import asyncio
import logging
import threading
import uuid
from collections import deque
from collections.abc import Callable
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, AsyncIterator

if TYPE_CHECKING:
    pass

from obra.api.protocol import EscalationDecision, EscalationNotice, UserDecisionChoice

logger = logging.getLogger(__name__)


class SessionEventBus:
    """Bridges sync HybridOrchestrator callbacks to async transport consumers.

    Thread-safe for producers (push_event, push_escalation called from orchestrator thread).
    Async for consumers (consume() used by SSE/WebSocket handlers).

    Args:
        session_id: Unique session identifier.
        escalation_timeout_s: Max seconds to wait for escalation decision before auto-resolving.
        max_queue_size: Maximum buffered event count before oldest events are dropped.
    """

    def __init__(
        self,
        session_id: str,
        escalation_timeout_s: float = 300.0,
        max_queue_size: int = 1000,
        *,
        initial_history: list[dict[str, Any]] | None = None,
        next_sequence: int = 0,
        raw_event_observer: Callable[[dict[str, Any]], None] | None = None,
    ) -> None:
        self.session_id = session_id
        self._escalation_timeout_s = escalation_timeout_s
        self._max_queue_size = max_queue_size
        self._event_history: deque[dict[str, Any]] = deque(maxlen=max_queue_size)
        self._subscribers: dict[
            str,
            tuple[asyncio.AbstractEventLoop, asyncio.Queue[dict[str, Any] | None], set[str] | None],
        ] = {}
        self._history_lock = threading.Lock()
        self._next_sequence = max(int(next_sequence), 0)
        self._escalation_notice = threading.Event()
        self._escalation_data: EscalationDecision | None = None
        self._escalation_pending = False
        self._closed = False
        self._raw_event_observer = raw_event_observer
        if initial_history:
            for event in initial_history:
                if isinstance(event, dict):
                    self._event_history.append(dict(event))

    def push_event(self, event_type: str, payload: dict[str, Any]) -> None:
        """Push an event onto the queue. Thread-safe (called from orchestrator thread)."""
        if self._closed:
            return
        with self._history_lock:
            sequence = self._next_sequence
            self._next_sequence += 1
            event = {
                "event_id": f"{self.session_id}:{sequence}",
                "event_type": event_type,
                "payload": payload,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
                "sequence": sequence,
                "session_id": self.session_id,
            }
            self._event_history.append(event)
            subscribers = list(self._subscribers.values())

        for loop, queue, filter_types in subscribers:
            if filter_types and event_type not in filter_types:
                continue
            try:
                loop.call_soon_threadsafe(
                    self._queue_event_for_subscriber,
                    queue,
                    event,
                )
            except RuntimeError:
                logger.debug(
                    "Dropping event for closed subscriber loop on session %s",
                    self.session_id,
                )
        if self._raw_event_observer is not None:
            try:
                self._raw_event_observer(dict(event))
            except Exception:
                logger.exception("Webhook observer failed for session %s", self.session_id)

    def latest_sequence(self) -> int:
        """Return the latest emitted sequence number, or -1 when empty."""
        with self._history_lock:
            return self._next_sequence - 1

    def snapshot(
        self,
        *,
        filter_types: set[str] | None = None,
        after_sequence: int | None = None,
    ) -> list[dict[str, Any]]:
        """Return a point-in-time snapshot of retained events."""
        with self._history_lock:
            events = list(self._event_history)

        if after_sequence is not None:
            events = [event for event in events if int(event.get("sequence", -1)) > after_sequence]
        if filter_types:
            events = [event for event in events if event.get("event_type") in filter_types]
        return events

    def _queue_event_for_subscriber(
        self,
        queue: asyncio.Queue[dict[str, Any] | None],
        event: dict[str, Any],
    ) -> None:
        try:
            queue.put_nowait(event)
            return
        except asyncio.QueueFull:
            logger.warning(
                "Event queue full for session %s subscriber, dropping oldest event",
                self.session_id,
            )
        try:
            queue.get_nowait()
        except asyncio.QueueEmpty:
            pass
        try:
            queue.put_nowait(event)
        except asyncio.QueueFull:
            pass

    async def subscribe(
        self,
        *,
        filter_types: set[str] | None = None,
        after_sequence: int | None = None,
    ) -> AsyncIterator[dict[str, Any]]:
        """Yield a dedicated event stream for one subscriber."""
        loop = asyncio.get_running_loop()
        queue: asyncio.Queue[dict[str, Any] | None] = asyncio.Queue(maxsize=self._max_queue_size)
        subscriber_id = uuid.uuid4().hex
        backlog = self.snapshot(filter_types=filter_types, after_sequence=after_sequence)

        with self._history_lock:
            self._subscribers[subscriber_id] = (loop, queue, filter_types)
            closed = self._closed

        for event in backlog:
            self._queue_event_for_subscriber(queue, event)
        if closed:
            self._queue_event_for_subscriber(queue, None)

        try:
            while True:
                event = await queue.get()
                if event is None:
                    break
                yield event
        finally:
            with self._history_lock:
                self._subscribers.pop(subscriber_id, None)

    def push_escalation(self, notice: EscalationNotice) -> EscalationDecision:
        """Push escalation notice and block until client resolves or timeout.

        Called from the orchestrator thread (synchronous, blocking).

        Returns:
            EscalationDecision from client, or FORCE_COMPLETE on timeout.
        """
        # Reset state for this escalation
        self._escalation_notice.clear()
        self._escalation_data = None
        self._escalation_pending = True

        # Push escalation event for consumers
        self.push_event(
            "escalation_notice",
            {
                "escalation_id": notice.escalation_id,
                "reason": notice.reason.value
                if hasattr(notice.reason, "value")
                else str(notice.reason),
                "reason_text": notice.reason_text,
                "options": notice.options,
                "blocking_issues": notice.blocking_issues,
            },
        )

        # Block until resolved or timeout
        resolved = self._escalation_notice.wait(timeout=self._escalation_timeout_s)
        self._escalation_pending = False

        if not resolved or self._escalation_data is None:
            return EscalationDecision(
                choice=UserDecisionChoice.FORCE_COMPLETE,
                was_timeout=True,
            )

        return self._escalation_data

    def resolve_escalation(self, decision: EscalationDecision) -> bool:
        """Resolve a pending escalation with the given decision.

        Called from transport layer when client submits a decision.

        Returns:
            True if escalation was pending and resolved, False otherwise.
        """
        if not self._escalation_pending:
            return False

        self._escalation_data = decision
        self._escalation_notice.set()
        return True

    async def consume(self) -> AsyncIterator[dict[str, Any]]:
        """Backward-compatible consumer API with dedicated subscriber semantics."""
        async for event in self.subscribe():
            yield event

    def close(self) -> None:
        """Close the bus. Puts sentinel to unblock consumers."""
        self._closed = True
        # Unblock any pending escalation
        if self._escalation_pending:
            self._escalation_notice.set()
        with self._history_lock:
            subscribers = list(self._subscribers.values())
        for loop, queue, _filter_types in subscribers:
            try:
                loop.call_soon_threadsafe(self._queue_event_for_subscriber, queue, None)
            except RuntimeError:
                continue
