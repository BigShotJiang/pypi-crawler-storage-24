"""Structured gateway API errors."""

from __future__ import annotations

from fastapi import Request
from fastapi.responses import JSONResponse

from obra.exceptions import APIError


class GatewayAPIError(Exception):
    """Exception carrying the public gateway API error envelope."""

    def __init__(
        self,
        *,
        error_code: str,
        message: str,
        status_code: int,
        hint: str | None = None,
    ) -> None:
        super().__init__(message)
        self.error_code = error_code
        self.message = message
        self.status_code = status_code
        self.hint = hint

    @classmethod
    def from_api_error(
        cls,
        exc: APIError,
        *,
        default_error_code: str,
        default_message: str | None = None,
        hint: str | None = None,
    ) -> "GatewayAPIError":
        """Normalize an upstream APIError into the gateway envelope."""
        return cls(
            error_code=str(exc.error_code or default_error_code),
            message=default_message or str(exc),
            status_code=int(exc.status_code or 502),
            hint=hint or exc.recovery or None,
        )


async def gateway_error_handler(
    request: Request,
    exc: GatewayAPIError,
) -> JSONResponse:
    """Render GatewayAPIError as the canonical JSON envelope."""
    del request
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error_code": exc.error_code,
            "message": exc.message,
            "hint": exc.hint,
        },
    )
