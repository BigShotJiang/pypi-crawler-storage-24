"""Workflow metadata mutation handlers for the studio assistant."""

from __future__ import annotations

import copy
from typing import Any

from obra.gateway.assistant.action_broker import HandlerContext
from obra.gateway.assistant.proposal_records import build_proposal_record

_ALLOWED_METADATA_FIELDS = {
    "title",
    "description",
    "domain_id",
    "summary",
    "quality_dimensions",
    "lifecycle_capabilities",
}


def _normalize_updates(updates: dict[str, Any]) -> dict[str, Any]:
    """Return the explicit metadata updates the assistant is allowed to change."""
    return {
        str(key): value
        for key, value in updates.items()
        if str(key).strip() in _ALLOWED_METADATA_FIELDS
    }


def apply_metadata_updates_to_candidate(
    candidate: dict[str, Any], updates: dict[str, Any]
) -> dict[str, Any]:
    """Apply canonical workflow-definition metadata updates in place."""
    normalized_updates = _normalize_updates(updates)
    if not normalized_updates:
        raise ValueError("At least one workflow metadata update is required.")

    workflow_definition = candidate.setdefault("workflow_definition", {})
    if not isinstance(workflow_definition, dict):
        raise ValueError("Workflow definition is missing.")

    for key, value in normalized_updates.items():
        workflow_definition[key] = value
        if key in {"title", "description", "domain_id"}:
            candidate[key] = value
    return normalized_updates


def _build_metadata_preview(
    workflow: dict[str, Any], updates: dict[str, Any]
) -> tuple[dict[str, Any], dict[str, Any]]:
    workflow_definition = workflow.get("workflow_definition", {})
    workflow_definition = workflow_definition if isinstance(workflow_definition, dict) else {}
    before_metadata = {key: workflow_definition.get(key) for key in updates}
    after_metadata = dict(before_metadata)
    after_metadata.update(updates)
    return before_metadata, after_metadata


def propose_update(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Propose updating canonical workflow metadata fields."""
    wf_id = workflow_id or inputs.get("workflow_id", "")
    updates = inputs.get("updates")
    normalized_updates = _normalize_updates(updates) if isinstance(updates, dict) else {}

    workflow = ctx.repository.get_workflow(wf_id)
    if workflow is None:
        return {"outcome": "invalid", "detail": f"Workflow not found: {wf_id}"}
    if not normalized_updates:
        return {
            "outcome": "invalid",
            "detail": "At least one workflow metadata update is required.",
        }

    before_metadata, after_metadata = _build_metadata_preview(workflow, normalized_updates)
    return build_proposal_record(
        action_id="execute_workflow_metadata_update",
        action_type="propose_workflow_metadata_update",
        action_inputs={
            "workflow_id": wf_id,
            "updates": normalized_updates,
            "expected_revision_id": inputs.get("expected_revision_id", ""),
        },
        preview_type="diff",
        outcome="proposal",
        workflow_id=wf_id,
        updates=normalized_updates,
        changed_fields=sorted(normalized_updates),
        before_metadata=before_metadata,
        after_metadata=after_metadata,
    )


def execute_update(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Apply canonical workflow metadata updates."""
    wf_id = workflow_id or inputs.get("workflow_id", "")
    updates = inputs.get("updates")
    expected_revision_id = str(inputs.get("expected_revision_id") or "")

    workflow = ctx.repository.get_workflow(wf_id)
    if workflow is None:
        return {"outcome": "invalid", "detail": f"Workflow not found: {wf_id}"}

    candidate = copy.deepcopy(workflow)
    try:
        apply_metadata_updates_to_candidate(candidate, updates if isinstance(updates, dict) else {})
    except ValueError as exc:
        return {"outcome": "invalid", "detail": str(exc)}

    result = ctx.action_service.apply_workflow(
        wf_id,
        candidate,
        expected_revision_id=expected_revision_id,
    )
    outcome = result.get("outcome", "")
    if outcome == "conflict":
        return {
            "outcome": "conflict",
            "conflict_summary": result.get("conflict_summary", {}),
            "workflow_id": wf_id,
        }
    if outcome == "invalid":
        return {
            "outcome": "invalid",
            "validation_summary": result.get("validation_summary", {}),
            "workflow_id": wf_id,
        }
    return {
        "outcome": "applied",
        "resulting_revision_ref": result.get("resulting_revision_ref"),
        "workflow_id": wf_id,
    }
