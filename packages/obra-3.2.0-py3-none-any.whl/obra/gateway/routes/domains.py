"""Gateway domain discovery routes."""

from __future__ import annotations

from fastapi import APIRouter, Request

from obra.gateway.pagination import paginate_collection, pagination_params_from_request
from obra.domains.loader import get_available_domains, load_domain

router = APIRouter(prefix="/api/domains", tags=["discovery"])


@router.get("/")
async def list_domains(request: Request) -> dict[str, object]:
    """Return available orchestration domains."""
    domains = []
    for domain_name in get_available_domains():
        domain = load_domain(domain_name)
        domains.append(
            {
                "name": domain.name,
                "display_name": domain.display_name,
                "description": domain.description,
                "example_objectives": list(domain.example_objectives),
                "requires_git": domain.requires_git,
                "default_sandbox_policy": domain.default_sandbox_policy,
            }
        )
    return paginate_collection(
        collection_key="domains",
        items=domains,
        params=pagination_params_from_request(request),
    )
