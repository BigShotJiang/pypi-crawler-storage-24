"""Canonical Workflow Studio runner lookup routes."""

from __future__ import annotations

import dataclasses
from typing import Any

from fastapi import APIRouter, HTTPException, Request, status

from obra.gateway.errors import GatewayAPIError
from obra.gateway.pagination import paginate_collection, pagination_params_from_request
from obra.gateway.workflow_studio.repository import WorkflowStudioRepository
from obra.workflow.runner_config_schemas import (
    CommandRunnerConfig,
    HttpRunnerConfig,
    PythonRunnerConfig,
)

router = APIRouter(prefix="/api/runners", tags=["workflow-studio"])


@router.get("/")
async def list_runners(request: Request) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    return paginate_collection(
        collection_key="runners",
        items=repository.list_runners(),
        params=pagination_params_from_request(request),
    )


@router.get("/kinds")
async def list_runner_kinds(request: Request) -> dict[str, object]:
    kinds = [
            {
                "kind": "command",
                "display_name": "Command",
                "config_schema_summary": "Shell command execution with args, env, cwd, and output capture.",
            },
            {
                "kind": "http",
                "display_name": "HTTP",
                "config_schema_summary": "HTTP request execution with method, url, headers, retries, and capture settings.",
            },
            {
                "kind": "python",
                "display_name": "Python",
                "config_schema_summary": "Python callable execution with kwargs and timeout settings.",
            },
        ]
    return paginate_collection(
        collection_key="kinds",
        items=kinds,
        params=pagination_params_from_request(request),
    )


@router.get("/kinds/{runner_kind}/config-schema")
async def get_runner_config_schema(
    runner_kind: str,
    request: Request,
) -> dict[str, Any]:
    del request
    config_classes = {
        "command": CommandRunnerConfig,
        "http": HttpRunnerConfig,
        "python": PythonRunnerConfig,
    }
    config_class = config_classes.get(runner_kind)
    if config_class is None:
        raise GatewayAPIError(
            error_code="unknown_runner_kind",
            message=f"Unknown runner kind: {runner_kind}",
            hint="Valid kinds: command, http, python",
            status_code=404,
        )

    fields_payload = []
    example_config: dict[str, Any] = {}
    for field in dataclasses.fields(config_class):
        has_default = field.default is not dataclasses.MISSING
        has_default_factory = field.default_factory is not dataclasses.MISSING
        default_value: Any = None
        if has_default:
            default_value = field.default
        elif has_default_factory:
            default_value = field.default_factory()
        fields_payload.append(
            {
                "name": field.name,
                "type": str(field.type),
                "default": default_value,
                "required": not has_default and not has_default_factory,
                "constraints": str(dict(field.metadata)) if field.metadata else None,
            }
        )
        example_config[field.name] = default_value

    return {
        "runner_kind": runner_kind,
        "fields": fields_payload,
        "example_config": example_config,
    }


@router.get("/{runner_id}")
async def get_runner(
    runner_id: str,
    request: Request,
    runner_version: str | None = None,
    runner_selector: str | None = None,
) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    runner = repository.get_runner(
        runner_id,
        runner_version=runner_version,
        runner_selector=runner_selector,
    )
    if runner is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Runner not found")
    return {"runner": runner}


@router.post("/compatibility-check")
async def check_runner_compatibility(
    payload: dict[str, Any],
    request: Request,
) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    return repository.check_runner_compatibility(payload)
