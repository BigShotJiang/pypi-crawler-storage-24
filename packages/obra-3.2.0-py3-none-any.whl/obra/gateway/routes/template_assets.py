"""Canonical Workflow Studio template-asset routes."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request, status

from obra.gateway.pagination import paginate_collection, pagination_params_from_request
from obra.gateway.workflow_studio.repository import WorkflowStudioRepository

router = APIRouter(prefix="/api/template-assets", tags=["workflow-studio"])


@router.get("/")
async def list_template_assets(request: Request) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    return paginate_collection(
        collection_key="template_assets",
        items=repository.list_template_assets(),
        params=pagination_params_from_request(request),
    )


@router.get("/{asset_id:path}/revisions")
async def list_template_asset_revisions(
    asset_id: str,
    request: Request,
) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    revisions = repository.list_template_asset_revisions(asset_id)
    if revisions is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Template asset not found"
        )
    return paginate_collection(
        collection_key="revisions",
        items=revisions,
        params=pagination_params_from_request(request),
        extra={"asset_id": asset_id},
    )


@router.get("/{asset_id:path}/bindings")
async def list_template_asset_bindings(
    asset_id: str,
    request: Request,
) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    bindings = repository.list_template_asset_bindings(asset_id)
    if bindings is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Template asset not found"
        )
    return paginate_collection(
        collection_key="bindings",
        items=bindings,
        params=pagination_params_from_request(request),
        extra={"asset_id": asset_id},
    )


@router.get("/{asset_id:path}")
async def get_template_asset(asset_id: str, request: Request) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    asset = repository.get_template_asset(asset_id)
    if asset is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Template asset not found"
        )
    return {"template_asset": asset}
