"""Webhook signature helpers."""

from __future__ import annotations

import hashlib
import hmac


def sign_payload(payload_bytes: bytes, secret: str) -> str:
    """Return the HMAC-SHA256 signature for one webhook payload."""
    digest = hmac.new(secret.encode("utf-8"), payload_bytes, hashlib.sha256).hexdigest()
    return f"sha256={digest}"


def verify_signature(payload_bytes: bytes, secret: str, signature: str) -> bool:
    """Verify a webhook HMAC-SHA256 signature in constant time."""
    expected = sign_payload(payload_bytes, secret)
    return hmac.compare_digest(expected, signature)
