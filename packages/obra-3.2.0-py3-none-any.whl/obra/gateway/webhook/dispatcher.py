"""Canonical webhook dispatcher."""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable
from typing import Any

from obra.gateway.webhook.delivery import WebhookDeliveryService
from obra.gateway.webhook.model import DeliveryRecord, WebhookRegistration, WebhookStatus
from obra.gateway.webhook.store import WebhookStore

TERMINAL_EVENTS = {
    "workflow_run.completed",
    "workflow_run.failed",
    "workflow_run.cancelled",
    "workflow_derivation.completed",
    "workflow_derivation.failed",
}


class WebhookDispatcher:
    """Match canonical events to webhook registrations and track outcomes."""

    def __init__(
        self,
        *,
        store: WebhookStore,
        delivery_service: WebhookDeliveryService,
        failure_threshold_failing: int,
        failure_threshold_disabled: int,
        cleanup_service: Any | None = None,
    ) -> None:
        self._store = store
        self._delivery_service = delivery_service
        self._failure_threshold_failing = failure_threshold_failing
        self._failure_threshold_disabled = failure_threshold_disabled
        self.cleanup_service = cleanup_service
        self._task_spawner: Callable[[Awaitable[None]], asyncio.Task[None]] | None = None

    def set_task_spawner(
        self,
        task_spawner: Callable[[Awaitable[None]], asyncio.Task[None]] | None,
    ) -> None:
        """Install a task spawner used to track background delivery tasks."""
        self._task_spawner = task_spawner

    async def dispatch(
        self,
        event_name: str,
        envelope: dict[str, Any],
        resource_type: str,
        resource_id: str,
    ) -> None:
        """Dispatch one canonical event to matching webhooks."""
        registrations = self._store.list_for_resource(resource_type, resource_id)
        for registration in registrations:
            if event_name not in registration.events:
                continue
            self._spawn_task(self._deliver_and_track(registration, envelope))
        if event_name in TERMINAL_EVENTS and self.cleanup_service is not None:
            self.cleanup_service.expire_for_resource(resource_type, resource_id)

    def _spawn_task(self, delivery_coro: Awaitable[None]) -> asyncio.Task[None]:
        if self._task_spawner is not None:
            return self._task_spawner(delivery_coro)
        return asyncio.create_task(delivery_coro)

    async def _deliver_and_track(
        self,
        registration: WebhookRegistration,
        envelope: dict[str, Any],
    ) -> None:
        delivery = await self._delivery_service.deliver_with_retry(registration, envelope)
        current = self._store.get(registration.webhook_id) or registration
        self._record_delivery_result(current, delivery)
        self._store.update(current)

    def _record_delivery_result(
        self,
        registration: WebhookRegistration,
        delivery: DeliveryRecord,
    ) -> None:
        registration.delivery_history.append(delivery)
        registration.delivery_history = registration.delivery_history[-10:]
        registration.last_delivery_at = delivery.timestamp
        if delivery.success:
            registration.consecutive_failures = 0
            registration.last_failure_reason = None
            if registration.status is WebhookStatus.FAILING:
                registration.status = WebhookStatus.ACTIVE
            return

        if registration.status is WebhookStatus.EXPIRED:
            return
        registration.consecutive_failures += 1
        registration.last_failure_reason = delivery.error
        if registration.consecutive_failures >= self._failure_threshold_disabled:
            registration.status = WebhookStatus.DISABLED
            return
        if (
            registration.consecutive_failures >= self._failure_threshold_failing
            and registration.status is WebhookStatus.ACTIVE
        ):
            registration.status = WebhookStatus.FAILING
