"""Webhook expiry and retention cleanup."""

from __future__ import annotations

from datetime import datetime, timezone

from obra.gateway.webhook.model import WebhookStatus
from obra.gateway.webhook.store import WebhookStore


def _parse_timestamp(raw_value: str | None) -> datetime | None:
    if not raw_value:
        return None
    normalized = raw_value.replace("Z", "+00:00")
    return datetime.fromisoformat(normalized)


class WebhookCleanupService:
    """Expire and delete webhook registrations after retention."""

    def __init__(self, store: WebhookStore, retention_seconds: int) -> None:
        self._store = store
        self._retention_seconds = retention_seconds

    def expire_for_resource(self, resource_type: str, resource_id: str) -> int:
        """Mark active and failing webhooks for a resource as expired."""
        expired_at = datetime.now(tz=timezone.utc).isoformat()
        registrations = self._store.list_for_resource(resource_type, resource_id)
        for registration in registrations:
            registration.status = WebhookStatus.EXPIRED
            registration.expired_at = expired_at
            self._store.update(registration)
        return len(registrations)

    async def cleanup_expired(self, now: datetime | None = None) -> int:
        """Delete expired registrations once their retention window has elapsed."""
        current_time = now or datetime.now(tz=timezone.utc)
        deleted = 0
        for registration in self._store.list_all(include_expired=True):
            if registration.status is not WebhookStatus.EXPIRED:
                continue
            expired_at = _parse_timestamp(registration.expired_at)
            if expired_at is None:
                continue
            if (current_time - expired_at).total_seconds() > self._retention_seconds:
                if self._store.delete(registration.webhook_id):
                    deleted += 1
        return deleted
