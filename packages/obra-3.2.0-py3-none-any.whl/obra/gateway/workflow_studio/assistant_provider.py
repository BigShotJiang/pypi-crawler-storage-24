"""Gateway-owned assistant provider bootstrap and model catalog helpers.

Uses Obra's canonical CLI subprocess pipeline (invoke_llm_via_cli) for LLM
invocation.  This ensures the gateway assistant respects OAuth authentication,
provider portability (claude/codex/gemini), and consistent auth handling
rather than requiring raw API keys.
"""

from __future__ import annotations

import asyncio
import logging
import shutil
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from obra.config.loaders import get_gateway_assistant_config, get_llm_call_timeout
from obra.config.providers import check_provider_status
from obra.model_registry import MODEL_REGISTRY, get_model_info, resolve_alias, validate_model

logger = logging.getLogger(__name__)

# Stable temp directory for text-mode CLI invocations (no file writes).
_CLI_CWD: Path | None = None


def _get_cli_cwd() -> Path:
    """Return a stable working directory for CLI subprocess invocations."""
    global _CLI_CWD
    if _CLI_CWD is None or not _CLI_CWD.exists():
        _CLI_CWD = Path(tempfile.mkdtemp(prefix="obra-gateway-assistant-"))
    return _CLI_CWD


@dataclass(frozen=True)
class AssistantProviderState:
    """Resolved assistant provider bootstrap state."""

    provider_name: str
    configured_model_id: str
    default_model_id: str
    timeout_s: float
    available: bool
    auth_method: str = "oauth"
    unavailable_reason: str | None = None


@dataclass(frozen=True)
class AssistantModelHealthCache:
    """Cached assistant model catalog with TTL."""

    models: list[dict[str, Any]]
    expires_at: float


def _compose_cli_prompt(system_prompt: str, user_message: str) -> str:
    """Compose a single prompt string for the CLI (no separate system prompt flag)."""
    return f"{system_prompt}\n\n---\n\nUser message:\n{user_message}"


class AssistantGatewayProvider:
    """Adapter using Obra's CLI subprocess pipeline for assistant turns."""

    def __init__(
        self,
        *,
        provider_name: str,
        default_model_id: str,
        timeout_s: float,
        auth_method: str = "oauth",
    ) -> None:
        self._provider_name = provider_name
        self._default_model_id = default_model_id
        self._timeout_s = timeout_s
        self._auth_method = auth_method

    @property
    def provider_name(self) -> str:
        """Configured provider name."""
        return self._provider_name

    @property
    def default_model_id(self) -> str:
        """Canonical default model id."""
        return self._default_model_id

    @property
    def timeout_s(self) -> float:
        """Configured assistant timeout in seconds."""
        return self._timeout_s

    async def generate_text(
        self,
        *,
        system_prompt: str,
        user_message: str,
        model_id: str | None = None,
    ) -> str:
        """Generate a normal assistant text response via CLI."""
        return await self._invoke(
            system_prompt=system_prompt,
            user_message=user_message,
            model_id=model_id,
            response_format="text",
        )

    async def generate_guided_contract(
        self,
        *,
        system_prompt: str,
        user_message: str,
        model_id: str | None = None,
    ) -> str:
        """Generate a guided-turn planning contract (JSON) via CLI."""
        return await self._invoke(
            system_prompt=system_prompt,
            user_message=user_message,
            model_id=model_id,
            response_format="json",
        )

    async def _invoke(
        self,
        *,
        system_prompt: str,
        user_message: str,
        model_id: str | None,
        response_format: str,
    ) -> str:
        from obra.llm.cli_runner import invoke_llm_via_cli

        effective_model = model_id or self._default_model_id
        prompt = _compose_cli_prompt(system_prompt, user_message)
        try:
            return await asyncio.wait_for(
                asyncio.to_thread(
                    invoke_llm_via_cli,
                    prompt=prompt,
                    cwd=_get_cli_cwd(),
                    provider=self._provider_name,
                    model=effective_model,
                    reasoning_level="off",
                    auth_method=self._auth_method,
                    timeout_s=int(self._timeout_s),
                    mode="text",
                    response_format=response_format,
                    retry_enabled=True,
                    call_site="gateway_assistant",
                ),
                timeout=self._timeout_s + 5,  # Slightly longer than CLI timeout
            )
        except TimeoutError as exc:
            raise RuntimeError(
                f"assistant LLM call timed out after {self._timeout_s:.0f}s"
            ) from exc


def bootstrap_assistant_provider() -> tuple[
    AssistantProviderState, AssistantGatewayProvider | None
]:
    """Resolve the configured assistant provider and bootstrap its adapter.

    Uses CLI availability (is the provider CLI installed?) instead of SDK
    availability (is the API key set?).  This matches Obra's canonical
    invocation pattern where OAuth is the default auth method.
    """
    assistant_config = get_gateway_assistant_config()
    provider_name = str(assistant_config.get("model_default_provider") or "").strip()
    configured_model_id = str(assistant_config.get("model_default_model") or "").strip()
    timeout_s = float(get_llm_call_timeout())
    auth_method = str(assistant_config.get("auth_method") or "oauth").strip()

    if not provider_name:
        return (
            AssistantProviderState(
                provider_name="",
                configured_model_id=configured_model_id,
                default_model_id=configured_model_id,
                timeout_s=timeout_s,
                auth_method=auth_method,
                available=False,
                unavailable_reason="assistant provider is not configured",
            ),
            None,
        )

    validation = validate_model(provider_name, configured_model_id)
    if not validation.valid:
        return (
            AssistantProviderState(
                provider_name=provider_name,
                configured_model_id=configured_model_id,
                default_model_id=configured_model_id,
                timeout_s=timeout_s,
                auth_method=auth_method,
                available=False,
                unavailable_reason=validation.error or "assistant default model is invalid",
            ),
            None,
        )

    default_model_id = resolve_alias(provider_name, configured_model_id)

    # Check CLI availability instead of SDK/API-key availability.
    cli_status = check_provider_status(provider_name)
    if not cli_status.installed:
        return (
            AssistantProviderState(
                provider_name=provider_name,
                configured_model_id=configured_model_id,
                default_model_id=default_model_id,
                timeout_s=timeout_s,
                auth_method=auth_method,
                available=False,
                unavailable_reason=(
                    f"{provider_name} CLI ({cli_status.cli_command}) is not installed. "
                    f"{cli_status.install_hint}"
                ),
            ),
            None,
        )

    return (
        AssistantProviderState(
            provider_name=provider_name,
            configured_model_id=configured_model_id,
            default_model_id=default_model_id,
            timeout_s=timeout_s,
            auth_method=auth_method,
            available=True,
        ),
        AssistantGatewayProvider(
            provider_name=provider_name,
            default_model_id=default_model_id,
            timeout_s=timeout_s,
            auth_method=auth_method,
        ),
    )


def configure_assistant_runtime(
    app_state: Any, *, warm_model_cache: bool = False
) -> AssistantProviderState:
    """Install assistant bootstrap state onto FastAPI app state."""
    state, provider = bootstrap_assistant_provider()
    app_state.assistant_llm_provider_state = state
    app_state.assistant_llm_provider = provider
    app_state.assistant_model_health_cache = None

    if state.available:
        logger.info(
            "Assistant provider ready: %s (model=%s, auth=%s, cli)",
            state.provider_name,
            state.default_model_id,
            state.auth_method,
        )
    else:
        logger.warning(
            "Assistant provider unavailable: %s",
            state.unavailable_reason,
        )

    assistant_config = get_gateway_assistant_config()
    if warm_model_cache and assistant_config.get("model_health_check_on_startup", True):
        ttl_s = int(assistant_config.get("model_health_check_cache_ttl_s", 300))
        app_state.assistant_model_health_cache = AssistantModelHealthCache(
            models=build_assistant_model_catalog(state),
            expires_at=time.time() + ttl_s,
        )
    return state


def ensure_assistant_runtime(app_state: Any) -> AssistantProviderState:
    """Bootstrap assistant runtime lazily when startup has not run yet."""
    state = getattr(app_state, "assistant_llm_provider_state", None)
    if state is None:
        return configure_assistant_runtime(app_state)
    return state


def build_assistant_model_catalog(state: AssistantProviderState) -> list[dict[str, Any]]:
    """Build the assistant model list across all installed providers.

    The configured default provider's models appear first with the
    synthetic ``"default"`` entry.  Models from other installed providers
    are appended so the operator can switch providers within the Studio
    assistant without reconfiguring the gateway.
    """
    models: list[dict[str, Any]] = []

    # Default entry for the configured provider
    if state.provider_name and MODEL_REGISTRY.get(state.provider_name) is not None:
        default_status = "available" if state.available else "unavailable"
        default_info = get_model_info(
            state.provider_name, state.default_model_id, resolve_aliases=False
        )
        default_display = (
            default_info.display_name if default_info is not None else state.default_model_id
        )
        models.append(
            {
                "model_id": "default",
                "full_model_id": state.default_model_id,
                "provider": state.provider_name,
                "display_name": f"Default ({default_display})",
                "status": default_status,
            }
        )

    # Build a set of providers to include: configured first, then others
    provider_order: list[str] = []
    if state.provider_name and state.provider_name in MODEL_REGISTRY:
        provider_order.append(state.provider_name)
    for provider_name in sorted(MODEL_REGISTRY):
        if provider_name not in provider_order:
            provider_order.append(provider_name)

    for provider_name in provider_order:
        provider_config = MODEL_REGISTRY.get(provider_name)
        if provider_config is None:
            continue

        # Determine availability: configured provider uses bootstrap state,
        # others use a lightweight CLI-installed check.
        if provider_name == state.provider_name:
            provider_available = state.available
        else:
            cli_status = check_provider_status(provider_name)
            provider_available = cli_status.installed

        status = "available" if provider_available else "unavailable"

        emitted_canonical_ids: set[str] = set()
        for model_id, model_info in provider_config.models.items():
            if not model_info.is_usable:
                continue
            canonical_id = resolve_alias(provider_name, model_id)
            if canonical_id in emitted_canonical_ids:
                continue
            emitted_canonical_ids.add(canonical_id)

            canonical_info = (
                get_model_info(
                    provider_name,
                    canonical_id,
                    resolve_aliases=False,
                )
                or model_info
            )
            models.append(
                {
                    "model_id": canonical_id,
                    "full_model_id": canonical_id,
                    "provider": provider_name,
                    "display_name": canonical_info.display_name,
                    "status": status,
                }
            )

    return models


def get_cached_model_catalog(app_state: Any) -> list[dict[str, Any]] | None:
    """Return cached models when the TTL has not expired."""
    cache = getattr(app_state, "assistant_model_health_cache", None)
    if not isinstance(cache, AssistantModelHealthCache):
        return None
    if cache.expires_at <= time.time():
        return None
    return cache.models


def cache_model_catalog(app_state: Any, models: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Cache the assistant model catalog using configured TTL."""
    assistant_config = get_gateway_assistant_config()
    ttl_s = int(assistant_config.get("model_health_check_cache_ttl_s", 300))
    app_state.assistant_model_health_cache = AssistantModelHealthCache(
        models=models,
        expires_at=time.time() + ttl_s,
    )
    return models
