"""Normalized output-review evidence assembly for assistant turns."""

from __future__ import annotations

from typing import Any

from obra.gateway.workflow_studio.artifacts import resolve_artifact_content
from obra.gateway.workflow_studio.data_access import (
    WorkflowStudioRunBundle,
    workflow_identity_from_sources,
)

_MAX_REPLAY_ENTRIES = 8
_CONTENT_PREVIEW_CHARS = 800


def _classify_bundle_artifacts(
    bundle: WorkflowStudioRunBundle,
    selected_artifact_id: str,
    artifact_content: str | None,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, Any] | None]:
    intermediate_outputs: list[dict[str, Any]] = []
    final_outputs: list[dict[str, Any]] = []
    selected_output: dict[str, Any] | None = None
    stage_lookup = _stage_lookup(bundle)
    stage_positions = _stage_positions(bundle)

    for artifact in bundle.workflow_artifacts:
        artifact_id = str(artifact.get("artifact_id") or "").strip()
        if not artifact_id:
            continue
        runtime_metadata = (
            artifact.get("runtime_metadata")
            if isinstance(artifact.get("runtime_metadata"), dict)
            else {}
        )
        stage_name = str(runtime_metadata.get("stage_name") or "").strip()
        stage_ref = stage_lookup.get(stage_name, {})
        content_text = (
            artifact_content
            if artifact_id == selected_artifact_id and artifact_content is not None
            else resolve_artifact_content(bundle, artifact_id)
        )
        evidence_entry = {
            "artifact_id": artifact_id,
            "artifact_type": str(artifact.get("artifact_type") or "").strip(),
            "title": str(artifact.get("title") or artifact_id),
            "lifecycle": str(artifact.get("lifecycle") or "").strip(),
            "stage_name": stage_name or None,
            "stage_id": str(stage_ref.get("stage_id") or "").strip() or None,
            "stage_title": str(stage_ref.get("stage_title") or stage_name or artifact_id),
            "stage_position": stage_positions.get(stage_name),
            "selected": artifact_id == selected_artifact_id,
            "content_text": content_text,
            "content_preview": _content_preview(content_text),
        }
        if evidence_entry["selected"]:
            selected_output = evidence_entry
        artifact_type = evidence_entry["artifact_type"]
        if artifact_type == "stage_output":
            intermediate_outputs.append(evidence_entry)
        elif artifact_type == "workflow_execution":
            final_outputs.append(evidence_entry)

    intermediate_outputs.sort(
        key=lambda item: (
            item.get("stage_position") if item.get("stage_position") is not None else 999,
            str(item.get("artifact_id") or ""),
        )
    )
    final_outputs.sort(key=lambda item: str(item.get("artifact_id") or ""))
    return intermediate_outputs, final_outputs, selected_output


def _build_direct_artifact_evidence(
    selected_artifact: dict[str, Any],
    artifact_content: str | None,
) -> dict[str, Any]:
    runtime_metadata = (
        selected_artifact.get("runtime_metadata")
        if isinstance(selected_artifact.get("runtime_metadata"), dict)
        else {}
    )
    artifact_id = str(selected_artifact.get("artifact_id") or "").strip()
    return {
        "artifact_id": artifact_id or None,
        "artifact_type": str(selected_artifact.get("artifact_type") or "").strip(),
        "title": str(selected_artifact.get("title") or artifact_id or "Selected artifact"),
        "lifecycle": str(selected_artifact.get("lifecycle") or "").strip(),
        "stage_name": str(runtime_metadata.get("stage_name") or "").strip() or None,
        "stage_id": None,
        "stage_title": str(runtime_metadata.get("stage_name") or artifact_id or "Selected artifact"),
        "stage_position": None,
        "selected": True,
        "content_text": artifact_content,
        "content_preview": _content_preview(artifact_content),
    }


def _resolve_review_workflow_ref(
    bundle: WorkflowStudioRunBundle | None,
    selected_run: dict[str, Any] | None,
) -> dict[str, Any]:
    if bundle is not None:
        return workflow_identity_from_sources(bundle.record, bundle.remote_session)
    return _workflow_ref_from_run(selected_run)


def build_output_review_context(
    *,
    bundle: WorkflowStudioRunBundle | None,
    selected_run: dict[str, Any] | None,
    selected_artifact: dict[str, Any] | None,
    artifact_content: str | None,
    run_replay: dict[str, Any] | None,
) -> dict[str, Any] | None:
    """Return a normalized evidence bundle for run or artifact output review."""
    if bundle is None and selected_run is None and selected_artifact is None:
        return None

    route = "artifact" if selected_artifact is not None else "run"
    selected_artifact_id = (
        str(selected_artifact.get("artifact_id") or "").strip()
        if isinstance(selected_artifact, dict)
        else ""
    )
    intermediate_outputs: list[dict[str, Any]] = []
    final_outputs: list[dict[str, Any]] = []
    selected_output: dict[str, Any] | None = None
    evidence_sources: list[str] = []

    if selected_artifact is not None:
        evidence_sources.append("selected_artifact")
    if artifact_content:
        evidence_sources.append("artifact_content")
    if bundle is not None:
        evidence_sources.append("run_bundle.workflow_artifacts")
        intermediate_outputs, final_outputs, selected_output = _classify_bundle_artifacts(
            bundle,
            selected_artifact_id,
            artifact_content,
        )

    if selected_output is None and isinstance(selected_artifact, dict):
        selected_output = _build_direct_artifact_evidence(selected_artifact, artifact_content)

    if selected_output is None:
        selected_output = (
            final_outputs[-1]
            if final_outputs
            else intermediate_outputs[-1]
            if intermediate_outputs
            else None
        )

    replay_entries = _replay_entries(run_replay)
    if replay_entries:
        evidence_sources.append("run_replay")

    run_id = _run_id(selected_run) or _bundle_run_id(bundle)
    workflow_ref = _resolve_review_workflow_ref(bundle, selected_run)

    return {
        "route": route,
        "run_id": run_id,
        "run_status": str((selected_run or {}).get("status") or ""),
        "workflow_ref": workflow_ref,
        "selected_output": selected_output,
        "selected_artifact_id": selected_artifact_id or None,
        "intermediate_outputs": intermediate_outputs,
        "final_outputs": final_outputs,
        "replay_entries": replay_entries,
        "evidence_sources": evidence_sources,
    }


def _stage_lookup(bundle: WorkflowStudioRunBundle) -> dict[str, dict[str, str]]:
    lookup: dict[str, dict[str, str]] = {}
    for stage in bundle.pipeline_stages:
        stage_name = str(stage.get("stage_name") or stage.get("trigger") or "").strip()
        if not stage_name:
            continue
        stage_id = ""
        for binding in stage.get("resolved_stage_asset_bindings") or []:
            if not isinstance(binding, dict):
                continue
            stage_id = str(binding.get("stage_id") or "").strip()
            if stage_id:
                break
        lookup[stage_name] = {
            "stage_id": stage_id,
            "stage_title": stage_name,
        }
    return lookup


def _stage_positions(bundle: WorkflowStudioRunBundle) -> dict[str, int]:
    positions: dict[str, int] = {}
    for index, stage in enumerate(bundle.pipeline_stages):
        stage_name = str(stage.get("stage_name") or stage.get("trigger") or "").strip()
        if stage_name and stage_name not in positions:
            positions[stage_name] = index
    return positions


def _replay_entries(run_replay: dict[str, Any] | None) -> list[dict[str, Any]]:
    entries = (run_replay or {}).get("entries") or []
    if not isinstance(entries, list):
        return []
    normalized: list[dict[str, Any]] = []
    for entry in entries[-_MAX_REPLAY_ENTRIES:]:
        if not isinstance(entry, dict):
            continue
        normalized.append(
            {
                "event_name": str(entry.get("event_name") or entry.get("event_type") or "event"),
                "timestamp": entry.get("timestamp"),
                "payload": dict(entry.get("payload") or {})
                if isinstance(entry.get("payload"), dict)
                else entry.get("payload"),
            }
        )
    return normalized


def _content_preview(content_text: str | None) -> str | None:
    text = str(content_text or "").strip()
    if not text:
        return None
    return text[:_CONTENT_PREVIEW_CHARS]


def _run_id(selected_run: dict[str, Any] | None) -> str | None:
    if not isinstance(selected_run, dict):
        return None
    run_id = str(selected_run.get("workflow_run_id") or selected_run.get("run_id") or "").strip()
    return run_id or None


def _bundle_run_id(bundle: WorkflowStudioRunBundle | None) -> str | None:
    if bundle is None:
        return None
    return str(bundle.record.workflow_run_id or bundle.record.session_id or "").strip() or None


def _workflow_ref_from_run(selected_run: dict[str, Any] | None) -> dict[str, Any]:
    if not isinstance(selected_run, dict):
        return {}
    workflow_ref = (
        selected_run.get("workflow_ref")
        if isinstance(selected_run.get("workflow_ref"), dict)
        else {}
    )
    if workflow_ref:
        return dict(workflow_ref)
    return {
        "workflow_id": selected_run.get("workflow_id"),
        "revision_id": selected_run.get("revision_id"),
        "domain_id": selected_run.get("domain_id"),
    }
