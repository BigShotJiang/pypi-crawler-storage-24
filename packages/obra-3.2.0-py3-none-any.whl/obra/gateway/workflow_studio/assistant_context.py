"""Context assembler for assistant conversation turns."""

from __future__ import annotations

import logging
from typing import Any

from pydantic import BaseModel

from obra.gateway.workflow_studio.output_review_context import build_output_review_context
from obra.gateway.workflow_studio.repository import WorkflowStudioRepository
from obra.gateway.workflow_studio.starter_catalog import (
    normalize_starter_domain_id,
    resolve_domain_starters,
)

logger = logging.getLogger(__name__)


def _resolve_business_tier_defaults(
    *,
    domain_id: str | None,
    workflow: dict[str, Any] | None,
) -> dict[str, Any]:
    """Return configured business tier defaults for prompt guidance."""
    normalized_domain_id = normalize_starter_domain_id(domain_id)
    if not normalized_domain_id and isinstance(workflow, dict):
        normalized_domain_id = normalize_starter_domain_id(
            str(workflow.get("domain_id") or workflow.get("domain") or "")
        )
    if normalized_domain_id != "business":
        return {}

    try:
        from obra_business.config.loader import get_config_value, load_config

        config = load_config()
        return {
            "business_execution_tier": get_config_value(config, "business.llm.execution_tier"),
            "business_stage_type_tiers": dict(
                get_config_value(config, "business.llm.stage_type_tiers")
            ),
        }
    except Exception as exc:
        logger.warning("Failed to resolve business tier defaults for assistant context: %s", exc)
        return {}


class UIState(BaseModel):
    """Typed UI state fields matching client EditorContext interface."""

    editor_surface: str | None = None
    editor_mode: str | None = None
    dirty: bool = False
    stage_count: int = 0
    last_change_kind: str | None = None
    last_change_summary: str | None = None
    has_validation_errors: bool = False
    validation_error_count: int = 0
    validation_error_stages: list[str] = []
    validation_issues: list[dict[str, Any]] = []
    has_conflict: bool = False
    last_save_status: str | None = None
    save_readiness: str | None = None
    semantic_projection: dict[str, Any] | None = None
    recent_interactions: list[dict[str, Any]] | None = None
    last_diff_summary: dict[str, Any] | None = None
    screenshot: str | None = None


class ContextAttachment(BaseModel):
    """Client-supplied context for a conversation turn."""

    project_id: str
    safety_mode: str = "guided"
    working_dir: str | None = None
    domain_id: str | None = None
    workflow_id: str | None = None
    revision_id: str | None = None
    run_id: str | None = None
    artifact_id: str | None = None
    derivation_id: str | None = None
    selected_nodes: list[str] | None = None
    current_route: str | None = None
    ui_state: dict[str, Any] | None = None

    def resolve_ui_state(self) -> UIState:
        """Parse ui_state dict into typed UIState with defaults."""
        if self.ui_state is None:
            return UIState()
        return UIState.model_validate(self.ui_state)


def _workflow_id_from_selected_run(selected_run: dict[str, Any] | None) -> str | None:
    if not isinstance(selected_run, dict):
        return None
    workflow_ref = selected_run.get("workflow_ref")
    if isinstance(workflow_ref, dict):
        workflow_id = str(workflow_ref.get("workflow_id") or "").strip()
        if workflow_id:
            return workflow_id
    workflow_id = str(selected_run.get("workflow_id") or "").strip()
    return workflow_id or None


def _selected_run_id(selected_run: dict[str, Any] | None) -> str | None:
    if not isinstance(selected_run, dict):
        return None
    run_id = str(selected_run.get("workflow_run_id") or selected_run.get("run_id") or "").strip()
    return run_id or None


def _build_ui_context(context: ContextAttachment, resolved_domain_id: str | None) -> dict[str, Any]:
    ui_context: dict[str, Any] = {}
    if context.selected_nodes is not None:
        ui_context["selected_nodes"] = context.selected_nodes
    if context.current_route is not None:
        ui_context["current_route"] = context.current_route
    if context.ui_state is not None:
        ui_context.update(context.ui_state)
    if resolved_domain_id:
        ui_context["domain_id"] = resolved_domain_id
    return ui_context


def _build_starter_catalog(resolved_domain_id: str | None) -> list[dict[str, Any]]:
    return [
        {
            "id": str(starter.get("id") or ""),
            "title": str(starter.get("title") or ""),
            "description": str(starter.get("description") or ""),
            "intended_use_cases": starter.get("intended_use_cases") or [],
        }
        for starter in resolve_domain_starters(resolved_domain_id)
    ]


class AssistantContextAssembler:
    """Resolves Studio context for an assistant conversation turn.

    Reads from the existing WorkflowStudioRepository to populate workflow
    and run context alongside client-supplied UI state.
    """

    def __init__(
        self,
        repository: WorkflowStudioRepository,
        project_root: Any | None = None,
    ) -> None:
        self._repository = repository
        self._project_root = project_root

    def _resolve_workflow_and_runs(
        self,
        context: ContextAttachment,
    ) -> tuple[dict[str, Any] | None, dict[str, Any] | None, dict[str, Any] | None, Any | None, dict[str, Any] | None]:
        resolved_workflow: dict[str, Any] | None = None
        resolved_latest_run: dict[str, Any] | None = None
        resolved_selected_run: dict[str, Any] | None = None
        selected_run_bundle: Any | None = None
        resolved_run_replay: dict[str, Any] | None = None

        if context.workflow_id is not None:
            try:
                resolved_workflow = self._repository.get_workflow(context.workflow_id)
            except Exception as exc:
                logger.warning("Failed to resolve workflow %s: %s", context.workflow_id, exc)
                resolved_workflow = None

            if resolved_workflow is not None:
                try:
                    matching_runs = self._repository.list_runs(workflow_id=context.workflow_id)
                    if matching_runs:
                        resolved_latest_run = matching_runs[0]
                except Exception as exc:
                    logger.warning(
                        "Failed to list runs for workflow %s: %s", context.workflow_id, exc
                    )
                    resolved_latest_run = None

        if context.run_id is None:
            return (
                resolved_workflow,
                resolved_latest_run,
                resolved_selected_run,
                selected_run_bundle,
                resolved_run_replay,
            )

        try:
            resolved_selected_run = self._repository.get_run(context.run_id)
        except Exception as exc:
            logger.warning("Failed to resolve run %s: %s", context.run_id, exc)
            resolved_selected_run = None
        try:
            selected_run_bundle = self._repository.get_run_bundle(context.run_id)
        except Exception as exc:
            logger.warning("Failed to resolve run bundle %s: %s", context.run_id, exc)
            selected_run_bundle = None
        if resolved_selected_run is None:
            return (
                resolved_workflow,
                resolved_latest_run,
                resolved_selected_run,
                selected_run_bundle,
                resolved_run_replay,
            )

        try:
            resolved_run_replay = self._repository.get_run_replay(context.run_id)
        except Exception as exc:
            logger.warning("Failed to resolve run replay %s: %s", context.run_id, exc)
            resolved_run_replay = None
        if resolved_workflow is None:
            selected_workflow_id = _workflow_id_from_selected_run(resolved_selected_run)
            if selected_workflow_id:
                try:
                    resolved_workflow = self._repository.get_workflow(selected_workflow_id)
                except Exception as exc:
                    logger.warning(
                        "Failed to resolve workflow %s from run: %s",
                        selected_workflow_id,
                        exc,
                    )
                    resolved_workflow = None
        return (
            resolved_workflow,
            resolved_latest_run,
            resolved_selected_run,
            selected_run_bundle,
            resolved_run_replay,
        )

    def _resolve_artifact_context(
        self,
        context: ContextAttachment,
        resolved_workflow: dict[str, Any] | None,
        resolved_selected_run: dict[str, Any] | None,
        selected_run_bundle: Any | None,
        resolved_run_replay: dict[str, Any] | None,
    ) -> tuple[
        dict[str, Any] | None,
        str | None,
        dict[str, Any] | None,
        Any | None,
        dict[str, Any] | None,
        dict[str, Any] | None,
    ]:
        resolved_selected_artifact: dict[str, Any] | None = None
        artifact_content: str | None = None

        if context.artifact_id is None:
            return (
                resolved_selected_artifact,
                artifact_content,
                resolved_selected_run,
                selected_run_bundle,
                resolved_run_replay,
                resolved_workflow,
            )

        try:
            resolved_selected_artifact = self._repository.get_artifact(context.artifact_id)
        except Exception as exc:
            logger.warning("Failed to resolve artifact %s: %s", context.artifact_id, exc)
            resolved_selected_artifact = None
        try:
            artifact_content = self._repository.get_artifact_content(context.artifact_id)
        except Exception as exc:
            logger.warning("Failed to resolve artifact content %s: %s", context.artifact_id, exc)
            artifact_content = None

        if resolved_selected_artifact is not None:
            producer_run_id = resolved_selected_artifact.get("producer_run_id")
            if producer_run_id and resolved_selected_run is None:
                try:
                    resolved_selected_run = self._repository.get_run(str(producer_run_id))
                except Exception as exc:
                    logger.warning("Failed to resolve producer run %s: %s", producer_run_id, exc)
                    resolved_selected_run = None
                try:
                    selected_run_bundle = self._repository.get_run_bundle(str(producer_run_id))
                except Exception as exc:
                    logger.warning(
                        "Failed to resolve producer run bundle %s: %s", producer_run_id, exc
                    )
                    selected_run_bundle = None
                if resolved_selected_run is not None:
                    try:
                        resolved_run_replay = self._repository.get_run_replay(str(producer_run_id))
                    except Exception as exc:
                        logger.warning(
                            "Failed to resolve producer run replay %s: %s", producer_run_id, exc
                        )
                        resolved_run_replay = None
            if resolved_workflow is None and resolved_selected_run is not None:
                selected_workflow_id = _workflow_id_from_selected_run(resolved_selected_run)
                if selected_workflow_id:
                    try:
                        resolved_workflow = self._repository.get_workflow(selected_workflow_id)
                    except Exception as exc:
                        logger.warning(
                            "Failed to resolve workflow %s from artifact: %s",
                            selected_workflow_id,
                            exc,
                        )
                        resolved_workflow = None
        return (
            resolved_selected_artifact,
            artifact_content,
            resolved_selected_run,
            selected_run_bundle,
            resolved_run_replay,
            resolved_workflow,
        )

    def _resolve_derivation(self, context: ContextAttachment) -> dict[str, Any] | None:
        if context.derivation_id is None:
            return None
        try:
            return self._repository.get_derivation(context.derivation_id)
        except Exception as exc:
            logger.warning("Failed to resolve derivation %s: %s", context.derivation_id, exc)
            return None

    def _resolve_revision_history(
        self,
        context: ContextAttachment,
        resolved_workflow: dict[str, Any] | None,
    ) -> list[dict[str, Any]]:
        if context.workflow_id is None or resolved_workflow is None:
            return []
        try:
            from obra.config.loaders import get_gateway_assistant_config

            assistant_config = get_gateway_assistant_config()
            max_revisions = assistant_config.get("revision_history_max_revisions", 5)
            revisions = self._repository.list_workflow_revisions(context.workflow_id)
            return revisions[-max_revisions:]
        except Exception as exc:
            logger.warning(
                "Failed to resolve revision history for workflow %s: %s",
                context.workflow_id,
                exc,
            )
            return []

    def _resolve_template_assets(
        self,
        resolved_workflow: dict[str, Any] | None,
    ) -> dict[str, str]:
        template_assets: dict[str, str] = {}
        if resolved_workflow is None:
            return template_assets
        stages = (
            resolved_workflow.get("stages")
            or resolved_workflow.get("definition", {}).get("stages")
            or []
        )
        for stage in stages:
            bindings = stage.get("template_asset_bindings") or []
            stage_id = stage.get("stage_id") or stage.get("id") or ""
            for binding in bindings:
                asset_id = binding.get("asset_id") or binding.get("template_id")
                if not asset_id:
                    continue
                try:
                    content = self._repository.get_template_asset(asset_id)
                    if content:
                        template_assets[stage_id] = content
                except Exception as exc:
                    logger.warning(
                        "Failed to resolve template asset %s for stage %s: %s",
                        asset_id,
                        stage_id,
                        exc,
                    )
        return template_assets

    def _resolve_knowledge_documents(
        self,
        context: ContextAttachment,
        resolved_workflow: dict[str, Any] | None,
    ) -> list[dict[str, Any]]:
        del resolved_workflow
        knowledge_documents: list[dict[str, Any]] = []
        if self._project_root is None:
            return knowledge_documents
        try:
            from obra.config.loaders import get_gateway_assistant_config as _get_kac
            from obra.gateway.workflow_studio.knowledge_repository import KnowledgeRepository

            assistant_config = _get_kac()
            knowledge_repository = KnowledgeRepository(
                self._project_root,
                max_document_bytes=assistant_config["knowledge_max_document_bytes"],
                max_total_bytes=assistant_config["knowledge_max_total_bytes"],
            )
            for doc in knowledge_repository.list_documents(scope="org-wide"):
                try:
                    _, content_text = knowledge_repository.get_document(doc["id"])
                    knowledge_documents.append(
                        {
                            "name": doc.get("name", ""),
                            "scope": doc.get("scope", "org-wide"),
                            "description": doc.get("description"),
                            "content_text": content_text,
                        }
                    )
                except Exception as exc:
                    logger.warning(
                        "Failed to resolve org-wide knowledge document %s: %s",
                        doc.get("id"),
                        exc,
                    )
            if context.workflow_id:
                for doc in knowledge_repository.list_documents(
                    scope="workflow",
                    workflow_id=context.workflow_id,
                ):
                    try:
                        _, content_text = knowledge_repository.get_document(doc["id"])
                        knowledge_documents.append(
                            {
                                "name": doc.get("name", ""),
                                "scope": doc.get("scope", "workflow"),
                                "description": doc.get("description"),
                                "content_text": content_text,
                            }
                        )
                    except Exception as exc:
                        logger.warning(
                            "Failed to resolve workflow knowledge document %s: %s",
                            doc.get("id"),
                            exc,
                        )
        except Exception as exc:
            logger.warning("Failed to initialize knowledge repository: %s", exc)
            return []
        return knowledge_documents

    def _resolve_run_timeline(
        self,
        resolved_latest_run: dict[str, Any] | None,
        resolved_run_replay: dict[str, Any] | None,
    ) -> list[dict[str, Any]]:
        if not isinstance(resolved_latest_run, dict):
            return []
        run_status = str(resolved_latest_run.get("status") or "")
        if run_status not in {"failed", "cancelled"}:
            return []
        run_id = resolved_latest_run.get("run_id") or resolved_latest_run.get("id")
        if not run_id:
            return []
        try:
            from obra.config.loaders import get_gateway_assistant_config as _get_ac

            assistant_config = _get_ac()
            max_events = assistant_config.get("run_timeline_max_events", 10)
            replay = resolved_run_replay
            if not isinstance(replay, dict):
                replay = self._repository.get_run_replay(run_id)
            if replay and isinstance(replay, dict):
                return (replay.get("entries") or [])[-max_events:]
        except Exception as exc:
            logger.warning("Failed to resolve run timeline for run %s: %s", run_id, exc)
        return []

    def resolve(self, context: ContextAttachment) -> dict[str, Any]:
        """Resolve full context from a client-supplied attachment.

        Returns a dict with keys: project_id, workflow, latest_run,
        ui_context, safety_mode.
        """
        resolved_domain_id = normalize_starter_domain_id(context.domain_id)
        (
            resolved_workflow,
            resolved_latest_run,
            resolved_selected_run,
            selected_run_bundle,
            resolved_run_replay,
        ) = self._resolve_workflow_and_runs(context)
        (
            resolved_selected_artifact,
            artifact_content,
            resolved_selected_run,
            selected_run_bundle,
            resolved_run_replay,
            resolved_workflow,
        ) = self._resolve_artifact_context(
            context,
            resolved_workflow,
            resolved_selected_run,
            selected_run_bundle,
            resolved_run_replay,
        )
        resolved_selected_derivation = self._resolve_derivation(context)

        if resolved_selected_run is not None:
            resolved_latest_run = resolved_selected_run

        if selected_run_bundle is None and resolved_selected_run is not None:
            selected_run_id = _selected_run_id(resolved_selected_run)
            if selected_run_id:
                try:
                    selected_run_bundle = self._repository.get_run_bundle(selected_run_id)
                except Exception as exc:
                    logger.warning(
                        "Failed to resolve run bundle %s (fallback): %s", selected_run_id, exc
                    )
                    selected_run_bundle = None

        if not resolved_domain_id and isinstance(resolved_workflow, dict):
            resolved_domain_id = normalize_starter_domain_id(
                str(resolved_workflow.get("domain_id") or resolved_workflow.get("domain") or "")
            )

        ui_context = _build_ui_context(context, resolved_domain_id)
        revision_history = self._resolve_revision_history(context, resolved_workflow)
        run_timeline = self._resolve_run_timeline(resolved_latest_run, resolved_run_replay)
        template_assets = self._resolve_template_assets(resolved_workflow)
        knowledge_documents = self._resolve_knowledge_documents(context, resolved_workflow)
        starter_catalog = _build_starter_catalog(resolved_domain_id)
        output_review = build_output_review_context(
            bundle=selected_run_bundle,
            selected_run=resolved_selected_run,
            selected_artifact=resolved_selected_artifact,
            artifact_content=artifact_content,
            run_replay=resolved_run_replay,
        )
        business_tier_defaults = _resolve_business_tier_defaults(
            domain_id=resolved_domain_id,
            workflow=resolved_workflow,
        )

        return {
            "project_id": context.project_id,
            "working_dir": context.working_dir,
            "domain_id": resolved_domain_id or None,
            "workflow_id": context.workflow_id,
            "revision_id": context.revision_id,
            "workflow": resolved_workflow,
            "latest_run": resolved_latest_run,
            "selected_run": resolved_selected_run,
            "selected_artifact": resolved_selected_artifact,
            "selected_derivation": resolved_selected_derivation,
            "run_replay": resolved_run_replay,
            "artifact_content": artifact_content,
            "ui_context": ui_context,
            "safety_mode": context.safety_mode,
            "revision_history": revision_history,
            "run_timeline": run_timeline,
            "template_assets": template_assets,
            "starter_catalog": starter_catalog,
            "knowledge_documents": knowledge_documents,
            "output_review": output_review,
            **business_tier_defaults,
        }
