"""Canonical workflow edit projections for Workflow Studio Stage C."""

from __future__ import annotations

from typing import Any

from obra.gateway.links import build_resource_links
from obra.gateway.workflow_studio.data_access import (
    WorkflowStudioRunBundle,
    workflow_identity_from_sources,
)
from obra.gateway.workflow_studio.workflow_edit_views import build_workflow_semantic_view


def build_workflow_revision(bundle: WorkflowStudioRunBundle) -> dict[str, Any] | None:
    """Build an edit-ready canonical revision projection from a run bundle."""
    identity = workflow_identity_from_sources(bundle.record, bundle.remote_session)
    workflow_id = identity["workflow_id"]
    if workflow_id is None:
        return None
    revision_id = identity["revision_id"] or "current"
    workflow_definition = _workflow_definition_from_bundle(bundle, workflow_id=workflow_id)
    validation_summary = _validation_summary_from_session(bundle.remote_session)
    diff_summary = _diff_summary_from_session(bundle.remote_session)
    conflict_summary = _conflict_summary_from_session(bundle.remote_session)
    stage_order = [
        str(stage.get("title") or stage.get("id") or "")
        for stage in workflow_definition.get("stages", [])
        if isinstance(stage, dict) and str(stage.get("title") or stage.get("id") or "").strip()
    ]
    payload = {
        "resource_type": "workflow_revision",
        "workflow_id": workflow_id,
        "revision_id": revision_id,
        "previous_revision_id": "",
        "domain_id": identity["domain_id"],
        "title": bundle.record.objective,
        "description": bundle.record.objective,
        "stage_order": stage_order,
        "stage_count": len(stage_order),
        "workflow_definition": workflow_definition,
        "validation_summary": validation_summary,
        "diff_summary": diff_summary,
        "conflict_summary": conflict_summary,
        "runner_diagnostics": _runner_diagnostics_from_definition(workflow_definition),
        "binding_diagnostics": _binding_diagnostics_from_definition(workflow_definition),
        "lifecycle_validation": {"valid": True, "issues": []},
        "correlation": {
            "workflow_run_id": bundle.record.workflow_run_id,
            "trace_id": bundle.record.trace_id,
        },
    }
    payload["semantic_view"] = build_workflow_semantic_view(payload)
    return payload


def build_workflow_summary(
    workflow_id: str,
    revisions: list[dict[str, Any]],
) -> dict[str, Any]:
    """Build workflow summary from edit-ready revisions."""
    latest = revisions[0]
    payload = {
        "resource_type": "workflow",
        "workflow_id": workflow_id,
        "domain_id": latest.get("domain_id"),
        "latest_revision_id": latest.get("revision_id"),
        "status": latest.get("validation_summary", {}).get("outcome", "unknown"),
        "title": latest.get("title"),
        "description": latest.get("description"),
        "revision_count": len(revisions),
        "stage_order": latest.get("stage_order", []),
        "stage_count": latest.get("stage_count", 0),
        "workflow_definition": latest.get("workflow_definition", {}),
        "validation_summary": latest.get("validation_summary", {}),
        "diff_summary": latest.get("diff_summary", {}),
        "conflict_summary": latest.get("conflict_summary", {}),
        "runner_diagnostics": latest.get("runner_diagnostics", []),
        "binding_diagnostics": latest.get("binding_diagnostics", []),
        "lifecycle_validation": latest.get("lifecycle_validation", {}),
        "correlation": latest.get("correlation", {}),
        "links": build_resource_links("workflow", workflow_id),
    }
    payload["semantic_view"] = build_workflow_semantic_view(payload)
    return payload


def build_workflow_detail(
    workflow_id: str,
    revisions: list[dict[str, Any]],
) -> dict[str, Any]:
    """Build workflow detail with embedded revision history."""
    summary = build_workflow_summary(workflow_id, revisions)
    summary["revisions"] = revisions
    return summary


def hydrate_workflow_payload(workflow: dict[str, Any]) -> dict[str, Any]:
    """Ensure persisted workflow payloads expose semantic edit views."""
    hydrated = dict(workflow)
    workflow_id = str(hydrated.get("workflow_id") or "").strip()
    if workflow_id and "links" not in hydrated:
        hydrated["links"] = build_resource_links("workflow", workflow_id)
    if "semantic_view" not in hydrated:
        hydrated["semantic_view"] = build_workflow_semantic_view(hydrated)
    return hydrated


def _workflow_definition_from_bundle(
    bundle: WorkflowStudioRunBundle,
    *,
    workflow_id: str,
) -> dict[str, Any]:
    stages = []
    for index, stage in enumerate(bundle.pipeline_stages, start=1):
        if not isinstance(stage, dict):
            continue
        stage_id = str(
            stage.get("stage_id")
            or stage.get("id")
            or stage.get("stage_execution_id")
            or stage.get("stage_name")
            or f"stage-{index}"
        )
        stage_payload = {
            "id": stage_id,
            "title": stage.get("stage_name") or stage.get("title") or stage_id,
            "purpose": stage.get("purpose") or "",
            "depends_on": list(stage.get("depends_on") or []),
            "runner": dict(stage.get("runner") or {}),
            "quality_loop": dict(stage.get("quality_loop") or {}),
            "template_asset_bindings": list(stage.get("resolved_stage_asset_bindings") or []),
            "rule_pack_refs": list(stage.get("rule_pack_refs") or []),
            "quality_pack_refs": list(stage.get("quality_pack_refs") or []),
            "lifecycle": dict(stage.get("lifecycle") or {}),
        }
        stages.append(stage_payload)
    workflow_lifecycle = (
        bundle.remote_session.get("workflow_lifecycle_state")
        if isinstance(bundle.remote_session.get("workflow_lifecycle_state"), dict)
        else {}
    )
    visual_authoring = (
        bundle.remote_session.get("workflow_visual_authoring")
        if isinstance(bundle.remote_session.get("workflow_visual_authoring"), dict)
        else {}
    )
    return {
        "workflow_id": workflow_id,
        "title": bundle.record.objective,
        "description": bundle.record.objective,
        "domain_id": bundle.record.domain_id,
        "lifecycle": workflow_lifecycle,
        "visual_authoring": visual_authoring,
        "template_asset_bindings": list(bundle.remote_session.get("template_asset_bindings") or []),
        "stages": stages,
    }


def _validation_summary_from_session(remote_session: dict[str, Any]) -> dict[str, Any]:
    state = (
        remote_session.get("workflow_derivation_state")
        if isinstance(remote_session.get("workflow_derivation_state"), dict)
        else {}
    )
    report = (
        state.get("validation_report") if isinstance(state.get("validation_report"), dict) else {}
    )
    checkpoint_state = (
        state.get("operator_review_checkpoint_state")
        if isinstance(state.get("operator_review_checkpoint_state"), dict)
        else {}
    )
    issues = list(report.get("issues") or [])
    blocking = [
        issue
        for issue in issues
        if isinstance(issue, dict)
        and str(issue.get("severity", "") or "").strip().lower() == "fail"
    ]
    return {
        "outcome": report.get("outcome"),
        "issue_codes": list(report.get("issue_codes") or []),
        "operator_review_points": list(state.get("operator_review_points") or []),
        "pending_operator_review_checkpoint_ids": list(
            checkpoint_state.get("checkpoint_ids") or []
        ),
        "blocking_issue_count": len(blocking),
        "advisory_issue_count": max(len(issues) - len(blocking), 0),
        "issues": issues,
    }


def _diff_summary_from_session(remote_session: dict[str, Any]) -> dict[str, Any]:
    state = (
        remote_session.get("workflow_derivation_state")
        if isinstance(remote_session.get("workflow_derivation_state"), dict)
        else {}
    )
    baseline = (
        state.get("expected_baseline_ref")
        if isinstance(state.get("expected_baseline_ref"), dict)
        else {}
    )
    derived = (
        state.get("derived_workflow_artifact")
        if isinstance(state.get("derived_workflow_artifact"), dict)
        else {}
    )
    return {
        "base_revision_id": baseline.get("revision_id") or baseline.get("version") or "",
        "changed": True,
        "resulting_revision_id": derived.get("revision_id") or derived.get("version") or "",
        "change_type": "structural_logic",
        "arrangement_changed": False,
        "logic_changed": True,
        "canvas_arrangement_changes": [],
        "workflow_logic_changes": ["Derived workflow logic is available for review."],
    }


def _conflict_summary_from_session(remote_session: dict[str, Any]) -> dict[str, Any]:
    state = (
        remote_session.get("workflow_derivation_state")
        if isinstance(remote_session.get("workflow_derivation_state"), dict)
        else {}
    )
    reason = str(state.get("accept_conflict_reason") or "").strip()
    if not reason:
        return {}
    return {
        "status": "stale_revision",
        "reason": reason,
    }


def _runner_diagnostics_from_definition(
    workflow_definition: dict[str, Any],
) -> list[dict[str, Any]]:
    diagnostics = []
    for stage in workflow_definition.get("stages", []):
        if not isinstance(stage, dict):
            continue
        runner = stage.get("runner")
        if not isinstance(runner, dict):
            continue
        diagnostics.append(
            {
                "stage_id": stage.get("id"),
                "runner_id": runner.get("runner_id"),
                "runner_version": runner.get("runner_version"),
                "runner_selector": runner.get("runner_selector"),
            }
        )
    return diagnostics


def _binding_diagnostics_from_definition(
    workflow_definition: dict[str, Any],
) -> list[dict[str, Any]]:
    diagnostics = []
    for stage in workflow_definition.get("stages", []):
        if not isinstance(stage, dict):
            continue
        bindings = [
            binding
            for binding in stage.get("template_asset_bindings", [])
            if isinstance(binding, dict)
        ]
        diagnostics.append(
            {
                "stage_id": stage.get("id"),
                "binding_count": len(bindings),
                "binding_roles": sorted(
                    {
                        str(binding.get("binding_role") or "")
                        for binding in bindings
                        if str(binding.get("binding_role") or "").strip()
                    }
                ),
            }
        )
    return diagnostics
