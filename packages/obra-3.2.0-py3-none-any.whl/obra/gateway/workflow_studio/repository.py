"""Repository facade for Workflow Studio Stage A routes."""

from __future__ import annotations

import logging
from collections import defaultdict
from datetime import UTC, datetime
from typing import Any, Callable, Literal

from fastapi import Request

from obra.api import APIClient
from obra.gateway.session_manager import SessionManager, SessionNotFoundError
from obra.gateway.workflow_studio import runners as runner_views
from obra.gateway.workflow_studio.artifacts import (
    build_artifact_detail,
    build_artifact_summary,
    resolve_artifact_content,
)
from obra.gateway.workflow_studio.data_access import StageADataAccess, WorkflowStudioRunBundle
from obra.gateway.workflow_studio.derivations import build_workflow_derivation_detail
from obra.gateway.workflow_studio.replay import build_replay_payload
from obra.gateway.workflow_studio.runs import (
    build_workflow_run_detail,
    build_workflow_run_summary,
)
from obra.gateway.workflow_studio.template_assets import collect_template_assets
from obra.gateway.workflow_studio.workflow_edits import (
    build_workflow_detail,
    build_workflow_revision,
    build_workflow_summary,
    hydrate_workflow_payload,
)

logger = logging.getLogger(__name__)


class WorkflowStudioRepository:
    """Query facade for canonical Workflow Studio resources."""

    def __init__(
        self,
        session_manager: SessionManager,
        *,
        client_factory: Callable[[], APIClient] | None = None,
        workflow_scenarios: dict[str, dict[str, Any]] | None = None,
    ) -> None:
        self._session_manager = session_manager
        self._data_access = StageADataAccess(session_manager)
        self._client_factory = client_factory or APIClient.from_config
        self._client: APIClient | None = None
        self._workflow_scenarios = dict(workflow_scenarios or {})

    @classmethod
    def from_request(cls, request: Request) -> "WorkflowStudioRepository":
        session_manager = request.app.state.session_manager
        workflow_scenarios = getattr(request.app.state, "workflow_studio_browser_scenarios", {})
        client_factory = getattr(request.app.state, "workflow_studio_client_factory", None)
        return cls(
            session_manager,
            client_factory=client_factory if callable(client_factory) else None,
            workflow_scenarios=workflow_scenarios,
        )

    def list_workflows(
        self, *, view: Literal["active", "archived", "trash"] | None = None
    ) -> list[dict[str, Any]]:
        remote = self._list_remote_workflows(view=view)
        if remote is not None:
            return remote
        revisions_by_workflow: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for bundle in self._data_access.list_run_bundles():
            revision = build_workflow_revision(bundle)
            if revision is None:
                continue
            revisions_by_workflow[str(revision["workflow_id"])].append(revision)
        workflows = []
        for workflow_id, revisions in revisions_by_workflow.items():
            workflows.append(build_workflow_summary(workflow_id, _sort_revisions(revisions)))
        return _filter_workflows_for_view(
            sorted(workflows, key=lambda workflow: str(workflow["workflow_id"])),
            view=view,
        )

    def get_workflow(self, workflow_id: str) -> dict[str, Any] | None:
        remote = self._get_remote_workflow(workflow_id)
        if remote is not None:
            return remote
        revisions = self.list_workflow_revisions(workflow_id)
        if not revisions:
            return None
        return build_workflow_detail(workflow_id, revisions)

    def list_workflow_revisions(self, workflow_id: str) -> list[dict[str, Any]]:
        remote = self._list_remote_workflow_revisions(workflow_id)
        if remote:
            return remote
        revisions: list[dict[str, Any]] = []
        for bundle in self._data_access.list_run_bundles():
            revision = build_workflow_revision(bundle)
            if revision is None:
                continue
            if str(revision["workflow_id"]) == workflow_id:
                revisions.append(revision)
        return _sort_revisions(revisions)

    def get_workflow_revision(
        self,
        workflow_id: str,
        revision_id: str,
    ) -> dict[str, Any] | None:
        remote = self._get_remote_workflow_revision(workflow_id, revision_id)
        if remote is not None:
            return remote
        revisions = self.list_workflow_revisions(workflow_id)
        for revision in revisions:
            if str(revision.get("revision_id")) == revision_id:
                return revision
        return None

    def list_artifacts(self) -> list[dict[str, Any]]:
        artifacts: dict[str, dict[str, Any]] = {}
        for bundle in self._data_access.list_run_bundles():
            for artifact in bundle.workflow_artifacts:
                artifact_id = str(artifact.get("artifact_id") or "")
                if not artifact_id:
                    continue
                current = artifacts.get(artifact_id)
                candidate = build_artifact_summary(artifact)
                if current is None or str(candidate.get("version") or "") >= str(
                    current.get("version") or ""
                ):
                    artifacts[artifact_id] = candidate
        return [artifacts[key] for key in sorted(artifacts)]

    def get_artifact(self, artifact_id: str) -> dict[str, Any] | None:
        for bundle in self._data_access.list_run_bundles():
            for artifact in bundle.workflow_artifacts:
                if str(artifact.get("artifact_id") or "") == artifact_id:
                    return build_artifact_detail(bundle, artifact)
        return None

    def get_artifact_references(self, artifact_id: str) -> dict[str, Any] | None:
        detail = self.get_artifact(artifact_id)
        if detail is None:
            return None
        return {
            "artifact_id": artifact_id,
            "references": detail.get("references", []),
            "upstream_refs": detail.get("upstream_refs", []),
            "downstream_refs": detail.get("downstream_refs", []),
        }

    def get_artifact_provenance(self, artifact_id: str) -> dict[str, Any] | None:
        detail = self.get_artifact(artifact_id)
        if detail is None:
            return None
        return {
            "artifact_id": artifact_id,
            "provenance": detail.get("provenance", {}),
            "producer_run_id": detail.get("producer_run_id"),
        }

    def get_artifact_content(self, artifact_id: str) -> str | None:
        for bundle in self._data_access.list_run_bundles():
            if not any(
                str(artifact.get("artifact_id") or "") == artifact_id
                for artifact in bundle.workflow_artifacts
            ):
                continue
            content = resolve_artifact_content(bundle, artifact_id)
            if content is not None:
                return content
        return None

    def get_template_asset(self, asset_id: str) -> dict[str, Any] | None:
        assets = collect_template_assets(self._data_access.list_run_bundles())
        return assets.get(asset_id)

    def list_template_assets(self) -> list[dict[str, Any]]:
        """List canonical template assets across known runs."""
        assets = collect_template_assets(self._data_access.list_run_bundles())
        return [assets[key] for key in sorted(assets)]

    def list_template_asset_revisions(self, asset_id: str) -> list[str] | None:
        asset = self.get_template_asset(asset_id)
        if asset is None:
            return None
        return list(asset.get("revisions", []))

    def list_template_asset_bindings(self, asset_id: str) -> list[dict[str, Any]] | None:
        asset = self.get_template_asset(asset_id)
        if asset is None:
            return None
        return list(asset.get("bindings", []))

    def list_runs(self, *, workflow_id: str | None = None) -> list[dict[str, Any]]:
        return [
            build_workflow_run_summary(bundle)
            for bundle in self._data_access.list_run_bundles(workflow_id=workflow_id)
        ]

    def get_run_bundle(self, run_id: str) -> WorkflowStudioRunBundle:
        return self._data_access.get_run_bundle(run_id)

    def get_run(self, run_id: str) -> dict[str, Any] | None:
        try:
            bundle = self.get_run_bundle(run_id)
        except Exception:
            return None
        return build_workflow_run_detail(bundle)

    def list_derivations(self) -> list[dict[str, Any]]:
        """List canonical workflow-derivation detail payloads."""
        bundles = sorted(
            self._data_access.list_derivation_bundles(),
            key=lambda bundle: (
                bundle.record.created_at.isoformat(),
                str(bundle.record.derivation_id or bundle.record.session_id),
            ),
            reverse=True,
        )
        return [build_workflow_derivation_detail(bundle) for bundle in bundles]

    def get_derivation(self, derivation_id: str) -> dict[str, Any] | None:
        try:
            bundle = self._data_access.get_derivation_bundle(derivation_id)
        except Exception:
            return None
        return build_workflow_derivation_detail(bundle)

    def get_run_replay(self, run_id: str) -> dict[str, Any] | None:
        try:
            bundle = self.get_run_bundle(run_id)
        except Exception:
            return None
        return build_replay_payload(bundle)

    def list_runners(self) -> list[dict[str, Any]]:
        """List canonical runner lookup payloads."""
        return runner_views.list_runners()

    def get_runner(
        self,
        runner_id: str,
        *,
        runner_version: str | None = None,
        runner_selector: str | None = None,
    ) -> dict[str, Any] | None:
        """Return one canonical runner detail payload."""
        return runner_views.get_runner(
            runner_id,
            runner_version=runner_version,
            runner_selector=runner_selector,
        )

    def check_runner_compatibility(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Check runner compatibility for a workflow-edit context."""
        return runner_views.check_runner_compatibility(payload)

    def list_callbacks(self) -> list[dict[str, Any]]:
        """Project persisted callback registrations across canonical workflow runs."""
        callbacks: list[dict[str, Any]] = []
        for bundle in self._data_access.list_run_bundles():
            callbacks.extend(_build_callback_entries(bundle))
        return sorted(
            callbacks,
            key=lambda item: (
                str(item.get("received_at") or ""),
                str(item.get("expires_at") or ""),
                str(item.get("callback_id") or ""),
            ),
            reverse=True,
        )

    def get_callback(self, callback_id: str) -> dict[str, Any] | None:
        normalized = str(callback_id or "").strip()
        if not normalized:
            return None
        for bundle in self._data_access.list_run_bundles():
            for callback in _build_callback_entries(bundle):
                if str(callback.get("callback_id") or "") == normalized:
                    return callback
        return None

    def get_run_lineage(self, run_id: str) -> dict[str, Any]:
        """Build parent/child lineage for a canonical workflow run."""
        bundle = self.get_run_bundle(run_id)
        launch_metadata = _launch_metadata(bundle.record)
        parent_session_id = str(launch_metadata.get("parent_session_id") or "").strip()
        parent = None
        if parent_session_id:
            try:
                parent_record = self._session_manager.get_session(parent_session_id)
            except SessionNotFoundError:
                parent_record = None
            parent = {
                "run_id": parent_session_id,
                "workflow_run_id": parent_session_id,
                "workflow_id": (
                    getattr(parent_record, "workflow_id", None)
                    or launch_metadata.get("parent_workflow_id")
                ),
                "revision_id": (
                    getattr(parent_record, "workflow_revision_id", None)
                    or launch_metadata.get("parent_revision_id")
                ),
                "project_id": getattr(parent_record, "project_id", None)
                or launch_metadata.get("project_id"),
                "stage_name": launch_metadata.get("parent_stage_name"),
                "stage_execution_id": launch_metadata.get("parent_stage_execution_id"),
            }

        children = []
        for child_record in self._session_manager.list_workflow_runs():
            child_launch_metadata = _launch_metadata(child_record)
            if str(child_launch_metadata.get("parent_session_id") or "").strip() != run_id:
                continue
            children.append(
                {
                    "run_id": child_record.workflow_run_id or child_record.session_id,
                    "workflow_run_id": child_record.workflow_run_id or child_record.session_id,
                    "workflow_id": child_launch_metadata.get("target_workflow_id")
                    or child_record.workflow_id,
                    "revision_id": child_launch_metadata.get("target_revision_id")
                    or child_record.workflow_revision_id,
                    "project_id": child_launch_metadata.get("project_id") or child_record.project_id,
                    "parent_stage_name": child_launch_metadata.get("parent_stage_name"),
                    "parent_stage_execution_id": child_launch_metadata.get(
                        "parent_stage_execution_id"
                    ),
                    "workflow_chain": list(child_launch_metadata.get("workflow_chain") or []),
                }
            )

        children.sort(key=lambda item: str(item.get("run_id") or ""))
        return {
            "run_id": bundle.record.workflow_run_id,
            "workflow_run_id": bundle.record.workflow_run_id,
            "workflow_chain": list(launch_metadata.get("workflow_chain") or []),
            "parent": parent,
            "children": children,
        }

    def _list_remote_workflows(
        self,
        *,
        view: Literal["active", "archived", "trash"] | None = None,
    ) -> list[dict[str, Any]] | None:
        client = self._get_client()
        if client is None:
            return None
        try:
            response = client.list_workflows(include_archived=True, include_deleted=True)
        except Exception as exc:
            logger.debug(
                "Workflow store listing unavailable, falling back to session view: %s", exc
            )
            return None
        workflows = response.get("workflows", [])
        if not isinstance(workflows, list):
            return None
        hydrated = [
            hydrate_workflow_payload(workflow)
            for workflow in workflows
            if isinstance(workflow, dict)
        ]
        return _filter_workflows_for_view(hydrated, view=view)

    def _get_remote_workflow(self, workflow_id: str) -> dict[str, Any] | None:
        client = self._get_client()
        if client is None:
            return None
        try:
            response = client.get_workflow(workflow_id)
        except Exception as exc:
            logger.debug("Workflow head lookup unavailable for %s: %s", workflow_id, exc)
            return None
        workflow = response.get("workflow")
        if not isinstance(workflow, dict):
            return None
        return hydrate_workflow_payload(workflow)

    def _list_remote_workflow_revisions(self, workflow_id: str) -> list[dict[str, Any]]:
        client = self._get_client()
        if client is None:
            return []
        try:
            response = client.list_workflow_revisions(workflow_id)
        except Exception as exc:
            logger.debug("Workflow revision listing unavailable for %s: %s", workflow_id, exc)
            return []
        revisions = response.get("revisions", [])
        if not isinstance(revisions, list):
            return []
        return [
            hydrate_workflow_payload(revision)
            for revision in revisions
            if isinstance(revision, dict)
        ]

    def _get_remote_workflow_revision(
        self,
        workflow_id: str,
        revision_id: str,
    ) -> dict[str, Any] | None:
        client = self._get_client()
        if client is None:
            return None
        try:
            response = client.get_workflow_revision(workflow_id, revision_id)
        except Exception as exc:
            logger.debug(
                "Workflow revision lookup unavailable for %s/%s: %s",
                workflow_id,
                revision_id,
                exc,
            )
            return None
        revision = response.get("workflow_revision")
        if not isinstance(revision, dict):
            return None
        return hydrate_workflow_payload(revision)

    def _get_client(self) -> APIClient | None:
        if self._client is not None:
            return self._client
        try:
            self._client = self._client_factory()
        except Exception as exc:
            logger.debug("Workflow Studio API client unavailable: %s", exc)
            return None
        return self._client


def _sort_revisions(revisions: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return sorted(
        revisions,
        key=lambda revision: (
            str(revision.get("revision_id") or ""),
            str(revision.get("current_run_id") or ""),
        ),
        reverse=True,
    )


def _filter_workflows_for_view(
    workflows: list[dict[str, Any]],
    *,
    view: Literal["active", "archived", "trash"] | None = None,
) -> list[dict[str, Any]]:
    normalized_view = view or "active"
    filtered: list[dict[str, Any]] = []
    for workflow in workflows:
        archived = bool(workflow.get("archived_at"))
        deleted = bool(workflow.get("deleted_at"))
        if normalized_view == "archived":
            if archived and not deleted:
                filtered.append(workflow)
            continue
        if normalized_view == "trash":
            if deleted:
                filtered.append(workflow)
            continue
        if not archived and not deleted:
            filtered.append(workflow)
    return filtered


def _launch_metadata(record: Any) -> dict[str, Any]:
    request_context = record.request_context if isinstance(record.request_context, dict) else {}
    launch_metadata = request_context.get("launch_metadata")
    return dict(launch_metadata) if isinstance(launch_metadata, dict) else {}


def _build_callback_entries(bundle: WorkflowStudioRunBundle) -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    resume_context = (
        dict(bundle.remote_session.get("pipeline_resume_context"))
        if isinstance(bundle.remote_session.get("pipeline_resume_context"), dict)
        else {}
    )
    stage_content = (
        dict(resume_context.get("pipeline_stage_content"))
        if isinstance(resume_context.get("pipeline_stage_content"), dict)
        else {}
    )
    callback_payload = (
        dict(stage_content.get("callback_payload"))
        if isinstance(stage_content.get("callback_payload"), dict)
        else {}
    )
    for stage in bundle.pipeline_stages:
        last_result = dict(stage.get("last_result") or {})
        metadata = dict(last_result.get("metadata") or {})
        registration = dict(metadata.get("callback_registration") or {})
        callback_id = str(registration.get("callback_id") or "").strip()
        if not callback_id:
            continue
        pending_manual_metadata = dict(stage.get("pending_manual_metadata") or {})
        received_at = str(
            pending_manual_metadata.get("callback_consumed_at") or registration.get("consumed_at") or ""
        ).strip() or None
        expires_at = str(registration.get("expires_at") or "").strip()
        entries.append(
            {
                "callback_id": callback_id,
                "session_id": bundle.record.session_id,
                "run_id": bundle.record.workflow_run_id,
                "workflow_run_id": bundle.record.workflow_run_id,
                "stage_execution_id": registration.get("stage_execution_id")
                or stage.get("stage_execution_id"),
                "stage_name": stage.get("stage_name") or stage.get("trigger"),
                "callback_url": pending_manual_metadata.get("callback_url"),
                "expected_schema": registration.get("expected_schema") or {},
                "expires_at": expires_at,
                "status": _callback_status(
                    expires_at=expires_at,
                    received_at=received_at,
                    callback_payload=callback_payload,
                ),
                "received_at": received_at,
                "payload_received": bool(callback_payload),
            }
        )
    return entries


def _callback_status(
    *,
    expires_at: str,
    received_at: str | None,
    callback_payload: dict[str, Any],
) -> str:
    if received_at or callback_payload:
        return "received"
    if _iso_is_past(expires_at):
        return "expired"
    return "waiting"


def _iso_is_past(value: str) -> bool:
    normalized = str(value or "").strip()
    if not normalized:
        return False
    try:
        return datetime.fromisoformat(normalized) < datetime.now(UTC)
    except ValueError:
        return False
