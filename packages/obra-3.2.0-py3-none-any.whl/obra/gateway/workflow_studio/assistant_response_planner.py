"""Record builders, scaffold enrichment, and utility functions for assistant proposal records."""

from __future__ import annotations

import re
from typing import Any, Callable

from obra.gateway.assistant.proposal_records import build_proposal_record
from obra.gateway.workflow_studio.assistant_types import AssistantLlmResponse
from obra.gateway.workflow_studio.starter_catalog import (
    choose_recommended_starters,
    normalize_starter_domain_id,
)

ACTION_ID_TO_INTENT_ID = {
    "recommend_starters": "recommend_starters",
    "generate_documentation": "generate_documentation",
    "execute_launch_run": "launch_run",
    "execute_approve_operator_review": "approve_operator_review",
    "execute_resolve_escalation": "resolve_escalation",
    "execute_template_edit": "tighten_stage_review_instructions",
    "execute_stage_insert": "insert_stage",
    "execute_stage_remove": "remove_stage",
    "execute_stage_update": "update_stage",
    "execute_stage_reorder": "reorder_stages",
    "execute_connection_add": "connect_stages",
    "execute_connection_remove": "disconnect_stages",
    "execute_workflow_metadata_update": "update_workflow_metadata",
    "execute_quality_gate_set": "set_quality_gate",
    "execute_batch_mutation": "batch_mutation",
    "execute_draft_workflow_from_thread": "draft_workflow_from_thread",
    "execute_pipeline": "run_pipeline",
}


def _normalize_request_text(value: Any) -> str:
    return " ".join(str(value or "").strip().lower().split())


def _record_action_id(record: dict[str, Any]) -> str:
    return str(record.get("action_id") or record.get("action_type") or "").strip()


def _record_intent_id(record: dict[str, Any]) -> str | None:
    action_id = _record_action_id(record)
    if action_id in ACTION_ID_TO_INTENT_ID:
        return ACTION_ID_TO_INTENT_ID[action_id]
    if action_id.startswith("propose_"):
        return action_id.removeprefix("propose_")
    return None


def _string_field(value: Any) -> str | None:
    text = str(value or "").strip()
    return text or None


def _conversation_text(resolved_context: dict[str, Any] | None) -> str:
    turns = (resolved_context or {}).get("all_turns") or []
    return "\n".join(
        str(turn.get("message") or "")
        for turn in turns
        if isinstance(turn, dict) and turn.get("role") == "user"
    ).lower()


def _ui_context(resolved_context: dict[str, Any] | None) -> dict[str, Any]:
    ui_context = (resolved_context or {}).get("ui_context") or {}
    return ui_context if isinstance(ui_context, dict) else {}


def _infer_domain_id(resolved_context: dict[str, Any] | None) -> str:
    explicit_domain = normalize_starter_domain_id((resolved_context or {}).get("domain_id"))
    if explicit_domain:
        return explicit_domain
    ui_domain = normalize_starter_domain_id(_ui_context(resolved_context).get("domain_id"))
    if ui_domain:
        return ui_domain
    workflow = (resolved_context or {}).get("workflow") or {}
    if isinstance(workflow, dict):
        workflow_domain = normalize_starter_domain_id(
            workflow.get("domain_id") or workflow.get("domain")
        )
        if workflow_domain:
            return workflow_domain
    conversation_text = _conversation_text(resolved_context)
    if any(
        keyword in conversation_text
        for keyword in ("code", "test", "bug", "frontend", "backend", "api")
    ):
        return "software"
    return "business"


def _compose_request_text(
    user_message: str,
    resolved_context: dict[str, Any] | None,
) -> str:
    return f"{_conversation_text(resolved_context)}\n{user_message}".strip().lower()


def _recommend_starter_payload(
    user_message: str,
    resolved_context: dict[str, Any] | None,
) -> tuple[dict[str, Any] | None, list[dict[str, Any]]]:
    domain_id = _infer_domain_id(resolved_context)
    ranked = choose_recommended_starters(
        domain_id=domain_id,
        request_text=_compose_request_text(user_message, resolved_context),
        limit=3,
    )
    if not ranked:
        return None, []

    def _shape(starter: dict[str, Any]) -> dict[str, Any]:
        return {
            "id": str(starter.get("id") or ""),
            "domain_id": normalize_starter_domain_id(starter.get("domain_id") or domain_id),
            "title": str(starter.get("title") or ""),
            "description": str(starter.get("description") or ""),
            "intended_use_cases": starter.get("intended_use_cases") or [],
            "stages": starter.get("stages") or [],
        }

    return _shape(ranked[0]), [_shape(starter) for starter in ranked[1:]]


def _stage_binding(stage_id: str, path_hint: str) -> dict[str, Any]:
    return {
        "binding_role": "primary_stage_instruction",
        "binding_scope": "stage",
        "stage_id": stage_id,
        "target_artifact_type": "stage_asset",
        "target_artifact_id": path_hint,
        "target_version_selector": "v1",
        "relationship_type": "binds_to",
        "path_hint": path_hint,
        "content_format": "markdown",
        "adoption_state": "approved_for_execution",
        "adoption_metadata": {},
        "materialization_metadata": {"path": path_hint},
    }


def _quality_loop(checkpoint: str) -> dict[str, Any]:
    return {
        "entry": {"when": "after_stage_runner"},
        "routing": {
            "on_pass": "continue",
            "on_advisory_pass": "continue_with_findings",
            "on_revise_required": "revise_same_stage",
            "on_block": "block_stage",
            "on_escalate": "escalate",
            "on_pending_manual": "wait_for_manual_action",
            "on_manual_resume": "resume_stage",
        },
        "evaluators": [
            {
                "runner": "quality.sense_check",
                "subject": "current_stage_output",
                "required": True,
            }
        ],
        "aggregation": {"strategy": "all_required_pass"},
        "thresholds": {"max_total_findings": 3},
        "pending_manual": {
            "required_action": "approve_revision",
            "resume": {"checkpoint": checkpoint, "strategy": "resume_stage"},
        },
    }


def _default_scaffold_title(
    user_message: str,
    resolved_context: dict[str, Any] | None,
) -> str:
    """Infer a draft title from the first user request in the thread."""
    title = "Assistant Drafted Workflow"
    turns = (resolved_context or {}).get("all_turns") or []
    first_user = next(
        (
            str(turn.get("message") or "")[:80]
            for turn in turns
            if isinstance(turn, dict) and turn.get("role") == "user"
        ),
        user_message[:80],
    )
    if len(first_user) > 60:
        first_user = first_user[:60].rsplit(" ", 1)[0]
    if first_user:
        title = first_user
    return title


def _first_user_request(
    user_message: str,
    resolved_context: dict[str, Any] | None,
) -> str:
    turns = (resolved_context or {}).get("all_turns") or []
    first_user = next(
        (
            str(turn.get("message") or "").strip()
            for turn in turns
            if isinstance(turn, dict)
            and turn.get("role") == "user"
            and str(turn.get("message") or "").strip()
        ),
        "",
    )
    return first_user or str(user_message or "").strip()


def _titleize_stage_phrase(phrase: str) -> str:
    words = [word for word in re.split(r"\s+", phrase.strip()) if word]
    titled: list[str] = []
    for word in words:
        if word.upper() in {"IT", "HR", "QA", "PRD", "API"}:
            titled.append(word.upper())
        else:
            titled.append(word.capitalize())
    return " ".join(titled)


def _default_workflow_top_level(
    *,
    title: str,
    domain_id: str,
    description: str,
) -> dict[str, Any]:
    return {
        "title": title,
        "domain_id": domain_id,
        "description": description,
        "compile_ready": True,
        "quality_dimensions": ["docs_analysis"] if domain_id == "business" else ["code_quality"],
        "lifecycle_capabilities": ["derive", "review", "execute", "wait_resume"],
    }


def _default_stage_category(index: int, total: int) -> str:
    if index == 0:
        return "intake"
    if index == total - 1:
        return "delivery"
    return "automation"


def _default_stage_type(title: str, index: int) -> str:
    if index == 0:
        return "analysis"
    lowered = title.lower()
    if any(
        keyword in lowered
        for keyword in ("review", "approve", "approval", "qa", "quality", "check")
    ):
        return "review"
    return "analysis"


def _default_stage_outputs(stage_id: str, title: str) -> list[str]:
    lowered = title.lower()
    if "review" in lowered:
        return ["review-decision"]
    if "approve" in lowered:
        return ["approval-decision"]
    return [f"{stage_id}-output"]


def _default_stage_inputs(stage_id: str, depends_on: list[str], index: int) -> list[str]:
    if index == 0:
        return ["source-request"]
    return [f"{dependency}-output" for dependency in depends_on] or [f"{stage_id}-input"]


def _default_stage_verification(title: str, purpose: str) -> list[str]:
    return [f"{title} output satisfies the stage purpose: {purpose}"]


def _default_stage_diagram(index: int, total: int) -> dict[str, Any]:
    category = _default_stage_category(index, total)
    return {
        "lane_id": category,
        "category": category,
    }


def _normalize_string_list(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    return [str(item).strip() for item in value if str(item).strip()]


def _enrich_scaffold_stage(
    stage: dict[str, Any],
    *,
    index: int,
    total: int,
    domain_id: str,
) -> dict[str, Any]:
    stage_id = str(stage.get("id") or "").strip()
    title = str(stage.get("title") or stage_id).strip()
    purpose = str(stage.get("purpose") or "").strip()
    depends_on = _normalize_string_list(stage.get("depends_on"))
    default_outputs = _default_stage_outputs(stage_id, title)
    enriched = dict(stage)
    enriched["id"] = stage_id
    enriched["title"] = title
    enriched["purpose"] = purpose
    enriched["depends_on"] = depends_on
    enriched["stage_type"] = str(
        enriched.get("stage_type") or _default_stage_type(title, index)
    ).strip()
    enriched["inputs"] = _normalize_string_list(enriched.get("inputs")) or _default_stage_inputs(
        stage_id,
        depends_on,
        index,
    )
    enriched["outputs"] = _normalize_string_list(enriched.get("outputs")) or default_outputs
    enriched["rules"] = _normalize_string_list(enriched.get("rules")) or ["workflow-safety"]
    enriched["quality_gates"] = _normalize_string_list(enriched.get("quality_gates")) or (
        ["docs_analysis"] if domain_id == "business" else ["code_quality"]
    )
    template_path = f"templates/{domain_id}/{stage_id}.md"
    bindings = enriched.get("template_asset_bindings")
    enriched["template_asset_bindings"] = (
        [binding for binding in bindings if isinstance(binding, dict)]
        if isinstance(bindings, list) and bindings
        else [_stage_binding(stage_id, template_path)]
    )
    enriched["verification"] = _normalize_string_list(
        enriched.get("verification")
    ) or _default_stage_verification(
        title,
        purpose,
    )
    runner = enriched.get("runner")
    enriched["runner"] = (
        dict(runner) if isinstance(runner, dict) and runner else {"runner_id": "docs"}
    )
    quality_loop = enriched.get("quality_loop")
    enriched["quality_loop"] = (
        dict(quality_loop)
        if isinstance(quality_loop, dict) and quality_loop
        else _quality_loop(f"{stage_id}-loop")
    )
    diagram = enriched.get("diagram")
    if isinstance(diagram, dict):
        category = str(diagram.get("category") or "").strip()
        lane_id = str(diagram.get("lane_id") or "").strip()
        if category and lane_id:
            enriched["diagram"] = dict(diagram)
        else:
            enriched["diagram"] = {
                **_default_stage_diagram(index, total),
                **dict(diagram),
            }
    else:
        enriched["diagram"] = _default_stage_diagram(index, total)
    return enriched


def _resolve_workflow_ref(resolved_context: dict[str, Any] | None) -> tuple[str | None, str | None]:
    resolved_context = resolved_context or {}
    ui_context = resolved_context.get("ui_context") or {}
    projection = ui_context.get("semantic_projection") if isinstance(ui_context, dict) else {}
    if isinstance(projection, dict):
        workflow_id = str(projection.get("workflow_id") or "").strip() or None
        revision_id = str(projection.get("expected_revision_id") or "").strip() or None
        if workflow_id or revision_id:
            return workflow_id, revision_id
    direct_workflow_id = str(resolved_context.get("workflow_id") or "").strip() or None
    direct_revision_id = str(resolved_context.get("revision_id") or "").strip() or None
    if direct_workflow_id or direct_revision_id:
        return direct_workflow_id, direct_revision_id
    workflow = resolved_context.get("workflow") or {}
    if isinstance(workflow, dict):
        return (
            str(workflow.get("workflow_id") or "") or None,
            str(workflow.get("latest_revision_id") or workflow.get("revision_id") or "") or None,
        )
    return None, None


def _workflow_stages(resolved_context: dict[str, Any] | None) -> list[dict[str, Any]]:
    workflow = (resolved_context or {}).get("workflow") or {}
    if not isinstance(workflow, dict):
        return []
    stages = workflow.get("workflow_definition", {}).get("stages") or workflow.get("stages") or []
    return [stage for stage in stages if isinstance(stage, dict)]


def _stage_identifier(stage: dict[str, Any]) -> str:
    return str(stage.get("stage_id") or stage.get("id") or "").strip()


def _stage_title(stage: dict[str, Any]) -> str:
    return str(stage.get("title") or stage.get("name") or _stage_identifier(stage)).strip()


def _selected_stage_id(resolved_context: dict[str, Any] | None) -> str | None:
    ui_context = _ui_context(resolved_context)
    projection = ui_context.get("semantic_projection")
    if isinstance(projection, dict):
        detail = projection.get("selected_stage_detail")
        if isinstance(detail, dict):
            stage_id = str(detail.get("stage_id") or "").strip()
            if stage_id:
                return stage_id
    selected_nodes = ui_context.get("selected_nodes") or []
    if isinstance(selected_nodes, list) and selected_nodes:
        stage_id = str(selected_nodes[0]).strip()
        if stage_id:
            return stage_id
    return None


def _stage_lookup(resolved_context: dict[str, Any] | None) -> dict[str, str]:
    lookup: dict[str, str] = {}

    def _register_aliases(value: str, stage_id: str) -> None:
        normalized = str(value or "").strip().lower()
        if not normalized:
            return
        lookup[normalized] = stage_id
        slug = _slugify_stage_id(normalized)
        if slug:
            lookup[slug] = stage_id
            lookup[slug.replace("-", "_")] = stage_id

    for stage in _workflow_stages(resolved_context):
        stage_id = _stage_identifier(stage)
        if not stage_id:
            continue
        _register_aliases(stage_id, stage_id)
        _register_aliases(_stage_title(stage), stage_id)
    selected_stage_id = _selected_stage_id(resolved_context)
    if selected_stage_id:
        lookup["selected"] = selected_stage_id
        lookup["selected stage"] = selected_stage_id
        lookup["this stage"] = selected_stage_id
        lookup["current stage"] = selected_stage_id
    return lookup


def _resolve_stage_id(value: Any, resolved_context: dict[str, Any] | None) -> str | None:
    text = str(value or "").strip()
    if not text:
        return None
    lookup = _stage_lookup(resolved_context)
    return lookup.get(text.lower()) or text


def _slugify_stage_id(value: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", value.strip().lower()).strip("-")
    return slug or "new-stage"


def _workflow_mutation_boundary_message(resolved_context: dict[str, Any] | None) -> str | None:
    ui_context = _ui_context(resolved_context)
    if ui_context.get("has_conflict"):
        return (
            "The visible workflow draft is in conflict with a newer saved revision. Reload or "
            "reapply your draft before I prepare an executable workflow mutation."
        )
    if ui_context.get("dirty"):
        return (
            "The visible workflow draft has unsaved local changes. Save, discard, or reload the "
            "draft before I prepare an executable workflow mutation against the persisted workflow."
        )
    return None


def _find_named_stage_ids(
    lower_message: str,
    resolved_context: dict[str, Any] | None,
) -> list[str]:
    stage_ids: list[str] = []
    for stage in _workflow_stages(resolved_context):
        stage_id = _stage_identifier(stage)
        stage_title = _stage_title(stage).lower()
        if not stage_id:
            continue
        if stage_id.lower() in lower_message or stage_title in lower_message:
            stage_ids.append(stage_id)
    selected_stage_id = _selected_stage_id(resolved_context)
    if selected_stage_id and selected_stage_id not in stage_ids:
        stage_ids.insert(0, selected_stage_id)
    return stage_ids


def _default_template_after_content(
    *,
    subject: str,
    instruction_focus: str,
) -> str:
    focus_text = f" Focus especially on {instruction_focus}." if instruction_focus else ""
    return (
        "Review the current output against explicit acceptance criteria, explain any quality gaps "
        f"grounded in {subject}, and state the correction or escalation path before moving on.{focus_text}"
    )


def _record_target_metadata(record: dict[str, Any]) -> dict[str, Any]:
    action_inputs = record.get("action_inputs")
    action_inputs = action_inputs if isinstance(action_inputs, dict) else {}
    metadata: dict[str, Any] = {}

    for key in (
        "workflow_id",
        "stage_id",
        "starter_id",
        "domain_id",
        "template_role",
        "source_stage_id",
        "target_stage_id",
        "run_id",
        "escalation_id",
        "choice",
        "output_review_finding_id",
    ):
        value = _string_field(record.get(key) or action_inputs.get(key))
        if value is not None:
            metadata[key] = value

    updates = record.get("updates") or action_inputs.get("updates")
    if isinstance(updates, dict):
        metadata["updated_fields"] = sorted(str(key) for key in updates if str(key).strip())

    ordered_stage_ids = record.get("ordered_stage_ids") or action_inputs.get("ordered_stage_ids")
    if isinstance(ordered_stage_ids, list):
        metadata["ordered_stage_ids"] = [
            str(item) for item in ordered_stage_ids if str(item).strip()
        ]

    operations = record.get("operations") or action_inputs.get("operations")
    if isinstance(operations, list):
        metadata["operation_count"] = len([item for item in operations if isinstance(item, dict)])

    proposed_stage = record.get("proposed_stage") or action_inputs.get("stage_definition")
    if isinstance(proposed_stage, dict):
        title = _string_field(proposed_stage.get("title"))
        if title is not None:
            metadata["proposed_stage_title"] = title
        stage_id = _string_field(proposed_stage.get("stage_id") or proposed_stage.get("id"))
        if stage_id is not None:
            metadata["proposed_stage_id"] = stage_id

    removed_stage = record.get("removed_stage")
    if isinstance(removed_stage, dict):
        title = _string_field(removed_stage.get("title"))
        if title is not None:
            metadata["removed_stage_title"] = title

    starter = record.get("starter")
    if isinstance(starter, dict):
        title = _string_field(starter.get("title"))
        if title is not None:
            metadata["starter_title"] = title

    return metadata


def _summary_with_workflow(
    action: str,
    value: str | None,
    workflow_id: str | None,
) -> str | None:
    if value and workflow_id:
        return f"{action} '{value}' in workflow {workflow_id}"
    return None


def _insert_stage_target_summary(metadata: dict[str, Any]) -> str | None:
    title = metadata.get("proposed_stage_title") or metadata.get("proposed_stage_id")
    workflow_id = metadata.get("workflow_id")
    return _summary_with_workflow("insert stage", title, workflow_id)


def _remove_stage_target_summary(metadata: dict[str, Any]) -> str | None:
    title = metadata.get("removed_stage_title") or metadata.get("stage_id")
    workflow_id = metadata.get("workflow_id")
    if title and workflow_id:
        return f"remove stage '{title}' from workflow {workflow_id}"
    return None


def _update_stage_target_summary(metadata: dict[str, Any]) -> str | None:
    return _summary_with_workflow("update stage", metadata.get("stage_id"), metadata.get("workflow_id"))


def _connection_target_summary(intent_id: str, metadata: dict[str, Any]) -> str | None:
    source = metadata.get("source_stage_id")
    target = metadata.get("target_stage_id")
    if source and target:
        verb = "connect" if intent_id == "connect_stages" else "disconnect"
        return f"{verb} {source} -> {target}"
    return None


def _reorder_stages_target_summary(metadata: dict[str, Any]) -> str | None:
    ordered = metadata.get("ordered_stage_ids") or []
    if ordered:
        return f"reorder stages to {' -> '.join(str(item) for item in ordered)}"
    return None


def _update_workflow_metadata_target_summary(metadata: dict[str, Any]) -> str | None:
    workflow_id = metadata.get("workflow_id")
    if workflow_id:
        return f"update workflow metadata for {workflow_id}"
    return None


def _set_quality_gate_target_summary(metadata: dict[str, Any]) -> str | None:
    stage_id = metadata.get("stage_id")
    workflow_id = metadata.get("workflow_id")
    if stage_id and workflow_id:
        return f"set a quality gate on stage '{stage_id}' in workflow {workflow_id}"
    return None


def _batch_mutation_target_summary(metadata: dict[str, Any]) -> str | None:
    workflow_id = metadata.get("workflow_id")
    operation_count = metadata.get("operation_count")
    if workflow_id and operation_count:
        return f"apply {operation_count} workflow changes to {workflow_id}"
    return None


def _tighten_stage_review_target_summary(metadata: dict[str, Any]) -> str | None:
    stage_id = metadata.get("stage_id")
    template_role = metadata.get("template_role")
    if stage_id:
        return f"tighten {template_role or 'stage'} instructions for {stage_id}"
    return None


def _recommend_starters_target_summary(metadata: dict[str, Any]) -> str | None:
    title = metadata.get("starter_title") or metadata.get("starter_id")
    domain_id = metadata.get("domain_id")
    if title and domain_id:
        return f"recommend starter '{title}' for {domain_id}"
    return None


def _generate_documentation_target_summary(metadata: dict[str, Any]) -> str | None:
    workflow_id = metadata.get("workflow_id")
    if workflow_id:
        return f"generate documentation for workflow {workflow_id}"
    return None


def _draft_workflow_target_summary(_metadata: dict[str, Any]) -> str | None:
    return "draft a new workflow from the current thread"


def _launch_run_target_summary(metadata: dict[str, Any]) -> str | None:
    workflow_id = metadata.get("workflow_id")
    if workflow_id:
        return f"launch a run for workflow {workflow_id}"
    return None


def _run_pipeline_target_summary(metadata: dict[str, Any]) -> str | None:
    pipeline_id = metadata.get("pipeline_id")
    workflow_id = metadata.get("workflow_id")
    if pipeline_id and workflow_id:
        return f"run pipeline '{pipeline_id}' for workflow {workflow_id}"
    return None


_TARGET_SUMMARY_BUILDERS: dict[str, Callable[[dict[str, Any]], str | None]] = {
    "insert_stage": _insert_stage_target_summary,
    "remove_stage": _remove_stage_target_summary,
    "update_stage": _update_stage_target_summary,
    "reorder_stages": _reorder_stages_target_summary,
    "update_workflow_metadata": _update_workflow_metadata_target_summary,
    "set_quality_gate": _set_quality_gate_target_summary,
    "batch_mutation": _batch_mutation_target_summary,
    "tighten_stage_review_instructions": _tighten_stage_review_target_summary,
    "recommend_starters": _recommend_starters_target_summary,
    "generate_documentation": _generate_documentation_target_summary,
    "draft_workflow_from_thread": _draft_workflow_target_summary,
    "launch_run": _launch_run_target_summary,
    "run_pipeline": _run_pipeline_target_summary,
}


def _target_summary(intent_id: str, metadata: dict[str, Any]) -> str | None:
    if intent_id in {"connect_stages", "disconnect_stages"}:
        return _connection_target_summary(intent_id, metadata)
    builder = _TARGET_SUMMARY_BUILDERS.get(intent_id)
    if builder is None:
        return None
    return builder(metadata)


def _record_status(
    turn: dict[str, Any],
    record: dict[str, Any],
    *,
    has_any_accepted: bool,
) -> str:
    if bool(record.get("reverted")):
        return "reverted"
    record_status = _normalize_request_text(record.get("status"))
    if record_status in {"accepted", "applied"}:
        return "accepted"
    if record_status == "reverted":
        return "reverted"
    if record_status == "rejected":
        return "rejected"
    if record_status == "conflict":
        return "conflict"
    if record_status == "superseded":
        return "superseded"

    turn_outcome = _normalize_request_text(turn.get("outcome"))
    if turn_outcome == "applied":
        return "superseded" if has_any_accepted else "accepted"
    if turn_outcome == "reverted":
        return "reverted"
    if turn_outcome == "rejected":
        return "rejected"
    if turn_outcome == "conflict":
        return "conflict"
    return "pending"


def build_recent_guided_decision_context(
    all_turns: list[dict[str, Any]] | None,
    *,
    limit: int = 10,
) -> list[dict[str, Any]]:
    """Build structured recent guided decision context from prior thread turns."""
    if not all_turns:
        return []

    recent: list[dict[str, Any]] = []
    last_user_message = ""
    for turn in all_turns:
        if not isinstance(turn, dict):
            continue
        role = str(turn.get("role") or "").strip()
        if role == "user":
            last_user_message = str(turn.get("message") or "")
            continue
        if role != "assistant":
            continue
        raw_records = turn.get("action_records")
        if not isinstance(raw_records, list) or not raw_records:
            continue
        proposal_records = [
            record
            for record in raw_records
            if isinstance(record, dict) and _record_intent_id(record) is not None
        ]
        if not proposal_records:
            continue
        accepted_ids = {
            id(record)
            for record in proposal_records
            if _normalize_request_text(record.get("status")) in {"accepted", "applied"}
        }
        for record in proposal_records:
            intent_id = _record_intent_id(record)
            if intent_id is None:
                continue
            metadata = _record_target_metadata(record)
            recent.append(
                {
                    "intent_id": intent_id,
                    "request_text": _normalize_request_text(last_user_message),
                    "status": _record_status(
                        turn,
                        record,
                        has_any_accepted=bool(accepted_ids) and id(record) not in accepted_ids,
                    ),
                    "target_summary": _target_summary(intent_id, metadata),
                    "target_metadata": metadata,
                    "turn_id": str(turn.get("turn_id") or ""),
                    "created_at": str(turn.get("created_at") or ""),
                }
            )
    return recent[-limit:]


def _build_stage_definition(
    intent_args: dict[str, Any],
    resolved_context: dict[str, Any] | None,
) -> tuple[dict[str, Any], str | None]:
    title = str(intent_args.get("title") or "").strip() or "New Stage"
    stage_id = str(intent_args.get("stage_id") or "").strip() or _slugify_stage_id(title)
    after_stage_id = _resolve_stage_id(intent_args.get("after_stage_id"), resolved_context)

    depends_on_raw = intent_args.get("depends_on")
    depends_on: list[str] = []
    if isinstance(depends_on_raw, list):
        depends_on = [
            resolved
            for item in depends_on_raw
            if (resolved := _resolve_stage_id(item, resolved_context)) is not None
        ]
    elif after_stage_id:
        depends_on = [after_stage_id]

    stage_type = str(
        intent_args.get("stage_type") or intent_args.get("category") or "analysis"
    ).strip()
    category = str(intent_args.get("category") or stage_type).strip()
    lane_id = str(intent_args.get("lane_id") or "").strip()

    stage_definition: dict[str, Any] = {
        "stage_id": stage_id,
        "id": stage_id,
        "title": title,
        "purpose": str(intent_args.get("purpose") or "").strip(),
        "stage_type": stage_type,
        "category": category,
        "depends_on": depends_on,
    }
    if lane_id or category:
        stage_definition["diagram"] = {
            **({"lane_id": lane_id} if lane_id else {}),
            **({"category": category} if category else {}),
        }
    return stage_definition, after_stage_id


def _build_insert_stage_record(
    *,
    workflow_id: str,
    revision_id: str | None,
    stage_definition: dict[str, Any],
    after_stage_id: str | None,
    explanation: str,
    resolved_context: dict[str, Any] | None,
) -> AssistantLlmResponse:
    stages = _workflow_stages(resolved_context)
    insertion_index = 0
    if after_stage_id:
        for index, stage in enumerate(stages):
            if _stage_identifier(stage) == after_stage_id:
                insertion_index = index + 1
                break
    previous_stage = (
        stages[insertion_index - 1]
        if insertion_index > 0 and insertion_index - 1 < len(stages)
        else None
    )
    next_stage = stages[insertion_index] if insertion_index < len(stages) else None
    return AssistantLlmResponse(
        message=explanation,
        outcome="proposal",
        action_records=[
            build_proposal_record(
                action_id="execute_stage_insert",
                action_type="propose_stage_insert",
                action_inputs={
                    "workflow_id": workflow_id,
                    "after_stage_id": after_stage_id,
                    "stage_definition": stage_definition,
                    "expected_revision_id": revision_id or "",
                },
                preview_type="scaffold",
                workflow_id=workflow_id,
                proposed_stage=stage_definition,
                insertion_index=insertion_index,
                surrounding_stages={
                    "previous": _stage_title(previous_stage)
                    if isinstance(previous_stage, dict)
                    else None,
                    "next": _stage_title(next_stage) if isinstance(next_stage, dict) else None,
                },
            )
        ],
    )


def _build_remove_stage_record(
    *,
    workflow_id: str,
    revision_id: str | None,
    stage_id: str,
    explanation: str,
    resolved_context: dict[str, Any] | None,
) -> AssistantLlmResponse:
    stages = _workflow_stages(resolved_context)
    target = next((stage for stage in stages if _stage_identifier(stage) == stage_id), None)
    affected_connections = []
    for stage in stages:
        if stage_id in (stage.get("depends_on") or []):
            affected_connections.append(
                {
                    "stage_id": _stage_identifier(stage),
                    "title": _stage_title(stage),
                    "relationship": "depends_on_removed",
                }
            )
    return AssistantLlmResponse(
        message=explanation,
        outcome="proposal",
        action_records=[
            build_proposal_record(
                action_id="execute_stage_remove",
                action_type="propose_stage_remove",
                action_inputs={
                    "workflow_id": workflow_id,
                    "stage_id": stage_id,
                    "expected_revision_id": revision_id or "",
                },
                preview_type="diff",
                workflow_id=workflow_id,
                removed_stage={
                    "stage_id": stage_id,
                    "title": _stage_title(target) if isinstance(target, dict) else stage_id,
                },
                affected_connections=affected_connections,
            )
        ],
    )


def _build_stage_update_record(
    *,
    workflow_id: str,
    revision_id: str | None,
    stage_id: str,
    updates: dict[str, Any],
    explanation: str,
    resolved_context: dict[str, Any] | None,
) -> AssistantLlmResponse:
    stages = _workflow_stages(resolved_context)
    target = next((stage for stage in stages if _stage_identifier(stage) == stage_id), None)
    before_stage = dict(target) if isinstance(target, dict) else {}
    after_stage = dict(before_stage)
    after_stage.update(updates)
    return AssistantLlmResponse(
        message=explanation,
        outcome="proposal",
        action_records=[
            build_proposal_record(
                action_id="execute_stage_update",
                action_type="propose_stage_update",
                action_inputs={
                    "workflow_id": workflow_id,
                    "stage_id": stage_id,
                    "updates": updates,
                    "expected_revision_id": revision_id or "",
                },
                preview_type="diff",
                workflow_id=workflow_id,
                stage_id=stage_id,
                updates=updates,
                changed_fields=sorted(str(key) for key in updates),
                before_stage=before_stage,
                after_stage=after_stage,
            )
        ],
    )


def _build_reorder_stage_record(
    *,
    workflow_id: str,
    revision_id: str | None,
    ordered_stage_ids: list[str],
    explanation: str,
    resolved_context: dict[str, Any] | None,
) -> AssistantLlmResponse:
    stages = _workflow_stages(resolved_context)
    stage_map = {_stage_identifier(stage): stage for stage in stages}
    before_order = [
        {"stage_id": _stage_identifier(stage), "title": _stage_title(stage)}
        for stage in stages
        if _stage_identifier(stage)
    ]
    after_order = [
        {
            "stage_id": stage_id,
            "title": _stage_title(stage_map.get(stage_id, {"stage_id": stage_id})),
        }
        for stage_id in ordered_stage_ids
    ]
    return AssistantLlmResponse(
        message=explanation,
        outcome="proposal",
        action_records=[
            build_proposal_record(
                action_id="execute_stage_reorder",
                action_type="propose_stage_reorder",
                action_inputs={
                    "workflow_id": workflow_id,
                    "ordered_stage_ids": ordered_stage_ids,
                    "expected_revision_id": revision_id or "",
                },
                preview_type="diff",
                workflow_id=workflow_id,
                before_order=before_order,
                after_order=after_order,
            )
        ],
    )


def _build_workflow_metadata_record(
    *,
    workflow_id: str,
    revision_id: str | None,
    updates: dict[str, Any],
    explanation: str,
    resolved_context: dict[str, Any] | None,
) -> AssistantLlmResponse:
    workflow = (resolved_context or {}).get("workflow") or {}
    workflow_definition = workflow.get("workflow_definition") if isinstance(workflow, dict) else {}
    workflow_definition = workflow_definition if isinstance(workflow_definition, dict) else {}
    before_metadata = {key: workflow_definition.get(key) for key in updates}
    after_metadata = dict(before_metadata)
    after_metadata.update(updates)
    return AssistantLlmResponse(
        message=explanation,
        outcome="proposal",
        action_records=[
            build_proposal_record(
                action_id="execute_workflow_metadata_update",
                action_type="propose_workflow_metadata_update",
                action_inputs={
                    "workflow_id": workflow_id,
                    "updates": updates,
                    "expected_revision_id": revision_id or "",
                },
                preview_type="diff",
                workflow_id=workflow_id,
                updates=updates,
                changed_fields=sorted(str(key) for key in updates),
                before_metadata=before_metadata,
                after_metadata=after_metadata,
            )
        ],
    )


def _build_connection_record(
    *,
    workflow_id: str,
    revision_id: str | None,
    source_stage_id: str,
    target_stage_id: str,
    action: str,
    explanation: str,
    resolved_context: dict[str, Any] | None,
) -> AssistantLlmResponse:
    stage_map = {_stage_identifier(stage): stage for stage in _workflow_stages(resolved_context)}
    edge = {
        "source_stage_id": source_stage_id,
        "source_title": _stage_title(stage_map.get(source_stage_id, {"stage_id": source_stage_id})),
        "target_stage_id": target_stage_id,
        "target_title": _stage_title(stage_map.get(target_stage_id, {"stage_id": target_stage_id})),
    }
    action_id = "execute_connection_add" if action == "add" else "execute_connection_remove"
    action_type = "propose_connection_add" if action == "add" else "propose_connection_remove"
    payload_field = "edge_added" if action == "add" else "edge_removed"
    return AssistantLlmResponse(
        message=explanation,
        outcome="proposal",
        action_records=[
            build_proposal_record(
                action_id=action_id,
                action_type=action_type,
                action_inputs={
                    "workflow_id": workflow_id,
                    "source_stage_id": source_stage_id,
                    "target_stage_id": target_stage_id,
                    "expected_revision_id": revision_id or "",
                },
                preview_type="diff",
                workflow_id=workflow_id,
                **{payload_field: edge},
            )
        ],
    )


def _build_quality_gate_record(
    *,
    workflow_id: str,
    revision_id: str | None,
    stage_id: str,
    quality_loop: dict[str, Any],
    explanation: str,
    resolved_context: dict[str, Any] | None,
) -> AssistantLlmResponse:
    stages = _workflow_stages(resolved_context)
    target = next((stage for stage in stages if _stage_identifier(stage) == stage_id), None)
    before_quality_loop = (
        dict(target.get("quality_loop"))
        if isinstance(target, dict) and isinstance(target.get("quality_loop"), dict)
        else {}
    )
    return AssistantLlmResponse(
        message=explanation,
        outcome="proposal",
        action_records=[
            build_proposal_record(
                action_id="execute_quality_gate_set",
                action_type="propose_quality_gate_set",
                action_inputs={
                    "workflow_id": workflow_id,
                    "stage_id": stage_id,
                    "quality_loop": quality_loop,
                    "expected_revision_id": revision_id or "",
                },
                preview_type="diff",
                workflow_id=workflow_id,
                stage_id=stage_id,
                before_quality_loop=before_quality_loop,
                after_quality_loop=quality_loop,
            )
        ],
    )


def _build_template_edit_response(
    *,
    workflow_id: str,
    revision_id: str | None,
    stage_id: str | None,
    template_role: str,
    before_content: str,
    after_content: str,
    explanation: str,
) -> AssistantLlmResponse:
    return AssistantLlmResponse(
        message=explanation,
        outcome="proposal",
        action_records=[
            build_proposal_record(
                action_id="execute_template_edit",
                action_type="propose_template_edit",
                action_inputs={
                    "workflow_id": workflow_id,
                    "stage_id": stage_id,
                    "template_role": template_role,
                    "proposed_content": after_content,
                    "expected_revision_id": revision_id or "",
                },
                preview_type="diff",
                before_content=before_content,
                after_content=after_content,
                workflow_id=workflow_id,
                stage_id=stage_id,
                template_role=template_role,
            )
        ],
    )


def _build_batch_mutation_record(
    *,
    workflow_id: str,
    revision_id: str | None,
    operations: list[dict[str, Any]],
    explanation: str,
) -> AssistantLlmResponse:
    return AssistantLlmResponse(
        message=explanation,
        outcome="proposal",
        action_records=[
            build_proposal_record(
                action_id="execute_batch_mutation",
                action_type="propose_batch_mutation",
                action_inputs={
                    "workflow_id": workflow_id,
                    "operations": operations,
                    "expected_revision_id": revision_id or "",
                },
                preview_type="diff",
                workflow_id=workflow_id,
                operations=operations,
                operation_count=len(operations),
            )
        ],
    )


def _build_starter_recommendation_record(
    *,
    user_message: str,
    explanation: str,
    resolved_context: dict[str, Any] | None,
) -> AssistantLlmResponse:
    workflow_id, revision_id = _resolve_workflow_ref(resolved_context)
    starter, alternates = _recommend_starter_payload(user_message, resolved_context)
    if starter is None:
        return AssistantLlmResponse(
            message=(
                "I couldn't find a starter that matches the current domain and request. "
                "Set a domain or describe the workflow outcome more specifically."
            )
        )
    return AssistantLlmResponse(
        message=explanation,
        outcome="proposal",
        action_records=[
            build_proposal_record(
                action_id="recommend_starters",
                action_type="propose_starter_recommendation",
                action_inputs={
                    "starter_id": starter["id"],
                    "domain_id": starter["domain_id"],
                    "workflow_id": workflow_id or "",
                    "expected_revision_id": revision_id or "",
                },
                preview_type="starter_recommendation",
                workflow_id=workflow_id,
                expected_revision_id=revision_id or "",
                domain_id=starter["domain_id"],
                starter=starter,
                alternate_starters=alternates,
            )
        ],
    )


def _build_generate_documentation_record(
    *,
    workflow_id: str,
    explanation: str,
) -> AssistantLlmResponse:
    return AssistantLlmResponse(
        message=explanation,
        outcome="proposal",
        action_records=[
            build_proposal_record(
                action_id="generate_documentation",
                action_type="propose_generate_documentation",
                action_inputs={"workflow_id": workflow_id},
                preview_type="documentation",
                workflow_id=workflow_id,
            )
        ],
    )


def _output_review_context(resolved_context: dict[str, Any] | None) -> dict[str, Any]:
    output_review = (resolved_context or {}).get("output_review") or {}
    return output_review if isinstance(output_review, dict) else {}


def _looks_like_output_review_request(
    lower_message: str,
    resolved_context: dict[str, Any] | None,
) -> bool:
    if not _output_review_context(resolved_context):
        return False
    return any(
        keyword in lower_message
        for keyword in (
            "review this output",
            "review these outputs",
            "review this run",
            "review this artifact",
            "review output",
            "review outputs",
            "workflow fix",
            "fix this workflow",
            "suggest a fix",
            "improve this output",
            "quality issue",
            "why is this weak",
        )
    )


def _stage_output_entry(
    output_review: dict[str, Any],
    stage_name: str,
) -> dict[str, Any] | None:
    for entry in output_review.get("intermediate_outputs") or []:
        if not isinstance(entry, dict):
            continue
        if str(entry.get("stage_name") or "").strip() == stage_name:
            return entry
    return None


def _content_text(entry: dict[str, Any] | None) -> str:
    if not isinstance(entry, dict):
        return ""
    return str(entry.get("content_text") or entry.get("content_preview") or "").strip()


def _stage_id_for_output_review(
    output_review: dict[str, Any],
    resolved_context: dict[str, Any] | None,
    stage_name: str,
) -> str | None:
    entry = _stage_output_entry(output_review, stage_name)
    if isinstance(entry, dict):
        stage_id = str(entry.get("stage_id") or "").strip()
        if stage_id:
            return stage_id
    return _resolve_stage_id(stage_name, resolved_context)


def _current_stage_before_content(
    resolved_context: dict[str, Any] | None,
    stage_id: str | None,
    template_role: str,
) -> str:
    if stage_id is None:
        return ""
    for stage in _workflow_stages(resolved_context):
        if _stage_identifier(stage) != stage_id:
            continue
        if template_role == "purpose":
            return str(stage.get("purpose") or stage.get("description") or "").strip()
        return str(stage.get(template_role) or "").strip()
    return ""


def _snippet(text: str, limit: int = 180) -> str:
    normalized = " ".join(str(text).split())
    return normalized[:limit]


def _build_output_review_findings(
    *,
    resolved_context: dict[str, Any] | None,
) -> list[dict[str, Any]]:
    output_review = _output_review_context(resolved_context)
    if not output_review:
        return []

    gather_text = _content_text(_stage_output_entry(output_review, "gather-sources"))
    analyze_text = _content_text(_stage_output_entry(output_review, "analyze-metrics"))
    narrative_text = _content_text(_stage_output_entry(output_review, "draft-narrative"))
    chart_text = _content_text(_stage_output_entry(output_review, "create-charts"))
    final_text = _content_text(output_review.get("selected_output")) or _content_text(
        (output_review.get("final_outputs") or [None])[-1]
        if isinstance(output_review.get("final_outputs"), list)
        else None
    )

    findings: list[dict[str, Any]] = []

    if any(
        keyword in chart_text.lower()
        for keyword in (
            "low resolution",
            "labels overlap",
            "not accessible",
            "reduced quality",
            "colorblind",
            "y-axis scale starts",
        )
    ):
        stage_id = _stage_id_for_output_review(output_review, resolved_context, "create-charts")
        findings.append(
            {
                "id": "chart-quality-guardrails",
                "priority": "P0",
                "title": "Chart stage allows presentation-quality defects through",
                "summary": "The chart output reports accessibility and rendering problems that should block or revise the stage before distribution.",
                "evidence": _snippet(chart_text),
                "stage_id": stage_id,
                "template_role": "purpose",
                "before_content": _current_stage_before_content(
                    resolved_context, stage_id, "purpose"
                ),
                "after_content": (
                    "Generate stakeholder-ready charts only. Validate label readability, color accessibility, "
                    "and axis integrity before completing the stage. If any chart uses reduced-quality rendering, "
                    "overlapping labels, inaccessible colors, or misleading scales, revise the chart package and "
                    "summarize the correction before handing off downstream."
                ),
                "proposal_label": "Tighten chart quality checks",
            }
        )

    if any(
        phrase in narrative_text.lower() or phrase in final_text.lower()
        for phrase in (
            "performed well this quarter",
            "plans to continue growing",
            "marketing campaigns were run",
            "costs were managed",
            "continue current trajectory",
        )
    ):
        stage_id = _stage_id_for_output_review(output_review, resolved_context, "draft-narrative")
        findings.append(
            {
                "id": "narrative-specificity",
                "priority": "P1",
                "title": "Narrative stage permits generic, weakly evidenced summary language",
                "summary": "The report narrative uses vague claims instead of translating the metric analysis into quantified stakeholder-facing conclusions.",
                "evidence": _snippet(narrative_text or final_text),
                "stage_id": stage_id,
                "template_role": "purpose",
                "before_content": _current_stage_before_content(
                    resolved_context, stage_id, "purpose"
                ),
                "after_content": (
                    "Draft a data-backed narrative for non-technical stakeholders. Every summary claim must cite "
                    "the underlying metrics or trend comparison, name the business driver, and avoid vague phrases "
                    "such as 'performed well' or 'continue current trajectory' unless the evidence is explicitly stated."
                ),
                "proposal_label": "Make the narrative evidence-backed",
            }
        )

    if any(
        keyword in gather_text.lower() or keyword in analyze_text.lower()
        for keyword in (
            "not available",
            "partial",
            "estimates",
            "pending final reconciliation",
            "unavailable",
        )
    ):
        stage_id = _stage_id_for_output_review(output_review, resolved_context, "gather-sources")
        findings.append(
            {
                "id": "source-completeness",
                "priority": "P1",
                "title": "Source collection stage does not gate incomplete or provisional inputs",
                "summary": "The run continued despite missing or estimated source data, which weakens every downstream artifact.",
                "evidence": _snippet(gather_text or analyze_text),
                "stage_id": stage_id,
                "template_role": "purpose",
                "before_content": _current_stage_before_content(
                    resolved_context, stage_id, "purpose"
                ),
                "after_content": (
                    "Collect every required quarterly source before completing the stage. Detect missing departments, "
                    "partial spreadsheets, reconciliation gaps, or estimated figures and return a structured deficiency "
                    "report instead of passing partial data to downstream analysis."
                ),
                "proposal_label": "Gate incomplete source inputs",
            }
        )

    if findings:
        return findings

    selected_output = output_review.get("selected_output")
    selected_stage_id = (
        str(selected_output.get("stage_id") or "").strip()
        if isinstance(selected_output, dict)
        else ""
    )
    fallback_stage_id = (
        selected_stage_id
        or _selected_stage_id(resolved_context)
        or _stage_identifier(_workflow_stages(resolved_context)[0])
        if _workflow_stages(resolved_context)
        else None
    )
    fallback_stage_name = (
        str(
            selected_output.get("stage_title")
            or selected_output.get("stage_name")
            or "selected stage"
        )
        if isinstance(selected_output, dict)
        else "selected stage"
    )
    return [
        {
            "id": "output-review-tightening",
            "priority": "P1",
            "title": "Selected output needs stronger acceptance criteria",
            "summary": "The current evidence does not show the stage is checking the output against explicit completeness and quality expectations.",
            "evidence": _snippet(_content_text(selected_output)),
            "stage_id": fallback_stage_id,
            "template_role": "purpose",
            "before_content": _current_stage_before_content(
                resolved_context, fallback_stage_id, "purpose"
            ),
            "after_content": (
                f"Review the {fallback_stage_name} output against explicit acceptance criteria before completing "
                "the stage. Call out missing evidence, quality gaps, and downstream risks, then either revise the "
                "output or return a structured issue summary."
            ),
            "proposal_label": "Tighten output review criteria",
        }
    ]


def _build_output_review_response(
    *,
    workflow_id: str,
    revision_id: str | None,
    explanation: str,
    resolved_context: dict[str, Any] | None,
) -> AssistantLlmResponse:
    output_review = _output_review_context(resolved_context)
    findings = _build_output_review_findings(resolved_context=resolved_context)
    if not findings:
        return AssistantLlmResponse(message=explanation)

    action_records: list[dict[str, Any]] = [
        {
            "action_id": "output_review_findings",
            "action_type": "output_review_findings",
            "preview_type": "output_review_findings",
            "route": output_review.get("route"),
            "run_id": output_review.get("run_id"),
            "selected_artifact_id": output_review.get("selected_artifact_id"),
            "selected_output": output_review.get("selected_output"),
            "findings": [
                {
                    "id": finding["id"],
                    "priority": finding["priority"],
                    "title": finding["title"],
                    "summary": finding["summary"],
                    "evidence": finding["evidence"],
                }
                for finding in findings
            ],
        }
    ]
    for finding in findings:
        action_records.append(
            build_proposal_record(
                action_id="execute_template_edit",
                action_type="propose_template_edit",
                action_inputs={
                    "workflow_id": workflow_id,
                    "stage_id": finding["stage_id"],
                    "template_role": finding["template_role"],
                    "proposed_content": finding["after_content"],
                    "expected_revision_id": revision_id or "",
                },
                preview_type="diff",
                workflow_id=workflow_id,
                stage_id=finding["stage_id"],
                template_role=finding["template_role"],
                before_content=finding["before_content"],
                after_content=finding["after_content"],
                output_review_finding_id=finding["id"],
                output_review_priority=finding["priority"],
                output_review_title=finding["title"],
                output_review_summary=finding["summary"],
                proposal_label=finding["proposal_label"],
            )
        )
    return AssistantLlmResponse(
        message=explanation,
        outcome="proposal",
        action_records=action_records,
    )


def _extract_embedded_json(text: str) -> dict[str, Any] | None:
    """Extract the first JSON object containing a 'message' key from mixed text.

    LLMs sometimes prepend chain-of-thought reasoning before the JSON
    contract.  This helper finds the first ``{...}`` block that parses as
    valid JSON and contains the expected ``message`` field.
    """
    import json as _json

    # Find all potential JSON object start positions
    for match in re.finditer(r"\{", text):
        start = match.start()
        # Walk forward to find balanced braces
        depth = 0
        for i in range(start, len(text)):
            if text[i] == "{":
                depth += 1
            elif text[i] == "}":
                depth -= 1
                if depth == 0:
                    candidate = text[start : i + 1]
                    try:
                        data = _json.loads(candidate)
                        if isinstance(data, dict) and "message" in data:
                            return data
                    except (ValueError, _json.JSONDecodeError):
                        pass
                    break
    return None
