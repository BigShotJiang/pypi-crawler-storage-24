"""Token-budgeted prompt assembly for assistant context."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class SectionStatus:
    """Status of a single section in the assembled prompt."""

    name: str
    status: str  # 'included' | 'truncated' | 'omitted'
    token_estimate: int


@dataclass
class ContextManifest:
    """Record of what the prompt builder included/truncated/omitted."""

    strategy: str = "contextual"
    sections: list[SectionStatus] = field(default_factory=list)
    total_token_estimate: int = 0
    budget: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "strategy": self.strategy,
            "sections": [
                {"name": s.name, "status": s.status, "token_estimate": s.token_estimate}
                for s in self.sections
            ],
            "total_token_estimate": self.total_token_estimate,
            "budget": self.budget,
        }


@dataclass
class _Section:
    """Internal section representation."""

    name: str
    content: str
    priority: int
    token_estimate: int


class PromptBudget:
    """Budget-aware prompt assembly that allocates tokens across sections.

    Sections are added with priorities (lower = higher priority). During
    assembly, sections are included in priority order until the budget is
    exhausted. Lower-priority sections are truncated or omitted.
    """

    def __init__(self, total_budget: int, chars_per_token: int) -> None:
        self._total_budget = total_budget
        self._chars_per_token = chars_per_token
        self._sections: list[_Section] = []

    def estimate_tokens(self, text: str) -> int:
        """Estimate token count from text length."""
        if not text:
            return 0
        return len(text) // self._chars_per_token

    def add_section(self, name: str, content: str, priority: int) -> None:
        """Add a named section with content and priority."""
        if not content:
            return
        self._sections.append(
            _Section(
                name=name,
                content=content,
                priority=priority,
                token_estimate=self.estimate_tokens(content),
            )
        )

    def update_priority(self, name: str, new_priority: int) -> None:
        """Update an existing section's priority."""
        for section in self._sections:
            if section.name == name:
                section.priority = new_priority
                return

    def assemble(self) -> tuple[str, ContextManifest]:
        """Assemble the prompt within budget, returning text and manifest.

        Sections are sorted by priority (ascending). Sections that fit are
        included in full. If a section partially fits, it is truncated with
        a transparency marker. Sections that don't fit are omitted.
        """
        sorted_sections = sorted(self._sections, key=lambda s: s.priority)
        remaining_budget = self._total_budget
        parts: list[str] = []
        section_statuses: list[SectionStatus] = []
        omitted_names: list[str] = []
        total_included_tokens = 0

        for section in sorted_sections:
            if remaining_budget <= 0:
                section_statuses.append(
                    SectionStatus(
                        name=section.name,
                        status="omitted",
                        token_estimate=section.token_estimate,
                    )
                )
                omitted_names.append(section.name)
                continue

            if section.token_estimate <= remaining_budget:
                # Fits entirely
                parts.append(section.content)
                remaining_budget -= section.token_estimate
                total_included_tokens += section.token_estimate
                section_statuses.append(
                    SectionStatus(
                        name=section.name,
                        status="included",
                        token_estimate=section.token_estimate,
                    )
                )
            else:
                # Truncate to fit remaining budget
                available_chars = remaining_budget * self._chars_per_token
                truncated_content = section.content[:available_chars]
                omitted_tokens = section.token_estimate - remaining_budget
                truncated_content += (
                    f"\n[... truncated — {omitted_tokens} tokens omitted from {section.name}]"
                )
                parts.append(truncated_content)
                included_tokens = remaining_budget
                total_included_tokens += included_tokens
                remaining_budget = 0
                section_statuses.append(
                    SectionStatus(
                        name=section.name,
                        status="truncated",
                        token_estimate=section.token_estimate,
                    )
                )

        if omitted_names:
            parts.append(f"[Context omitted due to token budget: {', '.join(omitted_names)}]")

        manifest = ContextManifest(
            sections=section_statuses,
            total_token_estimate=total_included_tokens,
            budget=self._total_budget,
        )

        return "\n\n".join(parts), manifest
