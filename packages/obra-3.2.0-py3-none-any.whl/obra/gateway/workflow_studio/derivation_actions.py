"""Canonical action service for Workflow Studio Stage B derivations."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from obra.gateway.session_manager import SessionManager

_ACCEPT_READY_VALIDATION_OUTCOMES = {"", "pass"}
_OPERATOR_REVIEW_APPROVAL_OUTCOMES = {"pass_with_operator_review"}


class WorkflowDerivationActionService:
    """Dispatch canonical derivation actions through the gateway substrate."""

    def __init__(self, session_manager: SessionManager) -> None:
        self._session_manager = session_manager

    def create(
        self,
        *,
        request_payload: dict[str, Any],
        idempotency_key: str,
        project_id: str,
        working_dir: str | None = None,
    ) -> dict[str, Any]:
        objective = _string_or_none(request_payload.get("mission")) or "Derive workflow"
        record, reused = self._session_manager.create_workflow_derivation(
            objective=objective,
            workflow_derivation_request=request_payload,
            idempotency_key=idempotency_key,
            project_id=project_id,
            working_dir=working_dir,
        )
        return {
            "derivation_id": record.derivation_id,
            "workflow_run_id": record.workflow_run_id,
            "status": "accepted",
            "outcome": "accepted",
            "idempotency_reused": reused,
        }

    def cancel(self, derivation_id: str) -> dict[str, Any]:
        record = self._session_manager.get_session_by_derivation_id(derivation_id)
        self._session_manager.cancel_session(record.session_id)
        return {
            "derivation_id": derivation_id,
            "status": "cancelling",
            "outcome": "accepted",
        }

    def resume(
        self,
        derivation_id: str,
        *,
        resume_target: str | None = None,
    ) -> dict[str, Any]:
        record = self._session_manager.get_session_by_derivation_id(derivation_id)
        resumed = self._session_manager.resume_session(
            record.session_id,
            resume_target=resume_target,
        )
        return {
            "derivation_id": derivation_id,
            "status": resumed.status,
            "outcome": "accepted",
            "resume_target": resume_target,
        }

    def dispatch(
        self,
        derivation_id: str,
        *,
        action: str,
        payload: dict[str, Any],
    ) -> dict[str, Any]:
        record = self._session_manager.get_session_by_derivation_id(derivation_id)
        normalized_action = action.strip().lower()
        if normalized_action in {"cancel"}:
            return self.cancel(derivation_id)
        if normalized_action in {"resume"}:
            return self.resume(
                derivation_id,
                resume_target=_string_or_none(payload.get("resume_target")),
            )
        if normalized_action in {"approve_operator_review", "approve_checkpoints"}:
            state = _update_checkpoint_state(
                self._session_manager,
                record,
                status="no_pending_review",
                clear_points=True,
            )
            _update_record_state(
                record,
                status="completed",
                blocking_summary={
                    "state": "ready_for_acceptance",
                    "required_action": "accept_candidate",
                    "terminal": False,
                },
            )
            return {
                "derivation_id": derivation_id,
                "status": "accepted",
                "outcome": "operator_review_approved",
                "checkpoint_state": state,
            }
        if normalized_action in {"request_revision", "revise"}:
            state = _update_checkpoint_state(
                self._session_manager,
                record,
                status="revision_required",
            )
            _update_record_state(
                record,
                status="running",
                blocking_summary={
                    "state": "revision_required",
                    "required_action": "submit_revision",
                    "terminal": False,
                },
            )
            return {
                "derivation_id": derivation_id,
                "status": "accepted",
                "outcome": "revision_required",
                "checkpoint_state": state,
            }
        if normalized_action in {"submit_revision", "revision_submitted"}:
            state = _update_checkpoint_state(
                self._session_manager,
                record,
                status="revision_submitted",
            )
            _update_record_state(
                record,
                status="completed",
                blocking_summary={
                    "state": "revision_submitted",
                    "required_action": "accept_candidate",
                    "terminal": False,
                },
            )
            return {
                "derivation_id": derivation_id,
                "status": "accepted",
                "outcome": "revision_submitted",
                "checkpoint_state": state,
            }
        return {
            "derivation_id": derivation_id,
            "status": "invalid",
            "outcome": "unsupported_action",
            "action": action,
        }

    def accept(
        self,
        derivation_id: str,
        *,
        expected_baseline_ref: dict[str, Any],
    ) -> dict[str, Any]:
        record = self._session_manager.get_session_by_derivation_id(derivation_id)
        remote_session = dict(record.latest_remote_session or {})
        state = (
            dict(remote_session.get("workflow_derivation_state", {}))
            if isinstance(remote_session.get("workflow_derivation_state"), dict)
            else {}
        )
        current_baseline = (
            dict(state.get("baseline_workflow_ref", {}))
            if isinstance(state.get("baseline_workflow_ref"), dict)
            else {}
        )
        existing_accepted_revision_ref = _accepted_revision_ref_from_state(state)
        if existing_accepted_revision_ref:
            _update_record_state(
                record,
                status="completed",
                blocking_summary={"state": "accepted", "terminal": True},
            )
            return {
                "derivation_id": derivation_id,
                "status": "accepted",
                "outcome": "accepted",
                "accepted_revision_ref": existing_accepted_revision_ref,
            }
        if _workflow_ref_key(current_baseline) != _workflow_ref_key(expected_baseline_ref):
            state["accept_conflict_reason"] = "stale_baseline"
            state["expected_baseline_ref"] = dict(expected_baseline_ref)
            remote_session["workflow_derivation_state"] = state
            self._session_manager.update_remote_snapshot(
                record.session_id, remote_session=remote_session
            )
            _update_record_state(
                record,
                status="running",
                blocking_summary={
                    "state": "conflict",
                    "required_action": "accept_candidate",
                    "terminal": False,
                },
            )
            return {
                "derivation_id": derivation_id,
                "status": "conflict",
                "outcome": "stale_baseline",
                "current_baseline_ref": current_baseline,
            }

        accept_conflict_reason = _accept_conflict_reason_for_state(state)
        if accept_conflict_reason:
            state["accept_conflict_reason"] = accept_conflict_reason
            state["expected_baseline_ref"] = dict(expected_baseline_ref)
            remote_session["workflow_derivation_state"] = state
            self._session_manager.update_remote_snapshot(
                record.session_id, remote_session=remote_session
            )
            _update_record_state(
                record,
                status="running",
                blocking_summary={
                    "state": "conflict",
                    "required_action": "accept_candidate",
                    "terminal": False,
                },
            )
            return {
                "derivation_id": derivation_id,
                "status": "conflict",
                "outcome": accept_conflict_reason,
                "validation_outcome": _validation_outcome_from_state(state),
            }

        accepted_revision_ref = _candidate_revision_ref_from_state(state)
        state["accepted_revision_ref"] = accepted_revision_ref
        state["accept_conflict_reason"] = ""
        state["expected_baseline_ref"] = dict(expected_baseline_ref)
        checkpoint_state = (
            dict(state.get("operator_review_checkpoint_state", {}))
            if isinstance(state.get("operator_review_checkpoint_state"), dict)
            else {}
        )
        checkpoint_state["status"] = "accepted"
        state["operator_review_checkpoint_state"] = checkpoint_state
        remote_session["workflow_derivation_state"] = state
        completion_payload = {
            "derivation_id": derivation_id,
            "accepted_revision_ref": accepted_revision_ref,
        }
        self._session_manager.update_remote_snapshot(
            record.session_id,
            remote_session=remote_session,
            remote_events=_append_remote_event(
                record,
                event_type="workflow_derivation.completed",
                payload=completion_payload,
            ),
        )
        _update_record_state(
            record,
            status="completed",
            blocking_summary={"state": "accepted", "terminal": True},
        )
        record.event_bus.push_event(
            "workflow_derivation.completed",
            completion_payload,
        )
        return {
            "derivation_id": derivation_id,
            "status": "accepted",
            "outcome": "accepted",
            "accepted_revision_ref": accepted_revision_ref,
        }


def _update_checkpoint_state(
    session_manager: SessionManager,
    record: Any,
    *,
    status: str,
    clear_points: bool = False,
) -> dict[str, Any]:
    remote_session = dict(record.latest_remote_session or {})
    state = (
        dict(remote_session.get("workflow_derivation_state", {}))
        if isinstance(remote_session.get("workflow_derivation_state"), dict)
        else {}
    )
    checkpoint_state = (
        dict(state.get("operator_review_checkpoint_state", {}))
        if isinstance(state.get("operator_review_checkpoint_state"), dict)
        else {}
    )
    checkpoint_state["status"] = status
    if clear_points:
        checkpoint_state["pending_count"] = 0
        checkpoint_state["checkpoint_ids"] = []
        checkpoint_state["pending_points"] = []
        state["operator_review_points"] = []
        validation_report = _validation_report_from_state(state)
        if (
            status == "no_pending_review"
            and str(validation_report.get("outcome", "") or "").strip()
            in _OPERATOR_REVIEW_APPROVAL_OUTCOMES
        ):
            validation_report["outcome"] = "pass"
            state["validation_report"] = validation_report
    state["operator_review_checkpoint_state"] = checkpoint_state
    remote_session["workflow_derivation_state"] = state
    session_manager.update_remote_snapshot(record.session_id, remote_session=remote_session)
    return checkpoint_state


def _update_record_state(
    record: Any,
    *,
    status: str,
    blocking_summary: dict[str, Any],
) -> None:
    record.status = status
    record.blocking_summary = dict(blocking_summary)


def _append_remote_event(
    record: Any,
    *,
    event_type: str,
    payload: dict[str, Any],
) -> list[dict[str, Any]]:
    remote_events = [dict(event) for event in (record.latest_remote_events or [])]
    next_sequence = (
        max(
            (
                int(event.get("sequence", -1))
                for event in remote_events
                if isinstance(event.get("sequence"), int)
            ),
            default=-1,
        )
        + 1
    )
    remote_events.append(
        {
            "event_id": f"{record.workflow_run_id}:{next_sequence}",
            "event_type": event_type,
            "timestamp": datetime.now(tz=UTC).isoformat(),
            "sequence": next_sequence,
            "trace_id": record.trace_id,
            "payload": dict(payload),
        }
    )
    return remote_events


def _workflow_ref_key(value: dict[str, Any]) -> tuple[str | None, str | None]:
    return (
        _string_or_none(value.get("workflow_id"))
        or _string_or_none(value.get("target_artifact_id")),
        _string_or_none(value.get("revision_id"))
        or _string_or_none(value.get("target_version_selector")),
    )


def _validation_report_from_state(state: dict[str, Any]) -> dict[str, Any]:
    return (
        dict(state.get("validation_report", {}))
        if isinstance(state.get("validation_report"), dict)
        else {}
    )


def _validation_outcome_from_state(state: dict[str, Any]) -> str:
    return str(_validation_report_from_state(state).get("outcome", "") or "").strip()


def _accepted_revision_ref_from_state(state: dict[str, Any]) -> dict[str, Any]:
    return (
        dict(state.get("accepted_revision_ref", {}))
        if isinstance(state.get("accepted_revision_ref"), dict)
        else {}
    )


def _candidate_revision_ref_from_state(state: dict[str, Any]) -> dict[str, Any]:
    return (
        dict(state.get("derived_workflow_artifact", {}))
        if isinstance(state.get("derived_workflow_artifact"), dict)
        else {}
    )


def _checkpoint_status_from_state(state: dict[str, Any]) -> str:
    checkpoint_state = (
        dict(state.get("operator_review_checkpoint_state", {}))
        if isinstance(state.get("operator_review_checkpoint_state"), dict)
        else {}
    )
    return str(checkpoint_state.get("status", "") or "").strip()


def _accept_conflict_reason_for_state(state: dict[str, Any]) -> str | None:
    validation_outcome = _validation_outcome_from_state(state)
    checkpoint_status = _checkpoint_status_from_state(state)
    if validation_outcome == "fail":
        return "validation_failed"
    if validation_outcome == "revise_required":
        return "validation_revision_required"
    if validation_outcome not in _ACCEPT_READY_VALIDATION_OUTCOMES:
        return "validation_not_accept_ready"
    if checkpoint_status == "pending_review":
        return "operator_review_pending"
    return None


def _string_or_none(value: Any) -> str | None:
    if isinstance(value, str):
        normalized = value.strip()
        if normalized:
            return normalized
    return None
