"""Template-asset projections for Workflow Studio Stage A."""

from __future__ import annotations

from typing import Any

from obra.gateway.workflow_studio.data_access import WorkflowStudioRunBundle


def collect_template_assets(
    bundles: list[WorkflowStudioRunBundle],
) -> dict[str, dict[str, Any]]:
    """Collect template assets from stage binding state across runs."""
    assets: dict[str, dict[str, Any]] = {}
    for bundle in bundles:
        for stage in bundle.pipeline_stages:
            stage_name = str(stage.get("stage_name") or stage.get("trigger") or "")
            stage_execution_id = str(stage.get("stage_execution_id") or "")
            for binding in _coerce_dict_list(stage.get("resolved_stage_asset_bindings")):
                artifact_ref = (
                    binding.get("artifact_ref")
                    if isinstance(binding.get("artifact_ref"), dict)
                    else {}
                )
                asset_id = str(
                    artifact_ref.get("target_artifact_id") or binding.get("materialized_path") or ""
                )
                if not asset_id:
                    continue
                asset = assets.setdefault(
                    asset_id,
                    {
                        "resource_type": "template_asset",
                        "asset_id": asset_id,
                        "bindings": [],
                        "revisions": set(),
                        "content_formats": set(),
                    },
                )
                version = str(artifact_ref.get("target_version_selector") or "").strip()
                if version:
                    asset["revisions"].add(version)
                content_format = str(binding.get("content_format") or "").strip()
                if content_format:
                    asset["content_formats"].add(content_format)
                asset["bindings"].append(
                    {
                        "stage_name": stage_name,
                        "stage_execution_id": stage_execution_id,
                        "workflow_run_id": bundle.record.workflow_run_id,
                        "binding_role": binding.get("binding_role"),
                        "binding_scope": binding.get("binding_scope"),
                        "stage_id": binding.get("stage_id"),
                        "content_format": binding.get("content_format"),
                        "adoption_state": binding.get("adoption_state"),
                        "materialized_path": binding.get("materialized_path"),
                        "artifact_ref": artifact_ref or None,
                        "metadata": dict(binding.get("metadata") or {}),
                    }
                )
    for asset in assets.values():
        asset["revisions"] = sorted(asset["revisions"])
        asset["content_formats"] = sorted(asset["content_formats"])
    return assets


def _coerce_dict_list(value: Any) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        return []
    return [dict(item) for item in value if isinstance(item, dict)]
