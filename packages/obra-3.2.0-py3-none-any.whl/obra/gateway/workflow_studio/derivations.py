"""Canonical Workflow Studio Stage B derivation projections."""

from __future__ import annotations

from typing import Any

from obra.gateway.links import build_resource_links
from obra.gateway.workflow_studio.data_access import (
    WorkflowStudioDerivationBundle,
    workflow_identity_from_sources,
)
from obra.gateway.workflow_studio.derivation_views import build_derivation_view_models


def build_workflow_derivation_detail(
    bundle: WorkflowStudioDerivationBundle,
) -> dict[str, Any]:
    """Build canonical workflow-derivation detail from one derivation bundle."""
    state = dict(bundle.workflow_derivation_state)
    request_payload = (
        dict(bundle.record.request_context.get("workflow_derivation_request", {}))
        if isinstance(bundle.record.request_context.get("workflow_derivation_request"), dict)
        else {}
    )
    identity = workflow_identity_from_sources(bundle.record, bundle.remote_session)
    normalized_inputs = _as_dict(state.get("normalized_inputs")) or request_payload
    validation_report = _as_dict(state.get("validation_report"))
    checkpoint_state = _as_dict(state.get("operator_review_checkpoint_state"))
    lifecycle_summary = _build_lifecycle_summary(bundle.remote_session, state)
    baseline_ref = _build_workflow_ref(
        _as_dict(state.get("baseline_workflow_ref"))
        or _as_dict(request_payload.get("baseline_workflow_ref")),
        identity_fallback=identity,
    )
    candidate_ref = _build_candidate_workflow_ref(state, identity)
    accepted_revision_ref = _build_workflow_ref(
        _as_dict(state.get("accepted_revision_ref"))
        or _as_dict(
            _as_dict(bundle.remote_session.get("workflow_lifecycle_state")).get("accepted")
        ),
        identity_fallback=identity,
    )
    acceptance = _build_acceptance_state(
        state=state,
        validation_report=validation_report,
        checkpoint_state=checkpoint_state,
        accepted_revision_ref=accepted_revision_ref,
    )
    detail = {
        "resource_type": "workflow_derivation",
        "derivation_id": bundle.record.derivation_id,
        "status": _derive_derivation_status(bundle.record.status, checkpoint_state, acceptance),
        "created_at": bundle.record.created_at.isoformat(),
        "updated_at": bundle.remote_session.get("updated_at"),
        "blocking_state": dict(bundle.record.blocking_summary),
        "resume_supported": bool(
            lifecycle_summary.get("lifecycle_decisions", {}).get("wait_resume_supported")
        ),
        "workflow_ref": {
            "workflow_id": identity["workflow_id"],
            "revision_id": identity["revision_id"],
            "domain_id": identity["domain_id"],
        },
        "normalized_inputs": normalized_inputs,
        "baseline_workflow_ref": baseline_ref,
        "candidate_workflow_ref": candidate_ref,
        "validation_summary": {
            "outcome": validation_report.get("outcome"),
            "issue_codes": list(validation_report.get("issue_codes") or []),
            "pending_operator_review_checkpoint_ids": list(
                checkpoint_state.get("checkpoint_ids") or []
            ),
        },
        "checkpoint_summary": {
            "status": checkpoint_state.get("status"),
            "pending_count": checkpoint_state.get("pending_count", 0),
            "checkpoint_ids": list(checkpoint_state.get("checkpoint_ids") or []),
            "pending_points": list(checkpoint_state.get("pending_points") or []),
        },
        "lifecycle_summary": lifecycle_summary,
        "acceptance": acceptance,
        "links": _build_links(bundle, baseline_ref, candidate_ref, accepted_revision_ref),
        "correlation": {
            "workflow_run_id": bundle.record.workflow_run_id,
            "hybrid_session_id": bundle.record.hybrid_session_id,
            "workflow_id": identity["workflow_id"],
            "workflow_revision_id": identity["revision_id"],
            "domain_id": identity["domain_id"],
            "checkpoint_id": bundle.record.checkpoint_id,
            "escalation_id": bundle.record.escalation_id,
            "trace_id": bundle.record.trace_id,
            "idempotency_key": bundle.record.idempotency_key,
        },
    }
    detail["views"] = build_derivation_view_models(detail)
    return detail


def _build_lifecycle_summary(
    remote_session: dict[str, Any],
    state: dict[str, Any],
) -> dict[str, Any]:
    workflow_lifecycle_state = (
        remote_session.get("workflow_lifecycle_state")
        if isinstance(remote_session.get("workflow_lifecycle_state"), dict)
        else {}
    )
    lifecycle_decisions = (
        remote_session.get("workflow_lifecycle_decisions")
        if isinstance(remote_session.get("workflow_lifecycle_decisions"), dict)
        else _as_dict(state.get("lifecycle_decisions"))
    )
    return {
        "workflow_lifecycle": workflow_lifecycle_state or _as_dict(state.get("workflow_lifecycle")),
        "lifecycle_decisions": lifecycle_decisions,
        "current_phase": remote_session.get("current_phase"),
        "status": remote_session.get("status"),
    }


def _build_candidate_workflow_ref(
    state: dict[str, Any],
    identity: dict[str, str | None],
) -> dict[str, Any]:
    derived_workflow_artifact = _as_dict(state.get("derived_workflow_artifact"))
    if not derived_workflow_artifact:
        return {}
    return {
        "workflow_id": derived_workflow_artifact.get("artifact_id") or identity["workflow_id"],
        "revision_id": derived_workflow_artifact.get("version") or identity["revision_id"],
        "domain_id": derived_workflow_artifact.get("domain_id") or identity["domain_id"],
        "artifact_id": derived_workflow_artifact.get("artifact_id"),
        "version": derived_workflow_artifact.get("version"),
    }


def _build_workflow_ref(
    source: dict[str, Any],
    *,
    identity_fallback: dict[str, str | None],
) -> dict[str, Any]:
    if not source:
        return {}
    metadata = source.get("metadata") if isinstance(source.get("metadata"), dict) else {}
    return {
        "workflow_id": source.get("workflow_id")
        or source.get("target_artifact_id")
        or metadata.get("workflow_id")
        or identity_fallback["workflow_id"],
        "revision_id": source.get("revision_id")
        or source.get("target_version_selector")
        or metadata.get("revision_id")
        or identity_fallback["revision_id"],
        "domain_id": source.get("domain_id")
        or metadata.get("domain_id")
        or identity_fallback["domain_id"],
        "artifact_id": source.get("target_artifact_id") or source.get("artifact_id"),
        "version": source.get("target_version_selector") or source.get("version"),
        "relationship_type": source.get("relationship_type"),
    }


def _build_acceptance_state(
    *,
    state: dict[str, Any],
    validation_report: dict[str, Any],
    checkpoint_state: dict[str, Any],
    accepted_revision_ref: dict[str, Any],
) -> dict[str, Any]:
    outcome = str(validation_report.get("outcome") or "")
    checkpoint_status = str(checkpoint_state.get("status") or "")
    accepted = bool(accepted_revision_ref)
    ready = checkpoint_status in {"no_pending_review", "revision_submitted"} and outcome in {
        "",
        "pass",
    }
    if accepted:
        ready = False
    return {
        "ready": ready,
        "status": checkpoint_status or ("accepted" if accepted else "pending"),
        "accepted_revision_ref": accepted_revision_ref,
        "conflict_reason": state.get("accept_conflict_reason"),
        "expected_baseline_ref": _as_dict(state.get("expected_baseline_ref")),
    }


def _build_links(
    bundle: WorkflowStudioDerivationBundle,
    baseline_ref: dict[str, Any],
    candidate_ref: dict[str, Any],
    accepted_revision_ref: dict[str, Any],
) -> dict[str, Any]:
    derivation_id = str(bundle.record.derivation_id or "")
    links = build_resource_links("derivation", derivation_id)
    baseline_workflow_id = baseline_ref.get("workflow_id")
    if baseline_workflow_id:
        links["baseline_workflow"] = f"/api/workflows/{baseline_workflow_id}"
    candidate_workflow_id = candidate_ref.get("workflow_id")
    if candidate_workflow_id:
        links["candidate_workflow"] = f"/api/workflows/{candidate_workflow_id}"
    accepted_workflow_id = accepted_revision_ref.get("workflow_id")
    if accepted_workflow_id:
        links["accepted_workflow"] = f"/api/workflows/{accepted_workflow_id}"
    return links


def _derive_derivation_status(
    record_status: str,
    checkpoint_state: dict[str, Any],
    acceptance: dict[str, Any],
) -> str:
    checkpoint_status = str(checkpoint_state.get("status") or "")
    if acceptance.get("accepted_revision_ref"):
        return "accepted"
    if acceptance.get("ready") or checkpoint_status in {"no_pending_review", "revision_submitted"}:
        return "completed"
    if checkpoint_status == "pending_review":
        return "awaiting_operator"
    if checkpoint_status == "revision_required":
        return "revision_required"
    if record_status == "completed":
        return "completed"
    return record_status


def _as_dict(value: Any) -> dict[str, Any]:
    return dict(value) if isinstance(value, dict) else {}
