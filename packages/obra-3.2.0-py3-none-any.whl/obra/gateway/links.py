"""Canonical path-based resource links for gateway responses."""

from __future__ import annotations


def build_resource_links(resource_type: str, resource_id: str, **extra: str) -> dict[str, str]:
    """Return route-backed links for a canonical gateway resource."""
    resource_id = str(resource_id).strip()
    if not resource_id:
        return {}

    mapping = {
        "workflow": {
            "self": f"/api/workflows/{resource_id}",
            "validate": f"/api/workflows/{resource_id}/validate",
            "archive": f"/api/workflows/{resource_id}/archive",
            "restore": f"/api/workflows/{resource_id}/restore",
            "revisions": f"/api/workflows/{resource_id}/revisions",
            "runs": f"/api/workflow-runs/?workflow_id={resource_id}",
        },
        "workflow_run": {
            "self": f"/api/workflow-runs/{resource_id}",
            "events": f"/api/workflow-runs/{resource_id}/events",
            "replay": f"/api/workflow-runs/{resource_id}/replay",
            "stages": f"/api/workflow-runs/{resource_id}/stages",
            "summary": f"/api/workflow-runs/{resource_id}/summary",
            "escalations": f"/api/workflow-runs/{resource_id}/escalations",
            "review_state": f"/api/workflow-runs/{resource_id}/review-state",
            "cancel": f"/api/workflow-runs/{resource_id}/cancel",
            "resume": f"/api/workflow-runs/{resource_id}/resume",
        },
        "session": {
            "self": f"/api/sessions/{resource_id}",
            "repair": f"/api/sessions/{resource_id}/repair",
            "force_complete": f"/api/sessions/{resource_id}/force-complete",
            "reset_review": f"/api/sessions/{resource_id}/reset-review",
        },
        "derivation": {
            "self": f"/api/workflow-derivations/{resource_id}",
            "events": f"/api/workflow-derivations/{resource_id}/events",
            "cancel": f"/api/workflow-derivations/{resource_id}/cancel",
            "resume": f"/api/workflow-derivations/{resource_id}/resume",
            "accept": f"/api/workflow-derivations/{resource_id}/accept",
        },
        "thread": {
            "self": f"/api/assistant/threads/{resource_id}",
            "turns": f"/api/assistant/threads/{resource_id}/turns",
            "audit": f"/api/assistant/threads/{resource_id}/audit",
            "restore": f"/api/assistant/threads/{resource_id}/restore",
            "delete": f"/api/assistant/threads/{resource_id}",
        },
    }
    links = dict(mapping.get(resource_type, {}))
    for key, value in extra.items():
        normalized_value = str(value).strip()
        if normalized_value:
            links[key] = normalized_value
    return links
