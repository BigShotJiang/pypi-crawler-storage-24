"""Gateway server — FastAPI application bridging HTTP/WebSocket clients to HybridOrchestrator."""

from __future__ import annotations

import asyncio
import ipaddress
import logging
import threading
from contextlib import asynccontextmanager
from math import ceil
from typing import Any

from fastapi import Depends, FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from obra import __version__
from obra.config.loaders import get_gateway_config, get_gateway_transcription_config
from obra.gateway.auth import get_auth_dependency, resolve_gateway_auth_token
from obra.gateway.automation.profile import resolve_gateway_automation_profile
from obra.gateway.errors import GatewayAPIError, gateway_error_handler
from obra.gateway.security.client_ip import extract_client_ip_from_request
from obra.gateway.security.rate_limit import TokenBucketRateLimiter
from obra.gateway.session_manager import SessionManager
from obra.gateway.webhook.cleanup import WebhookCleanupService
from obra.gateway.webhook.delivery import WebhookDeliveryService
from obra.gateway.webhook.dispatcher import WebhookDispatcher
from obra.gateway.webhook.store import InMemoryWebhookStore

logger = logging.getLogger(__name__)


def _resolve_webhook_config(config: dict[str, Any]) -> dict[str, Any]:
    return {
        "max_per_owner": int(config["webhooks_max_per_owner"]),
        "failure_threshold_failing": int(config["webhooks_failure_threshold_failing"]),
        "failure_threshold_disabled": int(config["webhooks_failure_threshold_disabled"]),
        "delivery_timeout_s": float(config["webhooks_delivery_timeout_s"]),
        "retry_backoff_schedule_s": tuple(float(item) for item in config["webhooks_retry_backoff_schedule"]),
        "retention_seconds": int(config["webhooks_retention_seconds"]),
        "cleanup_interval_s": float(config["webhooks_cleanup_interval_s"]),
    }


async def _webhook_cleanup_loop(
    cleanup_service: WebhookCleanupService,
    interval_s: float,
) -> None:
    try:
        while True:
            await asyncio.sleep(interval_s)
            await cleanup_service.cleanup_expired()
    except asyncio.CancelledError:
        raise


def _is_loopback_host(host: str) -> bool:
    """Return True when the provided host resolves to loopback."""
    normalized = host.strip().lower()
    if normalized in {"localhost", "::1"}:
        return True
    try:
        return ipaddress.ip_address(normalized).is_loopback
    except ValueError:
        return False


def _print_startup_banner(
    host: str,
    port: int,
    token: str,
    *,
    profile_name: str,
    auth_source: str,
) -> None:
    """Print Rich-formatted startup banner."""
    from rich.console import Console
    from rich.panel import Panel

    console = Console()
    token_hint = token[:4] + "***" if len(token) > 4 else "***"

    lines = [
        f"[bold]Obra Gateway[/bold] v{__version__}",
        "",
        f"  Profile:    [cyan]{profile_name}[/cyan]",
        f"  Listening:  [cyan]http://{host}:{port}[/cyan]",
        f"  Auth token: [yellow]{token_hint}[/yellow] ({auth_source})",
        "",
        "[dim]Endpoints:[/dim]",
        "  POST   /api/automation/runs       Automation launch for workflow runs",
        "  POST   /api/automation/derivations Automation launch for derivations",
        "  GET    /api/workflows             Workflow inspection",
        "  GET    /api/artifacts             Artifact inspection",
        "  GET    /api/runners               Runner lookup",
        "  POST   /api/workflow-derivations  Guided derivation control plane",
        "  GET    /api/workflow-runs         Workflow-run control plane",
        "  GET    /api/health/details        Authenticated diagnostics",
        "  WS     /api/events/stream         Workflow Studio event stream",
        "  GET    /health                   Health check",
        "  GET    /logs/                    Log viewer UI",
        "  GET    /logs/api/stream          Log viewer stream (SSE)",
    ]

    console.print()
    console.print(Panel("\n".join(lines), border_style="green"))
    console.print("[dim]Press Ctrl+C to stop[/dim]")
    console.print()


class GatewayServer:
    """FastAPI-based gateway server for HTTP/SSE and WebSocket access to Obra sessions.

    Args:
        config: Gateway configuration dict from get_gateway_config().
    """

    def __init__(self, config: dict[str, Any]) -> None:
        merged_config = get_gateway_config()
        merged_config.update(config)
        self._config = merged_config
        self._profile = resolve_gateway_automation_profile(self._config)
        self._webhook_config = _resolve_webhook_config(self._config)

        # Resolve auth token
        self._token, self._auth_source = resolve_gateway_auth_token(
            self._config,
            profile=self._profile,
        )

        # Session manager (created early so lifespan can reference it)
        self._session_manager = SessionManager(
            max_sessions=self._config.get("max_sessions", 5),
            escalation_timeout_s=self._config.get("escalation_timeout_s", 300.0),
            gateway_config=self._config,
        )
        self._webhook_store = InMemoryWebhookStore()
        self._webhook_delivery_service = WebhookDeliveryService(
            timeout_s=self._webhook_config["delivery_timeout_s"],
            retry_backoff_schedule_s=self._webhook_config["retry_backoff_schedule_s"],
        )
        self._webhook_dispatcher = WebhookDispatcher(
            store=self._webhook_store,
            delivery_service=self._webhook_delivery_service,
            failure_threshold_failing=self._webhook_config["failure_threshold_failing"],
            failure_threshold_disabled=self._webhook_config["failure_threshold_disabled"],
        )
        self._session_manager.set_webhook_dispatcher(self._webhook_dispatcher)

        # Lifespan with shutdown cleanup
        session_mgr = self._session_manager

        @asynccontextmanager
        async def _lifespan(app: FastAPI):  # type: ignore[type-arg]
            from obra.gateway.studio_browser import initialize_studio_browser_state
            from obra.gateway.workflow_studio.assistant_provider import (
                configure_assistant_runtime,
            )
            from obra.observability.log_viewer.server import (
                _load_ui_html,
                build_session_index,
                default_hybrid_log_path,
                default_production_log_path,
            )

            app.state.log_hybrid_path = default_hybrid_log_path()
            app.state.log_production_path = default_production_log_path()
            app.state.log_ui_bytes = _load_ui_html()
            app.state.log_session_index = build_session_index(
                app.state.log_hybrid_path,
                app.state.log_production_path,
            )
            app.state.logs_auth_sessions = {}
            app.state.logs_auth_lock = threading.Lock()
            app.state.logs_stream_lock = threading.Lock()
            app.state.logs_stream_clients_total = 0
            app.state.logs_stream_clients_by_ip = {}
            initialize_studio_browser_state(app.state)
            configure_assistant_runtime(app.state, warm_model_cache=True)
            loop = asyncio.get_running_loop()
            background_tasks: set[asyncio.Task[Any]] = set()

            def _track_background_task(task: asyncio.Task[Any]) -> asyncio.Task[Any]:
                background_tasks.add(task)
                task.add_done_callback(background_tasks.discard)
                return task

            def _spawn_webhook_task(coro: Any) -> asyncio.Task[Any]:
                return _track_background_task(loop.create_task(coro))

            def schedule_webhook_coro(coro: Any) -> None:
                def _schedule() -> None:
                    _spawn_webhook_task(coro)

                try:
                    loop.call_soon_threadsafe(_schedule)
                except RuntimeError:
                    if hasattr(coro, "close"):
                        coro.close()
                    raise

            cleanup_service = WebhookCleanupService(
                self._webhook_store,
                retention_seconds=self._webhook_config["retention_seconds"],
            )
            self._webhook_dispatcher.cleanup_service = cleanup_service
            self._webhook_dispatcher.set_task_spawner(_spawn_webhook_task)
            session_mgr.set_webhook_scheduler(schedule_webhook_coro)
            app.state.webhook_background_tasks = background_tasks
            app.state.schedule_webhook_coro = schedule_webhook_coro
            app.state.webhook_cleanup_service = cleanup_service
            app.state.webhook_cleanup_task = _spawn_webhook_task(
                _webhook_cleanup_loop(
                    cleanup_service,
                    self._webhook_config["cleanup_interval_s"],
                )
            )

            yield
            session_mgr.set_webhook_scheduler(None)
            self._webhook_dispatcher.set_task_spawner(None)
            self._webhook_dispatcher.cleanup_service = None
            if background_tasks:
                for task in list(background_tasks):
                    task.cancel()
                await asyncio.gather(*list(background_tasks), return_exceptions=True)
            # Shutdown: cancel all running sessions
            for record in session_mgr.list_sessions():
                if record.status == "running":
                    try:
                        session_mgr.cancel_session(record.session_id)
                    except Exception:
                        logger.warning("Failed to cancel session %s on shutdown", record.session_id)

        # Build FastAPI app (auth added per-router, not globally, so /health stays open)
        self._auth_dep = get_auth_dependency(self._token)
        self._app = FastAPI(
            title="Obra Gateway",
            version=__version__,
            lifespan=_lifespan,
        )
        self._app.add_exception_handler(GatewayAPIError, gateway_error_handler)

        # CORS middleware
        if self._config.get("enable_cors", False):
            origins = self._config.get("cors_origins", ["*"])
            credentials = self._config.get("cors_allow_credentials", True)
            if credentials and "*" in origins:
                logger.warning(
                    "CORS: credentials=True with wildcard origin is insecure; forcing credentials=False"
                )
                credentials = False
            self._app.add_middleware(
                CORSMiddleware,
                allow_origins=origins,
                allow_credentials=credentials,
                allow_methods=["*"],
                allow_headers=["*"],
            )

        # Attach session manager to app state
        self._app.state.session_manager = self._session_manager
        self._app.state.assistant_repository = None
        self._app.state.assistant_llm_provider = None
        self._app.state.assistant_llm_provider_state = None
        self._app.state.assistant_model_health_cache = None
        self._app.state.gateway_token = self._token
        self._app.state.gateway_profile = self._profile
        self._app.state.gateway_config = dict(self._config)
        self._app.state.webhook_config = dict(self._webhook_config)
        self._app.state.gateway_transcription_config = get_gateway_transcription_config()
        self._app.state.trusted_proxy_cidrs = list(self._config.get("trusted_proxy_cidrs", []))
        self._app.state.webhook_store = self._webhook_store
        self._app.state.webhook_delivery_service = self._webhook_delivery_service
        self._app.state.webhook_dispatcher = self._webhook_dispatcher
        self._app.state.webhook_cleanup_service = None
        self._app.state.webhook_cleanup_task = None
        self._app.state.webhook_background_tasks = set()
        self._app.state.schedule_webhook_coro = None
        self._app.state.enable_app_rate_limit = bool(
            self._config.get("enable_app_rate_limit", True)
        )

        if self._app.state.enable_app_rate_limit:
            self._app.state.rest_rate_limiter = TokenBucketRateLimiter(
                rate_per_minute=int(self._config.get("rest_rate_limit_per_minute", 120)),
                burst=int(self._config.get("rest_rate_limit_burst", 60)),
            )
            self._app.state.ws_rate_limiter = TokenBucketRateLimiter(
                rate_per_minute=int(self._config.get("ws_rate_limit_per_minute", 240)),
                burst=int(self._config.get("ws_rate_limit_burst", 120)),
            )
        else:
            self._app.state.rest_rate_limiter = None
            self._app.state.ws_rate_limiter = None

        # Register routes
        self._register_routes()

        @self._app.middleware("http")
        async def _rest_rate_limit_middleware(request: Request, call_next: Any) -> Any:
            limiter = request.app.state.rest_rate_limiter
            if limiter is None or not request.url.path.startswith("/api/"):
                return await call_next(request)

            client_ip = extract_client_ip_from_request(
                request,
                request.app.state.trusted_proxy_cidrs,
            )
            limit = int(request.app.state.gateway_config["rest_rate_limit_burst"])
            if not limiter.allow(client_ip):
                remaining, reset_seconds = limiter.remaining(client_ip)
                response = JSONResponse(
                    status_code=429,
                    content={"detail": "Rate limit exceeded"},
                )
                _attach_rate_limit_headers(
                    response,
                    limit=limit,
                    remaining=remaining,
                    reset_seconds=reset_seconds,
                    include_retry_after=True,
                )
                return response

            response = await call_next(request)
            remaining, reset_seconds = limiter.remaining(client_ip)
            _attach_rate_limit_headers(
                response,
                limit=limit,
                remaining=remaining,
                reset_seconds=reset_seconds,
                include_retry_after=False,
            )
            return response

        # Health endpoint (no auth required)
        @self._app.get("/health", include_in_schema=True)
        async def health() -> dict[str, Any]:
            return {"status": "ok"}

        @self._app.get(
            "/api/health/details",
            include_in_schema=True,
            dependencies=[Depends(self._auth_dep)],
        )
        async def health_details() -> dict[str, Any]:
            running = sum(1 for s in self._session_manager.list_sessions() if s.status == "running")
            return {
                "active_sessions": running,
                "version": __version__,
            }

    def _register_routes(self) -> None:
        """Register all route modules."""
        from obra.gateway.routes.api_root import router as api_root_router
        from obra.gateway.routes.artifacts import router as artifacts_router
        from obra.gateway.routes.assistant import router as assistant_router
        from obra.gateway.routes.automation import router as automation_router
        from obra.gateway.routes.callbacks import router as callbacks_router
        from obra.gateway.routes.domains import router as domains_router
        from obra.gateway.routes.interpolation import router as interpolation_router
        from obra.gateway.routes.knowledge import router as knowledge_router
        from obra.gateway.routes.logs import router as logs_router
        from obra.gateway.routes.runners import router as runners_router
        from obra.gateway.routes.sessions import router as sessions_router
        from obra.gateway.routes.studio import router as studio_router
        from obra.gateway.routes.template_assets import router as template_assets_router
        from obra.gateway.routes.transcription import router as transcription_router
        from obra.gateway.routes.webhooks import router as webhooks_router
        from obra.gateway.routes.workflow_derivations import (
            router as workflow_derivations_router,
        )
        from obra.gateway.routes.workflow_events import router as workflow_events_router
        from obra.gateway.routes.workflow_replay import router as workflow_replay_router
        from obra.gateway.routes.workflow_runs import router as workflow_runs_router
        from obra.gateway.routes.workflows import router as workflows_router

        auth = [Depends(self._auth_dep)]
        self._app.include_router(api_root_router, dependencies=auth)
        self._app.include_router(automation_router, dependencies=auth)
        self._app.include_router(assistant_router, dependencies=auth)
        self._app.include_router(callbacks_router, dependencies=auth)
        self._app.include_router(domains_router, dependencies=auth)
        self._app.include_router(interpolation_router, dependencies=auth)
        self._app.include_router(knowledge_router, dependencies=auth)
        self._app.include_router(sessions_router, dependencies=auth)
        self._app.include_router(transcription_router, dependencies=auth)
        self._app.include_router(workflows_router, dependencies=auth)
        self._app.include_router(artifacts_router, dependencies=auth)
        self._app.include_router(template_assets_router, dependencies=auth)
        self._app.include_router(runners_router, dependencies=auth)
        self._app.include_router(webhooks_router, dependencies=auth)
        self._app.include_router(workflow_derivations_router, dependencies=auth)
        self._app.include_router(workflow_runs_router, dependencies=auth)
        self._app.include_router(workflow_events_router)
        self._app.include_router(workflow_replay_router, dependencies=auth)
        self._app.include_router(logs_router)
        self._app.include_router(studio_router)

    @property
    def app(self) -> FastAPI:
        """The FastAPI application instance."""
        return self._app

    @property
    def token(self) -> str:
        """The auth token (for display/logging)."""
        return self._token

    def run(self, host: str | None = None, port: int | None = None) -> None:
        """Start the gateway server.

        Args:
            host: Override bind address.
            port: Override port number.
        """
        import uvicorn

        bind_host = host or self._config.get("host", "127.0.0.1")
        bind_port = port or self._config.get("port", 18790)
        allow_public_bind = bool(self._config.get("allow_public_bind", False))
        public_bind_tls_terminated = bool(self._config.get("public_bind_tls_terminated", False))

        if not _is_loopback_host(bind_host):
            if self._profile.private_only:
                raise RuntimeError(
                    "Private automation profile refuses non-loopback bind hosts. "
                    "Keep the gateway on loopback and use SSH tunnels or private overlays "
                    "for remote operator access."
                )
            if not allow_public_bind:
                msg = (
                    f"Refusing non-loopback bind host '{bind_host}'. "
                    "Set gateway.allow_public_bind=true and "
                    "gateway.public_bind_tls_terminated=true only when running behind "
                    "TLS-terminating edge infrastructure."
                )
                raise RuntimeError(msg)
            if not public_bind_tls_terminated:
                msg = (
                    "Refusing public bind without TLS termination acknowledgement. "
                    "Set gateway.public_bind_tls_terminated=true only when a trusted "
                    "reverse proxy/WAF terminates TLS."
                )
                raise RuntimeError(msg)

        _print_startup_banner(
            bind_host,
            bind_port,
            self._token,
            profile_name=self._profile.name,
            auth_source=self._auth_source,
        )
        uvicorn.run(
            self._app,
            host=bind_host,
            port=bind_port,
            ws_max_size=int(self._config.get("ws_max_message_bytes", 1_048_576)),
        )


def _attach_rate_limit_headers(
    response: Any,
    *,
    limit: int,
    remaining: float,
    reset_seconds: float,
    include_retry_after: bool,
) -> None:
    response.headers["X-RateLimit-Limit"] = str(limit)
    response.headers["X-RateLimit-Remaining"] = str(max(0, int(remaining)))
    response.headers["X-RateLimit-Reset"] = str(max(0, ceil(reset_seconds)))
    if include_retry_after:
        response.headers["Retry-After"] = str(max(1, ceil(reset_seconds)))
