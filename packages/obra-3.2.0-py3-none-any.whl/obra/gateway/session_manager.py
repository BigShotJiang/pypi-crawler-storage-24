"""Session lifecycle manager — thread-per-session model for HybridOrchestrator."""

from __future__ import annotations

import logging
import threading
import uuid
from collections import deque
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Literal

from obra.api.protocol import CompletionNotice
from obra.config.domain_resolution import resolve_orchestration_domain
from obra.config.loaders import get_gateway_config
from obra.core.interrupts import GracefulInterrupt, clear_interrupt_request
from obra.domains.resolution import (
    ensure_matching_domains,
    require_resolved_domain,
    resolve_domain_precedence,
)
from obra.gateway.automation.workspaces import resolve_gateway_workspace
from obra.gateway.bridge import OrchestratorBridge
from obra.gateway.event_bus import SessionEventBus
from obra.gateway.plan_context import (
    _ensure_gateway_userplan,
    _hydrate_gateway_workflow_run_plan_context,
    _install_gateway_imported_plan_handler,
    _load_gateway_workflow_run_plan_context,
)
from obra.gateway.session_helpers import (
    _extract_derivation_id,
    _gateway_noninteractive_stdio,
    _make_cancel_aware_callback,
    _new_derivation_id,
    _resolve_gateway_derivation_metadata_domain,
    _resolve_gateway_workflow_metadata_domain,
    _session_ref,
    _stable_payload_fingerprint,
    _string_or_none,
    _validate_working_dir,
)

logger = logging.getLogger(__name__)


class SessionLimitError(Exception):
    """Raised when max concurrent sessions exceeded."""

    def __init__(self, max_sessions: int) -> None:
        self.max_sessions = max_sessions
        super().__init__(f"Session limit reached: maximum {max_sessions} concurrent sessions")


class SessionNotFoundError(Exception):
    """Raised when a session ID is not found."""

    def __init__(self, session_id: str) -> None:
        self.session_id = session_id
        super().__init__(f"Session not found: {session_id}")


class SessionEvictedError(SessionNotFoundError):
    """Raised when a session existed but was evicted by TTL cleanup."""

    def __init__(self, session_id: str) -> None:
        self.session_id = session_id
        Exception.__init__(self, f"Session evicted: {session_id}")


@dataclass
class SessionRecord:
    """Tracks state of a single orchestration session."""

    session_id: str
    thread: threading.Thread
    event_bus: SessionEventBus
    workflow_run_id: str = ""
    derivation_id: str | None = None
    status: Literal["running", "completed", "failed", "cancelled"] = "running"
    created_at: datetime = field(default_factory=lambda: datetime.now(tz=timezone.utc))
    objective: str = ""
    project_id: str = ""
    completion_notice: CompletionNotice | None = None
    error: str | None = None
    cancel_event: threading.Event = field(default_factory=threading.Event)
    hybrid_session_id: str | None = None
    workflow_id: str | None = None
    workflow_revision_id: str | None = None
    domain_id: str | None = None
    current_stage: dict[str, Any] = field(default_factory=dict)
    blocking_summary: dict[str, Any] = field(default_factory=dict)
    request_context: dict[str, Any] = field(default_factory=dict)
    latest_remote_session: dict[str, Any] = field(default_factory=dict)
    latest_remote_plan: dict[str, Any] = field(default_factory=dict)
    latest_remote_events: list[dict[str, Any]] = field(default_factory=list)
    checkpoint_id: str | None = None
    escalation_id: str | None = None
    trace_id: str | None = None
    idempotency_key: str | None = None


class ProgressReconciler:
    """Reconciles session record state from progress events and remote snapshots.

    Extracted from SessionManager to isolate the record-mutation logic that
    interprets progress-callback payloads and remote session bundles.
    """

    def from_progress(
        self,
        record: SessionRecord,
        action: str,
        payload: dict[str, Any],
        derivation_sessions: dict[str, str],
    ) -> None:
        """Update a SessionRecord from a progress-callback event.

        Args:
            record: The session record to update.
            action: Progress action name.
            payload: Progress event payload.
            derivation_sessions: Mutable derivation-id -> session-id mapping.
        """
        payload_session_id = payload.get("session_id")
        if isinstance(payload_session_id, str) and payload_session_id:
            record.hybrid_session_id = payload_session_id

        derivation_id = _extract_derivation_id(payload)
        if derivation_id is not None:
            record.derivation_id = derivation_id
            derivation_sessions[derivation_id] = record.session_id

        for attr_name, field_name in (
            ("checkpoint_id", "checkpoint_id"),
            ("escalation_id", "escalation_id"),
            ("trace_id", "trace_id"),
        ):
            field_value = _string_or_none(payload.get(field_name))
            if field_value is not None:
                setattr(record, attr_name, field_value)

        workflow_lifecycle = payload.get("workflow_lifecycle")
        accepted_workflow = None
        if isinstance(workflow_lifecycle, dict):
            accepted_workflow = workflow_lifecycle.get("accepted")
            if not isinstance(accepted_workflow, dict):
                accepted_workflow = workflow_lifecycle
        if isinstance(accepted_workflow, dict):
            workflow_id = accepted_workflow.get("workflow_id")
            domain_id = accepted_workflow.get("domain_id")
            revision_id = accepted_workflow.get("revision_id")
            if isinstance(workflow_id, str) and workflow_id:
                record.workflow_id = workflow_id
            if isinstance(domain_id, str) and domain_id:
                record.domain_id = domain_id
            if isinstance(revision_id, str) and revision_id:
                record.workflow_revision_id = revision_id

        if action == "plan_snapshot":
            record.latest_remote_plan = {
                "session_id": _session_ref(record, record.session_id),
                "plan_items": list(payload.get("plan_items") or []),
                "plan_items_count": payload.get("plan_items_count", 0),
                "plan_snapshot_ref": payload.get("plan_snapshot_ref"),
            }

    def from_remote_snapshot(
        self,
        record: SessionRecord,
        remote_session: dict[str, Any],
        derivation_sessions: dict[str, str],
    ) -> None:
        """Update a SessionRecord from a remote session snapshot.

        Args:
            record: The session record to update.
            remote_session: Remote session data bundle.
            derivation_sessions: Mutable derivation-id -> session-id mapping.
        """
        workflow_state = (
            remote_session.get("workflow_lifecycle_state")
            if isinstance(remote_session.get("workflow_lifecycle_state"), dict)
            else {}
        )
        accepted_workflow = (
            workflow_state.get("accepted")
            if isinstance(workflow_state.get("accepted"), dict)
            else workflow_state
        )
        if isinstance(accepted_workflow, dict):
            workflow_id = accepted_workflow.get("workflow_id")
            domain_id = accepted_workflow.get("domain_id")
            revision_id = accepted_workflow.get("revision_id")
            if isinstance(workflow_id, str) and workflow_id:
                record.workflow_id = workflow_id
            if isinstance(domain_id, str) and domain_id:
                record.domain_id = domain_id
            if isinstance(revision_id, str) and revision_id:
                record.workflow_revision_id = revision_id

        workflow_derivation_state = (
            remote_session.get("workflow_derivation_state")
            if isinstance(remote_session.get("workflow_derivation_state"), dict)
            else {}
        )
        derivation_id = _extract_derivation_id(workflow_derivation_state)
        if derivation_id is not None:
            record.derivation_id = derivation_id
            derivation_sessions[derivation_id] = record.session_id
        derived_workflow = (
            workflow_derivation_state.get("derived_workflow_artifact")
            if isinstance(workflow_derivation_state.get("derived_workflow_artifact"), dict)
            else {}
        )
        if isinstance(derived_workflow.get("artifact_id"), str) and derived_workflow.get(
            "artifact_id"
        ):
            record.workflow_id = str(derived_workflow["artifact_id"])
        if isinstance(derived_workflow.get("version"), str) and derived_workflow.get("version"):
            record.workflow_revision_id = str(derived_workflow["version"])
        if isinstance(derived_workflow.get("domain_id"), str) and derived_workflow.get("domain_id"):
            record.domain_id = str(derived_workflow["domain_id"])

        pipeline_stages = remote_session.get("pipeline_stages")
        if isinstance(pipeline_stages, list) and pipeline_stages:
            active_stage = next(
                (
                    stage
                    for stage in pipeline_stages
                    if isinstance(stage, dict) and str(stage.get("status", "")).lower() == "running"
                ),
                None,
            ) or next((stage for stage in pipeline_stages if isinstance(stage, dict)), None)
            if active_stage is not None:
                record.current_stage = {
                    "stage_name": active_stage.get("stage_name") or active_stage.get("trigger"),
                    "stage_execution_id": active_stage.get("stage_execution_id"),
                    "status": active_stage.get("status"),
                    "outcome": active_stage.get("outcome"),
                }
                pending_reason = active_stage.get("pending_manual_reason")
                if isinstance(pending_reason, str) and pending_reason:
                    record.blocking_summary = {
                        "state": "blocked",
                        "reason": pending_reason,
                        "required_action": active_stage.get("pending_manual_required_action"),
                        "blocking": bool(active_stage.get("pending_manual_blocking", True)),
                    }
                checkpoint = None
                resume_metadata = active_stage.get("resume_metadata")
                if isinstance(resume_metadata, dict):
                    checkpoint = resume_metadata.get("checkpoint")
                if isinstance(checkpoint, str) and checkpoint:
                    record.checkpoint_id = checkpoint


class SessionManager:
    """Manages orchestration sessions with thread-per-session model.

    Each session runs HybridOrchestrator.derive() in its own thread, bridged
    to async consumers via SessionEventBus.

    Note on cancellation: each session has its own cancel_event checked in the
    session thread's progress callback.

    Args:
        max_sessions: Maximum concurrent running sessions.
        escalation_timeout_s: Timeout for escalation decisions.
    """

    def __init__(
        self,
        max_sessions: int = 5,
        escalation_timeout_s: float = 300.0,
        client_factory: Callable[[], Any] | None = None,
        gateway_config: dict[str, Any] | None = None,
    ) -> None:
        self._max_sessions = max_sessions
        self._escalation_timeout_s = escalation_timeout_s
        self._client_factory = client_factory
        self._gateway_config = dict(gateway_config or get_gateway_config())
        self._reconciler = ProgressReconciler()
        self._sessions: dict[str, SessionRecord] = {}
        self._derivation_sessions: dict[str, str] = {}
        self._derivation_idempotency: dict[str, tuple[str, str]] = {}
        self._workflow_event_buses: dict[str, SessionEventBus] = {}
        self._evicted_ids: set[str] = set()
        self._evicted_order: deque[str] = deque()
        self._webhook_dispatcher: Any | None = None
        self._webhook_scheduler: Callable[[Awaitable[Any]], None] | None = None
        self._lock = threading.Lock()

    def set_client_factory(self, client_factory: Callable[[], Any] | None) -> None:
        """Set the API client factory used by gateway-owned remote calls."""
        self._client_factory = client_factory

    def set_gateway_config(self, gateway_config: dict[str, Any]) -> None:
        """Update the effective gateway config owned by the current server."""
        self._gateway_config = dict(gateway_config)

    def set_webhook_dispatcher(self, dispatcher: Any | None) -> None:
        """Set the webhook dispatcher owned by the current server."""
        self._webhook_dispatcher = dispatcher

    def set_webhook_scheduler(
        self,
        scheduler: Callable[[Awaitable[Any]], None] | None,
    ) -> None:
        """Set the async scheduler used to submit webhook dispatch work."""
        self._webhook_scheduler = scheduler

    def _get_gateway_config(self) -> dict[str, Any]:
        return dict(self._gateway_config)

    def _create_api_client(self) -> Any:
        """Create a fresh API client for the current session thread/request path."""
        from obra.api import APIClient

        if callable(self._client_factory):
            return self._client_factory()
        return APIClient.from_config()

    def _remember_evicted_session(self, session_id: str) -> None:
        """Track recently evicted IDs with a bounded history."""
        if session_id in self._evicted_ids:
            return
        self._evicted_ids.add(session_id)
        self._evicted_order.append(session_id)
        while len(self._evicted_ids) > 1000:
            oldest = self._evicted_order.popleft()
            self._evicted_ids.discard(oldest)

    def _evict_terminal_sessions(self) -> int:
        """Evict terminal sessions older than configured TTL."""
        ttl_seconds = int(self._get_gateway_config()["session_eviction_ttl_seconds"])
        now = datetime.now(tz=timezone.utc)
        terminal = {"completed", "failed", "cancelled"}

        with self._lock:
            evict_ids = [
                session_id
                for session_id, record in self._sessions.items()
                if record.status in terminal
                and (now - record.created_at).total_seconds() > ttl_seconds
            ]
            for session_id in evict_ids:
                del self._sessions[session_id]
                self._remember_evicted_session(session_id)

        count = len(evict_ids)
        if count > 0:
            logger.info("Evicted %d terminal sessions", count)
        return count

    def create_session(
        self,
        objective: str,
        project_id: str,
        working_dir: str,
        *,
        workflow_id: str | None = None,
        revision_id: str | None = None,
        domain_id: str | None = None,
        domain_resolution_state: dict[str, Any] | None = None,
        workflow_derivation_request: dict[str, Any] | None = None,
        plan_context: dict[str, Any] | None = None,
        parent_payload: dict[str, Any] | None = None,
        launch_metadata: dict[str, Any] | None = None,
        derivation_id: str | None = None,
        idempotency_key: str | None = None,
    ) -> str:
        """Create and start a new orchestration session.

        Args:
            objective: The objective to derive.
            project_id: Project identifier.
            working_dir: Working directory path for the orchestrator.

        Returns:
            Session ID string.

        Raises:
            SessionLimitError: If max concurrent sessions exceeded.
        """
        self._evict_terminal_sessions()
        gateway_config = self._get_gateway_config()
        allowed_base = Path(gateway_config["allowed_working_dir_base"]).expanduser()
        max_queue_size = int(gateway_config["max_event_queue_size"])
        resolved_working_dir = _validate_working_dir(working_dir, allowed_base)
        if workflow_derivation_request and derivation_id is None:
            derivation_id = _new_derivation_id()

        with self._lock:
            running = sum(1 for s in self._sessions.values() if s.status == "running")
            if running >= self._max_sessions:
                raise SessionLimitError(self._max_sessions)

            session_id = uuid.uuid4().hex[:12]
            event_bus = self._new_event_bus(session_id, max_queue_size=max_queue_size)
            bridge = OrchestratorBridge(event_bus)

            thread = threading.Thread(
                target=self._run_session,
                args=(
                    session_id,
                    objective,
                    project_id,
                    str(resolved_working_dir),
                    bridge,
                    workflow_derivation_request,
                ),
                name=f"gateway-session-{session_id}",
                daemon=True,
            )

            record = SessionRecord(
                session_id=session_id,
                thread=thread,
                event_bus=event_bus,
                workflow_run_id=session_id,
                derivation_id=derivation_id,
                objective=objective,
                project_id=project_id,
                workflow_id=workflow_id,
                workflow_revision_id=revision_id,
                domain_id=domain_id,
                idempotency_key=idempotency_key,
                request_context={
                    "working_dir": str(resolved_working_dir),
                    "workflow_id": workflow_id,
                    "revision_id": revision_id,
                    "domain_id": domain_id,
                    "domain_resolution_state": dict(domain_resolution_state or {}),
                    "workflow_derivation_request": dict(workflow_derivation_request or {}),
                    "plan_context": dict(plan_context or {}),
                    "parent_payload": dict(parent_payload or {}),
                    "launch_metadata": dict(launch_metadata or {}),
                },
            )
            self._sessions[session_id] = record
            if derivation_id:
                self._derivation_sessions[derivation_id] = session_id

        thread.start()
        return session_id

    def create_workflow_run(
        self,
        *,
        objective: str,
        project_id: str,
        working_dir: str | None,
        workflow_id: str | None = None,
        revision_id: str | None = None,
        domain_id: str | None = None,
        workflow_derivation_request: dict[str, Any] | None = None,
        parent_payload: dict[str, Any] | None = None,
        launch_metadata: dict[str, Any] | None = None,
    ) -> str:
        """Create a canonical workflow run backed by the gateway session substrate."""
        workspace = resolve_gateway_workspace(
            project_id=project_id,
            working_dir=working_dir,
            allowed_base=Path(self._get_gateway_config()["allowed_working_dir_base"]),
            client_factory=self._client_factory,
        )
        resolved_working_dir = workspace.working_dir
        plan_context: dict[str, Any] | None = None
        workflow_metadata_domain_id: str | None = None
        resolved_domain_state: dict[str, Any] | None = None
        if workflow_derivation_request is None:
            plan_context = _load_gateway_workflow_run_plan_context(
                objective=objective,
                working_dir=resolved_working_dir,
                workflow_id=workflow_id,
                revision_id=revision_id,
                domain_id=None,
                client_factory=self._client_factory,
            )
            workflow_metadata_domain_id = _resolve_gateway_workflow_metadata_domain(plan_context)
        ensure_matching_domains(
            explicit_request_domain_id=domain_id,
            workflow_domain_id=workflow_metadata_domain_id,
            source="gateway_workflow_run",
        )
        explicit_domain = resolve_domain_precedence(
            (
                (domain_id, "explicit", "workflow_run.request.domain_id"),
                (
                    workflow_metadata_domain_id,
                    "explicit",
                    "workflow_run.workflow_metadata.domain_id",
                ),
                (
                    (
                        workflow_derivation_request.get("domain_id")
                        if isinstance(workflow_derivation_request, dict)
                        else None
                    ),
                    "explicit",
                    "workflow_run.workflow_derivation_request.domain_id",
                ),
            )
        )
        resolved_domain = (
            explicit_domain
            if explicit_domain.is_resolved or explicit_domain.status == "invalid"
            else resolve_orchestration_domain(
                None,
                project_path=Path(resolved_working_dir).expanduser().resolve(),
            )
        )
        resolved_domain_id = require_resolved_domain(
            resolved_domain,
            context="Workflow run launch",
        )
        resolved_domain_state = resolved_domain.to_dict()
        if plan_context is not None:
            plan_context = _hydrate_gateway_workflow_run_plan_context(
                plan_context=plan_context,
                objective=objective,
                workflow_id=_string_or_none(workflow_id),
                revision_id=_string_or_none(revision_id),
                domain_id=resolved_domain_id,
            )
        if plan_context is not None and workflow_derivation_request is None:
            from obra.execution.intake import materialize_workflow_derivation_request

            workflow_derivation_request = materialize_workflow_derivation_request(
                objective=objective,
                domain_id=resolved_domain_id,
                plan_context=plan_context,
            )
        if isinstance(workflow_derivation_request, dict):
            workflow_derivation_request = {
                **workflow_derivation_request,
                "domain_id": resolved_domain_id,
            }
        return self.create_session(
            objective=objective,
            project_id=project_id,
            working_dir=resolved_working_dir,
            workflow_id=workflow_id,
            revision_id=revision_id,
            domain_id=resolved_domain_id,
            domain_resolution_state=resolved_domain_state,
            workflow_derivation_request=workflow_derivation_request,
            plan_context=plan_context,
            parent_payload=parent_payload,
            launch_metadata=launch_metadata,
        )

    def create_workflow_derivation(
        self,
        *,
        objective: str,
        workflow_derivation_request: dict[str, Any],
        idempotency_key: str,
        project_id: str,
        working_dir: str | None = None,
    ) -> tuple[SessionRecord, bool]:
        """Create or reuse a canonical workflow-derivation record."""
        normalized_key = idempotency_key.strip()
        if not normalized_key:
            raise ValueError("Idempotency-Key is required")
        workflow_metadata_domain_id = _resolve_gateway_derivation_metadata_domain(
            workflow_derivation_request
        )
        ensure_matching_domains(
            explicit_request_domain_id=workflow_derivation_request.get("domain_id"),
            workflow_domain_id=workflow_metadata_domain_id,
            source="gateway_workflow_derivation",
        )
        resolved_domain = resolve_domain_precedence(
            (
                (
                    workflow_derivation_request.get("domain_id"),
                    "explicit",
                    "workflow_derivation_request.domain_id",
                ),
                (
                    workflow_metadata_domain_id,
                    "explicit",
                    "workflow_derivation_request.workflow_metadata.domain_id",
                ),
            )
        )
        resolved_domain_id = require_resolved_domain(
            resolved_domain,
            context="Workflow derivation launch",
        )
        workflow_derivation_request = {
            **dict(workflow_derivation_request),
            "domain_id": resolved_domain_id,
        }

        request_fingerprint = _stable_payload_fingerprint(workflow_derivation_request)
        with self._lock:
            existing = self._derivation_idempotency.get(normalized_key)
            if existing is not None:
                existing_derivation_id, existing_fingerprint = existing
                if existing_fingerprint != request_fingerprint:
                    raise ValueError("Idempotency-Key already used for a different request")
                existing_session_id = self._derivation_sessions.get(existing_derivation_id)
                if existing_session_id is None:
                    raise SessionNotFoundError(existing_derivation_id)
                return self._sessions[existing_session_id], True

        resolved_project_id, resolved_working_dir = self._resolve_derivation_launch_context(
            project_id=project_id,
            working_dir=working_dir,
        )
        derivation_id = _new_derivation_id()
        session_id = self.create_session(
            objective=objective,
            project_id=resolved_project_id,
            working_dir=resolved_working_dir,
            domain_id=resolved_domain_id,
            domain_resolution_state=resolved_domain.to_dict(),
            workflow_derivation_request=workflow_derivation_request,
            derivation_id=derivation_id,
            idempotency_key=normalized_key,
        )
        record = self.get_session(session_id)
        record.event_bus.push_event(
            "workflow_derivation.started",
            {
                "derivation_id": derivation_id,
                "workflow_run_id": record.workflow_run_id,
                "workflow_derivation_request": dict(workflow_derivation_request),
            },
        )
        with self._lock:
            self._derivation_sessions[derivation_id] = session_id
            self._derivation_idempotency[normalized_key] = (
                derivation_id,
                request_fingerprint,
            )
        return record, False

    def _finalize_session_outcome(
        self,
        record: SessionRecord,
        session_id: str,
        outcome: Literal["cancelled", "failed"],
        *,
        error: Exception | None = None,
        event_session_ref: str | None = None,
        extra_events: list[tuple[str, dict[str, Any]]] | None = None,
        log_message: str | None = None,
    ) -> None:
        """Consolidate terminal event handling for session threads.

        Handles setting record status/error/blocking_summary, pushing the
        canonical workflow_run.cancelled or workflow_run.failed event, any
        extra per-caller events, logging, and finally-block cleanup.
        """
        ref = event_session_ref if event_session_ref is not None else session_id
        if outcome == "cancelled":
            record.status = "cancelled"
            record.blocking_summary = {"state": "cancelled", "terminal": True}
            if log_message:
                logger.info(log_message, session_id)
            record.event_bus.push_event(
                "workflow_run.cancelled",
                {
                    "run_id": record.workflow_run_id,
                    "workflow_run_id": record.workflow_run_id,
                    "session_id": _session_ref(record, ref),
                },
            )
        elif outcome == "failed":
            error_name = type(error).__name__ if error else "Unknown"
            record.status = "failed"
            record.error = error_name
            record.blocking_summary = {
                "state": "failed",
                "terminal": True,
                "error": error_name,
            }
            if extra_events:
                for event_name, event_payload in extra_events:
                    record.event_bus.push_event(event_name, event_payload)
            record.event_bus.push_event(
                "workflow_run.failed",
                {
                    "run_id": record.workflow_run_id,
                    "workflow_run_id": record.workflow_run_id,
                    "session_id": _session_ref(record, ref),
                    "error": error_name,
                },
            )
            if log_message:
                logger.exception(log_message, session_id)

        record.event_bus.close()
        clear_interrupt_request()

    def _run_session(
        self,
        session_id: str,
        objective: str,
        project_id: str,
        working_dir: str,
        bridge: OrchestratorBridge,
        workflow_derivation_request: dict[str, Any] | None = None,
    ) -> None:
        """Run orchestration in a dedicated thread."""
        record = self._sessions[session_id]
        try:
            # Best-effort isolation from prior session cancels
            clear_interrupt_request()

            wd = Path(working_dir)

            userplan_id = _ensure_gateway_userplan(
                objective=objective,
                project_id=project_id,
                session_id=session_id,
                request_context=record.request_context,
                client_factory=self._client_factory,
            )
            with self._lock:
                current_record = self._sessions.get(session_id)
                if current_record is not None:
                    current_record.request_context["userplan_id"] = userplan_id

            plan_context = (
                dict(record.request_context.get("plan_context", {}))
                if isinstance(record.request_context.get("plan_context"), dict)
                and record.request_context.get("plan_context")
                else None
            )

            with _gateway_noninteractive_stdio():
                orchestrator, _, _ = self._create_orchestrator_instance(
                    session_id,
                    record,
                    bridge,
                    wd,
                )
                domain_resolution_state = record.request_context.get("domain_resolution_state")
                if isinstance(domain_resolution_state, dict) and domain_resolution_state:
                    orchestrator._domain_resolution = dict(domain_resolution_state)
                if plan_context is not None:
                    _install_gateway_imported_plan_handler(orchestrator, plan_context)

                completion = orchestrator.derive(
                    objective=objective,
                    project_id=project_id,
                    workflow_derivation_request=workflow_derivation_request,
                    userplan_id=userplan_id,
                )

            self._sync_hybrid_session_id(session_id, orchestrator.session_id)
            record.completion_notice = completion
            record.status = "completed"
            record.blocking_summary = {"state": "completed", "terminal": True}
            record.event_bus.push_event(
                "session_completed",
                {
                    "session_id": session_id,
                    "summary": completion.session_summary if completion else "",
                },
            )
            record.event_bus.push_event(
                "workflow_run.completed",
                {
                    "run_id": record.workflow_run_id,
                    "workflow_run_id": record.workflow_run_id,
                    "session_id": _session_ref(record, session_id),
                    "summary": completion.session_summary if completion else "",
                },
            )

        except GracefulInterrupt:
            self._finalize_session_outcome(
                record,
                session_id,
                "cancelled",
                event_session_ref=session_id,
                log_message="Session %s cancelled via interrupt",
            )
        except Exception as exc:
            self._finalize_session_outcome(
                record,
                session_id,
                "failed",
                error=exc,
                event_session_ref=session_id,
                extra_events=[
                    (
                        "session_error",
                        {
                            "session_id": session_id,
                            "error": type(exc).__name__,
                        },
                    )
                ],
                log_message="Session %s failed",
            )

    def get_session(self, session_id: str) -> SessionRecord:
        """Get session record by ID.

        Raises:
            SessionNotFoundError: If session not found.
        """
        with self._lock:
            if session_id in self._sessions:
                return self._sessions[session_id]
            if session_id in self._evicted_ids:
                raise SessionEvictedError(session_id)
            raise SessionNotFoundError(session_id)

    def get_session_by_derivation_id(self, derivation_id: str) -> SessionRecord:
        """Resolve a session by canonical derivation id."""
        with self._lock:
            session_id = self._derivation_sessions.get(derivation_id)
            if session_id is None:
                raise SessionNotFoundError(derivation_id)
        return self.get_session(session_id)

    def list_sessions(self) -> list[SessionRecord]:
        """Return all session records."""
        with self._lock:
            return list(self._sessions.values())

    def cancel_session(self, session_id: str) -> None:
        """Request cancellation of a running session.

        Raises:
            SessionNotFoundError: If session not found.
        """
        with self._lock:
            if session_id not in self._sessions:
                raise SessionNotFoundError(session_id)
            record = self._sessions[session_id]
            record.cancel_event.set()
            record.blocking_summary = {
                "state": "cancelling",
                "requested": True,
                "terminal": False,
            }
            record.event_bus.push_event(
                "workflow_run.cancel_requested",
                {
                    "run_id": record.workflow_run_id,
                    "workflow_run_id": record.workflow_run_id,
                    "session_id": _session_ref(record, session_id),
                },
            )

    def get_event_bus(self, session_id: str) -> SessionEventBus:
        """Get the event bus for a session (for transport layers to subscribe).

        Raises:
            SessionNotFoundError: If session not found.
        """
        record = self.get_session(session_id)
        return record.event_bus

    def resume_session(
        self,
        session_id: str,
        *,
        resume_target: str | None = None,
    ) -> SessionRecord:
        """Resume a terminal workflow run using the underlying hybrid session id."""
        gateway_config = self._get_gateway_config()
        max_queue_size = int(gateway_config["max_event_queue_size"])

        with self._lock:
            if session_id not in self._sessions:
                raise SessionNotFoundError(session_id)
            record = self._sessions[session_id]
            if record.hybrid_session_id is None:
                raise ValueError("Cannot resume workflow run without a hybrid session id")
            if record.status == "running":
                raise ValueError("Workflow run is already active")

            prior_history = record.event_bus.snapshot()
            next_sequence = record.event_bus.latest_sequence() + 1
            record.event_bus = self._new_event_bus(
                session_id,
                max_queue_size=max_queue_size,
                initial_history=prior_history,
                next_sequence=next_sequence,
            )
            record.cancel_event = threading.Event()
            record.status = "running"
            record.error = None
            record.blocking_summary = {"state": "resuming", "terminal": False}
            bridge = OrchestratorBridge(record.event_bus)
            thread = threading.Thread(
                target=self._run_resume_session,
                args=(session_id, record.hybrid_session_id, resume_target, bridge),
                name=f"gateway-session-resume-{session_id}",
                daemon=True,
            )
            record.thread = thread

        thread.start()
        return record

    def list_workflow_runs(self) -> list[SessionRecord]:
        """Return all canonical workflow runs."""
        return self.list_sessions()

    def list_workflow_derivations(self) -> list[SessionRecord]:
        """Return sessions addressable as canonical workflow derivations."""
        return [record for record in self.list_sessions() if self._record_has_derivation(record)]

    def update_remote_snapshot(
        self,
        session_id: str,
        *,
        remote_session: dict[str, Any] | None = None,
        remote_plan: dict[str, Any] | None = None,
        remote_events: list[dict[str, Any]] | None = None,
    ) -> None:
        """Persist the latest remote bundle used by Workflow Studio projections."""
        with self._lock:
            if session_id not in self._sessions:
                raise SessionNotFoundError(session_id)
            record = self._sessions[session_id]
            if remote_session is not None:
                record.latest_remote_session = dict(remote_session)
                self._update_record_from_remote_snapshot(record, remote_session)
            if remote_plan is not None:
                record.latest_remote_plan = dict(remote_plan)
            if remote_events is not None:
                record.latest_remote_events = [dict(event) for event in remote_events]

    def _new_event_bus(
        self,
        session_id: str,
        *,
        max_queue_size: int,
        initial_history: list[dict[str, Any]] | None = None,
        next_sequence: int = 0,
    ) -> SessionEventBus:
        return SessionEventBus(
            session_id,
            escalation_timeout_s=self._escalation_timeout_s,
            max_queue_size=max_queue_size,
            initial_history=initial_history,
            next_sequence=next_sequence,
            raw_event_observer=lambda raw_event: self._observe_session_raw_event(
                session_id,
                raw_event,
            ),
        )

    def _observe_session_raw_event(self, session_id: str, raw_event: dict[str, Any]) -> None:
        dispatcher = self._webhook_dispatcher
        scheduler = self._webhook_scheduler
        if dispatcher is None or scheduler is None:
            return
        try:
            record = self.get_session(session_id)
        except SessionNotFoundError:
            return

        from obra.gateway.workflow_studio.events import build_event_envelope

        resource_type = (
            "workflow_derivation"
            if isinstance(record.derivation_id, str) and record.derivation_id
            else "workflow_run"
        )
        resource_id = record.derivation_id if resource_type == "workflow_derivation" else record.workflow_run_id
        if not isinstance(resource_id, str) or not resource_id:
            return
        envelope = build_event_envelope(
            raw_event,
            run_id=record.workflow_run_id,
            record=record,
            resource_type="workflow_run",
        )
        scheduler(dispatcher.dispatch(envelope["event_name"], envelope, resource_type, resource_id))

    def _observe_workflow_raw_event(self, workflow_id: str, raw_event: dict[str, Any]) -> None:
        dispatcher = self._webhook_dispatcher
        scheduler = self._webhook_scheduler
        if dispatcher is None or scheduler is None:
            return

        from obra.gateway.workflow_studio.events import build_event_envelope

        envelope = build_event_envelope(
            raw_event,
            run_id=workflow_id,
            record=None,
            resource_type="workflow",
        )
        scheduler(dispatcher.dispatch(envelope["event_name"], envelope, "workflow", workflow_id))

    def _resolve_derivation_launch_context(
        self,
        *,
        project_id: str,
        working_dir: str | None = None,
    ) -> tuple[str, str]:
        workspace = resolve_gateway_workspace(
            project_id=project_id,
            working_dir=working_dir,
            allowed_base=Path(self._get_gateway_config()["allowed_working_dir_base"]),
            client_factory=self._client_factory,
        )
        return workspace.project_id, workspace.working_dir

    def _run_resume_session(
        self,
        session_id: str,
        hybrid_session_id: str,
        resume_target: str | None,
        bridge: OrchestratorBridge,
    ) -> None:
        record = self._sessions[session_id]
        try:
            clear_interrupt_request()
            wd = Path(str(record.request_context.get("working_dir") or "."))

            with _gateway_noninteractive_stdio():
                orchestrator, _, _ = self._create_orchestrator_instance(
                    session_id,
                    record,
                    bridge,
                    wd,
                )

                completion = orchestrator.resume(
                    session_id=hybrid_session_id,
                    resume_target=resume_target,
                )

            self._sync_hybrid_session_id(session_id, orchestrator.session_id or hybrid_session_id)
            record.completion_notice = completion
            record.status = "completed"
            record.blocking_summary = {"state": "completed", "terminal": True}
            record.event_bus.push_event(
                "workflow_run.resumed",
                {
                    "run_id": record.workflow_run_id,
                    "workflow_run_id": record.workflow_run_id,
                    "session_id": _session_ref(record, hybrid_session_id),
                },
            )
            record.event_bus.push_event(
                "workflow_run.completed",
                {
                    "run_id": record.workflow_run_id,
                    "workflow_run_id": record.workflow_run_id,
                    "session_id": _session_ref(record, hybrid_session_id),
                    "summary": completion.session_summary if completion else "",
                },
            )
        except GracefulInterrupt:
            self._finalize_session_outcome(
                record,
                session_id,
                "cancelled",
                event_session_ref=hybrid_session_id,
            )
        except Exception as exc:
            self._finalize_session_outcome(
                record,
                session_id,
                "failed",
                error=exc,
                event_session_ref=hybrid_session_id,
                log_message="Session %s failed during resume",
            )

    def _sync_hybrid_session_id(self, session_id: str, hybrid_session_id: str | None) -> None:
        if not isinstance(hybrid_session_id, str) or not hybrid_session_id:
            return
        with self._lock:
            record = self._sessions.get(session_id)
            if record is None:
                return
            record.hybrid_session_id = hybrid_session_id

    def _create_orchestrator_instance(
        self,
        session_id: str,
        record: SessionRecord,
        bridge: OrchestratorBridge,
        working_dir: Path,
    ) -> tuple[Any, dict[str, Any], Callable[[str, dict[str, Any]], None]]:
        """Create an orchestrator instance with common wiring.

        Consolidates the duplicated setup between ``_run_session`` and
        ``_run_resume_session``: client creation, progress callback, cancel
        awareness, and ``HybridOrchestrator.from_config`` invocation.

        Returns:
            A 3-tuple of (orchestrator, orchestrator_ref, cancel_aware_progress).
        """
        from obra.hybrid.orchestrator import HybridOrchestrator

        session_client = self._create_api_client()
        orchestrator_ref: dict[str, Any] = {}

        def _progress_callback(action: str, payload: dict[str, Any]) -> None:
            orchestrator = orchestrator_ref.get("instance")
            if orchestrator is not None:
                self._sync_hybrid_session_id(
                    session_id,
                    getattr(orchestrator, "session_id", None),
                )
            self._update_record_from_progress(session_id, action, payload)
            bridge.on_progress(action, payload)

        cancel_aware_progress = _make_cancel_aware_callback(
            record.cancel_event,
            _progress_callback,
        )
        orchestrator = HybridOrchestrator.from_config(
            client=session_client,
            working_dir=working_dir,
            on_progress=cancel_aware_progress,
            on_stream=bridge.on_stream,
            on_escalation=bridge.on_escalation,
            domain=record.domain_id,
        )
        orchestrator_ref["instance"] = orchestrator
        return orchestrator, orchestrator_ref, cancel_aware_progress

    def _update_record_from_progress(
        self,
        session_id: str,
        action: str,
        payload: dict[str, Any],
    ) -> None:
        with self._lock:
            record = self._sessions.get(session_id)
            if record is None:
                return
            self._reconciler.from_progress(
                record,
                action,
                payload,
                self._derivation_sessions,
            )

    def _update_record_from_remote_snapshot(
        self,
        record: SessionRecord,
        remote_session: dict[str, Any],
    ) -> None:
        self._reconciler.from_remote_snapshot(
            record,
            remote_session,
            self._derivation_sessions,
        )

    def _record_has_derivation(self, record: SessionRecord) -> bool:
        if isinstance(record.derivation_id, str) and record.derivation_id:
            return True
        request = record.request_context.get("workflow_derivation_request")
        return isinstance(request, dict) and bool(request)

    def get_workflow_event_bus(self, workflow_id: str) -> SessionEventBus:
        """Return the workflow-level event bus for one canonical workflow."""
        normalized_workflow_id = _string_or_none(workflow_id)
        if normalized_workflow_id is None:
            raise SessionNotFoundError(workflow_id)
        with self._lock:
            bus = self._workflow_event_buses.get(normalized_workflow_id)
            if bus is None:
                max_queue_size = int(self._get_gateway_config()["max_event_queue_size"])
                bus = SessionEventBus(
                    normalized_workflow_id,
                    escalation_timeout_s=self._escalation_timeout_s,
                    max_queue_size=max_queue_size,
                    raw_event_observer=lambda raw_event: self._observe_workflow_raw_event(
                        normalized_workflow_id,
                        raw_event,
                    ),
                )
                self._workflow_event_buses[normalized_workflow_id] = bus
            return bus

    def emit_workflow_event(self, workflow_id: str, payload: dict[str, Any]) -> None:
        """Emit a workflow-level event for Stage C mutation subscribers."""
        event_name = str(payload.get("event_name") or "").strip()
        if not event_name:
            return
        bus = self.get_workflow_event_bus(workflow_id)
        bus.push_event(
            event_name,
            {
                **dict(payload),
                "workflow_id": workflow_id,
            },
        )
