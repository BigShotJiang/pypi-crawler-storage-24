"""Config-wired cursor pagination helpers for gateway list routes."""

from __future__ import annotations

import base64
from dataclasses import dataclass
from typing import Any, Mapping, Sequence

from fastapi import Request

from obra.gateway.errors import GatewayAPIError


@dataclass(frozen=True, slots=True)
class PaginationParams:
    """Parsed pagination parameters for one request."""

    cursor: str | None
    limit: int
    default_limit: int
    max_limit: int
    offset: int
    requested: bool


def pagination_params_from_request(request: Request) -> PaginationParams:
    """Parse cursor pagination parameters from a request query string."""
    gateway_config = getattr(request.app.state, "gateway_config", None)
    if not isinstance(gateway_config, dict):
        raise GatewayAPIError(
            error_code="gateway_config_missing",
            message="Gateway pagination configuration is unavailable",
            status_code=500,
        )

    try:
        default_limit = int(gateway_config["pagination_default_limit"])
        max_limit = int(gateway_config["pagination_max_limit"])
    except (KeyError, TypeError, ValueError) as exc:
        raise GatewayAPIError(
            error_code="gateway_pagination_config_invalid",
            message="Gateway pagination configuration is invalid",
            status_code=500,
        ) from exc
    return parse_pagination_params(
        request.query_params,
        default_limit=default_limit,
        max_limit=max_limit,
    )


def parse_pagination_params(
    query_params: Mapping[str, Any],
    *,
    default_limit: int,
    max_limit: int,
) -> PaginationParams:
    """Parse cursor and limit from a generic query-param mapping."""
    if default_limit <= 0 or max_limit <= 0 or default_limit > max_limit:
        raise GatewayAPIError(
            error_code="gateway_pagination_config_invalid",
            message="Gateway pagination limits are invalid",
            status_code=500,
        )

    cursor_raw = _normalize_query_value(query_params.get("cursor"))
    limit_raw = _normalize_query_value(query_params.get("limit"))
    requested = cursor_raw is not None or limit_raw is not None
    limit = default_limit
    if limit_raw is not None:
        try:
            limit = int(limit_raw)
        except ValueError as exc:
            raise GatewayAPIError(
                error_code="invalid_pagination_limit",
                message="Pagination limit must be an integer",
                status_code=400,
            ) from exc
        if limit < 1 or limit > max_limit:
            raise GatewayAPIError(
                error_code="invalid_pagination_limit",
                message=f"Pagination limit must be between 1 and {max_limit}",
                status_code=400,
            )

    offset = 0
    if cursor_raw is not None:
        offset = decode_offset_cursor(cursor_raw)

    return PaginationParams(
        cursor=cursor_raw,
        limit=limit,
        default_limit=default_limit,
        max_limit=max_limit,
        offset=offset,
        requested=requested,
    )


def paginate_collection(
    *,
    collection_key: str,
    items: Sequence[Any],
    params: PaginationParams,
    total_count: int | None = None,
    extra: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Paginate a list while preserving the route's existing collection key."""
    payload: dict[str, Any] = dict(extra or {})
    if not params.requested:
        payload[collection_key] = list(items)
        return payload

    total = len(items) if total_count is None else total_count
    page_items = list(items[params.offset : params.offset + params.limit])
    next_offset = params.offset + params.limit
    next_cursor = encode_offset_cursor(next_offset) if next_offset < total else None
    payload[collection_key] = page_items
    payload["pagination"] = {
        "next_cursor": next_cursor,
        "has_more": next_cursor is not None,
        "total_count": total,
    }
    return payload


def encode_offset_cursor(offset: int) -> str:
    """Encode an offset as an opaque URL-safe cursor."""
    if offset < 0:
        raise ValueError("offset must be non-negative")
    encoded = base64.urlsafe_b64encode(str(offset).encode("ascii")).decode("ascii")
    return encoded.rstrip("=")


def decode_offset_cursor(cursor: str) -> int:
    """Decode an opaque cursor into an offset."""
    normalized = cursor.strip()
    if not normalized:
        raise GatewayAPIError(
            error_code="invalid_pagination_cursor",
            message="Pagination cursor must not be empty",
            status_code=400,
        )
    padding = "=" * (-len(normalized) % 4)
    try:
        decoded = base64.urlsafe_b64decode((normalized + padding).encode("ascii")).decode("ascii")
        offset = int(decoded)
    except (ValueError, UnicodeDecodeError) as exc:
        raise GatewayAPIError(
            error_code="invalid_pagination_cursor",
            message="Pagination cursor is invalid",
            status_code=400,
        ) from exc
    if offset < 0:
        raise GatewayAPIError(
            error_code="invalid_pagination_cursor",
            message="Pagination cursor is invalid",
            status_code=400,
        )
    return offset


def _normalize_query_value(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None
