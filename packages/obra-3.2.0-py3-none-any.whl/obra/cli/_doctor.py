"""Doctor command implementation extracted from obra.cli._main."""

from __future__ import annotations

import logging
import os
import platform
import sys
from pathlib import Path
from typing import Any

import typer
from rich.markup import escape

from obra import __version__
from obra.cli.feedback import offer_bug_report
from obra.config import DEFAULT_MODEL, DEFAULT_PROVIDER, DEFAULT_REASONING_LEVEL
from obra.display import console, glyphs, handle_encoding_errors, print_error
from obra.exceptions import APIError
from obra.messages import get_message
from obra.model_registry import resolve_quality_tier

logger = logging.getLogger(__name__)


def _resolve_doctor_llm_config() -> dict[str, Any]:
    """Resolve the effective implementation LLM config for doctor output."""

    from obra.config.llm import resolve_llm_config

    return resolve_llm_config(
        "implementation",
        override_provider=os.environ.get("OBRA_PROVIDER") or None,
        override_model=os.environ.get("OBRA_MODEL") or None,
    )


def _check_python_version(console) -> bool:
    """Print the Python version diagnostic block."""
    console.print("[bold]Python Version:[/bold]")
    python_version = sys.version_info
    version_str = f"{python_version.major}.{python_version.minor}.{python_version.micro}"
    passed = False

    if python_version >= (3, 12):
        console.print(f"  [green]{glyphs.success}[/green] Python {version_str} (recommended)")
        passed = True
    else:
        console.print(
            f"  [yellow]{glyphs.warning}[/yellow] Python {version_str} (Python 3.12+ recommended)"
        )
        console.print(
            "    [dim]Obra works with Python 3.10+, but 3.12+ is recommended for best performance[/dim]"
        )
        passed = python_version >= (3, 10)

    console.print()
    return passed


def _check_authentication(console) -> bool:
    """Print the authentication diagnostic block."""
    console.print("[bold]Authentication:[/bold]")
    passed = False
    try:
        from obra.auth import get_current_auth

        auth = get_current_auth()
        if auth:
            console.print(f"  [green]{glyphs.success}[/green] Logged in as {auth.email}")
            passed = True
        else:
            console.print(f"  [yellow]{glyphs.warning}[/yellow] Not logged in")
            console.print(f"    [dim]{get_message('recovery.auth.login')}[/dim]")
    except typer.Exit:
        raise
    except Exception as exc:
        console.print(f"  [red]{glyphs.failure}[/red] Authentication check failed: {exc}")
        logger.debug("Auth check error: %s", exc, exc_info=True)

    console.print()
    return passed


def _check_provider_clis(console) -> bool:
    """Print the provider CLI availability block."""
    console.print("[bold]Provider CLIs:[/bold]")
    provider_count = 0
    try:
        from obra.config import LLM_PROVIDERS, check_provider_status

        for provider_key in LLM_PROVIDERS:
            status = check_provider_status(provider_key)
            provider_name = LLM_PROVIDERS[provider_key].get("name", provider_key)

            if status.installed:
                console.print(
                    f"  [green]{glyphs.success}[/green] {provider_name} ({status.cli_command})"
                )
                provider_count += 1
            else:
                console.print(
                    f"  [red]{glyphs.failure}[/red] {provider_name} ({status.cli_command}) - not found"
                )
    except typer.Exit:
        raise
    except Exception as exc:
        console.print(f"  [red]{glyphs.failure}[/red] Provider check failed: {exc}")
        logger.debug("Provider check error: %s", exc, exc_info=True)

    console.print()
    return provider_count > 0


def _check_api_connectivity(console) -> bool:
    """Print the API connectivity diagnostic block."""
    console.print("[bold]API Connectivity:[/bold]")
    passed = False
    try:
        from obra.api import APIClient
        from obra.config import get_api_base_url

        client = APIClient(base_url=get_api_base_url())
        try:
            server_info = client.get_version()
            server_version = server_info.get("version", "N/A")
            api_version = server_info.get("api_version", "N/A")
            compatible = server_info.get("compatible", True)
            min_client = server_info.get("min_client_version", "0.0.0")

            console.print(f"  [green]{glyphs.success}[/green] Obra API reachable")
            console.print(f"    [dim]Server: v{server_version} (API {api_version})[/dim]")
            if compatible:
                console.print("    [dim]Client compatible with server[/dim]")
            else:
                from obra.install_guidance import recommended_upgrade_command

                console.print(
                    f"    [yellow]{glyphs.warning} Client update required (minimum: {min_client})[/yellow]"
                )
                console.print(f"    [dim]Run: {recommended_upgrade_command()}[/dim]")
            passed = True
        except APIError as exc:
            if exc.status_code == 0:
                console.print(f"  [red]{glyphs.failure}[/red] Cannot reach Obra API")
                console.print("    [dim]Check your network connection[/dim]")
            else:
                console.print(f"  [yellow]{glyphs.warning}[/yellow] API returned error: {exc}")
            logger.debug("API error in doctor: %s", exc, exc_info=True)
        except typer.Exit:
            raise
        except Exception as exc:
            console.print(f"  [red]{glyphs.failure}[/red] Cannot reach Obra API")
            console.print(f"    [dim]Error: {exc}[/dim]")
            logger.debug("Connection error in doctor: %s", exc, exc_info=True)
    except typer.Exit:
        raise
    except Exception as exc:
        console.print(f"  [red]{glyphs.failure}[/red] API check failed: {exc}")
        logger.debug("API check error: %s", exc, exc_info=True)

    console.print()
    return passed


def _check_working_directory(console) -> bool:
    """Print the working-directory diagnostic block."""
    console.print("[bold]Working Directory:[/bold]")
    passed = False
    try:
        cwd = Path.cwd()
        console.print(f"  Path: {cwd}")
        test_file = cwd / ".obra_doctor_test"
        try:
            test_file.write_text("test")
            test_file.unlink()
            console.print(f"  [green]{glyphs.success}[/green] Directory is writable")
            passed = True
        except PermissionError:
            console.print(f"  [red]{glyphs.failure}[/red] Directory is not writable")
            console.print("    [dim]Obra needs write access to create files[/dim]")
        except OSError as exc:
            console.print(f"  [yellow]{glyphs.warning}[/yellow] Write test failed: {exc}")
            passed = True
    except typer.Exit:
        raise
    except Exception as exc:
        console.print(f"  [red]{glyphs.failure}[/red] Working directory check failed: {exc}")
        logger.debug("Working directory check error: %s", exc, exc_info=True)

    console.print()
    return passed


def _check_workflow_studio(console) -> tuple[bool, dict[str, Any] | None]:
    """Print the Workflow Studio readiness block."""
    console.print("[bold]Workflow Studio:[/bold]")
    studio_payload: dict[str, Any] | None = None
    passed = False
    try:
        from obra.cli.studio import (
            _collect_studio_preflight,
            _studio_gateway_install_hint,
            _voice_dependency_available,
            _voice_install_hint,
        )

        studio_payload = _collect_studio_preflight(no_browser=True, host=None, port=None)
        if bool(studio_payload.get("healthy")):
            console.print(f"  [green]{glyphs.success}[/green] Workflow Studio preflight passed")
            passed = True
        else:
            console.print(f"  [yellow]{glyphs.warning}[/yellow] Workflow Studio needs attention")
            has_gateway_runtime_issue = False
            for check in studio_payload.get("checks", []):
                if not isinstance(check, dict) or str(check.get("status")) != "fail":
                    continue
                if str(check.get("name")) == "gateway_python_extra":
                    has_gateway_runtime_issue = True
                console.print(f"    [dim]{escape(str(check.get('detail')))}[/dim]")
            console.print("    [dim]Run: obra studio doctor[/dim]")
            if has_gateway_runtime_issue:
                console.print(
                    "    [dim]"
                    f"Install Workflow Studio runtime: {escape(_studio_gateway_install_hint())}"
                    "[/dim]"
                )
        if not _voice_dependency_available():
            console.print(
                f"    [dim]Optional voice dictation: {escape(_voice_install_hint())}[/dim]"
            )
    except typer.Exit:
        raise
    except Exception as exc:
        console.print(f"  [yellow]{glyphs.warning}[/yellow] Workflow Studio check failed: {exc}")
        logger.debug("Workflow Studio doctor check error: %s", exc, exc_info=True)

    console.print()
    return passed, studio_payload


def _check_codex_git_repo(console, llm_config: dict[str, Any]) -> tuple[list[str], list[str]]:
    """Validate Codex git requirements."""
    provider_issues: list[str] = []
    provider_warnings: list[str] = []
    cwd = Path.cwd()
    is_git_repo = (cwd / ".git").exists() or any((parent / ".git").exists() for parent in cwd.parents)
    codex_config = llm_config.get("codex", {})
    auto_init_git = codex_config.get("auto_init_git", False)
    skip_git_check = codex_config.get("skip_git_check", False)

    if is_git_repo:
        console.print(f"  [green]{glyphs.success}[/green] Git repository detected (Codex requirement)")
    elif auto_init_git:
        console.print(
            f"  [green]{glyphs.success}[/green] Git auto-init enabled (llm.codex.auto_init_git: true)"
        )
    elif skip_git_check:
        console.print(
            f"  [yellow]{glyphs.warning}[/yellow] Git check disabled (llm.codex.skip_git_check: true)"
        )
        provider_warnings.append("Git safety features bypassed")
    else:
        console.print(f"  [red]{glyphs.failure}[/red] Not in a git repository")
        console.print("    [dim]Codex requires git. Options:[/dim]")
        console.print("    [dim]  1. Run 'git init' in your project[/dim]")
        console.print("    [dim]  2. Set llm.codex.auto_init_git: true in config[/dim]")
        console.print("    [dim]  3. Set llm.codex.skip_git_check: true to bypass[/dim]")
        provider_issues.append("Git repository required for Codex")
    return provider_issues, provider_warnings


def _check_ollama_capabilities(
    console,
    config: dict[str, Any],
    doctor_llm_config: dict[str, Any],
) -> list[str]:
    """Print Ollama-specific guidance and return advisory warnings."""
    from obra.cli.config import _maybe_emit_ollama_fast_tip

    provider_warnings: list[str] = []
    console.print(f"  [green]{glyphs.success}[/green] Ollama provider configured")
    console.print("    [dim]Ensure Ollama server is running locally[/dim]")
    _maybe_emit_ollama_fast_tip(config)
    reasoning_level = doctor_llm_config.get("reasoning_level", "medium")
    enrichment = config.get("planning", {}).get("enrichment", {}).get("enabled", True)
    refinement_planning = config.get("refinement", {}).get("planning", {}).get("enabled", True)
    if reasoning_level not in ("off", "low"):
        console.print(
            f"    [yellow]{glyphs.warning}[/yellow] Ollama runs faster with reasoning_level=off "
            "(or use --profile ollama-fast)"
        )
        provider_warnings.append("Ollama reasoning level may slow local execution")
    if enrichment or refinement_planning:
        console.print(
            f"    [yellow]{glyphs.warning}[/yellow] Enrichment/refinement planning can be slow on local models; "
            "consider --profile ollama-fast"
        )
        provider_warnings.append("Ollama enrichment or refinement planning enabled")
    return provider_warnings


def _check_provider_config(
    console,
    selected_provider: str,
    config: dict[str, Any],
    doctor_llm_config: dict[str, Any],
) -> bool:
    """Print provider-specific configuration diagnostics."""
    llm_config = config.get("llm", {})
    provider_issues: list[str] = []
    provider_warnings: list[str] = []

    if selected_provider == "openai":
        provider_issues, provider_warnings = _check_codex_git_repo(console, llm_config)
    elif selected_provider == "google":
        console.print(f"  [green]{glyphs.success}[/green] Gemini provider configured")
        console.print("    [dim]Sandbox mode: permissive (for execution)[/dim]")
    elif selected_provider == "anthropic":
        console.print(f"  [green]{glyphs.success}[/green] Claude provider configured")
    elif selected_provider == "ollama":
        provider_warnings = _check_ollama_capabilities(console, config, doctor_llm_config)
    else:
        console.print(f"  [yellow]{glyphs.warning}[/yellow] Unknown provider: {selected_provider}")
        provider_warnings.append(f"Unrecognized provider: {selected_provider}")

    if provider_issues:
        console.print(f"  [red]{glyphs.failure}[/red] {len(provider_issues)} issue(s) need resolution")
        return False

    if provider_warnings:
        console.print(
            f"  [yellow]{glyphs.warning}[/yellow] {len(provider_warnings)} warning(s) - check config"
        )
    return True


def _display_llm_config(console, doctor_llm_config: dict[str, Any]) -> None:
    """Print the resolved LLM configuration block."""
    console.print("[bold]LLM Config:[/bold]")
    try:
        llm_provider = doctor_llm_config.get("provider", DEFAULT_PROVIDER)
        llm_model = doctor_llm_config.get("model", DEFAULT_MODEL)
        reasoning_level = doctor_llm_config.get("reasoning_level", DEFAULT_REASONING_LEVEL)
        quality_tier = resolve_quality_tier(llm_provider, llm_model)
        tier_suffix = " (auto-permissive)" if quality_tier == "fast" else ""
        console.print(f"  Provider: {llm_provider}")
        console.print(f"  Model: {llm_model}")
        console.print(f"  Reasoning level: {reasoning_level}")
        console.print(f"  Quality tier: {quality_tier}{tier_suffix}")
    except typer.Exit:
        raise
    except Exception as exc:
        console.print(f"  [yellow]{glyphs.warning}[/yellow] Could not resolve LLM config: {exc}")
        logger.debug("LLM config resolution error: %s", exc, exc_info=True)
    console.print()


def _display_health_summary(
    console,
    *,
    checks_passed: int,
    total_checks: int,
    report: bool,
    failures: list[str],
    diagnostic_payloads: dict[str, Any] | None = None,
) -> None:
    """Print the overall health summary and optional reporting hint."""
    console.print("[bold]Overall Health:[/bold]")
    percentage = int((checks_passed / total_checks) * 100)

    if percentage == 100:
        status_icon = f"[green]{glyphs.success}[/green]"
        status_text = "[green]Excellent - All checks passed![/green]"
    elif percentage >= 80:
        status_icon = f"[green]{glyphs.success}[/green]"
        status_text = "[green]Good - System is functional[/green]"
    elif percentage >= 60:
        status_icon = f"[yellow]{glyphs.warning}[/yellow]"
        status_text = "[yellow]Fair - Some issues detected[/yellow]"
    else:
        status_icon = f"[red]{glyphs.failure}[/red]"
        status_text = "[red]Poor - Multiple issues need attention[/red]"

    console.print(f"  {status_icon} {checks_passed}/{total_checks} checks passed ({percentage}%)")
    console.print(f"  {status_text}")
    console.print()

    if failures:
        if report:
            offer_bug_report(
                context="doctor diagnostics",
                command_used="obra doctor --report",
                failure_reason=f"{len(failures)} health check(s) failed ({percentage}%)",
                auto_report=True,
                diagnostic_payloads=diagnostic_payloads,
            )
        else:
            console.print(
                "[dim]Having trouble? Run 'obra doctor --report' to submit diagnostics[/dim]"
            )
            console.print()


def doctor(
    report: bool = typer.Option(
        False,
        "--report",
        help="Submit diagnostic report if checks fail (for troubleshooting)",
    ),
) -> None:
    """Run health checks on your Obra environment.

    Validates:
    - Python version compatibility
    - Authentication status
    - Provider CLI availability (claude, codex, gemini, ollama)
    - API connectivity and server compatibility
    - Working directory write permissions
    - Provider-specific configuration (git for Codex, etc.)

    Run this before 'obra run' to catch configuration issues early.

    Examples:
        $ obra doctor
        $ obra doctor --report   # Auto-submit if issues found
    """

    console.print()
    console.print("[bold]Obra Health Check[/bold]", style="cyan")
    console.print()

    console.print("[bold]Client Info:[/bold]")
    console.print(f"  Obra: v{__version__}")
    console.print(f"  Platform: {platform.system()} {platform.release()}")
    console.print()

    checks_passed = 0
    total_checks = 7
    failures: list[str] = []

    checks = [
        ("python_version", lambda: _check_python_version(console)),
        ("authentication", lambda: _check_authentication(console)),
        ("provider_clis", lambda: _check_provider_clis(console)),
        ("api_connectivity", lambda: _check_api_connectivity(console)),
        ("working_directory", lambda: _check_working_directory(console)),
    ]
    for name, check in checks:
        if check():
            checks_passed += 1
        else:
            failures.append(name)

    studio_ok, studio_payload = _check_workflow_studio(console)
    if studio_ok:
        checks_passed += 1
    else:
        failures.append("workflow_studio")

    console.print("[bold]Provider Configuration:[/bold]")
    doctor_llm_config = _resolve_doctor_llm_config()
    try:
        from obra.cli.config import _config_schema, _config_schema_version_warnings
        from obra.config.loaders import load_config_with_warnings

        config, warnings, _ = load_config_with_warnings()
        selected_provider = doctor_llm_config.get("provider", DEFAULT_PROVIDER)
        schema = _config_schema()
        schema_warnings = _config_schema_version_warnings(config, schema)
        if warnings or schema_warnings:
            console.print(f"  [yellow]{glyphs.warning}[/yellow] Config warnings detected")
            for warning in warnings + schema_warnings:
                console.print(f"    [dim]{warning}[/dim]")

        if _check_provider_config(console, selected_provider, config, doctor_llm_config):
            checks_passed += 1
        else:
            failures.append("provider_config")
    except typer.Exit:
        raise
    except Exception as exc:
        console.print(f"  [red]{glyphs.failure}[/red] Provider config check failed: {exc}")
        logger.debug("Provider config check error: %s", exc, exc_info=True)
        failures.append("provider_config")
    console.print()

    _display_llm_config(console, doctor_llm_config)
    _display_health_summary(
        console,
        checks_passed=checks_passed,
        total_checks=total_checks,
        report=report,
        failures=failures,
        diagnostic_payloads=(
            {"workflow_studio": studio_payload} if isinstance(studio_payload, dict) else None
        ),
    )
    console.print("[dim]Logs & monitoring: See ~/.obra/README.md for log paths and commands[/dim]")
    console.print()
