"""Feedback CLI commands extracted from obra.cli.feedback."""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

import typer
from rich.table import Table

from obra.cli._error_handling import handle_command_error
from obra.cli.feedback_shared import (
    _check_telemetry_consent,
    _display_submission_result,
    _get_privacy_level,
    _get_recent_session_id,
    _get_severity,
)
from obra.display import console, handle_encoding_errors, print_error, print_info, print_success

logger = logging.getLogger(__name__)


def _submit_feedback_report(
    collector: Any,
    report: Any,
    format_output: str,
    non_interactive: bool,
    success_message: str,
) -> None:
    """Shared submission logic for feedback commands.

    Handles telemetry consent, submission, JSON vs text output branching,
    and exit code determination.

    Args:
        collector: ``FeedbackCollector`` instance.
        report: The feedback report object to submit.
        format_output: ``"json"`` for machine-readable output, anything
            else for rich console rendering.
        non_interactive: When ``True``, skip interactive prompts.
        success_message: Fallback message label (unused directly but
            kept for future extensibility / caller context).
    """
    _check_telemetry_consent(non_interactive=non_interactive)

    result = collector.submit(report)

    if format_output == "json":
        print(json.dumps(result, indent=2, default=str))
        raise typer.Exit(0 if result.get("success") else 1)
    _display_submission_result(result, console)
    raise typer.Exit(0 if result.get("success") else 1)


def _preview_or_submit(
    collector: Any,
    report: Any,
    format_output: str,
    non_interactive: bool,
    success_message: str,
    preview: bool,
    target_console: Any,
) -> None:
    """Handle preview display or submission for a feedback report.

    When *preview* is ``True``, renders the report data that would be
    submitted (JSON for ``format_output=="json"``, Rich-formatted otherwise).
    When *preview* is ``False``, delegates to ``_submit_feedback_report``.

    Args:
        collector: ``FeedbackCollector`` instance.
        report: The feedback report object.
        format_output: ``"json"`` for machine-readable output, anything
            else for rich console rendering.
        non_interactive: When ``True``, skip interactive prompts.
        success_message: Message label forwarded to ``_submit_feedback_report``.
        preview: Whether to show a preview instead of submitting.
        target_console: Rich console instance for output.
    """
    if preview:
        if format_output == "json":
            preview_data = collector.preview_submission(report)
            print(json.dumps(preview_data, indent=2, default=str))
        else:
            target_console.print()
            target_console.print("[bold cyan]Preview - Data that will be submitted:[/bold cyan]")
            target_console.print()
            preview_data = collector.preview_submission(report)
            target_console.print(json.dumps(preview_data, indent=2, default=str))
            target_console.print()
            target_console.print("[dim]Run without --preview to submit.[/dim]")
        return

    _submit_feedback_report(collector, report, format_output, non_interactive, success_message)


feedback_app = typer.Typer(
    name="feedback",
    help="Submit bug reports, feature requests, and feedback",
    invoke_without_command=True,
    rich_markup_mode="rich",
)


def bug(
    summary: str = typer.Argument(..., help="One-line bug description"),
    non_interactive: bool = typer.Option(
        False,
        "--non-interactive",
        help="Non-interactive mode (no prompts, for orchestrator use)",
    ),
    format_output: str = typer.Option(
        "text",
        "--format",
        "-f",
        help="Output format: text, json",
    ),
    severity: str = typer.Option(
        "medium",
        "--severity",
        "-s",
        help="Bug severity: critical, high, medium, low",
    ),
    error: str = typer.Option(
        "",
        "--error",
        "-e",
        help="Error message if any",
    ),
    privacy: str = typer.Option(
        "standard",
        "--privacy",
        "-p",
        help="Privacy level: full, standard, minimal",
    ),
) -> None:
    """Quick bug report shortcut.

    Shortcut for `obra feedback bug`. For more options, use the full command.

    Examples:
        obra bug "App crashes on startup"
        obra bug "Orchestrator hangs" --severity high
        obra bug "Error in derive" --error "ValueError: invalid"

    For more options (attachments, session ID, etc.):
        obra feedback bug --help
    """
    from obra.feedback import FeedbackCollector

    try:
        privacy_level = _get_privacy_level(privacy)
        collector = FeedbackCollector(privacy_level=privacy_level)

        # Auto-detect recent session
        session_id = _get_recent_session_id()
        if session_id and not non_interactive:
            console.print(f"[dim]Auto-detected session: {session_id}[/dim]")

        report = collector.create_bug_report(
            summary=summary,
            severity=_get_severity(severity),
            error_message=error,
            session_id=session_id,
        )

        _submit_feedback_report(
            collector, report, format_output, non_interactive, "Bug report submitted"
        )

    except Exception as e:
        handle_command_error(e, format_output, "bug", console, include_bug_hint=False)


def feedback_callback(
    ctx: typer.Context,
) -> None:
    """Submit bug reports, feature requests, and feedback.

    Subcommands:
        bug      - Submit a bug report
        feature  - Request a new feature
        comment  - Submit general feedback
        drafts   - Manage saved drafts

    Privacy Levels:
        full     - Maximum data for debugging (prompts, logs, system info)
        standard - Balanced data (truncated prompts, errors, basic system info)
        minimal  - Essential data only (summary, category, Obra version)

    Examples:
        obra feedback bug "App crashes on startup"
        obra feedback feature "Add dark mode"
        obra feedback comment "Great documentation!"
    """
    # If no subcommand was invoked, show help
    if ctx.invoked_subcommand is None:
        console.print()
        console.print("[bold cyan]Obra Feedback System[/bold cyan]")
        console.print()
        console.print("Submit bug reports, feature requests, and feedback to help improve Obra.")
        console.print()
        console.print("[bold]Commands:[/bold]")
        console.print("  obra feedback bug 'App crashes'     # Bug report")
        console.print("  obra feedback feature 'Add X'       # Feature request")
        console.print("  obra feedback comment 'Nice work!'  # General comment")
        console.print()
        console.print("[dim]Run 'obra feedback --help' for more options.[/dim]")


def feedback_bug(
    summary: str = typer.Argument(..., help="One-line bug summary"),
    non_interactive: bool = typer.Option(
        False,
        "--non-interactive",
        help="Non-interactive mode (no prompts, for orchestrator use)",
    ),
    format_output: str = typer.Option(
        "text",
        "--format",
        "-f",
        help="Output format: text, json",
    ),
    severity: str = typer.Option(
        "medium",
        "--severity",
        "-s",
        help="Bug severity: critical, high, medium, low",
    ),
    description: str = typer.Option(
        "",
        "--description",
        "-d",
        help="Detailed description",
    ),
    steps: str = typer.Option(
        "",
        "--steps",
        help="Steps to reproduce (use \\n for newlines)",
    ),
    expected: str = typer.Option(
        "",
        "--expected",
        help="Expected behavior",
    ),
    actual: str = typer.Option(
        "",
        "--actual",
        help="Actual behavior",
    ),
    error: str = typer.Option(
        "",
        "--error",
        "-e",
        help="Error message if any",
    ),
    command: str = typer.Option(
        "",
        "--command",
        help="The obra command that triggered the bug",
    ),
    session_id: str = typer.Option(
        None,
        "--session",
        help="Session ID for context (auto-detected if recent)",
    ),
    workaround: str = typer.Option(
        "",
        "--workaround",
        "-w",
        help="Known workaround if any",
    ),
    attach: list[Path] = typer.Option(
        None,
        "--attach",
        "-a",
        help="Attach files (logs, screenshots)",
    ),
    privacy: str = typer.Option(
        "standard",
        "--privacy",
        "-p",
        help="Privacy level: full, standard, minimal",
    ),
    preview: bool = typer.Option(
        False,
        "--preview",
        help="Preview what will be sent without submitting",
    ),
) -> None:
    """Submit a bug report.

    Include as much detail as possible to help diagnose the issue.
    System information and recent logs are automatically collected
    based on your chosen privacy level.

    Examples:
        obra feedback bug "App crashes on startup"
        obra feedback bug "Orchestrator hangs" --severity high
        obra feedback bug "Error in derive" --error "ValueError: invalid input"
        obra feedback bug "Crash with spaces" --session abc-123 --attach session.log

    Privacy Levels:
        full     - Include full prompts, logs, and system details
        standard - Include truncated prompts, errors, basic info (default)
        minimal  - Summary, severity, and Obra version only
    """
    from obra.feedback import FeedbackCollector

    try:
        privacy_level = _get_privacy_level(privacy)
        collector = FeedbackCollector(privacy_level=privacy_level)

        # Convert attachment paths to strings
        attachment_paths = [str(p) for p in attach] if attach else []

        # Auto-detect recent session if not provided
        effective_session_id = session_id or _get_recent_session_id()
        if effective_session_id and not session_id and not non_interactive:
            console.print(f"[dim]Auto-detected session: {effective_session_id}[/dim]")

        report = collector.create_bug_report(
            summary=summary,
            severity=_get_severity(severity),
            description=description,
            steps_to_reproduce=steps.replace("\\n", "\n") if steps else "",
            expected_behavior=expected,
            actual_behavior=actual,
            error_message=error,
            command_used=command,
            session_id=effective_session_id,
            workaround=workaround,
            attachment_paths=attachment_paths,
        )

        _preview_or_submit(
            collector,
            report,
            format_output,
            non_interactive,
            "Bug report submitted",
            preview,
            console,
        )

    except Exception as e:
        handle_command_error(e, format_output, "feedback bug", console, include_bug_hint=False)


def feedback_feature(
    title: str = typer.Argument(..., help="Feature title"),
    non_interactive: bool = typer.Option(
        False,
        "--non-interactive",
        help="Non-interactive mode (no prompts, for orchestrator use)",
    ),
    format_output: str = typer.Option(
        "text",
        "--format",
        help="Output format: text, json",
    ),
    use_case: str = typer.Option(
        "",
        "--use-case",
        "-u",
        help="Why do you need this feature?",
    ),
    description: str = typer.Option(
        "",
        "--description",
        "-d",
        help="Detailed description of the feature",
    ),
    workaround: str = typer.Option(
        "",
        "--workaround",
        "-w",
        help="How do you handle this currently?",
    ),
    impact: str = typer.Option(
        "",
        "--impact",
        "-i",
        help="How would this help your work?",
    ),
    frequency: str = typer.Option(
        "",
        "--frequency",
        "-f",
        help="How often would you use this? (daily, weekly, monthly)",
    ),
    similar: str = typer.Option(
        "",
        "--similar",
        help="Have you seen this in other tools?",
    ),
    privacy: str = typer.Option(
        "standard",
        "--privacy",
        "-p",
        help="Privacy level: full, standard, minimal",
    ),
    preview: bool = typer.Option(
        False,
        "--preview",
        help="Preview what will be sent without submitting",
    ),
) -> None:
    """Request a new feature.

    Describe the feature you'd like to see in Obra. Include your use case
    and how it would help your workflow.

    Examples:
        obra feedback feature "Add dark mode"
        obra feedback feature "Export to PDF" --use-case "Share reports with team"
        obra feedback feature "Git integration" --frequency daily --impact "Save 10 min/day"

    Tips:
        - Be specific about the problem you're trying to solve
        - Include frequency of need to help prioritize
        - Mention similar features in other tools if applicable
    """
    from obra.feedback import FeedbackCollector

    try:
        privacy_level = _get_privacy_level(privacy)
        collector = FeedbackCollector(privacy_level=privacy_level)

        report = collector.create_feature_request(
            feature_title=title,
            use_case=use_case,
            description=description,
            current_workaround=workaround,
            business_impact=impact,
            frequency_of_need=frequency,
            similar_tools=similar,
        )

        _preview_or_submit(
            collector,
            report,
            format_output,
            non_interactive,
            "Feature request submitted",
            preview,
            console,
        )

    except Exception as e:
        handle_command_error(e, format_output, "feedback feature", console, include_bug_hint=False)


def feedback_comment(
    text: str = typer.Argument(..., help="Your feedback"),
    non_interactive: bool = typer.Option(
        False,
        "--non-interactive",
        help="Non-interactive mode (no prompts, for orchestrator use)",
    ),
    format_output: str = typer.Option(
        "text",
        "--format",
        help="Output format: text, json",
    ),
    category: str = typer.Option(
        "general",
        "--category",
        "-c",
        help="Category: general, documentation, ux, performance",
    ),
    suggestion: str = typer.Option(
        "",
        "--suggestion",
        "-s",
        help="Improvement suggestion",
    ),
    privacy: str = typer.Option(
        "standard",
        "--privacy",
        "-p",
        help="Privacy level: full, standard, minimal",
    ),
    preview: bool = typer.Option(
        False,
        "--preview",
        help="Preview what will be sent without submitting",
    ),
) -> None:
    """Submit general feedback or a comment.

    Share your thoughts about Obra - what's working well, what could be better,
    or general observations about your experience.

    Examples:
        obra feedback comment "Great documentation!"
        obra feedback comment "Slow on large projects" --category performance
        obra feedback comment "Hard to find settings" --category ux --suggestion "Add search"

    Categories:
        general       - General feedback (default)
        documentation - Feedback about docs
        ux            - User experience feedback
        performance   - Performance observations
    """
    from obra.feedback import FeedbackCollector

    try:
        privacy_level = _get_privacy_level(privacy)
        collector = FeedbackCollector(privacy_level=privacy_level)

        from obra.config.loaders import get_display_limit

        summary_limit = get_display_limit("summary_max_chars")
        report = collector.create_comment(
            summary=text[:summary_limit] + ("..." if len(text) > summary_limit else ""),
            description=text,
            category=category,
            suggestion=suggestion,
        )

        _preview_or_submit(
            collector,
            report,
            format_output,
            non_interactive,
            "Comment submitted",
            preview,
            console,
        )

    except Exception as e:
        handle_command_error(e, format_output, "feedback comment", console, include_bug_hint=False)


def feedback_drafts(
    delete: str = typer.Option(
        None,
        "--delete",
        "-d",
        help="Delete a draft by report ID",
    ),
) -> None:
    """List and manage feedback drafts.

    Drafts are automatically saved when creating feedback reports.
    Use this command to view, resume, or delete saved drafts.

    Examples:
        obra feedback drafts                    # List all drafts
        obra feedback drafts --delete abc-123   # Delete a draft
    """
    from obra.feedback import FeedbackCollector

    try:
        collector = FeedbackCollector()

        if delete:
            if collector.delete_draft(delete):
                print_success(f"Draft deleted: {delete}")
            else:
                print_error(f"Draft not found: {delete}")
            return

        drafts = collector.list_drafts()

        console.print()
        if not drafts:
            print_info("No drafts saved")
            return

        console.print(f"[bold cyan]Saved Drafts[/bold cyan] ({len(drafts)} total)")
        console.print()

        table = Table()
        table.add_column("Report ID", style="cyan")
        table.add_column("Type", style="bold")
        table.add_column("Summary")
        table.add_column("Created", style="dim")

        for draft in drafts:
            report_id = draft.get("report_id", "")[:8] + "..."
            feedback_type = draft.get("type", "unknown")
            from obra.config.loaders import get_display_limit

            title_limit = get_display_limit("title_max_chars")
            summary = draft.get("summary", "")[:title_limit] + (
                "..." if len(draft.get("summary", "")) > title_limit else ""
            )
            created = draft.get("created_at", "N/A")

            if "T" in str(created):
                try:
                    from datetime import datetime

                    dt = datetime.fromisoformat(created.replace("Z", "+00:00"))
                    created = dt.strftime("%Y-%m-%d %H:%M")
                except (ValueError, TypeError):
                    pass

            table.add_row(report_id, feedback_type, summary, created)

        console.print(table)
        console.print()
        console.print("[dim]Delete with: obra feedback drafts --delete <report_id>[/dim]")

    except Exception as e:
        handle_command_error(e, None, "feedback drafts", console, include_bug_hint=False)


def feedback_sync() -> None:
    """Sync pending feedback to server.

    Attempts to submit any feedback that was stored locally due to
    network issues. Run this when you regain connectivity.

    Examples:
        obra feedback sync
    """
    from obra.feedback import FeedbackCollector

    try:
        collector = FeedbackCollector()
        result = collector.sync_pending()

        console.print()
        if result["synced"] > 0:
            print_success(f"Synced {result['synced']} pending report(s)")
        if result["failed"] > 0:
            console.print(f"[yellow]Failed to sync {result['failed']} report(s):[/yellow]")
            for err in result.get("errors", []):
                report_id = err.get("report_id", "unknown")
                error_msg = err.get("error", "unknown error")
                if report_id == "*":
                    console.print(f"  [yellow]All reports:[/yellow] {error_msg}")
                else:
                    short_id = report_id[:12]
                    console.print(f"  [yellow]{short_id}:[/yellow] {error_msg}")
        if result["remaining"] > 0:
            console.print(f"[dim]{result['remaining']} report(s) still pending[/dim]")
        if result["synced"] == 0 and result["failed"] == 0:
            print_info("No pending reports to sync")

    except Exception as e:
        handle_command_error(e, None, "feedback sync", console, include_bug_hint=False)


bug = handle_encoding_errors(bug)
feedback_bug = handle_encoding_errors(feedback_bug)
feedback_feature = handle_encoding_errors(feedback_feature)
feedback_comment = handle_encoding_errors(feedback_comment)
feedback_drafts = handle_encoding_errors(feedback_drafts)
feedback_sync = handle_encoding_errors(feedback_sync)
feedback_app.callback()(feedback_callback)
feedback_app.command("bug")(feedback_bug)
feedback_app.command("feature")(feedback_feature)
feedback_app.command("comment")(feedback_comment)
feedback_app.command("drafts")(feedback_drafts)
feedback_app.command("sync")(feedback_sync)
