"""Helpers for rendering workflow lifecycle state in CLI surfaces."""

from __future__ import annotations

from typing import Any

_LIFECYCLE_CAPABILITY_ORDER = (
    "story0",
    "preflight",
    "review",
    "wait_resume",
    "git_required",
    "tooling_verification",
)


def extract_lifecycle_status(
    workflow_lifecycle: Any,
    lifecycle_decisions: Any,
) -> dict[str, Any]:
    """Build a compact, stable lifecycle summary for CLI rendering."""
    workflow_dict = dict(workflow_lifecycle) if isinstance(workflow_lifecycle, dict) else {}
    decisions_dict = dict(lifecycle_decisions) if isinstance(lifecycle_decisions, dict) else {}

    capability_states: dict[str, str] = {}
    raw_capability_states = workflow_dict.get("capability_states")
    if isinstance(raw_capability_states, dict):
        for capability in _LIFECYCLE_CAPABILITY_ORDER:
            state = str(raw_capability_states.get(capability, "") or "").strip().lower()
            if state:
                capability_states[capability] = state
        for raw_capability, raw_state in raw_capability_states.items():
            capability = str(raw_capability or "").strip()
            state = str(raw_state or "").strip().lower()
            if capability and state and capability not in capability_states:
                capability_states[capability] = state
    else:
        for capability in _LIFECYCLE_CAPABILITY_ORDER:
            entry = workflow_dict.get(capability)
            if not isinstance(entry, dict):
                continue
            state = str(entry.get("state", "") or "").strip().lower()
            if state:
                capability_states[capability] = state

    return {
        "selected_path": str(decisions_dict.get("selected_path", "") or "").strip(),
        "next_action": str(decisions_dict.get("next_action", "") or "").strip(),
        "resume_target": str(decisions_dict.get("resume_target", "") or "").strip(),
        "wait_resume_supported": bool(decisions_dict.get("wait_resume_supported", False)),
        "operator_review_pending": bool(decisions_dict.get("operator_review_pending", False)),
        "operator_review_required": bool(decisions_dict.get("operator_review_required", False)),
        "capability_states": capability_states,
    }


def format_lifecycle_capability_states(workflow_lifecycle: Any) -> str:
    """Render capability states in a compact human-readable format."""
    lifecycle_status = extract_lifecycle_status(workflow_lifecycle, {})
    capability_states = lifecycle_status["capability_states"]
    if not capability_states:
        return ""
    return ", ".join(f"{capability}={state}" for capability, state in capability_states.items())
