"""Helpers for deterministic seeded review-episode simulations."""

from __future__ import annotations

import os
from datetime import datetime, timezone
from types import SimpleNamespace
from typing import Any

# ---------------------------------------------------------------------------
# Escalation-fixer delegation — definitions now live in
# obra.cli.simulation_escalation_fixer.
# ---------------------------------------------------------------------------
from obra.cli.simulation_escalation_fixer import (  # noqa: F401
    _prime_pending_escalation_fixer,
)

# ---------------------------------------------------------------------------
# Re-exports from the normalization module.
#
# All normalization functions have been extracted to
# obra.cli.simulation_review_normalization.  The imports below preserve
# backward compatibility for every external caller that was importing from
# this module.
# ---------------------------------------------------------------------------
from obra.cli.simulation_review_normalization import (  # noqa: F401
    _SESSION_SNAPSHOT_VERSION,
    _SUPPORTED_SESSION_SNAPSHOT_SUBCOLLECTIONS,
    _build_project_context_patch,
    _deep_merge,
    _fresh_seeded_session_expiry,
    _load_structured_file,
    _normalize_pending_escalation_fixer,
    _normalize_scorecard_payload,
    _normalize_session_patch,
    _normalize_session_snapshot,
    _resolve_relative_asset,
    _restore_snapshot_value,
    _serialize_snapshot_value,
    prepare_seeded_review_session_updates,
)


def _resolve_firebase_admin_init_config(
    env: dict[str, str] | None = None,
) -> tuple[Any, dict[str, Any] | None]:
    """Resolve Firebase Admin initialization for emulator-backed CLI helpers."""
    source = env or os.environ
    emulator_host = source.get("FIRESTORE_EMULATOR_HOST", "").strip()
    if not emulator_host:
        return (None, None)

    project_id = (
        source.get("OBRA_FIREBASE_EMULATOR_PROJECT_ID", "").strip()
        or source.get("GOOGLE_CLOUD_PROJECT", "").strip()
        or source.get("GCLOUD_PROJECT", "").strip()
    )
    if not project_id:
        raise RuntimeError(
            "Local Firestore emulator mode requires OBRA_FIREBASE_EMULATOR_PROJECT_ID "
            "or GOOGLE_CLOUD_PROJECT."
        )

    from firebase_admin import credentials as firebase_credentials
    from google.auth.credentials import AnonymousCredentials

    class _EmulatorAdminCredential(firebase_credentials.Base):
        def __init__(self) -> None:
            self._credential = AnonymousCredentials()

        def get_credential(self) -> AnonymousCredentials:
            return self._credential

    return (_EmulatorAdminCredential(), {"projectId": project_id})


class _SeededReviewSessionManager:
    """Minimal Firestore-backed session adapter for local simulation helpers."""

    def __init__(self, user_id: str, db: Any):
        if not user_id:
            raise ValueError("user_id is required for seeded review session access")
        self._user_id = user_id
        self._db = db

    def _global_session_doc(self, session_id: str) -> Any:
        return self._db.collection("sessions").document(session_id)

    def _session_doc(self, session_id: str) -> Any:
        return (
            self._db.collection("users")
            .document(self._user_id)
            .collection("sessions")
            .document(session_id)
        )

    def _quality_scorecards_collection(self, session_id: str) -> Any:
        return self._session_doc(session_id).collection("quality_scorecards")

    def get_session(self, session_id: str) -> Any | None:
        doc = self._global_session_doc(session_id).get()
        if not doc.exists:
            doc = self._session_doc(session_id).get()
            if not doc.exists:
                return None
        return SimpleNamespace(**dict(doc.to_dict() or {}))

    def update_session(self, session_id: str, updates: dict[str, Any]) -> bool:
        doc = self._global_session_doc(session_id).get()
        if not doc.exists:
            doc = self._session_doc(session_id).get()
            if not doc.exists:
                return False

        from firebase_admin import firestore

        payload = dict(updates)
        payload["updated_at"] = firestore.SERVER_TIMESTAMP
        self._session_doc(session_id).update(payload)
        self._global_session_doc(session_id).set(payload, merge=True)
        return True

    def store_quality_scorecard(self, session_id: str, scorecard_payload: dict[str, Any]) -> str:
        from firebase_admin import firestore

        payload = dict(scorecard_payload)
        item_id = str(payload.get("item_id", "") or "").strip()
        iteration = int(payload.get("iteration", 0) or 0)
        doc_id = f"{item_id}_{iteration}"
        payload["created_at"] = firestore.SERVER_TIMESTAMP
        self._quality_scorecards_collection(session_id).document(doc_id).set(payload)
        return doc_id

    def get_all_quality_scorecards(self, session_id: str) -> list[dict[str, Any]]:
        from firebase_admin import firestore

        docs = (
            self._quality_scorecards_collection(session_id)
            .order_by("iteration", direction=firestore.Query.DESCENDING)
            .stream()
        )
        return [dict(doc.to_dict() or {}) for doc in docs]

    def get_latest_plan_version(self, session_id: str) -> Any | None:
        from firebase_admin import firestore

        docs = (
            self._session_doc(session_id)
            .collection("plan_versions")
            .order_by("created_at", direction=firestore.Query.DESCENDING)
            .limit(1)
            .stream()
        )
        for doc in docs:
            data = doc.to_dict() or {}
            return SimpleNamespace(**data)
        return None

    def store_progress_event(self, session_id: str, event_type: str, data: dict[str, Any]) -> None:
        import uuid

        from firebase_admin import firestore

        doc_id = str(uuid.uuid4())
        event_data = {
            "event_type": event_type,
            "data": data,
            "created_at": firestore.SERVER_TIMESTAMP,
        }
        self._session_doc(session_id).collection("progress_events").document(doc_id).set(event_data)


def _ensure_firestore_initialized():
    """Initialize Firebase Admin against the active emulator project."""
    import firebase_admin

    if not firebase_admin._apps:
        credential, options = _resolve_firebase_admin_init_config()
        firebase_admin.initialize_app(
            credential=credential,
            options=options,
        )

    from firebase_admin import firestore

    return firestore.client()


def capture_seeded_review_session_snapshot(session_id: str) -> dict[str, Any]:
    """Capture the replayable Firestore substrate for a seeded review session."""
    db = _ensure_firestore_initialized()
    normalized_session_id = str(session_id or "").strip()
    if not normalized_session_id:
        raise ValueError("Seeded review session snapshot requires session_id")

    global_doc = db.collection("sessions").document(normalized_session_id).get()
    if not global_doc.exists:
        raise ValueError(
            f"Seeded review episode session not found in emulator: {normalized_session_id}"
        )
    global_payload = dict(global_doc.to_dict() or {})
    user_id = str(global_payload.get("user_id", "") or "").strip()
    if not user_id:
        raise ValueError(
            f"Seeded review episode session {normalized_session_id} is missing user_id"
        )

    session_doc = (
        db.collection("users")
        .document(user_id)
        .collection("sessions")
        .document(normalized_session_id)
    )
    session_snapshot = session_doc.get()
    if not session_snapshot.exists:
        raise ValueError(
            f"Seeded review episode session not found in user scope: {normalized_session_id}"
        )

    subcollections: dict[str, list[dict[str, Any]]] = {}
    for name in _SUPPORTED_SESSION_SNAPSHOT_SUBCOLLECTIONS:
        docs = []
        for doc in session_doc.collection(name).stream():
            docs.append(
                {
                    "doc_id": doc.id,
                    "data": _serialize_snapshot_value(dict(doc.to_dict() or {})),
                }
            )
        subcollections[name] = sorted(docs, key=lambda entry: entry["doc_id"])

    project_snapshot: dict[str, Any] = {}
    project_id = str(
        (session_snapshot.to_dict() or {}).get("project_id")
        or global_payload.get("project_id")
        or ""
    ).strip()
    if project_id:
        project_doc = (
            db.collection("users")
            .document(user_id)
            .collection("projects")
            .document(project_id)
            .get()
        )
        if project_doc.exists:
            project_snapshot = {
                "project_id": project_id,
                "data": _serialize_snapshot_value(dict(project_doc.to_dict() or {})),
            }

    return _normalize_session_snapshot(
        {
            "snapshot_version": _SESSION_SNAPSHOT_VERSION,
            "session_id": normalized_session_id,
            "user_id": user_id,
            "project_snapshot": project_snapshot,
            "global_session": _serialize_snapshot_value(global_payload),
            "user_session": _serialize_snapshot_value(dict(session_snapshot.to_dict() or {})),
            "subcollections": subcollections,
        }
    )


def restore_seeded_review_session_snapshot(snapshot: dict[str, Any]) -> dict[str, Any]:
    """Restore a replayable session snapshot into the active emulator."""
    normalized = _normalize_session_snapshot(snapshot)
    if not normalized:
        return {}

    db = _ensure_firestore_initialized()
    session_id = str(normalized["session_id"])
    user_id = str(normalized["user_id"])

    user_doc = db.collection("users").document(user_id)
    if not user_doc.get().exists:
        user_doc.set({"created_at": datetime.now(timezone.utc).isoformat()})

    global_session = dict(normalized["global_session"])
    user_session = dict(normalized["user_session"])
    global_session.setdefault("session_id", session_id)
    global_session.setdefault("user_id", user_id)
    user_session.setdefault("session_id", session_id)
    user_session.setdefault("user_id", user_id)
    refreshed_expires_at = _fresh_seeded_session_expiry()
    global_session["expires_at"] = refreshed_expires_at
    user_session["expires_at"] = refreshed_expires_at

    db.collection("sessions").document(session_id).set(_restore_snapshot_value(global_session))
    session_doc = user_doc.collection("sessions").document(session_id)
    session_doc.set(_restore_snapshot_value(user_session))
    project_snapshot = dict(normalized.get("project_snapshot") or {})
    if project_snapshot:
        project_id = str(project_snapshot["project_id"])
        user_doc.collection("projects").document(project_id).set(
            _restore_snapshot_value(dict(project_snapshot["data"]))
        )

    restored_subcollections: dict[str, int] = {}
    for name in _SUPPORTED_SESSION_SNAPSHOT_SUBCOLLECTIONS:
        collection = session_doc.collection(name)
        for existing_doc in collection.stream():
            existing_doc.reference.delete()
        entries = list((normalized.get("subcollections") or {}).get(name) or [])
        for entry in entries:
            collection.document(str(entry["doc_id"])).set(
                _restore_snapshot_value(dict(entry["data"]))
            )
        restored_subcollections[name] = len(entries)

    return {
        "session_id": session_id,
        "user_id": user_id,
        "project_restored": bool(project_snapshot),
        "restored_subcollections": restored_subcollections,
        "restored_doc_count": sum(restored_subcollections.values()),
    }


def align_seeded_session_to_resume_target(
    *,
    session_id: str,
    resume_target: str,
) -> dict[str, Any]:
    """Align a restored seeded session to the checkpoint resume target."""
    normalized_session_id = str(session_id or "").strip()
    normalized_resume_target = str(resume_target or "").strip().lower()
    if not normalized_session_id or not normalized_resume_target:
        return {}

    db = _ensure_firestore_initialized()
    global_doc = db.collection("sessions").document(normalized_session_id).get()
    if not global_doc.exists:
        raise ValueError(
            f"Seeded review episode session not found in emulator: {normalized_session_id}"
        )
    global_payload = dict(global_doc.to_dict() or {})
    user_id = str(global_payload.get("user_id", "") or "").strip()
    if not user_id:
        raise ValueError(
            f"Seeded review episode session {normalized_session_id} is missing user_id"
        )

    manager = _SeededReviewSessionManager(user_id, db)
    session = manager.get_session(normalized_session_id)
    if session is None:
        raise ValueError(
            f"Seeded review episode session not found in user scope: {normalized_session_id}"
        )

    updates = prepare_seeded_review_session_updates(
        session=session,
        session_patch={"current_phase": normalized_resume_target},
    )
    if updates:
        manager.update_session(normalized_session_id, updates)

    return {
        "session_id": normalized_session_id,
        "resume_target": normalized_resume_target,
        "updated_fields": sorted(updates.keys()),
    }


def apply_seeded_review_episode_plan(plan: dict[str, Any]) -> dict[str, Any]:
    """Apply the hydrated review-episode plan to the local emulator."""
    if not plan:
        return {}

    db = _ensure_firestore_initialized()
    session_id = str(plan.get("session_id", "") or "").strip()
    if not session_id:
        raise ValueError("Seeded review episode plan is missing session_id")

    session_snapshot_summary: dict[str, Any] = {}
    session_snapshot = _normalize_session_snapshot(plan.get("session_snapshot"))
    if session_snapshot:
        session_snapshot_summary = restore_seeded_review_session_snapshot(session_snapshot)

    global_doc = db.collection("sessions").document(session_id).get()
    if not global_doc.exists:
        raise ValueError(f"Seeded review episode session not found in emulator: {session_id}")
    global_payload = global_doc.to_dict() or {}
    user_id = str(global_payload.get("user_id", "") or "").strip()
    if not user_id:
        raise ValueError(f"Seeded review episode session {session_id} is missing user_id")

    manager = _SeededReviewSessionManager(user_id, db)
    session = manager.get_session(session_id)
    if session is None:
        raise ValueError(f"Seeded review episode session not found in user scope: {session_id}")

    updates = prepare_seeded_review_session_updates(
        session=session,
        session_patch=dict(plan.get("session_patch") or {}),
    )
    if updates:
        manager.update_session(session_id, updates)

    for scorecard_payload in plan.get("scorecards") or []:
        manager.store_quality_scorecard(session_id, dict(scorecard_payload))

    pending_escalation_summary: dict[str, Any] = {}
    pending_escalation_fixer = dict(plan.get("pending_escalation_fixer") or {})
    if pending_escalation_fixer:
        refreshed_session = manager.get_session(session_id)
        if refreshed_session is None:
            raise ValueError(
                f"Seeded review episode session not found after scorecard load: {session_id}"
            )
        pending_escalation_summary = _prime_pending_escalation_fixer(
            manager=manager,
            session=refreshed_session,
            session_id=session_id,
            pending_config=pending_escalation_fixer,
        )

    return {
        "session_id": session_id,
        "user_id": user_id,
        "scorecard_count": len(plan.get("scorecards") or []),
        "item_ids": list(plan.get("item_ids") or []),
        "updated_session_fields": sorted(updates),
        "session_snapshot_restored": bool(session_snapshot_summary),
        "project_restored": bool(session_snapshot_summary.get("project_restored")),
        "restored_subcollections": dict(
            session_snapshot_summary.get("restored_subcollections") or {}
        ),
        "restored_doc_count": int(session_snapshot_summary.get("restored_doc_count", 0) or 0),
        "pending_escalation_fixer": pending_escalation_summary,
    }
