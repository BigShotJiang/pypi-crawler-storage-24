"""Skip tracking commands for the Obra CLI.

Extracted from obra/cli/_main.py as part of REFACTOR-CLI-SUBAPPS-001.
"""

import json
from datetime import UTC, datetime
from typing import Any

import typer
from rich.table import Table

from obra.display import (
    console,
    handle_encoding_errors,
    print_error,
    print_info,
    print_success,
)

skips_app = typer.Typer(
    name="skips",
    help="Manage skip records from execution gaps",
    no_args_is_help=True,
    rich_markup_mode="rich",
)


def _find_skip_record(skip_id: str):
    from obra.execution.skip_record import list_skip_records

    records = list_skip_records()
    matches = [record for record in records if record.id.startswith(skip_id)]
    if not matches:
        print_error(f"Skip record not found: {skip_id}")
        raise typer.Exit(1)
    if len(matches) > 1:
        print_error(f"Skip ID is ambiguous: {skip_id}")
        raise typer.Exit(1)
    return matches[0]


@skips_app.command("list")
@handle_encoding_errors
def skips_list(
    session_id: str | None = typer.Option(None, "--session-id", help="Filter by session ID"),
    source: str | None = typer.Option(None, "--source", help="Filter by skip source"),
    reason: str | None = typer.Option(None, "--reason", help="Filter by skip reason"),
    status: str | None = typer.Option(
        "pending", "--status", help="Filter by status (default: pending)"
    ),
    as_json: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """List skip records."""
    from obra.execution.skip_record import SkipSource, SkipStatus, list_skip_records

    source_enum = SkipSource(source) if source else None
    status_enum = SkipStatus(status) if status else None

    records = list_skip_records(source=source_enum, status=status_enum)
    if session_id:
        records = [r for r in records if r.session_id == session_id]
    if reason:
        records = [r for r in records if r.reason.value == reason]

    if as_json:
        payload = [record.to_dict() for record in records]
        console.print(json.dumps(payload, indent=2))
        return

    table = Table()
    table.add_column("ID", style="cyan")
    table.add_column("Task")
    table.add_column("Source")
    table.add_column("Reason")
    table.add_column("Created", style="dim")
    table.add_column("Status")

    for record in records:
        created_at = record.created_at
        if "T" in created_at:
            try:
                dt = datetime.fromisoformat(created_at.replace("Z", "+00:00"))
                created_at = dt.strftime("%Y-%m-%d %H:%M")
            except ValueError:
                pass
        table.add_row(
            record.id[:8],
            record.task_id,
            record.source.value,
            record.reason.value,
            created_at,
            record.status.value,
        )

    console.print(table)


@skips_app.command("show")
@handle_encoding_errors
def skips_show(skip_id: str) -> None:
    """Display full details of a skip record."""
    record = _find_skip_record(skip_id)

    console.print(f"[bold]Skip {record.id}[/bold]")
    console.print(f"Session: {record.session_id}")
    console.print(f"Task: {record.task_id}")
    console.print(f"Source: {record.source.value}")
    console.print(f"Reason: {record.reason.value}")
    console.print(f"Status: {record.status.value}")
    console.print(f"Created: {record.created_at}")
    console.print(f"Description: {record.description}")
    if record.required_input:
        console.print(f"Required Input: {json.dumps(record.required_input, indent=2)}")
    if record.attempted_resolution:
        console.print(f"Attempted Resolution: {record.attempted_resolution}")
    if record.file_context:
        console.print(f"File Context: {record.file_context}")
    if record.error_logs:
        console.print("Error Logs:")
        console.print(record.error_logs)
    if record.source_context:
        console.print(f"Source Context: {json.dumps(record.source_context, indent=2)}")
    if record.resolution_notes:
        console.print(f"Resolution Notes: {record.resolution_notes}")
    if record.resolved_at:
        console.print(f"Resolved At: {record.resolved_at}")
    if record.resolved_by:
        console.print(f"Resolved By: {record.resolved_by}")


@skips_app.command("resolve")
@handle_encoding_errors
def skips_resolve(
    skip_id: str,
    status: str = typer.Option(
        "resolved",
        "--status",
        help="Resolution status (resolved, deferred, wont_fix)",
    ),
    notes: str | None = typer.Option(None, "--notes", help="Resolution notes"),
    context_json: str | None = typer.Option(None, "--context", help="Resolution context JSON"),
) -> None:
    """Mark a skip record as resolved."""
    from obra.cleanup.resolver import parse_resolution_context
    from obra.execution.skip_record import SkipStatus, persist_skip_record

    record = _find_skip_record(skip_id)
    record.status = SkipStatus(status)
    if notes:
        record.resolution_notes = notes
    record.resolved_at = datetime.now(UTC).isoformat()
    record.resolved_by = "user"
    context = parse_resolution_context(context_json)
    if context:
        record.source_context = {
            **record.source_context,
            "resolution_context": context,
        }
    persist_skip_record(record)
    print_success(f"Skip {record.id[:8]} marked as {record.status.value}")


@skips_app.command("stats")
@handle_encoding_errors
def skips_stats() -> None:
    """Show skip statistics."""
    from obra.execution.skip_record import get_skip_metrics_summary

    summary = get_skip_metrics_summary()
    console.print(f"[bold]Total skips:[/bold] {summary.get('total', 0)}")

    def _render_breakdown(title: str, data: dict[str, Any]) -> None:
        if not data:
            return
        console.print(f"[bold]{title}[/bold]")
        table = Table()
        table.add_column("Key")
        table.add_column("Count", justify="right")
        for key, value in sorted(data.items()):
            table.add_row(str(key), str(value))
        console.print(table)

    _render_breakdown("By source", summary.get("by_source", {}))
    _render_breakdown("By reason", summary.get("by_reason", {}))
    _render_breakdown("By status", summary.get("by_status", {}))


@skips_app.command("cleanup")
@handle_encoding_errors
def skips_cleanup(
    interactive: bool = typer.Option(
        True,
        "--interactive/--no-interactive",
        help="Interactive resolution mode",
    ),
    export_plan: bool = typer.Option(
        False,
        "--export",
        help="Export cleanup epic as MACHINE_PLAN.json",
    ),
    auto: bool = typer.Option(
        False,
        "--auto",
        help="Auto-retry transient skips",
    ),
) -> None:
    """Generate cleanup epic from pending skips."""
    from obra.cleanup.epic_generator import (
        export_cleanup_as_machine_plan,
        generate_cleanup_epic,
    )
    from obra.cleanup.resolver import auto_retry_skips, resolve_skips_interactively
    from obra.execution.skip_record import SkipStatus, list_skip_records

    pending_skips = list_skip_records(status=SkipStatus.PENDING)
    epic = generate_cleanup_epic(pending_skips)

    if export_plan:
        path = export_cleanup_as_machine_plan(epic)
        print_success(f"Cleanup plan exported to {path}")

    if auto:
        auto_retry_skips(pending_skips)
        print_info("Auto-retry completed for eligible skips.")

    if interactive:
        resolve_skips_interactively(pending_skips)
