"""Consolidated CLI error handling.

Extracted from repeated try/except patterns across CLI command modules
(REFACTOR-DEBT-CLEANUP-001 S3.T0).
"""

from __future__ import annotations

import logging
from typing import NoReturn

import typer

from obra.cli.interrupt import _print_bug_hint
from obra.cli.userplan_shared import output_json_error
from obra.display.errors import display_error, display_obra_error
from obra.exceptions import APIError, ConfigurationError, ObraError

logger = logging.getLogger(__name__)

# Maps exception types to their JSON error code and log prefix.
_ERROR_CODE_MAP: dict[type, tuple[str, str]] = {
    APIError: ("API_ERROR", "API error"),
    ConfigurationError: ("CONFIG_ERROR", "Configuration error"),
    ObraError: ("OBRA_ERROR", "Obra error"),
}


def handle_command_error(
    exc: BaseException,
    format_output: str | None,
    command_name: str,
    console: object,
    *,
    include_bug_hint: bool = True,
) -> NoReturn:
    """Handle an exception raised during a CLI command.

    Consolidates the 5-branch try/except pattern (typer.Exit, APIError,
    ConfigurationError, ObraError, Exception) into a single call site.

    Args:
        exc: The caught exception.
        format_output: Output format string (``"json"`` triggers JSON error
            output, anything else triggers rich console display).  Pass
            ``None`` when the command has no ``--format`` option.
        command_name: Human-readable command name for log messages
            (e.g. ``"sessions list"``).
        console: Rich console instance for display output.
        include_bug_hint: Whether to print the ``obra bug`` hint after
            displaying the error.  Defaults to ``True``.

    Raises:
        typer.Exit: Always re-raised (code 1 for errors, or the original
            exit code for ``typer.Exit`` pass-through).
    """
    # typer.Exit should always propagate unchanged.
    if isinstance(exc, typer.Exit):
        raise exc

    # Determine error code / log prefix for known Obra exception types.
    for exc_type, (error_code, log_prefix) in _ERROR_CODE_MAP.items():
        if isinstance(exc, exc_type):
            if format_output == "json":
                output_json_error(str(exc), error_code)
                raise typer.Exit(1) from exc
            display_obra_error(exc, console)  # type: ignore[arg-type]
            logger.error("%s in %s command: %s", log_prefix, command_name, exc, exc_info=True)
            if include_bug_hint:
                _print_bug_hint()
            raise typer.Exit(1) from exc

    # Generic / unexpected exception fallback.
    if format_output == "json":
        output_json_error(str(exc), "UNKNOWN_ERROR")
        raise typer.Exit(1) from exc
    display_error(exc, console)  # type: ignore[arg-type]
    logger.exception("Unexpected error in %s command: %s", command_name, exc)
    if include_bug_hint:
        _print_bug_hint()
    raise typer.Exit(1) from exc
