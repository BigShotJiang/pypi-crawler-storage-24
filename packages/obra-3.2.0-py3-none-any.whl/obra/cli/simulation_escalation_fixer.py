"""Escalation-fixer helpers for seeded review-episode simulations.

Extracted from ``obra.cli.simulation_review_episode`` to reduce module size
and isolate the escalation-fixer concern.
"""

from __future__ import annotations

import json
import uuid
from typing import Any

from obra.api.protocol import ValidatorRequest
from obra.cli.simulation_review_normalization import _serialize_snapshot_value

# ---------------------------------------------------------------------------
# Scorecard and issue-detail helpers
# ---------------------------------------------------------------------------


def _scorecard_to_dict(scorecard: Any) -> dict[str, Any]:
    """Serialize a QualityScorecard-like object into a plain mapping."""
    if hasattr(scorecard, "to_dict"):
        payload = scorecard.to_dict()
        if isinstance(payload, dict):
            return payload
    if isinstance(scorecard, dict):
        return dict(scorecard)
    raise ValueError("Seeded escalation fixer requires a scorecard mapping")


def _extract_issue_details_from_reports(
    agent_reports: list[dict[str, Any]],
    issue_ids: set[str],
) -> list[dict[str, Any]]:
    """Collect canonical issue details from review agent reports."""
    details: list[dict[str, Any]] = []
    seen_ids: set[str] = set()
    for report in agent_reports:
        if not isinstance(report, dict):
            continue
        issues = report.get("issues")
        if not isinstance(issues, list):
            continue
        for issue in issues:
            if not isinstance(issue, dict):
                continue
            canonical_id = str(issue.get("canonical_id") or issue.get("id") or "").strip()
            if not canonical_id or canonical_id in seen_ids:
                continue
            if issue_ids and canonical_id not in issue_ids:
                continue
            detail = dict(issue)
            detail.setdefault("canonical_id", canonical_id)
            detail.setdefault("id", canonical_id)
            details.append(detail)
            seen_ids.add(canonical_id)
    return details


def _build_registry_issue_details(
    scorecard_payload: dict[str, Any],
    issue_ids: list[str],
) -> list[dict[str, Any]]:
    """Backfill issue details from scorecard issue_registry entries."""
    registry = (
        scorecard_payload.get("issue_registry")
        if isinstance(scorecard_payload.get("issue_registry"), dict)
        else {}
    )
    if not isinstance(registry, dict):
        return []
    details: list[dict[str, Any]] = []
    for issue_id in issue_ids:
        entry = registry.get(issue_id)
        if not isinstance(entry, dict):
            continue
        details.append(
            {
                "canonical_id": issue_id,
                "id": issue_id,
                "description": str(entry.get("description") or ""),
                "file_path": str(entry.get("file_path") or ""),
                "priority": str(entry.get("priority") or "P2"),
                "category": str(entry.get("category") or ""),
                "agent_type": str(entry.get("agent_type") or ""),
            }
        )
    return details


# ---------------------------------------------------------------------------
# Core escalation-fixer functions
# ---------------------------------------------------------------------------


def _resolve_pending_escalation_target(
    scorecards: list[dict[str, Any]],
    pending_config: dict[str, Any],
) -> dict[str, Any]:
    """Pick the scorecard that should own the seeded escalation-fixer episode."""
    target_item_id = str(pending_config.get("item_id", "") or "").strip()
    target_iteration = pending_config.get("iteration")
    candidates = []
    for scorecard in scorecards:
        item_id = str(scorecard.get("item_id", "") or "").strip()
        iteration = int(scorecard.get("iteration", 0) or 0)
        if target_item_id and item_id != target_item_id:
            continue
        if target_iteration is not None and iteration != int(target_iteration):
            continue
        candidates.append(scorecard)
    if not candidates:
        raise ValueError("Seeded pending escalation fixer could not find a matching scorecard")
    return sorted(
        candidates,
        key=lambda payload: (
            int(payload.get("iteration", 0) or 0),
            str(payload.get("item_id", "") or ""),
        ),
    )[-1]


def _build_escalation_fixer_subject_payload(
    *,
    session: Any,
    session_id: str,
    pending_config: dict[str, Any],
    target_scorecard: dict[str, Any],
) -> dict[str, Any]:
    """Build the escalation-fixer subject payload and associated metadata.

    Returns a mapping containing the subject_payload, original_spec,
    and all derived fields needed by ``_apply_escalation_fixer_session_state``.
    """
    from obra.config.loaders import get_escalation_fixer_timeout_s
    from prompts.registry import get_prompt, get_prompt_metadata

    item_id = str(target_scorecard.get("item_id", "") or "").strip()
    iteration = int(pending_config.get("iteration", target_scorecard.get("iteration", 0)) or 0)
    effective_issue_ids = [
        issue_id
        for issue_id in (
            pending_config.get("blocking_issue_ids")
            or target_scorecard.get("blocking_issues")
            or []
        )
        if str(issue_id).strip()
    ]
    resolved_issue_ids = {
        str(issue_id).strip()
        for issue_id in (target_scorecard.get("resolved_issues") or [])
        if str(issue_id).strip()
    }
    effective_issue_ids = [
        issue_id for issue_id in effective_issue_ids if issue_id not in resolved_issue_ids
    ]
    if not effective_issue_ids:
        raise ValueError(
            "Seeded pending escalation fixer requires at least one effective blocking issue"
        )

    agent_reports = target_scorecard.get("agent_reports")
    if not isinstance(agent_reports, list):
        agent_reports = []
    normalized_reports = [dict(report) for report in agent_reports if isinstance(report, dict)]
    serialized_reports = _serialize_snapshot_value(normalized_reports)
    serialized_scorecard = _serialize_snapshot_value(target_scorecard)

    issue_details = _extract_issue_details_from_reports(
        normalized_reports,
        set(effective_issue_ids),
    )
    if len(issue_details) < len(effective_issue_ids):
        present_ids = {
            str(detail.get("canonical_id") or detail.get("id") or "").strip()
            for detail in issue_details
        }
        missing_ids = [issue_id for issue_id in effective_issue_ids if issue_id not in present_ids]
        issue_details.extend(_build_registry_issue_details(target_scorecard, missing_ids))

    reason_code = str(pending_config["reason_code"])
    reason_text = str(
        pending_config.get("reason_text")
        or f"Seeded blocked review episode for {item_id} requested escalation fixer."
    ).strip()
    phase_value = getattr(session, "current_phase", "review")
    phase_name = phase_value.value if hasattr(phase_value, "value") else str(phase_value)
    episode_key = f"review:{reason_code}:{item_id or 'session'}:{iteration}"

    plan_items: list[dict[str, Any]] = []
    original_spec = {
        "session_id": session_id,
        "reason": "blocking_issues_unresolved",
        "reason_code": reason_code,
        "reason_text": reason_text,
        "blocking_issues": issue_details,
        "extra": {
            "item_id": item_id,
            "scope": "task",
            "escalation_origin": "review",
            "quality_score": target_scorecard.get("compiled_score"),
            "review_agent_reports": serialized_reports,
            "review_scorecard": serialized_scorecard,
            "review_effective_issue_ids": effective_issue_ids,
            "review_issue_details": issue_details,
        },
        "plan_items": plan_items,
        "iteration": iteration,
        "bypass_modes_active": list(getattr(session, "bypass_modes", []) or []),
    }
    subject_payload = {
        "session_id": session_id,
        "episode_key": episode_key,
        "phase": phase_name,
        "current_iteration": int(getattr(session, "current_iteration", 0) or 0),
        "reason": original_spec["reason"],
        "reason_code": reason_code,
        "reason_text": reason_text,
        "blocking_issues": issue_details,
        "quality_score": target_scorecard.get("compiled_score"),
        "item_id": item_id,
        "origin": "review",
        "convergence_diagnostic": None,
        "scorecard": serialized_scorecard,
        "agent_reports": serialized_reports,
        "review_effective_issue_ids": effective_issue_ids,
        "review_issue_details": issue_details,
        "plan_items": plan_items,
        "escalation_details": None,
        "revision_issues": None,
    }
    prompt_id = "escalation.fixer"
    prompt_metadata = get_prompt_metadata(prompt_id)
    prompt_version = str(prompt_metadata.get("version", "v1"))
    project_context = (
        getattr(session, "project_context", {})
        if isinstance(getattr(session, "project_context", {}), dict)
        else {}
    )
    session_config = (
        project_context.get("config")
        if isinstance(project_context.get("config"), dict)
        else project_context
    )
    review_cfg = (
        session_config.get("review")
        if isinstance(session_config, dict) and isinstance(session_config.get("review"), dict)
        else {}
    )
    escalation_cfg = (
        review_cfg.get("escalation_fixer")
        if isinstance(review_cfg.get("escalation_fixer"), dict)
        else {}
    )
    timeout_s = int(escalation_cfg.get("timeout_s") or get_escalation_fixer_timeout_s())
    allowed_routes = escalation_cfg.get("allowed_routes")
    if isinstance(allowed_routes, list):
        normalized_allowed_routes = [
            str(route).strip() for route in allowed_routes if str(route).strip()
        ]
    else:
        normalized_allowed_routes = []
    compiled_prompt = (
        f"{get_prompt(prompt_id).rstrip()}\n\n"
        "## Escalation Context\n"
        f"{json.dumps(subject_payload, indent=2, sort_keys=True)}\n"
    )
    validator_request = ValidatorRequest(
        stage="escalation_fix",
        subject_type="escalation_context",
        subject_payload=subject_payload,
        prompt_id=prompt_id,
        prompt_version=prompt_version,
        compiled_prompt=compiled_prompt,
        timeout_s=timeout_s,
        config={
            "schema_validation": True,
            "allowed_routes": normalized_allowed_routes,
        },
    )

    return {
        "item_id": item_id,
        "iteration": iteration,
        "reason_code": reason_code,
        "reason_text": reason_text,
        "episode_key": episode_key,
        "phase_name": phase_name,
        "effective_issue_ids": effective_issue_ids,
        "original_spec": original_spec,
        "subject_payload": subject_payload,
        "validator_request": validator_request,
        "prompt_id": prompt_id,
        "prompt_version": prompt_version,
        "timeout_s": timeout_s,
        "plan_items": plan_items,
    }


def _apply_escalation_fixer_session_state(
    *,
    manager: Any,
    session_id: str,
    payload_result: dict[str, Any],
) -> dict[str, Any]:
    """Write the escalation-fixer invocation record and progress event to Firestore.

    ``payload_result`` is the mapping returned by
    ``_build_escalation_fixer_subject_payload``.
    """
    item_id = payload_result["item_id"]
    iteration = payload_result["iteration"]
    reason_code = payload_result["reason_code"]
    reason_text = payload_result["reason_text"]
    episode_key = payload_result["episode_key"]
    phase_name = payload_result["phase_name"]
    effective_issue_ids = payload_result["effective_issue_ids"]
    original_spec = payload_result["original_spec"]
    validator_request = payload_result["validator_request"]
    prompt_id = payload_result["prompt_id"]
    prompt_version = payload_result["prompt_version"]
    timeout_s = payload_result["timeout_s"]

    fixer_invocation_id = str(uuid.uuid4())
    invocation_record = {
        "fixer_invocation_id": fixer_invocation_id,
        "session_id": session_id,
        "item_id": item_id or None,
        "scope": "task",
        "phase": phase_name,
        "episode_key": episode_key,
        "origin_stage": "review",
        "origin_reason_code": reason_code,
        "reason_text": reason_text,
        "pre_fixer_state": {"original_escalation": original_spec},
        "prompt_provenance": {
            "prompt_id": prompt_id,
            "prompt_version": prompt_version,
            "model_provider": None,
            "model_name": None,
            "model_tier": "inherit",
            "timeout_s": timeout_s,
        },
        "fixer_result": {},
        "outcome": {
            "fallback_to_original": False,
            "next_action": "",
            "requires_triage": True,
        },
        "status": "requested",
    }
    pipeline_resume_context = {
        "action": "escalate",
        "validator_stage": "escalation_fix",
        "schema_validation": True,
        "fixer_invocation_id": fixer_invocation_id,
        "episode_key": episode_key,
        "origin": "review",
        "original_escalation": original_spec,
        "validator_request": validator_request.to_dict(),
    }
    manager.update_session(
        session_id,
        {
            "pipeline_resume_context": pipeline_resume_context,
            "escalation_fixer_attempted": True,
            "escalation_fixer_episode_key": episode_key,
            "escalation_fixer_origin_reason_code": reason_code,
            "escalation_fixer_attempt_count": 1,
            "escalation_fixer_invocations": [invocation_record],
        },
    )
    manager.store_progress_event(
        session_id,
        "escalation_fixer_requested",
        {
            "fixer_invocation_id": fixer_invocation_id,
            "episode_key": episode_key,
            "reason_code": reason_code,
        },
    )
    return {
        "session_id": session_id,
        "item_id": item_id,
        "iteration": iteration,
        "reason_code": reason_code,
        "fixer_invocation_id": fixer_invocation_id,
        "episode_key": episode_key,
        "effective_issue_ids": effective_issue_ids,
    }


def _prime_pending_escalation_fixer(
    *,
    manager: Any,
    session: Any,
    session_id: str,
    pending_config: dict[str, Any],
) -> dict[str, Any]:
    """Seed a pending escalation-fixer validator dispatch into session state."""
    target_scorecard = _resolve_pending_escalation_target(
        [
            _scorecard_to_dict(scorecard)
            for scorecard in manager.get_all_quality_scorecards(session_id)
        ],
        pending_config,
    )

    # Resolve plan items so they can be included in the payload.
    plan = manager.get_latest_plan_version(session_id)
    plan_items = [item.to_dict() for item in plan.plan_items] if plan else []

    payload_result = _build_escalation_fixer_subject_payload(
        session=session,
        session_id=session_id,
        pending_config=pending_config,
        target_scorecard=target_scorecard,
    )
    # Inject plan_items resolved from Firestore into the payload structures.
    payload_result["plan_items"] = plan_items
    payload_result["original_spec"]["plan_items"] = plan_items
    payload_result["subject_payload"]["plan_items"] = plan_items

    return _apply_escalation_fixer_session_state(
        manager=manager,
        session_id=session_id,
        payload_result=payload_result,
    )
