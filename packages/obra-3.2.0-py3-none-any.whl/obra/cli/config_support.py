"""Schema, path, and exploration helpers for obra.cli.config.

Validation functions have been extracted to config_validation.py.
Display functions have been extracted to config_display.py.
"""

from __future__ import annotations

import json
import logging
import os
import re
import sys
from pathlib import Path
from typing import cast

from obra.display import console, err_console
from obra.messages import get_message

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Schema & path helpers (formerly config_schema_helpers.py)
# ---------------------------------------------------------------------------


def _config_schema() -> dict[str, object]:
    """Load the packaged default config schema."""
    try:
        from obra.config.explorer.utils import load_default_config_schema

        schema = load_default_config_schema()
        if isinstance(schema, dict):
            return schema
    except Exception:
        return {}
    return {}


def _config_schema_paths() -> set[str]:
    """Cache all schema dot-paths for fast lookup."""
    schema = _config_schema()
    if not schema:
        return set()

    from obra.config.explorer.utils import iter_schema_paths

    return {path for path, _ in iter_schema_paths(schema)}


def _config_deprecated_paths() -> set[str]:
    """Return deprecated config paths that map to new hierarchy."""
    from obra.config.loaders import CONFIG_PATH_ALIASES

    return set(CONFIG_PATH_ALIASES.keys())


def _config_normalize_path(path: str) -> tuple[str, str | None]:
    """Normalize config paths, handling both deprecated and semantic aliases.

    Deprecated aliases generate a warning.
    Semantic aliases (shortcuts) generate an informational message.
    """
    from obra.config.loaders import CONFIG_PATH_ALIASES, SEMANTIC_CONFIG_ALIASES

    # Check deprecated aliases first (these generate warnings)
    if path in CONFIG_PATH_ALIASES:
        canonical = CONFIG_PATH_ALIASES[path]
        return canonical, get_message("warning.deprecation.config_key", old=path, new=canonical)

    # Check semantic aliases (these are shortcuts, no warning)
    if path in SEMANTIC_CONFIG_ALIASES:
        canonical = SEMANTIC_CONFIG_ALIASES[path]
        # Return None for warning - semantic aliases are valid shortcuts
        return canonical, None

    return path, None


def _config_is_known_path(path: str) -> bool:
    """Check if a path exists in the schema (fallback to descriptions)."""
    normalized, _ = _config_normalize_path(path)
    schema_paths = _config_schema_paths()
    if schema_paths:
        return normalized in schema_paths

    from obra.config.explorer.descriptions import get_description

    return get_description(normalized) is not None


def _config_suggest_paths(invalid_path: str) -> str:
    """Suggest valid config paths when an invalid path is provided.

    Returns a hint string like:
    "Valid paths under 'llm': model, type, cli_command, timeout, ..."

    Also detects keywords and suggests semantic aliases when appropriate.
    """
    from obra.config.loaders import SEMANTIC_CONFIG_ALIASES

    normalized, _ = _config_normalize_path(invalid_path)
    schema_paths = _config_schema_paths()

    suggestions: list[str] = []

    # Check if the path matches a semantic alias exactly
    if invalid_path in SEMANTIC_CONFIG_ALIASES:
        canonical = SEMANTIC_CONFIG_ALIASES[invalid_path]
        suggestions.append(f"Did you mean: obra config set {canonical} <value>")
        suggestions.append(f"('{invalid_path}' is a shortcut for '{canonical}')")
        return "\n".join(suggestions)

    # Keyword detection for common use cases (UX-CONFIG-001)
    keywords_to_paths: dict[str, list[tuple[str, str]]] = {
        "security": [
            (
                "features.quality_automation.agents.security_audit.enabled",
                "Enable/disable security audits",
            ),
            ("agents.security", "Shortcut for security_audit agent"),
        ],
        "doc": [
            (
                "features.quality_automation.agents.doc_audit.enabled",
                "Enable/disable documentation audits",
            ),
            ("agents.doc_audit", "Shortcut for doc_audit agent"),
        ],
        "documentation": [
            (
                "features.quality_automation.agents.doc_audit.enabled",
                "Enable/disable documentation audits",
            ),
            ("agents.documentation", "Shortcut for doc_audit agent"),
        ],
        "review": [
            (
                "features.quality_automation.agents.code_review.enabled",
                "Enable/disable code review",
            ),
            (
                "features.quality_automation.agents.security_audit.enabled",
                "Security reviews",
            ),
            (
                "features.quality_automation.agents.doc_audit.enabled",
                "Documentation reviews",
            ),
        ],
        "agent": [
            ("features.quality_automation.agents", "All agent settings"),
            ("agent.timeout", "Implementation execution timeout"),
        ],
        "model": [
            ("llm.model", "LLM model selection (sonnet, opus, haiku)"),
        ],
        "orchestrator": [
            ("llm.model", "Orchestrator uses the same LLM as configured in llm.model"),
        ],
        "timeout": [
            ("orchestration.timeouts.agent_execution_s", "Agent execution timeout"),
            ("orchestration.timeouts.cli_runner_s", "CLI runner timeout"),
            ("orchestration.timeouts.llm_call_s", "Individual LLM call timeout"),
        ],
        "budget": [
            ("orchestration.budgets.enabled", "Enable/disable budget framework"),
            ("workflow.budgets.tokens", "Token budget settings"),
        ],
    }

    # Check for keyword matches in the invalid path
    path_lower = invalid_path.lower()
    for keyword, paths in keywords_to_paths.items():
        if keyword in path_lower:
            suggestions.append(f"Related settings for '{keyword}':")
            for path, desc in paths:
                suggestions.append(f"  \u2022 {path} - {desc}")
            suggestions.append("")  # blank line
            break

    if not schema_paths:
        return "\n".join(suggestions) if suggestions else ""

    # Extract the prefix (e.g., "llm" from "llm.orchestrator_model")
    parts = normalized.split(".")
    if not parts:
        return "\n".join(suggestions) if suggestions else ""

    # Try progressively shorter prefixes to find valid siblings
    for i in range(len(parts) - 1, 0, -1):
        prefix = ".".join(parts[:i])
        prefix_dot = f"{prefix}."

        # Find all paths that start with this prefix
        matching = sorted(p for p in schema_paths if p.startswith(prefix_dot) and p != normalized)

        if matching:
            # Extract immediate children (next segment after prefix)
            children = set()
            for p in matching:
                remainder = p[len(prefix_dot) :]
                child = remainder.split(".")[0]
                children.add(child)

            # Format the hint
            sorted_children = sorted(children)
            if len(sorted_children) > 6:
                display = ", ".join(sorted_children[:6]) + ", ..."
            else:
                display = ", ".join(sorted_children)

            suggestions.append(f"Valid paths under '{prefix}': {display}")
            break

    # If no prefix matched, show top-level keys
    if not any("Valid paths" in s for s in suggestions):
        top_level = sorted({p.split(".")[0] for p in schema_paths})
        if top_level:
            if len(top_level) > 6:
                display = ", ".join(top_level[:6]) + ", ..."
            else:
                display = ", ".join(top_level)
            suggestions.append(f"Top-level config keys: {display}")

    # Add hint about search command
    if suggestions:
        suggestions.append("")
        suggestions.append("Tip: Use 'obra config search <keyword>' to find related settings.")

    return "\n".join(suggestions)


def _config_get_schema_value(path: str) -> object | None:
    """Get a schema value by dotted path."""
    current: object = _config_schema()
    for part in path.split("."):
        if isinstance(current, dict) and part in current:
            current = current[part]
        else:
            return None
    return current


def _config_schema_has_children(path: str) -> bool:
    """Check if a schema path has children."""
    normalized, _ = _config_normalize_path(path)
    schema_paths = _config_schema_paths()
    if schema_paths:
        prefix = f"{normalized}."
        return any(other.startswith(prefix) for other in schema_paths)

    from obra.config.explorer.descriptions import get_all_paths

    prefix = f"{normalized}."
    return any(other.startswith(prefix) for other in get_all_paths())


def _config_get_nested_value(config: dict[str, object], path: str) -> object | None:
    """Get nested value from config dict by dotted path."""
    parts = path.split(".")
    current: object = config
    for part in parts:
        if isinstance(current, dict) and part in current:
            current = current[part]
        else:
            return None
    return current


def _config_set_nested_value(config: dict[str, object], path: str, value: object) -> None:
    """Set nested value in config dict by dotted path."""
    parts = path.split(".")
    current: dict[str, object] = config
    for part in parts[:-1]:
        if part not in current or not isinstance(current[part], dict):
            current[part] = {}
        current = current[part]  # type: ignore[assignment]
    current[parts[-1]] = value


def _ensure_dict_section(config: dict[str, object], key: str) -> dict[str, object]:
    """Ensure a nested config section is a dict, replacing invalid values."""
    existing = config.get(key)
    if isinstance(existing, dict):
        return existing
    new_section: dict[str, object] = {}
    config[key] = new_section
    return new_section


def _config_flatten(data: dict[str, object], prefix: str = "") -> dict[str, object]:
    """Flatten nested config dict to dotted paths."""
    flat: dict[str, object] = {}
    for key, value in data.items():
        path = f"{prefix}.{key}" if prefix else key
        if isinstance(value, dict):
            flat.update(_config_flatten(value, path))
        else:
            flat[path] = value
    return flat


def _config_apply_defaults(config_data: dict[str, object]) -> dict[str, object]:
    """Apply default values to config dict."""
    import copy

    from obra.config.explorer.descriptions import CONFIG_DEFAULTS

    schema = _config_schema()
    if schema:
        try:
            from obra.config.explorer.utils import merge_with_default_schema

            merged_with_defaults = merge_with_default_schema(cast(dict[str, object], config_data))
            return cast(dict[str, object], merged_with_defaults)
        except Exception:
            pass

    merged = copy.deepcopy(config_data)
    for path, default_value in CONFIG_DEFAULTS.items():
        if _config_get_nested_value(merged, path) is None:
            _config_set_nested_value(merged, path, default_value)
    return merged


def _config_format_human_value(value: object) -> str:
    """Format value for human-readable output."""
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "true" if value else "false"
    return str(value)


def _config_redact_value(path: str, value: object) -> object:
    """Redact sensitive values."""
    from obra.config.explorer.descriptions import is_sensitive

    if is_sensitive(path):
        return "***"
    return value


def _config_redact(data: dict[str, object]) -> dict[str, object]:
    """Redact all sensitive values in config dict."""
    redacted: dict[str, object] = {}
    for path, value in _config_flatten(data).items():
        _config_set_nested_value(redacted, path, _config_redact_value(path, value))
    return redacted


def _config_prune_deprecated_paths(config_data: dict[str, object]) -> dict[str, object]:
    """Remove deprecated top-level paths from config display."""
    pruned = dict(config_data)
    for path in _config_deprecated_paths():
        pruned.pop(path, None)
    return pruned


def _config_parse_value(raw: str) -> object:
    """Parse string value to appropriate type."""
    stripped = raw.strip()
    if len(stripped) >= 2 and stripped[0] == stripped[-1] and stripped[0] in ("'", '"'):
        return stripped[1:-1]
    lower = stripped.lower()
    if lower == "true":
        return True
    if lower == "false":
        return False
    if re.fullmatch(r"-?\d+", stripped):
        return int(stripped)
    if re.fullmatch(r"-?\d+\.\d+", stripped):
        return float(stripped)
    return stripped


def _config_infer_expected_type(path: str, current_config: dict[str, object]) -> type | None:
    """Infer expected type for a config path."""
    schema_value = _config_get_schema_value(path)
    if isinstance(schema_value, (bool, int, float, list, dict, str)):
        return type(schema_value)

    existing = _config_get_nested_value(current_config, path)
    if isinstance(existing, (bool, int, float, list, dict, str)):
        return type(existing)
    return None


def _config_path_has_children(path: str) -> bool:
    """Check if a config path has child paths."""
    return _config_schema_has_children(path)


def _resolve_project_id_for_layers() -> tuple[str | None, list[str]]:
    """Resolve a project identifier for config layers using the current working dir."""
    try:
        from obra.intent.storage import IntentStorage

        return IntentStorage().get_project_id(Path.cwd()), []
    except Exception as exc:
        return None, [f"Unable to resolve project ID for config layers: {exc}"]


def _config_load_scope(
    scope: str,
    warn_unknown_keys: bool = False,
) -> tuple[dict[str, object], bool, dict[str, object], list[str], dict[str, str]]:
    """Load config for the given scope (local, project, or server)."""
    from obra.config import CONFIG_PATH
    from obra.config.loaders import (
        get_project_layer_path,
        load_config,
        load_layered_config,
        load_project_layer,
    )

    if scope == "server":
        from obra.api import APIClient

        api_client = APIClient.from_config()
        server_config = api_client.get_user_config()
        return (
            server_config.get("resolved", {}),
            True,
            server_config.get("resolved", {}),
            [],
            {},
        )

    warnings: list[str] = []
    origins: dict[str, str] = {}

    if scope == "project":
        project_id, id_warnings = _resolve_project_id_for_layers()
        warnings.extend(id_warnings)
        if not project_id:
            return {}, False, {}, warnings, origins
        project_config, layer_warnings, config_exists = load_project_layer(project_id)
        warnings.extend(layer_warnings)
        if warn_unknown_keys:
            schema = _config_schema()
            if schema and project_config:
                unknown_keys = _config_unknown_keys(project_config, schema)
                if unknown_keys:
                    preview = ", ".join(sorted(unknown_keys)[:10])
                    suffix = "..." if len(unknown_keys) > 10 else ""
                    warnings.append(
                        "Unknown config keys in "
                        f"{get_project_layer_path(project_id)}: {preview}{suffix}. "
                        "Hint: remove or check spelling; see `obra config show --json` for valid keys."
                    )
        for path in _config_flatten(project_config):
            origins[path] = "project"
        return project_config, config_exists, project_config, warnings, origins

    config_data, origins, warnings = load_layered_config(include_defaults=True)
    raw_config = load_config()
    config_exists = CONFIG_PATH.exists()
    if warn_unknown_keys:
        schema = _config_schema()
        if schema and raw_config:
            unknown_keys = _config_unknown_keys(raw_config, schema)
            if unknown_keys:
                preview = ", ".join(sorted(unknown_keys)[:10])
                suffix = "..." if len(unknown_keys) > 10 else ""
                warnings.append(
                    "Unknown config keys in "
                    f"{CONFIG_PATH}: {preview}{suffix}. "
                    "Hint: remove or check spelling; see `obra config show --json` for valid keys."
                )
    return config_data, config_exists, raw_config, warnings, origins


def _config_print_show(
    config_data: dict[str, object],
    scope: str,
    json_output: bool,
    origins: dict[str, str] | None = None,
    verbose: bool = False,
) -> None:
    """Print config in show format."""

    redacted = _config_redact(_config_prune_deprecated_paths(config_data))
    if json_output:
        payload: dict[str, object] = {"scope": scope, "data": redacted}
        if verbose and origins is not None:
            payload["origins"] = origins
        print(json.dumps(payload, ensure_ascii=True))
        return

    for path, value in sorted(_config_flatten(redacted).items()):
        if verbose and origins is not None:
            layer = origins.get(path, "unknown")
            print(f"{path}: {_config_format_human_value(value)}  [{layer}]")
        else:
            print(f"{path}: {_config_format_human_value(value)}")


def _maybe_emit_ollama_fast_tip(config_data: dict[str, object] | None = None) -> None:
    """Emit a hint about the ollama-fast profile for local performance tuning."""
    active_profile = os.environ.get("OBRA_PROFILE", "").strip()
    config_profile = None
    if isinstance(config_data, dict):
        config_profile = config_data.get("profile_name") or config_data.get("profile")
        if config_profile is None:
            profiles_section = config_data.get("profiles")
            if isinstance(profiles_section, dict):
                config_profile = profiles_section.get("default_profile")
    if active_profile == "ollama-fast" or config_profile == "ollama-fast":
        return
    console.print(
        "[dim]Tip: Local Ollama can be slow. Try `obra --profile ollama-fast` "
        "or copy settings from config/profiles/ollama-fast.yaml for faster runs.[/dim]"
    )


def _config_emit_warnings(warnings: list[str]) -> None:
    """Emit warnings for config load or schema issues."""
    for warning in warnings:
        err_console.print(f"[yellow]Warning:[/yellow] {warning}", style="yellow")


def _config_emit_error(message: str, detail: str = "") -> None:
    """Emit config error to stderr."""
    prefix = "Error: "
    print(f"{prefix}{message}", file=sys.stderr)
    if detail:
        print(detail, file=sys.stderr)


# ---------------------------------------------------------------------------
# Provider detection helpers (extracted from config_set)
# ---------------------------------------------------------------------------

#: Model config paths that can trigger auto-provider detection.
_MODEL_PATHS = {
    "llm.model",
    "llm.orchestrator.model",
    "llm.implementation.model",
}

#: Provider config paths for provider-side-effect logic.
_PROVIDER_PATHS = {
    "llm.provider",
    "llm.orchestrator.provider",
    "llm.implementation.provider",
}


def _apply_auto_provider_detection(
    normalized_path: str,
    parsed_value: object,
    config_data: dict[str, object],
    raw_config: dict[str, object],
) -> tuple[str | None, str | None]:
    """Infer and auto-set the provider when a model path implies a different provider.

    ISSUE-SAAS-052: Ensures ``obra config set llm.model gpt-5.2-codex`` correctly
    switches the corresponding provider to openai.

    Args:
        normalized_path: The canonical config path being set.
        parsed_value: The parsed value for the path.
        config_data: The resolved (merged) config dict for reading current provider.
        raw_config: The raw config dict to mutate if auto-detection applies.

    Returns:
        A tuple of (auto_set_provider_path, inferred_provider). Both are ``None``
        when auto-detection does not apply.
    """
    if normalized_path not in _MODEL_PATHS or not isinstance(parsed_value, str):
        return None, None

    from obra.config.llm import infer_provider_from_model

    inferred_provider = infer_provider_from_model(parsed_value)
    if not inferred_provider:
        return None, None

    # Determine which provider path to check against
    if normalized_path == "llm.orchestrator.model":
        provider_path = "llm.orchestrator.provider"
    elif normalized_path == "llm.implementation.model":
        provider_path = "llm.implementation.provider"
    else:
        provider_path = "llm.provider"

    current_provider = _config_get_nested_value(config_data, provider_path)
    if current_provider != inferred_provider:
        _config_set_nested_value(raw_config, provider_path, inferred_provider)
        console.print(
            f"[cyan]Auto-detected:[/cyan] Setting {provider_path} = {inferred_provider} "
            f"(inferred from model '{parsed_value}')"
        )
        return provider_path, inferred_provider

    return None, inferred_provider


def _apply_provider_side_effects(
    normalized_path: str,
    parsed_value: object,
    auto_set_provider_path: str | None,
    inferred_provider: str | None,
    raw_config: dict[str, object],
) -> None:
    """Apply OpenAI-specific git config side effects when provider is set.

    When the provider is set to ``openai`` (directly via a provider path or
    indirectly via auto-provider detection), this sets ``llm.git.skip_check``
    to ``True`` so that Codex git-repo requirements don't block execution.

    Args:
        normalized_path: The canonical config path being set.
        parsed_value: The parsed value for the path.
        auto_set_provider_path: Provider path from auto-detection (or ``None``).
        inferred_provider: Inferred provider name (or ``None``).
        raw_config: The raw config dict to mutate.
    """
    provider_set_to_openai = (normalized_path in _PROVIDER_PATHS and parsed_value == "openai") or (
        auto_set_provider_path and inferred_provider == "openai"
    )

    if provider_set_to_openai:
        llm_section = _ensure_dict_section(raw_config, "llm")
        git_section = _ensure_dict_section(llm_section, "git")
        git_section["skip_check"] = True
