"""Intent command cluster for the Obra CLI."""

from __future__ import annotations

import logging
from pathlib import Path

import typer
from rich.table import Table

from obra.config import DEFAULT_MODEL, DEFAULT_PROVIDER, DEFAULT_REASONING_LEVEL
from obra.display import (
    console,
    glyphs,
    handle_encoding_errors,
    print_error,
    print_info,
    print_success,
    print_warning,
)
from obra.display.errors import display_error

logger = logging.getLogger(__name__)

intent_app = typer.Typer(
    name="intent",
    help="Manage intent capture for derivation workflows",
    rich_markup_mode="rich",
)


@intent_app.command("new")
@handle_encoding_errors
def intent_new(
    objective: str = typer.Argument(
        None, help="User objective (natural language). Omit if using --prd or --plan."
    ),
    prd: Path | None = typer.Option(None, "--prd", help="Path to PRD file to extract intent from"),
    plan: Path | None = typer.Option(
        None,
        "--plan",
        help="Path to plan file (structured or prose) to extract intent from",
    ),
    force_empty: bool = typer.Option(
        False, "--force-empty", help="Force EMPTY project state (new/minimal project)"
    ),
    force_existing: bool = typer.Option(
        False,
        "--force-existing",
        help="Force EXISTING project state (established codebase)",
    ),
    detect_project_state: bool = typer.Option(
        False,
        "--detect-project-state",
        help="Enable project state detection for PRD/plan inputs (skipped by default)",
    ),
) -> None:
    """Create a new intent from an objective or file.

    Generates a structured intent with problem statement, assumptions,
    requirements, acceptance criteria, and non-goals using LLM.

    The intent is saved to ~/.obra/intents/{project}/ and set as the
    active intent for the project.

    Examples:
        obra intent new "add user authentication"
        obra intent new --prd docs/AUTH_PRD.md
        obra intent new --plan docs/IMPLEMENTATION_PLAN.md
        obra intent new --plan docs/MACHINE_PLAN.json

    The intent can then be used with 'obra derive' or 'obra derive --continue'.
    """
    from obra.config.planning import get_project_planning_config
    from obra.hybrid.handlers.intent import IntentHandler
    from obra.intent import IntentStorage
    from obra.intent.detection import is_structured_plan_file
    from obra.intent.models import InputType

    try:
        working_dir = Path.cwd()
        storage = IntentStorage()
        project_id = storage.get_project_id(working_dir)

        # Validate inputs
        input_count = sum([bool(objective), bool(prd), bool(plan)])
        if input_count > 1:
            console.print()
            print_error("Cannot specify multiple input types")
            console.print("  Use one of:")
            console.print("    • obra intent new 'objective'")
            console.print("    • obra intent new --prd <file>")
            console.print("    • obra intent new --plan <file>")
            console.print()
            raise typer.Exit(1)

        if input_count == 0:
            console.print()
            print_error("Must specify an input")
            console.print("  Use one of:")
            console.print("    • obra intent new 'objective'")
            console.print("    • obra intent new --prd <file>")
            console.print("    • obra intent new --plan <file>")
            console.print()
            raise typer.Exit(1)

        # Validate force flags are mutually exclusive
        if force_empty and force_existing:
            console.print()
            print_error("Cannot specify both --force-empty and --force-existing")
            console.print()
            raise typer.Exit(1)

        # Determine input type and source
        if prd:
            if not prd.exists():
                console.print()
                print_error(f"PRD file not found: {prd}")
                console.print()
                raise typer.Exit(1)

            input_source = str(prd)
            input_type = InputType.PRD
            console.print()
            print_info(f"Extracting intent from PRD: {prd.name}")
            console.print()
        elif plan:
            if not plan.exists():
                console.print()
                print_error(f"Plan file not found: {plan}")
                console.print()
                raise typer.Exit(1)

            input_source = str(plan)
            # Auto-detect structured vs prose plan
            if is_structured_plan_file(plan):
                input_type = InputType.STRUCTURED_PLAN
                console.print()
                print_info(f"Mechanically extracting intent from structured plan: {plan.name}")
                console.print()
            else:
                input_type = InputType.PROSE_PLAN
                console.print()
                print_info(f"Extracting intent from prose plan: {plan.name}")
                console.print()
        else:
            input_source = objective
            input_type = None  # Auto-detect
            console.print()
            print_info(f"Generating intent from: {objective[:60]}...")
            console.print()

        # Get LLM config
        planning_config = get_project_planning_config(working_dir)
        llm_config = {
            "provider": planning_config.get("provider", DEFAULT_PROVIDER),
            "model": planning_config.get("model", DEFAULT_MODEL),
            "reasoning_level": planning_config.get("reasoning_level", DEFAULT_REASONING_LEVEL),
        }

        # Generate intent
        handler = IntentHandler(
            working_dir=working_dir,
            project=project_id,
            llm_config=llm_config,
        )
        intent = handler.generate(
            input_source,
            input_type=input_type,
            force_empty=force_empty,
            force_existing=force_existing,
            detect_project_state_flag=detect_project_state,
        )

        # Save intent
        file_path = storage.save(intent)

        # Write project-local pointer for LLM discoverability
        pointer_path = storage.write_project_pointer(working_dir, intent)

        console.print()
        print_success(f"Created intent: {intent.id}")
        console.print()
        console.print(f"  [cyan]Problem:[/cyan] {intent.problem_statement}")
        console.print(f"  [cyan]Requirements:[/cyan] {len(intent.requirements)} items")
        console.print(f"  [cyan]Acceptance:[/cyan] {len(intent.acceptance_criteria)} criteria")
        console.print()
        console.print(f"  [dim]Saved to: {file_path}[/dim]")
        console.print()

        # Machine-parseable output for LLM agents
        console.print("[dim]── LLM-parseable output ──[/dim]")
        console.print("INTENT_ACTIVE=true")
        console.print(f"INTENT_ID={intent.id}")
        console.print(f"INTENT_FILE={pointer_path}")
        console.print(f"INTENT_SUMMARY={intent.problem_statement[:100]}...")
        console.print()

        console.print("Next steps:")
        console.print("  • [cyan]obra derive[/cyan] - Derive plan using this intent")
        console.print("  • [cyan]obra intent show[/cyan] - View intent details")
        console.print()

    except typer.Exit:
        raise
    except Exception as e:
        console.print()
        display_error(e, console)
        logger.exception("Intent generation failed")
        raise typer.Exit(1) from e


@intent_app.command("list")
@handle_encoding_errors
def intent_list(
    here: bool = typer.Option(False, "--here", help="Show only intents for current project"),
) -> None:
    """List all intents.

    Shows PROJECT, CREATED, SLUG, and STATUS columns for all intents.
    Use --here to filter to the current project only.

    Examples:
        obra intent list
        obra intent list --here
    """
    from obra.intent import IntentStorage

    try:
        working_dir = Path.cwd()
        storage = IntentStorage()
        project_id = storage.get_project_id(working_dir) if here else None

        intents = storage.list_intents(project=project_id)

        if not intents:
            console.print()
            if here:
                print_info("No intents found for this project")
                console.print()
                console.print("Create an intent with:")
                console.print("  [cyan]obra intent new 'your objective'[/cyan]")
            else:
                print_info("No intents found")
            console.print()
            return

        # Build table
        table = Table(show_header=True, header_style="bold cyan")
        table.add_column("PROJECT", style="dim")
        table.add_column("CREATED", style="yellow")
        table.add_column("SLUG", style="green")
        table.add_column("STATUS", justify="center")

        for intent in intents:
            status = f"{glyphs.success} Active" if intent.get("is_active") else ""
            table.add_row(
                intent.get("project", ""),
                intent.get("created", ""),
                intent.get("slug", ""),
                status,
            )

        console.print()
        console.print(table)
        console.print()
        console.print(f"  Total: {len(intents)} intent(s)")
        console.print()

    except typer.Exit:
        raise
    except Exception as e:
        console.print()
        display_error(e, console)
        logger.exception("Intent list failed")
        raise typer.Exit(1) from e


@intent_app.command("show")
@handle_encoding_errors
def intent_show(
    intent_id: str | None = typer.Argument(
        None,
        help="Intent ID to show (full, timestamp, or slug). Omit to show active intent.",
    ),
    machine: bool = typer.Option(
        False,
        "--machine",
        help="Output in machine-parseable key=value format for LLM agents",
    ),
) -> None:
    """Show details of an intent.

    If no ID is provided, shows the active intent for the current project.
    Otherwise, resolves the ID (supports full ID, timestamp, or slug) and
    displays the specified intent.

    Use --machine for LLM-parseable output format.

    Examples:
        obra intent show                           # Show active intent
        obra intent show 20260110T1200-add-auth    # Full ID
        obra intent show 20260110T1200             # Timestamp only
        obra intent show add-auth                  # Slug only
        obra intent show --machine                 # Machine-parseable output
    """
    from obra.intent import IntentStorage

    try:
        working_dir = Path.cwd()
        storage = IntentStorage()
        project_id = storage.get_project_id(working_dir)

        # Load intent
        if intent_id:
            # Resolve partial ID to full ID
            resolved_id = storage.resolve_id(intent_id, project_id)
            if not resolved_id:
                if machine:
                    console.print("INTENT_ACTIVE=false")
                    console.print(f"INTENT_ERROR=Intent not found: {intent_id}")
                    console.print(
                        "INTENT_HINT=Run 'obra intent list --here' to see available intents"
                    )
                else:
                    console.print()
                    print_error(f"Intent not found: {intent_id}")
                    console.print()
                    console.print("Available intents:")
                    console.print("  [cyan]obra intent list --here[/cyan]")
                    console.print()
                raise typer.Exit(1)

            intent = storage.load(resolved_id, project_id)
            if not intent:
                if machine:
                    console.print("INTENT_ACTIVE=false")
                    console.print(f"INTENT_ERROR=Failed to load intent: {resolved_id}")
                else:
                    console.print()
                    print_error(f"Failed to load intent: {resolved_id}")
                    console.print()
                raise typer.Exit(1)
        else:
            # Load active intent
            intent = storage.load_active(project_id)
            if not intent:
                if machine:
                    console.print("INTENT_ACTIVE=false")
                    console.print(
                        "INTENT_HINT=Run 'obra intent new \"<objective>\"' to create an intent"
                    )
                else:
                    console.print()
                    print_info("No active intent for this project")
                    console.print()
                    console.print("Create an intent with:")
                    console.print("  [cyan]obra intent new 'your objective'[/cyan]")
                    console.print()
                raise typer.Exit(0)

        # Get pointer file path
        pointer_path = working_dir / ".obra" / "active_intent.yaml"
        intent_file_path = storage.root / intent.project / f"{intent.id}.md"

        if machine:
            # Machine-parseable output for LLM agents
            console.print("INTENT_ACTIVE=true")
            console.print(f"INTENT_ID={intent.id}")
            console.print(f"INTENT_PROJECT={intent.project}")
            console.print(f"INTENT_STATUS={intent.status.value}")
            console.print(f"INTENT_FILE={pointer_path}")
            console.print(f"INTENT_FULL_PATH={intent_file_path}")
            console.print(f"INTENT_SUMMARY={intent.problem_statement}")
            if intent.requirements:
                console.print(f"INTENT_REQUIREMENTS={'|'.join(intent.requirements)}")
            if intent.acceptance_criteria:
                console.print(f"INTENT_ACCEPTANCE_CRITERIA={'|'.join(intent.acceptance_criteria)}")
            if intent.assumptions:
                console.print(f"INTENT_ASSUMPTIONS={'|'.join(intent.assumptions)}")
            if intent.non_goals:
                console.print(f"INTENT_NON_GOALS={'|'.join(intent.non_goals)}")
        else:
            # Human-readable output
            console.print()
            console.print(f"[bold cyan]Intent: {intent.slug}[/bold cyan]")
            console.print(f"[dim]ID: {intent.id}[/dim]")
            console.print(f"[dim]Project: {intent.project}[/dim]")
            console.print(f"[dim]Status: {intent.status.value}[/dim]")
            console.print()

            console.print("[bold]Problem Statement:[/bold]")
            console.print(f"  {intent.problem_statement}")
            console.print()

            if intent.assumptions:
                console.print("[bold]Assumptions:[/bold]")
                for assumption in intent.assumptions:
                    console.print(f"  • {assumption}")
                console.print()

            if intent.requirements:
                console.print("[bold]Requirements:[/bold]")
                for req in intent.requirements:
                    console.print(f"  • {req}")
                console.print()

            if intent.acceptance_criteria:
                console.print("[bold]Acceptance Criteria:[/bold]")
                for criterion in intent.acceptance_criteria:
                    console.print(f"  • {criterion}")
                console.print()

            if intent.non_goals:
                console.print("[bold]Non-Goals:[/bold]")
                for non_goal in intent.non_goals:
                    console.print(f"  • {non_goal}")
                console.print()

            if intent.context_amendments:
                console.print("[bold]Context Amendments:[/bold]")
                for amendment in intent.context_amendments:
                    console.print(f"  • {amendment}")
                console.print()

            console.print("Next steps:")
            console.print("  • [cyan]obra derive[/cyan] - Derive plan using this intent")
            console.print("  • [cyan]obra context add 'info'[/cyan] - Amend the intent")
            console.print()

    except typer.Exit:
        raise
    except Exception as e:
        if machine:
            console.print("INTENT_ACTIVE=false")
            console.print(f"INTENT_ERROR={e}")
        else:
            console.print()
            display_error(e, console)
        logger.exception("Intent show failed")
        raise typer.Exit(1) from e


@intent_app.command("use")
@handle_encoding_errors
def intent_use(
    intent_id: str = typer.Argument(
        ..., help="Intent ID to set as active (full, timestamp, or slug)"
    ),
) -> None:
    """Set an intent as the active intent for the current project.

    The active intent is used by 'obra derive' (with no objective) and
    'obra context add' commands.

    Examples:
        obra intent use 20260110T1200-add-auth    # Full ID
        obra intent use 20260110T1200             # Timestamp only
        obra intent use add-auth                  # Slug only
    """
    from obra.intent import IntentStorage

    try:
        working_dir = Path.cwd()
        storage = IntentStorage()
        project_id = storage.get_project_id(working_dir)

        # Resolve partial ID to full ID
        resolved_id = storage.resolve_id(intent_id, project_id)
        if not resolved_id:
            console.print()
            print_error(f"Intent not found: {intent_id}")
            console.print()
            console.print("Available intents:")
            console.print("  [cyan]obra intent list --here[/cyan]")
            console.print()
            raise typer.Exit(1)

        # Set as active
        success = storage.set_active(resolved_id, project_id)
        if not success:
            console.print()
            print_error(f"Failed to set active intent: {resolved_id}")
            console.print()
            raise typer.Exit(1)

        # Load intent for pointer file and summary
        intent = storage.load(resolved_id, project_id)
        if intent:
            # Write project-local pointer for LLM discoverability
            pointer_path = storage.write_project_pointer(working_dir, intent)

            console.print()
            print_success(f"Active intent set: {resolved_id}")
            console.print()

            # Machine-parseable output for LLM agents
            console.print("[dim]── LLM-parseable output ──[/dim]")
            console.print("INTENT_ACTIVE=true")
            console.print(f"INTENT_ID={intent.id}")
            console.print(f"INTENT_FILE={pointer_path}")
            console.print(
                f"INTENT_SUMMARY={intent.problem_statement[:100] if intent.problem_statement else ''}..."
            )
            console.print()
        else:
            console.print()
            print_success(f"Active intent set: {resolved_id}")
            console.print()

        console.print("Next steps:")
        console.print("  • [cyan]obra derive[/cyan] - Derive plan using this intent")
        console.print("  • [cyan]obra intent show[/cyan] - View intent details")
        console.print()

    except typer.Exit:
        raise
    except Exception as e:
        console.print()
        display_error(e, console)
        logger.exception("Intent use failed")
        raise typer.Exit(1) from e


@intent_app.command("delete")
@handle_encoding_errors
def intent_delete(
    intent_id: str = typer.Argument(..., help="Intent ID to delete (full, timestamp, or slug)"),
) -> None:
    """Delete an intent from storage.

    If the intent is currently active, it will be removed from active status
    and a warning will be displayed.

    Examples:
        obra intent delete 20260110T1200-add-auth    # Full ID
        obra intent delete 20260110T1200             # Timestamp only
        obra intent delete add-auth                  # Slug only
    """
    from obra.intent import IntentStorage

    try:
        working_dir = Path.cwd()
        storage = IntentStorage()
        project_id = storage.get_project_id(working_dir)

        # Resolve partial ID to full ID
        resolved_id = storage.resolve_id(intent_id, project_id)
        if not resolved_id:
            console.print()
            print_error(f"Intent not found: {intent_id}")
            console.print()
            console.print("Available intents:")
            console.print("  [cyan]obra intent list --here[/cyan]")
            console.print()
            raise typer.Exit(1)

        # Check if this is the active intent
        active_intent = storage.load_active(project_id)
        is_active = active_intent and active_intent.id == resolved_id

        if is_active:
            console.print()
            print_warning(f"Warning: Deleting active intent: {resolved_id}")
            console.print()

        # Delete
        success = storage.delete(resolved_id, project_id)
        if not success:
            console.print()
            print_error(f"Failed to delete intent: {resolved_id}")
            console.print()
            raise typer.Exit(1)

        # Remove project pointer if this was the active intent
        if is_active:
            storage.remove_project_pointer(working_dir)

        console.print()
        print_success(f"Deleted intent: {resolved_id}")
        console.print()

        if is_active:
            console.print("Note: This was the active intent. Set a new active intent with:")
            console.print("  [cyan]obra intent use <id>[/cyan]")
            console.print()

    except typer.Exit:
        raise
    except Exception as e:
        console.print()
        display_error(e, console)
        logger.exception("Intent delete failed")
        raise typer.Exit(1) from e


@intent_app.command("export")
@handle_encoding_errors
def intent_export() -> None:
    """Export the active intent to the project docs/intents/ directory.

    Renders the active intent to markdown and saves to docs/intents/{intent-id}.md
    in the current project directory.

    Example:
        obra intent export
    """
    from obra.intent import IntentStorage

    try:
        working_dir = Path.cwd()
        storage = IntentStorage()
        project_id = storage.get_project_id(working_dir)

        # Load active intent
        intent = storage.load_active(project_id)
        if not intent:
            console.print()
            print_info("No active intent for this project")
            console.print()
            console.print("Create an intent with:")
            console.print("  [cyan]obra intent new 'your objective'[/cyan]")
            console.print()
            raise typer.Exit(0)

        # Create docs/intents/ directory
        export_dir = working_dir / "docs" / "intents"
        export_dir.mkdir(parents=True, exist_ok=True)

        # Render and write intent markdown
        from obra.intent.templates import render_intent_template

        export_file = export_dir / f"{intent.id}.md"
        export_file.write_text(render_intent_template(intent), encoding="utf-8")

        console.print()
        print_success(f"Exported intent: {intent.id}")
        console.print()
        console.print(f"  [dim]Saved to: {export_file}[/dim]")
        console.print()

    except typer.Exit:
        raise
    except Exception as e:
        console.print()
        display_error(e, console)
        logger.exception("Intent export failed")
        raise typer.Exit(1) from e
