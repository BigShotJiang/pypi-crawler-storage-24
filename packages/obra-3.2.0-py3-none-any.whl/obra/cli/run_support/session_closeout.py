"""Closeout helpers for CLI run/derive flows."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from obra.cli.feedback_shared import offer_bug_report


def handle_graceful_interrupt(
    cli: Any,
    *,
    progress_emitter: Any | None,
    orchestrator: Any,
    objective: str,
    verbose: int,
) -> None:
    """Render interrupted closeout and exit with the expected code."""
    session_id = orchestrator.session_id
    hint_session_id = cli._interrupt_manager.recovery_hint_session_id
    suppress_interrupt_hint = (
        bool(cli._interrupt_manager.recovery_hint_printed)
        and bool(hint_session_id)
        and (not session_id or str(hint_session_id) == str(session_id))
    )
    if progress_emitter:
        progress_emitter.halt_spinner()
    closeout_ctx = cli._build_interrupted_closeout_context(
        orchestrator=orchestrator,
        session_id=session_id or "",
        objective=objective,
        suppress_interrupt_hint=suppress_interrupt_hint,
    )
    cli.build_closeout_message(closeout_ctx, cli.console, verbosity=verbose)
    cli._log_closeout_rendered(orchestrator, closeout_ctx)
    raise cli.typer.Exit(130) from None


def render_session_result(
    cli: Any,
    *,
    result: Any,
    progress_emitter: Any | None,
    plan_only: bool,
    work_dir: Path,
    session_id: str | None,
    objective: str,
    auto_report: bool,
    orchestrator: Any,
    verbose: int,
) -> None:
    """Render normal session closeout and enforce CLI exit semantics."""
    if progress_emitter:
        progress_emitter.halt_spinner()

    cli.console.print()
    action = getattr(result, "action", None)
    items_completed = 0
    is_plan_only_completion = bool(plan_only)
    if action == "complete" or action is None:
        (
            items_completed,
            _total_iterations,
            _quality_score,
            was_escalated,
            _terminal_phase,
        ) = cli._extract_completion_context(result)

        cli._print_git_file_summary(cli.console, str(work_dir))

        closeout_ctx = cli._build_closeout_context(
            result,
            session_id=session_id,
            objective=objective,
        )
        session_summary = getattr(result, "session_summary", None)
        if isinstance(session_summary, str):
            is_plan_only_completion = is_plan_only_completion or session_summary.lower().startswith(
                "plan-only mode:"
            )
        cli.build_closeout_message(closeout_ctx, cli.console, verbosity=verbose)
        cli._log_closeout_rendered(orchestrator, closeout_ctx)

        if was_escalated:
            raise cli.typer.Exit(1)

        if items_completed == 0 and not is_plan_only_completion:
            offer_bug_report(
                context="orchestration",
                command_used="obra derive",
                objective=objective,
                failure_reason="0 items completed successfully",
                auto_report=auto_report,
                orchestrator=orchestrator,
            )
            raise cli.typer.Exit(1)
        return

    cli.console.print(f"Session state: {action}")
