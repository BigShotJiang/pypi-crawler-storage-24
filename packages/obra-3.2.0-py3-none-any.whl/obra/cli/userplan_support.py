"""Support helpers for UserPlan CLI commands."""

from __future__ import annotations

from typing import Any


def parse_step_identifier(step_id: str) -> int:
    """Parse either a 1-indexed step number or full UserPlan step id."""
    if step_id.isdigit():
        step_index = int(step_id)
    elif ":S" in step_id:
        try:
            step_index = int(step_id.rsplit(":S", maxsplit=1)[-1])
        except ValueError as exc:
            raise ValueError(f"Invalid step ID format: {step_id}") from exc
    else:
        raise ValueError(
            f"Invalid step identifier: {step_id}. "
            "Provide either a step index (e.g., '2') or full step ID (e.g., 'UP-xxx:S2')"
        )

    if step_index < 1:
        raise ValueError("Step index must be >= 1")
    return step_index


def build_step_context_payload(
    *,
    deliverables: str | None,
    success_criteria: str | None,
    requirements: str | None,
    tech_stack: str | None,
    constraints: str | None,
    assumptions: str | None,
) -> dict[str, Any]:
    """Build the update payload for step-context mutation."""
    context: dict[str, Any] = {}

    if deliverables is not None:
        context["deliverables"] = (
            [item.strip() for item in deliverables.split(",") if item.strip()]
            if deliverables
            else []
        )
    if success_criteria is not None:
        context["success_criteria"] = success_criteria if success_criteria else None
    if requirements is not None:
        context["requirements"] = (
            [item.strip() for item in requirements.split(",") if item.strip()]
            if requirements
            else []
        )
    if tech_stack is not None:
        context["tech_stack"] = (
            [item.strip() for item in tech_stack.split(",") if item.strip()] if tech_stack else []
        )
    if constraints is not None:
        context["constraints"] = (
            [item.strip() for item in constraints.split(",") if item.strip()] if constraints else []
        )
    if assumptions is not None:
        context["assumptions"] = (
            [item.strip() for item in assumptions.split(",") if item.strip()] if assumptions else []
        )

    return context


def build_rederive_step_range(
    *,
    total_steps: int,
    from_step: int | None,
) -> tuple[int, list[int]]:
    """Return the starting step and 1-indexed step range for re-derive."""
    start_step = from_step if from_step is not None else 1
    return start_step, list(range(start_step, total_steps + 1))
