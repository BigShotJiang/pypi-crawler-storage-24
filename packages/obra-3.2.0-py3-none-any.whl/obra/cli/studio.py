"""Workflow Studio lifecycle commands."""

from __future__ import annotations

import importlib.util
import json
import shutil
import subprocess
import webbrowser
from importlib import metadata, resources
from pathlib import Path

import typer
from packaging.markers import default_environment
from packaging.requirements import Requirement
from packaging.specifiers import SpecifierSet
from packaging.utils import canonicalize_name
from packaging.version import InvalidVersion, Version
from rich.markup import escape

from obra.cli._setup import setup
from obra.cli.auth import login
from obra.cli.studio_runtime import (
    _gateway_base_url,
    clear_studio_gateway_state,
    find_obra_gateway_listener_process,
    is_process_running,
    load_studio_gateway_state,
    mint_studio_launch_url,
    probe_gateway,
    probe_gateway_auth,
    recover_studio_gateway_state,
    resolve_or_create_gateway_state,
    save_studio_gateway_state,
    start_studio_gateway,
    stop_studio_gateway,
    stop_untracked_studio_gateway,
)
from obra.display import console, handle_encoding_errors, print_info, print_success, print_warning
from obra.utils.terminal import can_open_browser

studio_app = typer.Typer(
    help="Launch and manage the local Workflow Studio runtime.",
    invoke_without_command=True,
    no_args_is_help=False,
)

_STUDIO_GATEWAY_DEPENDENCIES = (
    {
        "distribution_name": "fastapi",
        "module_name": "fastapi",
        "display_name": "fastapi",
        "fallback_spec": ">=0.115.0",
    },
    {
        "distribution_name": "uvicorn",
        "module_name": "uvicorn",
        "display_name": "uvicorn",
        "fallback_spec": ">=0.30.0",
    },
    {
        "distribution_name": "websockets",
        "module_name": "websockets",
        "display_name": "websockets",
        "fallback_spec": ">=13.0",
    },
    {
        "distribution_name": "python-multipart",
        "module_name": "multipart",
        "display_name": "python-multipart",
        "fallback_spec": "",
    },
)
_STUDIO_DOCTOR_SCHEMA_VERSION = 1
_STUDIO_DOCTOR_EXIT_OK = 0
_STUDIO_DOCTOR_EXIT_MISSING_GATEWAY_PYTHON_EXTRA = 20
_STUDIO_DOCTOR_EXIT_MISSING_STUDIO_WEB_ASSETS = 21
_STUDIO_DOCTOR_EXIT_OTHER = 29


def _studio_gateway_install_hint() -> str:
    from obra.install_guidance import recommended_gateway_install_hint

    return recommended_gateway_install_hint()


def _voice_install_hint() -> str:
    from obra.gateway.workflow_studio.stt_provider import get_voice_install_hint

    return get_voice_install_hint()


def _voice_dependency_available() -> bool:
    from obra.gateway.workflow_studio.stt_provider import LocalWhisperProvider

    return LocalWhisperProvider().is_available()


def _render_optional_voice_hint() -> None:
    if _voice_dependency_available():
        return
    console.print(
        f"[dim]Optional: enable Studio voice dictation with {escape(_voice_install_hint())}[/dim]"
    )


def _gateway_requirement_specs() -> dict[str, str]:
    specs = {
        canonicalize_name(str(dependency["distribution_name"])): str(dependency["fallback_spec"])
        for dependency in _STUDIO_GATEWAY_DEPENDENCIES
    }
    try:
        dist = metadata.distribution("obra")
    except metadata.PackageNotFoundError:
        return specs

    environment = default_environment()
    environment["extra"] = "gateway"
    for raw_requirement in dist.requires or []:
        try:
            requirement = Requirement(raw_requirement)
        except Exception:
            continue
        if requirement.marker and not requirement.marker.evaluate(environment):
            continue
        normalized_name = canonicalize_name(requirement.name)
        if normalized_name not in specs:
            continue
        if str(requirement.specifier).strip():
            specs[normalized_name] = str(requirement.specifier)
    return specs


def _collect_gateway_dependency_issues() -> list[str]:
    issues: list[str] = []
    requirement_specs = _gateway_requirement_specs()

    for dependency in _STUDIO_GATEWAY_DEPENDENCIES:
        distribution_name = str(dependency["distribution_name"])
        module_name = str(dependency["module_name"])
        display_name = str(dependency["display_name"])
        normalized_name = canonicalize_name(distribution_name)
        spec_text = requirement_specs.get(
            normalized_name,
            str(dependency["fallback_spec"]),
        )
        if importlib.util.find_spec(module_name) is None:
            issues.append(f"{display_name}{spec_text} (missing)")
            continue

        try:
            installed_version = metadata.version(distribution_name)
        except metadata.PackageNotFoundError:
            issues.append(f"{display_name}{spec_text} (missing package metadata)")
            continue

        if not spec_text:
            continue

        try:
            if Version(installed_version) not in SpecifierSet(spec_text):
                issues.append(f"{display_name}{spec_text} (found {installed_version})")
        except InvalidVersion:
            issues.append(
                f"{display_name}{spec_text} (found unparseable version {installed_version})"
            )

    return issues


def _studio_web_assets_ready() -> bool:
    try:
        dist_root = resources.files("obra.studio_web").joinpath("dist")
        return dist_root.joinpath("index.html").is_file()
    except ModuleNotFoundError:
        return False
    except Exception:
        return False


def _find_dev_client_root() -> Path | None:
    """Return the Studio web client source root if running from a dev checkout."""
    try:
        studio_web_pkg = resources.files("obra.studio_web")
        # In an editable install, this resolves to the repo's obra/studio_web/
        pkg_path = Path(str(studio_web_pkg))
        # Climb to repo root: obra/studio_web/ -> obra/ -> repo root
        repo_root = pkg_path.parent.parent
        client_root = repo_root / "clients" / "workflow-studio-web"
        if (client_root / "package.json").is_file() and (client_root / "src").is_dir():
            return client_root
    except Exception:
        pass
    return None


def _dev_studio_assets_stale(client_root: Path) -> bool:
    """Check whether the packaged Studio dist is older than the web client source."""
    try:
        dist_root = resources.files("obra.studio_web").joinpath("dist")
        dist_index = Path(str(dist_root.joinpath("index.html")))
        if not dist_index.is_file():
            return True
        dist_mtime = dist_index.stat().st_mtime

        src_dir = client_root / "src"
        newest_src = 0.0
        for f in src_dir.rglob("*"):
            if f.is_file() and f.suffix in (".ts", ".tsx", ".css", ".html", ".json"):
                newest_src = max(newest_src, f.stat().st_mtime)

        return newest_src > dist_mtime
    except Exception:
        return False


def _dev_rebuild_studio_assets(client_root: Path) -> bool:
    """Build the Studio web client and sync into the packaged dist directory.

    Only invoked from a dev checkout when source files are newer than the
    packaged dist.  This path is unreachable from a wheel install because
    the ``clients/`` directory does not exist.
    """
    npm = shutil.which("npm")
    if npm is None:
        print_warning("npm is not installed — cannot auto-rebuild Studio web assets.")
        print_info("Run manually: cd clients/workflow-studio-web && npm run build")
        return False

    print_info("Studio web source has changed — rebuilding assets...")
    try:
        # MONITORING EXEMPTION: Dev-only npm asset rebuild from editable checkout; unreachable from wheel installs and outside orchestrator subprocess monitoring.
        result = subprocess.run(
            [npm, "run", "build"],
            cwd=str(client_root),
            capture_output=True,
            text=True,
            timeout=120,
        )
    except subprocess.TimeoutExpired:
        print_warning("Studio web build timed out after 120 s.")
        return False
    except OSError as exc:
        print_warning(f"Studio web build failed: {exc}")
        return False

    if result.returncode != 0:
        print_warning("Studio web build failed.")
        if result.stderr:
            for line in result.stderr.strip().splitlines()[-5:]:
                console.print(f"  {escape(line)}")
        return False

    # Sync built output into the package dist directory
    built_dist = client_root / "dist"
    if not (built_dist / "index.html").is_file():
        print_warning("Build succeeded but dist/index.html is missing.")
        return False

    try:
        studio_web_pkg = resources.files("obra.studio_web")
        target_dist = Path(str(studio_web_pkg)) / "dist"
        if target_dist.is_dir():
            shutil.rmtree(target_dist)
        shutil.copytree(str(built_dist), str(target_dist))
    except Exception as exc:
        print_warning(f"Failed to sync built assets: {exc}")
        return False

    print_success("Studio web assets rebuilt and synced.")
    return True


def _collect_studio_preflight(
    *,
    no_browser: bool,
    host: str | None = None,
    port: int | None = None,
) -> dict[str, object]:
    checks: list[dict[str, object]] = []
    healthy = True

    dependency_issues = _collect_gateway_dependency_issues()
    if dependency_issues:
        healthy = False
        checks.append(
            {
                "name": "gateway_python_extra",
                "status": "fail",
                "ok": False,
                "issue_code": "missing_gateway_python_extra",
                "detail": (
                    "Gateway runtime dependencies are missing or below the supported minimum: "
                    + ", ".join(dependency_issues)
                ),
                "remediation": _studio_gateway_install_hint(),
                "auto_fixable": False,
            }
        )
    else:
        checks.append(
            {
                "name": "gateway_python_extra",
                "status": "pass",
                "ok": True,
                "issue_code": None,
                "detail": "Gateway runtime dependencies are installed.",
                "remediation": "",
                "auto_fixable": False,
            }
        )

    assets_ready = _studio_web_assets_ready()
    if not assets_ready:
        healthy = False
        checks.append(
            {
                "name": "studio_web_assets",
                "status": "fail",
                "ok": False,
                "issue_code": "missing_studio_web_assets",
                "detail": "Packaged Workflow Studio assets are missing from this installation.",
                "remediation": "Reinstall Obra so the bundled `obra.studio_web` assets are present.",
                "auto_fixable": False,
            }
        )
    else:
        dev_client_root = _find_dev_client_root()
        if dev_client_root is not None and _dev_studio_assets_stale(dev_client_root):
            checks.append(
                {
                    "name": "studio_web_assets",
                    "status": "warn",
                    "ok": True,
                    "issue_code": "stale_studio_web_assets",
                    "detail": "Packaged Studio assets are stale — source files are newer than the build.",
                    "remediation": "`obra studio` will auto-rebuild, or run: cd clients/workflow-studio-web && npm run build",
                    "auto_fixable": True,
                }
            )
        else:
            checks.append(
                {
                    "name": "studio_web_assets",
                    "status": "pass",
                    "ok": True,
                    "issue_code": None,
                    "detail": "Packaged Workflow Studio assets are available.",
                    "remediation": "",
                    "auto_fixable": False,
                }
            )

    if no_browser:
        checks.append(
            {
                "name": "browser_launch",
                "status": "pass",
                "ok": True,
                "issue_code": None,
                "detail": "Browser launch check skipped because `--no-browser` was requested.",
                "remediation": "",
                "auto_fixable": False,
            }
        )
    elif can_open_browser():
        checks.append(
            {
                "name": "browser_launch",
                "status": "pass",
                "ok": True,
                "issue_code": None,
                "detail": "A browser launcher is available in this environment.",
                "remediation": "",
                "auto_fixable": False,
            }
        )
    else:
        checks.append(
            {
                "name": "browser_launch",
                "status": "warn",
                "ok": True,
                "issue_code": "browser_launch_unavailable",
                "detail": "No browser launcher was detected in this environment.",
                "remediation": "Run `obra studio --no-browser` and open the printed URL manually.",
                "auto_fixable": False,
            }
        )

    status_payload = _resolve_status_payload(host, port)
    if status_payload["status"] == "stale_state":
        checks.append(
            {
                "name": "launcher_state",
                "status": "warn",
                "ok": True,
                "issue_code": "stale_launcher_state",
                "detail": (
                    f"Tracked Studio launcher state is stale for {status_payload['base_url']}."
                ),
                "remediation": "Run `obra studio doctor --fix` to clear stale launcher state.",
                "auto_fixable": True,
            }
        )
    else:
        checks.append(
            {
                "name": "launcher_state",
                "status": "pass",
                "ok": True,
                "issue_code": None,
                "detail": (
                    "No stale tracked Studio launcher state was found."
                    if not status_payload["tracked_state_present"]
                    else f"Tracked Studio launcher state is {status_payload['status']}."
                ),
                "remediation": "",
                "auto_fixable": False,
            }
        )

    return {
        "healthy": healthy,
        "checks": checks,
        "status": status_payload,
    }


def _studio_doctor_failure_codes(payload: dict[str, object]) -> list[str]:
    codes: list[str] = []
    for check in payload.get("checks", []):
        if not isinstance(check, dict) or str(check.get("status")) != "fail":
            continue
        issue_code = str(check.get("issue_code") or "").strip()
        if not issue_code:
            check_name = str(check.get("name") or "").strip()
            if check_name == "gateway_python_extra":
                issue_code = "missing_gateway_python_extra"
            elif check_name == "studio_web_assets":
                issue_code = "missing_studio_web_assets"
        if issue_code:
            codes.append(issue_code)
    return codes


def _studio_doctor_warning_codes(payload: dict[str, object]) -> list[str]:
    codes: list[str] = []
    for check in payload.get("checks", []):
        if not isinstance(check, dict) or str(check.get("status")) != "warn":
            continue
        issue_code = str(check.get("issue_code") or "").strip()
        if not issue_code:
            check_name = str(check.get("name") or "").strip()
            if check_name == "browser_launch":
                issue_code = "browser_launch_unavailable"
            elif check_name == "launcher_state":
                issue_code = "stale_launcher_state"
            elif check_name == "studio_web_assets":
                issue_code = "stale_studio_web_assets"
        if issue_code:
            codes.append(issue_code)
    return codes


def _studio_doctor_exit_code(payload: dict[str, object]) -> int:
    failure_codes = _studio_doctor_failure_codes(payload)
    if not failure_codes:
        return _STUDIO_DOCTOR_EXIT_OK
    primary_code = failure_codes[0]
    if primary_code == "missing_gateway_python_extra":
        return _STUDIO_DOCTOR_EXIT_MISSING_GATEWAY_PYTHON_EXTRA
    if primary_code == "missing_studio_web_assets":
        return _STUDIO_DOCTOR_EXIT_MISSING_STUDIO_WEB_ASSETS
    return _STUDIO_DOCTOR_EXIT_OTHER


def _build_studio_doctor_payload(
    payload: dict[str, object],
    *,
    applied_fixes: list[str] | None = None,
) -> dict[str, object]:
    failure_codes = _studio_doctor_failure_codes(payload)
    warning_codes = _studio_doctor_warning_codes(payload)
    exit_code = _studio_doctor_exit_code(payload)
    doctor_payload = dict(payload)
    doctor_payload["schema_version"] = _STUDIO_DOCTOR_SCHEMA_VERSION
    doctor_payload["command"] = "obra studio doctor"
    doctor_payload["failure_codes"] = failure_codes
    doctor_payload["warning_codes"] = warning_codes
    doctor_payload["primary_code"] = failure_codes[0] if failure_codes else "ok"
    doctor_payload["exit_code"] = exit_code
    doctor_payload["applied_fixes"] = list(applied_fixes or [])
    return doctor_payload


def _apply_studio_preflight_fixes(payload: dict[str, object]) -> list[str]:
    applied: list[str] = []
    status_payload = payload.get("status")
    if isinstance(status_payload, dict) and status_payload.get("status") == "stale_state":
        clear_studio_gateway_state()
        applied.append("Cleared stale Studio launcher state.")
    return applied


def _render_studio_preflight(payload: dict[str, object]) -> None:
    if bool(payload["healthy"]):
        print_success("Workflow Studio preflight passed")
    else:
        print_warning("Workflow Studio is not ready")

    for check in payload["checks"]:
        if not isinstance(check, dict):
            continue
        label = str(check.get("status") or "pass").upper()
        console.print(
            f"[{label}] {escape(str(check.get('name')))}: {escape(str(check.get('detail')))}"
        )
        remediation = str(check.get("remediation") or "").strip()
        if remediation:
            console.print(f"       Fix: {escape(remediation)}")
    _render_optional_voice_hint()


def _raise_for_failed_studio_preflight(payload: dict[str, object]) -> None:
    if bool(payload["healthy"]):
        return
    failed_checks = [
        check
        for check in payload["checks"]
        if isinstance(check, dict) and str(check.get("status")) == "fail"
    ]
    print_warning("Workflow Studio is not ready.")
    if failed_checks:
        console.print("Missing or incompatible:")
        for check in failed_checks:
            console.print(f"  - {escape(str(check.get('detail')))}")
    console.print("Run: obra studio doctor")
    first_failure = failed_checks[0] if failed_checks else None
    if isinstance(first_failure, dict):
        remediation = str(first_failure.get("remediation") or "").strip()
        if remediation:
            console.print(f"Suggested fix: {escape(remediation)}")
    console.print()
    console.print("Detailed checks:")
    _render_studio_preflight(payload)
    console.print()
    raise typer.Exit(_studio_doctor_exit_code(payload))


def _ensure_setup_and_auth(*, timeout: int, no_browser: bool) -> None:
    from obra.auth import get_current_auth
    from obra.config import is_terms_accepted, needs_reacceptance

    if not is_terms_accepted() or needs_reacceptance():
        print_info("Running `obra setup` before Studio launch.")
        setup(timeout=timeout, no_browser=no_browser)
        return

    if get_current_auth() is None:
        print_info("Running `obra login` before Studio launch.")
        login(timeout=timeout, no_browser=no_browser)


def _launch_studio(
    *,
    no_browser: bool,
    host: str | None,
    port: int | None,
    route: str,
    timeout: int,
) -> None:
    from obra.config.loaders import get_gateway_config

    preflight = _collect_studio_preflight(no_browser=no_browser, host=host, port=port)
    _raise_for_failed_studio_preflight(preflight)

    # Dev-only: auto-rebuild stale Studio web assets when running from a
    # checkout that has clients/workflow-studio-web/src/.  This path is
    # unreachable from a wheel install.
    dev_client_root = _find_dev_client_root()
    if dev_client_root is not None and _dev_studio_assets_stale(dev_client_root):
        _dev_rebuild_studio_assets(dev_client_root)

    _ensure_setup_and_auth(timeout=timeout, no_browser=no_browser)

    gateway_config = get_gateway_config()
    launch_host = host or str(gateway_config["host"])
    launch_port = port or int(gateway_config["port"])
    configured_token = str(gateway_config.get("auth_token") or "").strip() or None

    state = resolve_or_create_gateway_state(
        host=launch_host,
        port=launch_port,
        configured_token=configured_token,
    )
    if state is None:
        print_info(
            f"Starting local Studio gateway on {_gateway_base_url(launch_host, launch_port)}"
        )
        state = start_studio_gateway(
            host=launch_host,
            port=launch_port,
            token=configured_token,
        )
    else:
        save_studio_gateway_state(state)

    launch_url = mint_studio_launch_url(
        base_url=_gateway_base_url(state.host, state.port),
        token=state.token,
        next_path=route,
    )

    if no_browser:
        print_success("Studio is ready.")
        print_info(launch_url)
        _render_optional_voice_hint()
        return

    if can_open_browser():
        if not webbrowser.open(launch_url):
            print_warning(
                "Automatic browser launch was declined by the platform. Open this URL manually:"
            )
            print_info(launch_url)
            _render_optional_voice_hint()
            return
        print_success(f"Opened Studio at {launch_url}")
        _render_optional_voice_hint()
        return

    print_warning(
        "No browser launch capability detected in this environment. Open this URL manually:"
    )
    print_info(launch_url)
    _render_optional_voice_hint()


def _resolve_status_payload(host: str | None, port: int | None) -> dict[str, object]:
    from obra.config.loaders import get_gateway_config

    gateway_config = get_gateway_config()
    state = load_studio_gateway_state()
    resolved_host = host or (state.host if state is not None else str(gateway_config["host"]))
    resolved_port = port or (state.port if state is not None else int(gateway_config["port"]))
    base_url = _gateway_base_url(resolved_host, resolved_port)
    healthy = probe_gateway(base_url)
    listener_process = (
        find_obra_gateway_listener_process(resolved_host, resolved_port) if healthy else None
    )
    listener_pid = listener_process.pid if listener_process is not None else None
    state_matches_target = (
        state is not None and state.host == resolved_host and state.port == resolved_port
    )
    tracked_pid = state.pid if state_matches_target and state is not None else None
    tracked_pid_running = bool(
        tracked_pid is not None
        and state is not None
        and is_process_running(
            tracked_pid,
            expected_create_time=state.process_create_time,
        )
    )
    status = "stopped"
    ownership = "none"
    if state_matches_target and state is not None:
        if tracked_pid_running:
            status = "running"
            ownership = "launcher_owned"
        elif healthy and probe_gateway_auth(base_url, state.token):
            recovered = recover_studio_gateway_state(state)
            if recovered is not None:
                save_studio_gateway_state(recovered)
                tracked_pid = recovered.pid
                tracked_pid_running = bool(
                    tracked_pid is not None
                    and is_process_running(
                        tracked_pid,
                        expected_create_time=recovered.process_create_time,
                    )
                )
                status = "running"
                ownership = "launcher_owned" if tracked_pid_running else "recovered_unowned"
                state = recovered
        elif state.pid is None and healthy:
            status = "running"
            ownership = "reused_unowned"
        elif not healthy:
            status = "stale_state"
            ownership = "none"
    elif healthy:
        status = "running"
        ownership = "untracked_obra_gateway" if listener_process is not None else "untracked"

    return {
        "status": status,
        "ownership": ownership,
        "base_url": base_url,
        "host": resolved_host,
        "port": resolved_port,
        "healthy": healthy,
        "tracked_state_present": state is not None,
        "tracked_state_matches_target": state_matches_target,
        "tracked_pid": tracked_pid,
        "tracked_pid_running": tracked_pid_running,
        "tracked_started_at": state.started_at
        if state_matches_target and state is not None
        else None,
        "tracked_state_target": (
            _gateway_base_url(state.host, state.port) if state is not None else None
        ),
        "listener_pid": listener_pid,
        "listener_identified_as_obra_gateway": listener_process is not None,
    }


def _render_studio_status(payload: dict[str, object]) -> None:
    status = str(payload["status"])
    ownership = str(payload["ownership"])
    base_url = str(payload["base_url"])

    if status == "running":
        print_success(f"Studio gateway is running at {base_url}")
    elif status == "stale_state":
        print_warning(f"Studio gateway state is stale for {base_url}")
    else:
        print_info(f"Studio gateway is not running at {base_url}")

    console.print(f"Status: {status}")
    console.print(f"Ownership: {ownership}")
    console.print(f"Health probe: {'healthy' if bool(payload['healthy']) else 'unreachable'}")

    tracked_target = payload.get("tracked_state_target")
    if tracked_target is not None:
        console.print(f"Tracked state target: {tracked_target}")
    tracked_pid = payload.get("tracked_pid")
    if tracked_pid is not None:
        console.print(
            f"Tracked pid: {tracked_pid} "
            f"({'alive' if bool(payload['tracked_pid_running']) else 'not running'})"
        )
    tracked_started_at = payload.get("tracked_started_at")
    if tracked_started_at is not None:
        console.print(f"Tracked started at: {tracked_started_at}")


def _stop_studio_gateway_for_target(host: str | None, port: int | None) -> dict[str, object]:
    payload = _resolve_status_payload(host, port)
    state = load_studio_gateway_state()
    target_host = str(payload["host"])
    target_port = int(payload["port"])

    def _stop_identified_untracked_listener() -> dict[str, object] | None:
        if not bool(payload.get("listener_identified_as_obra_gateway")):
            return None
        result = stop_untracked_studio_gateway(host=target_host, port=target_port)
        if bool(result.get("stopped")) and state is not None:
            if state.host == target_host and state.port == target_port:
                clear_studio_gateway_state()
        return {**payload, **result}

    if state is None:
        stopped_untracked = _stop_identified_untracked_listener()
        if stopped_untracked is not None:
            return stopped_untracked
        return {"stopped": False, "reason": "not_tracked", **payload}

    if state.host != target_host or state.port != target_port:
        stopped_untracked = _stop_identified_untracked_listener()
        if stopped_untracked is not None:
            return stopped_untracked
        return {"stopped": False, "reason": "target_not_tracked", **payload}

    result = stop_studio_gateway(state=state)
    if not bool(result.get("stopped")) and str(result.get("reason")) == "unowned_gateway":
        stopped_untracked = _stop_identified_untracked_listener()
        if stopped_untracked is not None:
            return stopped_untracked
    return {**payload, **result}


@studio_app.callback()
@handle_encoding_errors
def studio(
    ctx: typer.Context,
    no_browser: bool = typer.Option(
        False,
        "--no-browser",
        help="Don't open the browser automatically; print the Studio URL instead.",
    ),
    host: str | None = typer.Option(
        None,
        "--host",
        help="Gateway host to launch or inspect (default: tracked target or gateway config).",
    ),
    port: int | None = typer.Option(
        None,
        "--port",
        help="Gateway port to launch or inspect (default: tracked target or gateway config).",
    ),
    route: str = typer.Option(
        "/studio/",
        "--route",
        help="Studio route to enter after bootstrap (must stay under /studio/*).",
    ),
    timeout: int = typer.Option(
        300,
        "--timeout",
        help="Timeout in seconds for hosted auth/setup preflight.",
    ),
) -> None:
    """Launch or reuse the local Workflow Studio control plane and open Studio."""
    if ctx.invoked_subcommand is not None:
        return
    _launch_studio(
        no_browser=no_browser,
        host=host,
        port=port,
        route=route,
        timeout=timeout,
    )


@studio_app.command("start")
@handle_encoding_errors
def studio_start(
    no_browser: bool = typer.Option(
        False,
        "--no-browser",
        help="Don't open the browser automatically; print the Studio URL instead.",
    ),
    host: str | None = typer.Option(
        None,
        "--host",
        help="Gateway host to launch or reuse (default: from gateway config).",
    ),
    port: int | None = typer.Option(
        None,
        "--port",
        help="Gateway port to launch or reuse (default: from gateway config).",
    ),
    route: str = typer.Option(
        "/studio/",
        "--route",
        help="Studio route to enter after bootstrap (must stay under /studio/*).",
    ),
    timeout: int = typer.Option(
        300,
        "--timeout",
        help="Timeout in seconds for hosted auth/setup preflight.",
    ),
) -> None:
    """Launch or reuse Workflow Studio explicitly."""
    _launch_studio(
        no_browser=no_browser,
        host=host,
        port=port,
        route=route,
        timeout=timeout,
    )


@studio_app.command("status")
@handle_encoding_errors
def studio_status(
    host: str | None = typer.Option(
        None,
        "--host",
        help="Gateway host to inspect (default: tracked target or gateway config).",
    ),
    port: int | None = typer.Option(
        None,
        "--port",
        help="Gateway port to inspect (default: tracked target or gateway config).",
    ),
    json_output: bool = typer.Option(False, "--json", help="Print JSON output"),
) -> None:
    """Show whether the local Workflow Studio gateway is running."""
    payload = _resolve_status_payload(host, port)
    if payload["status"] == "stale_state":
        clear_studio_gateway_state()
        payload["tracked_state_present"] = False
        payload["tracked_state_matches_target"] = False
    if json_output:
        console.print_json(json.dumps(payload))
        if payload["status"] != "running":
            raise typer.Exit(1)
        return
    _render_studio_status(payload)
    if payload["status"] != "running":
        raise typer.Exit(1)


@studio_app.command("doctor")
@handle_encoding_errors
def studio_doctor(
    no_browser: bool = typer.Option(
        False,
        "--no-browser",
        help="Skip browser-launch checks and validate Studio for manual URL launch.",
    ),
    host: str | None = typer.Option(
        None,
        "--host",
        help="Gateway host to inspect for tracked launcher-state diagnostics.",
    ),
    port: int | None = typer.Option(
        None,
        "--port",
        help="Gateway port to inspect for tracked launcher-state diagnostics.",
    ),
    fix: bool = typer.Option(
        False,
        "--fix",
        help="Apply safe local fixes such as clearing stale tracked Studio launcher state.",
    ),
    json_output: bool = typer.Option(False, "--json", help="Print JSON output"),
) -> None:
    """Run Workflow Studio dependency and launcher-state diagnostics."""
    payload = _collect_studio_preflight(no_browser=no_browser, host=host, port=port)
    applied_fixes: list[str] = []
    if fix:
        applied_fixes = _apply_studio_preflight_fixes(payload)
        payload = _collect_studio_preflight(no_browser=no_browser, host=host, port=port)
    doctor_payload = _build_studio_doctor_payload(payload, applied_fixes=applied_fixes)

    if json_output:
        console.print_json(json.dumps(doctor_payload))
        if doctor_payload["exit_code"] != _STUDIO_DOCTOR_EXIT_OK:
            raise typer.Exit(int(doctor_payload["exit_code"]))
        return

    _render_studio_preflight(doctor_payload)
    if applied_fixes:
        console.print()
        for entry in applied_fixes:
            print_success(entry)
    if doctor_payload["exit_code"] != _STUDIO_DOCTOR_EXIT_OK:
        raise typer.Exit(int(doctor_payload["exit_code"]))


@studio_app.command("stop")
@handle_encoding_errors
def studio_stop(
    host: str | None = typer.Option(
        None,
        "--host",
        help="Gateway host to stop (default: tracked target or gateway config).",
    ),
    port: int | None = typer.Option(
        None,
        "--port",
        help="Gateway port to stop (default: tracked target or gateway config).",
    ),
    json_output: bool = typer.Option(False, "--json", help="Print JSON output"),
) -> None:
    """Stop the launcher-owned Workflow Studio gateway safely."""
    payload = _stop_studio_gateway_for_target(host, port)
    reason = str(payload["reason"])

    if json_output:
        console.print_json(json.dumps(payload))
        if not bool(payload["stopped"]):
            raise typer.Exit(1)
        return

    if bool(payload["stopped"]):
        print_success(
            f"Stopped Studio gateway at {_gateway_base_url(str(payload['host']), int(payload['port']))}"
        )
        return

    if reason == "unowned_gateway":
        print_warning(
            "A gateway is responding, but it is not launcher-owned. "
            "`obra studio stop` only stops launcher-owned Studio gateways."
        )
    elif reason == "target_not_tracked":
        print_warning(
            "The requested gateway target does not match the tracked Studio launcher state. "
            "Use `obra studio status` to inspect the active target first."
        )
    elif reason == "stale_state_cleared":
        print_info(
            "Cleared stale Studio launcher state; no running launcher-owned gateway remained."
        )
    else:
        print_info("No launcher-owned Studio gateway is currently tracked.")

    raise typer.Exit(1)
