"""Briefing command cluster for Obra CLI."""

from __future__ import annotations

import logging
from collections.abc import Callable
from datetime import UTC
from pathlib import Path

import typer
from rich.console import Console

from obra import __version__
from obra.cli.briefing_display import (
    _display_blueprint as _display_blueprint_impl,
)
from obra.cli.briefing_display import (
    _display_default_briefing as _display_default_briefing_impl,
)
from obra.cli.briefing_display import (
    _display_examples as _display_examples_impl,
)
from obra.display import (
    console,
    err_console,
    handle_encoding_errors,
    print_error,
)
from obra.display.errors import display_error
from obra.messages.warnings import build_deprecation_warning

logger = logging.getLogger(__name__)

briefing_app = typer.Typer(
    name="briefing",
    help="★ Operating guide, blueprint, and protocol for AI assistants",
    invoke_without_command=True,
    rich_markup_mode="rich",
)


def _load_onboarding_content() -> tuple[str, str]:
    """Load LLM_ONBOARDING.md content and file path.

    Returns:
        Tuple of (content, file_path)

    Raises:
        typer.Exit: If file cannot be located
    """
    import importlib.resources as pkg_resources
    from pathlib import Path

    try:
        # Python 3.9+ approach
        if hasattr(pkg_resources, "files"):
            obra_package = pkg_resources.files("obra")
            onboarding_file = obra_package / ".obra" / "LLM_ONBOARDING.md"
            file_path = str(onboarding_file)

            # Read the file content
            if hasattr(onboarding_file, "read_text"):
                content = onboarding_file.read_text(encoding="utf-8")
            else:
                # Fallback for older Python versions
                with Path(file_path).open(encoding="utf-8") as f:
                    content = f.read()
        else:
            # Fallback for Python < 3.9
            import pkg_resources as old_pkg

            file_path = old_pkg.resource_filename("obra", ".obra/LLM_ONBOARDING.md")
            with Path(file_path).open(encoding="utf-8") as f:
                content = f.read()
        return content, file_path
    except typer.Exit:
        raise
    except Exception as e:
        # Development mode fallback - look in source tree
        dev_path = Path(__file__).parent / ".obra" / "LLM_ONBOARDING.md"
        if dev_path.exists():
            file_path = str(dev_path)
            content = dev_path.read_text(encoding="utf-8")
            return content, file_path
        print_error(f"Could not locate LLM_ONBOARDING.md: {e}")
        raise typer.Exit(1) from e


def _track_briefing_usage(command: str) -> None:
    """Track briefing command usage for analytics (Phase 2 telemetry).

    Records which briefing subcommand was invoked to validate 80/20 assumptions:
    - >80% should use 'quick' (the recommended option)
    - <10% should use 'full' (validates full guide is rarely needed)

    Data is stored locally in ~/.obra/usage/briefing.jsonl (JSON Lines format).
    Only tracks if advanced.telemetry.enabled is true in config.

    Args:
        command: The briefing subcommand name (quick, full, blueprint, etc.)
    """
    try:
        import json
        from datetime import datetime

        from obra.config import load_config

        # Check if telemetry is enabled
        config = load_config()
        telemetry_enabled = config.get("advanced", {}).get("telemetry", {}).get("enabled", False)
        if not telemetry_enabled:
            return

        # Create usage directory if needed
        usage_dir = Path.home() / ".obra" / "usage"
        usage_dir.mkdir(parents=True, exist_ok=True)

        # Append event to JSON Lines file (one JSON object per line)
        usage_file = usage_dir / "briefing.jsonl"
        event = {
            "timestamp": datetime.now(UTC).isoformat(),
            "command": command,
            "version": __version__,
        }

        with usage_file.open("a", encoding="utf-8") as f:
            f.write(json.dumps(event) + "\n")

    except Exception:
        # Telemetry should never break the command - silently ignore errors
        pass


def _briefing_command(name: str, fn: Callable[[Console], None], target_console: Console) -> None:
    """Execute a briefing subcommand with shared error handling.

    Wraps the try/except scaffold common to all briefing subcommands:
    track usage, run the display function, catch non-Exit exceptions.

    Args:
        name: Briefing subcommand name for telemetry (e.g. ``"quick"``).
        fn: Display callable that accepts a ``Console`` and renders output.
        target_console: Rich console instance for output.
    """
    try:
        _track_briefing_usage(name)
        fn(target_console)
    except typer.Exit:
        raise
    except Exception as e:
        display_error(e, target_console)
        logger.exception(f"Unexpected error in briefing {name}: {e}")
        raise typer.Exit(1) from e


def _display_markdown_section(
    content: str, heading: str, display_title: str, target_console: Console
) -> None:
    """Extract and display a markdown section by heading.

    Parses *content* line-by-line, collecting everything between the ``##``
    *heading* and the next ``##`` heading (excluding ``###`` sub-headings
    which are included).

    Args:
        content: Full markdown text (e.g. LLM_ONBOARDING.md).
        heading: The ``## <heading>`` to search for.  For headings with
            multiple possible names, separate alternatives with ``|``
            (e.g. ``"Question Patterns|The Questions to Ask"``).
        display_title: Rich-markup title shown above the extracted section.
        target_console: Rich console instance for output.
    """
    heading_alternatives = [h.strip() for h in heading.split("|")]
    lines = content.split("\n")
    in_section = False
    section_lines: list[str] = []

    for line in lines:
        if not in_section:
            stripped = line.strip()
            for alt in heading_alternatives:
                if stripped == f"## {alt}" or f"## {alt}" in line:
                    in_section = True
                    break
            continue

        # Stop at the next ## heading (but not ### sub-headings)
        if line.startswith("## ") and not line.startswith("### "):
            break
        section_lines.append(line)

    target_console.print()
    target_console.print(f"[bold cyan]{display_title}[/bold cyan]")
    target_console.print()
    target_console.print("\n".join(section_lines))
    target_console.print()


def _display_default_briefing() -> None:
    """Display the default briefing output (process-first with conversation example)."""
    _display_default_briefing_impl(console)


def _display_blueprint() -> None:
    """Display the condensed blueprint checklist format."""
    _display_blueprint_impl(console)


@briefing_app.callback(invoke_without_command=True)
@handle_encoding_errors
def briefing_callback(
    ctx: typer.Context,
    # Hidden aliases for deprecated flags (S2.T3 - backwards compatibility)
    blueprint: bool = typer.Option(
        False,
        "--blueprint",
        hidden=True,
        help="[DEPRECATED] Use 'obra briefing blueprint' instead",
    ),
    protocol: bool = typer.Option(
        False,
        "--protocol",
        hidden=True,
        help="[DEPRECATED] Use 'obra briefing protocol' instead",
    ),
    questions: bool = typer.Option(
        False,
        "--questions",
        hidden=True,
        help="[DEPRECATED] Use 'obra briefing questions' instead",
    ),
    full: bool = typer.Option(
        False,
        "--full",
        hidden=True,
        help="[DEPRECATED] Use 'obra briefing full' instead",
    ),
    path: bool = typer.Option(
        False,
        "--path",
        hidden=True,
        help="[DEPRECATED] Use 'obra briefing path' instead",
    ),
) -> None:
    """Operating guide for AI assistants using Obra.

    Provides blueprint, protocol, and best practices for LLMs (Claude Code,
    Cursor, Gemini) helping users with Obra.

    Default output (no subcommand) includes:
    - Obra description
    - Input blueprint inline
    - 11 autonomous execution behaviors (names)
    - Subcommand reference

    Examples:
        obra briefing              Default: blueprint inline
        obra briefing blueprint    Quick reference checklist
        obra briefing protocol     Full 11 autonomous behaviors
        obra briefing questions    Question patterns by category
        obra briefing full         Complete guide (1700+ lines)
        obra briefing path         Show file location

    Exit Codes:
        0: Always (informational command)
    """
    try:
        # Handle deprecated flag usage with warnings
        if any([blueprint, protocol, questions, full, path]):
            # Map deprecated flags to new subcommands
            if path:
                err_console.print(
                    f"[yellow]{build_deprecation_warning('--path', 'obra briefing path')}[/yellow]",
                    style="yellow",
                )
                content, file_path = _load_onboarding_content()
                console.print()
                console.print("[bold]LLM Onboarding Guide Location:[/bold]")
                console.print()
                console.print(f"  {file_path}")
                console.print()
                console.print("Use this path to read the complete guide in your editor or tools.")
                console.print()
                return

            if full:
                err_console.print(
                    f"[yellow]{build_deprecation_warning('--full', 'obra briefing full')}[/yellow]",
                    style="yellow",
                )
                content, _ = _load_onboarding_content()
                console.print(content)
                return

            if blueprint:
                err_console.print(
                    f"[yellow]{build_deprecation_warning('--blueprint', 'obra briefing blueprint')}[/yellow]",
                    style="yellow",
                )
                _display_blueprint()
                return

            if protocol:
                err_console.print(
                    f"[yellow]{build_deprecation_warning('--protocol', 'obra briefing protocol')}[/yellow]",
                    style="yellow",
                )
                content, _ = _load_onboarding_content()
                _display_markdown_section(
                    content,
                    "Autonomous Operation Protocol",
                    "AUTONOMOUS OPERATION PROTOCOL",
                    console,
                )
                return

            if questions:
                err_console.print(
                    f"[yellow]{build_deprecation_warning('--questions', 'obra briefing questions')}[/yellow]",
                    style="yellow",
                )
                content, _ = _load_onboarding_content()
                _display_markdown_section(
                    content,
                    "Question Patterns|The Questions to Ask",
                    "QUESTION PATTERNS FOR GATHERING REQUIREMENTS",
                    console,
                )
                return

        # If a subcommand is being invoked, let it handle things
        if ctx.invoked_subcommand is not None:
            return

        # Default: show the briefing guide
        _track_briefing_usage("default")
        _display_default_briefing()

    except typer.Exit:
        raise
    except (UnicodeEncodeError, UnicodeDecodeError):
        raise
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in briefing command: {e}")
        raise typer.Exit(1) from e


@briefing_app.command(name="quick")
@handle_encoding_errors
def briefing_quick() -> None:
    """Essential input quality checklist (~2 min read, 1,500 tokens).

    Shows a quick reference with minimum required information, quality gates,
    and decision tree for gathering requirements. Recommended starting point
    for AI agents.

    Examples:
        obra briefing quick

    Exit Codes:
        0: Always (informational command)
    """

    def _show_quick(c: Console) -> None:
        # Load BRIEFING_QUICK.md from package
        try:
            # Try importlib.resources first (Python 3.9+)
            from importlib.resources import files

            quick_content = files("obra").joinpath(".obra/BRIEFING_QUICK.md").read_text()
        except (ImportError, AttributeError):
            # Fallback to pkg_resources for older Python
            import pkg_resources

            quick_content = pkg_resources.resource_string("obra", ".obra/BRIEFING_QUICK.md").decode(
                "utf-8"
            )
        c.print(quick_content)

    _briefing_command("quick", _show_quick, console)


@briefing_app.command(name="full")
@handle_encoding_errors
def briefing_full() -> None:
    """Complete LLM onboarding guide (3,600+ lines).

    Outputs the entire LLM_ONBOARDING.md file, which includes:
    - Input blueprint (what to gather from users)
    - Autonomous operation protocol (11 behaviors)
    - Question patterns by category
    - Advanced usage patterns

    Examples:
        obra briefing full
        obra briefing full | head -100

    Exit Codes:
        0: Always (informational command)
    """

    def _show_full(c: Console) -> None:
        content, _ = _load_onboarding_content()
        c.print(content)

    _briefing_command("full", _show_full, console)


@briefing_app.command(name="blueprint")
@handle_encoding_errors
def briefing_blueprint() -> None:
    """Quick blueprint reference (condensed checklist format).

    Shows a condensed checklist of what to gather from users before
    invoking Obra. Useful as a quick reference during conversations.

    Examples:
        obra briefing blueprint

    Exit Codes:
        0: Always (informational command)
    """
    _briefing_command("blueprint", lambda c: _display_blueprint(), console)


@briefing_app.command(name="protocol")
@handle_encoding_errors
def briefing_protocol() -> None:
    """Full autonomous execution protocol (11 behaviors detailed).

    Shows the complete autonomous operation protocol that describes
    how LLMs should behave while Obra executes tasks.

    Examples:
        obra briefing protocol

    Exit Codes:
        0: Always (informational command)
    """

    def _show_protocol(c: Console) -> None:
        content, _ = _load_onboarding_content()
        _display_markdown_section(
            content,
            "Autonomous Operation Protocol",
            "AUTONOMOUS OPERATION PROTOCOL",
            c,
        )

    _briefing_command("protocol", _show_protocol, console)


@briefing_app.command(name="questions")
@handle_encoding_errors
def briefing_questions() -> None:
    """Detailed question patterns by category.

    Shows question patterns organized by category to help LLMs
    gather requirements from users effectively.

    Examples:
        obra briefing questions

    Exit Codes:
        0: Always (informational command)
    """

    def _show_questions(c: Console) -> None:
        content, _ = _load_onboarding_content()
        _display_markdown_section(
            content,
            "Question Patterns|The Questions to Ask",
            "QUESTION PATTERNS FOR GATHERING REQUIREMENTS",
            c,
        )

    _briefing_command("questions", _show_questions, console)


@briefing_app.command(name="path")
@handle_encoding_errors
def briefing_path() -> None:
    """Show file path for deep reading.

    Shows the location of the LLM_ONBOARDING.md file so you can
    read it directly in your editor or tools.

    Examples:
        obra briefing path

    Exit Codes:
        0: Always (informational command)
    """

    def _show_path(c: Console) -> None:
        _, file_path = _load_onboarding_content()
        c.print()
        c.print("[bold]LLM Onboarding Guide Location:[/bold]")
        c.print()
        c.print(f"  {file_path}")
        c.print()
        c.print("Use this path to read the complete guide in your editor or tools.")
        c.print()

    _briefing_command("path", _show_path, console)


@briefing_app.command(name="examples")
@handle_encoding_errors
def briefing_examples() -> None:
    """Good vs bad input examples across project types.

    Shows 20+ worked examples comparing vague (bad) vs specific (good)
    input for common project types: APIs, web apps, CLIs, and more.

    Examples:
        obra briefing examples

    Exit Codes:
        0: Always (informational command)
    """
    _briefing_command("examples", lambda c: _display_examples(), console)


def _display_examples() -> None:
    """Display good vs bad input examples for common project types."""
    _display_examples_impl(console)
