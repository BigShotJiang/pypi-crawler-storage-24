"""Setup command implementation extracted from obra.cli._main."""

from __future__ import annotations

import logging

import typer
from rich.markup import escape

from obra import __version__
from obra.cli.feedback import offer_bug_report
from obra.config.loaders import get_cli_retry_config
from obra.display import console, glyphs, print_error, print_success, print_warning
from obra.display.errors import display_error, display_obra_error
from obra.exceptions import ConfigurationError, ObraError
from obra.messages import get_message

logger = logging.getLogger(__name__)


def _render_workflow_studio_setup_hint() -> None:
    from obra.cli.studio import _studio_gateway_install_hint, _voice_install_hint

    console.print("[bold]Workflow Studio[/bold]")
    console.print("    Launch with `obra studio`.")
    console.print(
        f"    Install the Studio runtime if needed: `{escape(_studio_gateway_install_hint())}`"
    )
    console.print(f"    Optional voice dictation: `{escape(_voice_install_hint())}`")
    console.print("    Diagnose launch issues with `obra studio doctor`.")
    console.print()


def setup(
    check: bool = typer.Option(
        False,
        "--check",
        help="Check setup status without prompting",
    ),
    skip_validation: bool = typer.Option(
        False,
        "--skip-validation",
        help="Skip environment validation after authentication",
    ),
    timeout: int = typer.Option(
        300,
        "--timeout",
        "-t",
        help="Timeout in seconds for browser authentication",
    ),
    no_browser: bool = typer.Option(
        False,
        "--no-browser",
        help="Don't open browser, just print URL",
    ),
    device_code: bool = typer.Option(  # noqa: ARG001 - kept for backward compat
        False,
        "--device-code",
        hidden=True,
        help="(Deprecated) Device code flow is now the default.",
    ),
) -> None:
    """First-time setup with terms acceptance, authentication, and provider selection.

    Complete onboarding flow:
    1. Display and accept Beta Software Agreement
    2. Authenticate via browser OAuth
    3. Register acceptance with server
    4. Validate environment configuration
    5. Select LLM provider (recommended settings auto-applied)

    Examples:
        $ obra setup
        $ obra setup --check
        $ obra setup --no-browser
        $ obra setup --timeout 600

    Exit Codes:
        0: Setup complete (or --check passed)
        1: Setup incomplete or failed
        2: User declined terms
    """
    try:
        from obra.api import APIClient
        from obra.auth import save_auth
        from obra.config import (
            DEFAULT_PROVIDER,
            PRIVACY_VERSION,
            TERMS_VERSION,
            is_terms_accepted,
            load_config,
            needs_reacceptance,
            save_config,
            save_terms_acceptance,
        )
        from obra.legal import get_terms_summary

        # S1.T6: Implement --check flag
        if check:
            console.print()
            console.print("[bold]Setup Status Check[/bold]", style="cyan")
            console.print()

            # Check terms acceptance
            if is_terms_accepted():
                print_success(f"Terms accepted: version {TERMS_VERSION}")
            elif needs_reacceptance():
                from obra.config import get_terms_acceptance

                old_acceptance = get_terms_acceptance()
                old_version = (
                    old_acceptance.get("version", "unknown") if old_acceptance else "unknown"
                )
                print_warning(f"Terms version mismatch: {old_version} → {TERMS_VERSION}")
                console.print(get_message("recovery.auth.terms"))
                raise typer.Exit(1)
            else:
                print_warning("Terms not accepted")
                console.print(get_message("recovery.auth.terms"))
                raise typer.Exit(1)

            # Check authentication
            from obra.auth import get_current_auth

            auth = get_current_auth()
            if auth:
                print_success(f"Authenticated: {auth.email}")
            else:
                print_warning("Not authenticated")
                console.print(get_message("recovery.auth.setup"))
                raise typer.Exit(1)

            # Check environment (provider CLIs)
            console.print()
            console.print("[bold]Environment:[/bold]")

            from obra.config import LLM_PROVIDERS, check_provider_status

            provider_count = 0
            for provider_key in LLM_PROVIDERS:
                status = check_provider_status(provider_key)
                provider_name = LLM_PROVIDERS[provider_key].get("name", provider_key)

                if status.installed:
                    console.print(
                        f"  [green]{glyphs.success}[/green] {provider_name} ({status.cli_command})"
                    )
                    provider_count += 1
                else:
                    console.print(
                        f"  [red]{glyphs.failure}[/red] {provider_name} ({status.cli_command}) - not found"
                    )

            console.print()
            if provider_count > 0:
                print_success("Setup complete - all checks passed")
                raise typer.Exit(0)
            print_warning("No provider CLIs installed")
            console.print("Install at least one: claude, codex, or gemini")
            raise typer.Exit(1)

        # Regular setup flow (not --check mode)
        console.print()
        console.print("[bold]Obra Setup[/bold]", style="cyan")
        console.print()

        # S1.T7: Check if re-acceptance is needed
        if needs_reacceptance():
            from obra.config import get_terms_acceptance

            old_acceptance = get_terms_acceptance()
            old_version = old_acceptance.get("version", "unknown") if old_acceptance else "unknown"
            console.print(
                f"[yellow]Terms have been updated: v{old_version} → v{TERMS_VERSION}[/yellow]"
            )
            console.print()
            console.print("You must review and accept the updated terms to continue.")
            console.print()

        # S1.T1: Display terms summary
        terms_text = get_terms_summary()

        # Display terms in a box
        console.print(
            "[bold cyan]════════════════════════════════════════════════════════════════════════[/bold cyan]"
        )
        console.print(terms_text.strip())
        console.print(
            "[bold cyan]════════════════════════════════════════════════════════════════════════[/bold cyan]"
        )
        console.print()

        # Prompt for acceptance
        console.print("To accept these terms, type exactly: [bold]I ACCEPT[/bold]")
        console.print("To decline, type anything else or press Ctrl+C")
        console.print()

        # Get user input
        try:
            from obra.display.prompting import prompt_input

            user_input = prompt_input("> ").strip()
        except (KeyboardInterrupt, EOFError):
            console.print()
            console.print("[yellow]Setup cancelled by user[/yellow]")
            raise typer.Exit(2) from None

        # Check acceptance (case-insensitive)
        if user_input.upper() != "I ACCEPT":
            console.print()
            console.print("[yellow]Terms not accepted. Setup cancelled.[/yellow]")
            console.print()
            console.print(get_message("guidance.requirement.accept_terms"))
            raise typer.Exit(2)

        console.print()
        print_success(f"Terms v{TERMS_VERSION} accepted")
        console.print()

        # Save local acceptance
        save_terms_acceptance()

        # S1.T2: Authenticate via OAuth
        # Default: device code flow with auto-browser-open. The hosted auth
        # page (obra-205b0.web.app) avoids cross-origin cookie issues that
        # cause signInWithPopup to hang on localhost-served pages.
        if no_browser:
            console.print("Printing authentication URL (no browser)...")
        else:
            console.print("Opening browser for authentication...")
        console.print()

        try:
            from obra.auth import login_with_device_code

            if no_browser:
                auth_result = login_with_device_code(
                    timeout=timeout,
                    auto_open_browser=False,
                )
            else:
                auth_result = login_with_device_code(
                    timeout=timeout,
                    auto_open_browser=True,
                )
            save_auth(auth_result)

            console.print()
            print_success(f"Logged in as: {auth_result.email}")
            if auth_result.display_name:
                console.print(f"Name: {auth_result.display_name}")
            console.print()

        except typer.Exit:
            raise
        except Exception as e:
            print_error(f"Authentication failed: {e}")
            logger.error(f"OAuth flow failed during setup: {e}", exc_info=True)
            raise typer.Exit(1) from e

        # S1.T3: Register terms acceptance with server (MANDATORY)
        # Server-side registration is required for legal compliance.
        # Without server confirmation, we cannot prove acceptance in disputes.
        import time

        client = APIClient.from_config()
        # Get CLI retry config (CHORE-CONFIG-DEFAULTS-001-E3 S3)
        retry_config = get_cli_retry_config()
        max_retries = retry_config["max_attempts"]
        retry_delay = retry_config["initial_delay_s"]
        backoff_multiplier = retry_config["backoff_multiplier"]

        for attempt in range(1, max_retries + 1):
            try:
                client.log_terms_acceptance(
                    terms_version=TERMS_VERSION,
                    privacy_version=PRIVACY_VERSION,
                    client_version=__version__,
                )
                print_success("Terms acceptance registered with server")
                console.print()
                break  # Success - exit retry loop
            except typer.Exit:
                raise
            except Exception as e:
                logger.warning(f"Terms registration attempt {attempt}/{max_retries} failed: {e}")
                if attempt < max_retries:
                    console.print(
                        f"[yellow]Server registration failed, retrying ({attempt}/{max_retries})...[/yellow]"
                    )
                    time.sleep(retry_delay)
                    retry_delay *= backoff_multiplier  # Exponential backoff
                else:
                    # All retries exhausted - this is fatal
                    logger.exception(f"Terms registration failed after {max_retries} attempts")
                    print_error("Failed to register terms acceptance with server")
                    console.print()
                    console.print(
                        "[red]Server-side registration is required for legal compliance.[/red]"
                    )
                    console.print("Please check your internet connection and try again.")
                    console.print()
                    console.print(
                        "If the problem persists, please report the issue at: https://github.com/Unpossible-Creations/Obra/issues"
                    )
                    raise typer.Exit(1) from e

        # S1.T4: Run environment validation (unless skipped)
        if not skip_validation:
            console.print("[bold]Validating environment...[/bold]")
            console.print()

            from obra.config import LLM_PROVIDERS, check_provider_status

            provider_count = 0
            for provider_key in LLM_PROVIDERS:
                status = check_provider_status(provider_key)
                provider_name = LLM_PROVIDERS[provider_key].get("name", provider_key)

                if status.installed:
                    console.print(
                        f"  [green]{glyphs.success}[/green] {provider_name} CLI: {status.cli_command}"
                    )
                    provider_count += 1
                else:
                    console.print(f"  [dim]o[/dim] {provider_name} CLI: Not installed")

            console.print()

            # Check working directory
            from pathlib import Path

            obra_projects = Path.home() / "obra-projects"
            if obra_projects.exists():
                console.print(
                    f"  [green]{glyphs.success}[/green] Working directory: {obra_projects}"
                )
            else:
                console.print(
                    f"  [yellow]o[/yellow] Working directory: {obra_projects} (will be created)"
                )

            console.print()

            if provider_count == 0:
                print_warning("No provider CLIs installed")
                console.print()
                console.print("Obra requires at least one LLM provider CLI:")
                console.print("  - Claude Code: https://claude.com/download")
                console.print("  - OpenAI Codex: https://openai.com/codex")
                console.print("  - Gemini CLI: https://ai.google.dev/gemini-api/docs/cli")
                console.print()
                console.print("Install one and run 'obra setup --check' to verify.")
                console.print()

        # S4.T0: Prompt for LLM provider selection (simplified)
        console.print("[bold]Select LLM Provider[/bold]")
        console.print("Choose your preferred provider. Recommended settings will be applied.")
        console.print("(You can customize later with 'obra config')")
        console.print()

        # Show available providers with status
        from obra.config import LLM_PROVIDERS, check_provider_status

        available_providers = []
        for idx, provider_key in enumerate(["anthropic", "openai", "google"], 1):
            if provider_key not in LLM_PROVIDERS:
                continue
            status = check_provider_status(provider_key)
            provider_name = LLM_PROVIDERS[provider_key].get("name", provider_key)
            if status.installed:
                console.print(f"  {idx}. {provider_name} [green](installed)[/green]")
                available_providers.append(provider_key)
            else:
                console.print(f"  {idx}. {provider_name} [dim](not installed)[/dim]")
                available_providers.append(provider_key)

        console.print()

        # Get provider selection
        try:
            from obra.display.prompting import prompt_input

            selection = prompt_input("Enter provider number [1/2/3]: ").strip()
        except (KeyboardInterrupt, EOFError):
            console.print()
            console.print("[yellow]Setup cancelled by user[/yellow]")
            raise typer.Exit(2) from None

        # Parse selection
        provider_map = {"1": "anthropic", "2": "openai", "3": "google"}
        selected_provider = provider_map.get(selection, DEFAULT_PROVIDER)

        # Apply default persona features + provider config
        from obra.config.explorer.widgets.preset_picker import apply_default_persona_to_config
        from obra.config.llm import apply_provider_config

        config = load_config()
        apply_default_persona_to_config(config)
        config, _notifications = apply_provider_config(config, selected_provider)
        save_config(config)
        console.print()
        provider_display = LLM_PROVIDERS.get(selected_provider, {}).get("name", selected_provider)
        print_success(f"LLM configuration set to {provider_display}")
        console.print()
        _render_workflow_studio_setup_hint()

        # S1.T5: Display setup completion with copy-paste prompt
        console.print(
            "[bold cyan]═══════════════════════════════════════════════════════════════════════[/bold cyan]"
        )
        console.print()
        console.print("[bold green]Setup complete![/bold green]")
        console.print()
        console.print(
            "[bold cyan]═══════════════════════════════════════════════════════════════════════[/bold cyan]"
        )
        console.print()
        console.print("[bold]  USING OBRA WITH YOUR AI ASSISTANT[/bold]")
        console.print()
        console.print("    Copy this prompt to your AI assistant (Claude Code, Codex, Gemini):")
        console.print()
        console.print(
            "    [cyan]┌─────────────────────────────────────────────────────────────────┐[/cyan]"
        )
        console.print(
            "    [cyan]│[/cyan]                                                                 [cyan]│[/cyan]"
        )
        console.print(
            "    [cyan]│[/cyan]  I want to use Obra. Start with `obra briefing quick`, then  [cyan]│[/cyan]"
        )
        console.print(
            "    [cyan]│[/cyan]  use `obra models`, `obra help domains`, and `obra help run` [cyan]│[/cyan]"
        )
        console.print(
            "    [cyan]│[/cyan]  before invoking `obra run` for my objective.                 [cyan]│[/cyan]"
        )
        console.print(
            "    [cyan]│[/cyan]                                                                 [cyan]│[/cyan]"
        )
        console.print(
            "    [cyan]└─────────────────────────────────────────────────────────────────┘[/cyan]"
        )
        console.print()
        console.print("    Your AI will then follow the current discovery path and prepare")
        console.print("    higher-quality input before invoking Obra.")
        console.print()
        console.print(
            "[bold cyan]═══════════════════════════════════════════════════════════════════════[/bold cyan]"
        )
        console.print()
        console.print("[bold]Next steps:[/bold]")
        console.print()
        console.print("  1. Give your AI the prompt above, then describe what you want to build")
        console.print()
        console.print("  2. Or inspect the LLM/operator path directly:")
        console.print("     [cyan]$ obra briefing quick[/cyan]")
        console.print("     [cyan]$ obra models[/cyan]")
        console.print("     [cyan]$ obra help domains[/cyan]")
        console.print("     [cyan]$ obra help run[/cyan]")
        console.print()
        console.print("  3. Or start directly (if you know what you're doing):")
        console.print('     [cyan]$ obra run "Add user authentication" --stream[/cyan]')
        console.print()
        console.print("  4. Check session status anytime:")
        console.print("     [cyan]$ obra status[/cyan]")
        console.print()
        console.print("  5. Explore configuration:")
        console.print("     [cyan]$ obra config[/cyan]")
        console.print()
        console.print(
            "[bold cyan]═══════════════════════════════════════════════════════════════════════[/bold cyan]"
        )
        console.print()

    except typer.Exit:
        # Re-raise typer.Exit without catching it as an error
        raise
    except ConfigurationError as e:
        display_obra_error(e, console)
        logger.error(f"Configuration error in setup command: {e}", exc_info=True)
        offer_bug_report(e, context="setup", command_used="obra setup")
        raise typer.Exit(1) from e
    except ObraError as e:
        display_obra_error(e, console)
        logger.error(f"Obra error in setup command: {e}", exc_info=True)
        offer_bug_report(e, context="setup", command_used="obra setup")
        raise typer.Exit(1) from e
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in setup command: {e}")
        offer_bug_report(e, context="setup", command_used="obra setup")
        raise typer.Exit(1) from e
