"""Version check and auto-update module for Obra CLI.

Provides version checking against PyPI and automatic updates via the detected
installation toolchain (pipx, uv, or pip).

Features:
- Auto-update: runs the install-matched upgrade command with retries, then re-execs
  (FEAT-CLI-AUTO-UPDATE-001)
- Notification fallback: async banner when auto-update is disabled (FEAT-CLI-VERSION-NOTIFY-001)
- Semantic version comparison using packaging.version
- PyPI API fetching with timeout
- Local caching to prevent spam and redundant upgrade attempts
- All tunables exposed via config (cli.auto_update_*)
- Privacy-friendly (no tracking or user identification)

Example:
    from obra.version_check import try_auto_update, check_for_updates_async

    # Try auto-update first (synchronous, blocks until done)
    updated = try_auto_update()

    # If auto-update didn't handle it, fall back to notification
    if not updated:
        check_for_updates_async()

References: FEAT-CLI-AUTO-UPDATE-001, FEAT-CLI-VERSION-NOTIFY-001
"""

import atexit
import json
import logging
import os
import shutil
import subprocess
import sys
import threading
import time
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any, TypedDict, cast

import requests  # type: ignore[import-untyped]
from packaging.version import InvalidVersion
from packaging.version import parse as parse_version

from obra.constants import PYPI_TIMEOUT_S, VERSION_CHECK_EXIT_TIMEOUT_S

logger = logging.getLogger(__name__)

# Thread reference for exit handler coordination
_version_check_thread: threading.Thread | None = None
_VERSION_CHECK_EXIT_TIMEOUT = VERSION_CHECK_EXIT_TIMEOUT_S  # Max seconds to wait at exit

# PyPI API endpoint for Obra package
PYPI_API_URL = "https://pypi.org/pypi/obra/json"
PYPI_TIMEOUT = PYPI_TIMEOUT_S  # seconds

# Cache location
CACHE_DIR = Path.home() / ".obra"
CACHE_FILE = CACHE_DIR / ".version_check_cache"


def _is_editable_install() -> bool:
    """Return True if obra is installed in editable (dev) mode."""
    return _editable_source_dir() is not None


def _editable_source_dir() -> str | None:
    """Return the source directory for an editable install, or None."""
    try:
        import site as _site
        from importlib import metadata as _meta

        dist = _meta.distribution("obra")

        # Collect candidate direct_url.json locations.  Editable installs
        # may use egg-info (in the source tree) or dist-info (in
        # site-packages) depending on the build backend.
        candidates: list[Path] = [Path(str(dist._path)) / "direct_url.json"]
        for sp in _site.getsitepackages():
            for entry in Path(sp).iterdir():
                if entry.name.startswith("obra-") and entry.name.endswith(".dist-info"):
                    candidates.append(entry / "direct_url.json")

        for direct_url in candidates:
            if not direct_url.is_file():
                continue
            data = json.loads(direct_url.read_text(encoding="utf-8"))
            if not data.get("dir_info", {}).get("editable", False):
                continue
            url = data.get("url", "")
            if url.startswith("file://"):
                return url.removeprefix("file://")

        return None
    except Exception:
        return None


class VersionCache(TypedDict, total=False):
    """Structure for version check cache.

    Attributes:
        last_check_time: ISO timestamp of last PyPI check
        latest_version: Latest version fetched from PyPI
        last_shown_time: ISO timestamp when banner was last shown
        last_auto_update_time: ISO timestamp of last auto-update attempt
        last_auto_update_version: Version that was auto-updated to
    """

    last_check_time: str
    latest_version: str
    last_shown_time: str
    last_auto_update_time: str
    last_auto_update_version: str


class _UpgradeStrategy(TypedDict):
    """Resolved self-update execution strategy."""

    method: str
    command: list[str]


def compare_versions(current: str, latest: str) -> bool:
    """Compare semantic versions to determine if an update is available.

    Uses packaging.version.parse() for proper semantic version comparison,
    handling major, minor, patch increments, and prerelease versions.

    Args:
        current: Current installed version (e.g., "2.5.47")
        latest: Latest available version from PyPI (e.g., "2.6.0")

    Returns:
        True if latest > current, False otherwise

    Examples:
        >>> compare_versions("2.5.47", "2.6.0")
        True
        >>> compare_versions("2.6.0", "2.5.99")
        False
        >>> compare_versions("2.5.47", "2.5.47")
        False
        >>> compare_versions("2.5.47", "2.5.47-beta.1")
        False
    """
    try:
        current_ver = parse_version(current)
        latest_ver = parse_version(latest)
        return bool(latest_ver > current_ver)
    except InvalidVersion as e:
        logger.debug("Invalid version format: %s", e)
        return False


def fetch_latest_version() -> str | None:
    """Fetch the latest version of Obra from PyPI.

    Makes a synchronous HTTP request to the PyPI JSON API with a 2-second
    timeout. This function is intended to be called from a background thread
    to avoid blocking CLI startup.

    Returns:
        Latest version string (e.g., "2.6.0") if successful, None on error

    Examples:
        >>> version = fetch_latest_version()
        >>> if version:
        ...     print(f"Latest version: {version}")
    """
    try:
        response = requests.get(PYPI_API_URL, timeout=PYPI_TIMEOUT)
        response.raise_for_status()
        data = response.json()
        if not isinstance(data, dict):
            logger.warning("PyPI response is not a JSON object")
            return None

        info = data.get("info")
        if isinstance(info, dict):
            version = info.get("version")
            if isinstance(version, str):
                logger.debug("Fetched latest version from PyPI: %s", version)
                return version

        logger.warning("PyPI response missing version field")
        return None
    except requests.exceptions.Timeout:
        logger.debug("PyPI request timed out")
        return None
    except requests.exceptions.RequestException as e:
        logger.debug("PyPI request failed: %s", e)
        return None
    except (json.JSONDecodeError, KeyError) as e:
        logger.debug("Failed to parse PyPI response: %s", e)
        return None


def read_cache() -> VersionCache | None:
    """Read version check cache from disk.

    Returns:
        Cache dict with last_check_time, latest_version, and last_shown_time,
        or None if cache doesn't exist or is invalid

    Examples:
        >>> cache = read_cache()
        >>> if cache and "latest_version" in cache:
        ...     print(f"Cached version: {cache['latest_version']}")
    """
    try:
        if not CACHE_FILE.exists():
            return None

        with CACHE_FILE.open("r", encoding="utf-8") as f:
            data: Any = json.load(f)

        # Validate structure
        if not isinstance(data, dict):
            logger.warning("Cache file has invalid structure")
            return None

        return cast(VersionCache, data)
    except (json.JSONDecodeError, OSError) as e:
        logger.debug("Failed to read cache: %s", e)
        return None


def write_cache(cache: VersionCache) -> bool:
    """Write version check cache to disk.

    Args:
        cache: Cache dict with last_check_time, latest_version, last_shown_time

    Returns:
        True if successful, False on error

    Examples:
        >>> cache = {
        ...     "last_check_time": "2026-01-08T12:34:56Z",
        ...     "latest_version": "2.6.0",
        ...     "last_shown_time": "2026-01-08T12:34:56Z"
        ... }
        >>> write_cache(cache)
        True
    """
    try:
        # Ensure cache directory exists
        CACHE_DIR.mkdir(parents=True, exist_ok=True)

        with CACHE_FILE.open("w", encoding="utf-8") as f:
            json.dump(cache, f, indent=2)

        logger.debug("Cache written to %s", CACHE_FILE)
        return True
    except OSError as e:
        logger.debug("Failed to write cache: %s", e)
        return False


def _is_auto_update_cooldown_active(cache: VersionCache | None) -> bool:
    """Check if auto-update cooldown is still active.

    Args:
        cache: Current cache data, or None if no cache exists

    Returns:
        True if cooldown is active (should skip update), False otherwise
    """
    if not cache:
        return False

    last_update_raw = cache.get("last_auto_update_time")
    if not isinstance(last_update_raw, str):
        return False

    from obra.config import get_auto_update_cooldown_minutes

    cooldown_minutes = get_auto_update_cooldown_minutes()
    try:
        last_update = datetime.fromisoformat(last_update_raw)
        return datetime.now(UTC) - last_update <= timedelta(minutes=cooldown_minutes)
    except ValueError:
        return False


def _run_pipx_upgrade() -> bool:
    """Run pipx upgrade obra with retries.

    This helper is retained for backward compatibility/tests and delegates to
    the generic strategy runner.

    Returns:
        True if upgrade succeeded on any attempt, False otherwise
    """
    pipx_path = shutil.which("pipx")
    if not pipx_path:
        logger.debug("pipx not found on PATH, cannot auto-update via pipx")
        return False
    return _run_upgrade_with_retries(
        {
            "method": "pipx",
            "command": [pipx_path, "upgrade", "obra"],
        }
    )


def _determine_installer() -> str:
    """Detect how the current Obra distribution was installed."""
    try:
        import importlib.metadata

        dist = importlib.metadata.distribution("obra")
        installer_raw = dist.read_text("INSTALLER") if dist else ""
        installer = (installer_raw or "").strip().lower()
        if installer:
            return installer
    except Exception:
        return "unknown"
    return "unknown"


def _is_pipx_managing_obra(pipx_path: str, timeout_s: int) -> bool:
    """Return True if pipx currently manages an ``obra`` venv."""
    try:
        result = subprocess.run(
            [pipx_path, "list", "--json"],
            capture_output=True,
            text=True,
            timeout=timeout_s,
        )
        if result.returncode != 0:
            logger.debug(
                "pipx list --json failed while checking ownership (rc=%d): %s",
                result.returncode,
                result.stderr.strip(),
            )
            return False
        payload = json.loads(result.stdout or "{}")
        venvs = payload.get("venvs", {}) if isinstance(payload, dict) else {}
        return isinstance(venvs, dict) and "obra" in venvs
    except (subprocess.TimeoutExpired, OSError, ValueError, TypeError) as e:
        logger.debug("Failed to inspect pipx-managed packages: %s", e)
        return False


def _resolve_upgrade_strategy() -> _UpgradeStrategy | None:
    """Resolve the most appropriate self-update strategy for this installation.

    Editable (dev) installs are re-installed from the local source tree so
    that ``pip install --upgrade obra`` never replaces the editable link
    with a PyPI wheel.
    """
    # Editable installs: reinstall from the local source tree, not PyPI.
    editable_source = _editable_source_dir()
    if editable_source is not None:
        return {
            "method": "pip-editable",
            "command": [
                sys.executable,
                "-m",
                "pip",
                "install",
                "-e",
                f"{editable_source}[gateway]",
            ],
        }

    from obra.config import get_auto_update_pipx_timeout_s

    pipx_timeout = get_auto_update_pipx_timeout_s()
    pipx_path = shutil.which("pipx")
    if pipx_path and _is_pipx_managing_obra(pipx_path, timeout_s=pipx_timeout):
        return {
            "method": "pipx",
            "command": [pipx_path, "upgrade", "obra"],
        }

    installer = _determine_installer()
    if installer == "uv":
        uv_path = shutil.which("uv")
        if uv_path:
            return {
                "method": "uv",
                "command": [uv_path, "tool", "upgrade", "obra"],
            }
        logger.debug("INSTALLER=uv but uv is not on PATH; falling back to pip")

    return {
        "method": "pip",
        "command": [sys.executable, "-m", "pip", "install", "--upgrade", "obra"],
    }


def _clean_env_for_tool_upgrade(method: str) -> dict[str, str] | None:
    """Return a sanitized environment dict for tool-manager subprocesses.

    When obra runs inside a ``uv tool`` or ``pipx`` managed venv, the
    inherited environment may contain ``VIRTUAL_ENV``, ``PYTHONHOME``,
    or internal ``UV_INTERNAL__*`` variables that cause the tool manager
    to mis-target the upgrade (e.g. operating on the active venv instead
    of the tool's dedicated venv).  Stripping these variables matches the
    environment the user gets from a fresh shell — which is exactly the
    context where ``uv tool upgrade obra`` works correctly.

    Returns None for methods that don't need env sanitization (pip).
    """
    if method not in ("uv", "pipx"):
        return None

    env = os.environ.copy()
    # Keys that can mislead tool managers about the active environment.
    for key in list(env):
        if key in ("VIRTUAL_ENV", "PYTHONHOME"):
            env.pop(key)
        elif key.startswith("UV_INTERNAL"):
            env.pop(key)
    return env


def _run_upgrade_with_retries(strategy: _UpgradeStrategy) -> bool:
    """Run resolved self-update command with retries.

    Reads max retries, backoff delay, and timeout from config.

    Returns:
        True if upgrade succeeded on any attempt, False otherwise
    """
    from rich.console import Console

    from obra.config import (
        get_auto_update_max_retries,
        get_auto_update_pipx_timeout_s,
        get_auto_update_retry_delay_s,
    )

    max_retries = get_auto_update_max_retries()
    base_delay = get_auto_update_retry_delay_s()
    pipx_timeout = get_auto_update_pipx_timeout_s()
    err_console = Console(stderr=True)
    method = strategy.get("method", "unknown")
    command = strategy.get("command", [])
    if not command:
        logger.debug("No update command resolved for method=%s", method)
        return False

    clean_env = _clean_env_for_tool_upgrade(method)

    for attempt in range(1, max_retries + 1):
        try:
            result = subprocess.run(
                command,
                capture_output=True,
                text=True,
                timeout=pipx_timeout,
                env=clean_env,
            )

            if result.returncode == 0:
                logger.debug(
                    "%s upgrade succeeded on attempt %d: %s",
                    method,
                    attempt,
                    (result.stdout.strip() or result.stderr.strip())[:200],
                )
                return True

            logger.debug(
                "%s upgrade attempt %d/%d failed (rc=%d): %s",
                method,
                attempt,
                max_retries,
                result.returncode,
                result.stderr.strip(),
            )

        except subprocess.TimeoutExpired:
            logger.debug(
                "%s upgrade attempt %d/%d timed out after %ds",
                method,
                attempt,
                max_retries,
                pipx_timeout,
            )
        except OSError as e:
            logger.debug("%s upgrade attempt %d/%d OS error: %s", method, attempt, max_retries, e)
            return False  # Unrecoverable

        if attempt < max_retries:
            delay = base_delay * (2 ** (attempt - 1))
            err_console.print(f"  [dim]Retry {attempt}/{max_retries - 1} in {delay:.0f}s...[/dim]")
            time.sleep(delay)

    return False


def _verify_installed_version() -> str | None:
    """Check the on-disk installed version of obra via a fresh subprocess.

    A fresh Python process avoids any in-memory metadata cache from the
    currently running interpreter, giving an accurate read of what the
    tool manager actually wrote to the venv's site-packages.
    """
    try:
        result = subprocess.run(
            [
                sys.executable,
                "-c",
                "from importlib.metadata import version; print(version('obra'))",
            ],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode == 0:
            return result.stdout.strip() or None
    except (subprocess.TimeoutExpired, OSError) as e:
        logger.debug("Post-upgrade version verification failed: %s", e)
    return None


def _recommended_upgrade_command() -> str:
    """Return a user-facing upgrade command string for this installation."""
    from obra.install_guidance import recommended_upgrade_command

    return recommended_upgrade_command()


def try_auto_update() -> bool:
    """Check for updates and auto-upgrade via detected package manager if behind.

    This is the primary entry point called from ``main()`` before
    ``check_for_updates_async()``. It runs synchronously and blocks
    until the upgrade completes (or fails/skips).

    Flow:
    1. Check ``cli.auto_update`` config — return False if disabled
    2. Read cache — skip if cooldown is active
    3. Fetch latest version from PyPI (2s timeout)
    4. If behind, run install-matched upgrade command with up to N retries
    5. On success, re-exec the CLI so the new version handles the command
    6. On failure, warn and return False (caller falls back to notification)

    Returns:
        True if auto-update was attempted (whether success or fail),
        False if skipped (disabled, cooldown, up-to-date).
        On successful upgrade, this function does **not** return — it
        re-execs the process.
    """
    try:
        from obra.config import get_auto_update

        if not get_auto_update():
            logger.debug("Auto-update disabled via config")
            return False

        from obra import __version__ as current_version

        # Check cache for cooldown
        cache = read_cache()
        if _is_auto_update_cooldown_active(cache):
            logger.debug("Auto-update cooldown active, skipping")
            return False

        # Fetch latest version
        latest_version = fetch_latest_version()
        if not latest_version:
            return False

        if not compare_versions(current_version, latest_version):
            # Already up to date — update cache timestamp so cooldown kicks in
            now = datetime.now(UTC).isoformat()
            new_cache: VersionCache = {
                "last_check_time": now,
                "latest_version": latest_version,
                "last_auto_update_time": now,
                "last_auto_update_version": latest_version,
            }
            if cache and "last_shown_time" in cache:
                new_cache["last_shown_time"] = cache["last_shown_time"]
            write_cache(new_cache)
            return False

        # Newer version available — attempt upgrade
        from rich.console import Console

        err_console = Console(stderr=True)
        err_console.print(
            f"[bold cyan]Updating obra {current_version} → {latest_version}...[/bold cyan]"
        )

        now = datetime.now(UTC).isoformat()
        strategy = _resolve_upgrade_strategy()
        if not strategy:
            logger.debug("No auto-update strategy resolved; skipping auto-update")
            return False
        success = _run_upgrade_with_retries(strategy)

        # Update cache regardless of outcome
        new_cache = VersionCache(
            last_check_time=now,
            latest_version=latest_version,
            last_auto_update_time=now,
            last_auto_update_version=latest_version,
        )
        if cache and "last_shown_time" in cache:
            new_cache["last_shown_time"] = cache["last_shown_time"]
        write_cache(new_cache)

        if success:
            # Verify the upgrade actually took effect by checking the
            # installed metadata from a fresh subprocess.  Tool managers
            # can return exit-code 0 without changing the installed
            # version (stale index cache, env interference, file locks).
            actual_version = _verify_installed_version()
            if actual_version and actual_version == current_version:
                logger.warning(
                    "Upgrade command succeeded (rc=0) but installed version "
                    "is still %s — skipping re-exec",
                    current_version,
                )
                err_console.print(
                    f"[yellow]Update did not take effect "
                    f"(still {current_version}), continuing.[/yellow]"
                )
                return True  # Attempted — skip notification fallback

            err_console.print(f"[bold green]Updated to {latest_version}[/bold green]")
            # Re-exec so the new version handles the command
            logger.debug("Re-execing with argv: %s", sys.argv)
            os.execvp(sys.argv[0], sys.argv)
            # execvp replaces the process — code below never runs
            return True  # pragma: no cover

        err_console.print(
            f"[yellow]Update failed after retries, continuing with {current_version}[/yellow]"
        )
        return True  # Attempted but failed — skip notification fallback

    except Exception as e:  # pylint: disable=broad-except
        logger.debug("Auto-update failed: %s", e)
        return False


def _background_check() -> None:
    """Background worker that checks for version updates.

    This function runs in a daemon thread and handles all the logic
    for fetching, comparing, and displaying version updates. Fails
    silently on any error to avoid disrupting CLI usage.
    """
    try:
        from obra import __version__ as current_version

        # Read cache
        cache = read_cache()

        # Fetch latest version from PyPI
        latest_version = fetch_latest_version()
        if not latest_version:
            return

        # Update cache with latest check
        now = datetime.now(UTC).isoformat()
        new_cache: VersionCache = {
            "last_check_time": now,
            "latest_version": latest_version,
        }

        # Check if we should show the banner
        should_show = False
        if compare_versions(current_version, latest_version):
            # New version available - check cooldown
            if cache:
                # Get cooldown from config
                # pylint: disable=no-name-in-module
                from obra.config import get_update_notification_cooldown_minutes

                cooldown_minutes = get_update_notification_cooldown_minutes()
                try:
                    last_shown_raw = cache.get("last_shown_time")
                    if isinstance(last_shown_raw, str):
                        last_shown = datetime.fromisoformat(last_shown_raw)
                        if datetime.now(UTC) - last_shown > timedelta(minutes=cooldown_minutes):
                            should_show = True
                    else:
                        should_show = True
                except ValueError:
                    # Invalid timestamp, show banner
                    should_show = True
            else:
                # Never shown before, show banner
                should_show = True

        if should_show:
            # Display update banner
            _display_update_banner(current_version, latest_version)
            new_cache["last_shown_time"] = now
        elif cache and "last_shown_time" in cache:
            # Preserve existing last_shown_time
            new_cache["last_shown_time"] = cache["last_shown_time"]

        # Write cache
        write_cache(new_cache)

    except Exception as e:  # pylint: disable=broad-except
        # Fail silently - version check should never disrupt CLI
        logger.debug("Version check failed: %s", e)


def _display_update_banner(current: str, latest: str) -> None:
    """Display update notification banner to stderr.

    Args:
        current: Current installed version
        latest: Latest available version from PyPI
    """
    # Import here to avoid circular dependencies and reduce startup overhead
    from rich.console import Console
    from rich.panel import Panel

    err_console = Console(stderr=True)

    message = (
        f"[bold yellow]Update available![/bold yellow] "
        f"{current} → [bold green]{latest}[/bold green]\n\n"
        "Upgrade command:\n"
        f"  [bold cyan]{_recommended_upgrade_command()}[/bold cyan]"
    )

    panel = Panel(
        message,
        title="[bold]Obra Version Notification[/bold]",
        border_style="yellow",
        padding=(1, 2),
    )

    err_console.print(panel)


def _on_exit_wait_for_version_check() -> None:
    """Exit handler that waits for version check thread to complete.

    This ensures the version check has time to complete before the CLI
    exits, even for quick commands like `obra --help`. Uses a timeout
    to avoid blocking indefinitely if something goes wrong.
    """
    global _version_check_thread
    if _version_check_thread is not None and _version_check_thread.is_alive():
        logger.debug("Waiting for version check to complete...")
        _version_check_thread.join(timeout=_VERSION_CHECK_EXIT_TIMEOUT)
        if _version_check_thread.is_alive():
            logger.debug("Version check timed out at exit")


def check_for_updates_async() -> None:
    """Spawn background thread to check for version updates.

    This is the main entry point for version checking. It spawns a
    daemon thread that performs the check asynchronously, returning
    immediately to avoid blocking CLI startup.

    The thread will:
    - Fetch latest version from PyPI with 2-second timeout
    - Compare with current version
    - Display banner on stderr if update available
    - Respect cooldown period to avoid notification spam
    - Fail silently on any error

    An atexit handler ensures the thread has time to complete before
    the CLI exits, even for quick commands.

    Examples:
        >>> # Call from CLI main() before app() invocation
        >>> check_for_updates_async()
        >>> # CLI continues immediately, version check runs in background
    """
    global _version_check_thread

    # Check config flag - skip if disabled
    # pylint: disable=no-name-in-module
    from obra.config import get_check_for_updates

    if not get_check_for_updates():
        logger.debug("Version check disabled via config")
        return

    # Skip if already running (shouldn't happen, but be safe)
    if _version_check_thread is not None and _version_check_thread.is_alive():
        logger.debug("Version check already in progress")
        return

    thread = threading.Thread(target=_background_check, daemon=True)
    thread.start()
    _version_check_thread = thread

    # Register exit handler to wait for thread completion
    atexit.register(_on_exit_wait_for_version_check)

    # Return immediately - thread runs in background
