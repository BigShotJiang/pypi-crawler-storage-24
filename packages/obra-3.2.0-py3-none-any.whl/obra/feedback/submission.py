"""Feedback submission management.

This module encapsulates the server submission logic extracted from
FeedbackCollector, providing a dedicated SubmissionManager that handles:
- 3-tier authenticated submission (APIClient -> raw token -> anonymous)
- Raw auth token retrieval from YAML config without validation
- Local storage fallback when API submission fails
"""

import json
import logging
from http import HTTPStatus
from pathlib import Path
from typing import Any

from obra.constants import FEEDBACK_SUBMIT_TIMEOUT_S

logger = logging.getLogger(__name__)


class SubmissionManager:
    """Manages feedback submission with 3-tier auth fallback.

    Handles server submission attempts and local storage fallback
    independently of report creation and draft management concerns.

    The auth fallback strategy is:
    1. Fully authenticated submission via APIClient
    2. Raw auth token from config (even if expired — let server decide)
    3. Anonymous submission (no token)

    If all server attempts fail, stores feedback locally for later sync.
    """

    # Default pending directory for locally stored feedback
    DEFAULT_PENDING_DIR = Path.home() / ".obra" / "feedback" / "pending"

    def __init__(self, pending_dir: Path | None = None) -> None:
        """Initialize submission manager.

        Args:
            pending_dir: Directory for storing pending feedback when
                submission fails. Defaults to ~/.obra/feedback/pending/.
        """
        self._pending_dir = pending_dir or self.DEFAULT_PENDING_DIR

    def submit_to_server(self, submission_data: dict[str, Any]) -> dict[str, Any]:
        """Submit feedback to server, preserving auth when possible.

        Strategy:
        1. Try fully authenticated submission via APIClient
        2. If auth setup fails, try with whatever token we have (let server decide)
        3. Fall back to anonymous only if no token available

        Args:
            submission_data: Prepared feedback data

        Returns:
            Server response dict with success, report_id, message

        Raises:
            Exception: If all submission attempts fail
        """
        import requests

        from obra.config import get_api_base_url

        feedback_url = f"{get_api_base_url()}/feedback"

        # Try authenticated submission first
        try:
            from obra.api import APIClient

            client = APIClient.from_config()
            return client.submit_feedback(submission_data)
        except Exception as auth_error:
            logger.debug(f"APIClient auth failed: {auth_error}")

        # Auth setup failed - try with raw token from config (even if expired)
        # Server may still accept it or handle gracefully
        auth_token = self._get_raw_auth_token()
        headers = {"Content-Type": "application/json"}
        if auth_token:
            headers["Authorization"] = f"Bearer {auth_token}"
            logger.debug("Submitting feedback with raw token (may be expired)")
        else:
            logger.debug("No auth token available, submitting anonymously")

        try:
            response = requests.post(
                feedback_url,
                json=submission_data,
                headers=headers,
                timeout=FEEDBACK_SUBMIT_TIMEOUT_S,
            )

            if response.status_code == HTTPStatus.CREATED.value:
                return response.json()
            if response.status_code == HTTPStatus.TOO_MANY_REQUESTS.value:
                msg = "Rate limit exceeded. Please try again later."
                raise Exception(msg)
            error_data = response.json() if response.text else {}
            raise Exception(error_data.get("error", f"Server returned {response.status_code}"))

        except requests.RequestException as e:
            msg = f"Network error: {e}"
            raise Exception(msg) from e

    def _get_raw_auth_token(self) -> str | None:
        """Get auth token from config without validation.

        Used for feedback submission when normal auth flow fails.
        Returns token even if expired - let server decide validity.
        """
        try:
            import yaml

            from obra.config import AUTH_STATE_PATH

            auth_path = AUTH_STATE_PATH
            if auth_path.exists():
                with auth_path.open(encoding="utf-8") as f:
                    state = yaml.safe_load(f) or {}
                return state.get("auth_token")
        except Exception as e:
            logger.debug(f"Failed to read auth token: {e}")
        return None

    def store_locally(self, report_id: str, submission_data: dict[str, Any]) -> dict[str, Any]:
        """Store feedback locally when API submission fails.

        This ensures feedback is never lost even if the server is unreachable.

        Args:
            report_id: The report ID for the feedback being stored
            submission_data: Prepared feedback data to persist

        Returns:
            Dictionary with storage result including local path
        """
        try:
            self._pending_dir.mkdir(parents=True, exist_ok=True)

            pending_path = self._pending_dir / f"{report_id}.json"
            with pending_path.open("w", encoding="utf-8") as f:
                json.dump(submission_data, f, indent=2)

            return {
                "success": False,
                "report_id": report_id,
                "message": "Submission failed. Feedback saved locally — run 'obra feedback sync' to retry.",
                "stored_locally": True,
                "local_path": str(pending_path),
            }
        except Exception as e:
            return {
                "success": False,
                "report_id": report_id,
                "message": f"Failed to store feedback: {e}",
            }
