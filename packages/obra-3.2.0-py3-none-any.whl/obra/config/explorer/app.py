"""Configuration Explorer Textual Application.

Main application class for the interactive configuration browser.
"""

import logging
from importlib.resources import files
from typing import Any

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Container, ScrollableContainer, Vertical
from textual.widgets import Footer, Header, Static, Tree

from obra import config
from obra.config.loaders import get_config_explorer_config

from .dirty_state_controller import DirtyStateController
from .llm_view_state import LLMViewState
from .models import ConfigTree
from .save_controller import SaveController
from .tree_controller import TreeController
from .utils import (
    dict_to_config_tree,
    find_nodes_by_path_pattern,
    get_preset_name,
)
from .view_router import ViewRouter
from .widgets import (
    Breadcrumb,
    ConfigTreeView,
    CustomLLMView,
    DebugAdvancedView,
    DomainView,
    HelpOverlay,
    LLMSelection,
    LLMWizard,
    ModerateLLMView,
    NavigationMenu,
    PersonaView,
    PipelineOptionsView,
    PresetPicker,
    PresetSelection,
    QuickActionsBar,
    RuntimeCLIView,
    SearchBar,
    SimpleLLMView,
    SpecializedAgentsView,
    ValidationToolingView,
)
from .widgets.saveable_view import SaveableViewMixin

logger = logging.getLogger(__name__)


class OfflineBanner(Static):
    """Warning banner shown when server connection is unavailable."""

    DEFAULT_CSS = """
    OfflineBanner {
        height: auto;
        padding: 0 1;
        background: $warning-darken-3;
        color: $warning;
        text-style: bold;
    }
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self.update(
            "Offline Mode - Server unavailable. "
            "Local settings are editable, server settings are read-only."
        )


class DescriptionPanel(Static):
    """Panel showing the description of the currently selected setting."""

    DEFAULT_CSS = """
    DescriptionPanel {
        height: auto;
        min-height: 3;
        max-height: 6;
        padding: 0 1;
        background: $surface;
        border-top: solid $primary;
    }
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._description = "Select a setting to see its description."

    def update_description(self, description: str | None, path: str = "") -> None:
        """Update the displayed description.

        Args:
            description: Description text to show
            path: Path of the setting being described
        """
        if description:
            self._description = f"[bold]{path}[/bold]\n{description}"
        else:
            self._description = f"[bold]{path}[/bold]\nNo description available."
        self.update(self._description)


class StatusBar(Static):
    """Status bar showing pending changes, domain, persona, and connection status."""

    DEFAULT_CSS = """
    StatusBar {
        height: 1;
        dock: bottom;
        padding: 0 1;
        background: $primary-background;
        color: $text;
    }
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._pending_count = 0
        self._domain = "software"
        self._persona = "Custom"
        self._connected = True
        self._view_mode = "tree"
        self._tag_filter: str | None = None
        self._session_overrides: dict[str, str] | None = None

    def update_status(
        self,
        pending_count: int = 0,
        preset: str = "Custom",
        connected: bool = True,
        view_mode: str = "tree",
        tag_filter: str | None = None,
        persona: str | None = None,
        domain: str | None = None,
        session_overrides: dict[str, str] | None = None,
    ) -> None:
        """Update the status bar content.

        Args:
            pending_count: Number of pending changes
            preset: Current preset name (legacy, for backward compatibility)
            connected: Whether server connection is active
            view_mode: Current view mode (tree or pipeline)
            tag_filter: Active tag filter
            persona: Current detected persona name
            domain: Current configured domain
            session_overrides: Dict of CLI flag overrides (e.g., {"model": "sonnet via --model"})
        """
        self._pending_count = pending_count
        self._domain = domain or self._domain
        self._persona = persona or preset
        self._connected = connected
        self._view_mode = view_mode
        self._tag_filter = tag_filter
        self._session_overrides = session_overrides

        # Build status components
        parts = []

        # Pending changes
        changes_text = f"{pending_count} unsaved" if pending_count > 0 else "saved"
        parts.append(changes_text)

        # Domain indicator
        parts.append(f"Domain: {self._domain}")

        # Persona indicator
        parts.append(f"Persona: {self._persona}")

        # Session overrides indicator (S7.T3)
        if self._session_overrides:
            override_text = ", ".join(f"{k}: {v}" for k, v in self._session_overrides.items())
            parts.append(f"[yellow]Override: {override_text}[/yellow]")

        # View mode and tag filter
        view_text = f"view: {view_mode}"
        if tag_filter:
            view_text = f"{view_text} | tag: {tag_filter}"
        parts.append(view_text)

        # Connection status
        connection_icon = "[green]o[/green]" if connected else "[red]x[/red]"
        connection_text = "Connected" if connected else "Offline"
        parts.append(f"{connection_icon} {connection_text}")

        self.update(" | ".join(parts))


class ConfigExplorerApp(App):
    """Interactive TUI for browsing and editing Obra configuration.

    Features:
    - Tree-based navigation of configuration
    - Inline editing of values
    - Quick action wizards for common operations
    - Staged changes with explicit save
    """

    TITLE = "Obra Configuration Explorer"

    # Use importlib.resources to access package data file (works in installed packages)
    CSS_PATH = str(files("obra.config.explorer.styles").joinpath("explorer.tcss"))

    BINDINGS = [
        # q = contextual: back when in subview, quit when on menu
        Binding("q", "back_or_quit", "Back/Quit", priority=True),
        # Escape = always safe back (never quits)
        Binding("escape", "safe_back", "Back", priority=True),
        Binding("s", "save", "Save"),
        Binding("u", "discard", "Discard"),
        Binding("R", "reset_to_defaults", "Reset All"),
        Binding("slash", "search", "Search"),
        Binding("question_mark", "show_shortcuts", "Shortcuts"),
        Binding("v", "toggle_view", "View"),
        # Navigation shortcuts - ordered by increasing complexity
        Binding("0", "nav_domain", "Domain", show=False),
        Binding("1", "nav_personas", "Personas", show=False),
        Binding("2", "nav_simple_llm", "LLM Simple", show=False),
        Binding("3", "nav_moderate_llm", "LLM Moderate", show=False),
        Binding("4", "nav_custom_llm", "LLM Custom", show=False),
        Binding("5", "nav_runtime_cli", "Runtime & CLI", show=False),
        Binding("6", "nav_pipeline", "Pipeline", show=False),
        Binding("7", "nav_agents", "Agents", show=False),
        Binding("8", "nav_validation", "Validation", show=False),
        Binding("9", "nav_debug_advanced", "Debug & Advanced", show=False),
        Binding("f", "nav_full_config", "Full Config", show=False),
        Binding("d", "nav_domain", "Domain", show=False),
        Binding("m", "nav_menu", "Menu", show=False),
        Binding("p", "nav_personas", "Personas", show=False),
        # App-level scroll bindings — needed because key events from focused
        # child widgets (Select, Input, Switch) do NOT bubble to their parent
        # ScrollableContainer in Textual.  These catch the keys at app level
        # and forward to the active scrollable container or tree view.
        Binding("pagedown", "app_scroll('page_down')", "Page Down", show=False),
        Binding("pageup", "app_scroll('page_up')", "Page Up", show=False),
        Binding("home", "app_scroll('home')", "Home", show=False),
        Binding("end", "app_scroll('end')", "End", show=False),
        Binding("ctrl+f", "app_scroll('page_down')", "Page Down", show=False),
        Binding("ctrl+b", "app_scroll('page_up')", "Page Up", show=False),
        Binding("ctrl+d", "app_scroll('half_page_down')", "Half Page Down", show=False),
        Binding("ctrl+u", "app_scroll('half_page_up')", "Half Page Up", show=False),
        # Horizontal scroll — shift+arrow to scroll form content sideways
        Binding("shift+left", "app_hscroll('left')", "Scroll Left", show=False),
        Binding("shift+right", "app_hscroll('right')", "Scroll Right", show=False),
    ]

    def __init__(
        self,
        local_config: dict[str, Any] | None = None,
        server_config: dict[str, Any] | None = None,
        initial_section: str | None = None,
        api_client: Any | None = None,
        origins: dict[str, str] | None = None,
    ) -> None:
        """Initialize the Configuration Explorer.

        Args:
            local_config: Local configuration dictionary
            server_config: Server configuration dictionary
            initial_section: Section to expand initially (llm, features, advanced)
            api_client: API client for server operations
        """
        super().__init__()
        self._local_config = local_config or {}
        self._server_config = server_config or {}
        self._initial_section = initial_section
        self._api_client = api_client
        self._origins = origins or {}
        self._config_tree: ConfigTree | None = None
        self._base_tree: ConfigTree | None = None
        self._view_mode = "tree"
        self._active_tag_filter: str | None = None
        # Assume disconnected if no API client or no server config
        self._connected = api_client is not None and bool(server_config)
        # Navigation state
        self._current_view = "menu"  # 'menu', 'simple_llm', 'moderate_llm', etc.
        self._config_module = config
        self._offline_banner_cls = OfflineBanner
        self._view_router = ViewRouter(self)
        self._llm_view_state = LLMViewState(self)
        self._tree_controller = TreeController(self)
        self._save_controller = SaveController(self)
        self._dirty_state_controller = DirtyStateController(self)

    def compose(self) -> ComposeResult:
        """Create child widgets for the app."""
        yield Header()
        # Show offline banner if not connected
        if not self._connected:
            yield OfflineBanner(id="offline-banner")
        # Breadcrumb (hidden when on menu)
        yield Breadcrumb(id="breadcrumb")
        yield QuickActionsBar(id="quick-actions")
        yield SearchBar(id="search")
        # Navigation menu (shown on launch, wrapped for scroll on short terminals)
        with ScrollableContainer(id="menu-scroll"):
            yield NavigationMenu(id="nav-menu")
        yield Container(
            Vertical(
                # Tree will be added after config_tree is built in on_mount
                id="tree-container",
            ),
            DescriptionPanel(id="description"),
            id="main",
        )
        yield StatusBar(id="status")
        yield Footer()

    def on_mount(self) -> None:
        """Initialize the app when mounted."""
        from obra.config.explorer.debug import is_debug_enabled, log_tree_rebuild

        # Build the config tree
        if is_debug_enabled():
            log_tree_rebuild("on_mount: initial build")

        self._base_tree = dict_to_config_tree(
            self._local_config,
            self._server_config,
            origins=self._origins,
        )
        self._config_tree = self._build_view_tree()

        # Add the tree view to the container
        tree_container = self.query_one("#tree-container", Vertical)
        tree_view = ConfigTreeView(self._config_tree, id="tree")
        tree_container.mount(tree_view)

        # Update status bar with preset info
        preset = get_preset_name(self._server_config) or "default"
        status_bar = self.query_one("#status", StatusBar)
        status_bar.update_status(
            pending_count=0,
            preset=preset,
            connected=self._connected,
            domain=self._get_active_domain(),
        )

        # Set up initial navigation state - show menu, hide main content
        self._show_menu()

        # If initial_section specified, navigate to it directly
        if self._initial_section:
            section_mappings = {
                "llm": "simple_llm",
                "features": "personas",
                "advanced": "full_config",
            }
            target_view = section_mappings.get(self._initial_section)
            if target_view:
                self._show_view(target_view)

    # --- Navigation Methods ---

    # Human-readable names for entry points (ordered by complexity)
    VIEW_NAMES = {
        "domain": "Domain",
        "personas": "Personas",
        "simple_llm": "LLM Simple",
        "moderate_llm": "LLM Moderate",
        "custom_llm": "LLM Custom",
        "runtime_cli": "Runtime & CLI",
        "pipeline": "Pipeline Options",
        "agents": "Specialized Agents",
        "validation": "Validation & Tooling",
        "debug_advanced": "Debug & Advanced",
        "full_config": "Full Config",
    }

    def on_navigation_menu_selected(self, event: NavigationMenu.Selected) -> None:
        """Handle navigation menu selection."""
        self._show_view(event.entry_point)

    def on_breadcrumb_home_clicked(self, _event: Breadcrumb.HomeClicked) -> None:
        """Handle breadcrumb home button click."""
        self._show_menu()

    def _show_menu(self) -> None:
        """Show the navigation menu and hide other views."""
        self._view_router.show_menu()

    def _show_view(self, entry_point: str) -> None:
        """Navigate to a specific view.

        Args:
            entry_point: ID of the view to show ('simple_llm', 'full_config', etc.)
        """
        self._view_router.show_view(entry_point)

    def _remove_custom_views(self) -> None:
        """Remove any mounted custom view widgets."""
        self._view_router.remove_custom_views()

    def _sanitize_model_value(self, model: str | None, provider: str) -> str:
        """Sanitize model value for Select widget compatibility.

        Special config values like 'per-tier' and 'per-role' are delegation
        markers, not actual model IDs. This method validates the model value
        against available options and falls back to 'default' if invalid.

        Args:
            model: Model value from config (may be None or special value)
            provider: Provider to check valid models for

        Returns:
            Valid model ID for the Select widget
        """
        return self._llm_view_state.sanitize_model_value(model, provider)

    def _sanitize_reasoning_value(self, reasoning: str | None) -> str:
        """Sanitize reasoning value for Select widget compatibility."""
        return self._llm_view_state.sanitize_reasoning_value(reasoning)

    def _extract_tier_model(self, tier_value: Any, provider: str, default: str = "default") -> str:
        """Extract model from a tier entry (string or mapping)."""
        return self._llm_view_state.extract_tier_model(tier_value, provider, default)

    def _extract_tier_reasoning(self, tier_value: Any, fallback: str = "default") -> str:
        """Extract reasoning from a tier entry (string or mapping)."""
        return self._llm_view_state.extract_tier_reasoning(tier_value, fallback)

    def _mount_persona_view(self) -> None:
        """Mount the Persona configuration view with current config values."""
        # Detect current active persona from config
        current_persona = self._detect_active_persona_id()

        # Get current provider for tier resolution
        current_provider = "anthropic"
        if self._config_tree:
            provider_node = self._config_tree.get_node("llm.orchestrator.provider")
            if provider_node and provider_node.value:
                current_provider = provider_node.value

        # Create and mount the view
        view = PersonaView(
            current_persona=current_persona,
            current_provider=current_provider,
            classes="custom-view",
            id="persona-view",
        )
        main = self.query_one("#main", Container)
        main.mount(view)
        view.focus()

    def _mount_domain_view(self) -> None:
        """Mount the Domain configuration view with current config values."""
        view = DomainView(
            current_domain=self._get_active_domain(),
            classes="custom-view",
            id="domain-view",
        )
        main = self.query_one("#main", Container)
        main.mount(view)
        view.focus()

    def _detect_active_persona_id(self) -> str:
        """Detect which persona ID matches the current configuration.

        Returns:
            Persona ID (recommended, genie, quick_start, local_only) or default persona.
        """
        if self._config_tree is None:
            from .widgets.preset_picker import DEFAULT_PERSONA_ID

            return DEFAULT_PERSONA_ID

        from .widgets.preset_picker import PERSONAS

        # Get current automation_mode - key differentiator between personas
        automation_mode = "auto_full"  # default
        automation_node = self._config_tree.get_node("automation_mode")
        if automation_node and automation_node.value:
            automation_mode = automation_node.value

        # Get current provider
        provider = "anthropic"
        provider_node = self._config_tree.get_node("llm.orchestrator.provider")
        if provider_node and provider_node.value:
            provider = provider_node.value

        # Check scaffolded settings
        scaffolded_enabled = True  # default
        scaffolded_node = self._config_tree.get_node("planning.scaffolded.enabled")
        if scaffolded_node and scaffolded_node.value is not None:
            scaffolded_enabled = scaffolded_node.value

        # Match against personas
        for persona_id, persona in PERSONAS.items():
            features = persona.get("features", {})
            llm_profiles = persona.get("llm_profiles", {})

            # Check automation_mode match
            persona_automation = features.get("automation_mode")
            if persona_automation and persona_automation != automation_mode:
                continue

            # Check scaffolded.enabled match
            persona_scaffolded = features.get("planning.scaffolded.enabled")
            if persona_scaffolded is not None and persona_scaffolded != scaffolded_enabled:
                continue

            # Check provider match for local_only
            orch_profile = llm_profiles.get("orchestrator", {})
            persona_provider = orch_profile.get("provider")
            if persona_provider == "ollama" and provider != "ollama":
                continue
            if persona_provider != "ollama" and provider == "ollama":
                continue

            # This persona matches
            return persona_id

        from .widgets.preset_picker import DEFAULT_PERSONA_ID

        return DEFAULT_PERSONA_ID

    def on_persona_view_changed(self, event: PersonaView.Changed) -> None:
        """Handle Persona view selection changes.

        Persona cascades down to all LLM views (Simple, Moderate, Custom).
        """
        if not self._config_tree:
            return

        result = event.selection
        changes_made = self._apply_persona_to_config(result)

        # Note: We do NOT modify llm.roles.* here because those paths contain
        # profile references (e.g., "orchestrator", "implementation"), not model names.
        # LLM model settings are applied via llm_profiles in _apply_persona_to_config.

        # Update the view to show new ACTIVE state
        try:
            persona_view = self.query_one("#persona-view", PersonaView)
            persona_view.set_current_persona(result.preset_id)
        except Exception:
            pass

        # Update status bar
        self._update_status_bar()

        self.notify(
            f"Persona applied: {result.preset_name} ({changes_made} changes)",
            severity="information",
        )

    def on_domain_view_changed(self, event: DomainView.Changed) -> None:
        """Handle Domain view configuration changes."""
        if not self._config_tree:
            return

        self._config_tree.set_value(event.path, event.value)
        self._update_status_bar()

    def _mount_simple_llm_view(self) -> None:
        """Mount the Simple LLM configuration view with current config values."""
        self._llm_view_state.mount_simple_llm_view()

    def on_simple_llmview_changed(self, event: SimpleLLMView.Changed) -> None:
        """Handle Simple LLM view configuration changes.

        Menu 1 (Simple) cascades down to Menu 2 (Moderate) and Menu 3 (Custom).
        When a single model is selected, all tiers are set to that model.
        """
        from .debug import is_debug_enabled, log_action

        if is_debug_enabled():
            log_action(
                "on_simple_llmview_changed",
                f"RECEIVED Changed event: orch={event.orchestrator_provider}/{event.orchestrator_model}, "
                f"impl={event.implementation_provider}/{event.implementation_model}",
            )

        if not self._config_tree:
            return

        # Update Menu 1 config paths
        self._config_tree.set_value("llm.orchestrator.provider", event.orchestrator_provider)
        self._config_tree.set_value("llm.orchestrator.model", event.orchestrator_model)
        self._config_tree.set_value(
            "llm.orchestrator.reasoning_level", event.orchestrator_reasoning
        )
        self._config_tree.set_value("llm.implementation.provider", event.implementation_provider)
        self._config_tree.set_value("llm.implementation.model", event.implementation_model)
        self._config_tree.set_value(
            "llm.implementation.reasoning_level", event.implementation_reasoning
        )

        # CASCADE to Menu 2: Set all tiers to the selected model
        for tier in ("fast", "medium", "high"):
            self._config_tree.set_value(
                f"llm.orchestrator.tiers.{tier}",
                {
                    "model": event.orchestrator_model,
                    "reasoning_level": event.orchestrator_reasoning,
                },
            )
            self._config_tree.set_value(
                f"llm.implementation.tiers.{tier}",
                {
                    "model": event.implementation_model,
                    "reasoning_level": event.implementation_reasoning,
                },
            )

        # CASCADE to Menu 3: Update CustomLLMView if mounted
        self._cascade_to_custom_view(
            orchestrator_provider=event.orchestrator_provider,
            orchestrator_tiers={
                "fast": event.orchestrator_model,
                "medium": event.orchestrator_model,
                "high": event.orchestrator_model,
            },
            orchestrator_reasoning_tiers={
                "fast": event.orchestrator_reasoning,
                "medium": event.orchestrator_reasoning,
                "high": event.orchestrator_reasoning,
            },
            implementation_provider=event.implementation_provider,
            implementation_tiers={
                "fast": event.implementation_model,
                "medium": event.implementation_model,
                "high": event.implementation_model,
            },
            implementation_reasoning_tiers={
                "fast": event.implementation_reasoning,
                "medium": event.implementation_reasoning,
                "high": event.implementation_reasoning,
            },
        )

        # CASCADE to llm.roles: Update reasoning_level on any role entry
        # that has an explicit override (dict with reasoning_level key).
        # Without this, prior Menu 3 customizations keep stale reasoning
        # values that override the profile-level setting during resolution.
        from obra.config.explorer.widgets.llm_custom_view import DEFAULT_MAPPINGS

        reasoning_by_profile = {
            "orchestrator": event.orchestrator_reasoning,
            "implementation": event.implementation_reasoning,
        }
        for role_key, default_profile in DEFAULT_MAPPINGS.items():
            node = self._config_tree.get_node(f"llm.roles.{role_key}")
            if node and isinstance(node.value, dict) and "reasoning_level" in node.value:
                profile = node.value.get("profile", default_profile)
                new_reasoning = reasoning_by_profile.get(profile, event.implementation_reasoning)
                self._config_tree.set_value(f"llm.roles.{role_key}.reasoning_level", new_reasoning)

        # Update status bar to show pending changes
        self._update_status_bar()

    def _mount_moderate_llm_view(self) -> None:
        """Mount the Moderate LLM configuration view with tier-based config values."""
        self._llm_view_state.mount_moderate_llm_view()

    def on_moderate_llmview_changed(self, event: ModerateLLMView.Changed) -> None:
        """Handle Moderate LLM view configuration changes.

        Menu 2 (Moderate) cascades down to Menu 3 (Custom).
        Tier-based models propagate to per-action inheritance.
        """
        from obra.config.explorer.debug import (
            is_debug_enabled,
            log_message_received,
            log_pending_changes,
        )

        if is_debug_enabled():
            log_message_received(
                "on_moderate_llmview_changed",
                {
                    "orch_provider": event.orchestrator_provider,
                    "orch_tiers": event.orchestrator_tiers,
                    "impl_provider": event.implementation_provider,
                    "impl_tiers": event.implementation_tiers,
                },
            )

        if not self._config_tree:
            if is_debug_enabled():
                log_pending_changes(None, "handler_early_exit")
            return

        # Update Menu 2 config: providers and tiers
        self._config_tree.set_value("llm.orchestrator.provider", event.orchestrator_provider)
        self._config_tree.set_value(
            "llm.orchestrator.reasoning_level",
            event.orchestrator_reasoning_tiers.get("medium", "default"),
        )
        self._config_tree.set_value("llm.implementation.provider", event.implementation_provider)
        self._config_tree.set_value(
            "llm.implementation.reasoning_level",
            event.implementation_reasoning_tiers.get("medium", "default"),
        )

        # Update orchestrator tiers
        for tier, model in event.orchestrator_tiers.items():
            self._config_tree.set_value(
                f"llm.orchestrator.tiers.{tier}",
                {
                    "model": model,
                    "reasoning_level": event.orchestrator_reasoning_tiers.get(tier, "default"),
                },
            )

        # Update implementation tiers
        for tier, model in event.implementation_tiers.items():
            self._config_tree.set_value(
                f"llm.implementation.tiers.{tier}",
                {
                    "model": model,
                    "reasoning_level": event.implementation_reasoning_tiers.get(tier, "default"),
                },
            )

        # CASCADE to Menu 3: Update CustomLLMView if mounted
        self._cascade_to_custom_view(
            orchestrator_provider=event.orchestrator_provider,
            orchestrator_tiers=event.orchestrator_tiers,
            orchestrator_reasoning_tiers=event.orchestrator_reasoning_tiers,
            implementation_provider=event.implementation_provider,
            implementation_tiers=event.implementation_tiers,
            implementation_reasoning_tiers=event.implementation_reasoning_tiers,
        )

        # Debug: log pending changes after handler completes
        if is_debug_enabled():
            log_pending_changes(self._config_tree, "after_moderate_handler")

        # Update status bar to show pending changes
        self._update_status_bar()

    def _mount_custom_llm_view(self) -> None:
        """Mount the Custom LLM configuration view with current config values.

        Menu 3 (Custom) inherits tier configs from Menu 2 (Moderate).
        Each action has a profile.tier mapping that resolves to actual models.
        """
        self._llm_view_state.mount_custom_llm_view()

    def _get_orchestrator_tier_config(self) -> tuple[str, dict[str, str]]:
        """Get orchestrator provider and tier models from config.

        Returns:
            Tuple of (provider, {fast: model, medium: model, high: model})
        """
        return self._llm_view_state.get_orchestrator_tier_config()

    def _get_implementation_tier_config(self) -> tuple[str, dict[str, str]]:
        """Get implementation provider and tier models from config.

        Returns:
            Tuple of (provider, {fast: model, medium: model, high: model})
        """
        return self._llm_view_state.get_implementation_tier_config()

    def _get_tier_reasoning_config(self, role: str) -> dict[str, str]:
        """Get per-tier reasoning from config for a role."""
        return self._llm_view_state.get_tier_reasoning_config(role)

    def _get_role_reasoning_level(self, role: str) -> str:
        """Get role-level reasoning (reasoning_level) from config."""
        return self._llm_view_state.get_role_reasoning_level(role)

    def _get_role_configs(self) -> dict[str, dict[str, Any]]:
        """Get Menu 3 role configs (per-action overrides).

        Returns:
            Dict mapping action_id to role config dict with optional
            provider, model, reasoning_level overrides.
        """
        return self._llm_view_state.get_role_configs()

    def _cascade_to_custom_view(
        self,
        orchestrator_provider: str | None = None,
        orchestrator_tiers: dict[str, str] | None = None,
        orchestrator_reasoning_tiers: dict[str, str] | None = None,
        implementation_provider: str | None = None,
        implementation_tiers: dict[str, str] | None = None,
        implementation_reasoning_tiers: dict[str, str] | None = None,
    ) -> None:
        """Cascade tier config changes to Menu 3 (Custom) if mounted.

        Called when Menu 1 or Menu 2 changes to propagate new tier settings
        down to the Custom view's "Inherit" labels.

        Args:
            orchestrator_provider: New orchestrator provider
            orchestrator_tiers: New orchestrator tier models
            orchestrator_reasoning_tiers: New orchestrator tier reasoning
            implementation_provider: New implementation provider
            implementation_tiers: New implementation tier models
            implementation_reasoning_tiers: New implementation tier reasoning
        """
        try:
            custom_view = self.query_one("#custom-llm-view", CustomLLMView)
            custom_view.update_tier_configs(
                orchestrator_provider=orchestrator_provider,
                orchestrator_tiers=orchestrator_tiers,
                orchestrator_reasoning_tiers=orchestrator_reasoning_tiers,
                implementation_provider=implementation_provider,
                implementation_tiers=implementation_tiers,
                implementation_reasoning_tiers=implementation_reasoning_tiers,
            )
        except Exception:
            # View not mounted, cascade will happen when it's mounted
            pass

    def on_custom_llmview_changed(self, event: CustomLLMView.Changed) -> None:
        """Handle Custom LLM view configuration changes.

        Menu 3 (Custom) is the source of truth. Updates llm.roles.* config paths
        based on role configurations including profile, tier, and explicit overrides.
        """
        if not self._config_tree:
            return

        for role_id, role_cfg in event.role_configs.items():
            # Check if there are any explicit overrides
            has_overrides = (
                role_cfg.provider is not None
                or role_cfg.model is not None
                or role_cfg.reasoning_level is not None
            )

            if not has_overrides:
                # No overrides - save as profile.tier reference for inheritance
                # Format: {profile: "orchestrator", tier: "high"}
                self._config_tree.set_value(
                    f"llm.roles.{role_id}",
                    {"profile": role_cfg.profile, "tier": role_cfg.tier},
                )
            else:
                # Has explicit overrides - save full config
                role_value: dict[str, str] = {
                    "profile": role_cfg.profile,
                    "tier": role_cfg.tier,
                }
                if role_cfg.provider:
                    role_value["provider"] = role_cfg.provider
                if role_cfg.model:
                    role_value["model"] = role_cfg.model
                if role_cfg.reasoning_level:
                    role_value["reasoning_level"] = role_cfg.reasoning_level

                self._config_tree.set_value(f"llm.roles.{role_id}", role_value)

        # Update status bar to show pending changes
        self._update_status_bar()

    def _mount_runtime_cli_view(self) -> None:
        """Mount Runtime & CLI view with current Codex feature config."""
        from obra.config.explorer.widgets.runtime_cli_view import ALL_RUNTIME_CLI_SETTINGS

        current_values: dict[str, Any] = {}
        if self._config_tree:
            for setting_path in ALL_RUNTIME_CLI_SETTINGS:
                node = self._config_tree.get_node(setting_path)
                if node and node.value is not None:
                    current_values[setting_path] = node.value

        view = RuntimeCLIView(
            current_values=current_values,
            classes="custom-view",
            id="runtime-cli-view",
        )
        main = self.query_one("#main", Container)
        main.mount(view)
        view.focus()

    def on_runtime_cli_view_changed(self, event: RuntimeCLIView.Changed) -> None:
        """Handle Runtime & CLI view changes."""
        if not self._config_tree:
            return

        self._config_tree.set_value(event.path, event.value)
        self._update_status_bar()

    def _mount_pipeline_options_view(self) -> None:
        """Mount the Pipeline Options view with current config values.

        Passes both Menu 2 tier configs and Menu 3 role configs so Pipeline
        Options can display accurate inherited model info per phase.
        """
        self._llm_view_state.mount_pipeline_options_view()

    def on_pipeline_options_view_changed(self, event: PipelineOptionsView.Changed) -> None:
        """Handle Pipeline Options view configuration changes.

        Updates the config tree with the new setting value.
        """
        if not self._config_tree:
            return

        # Update the config value
        self._config_tree.set_value(event.path, event.value)

        # Update status bar to show pending changes
        self._update_status_bar()

    def _mount_specialized_agents_view(self) -> None:
        """Mount the Specialized Agents view with current config values.

        Agents inherit from the Review role configuration (llm.roles.review).
        The Review role can have explicit overrides or point to a profile
        (orchestrator or implementation) whose settings are then used.
        """
        self._llm_view_state.mount_specialized_agents_view()

    def on_specialized_agents_view_changed(self, event: SpecializedAgentsView.Changed) -> None:
        """Handle Specialized Agents view configuration changes.

        Updates the config tree with the new agent enabled state.
        Uses canonical config paths (features.quality_automation.agents.*.enabled).
        """
        if not self._config_tree:
            return

        # Update the config value using canonical path
        self._config_tree.set_value(event.config_path, event.enabled)

        # Update status bar to show pending changes
        self._update_status_bar()

    def on_specialized_agents_view_llm_changed(
        self, event: SpecializedAgentsView.LLMChanged
    ) -> None:
        """Handle Specialized Agents LLM config changes."""
        if not self._config_tree:
            return

        self._config_tree.set_value(event.config_path, event.value)
        self._update_status_bar()

    def _mount_validation_tooling_view(self) -> None:
        """Mount the Validation & Tooling view with current config values."""
        from pathlib import Path

        from obra.config.explorer.widgets.validation_tooling_view import (
            DISCOVERY_SETTINGS,
            STORY0_SETTINGS,
        )

        # Collect current values for automation_mode, story0, and discovery settings
        current_values: dict[str, Any] = {}

        if self._config_tree:
            # Get automation_mode (top-level config)
            automation_node = self._config_tree.get_node("automation_mode")
            if automation_node and automation_node.value is not None:
                current_values["automation_mode"] = automation_node.value

            # Get all story0 settings
            for setting_path in STORY0_SETTINGS:
                node = self._config_tree.get_node(setting_path)
                if node and node.value is not None:
                    current_values[setting_path] = node.value

            # Get all discovery settings
            for setting_path in DISCOVERY_SETTINGS:
                node = self._config_tree.get_node(setting_path)
                if node and node.value is not None:
                    current_values[setting_path] = node.value

        # Determine working_dir: check if .obra exists in cwd
        cwd = Path.cwd()
        working_dir: Path | None = None
        if (cwd / ".obra").exists():
            working_dir = cwd

        # Get LLM config for tooling discovery
        llm_config = self._local_config.get("llm", {})
        # Use orchestrator config if available
        if "orchestrator" in llm_config:
            llm_config = llm_config.get("orchestrator", {})

        # Create and mount the view
        view = ValidationToolingView(
            current_values=current_values,
            working_dir=working_dir,
            llm_config=llm_config if llm_config else None,
            classes="custom-view",
            id="validation-tooling-view",
        )
        main = self.query_one("#main", Container)
        main.mount(view)
        view.focus()

    def on_validation_tooling_view_changed(self, event: ValidationToolingView.Changed) -> None:
        """Handle Validation & Tooling view configuration changes.

        Updates the config tree with the new setting value.
        Handles nested tool command paths specially.
        """
        if not self._config_tree:
            return

        # Handle tool command paths specially (may not exist in tree)
        if event.path.startswith("fix.verification.tools."):
            # These are dynamic paths that may not exist in the tree
            # Track them in pending_changes directly
            if event.path not in self._config_tree.pending_changes:
                self._config_tree.pending_changes[event.path] = (None, event.value)
            else:
                original_old = self._config_tree.pending_changes[event.path][0]
                self._config_tree.pending_changes[event.path] = (
                    original_old,
                    event.value,
                )
        else:
            # Update the config value normally
            self._config_tree.set_value(event.path, event.value)

        # Update status bar to show pending changes
        self._update_status_bar()

    def _mount_debug_advanced_view(self) -> None:
        """Mount the Debug & Advanced view with current config values."""
        from obra.config.explorer.widgets.debug_advanced_view import ALL_DEBUG_SETTINGS

        current_values: dict[str, Any] = {}

        if self._config_tree:
            for setting_path in ALL_DEBUG_SETTINGS:
                node = self._config_tree.get_node(setting_path)
                if node and node.value is not None:
                    current_values[setting_path] = node.value

        view = DebugAdvancedView(
            current_values=current_values,
            classes="custom-view",
            id="debug-advanced-view",
        )
        main = self.query_one("#main", Container)
        main.mount(view)
        view.focus()

    def on_debug_advanced_view_changed(self, event: DebugAdvancedView.Changed) -> None:
        """Handle Debug & Advanced view configuration changes."""
        if not self._config_tree:
            return

        self._config_tree.set_value(event.path, event.value)
        self._update_status_bar()

    # --- Navigation Action Methods (keyboard shortcuts) ---

    def action_nav_domain(self) -> None:
        """Navigate to Domain view."""
        self._navigate_with_dirty_check("domain")

    def action_nav_simple_llm(self) -> None:
        """Navigate to Simple LLM view."""
        self._navigate_with_dirty_check("simple_llm")

    def action_nav_moderate_llm(self) -> None:
        """Navigate to Moderate LLM view."""
        self._navigate_with_dirty_check("moderate_llm")

    def action_nav_custom_llm(self) -> None:
        """Navigate to Custom LLM view."""
        self._navigate_with_dirty_check("custom_llm")

    def action_nav_runtime_cli(self) -> None:
        """Navigate to Runtime & CLI view."""
        self._navigate_with_dirty_check("runtime_cli")

    def action_nav_personas(self) -> None:
        """Navigate to Personas view."""
        self._navigate_with_dirty_check("personas")

    def action_nav_pipeline(self) -> None:
        """Navigate to Pipeline Options view."""
        self._navigate_with_dirty_check("pipeline")

    def action_nav_agents(self) -> None:
        """Navigate to Specialized Agents view."""
        self._navigate_with_dirty_check("agents")

    def action_nav_validation(self) -> None:
        """Navigate to Validation & Tooling view."""
        self._navigate_with_dirty_check("validation")

    def action_nav_debug_advanced(self) -> None:
        """Navigate to Debug & Advanced view."""
        self._navigate_with_dirty_check("debug_advanced")

    def action_nav_full_config(self) -> None:
        """Navigate to Full Config (tree view)."""
        self._navigate_with_dirty_check("full_config")

    def action_nav_menu(self) -> None:
        """Return to navigation menu."""
        self._navigate_with_dirty_check("menu")

    def action_back_or_quit(self) -> None:
        """Contextual back/quit handler (q key).

        - In subview: go back to menu (prompts if dirty)
        - On menu: quit the app

        This follows the Lazygit pattern where 'q' means "I'm done with this level".
        """
        if self._current_view == "menu":
            # On menu - quit the app
            self.exit()
        else:
            # In subview - check dirty state before leaving
            self._navigate_with_dirty_check(target="menu")

    def action_safe_back(self) -> None:
        """Safe back handler (Escape key) - never quits.

        Goes back to menu from any subview.
        On menu, does nothing (safe - won't accidentally quit).
        """
        if self._current_view != "menu":
            self._navigate_with_dirty_check(target="menu")

    def _get_current_view_widget(self) -> SaveableViewMixin | None:
        """Get the current view widget if it supports save/discard.

        Returns:
            The current view widget if it implements SaveableViewMixin, None otherwise.
        """
        return self._dirty_state_controller.get_current_view_widget()

    def _navigate_with_dirty_check(self, target: str) -> None:
        """Navigate to target, prompting if current view is dirty.

        Args:
            target: Navigation target ('menu' or a view name)
        """
        self._dirty_state_controller.navigate_with_dirty_check(target)

    def on_tree_node_highlighted(self, event: Tree.NodeHighlighted) -> None:
        """Update description panel when tree selection changes."""
        self._tree_controller.on_tree_node_highlighted(event)

    def on_config_tree_view_value_changed(self, _event: ConfigTreeView.ValueChanged) -> None:
        """Update status bar when a config value changes."""
        self._update_status_bar()

    def _build_view_tree(self) -> ConfigTree:
        return self._tree_controller.build_view_tree()

    def on_config_tree_view_edit_requested(self, event: ConfigTreeView.EditRequested) -> None:
        """Open edit modal when a non-boolean node is selected."""
        self._open_edit_modal(event.node)

    def _open_edit_modal(self, node: Any) -> None:
        """Open the edit modal for a config node.

        Args:
            node: ConfigNode to edit
        """
        self._tree_controller.open_edit_modal(node)

    def _auto_update_tiers_for_provider(self, provider_path: str, new_provider: str) -> None:
        """Auto-update tier models and git settings when role provider changes.

        When a user changes a role's provider, automatically update the tier models
        (fast/medium/high) to match the new provider's defaults.

        For Codex-backed providers (OpenAI and Ollama local-provider mode):
        auto-enable llm.git.skip_check for Codex trust compatibility.

        Args:
            provider_path: Path to the role provider field (e.g., "llm.orchestrator.provider")
            new_provider: New provider value (e.g., "openai")
        """
        if not self._config_tree:
            return

        # Import here to avoid circular dependency
        from obra.config.llm_compat import PROVIDER_TIER_DEFAULTS

        # Get the provider's default tier models
        tier_defaults = PROVIDER_TIER_DEFAULTS.get(new_provider, {})
        if not tier_defaults:
            return

        # Determine the tier path prefix from role path
        # e.g., "llm.orchestrator.provider" -> "llm.orchestrator.tiers"
        role_path = provider_path.rsplit(".provider", 1)[0]
        tier_section_path = f"{role_path}.tiers"

        # Update fast/medium/high to the provider's defaults
        changes_made = []
        for tier_name, default_model in tier_defaults.items():
            tier_path = f"{tier_section_path}.{tier_name}"
            # Only update if the node exists in the tree
            tier_node = self._config_tree.get_node(tier_path)
            if tier_node:
                self._config_tree.set_value(tier_path, default_model)
                changes_made.append(f"{tier_name}={default_model}")

        # Notify user about the auto-update
        if changes_made:
            provider_display = new_provider.capitalize()
            tier_list = ", ".join(changes_made)
            section_name = "orchestrator" if "orchestrator" in role_path else "implementation"
            self.notify(
                f"Updated {section_name} tiers to match {provider_display}: {tier_list}",
                severity="information",
                timeout=5,
            )

        # Auto-enable Codex compatibility flags.
        # This "heals" the config when switching to a codex-backed provider
        # and aligns with runtime enforcement.
        if new_provider in ("openai", "ollama"):
            git_skip_node = self._config_tree.get_node("llm.git.skip_check")
            if git_skip_node and git_skip_node.value is not True:
                self._config_tree.set_value("llm.git.skip_check", True)
            approval_node = self._config_tree.get_node("llm.codex.approval_mode")
            if approval_node and approval_node.value != "full-auto":
                self._config_tree.set_value("llm.codex.approval_mode", "full-auto")
            sandbox_node = self._config_tree.get_node("llm.codex.bypass_sandbox")
            if sandbox_node and sandbox_node.value is not True:
                self._config_tree.set_value("llm.codex.bypass_sandbox", True)
            provider_display = "OpenAI" if new_provider == "openai" else "Ollama"
            self.notify(
                f"{provider_display} selected: forcing git.skip_check, "
                "codex.approval_mode=full-auto, and codex.bypass_sandbox=true "
                "for Codex CLI compatibility.",
                severity="warning",
                timeout=8,
            )

    def _update_status_bar(self) -> None:
        """Update the status bar with current pending changes, domain, and persona."""
        if self._config_tree is None:
            return

        status_bar = self.query_one("#status", StatusBar)

        # Detect current persona and domain
        persona = self._detect_active_persona()
        domain = self._get_active_domain()

        status_bar.update_status(
            pending_count=self._config_tree.pending_count,
            preset=persona,
            connected=self._connected,
            view_mode=self._view_mode,
            tag_filter=self._active_tag_filter,
            persona=persona,
            domain=domain,
        )

    def _get_active_domain(self) -> str:
        """Return the currently configured domain identifier."""
        if self._config_tree is None:
            return "software"

        domain_node = self._config_tree.get_node("orchestration.domain")
        if domain_node and domain_node.value:
            return str(domain_node.value)
        return "software"

    def _detect_active_persona(self) -> str:
        """Detect which persona matches the current configuration.

        Returns:
            Persona name if matched, 'Custom' if no match.
        """
        if self._config_tree is None:
            return "Custom"

        from .widgets.preset_picker import detect_active_persona

        # Get current provider
        provider = "anthropic"
        provider_node = self._config_tree.get_node("llm.orchestrator.provider")
        if provider_node and provider_node.value:
            provider = provider_node.value

        # Collect current feature values
        current_features: dict[str, Any] = {}
        feature_paths = [
            "planning.scaffolded.enabled",
            "planning.scaffolded.always_on",
            "review.agents.max_workers",
            "features.quality_automation.agents.rca_agent.enabled",
            "features.quality_automation.agents.security_audit.enabled",
        ]
        for path in feature_paths:
            node = self._config_tree.get_node(path)
            if node and node.value is not None:
                current_features[path] = node.value

        # Collect current role model assignments
        current_roles: dict[str, str] = {}
        role_names = ["derive", "examine", "revise", "execute", "fix", "review"]
        for role in role_names:
            node = self._config_tree.get_node(f"llm.roles.{role}")
            if node and node.value:
                if isinstance(node.value, str):
                    current_roles[role] = node.value
                elif isinstance(node.value, dict) and "model" in node.value:
                    current_roles[role] = node.value["model"]

        return detect_active_persona(current_features, current_roles, provider)

    async def action_quit(self) -> None:
        """Quit the application, checking for unsaved changes."""
        await self._dirty_state_controller.action_quit()

    def _show_unsaved_changes_modal(self) -> None:
        """Show the unsaved changes modal and handle the result."""
        self._dirty_state_controller.show_unsaved_changes_modal()

    def action_save(self) -> None:
        """Save current view's changes to config.

        Per-screen save: only saves changes made in the current menu screen.
        Shows a preview modal before saving to let user review changes.
        """
        self._save_controller.action_save()

    def _save_full_config(self) -> None:
        """Save all pending changes in full config view (legacy global save)."""
        self._save_controller.save_full_config()

    def _save_current_view(self) -> None:
        """Save only the current view's changes."""
        self._save_controller.save_current_view()

    def _perform_save(self) -> None:
        """Actually perform the save operation after user confirms."""
        self._save_controller.perform_save()

    def _save_local_changes(self, changes: dict[str, Any]) -> None:
        """Save local config changes to ~/.obra/config-layers/01-user.yaml.

        Args:
            changes: Dictionary of path -> new_value pairs

        Raises:
            Exception: If save fails
        """
        self._save_controller.save_local_changes(changes)

    def _set_nested_value(self, d: dict[str, Any], path: str, value: Any) -> None:
        """Set a value in a nested dictionary using dot-notation path.

        Args:
            d: Dictionary to modify
            path: Dot-notation path like "llm.orchestrator.provider"
            value: Value to set
        """
        self._save_controller._set_nested_value(d, path, value)

    def _save_server_changes(self, changes: dict[str, Any]) -> None:
        """Save server config changes via API client.

        Args:
            changes: Dictionary of path -> new_value pairs

        Raises:
            RuntimeError: If no API client configured
            Exception: If API call fails
        """
        self._save_controller.save_server_changes(changes)

    def _set_offline_mode(self) -> None:
        """Switch to offline mode when server becomes unavailable."""
        self._save_controller.set_offline_mode()

    async def action_discard(self) -> None:
        """Discard all pending (unsaved) changes and reload from disk."""
        await self._dirty_state_controller.action_discard()

    async def action_reset_to_defaults(self) -> None:
        """Reset ALL settings to bundled defaults (preserves auth/account).

        Shows a confirmation dialog first since this is destructive.
        """
        await self._dirty_state_controller.action_reset_to_defaults()

    def _perform_reset_to_defaults(self) -> None:
        """Execute the actual reset after confirmation.

        Wipes all config settings but keeps:
        - Auth tokens (stays logged in)
        - Account info (email, uid, etc.)
        - Terms acceptance (no need to re-accept)

        Equivalent to 'obra config reset --yes' from CLI.
        """
        self._dirty_state_controller.perform_reset_to_defaults()

    def action_app_scroll(self, direction: str) -> None:
        """App-level scroll dispatcher for Page Up/Down, Home/End, Ctrl+D/U.

        Routes scroll commands to the active scrollable widget:
        - In Full Config (view 9): delegates to ConfigTreeView cursor movement
        - In form views: scrolls the active ScrollableContainer viewport

        Args:
            direction: One of page_up, page_down, half_page_up, half_page_down,
                       home, end.
        """
        from textual.containers import ScrollableContainer

        # If the tree view is focused, use its cursor-aware movement
        if self._current_view == "full_config":
            try:
                tree = self.query_one("#tree", ConfigTreeView)
                if tree.has_focus:
                    action_map = {
                        "page_down": tree.action_cursor_page_down,
                        "page_up": tree.action_cursor_page_up,
                        "half_page_down": tree.action_cursor_half_page_down,
                        "half_page_up": tree.action_cursor_half_page_up,
                        "home": tree.action_cursor_first,
                        "end": tree.action_cursor_last,
                    }
                    action = action_map.get(direction)
                    if action:
                        action()
                    return
            except Exception:
                pass

        # For menu / form views: find the visible ScrollableContainer and scroll it
        scroll_ids = ["#menu-scroll", "#content-scroll", "#phases-scroll"]
        for scroll_id in scroll_ids:
            try:
                container = self.query_one(scroll_id, ScrollableContainer)
                if container.display:
                    if direction == "page_down":
                        container.scroll_page_down(animate=False)
                    elif direction == "page_up":
                        container.scroll_page_up(animate=False)
                    elif direction == "half_page_down":
                        container.scroll_to(
                            y=container.scroll_y + container.scrollable_content_region.height // 2,
                            animate=False,
                        )
                    elif direction == "half_page_up":
                        container.scroll_to(
                            y=max(
                                0,
                                container.scroll_y
                                - container.scrollable_content_region.height // 2,
                            ),
                            animate=False,
                        )
                    elif direction == "home":
                        container.scroll_home(animate=False)
                    elif direction == "end":
                        container.scroll_end(animate=False)
                    return
            except Exception:
                pass

    def action_app_hscroll(self, direction: str) -> None:
        """App-level horizontal scroll dispatcher (Shift+Left / Shift+Right).

        Routes horizontal scroll to the active scrollable widget. Uses a step
        of 8 columns per keypress for comfortable navigation.

        Args:
            direction: 'left' or 'right'.
        """
        step = 8

        # Tree view: scroll the tree widget itself
        if self._current_view == "full_config":
            try:
                tree = self.query_one("#tree", ConfigTreeView)
                if direction == "right":
                    tree.scroll_to(x=tree.scroll_x + step, animate=False)
                else:
                    tree.scroll_to(x=max(0, tree.scroll_x - step), animate=False)
                return
            except Exception:
                pass

        # Menu / form views: scroll the visible ScrollableContainer
        scroll_ids = ["#menu-scroll", "#content-scroll", "#phases-scroll"]
        for scroll_id in scroll_ids:
            try:
                container = self.query_one(scroll_id, ScrollableContainer)
                if container.display:
                    if direction == "right":
                        container.scroll_to(x=container.scroll_x + step, animate=False)
                    else:
                        container.scroll_to(x=max(0, container.scroll_x - step), animate=False)
                    return
            except Exception:
                pass

    def action_search(self) -> None:
        """Enter search/filter mode."""
        search_bar = self.query_one("#search", SearchBar)
        search_bar.activate()

    def on_search_bar_search_applied(self, event: SearchBar.SearchApplied) -> None:
        """Handle search submission."""
        self._apply_search_filter(event.query)

    def on_search_bar_search_changed(self, event: SearchBar.SearchChanged) -> None:
        """Handle live search filtering as user types."""
        self._apply_search_filter(event.query)

    def on_search_bar_search_cleared(self, _event: SearchBar.SearchCleared) -> None:
        """Handle search cancellation - show all nodes."""
        self._clear_search_filter()
        # Re-focus tree
        try:
            tree_view = self.query_one("#tree", ConfigTreeView)
            tree_view.focus()
        except Exception:
            pass

    def on_quick_actions_bar_action_clicked(self, event: QuickActionsBar.ActionClicked) -> None:
        """Handle quick action button clicks."""
        if event.action == "llm":
            self.action_quick_llm()
        elif event.action == "preset":
            self.action_quick_preset()
        elif event.action == "features":
            self.action_quick_features()

    def _apply_search_filter(self, query: str) -> None:
        """Apply search filter to the tree.

        Args:
            query: Search query to filter by
        """
        self._tree_controller.apply_search_filter(query)

    def _clear_search_filter(self) -> None:
        """Clear search filter and restore normal view."""
        self._tree_controller.clear_search_filter()

    def action_toggle_view(self) -> None:
        """Toggle between tree and pipeline views."""
        if self._view_mode == "tree":
            self._view_mode = "pipeline"
        else:
            self._view_mode = "tree"
        self._config_tree = self._build_view_tree()
        self._rebuild_tree_view()
        self.notify(f"View: {self._view_mode}")

    def _rebuild_tree_view(self) -> None:
        """Rebuild the tree widget with the current view tree."""
        self._tree_controller.rebuild_tree_view()

    def action_help(self) -> None:
        """Show help overlay with all keybindings."""
        self.push_screen(HelpOverlay())

    def action_show_shortcuts(self) -> None:
        """Show keyboard shortcuts help."""
        shortcuts = (
            "Navigation Shortcuts (by complexity):\n"
            "  0: Domain        6: Pipeline\n"
            "  1: Personas      7: Agents\n"
            "  2: LLM Simple    8: Validation\n"
            "  3: LLM Moderate  9: Debug & Advanced\n"
            "  4: LLM Custom    f: Full Config\n"
            "  5: Runtime & CLI\n"
            "  m: Return to Menu\n"
            "\n"
            "Back/Quit:\n"
            "  q: Back (in view) / Quit (on menu)\n"
            "  Esc: Back (safe, never quits)\n"
            "\n"
            "Actions: R=Reset All  s=Save  u=Discard"
        )
        # Get notification timeout from config (CHORE-CONFIG-DEFAULTS-001-E3 S3)
        timeout_s = get_config_explorer_config()["notification_timeout_s"]
        self.notify(shortcuts, title="Keyboard Shortcuts", timeout=timeout_s)

    def action_quick_llm(self) -> None:
        """Launch LLM change wizard."""
        # Get current LLM settings from local config
        llm_config = self._local_config.get("llm", {})
        orchestrator = llm_config.get("orchestrator", {})
        implementation = llm_config.get("implementation", {})

        wizard = LLMWizard(
            current_orchestrator_provider=orchestrator.get("provider", "anthropic"),
            current_orchestrator_model=orchestrator.get("model", "default"),
            current_implementation_provider=implementation.get("provider", "anthropic"),
            current_implementation_model=implementation.get("model", "default"),
        )

        def handle_result(result: LLMSelection | None) -> None:
            if result is None:
                return  # User cancelled

            # Apply the changes to config tree
            if self._config_tree is None:
                return

            roles = ["orchestrator", "implementation"] if result.role == "both" else [result.role]

            for role in roles:
                provider_path = f"llm.{role}.provider"
                model_path = f"llm.{role}.model"

                # Set provider and model
                self._config_tree.set_value(provider_path, result.provider)
                self._config_tree.set_value(model_path, result.model)

                # Auto-update tiers and git settings for the new provider
                self._auto_update_tiers_for_provider(provider_path, result.provider)

            # Refresh the tree display
            tree_view = self.query_one("#tree", ConfigTreeView)
            tree_view.refresh_tree()

            # Update status bar
            self._update_status_bar()

            role_text = "orchestrator and implementation" if result.role == "both" else result.role
            self.notify(
                f"LLM changed: {role_text} -> {result.provider}/{result.model}",
                severity="information",
            )

        self.push_screen(wizard, handle_result)

    def _apply_persona_to_config(self, result: PresetSelection) -> int:
        """Apply persona LLM profiles and features to config tree.

        Cascades: Persona -> Menu 1 -> Menu 2 -> Menu 3 -> Menu 4

        Args:
            result: Persona selection result with features and llm_profiles

        Returns:
            Number of config changes made
        """
        if self._config_tree is None:
            return 0

        changes_made = 0

        # Apply LLM profiles
        if result.llm_profiles:
            from obra.config.llm_compat import PROVIDER_TIER_DEFAULTS

            orch = result.llm_profiles.get("orchestrator", {})
            impl = result.llm_profiles.get("implementation", {})

            # Set Menu 1 (Simple) config values and cascade to Menu 2 tiers
            for profile, cfg in [("orchestrator", orch), ("implementation", impl)]:
                if cfg:
                    # Get provider - use specified or keep current
                    provider = cfg.get("provider")
                    if not provider:
                        # Keep user's current provider
                        prov_node = self._config_tree.get_node(f"llm.{profile}.provider")
                        provider = prov_node.value if prov_node and prov_node.value else "anthropic"

                    model = cfg.get("model", "default")

                    # Resolve "tier:xxx" syntax to actual model name
                    if isinstance(model, str) and model.startswith("tier:"):
                        tier_name = model[5:]  # e.g., "fast" from "tier:fast"
                        tier_defaults = PROVIDER_TIER_DEFAULTS.get(provider, {})
                        model = (
                            tier_defaults.get(tier_name, "default") if tier_defaults else "default"
                        )

                    self._config_tree.set_value(f"llm.{profile}.provider", provider)
                    self._config_tree.set_value(f"llm.{profile}.model", model)
                    changes_made += 2
                    for tier in ("fast", "medium", "high"):
                        self._config_tree.set_value(f"llm.{profile}.tiers.{tier}", model)
                        changes_made += 1

            # CASCADE to Menu 3: Update CustomLLMView if mounted
            self._cascade_to_custom_view(
                orchestrator_provider=orch.get("provider") if orch else None,
                orchestrator_tiers=(
                    {t: orch.get("model", "default") for t in ("fast", "medium", "high")}
                    if orch
                    else None
                ),
                implementation_provider=impl.get("provider") if impl else None,
                implementation_tiers=(
                    {t: impl.get("model", "default") for t in ("fast", "medium", "high")}
                    if impl
                    else None
                ),
            )

        # Apply feature toggles
        # Note: feature paths in personas are the actual config paths (e.g., "automation_mode",
        # "planning.scaffolded.enabled") - do NOT prefix with "features."
        for feature_path, value in result.features.items():
            self._config_tree.set_value(feature_path, value)
            changes_made += 1

        return changes_made

    def action_quick_preset(self, from_navigation: bool = False) -> None:
        """Launch persona picker.

        Args:
            from_navigation: True if launched from nav menu (returns to menu on cancel)
        """
        from .widgets.preset_picker import DEFAULT_PERSONA_ID

        current_preset = get_preset_name(self._server_config) or DEFAULT_PERSONA_ID

        # Get current provider from config for tier resolution
        current_provider = "anthropic"
        if self._config_tree:
            provider_node = self._config_tree.get_node("llm.orchestrator.provider")
            if provider_node and provider_node.value:
                current_provider = provider_node.value

        picker = PresetPicker(
            current_preset=current_preset,
            current_provider=current_provider,
        )

        def handle_result(result: PresetSelection | None) -> None:
            # If launched from navigation and cancelled, return to menu
            if result is None:
                if from_navigation:
                    self._show_menu()
                return

            # Apply persona to config tree
            if self._config_tree is None:
                return

            changes_made = self._apply_persona_to_config(result)

            # Apply resolved LLM models to llm.roles.*
            for role, model in result.llm_models.items():
                role_path = f"llm.roles.{role}"
                self._config_tree.set_value(role_path, model)
                changes_made += 1

            # Refresh the tree display if currently showing full config
            if self._current_view == "full_config":
                try:
                    tree_view = self.query_one("#tree", ConfigTreeView)
                    tree_view.refresh_tree()
                except Exception:
                    pass

            # Update status bar
            self._update_status_bar()

            # Return to menu after applying persona if launched from navigation
            if from_navigation:
                self._show_menu()

            self.notify(
                f"Persona applied: {result.preset_name} ({changes_made} changes)",
                severity="information",
            )

        self.push_screen(picker, handle_result)

    def action_quick_features(self) -> None:
        """Jump to features section in the tree."""
        tree_view = self.query_one("#tree", ConfigTreeView)

        # Try to find the features section - could be under server config
        # Look for nodes with "features" in their path
        features_paths = [
            "features",
            "resolved.features",
            "Server Settings (SaaS).resolved.features",
            "Server Settings (SaaS).features",
        ]

        for path in features_paths:
            node = tree_view.find_node_by_path(path)
            if node is not None:
                # Expand and scroll to this node
                tree_view.scroll_to_path(path)
                self.notify("Jumped to Features section")
                return

        # Fallback: try to find any node with "features" in it
        if self._config_tree is not None:
            matches = find_nodes_by_path_pattern(self._config_tree.server_root, "features")
            if matches:
                first_match = matches[0]
                if first_match.path:
                    tree_view.scroll_to_path(first_match.path)
                    self.notify("Jumped to Features section")
                    return

        self.notify("Features section not found", severity="warning")


def run_explorer(
    local_config: dict[str, Any] | None = None,
    server_config: dict[str, Any] | None = None,
    initial_section: str | None = None,
    api_client: Any | None = None,
    origins: dict[str, str] | None = None,
    debug: bool = False,
    max_runtime_hours: float = 1.0,
) -> None:
    """Run the Configuration Explorer application.

    Args:
        local_config: Local configuration dictionary
        server_config: Server configuration dictionary
        initial_section: Section to expand initially
        api_client: API client for server operations
        origins: Origins map for layered config
        debug: Enable debug logging to ~/.obra/logs/config-explorer.log
        max_runtime_hours: Maximum runtime before auto-termination (default: 1 hour)
    """
    from obra.utils.process_guard import ProcessGuard

    # Acquire process guard to prevent duplicates and enable watchdogs
    guard = ProcessGuard(
        "config",
        max_runtime_hours=max_runtime_hours,
        cpu_threshold_percent=90.0,
        cpu_violation_minutes=5,
    )

    if not guard.acquire():
        import sys

        print("Config explorer already running. Kill it first or use: obra procs --kill")
        sys.exit(1)

    try:
        if debug:
            from obra.config.explorer.debug import enable_debug_logging

            session_id, log_file = enable_debug_logging()
            print(f"Debug session: {session_id}")
            print(f"Log file: {log_file}")
            print()

        app = ConfigExplorerApp(
            local_config=local_config,
            server_config=server_config,
            initial_section=initial_section,
            api_client=api_client,
            origins=origins,
        )
        app.run()
    finally:
        guard.release()


if __name__ == "__main__":
    # Allow running directly for testing
    run_explorer(
        local_config={
            "llm": {
                "orchestrator": {"provider": "anthropic", "model": "default"},
            }
        },
        server_config={
            "preset": "beta-tester",
            "resolved": {
                "features": {"budgets": {"enabled": True}},
            },
        },
    )
