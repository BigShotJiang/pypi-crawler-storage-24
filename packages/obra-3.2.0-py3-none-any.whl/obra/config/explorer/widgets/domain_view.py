"""Domain selection view for the Config Explorer.

Provides a high-level selector for the default orchestration domain.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from textual.app import ComposeResult
from textual.containers import ScrollableContainer, Vertical
from textual.message import Message
from textual.widgets import Select, Static

from obra.domains import get_available_domains, load_domain

from .navigation_menu import get_menu_info
from .saveable_view import SaveableViewMixin

DOMAIN_PATH = "orchestration.domain"


@dataclass(frozen=True)
class DomainOption:
    """Presentation metadata for one selectable domain."""

    domain_id: str
    display_name: str
    description: str
    example_objectives: tuple[str, ...]
    source_label: str
    available: bool
    error: str | None = None

    @property
    def select_label(self) -> str:
        """Return the user-facing dropdown label."""
        base = f"{self.display_name} ({self.domain_id})"
        if self.available:
            return base
        return f"{base} - unavailable"


def _build_domain_options(current_domain: str | None = None) -> list[DomainOption]:
    """Build selectable domain metadata from installed domains."""

    current = (current_domain or "").strip() or None
    options_by_id: dict[str, DomainOption] = {}

    for domain_id in get_available_domains():
        try:
            domain = load_domain(domain_id)
        except Exception as exc:
            options_by_id[domain_id] = DomainOption(
                domain_id=domain_id,
                display_name=domain_id.replace("_", " ").title(),
                description="Installed domain could not be loaded.",
                example_objectives=(),
                source_label="Installed domain",
                available=False,
                error=str(exc),
            )
            continue

        module_name = domain.__class__.__module__
        source_label = "Built-in" if module_name.startswith("obra.domains.") else "Installed plugin"
        options_by_id[domain_id] = DomainOption(
            domain_id=domain.name,
            display_name=domain.display_name,
            description=domain.description,
            example_objectives=tuple(domain.example_objectives),
            source_label=source_label,
            available=True,
        )

    if current and current not in options_by_id:
        options_by_id[current] = DomainOption(
            domain_id=current,
            display_name=current.replace("_", " ").title(),
            description="Configured domain is not currently installed.",
            example_objectives=(),
            source_label="Configured value",
            available=False,
            error=(
                "Install the matching domain package or choose one of the installed domains below."
            ),
        )

    ordered_ids = sorted(options_by_id)
    if current and current in options_by_id and not options_by_id[current].available:
        ordered_ids = [current] + [domain_id for domain_id in ordered_ids if domain_id != current]

    return [options_by_id[domain_id] for domain_id in ordered_ids]


class DomainView(SaveableViewMixin, Static):
    """Top-level domain selection view."""

    DEFAULT_CSS = """
    DomainView {
        width: 100%;
        height: 100%;
        padding: 1 2;
    }

    DomainView > Vertical {
        width: 100%;
        height: 100%;
    }

    DomainView #content-scroll {
        width: 100%;
        height: 1fr;
        min-height: 10;
    }

    DomainView .header {
        text-style: bold;
        text-align: center;
        margin-bottom: 1;
        width: 100%;
    }

    DomainView .description {
        color: $text-muted;
        text-align: center;
        margin-bottom: 2;
        width: 100%;
    }

    DomainView .section {
        width: 100%;
        height: auto;
        padding: 1;
        background: $surface;
        border: solid $primary-background;
    }

    DomainView .section-title {
        text-style: bold;
        margin-bottom: 1;
        color: $primary;
    }

    DomainView .setting-card {
        width: 100%;
        height: auto;
        margin-bottom: 1;
        padding: 1;
        border: solid $panel;
        background: $surface-darken-1;
    }

    DomainView .setting-label {
        text-style: bold;
        margin-bottom: 1;
    }

    DomainView .setting-description {
        color: $text-muted;
        margin-bottom: 1;
    }

    DomainView Select {
        width: 100%;
    }

    DomainView .details-box {
        width: 100%;
        height: auto;
        min-height: 10;
        padding: 1;
        background: $surface-darken-1;
        border: solid $primary-darken-2;
    }

    DomainView .details-title {
        text-style: bold;
        margin-bottom: 1;
    }

    DomainView .help-text {
        color: $text-muted;
        margin-top: 2;
        text-align: center;
        width: 100%;
    }
    """

    class Changed(Message):
        """Message emitted when the selected domain changes."""

        def __init__(self, path: str, value: str) -> None:
            super().__init__()
            self.path = path
            self.value = value

    def __init__(
        self,
        current_domain: str | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self._options = _build_domain_options(current_domain)
        if not self._options:
            fallback_domain = (current_domain or "software").strip() or "software"
            self._options = [
                DomainOption(
                    domain_id=fallback_domain,
                    display_name=fallback_domain.replace("_", " ").title(),
                    description="No installed domains were discovered.",
                    example_objectives=(),
                    source_label="Fallback",
                    available=False,
                    error="Install at least one domain plugin or restore bundled domains.",
                )
            ]
        self._option_map = {option.domain_id: option for option in self._options}
        self._selected_domain = self._resolve_initial_domain(current_domain)
        self._initializing = True
        self._snapshot_state()

    def _resolve_initial_domain(self, current_domain: str | None) -> str:
        current = (current_domain or "").strip()
        if current and current in self._option_map:
            return current
        if self._options:
            return self._options[0].domain_id
        return "software"

    def compose(self) -> ComposeResult:
        """Create the view content."""
        menu_info = get_menu_info("domain")
        with Vertical():
            yield Static(menu_info["label"], classes="header")
            yield Static(menu_info["subtitle"], classes="description")

            with ScrollableContainer(id="content-scroll"):
                with Vertical(classes="section"):
                    yield Static("Default Runtime Domain", classes="section-title")

                    with Vertical(classes="setting-card"):
                        yield Static("Configured Domain", classes="setting-label")
                        yield Static(
                            "Choose the default domain for new runs, derivations, and "
                            "workflow launches. Installed domains are discovered "
                            "dynamically from built-ins and domain plugins.",
                            classes="setting-description",
                        )
                        yield Select(
                            [(option.select_label, option.domain_id) for option in self._options],
                            value=self._selected_domain,
                            allow_blank=False,
                            id="domain-select",
                        )

                    with Vertical(classes="setting-card"):
                        yield Static("Selected Domain Details", classes="details-title")
                        yield Static("", id="domain-details", classes="details-box")

                yield Static(
                    "`--domain` still overrides this setting for a single run. "
                    "This screen sets the explicit configured default.",
                    classes="help-text",
                )

    def on_mount(self) -> None:
        """Finish initialization after widgets are mounted."""

        def finish_initialization() -> None:
            self._initializing = False
            self._update_details()
            self._snapshot_state()

        self.call_after_refresh(finish_initialization)

    def _get_saveable_state(self) -> dict[str, Any]:
        """Return state used for dirty tracking."""
        return {DOMAIN_PATH: self._selected_domain}

    def _restore_state(self, state: dict[str, Any]) -> None:
        """Restore state from snapshot."""
        restored_domain = str(state.get(DOMAIN_PATH, self._selected_domain))
        if restored_domain not in self._option_map:
            self._options = _build_domain_options(restored_domain)
            self._option_map = {option.domain_id: option for option in self._options}
        self._selected_domain = restored_domain
        self._sync_widgets()
        self._update_details()

    def _sync_widgets(self) -> None:
        """Sync select widget with internal state."""
        try:
            select = self.query_one("#domain-select", Select)
        except Exception:
            return

        select.set_options([(option.select_label, option.domain_id) for option in self._options])
        if self._selected_domain in self._option_map:
            select.value = self._selected_domain

    def _update_details(self) -> None:
        """Refresh the detail panel for the selected domain."""
        try:
            details = self.query_one("#domain-details", Static)
        except Exception:
            return

        option = self._option_map.get(self._selected_domain)
        if option is None:
            details.update("No installed domains were discovered.")
            return

        if not option.available:
            details.update(
                "\n".join(
                    [
                        f"Domain ID: {option.domain_id}",
                        "Status: unavailable",
                        f"Source: {option.source_label}",
                        option.description,
                        "",
                        option.error or "Choose an installed domain and save.",
                    ]
                )
            )
            return

        example_lines = option.example_objectives or ("No example objectives published.",)
        details.update(
            "\n".join(
                [
                    option.display_name,
                    f"Domain ID: {option.domain_id}",
                    f"Source: {option.source_label}",
                    option.description,
                    "",
                    "Example objectives:",
                    *[f"- {example}" for example in example_lines],
                ]
            )
        )

    def on_select_changed(self, event: Select.Changed) -> None:
        """Handle domain selection changes."""
        if self._initializing or event.select.id != "domain-select":
            return
        if event.value is Select.BLANK:
            return

        self._selected_domain = str(event.value)
        self._update_details()
        self.post_message(self.Changed(DOMAIN_PATH, self._selected_domain))
