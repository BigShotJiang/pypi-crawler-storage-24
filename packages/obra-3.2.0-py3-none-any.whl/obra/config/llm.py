"""LLM configuration resolution and CLI building for Obra.

Handles model validation, thinking level mapping, config resolution, and CLI argument
construction for all supported LLM providers (Anthropic, OpenAI, Google).

Example:
    from obra.config.llm import resolve_llm_config, build_llm_args

    config = resolve_llm_config("orchestrator", override_model="sonnet")
    args = build_llm_args(config, mode="text")
"""

import logging
from typing import Any

# --- Extracted sub-modules (REFACTOR-HIGH-PRIORITY-P10-001 Story 3) -----------
# Re-export all symbols that were moved so existing import paths continue to work.
from obra.config.llm_normalization import (
    DEFAULT_REASONING_LEVEL,
    DEFAULT_REASONING_SELECTION,
    DEFAULT_THINKING_BUDGET,
    THINKING_BUDGET_MAX,
    THINKING_BUDGET_MIN,
    _base_llm_defaults,
    _coerce_auth_method,
    _coerce_bool,
    _coerce_model,
    _coerce_optional_reasoning_level,
    _coerce_provider,
    _coerce_reasoning_level,
    _coerce_string_list,
    _coerce_thinking_budget,
    _get_env_tier_override,
    _normalize_reasoning_bounds,
    _normalize_reasoning_config,
    _normalize_role_config,
    _normalize_role_tiers,
    _normalize_tier_entry,
    _normalize_tiers,
    _normalized_llm_config,
)
from obra.config.provider_inference import (
    MODEL_PROVIDER_PATTERNS,
    MODEL_PROVIDER_PREFIXES,
    MODEL_SHORTCUTS,
    infer_provider_from_model,
    validate_model,
)
from obra.config.reasoning_selection import (
    REASONING_LEVEL_MAP,
    ReasoningSelection,
    _materialize_default_reasoning_level,
    get_anthropic_api_thinking_param,
    get_effective_reasoning_value,
    get_reasoning_level_notes,
    resolve_reasoning_selection,
)
from obra.model_registry import REASONING_LEVELS

from .loaders import (
    get_provider_tier_defaults,
    load_config,
    load_layered_config,
    load_llm_section,
    save_config,
)
from .providers import (
    DEFAULT_AUTH_METHOD,
    DEFAULT_MODEL,
    DEFAULT_PROVIDER,
    LLM_AUTH_METHODS,
    LLM_PROVIDERS,
)

# Module logger
logger = logging.getLogger(__name__)

# Backward-compatible deprecated constants (moved to llm_compat.py, S6.T2).
# Re-exported so ``from obra.config.llm import TIER_FALLBACKS`` still works.
from obra.config.llm_compat import (  # noqa: E402
    PROVIDER_TIER_DEFAULTS,
    ROLE_TIER_DEFAULTS,
    TIER_FALLBACKS,
    XHIGH_SUPPORTED_MODELS,
    _RuntimeRefreshDict,
)

TIER_NAMES: tuple[str, str, str] = ("fast", "medium", "high")

from obra.config.tier_resolution import (  # noqa: E402
    get_role_tier_default,
    update_role_tiers_for_provider,
)


def apply_provider_config(
    config: dict[str, Any],
    provider: str,
    *,
    model: str | None = None,
    auth_method: str = "oauth",
    roles: list[str] | None = None,
) -> tuple[dict[str, Any], list[str]]:
    """Apply provider selection to config — single codepath for setup, config CLI, and TUI.

    Merges provider settings into existing config (never replaces the llm section).
    Sets tiers to "default" (passthrough) so they resolve at runtime from
    ROLE_TIER_DEFAULTS for the current provider, making config resilient to
    subsequent provider changes via any codepath.

    Args:
        config: Full config dict (modified in place).
        provider: Provider name (anthropic, openai, google, ollama).
        model: Explicit model override. None means "default" (Let Obra choose).
        auth_method: Auth method (default: oauth).
        roles: Roles to update. None means both orchestrator and implementation.

    Returns:
        Tuple of (updated_config, notification_messages).

    Example:
        >>> config = load_config()
        >>> config, msgs = apply_provider_config(config, "openai")
        >>> save_config(config)
    """
    roles_to_update = roles or ["orchestrator", "implementation"]
    effective_model = model if model else "default"
    notifications: list[str] = []

    # Ensure llm section exists
    if "llm" not in config or not isinstance(config.get("llm"), dict):
        config["llm"] = {}

    for role in roles_to_update:
        # Ensure role section exists
        if role not in config["llm"] or not isinstance(config["llm"].get(role), dict):
            config["llm"][role] = {}

        role_section = config["llm"][role]
        role_section["provider"] = provider
        role_section["auth_method"] = auth_method
        role_section["model"] = effective_model
        # Use "default" tiers — resolved at runtime from ROLE_TIER_DEFAULTS
        # for the current provider. This avoids stale tier models when the
        # provider is later changed via a different codepath (TUI, CLI, etc).
        role_section["tiers"] = {"fast": "default", "medium": "default", "high": "default"}

        provider_display = provider.capitalize()
        notifications.append(f"Set {role} to {provider_display} (model: {effective_model})")

    # OpenAI requires git.skip_check
    if provider == "openai":
        llm_section = config["llm"]
        if "git" not in llm_section or not isinstance(llm_section.get("git"), dict):
            llm_section["git"] = {}
        llm_section["git"]["skip_check"] = True

    return config, notifications


def resolve_llm_config(
    role: str,
    override_provider: str | None = None,
    override_model: str | None = None,
    override_auth_method: str | None = None,
    override_reasoning_level: str | None = None,
    override_skip_git_check: bool | None = None,
    override_auto_init_git: bool | None = None,
) -> dict[str, Any]:
    """Resolve LLM configuration for a role with optional overrides.

    Resolution order (highest to lowest priority):
    1. Session overrides (passed as arguments, e.g., CLI flags)
    2. Layered config (user, project, session)
    3. Defaults (anthropic, oauth, default, medium)

    Args:
        role: "orchestrator" or "implementation"
        override_provider: Optional provider override (session-only)
        override_model: Optional model override (session-only)
        override_auth_method: Optional auth method override (session-only)
        override_reasoning_level: Optional thinking level override (session-only)
        override_skip_git_check: Optional git skip check override (CLI flag)
        override_auto_init_git: Optional git auto init override (CLI flag)

    Returns:
        Resolved config dict with provider, auth_method, model, reasoning_level keys
        and optional parse retry controls.
    """
    from obra.config.llm_resolution import LLMConfigResolver

    return LLMConfigResolver().resolve(
        role,
        override_provider=override_provider,
        override_model=override_model,
        override_auth_method=override_auth_method,
        override_reasoning_level=override_reasoning_level,
        override_skip_git_check=override_skip_git_check,
        override_auto_init_git=override_auto_init_git,
    )


def get_llm_config() -> dict[str, Any]:
    """Get LLM configuration from config file.

    Returns:
        Normalized LLM config with role defaults and optional tiers:
        {
            "provider": "anthropic",
            "auth_method": "oauth",
            "model": "default",
            "reasoning_level": "medium",
            "orchestrator": {...},
            "implementation": {...},
            "tiers": {
                "fast": {
                    "provider": "...",
                    "auth_method": "...",
                    "model": "...",
                    "reasoning_level": "...",
                }
            }
        }
    """
    config, _, _ = load_layered_config()
    llm_section = load_llm_section(config)
    if not llm_section:
        return _normalized_llm_config({})
    return _normalized_llm_config(llm_section)


from obra.config.llm_cli_builder import build_llm_args, get_llm_cli  # noqa: E402,F401
from obra.config.llm_display import get_llm_display, get_reasoning_keyword  # noqa: E402,F401
from obra.config.tier_resolution import resolve_tier_config  # noqa: E402,F401


def set_llm_config(
    role: str,  # "orchestrator" or "implementation"
    provider: str,
    auth_method: str,
    model: str = "default",
    reasoning_level: str = "medium",
) -> str:
    """Set LLM configuration for a specific role.

    Thin wrapper around apply_provider_config for backward compatibility.

    Args:
        role: "orchestrator" or "implementation"
        provider: LLM provider (anthropic, openai, google)
        auth_method: Auth method (oauth, api_key)
        model: Model to use (default recommended for oauth)
        reasoning_level: Abstract reasoning level (off, low, medium, high, extra high, maximum)

    Returns:
        Notification message (joined), empty string if none.
    """
    config = load_config()
    config, notifications = apply_provider_config(
        config,
        provider,
        model=model if model != "default" else None,
        auth_method=auth_method,
        roles=[role],
    )
    save_config(config)
    return "; ".join(notifications)


def get_llm_command() -> tuple[str, list[str]]:
    """Get the implementation LLM command and arguments.

    Returns:
        Tuple of (command, args) for subprocess execution.
        Uses provider-specific CLI:
        - Anthropic: claude (Claude Code CLI)
        - Google: gemini (Gemini CLI)
        - OpenAI: codex (OpenAI Codex CLI)

    Note:
        Consider using resolve_llm_config() + build_llm_args() for more control.
    """
    llm_config = get_llm_config()
    impl_config = llm_config.get("implementation", {})

    provider = impl_config.get("provider", DEFAULT_PROVIDER)
    model = impl_config.get("model", DEFAULT_MODEL)

    cli = get_llm_cli(provider)
    args = build_llm_args({"provider": provider, "model": model})

    return cli, args


# --- Role-based LLM configuration (moved to llm_resolution.py, P24-001) ---
# Re-export all symbols so existing import paths continue to work.
from obra.config.llm_resolution import (  # noqa: E402,F401
    DEFAULT_ROLE_MAPPINGS,
    HANDLER_ROLES,
    RoleConfigResolver,
    _get_role_entry,
    _normalize_role_key,
    _resolve_action_profile,
    resolve_action_llm_config,
)


def resolve_role_llm_config(
    role: str,
    override_provider: str | None = None,
    override_model: str | None = None,
    override_reasoning_level: str | None = None,
) -> dict[str, Any]:
    """Resolve LLM config for a handler role (derive, examine, execute, etc.).

    This function provides indirection between handlers and LLM settings,
    allowing different handlers to use different models based on configuration.

    Resolution order:
    1. llm.roles.<role> - explicit role configuration
    2. llm.profiles.<profile> - if role references a profile
    3. Default mapping (derive->orchestrator, execute->implementation)
    4. Top-level llm.* settings as final fallback

    Args:
        role: Handler role name (derive, examine, revise, execute, fix, review)
        override_provider: Optional provider override (session-only)
        override_model: Optional model override (session-only)
        override_reasoning_level: Optional thinking level override (session-only)

    Returns:
        Resolved config dict with provider, auth_method, model, reasoning_level keys

    See:
        ADR-069: Role-Based LLM Configuration
    """
    return RoleConfigResolver().resolve(
        role,
        override_provider=override_provider,
        override_model=override_model,
        override_reasoning_level=override_reasoning_level,
    )


# Public exports
__all__ = [
    "DEFAULT_ROLE_MAPPINGS",
    "DEFAULT_THINKING_BUDGET",
    # Reasoning level constants (ADR-073)
    "DEFAULT_REASONING_SELECTION",
    "DEFAULT_REASONING_LEVEL",
    # Role-based configuration (ADR-061)
    "HANDLER_ROLES",
    "MODEL_PROVIDER_PATTERNS",
    "MODEL_PROVIDER_PREFIXES",
    # Model constants
    "MODEL_SHORTCUTS",
    "PROVIDER_TIER_DEFAULTS",
    "ROLE_TIER_DEFAULTS",
    "THINKING_BUDGET_MAX",
    # Thinking budget constants (Anthropic-specific, not renamed)
    "THINKING_BUDGET_MIN",
    "REASONING_LEVELS",
    "REASONING_LEVEL_MAP",
    "TIER_FALLBACKS",
    "TIER_NAMES",
    "XHIGH_SUPPORTED_MODELS",
    "ReasoningSelection",
    "build_llm_args",
    "get_anthropic_api_thinking_param",
    "get_effective_reasoning_value",
    "get_llm_cli",
    "get_llm_command",
    "get_llm_config",
    "get_role_tier_default",
    "get_llm_display",
    "get_provider_tier_defaults",
    # CLI building
    "get_reasoning_keyword",
    # Reasoning level functions
    "get_reasoning_level_notes",
    # Model inference
    "infer_provider_from_model",
    # Config resolution
    "resolve_llm_config",
    "resolve_action_llm_config",
    "resolve_reasoning_selection",
    "resolve_role_llm_config",
    "resolve_tier_config",
    "apply_provider_config",
    "set_llm_config",
    "update_role_tiers_for_provider",
    # Model validation
    "validate_model",
]
