"""Review, convergence, and quality getter owners."""

from __future__ import annotations

from typing import Any

from obra.exceptions import ConfigurationError

from .. import _core, _defaults
from .._defaults import (
    DEFAULT_REVIEW_DEFAULT_INITIAL_QUALITY_SCORE,
    DEFAULT_REVIEW_FAIL_ADJUSTMENT,
    DEFAULT_REVIEW_FLAG_PENALTY_CAP,
    DEFAULT_REVIEW_PASS_ADJUSTMENT,
    DEFAULT_REVIEW_PASS_RATING_THRESHOLD,
    DEFAULT_REVIEW_REDERIVATION_THRESHOLD,
)
from ._helpers import (
    _get_nested_config_dict,
    _resolve_config_value,
    coerce_float_with_default,
    resolve_bool_config,
    resolve_float_config,
    resolve_int_config,
)

__all__ = [
    "get_convergence_fresh_fix_enabled",
    "get_convergence_identity_overlap_threshold",
    "get_convergence_max_template_failure_cycles",
    "get_convergence_stale_cycles_for_escalate",
    "get_convergence_stale_cycles_for_fresh_fix",
    "get_escalation_continue_iteration_reset",
    "get_generated_plan_quality_threshold",
    "get_quality_config",
    "get_quality_policy_mode",
    "get_quality_threshold",
    "get_review_blocking_low_priority_strict",
    "get_review_complexity_medium",
    "get_review_complexity_simple",
    "get_review_feedback_config",
    "get_review_flag_weights",
    "get_review_loop_exit_policy_enabled",
    "get_review_loop_exit_policy_max_non_critical_review_cycles",
    "get_review_loop_exit_policy_require_no_new_critical",
    "get_review_loop_exit_policy_require_required_checks_pass",
    "get_review_loop_exit_policy_require_threshold_met",
    "get_review_rating_adjustments",
    "get_review_stabilization_cycle_threshold",
    "get_revision_plan_shrinkage_block_threshold",
    "get_revision_plan_shrinkage_warning_threshold",
]

_CONVERGENCE = "Convergence setting"


# ---------------------------------------------------------------------------
# Scalar getters — refactored to use typed resolvers from _helpers.
# ---------------------------------------------------------------------------


def get_quality_threshold() -> float:
    """Get standard quality threshold for user-provided plans.

    Resolution order:
    1. OBRA_QUALITY_THRESHOLD environment variable
    2. quality.threshold from config file
    3. DEFAULT_QUALITY_THRESHOLD constant (0.6)

    Returns:
        Quality threshold as float (0.0 to 1.0)
    """
    return resolve_float_config(
        env_key="OBRA_QUALITY_THRESHOLD",
        config_path="quality.threshold",
        default=_defaults.DEFAULT_QUALITY_THRESHOLD,
        min_val=0.0,
        max_val=1.0,
    )


def get_generated_plan_quality_threshold() -> float:
    """Get relaxed quality threshold for Obra-generated plans.

    Resolution order:
    1. OBRA_GENERATED_PLAN_QUALITY_THRESHOLD environment variable
    2. quality.generated_plan_threshold from config file
    3. DEFAULT_GENERATED_PLAN_QUALITY_THRESHOLD constant (0.4)

    Returns:
        Quality threshold as float (0.0 to 1.0)
    """
    return resolve_float_config(
        env_key="OBRA_GENERATED_PLAN_QUALITY_THRESHOLD",
        config_path="quality.generated_plan_threshold",
        default=_defaults.DEFAULT_GENERATED_PLAN_QUALITY_THRESHOLD,
        min_val=0.0,
        max_val=1.0,
    )


def get_quality_policy_mode() -> str:
    """Get quality policy mode override.

    Resolution order:
    1. OBRA_QUALITY_POLICY_MODE environment variable
    2. orchestration.quality.policy_mode from config file
    3. DEFAULT_QUALITY_POLICY_MODE constant ("auto")

    Returns:
        Quality policy mode string: "auto", "fast", "medium", or "high"

    Raises:
        ConfigurationError: If the value is not in the allowed set
    """
    value = _resolve_config_value(
        env_key="OBRA_QUALITY_POLICY_MODE",
        config_path="orchestration.quality.policy_mode",
        default=_defaults.DEFAULT_QUALITY_POLICY_MODE,
    )
    mode_str = str(value).strip().lower()
    if mode_str not in _defaults.VALID_QUALITY_POLICY_MODES:
        raise ConfigurationError(
            f"Invalid quality policy mode='{value}'. "
            f"Allowed values: {sorted(_defaults.VALID_QUALITY_POLICY_MODES)}"
        )
    return mode_str


def get_escalation_continue_iteration_reset() -> int:
    """Get iteration value to reset to when user selects 'continue fixing' after escalation.

    Resolution order:
    1. OBRA_ESCALATION_CONTINUE_ITERATION_RESET
    2. refinement.escalation_continue_iteration_reset
    3. Default: 0
    """
    return resolve_int_config(
        env_key="OBRA_ESCALATION_CONTINUE_ITERATION_RESET",
        config_path="refinement.escalation_continue_iteration_reset",
        default=0,
        min_val=0,
        include_defaults=True,
    )


def get_convergence_max_template_failure_cycles() -> int:
    """Get max consecutive template-failure cycles before counting toward stale_cycles.

    Resolution order:
    1. OBRA_CONVERGENCE_MAX_TEMPLATE_FAILURE_CYCLES
    2. review.convergence.max_template_failure_cycles
    3. Default: 3
    """
    return resolve_int_config(
        env_key="OBRA_CONVERGENCE_MAX_TEMPLATE_FAILURE_CYCLES",
        config_path="review.convergence.max_template_failure_cycles",
        default=3,
        min_val=1,
        include_defaults=True,
    )


# ---------------------------------------------------------------------------
# Remaining scalar getters — refactored to use typed resolvers from _helpers.
# ---------------------------------------------------------------------------


def get_convergence_fresh_fix_enabled() -> bool:
    """Get review convergence fresh-fix toggle.

    Resolution order:
    1. OBRA_CONVERGENCE_FRESH_FIX_ENABLED
    2. review.convergence.fresh_fix_enabled
    3. Fail fast if missing/invalid
    """
    return resolve_bool_config(
        env_key="OBRA_CONVERGENCE_FRESH_FIX_ENABLED",
        config_path="review.convergence.fresh_fix_enabled",
        default=None,
        include_defaults=True,
        label=_CONVERGENCE,
    )


def get_convergence_stale_cycles_for_fresh_fix() -> int:
    """Get stale cycle threshold before triggering fresh-fix.

    Resolution order:
    1. OBRA_CONVERGENCE_STALE_CYCLES_FOR_FRESH_FIX
    2. review.convergence.stale_cycles_for_fresh_fix
    3. Fail fast if missing/invalid
    """
    return resolve_int_config(
        env_key="OBRA_CONVERGENCE_STALE_CYCLES_FOR_FRESH_FIX",
        config_path="review.convergence.stale_cycles_for_fresh_fix",
        default=None,
        min_val=1,
        fail_fast=True,
        include_defaults=True,
        label=_CONVERGENCE,
    )


def get_convergence_stale_cycles_for_escalate() -> int:
    """Get stale cycle threshold before convergence escalation.

    Resolution order:
    1. OBRA_CONVERGENCE_STALE_CYCLES_FOR_ESCALATE
    2. review.convergence.stale_cycles_for_escalate
    3. Fail fast if missing/invalid
    """
    return resolve_int_config(
        env_key="OBRA_CONVERGENCE_STALE_CYCLES_FOR_ESCALATE",
        config_path="review.convergence.stale_cycles_for_escalate",
        default=None,
        min_val=1,
        fail_fast=True,
        include_defaults=True,
        label=_CONVERGENCE,
    )


def get_convergence_identity_overlap_threshold() -> float:
    """Get identity-overlap threshold for convergence divergence gating.

    Resolution order:
    1. OBRA_CONVERGENCE_IDENTITY_OVERLAP_THRESHOLD
    2. review.convergence.identity_overlap_threshold
    3. Fail fast if missing/invalid
    """
    return resolve_float_config(
        env_key="OBRA_CONVERGENCE_IDENTITY_OVERLAP_THRESHOLD",
        config_path="review.convergence.identity_overlap_threshold",
        default=None,
        min_val=0.0,
        max_val=1.0,
        fail_fast=True,
        include_defaults=True,
        label=_CONVERGENCE,
    )


def get_review_blocking_low_priority_strict() -> bool:
    """Get strict low-priority blocking policy toggle for review scorecards."""
    return resolve_bool_config(
        env_key="OBRA_REVIEW_LOW_PRIORITY_STRICT",
        config_path="review.blocking_policy.low_priority_strict",
        default=_defaults.DEFAULT_REVIEW_BLOCKING_LOW_PRIORITY_STRICT,
        fail_fast=True,
        include_defaults=True,
    )


def get_review_stabilization_cycle_threshold() -> int:
    """Get the fix-cycle threshold for P2/P3 deferral during stabilization.

    After this many review->fix cycles, P2/P3 issues are deferred from FIX
    payload so the loop focuses on P0/P1 convergence.

    Config path: review.stabilization.cycle_threshold
    Env override: OBRA_REVIEW_STABILIZATION_CYCLE_THRESHOLD
    Default: 1 (defer P2/P3 after the first fix cycle)
    """
    return resolve_int_config(
        env_key="OBRA_REVIEW_STABILIZATION_CYCLE_THRESHOLD",
        config_path="review.stabilization.cycle_threshold",
        default=_defaults.DEFAULT_REVIEW_STABILIZATION_CYCLE_THRESHOLD,
        min_val=0,
        fail_fast=True,
        include_defaults=True,
    )


def get_review_loop_exit_policy_enabled() -> bool:
    """Get review.loop_exit_policy.enabled."""
    return resolve_bool_config(
        env_key="OBRA_REVIEW_LOOP_EXIT_POLICY_ENABLED",
        config_path="review.loop_exit_policy.enabled",
        default=_defaults.DEFAULT_REVIEW_LOOP_EXIT_POLICY_ENABLED,
        fail_fast=True,
        include_defaults=True,
    )


def get_review_loop_exit_policy_max_non_critical_review_cycles() -> int:
    """Get review.loop_exit_policy.max_non_critical_review_cycles."""
    return resolve_int_config(
        env_key="OBRA_REVIEW_LOOP_EXIT_POLICY_MAX_NON_CRITICAL_REVIEW_CYCLES",
        config_path="review.loop_exit_policy.max_non_critical_review_cycles",
        default=_defaults.DEFAULT_REVIEW_LOOP_EXIT_POLICY_MAX_NON_CRITICAL_REVIEW_CYCLES,
        min_val=1,
        fail_fast=True,
        include_defaults=True,
    )


def get_review_loop_exit_policy_require_threshold_met() -> bool:
    """Get review.loop_exit_policy.require_threshold_met."""
    return resolve_bool_config(
        env_key=None,
        config_path="review.loop_exit_policy.require_threshold_met",
        default=_defaults.DEFAULT_REVIEW_LOOP_EXIT_POLICY_REQUIRE_THRESHOLD_MET,
        fail_fast=True,
        include_defaults=True,
    )


def get_review_loop_exit_policy_require_required_checks_pass() -> bool:
    """Get review.loop_exit_policy.require_required_checks_pass."""
    return resolve_bool_config(
        env_key=None,
        config_path="review.loop_exit_policy.require_required_checks_pass",
        default=_defaults.DEFAULT_REVIEW_LOOP_EXIT_POLICY_REQUIRE_REQUIRED_CHECKS_PASS,
        fail_fast=True,
        include_defaults=True,
    )


def get_review_loop_exit_policy_require_no_new_critical() -> bool:
    """Get review.loop_exit_policy.require_no_new_critical."""
    return resolve_bool_config(
        env_key=None,
        config_path="review.loop_exit_policy.require_no_new_critical",
        default=_defaults.DEFAULT_REVIEW_LOOP_EXIT_POLICY_REQUIRE_NO_NEW_CRITICAL,
        fail_fast=True,
        include_defaults=True,
    )


def get_revision_plan_shrinkage_warning_threshold() -> float:
    """Get review.revision_integrity.plan_shrinkage_warning_threshold."""
    return resolve_float_config(
        env_key="OBRA_REVISION_PLAN_SHRINKAGE_WARNING_THRESHOLD",
        config_path="review.revision_integrity.plan_shrinkage_warning_threshold",
        default=_defaults.DEFAULT_REVISION_PLAN_SHRINKAGE_WARNING_THRESHOLD,
        min_val=0.0,
        max_val=1.0,
        fail_fast=True,
        include_defaults=True,
    )


def get_revision_plan_shrinkage_block_threshold() -> float:
    """Get review.revision_integrity.plan_shrinkage_block_threshold."""
    # Cross-field validation: block threshold must be <= warning threshold.
    # Use resolve_float_config for the base lookup, then apply the cross-field
    # constraint that cannot be expressed as a static range.
    value = resolve_float_config(
        env_key="OBRA_REVISION_PLAN_SHRINKAGE_BLOCK_THRESHOLD",
        config_path="review.revision_integrity.plan_shrinkage_block_threshold",
        default=_defaults.DEFAULT_REVISION_PLAN_SHRINKAGE_BLOCK_THRESHOLD,
        min_val=0.0,
        max_val=1.0,
        fail_fast=True,
        include_defaults=True,
    )
    warning_threshold = get_revision_plan_shrinkage_warning_threshold()
    if value > warning_threshold:
        raise ConfigurationError(
            "review.revision_integrity.plan_shrinkage_block_threshold "
            f"must be between 0 and warning threshold {warning_threshold} (got {value})"
        )
    return value


# ---------------------------------------------------------------------------
# Multi-key dict return getters -- not suitable for typed resolvers.
# ---------------------------------------------------------------------------


def get_review_complexity_simple() -> dict:
    """Get simple review complexity thresholds.

    Returns:
        Dict with max_words, max_files, max_lines keys
    """
    # Multi-key dict return -- not suitable for typed resolvers
    defaults = _defaults.DEFAULT_REVIEW_COMPLEXITY_SIMPLE
    config, _, _ = _core.load_layered_config()
    leaf = _get_nested_config_dict(config, ["review", "complexity", "simple"], defaults)
    return {key: leaf.get(key, defaults[key]) for key in defaults}


def get_review_complexity_medium() -> dict:
    """Get medium review complexity thresholds.

    Returns:
        Dict with max_files, max_lines keys
    """
    # Multi-key dict return -- not suitable for typed resolvers
    defaults = _defaults.DEFAULT_REVIEW_COMPLEXITY_MEDIUM
    config, _, _ = _core.load_layered_config()
    leaf = _get_nested_config_dict(config, ["review", "complexity", "medium"], defaults)
    return {key: leaf.get(key, defaults[key]) for key in defaults}


def get_review_flag_weights() -> dict:
    """Get severity weights for review flags.

    Returns:
        Dict with flag names mapped to severity weights (0.0-1.0).
    """
    # Multi-key dict return -- not suitable for typed resolvers
    defaults = _defaults.DEFAULT_REVIEW_FLAG_WEIGHTS
    config, _, _ = _core.load_layered_config()
    leaf = _get_nested_config_dict(config, ["review", "feedback", "flag_weights"], defaults)
    return {key: leaf.get(key, defaults[key]) for key in defaults}


def get_review_rating_adjustments() -> dict:
    """Get quality score adjustments based on numeric rating (1-5).

    Returns:
        Dict mapping rating (1-5) to quality score adjustment.
    """
    # Multi-key dict return -- not suitable for typed resolvers
    defaults = _defaults.DEFAULT_REVIEW_RATING_ADJUSTMENTS
    config, _, _ = _core.load_layered_config()
    leaf = _get_nested_config_dict(config, ["review", "feedback", "rating_adjustments"], defaults)
    return {
        rating: coerce_float_with_default(leaf.get(rating), defaults[rating]) for rating in defaults
    }


def get_review_feedback_config() -> dict:
    """Get review feedback configuration (scalar values).

    Returns:
        Dict with scalar configuration values for review feedback scoring:
        - pass_adjustment, fail_adjustment, flag_penalty_cap,
          default_initial_quality_score, rederivation_threshold,
          pass_rating_threshold
    """
    # Multi-key dict return -- not suitable for typed resolvers
    _float_defaults = {
        "pass_adjustment": DEFAULT_REVIEW_PASS_ADJUSTMENT,
        "fail_adjustment": DEFAULT_REVIEW_FAIL_ADJUSTMENT,
        "flag_penalty_cap": DEFAULT_REVIEW_FLAG_PENALTY_CAP,
        "default_initial_quality_score": DEFAULT_REVIEW_DEFAULT_INITIAL_QUALITY_SCORE,
        "rederivation_threshold": DEFAULT_REVIEW_REDERIVATION_THRESHOLD,
    }

    config, _, _ = _core.load_layered_config()
    feedback_config = _get_nested_config_dict(config, ["review", "feedback"], {})

    result: dict = {
        key: coerce_float_with_default(feedback_config.get(key), default_val, key)
        for key, default_val in _float_defaults.items()
    }

    # pass_rating_threshold is int, not float
    raw_threshold = feedback_config.get("pass_rating_threshold")
    if raw_threshold is not None:
        try:
            result["pass_rating_threshold"] = int(raw_threshold)
        except (TypeError, ValueError):
            result["pass_rating_threshold"] = DEFAULT_REVIEW_PASS_RATING_THRESHOLD
    else:
        result["pass_rating_threshold"] = DEFAULT_REVIEW_PASS_RATING_THRESHOLD

    return result


def get_quality_config(config: dict | None = None) -> dict[str, Any]:
    """Get quality assessment configuration.

    Args:
        config: Optional config dict. If None, loads from layered config

    Returns:
        Dict with quality configuration keys.
    """
    # Custom signature (accepts config arg) -- not suitable for typed resolvers
    if config is None:
        config, _, _ = _core.load_layered_config()

    return config.get("quality", {})
