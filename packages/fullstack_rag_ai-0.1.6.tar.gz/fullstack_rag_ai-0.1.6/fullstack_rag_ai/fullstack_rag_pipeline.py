import os
import hashlib
import pickle
from typing import List, Set, Dict, Any
from langchain_ollama import ChatOllama
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from .config import DEFAULT_CONFIG


# -----------------------------
# Binary Helpers
# -----------------------------
def load_binary(path: str) -> Dict[Any, Any]:
    """
    Load a pickle file safely.

    Args:
        path (str): Path to the pickle file.

    Returns:
        Dict[Any, Any]: Loaded data or empty dict if file missing or corrupted.
    """
    try:
        if os.path.exists(path):
            with open(path, "rb") as f:
                return pickle.load(f)
        else:
            print(f"[WARN] File not found: {path}")
    except Exception as e:
        print(f"[ERROR] Failed to load {path}: {e}")
    return {}


def save_binary(path: str, data: Any) -> bool:
    """
    Save data as a pickle file safely.

    Args:
        path (str): File path to save.
        data (Any): Data to pickle.

    Returns:
        bool: True if saved successfully, False otherwise.
    """
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "wb") as f:
            pickle.dump(data, f)
        return True
    except Exception as e:
        print(f"[ERROR] Failed to save {path}: {e}")
        return False


# -----------------------------
# Cache Key Helper
# -----------------------------
def compute_cache_key(question: str, docs: List[Any]) -> str:
    """
    Compute a deterministic cache key based on the question and document content.

    Args:
        question (str): User query.
        docs (List[Document]): Retrieved documents.

    Returns:
        str: MD5 hash as cache key.
    """
    context_text = "".join(d.page_content for d in docs)
    context_hash = hashlib.md5(context_text.encode()).hexdigest()
    return hashlib.md5((question + context_hash).encode()).hexdigest()


# -----------------------------
# QA Helper Functions
# -----------------------------
def retrieve_documents(
    index_path: str,
    question: str,
    embedding_model: str,
    k: int,
    debug: bool
) -> List[Any]:
    """
    Load FAISS vector DB and retrieve top-k documents safely.

    Args:
        index_path (str): Path to FAISS DB.
        question (str): User query.
        embedding_model (str): HuggingFace embedding model.
        k (int): Number of top documents to retrieve.
        debug (bool): Print retrieved chunks if True.

    Returns:
        List[Document]: Retrieved documents, empty if index missing or error occurs.
    """
    if not os.path.exists(index_path):
        print(f"[WARN] FAISS index path does not exist: {index_path}")
        return []

    try:
        embeddings = HuggingFaceEmbeddings(model_name=embedding_model)
        vectordb = FAISS.load_local(index_path, embeddings, allow_dangerous_deserialization=True)
        docs = vectordb.similarity_search(question, k=k)

        if debug:
            print("[DEBUG] Retrieved sources:", [d.metadata.get("source", "unknown") for d in docs])
            for d in docs:
                print(d.page_content[:200], "\n---")

        return docs
    except Exception as e:
        print(f"[ERROR] Failed to retrieve documents from FAISS: {e}")
        return []


def generate_answer(prompt: str, model: str) -> str:
    """
    Generate an answer from the LLM using the given prompt.

    Args:
        prompt (str): Prompt text including context and question.
        model (str): Ollama model name.

    Returns:
        str: Generated answer or error message.
    """
    try:
        llm = ChatOllama(model=model)
        return llm.invoke(prompt)
    except Exception as e:
        print(f"[ERROR] LLM failed to generate answer: {e}")
        return "Failed to generate answer due to LLM error."


# -----------------------------
# Main QA Function
# -----------------------------
def ask_question(
    question: str,
    index_path: str,
    model: str = DEFAULT_CONFIG["llm_model"],
    embedding_model: str = DEFAULT_CONFIG["embedding_model"],
    k: int = DEFAULT_CONFIG["k"],
    debug: bool = False
) -> str:
    """
    Ask a question using FAISS vector DB and QA cache.
    Returns cached answers if available and sources unchanged.
    Handles missing paths and missing index gracefully.

    Args:
        question (str): User query.
        index_path (str): Path to vector DB and QA cache.
        model (str): Ollama LLM model name.
        embedding_model (str): HuggingFace embedding model.
        k (int): Number of top chunks to retrieve.
        debug (bool): Print debug info.

    Returns:
        str: Answer to the question or error message.
    """
    if not os.path.exists(index_path):
        print(f"[WARN] Vector DB path does not exist: {index_path}")
        return "No documents found. Please check your vector DB path."

    # Load top documents
    docs = retrieve_documents(index_path, question, embedding_model, k, debug)
    if not docs:
        return "No relevant information found in the documents."

    # Load QA cache
    cache_file = os.path.join(index_path, "qa_cache.bin")
    qa_cache = load_binary(cache_file)

    # Compute cache key
    key = compute_cache_key(question, docs)
    source_files: Set[str] = {d.metadata.get("source") for d in docs}

    # Return cached answer if sources unchanged
    if key in qa_cache:
        cached_sources = set(qa_cache[key].get("sources", []))
        if cached_sources == source_files:
            if debug:
                print("[INFO] Returning cached answer")
            return qa_cache[key].get("answer", "Cached answer missing.")

    # Build context and prompt
    context = "\n\n".join(d.page_content for d in docs)
    prompt = f"""
You are a helpful assistant. Use the context below to answer the question. 
Combine information, reason, and infer if needed. 
If answer is not in context, say "I could not find the answer in the documents."

Context:
{context}

Question:
{question}
"""

    # Generate answer
    answer = generate_answer(prompt, model)

    # Save in cache safely
    qa_cache[key] = {"answer": answer, "sources": list(source_files)}
    if not save_binary(cache_file, qa_cache):
        print(f"[WARN] Could not update QA cache at {cache_file}")

    return answer