DEFAULT_CONFIG = {

    "embedding_model": "sentence-transformers/all-MiniLM-L6-v2",

    "llm_model": "llama3",

    "chunk_size": 500,

    "chunk_overlap": 100,

    "k": 15

}