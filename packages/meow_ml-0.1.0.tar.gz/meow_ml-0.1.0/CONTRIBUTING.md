# Contributing

## Scope

The public review surface of this branch is centered on `meow_ml`. Contributions that improve packaging, documentation, config hygiene, reproducibility, and the reusable framework layer are the highest priority.

Legacy runtime code under `meow_ml/src/` is retained for continuity, but changes there should be clearly justified and should avoid breaking the public MEOW-ML workflow.

## Development Setup

```bash
conda env create -f environment.yml
conda activate meow_ml
python -m pip install --upgrade pip
python -m pip install -e .[dev]
```

## Before Opening A Pull Request

- run `python -m compileall meow_ml`
- run `python scripts/check_no_local_paths.py`
- run the relevant CLI `--help` checks for any entrypoints you touched
- update docs when changing config shape, public behavior, or supported workflows

## Coding Expectations

- prefer configuration-driven behavior over hard-coded paths or machine-specific assumptions
- keep the public API under `meow_ml` stable and well documented
- preserve reproducibility by documenting required data layout and environment assumptions
- treat archived/reference material as non-public unless it is explicitly promoted into the supported surface

## Changes Log For Modifications

NOSA requests that modifications be clearly identified. When you make non-trivial changes, include a short summary in your pull request and update any relevant changelog or review notes so downstream recipients can identify the origin and intent of the modification.
