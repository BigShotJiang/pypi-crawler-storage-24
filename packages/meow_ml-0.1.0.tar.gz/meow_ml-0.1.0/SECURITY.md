# Security Policy

## Reporting A Vulnerability

Please do not open a public issue for an undisclosed security problem.

If you discover a vulnerability in this repository, report it through the project’s designated private disclosure channel once the public repository location and maintainer workflow are finalized. Until then, coordinate through the maintainers’ private review process rather than publishing exploit details in issues or pull requests.

## In Scope

- accidental exposure of secrets, tokens, private service endpoints, or local machine details
- unsafe path handling or file writes in the public workflow
- deserialization or command-execution bugs
- vulnerabilities in the supported MEOW-ML package surface

## Out Of Scope

- local environment misconfiguration outside the repository
- issues confined to removed notebooks or removed cluster submission scripts
- vulnerabilities in third-party dependencies that are already disclosed and fixed upstream unless the repository is pinning a vulnerable version unnecessarily

## Hardening Expectations

- do not commit credentials or internal endpoints
- replace machine-specific paths with placeholders before committing
- use MLflow tracking URIs that are appropriate for your environment
- review public example configs before publishing derivative work
