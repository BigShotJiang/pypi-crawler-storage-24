"""Top-level package for MEOW-ML."""

__all__ = ["__version__"]

__version__ = "0.1.0"
