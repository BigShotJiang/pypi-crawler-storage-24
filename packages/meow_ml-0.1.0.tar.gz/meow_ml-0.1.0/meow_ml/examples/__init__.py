"""
MEOW-ML Examples
"""