"""Packaged example configuration files for the forest canopy workflow."""
