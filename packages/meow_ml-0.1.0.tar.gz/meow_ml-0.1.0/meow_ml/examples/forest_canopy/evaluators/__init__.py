"""Forest canopy example evaluators."""
