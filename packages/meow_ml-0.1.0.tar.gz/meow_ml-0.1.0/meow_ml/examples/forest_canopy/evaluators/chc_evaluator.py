"""Forest canopy evaluator."""

from meow_ml.src.visualization.ModelEvaluator import ModelEvaluator


class CHCEvaluator(ModelEvaluator):
    """Example-specific evaluator wrapper for canopy-height workflows."""

    pass
