"""Diagnostics and helper tools for the forest canopy example."""
