"""Forest canopy example model factories."""
