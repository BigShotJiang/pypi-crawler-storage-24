"""Forest canopy model factory."""

from ....core.model_factories.keras_model_factory import KerasModelFactory
from ..evaluators.chc_evaluator import CHCEvaluator


class CHCKerasModelFactory(KerasModelFactory):
    """Use the shared Keras runtime with the canopy-height evaluator."""

    def __init__(self, model_config):
        super().__init__(model_config)
        self.evaluator = CHCEvaluator()
