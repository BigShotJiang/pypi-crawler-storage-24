"""Forest canopy example data generators."""
