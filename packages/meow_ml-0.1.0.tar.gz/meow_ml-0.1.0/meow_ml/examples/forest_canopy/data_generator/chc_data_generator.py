"""Forest canopy example data generator."""

from meow_ml.src.data_generators.data_generator import DataGenerator


class CHCDataGenerator(DataGenerator):
    """Expose the canopy-height generator through the MEOW-ML example namespace."""

    pass
