"""
MEOW-ML Core Framework
"""
__version__ = "0.1.0"
__author__ = "NASA GSFC"
__description__ = "Multi-Path Earth Observation Machine Learning Framework"