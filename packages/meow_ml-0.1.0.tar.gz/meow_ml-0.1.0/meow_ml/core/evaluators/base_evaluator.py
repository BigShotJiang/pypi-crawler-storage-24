"""
Base evaluator class for evaluating model performance.
"""
from abc import ABC, abstractmethod
import matplotlib.pyplot as plt
import numpy as np
import mlflow

class BaseEvaluator(ABC):
    """
    Abstract base class for model evaluators.
    """
    
    def __init__(self, config=None):
        """
        Initialize the evaluator.
        
        Parameters
        ----------
        config : dict, optional
            Configuration dictionary
        """
        self.config = config or {}
    
    def analyze_data_before_training(self, train_generator, validation_generator, test_generator):
        """
        Analyze data before training.
        
        Parameters
        ----------
        train_generator : BaseDataGenerator
            Training data generator
        validation_generator : BaseDataGenerator
            Validation data generator
        test_generator : BaseDataGenerator
            Test data generator
        """
        # Default implementation - can be overridden
        pass
    
    @abstractmethod
    def evaluate_model(self, model, test_generator):
        """
        Evaluate model performance.
        
        Parameters
        ----------
        model : model instance
            Model to evaluate
        test_generator : BaseDataGenerator
            Test data generator
        
        Returns
        -------
        dict
            Evaluation metrics
        """
        pass
    
    @abstractmethod
    def plot_metrics(self, model, train_generator, validation_generator, test_generator, history, test_type="reg", scale_method=None):
        """
        Generate and log evaluation plots.
        
        Parameters
        ----------
        model : model instance
            Trained model
        train_generator : BaseDataGenerator
            Training data generator
        validation_generator : BaseDataGenerator
            Validation data generator
        test_generator : BaseDataGenerator
            Test data generator
        history : History
            Training history
        test_type : str
            Type of test (regression/classification)
        scale_method : str, optional
            Method used for scaling data
        """
        pass