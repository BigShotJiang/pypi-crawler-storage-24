"""Evaluator interfaces for MEOW-ML core."""
