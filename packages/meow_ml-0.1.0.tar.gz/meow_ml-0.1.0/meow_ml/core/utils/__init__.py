"""Utility helpers for MEOW-ML core."""
