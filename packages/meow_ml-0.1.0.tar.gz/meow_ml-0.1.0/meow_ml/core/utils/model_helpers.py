"""Model factory helpers for MEOW-ML."""

import importlib

from ..model_factories.keras_model_factory import KerasModelFactory
from meow_ml.src.model_factories.KerasOptunaModelFactory import KerasOptunaModelFactory
from meow_ml.src.model_factories.XGBoostModelFactory import XGBoostModelFactory


def import_class(class_path):
    module_path, class_name = class_path.rsplit(".", 1)
    module = importlib.import_module(module_path)
    return getattr(module, class_name)


def init_model_factory(model_config, model_type="Sequential", optuna=False):
    class_path = model_config.get("class")
    if class_path:
        return import_class(class_path)(model_config)

    if optuna:
        if model_type == "Sequential":
            return KerasOptunaModelFactory(model_config)
    else:
        if model_type in {"Sequential", "Functional", "Keras"}:
            return KerasModelFactory(model_config)
        if model_type == "XGBoost":
            return XGBoostModelFactory(model_config)
    raise ValueError("Invalid model type")
