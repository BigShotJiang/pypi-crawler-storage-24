"""Data generator interfaces for MEOW-ML core."""
