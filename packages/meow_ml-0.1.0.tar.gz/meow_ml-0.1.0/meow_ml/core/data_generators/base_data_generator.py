"""
Base data generator class that all specific data generators should inherit from.
"""
from abc import ABC, abstractmethod
from tensorflow.keras.utils import Sequence

class BaseDataGenerator(Sequence, ABC):
    """
    Abstract base class for data generators.
    Extends Keras Sequence for compatibility with Keras model.fit().
    """
    
    def __init__(self, config=None, **kwargs):
        """
        Initialize the data generator.
        
        Parameters
        ----------
        config : dict, optional
            Configuration dictionary
        **kwargs : dict
            Additional keyword arguments
        """
        self.config = config or {}
        self.batch_size = self.config.get("batch_size", 32)
        self.setup(**kwargs)
    
    @abstractmethod
    def setup(self, **kwargs):
        """
        Set up data generator with implementation-specific parameters.
        This should be overridden by subclasses.
        
        Parameters
        ----------
        **kwargs : dict
            Additional keyword arguments
        """
        pass
    
    @abstractmethod
    def __len__(self):
        """
        Return the number of batches per epoch.
        
        Returns
        -------
        int
            Number of batches
        """
        pass
    
    @abstractmethod
    def __getitem__(self, index):
        """
        Return a batch of data.
        
        Parameters
        ----------
        index : int
            Batch index
        
        Returns
        -------
        tuple
            (x, y) where x is input features and y is target values
        """
        pass
    
    def on_epoch_end(self):
        """
        Method called at the end of every epoch.
        """
        pass
    
    @abstractmethod
    def load_data(self):
        """
        Load data from files.
        
        Returns
        -------
        tuple
            Loaded features and labels
        """
        pass