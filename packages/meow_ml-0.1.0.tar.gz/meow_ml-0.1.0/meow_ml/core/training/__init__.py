"""Training utilities for MEOW-ML core."""
