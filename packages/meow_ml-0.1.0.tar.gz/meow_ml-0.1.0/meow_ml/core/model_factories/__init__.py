"""Model factories for MEOW-ML core."""
