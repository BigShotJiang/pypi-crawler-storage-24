"""Expose the proven Keras runtime under the MEOW-ML core namespace."""

from meow_ml.src.model_factories.KerasModelFactory import (
    KerasModelFactory as LegacyKerasModelFactory,
)


class KerasModelFactory(LegacyKerasModelFactory):
    """Compatibility wrapper for the repo's existing Keras runtime."""

    pass
