from meow_ml.src.model_factories.KerasModelFactory import KerasModelFactory
from meow_ml.src.model_factories.KerasOptunaModelFactory import KerasOptunaModelFactory
from meow_ml.src.model_factories.XGBoostModelFactory import XGBoostModelFactory

def init_model_factory(model_config, model_type="Sequential", optuna=False):
    if optuna:
        if model_type == "Sequential":
            return KerasOptunaModelFactory(model_config)
    else:
        if model_type == "Sequential" or model_type == "Functional":
            return KerasModelFactory(model_config)
        elif model_type == "XGBoost":
            return XGBoostModelFactory(model_config)
        else:
            raise ValueError("Invalid model type")
