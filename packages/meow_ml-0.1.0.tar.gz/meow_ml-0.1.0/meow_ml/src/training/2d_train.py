import os
import time
import yaml
import argparse
import mlflow.tensorflow
from meow_ml.src.utils.mlflow_helpers import setup_mlflow, log_params
from meow_ml.src.utils.data_generator_helpers import load_2d_data_generator
from meow_ml.src.utils.model_helpers import init_model_factory

def train(model_config, data_generator_config, mlflow_config):
    model_type = model_config.get("model_type", "Functional")
    model_factory = init_model_factory(model_config, model_type=model_type)
    model = model_factory.create_model(model_config)
    model = model_factory.compile_model(model, model_config)

    train_generator = load_2d_data_generator(data_generator_config, 'train')
    train_scalers = train_generator.scalers
    validate_generator = load_2d_data_generator(data_generator_config, 'validate', scalers=train_scalers)
    test_generator = load_2d_data_generator(data_generator_config, 'test', scalers=train_scalers)

    with mlflow.start_run(
        experiment_id=mlflow_config['EXPERIMENT_ID'],
        run_name=model_config.get("model_name", None),
        description=model_config.get("model_description", ""),
        nested=False
    ) as run:
        model_factory.autolog()
        RUN_ID = mlflow.active_run().info.run_id
        print(f"STARTING RUN: {RUN_ID}")
        mlflow.log_artifact(mlflow_config['config_file_path'])
        mlflow.log_param("run_name", model_config.get("model_name", None))

        model_factory.extras_before_training(model, train_generator, validate_generator, test_generator)

        t0 = time.time()

        if model_type in ["Sequential", "Keras", "Functional"]:
            model_factory.summary(model)
        history = model_factory.train_model(model, train_generator, validate_generator, model_config)

        t1 = time.time()
        total_time = t1 - t0

        mlflow.log_param("Training time", total_time)

        print(f"\nTotal time for model.fit() processing is: {total_time} seconds.")

        if model_type == "XGBoost":
            model_factory.summary(model)

        predictions = model_factory.predict(model, test_generator)
        eval_results = model_factory.evaluate(model, test_generator)
        print(f'eval_results: {eval_results}')

        model_factory.log_metrics(eval_results)
        model_factory.plot_metrics(
            model,
            train_generator,
            validate_generator,
            test_generator,
            history,
            data_generator_config.get('test_type', 'cat'),
            data_generator_config.get('scale_data_method', None)
        )

        model_factory.extras_after_training(
            model,
            train_generator,
            validate_generator,
            test_generator,
            data_generator_config.get('test_type', 'cat')
        )

        print("Finished successfully")

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Flags for settings')
    parser.add_argument(
        '--config',
        required=True,
        type=str,
        help='config file path for loading settings',
    )
    args = parser.parse_args()

    with open(args.config, 'r') as f:
        config = yaml.safe_load(f)
        models_config = config["models"]
        data_generator_config = config["data_generator"]
        mlflow_config = config["mlflow"]
        gpu_config = config["gpu"]

    gpus = gpu_config.get('GPUS', None)
    if gpus:
        os.environ["CUDA_VISIBLE_DEVICES"] = gpus

    mlflow_config = setup_mlflow(mlflow_config, config_file_path=args.config)

    for model_config in models_config:
        train(model_config=model_config, data_generator_config=data_generator_config, mlflow_config=mlflow_config)
