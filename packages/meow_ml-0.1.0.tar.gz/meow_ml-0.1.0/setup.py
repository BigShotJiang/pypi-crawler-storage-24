from pathlib import Path

from setuptools import find_packages, setup


ROOT = Path(__file__).parent


setup(
    name="meow-ml",
    version="0.1.0",
    description="MEOW-ML framework for Earth observation machine learning workflows.",
    long_description=(ROOT / "README.md").read_text(encoding="utf-8"),
    long_description_content_type="text/markdown",
    license="NASA Open Source Agreement 1.3",
    license_files=["LICENSE", "NOTICE", "NOSA-GSC-19449-1.pdf"],
    packages=find_packages(
        include=[
            "meow_ml",
            "meow_ml.*",
        ]
    ),
    include_package_data=True,
    package_data={
        "meow_ml.examples.forest_canopy": ["configs/*.yaml"],
    },
    python_requires=">=3.10",
    install_requires=[
        "certifi>=2024.7.4",
        "geopandas>=0.11.0",
        "joblib>=1.1.0",
        "keras>=2.10.0",
        "jinja2>=3.1.6",
        "matplotlib>=3.5.0",
        "mlflow>=2.22.4",
        "numpy>=1.21.0",
        "omegaconf>=2.2.0",
        "pandas>=1.4.0",
        "pillow>=10.3.0",
        "pyyaml>=6.0",
        "rasterio>=1.3.0",
        "requests>=2.32.4",
        "scikit-learn>=1.5.0",
        "scipy>=1.8.0",
        "seaborn>=0.11.0",
        "tensorflow>=2.11.1",
        "tqdm>=4.66.3",
        "urllib3>=2.5.0",
        "werkzeug>=3.1.6",
    ],
    extras_require={
        "dev": [
            "bandit>=1.7.0",
            "build>=1.2.0",
            "pip-audit>=2.7.0",
            "pytest>=7.0.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "meow-ml=meow_ml.core.main:main",
            "meow-ml-forest-canopy=meow_ml.examples.forest_canopy.main:main",
        ]
    },
    zip_safe=False,
)
