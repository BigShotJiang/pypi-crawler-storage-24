"""Filesystem-backed state management for downloads, failures, and removals."""

from __future__ import annotations

from datetime import datetime, timezone
import json
import re
from pathlib import Path

from musicdl.types import Song

LOG_DOWNLOADED = "downloaded.json"
LOG_FAILED = "failed.json"
LOG_REMOVED = "removed.json"
FILENAME_RE = re.compile(r"^(?P<artist>.+?)\s+-\s+(?P<title>.+?)(?:\s+\[[^\]]+\])?$")


def _song_record(
    song: Song,
    file_name: str | None = None,
    source: str | None = None,
    matched_title: str | None = None,
    matched_artist: str | None = None,
    matched_url: str | None = None,
    downloaded_at: str | None = None,
    failed_at: str | None = None,
) -> dict[str, str | int | list[str]]:
    """Build a serialized log record for a song event."""

    record = {"artist": song.artist, "title": song.title, "key": song.key}
    if song.source_url:
        record["source_url"] = song.source_url
    if song.album:
        record["album"] = song.album
    if song.track_number is not None:
        record["track_number"] = song.track_number
    if song.release_date:
        record["release_date"] = song.release_date
    if song.isrc:
        record["isrc"] = song.isrc
    if song.artwork_url:
        record["artwork_url"] = song.artwork_url
    if song.genres:
        record["genres"] = list(song.genres)
    if file_name:
        record["file_name"] = file_name
    if source:
        record["source"] = source
    if matched_title:
        record["matched_title"] = matched_title
    if matched_artist:
        record["matched_artist"] = matched_artist
    if matched_url:
        record["matched_url"] = matched_url
    if downloaded_at:
        record["downloaded_at"] = downloaded_at
    if failed_at:
        record["failed_at"] = failed_at
    return record


def _timestamp_now() -> str:
    """Return the current UTC timestamp in the JSON log format."""

    return (
        datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")
    )


def _timestamp_from_epoch(epoch_seconds: float) -> str:
    """Convert a filesystem timestamp to the JSON log timestamp format."""

    return (
        datetime.fromtimestamp(epoch_seconds, timezone.utc)
        .isoformat(timespec="seconds")
        .replace("+00:00", "Z")
    )


def _load_json(path: Path) -> list[dict[str, str | int | list[str]]]:
    """Load a JSON log file defensively, returning an empty list on invalid input."""

    if not path.exists():
        return []
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return []
    return value if isinstance(value, list) else []


def _save_json(path: Path, value: list[dict[str, str | int | list[str]]]) -> None:
    """Persist a JSON log file using stable pretty-printed formatting."""

    path.write_text(
        json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )


def load_downloaded(download_dir: Path) -> dict[str, dict[str, str | int | list[str]]]:
    """Load downloaded-song state indexed by normalized song key."""

    records = _load_json(download_dir / LOG_DOWNLOADED)
    return {record.get("key", ""): record for record in records if record.get("key")}


def load_failed(download_dir: Path) -> dict[str, dict[str, str | int | list[str]]]:
    """Load failed-song state indexed by normalized song key."""

    records = _load_json(download_dir / LOG_FAILED)
    return {record.get("key", ""): record for record in records if record.get("key")}


def load_removed(download_dir: Path) -> dict[str, dict[str, str | int | list[str]]]:
    """Load removal-history state indexed by normalized song key."""

    records = _load_json(download_dir / LOG_REMOVED)
    return {record.get("key", ""): record for record in records if record.get("key")}


def sync_logs_with_folder(
    download_dir: Path,
) -> tuple[
    dict[str, dict[str, str | int | list[str]]],
    dict[str, dict[str, str | int | list[str]]],
]:
    """Reconcile JSON logs against the actual `.mp3` files in an output directory."""

    # Rebuild downloaded log from disk each run.
    previous_downloaded = load_downloaded(download_dir)
    downloaded: dict[str, dict[str, str | int | list[str]]] = {}
    failed = load_failed(download_dir)
    removed = load_removed(download_dir)

    existing_files = {p.name for p in download_dir.glob("*.mp3")}

    # Infer downloaded songs from current filenames so manually added tracks are tracked too.
    for filename in existing_files:
        file_path = download_dir / filename
        stem = Path(filename).stem
        match = FILENAME_RE.match(stem)
        if not match:
            continue
        song = Song(artist=match.group("artist"), title=match.group("title"))
        downloaded.setdefault(
            song.key,
            _song_record(
                song,
                file_name=filename,
                source="folder-scan",
                downloaded_at=_timestamp_from_epoch(file_path.stat().st_mtime),
            ),
        )

    _save_json(download_dir / LOG_DOWNLOADED, list(downloaded.values()))

    # Move entries that no longer exist on disk into removed.json history.
    for key, record in previous_downloaded.items():
        if key in downloaded:
            continue
        moved = dict(record)
        moved["removed_at"] = _timestamp_now()
        removed.pop(key, None)
        removed[key] = moved

    _save_json(download_dir / LOG_REMOVED, list(removed.values()))
    return downloaded, failed


def mark_downloaded(
    download_dir: Path,
    downloaded: dict[str, dict[str, str | int | list[str]]],
    failed: dict[str, dict[str, str | int | list[str]]],
    song: Song,
    file_name: str,
    source: str,
    matched_title: str | None = None,
    matched_artist: str | None = None,
    matched_url: str | None = None,
    downloaded_at: str | None = None,
) -> None:
    """Record a successful or already-present song in `downloaded.json`."""

    # Keep downloaded.json recency-ordered: updated songs move to the bottom.
    downloaded.pop(song.key, None)

    # Remove stale aliases (for example sanitized filename-derived keys) so the
    # same file is represented by exactly one record.
    stale_keys = [
        key
        for key, record in downloaded.items()
        if key != song.key and record.get("file_name") == file_name
    ]
    for key in stale_keys:
        downloaded.pop(key, None)

    downloaded[song.key] = _song_record(
        song,
        file_name=file_name,
        source=source,
        matched_title=matched_title,
        matched_artist=matched_artist,
        matched_url=matched_url,
        downloaded_at=downloaded_at or _timestamp_now(),
    )
    _save_json(download_dir / LOG_DOWNLOADED, list(downloaded.values()))


def mark_failed(
    download_dir: Path,
    failed: dict[str, dict[str, str | int | list[str]]],
    song: Song,
    error: str,
) -> None:
    """Record a song failure in `failed.json` using upsert semantics."""

    # Append-only history with upsert by key.
    record = _song_record(song, failed_at=_timestamp_now())
    record["error"] = error
    failed[song.key] = record
    _save_json(download_dir / LOG_FAILED, list(failed.values()))
