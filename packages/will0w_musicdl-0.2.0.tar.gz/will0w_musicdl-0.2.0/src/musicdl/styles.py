"""Terminal color and styling utilities for CLI output."""

import os
import sys


def _env_flag(name: str) -> bool:
    """Return whether an environment flag is set to a truthy value."""

    return os.getenv(name, "").lower() in {"1", "true", "yes", "on"}


def _is_ci() -> bool:
    """Return whether the current process appears to be running in CI."""

    return _env_flag("CI")


def _stdout_is_tty() -> bool:
    """Return whether stdout is attached to an interactive terminal."""

    stdout = getattr(sys, "stdout", None)
    isatty = getattr(stdout, "isatty", None)
    return bool(callable(isatty) and isatty())


def _supports_ansi() -> bool:
    """Return whether ANSI styling should be emitted for the current stdout."""

    if os.getenv("NO_COLOR") is not None:
        return False
    if _env_flag("FORCE_COLOR"):
        return True

    term = os.getenv("TERM", "")
    if not _stdout_is_tty() or term in {"", "dumb"}:
        return False
    return True


def _use_transient_updates() -> bool:
    """Return whether carriage-return progress updates are appropriate."""

    return _supports_ansi() and not _is_ci()


class pconst:
    """ANSI color and formatting constants."""

    # Colors
    SUCCESS = "\033[92m"  # Green
    WARN = "\033[93m"  # Yellow
    DEV_WARN = "\033[103m"  # Bright yellow background
    ERROR = "\033[91m"  # Red
    GRAY = "\033[90m"  # Dark gray
    BOLD = "\033[1m"  # Bold
    UNDERLINE = "\033[4m"  # Underline
    END = "\033[0m"  # Reset
    # Indentation
    TAB = "  "


def print_update(text: str) -> None:
    """Print a temporary update message (e.g., progress indicator).

    In CI environments, this is suppressed. On terminals, it uses carriage
    return to overwrite the line.
    """
    if _is_ci():
        return
    if not _use_transient_updates():
        print(f"[progress] {text}")
        return
    print(
        f"{pconst.TAB}{pconst.GRAY}{text:<70}\r{pconst.END}",
        end="",
        flush=True,
    )


def clear_update() -> None:
    """Clear the current transient update line."""
    if not _use_transient_updates():
        return
    print(" " * 80 + "\r", end="", flush=True)


def colorize(tag: str, message: str) -> str:
    """Apply color formatting to a message based on its tag.

    Tags:
      - 'info': Gray
      - 'ok': Green
      - 'skip': Gray
      - 'try': Default (no color)
      - 'done': Green
      - 'warn': Yellow
      - 'error': Red
      - 'fail': Red
    """
    if not _supports_ansi():
        return f"[{tag}] {message}"

    color_map = {
        "info": pconst.GRAY,
        "ok": pconst.SUCCESS,
        "skip": pconst.GRAY,
        "try": "",
        "done": pconst.SUCCESS,
        "warn": pconst.WARN,
        "error": pconst.ERROR,
        "fail": pconst.ERROR,
    }
    color = color_map.get(tag, "")
    reset = pconst.END if color else ""
    return f"{color}[{tag}]{reset} {message}"
