"""Online metadata enrichment for standalone song files."""

from __future__ import annotations

from copy import deepcopy
from difflib import SequenceMatcher
import re
import time
from typing import Any, Callable
from urllib.parse import quote_plus

import requests

# Rate-limiting state (module-level, sync-safe for single-threaded CLI use)
_mb_last_call: float = 0.0
_itunes_last_call: float = 0.0
_MB_MIN_INTERVAL: float = 1.1  # MusicBrainz ToS: max 1 req/sec for anonymous usage
_ITUNES_MIN_INTERVAL: float = 0.15  # Courtesy throttle to avoid Apple 429s on bulk runs


def _wait_before_mb() -> None:
    """Block until the MusicBrainz minimum inter-request interval has elapsed."""
    global _mb_last_call
    elapsed = time.monotonic() - _mb_last_call
    if elapsed < _MB_MIN_INTERVAL:
        time.sleep(_MB_MIN_INTERVAL - elapsed)
    _mb_last_call = time.monotonic()


def _wait_before_itunes() -> None:
    """Block until the iTunes courtesy throttle interval has elapsed."""
    global _itunes_last_call
    elapsed = time.monotonic() - _itunes_last_call
    if elapsed < _ITUNES_MIN_INTERVAL:
        time.sleep(_ITUNES_MIN_INTERVAL - elapsed)
    _itunes_last_call = time.monotonic()


_ITUNES_SEARCH_URL = "https://itunes.apple.com/search"
_MUSICBRAINZ_SEARCH_URL = "https://musicbrainz.org/ws/2/recording/"
_MUSICBRAINZ_LOOKUP_URL = "https://musicbrainz.org/ws/2/recording/{mbid}"
_MUSICBRAINZ_HEADERS = {
    "Accept": "application/json",
    "User-Agent": "music-downloader/0.1.0 (metadata enrichment)",
}


def enrich_metadata_rows(
    rows: list[dict[str, Any]],
    progress: Callable[[str], None] | None = None,
    checkpoint_fn: Callable[[list[dict[str, Any]]], None] | None = None,
    checkpoint_every: int = 100,
) -> tuple[list[dict[str, Any]], int]:
    """Fill missing metadata fields for rows using online catalog search.

    Args:
        rows: Metadata rows to enrich.
        progress: Optional callback called with a progress string before each API lookup.
        checkpoint_fn: Optional callback called with the current rows after every
            ``checkpoint_every`` iterations so callers can persist incremental progress.
        checkpoint_every: How many songs to process between checkpoint saves.
    """

    enriched_rows = [deepcopy(row) for row in rows]
    enriched_count = 0

    for index, row in enumerate(enriched_rows, start=1):
        artist = _clean_str(row.get("artist"))
        title = _clean_str(row.get("title"))
        if not artist or not title:
            continue
        if not _row_needs_enrichment(row):
            continue

        if progress:
            progress(
                f"Enriching metadata {index}/{len(enriched_rows)}: {artist} - {title}"
            )

        before = deepcopy(row)
        for query_artist, query_title in _query_variants(artist, title):
            if _row_needs_enrichment(row):
                try:
                    match = _search_itunes(query_artist, query_title)
                except requests.RequestException:
                    match = None
                if match:
                    _merge_itunes_match(row, match)

            if _row_needs_enrichment(row):
                try:
                    mb_match = _search_musicbrainz(query_artist, query_title)
                except requests.RequestException:
                    mb_match = None
                if mb_match:
                    _merge_musicbrainz_match(row, mb_match)

            if not _row_needs_enrichment(row):
                break

        if _row_needs_enrichment(row):
            for query_title in _title_only_variants(title):
                try:
                    match = _search_itunes_title_only(artist, query_title)
                except requests.RequestException:
                    match = None
                if match:
                    _merge_itunes_match(row, match)
                if not _row_needs_enrichment(row):
                    break

        if not _genres_from_row(row):
            try:
                fallback_genre = _search_itunes_artist_genre(
                    _primary_artist(_clean_artist(artist))
                )
            except requests.RequestException:
                fallback_genre = None
            if fallback_genre:
                row["genres"] = [fallback_genre]

        if row != before:
            enriched_count += 1

        if checkpoint_fn and index % checkpoint_every == 0:
            try:
                checkpoint_fn(list(enriched_rows))
            except Exception:
                pass

    return enriched_rows, enriched_count


def _row_needs_enrichment(row: dict[str, Any]) -> bool:
    """Return whether a row is missing rich metadata worth enriching."""

    if not _clean_str(row.get("artist")) or not _clean_str(row.get("title")):
        return False
    missing_fields = (
        not _clean_str(row.get("album")),
        not row.get("track_number"),
        not _clean_str(row.get("release_date")),
        not _clean_str(row.get("artwork_url")),
        not _clean_str(row.get("source_url")),
        not _genres_from_row(row),
    )
    return any(missing_fields)


def _search_itunes(artist: str, title: str) -> dict[str, Any] | None:
    """Search the iTunes catalog for the best song match by artist/title."""

    _wait_before_itunes()
    term = quote_plus(f"{artist} {title}")
    response = requests.get(
        f"{_ITUNES_SEARCH_URL}?term={term}&entity=song&limit=10",
        timeout=15,
        headers={"Accept": "application/json"},
    )
    response.raise_for_status()
    payload = response.json()
    results = payload.get("results") or []
    if not isinstance(results, list):
        return None

    scored: list[tuple[float, dict[str, Any]]] = []
    for result in results:
        if not isinstance(result, dict):
            continue
        score = _score_itunes_result(artist, title, result)
        if score >= 0.72:
            scored.append((score, result))

    if not scored:
        return None

    scored.sort(key=lambda item: item[0], reverse=True)
    return scored[0][1]


def _search_musicbrainz(artist: str, title: str) -> dict[str, Any] | None:
    """Search MusicBrainz for the best recording match by artist/title."""

    _wait_before_mb()
    query = quote_plus(f'recording:"{title}" AND artist:"{artist}"')
    response = requests.get(
        f"{_MUSICBRAINZ_SEARCH_URL}?query={query}&fmt=json&limit=10",
        timeout=15,
        headers=_MUSICBRAINZ_HEADERS,
    )
    response.raise_for_status()
    payload = response.json()
    recordings = payload.get("recordings") or []
    if not isinstance(recordings, list):
        return None

    scored: list[tuple[float, dict[str, Any]]] = []
    for recording in recordings:
        if not isinstance(recording, dict):
            continue
        score = _score_musicbrainz_result(artist, title, recording)
        if score >= 0.72:
            scored.append((score, recording))

    if not scored:
        return None

    scored.sort(key=lambda item: item[0], reverse=True)
    best = scored[0][1]
    mbid = _clean_str(best.get("id"))
    if not mbid:
        return best

    detail = _lookup_musicbrainz_recording(mbid)
    return detail or best


def _search_itunes_title_only(artist: str, title: str) -> dict[str, Any] | None:
    """Search iTunes by title only and pick the best artist-aware candidate."""

    _wait_before_itunes()
    term = quote_plus(title)
    response = requests.get(
        f"{_ITUNES_SEARCH_URL}?term={term}&entity=song&limit=20",
        timeout=15,
        headers={"Accept": "application/json"},
    )
    response.raise_for_status()
    payload = response.json()
    results = payload.get("results") or []
    if not isinstance(results, list):
        return None

    scored: list[tuple[float, dict[str, Any]]] = []
    for result in results:
        if not isinstance(result, dict):
            continue
        score = _score_itunes_result(artist, title, result)
        if score >= 0.78:
            scored.append((score, result))

    if not scored:
        return None
    scored.sort(key=lambda item: item[0], reverse=True)
    return scored[0][1]


def _search_itunes_artist_genre(artist: str) -> str | None:
    """Fetch a best-effort genre from iTunes artist-level search."""

    if not artist:
        return None
    _wait_before_itunes()
    term = quote_plus(artist)
    response = requests.get(
        f"{_ITUNES_SEARCH_URL}?term={term}&entity=musicArtist&limit=5",
        timeout=15,
        headers={"Accept": "application/json"},
    )
    response.raise_for_status()
    payload = response.json()
    results = payload.get("results") or []
    if not isinstance(results, list):
        return None

    normalized_artist = _normalize_phrase(artist)
    best_name_score = 0.0
    best_genre: str | None = None
    for result in results:
        if not isinstance(result, dict):
            continue
        name = _clean_str(result.get("artistName")) or ""
        genre = _clean_str(result.get("primaryGenreName"))
        if not name or not genre:
            continue
        score = SequenceMatcher(
            None, normalized_artist, _normalize_phrase(name)
        ).ratio()
        if score > best_name_score:
            best_name_score = score
            best_genre = genre
    return best_genre if best_name_score >= 0.72 else None


def _lookup_musicbrainz_recording(mbid: str) -> dict[str, Any] | None:
    """Fetch a MusicBrainz recording detail payload with releases and ISRCs."""

    _wait_before_mb()
    response = requests.get(
        _MUSICBRAINZ_LOOKUP_URL.format(mbid=mbid)
        + "?fmt=json&inc=isrcs+releases+genres",
        timeout=15,
        headers=_MUSICBRAINZ_HEADERS,
    )
    response.raise_for_status()
    payload = response.json()
    return payload if isinstance(payload, dict) else None


def _score_itunes_result(artist: str, title: str, result: dict[str, Any]) -> float:
    """Compute a similarity score for one iTunes result."""

    result_artist = _clean_str(result.get("artistName")) or ""
    result_title = _clean_str(result.get("trackName")) or ""
    normalized_requested_artist = _normalize_phrase(artist)
    normalized_requested_title = _normalize_phrase(title)
    normalized_result_artist = _normalize_phrase(result_artist)
    normalized_result_title = _normalize_phrase(result_title)

    artist_ratio = SequenceMatcher(
        None, normalized_requested_artist, normalized_result_artist
    ).ratio()
    title_ratio = SequenceMatcher(
        None, normalized_requested_title, normalized_result_title
    ).ratio()

    if (
        normalized_requested_title
        and normalized_requested_title in normalized_result_title
    ):
        title_ratio = max(title_ratio, 0.97)
    if (
        normalized_requested_artist
        and normalized_requested_artist in normalized_result_artist
    ):
        artist_ratio = max(artist_ratio, 0.97)

    return (title_ratio * 0.7) + (artist_ratio * 0.3)


def _score_musicbrainz_result(artist: str, title: str, result: dict[str, Any]) -> float:
    """Compute a similarity score for a MusicBrainz recording result."""

    result_artist = _musicbrainz_artist_name(result)
    result_title = _clean_str(result.get("title")) or ""
    normalized_requested_artist = _normalize_phrase(artist)
    normalized_requested_title = _normalize_phrase(title)
    normalized_result_artist = _normalize_phrase(result_artist)
    normalized_result_title = _normalize_phrase(result_title)

    artist_ratio = SequenceMatcher(
        None, normalized_requested_artist, normalized_result_artist
    ).ratio()
    title_ratio = SequenceMatcher(
        None, normalized_requested_title, normalized_result_title
    ).ratio()
    mb_score = result.get("score")
    score_ratio = 0.0
    if isinstance(mb_score, str) and mb_score.isdigit():
        score_ratio = int(mb_score) / 100.0
    elif isinstance(mb_score, (int, float)):
        score_ratio = float(mb_score) / 100.0

    return (title_ratio * 0.5) + (artist_ratio * 0.3) + (score_ratio * 0.2)


def _merge_itunes_match(row: dict[str, Any], match: dict[str, Any]) -> None:
    """Merge useful iTunes metadata into a row without clobbering existing data."""

    _fill_if_missing(row, "source_url", _clean_str(match.get("trackViewUrl")))
    _fill_if_missing(row, "album", _clean_str(match.get("collectionName")))
    _fill_if_missing(row, "track_number", match.get("trackNumber"))

    release_date = _clean_str(match.get("releaseDate"))
    if release_date and "T" in release_date:
        release_date = release_date.split("T", 1)[0]
    _fill_if_missing(row, "release_date", release_date)

    artwork_url = _upgrade_artwork_url(_clean_str(match.get("artworkUrl100")))
    _fill_if_missing(row, "artwork_url", artwork_url)

    if not _genres_from_row(row):
        genre = _clean_str(match.get("primaryGenreName"))
        if genre:
            row["genres"] = [genre]


def _merge_musicbrainz_match(row: dict[str, Any], match: dict[str, Any]) -> None:
    """Merge useful MusicBrainz metadata into a row without clobbering data."""

    releases = match.get("releases")
    release = releases[0] if isinstance(releases, list) and releases else None
    if isinstance(release, dict):
        _fill_if_missing(row, "album", _clean_str(release.get("title")))
        _fill_if_missing(row, "release_date", _clean_str(release.get("date")))

    isrcs = match.get("isrcs")
    if isinstance(isrcs, list):
        normalized_isrcs = [str(value).strip() for value in isrcs if str(value).strip()]
        if normalized_isrcs:
            _fill_if_missing(row, "isrc", normalized_isrcs[0])

    if not _genres_from_row(row):
        raw_genres = match.get("genres")
        if isinstance(raw_genres, list):
            normalized = []
            for genre in raw_genres:
                if isinstance(genre, dict):
                    name = _clean_str(genre.get("name"))
                else:
                    name = _clean_str(genre)
                if name:
                    normalized.append(name)
            if normalized:
                row["genres"] = normalized


def _genres_from_row(row: dict[str, Any]) -> list[str]:
    """Return normalized genre values from a metadata row."""

    raw = row.get("genres")
    if isinstance(raw, list):
        return [str(value).strip() for value in raw if str(value).strip()]
    genre = _clean_str(row.get("genre"))
    return [genre] if genre else []


def _musicbrainz_artist_name(result: dict[str, Any]) -> str:
    """Return the flattened MusicBrainz artist-credit string for a result."""

    artist_credit = result.get("artist-credit") or []
    if not isinstance(artist_credit, list):
        return ""
    parts: list[str] = []
    for item in artist_credit:
        if not isinstance(item, dict):
            continue
        name = _clean_str(item.get("name"))
        if name:
            parts.append(name)
    return ", ".join(parts)


def _query_variants(artist: str, title: str) -> list[tuple[str, str]]:
    """Return progressively-cleaned query variants for robust metadata lookups."""

    artist_clean = _clean_artist(artist)
    title_clean = _clean_title(title)
    primary_artist = _primary_artist(artist_clean)

    variants = [
        (artist, title),
        (artist_clean, title_clean),
        (primary_artist, title_clean),
        (primary_artist, _remove_parenthetical(title_clean)),
        (primary_artist, _de_version_title(_remove_parenthetical(title_clean))),
    ]

    seen: set[tuple[str, str]] = set()
    unique: list[tuple[str, str]] = []
    for variant_artist, variant_title in variants:
        cleaned_artist = (variant_artist or "").strip()
        cleaned_title = (variant_title or "").strip()
        if not cleaned_artist or not cleaned_title:
            continue
        pair = (cleaned_artist, cleaned_title)
        if pair in seen:
            continue
        seen.add(pair)
        unique.append(pair)
    return unique


def _clean_artist(value: str) -> str:
    """Normalize noisy artist strings from filenames/providers for metadata search."""

    artist = value.replace("_", " ").strip()
    artist = re.sub(r"\s+-\s+topic$", "", artist, flags=re.IGNORECASE)
    artist = re.sub(r"\s+topic$", "", artist, flags=re.IGNORECASE)
    artist = re.sub(r"\s+", " ", artist)
    return artist.strip(" -")


def _clean_title(value: str) -> str:
    """Normalize noisy title strings from filenames/providers for metadata search."""

    title = value.replace("_", " ").strip()
    title = re.sub(r"^topic\s*-\s*", "", title, flags=re.IGNORECASE)
    title = re.sub(r"\s+", " ", title)
    return title.strip(" -")


def _primary_artist(value: str) -> str:
    """Extract primary artist token from multi-artist strings for fallback lookup."""

    for delimiter in (",", " & ", " feat.", " feat ", " ft.", " ft ", " x "):
        if delimiter in value.lower():
            parts = re.split(
                re.escape(delimiter), value, maxsplit=1, flags=re.IGNORECASE
            )
            if parts and parts[0].strip():
                return parts[0].strip()
    return value.strip()


def _remove_parenthetical(value: str) -> str:
    """Drop parenthetical title segments to broaden fallback matching."""

    stripped = re.sub(r"\s*\([^)]*\)", "", value)
    stripped = re.sub(r"\s+", " ", stripped).strip()
    return stripped or value


def _title_only_variants(title: str) -> list[str]:
    """Return cleaned title-only variants for fallback metadata lookups."""

    cleaned = _clean_title(title)
    variants = [
        title,
        cleaned,
        _remove_parenthetical(cleaned),
        _de_version_title(_remove_parenthetical(cleaned)),
    ]
    seen: set[str] = set()
    unique: list[str] = []
    for value in variants:
        candidate = value.strip()
        if not candidate or candidate in seen:
            continue
        seen.add(candidate)
        unique.append(candidate)
    return unique


def _de_version_title(value: str) -> str:
    """Strip common version/remaster/edit suffixes for fallback matching."""

    stripped = re.sub(
        r"\s+-\s+.*\b(remaster|remastered|digital remaster|single edit|edit|version|mix|live)\b.*$",
        "",
        value,
        flags=re.IGNORECASE,
    )
    stripped = re.sub(r"\s+", " ", stripped).strip()
    return stripped or value


def _upgrade_artwork_url(value: str | None) -> str | None:
    """Upgrade iTunes artwork URLs to a higher-resolution variant when possible."""

    if not value:
        return None
    return value.replace("100x100bb", "1000x1000bb")


def _fill_if_missing(row: dict[str, Any], key: str, value: Any) -> None:
    """Set a row value only when the current field is missing or empty."""

    current = row.get(key)
    if current not in (None, "", [], ()):
        return
    if value in (None, "", [], ()):
        return
    row[key] = value


def _clean_str(value: object) -> str | None:
    """Return a stripped string when the value is non-empty."""

    if not isinstance(value, str):
        return None
    stripped = value.strip()
    return stripped or None


def _normalize_phrase(value: str) -> str:
    """Normalize a free-form string for fuzzy comparisons."""

    chars = [character.lower() if character.isalnum() else " " for character in value]
    return " ".join("".join(chars).split())
