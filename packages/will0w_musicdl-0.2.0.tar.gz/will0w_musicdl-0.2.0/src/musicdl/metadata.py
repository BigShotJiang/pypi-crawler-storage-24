"""Folder metadata extraction utilities for already-downloaded audio files."""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

import requests
from mutagen import File as MutagenFile
from mutagen.easyid3 import EasyID3
from mutagen.id3 import APIC, ID3, ID3NoHeaderError, TSRC

FILENAME_RE = re.compile(r"^(?P<artist>.+?)\s+-\s+(?P<title>.+?)(?:\s+\[[^\]]+\])?$")


def _first_tag(tags: Any, key: str) -> str | None:
    """Return the first string value for a mutagen easy tag key, if present."""

    if not tags:
        return None
    values = tags.get(key)
    if not values:
        return None
    if isinstance(values, list) and values:
        value = values[0]
    else:
        value = values
    text = str(value).strip()
    return text or None


def _tag_values(tags: Any, key: str) -> list[str]:
    """Return normalized tag values for a mutagen key."""

    if not tags:
        return []
    values = tags.get(key) or []
    if not isinstance(values, list):
        values = [values]
    cleaned = [str(value).strip() for value in values if str(value).strip()]
    return cleaned


def _artist_title_from_filename(file_path: Path) -> tuple[str | None, str | None]:
    """Infer artist/title from the canonical filename convention when tags are missing."""

    match = FILENAME_RE.match(file_path.stem)
    if not match:
        return None, None
    return match.group("artist"), match.group("title")


def collect_folder_metadata(folder: Path) -> list[dict[str, Any]]:
    """Collect metadata from every `.mp3` file in a folder."""

    records: list[dict[str, Any]] = []
    for file_path in sorted(folder.glob("*.mp3"), key=lambda path: path.name.lower()):
        parsed = MutagenFile(file_path, easy=True)
        artist, title = _artist_title_from_filename(file_path)

        if parsed is not None:
            artist = _first_tag(parsed, "artist") or artist
            title = _first_tag(parsed, "title") or title

        info = getattr(parsed, "info", None)
        duration_seconds = None
        bitrate_kbps = None
        if info is not None:
            length = getattr(info, "length", None)
            bitrate = getattr(info, "bitrate", None)
            if isinstance(length, (int, float)):
                duration_seconds = round(float(length), 3)
            if isinstance(bitrate, (int, float)) and bitrate > 0:
                bitrate_kbps = int(round(float(bitrate) / 1000))

        records.append(
            {
                "file_name": file_path.name,
                "artist": artist,
                "title": title,
                "album": _first_tag(parsed, "album"),
                "genres": _tag_values(parsed, "genre"),
                "track_number": _first_tag(parsed, "tracknumber"),
                "duration_seconds": duration_seconds,
                "bitrate_kbps": bitrate_kbps,
                "file_size_bytes": file_path.stat().st_size,
            }
        )

    return records


def export_folder_metadata(folder: Path, output_path: Path) -> int:
    """Write all `.mp3` metadata rows from `folder` into `output_path` as JSON."""

    records = collect_folder_metadata(folder)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(
        json.dumps(records, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    return len(records)


def save_metadata_rows(path: Path, rows: list[dict[str, Any]]) -> None:
    """Persist metadata rows to a JSON file using stable pretty formatting."""

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(rows, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )


def load_metadata_rows(path: Path) -> list[dict[str, Any]]:
    """Load metadata rows from a JSON file, returning an empty list on invalid data."""

    if not path.exists():
        return []
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return []
    if not isinstance(value, list):
        return []
    return [row for row in value if isinstance(row, dict)]


def _normalized_track_number(value: str | int | None) -> str | None:
    """Normalize track-number values into a writeable ID3 representation."""

    if value is None:
        return None
    text = str(value).strip()
    return text or None


def write_mp3_tags(
    file_path: Path,
    artist: str,
    title: str,
    album: str | None = None,
    track_number: str | int | None = None,
    release_date: str | None = None,
    isrc: str | None = None,
    artwork_url: str | None = None,
    genres: tuple[str, ...] | list[str] | None = None,
) -> None:
    """Write basic ID3 tags to an MP3 file, creating an ID3 header when missing."""

    try:
        tags = EasyID3(file_path)
    except ID3NoHeaderError:
        tags = EasyID3()
        tags.save(file_path)
        tags = EasyID3(file_path)

    tags["artist"] = [artist]
    tags["title"] = [title]
    if album:
        tags["album"] = [album]

    normalized_track = _normalized_track_number(track_number)
    if normalized_track:
        tags["tracknumber"] = [normalized_track]
    if release_date:
        tags["date"] = [release_date]
    if genres:
        tags["genre"] = [value for value in genres if value]

    tags.save()

    if not isrc and not artwork_url:
        return

    id3 = ID3(file_path)
    if isrc:
        id3.delall("TSRC")
        id3.add(TSRC(encoding=3, text=[isrc]))

    if artwork_url and artwork_url.startswith(("http://", "https://")):
        try:
            response = requests.get(artwork_url, timeout=15)
            if response.ok and response.content:
                mime_type = response.headers.get("Content-Type") or "image/jpeg"
                id3.delall("APIC")
                id3.add(
                    APIC(
                        encoding=3,
                        mime=mime_type,
                        type=3,
                        desc="Cover",
                        data=response.content,
                    )
                )
        except requests.RequestException:
            pass

    id3.save(file_path)


def backfill_missing_mp3_tags(
    file_path: Path,
    artist: str | None = None,
    title: str | None = None,
    album: str | None = None,
    track_number: str | int | None = None,
    release_date: str | None = None,
    isrc: str | None = None,
    artwork_url: str | None = None,
    genres: tuple[str, ...] | list[str] | None = None,
) -> bool:
    """Fill only missing ID3 fields on an MP3 file, preserving existing values."""

    changed = False

    try:
        tags = EasyID3(file_path)
    except ID3NoHeaderError:
        tags = EasyID3()
        tags.save(file_path)
        tags = EasyID3(file_path)

    def _set_if_missing(key: str, values: list[str]) -> None:
        nonlocal changed
        if tags.get(key):
            return
        cleaned = [value for value in values if value]
        if not cleaned:
            return
        tags[key] = cleaned
        changed = True

    _set_if_missing("artist", [artist or ""])
    _set_if_missing("title", [title or ""])
    _set_if_missing("album", [album or ""])
    normalized_track = _normalized_track_number(track_number)
    _set_if_missing("tracknumber", [normalized_track or ""])
    _set_if_missing("date", [release_date or ""])
    if genres:
        _set_if_missing("genre", [value for value in genres if value])

    if changed:
        tags.save()

    id3 = ID3(file_path)
    id3_changed = False
    if isrc and not id3.getall("TSRC"):
        id3.add(TSRC(encoding=3, text=[isrc]))
        id3_changed = True

    if (
        artwork_url
        and artwork_url.startswith(("http://", "https://"))
        and not id3.getall("APIC")
    ):
        try:
            response = requests.get(artwork_url, timeout=15)
            if response.ok and response.content:
                mime_type = response.headers.get("Content-Type") or "image/jpeg"
                id3.add(
                    APIC(
                        encoding=3,
                        mime=mime_type,
                        type=3,
                        desc="Cover",
                        data=response.content,
                    )
                )
                id3_changed = True
        except requests.RequestException:
            pass

    if id3_changed:
        id3.save(file_path)

    return changed or id3_changed


def tag_folder_files(
    folder: Path,
    metadata_rows: list[dict[str, Any]] | None = None,
    default_album: str | None = None,
) -> tuple[int, int]:
    """Write tags for all `.mp3` files in a folder using metadata rows or filename fallback."""

    rows_by_name: dict[str, dict[str, Any]] = {}
    for row in metadata_rows or []:
        name = row.get("file_name")
        if isinstance(name, str) and name:
            rows_by_name[name] = row

    tagged = 0
    skipped = 0

    for file_path in sorted(folder.glob("*.mp3"), key=lambda path: path.name.lower()):
        row = rows_by_name.get(file_path.name, {})
        file_artist, file_title = _artist_title_from_filename(file_path)
        artist = row.get("artist") or file_artist
        title = row.get("title") or file_title
        album = row.get("album") or default_album
        track_number = row.get("track_number")
        release_date = row.get("release_date")
        isrc = row.get("isrc")
        artwork_url = row.get("artwork_url")
        genres = row.get("genres")
        if not genres and row.get("genre"):
            genres = [row.get("genre")]
        if not isinstance(genres, list):
            genres = []

        if not artist or not title:
            skipped += 1
            continue

        write_mp3_tags(
            file_path,
            artist=str(artist),
            title=str(title),
            album=str(album) if album else None,
            track_number=track_number,
            release_date=str(release_date) if release_date else None,
            isrc=str(isrc) if isrc else None,
            artwork_url=str(artwork_url) if artwork_url else None,
            genres=tuple(str(value) for value in genres if str(value).strip()),
        )
        tagged += 1

    return tagged, skipped
