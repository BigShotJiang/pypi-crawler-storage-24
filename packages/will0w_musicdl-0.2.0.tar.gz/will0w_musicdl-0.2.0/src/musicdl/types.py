"""Shared data models and normalization helpers used across the application."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Song:
    """Normalized representation of a single requested track."""

    artist: str
    title: str
    duration_seconds: int | None = None
    source_url: str | None = None
    album: str | None = None
    track_number: int | None = None
    release_date: str | None = None
    isrc: str | None = None
    artwork_url: str | None = None
    genres: tuple[str, ...] | None = None

    @property
    def key(self) -> str:
        """Return the normalized song identifier used in persistent state files."""

        return f"{normalize_text(self.artist)}::{normalize_text(self.title)}"


@dataclass(frozen=True)
class Playlist:
    """Resolved playlist metadata and ordered song list from a provider."""

    source: str
    name: str
    songs: list[Song]


@dataclass(frozen=True)
class DownloadResult:
    """Outcome of attempting to download a single song."""

    song: Song
    success: bool
    file_path: Path | None = None
    source_used: str | None = None
    error: str | None = None
    matched_title: str | None = None
    matched_artist: str | None = None
    matched_url: str | None = None


def normalize_text(value: str) -> str:
    """Normalize free-form text for stable key generation and comparisons."""

    return " ".join(value.strip().lower().split())
