"""Module entrypoint for `python -m musicdl`."""

from musicdl.cli import main

raise SystemExit(main())
