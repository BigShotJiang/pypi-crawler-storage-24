"""CLI orchestration for playlist resolution, download execution, and log updates."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from musicdl.downloader.engine import DownloadEngine
from musicdl.enrichment import enrich_metadata_rows
from musicdl.errors import MusicDLError
from musicdl.fs import mark_downloaded, mark_failed, sync_logs_with_folder
from musicdl.metadata import (
    backfill_missing_mp3_tags,
    collect_folder_metadata,
    export_folder_metadata,
    load_metadata_rows,
    save_metadata_rows,
    tag_folder_files,
    write_mp3_tags,
)
from musicdl.providers.resolver import ProviderResolver
from musicdl.styles import clear_update, colorize, print_update
from musicdl.types import Song


def result_time(path: Path) -> str:
    """Return an ISO-8601 UTC timestamp for a downloaded file's mtime."""

    return (
        datetime.fromtimestamp(path.stat().st_mtime, timezone.utc)
        .isoformat(timespec="seconds")
        .replace("+00:00", "Z")
    )


def build_parser() -> argparse.ArgumentParser:
    """Construct the command-line parser for the `musicdl` executable."""

    parser = argparse.ArgumentParser(
        prog="musicdl",
        description="Download music tracks from a playlist URL or .txt playlist file.",
    )
    parser.add_argument("playlist", nargs="?", help="Playlist URL or path to .txt file")
    parser.add_argument(
        "-o",
        "--output",
        default=".",
        help="Output folder where music and logs are written (default: current folder)",
    )
    parser.add_argument(
        "--max-songs",
        type=int,
        default=0,
        help="Optional limit for testing; 0 means all songs",
    )
    parser.add_argument(
        "--download-failed",
        action="store_true",
        help="Retry only songs currently listed in failed.json for this output folder",
    )
    parser.add_argument(
        "--metadata-folder",
        help="Scan all .mp3 files in a folder and export metadata JSON",
    )
    parser.add_argument(
        "--metadata-output",
        help="Output JSON path for metadata export (default: <metadata-folder>/metadata.json)",
    )
    parser.add_argument(
        "--tag-folder",
        help="Write artist/title ID3 tags for all .mp3 files in a folder",
    )
    parser.add_argument(
        "--tag-metadata",
        help="Optional metadata JSON path used by --tag-folder (for album/track and overrides)",
    )
    parser.add_argument(
        "--artist",
        help="Artist name for single-song download (requires --title)",
    )
    parser.add_argument(
        "--title",
        help="Track title for single-song download (requires --artist)",
    )
    parser.add_argument(
        "--album",
        help="Album name for single-song download (optional, use with --artist and --title)",
    )
    parser.add_argument(
        "--search",
        type=int,
        metavar="N",
        help="Search for N candidates and interactively pick one to download (requires --artist or --title)",
    )
    return parser


def _format_duration(seconds: object) -> str:
    """Format a duration in seconds as M:SS, or '?' if unavailable."""
    if not isinstance(seconds, (int, float)):
        return "?"
    total = int(seconds)
    return f"{total // 60}:{total % 60:02d}"


def _handle_search(args: argparse.Namespace) -> int:
    """Run the interactive search workflow and return a process exit code."""

    if not args.artist and not args.title:
        print(
            colorize(
                "error",
                "--search requires at least --artist or --title.",
            )
        )
        return 2

    if args.search < 1:
        print(colorize("error", "--search must be a positive integer."))
        return 2

    if args.playlist or args.download_failed:
        print(
            colorize(
                "error",
                "--search cannot be combined with a playlist or --download-failed.",
            )
        )
        return 2

    artist = args.artist or ""
    title = args.title or ""
    song = Song(artist=artist, title=title, album=args.album)

    output_dir = Path(args.output).expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    engine = DownloadEngine(output_dir)

    print_update(f"Searching for {song.artist} - {song.title}")
    candidates = engine.search_candidates(song, max_results=args.search)
    clear_update()

    if not candidates:
        print(colorize("fail", "No results found."))
        return 1

    # Display the numbered results table.
    print(colorize("info", f"Found {len(candidates)} result(s):\n"))
    print(f"  {'#':<4} {'Title':<45} {'Artist':<25} {'Duration':<10} URL")
    print(f"  {'─'*4} {'─'*45} {'─'*25} {'─'*10} {'─'*50}")
    for i, c in enumerate(candidates, start=1):
        c_title = str(c.get("title") or "?")[:44]
        c_artist = str(c.get("uploader") or c.get("artist") or "?")[:24]
        c_duration = _format_duration(c.get("duration"))
        c_url = str(c.get("webpage_url") or c.get("url") or "?")
        print(f"  {i:<4} {c_title:<45} {c_artist:<25} {c_duration:<10} {c_url}")

    print()
    try:
        choice = input(colorize("info", "Enter number to download (or 'q' to quit): "))
    except (EOFError, KeyboardInterrupt):
        print()
        return 0

    if choice.strip().lower() in ("q", "quit", ""):
        return 0

    try:
        index = int(choice.strip()) - 1
    except ValueError:
        print(colorize("error", "Invalid selection."))
        return 2

    if index < 0 or index >= len(candidates):
        print(
            colorize("error", f"Please enter a number between 1 and {len(candidates)}.")
        )
        return 2

    selected = candidates[index]
    url = str(selected.get("webpage_url") or selected.get("url") or "")
    if not url:
        print(colorize("error", "Selected candidate has no downloadable URL."))
        return 2

    # Build the Song for download, using CLI flags as overrides.
    download_song = Song(
        artist=args.artist
        or str(selected.get("uploader") or selected.get("artist") or "Unknown Artist"),
        title=args.title or str(selected.get("title") or "Unknown Title"),
        album=args.album,
        source_url=url,
        duration_seconds=(
            int(selected["duration"])
            if isinstance(selected.get("duration"), (int, float))
            else None
        ),
    )

    print_update(f"Downloading {download_song.artist} - {download_song.title}")
    result = engine.download_song(download_song)
    clear_update()

    if result.success and result.file_path:
        try:
            write_mp3_tags(
                result.file_path,
                artist=download_song.artist,
                title=download_song.title,
                album=download_song.album,
            )
        except Exception as exc:
            print(colorize("warn", f"Could not write tags: {exc}"))

        print(
            colorize(
                "ok",
                f"{download_song.artist} - {download_song.title} -> {result.file_path.name}",
            )
        )
        return 0

    message = result.error or "download failed"
    print(
        colorize("fail", f"{download_song.artist} - {download_song.title} ({message})")
    )
    return 1


def main() -> int:
    """Run the CLI command and return a process exit code."""

    parser = build_parser()
    args = parser.parse_args()

    if args.metadata_folder:
        if args.playlist:
            print(
                colorize(
                    "error",
                    "Do not provide a playlist when using --metadata-folder.",
                )
            )
            return 2
        if args.download_failed:
            print(
                colorize(
                    "error",
                    "--download-failed cannot be combined with --metadata-folder.",
                )
            )
            return 2

        metadata_folder = Path(args.metadata_folder).expanduser().resolve()
        if not metadata_folder.is_dir():
            print(
                colorize(
                    "error",
                    f"Metadata folder not found: {metadata_folder}",
                )
            )
            return 2

        metadata_output = (
            Path(args.metadata_output).expanduser().resolve()
            if args.metadata_output
            else metadata_folder / "metadata.json"
        )
        print_update("Extracting metadata from folder")
        total = export_folder_metadata(metadata_folder, metadata_output)
        clear_update()
        print(colorize("done", f"metadata rows: {total}"))
        print(colorize("done", f"metadata file: {metadata_output}"))
        return 0

    if args.tag_folder:
        if args.playlist:
            print(
                colorize(
                    "error",
                    "Do not provide a playlist when using --tag-folder.",
                )
            )
            return 2
        if args.download_failed:
            print(
                colorize(
                    "error",
                    "--download-failed cannot be combined with --tag-folder.",
                )
            )
            return 2

        tag_folder = Path(args.tag_folder).expanduser().resolve()
        if not tag_folder.is_dir():
            print(colorize("error", f"Tag folder not found: {tag_folder}"))
            return 2

        metadata_save_path = tag_folder / "metadata.json"
        enriched_count = 0

        # --- Step 1: load any existing sidecar ---
        sidecar_rows: list[Any] = []
        metadata_source = "folder-scan"
        if args.tag_metadata:
            metadata_path = Path(args.tag_metadata).expanduser().resolve()
            metadata_save_path = metadata_path
            sidecar_rows = load_metadata_rows(metadata_path)
            if not sidecar_rows:
                print(
                    colorize(
                        "warn",
                        "Tag metadata file is missing/invalid/empty; will build from tags/filenames.",
                    )
                )
            else:
                metadata_source = str(metadata_path)
        else:
            for candidate in (
                tag_folder / "metadata.json",
                tag_folder / "downloaded.json",
            ):
                sidecar_rows = load_metadata_rows(candidate)
                if sidecar_rows:
                    metadata_source = str(candidate)
                    if candidate.name == "metadata.json":
                        metadata_save_path = candidate
                    break

        if not sidecar_rows:
            print(
                colorize(
                    "warn",
                    "No metadata sidecar found; building from existing tags/filenames.",
                )
            )

        # --- Step 2: always scan folder so newly added songs are included ---
        print_update("Scanning folder for MP3 files")
        folder_rows = collect_folder_metadata(tag_folder)
        clear_update()

        # --- Step 3: merge – prefer sidecar data for existing files ---
        sidecar_by_name = {
            row["file_name"]: row
            for row in sidecar_rows
            if isinstance(row.get("file_name"), str) and row["file_name"]
        }
        metadata_rows = [
            sidecar_by_name.get(str(row.get("file_name")), row) for row in folder_rows
        ]

        new_count = sum(
            1 for row in folder_rows if str(row.get("file_name")) not in sidecar_by_name
        )
        if new_count:
            print(colorize("info", f"New files not yet in sidecar: {new_count}"))

        # --- Step 4: enrich with checkpointing ---
        def _checkpoint(rows: list[Any]) -> None:
            try:
                save_metadata_rows(metadata_save_path, rows)
            except Exception:
                pass

        try:
            metadata_rows, enriched_count = enrich_metadata_rows(
                metadata_rows,
                progress=print_update,
                checkpoint_fn=_checkpoint,
                checkpoint_every=100,
            )
        except Exception as exc:
            clear_update()
            print(
                colorize(
                    "warn",
                    f"Online metadata enrichment failed; continuing with local metadata only ({exc}).",
                )
            )

        try:
            save_metadata_rows(metadata_save_path, metadata_rows)
        except Exception as exc:
            clear_update()
            print(
                colorize(
                    "warn",
                    f"Could not persist metadata sidecar: {exc}",
                )
            )

        print_update("Writing ID3 tags")
        try:
            tagged, skipped = tag_folder_files(tag_folder, metadata_rows=metadata_rows)
        except Exception as exc:
            clear_update()
            print(colorize("error", f"Could not tag folder: {exc}"))
            return 2

        clear_update()
        print(colorize("info", f"metadata source: {metadata_source}"))
        print(colorize("info", f"metadata saved: {metadata_save_path}"))
        print(colorize("info", f"metadata enriched online: {enriched_count}"))
        print(colorize("done", f"tagged files: {tagged}"))
        print(colorize("done", f"skipped files: {skipped}"))
        return 0

    # --- Interactive search mode ---
    if args.search is not None:
        return _handle_search(args)

    # --- Validate --artist / --title / --album flags ---
    has_metadata_flags = args.artist or args.title or args.album
    has_single_song = args.artist and args.title and not args.playlist
    has_url_with_overrides = args.playlist and has_metadata_flags

    if has_metadata_flags and not args.playlist:
        if not args.artist or not args.title:
            print(
                colorize(
                    "error",
                    "--artist and --title must both be provided for single-song download.",
                )
            )
            return 2

    if has_url_with_overrides and args.album and not args.artist:
        # --album with a URL but without --artist is fine; it overrides album only.
        pass

    if has_single_song and args.download_failed:
        print(
            colorize(
                "error",
                "--download-failed cannot be combined with --artist/--title.",
            )
        )
        return 2

    if args.album and not args.playlist and not (args.artist and args.title):
        print(
            colorize(
                "error",
                "--album requires --artist and --title, or a URL.",
            )
        )
        return 2

    output_dir = Path(args.output).expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    print_update("Scanning output folder and loading logs")
    downloaded, failed = sync_logs_with_folder(output_dir)
    engine = DownloadEngine(output_dir)

    songs: list[Song]
    provider_name = "n/a"
    playlist_name = "failed songs"
    total_discovered: int | None = None

    if has_single_song:
        songs = [Song(artist=args.artist, title=args.title, album=args.album)]
        provider_name = "cli"
        playlist_name = f"{args.artist} - {args.title}"
    elif args.download_failed and not args.playlist:
        songs = []
        for record in failed.values():
            artist = record.get("artist")
            title = record.get("title")
            if artist and title:
                songs.append(Song(artist=artist, title=title))
    else:
        if not args.playlist:
            clear_update()
            print(
                colorize(
                    "error",
                    "Please provide a playlist input, or use --download-failed to retry from failed.json.",
                )
            )
            return 2

        resolver = ProviderResolver()
        try:
            print_update("Resolving playlist")
            playlist = resolver.resolve(args.playlist)
        except MusicDLError as exc:
            clear_update()
            print(colorize("error", f"Could not resolve playlist: {exc}"))
            return 2

        provider_name = playlist.source
        playlist_name = playlist.name
        total_discovered = len(playlist.songs)
        songs = playlist.songs

        # When CLI flags are given alongside a URL, they override the provider
        # values for those specific fields (the user knows the correct metadata).
        # Provider data is kept for fields the user did not supply.
        if has_url_with_overrides and songs:
            songs = [
                Song(
                    artist=args.artist or song.artist,
                    title=args.title or song.title,
                    duration_seconds=song.duration_seconds,
                    source_url=song.source_url,
                    album=args.album or song.album,
                    track_number=song.track_number,
                    release_date=song.release_date,
                    isrc=song.isrc,
                    artwork_url=song.artwork_url,
                    genres=song.genres,
                )
                for song in songs
            ]

    if args.download_failed and args.playlist:
        failed_keys = set(failed.keys())
        songs = [song for song in songs if song.key in failed_keys]

    if args.max_songs and args.max_songs > 0:
        songs = songs[: args.max_songs]

    if args.download_failed and not songs:
        clear_update()
        print(colorize("info", "No failed songs to retry."))
        return 0

    clear_update()
    print(colorize("info", f"Provider: {provider_name}"))
    print(colorize("info", f"Playlist: {playlist_name}"))
    if total_discovered is not None:
        print(colorize("info", f"Total songs discovered: {total_discovered}"))

    print(colorize("info", f"Songs queued this run: {len(songs)}"))

    skipped = 0
    success = 0
    failed_count = 0

    def _backfill_existing(song: Song, path: Path) -> None:
        """Fill missing tags on an existing file without overwriting present metadata."""

        try:
            backfill_missing_mp3_tags(
                path,
                artist=song.artist,
                title=song.title,
                album=song.album,
                track_number=song.track_number,
                release_date=song.release_date,
                isrc=song.isrc,
                artwork_url=song.artwork_url,
                genres=song.genres,
            )
        except Exception as exc:
            print(
                colorize(
                    "warn",
                    f"Could not backfill tags for {path.name}: {exc}",
                )
            )

    for index, song in enumerate(songs, start=1):
        if song.key in downloaded:
            existing_name = downloaded[song.key].get("file_name")
            if isinstance(existing_name, str) and existing_name:
                existing_path = output_dir / existing_name
                if existing_path.exists():
                    _backfill_existing(song, existing_path)
            clear_update()
            skipped += 1
            print(
                colorize(
                    "skip",
                    f"{index}/{len(songs)} {song.artist} - {song.title} (already downloaded)",
                )
            )
            continue

        target_file = engine.target_file_path(song)
        if target_file.exists():
            _backfill_existing(song, target_file)
            clear_update()
            skipped += 1
            mark_downloaded(
                output_dir,
                downloaded,
                failed,
                song,
                file_name=target_file.name,
                source="filename-exists",
                downloaded_at=result_time(target_file),
            )
            print(
                colorize(
                    "skip",
                    f"{index}/{len(songs)} {song.artist} - {song.title} (target file exists)",
                )
            )
            continue

        clear_update()
        print(colorize("try", f"{index}/{len(songs)} {song.artist} - {song.title}"))
        result = engine.download_song(song)

        if result.success and result.file_path:
            clear_update()
            success += 1
            try:
                write_mp3_tags(
                    result.file_path,
                    artist=song.artist,
                    title=song.title,
                    album=song.album,
                    track_number=song.track_number,
                    release_date=song.release_date,
                    isrc=song.isrc,
                    artwork_url=song.artwork_url,
                    genres=song.genres,
                )
            except Exception as exc:
                print(
                    colorize(
                        "warn",
                        f"Could not write tags for {result.file_path.name}: {exc}",
                    )
                )
            mark_downloaded(
                output_dir,
                downloaded,
                failed,
                song,
                file_name=result.file_path.name,
                source=result.source_used or "unknown",
                matched_title=result.matched_title,
                matched_artist=result.matched_artist,
                matched_url=result.matched_url,
                downloaded_at=result_time(result.file_path),
            )
            print(
                colorize(
                    "ok",
                    f"{song.artist} - {song.title} via {result.source_used} -> {result.file_path.name}",
                )
            )
        else:
            clear_update()
            failed_count += 1
            message = result.error or "all source attempts failed"
            mark_failed(output_dir, failed, song, message)
            print(colorize("fail", f"{song.artist} - {song.title} ({message})"))

        clear_update()
    print(colorize("done", ""))
    print(colorize("done", f"downloaded: {success}"))
    print(colorize("done", f"skipped: {skipped}"))
    print(colorize("done", f"failed: {failed_count}"))
    print(
        colorize(
            "done",
            f"logs: {output_dir / 'downloaded.json'} | {output_dir / 'failed.json'}",
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
