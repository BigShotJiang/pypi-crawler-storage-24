"""Domain-specific exceptions used across playlist resolution and downloading."""


class MusicDLError(Exception):
    """Base error for musicdl."""


class PlaylistResolutionError(MusicDLError):
    """Raised when a playlist cannot be resolved."""


class PlaylistPrivateError(PlaylistResolutionError):
    """Raised when a playlist exists but cannot be accessed due to privacy."""


class PlaylistNotFoundError(PlaylistResolutionError):
    """Raised when a playlist does not exist."""
