"""Spotify playlist resolution using public web-facing Spotify endpoints."""

from __future__ import annotations

from dataclasses import replace
import json
from pathlib import Path
import re
import time
from urllib.parse import parse_qs, urlparse

import requests
import threading

# --- Global Spotify API rate limiting (1 req/sec, shared for all calls) ---
_spotify_last_call = 0.0
_spotify_lock = threading.Lock()
_SPOTIFY_MIN_INTERVAL = 1.1  # seconds
_SPOTIFY_V1_COOLDOWN_FILE = Path.home() / ".cache" / "musicdl" / "spotify_v1.json"
_SPOTIFY_GENRE_CACHE_FILE = (
    Path.home() / ".cache" / "musicdl" / "spotify_artist_genres.json"
)


def _wait_before_spotify() -> None:
    global _spotify_last_call
    with _spotify_lock:
        now = time.monotonic()
        elapsed = now - _spotify_last_call
        if elapsed < _SPOTIFY_MIN_INTERVAL:
            time.sleep(_SPOTIFY_MIN_INTERVAL - elapsed)
        _spotify_last_call = time.monotonic()


def _read_spotify_v1_cooldown() -> float | None:
    """Return the active Spotify v1 cooldown-until timestamp, if any."""

    if not _SPOTIFY_V1_COOLDOWN_FILE.exists():
        return None
    try:
        payload = json.loads(_SPOTIFY_V1_COOLDOWN_FILE.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    until = payload.get("until") if isinstance(payload, dict) else None
    if not isinstance(until, (int, float)):
        return None
    if until <= time.time():
        try:
            _SPOTIFY_V1_COOLDOWN_FILE.unlink()
        except OSError:
            pass
        return None
    return float(until)


def _write_spotify_v1_cooldown(retry_after: int) -> None:
    """Persist a Spotify v1 cooldown window so later runs avoid banned endpoints."""

    _SPOTIFY_V1_COOLDOWN_FILE.parent.mkdir(parents=True, exist_ok=True)
    payload = {"until": time.time() + max(retry_after, 0)}
    _SPOTIFY_V1_COOLDOWN_FILE.write_text(
        json.dumps(payload),
        encoding="utf-8",
    )


def _spotify_v1_rate_limit_message(seconds_remaining: float) -> str:
    """Format a human-readable Spotify v1 cooldown message."""

    hours = max(1, round(seconds_remaining / 3600))
    return f"Spotify v1 API rate-limited for ~{hours:.0f}h."


def _load_spotify_genre_cache() -> dict[str, tuple[str, ...]]:
    """Load the persistent Spotify artist genre cache."""

    if not _SPOTIFY_GENRE_CACHE_FILE.exists():
        return {}
    try:
        payload = json.loads(_SPOTIFY_GENRE_CACHE_FILE.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    if not isinstance(payload, dict):
        return {}

    cache: dict[str, tuple[str, ...]] = {}
    for artist_id, raw_genres in payload.items():
        if not isinstance(artist_id, str) or not artist_id:
            continue
        if not isinstance(raw_genres, list):
            continue
        cache[artist_id] = tuple(
            str(value).strip() for value in raw_genres if str(value).strip()
        )
    return cache


def _save_spotify_genre_cache(cache: dict[str, tuple[str, ...]]) -> None:
    """Persist the Spotify artist genre cache to disk."""

    _SPOTIFY_GENRE_CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
    payload = {artist_id: list(genres) for artist_id, genres in cache.items()}
    _SPOTIFY_GENRE_CACHE_FILE.write_text(
        json.dumps(payload, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )


from musicdl.errors import (
    PlaylistNotFoundError,
    PlaylistPrivateError,
    PlaylistResolutionError,
)
from musicdl.providers.base import PlaylistProvider
from musicdl.styles import print_update
from musicdl.types import Playlist, Song


class _SpotifyV1CooldownError(PlaylistResolutionError):
    """Raised when Spotify v1 is under a long-lived cooldown window."""


class _SpotifyPathfinderFallbackError(PlaylistResolutionError):
    """Raised when pathfinder transport fails and falling back to v1 is allowed."""


SPOTIFY_PLAYLIST_RE = re.compile(r"/playlist/([a-zA-Z0-9]+)")

_BROWSER_UA = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/122.0.0.0 Safari/537.36"
)

# Persisted query hash for Spotify's internal web player GraphQL.
# Covers fetchPlaylistMetadata, fetchPlaylistContents, fetchPlaylist operations.
# If this goes stale, _fetch_pathfinder_hash_from_js() can retrieve a fresh one.
_PATHFINDER_HASH = "346811f856fb0b7e4f6c59f8ebea78dd081c6e2fb01b77c954b26259d5fc6763"

# Spotify web player client ID (public, used for clienttoken endpoint)
_WEB_PLAYER_CLIENT_ID = "d8a5ed958d274c2e8ee717e6a4b0971d"


class SpotifyProvider(PlaylistProvider):
    """Resolve Spotify playlist URLs into normalized playlist metadata."""

    name = "spotify"

    def can_handle(self, playlist_input: str) -> bool:
        """Return whether the input looks like a Spotify playlist URL."""

        return "spotify.com/playlist/" in playlist_input

    def resolve(self, playlist_input: str) -> Playlist:
        """Resolve a Spotify playlist using the preferred provider flow and fallback path."""

        playlist_id = _extract_playlist_id(playlist_input)
        if not playlist_id:
            raise PlaylistResolutionError(
                "Could not parse Spotify playlist ID from URL."
            )

        errors: list[str] = []

        # Primary: Spotify internal GraphQL (api-partner) — no v1 rate limits.
        try:
            return _resolve_via_pathfinder(playlist_id)
        except (PlaylistNotFoundError, PlaylistPrivateError):
            raise
        except _SpotifyPathfinderFallbackError as exc:
            errors.append(f"pathfinder: {exc}")
        except Exception as exc:
            raise PlaylistResolutionError(str(exc))

        # Fallback: Spotify Web API v1 (may be rate-limited on heavy use).
        try:
            token = _get_token_from_embed(playlist_id)
            return _resolve_with_token(token, playlist_id)
        except (PlaylistNotFoundError, PlaylistPrivateError):
            raise
        except Exception as exc:
            errors.append(f"v1-api: {exc}")

        raise PlaylistResolutionError(
            "Could not resolve Spotify playlist. Errors: " + "; ".join(errors)
        )


# ---------------------------------------------------------------------------
# Primary resolution: api-partner.spotify.com (Spotify internal GraphQL)
# ---------------------------------------------------------------------------


def _resolve_via_pathfinder(playlist_id: str) -> Playlist:
    """Resolve a playlist via Spotify\'s internal GraphQL (api-partner.spotify.com).

    Uses the embed page Bearer token + clienttoken endpoint — both bypass the
    Cloudflare block on get_access_token and have separate rate-limit buckets
    from api.spotify.com/v1.
    """
    print_update("Spotify: acquiring playlist access token")
    embed_token = _get_token_from_embed(playlist_id)
    print_update("Spotify: acquiring client token")
    client_token = _get_client_token()
    hash_ = _PATHFINDER_HASH

    req_headers = {
        "Authorization": f"Bearer {embed_token}",
        "client-token": client_token,
        "Accept": "application/json",
        "app-platform": "WebPlayer",
        "User-Agent": _BROWSER_UA,
        "Spotify-App-Version": "1.2.52.442.g0f3f5f1c",
    }

    def _pathfinder_get(operation: str, variables: dict) -> dict:
        max_wait = 300  # 5 minutes
        wait = 2
        for attempt in range(8):
            _wait_before_spotify()
            r = requests.get(
                "https://api-partner.spotify.com/pathfinder/v1/query",
                params={
                    "operationName": operation,
                    "variables": json.dumps(variables),
                    "extensions": json.dumps(
                        {"persistedQuery": {"version": 1, "sha256Hash": hash_}}
                    ),
                },
                headers=req_headers,
                timeout=20,
            )
            if r.status_code == 404:
                raise PlaylistNotFoundError("Spotify playlist not found.")
            if r.status_code in (401, 403):
                raise PlaylistPrivateError(
                    "Spotify playlist is private or inaccessible."
                )
            if r.status_code == 429:
                retry_after = int(r.headers.get("Retry-After", "3"))
                if retry_after > max_wait:
                    raise _SpotifyPathfinderFallbackError(
                        f"Spotify API rate-limited for ~{retry_after // 3600:.0f}h."
                    )
                time.sleep(min(retry_after, 10))
                continue
            if r.status_code >= 400:
                raise _SpotifyPathfinderFallbackError(
                    f"Pathfinder {operation} failed: HTTP {r.status_code}"
                )
            d = r.json()
            if "errors" in d:
                raise _SpotifyPathfinderFallbackError(
                    f"Pathfinder GraphQL errors ({operation}): {d['errors']}"
                )
            return d
            # Exponential backoff for repeated 429s
            time.sleep(min(wait, max_wait))
            wait *= 2
        raise _SpotifyPathfinderFallbackError(
            "Spotify API repeatedly rate-limited (Pathfinder)"
        )

    # Fetch playlist name.
    playlist_name = playlist_id
    try:
        print_update("Spotify: fetching playlist metadata")
        meta_d = _pathfinder_get(
            "fetchPlaylistMetadata",
            {
                "uri": f"spotify:playlist:{playlist_id}",
                "offset": 0,
                "limit": 0,
                "enableWatchFeedEntrypoint": False,
            },
        )
        pl = (meta_d.get("data") or {}).get("playlistV2") or {}
        playlist_name = pl.get("name") or playlist_id
    except (PlaylistNotFoundError, PlaylistPrivateError):
        raise
    except Exception:
        pass  # Name is non-critical; fall through with playlist_id as name.

    # Paginate all tracks.
    songs: list[Song] = []
    artist_ids_by_song: list[str | None] = []
    limit = 100
    offset = 0

    while True:
        page_end = offset + limit
        print_update(f"Spotify: fetching tracks {offset + 1}-{page_end}")
        page_d = _pathfinder_get(
            "fetchPlaylistContents",
            {
                "uri": f"spotify:playlist:{playlist_id}",
                "offset": offset,
                "limit": limit,
            },
        )
        content = (page_d.get("data") or {}).get("playlistV2", {}).get("content", {})
        items = content.get("items") or []
        total = content.get("totalCount") or 0

        for item in items:
            data = ((item.get("itemV2") or {}).get("data")) or {}
            title = data.get("name")
            duration_ms = (data.get("duration") or {}).get("totalMilliseconds")
            artist_items = (data.get("artists") or {}).get("items") or []
            artists = [
                a.get("profile", {}).get("name")
                for a in artist_items
                if isinstance(a, dict) and a.get("profile", {}).get("name")
            ]
            primary_artist_id = _spotify_artist_id(
                _first_str(_nested_get(artist_items, 0, "uri"))
            )
            if title:
                track_uri = _first_str(
                    data.get("uri"),
                    _nested_get(data, "trackUri"),
                )
                album_name = _first_str(
                    _nested_get(data, "albumOfTrack", "name"),
                    _nested_get(data, "album", "name"),
                )
                track_number = _first_int(
                    data.get("trackNumber"),
                    _nested_get(data, "albumOfTrack", "trackNumber"),
                )
                release_date = _first_str(
                    _nested_get(data, "albumOfTrack", "date", "isoString"),
                    _nested_get(data, "album", "date", "isoString"),
                    _nested_get(data, "albumOfTrack", "releaseDate"),
                )
                isrc = _first_str(
                    _nested_get(data, "externalIds", "isrc"),
                    _nested_get(data, "externalId", "isrc"),
                )
                artwork_url = _first_str(
                    _nested_get(data, "albumOfTrack", "coverArt", "sources", 0, "url"),
                    _nested_get(data, "album", "coverArt", "sources", 0, "url"),
                )
                songs.append(
                    Song(
                        artist=", ".join(artists) or "Unknown Artist",
                        title=str(title),
                        duration_seconds=(
                            int(duration_ms / 1000)
                            if isinstance(duration_ms, (int, float))
                            else None
                        ),
                        source_url=_spotify_track_url(track_uri),
                        album=album_name,
                        track_number=track_number,
                        release_date=release_date,
                        isrc=isrc,
                        artwork_url=artwork_url,
                    )
                )
                artist_ids_by_song.append(primary_artist_id)

        offset += limit
        if not items or offset >= total:
            break

    if not songs:
        raise PlaylistResolutionError(
            "Spotify playlist appears to contain no downloadable tracks."
        )

    try:
        genre_map = _fetch_artist_genres(embed_token, artist_ids_by_song)
    except Exception as exc:
        print_update(f"[warn] Skipping genre enrichment due to v1 API error: {exc}")
        genre_map = {}
    songs = [
        (
            replace(song, genres=genre_map.get(artist_id))
            if artist_id and genre_map.get(artist_id)
            else song
        )
        for song, artist_id in zip(songs, artist_ids_by_song)
    ]

    return Playlist(source="spotify", name=playlist_name, songs=songs)


def _get_client_token() -> str:
    """Obtain a short-lived client token from clienttoken.spotify.com with rate limiting and retry."""
    max_wait = 300
    wait = 2
    for attempt in range(8):
        _wait_before_spotify()
        response = requests.post(
            "https://clienttoken.spotify.com/v1/clienttoken",
            json={
                "client_data": {
                    "client_version": "1.2.52.442.g0f3f5f1c",
                    "client_id": _WEB_PLAYER_CLIENT_ID,
                    "js_sdk_data": {
                        "device_brand": "unknown",
                        "device_model": "desktop",
                        "os": "Windows",
                        "os_version": "NT 10.0",
                    },
                }
            },
            headers={
                "User-Agent": _BROWSER_UA,
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
            timeout=20,
        )
        if response.status_code == 429:
            retry_after = int(response.headers.get("Retry-After", "3"))
            if retry_after > max_wait:
                raise _SpotifyPathfinderFallbackError(
                    f"Spotify client token rate-limited for ~{retry_after // 3600:.0f}h."
                )
            time.sleep(min(retry_after, 10))
            continue
        if response.status_code >= 400:
            raise _SpotifyPathfinderFallbackError(
                f"Spotify client token request failed: HTTP {response.status_code}"
            )
        token = (response.json().get("granted_token") or {}).get("token")
        if not token:
            raise _SpotifyPathfinderFallbackError(
                "Could not parse Spotify client token."
            )
        return token
        time.sleep(min(wait, max_wait))
        wait *= 2
    raise _SpotifyPathfinderFallbackError(
        "Spotify client token repeatedly rate-limited"
    )


# ---------------------------------------------------------------------------
# Fallback resolution: Spotify Web API v1
# ---------------------------------------------------------------------------


def _resolve_with_token(token: str, playlist_id: str) -> Playlist:
    """Fetch the full playlist via the Spotify Web API v1 using a bearer token."""
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/json",
    }

    base_url = f"https://api.spotify.com/v1/playlists/{playlist_id}"
    meta_resp = _v1_get(base_url, headers=headers, timeout=20)
    if meta_resp.status_code == 404:
        raise PlaylistNotFoundError("Spotify playlist not found.")
    if meta_resp.status_code in (401, 403):
        raise PlaylistPrivateError("Spotify playlist is private or inaccessible.")
    if meta_resp.status_code >= 400:
        raise PlaylistResolutionError(
            f"Spotify v1 metadata request failed: HTTP {meta_resp.status_code}"
        )

    metadata = meta_resp.json()
    playlist_name = metadata.get("name") or playlist_id

    songs: list[Song] = []
    artist_ids_by_song: list[str | None] = []
    limit = 100
    offset = 0

    while True:
        tracks_url = f"{base_url}/tracks?limit={limit}&offset={offset}"
        tracks_resp = _v1_get(tracks_url, headers=headers, timeout=20)
        if tracks_resp.status_code == 404:
            raise PlaylistNotFoundError("Spotify playlist tracks not found.")
        if tracks_resp.status_code in (401, 403):
            raise PlaylistPrivateError(
                "Spotify playlist tracks are private or inaccessible."
            )
        if tracks_resp.status_code >= 400:
            raise PlaylistResolutionError(
                f"Spotify v1 tracks request failed at offset {offset}: "
                f"HTTP {tracks_resp.status_code}"
            )

        payload = tracks_resp.json()
        items = payload.get("items") or []
        if not items:
            break

        for item in items:
            track = (item or {}).get("track") or {}
            title = track.get("name")
            duration_ms = track.get("duration_ms")
            artists = track.get("artists") or []
            artist = ", ".join(a.get("name", "") for a in artists if a.get("name"))
            primary_artist_id = None
            if isinstance(artists, list) and artists:
                first_artist = artists[0] if isinstance(artists[0], dict) else {}
                if isinstance(first_artist, dict):
                    candidate_id = first_artist.get("id")
                    if isinstance(candidate_id, str) and candidate_id:
                        primary_artist_id = candidate_id
            if title:
                album = track.get("album") or {}
                images = album.get("images") or []
                artwork_url = None
                if isinstance(images, list) and images:
                    first_image = images[0] if isinstance(images[0], dict) else {}
                    artwork_url = first_image.get("url")
                songs.append(
                    Song(
                        artist=artist or "Unknown Artist",
                        title=title,
                        duration_seconds=(
                            int(duration_ms / 1000)
                            if isinstance(duration_ms, (int, float))
                            else None
                        ),
                        source_url=(track.get("external_urls") or {}).get("spotify"),
                        album=album.get("name") if isinstance(album, dict) else None,
                        track_number=(
                            int(track.get("track_number"))
                            if isinstance(track.get("track_number"), int)
                            else None
                        ),
                        release_date=(
                            album.get("release_date")
                            if isinstance(album, dict)
                            else None
                        ),
                        isrc=(track.get("external_ids") or {}).get("isrc"),
                        artwork_url=artwork_url,
                    )
                )
                artist_ids_by_song.append(primary_artist_id)

        offset += limit
        total = payload.get("total")
        if isinstance(total, int) and offset >= total:
            break

    if not songs:
        raise PlaylistResolutionError(
            "Spotify playlist appears to contain no downloadable tracks."
        )

    try:
        genre_map = _fetch_artist_genres(token, artist_ids_by_song)
    except Exception as exc:
        print_update(f"[warn] Skipping genre enrichment due to v1 API error: {exc}")
        genre_map = {}
    songs = [
        (
            replace(song, genres=genre_map.get(artist_id))
            if artist_id and genre_map.get(artist_id)
            else song
        )
        for song, artist_id in zip(songs, artist_ids_by_song)
    ]

    return Playlist(source="spotify", name=playlist_name, songs=songs)


def _v1_get(url: str, headers: dict, timeout: int = 20) -> requests.Response:
    """GET with robust 429-aware retry and global rate limiting for the v1 API."""
    max_wait = 300  # 5 minutes
    wait = 2
    cooldown_until = _read_spotify_v1_cooldown()
    if cooldown_until is not None:
        raise _SpotifyV1CooldownError(
            _spotify_v1_rate_limit_message(cooldown_until - time.time())
        )
    for attempt in range(8):
        _wait_before_spotify()
        response = requests.get(url, headers=headers, timeout=timeout)
        if response.status_code == 429:
            retry_after = int(response.headers.get("Retry-After", "3"))
            if retry_after > max_wait:
                _write_spotify_v1_cooldown(retry_after)
                raise _SpotifyV1CooldownError(
                    _spotify_v1_rate_limit_message(retry_after)
                )
            time.sleep(min(retry_after, 10))
            continue
        if response.status_code >= 400:
            raise PlaylistResolutionError(
                f"Spotify v1 API failed: HTTP {response.status_code}"
            )
        return response
        # Exponential backoff for repeated 429s
        time.sleep(min(wait, max_wait))
        wait *= 2
    raise PlaylistResolutionError("Spotify v1 API repeatedly rate-limited")


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _extract_playlist_id(url: str) -> str | None:
    """Extract a Spotify playlist ID from supported Spotify URL formats."""

    matched = SPOTIFY_PLAYLIST_RE.search(url)
    if matched:
        return matched.group(1)

    parsed = urlparse(url)
    if parsed.scheme == "spotify" and parsed.netloc == "playlist":
        return parsed.path.strip("/")

    query = parse_qs(parsed.query)
    if "si" in query and parsed.path:
        parts = parsed.path.strip("/").split("/")
        if len(parts) >= 2 and parts[-2] == "playlist":
            return parts[-1]
    return None


def _get_token_from_embed(playlist_id: str) -> str:
    """Extract a Bearer token embedded in the Spotify playlist embed page HTML, with rate limiting and retry."""
    max_wait = 300
    wait = 2
    for attempt in range(8):
        _wait_before_spotify()
        response = requests.get(
            f"https://open.spotify.com/embed/playlist/{playlist_id}",
            headers={"User-Agent": _BROWSER_UA},
            timeout=20,
        )
        if response.status_code == 429:
            retry_after = int(response.headers.get("Retry-After", "3"))
            if retry_after > max_wait:
                raise PlaylistResolutionError(
                    f"Spotify embed page rate-limited for ~{retry_after // 3600:.0f}h."
                )
            time.sleep(min(retry_after, 10))
            continue
        if response.status_code >= 400:
            raise PlaylistResolutionError(
                f"Spotify embed page request failed: HTTP {response.status_code}"
            )
        match = re.search(
            r'"accessToken"\s*:\s*"([A-Za-z0-9._\-]{20,})"', response.text
        )
        if not match:
            raise PlaylistResolutionError(
                "Could not locate an access token in the Spotify embed page."
            )
        return match.group(1)
        time.sleep(min(wait, max_wait))
        wait *= 2
    raise PlaylistResolutionError("Spotify embed repeatedly rate-limited")


def _spotify_track_url(track_uri: str | None) -> str | None:
    """Convert `spotify:track:<id>` URIs into canonical HTTPS track URLs."""

    if not track_uri:
        return None
    if track_uri.startswith("https://"):
        return track_uri
    if not track_uri.startswith("spotify:track:"):
        return None
    track_id = track_uri.rsplit(":", 1)[-1]
    if not track_id:
        return None
    return f"https://open.spotify.com/track/{track_id}"


def _nested_get(data: object, *path: object) -> object | None:
    """Safely walk nested dict/list data structures using a mixed key/index path."""

    current = data
    for key in path:
        if isinstance(key, int):
            if not isinstance(current, list) or key >= len(current):
                return None
            current = current[key]
            continue
        if not isinstance(current, dict):
            return None
        current = current.get(key)
        if current is None:
            return None
    return current


def _first_str(*values: object) -> str | None:
    """Return the first non-empty string representation from a value list."""

    for value in values:
        if isinstance(value, str) and value.strip():
            return value.strip()
    return None


def _first_int(*values: object) -> int | None:
    """Return the first int-like value from a list of candidates."""

    for value in values:
        if isinstance(value, int):
            return value
        if isinstance(value, str) and value.isdigit():
            return int(value)
    return None


def _spotify_artist_id(value: str | None) -> str | None:
    """Convert Spotify artist URI/URL identifiers into bare artist IDs."""

    if not value:
        return None
    if value.startswith("spotify:artist:"):
        artist_id = value.rsplit(":", 1)[-1]
        return artist_id or None
    match = re.search(r"/artist/([A-Za-z0-9]+)", value)
    if match:
        return match.group(1)
    return None


def _fetch_artist_genres(
    token: str, artist_ids_by_song: list[str | None]
) -> dict[str, tuple[str, ...]]:
    """Fetch artist genre metadata via Spotify v1 API in batched requests."""

    unique_ids = sorted({artist_id for artist_id in artist_ids_by_song if artist_id})
    if not unique_ids:
        return {}

    genre_cache = _load_spotify_genre_cache()
    headers = {"Authorization": f"Bearer {token}", "Accept": "application/json"}
    genres_by_artist_id = {
        artist_id: genre_cache[artist_id]
        for artist_id in unique_ids
        if artist_id in genre_cache and genre_cache[artist_id]
    }
    missing_ids = [
        artist_id for artist_id in unique_ids if artist_id not in genre_cache
    ]
    cache_changed = False

    for index in range(0, len(missing_ids), 50):
        chunk = missing_ids[index : index + 50]
        try:
            response = _v1_get(
                "https://api.spotify.com/v1/artists?ids=" + ",".join(chunk),
                headers=headers,
                timeout=20,
            )
        except _SpotifyV1CooldownError as exc:
            print_update(f"[warn] v1 API genre batch failed for chunk {chunk}: {exc}")
            break
        except Exception as exc:
            print_update(f"[warn] v1 API genre batch failed for chunk {chunk}: {exc}")
            continue
        if response.status_code >= 400:
            print_update(
                f"[warn] v1 API genre batch HTTP {response.status_code} for chunk {chunk}"
            )
            continue
        payload = response.json()
        for artist_id in chunk:
            genre_cache.setdefault(artist_id, tuple())
        artists = payload.get("artists") or []
        for artist in artists:
            if not isinstance(artist, dict):
                continue
            artist_id = artist.get("id")
            if not isinstance(artist_id, str) or not artist_id:
                continue
            raw_genres = artist.get("genres")
            if not isinstance(raw_genres, list):
                continue
            normalized = [
                str(value).strip() for value in raw_genres if str(value).strip()
            ]
            genre_cache[artist_id] = tuple(normalized)
            if normalized:
                genres_by_artist_id[artist_id] = genre_cache[artist_id]
        cache_changed = True

    if cache_changed:
        try:
            _save_spotify_genre_cache(genre_cache)
        except OSError:
            pass

    return genres_by_artist_id
