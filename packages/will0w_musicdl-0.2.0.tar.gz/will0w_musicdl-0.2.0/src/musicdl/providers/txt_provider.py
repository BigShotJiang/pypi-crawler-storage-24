"""Provider for local text playlists with one `Artist - Title` entry per line."""

from __future__ import annotations

from pathlib import Path

from musicdl.errors import PlaylistNotFoundError, PlaylistResolutionError
from musicdl.providers.base import PlaylistProvider
from musicdl.types import Playlist, Song


class TxtProvider(PlaylistProvider):
    """Resolve a local `.txt` file into an ordered playlist."""

    name = "txt"

    def can_handle(self, playlist_input: str) -> bool:
        """Return whether the input path points to a text playlist file."""

        return (
            playlist_input.endswith(".txt")
            or Path(playlist_input).suffix.lower() == ".txt"
        )

    def resolve(self, playlist_input: str) -> Playlist:
        """Parse a text playlist file into normalized song objects."""

        path = Path(playlist_input).expanduser().resolve()
        if not path.exists():
            raise PlaylistNotFoundError(f"Text playlist file does not exist: {path}")

        raw_lines = [
            line.strip() for line in path.read_text(encoding="utf-8").splitlines()
        ]
        songs: list[Song] = []
        for line in raw_lines:
            if not line or line.startswith("#"):
                continue
            if " - " not in line:
                raise PlaylistResolutionError(
                    "Invalid txt format. Use one song per line as 'artist - title'."
                )
            artist, title = [part.strip() for part in line.split(" - ", 1)]
            if artist and title:
                songs.append(Song(artist=artist, title=title))

        if not songs:
            raise PlaylistResolutionError("No songs found in txt playlist.")

        return Playlist(source=self.name, name=path.stem, songs=songs)
