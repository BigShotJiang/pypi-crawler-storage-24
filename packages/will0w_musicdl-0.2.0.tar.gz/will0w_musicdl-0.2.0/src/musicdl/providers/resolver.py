"""Provider selection and fallback handling for playlist resolution."""

from __future__ import annotations

from musicdl.errors import PlaylistResolutionError
from musicdl.providers.base import PlaylistProvider
from musicdl.providers.spotify_provider import SpotifyProvider
from musicdl.providers.txt_provider import TxtProvider
from musicdl.providers.ytdlp_metadata import YtDlpMetadataProvider
from musicdl.types import Playlist


class ProviderResolver:
    """Choose the first matching provider that can successfully resolve an input."""

    def __init__(self) -> None:
        self.providers: list[PlaylistProvider] = [
            TxtProvider(),
            SpotifyProvider(),
            YtDlpMetadataProvider(),
        ]

    def resolve(self, playlist_input: str) -> Playlist:
        """Resolve user input through matching providers in configured precedence order."""

        matching = [
            provider
            for provider in self.providers
            if provider.can_handle(playlist_input)
        ]
        if not matching:
            raise PlaylistResolutionError(
                "No provider can handle this input. Provide a supported URL or a .txt file."
            )

        errors: list[str] = []
        for provider in matching:
            try:
                return provider.resolve(playlist_input)
            except PlaylistResolutionError as exc:
                errors.append(f"{provider.name}: {exc}")

        raise PlaylistResolutionError("; ".join(errors))
