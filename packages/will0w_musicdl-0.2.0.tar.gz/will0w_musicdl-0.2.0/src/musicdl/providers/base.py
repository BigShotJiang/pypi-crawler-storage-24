"""Abstract interfaces for playlist input providers."""

from __future__ import annotations

from abc import ABC, abstractmethod

from musicdl.types import Playlist


class PlaylistProvider(ABC):
    """Base contract for components that resolve user input into a playlist."""

    name: str

    @abstractmethod
    def can_handle(self, playlist_input: str) -> bool:
        """Return whether this provider can attempt to resolve the given input."""

        raise NotImplementedError

    @abstractmethod
    def resolve(self, playlist_input: str) -> Playlist:
        """Resolve the input into a normalized playlist or raise a resolution error."""

        raise NotImplementedError
