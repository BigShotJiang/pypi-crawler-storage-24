"""Generic playlist metadata resolution backed by `yt-dlp` extractors."""

from __future__ import annotations

import json
import subprocess

from musicdl.errors import (
    PlaylistNotFoundError,
    PlaylistPrivateError,
    PlaylistResolutionError,
)
from musicdl.providers.base import PlaylistProvider
from musicdl.types import Playlist, Song


class YtDlpMetadataProvider(PlaylistProvider):
    """Resolve supported remote playlist URLs through `yt-dlp` metadata output."""

    name = "ytdlp-metadata"

    def can_handle(self, playlist_input: str) -> bool:
        """Return whether the input is an HTTP(S) URL that `yt-dlp` may resolve."""

        return playlist_input.startswith("http://") or playlist_input.startswith(
            "https://"
        )

    def resolve(self, playlist_input: str) -> Playlist:
        """Resolve a remote playlist URL into normalized song metadata."""

        cmd = [
            "yt-dlp",
            "--flat-playlist",
            "--dump-single-json",
            "--skip-download",
            playlist_input,
        ]
        proc = subprocess.run(cmd, capture_output=True, text=True)
        stderr = (proc.stderr or "").strip()

        if proc.returncode != 0:
            lowered = stderr.lower()
            if any(
                token in lowered for token in ["private", "forbidden", "members-only"]
            ):
                raise PlaylistPrivateError(
                    f"Playlist is private or unavailable: {stderr}"
                )
            if any(
                token in lowered for token in ["not found", "404", "does not exist"]
            ):
                raise PlaylistNotFoundError(f"Playlist not found: {stderr}")
            raise PlaylistResolutionError(
                f"Could not read playlist metadata: {stderr or 'unknown error'}"
            )

        try:
            data = json.loads(proc.stdout)
        except json.JSONDecodeError as exc:
            raise PlaylistResolutionError(
                "yt-dlp returned invalid metadata JSON"
            ) from exc

        entries = data.get("entries") or []
        songs: list[Song] = []

        # Single-track URLs return metadata at the top level without an entries array.
        if not entries and data.get("title"):
            entries = [data]

        for entry in entries:
            title = (entry or {}).get("title")
            artist = (
                (entry or {}).get("artist")
                or (entry or {}).get("uploader")
                or (entry or {}).get("channel")
                or "Unknown Artist"
            )
            if title:
                duration_value = (entry or {}).get("duration")
                track_number_value = (entry or {}).get("track_number")
                genres_value = _extract_genres(entry or {})
                if not isinstance(track_number_value, int):
                    track_number_value = None
                # YouTube thumbnails, upload dates, and categories are
                # unreliable as music metadata — only keep fields that
                # genuinely describe the song.
                is_youtube = any(
                    h in ((entry or {}).get("webpage_url") or "")
                    for h in ("youtube.com", "youtu.be")
                )

                songs.append(
                    Song(
                        artist=artist,
                        title=title,
                        duration_seconds=(
                            int(duration_value)
                            if isinstance(duration_value, (int, float))
                            else None
                        ),
                        source_url=(
                            (entry or {}).get("webpage_url")
                            or (entry or {}).get("url")
                            or (entry or {}).get("original_url")
                        ),
                        album=(entry or {}).get("album"),
                        track_number=track_number_value,
                        release_date=(
                            None
                            if is_youtube
                            else (
                                (entry or {}).get("release_date")
                                or (entry or {}).get("upload_date")
                            )
                        ),
                        isrc=(entry or {}).get("isrc"),
                        artwork_url=(
                            None if is_youtube else (entry or {}).get("thumbnail")
                        ),
                        genres=None if is_youtube else genres_value,
                    )
                )

        if not songs:
            raise PlaylistResolutionError("No songs discovered in playlist metadata.")

        return Playlist(
            source=self.name,
            name=str(data.get("title") or "playlist"),
            songs=songs,
        )


def _extract_genres(entry: dict[str, object]) -> tuple[str, ...] | None:
    """Extract normalized genre values from yt-dlp metadata entry fields."""

    candidates = entry.get("genres")
    if isinstance(candidates, list):
        values = [str(value).strip() for value in candidates if str(value).strip()]
        return tuple(values) if values else None

    single = entry.get("genre")
    if isinstance(single, str) and single.strip():
        return (single.strip(),)

    category = entry.get("categories")
    if isinstance(category, list):
        values = [str(value).strip() for value in category if str(value).strip()]
        return tuple(values) if values else None
    return None
