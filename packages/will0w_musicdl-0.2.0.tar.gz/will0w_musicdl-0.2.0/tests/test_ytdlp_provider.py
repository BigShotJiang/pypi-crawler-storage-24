import json
from types import SimpleNamespace

from musicdl.providers.ytdlp_metadata import YtDlpMetadataProvider


def test_resolve_single_track_url(monkeypatch) -> None:
    """A single-track URL (no entries array) should resolve to a one-song playlist."""
    provider = YtDlpMetadataProvider()

    single_track_data = {
        "title": "One More Time",
        "artist": "Daft Punk",
        "album": "Discovery",
        "duration": 320,
        "webpage_url": "https://www.youtube.com/watch?v=FGBhQbmPwH8",
        "upload_date": "20010930",
        "thumbnail": "https://example.com/thumb.jpg",
    }

    monkeypatch.setattr(
        "musicdl.providers.ytdlp_metadata.subprocess.run",
        lambda cmd, capture_output, text: SimpleNamespace(
            returncode=0,
            stdout=json.dumps(single_track_data),
            stderr="",
        ),
    )

    playlist = provider.resolve("https://www.youtube.com/watch?v=FGBhQbmPwH8")

    assert len(playlist.songs) == 1
    assert playlist.songs[0].artist == "Daft Punk"
    assert playlist.songs[0].title == "One More Time"
    assert playlist.songs[0].album == "Discovery"
    assert playlist.songs[0].source_url == "https://www.youtube.com/watch?v=FGBhQbmPwH8"
    assert playlist.songs[0].duration_seconds == 320
    # YouTube thumbnails, upload dates and categories are unreliable.
    assert playlist.songs[0].artwork_url is None
    assert playlist.songs[0].release_date is None
    assert playlist.songs[0].genres is None


def test_resolve_playlist_url_still_works(monkeypatch) -> None:
    """A playlist URL with entries should resolve normally."""
    provider = YtDlpMetadataProvider()

    playlist_data = {
        "title": "My Playlist",
        "entries": [
            {
                "title": "Song A",
                "artist": "Artist A",
                "webpage_url": "https://example.com/a",
            },
            {
                "title": "Song B",
                "uploader": "Artist B",
                "webpage_url": "https://example.com/b",
            },
        ],
    }

    monkeypatch.setattr(
        "musicdl.providers.ytdlp_metadata.subprocess.run",
        lambda cmd, capture_output, text: SimpleNamespace(
            returncode=0,
            stdout=json.dumps(playlist_data),
            stderr="",
        ),
    )

    playlist = provider.resolve("https://www.youtube.com/playlist?list=abc")

    assert len(playlist.songs) == 2
    assert playlist.songs[0].title == "Song A"
    assert playlist.songs[1].artist == "Artist B"


def test_non_youtube_url_preserves_metadata(monkeypatch) -> None:
    """Non-YouTube sources should keep artwork, release_date and genres."""
    provider = YtDlpMetadataProvider()

    entry_data = {
        "title": "My Playlist",
        "entries": [
            {
                "title": "Cool Track",
                "artist": "SoundCloud DJ",
                "webpage_url": "https://soundcloud.com/artist/cool-track",
                "thumbnail": "https://i1.sndcdn.com/artworks.jpg",
                "release_date": "20240115",
                "genre": "Electronic",
            },
        ],
    }

    monkeypatch.setattr(
        "musicdl.providers.ytdlp_metadata.subprocess.run",
        lambda cmd, capture_output, text: SimpleNamespace(
            returncode=0,
            stdout=json.dumps(entry_data),
            stderr="",
        ),
    )

    playlist = provider.resolve("https://soundcloud.com/artist/cool-track")

    assert len(playlist.songs) == 1
    assert playlist.songs[0].artwork_url == "https://i1.sndcdn.com/artworks.jpg"
    assert playlist.songs[0].release_date == "20240115"
    assert playlist.songs[0].genres == ("Electronic",)


def test_youtube_playlist_strips_unreliable_metadata(monkeypatch) -> None:
    """YouTube playlist entries should also have artwork/release_date/genres stripped."""
    provider = YtDlpMetadataProvider()

    playlist_data = {
        "title": "My YT Playlist",
        "entries": [
            {
                "title": "Live Session",
                "uploader": "MusicChannel",
                "webpage_url": "https://www.youtube.com/watch?v=abc123",
                "thumbnail": "https://i.ytimg.com/vi/abc123/hq.jpg",
                "upload_date": "20230601",
                "categories": ["Music"],
            },
        ],
    }

    monkeypatch.setattr(
        "musicdl.providers.ytdlp_metadata.subprocess.run",
        lambda cmd, capture_output, text: SimpleNamespace(
            returncode=0,
            stdout=json.dumps(playlist_data),
            stderr="",
        ),
    )

    playlist = provider.resolve("https://www.youtube.com/playlist?list=xyz")

    assert len(playlist.songs) == 1
    assert playlist.songs[0].artwork_url is None
    assert playlist.songs[0].release_date is None
    assert playlist.songs[0].genres is None
