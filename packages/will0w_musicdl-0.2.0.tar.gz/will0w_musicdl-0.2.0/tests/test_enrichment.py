import json

from musicdl.enrichment import enrich_metadata_rows


class _FakeResponse:
    def __init__(self, payload: dict) -> None:
        self._payload = payload

    def raise_for_status(self) -> None:
        return None

    def json(self) -> dict:
        return self._payload


def test_enrich_metadata_rows_fills_missing_fields(monkeypatch) -> None:
    def _fake_get(url: str, timeout: int, headers: dict):
        assert "itunes.apple.com/search" in url
        return _FakeResponse(
            {
                "results": [
                    {
                        "artistName": "The Beaches",
                        "trackName": "Blow Up",
                        "collectionName": "Blame My Ex",
                        "trackNumber": 2,
                        "releaseDate": "2023-09-15T07:00:00Z",
                        "artworkUrl100": "https://example.com/100x100bb.jpg",
                        "primaryGenreName": "Alternative",
                        "trackViewUrl": "https://music.apple.com/example-track",
                    }
                ]
            }
        )

    monkeypatch.setattr("musicdl.enrichment.requests.get", _fake_get)

    rows, enriched_count = enrich_metadata_rows(
        [
            {
                "artist": "The Beaches",
                "title": "Blow Up",
                "file_name": "The Beaches - Blow Up.mp3",
                "album": None,
                "track_number": None,
                "release_date": None,
                "artwork_url": None,
                "genres": [],
                "source_url": None,
            }
        ]
    )

    assert enriched_count == 1
    assert rows[0]["album"] == "Blame My Ex"
    assert rows[0]["track_number"] == 2
    assert rows[0]["release_date"] == "2023-09-15"
    assert rows[0]["artwork_url"] == "https://example.com/1000x1000bb.jpg"
    assert rows[0]["genres"] == ["Alternative"]
    assert rows[0]["source_url"] == "https://music.apple.com/example-track"


def test_enrich_metadata_rows_preserves_existing_values(monkeypatch) -> None:
    def _fake_get(url: str, timeout: int, headers: dict):
        return _FakeResponse(
            {
                "results": [
                    {
                        "artistName": "Artist",
                        "trackName": "Song",
                        "collectionName": "New Album",
                        "trackNumber": 8,
                        "releaseDate": "2020-01-01T00:00:00Z",
                        "artworkUrl100": "https://example.com/100x100bb.jpg",
                        "primaryGenreName": "Rock",
                        "trackViewUrl": "https://music.apple.com/example-track",
                    }
                ]
            }
        )

    monkeypatch.setattr("musicdl.enrichment.requests.get", _fake_get)

    rows, enriched_count = enrich_metadata_rows(
        [
            {
                "artist": "Artist",
                "title": "Song",
                "album": "Existing Album",
                "genres": ["Existing Genre"],
                "source_url": "https://existing.example/song",
            }
        ]
    )

    assert enriched_count == 1
    assert rows[0]["album"] == "Existing Album"
    assert rows[0]["genres"] == ["Existing Genre"]
    assert rows[0]["source_url"] == "https://existing.example/song"
    assert rows[0]["track_number"] == 8


def test_enrich_metadata_rows_ignores_bad_matches(monkeypatch) -> None:
    def _fake_get(url: str, timeout: int, headers: dict):
        return _FakeResponse(
            {
                "results": [
                    {
                        "artistName": "Completely Different Artist",
                        "trackName": "Wrong Song",
                        "collectionName": "Wrong Album",
                    }
                ]
            }
        )

    monkeypatch.setattr("musicdl.enrichment.requests.get", _fake_get)

    rows, enriched_count = enrich_metadata_rows(
        [{"artist": "The Beaches", "title": "Blow Up"}]
    )

    assert enriched_count == 0
    assert rows == [{"artist": "The Beaches", "title": "Blow Up"}]


def test_enrich_metadata_rows_falls_back_to_musicbrainz(monkeypatch) -> None:
    monkeypatch.setattr("musicdl.enrichment._search_itunes", lambda *_args: None)
    monkeypatch.setattr(
        "musicdl.enrichment._search_musicbrainz",
        lambda *_args: {
            "releases": [{"title": "Album Name", "date": "1999-02-03"}],
            "isrcs": ["USRC17607839"],
            "genres": [{"name": "power pop"}],
        },
    )

    rows, enriched_count = enrich_metadata_rows(
        [{"artist": "Artist", "title": "Song", "album": None, "genres": []}]
    )

    assert enriched_count == 1
    assert rows[0]["album"] == "Album Name"
    assert rows[0]["release_date"] == "1999-02-03"
    assert rows[0]["isrc"] == "USRC17607839"
    assert rows[0]["genres"] == ["power pop"]


def test_enrich_metadata_rows_uses_cleaned_query_variants(monkeypatch) -> None:
    seen_queries: list[tuple[str, str]] = []

    def _fake_itunes(artist: str, title: str):
        seen_queries.append((artist, title))
        if artist == "Unknown Reality" and title == "late night":
            return {
                "artistName": "Unknown Reality",
                "trackName": "late night",
                "collectionName": "late night",
                "trackNumber": 1,
                "releaseDate": "2022-01-01T00:00:00Z",
                "artworkUrl100": "https://example.com/100x100bb.jpg",
                "primaryGenreName": "Electronic",
                "trackViewUrl": "https://music.apple.com/example-track",
            }
        return None

    monkeypatch.setattr("musicdl.enrichment._search_itunes", _fake_itunes)
    monkeypatch.setattr("musicdl.enrichment._search_musicbrainz", lambda *_args: None)

    rows, enriched_count = enrich_metadata_rows(
        [{"artist": "Unknown Reality - Topic", "title": "Topic - late night"}]
    )

    assert enriched_count == 1
    assert rows[0]["album"] == "late night"
    assert rows[0]["genres"] == ["Electronic"]
    assert ("Unknown Reality", "late night") in seen_queries


def test_enrich_metadata_rows_uses_title_only_fallback(monkeypatch) -> None:
    monkeypatch.setattr("musicdl.enrichment._search_itunes", lambda *_args: None)
    monkeypatch.setattr("musicdl.enrichment._search_musicbrainz", lambda *_args: None)

    def _fake_title_only(artist: str, title: str):
        if title == "Party Time":
            return {
                "artistName": "The Northern Boys",
                "trackName": "Party Time",
                "collectionName": "Party Time - Single",
                "releaseDate": "2024-03-01T00:00:00Z",
                "primaryGenreName": "Hip-Hop/Rap",
                "trackViewUrl": "https://music.apple.com/example-track",
            }
        return None

    monkeypatch.setattr(
        "musicdl.enrichment._search_itunes_title_only", _fake_title_only
    )
    monkeypatch.setattr(
        "musicdl.enrichment._search_itunes_artist_genre", lambda *_args: None
    )

    rows, enriched_count = enrich_metadata_rows(
        [{"artist": "The Northern Boys", "title": "Party Time"}]
    )

    assert enriched_count == 1
    assert rows[0]["album"] == "Party Time - Single"
    assert rows[0]["genres"] == ["Hip-Hop/Rap"]


def test_enrich_metadata_rows_uses_artist_genre_fallback(monkeypatch) -> None:
    monkeypatch.setattr("musicdl.enrichment._search_itunes", lambda *_args: None)
    monkeypatch.setattr("musicdl.enrichment._search_musicbrainz", lambda *_args: None)
    monkeypatch.setattr(
        "musicdl.enrichment._search_itunes_title_only", lambda *_args: None
    )
    monkeypatch.setattr(
        "musicdl.enrichment._search_itunes_artist_genre",
        lambda *_args: "Punk",
    )

    rows, enriched_count = enrich_metadata_rows(
        [{"artist": "Stick To Your Guns", "title": "What Choice Did You Give Us_"}]
    )

    assert enriched_count == 1
    assert rows[0]["genres"] == ["Punk"]


def test_enrich_metadata_rows_uses_deversioned_title_variant(monkeypatch) -> None:
    monkeypatch.setattr("musicdl.enrichment._search_itunes", lambda *_args: None)
    monkeypatch.setattr("musicdl.enrichment._search_musicbrainz", lambda *_args: None)

    def _fake_title_only(artist: str, title: str):
        if title in {"(She's) Sexy + 17", "Sexy + 17"}:
            return {
                "artistName": "Stray Cats",
                "trackName": "(She's) Sexy + 17",
                "collectionName": "Built for Speed",
                "releaseDate": "1982-06-01T00:00:00Z",
                "primaryGenreName": "Rock",
                "trackViewUrl": "https://music.apple.com/example-track",
            }
        return None

    monkeypatch.setattr(
        "musicdl.enrichment._search_itunes_title_only", _fake_title_only
    )
    monkeypatch.setattr(
        "musicdl.enrichment._search_itunes_artist_genre", lambda *_args: None
    )

    rows, enriched_count = enrich_metadata_rows(
        [
            {
                "artist": "Stray Cats",
                "title": "(She's) Sexy + 17 - Single Edit_24 Bit Remastered 99_Digital Remaster_1999",
            }
        ]
    )

    assert enriched_count == 1
    assert rows[0]["album"] == "Built for Speed"
    assert rows[0]["release_date"] == "1982-06-01"
