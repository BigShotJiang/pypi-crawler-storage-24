from pathlib import Path
import json

from musicdl.fs import mark_downloaded, mark_failed, sync_logs_with_folder
from musicdl.types import Song


def test_sync_logs_detects_manually_added_file(tmp_path: Path) -> None:
    (tmp_path / "Daft Punk - One More Time.mp3").write_bytes(b"test")

    downloaded, failed = sync_logs_with_folder(tmp_path)

    key = Song(artist="Daft Punk", title="One More Time").key
    assert key in downloaded
    assert "downloaded_at" in downloaded[key]
    assert failed == {}


def test_sync_logs_keeps_failed_history_if_song_present(tmp_path: Path) -> None:
    song = Song(artist="Nina Simone", title="Sinnerman")
    mark_failed(tmp_path, {}, song, "network error")
    (tmp_path / "Nina Simone - Sinnerman.mp3").write_bytes(b"x")

    downloaded, failed = sync_logs_with_folder(tmp_path)

    assert song.key in downloaded
    assert "downloaded_at" in downloaded[song.key]
    assert song.key in failed
    assert "failed_at" in failed[song.key]


def test_sync_logs_moves_missing_downloads_to_removed(tmp_path: Path) -> None:
    kept = Song(artist="Kept Artist", title="Kept Song")
    removed_song = Song(artist="Removed Artist", title="Removed Song")

    (tmp_path / "Kept Artist - Kept Song.mp3").write_bytes(b"x")
    downloaded_path = tmp_path / "downloaded.json"
    downloaded_path.write_text(
        json.dumps(
            [
                {
                    "artist": kept.artist,
                    "title": kept.title,
                    "key": kept.key,
                    "file_name": "Kept Artist - Kept Song.mp3",
                },
                {
                    "artist": removed_song.artist,
                    "title": removed_song.title,
                    "key": removed_song.key,
                    "file_name": "Removed Artist - Removed Song.mp3",
                },
            ]
        ),
        encoding="utf-8",
    )

    downloaded, _failed = sync_logs_with_folder(tmp_path)

    assert list(downloaded.keys()) == [kept.key]
    removed_records = json.loads(
        (tmp_path / "removed.json").read_text(encoding="utf-8")
    )
    assert len(removed_records) == 1
    assert removed_records[0]["key"] == removed_song.key
    assert "removed_at" in removed_records[0]


def test_mark_downloaded_moves_existing_song_to_bottom(tmp_path: Path) -> None:
    downloaded: dict[str, dict[str, str]] = {}
    failed: dict[str, dict[str, str]] = {}
    first = Song(artist="Artist A", title="Song A")
    second = Song(artist="Artist B", title="Song B")

    mark_downloaded(
        tmp_path,
        downloaded,
        failed,
        first,
        file_name="Artist A - Song A.mp3",
        source="test",
        downloaded_at="2026-03-11T10:00:00Z",
    )
    mark_downloaded(
        tmp_path,
        downloaded,
        failed,
        second,
        file_name="Artist B - Song B.mp3",
        source="test",
        downloaded_at="2026-03-11T10:01:00Z",
    )
    # Re-mark first song; it should move to the bottom.
    mark_downloaded(
        tmp_path,
        downloaded,
        failed,
        first,
        file_name="Artist A - Song A.mp3",
        source="test",
        downloaded_at="2026-03-11T10:02:00Z",
    )

    assert list(downloaded.keys()) == [second.key, first.key]

    records = json.loads((tmp_path / "downloaded.json").read_text(encoding="utf-8"))
    assert [record["key"] for record in records] == [second.key, first.key]


def test_mark_downloaded_removes_stale_filename_alias(tmp_path: Path) -> None:
    failed: dict[str, dict[str, str]] = {}
    song = Song(artist="Au/Ra", title="Panic Room")
    downloaded = {
        "au_ra::panic room": {
            "artist": "Au_Ra",
            "title": "Panic Room",
            "key": "au_ra::panic room",
            "file_name": "Au_Ra - Panic Room.mp3",
            "source": "folder-scan",
        }
    }

    mark_downloaded(
        tmp_path,
        downloaded,
        failed,
        song,
        file_name="Au_Ra - Panic Room.mp3",
        source="filename-exists",
        downloaded_at="2026-03-11T10:03:00Z",
    )

    assert list(downloaded.keys()) == [song.key]
    records = json.loads((tmp_path / "downloaded.json").read_text(encoding="utf-8"))
    assert len(records) == 1
    assert records[0]["key"] == song.key


def test_mark_failed_persists_source_url(tmp_path: Path) -> None:
    failed: dict[str, dict[str, str | int]] = {}
    song = Song(
        artist="Artist",
        title="Title",
        source_url="https://open.spotify.com/track/123",
    )

    mark_failed(tmp_path, failed, song, "network error")

    records = json.loads((tmp_path / "failed.json").read_text(encoding="utf-8"))
    assert records[0]["key"] == song.key
    assert records[0]["source_url"] == "https://open.spotify.com/track/123"


def test_mark_downloaded_persists_source_url(tmp_path: Path) -> None:
    downloaded: dict[str, dict[str, str | int | list[str]]] = {}
    failed: dict[str, dict[str, str | int | list[str]]] = {}
    song = Song(
        artist="Artist",
        title="Title",
        source_url="https://open.spotify.com/track/123",
        genres=("indie", "rock"),
    )

    mark_downloaded(
        tmp_path,
        downloaded,
        failed,
        song,
        file_name="Artist - Title.mp3",
        source="test",
        downloaded_at="2026-03-13T11:00:00Z",
    )

    records = json.loads((tmp_path / "downloaded.json").read_text(encoding="utf-8"))
    assert records[0]["key"] == song.key
    assert records[0]["source_url"] == "https://open.spotify.com/track/123"
    assert records[0]["genres"] == ["indie", "rock"]
