from pathlib import Path
import time
from types import SimpleNamespace

import pytest

from musicdl.errors import PlaylistResolutionError
from musicdl.providers import spotify_provider
from musicdl.types import Playlist, Song


def test_v1_get_short_circuits_when_cooldown_file_is_active(
    monkeypatch, tmp_path: Path
) -> None:
    cooldown_path = tmp_path / "spotify-v1.json"
    cooldown_path.write_text(
        '{"until": %s}' % (time.time() + 3600),
        encoding="utf-8",
    )

    monkeypatch.setattr(spotify_provider, "_SPOTIFY_V1_COOLDOWN_FILE", cooldown_path)

    def _unexpected_get(*_args, **_kwargs):
        raise AssertionError("requests.get should not be called during active cooldown")

    monkeypatch.setattr(spotify_provider.requests, "get", _unexpected_get)

    with pytest.raises(PlaylistResolutionError, match="Spotify v1 API rate-limited"):
        spotify_provider._v1_get("https://api.spotify.com/v1/test", headers={})


def test_fetch_artist_genres_stops_after_first_cooldown(
    monkeypatch, tmp_path: Path
) -> None:
    monkeypatch.setattr(
        spotify_provider,
        "_SPOTIFY_V1_COOLDOWN_FILE",
        tmp_path / "spotify-v1.json",
    )

    calls = 0
    warnings: list[str] = []

    def _fake_v1_get(*_args, **_kwargs):
        nonlocal calls
        calls += 1
        raise spotify_provider._SpotifyV1CooldownError(
            "Spotify v1 API rate-limited for ~8h."
        )

    monkeypatch.setattr(spotify_provider, "_v1_get", _fake_v1_get)
    monkeypatch.setattr(spotify_provider, "print_update", warnings.append)

    result = spotify_provider._fetch_artist_genres(
        "token",
        [f"artist-{index:03d}" for index in range(120)],
    )

    assert result == {}
    assert calls == 1
    assert len(warnings) == 1
    assert "v1 API genre batch failed" in warnings[0]


def test_fetch_artist_genres_uses_persistent_cache(monkeypatch, tmp_path: Path) -> None:
    cache_path = tmp_path / "spotify-artist-genres.json"
    monkeypatch.setattr(spotify_provider, "_SPOTIFY_GENRE_CACHE_FILE", cache_path)

    responses = [
        SimpleNamespace(
            status_code=200,
            json=lambda: {
                "artists": [
                    {"id": "artist-001", "genres": ["indie pop"]},
                    {"id": "artist-002", "genres": []},
                ]
            },
        )
    ]

    def _fake_v1_get(*_args, **_kwargs):
        return responses.pop(0)

    monkeypatch.setattr(spotify_provider, "_v1_get", _fake_v1_get)

    first = spotify_provider._fetch_artist_genres(
        "token",
        ["artist-001", "artist-002"],
    )

    assert first == {"artist-001": ("indie pop",)}
    assert cache_path.exists()

    def _unexpected_v1_get(*_args, **_kwargs):
        raise AssertionError("_v1_get should not be called for cached artists")

    monkeypatch.setattr(spotify_provider, "_v1_get", _unexpected_v1_get)

    second = spotify_provider._fetch_artist_genres(
        "token",
        ["artist-001", "artist-002"],
    )

    assert second == {"artist-001": ("indie pop",)}


def test_resolve_does_not_fallback_for_non_transport_pathfinder_errors(
    monkeypatch,
) -> None:
    monkeypatch.setattr(spotify_provider, "_extract_playlist_id", lambda _value: "abc")
    monkeypatch.setattr(
        spotify_provider,
        "_resolve_via_pathfinder",
        lambda _playlist_id: (_ for _ in ()).throw(
            PlaylistResolutionError(
                "Spotify playlist appears to contain no downloadable tracks."
            )
        ),
    )

    def _unexpected_embed(*_args, **_kwargs):
        raise AssertionError(
            "v1 fallback should not run for pathfinder content failures"
        )

    monkeypatch.setattr(spotify_provider, "_get_token_from_embed", _unexpected_embed)

    provider = spotify_provider.SpotifyProvider()
    with pytest.raises(PlaylistResolutionError, match="no downloadable tracks"):
        provider.resolve("https://open.spotify.com/playlist/abc")


def test_resolve_uses_v1_fallback_for_pathfinder_transport_errors(
    monkeypatch,
) -> None:
    monkeypatch.setattr(spotify_provider, "_extract_playlist_id", lambda _value: "abc")
    monkeypatch.setattr(
        spotify_provider,
        "_resolve_via_pathfinder",
        lambda _playlist_id: (_ for _ in ()).throw(
            spotify_provider._SpotifyPathfinderFallbackError(
                "Pathfinder fetchPlaylistContents failed: HTTP 500"
            )
        ),
    )
    monkeypatch.setattr(
        spotify_provider, "_get_token_from_embed", lambda _playlist_id: "token"
    )
    monkeypatch.setattr(
        spotify_provider,
        "_resolve_with_token",
        lambda _token, _playlist_id: Playlist(
            source="spotify",
            name="Recovered",
            songs=[Song(artist="Artist", title="Song")],
        ),
    )

    provider = spotify_provider.SpotifyProvider()
    playlist = provider.resolve("https://open.spotify.com/playlist/abc")

    assert playlist.name == "Recovered"
