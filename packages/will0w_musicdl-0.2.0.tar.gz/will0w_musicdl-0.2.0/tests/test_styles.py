from __future__ import annotations

from musicdl import styles


def test_colorize_returns_plain_text_without_tty(monkeypatch) -> None:
    monkeypatch.setattr(styles, "_stdout_is_tty", lambda: False)
    monkeypatch.delenv("FORCE_COLOR", raising=False)
    monkeypatch.delenv("NO_COLOR", raising=False)
    monkeypatch.setenv("TERM", "xterm-256color")

    assert styles.colorize("info", "hello") == "[info] hello"


def test_print_update_uses_plain_progress_line_without_tty(monkeypatch, capsys) -> None:
    monkeypatch.setattr(styles, "_stdout_is_tty", lambda: False)
    monkeypatch.delenv("FORCE_COLOR", raising=False)
    monkeypatch.delenv("NO_COLOR", raising=False)
    monkeypatch.setenv("TERM", "xterm-256color")
    monkeypatch.delenv("CI", raising=False)

    styles.print_update("Resolving playlist")

    assert capsys.readouterr().out == "[progress] Resolving playlist\n"


def test_print_update_is_suppressed_in_ci(monkeypatch, capsys) -> None:
    monkeypatch.setattr(styles, "_stdout_is_tty", lambda: False)
    monkeypatch.setenv("CI", "true")

    styles.print_update("Resolving playlist")

    assert capsys.readouterr().out == ""
