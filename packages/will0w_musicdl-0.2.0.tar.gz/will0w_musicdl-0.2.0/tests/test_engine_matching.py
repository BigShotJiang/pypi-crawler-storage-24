import json
from pathlib import Path
from types import SimpleNamespace

from musicdl.downloader.engine import DownloadEngine
from musicdl.types import Song


def test_select_candidate_prefers_regular_track_over_club_mix(
    monkeypatch,
    tmp_path: Path,
) -> None:
    engine = DownloadEngine(tmp_path)
    song = Song(artist="Au/Ra", title="Panic Room")
    payload = {
        "entries": [
            {
                "title": "Au/Ra - Panic Room (Club Mix)",
                "uploader": "Dance Channel",
                "duration": 193,
                "webpage_url": "https://example.com/club-mix",
            },
            {
                "title": "Au/Ra - Panic Room",
                "uploader": "Au/Ra - Topic",
                "duration": 193,
                "webpage_url": "https://example.com/original",
            },
        ]
    }

    def fake_run(cmd, capture_output, text):
        return SimpleNamespace(returncode=0, stdout=json.dumps(payload), stderr="")

    monkeypatch.setattr("musicdl.downloader.engine.subprocess.run", fake_run)

    candidate = engine._select_candidate(song, "ytsearch5:Au/Ra - Panic Room")

    assert candidate is not None
    assert candidate["title"] == "Au/Ra - Panic Room"


def test_unwanted_variant_allows_requested_mix(tmp_path: Path) -> None:
    engine = DownloadEngine(tmp_path)

    assert not engine._has_unwanted_variant(
        "Panic Room (Club Mix)",
        {
            "title": "Au/Ra - Panic Room (Club Mix)",
            "uploader": "Au/Ra - Topic",
        },
    )


def test_unwanted_variant_treats_session_as_variant(tmp_path: Path) -> None:
    engine = DownloadEngine(tmp_path)

    assert engine._has_unwanted_variant(
        "Panic Room",
        {
            "title": "Au/Ra - Panic Room (Secret Session)",
            "uploader": "Au/Ra",
        },
    )

    assert not engine._has_unwanted_variant(
        "Panic Room (Secret Session)",
        {
            "title": "Au/Ra - Panic Room (Secret Session)",
            "uploader": "Au/Ra",
        },
    )


def test_unwanted_variant_treats_remastered_as_variant(tmp_path: Path) -> None:
    engine = DownloadEngine(tmp_path)

    assert engine._has_unwanted_variant(
        "The Heat Is On",
        {
            "title": "The Heat Is On (Remastered)",
            "uploader": "Glenn Frey - Topic",
        },
        "Glenn Frey",
    )

    assert not engine._has_unwanted_variant(
        "The Heat Is On (Remastered)",
        {
            "title": "The Heat Is On (Remastered)",
            "uploader": "Glenn Frey - Topic",
        },
        "Glenn Frey",
    )


def test_unwanted_variant_rejects_unrequested_collab_title(tmp_path: Path) -> None:
    engine = DownloadEngine(tmp_path)

    assert engine._has_unwanted_variant(
        "Panic Room",
        {
            "title": "Au/Ra & CamelPhat - Panic Room",
            "uploader": "Au/Ra",
        },
        "Au/Ra",
    )

    assert not engine._has_unwanted_variant(
        "Panic Room",
        {
            "title": "Au/Ra & CamelPhat - Panic Room",
            "uploader": "Au/Ra",
        },
        "Au/Ra, CamelPhat",
    )


def test_select_candidate_prefers_topic_audio_over_music_video(
    monkeypatch,
    tmp_path: Path,
) -> None:
    engine = DownloadEngine(tmp_path)
    song = Song(artist="Simple Plan", title="What's New Scooby-Doo")
    payload = {
        "entries": [
            {
                "title": "Simple Plan - What's New Scooby-Doo? (Official Video)",
                "uploader": "SimplePlan",
                "duration": 151,
                "webpage_url": "https://example.com/video",
            },
            {
                "title": "What's New Scooby-Doo?",
                "uploader": "Simple Plan - Topic",
                "duration": 151,
                "webpage_url": "https://example.com/topic-audio",
            },
        ]
    }

    def fake_run(cmd, capture_output, text):
        return SimpleNamespace(returncode=0, stdout=json.dumps(payload), stderr="")

    monkeypatch.setattr("musicdl.downloader.engine.subprocess.run", fake_run)

    candidate = engine._select_candidate(
        song, "ytsearch5:Simple Plan - What's New Scooby-Doo"
    )

    assert candidate is not None
    assert candidate["webpage_url"] == "https://example.com/topic-audio"


def test_select_candidate_prefers_official_soundtrack_over_year_tag_upload(
    monkeypatch,
    tmp_path: Path,
) -> None:
    engine = DownloadEngine(tmp_path)
    song = Song(
        artist="Glenn Frey",
        title='The Heat Is On - From "Beverly Hills Cop" Soundtrack',
    )
    payload = {
        "entries": [
            {
                "title": "Glenn Frey - 1984 - The Heat Is On",
                "uploader": "Jan Knudsen",
                "duration": 226,
                "webpage_url": "https://example.com/year-tag",
            },
            {
                "title": 'Glenn Frey - The Heat Is On (From "Beverly Hills Cop" Soundtrack)',
                "uploader": "GlennFreyVEVO",
                "duration": 235,
                "webpage_url": "https://example.com/official-soundtrack",
            },
        ]
    }

    def fake_run(cmd, capture_output, text):
        return SimpleNamespace(returncode=0, stdout=json.dumps(payload), stderr="")

    monkeypatch.setattr("musicdl.downloader.engine.subprocess.run", fake_run)

    candidate = engine._select_candidate(song, "ytsearch5:Glenn Frey - The Heat Is On")

    assert candidate is not None
    assert candidate["webpage_url"] == "https://example.com/official-soundtrack"


def test_select_candidate_requires_uploader_match_for_short_artist_name(
    monkeypatch,
    tmp_path: Path,
) -> None:
    engine = DownloadEngine(tmp_path)
    song = Song(artist="P.E.T", title="Tommy")
    payload = {
        "entries": [
            {
                "title": "Tommy",
                "uploader": "Random Channel",
                "duration": 205,
                "webpage_url": "https://example.com/random",
            },
            {
                "title": "P.E.T. - Tommy",
                "uploader": "P.E.T - Topic",
                "duration": 205,
                "webpage_url": "https://example.com/pet-topic",
            },
        ]
    }

    def fake_run(cmd, capture_output, text):
        return SimpleNamespace(returncode=0, stdout=json.dumps(payload), stderr="")

    monkeypatch.setattr("musicdl.downloader.engine.subprocess.run", fake_run)

    candidate = engine._select_candidate(song, 'ytsearch5:"P.E.T" - Tommy')

    assert candidate is not None
    assert candidate["webpage_url"] == "https://example.com/pet-topic"


def test_score_candidate_rejects_preview_and_podcast(tmp_path: Path) -> None:
    engine = DownloadEngine(tmp_path)
    song = Song(artist="Artist", title="Song")

    preview_candidate = {
        "title": "Artist - Song",
        "uploader": "Artist - Topic",
        "webpage_url": "https://cf-preview-media.sndcdn.com/preview/track",
        "duration": 30,
    }
    podcast_candidate = {
        "title": "Artist - Song podcast episode",
        "uploader": "Podcast Channel",
        "webpage_url": "https://example.com/podcast",
        "duration": 180,
    }

    assert engine._score_candidate(song, preview_candidate) == 0
    assert engine._score_candidate(song, podcast_candidate) == 0


def test_canonical_title_strips_soundtrack_suffix(tmp_path: Path) -> None:
    engine = DownloadEngine(tmp_path)

    assert (
        engine._canonical_title('Accidentally In Love - From "Shrek 2" Soundtrack')
        == "Accidentally In Love"
    )


def test_download_song_skips_variant_only_backend(
    monkeypatch,
    tmp_path: Path,
) -> None:
    engine = DownloadEngine(tmp_path)
    song = Song(artist="Au/Ra", title="Panic Room")
    temp_file = tmp_path / "temp.mp3"
    temp_file.write_bytes(b"x")

    acoustic_candidate = {
        "title": "Panic Room (Acoustic)",
        "uploader": "Au/Ra",
        "webpage_url": "https://example.com/acoustic",
    }
    clean_candidate = {
        "title": "Au/Ra - Panic Room",
        "uploader": "Au/Ra",
        "webpage_url": "https://example.com/original",
    }

    def fake_select_candidate(selected_song, search_target):
        assert selected_song == song
        if "topic" in search_target:
            return acoustic_candidate
        return clean_candidate

    monkeypatch.setattr("musicdl.downloader.engine.shutil.which", lambda _: "yt-dlp")
    monkeypatch.setattr(engine, "_select_candidate", fake_select_candidate)
    monkeypatch.setattr(
        engine,
        "_candidate_target_url",
        lambda candidate: str(candidate.get("webpage_url")),
    )
    monkeypatch.setattr(
        "musicdl.downloader.engine.subprocess.run",
        lambda cmd, capture_output, text: SimpleNamespace(
            returncode=0, stdout="", stderr=""
        ),
    )
    monkeypatch.setattr(engine, "_most_recent_file", lambda: temp_file)

    result = engine.download_song(song)

    assert result.success is True
    assert result.source_used == "youtube"
    assert result.matched_title == "Au/Ra - Panic Room"


def test_generic_theme_uses_from_context_in_query(tmp_path: Path) -> None:
    engine = DownloadEngine(tmp_path)
    song = Song(
        artist="London Music Works",
        title="Theme (From _Thomas the Tank Engine_)",
    )

    query = engine._build_query(song, "youtube")

    assert "thomas" in query.lower()
    assert "tank" in query.lower()
    assert "engine" in query.lower()


def test_generic_theme_rejects_wrong_franchise_candidate(tmp_path: Path) -> None:
    engine = DownloadEngine(tmp_path)
    song = Song(
        artist="London Music Works",
        title="Theme (From _Thomas the Tank Engine_)",
    )

    wrong_candidate = {
        "title": "Game of Thrones Theme",
        "uploader": "London Music Works - Topic",
        "duration": 120,
        "webpage_url": "https://example.com/got",
    }
    right_candidate = {
        "title": "Theme From Thomas The Tank Engine",
        "uploader": "London Music Works",
        "duration": 120,
        "webpage_url": "https://example.com/thomas",
    }

    assert engine._score_candidate(song, wrong_candidate) == 0
    assert engine._score_candidate(song, right_candidate) > 0


def test_download_song_tries_source_url_first(
    monkeypatch,
    tmp_path: Path,
) -> None:
    """When song.source_url is set, download directly from it before trying backends."""
    engine = DownloadEngine(tmp_path)
    song = Song(
        artist="Daft Punk",
        title="One More Time",
        source_url="https://www.youtube.com/watch?v=FGBhQbmPwH8",
    )
    temp_file = tmp_path / "temp.mp3"
    temp_file.write_bytes(b"x")

    monkeypatch.setattr("musicdl.downloader.engine.shutil.which", lambda _: "yt-dlp")
    monkeypatch.setattr(
        "musicdl.downloader.engine.subprocess.run",
        lambda cmd, capture_output, text: SimpleNamespace(
            returncode=0, stdout="", stderr=""
        ),
    )
    monkeypatch.setattr(engine, "_most_recent_file", lambda: temp_file)

    result = engine.download_song(song)

    assert result.success is True
    assert result.source_used == "direct-url"
    assert result.matched_url == "https://www.youtube.com/watch?v=FGBhQbmPwH8"


def test_download_song_falls_back_to_search_when_source_url_fails(
    monkeypatch,
    tmp_path: Path,
) -> None:
    """When source_url download fails, fall back to search backends."""
    engine = DownloadEngine(tmp_path)
    song = Song(
        artist="Daft Punk",
        title="One More Time",
        source_url="https://www.youtube.com/watch?v=broken",
    )
    temp_file = tmp_path / "temp.mp3"
    temp_file.write_bytes(b"x")
    call_count = 0

    def fake_run(cmd, capture_output, text):
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            # First call is the direct URL attempt — fail it
            return SimpleNamespace(returncode=1, stdout="", stderr="not available")
        # Subsequent calls succeed (search + download)
        return SimpleNamespace(returncode=0, stdout="", stderr="")

    clean_candidate = {
        "title": "Daft Punk - One More Time",
        "uploader": "Daft Punk",
        "webpage_url": "https://example.com/search-result",
    }

    monkeypatch.setattr("musicdl.downloader.engine.shutil.which", lambda _: "yt-dlp")
    monkeypatch.setattr("musicdl.downloader.engine.subprocess.run", fake_run)
    monkeypatch.setattr(
        engine, "_select_candidate", lambda _song, _target: clean_candidate
    )
    monkeypatch.setattr(
        engine,
        "_candidate_target_url",
        lambda candidate: str(candidate.get("webpage_url")),
    )
    monkeypatch.setattr(engine, "_most_recent_file", lambda: temp_file)

    result = engine.download_song(song)

    assert result.success is True
    assert result.source_used == "youtube-music-query"
