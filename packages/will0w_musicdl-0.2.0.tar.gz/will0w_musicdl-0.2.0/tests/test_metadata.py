from pathlib import Path
from types import SimpleNamespace
import json

from musicdl.metadata import (
    backfill_missing_mp3_tags,
    collect_folder_metadata,
    export_folder_metadata,
    load_metadata_rows,
    save_metadata_rows,
    tag_folder_files,
    write_mp3_tags,
)


class _FakeParsed(dict):
    def __init__(self) -> None:
        super().__init__()
        self["artist"] = ["Tag Artist"]
        self["title"] = ["Tag Title"]
        self["album"] = ["Tag Album"]
        self["genre"] = ["Synthpop", "Electropop"]
        self["tracknumber"] = ["3"]
        self.info = SimpleNamespace(length=199.3456, bitrate=191234)


def test_collect_folder_metadata_uses_tags(monkeypatch, tmp_path: Path) -> None:
    file_path = tmp_path / "File Artist - File Title.mp3"
    file_path.write_bytes(b"x")

    monkeypatch.setattr(
        "musicdl.metadata.MutagenFile", lambda *_args, **_kwargs: _FakeParsed()
    )

    records = collect_folder_metadata(tmp_path)

    assert len(records) == 1
    row = records[0]
    assert row["file_name"] == "File Artist - File Title.mp3"
    assert row["artist"] == "Tag Artist"
    assert row["title"] == "Tag Title"
    assert row["album"] == "Tag Album"
    assert row["genres"] == ["Synthpop", "Electropop"]
    assert row["track_number"] == "3"
    assert row["duration_seconds"] == 199.346
    assert row["bitrate_kbps"] == 191


def test_collect_folder_metadata_falls_back_to_filename(
    monkeypatch, tmp_path: Path
) -> None:
    file_path = tmp_path / "Daft Punk - One More Time.mp3"
    file_path.write_bytes(b"x")

    monkeypatch.setattr("musicdl.metadata.MutagenFile", lambda *_args, **_kwargs: None)

    records = collect_folder_metadata(tmp_path)

    assert len(records) == 1
    row = records[0]
    assert row["artist"] == "Daft Punk"
    assert row["title"] == "One More Time"
    assert row["duration_seconds"] is None
    assert row["bitrate_kbps"] is None


def test_export_folder_metadata_writes_json(monkeypatch, tmp_path: Path) -> None:
    (tmp_path / "A - B.mp3").write_bytes(b"x")
    monkeypatch.setattr("musicdl.metadata.MutagenFile", lambda *_args, **_kwargs: None)

    output_path = tmp_path / "metadata.json"
    total = export_folder_metadata(tmp_path, output_path)

    assert total == 1
    rows = json.loads(output_path.read_text(encoding="utf-8"))
    assert isinstance(rows, list)
    assert rows[0]["file_name"] == "A - B.mp3"


def test_load_metadata_rows_returns_empty_for_invalid_json(tmp_path: Path) -> None:
    path = tmp_path / "metadata.json"
    path.write_text("not-json", encoding="utf-8")

    rows = load_metadata_rows(path)

    assert rows == []


def test_save_metadata_rows_writes_json(tmp_path: Path) -> None:
    path = tmp_path / "metadata.json"

    save_metadata_rows(path, [{"artist": "Artist", "title": "Song"}])

    rows = json.loads(path.read_text(encoding="utf-8"))
    assert rows == [{"artist": "Artist", "title": "Song"}]


def test_tag_folder_files_uses_metadata_rows(monkeypatch, tmp_path: Path) -> None:
    file_path = tmp_path / "A - B.mp3"
    file_path.write_bytes(b"x")
    calls: list[
        tuple[
            str,
            str,
            str | None,
            str | int | None,
            str | None,
            str | None,
            str | None,
            tuple[str, ...] | list[str] | None,
        ]
    ] = []

    def _fake_write(
        path: Path,
        artist: str,
        title: str,
        album: str | None = None,
        track_number: str | int | None = None,
        release_date: str | None = None,
        isrc: str | None = None,
        artwork_url: str | None = None,
        genres: tuple[str, ...] | list[str] | None = None,
    ) -> None:
        calls.append(
            (
                artist,
                title,
                album,
                track_number,
                release_date,
                isrc,
                artwork_url,
                genres,
            )
        )
        assert path == file_path

    monkeypatch.setattr("musicdl.metadata.write_mp3_tags", _fake_write)

    tagged, skipped = tag_folder_files(
        tmp_path,
        metadata_rows=[
            {
                "file_name": "A - B.mp3",
                "artist": "Metadata Artist",
                "title": "Metadata Title",
                "album": "Metadata Album",
                "track_number": "7",
                "release_date": "2024-04-13",
                "isrc": "TEST12345678",
                "artwork_url": "https://example.com/cover.jpg",
                "genres": ["rock", "alt-rock"],
            }
        ],
    )

    assert tagged == 1
    assert skipped == 0
    assert calls == [
        (
            "Metadata Artist",
            "Metadata Title",
            "Metadata Album",
            "7",
            "2024-04-13",
            "TEST12345678",
            "https://example.com/cover.jpg",
            ("rock", "alt-rock"),
        )
    ]


def test_tag_folder_files_falls_back_to_filename(monkeypatch, tmp_path: Path) -> None:
    file_path = tmp_path / "Daft Punk - One More Time.mp3"
    file_path.write_bytes(b"x")
    calls: list[
        tuple[
            str,
            str,
            str | None,
            str | int | None,
            str | None,
            str | None,
            str | None,
            tuple[str, ...] | list[str] | None,
        ]
    ] = []

    def _fake_write(
        path: Path,
        artist: str,
        title: str,
        album: str | None = None,
        track_number: str | int | None = None,
        release_date: str | None = None,
        isrc: str | None = None,
        artwork_url: str | None = None,
        genres: tuple[str, ...] | list[str] | None = None,
    ) -> None:
        calls.append(
            (
                artist,
                title,
                album,
                track_number,
                release_date,
                isrc,
                artwork_url,
                genres,
            )
        )
        assert path == file_path

    monkeypatch.setattr("musicdl.metadata.write_mp3_tags", _fake_write)

    tagged, skipped = tag_folder_files(tmp_path, default_album="Playlist Name")

    assert tagged == 1
    assert skipped == 0
    assert calls == [
        (
            "Daft Punk",
            "One More Time",
            "Playlist Name",
            None,
            None,
            None,
            None,
            (),
        )
    ]


def test_write_mp3_tags_creates_missing_id3_header(monkeypatch, tmp_path: Path) -> None:
    file_path = tmp_path / "track.mp3"
    file_path.write_bytes(b"x")
    save_calls: list[Path | None] = []
    constructed: list[object] = []

    class _FakeTags(dict):
        def save(self, target: Path | None = None) -> None:
            save_calls.append(target)

    def _fake_easyid3(path: Path | None = None) -> _FakeTags:
        if path is not None and not constructed:
            constructed.append("raised")
            from mutagen.id3 import ID3NoHeaderError

            raise ID3NoHeaderError("missing")
        tags = _FakeTags()
        constructed.append(tags)
        return tags

    monkeypatch.setattr("musicdl.metadata.EasyID3", _fake_easyid3)

    write_mp3_tags(
        file_path,
        artist="Artist",
        title="Title",
        album="Album",
        track_number=5,
    )

    tag_instances = [item for item in constructed if isinstance(item, _FakeTags)]
    tags_obj = tag_instances[-1]
    assert tags_obj["artist"] == ["Artist"]
    assert tags_obj["title"] == ["Title"]
    assert tags_obj["album"] == ["Album"]
    assert tags_obj["tracknumber"] == ["5"]
    assert file_path in save_calls


def test_backfill_missing_mp3_tags_preserves_existing_values(
    monkeypatch, tmp_path: Path
) -> None:
    file_path = tmp_path / "track.mp3"
    file_path.write_bytes(b"x")

    class _FakeTags(dict):
        def save(self, target: Path | None = None) -> None:
            return None

    tags = _FakeTags(
        {
            "artist": ["Existing Artist"],
            "title": ["Existing Title"],
        }
    )

    class _FakeID3:
        def __init__(self) -> None:
            self._frames: dict[str, list[object]] = {"TSRC": [], "APIC": []}

        def getall(self, key: str) -> list[object]:
            return self._frames.get(key, [])

        def add(self, frame: object) -> None:
            key = type(frame).__name__
            self._frames.setdefault(key, []).append(frame)

        def save(self, target: Path | None = None) -> None:
            return None

    fake_id3 = _FakeID3()

    monkeypatch.setattr("musicdl.metadata.EasyID3", lambda *_args, **_kwargs: tags)
    monkeypatch.setattr("musicdl.metadata.ID3", lambda *_args, **_kwargs: fake_id3)
    monkeypatch.setattr(
        "musicdl.metadata.TSRC", lambda **kwargs: SimpleNamespace(**kwargs)
    )
    monkeypatch.setattr(
        "musicdl.metadata.APIC", lambda **kwargs: SimpleNamespace(**kwargs)
    )

    changed = backfill_missing_mp3_tags(
        file_path,
        artist="New Artist",
        title="New Title",
        album="Album",
        track_number=4,
        release_date="2024-01-01",
        isrc="USRC12345678",
        genres=("Rock",),
    )

    assert changed is True
    # Existing fields are preserved.
    assert tags["artist"] == ["Existing Artist"]
    assert tags["title"] == ["Existing Title"]
    # Missing fields are backfilled.
    assert tags["album"] == ["Album"]
    assert tags["tracknumber"] == ["4"]
    assert tags["date"] == ["2024-01-01"]
    assert tags["genre"] == ["Rock"]
