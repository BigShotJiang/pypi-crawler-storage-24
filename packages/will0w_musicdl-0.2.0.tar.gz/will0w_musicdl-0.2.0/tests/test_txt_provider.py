from pathlib import Path

import pytest

from musicdl.errors import PlaylistResolutionError
from musicdl.providers.txt_provider import TxtProvider


def test_txt_provider_reads_songs(tmp_path: Path) -> None:
    playlist_file = tmp_path / "playlist.txt"
    playlist_file.write_text(
        "Artist A - Song A\n# comment\nArtist B - Song B\n", encoding="utf-8"
    )

    provider = TxtProvider()
    playlist = provider.resolve(str(playlist_file))

    assert playlist.name == "playlist"
    assert len(playlist.songs) == 2
    assert playlist.songs[0].artist == "Artist A"
    assert playlist.songs[0].title == "Song A"


def test_txt_provider_rejects_invalid_lines(tmp_path: Path) -> None:
    playlist_file = tmp_path / "playlist.txt"
    playlist_file.write_text("invalid line\n", encoding="utf-8")

    provider = TxtProvider()
    with pytest.raises(PlaylistResolutionError):
        provider.resolve(str(playlist_file))
