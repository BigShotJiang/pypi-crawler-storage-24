"""Primitives de domaine partagées (identifiants, métadonnées, versions, synchro)."""

from baobab_collection_core.domain.audit_timestamps import AuditTimestamps
from baobab_collection_core.domain.conflict_resolution_decision import ConflictResolutionDecision
from baobab_collection_core.domain.collection_card import UNSET, CollectionCard
from baobab_collection_core.domain.collection_user import CollectionUser
from baobab_collection_core.domain.container import Container
from baobab_collection_core.domain.container_kind import ContainerKind
from baobab_collection_core.domain.domain_id import DomainId
from baobab_collection_core.domain.entity_base import EntityBase
from baobab_collection_core.domain.entity_lifecycle_state import EntityLifecycleState
from baobab_collection_core.domain.entity_metadata import EntityMetadata
from baobab_collection_core.domain.entity_version import EntityVersion
from baobab_collection_core.domain.local_entity_kind import LocalEntityKind
from baobab_collection_core.domain.local_mutation import LocalMutation
from baobab_collection_core.domain.local_mutation_kind import LocalMutationKind
from baobab_collection_core.domain.physical_copy import PhysicalCopy
from baobab_collection_core.domain.sync_conflict import SyncConflict
from baobab_collection_core.domain.sync_conflict_kind import SyncConflictKind
from baobab_collection_core.domain.sync_delta_kind import SyncDeltaKind
from baobab_collection_core.domain.sync_dtos import (
    EntitySyncApplyRecord,
    EntitySyncDelta,
    LocalEntitySyncSnapshot,
    RemoteEntitySyncSnapshot,
    SyncPlan,
    SyncPlanItem,
    SynchronizationBatchResult,
)
from baobab_collection_core.domain.sync_plan_action import SyncPlanAction
from baobab_collection_core.domain.sync_session_outcome import SyncSessionOutcome
from baobab_collection_core.domain.physical_copy_business_status import PhysicalCopyBusinessStatus
from baobab_collection_core.domain.physical_copy_condition import PhysicalCopyCondition
from baobab_collection_core.domain.sync_state import SyncState

__all__: list[str] = [
    "AuditTimestamps",
    "ConflictResolutionDecision",
    "CollectionCard",
    "CollectionUser",
    "Container",
    "ContainerKind",
    "DomainId",
    "EntityBase",
    "EntityLifecycleState",
    "EntityMetadata",
    "EntityVersion",
    "LocalEntityKind",
    "LocalMutation",
    "LocalMutationKind",
    "PhysicalCopy",
    "PhysicalCopyBusinessStatus",
    "PhysicalCopyCondition",
    "EntitySyncApplyRecord",
    "EntitySyncDelta",
    "LocalEntitySyncSnapshot",
    "RemoteEntitySyncSnapshot",
    "SyncConflict",
    "SyncConflictKind",
    "SyncDeltaKind",
    "SyncPlan",
    "SyncPlanAction",
    "SyncPlanItem",
    "SyncSessionOutcome",
    "SynchronizationBatchResult",
    "SyncState",
    "UNSET",
]
