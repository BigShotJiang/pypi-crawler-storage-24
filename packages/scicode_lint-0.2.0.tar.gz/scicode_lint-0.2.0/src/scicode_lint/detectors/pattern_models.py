"""
Pydantic models for TOML pattern files.

These models define the structure of pattern.toml files and provide
validation for pattern data.
"""

from typing import Literal

from pydantic import BaseModel, Field


class PatternMeta(BaseModel):
    """Metadata about the pattern."""

    id: str
    name: str
    category: str  # Category: ai-*, scientific-*
    severity: Literal["critical", "high", "medium"]
    version: str = "1.0.0"
    created: str
    updated: str
    author: str = "scicode-lint"
    description: str
    explanation: str
    research_impact: str | None = None
    tags: list[str] = Field(default_factory=list)
    related_patterns: list[str] = Field(default_factory=list)
    references: list[str] = Field(default_factory=list)


class DetectionConfig(BaseModel):
    """Configuration for pattern detection."""

    question: str
    warning_message: str
    suggestion: str | None = None
    min_confidence: float = 0.85
    false_positive_risks: list[str] = Field(default_factory=list)


class TestLocation(BaseModel):
    """Expected location of a finding in test code."""

    type: Literal["function", "class", "method", "module"]
    name: str
    snippet: str


class PositiveTest(BaseModel):
    """Test case that should trigger detection (True Positive)."""

    file: str
    description: str
    expected_location: TestLocation
    expected_issue: str
    min_confidence: float = 0.85


class NegativeTest(BaseModel):
    """Test case that should NOT trigger detection (True Negative)."""

    file: str
    description: str
    notes: str | None = None


class ContextDependentTest(BaseModel):
    """Test case where detection is acceptable either way (ambiguous context)."""

    file: str
    description: str
    allow_detection: bool  # Must be explicit - no default
    allow_skip: bool  # Must be explicit - no default
    context_notes: str
    rationale_for_detection: str | None = None
    rationale_against_detection: str | None = None


class TestCases(BaseModel):
    """Collection of test cases for the pattern."""

    positive: list[PositiveTest] = Field(default_factory=list)
    negative: list[NegativeTest] = Field(default_factory=list)
    context_dependent: list[ContextDependentTest] = Field(default_factory=list)


class AIScience(BaseModel):
    """AI/science-specific metadata."""

    domains: list[str] = Field(default_factory=list)
    audience: list[str] = Field(default_factory=list)
    paper_sections: list[str] = Field(default_factory=list)
    impact_severity: str | None = None
    impact_magnitude: str | None = None
    prevalence: str | None = None
    educational_notes: str | None = None


class PatternTOML(BaseModel):
    """Complete pattern definition from TOML file."""

    meta: PatternMeta
    detection: DetectionConfig
    tests: TestCases
    ai_science: AIScience | None = None
