"""Basic usage: add skills, route queries, record outcomes."""

import hashlib
import tempfile
from pathlib import Path

from skill_mem import Library, Outcome


def mock_embed(text: str) -> list[float]:
    h = hashlib.sha256(text.encode()).digest()
    return [b / 255.0 for b in h[:32]]


def main() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        lib = Library(Path(tmp) / "skills", mock_embed)

        lib.add(
            "csv-analysis",
            "Analyze, summarize, or query CSV files and dataframes.",
            "Load with pandas. df.describe() for numerics. df.isnull().sum() for nulls.",
        )
        lib.add(
            "web-search",
            "Search the web for current information, news, or documentation.",
            "Use a search API. Open top 3-5 links. Cite sources.",
        )
        lib.add(
            "sql-query",
            "Write SQL queries from natural language questions about a database.",
            "Ask for schema. Write standard SQL. Use CTEs. Always LIMIT.",
        )

        print(f"Skills: {[s.name for s in lib.all()]}")

        query = "I need to analyze sales.csv and find trends"
        matches = lib.route(query, k=3)
        print(f"\nQuery: {query}")
        for m in matches:
            print(f"  {m.skill.name}: {m.score:.3f}")

        lib.record(
            "csv-analysis", "analyze sales.csv", Outcome(success=True, reason="ok")
        )
        lib.record(
            "csv-analysis", "find top customers", Outcome(success=True, reason="ok")
        )
        lib.record(
            "csv-analysis", "process 500k rows", Outcome(success=False, reason="OOM")
        )

        st = lib.stats("csv-analysis")
        print(f"\ncsv-analysis: utility={st.utility:.2f}, attempts={st.attempts}")
        for a in st.recent:
            print(f"  {'ok' if a.success else 'FAIL'} | {a.query} | {a.reason}")


if __name__ == "__main__":
    main()
