import hashlib
from pathlib import Path

import pytest

from skill_mem import Library, Outcome, Revision, Skill


def mock_embed(text: str) -> list[float]:
    h = hashlib.sha256(text.encode()).digest()
    return [b / 255.0 for b in h[:32]]


def test_empty_library(tmp_path: Path) -> None:
    lib = Library(tmp_path / "skills", mock_embed)
    assert lib.all() == []


def test_add_and_get(tmp_path: Path) -> None:
    lib = Library(tmp_path / "skills", mock_embed)
    skill = lib.add("csv", "Analyze CSV files.", "Use pandas.")
    assert skill.name == "csv"
    assert skill.version == 1

    got = lib.get("csv")
    assert got.name == "csv"
    assert got.content == "Use pandas."


def test_add_and_route(tmp_path: Path) -> None:
    lib = Library(tmp_path / "skills", mock_embed)
    lib.add("csv", "Analyze CSV files and dataframes.", "Use pandas.")
    lib.add("web", "Search the web for information.", "Use requests.")
    lib.add("sql", "Write SQL queries from questions.", "Use sqlite3.")

    matches = lib.route("I want to analyze a spreadsheet")
    assert len(matches) == 3
    assert all(isinstance(m.skill, Skill) for m in matches)


def test_record_and_utility(tmp_path: Path) -> None:
    lib = Library(tmp_path / "skills", mock_embed)
    lib.add("csv", "Analyze CSV files.", "Use pandas.")

    assert lib.utility("csv") == 0.5  # default prior

    lib.record("csv", "q1", Outcome(success=True, reason="worked"))
    lib.record("csv", "q2", Outcome(success=True, reason="worked"))
    lib.record("csv", "q3", Outcome(success=False, reason="failed"))

    assert abs(lib.utility("csv") - 2 / 3) < 1e-9


def test_stats(tmp_path: Path) -> None:
    lib = Library(tmp_path / "skills", mock_embed)
    lib.add("csv", "Analyze CSV files.", "Use pandas.")

    lib.record("csv", "analyze sales", Outcome(success=True, reason="ok"))
    lib.record("csv", "big file", Outcome(success=False, reason="OOM"))

    st = lib.stats("csv")
    assert st.attempts == 2
    assert st.successes == 1
    assert st.failures == 1
    assert len(st.recent) == 2
    assert st.recent[0].query == "analyze sales"


def test_evolve(tmp_path: Path) -> None:
    lib = Library(tmp_path / "skills", mock_embed)
    lib.add("csv", "Analyze CSV files.", "Use pandas.")

    def rewrite(skill: Skill, context: str) -> Revision:
        return Revision(
            description=skill.description,
            content=f"{skill.content}\n\nFor large files, sample first.",
        )

    evolved = lib.evolve("csv", "choked on 500k rows", rewrite)
    assert evolved.version == 2
    assert "sample first" in evolved.content

    got = lib.get("csv")
    assert got.version == 2


def test_evolve_updates_description(tmp_path: Path) -> None:
    lib = Library(tmp_path / "skills", mock_embed)
    lib.add("csv", "Analyze CSV files.", "Use pandas.")

    def rewrite(skill: Skill, context: str) -> Revision:
        return Revision(
            description="Analyze CSV files, parquet files, and tabular data.",
            content=f"{skill.content}\n\nAlso handles parquet.",
        )

    evolved = lib.evolve("csv", "failed on parquet", rewrite)
    assert "parquet" in evolved.description
    assert "parquet" in evolved.content


def test_evolve_archives(tmp_path: Path) -> None:
    lib = Library(tmp_path / "skills", mock_embed)
    lib.add("csv", "Analyze CSV files.", "Original content.")

    lib.evolve("csv", "failed", lambda s, c: Revision(s.description, "New content."))

    history = tmp_path / "skills" / ".skill-meta" / "history" / "csv" / "v1.md"
    assert history.exists()
    archived = history.read_text()
    assert "name: csv" in archived
    assert "Original content." in archived


def test_evolve_preserves_extra_frontmatter(tmp_path: Path) -> None:
    lib = Library(tmp_path / "skills", mock_embed)
    lib.add("csv", "Analyze CSV files.", "Use pandas.")

    path = tmp_path / "skills" / "csv" / "SKILL.md"
    path.write_text(
        "---\nname: csv\ndescription: Analyze CSV files.\nlicense: MIT\nmetadata:\n  author: joey\n---\n\nUse pandas.\n"
    )

    lib2 = Library(tmp_path / "skills", mock_embed)
    assert lib2.get("csv").extra_frontmatter == {
        "license": "MIT",
        "metadata": {"author": "joey"},
    }

    text = (tmp_path / "skills" / "csv" / "SKILL.md").read_text()
    assert "license: MIT" in text
    assert "author: joey" in text


def test_evolve_validate_rejects(tmp_path: Path) -> None:
    lib = Library(tmp_path / "skills", mock_embed)
    lib.add("csv", "Analyze CSV files.", "Original.")

    def rewrite(skill: Skill, context: str) -> Revision:
        return Revision(skill.description, "Bad rewrite.")

    result = lib.evolve("csv", "context", rewrite, validate=lambda old, new: False)
    assert result.content == "Original."
    assert result.version == 1


def test_evolve_validate_accepts(tmp_path: Path) -> None:
    lib = Library(tmp_path / "skills", mock_embed)
    lib.add("csv", "Analyze CSV files.", "Original.")

    def rewrite(skill: Skill, context: str) -> Revision:
        return Revision(skill.description, "Good rewrite.")

    result = lib.evolve("csv", "context", rewrite, validate=lambda old, new: True)
    assert result.content == "Good rewrite."
    assert result.version == 2


def test_discover(tmp_path: Path) -> None:
    lib = Library(tmp_path / "skills", mock_embed)

    def create(query: str, context: str) -> tuple[str, str, str]:
        return ("email", "Draft emails from instructions.", "Be concise.")

    skill = lib.discover("write an email", "some context", create)
    assert skill.name == "email"
    assert lib.get("email").content == "Be concise."


def test_discover_duplicate_asserts(tmp_path: Path) -> None:
    lib = Library(tmp_path / "skills", mock_embed)
    lib.add("csv", "Analyze CSV files.", "Content.")

    def create(q: str, c: str) -> tuple[str, str, str]:
        return ("csv", "Duplicate.", "Content.")

    with pytest.raises(AssertionError, match="already exists"):
        lib.discover("anything", "context", create)


def test_get_missing_asserts(tmp_path: Path) -> None:
    lib = Library(tmp_path / "skills", mock_embed)
    with pytest.raises(AssertionError, match="not found"):
        lib.get("nonexistent")


def test_gitignore_created(tmp_path: Path) -> None:
    Library(tmp_path / "skills", mock_embed)
    assert (tmp_path / "skills" / ".skill-meta" / ".gitignore").exists()


def test_persists_across_instances(tmp_path: Path) -> None:
    root = tmp_path / "skills"
    lib1 = Library(root, mock_embed)
    lib1.add("csv", "Analyze CSV files.", "Use pandas.")
    lib1.evolve("csv", "failed", lambda s, c: Revision(s.description, "Improved."))

    lib2 = Library(root, mock_embed)
    assert lib2.get("csv").version == 2
    assert lib2.get("csv").content == "Improved."
