from pathlib import Path

import pytest

from skill_mem.parse import read_skill, scan_skills, write_skill


def _write_md(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)


def test_read_skill(tmp_path: Path) -> None:
    _write_md(
        tmp_path / "my-skill" / "SKILL.md",
        "---\nname: my-skill\ndescription: Do the thing.\n---\n\nStep 1: do it.\n",
    )
    skill = read_skill(tmp_path / "my-skill" / "SKILL.md")
    assert skill.name == "my-skill"
    assert skill.description == "Do the thing."
    assert skill.content == "Step 1: do it."
    assert skill.version == 1


def test_read_skill_missing_name(tmp_path: Path) -> None:
    _write_md(
        tmp_path / "bad" / "SKILL.md",
        "---\ndescription: No name here.\n---\n\nBody.\n",
    )
    with pytest.raises(AssertionError, match="name"):
        read_skill(tmp_path / "bad" / "SKILL.md")


def test_read_skill_missing_description(tmp_path: Path) -> None:
    _write_md(
        tmp_path / "bad" / "SKILL.md",
        "---\nname: bad\n---\n\nBody.\n",
    )
    with pytest.raises(AssertionError, match="description"):
        read_skill(tmp_path / "bad" / "SKILL.md")


def test_read_skill_extra_fields(tmp_path: Path) -> None:
    _write_md(
        tmp_path / "extra" / "SKILL.md",
        "---\nname: extra\ndescription: Has extras.\nlicense: MIT\nmetadata:\n  author: joey\n---\n\nBody.\n",
    )
    skill = read_skill(tmp_path / "extra" / "SKILL.md")
    assert skill.name == "extra"
    assert skill.description == "Has extras."
    assert skill.extra_frontmatter == {"license": "MIT", "metadata": {"author": "joey"}}


def test_write_and_read_roundtrip(tmp_path: Path) -> None:
    skill = write_skill(
        tmp_path, "round-trip", "Trigger text.", "Do the thing.\n\nStep 2."
    )
    assert skill.name == "round-trip"
    assert skill.content == "Do the thing.\n\nStep 2."
    assert (tmp_path / "round-trip" / "SKILL.md").exists()

    loaded = read_skill(tmp_path / "round-trip" / "SKILL.md")
    assert loaded.name == skill.name
    assert loaded.description == skill.description
    assert loaded.content == skill.content


def test_scan_skills(tmp_path: Path) -> None:
    _write_md(
        tmp_path / "alpha" / "SKILL.md",
        "---\nname: alpha\ndescription: A.\n---\n\nA body.\n",
    )
    _write_md(
        tmp_path / "beta" / "SKILL.md",
        "---\nname: beta\ndescription: B.\n---\n\nB body.\n",
    )

    skills = scan_skills(tmp_path)
    assert len(skills) == 2
    assert skills[0].name == "alpha"
    assert skills[1].name == "beta"


def test_scan_skips_dotdirs(tmp_path: Path) -> None:
    _write_md(
        tmp_path / "real" / "SKILL.md",
        "---\nname: real\ndescription: Real.\n---\n\nBody.\n",
    )
    _write_md(
        tmp_path / ".hidden" / "SKILL.md",
        "---\nname: hidden\ndescription: Hidden.\n---\n\nBody.\n",
    )

    skills = scan_skills(tmp_path)
    assert len(skills) == 1
    assert skills[0].name == "real"


def test_write_skill_special_chars(tmp_path: Path) -> None:
    desc = 'Use this skill when: the user says "hello"'
    write_skill(tmp_path, "special", desc, "Content here.")
    loaded = read_skill(tmp_path / "special" / "SKILL.md")
    assert loaded.description == desc


def test_body_with_horizontal_rule(tmp_path: Path) -> None:
    body = "Before rule.\n\n---\n\nAfter rule."
    _write_md(
        tmp_path / "hr" / "SKILL.md",
        f"---\nname: hr\ndescription: Has HR.\n---\n\n{body}\n",
    )
    skill = read_skill(tmp_path / "hr" / "SKILL.md")
    assert "After rule." in skill.content
