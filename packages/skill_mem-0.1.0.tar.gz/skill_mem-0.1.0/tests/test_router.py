import hashlib
from pathlib import Path

from skill_mem.router import Router
from skill_mem.types import Skill


def mock_embed(text: str) -> list[float]:
    h = hashlib.sha256(text.encode()).digest()
    return [b / 255.0 for b in h[:32]]


def _skill(name: str, description: str) -> Skill:
    return Skill(
        name=name, description=description, content="", path=Path(f"/{name}/SKILL.md")
    )


def test_index_and_search(tmp_path: Path) -> None:
    router = Router(tmp_path, mock_embed)
    skills = [
        _skill("csv", "Analyze CSV files and dataframes"),
        _skill("web", "Search the web for information"),
        _skill("sql", "Write SQL queries from natural language"),
    ]
    router.index(skills)
    matches = router.search("I need to query a database", k=3)
    assert len(matches) == 3
    assert all(0.0 <= m.score <= 1.0 for m in matches)


def test_search_returns_k(tmp_path: Path) -> None:
    router = Router(tmp_path, mock_embed)
    skills = [_skill(f"s{i}", f"Skill {i} description") for i in range(10)]
    router.index(skills)
    matches = router.search("anything", k=3)
    assert len(matches) == 3


def test_search_fewer_than_k(tmp_path: Path) -> None:
    router = Router(tmp_path, mock_embed)
    router.index([_skill("only", "The only skill")])
    matches = router.search("anything", k=5)
    assert len(matches) == 1


def test_search_empty(tmp_path: Path) -> None:
    router = Router(tmp_path, mock_embed)
    router.index([])
    matches = router.search("anything", k=3)
    assert matches == []


def test_cache_invalidation(tmp_path: Path) -> None:
    router = Router(tmp_path, mock_embed)
    router.index([_skill("s", "Original description")])

    router.index([_skill("s", "Changed description")])

    assert (
        router._entries["s"]["hash"]
        != hashlib.sha256(b"Original description").hexdigest()
    )


def test_cache_hit(tmp_path: Path) -> None:
    call_count = 0

    def counting_embed(text: str) -> list[float]:
        nonlocal call_count
        call_count += 1
        return mock_embed(text)

    router = Router(tmp_path, counting_embed)
    skills = [_skill("s", "Same description")]

    router.index(skills)
    first_count = call_count

    router.index(skills)
    assert call_count == first_count


def test_prunes_removed_skills(tmp_path: Path) -> None:
    router = Router(tmp_path, mock_embed)
    router.index([_skill("a", "A"), _skill("b", "B"), _skill("c", "C")])
    assert "c" in router._entries

    router.index([_skill("a", "A"), _skill("b", "B")])
    assert "c" not in router._entries


def test_index_with_successful_queries(tmp_path: Path) -> None:
    call_count = 0

    def counting_embed(text: str) -> list[float]:
        nonlocal call_count
        call_count += 1
        return mock_embed(text)

    router = Router(tmp_path, counting_embed)
    skills = [_skill("csv", "Analyze CSV files")]
    router.index(skills)
    first_count = call_count

    router.index(skills, {"csv": ["analyze sales.csv"]})
    assert call_count > first_count
