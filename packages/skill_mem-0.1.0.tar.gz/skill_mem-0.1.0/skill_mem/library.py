from __future__ import annotations

import json
from dataclasses import replace
from pathlib import Path

from skill_mem.parse import scan_skills, write_skill
from skill_mem.router import Router
from skill_mem.tracker import Tracker
from skill_mem.types import (
    Create,
    Embed,
    Match,
    Outcome,
    Rewrite,
    Skill,
    Stats,
    Validate,
)


class Library:
    def __init__(self, path: str | Path, embed: Embed) -> None:
        self._root = Path(path).resolve()
        self._root.mkdir(parents=True, exist_ok=True)

        self._meta = self._root / ".skill-meta"
        self._meta.mkdir(exist_ok=True)
        (self._meta / "history").mkdir(exist_ok=True)

        gitignore = self._meta / ".gitignore"
        if not gitignore.exists():
            gitignore.write_text("*\n")

        self._versions_path = self._meta / "versions.json"
        self._versions = self._load_versions()

        skills = scan_skills(self._root)
        self._skills: dict[str, Skill] = {}
        for skill in skills:
            v = self._versions.get(skill.name, 1)
            self._skills[skill.name] = replace(skill, version=v)

        self._router = Router(self._meta, embed)
        self._tracker = Tracker(self._meta)
        self._reindex()

    def route(self, query: str, k: int = 3) -> list[Match]:
        return self._router.search(query, k)

    def get(self, name: str) -> Skill:
        assert name in self._skills, f"Skill not found: {name}"
        return self._skills[name]

    def all(self) -> list[Skill]:
        return sorted(self._skills.values(), key=lambda s: s.name)

    def utility(self, name: str) -> float:
        return self._tracker.utility(name)

    def stats(self, name: str) -> Stats:
        return self._tracker.stats(name)

    def add(self, name: str, description: str, content: str) -> Skill:
        skill = write_skill(self._root, name, description, content)
        self._versions[name] = 1
        self._save_versions()
        self._skills[name] = skill
        self._reindex()
        return skill

    def record(self, name: str, query: str, outcome: Outcome) -> None:
        assert name in self._skills, f"Skill not found: {name}"
        self._tracker.record(name, query, outcome)
        if outcome.success:
            self._reindex()

    def evolve(
        self,
        name: str,
        context: str,
        rewrite: Rewrite,
        validate: Validate | None = None,
    ) -> Skill:
        old = self.get(name)
        revision = rewrite(old, context)

        candidate = replace(
            old,
            description=revision.description,
            content=revision.content,
            version=old.version + 1,
        )

        if validate and not validate(old, candidate):
            return old

        history_dir = self._meta / "history" / name
        history_dir.mkdir(parents=True, exist_ok=True)
        (history_dir / f"v{old.version}.md").write_text(old.path.read_text())

        updated = write_skill(
            self._root,
            name,
            revision.description,
            revision.content,
            old.extra_frontmatter,
        )
        updated = replace(updated, version=old.version + 1)

        self._versions[name] = updated.version
        self._save_versions()
        self._skills[name] = updated
        self._reindex()
        return updated

    def discover(self, query: str, context: str, create: Create) -> Skill:
        name, description, content = create(query, context)
        assert name not in self._skills, f"Skill already exists: {name}"
        return self.add(name, description, content)

    def _reindex(self) -> None:
        queries = {
            name: self._tracker.successful_queries(name) for name in self._skills
        }
        self._router.index(list(self._skills.values()), queries)

    def _load_versions(self) -> dict[str, int]:
        if self._versions_path.exists():
            return json.loads(self._versions_path.read_text())
        return {}

    def _save_versions(self) -> None:
        self._versions_path.write_text(json.dumps(self._versions))
