from __future__ import annotations

import hashlib
import json
from pathlib import Path

from skill_mem.types import Embed, Match, Skill


def _cosine(a: list[float], b: list[float]) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = sum(x * x for x in a) ** 0.5
    norm_b = sum(x * x for x in b) ** 0.5
    assert norm_a > 0 and norm_b > 0, "Zero-norm vector"
    return dot / (norm_a * norm_b)


def _hash(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()


def _routing_text(skill: Skill, successful_queries: list[str]) -> str:
    parts = [skill.description]
    if successful_queries:
        examples = successful_queries[-5:]  # last 5
        parts.append("Examples: " + " | ".join(examples))
    return "\n".join(parts)


class Router:
    def __init__(self, meta_path: Path, embed: Embed) -> None:
        self._embed = embed
        self._db_path = meta_path / "embeddings.json"
        self._entries: dict[str, dict] = self._load()
        self._skills: dict[str, Skill] = {}

    def index(
        self,
        skills: list[Skill],
        successful_queries: dict[str, list[str]] | None = None,
    ) -> None:
        self._skills = {s.name: s for s in skills}
        queries = successful_queries or {}
        current_names = set(self._skills)

        for name in list(self._entries):
            if name not in current_names:
                del self._entries[name]

        for skill in skills:
            text = _routing_text(skill, queries.get(skill.name, []))
            h = _hash(text)
            entry = self._entries.get(skill.name)
            if entry and entry["hash"] == h:
                continue
            self._entries[skill.name] = {
                "vector": [float(x) for x in self._embed(text)],
                "hash": h,
            }

        self._save()

    def search(self, query: str, k: int) -> list[Match]:
        if not self._entries:
            return []

        q_vec = self._embed(query)
        scored = [
            (name, _cosine(q_vec, entry["vector"]))
            for name, entry in self._entries.items()
        ]
        scored.sort(key=lambda x: x[1], reverse=True)

        return [
            Match(skill=self._skills[name], score=score)
            for name, score in scored[:k]
            if name in self._skills
        ]

    def _load(self) -> dict[str, dict]:
        if self._db_path.exists():
            return json.loads(self._db_path.read_text())
        return {}

    def _save(self) -> None:
        self._db_path.write_text(json.dumps(self._entries))
