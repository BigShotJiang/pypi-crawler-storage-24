from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path


@dataclass(frozen=True, slots=True)
class Skill:
    name: str
    description: str
    content: str
    path: Path
    version: int = 1
    extra_frontmatter: dict = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class Match:
    skill: Skill
    score: float


@dataclass(frozen=True, slots=True)
class Outcome:
    success: bool
    reason: str


@dataclass(frozen=True, slots=True)
class Attempt:
    query: str
    skill: str
    success: bool
    reason: str


@dataclass(frozen=True, slots=True)
class Revision:
    description: str
    content: str


@dataclass(frozen=True, slots=True)
class Stats:
    utility: float
    attempts: int
    successes: int
    failures: int
    recent: list[Attempt]


Embed = Callable[[str], list[float]]
Rewrite = Callable[[Skill, str], Revision]
Create = Callable[[str, str], tuple[str, str, str]]
Validate = Callable[[Skill, Skill], bool]
