from __future__ import annotations

from pathlib import Path

import yaml

from skill_mem.types import Skill


def read_skill(path: Path) -> Skill:
    text = path.read_text()
    assert text.startswith("---"), f"SKILL.md must start with ---: {path}"

    end = text.index("\n---", 3)
    frontmatter = yaml.safe_load(text[3:end])
    body = text[end + 4 :].strip()

    assert isinstance(frontmatter, dict), f"Invalid frontmatter in {path}"
    name = frontmatter.get("name")
    description = frontmatter.get("description")
    assert name, f"Missing 'name' in {path}"
    assert description, f"Missing 'description' in {path}"

    extra = {k: v for k, v in frontmatter.items() if k not in ("name", "description")}

    return Skill(
        name=name,
        description=description,
        content=body,
        path=path.resolve(),
        extra_frontmatter=extra,
    )


def write_skill(
    root: Path,
    name: str,
    description: str,
    content: str,
    extra_frontmatter: dict | None = None,
) -> Skill:
    skill_dir = root / name
    skill_dir.mkdir(parents=True, exist_ok=True)
    path = skill_dir / "SKILL.md"

    fm = {"name": name, "description": description}
    if extra_frontmatter:
        fm.update(extra_frontmatter)

    header = yaml.dump(fm, default_flow_style=False, sort_keys=False).strip()
    path.write_text(f"---\n{header}\n---\n\n{content}\n")

    return Skill(
        name=name,
        description=description,
        content=content,
        path=path.resolve(),
        extra_frontmatter=extra_frontmatter or {},
    )


def scan_skills(root: Path) -> list[Skill]:
    skills = []
    for skill_md in sorted(root.glob("*/SKILL.md")):
        if skill_md.parent.name.startswith("."):
            continue
        skills.append(read_skill(skill_md))
    return skills
