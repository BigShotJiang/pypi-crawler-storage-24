"""
AzerAI DateTime Plugin - Tarix və zaman sorğuları üçün plugin

Plugin əsaslı, çoxdilli AI asistenti üçün tarix və zaman modulu.
"""

__version__ = "3.0.5"
__author__ = "AzStudio Dev"
__email__ = "info.azstudiodev@gmail.com"

from .plugins.datetime.main import get_datetime

__all__ = [
    "get_datetime"
]
