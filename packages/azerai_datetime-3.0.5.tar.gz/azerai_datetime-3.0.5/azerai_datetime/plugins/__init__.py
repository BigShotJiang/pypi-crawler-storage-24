"""
AzerAI DateTime Plugin - Plugin package
"""
