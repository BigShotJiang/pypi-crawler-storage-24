# 🕐 AzerAI DateTime Plugin

Azərbaycan dilində qabaqcıl səsli AI asistenti üçün tarix və zaman plugini.

## Xüsusiyyətlər

- 🕐 **Cari vaxt** - Azərbaycan vaxt zonasında (UTC+4)
- 📅 **Cari tarix** - Tam tarix məlumatları
- 📊 **Detallı məlumat** - Həftənin günü, ayın günü, ilin günü
- 🌍 **Azərbaycan dilində** - Bütün məlumatlar azərbaycan dilində
- 🗺️ **Vaxt zona** - Avtomatik Azərbaycan vaxtı
- 📈 **Formatlama** - Müxtəlif format seçimləri

## Quraşdırma

```bash
pip install AzerAI-DateTime
```

## İstifadə

Plugin avtomatik olaraq AzerAI tərəfindən aşkar edilir.

### Əmrlər

- `"İndi saat neçədir?"` - Cari vaxt
- `"Bugün tarix neçədir?"` - Cari tarix
- `"Tarix və zaman məlumatları"` - Tam məlumat
- `"Saat neçə?"` - Sadə vaxt sorğusu
- `"Bugün günlerden neçədir?"` - Günün adı

## Fayl struktur

```
azerai_datetime/
├── plugins/
│   └── datetime/
│       ├── __init__.py
│       └── main.py
└── __init__.py
```

## Xüsusiyyətlər

### 🕐 **Cari Vaxt**
- Saat, dəqiqə, saniyə
- Azərbaycan vaxt zonası (UTC+4)
- Günün periodu (səhər, gündüz, axşam, gecə)

### 📅 **Cari Tarix**
- Gün, ay, il
- Günün adı (azərbaycan dilində)
- Ayın adı (azərbaycan dilində)

### 📊 **Detallı Məlumatlar**
- Həftənin günü (1-7)
- İl günü (1-366)
- İl həftəsi (1-52)
- Ay günü

## Asılılıqlar

- `livekit-agents` - AI agent framework

## 📄 Lisenziya

Bu layihə MIT Lisenziyası ilə lisenziyalaşdırılıb.

## 📞 Əlaqə

- **Müəllif:** AzStudio Dev
- **Email:** info.azstudiodev@gmail.com
- **GitHub:** https://github.com/AzStudio-Dev/AzerAI-DateTime
- **PyPI:** https://pypi.org/project/AzerAI-DateTime/

---

**🇦🇿 Azərbaycanın ilk tam plugin ekosistemli AI asistentinin DateTime plugini!** 🚀
