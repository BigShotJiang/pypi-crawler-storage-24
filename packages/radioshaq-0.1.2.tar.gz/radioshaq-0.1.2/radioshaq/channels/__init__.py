"""Communication channels (WhatsApp, SMS)."""
