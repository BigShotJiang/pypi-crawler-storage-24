"""FastAPI web API."""
