"""vLLM adapter stub.

Will eventually provide integration with vLLM's offline inference engine
for high-throughput benchmarking with PagedAttention and continuous batching.
"""

from local_inferbench.adapters.base import BaseAdapter, GenerationResult


class VLLMAdapter(BaseAdapter):
    """Adapter for vLLM inference engine.

    This is a stub — full implementation coming in a future release.
    """

    def __init__(self, model: str, **kwargs: object) -> None:
        self._model = model

    def name(self) -> str:
        return "vllm"

    def model_id(self) -> str:
        return self._model

    def load(self) -> None:
        raise NotImplementedError("Coming in a future release")

    def generate(
        self,
        prompt: str,
        max_tokens: int = 512,
        temperature: float = 0.0,
        **kwargs: object,
    ) -> GenerationResult:
        raise NotImplementedError("Coming in a future release")

    def unload(self) -> None:
        raise NotImplementedError("Coming in a future release")
