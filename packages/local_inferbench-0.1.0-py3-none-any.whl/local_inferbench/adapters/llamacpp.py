"""llama.cpp adapter stub.

Will eventually provide direct integration with llama-cpp-python for
native llama.cpp inference without a separate server process. This enables
fine-grained control over model loading parameters, context sizes, and
batch processing.
"""

from local_inferbench.adapters.base import BaseAdapter, GenerationResult


class LlamaCppAdapter(BaseAdapter):
    """Adapter for llama-cpp-python (llama.cpp bindings).

    This is a stub — full implementation coming in a future release.
    """

    def __init__(self, model_path: str, **kwargs: object) -> None:
        self._model_path = model_path

    def name(self) -> str:
        return "llamacpp"

    def model_id(self) -> str:
        return self._model_path

    def load(self) -> None:
        raise NotImplementedError("Coming in a future release")

    def generate(
        self,
        prompt: str,
        max_tokens: int = 512,
        temperature: float = 0.0,
        **kwargs: object,
    ) -> GenerationResult:
        raise NotImplementedError("Coming in a future release")

    def unload(self) -> None:
        raise NotImplementedError("Coming in a future release")
