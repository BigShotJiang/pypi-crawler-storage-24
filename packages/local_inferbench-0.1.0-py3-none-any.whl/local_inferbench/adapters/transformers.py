"""HuggingFace Transformers adapter stub.

Will eventually provide direct integration with the HuggingFace Transformers
library for benchmarking models using the standard transformers pipeline,
including support for quantized models via bitsandbytes and GPTQ.
"""

from local_inferbench.adapters.base import BaseAdapter, GenerationResult


class TransformersAdapter(BaseAdapter):
    """Adapter for HuggingFace Transformers.

    This is a stub — full implementation coming in a future release.
    """

    def __init__(self, model: str, **kwargs: object) -> None:
        self._model = model

    def name(self) -> str:
        return "transformers"

    def model_id(self) -> str:
        return self._model

    def load(self) -> None:
        raise NotImplementedError("Coming in a future release")

    def generate(
        self,
        prompt: str,
        max_tokens: int = 512,
        temperature: float = 0.0,
        **kwargs: object,
    ) -> GenerationResult:
        raise NotImplementedError("Coming in a future release")

    def unload(self) -> None:
        raise NotImplementedError("Coming in a future release")
