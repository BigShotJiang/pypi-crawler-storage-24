import pytest


@pytest.fixture(autouse=True)
def disable_sidecar(request: pytest.FixtureRequest, monkeypatch: pytest.MonkeyPatch) -> None:
    """Disable the sidecar process for all unit tests.

    The sidecar runs in a separate subprocess and makes real HTTP calls
    that are not intercepted by pytest_httpx. Disabling it ensures all
    HTTP calls go through the mock transport as expected.

    Integration tests that need a real sidecar should be marked with
    ``@pytest.mark.integration``.
    """
    if request.node.get_closest_marker("integration") is None:
        monkeypatch.setenv("TYKO_DISABLE_SIDECAR", "1")
