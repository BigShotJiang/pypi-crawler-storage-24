"""Empty profile."""
