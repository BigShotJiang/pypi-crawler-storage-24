"""Various cache implementations."""
