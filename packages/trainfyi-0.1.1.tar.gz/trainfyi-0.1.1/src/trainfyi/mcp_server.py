"""MCP server for trainfyi — AI assistant tools for trainfyi.com.

Run: uvx --from "trainfyi[mcp]" python -m trainfyi.mcp_server
"""
from __future__ import annotations

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("TrainFYI")


@mcp.tool()
def list_stations(limit: int = 20, offset: int = 0) -> str:
    """List stations from trainfyi.com.

    Args:
        limit: Maximum number of results. Default 20.
        offset: Number of results to skip. Default 0.
    """
    from trainfyi.api import TrainFYI

    with TrainFYI() as api:
        data = api.list_stations(limit=limit, offset=offset)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return "No stations found."
        items = results[:limit] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


@mcp.tool()
def get_station(slug: str) -> str:
    """Get detailed information about a specific station.

    Args:
        slug: URL slug identifier for the station.
    """
    from trainfyi.api import TrainFYI

    with TrainFYI() as api:
        data = api.get_station(slug)
        return str(data)


@mcp.tool()
def list_operators(limit: int = 20, offset: int = 0) -> str:
    """List operators from trainfyi.com.

    Args:
        limit: Maximum number of results. Default 20.
        offset: Number of results to skip. Default 0.
    """
    from trainfyi.api import TrainFYI

    with TrainFYI() as api:
        data = api.list_operators(limit=limit, offset=offset)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return "No operators found."
        items = results[:limit] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


@mcp.tool()
def search_train(query: str) -> str:
    """Search trainfyi.com for railway stations, operators, and train routes.

    Args:
        query: Search query string.
    """
    from trainfyi.api import TrainFYI

    with TrainFYI() as api:
        data = api.search(query)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return f"No results found for \"{query}\"."
        items = results[:10] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


def main() -> None:
    """Run the MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
