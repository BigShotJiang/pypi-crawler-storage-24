"""Command-line interface for trainfyi."""

from __future__ import annotations

import json

import typer

from trainfyi.api import TrainFYI

app = typer.Typer(help="TrainFYI — Railway stations and train routes API client.")


@app.command()
def search(query: str) -> None:
    """Search trainfyi.com."""
    with TrainFYI() as api:
        result = api.search(query)
        typer.echo(json.dumps(result, indent=2))
