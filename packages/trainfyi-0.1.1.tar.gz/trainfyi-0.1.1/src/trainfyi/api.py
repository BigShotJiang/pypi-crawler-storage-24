"""HTTP API client for trainfyi.com REST endpoints.

Requires the ``api`` extra: ``pip install trainfyi[api]``

Usage::

    from trainfyi.api import TrainFYI

    with TrainFYI() as api:
        items = api.list_countries()
        detail = api.get_country("example-slug")
        results = api.search("query")
"""

from __future__ import annotations

from typing import Any

import httpx


class TrainFYI:
    """API client for the trainfyi.com REST API.

    Provides typed access to all trainfyi.com endpoints including
    list, detail, and search operations.

    Args:
        base_url: API base URL. Defaults to ``https://trainfyi.com``.
        timeout: Request timeout in seconds. Defaults to ``10.0``.
    """

    def __init__(
        self,
        base_url: str = "https://trainfyi.com",
        timeout: float = 10.0,
    ) -> None:
        self._client = httpx.Client(base_url=base_url, timeout=timeout)

    def _get(self, path: str, **params: Any) -> dict[str, Any]:
        resp = self._client.get(
            path,
            params={k: v for k, v in params.items() if v is not None},
        )
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    # -- Endpoints -----------------------------------------------------------

    def list_countries(self, **params: Any) -> dict[str, Any]:
        """List all countries."""
        return self._get("/api/v1/countries/", **params)

    def get_country(self, slug: str) -> dict[str, Any]:
        """Get country by slug."""
        return self._get(f"/api/v1/countries/" + slug + "/")

    def list_faqs(self, **params: Any) -> dict[str, Any]:
        """List all faqs."""
        return self._get("/api/v1/faqs/", **params)

    def get_faq(self, slug: str) -> dict[str, Any]:
        """Get faq by slug."""
        return self._get(f"/api/v1/faqs/" + slug + "/")

    def list_operators(self, **params: Any) -> dict[str, Any]:
        """List all operators."""
        return self._get("/api/v1/operators/", **params)

    def get_operator(self, slug: str) -> dict[str, Any]:
        """Get operator by slug."""
        return self._get(f"/api/v1/operators/" + slug + "/")

    def list_route_pairs(self, **params: Any) -> dict[str, Any]:
        """List all route pairs."""
        return self._get("/api/v1/route-pairs/", **params)

    def get_route_pair(self, slug: str) -> dict[str, Any]:
        """Get route pair by slug."""
        return self._get(f"/api/v1/route-pairs/" + slug + "/")

    def list_stations(self, **params: Any) -> dict[str, Any]:
        """List all stations."""
        return self._get("/api/v1/stations/", **params)

    def get_station(self, slug: str) -> dict[str, Any]:
        """Get station by slug."""
        return self._get(f"/api/v1/stations/" + slug + "/")

    def search(self, query: str, **params: Any) -> dict[str, Any]:
        """Search across all content."""
        return self._get(f"/api/v1/search/", q=query, **params)

    # -- Lifecycle -----------------------------------------------------------

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> TrainFYI:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()
