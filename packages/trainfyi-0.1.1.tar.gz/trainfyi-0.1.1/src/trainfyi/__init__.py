"""Python API client for trainfyi.com."""

__version__ = "0.1.0"
