"""Hotel Key enforcement — the single gate for ``codemind init`` and ``codemind scan``.

Pricing model (v3.3 — permanent free tier, no time bombs):

  Free tier (permanent — no expiry):
    - 1 project forever
    - All core tools work offline (MCP, scaffold, decisions, health)
    - AI via BYOK (user sets ANTHROPIC_API_KEY — they pay Anthropic directly)

  ``codemind init``:
    - Class A project (already activated on this key)  →  always allow
    - New project + within_project_limit               →  allow
    - New project + limit reached (server rejected it) →  BLOCK + upgrade message

  ``codemind scan``:
    - Always allowed if project was previously initialized (graph exists)
    - Never blocked for existing projects — scan is never paused

  AI features (enrichment, Pro review/brief/impact):
    - BYOK features: allowed if ANTHROPIC_API_KEY is set (free tier)
    - Pro features: require paid tier in features list
    - Expired paid license: AI paused, core tools continue

All other commands (serve, check, scaffold, decide, query) are never blocked.
"""

from __future__ import annotations

from dataclasses import dataclass

from codemind.license.license import (
    LicenseState,
    FEATURE_AI_ENRICHMENT,
    FEATURE_AI_ENRICHMENT_BYOK,
    FEATURE_PRO_REVIEW,
    FEATURE_PRO_BRIEF,
    FEATURE_PRO_IMPACT,
    EXPIRY_WARNING_DAYS,
)


@dataclass
class EnforcementResult:
    """Return value from every enforcer check."""

    allowed: bool
    reason: str = ""    # shown on block; empty when allowed
    warning: str = ""   # advisory banner; shown but does not block


def _expiry_warning(state: LicenseState) -> str:
    """Warning shown when a paid subscription is close to expiry."""
    days = state.days_until_expiry
    if days is None or days > EXPIRY_WARNING_DAYS or days <= 0:
        return ""
    unit = "day" if days == 1 else "days"
    return (
        f"Subscription expires in {days} {unit}. "
        "Visit codemind.sh/dashboard to renew."
    )


def _limit_reached_reason() -> str:
    return (
        "Free plan supports 1 project.\n\n"
        "  Upgrade at [cyan]codemind.sh/upgrade[/cyan] to add unlimited projects\n"
        "  and unlock Pro AI features (review, brief, impact --ai)."
    )


def _expired_paid_warning() -> str:
    return (
        "Subscription expired — AI features paused. "
        "Core tools continue working offline. "
        "Renew at codemind.sh/dashboard."
    )


class LicenseEnforcer:
    """Apply Hotel Key rules. Stateless — takes a :class:`LicenseState` each call."""

    def check_init(self, state: LicenseState, project_id: str) -> EnforcementResult:
        """Can ``codemind init`` proceed for *project_id*?

        Rules:
        - Class A project (already in activated_projects): always allow.
        - New project + within project limit: allow.
        - New project + limit reached: BLOCK.
          (The server enforced this first; local check is a secondary gate
          when offline or when the server already rejected /validate.)
        """
        # Class A: project was previously initialized on this key — never block
        if state.is_class_a(project_id):
            return EnforcementResult(allowed=True, warning=_expiry_warning(state))

        # Expired paid license: block new project init (renewal required)
        if state.is_expired:
            return EnforcementResult(
                allowed=False,
                reason=(
                    "Subscription expired. Existing projects continue working offline.\n"
                    "  Renew at [cyan]codemind.sh/dashboard[/cyan] to add new projects."
                ),
            )

        # Check project limit (secondary to server-side enforcement)
        if not state.within_project_limit():
            return EnforcementResult(allowed=False, reason=_limit_reached_reason())

        return EnforcementResult(allowed=True, warning=_expiry_warning(state))

    def check_scan(
        self,
        state: LicenseState,
        project_id: str,
        graph_exists: bool,
    ) -> EnforcementResult:
        """Can ``codemind scan`` proceed?

        Scan is always allowed for existing projects (graph exists or project
        was previously activated). It is never paused — only AI enrichment
        may be restricted.
        """
        if state.is_class_a(project_id) or graph_exists:
            # Warn if paid license expired but never block scan
            warning = _expired_paid_warning() if state.is_expired else _expiry_warning(state)
            return EnforcementResult(allowed=True, warning=warning)

        # Project not yet initialized — check limit before first scan
        if not state.within_project_limit():
            return EnforcementResult(allowed=False, reason=_limit_reached_reason())

        return EnforcementResult(allowed=True, warning=_expiry_warning(state))

    def ai_allowed(self, state: LicenseState) -> bool:
        """True when server-paid AI enrichment may run (Pro+).

        Free tier users run AI via BYOK (their own key) — always allowed
        if they have set ANTHROPIC_API_KEY. Only the Pro-tier managed
        enrichment (we pay) requires a non-expired paid license.
        """
        return state.has_feature(FEATURE_AI_ENRICHMENT)

    def byok_ai_allowed(self, state: LicenseState) -> bool:
        """True when BYOK AI (user's own key) may run — free + paid tiers."""
        return (
            state.has_feature(FEATURE_AI_ENRICHMENT_BYOK)
            or state.has_feature(FEATURE_AI_ENRICHMENT)
        )

    def pro_features_allowed(self, state: LicenseState) -> bool:
        """True when Pro AI commands (review, brief, impact --ai) are available."""
        return any(
            state.has_feature(f)
            for f in (FEATURE_PRO_REVIEW, FEATURE_PRO_BRIEF, FEATURE_PRO_IMPACT)
        )
