from .hayazip import *

__doc__ = hayazip.__doc__
if hasattr(hayazip, "__all__"):
    __all__ = hayazip.__all__