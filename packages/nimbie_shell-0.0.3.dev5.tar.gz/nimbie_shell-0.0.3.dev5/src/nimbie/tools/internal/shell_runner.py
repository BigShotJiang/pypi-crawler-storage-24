from __future__ import annotations

import asyncio
import datetime as dt
from dataclasses import dataclass
import os
import queue
import re
import signal
import subprocess
import sys
import tempfile
import threading
import time
from typing import Any, Callable

try:
    import nimbie_flash as flash
except Exception:
    flash = None

from ..tool_runtime import BaseTool, ToolExecutionError, ToolGateDecision, ToolGateStatus
from ...command_policy import get_audit_details, should_auto_allow
from ...model import ToolMessageContent, UserContent

BACKGROUND_SYSTEM_USER = "background-process-manager"
BACKGROUND_SYSTEM_EMAIL = "background@nimbie.local"


@dataclass(slots=True)
class BackgroundProcessRecord:
    command_id: str
    command: str
    process: subprocess.Popen[Any]
    started_at_monotonic: float
    stdout_file: Any
    stderr_file: Any


class BackgroundProcessStore:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._entries: dict[str, BackgroundProcessRecord] = {}

    def register(self, command: str, process: subprocess.Popen[Any], stdout_file: Any, stderr_file: Any) -> str:
        try:
            command_id = str(os.getpgid(process.pid))
        except Exception:
            command_id = str(process.pid)
        record = BackgroundProcessRecord(
            command_id=command_id,
            command=command,
            process=process,
            started_at_monotonic=time.monotonic(),
            stdout_file=stdout_file,
            stderr_file=stderr_file,
        )
        with self._lock:
            self._entries[command_id] = record
        return command_id

    def list_snapshot(self, *, include_completed_output: bool = True) -> list[dict[str, Any]]:
        now = time.monotonic()
        with self._lock:
            records = list(self._entries.values())
        payloads: list[dict[str, Any]] = []
        for record in records:
            retcode = record.process.poll()
            item: dict[str, Any] = {
                "id": record.command_id,
                "command": record.command,
                "pid": record.process.pid,
                "runtime": _format_runtime(now - record.started_at_monotonic),
                "retcode": retcode,
                "status": "running" if retcode is None else "completed",
            }
            if retcode is not None and include_completed_output:
                item["stdout"] = _read_temp_bytes(record.stdout_file)
                item["stderr"] = _read_temp_bytes(record.stderr_file)
            payloads.append(item)
        return payloads

    def wait_or_get(self, command_id: str, timeout: int = 60) -> dict[str, Any]:
        record = self._get(command_id)
        if record is None:
            return {"status": "not_found", "command_id": command_id}
        before_wait = time.monotonic()
        retcode = record.process.poll()
        if retcode is None:
            try:
                record.process.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                retcode = None
            else:
                retcode = record.process.poll()
        payload: dict[str, Any] = {
            "command_id": record.command_id,
            "command": record.command,
            "runtime": _format_runtime(time.monotonic() - record.started_at_monotonic),
            "status": "running" if retcode is None else "completed",
            "waited": _format_runtime(time.monotonic() - before_wait),
        }
        if retcode is None:
            return payload
        payload.update(
            {
                "retcode": retcode,
                "stdout": _read_temp_bytes(record.stdout_file),
                "stderr": _read_temp_bytes(record.stderr_file),
            }
        )
        self.remove(command_id)
        return payload

    def terminate(self, command_id: str) -> dict[str, Any]:
        record = self._get(command_id)
        if record is None:
            return {"status": "not_found", "command_id": command_id}
        process = record.process
        try:
            try:
                os.killpg(os.getpgid(process.pid), signal.SIGTERM)
            except Exception:
                process.terminate()
            process.wait(timeout=3)
        except Exception:
            try:
                try:
                    os.killpg(os.getpgid(process.pid), signal.SIGKILL)
                except Exception:
                    process.kill()
                process.wait(timeout=3)
            except Exception:
                pass
        self.remove(command_id)
        return {"status": "terminated", "command_id": command_id, "command": record.command}

    def has_running(self) -> bool:
        with self._lock:
            return bool(self._entries)

    def remove(self, command_id: str) -> None:
        with self._lock:
            self._entries.pop(command_id, None)

    def _get(self, command_id: str) -> BackgroundProcessRecord | None:
        with self._lock:
            return self._entries.get(command_id)


class ShellCommandRunner:
    GREP_PATTERN = re.compile(r"^\s*(grep|egrep|fgrep|zgrep|rg|ripgrep)\b")
    HEREDOC_PATTERN = re.compile(
        r"""
        ( ^ | [;&|]\s* | \s )
        <<-?
        \s*
        (['"]?)
        ([^'"\\s]+)
        \1
        """,
        re.MULTILINE | re.VERBOSE,
    )

    def __init__(self, background_store: BackgroundProcessStore) -> None:
        self._background_store = background_store

    def execute(
        self,
        command: str,
        *,
        timeout: int,
        run_in_background: bool,
        emit_event: Callable[[dict[str, Any]], None] | None,
    ) -> dict[str, Any]:
        prepared_command = self._prepare_command(command)
        if run_in_background:
            process, stdout_file, stderr_file = self._spawn_background_process(prepared_command)
            command_id = self._background_store.register(prepared_command, process, stdout_file, stderr_file)
            return {
                "status": "background",
                "command_id": command_id,
                "command": prepared_command,
                "message": f"Command running in background as PGID {command_id}.",
            }
        result = self._run(prepared_command, timeout=timeout, emit_event=emit_event)
        if result["retcode"] != 0:
            raise ToolExecutionError(
                f"Command exited with code {result['retcode']}",
                metadata={
                    "exit_code": result["retcode"],
                    "stdout": result["stdout"],
                    "stderr": result["stderr"],
                    "actual_command": prepared_command,
                },
            )
        return {
            "exit_code": result["retcode"],
            "stdout": result["stdout"],
            "stderr": result["stderr"],
            "actual_command": prepared_command,
        }

    def _run(self, command: str, *, timeout: int, emit_event: Callable[[dict[str, Any]], None] | None) -> dict[str, Any]:
        retcode, stdout, stderr, streamed = self._run_via_flash(
            command,
            timeout=timeout,
            emit=self._stream_emitter(emit_event),
        )
        folded_stdout = self._fold_output(stdout)
        folded_stderr = self._fold_output(stderr)
        if emit_event is None:
            self._mirror_output(stdout=stdout, stderr=stderr, already_streamed=streamed)
        elif not streamed:
            if stdout:
                emit_event({"type": "tool_output", "stream": "stdout", "text": stdout})
            if stderr:
                emit_event({"type": "tool_output", "stream": "stderr", "text": stderr})
        return {"retcode": retcode, "stdout": folded_stdout, "stderr": folded_stderr, "streamed": streamed}

    def _prepare_command(self, command: str) -> str:
        if not self.GREP_PATTERN.match(command):
            return command
        if "--exclude-dir" in command or "--exclude" in command:
            return command
        parts = command.strip().split()
        if not parts:
            return command
        insert_at = 1
        for index, token in enumerate(parts[1:], start=1):
            if not token.startswith("-"):
                insert_at = index
                break
        parts.insert(insert_at, "--exclude-dir=.nimbie")
        return " ".join(parts)

    def _contains_heredoc(self, command: str) -> bool:
        return bool(self.HEREDOC_PATTERN.search(command))

    def _run_via_subprocess(self, command: str, *, timeout: int) -> tuple[int, str, str]:
        try:
            result = subprocess.run(command, shell=True, capture_output=True, text=True, timeout=timeout)
            return result.returncode, result.stdout, result.stderr
        except subprocess.TimeoutExpired:
            return 124, "", f"Command timed out after {timeout} seconds"
        except Exception as exc:
            return 1, "", str(exc)

    def _run_via_flash(
        self,
        command: str,
        *,
        timeout: int,
        emit: Callable[[str, str], None] | None,
    ) -> tuple[int, str, str, bool]:
        if flash is None:
            return 1, "", "flash runtime unavailable; refusing shell=True fallback", False
        try:
            interpreter = flash.FlashInterpreter()
            executor = flash.LocalExecutor()
            output_chunks: list[str] = []
            error_chunks: list[str] = []
            result_queue: queue.Queue[Any] = queue.Queue(maxsize=1)
            event_queue: queue.Queue[tuple[str, str]] = queue.Queue()

            def on_event(event: Any) -> None:
                if not isinstance(event, dict):
                    return
                stream_type = str(event.get("type") or "")
                text = str(event.get("data") or event.get("stdout") or event.get("stderr") or "")
                if not text:
                    return
                if stream_type == "stderr":
                    event_queue.put(("stderr", text))
                elif stream_type in {"stdout", "raw"}:
                    event_queue.put(("stdout", text))

            def worker() -> None:
                try:
                    result_queue.put(("ok", interpreter.run_shell_stream(command, executor, on_event)))
                except Exception as exc:
                    result_queue.put(("err", exc))

            thread = threading.Thread(target=worker, daemon=True)
            thread.start()
            deadline = time.monotonic() + max(1, int(timeout))
            timed_out = False
            while thread.is_alive():
                self._drain_event_queue(event_queue, output_chunks, error_chunks, emit)
                if time.monotonic() >= deadline:
                    timed_out = True
                    break
                thread.join(0.05)
            if timed_out:
                try:
                    executor.close_run()
                except Exception:
                    pass
                thread.join(0.3)
                self._drain_event_queue(event_queue, output_chunks, error_chunks, emit)
                return 124, "".join(output_chunks), f"Command timed out after {timeout} seconds", True
            self._drain_event_queue(event_queue, output_chunks, error_chunks, emit)
            if result_queue.empty():
                return 1, "".join(output_chunks), "".join(error_chunks) or "No result from flash executor", True
            status, payload = result_queue.get_nowait()
            if status == "err":
                return 1, "".join(output_chunks), "".join(error_chunks) or str(payload), True
            return (
                int(getattr(payload, "exit_code", 1)),
                "".join(output_chunks) or str(getattr(payload, "stdout", "") or ""),
                "".join(error_chunks) or str(getattr(payload, "stderr", "") or ""),
                True,
            )
        except Exception as exc:
            return 1, "", str(exc), False

    def _drain_event_queue(
        self,
        event_queue: queue.Queue[tuple[str, str]],
        stdout_chunks: list[str],
        stderr_chunks: list[str],
        emit: Callable[[str, str], None] | None,
    ) -> None:
        while True:
            try:
                stream, chunk = event_queue.get_nowait()
            except queue.Empty:
                return
            if stream == "stderr":
                stderr_chunks.append(chunk)
            else:
                stdout_chunks.append(chunk)
            if emit is not None:
                emit(stream, chunk)

    def _spawn_background_process(self, command: str) -> tuple[subprocess.Popen[Any], Any, Any]:
        stdout_file = tempfile.TemporaryFile()
        stderr_file = tempfile.TemporaryFile()
        process = subprocess.Popen(
            command,
            shell=True,
            stdout=stdout_file,
            stderr=stderr_file,
            start_new_session=True,
        )
        return process, stdout_file, stderr_file

    def _stream_emitter(self, emit_event: Callable[[dict[str, Any]], None] | None) -> Callable[[str, str], None] | None:
        if emit_event is None:
            return None

        def emit(stream: str, text: str) -> None:
            if text:
                emit_event({"type": "tool_output", "stream": stream, "text": text})

        return emit

    def _mirror_output(self, *, stdout: str, stderr: str, already_streamed: bool) -> None:
        if already_streamed:
            return
        if stdout:
            sys.stdout.write(stdout + ("" if stdout.endswith("\n") else "\n"))
            sys.stdout.flush()
        if stderr:
            sys.stderr.write(stderr + ("" if stderr.endswith("\n") else "\n"))
            sys.stderr.flush()

    def _fold_output(self, output: str, keep_bytes: int = 10240) -> str:
        if not output or len(output) <= keep_bytes * 2:
            return output
        prefix = output[:keep_bytes]
        suffix = output[-keep_bytes:]
        collapsed = len(output) - keep_bytes * 2
        if collapsed >= 1024 * 1024:
            summary = f"{collapsed // (1024 * 1024)} MB"
        elif collapsed >= 1024:
            summary = f"{collapsed // 1024} KB"
        else:
            summary = f"{collapsed} bytes"
        return f"{prefix}\n\n(...{summary} collapsed...)\n\n{suffix}"


_BACKGROUND_STORE = BackgroundProcessStore()
_COMMAND_RUNNER = ShellCommandRunner(_BACKGROUND_STORE)


def _format_runtime(seconds: float) -> str:
    if seconds < 1:
        return f"{seconds * 1000:.0f}ms"
    return f"{seconds:.1f}s"


def _read_temp_bytes(handle: Any) -> str:
    try:
        handle.flush()
        handle.seek(0)
        return (handle.read() or b"").decode("utf-8", errors="backslashreplace")
    except Exception:
        return ""


def wait_or_get_result(command_id: str, timeout: int = 60) -> dict[str, Any]:
    return _BACKGROUND_STORE.wait_or_get(command_id, timeout=timeout)


def terminate_background_command(command_id: str) -> dict[str, Any]:
    return _BACKGROUND_STORE.terminate(command_id)


def has_background_processes() -> bool:
    return _BACKGROUND_STORE.has_running()


def get_background_registry_snapshot() -> list[dict[str, Any]]:
    return _BACKGROUND_STORE.list_snapshot()


def kill_background_command(command_id: str) -> dict[str, Any]:
    return terminate_background_command(command_id)


class ShellCommandTool(BaseTool):
    @classmethod
    @property
    def name(cls) -> str:
        return "execute_shell_command"

    @property
    def description(self) -> str:
        return "Execute shell command(s) in the current working directory."

    @property
    def schema(self) -> dict[str, Any]:
        return self.get_schema()

    @classmethod
    def get_schema(cls) -> dict[str, Any]:
        return {
            "type": "function",
            "function": {
                "name": cls.name,
                "description": (
                    "Execute shell command(s) in the current working directory. "
                    "Use run_background to keep the process running."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "command": {"type": "string", "description": "Shell command to run."},
                        "timeout": {"type": "integer", "minimum": 1, "maximum": 600, "default": 60},
                        "run_background": {
                            "type": "boolean",
                            "description": "When true, run the command in background and ignore timeout.",
                            "default": False,
                        },
                    },
                    "required": ["command"],
                },
            },
        }

    @staticmethod
    def execute(
        command: str,
        timeout: int = 60,
        run_background: bool = False,
        emit_event: Callable[[dict[str, Any]], None] | None = None,
    ) -> dict[str, Any]:
        try:
            return _COMMAND_RUNNER.execute(
                command,
                timeout=timeout,
                run_in_background=run_background,
                emit_event=emit_event,
            )
        except ToolExecutionError:
            raise
        except Exception as exc:
            raise ToolExecutionError("Failed to execute shell command", metadata={"error": str(exc)})

    @classmethod
    def validate_arguments(cls, args: dict[str, Any]) -> str | None:
        command = args.get("command")
        if not isinstance(command, str) or not command:
            return "command is required"
        timeout = args.get("timeout", 60)
        if not isinstance(timeout, int) or timeout <= 0:
            return "timeout must be a positive integer"
        run_background = args.get("run_background", False)
        if not isinstance(run_background, bool):
            return "run_background must be a boolean"
        return None

    @classmethod
    def get_preview(cls, args: dict[str, Any]) -> str | None:
        command = str(args.get("command", "") or "")
        if not command:
            return None
        timeout = args.get("timeout", 60)
        run_background = bool(args.get("run_background", False))
        lines = [f"```bash\n{command}\n```", f"timeout={timeout}"]
        if run_background:
            lines.append("run_background=true")
        return "\n".join(lines) + "\n"

    @classmethod
    def get_precheck(cls, args: dict[str, Any]) -> ToolGateDecision:
        command = str(args.get("command", "") or "").strip()
        if not command:
            return ToolGateDecision(status=ToolGateStatus.DENY, message="Empty command.")
        if should_auto_allow(command):
            return ToolGateDecision(status=ToolGateStatus.ALLOW)
        decision, reasons, suggestions = get_audit_details(command)
        details = [str(item) for item in [*reasons, *suggestions] if item]
        if decision == "REJECT":
            return ToolGateDecision(
                status=ToolGateStatus.DENY,
                message="Command rejected by policy.",
                reasons=details or ["Policy rejected the command."],
            )
        return ToolGateDecision(
            status=ToolGateStatus.NEEDS_APPROVAL,
            message="Command requires approval.",
            reasons=details,
            metadata={"suggestions": suggestions},
        )

    @classmethod
    def user_input_hook(cls) -> UserContent | None:
        snapshot = _BACKGROUND_STORE.list_snapshot(include_completed_output=False)
        if not snapshot:
            return None
        any_completed = any(item.get("status") == "completed" for item in snapshot)
        lines = ["[Background Command Status]"]
        for item in snapshot:
            lines.append(f"PGID: {item.get('id', '-')}")
            lines.append(f"Command: {item.get('command', '')}")
            lines.append(f"Runtime: {item.get('runtime', '-')}")
            if item.get("status") == "completed":
                lines.append(f"Retcode: {item.get('retcode', '')}")
                lines.append("Output: omitted in prompt hook (use background_cmd_wait_or_get_result to fetch full stdout/stderr)")
            elif not any_completed:
                lines.append("Status: running")
            lines.append("")
        return UserContent(
            user_name=BACKGROUND_SYSTEM_USER,
            email=BACKGROUND_SYSTEM_EMAIL,
            date=dt.datetime.now().astimezone(),
            content="\n".join(lines).strip(),
        )

    @classmethod
    def get_request_template(cls, prefix: str) -> str:
        return (
            f"## {{name}} shell request\n\n{prefix}.function.arguments:\n\n```json\n"
            "{{ .function.arguments:json }}\n```\n\n{{ .content:code-block }}"
        )

    @classmethod
    def get_response_template(cls, item: Any) -> str | None:
        content = getattr(item, "content", None)
        if not isinstance(content, ToolMessageContent) or not isinstance(content.data, dict):
            return None
        sections = ["# Bash Result"]
        if str(content.data.get("stdout", "")).strip():
            sections.extend(["## stdout", "{.content.data.stdout:code-block}"])
        if str(content.data.get("stderr", "")).strip():
            sections.extend(["## stderr", "{.content.data.stderr:code-block}"])
        sections.extend(["## exit_code", "{.content.data.exit_code:code-block}"])
        return "\n\n".join(sections)


class BackgroundCommandTool(BaseTool):
    @classmethod
    @property
    def name(cls) -> str:
        return "background_cmd_wait_or_get_result"

    @property
    def description(self) -> str:
        return "Wait for a background command to finish or return its current status."

    @property
    def schema(self) -> dict[str, Any]:
        return self.get_schema()

    @classmethod
    def get_schema(cls) -> dict[str, Any]:
        return {
            "type": "function",
            "function": {
                "name": cls.name,
                "description": cls().description,
                "parameters": {
                    "type": "object",
                    "properties": {
                        "command_id": {"type": "string", "description": "Background command PGID to query."},
                        "timeout": {"type": "integer", "minimum": 1, "maximum": 600, "default": 60},
                    },
                    "required": ["command_id"],
                },
            },
        }

    @staticmethod
    def execute(command_id: str, timeout: int = 60) -> dict[str, Any]:
        return wait_or_get_result(command_id, timeout=timeout)

    @classmethod
    def validate_arguments(cls, args: dict[str, Any]) -> str | None:
        if not isinstance(args.get("command_id"), str) or not args.get("command_id"):
            return "command_id is required"
        timeout = args.get("timeout", 60)
        if not isinstance(timeout, int) or timeout <= 0:
            return "timeout must be a positive integer"
        return None

    @classmethod
    def get_preview(cls, args: dict[str, Any]) -> str | None:
        command_id = str(args.get("command_id", "") or "")
        if not command_id:
            return None
        return f"background_cmd_wait_or_get_result: {command_id} (timeout={args.get('timeout', 60)})"

    @classmethod
    def get_precheck(cls, args: dict[str, Any]) -> ToolGateDecision:
        return ToolGateDecision(status=ToolGateStatus.ALLOW)
