"""
Slash Command System for Nimbie REPL
"""
from abc import ABC, abstractmethod
from typing import List, Optional, Callable, Awaitable
from dataclasses import dataclass
from typing import Any, TYPE_CHECKING
if TYPE_CHECKING:
    from .repl_app import ReplApp

@dataclass
class CommandContext:
    """Context passed to slash command handlers."""
    app: 'ReplApp'
    args: List[str]
    raw_input: str
    lazy_input: bool
    future: Optional[Any]

class SlashCommand(ABC):
    """Base class for slash commands."""

    @property
    @abstractmethod
    def name(self) -> str:
        """Command name (e.g., '/restore')"""
        pass

    @property
    @abstractmethod
    def usage(self) -> str:
        """Usage string (e.g., '<snapshot_id>')"""
        pass

    @property
    @abstractmethod
    def description(self) -> str:
        """One-line description"""
        pass

    @property
    def aliases(self) -> List[str]:
        """Alternative command names"""
        return []

    @property
    def requires_session(self) -> bool:
        """Whether this command requires session initialization"""
        return False

    @abstractmethod
    async def execute(self, ctx: CommandContext) -> None:
        """Execute the command"""
        pass

    def on_error(self, ctx: CommandContext, error: Exception) -> None:
        """Handle execution error"""
        ctx.app.renderer.print_error(f'[{self.name}] Error: {error}')

class ExitCommand(SlashCommand):
    name = '/exit'
    aliases = ['/quit', 'exit', 'quit']
    usage = ''
    description = 'Exit nimbie'
    requires_session = False

    async def execute(self, ctx: CommandContext) -> None:
        import sys
        try:
            sys.stdout.write('Bye\n')
            sys.stdout.flush()
        except Exception:
            pass
        ctx.app._signal_exit()

class BackgroundCommand(SlashCommand):
    name = '/bg'
    aliases = ['/background']
    usage = ''
    description = 'Open background process manager'
    requires_session = True

    async def execute(self, ctx: CommandContext) -> None:
        await ctx.app._run_background_manager_ui()

class GatewayCommand(SlashCommand):
    name = '/gateway'
    usage = ''
    description = 'Open gateway manager'
    requires_session = False

    async def execute(self, ctx: CommandContext) -> None:
        await ctx.app._run_gateway_ui()

class HistoryCommand(SlashCommand):
    name = '/history'
    usage = ''
    description = 'View command history'
    requires_session = True

    async def execute(self, ctx: CommandContext) -> None:
        await ctx.app._run_history_ui()

class CompactCommand(SlashCommand):
    name = '/compact'
    usage = ''
    description = 'Compact context'
    requires_session = True

    async def execute(self, ctx: CommandContext) -> None:
        await ctx.app._run_compact(ctx.raw_input)

class ConnectSSHCommand(SlashCommand):
    name = '/connect-ssh'
    aliases = ['/ssh']
    usage = '[--force] [user@]host[:port]'
    description = 'Connect to remote host via SSH'
    requires_session = False

    async def execute(self, ctx: CommandContext) -> None:
        args = ctx.args[1:] if ctx.args else []
        force_upload = False
        if '--force' in args:
            force_upload = True
            args = [a for a in args if a != '--force']
        if len(args) < 1:
            ctx.app.renderer.print_warning('usage: /connect-ssh [--force] [user@]host[:port]')
            return
        target = args[0]
        try:
            msg = await ctx.app.shell.connect_ssh(target, force_upload=force_upload)
            ctx.app.renderer.print_info(f'[ssh] {msg}')
        except Exception as e:
            ctx.app.renderer.print_error(f'[ssh] connect failed: {e}')


class ConnectCommand(SlashCommand):
    name = '/connect'
    usage = '[--force] <provider> <target> | [--force] <provider>:<target>'
    description = 'Connect via provider (ssh, jumper-ssh)'
    requires_session = False

    async def execute(self, ctx: CommandContext) -> None:
        args = ctx.args[1:] if ctx.args else []
        force_upload = False
        if '--force' in args:
            force_upload = True
            args = [a for a in args if a != '--force']
        if not args:
            ctx.app.renderer.print_warning('usage: /connect [--force] <provider> <target> | <provider>:<target>')
            return
        provider = ''
        target = ''
        if len(args) == 1 and ':' in args[0]:
            provider, target = args[0].split(':', 1)
        elif len(args) >= 2:
            provider = args[0]
            target = args[1]
        provider = provider.strip()
        target = target.strip()
        if not provider or not target:
            ctx.app.renderer.print_warning('usage: /connect [--force] <provider> <target> | <provider>:<target>')
            return
        try:
            msg = await ctx.app.shell.connect_with_provider(provider, target, force_upload=force_upload)
            ctx.app.renderer.print_info(f'[{provider}] {msg}')
        except Exception as e:
            ctx.app.renderer.print_error(f'[{provider}] connect failed: {e}')

class DisconnectSSHCommand(SlashCommand):
    name = '/disconnect-ssh'
    usage = ''
    description = 'Disconnect SSH and switch to local executor'
    requires_session = False

    async def execute(self, ctx: CommandContext) -> None:
        ctx.app.shell.disconnect_ssh()
        ctx.app.renderer.print_info('[ssh] disconnected, switched to local executor')

class RestoreCommand(SlashCommand):
    name = '/restore'
    usage = '<snapshot_id>'
    description = 'Restore worktree to a ghost snapshot'
    requires_session = False

    async def execute(self, ctx: CommandContext) -> None:
        import shlex
        from pathlib import Path
        from nimbie.tools.internal.file_patcher import restore_ghost_snapshot_by_id
        if len(ctx.args) < 2:
            ctx.app.renderer.print_warning('usage: /restore <snapshot_id>')
            ctx.app.renderer.print_info('snapshot_id comes from edit tool result: ghost_snapshot.id')
            return
        snapshot_id = ctx.args[1]
        try:
            success = restore_ghost_snapshot_by_id(Path.cwd(), snapshot_id)
            if success:
                ctx.app.renderer.print_info(f'[restore] Successfully restored to snapshot {snapshot_id}')
            else:
                ctx.app.renderer.print_error(f'[restore] Failed to restore snapshot {snapshot_id}')
        except Exception as e:
            ctx.app.renderer.print_error(f'[restore] Error: {e}')

class SlashCommandRegistry:
    """Registry for slash commands."""

    def __init__(self) -> None:
        self._commands: dict[str, SlashCommand] = {}
        self._aliases: dict[str, str] = {}

    def register(self, cmd: SlashCommand) -> None:
        self._commands[cmd.name] = cmd
        for alias in cmd.aliases:
            self._aliases[alias] = cmd.name

    def get(self, name: str) -> Optional[SlashCommand]:
        canonical = self._aliases.get(name, name)
        return self._commands.get(canonical)

    def resolve(self, input_text: str) -> tuple[Optional[SlashCommand], List[str]]:
        """Resolve input to command and args. Returns (command, args)."""
        if not input_text:
            return (None, [])
        parts = input_text.split(None, 1)
        cmd_name = parts[0]
        args = parts[1].split() if len(parts) > 1 else []
        cmd = self.get(cmd_name)
        return (cmd, args)

    def all_commands(self) -> List[SlashCommand]:
        return list(self._commands.values())

    def help_text(self) -> str:
        lines = ['Available commands:']
        for cmd in self._commands.values():
            lines.append(f'  {cmd.name} {cmd.usage} - {cmd.description}')
        return '\n'.join(lines)
_slash_commands = SlashCommandRegistry()
_slash_commands.register(ExitCommand())
_slash_commands.register(BackgroundCommand())
_slash_commands.register(GatewayCommand())
_slash_commands.register(HistoryCommand())
_slash_commands.register(CompactCommand())
_slash_commands.register(ConnectSSHCommand())
_slash_commands.register(ConnectCommand())
_slash_commands.register(DisconnectSSHCommand())
_slash_commands.register(RestoreCommand())

def get_slash_command_registry() -> SlashCommandRegistry:
    return _slash_commands
