from __future__ import annotations
import asyncio
import json
import os
import sys
import time
import threading
import select
import signal
import traceback
import shutil
import subprocess
import shlex
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, List, Tuple, Any
from collections import deque
import click
from rich.console import Console
from rich.markdown import Markdown
from rich.style import Style
from rich.text import Text
from .renderer import Renderer, RendererConfig, RenderState
from ..shared.remote_shell_support import RemoteShellSupport
from oturn import Oturn, OturnConfig, OturnProviderConfig, OturnModelConfig, OturnAgentConfig, Context, Message
from ...model import ShellResult
import datetime as _dt
from ...system_prompt import get_system_prompt
from ...command_policy import parse_shell_command
from ...tools import registry as nimbie_tool_registry
from ...tools.internal.shell_runner import get_background_registry_snapshot
from ..process_overview_textual import ProcessOverviewApp
from ..session_history_inspector_textual import SessionHistoryInspectorApp
try:
    import termios as _termios
    import tty as _tty
except Exception:
    _termios = None
    _tty = None
_SESSION_META_DIR = '.nimbie'
_SESSION_GLOBAL_ROOT = Path.home() / '.nimbie' / 'global_sessions'
_SHELL_BUILTINS = {'.', ':', '[', 'alias', 'bg', 'break', 'cd', 'continue', 'echo', 'eval', 'exec', 'exit', 'export', 'fg', 'hash', 'jobs', 'printf', 'pwd', 'read', 'return', 'set', 'shift', 'source', 'test', 'times', 'trap', 'true', 'false', 'type', 'ulimit', 'umask', 'unalias', 'unset', 'wait'}

def _build_ps1_prompt_fallback() -> str:
    user, host, cwd, suffix = _build_ps1_prompt_parts()
    return f'{user}@{host}:{cwd}{suffix} '

def _build_ps1_prompt_parts() -> tuple[str, str, str, str]:
    import socket
    user = os.getenv('USER') or os.getenv('USERNAME') or 'user'
    try:
        host = socket.gethostname().split('.', 1)[0] or 'host'
    except Exception:
        host = 'host'
    try:
        cwd = os.getcwd()
        home = str(Path.home())
        if home and cwd.startswith(home):
            cwd = '~' + cwd[len(home):]
    except Exception:
        cwd = '?'
    try:
        is_root = hasattr(os, 'geteuid') and os.geteuid() == 0
    except Exception:
        is_root = False
    suffix = '#' if is_root else '$'
    return (user, host, cwd, suffix)

def _format_approval_subtitle(message: str, args: dict[str, Any]) -> str:
    if message:
        return message
    return json.dumps(args, ensure_ascii=False, indent=2) if isinstance(args, dict) else str(args)

@dataclass
class ReplOptions:
    provider: Any
    model: str
    model_config: Any
    agent_config: Any
    ui_config: Any
    new_session: bool = False
    resume_id: Optional[str] = None
    fork_session_id: Optional[str] = None
    debug_loop: bool = False
    connect: Optional[str] = None

class EscCancelController:
    """
    负责非-PTK阶段（tool运行、spinner显示期间）的 ESC 双击取消。
    PTK 阶段建议直接在 key bindings 里处理（更靠谱）。
    """

    def __init__(self) -> None:
        self._thread: Optional[threading.Thread] = None
        self._stop_evt: Optional[threading.Event] = None
        self._fd: Optional[int] = None
        self._orig: Any = None
        self._agent: Any = None

    def start(self, agent: Any) -> None:
        if _termios is None or _tty is None:
            return
        if self._thread is not None:
            return
        try:
            fd = sys.stdin.fileno()
            orig = _termios.tcgetattr(fd)
            _tty.setcbreak(fd)
        except Exception:
            return
        stop_evt = threading.Event()
        self._fd = fd
        self._orig = orig
        self._stop_evt = stop_evt
        self._agent = agent

        def _consume_after_esc(fd: int, grace: float=0.03) -> str:
            r, _, _ = select.select([fd], [], [], max(0.0, grace))
            if not r:
                return 'isolated'
            try:
                b2 = os.read(fd, 1)
            except Exception:
                return 'isolated'
            if not b2:
                return 'isolated'
            if b2 == b'O':
                select.select([fd], [], [], 0.02)
                try:
                    os.read(fd, 1)
                except Exception:
                    pass
                return 'control'
            if b2 == b'[':
                end_deadline = time.monotonic() + 0.08
                while time.monotonic() < end_deadline:
                    r, _, _ = select.select([fd], [], [], 0.02)
                    if not r:
                        break
                    try:
                        b = os.read(fd, 1)
                    except Exception:
                        break
                    if not b:
                        break
                    if 64 <= b[0] <= 126:
                        return 'control'
                return 'control'
            if b2 in (b']', b'P', b'_', b'^'):
                end_deadline = time.monotonic() + 0.2
                prev = b''
                while time.monotonic() < end_deadline:
                    r, _, _ = select.select([fd], [], [], 0.02)
                    if not r:
                        break
                    try:
                        b = os.read(fd, 1)
                    except Exception:
                        break
                    if not b:
                        break
                    if b == b'\x07':
                        return 'control'
                    if prev == b'\x1b' and b == b'\\':
                        return 'control'
                    prev = b
                return 'control'
            if b2 in (b'(', b')', b'*', b'+', b'#', b'=', b'>', b'7', b'8'):
                select.select([fd], [], [], 0.02)
                try:
                    os.read(fd, 1)
                except Exception:
                    pass
                return 'control'
            return 'alt_or_text'

        def _loop() -> None:
            last = 0.0
            try:
                while not stop_evt.is_set():
                    r, _, _ = select.select([fd], [], [], 0.1)
                    if not r:
                        continue
                    try:
                        b = os.read(fd, 1)
                    except Exception:
                        break
                    if not b:
                        continue
                    if b == b'\x1b':
                        now = time.monotonic()
                        kind = _consume_after_esc(fd)
                        if kind != 'isolated':
                            continue
                        if now - last < 0.6:
                            try:
                                self._agent.request_cancel_tool()
                            except Exception:
                                pass
                            last = 0.0
                        else:
                            last = now
            finally:
                try:
                    if self._orig is not None and self._fd is not None and (_termios is not None):
                        _termios.tcsetattr(self._fd, _termios.TCSADRAIN, self._orig)
                except Exception:
                    pass
        th = threading.Thread(target=_loop, daemon=True)
        self._thread = th
        th.start()

    def stop(self) -> None:
        if self._stop_evt is not None:
            self._stop_evt.set()
        if self._thread is not None:
            try:
                self._thread.join(timeout=0.5)
            except Exception:
                pass
        try:
            if self._orig is not None and self._fd is not None and (_termios is not None):
                _termios.tcsetattr(self._fd, _termios.TCSADRAIN, self._orig)
        except Exception:
            pass
        self._thread = None
        self._stop_evt = None
        self._fd = None
        self._orig = None
        self._agent = None

class ShellAdapter(RemoteShellSupport):

    def __init__(self, opts: ReplOptions) -> None:
        super().__init__(opts)

    def _prompt_parts(self) -> tuple[str, str, str, str]:
        user, host, cwd, suffix = _build_ps1_prompt_parts()
        if self._remote_executor_path and self._remote_ssh_host:
            if self._remote_identity_user:
                user = str(self._remote_identity_user)
            if self._remote_identity_host:
                host = str(self._remote_identity_host)
            try:
                remote_cwd = getattr(self._flash_interp, 'cwd', None)
                if isinstance(remote_cwd, str) and remote_cwd.strip():
                    cwd = remote_cwd.strip()
            except Exception:
                pass
        return (user, host, cwd, suffix)

    def build_prompt(self) -> str:
        user, host, cwd, suffix = self._prompt_parts()
        return f'{user}@{host}:{cwd}{suffix} '

    def build_prompt_formatted(self):
        user, host, cwd, suffix = self._prompt_parts()
        suffix_style = 'ansired' if suffix == '#' else 'ansiyellow'
        return [('ansibrightblack', f'{user}@'), ('ansibrightcyan', host), ('ansibrightblack', ':'), ('ansibrightgreen', cwd), (suffix_style, f'{suffix} ')]

    def init(self) -> None:
        os.environ.setdefault('PROMPT_TOOLKIT_NO_CPR', '1')
        from prompt_toolkit import PromptSession
        from prompt_toolkit.enums import EditingMode
        from prompt_toolkit.completion import Completer, Completion, PathCompleter
        from prompt_toolkit.history import InMemoryHistory, ThreadedHistory
        from prompt_toolkit.auto_suggest import AutoSuggestFromHistory
        from prompt_toolkit.shortcuts.prompt import CompleteStyle
        adapter = self

        class _CommandPathCompleter(Completer):

            def __init__(self, update_on_keypress: bool) -> None:
                self._update_on_keypress = bool(update_on_keypress)
                self._path_completer = PathCompleter(expanduser=True)
                self._repl_cmds = ('/exit', '/quit', '/bg', '/background', '/history', '/compact', '/connect', '/connect-ssh', '/disconnect-ssh')

            def _iter_exec_names(self):
                seen: set[str] = set()
                for p in os.environ.get('PATH', '').split(os.pathsep):
                    if not p:
                        continue
                    try:
                        for n in os.listdir(p):
                            if n in seen:
                                continue
                            full = os.path.join(p, n)
                            if os.path.isfile(full) and os.access(full, os.X_OK):
                                seen.add(n)
                                yield n
                    except Exception:
                        continue

            def get_completions(self, document, complete_event):
                should_complete = complete_event.completion_requested or self._update_on_keypress
                if not should_complete:
                    return
                text = document.text_before_cursor
                stripped = text.lstrip()
                first_word = stripped.split(maxsplit=1)[0] if stripped else ''
                is_first_token = ' ' not in stripped and (not stripped.endswith(' '))
                looks_like_path = first_word.startswith(('.', '/', '~'))
                if is_first_token and (not looks_like_path):
                    seen: set[str] = set()
                    for cmd in self._repl_cmds:
                        if cmd.startswith(first_word) and cmd not in seen:
                            seen.add(cmd)
                            yield Completion(cmd, start_position=-len(first_word), display_meta='repl')
                    for name in self._iter_exec_names():
                        if name.startswith(first_word) and name not in seen:
                            seen.add(name)
                            yield Completion(name, start_position=-len(first_word), display_meta='cmd')
                    return
                token = text.split()[-1] if text and (not text.endswith(' ')) else ''
                from prompt_toolkit.document import Document
                token_doc = Document(text=token, cursor_position=len(token))
                yield from self._path_completer.get_completions(token_doc, complete_event)

        class _PTKPromptShell:

            def __init__(self) -> None:
                self._session = None
                self._history = ThreadedHistory(InMemoryHistory())
                self._autosuggest = AutoSuggestFromHistory()
                self.pt_completer = self._build_completer()
                self._local_shell_lexer_cls = None
                self._bottom_toolbar_provider = None
                self._keybinding_callbacks: dict[str, Any] = {}
                self._last_esc = 0.0
                self._key_bindings = self._build_key_bindings()

            def _env_bool(self, name: str, default: bool) -> bool:
                v = os.getenv(name)
                if v is None:
                    return default
                return v.strip().lower() in {'1', 'true', 'yes', 'on'}

            def _build_completer(self):
                update_on_keypress = self._env_bool('UPDATE_COMPLETIONS_ON_KEYPRESS', False)
                return _CommandPathCompleter(update_on_keypress=update_on_keypress)

            def _build_local_shell_lexer_cls(self):
                import re
                from keyword import iskeyword
                from pygments.lexer import bygroups, include, inherit
                from pygments.lexers.python import Python3Lexer
                from pygments.token import Error, Keyword, Name, Operator, Punctuation, String, Text, Whitespace
                command_token_re = '[^=\\s\\[\\]{}()$"\\\'`<&|;!]+(?=\\s|$|\\)|\\]|\\}|!)'
                repl_cmds = {'cd', 'pushd', 'popd', 'exit', 'quit', 'source'}

                def _command_is_valid(cmd: str) -> bool:
                    if iskeyword(cmd):
                        return False
                    if cmd in repl_cmds:
                        return True
                    if '/' in cmd:
                        p = Path(cmd).expanduser()
                        try:
                            return p.is_file() and os.access(p, os.X_OK)
                        except Exception:
                            return False
                    return shutil.which(cmd) is not None

                def _subproc_cmd_callback(_, match):
                    cmd = match.group()
                    yield (match.start(), Name.Builtin if _command_is_valid(cmd) else Error, cmd)

                def _subproc_arg_callback(_, match):
                    text = match.group()
                    tok = Text
                    try:
                        path = os.path.expanduser(text)
                        if os.path.exists(path):
                            tok = Name.Constant
                    except OSError:
                        pass
                    yield (match.start(), tok, text)

                class LocalShellLexer(Python3Lexer):
                    name = 'Local shell lexer'
                    aliases = ['local-shell', 'local-sh']
                    filenames = ['*.sh', '*.bash']
                    tokens = {'mode_switch_brackets': [('(\\$)(\\{)', bygroups(Keyword, Punctuation), 'py_curly_bracket'), ('(@)(\\()', bygroups(Keyword, Punctuation), 'py_bracket'), ('([\\!\\$])(\\()', bygroups(Keyword, Punctuation), ('subproc_bracket', 'subproc_start')), ('(@\\$)(\\()', bygroups(Keyword, Punctuation), ('subproc_bracket', 'subproc_start')), ('([\\!\\$])(\\[)', bygroups(Keyword, Punctuation), ('subproc_square_bracket', 'subproc_start')), ('(g?)(`)', bygroups(String.Affix, String.Backtick), 'backtick_re')], 'subproc_bracket': [('\\)', Punctuation, '#pop'), include('subproc')], 'subproc_square_bracket': [('\\]', Punctuation, '#pop'), include('subproc')], 'py_bracket': [('\\)', Punctuation, '#pop'), include('root')], 'py_curly_bracket': [('\\}', Punctuation, '#pop'), include('root')], 'backtick_re': [('[\\.\\^\\$\\*\\+\\?\\[\\]\\|]', String.Regex), ('({[0-9]+}|{[0-9]+,[0-9]+})\\??', String.Regex), ('\\\\([0-9]+|[AbBdDsSwWZabfnrtuUvx\\\\])', String.Escape), ('`', String.Backtick, '#pop'), ('[^`\\.\\^\\$\\*\\+\\?\\[\\]\\|]+', String.Backtick)], 'root': [('\\?', Keyword), ('(?<=\\w)!', Keyword), ('\\$\\w+', Name.Variable), ('\\(', Punctuation, 'py_bracket'), ('\\{', Punctuation, 'py_curly_bracket'), include('mode_switch_brackets'), inherit], 'subproc_start': [('\\s+', Whitespace), (command_token_re, _subproc_cmd_callback, '#pop'), ('', Whitespace, '#pop')], 'subproc': [include('mode_switch_brackets'), ('&&|\\|\\||\\band\\b|\\bor\\b', Operator, 'subproc_start'), ('"(\\\\\\\\|\\\\[0-7]+|\\\\.|[^"\\\\])*"', String.Double), ("'(\\\\\\\\|\\\\[0-7]+|\\\\.|[^'\\\\])*'", String.Single), ('(?<=\\w|\\s)!', Keyword, 'subproc_macro'), ('^!', Keyword, 'subproc_macro'), (';', Punctuation, 'subproc_start'), ('&|=', Punctuation), ('\\|', Punctuation, 'subproc_start'), ('\\s+', Text), ('[^=\\s\\[\\]{}()$"\\\'`<&|;]+', _subproc_arg_callback), ('<', Text), ('\\$\\w+', Name.Variable)], 'subproc_macro': [('(\\s*)([^\\n]+)', bygroups(Whitespace, String)), ('', Whitespace, '#pop')]}

                    def get_tokens_unprocessed(self, text, **_):
                        start = 0
                        state = ('root',)
                        m = re.match(f'(\\s*)({command_token_re})', text)
                        if m is not None:
                            yield (m.start(1), Whitespace, m.group(1))
                            start = m.end(1)
                            cmd = m.group(2)
                            cmd_is_valid = _command_is_valid(cmd)
                            if cmd_is_valid:
                                yield (m.start(2), Name.Builtin, cmd)
                                start = m.end(2)
                                state = ('subproc',)
                        for i, t, v in super().get_tokens_unprocessed(text[start:], state):
                            yield (i + start, t, v)
                return LocalShellLexer

            def _build_lexer(self):
                if not self._env_bool('COLOR_INPUT', True):
                    return None
                try:
                    from prompt_toolkit.lexers import PygmentsLexer
                    if self._local_shell_lexer_cls is None:
                        self._local_shell_lexer_cls = self._build_local_shell_lexer_cls()
                    return PygmentsLexer(self._local_shell_lexer_cls)
                except Exception:
                    pass
                try:
                    from prompt_toolkit.lexers import PygmentsLexer
                    from pygments.lexers.shell import BashLexer
                    return PygmentsLexer(BashLexer)
                except Exception:
                    return None

            def _build_prompt_style(self):
                if not self._env_bool('COLOR_INPUT', True):
                    return None
                try:
                    from prompt_toolkit.styles.pygments import style_from_pygments_cls
                    from pygments.styles import get_style_by_name
                    style_name = os.getenv('SHELL_COLOR_STYLE', os.getenv('XONSH_COLOR_STYLE', 'friendly'))
                    try:
                        style_cls = get_style_by_name(style_name)
                    except Exception:
                        style_cls = get_style_by_name('friendly')
                    return style_from_pygments_cls(style_cls)
                except Exception:
                    return None

            def _bottom_toolbar(self) -> str:
                provider = self._bottom_toolbar_provider
                if callable(provider):
                    try:
                        return str(provider())
                    except Exception:
                        pass
                return 'PTK+subprocess mode'

            def set_bottom_toolbar_provider(self, provider) -> None:
                self._bottom_toolbar_provider = provider

            def set_keybinding_callbacks(self, callbacks: dict[str, Any]) -> None:
                self._keybinding_callbacks = dict(callbacks or {})

            def _cb(self, name: str):
                cb = self._keybinding_callbacks.get(name)
                return cb if callable(cb) else None

            def _build_key_bindings(self):
                from prompt_toolkit.key_binding import KeyBindings
                bindings = KeyBindings()

                @bindings.add('f2')
                def _toggle_mode(event) -> None:
                    cb = self._cb('toggle_mode')
                    if cb:
                        cb()
                    try:
                        event.app.invalidate()
                    except Exception:
                        pass

                @bindings.add('f1')
                def _history(event) -> None:
                    cb = self._cb('open_history')
                    if cb:
                        cb()

                @bindings.add('f6')
                def _bg(event) -> None:
                    cb = self._cb('open_background')
                    if cb:
                        cb()

                @bindings.add('f4')
                def _mcp(event) -> None:
                    cb = self._cb('open_mcp')
                    if cb:
                        cb()

                @bindings.add('f3')
                def _chat_only(event) -> None:
                    text = ''
                    try:
                        buf = event.app.current_buffer
                        text = buf.text if hasattr(buf, 'text') else ''
                    except Exception:
                        text = ''
                    cb = self._cb('chat_only')
                    if cb:
                        cb(text)
                    event.app.exit(exception=KeyboardInterrupt('Chat only mode activated'))

                @bindings.add('c-q')
                def _exit_cq(event) -> None:
                    cb = self._cb('exit')
                    if cb:
                        cb()
                    event.app.exit(result='')

                @bindings.add('f10')
                def _exit_f10(event) -> None:
                    cb = self._cb('exit')
                    if cb:
                        cb()
                    event.app.exit(result='')

                @bindings.add('escape')
                def _esc(event) -> None:
                    now = time.monotonic()
                    if now - self._last_esc < 0.6:
                        cb = self._cb('cancel_tool')
                        if cb:
                            cb()
                        self._last_esc = 0.0
                        try:
                            event.app.invalidate()
                        except Exception:
                            pass
                    else:
                        self._last_esc = now

                @bindings.add('escape', 'escape')
                def _esc_esc(event) -> None:
                    cb = self._cb('cancel_tool')
                    if cb:
                        cb()
                    try:
                        event.app.invalidate()
                    except Exception:
                        pass
                return bindings

            def _get_session(self):
                if self._session is None:
                    self.pt_completer = self._build_completer()
                    self._session = PromptSession(history=self._history, completer=self.pt_completer, key_bindings=self._key_bindings)
                    self.pt_completer = getattr(self._session, 'completer', None)
                return self._session

            def singleline(self) -> str:
                session = self._get_session()
                completions_display = os.getenv('COMPLETIONS_DISPLAY', 'multi').strip().lower()
                completion_style = {'multi': CompleteStyle.MULTI_COLUMN, 'single': CompleteStyle.COLUMN, 'readline': CompleteStyle.READLINE_LIKE, 'none': None}.get(completions_display, CompleteStyle.MULTI_COLUMN)
                complete_while_typing = self._env_bool('UPDATE_COMPLETIONS_ON_KEYPRESS', False)
                lexer = self._build_lexer()
                style = self._build_prompt_style()
                prompt_args = {'bottom_toolbar': self._bottom_toolbar, 'auto_suggest': self._autosuggest if self._env_bool('AUTO_SUGGEST', True) else None, 'completer': None if completions_display == 'none' else self.pt_completer, 'complete_style': completion_style, 'complete_while_typing': complete_while_typing, 'enable_history_search': not complete_while_typing, 'editing_mode': EditingMode.VI if self._env_bool('VI_MODE', False) else EditingMode.EMACS, 'mouse_support': self._env_bool('MOUSE_SUPPORT', False), 'complete_in_thread': self._env_bool('COMPLETION_IN_THREAD', True)}
                if lexer is not None:
                    prompt_args['lexer'] = lexer
                    prompt_args['include_default_pygments_style'] = True
                if style is not None:
                    prompt_args['style'] = style
                return session.prompt(adapter.build_prompt_formatted(), **prompt_args)
        self.shell = _PTKPromptShell()

    def command_available(self, name: str) -> bool:
        if not name:
            return False
        if name in _SHELL_BUILTINS:
            return True
        if self._remote_executor_path and self._remote_ssh_host:
            if '/' in name:
                return True
            if name in self._remote_initial_commands:
                return True
            return self._remote_command_exists(name)
        if '/' in name:
            p = Path(name).expanduser()
            try:
                return p.is_file() and os.access(p, os.X_OK)
            except Exception:
                return False
        return shutil.which(name) is not None

    def auto_should_run_shell(self, line: str) -> Tuple[bool, Optional[str]]:
        segments, parse_reasons = parse_shell_command(line)
        if parse_reasons:
            return (False, str(parse_reasons[0]))
        if not segments:
            return (False, '无法识别命令：需人工确认')
        for seg in segments:
            program = str(getattr(seg, 'program', '') or '')
            if program and (not self.command_available(program)):
                return (False, f'命令未找到：{program}')
        return (True, None)

    def run_and_capture(self, cmd: str, *, fold: bool=True, each: int=2048, proxy_stdin: bool=True) -> Tuple[int, str, str]:
        t0 = time.monotonic()
        self._emit_executor_debug(f'run start backend=local cmd={cmd!r}')

        def fix_surrogate(s: str) -> str:
            return s.encode('utf-8', errors='backslashreplace').decode('utf-8')

        def trim(t: str) -> str:
            if not fold:
                return t
            b = t.encode('utf-8', errors='ignore')
            if len(b) <= each * 2:
                return t
            head = b[:each].decode('utf-8', errors='ignore')
            tail = b[-each:].decode('utf-8', errors='ignore')
            return head + '\n...<snip>...\n' + tail

        def _emit_text(text: str) -> None:
            if not text:
                return
            sink = self._output_sink
            if callable(sink):
                try:
                    sink('pty', text, True, False)
                except TypeError:
                    try:
                        sink('pty', text, True)
                    except Exception:
                        pass
                except Exception:
                    pass
            else:
                try:
                    sys.stdout.write(text)
                    sys.stdout.flush()
                except Exception:
                    pass
        try:
            import nimbie_flash as flash
            if self._flash_interp is None:
                self._flash_interp = flash.FlashInterpreter()
            custom_env_builder = getattr(self, '_build_remote_ssh_command', None)
            custom_env = custom_env_builder() if callable(custom_env_builder) else None
            interp = self._flash_interp
            executor = self._ensure_flash_executor(flash, remote=(custom_env is not None))
            old_bin = os.environ.get('FLASH_STDIO_EXECUTOR_BIN')
            old_args = os.environ.get('FLASH_STDIO_EXECUTOR_ARGS_JSON')
            if custom_env is not None:
                bin_name, args = custom_env
                os.environ['FLASH_STDIO_EXECUTOR_BIN'] = bin_name
                os.environ['FLASH_STDIO_EXECUTOR_ARGS_JSON'] = json.dumps(args)
            else:
                os.environ.pop('FLASH_STDIO_EXECUTOR_BIN', None)
                os.environ.pop('FLASH_STDIO_EXECUTOR_ARGS_JSON', None)
            stdin_fd: Optional[int] = None
            if proxy_stdin:
                try:
                    stdin_fd = sys.stdin.fileno()
                except Exception:
                    stdin_fd = None
            stdin_termios_orig: Any = None
            if stdin_fd is not None and _termios is not None:
                try:
                    if os.isatty(stdin_fd):
                        stdin_termios_orig = _termios.tcgetattr(stdin_fd)
                        attrs = _termios.tcgetattr(stdin_fd)
                        attrs[3] = attrs[3] & ~getattr(_termios, 'ECHO', 0)
                        _termios.tcsetattr(stdin_fd, _termios.TCSADRAIN, attrs)
                except Exception:
                    stdin_termios_orig = None
            input_stop = threading.Event()
            input_lock = threading.Lock()
            pending_input: list[str] = []
            active_run_id: Optional[str] = None

            def _send_pending_input() -> None:
                nonlocal pending_input
                if not active_run_id or not pending_input:
                    return
                try:
                    payload = ''.join(pending_input)
                    pending_input = []
                    sender = getattr(executor, 'send_stdin', None)
                    if callable(sender):
                        sender(active_run_id, payload)
                except Exception:
                    pass

            def _stdin_proxy_loop() -> None:
                if stdin_fd is None:
                    return
                while not input_stop.is_set():
                    try:
                        r, _, _ = select.select([stdin_fd], [], [], 0.05)
                    except Exception:
                        break
                    if not r:
                        continue
                    try:
                        chunk = os.read(stdin_fd, 1024)
                    except Exception:
                        break
                    if not chunk:
                        break
                    text = chunk.decode('utf-8', errors='ignore')
                    if not text:
                        continue
                    with input_lock:
                        pending_input.append(text)
                        _send_pending_input()
            input_thread: Optional[threading.Thread] = None
            if stdin_fd is not None:
                input_thread = threading.Thread(target=_stdin_proxy_loop, daemon=True)
                input_thread.start()

            def _cleanup_input_thread() -> None:
                input_stop.set()
                if input_thread is not None:
                    try:
                        input_thread.join(timeout=0.2)
                    except Exception:
                        pass
                if stdin_termios_orig is not None and stdin_fd is not None and (_termios is not None):
                    try:
                        _termios.tcsetattr(stdin_fd, _termios.TCSADRAIN, stdin_termios_orig)
                    except Exception:
                        pass

            def _on_event(ev: Any) -> None:
                nonlocal active_run_id
                data = ''
                ev_type = 'raw'
                try:
                    if isinstance(ev, dict):
                        t = str(ev.get('type') or '')
                        ev_type = t or 'raw'
                        rid = ev.get('run_id')
                        if rid is not None:
                            active_run_id = str(rid)
                            with input_lock:
                                _send_pending_input()
                        if t in {'stdout', 'stderr', 'raw'}:
                            data = str(ev.get('data') or ev.get('stdout') or ev.get('stderr') or '')
                        else:
                            data = str(ev.get('stdout') or ev.get('stderr') or ev.get('data') or '')
                    else:
                        data = str(ev or '')
                except Exception:
                    data = ''
                if self._executor_debug_verbose():
                    self._emit_executor_debug(f"stream event type={ev_type} bytes={len(data.encode('utf-8', errors='ignore'))}")
                if data:
                    _emit_text(fix_surrogate(data))
            try:
                result = interp.run_shell_stream(cmd, executor, _on_event)
            finally:
                _cleanup_input_thread()
                if old_bin is not None:
                    os.environ['FLASH_STDIO_EXECUTOR_BIN'] = old_bin
                else:
                    os.environ.pop('FLASH_STDIO_EXECUTOR_BIN', None)
                if old_args is not None:
                    os.environ['FLASH_STDIO_EXECUTOR_ARGS_JSON'] = old_args
                else:
                    os.environ.pop('FLASH_STDIO_EXECUTOR_ARGS_JSON', None)
            stdout = trim(fix_surrogate(getattr(result, 'stdout', '')))
            stderr = trim(fix_surrogate(getattr(result, 'stderr', '')))
            rc = int(getattr(result, 'exit_code', 1))
            self._emit_executor_debug(f"run done rc={rc} out_bytes={len(stdout.encode('utf-8', errors='ignore'))} err_bytes={len(stderr.encode('utf-8', errors='ignore'))} elapsed_ms={(time.monotonic() - t0) * 1000:.1f}")
            return (rc, stdout, stderr)
        except KeyboardInterrupt:
            self._emit_executor_debug(f'run interrupted elapsed_ms={(time.monotonic() - t0) * 1000:.1f}')
            return (130, '', 'Interrupted')
        except Exception as e:
            self._emit_executor_debug(f'run error err={e} elapsed_ms={(time.monotonic() - t0) * 1000:.1f}')
            return (1, '', str(e))

class ReplApp:

    def __init__(self, work_dir: Path, opts: ReplOptions) -> None:
        self.work_dir = work_dir.absolute()
        self.opts = opts
        self.console = Console(highlight=False, force_terminal=True, soft_wrap=False)
        self.renderer = Renderer(self.console, RendererConfig(refresh_per_second=16, code_theme='auto'))
        self.shell = ShellAdapter(opts)
        self.esc_cancel = EscCancelController()
        self.MODE = 'auto'
        self.USAGE_TOTAL: Optional[int] = None
        self.EXIT = False
        self.ctx: Any = None
        self.session: Any = None
        self.agent: Any = None
        self.out_q: asyncio.Queue = asyncio.Queue()
        self._agent_task: Optional[asyncio.Task] = None
        self._chat_only_pending = False
        self._chat_only_text = ''
        self._chat_only_was_used = False
        self._session_initialized: bool = False
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._pending_inputs = deque()

    def _build_agent_tools(self) -> list[type]:
        tool_classes: list[type] = []
        try:
            for tool_name in nimbie_tool_registry.list_tools():
                tool_cls = nimbie_tool_registry.get_tool_class(tool_name)
                if tool_cls is not None:
                    tool_classes.append(tool_cls)
        except Exception:
            pass
        return tool_classes

    def _build_oturn_config(self) -> OturnConfig:
        provider = getattr(self.opts, 'provider', None)
        model_cfg = getattr(self.opts, 'model_config', None)
        agent_cfg = getattr(self.opts, 'agent_config', None)
        return OturnConfig(model=str(getattr(self.opts, 'model', '') or ''), provider=OturnProviderConfig(api_base=str(getattr(provider, 'api_base', '') or ''), api_key=getattr(provider, 'api_key', None), debug_request=bool(getattr(provider, 'debug_request', False)), debug_sse=bool(getattr(provider, 'debug_sse', False)), debug_tools=bool(getattr(provider, 'debug_tools', False))), model_config=OturnModelConfig(max_output_tokens=getattr(model_cfg, 'max_output_tokens', None), temperature=getattr(model_cfg, 'temperature', None), extra_body=getattr(model_cfg, 'extra_body', None)), agent_config=OturnAgentConfig(max_steps=int(getattr(agent_cfg, 'max_steps', 100) or 100), user_name=str(getattr(agent_cfg, 'user_name', 'User') or 'User'), email=getattr(agent_cfg, 'email', None)), debug_loop=bool(getattr(self.opts, 'debug_loop', False)))

    async def run(self) -> None:
        self._loop = asyncio.get_running_loop()
        self._install_sigttou_handler()
        self._load_or_create_session()
        self._print_last_assistant_if_resumed()
        self.shell.init()
        if getattr(self.opts, 'connect', None):
            try:
                target = str(self.opts.connect)
                self.renderer.print_info(f'[ssh] connecting to {target} ...')
                msg = await self.shell.connect(target)
                self.renderer.print_info(f'[ssh] {msg}')
            except Exception as e:
                self.renderer.print_error(f'[ssh] auto connect failed: {e}')
        self._install_ptk_keybindings()
        if self._session_initialized:
            self.agent = Oturn(self.session.work_dir, self._build_oturn_config(), tools=self._build_agent_tools())
            self.agent.subscribe(self.out_q)
            self._agent_task = asyncio.create_task(self.agent.run_queues(self.ctx))
            asyncio.create_task(self._handle_user_input({'future': None}))
        else:
            asyncio.create_task(self._handle_user_input({'future': None}))
        try:
            await self._event_loop()
        finally:
            self.renderer.close()
            self.esc_cancel.stop()
            if self._agent_task is not None:
                try:
                    self._agent_task.cancel()
                except Exception:
                    pass
            if self.agent is not None:
                try:
                    await self.agent.aclose()
                except Exception:
                    pass
            try:
                self.shell.close()
            except Exception:
                pass

    def _install_sigttou_handler(self) -> None:

        def on_sigttou(signum, frame) -> None:
            return
        try:
            signal.signal(signal.SIGTTOU, on_sigttou)
        except Exception:
            pass

    def _load_or_create_session(self) -> None:
        wd = self.work_dir
        opts = self.opts
        self._session_initialized = False
        self._resumed = False

        def _safe_resume(session_id: str) -> Any:
            try:
                return Context.resume_session(
                    wd,
                    session_id,
                    meta_dirname=_SESSION_META_DIR,
                    global_sessions_root=_SESSION_GLOBAL_ROOT,
                )
            except Exception as e:
                self.renderer.print_warning(f'[session] failed to resume {session_id}: {e}')
                return None

        def _safe_continue() -> Any:
            try:
                return Context.continue_session(
                    wd,
                    meta_dirname=_SESSION_META_DIR,
                    global_sessions_root=_SESSION_GLOBAL_ROOT,
                )
            except Exception as e:
                self.renderer.print_warning(f'[session] failed to continue last session: {e}')
                return None

        def _safe_restore(session_obj: Any) -> bool:
            try:
                return bool(session_obj.restore())
            except Exception as e:
                history_file = getattr(session_obj, 'history_file', None)
                if history_file is not None:
                    self.renderer.print_warning(f'[session] history restore failed: {history_file} ({e})')
                else:
                    self.renderer.print_warning(f'[session] history restore failed: {e}')
                return False

        if opts.fork_session_id is not None:
            if not opts.resume_id:
                raise click.ClickException('--fork requires --resume-id to specify source session')
            source_session = _safe_resume(opts.resume_id)
            if source_session is None:
                raise click.ClickException(f'source session not found: {opts.resume_id}')
            if not _safe_restore(source_session):
                raise click.ClickException(f'source session is corrupted and cannot be restored: {opts.resume_id}')
            self.ctx = source_session
            return
        session = None
        if opts.resume_id:
            session = _safe_resume(opts.resume_id)
            if session is None:
                session = Context.create_session(wd, meta_dirname=_SESSION_META_DIR, global_sessions_root=_SESSION_GLOBAL_ROOT)
        elif not opts.new_session:
            session = _safe_continue()
        if session is not None:
            self.session = session
            self.ctx = session
            if not _safe_restore(self.ctx):
                self.session = None
                self.ctx = None
                return
            self._session_initialized = True
            self._resumed = True
            return

    def _ensure_session_initialized(self) -> None:
        """延迟初始化session，在用户发送第一条消息时调用"""
        if self._session_initialized:
            return
        wd = self.work_dir
        opts = self.opts
        if opts.fork_session_id is not None:
            session = Context.fork_session(wd, opts.resume_id, opts.fork_session_id, meta_dirname=_SESSION_META_DIR, global_sessions_root=_SESSION_GLOBAL_ROOT)
            self.console.print(f'[info] Forked from session {opts.resume_id} -> {session.session_id}')
            self.session = session
            self.ctx = session
        else:
            session = Context.create_session(wd, meta_dirname=_SESSION_META_DIR, global_sessions_root=_SESSION_GLOBAL_ROOT)
            self.session = session
            self.ctx = session
        self._session_initialized = True
        self._ensure_system_prompt()
        self.agent = Oturn(self.session.work_dir, self._build_oturn_config(), tools=self._build_agent_tools())
        self.agent.subscribe(self.out_q)
        self._agent_task = asyncio.create_task(self.agent.run_queues(self.ctx))

    def _ensure_system_prompt(self) -> None:
        if self.ctx is None:
            return
        try:
            if not any((getattr(m, 'role', '') == 'system' for m in self.ctx.history)):
                self.ctx.append_message(Message(role='system', content=get_system_prompt(self.work_dir)))
        except Exception:
            pass

    def _print_last_assistant_if_resumed(self) -> None:
        if not getattr(self, '_resumed', False):
            return
        try:
            for m in reversed(list(self.ctx.history)):
                if getattr(m, 'role', '') == 'assistant' and (getattr(m, 'content', '') or '').strip():
                    self.console.print(Markdown(m.content))
                    break
        except Exception:
            pass

    def _install_ptk_keybindings(self) -> None:

        def status_line() -> str:
            if self.MODE == 'agent':
                mode_text = 'Agent'
                mode_desc = '直接与AI对话'
            elif self.MODE == 'shell':
                mode_text = 'Shell'
                mode_desc = '执行系统命令'
            else:
                mode_text = 'Auto'
                mode_desc = '智能判断命令类型'
            usage = '-'
            if isinstance(self.USAGE_TOTAL, (int, float)):
                usage = f'{self.USAGE_TOTAL / 1000:.1f}K'
            renderer_status = {RenderState.OFF: '⌨️', RenderState.LIVE_TRANSIENT: '⏳', RenderState.LIVE_NON_TRANSIENT: '📌', RenderState.MARKDOWN_STREAMING: '📺'}.get(self.renderer.state, '❓')
            session_info = self.session.session_id[:8] if hasattr(self, 'session') and self.session else '-'
            try:
                return f'模式:{mode_text} ({mode_desc})' + f' | 渲染:{renderer_status}' + f' | 会话:{session_info}' + f' | 使用量:{usage}' + ' | 快捷键:F2/F3/F1/F6/Ctrl-Q'
            except Exception:
                return '状态栏渲染失败'
        shell = getattr(self.shell, 'shell', None)
        if shell is None:
            return
        if not hasattr(shell, 'set_bottom_toolbar_provider'):
            return
        if not hasattr(shell, 'set_keybinding_callbacks'):
            return

        def _on_chat_only(text: str) -> None:
            self._chat_only_pending = True
            self._chat_only_text = text or ''
            self.console.print('[green]已切换到 Chat Only 模式[/green]')

        def _on_exit() -> None:
            self.EXIT = True
            self._request_shutdown_event()

        def _on_cancel_tool() -> None:
            try:
                if self.agent is not None:
                    self.agent.request_cancel_tool()
            except Exception:
                pass
        shell.set_bottom_toolbar_provider(status_line)
        shell.set_keybinding_callbacks({'toggle_mode': self._toggle_mode, 'open_history': self._schedule_history_ui, 'open_background': self._schedule_background_manager, 'chat_only': _on_chat_only, 'exit': _on_exit, 'cancel_tool': _on_cancel_tool})

    def _toggle_mode(self) -> None:
        if self.MODE == 'auto':
            self.MODE = 'agent'
        elif self.MODE == 'agent':
            self.MODE = 'shell'
        else:
            self.MODE = 'auto'

    async def _event_loop(self) -> None:
        while True:
            ev = await self.out_q.get()
            t = ev.get('type') if isinstance(ev, dict) else None
            if t == 'request_user_input':
                fut = ev.get('future') if isinstance(ev, dict) else None
                if fut is not None and self._pending_inputs:
                    payload = self._pending_inputs.popleft()
                    self._set_future(fut, {'status': payload['status'], 'text': payload['text'], 'type': payload['type']})
                    continue
                await self._handle_user_input(ev)
                if self.EXIT:
                    return
                continue
            if t == 'shutdown':
                return
            if t == 'message_sent':
                spinner = self._build_spinner_grid('Requesting...')
                self.renderer.show_spinner(spinner)
                self.esc_cancel.start(self.agent)
                continue
            if t == 'usage_total':
                try:
                    usage_dict = ev.get('usage')
                    if isinstance(usage_dict, dict):
                        total_tokens = usage_dict.get('total_tokens')
                        if isinstance(total_tokens, int):
                            self.USAGE_TOTAL = total_tokens
                except Exception:
                    pass
                continue
            if t == 'assistant_reasoning_delta':
                self.renderer.stream_delta('reasoning', str(ev.get('text', '') or ''))
                continue
            if t == 'assistant_delta':
                self.renderer.stream_delta('content', str(ev.get('text', '') or ''))
                continue
            if t == 'tool_call_preview':
                self.renderer.end_streaming_turn()
                name = str(ev.get('tool') or '')
                arg_str = str(ev.get('args') or '')
                header = f'### Tool Preview: {name}\n'
                preview_text = ev.get('preview')
                if not preview_text:
                    try:
                        from ...tools import registry
                        tool_class = registry.get_tool_class(name)
                        if tool_class:
                            import json
                            try:
                                parsed_args = json.loads(arg_str) if arg_str else {}
                                preview_text = tool_class.get_preview(parsed_args)
                            except (json.JSONDecodeError, TypeError):
                                preview_text = f'```\n{arg_str}\n```\n' if arg_str else None
                    except Exception:
                        preview_text = f'```\n{arg_str}\n```\n' if arg_str else None
                if preview_text:
                    self.renderer.show_tool_preview(preview_text, header=header)
                continue
            if t == 'tool_call':
                self.renderer.enter_prompt()
                self.esc_cancel.stop()
                self._set_future(ev.get('future'), {'status': 'preview_done'})
                continue
            if t == 'approval_request':
                await self._handle_approval_request(ev)
                continue
            if t == 'choice_request':
                await self._handle_choice_request(ev)
                continue
            if t == 'run_aborted':
                self.renderer.end_streaming_turn()
                self.esc_cancel.stop()
                if not self.EXIT:
                    self._schedule_lazy_prompt()
                continue
            if t == 'assistant_final':
                self.renderer.end_streaming_turn()
                self.esc_cancel.stop()
                if not self.EXIT:
                    self._schedule_lazy_prompt()
                continue
            if t == 'warning':
                self.renderer.end_streaming_turn()
                self.renderer.print_warning(f"警告: {ev.get('warning', '未知警告')}")
                continue
            if t == 'error':
                self.renderer.end_streaming_turn()
                self.renderer.print_error(f"错误: {ev.get('error', '未知错误')}")
                et = ev.get('exception_type', '')
                if et:
                    self.renderer.print_info(f'异常类型: {et}')
                tb = ev.get('traceback', '')
                if tb:
                    self.renderer.print_info(f'Traceback:\n{tb}')
                self.esc_cancel.stop()
                continue
            if t == 'tool_exit':
                self.esc_cancel.stop()
                continue
            if t == 'tool_output':
                try:
                    text = str(ev.get('text', '') or '')
                    stream = str(ev.get('stream', '') or '')
                    if text:
                        if stream == 'stderr':
                            self.renderer.print_warning(text.rstrip('\n'))
                        else:
                            self.renderer.print_info(text.rstrip('\n'))
                except Exception:
                    pass
                continue
            if t == 'tool_call_debug':
                try:
                    import json
                    self.renderer.print_info('[tool] debug: ' + json.dumps(ev, ensure_ascii=False))
                except Exception:
                    pass
                continue

    async def _handle_user_input(self, ev: dict) -> None:
        fut = ev.get('future')
        self.renderer.enter_prompt()
        self.esc_cancel.stop()
        line: Optional[str] = None
        try:
            line = await asyncio.to_thread(self.shell.shell.singleline)
        except KeyboardInterrupt:
            if self._chat_only_pending:
                line = self._chat_only_text
                self._chat_only_pending = False
                self._chat_only_text = ''
                self._chat_only_was_used = True
            else:
                self._resolve_input(fut, status='agent', text='', input_type='default')
                return
        if self.EXIT:
            self._resolve_input(fut, status='agent', text='', input_type='default')
            try:
                sys.stdout.write('Bye\n')
                sys.stdout.flush()
            except Exception:
                pass
            self._request_shutdown_event()
            return
        if line is None:
            self._resolve_input(fut, status='agent', text='', input_type='default')
            return
        s = line.strip()
        input_type = 'chat_only' if self._chat_only_was_used else 'default'
        self._chat_only_was_used = False
        lazy_input = fut is None
        if not lazy_input:
            self._ensure_session_initialized()
        if not s:
            if not lazy_input:
                self._resolve_input(fut, status='agent', text='', input_type=input_type)
            else:
                self._schedule_lazy_prompt()
            return
        if s in ('exit', 'quit', '/exit', '/quit'):
            if not lazy_input:
                self._resolve_input(fut, status='agent', text='', input_type=input_type)
            try:
                sys.stdout.write('Bye\n')
                sys.stdout.flush()
            except Exception:
                pass
            self.EXIT = True
            self._request_shutdown_event()
            return
        self._append_input_history(s)
        if s.startswith('/bg') or s.startswith('/background'):
            if lazy_input:
                self._ensure_session_initialized()
            await self._run_background_manager_ui()
            if not lazy_input:
                self._resolve_input(fut, status='agent', text='', input_type=input_type)
            else:
                self._schedule_lazy_prompt()
            return
        if s.startswith('/history'):
            if lazy_input:
                self._ensure_session_initialized()
            await self._run_history_ui()
            if not lazy_input:
                self._resolve_input(fut, status='agent', text='', input_type=input_type)
            else:
                self._schedule_lazy_prompt()
            return
        if s.startswith('/compact'):
            if lazy_input:
                self._ensure_session_initialized()
            await self._run_compact(s)
            if not lazy_input:
                self._resolve_input(fut, status='agent', text='', input_type=input_type)
            else:
                self._schedule_lazy_prompt()
            return
        if s.startswith('/connect ') or s.startswith('/connect\t'):
            args = shlex.split(s)
            force_upload = False
            rest = args[1:] if len(args) > 1 else []
            if '--force' in rest:
                force_upload = True
                rest = [a for a in rest if a != '--force']
            provider = ''
            target = ''
            if len(rest) == 1 and ':' in rest[0]:
                provider, target = rest[0].split(':', 1)
            elif len(rest) >= 2:
                provider = rest[0]
                target = rest[1]
            provider = provider.strip()
            target = target.strip()
            if not provider or not target:
                self.renderer.print_warning('usage: /connect [--force] <provider> <target> | <provider>:<target>')
                if lazy_input:
                    self._schedule_lazy_prompt()
                else:
                    self._resolve_input(fut, status='agent', text='', input_type=input_type)
                return
            try:
                msg = await self.shell.connect_with_provider(provider, target, force_upload=force_upload)
                self.renderer.print_info(f'[{provider}] {msg}')
            except Exception as e:
                self.renderer.print_error(f'[{provider}] connect failed: {e}')
            if lazy_input:
                self._schedule_lazy_prompt()
            else:
                self._resolve_input(fut, status='agent', text='', input_type=input_type)
            return
        if s.startswith('/connect-ssh') or s.startswith('/ssh'):
            args = shlex.split(s)
            force_upload = False
            rest = args[1:] if len(args) > 1 else []
            if '--force' in rest:
                force_upload = True
                rest = [a for a in rest if a != '--force']
            if not rest:
                self.renderer.print_warning('usage: /connect-ssh [--force] [user@]host[:port]')
                if lazy_input:
                    self._schedule_lazy_prompt()
                else:
                    self._resolve_input(fut, status='agent', text='', input_type=input_type)
                return
            target = rest[0]
            try:
                msg = await self.shell.connect_ssh(target, force_upload=force_upload)
                self.renderer.print_info(f'[ssh] {msg}')
            except Exception as e:
                self.renderer.print_error(f'[ssh] connect failed: {e}')
            if lazy_input:
                self._schedule_lazy_prompt()
            else:
                self._resolve_input(fut, status='agent', text='', input_type=input_type)
            return
        if s.startswith('/disconnect-ssh'):
            self.shell.disconnect_ssh()
            self.renderer.print_info('[ssh] disconnected, switched to local executor')
            if lazy_input:
                self._schedule_lazy_prompt()
            else:
                self._resolve_input(fut, status='agent', text='', input_type=input_type)
            return
        if self.MODE == 'shell':
            if lazy_input:
                self._ensure_session_initialized()
            shell_result = self._run_shell_and_build_summary(s)
            try:
                self.ctx.append_message(Message(role='user', content=shell_result))
            except Exception:
                pass
            if not lazy_input:
                self._resolve_input(fut, status='shell', text=s, input_type=input_type)
            else:
                self._schedule_lazy_prompt()
            return
        if self.MODE == 'auto':
            should_run, reason = self.shell.auto_should_run_shell(s)
            if should_run:
                if lazy_input:
                    self._ensure_session_initialized()
                shell_result = self._run_shell_and_build_summary(s)
                try:
                    self.ctx.append_message(Message(role='user', content=shell_result))
                except Exception:
                    pass
                if not lazy_input:
                    self._resolve_input(fut, status='auto', text=s, input_type=input_type)
                else:
                    self._schedule_lazy_prompt()
                return
            if reason:
                self.renderer.print_warning(f'Auto 模式 defer to agent：{reason}，agent 来帮忙~')
        if lazy_input:
            self._ensure_session_initialized()
            enqueued = False
            try:
                if self.agent is not None and hasattr(self.agent, 'enqueue_user_input_nowait'):
                    enqueued = bool(self.agent.enqueue_user_input_nowait(s, status='agent', input_type=input_type))
            except Exception:
                enqueued = False
            if not enqueued:
                self._pending_inputs.append({'status': 'agent', 'text': s, 'type': input_type})
            return
        self._resolve_input(fut, status='agent', text=s, input_type=input_type)

    def _run_shell_and_build_summary(self, cmd: str) -> ShellResult:
        fold = True
        try:
            if hasattr(self.opts.ui_config, 'fold_bash_output') and (not self.opts.ui_config.fold_bash_output):
                fold = False
        except Exception:
            pass
        rc, stdout, stderr = self.shell.run_and_capture(cmd, fold=fold)
        shell_result = ShellResult(command=cmd, cwd=os.getcwd(), stdout=stdout, stderr=stderr, retcode=rc, date=_dt.datetime.now().astimezone())
        return shell_result

    async def _handle_approval_request(self, ev: dict) -> None:
        name = str(ev.get('tool') or '')
        args = ev.get('args') or {}
        fut = ev.get('future')
        precheck = ev.get('precheck') or {}
        message = str(precheck.get('message') or '')
        raw_reasons = precheck.get('reasons') or []
        reasons: List[str] = [str(r) for r in raw_reasons if isinstance(r, (str, int, float))]
        self.renderer.enter_prompt()
        self.esc_cancel.stop()
        if name == 'execute_shell_command' and isinstance(args, dict):
            command = str(args.get('command') or '').strip()
            if command:
                self.renderer.print_info('Command to approve:\n' + command)
        if message:
            self.renderer.print_warning(message)
        if reasons:
            self.renderer.print_info('Reasons:\n' + '\n'.join([f'  - {r}' for r in reasons]))
        prompt = f"[approval] {name or 'tool'} | Allow? [y/N]: "
        approved = await asyncio.to_thread(self._prompt_yes_no, prompt)
        decision = 'ALLOW'
        if not approved:
            decision = 'DENIED'
            self.renderer.print_warning('[tool] denied')
            try:
                if self.agent is not None:
                    self.agent.request_cancel_tool()
            except Exception:
                pass
        payload = {'approved': bool(approved), 'decision': decision, 'reasons': reasons}
        self._set_future(fut, payload)
        if approved:
            self.esc_cancel.start(self.agent)
            spinner = self._build_spinner_grid('Continuing...')
            self.renderer.show_spinner(spinner)
        else:
            self.renderer.enter_prompt()

    async def _handle_choice_request(self, ev: dict) -> None:
        prompt = str(ev.get('prompt') or '请选择一个选项')
        choices = ev.get('choices') or []
        fut = ev.get('future')
        self.renderer.enter_prompt()
        self.esc_cancel.stop()
        selected, confirmed = await asyncio.to_thread(self._prompt_choice, prompt, list(map(str, choices)))
        if confirmed and selected is not None:
            self.renderer.print_info(f'[choice] 你选择了: {selected}')
        else:
            self.renderer.print_warning('[choice] 选择被取消')
        payload = {'selected': selected, 'confirmed': confirmed}
        self._set_future(fut, payload)
        if confirmed:
            self.esc_cancel.start(self.agent)
        else:
            self.renderer.enter_prompt()

    async def _run_history_ui(self) -> None:
        os.environ.setdefault('TEXTUAL_DISABLE_MOUSE', '1')

        def _fork_from_debug(msg_idx: int) -> str | None:
            try:
                old_id = self.ctx.session_id
                new_session = Context.create_session(self.work_dir)
                forked = self.ctx.truncate_and_fork(msg_idx, new_session.history_file)
                self.ctx.adopt(forked)
                self.session = self.ctx
                result = f'Forked from {old_id} to {self.ctx.session_id}'
                self.renderer.print_info(f'[info] {result}')
                return result
            except Exception as err:
                self.renderer.print_error(f'Fork failed: {err}')
                return f'Fork failed: {err}'
        app = SessionHistoryInspectorApp(list(self.ctx.history), path=str(self.session.history_file), fork_callback=_fork_from_debug)
        try:
            fork_result = await app.run_async()
            if fork_result:
                self.renderer.print_info(f'[info]{fork_result}[/info]')
        except Exception:
            pass

    async def _run_background_manager_ui(self) -> None:
        os.environ.setdefault('TEXTUAL_DISABLE_MOUSE', '1')
        app = ProcessOverviewApp(get_background_registry_snapshot)
        try:
            await app.run_async()
        except Exception:
            pass

    def _schedule_history_ui(self) -> None:
        loop = self._loop
        if loop is None or loop.is_closed():
            return
        try:
            asyncio.run_coroutine_threadsafe(self._run_history_ui(), loop)
        except RuntimeError:
            pass

    def _schedule_background_manager(self) -> None:
        loop = self._loop
        if loop is None or loop.is_closed():
            return
        try:
            asyncio.run_coroutine_threadsafe(self._run_background_manager_ui(), loop)
        except RuntimeError:
            pass

    async def _run_compact(self, cmd: str) -> None:
        try:
            hist = list(self.ctx.history)
            if not hist:
                self.renderer.print_warning('Context is empty.')
                return
            preserve_start = len(hist)
            n_keep = 0
            for idx in range(len(hist) - 1, -1, -1):
                r = getattr(hist[idx], 'role', None)
                c = getattr(hist[idx], 'content', None)
                if isinstance(r, str) and r in ('user', 'assistant') and isinstance(c, str) and c.strip():
                    n_keep += 1
                    if n_keep == 2:
                        preserve_start = idx
                        break
            to_compact = hist[:preserve_start]
            if not to_compact:
                self.renderer.print_warning('Nothing to compact (history too short).')
                return
            parts: list[str] = []
            for i, rec in enumerate(to_compact, 1):
                role = getattr(rec, 'role', None)
                if role is None and getattr(rec, 'type', None) == 'compact':
                    role = 'assistant'
                    content = getattr(rec, 'value', '')
                else:
                    content = getattr(rec, 'content', '')
                parts.append(f'## Message {i}\nRole: {role}\nContent: {str(content)}')
            history_text = '\n\n'.join(parts)
            sys_prompt = 'You are a helpful assistant that compacts conversation context. Summarize the following earlier messages into a concise markdown note that preserves key intent, constraints, paths, and code.'
            additional_instructions = cmd[len('/compact'):].strip() if len(cmd) > len('/compact') else ''
            user_prompt = f"Please compact the following context into a concise summary.{(' ' + additional_instructions if additional_instructions else '')}\n\n{history_text}"
            payload = [{'role': 'system', 'content': sys_prompt}, {'role': 'user', 'content': user_prompt}]
            spinner = self._build_spinner_grid('Requesting compact...')
            self.renderer.show_spinner(spinner)
            got_first = False
            acc: list[str] = []
            client = getattr(self.agent, '_client', None)
            if client is None:
                self.renderer.print_warning('Compact unavailable: Oturn client not initialized.')
                return
            agen = await client.acreate(payload, stream=True, tool_stream=False, debug=self.opts.provider.debug_request, sse_debug=self.opts.provider.debug_sse)
            try:
                async for cev in agen:
                    if not got_first:
                        got_first = True
                        self.renderer.end_streaming_turn()
                        self.renderer.enter_prompt()
                    if isinstance(cev, dict) and cev.get('type') in ('assistant_delta', 'assistant_reasoning_delta'):
                        text = cev.get('text', '')
                        if text:
                            acc.append(text)
            finally:
                pass
            content = ''.join(acc).strip()
            if not content:
                self.renderer.print_warning('LLM did not return summary; skipping compaction.')
                return
            self.console.print(Markdown(content))
            self.ctx.append_compact(str(content), additional_instructions)
        except Exception as e:
            self.renderer.print_error(f'Failed to compact context: {e}')

    def _append_input_history(self, s: str) -> None:
        return

    def _build_spinner_grid(self, text: str):
        from rich.spinner import Spinner
        from rich.table import Table
        grid = Table.grid(padding=(0, 0))
        grid.add_row(Spinner('arrow2'), Text(text))
        return grid

    @staticmethod
    def _prompt_yes_no(prompt: str) -> bool:
        try:
            reply = input(prompt)
        except (EOFError, KeyboardInterrupt):
            return False
        return str(reply or '').strip().lower() in {'y', 'yes'}

    @staticmethod
    def _prompt_choice(prompt: str, choices: list[str]) -> tuple[Optional[str], bool]:
        items = [str(choice) for choice in (choices or [])]
        if not items:
            return (None, False)
        try:
            print(prompt)
            for idx, item in enumerate(items, start=1):
                print(f'  {idx}. {item}')
            print('  0. Cancel')
            reply = input('Select an option [0]: ')
        except (EOFError, KeyboardInterrupt):
            return (None, False)
        raw = str(reply or '').strip()
        if not raw:
            return (None, False)
        try:
            index = int(raw)
        except ValueError:
            return (None, False)
        if index == 0:
            return (None, False)
        if 1 <= index <= len(items):
            return (items[index - 1], True)
        return (None, False)

    def _set_future(self, fut: Any, payload: Any) -> None:
        if fut is None:
            return
        try:
            if isinstance(fut, asyncio.Future) and (not fut.done()):
                if self.opts.debug_loop:
                    print(f'[debug][future.set_result] {payload}')
                fut.set_result(payload)
        except Exception:
            pass

    def _resolve_input(self, fut: Any, *, status: str, text: str, input_type: str) -> None:
        self._set_future(fut, {'status': status, 'text': text, 'type': input_type})

    def _schedule_lazy_prompt(self) -> None:
        if self.EXIT:
            return
        task = asyncio.create_task(self._handle_user_input({'future': None}))

        def _done(t: asyncio.Task) -> None:
            try:
                _ = t.exception()
            except Exception:
                pass
        task.add_done_callback(_done)

    def _request_shutdown_event(self) -> None:
        if self._loop is None or self._loop.is_closed():
            return
        try:
            self._loop.call_soon_threadsafe(self.out_q.put_nowait, {'type': 'shutdown'})
        except Exception:
            pass

async def run_repl(work_dir: Path, opts: ReplOptions) -> None:
    """
    兼容你原来的入口：只是把主体搬进 ReplApp。
    """
    app = ReplApp(work_dir, opts)
    await app.run()
