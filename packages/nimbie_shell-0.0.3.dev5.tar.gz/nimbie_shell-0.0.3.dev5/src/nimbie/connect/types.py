from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Awaitable, Callable, Optional, Protocol


@dataclass
class UploadedBinary:
    remote_path: str
    digest: str
    upload_mode: str
    supports_started_event: bool
    local_path: str


@dataclass
class RemoteIdentity:
    user: Optional[str] = None
    host: Optional[str] = None
    home: Optional[str] = None
    login_pwd: Optional[str] = None
    path: Optional[str] = None
    env: dict[str, str] = field(default_factory=dict)


@dataclass
class TransportHandle:
    bin_name: Optional[str] = None
    args: list[str] = field(default_factory=list)
    stdin_fd: Optional[int] = None
    stdout_fd: Optional[int] = None
    stderr_fd: Optional[int] = None
    pid: Optional[int] = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class ConnectResult:
    provider: str
    transport: TransportHandle
    uploaded: UploadedBinary
    identity: RemoteIdentity
    command_cache: set[str] = field(default_factory=set)
    ssh_host: Optional[str] = None
    ssh_user: Optional[str] = None
    ssh_port: Optional[int] = None
    ssh_config_path: Optional[str] = None
    status_message: str = ""


@dataclass
class ConnectContext:
    force_upload: bool = False
    collect_local_candidates: Callable[[], list[dict[str, Any]]] = lambda: []
    rank_candidates: Callable[[list[dict[str, Any]], str, str, str, str], list[dict[str, Any]]] = (
        lambda cands, _arch, _libc, _os, _glibc: cands
    )
    emit_debug: Callable[[str], None] = lambda _msg: None
    ssh_config_path: Optional[Path] = None


class ConnectProvider(Protocol):
    name: str

    async def connect(self, target: str, ctx: ConnectContext) -> ConnectResult:
        ...

    async def disconnect(self) -> None:
        ...
