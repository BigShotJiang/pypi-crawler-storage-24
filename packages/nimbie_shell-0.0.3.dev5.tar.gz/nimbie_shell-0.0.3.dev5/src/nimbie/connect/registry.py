from __future__ import annotations

import importlib
import importlib.util
import logging
from pathlib import Path
import sys
from typing import Any, Dict

from .providers import JumperSSHProvider, SSHProvider
from .types import ConnectProvider

LOGGER = logging.getLogger(__name__)


class ConnectProviderRegistry:
    def __init__(self) -> None:
        self._providers: Dict[str, ConnectProvider] = {}
        self._default_user_plugin_path = Path.home() / ".nimbie" / "connect"
        self._ensure_default_user_plugin_path()
        self.register(SSHProvider())
        self.register(JumperSSHProvider())
        self._load_external_providers_from_unified_config()

    def register(self, provider: ConnectProvider) -> None:
        self._providers[str(provider.name)] = provider

    def get(self, name: str) -> ConnectProvider:
        key = (name or "").strip()
        if not key:
            raise KeyError("empty provider name")
        if key not in self._providers:
            raise KeyError(f"connect provider not found: {key}")
        return self._providers[key]

    def names(self) -> list[str]:
        return sorted(self._providers.keys())

    def _ensure_default_user_plugin_path(self) -> None:
        p = self._default_user_plugin_path.expanduser()
        if p.exists():
            s = str(p.resolve())
            if s not in sys.path:
                sys.path.insert(0, s)

    def _load_external_providers_from_unified_config(self) -> None:
        cfg_path = Path.home() / ".nimbie" / "config.py"
        if not cfg_path.exists():
            return
        try:
            payload = _read_python_config_payload(cfg_path)
        except Exception as e:
            LOGGER.warning("connect: failed to read %s: %s", cfg_path, e)
            return
        connect_cfg = payload.get("connect")
        if not isinstance(connect_cfg, dict):
            return
        python_paths = connect_cfg.get("python_paths")
        if isinstance(python_paths, list):
            for item in python_paths:
                if not isinstance(item, str):
                    continue
                p = Path(item).expanduser()
                if p.exists():
                    s = str(p.resolve())
                    if s not in sys.path:
                        sys.path.insert(0, s)
        provider_settings = connect_cfg.get("provider_settings")
        if isinstance(provider_settings, dict):
            for provider_name, cfg in provider_settings.items():
                if not isinstance(provider_name, str) or not isinstance(cfg, dict):
                    continue
                try:
                    provider = self.get(provider_name)
                except KeyError:
                    continue
                _apply_provider_config(provider, cfg)

        providers = connect_cfg.get("providers")
        if not isinstance(providers, list):
            return
        for ent in providers:
            if not isinstance(ent, dict):
                continue
            try:
                provider = _load_provider_from_entry(ent)
                self.register(provider)
            except Exception as e:
                LOGGER.warning("connect: failed to load provider entry %r: %s", ent, e)


def _read_python_config_payload(config_path: Path) -> dict[str, Any]:
    module_name = f"nimbie_connect_cfg_{config_path.stem}"
    spec = importlib.util.spec_from_file_location(module_name, config_path)
    if spec is None or spec.loader is None:
        raise ValueError(f"cannot import config module: {config_path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    try:
        spec.loader.exec_module(module)
        payload = getattr(module, "CONFIG")
        if not isinstance(payload, dict):
            raise ValueError(f"CONFIG must be dict in {config_path}")
        return payload
    finally:
        sys.modules.pop(module_name, None)


def _load_provider_from_entry(entry: dict[str, Any]) -> ConnectProvider:
    module_name = str(entry.get("module") or "").strip()
    class_name = str(entry.get("class") or "").strip()
    if not module_name or not class_name:
        raise ValueError("provider entry needs non-empty module and class")
    extra_path = str(entry.get("path") or "").strip()
    if extra_path:
        p = Path(extra_path).expanduser()
        if p.exists():
            s = str(p.resolve())
            if s not in sys.path:
                sys.path.insert(0, s)
    mod = importlib.import_module(module_name)
    cls = getattr(mod, class_name, None)
    if cls is None:
        raise ValueError(f"class {class_name!r} not found in module {module_name!r}")
    provider_cfg = _extract_provider_config(entry)
    provider = _instantiate_provider(cls, provider_cfg)
    _apply_provider_config(provider, provider_cfg)
    if not getattr(provider, "name", None):
        override_name = str(entry.get("name") or "").strip()
        if override_name:
            setattr(provider, "name", override_name)
    return provider


def _extract_provider_config(entry: dict[str, Any]) -> dict[str, Any]:
    cfg = dict(entry.get("config") or {}) if isinstance(entry.get("config"), dict) else {}
    reserved = {"name", "module", "class", "path", "config"}
    for k, v in entry.items():
        if k in reserved:
            continue
        cfg[k] = v
    return cfg


def _instantiate_provider(cls: Any, provider_cfg: dict[str, Any]) -> ConnectProvider:
    try:
        return cls(config=provider_cfg)
    except TypeError:
        pass
    try:
        return cls(provider_cfg)
    except TypeError:
        pass
    return cls()


def _apply_provider_config(provider: ConnectProvider, provider_cfg: dict[str, Any]) -> None:
    if not provider_cfg:
        return
    configured = False
    if hasattr(provider, "configure"):
        try:
            getattr(provider, "configure")(provider_cfg)
            configured = True
        except Exception as e:
            LOGGER.warning("connect: provider.configure failed for %s: %s", getattr(provider, "name", provider), e)
    if not configured and hasattr(provider, "set_config"):
        try:
            getattr(provider, "set_config")(provider_cfg)
            configured = True
        except Exception as e:
            LOGGER.warning("connect: provider.set_config failed for %s: %s", getattr(provider, "name", provider), e)
    try:
        setattr(provider, "provider_config", dict(provider_cfg))
    except Exception:
        pass


_REGISTRY = ConnectProviderRegistry()


def get_connect_provider_registry() -> ConnectProviderRegistry:
    return _REGISTRY
