#!/bin/bash
# Simulate REPL exit
# Clear the bash command line (which shows the script path)
printf '\033[1A\033[2K'
echo -e "  \033[90mBye.\033[0m"
echo ""
