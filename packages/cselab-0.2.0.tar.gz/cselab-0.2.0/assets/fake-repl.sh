#!/bin/bash
# Simulates cselab REPL startup: connection + banner + first-time examples
# Used by demo-repl.tape for VHS recording

RST="\033[0m"
BOLD="\033[1m"
DIM="\033[90m"
GREEN="\033[32m"
TEAL="\033[36m"
# Truecolor for mascot
T_FG="\033[38;2;78;201;176m"
W_FG="\033[38;2;255;255;255m"
D_FG="\033[38;2;20;100;85m"
L_FG="\033[38;2;180;245;230m"
T_BG="\033[48;2;78;201;176m"
W_BG="\033[48;2;255;255;255m"
D_BG="\033[48;2;20;100;85m"
L_BG="\033[48;2;180;245;230m"

# Connection
sleep 0.3
echo -ne "  ${DIM}Connecting to cse.unsw.edu.au...${RST} "
sleep 0.8
echo -e "${GREEN}ok${RST}"

# Banner with mascot (half-block art)
echo ""
# Row 1: ears / head  →  cselab v0.2.0
echo -e "  ${T_FG}${T_BG}▀${RST} ${T_FG}${T_BG}▀${RST}${T_FG}${T_BG}▀${RST}${T_FG}${T_BG}▀${RST}${T_FG}${T_BG}▀${RST}${T_FG}${T_BG}▀${RST} ${T_FG}${T_BG}▀${RST}        ${BOLD}cselab${RST} v0.2.0"
# Row 2: eyes / body  →  user@host
echo -e "  ${W_FG}${L_BG}▀${RST}${D_FG}${D_BG}▀${RST}${T_FG}${T_BG}▀${RST}${W_FG}${L_BG}▀${RST}${D_FG}${D_BG}▀${RST}${T_FG}${T_BG}▀${RST}        ${DIM}z5502277@cse.unsw.edu.au${RST}"
# Row 3: body + tail  →  path
echo -e " ${T_FG}${T_BG}▀${RST}${T_FG}${T_BG}▀${RST}${T_FG}${T_BG}▀${RST}${T_FG}${T_BG}▀${RST}${T_FG}${T_BG}▀${RST}${T_FG}${T_BG}▀${RST}${T_FG}${T_BG}▀${RST}${T_FG}${T_BG}▀${RST}  ${T_FG}▀${RST}     ${DIM}~/COMP1521/lab03${RST}"
# Row 4: legs
echo -e "    ${T_FG}▀${RST}   ${T_FG}▀${RST}"
echo ""

# First-time examples
echo -e "  ${DIM}Examples:${RST}"
echo -e "    1521 autotest lab03   ${DIM}run autotest${RST}"
echo -e "    give cs1521 lab03 *.c ${DIM}submit files${RST}"
echo -e "    dcc prog.c -o prog    ${DIM}compile C${RST}"
echo -e "  ${DIM}Start typing for suggestions.${RST} help ${DIM}for more.${RST}"
