#!/bin/bash
# Simulates a REPL command execution: sync + autotest output
# Used by demo-repl.tape for VHS recording

RST="\033[0m"
DIM="\033[90m"
GREEN="\033[32m"
MAGENTA="\033[35m"

# Sync indicator
sleep 0.2
echo -e "  ${GREEN}●${RST} ${DIM}sync 0.3s${RST}"
sleep 0.3

# Autotest output
echo -e "${MAGENTA}========================================${RST}"
sleep 0.1
echo "1521 check-recursion collatz.c"
echo "dcc -fsanitize=address -o collatz collatz.c"
sleep 0.15
echo "Test 0 (./collatz 1) - passed"
sleep 0.1
echo "Test 1 (./collatz 12) - passed"
sleep 0.1
echo "Test 2 (./collatz 10) - passed"
sleep 0.1
echo "Test 3 (./collatz 42) - passed"
sleep 0.1
echo "Test 4 (./collatz 100) - passed"
sleep 0.15
echo -e "${GREEN}5 tests passed${RST} 0 tests failed"
echo -e "${MAGENTA}========================================${RST}"
