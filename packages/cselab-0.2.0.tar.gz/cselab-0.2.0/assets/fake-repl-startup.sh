#!/bin/bash
# Full REPL startup: clear → connect → banner → examples → separator
# Used by demo-repl.tape

RST="\033[0m"
DIM="\033[90m"
GREEN="\033[32m"
BOLD="\033[1m"

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# Clear screen
printf '\033[2J\033[H'

# Connection
printf "  ${DIM}Connecting to cse.unsw.edu.au...${RST} "
sleep 0.8
printf "${GREEN}ok${RST}\n"

# Banner with REAL mascot renderer
python3 "$SCRIPT_DIR/render-banner.py"

# First-time examples
echo -e "  ${DIM}Examples:${RST}"
echo -e "    1521 autotest lab03   ${DIM}run autotest${RST}"
echo -e "    give cs1521 lab03 *.c ${DIM}submit files${RST}"
echo -e "    dcc prog.c -o prog    ${DIM}compile C${RST}"
echo -e "  ${DIM}Start typing for suggestions.${RST} help ${DIM}for more.${RST}"

# Separator
printf "${DIM}"
printf '─%.0s' {1..70}
printf "${RST}\n"
