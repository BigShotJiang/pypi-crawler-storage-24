#!/bin/bash
# Simulate REPL command: sync + dcc + run hello + separator
RST="\033[0m"
DIM="\033[90m"
GREEN="\033[32m"

# Clear the bash command line (which shows the script path)
printf '\033[1A\033[2K'

sleep 0.2
echo -e "  ${GREEN}●${RST} ${DIM}sync 0.2s${RST}"
sleep 0.3
echo "  Hello, World!"

# Separator
printf "${DIM}"
printf '─%.0s' {1..70}
printf "${RST}\n"
