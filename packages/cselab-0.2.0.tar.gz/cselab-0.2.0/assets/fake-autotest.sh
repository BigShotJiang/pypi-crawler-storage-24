#!/bin/bash
# Simulates real cselab autotest output for demo recording
sleep 0.3
echo -e "\033[90m[1/3] Connecting to cse.unsw.edu.au...\033[0m \033[32mOK\033[0m (0.0s)"
sleep 0.3
echo -e "\033[90m[2/3] Syncing files...\033[0m \033[32mOK\033[0m (0.1s)"
sleep 0.2
echo -e "\033[90m[3/3] Running:\033[0m \033[33m1521 autotest collatz\033[0m"
sleep 0.1
echo -e "\033[35m========================================\033[0m"
sleep 0.1
echo "1521 check-recursion collatz.c"
echo "dcc -fsanitize=address -o collatz collatz.c"
sleep 0.15
echo "Test 0 (./collatz 1) - passed"
sleep 0.1
echo "Test 1 (./collatz 12) - passed"
sleep 0.1
echo "Test 2 (./collatz 10) - passed"
sleep 0.1
echo "Test 3 (./collatz 42) - passed"
sleep 0.1
echo "Test 4 (./collatz 100) - passed"
sleep 0.15
echo -e "\033[32m5 tests passed\033[0m 0 tests failed"
echo -e "\033[35m========================================\033[0m"
echo -e "Exit: \033[32mOK\033[0m"
