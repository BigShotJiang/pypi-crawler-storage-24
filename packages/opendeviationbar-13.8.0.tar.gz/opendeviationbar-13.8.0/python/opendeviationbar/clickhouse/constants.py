# Issue #46: Modularization - ClickHouse-level constants
"""ClickHouse cache layer constants.

SSoT for ClickHouse-specific settings shared across mixins.
"""

from __future__ import annotations

from typing import Literal

CLICKHOUSE_TRANSIENT_ERRORS: tuple[type[Exception], ...] = (
    OSError,
    RuntimeError,
    ConnectionError,
)
"""Exception types caught for transient ClickHouse failures.

Used across all ClickHouse modules for consistent error handling.
ConnectionError included for network-level failures.
"""

# Issue #90: Parallelize FINAL dedup across partitions for ~7x faster reads.
# Safe because our partitions (symbol, threshold, month) are independent.
FINAL_READ_SETTINGS: dict[str, int] = {
    "do_not_merge_across_partitions_select_final": 1,
}

# Issue #158 Phase 8: Overlap strategy type and validation.
OverlapStrategy = Literal["off", "warn", "skip", "replace"]
_VALID_OVERLAP_STRATEGIES: frozenset[str] = frozenset({"off", "warn", "skip", "replace"})


def validate_overlap_strategy(strategy: str) -> OverlapStrategy:
    """Validate overlap_strategy string. Raises ValueError on invalid input."""
    if strategy not in _VALID_OVERLAP_STRATEGIES:
        msg = f"Invalid overlap_strategy={strategy!r}. Must be one of: {', '.join(sorted(_VALID_OVERLAP_STRATEGIES))}"
        raise ValueError(msg)
    return strategy  # type: ignore[return-value]
