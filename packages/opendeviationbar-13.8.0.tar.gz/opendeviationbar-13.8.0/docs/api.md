# opendeviationbar-py API Reference

> **DEPRECATED**: This file has been split into topic-focused files for better maintainability.
>
> Please see **[docs/api/INDEX.md](/docs/api/INDEX.md)** for the new API reference.

---

## Quick Links

| Topic                                                      | New Location                                         |
| ---------------------------------------------------------- | ---------------------------------------------------- |
| `get_open_deviation_bars()`, `get_n_open_deviation_bars()` | [api/primary-api.md](/docs/api/primary-api.md)       |
| `populate_cache_resumable()`                               | [api/cache-api.md](/docs/api/cache-api.md)           |
| `process_trades_*`, `OpenDeviationBarProcessor`            | [api/processing-api.md](/docs/api/processing-api.md) |
| Data formats, error handling                               | [api/validation-api.md](/docs/api/validation-api.md) |
| Constants, utilities                                       | [api/utilities.md](/docs/api/utilities.md)           |
| FAQ, troubleshooting                                       | [api/faq.md](/docs/api/faq.md)                       |

---

**Last Updated**: 2026-02-03 (redirected to split docs)
