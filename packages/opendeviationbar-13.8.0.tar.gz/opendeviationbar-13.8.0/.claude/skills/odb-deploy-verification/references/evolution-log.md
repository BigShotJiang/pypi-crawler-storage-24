# Evolution Log

## 2026-03-10: Initial creation

Created 58-point verification checklist covering 9 sections:

1. Package & Version Integrity (7 checks)
2. Native Extension & Process Health (6 checks)
3. Systemd Services & Process Management (6 checks)
4. ClickHouse Health (8 checks)
5. Stathera Audit (4 checks)
6. Sidecar HTTP Endpoints (4 checks)
7. Infrastructure & Resources (6 checks)
8. Monitoring & Alerting (3 checks)
9. Configuration Consistency (5 checks)

Born from v13.6.6 bigblack alignment session where stale `.so` detection and DRY constant verification were discovered as critical post-deploy checks.

## 2026-03-10: v2 — Release pipeline pitfalls (learned from v13.7.0)

Added 2 new sections based on real failures during v13.7.0 release:

- **Section 0: Network & Connectivity Pre-Check** (5 checks)
  - GitHub SSH timeout detection with 5s ConnectTimeout
  - Bigblack SSH connectivity pre-check
  - HTTPS fallback procedure (swap remote URL + `gh auth token`)
  - GitHub API (HTTPS) as alternative connectivity test
  - semantic-release SSH dependency warning

- **Section 10: Release Pipeline Pitfalls** (6 checks)
  - Version file consistency after release (Cargo.toml vs git tag vs Python)
  - Crates.io "already exists" race condition (version bump not finished)
  - semantic-release SSH dependency (needs HTTPS remote)
  - semantic-release dry-run outside CI (needs `--no-ci`)
  - PyPI CDN propagation delay (30-60s normal, up to 5min)
  - Git push via HTTPS with `gh auth token`

Enhanced existing sections:

- **1.2**: Added note about `maturin develop` for local version sync
- **1.3**: Added PyPI CDN propagation delay context
- **Verdict table**: Added sections 0 and 10, added SKIP status
- **Remediation table**: 5 new entries (SSH timeout, dry-run, crates.io, PyPI CDN, stale **version**)

Total: 69 checks across 11 sections (was 58 across 9).

## 2026-03-10: v3 — skill-architecture validation + progressive disclosure

Validated against `plugin-dev:skill-architecture` checklist. Fixed 4 FAILs and 2 WARNs:

**Fixes applied:**

1. **SKILL.md over 500 lines** (was 838): Restructured with progressive disclosure — SKILL.md now 204 lines with section overview table, Critical Checks (quick path), and operational notes. Detailed bash commands moved to:
   - `references/version-and-release-checks.md` (Sections 0, 1, 10)
   - `references/production-health-checks.md` (Sections 2-9)

2. **Missing `disable-model-invocation: true`**: Added — this is a task skill (runs SSH commands to production) and should never auto-trigger.

3. **Stale "58-point" count**: Updated to "70-point" in body text.

4. **Remediation table inconsistency**: Fixed stale .so remediation from `systemctl restart` (doesn't work on bigblack) to monit kill+respawn pattern.

5. **Description anti-pattern**: Removed `TRIGGERS - keyword1, keyword2` suffix. Replaced with natural language sentences per writing guide ("Write descriptions as sentences a human could understand").

6. **Added Critical Checks section**: Quick-path 5-command sanity check for fast post-deploy verification without reading full reference files.

7. **Added Section 1.8**: Version alignment cross-check (package, Cargo.toml, git tag, running process .so timestamps).

8. **Updated Section 2.2**: Documented monit service management on bigblack (not systemd).

Total: 70 checks across 11 sections. SKILL.md: 204 lines + 2 reference files.
