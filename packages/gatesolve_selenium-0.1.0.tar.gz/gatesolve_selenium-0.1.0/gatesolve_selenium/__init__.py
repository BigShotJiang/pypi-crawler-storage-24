"""
gatesolve-selenium: Automatic CAPTCHA solving for Selenium WebDriver.

Usage:
    from gatesolve_selenium import solve_on_page, with_gatesolve

    # One-shot: solve any CAPTCHA on the current page
    result = solve_on_page(driver, api_key="gs_...")

    # Auto-solve: patch driver to solve on every navigation
    driver = with_gatesolve(driver, api_key="gs_...")
"""

from .solver import (
    GateSolveOptions,
    CaptchaDetection,
    SolveResult,
    detect_captcha,
    solve_on_page,
    with_gatesolve,
)

__version__ = "0.1.0"
__all__ = [
    "GateSolveOptions",
    "CaptchaDetection",
    "SolveResult",
    "detect_captcha",
    "solve_on_page",
    "with_gatesolve",
]
