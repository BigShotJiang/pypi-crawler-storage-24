"""
Core solver logic for gatesolve-selenium.
"""

import time
import logging
from dataclasses import dataclass, field
from typing import Optional, Any

import requests

logger = logging.getLogger("gatesolve")

DEFAULT_BASE_URL = "https://gatesolve.dev"
DEFAULT_TIMEOUT = 30.0
DEFAULT_POLL_INTERVAL = 2.0


@dataclass
class GateSolveOptions:
    """Configuration for GateSolve solver."""
    api_key: str
    base_url: str = DEFAULT_BASE_URL
    timeout: float = DEFAULT_TIMEOUT
    poll_interval: float = DEFAULT_POLL_INTERVAL
    debug: bool = False


@dataclass
class CaptchaDetection:
    """Detected CAPTCHA on a page."""
    type: str  # "turnstile", "recaptcha", "hcaptcha"
    site_key: str
    page_url: str


@dataclass
class SolveResult:
    """Result of a CAPTCHA solve attempt."""
    success: bool
    token: Optional[str] = None
    type: Optional[str] = None
    error: Optional[str] = None
    solve_time_ms: Optional[float] = None


# JavaScript to detect CAPTCHAs in the page
DETECT_JS = """
(function() {
    // Cloudflare Turnstile
    var ts = document.querySelector('[data-sitekey].cf-turnstile') ||
             document.querySelector('iframe[src*="challenges.cloudflare.com"]');
    if (ts) {
        var sk = ts.getAttribute('data-sitekey') || '';
        if (!sk && ts.src) {
            try { sk = new URL(ts.src).searchParams.get('k') || ''; } catch(e) {}
        }
        return JSON.stringify({type: 'turnstile', site_key: sk, page_url: window.location.href});
    }

    // reCAPTCHA
    var rc = document.querySelector('.g-recaptcha[data-sitekey]') ||
             document.querySelector('iframe[src*="google.com/recaptcha"]');
    if (rc) {
        var sk = rc.getAttribute('data-sitekey') || '';
        if (!sk && rc.src) {
            try { sk = new URL(rc.src).searchParams.get('k') || ''; } catch(e) {}
        }
        return JSON.stringify({type: 'recaptcha', site_key: sk, page_url: window.location.href});
    }

    // hCaptcha
    var hc = document.querySelector('.h-captcha[data-sitekey]') ||
             document.querySelector('iframe[src*="hcaptcha.com"]');
    if (hc) {
        var sk = hc.getAttribute('data-sitekey') || '';
        if (!sk && hc.src) {
            try { sk = new URL(hc.src).searchParams.get('sitekey') || ''; } catch(e) {}
        }
        return JSON.stringify({type: 'hcaptcha', site_key: sk, page_url: window.location.href});
    }

    return null;
})();
"""

# JavaScript to inject solved token
INJECT_TURNSTILE_JS = """
(function(token) {
    var input = document.querySelector('input[name="cf-turnstile-response"]') ||
                document.querySelector('.cf-turnstile input[type=hidden]');
    if (input) input.value = token;
    var widget = document.querySelector('.cf-turnstile');
    var cbName = widget && widget.getAttribute('data-callback');
    if (cbName && typeof window[cbName] === 'function') window[cbName](token);
})(arguments[0]);
"""

INJECT_RECAPTCHA_JS = """
(function(token) {
    var textarea = document.querySelector('#g-recaptcha-response');
    if (textarea) { textarea.style.display = 'block'; textarea.value = token; }
    if (typeof window.___grecaptcha_cfg !== 'undefined' && window.___grecaptcha_cfg.clients) {
        var clients = window.___grecaptcha_cfg.clients;
        for (var k in clients) {
            for (var j in clients[k]) {
                var v = clients[k][j];
                if (v && v.callback && typeof v.callback === 'function') v.callback(token);
            }
        }
    }
})(arguments[0]);
"""

INJECT_HCAPTCHA_JS = """
(function(token) {
    var textarea = document.querySelector('[name="h-captcha-response"]');
    if (textarea) textarea.value = token;
    var iframe = document.querySelector('iframe[src*="hcaptcha.com"]');
    var parent = iframe && iframe.closest('.h-captcha');
    var cbName = parent && parent.getAttribute('data-callback');
    if (cbName && typeof window[cbName] === 'function') window[cbName](token);
})(arguments[0]);
"""

INJECT_MAP = {
    "turnstile": INJECT_TURNSTILE_JS,
    "recaptcha": INJECT_RECAPTCHA_JS,
    "hcaptcha": INJECT_HCAPTCHA_JS,
}


def detect_captcha(driver: Any) -> Optional[CaptchaDetection]:
    """
    Detect CAPTCHA challenges on the current Selenium page.

    Args:
        driver: Selenium WebDriver instance

    Returns:
        CaptchaDetection if found, None otherwise
    """
    import json as _json

    result = driver.execute_script(DETECT_JS)
    if not result:
        return None

    data = _json.loads(result)
    return CaptchaDetection(
        type=data["type"],
        site_key=data["site_key"],
        page_url=data["page_url"],
    )


def _submit_and_poll(detection: CaptchaDetection, opts: GateSolveOptions) -> SolveResult:
    """Submit a solve request and poll for result."""
    start = time.time()

    if opts.debug:
        logger.info(f"Solving {detection.type} for {detection.page_url}")

    # Submit
    try:
        resp = requests.post(
            f"{opts.base_url}/api/solve",
            json={
                "type": detection.type,
                "siteKey": detection.site_key,
                "pageUrl": detection.page_url,
            },
            headers={
                "Content-Type": "application/json",
                "x-api-key": opts.api_key,
            },
            timeout=10,
        )
    except requests.RequestException as e:
        return SolveResult(success=False, error=f"Submit failed: {e}")

    if not resp.ok:
        return SolveResult(success=False, error=f"Submit failed ({resp.status_code}): {resp.text}")

    data = resp.json()

    # Immediate result
    if data.get("token"):
        elapsed = (time.time() - start) * 1000
        return SolveResult(
            success=True,
            token=data["token"],
            type=detection.type,
            solve_time_ms=elapsed,
        )

    job_id = data.get("id")
    if not job_id:
        return SolveResult(success=False, error=data.get("error", "No job ID returned"))

    if opts.debug:
        logger.info(f"Job {job_id} submitted, polling...")

    # Poll
    deadline = start + opts.timeout
    while time.time() < deadline:
        time.sleep(opts.poll_interval)

        try:
            poll_resp = requests.get(
                f"{opts.base_url}/api/solve",
                params={"id": job_id},
                headers={"x-api-key": opts.api_key},
                timeout=10,
            )
        except requests.RequestException:
            continue

        if not poll_resp.ok:
            continue

        poll_data = poll_resp.json()

        if poll_data.get("status") == "completed" and poll_data.get("token"):
            elapsed = (time.time() - start) * 1000
            if opts.debug:
                logger.info(f"Solved in {elapsed:.0f}ms")
            return SolveResult(
                success=True,
                token=poll_data["token"],
                type=detection.type,
                solve_time_ms=elapsed,
            )

        if poll_data.get("status") == "failed":
            return SolveResult(success=False, error=poll_data.get("error", "Solve failed"))

        if opts.debug:
            logger.info(f"Status: {poll_data.get('status')}, waiting...")

    return SolveResult(success=False, error=f"Timeout after {opts.timeout}s")


def _inject_token(driver: Any, detection: CaptchaDetection, token: str) -> None:
    """Inject a solved CAPTCHA token into the page."""
    js = INJECT_MAP.get(detection.type)
    if js:
        driver.execute_script(js, token)


def solve_on_page(
    driver: Any,
    api_key: Optional[str] = None,
    opts: Optional[GateSolveOptions] = None,
    **kwargs: Any,
) -> Optional[SolveResult]:
    """
    Detect and solve any CAPTCHA on the current page.

    Args:
        driver: Selenium WebDriver instance
        api_key: GateSolve API key (shortcut; or pass opts)
        opts: Full GateSolveOptions (overrides api_key)
        **kwargs: Additional options passed to GateSolveOptions

    Returns:
        SolveResult if CAPTCHA found and solve attempted, None if no CAPTCHA
    """
    if opts is None:
        if api_key is None:
            raise ValueError("Either api_key or opts must be provided")
        opts = GateSolveOptions(api_key=api_key, **kwargs)

    detection = detect_captcha(driver)
    if not detection:
        if opts.debug:
            logger.info("No CAPTCHA detected")
        return None

    if opts.debug:
        logger.info(f"Detected {detection.type} (siteKey: {detection.site_key})")

    result = _submit_and_poll(detection, opts)

    if result.success and result.token:
        _inject_token(driver, detection, result.token)
        if opts.debug:
            logger.info("Token injected into page")

    return result


def with_gatesolve(
    driver: Any,
    api_key: Optional[str] = None,
    opts: Optional[GateSolveOptions] = None,
    **kwargs: Any,
) -> Any:
    """
    Patch a Selenium WebDriver to auto-solve CAPTCHAs after every get() call.

    Args:
        driver: Selenium WebDriver instance
        api_key: GateSolve API key
        opts: Full GateSolveOptions
        **kwargs: Additional options passed to GateSolveOptions

    Returns:
        The same driver, patched with auto-solve
    """
    if opts is None:
        if api_key is None:
            raise ValueError("Either api_key or opts must be provided")
        opts = GateSolveOptions(api_key=api_key, **kwargs)

    original_get = driver.get

    def patched_get(url: str) -> None:
        original_get(url)
        # Small delay for JS to render CAPTCHA widgets
        time.sleep(1.0)
        try:
            solve_on_page(driver, opts=opts)
        except Exception as e:
            if opts.debug:
                logger.error(f"Auto-solve error: {e}")

    driver.get = patched_get
    return driver
