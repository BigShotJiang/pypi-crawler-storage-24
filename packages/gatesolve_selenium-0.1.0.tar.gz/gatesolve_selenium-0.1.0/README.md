# gatesolve-selenium

Automatic CAPTCHA solving for Selenium WebDriver. Detects Cloudflare Turnstile, reCAPTCHA, and hCaptcha and solves them via [GateSolve](https://gatesolve.dev).

## Install

```bash
pip install gatesolve-selenium
```

## Quick Start

### One-shot: Solve CAPTCHA on current page

```python
from selenium import webdriver
from gatesolve_selenium import solve_on_page

driver = webdriver.Chrome()
driver.get("https://example.com/login")

# Detect and solve any CAPTCHA
result = solve_on_page(driver, api_key="gs_your_key_here")

if result and result.success:
    print(f"Solved {result.type} in {result.solve_time_ms:.0f}ms")
    driver.find_element("css selector", 'button[type="submit"]').click()
```

### Auto-solve: Patch driver

```python
from selenium import webdriver
from gatesolve_selenium import with_gatesolve

driver = webdriver.Chrome()
driver = with_gatesolve(driver, api_key="gs_your_key_here", debug=True)

# CAPTCHAs are solved automatically after every driver.get()
driver.get("https://protected-site.com")
```

### Detect only

```python
from gatesolve_selenium import detect_captcha

detection = detect_captcha(driver)
if detection:
    print(f"Found {detection.type} with siteKey {detection.site_key}")
```

## API

### `solve_on_page(driver, api_key=None, opts=None, **kwargs)`

Detect and solve a CAPTCHA on the current page. Returns `SolveResult | None`.

### `with_gatesolve(driver, api_key=None, opts=None, **kwargs)`

Patch a WebDriver to auto-solve CAPTCHAs after every `get()` call. Returns the same driver.

### `detect_captcha(driver)`

Detect CAPTCHA type and siteKey without solving. Returns `CaptchaDetection | None`.

## Options

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `api_key` | `str` | required | GateSolve API key |
| `base_url` | `str` | `https://gatesolve.dev` | API base URL |
| `timeout` | `float` | `30.0` | Max solve wait (seconds) |
| `poll_interval` | `float` | `2.0` | Poll frequency (seconds) |
| `debug` | `bool` | `False` | Log debug info |

## Supported CAPTCHAs

- **Cloudflare Turnstile** — $0.02/solve
- **reCAPTCHA v2/v3** — $0.03/solve
- **hCaptcha** — $0.03/solve

## Free Tier

100 free solves per API key. No credit card required. [gatesolve.dev](https://gatesolve.dev)

## License

MIT
