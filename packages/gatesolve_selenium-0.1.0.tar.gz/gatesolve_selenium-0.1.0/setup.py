from setuptools import setup, find_packages

setup(
    name="gatesolve-selenium",
    version="0.1.0",
    description="Automatic CAPTCHA solving for Selenium. Detects Cloudflare Turnstile, reCAPTCHA, and hCaptcha and solves them via GateSolve.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Arson",
    author_email="arson@agentmail.to",
    url="https://github.com/arsonx-dev/gatesolve-selenium",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        "requests>=2.20.0",
    ],
    extras_require={
        "selenium": ["selenium>=4.0.0"],
    },
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Internet :: WWW/HTTP",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    keywords="selenium captcha turnstile cloudflare recaptcha hcaptcha gatesolve automation ai-agent web-scraping",
    project_urls={
        "Homepage": "https://gatesolve.dev",
        "Documentation": "https://gatesolve.dev/docs",
        "Source": "https://github.com/arsonx-dev/gatesolve-selenium",
    },
)
