"""Fonctions pures de construction de chemins normalisés pour le datalake.

Ces fonctions construisent les chemins S3 sans préfixe d'environnement.
Le préfixage par `{env_prefix}/` est géré par le DatalakeClient.
"""


def original_path(simulation_id: str, filename: str) -> str:
    """Construit le chemin vers un fichier original."""
    return f"{simulation_id}/original/{filename}"


def pages_path(simulation_id: str, filename: str) -> str:
    """Construit le chemin vers une page extraite."""
    return f"{simulation_id}/pages/{filename}"


def ocr_path(simulation_id: str, filename: str) -> str:
    """Construit le chemin vers un résultat OCR."""
    return f"{simulation_id}/ocr/{filename}"


def classifier_path(simulation_id: str, filename: str) -> str:
    """Construit le chemin vers un résultat de classification."""
    return f"{simulation_id}/classifier/{filename}"


def pipeline_inputs_path(simulation_id: str, filename: str) -> str:
    """Construit le chemin vers les entrées pipeline."""
    return f"{simulation_id}/pipeline_inputs/{filename}"


def fusion_path(simulation_id: str, filename: str) -> str:
    """Construit le chemin vers un résultat de fusion."""
    return f"{simulation_id}/fusion/{filename}"


def analyse_path(simulation_id: str, filename: str) -> str:
    """Construit le chemin vers un résultat d'analyse."""
    return f"{simulation_id}/analyse/{filename}"


def events_path(simulation_id: str, filename: str) -> str:
    """Construit le chemin vers un fichier d'événements."""
    return f"{simulation_id}/events/{filename}"


def corrected_path(simulation_id: str, filename: str) -> str:
    """Construit le chemin vers un fichier corrigé."""
    return f"{simulation_id}/corrected/{filename}"


def errors_path(simulation_id: str, filename: str) -> str:
    """Construit le chemin vers un fichier d'erreurs."""
    return f"{simulation_id}/errors/{filename}"


def pipeline_result_path(
    simulation_id: str, pipeline_name: str, filename: str
) -> str:
    """Construit le chemin vers un résultat de pipeline spécifique."""
    return f"{simulation_id}/{pipeline_name}/{filename}"


def classifier_model_path(filename: str) -> str:
    """Construit le chemin vers un modèle de classification."""
    return f"models/classifier/{filename}"


def classifier_features_path(simulation_id: str, doc_id: str) -> str:
    """Construit le chemin vers les features d'un document."""
    return f"{simulation_id}/classifier/features/{doc_id}.json"
