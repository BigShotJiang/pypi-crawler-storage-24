"""Exceptions partagées pour les clients CEZAM."""


class MinIOError(Exception):
    """Erreur lors d'une opération MinIO."""

    pass


class RabbitMQError(Exception):
    """Erreur lors d'une opération RabbitMQ."""

    pass


class RetryableError(Exception):
    """Erreur qui doit déclencher un retry."""

    pass


class NonRetryableError(Exception):
    """Erreur qui ne doit pas déclencher de retry."""

    pass
