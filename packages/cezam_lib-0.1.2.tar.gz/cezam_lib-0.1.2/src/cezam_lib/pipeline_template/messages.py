"""Modèles de messages pour la communication inter-pipelines."""

from typing import Literal

from pydantic import BaseModel, Field


class PipelineMessage(BaseModel):
    """Message reçu du Doc Classifier."""

    simulation_id: str = Field(..., min_length=1)
    simulation_public_id: str = Field(..., min_length=1)
    doc_name: str = Field(..., min_length=1)
    document_type: str = Field(..., min_length=1)
    confidence: float = Field(..., ge=0.0, le=1.0)
    ocr_json_path: str = Field(..., min_length=1)
    correlation_id: str | None = None
    n_doc: int = Field(0, ge=0)
    n_doc_total: int = Field(0, ge=0)
    n_doc_for_queue: int = Field(0, ge=0)


class FusionMessage(BaseModel):
    """Message envoyé vers la queue Fusion.

    Contient les métadonnées suffisantes pour que le service fusion
    puisse prendre une décision de routage sans relire le JSON MinIO.
    """

    # Identifiants
    simulation_id: str = Field(..., min_length=1)
    simulation_public_id: str = Field(..., min_length=1)
    document_type: str = Field(..., min_length=1)
    correlation_id: str | None = None

    # Résultat
    pipeline_output_path: str = Field(..., min_length=1)
    status: Literal["success", "partial", "error"]
    quality: str = "POOR"
    action: str = "REJECT"

    # Métriques post-extraction
    fields_extracted: int = Field(0, ge=0)
    confidence_avg: float = Field(0.0, ge=0.0, le=1.0)
    warnings_count: int = Field(0, ge=0)

    # Contexte
    source_documents: list[str] = Field(default_factory=list)
    partner: str | None = None
    pipeline_name: str = ""
    duration_ms: int = Field(0, ge=0)
    n_doc: int = Field(0, ge=0)
    n_doc_total: int = Field(0, ge=0)
