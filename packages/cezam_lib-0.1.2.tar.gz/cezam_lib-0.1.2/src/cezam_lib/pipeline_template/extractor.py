"""Interface abstraite pour l'extraction de données depuis l'OCR."""

from abc import ABC, abstractmethod
from typing import Generic, TypeVar

from pydantic import BaseModel

T = TypeVar("T", bound=BaseModel)


class DataExtractor(ABC, Generic[T]):
    """Interface abstraite pour l'extraction de données.

    Les extracteurs concrets héritent de cette classe et implémentent
    la méthode extract() pour transformer les données OCR en modèle typé.
    """

    @abstractmethod
    def extract(self, ocr_data: dict) -> T:
        """Extrait les données structurées depuis l'OCR.

        Args:
            ocr_data: Données OCR du document (dict JSON).

        Returns:
            Données extraites typées selon le modèle T.

        Raises:
            RetryableError: Si l'extraction peut être retentée.
            NonRetryableError: Si l'extraction a échoué définitivement.
        """
        ...
