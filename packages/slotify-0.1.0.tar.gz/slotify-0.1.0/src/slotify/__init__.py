"""Towards a more natural understanding of language."""

from importlib.metadata import version

__version__ = version(__name__)
