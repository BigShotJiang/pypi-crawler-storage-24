# Slotify 🔏

Enforce, validate, and promote the usage of slots.