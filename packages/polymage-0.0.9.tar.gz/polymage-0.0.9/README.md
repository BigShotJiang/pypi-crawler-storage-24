# A Polymorphic Multimodal Agents Framework

A modular, platform-agnostic Python library to orchestrate multimodal AI agents across multiple platforms 
and AI models (Gemma, moondream, Flux, HiDream, etc.)

Compared to other AI Agent libraries, polymage is not "LLM centric" and do not use LLMs as Orchestrators.

Can run both on Local platforms
- Ollama (https://ollama.com), available for macOS, Windows, and Linux
- LmStudio (https://lmstudio.ai), available for macOS, Windows, and Linux
- DrawThings (https://drawthings.ai), available only on macOS

And on Cloud platforms
- Groq ( https://groq.com/ )
- Cloudflare ( https://developers.cloudflare.com/workers-ai/ )
- Togetherai ( https://docs.together.ai/intro )
- Hugginface ( https://huggingface.co/docs/hub/en/api )

## ✨ Features

- Define agents with prompts + multimodal inputs (image, audio, video, text)
- Run same agent on multiple platforms/models for comparison
- Workflow orchestration : just python scripts or tools like Apache Airflow

## 🚀 Quick Start

I recommand to use UV. 
UV is the best tool to manage multiple python version and multiple virtual python environment on your machine

For testing polymage, clone the examples repo
```bash
git clone https://gitlab.com/polymage-org/examples.git
```

then go to the examples directory, create a python virtual env with UV
```bash
uv venv
```
And run an example, for example the image captioner demo
```bash
uv run image_captioner.py images/cat_at_the_window.jpg
``` 



---

Apache 2.0 License — Happy coding with polymage! 🚀
