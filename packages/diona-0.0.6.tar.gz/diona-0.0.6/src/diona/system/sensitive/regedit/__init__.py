"""
Registry Analysis Module for Windows Privacy Information

This module provides functionality to analyze Windows registry keys related to user privacy,
including RecentDocs and ShellBags analysis.
"""

from .analyzer import RegistryAnalyzer
from .recent_docs import RecentDocsAnalyzer
from .shellbags import ShellBagsAnalyzer
from .exporter import RegistryExporter
from .models import (
    RecentDocsData,
    RecentDocsEntry,
    ShellBagsData,
    ShellBagEntry,
    RegistryAnalysisResult
)

__all__ = [
    "RegistryAnalyzer",
    "RecentDocsAnalyzer",
    "ShellBagsAnalyzer", 
    "RegistryExporter",
    "RecentDocsData",
    "RecentDocsEntry",
    "ShellBagsData",
    "ShellBagEntry",
    "RegistryAnalysisResult"
]