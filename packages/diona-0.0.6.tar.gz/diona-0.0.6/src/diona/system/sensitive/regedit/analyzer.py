"""
Main Registry Analyzer

Combines RecentDocs and ShellBags analysis into a unified interface.
"""

from typing import Optional
from datetime import datetime

from diona.system.sensitive.core.info_store import InfoStore
from diona.system.sensitive.runcontext.models import ContextInfo
from .recent_docs import RecentDocsAnalyzer
from .shellbags import ShellBagsAnalyzer
from .models import RegistryAnalysisResult, RecentDocsData, ShellBagsData


class RegistryAnalyzer:
    """Main analyzer for Windows registry privacy data."""
    
    def __init__(self):
        self._info_store = InfoStore()
        self._context_info: Optional[ContextInfo] = None
        self.recent_docs_analyzer = RecentDocsAnalyzer()
        self.shellbags_analyzer = ShellBagsAnalyzer()
    
    def _initialize_context(self) -> bool:
        """Initialize context information and check permissions."""
        try:
            self._info_store.initialize()
            self._context_info = self._info_store._context_info
            return self._context_info is not None
        except Exception as e:
            print(f"Error initializing context: {e}")
            return False
    
    def analyze_all(self) -> RegistryAnalysisResult:
        """
        Perform complete registry analysis including RecentDocs and ShellBags.
        
        Returns:
            RegistryAnalysisResult containing all analysis data
        """
        if not self._initialize_context():
            # Return empty result with error status
            return RegistryAnalysisResult(
                recent_docs=RecentDocsData(status="permission_denied"),
                shellbags=ShellBagsData(status="permission_denied"),
                context_info=None
            )
        
        # Perform both analyses
        recent_docs_result = self.recent_docs_analyzer.analyze()
        shellbags_result = self.shellbags_analyzer.analyze()
        
        return RegistryAnalysisResult(
            recent_docs=recent_docs_result,
            shellbags=shellbags_result,
            context_info=self._context_info
        )
    
    def analyze_recent_docs(self) -> RecentDocsData:
        """
        Analyze only RecentDocs registry data.
        
        Returns:
            RecentDocsData containing analysis results
        """
        if not self._initialize_context():
            return RecentDocsData(status="permission_denied")
        
        return self.recent_docs_analyzer.analyze()
    
    def analyze_shellbags(self) -> ShellBagsData:
        """
        Analyze only ShellBags registry data.
        
        Returns:
            ShellBagsData containing analysis results
        """
        if not self._initialize_context():
            return ShellBagsData(status="permission_denied")
        
        return self.shellbags_analyzer.analyze()