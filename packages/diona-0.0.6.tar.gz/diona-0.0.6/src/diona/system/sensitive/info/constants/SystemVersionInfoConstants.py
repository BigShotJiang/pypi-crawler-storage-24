"""
System Version Information Constants
"""

class SystemVersionInfoConstants:
    """System Version Information Related Constants"""
    
    # System information retrieval commands
    SYSTEMINFO_COMMAND = ['systeminfo']
    VER_COMMAND = ['ver']
    
    # System information output parsing patterns
    OS_NAME_PATTERN = 'OS 名称:'
    OS_VERSION_PATTERN = 'OS 版本:'
    OS_MANUFACTURER_PATTERN = 'OS 制造商:'
    OS_CONFIGURATION_PATTERN = 'OS 配置:'
    OS_BUILD_TYPE_PATTERN = 'OS 构建类型:'
    REGISTERED_OWNER_PATTERN = '已注册的所有者:'
    REGISTERED_ORGANIZATION_PATTERN = '已注册的组织:'
    PRODUCT_ID_PATTERN = '产品 ID:'
    ORIGINAL_INSTALL_DATE_PATTERN = '初始安装日期:'
    SYSTEM_BOOT_TIME_PATTERN = '系统启动时间:'
    SYSTEM_MANUFACTURER_PATTERN = '系统制造商:'
    SYSTEM_MODEL_PATTERN = '系统型号:'
    SYSTEM_TYPE_PATTERN = '系统类型:'
    PROCESSORS_PATTERN = '处理器:'
    BIOS_VERSION_PATTERN = 'BIOS 版本:'
    WINDOWS_DIRECTORY_PATTERN = 'Windows 目录:'
    SYSTEM_DIRECTORY_PATTERN = '系统目录:'
    BOOT_DEVICE_PATTERN = '启动设备:'
    SYSTEM_LOCALE_PATTERN = '系统区域设置:'
    INPUT_LOCALE_PATTERN = '输入区域设置:'
    TIME_ZONE_PATTERN = '时区:'
    TOTAL_PHYSICAL_MEMORY_PATTERN = '物理内存总量:'
    AVAILABLE_PHYSICAL_MEMORY_PATTERN = '可用物理内存:'
    VIRTUAL_MEMORY_MAX_SIZE_PATTERN = '虚拟内存: 最大值:'
    VIRTUAL_MEMORY_AVAILABLE_PATTERN = '虚拟内存: 可用:'
    VIRTUAL_MEMORY_IN_USE_PATTERN = '虚拟内存: 使用中:'
    PAGE_FILE_LOCATIONS_PATTERN = '页面文件位置:'
    DOMAIN_PATTERN = '域:'
    LOGON_SERVER_PATTERN = '登录服务器:'
    HOTFIXES_PATTERN = '修补程序:'
    NETWORK_CARD_PATTERN = '网络卡:'
    
    # Error messages
    ERROR_EXECUTING_COMMAND = "Error executing systeminfo command"
    ERROR_PARSING_OUTPUT = "Error parsing systeminfo output"
    
    # Permission related
    MINIMUM_PERMISSION_LEVEL = "standard_user"
    
    # 编码设置
    DEFAULT_ENCODING = "gbk"