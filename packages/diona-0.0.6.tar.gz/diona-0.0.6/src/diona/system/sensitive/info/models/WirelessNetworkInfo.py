"""
Wireless Network Information Model
"""

from dataclasses import dataclass
from typing import List, Optional


@dataclass
class WirelessNetworkProfile:
    """Wireless Network Profile Model"""
    ssid: Optional[str] = None
    authentication: Optional[str] = None
    encryption: Optional[str] = None
    key_content: Optional[str] = None
    profile_path: Optional[str] = None


@dataclass
class WirelessNetworkInfo:
    """Wireless Network Information Model"""
    profiles: Optional[List[WirelessNetworkProfile]] = None
    error_message: Optional[str] = None