"""System information command"""

from typing import Dict, Any
from diona.project.command.models import CommandModel, CommandParameter
from diona.system.sensitive.info.SystemVersionInfoImpl import SystemVersionInfoImpl
from diona.system.sensitive.info.NetworkConfigInfoImpl import NetworkConfigInfoImpl
from diona.system.sensitive.info.WirelessNetworkInfoImpl import WirelessNetworkInfoImpl


def get_help() -> str:
    """Get help information for the command"""
    return """
Usage: system_info [OPTIONS]

Get system information including OS and network details.

Options:
  --type TYPE       Information type: all, system, network (default: all)
  --help            Show this help message and exit
        """

def execute(args=None) -> str:
    """Execute system info collection
    
    Args:
        args: Command arguments (can be None, dict, or list of strings)
        
    Returns:
        System information
    """
    import argparse
    
    # Create argument parser
    parser = argparse.ArgumentParser(description="Get system information including OS and network details")
    parser.add_argument('--type', type=str, default='all', choices=['all', 'system', 'network'], help='Information type: all, system, network (default: all)')
    
    # Parse arguments
    if args is None:
        # No arguments provided
        parsed_args = parser.parse_args([])
    elif isinstance(args, list):
        # List of strings (command line arguments)
        try:
            parsed_args = parser.parse_args(args)
        except SystemExit:
            return get_help()
    elif isinstance(args, dict):
        # Dict of arguments
        parsed_args = argparse.Namespace(**args)
    else:
        # Invalid argument type
        return get_help()
    
    # help is handled by argparse automatically
    
    info_type = parsed_args.type
    
    import json
    
    result_data = {
        "summary": f"System information collected (type: {info_type})",
        "details": {},
        "metadata": {
            "info_type": info_type
        }
    }
    
    if info_type == 'all' or info_type == 'system':
        try:
            system_info = SystemVersionInfoImpl()
            info = system_info.get_system_version_info()
            result_data["details"]["system"] = info
        except Exception as e:
            result_data["details"]["system_error"] = str(e)
    
    if info_type == 'all' or info_type == 'network':
        try:
            network_info = NetworkConfigInfoImpl()
            info = network_info.get_network_info()
            result_data["details"]["network"] = info
        except Exception as e:
            result_data["details"]["network_error"] = str(e)
    
    return json.dumps(result_data, ensure_ascii=False, indent=2)


SystemInfoCommand = CommandModel(
    name="system_info",
    description="Get system information",
    implementation=execute,
    parameters=[
        CommandParameter(
            name="type",
            type="str",
            description="Information type: all, system, network",
            required=False,
            default="all"
        ),
        CommandParameter(
            name="help",
            type="bool",
            description="Show help message",
            required=False,
            default=False
        )
    ]
)
