"""
常量定义模块
"""

class ContextType:
    """上下文类型常量"""
    ADMINISTRATOR = "administrator"
    STANDARD_USER = "standard_user"

class SessionType:
    """会话类型常量"""
    CONSOLE = "console"
    RDP = "rdp"
    OTHER = "other"
    UNKNOWN = "unknown"

class GroupConstants:
    """用户组相关常量"""
    ADMINISTRATORS_GROUP_NAME = "Administrators"
    ADMINISTRATORS_GROUP_SID = "S-1-5-32-544"
    
    # 常见的Windows用户组
    USERS_GROUP = "Users"
    AUTHENTICATED_USERS = "Authenticated Users"
    EVERYONE = "Everyone"

class CommandPatterns:
    """命令输出模式匹配常量"""
    # whoami命令输出模式
    SID_PATTERN = "S-1-5-"
    
    # net user命令输出模式
    LOCAL_GROUP_MEMBERS_ZH = "本地组成员"
    LOCAL_GROUP_MEMBERS_EN = "Local Group Members"
    
    # 会话类型检测
    RDP_SESSION_PREFIX = "RDP-Tcp"
    CONSOLE_SESSION_NAME = "Console"

class EnvironmentVariables:
    """环境变量常量"""
    USERPROFILE = "USERPROFILE"
    APPDATA = "APPDATA"
    LOCALAPPDATA = "LOCALAPPDATA"
    SESSIONNAME = "SESSIONNAME"