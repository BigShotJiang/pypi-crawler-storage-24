"""
browser 模块初始化文件
"""

from .history import HistoryCollector, ChromeHistoryCollector, EdgeHistoryCollector
from .cookies import CookieCollector, ChromeCookieCollector, EdgeCookieCollector
from .logindata import LoginDataCollector, ChromeLoginDataCollector, EdgeLoginDataCollector
from .models import HistoryRecord, CookieRecord, LoginDataRecord

__all__ = [
    'HistoryCollector', 'ChromeHistoryCollector', 'EdgeHistoryCollector',
    'CookieCollector', 'ChromeCookieCollector', 'EdgeCookieCollector',
    'LoginDataCollector', 'ChromeLoginDataCollector', 'EdgeLoginDataCollector',
    'HistoryRecord', 'CookieRecord', 'LoginDataRecord'
]
