"""
history 模块初始化文件
"""

from .base import HistoryCollector
from .chrome import ChromeHistoryCollector
from .edge import EdgeHistoryCollector

__all__ = ['HistoryCollector', 'ChromeHistoryCollector', 'EdgeHistoryCollector']
