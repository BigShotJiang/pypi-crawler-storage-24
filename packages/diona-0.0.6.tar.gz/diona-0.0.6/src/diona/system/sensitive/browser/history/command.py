"""History collector command"""

from typing import Dict, Any
from diona.project.command.models import CommandModel, CommandParameter
from diona.system.sensitive.browser.history.chrome import ChromeHistoryCollector
from diona.system.sensitive.browser.history.edge import EdgeHistoryCollector


def get_help() -> str:
    """Get help information for the command"""
    return """
Usage: collect_history [OPTIONS]

Collect browsing history from browsers such as Chrome and Edge.

Options:
  --limit LIMIT       Maximum number of history entries to collect (default: 1000)
  --browser BROWSER   Browser to collect from: all, chrome, edge (default: all)
  --help              Show this help message and exit
        """

def execute(args=None) -> str:
    """Execute history collection
    
    Args:
        args: Command arguments (can be None, dict, or list of strings)
        
    Returns:
        Collection result
    """
    import argparse
    
    # Create argument parser
    parser = argparse.ArgumentParser(description="Collect browsing history from browsers such as Chrome and Edge")
    parser.add_argument('--limit', type=int, default=1000, help='Maximum number of history entries to collect (default: 1000)')
    parser.add_argument('--browser', type=str, default='all', choices=['all', 'chrome', 'edge'], help='Browser to collect from: all, chrome, edge (default: all)')
    
    # Parse arguments
    if args is None:
        # No arguments provided
        parsed_args = parser.parse_args([])
    elif isinstance(args, list):
        # List of strings (command line arguments)
        try:
            parsed_args = parser.parse_args(args)
        except SystemExit:
            return get_help()
    elif isinstance(args, dict):
        # Dict of arguments
        parsed_args = argparse.Namespace(**args)
    else:
        # Invalid argument type
        return get_help()
    
    # help is handled by argparse automatically
    
    limit = parsed_args.limit
    browser = parsed_args.browser
    
    result = []
    
    if browser == 'all' or browser == 'chrome':
        try:
            chrome_collector = ChromeHistoryCollector()
            chrome_history = chrome_collector.collect(limit)
            for history in chrome_history:
                # Convert HistoryRecord to serializable dict
                history_dict = {
                    'url': getattr(history, 'url', None),
                    'title': getattr(history, 'title', None),
                    'visit_count': getattr(history, 'visit_count', None),
                    'last_visit_time': getattr(history, 'last_visit_time', None)
                }
                result.append({'browser': 'Chrome', 'history': history_dict})
        except Exception as e:
            result.append({'browser': 'Chrome', 'error': str(e)})
    
    if browser == 'all' or browser == 'edge':
        try:
            edge_collector = EdgeHistoryCollector()
            edge_history = edge_collector.collect(limit)
            for history in edge_history:
                # Convert HistoryRecord to serializable dict
                history_dict = {
                    'url': getattr(history, 'url', None),
                    'title': getattr(history, 'title', None),
                    'visit_count': getattr(history, 'visit_count', None),
                    'last_visit_time': getattr(history, 'last_visit_time', None)
                }
                result.append({'browser': 'Edge', 'history': history_dict})
        except Exception as e:
            result.append({'browser': 'Edge', 'error': str(e)})
    
    import json
    
    # Prepare result data
    result_data = {
        "summary": f"Collected {len(result)} history entries from {browser} browser(s)",
        "details": result,
        "metadata": {
            "browser": browser,
            "limit": limit,
            "total_entries": len(result)
        }
    }
    
    return json.dumps(result_data, ensure_ascii=False, indent=2)


HistoryCollectorCommand = CommandModel(
    name="collect_history",
    description="Collect browsing history from browsers",
    implementation=execute,
    parameters=[
        CommandParameter(
            name="limit",
            type="int",
            description="Maximum number of history entries to collect",
            required=False,
            default=1000
        ),
        CommandParameter(
            name="browser",
            type="str",
            description="Browser to collect from: all, chrome, edge",
            required=False,
            default="all"
        ),
        CommandParameter(
            name="help",
            type="bool",
            description="Show help message",
            required=False,
            default=False
        )
    ]
)
