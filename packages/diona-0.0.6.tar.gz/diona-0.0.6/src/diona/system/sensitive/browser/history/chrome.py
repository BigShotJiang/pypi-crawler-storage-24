"""
Chrome 浏览器历史记录采集
"""

import os
import sqlite3
import tempfile
from typing import List
from datetime import datetime
from diona.system.sensitive.browser.history.base import HistoryCollector
from diona.system.sensitive.browser.models.history import HistoryRecord


class ChromeHistoryCollector(HistoryCollector):
    """
    Chrome 浏览器历史记录采集器
    """
    
    def __init__(self):
        """
        初始化 Chrome 历史记录采集器
        """
        self.history_path = os.path.join(
            os.environ.get('LOCALAPPDATA', ''),
            'Google', 'Chrome', 'User Data', 'Default', 'History'
        )
    
    def collect(self, limit: int = 1000) -> List[HistoryRecord]:
        """
        采集 Chrome 历史记录
        
        Args:
            limit: 采集的记录数量限制
            
        Returns:
            历史记录列表
        """
        history_records = []
        
        if not os.path.exists(self.history_path):
            return history_records
        
        try:
            # 创建临时文件，因为 History 文件可能被 Chrome 锁定
            with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as temp_file:
                temp_path = temp_file.name
            
            # 复制文件内容
            with open(self.history_path, 'rb') as src, open(temp_path, 'wb') as dst:
                dst.write(src.read())
            
            # 连接数据库
            conn = sqlite3.connect(temp_path)
            cursor = conn.cursor()
            
            # 查询历史记录
            query = """
                SELECT url, title, visit_count, last_visit_time 
                FROM urls 
                ORDER BY last_visit_time DESC 
                LIMIT ?
            """
            cursor.execute(query, (limit,))
            
            # 解析结果
            for row in cursor.fetchall():
                url, title, visit_count, last_visit_time = row
                # 转换时间戳（Chrome 使用 WebKit 时间格式：自 1601-01-01 以来的微秒数）
                last_visit_time = self._webkit_timestamp_to_datetime(last_visit_time)
                
                history_records.append(HistoryRecord(
                    url=url,
                    title=title,
                    visit_count=visit_count,
                    last_visit_time=last_visit_time
                ))
            
            # 关闭连接
            cursor.close()
            conn.close()
            
            # 删除临时文件
            os.unlink(temp_path)
            
        except Exception as e:
            print(f"Error collecting Chrome history: {e}")
            if 'temp_path' in locals() and os.path.exists(temp_path):
                try:
                    os.unlink(temp_path)
                except:
                    pass
        
        return history_records
    
    def get_browser_name(self) -> str:
        """
        获取浏览器名称
        
        Returns:
            浏览器名称
        """
        return "Chrome"
    
    def _webkit_timestamp_to_datetime(self, timestamp: int) -> str:
        """
        将 WebKit 时间戳转换为可读的日期时间字符串
        
        Args:
            timestamp: WebKit 时间戳（微秒）
            
        Returns:
            日期时间字符串
        """
        # WebKit 时间戳是自 1601 年 1 月 1 日以来的微秒数
        # 转换为 Unix 时间戳（自 1970 年 1 月 1 日以来的秒数）
        unix_timestamp = (timestamp - 11644473600000000) / 1000000
        return datetime.utcfromtimestamp(unix_timestamp).strftime('%Y-%m-%d %H:%M:%S')
