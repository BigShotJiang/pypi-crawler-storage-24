"""
历史记录采集基类
"""

from abc import ABC, abstractmethod
from typing import List, Dict, Any


class HistoryCollector(ABC):
    """
    历史记录采集器基类
    """
    
    @abstractmethod
    def collect(self, limit: int = 1000) -> List[Dict[str, Any]]:
        """
        采集历史记录
        
        Args:
            limit: 采集的记录数量限制
            
        Returns:
            历史记录列表，每条记录包含url、title、visit_count、last_visit_time等字段
        """
        pass
    
    @abstractmethod
    def get_browser_name(self) -> str:
        """
        获取浏览器名称
        
        Returns:
            浏览器名称
        """
        pass
