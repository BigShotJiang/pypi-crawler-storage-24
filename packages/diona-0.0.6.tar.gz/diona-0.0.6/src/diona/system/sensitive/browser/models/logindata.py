"""
登录数据模型
"""

from dataclasses import dataclass
from typing import Optional


@dataclass
class LoginDataRecord:
    """
    登录数据模型
    """
    
    origin_url: str
    """原始 URL"""
    
    action_url: str
    """操作 URL"""
    
    username_value: str
    """用户名"""
    
    password_value: str
    """加密密码（十六进制格式）"""
    
    date_created: str
    """创建时间（格式：YYYY-MM-DD HH:MM:SS）"""
    
    date_last_used: str
    """最后使用时间（格式：YYYY-MM-DD HH:MM:SS）"""
    
    blacklisted: bool
    """是否被用户列入黑名单"""
    
    def to_dict(self) -> dict:
        """
        将模型转换为字典
        
        Returns:
            字典形式的数据
        """
        return {
            'origin_url': self.origin_url,
            'action_url': self.action_url,
            'username_value': self.username_value,
            'password_value': self.password_value,
            'date_created': self.date_created,
            'date_last_used': self.date_last_used,
            'blacklisted': self.blacklisted
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> 'LoginDataRecord':
        """
        从字典创建模型实例
        
        Args:
            data: 字典数据
            
        Returns:
            LoginDataRecord 实例
        """
        return cls(
            origin_url=data.get('origin_url', ''),
            action_url=data.get('action_url', ''),
            username_value=data.get('username_value', ''),
            password_value=data.get('password_value', ''),
            date_created=data.get('date_created', ''),
            date_last_used=data.get('date_last_used', ''),
            blacklisted=data.get('blacklisted', False)
        )