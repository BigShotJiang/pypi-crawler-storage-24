"""
登录数据采集基类
"""

from abc import ABC, abstractmethod
from typing import List, Dict, Any


class LoginDataCollector(ABC):
    """
    登录数据采集器基类
    """
    
    @abstractmethod
    def collect(self, limit: int = 100) -> List[Dict[str, Any]]:
        """
        采集登录数据
        
        Args:
            limit: 采集的记录数量限制
            
        Returns:
            登录数据列表，每条记录包含origin_url、username_value、password_value等字段
        """
        pass
    
    @abstractmethod
    def get_browser_name(self) -> str:
        """
        获取浏览器名称
        
        Returns:
            浏览器名称
        """
        pass
