"""
logindata 模块初始化文件
"""

from .base import LoginDataCollector
from .chrome import ChromeLoginDataCollector
from .edge import EdgeLoginDataCollector

__all__ = ['LoginDataCollector', 'ChromeLoginDataCollector', 'EdgeLoginDataCollector']
