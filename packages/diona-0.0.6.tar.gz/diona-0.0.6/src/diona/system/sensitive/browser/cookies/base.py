"""
cookie 采集基类
"""

from abc import ABC, abstractmethod
from typing import List, Dict, Any


class CookieCollector(ABC):
    """
    cookie 采集器基类
    """
    
    @abstractmethod
    def collect(self, limit: int = 500) -> List[Dict[str, Any]]:
        """
        采集 cookie
        
        Args:
            limit: 采集的记录数量限制
            
        Returns:
            cookie 列表，每条记录包含host_key、name、value、expires_utc、creation_utc等字段
        """
        pass
    
    @abstractmethod
    def get_browser_name(self) -> str:
        """
        获取浏览器名称
        
        Returns:
            浏览器名称
        """
        pass
