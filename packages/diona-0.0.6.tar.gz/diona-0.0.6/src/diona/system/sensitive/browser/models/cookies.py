"""
Cookie 数据模型
"""

from dataclasses import dataclass
from typing import Optional


@dataclass
class CookieRecord:
    """
    Cookie 数据模型
    """
    
    host_key: str
    """域名"""
    
    name: str
    """Cookie 名称"""
    
    value: str
    """Cookie 值"""
    
    expires_utc: str
    """过期时间（格式：YYYY-MM-DD HH:MM:SS）"""
    
    creation_utc: str
    """创建时间（格式：YYYY-MM-DD HH:MM:SS）"""
    
    last_access_utc: str
    """最后访问时间（格式：YYYY-MM-DD HH:MM:SS）"""
    
    secure: bool
    """是否安全（HTTPS）"""
    
    httponly: bool
    """是否仅 HTTP"""
    
    def to_dict(self) -> dict:
        """
        将模型转换为字典
        
        Returns:
            字典形式的数据
        """
        return {
            'host_key': self.host_key,
            'name': self.name,
            'value': self.value,
            'expires_utc': self.expires_utc,
            'creation_utc': self.creation_utc,
            'last_access_utc': self.last_access_utc,
            'secure': self.secure,
            'httponly': self.httponly
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> 'CookieRecord':
        """
        从字典创建模型实例
        
        Args:
            data: 字典数据
            
        Returns:
            CookieRecord 实例
        """
        return cls(
            host_key=data.get('host_key', ''),
            name=data.get('name', ''),
            value=data.get('value', ''),
            expires_utc=data.get('expires_utc', ''),
            creation_utc=data.get('creation_utc', ''),
            last_access_utc=data.get('last_access_utc', ''),
            secure=data.get('secure', False),
            httponly=data.get('httponly', False)
        )