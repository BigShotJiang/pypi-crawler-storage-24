"""
Credential data models
"""

from dataclasses import dataclass
from typing import Optional, List
from datetime import datetime


@dataclass
class CredentialEntry:
    """Credential entry data model"""
    target: str
    credential_type: str
    source: str
    username: Optional[str] = None
    target_name: Optional[str] = None
    file_size: Optional[int] = None
    persist: Optional[int] = None
    timestamp: Optional[datetime] = None


@dataclass
class CredentialCollectionResult:
    """Credential collection result data model"""
    success: bool
    entries: List[CredentialEntry]
    error_message: Optional[str] = None
    timestamp: Optional[datetime] = None
    collection_methods_used: List[str] = None

    def __post_init__(self):
        if self.collection_methods_used is None:
            self.collection_methods_used = []
        if self.timestamp is None:
            self.timestamp = datetime.now()