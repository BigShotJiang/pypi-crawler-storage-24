"""Command module for project tool system"""

from diona.project.cli.register import (
    ModuleCommandRegistry,
    ModuleCommandRegistry as CommandRegistry,
    get_module_command_registry
)
from .models import CommandModel, CommandParameter

# Backward compatibility
CommandManager = ModuleCommandRegistry

__all__ = ['CommandManager', 'CommandModel', 'CommandParameter', 'CommandRegistry', 'get_module_command_registry']
