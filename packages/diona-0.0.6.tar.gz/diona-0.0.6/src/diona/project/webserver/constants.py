"""WebServer constants"""

from typing import Final

DEFAULT_WEB_ADDR: Final[str] = "localhost"
DEFAULT_WEB_PORT: Final[int] = 8899

ENV_WEB_ADDR: Final[str] = "DIONA_WEB_ADDR"
ENV_WEB_PORT: Final[str] = "DIONA_WEB_PORT"
