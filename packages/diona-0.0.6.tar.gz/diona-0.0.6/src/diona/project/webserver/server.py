"""FastAPI WebServer for command execution"""

import os
import uvicorn
import asyncio
from concurrent.futures import ThreadPoolExecutor
from fastapi import FastAPI
from fastapi.responses import StreamingResponse

from .constants import DEFAULT_WEB_ADDR, DEFAULT_WEB_PORT, ENV_WEB_ADDR, ENV_WEB_PORT
from .models import CommandRequest, CommandResponse
from diona.project.encrypt import get_crypto_manager
from diona.project.cli.core.executor_core import get_executor_core
from diona.project.cli.core.models import StreamChunk


app = FastAPI(title="Diona WebServer", version="1.0.0")

_executor_core = None
_executor = ThreadPoolExecutor(max_workers=1)


def _get_executor_core():
    """Get or create executor core"""
    global _executor_core
    if _executor_core is None:
        _executor_core = get_executor_core()
    return _executor_core


@app.on_event("startup")
async def startup_event():
    """Initialize executor core"""
    _get_executor_core()


@app.get("/")
async def root():
    """Root endpoint"""
    return {"message": "Diona WebServer is running", "version": "1.0.0"}


@app.get("/health")
async def health():
    """Health check endpoint"""
    return {"status": "healthy", "registry_loaded": True}


@app.post("/execute", response_model=CommandResponse)
async def execute_command(request: CommandRequest):
    """Execute a command and return the result"""
    crypto = get_crypto_manager()
    executor = _get_executor_core()

    if not request.command or not request.command.strip():
        return CommandResponse(
            success=False,
            return_code=-1,
            stdout="",
            stderr="",
            error_message="Empty command"
        )

    command = request.command.strip()

    try:
        decrypted_command = crypto.decrypt(command)
    except Exception:
        decrypted_command = command

    stdout = ""
    stderr = ""
    success = True
    return_code = 0

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        async for chunk in executor.execute(decrypted_command):
            if chunk.is_error:
                stderr += chunk.content
                success = False
            else:
                stdout += chunk.content
    except Exception as e:
        stderr += str(e)
        success = False
    finally:
        loop.close()

    return CommandResponse(
        success=success,
        return_code=return_code,
        stdout=stdout,
        stderr=stderr,
        error_message=None
    )


@app.post("/execute/stream")
async def execute_command_stream(request: CommandRequest):
    """Execute a command and stream the result in real-time"""
    crypto = get_crypto_manager()
    executor = _get_executor_core()

    if not request.command or not request.command.strip():
        return CommandResponse(
            success=False,
            return_code=-1,
            stdout="",
            stderr="",
            error_message="Empty command"
        )

    command = request.command.strip()

    try:
        decrypted_command = crypto.decrypt(command)
    except Exception:
        decrypted_command = command

    async def generate():
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            async for chunk in executor.execute(decrypted_command):
                if chunk.is_error:
                    encrypted = crypto.encrypt(chunk.content)
                    yield f"error: {encrypted}\n\n"
                else:
                    encrypted = crypto.encrypt(chunk.content)
                    yield f"data: {encrypted}\n\n"

                if chunk.is_final:
                    yield f"done: returncode={chunk.return_code}\n\n"

        except Exception as e:
            encrypted = crypto.encrypt(str(e))
            yield f"error: {encrypted}\n\n"
        finally:
            loop.close()

    return StreamingResponse(generate(), media_type="text/event-stream")


def get_web_addr() -> str:
    """Get web server address from environment or use default"""
    return os.environ.get(ENV_WEB_ADDR, DEFAULT_WEB_ADDR)


def get_web_port() -> int:
    """Get web server port from environment or use default"""
    port_str = os.environ.get(ENV_WEB_PORT, str(DEFAULT_WEB_PORT))
    try:
        return int(port_str)
    except ValueError:
        return DEFAULT_WEB_PORT


def run_webserver():
    """Run the web server"""
    addr = get_web_addr()
    port = get_web_port()

    print(f"Starting Diona WebServer at http://{addr}:{port}")
    uvicorn.run(app, host=addr, port=port)


if __name__ == "__main__":
    run_webserver()
