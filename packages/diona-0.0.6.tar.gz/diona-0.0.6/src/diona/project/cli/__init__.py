"""CLI module"""

from diona.project.cli.core.core import CLI

__all__ = ["CLI"]
