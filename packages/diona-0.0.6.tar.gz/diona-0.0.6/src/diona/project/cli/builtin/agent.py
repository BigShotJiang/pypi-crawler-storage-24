"""Agent command for starting agent conversation mode"""

from .base import BuiltinCommand
from diona.project.cli.core.mode import get_mode_manager


class AgentCommand(BuiltinCommand):
    """Agent command to start agent conversation mode"""
    name = "agent"
    description = "Start agent conversation mode"

    def execute(self, args):
        """Execute agent command

        Args:
            args: Command arguments
        """
        mode_mgr = get_mode_manager()
        success = mode_mgr.set_mode("agent")
        if success:
            return False
        else:
            print("Failed to activate agent mode")
            return False


agent_command = AgentCommand()
