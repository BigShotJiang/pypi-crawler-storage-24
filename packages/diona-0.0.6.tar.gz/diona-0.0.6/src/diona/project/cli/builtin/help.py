"""Help command"""

from .base import BuiltinCommand


class HelpCommand(BuiltinCommand):
    """Help command"""
    name = "help"
    description = "Show help information"

    def execute(self, args):
        """Execute help command"""
        from diona.project.cli.executor.builtin import BuiltinExecutor

        executor = BuiltinExecutor()
        commands = executor.get_builtin_commands()

        print("Built-in Commands:")
        print("-" * 50)
        for name, cmd in sorted(commands.items()):
            desc = cmd.description if hasattr(cmd, 'description') else ""
            print(f"  /{name:<20} {desc}")
        print("-" * 50)
        print("")
        print("Mode Commands:")
        print("-" * 50)
        print(f"  $agent{'':<16} Switch to agent mode")
        print(f"  $web{'':<18} Switch to web mode")
        print(f"  $client{'':<15} Switch to client mode")
        print(f"  $exit{'':<18} Exit current mode")
        print("-" * 50)
        print("")
        print("Special Commands:")
        print("-" * 50)
        print(f"  /local <cmd>{'':<8} Execute command locally")
        print("-" * 50)

        return False


help_command = HelpCommand()
