"""Global memory command"""

from .base import BuiltinCommand
from diona.project.agent.global_memory import get_global_memory


class GlobalMemoryCommand(BuiltinCommand):
    """Global memory command"""
    name = "global-memory"
    description = "Query global memory information and list entries"
    
    def execute(self, args):
        """Execute global-memory command"""
        global_memory = get_global_memory()
        
        # Get memory statistics
        count = global_memory.get_memory_count()
        char_count = global_memory.get_memory_char_count()
        
        print(f"Global Memory Statistics:")
        print(f"- Total entries: {count}")
        print(f"- Total characters: {char_count}")
        
        if count > 0:
            print("\nGlobal Memory Entries:")
            print("-" * 60)
            
            # List all entries with pagination
            page = 1
            page_size = 10
            
            while True:
                memories = global_memory.list_memories(page, page_size)
                if not memories:
                    break
                
                for key, value in memories:
                    print(f"{key:<20} {value}")
                
                if len(memories) < page_size:
                    break
                
                page += 1
                input("\nPress Enter to see more...")
            
            print("-" * 60)
        else:
            print("\nNo global memory entries found.")
        
        return False


# Global instance
global_memory_command = GlobalMemoryCommand()
