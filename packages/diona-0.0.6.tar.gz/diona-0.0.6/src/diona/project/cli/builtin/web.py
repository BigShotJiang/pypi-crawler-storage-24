"""Web command for executing commands via webserver"""

import os
from typing import AsyncIterator

from .base import BuiltinCommand
from diona.project.webserver.constants import DEFAULT_WEB_ADDR, DEFAULT_WEB_PORT, ENV_WEB_ADDR, ENV_WEB_PORT
from diona.project.webserver.models import CommandResponse
from diona.project.encrypt import get_crypto_manager
from diona.project.cli.core.mode import get_mode_manager
from diona.project.cli.core.models import StreamChunk


class WebCommand(BuiltinCommand):
    """Web command for entering web mode"""
    name = "web"
    description = "Enter web mode to execute commands via webserver"

    def execute(self, args):
        """Execute web command - enters web mode
        
        Args:
            args: Command arguments (ignored, enters web mode)
        """
        mode_mgr = get_mode_manager()
        success = mode_mgr.set_mode("web")
        if success:
            return False
        else:
            print("Failed to activate web mode")
            return False

    async def execute_stream(self, args) -> AsyncIterator[StreamChunk]:
        """Not used for mode commands - just return empty iterator"""
        return
        yield

    def _print_help(self):
        """Print help message"""
        print("Usage: /web")
        print("Enter web mode to execute commands via the webserver")
        print("")
        print("In web mode, all input will be sent to the webserver for execution.")
        print("Type /exit to exit web mode and return to CLI.")
        print("")
        print(f"Webserver: {os.environ.get(ENV_WEB_ADDR, DEFAULT_WEB_ADDR)}:{os.environ.get(ENV_WEB_PORT, str(DEFAULT_WEB_PORT))}")


web_command = WebCommand()
