"""Echo command"""

from .base import BuiltinCommand
from diona.project.cli.core.result_storage import get_result_storage


class EchoCommand(BuiltinCommand):
    """Echo command"""
    name = "echo"
    description = "Output stored results or input text"
    
    def execute(self, args):
        """Execute echo command"""
        storage = get_result_storage()
        
        if args:
            param = args[0]
            if param == "$0":
                # Output return value
                value = storage.get_return_value()
                print(value)
            elif param == "$1":
                # Output stdout
                print(storage.get_stdout())
            elif param == "$2":
                # Output stderr
                print(storage.get_stderr())
            else:
                # Output input text
                print(" ".join(args))
        else:
            # No arguments, output nothing
            pass
        return False


# Global instance
echo_command = EchoCommand()
