"""List commands command"""

from .base import BuiltinCommand
from diona.project.command import CommandRegistry


class ListCommandsCommand(BuiltinCommand):
    """List commands command"""
    name = "list-commands"
    description = "List all registered commands"
    
    def execute(self, args):
        """Execute list-commands command"""
        registry = CommandRegistry()
        command_manager = registry.get_command_manager()
        commands = command_manager.list_commands()
        
        # Check if a command name is provided as argument
        if args and len(args) > 0:
            command_name = args[0]
            if command_name in commands:
                command = commands[command_name]
                print(f'Command: {command_name}')
                print(f'Description: {command.description}')
                print('Parameters:')
                print('-' * 60)
                if command.parameters:
                    for param in command.parameters:
                        required = ' (required)' if param.required else ''
                        default = f' (default: {param.default})' if param.default is not None else ''
                        print(f'{param.name:<20} {param.type:<10} {param.description}{required}{default}')
                else:
                    print('No parameters')
                print('-' * 60)
            else:
                print(f'Command "{command_name}" not found.')
            return False
        
        # List all commands if no specific command is requested
        if not commands:
            print('No commands registered.')
            return False
        
        print('Registered commands:')
        print('-' * 60)
        for name, command in commands.items():
            print(f'{name:<20} {command.description}')
        print('-' * 60)
        return False


# Global instance
list_commands_command = ListCommandsCommand()
