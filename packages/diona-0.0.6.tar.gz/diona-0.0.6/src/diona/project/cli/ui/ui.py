"""UI design"""

from diona.project.cli.ui.banner import BANNER


class UI:
    """UI design class"""

    @staticmethod
    def display_output(output):
        """Display output

        Args:
            output: Output to display
        """
        print(output)

    @staticmethod
    def display_error(error):
        """Display error

        Args:
            error: Error to display
        """
        print(f"[ERROR] {error}")

    @staticmethod
    def display_banner():
        """Display banner"""
        from rich.console import Console
        from rich.text import Text
        console = Console()
        banner_text = Text()
        colors = ["#fffbfe", "#fce7f3", "#fbcfe8", "#f9a8d4", "#f472b6"]
        for i, char in enumerate(BANNER):
            color_index = i % len(colors)
            banner_text.append(char, style=f"bold {colors[color_index]}")
        console.print(banner_text)
        console.print()

    @staticmethod
    def get_prompt(is_custom_mode: bool) -> str:
        """Get prompt based on mode

        Args:
            is_custom_mode: Whether in a custom mode (not default)

        Returns:
            Prompt string
        """
        if is_custom_mode:
            from diona.project.cli.core.mode import get_mode_manager
            mode_mgr = get_mode_manager()
            if mode_mgr.current_mode:
                mode_name = mode_mgr.current_mode.name
                if mode_name == "client":
                    return "\033[95m<diona@UUU>\033[0m "
                else:
                    return f"\033[95m{mode_mgr.current_mode.prompt_prefix}\033[0m"
        return "\033[95m<diona@UUU>\033[0m "
