"""Agent mode handler"""

from diona.project.cli.core.mode import ModeHandler, ModeConstants


class AgentModeHandler(ModeHandler):
    """Handler for agent mode"""

    @property
    def name(self) -> str:
        return ModeConstants.MODE_AGENT

    @property
    def prompt_prefix(self) -> str:
        return "agent:diona> "

    def on_activate(self):
        """Called when mode is activated"""
        print("Agent mode activated. All input will be processed by the agent.")
        print("Type $exit to exit agent mode and return to client mode.")

    def on_deactivate(self):
        """Called when mode is deactivated"""
        pass

    def should_exit(self, user_input: str) -> bool:
        """Check if should exit based on input"""
        if user_input.startswith("$exit"):
            return True
        return False
