"""Input parser engine"""

from diona.project.cli.core.models import ParsedInput, InputType


class InputParser:
    """Parser for user input"""
    
    def __init__(self):
        self._builtin_commands = self._get_builtin_commands()
        self._command_manager = self._get_command_manager()
    
    def _get_builtin_commands(self):
        from diona.project.cli.register import get_builtin_registry
        registry = get_builtin_registry()
        return registry.get_command_names()
    
    def _get_command_manager(self):
        from diona.project.command import CommandManager
        return CommandManager()
    
    def parse(self, raw_input: str) -> ParsedInput:
        """Parse raw input into ParsedInput
        
        Args:
            raw_input: Raw user input
            
        Returns:
            ParsedInput object
        """
        if not raw_input or not raw_input.strip():
            return ParsedInput(
                raw_input=raw_input,
                input_type=InputType.SYSTEM,
                command_name="",
                args=[],
                is_exit=False
            )
        
        parts = raw_input.strip().split()
        command = parts[0]
        args = parts[1:] if len(parts) > 1 else []
        
        if command.startswith("/"):
            command = command[1:]
            
            if command == "exit":
                return ParsedInput(
                    raw_input=raw_input,
                    input_type=InputType.BUILTIN,
                    command_name="exit",
                    args=args,
                    is_exit=True
                )
            
            if command in self._builtin_commands:
                return ParsedInput(
                    raw_input=raw_input,
                    input_type=InputType.BUILTIN,
                    command_name=command,
                    args=args
                )
            
            return ParsedInput(
                raw_input=raw_input,
                input_type=InputType.SYSTEM,
                command_name=command,
                args=args
            )
        
        if command in self._builtin_commands:
            return ParsedInput(
                raw_input=raw_input,
                input_type=InputType.BUILTIN,
                command_name=command,
                args=args
            )
        
        if self._command_manager.has_command(command):
            return ParsedInput(
                raw_input=raw_input,
                input_type=InputType.REGISTERED,
                command_name=command,
                args=args
            )
        
        return ParsedInput(
            raw_input=raw_input,
            input_type=InputType.SYSTEM,
            command_name=command,
            args=args
        )


def get_input_parser() -> InputParser:
    """Get the input parser instance"""
    global _input_parser
    if _input_parser is None:
        _input_parser = InputParser()
    return _input_parser


_input_parser = None