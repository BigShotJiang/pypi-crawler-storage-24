"""Data models for CLI execution"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Any
from enum import Enum


class InputType(Enum):
    """Input type enumeration"""
    BUILTIN = "builtin"
    REGISTERED = "registered"
    SYSTEM = "system"
    AGENT = "agent"


@dataclass
class ParsedInput:
    """Parsed input data"""
    raw_input: str
    input_type: InputType
    command_name: str
    args: list[str] = field(default_factory=list)
    is_exit: bool = False


@dataclass
class ExecutionResult:
    """Execution result data"""
    success: bool
    return_code: int = 0
    stdout: str = ""
    stderr: str = ""
    error_message: Optional[str] = None
    is_streaming: bool = False


@dataclass
class StreamChunk:
    """Streaming output chunk"""
    content: str
    is_error: bool = False
    is_final: bool = False
    return_code: Optional[int] = None