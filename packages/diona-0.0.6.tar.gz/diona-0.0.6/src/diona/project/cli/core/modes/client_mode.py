"""Client mode handler"""

import asyncio

from diona.project.cli.core.mode import ModeHandler, ModeConstants


class ClientModeHandler(ModeHandler):
    """Handler for client (default local execution) mode"""

    @property
    def name(self) -> str:
        return ModeConstants.MODE_CLIENT

    @property
    def prompt_prefix(self) -> str:
        return "client:diona> "

    def on_activate(self):
        """Called when mode is activated"""
        pass

    def on_deactivate(self):
        """Called when mode is deactivated"""
        pass

    def should_exit(self, user_input: str) -> bool:
        """Check if should exit (client mode never exits via input)"""
        return False
