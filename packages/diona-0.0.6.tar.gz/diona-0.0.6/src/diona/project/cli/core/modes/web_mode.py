"""Web mode handler"""

import os

from diona.project.cli.core.mode import ModeHandler, ModeConstants
from diona.project.webserver.constants import DEFAULT_WEB_ADDR, DEFAULT_WEB_PORT, ENV_WEB_ADDR, ENV_WEB_PORT


class WebModeHandler(ModeHandler):
    """Handler for web mode - all commands sent to remote server"""

    @property
    def name(self) -> str:
        return ModeConstants.MODE_WEB

    @property
    def prompt_prefix(self) -> str:
        return "web:diona> "

    def on_activate(self):
        """Called when mode is activated"""
        web_addr = os.environ.get(ENV_WEB_ADDR, DEFAULT_WEB_ADDR)
        web_port = os.environ.get(ENV_WEB_PORT, str(DEFAULT_WEB_PORT))
        print(f"Web mode activated. All commands will be sent to remote server at http://{web_addr}:{web_port}")
        print("Type $exit to exit web mode and return to client mode.")

    def on_deactivate(self):
        """Called when mode is deactivated"""
        pass

    def should_exit(self, user_input: str) -> bool:
        """Check if should exit based on input"""
        if user_input.startswith("$exit"):
            return True
        return False
