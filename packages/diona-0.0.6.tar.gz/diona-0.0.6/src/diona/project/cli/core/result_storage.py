"""Temporary result storage for executor results"""

from typing import Optional, Any
from dataclasses import dataclass


@dataclass
class ExecutionResultData:
    """Execution result data"""
    return_value: Any
    stdout: str
    stderr: str


class ResultStorage:
    """Singleton class for storing executor results"""
    
    _instance: Optional["ResultStorage"] = None
    
    def __new__(cls) -> "ResultStorage":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._result: Optional[ExecutionResultData] = None
        return cls._instance
    
    def set_result(self, return_value: Any, stdout: str, stderr: str) -> None:
        """Set the execution result
        
        Args:
            return_value: The return value of the command
            stdout: The standard output
            stderr: The standard error
        """
        self._result = ExecutionResultData(
            return_value=return_value,
            stdout=stdout,
            stderr=stderr
        )
    
    def get_result(self) -> Optional[ExecutionResultData]:
        """Get the execution result
        
        Returns:
            The execution result data or None if no result has been set
        """
        return self._result
    
    def get_return_value(self) -> Any:
        """Get the return value ($0)
        
        Returns:
            The return value or None if no result has been set
        """
        if self._result:
            return self._result.return_value
        return None
    
    def get_stdout(self) -> str:
        """Get the standard output ($1)
        
        Returns:
            The standard output or empty string if no result has been set
        """
        if self._result:
            return self._result.stdout
        return ""
    
    def get_stderr(self) -> str:
        """Get the standard error ($2)
        
        Returns:
            The standard error or empty string if no result has been set
        """
        if self._result:
            return self._result.stderr
        return ""


def get_result_storage() -> ResultStorage:
    """Get the result storage instance"""
    return ResultStorage()
