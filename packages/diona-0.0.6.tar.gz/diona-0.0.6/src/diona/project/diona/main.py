"""Main entry point for the diona command"""

import sys


def main():
    """Main function for the diona command"""
    args = sys.argv[1:]
    
    if "--webserver" in args or "-w" in args:
        from diona.project.webserver import server
        server.run_webserver()
        return
    
    # Start loading bar
    from diona.project.ui import get_loading_bar
    loading_bar = get_loading_bar()
    loading_bar.start()
    
    # Import and run CLI
    from diona.project.cli import CLI
    cli = CLI()
    loading_bar.stop()
    cli.run()


if __name__ == '__main__':
    main()
