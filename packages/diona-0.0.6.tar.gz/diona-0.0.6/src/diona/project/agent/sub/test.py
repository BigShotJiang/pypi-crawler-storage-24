"""Test sub-agent for demonstration"""

from diona.project.agent.sub.base import BaseSubAgent


class TestSubAgent(BaseSubAgent):
    """Test sub-agent that echoes input with a prefix"""
    
    def __init__(self):
        super().__init__(
            name="test",
            description="A test agent that echoes your input",
            instructions="You are a test agent. Simply repeat the user's input with a prefix 'Test Agent: '"
        )
    
    def execute(self, user_input: str) -> str:
        """Execute the test agent
        
        Args:
            user_input: User input
            
        Returns:
            Processed result
        """
        if not user_input:
            return "Test Agent: Hello! This is a test agent."
        return f"Test Agent: {user_input}"


def register_test_agent() -> TestSubAgent:
    """Register the test agent
    
    Returns:
        TestSubAgent instance
    """
    agent = TestSubAgent()
    agent.register()
    return agent
