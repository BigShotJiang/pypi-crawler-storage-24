"""Base class for sub-agents"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Optional

from diona.project.agent.sub_registry import get_sub_agent_registry


class BaseSubAgent(ABC):
    """Base class for sub-agents"""
    
    def __init__(
        self,
        name: str,
        description: str,
        instructions: str,
        metadata: Optional[dict] = None
    ):
        """Initialize sub-agent
        
        Args:
            name: Agent name (unique identifier)
            description: Brief description of what the agent does
            instructions: Detailed instructions for the agent
            metadata: Additional metadata
        """
        self._name = name
        self._description = description
        self._instructions = instructions
        self._metadata = metadata or {}
        self._registry = get_sub_agent_registry()
    
    @property
    def name(self) -> str:
        """Get agent name"""
        return self._name
    
    @property
    def description(self) -> str:
        """Get agent description"""
        return self._description
    
    @property
    def instructions(self) -> str:
        """Get agent instructions"""
        return self._instructions
    
    @property
    def metadata(self) -> dict:
        """Get agent metadata"""
        return self._metadata
    
    @abstractmethod
    def execute(self, user_input: str) -> str:
        """Execute the agent with user input
        
        Args:
            user_input: Input from user
            
        Returns:
            Agent response
        """
        pass
    
    def register(self) -> None:
        """Register this agent to the registry"""
        self._registry.register(
            name=self._name,
            description=self._description,
            instructions=self._instructions,
            callable=self.execute,
            metadata=self._metadata
        )
    
    def unregister(self) -> bool:
        """Unregister this agent from the registry
        
        Returns:
            True if successfully unregistered
        """
        return self._registry.unregister(self._name)
