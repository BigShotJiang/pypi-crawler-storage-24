"""Handoff agent registry for managing available handoff agents"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Optional
from agents import Agent
from diona.project.agent.model import BaseModelProvider


@dataclass
class HandoffAgentInfo:
    """Information about a registered handoff agent"""
    name: str
    description: str
    create_func: Callable[[Optional[BaseModelProvider]], Agent]
    metadata: dict = field(default_factory=dict)


class HandoffAgentRegistry:
    """Singleton registry for handoff agents"""
    
    _instance: Optional[HandoffAgentRegistry] = None
    
    def __new__(cls) -> HandoffAgentRegistry:
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance
    
    def __init__(self):
        if self._initialized:
            return
        self._agents: dict[str, HandoffAgentInfo] = {}
        self._initialized = True
    
    def register(
        self,
        name: str,
        description: str,
        create_func: Callable[[Optional[BaseModelProvider]], Agent],
        metadata: Optional[dict] = None
    ) -> None:
        """Register a handoff agent
        
        Args:
            name: Agent name (unique identifier)
            description: Brief description of what the agent does
            create_func: Function to create the agent instance
            metadata: Additional metadata
        """
        self._agents[name] = HandoffAgentInfo(
            name=name,
            description=description,
            create_func=create_func,
            metadata=metadata or {}
        )
    
    def unregister(self, name: str) -> bool:
        """Unregister a handoff agent
        
        Args:
            name: Agent name
            
        Returns:
            True if agent was removed, False if not found
        """
        if name in self._agents:
            del self._agents[name]
            return True
        return False
    
    def get(self, name: str) -> Optional[HandoffAgentInfo]:
        """Get a handoff agent by name
        
        Args:
            name: Agent name
            
        Returns:
            HandoffAgentInfo or None if not found
        """
        return self._agents.get(name)
    
    def list_all(self) -> list[HandoffAgentInfo]:
        """List all registered handoff agents
        
        Returns:
            List of all registered handoff agents
        """
        return list(self._agents.values())
    
    def get_descriptions(self) -> list[dict[str, str]]:
        """Get descriptions for all registered handoff agents
        
        Returns:
            List of agent descriptions with name and description
        """
        return [
            {"name": agent.name, "description": agent.description}
            for agent in self._agents.values()
        ]
    
    def clear(self) -> None:
        """Clear all registered handoff agents"""
        self._agents.clear()


def get_handoff_agent_registry() -> HandoffAgentRegistry:
    """Get the singleton instance of HandoffAgentRegistry
    
    Returns:
        HandoffAgentRegistry instance
    """
    return HandoffAgentRegistry()
