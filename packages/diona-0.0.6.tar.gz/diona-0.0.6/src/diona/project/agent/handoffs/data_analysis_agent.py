"""Data analysis agent for SQLite and command-line data"""

from agents import Agent
from diona.project.agent.model import BaseModelProvider
from diona.project.agent.tools import sqlite_tool, global_memory_tool


class DataAnalysisAgent:
    """Data analysis agent that specializes in analyzing data from SQLite databases and command-line input"""
    
    @staticmethod
    def create_agent(model_provider: BaseModelProvider = None) -> Agent:
        """Create data analysis agent
        
        Args:
            model_provider: Model provider for the agent
            
        Returns:
            Data analysis agent
        """
        model_provider = model_provider or BaseModelProvider.get_default()
        
        try:
            model = model_provider.get_model(None)
        except Exception as e:
            raise ValueError(f"Failed to get model: {e}. Check API key and base URL configuration.")
        
        instructions = """
        You are a professional data analyst with expertise in SQL and data analysis. Your role is to help users analyze data from SQLite databases and command-line input.
        
        Your responsibilities include:
        1. Analyzing data from SQLite databases using SQL queries
        2. Analyzing data provided directly through command-line input
        3. Providing insights and recommendations based on data analysis
        4. Visualizing data when appropriate
        5. Explaining complex data concepts in a clear and understandable way
        
        When analyzing data from SQLite databases:
        - Use the sqlite_tool to execute SQL queries
        - Understand the database schema before writing queries
        - Write efficient and optimized SQL queries
        - Handle large datasets appropriately
        - Validate data quality and identify potential issues
        
        When analyzing data from command-line input:
        - Parse and understand the data format
        - Clean and preprocess the data if necessary
        - Apply appropriate statistical methods
        - Identify patterns and trends
        
        You can use the global_memory_tool to:
        - Store important analysis results for future reference
        - Retrieve previously analyzed data
        - Track analysis history
        
        Your analysis should include:
        - Summary statistics
        - Key insights
        - Data visualizations (described in text form)
        - Recommendations based on findings
        - Potential limitations of the analysis
        
        Always present your findings in a clear, structured manner, and be prepared to explain your analysis methodology.
        """
        
        agent = Agent(
            name="DataAnalysisAgent",
            instructions=instructions,
            tools=[sqlite_tool, global_memory_tool],
            model=model,
            handoff_description="Analyzes data from SQLite databases and command-line input"
        )
        
        return agent


def get_data_analysis_agent(model_provider: BaseModelProvider = None) -> Agent:
    """Get data analysis agent
    
    Args:
        model_provider: Model provider for the agent
        
    Returns:
        Data analysis agent
    """
    return DataAnalysisAgent.create_agent(model_provider)
