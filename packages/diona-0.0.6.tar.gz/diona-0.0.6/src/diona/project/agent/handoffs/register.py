"""Register handoff agents"""

from diona.project.agent import get_handoff_agent_registry
from .learning_agent import get_learning_agent
from .data_analysis_agent import get_data_analysis_agent


def register_handoff_agents():
    """Register all handoff agents"""
    registry = get_handoff_agent_registry()
    
    # Register learning agent
    registry.register(
        name="learning",
        description="Helps users learn through Socratic questioning method",
        create_func=get_learning_agent
    )
    
    # Register data analysis agent
    registry.register(
        name="data_analysis",
        description="Analyzes data from SQLite databases and command-line input",
        create_func=get_data_analysis_agent
    )


# Register handoff agents when module is imported
register_handoff_agents()
