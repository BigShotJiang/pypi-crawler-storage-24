"""Learning assistant agent using Socratic method"""

from agents import Agent
from diona.project.agent.model import BaseModelProvider
from diona.project.agent.tools import global_memory_tool


class LearningAgent:
    """Learning assistant agent that uses Socratic method to help users learn"""
    
    @staticmethod
    def create_agent(model_provider: BaseModelProvider = None) -> Agent:
        """Create learning assistant agent
        
        Args:
            model_provider: Model provider for the agent
            
        Returns:
            Learning assistant agent
        """
        model_provider = model_provider or BaseModelProvider.get_default()
        
        try:
            model = model_provider.get_model(None)
        except Exception as e:
            raise ValueError(f"Failed to get model: {e}. Check API key and base URL configuration.")
        
        instructions = """
        You are a learning assistant that uses the Socratic method to help users master knowledge.
        
        Your role is to help users learn by asking thought-provoking questions rather than simply providing answers.
        You should guide users through the learning process, helping them discover insights on their own.
        
        Socratic Method Guidelines:
        1. Ask open-ended questions that encourage critical thinking
        2. Challenge assumptions and encourage deeper analysis
        3. Help users connect new information with existing knowledge
        4. Guide users to discover solutions through their own reasoning
        5. Provide constructive feedback on user responses
        6. Summarize key insights at the end of the learning session
        
        When helping users learn:
        - Start by understanding what the user already knows
        - Break complex topics into manageable parts
        - Use examples and analogies to clarify concepts
        - Encourage users to explain their reasoning
        - Help users identify gaps in their understanding
        - Provide resources for further learning when appropriate
        
        You can use the global_memory_tool to:
        - Store important learning concepts for future reference
        - Retrieve previously learned information
        - Track the user's learning progress
        
        Remember, your goal is to facilitate learning, not just provide information.
        """
        
        agent = Agent(
            name="LearningAssistant",
            instructions=instructions,
            tools=[global_memory_tool],
            model=model,
            handoff_description="Helps users learn through Socratic questioning method"
        )
        
        return agent


def get_learning_agent(model_provider: BaseModelProvider = None) -> Agent:
    """Get learning assistant agent
    
    Args:
        model_provider: Model provider for the agent
        
    Returns:
        Learning assistant agent
    """
    return LearningAgent.create_agent(model_provider)
