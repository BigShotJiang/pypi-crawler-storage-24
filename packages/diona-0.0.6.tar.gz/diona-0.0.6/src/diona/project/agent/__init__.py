"""Agent module"""

from .model import BaseModelProvider, SubModelProvider
from .sub_registry import SubAgentRegistry, get_sub_agent_registry
from .handoff_registry import HandoffAgentRegistry, get_handoff_agent_registry
from .core import CoreAgent, get_core_agent
from .session import AgentSessionManager, get_session_manager
from .handoffs import get_learning_agent, get_data_analysis_agent

__all__ = [
    "BaseModelProvider",
    "SubModelProvider",
    "SubAgentRegistry",
    "get_sub_agent_registry",
    "HandoffAgentRegistry",
    "get_handoff_agent_registry",
    "CoreAgent",
    "get_core_agent",
    "AgentSessionManager",
    "get_session_manager",
    "get_learning_agent",
    "get_data_analysis_agent",
]
