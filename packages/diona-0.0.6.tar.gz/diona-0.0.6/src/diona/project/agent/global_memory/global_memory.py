"""Global memory implementation"""

import os
import sqlite3
from typing import Optional, Dict, List, Tuple
from diona.project.storage import get_storage_instance


class GlobalMemory:
    """Singleton global memory class"""

    _instance: Optional["GlobalMemory"] = None

    def __new__(cls) -> "GlobalMemory":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return
        
        self._storage = get_storage_instance()
        self._db_path = self._storage.get_path("agent", "global.db", storage_type="user")
        self._cache: Dict[str, str] = {}
        self._initialize_db()
        self._load_from_db()
        self._initialized = True

    def _initialize_db(self):
        """Initialize the database"""
        conn = sqlite3.connect(self._db_path)
        cursor = conn.cursor()
        
        # Create table if it doesn't exist
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS global_memory (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            key TEXT UNIQUE NOT NULL,
            value TEXT NOT NULL
        )
        ''')
        
        conn.commit()
        conn.close()

    def _load_from_db(self):
        """Load global memory from database into cache"""
        conn = sqlite3.connect(self._db_path)
        cursor = conn.cursor()
        
        cursor.execute('SELECT key, value FROM global_memory')
        rows = cursor.fetchall()
        
        for key, value in rows:
            self._cache[key] = value
        
        conn.close()

    def add_memory(self, key: str, value: str) -> bool:
        """Add or update a global memory

        Args:
            key: Memory key
            value: Memory value

        Returns:
            True if successful, False otherwise
        """
        try:
            conn = sqlite3.connect(self._db_path)
            cursor = conn.cursor()
            
            # Insert or update
            cursor.execute('''
            INSERT OR REPLACE INTO global_memory (key, value) 
            VALUES (?, ?)
            ''', (key, value))
            
            conn.commit()
            conn.close()
            
            # Update cache
            self._cache[key] = value
            return True
        except Exception:
            return False

    def delete_memory(self, key: str) -> bool:
        """Delete a global memory

        Args:
            key: Memory key

        Returns:
            True if successful, False otherwise
        """
        try:
            conn = sqlite3.connect(self._db_path)
            cursor = conn.cursor()
            
            cursor.execute('DELETE FROM global_memory WHERE key = ?', (key,))
            conn.commit()
            conn.close()
            
            # Update cache
            if key in self._cache:
                del self._cache[key]
            return True
        except Exception:
            return False

    def get_memory(self, key: str) -> Optional[str]:
        """Get a global memory

        Args:
            key: Memory key

        Returns:
            Memory value or None if not found
        """
        return self._cache.get(key)

    def list_memories(self, page: int = 1, page_size: int = 10) -> List[Tuple[str, str]]:
        """List all global memories with pagination

        Args:
            page: Page number (starting from 1)
            page_size: Number of items per page

        Returns:
            List of (key, value) tuples
        """
        offset = (page - 1) * page_size
        
        conn = sqlite3.connect(self._db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
        SELECT key, value FROM global_memory 
        ORDER BY id DESC 
        LIMIT ? OFFSET ?
        ''', (page_size, offset))
        
        rows = cursor.fetchall()
        conn.close()
        
        return rows

    def get_memory_count(self) -> int:
        """Get the number of global memory entries

        Returns:
            Number of entries
        """
        return len(self._cache)

    def get_memory_char_count(self) -> int:
        """Get the total character count of all global memories

        Returns:
            Total character count
        """
        return sum(len(key) + len(value) for key, value in self._cache.items())


def get_global_memory() -> GlobalMemory:
    """Get the singleton global memory instance

    Returns:
        GlobalMemory instance
    """
    return GlobalMemory()
