"""Global memory module"""

from .global_memory import GlobalMemory, get_global_memory

__all__ = ['GlobalMemory', 'get_global_memory']
