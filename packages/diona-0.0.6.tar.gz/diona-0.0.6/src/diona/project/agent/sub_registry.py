"""Sub-agent registry for managing available sub-agents"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Optional


@dataclass
class SubAgentInfo:
    """Information about a registered sub-agent"""
    name: str
    description: str
    instructions: str
    callable: Callable[[str], str]
    metadata: dict = field(default_factory=dict)


class SubAgentRegistry:
    """Singleton registry for sub-agents"""
    
    _instance: Optional[SubAgentRegistry] = None
    
    def __new__(cls) -> SubAgentRegistry:
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance
    
    def __init__(self):
        if self._initialized:
            return
        self._agents: dict[str, SubAgentInfo] = {}
        self._initialized = True
    
    def register(
        self,
        name: str,
        description: str,
        instructions: str,
        callable: Callable[[str], str],
        metadata: Optional[dict] = None
    ) -> None:
        """Register a sub-agent
        
        Args:
            name: Agent name (unique identifier)
            description: Brief description of what the agent does
            instructions: Detailed instructions for the agent
            callable: Function to execute when agent is called
            metadata: Additional metadata
        """
        self._agents[name] = SubAgentInfo(
            name=name,
            description=description,
            instructions=instructions,
            callable=callable,
            metadata=metadata or {}
        )
    
    def unregister(self, name: str) -> bool:
        """Unregister a sub-agent
        
        Args:
            name: Agent name
            
        Returns:
            True if agent was removed, False if not found
        """
        if name in self._agents:
            del self._agents[name]
            return True
        return False
    
    def get(self, name: str) -> Optional[SubAgentInfo]:
        """Get a sub-agent by name
        
        Args:
            name: Agent name
            
        Returns:
            SubAgentInfo or None if not found
        """
        return self._agents.get(name)
    
    def list_all(self) -> list[SubAgentInfo]:
        """List all registered sub-agents
        
        Returns:
            List of all registered sub-agents
        """
        return list(self._agents.values())
    
    def get_descriptions(self) -> list[dict[str, str]]:
        """Get descriptions for all registered agents (for core agent)
        
        Returns:
            List of agent descriptions with name and description
        """
        return [
            {"name": agent.name, "description": agent.description}
            for agent in self._agents.values()
        ]
    
    def clear(self) -> None:
        """Clear all registered agents"""
        self._agents.clear()


def get_sub_agent_registry() -> SubAgentRegistry:
    """Get the singleton instance of SubAgentRegistry
    
    Returns:
        SubAgentRegistry instance
    """
    return SubAgentRegistry()
