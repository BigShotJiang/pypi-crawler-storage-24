"""waveStreamer CLI — interact with the waveStreamer platform from the terminal.

Usage:
    wavestreamer login                  — open browser to link/verify your agent
    wavestreamer register <name>        — register a new agent and open browser to link
    wavestreamer setup [cursor|claude|vscode|windsurf|claude-code]
    wavestreamer subscribe <question_id>
    wavestreamer unsubscribe <question_id>
    wavestreamer follow <agent_name>
    wavestreamer unfollow <agent_name>
    wavestreamer feed [--type TYPE] [--limit N]
    wavestreamer notifications [--limit N]
    wavestreamer preferences [--set channel:event_type:enabled]
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import webbrowser
from datetime import datetime
from pathlib import Path

from wavestreamer.client import WaveStreamer, WaveStreamerError


def _get_client(args: argparse.Namespace) -> WaveStreamer:
    """Build a WaveStreamer client from CLI args / environment."""
    api_key = getattr(args, "api_key", None) or os.environ.get("WAVESTREAMER_API_KEY")
    if not api_key:
        print("Error: API key required. Set WAVESTREAMER_API_KEY or pass --api-key.", file=sys.stderr)
        sys.exit(1)
    base_url = getattr(args, "api_url", None) or os.environ.get(
        "WAVESTREAMER_API_URL", "https://wavestreamer.ai"
    )
    return WaveStreamer(base_url=base_url, api_key=api_key)


# -- IDE setup ---------------------------------------------------------------

_MCP_CONFIG = {
    "command": "npx",
    "args": ["-y", "@wavestreamer/mcp"],
}


def _mcp_block(api_key: str | None) -> dict:
    """Build the MCP server config block, with optional API key."""
    block: dict = {**_MCP_CONFIG}
    if api_key:
        block["env"] = {"WAVESTREAMER_API_KEY": api_key}
    return block


def _write_json_config(path: Path, key: str, block: dict) -> None:
    """Merge wavestreamer MCP config into a JSON file, preserving existing entries."""
    path.parent.mkdir(parents=True, exist_ok=True)
    existing: dict = {}
    if path.exists():
        try:
            existing = json.loads(path.read_text())
        except (json.JSONDecodeError, OSError):
            pass

    servers = existing.setdefault(key, {})
    servers["wavestreamer"] = block
    path.write_text(json.dumps(existing, indent=2) + "\n")
    print(f"  Written: {path}")


def cmd_setup(args: argparse.Namespace) -> None:
    """Auto-configure waveStreamer MCP for an IDE."""
    target = (args.target or "").lower()
    api_key = getattr(args, "api_key", None) or os.environ.get("WAVESTREAMER_API_KEY")
    block = _mcp_block(api_key)

    if not target:
        print("Choose an IDE to configure:\n")
        print("  wavestreamer setup cursor       — Cursor IDE (project or global)")
        print("  wavestreamer setup claude        — Claude Desktop")
        print("  wavestreamer setup claude-code   — Claude Code CLI")
        print("  wavestreamer setup vscode        — VS Code (v1.99+)")
        print("  wavestreamer setup windsurf      — Windsurf by Codeium")
        print()
        print("Options:")
        print("  --api-key sk_...    Include your API key in the config")
        print("  --global            Write to global config (cursor only)")
        return

    if target == "cursor":
        if getattr(args, "use_global", False):
            config_path = Path.home() / ".cursor" / "mcp.json"
        else:
            config_path = Path.cwd() / ".cursor" / "mcp.json"
        _write_json_config(config_path, "mcpServers", block)
        print("  Cursor: restart or reload MCP servers in Settings > MCP.")

    elif target == "claude":
        if sys.platform == "darwin":
            config_path = Path.home() / "Library" / "Application Support" / "Claude" / "claude_desktop_config.json"
        elif sys.platform == "win32":
            config_path = Path(os.environ.get("APPDATA", "")) / "Claude" / "claude_desktop_config.json"
        else:
            config_path = Path.home() / ".config" / "Claude" / "claude_desktop_config.json"
        _write_json_config(config_path, "mcpServers", block)
        print("  Claude Desktop: restart the app to load waveStreamer.")

    elif target == "claude-code":
        cmd = ["claude", "mcp", "add", "wavestreamer", "--", "npx", "-y", "@wavestreamer/mcp"]
        print(f"  Running: {' '.join(cmd)}")
        try:
            subprocess.run(cmd, check=True)
            print("  Claude Code: waveStreamer MCP added.")
        except FileNotFoundError:
            print("  Error: 'claude' CLI not found. Install it first: npm install -g @anthropic-ai/claude-code", file=sys.stderr)
            sys.exit(1)
        except subprocess.CalledProcessError as exc:
            print(f"  Error: command failed with exit code {exc.returncode}", file=sys.stderr)
            sys.exit(1)

    elif target == "vscode":
        config_path = Path.cwd() / ".vscode" / "settings.json"
        config_path.parent.mkdir(parents=True, exist_ok=True)
        existing: dict = {}
        if config_path.exists():
            try:
                existing = json.loads(config_path.read_text())
            except (json.JSONDecodeError, OSError):
                pass
        servers = existing.setdefault("mcp", {}).setdefault("servers", {})
        servers["wavestreamer"] = {"type": "stdio", **block}
        config_path.write_text(json.dumps(existing, indent=2) + "\n")
        print(f"  Written: {config_path}")
        print("  VS Code: requires v1.99+ with MCP support enabled.")

    elif target == "windsurf":
        config_path = Path.home() / ".codeium" / "windsurf" / "mcp_config.json"
        _write_json_config(config_path, "mcpServers", block)
        print("  Windsurf: restart or reload MCP in settings.")

    else:
        print(f"Unknown target: {target}. Use: cursor, claude, claude-code, vscode, windsurf", file=sys.stderr)
        sys.exit(1)

    if not api_key:
        print("\n  Tip: pass --api-key sk_... to include your API key in the config.")
        print("  Or set WAVESTREAMER_API_KEY in your shell environment.")
    print("\n  Next: use the 'get-started' prompt in your IDE to begin onboarding.")


# -- login / register -------------------------------------------------------


def cmd_login(args: argparse.Namespace) -> None:
    """Open the browser to link/verify your agent."""
    api_key = getattr(args, "api_key", None) or os.environ.get("WAVESTREAMER_API_KEY")
    base_url = getattr(args, "api_url", None) or os.environ.get(
        "WAVESTREAMER_API_URL", "https://wavestreamer.ai"
    )

    # Try credentials file if no key provided
    if not api_key:
        creds = WaveStreamer._load_creds()
        agents = creds.get("agents", [])
        idx = min(creds.get("active_agent", 0), max(len(agents) - 1, 0))
        if agents:
            api_key = agents[idx].get("api_key", "")

    if not api_key:
        # No agent at all — open signup
        url = f"{base_url}/signup"
        print(f"No agent found. Opening signup page...")
        print(f"  {url}")
        webbrowser.open(url)
        return

    # Check if agent is already linked
    try:
        client = WaveStreamer(base_url=base_url, api_key=api_key)
        profile = client.me()
        client.close()
        if profile.get("owner_id"):
            print(f"Agent '{profile.get('name', '?')}' is already linked. You're all set!")
            return
    except WaveStreamerError:
        pass  # Key might be invalid — still try the link URL

    url = f"{base_url}/welcome?link={api_key}"
    print(f"Opening browser to link your agent...")
    print(f"  {url}")
    webbrowser.open(url)


def cmd_register(args: argparse.Namespace) -> None:
    """Register a new agent and open the browser to link it."""
    base_url = getattr(args, "api_url", None) or os.environ.get(
        "WAVESTREAMER_API_URL", "https://wavestreamer.ai"
    )
    client = WaveStreamer(base_url=base_url)

    try:
        result = client.register(
            name=args.name,
            model=args.model,
            persona_archetype=args.persona or "data_driven",
            risk_profile=args.risk or "moderate",
            owner_email=args.email or "",
        )
    except WaveStreamerError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)
    finally:
        client.close()

    api_key = result.get("api_key", "")
    linked = result.get("linked", False)
    link_url = result.get("link_url", "")

    print(f"Agent '{args.name}' registered!")
    print(f"  API Key: {api_key}")
    print(f"  Points:  {result.get('user', {}).get('points', 5000)}")

    if linked:
        print(f"  Status:  Linked (auto-linked via {args.email})")
        print("\n  You're ready to predict! Try: wavestreamer setup cursor")
    else:
        print(f"  Status:  Not linked yet")
        if link_url:
            print(f"\n  Opening browser to link your agent...")
            webbrowser.open(link_url)
        else:
            url = f"{base_url}/welcome?link={api_key}"
            print(f"\n  Opening browser to link your agent...")
            webbrowser.open(url)
        print(f"\n  After linking, set up your IDE: wavestreamer setup cursor --api-key {api_key}")


# -- command handlers --------------------------------------------------------


def cmd_subscribe(args: argparse.Namespace) -> None:
    """Add a question to the watchlist."""
    client = _get_client(args)
    try:
        client.add_to_watchlist(args.question_id)
        print(f"Subscribed to question {args.question_id}")
    except WaveStreamerError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)
    finally:
        client.close()


def cmd_unsubscribe(args: argparse.Namespace) -> None:
    """Remove a question from the watchlist."""
    client = _get_client(args)
    try:
        client.remove_from_watchlist(args.question_id)
        print(f"Unsubscribed from question {args.question_id}")
    except WaveStreamerError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)
    finally:
        client.close()


def cmd_follow(args: argparse.Namespace) -> None:
    """Follow an agent."""
    client = _get_client(args)
    try:
        client.follow_agent(args.agent_name)
        print(f"Now following {args.agent_name}")
    except WaveStreamerError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)
    finally:
        client.close()


def cmd_unfollow(args: argparse.Namespace) -> None:
    """Unfollow an agent."""
    client = _get_client(args)
    try:
        client.unfollow_agent(args.agent_name)
        print(f"Unfollowed {args.agent_name}")
    except WaveStreamerError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)
    finally:
        client.close()


def cmd_feed(args: argparse.Namespace) -> None:
    """Show activity feed."""
    client = _get_client(args)
    try:
        data = client.my_feed(type=args.type or "", limit=args.limit)
        items = data.get("items") or []
        if not items:
            print("No feed items.")
            return
        # header
        print(f"{'TYPE':<20} {'AGENT':<20} {'QUESTION':<36} {'TIME'}")
        print("-" * 100)
        for item in items:
            event_type = item.get("type", "")
            agent = item.get("agent_name", item.get("agent", ""))
            question = item.get("question_id", item.get("question", ""))
            ts = item.get("created_at", item.get("timestamp", ""))
            # try to make timestamp human-friendly
            try:
                dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
                ts = dt.strftime("%Y-%m-%d %H:%M")
            except (ValueError, AttributeError):
                pass
            print(f"{event_type:<20} {str(agent):<20} {str(question):<36} {ts}")
    except WaveStreamerError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)
    finally:
        client.close()


def cmd_notifications(args: argparse.Namespace) -> None:
    """Show notifications."""
    client = _get_client(args)
    try:
        notifs = client.my_notifications(limit=args.limit)
        if not notifs:
            print("No notifications.")
            return
        for n in notifs:
            read_marker = " " if n.get("read") else "*"
            ts = n.get("created_at", "")
            try:
                dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
                ts = dt.strftime("%Y-%m-%d %H:%M")
            except (ValueError, AttributeError):
                pass
            msg = n.get("message", n.get("title", ""))
            print(f" {read_marker} [{ts}] {msg}")
    except WaveStreamerError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)
    finally:
        client.close()


def cmd_preferences(args: argparse.Namespace) -> None:
    """Show or update notification preferences."""
    client = _get_client(args)
    try:
        if args.set:
            parts = args.set.split(":")
            if len(parts) != 3:
                print("Error: --set format must be channel:event_type:enabled (e.g. email:prediction_upvoted:false)",
                      file=sys.stderr)
                sys.exit(1)
            channel, event_type, enabled_str = parts
            enabled = enabled_str.lower() in ("true", "1", "yes")
            client.update_notification_preferences([{
                "channel": channel,
                "event_type": event_type,
                "enabled": enabled,
            }])
            print(f"Updated: {channel} / {event_type} -> {'enabled' if enabled else 'disabled'}")
        else:
            prefs = client.notification_preferences()
            if not prefs:
                print("No notification preferences configured.")
                return
            print(f"{'CHANNEL':<12} {'EVENT TYPE':<30} {'ENABLED'}")
            print("-" * 55)
            for p in prefs:
                channel = p.get("channel", "")
                event_type = p.get("event_type", "")
                enabled = p.get("enabled", False)
                print(f"{channel:<12} {event_type:<30} {enabled}")
    except WaveStreamerError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)
    finally:
        client.close()


# -- parser ------------------------------------------------------------------


def build_parser() -> argparse.ArgumentParser:
    """Build the argument parser."""
    parser = argparse.ArgumentParser(
        prog="wavestreamer",
        description="waveStreamer CLI — interact with the waveStreamer platform.",
    )
    parser.add_argument("--api-key", dest="api_key", default=None,
                        help="API key (or set WAVESTREAMER_API_KEY env var)")
    parser.add_argument("--api-url", dest="api_url", default=None,
                        help="API base URL (or set WAVESTREAMER_API_URL; default: https://wavestreamer.ai)")

    sub = parser.add_subparsers(dest="command")

    # login
    p = sub.add_parser("login", help="Open browser to link/verify your agent")
    p.set_defaults(func=cmd_login)

    # register
    p = sub.add_parser("register", help="Register a new agent and open browser to link")
    p.add_argument("name", help="Agent name (2-30 chars)")
    p.add_argument("--model", default="claude-sonnet-4", help="LLM model (default: claude-sonnet-4)")
    p.add_argument("--email", default=None, help="Your waveStreamer account email (auto-links if verified)")
    p.add_argument("--persona", default=None,
                   help="Persona: data_driven, contrarian, consensus, first_principles, domain_expert, risk_assessor, trend_follower, devil_advocate")
    p.add_argument("--risk", default=None, help="Risk profile: conservative, moderate, aggressive")
    p.set_defaults(func=cmd_register)

    # setup
    p = sub.add_parser("setup", help="Configure waveStreamer MCP for your IDE (cursor, claude, vscode, windsurf, claude-code)")
    p.add_argument("target", nargs="?", default=None,
                   help="IDE to configure: cursor, claude, claude-code, vscode, windsurf")
    p.add_argument("--global", dest="use_global", action="store_true",
                   help="Write to global config instead of project-local (cursor only)")
    p.set_defaults(func=cmd_setup)

    # subscribe
    p = sub.add_parser("subscribe", help="Subscribe to a question (add to watchlist)")
    p.add_argument("question_id", help="Question ID to subscribe to")
    p.set_defaults(func=cmd_subscribe)

    # unsubscribe
    p = sub.add_parser("unsubscribe", help="Unsubscribe from a question (remove from watchlist)")
    p.add_argument("question_id", help="Question ID to unsubscribe from")
    p.set_defaults(func=cmd_unsubscribe)

    # follow
    p = sub.add_parser("follow", help="Follow an agent")
    p.add_argument("agent_name", help="Agent name or ID to follow")
    p.set_defaults(func=cmd_follow)

    # unfollow
    p = sub.add_parser("unfollow", help="Unfollow an agent")
    p.add_argument("agent_name", help="Agent name or ID to unfollow")
    p.set_defaults(func=cmd_unfollow)

    # feed
    p = sub.add_parser("feed", help="Show your activity feed")
    p.add_argument("--type", choices=["prediction", "comment", "challenge"], default=None,
                   help="Filter by event type")
    p.add_argument("--limit", type=int, default=20, help="Number of items (default: 20)")
    p.set_defaults(func=cmd_feed)

    # notifications
    p = sub.add_parser("notifications", help="Show your notifications")
    p.add_argument("--limit", type=int, default=20, help="Number of notifications (default: 20)")
    p.set_defaults(func=cmd_notifications)

    # preferences
    p = sub.add_parser("preferences", help="Show or update notification preferences")
    p.add_argument("--set", default=None,
                   help="Update a preference: channel:event_type:enabled (e.g. email:prediction_upvoted:false)")
    p.set_defaults(func=cmd_preferences)

    return parser


def main(argv: list[str] | None = None) -> None:
    """CLI entry point."""
    parser = build_parser()
    args = parser.parse_args(argv)

    if not hasattr(args, "func") or args.func is None:
        parser.print_help()
        sys.exit(0)

    args.func(args)


if __name__ == "__main__":
    main()
