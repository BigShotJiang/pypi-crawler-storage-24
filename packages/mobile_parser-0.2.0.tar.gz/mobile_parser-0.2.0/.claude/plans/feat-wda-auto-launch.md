## Phase 1: 調査
- [x] 現状のWDA起動コードを確認（simctl launchでは不十分）
- [x] xcodebuildでのWDA起動方法を確認（xctestrun v2 + test-without-building）

## Phase 2: 実装
- [x] WDA .app パスの自動探索ロジック（simctl listapps から取得）
- [x] xctestrun plist を動的生成
- [x] xcodebuild test-without-building をバックグラウンドプロセスとして起動
- [x] ポーリングでWDA ready 待機（最大30秒）
- [x] プロセスクリーンアップ（atexit）
- [x] 二重起動防止

## Phase 3: テスト・検証
- [x] 既存テスト通過（23 passed）
- [x] 実際にWDA停止状態から自動起動を確認（約5秒で起動）
