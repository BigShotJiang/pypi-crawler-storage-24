"""Fastn Bitly connector — auto-generated type stubs.

Do not edit manually. Regenerate with `fastn connector sync`.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional, TypedDict


class BitlyConnector:
    """Bitly connector ().

    Provides 0 tools.
    """

    def __getattr__(self, name: str) -> Any: ...
