# 🤖 ClawBot — AI Browser Automation CLI

Apne browser ko AI se automate karo! Just one command:

```bash
pip install clawbot
```

Then run:

```bash
clawbot
```

## Features

- 🧠 **6 AI Providers** — Gemini, OpenAI, Claude, Groq, DeepSeek, Ollama
- 🌐 **Your Browser** — Use your own Chrome with logged-in accounts
- 🔑 **API Key Management** — Enter once, saved permanently
- 🔄 **Interactive Loop** — Keep giving tasks, switch AI anytime
- 💻 **Cross Platform** — Windows, Mac, Linux

## Quick Start

```bash
# Install
pip install clawbot

# Run
clawbot
```

That's it! ClawBot will:
1. Ask which AI to use (Gemini, ChatGPT, Claude, etc.)
2. Ask which model
3. Ask for API key (saved permanently)
4. Auto-launch Chrome
5. Wait for your tasks!

## Example Tasks

```
🤖 Task > open youtube and search for latest tech news
🤖 Task > go to amazon and find best laptop under 50k
🤖 Task > open gmail and check my latest emails
🤖 Task > search google for weather in Delhi
```

## Commands

| Command | Description |
|---------|-------------|
| `quit` | Exit ClawBot |
| `switch` | Change AI provider/model |
| `chrome` | Restart Chrome browser |

## Requirements

- Python 3.11+
- Google Chrome browser
