"""
🤖 ClawBot Telegram Bot — Remote Control via Telegram
Lets you control JARVIS Computer Agent from anywhere via Telegram.
Shows step-by-step progress + screenshots in Telegram chat.

Setup:
1. Talk to @BotFather on Telegram → /newbot → get TOKEN
2. Set environment variables:
   TELEGRAM_BOT_TOKEN=your_bot_token_here
   TELEGRAM_CHAT_ID=your_chat_id_here
   OLLAMA_BASE_URL=http://your-ollama-url:11434
3. Run: python telegram_bot.py

To get your Chat ID:
   - Send /start to your bot
   - Open https://api.telegram.org/bot<TOKEN>/getUpdates
   - Find "chat":{"id": XXXXXXXX}
"""

import os
import sys
import asyncio
import base64
import logging
import time
from io import BytesIO
from pathlib import Path
from datetime import datetime
from dotenv import load_dotenv

# Load env from ~/.clawbot/.env
env_file = Path.home() / '.clawbot' / '.env'
if env_file.exists():
    load_dotenv(env_file)

# Also load from current directory .env if exists
load_dotenv()

# Force load variables explicitly just in case
if env_file.exists():
    with open(env_file, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if line and '=' in line and not line.startswith('#'):
                k, v = line.split('=', 1)
                os.environ[k.strip()] = v.strip().strip("'").strip('"')

from telegram import Update, Bot
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes
from telegram.constants import ParseMode

# ── Setup paths ──
COMPUTER_DIR = Path(__file__).parent.parent / "computer"
if str(COMPUTER_DIR) not in sys.path:
    sys.path.insert(0, str(COMPUTER_DIR))

# ── Logging ──
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# ── Config ──
# We must load these AFTER the env_file parsing is complete.
def get_bot_token():
    return os.getenv("TELEGRAM_BOT_TOKEN", "")

def get_authorized_chat_id():
    return os.getenv("TELEGRAM_CHAT_ID", "")

# ════════════════════════════════════════════════════════
# 🤖 LLM SETUP — Same as ClawBot CLI
# ════════════════════════════════════════════════════════

def create_default_llm():
    """Create LLM instance using environment variables."""
    from browser_use.llm import ChatOllama
    
    base_url = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
    model = os.getenv("TELEGRAM_BOT_MODEL", "qwen3.5:397b-cloud")
    
    logger.info(f"🤖 LLM: {model} @ {base_url}")
    return ChatOllama(model=model, host=base_url)


# ════════════════════════════════════════════════════════
# 📨 TELEGRAM OUTPUT — Replaces console.print for Telegram
# ════════════════════════════════════════════════════════

class TelegramOutput:
    """
    Captures JARVIS agent output and sends to Telegram.
    Batches messages to avoid Telegram rate limits.
    """
    
    def __init__(self, bot: Bot, chat_id: str):
        self.bot = bot
        self.chat_id = chat_id
        self.buffer: list[str] = []
        self.last_flush = time.time()
        self.message_id = None  # For editing existing message
        self.step_count = 0
    
    async def send(self, text: str):
        """Send a message to Telegram."""
        try:
            # Clean rich markup
            clean = self._clean_markup(text)
            if not clean.strip():
                return
            
            self.buffer.append(clean)
            
            # Flush every 2 seconds or every 5 lines
            if time.time() - self.last_flush > 2 or len(self.buffer) >= 5:
                await self.flush()
        except Exception as e:
            logger.error(f"Telegram send error: {e}")
    
    async def flush(self):
        """Flush buffer to Telegram."""
        if not self.buffer:
            return
        
        text = "\n".join(self.buffer)
        self.buffer = []
        self.last_flush = time.time()
        
        try:
            # Truncate if too long (Telegram limit is 4096)
            if len(text) > 3900:
                text = text[:3900] + "\n... (truncated)"
            
            await self.bot.send_message(
                chat_id=self.chat_id,
                text=text,
                parse_mode=None  # Plain text to avoid markdown issues
            )
        except Exception as e:
            logger.error(f"Telegram flush error: {e}")
    
    async def send_photo(self, image_bytes: bytes, caption: str = ""):
        """Send a screenshot to Telegram."""
        try:
            await self.bot.send_photo(
                chat_id=self.chat_id,
                photo=image_bytes,
                caption=caption[:200] if caption else "📸 Screenshot"
            )
        except Exception as e:
            logger.error(f"Telegram photo error: {e}")
    
    def _clean_markup(self, text: str) -> str:
        """Remove Rich markup tags from text."""
        import re
        # Remove [color], [bold], [dim], etc.
        clean = re.sub(r'\[/?[a-zA-Z\s#0-9_]+\]', '', text)
        # Remove ╭╰╮╯│─ box characters
        clean = re.sub(r'[╭╰╮╯│─═]+', '', clean)
        return clean.strip()


# ════════════════════════════════════════════════════════
# 🚀 JARVIS RUNNER — Runs tasks with Telegram output
# ════════════════════════════════════════════════════════

is_task_running = False
cancel_task = False

async def run_jarvis_task(task: str, tg_output: TelegramOutput):
    """Run a JARVIS computer agent task with Telegram output."""
    from agent import run_computer_task as _original_run
    from agent import (
        load_memory, discover_apps, build_app_context, get_relevant_learnings,
        get_system_context, take_full_screenshot_b64, take_active_window_screenshot_b64,
        run_shell, _ask_llm, _parse_json, record_task, extract_file_paths,
        APP_KNOWLEDGE
    )
    from actions import reliable_click, reliable_type, smart_wait, ensure_window_focus, drag_and_drop
    from security import is_command_safe, log_action
    from system_control import (
        set_volume, mute_toggle, set_brightness, wifi_toggle, bluetooth_toggle,
        get_system_info, get_running_processes, kill_process,
        lock_screen, shutdown, restart, sleep_pc, create_file
    )
    from window_manager import (
        list_windows, focus_window, minimize_window, maximize_window,
        close_window, snap_window
    )
    import pyautogui
    
    # Setup
    llm = create_default_llm()
    sys_context = get_system_context()
    mem = load_memory()
    app_data = discover_apps()
    app_context = build_app_context(app_data)
    learnings = get_relevant_learnings(mem, task)
    
    width, height = pyautogui.size()
    memory: list[dict] = []
    needs_screenshot = False
    extra_images = extract_file_paths(task)
    task_success = False
    
    await tg_output.send(
        f"🤖 JARVIS — Task Started\n"
        f"📋 {task}\n"
        f"📱 Apps: {app_data.get('app_count', 0)} | 🧠 Memory: {len(mem.get('tasks', []))} tasks\n"
        f"🔒 Security: Active"
    )
    
    # System Prompt (same as agent.py)
    SYSTEM = f"""You are JARVIS — an intelligent AI assistant with FULL CONTROL of this Windows {width}x{height} PC.
You are precise, efficient, and never repeat failing actions.

{sys_context}

You know every app installed and how humans use them.

{app_context}

{f"MEMORY (learn from past):{chr(10)}{learnings}" if learnings else ""}

STRATEGY (follow in order of preference):
1. Direct system commands FIRST — shell, system_control actions (instant, most reliable)
2. Keyboard shortcuts next — hotkeys, Ctrl+shortcuts (fast, reliable)
3. Focus the target app BEFORE any GUI interaction
4. GUI clicks ONLY as last resort (after 1-3 fail)

ACTIONS — Return ONE JSON per step with "thought":

--- SYSTEM CONTROL ---
Shell:            {{"thought":"...", "action":"shell",            "command":"start chrome"}}
Volume:           {{"thought":"...", "action":"set_volume",       "level":50}}
Mute:             {{"thought":"...", "action":"mute_toggle"}}
Brightness:       {{"thought":"...", "action":"set_brightness",   "level":80}}
WiFi:             {{"thought":"...", "action":"wifi",             "enable":true}}
Bluetooth:        {{"thought":"...", "action":"bluetooth",        "enable":true}}
System info:      {{"thought":"...", "action":"system_info"}}
Running apps:     {{"thought":"...", "action":"list_processes"}}
Kill app:         {{"thought":"...", "action":"kill_process",     "name":"notepad"}}
Lock screen:      {{"thought":"...", "action":"lock_screen"}}
Shutdown:         {{"thought":"...", "action":"shutdown",         "delay":30}}
Restart:          {{"thought":"...", "action":"restart",          "delay":10}}
Sleep:            {{"thought":"...", "action":"sleep"}}
File create:      {{"thought":"...", "action":"create_file",      "path":"C:/test.txt", "content":"hello"}}

--- WINDOW MANAGEMENT ---
Focus app:        {{"thought":"...", "action":"focus_app",        "window_title":"WhatsApp"}}
Minimize:         {{"thought":"...", "action":"minimize_window",  "window_title":"Notepad"}}
Maximize:         {{"thought":"...", "action":"maximize_window",  "window_title":"Chrome"}}
Close window:     {{"thought":"...", "action":"close_window",     "window_title":"Calculator"}}
Snap window:      {{"thought":"...", "action":"snap_window",      "window_title":"Chrome", "position":"left"}}
List windows:     {{"thought":"...", "action":"list_windows"}}

--- GUI INTERACTIONS ---
Click:            {{"thought":"...", "action":"click",            "x":500, "y":300}}
Double-click:     {{"thought":"...", "action":"double_click",     "x":500, "y":300}}
Right-click:      {{"thought":"...", "action":"right_click",      "x":500, "y":300}}
Type:             {{"thought":"...", "action":"type",             "text":"hello"}}
Hotkey:           {{"thought":"...", "action":"hotkey",           "keys":["ctrl","c"]}}
Press key:        {{"thought":"...", "action":"press",            "key":"enter"}}
Scroll:           {{"thought":"...", "action":"scroll",           "direction":"down", "amount":3, "x":640, "y":400}}
Drag:             {{"thought":"...", "action":"drag",             "x1":100, "y1":100, "x2":500, "y2":500}}

--- FLOW ---
Done:             {{"thought":"...", "action":"done",             "result":"what was accomplished"}}
Screenshot:       {{"thought":"...", "action":"take_screenshot"}}

CRITICAL RULES:
- All shell commands are security checked. Dangerous commands are BLOCKED.
- After clicking a text field, IMMEDIATELY type in next step.
- NEVER repeat the same action more than 2 times.
- Before GUI click/type, use "focus_app" first.
- Output ONLY valid JSON."""

    win_offset = (0, 0)
    log_action("telegram_task_start", task)
    
    for step in range(1, 41):
        global cancel_task
        if cancel_task:
            await tg_output.send("🛑 **Task stopped by user.**")
            cancel_task = False
            task_success = False
            break
            
        mem_text = ""
        if memory:
            mem_text = "\nSession history:\n" + "\n".join(
                f"  {m['step']}. {m['summary']}" for m in memory[-8:]
            )
        
        prompt = f"{SYSTEM}{mem_text}\n\nTask: {task}\n"
        
        # Loop detection
        if len(memory) >= 3:
            last_3 = [m['summary'] for m in memory[-3:]]
            if len(set(last_3)) == 1 or all('screen(' in s for s in last_3):
                prompt += "\n⚠️ CRITICAL: Same action 3x! Use COMPLETELY DIFFERENT approach.\n"
                await tg_output.send("🔄 Loop detected! Switching strategy...")
            elif len(memory) >= 2 and memory[-1]['summary'] == memory[-2]['summary']:
                prompt += "\n⚠️ Same action twice. Switch strategy if fails again.\n"
        
        if needs_screenshot:
            prompt += "Screenshot attached. Analyze and decide."
        else:
            prompt += "No screenshot. Use system commands first."
        
        # Take screenshot if needed
        b64 = None
        if needs_screenshot:
            if step == 1 or len(memory) == 0:
                b64 = take_full_screenshot_b64()
                win_offset = (0, 0)
            else:
                time.sleep(0.6)
                b64, win_offset = take_active_window_screenshot_b64()
            needs_screenshot = False
            
            # Send screenshot to Telegram
            if b64:
                try:
                    img_bytes = base64.b64decode(b64)
                    await tg_output.send_photo(img_bytes, f"📸 Step {step}")
                except Exception:
                    pass
        
        try:
            raw = await _ask_llm(llm, prompt, b64_img=b64, extra_images=extra_images)
            action = _parse_json(raw)
            act = action.get('action')
            thought = action.get('thought', '')
            
            step_msg = f"📍 Step {step}"
            if thought:
                step_msg += f"\n🧠 {thought}"
            
            # ══════ EXECUTE ══════
            
            # --- System Control ---
            if act == 'set_volume':
                level = int(action.get('level', 50))
                set_volume(level)
                step_msg += f"\n🔊 Volume → {level}%"
                memory.append({"step": step, "summary": f"Volume: {level}%"})
            
            elif act == 'mute_toggle':
                mute_toggle()
                step_msg += "\n🔇 Mute toggled"
                memory.append({"step": step, "summary": "Mute toggled"})
            
            elif act == 'set_brightness':
                level = int(action.get('level', 50))
                out = set_brightness(level)
                step_msg += f"\n💡 Brightness → {level}%"
                memory.append({"step": step, "summary": f"Brightness: {level}%"})
            
            elif act == 'wifi':
                enable = action.get('enable', True)
                out = wifi_toggle(enable)
                step_msg += f"\n📡 WiFi → {'ON' if enable else 'OFF'}: {out[:50]}"
                memory.append({"step": step, "summary": f"WiFi: {'ON' if enable else 'OFF'}"})
            
            elif act == 'bluetooth':
                enable = action.get('enable', True)
                out = bluetooth_toggle(enable)
                step_msg += f"\n🔵 Bluetooth → {'ON' if enable else 'OFF'}: {out[:50]}"
                memory.append({"step": step, "summary": f"BT: {'ON' if enable else 'OFF'}"})
            
            elif act == 'system_info':
                out = get_system_info()
                step_msg += f"\n📊 {out[:200]}"
                memory.append({"step": step, "summary": "System info retrieved"})
            
            elif act == 'list_processes':
                out = get_running_processes()
                step_msg += f"\n📋 {out[:300]}"
                memory.append({"step": step, "summary": "Listed processes"})
            
            elif act == 'kill_process':
                name = action.get('name', '')
                out = kill_process(name)
                step_msg += f"\n💀 Kill {name}: {out}"
                memory.append({"step": step, "summary": f"Kill: {name}"})
            
            elif act == 'lock_screen':
                lock_screen()
                step_msg += "\n🔒 Screen locked"
                memory.append({"step": step, "summary": "Locked"})
            
            elif act == 'shutdown':
                delay = int(action.get('delay', 30))
                shutdown(delay)
                step_msg += f"\n⚡ Shutdown in {delay}s"
                memory.append({"step": step, "summary": f"Shutdown: {delay}s"})
            
            elif act == 'restart':
                delay = int(action.get('delay', 10))
                restart(delay)
                step_msg += f"\n🔄 Restart in {delay}s"
                memory.append({"step": step, "summary": f"Restart: {delay}s"})
            
            elif act == 'sleep':
                sleep_pc()
                step_msg += "\n😴 Sleeping..."
                memory.append({"step": step, "summary": "Sleep"})
            
            elif act == 'create_file':
                fpath = action.get('path', '')
                content = action.get('content', '')
                create_file(fpath, content)
                step_msg += f"\n📄 Created: {fpath}"
                memory.append({"step": step, "summary": f"File: {fpath}"})
            
            # --- Window Management ---
            elif act == 'focus_app':
                title = action.get('window_title', '')
                result = focus_window(title)
                step_msg += f"\n🪟 Focus: {title} → {result}"
                memory.append({"step": step, "summary": f"Focused: {title}"})
                needs_screenshot = True
            
            elif act == 'minimize_window':
                title = action.get('window_title', '')
                result = minimize_window(title)
                step_msg += f"\n⬇️ Minimize: {title}"
                memory.append({"step": step, "summary": f"Minimized: {title}"})
            
            elif act == 'maximize_window':
                title = action.get('window_title', '')
                result = maximize_window(title)
                step_msg += f"\n⬆️ Maximize: {title}"
                memory.append({"step": step, "summary": f"Maximized: {title}"})
            
            elif act == 'close_window':
                title = action.get('window_title', '')
                close_window(title)
                step_msg += f"\n❌ Closed: {title}"
                memory.append({"step": step, "summary": f"Closed: {title}"})
            
            elif act == 'snap_window':
                title = action.get('window_title', '')
                pos = action.get('position', 'left')
                snap_window(title, pos)
                step_msg += f"\n📐 Snap: {title} → {pos}"
                memory.append({"step": step, "summary": f"Snap: {title} {pos}"})
            
            elif act == 'list_windows':
                windows = list_windows()
                win_text = "\n".join(f"  • {w.get('title', '?')}" for w in windows[:6])
                step_msg += f"\n🪟 Windows:\n{win_text}"
                memory.append({"step": step, "summary": f"{len(windows)} windows"})
            
            # --- GUI Actions ---
            elif act in ('click', 'double_click', 'right_click'):
                raw_x, raw_y = int(action.get('x', 0)), int(action.get('y', 0))
                ox, oy = win_offset
                x, y = raw_x + ox, raw_y + oy
                label = {'click': '🖱️', 'double_click': '🖱️🖱️', 'right_click': '🖱️R'}[act]
                reliable_click(x, y, click_type=act)
                step_msg += f"\n{label} Click ({x},{y})"
                memory.append({"step": step, "summary": f"{label} screen({x},{y})"})
                smart_wait(act)
                needs_screenshot = True
            
            elif act == 'type':
                text = action.get('text', '')
                ensure_window_focus()
                reliable_type(text)
                step_msg += f"\n⌨️ Typed: '{text[:40]}'"
                memory.append({"step": step, "summary": f"Typed: '{text[:40]}'"})
                smart_wait('type')
                needs_screenshot = True
            
            elif act == 'press':
                key = action.get('key', 'enter')
                ensure_window_focus()
                pyautogui.press(key)
                step_msg += f"\n⌨️ Press: {key}"
                memory.append({"step": step, "summary": f"Pressed: {key}"})
                smart_wait('press')
                needs_screenshot = True
            
            elif act == 'hotkey':
                keys = action.get('keys', [])
                ensure_window_focus()
                pyautogui.hotkey(*keys)
                step_msg += f"\n⌨️ Hotkey: {'+'.join(keys)}"
                memory.append({"step": step, "summary": f"Hotkey: {'+'.join(keys)}"})
                smart_wait('hotkey')
                needs_screenshot = True
            
            elif act == 'scroll':
                direction = action.get('direction', 'down')
                amount = int(action.get('amount', 3))
                if 'x' in action and 'y' in action:
                    ox, oy = win_offset
                    sx, sy = int(action['x']) + ox, int(action['y']) + oy
                    pyautogui.moveTo(sx, sy, duration=0.2)
                pyautogui.scroll(-amount if direction == 'down' else amount)
                step_msg += f"\n🔄 Scroll {direction} ×{amount}"
                memory.append({"step": step, "summary": f"Scroll {direction} ×{amount}"})
                smart_wait('scroll')
                needs_screenshot = True
            
            elif act == 'drag':
                x1, y1 = int(action.get('x1', 0)), int(action.get('y1', 0))
                x2, y2 = int(action.get('x2', 0)), int(action.get('y2', 0))
                ox, oy = win_offset
                drag_and_drop(x1 + ox, y1 + oy, x2 + ox, y2 + oy)
                step_msg += f"\n↕️ Drag ({x1+ox},{y1+oy}) → ({x2+ox},{y2+oy})"
                memory.append({"step": step, "summary": f"Drag"})
                needs_screenshot = True
            
            elif act == 'take_screenshot':
                step_msg += "\n📸 Screenshot requested"
                needs_screenshot = True
                memory.append({"step": step, "summary": "Screenshot"})
            
            elif act == 'shell':
                cmd = action.get('command', '')
                out = run_shell(cmd)
                step_msg += f"\n⚡ Shell: {cmd}\n   → {out[:100]}"
                memory.append({"step": step, "summary": f"Shell: {cmd[:30]} → {out[:30]}"})
                smart_wait('shell')
            
            elif act == 'done':
                result = action.get('result', 'Done.')
                await tg_output.send(f"✅ JARVIS — Task Complete!\n\n{result}")
                task_success = True
                log_action("telegram_task_done", result)
                break
            
            else:
                step_msg += f"\n❓ Unknown: {act}"
            
            # Send step update to Telegram
            await tg_output.send(step_msg)
        
        except Exception as e:
            await tg_output.send(f"📍 Step {step}\n❌ Error: {str(e)[:100]}")
            memory.append({"step": step, "summary": f"Error: {str(e)[:60]}"})
            time.sleep(0.5)
    
    # Save memory
    record_task(mem, task, memory, task_success)
    if not task_success:
        await tg_output.send("⚠️ Task finished without explicit completion (max steps reached)")
    
    await tg_output.flush()


# ════════════════════════════════════════════════════════
# 📱 TELEGRAM HANDLERS
# ════════════════════════════════════════════════════════

is_task_running = False

async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /start command."""
    chat_id = str(update.effective_chat.id)
    await update.message.reply_text(
        f"🤖 JARVIS — ClawBot Remote Control\n\n"
        f"Your Chat ID: {chat_id}\n\n"
        f"Commands:\n"
        f"  /task <task> — Run a computer task\n"
        f"  /status — System info\n"
        f"  /screenshot — Take screenshot\n"
        f"  /windows — List open windows\n"
        f"  /processes — Running processes\n"
        f"  /stop — Stop current task\n\n"
        f"Or just type any task directly!"
    )


async def cmd_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """System status."""
    if not _is_authorized(update):
        return
    
    from system_control import get_system_info, get_network_info
    info = get_system_info()
    net = get_network_info()
    await update.message.reply_text(f"📊 System Status\n\n{info}\n\n{net}")


async def cmd_screenshot(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Take and send a screenshot."""
    if not _is_authorized(update):
        return
    
    from agent import take_full_screenshot_b64
    b64 = take_full_screenshot_b64()
    if b64:
        img_bytes = base64.b64decode(b64)
        await update.message.reply_photo(photo=img_bytes, caption="📸 Current Screen")
    else:
        await update.message.reply_text("❌ Screenshot failed")


async def cmd_windows(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """List open windows."""
    if not _is_authorized(update):
        return
    
    windows = list_windows()
    text = "🪟 Open Windows:\n\n"
    for w in windows[:15]:
        text += f"• {w.get('title', '?')} ({w.get('width', 0)}x{w.get('height', 0)})\n"
    await update.message.reply_text(text)


async def cmd_processes(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """List running processes."""
    if not _is_authorized(update):
        return
    
    from system_control import get_running_processes
    out = get_running_processes(top_n=20)
    await update.message.reply_text(f"📋 Top Processes:\n\n{out[:3500]}")


async def cmd_stop(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Stop the currently running task."""
    global is_task_running, cancel_task
    
    if not _is_authorized(update):
        return
        
    if not is_task_running:
        await update.message.reply_text("✅ No task is currently running.")
        return
        
    cancel_task = True
    await update.message.reply_text("🛑 Stopping the current task... Please wait a moment.")


async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle any text message as a task."""
    global is_task_running, cancel_task
    
    if not _is_authorized(update):
        return
    
    task = update.message.text.strip()
    
    if not task:
        return
    
    # Handle /task prefix
    if task.lower().startswith('/task '):
        task = task[6:].strip()
    
    if is_task_running:
        await update.message.reply_text("⏳ A task is already running! Wait for it to finish.")
        return
    
    is_task_running = True
    cancel_task = False
    
    try:
        bot = context.bot
        chat_id = str(update.effective_chat.id)
        tg_output = TelegramOutput(bot, chat_id)
        
        await update.message.reply_text(f"🚀 JARVIS starting task:\n{task}")
        
        await run_jarvis_task(task, tg_output)
    except Exception as e:
        await update.message.reply_text(f"❌ Task failed: {str(e)[:200]}")
        logger.error(f"Task error: {e}", exc_info=True)
    finally:
        is_task_running = False
        cancel_task = False


def _is_authorized(update: Update) -> bool:
    """Check if the user is authorized."""
    chat_id = str(update.effective_chat.id)
    auth_chat_id = get_authorized_chat_id()
    
    # If no CHAT_ID set, allow anyone (first-time setup)
    if not auth_chat_id:
        logger.warning(f"⚠️ No TELEGRAM_CHAT_ID set. Message from chat_id={chat_id}")
        return True
    
    if chat_id != auth_chat_id:
        logger.warning(f"🚫 Unauthorized access from chat_id={chat_id}")
        asyncio.ensure_future(
            update.message.reply_text("🚫 Unauthorized. This bot is private.")
        )
        return False
    
    return True


# ════════════════════════════════════════════════════════
# 🚀 MAIN
# ════════════════════════════════════════════════════════

def main():
    """Start the Telegram bot."""
    bot_token = get_bot_token()
    auth_chat_id = get_authorized_chat_id()
    
    if not bot_token:
        print("❌ TELEGRAM_BOT_TOKEN not set!")
        print("\nSetup:")
        print("  1. Talk to @BotFather on Telegram → /newbot → get TOKEN")
        print("  2. Set: TELEGRAM_BOT_TOKEN=your_token")
        print("     Set: TELEGRAM_CHAT_ID=your_chat_id")
        print("     Set: OLLAMA_BASE_URL=http://your-url:11434")
        print("  3. Save in ~/.clawbot/.env or set as environment variables")
        print("  4. Run: python telegram_bot.py")
        sys.exit(1)
    
    print("🤖 JARVIS Telegram Bot Starting...")
    print(f"   Token: {bot_token[:8]}...{bot_token[-4:]}")
    print(f"   Auth Chat ID: {auth_chat_id or 'ANY (⚠️ set TELEGRAM_CHAT_ID!)'}")
    print(f"   Model: {os.getenv('TELEGRAM_BOT_MODEL', 'qwen3.5:397b-cloud')}")
    print(f"   Ollama: {os.getenv('OLLAMA_BASE_URL', 'http://localhost:11434')}")
    print()
    
    app = Application.builder().token(bot_token).build()
    
    # Commands
    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("status", cmd_status))
    app.add_handler(CommandHandler("screenshot", cmd_screenshot))
    app.add_handler(CommandHandler("windows", cmd_windows))
    app.add_handler(CommandHandler("processes", cmd_processes))
    app.add_handler(CommandHandler("stop", cmd_stop))
    app.add_handler(CommandHandler("task", handle_message))
    
    # Any text message = task
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    
    print("✅ JARVIS is listening on Telegram! Send a message to control your PC.\n")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == '__main__':
    main()
