"""
address-finder-data: companion data package for address-finder.

On first import, call assemble() to decompress all data files into the
cache directory and make them available to address-finder.
"""
from __future__ import annotations

import importlib
import json
import lzma
import os
from pathlib import Path
from typing import Optional

__version__ = "1.0.0"

# Where address-finder looks for data
DEFAULT_CACHE = Path.home() / ".cache" / "address_finder" / "v1.0.0"

# File destination sub-paths (relative to cache root)
DEST_PATHS = {
    "address_parser_crf.dat":          "address_parser/address_parser_crf.dat",
    "address_parser_postal_codes.dat":  "address_parser/address_parser_postal_codes.dat",
    "address_parser_phrases.dat":       "address_parser/address_parser_phrases.dat",
    "address_parser_vocab.trie":        "address_parser/address_parser_vocab.trie",
    "language_classifier.dat":          "language_classifier/language_classifier.dat",
    "transliteration.dat":              "transliteration/transliteration.dat",
    "address_dictionary.dat":           "address_expansions/address_dictionary.dat",
    "numex.dat":                        "numex/numex.dat",
}

MANIFEST: dict = json.loads('{\n  "version": "1.0.0",\n  "files": {\n    "address_parser_crf.dat": {\n      "original_size": 1014429504,\n      "chunk_packages": [\n        "address_finder_data_p00",\n        "address_finder_data_p01",\n        "address_finder_data_p02",\n        "address_finder_data_p03",\n        "address_finder_data_p04"\n      ]\n    },\n    "address_parser_postal_codes.dat": {\n      "original_size": 621588636,\n      "chunk_packages": [\n        "address_finder_data_p05"\n      ]\n    },\n    "address_parser_phrases.dat": {\n      "original_size": 137484586,\n      "chunk_packages": [\n        "address_finder_data_p06"\n      ]\n    },\n    "address_parser_vocab.trie": {\n      "original_size": 99219597,\n      "chunk_packages": [\n        "address_finder_data_p07"\n      ]\n    },\n    "language_classifier.dat": {\n      "original_size": 77823270,\n      "chunk_packages": [\n        "address_finder_data_p08"\n      ]\n    },\n    "transliteration.dat": {\n      "original_size": 19570085,\n      "chunk_packages": [\n        "address_finder_data_p09"\n      ]\n    },\n    "address_dictionary.dat": {\n      "original_size": 8737530,\n      "chunk_packages": [\n        "address_finder_data_p10"\n      ]\n    },\n    "numex.dat": {\n      "original_size": 396966,\n      "chunk_packages": [\n        "address_finder_data_p11"\n      ]\n    }\n  }\n}')


def assemble(cache_dir: Path | None = None, force: bool = False) -> Path:
    """
    Decompress and assemble all data files into *cache_dir*.

    Args:
        cache_dir: Target directory (default: ~/.cache/address_finder/v1.0.0).
        force: Re-assemble even if stamp file already exists.

    Returns:
        Path to the assembled data root.
    """
    cache_dir = Path(cache_dir or DEFAULT_CACHE)
    stamp = cache_dir / ".assembled"

    if stamp.exists() and not force:
        return cache_dir

    print("address-finder-data: assembling data files…")
    cache_dir.mkdir(parents=True, exist_ok=True)

    for canonical_name, info in MANIFEST["files"].items():
        dest_rel = DEST_PATHS[canonical_name]
        dest = cache_dir / dest_rel
        dest.parent.mkdir(parents=True, exist_ok=True)

        if dest.exists() and not force:
            print(f"  {canonical_name} already present, skipping")
            continue

        print(f"  Assembling {canonical_name}…", end=" ", flush=True)

        # Collect compressed bytes from all chunk packages
        compressed_parts: list[bytes] = []
        for mod_name in info["chunk_packages"]:
            mod = importlib.import_module(mod_name)
            chunk_path = mod.chunk_path()
            compressed_parts.append(chunk_path.read_bytes())

        compressed = b"".join(compressed_parts)
        print(f"decompressing {len(compressed)//1024//1024} MB…", end=" ", flush=True)
        data = lzma.decompress(compressed, format=lzma.FORMAT_XZ)
        dest.write_bytes(data)
        print(f"done ({len(data)//1024//1024} MB)")

    stamp.write_text("assembled")
    print(f"address-finder-data: all files ready at {cache_dir}")
    return cache_dir


def is_assembled(cache_dir: Path | None = None) -> bool:
    """Return True if data has already been assembled."""            cache_dir = Path(cache_dir or DEFAULT_CACHE)
    return (cache_dir / ".assembled").exists()
