# -*- coding: utf-8 -*-
"""
Slash-command aliases for AI Chat plugin. (C) 2026 by Maciej Piecko

Commands are stored in ~/.spyder_ai_chat/commands.json as a list of:
  { "name": "tests", "prompt": "Write comprehensive unit tests for the following code:" }

The 'name' is without the leading '/'.  Minimum 2 characters.
"""

import json
import os

# ---------------------------------------------------------------------------
# Built-in default commands (shipped with the plugin)
# ---------------------------------------------------------------------------
DEFAULT_COMMANDS = [
    {
        "name": "tests",
        "prompt": (
            "Generate comprehensive unit tests for the following code. "
            "Cover edge cases, typical inputs, and error conditions. "
            "Use the appropriate testing framework for the language."
        ),
    },
    {
        "name": "simplify",
        "prompt": (
            "Simplify the following code. Make it cleaner, more readable, "
            "and easier to maintain without changing its behaviour."
        ),
    },
    {
        "name": "fix",
        "prompt": (
            "Fix all problems and compile errors in the following code. "
            "Explain each fix briefly."
        ),
    },
    {
        "name": "explain",
        "prompt": (
            "Explain how the following code works. "
            "Describe the overall structure, key logic, and any non-obvious parts."
        ),
    },
    {
        "name": "doc",
        "prompt": (
            "Document the following code. Add clear docstrings, "
            "parameter descriptions, return value descriptions, "
            "and inline comments where helpful."
        ),
    },
]


# ---------------------------------------------------------------------------
# Storage path
# ---------------------------------------------------------------------------
def _commands_path():
    d = os.path.join(os.path.expanduser("~"), ".spyder_ai_chat")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "commands.json")


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------
def load_commands():
    """Load commands from disk.  Returns list of {name, prompt} dicts.
    If no file exists yet, seeds with DEFAULT_COMMANDS and saves."""
    path = _commands_path()
    if not os.path.exists(path):
        save_commands(DEFAULT_COMMANDS)
        return list(DEFAULT_COMMANDS)
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        # Validate minimal structure
        result = []
        for item in data:
            if isinstance(item, dict) and "name" in item and "prompt" in item:
                name = str(item["name"]).strip().lstrip("/")
                prompt = str(item["prompt"]).strip()
                if len(name) >= 2 and prompt:
                    result.append({"name": name, "prompt": prompt})
        return result
    except Exception:
        return list(DEFAULT_COMMANDS)


def save_commands(commands):
    """Persist the given list of {name, prompt} dicts to disk."""
    try:
        with open(_commands_path(), "w", encoding="utf-8") as f:
            json.dump(commands, f, indent=2, ensure_ascii=False)
    except Exception:
        pass


def get_command_prompt(name, commands):
    """Return the prompt string for the given command name (without '/'),
    or None if not found."""
    for cmd in commands:
        if cmd["name"] == name:
            return cmd["prompt"]
    return None
