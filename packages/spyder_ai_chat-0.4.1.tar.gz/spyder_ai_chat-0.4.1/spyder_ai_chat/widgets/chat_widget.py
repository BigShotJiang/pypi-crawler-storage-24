# -*- coding: utf-8 -*-
"""AI Chat Panel — Spyder 6 plugin (C) 2026 by Maciej Piecko"""

import json
import threading

from qtpy.QtCore import Qt, Signal, Slot, QEvent, QObject, QThread, QTimer
from qtpy.QtGui import QFont, QTextCursor, QTextCharFormat, QColor
from qtpy.QtWidgets import (
    QApplication, QComboBox, QDialog, QDialogButtonBox, QDoubleSpinBox,
    QFormLayout, QGroupBox,
    QHBoxLayout, QLabel, QLineEdit, QListWidget, QListWidgetItem,
    QFrame, QPlainTextEdit, QPushButton, QTabWidget, QTextEdit,
    QVBoxLayout, QWidget, QSizePolicy, QToolButton, QStyle, QScrollArea,
    QSpinBox,
)

from .chat_history_manager import save_chat, load_chat, delete_chat, list_chats
from .commands import load_commands, save_commands, get_command_prompt

DEFAULT_MODELS = [
    "gpt-4o", "gpt-4o-mini", "gpt-3.5-turbo",
    "llama3", "mistral", "codellama", "phi3",
]

# Styles for the inference params summary bar label
_PARAMS_BAR_IDLE_STYLE = (
    "QPushButton { color: #ccc; font-size: 9px; text-align: left; "
    "border: none; padding: 0 4px; }"
    "QPushButton:hover { color: #fff; }"
)
_PARAMS_BAR_ACTIVE_STYLE = (
    "QPushButton { color: #c8a000; font-size: 9px; text-align: left; "
    "border: none; padding: 0 4px; }"
    "QPushButton:hover { color: #ffe080; }"
)



# ---------------------------------------------------------------------------
# Command-input widget
# A QPlainTextEdit that:
#  - watches for "/" typed by the user and shows a command-picker dropdown
#  - tracks which text spans are "active commands" (typed via the picker)
#  - highlights active-command spans with a tinted background
#  - translates active-command spans to their prompt text at send-time
#
# KEY DESIGN: "active command" tracking
#   self._active_commands = list of dicts:
#       { "start": int, "length": int, "name": str }
#   start/length are character positions in the document.
#   A span is ONLY considered an active command if it was selected via the
#   dropdown — typing "/tests" manually (after dismissing the dropdown with
#   Escape) is never added to _active_commands and is sent verbatim.
# ---------------------------------------------------------------------------
class _CommandInput(QPlainTextEdit):
    """Input field with slash-command picker dropdown."""

    # Emitted when Ctrl+Enter is pressed (parent wires this to _send)
    send_requested = Signal()

    # Background colour for highlighted command tokens
    _CMD_BG   = QColor("#2a3a1a")   # dark green tint
    _CMD_FG   = QColor("#b8e090")   # light green text

    def __init__(self, parent=None):
        super().__init__(parent)
        self._commands = []          # list of {name, prompt} — loaded externally
        self._active_commands = []   # list of {start, length, name}
        self._dropdown = None        # _CommandDropdown instance (lazy)
        self._dropdown_slash_pos = -1  # doc position of the '/' that opened dropdown
        self._suppress_change = False

        self.document().contentsChange.connect(self._on_contents_change)

    # ── public ───────────────────────────────────────────────────────────

    def set_commands(self, commands):
        self._commands = commands

    def get_text_for_send(self):
        """Return the plain text with all active-command spans replaced by their prompts."""
        raw = self.toPlainText()
        if not self._active_commands:
            return raw
        # Sort by start position, process in reverse so replacements don't shift offsets
        cmds = sorted(self._active_commands, key=lambda c: c["start"], reverse=True)
        result = list(raw)
        for cmd in cmds:
            s, l = cmd["start"], cmd["length"]
            prompt = get_command_prompt(cmd["name"], self._commands)
            replacement = prompt if prompt else raw[s:s+l]
            result[s:s+l] = list(replacement)
        return "".join(result)

    def clear(self):
        self._active_commands.clear()
        self._dropdown_slash_pos = -1
        self._close_dropdown()
        super().clear()

    # ── dropdown interaction ─────────────────────────────────────────────

    def _open_dropdown(self, slash_pos):
        """Show the command picker anchored near the slash character."""
        if not self._commands:
            return
        self._dropdown_slash_pos = slash_pos
        if self._dropdown is None:
            self._dropdown = _CommandDropdown(self)
            self._dropdown.command_selected.connect(self._on_command_selected)
            self._dropdown.cancelled.connect(self._on_dropdown_cancelled)
        self._dropdown.populate(self._commands)
        self._reposition_dropdown()
        self._dropdown.show()
        self._dropdown.raise_()
        self.setFocus()

    def _close_dropdown(self):
        if self._dropdown and self._dropdown.isVisible():
            self._dropdown.hide()
        self._dropdown_slash_pos = -1

    def _reposition_dropdown(self):
        if self._dropdown is None:
            return
        # Position relative to the slash character, not current cursor
        cursor = self.textCursor()
        if self._dropdown_slash_pos >= 0:
            cursor.setPosition(self._dropdown_slash_pos)
        rect = self.cursorRect(cursor)
        # Global position of the bottom of the slash character
        global_pt = self.mapToGlobal(rect.bottomLeft())
        dd = self._dropdown
        dd.adjustSize()
        dh = dd.sizeHint().height()
        dw = dd.sizeHint().width()
        # Screen geometry to decide above/below
        from qtpy.QtWidgets import QApplication
        screen = QApplication.screenAt(global_pt)
        if screen is None:
            screen = QApplication.primaryScreen()
        sg = screen.availableGeometry()
        # Show above the slash if not enough space below
        if global_pt.y() + dh > sg.bottom():
            y = self.mapToGlobal(rect.topLeft()).y() - dh
        else:
            y = global_pt.y()
        # Clamp horizontally
        x = min(global_pt.x(), sg.right() - dw)
        x = max(x, sg.left())
        dd.move(x, y)

    def _on_command_selected(self, name):
        """User picked a command — replace the '/' + any partial text with '/name'."""
        slash_pos = self._dropdown_slash_pos
        self._close_dropdown()
        if slash_pos < 0:
            return

        cursor = self.textCursor()
        doc_len = len(self.toPlainText())
        current_pos = cursor.position()

        # Replace from slash_pos to current cursor position with '/name'
        cmd_text = "/" + name
        self._suppress_change = True
        cursor.setPosition(slash_pos)
        cursor.setPosition(current_pos, QTextCursor.KeepAnchor)
        cursor.removeSelectedText()
        cursor.insertText(cmd_text)
        self._suppress_change = False

        # Register this as an active command
        self._active_commands.append({
            "start":  slash_pos,
            "length": len(cmd_text),
            "name":   name,
        })
        self._apply_highlights()
        self.setFocus()

    def _on_dropdown_cancelled(self):
        """Escape pressed — close dropdown, leave '/' as plain text (not a command)."""
        self._close_dropdown()
        self.setFocus()

    # ── highlights ───────────────────────────────────────────────────────

    def _apply_highlights(self):
        """Re-apply background highlights for all active-command spans."""
        # Clear all existing extra selections
        self.setExtraSelections([])
        selections = []
        raw = self.toPlainText()
        for cmd in self._active_commands:
            s, l = cmd["start"], cmd["length"]
            if s + l > len(raw):
                continue
            # Verify text still matches (guard against out-of-sync after edit)
            if raw[s:s+l] != "/" + cmd["name"]:
                continue
            cursor = self.textCursor()
            cursor.setPosition(s)
            cursor.setPosition(s + l, QTextCursor.KeepAnchor)
            fmt = QTextCharFormat()
            fmt.setBackground(self._CMD_BG)
            fmt.setForeground(self._CMD_FG)
            sel = QTextEdit.ExtraSelection()
            sel.cursor = cursor
            sel.format = fmt
            selections.append(sel)
        self.setExtraSelections(selections)

    # ── content-change tracking ──────────────────────────────────────────

    def _on_contents_change(self, position, removed, added):
        """Keep _active_commands offsets in sync as text is edited."""
        if self._suppress_change:
            return

        raw = self.toPlainText()
        updated = []
        for cmd in self._active_commands:
            s, l = cmd["start"], cmd["length"]
            end = s + l

            if removed > 0 or added > 0:
                # If the edit touched inside the command span → invalidate it
                edit_end = position + max(removed, added)
                if position < end and edit_end > s:
                    # Edit overlaps span — drop this command
                    continue
                # Shift spans that come after the edit position
                if position <= s:
                    delta = added - removed
                    s += delta
                    cmd = {**cmd, "start": s}

            # Final guard: verify text still matches
            if s >= 0 and s + l <= len(raw) and raw[s:s+l] == "/" + cmd["name"]:
                updated.append(cmd)

        self._active_commands = updated
        self._apply_highlights()

        # Also filter dropdown results if it's open
        if self._dropdown and self._dropdown.isVisible():
            slash_pos = self._dropdown_slash_pos
            cur_pos = self.textCursor().position()
            if slash_pos >= 0 and cur_pos > slash_pos:
                partial = raw[slash_pos + 1 : cur_pos]
                self._dropdown.filter(partial)
            else:
                self._close_dropdown()

    # ── keyboard events ──────────────────────────────────────────────────

    def keyPressEvent(self, event):
        key = event.key()

        # Ctrl+Enter → send
        if key in (Qt.Key_Return, Qt.Key_Enter) and event.modifiers() & Qt.ControlModifier:
            self.send_requested.emit()
            return

        # Forward Up/Down/Enter/Escape to dropdown when visible
        if self._dropdown and self._dropdown.isVisible():
            if key == Qt.Key_Escape:
                self._on_dropdown_cancelled()
                return
            if key in (Qt.Key_Up, Qt.Key_Down):
                self._dropdown.move_selection(key == Qt.Key_Down)
                return
            if key in (Qt.Key_Return, Qt.Key_Enter):
                self._dropdown.confirm_selection()
                return

        super().keyPressEvent(event)

        # After typing, check if we just typed '/'
        if key == Qt.Key_Slash:
            pos = self.textCursor().position()
            self._open_dropdown(pos - 1)


# ---------------------------------------------------------------------------
# Command-picker dropdown  (frameless popup list)
# ---------------------------------------------------------------------------
class _CommandDropdown(QFrame):
    """Floating dropdown that lists available slash commands."""

    command_selected = Signal(str)   # emits command name (without '/')
    cancelled = Signal()

    def __init__(self, parent=None):
        super().__init__(parent, Qt.ToolTip | Qt.FramelessWindowHint)
        self.setStyleSheet(
            "QFrame { background: #1e2a1e; border: 1px solid #3a5a3a; "
            "border-radius: 4px; }"
        )
        lay = QVBoxLayout(self)
        lay.setContentsMargins(2, 2, 2, 2)
        lay.setSpacing(0)

        self._list = QListWidget()
        self._list.setStyleSheet(
            "QListWidget { background: transparent; border: none; "
            "color: #d0d0d0; font-size: 9pt; }"
            "QListWidget::item { padding: 2px 6px; border-radius: 2px; }"
            "QListWidget::item:selected { background: #2a4a2a; color: #b8e090; }"
            "QListWidget::item:hover { background: #243424; }"
        )
        self._list.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self._list.setFixedWidth(280)
        self._list.itemClicked.connect(self._on_item_click)
        lay.addWidget(self._list)
        self._all_commands = []

    def populate(self, commands):
        self._all_commands = commands
        self._fill(commands)

    def filter(self, partial):
        """Show only commands whose name starts with `partial`."""
        filtered = [c for c in self._all_commands
                    if c["name"].startswith(partial.lower())]
        self._fill(filtered)
        if not filtered:
            self.hide()

    def _fill(self, commands):
        self._list.clear()
        for cmd in commands:
            item = QListWidgetItem(f"/{cmd['name']}")
            # Add short description in muted colour using HTML isn't possible in
            # QListWidget directly — use UserRole for description display via
            # a custom approach: append description with tab spacing
            desc = self._short_desc(cmd["prompt"])
            item.setText(f"/{cmd['name']}   —   {desc}")
            item.setData(Qt.UserRole, cmd["name"])
            self._list.addItem(item)
        if self._list.count():
            self._list.setCurrentRow(0)
        # Resize to content
        rows = min(self._list.count(), 8)
        item_h = self._list.sizeHintForRow(0) if self._list.count() else 28
        self._list.setFixedHeight(rows * item_h + 6)
        self.adjustSize()

    @staticmethod
    def _short_desc(prompt, max_chars=40):
        words = prompt.split()
        out = ""
        for w in words:
            if len(out) + len(w) + 1 > max_chars:
                return out.rstrip() + "…"
            out += w + " "
        return out.strip()

    def move_selection(self, down: bool):
        row = self._list.currentRow()
        n = self._list.count()
        if down:
            row = (row + 1) % n
        else:
            row = (row - 1) % n
        self._list.setCurrentRow(row)

    def confirm_selection(self):
        item = self._list.currentItem()
        if item:
            self.command_selected.emit(item.data(Qt.UserRole))

    def _on_item_click(self, item):
        self.command_selected.emit(item.data(Qt.UserRole))


# ---------------------------------------------------------------------------
# Hover-warmup button: stays disabled/gray until the pointer rests on it,
# then animates gray→red over `warmup_ms` ms and becomes clickable.
# Moving the pointer off while still warming up reverses back to gray/disabled.
# ---------------------------------------------------------------------------
class _WarmupButton(QPushButton):
    """QPushButton that activates only after the cursor hovers for `warmup_ms` ms."""

    STEPS = 20  # animation ticks

    def __init__(self, text, warmup_ms=2000, parent=None):
        super().__init__(text, parent)
        self._warmup_ms = warmup_ms
        self._warmup_step = 0
        self._warmup_timer = None
        self._apply_style(0)
        self.setEnabled(False)

    # ── hover enter: start / resume animation ────────────────────────
    def enterEvent(self, event):
        super().enterEvent(event)
        if self._warmup_timer is None:
            interval = self._warmup_ms // self.STEPS
            self._warmup_timer = QTimer(self)
            self._warmup_timer.setInterval(interval)
            self._warmup_timer.timeout.connect(self._tick)
        self._warmup_timer.start()

    # ── hover leave: stop and reverse ────────────────────────────────
    def leaveEvent(self, event):
        super().leaveEvent(event)
        # Always reset -- button is only clickable while cursor is hovering
        self.reset()

    def _tick(self):
        self._warmup_step += 1
        if self._warmup_step >= self.STEPS:
            self._warmup_timer.stop()
            self._warmup_step = self.STEPS
            self.setEnabled(True)   # clickable only while cursor is here
            self._apply_style(self.STEPS)
        else:
            self._apply_style(self._warmup_step)

    def _apply_style(self, step):
        t = step / self.STEPS
        # gray #888 → red #f44
        r = int(0x88 + (0xff - 0x88) * t)
        g = int(0x88 + (0x44 - 0x88) * t)
        b = int(0x88 + (0x44 - 0x88) * t)
        col = f"#{r:02x}{g:02x}{b:02x}"
        bg_r = max(0x28, int(0x28 + 0x18 * t))
        dim = f"#{bg_r:02x}2828"
        self.setStyleSheet(
            f"QPushButton {{ color: {col}; font-size: 9px; padding: 1px 8px; "
            f"border: 1px solid {col}; border-radius: 3px; background: {dim}; }}"
            f"QPushButton:hover {{ color: #fcc; border-color: #fcc; background: {dim}; }}"
            f"QPushButton:disabled {{ color: {col}; border-color: {col}; background: {dim}; }}")

    def reset(self):
        """Call when popup is shown to put button back to initial gray state."""
        if self._warmup_timer:
            self._warmup_timer.stop()
        self._warmup_step = 0
        self.setEnabled(False)
        self._apply_style(0)


# ---------------------------------------------------------------------------
# Chat History Popup
# ---------------------------------------------------------------------------
class _ChatHistoryPopup(QFrame):
    """Popup listing saved chats. Emits load_chat(filename) or del_chat(filename)."""
    load_chat = Signal(str)
    del_chat  = Signal(str)
    del_all   = Signal()

    def __init__(self, parent=None):
        super().__init__(parent, Qt.Popup | Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_StyledBackground, True)
        self.setMinimumWidth(400)
        self.setMinimumHeight(420)
        self.setMaximumHeight(600)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(6, 6, 6, 6)
        lay.setSpacing(4)

        # ── header row: title + Delete All button ─────────────────────
        hdr_row = QHBoxLayout()
        hdr_row.setContentsMargins(0, 0, 0, 0)
        hdr_lbl = QLabel("Chat History")
        hdr_lbl.setStyleSheet("font-weight: bold; font-size: 11px; padding: 2px 4px;")
        hdr_row.addWidget(hdr_lbl, 1)

        # "Delete All" — activates only after cursor hovers for 2 s
        self._del_all_btn = _WarmupButton("🗑 Delete all", warmup_ms=1000)
        self._del_all_btn.setFlat(True)
        self._del_all_btn.setToolTip(
            "Delete all saved chats  (hold cursor here 1 s to unlock)")
        self._del_all_btn.setFixedHeight(24)
        self._del_all_cancel = QPushButton("↩ Cancel (3)")
        self._del_all_cancel.setFlat(True)
        self._del_all_cancel.setFixedHeight(24)
        self._del_all_cancel.setStyleSheet(
            "QPushButton { color: #f88; font-size: 9px; padding: 1px 8px; "
            "border: 1px solid #f88; border-radius: 3px; }"
            "QPushButton:hover { color: #fcc; border-color: #fcc; }")
        self._del_all_cancel.setVisible(False)
        self._del_all_timer = None
        self._del_all_remaining = [3]

        self._del_all_btn.clicked.connect(self._arm_delete_all)
        self._del_all_cancel.clicked.connect(self._cancel_delete_all)
        hdr_row.addWidget(self._del_all_btn)
        hdr_row.addWidget(self._del_all_cancel)
        lay.addLayout(hdr_row)

        # bottom separator
        sep_bot = QFrame()
        sep_bot.setFrameShape(QFrame.HLine)
        sep_bot.setStyleSheet("color: #444;")
        lay.addWidget(sep_bot)

        self._scroll = QScrollArea()
        self._scroll.setWidgetResizable(True)
        self._scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self._scroll.setFrameShape(QFrame.NoFrame)
        self._container = QWidget()
        self._list_lay = QVBoxLayout(self._container)
        self._list_lay.setContentsMargins(0, 4, 0, 4)
        self._list_lay.setSpacing(2)
        self._list_lay.setAlignment(Qt.AlignTop)

        self._empty_lbl = QLabel("No saved chats yet.")
        self._empty_lbl.setStyleSheet("color: gray; padding: 12px 8px;")
        self._empty_lbl.setAlignment(Qt.AlignTop | Qt.AlignHCenter)
        self._list_lay.addWidget(self._empty_lbl)

        self._scroll.setWidget(self._container)
        lay.addWidget(self._scroll, stretch=1)

    # ── delete-all countdown ──────────────────────────────────────────
    def _arm_delete_all(self):
        """Start 3-second countdown before deleting all chats."""
        if self._del_all_timer:
            self._del_all_timer.stop()
        self._del_all_remaining[0] = 3
        self._del_all_btn.setVisible(False)
        self._del_all_cancel.setText("\u21a9 Cancel (3)")
        self._del_all_cancel.setVisible(True)

        def _tick():
            self._del_all_remaining[0] -= 1
            if self._del_all_remaining[0] > 0:
                self._del_all_cancel.setText(
                    f"\u21a9 Cancel ({self._del_all_remaining[0]})")
            else:
                self._del_all_timer.stop()
                self._del_all_timer = None
                self._del_all_cancel.setVisible(False)
                self._del_all_btn.setVisible(True)
                self._execute_delete_all()

        self._del_all_timer = QTimer(self)
        self._del_all_timer.setInterval(1000)
        self._del_all_timer.timeout.connect(_tick)
        self._del_all_timer.start()

    def _cancel_delete_all(self):
        if self._del_all_timer:
            self._del_all_timer.stop()
            self._del_all_timer = None
        self._del_all_cancel.setVisible(False)
        self._del_all_btn.reset()
        self._del_all_btn.setVisible(True)

    def _execute_delete_all(self):
        from .chat_history_manager import list_chats
        for chat in list_chats():
            delete_chat(chat["filename"])
        self.del_all.emit()
        self._refresh()

    def show_below(self, btn, current_file=None):
        self._current_file = current_file
        self._cancel_delete_all()       # reset any pending countdown on reopen
        self._del_all_btn.reset()       # back to gray/disabled until hovered
        self._refresh()
        self.adjustSize()

        try:
            btn_bottom_right = btn.mapToGlobal(btn.rect().bottomRight())
            popup_x = btn_bottom_right.x() - self.width()
            popup_y = btn_bottom_right.y()
            from qtpy.QtWidgets import QApplication
            screen = QApplication.primaryScreen().availableGeometry()
            popup_x = max(screen.left(), popup_x)
        except Exception:
            pos = btn.mapToGlobal(btn.rect().bottomLeft())
            popup_x, popup_y = pos.x(), pos.y()

        self.move(popup_x, popup_y)
        self.show()
        self.raise_()

    def _refresh(self):
        # Clear chat rows but keep empty_lbl (index 0)
        while self._list_lay.count() > 1:
            item = self._list_lay.takeAt(1)
            if item.widget():
                item.widget().deleteLater()

        chats = list_chats()
        self._empty_lbl.setVisible(len(chats) == 0)
        self._del_all_btn.setVisible(len(chats) > 0)

        for chat in chats:
            self._add_row(chat)

    def _add_row(self, chat):
        fname   = chat["filename"]
        preview = chat["preview"] or "(empty)"
        label   = preview[:55] + ("…" if len(preview) > 55 else "")
        try:
            dt = chat["saved_at"][:16].replace("T", " ")
        except Exception:
            dt = ""

        is_active = (fname == getattr(self, "_current_file", None))

        row = QFrame()
        row.setObjectName("chatrow")
        if is_active:
            row.setStyleSheet(
                "QFrame#chatrow { border-radius: 3px; background: #1a3a1a; "
                "border: 1px solid #3a7a3a; }"
                "QFrame#chatrow:hover { background: #244a24; }")
        else:
            row.setStyleSheet(
                "QFrame#chatrow { border-radius: 3px; }"
                "QFrame#chatrow:hover { background: palette(highlight); }")
        rl = QHBoxLayout(row)
        rl.setContentsMargins(7, 3, 4, 3)
        rl.setSpacing(6)

        txt_btn = QPushButton(f"{label}\n{dt}")
        txt_btn.setFlat(True)
        if is_active:
            txt_btn.setStyleSheet(
                "QPushButton { text-align: left; border: none; padding: 2px 0 2px 6px; "
                "font-size: 11px; color: #7ec87e; }"
                "QPushButton:hover { color: #aeeaae; }")
        else:
            txt_btn.setStyleSheet(
                "QPushButton { text-align: left; border: none; padding: 2px 0 2px 6px; "
                "font-size: 11px; }"
                "QPushButton:hover { color: palette(highlighted-text); }")
        txt_btn.clicked.connect(lambda checked=False, f=fname: self._on_load(f))
        rl.addWidget(txt_btn, stretch=1)

        # Per-row delete with countdown/cancel
        del_btn = QPushButton("✕")
        del_btn.setFixedSize(28, 28)
        del_btn.setFlat(True)
        del_btn.setToolTip("Delete this chat")
        del_btn.setStyleSheet(
            "QPushButton { color: #888; border: none; font-size: 13px; font-weight: bold; }"
            "QPushButton:hover { color: #f88; }")

        cancel_btn = QPushButton("↩ 3")
        cancel_btn.setFixedSize(44, 28)
        cancel_btn.setFlat(True)
        cancel_btn.setToolTip("Cancel deletion")
        cancel_btn.setStyleSheet(
            "QPushButton { color: #f88; border: 1px solid #f88; "
            "border-radius: 3px; font-size: 10px; font-weight: bold; }"
            "QPushButton:hover { color: #fcc; border-color: #fcc; }")
        cancel_btn.setVisible(False)

        rl.addWidget(del_btn)
        rl.addWidget(cancel_btn)

        row_state = {"timer": None, "remaining": [3]}

        def _arm():
            if row_state["timer"]:
                row_state["timer"].stop()
            row_state["remaining"][0] = 3
            del_btn.setVisible(False)
            cancel_btn.setText("↩ 3")
            cancel_btn.setVisible(True)

            def _tick():
                row_state["remaining"][0] -= 1
                r = row_state["remaining"][0]
                if r > 0:
                    cancel_btn.setText(f"↩ {r}")
                else:
                    row_state["timer"].stop()
                    row_state["timer"] = None
                    self._on_delete(fname)

            t = QTimer(row)
            t.setInterval(1000)
            t.timeout.connect(_tick)
            t.start()
            row_state["timer"] = t

        def _cancel():
            if row_state["timer"]:
                row_state["timer"].stop()
                row_state["timer"] = None
            cancel_btn.setVisible(False)
            del_btn.setVisible(True)

        del_btn.clicked.connect(lambda checked=False: _arm())
        cancel_btn.clicked.connect(lambda checked=False: _cancel())

        self._list_lay.addWidget(row)

    def _on_load(self, filename):
        self.hide()
        self.load_chat.emit(filename)

    def _on_delete(self, filename):
        delete_chat(filename)
        self.del_chat.emit(filename)
        self._refresh()





# ---------------------------------------------------------------------------
# Chat API worker
# ---------------------------------------------------------------------------
class _ChatWorker(QObject):
    chunk_ready = Signal(str)
    finished    = Signal()
    error       = Signal(str)

    def __init__(self, api_url, api_key, model, messages, extra_params=None):
        super().__init__()
        self._url          = api_url.rstrip("/")
        self._key          = api_key
        self._model        = model
        self._messages     = messages
        self._extra_params = extra_params or {}
        self._stop         = False

    def stop(self):
        self._stop = True

    def run(self):
        try:
            import urllib.request
            import urllib.error
            body = {
                "model": self._model,
                "messages": self._messages,
                "stream": True,
            }
            body.update(self._extra_params)
            payload = json.dumps(body).encode()
            headers = {
                "Content-Type": "application/json",
                "User-Agent": "spyder-ai-chat/0.1.2",
            }
            if self._key:
                headers["Authorization"] = f"Bearer {self._key}"
            req = urllib.request.Request(
                f"{self._url}/chat/completions",
                data=payload, headers=headers, method="POST")
            try:
                resp_cm = urllib.request.urlopen(req, timeout=120)
            except urllib.error.HTTPError as e:
                try:
                    body = e.read().decode(errors="replace")[:300]
                except Exception:
                    body = ""
                self.error.emit(f"HTTP {e.code} {e.reason}: {body}")
                return
            with resp_cm as resp:
                for raw in resp:
                    if self._stop:
                        break
                    line = raw.decode().strip()
                    if not line or line == "data: [DONE]":
                        continue
                    if line.startswith("data: "):
                        line = line[6:]
                    try:
                        d = json.loads(line)
                        t = d["choices"][0]["delta"].get("content", "")
                        if t:
                            self.chunk_ready.emit(t)
                    except Exception:
                        pass
        except Exception as exc:
            self.error.emit(str(exc))
        finally:
            self.finished.emit()


# ---------------------------------------------------------------------------
# Inference Parameters Popup
# ---------------------------------------------------------------------------
class _InferParamsPopup(QFrame):
    """
    Popup for configuring per-chat inference hyperparameters.
    Shows all params supported by the current provider as a flat form.
    No scroll bar — the popup expands to fit its content naturally.
    Anchors ABOVE the button that opens it.
    Changes apply immediately to the parent panel's _infer_params dict.
    """

    def __init__(self, parent=None):
        super().__init__(parent, Qt.Popup | Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_StyledBackground, True)
        self.setMinimumWidth(320)
        self.setMaximumWidth(420)

        self._panel = None
        self._provider_id = "custom"

        # Outer layout — no scroll area; just a plain VBox that sizes to content
        self._outer = QVBoxLayout(self)
        self._outer.setContentsMargins(8, 8, 8, 8)
        self._outer.setSpacing(4)

        # Header row
        hdr = QHBoxLayout()
        hdr.setContentsMargins(0, 0, 0, 2)
        hdr_lbl = QLabel("Inference Parameters")
        hdr_lbl.setStyleSheet("font-weight: bold; font-size: 11px;")
        hdr.addWidget(hdr_lbl, 1)
        self._reset_btn = QPushButton("Reset to defaults")
        self._reset_btn.setFlat(True)
        self._reset_btn.setStyleSheet(
            "QPushButton { color: #888; font-size: 9px; padding: 1px 6px; "
            "border: 1px solid #555; border-radius: 3px; }"
            "QPushButton:hover { color: #f88; border-color: #f88; }")
        self._reset_btn.clicked.connect(self._on_reset)
        hdr.addWidget(self._reset_btn)
        self._outer.addLayout(hdr)

        sep = QFrame()
        sep.setFrameShape(QFrame.HLine)
        sep.setStyleSheet("color: #444;")
        self._outer.addWidget(sep)

        # Placeholder — will be replaced by _rebuild_controls()
        self._form_widget = QWidget()
        self._outer.addWidget(self._form_widget)

        # Notes label (provider-specific warnings)
        self._notes_lbl = QLabel()
        self._notes_lbl.setWordWrap(True)
        self._notes_lbl.setStyleSheet(
            "color: #c8a000; font-size: 9pt; padding: 4px 2px 0 2px;")
        self._notes_lbl.setVisible(False)
        self._outer.addWidget(self._notes_lbl)

    # ── public API ────────────────────────────────────────────────────

    def show_above(self, btn, panel):
        """Build controls for panel's current provider and show above btn."""
        self._panel = panel
        state = panel._load_state()
        self._provider_id = state.get("provider_type", "custom")
        self._rebuild_controls()

        # Let Qt compute the natural size before positioning
        self.adjustSize()

        # Anchor: bottom-right of popup aligns to top-right of button
        btn_top_right = btn.mapToGlobal(btn.rect().topRight())
        popup_x = btn_top_right.x() - self.width()
        popup_y = btn_top_right.y() - self.height()

        # Clamp to screen
        try:
            screen = QApplication.primaryScreen().availableGeometry()
            popup_x = max(screen.left(), min(popup_x, screen.right() - self.width()))
            popup_y = max(screen.top(), popup_y)
        except Exception:
            pass

        self.move(popup_x, popup_y)
        self.show()
        self.raise_()

    # ── control building ──────────────────────────────────────────────

    def _rebuild_controls(self):
        """Replace form widget with fresh controls for the current provider."""
        # Detach old form widget and schedule deletion
        old = self._form_widget
        old.setParent(None)
        old.deleteLater()

        pdef      = PROVIDERS.get(self._provider_id, PROVIDERS["custom"])
        supported = pdef["supported_params"]
        temp_max  = pdef.get("temperature_max", 2.0)
        params    = self._panel._infer_params if self._panel else {}

        # All params in display order (basic first, then advanced — no toggle)
        all_params = [
            "temperature", "max_tokens", "top_p",
            "presence_penalty", "frequency_penalty",
            "top_k", "min_p", "repetition_penalty",
            "seed", "num_ctx",
        ]

        self._form_widget = QWidget()
        form_lay = QVBoxLayout(self._form_widget)
        form_lay.setContentsMargins(0, 4, 0, 0)
        form_lay.setSpacing(4)

        self._ctrl_widgets = {}

        for pid in all_params:
            if pid not in supported:
                continue
            pinfo = PARAM_DEFS[pid]
            t_max = temp_max if pid == "temperature" else None
            row   = self._make_param_row(pid, pinfo, params, t_max)
            form_lay.addWidget(row)

        # Insert before notes label (which is the last item in outer)
        # outer layout: hdr(0), sep(1), form(2-old→removed), notes(last)
        # After removing old form we insert at position 2
        self._outer.insertWidget(2, self._form_widget)

        # Notes
        notes = pdef.get("notes", "")
        self._notes_lbl.setText(notes)
        self._notes_lbl.setVisible(bool(notes))

    def _make_param_row(self, pid, pinfo, current_params, temp_max=None):
        """Create a single label + spinbox row."""
        label_text, ptype, prange, tooltip = pinfo

        row = QWidget()
        rl  = QHBoxLayout(row)
        rl.setContentsMargins(2, 1, 2, 1)
        rl.setSpacing(8)

        lbl = QLabel(label_text + ":")
        lbl.setFixedWidth(140)
        lbl.setStyleSheet("font-size: 9pt;")
        lbl.setToolTip(tooltip)
        rl.addWidget(lbl)

        current_val = current_params.get(pid)

        if ptype == "float":
            lo, hi = prange
            if temp_max is not None:
                hi = temp_max

            sp = QDoubleSpinBox()
            sp.setRange(lo, hi)
            sp.setSingleStep(0.05)
            sp.setDecimals(2)
            sp.setFixedWidth(90)
            # 0.0 as minimum → special "default" text
            sp.setSpecialValueText("default")
            sp.setValue(float(current_val) if current_val is not None else 0.0)

            def _on_float(val, p=pid, s=sp):
                if not self._panel:
                    return
                if val == s.minimum():
                    self._panel._infer_params.pop(p, None)
                else:
                    self._panel._infer_params[p] = val
                self._panel._update_summary_bar()

            sp.valueChanged.connect(_on_float)
            rl.addWidget(sp)
            self._ctrl_widgets[pid] = sp

        elif ptype == "int":
            _, hi = prange
            sp = QSpinBox()
            sp.setRange(0, hi)   # 0 = "default"
            sp.setFixedWidth(100)
            sp.setSpecialValueText("default")
            sp.setValue(int(current_val) if current_val is not None else 0)

            def _on_int(val, p=pid):
                if not self._panel:
                    return
                if val == 0:
                    self._panel._infer_params.pop(p, None)
                else:
                    self._panel._infer_params[p] = val
                self._panel._update_summary_bar()

            sp.valueChanged.connect(_on_int)
            rl.addWidget(sp)
            self._ctrl_widgets[pid] = sp

        rl.addStretch()
        return row

    def _on_reset(self):
        if self._panel:
            self._panel._infer_params.clear()
            self._panel._update_summary_bar()
        self._rebuild_controls()
        self.adjustSize()


# ---------------------------------------------------------------------------
# Model dropdown popup
# ---------------------------------------------------------------------------
class _ModelPopup(QFrame):
    selected = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent, Qt.Popup | Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_StyledBackground, True)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(1, 1, 1, 1)
        lay.setSpacing(0)
        self._lw = QListWidget()
        self._lw.setFrameShape(QFrame.NoFrame)
        self._lw.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self._lw.itemClicked.connect(
            lambda item: (self.selected.emit(item.text()), self.hide()))
        lay.addWidget(self._lw)

    def _apply_theme(self):
        """Inherit application theme — no custom stylesheet needed."""
        self.setStyleSheet("")
        self._lw.setStyleSheet("")

    def show_below(self, btn, models, current):
        self._apply_theme()
        self._lw.clear()
        for m in models:
            item = QListWidgetItem(m)
            if m == current:
                f = item.font(); f.setBold(True); item.setFont(f)
            self._lw.addItem(item)
        row_h = max(self._lw.sizeHintForRow(0), 24)
        self._lw.setFixedHeight(min(row_h * len(models) + 4, 350))
        self.setFixedWidth(max(btn.width(), 200))
        self.adjustSize()
        self.move(btn.mapToGlobal(btn.rect().bottomLeft()))
        self.show()
        self.raise_()


from .markdown_renderer import (
    render_markdown, parse_blocks,
    build_heading, build_paragraph, build_code_block, build_hr,
    build_blockquote, build_list, build_table, build_think,
)
from .settings_dialog import (
    SettingsDialog, EDITOR_DEFAULTS, HISTORY_DEFAULTS,
    PROVIDERS, PROVIDER_ORDER, PARAM_DEFS,
)
from .system_prompts import load_prompts, get_prompt, CUSTOM_ID


# ---------------------------------------------------------------------------
# Helper: assemble LLM message content from structured storage
# ---------------------------------------------------------------------------
def _build_llm_content(msg):
    """
    Build the content string to send to the LLM from a stored message dict.
    New format: {"role": "user", "content": "user text",
                 "content_llm": "expanded command text (if commands were used)",
                 "command_spans": [[start, length], ...],
                 "attachments": [{"name": "file.py", "content": "..."}]}
    Old format: {"role": "user", "content": "File: ...\n```\n...\n```\n\ntext"}
                 — returned as-is for backwards compatibility.
    content_llm is used when present so the original expansion is preserved
    even if the command is later edited or deleted in Settings.
    """
    import os
    text        = msg.get("content_llm") or msg.get("content", "")
    attachments = msg.get("attachments", [])
    if not attachments:
        return text  # no attachments, or legacy format

    parts = []
    for att in attachments:
        name    = att.get("name", "")
        content = att.get("content", "")
        ext  = os.path.splitext(name)[1].lower()
        lang = {".py": "python", ".js": "javascript", ".ts": "typescript",
                ".html": "html", ".css": "css", ".json": "json",
                ".md": "markdown", ".txt": ""}.get(ext, "")
        fence = f"```{lang}" if lang else "```"
        parts.append(f"File: {name}\n{fence}\n{content}\n```")
    file_block = "\n\n".join(parts)
    return f"{file_block}\n\n{text}"


# ---------------------------------------------------------------------------
# The chat history display
# ---------------------------------------------------------------------------
class _ChatHistory(QWidget):

    insert_to_editor = Signal(str)

    _SPINNER_FRAMES = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]

    def __init__(self, parent=None):
        super().__init__(parent)
        self._lay = QVBoxLayout(self)
        self._lay.setContentsMargins(4, 4, 4, 4)
        self._lay.setSpacing(6)
        self._lay.setAlignment(Qt.AlignTop)
        # Expand horizontally to fill scroll area width (needed for word-wrap),
        # but only take as much vertical space as the content actually needs
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        self._blocks = []
        self._stream_container = None
        self._stream_lbl       = None
        self._spinner_lbl      = None
        self._spinner_timer    = None
        self._spinner_frame    = 0
        self._rendered_zone          = None  # QVBoxLayout for incrementally rendered blocks
        self._rendered_block_count   = 0     # blocks already pushed to _rendered_zone
        self._scroll_to_bottom_cb = None  # callable, fired once after next resize

    # Signal(block_index, delete_before_too, role)
    # Signal(block_index, delete_before_too)
    delete_exchange = Signal(int, bool)
    # Signal() — regenerate the last assistant response
    regenerate = Signal()

    def _make_delete_bar(self, block_idx_fn):
        """
        Return a QWidget containing the delete action buttons for one message.
        block_idx_fn: callable returning the current block index at click time.
        """
        bar = QWidget()
        bar.setStyleSheet("background: transparent;")
        bl = QHBoxLayout(bar)
        bl.setContentsMargins(0, 0, 0, 0)
        bl.setSpacing(4)
        bl.addStretch()

        btn_this   = QPushButton("🗑 This")
        btn_before = QPushButton("⏫ All before")
        btn_this.setToolTip(
            "Delete this exchange (your message + assistant reply) from the chat")
        btn_before.setToolTip(
            "Delete all exchanges before this one (keeps this exchange)")
        for btn in (btn_this, btn_before):
            btn.setFlat(True)
            btn.setStyleSheet(
                "QPushButton { color: #888; font-size: 9px; padding: 1px 5px; "
                "border: 1px solid #555; border-radius: 3px; background: transparent; }"
                "QPushButton:hover { color: #f88; border-color: #f88; }")
        bl.addWidget(btn_before)
        bl.addWidget(btn_this)

        _state = {"timer": None, "pending": None}

        def _arm(delete_before):
            if _state["timer"] is not None:
                _state["timer"].stop()
            _state["pending"] = delete_before
            btn_this.setVisible(False)
            btn_before.setVisible(False)
            cancel_btn.setText("↩ Cancel (3)")
            cancel_btn.setVisible(True)
            remaining = [3]

            def _tick():
                remaining[0] -= 1
                if remaining[0] > 0:
                    cancel_btn.setText(f"↩ Cancel ({remaining[0]})")
                else:
                    _state["timer"].stop()
                    cancel_btn.setVisible(False)
                    btn_this.setVisible(True)
                    btn_before.setVisible(True)
                    self.delete_exchange.emit(block_idx_fn(), _state["pending"])

            t = QTimer(bar)
            t.setInterval(1000)
            t.timeout.connect(_tick)
            t.start()
            _state["timer"] = t

        def _cancel():
            if _state["timer"]:
                _state["timer"].stop()
                _state["timer"] = None
            cancel_btn.setVisible(False)
            btn_this.setVisible(True)
            btn_before.setVisible(True)

        cancel_btn = QPushButton("↩ Cancel (3)")
        cancel_btn.setFlat(True)
        cancel_btn.setStyleSheet(
            "QPushButton { color: #f88; font-size: 9px; padding: 1px 5px; "
            "border: 1px solid #f88; border-radius: 3px; background: transparent; }"
            "QPushButton:hover { color: #fcc; border-color: #fcc; }")
        cancel_btn.setVisible(False)
        cancel_btn.clicked.connect(_cancel)
        bl.addWidget(cancel_btn)

        btn_this.clicked.connect(lambda: _arm(False))
        btn_before.clicked.connect(lambda: _arm(True))

        return bar

    def _make_regenerate_btn(self):
        """Return a small Regenerate button that emits self.regenerate."""
        btn = QPushButton("🔄 Regenerate")
        btn.setFlat(True)
        btn.setToolTip("Discard this response and ask the model to answer again")
        btn.setStyleSheet(
            "QPushButton { color: #888; font-size: 9px; padding: 1px 5px; "
            "border: 1px solid #555; border-radius: 3px; background: transparent; }"
            "QPushButton:hover { color: #4ec9b0; border-color: #4ec9b0; }")
        btn.clicked.connect(self.regenerate.emit)
        return btn

    def _update_regenerate_button(self):
        """
        Ensure only the last assistant block has a Regenerate button.
        Scans all blocks, removes any existing regenerate buttons,
        then injects one into the last assistant block's title row.
        """
        # Remove existing regenerate buttons from all title rows
        for role, container in self._blocks:
            lay = container.layout()
            if lay and lay.count() > 0:
                first_item = lay.itemAt(0)
                if first_item and first_item.layout():
                    title_row = first_item.layout()
                    for i in range(title_row.count() - 1, -1, -1):
                        item = title_row.itemAt(i)
                        if item and item.widget():
                            w = item.widget()
                            if (isinstance(w, QPushButton) and
                                    "Regenerate" in w.text()):
                                title_row.removeWidget(w)
                                w.deleteLater()

        # Find last assistant or error block and inject regenerate button
        last_asst = None
        for role, container in reversed(self._blocks):
            if role in ("assistant", "assistant_error"):
                last_asst = container
                break
        if last_asst is None:
            return
        lay = last_asst.layout()
        if lay and lay.count() > 0:
            first_item = lay.itemAt(0)
            if first_item and first_item.layout():
                title_row = first_item.layout()
                # Insert before the delete bar (last widget)
                regen_btn = self._make_regenerate_btn()
                title_row.insertWidget(title_row.count() - 1, regen_btn)

    def request_scroll_to_bottom(self, callback):
        """Ask to fire callback once after the next resize (layout settled)."""
        self._scroll_to_bottom_cb = callback

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if self._scroll_to_bottom_cb is not None:
            cb = self._scroll_to_bottom_cb
            self._scroll_to_bottom_cb = None
            cb()

    # ── user bubble ───────────────────────────────────────────────────
    def add_user(self, text, attachments=None, command_spans=None):
        """
        Add a user message bubble.
        attachments:    optional list of attachment name strings (locked badges).
        command_spans:  optional list of (start, length) tuples marking active
                        command tokens — rendered with a green highlight.
        """
        container = QWidget()
        container.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        cl = QVBoxLayout(container)
        cl.setContentsMargins(0, 0, 0, 0)
        cl.setSpacing(2)

        # Title row: "You:" on left, delete buttons on right
        title_row = QHBoxLayout()
        title_row.setContentsMargins(0, 0, 0, 0)
        title = QLabel("<b>You:</b>")
        title.setStyleSheet("color: #569cd6;")
        title_row.addWidget(title)
        title_row.addStretch()
        block_idx_fn = lambda: next(
            (i for i, b in enumerate(self._blocks) if b[1] is container), -1)
        title_row.addWidget(self._make_delete_bar(block_idx_fn))
        cl.addLayout(title_row)

        # Build label content — highlight command spans if present
        if command_spans:
            # Build rich-text with highlighted command tokens
            import html as _html
            spans = sorted(command_spans, key=lambda s: s[0])
            result = ""
            prev = 0
            for (s, l) in spans:
                result += _html.escape(text[prev:s])
                result += (
                    f'<span style="background:#2a3a1a; color:#b8e090; '
                    f'border-radius:3px; padding:0 2px;">'
                    f'{_html.escape(text[s:s+l])}</span>'
                )
                prev = s + l
            result += _html.escape(text[prev:])
            # Preserve newlines
            result = result.replace("\n", "<br>")
            w = QLabel(result)
            w.setTextFormat(Qt.RichText)
        else:
            w = QLabel(text)
            w.setTextFormat(Qt.PlainText)

        w.setWordWrap(True)
        w.setFont(QFont("Monospace", 10))
        w.setStyleSheet(
            "background: transparent; border-left: 3px solid #569cd6; "
            "padding: 4px 8px;")
        w.setTextInteractionFlags(
            Qt.TextSelectableByMouse | Qt.TextSelectableByKeyboard)
        cl.addWidget(w)

        # Locked attachment badges (no X button — already sent)
        if attachments:
            badge_row = QWidget()
            badge_row.setStyleSheet("background: transparent;")
            bl = QHBoxLayout(badge_row)
            bl.setContentsMargins(8, 2, 0, 0)
            bl.setSpacing(4)
            for name in attachments:
                icon = "✂" if " selection" in name else "📎"
                tag = QFrame()
                tag.setStyleSheet(
                    "QFrame { background: #1e3a1e; border: 1px solid #3a6a3a; "
                    "border-radius: 3px; }")
                tl = QHBoxLayout(tag)
                tl.setContentsMargins(5, 1, 5, 1)
                tl.setSpacing(3)
                lbl = QLabel(f"{icon} {name}")
                lbl.setStyleSheet(
                    "color: #7ec87e; font-size: 9px; border: none; "
                    "background: transparent;")
                tl.addWidget(lbl)
                bl.addWidget(tag)
            bl.addStretch()
            cl.addWidget(badge_row)

        self._lay.addWidget(container)
        self._blocks.append(("user", container))

    # ── assistant: streaming placeholder ─────────────────────────────
    def add_assistant_start(self):
        """Create a plain streaming label. Returns the QLabel to write into."""
        container = QWidget()
        container.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        cl = QVBoxLayout(container)
        cl.setContentsMargins(0, 0, 0, 0)
        cl.setSpacing(2)

        # Title row: "Assistant:" on left, delete buttons on right
        title_row = QHBoxLayout()
        title_row.setContentsMargins(0, 0, 0, 0)
        title = QLabel("<b>Assistant:</b>")
        title.setStyleSheet("color: #4ec9b0;")
        title_row.addWidget(title)
        title_row.addStretch()
        block_idx_fn = lambda: next(
            (i for i, b in enumerate(self._blocks) if b[1] is container), -1)
        title_row.addWidget(self._make_delete_bar(block_idx_fn))
        cl.addLayout(title_row)
        # Spinner shown while waiting for the first response token
        spinner = QLabel(self._SPINNER_FRAMES[0])
        spinner.setStyleSheet(
            "color: #4ec9b0; font-size: 14px; padding: 4px 8px;")
        cl.addWidget(spinner)
        self._spinner_lbl   = spinner
        self._spinner_frame = 0
        timer = QTimer(self)
        timer.timeout.connect(self._spinner_tick)
        timer.start(80)
        self._spinner_timer = timer

        # Rendered zone: completed blocks are added here incrementally
        rz_widget = QWidget()
        rz_widget.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        self._rendered_zone = QVBoxLayout(rz_widget)
        self._rendered_zone.setContentsMargins(0, 0, 0, 0)
        self._rendered_zone.setSpacing(3)
        self._rendered_block_count = 0
        cl.addWidget(rz_widget)

        # Tail label: shows the current (potentially incomplete) block as plain text
        lbl = QLabel()
        lbl.setWordWrap(True)
        lbl.setTextFormat(Qt.PlainText)
        lbl.setFont(QFont("Monospace", 10))
        lbl.setStyleSheet(
            "background: transparent; border-left: 3px solid #4ec9b0; "
            "padding: 4px 8px;")
        lbl.setTextInteractionFlags(
            Qt.TextSelectableByMouse | Qt.TextSelectableByKeyboard)
        lbl.hide()   # shown only after first response token arrives
        cl.addWidget(lbl)
        self._lay.addWidget(container)
        self._blocks.append(("assistant_streaming", container))
        self._stream_container = container
        self._stream_lbl       = lbl
        return lbl

    def _spinner_tick(self):
        if self._spinner_lbl is None:
            return
        self._spinner_frame = (self._spinner_frame + 1) % len(self._SPINNER_FRAMES)
        self._spinner_lbl.setText(self._SPINNER_FRAMES[self._spinner_frame])

    def hide_spinner(self):
        """Stop and remove the waiting spinner (called on first chunk or error)."""
        if self._spinner_timer is not None:
            self._spinner_timer.stop()
            self._spinner_timer = None
        if self._spinner_lbl is not None:
            self._spinner_lbl.setParent(None)
            self._spinner_lbl.deleteLater()
            self._spinner_lbl = None

    def push_rendered_widget(self, widget):
        """Append a pre-built widget to the rendered zone (no block parsing)."""
        if self._rendered_zone is None:
            return
        self._rendered_zone.addWidget(widget)
        self._rendered_block_count += 1

    def push_rendered_block(self, block):
        """Build one block widget and append it to the rendered zone."""
        if self._rendered_zone is None:
            return
        from .settings_dialog import EDITOR_DEFAULTS
        cfg = {**EDITOR_DEFAULTS, **(getattr(self, "_font_cfg", None) or {})}
        try:
            from spyder.config.gui import is_dark_interface
            text_color = "#d4d4d4" if is_dark_interface() else "#1a1a1a"
        except Exception:
            text_color = "#d4d4d4"
        t = block["type"]
        if   t == "heading":    w = build_heading(block, cfg["fs_heading"])
        elif t == "paragraph":  w = build_paragraph(block, text_color, cfg["fs_base"])
        elif t == "code":       w = build_code_block(block, self.insert_to_editor, cfg["fs_code"])
        elif t == "hr":         w = build_hr()
        elif t == "blockquote": w = build_blockquote(block, text_color, cfg["fs_base"])
        elif t == "list":       w = build_list(block, text_color, cfg["fs_list"])
        elif t == "table":      w = build_table(block, cfg["fs_table"])
        elif t == "think":      w = build_think(block, cfg["fs_think"])
        else:                   return
        self._rendered_zone.addWidget(w)
        self._rendered_block_count += 1

    def show_error(self, msg):
        """Display an error response in a dark-red styled box. No Regenerate button."""
        self.hide_spinner()
        if self._stream_container is None:
            container = QWidget()
            container.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
            cl = QVBoxLayout(container)
            cl.setContentsMargins(0, 0, 0, 0)
            cl.setSpacing(2)
            title_row = QHBoxLayout()
            title_row.setContentsMargins(0, 0, 0, 0)
            title = QLabel("<b>Assistant:</b>")
            title.setStyleSheet("color: #4ec9b0;")
            title_row.addWidget(title)
            title_row.addStretch()
            block_idx_fn = lambda c=container: next(
                (i for i, b in enumerate(self._blocks) if b[1] is c), -1)
            title_row.addWidget(self._make_delete_bar(block_idx_fn))
            cl.addLayout(title_row)
            self._lay.addWidget(container)
            self._blocks.append(("assistant_streaming", container))
            self._stream_container = container
            self._stream_lbl = None

        container = self._stream_container
        cl = container.layout()

        if self._stream_lbl is not None:
            self._stream_lbl.setParent(None)
            self._stream_lbl.deleteLater()
            self._stream_lbl = None

        header = QLabel("⚠ Response error occurred")
        header.setStyleSheet(
            "color: #ff6b6b; font-weight: bold; background: #3d1515; "
            "border-radius: 3px; padding: 4px 8px;")
        cl.addWidget(header)

        err_lbl = QLabel(msg)
        err_lbl.setWordWrap(True)
        err_lbl.setTextFormat(Qt.PlainText)
        err_lbl.setStyleSheet(
            "color: #ffaaaa; background: #2a0d0d; "
            "border-left: 3px solid #8b2020; padding: 6px 10px;")
        err_lbl.setTextInteractionFlags(
            Qt.TextSelectableByMouse | Qt.TextSelectableByKeyboard)
        cl.addWidget(err_lbl)

        for i, b in enumerate(self._blocks):
            if b[0] == "assistant_streaming" and b[1] is container:
                self._blocks[i] = ("assistant_error", container)
                break

        self._stream_container = None
        self._update_regenerate_button()

    # ── assistant: finalize with parsed code blocks ───────────────────
    def finalize_assistant(self, full_text):
        """
        Finalize a streaming response: render any not-yet-rendered blocks,
        remove the tail label, and add the 'Copy to editor' button if needed.
        Works both after streaming (container exists) and when loading from file.
        """
        self.hide_spinner()
        # If no streaming container exists (e.g. loading from file), create one now
        if self._stream_container is None:
            container = QWidget()
            container.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
            cl = QVBoxLayout(container)
            cl.setContentsMargins(0, 0, 0, 0)
            cl.setSpacing(2)
            title_row = QHBoxLayout()
            title_row.setContentsMargins(0, 0, 0, 0)
            title = QLabel("<b>Assistant:</b>")
            title.setStyleSheet("color: #4ec9b0;")
            title_row.addWidget(title)
            title_row.addStretch()
            block_idx_fn = lambda c=container: next(
                (i for i, b in enumerate(self._blocks) if b[1] is c), -1)
            title_row.addWidget(self._make_delete_bar(block_idx_fn))
            cl.addLayout(title_row)
            # Rendered zone for this (file-load) container
            rz_widget = QWidget()
            rz_widget.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
            self._rendered_zone = QVBoxLayout(rz_widget)
            self._rendered_zone.setContentsMargins(0, 0, 0, 0)
            self._rendered_zone.setSpacing(3)
            self._rendered_block_count = 0
            cl.addWidget(rz_widget)
            self._lay.addWidget(container)
            self._blocks.append(("assistant_streaming", container))
            self._stream_container = container
            self._stream_lbl = None

        container = self._stream_container

        # Remove the tail (plain-text streaming) label
        if self._stream_lbl is not None:
            self._stream_lbl.setParent(None)
            self._stream_lbl.deleteLater()
            self._stream_lbl = None

        # Render any blocks not yet pushed during streaming
        blocks = parse_blocks(full_text)
        has_code = any(b["type"] == "code" for b in blocks)
        for block in blocks[self._rendered_block_count:]:
            self.push_rendered_block(block)

        # 'Copy to editor' button (only when response has no code blocks)
        if not has_code and self._rendered_zone is not None:
            btn_row = QHBoxLayout()
            btn_row.addStretch()
            copy_all = QPushButton("📋 Copy to editor")
            copy_all.setFlat(True)
            copy_all.setStyleSheet(
                "QPushButton { color: #888; font-size: 10px; padding: 1px 4px; "
                "border: none; background: transparent; }"
                "QPushButton:hover { color: #ccc; }")
            copy_all.setToolTip("Insert full response at cursor in current editor")
            copy_all.clicked.connect(
                lambda checked=False, t=full_text: self.insert_to_editor.emit(t))
            btn_row.addWidget(copy_all)
            self._rendered_zone.addLayout(btn_row)

        # Update block record
        for i, b in enumerate(self._blocks):
            if b[0] == "assistant_streaming" and b[1] is container:
                self._blocks[i] = ("assistant", container)
                break

        self._stream_container     = None
        self._rendered_zone        = None
        self._rendered_block_count = 0
        self._update_regenerate_button()

    def clear_all(self):
        for _, container in self._blocks:
            container.deleteLater()
        self._blocks.clear()
        self._stream_container     = None
        self._stream_lbl           = None
        self._rendered_zone        = None
        self._rendered_block_count = 0
        self.hide_spinner()


# ---------------------------------------------------------------------------
# Main chat panel — pure QWidget, no PluginMainWidget inheritance
# ---------------------------------------------------------------------------
class AIChatPanel(QWidget):

    _sig_models_ok  = Signal(list)
    _sig_models_err = Signal(str)

    def __init__(self, get_conf, set_conf, get_editor_cursor, parent=None):
        super().__init__(parent)
        self._get_editor_cursor = get_editor_cursor
        self._messages         = []
        self._assistant_buf    = ""
        self._model_list       = list(DEFAULT_MODELS)
        self._current_model    = DEFAULT_MODELS[0]
        self._fetching         = False
        self._chat_thread      = None
        self._chat_worker      = None
        self._current_lbl      = None
        self._context_files    = []   # list of (name, content) added as context
        self._selection_counters = {}  # filename -> selection count
        self._current_chat_file = None  # filename of currently saved chat
        self._auto_scroll = True
        self._sp_selected_id = CUSTOM_ID  # currently selected system prompt id
        self._hist_popup = None           # created lazily
        self._params_popup = None         # created lazily
        # Per-chat inference params: only explicitly-set values (empty = use defaults)
        self._infer_params: dict = {}
        # Provider type active when this chat was opened (used to detect provider change)
        self._chat_provider: str = ""
        self._worker_had_error  = False
        self._rendered_char_end = 0   # chars of _assistant_buf already in rendered zone
        # Live streaming code block: QPlainTextEdit inside the in-progress widget
        self._streaming_code_edit = None

        self._sig_models_ok.connect(self._on_models_ok)
        self._sig_models_err.connect(self._on_models_err)

        # Load persisted state from local JSON file (reliable across restarts)
        self._state = self._load_state()
        saved_models = self._state.get("model_list", [])
        if saved_models:
            self._model_list = saved_models
        saved_sel = self._state.get("selected_model", "")
        if saved_sel and saved_sel in self._model_list:
            self._current_model = saved_sel
        elif self._model_list:
            self._current_model = self._model_list[0]

        self._popup = None  # created lazily on first use

        self._build_ui()

        # Initialise chat_provider from global state (before any chat is loaded)
        self._chat_provider = self._load_state().get("provider_type", "openai")

        # Restore last open chat after the widget is first shown
        self._last_chat_restored = False

    def showEvent(self, event):
        super().showEvent(event)
        if not self._last_chat_restored:
            self._last_chat_restored = True
            last = self._load_state().get("last_chat_file")
            if last:
                from .chat_history_manager import load_chat as _lc
                if _lc(last) is not None:  # file still exists
                    QTimer.singleShot(100, lambda: self._load_chat_from_file(last))

    # ── persistent state helpers ──────────────────────────────────────
    @staticmethod
    def _state_path():
        import os
        home = os.path.expanduser("~")
        d = os.path.join(home, ".spyder_ai_chat")
        os.makedirs(d, exist_ok=True)
        return os.path.join(d, "state.json")

    def _load_state(self):
        try:
            with open(self._state_path(), "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}

    def _save_state(self, **kwargs):
        state = self._load_state()
        state.update(kwargs)
        try:
            with open(self._state_path(), "w", encoding="utf-8") as f:
                json.dump(state, f, indent=2)
        except Exception:
            pass

    def _build_ui(self):
        # ── top bar ───────────────────────────────────────────────────
        top = QHBoxLayout()
        top.setContentsMargins(4, 4, 4, 2)
        top.setSpacing(4)

        self._model_btn = QPushButton(self._current_model + " ▾")
        self._model_btn.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self._model_btn.setToolTip("Select model")
        self._model_btn.clicked.connect(self._toggle_popup)
        top.addWidget(self._model_btn)

        self._reload_btn = QPushButton("⟳")
        self._reload_btn.setToolTip("Reload model list from API")
        self._reload_btn.setFixedWidth(36)
        self._reload_btn.setStyleSheet(
            "QPushButton { font-size: 16px; font-weight: bold; padding: 0px; }")
        self._reload_btn.clicked.connect(self._reload_models)
        top.addWidget(self._reload_btn)

        self._new_btn = QPushButton("🗑 New Chat")
        self._new_btn.setToolTip("Clear conversation and start fresh")
        self._new_btn.clicked.connect(self._new_chat)
        top.addWidget(self._new_btn)

        self._cfg_btn = QPushButton("⚙ Settings")
        self._cfg_btn.clicked.connect(self._open_settings)
        top.addWidget(self._cfg_btn)

        self._hist_btn = QPushButton()
        self._hist_btn.setToolTip("Chat history")
        self._hist_btn.setFixedSize(28, 24)
        self._hist_btn.setStyleSheet("QPushButton { padding: 1px; border: none; }")
        # Inline SVG: document with checkmark lines
        _svg = b"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
  <path d="M6 2h9l4 4v16H5V2z" fill="none" stroke="currentColor" stroke-width="1.5"/>
  <path d="M14 2v5h5" fill="none" stroke="currentColor" stroke-width="1.5"/>
  <path d="M7 10l1.5 1.5L11 9" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
  <line x1="12.5" y1="10" x2="17" y2="10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
  <path d="M7 14l1.5 1.5L11 13" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
  <line x1="12.5" y1="14" x2="17" y2="14" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
  <path d="M7 18l1.5 1.5L11 17" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
  <line x1="12.5" y1="18" x2="17" y2="18" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
</svg>"""
        from qtpy.QtSvg import QSvgRenderer
        from qtpy.QtGui import QPixmap, QPainter, QColor
        from qtpy.QtCore import QByteArray
        try:
            # Try to get foreground color from theme
            from spyder.config.gui import is_dark_interface
            icon_color = "#d4d4d4" if is_dark_interface() else "#333333"
        except Exception:
            icon_color = "#d4d4d4"
        svg_colored = _svg.replace(b"currentColor", icon_color.encode())
        renderer = QSvgRenderer(QByteArray(svg_colored))
        pixmap = QPixmap(16, 16)
        pixmap.fill(Qt.transparent)
        painter = QPainter(pixmap)
        renderer.render(painter)
        painter.end()
        from qtpy.QtGui import QIcon
        self._hist_btn.setIcon(QIcon(pixmap))
        self._hist_btn.setIconSize(pixmap.size())
        self._hist_btn.clicked.connect(self._toggle_history_popup)
        top.addWidget(self._hist_btn)

        # ── scrollable chat history ───────────────────────────────────
        from qtpy.QtWidgets import QScrollArea
        self._history = _ChatHistory()
        self._history._font_cfg = self._editor_cfg()
        self._history.setMinimumWidth(400)
        self._history.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        scroll = QScrollArea()
        scroll.setWidget(self._history)
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setFrameShape(QFrame.NoFrame)
        self._scroll = scroll
        self._auto_scroll = True
        scroll.verticalScrollBar().rangeChanged.connect(self._on_scroll_range_changed)

        # ── file context bar ──────────────────────────────────────────
        # Shows dismissible tags for files added as context
        self._ctx_bar = QWidget()
        self._ctx_bar.setVisible(False)
        self._ctx_bar_layout = QHBoxLayout(self._ctx_bar)
        self._ctx_bar_layout.setContentsMargins(4, 2, 4, 2)
        self._ctx_bar_layout.setSpacing(4)
        self._ctx_bar_layout.addStretch()

        # ══════════════════════════════════════════════════════════════
        # ROW 1: Inference params summary (always visible) + config btn
        # ══════════════════════════════════════════════════════════════
        params_row = QHBoxLayout()
        params_row.setContentsMargins(2, 1, 2, 1)
        params_row.setSpacing(4)

        # Summary label — always shown, clickable, opens params popup
        self._params_bar_lbl = QPushButton("Click to set inference params")
        self._params_bar_lbl.setFlat(True)
        self._params_bar_lbl.setStyleSheet(_PARAMS_BAR_IDLE_STYLE)
        self._params_bar_lbl.setToolTip("Click to configure inference parameters (temperature, max tokens…)")
        self._params_bar_lbl.clicked.connect(self._toggle_params_popup)
        self._params_bar_lbl.setFixedHeight(24)
        params_row.addWidget(self._params_bar_lbl, 1)

        # Wrap in a widget
        params_bar_w = QWidget()
        params_bar_w.setLayout(params_row)
        self._params_bar = params_bar_w

        # ══════════════════════════════════════════════════════════════
        # ROW 2: System prompts selector + ↓ Copy to field button
        # ══════════════════════════════════════════════════════════════
        sp_bar = QWidget()
        sp_bar_lay = QHBoxLayout(sp_bar)
        sp_bar_lay.setContentsMargins(0, 0, 0, 0)
        sp_bar_lay.setSpacing(4)

        sp_lbl = QLabel("System prompts:")
        sp_lbl.setStyleSheet("font-size: 9pt; color: gray;")
        sp_lbl.setFixedWidth(100)
        sp_bar_lay.addWidget(sp_lbl)

        self._sp_combo = QComboBox()
        self._sp_combo.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self._sp_combo.setStyleSheet("font-size: 9pt;")
        sp_bar_lay.addWidget(self._sp_combo, 1)

        # ⚙ Settings button → opens Settings on the System Prompts tab
        self._sp_settings_btn = QPushButton("⚙")
        self._sp_settings_btn.setFixedSize(24, 24)
        self._sp_settings_btn.setToolTip("Manage system prompts in Settings")
        self._sp_settings_btn.setStyleSheet(
            "QPushButton { font-size: 12px; padding: 0; border: 1px solid #555; "
            "border-radius: 3px; color: #aaa; }"
            "QPushButton:hover { color: #fff; border-color: #aaa; }"
            "QPushButton:pressed { color: #c8a000; border-color: #c8a000; }")
        self._sp_settings_btn.clicked.connect(self._open_settings_sp_tab)
        sp_bar_lay.addWidget(self._sp_settings_btn)

        self._sp_copy_btn = QPushButton("↓📋 Copy and edit")
        self._sp_copy_btn.setFixedHeight(24)
        self._sp_copy_btn.setFixedWidth(125)
        self._sp_copy_btn.setStyleSheet("font-size: 9pt;")
        self._sp_copy_btn.setToolTip("Copy selected prompt text into the field below for editing")
        self._sp_copy_btn.setVisible(False)
        sp_bar_lay.addWidget(self._sp_copy_btn)

        # ══════════════════════════════════════════════════════════════
        # ROW 3: System prompt field (full width)
        # ══════════════════════════════════════════════════════════════
        self._sys_prompt = QPlainTextEdit()
        self._sys_prompt.setPlaceholderText("System prompt (optional)")
        self._sys_prompt.setMaximumHeight(48)
        self._sys_prompt.setFont(QFont("Monospace", 9))

        # ══════════════════════════════════════════════════════════════
        # ROW 4: User input + Send (tall) / Stop (short) stacked right
        # ══════════════════════════════════════════════════════════════
        self._input = _CommandInput()
        self._input.set_commands(load_commands())
        self._input.send_requested.connect(self._send)
        self._input.setPlaceholderText("Type message… (Ctrl+Enter to send, / for commands)")
        self._input.setMaximumHeight(72)
        self._input.setFont(QFont("Monospace", 10))
        self._input.installEventFilter(self)

        self._send_btn = QPushButton("Send")
        self._send_btn.setMinimumWidth(64)
        # Send gets ~66% of the input height
        self._send_btn.setFixedHeight(48)
        self._send_btn.clicked.connect(self._send)

        self._stop_btn = QPushButton("Stop")
        self._stop_btn.setMinimumWidth(64)
        # Stop gets the remaining ~34%
        self._stop_btn.setFixedHeight(24)
        self._stop_btn.setEnabled(False)
        self._stop_btn.clicked.connect(self._stop)

        btn_col = QVBoxLayout()
        btn_col.setContentsMargins(0, 0, 0, 0)
        btn_col.setSpacing(4)
        btn_col.addWidget(self._send_btn)
        btn_col.addWidget(self._stop_btn)

        input_row = QHBoxLayout()
        input_row.setContentsMargins(0, 0, 0, 0)
        input_row.setSpacing(2)
        input_row.addWidget(self._input, 1)
        input_row.addLayout(btn_col)

        # ── status ────────────────────────────────────────────────────
        n = len(self._model_list)
        src = "saved" if self._state.get("model_list") else "defaults"
        self._status = QLabel(f"Ready. {n} model(s) from {src}. Click ⟳ to refresh.")
        self._status.setWordWrap(True)
        self._status.setStyleSheet("font-size:10px; padding:2px 4px;")

        # ── assemble ──────────────────────────────────────────────────
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(2)
        lay.addLayout(top)
        lay.addWidget(scroll, stretch=1)
        lay.addWidget(self._ctx_bar)
        lay.addWidget(params_bar_w)
        lay.addWidget(sp_bar)
        lay.addWidget(self._sys_prompt)
        lay.addLayout(input_row)
        lay.addWidget(self._status)

        # Wire up copy-to-editor from history
        self._history.insert_to_editor.connect(self._insert_to_editor)
        # Wire up delete exchange
        self._history.delete_exchange.connect(self._on_delete_exchange)
        # Wire up regenerate
        self._history.regenerate.connect(self._on_regenerate)

        # Wire up system prompt selector
        self._sp_populate_combo()
        self._sp_combo.currentIndexChanged.connect(self._sp_on_select)
        self._sp_copy_btn.clicked.connect(self._sp_on_copy)

    # ── file context ─────────────────────────────────────────────────
    def add_file_context(self, path):
        """Add a saved file by path — reads content from disk."""
        import os
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as f:
                content = f.read()
        except Exception as e:
            self._status.setText(f"⚠ Could not read file: {e}")
            return
        self.add_file_context_content(os.path.basename(path), content)

    def add_file_context_content(self, name, content):
        """Add file context by name + content directly (works for unsaved files)."""
        # Don't add duplicates by name
        if any(n == name for n, _ in self._context_files):
            self._status.setText(f"Already in context: {name}")
            return
        self._context_files.append((name, content))
        self._rebuild_ctx_bar()
        self._status.setText(
            f"Added to context: {name} ({len(content)} chars)")

    def next_selection_id(self, filename):
        """Return and increment the selection counter for this filename."""
        key = filename
        count = self._selection_counters.get(key, 0) + 1
        self._selection_counters[key] = count
        return count

    def _remove_file_context(self, name):
        self._context_files = [(n, c) for n, c in self._context_files if n != name]
        self._rebuild_ctx_bar()

    def _rebuild_ctx_bar(self):
        # Remove all tag widgets (everything except the trailing stretch)
        while self._ctx_bar_layout.count() > 1:
            item = self._ctx_bar_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        for name, _ in self._context_files:
            tag = QFrame()
            tag.setStyleSheet(
                "QFrame { background: #2d4a6e; border: 1px solid #4a7ab5; "
                "border-radius: 3px; padding: 1px; }")
            tl = QHBoxLayout(tag)
            tl.setContentsMargins(5, 1, 3, 1)
            tl.setSpacing(3)
            lbl = QLabel(name)
            lbl.setStyleSheet(
                "color: #9ec8f0; font-size: 10px; border: none; "
                "background: transparent;")
            tl.addWidget(lbl)
            x_btn = QPushButton("×")
            x_btn.setFixedSize(14, 14)
            x_btn.setFlat(True)
            x_btn.setStyleSheet(
                "QPushButton { color: #888; font-size: 11px; border: none; "
                "background: transparent; padding: 0; }"
                "QPushButton:hover { color: #fff; }")
            x_btn.clicked.connect(
                lambda checked=False, n=name: self._remove_file_context(n))
            tl.addWidget(x_btn)
            self._ctx_bar_layout.insertWidget(
                self._ctx_bar_layout.count() - 1, tag)

        self._ctx_bar.setVisible(len(self._context_files) > 0)

    # ── event filter ─────────────────────────────────────────────────
    def eventFilter(self, obj, event):
        # _CommandInput handles Ctrl+Enter and slash-dropdown natively;
        # keep this filter for any future obj-level overrides.
        return super().eventFilter(obj, event)

    # ── model popup ───────────────────────────────────────────────────
    def _toggle_popup(self):
        if self._popup is None:
            # Create lazily so main window is visible and stylesheet is applied
            try:
                from qtpy.QtWidgets import QApplication
                wins = QApplication.topLevelWidgets()
                main_win = next(
                    (w for w in wins if w.isVisible()
                     and 'MainWindow' in type(w).__name__), None)
                if main_win is None:
                    main_win = next((w for w in wins if w.isVisible()), None)
            except Exception:
                main_win = None
            self._popup = _ModelPopup(main_win)
            self._popup.selected.connect(self._select_model)

        if self._popup.isVisible():
            self._popup.hide()
        else:
            self._popup.show_below(
                self._model_btn, self._model_list, self._current_model)

    def _select_model(self, name):
        self._current_model = name
        self._model_btn.setText(name + " ▾")
        self._status.setText(f"Model: {name}")
        self._save_state(selected_model=name)

    def _reload_models(self):
        """Manually triggered model list refresh from API."""
        self._fetching = False   # force re-fetch even if previous attempt failed
        self._reload_btn.setEnabled(False)
        self._reload_btn.setText("…")
        self._fetch_models()

    # ── model fetching ────────────────────────────────────────────────
    def _fetch_models(self):
        if self._fetching:
            return
        self._fetching = True
        url = self._api_url()
        key = self._api_key()
        sig_ok  = self._sig_models_ok
        sig_err = self._sig_models_err

        def _work():
            try:
                import urllib.request
                import urllib.error
                headers = {
                    "Content-Type": "application/json",
                    "User-Agent": "spyder-ai-chat/0.1.2",
                }
                if key:
                    headers["Authorization"] = f"Bearer {key}"
                req = urllib.request.Request(
                    url.rstrip("/") + "/models", headers=headers)
                with urllib.request.urlopen(req, timeout=8) as r:
                    data  = json.loads(r.read().decode())
                    items = data.get("data", data.get("models", []))
                    models = sorted(
                        m["id"] for m in items
                        if isinstance(m, dict) and "id" in m)
                    sig_ok.emit(models if models else [])
            except urllib.error.HTTPError as e:
                try:
                    body = e.read().decode(errors="replace")[:200]
                except Exception:
                    body = ""
                sig_err.emit(f"HTTP {e.code} {e.reason}: {body}")
            except Exception as e:
                sig_err.emit(f"{type(e).__name__}: {e}")

        threading.Thread(target=_work, daemon=True).start()

    @Slot(list)
    def _on_models_ok(self, models):
        self._fetching = False
        self._reload_btn.setEnabled(True)
        self._reload_btn.setText("⟳")
        if models:
            self._model_list = models
            if self._current_model not in models:
                self._current_model = models[0]
                self._model_btn.setText(self._current_model + " ▾")
            self._save_state(model_list=models, selected_model=self._current_model)
            preview = ", ".join(models[:3]) + (" …" if len(models) > 3 else "")
            self._status.setText(f"✓ {len(models)} model(s): {preview}")
        else:
            self._status.setText("⚠ No models returned.")

    @Slot(str)
    def _on_models_err(self, err):
        self._fetching = False
        self._reload_btn.setEnabled(True)
        self._reload_btn.setText("⟳")
        self._status.setText(f"⚠ Model fetch failed: {err}")

    # ── config ────────────────────────────────────────────────────────
    def _api_url(self):
        return self._load_state().get("api_url", "https://api.openai.com/v1")

    def _api_key(self):
        return self._load_state().get("api_key", "")

    def _history_cfg(self):
        return {**HISTORY_DEFAULTS, **self._load_state().get("history", {})}

    def _editor_cfg(self):
        return {**EDITOR_DEFAULTS, **self._load_state().get("editor", {})}

    # ── copy to editor ────────────────────────────────────────────────
    def _insert_to_editor(self, text):
        result = self._get_editor_cursor()
        cursor, editor_or_diag = result

        if cursor is not None:
            try:
                cursor.insertText(text)
                editor_or_diag.setTextCursor(cursor)
                self._status.setText("✓ Inserted into editor at cursor position.")
                return
            except Exception as e:
                editor_or_diag = str(e)

        # Fallback: clipboard
        QApplication.clipboard().setText(text)
        # Show diagnostic info so we can debug
        self._status.setText(f"Clipboard copy. Diag: {editor_or_diag}")

    # ── new chat ──────────────────────────────────────────────────────
    def _on_history_deleted(self, filename):
        """Called when a chat is deleted from the history popup."""
        if filename == self._current_chat_file:
            # The currently displayed chat was deleted — clear the window
            self._current_chat_file = None
            self._messages.clear()
            self._history.clear_all()
            self._context_files.clear()
            self._selection_counters.clear()
            self._rebuild_ctx_bar()
            self._sys_prompt.clear()
            self._sp_selected_id = CUSTOM_ID
            self._sp_populate_combo(select_id=CUSTOM_ID)
            self._status.setText("Current chat deleted.")

    def _on_history_deleted_all(self):
        """Called when all chats are deleted via the Delete All button."""
        self._current_chat_file = None
        self._messages.clear()
        self._history.clear_all()
        self._context_files.clear()
        self._selection_counters.clear()
        self._rebuild_ctx_bar()
        self._sys_prompt.clear()
        self._sp_selected_id = CUSTOM_ID
        self._sp_populate_combo(select_id=CUSTOM_ID)
        self._save_state(last_chat_file=None)
        self._status.setText("All chats deleted.")

    def _new_chat(self):
        # Save current chat to history before clearing (if enabled)
        if self._messages and self._history_cfg().get("save_on_new", True):
            self._current_chat_file = save_chat(
                self._messages,
                system_prompt=self._sp_get_active_prompt(), prompt_id=self._sp_selected_id,
                model=self._current_model,
                filename=self._current_chat_file,
                provider=self._chat_provider,
                infer_params=self._infer_params,
            )
        self._current_chat_file = None
        self._messages.clear()
        self._history.clear_all()
        self._context_files.clear()
        self._selection_counters.clear()
        self._rebuild_ctx_bar()
        default_id = self._load_state().get("default_system_prompt_id")
        if default_id:
            p = get_prompt(default_id)
            if p:
                self._sp_selected_id = default_id
                self._sp_populate_combo(select_id=default_id)
                self._sys_prompt.setPlainText(p["content"])
            else:
                self._sp_selected_id = CUSTOM_ID
                self._sp_populate_combo(select_id=CUSTOM_ID)
                self._sys_prompt.clear()
        else:
            self._sp_selected_id = CUSTOM_ID
            self._sp_populate_combo(select_id=CUSTOM_ID)
            self._sys_prompt.clear()
        self._infer_params = {}
        self._update_summary_bar()
        self._save_state(last_chat_file=None)
        self._status.setText("New conversation started.")

    def _toggle_history_popup(self):
        if self._hist_popup is None:
            try:
                wins = QApplication.topLevelWidgets()
                main_win = next(
                    (w for w in wins if w.isVisible()
                     and 'MainWindow' in type(w).__name__), None)
                if main_win is None:
                    main_win = next((w for w in wins if w.isVisible()), None)
            except Exception:
                main_win = None
            self._hist_popup = _ChatHistoryPopup(main_win)
            self._hist_popup.load_chat.connect(self._load_chat_from_file)
            self._hist_popup.del_chat.connect(self._on_history_deleted)
            self._hist_popup.del_all.connect(self._on_history_deleted_all)

        if self._hist_popup.isVisible():
            self._hist_popup.hide()
        else:
            self._hist_popup.show_below(self._hist_btn, self._current_chat_file)

    def _load_chat_from_file(self, filename):
        """Load a saved chat into the current view."""
        data = load_chat(filename)
        if data is None:
            self._status.setText("⚠ Could not load chat.")
            return
        # Save current chat first if it has content and saving is enabled
        if self._messages and self._history_cfg().get("autosave", True):
            save_chat(
                self._messages,
                system_prompt=self._sp_get_active_prompt(), prompt_id=self._sp_selected_id,
                model=self._current_model,
                filename=self._current_chat_file,
                provider=self._chat_provider,
                infer_params=self._infer_params,
            )
        # Restore state
        self._messages.clear()
        self._history.clear_all()
        self._context_files.clear()
        self._selection_counters.clear()
        self._rebuild_ctx_bar()

        sys_p     = data.get("system_prompt", "")
        prompt_id = data.get("prompt_id", CUSTOM_ID) or CUSTOM_ID

        # If saved prompt no longer exists, fall back to custom
        if prompt_id != CUSTOM_ID and get_prompt(prompt_id) is None:
            prompt_id = CUSTOM_ID

        # Restore prompt selector first (it may overwrite sys_p via _sp_on_select)
        self._sp_selected_id = prompt_id
        self._sp_populate_combo(select_id=prompt_id)

        # For custom prompts, restore the text; saved prompts are set by combo
        if prompt_id == CUSTOM_ID:
            self._sys_prompt.setPlainText(sys_p)

        model = data.get("model", "")
        if model and model in self._model_list:
            self._current_model = model
            self._model_btn.setText(model + " ▾")

        for msg in data.get("messages", []):
            role    = msg.get("role", "")
            content = msg.get("content", "")
            if role == "user":
                attachments = msg.get("attachments", [])
                # New format: content is plain user text, attachments are separate
                # Legacy format: file blocks embedded in content — strip them
                display = content
                if not attachments and "```" in content and content.startswith("File: "):
                    parts = content.rsplit("```", 2)
                    if len(parts) >= 2:
                        display = parts[-1].strip()
                att_names = [a["name"] if isinstance(a, dict) else a
                             for a in attachments]
                spans = msg.get("command_spans")
                self._history.add_user(
                    display,
                    attachments=att_names or None,
                    command_spans=[(s[0], s[1]) for s in spans] if spans else None,
                )
                self._messages.append(msg)
            elif role == "assistant":
                self._history.finalize_assistant(content)
                self._messages.append(msg)
            elif role == "assistant_error":
                self._history.show_error(content)
                self._messages.append(msg)

        self._current_chat_file = filename
        self._save_state(last_chat_file=filename)

        # Restore per-chat provider and inference params
        current_provider = self._load_state().get("provider_type", "custom")
        saved_provider   = data.get("provider") or ""
        if saved_provider and saved_provider != current_provider:
            # Chat was saved under a different provider — reset params
            self._infer_params    = {}
            self._chat_provider   = current_provider
        else:
            self._infer_params  = dict(data.get("infer_params") or {})
            self._chat_provider = current_provider
        self._update_summary_bar()

        self._status.setText(f"Loaded: {data.get('preview', filename)[:40]}")
        self._deferred_scroll_to_bottom()

    # ── settings ──────────────────────────────────────────────────────
    def _open_settings_sp_tab(self):
        """Open Settings dialog with the System Prompts tab pre-selected."""
        self._open_settings(initial_tab=3)

    def _open_settings(self, initial_tab=0):
        state = self._load_state()
        old_provider = state.get("provider_type", "custom")
        dlg = SettingsDialog(
            self,
            provider_type    = state.get("provider_type", "openai"),
            api_url          = state.get("api_url", "https://api.openai.com/v1"),
            api_key          = state.get("api_key", ""),
            default_system_prompt_id = state.get("default_system_prompt_id"),
            editor_cfg       = state.get("editor", {}),
            history_cfg      = state.get("history", {}),
            azure_deployment = state.get("azure_deployment", ""),
            azure_api_version= state.get("azure_api_version", "2024-02-01"),
            commands         = load_commands(),
            fim_cfg          = state.get("fim", {}),
            initial_tab      = initial_tab,
        )
        if dlg.exec_() == QDialog.Accepted:
            v = dlg.values()
            self._save_state(
                provider_type            = v["provider_type"],
                api_url                  = v["api_url"],
                api_key                  = v["api_key"],
                azure_deployment         = v["azure_deployment"],
                azure_api_version        = v["azure_api_version"],
                editor                   = v["editor"],
                history                  = v["history"],
                fim                      = v["fim"],
                default_system_prompt_id = v["default_system_prompt_id"],
            )
            self._history._font_cfg = self._editor_cfg()
            self._fetching = False
            self._status.setText("Settings saved.")
            self._fetch_models()
            # Refresh prompt combo in case prompts were added/deleted
            self._sp_populate_combo()
            # Reload commands into the input widget
            self._input.set_commands(load_commands())
            # If provider changed, reset per-chat inference params
            if v["provider_type"] != old_provider:
                self._on_provider_changed(v["provider_type"])

    # ── send / stop ───────────────────────────────────────────────────
    def _send(self):
        # Snapshot active commands BEFORE clearing the input (clear() resets them)
        active_commands_snapshot = list(self._input._active_commands)
        display_text = self._input.toPlainText().strip()
        if not display_text:
            return
        if self._chat_thread is not None and self._chat_thread.isRunning():
            return
        self._input.clear()

        # Snapshot and clear pending context files
        pending_attachments = list(self._context_files)
        if pending_attachments:
            self._context_files.clear()
            self._rebuild_ctx_bar()

        # Build structured message — content = display text for UI / history.
        # content_llm = expanded text frozen at send time so history replay is
        # correct even if the command is later edited or deleted in Settings.
        user_msg = {
            "role": "user",
            "content": display_text,
        }
        if active_commands_snapshot:
            # Expand spans against the display_text to produce the full LLM prompt
            chars = list(display_text)
            for c in sorted(active_commands_snapshot,
                            key=lambda x: x["start"], reverse=True):
                s, l = c["start"], c["length"]
                prompt = get_command_prompt(c["name"], self._input._commands)
                if prompt:
                    chars[s:s+l] = list(prompt)
            user_msg["content_llm"] = "".join(chars)
            user_msg["command_spans"] = [
                [c["start"], c["length"]] for c in active_commands_snapshot
            ]
        if pending_attachments:
            user_msg["attachments"] = [
                {"name": name, "content": content}
                for name, content in pending_attachments
            ]

        llm_content = _build_llm_content(user_msg)

        # Build full message list for LLM (system prompt + history + new)
        messages = []
        sys_p = self._sp_get_active_prompt()
        if sys_p:
            messages.append({"role": "system", "content": sys_p})
        for m in self._messages:
            if m.get("role") not in ("user", "assistant"):
                continue
            messages.append({"role": m["role"],
                             "content": _build_llm_content(m)})
        messages.append({"role": "user", "content": llm_content})

        attachment_names = [a["name"] for a in user_msg.get("attachments", [])]

        # Update UI — show display_text with command highlights in chat bubble
        self._history.add_user(
            display_text,
            attachments=attachment_names or None,
            command_spans=[
                (c["start"], c["length"])
                for c in active_commands_snapshot
            ] or None,
        )
        self._messages.append(user_msg)
        self._current_lbl = self._history.add_assistant_start()
        self._assistant_buf    = ""
        self._rendered_char_end = 0
        self._streaming_code_edit = None
        self._auto_scroll = True   # re-enable auto-scroll for this new exchange

        worker = _ChatWorker(
            self._api_url(), self._api_key(),
            self._current_model, messages,
            extra_params=self._build_extra_params())
        thread = QThread(self)
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.chunk_ready.connect(self._on_chunk)
        worker.finished.connect(self._on_done)
        worker.error.connect(self._on_err)
        worker.finished.connect(thread.quit)

        self._chat_worker = worker
        self._chat_thread = thread

        self._send_btn.setEnabled(False)
        self._stop_btn.setEnabled(True)
        self._status.setText(f"Generating with {self._current_model}…")
        thread.start()

    def _stop(self):
        if self._chat_worker:
            self._chat_worker.stop()
        self._status.setText("Stopped.")

    @Slot(str)
    def _on_chunk(self, text):
        if not self._assistant_buf:          # first token — hide spinner, show tail bar
            self._history.hide_spinner()
            if self._current_lbl:
                self._current_lbl.show()
        self._assistant_buf += text
        if self._current_lbl:
            self._current_lbl.setText(
                self._current_lbl.text() + text)
        # On every newline, promote any newly completed blocks to rendered widgets
        if '\n' in text:
            self._try_render_complete_blocks()
        # Scrolling is handled automatically by rangeChanged signal

    def _try_render_complete_blocks(self):
        """Parse _assistant_buf, render complete blocks into the rendered zone,
        and update the tail label with only the current incomplete block text."""
        import re as _re
        from qtpy.QtWidgets import QPlainTextEdit as _PTE
        from qtpy.QtGui import QFont as _QFont

        buf = self._assistant_buf
        # Suppress all promotion while inside an unclosed <think> block.
        # Without this, the think content is parsed as plain paragraphs and
        # promoted piecemeal, so the think widget never gets built.
        buf_lower = buf.lower()
        if '<think>' in buf_lower and '</think>' not in buf_lower:
            return

        blocks = parse_blocks(buf)
        if not blocks:
            return

        # ── Live-update streaming code block ─────────────────────────────
        # The parser always emits a code block from an opening ``` even without
        # a closing ```, so we can't use "it's a code block → it's complete".
        # Instead, when the response so far is exactly ONE code block, we live-
        # update a QPlainTextEdit widget in the rendered zone on every newline,
        # giving progressive rendering. We only finalise (fix height, clear tail)
        # when the closing ``` has actually arrived.
        if len(blocks) == 1 and blocks[0]["type"] == "code":
            block = blocks[0]
            # Detect closing fence: at least two ``` lines in the buffer
            fence_lines = [l for l in buf.splitlines()
                           if _re.match(r'^\s*```', l)]
            fence_closed = len(fence_lines) >= 2

            cfg = {**EDITOR_DEFAULTS,
                   **(getattr(self._history, "_font_cfg", None) or {})}
            fs_code = cfg.get("fs_code", 10)

            if self._streaming_code_edit is None:
                # First newline inside the code block — create the widget
                w = build_code_block(block, self._history.insert_to_editor, fs_code)
                self._streaming_code_edit = w.findChild(_PTE)
                self._history.push_rendered_widget(w)

            # Update content in-place
            code = block["content"]
            self._streaming_code_edit.setPlainText(code)
            line_h = _QFont("Monospace", fs_code).pointSize() + 8
            n_lines = max(code.count("\n") + 1, 1)
            self._streaming_code_edit.setFixedHeight(n_lines * line_h + 20)

            # All buffer content is now shown inside the widget — clear the tail
            self._rendered_char_end = len(buf)
            if self._current_lbl is not None:
                self._current_lbl.setText("")

            if fence_closed:
                # Code block is complete — stop live-updating
                self._streaming_code_edit = None
            return

        # If we were live-updating a code block but now there are more blocks
        # (content appeared after the closing ```), stop tracking the live edit.
        if self._streaming_code_edit is not None:
            self._streaming_code_edit = None

        # ── Standard block promotion ──────────────────────────────────────
        # Think blocks are self-contained: parse_blocks only creates them when
        # </think> has been matched, so a lone think block is definitively complete.
        # All other single-block responses stay in the tail until a second block
        # confirms they are complete.
        if len(blocks) == 1 and blocks[0]["type"] != "think":
            return   # single non-self-closing block — tail may still be incomplete
        # All blocks except the last are complete (something follows them).
        # For a lone think block, treat the whole list as complete.
        complete = blocks[:-1] if len(blocks) >= 2 else blocks
        new_blocks = complete[self._history._rendered_block_count:]
        if not new_blocks:
            return
        for block in new_blocks:
            self._history.push_rendered_block(block)
        # Update char position of rendered content
        self._rendered_char_end = complete[-1]["_char_end"]
        # Trim the tail label to show only the unrendered suffix
        tail = self._assistant_buf[self._rendered_char_end:]
        if self._current_lbl is not None:
            self._current_lbl.setText(tail)

    @Slot()
    def _on_done(self):
        if self._worker_had_error:
            # _on_err already finalized — skip to avoid creating a second empty block
            self._worker_had_error = False
            return
        if self._assistant_buf:
            self._messages.append(
                {"role": "assistant", "content": self._assistant_buf})
        # Replace streaming label with parsed markdown view
        self._history.finalize_assistant(self._assistant_buf)
        self._send_btn.setEnabled(True)
        self._stop_btn.setEnabled(False)
        self._status.setText("Done.")
        self._chat_thread = None
        self._chat_worker = None
        self._current_lbl = None
        # Fire multiple deferred scrolls to catch all layout passes.
        # Rendered markdown is often shorter than raw streamed text, so the
        # scroll range shrinks and we must re-anchor to the new bottom.
        self._deferred_scroll_to_bottom()
        self._autosave()

    @Slot(str)
    def _on_err(self, msg):
        self._worker_had_error = True
        if self._assistant_buf:
            # Partial response received before error — finalize what we have
            self._messages.append({"role": "assistant", "content": self._assistant_buf})
            self._history.finalize_assistant(self._assistant_buf)
        else:
            # No content received — show styled error block
            self._messages.append({"role": "assistant_error", "content": msg})
            self._history.show_error(msg)
        self._status.setText(f"⚠ {msg}")
        self._send_btn.setEnabled(True)
        self._stop_btn.setEnabled(False)
        self._chat_thread = None
        self._chat_worker = None
        self._current_lbl = None
        self._deferred_scroll_to_bottom()
        self._autosave()

    def _deferred_scroll_to_bottom(self):
        """Schedule scroll-to-bottom at 0 ms, 100 ms and 300 ms.
        Multiple passes are needed because Qt may take several layout
        rounds to settle after replacing the streaming label with
        rendered markdown (especially when content shrinks in height)."""
        for delay in (0, 100, 300):
            QTimer.singleShot(delay, self._scroll_to_bottom)

    def _on_scroll_range_changed(self, min_, max_):
        """Called whenever the vertical scroll range changes.
        Scrolls to bottom during streaming (content grows)."""
        if self._auto_scroll and max_ > 0:
            self._scroll.verticalScrollBar().setValue(max_)

    def _scroll_to_bottom(self):
        """Scroll to the true bottom of content, even after re-render shrinks height."""
        self._auto_scroll = True
        sb = self._scroll.verticalScrollBar()
        # With setWidgetResizable(True), the widget is stretched to viewport
        # height, so sb.maximum() can be 0 even when content overflows.
        # Use the layout's sizeHint to find the real content height.
        content_h = self._history.layout().sizeHint().height()
        viewport_h = self._scroll.viewport().height()
        true_max = max(0, content_h - viewport_h)
        if true_max > 0:
            sb.setValue(true_max)
        else:
            sb.setValue(sb.maximum())

    # ── system prompt selector ────────────────────────────────────────

    def _sp_populate_combo(self, select_id=None):
        """Reload combo from saved prompts. Preserves current selection."""
        if select_id is None:
            select_id = self._sp_selected_id
        self._sp_combo.blockSignals(True)
        self._sp_combo.clear()
        self._sp_combo.addItem("Use custom", userData=CUSTOM_ID)
        prompts = load_prompts()
        target_idx = 0
        for i, p in enumerate(prompts):
            self._sp_combo.addItem(p["title"], userData=p["id"])
            if p["id"] == select_id:
                target_idx = i + 1
        self._sp_combo.blockSignals(False)
        self._sp_combo.setCurrentIndex(target_idx)
        self._sp_on_select(target_idx)

    def _sp_on_select(self, idx):
        prompt_id = self._sp_combo.currentData()
        self._sp_selected_id = prompt_id
        if prompt_id == CUSTOM_ID:
            # Custom: enable the text field, hide copy button
            self._sys_prompt.setEnabled(True)
            self._sys_prompt.setPlaceholderText("System prompt (optional)")
            self._sp_copy_btn.setVisible(False)
        else:
            # Saved prompt selected: show content read-only, show copy button
            p = get_prompt(prompt_id)
            if p:
                self._sys_prompt.setPlainText(p["content"])
            self._sys_prompt.setEnabled(False)
            self._sp_copy_btn.setVisible(True)

    def _sp_on_copy(self):
        """Copy selected saved prompt into the field for editing, switch to custom."""
        p = get_prompt(self._sp_selected_id)
        if p:
            self._sys_prompt.setPlainText(p["content"])
        # Switch combo to "Use custom" without triggering _sp_on_select clear
        self._sp_combo.blockSignals(True)
        self._sp_combo.setCurrentIndex(0)
        self._sp_combo.blockSignals(False)
        self._sp_selected_id = CUSTOM_ID
        self._sys_prompt.setEnabled(True)
        self._sp_copy_btn.setVisible(False)
        self._sys_prompt.setFocus()

    def _sp_get_active_prompt(self):
        """Return the effective system prompt text for sending."""
        if self._sp_selected_id != CUSTOM_ID:
            p = get_prompt(self._sp_selected_id)
            if p:
                return p["content"]
        return self._sys_prompt.toPlainText().strip()

    def _on_delete_exchange(self, block_idx, delete_before):
        """
        Delete one exchange (user+assistant pair) or all exchanges before it.
        '🗑 This'      → delete this user+assistant pair.
        '⏫ All before' → delete all exchanges before (and including) this one.
        """
        if block_idx < 0 or block_idx >= len(self._messages):
            return

        # Step back to paired user if an assistant block was clicked
        idx = block_idx
        if idx % 2 == 1:
            idx -= 1

        if delete_before:
            del self._messages[: idx + 2]
        else:
            del self._messages[idx: idx + 2]

        # Rebuild UI
        self._history.clear_all()
        for msg in self._messages:
            role_   = msg.get("role", "")
            content = msg.get("content", "")
            if role_ == "user":
                attachments = msg.get("attachments", [])
                display = content
                if not attachments and "```" in content and content.startswith("File: "):
                    parts = content.rsplit("```", 2)
                    if len(parts) >= 2:
                        display = parts[-1].strip()
                att_names = [a["name"] if isinstance(a, dict) else a
                             for a in attachments]
                spans = msg.get("command_spans")
                self._history.add_user(
                    display,
                    attachments=att_names or None,
                    command_spans=[(s[0], s[1]) for s in spans] if spans else None,
                )
            elif role_ == "assistant":
                self._history.finalize_assistant(content)
            elif role_ == "assistant_error":
                self._history.show_error(content)

        self._autosave()
        self._deferred_scroll_to_bottom()
        self._status.setText("Exchange deleted.")

    def _on_regenerate(self):
        """Remove the last assistant reply and re-send the last user message."""
        if self._chat_thread is not None and self._chat_thread.isRunning():
            return
        # Need at least one user + one assistant message
        if len(self._messages) < 2:
            return
        if self._messages[-1].get("role") not in ("assistant", "assistant_error"):
            return

        # Drop the last assistant reply (or error) from the stored messages
        self._messages.pop()

        # Rebuild UI without the last assistant block
        self._history.clear_all()
        for msg in self._messages:
            role_   = msg.get("role", "")
            content = msg.get("content", "")
            if role_ == "user":
                attachments = msg.get("attachments", [])
                display = content
                if not attachments and "```" in content and content.startswith("File: "):
                    parts = content.rsplit("```", 2)
                    if len(parts) >= 2:
                        display = parts[-1].strip()
                att_names = [a["name"] if isinstance(a, dict) else a
                             for a in attachments]
                spans = msg.get("command_spans")
                self._history.add_user(
                    display,
                    attachments=att_names or None,
                    command_spans=[(s[0], s[1]) for s in spans] if spans else None,
                )
            elif role_ == "assistant":
                self._history.finalize_assistant(content)
            elif role_ == "assistant_error":
                self._history.show_error(content)

        # Build LLM messages from current history (last entry is the user message)
        messages = []
        sys_p = self._sp_get_active_prompt()
        if sys_p:
            messages.append({"role": "system", "content": sys_p})
        for m in self._messages:
            if m.get("role") not in ("user", "assistant"):
                continue
            messages.append({"role": m["role"],
                             "content": _build_llm_content(m)})

        # Add streaming placeholder for the new response
        self._current_lbl = self._history.add_assistant_start()
        self._assistant_buf    = ""
        self._rendered_char_end = 0
        self._streaming_code_edit = None
        self._auto_scroll = True

        worker = _ChatWorker(
            self._api_url(), self._api_key(),
            self._current_model, messages,
            extra_params=self._build_extra_params())
        thread = QThread(self)
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.chunk_ready.connect(self._on_chunk)
        worker.finished.connect(self._on_done)
        worker.error.connect(self._on_err)
        worker.finished.connect(thread.quit)

        self._chat_worker = worker
        self._chat_thread = thread
        self._send_btn.setEnabled(False)
        self._stop_btn.setEnabled(True)
        self._status.setText(f"Regenerating with {self._current_model}…")
        thread.start()

    # ── inference parameters ──────────────────────────────────────────

    def _build_extra_params(self) -> dict:
        """
        Build the dict of inference params to send to the API.
        Filters to only params supported by the current provider,
        and renames max_tokens → max_completion_tokens for Groq.
        Returns empty dict if no params are set.
        """
        if not self._infer_params:
            return {}
        state = self._load_state()
        pid   = state.get("provider_type", "custom")
        pdef  = PROVIDERS.get(pid, PROVIDERS["custom"])
        supported = set(pdef["supported_params"])
        result = {k: v for k, v in self._infer_params.items() if k in supported}
        # Groq uses max_completion_tokens, not max_tokens
        if pid == "groq" and "max_tokens" in result:
            result["max_completion_tokens"] = result.pop("max_tokens")
        return result

    def _update_summary_bar(self):
        """Update the params summary label. Bar is always visible."""
        if not self._infer_params:
            self._params_bar_lbl.setText("Click to set inference params")
            self._params_bar_lbl.setStyleSheet(_PARAMS_BAR_IDLE_STYLE)
            return
        # Build compact summary text
        parts = []
        label_map = {
            "temperature": "temp", "max_tokens": "max", "top_p": "top_p",
            "top_k": "top_k", "min_p": "min_p",
            "presence_penalty": "pres", "frequency_penalty": "freq",
            "repetition_penalty": "rep", "seed": "seed", "num_ctx": "ctx",
        }
        for k, v in self._infer_params.items():
            short = label_map.get(k, k)
            if isinstance(v, float):
                parts.append(f"{short}: {v:.2f}")
            else:
                parts.append(f"{short}: {v}")
        self._params_bar_lbl.setText("⚙ " + " · ".join(parts))
        self._params_bar_lbl.setStyleSheet(_PARAMS_BAR_ACTIVE_STYLE)

    def _toggle_params_popup(self):
        """Open or close the inference params popup anchored above the ⚙ button."""
        if self._params_popup is None:
            try:
                wins = QApplication.topLevelWidgets()
                main_win = next(
                    (w for w in wins if w.isVisible()
                     and 'MainWindow' in type(w).__name__), None)
                if main_win is None:
                    main_win = next((w for w in wins if w.isVisible()), None)
            except Exception:
                main_win = None
            self._params_popup = _InferParamsPopup(main_win)

        if self._params_popup.isVisible():
            self._params_popup.hide()
        else:
            self._params_popup.show_above(self._params_bar_lbl, self)

    def _on_provider_changed(self, new_provider_id: str):
        """
        Called when the user switches provider in Settings.
        Resets per-chat inference params and updates chat_provider.
        """
        self._infer_params  = {}
        self._chat_provider = new_provider_id
        self._update_summary_bar()
        # Close popup if open so it rebuilds with new provider next time
        if self._params_popup and self._params_popup.isVisible():
            self._params_popup.hide()
        self._status.setText(
            f"Provider changed to {PROVIDERS.get(new_provider_id, {}).get('label', new_provider_id)}"
            f" — inference parameters reset.")

    def _autosave(self):
        """Save current chat to disk after each exchange (if enabled)."""
        if self._messages and self._history_cfg().get("autosave", True):
            self._current_chat_file = save_chat(
                self._messages,
                system_prompt=self._sp_get_active_prompt(), prompt_id=self._sp_selected_id,
                model=self._current_model,
                filename=self._current_chat_file,
                provider=self._chat_provider,
                infer_params=self._infer_params,
            )
            if self._current_chat_file:
                self._save_state(last_chat_file=self._current_chat_file)


# ---------------------------------------------------------------------------
# PluginMainWidget — proper Spyder 6 integration
# Spyder calls setup() to build content inside its managed central area.
# get_main_layout() returns the QVBoxLayout of the central content widget,
# which sits BELOW the toolbars and title bar — so toolbars stay intact.
# ---------------------------------------------------------------------------
from spyder.api.widgets.main_widget import PluginMainWidget

class AIChatWidget(PluginMainWidget):

    DEFAULT_OPTIONS = {}

    def get_title(self):
        return "AI Chat"

    def setup(self, options=None):
        self._panel = AIChatPanel(
            get_conf=lambda k, d="": d,
            set_conf=lambda k, v: None,
            get_editor_cursor=lambda: (None, "not set yet"),
            parent=self,
        )
        # set_content_widget() is the correct Spyder 6 API —
        # places our panel in the central area below the toolbars
        self.set_content_widget(self._panel)

    def set_editor_cursor_fn(self, fn):
        """Called by plugin.py after Spyder wires up the editor plugin."""
        if hasattr(self, '_panel'):
            self._panel._get_editor_cursor = fn

    def add_file_context(self, path):
        """Called by plugin.py when user picks 'Add to AI Chat context'."""
        if hasattr(self, '_panel'):
            self._panel.add_file_context(path)

    def add_file_context_content(self, name, content):
        """Called by plugin.py with already-read content (supports unsaved files)."""
        if hasattr(self, '_panel'):
            self._panel.add_file_context_content(name, content)

    def next_selection_id(self, filename):
        """Return next selection counter for this filename."""
        if hasattr(self, '_panel'):
            return self._panel.next_selection_id(filename)
        return 1

    def update_actions(self):
        pass
