# -*- coding: utf-8 -*-
"""Chat History Manager — one JSON file per chat session. (C) 2026 by Maciej Piecko"""

import json
import os
from datetime import datetime


CHATS_DIR = os.path.join(os.path.expanduser("~"), ".spyder_ai_chat", "chats")


def _ensure_dir():
    os.makedirs(CHATS_DIR, exist_ok=True)


def _chat_path(filename):
    return os.path.join(CHATS_DIR, filename)


def _new_filename():
    """Generate a unique filename based on current timestamp."""
    return datetime.now().strftime("%Y%m%d_%H%M%S_%f") + ".json"


def save_chat(messages, system_prompt="", model="", filename=None,
              prompt_id=None, provider=None, infer_params=None):
    """
    Save a chat session to disk.
    Returns the filename used (so caller can track the current chat file).

    prompt_id:    id of the saved system prompt used, or None / CUSTOM_ID.
    provider:     provider type string (e.g. "openai", "groq", "ollama").
    infer_params: dict of explicitly-set inference parameter values only.
                  Omitted/default params should NOT be in this dict.
    """
    if not messages:
        return None
    _ensure_dir()

    # If updating an existing file, check if messages changed
    existing_saved_at = None
    existing_msg_count = None
    if filename:
        try:
            with open(_chat_path(filename), "r", encoding="utf-8") as f:
                existing = json.load(f)
                existing_saved_at = existing.get("saved_at")
                existing_msg_count = len(existing.get("messages", []))
        except Exception:
            pass

    # Only bump saved_at if message count changed (new messages added)
    if (existing_saved_at is not None and
            existing_msg_count == len(messages)):
        saved_at = existing_saved_at
    else:
        saved_at = datetime.now().isoformat()

    if filename is None:
        filename = _new_filename()

    # Preview: first user message, up to 60 chars.
    # If the message uses a slash-command, build: "/cmd — <context>" where
    # context priority is: (1) user's extra typed text, (2) first attachment
    # name, (3) current date-time as fallback.
    preview = ""
    for m in messages:
        if m.get("role") == "user":
            content = m.get("content", "")
            # Strip legacy file context block (starts with "File: ")
            if content.startswith("File: "):
                parts = content.rsplit("```", 2)
                content = parts[-1].strip() if len(parts) >= 2 else content
            spans = m.get("command_spans")
            if spans:
                # Remove command tokens to get any surrounding user text
                remaining = content
                for s, l in sorted(spans, key=lambda x: x[0], reverse=True):
                    remaining = remaining[:s] + remaining[s+l:]
                remaining = remaining.strip(" \n")
                cmd_tokens = " ".join(
                    content[s:s+l] for s, l in sorted(spans, key=lambda x: x[0])
                )
                if remaining:
                    # (1) User typed extra text alongside the command
                    suffix = remaining
                else:
                    # (2) First attachment name (file or selection)
                    attachments = m.get("attachments", [])
                    if attachments:
                        suffix = attachments[0].get("name", "")
                    else:
                        # (3) Fallback: timestamp
                        from datetime import datetime as _dt
                        suffix = "at " + _dt.now().strftime("%Y-%m-%d %H:%M")
                preview = f"{cmd_tokens} — {suffix}"
            else:
                preview = content
            preview = preview[:60].replace("\n", " ")
            break

    data = {
        "filename":      filename,
        "saved_at":      saved_at,
        "preview":       preview,
        "model":         model,
        "system_prompt": system_prompt,
        "prompt_id":     prompt_id,
        "provider":      provider,           # NEW: provider type id string
        "infer_params":  infer_params or {}, # NEW: explicitly-set params only
        "messages":      messages,
    }
    with open(_chat_path(filename), "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    return filename


def load_chat(filename):
    """Load a chat session from disk. Returns dict or None on error.

    Always returns 'provider' (str or None) and 'infer_params' (dict)
    even for old files that predate these fields.
    """
    try:
        with open(_chat_path(filename), "r", encoding="utf-8") as f:
            data = json.load(f)
        # Back-compat: ensure new fields exist
        data.setdefault("provider", None)
        data.setdefault("infer_params", {})
        return data
    except Exception:
        return None


def delete_chat(filename):
    """Delete a chat file. Returns True on success."""
    try:
        os.remove(_chat_path(filename))
        return True
    except Exception:
        return False


def list_chats(limit=200):
    """
    Return list of chat metadata dicts, newest first.
    Each dict has: filename, saved_at, preview, model.
    """
    _ensure_dir()
    results = []
    try:
        for fname in os.listdir(CHATS_DIR):
            if not fname.endswith(".json"):
                continue
            try:
                with open(_chat_path(fname), "r", encoding="utf-8") as f:
                    data = json.load(f)
                results.append({
                    "filename": fname,
                    "saved_at": data.get("saved_at", ""),
                    "preview":  data.get("preview", "(no preview)"),
                    "model":    data.get("model", ""),
                })
            except Exception:
                continue
    except Exception:
        return []

    results.sort(key=lambda x: x["saved_at"], reverse=True)
    return results[:limit]
