import asyncio
import datetime as dt
from asyncexchange.services.exchange.emails import EmailService

email_service = EmailService(

    tz=dt.timezone(dt.timedelta(hours=3)),
)

async def main():
    end = dt.datetime.now()
    start = end - dt.timedelta(days=1)
    messages = await email_service.get_messages(
        start=start,
        end=end,
        is_read=False,
    )
    for message in messages:
        print(message.subject)
        print(message.author.email_address)
        print(message.to_recipients)
        print(message.datetime_sent)
        print(message.is_read)
    await email_service.mark_as_read(messages=messages)

if __name__ == "__main__":
    asyncio.run(main())