"""Tests unitarios para modelos de datos y configuracion."""

from market_streaming.config import MARKET_URLS, Market, StreamConfig
from market_streaming.models import (
    OrderBookLevel,
    OrderBookSnapshot,
    StreamState,
    StreamStatus,
    StreamType,
    Trade,
)


class TestTrade:
    def test_trade_is_frozen(self) -> None:
        trade = Trade(
            symbol="BTCUSDT",
            trade_id=1,
            price=50000.0,
            quantity=0.1,
            quote_quantity=5000.0,
            buyer_maker=False,
            timestamp_ms=1000,
        )
        try:
            trade.price = 99999.0  # type: ignore[misc]
            assert False, "Trade deberia ser inmutable"
        except AttributeError:
            pass

    def test_trade_fields(self) -> None:
        trade = Trade(
            symbol="ETHUSDT",
            trade_id=42,
            price=3000.0,
            quantity=1.5,
            quote_quantity=4500.0,
            buyer_maker=True,
            timestamp_ms=1234567890,
            price_str="3000.00000000",
            quantity_str="1.50000000",
            quote_quantity_str="4500.00000000",
            is_best_match=True,
            event_time_ms=1234567891,
        )
        assert trade.symbol == "ETHUSDT"
        assert trade.trade_id == 42
        assert trade.buyer_maker is True
        assert trade.quote_quantity == 4500.0
        assert trade.is_best_match is True
        assert trade.price_str == "3000.00000000"

    def test_trade_to_rest_format(self) -> None:
        trade = Trade(
            symbol="BTCUSDT",
            trade_id=100,
            price=68332.01,
            quantity=0.00016,
            quote_quantity=10.933122,
            buyer_maker=False,
            timestamp_ms=1499865549590,
            price_str="68332.01000000",
            quantity_str="0.00016000",
            quote_quantity_str="10.93312160",
        )
        rest = trade.to_rest_format()
        assert rest == {
            "id": 100,
            "price": "68332.01000000",
            "qty": "0.00016000",
            "quoteQty": "10.93312160",
            "time": 1499865549590,
            "isBuyerMaker": False,
            "isBestMatch": True,
        }

    def test_trade_defaults(self) -> None:
        trade = Trade(
            symbol="BTCUSDT",
            trade_id=1,
            price=100.0,
            quantity=1.0,
            quote_quantity=100.0,
            buyer_maker=False,
            timestamp_ms=1000,
        )
        assert trade.is_best_match is True
        assert trade.event_time_ms == 0
        assert trade.price_str == ""
        assert trade.quantity_str == ""


class TestOrderBookLevel:
    def test_level_is_frozen(self) -> None:
        level = OrderBookLevel(price=100.0, quantity=1.0)
        try:
            level.price = 200.0  # type: ignore[misc]
            assert False, "OrderBookLevel deberia ser inmutable"
        except AttributeError:
            pass

    def test_level_with_strings(self) -> None:
        level = OrderBookLevel(
            price=50000.0, quantity=1.5,
            price_str="50000.00000000", quantity_str="1.50000000",
        )
        assert level.price_str == "50000.00000000"
        assert level.to_rest_format() == ["50000.00000000", "1.50000000"]

    def test_level_to_rest_fallback(self) -> None:
        level = OrderBookLevel(price=100.0, quantity=2.0)
        rest = level.to_rest_format()
        assert len(rest) == 2
        assert float(rest[0]) == 100.0


class TestOrderBookSnapshot:
    def test_default_values(self) -> None:
        snap = OrderBookSnapshot(symbol="BTCUSDT")
        assert snap.bids == []
        assert snap.asks == []
        assert snap.last_update_id == 0
        assert snap.timestamp > 0
        assert snap.event_time_ms == 0
        assert snap.transaction_time_ms == 0

    def test_to_rest_format(self) -> None:
        snap = OrderBookSnapshot(
            symbol="BTCUSDT",
            bids=[OrderBookLevel(50000.0, 1.0, "50000.00", "1.00")],
            asks=[OrderBookLevel(50001.0, 0.5, "50001.00", "0.50")],
            last_update_id=12345,
        )
        rest = snap.to_rest_format()
        assert rest == {
            "lastUpdateId": 12345,
            "bids": [["50000.00", "1.00"]],
            "asks": [["50001.00", "0.50"]],
        }


class TestStreamStatus:
    def test_default_state(self) -> None:
        status = StreamStatus(
            stream_id="test",
            stream_type=StreamType.TRADE,
            symbol="BTCUSDT",
        )
        assert status.state == StreamState.STARTING
        assert status.message_count == 0
        assert status.error_count == 0
        assert status.reconnect_count == 0


class TestStreamState:
    def test_string_values(self) -> None:
        assert StreamState.RUNNING == "running"
        assert StreamState.STALE == "stale"
        assert StreamState.RECONNECTING == "reconnecting"


class TestMarket:
    def test_market_values(self) -> None:
        assert Market.SPOT == "spot"
        assert Market.FUTURES_USD == "futures_usd"
        assert Market.FUTURES_COIN == "futures_coin"

    def test_all_markets_have_urls(self) -> None:
        for market in Market:
            assert market in MARKET_URLS


class TestStreamConfig:
    def test_default_is_spot(self) -> None:
        config = StreamConfig()
        assert config.market == Market.SPOT
        assert "stream.binance.com" in config.base_url

    def test_futures_usd(self) -> None:
        config = StreamConfig(market=Market.FUTURES_USD)
        assert "fstream.binance.com" in config.base_url

    def test_futures_coin(self) -> None:
        config = StreamConfig(market=Market.FUTURES_COIN)
        assert "dstream.binance.com" in config.base_url

    def test_custom_url_overrides_market(self) -> None:
        config = StreamConfig(
            market=Market.SPOT,
            base_url="wss://custom.example.com/ws",
        )
        assert config.base_url == "wss://custom.example.com/ws"
