"""Test de carga: order books profundos (200 niveles) para todos los USDT+USDC.

Levanta diff depth streams para todos los pares activos en Binance Spot,
acumula actualizaciones incrementales durante 60 segundos y verifica
integridad estructural de los order books: orden de precios, spread positivo,
profundidad, update IDs crecientes y estabilidad del sistema.

Usa el Diff Depth Stream (@depth) que envia actualizaciones incrementales,
no snapshots parciales. Esto permite acumular hasta 200 niveles por lado
(bids + asks), verificando que la memoria y los sockets aguantan.
"""

import json
import time
import urllib.request

import pytest

from market_streaming import MarketStreamManager, StreamConfig

ACCUMULATION_SECONDS = 60
BOOK_DEPTH = 200
BATCH_SIZE = 200


def _fetch_all_usdt_usdc_symbols() -> list[str]:
    """Obtiene todos los pares USDT y USDC activos de Binance."""
    url = "https://api.binance.com/api/v3/exchangeInfo"
    data = json.loads(urllib.request.urlopen(url, timeout=15).read())
    symbols = sorted([
        s["symbol"] for s in data["symbols"]
        if s["status"] == "TRADING"
        and (s["symbol"].endswith("USDT") or s["symbol"].endswith("USDC"))
        and s["symbol"].isascii()
    ])
    return symbols


@pytest.fixture(scope="module")
def ob_results() -> dict:
    """Levanta combined diff depth streams, acumula 60s, recoge order books."""
    symbols = _fetch_all_usdt_usdc_symbols()
    stream_count = len(symbols)
    n_connections = (stream_count + BATCH_SIZE - 1) // BATCH_SIZE
    print(f"\nSymbols obtenidos de Binance: {stream_count}")
    print(f"Conexiones combinadas necesarias: {n_connections}")
    print(f"Profundidad objetivo: {BOOK_DEPTH} niveles por lado")

    config = StreamConfig(
        default_order_book_depth=BOOK_DEPTH,
        log_level=40,  # ERROR
        log_dir="",
    )

    manager = MarketStreamManager(config)
    manager.start()
    try:
        worker_ids = manager.add_order_book_streams(
            symbols, depth=BOOK_DEPTH, batch_size=BATCH_SIZE,
        )
        print(f"Workers combinados creados: {len(worker_ids)}")
        print(f"Acumulando datos durante {ACCUMULATION_SECONDS}s...")

        # Esperar conexion + acumulacion
        time.sleep(5 + ACCUMULATION_SECONDS)

        # Recoger todos los books
        books = {}
        for symbol in symbols:
            book = manager.get_order_book(symbol)
            if book is not None and (book.bids or book.asks):
                books[symbol] = book

        results = {
            "__books__": books,
            "__stats__": manager.get_stats(),
            "__health__": manager.get_health(),
            "__stream_count__": stream_count,
            "__worker_ids__": worker_ids,
        }
    finally:
        manager.stop()

    return results


class TestOrderBookLoad:
    """Verifica integridad de order books profundos bajo carga masiva."""

    def test_sufficient_symbols_have_books(self, ob_results: dict) -> None:
        books = ob_results["__books__"]
        stream_count = ob_results["__stream_count__"]
        total = len(books)
        print(f"\nSymbols con order book: {total}/{stream_count}")
        min_expected = stream_count * 0.3
        assert total >= min_expected, (
            f"Solo {total} symbols tienen order book, esperado >= {min_expected:.0f}"
        )

    def test_bids_sorted_descending(self, ob_results: dict) -> None:
        """Los bids deben estar ordenados de mayor a menor precio."""
        failures = []
        for symbol, book in ob_results["__books__"].items():
            if len(book.bids) < 2:
                continue
            for i in range(len(book.bids) - 1):
                if book.bids[i].price < book.bids[i + 1].price:
                    failures.append(
                        f"{symbol}: bid[{i}]={book.bids[i].price} < "
                        f"bid[{i+1}]={book.bids[i+1].price}"
                    )
                    break
        assert not failures, (
            f"BIDS DESORDENADOS en {len(failures)} symbols:\n  "
            + "\n  ".join(failures[:20])
        )

    def test_asks_sorted_ascending(self, ob_results: dict) -> None:
        """Los asks deben estar ordenados de menor a mayor precio."""
        failures = []
        for symbol, book in ob_results["__books__"].items():
            if len(book.asks) < 2:
                continue
            for i in range(len(book.asks) - 1):
                if book.asks[i].price > book.asks[i + 1].price:
                    failures.append(
                        f"{symbol}: ask[{i}]={book.asks[i].price} > "
                        f"ask[{i+1}]={book.asks[i+1].price}"
                    )
                    break
        assert not failures, (
            f"ASKS DESORDENADOS en {len(failures)} symbols:\n  "
            + "\n  ".join(failures[:20])
        )

    def test_spread_positive(self, ob_results: dict) -> None:
        """El spread (best ask - best bid) debe ser positivo o cero."""
        failures = []
        for symbol, book in ob_results["__books__"].items():
            if not book.bids or not book.asks:
                continue
            best_bid = book.bids[0].price
            best_ask = book.asks[0].price
            if best_ask < best_bid:
                spread_bps = (best_bid - best_ask) / best_ask * 10000
                failures.append(
                    f"{symbol}: ask={best_ask} < bid={best_bid} "
                    f"(spread negativo: {spread_bps:.1f} bps)"
                )
        assert not failures, (
            f"SPREAD NEGATIVO en {len(failures)} symbols:\n  "
            + "\n  ".join(failures[:20])
        )

    def test_book_depth_within_limits(self, ob_results: dict) -> None:
        """Ningun book debe exceder la profundidad configurada."""
        failures = []
        for symbol, book in ob_results["__books__"].items():
            if len(book.bids) > BOOK_DEPTH:
                failures.append(
                    f"{symbol}: {len(book.bids)} bids (max {BOOK_DEPTH})"
                )
            if len(book.asks) > BOOK_DEPTH:
                failures.append(
                    f"{symbol}: {len(book.asks)} asks (max {BOOK_DEPTH})"
                )
        assert not failures, (
            f"PROFUNDIDAD EXCEDIDA:\n  " + "\n  ".join(failures[:20])
        )

    def test_deep_books_accumulated(self, ob_results: dict) -> None:
        """Los symbols mas activos deben haber acumulado profundidad significativa."""
        books = ob_results["__books__"]
        depth_stats = []
        for symbol, book in books.items():
            depth_stats.append((symbol, len(book.bids), len(book.asks)))

        # Ordenar por profundidad total descendente
        depth_stats.sort(key=lambda x: x[1] + x[2], reverse=True)

        print(f"\n  Top 10 books por profundidad acumulada:")
        for symbol, n_bids, n_asks in depth_stats[:10]:
            print(f"    {symbol:<14} {n_bids:>4} bids, {n_asks:>4} asks")

        # Al menos algunos symbols deben tener profundidad alta
        deep_books = sum(1 for _, nb, na in depth_stats if nb >= 50 and na >= 50)
        print(f"\n  Books con >= 50 niveles por lado: {deep_books}")
        assert deep_books >= 5, (
            f"Solo {deep_books} books tienen >= 50 niveles por lado"
        )

    def test_prices_and_quantities_positive(self, ob_results: dict) -> None:
        """Todos los precios y cantidades deben ser positivos."""
        failures = []
        for symbol, book in ob_results["__books__"].items():
            for side, levels in [("bid", book.bids), ("ask", book.asks)]:
                for i, level in enumerate(levels):
                    if level.price <= 0:
                        failures.append(
                            f"{symbol}: {side}[{i}] price={level.price}"
                        )
                    if level.quantity <= 0:
                        failures.append(
                            f"{symbol}: {side}[{i}] qty={level.quantity}"
                        )
        assert not failures, (
            f"VALORES NO POSITIVOS:\n  " + "\n  ".join(failures[:20])
        )

    def test_update_ids_positive(self, ob_results: dict) -> None:
        """Todos los order books deben tener update ID > 0."""
        zero_ids = []
        for symbol, book in ob_results["__books__"].items():
            if book.last_update_id <= 0:
                zero_ids.append(symbol)
        assert not zero_ids, (
            f"{len(zero_ids)} symbols con update_id <= 0: "
            + ", ".join(zero_ids[:20])
        )

    def test_string_precision_preserved(self, ob_results: dict) -> None:
        """Los niveles deben preservar cadenas originales de precision."""
        checked = 0
        missing_strings = []
        for symbol, book in ob_results["__books__"].items():
            for level in book.bids[:3] + book.asks[:3]:
                checked += 1
                if not level.price_str or not level.quantity_str:
                    missing_strings.append(
                        f"{symbol}: price_str='{level.price_str}' "
                        f"qty_str='{level.quantity_str}'"
                    )
        print(f"\nNiveles verificados: {checked}")
        assert not missing_strings, (
            f"PRECISION PERDIDA en {len(missing_strings)} niveles:\n  "
            + "\n  ".join(missing_strings[:10])
        )

    def test_combined_workers_healthy(self, ob_results: dict) -> None:
        """Verifica que los workers combinados funcionaron correctamente."""
        health = ob_results["__health__"]
        worker_ids = ob_results["__worker_ids__"]
        n_workers = len(worker_ids)
        print(f"\nWorkers combinados: {n_workers}")
        print(f"Running: {health.running_streams}")
        print(f"Stale: {health.stale_streams}")
        print(f"Reconnecting: {health.reconnecting_streams}")
        print(f"Total mensajes: {health.total_messages:,}")
        assert health.running_streams >= n_workers * 0.8, (
            f"Solo {health.running_streams}/{n_workers} workers running"
        )

    def test_total_messages_reasonable(self, ob_results: dict) -> None:
        stats = ob_results["__stats__"]
        total = stats["total_messages"]
        print(f"\nTotal mensajes procesados: {total:,}")
        assert total > 1000, f"Solo {total} mensajes en {ACCUMULATION_SECONDS}s"

    def test_memory_footprint(self, ob_results: dict) -> None:
        """Verifica que el footprint de memoria es razonable."""
        import sys
        books = ob_results["__books__"]
        total_levels = sum(
            len(b.bids) + len(b.asks) for b in books.values()
        )
        # Estimacion burda del tamanio en memoria
        sample_books = list(books.values())[:5]
        if sample_books:
            avg_book_size = sum(sys.getsizeof(b) for b in sample_books) / len(sample_books)
            estimated_mb = (avg_book_size * len(books)) / (1024 * 1024)
        else:
            estimated_mb = 0
        print(f"\nTotal niveles en memoria: {total_levels:,}")
        print(f"Estimacion footprint: {estimated_mb:.1f} MB")
        # 200 niveles * 2 lados * 728 symbols = ~291K niveles max
        # Cada nivel ~200 bytes -> ~58 MB max, razonable
        assert total_levels > 0

    def test_load_summary(self, ob_results: dict) -> None:
        """Resumen final de la prueba de carga de order books."""
        stream_count = ob_results["__stream_count__"]
        worker_ids = ob_results["__worker_ids__"]
        books = ob_results["__books__"]
        stats = ob_results["__stats__"]

        # Estadisticas de profundidad
        bid_depths = [len(b.bids) for b in books.values()]
        ask_depths = [len(b.asks) for b in books.values()]
        total_levels = sum(bid_depths) + sum(ask_depths)

        full_depth = sum(
            1 for b in books.values()
            if len(b.bids) >= BOOK_DEPTH and len(b.asks) >= BOOK_DEPTH
        )
        deep_50 = sum(
            1 for b in books.values()
            if len(b.bids) >= 50 and len(b.asks) >= 50
        )
        deep_100 = sum(
            1 for b in books.values()
            if len(b.bids) >= 100 and len(b.asks) >= 100
        )

        avg_bid = sum(bid_depths) / len(bid_depths) if bid_depths else 0
        avg_ask = sum(ask_depths) / len(ask_depths) if ask_depths else 0

        # Spreads
        spreads = {}
        for symbol, book in books.items():
            if book.bids and book.asks:
                mid = (book.bids[0].price + book.asks[0].price) / 2
                if mid > 0:
                    spread_bps = (
                        (book.asks[0].price - book.bids[0].price) / mid * 10000
                    )
                    spreads[symbol] = spread_bps

        sorted_spreads = sorted(spreads.items(), key=lambda x: x[1])

        print(f"\n{'='*60}")
        print(f"  RESUMEN PRUEBA DE CARGA - ORDER BOOKS PROFUNDOS")
        print(f"{'='*60}")
        print(f"  Symbols:               {stream_count}")
        print(f"  Conexiones WS:         {len(worker_ids)}")
        print(f"  Duracion:              {ACCUMULATION_SECONDS}s")
        print(f"  Profundidad objetivo:  {BOOK_DEPTH} niveles/lado")
        print(f"  Books recibidos:       {len(books)}")
        print(f"  Total niveles:         {total_levels:,}")
        print(f"  Profundidad media:     {avg_bid:.0f} bids, {avg_ask:.0f} asks")
        print(f"  Books >= 200 niveles:  {full_depth}")
        print(f"  Books >= 100 niveles:  {deep_100}")
        print(f"  Books >= 50 niveles:   {deep_50}")
        print(f"  Total mensajes:        {stats['total_messages']:,}")
        if sorted_spreads:
            print(f"\n  Top 5 spreads mas ajustados (bps):")
            for symbol, spread in sorted_spreads[:5]:
                book = books[symbol]
                print(
                    f"    {symbol:<14} {spread:>8.2f} bps  "
                    f"({len(book.bids)} bids, {len(book.asks)} asks)"
                )
            print(f"\n  Top 5 spreads mas amplios (bps):")
            for symbol, spread in sorted_spreads[-5:]:
                book = books[symbol]
                print(
                    f"    {symbol:<14} {spread:>8.2f} bps  "
                    f"({len(book.bids)} bids, {len(book.asks)} asks)"
                )
        print(f"{'='*60}")
