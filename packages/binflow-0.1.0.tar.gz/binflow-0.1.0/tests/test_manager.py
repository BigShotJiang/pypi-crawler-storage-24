"""Tests unitarios para MarketStreamManager."""

import pytest

from market_streaming.config import StreamConfig
from market_streaming.exceptions import (
    ManagerNotRunningError,
    StreamAlreadyExistsError,
)
from market_streaming.manager import MarketStreamManager


@pytest.fixture
def config() -> StreamConfig:
    return StreamConfig(log_dir="")


class TestManagerLifecycle:
    def test_start_and_stop(self, config: StreamConfig) -> None:
        manager = MarketStreamManager(config)
        manager.start()
        assert manager._running is True
        manager.stop()
        assert manager._running is False

    def test_double_start(self, config: StreamConfig) -> None:
        manager = MarketStreamManager(config)
        manager.start()
        manager.start()  # No debe fallar
        manager.stop()

    def test_stop_without_start(self, config: StreamConfig) -> None:
        manager = MarketStreamManager(config)
        manager.stop()  # No debe fallar

    def test_context_manager(self, config: StreamConfig) -> None:
        with MarketStreamManager(config) as mgr:
            assert mgr._running is True
        assert mgr._running is False

    def test_operations_require_running(self, config: StreamConfig) -> None:
        manager = MarketStreamManager(config)
        with pytest.raises(ManagerNotRunningError):
            manager.add_trade_stream("BTCUSDT")


class TestManagerStreams:
    def test_add_trade_stream(self, config: StreamConfig) -> None:
        with MarketStreamManager(config) as mgr:
            stream_id = mgr.add_trade_stream("BTCUSDT")
            assert stream_id == "trade_BTCUSDT"
            assert stream_id in mgr.get_all_streams_status()

    def test_add_order_book_stream(self, config: StreamConfig) -> None:
        with MarketStreamManager(config) as mgr:
            stream_id = mgr.add_order_book_stream("ETHUSDT", depth=10)
            assert stream_id == "depth_ETHUSDT"

    def test_duplicate_stream_raises(self, config: StreamConfig) -> None:
        with MarketStreamManager(config) as mgr:
            mgr.add_trade_stream("BTCUSDT")
            with pytest.raises(StreamAlreadyExistsError):
                mgr.add_trade_stream("BTCUSDT")

    def test_remove_stream(self, config: StreamConfig) -> None:
        with MarketStreamManager(config) as mgr:
            mgr.add_trade_stream("BTCUSDT")
            mgr.remove_stream("trade_BTCUSDT")
            assert "trade_BTCUSDT" not in mgr.get_all_streams_status()


class TestManagerObservability:
    def test_get_stats(self, config: StreamConfig) -> None:
        with MarketStreamManager(config) as mgr:
            stats = mgr.get_stats()
            assert "running" in stats
            assert stats["running"] is True
            assert stats["total_streams"] == 0

    def test_get_health_empty(self, config: StreamConfig) -> None:
        with MarketStreamManager(config) as mgr:
            health = mgr.get_health()
            assert health.is_healthy is False  # No hay streams
            assert health.total_streams == 0

    def test_empty_cache_queries(self, config: StreamConfig) -> None:
        with MarketStreamManager(config) as mgr:
            assert mgr.get_last_trade("BTCUSDT") is None
            assert mgr.get_recent_trades("BTCUSDT") == []
            assert mgr.get_order_book("BTCUSDT") is None
