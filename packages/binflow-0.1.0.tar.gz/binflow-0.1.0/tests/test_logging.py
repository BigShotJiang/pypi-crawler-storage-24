"""Tests unitarios para el sistema de logging."""

import logging
from pathlib import Path

import pytest

from market_streaming.config import StreamConfig
from market_streaming.logging_config import (
    PACKAGE_LOGGER_NAME,
    setup_logging,
    teardown_logging,
)


@pytest.fixture(autouse=True)
def clean_logger():
    """Limpia handlers entre tests para evitar acumulacion."""
    yield
    teardown_logging()


class TestSetupLogging:
    def test_console_only_when_no_log_dir(self) -> None:
        config = StreamConfig(log_dir="")
        logger = setup_logging(config)
        assert logger.name == PACKAGE_LOGGER_NAME
        assert len(logger.handlers) == 1  # solo consola
        assert isinstance(logger.handlers[0], logging.StreamHandler)

    def test_creates_file_handlers(self, tmp_path: Path) -> None:
        config = StreamConfig(log_dir=str(tmp_path / "test_logs"))
        logger = setup_logging(config)
        # consola + general + errores = 3 handlers
        assert len(logger.handlers) == 3
        assert (tmp_path / "test_logs" / "binflow.log").exists()
        assert (tmp_path / "test_logs" / "binflow.error.log").exists()

    def test_creates_log_directory(self, tmp_path: Path) -> None:
        log_dir = tmp_path / "deep" / "nested" / "logs"
        config = StreamConfig(log_dir=str(log_dir))
        setup_logging(config)
        assert log_dir.is_dir()

    def test_writes_to_general_log(self, tmp_path: Path) -> None:
        config = StreamConfig(log_dir=str(tmp_path))
        logger = setup_logging(config)
        logger.info("test message 12345")
        # Flush handlers
        for h in logger.handlers:
            h.flush()
        content = (tmp_path / "binflow.log").read_text()
        assert "test message 12345" in content

    def test_error_log_only_captures_warnings_and_above(self, tmp_path: Path) -> None:
        config = StreamConfig(log_dir=str(tmp_path))
        logger = setup_logging(config)
        logger.info("info message")
        logger.warning("warning message")
        logger.error("error message")
        for h in logger.handlers:
            h.flush()
        error_content = (tmp_path / "binflow.error.log").read_text()
        assert "info message" not in error_content
        assert "warning message" in error_content
        assert "error message" in error_content

    def test_idempotent_setup(self, tmp_path: Path) -> None:
        config = StreamConfig(log_dir=str(tmp_path))
        logger1 = setup_logging(config)
        handler_count = len(logger1.handlers)
        logger2 = setup_logging(config)
        assert logger1 is logger2
        assert len(logger2.handlers) == handler_count  # no duplica handlers

    def test_log_level_applies_to_console(self) -> None:
        config = StreamConfig(log_dir="", log_level=logging.WARNING)
        logger = setup_logging(config)
        assert logger.handlers[0].level == logging.WARNING

    def test_general_file_captures_debug(self, tmp_path: Path) -> None:
        config = StreamConfig(log_dir=str(tmp_path))
        logger = setup_logging(config)
        logger.debug("debug trace xyz")
        for h in logger.handlers:
            h.flush()
        content = (tmp_path / "binflow.log").read_text()
        assert "debug trace xyz" in content


class TestTeardownLogging:
    def test_removes_all_handlers(self, tmp_path: Path) -> None:
        config = StreamConfig(log_dir=str(tmp_path))
        setup_logging(config)
        teardown_logging()
        logger = logging.getLogger(PACKAGE_LOGGER_NAME)
        assert len(logger.handlers) == 0

    def test_teardown_idempotent(self) -> None:
        teardown_logging()
        teardown_logging()  # no debe fallar


class TestRotationConfig:
    def test_default_max_bytes(self) -> None:
        config = StreamConfig()
        assert config.log_max_bytes == 10 * 1024 * 1024  # 10 MB

    def test_default_backup_count(self) -> None:
        config = StreamConfig()
        assert config.log_backup_count == 5

    def test_custom_rotation(self) -> None:
        config = StreamConfig(log_max_bytes=1024, log_backup_count=2)
        assert config.log_max_bytes == 1024
        assert config.log_backup_count == 2
