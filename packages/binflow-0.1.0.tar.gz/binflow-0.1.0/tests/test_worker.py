"""Tests unitarios para WebSocketStreamWorker."""

import json

import pytest

from market_streaming.cache import MarketDataCache
from market_streaming.config import Market, StreamConfig
from market_streaming.models import StreamState, StreamType
from market_streaming.worker import WebSocketStreamWorker


@pytest.fixture
def config() -> StreamConfig:
    return StreamConfig(max_recent_trades=100, default_order_book_depth=5)


@pytest.fixture
def cache(config: StreamConfig) -> MarketDataCache:
    return MarketDataCache(config)


@pytest.fixture
def trade_worker(config: StreamConfig, cache: MarketDataCache) -> WebSocketStreamWorker:
    return WebSocketStreamWorker(
        stream_id="trade_BTCUSDT",
        stream_type=StreamType.TRADE,
        symbol="BTCUSDT",
        config=config,
        cache=cache,
    )


@pytest.fixture
def depth_worker(config: StreamConfig, cache: MarketDataCache) -> WebSocketStreamWorker:
    return WebSocketStreamWorker(
        stream_id="depth_BTCUSDT",
        stream_type=StreamType.DEPTH,
        symbol="BTCUSDT",
        config=config,
        cache=cache,
        depth=5,
    )


class TestWorkerInit:
    def test_initial_state(self, trade_worker: WebSocketStreamWorker) -> None:
        assert trade_worker.status.state == StreamState.STARTING
        assert trade_worker.status.message_count == 0
        assert trade_worker.stream_id == "trade_BTCUSDT"

    def test_url_trade(self, trade_worker: WebSocketStreamWorker) -> None:
        url = trade_worker._build_url()
        assert "btcusdt@trade" in url

    def test_url_depth(self, depth_worker: WebSocketStreamWorker) -> None:
        url = depth_worker._build_url()
        assert "btcusdt@depth5" in url

    def test_url_spot_default(self, trade_worker: WebSocketStreamWorker) -> None:
        url = trade_worker._build_url()
        assert "stream.binance.com" in url

    def test_url_futures_usd(self, cache: MarketDataCache) -> None:
        cfg = StreamConfig(market=Market.FUTURES_USD, max_recent_trades=100)
        worker = WebSocketStreamWorker(
            stream_id="trade_BTCUSDT",
            stream_type=StreamType.TRADE,
            symbol="BTCUSDT",
            config=cfg,
            cache=cache,
        )
        url = worker._build_url()
        assert "fstream.binance.com" in url

    def test_url_futures_coin(self, cache: MarketDataCache) -> None:
        cfg = StreamConfig(market=Market.FUTURES_COIN, max_recent_trades=100)
        worker = WebSocketStreamWorker(
            stream_id="trade_BTCUSD_PERP",
            stream_type=StreamType.TRADE,
            symbol="BTCUSD_PERP",
            config=cfg,
            cache=cache,
        )
        url = worker._build_url()
        assert "dstream.binance.com" in url

    def test_url_custom_base_url(self, cache: MarketDataCache) -> None:
        cfg = StreamConfig(base_url="wss://custom.example.com/ws", max_recent_trades=100)
        worker = WebSocketStreamWorker(
            stream_id="trade_BTCUSDT",
            stream_type=StreamType.TRADE,
            symbol="BTCUSDT",
            config=cfg,
            cache=cache,
        )
        url = worker._build_url()
        assert "custom.example.com" in url


class TestWorkerMessageProcessing:
    def test_process_trade_message(
        self, trade_worker: WebSocketStreamWorker, cache: MarketDataCache
    ) -> None:
        msg = json.dumps({
            "e": "trade",
            "E": 1234567890,
            "s": "BTCUSDT",
            "t": 100,
            "p": "50000.00",
            "q": "0.50000000",
            "T": 1234567890,
            "m": False,
            "M": True,
        })
        trade_worker._process_message(msg)

        assert trade_worker.status.message_count == 1
        assert trade_worker.status.last_message_at is not None

        last = cache.get_last_trade("BTCUSDT")
        assert last is not None
        assert last.price == 50000.0
        assert last.quantity == 0.5
        assert last.quote_quantity == 25000.0
        assert last.price_str == "50000.00"
        assert last.quantity_str == "0.50000000"
        assert last.is_best_match is True
        assert last.event_time_ms == 1234567890

    def test_trade_to_rest_format(
        self, trade_worker: WebSocketStreamWorker, cache: MarketDataCache
    ) -> None:
        msg = json.dumps({
            "e": "trade",
            "E": 1234567890,
            "s": "BTCUSDT",
            "t": 42,
            "p": "68332.01000000",
            "q": "0.00016000",
            "T": 1499865549590,
            "m": False,
            "M": True,
        })
        trade_worker._process_message(msg)
        last = cache.get_last_trade("BTCUSDT")
        rest = last.to_rest_format()
        assert rest["id"] == 42
        assert rest["price"] == "68332.01000000"
        assert rest["qty"] == "0.00016000"
        assert "quoteQty" in rest
        assert rest["time"] == 1499865549590
        assert rest["isBuyerMaker"] is False
        assert rest["isBestMatch"] is True

    def test_process_depth_update(
        self, depth_worker: WebSocketStreamWorker, cache: MarketDataCache
    ) -> None:
        msg = json.dumps({
            "e": "depthUpdate",
            "E": 1234567890,
            "T": 1234567891,
            "s": "BTCUSDT",
            "U": 1,
            "u": 5,
            "b": [["50000.00000000", "1.00000000"], ["49999.00000000", "2.00000000"]],
            "a": [["50001.00000000", "0.50000000"]],
        })
        depth_worker._process_message(msg)

        book = cache.get_order_book("BTCUSDT")
        assert book is not None
        assert len(book.bids) == 2
        assert len(book.asks) == 1
        assert book.bids[0].price_str == "50000.00000000"
        assert book.bids[0].quantity_str == "1.00000000"
        assert book.event_time_ms == 1234567890
        assert book.transaction_time_ms == 1234567891

    def test_process_depth_snapshot(
        self, depth_worker: WebSocketStreamWorker, cache: MarketDataCache
    ) -> None:
        msg = json.dumps({
            "lastUpdateId": 100,
            "bids": [["50000.00000000", "1.00000000"]],
            "asks": [["50001.00000000", "0.50000000"]],
        })
        depth_worker._process_message(msg)

        book = cache.get_order_book("BTCUSDT")
        assert book is not None
        assert book.last_update_id == 100
        assert book.bids[0].price_str == "50000.00000000"

    def test_depth_to_rest_format(
        self, depth_worker: WebSocketStreamWorker, cache: MarketDataCache
    ) -> None:
        msg = json.dumps({
            "lastUpdateId": 200,
            "bids": [["50000.00000000", "1.00000000"]],
            "asks": [["50001.00000000", "0.50000000"]],
        })
        depth_worker._process_message(msg)
        book = cache.get_order_book("BTCUSDT")
        rest = book.to_rest_format()
        assert rest["lastUpdateId"] == 200
        assert rest["bids"] == [["50000.00000000", "1.00000000"]]
        assert rest["asks"] == [["50001.00000000", "0.50000000"]]

    def test_invalid_json(self, trade_worker: WebSocketStreamWorker) -> None:
        trade_worker._process_message("not json at all")
        assert trade_worker.status.error_count == 1
        assert trade_worker.status.message_count == 1


class TestWorkerBackoff:
    def test_backoff_increases(self, trade_worker: WebSocketStreamWorker) -> None:
        d1 = trade_worker._calculate_backoff(1)
        d2 = trade_worker._calculate_backoff(3)
        # Con jitter puede variar, pero en promedio d2 >> d1
        # Verificamos al menos que el cálculo no falle y sea positivo
        assert d1 > 0
        assert d2 > 0

    def test_backoff_capped(self, trade_worker: WebSocketStreamWorker) -> None:
        # Attempt muy alto debería estar acotado por max_delay
        delay = trade_worker._calculate_backoff(100)
        max_with_jitter = (
            trade_worker._config.reconnect_max_delay_s * 1.3  # margen jitter
        )
        assert delay <= max_with_jitter
