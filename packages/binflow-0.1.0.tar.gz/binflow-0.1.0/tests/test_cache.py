"""Tests unitarios para MarketDataCache."""

import time

import pytest

from market_streaming.cache import MarketDataCache
from market_streaming.config import StreamConfig
from market_streaming.models import OrderBookLevel, OrderBookSnapshot, Trade


@pytest.fixture
def config() -> StreamConfig:
    return StreamConfig(max_recent_trades=5, default_order_book_depth=3)


@pytest.fixture
def cache(config: StreamConfig) -> MarketDataCache:
    return MarketDataCache(config)


def _make_trade(symbol: str = "BTCUSDT", price: float = 50000.0, tid: int = 1) -> Trade:
    qty = 0.1
    return Trade(
        symbol=symbol,
        trade_id=tid,
        price=price,
        quantity=qty,
        quote_quantity=price * qty,
        buyer_maker=False,
        timestamp_ms=int(time.time() * 1000),
    )


# ---------- Trades ----------


class TestTradeCache:
    def test_last_trade_empty(self, cache: MarketDataCache) -> None:
        assert cache.get_last_trade("BTCUSDT") is None

    def test_update_and_get_last_trade(self, cache: MarketDataCache) -> None:
        trade = _make_trade(price=50000.0)
        cache.update_trade(trade)
        last = cache.get_last_trade("BTCUSDT")
        assert last is not None
        assert last.price == 50000.0

    def test_last_trade_updates(self, cache: MarketDataCache) -> None:
        cache.update_trade(_make_trade(price=50000.0, tid=1))
        cache.update_trade(_make_trade(price=51000.0, tid=2))
        assert cache.get_last_trade("BTCUSDT").price == 51000.0  # type: ignore[union-attr]

    def test_recent_trades_limit(self, cache: MarketDataCache) -> None:
        for i in range(10):
            cache.update_trade(_make_trade(price=float(i), tid=i))
        # maxlen=5, pedir 3
        trades = cache.get_recent_trades("BTCUSDT", limit=3)
        assert len(trades) == 3
        assert trades[0].price == 7.0  # últimos 5 son [5,6,7,8,9], últimos 3 son [7,8,9]

    def test_recent_trades_respects_deque_maxlen(self, cache: MarketDataCache) -> None:
        for i in range(10):
            cache.update_trade(_make_trade(price=float(i), tid=i))
        all_trades = cache.get_recent_trades("BTCUSDT", limit=100)
        assert len(all_trades) == 5  # maxlen del deque

    def test_symbol_case_insensitive(self, cache: MarketDataCache) -> None:
        cache.update_trade(_make_trade(symbol="btcusdt"))
        assert cache.get_last_trade("BTCUSDT") is not None
        assert cache.get_last_trade("btcusdt") is not None

    def test_empty_recent_trades(self, cache: MarketDataCache) -> None:
        assert cache.get_recent_trades("ETHUSDT") == []

    def test_trade_ids_continuous(self, cache: MarketDataCache) -> None:
        for tid in range(100, 120):
            cache.update_trade(_make_trade(tid=tid))
        trades = cache.get_recent_trades("BTCUSDT", limit=100)
        ids = [t.trade_id for t in trades]
        gaps = [
            (ids[i], ids[i + 1])
            for i in range(len(ids) - 1)
            if ids[i + 1] - ids[i] != 1
        ]
        assert gaps == [], f"Huecos en IDs: {gaps}"

    def test_trade_ids_continuous_after_overflow(self, cache: MarketDataCache) -> None:
        # maxlen=5, insertamos 10 IDs consecutivos: solo quedan los ultimos 5
        for tid in range(100, 110):
            cache.update_trade(_make_trade(tid=tid))
        trades = cache.get_recent_trades("BTCUSDT", limit=100)
        ids = [t.trade_id for t in trades]
        assert ids == [105, 106, 107, 108, 109]
        gaps = [
            (ids[i], ids[i + 1])
            for i in range(len(ids) - 1)
            if ids[i + 1] - ids[i] != 1
        ]
        assert gaps == []


# ---------- Order Book ----------


class TestOrderBookCache:
    def test_empty_order_book(self, cache: MarketDataCache) -> None:
        assert cache.get_order_book("BTCUSDT") is None

    def test_update_order_book(self, cache: MarketDataCache) -> None:
        snapshot = OrderBookSnapshot(
            symbol="BTCUSDT",
            bids=[OrderBookLevel(50000.0, 1.0)],
            asks=[OrderBookLevel(50001.0, 0.5)],
            last_update_id=100,
        )
        cache.update_order_book(snapshot)
        book = cache.get_order_book("BTCUSDT")
        assert book is not None
        assert len(book.bids) == 1
        assert book.bids[0].price == 50000.0

    def test_order_book_returns_copy(self, cache: MarketDataCache) -> None:
        snapshot = OrderBookSnapshot(
            symbol="BTCUSDT",
            bids=[OrderBookLevel(50000.0, 1.0)],
            asks=[],
            last_update_id=1,
        )
        cache.update_order_book(snapshot)
        book1 = cache.get_order_book("BTCUSDT")
        book2 = cache.get_order_book("BTCUSDT")
        assert book1 is not book2

    def test_apply_depth_update(self, cache: MarketDataCache) -> None:
        # Snapshot inicial
        snapshot = OrderBookSnapshot(
            symbol="BTCUSDT",
            bids=[OrderBookLevel(100.0, 1.0), OrderBookLevel(99.0, 2.0)],
            asks=[OrderBookLevel(101.0, 1.0)],
            last_update_id=10,
        )
        cache.update_order_book(snapshot)

        # Actualización incremental
        cache.apply_depth_update(
            "BTCUSDT",
            bids=[OrderBookLevel(100.0, 3.0)],  # Actualizar cantidad
            asks=[OrderBookLevel(102.0, 0.5)],   # Nuevo nivel
            last_update_id=11,
        )
        book = cache.get_order_book("BTCUSDT")
        assert book is not None
        bid_prices = {b.price for b in book.bids}
        assert 100.0 in bid_prices
        # La cantidad del bid a 100.0 se actualizó
        bid_100 = next(b for b in book.bids if b.price == 100.0)
        assert bid_100.quantity == 3.0

    def test_apply_depth_removes_zero_quantity(self, cache: MarketDataCache) -> None:
        snapshot = OrderBookSnapshot(
            symbol="BTCUSDT",
            bids=[OrderBookLevel(100.0, 1.0), OrderBookLevel(99.0, 2.0)],
            asks=[],
            last_update_id=10,
        )
        cache.update_order_book(snapshot)

        cache.apply_depth_update(
            "BTCUSDT",
            bids=[OrderBookLevel(100.0, 0.0)],  # Eliminar nivel
            asks=[],
            last_update_id=11,
        )
        book = cache.get_order_book("BTCUSDT")
        assert book is not None
        bid_prices = {b.price for b in book.bids}
        assert 100.0 not in bid_prices

    def test_apply_depth_ignores_old_update_id(self, cache: MarketDataCache) -> None:
        snapshot = OrderBookSnapshot(
            symbol="BTCUSDT",
            bids=[OrderBookLevel(100.0, 1.0)],
            asks=[],
            last_update_id=10,
        )
        cache.update_order_book(snapshot)

        cache.apply_depth_update(
            "BTCUSDT",
            bids=[OrderBookLevel(100.0, 999.0)],
            asks=[],
            last_update_id=5,  # Antiguo
        )
        book = cache.get_order_book("BTCUSDT")
        assert book is not None
        assert book.bids[0].quantity == 1.0  # Sin cambios

    def test_apply_depth_respects_max_depth(self, cache: MarketDataCache) -> None:
        # config tiene depth=3
        cache.apply_depth_update(
            "BTCUSDT",
            bids=[
                OrderBookLevel(100.0, 1.0),
                OrderBookLevel(99.0, 1.0),
                OrderBookLevel(98.0, 1.0),
                OrderBookLevel(97.0, 1.0),  # Excede max_depth
            ],
            asks=[],
            last_update_id=1,
        )
        book = cache.get_order_book("BTCUSDT")
        assert book is not None
        assert len(book.bids) == 3
        assert book.bids[0].price == 100.0  # Ordenados descendente


# ---------- Misc ----------


class TestCacheMisc:
    def test_get_symbols(self, cache: MarketDataCache) -> None:
        cache.update_trade(_make_trade(symbol="BTCUSDT"))
        cache.update_order_book(
            OrderBookSnapshot(symbol="ETHUSDT", last_update_id=1)
        )
        symbols = cache.get_symbols()
        assert "BTCUSDT" in symbols
        assert "ETHUSDT" in symbols

    def test_clear(self, cache: MarketDataCache) -> None:
        cache.update_trade(_make_trade())
        cache.clear()
        assert cache.get_last_trade("BTCUSDT") is None
        assert cache.get_symbols() == []
