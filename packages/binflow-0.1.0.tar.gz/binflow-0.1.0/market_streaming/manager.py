"""API pública del sistema de streaming de mercado.

MarketStreamManager es la fachada principal. Arranca un thread dedicado con
un event loop asyncio, gestiona workers, expone datos del cache y métricas.

Modelo de concurrencia
----------------------
Se usa un thread dedicado con event loop asyncio. Esto permite:
- API pública síncrona (sin await en el código cliente).
- Múltiples conexiones WebSocket concurrentes dentro del event loop.
- Cache protegido con threading.Lock (escritura desde asyncio, lectura sync).
El contention del Lock es mínimo porque las operaciones de cache son O(1).
"""

from __future__ import annotations

import asyncio
import logging
import threading
import time
from typing import Any

from .cache import MarketDataCache
from .config import StreamConfig
from .exceptions import (
    ManagerNotRunningError,
    StreamAlreadyExistsError,
)
from .health import HealthMonitor
from .logging_config import setup_logging, teardown_logging
from .models import (
    OrderBookSnapshot,
    StreamState,
    StreamStatus,
    StreamType,
    SystemHealth,
    Trade,
)
from .worker import CombinedStreamWorker, WebSocketStreamWorker

logger = logging.getLogger(__name__)


class MarketStreamManager:
    """Fachada principal del motor de WebSockets de mercado.

    Uso básico::

        manager = MarketStreamManager()
        manager.start()
        manager.add_trade_stream("BTCUSDT")
        trade = manager.get_last_trade("BTCUSDT")
        manager.stop()

    También soporta context manager::

        with MarketStreamManager() as mgr:
            mgr.add_trade_stream("BTCUSDT")
    """

    def __init__(self, config: StreamConfig | None = None) -> None:
        self._config = config or StreamConfig()
        self._cache = MarketDataCache(self._config)
        self._health_monitor = HealthMonitor(self._config)
        self._workers: dict[str, WebSocketStreamWorker] = {}
        self._loop: asyncio.AbstractEventLoop | None = None
        self._thread: threading.Thread | None = None
        self._started_at: float = 0.0
        self._running = False
        self._lock = threading.Lock()

        setup_logging(self._config)

    # ------------------------------------------------------------------
    # Context manager
    # ------------------------------------------------------------------

    def __enter__(self) -> MarketStreamManager:
        self.start()
        return self

    def __exit__(self, *args: Any) -> None:
        self.stop()

    # ------------------------------------------------------------------
    # Arranque y parada
    # ------------------------------------------------------------------

    def start(self) -> None:
        """Arranca el motor de streaming en un thread dedicado."""
        if self._running:
            logger.warning("Manager ya está en ejecución")
            return

        self._loop = asyncio.new_event_loop()
        self._started_at = time.time()
        self._running = True

        self._thread = threading.Thread(
            target=self._run_loop,
            name="market-stream-loop",
            daemon=True,
        )
        self._thread.start()
        logger.info("MarketStreamManager iniciado")

    def stop(self) -> None:
        """Detiene todos los streams y libera recursos de forma limpia."""
        if not self._running:
            return

        self._running = False
        logger.info("Deteniendo MarketStreamManager...")

        loop = self._loop
        if loop is not None and not loop.is_closed():
            future = asyncio.run_coroutine_threadsafe(
                self._stop_all_workers(), loop
            )
            try:
                future.result(timeout=10.0)
            except Exception as exc:
                logger.warning("Error deteniendo workers: %s", exc)

            loop.call_soon_threadsafe(loop.stop)

        if self._thread is not None:
            self._thread.join(timeout=5.0)
            if self._thread.is_alive():
                logger.warning("Thread del event loop no terminó a tiempo")

        if loop is not None and not loop.is_closed():
            loop.close()

        self._loop = None
        self._thread = None
        self._workers.clear()
        logger.info("MarketStreamManager detenido")
        teardown_logging()

    # ------------------------------------------------------------------
    # Registro de streams
    # ------------------------------------------------------------------

    def add_trade_stream(self, symbol: str) -> str:
        """Registra y arranca un stream de trades para un símbolo.

        Parameters
        ----------
        symbol : str
            Par de trading (ej: "BTCUSDT").

        Returns
        -------
        str
            Identificador del stream creado.
        """
        self._ensure_running()
        stream_id = f"trade_{symbol.upper()}"
        self._ensure_unique(stream_id)

        worker = WebSocketStreamWorker(
            stream_id=stream_id,
            stream_type=StreamType.TRADE,
            symbol=symbol,
            config=self._config,
            cache=self._cache,
        )
        self._register_and_start(stream_id, worker)
        logger.info("Stream de trades registrado: %s", stream_id)
        return stream_id

    def add_order_book_stream(self, symbol: str, depth: int | None = None) -> str:
        """Registra y arranca un stream de order book para un símbolo.

        Parameters
        ----------
        symbol : str
            Par de trading (ej: "BTCUSDT").
        depth : int, opcional
            Profundidad del order book (default: config).

        Returns
        -------
        str
            Identificador del stream creado.
        """
        self._ensure_running()
        depth = depth or self._config.default_order_book_depth
        stream_id = f"depth_{symbol.upper()}"
        self._ensure_unique(stream_id)

        worker = WebSocketStreamWorker(
            stream_id=stream_id,
            stream_type=StreamType.DEPTH,
            symbol=symbol,
            config=self._config,
            cache=self._cache,
            depth=depth,
        )
        self._register_and_start(stream_id, worker)
        logger.info("Stream de order book registrado: %s", stream_id)
        return stream_id

    def add_trade_streams(
        self, symbols: list[str], batch_size: int = 200,
    ) -> list[str]:
        """Registra streams de trades para multiples simbolos en conexiones combinadas.

        Usa el endpoint de combined streams de Binance para multiplexar
        hasta ``batch_size`` simbolos por conexion WebSocket. Esto permite
        escalar a cientos de simbolos sin saturar el rate limit de conexiones.

        Parameters
        ----------
        symbols : list[str]
            Lista de pares de trading (ej: ["BTCUSDT", "ETHUSDT", ...]).
        batch_size : int
            Simbolos por conexion WebSocket (default: 200).

        Returns
        -------
        list[str]
            Identificadores de los workers combinados creados.
        """
        self._ensure_running()

        worker_ids = []
        for i in range(0, len(symbols), batch_size):
            batch = symbols[i:i + batch_size]
            worker_id = f"combined_trades_{i // batch_size}"

            with self._lock:
                if worker_id in self._workers:
                    continue

            worker = CombinedStreamWorker(
                worker_id=worker_id,
                stream_type=StreamType.TRADE,
                symbols=batch,
                config=self._config,
                cache=self._cache,
            )
            self._register_and_start(worker_id, worker)
            worker_ids.append(worker_id)

        logger.info(
            "Registrados %d streams de trades en %d conexiones combinadas",
            len(symbols), len(worker_ids),
        )
        return worker_ids

    def add_order_book_streams(
        self,
        symbols: list[str],
        depth: int | None = None,
        batch_size: int = 200,
    ) -> list[str]:
        """Registra streams de order book para multiples simbolos en conexiones combinadas.

        Parameters
        ----------
        symbols : list[str]
            Lista de pares de trading.
        depth : int, opcional
            Profundidad del order book (default: config).
        batch_size : int
            Simbolos por conexion WebSocket (default: 200).

        Returns
        -------
        list[str]
            Identificadores de los workers combinados creados.
        """
        self._ensure_running()
        depth = depth or self._config.default_order_book_depth

        worker_ids = []
        for i in range(0, len(symbols), batch_size):
            batch = symbols[i:i + batch_size]
            worker_id = f"combined_depth_{i // batch_size}"

            with self._lock:
                if worker_id in self._workers:
                    continue

            worker = CombinedStreamWorker(
                worker_id=worker_id,
                stream_type=StreamType.DEPTH,
                symbols=batch,
                config=self._config,
                cache=self._cache,
                depth=depth,
            )
            self._register_and_start(worker_id, worker)
            worker_ids.append(worker_id)

        logger.info(
            "Registrados %d streams de order book en %d conexiones combinadas",
            len(symbols), len(worker_ids),
        )
        return worker_ids

    def remove_stream(self, stream_id: str) -> None:
        """Detiene y elimina un stream específico."""
        self._ensure_running()
        with self._lock:
            worker = self._workers.get(stream_id)
        if worker is None:
            return

        if self._loop is not None and not self._loop.is_closed():
            future = asyncio.run_coroutine_threadsafe(
                worker.stop(), self._loop
            )
            try:
                future.result(timeout=5.0)
            except Exception as exc:
                logger.warning("Error deteniendo stream %s: %s", stream_id, exc)

        with self._lock:
            self._workers.pop(stream_id, None)

    # ------------------------------------------------------------------
    # Acceso a datos de mercado
    # ------------------------------------------------------------------

    def get_last_trade(self, symbol: str) -> Trade | None:
        """Devuelve el último trade para un símbolo."""
        return self._cache.get_last_trade(symbol)

    def get_recent_trades(self, symbol: str, limit: int = 100) -> list[Trade]:
        """Devuelve los últimos N trades para un símbolo."""
        return self._cache.get_recent_trades(symbol, limit)

    def get_order_book(self, symbol: str) -> OrderBookSnapshot | None:
        """Devuelve el snapshot actual del order book."""
        return self._cache.get_order_book(symbol)

    # ------------------------------------------------------------------
    # Observabilidad
    # ------------------------------------------------------------------

    def get_stream_status(self, stream_id: str) -> StreamStatus | None:
        """Devuelve el estado de un stream específico."""
        with self._lock:
            worker = self._workers.get(stream_id)
        return worker.status if worker else None

    def get_all_streams_status(self) -> dict[str, StreamStatus]:
        """Devuelve el estado de todos los streams."""
        with self._lock:
            return {sid: w.status for sid, w in self._workers.items()}

    def get_health(self) -> SystemHealth:
        """Devuelve el diagnóstico de salud global del sistema."""
        statuses = self.get_all_streams_status()
        return self._health_monitor.evaluate_system(statuses, self._started_at)

    def get_stats(self) -> dict[str, Any]:
        """Devuelve estadísticas resumidas del sistema."""
        health = self.get_health()
        return {
            "running": self._running,
            "uptime_s": round(health.uptime_s, 1),
            "total_streams": health.total_streams,
            "running_streams": health.running_streams,
            "stale_streams": health.stale_streams,
            "total_messages": health.total_messages,
            "symbols": self._cache.get_symbols(),
            "is_healthy": health.is_healthy,
        }

    def is_healthy(self) -> bool:
        """Indica si el sistema global está sano."""
        return self.get_health().is_healthy

    def print_summary(self) -> None:
        """Imprime un resumen del estado del sistema por logging."""
        stats = self.get_stats()
        logger.info("=== Market Stream Summary ===")
        for key, value in stats.items():
            logger.info("  %s: %s", key, value)
        for sid, status in self.get_all_streams_status().items():
            evaluated = self._health_monitor.evaluate_stream(status)
            logger.info(
                "  [%s] state=%s msgs=%d reconnects=%d errors=%d",
                sid,
                evaluated.value,
                status.message_count,
                status.reconnect_count,
                status.error_count,
            )

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _run_loop(self) -> None:
        """Ejecuta el event loop asyncio en el thread dedicado."""
        assert self._loop is not None
        asyncio.set_event_loop(self._loop)
        try:
            self._loop.run_forever()
        finally:
            pending = asyncio.all_tasks(self._loop)
            for task in pending:
                task.cancel()
            if pending:
                self._loop.run_until_complete(
                    asyncio.wait(pending, timeout=5.0)
                )
            self._loop.run_until_complete(
                self._loop.shutdown_asyncgens()
            )
            self._loop.run_until_complete(
                self._loop.shutdown_default_executor()
            )

    async def _stop_all_workers(self) -> None:
        """Detiene todos los workers de forma concurrente."""
        with self._lock:
            workers = list(self._workers.values())
        if workers:
            await asyncio.gather(
                *(w.stop() for w in workers), return_exceptions=True
            )

    def _register_and_start(self, stream_id: str, worker: WebSocketStreamWorker) -> None:
        """Registra un worker y lo arranca en el event loop."""
        with self._lock:
            self._workers[stream_id] = worker
        if self._loop is not None:
            self._loop.call_soon_threadsafe(worker.start, self._loop)

    def _ensure_running(self) -> None:
        """Verifica que el manager esté en ejecución."""
        if not self._running or self._loop is None:
            raise ManagerNotRunningError(
                "El manager no está en ejecución. Llama a start() primero."
            )

    def _ensure_unique(self, stream_id: str) -> None:
        """Verifica que no exista un stream con el mismo ID."""
        with self._lock:
            if stream_id in self._workers:
                raise StreamAlreadyExistsError(
                    f"Ya existe un stream con ID '{stream_id}'"
                )
