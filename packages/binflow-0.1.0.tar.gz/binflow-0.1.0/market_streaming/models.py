"""Modelos de dominio para datos de mercado y estado de streams.

Se usan dataclasses en lugar de pydantic porque estos modelos son poblados
por código interno (parsing de JSON de Binance), no por input de usuario.
dataclasses con __slots__ son más ligeros y no añaden dependencias externas.
"""

from __future__ import annotations

import enum
import time
from dataclasses import dataclass, field


# ---------------------------------------------------------------------------
# Datos de mercado
# ---------------------------------------------------------------------------

@dataclass(slots=True, frozen=True)
class Trade:
    """Un trade individual de Binance.

    Normalizado para ser compatible con la REST API de Binance
    (GET /api/v3/trades y GET /fapi/v1/trades). Contiene tanto los valores
    numéricos (float) como las cadenas originales de precisión (str) para
    mantener la fidelidad con la fuente.

    Mapping REST -> modelo::

        id           -> trade_id
        price        -> price / price_str
        qty          -> quantity / quantity_str
        quoteQty     -> quote_quantity / quote_quantity_str
        time         -> timestamp_ms
        isBuyerMaker -> buyer_maker
        isBestMatch  -> is_best_match  (solo Spot)
    """

    symbol: str
    trade_id: int
    price: float
    quantity: float
    quote_quantity: float
    buyer_maker: bool
    timestamp_ms: int
    price_str: str = ""
    quantity_str: str = ""
    quote_quantity_str: str = ""
    is_best_match: bool = True
    event_time_ms: int = 0

    def to_rest_format(self) -> dict:
        """Devuelve un dict con los mismos campos que GET /api/v3/trades."""
        return {
            "id": self.trade_id,
            "price": self.price_str or f"{self.price:.8f}",
            "qty": self.quantity_str or f"{self.quantity:.8f}",
            "quoteQty": self.quote_quantity_str or f"{self.quote_quantity:.8f}",
            "time": self.timestamp_ms,
            "isBuyerMaker": self.buyer_maker,
            "isBestMatch": self.is_best_match,
        }


@dataclass(slots=True, frozen=True)
class OrderBookLevel:
    """Un nivel de precio en el order book.

    Mantiene tanto los valores numéricos como las cadenas originales
    para preservar la precisión decimal de Binance.
    """

    price: float
    quantity: float
    price_str: str = ""
    quantity_str: str = ""

    def to_rest_format(self) -> list[str]:
        """Devuelve [price, qty] como cadenas, igual que la REST API."""
        return [
            self.price_str or f"{self.price:.8f}",
            self.quantity_str or f"{self.quantity:.8f}",
        ]


@dataclass(slots=True)
class OrderBookSnapshot:
    """Snapshot actual del order book para un símbolo.

    Normalizado para ser compatible con la REST API de Binance
    (GET /api/v3/depth y GET /fapi/v1/depth).
    """

    symbol: str
    bids: list[OrderBookLevel] = field(default_factory=list)
    asks: list[OrderBookLevel] = field(default_factory=list)
    last_update_id: int = 0
    timestamp: float = field(default_factory=time.time)
    event_time_ms: int = 0
    transaction_time_ms: int = 0

    def to_rest_format(self) -> dict:
        """Devuelve un dict con los mismos campos que GET /api/v3/depth."""
        return {
            "lastUpdateId": self.last_update_id,
            "bids": [level.to_rest_format() for level in self.bids],
            "asks": [level.to_rest_format() for level in self.asks],
        }


# ---------------------------------------------------------------------------
# Estado de streams
# ---------------------------------------------------------------------------

class StreamState(str, enum.Enum):
    """Estados posibles de un stream."""

    STARTING = "starting"
    RUNNING = "running"
    RECONNECTING = "reconnecting"
    STALE = "stale"
    STOPPED = "stopped"
    FAILED = "failed"


class StreamType(str, enum.Enum):
    """Tipos de stream soportados."""

    TRADE = "trade"
    DEPTH = "depth"


@dataclass(slots=True)
class StreamStatus:
    """Estado operativo de un stream individual."""

    stream_id: str
    stream_type: StreamType
    symbol: str
    state: StreamState = StreamState.STARTING
    connected_at: float | None = None
    last_message_at: float | None = None
    reconnect_count: int = 0
    message_count: int = 0
    error_count: int = 0


@dataclass(slots=True)
class SystemHealth:
    """Salud global del sistema de streaming."""

    is_healthy: bool
    total_streams: int
    running_streams: int
    stale_streams: int
    reconnecting_streams: int
    stopped_streams: int
    uptime_s: float
    total_messages: int
    stream_details: dict[str, StreamStatus] = field(default_factory=dict)
