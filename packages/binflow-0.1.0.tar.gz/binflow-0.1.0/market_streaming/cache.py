"""Cache en memoria thread-safe para datos de mercado.

El cache es el repositorio central de estado de mercado. Escrito desde el
thread asyncio (workers) y leído desde el thread principal (API pública).
Se protege con threading.Lock - las operaciones son O(1) por lo que el
contention es despreciable.
"""

from __future__ import annotations

import threading
import time
from collections import deque
from dataclasses import dataclass, field

from .config import StreamConfig
from .models import OrderBookLevel, OrderBookSnapshot, Trade


@dataclass
class _SymbolTradeData:
    """Datos de trades para un símbolo."""

    last: Trade | None = None
    recent: deque[Trade] = field(default_factory=deque)


class MarketDataCache:
    """Cache en memoria para trades y order books.

    Thread-safe mediante un Lock global. Las lecturas y escrituras son
    operaciones rápidas (O(1) amortizado) por lo que el Lock no es un
    cuello de botella en la práctica.
    """

    def __init__(self, config: StreamConfig) -> None:
        self._config = config
        self._lock = threading.Lock()
        self._trades: dict[str, _SymbolTradeData] = {}
        self._order_books: dict[str, OrderBookSnapshot] = {}

    # ------------------------------------------------------------------
    # Escritura (llamado desde workers asyncio)
    # ------------------------------------------------------------------

    def update_trade(self, trade: Trade) -> None:
        """Registra un nuevo trade en el cache."""
        symbol = trade.symbol.upper()
        with self._lock:
            data = self._trades.get(symbol)
            if data is None:
                data = _SymbolTradeData(
                    recent=deque(maxlen=self._config.max_recent_trades)
                )
                self._trades[symbol] = data
            data.last = trade
            data.recent.append(trade)

    def update_order_book(self, snapshot: OrderBookSnapshot) -> None:
        """Reemplaza el snapshot del order book para un símbolo."""
        symbol = snapshot.symbol.upper()
        with self._lock:
            self._order_books[symbol] = snapshot

    def apply_depth_update(
        self,
        symbol: str,
        bids: list[OrderBookLevel],
        asks: list[OrderBookLevel],
        last_update_id: int,
        *,
        event_time_ms: int = 0,
        transaction_time_ms: int = 0,
    ) -> None:
        """Aplica una actualización incremental al order book.

        Si no existe snapshot previo, crea uno nuevo. Si el update_id no es
        posterior al actual, lo ignora (protección contra duplicados).
        Preserva las cadenas originales de precisión en cada nivel.
        """
        symbol = symbol.upper()
        with self._lock:
            book = self._order_books.get(symbol)
            if book is None:
                book = OrderBookSnapshot(symbol=symbol)
                self._order_books[symbol] = book

            if last_update_id <= book.last_update_id:
                return

            # Mapas con (quantity, price_str, qty_str) para preservar strings
            bid_map: dict[float, OrderBookLevel] = {
                level.price: level for level in book.bids
            }
            for level in bids:
                if level.quantity == 0.0:
                    bid_map.pop(level.price, None)
                else:
                    bid_map[level.price] = level

            ask_map: dict[float, OrderBookLevel] = {
                level.price: level for level in book.asks
            }
            for level in asks:
                if level.quantity == 0.0:
                    ask_map.pop(level.price, None)
                else:
                    ask_map[level.price] = level

            max_depth = self._config.default_order_book_depth
            book.bids = [
                v for _, v in sorted(bid_map.items(), reverse=True)[:max_depth]
            ]
            book.asks = [
                v for _, v in sorted(ask_map.items())[:max_depth]
            ]
            book.last_update_id = last_update_id
            book.timestamp = time.time()
            book.event_time_ms = event_time_ms
            book.transaction_time_ms = transaction_time_ms

    # ------------------------------------------------------------------
    # Lectura (llamado desde el thread principal)
    # ------------------------------------------------------------------

    def get_last_trade(self, symbol: str) -> Trade | None:
        """Devuelve el último trade para un símbolo, o None."""
        symbol = symbol.upper()
        with self._lock:
            data = self._trades.get(symbol)
            return data.last if data else None

    def get_recent_trades(self, symbol: str, limit: int = 100) -> list[Trade]:
        """Devuelve los últimos N trades para un símbolo."""
        symbol = symbol.upper()
        with self._lock:
            data = self._trades.get(symbol)
            if data is None:
                return []
            trades = list(data.recent)
            return trades[-limit:]

    def get_order_book(self, symbol: str) -> OrderBookSnapshot | None:
        """Devuelve el snapshot actual del order book, o None."""
        symbol = symbol.upper()
        with self._lock:
            book = self._order_books.get(symbol)
            if book is None:
                return None
            # Devolver copia para evitar mutación externa
            return OrderBookSnapshot(
                symbol=book.symbol,
                bids=list(book.bids),
                asks=list(book.asks),
                last_update_id=book.last_update_id,
                timestamp=book.timestamp,
                event_time_ms=book.event_time_ms,
                transaction_time_ms=book.transaction_time_ms,
            )

    def get_symbols(self) -> list[str]:
        """Devuelve la lista de símbolos conocidos."""
        with self._lock:
            return list(
                set(list(self._trades.keys()) + list(self._order_books.keys()))
            )

    def clear(self) -> None:
        """Limpia todo el cache."""
        with self._lock:
            self._trades.clear()
            self._order_books.clear()
