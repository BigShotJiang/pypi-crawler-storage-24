"""Worker asyncio que gestiona una conexión WebSocket a Binance.

Cada worker gestiona un stream lógico (trade o depth para un símbolo).
Se encarga de: conectar, suscribir, recibir, parsear, alimentar el cache,
detectar errores y reconectar con backoff exponencial.
"""

from __future__ import annotations

import asyncio
import json
import logging
import random
import time
from typing import TYPE_CHECKING

import websockets
from websockets.asyncio.client import ClientConnection

from .exceptions import FatalStreamError
from .models import (
    OrderBookLevel,
    OrderBookSnapshot,
    StreamState,
    StreamStatus,
    StreamType,
    Trade,
)

if TYPE_CHECKING:
    from .cache import MarketDataCache
    from .config import StreamConfig

logger = logging.getLogger(__name__)

# Profundidades validas para el Partial Book Depth Stream de Binance.
# Cualquier otro valor usa el Diff Depth Stream (actualizaciones incrementales).
_PARTIAL_DEPTH_LEVELS = {5, 10, 20}


def _depth_stream_name(symbol: str, depth: int) -> str:
    """Devuelve el nombre de stream de depth correcto segun la profundidad."""
    if depth in _PARTIAL_DEPTH_LEVELS:
        return f"{symbol}@depth{depth}"
    return f"{symbol}@depth"


class WebSocketStreamWorker:
    """Worker que mantiene una conexión WebSocket a un stream de Binance.

    Diseñado para ejecutarse como tarea asyncio de larga duración. Gestiona
    su propio ciclo de reconexión y actualiza el cache de forma autónoma.
    """

    def __init__(
        self,
        stream_id: str,
        stream_type: StreamType,
        symbol: str,
        config: StreamConfig,
        cache: MarketDataCache,
        depth: int = 20,
    ) -> None:
        self._stream_id = stream_id
        self._stream_type = stream_type
        self._symbol = symbol.lower()
        self._symbol_upper = symbol.upper()
        self._config = config
        self._cache = cache
        self._depth = depth
        self._ws: ClientConnection | None = None
        self._task: asyncio.Task | None = None  # type: ignore[type-arg]
        self._stop_event = asyncio.Event()

        self.status = StreamStatus(
            stream_id=stream_id,
            stream_type=stream_type,
            symbol=self._symbol_upper,
        )

    @property
    def stream_id(self) -> str:
        return self._stream_id

    # ------------------------------------------------------------------
    # Ciclo de vida
    # ------------------------------------------------------------------

    def start(self, loop: asyncio.AbstractEventLoop) -> None:
        """Lanza la tarea del worker en el event loop dado."""
        self._task = loop.create_task(self._run(), name=f"worker-{self._stream_id}")

    async def stop(self) -> None:
        """Detiene el worker de forma limpia."""
        self._stop_event.set()
        ws = self._ws
        if ws is not None:
            self._ws = None
            try:
                await ws.close()
            except Exception:
                pass
        if self._task is not None and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except (asyncio.CancelledError, Exception):
                pass
        self.status.state = StreamState.STOPPED
        logger.info("Stream %s detenido", self._stream_id)

    # ------------------------------------------------------------------
    # Bucle principal con reconexión
    # ------------------------------------------------------------------

    async def _run(self) -> None:
        """Bucle principal: conectar -> recibir -> reconectar."""
        attempt = 0
        while not self._stop_event.is_set():
            try:
                await self._connect_and_consume()
                # Conexión cerrada limpiamente (raro en streams perpetuos)
                if self._stop_event.is_set():
                    break
            except FatalStreamError as exc:
                logger.error(
                    "Error fatal en stream %s: %s", self._stream_id, exc
                )
                self.status.state = StreamState.FAILED
                self.status.error_count += 1
                break
            except asyncio.CancelledError:
                break
            except Exception as exc:
                self.status.error_count += 1
                logger.warning(
                    "Error en stream %s (intento %d): %s",
                    self._stream_id,
                    attempt,
                    exc,
                )

            if self._stop_event.is_set():
                break

            # Backoff exponencial con jitter
            attempt += 1
            max_attempts = self._config.max_reconnect_attempts
            if max_attempts > 0 and attempt > max_attempts:
                logger.error(
                    "Stream %s: máximo de reconexiones alcanzado (%d)",
                    self._stream_id,
                    max_attempts,
                )
                self.status.state = StreamState.FAILED
                break

            delay = self._calculate_backoff(attempt)
            self.status.state = StreamState.RECONNECTING
            self.status.reconnect_count += 1
            logger.info(
                "Stream %s: reconectando en %.1fs (intento %d)",
                self._stream_id,
                delay,
                attempt,
            )

            try:
                await asyncio.wait_for(
                    self._stop_event.wait(), timeout=delay
                )
                break  # stop_event se activó durante el wait
            except asyncio.TimeoutError:
                pass  # Timeout esperado, proceder a reconectar

        self.status.state = StreamState.STOPPED

    def _calculate_backoff(self, attempt: int) -> float:
        """Calcula el delay de reconexión con backoff exponencial y jitter."""
        base = self._config.reconnect_base_delay_s
        max_delay = self._config.reconnect_max_delay_s
        delay = min(base * (2 ** (attempt - 1)), max_delay)
        jitter = delay * self._config.reconnect_jitter_factor
        return delay + random.uniform(-jitter, jitter)

    # ------------------------------------------------------------------
    # Conexión y consumo
    # ------------------------------------------------------------------

    async def _connect_and_consume(self) -> None:
        """Abre conexión, suscribe y consume mensajes."""
        url = self._build_url()
        logger.info("Stream %s: conectando a %s", self._stream_id, url)

        try:
            async with websockets.connect(
                url,
                ping_interval=self._config.ping_interval_s,
                ping_timeout=self._config.ping_timeout_s,
                close_timeout=5,
            ) as ws:
                self._ws = ws
                self.status.state = StreamState.RUNNING
                self.status.connected_at = time.time()
                logger.info("Stream %s: conexión establecida", self._stream_id)

                async for raw_message in ws:
                    if self._stop_event.is_set():
                        break
                    self._process_message(raw_message)
        finally:
            self._ws = None

    def _build_url(self) -> str:
        """Construye la URL del stream según el tipo."""
        if self._stream_type == StreamType.TRADE:
            stream_name = f"{self._symbol}@trade"
        elif self._stream_type == StreamType.DEPTH:
            stream_name = _depth_stream_name(self._symbol, self._depth)
        else:
            raise FatalStreamError(f"Tipo de stream desconocido: {self._stream_type}")
        return f"{self._config.base_url}/{stream_name}"

    # ------------------------------------------------------------------
    # Procesamiento de mensajes
    # ------------------------------------------------------------------

    def _process_message(self, raw: str | bytes) -> None:
        """Parsea y despacha un mensaje del WebSocket."""
        now = time.time()
        self.status.last_message_at = now
        self.status.message_count += 1

        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            logger.warning("Stream %s: mensaje JSON inválido", self._stream_id)
            self.status.error_count += 1
            return

        event_type = data.get("e")

        if event_type == "trade":
            self._handle_trade(data)
        elif event_type == "depthUpdate":
            self._handle_depth_update(data)
        elif "lastUpdateId" in data:
            # Respuesta de snapshot parcial del depth stream
            self._handle_depth_snapshot(data)

    def _handle_trade(self, data: dict) -> None:
        """Procesa un evento de trade.

        Normaliza los campos del WebSocket para que coincidan con
        GET /api/v3/trades, incluyendo quoteQty y isBestMatch.
        """
        price_str = data["p"]
        qty_str = data["q"]
        price = float(price_str)
        quantity = float(qty_str)
        quote_quantity = price * quantity

        trade = Trade(
            symbol=self._symbol_upper,
            trade_id=data["t"],
            price=price,
            quantity=quantity,
            quote_quantity=quote_quantity,
            buyer_maker=data["m"],
            timestamp_ms=data["T"],
            price_str=price_str,
            quantity_str=qty_str,
            quote_quantity_str=f"{quote_quantity:.8f}",
            is_best_match=data.get("M", True),
            event_time_ms=data.get("E", 0),
        )
        self._cache.update_trade(trade)

    @staticmethod
    def _parse_book_levels(raw_levels: list) -> list[OrderBookLevel]:
        """Parsea niveles del order book preservando cadenas originales."""
        return [
            OrderBookLevel(
                price=float(p),
                quantity=float(q),
                price_str=p,
                quantity_str=q,
            )
            for p, q in raw_levels
        ]

    def _handle_depth_update(self, data: dict) -> None:
        """Procesa una actualización incremental del order book."""
        bids = self._parse_book_levels(data.get("b", []))
        asks = self._parse_book_levels(data.get("a", []))
        last_update_id = data.get("u", 0)
        event_time_ms = data.get("E", 0)
        transaction_time_ms = data.get("T", 0)
        self._cache.apply_depth_update(
            self._symbol_upper, bids, asks, last_update_id,
            event_time_ms=event_time_ms,
            transaction_time_ms=transaction_time_ms,
        )

    def _handle_depth_snapshot(self, data: dict) -> None:
        """Procesa un snapshot completo del order book."""
        max_depth = self._depth
        bids = self._parse_book_levels(data.get("bids", [])[:max_depth])
        asks = self._parse_book_levels(data.get("asks", [])[:max_depth])
        snapshot = OrderBookSnapshot(
            symbol=self._symbol_upper,
            bids=bids,
            asks=asks,
            last_update_id=data.get("lastUpdateId", 0),
            timestamp=time.time(),
            event_time_ms=data.get("E", 0),
            transaction_time_ms=data.get("T", 0),
        )
        self._cache.update_order_book(snapshot)


class CombinedStreamWorker:
    """Worker que multiplexa varios streams en una sola conexion WebSocket.

    Usa el endpoint de combined streams de Binance para gestionar hasta
    MAX_STREAMS simbolos en una sola conexion TCP, eliminando el cuello
    de botella de conexiones individuales.

    El formato de mensajes combinados envuelve cada evento::

        {"stream": "btcusdt@trade", "data": {...evento original...}}
    """

    MAX_STREAMS = 200

    def __init__(
        self,
        worker_id: str,
        stream_type: StreamType,
        symbols: list[str],
        config: StreamConfig,
        cache: MarketDataCache,
        depth: int = 20,
    ) -> None:
        self._worker_id = worker_id
        self._stream_type = stream_type
        self._symbols = [s.lower() for s in symbols]
        self._config = config
        self._cache = cache
        self._depth = depth
        self._ws: ClientConnection | None = None
        self._task: asyncio.Task | None = None
        self._stop_event = asyncio.Event()

        self.status = StreamStatus(
            stream_id=worker_id,
            stream_type=stream_type,
            symbol=f"COMBINED({len(symbols)})",
        )

    @property
    def stream_id(self) -> str:
        return self._worker_id

    # ------------------------------------------------------------------
    # Ciclo de vida
    # ------------------------------------------------------------------

    def start(self, loop: asyncio.AbstractEventLoop) -> None:
        """Lanza la tarea del worker en el event loop dado."""
        self._task = loop.create_task(
            self._run(), name=f"worker-{self._worker_id}"
        )

    async def stop(self) -> None:
        """Detiene el worker de forma limpia."""
        self._stop_event.set()
        ws = self._ws
        if ws is not None:
            self._ws = None
            try:
                await ws.close()
            except Exception:
                pass
        if self._task is not None and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except (asyncio.CancelledError, Exception):
                pass
        self.status.state = StreamState.STOPPED
        logger.info("Combined stream %s detenido", self._worker_id)

    # ------------------------------------------------------------------
    # Bucle principal con reconexion
    # ------------------------------------------------------------------

    async def _run(self) -> None:
        """Bucle principal: conectar -> recibir -> reconectar."""
        attempt = 0
        while not self._stop_event.is_set():
            try:
                await self._connect_and_consume()
                if self._stop_event.is_set():
                    break
            except FatalStreamError as exc:
                logger.error(
                    "Error fatal en combined stream %s: %s",
                    self._worker_id, exc,
                )
                self.status.state = StreamState.FAILED
                self.status.error_count += 1
                break
            except asyncio.CancelledError:
                break
            except Exception as exc:
                self.status.error_count += 1
                logger.warning(
                    "Error en combined stream %s (intento %d): %s",
                    self._worker_id, attempt, exc,
                )

            if self._stop_event.is_set():
                break

            attempt += 1
            max_attempts = self._config.max_reconnect_attempts
            if max_attempts > 0 and attempt > max_attempts:
                logger.error(
                    "Combined stream %s: maximo de reconexiones (%d)",
                    self._worker_id, max_attempts,
                )
                self.status.state = StreamState.FAILED
                break

            delay = self._calculate_backoff(attempt)
            self.status.state = StreamState.RECONNECTING
            self.status.reconnect_count += 1
            logger.info(
                "Combined stream %s: reconectando en %.1fs (intento %d)",
                self._worker_id, delay, attempt,
            )

            try:
                await asyncio.wait_for(
                    self._stop_event.wait(), timeout=delay
                )
                break
            except asyncio.TimeoutError:
                pass

        self.status.state = StreamState.STOPPED

    def _calculate_backoff(self, attempt: int) -> float:
        """Calcula el delay de reconexion con backoff exponencial y jitter."""
        base = self._config.reconnect_base_delay_s
        max_delay = self._config.reconnect_max_delay_s
        delay = min(base * (2 ** (attempt - 1)), max_delay)
        jitter = delay * self._config.reconnect_jitter_factor
        return delay + random.uniform(-jitter, jitter)

    # ------------------------------------------------------------------
    # Conexion y consumo
    # ------------------------------------------------------------------

    async def _connect_and_consume(self) -> None:
        """Abre conexion combinada y consume mensajes."""
        url = self._build_url()
        logger.info(
            "Combined stream %s: conectando (%d streams)",
            self._worker_id, len(self._symbols),
        )

        try:
            async with websockets.connect(
                url,
                ping_interval=self._config.ping_interval_s,
                ping_timeout=self._config.ping_timeout_s,
                close_timeout=5,
            ) as ws:
                self._ws = ws
                self.status.state = StreamState.RUNNING
                self.status.connected_at = time.time()
                logger.info(
                    "Combined stream %s: conexion establecida",
                    self._worker_id,
                )

                async for raw_message in ws:
                    if self._stop_event.is_set():
                        break
                    self._process_message(raw_message)
        finally:
            self._ws = None

    def _build_url(self) -> str:
        """Construye la URL de combined streams."""
        if self._stream_type == StreamType.TRADE:
            stream_names = [f"{s}@trade" for s in self._symbols]
        elif self._stream_type == StreamType.DEPTH:
            stream_names = [
                _depth_stream_name(s, self._depth) for s in self._symbols
            ]
        else:
            raise FatalStreamError(
                f"Tipo de stream desconocido: {self._stream_type}"
            )

        streams_path = "/".join(stream_names)
        base = self._config.base_url
        if base.endswith("/ws"):
            base = base[:-3]
        return f"{base}/stream?streams={streams_path}"

    # ------------------------------------------------------------------
    # Procesamiento de mensajes
    # ------------------------------------------------------------------

    def _process_message(self, raw: str | bytes) -> None:
        """Parsea y despacha un mensaje del combined stream."""
        now = time.time()
        self.status.last_message_at = now
        self.status.message_count += 1

        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            logger.warning(
                "Combined stream %s: mensaje JSON invalido",
                self._worker_id,
            )
            self.status.error_count += 1
            return

        # Combined streams envuelven en {stream, data}
        if "stream" in data and "data" in data:
            stream_name = data["stream"]
            inner = data["data"]
            event_type = inner.get("e")

            if event_type == "trade":
                self._handle_trade(inner)
            elif event_type == "depthUpdate":
                self._handle_depth_update(inner)
            elif "lastUpdateId" in inner:
                # Partial book depth no incluye "s", extraer del stream name
                symbol = stream_name.split("@")[0].upper()
                self._handle_depth_snapshot(inner, symbol)

    def _handle_trade(self, data: dict) -> None:
        """Procesa un evento de trade del combined stream."""
        symbol_upper = data["s"]
        price_str = data["p"]
        qty_str = data["q"]
        price = float(price_str)
        quantity = float(qty_str)
        quote_quantity = price * quantity

        trade = Trade(
            symbol=symbol_upper,
            trade_id=data["t"],
            price=price,
            quantity=quantity,
            quote_quantity=quote_quantity,
            buyer_maker=data["m"],
            timestamp_ms=data["T"],
            price_str=price_str,
            quantity_str=qty_str,
            quote_quantity_str=f"{quote_quantity:.8f}",
            is_best_match=data.get("M", True),
            event_time_ms=data.get("E", 0),
        )
        self._cache.update_trade(trade)

    @staticmethod
    def _parse_book_levels(raw_levels: list) -> list[OrderBookLevel]:
        """Parsea niveles del order book preservando cadenas originales."""
        return [
            OrderBookLevel(
                price=float(p),
                quantity=float(q),
                price_str=p,
                quantity_str=q,
            )
            for p, q in raw_levels
        ]

    def _handle_depth_update(self, data: dict) -> None:
        """Procesa una actualizacion incremental del order book."""
        symbol_upper = data["s"]
        bids = self._parse_book_levels(data.get("b", []))
        asks = self._parse_book_levels(data.get("a", []))
        last_update_id = data.get("u", 0)
        event_time_ms = data.get("E", 0)
        transaction_time_ms = data.get("T", 0)
        self._cache.apply_depth_update(
            symbol_upper, bids, asks, last_update_id,
            event_time_ms=event_time_ms,
            transaction_time_ms=transaction_time_ms,
        )

    def _handle_depth_snapshot(
        self, data: dict, symbol: str | None = None,
    ) -> None:
        """Procesa un snapshot completo del order book."""
        symbol_upper = symbol or data.get("s", "UNKNOWN")
        max_depth = self._depth
        bids = self._parse_book_levels(data.get("bids", [])[:max_depth])
        asks = self._parse_book_levels(data.get("asks", [])[:max_depth])
        snapshot = OrderBookSnapshot(
            symbol=symbol_upper,
            bids=bids,
            asks=asks,
            last_update_id=data.get("lastUpdateId", 0),
            timestamp=time.time(),
            event_time_ms=data.get("E", 0),
            transaction_time_ms=data.get("T", 0),
        )
        self._cache.update_order_book(snapshot)
