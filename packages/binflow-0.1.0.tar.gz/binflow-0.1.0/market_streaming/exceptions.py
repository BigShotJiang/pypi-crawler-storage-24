"""Excepciones del dominio de market streaming."""

from __future__ import annotations


class MarketStreamError(Exception):
    """Excepción base del módulo."""


class StreamAlreadyExistsError(MarketStreamError):
    """Se intentó registrar un stream que ya existe."""


class StreamNotFoundError(MarketStreamError):
    """Se intentó acceder a un stream que no existe."""


class ManagerNotRunningError(MarketStreamError):
    """Se intentó operar con el manager cuando no está en ejecución."""


class FatalStreamError(MarketStreamError):
    """Error no recuperable en un stream (no reconectar)."""
