"""Data files for lucidshark."""
