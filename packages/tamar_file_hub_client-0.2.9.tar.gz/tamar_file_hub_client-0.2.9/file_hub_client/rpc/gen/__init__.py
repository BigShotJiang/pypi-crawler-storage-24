"""gRPC generated modules package."""

import sys

from . import file_service_pb2 as _file_service_pb2
from . import folder_service_pb2 as _folder_service_pb2
from . import taple_service_pb2 as _taple_service_pb2

# grpc_tools >= 1.67 may generate absolute imports like `import file_service_pb2`.
# Register aliases so generated stubs work when imported as a package module.
sys.modules.setdefault("file_service_pb2", _file_service_pb2)
sys.modules.setdefault("folder_service_pb2", _folder_service_pb2)
sys.modules.setdefault("taple_service_pb2", _taple_service_pb2)

__all__ = [
    "file_service_pb2",
    "file_service_pb2_grpc",
    "folder_service_pb2",
    "folder_service_pb2_grpc",
    "taple_service_pb2",
    "taple_service_pb2_grpc",
]
