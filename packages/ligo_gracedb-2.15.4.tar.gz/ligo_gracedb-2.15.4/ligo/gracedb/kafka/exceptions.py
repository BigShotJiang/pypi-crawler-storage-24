# -*- coding: utf-8 -*-
# Copyright (C) Alexander Pace, Daniel Wysocki (2026)
#
# This file is part of gracedb
#
# gracedb is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# It is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with gracedb.  If not, see <http://www.gnu.org/licenses/>.
"""
Exceptions for Kafka integration.
"""


class KafkaError(Exception):
    """Base exception for Kafka-related errors."""
    pass


class KafkaAuthenticationError(KafkaError):
    """Exception raised when Kafka authentication fails."""
    pass


class KafkaTokenError(KafkaAuthenticationError):
    """Exception raised when SciToken cannot be obtained or is invalid."""
    pass


class KafkaProducerError(KafkaError):
    """Exception raised when Kafka producer encounters an error."""
    pass


class KafkaConsumerError(KafkaError):
    """Exception raised when Kafka consumer encounters an error."""
    pass


class KafkaConnectionError(KafkaError):
    """Exception raised when connection to Kafka broker fails."""
    pass


class KafkaMessageDeliveryError(KafkaProducerError):
    """Exception raised when message delivery to Kafka fails."""
    pass
