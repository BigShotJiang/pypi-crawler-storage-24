# -*- coding: utf-8 -*-
# Copyright (C) Alexander Pace, Daniel Wysocki (2026)
#
# This file is part of gracedb
#
# gracedb is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# It is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with gracedb.  If not, see <http://www.gnu.org/licenses/>.
"""
Kafka integration for GraceDB with SciToken authentication.

This package provides Kafka producer functionality for publishing
GraceDB events to Kafka brokers using SciToken (JWT) authentication.
"""

from .producer import GraceDbKafkaProducer
from .consumer import GraceDbKafkaConsumer
from .exceptions import (
    KafkaError,
    KafkaAuthenticationError,
    KafkaTokenError,
    KafkaProducerError,
    KafkaConsumerError,
    KafkaConnectionError,
    KafkaMessageDeliveryError,
)
from .utils import derive_instance_name, make_topic_name, parse_topic_name

__all__ = [
    "GraceDbKafkaProducer",
    "GraceDbKafkaConsumer",
    "KafkaError",
    "KafkaAuthenticationError",
    "KafkaTokenError",
    "KafkaProducerError",
    "KafkaConsumerError",
    "KafkaConnectionError",
    "KafkaMessageDeliveryError",
    "derive_instance_name",
    "make_topic_name",
    "parse_topic_name",
]
