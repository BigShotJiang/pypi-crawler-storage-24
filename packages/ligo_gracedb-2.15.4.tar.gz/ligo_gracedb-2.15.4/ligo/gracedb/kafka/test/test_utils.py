# -*- coding: utf-8 -*-
# Copyright (C) Alexander Pace, Daniel Wysocki (2026)
#
# This file is part of gracedb
#
# gracedb is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# It is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with gracedb.  If not, see <http://www.gnu.org/licenses/>.
"""Tests for Kafka topic utility functions."""

import pytest

from ligo.gracedb.kafka.utils import (
    derive_instance_name,
    make_topic_name,
    parse_topic_name,
)


class TestDeriveInstanceName:
    """Test derive_instance_name()."""

    def test_subdomain_with_path(self):
        assert derive_instance_name("https://gracedb-dev.ligo.org/api/") == "gracedb-dev"

    def test_top_level_subdomain(self):
        assert derive_instance_name("https://gracedb.ligo.org/api/") == "gracedb"

    def test_localhost_with_port(self):
        assert derive_instance_name("https://localhost:8080/api/") == "localhost"

    def test_localhost_no_port(self):
        assert derive_instance_name("http://localhost/api/") == "localhost"

    def test_ip_address(self):
        assert derive_instance_name("https://192.168.1.1:9092/") == "192"

    def test_no_scheme(self):
        """URL without scheme cannot be parsed."""
        with pytest.raises(ValueError, match="Cannot parse hostname"):
            derive_instance_name("gracedb-dev.ligo.org/api/")

    def test_empty_string(self):
        with pytest.raises(ValueError, match="Cannot parse hostname"):
            derive_instance_name("")

    def test_deep_subdomain(self):
        assert derive_instance_name("https://a.b.c.d.e/") == "a"

    def test_gracedb_test(self):
        assert derive_instance_name("https://gracedb-test.ligo.org/api/") == "gracedb-test"

    def test_gracedb_playground(self):
        assert derive_instance_name("https://gracedb-playground.ligo.org/api/") == "gracedb-playground"


class TestMakeTopicName:
    """Test make_topic_name()."""

    def test_basic(self):
        assert make_topic_name("gracedb-dev", "gstlal") == "gracedb-dev.gstlal"

    def test_prod_instance(self):
        assert make_topic_name("gracedb", "cwb") == "gracedb.cwb"

    def test_test_topic(self):
        assert make_topic_name("gracedb-test", "test") == "gracedb-test.test"


class TestParseTopicName:
    """Test parse_topic_name()."""

    def test_basic(self):
        assert parse_topic_name("gracedb-dev.gstlal") == ("gracedb-dev", "gstlal")

    def test_prod(self):
        assert parse_topic_name("gracedb.cwb") == ("gracedb", "cwb")

    def test_no_dot_raises(self):
        with pytest.raises(ValueError, match="not namespaced"):
            parse_topic_name("gstlal")

    def test_multiple_dots(self):
        """Only splits on the first dot."""
        assert parse_topic_name("gracedb-dev.a.b") == ("gracedb-dev", "a.b")

    def test_empty_string_raises(self):
        with pytest.raises(ValueError, match="not namespaced"):
            parse_topic_name("")
