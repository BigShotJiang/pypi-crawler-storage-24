"""Interactive model management CLI commands."""

import tomllib
from pathlib import Path
from typing import Optional, Dict, Any, List

from rich.console import Console
from rich.table import Table
from rich import prompt
from rich.prompt import Prompt, Confirm, FloatPrompt, IntPrompt

import tomlkit
from asky.config import MODELS, load_config
from . import openrouter

console = Console()

SHORTLIST_MODE_AUTO = "auto"
SHORTLIST_MODE_ON = "on"
SHORTLIST_MODE_OFF = "off"
IMAGE_SUPPORT_MODE_AUTO = "auto"
IMAGE_SUPPORT_MODE_ON = "on"
IMAGE_SUPPORT_MODE_OFF = "off"


def list_model_aliases() -> List[str]:
    """Return available model aliases in a stable order."""
    return sorted(MODELS.keys())


def update_general_config(key: str, value: str):
    """Update general.toml configuration using tomlkit."""
    config_path = Path.home() / ".config" / "asky" / "general.toml"

    if not config_path.exists():
        console.print(
            f"[yellow]Warning: {config_path} does not exist. Skipping update for {key}.[/yellow]"
        )
        return

    try:
        content = config_path.read_text()
        doc = tomlkit.parse(content)

        if "general" not in doc:
            doc.add("general", tomlkit.table())

        doc["general"][key] = value

        config_path.write_text(doc.as_string())
        console.print(f"[green]Updated {key} to '{value}' in general.toml[/green]")

    except Exception as e:
        console.print(f"[red]Failed to update general.toml: {e}[/red]")


def _shortlist_mode_from_value(value: Optional[bool]) -> str:
    """Map model shortlist setting to CLI choice token."""
    if value is True:
        return SHORTLIST_MODE_ON
    if value is False:
        return SHORTLIST_MODE_OFF
    return SHORTLIST_MODE_AUTO


def _shortlist_value_from_mode(mode: str) -> Optional[bool]:
    """Map CLI choice token back to stored shortlist setting."""
    if mode == SHORTLIST_MODE_ON:
        return True
    if mode == SHORTLIST_MODE_OFF:
        return False
    return None


def _image_support_mode_from_value(value: Optional[bool]) -> str:
    """Map image support setting to CLI choice token."""
    if value is True:
        return IMAGE_SUPPORT_MODE_ON
    if value is False:
        return IMAGE_SUPPORT_MODE_OFF
    return IMAGE_SUPPORT_MODE_AUTO


def _image_support_value_from_mode(mode: str) -> Optional[bool]:
    """Map CLI choice token back to stored image support setting."""
    if mode == IMAGE_SUPPORT_MODE_ON:
        return True
    if mode == IMAGE_SUPPORT_MODE_OFF:
        return False
    return None


def add_model_command():
    """Interactively add a new model definition."""
    console.print("[bold]Add New Model Definition[/bold]\n")

    # Step 1: Select API provider
    config = load_config()
    apis = list(config.get("api", {}).keys())

    if not apis:
        console.print(
            "[red]No APIs configured. Please configure [api] sections in your config first.[/red]"
        )
        return

    console.print("[bold]Step 1: Select API Provider[/bold]")
    for i, api in enumerate(apis, 1):
        console.print(f"  {i}. {api}")

    api_choice = IntPrompt.ask("Select provider", default=1, show_default=True)
    if api_choice < 1 or api_choice > len(apis):
        console.print("[red]Invalid selection[/red]")
        return

    selected_api = apis[api_choice - 1]

    # Step 2: Model selection (search or enter full name)
    console.print("\n[bold]Step 2: Select Model[/bold]")

    # Fetch models if using OpenRouter
    models = []
    if selected_api == "openrouter":
        console.print("Fetching available models from OpenRouter...")
        try:
            models = openrouter.fetch_models()
            console.print(f"Found {len(models)} models")
        except Exception as e:
            console.print(f"[yellow]Warning: Could not fetch models: {e}[/yellow]")

    selected_model_data = {}
    model_id = ""
    context_size = 4096
    supported_params = []

    while True:
        if models:
            search_query = prompt.Prompt.ask(
                "Search for model (or enter full model ID)"
            )
            results = openrouter.search_models(search_query, models)

            if results:
                console.print(f"\nFound {len(results)} matches:")
                # Limit display to 20
                display_limit = 20
                for i, m in enumerate(results[:display_limit], 1):
                    name = m.get("name") or m.get("id")
                    console.print(f"  {i}. {m.get('id')} - {name}")

                if len(results) > display_limit:
                    console.print(f"  ... and {len(results) - display_limit} more")

                choice_default = 1
                choice = prompt.IntPrompt.ask(
                    "Select model (0 to enter custom ID)", default=choice_default
                )

                if choice > 0 and choice <= len(results):
                    selected_model_data = results[choice - 1]
                    model_id = selected_model_data.get("id")
                    context_size = selected_model_data.get("context_length", 4096)
                    supported_params = selected_model_data.get(
                        "supported_parameters", []
                    )
                    break
                elif choice == 0:
                    model_id = search_query
                    supported_params = list(openrouter.KNOWN_PARAMETERS.keys())
                    break
            else:
                console.print(
                    f"[yellow]No matches found for '{search_query}'.[/yellow]"
                )
                action = prompt.Prompt.ask(
                    "Action",
                    choices=["s", "c", "x"],
                    default="s",
                )
                # s: search again (continue loop)
                # c: enter custom ID (break loop after prompt)
                # x: cancel (return)
                if action == "c":
                    model_id = prompt.Prompt.ask("Enter custom model ID")
                    supported_params = list(openrouter.KNOWN_PARAMETERS.keys())
                    break
                elif action == "x":
                    console.print("[yellow]Cancelled[/yellow]")
                    return
                # if action == "s", loop continues
        else:
            # Fallback for empty models or other APIs
            model_id = Prompt.ask("Enter model ID")
            supported_params = list(openrouter.KNOWN_PARAMETERS.keys())
            break

    context_size = IntPrompt.ask("Context size", default=int(context_size or 4096))

    shortlist_mode = Prompt.ask(
        "Pre-LLM source shortlisting for this model",
        choices=[SHORTLIST_MODE_AUTO, SHORTLIST_MODE_ON, SHORTLIST_MODE_OFF],
        default=SHORTLIST_MODE_AUTO,
    )
    shortlist_enabled = _shortlist_value_from_mode(shortlist_mode)
    image_support_mode = Prompt.ask(
        "Image input support for this model",
        choices=[
            IMAGE_SUPPORT_MODE_AUTO,
            IMAGE_SUPPORT_MODE_ON,
            IMAGE_SUPPORT_MODE_OFF,
        ],
        default=IMAGE_SUPPORT_MODE_AUTO,
    )
    image_support = _image_support_value_from_mode(image_support_mode)

    # Step 3: Configure parameters
    console.print("\n[bold]Step 3: Configure Parameters[/bold]")
    console.print("Press Enter to skip (use default value)\n")

    parameters = {}

    # If using OpenRouter, we know which params are supported.
    # If not, we offer all known params.
    candidates = (
        supported_params
        if supported_params
        else list(openrouter.KNOWN_PARAMETERS.keys())
    )

    for param in candidates:
        if param not in openrouter.KNOWN_PARAMETERS:
            continue

        param_info = openrouter.KNOWN_PARAMETERS[param]
        default_val = param_info.get("default")
        param_type = param_info.get("type")

        hint = f"({param_type}"
        if "min" in param_info:
            hint += f", min={param_info['min']}"
        if "max" in param_info:
            hint += f", max={param_info['max']}"
        if default_val is not None:
            hint += f", default={default_val}"
        hint += ")"

        value = Prompt.ask(f"  {param} {hint}", default="", show_default=False)
        if value:
            try:
                if param_type == "float":
                    parameters[param] = float(value)
                elif param_type == "bool":
                    val_lower = value.lower()
                    if val_lower in ["true", "t", "yes", "y", "1"]:
                        parameters[param] = True
                    elif val_lower in ["false", "f", "no", "n", "0"]:
                        parameters[param] = False
                    else:
                        raise ValueError(f"Invalid boolean value: {value}")
            except ValueError:
                console.print(f"[yellow]Invalid value, skipping {param}[/yellow]")

    # Step 4: Nickname
    console.print("\n[bold]Step 4: Set Nickname[/bold]")
    default_nick = model_id.split("/")[-1]
    # Simple sanitization
    default_nick = default_nick.replace(".", "-").replace(":", "-")
    nickname = Prompt.ask("Enter nickname for CLI flag (-m)", default=default_nick)

    # Confirm and save
    console.print("\n[bold]Summary:[/bold]")
    console.print(f"  Nickname: {nickname}")
    console.print(f"  Model ID: {model_id}")
    console.print(f"  API: {selected_api}")
    console.print(f"  Context Size: {context_size}")
    console.print(f"  Source Shortlist: {shortlist_mode}")
    console.print(f"  Image Support: {image_support_mode}")
    if parameters:
        console.print(f"  Parameters: {parameters}")

    if Confirm.ask("\nSave this model?", default=True):
        save_model_config(
            nickname,
            {
                "id": model_id,
                "api": selected_api,
                "context_size": context_size,
                "source_shortlist_enabled": shortlist_enabled,
                "image_support": image_support,
                "parameters": parameters if parameters else None,
            },
        )
        console.print(f"\n[green]Model '{nickname}' saved successfully![/green]")
        console.print(
            f"You can now use this model with: [bold]asky -m {nickname}[/bold]"
        )
    else:
        console.print("[yellow]Cancelled[/yellow]")
        return

    # Offer to set as default/summarization
    if Confirm.ask("\nSet as default main model?", default=False):
        update_general_config("default_model", nickname)

    if Confirm.ask("Set as summarization model?", default=False):
        update_general_config("summarization_model", nickname)

    if Confirm.ask("Set as interface model?", default=False):
        update_general_config("interface_model", nickname)

    if Confirm.ask("Set as default image model?", default=False):
        update_general_config("default_image_model", nickname)


def edit_model_command(model_alias: Optional[str] = None):
    """Interactively edit an existing model definition."""
    # List existing models if no alias provided
    if not model_alias:
        # Load current defaults
        config = load_config()
        general = config.get("general", {})
        def_model = general.get("default_model")
        sum_model = general.get("summarization_model")
        interface_model = general.get("interface_model")

        console.print("[bold]Existing Models:[/bold]")
        console.print(
            f"  [green]* Main Model: {def_model}[/green]   "
            f"[blue]* Summarization Model: {sum_model}[/blue]   "
            f"[magenta]* Interface Model: {interface_model}[/magenta]\n"
        )

        table = Table(show_header=True)
        table.add_column("No.")
        table.add_column("Alias")
        table.add_column("ID")

        aliases = list_model_aliases()
        for i, alias in enumerate(aliases, 1):
            model = MODELS[alias]

            # Format alias with indicators
            alias_display = alias
            if alias == def_model:
                alias_display = f"[green]{alias} *[/green]"
            if alias == sum_model:
                # If both, append blue * too
                if alias == def_model:
                    alias_display += f" [blue]*[/blue]"
                else:
                    alias_display = f"[blue]{alias} *[/blue]"

            table.add_row(str(i), alias_display, model.get("id", ""))

        console.print(table)

        choice_input = Prompt.ask("Enter model alias (or number) to edit")

        # Check if number
        try:
            choice_idx = int(choice_input)
            if 1 <= choice_idx <= len(aliases):
                model_alias = aliases[choice_idx - 1]
            else:
                model_alias = choice_input
        except ValueError:
            model_alias = choice_input

    if model_alias not in MODELS:
        console.print(f"[red]Model '{model_alias}' not found[/red]")
        return

    current_config = MODELS[model_alias]

    config = load_config()
    general = config.get("general", {})
    def_model = general.get("default_model")
    sum_model = general.get("summarization_model")
    interface_model = general.get("interface_model")
    image_model = general.get("default_image_model")

    role_tags = []
    if model_alias == def_model:
        role_tags.append("[green]main[/green]")
    if model_alias == sum_model:
        role_tags.append("[blue]summarization[/blue]")
    if model_alias == interface_model:
        role_tags.append("[magenta]interface[/magenta]")
    if model_alias == image_model:
        role_tags.append("[yellow]image[/yellow]")
    role_str = ", ".join(role_tags) if role_tags else "none"

    console.print(f"\n[bold]Model: {model_alias}[/bold]  (current role: {role_str})")
    console.print(f"  ID:             {current_config.get('id')}")
    console.print(f"  API:            {current_config.get('api')}")
    console.print(f"  Context size:   {current_config.get('context_size')}")
    console.print(
        f"  Source shortlist: "
        f"{_shortlist_mode_from_value(current_config.get('source_shortlist_enabled'))}"
    )
    console.print(
        f"  Image support:    "
        f"{_image_support_mode_from_value(current_config.get('image_support'))}"
    )

    console.print("\n[bold]Perform action:[/bold]")
    console.print("  [green]m[/green] - set as [bold]main[/bold] model")
    console.print("  [blue]s[/blue] - set as [bold]summarization[/bold] model")
    console.print("  [magenta]i[/magenta] - set as [bold]interface[/bold] model")
    console.print("  [yellow]g[/yellow] - set as [bold]default image[/bold] model")
    console.print("  [yellow]e[/yellow] - edit parameters")

    action = Prompt.ask(
        "\nSelect action",
        choices=["m", "s", "i", "g", "e"],
        default="e",
    )

    if action == "m":
        update_general_config("default_model", model_alias)
        return

    if action == "s":
        update_general_config("summarization_model", model_alias)
        return

    if action == "i":
        update_general_config("interface_model", model_alias)
        return

    if action == "g":
        update_general_config("default_image_model", model_alias)
        return

    # action == "e": proceed to full parameter edit
    context_size = IntPrompt.ask(
        "Context size",
        default=int(current_config.get("context_size", 4096)),
    )

    shortlist_mode = Prompt.ask(
        "Pre-LLM source shortlisting for this model",
        choices=[SHORTLIST_MODE_AUTO, SHORTLIST_MODE_ON, SHORTLIST_MODE_OFF],
        default=_shortlist_mode_from_value(
            current_config.get("source_shortlist_enabled")
        ),
    )
    shortlist_enabled = _shortlist_value_from_mode(shortlist_mode)
    image_support_mode = Prompt.ask(
        "Image input support for this model",
        choices=[
            IMAGE_SUPPORT_MODE_AUTO,
            IMAGE_SUPPORT_MODE_ON,
            IMAGE_SUPPORT_MODE_OFF,
        ],
        default=_image_support_mode_from_value(current_config.get("image_support")),
    )
    image_support = _image_support_value_from_mode(image_support_mode)

    console.print("\n[bold]Configure Parameters[/bold]")

    parameters = current_config.get("parameters", {}).copy()
    options = list(openrouter.KNOWN_PARAMETERS.keys())

    console.print(
        "\n[bold]Configuration (Press Enter to keep current, type 'none' to unset)[/bold]"
    )

    for param_to_edit in options:
        param_info = openrouter.KNOWN_PARAMETERS[param_to_edit]
        default_val = param_info.get("default")
        curr_val = parameters.get(param_to_edit)

        prompt_default = str(curr_val) if curr_val is not None else ""

        param_type = param_info.get("type")
        hint = f"({param_type}"
        if "min" in param_info:
            hint += f", min={param_info['min']}"
        if "max" in param_info:
            hint += f", max={param_info['max']}"
        if default_val is not None and curr_val is None:
            hint += f", default={default_val}"
        hint += ")"

        label = param_to_edit
        if curr_val is not None:
            label = f"[green]{param_to_edit}[/green]"

        val_input = Prompt.ask(f"  {label} {hint}", default=prompt_default)

        if val_input == prompt_default:
            continue

        if val_input.lower() in ["none", "unset", "null", ""]:
            if param_to_edit in parameters:
                del parameters[param_to_edit]
                console.print(f"    [yellow]Unset {param_to_edit}[/yellow]")
        else:
            try:
                if param_type == "float":
                    parameters[param_to_edit] = float(val_input)
                elif param_type == "int":
                    parameters[param_to_edit] = int(val_input)
                elif param_type == "bool":
                    val_lower = val_input.lower()
                    if val_lower in ["true", "t", "yes", "y", "1"]:
                        parameters[param_to_edit] = True
                    elif val_lower in ["false", "f", "no", "n", "0"]:
                        parameters[param_to_edit] = False
                    else:
                        raise ValueError(f"Invalid boolean value: {val_input}")
            except ValueError:
                console.print(
                    f"    [red]Invalid value for {param_to_edit}, skipping change[/red]"
                )

    if Confirm.ask("\nSave changes?", default=True):
        new_config = {
            "id": current_config.get("id"),
            "api": current_config.get("api"),
            "context_size": context_size,
            "source_shortlist_enabled": shortlist_enabled,
            "image_support": image_support,
            "parameters": parameters if parameters else None,
        }
        save_model_config(model_alias, new_config)
        console.print(f"\n[green]Model '{model_alias}' updated successfully![/green]")


def save_model_config(nickname: str, config: Dict[str, Any]):
    """Save a model configuration to user's models.toml using tomlkit."""
    config_path = Path.home() / ".config" / "asky" / "models.toml"

    if not config_path.exists():
        config_path.touch()

    try:
        content = config_path.read_text()
        doc = tomlkit.parse(content)

        # Ensure 'models' listing style is supported.
        # Typically structure is [models.nickname].
        # In tomlkit, if we access doc["models"], it refers to the table 'models' if it exists.
        # But if we want [models.impl], we usually treat 'models' as a table containing subtables.

        if "models" not in doc:
            doc.add("models", tomlkit.table())

        models_table = doc["models"]

        # Prepare new model data
        # We want it to be an inline table or standard table?
        # Using [models.nickname] implies nickname is a subtable of models.

        # Build the model dict
        model_data = tomlkit.table()
        model_data["id"] = config["id"]
        if "api" in config:
            model_data["api"] = config["api"]
        model_data["context_size"] = config["context_size"]
        shortlist_enabled = config.get("source_shortlist_enabled")
        if shortlist_enabled is not None:
            model_data["source_shortlist_enabled"] = bool(shortlist_enabled)
        image_support = config.get("image_support")
        if image_support is not None:
            model_data["image_support"] = bool(image_support)

        if config.get("parameters"):
            params = tomlkit.table()
            for k, v in config["parameters"].items():
                params[k] = v
            model_data["parameters"] = params

        # Update or Set
        # If duplicated, tomlkit handles replacement in memory.
        models_table[nickname] = model_data

        config_path.write_text(doc.as_string())

    except Exception as e:
        console.print(f"[red]Failed to save model config: {e}[/red]")
