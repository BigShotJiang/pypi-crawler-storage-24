"""Plugin manager: manifest loading, import, dependency ordering, lifecycle."""

from __future__ import annotations

import importlib
import logging
import os
import tomllib
import tomlkit
from dataclasses import dataclass
from importlib import resources
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

from asky.config.loader import _get_config_dir
from asky.plugins.base import AskyPlugin, CLIContribution, PluginContext, PluginStatus
from asky.plugins.hooks import HookRegistry
from asky.plugins.manifest import PluginManifest, build_manifest_entry

logger = logging.getLogger(__name__)


@dataclass
class DependencyIssue:
    """Describes one unmet plugin dependency detected during roster resolution."""

    plugin_name: str
    dep_name: str
    reason: str  # "disabled" | "not_found" | "failed"


PLUGIN_ROSTER_FILENAME = "plugins.toml"
PLUGIN_CONFIG_SUBDIR = "plugins"
PLUGIN_DATA_SUBDIR = "plugins"
_BUNDLED_PLUGINS_TOML = resources.files("asky.data.config").joinpath("plugins.toml")
ACTIVE_PLUGIN_STATE = "active"
IMPORTED_PLUGIN_STATE = "imported"
DISABLED_PLUGIN_STATE = "disabled"
FAILED_MANIFEST_STATE = "failed_manifest"
FAILED_DEPENDENCY_STATE = "failed_dependency"
SKIPPED_DEPENDENCY_STATE = "skipped_dependency"
FAILED_IMPORT_STATE = "failed_import"
FAILED_ACTIVATION_STATE = "failed_activation"
INACTIVE_PLUGIN_STATE = "inactive"


class PluginManager:
    """Load, resolve, and manage plugin lifecycle."""

    def __init__(
        self,
        *,
        hook_registry: Optional[HookRegistry] = None,
        config_dir: Optional[Path] = None,
    ) -> None:
        self.hook_registry = hook_registry or HookRegistry()
        self.config_dir = (config_dir or _get_config_dir()).expanduser()
        self.roster_path = self.config_dir / PLUGIN_ROSTER_FILENAME
        self.plugin_config_root = self.config_dir
        self.plugin_data_root = self.config_dir / PLUGIN_DATA_SUBDIR

        self._manifests: Dict[str, PluginManifest] = {}
        self._plugins: Dict[str, AskyPlugin] = {}
        self._contexts: Dict[str, PluginContext] = {}
        self._statuses: Dict[str, PluginStatus] = {}
        self._load_order: List[str] = []
        self._activation_order: List[str] = []
        self._dependency_issues: List[DependencyIssue] = []

    def load_roster(self) -> List[PluginManifest]:
        """Load plugin roster from ~/.config/asky/plugins.toml."""
        self._ensure_roster_file()
        try:
            with self.roster_path.open("rb") as file_obj:
                payload = tomllib.load(file_obj)
        except tomllib.TOMLDecodeError as exc:
            logger.error("Invalid plugins.toml at %s: %s", self.roster_path, exc)
            return []
        except Exception:
            logger.exception("Failed to read plugin roster at %s", self.roster_path)
            return []

        plugin_table = payload.get("plugin", {})
        if not isinstance(plugin_table, dict):
            logger.warning("plugins.toml entry [plugin] must be a table")
            return []

        self._manifests = {}
        self._plugins = {}
        self._contexts = {}
        self._statuses = {}
        self._load_order = []
        self._activation_order = []
        self._dependency_issues = []

        normalized_name_map: Dict[str, str] = {}
        for plugin_name in sorted(plugin_table.keys()):
            raw_entry = plugin_table.get(plugin_name)
            name = str(plugin_name or "").strip()
            if not name:
                continue

            normalized_name = name.casefold()
            if normalized_name in normalized_name_map:
                conflict_name = normalized_name_map[normalized_name]
                self._statuses[name] = PluginStatus(
                    name=name,
                    enabled=False,
                    state=FAILED_MANIFEST_STATE,
                    message=f"name collision with plugin '{conflict_name}'",
                )
                logger.error(
                    "Plugin name collision: '%s' conflicts with '%s'",
                    name,
                    conflict_name,
                )
                continue
            normalized_name_map[normalized_name] = name

            build_result = build_manifest_entry(name, raw_entry)
            for warning in build_result.warnings:
                logger.warning(warning)

            if build_result.manifest is None:
                message = build_result.error or "invalid manifest entry"
                self._statuses[name] = PluginStatus(
                    name=name,
                    enabled=False,
                    state=FAILED_MANIFEST_STATE,
                    message=message,
                )
                logger.error("Plugin '%s' manifest invalid: %s", name, message)
                continue

            manifest = build_result.manifest
            self._manifests[name] = manifest
            state = DISABLED_PLUGIN_STATE if not manifest.enabled else "loaded"
            status_message = "plugin is disabled" if not manifest.enabled else ""
            self._statuses[name] = PluginStatus(
                name=name,
                enabled=manifest.enabled,
                module=manifest.module,
                plugin_class=manifest.plugin_class,
                state=state,
                message=status_message,
                active=False,
                dependencies=manifest.dependencies,
            )

        self._detect_early_dependency_issues()
        return [self._manifests[name] for name in sorted(self._manifests.keys())]

    def discover_and_import(self) -> None:
        """Import plugin classes and instantiate plugin objects."""
        order = self._resolve_dependency_order()
        self._load_order = []

        for plugin_name in order:
            manifest = self._manifests[plugin_name]
            if not manifest.enabled:
                continue
            dependency_failure = self._first_failed_dependency(manifest)
            if dependency_failure is not None:
                self._set_status(
                    plugin_name,
                    state=SKIPPED_DEPENDENCY_STATE,
                    message=(
                        f"dependency '{dependency_failure}' is not available"
                    ),
                )
                continue

            try:
                plugin_module = importlib.import_module(manifest.module)
                plugin_class = getattr(plugin_module, manifest.plugin_class)
                plugin_instance = plugin_class()
                if not isinstance(plugin_instance, AskyPlugin):
                    raise TypeError(
                        f"{manifest.module}.{manifest.plugin_class} is not an AskyPlugin"
                    )
            except Exception as exc:
                self._set_status(
                    plugin_name,
                    state=FAILED_IMPORT_STATE,
                    message=str(exc),
                )
                logger.exception(
                    "Plugin '%s' import failed module=%s class=%s",
                    plugin_name,
                    manifest.module,
                    manifest.plugin_class,
                )
                continue

            self._plugins[plugin_name] = plugin_instance
            self._load_order.append(plugin_name)
            self._set_status(plugin_name, state=IMPORTED_PLUGIN_STATE, message="")

    def activate_all(self) -> None:
        """Activate all imported plugins in deterministic dependency order."""
        self.plugin_data_root.mkdir(parents=True, exist_ok=True)
        self._activation_order = []

        for plugin_name in self._load_order:
            manifest = self._manifests[plugin_name]
            if not manifest.enabled:
                continue

            dependency_failure = self._first_failed_dependency(manifest)
            if dependency_failure is not None:
                self._set_status(
                    plugin_name,
                    state=SKIPPED_DEPENDENCY_STATE,
                    message=(
                        f"dependency '{dependency_failure}' is not active"
                    ),
                )
                continue

            plugin = self._plugins.get(plugin_name)
            if plugin is None:
                continue

            try:
                plugin_config = self._load_plugin_config(manifest)
            except Exception as exc:
                self._set_status(
                    plugin_name,
                    state=FAILED_ACTIVATION_STATE,
                    message=f"config load failed: {exc}",
                )
                logger.exception(
                    "Plugin '%s' config load failed from %s",
                    plugin_name,
                    manifest.config_file,
                )
                continue

            context = PluginContext(
                plugin_name=plugin_name,
                config_dir=self.config_dir,
                data_dir=self._get_plugin_data_dir(plugin_name),
                config=plugin_config,
                hook_registry=self.hook_registry,
                logger=logger.getChild(plugin_name),
            )

            capability_mismatches = [
                capability
                for capability in manifest.capabilities
                if capability not in plugin.declared_capabilities
            ]
            for capability in capability_mismatches:
                logger.warning(
                    "Plugin '%s' manifest capability '%s' is not declared by plugin class",
                    plugin_name,
                    capability,
                )

            try:
                context.data_dir.mkdir(parents=True, exist_ok=True)
                plugin.activate(context)
            except Exception as exc:
                self._set_status(
                    plugin_name,
                    state=FAILED_ACTIVATION_STATE,
                    message=str(exc),
                )
                logger.exception("Plugin '%s' activation failed", plugin_name)
                continue

            self._contexts[plugin_name] = context
            self._activation_order.append(plugin_name)
            self._set_status(
                plugin_name,
                state=ACTIVE_PLUGIN_STATE,
                message="",
                active=True,
            )

        self.hook_registry.freeze()

    def deactivate_all(self) -> None:
        """Deactivate plugins in reverse activation order."""
        for plugin_name in reversed(self._activation_order):
            plugin = self._plugins.get(plugin_name)
            if plugin is None:
                continue
            try:
                plugin.deactivate()
            except Exception:
                logger.exception("Plugin '%s' deactivation failed", plugin_name)
            self._set_status(
                plugin_name,
                state=INACTIVE_PLUGIN_STATE,
                message="",
                active=False,
            )
        self._activation_order = []

    def list_status(self) -> List[PluginStatus]:
        """Return plugin statuses sorted by plugin name."""
        return [self._statuses[name] for name in sorted(self._statuses.keys())]

    def is_active(self, name: str) -> bool:
        """Return True when plugin is active."""
        status = self._statuses.get(name)
        return bool(status and status.active and status.state == ACTIVE_PLUGIN_STATE)

    def get_plugin(self, name: str) -> Optional[AskyPlugin]:
        """Return plugin instance by name."""
        return self._plugins.get(name)

    def collect_cli_contributions(self) -> list[tuple[str, CLIContribution]]:
        """Light-import each enabled plugin class and collect its CLI contributions.

        Does NOT call activate(). Safe to call before activate_all(). Import
        errors are logged and skipped so a broken plugin never blocks CLI startup.
        """
        results: list[tuple[str, CLIContribution]] = []
        for name, manifest in sorted(self._manifests.items()):
            if not manifest.enabled:
                continue
            try:
                plugin_module = importlib.import_module(manifest.module)
                plugin_class = getattr(plugin_module, manifest.plugin_class)
                for contribution in plugin_class.get_cli_contributions():
                    results.append((name, contribution))
            except Exception:
                logger.warning(
                    "Plugin '%s' CLI contribution collection failed; skipping",
                    name,
                    exc_info=True,
                )
        return results

    def collect_cli_hint_contributions(self, context: Any) -> list[tuple[str, Any]]:
        """Light-import each enabled plugin class and collect its CLI inline hints.
        
        context should be an instance of CLIHintContext.
        Returns a list of tuples: (plugin_name, CLIHint).
        """
        results: list[tuple[str, Any]] = []
        for name, manifest in sorted(self._manifests.items()):
            if not manifest.enabled:
                continue
            try:
                plugin_module = importlib.import_module(manifest.module)
                plugin_class = getattr(plugin_module, manifest.plugin_class)
                if hasattr(plugin_class, "get_cli_hint_contributions"):
                    for hint in plugin_class.get_cli_hint_contributions(context):
                        results.append((name, hint))
            except Exception:
                logger.warning(
                    "Plugin '%s' CLI hint collection failed; skipping",
                    name,
                    exc_info=True,
                )
        return results

    def has_enabled_plugins(self) -> bool:
        """Return whether manifest contains any enabled plugins."""
        return any(manifest.enabled for manifest in self._manifests.values())

    def get_dependency_issues(self) -> List[DependencyIssue]:
        """Return all dependency issues collected during roster resolution."""
        return list(self._dependency_issues)

    def enable_plugin(self, name: str) -> bool:
        """Enable a plugin in-memory and persist the change to plugins.toml."""
        manifest = self._manifests.get(name)
        if manifest is None:
            return False
        self._manifests[name] = PluginManifest(
            name=manifest.name,
            enabled=True,
            module=manifest.module,
            plugin_class=manifest.plugin_class,
            dependencies=manifest.dependencies,
            capabilities=manifest.capabilities,
            config_file=manifest.config_file,
        )
        status = self._statuses.get(name)
        if status is not None:
            status.enabled = True
            status.state = "loaded"
            status.message = ""
        self._persist_enabled_state(name, enabled=True)
        return True

    def _persist_enabled_state(self, name: str, enabled: bool) -> None:
        """Atomically write the enabled flag for plugin ``name`` to plugins.toml."""
        import tomlkit

        try:
            with self.roster_path.open("rb") as fh:
                doc = tomlkit.load(fh)
        except Exception:
            logger.exception(
                "Could not read plugins.toml for enabled-state update plugin=%s", name
            )
            return

        plugin_table = doc.get("plugin", {})
        if isinstance(plugin_table, dict) and name in plugin_table:
            plugin_table[name]["enabled"] = enabled

        tmp_path = self.roster_path.with_suffix(".toml.tmp")
        try:
            tmp_path.write_text(tomlkit.dumps(doc), encoding="utf-8")
            os.replace(tmp_path, self.roster_path)
        except Exception:
            logger.exception(
                "Could not write plugins.toml for enabled-state update plugin=%s", name
            )
            tmp_path.unlink(missing_ok=True)

    def _detect_early_dependency_issues(self) -> None:
        """Populate ``_dependency_issues`` for disabled/missing deps after roster load.

        This runs before ``discover_and_import()`` so the interactive prompt in
        ``_handle_dependency_issues()`` can offer to enable disabled deps before
        the import phase.
        """
        for name in sorted(self._manifests):
            manifest = self._manifests[name]
            if not manifest.enabled:
                continue
            for dep in manifest.dependencies:
                dep_manifest = self._manifests.get(dep)
                if dep_manifest is None:
                    self._dependency_issues.append(
                        DependencyIssue(plugin_name=name, dep_name=dep, reason="not_found")
                    )
                    break
                if not dep_manifest.enabled:
                    self._dependency_issues.append(
                        DependencyIssue(plugin_name=name, dep_name=dep, reason="disabled")
                    )
                    break

    def _ensure_roster_file(self) -> None:
        self.config_dir.mkdir(parents=True, exist_ok=True)
        if not self.roster_path.exists():
            try:
                self.roster_path.write_bytes(_BUNDLED_PLUGINS_TOML.read_bytes())
                logger.info("Created plugin roster template at %s", self.roster_path)
            except Exception:
                logger.exception("Failed to create plugin roster template at %s", self.roster_path)
            return
        self._sync_new_bundled_plugins()

    def _sync_new_bundled_plugins(self) -> None:
        """Append plugins from the bundled default that are absent in the user roster."""
        try:
            bundled = tomllib.loads(_BUNDLED_PLUGINS_TOML.read_bytes().decode())
            user_text = self.roster_path.read_text(encoding="utf-8")
            user = tomllib.loads(user_text)
            user_doc = tomlkit.parse(user_text)
        except Exception:
            logger.debug("Could not parse plugin rosters for sync; skipping", exc_info=True)
            return

        missing = {
            name: cfg
            for name, cfg in bundled.get("plugin", {}).items()
            if name not in user.get("plugin", {})
        }
        if not missing:
            return

        try:
            plugin_table = user_doc.get("plugin")
            if plugin_table is None or not isinstance(plugin_table, dict):
                plugin_table = tomlkit.table()
                user_doc["plugin"] = plugin_table

            for name, cfg in missing.items():
                section = tomlkit.table()
                for key, value in cfg.items():
                    section[key] = tomlkit.item(value)
                plugin_table[name] = section

            self.roster_path.write_text(tomlkit.dumps(user_doc), encoding="utf-8")
            logger.info("Added new built-in plugin(s) to roster: %s", list(missing))
        except Exception:
            logger.exception("Failed to append new plugins to roster at %s", self.roster_path)

    def _set_status(
        self,
        plugin_name: str,
        *,
        state: str,
        message: str,
        active: Optional[bool] = None,
    ) -> None:
        status = self._statuses.get(plugin_name)
        if status is None:
            status = PluginStatus(name=plugin_name, enabled=True)
            self._statuses[plugin_name] = status

        status.state = state
        status.message = message
        if active is not None:
            status.active = active

    def _resolve_dependency_order(self) -> List[str]:
        enabled_names = {
            name for name, manifest in self._manifests.items() if manifest.enabled
        }

        # Early dependency validation for unknown/disabled dependencies.
        valid_names: Set[str] = set()
        for name in sorted(enabled_names):
            manifest = self._manifests[name]
            invalid_dependency = None
            for dependency in manifest.dependencies:
                dependency_manifest = self._manifests.get(dependency)
                if dependency_manifest is None:
                    invalid_dependency = f"unknown dependency '{dependency}'"
                    break
                if not dependency_manifest.enabled:
                    invalid_dependency = f"dependency '{dependency}' is disabled"
                    break
            if invalid_dependency:
                self._set_status(
                    name,
                    state=FAILED_DEPENDENCY_STATE,
                    message=invalid_dependency,
                )
                continue
            valid_names.add(name)

        adjacency: Dict[str, Set[str]] = {name: set() for name in valid_names}
        indegree: Dict[str, int] = {name: 0 for name in valid_names}

        for name in sorted(valid_names):
            manifest = self._manifests[name]
            for dependency in manifest.dependencies:
                if dependency not in valid_names:
                    continue
                adjacency[dependency].add(name)
                indegree[name] += 1

        available = sorted([name for name, degree in indegree.items() if degree == 0])
        order: List[str] = []
        while available:
            current = available.pop(0)
            order.append(current)
            for dependent in sorted(adjacency.get(current, set())):
                indegree[dependent] -= 1
                if indegree[dependent] == 0:
                    available.append(dependent)
                    available.sort()

        cycle_nodes = sorted(set(valid_names) - set(order))
        for name in cycle_nodes:
            self._set_status(
                name,
                state=FAILED_DEPENDENCY_STATE,
                message="dependency cycle detected",
            )

        # Skip plugins depending on failed dependency nodes.
        failed_names = {
            name
            for name, status in self._statuses.items()
            if status.state in {FAILED_DEPENDENCY_STATE, FAILED_MANIFEST_STATE}
        }
        if failed_names:
            for name in order:
                manifest = self._manifests[name]
                failed_dependency = next(
                    (dependency for dependency in manifest.dependencies if dependency in failed_names),
                    None,
                )
                if failed_dependency is not None:
                    self._set_status(
                        name,
                        state=SKIPPED_DEPENDENCY_STATE,
                        message=f"dependency '{failed_dependency}' failed",
                    )

        return order

    def _first_failed_dependency(self, manifest: PluginManifest) -> Optional[str]:
        for dependency in manifest.dependencies:
            if dependency not in self._manifests:
                return dependency
            dep_status = self._statuses.get(dependency)
            if dep_status is None:
                return dependency
            if dep_status.state not in {
                "loaded",
                IMPORTED_PLUGIN_STATE,
                ACTIVE_PLUGIN_STATE,
                INACTIVE_PLUGIN_STATE,
                DISABLED_PLUGIN_STATE,
            }:
                return dependency
            if dep_status.state == DISABLED_PLUGIN_STATE:
                return dependency
            if dep_status.state == INACTIVE_PLUGIN_STATE and dependency not in self._activation_order:
                return dependency
        return None

    def _get_plugin_data_dir(self, plugin_name: str) -> Path:
        return self.plugin_data_root / plugin_name

    def _load_plugin_config(self, manifest: PluginManifest) -> Dict[str, Any]:
        if not manifest.config_file:
            return {}

        config_path = (self.plugin_config_root / manifest.config_file).expanduser()
        if not config_path.exists():
            return {}

        with config_path.open("rb") as file_obj:
            loaded = tomllib.load(file_obj)

        if not isinstance(loaded, dict):
            return {}
        return loaded
