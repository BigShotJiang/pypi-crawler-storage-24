"""Evaluation helpers for asky."""
