"""Session management logic for asky."""

import atexit
import logging
import os
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from asky.config import (
    SESSION_COMPACTION_THRESHOLD,
    SESSION_COMPACTION_STRATEGY,
    SUMMARIZE_SESSION_PROMPT,
    SUMMARIZE_SESSION_TITLE_PROMPT,
    MODELS,
    DEFAULT_CONTEXT_SIZE,
    SUMMARIZATION_MODEL,
)
from asky.storage import Session
from asky.storage.sqlite import SQLiteHistoryRepository
from asky.core.api_client import count_tokens, get_llm_msg, UsageTracker
from asky.summarization import _summarize_content
from asky.html import strip_think_tags

logger = logging.getLogger(__name__)

# Lock file for shell-sticky sessions
# Each terminal (identified by parent shell PID) gets its own lock file.
LOCK_DIR = Path("/tmp")
LOCK_PREFIX = "asky_session_"

# Common stopwords to filter from session names
STOPWORDS = frozenset(
    {
        "a",
        "an",
        "the",
        "is",
        "are",
        "was",
        "were",
        "be",
        "been",
        "being",
        "have",
        "has",
        "had",
        "do",
        "does",
        "did",
        "will",
        "would",
        "could",
        "should",
        "may",
        "might",
        "must",
        "shall",
        "can",
        "need",
        "dare",
        "ought",
        "used",
        "to",
        "of",
        "in",
        "for",
        "on",
        "with",
        "at",
        "by",
        "from",
        "as",
        "into",
        "through",
        "during",
        "before",
        "after",
        "above",
        "below",
        "between",
        "under",
        "again",
        "further",
        "then",
        "once",
        "here",
        "there",
        "when",
        "where",
        "why",
        "how",
        "all",
        "each",
        "few",
        "more",
        "most",
        "other",
        "some",
        "such",
        "no",
        "nor",
        "not",
        "only",
        "own",
        "same",
        "so",
        "than",
        "too",
        "very",
        "just",
        "also",
        "now",
        "what",
        "which",
        "who",
        "whom",
        "this",
        "that",
        "these",
        "those",
        "am",
        "and",
        "but",
        "if",
        "or",
        "because",
        "while",
        "although",
        "i",
        "me",
        "my",
        "myself",
        "we",
        "our",
        "ours",
        "ours",
        "ourselves",
        "you",
        "your",
        "yours",
        "yourself",
        "yourselves",
        "he",
        "him",
        "his",
        "himself",
        "she",
        "her",
        "hers",
        "herself",
        "it",
        "its",
        "itself",
        "they",
        "them",
        "their",
        "theirs",
        "themselves",
        "about",
        "tell",
        "no",
    }
)
TERMINAL_CONTEXT_PREFIX = "terminal context (last "
TERMINAL_CONTEXT_QUERY_MARKER = "\n\nQuery:\n"


def _strip_terminal_context_wrapper(query: str) -> str:
    """Extract the actual user query when terminal-context wrapper is present."""
    normalized = (query or "").replace("\r\n", "\n").strip()
    if not normalized:
        return ""
    if not normalized.lower().startswith(TERMINAL_CONTEXT_PREFIX):
        return normalized

    marker_index = normalized.find(TERMINAL_CONTEXT_QUERY_MARKER)
    if marker_index < 0:
        return normalized

    extracted_query = normalized[
        marker_index + len(TERMINAL_CONTEXT_QUERY_MARKER) :
    ].strip()
    return extracted_query or normalized


def generate_session_name(query: str, max_words: int = 2) -> str:
    """Generate a session name from query by asking the summarization model.

    Falls back to extracting key words if the LLM call fails or returns empty.
    """
    normalized_query = _strip_terminal_context_wrapper(query)

    if not normalized_query:
        return "session"

    try:
        from asky.summarization import _summarize_content
        # Attempt to get a short, human-readable title via LLM.
        # We allow up to a typical title length (e.g., 50 chars).
        summarized_name = _summarize_content(
            content=normalized_query,
            prompt_template=SUMMARIZE_SESSION_TITLE_PROMPT,
            max_output_chars=50,
        )
        if summarized_name:
            # Clean up potential punctuation or quotes
            cleaned = summarized_name.strip(' "\'.')
            if cleaned:
                return cleaned
    except Exception as e:
        logger.debug(f"Failed to generate session name via LLM: {e}")

    # Deterministic fallback (legacy behavior)
    words = re.findall(r"[a-zA-Z]+", normalized_query.lower())
    key_words = [w for w in words if w not in STOPWORDS and len(w) > 2]
    selected = key_words[:max_words]

    if not selected:
        return "session"

    return "_".join(selected)


def _get_shell_pid() -> int:
    """Get the parent shell's process ID."""
    return os.getppid()


def _get_lock_file_path() -> Path:
    """Return the lock file path for the current shell."""
    return LOCK_DIR / f"{LOCK_PREFIX}{_get_shell_pid()}"


def get_shell_session_id() -> Optional[int]:
    """Read the session ID from the shell's lock file, if any."""
    lock_file = _get_lock_file_path()
    if lock_file.exists():
        try:
            return int(lock_file.read_text().strip())
        except ValueError:
            return None
    return None


def set_shell_session_id(session_id: int) -> None:
    """Write the session ID to the shell's lock file atomically."""
    lock_file = _get_lock_file_path()
    tmp = lock_file.with_suffix(".tmp")
    tmp.write_text(str(session_id))
    os.replace(tmp, lock_file)
    logger.info(f"Session lock file created: {lock_file}")


def clear_shell_session() -> None:
    """Remove the shell's session lock file (detach from session)."""
    lock_file = _get_lock_file_path()
    if lock_file.exists():
        lock_file.unlink()
        logger.info(f"Session lock file removed: {lock_file}")


class SessionManager:
    """Orchestrates persistent conversation sessions and compaction.

    Sessions are persistent conversation threads that never end.
    A shell attaches to a session via lock file, not DB state.
    """

    def __init__(
        self,
        model_config: Dict[str, Any],
        usage_tracker: Optional[UsageTracker] = None,
        summarization_tracker: Optional[UsageTracker] = None,
    ):
        self.repo = SQLiteHistoryRepository()
        self.model_config = model_config
        self.usage_tracker = usage_tracker
        self.summarization_tracker = summarization_tracker
        self.current_session: Optional[Session] = None
        self.context_size = model_config.get("context_size", DEFAULT_CONTEXT_SIZE)

    def create_session(
        self,
        name: str,
        memory_auto_extract: bool = False,
        max_turns: Optional[int] = None,
        research_mode: bool = False,
        research_source_mode: Optional[str] = None,
        research_local_corpus_paths: Optional[List[str]] = None,
    ) -> Session:
        """Create a new named session.

        args:
            name: The name for the new session.
            memory_auto_extract: Enable automatic fact extraction for this session.
            max_turns: Overridden max turn limit for this session.
        """
        sid = self.repo.create_session(
            self.model_config["alias"],
            name=name,
            memory_auto_extract=memory_auto_extract,
            max_turns=max_turns,
            research_mode=research_mode,
            research_source_mode=research_source_mode,
            research_local_corpus_paths=research_local_corpus_paths,
        )
        self.current_session = self.repo.get_session_by_id(sid)
        return self.current_session

    def update_current_session_research_profile(
        self,
        *,
        research_mode: bool,
        research_source_mode: Optional[str],
        research_local_corpus_paths: Optional[List[str]],
    ) -> None:
        """Update persisted research metadata for the active session."""
        if not self.current_session:
            return
        self.repo.update_session_research_profile(
            int(self.current_session.id),
            research_mode=research_mode,
            research_source_mode=research_source_mode,
            research_local_corpus_paths=research_local_corpus_paths,
        )
        refreshed = self.repo.get_session_by_id(int(self.current_session.id))
        if refreshed:
            self.current_session = refreshed

    def update_current_session_shortlist_override(self, value: Optional[str]) -> None:
        """Update persisted shortlist override for the active session."""
        if not self.current_session:
            return
        self.repo.update_session_shortlist_override(int(self.current_session.id), value)
        self.current_session.shortlist_override = value

    def update_current_session_query_defaults(self, values: Dict[str, Any]) -> None:
        """Update persisted query-behavior defaults for the active session."""
        if not self.current_session:
            return
        self.repo.update_session_query_defaults(int(self.current_session.id), values)
        self.current_session.query_defaults = dict(values)

    def find_sessions(self, search_term: str) -> List[Session]:
        """Find sessions matching the search term.

        Search logic:
        1. If numeric, exact ID match.
        2. Exact name match.
        3. Partial name match (case-insensitive).
        4. Legacy 'S' prefix handling.
        """
        results = []
        seen_ids = set()

        def add(session: Optional[Session]):
            if session and session.id not in seen_ids:
                results.append(session)
                seen_ids.add(session.id)

        # 1. Exact ID - numeric terms are unambiguous; skip name/partial scans
        if search_term.isdigit():
            add(self.repo.get_session_by_id(int(search_term)))
            return results

        # 2. Legacy S-prefix
        if search_term.lower().startswith("s") and search_term[1:].isdigit():
            add(self.repo.get_session_by_id(int(search_term[1:])))

        # 3. Name Search (Exact)
        exact_matches = self.repo.get_sessions_by_name(search_term)
        for s in exact_matches:
            add(s)

        # 4. Partial Scan
        # Scan recent sessions (limit 200) for fuzzy matches
        recent_sessions = self.repo.list_sessions(limit=200)
        term_lower = search_term.lower()
        for s in recent_sessions:
            if s.name and term_lower in s.name.lower():
                add(s)

        return results

    def build_context_messages(self) -> List[Dict[str, str]]:
        """Retrieve session messages and format them for context."""
        if not self.current_session:
            return []

        messages = []

        # 1. Add compacted summary if it exists
        if self.current_session.compacted_summary:
            messages.append(
                {
                    "role": "user",
                    "content": f"Previous conversation summary:\n{self.current_session.compacted_summary}",
                }
            )
            messages.append(
                {
                    "role": "assistant",
                    "content": "I understand the context. How can I help further?",
                }
            )

        # 2. Add recent messages (all messages after compaction for now)
        # In a more advanced version, we might only add messages AFTER the compaction timestamp.
        session_msgs = self.repo.get_session_messages(self.current_session.id)
        for msg in session_msgs:
            messages.append({"role": msg.role, "content": msg.content})

        return messages

    def save_turn(
        self, query: str, answer: str, query_summary: str = "", answer_summary: str = ""
    ) -> int:
        """Save a conversation turn to the session. Returns the assistant message ID."""
        if not self.current_session:
            return 0

        # Calculate tokens (naive for now, improved later if needed)
        q_tokens = count_tokens([{"role": "user", "content": query}])
        a_tokens = count_tokens([{"role": "assistant", "content": answer}])

        self.repo.save_message(
            self.current_session.id, "user", query, query_summary, q_tokens
        )
        msg_id = self.repo.save_message(
            self.current_session.id, "assistant", answer, answer_summary, a_tokens
        )
        return msg_id

    def check_and_compact(self) -> bool:
        """Check if compaction is needed and trigger it."""
        if not self.current_session:
            return False

        # Calculate current session tokens
        messages = self.build_context_messages()
        current_token_count = count_tokens(messages)

        threshold_tokens = int(self.context_size * (SESSION_COMPACTION_THRESHOLD / 100))

        if current_token_count >= threshold_tokens:
            logger.info(
                f"Session {self.current_session.id} reached threshold ({current_token_count}/{threshold_tokens}). Compacting..."
            )
            return self._perform_compaction()

        return False

    def _perform_compaction(self) -> bool:
        """Perform compaction using the configured strategy."""
        if SESSION_COMPACTION_STRATEGY == "llm_summary":
            return self._compact_with_llm()
        else:
            return self._compact_with_summaries()

    def _compact_with_summaries(self) -> bool:
        """Concatenate existing summaries."""
        session_msgs = self.repo.get_session_messages(self.current_session.id)
        logger.info(
            f"Found {len(session_msgs)} messages to compact for session {self.current_session.id}"
        )
        summary_parts = []
        for msg in session_msgs:
            if msg.summary:
                summary_parts.append(f"{msg.role.capitalize()}: {msg.summary}")
            else:
                # Fallback to truncated content if no summary
                summary_parts.append(f"{msg.role.capitalize()}: {msg.content[:100]}...")

        compacted_content = "\n".join(summary_parts)
        logger.info(f"Compacted content length: {len(compacted_content)} chars")
        self.repo.compact_session(self.current_session.id, compacted_content)
        logger.info(f"Compaction saved for session {self.current_session.id}")
        return True

    def _compact_with_llm(self) -> bool:
        """Ask the model to summarize the whole session."""
        session_msgs = self.repo.get_session_messages(self.current_session.id)
        full_text = []
        for msg in session_msgs:
            full_text.append(f"{msg.role.capitalize()}: {msg.content}")

        conversation_blob = "\n\n".join(full_text)

        compacted_content = _summarize_content(
            content=conversation_blob,
            prompt_template=SUMMARIZE_SESSION_PROMPT,
            max_output_chars=4000,  # Large enough for context summary
            usage_tracker=self.summarization_tracker,
        )

        self.repo.compact_session(self.current_session.id, compacted_content)
        return True
