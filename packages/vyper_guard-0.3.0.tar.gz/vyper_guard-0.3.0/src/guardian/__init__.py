"""Vyper Guard — Vyper-native smart contract security analysis."""

__version__ = "0.3.0"
__app_name__ = "vyper-guard"
