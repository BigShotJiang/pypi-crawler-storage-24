"""Integration tests for the Ncheta class lifecycle."""
from __future__ import annotations

import http.client
import json
import time

import pytest

from ncheta import Ncheta
from tests.conftest import cleanup_db, random_port, temp_db_url


class TestNchetaLifecycle:
    def test_start_and_health(self) -> None:
        """Ncheta starts the binary and /health returns ok."""
        db_url = temp_db_url("lifecycle-start")
        ncheta = Ncheta(
            control_port=random_port(),
            ingestion_port=random_port(),
            db_url=db_url,
            start_timeout=15.0,
        )
        try:
            ncheta.start()
            result = ncheta.client.health()
            assert result["status"] == "ok"
        finally:
            ncheta.stop()
            cleanup_db(db_url)

    def test_events_returns_list(self) -> None:
        """ncheta.events() returns a list."""
        db_url = temp_db_url("lifecycle-events")
        ncheta = Ncheta(
            control_port=random_port(),
            ingestion_port=random_port(),
            db_url=db_url,
            start_timeout=15.0,
        )
        try:
            ncheta.start()
            events = ncheta.events()
            assert isinstance(events, list)
        finally:
            ncheta.stop()
            cleanup_db(db_url)

    def test_replay(self) -> None:
        """ncheta.replay() calls POST /events/{id}/replay."""
        db_url = temp_db_url("lifecycle-replay")
        ingestion_port = random_port()
        ncheta = Ncheta(
            control_port=random_port(),
            ingestion_port=ingestion_port,
            db_url=db_url,
            start_timeout=15.0,
        )
        try:
            ncheta.start()

            # Create endpoint and send a webhook via ingestion port
            ncheta.client.create_endpoint("replay-test", "http://127.0.0.1:9999")
            body = json.dumps({"test": "replay"}).encode()
            conn = http.client.HTTPConnection("127.0.0.1", ingestion_port, timeout=5)
            conn.request(
                "POST", "/in/replay-test", body,
                {"Content-Type": "application/json"},
            )
            conn.getresponse().read()
            conn.close()

            time.sleep(0.5)

            events = ncheta.events()
            assert len(events) > 0

            result = ncheta.replay(events[0]["id"])
            assert result["replaying"] is True
            assert result["event_id"] == events[0]["id"]
        finally:
            ncheta.stop()
            cleanup_db(db_url)

    def test_stop_terminates_binary(self) -> None:
        """ncheta.stop() terminates the binary so health fails after."""
        db_url = temp_db_url("lifecycle-stop")
        ncheta = Ncheta(
            control_port=random_port(),
            ingestion_port=random_port(),
            db_url=db_url,
            start_timeout=15.0,
        )
        ncheta.start()
        health = ncheta.client.health()
        assert health["status"] == "ok"

        ncheta.stop()
        time.sleep(0.2)

        with pytest.raises(Exception):
            ncheta.client.health()

        cleanup_db(db_url)
