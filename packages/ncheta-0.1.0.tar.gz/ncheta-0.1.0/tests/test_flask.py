"""Tests for Flask middleware."""
from __future__ import annotations

import json
import time

import pytest

from ncheta import Ncheta, RelayClient
from tests.conftest import cleanup_db, random_port, temp_db_url

flask = pytest.importorskip("flask")


@pytest.fixture(scope="module")
def ncheta_flask():
    """Start a ncheta instance for Flask tests."""
    db_url = temp_db_url("flask")
    control_port = random_port()
    ingestion_port = random_port()
    ncheta = Ncheta(
        control_port=control_port,
        ingestion_port=ingestion_port,
        db_url=db_url,
        start_timeout=15.0,
    )
    ncheta.start()
    ncheta.client.create_endpoint(
        "flask-test", "http://127.0.0.1:5000/webhook"
    )
    yield ncheta
    ncheta.stop()
    cleanup_db(db_url)


@pytest.fixture()
def flask_app(ncheta_flask: Ncheta):
    """Create a Flask app with Ncheta watch middleware."""
    app = flask.Flask(__name__)

    watch = ncheta_flask.watch_flask({
        "endpoint_name": "flask-test",
        "target_url": "http://127.0.0.1:5000/webhook",
    })

    @app.route("/webhook", methods=["POST"])
    @watch
    def webhook():
        data = flask.request.get_json(silent=True)
        return flask.jsonify({"received": True, "echo": data})

    return app


class TestFlaskMiddleware:
    def test_captures_request_body(
        self, flask_app: flask.Flask, ncheta_flask: Ncheta
    ) -> None:
        client = flask_app.test_client()
        body = {"type": "invoice.paid", "data": {"amount": 5000}}
        resp = client.post(
            "/webhook",
            data=json.dumps(body),
            content_type="application/json",
        )
        assert resp.status_code == 200

        # Wait for fire-and-forget capture
        time.sleep(0.5)

        events = ncheta_flask.events()
        assert len(events) > 0
        full_event = ncheta_flask.client.event(events[0]["id"])
        assert full_event.get("request_body") is not None
        parsed = json.loads(full_event["request_body"])
        assert parsed["type"] == "invoice.paid"

    def test_captures_response_status(
        self, flask_app: flask.Flask, ncheta_flask: Ncheta
    ) -> None:
        client = flask_app.test_client()
        resp = client.post(
            "/webhook",
            data=json.dumps({"test": "status"}),
            content_type="application/json",
        )
        assert resp.status_code == 200

        time.sleep(0.5)

        events = ncheta_flask.events()
        full_event = ncheta_flask.client.event(events[0]["id"])
        assert full_event.get("response_status") == 200

    def test_captures_response_body(
        self, flask_app: flask.Flask, ncheta_flask: Ncheta
    ) -> None:
        client = flask_app.test_client()
        resp = client.post(
            "/webhook",
            data=json.dumps({"test": "response-body"}),
            content_type="application/json",
        )
        time.sleep(0.5)

        events = ncheta_flask.events()
        full_event = ncheta_flask.client.event(events[0]["id"])
        assert full_event.get("response_body") is not None
        parsed = json.loads(full_event["response_body"])
        assert parsed["received"] is True

    def test_does_not_block_response(
        self, flask_app: flask.Flask
    ) -> None:
        client = flask_app.test_client()
        start = time.monotonic()
        resp = client.post(
            "/webhook",
            data=json.dumps({"test": "non-blocking"}),
            content_type="application/json",
        )
        elapsed = time.monotonic() - start
        assert elapsed < 2.0
        data = json.loads(resp.data)
        assert data["received"] is True

    def test_failure_never_crashes_handler(self) -> None:
        """Capture failure should not affect the handler response."""
        from ncheta.middleware._flask import create_flask_middleware

        bad_client = RelayClient(1)  # unreachable port
        app = flask.Flask(__name__)

        watch = create_flask_middleware(bad_client, {
            "endpoint_name": "bad",
            "target_url": "http://localhost:9999",
        })

        @app.route("/test", methods=["POST"])
        @watch
        def test_handler():
            return flask.jsonify({"handler": "ok"})

        client = app.test_client()
        resp = client.post(
            "/test",
            data=json.dumps({"test": "failure"}),
            content_type="application/json",
        )
        assert resp.status_code == 200
        data = json.loads(resp.data)
        assert data["handler"] == "ok"
