"""Tests for RelayClient against a real ncheta binary."""
from __future__ import annotations

import time

import pytest

from ncheta import Ncheta, RelayClient
from tests.conftest import cleanup_db, random_port, temp_db_url


@pytest.fixture(scope="module")
def ncheta_instance():
    """Start a ncheta instance for the test module."""
    db_url = temp_db_url("client")
    instance = Ncheta(
        control_port=random_port(),
        ingestion_port=random_port(),
        db_url=db_url,
        start_timeout=15.0,
    )
    instance.start()
    yield instance
    instance.stop()
    cleanup_db(db_url)


class TestRelayClient:
    def test_health(self, ncheta_instance: Ncheta) -> None:
        result = ncheta_instance.client.health()
        assert result["status"] == "ok"
        assert "version" in result

    def test_endpoints_empty(self, ncheta_instance: Ncheta) -> None:
        result = ncheta_instance.client.endpoints()
        assert isinstance(result, list)

    def test_create_endpoint(self, ncheta_instance: Ncheta) -> None:
        ep = ncheta_instance.client.create_endpoint(
            "test-ep", "http://localhost:9999/hook"
        )
        assert ep["name"] == "test-ep"
        assert ep["target_url"] == "http://localhost:9999/hook"
        assert "id" in ep

    def test_events_empty(self, ncheta_instance: Ncheta) -> None:
        result = ncheta_instance.client.events()
        assert isinstance(result, list)

    def test_capture_and_retrieve_event(self, ncheta_instance: Ncheta) -> None:
        # Ensure endpoint exists
        ncheta_instance.client.create_endpoint(
            "capture-test", "http://localhost:9999/hook"
        )
        resp = ncheta_instance.client.capture_event({
            "endpoint_name": "capture-test",
            "target_url": "http://localhost:9999/hook",
            "method": "POST",
            "path": "/hook",
            "request_body": '{"hello":"world"}',
            "response_status": 200,
            "response_body": '{"ok":true}',
        })
        assert "event_id" in resp

        # Retrieve the event
        event = ncheta_instance.client.event(resp["event_id"])
        assert event["method"] == "POST"

    def test_attempts(self, ncheta_instance: Ncheta) -> None:
        # Capture an event first
        ncheta_instance.client.create_endpoint(
            "attempts-test", "http://localhost:9999/hook"
        )
        resp = ncheta_instance.client.capture_event({
            "endpoint_name": "attempts-test",
            "target_url": "http://localhost:9999/hook",
            "method": "POST",
            "path": "/hook",
        })
        attempts = ncheta_instance.client.attempts(resp["event_id"])
        assert isinstance(attempts, list)
