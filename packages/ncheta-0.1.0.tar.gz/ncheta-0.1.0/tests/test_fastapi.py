"""Tests for FastAPI middleware."""
from __future__ import annotations

import json
import time

import pytest

fastapi = pytest.importorskip("fastapi")
httpx = pytest.importorskip("httpx")

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from fastapi.testclient import TestClient

from ncheta import Ncheta, RelayClient
from tests.conftest import cleanup_db, random_port, temp_db_url


@pytest.fixture(scope="module")
def ncheta_fastapi():
    """Start a ncheta instance for FastAPI tests."""
    db_url = temp_db_url("fastapi")
    ncheta = Ncheta(
        control_port=random_port(),
        ingestion_port=random_port(),
        db_url=db_url,
        start_timeout=15.0,
    )
    ncheta.start()
    ncheta.client.create_endpoint(
        "fastapi-test", "http://127.0.0.1:8000/webhook"
    )
    yield ncheta
    ncheta.stop()
    cleanup_db(db_url)


@pytest.fixture()
def fastapi_app(ncheta_fastapi: Ncheta):
    """Create a FastAPI app with Ncheta watch middleware."""
    app = FastAPI()

    middleware_fn = ncheta_fastapi.watch_fastapi({
        "endpoint_name": "fastapi-test",
        "target_url": "http://127.0.0.1:8000/webhook",
    })
    app.middleware("http")(middleware_fn)

    @app.post("/webhook")
    async def webhook(request: Request):
        body = await request.json()
        return JSONResponse({"received": True, "echo": body})

    return app


class TestFastAPIMiddleware:
    def test_captures_request_body(
        self, fastapi_app: FastAPI, ncheta_fastapi: Ncheta
    ) -> None:
        client = TestClient(fastapi_app)
        body = {"type": "invoice.paid", "data": {"amount": 5000}}
        resp = client.post("/webhook", json=body)
        assert resp.status_code == 200

        time.sleep(0.5)

        events = ncheta_fastapi.events()
        assert len(events) > 0
        full_event = ncheta_fastapi.client.event(events[0]["id"])
        assert full_event.get("request_body") is not None
        parsed = json.loads(full_event["request_body"])
        assert parsed["type"] == "invoice.paid"

    def test_captures_response_status(
        self, fastapi_app: FastAPI, ncheta_fastapi: Ncheta
    ) -> None:
        client = TestClient(fastapi_app)
        resp = client.post("/webhook", json={"test": "status"})
        assert resp.status_code == 200

        time.sleep(0.5)

        events = ncheta_fastapi.events()
        full_event = ncheta_fastapi.client.event(events[0]["id"])
        assert full_event.get("response_status") == 200

    def test_captures_response_body(
        self, fastapi_app: FastAPI, ncheta_fastapi: Ncheta
    ) -> None:
        client = TestClient(fastapi_app)
        resp = client.post("/webhook", json={"test": "response-body"})
        assert resp.status_code == 200

        time.sleep(0.5)

        events = ncheta_fastapi.events()
        full_event = ncheta_fastapi.client.event(events[0]["id"])
        assert full_event.get("response_body") is not None
        parsed = json.loads(full_event["response_body"])
        assert parsed["received"] is True

    def test_does_not_block_response(self, fastapi_app: FastAPI) -> None:
        client = TestClient(fastapi_app)
        start = time.monotonic()
        resp = client.post("/webhook", json={"test": "non-blocking"})
        elapsed = time.monotonic() - start
        assert elapsed < 2.0
        data = resp.json()
        assert data["received"] is True

    def test_failure_never_crashes_handler(self) -> None:
        """Capture failure should not affect the handler response."""
        from ncheta.middleware._fastapi import create_fastapi_middleware

        bad_client = RelayClient(1)
        app = FastAPI()

        middleware_fn = create_fastapi_middleware(bad_client, {
            "endpoint_name": "bad",
            "target_url": "http://localhost:9999",
        })
        app.middleware("http")(middleware_fn)

        @app.post("/test")
        async def test_handler(request: Request):
            return JSONResponse({"handler": "ok"})

        client = TestClient(app)
        resp = client.post("/test", json={"test": "failure"})
        assert resp.status_code == 200
        data = resp.json()
        assert data["handler"] == "ok"
