"""Tests for binary resolution."""
from __future__ import annotations

import os
from pathlib import Path
from unittest import mock

from ncheta._binary import resolve_binary_path


class TestResolveBinaryPath:
    def test_dev_mode_returns_debug_binary(self) -> None:
        """In dev mode, should resolve to core/target/debug/ncheta."""
        path = resolve_binary_path()
        assert path.endswith("core/target/debug/ncheta")
        assert os.path.isfile(path)

    def test_dev_mode_missing_binary_raises(self) -> None:
        """If dev binary doesn't exist, should raise FileNotFoundError."""
        # Point __file__ to a fake location so binary can't be found
        fake_file = "/tmp/fake_ncheta_pkg/_binary.py"
        with mock.patch("ncheta._binary.__file__", fake_file):
            with mock.patch.dict(os.environ, {"NCHETA_DEV": "true"}):
                try:
                    resolve_binary_path()
                    assert False, "Expected FileNotFoundError"
                except FileNotFoundError as exc:
                    assert "NCHETA_DEV=true but binary not found" in str(exc)

    def test_production_mode_missing_binary_raises(self) -> None:
        """Without NCHETA_DEV, should raise FileNotFoundError for missing bin/ncheta."""
        with mock.patch.dict(os.environ, {}, clear=False):
            os.environ.pop("NCHETA_DEV", None)
            try:
                resolve_binary_path()
                # If it doesn't raise, the file happens to exist (unlikely)
            except FileNotFoundError as exc:
                assert "Binary not found" in str(exc)
            finally:
                os.environ["NCHETA_DEV"] = "true"
