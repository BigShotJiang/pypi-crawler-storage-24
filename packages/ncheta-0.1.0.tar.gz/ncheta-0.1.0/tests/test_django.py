"""Tests for Django middleware."""
from __future__ import annotations

import json
import os
import time

import pytest

# Configure Django settings before importing anything else
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "tests.django_settings")

django = pytest.importorskip("django")

# Minimal Django settings as a module
import types
import sys

django_settings = types.ModuleType("tests.django_settings")
django_settings.SECRET_KEY = "test-secret-key"
django_settings.DEBUG = True
django_settings.ROOT_URLCONF = "tests.django_urls"
django_settings.ALLOWED_HOSTS = ["*"]
django_settings.MIDDLEWARE = []
django_settings.INSTALLED_APPS = ["django.contrib.contenttypes"]
django_settings.DATABASES = {"default": {"ENGINE": "django.db.backends.sqlite3", "NAME": ":memory:"}}
sys.modules["tests.django_settings"] = django_settings

django.setup()

from django.http import JsonResponse, HttpRequest
from django.test import RequestFactory
from django.urls import path

from ncheta import Ncheta, RelayClient
from tests.conftest import cleanup_db, random_port, temp_db_url


@pytest.fixture(scope="module")
def ncheta_django():
    """Start a ncheta instance for Django tests."""
    db_url = temp_db_url("django")
    ncheta = Ncheta(
        control_port=random_port(),
        ingestion_port=random_port(),
        db_url=db_url,
        start_timeout=15.0,
    )
    ncheta.start()
    ncheta.client.create_endpoint(
        "django-test", "http://127.0.0.1:8000/webhook"
    )
    yield ncheta
    ncheta.stop()
    cleanup_db(db_url)


class TestDjangoMiddleware:
    def _make_middleware_and_handler(self, ncheta_instance: Ncheta):
        """Create the Django middleware wrapping a simple view."""
        MiddlewareCls = ncheta_instance.watch_django({
            "endpoint_name": "django-test",
            "target_url": "http://127.0.0.1:8000/webhook",
        })

        def view(request: HttpRequest) -> JsonResponse:
            body = json.loads(request.body) if request.body else {}
            return JsonResponse({"received": True, "echo": body})

        middleware = MiddlewareCls(view)
        return middleware

    def test_captures_request_body(self, ncheta_django: Ncheta) -> None:
        middleware = self._make_middleware_and_handler(ncheta_django)
        factory = RequestFactory()

        body = {"type": "invoice.paid", "data": {"amount": 5000}}
        request = factory.post(
            "/webhook",
            data=json.dumps(body),
            content_type="application/json",
        )
        resp = middleware(request)
        assert resp.status_code == 200

        time.sleep(0.5)

        events = ncheta_django.events()
        assert len(events) > 0
        full_event = ncheta_django.client.event(events[0]["id"])
        assert full_event.get("request_body") is not None
        parsed = json.loads(full_event["request_body"])
        assert parsed["type"] == "invoice.paid"

    def test_captures_response_status(self, ncheta_django: Ncheta) -> None:
        middleware = self._make_middleware_and_handler(ncheta_django)
        factory = RequestFactory()

        request = factory.post(
            "/webhook",
            data=json.dumps({"test": "status"}),
            content_type="application/json",
        )
        resp = middleware(request)
        assert resp.status_code == 200

        time.sleep(0.5)

        events = ncheta_django.events()
        full_event = ncheta_django.client.event(events[0]["id"])
        assert full_event.get("response_status") == 200

    def test_captures_response_body(self, ncheta_django: Ncheta) -> None:
        middleware = self._make_middleware_and_handler(ncheta_django)
        factory = RequestFactory()

        request = factory.post(
            "/webhook",
            data=json.dumps({"test": "response-body"}),
            content_type="application/json",
        )
        resp = middleware(request)

        time.sleep(0.5)

        events = ncheta_django.events()
        full_event = ncheta_django.client.event(events[0]["id"])
        assert full_event.get("response_body") is not None
        parsed = json.loads(full_event["response_body"])
        assert parsed["received"] is True

    def test_does_not_block_response(self, ncheta_django: Ncheta) -> None:
        middleware = self._make_middleware_and_handler(ncheta_django)
        factory = RequestFactory()

        request = factory.post(
            "/webhook",
            data=json.dumps({"test": "non-blocking"}),
            content_type="application/json",
        )
        start = time.monotonic()
        resp = middleware(request)
        elapsed = time.monotonic() - start
        assert elapsed < 2.0
        data = json.loads(resp.content)
        assert data["received"] is True

    def test_failure_never_crashes_handler(self) -> None:
        """Capture failure should not affect the handler response."""
        from ncheta.middleware._django import create_django_middleware

        bad_client = RelayClient(1)
        MiddlewareCls = create_django_middleware(bad_client, {
            "endpoint_name": "bad",
            "target_url": "http://localhost:9999",
        })

        def view(request: HttpRequest) -> JsonResponse:
            return JsonResponse({"handler": "ok"})

        middleware = MiddlewareCls(view)
        factory = RequestFactory()
        request = factory.post(
            "/test",
            data=json.dumps({"test": "failure"}),
            content_type="application/json",
        )
        resp = middleware(request)
        assert resp.status_code == 200
        data = json.loads(resp.content)
        assert data["handler"] == "ok"
