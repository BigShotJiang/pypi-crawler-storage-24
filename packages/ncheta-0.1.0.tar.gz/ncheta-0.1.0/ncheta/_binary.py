"""Binary resolution and lifecycle management for the ncheta process."""
from __future__ import annotations

import os
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


@dataclass
class BinaryOptions:
    """Options for spawning the ncheta binary."""
    ingestion_port: Optional[int] = None
    control_port: Optional[int] = None
    db_url: Optional[str] = None


def resolve_binary_path() -> str:
    """Resolve the path to the ncheta binary.

    When NCHETA_DEV=true, looks for the local debug binary at
    ../../core/target/debug/ncheta (relative to this package).
    Otherwise, looks for a downloaded binary in the package directory.
    """
    if os.environ.get("NCHETA_DEV") == "true":
        package_dir = Path(__file__).resolve().parent
        dev_path = package_dir.parent.parent.parent / "core" / "target" / "debug" / "ncheta"
        if not dev_path.exists():
            raise FileNotFoundError(
                f"[Ncheta] NCHETA_DEV=true but binary not found at {dev_path}. "
                f"Run 'cargo build' in core/ first."
            )
        return str(dev_path)

    package_dir = Path(__file__).resolve().parent
    bin_path = package_dir.parent / "bin" / "ncheta"
    if not bin_path.exists():
        raise FileNotFoundError(
            f"[Ncheta] Binary not found at {bin_path}. "
            f"Set NCHETA_DEV=true for local development."
        )
    return str(bin_path)


def spawn_binary(options: BinaryOptions) -> subprocess.Popen:
    """Spawn the ncheta binary as a subprocess.

    Returns the Popen handle for lifecycle management.
    """
    bin_path = resolve_binary_path()

    env = os.environ.copy()
    if options.ingestion_port is not None:
        env["NCHETA_INGESTION_PORT"] = str(options.ingestion_port)
    if options.control_port is not None:
        env["NCHETA_CONTROL_PORT"] = str(options.control_port)
    if options.db_url is not None:
        env["NCHETA_DB_URL"] = options.db_url

    return subprocess.Popen(
        [bin_path],
        env=env,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
