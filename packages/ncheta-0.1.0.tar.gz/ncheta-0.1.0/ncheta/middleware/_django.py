"""Django middleware for Ncheta — captures request/response data."""
from __future__ import annotations

import sys
import threading
import time
from typing import Any, Callable, Dict, Type

from ncheta._client import RelayClient
from ncheta._types import WatchOptions


def create_django_middleware(
    client: RelayClient, options: WatchOptions
) -> Type:
    """Return a Django middleware class that captures request/response data.

    The capture is fire-and-forget: it never blocks the response
    and never throws or crashes the handler.
    """

    class NchetaMiddleware:
        def __init__(self, get_response: Callable) -> None:
            self.get_response = get_response

        def __call__(self, request: Any) -> Any:
            start_time = time.monotonic()

            # Capture request data
            method = request.method
            path = request.get_full_path()

            # Convert Django META headers (HTTP_X_FOO → X-Foo)
            request_headers: Dict[str, str] = {}
            for key, value in request.META.items():
                if key.startswith("HTTP_"):
                    header_name = key[5:].replace("_", "-").title()
                    request_headers[header_name] = value
                elif key == "CONTENT_TYPE":
                    request_headers["Content-Type"] = value
                elif key == "CONTENT_LENGTH":
                    request_headers["Content-Length"] = value

            try:
                request_body = request.body.decode("utf-8")
            except Exception:
                request_body = ""

            # Call the next middleware / view
            response = self.get_response(request)

            # Capture response data
            response_status = response.status_code
            try:
                response_body = response.content.decode("utf-8")
            except Exception:
                response_body = ""

            duration_ms = int((time.monotonic() - start_time) * 1000)

            # Fire-and-forget capture in daemon thread
            def _capture() -> None:
                try:
                    client.capture_event({
                        "endpoint_name": options["endpoint_name"],
                        "target_url": options["target_url"],
                        "method": method,
                        "path": path,
                        "request_headers": request_headers,
                        "request_body": request_body,
                        "response_status": response_status,
                        "response_body": response_body,
                        "duration_ms": duration_ms,
                    })
                except Exception as exc:
                    print(f"[Ncheta] capture failed: {exc}", file=sys.stderr)

            threading.Thread(target=_capture, daemon=True).start()

            return response

    return NchetaMiddleware
