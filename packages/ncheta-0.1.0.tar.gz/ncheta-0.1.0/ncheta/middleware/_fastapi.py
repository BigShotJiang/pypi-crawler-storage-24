"""FastAPI/Starlette middleware for Ncheta — captures request/response data."""
from __future__ import annotations

import sys
import time
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Callable

from ncheta._client import RelayClient
from ncheta._types import WatchOptions

# Bounded thread pool for fire-and-forget captures
_executor = ThreadPoolExecutor(max_workers=4)


def create_fastapi_middleware(
    client: RelayClient, options: WatchOptions
) -> Callable:
    """Return an async middleware function for FastAPI/Starlette.

    Usage:
        app.middleware("http")(ncheta.watch_fastapi(options))

    The capture is fire-and-forget: it never blocks the response
    and never throws or crashes the handler.
    """

    async def middleware(request: Any, call_next: Callable) -> Any:
        from starlette.responses import Response

        start_time = time.monotonic()

        # Capture request data
        method = request.method
        path = str(request.url.path)
        if request.url.query:
            path += "?" + str(request.url.query)
        request_headers = dict(request.headers)

        try:
            request_body = (await request.body()).decode("utf-8")
        except Exception:
            request_body = ""

        # Call the next middleware / route handler
        response = await call_next(request)

        # Read response body by consuming body_iterator
        response_body_chunks = []
        async for chunk in response.body_iterator:
            if isinstance(chunk, bytes):
                response_body_chunks.append(chunk)
            else:
                response_body_chunks.append(chunk.encode("utf-8"))

        response_body_bytes = b"".join(response_body_chunks)
        response_body = response_body_bytes.decode("utf-8", errors="replace")
        response_status = response.status_code

        duration_ms = int((time.monotonic() - start_time) * 1000)

        # Reconstruct response with the consumed body
        new_response = Response(
            content=response_body_bytes,
            status_code=response_status,
            headers=dict(response.headers),
            media_type=response.media_type,
        )

        # Fire-and-forget capture via thread pool
        def _capture() -> None:
            try:
                client.capture_event({
                    "endpoint_name": options["endpoint_name"],
                    "target_url": options["target_url"],
                    "method": method,
                    "path": path,
                    "request_headers": request_headers,
                    "request_body": request_body,
                    "response_status": response_status,
                    "response_body": response_body,
                    "duration_ms": duration_ms,
                })
            except Exception as exc:
                print(f"[Ncheta] capture failed: {exc}", file=sys.stderr)

        _executor.submit(_capture)

        return new_response

    return middleware
