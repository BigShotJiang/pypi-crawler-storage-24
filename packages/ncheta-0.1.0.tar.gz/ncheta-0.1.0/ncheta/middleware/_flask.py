"""Flask middleware for Ncheta — captures request/response data via decorator."""
from __future__ import annotations

import functools
import sys
import threading
import time
from typing import Any, Callable

from ncheta._client import RelayClient
from ncheta._types import WatchOptions


def create_flask_middleware(
    client: RelayClient, options: WatchOptions
) -> Callable:
    """Return a decorator that wraps a Flask view to capture request/response data.

    The capture is fire-and-forget: it never blocks the response
    and never throws or crashes the handler.
    """

    def decorator(fn: Callable) -> Callable:
        @functools.wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            from flask import request as flask_request

            start_time = time.monotonic()

            # Capture request data
            method = flask_request.method
            path = flask_request.full_path.rstrip("?") if flask_request.query_string else flask_request.path
            request_headers = dict(flask_request.headers)
            request_body = flask_request.get_data(as_text=True)

            # Call the original handler
            response = fn(*args, **kwargs)

            # Capture response data
            from flask import make_response as flask_make_response
            if not hasattr(response, "status_code"):
                response = flask_make_response(response)

            response_status = response.status_code
            response_body = response.get_data(as_text=True)
            duration_ms = int((time.monotonic() - start_time) * 1000)

            # Fire-and-forget capture in daemon thread
            def _capture() -> None:
                try:
                    client.capture_event({
                        "endpoint_name": options["endpoint_name"],
                        "target_url": options["target_url"],
                        "method": method,
                        "path": path,
                        "request_headers": request_headers,
                        "request_body": request_body,
                        "response_status": response_status,
                        "response_body": response_body,
                        "duration_ms": duration_ms,
                    })
                except Exception as exc:
                    print(f"[Ncheta] capture failed: {exc}", file=sys.stderr)

            threading.Thread(target=_capture, daemon=True).start()

            return response

        return wrapper

    return decorator
