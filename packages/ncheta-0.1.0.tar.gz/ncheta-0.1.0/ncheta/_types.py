"""Type definitions for Ncheta SDK."""
from __future__ import annotations

from typing import Dict, List, Optional
from typing_extensions import TypedDict


class Endpoint(TypedDict):
    id: str
    name: str
    target_url: str
    created_at: str


class EventSummary(TypedDict):
    id: str
    endpoint_id: str
    method: str
    path: str
    status: str
    attempt_count: int
    received_at: str


class DeliveryAttempt(TypedDict):
    id: str
    event_id: str
    attempt_number: int
    status_code: Optional[int]
    success: bool
    error: Optional[str]
    attempted_at: str


class CapturePayload(TypedDict, total=False):
    endpoint_name: str
    target_url: str
    method: str
    path: str
    request_headers: Dict[str, str]
    request_body: str
    response_status: int
    response_body: str
    duration_ms: int


class HealthResponse(TypedDict):
    status: str
    version: str


class ReplayResponse(TypedDict):
    replaying: bool
    event_id: str


class CaptureResponse(TypedDict):
    event_id: str


class WatchOptions(TypedDict):
    endpoint_name: str
    target_url: str
