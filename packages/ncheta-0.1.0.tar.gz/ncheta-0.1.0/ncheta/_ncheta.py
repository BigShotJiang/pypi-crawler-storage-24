"""Main Ncheta SDK class — manages binary lifecycle and provides API access."""
from __future__ import annotations

import subprocess
import threading
import time
from typing import Any, Callable, Dict, List, Optional

from ncheta._binary import BinaryOptions, spawn_binary
from ncheta._client import RelayClient
from ncheta._types import EventSummary, ReplayResponse, WatchOptions


class Ncheta:
    """Main Ncheta SDK class.

    Manages the lifecycle of the ncheta binary and provides
    access to the control API and framework middleware.
    """

    def __init__(
        self,
        *,
        control_port: int = 7001,
        ingestion_port: int = 7000,
        db_url: Optional[str] = None,
        start_timeout: float = 10.0,
    ) -> None:
        self.control_port = control_port
        self.ingestion_port = ingestion_port
        self.start_timeout = start_timeout
        self._options = BinaryOptions(
            ingestion_port=ingestion_port,
            control_port=control_port,
            db_url=db_url,
        )
        self.client = RelayClient(control_port)
        self._process: Optional[subprocess.Popen] = None
        self._stderr_output = ""

    def start(self) -> None:
        """Start the ncheta binary and wait for it to be ready.

        Polls GET /health every 100ms until a 200 response is received,
        or times out after start_timeout seconds.
        """
        self._process = spawn_binary(self._options)
        self._stderr_output = ""

        # Collect stderr in a daemon thread
        def _read_stderr() -> None:
            assert self._process is not None
            assert self._process.stderr is not None
            for line in self._process.stderr:
                self._stderr_output += line.decode("utf-8", errors="replace")

        stderr_thread = threading.Thread(target=_read_stderr, daemon=True)
        stderr_thread.start()

        # Poll /health until ready
        deadline = time.monotonic() + self.start_timeout
        while time.monotonic() < deadline:
            # Check for early exit
            if self._process.poll() is not None:
                raise RuntimeError(
                    f"[Ncheta] Binary exited with code {self._process.returncode} "
                    f"during startup.\nstderr: {self._stderr_output}"
                )
            try:
                result = self.client.health()
                if result.get("status") == "ok":
                    return
            except Exception:
                pass
            time.sleep(0.1)

        raise TimeoutError(
            f"[Ncheta] Binary did not become ready within {self.start_timeout}s.\n"
            f"stderr: {self._stderr_output}"
        )

    def stop(self) -> None:
        """Stop the ncheta binary.

        Sends SIGTERM and waits for the process to exit.
        Falls back to SIGKILL after 5 seconds.
        """
        if self._process is None:
            return

        proc = self._process
        self._process = None

        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait(timeout=5)

    def watch_flask(self, options: WatchOptions) -> Callable:
        """Create Flask decorator middleware that captures request/response data."""
        from ncheta.middleware._flask import create_flask_middleware
        return create_flask_middleware(self.client, options)

    def watch_django(self, options: WatchOptions) -> type:
        """Create Django middleware class that captures request/response data."""
        from ncheta.middleware._django import create_django_middleware
        return create_django_middleware(self.client, options)

    def watch_fastapi(self, options: WatchOptions) -> Callable:
        """Create FastAPI middleware function that captures request/response data."""
        from ncheta.middleware._fastapi import create_fastapi_middleware
        return create_fastapi_middleware(self.client, options)

    def events(
        self,
        *,
        status: Optional[str] = None,
        endpoint_id: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> List[EventSummary]:
        """List events from the control API."""
        return self.client.events(status=status, endpoint_id=endpoint_id, limit=limit)

    def replay(self, event_id: str) -> ReplayResponse:
        """Replay an event by ID."""
        return self.client.replay(event_id)
