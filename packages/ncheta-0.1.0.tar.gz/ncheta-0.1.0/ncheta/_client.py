"""HTTP client for the Ncheta control API.

All methods use Python's built-in urllib.request (no external dependencies).
"""
from __future__ import annotations

import json
import urllib.request
import urllib.error
import urllib.parse
from typing import Any, Dict, List, Optional

from ncheta._types import (
    CapturePayload,
    CaptureResponse,
    DeliveryAttempt,
    Endpoint,
    EventSummary,
    HealthResponse,
    ReplayResponse,
)


class RelayClient:
    """Synchronous HTTP client for the Ncheta control API."""

    def __init__(self, control_port: int) -> None:
        self._base_url = f"http://127.0.0.1:{control_port}"

    def health(self) -> HealthResponse:
        """GET /health — check if the binary is ready."""
        return self._get("/health")

    def endpoints(self) -> List[Endpoint]:
        """GET /endpoints — list all endpoints."""
        return self._get("/endpoints")

    def create_endpoint(
        self, name: str, target_url: str, secret: Optional[str] = None
    ) -> Endpoint:
        """POST /endpoints — create a new endpoint."""
        body: Dict[str, str] = {"name": name, "target_url": target_url}
        if secret is not None:
            body["secret"] = secret
        return self._post("/endpoints", body)

    def events(
        self,
        *,
        status: Optional[str] = None,
        endpoint_id: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> List[EventSummary]:
        """GET /events — list events with optional filters."""
        params: Dict[str, str] = {}
        if status is not None:
            params["status"] = status
        if endpoint_id is not None:
            params["endpoint_id"] = endpoint_id
        if limit is not None:
            params["limit"] = str(limit)
        path = "/events"
        if params:
            path += "?" + urllib.parse.urlencode(params)
        return self._get(path)

    def event(self, event_id: str) -> Dict[str, Any]:
        """GET /events/:id — get a single event with full detail."""
        return self._get(f"/events/{event_id}")

    def attempts(self, event_id: str) -> List[DeliveryAttempt]:
        """GET /events/:id/attempts — get delivery attempts for an event."""
        return self._get(f"/events/{event_id}/attempts")

    def replay(self, event_id: str) -> ReplayResponse:
        """POST /events/:id/replay — replay an event."""
        return self._post(f"/events/{event_id}/replay", {})

    def capture_event(self, payload: CapturePayload) -> CaptureResponse:
        """POST /events/capture — capture an event from SDK middleware."""
        return self._post("/events/capture", payload)

    def _get(self, path: str) -> Any:
        url = self._base_url + path
        req = urllib.request.Request(url, method="GET")
        with urllib.request.urlopen(req, timeout=5) as resp:
            return json.loads(resp.read().decode("utf-8"))

    def _post(self, path: str, body: Any) -> Any:
        url = self._base_url + path
        data = json.dumps(body).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=data,
            method="POST",
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            return json.loads(resp.read().decode("utf-8"))
