"""
AsterPay client — sync and async HTTP clients for the AsterPay x402 API.
"""

from __future__ import annotations

import httpx

from asterpay.services.market import MarketService, AsyncMarketService
from asterpay.services.ai import AIService, AsyncAIService
from asterpay.services.crypto import CryptoService, AsyncCryptoService
from asterpay.services.utility import UtilityService, AsyncUtilityService
from asterpay.services.settlement import SettlementService, AsyncSettlementService
from asterpay.services.discovery import DiscoveryService, AsyncDiscoveryService
from asterpay.services.kya import KYAService, AsyncKYAService


DEFAULT_BASE_URL = "https://x402-api-production-ba87.up.railway.app"


class AsterPay:
    """
    Synchronous AsterPay client.

    Usage:
        from asterpay import AsterPay

        client = AsterPay()
        price = client.market.price("bitcoin")
        quote = client.settlement.estimate(100)
    """

    def __init__(
        self,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
    ):
        """
        Initialize AsterPay client.

        Args:
            base_url: API base URL (default: production Railway)
            timeout: Request timeout in seconds
        """
        self.base_url = base_url.rstrip("/")
        self._http = httpx.Client(
            base_url=self.base_url,
            timeout=timeout,
            headers=self._build_headers(),
        )

        # Services
        self.market = MarketService(self._http)
        self.ai = AIService(self._http)
        self.crypto = CryptoService(self._http)
        self.utility = UtilityService(self._http)
        self.settlement = SettlementService(self._http)
        self.discovery = DiscoveryService(self._http)
        self.kya = KYAService(self._http)

    def _build_headers(self) -> dict:
        return {
            "User-Agent": "asterpay-python/0.1.0",
            "Accept": "application/json",
        }

    def health(self) -> dict:
        """Check API health status."""
        resp = self._http.get("/health")
        resp.raise_for_status()
        return resp.json()

    def info(self) -> dict:
        """Get API info and version."""
        resp = self._http.get("/")
        resp.raise_for_status()
        return resp.json()

    def close(self):
        """Close the HTTP client."""
        self._http.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def __repr__(self):
        return f"AsterPay(base_url='{self.base_url}')"


class AsyncAsterPay:
    """
    Asynchronous AsterPay client.

    Usage:
        from asterpay import AsyncAsterPay

        async with AsyncAsterPay() as client:
            price = await client.market.price("bitcoin")
    """

    def __init__(
        self,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
    ):
        self.base_url = base_url.rstrip("/")
        self._http = httpx.AsyncClient(
            base_url=self.base_url,
            timeout=timeout,
            headers=self._build_headers(),
        )

        # Services
        self.market = AsyncMarketService(self._http)
        self.ai = AsyncAIService(self._http)
        self.crypto = AsyncCryptoService(self._http)
        self.utility = AsyncUtilityService(self._http)
        self.settlement = AsyncSettlementService(self._http)
        self.discovery = AsyncDiscoveryService(self._http)
        self.kya = AsyncKYAService(self._http)

    def _build_headers(self) -> dict:
        return {
            "User-Agent": "asterpay-python/0.1.0",
            "Accept": "application/json",
        }

    async def health(self) -> dict:
        resp = await self._http.get("/health")
        resp.raise_for_status()
        return resp.json()

    async def info(self) -> dict:
        resp = await self._http.get("/")
        resp.raise_for_status()
        return resp.json()

    async def close(self):
        await self._http.aclose()

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.close()

    def __repr__(self):
        return f"AsyncAsterPay(base_url='{self.base_url}')"
