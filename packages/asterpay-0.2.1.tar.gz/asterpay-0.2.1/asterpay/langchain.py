"""
AsterPay LangChain Tools — EUR settlement for AI agent commerce.

Usage:
    from asterpay.langchain import get_asterpay_tools

    tools = get_asterpay_tools()
    agent = create_react_agent(llm, tools)

Or pick individual tools:
    from asterpay.langchain import AsterPayPriceTool, AsterPaySettlementEstimateTool
"""

from __future__ import annotations

import json
from typing import Optional, Type

try:
    from langchain_core.tools import BaseTool
    from pydantic import BaseModel, Field
except ImportError:
    raise ImportError(
        "LangChain integration requires langchain-core. "
        "Install with: pip install asterpay[langchain]"
    )

from asterpay.client import AsterPay


# ─── Input Schemas ───────────────────────────────────────────────

class PriceInput(BaseModel):
    symbol: str = Field(description="Cryptocurrency symbol, e.g. 'bitcoin', 'ethereum', 'solana'")


class OHLCVInput(BaseModel):
    symbol: str = Field(description="Cryptocurrency symbol, e.g. 'bitcoin'")
    days: int = Field(default=7, description="Number of days of OHLCV data (1-365)")


class SummarizeInput(BaseModel):
    text: str = Field(description="Text to summarize")
    max_length: Optional[int] = Field(default=None, description="Maximum summary length")


class SentimentInput(BaseModel):
    text: str = Field(description="Text to analyze sentiment for")


class TranslateInput(BaseModel):
    text: str = Field(description="Text to translate")
    target_language: str = Field(description="Target language code, e.g. 'fi', 'de', 'fr', 'es'")


class WalletScoreInput(BaseModel):
    address: str = Field(description="Blockchain wallet address to score")


class TokenAnalysisInput(BaseModel):
    address: str = Field(description="Token contract address to analyze")


class SettlementEstimateInput(BaseModel):
    amount_usdc: float = Field(description="Amount in USDC to settle to EUR")


class SettlementQuoteInput(BaseModel):
    amount_usdc: float = Field(description="Amount in USDC to get a settlement quote for")
    iban: Optional[str] = Field(default=None, description="IBAN for EUR settlement")


class TransferStatusInput(BaseModel):
    transfer_id: str = Field(description="Transfer ID to check status for")


# ─── KYA (Know Your Agent) Inputs ─────────────────────────────────

class TrustScoreInput(BaseModel):
    address: str = Field(description="Ethereum address of the agent or wallet to get trust score for (0-100)")


class VerifyAgentInput(BaseModel):
    address: str = Field(description="Ethereum address to verify as registered agent (ERC-8004)")


class AgentTierInput(BaseModel):
    address: str = Field(description="Ethereum address to get agent tier (Open/Verified/Trusted/Enterprise)")


class DeepAnalysisInput(BaseModel):
    address: str = Field(description="Ethereum address for deep behavioral trust analysis. Costs $0.01 USDC via x402.")


class CodeReviewInput(BaseModel):
    code: str = Field(description="Source code to review")
    language: str = Field(default="auto", description="Programming language")


class QRCodeInput(BaseModel):
    data: str = Field(description="Data to encode in QR code")
    size: int = Field(default=256, description="QR code size in pixels")


class ScreenshotInput(BaseModel):
    url: str = Field(description="URL to take a screenshot of")


# ─── Helper ──────────────────────────────────────────────────────

def _format(result: dict) -> str:
    """Format API response as readable string for the LLM."""
    return json.dumps(result, indent=2, default=str)


def _handle_402(e: Exception) -> str:
    """Handle x402 Payment Required errors gracefully."""
    return (
        f"This endpoint requires x402 USDC payment: {e}. "
        "The agent needs a funded USDC wallet on Base to call paid endpoints. "
        "Free endpoints: health, discovery, settlement estimate."
    )


# ─── KYA (Know Your Agent) Tools ──────────────────────────────────

class AsterPayKYATrustScoreTool(BaseTool):
    name: str = "asterpay_check_agent_trust"
    description: str = (
        "Check if an AI agent or wallet is trustworthy before paying or transacting. "
        "Returns a trust score 0-100, tier (Open/Verified/Trusted/Enterprise), and components (ERC-8004, sanctions, etc.). "
        "Use this when you need to verify another agent's identity and risk level. Input: Ethereum address. FREE."
    )
    args_schema: Type[BaseModel] = TrustScoreInput
    _client: AsterPay = None

    def __init__(self, client: Optional[AsterPay] = None, **kwargs):
        super().__init__(**kwargs)
        object.__setattr__(self, "_client", client or AsterPay())

    def _run(self, address: str) -> str:
        try:
            return _format(self._client.kya.trust_score(address))
        except Exception as e:
            return f"Error: {e}"


class AsterPayKYAVerifyTool(BaseTool):
    name: str = "asterpay_verify_agent_identity"
    description: str = (
        "Verify whether an Ethereum address is registered as an AI agent (ERC-8004 on Base). "
        "Returns verified true/false, agentId, owner, metadataUri. Use before trusting an unknown agent. FREE."
    )
    args_schema: Type[BaseModel] = VerifyAgentInput
    _client: AsterPay = None

    def __init__(self, client: Optional[AsterPay] = None, **kwargs):
        super().__init__(**kwargs)
        object.__setattr__(self, "_client", client or AsterPay())

    def _run(self, address: str) -> str:
        try:
            return _format(self._client.kya.verify(address))
        except Exception as e:
            return f"Error: {e}"


class AsterPayKYATierTool(BaseTool):
    name: str = "asterpay_get_agent_tier"
    description: str = (
        "Get the trust tier and spending limit for an agent address (Open, Verified, Trusted, Enterprise). "
        "Use to know max per-transaction limit when paying an agent. Input: Ethereum address. FREE."
    )
    args_schema: Type[BaseModel] = AgentTierInput
    _client: AsterPay = None

    def __init__(self, client: Optional[AsterPay] = None, **kwargs):
        super().__init__(**kwargs)
        object.__setattr__(self, "_client", client or AsterPay())

    def _run(self, address: str) -> str:
        try:
            return _format(self._client.kya.tier(address))
        except Exception as e:
            return f"Error: {e}"


class AsterPayKYADeepAnalysisTool(BaseTool):
    name: str = "asterpay_agent_deep_analysis"
    description: str = (
        "Deep behavioral trust analysis for an agent address — velocity, signals, recommendation. "
        "Use when you need detailed risk intelligence before a large transaction. Input: Ethereum address. Costs $0.01 USDC via x402."
    )
    args_schema: Type[BaseModel] = DeepAnalysisInput
    _client: AsterPay = None

    def __init__(self, client: Optional[AsterPay] = None, **kwargs):
        super().__init__(**kwargs)
        object.__setattr__(self, "_client", client or AsterPay())

    def _run(self, address: str) -> str:
        try:
            return _format(self._client.kya.deep_analysis(address))
        except Exception as e:
            if "402" in str(e):
                return _handle_402(e)
            return f"Error: {e}"


# ─── Market Tools ────────────────────────────────────────────────

class AsterPayPriceTool(BaseTool):
    name: str = "asterpay_crypto_price"
    description: str = (
        "Get the current price of a cryptocurrency. "
        "Input: symbol like 'bitcoin', 'ethereum', 'solana'. "
        "Returns price in USD and market data. Requires x402 payment."
    )
    args_schema: Type[BaseModel] = PriceInput
    _client: AsterPay = None

    def __init__(self, client: Optional[AsterPay] = None, **kwargs):
        super().__init__(**kwargs)
        object.__setattr__(self, "_client", client or AsterPay())

    def _run(self, symbol: str) -> str:
        try:
            return _format(self._client.market.price(symbol))
        except Exception as e:
            if "402" in str(e):
                return _handle_402(e)
            return f"Error: {e}"


class AsterPayOHLCVTool(BaseTool):
    name: str = "asterpay_crypto_ohlcv"
    description: str = (
        "Get OHLCV (Open, High, Low, Close, Volume) chart data for a cryptocurrency. "
        "Input: symbol and days. Returns historical price data. Requires x402 payment."
    )
    args_schema: Type[BaseModel] = OHLCVInput
    _client: AsterPay = None

    def __init__(self, client: Optional[AsterPay] = None, **kwargs):
        super().__init__(**kwargs)
        object.__setattr__(self, "_client", client or AsterPay())

    def _run(self, symbol: str, days: int = 7) -> str:
        try:
            return _format(self._client.market.ohlcv(symbol, days))
        except Exception as e:
            if "402" in str(e):
                return _handle_402(e)
            return f"Error: {e}"


class AsterPayTrendingTool(BaseTool):
    name: str = "asterpay_trending_tokens"
    description: str = (
        "Get currently trending cryptocurrencies. "
        "No input required. Returns trending tokens list. Requires x402 payment."
    )
    _client: AsterPay = None

    def __init__(self, client: Optional[AsterPay] = None, **kwargs):
        super().__init__(**kwargs)
        object.__setattr__(self, "_client", client or AsterPay())

    def _run(self, query: str = "") -> str:
        try:
            return _format(self._client.market.trending())
        except Exception as e:
            if "402" in str(e):
                return _handle_402(e)
            return f"Error: {e}"


# ─── AI Tools ────────────────────────────────────────────────────

class AsterPaySummarizeTool(BaseTool):
    name: str = "asterpay_summarize"
    description: str = (
        "Summarize a long text into a shorter version. "
        "Input: text and optional max_length. Requires x402 payment."
    )
    args_schema: Type[BaseModel] = SummarizeInput
    _client: AsterPay = None

    def __init__(self, client: Optional[AsterPay] = None, **kwargs):
        super().__init__(**kwargs)
        object.__setattr__(self, "_client", client or AsterPay())

    def _run(self, text: str, max_length: Optional[int] = None) -> str:
        try:
            return _format(self._client.ai.summarize(text, max_length))
        except Exception as e:
            if "402" in str(e):
                return _handle_402(e)
            return f"Error: {e}"


class AsterPaySentimentTool(BaseTool):
    name: str = "asterpay_sentiment"
    description: str = (
        "Analyze the sentiment of text (positive, negative, neutral). "
        "Input: text to analyze. Requires x402 payment."
    )
    args_schema: Type[BaseModel] = SentimentInput
    _client: AsterPay = None

    def __init__(self, client: Optional[AsterPay] = None, **kwargs):
        super().__init__(**kwargs)
        object.__setattr__(self, "_client", client or AsterPay())

    def _run(self, text: str) -> str:
        try:
            return _format(self._client.ai.sentiment(text))
        except Exception as e:
            if "402" in str(e):
                return _handle_402(e)
            return f"Error: {e}"


class AsterPayTranslateTool(BaseTool):
    name: str = "asterpay_translate"
    description: str = (
        "Translate text to another language. "
        "Input: text and target_language code (e.g. 'fi', 'de', 'es'). Requires x402 payment."
    )
    args_schema: Type[BaseModel] = TranslateInput
    _client: AsterPay = None

    def __init__(self, client: Optional[AsterPay] = None, **kwargs):
        super().__init__(**kwargs)
        object.__setattr__(self, "_client", client or AsterPay())

    def _run(self, text: str, target_language: str) -> str:
        try:
            return _format(self._client.ai.translate(text, target_language))
        except Exception as e:
            if "402" in str(e):
                return _handle_402(e)
            return f"Error: {e}"


class AsterPayCodeReviewTool(BaseTool):
    name: str = "asterpay_code_review"
    description: str = (
        "Review source code for quality, bugs, and improvements. "
        "Input: code and optional language. Requires x402 payment."
    )
    args_schema: Type[BaseModel] = CodeReviewInput
    _client: AsterPay = None

    def __init__(self, client: Optional[AsterPay] = None, **kwargs):
        super().__init__(**kwargs)
        object.__setattr__(self, "_client", client or AsterPay())

    def _run(self, code: str, language: str = "auto") -> str:
        try:
            return _format(self._client.ai.code_review(code, language))
        except Exception as e:
            if "402" in str(e):
                return _handle_402(e)
            return f"Error: {e}"


# ─── Crypto Analytics Tools ─────────────────────────────────────

class AsterPayWalletScoreTool(BaseTool):
    name: str = "asterpay_wallet_score"
    description: str = (
        "Score a blockchain wallet for activity, risk, and reputation. "
        "Input: wallet address. Requires x402 payment."
    )
    args_schema: Type[BaseModel] = WalletScoreInput
    _client: AsterPay = None

    def __init__(self, client: Optional[AsterPay] = None, **kwargs):
        super().__init__(**kwargs)
        object.__setattr__(self, "_client", client or AsterPay())

    def _run(self, address: str) -> str:
        try:
            return _format(self._client.crypto.wallet_score(address))
        except Exception as e:
            if "402" in str(e):
                return _handle_402(e)
            return f"Error: {e}"


class AsterPayTokenAnalysisTool(BaseTool):
    name: str = "asterpay_token_analysis"
    description: str = (
        "Analyze a token contract for risk, liquidity, and holder distribution. "
        "Input: token contract address. Requires x402 payment."
    )
    args_schema: Type[BaseModel] = TokenAnalysisInput
    _client: AsterPay = None

    def __init__(self, client: Optional[AsterPay] = None, **kwargs):
        super().__init__(**kwargs)
        object.__setattr__(self, "_client", client or AsterPay())

    def _run(self, address: str) -> str:
        try:
            return _format(self._client.crypto.token_analysis(address))
        except Exception as e:
            if "402" in str(e):
                return _handle_402(e)
            return f"Error: {e}"


class AsterPayWhaleAlertsTool(BaseTool):
    name: str = "asterpay_whale_alerts"
    description: str = (
        "Get recent whale (large) crypto transactions. "
        "No input required. Requires x402 payment."
    )
    _client: AsterPay = None

    def __init__(self, client: Optional[AsterPay] = None, **kwargs):
        super().__init__(**kwargs)
        object.__setattr__(self, "_client", client or AsterPay())

    def _run(self, query: str = "") -> str:
        try:
            return _format(self._client.crypto.whale_alerts())
        except Exception as e:
            if "402" in str(e):
                return _handle_402(e)
            return f"Error: {e}"


# ─── Settlement Tools (EUR) ─────────────────────────────────────

class AsterPaySettlementEstimateTool(BaseTool):
    name: str = "asterpay_eur_settlement_estimate"
    description: str = (
        "Estimate USDC → EUR settlement amount via SEPA Instant. "
        "Input: amount_usdc. Returns estimated EUR amount, fees, and exchange rate. FREE endpoint."
    )
    args_schema: Type[BaseModel] = SettlementEstimateInput
    _client: AsterPay = None

    def __init__(self, client: Optional[AsterPay] = None, **kwargs):
        super().__init__(**kwargs)
        object.__setattr__(self, "_client", client or AsterPay())

    def _run(self, amount_usdc: float) -> str:
        try:
            return _format(self._client.settlement.estimate(amount_usdc))
        except Exception as e:
            return f"Error: {e}"


class AsterPaySettlementQuoteTool(BaseTool):
    name: str = "asterpay_eur_settlement_quote"
    description: str = (
        "Get a firm quote for USDC → EUR SEPA settlement. "
        "Input: amount_usdc and optional IBAN. Returns locked rate and settlement details."
    )
    args_schema: Type[BaseModel] = SettlementQuoteInput
    _client: AsterPay = None

    def __init__(self, client: Optional[AsterPay] = None, **kwargs):
        super().__init__(**kwargs)
        object.__setattr__(self, "_client", client or AsterPay())

    def _run(self, amount_usdc: float, iban: Optional[str] = None) -> str:
        try:
            return _format(self._client.settlement.quote(amount_usdc, iban))
        except Exception as e:
            return f"Error: {e}"


class AsterPayTransferStatusTool(BaseTool):
    name: str = "asterpay_transfer_status"
    description: str = (
        "Check the status of a EUR settlement transfer. "
        "Input: transfer_id. Returns current status and timeline."
    )
    args_schema: Type[BaseModel] = TransferStatusInput
    _client: AsterPay = None

    def __init__(self, client: Optional[AsterPay] = None, **kwargs):
        super().__init__(**kwargs)
        object.__setattr__(self, "_client", client or AsterPay())

    def _run(self, transfer_id: str) -> str:
        try:
            return _format(self._client.settlement.transfer_status(transfer_id))
        except Exception as e:
            return f"Error: {e}"


# ─── Discovery & Health Tools (FREE) ────────────────────────────

class AsterPayHealthTool(BaseTool):
    name: str = "asterpay_health"
    description: str = (
        "Check if AsterPay API is online and healthy. "
        "No input required. FREE endpoint."
    )
    _client: AsterPay = None

    def __init__(self, client: Optional[AsterPay] = None, **kwargs):
        super().__init__(**kwargs)
        object.__setattr__(self, "_client", client or AsterPay())

    def _run(self, query: str = "") -> str:
        try:
            return _format(self._client.health())
        except Exception as e:
            return f"Error: {e}"


class AsterPayDiscoveryTool(BaseTool):
    name: str = "asterpay_discover_endpoints"
    description: str = (
        "Discover all available AsterPay API endpoints with pricing and schemas. "
        "No input required. FREE endpoint."
    )
    _client: AsterPay = None

    def __init__(self, client: Optional[AsterPay] = None, **kwargs):
        super().__init__(**kwargs)
        object.__setattr__(self, "_client", client or AsterPay())

    def _run(self, query: str = "") -> str:
        try:
            return _format(self._client.discovery.resources())
        except Exception as e:
            return f"Error: {e}"


# ─── Utility Tools ──────────────────────────────────────────────

class AsterPayQRCodeTool(BaseTool):
    name: str = "asterpay_qr_code"
    description: str = (
        "Generate a QR code from data. "
        "Input: data string and optional size. Requires x402 payment."
    )
    args_schema: Type[BaseModel] = QRCodeInput
    _client: AsterPay = None

    def __init__(self, client: Optional[AsterPay] = None, **kwargs):
        super().__init__(**kwargs)
        object.__setattr__(self, "_client", client or AsterPay())

    def _run(self, data: str, size: int = 256) -> str:
        try:
            return _format(self._client.utility.qr_code(data, size))
        except Exception as e:
            if "402" in str(e):
                return _handle_402(e)
            return f"Error: {e}"


class AsterPayScreenshotTool(BaseTool):
    name: str = "asterpay_screenshot"
    description: str = (
        "Take a screenshot of a website. "
        "Input: URL to capture. Requires x402 payment."
    )
    args_schema: Type[BaseModel] = ScreenshotInput
    _client: AsterPay = None

    def __init__(self, client: Optional[AsterPay] = None, **kwargs):
        super().__init__(**kwargs)
        object.__setattr__(self, "_client", client or AsterPay())

    def _run(self, url: str) -> str:
        try:
            return _format(self._client.utility.screenshot(url))
        except Exception as e:
            if "402" in str(e):
                return _handle_402(e)
            return f"Error: {e}"


# ─── Tool Collection ────────────────────────────────────────────

KYA_TOOLS = [
    AsterPayKYATrustScoreTool,
    AsterPayKYAVerifyTool,
    AsterPayKYATierTool,
    AsterPayKYADeepAnalysisTool,
]

ALL_TOOLS = [
    # KYA (Know Your Agent) — agent trust verification, prioritized for discovery
    AsterPayKYATrustScoreTool,
    AsterPayKYAVerifyTool,
    AsterPayKYATierTool,
    AsterPayKYADeepAnalysisTool,
    # Free tools
    AsterPayHealthTool,
    AsterPayDiscoveryTool,
    # Settlement (EUR)
    AsterPaySettlementEstimateTool,
    AsterPaySettlementQuoteTool,
    AsterPayTransferStatusTool,
    # Market data
    AsterPayPriceTool,
    AsterPayOHLCVTool,
    AsterPayTrendingTool,
    # AI
    AsterPaySummarizeTool,
    AsterPaySentimentTool,
    AsterPayTranslateTool,
    AsterPayCodeReviewTool,
    # Crypto analytics
    AsterPayWalletScoreTool,
    AsterPayTokenAnalysisTool,
    AsterPayWhaleAlertsTool,
    # Utility
    AsterPayQRCodeTool,
    AsterPayScreenshotTool,
]


def get_asterpay_tools(client: Optional[AsterPay] = None) -> list[BaseTool]:
    """
    Get all AsterPay tools for use with LangChain agents.

    Usage:
        from asterpay.langchain import get_asterpay_tools
        tools = get_asterpay_tools()
        agent = create_react_agent(llm, tools)

    Args:
        client: Optional AsterPay client instance. If not provided, a default client is created.

    Returns:
        List of LangChain tools covering KYA, market data, AI, crypto analytics,
        EUR settlement, and utility services.
    """
    c = client or AsterPay()
    return [ToolClass(client=c) for ToolClass in ALL_TOOLS]


def get_free_tools(client: Optional[AsterPay] = None) -> list[BaseTool]:
    """Get only the free (no x402 payment required) AsterPay tools."""
    c = client or AsterPay()
    free_classes = [
        AsterPayHealthTool,
        AsterPayDiscoveryTool,
        AsterPaySettlementEstimateTool,
    ]
    return [ToolClass(client=c) for ToolClass in free_classes]


def get_asterpay_kya_tools(client: Optional[AsterPay] = None) -> list[BaseTool]:
    """
    Get only the KYA (Know Your Agent) tools for verifying agent trust.

    Use when your agent needs to check another agent's trust score, identity, or tier
    before paying or transacting.

    Usage:
        from asterpay.langchain import get_asterpay_kya_tools
        kya_tools = get_asterpay_kya_tools()
        agent = create_react_agent(llm, kya_tools + other_tools)

    Returns:
        List of 4 tools: check_agent_trust, verify_agent_identity, get_agent_tier, agent_deep_analysis.
    """
    c = client or AsterPay()
    return [ToolClass(client=c) for ToolClass in KYA_TOOLS]
