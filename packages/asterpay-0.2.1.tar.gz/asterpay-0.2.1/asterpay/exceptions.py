"""AsterPay custom exceptions."""

from __future__ import annotations
from typing import Optional


class AsterPayError(Exception):
    """Base exception for AsterPay SDK."""

    def __init__(self, message: str, status_code: Optional[int] = None, response: Optional[dict] = None):
        self.message = message
        self.status_code = status_code
        self.response = response
        super().__init__(self.message)


class PaymentRequiredError(AsterPayError):
    """
    HTTP 402 — x402 payment required.

    This endpoint requires USDC micropayment via x402 protocol.
    Use an x402-compatible wallet or agent framework to authorize payment.
    """

    def __init__(self, message: str = "Payment required", accepts: Optional[list] = None, **kwargs):
        self.accepts = accepts or []
        super().__init__(message, status_code=402, **kwargs)


class RateLimitError(AsterPayError):
    """HTTP 429 — rate limit exceeded."""

    def __init__(self, message: str = "Rate limit exceeded", retry_after: Optional[int] = None, **kwargs):
        self.retry_after = retry_after
        super().__init__(message, status_code=429, **kwargs)


class NotFoundError(AsterPayError):
    """HTTP 404 — resource not found."""

    def __init__(self, message: str = "Not found", **kwargs):
        super().__init__(message, status_code=404, **kwargs)


class ServerError(AsterPayError):
    """HTTP 5xx — server error."""

    def __init__(self, message: str = "Server error", **kwargs):
        super().__init__(message, **kwargs)
