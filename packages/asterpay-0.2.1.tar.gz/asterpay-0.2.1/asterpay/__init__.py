"""
AsterPay Python SDK — EUR settlement for AI agent commerce.

USDC → EUR via SEPA Instant on Base. x402-native.

Quick start:
    from asterpay import AsterPay

    client = AsterPay()

    # Get a crypto price
    price = client.market.price("bitcoin")

    # Estimate EUR settlement
    quote = client.settlement.estimate(amount_usdc=100)

    # AI text summarization
    summary = client.ai.summarize("Your long text here...")
"""

__version__ = "0.2.0"

from asterpay.client import AsterPay
from asterpay.client import AsyncAsterPay

__all__ = ["AsterPay", "AsyncAsterPay", "__version__"]
