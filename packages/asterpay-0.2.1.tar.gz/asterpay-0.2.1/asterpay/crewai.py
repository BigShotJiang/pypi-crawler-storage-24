"""
AsterPay CrewAI Tools — EUR settlement for AI agent commerce.

Usage:
    from asterpay.crewai import get_asterpay_tools

    tools = get_asterpay_tools()
    agent = Agent(role="Crypto Analyst", tools=tools)

Or pick individual tools:
    from asterpay.crewai import asterpay_crypto_price, asterpay_eur_settlement_estimate
"""

from __future__ import annotations

import json
from typing import Optional

try:
    from crewai.tools import tool
except ImportError:
    raise ImportError(
        "CrewAI integration requires crewai. "
        "Install with: pip install asterpay[crewai]"
    )

from asterpay.client import AsterPay

# Module-level shared client
_client: Optional[AsterPay] = None


def _get_client() -> AsterPay:
    global _client
    if _client is None:
        _client = AsterPay()
    return _client


def set_client(client: AsterPay) -> None:
    """Set a custom AsterPay client for all CrewAI tools."""
    global _client
    _client = client


def _fmt(result: dict) -> str:
    return json.dumps(result, indent=2, default=str)


def _handle_402(e: Exception) -> str:
    return (
        f"x402 payment required: {e}. "
        "Agent needs a funded USDC wallet on Base for paid endpoints."
    )


# ─── Market Tools ────────────────────────────────────────────────

@tool("AsterPay: Get Crypto Price")
def asterpay_crypto_price(symbol: str) -> str:
    """Get the current price of a cryptocurrency (e.g. 'bitcoin', 'ethereum'). Returns USD price and market data. Requires x402 USDC payment."""
    try:
        return _fmt(_get_client().market.price(symbol))
    except Exception as e:
        return _handle_402(e) if "402" in str(e) else f"Error: {e}"


@tool("AsterPay: Get OHLCV Data")
def asterpay_crypto_ohlcv(symbol: str, days: int = 7) -> str:
    """Get OHLCV chart data for a cryptocurrency. Input: symbol and days (1-365). Requires x402 payment."""
    try:
        return _fmt(_get_client().market.ohlcv(symbol, days))
    except Exception as e:
        return _handle_402(e) if "402" in str(e) else f"Error: {e}"


@tool("AsterPay: Trending Tokens")
def asterpay_trending_tokens() -> str:
    """Get currently trending cryptocurrencies. No input needed. Requires x402 payment."""
    try:
        return _fmt(_get_client().market.trending())
    except Exception as e:
        return _handle_402(e) if "402" in str(e) else f"Error: {e}"


# ─── AI Tools ────────────────────────────────────────────────────

@tool("AsterPay: Summarize Text")
def asterpay_summarize(text: str) -> str:
    """Summarize a long text into a shorter version. Requires x402 payment."""
    try:
        return _fmt(_get_client().ai.summarize(text))
    except Exception as e:
        return _handle_402(e) if "402" in str(e) else f"Error: {e}"


@tool("AsterPay: Sentiment Analysis")
def asterpay_sentiment(text: str) -> str:
    """Analyze sentiment of text (positive/negative/neutral). Requires x402 payment."""
    try:
        return _fmt(_get_client().ai.sentiment(text))
    except Exception as e:
        return _handle_402(e) if "402" in str(e) else f"Error: {e}"


@tool("AsterPay: Translate Text")
def asterpay_translate(text: str, target_language: str) -> str:
    """Translate text to another language. target_language: 'fi', 'de', 'fr', 'es', etc. Requires x402 payment."""
    try:
        return _fmt(_get_client().ai.translate(text, target_language))
    except Exception as e:
        return _handle_402(e) if "402" in str(e) else f"Error: {e}"


@tool("AsterPay: Code Review")
def asterpay_code_review(code: str) -> str:
    """Review source code for quality, bugs, and improvements. Requires x402 payment."""
    try:
        return _fmt(_get_client().ai.code_review(code))
    except Exception as e:
        return _handle_402(e) if "402" in str(e) else f"Error: {e}"


# ─── Crypto Analytics ────────────────────────────────────────────

@tool("AsterPay: Wallet Score")
def asterpay_wallet_score(address: str) -> str:
    """Score a blockchain wallet for activity, risk, and reputation. Requires x402 payment."""
    try:
        return _fmt(_get_client().crypto.wallet_score(address))
    except Exception as e:
        return _handle_402(e) if "402" in str(e) else f"Error: {e}"


@tool("AsterPay: Token Analysis")
def asterpay_token_analysis(address: str) -> str:
    """Analyze a token contract for risk, liquidity, holders. Requires x402 payment."""
    try:
        return _fmt(_get_client().crypto.token_analysis(address))
    except Exception as e:
        return _handle_402(e) if "402" in str(e) else f"Error: {e}"


@tool("AsterPay: Whale Alerts")
def asterpay_whale_alerts() -> str:
    """Get recent large crypto transactions (whale alerts). Requires x402 payment."""
    try:
        return _fmt(_get_client().crypto.whale_alerts())
    except Exception as e:
        return _handle_402(e) if "402" in str(e) else f"Error: {e}"


# ─── Settlement (EUR) ───────────────────────────────────────────

@tool("AsterPay: EUR Settlement Estimate")
def asterpay_eur_settlement_estimate(amount_usdc: float) -> str:
    """Estimate USDC → EUR settlement via SEPA Instant. Returns EUR amount, fees, rate. FREE endpoint."""
    try:
        return _fmt(_get_client().settlement.estimate(amount_usdc))
    except Exception as e:
        return f"Error: {e}"


@tool("AsterPay: EUR Settlement Quote")
def asterpay_eur_settlement_quote(amount_usdc: float) -> str:
    """Get a firm USDC → EUR SEPA settlement quote with locked rate."""
    try:
        return _fmt(_get_client().settlement.quote(amount_usdc))
    except Exception as e:
        return f"Error: {e}"


@tool("AsterPay: Transfer Status")
def asterpay_transfer_status(transfer_id: str) -> str:
    """Check the status of a EUR settlement transfer by ID."""
    try:
        return _fmt(_get_client().settlement.transfer_status(transfer_id))
    except Exception as e:
        return f"Error: {e}"


# ─── Health & Discovery (FREE) ──────────────────────────────────

@tool("AsterPay: Health Check")
def asterpay_health() -> str:
    """Check if AsterPay API is online. FREE endpoint."""
    try:
        return _fmt(_get_client().health())
    except Exception as e:
        return f"Error: {e}"


@tool("AsterPay: Discover Endpoints")
def asterpay_discover_endpoints() -> str:
    """Discover all AsterPay API endpoints with pricing and schemas. FREE endpoint."""
    try:
        return _fmt(_get_client().discovery.resources())
    except Exception as e:
        return f"Error: {e}"


# ─── Utility ────────────────────────────────────────────────────

@tool("AsterPay: QR Code")
def asterpay_qr_code(data: str) -> str:
    """Generate a QR code from data string. Requires x402 payment."""
    try:
        return _fmt(_get_client().utility.qr_code(data))
    except Exception as e:
        return _handle_402(e) if "402" in str(e) else f"Error: {e}"


@tool("AsterPay: Screenshot")
def asterpay_screenshot(url: str) -> str:
    """Take a screenshot of a website URL. Requires x402 payment."""
    try:
        return _fmt(_get_client().utility.screenshot(url))
    except Exception as e:
        return _handle_402(e) if "402" in str(e) else f"Error: {e}"


# ─── Tool Collection ────────────────────────────────────────────

def get_asterpay_tools() -> list:
    """
    Get all AsterPay tools for CrewAI agents.

    Usage:
        from asterpay.crewai import get_asterpay_tools
        agent = Agent(role="Analyst", tools=get_asterpay_tools())
    """
    return [
        asterpay_health,
        asterpay_discover_endpoints,
        asterpay_eur_settlement_estimate,
        asterpay_eur_settlement_quote,
        asterpay_transfer_status,
        asterpay_crypto_price,
        asterpay_crypto_ohlcv,
        asterpay_trending_tokens,
        asterpay_summarize,
        asterpay_sentiment,
        asterpay_translate,
        asterpay_code_review,
        asterpay_wallet_score,
        asterpay_token_analysis,
        asterpay_whale_alerts,
        asterpay_qr_code,
        asterpay_screenshot,
    ]


def get_free_tools() -> list:
    """Get only the free (no x402 payment) AsterPay tools for CrewAI."""
    return [
        asterpay_health,
        asterpay_discover_endpoints,
        asterpay_eur_settlement_estimate,
    ]
