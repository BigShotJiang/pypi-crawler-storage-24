"""Crypto analytics — wallet score, token analysis, whale alerts."""

from __future__ import annotations
import httpx
from asterpay.services._base import handle_response


class CryptoService:
    """Sync crypto analytics (x402: $0.02-$0.10 per call)."""

    def __init__(self, http: httpx.Client):
        self._http = http

    def wallet_score(self, address: str) -> dict:
        """
        Get wallet reputation score.

        Args:
            address: Wallet address (0x...)

        Returns:
            Reputation score, transaction count, risk level

        Price: $0.05 USDC
        """
        return handle_response(self._http.get(f"/v1/crypto/wallet-score/{address}"))

    def token_analysis(self, address: str) -> dict:
        """
        Analyze token security and metrics.

        Args:
            address: Token contract address

        Returns:
            Security score, holder distribution, liquidity analysis

        Price: $0.10 USDC
        """
        return handle_response(self._http.get(f"/v1/crypto/token-analysis/{address}"))

    def whale_alerts(self) -> dict:
        """
        Get recent whale movements.

        Returns:
            List of large transactions

        Price: $0.02 USDC
        """
        return handle_response(self._http.get("/v1/crypto/whale-alerts"))


class AsyncCryptoService:
    """Async crypto analytics."""

    def __init__(self, http: httpx.AsyncClient):
        self._http = http

    async def wallet_score(self, address: str) -> dict:
        return handle_response(await self._http.get(f"/v1/crypto/wallet-score/{address}"))

    async def token_analysis(self, address: str) -> dict:
        return handle_response(await self._http.get(f"/v1/crypto/token-analysis/{address}"))

    async def whale_alerts(self) -> dict:
        return handle_response(await self._http.get("/v1/crypto/whale-alerts"))
