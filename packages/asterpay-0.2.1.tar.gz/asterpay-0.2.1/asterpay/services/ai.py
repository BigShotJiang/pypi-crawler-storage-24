"""AI services — summarize, sentiment, translate, code review."""

from __future__ import annotations
from typing import Optional
import httpx
from asterpay.services._base import handle_response


class AIService:
    """Sync AI tools (x402: $0.01-$0.05 per call)."""

    def __init__(self, http: httpx.Client):
        self._http = http

    def summarize(self, text: str, max_length: Optional[int] = None) -> dict:
        """
        Summarize text using AI.

        Args:
            text: Text to summarize
            max_length: Optional max summary length

        Returns:
            Summary result

        Price: $0.01 USDC
        """
        payload = {"text": text}
        if max_length:
            payload["max_length"] = max_length
        return handle_response(self._http.post("/v1/ai/summarize", json=payload))

    def sentiment(self, text: str) -> dict:
        """
        Analyze sentiment of text.

        Args:
            text: Text to analyze

        Returns:
            Sentiment score and label

        Price: $0.01 USDC
        """
        return handle_response(self._http.post("/v1/ai/sentiment", json={"text": text}))

    def translate(self, text: str, target_language: str, source_language: str = "auto") -> dict:
        """
        Translate text to target language.

        Args:
            text: Text to translate
            target_language: Target language code (e.g. "fi", "de", "fr")
            source_language: Source language (default: auto-detect)

        Returns:
            Translated text

        Price: $0.02 USDC
        """
        return handle_response(self._http.post("/v1/ai/translate", json={
            "text": text,
            "target_language": target_language,
            "source_language": source_language,
        }))

    def code_review(self, code: str, language: str = "auto") -> dict:
        """
        AI code review.

        Args:
            code: Source code to review
            language: Programming language (default: auto-detect)

        Returns:
            Code review with suggestions

        Price: $0.05 USDC
        """
        return handle_response(self._http.post("/v1/ai/code-review", json={
            "code": code,
            "language": language,
        }))


class AsyncAIService:
    """Async AI tools."""

    def __init__(self, http: httpx.AsyncClient):
        self._http = http

    async def summarize(self, text: str, max_length: Optional[int] = None) -> dict:
        payload = {"text": text}
        if max_length:
            payload["max_length"] = max_length
        return handle_response(await self._http.post("/v1/ai/summarize", json=payload))

    async def sentiment(self, text: str) -> dict:
        return handle_response(await self._http.post("/v1/ai/sentiment", json={"text": text}))

    async def translate(self, text: str, target_language: str, source_language: str = "auto") -> dict:
        return handle_response(await self._http.post("/v1/ai/translate", json={
            "text": text,
            "target_language": target_language,
            "source_language": source_language,
        }))

    async def code_review(self, code: str, language: str = "auto") -> dict:
        return handle_response(await self._http.post("/v1/ai/code-review", json={
            "code": code,
            "language": language,
        }))
