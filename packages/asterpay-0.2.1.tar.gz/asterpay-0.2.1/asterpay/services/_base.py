"""Base service with x402 error handling."""

from __future__ import annotations
import httpx
from asterpay.exceptions import PaymentRequiredError, RateLimitError, NotFoundError, ServerError


def handle_response(resp: httpx.Response) -> dict:
    """Handle API response with friendly error messages."""
    if resp.status_code == 200:
        return resp.json()

    if resp.status_code == 402:
        # x402 Payment Required — extract payment info
        try:
            body = resp.json()
        except Exception:
            body = {}
        payment_header = resp.headers.get("PAYMENT-REQUIRED", "")
        raise PaymentRequiredError(
            message=f"x402 payment required for {resp.request.url.path}. "
                    f"Use an x402-compatible wallet to pay with USDC.",
            accepts=body.get("accepts", []),
            response=body,
        )

    if resp.status_code == 429:
        retry_after = resp.headers.get("Retry-After")
        raise RateLimitError(
            message="Rate limit exceeded. Try again later.",
            retry_after=int(retry_after) if retry_after else None,
        )

    if resp.status_code == 404:
        raise NotFoundError(message=f"Resource not found: {resp.request.url.path}")

    if resp.status_code >= 500:
        raise ServerError(
            message=f"Server error ({resp.status_code}): {resp.text[:200]}",
            status_code=resp.status_code,
        )

    # Other errors — fall through to httpx default
    resp.raise_for_status()
    return resp.json()
