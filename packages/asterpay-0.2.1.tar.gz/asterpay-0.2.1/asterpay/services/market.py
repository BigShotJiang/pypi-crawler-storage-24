"""Market data service — crypto prices, OHLCV, trending tokens."""

from __future__ import annotations
from typing import Optional, Union
import httpx
from asterpay.services._base import handle_response


class MarketService:
    """Sync market data (x402: $0.001-$0.005 per call)."""

    def __init__(self, http: httpx.Client):
        self._http = http

    def price(self, symbol: str) -> dict:
        """
        Get real-time crypto price.

        Args:
            symbol: Token symbol (e.g. "bitcoin", "ethereum", "usdc")

        Returns:
            Price data with USD value, 24h change, market cap

        Price: $0.001 USDC
        """
        return handle_response(self._http.get(f"/v1/market/price/{symbol}"))

    def ohlcv(self, symbol: str, days: int = 7) -> dict:
        """
        Get OHLCV candle data for charting.

        Args:
            symbol: Token symbol
            days: Number of days (default: 7)

        Returns:
            OHLCV candle data

        Price: $0.005 USDC
        """
        return handle_response(self._http.get(f"/v1/market/ohlcv/{symbol}", params={"days": days}))

    def trending(self) -> dict:
        """
        Get trending tokens.

        Returns:
            List of trending tokens

        Price: $0.002 USDC
        """
        return handle_response(self._http.get("/v1/market/trending"))


class AsyncMarketService:
    """Async market data."""

    def __init__(self, http: httpx.AsyncClient):
        self._http = http

    async def price(self, symbol: str) -> dict:
        return handle_response(await self._http.get(f"/v1/market/price/{symbol}"))

    async def ohlcv(self, symbol: str, days: int = 7) -> dict:
        return handle_response(await self._http.get(f"/v1/market/ohlcv/{symbol}", params={"days": days}))

    async def trending(self) -> dict:
        return handle_response(await self._http.get("/v1/market/trending"))
