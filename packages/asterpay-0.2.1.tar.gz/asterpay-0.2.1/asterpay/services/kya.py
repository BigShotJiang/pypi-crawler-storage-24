"""Know Your Agent (KYA) service — trust score, verify, tier, deep analysis."""

from __future__ import annotations
import httpx
from asterpay.services._base import handle_response


class KYAService:
    """
    Sync KYA (Know Your Agent) — agent trust verification.

    FREE: trust_score, verify, tier.
    PAID (x402): deep_analysis ($0.01).
    """

    def __init__(self, http: httpx.Client):
        self._http = http

    def trust_score(self, address: str) -> dict:
        """
        Get full trust assessment for an agent wallet (0-100 score).

        Args:
            address: Ethereum address (agent or wallet)

        Returns:
            trust_score, tier, components (ERC-8004, sanctions, etc.)

        Price: FREE
        """
        return handle_response(self._http.get(f"/v1/agent/trust-score/{address}"))

    def verify(self, address: str) -> dict:
        """
        Quick identity check — is this address registered as an agent (ERC-8004)?

        Args:
            address: Ethereum address

        Returns:
            verified, agentId, owner, metadataUri

        Price: FREE
        """
        return handle_response(self._http.get(f"/v1/agent/verify/{address}"))

    def tier(self, address: str) -> dict:
        """
        Get agent tier (Open / Verified / Trusted / Enterprise) and max per-transaction limit.

        Args:
            address: Ethereum address

        Returns:
            tier, max_per_tx

        Price: FREE
        """
        return handle_response(self._http.get(f"/v1/agent/tier/{address}"))

    def deep_analysis(self, address: str) -> dict:
        """
        Behavioral intelligence and deep trust analysis (velocity, signals, recommendation).

        Args:
            address: Ethereum address

        Returns:
            Deep analysis result with behavioral signals

        Price: $0.01 USDC (x402)
        """
        return handle_response(self._http.get(f"/v1/agent/deep-analysis/{address}"))


class AsyncKYAService:
    """Async KYA (Know Your Agent) service."""

    def __init__(self, http: httpx.AsyncClient):
        self._http = http

    async def trust_score(self, address: str) -> dict:
        return handle_response(await self._http.get(f"/v1/agent/trust-score/{address}"))

    async def verify(self, address: str) -> dict:
        return handle_response(await self._http.get(f"/v1/agent/verify/{address}"))

    async def tier(self, address: str) -> dict:
        return handle_response(await self._http.get(f"/v1/agent/tier/{address}"))

    async def deep_analysis(self, address: str) -> dict:
        return handle_response(await self._http.get(f"/v1/agent/deep-analysis/{address}"))
