"""ASTERPAY Token service — tiers, discounts, wallet checks."""

from __future__ import annotations
import httpx
from asterpay.services._base import handle_response


class TokenService:
    """
    Sync ASTERPAY token utilities (FREE endpoints).

    Hold $ASTERPAY tokens to unlock API discounts up to 60%.
    """

    def __init__(self, http: httpx.Client):
        self._http = http

    def tiers(self) -> dict:
        """
        Get all ASTERPAY tier levels and benefits.

        Returns:
            Tier list: Explorer, Builder, Professional, Enterprise, Whale

        Price: FREE
        """
        return handle_response(self._http.get("/v1/token/tiers"))

    def check_wallet(self, address: str) -> dict:
        """
        Check wallet's ASTERPAY tier and discount.

        Args:
            address: Wallet address to check

        Returns:
            Current tier, balance, discount percentage

        Price: FREE
        """
        return handle_response(self._http.get(f"/v1/token/check/{address}"))

    def stats(self) -> dict:
        """
        Get live ASTERPAY token stats.

        Returns:
            Price, market cap, holders, liquidity

        Price: FREE
        """
        return handle_response(self._http.get("/v1/token/stats"))


class AsyncTokenService:
    """Async ASTERPAY token utilities."""

    def __init__(self, http: httpx.AsyncClient):
        self._http = http

    async def tiers(self) -> dict:
        return handle_response(await self._http.get("/v1/token/tiers"))

    async def check_wallet(self, address: str) -> dict:
        return handle_response(await self._http.get(f"/v1/token/check/{address}"))

    async def stats(self) -> dict:
        return handle_response(await self._http.get("/v1/token/stats"))
