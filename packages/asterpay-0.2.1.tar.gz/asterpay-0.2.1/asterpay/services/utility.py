"""Utility services — QR codes, screenshots, PDF generation."""

from __future__ import annotations
from typing import Optional
import httpx
from asterpay.services._base import handle_response


class UtilityService:
    """Sync utility tools (x402: $0.005-$0.03 per call)."""

    def __init__(self, http: httpx.Client):
        self._http = http

    def qr_code(self, data: str, size: int = 256) -> dict:
        """
        Generate QR code.

        Args:
            data: Data to encode (URL, text, etc.)
            size: QR code size in pixels (default: 256)

        Returns:
            QR code image (base64 or URL)

        Price: $0.005 USDC
        """
        return handle_response(self._http.post("/v1/util/qr-code", json={"data": data, "size": size}))

    def screenshot(self, url: str, width: int = 1280, height: int = 720) -> dict:
        """
        Take a webpage screenshot.

        Args:
            url: URL to screenshot
            width: Viewport width (default: 1280)
            height: Viewport height (default: 720)

        Returns:
            Screenshot image

        Price: $0.02 USDC
        """
        return handle_response(self._http.post("/v1/util/screenshot", json={
            "url": url, "width": width, "height": height,
        }))

    def pdf(self, html: str) -> dict:
        """
        Generate PDF from HTML.

        Args:
            html: HTML content to convert

        Returns:
            PDF document

        Price: $0.03 USDC
        """
        return handle_response(self._http.post("/v1/util/pdf-generate", json={"html": html}))


class AsyncUtilityService:
    """Async utility tools."""

    def __init__(self, http: httpx.AsyncClient):
        self._http = http

    async def qr_code(self, data: str, size: int = 256) -> dict:
        return handle_response(await self._http.post("/v1/util/qr-code", json={"data": data, "size": size}))

    async def screenshot(self, url: str, width: int = 1280, height: int = 720) -> dict:
        return handle_response(await self._http.post("/v1/util/screenshot", json={
            "url": url, "width": width, "height": height,
        }))

    async def pdf(self, html: str) -> dict:
        return handle_response(await self._http.post("/v1/util/pdf-generate", json={"html": html}))
