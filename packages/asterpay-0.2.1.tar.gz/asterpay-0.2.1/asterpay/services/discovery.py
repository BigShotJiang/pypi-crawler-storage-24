"""Discovery service — x402 Bazaar endpoint discovery."""

from __future__ import annotations
import httpx
from asterpay.services._base import handle_response


class DiscoveryService:
    """Sync x402 discovery (FREE)."""

    def __init__(self, http: httpx.Client):
        self._http = http

    def resources(self) -> dict:
        """
        Discover all available API endpoints with pricing and schemas.

        Returns:
            List of endpoints with input/output schemas, prices, categories

        Price: FREE
        """
        return handle_response(self._http.get("/discovery/resources"))


class AsyncDiscoveryService:
    """Async x402 discovery."""

    def __init__(self, http: httpx.AsyncClient):
        self._http = http

    async def resources(self) -> dict:
        return handle_response(await self._http.get("/discovery/resources"))
