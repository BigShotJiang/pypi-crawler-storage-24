"""EUR Settlement service — USDC to EUR via SEPA Instant."""

from __future__ import annotations
from typing import Optional
import httpx
from asterpay.services._base import handle_response


class SettlementService:
    """
    Sync EUR settlement — core AsterPay feature.

    Convert USDC to EUR via SEPA Instant on Base.
    """

    def __init__(self, http: httpx.Client):
        self._http = http

    def estimate(self, amount_usdc: float, currency: str = "EUR") -> dict:
        """
        Get EUR settlement estimate.

        Args:
            amount_usdc: Amount in USDC to convert
            currency: Target currency (default: EUR)

        Returns:
            Estimated EUR amount, fee, exchange rate, settlement time

        Price: $0.001 USDC
        """
        return handle_response(self._http.get("/v1/settlement/estimate", params={
            "amount": amount_usdc,
            "currency": currency,
        }))

    def quote(self, amount_usdc: float, iban: Optional[str] = None) -> dict:
        """
        Get a firm settlement quote.

        Args:
            amount_usdc: Amount in USDC
            iban: Target IBAN for SEPA settlement

        Returns:
            Firm quote with locked exchange rate
        """
        params = {"amount": amount_usdc}
        if iban:
            params["iban"] = iban
        return handle_response(self._http.get("/v1/settlement/quote", params=params))

    def transfer_status(self, transfer_id: str) -> dict:
        """
        Check status of a settlement transfer.

        Args:
            transfer_id: Transfer ID from settlement

        Returns:
            Transfer status, amount, timestamps
        """
        return handle_response(self._http.get(f"/v1/settlement/transfer/{transfer_id}"))

    def list_transfers(self) -> dict:
        """
        List all settlement transfers.

        Returns:
            List of transfers with status
        """
        return handle_response(self._http.get("/v1/settlement/transfers"))

    def bridge_health(self) -> dict:
        """
        Check Bridge (settlement provider) health.

        Returns:
            Bridge API status
        """
        return handle_response(self._http.get("/v1/settlement/bridge/health"))


class AsyncSettlementService:
    """Async EUR settlement."""

    def __init__(self, http: httpx.AsyncClient):
        self._http = http

    async def estimate(self, amount_usdc: float, currency: str = "EUR") -> dict:
        return handle_response(await self._http.get("/v1/settlement/estimate", params={
            "amount": amount_usdc, "currency": currency,
        }))

    async def quote(self, amount_usdc: float, iban: Optional[str] = None) -> dict:
        params = {"amount": amount_usdc}
        if iban:
            params["iban"] = iban
        return handle_response(await self._http.get("/v1/settlement/quote", params=params))

    async def transfer_status(self, transfer_id: str) -> dict:
        return handle_response(await self._http.get(f"/v1/settlement/transfer/{transfer_id}"))

    async def list_transfers(self) -> dict:
        return handle_response(await self._http.get("/v1/settlement/transfers"))

    async def bridge_health(self) -> dict:
        return handle_response(await self._http.get("/v1/settlement/bridge/health"))
