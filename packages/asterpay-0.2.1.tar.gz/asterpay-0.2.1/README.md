# asterpay

**Python SDK for AsterPay** — EUR settlement for AI agent commerce via x402 protocol.

[![PyPI](https://img.shields.io/pypi/v/asterpay)](https://pypi.org/project/asterpay/)
[![Python](https://img.shields.io/pypi/pyversions/asterpay)](https://pypi.org/project/asterpay/)
[![License](https://img.shields.io/pypi/l/asterpay)](https://github.com/AsterPay/asterpay-python/blob/main/LICENSE)

## What is AsterPay?

AsterPay is the EUR settlement layer for AI agent commerce. Convert USDC to EUR via SEPA Instant in under 5 seconds — on Base, MiCA-compliant, and listed in the [Coinbase x402 ecosystem](https://x402.org/ecosystem).

**Key features:**
- **KYA (Know Your Agent)** — 5-layer trust scoring (0-100) for AI agent wallets
- **EUR Settlement** — USDC/EURC → EUR via SEPA Instant
- **LangChain + CrewAI** — 20+ ready-made tools
- **x402 Protocol** — HTTP 402 pay-per-call with USDC
- Referenced in [Google A2A spec](https://github.com/a2aproject/A2A/issues/1628) for trust.signals[]

## Install

```bash
pip install asterpay
```

## Quick Start

```python
from asterpay import AsterPay

client = AsterPay()

# Get a crypto price ($0.001 USDC)
price = client.market.price("bitcoin")
print(f"BTC: ${price['price']}")

# Get EUR settlement estimate (FREE)
quote = client.settlement.estimate(amount_usdc=100)
print(f"100 USDC → {quote['eur_amount']} EUR")

# AI text summarization ($0.01 USDC)
result = client.ai.summarize("Your long article text here...")
print(result['summary'])

# Check your ASTERPAY tier (FREE)
tier = client.token.check_wallet("0xYourWallet...")
print(f"Tier: {tier['tier']} ({tier['discount']}% discount)")
```

## LangChain Integration

```bash
pip install asterpay[langchain]
```

```python
from asterpay.langchain import get_asterpay_tools
from langchain.agents import create_react_agent

# 19 tools — market data, AI, EUR settlement, crypto analytics
tools = get_asterpay_tools()
agent = create_react_agent(llm, tools)

# Or just the free tools (no x402 payment needed)
from asterpay.langchain import get_free_tools
free_tools = get_free_tools()

# Or just the KYA (trust scoring) tools
from asterpay.langchain import get_asterpay_kya_tools
kya_tools = get_asterpay_kya_tools()
```

## CrewAI Integration

```bash
pip install asterpay[crewai]
```

```python
from asterpay.crewai import get_asterpay_tools
from crewai import Agent

analyst = Agent(
    role="Crypto Analyst",
    goal="Analyze market trends and settle profits to EUR",
    tools=get_asterpay_tools()
)
```

## Both Frameworks

```bash
pip install asterpay[agents]  # installs langchain + crewai support
```

## Async Support

```python
from asterpay import AsyncAsterPay
import asyncio

async def main():
    async with AsyncAsterPay() as client:
        price = await client.market.price("ethereum")
        print(f"ETH: ${price['price']}")

asyncio.run(main())
```

## Services

| Service | Endpoints | Pricing |
|---------|-----------|---------|
| `client.market` | `price()`, `ohlcv()`, `trending()` | $0.001–$0.005 |
| `client.ai` | `summarize()`, `sentiment()`, `translate()`, `code_review()` | $0.01–$0.05 |
| `client.crypto` | `wallet_score()`, `token_analysis()`, `whale_alerts()` | $0.02–$0.10 |
| `client.utility` | `qr_code()`, `screenshot()`, `pdf()` | $0.005–$0.03 |
| `client.settlement` | `estimate()`, `quote()`, `transfer_status()` | **FREE** |
| `client.token` | `tiers()`, `check_wallet()`, `stats()` | **FREE** |
| `client.discovery` | `resources()` | **FREE** |

## ASTERPAY Token Discounts

Hold [$ASTERPAY](https://asterpay.io) tokens to unlock API discounts:

| Tier | Balance | Discount |
|------|---------|----------|
| Explorer | 0 | 0% |
| Builder | 100K | 10% |
| Professional | 1M | 25% |
| Enterprise | 10M | 40% |
| Whale | 50M | 60% |

```python
# Pass your wallet for automatic tier discounts
client = AsterPay(wallet_address="0xYourWallet...")
```

## EUR Settlement

AsterPay's core feature — USDC to EUR via SEPA Instant:

```python
# 1. Get a quote
quote = client.settlement.estimate(amount_usdc=500)
print(f"500 USDC → {quote['eur_amount']} EUR (fee: {quote['fee']})")

# 2. Check Bridge provider health
health = client.settlement.bridge_health()
print(f"Bridge status: {health['status']}")
```

## x402 Protocol

Paid endpoints use the [x402 HTTP payment protocol](https://x402.org). When a 402 response is returned, your x402-compatible wallet or agent framework handles the USDC micropayment automatically.

## Also Available

- **MCP Server**: `npx @asterpay/mcp-server` — for Claude, Cursor, and other AI tools
- **REST API**: Direct HTTP access at `https://x402-api-production-ba87.up.railway.app`

## Links

- [Website](https://asterpay.io)
- [x402 Ecosystem](https://x402.org/ecosystem)
- [MCP Server (npm)](https://www.npmjs.com/package/@asterpay/mcp-server)
- [API Docs](https://x402-api-production-ba87.up.railway.app/docs)

## License

MIT
