# Topic-Enhanced RAG
# Copyright (C) 2026 Topic-Enhanced RAG Research Team
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.

"""
topic_rag — Topic-Enhanced Retrieval-Augmented Generation Library

A Python library for building, evaluating, and benchmarking Topic-Enhanced RAG systems.

Quickstart::

    from topic_rag import DocumentProcessor, TopicEnhancedRAGRetriever, RAGEvaluator

    processor = DocumentProcessor(n_topics=10)
    corpus_data = processor.process_corpus(documents)

    retriever = TopicEnhancedRAGRetriever(corpus_data)
    results = retriever.retrieve("What is machine learning?", k=5)

    evaluator = RAGEvaluator()
    metrics = evaluator.evaluate_retrieval(results, relevant_doc_ids)
"""

from topic_rag.core import (
    DocumentProcessor,
    StandardRAGRetriever,
    TopicEnhancedRAGRetriever,
    RAGEvaluator,
    SimpleTfidfVectorizer,
    SimpleTopicModel,
    run_single_document_rag_comparison,
    train_topic_embedder,
)

from topic_rag.datasets import DatasetLoader, get_dataset_loader

from topic_rag.statistics import StatisticalAnalyzer, calculate_statistical_significance

from topic_rag.visualization import VisualizationManager

from topic_rag.paper import PaperGenerator

from topic_rag.evaluation import (
    EvaluationPipeline,
    ExperimentConfig,
    create_default_experiment_configs,
)

from topic_rag.config import (
    DEFAULT_N_TOPICS,
    DEFAULT_K_VALUES,
    SUPPORTED_DATASETS,
    RESULTS_DIR,
    FIGURES_DIR,
    PAPERS_DIR,
    CACHE_DIR,
    SIGNIFICANCE_LEVEL,
)

__version__ = "1.0.1"
__author__ = "Topic-Enhanced RAG Research Team"
__all__ = [
    "DocumentProcessor",
    "StandardRAGRetriever",
    "TopicEnhancedRAGRetriever",
    "RAGEvaluator",
    "SimpleTfidfVectorizer",
    "SimpleTopicModel",
    "run_single_document_rag_comparison",
    "train_topic_embedder",
    "DatasetLoader",
    "get_dataset_loader",
    "StatisticalAnalyzer",
    "calculate_statistical_significance",
    "VisualizationManager",
    "PaperGenerator",
    "EvaluationPipeline",
    "ExperimentConfig",
    "create_default_experiment_configs",
    "DEFAULT_N_TOPICS",
    "DEFAULT_K_VALUES",
    "SUPPORTED_DATASETS",
    "RESULTS_DIR",
    "FIGURES_DIR",
    "PAPERS_DIR",
    "CACHE_DIR",
    "SIGNIFICANCE_LEVEL",
]
