"""Tests for crisprbact.cli using Click's CliRunner."""

import os
import tempfile

import pytest
from click.testing import CliRunner

from crisprbact.cli import HEADER, main


# Sequence with a known CC (= NGG on revcomp) that yields exactly one guide.
# From predict_test.py: this sequence produces 1 guide with guide="GTTTTTTTTTTTTTCTTTTC".
_SEQ_ONE_GUIDE = "TTTTTTTTTTTTTTTTCCAGAAAAGAAAAAAAAAAAAAC"

# Longer sequence with multiple CC sites for tests expecting multiple guides.
# CC appears at positions 16-17 and 56-57 (0-indexed).
_SEQ = (
    "TTTTTTTTTTTTTTTTCCAGAAAAGAAAAAAAAAAAAAC"
    "TTTTTTTTTTTTTTTTCCAGAAAAGAAAAAAAAAAAAAC"
)


class TestPredictFromStr:
    def test_valid_sequence_produces_tsv(self):
        """from-str with a sequence containing NGG PAMs (CC on fwd) outputs valid TSV."""
        runner = CliRunner()
        result = runner.invoke(main, ["predict", "from-str", "-t", _SEQ_ONE_GUIDE])
        assert result.exit_code == 0, result.output
        lines = [l for l in result.output.splitlines() if l]
        assert len(lines) >= 1  # at least header
        header = lines[0].split("\t")
        assert header == HEADER

    def test_header_columns_match(self):
        """Output header matches the HEADER constant exactly."""
        runner = CliRunner()
        result = runner.invoke(main, ["predict", "from-str", "-t", _SEQ_ONE_GUIDE])
        assert result.exit_code == 0
        first_line = result.output.splitlines()[0]
        assert first_line == "\t".join(HEADER)

    def test_guides_found(self):
        """At least one guide is output for a sequence with CC on the forward strand."""
        runner = CliRunner()
        result = runner.invoke(main, ["predict", "from-str", "-t", _SEQ_ONE_GUIDE])
        assert result.exit_code == 0
        lines = [l for l in result.output.splitlines() if l]
        assert len(lines) >= 2, "Expected at least one data row"

    def test_data_row_has_correct_number_of_fields(self):
        """Each data row has exactly len(HEADER) tab-separated fields."""
        runner = CliRunner()
        result = runner.invoke(main, ["predict", "from-str", "-t", _SEQ_ONE_GUIDE])
        assert result.exit_code == 0
        # Use splitlines() directly (avoid strip() which eats trailing tabs)
        data_lines = [l for l in result.output.splitlines() if l][1:]
        for line in data_lines:
            fields = line.split("\t")
            assert len(fields) == len(HEADER), (
                f"Row has {len(fields)} fields, expected {len(HEADER)}"
            )

    def test_empty_sequence_exits_cleanly(self):
        """An all-A sequence with no NGG sites returns only the header."""
        runner = CliRunner()
        result = runner.invoke(main, ["predict", "from-str", "-t", "A" * 50])
        assert result.exit_code == 0
        lines = [l for l in result.output.strip().splitlines() if l]
        assert lines[0] == "\t".join(HEADER)
        assert len(lines) == 1  # header only


class TestPredictFromSeq:
    def _write_fasta(self, path, seq, seq_id="test"):
        with open(path, "w") as fh:
            fh.write(f">{seq_id}\n{seq}\n")

    def test_valid_fasta_produces_tsv(self, tmp_path):
        """from-seq with a FASTA file outputs valid TSV."""
        fa = str(tmp_path / "seq.fasta")
        self._write_fasta(fa, _SEQ_ONE_GUIDE)

        runner = CliRunner()
        result = runner.invoke(main, ["predict", "from-seq", "-t", fa])
        assert result.exit_code == 0, result.output
        lines = [l for l in result.output.splitlines() if l]
        assert lines[0] == "\t".join(HEADER)

    def test_multi_record_fasta(self, tmp_path):
        """from-seq processes all records in a multi-record FASTA."""
        fa = str(tmp_path / "multi.fasta")
        with open(fa, "w") as fh:
            fh.write(f">rec1\n{_SEQ_ONE_GUIDE}\n")
            fh.write(f">rec2\n{_SEQ_ONE_GUIDE}\n")

        runner = CliRunner()
        result = runner.invoke(main, ["predict", "from-seq", "-t", fa])
        assert result.exit_code == 0, result.output

        # Both records should produce output; check the seq_id column (index 6)
        data_lines = [l for l in result.output.splitlines() if l][1:]
        assert len(data_lines) >= 2, "Expected guide rows from both records"
        seq_ids = [line.split("\t")[6] for line in data_lines]
        assert "rec1" in seq_ids
        assert "rec2" in seq_ids

    def test_missing_file_exits_nonzero(self):
        """Passing a non-existent file path should cause a non-zero exit."""
        runner = CliRunner()
        result = runner.invoke(
            main, ["predict", "from-seq", "-t", "/nonexistent/path.fasta"]
        )
        assert result.exit_code != 0
