import pandas as pd
import pytest

from crisprbact.library import (
    DEFAULT_BAD_SEEDS,
    add_annotations,
    add_badseeds,
    add_on_target_predictions,
    add_score_quartile,
    find_all_targets,
    generate_library,
    rank_targets,
)


def test_find_all_targets_overlapping():
    """find_all_targets detects overlapping guide sequences from adjacent PAMs.

    The gene sequence GCAGGCCAGCGAGCCAGCGGCGGGAGCGAGTAGGGGAA has two
    overlapping CCN PAMs on the coding strand (positions 5 and 13), which
    correspond to NGG on the template strand. This should yield exactly 2
    guides on the "-" strand (targeting the coding strand of a + gene).
    """
    from Bio.Seq import Seq
    from Bio.SeqRecord import SeqRecord

    gene_seq = "GCAGGCCAGCGAGCCAGCGGCGGGAGCGAGTAGGGGAA"
    flank = "A" * 50
    full_seq = flank + gene_seq + flank
    rec = SeqRecord(Seq(full_seq), id="test")

    targets = find_all_targets([rec], "-")

    guides = [t[0] for t in targets]
    assert len(guides) == 2
    assert "CCCCTACTCGCTCCCGCCGC" in guides
    assert "CGCTCCCGCCGCTGGCTCGC" in guides


def test_find_all_targets(mg1655_records):
    """find_all_targets finds many 20nt guides on both strands."""
    for strand in ["+", "-"]:
        targets = find_all_targets(mg1655_records, strand)

        assert len(targets) > 100000  # MG1655 has many NGG PAMs

        # Each target is [guide, target, recid, strand, pos]
        for t in targets[:20]:
            assert len(t) == 5
            guide, target, recid, s, pos = t
            assert len(guide) == 20
            assert s == strand
            # target is 25bp: guide[-6:] + NGG + 16bp downstream
            assert len(target) == 25


def test_add_annotations(mg1655_10kb_records):
    """add_annotations adds gene/locus_tag columns, keeps targets in genes."""
    targets_raw = find_all_targets(mg1655_10kb_records, "+")
    targets = pd.DataFrame(
        targets_raw, columns=["guide", "seq", "recid", "strand", "pos"]
    )

    annotated = add_annotations(targets, mg1655_10kb_records)

    assert len(annotated) > 0
    assert "gene" in annotated.columns
    assert "locus_tag" in annotated.columns
    assert "gene_ori" in annotated.columns
    assert "targets_coding_strand" in annotated.columns
    assert "second_half_gene" in annotated.columns

    # All rows should have a locus_tag
    assert annotated["locus_tag"].notna().all()


def test_add_on_target_predictions(mg1655_10kb_records):
    """add_on_target_predictions adds a 'score' column with float values."""
    targets_raw = find_all_targets(mg1655_10kb_records, "+")
    targets = pd.DataFrame(
        targets_raw[:100], columns=["guide", "seq", "recid", "strand", "pos"]
    )

    result = add_on_target_predictions(targets)

    assert "score" in result.columns
    assert result["score"].dtype == float
    assert len(result) == 100


def test_add_score_quartile(mg1655_10kb_records):
    """add_score_quartile assigns quartile values 1-4."""
    targets_raw = find_all_targets(mg1655_10kb_records, "+")
    targets = pd.DataFrame(
        targets_raw, columns=["guide", "seq", "recid", "strand", "pos"]
    )
    targets = add_on_target_predictions(targets)

    result = add_score_quartile(targets)

    assert "score_quartile" in result.columns
    assert set(result["score_quartile"].unique()).issubset({1, 2, 3, 4})
    # All four quartiles should be represented with enough targets
    assert len(result["score_quartile"].unique()) == 4


def test_add_badseeds():
    """add_badseeds flags guides with default and custom bad seeds."""
    targets = pd.DataFrame({"guide": [
        "AAAAAAAAAAAAAATATAG",   # not 20nt, won't match; let's use 20nt
    ]})
    # Use 20nt guides where the last 5 bases match a bad seed
    targets = pd.DataFrame({"guide": [
        "A" * 15 + "TATAG",   # last 5 = TATAG -> bad seed
        "A" * 15 + "AAAGG",   # last 5 = AAAGG -> bad seed
        "A" * 15 + "CCCCC",   # last 5 = CCCCC -> not a bad seed
    ]})

    result = add_badseeds(targets)

    assert "inbadseeds" in result.columns
    assert result.iloc[0]["inbadseeds"] == True  # noqa: E712
    assert result.iloc[1]["inbadseeds"] == True  # noqa: E712
    assert result.iloc[2]["inbadseeds"] == False  # noqa: E712

    # Empty bad seeds list: no guides should be flagged
    result_empty = add_badseeds(
        targets.drop(columns=["inbadseeds"]),
        badseeds=[],
    )
    assert not result_empty["inbadseeds"].any()

    # Custom bad seeds
    result2 = add_badseeds(
        targets.drop(columns=["inbadseeds"]),
        badseeds=["CCCCC"]
    )
    assert result2.iloc[0]["inbadseeds"] == False  # noqa: E712
    assert result2.iloc[2]["inbadseeds"] == True  # noqa: E712


def test_rank_targets():
    """rank_targets assigns per-gene ranking."""
    targets = pd.DataFrame({
        "locus_tag": ["b0001", "b0001", "b0001", "b0002", "b0002"],
        "ntargets": [1, 1, 2, 1, 1],
        "noff_12": [0, 1, 0, 0, 0],
        "noff_11_gene": [0, 0, 0, 0, 0],
        "noff_9_prom": [0, 0, 0, 0, 0],
        "inbadseeds": [False, False, False, False, False],
        "score_quartile": [1, 2, 1, 1, 2],
        "second_half_gene": [False, False, False, False, False],
        "score": [0.9, 0.5, 0.8, 0.7, 0.3],
    })

    result = rank_targets(targets)

    assert "gene_rank" in result.columns
    # Each gene should have sequential ranks 1..n
    for lt in ["b0001", "b0002"]:
        gene_ranks = result[result.locus_tag == lt]["gene_rank"].tolist()
        n = len(gene_ranks)
        assert gene_ranks == list(range(1, n + 1)), (
            f"Gene {lt}: expected sequential ranks 1..{n}, got {gene_ranks}"
        )


@pytest.mark.slow
def test_generate_library(mg1655_gbk):
    """End-to-end: generate_library returns DataFrame with expected columns."""
    from tests.conftest import PERSISTENT_OFF_DICS_DIR

    n = 5
    library = generate_library(
        mg1655_gbk,
        n=n,
        cache_dir=PERSISTENT_OFF_DICS_DIR,
    )

    assert isinstance(library, pd.DataFrame)
    assert len(library) > 0

    expected_cols = [
        "guide", "recid", "strand", "pos",
        "gene", "locus_tag", "gene_ori",
        "targets_coding_strand", "second_half_gene",
        "score", "score_quartile",
        "ntargets", "noff_12", "noff_11_gene", "noff_9_prom",
        "inbadseeds", "gene_rank",
    ]
    for col in expected_cols:
        assert col in library.columns, f"Missing column: {col}"

    # All gene_rank values should be <= n
    assert (library["gene_rank"] <= n).all()

    # Should cover many genes
    n_genes = library["locus_tag"].nunique()
    assert n_genes > 4000  # MG1655 has ~4400 genes
