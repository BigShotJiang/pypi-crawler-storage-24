"""Tests for crisprbact.pangenome module."""

import os
import shutil
import textwrap

import pandas as pd
import pytest
from Bio.Seq import Seq
from Bio.SeqFeature import SeqFeature, FeatureLocation
from Bio.SeqRecord import SeqRecord


@pytest.fixture
def two_records():
    """Two minimal GenBank-style SeqRecords with CDS features."""
    def make_record(rec_id, locus, seq_str, aa_seq):
        rec = SeqRecord(
            Seq(seq_str),
            id=rec_id,
            name=rec_id,
            description="",
        )
        feat = SeqFeature(
            FeatureLocation(0, len(seq_str)),
            type="CDS",
            qualifiers={
                "locus_tag": [locus],
                "translation": [aa_seq],
            },
        )
        rec.features.append(feat)
        return rec

    rec1 = make_record("genome1_chr", "g1_001", "ATGCATGC" * 5, "MHAC")
    rec2 = make_record("genome2_chr", "g2_001", "GCTAGCTA" * 5, "ASMH")
    return rec1, rec2


def test_extract_proteins_to_fasta(tmp_path, two_records):
    """extract_proteins_to_fasta writes correct FASTA headers and sequences."""
    from crisprbact.pangenome import extract_proteins_to_fasta

    rec1, rec2 = two_records
    fasta = str(tmp_path / "proteins.fasta")
    result = extract_proteins_to_fasta(
        [[rec1], [rec2]],
        ["genome1", "genome2"],
        fasta,
    )

    assert result == fasta
    assert os.path.exists(fasta)

    content = open(fasta).read()
    assert ">genome1|g1_001" in content
    assert "MHAC" in content
    assert ">genome2|g2_001" in content
    assert "ASMH" in content


def test_extract_proteins_to_fasta_skips_no_translation(tmp_path):
    """extract_proteins_to_fasta skips CDS without translation."""
    from crisprbact.pangenome import extract_proteins_to_fasta

    rec = SeqRecord(Seq("ATGATG"), id="g1", description="")
    feat_ok = SeqFeature(
        FeatureLocation(0, 6), type="CDS",
        qualifiers={"locus_tag": ["lt1"], "translation": ["MW"]},
    )
    feat_no_transl = SeqFeature(
        FeatureLocation(0, 6), type="CDS",
        qualifiers={"locus_tag": ["lt2"]},  # no translation
    )
    rec.features = [feat_ok, feat_no_transl]

    fasta = str(tmp_path / "out.fasta")
    extract_proteins_to_fasta([[rec]], ["g1"], fasta)

    content = open(fasta).read()
    assert ">g1|lt1" in content
    assert "lt2" not in content


def test_parse_cluster_tsv(tmp_path):
    """parse_cluster_tsv produces DataFrame with correct columns and values."""
    from crisprbact.pangenome import parse_cluster_tsv

    tsv_content = textwrap.dedent("""\
        genome1|lt1\tgenome1|lt1
        genome1|lt1\tgenome2|lt1
        genome1|lt1\tgenome3|lt2
        genome2|lt3\tgenome2|lt3
    """)
    tsv_file = str(tmp_path / "clusters_cluster.tsv")
    with open(tsv_file, "w") as f:
        f.write(tsv_content)

    df = parse_cluster_tsv(tsv_file)

    assert isinstance(df, pd.DataFrame)
    assert set(df.columns) == {"family_id", "genome_id", "locus_tag"}
    assert len(df) == 4
    assert set(df["genome_id"].unique()) == {"genome1", "genome2", "genome3"}
    # Representative is "genome1|lt1"; parse_cluster_tsv strips the genome prefix → "lt1"
    assert df[df["family_id"] == "lt1"]["locus_tag"].tolist() == [
        "lt1", "lt1", "lt2"
    ]


def test_find_core_families_basic():
    """find_core_families filters by presence."""
    from crisprbact.pangenome import find_core_families

    # Family A: in all 3 genomes, 1 copy each → core
    # Family B: in 2/3 genomes → not core at 100% but core at 66%
    # Family C: in all 3, multi-copy in g1 → still included (no max_copies filter)
    rows = [
        # Family A
        ("famA", "g1", "lt1"),
        ("famA", "g2", "lt2"),
        ("famA", "g3", "lt3"),
        # Family B
        ("famB", "g1", "lt4"),
        ("famB", "g2", "lt5"),
        # Family C (multi-copy in g1)
        ("famC", "g1", "lt6a"),
        ("famC", "g1", "lt6b"),
        ("famC", "g1", "lt6c"),
        ("famC", "g1", "lt6d"),
        ("famC", "g1", "lt6e"),
        ("famC", "g2", "lt7"),
        ("famC", "g3", "lt8"),
    ]
    cluster_df = pd.DataFrame(rows, columns=["family_id", "genome_id", "locus_tag"])
    genome_ids = ["g1", "g2", "g3"]

    # At min_presence=1.0, famA and famC qualify (3/3 genomes)
    core = find_core_families(cluster_df, genome_ids, min_presence=1.0)
    assert len(core) == 2  # famA + famC
    coverages = [set(m.keys()) for m in core.values()]
    assert {"g1", "g2", "g3"} in coverages

    # At min_presence=0.6, famB also qualifies (2/3 = 0.67)
    core2 = find_core_families(cluster_df, genome_ids, min_presence=0.6)
    assert len(core2) == 3  # famA + famB + famC
    coverages2 = [set(m.keys()) for m in core2.values()]
    assert {"g1", "g2", "g3"} in coverages2
    assert {"g1", "g2"} in coverages2


def test_find_core_families_structure():
    """find_core_families returns correct {family_id: {genome_id: [locus_tags]}} structure."""
    from crisprbact.pangenome import find_core_families

    rows = [
        ("fam1", "g1", "lt1"),
        ("fam1", "g2", "lt2"),
    ]
    df = pd.DataFrame(rows, columns=["family_id", "genome_id", "locus_tag"])
    core = find_core_families(df, ["g1", "g2"], min_presence=1.0)

    # find_core_families assigns sequential IDs (F00001, ...) so check by structure
    assert len(core) == 1
    (fam_members,) = core.values()
    assert set(fam_members.keys()) == {"g1", "g2"}
    assert fam_members["g1"] == ["lt1"]
    assert fam_members["g2"] == ["lt2"]


@pytest.mark.skipif(
    shutil.which("mmseqs") is None,
    reason="mmseqs2 not installed",
)
def test_run_mmseqs2_skip_if_not_installed(tmp_path):
    """run_mmseqs2_easy_cluster produces a cluster TSV when mmseqs2 is available."""
    from crisprbact.pangenome import run_mmseqs2_easy_cluster

    # Write a minimal FASTA with 2 identical proteins
    fasta = str(tmp_path / "test.fasta")
    with open(fasta, "w") as f:
        f.write(">g1|lt1\nMKLAVV\n>g2|lt1\nMKLAVV\n")

    cluster_tsv = run_mmseqs2_easy_cluster(
        fasta,
        output_dir=str(tmp_path / "mmseqs_out"),
    )
    assert os.path.exists(cluster_tsv)
    assert cluster_tsv.endswith("_cluster.tsv")


def test_run_mmseqs2_raises_if_not_found(tmp_path, monkeypatch):
    """run_mmseqs2_easy_cluster raises RuntimeError when mmseqs is absent."""
    from crisprbact.pangenome import run_mmseqs2_easy_cluster

    monkeypatch.setattr("shutil.which", lambda _: None)

    with pytest.raises(RuntimeError, match="MMseqs2 not found"):
        run_mmseqs2_easy_cluster("dummy.fasta", str(tmp_path))
