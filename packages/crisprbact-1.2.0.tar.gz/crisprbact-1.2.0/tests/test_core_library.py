"""Tests for crisprbact.core_library module."""

import pytest
import pandas as pd
from Bio.Seq import Seq
from Bio.SeqFeature import SeqFeature, FeatureLocation
from Bio.SeqRecord import SeqRecord


# ---------------------------------------------------------------------------
# Helpers for building synthetic records
# ---------------------------------------------------------------------------

def _make_record_with_gene(rec_id, gene_seq, flank_len=50, gene_strand=1, locus_tag="lt1"):
    """Return a SeqRecord with a CDS gene embedded in A-flanks.

    The gene is placed at [flank_len, flank_len + len(gene_seq)] on strand=gene_strand.
    """
    flank = "A" * flank_len
    if gene_strand == 1:
        full_seq = flank + gene_seq + flank
    else:
        # Gene on minus strand: embed as given but annotate as strand=-1
        full_seq = flank + gene_seq + flank

    rec = SeqRecord(Seq(full_seq), id=rec_id, name=rec_id, description="")
    feat = SeqFeature(
        FeatureLocation(flank_len, flank_len + len(gene_seq), strand=gene_strand),
        type="CDS",
        qualifiers={"locus_tag": [locus_tag]},
    )
    rec.features.append(feat)
    return rec


# ---------------------------------------------------------------------------
# Test: find_guides_for_family
# ---------------------------------------------------------------------------

def test_find_guides_for_family_finds_guides():
    """find_guides_for_family returns guides for a known NGG PAM site."""
    from crisprbact.core_library import find_guides_for_family

    # Gene with a CCN on the + strand (= NGG on revcomp), targeting - strand gene
    # For a + strand gene, we want to target the coding (+) strand → search revcomp for NGG
    # Place an NGG at a known position on the coding strand revcomp
    # Gene sequence (coding strand = +):
    # We'll put CC (= revcomp GG) at a specific position in the + strand
    # so that searching revcomp for GG finds it.
    gene_len = 80
    # Position 30 in the gene (pos 30+50=80 in full record):
    # Let's put CC at gene position 55 (GG on revcomp position gene_len-57)
    gene_seq_list = ["A"] * gene_len
    gene_seq_list[55] = "C"
    gene_seq_list[56] = "C"
    gene_seq = "".join(gene_seq_list)

    rec = _make_record_with_gene("genome1", gene_seq, flank_len=50, gene_strand=1)
    all_records = {"genome1": [rec]}
    family_members = {"genome1": ["lt1"]}

    df = find_guides_for_family(family_members, all_records)

    assert isinstance(df, pd.DataFrame)
    # At minimum, some guides should be found (at the CC position = NGG on revcomp)
    assert len(df) > 0
    assert "guide" in df.columns
    assert "genome_id" in df.columns
    assert "locus_tag" in df.columns
    assert "score" in df.columns
    assert df["genome_id"].iloc[0] == "genome1"
    assert df["locus_tag"].iloc[0] == "lt1"
    assert all(len(g) == 20 for g in df["guide"])


def test_find_guides_for_family_minus_strand_gene():
    """find_guides_for_family finds guides for a minus-strand gene."""
    from crisprbact.core_library import find_guides_for_family

    # For a - strand gene, we search the + strand for NGG
    gene_len = 80
    gene_seq_list = ["A"] * gene_len
    gene_seq_list[30] = "G"
    gene_seq_list[31] = "G"
    gene_seq = "".join(gene_seq_list)

    rec = _make_record_with_gene("genome1", gene_seq, flank_len=50, gene_strand=-1)
    all_records = {"genome1": [rec]}
    family_members = {"genome1": ["lt1"]}

    df = find_guides_for_family(family_members, all_records)

    assert isinstance(df, pd.DataFrame)
    assert len(df) > 0
    assert all(len(g) == 20 for g in df["guide"])


def test_find_guides_for_family_empty_for_missing_locus():
    """find_guides_for_family returns empty DataFrame for unknown locus_tag."""
    from crisprbact.core_library import find_guides_for_family

    rec = _make_record_with_gene("genome1", "ATGC" * 20, flank_len=50)
    all_records = {"genome1": [rec]}
    family_members = {"genome1": ["nonexistent_lt"]}

    df = find_guides_for_family(family_members, all_records)
    assert isinstance(df, pd.DataFrame)
    assert len(df) == 0


# ---------------------------------------------------------------------------
# Test: compute_guide_coverage
# ---------------------------------------------------------------------------

def test_compute_guide_coverage():
    """compute_guide_coverage adds correct n_covered and coverage columns."""
    from crisprbact.core_library import compute_guide_coverage

    df = pd.DataFrame({
        "guide": ["AAAA", "AAAA", "BBBB", "CCCC"],
        "genome_id": ["g1", "g2", "g1", "g1"],
    })
    result = compute_guide_coverage(df, n_genomes=4)

    assert "n_covered" in result.columns
    assert "coverage" in result.columns

    aaaa = result[result["guide"] == "AAAA"]["n_covered"].iloc[0]
    assert aaaa == 2
    assert result[result["guide"] == "AAAA"]["coverage"].iloc[0] == pytest.approx(0.5)

    bbbb = result[result["guide"] == "BBBB"]["n_covered"].iloc[0]
    assert bbbb == 1
    assert result[result["guide"] == "BBBB"]["coverage"].iloc[0] == pytest.approx(0.25)


# ---------------------------------------------------------------------------
# Test: preselect_by_coverage
# ---------------------------------------------------------------------------

def test_preselect_by_coverage_keeps_high_coverage():
    """preselect_by_coverage keeps guides near maximum coverage."""
    from crisprbact.core_library import preselect_by_coverage

    df = pd.DataFrame({
        "guide": ["A"] * 3 + ["B"] * 3 + ["C"] * 3,
        "genome_id": ["g1", "g2", "g3"] * 3,
        "coverage": [1.0] * 3 + [0.5] * 3 + [0.25] * 3,
    })
    result = preselect_by_coverage(df, n_genomes=4, min_guides=1)

    # Only guide A has max coverage (1.0), should be kept
    assert set(result["guide"].unique()).issuperset({"A"})


def test_preselect_by_coverage_rescue_when_few_guides():
    """preselect_by_coverage relaxes threshold to ensure min_guides."""
    from crisprbact.core_library import preselect_by_coverage

    # Only 2 unique guides, we request min_guides=5 → rescue kicks in
    df = pd.DataFrame({
        "guide": ["A", "B"],
        "genome_id": ["g1", "g2"],
        "coverage": [1.0, 0.5],
    })
    result = preselect_by_coverage(df, n_genomes=2, min_guides=5)
    # With only 2 guides available, rescue includes all
    assert result["guide"].nunique() == 2


# ---------------------------------------------------------------------------
# Test: compute_global_penalty_score
# ---------------------------------------------------------------------------

def test_compute_global_penalty_score_range():
    """compute_global_penalty_score produces GPS in expected range."""
    from crisprbact.core_library import compute_global_penalty_score

    df = pd.DataFrame({
        "guide": ["A", "B", "C"],
        "off_11_gene_score": [0.0, 0.5, 1.0],
        "off_9_prom_score": [0.0, 0.5, 1.0],
        "score": [1.0, 0.5, 0.0],
        "coverage": [1.0, 0.5, 0.0],
    })
    result = compute_global_penalty_score(df)

    assert "gps" in result.columns
    # GPS should be finite
    assert result["gps"].notna().all()
    # Best guide (A) should have GPS=0+0+0=0
    gps_A = result[result["guide"] == "A"]["gps"].iloc[0]
    assert gps_A == pytest.approx(0.0)
    # Worst guide (C) should have GPS=1+1+1=3
    gps_C = result[result["guide"] == "C"]["gps"].iloc[0]
    assert gps_C == pytest.approx(3.0)


def test_compute_global_penalty_score_single_guide():
    """compute_global_penalty_score handles single guide (no variation)."""
    from crisprbact.core_library import compute_global_penalty_score

    df = pd.DataFrame({
        "guide": ["A"],
        "off_11_gene_score": [0.5],
        "off_9_prom_score": [0.3],
        "score": [0.7],
        "coverage": [0.8],
    })
    result = compute_global_penalty_score(df)
    assert "gps" in result.columns
    assert result["gps"].notna().all()


# ---------------------------------------------------------------------------
# Test: select_top_guides
# ---------------------------------------------------------------------------

def test_select_top_guides_selects_n():
    """select_top_guides returns exactly n guides sorted by GPS."""
    from crisprbact.core_library import select_top_guides

    df = pd.DataFrame({
        "guide": list("ABCDE"),
        "gps": [0.5, 0.1, 0.9, 0.2, 0.8],
        "score": [0.5, 0.9, 0.1, 0.7, 0.2],
        "coverage": [1.0, 1.0, 1.0, 1.0, 1.0],
        "genome_id": ["g1", "g1", "g1", "g1", "g1"],
    })
    result = select_top_guides(df, n=3, coverage_threshold=None)

    assert len(result) == 3
    # Should be sorted by GPS ascending (B=0.1, D=0.2, A=0.5)
    assert result.iloc[0]["guide"] == "B"
    assert result.iloc[1]["guide"] == "D"
    assert result.iloc[2]["guide"] == "A"


def test_select_top_guides_rescue():
    """select_top_guides adds a 4th guide when collective coverage is low."""
    from crisprbact.core_library import select_top_guides

    # 4 guides but top 3 each cover only g1; guide D covers g2
    df = pd.DataFrame({
        "guide": ["A", "A", "B", "B", "C", "C", "D"],
        "gps":   [0.1, 0.1, 0.2, 0.2, 0.3, 0.3, 0.4],
        "score": [0.9, 0.9, 0.8, 0.8, 0.7, 0.7, 0.6],
        "coverage": [0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5],
        "genome_id": ["g1", "g1", "g1", "g1", "g1", "g1", "g2"],
    })
    # Top 3 (A, B, C) cover only g1 → collective coverage = 1/2 = 0.5 < 0.8
    result = select_top_guides(df, n=3, coverage_threshold=0.8, n_genomes=2)

    # Should have selected 4 guides (rescue triggered)
    assert len(result) == 4
    assert "D" in result["guide"].values


def test_select_top_guides_no_rescue_when_sufficient():
    """select_top_guides does not add a 4th guide when coverage is sufficient."""
    from crisprbact.core_library import select_top_guides

    df = pd.DataFrame({
        "guide": ["A", "B", "C"],
        "gps":   [0.1, 0.2, 0.3],
        "score": [0.9, 0.8, 0.7],
        "coverage": [1.0, 1.0, 1.0],
        "genome_id": ["g1", "g2", "g3"],
    })
    result = select_top_guides(df, n=3, coverage_threshold=0.8, n_genomes=3)
    assert len(result) == 3  # no rescue needed


# ---------------------------------------------------------------------------
# Test: compute_guide_coverage_by_match
# ---------------------------------------------------------------------------

def test_compute_guide_coverage_by_match():
    """compute_guide_coverage_by_match counts genomes with perfect 20nt match."""
    from crisprbact.core_library import compute_guide_coverage_by_match

    guide = "A" * 20
    # Mock off-target dicts: guide present in g1 (plus), g2 (minus), absent in g3
    off_dics_per_genome = {
        "g1": {
            "off_plus": {20: {guide: ["pos1"]}},
            "off_minus": {20: {}},
        },
        "g2": {
            "off_plus": {20: {}},
            "off_minus": {20: {guide: ["pos2"]}},
        },
        "g3": {
            "off_plus": {20: {}},
            "off_minus": {20: {}},
        },
    }
    df = pd.DataFrame({"guide": [guide, guide], "genome_id": ["g1", "g2"]})
    result = compute_guide_coverage_by_match(df, off_dics_per_genome, n_genomes=3)

    assert "n_covered" in result.columns
    assert "coverage" in result.columns
    assert result["n_covered"].iloc[0] == 2
    assert result["coverage"].iloc[0] == pytest.approx(2 / 3)


# ---------------------------------------------------------------------------
# Test: find_rna_families
# ---------------------------------------------------------------------------

def _make_record_with_rna(rec_id, gene_seq, flank_len=50, gene_strand=1,
                          locus_tag="rna1", feat_type="rRNA"):
    """Return a SeqRecord with an RNA feature embedded in A-flanks."""
    flank = "A" * flank_len
    full_seq = flank + gene_seq + flank
    rec = SeqRecord(Seq(full_seq), id=rec_id, name=rec_id, description="")
    feat = SeqFeature(
        FeatureLocation(flank_len, flank_len + len(gene_seq), strand=gene_strand),
        type=feat_type,
        qualifiers={"locus_tag": [locus_tag], "gene": ["testRNA"]},
    )
    rec.features.append(feat)
    return rec


def test_find_rna_families_basic():
    """find_rna_families clusters RNA features sharing guides."""
    from crisprbact.core_library import find_rna_families
    from crisprbact.off_target_dict import get_off_dics
    from collections import defaultdict

    # Create two genomes each with an rRNA containing a CC (NGG on revcomp)
    gene_len = 80
    gene_seq_list = ["A"] * gene_len
    gene_seq_list[55] = "C"
    gene_seq_list[56] = "C"
    gene_seq = "".join(gene_seq_list)

    rec1 = _make_record_with_rna("g1", gene_seq, locus_tag="rrs1", feat_type="rRNA")
    rec2 = _make_record_with_rna("g2", gene_seq, locus_tag="rrs2", feat_type="rRNA")

    all_records = {"g1": [rec1], "g2": [rec2]}
    genome_ids = ["g1", "g2"]

    # Build precomputed caches
    lt_to_feat_per_genome = {}
    seq_cache = {}
    for gid, recs in all_records.items():
        lt_map = {}
        for rec in recs:
            seq_cache[rec.id] = {
                "fwd": str(rec.seq),
                "rev": str(rec.seq.reverse_complement()),
            }
            for feat in rec.features:
                if feat.type in ("CDS", "gene", "ncRNA", "rRNA", "tRNA"):
                    lt = feat.qualifiers.get("locus_tag", [None])[0]
                    if lt:
                        lt_map[lt] = (rec, feat)
        lt_to_feat_per_genome[gid] = lt_map

    # Build off-target dicts
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdir:
        off_dics_per_genome = {}
        for gid, recs in all_records.items():
            off_dics_per_genome[gid] = get_off_dics(
                recs, ref_name=gid, cache_dir=tmpdir
            )

        rna_families, rna_candidates = find_rna_families(
            all_records, genome_ids, lt_to_feat_per_genome, seq_cache,
            off_dics_per_genome, min_presence=0.5,
        )

    # Should find at least one RNA family
    assert len(rna_families) > 0

    # Family IDs should be R-prefixed
    for fid in rna_families:
        assert fid.startswith("R")

    # The family should cover both genomes (same sequence → same guides)
    fid = list(rna_families.keys())[0]
    assert "g1" in rna_families[fid]
    assert "g2" in rna_families[fid]

    # Candidates should have guides
    assert fid in rna_candidates
    assert len(rna_candidates[fid]) > 0


# ---------------------------------------------------------------------------
# Slow integration test
# ---------------------------------------------------------------------------

@pytest.mark.slow
def test_generate_core_library_four_ecoli(four_ecoli_gbks):
    """generate_core_library runs end-to-end with four E. coli strains."""
    from crisprbact.core_library import generate_core_library
    from tests.conftest import PERSISTENT_OFF_DICS_DIR, MMSEQS_CLUSTER_CACHE

    lib = generate_core_library(
        four_ecoli_gbks,
        n=3,
        min_presence=0.9,
        cache_dir=PERSISTENT_OFF_DICS_DIR,
        cluster_tsv_cache=MMSEQS_CLUSTER_CACHE,
        coverage_threshold=0.8,
        badseeds=[],
    )

    assert isinstance(lib, pd.DataFrame)
    assert len(lib) > 0

    expected_cols = [
        "guide", "family_id", "coverage", "gps",
        "off_11_gene_score", "off_9_prom_score",
        "mean_score", "inbadseeds", "feature_type",
    ]
    for col in expected_cols:
        assert col in lib.columns, f"Missing column: {col}"

    # All guides should have valid coverage (> 0)
    assert (lib["coverage"] > 0).all()

    # Most guides should have high coverage; some rescue guides may have
    # lower individual coverage while improving collective family coverage.
    assert lib["coverage"].mean() >= 0.8

    # GPS should be finite
    assert lib["gps"].notna().all()

    # Each family should have at most n+1 guides (n + possible rescue)
    assert lib.groupby("family_id")["guide"].count().max() <= 4

    # Should cover many core gene families (E. coli strains share ~3000+ core genes)
    n_families = lib["family_id"].nunique()
    assert n_families > 100  # Conservative lower bound
