import os

import pandas as pd
import pytest
from Bio import SeqIO
from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord


DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
GENOMES_DIR = os.path.join(DATA_DIR, "genomes")
OUTPUT_DIR = os.path.join(os.path.dirname(__file__), "output")
CORE_LIBRARY_CACHE = os.path.join(DATA_DIR, "core_library.csv")
CORE_REPORT_PATH = os.path.join(OUTPUT_DIR, "core_report.html")
CORE_STRAINS_DIR = os.path.join(OUTPUT_DIR, "core_strains")
# Persistent caches for slow tests (kept between runs to speed up reruns)
PERSISTENT_OFF_DICS_DIR = os.path.join(DATA_DIR, "off_dics")
MMSEQS_CLUSTER_CACHE = os.path.join(DATA_DIR, "mmseqs_cluster.tsv")


# ---------------------------------------------------------------------------
# Shared test helpers (importable from test files)
# ---------------------------------------------------------------------------


def make_record(seq_str, rec_id="rec1", features=None, organism="Unknown"):
    """Create a minimal SeqRecord for testing."""
    rec = SeqRecord(
        Seq(seq_str),
        id=rec_id,
        name=rec_id,
        description="",
        annotations={"molecule_type": "DNA", "organism": organism},
    )
    if features:
        rec.features = features
    return rec


def assert_has_columns(df, cols):
    """Assert that a DataFrame has all expected columns."""
    for col in cols:
        assert col in df.columns, f"Missing column: {col}"


@pytest.fixture(scope="session")
def mg1655_gbk():
    """Path to E. coli MG1655 GenBank file."""
    path = os.path.join(GENOMES_DIR, "U00096.gb")
    if not os.path.exists(path):
        pytest.skip("MG1655 genome file not found at tests/data/genomes/U00096.gb")
    return path


@pytest.fixture(scope="session")
def mg1655_records(mg1655_gbk):
    """Parsed SeqRecords from MG1655 GenBank file."""
    return list(SeqIO.parse(mg1655_gbk, "genbank"))


@pytest.fixture(scope="session")
def mg1655_10kb_gbk(mg1655_gbk):
    """Path to the first 10 kb of the MG1655 genome (fast unit tests).

    Generated from U00096.gb on first use and cached in tests/data/genomes/.
    """
    path = os.path.join(GENOMES_DIR, "mg1655_10kb.gb")
    if not os.path.exists(path):
        from Bio import SeqIO as _SeqIO

        records = list(_SeqIO.parse(mg1655_gbk, "genbank"))
        sliced = records[0][0:10000]
        sliced.annotations["molecule_type"] = "DNA"
        os.makedirs(GENOMES_DIR, exist_ok=True)
        _SeqIO.write(sliced, path, "genbank")
    return path


@pytest.fixture(scope="session")
def mg1655_10kb_records(mg1655_10kb_gbk):
    """Parsed SeqRecords from the 10 kb MG1655 genome slice."""
    return list(SeqIO.parse(mg1655_10kb_gbk, "genbank"))


@pytest.fixture(scope="session")
def mg1655_10kb_off_dics_dir(tmp_path_factory):
    """Shared off-target dict cache for the 10 kb genome (built once per session)."""
    return str(tmp_path_factory.mktemp("off_dics_10kb"))


@pytest.fixture(scope="session")
def mg1655_10kb_full_library(mg1655_10kb_gbk, mg1655_10kb_off_dics_dir):
    """Full guide library for the 10 kb genome slice, computed once per session."""
    from crisprbact.addon_library import generate_addon_library

    return generate_addon_library(
        ref_file=mg1655_10kb_gbk,
        existing_library=pd.DataFrame({"guide": []}),
        n=5,
        cache_dir=mg1655_10kb_off_dics_dir,
        badseeds=[],
    )


@pytest.fixture(scope="session")
def sakai_gbk():
    """Path to E. coli Sakai (O157:H7) GenBank file."""
    path = os.path.join(GENOMES_DIR, "sakai.gb")
    if not os.path.exists(path):
        pytest.skip("Sakai genome file not found at tests/data/genomes/sakai.gb")
    return path


@pytest.fixture(scope="session")
def ecoli_07_3722_gbk():
    """Path to E. coli 07-3722 GenBank file."""
    path = os.path.join(GENOMES_DIR, "07_3722.gb")
    if not os.path.exists(path):
        pytest.skip("07_3722 genome file not found at tests/data/genomes/07_3722.gb")
    return path


@pytest.fixture(scope="session")
def etec_h10407_gbk():
    """Path to E. coli ETEC H10407 GenBank file."""
    path = os.path.join(GENOMES_DIR, "ETEC H10407.gb")
    if not os.path.exists(path):
        pytest.skip(
            "ETEC H10407 genome file not found at tests/data/genomes/ETEC H10407.gb"
        )
    return path


@pytest.fixture(scope="session")
def four_ecoli_gbks(mg1655_gbk, sakai_gbk, ecoli_07_3722_gbk, etec_h10407_gbk):
    """Paths to all four E. coli GenBank files."""
    return [mg1655_gbk, sakai_gbk, ecoli_07_3722_gbk, etec_h10407_gbk]


@pytest.fixture(scope="session")
def four_ecoli_core_library(four_ecoli_gbks, tmp_path_factory):
    """Generate a core library from four E. coli strains and write output files.

    Always calls generate_core_library() (session-scoped, so runs once per
    test session) and writes:
      - tests/data/core_library.csv  — the library CSV
      - tests/output/core_report.html — the HTML quality report
      - tests/output/core_strains/   — per-strain CSV files
    """
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    from crisprbact.core_library import generate_core_library

    library = generate_core_library(
        four_ecoli_gbks,
        n=3,
        min_presence=0.9,
        cache_dir=PERSISTENT_OFF_DICS_DIR,
        cluster_tsv_cache=MMSEQS_CLUSTER_CACHE,
        coverage_threshold=0.8,
        badseeds=[],
        output_csv=CORE_LIBRARY_CACHE,
        output_report=CORE_REPORT_PATH,
        output_strains_dir=CORE_STRAINS_DIR,
    )
    return library
