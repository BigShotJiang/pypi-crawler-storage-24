"""Tests for crisprbact.off_target.

Covers extract_records, extract_features (Priority 1c fix), compute_off_target_df,
and get_off_target_pos using small synthetic genomes.
"""

import io

import pandas as pd
import pytest
from Bio.Seq import Seq
from Bio.SeqFeature import FeatureLocation, SeqFeature
from Bio.SeqRecord import SeqRecord

from crisprbact.off_target import (
    FEATURE_TYPES,
    compute_off_target_df,
    extract_features,
    extract_records,
    get_off_target_pos,
)
from tests.conftest import make_record


# ---------------------------------------------------------------------------
# extract_records
# ---------------------------------------------------------------------------

class TestExtractRecords:
    def test_non_empty_iterable(self):
        """Returns a list when the iterable has records."""
        rec = make_record("ATGCATGC")
        result = extract_records(iter([rec]))
        assert result is not None
        assert len(result) == 1
        assert result[0].id == rec.id

    def test_empty_iterable_returns_none(self):
        """Returns None when the iterable is empty."""
        result = extract_records(iter([]))
        assert result is None

    def test_multiple_records(self):
        """Returns all records from the iterable."""
        recs = [make_record("ATGC", rec_id=f"r{i}") for i in range(5)]
        result = extract_records(iter(recs))
        assert len(result) == 5


# ---------------------------------------------------------------------------
# extract_features — Priority 1c fix: no real gene feature is dropped
# ---------------------------------------------------------------------------

class TestExtractFeatures:
    def _make_genome_with_features(self, n_cds=3, extra_types=None):
        """Build a SeqRecord with n_cds CDS features and optional extras."""
        seq_len = 1000
        rec = SeqRecord(Seq("A" * seq_len), id="chr1", description="")
        for i in range(n_cds):
            rec.features.append(
                SeqFeature(
                    FeatureLocation(i * 100, i * 100 + 80, strand=1),
                    type="CDS",
                    qualifiers={"locus_tag": [f"lt{i}"]},
                )
            )
        if extra_types:
            for j, ftype in enumerate(extra_types):
                rec.features.append(
                    SeqFeature(
                        FeatureLocation(900 + j * 10, 900 + j * 10 + 5, strand=1),
                        type=ftype,
                    )
                )
        return rec

    def test_cds_features_all_extracted(self):
        """All CDS features are returned; none are silently dropped (Priority 1c)."""
        n_cds = 5
        rec = self._make_genome_with_features(n_cds=n_cds)
        df = extract_features([rec])
        assert df is not None
        assert len(df) == n_cds

    def test_only_feature_types_extracted(self):
        """Only CDS/ncRNA/rRNA/tRNA are returned; source and gene features are filtered."""
        rec = self._make_genome_with_features(n_cds=2)
        # Add a 'gene' and 'source' feature that should NOT appear
        rec.features.append(
            SeqFeature(FeatureLocation(500, 600, strand=1), type="gene")
        )
        rec.features.append(
            SeqFeature(FeatureLocation(0, 1000, strand=1), type="source")
        )
        df = extract_features([rec])
        assert len(df) == 2
        assert set(df["type"].unique()).issubset(set(FEATURE_TYPES))

    def test_mixed_feature_types(self):
        """CDS, ncRNA, rRNA, tRNA are all included; others excluded."""
        rec = self._make_genome_with_features(
            n_cds=1,
            extra_types=["ncRNA", "rRNA", "tRNA", "misc_feature"],
        )
        df = extract_features([rec])
        # 1 CDS + ncRNA + rRNA + tRNA = 4; misc_feature excluded
        assert len(df) == 4

    def test_no_features_returns_empty_df(self):
        """Record with no FEATURE_TYPES features → empty DataFrame."""
        rec = SeqRecord(Seq("ATGC" * 100), id="empty", description="")
        rec.features.append(
            SeqFeature(FeatureLocation(0, 100, strand=1), type="source")
        )
        df = extract_features([rec])
        # When the list is empty, the zip(*[]) path in extract_features
        # produces an empty DataFrame (or None if f_list stays empty).
        assert df is None or (isinstance(df, pd.DataFrame) and len(df) == 0)

    def test_none_input_returns_none(self):
        """None input returns None."""
        assert extract_features(None) is None

    def test_df_has_expected_columns(self):
        """Result DataFrame has required columns."""
        rec = self._make_genome_with_features(n_cds=2)
        df = extract_features([rec])
        for col in ["start", "end", "strand", "type", "feature", "recid"]:
            assert col in df.columns

    def test_multiple_records(self):
        """Features are collected across multiple records."""
        rec1 = self._make_genome_with_features(n_cds=2)
        rec2 = self._make_genome_with_features(n_cds=3)
        rec2.id = "chr2"
        df = extract_features([rec1, rec2])
        assert len(df) == 5


# ---------------------------------------------------------------------------
# get_off_target_pos and compute_off_target_df
# ---------------------------------------------------------------------------

class TestGetOffTargetPos:
    def test_exact_match_found(self):
        """A guide with an exact NGG match in the genome is found."""
        guide = "ATGCATGCATGCATGCATGC"  # 20 nt
        pam = "AGG"
        seq = "C" * 30 + guide + pam + "T" * 30
        rec = make_record(seq, rec_id="chr1")

        df = get_off_target_pos(guide, [rec], seed_size=20)
        assert df is not None
        assert len(df) >= 1
        # The exact match should have the full 20-nt perfect match
        assert any(guide in row for row in df["longest_perfect_match"].values)

    def test_no_match_when_no_pam(self):
        """A guide with no NGG site in the genome returns None or empty."""
        guide = "ATGCATGCATGCATGCATGC"
        seq = "A" * 100  # No NGG
        rec = make_record(seq, rec_id="chr1")
        df = get_off_target_pos(guide, [rec], seed_size=20)
        assert df is None or len(df) == 0

    def test_none_records_returns_none(self):
        """records=None returns None."""
        result = get_off_target_pos("ATGCATGCATGCATGCATGC", None, seed_size=8)
        assert result is None

    def test_result_has_expected_columns(self):
        """Result DataFrame has all required columns."""
        guide = "ATGCATGCATGCATGCATGC"
        pam = "CGG"
        seq = "C" * 30 + guide + pam + "T" * 30
        rec = make_record(seq)
        df = get_off_target_pos(guide, [rec], seed_size=20)
        if df is not None and len(df) > 0:
            for col in ["start", "end", "pampos", "strand", "recid",
                        "longest_perfect_match", "pam_seq"]:
                assert col in df.columns


class TestComputeOffTargetDf:
    def test_returns_dataframe_with_features_column(self):
        """compute_off_target_df adds a 'features' column."""
        guide = "ATGCATGCATGCATGCATGC"
        pam = "AGG"
        seq = "C" * 30 + guide + pam + "T" * 30
        rec = make_record(seq, rec_id="chr1")
        feature_df = extract_features([rec])  # None or empty (no CDS)
        if feature_df is None:
            feature_df = pd.DataFrame(columns=["start", "end", "strand", "type",
                                                "feature", "recid"])

        df = compute_off_target_df(guide, 20, [rec], feature_df)
        assert df is not None
        assert "features" in df.columns

    def test_empty_when_no_off_targets(self):
        """Returns None or empty DataFrame when there are no off-target hits."""
        guide = "ATGCATGCATGCATGCATGC"
        seq = "A" * 100
        rec = make_record(seq)
        feature_df = pd.DataFrame(columns=["start", "end", "strand", "type",
                                            "feature", "recid"])
        result = compute_off_target_df(guide, 20, [rec], feature_df)
        assert result is None or len(result) == 0
