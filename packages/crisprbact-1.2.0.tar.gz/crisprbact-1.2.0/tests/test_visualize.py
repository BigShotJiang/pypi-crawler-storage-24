import os

import pandas as pd
import pytest

from crisprbact.library import generate_library
from crisprbact.visualize import (
    _badseed_summary_html,
    _gene_coverage_section,
    _genome_summary_html,
    _glossary_html,
    _off_target_stats_html,
    _position_summary_html,
    _unified_title_html,
    generate_report,
    inspect_gene,
    inspect_gene_summary,
    plot_genome_coverage,
    plot_guides_per_gene,
    plot_off_target_distribution,
    plot_score_distribution,
)
from tests.conftest import DATA_DIR, OUTPUT_DIR, make_record

LIBRARY_CACHE = os.path.join(DATA_DIR, "mg1655_library.csv")
CORE_REPORT_PATH = os.path.join(OUTPUT_DIR, "core_report.html")
CORE_STRAINS_DIR = os.path.join(OUTPUT_DIR, "core_strains")


@pytest.fixture(scope="session", autouse=True)
def ensure_output_dir():
    """Create the output directory for manual inspection files."""
    os.makedirs(OUTPUT_DIR, exist_ok=True)


@pytest.fixture(scope="session")
def mg1655_library(mg1655_gbk, tmp_path_factory):
    """Generate (and cache) a library from MG1655. Always regenerated."""
    cache_dir = str(tmp_path_factory.mktemp("off_dics"))
    return generate_library(
        mg1655_gbk, n=5, cache_dir=cache_dir, output_csv=LIBRARY_CACHE
    )


@pytest.mark.slow
class TestPlots:
    """Test plot functions return matplotlib Figure objects and save PNGs."""

    def test_plot_score_distribution(self, mg1655_library):
        fig = plot_score_distribution(mg1655_library)
        assert fig is not None
        assert type(fig).__name__ == "Figure"
        fig.savefig(os.path.join(OUTPUT_DIR, "score_distribution.png"), dpi=150)

    def test_plot_guides_per_gene(self, mg1655_library):
        fig = plot_guides_per_gene(mg1655_library)
        assert fig is not None
        assert type(fig).__name__ == "Figure"
        fig.savefig(os.path.join(OUTPUT_DIR, "guides_per_gene.png"), dpi=150)

    def test_plot_off_target_distribution(self, mg1655_library):
        fig = plot_off_target_distribution(mg1655_library)
        assert fig is not None
        assert type(fig).__name__ == "Figure"
        fig.savefig(os.path.join(OUTPUT_DIR, "off_target_distribution.png"), dpi=150)

    def test_plot_genome_coverage(self, mg1655_library, mg1655_records):
        fig = plot_genome_coverage(mg1655_library, mg1655_records)
        assert fig is not None
        assert type(fig).__name__ == "Figure"
        fig.savefig(os.path.join(OUTPUT_DIR, "genome_coverage.png"), dpi=150)


@pytest.mark.slow
class TestInspect:
    """Test gene inspection functions with lacZ (-strand) and cynT (+strand)."""

    def test_inspect_lacZ(self, mg1655_library, mg1655_records):
        """lacZ is on the (-) strand."""
        result = inspect_gene(mg1655_library, mg1655_records, "lacZ")
        assert isinstance(result, str)
        assert "lacZ" in result
        assert "coding 5'" in result
        assert "guide  3'" in result
        assert "score:" in result
        # PAM on coding strand should be CCN (lowercase)
        assert "cc" in result.lower()
        with open(os.path.join(OUTPUT_DIR, "inspect_lacZ.txt"), "w") as f:
            f.write(result)

    def test_inspect_cynT(self, mg1655_library, mg1655_records):
        """cynT is on the (+) strand."""
        result = inspect_gene(mg1655_library, mg1655_records, "cynT")
        assert isinstance(result, str)
        assert "cynT" in result
        assert "coding 5'" in result
        assert "guide  3'" in result
        assert "score:" in result
        with open(os.path.join(OUTPUT_DIR, "inspect_cynT.txt"), "w") as f:
            f.write(result)

    def test_inspect_gene_not_found(self, mg1655_library, mg1655_records):
        result = inspect_gene(mg1655_library, mg1655_records, "nonexistent_gene")
        assert "not found" in result

    def test_inspect_gene_summary_lacZ(self, mg1655_library):
        result = inspect_gene_summary(mg1655_library, "lacZ")
        assert isinstance(result, str)
        assert "rank" in result
        assert "guide" in result
        assert "strand" in result
        with open(os.path.join(OUTPUT_DIR, "summary_lacZ.txt"), "w") as f:
            f.write(result)

    def test_inspect_gene_summary_cynT(self, mg1655_library):
        result = inspect_gene_summary(mg1655_library, "cynT")
        assert isinstance(result, str)
        assert "rank" in result
        with open(os.path.join(OUTPUT_DIR, "summary_cynT.txt"), "w") as f:
            f.write(result)

    def test_inspect_gene_summary_not_found(self, mg1655_library):
        result = inspect_gene_summary(mg1655_library, "nonexistent")
        assert "No guides found" in result


@pytest.mark.slow
class TestCoreReport:
    """Test HTML report generation for core-genome library."""

    def test_core_report_exists(self, four_ecoli_core_library):
        """Fixture generates core_report.html; verify it exists and is valid HTML."""
        assert os.path.exists(CORE_REPORT_PATH), (
            "core_report.html not found. Delete tests/data/core_library.csv "
            "to trigger regeneration."
        )
        with open(CORE_REPORT_PATH, "r") as f:
            html = f.read()

        # Basic structure
        assert "<!DOCTYPE html>" in html
        assert "<h1>" in html
        assert "Core-Genome" in html

        # Section 1: summary
        assert "Run Parameters" in html or "RUN PARAMETERS" in html
        assert "Core families found" in html
        assert "Total guides in library" in html

        # Glossary section (collapsed)
        assert "Glossary" in html
        assert "GPS" in html or "gps" in html
        assert "Global Penalty Score" in html
        assert "mean_score" in html or "Mean score" in html

        # Per-strain table
        assert "<table" in html
        assert "Genome ID" in html
        assert "CDS" in html
        # Shared helper sections
        assert "Family Coverage" in html
        assert "families covered in at least one strain" in html
        assert "families covered in all strains" in html

        # Families-without-guides block
        assert "Families Without Guides" in html or "families without guides" in html.lower()

        # Plots embedded as base64 PNGs
        assert "data:image/png;base64," in html
        assert html.count("<img") >= 3

    def test_core_library_columns(self, four_ecoli_core_library):
        """Verify the core library has the expected cross-genome columns only."""
        lib = four_ecoli_core_library
        assert isinstance(lib, pd.DataFrame)
        assert len(lib) > 0
        for col in ["guide", "family_id", "gene", "n_covered", "coverage", "gps",
                    "mean_score", "inbadseeds"]:
            assert col in lib.columns
        # Must NOT contain strain-specific columns
        for col in ["genome_id", "locus_tag", "recid", "pos", "strand"]:
            assert col not in lib.columns
        # family_id must be sequential (F00001 format), not a locus_tag
        assert lib["family_id"].str.match(r"^F\d{5}$").all()

    def test_per_strain_csvs(self, four_ecoli_core_library):
        """Verify per-strain CSV files were written with the right format."""
        assert os.path.isdir(CORE_STRAINS_DIR), (
            "core_strains/ directory not found. Delete tests/data/core_library.csv "
            "to trigger regeneration."
        )
        csv_files = [f for f in os.listdir(CORE_STRAINS_DIR) if f.endswith(".csv")]
        assert len(csv_files) > 0, "No per-strain CSV files found."

        for fname in csv_files:
            strain_df = pd.read_csv(os.path.join(CORE_STRAINS_DIR, fname))
            assert len(strain_df) > 0, f"{fname} is empty"
            for col in ["guide", "family_id", "gene", "genome_id", "locus_tag",
                        "recid", "strand", "pos", "score",
                        "ntargets", "noff_12", "noff_11_gene", "noff_9_prom",
                        "inbadseeds"]:
                assert col in strain_df.columns, f"{fname} missing column {col}"


class TestSharedHelpers:
    """Test shared HTML helper functions (fast, no genome data needed)."""

    @pytest.fixture()
    def sample_df(self):
        return pd.DataFrame({
            "guide": ["A" * 20, "C" * 20, "G" * 20, "T" * 20],
            "locus_tag": ["b0001", "b0001", "b0002", "b0003"],
            "score": [0.5, -0.1, 0.3, -0.7],
            "ntargets": [1, 3, 1, 2],
            "noff_12": [0, 1, 0, 2],
            "noff_11_gene": [0, 0, 1, 0],
            "noff_9_prom": [1, 0, 0, 0],
            "inbadseeds": [False, True, False, False],
        })

    @pytest.fixture()
    def simple_records(self):
        from Bio.SeqFeature import SeqFeature, FeatureLocation
        rec = make_record("A" * 1000, rec_id="chr1")
        rec.features = [
            SeqFeature(FeatureLocation(0, 300, 1), type="gene",
                       qualifiers={"locus_tag": ["b0001"], "gene": ["geneA"]}),
            SeqFeature(FeatureLocation(0, 300, 1), type="CDS",
                       qualifiers={"locus_tag": ["b0001"], "product": ["prodA"]}),
            SeqFeature(FeatureLocation(300, 600, -1), type="gene",
                       qualifiers={"locus_tag": ["b0002"], "gene": ["geneB"]}),
            SeqFeature(FeatureLocation(300, 600, -1), type="CDS",
                       qualifiers={"locus_tag": ["b0002"], "product": ["prodB"]}),
            SeqFeature(FeatureLocation(600, 900, 1), type="gene",
                       qualifiers={"locus_tag": ["b0003"], "gene": ["geneC"]}),
            SeqFeature(FeatureLocation(600, 900, 1), type="CDS",
                       qualifiers={"locus_tag": ["b0003"], "product": ["prodC"]}),
            SeqFeature(FeatureLocation(900, 1000, 1), type="gene",
                       qualifiers={"locus_tag": ["b0004"], "gene": ["geneD"]}),
        ]
        return [rec]

    def test_unified_title(self):
        html = _unified_title_html("Library Design", "E. coli K-12")
        assert "CRISPRbact Report: Library Design" in html
        assert "E. coli K-12" in html

    def test_genome_summary(self, simple_records):
        html = _genome_summary_html(simple_records)
        assert "1,000 bp" in html
        assert "Total genes:" in html

    def test_off_target_stats(self, sample_df):
        html = _off_target_stats_html(sample_df)
        assert "ntargets" in html
        assert "noff_12" in html
        assert '<table class="stats">' in html

    def test_off_target_stats_empty(self):
        html = _off_target_stats_html(pd.DataFrame())
        assert "No guides" in html

    def test_badseed_summary(self, sample_df):
        html = _badseed_summary_html(sample_df)
        assert "1" in html  # 1 flagged
        assert "25.0%" in html

    def test_position_summary(self, sample_df):
        df = sample_df.copy()
        df["second_half_gene"] = [True, False, False, True]
        html = _position_summary_html(df)
        assert "first half" in html
        assert "second half" in html
        assert "50.0%" in html

    def test_position_summary_missing_column(self, sample_df):
        html = _position_summary_html(sample_df)
        assert html == ""

    def test_badseed_missing_column(self):
        df = pd.DataFrame({"guide": ["AAAA"]})
        html = _badseed_summary_html(df)
        assert "not available" in html

    def test_gene_coverage_section(self, sample_df, simple_records):
        html = _gene_coverage_section(sample_df, simple_records, n=5)
        assert "3 / 4" in html  # b0001,b0002,b0003 covered, b0004 not
        assert "0 guides" in html
        # 1 uncovered gene → ≤20 → always visible (no <details>)
        assert "b0004" in html
        assert "<details>" not in html.split("0 guides")[1].split("1 guide")[0]

    def test_gene_coverage_section_collapse(self, simple_records):
        """21+ genes in a bucket → collapsed; 101+ → count only."""
        import pandas as pd
        from Bio.SeqFeature import SeqFeature, FeatureLocation
        from tests.conftest import make_record

        # Build a record with 110 genes
        rec = make_record("A" * 120000, rec_id="big")
        feats = []
        for i in range(110):
            lt = f"b{i:04d}"
            feats.append(SeqFeature(FeatureLocation(i * 1000, i * 1000 + 900, 1),
                                    type="gene", qualifiers={"locus_tag": [lt], "gene": [lt]}))
        rec.features = feats
        big_records = [rec]

        # 25 genes covered (bucket 1-guide = 25 → collapsed)
        df_25 = pd.DataFrame({"locus_tag": [f"b{i:04d}" for i in range(25)]})
        html = _gene_coverage_section(df_25, big_records)
        assert "<details>" in html  # 85 uncovered → collapsed
        assert html.count("<details>") >= 1

        # All 110 uncovered → >100 → count only, no list
        df_empty = pd.DataFrame({"locus_tag": pd.Series([], dtype=str)})
        html2 = _gene_coverage_section(df_empty, big_records)
        assert "110" in html2
        assert "<pre" not in html2  # no gene list rendered

    def test_glossary_html(self):
        html = _glossary_html(["score", "ntargets"])
        assert "<details>" in html
        assert "Glossary" in html
        assert "score" in html
        assert "ntargets" in html

    def test_glossary_html_all(self):
        html = _glossary_html()
        assert "gps" in html.lower() or "GPS" in html

    def test_glossary_empty(self):
        html = _glossary_html(["nonexistent_column"])
        assert html == ""


@pytest.mark.slow
class TestReport:
    """Test HTML report generation."""

    def test_generate_report(self, mg1655_library, mg1655_records):
        output_path = os.path.join(OUTPUT_DIR, "report.html")
        generate_report(mg1655_library, mg1655_records, n=5, output_path=output_path)

        assert os.path.exists(output_path)
        with open(output_path, "r") as f:
            html = f.read()

        assert "CRISPRbact Report: Library Design" in html
        assert "Genome Summary" in html
        assert "Library Summary" in html
        assert "Off-target Statistics" in html
        assert "Bad Seeds" in html
        assert "Gene Coverage" in html
        assert "Gene Inspection Examples" in html
        assert "Glossary" in html
        assert "Total genes:" in html
        assert "Genes covered:" in html
        assert "data:image/png;base64," in html
        assert html.count("<img") >= 3
