"""Tests for crisprbact.map_library."""

import os

import pandas as pd
import pytest
from Bio import SeqIO
from Bio.Seq import Seq
from Bio.SeqFeature import FeatureLocation, SeqFeature
from Bio.SeqRecord import SeqRecord

from crisprbact.map_library import build_pam_index, map_library
from tests.conftest import (
    DATA_DIR, GENOMES_DIR, OUTPUT_DIR, PERSISTENT_OFF_DICS_DIR,
    assert_has_columns, make_record,
)


PAM_INDEX_CACHE_DIR = DATA_DIR  # store cached pam indices with test data
MAP_REPORT_PATH = os.path.join(OUTPUT_DIR, "map_report_mg1655_on_sakai.html")
MAP_CSV_PATH = os.path.join(OUTPUT_DIR, "map_mg1655_on_sakai.csv")


_make_record = make_record


# ---------------------------------------------------------------------------
# build_pam_index unit tests
# ---------------------------------------------------------------------------

class TestBuildPamIndex:
    def test_forward_strand_ngg(self):
        """Forward strand NGG site: guide extracted correctly."""
        guide = "ATGTTCGATCGATCGATCGA"  # 20 nt
        pam = "AGG"  # NGG where N=A
        # Layout: [20 left flank] [guide] [pam] [20 right flank]
        seq = "C" * 20 + guide + pam + "G" * 20
        rec = _make_record(seq)

        index = build_pam_index([rec])

        assert guide in index
        assert len(index[guide]) == 1
        recid, strand, pam_pos, seq_window = index[guide][0]
        assert recid == "rec1"
        assert strand == "+"
        # pam_pos = position of N in NGG = 20 + 20 = 40 (0-indexed)
        assert pam_pos == 40
        # seq_window is 25bp: guide[-6:] + pam + 16bp downstream
        assert len(seq_window) == 25
        assert seq_window[0:6] == guide[-6:]  # last 6 chars of guide
        assert seq_window[6:9] == pam          # pam at positions 6:9

    def test_reverse_strand_ngg(self):
        """Minus strand NGG site: guide found in revcomp."""
        guide = "ATGTTCGATCGATCGATCGA"  # 20 nt
        pam = "AGG"
        # Build forward strand such that NGG appears on the reverse complement.
        # revcomp of pam+guide = revcomp(guide)+revcomp(pam)
        guide_rc = str(Seq(guide).reverse_complement())
        pam_rc = str(Seq(pam).reverse_complement())
        # Forward seq: [20 right flank rc] + pam_rc + guide_rc + [20 left flank rc]
        seq_fwd = "G" * 20 + pam_rc + guide_rc + "C" * 20
        # The reverse complement is: "G"*20 + guide + pam + "C"*20
        rec = _make_record(seq_fwd)

        index = build_pam_index([rec])

        assert guide in index
        recid, strand, pam_pos, seq_window = index[guide][0]
        assert strand == "-"
        assert recid == "rec1"
        # pam_pos in genome coordinates (forward strand)
        L = len(seq_fwd)
        # In revcomp: "G"*20 + guide (20nt) + pam (3nt) + "C"*20
        # N of NGG is at position 20+20=40 in revcomp → genome pos = L - 40 - 1
        revcomp_pam_start = 20 + len(guide)
        assert pam_pos == L - revcomp_pam_start - 1

    def test_no_match(self):
        """Guide not present in genome → not in index."""
        seq = "A" * 200
        rec = _make_record(seq)
        index = build_pam_index([rec])
        assert "ATGTTCGATCGATCGATCGA" not in index

    def test_custom_pam_nga(self):
        """NGA PAM finds the guide; NGG PAM does not (only A, not GG)."""
        guide = "ATGTTCGATCGATCGATCGA"
        pam_nga = "AGA"  # NGA where N=A
        seq = "C" * 20 + guide + pam_nga + "G" * 20
        rec = _make_record(seq)

        index_ngg = build_pam_index([rec], pam="NGG")
        index_nga = build_pam_index([rec], pam="NGA")

        assert guide not in index_ngg
        assert guide in index_nga

    def test_window_format_compatible_with_scoring(self):
        """Sequence window has correct layout for add_on_target_predictions."""
        guide = "ATGTTCGATCGATCGATCGA"
        pam = "TGG"
        right_flank = "ACGTACGTACGTACGTACGT"  # 20 nt
        seq = "C" * 20 + guide + pam + right_flank
        rec = _make_record(seq)

        index = build_pam_index([rec])

        assert guide in index
        _, _, _, seq_window = index[guide][0]
        # 25bp window: guide[-6:] + PAM + 16bp downstream
        # position 6 = N of PAM = "T" here
        assert seq_window[6] == pam[0]
        # positions 7-8 = GG
        assert seq_window[7:9] == "GG"
        # positions 9-24 = first 16bp of right_flank
        assert seq_window[9:25] == right_flank[:16]

    def test_multiple_records(self):
        """PAM index aggregates hits across multiple records."""
        guide = "ATGTTCGATCGATCGATCGA"
        pam = "AGG"
        seq = "C" * 20 + guide + pam + "G" * 20
        rec1 = _make_record(seq, rec_id="chr1")
        rec2 = _make_record(seq, rec_id="chr2")

        index = build_pam_index([rec1, rec2])

        assert guide in index
        recids = [entry[0] for entry in index[guide]]
        assert "chr1" in recids
        assert "chr2" in recids

    def test_edge_too_close_to_left_boundary(self):
        """PAM site within 20bp of left boundary: guide_start < 0 → skipped."""
        pam = "AGG"
        # 18 bases before PAM → pam_start = 18, guide_start = 18 - 20 = -2 < 0
        seq = "ACGTACGTACGTACGTAC" + pam + "ACGTACGTACGTACGTACGT"
        rec = _make_record(seq)
        index = build_pam_index([rec])
        assert len(index) == 0

    def test_edge_insufficient_right_flank(self):
        """PAM sites with insufficient right flank are skipped."""
        guide = "ATGTTCGATCGATCGATCGA"
        pam = "AGG"
        # Only 15 bases after PAM (need pam_len + 16 = 19), so skipped.
        seq = "C" * 20 + guide + pam + "G" * 15
        rec = _make_record(seq)
        index = build_pam_index([rec])
        assert guide not in index


# ---------------------------------------------------------------------------
# map_library unit tests
# ---------------------------------------------------------------------------

class TestMapLibraryUnit:
    def _write_genbank(self, path, seq_str, rec_id="test", features=None, organism="Unknown"):
        """Write a minimal GenBank file for testing."""
        rec = SeqRecord(
            Seq(seq_str),
            id=rec_id,
            name=rec_id,
            description="test genome",
            annotations={"molecule_type": "DNA", "organism": organism},
        )
        if features:
            rec.features = features
        SeqIO.write(rec, path, "genbank")
        return path

    def test_guide_not_in_genome(self, tmp_path):
        """Guide with no NGG site → n_matches=0, NaN genomic columns."""
        seq = "A" * 200
        gb_file = str(tmp_path / "genome.gb")
        self._write_genbank(gb_file, seq)

        guide = "ATGTTCGATCGATCGATCGA"
        csv_file = str(tmp_path / "guides.csv")
        pd.DataFrame({"guide": [guide]}).to_csv(csv_file, index=False)

        result = map_library(
            csv_file, gb_file,
            cache_dir=str(tmp_path / "off_dics"),
            badseeds=[],
        )

        assert len(result) == 1
        row = result.iloc[0]
        assert row["guide"] == guide
        assert row["n_matches"] == 0
        assert pd.isna(row["recid"])
        assert pd.isna(row["pos"])
        assert pd.isna(row["on_target_score"])
        assert pd.isna(row["score_quartile"])
        assert row["ntargets"] == 0

    def test_guide_found_in_genome(self, tmp_path):
        """Guide with one NGG match → n_matches=1, score computed."""
        guide = "ATGTTCGATCGATCGATCGA"
        pam = "AGG"
        seq = "C" * 20 + guide + pam + "G" * 20
        gb_file = str(tmp_path / "genome.gb")
        self._write_genbank(gb_file, seq)

        csv_file = str(tmp_path / "guides.csv")
        pd.DataFrame({"guide": [guide]}).to_csv(csv_file, index=False)

        result = map_library(
            csv_file, gb_file,
            cache_dir=str(tmp_path / "off_dics"),
            badseeds=[],
        )

        assert len(result) == 1
        row = result.iloc[0]
        assert row["guide"] == guide
        assert row["n_matches"] == 1
        assert row["recid"] == "test"
        assert row["strand"] == "+"
        assert not pd.isna(row["on_target_score"])
        assert row["score_quartile"] in [1, 2, 3, 4]
        assert row["ntargets"] == 1

    def test_multi_match_guide(self, tmp_path):
        """Guide matching at 2 positions → 2 rows with same n_matches."""
        guide = "ATGTTCGATCGATCGATCGA"
        pam = "AGG"
        unit = "C" * 20 + guide + pam + "G" * 20
        seq = unit + "N" * 10 + unit  # guide appears twice
        # Replace N with A for valid DNA
        seq = seq.replace("N", "A")
        gb_file = str(tmp_path / "genome.gb")
        self._write_genbank(gb_file, seq)

        csv_file = str(tmp_path / "guides.csv")
        pd.DataFrame({"guide": [guide]}).to_csv(csv_file, index=False)

        result = map_library(
            csv_file, gb_file,
            cache_dir=str(tmp_path / "off_dics"),
            badseeds=[],
        )

        assert len(result) == 2
        assert (result["n_matches"] == 2).all()
        assert (result["ntargets"] == 2).all()

    def test_output_columns(self, tmp_path):
        """All expected output columns are present."""
        seq = "A" * 200
        gb_file = str(tmp_path / "genome.gb")
        self._write_genbank(gb_file, seq)

        csv_file = str(tmp_path / "guides.csv")
        pd.DataFrame({"guide": ["ATGTTCGATCGATCGATCGA"]}).to_csv(csv_file, index=False)

        result = map_library(
            csv_file, gb_file,
            cache_dir=str(tmp_path / "off_dics"),
            badseeds=[],
        )

        assert_has_columns(result, [
            "guide", "n_matches", "recid", "strand", "pos",
            "locus_tag", "gene", "gene_ori", "targets_coding_strand",
            "on_target_score", "score_quartile",
            "ntargets", "noff_12", "noff_11_gene", "noff_9_prom",
            "inbadseeds",
        ])

    def test_pam_index_cache(self, tmp_path):
        """PAM index is saved and loaded from cache file."""
        guide = "ATGTTCGATCGATCGATCGA"
        pam = "AGG"
        seq = "C" * 20 + guide + pam + "G" * 20
        gb_file = str(tmp_path / "genome.gb")
        self._write_genbank(gb_file, seq)

        csv_file = str(tmp_path / "guides.csv")
        pd.DataFrame({"guide": [guide]}).to_csv(csv_file, index=False)

        cache_file = str(tmp_path / "pam_index.pkl")
        assert not os.path.exists(cache_file)

        # First call: builds and caches
        result1 = map_library(
            csv_file, gb_file,
            cache_dir=str(tmp_path / "off_dics"),
            badseeds=[],
            pam_index_cache=cache_file,
        )
        assert os.path.exists(cache_file)

        # Second call: loads from cache
        result2 = map_library(
            csv_file, gb_file,
            cache_dir=str(tmp_path / "off_dics"),
            badseeds=[],
            pam_index_cache=cache_file,
        )
        assert result1["n_matches"].iloc[0] == result2["n_matches"].iloc[0]
        assert result1["pos"].iloc[0] == result2["pos"].iloc[0]

    def test_custom_pam_fewer_matches(self, tmp_path):
        """NGA PAM finds different matches than NGG."""
        guide_ngg = "ATGTTCGATCGATCGATCGA"
        guide_nga = "TTGCCGATCGATCGATCGAT"
        seq = (
            "C" * 20 + guide_ngg + "AGG" + "G" * 10   # NGG site
            + "C" * 20 + guide_nga + "AGA" + "G" * 20  # NGA site
        )
        gb_file = str(tmp_path / "genome.gb")
        self._write_genbank(gb_file, seq)

        csv_file = str(tmp_path / "guides.csv")
        pd.DataFrame({"guide": [guide_ngg, guide_nga]}).to_csv(csv_file, index=False)

        result_ngg = map_library(
            csv_file, gb_file,
            pam="NGG",
            cache_dir=str(tmp_path / "off_dics_ngg"),
            badseeds=[],
        )
        result_nga = map_library(
            csv_file, gb_file,
            pam="NGA",
            cache_dir=str(tmp_path / "off_dics_nga"),
            badseeds=[],
        )

        # guide_ngg found with NGG, not with NGA
        ngg_row = result_ngg[result_ngg["guide"] == guide_ngg].iloc[0]
        nga_row = result_nga[result_nga["guide"] == guide_ngg].iloc[0]
        assert ngg_row["n_matches"] >= 1
        assert nga_row["n_matches"] == 0

    def test_score_quartile_boundaries(self, tmp_path):
        """Score quartile uses fixed boundaries from predict.SCORE_BOUNDARIES."""
        from crisprbact.map_library import _apply_score_quartile
        from crisprbact.predict import SCORE_BOUNDARIES
        q1, q2, q3 = SCORE_BOUNDARIES
        scores = [q1 + 0.1, (q1 + q2) / 2, (q2 + q3) / 2, q3 - 0.1, float("nan")]
        quartiles = _apply_score_quartile(scores)
        assert quartiles[0] == 1   # above q1
        assert quartiles[1] == 2   # between q1 and q2
        assert quartiles[2] == 3   # between q2 and q3
        assert quartiles[3] == 4   # below q3
        assert pd.isna(quartiles[4])


# ---------------------------------------------------------------------------
# Integration test (slow)
# ---------------------------------------------------------------------------

@pytest.mark.slow
def test_map_mg1655_library_on_sakai(sakai_gbk):
    """Map MG1655 library guides against Sakai genome.

    Most MG1655 guides should also have NGG sites in Sakai (both E. coli),
    all matched guides should get a valid on-target score.
    """
    mg1655_csv = os.path.join(DATA_DIR, "mg1655_library.csv")
    if not os.path.exists(mg1655_csv):
        pytest.skip("mg1655_library.csv not found in tests/data/")

    pam_index_cache = os.path.join(DATA_DIR, "pam_index_sakai.pkl")
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    result = map_library(
        guides=mg1655_csv,
        ref_file=sakai_gbk,
        cache_dir=PERSISTENT_OFF_DICS_DIR,
        badseeds=[],
        pam_index_cache=pam_index_cache,
        output_report=MAP_REPORT_PATH,
        output_csv=MAP_CSV_PATH,
    )

    # All expected columns present
    assert_has_columns(result, [
        "guide", "n_matches", "recid", "strand", "pos",
        "locus_tag", "gene", "gene_ori", "targets_coding_strand",
        "on_target_score", "score_quartile",
        "ntargets", "noff_12", "noff_11_gene", "noff_9_prom",
        "inbadseeds",
    ])

    # Most MG1655 guides have at least one NGG match in Sakai
    n_guides = result["guide"].nunique()
    n_matched = result[result["n_matches"] > 0]["guide"].nunique()
    match_fraction = n_matched / n_guides
    assert match_fraction > 0.5, (
        f"Only {match_fraction:.1%} of guides matched Sakai (expected >50%)"
    )

    # All matched guides have a valid on-target score (not NaN)
    matched_rows = result[result["n_matches"] > 0]
    assert matched_rows["on_target_score"].notna().all(), (
        "Some matched guides have NaN on_target_score"
    )

    # ntargets >= 1 for all matched guides
    assert (matched_rows["ntargets"] >= 1).all()

    # score_quartile is 1-4 for all matched guides
    assert matched_rows["score_quartile"].notna().all()
    assert matched_rows["score_quartile"].isin([1, 2, 3, 4]).all()

    # Report was written
    assert os.path.exists(MAP_REPORT_PATH), f"Report not written to {MAP_REPORT_PATH}"
