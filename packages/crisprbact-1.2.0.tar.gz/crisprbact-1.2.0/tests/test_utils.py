"""Tests for crisprbact.utils."""

import pytest

from crisprbact.utils import NoRecordsException, rev_comp


class TestRevComp:
    def test_simple(self):
        """Standard complement and reversal."""
        assert rev_comp("ATGC") == "GCAT"

    def test_round_trip(self):
        """Double reverse complement returns the original sequence."""
        seq = "ATGCGATCGATCGATCGATCG"
        assert rev_comp(rev_comp(seq)) == seq

    def test_all_bases(self):
        """Each base is complemented correctly."""
        assert rev_comp("A") == "T"
        assert rev_comp("T") == "A"
        assert rev_comp("G") == "C"
        assert rev_comp("C") == "G"

    def test_empty_string(self):
        """Empty input returns empty string."""
        assert rev_comp("") == ""

    def test_palindrome(self):
        """A palindromic sequence equals its own reverse complement."""
        assert rev_comp("ATAT") == "ATAT"
        assert rev_comp("GCGC") == "GCGC"


class TestNoRecordsException:
    def test_can_be_raised(self):
        """NoRecordsException can be raised and caught as an Exception."""
        with pytest.raises(NoRecordsException):
            raise NoRecordsException("no records found")

    def test_is_exception_subclass(self):
        """NoRecordsException is a subclass of Exception."""
        assert issubclass(NoRecordsException, Exception)

    def test_message_preserved(self):
        """Exception message is accessible."""
        msg = "custom error message"
        try:
            raise NoRecordsException(msg)
        except NoRecordsException as e:
            assert str(e) == msg
