import os

import pytest

from crisprbact.off_target_dict import (
    compute_off_target_dic,
    count_off_targets,
    extract_gene_records,
    extract_genome_records,
    extract_promoter_records,
    get_off_dics,
)


@pytest.mark.slow
def test_compute_off_target_dic(mg1655_records):
    """compute_off_target_dic returns dict keyed by seed_size with seed->positions."""
    genome_recs = extract_genome_records(mg1655_records)
    seed_sizes = [8, 11]
    result = compute_off_target_dic(genome_recs, seed_sizes=seed_sizes, search_ori=1)

    assert set(result.keys()) == set(seed_sizes)
    for ss in seed_sizes:
        assert isinstance(result[ss], dict)
        assert len(result[ss]) > 0
        # Each value should be a list of position strings
        first_key = next(iter(result[ss]))
        assert len(first_key) == ss
        assert isinstance(result[ss][first_key], list)
        assert len(result[ss][first_key]) > 0


@pytest.mark.slow
def test_extract_gene_records(mg1655_records):
    """extract_gene_records returns SeqRecords with 'recid,start-end,strand' IDs."""
    gene_recs = extract_gene_records(mg1655_records)

    assert len(gene_recs) > 4000  # MG1655 has ~4400 CDS + ncRNA + rRNA + tRNA

    # Check ID format
    for rec in gene_recs[:10]:
        parts = rec.id.split(",")
        assert len(parts) == 3
        recid = parts[0]
        pos = parts[1]
        strand = parts[2]
        assert "-" in pos
        left, right = pos.split("-")
        assert int(left) >= 0
        assert int(right) > int(left)
        assert strand in ("1", "-1")


@pytest.mark.slow
def test_extract_promoter_records(mg1655_records):
    """extract_promoter_records returns correct number with reasonable lengths."""
    gene_recs = extract_gene_records(mg1655_records)
    prom_recs = extract_promoter_records(mg1655_records)

    # Same number as gene records
    assert len(prom_recs) == len(gene_recs)

    # Default is 100 upstream + 20 downstream = 120bp
    lengths = [len(rec.seq) for rec in prom_recs]
    assert max(lengths) == 120
    # Most should be 120, a few at genome edges may be shorter
    n_full = sum(1 for l in lengths if l == 120)
    assert n_full > len(prom_recs) * 0.99


@pytest.mark.slow
def test_extract_genome_records(mg1655_records):
    """extract_genome_records returns plain SeqRecords without features."""
    genome_recs = extract_genome_records(mg1655_records)

    assert len(genome_recs) == len(mg1655_records)
    for orig, stripped in zip(mg1655_records, genome_recs):
        assert str(stripped.seq) == str(orig.seq)
        assert stripped.id == orig.id
        assert len(stripped.features) == 0


@pytest.mark.slow
def test_count_off_targets(mg1655_records):
    """count_off_targets returns correct counts for a known guide."""
    genome_recs = extract_genome_records(mg1655_records)
    dic = compute_off_target_dic(genome_recs, seed_sizes=[20], search_ori=1)

    recid = mg1655_records[0].id
    # Pick a real seed from the dictionary
    seed_20 = next(iter(dic[20]))
    positions = dic[20][seed_20]

    # Build a fake guide ending with that seed (seed_size=20 means the whole guide)
    guide = seed_20
    # Use the first position as the guide's own position
    own_pos_str = positions[0]
    own_pos = int(own_pos_str.split("_")[1])
    own_recid = own_pos_str.split("_")[0]

    n = count_off_targets(guide, own_pos, own_recid, dic, seed_size=20)
    # Should be total occurrences minus 1 (self)
    assert n == len(positions) - 1


@pytest.mark.slow
def test_get_off_dics(mg1655_records, tmp_path):
    """get_off_dics computes and caches 5 dicts, second call loads from cache."""
    cache_dir = str(tmp_path / "off_dics")
    ref_name = "test_mg1655"

    dics = get_off_dics(mg1655_records, ref_name=ref_name, cache_dir=cache_dir)

    expected_keys = {
        "off_plus",
        "off_minus",
        "off_11_gene",
        "off_9_prom_plus",
        "off_9_prom_minus",
    }
    assert set(dics.keys()) == expected_keys

    # Verify cache files exist
    dic_path = os.path.join(cache_dir, ref_name)
    for name in expected_keys:
        assert os.path.exists(os.path.join(dic_path, name + ".pkl"))

    # Second call should load from cache (faster)
    dics2 = get_off_dics(mg1655_records, ref_name=ref_name, cache_dir=cache_dir)
    assert set(dics2.keys()) == expected_keys

    # Verify contents match
    for key in expected_keys:
        for ss in dics[key]:
            assert ss in dics2[key]
