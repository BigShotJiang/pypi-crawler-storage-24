"""Tests for crisprbact.addon_library."""

import os

import pandas as pd
import pytest

from crisprbact.addon_library import generate_addon_library
from tests.conftest import DATA_DIR, GENOMES_DIR, OUTPUT_DIR, PERSISTENT_OFF_DICS_DIR


# ---------------------------------------------------------------------------
# Unit tests (fast, 10 kb MG1655 genome slice)
#
# Fixtures used:
#   mg1655_10kb_gbk          — path to the 10 kb genome file (session)
#   mg1655_10kb_off_dics_dir — shared off-target dict cache (session)
#   mg1655_10kb_full_library — pre-built full library (session), from conftest
# ---------------------------------------------------------------------------

class TestGenerateAddonLibraryUnit:
    def test_empty_existing_library_all_need_addon(
        self, mg1655_10kb_gbk, mg1655_10kb_off_dics_dir
    ):
        """Empty existing library → all genes receive add-on guides."""
        addon = generate_addon_library(
            ref_file=mg1655_10kb_gbk,
            existing_library=pd.DataFrame({"guide": []}),
            n=5,
            cache_dir=mg1655_10kb_off_dics_dir,
            badseeds=[],
        )

        assert isinstance(addon, pd.DataFrame)
        assert len(addon) > 0
        # At minimum thrA (b0002), the largest gene in the slice, should be covered
        assert "b0002" in addon["locus_tag"].values

    def test_fully_covered_gene_excluded_from_addon(
        self, mg1655_10kb_gbk, mg1655_10kb_off_dics_dir, mg1655_10kb_full_library, tmp_path
    ):
        """Gene with ≥ n existing coding-strand guides is not in the add-on."""
        n = 5
        full = mg1655_10kb_full_library
        target_lt = "b0002"  # thrA — large gene with many guides
        other_lt = "b0003"   # thrB — should still need an add-on

        target_guides = full[full["locus_tag"] == target_lt]["guide"]
        if len(target_guides) < n:
            pytest.skip(f"{target_lt} has fewer than {n} guides in the full library")

        existing_csv = str(tmp_path / "existing.csv")
        pd.DataFrame({"guide": target_guides.tolist()[:n]}).to_csv(
            existing_csv, index=False
        )

        addon = generate_addon_library(
            ref_file=mg1655_10kb_gbk,
            existing_library=existing_csv,
            n=n,
            cache_dir=mg1655_10kb_off_dics_dir,
            badseeds=[],
        )

        locus_tags_in_addon = set(addon["locus_tag"].unique())
        assert target_lt not in locus_tags_in_addon, (
            f"{target_lt} already has {n} guides and should be excluded from the add-on"
        )
        assert other_lt in locus_tags_in_addon, (
            f"{other_lt} has 0 existing guides and should be in the add-on"
        )

    def test_partial_coverage_topped_up(
        self, mg1655_10kb_gbk, mg1655_10kb_off_dics_dir, mg1655_10kb_full_library, tmp_path
    ):
        """Gene with k < n existing guides receives at most n − k add-on guides."""
        n = 5
        k = 2
        full = mg1655_10kb_full_library
        target_lt = "b0002"  # thrA

        target_guides = full[full["locus_tag"] == target_lt]["guide"].tolist()
        if len(target_guides) < k:
            pytest.skip(f"{target_lt} has fewer than {k} guides in the full library")

        existing_csv = str(tmp_path / "existing.csv")
        pd.DataFrame({"guide": target_guides[:k]}).to_csv(existing_csv, index=False)

        addon = generate_addon_library(
            ref_file=mg1655_10kb_gbk,
            existing_library=existing_csv,
            n=n,
            cache_dir=mg1655_10kb_off_dics_dir,
            badseeds=[],
        )

        gene_addon = addon[addon["locus_tag"] == target_lt]
        assert len(gene_addon) <= n - k, (
            f"Expected ≤ {n - k} add-on guides for {target_lt}, got {len(gene_addon)}"
        )

    def test_addon_guides_not_in_existing_library(
        self, mg1655_10kb_gbk, mg1655_10kb_off_dics_dir, mg1655_10kb_full_library, tmp_path
    ):
        """Add-on guides must not duplicate existing library guides for the same gene."""
        n = 5
        k = 2
        full = mg1655_10kb_full_library
        target_lt = "b0002"  # thrA

        target_guides = full[full["locus_tag"] == target_lt]["guide"].tolist()
        if len(target_guides) < k:
            pytest.skip(f"Not enough {target_lt} guides")

        existing_seqs = {g.upper() for g in target_guides[:k]}
        existing_csv = str(tmp_path / "existing.csv")
        pd.DataFrame({"guide": target_guides[:k]}).to_csv(existing_csv, index=False)

        addon = generate_addon_library(
            ref_file=mg1655_10kb_gbk,
            existing_library=existing_csv,
            n=n,
            cache_dir=mg1655_10kb_off_dics_dir,
            badseeds=[],
        )

        gene_addon = addon[addon["locus_tag"] == target_lt]
        addon_seqs = set(gene_addon["guide"].str.upper())
        overlap = addon_seqs & existing_seqs
        assert len(overlap) == 0, (
            f"Add-on contains guides already in the existing library: {overlap}"
        )

    def test_output_columns_present(
        self, mg1655_10kb_gbk, mg1655_10kb_off_dics_dir
    ):
        """Add-on library DataFrame has all expected columns."""
        addon = generate_addon_library(
            ref_file=mg1655_10kb_gbk,
            existing_library=pd.DataFrame({"guide": []}),
            n=5,
            cache_dir=mg1655_10kb_off_dics_dir,
            badseeds=[],
        )

        if len(addon) == 0:
            pytest.skip("No guides produced for the 10 kb genome slice")

        expected_cols = [
            "guide", "locus_tag", "gene_rank", "score",
            "ntargets", "inbadseeds",
        ]
        for col in expected_cols:
            assert col in addon.columns, f"Missing column: {col}"

    def test_dataframe_existing_library_accepted(
        self, mg1655_10kb_gbk, mg1655_10kb_off_dics_dir
    ):
        """Passing a DataFrame (not a path) as existing_library works."""
        addon = generate_addon_library(
            ref_file=mg1655_10kb_gbk,
            existing_library=pd.DataFrame({"guide": []}),
            n=3,
            cache_dir=mg1655_10kb_off_dics_dir,
            badseeds=[],
        )

        assert isinstance(addon, pd.DataFrame)

    def test_all_covered_returns_empty(
        self, mg1655_10kb_gbk, mg1655_10kb_off_dics_dir, mg1655_10kb_full_library, tmp_path
    ):
        """When all genes have ≥ n existing coding-strand guides, add-on is empty."""
        full = mg1655_10kb_full_library
        if len(full) == 0:
            pytest.skip("No guides produced for the 10 kb genome slice")

        existing_csv = str(tmp_path / "existing.csv")
        full[["guide"]].to_csv(existing_csv, index=False)

        addon = generate_addon_library(
            ref_file=mg1655_10kb_gbk,
            existing_library=existing_csv,
            n=5,
            cache_dir=mg1655_10kb_off_dics_dir,
            badseeds=[],
        )

        assert len(addon) == 0, (
            f"Expected empty add-on but got {len(addon)} guides"
        )

    def test_gene_rank_bounded_by_n(
        self, mg1655_10kb_gbk, mg1655_10kb_off_dics_dir
    ):
        """All add-on guides have gene_rank ≤ n."""
        n = 3
        addon = generate_addon_library(
            ref_file=mg1655_10kb_gbk,
            existing_library=pd.DataFrame({"guide": []}),
            n=n,
            cache_dir=mg1655_10kb_off_dics_dir,
            badseeds=[],
        )

        if len(addon) == 0:
            pytest.skip("No guides produced")

        assert (addon["gene_rank"] <= n).all(), "Some guides have gene_rank > n"

    def test_csv_output_written(
        self, mg1655_10kb_gbk, mg1655_10kb_off_dics_dir, tmp_path
    ):
        """output_csv parameter causes the add-on library to be written."""
        out_csv = str(tmp_path / "addon_out.csv")

        generate_addon_library(
            ref_file=mg1655_10kb_gbk,
            existing_library=pd.DataFrame({"guide": []}),
            n=3,
            cache_dir=mg1655_10kb_off_dics_dir,
            badseeds=[],
            output_csv=out_csv,
        )

        assert os.path.exists(out_csv)

    def test_html_report_written(
        self, mg1655_10kb_gbk, mg1655_10kb_off_dics_dir, tmp_path
    ):
        """output_report parameter causes an HTML report to be written."""
        report_path = str(tmp_path / "addon_report.html")

        generate_addon_library(
            ref_file=mg1655_10kb_gbk,
            existing_library=pd.DataFrame({"guide": []}),
            n=3,
            cache_dir=mg1655_10kb_off_dics_dir,
            badseeds=[],
            output_report=report_path,
        )

        assert os.path.exists(report_path)
        with open(report_path) as f:
            content = f.read()
        assert "<!DOCTYPE html>" in content
        assert "Add-on Library" in content


# ---------------------------------------------------------------------------
# Integration tests (slow) — use full-size strain genomes
# ---------------------------------------------------------------------------

@pytest.mark.slow
def test_addon_core_library_on_sakai(sakai_gbk):
    """Integration test: add-on for Sakai (O157:H7) using the core-genome library.

    The core library covers core genes shared across multiple E. coli strains.
    Sakai has strain-specific genes absent from the core genome, so the add-on
    should supply guides for those genes and improve total gene coverage.
    """
    core_csv = os.path.join(DATA_DIR, "core_library.csv")
    if not os.path.exists(core_csv):
        pytest.skip("core_library.csv not found in tests/data/")

    os.makedirs(OUTPUT_DIR, exist_ok=True)
    report_path = os.path.join(OUTPUT_DIR, "addon_core_on_sakai_report.html")
    csv_path = os.path.join(OUTPUT_DIR, "addon_core_on_sakai.csv")
    n = 3

    addon = generate_addon_library(
        ref_file=sakai_gbk,
        existing_library=core_csv,
        n=n,
        cache_dir=PERSISTENT_OFF_DICS_DIR,
        badseeds=["AGGAA", "ACCCA"],
        output_csv=csv_path,
        output_report=report_path,
    )

    # Expected columns
    expected_cols = [
        "guide", "locus_tag", "gene_rank", "score",
        "ntargets", "noff_12", "noff_11_gene", "noff_9_prom", "inbadseeds",
    ]
    for col in expected_cols:
        assert col in addon.columns, f"Missing column: {col}"

    # All add-on guides have gene_rank ≤ n
    if len(addon) > 0:
        assert (addon["gene_rank"] <= n).all()

    # Sakai has strain-specific genes not in any core library → non-empty add-on
    assert len(addon) > 0, (
        "Expected add-on guides for Sakai (strain-specific genes absent from core library)"
    )

    # Combined coverage ≥ existing coverage
    from crisprbact.map_library import map_library
    map_result = map_library(
        core_csv, sakai_gbk,
        cache_dir=PERSISTENT_OFF_DICS_DIR,
        badseeds=[],
    )
    coding_existing = map_result[map_result["targets_coding_strand"] == True]  # noqa
    genes_with_existing = set(coding_existing["locus_tag"].dropna().unique())
    genes_with_addon = set(addon["locus_tag"].unique())
    assert len(genes_with_existing | genes_with_addon) >= len(genes_with_existing)

    # No add-on guide may duplicate an existing coding-strand guide for the same gene
    existing_per_gene = {
        lt: set(grp["guide"].str.upper())
        for lt, grp in coding_existing.groupby("locus_tag")
    }
    for lt in genes_with_addon:
        addon_seqs = set(addon[addon["locus_tag"] == lt]["guide"].str.upper())
        already = existing_per_gene.get(lt, set())
        overlap = addon_seqs & already
        assert len(overlap) == 0, (
            f"Gene {lt}: add-on contains {len(overlap)} guide(s) already in existing library"
        )

    # No gene with ≥ n existing coding-strand guides should appear in the add-on
    existing_coverage = {
        lt: len(gs) for lt, gs in existing_per_gene.items()
    }
    well_covered = {lt for lt, cnt in existing_coverage.items() if cnt >= n}
    overlap_genes = genes_with_addon & well_covered
    assert len(overlap_genes) == 0, (
        f"{len(overlap_genes)} add-on genes already have ≥ {n} existing guides: "
        f"{sorted(overlap_genes)[:5]}"
    )

    # Output files written
    assert os.path.exists(csv_path)
    assert os.path.exists(report_path)
    with open(report_path) as f:
        html = f.read()
    assert "Add-on Library" in html
