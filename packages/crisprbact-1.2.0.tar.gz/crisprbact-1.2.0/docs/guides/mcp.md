# MCP Server

CRISPRbact includes an [MCP (Model Context Protocol)](https://modelcontextprotocol.io/) server that exposes guide RNA prediction and off-target analysis as tools for AI assistants like Claude.

## Installation

Install crisprbact with the `mcp` extra:

```console
pip install "crisprbact[mcp]"
```

## Available tools

The server exposes two tools:

### `predict_guides`

Finds all NGG PAM sites on the coding strand of a DNA sequence, predicts on-target CRISPRi activity, and optionally computes off-targets against a genome.

**Parameters:**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `sequence` | string | yes | DNA sequence to target (ATGC only) |
| `genome_path` | string | no | Path to a GenBank file for off-target analysis |
| `seed_sizes` | list of int | no | Seed sizes for off-target matching (default: `[8, 9, 10, 11, 12, 20]`) |

### `find_off_targets`

Searches for seed matches of a specific 20-nt guide RNA in a genome and annotates hits with overlapping genomic features.

**Parameters:**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `guide` | string | yes | 20-nt guide RNA sequence (ATGC, 5' to 3') |
| `genome_path` | string | yes | Path to a GenBank genome file |
| `seed_size` | int | no | Length of the 3' seed to match (default: 12) |

## Running the server

Start the server directly:

```console
crisprbact-mcp
```

Or run as a Python module:

```console
python -m crisprbact.mcp_server
```

## Using with Claude Code

Register the server in Claude Code:

```console
claude mcp add crisprbact -- crisprbact-mcp
```

If using a conda environment:

```console
claude mcp add crisprbact -- /path/to/conda/envs/myenv/bin/python -m crisprbact.mcp_server
```

## Using with Claude Desktop

Add the following to your Claude Desktop MCP configuration (`claude_desktop_config.json`):

```json
{
  "mcpServers": {
    "crisprbact": {
      "command": "crisprbact-mcp"
    }
  }
}
```

Once configured, you can ask Claude to predict guide RNAs or check off-targets by providing a DNA sequence or genome file path.
