# Genome-wide CRISPRi Library Design

CRISPRbact designs a genome-wide CRISPRi guide RNA library for any bacterial genome provided as a GenBank file. The pipeline finds all NGG PAM sites, annotates them with gene information, predicts on-target activity, evaluates off-targets, and ranks guides to select the best N per gene.

## Command line

```console
crisprbact library generate --help
```

```
Usage: crisprbact library generate [OPTIONS]

  Generate a genome-wide CRISPRi guide RNA library.

  Finds all NGG PAM targets in the genome, annotates them with gene
  information, predicts on-target activity, evaluates off-targets, and selects
  the top N guides per gene.

  Examples:
    crisprbact library generate --ref genome.gb -o library.csv
    crisprbact library generate --ref genome.gb -o library.csv --report report.html
    crisprbact library generate --ref genome.gb -n 10 --badseeds TATAG,AAAGG
    crisprbact library generate --ref genome.gb --badseeds none

Options:
  --ref PATH              Path to GenBank file of the genome.  [required]
  -n, --n-guides INTEGER  Number of guides to select per gene.  [default: 3]
  --ref-name TEXT         Genome name for caching off-target dicts. Default:
                          first record ID.  [default: default]
  --cache-dir TEXT        Directory to cache off-target dictionaries.
                          [default: off_dics]
  -o, --output TEXT       Output CSV file path. If not set, prints to stdout.
  --report PATH           Path to write an HTML quality report.
  --badseeds TEXT         Comma-separated bad seed sequences to flag, or
                          'none' to disable. If not provided, auto-detects:
                          uses E. coli defaults for E. coli genomes, or empty
                          list for other organisms.
  --help                  Show this message and exit.
```

## Python API

```python
from crisprbact import generate_library

library = generate_library(
    ref_file,             # Path to GenBank genome file (required)
    n=5,                  # Number of guides to select per gene
    ref_name=None,        # Genome name for caching (default: first record ID)
    cache_dir="off_dics", # Directory for cached off-target dictionaries
    badseeds=None,        # None=auto-detect, []=disable, or list of custom seeds
    output_csv=None,      # Path to save library as CSV
    output_report=None,   # Path to save HTML report
)
```

Returns a pandas DataFrame with the top N guides per gene:

## Output

<!-- columns:library -->

| Column | Description |
|---|---|
| `guide` | 20nt guide RNA sequence |
| `strand` | Strand of the PAM site (`+` or `-`) |
| `pos` | Genome position of the N in the NGG PAM |
| `recid` | Sequence record ID |
| `gene` | Gene name |
| `locus_tag` | Locus tag |
| `gene_ori` | Gene orientation (1 or -1) |
| `score` | Predicted on-target activity (higher = stronger repression) |
| `score_quartile` | Score quartile (1 = best, 4 = worst). Boundaries: Q1 > 0.4, Q2 > −0.08, Q3 > −0.59 |
| `gene_rank` | Rank of this guide within its gene (1 = best) |
| `ntargets` | Total NGG PAM sites matching the full 20nt guide (perfect matches in genome) |
| `noff_12` | Off-target sites with a matching 12nt seed and an NGG PAM |
| `noff_11_gene` | 11nt seed matches inside genes (coding strand, NGG PAM) |
| `noff_9_prom` | 9nt seed matches in promoter regions (−100 to +20 relative to gene starts, NGG PAM) |
| `inbadseeds` | Whether the guide's PAM-proximal 5nt seed is in the bad seeds list |
| `second_half_gene` | Whether the guide targets the second half of the gene |
| `targets_coding_strand` | Whether the guide targets the coding (non-template) strand |

<!-- /columns:library -->


## Ranking logic

Guides are ranked per gene using a sequential sort (first criterion is most important):

1. **`ntargets`** — fewer full-length (20nt) genomic matches preferred
2. **`noff_12`** — fewer 12nt seed off-targets preferred
3. **`noff_11_gene`** — fewer 11nt seed matches in gene coding strands preferred
4. **`noff_9_prom`** — fewer 9nt seed matches in promoter regions (±100/+20 relative to gene starts) preferred
5. **`badseed`** — guides without bad seeds preferred
6. **`score_quartile`** — higher score quartile preferred (1 > 2 > 3 > 4)
7. **`second_half`** — first half of gene preferred (stronger CRISPRi effect)
8. **`score`** — higher predicted activity preferred (final tiebreaker)

Only NGG PAM sites are counted for off-targets.

## Bad seeds

Bad seeds are 5-nucleotide motifs at the PAM-proximal (3') end of CRISPRi guide RNAs that cause growth toxicity by off-target binding to promoters of essential genes (Rostain et al., [NAR 2023](https://doi.org/10.1093/nar/gkad170)).

**The default bad seeds are specific to *E. coli* MG1655.** The tool auto-detects *E. coli* from GenBank annotations and applies defaults automatically. For other organisms, use an empty list.

| Organism | Recommendation |
|---|---|
| *E. coli* MG1655 / BW25113 / BL21 | Auto-detect (defaults are appropriate) |
| Other *E. coli* strains | Defaults are a reasonable starting point |
| Other Enterobacteriaceae | Use with caution; some seeds may transfer |
| Distant species | Disable (`badseeds=[]` / `--badseeds none`) |
| Custom organism with characterized seeds | Pass explicitly |

```python
# Auto-detect (E. coli → defaults, other → empty)
library = generate_library("genome.gb")

# Explicitly disable
library = generate_library("genome.gb", badseeds=[])

# Custom bad seeds
library = generate_library("genome.gb", badseeds=["TATAG", "AAAGG"])
```

```console
# Auto-detect
crisprbact library generate --ref genome.gb -o library.csv

# Disable
crisprbact library generate --ref genome.gb -o library.csv --badseeds none

# Custom
crisprbact library generate --ref genome.gb -o library.csv --badseeds TATAG,AAAGG
```

## Off-target caching

Computing off-target dictionaries is the most time-consuming step. Results are cached in `cache_dir` (default: `off_dics/`). On subsequent runs with the same genome the cache is loaded automatically. Delete the cache directory to force recomputation.

## HTML report

When `output_report` is set, a self-contained HTML file is produced containing:

- **Genome and library summary** — records, genome size, gene count, guide count, coverage
- **Score statistics** — min/max/mean/median; fraction per quartile
- **Off-target statistics** — percentage of unique guides, mean/max off-target counts
- **Bad seeds and position bias** — percentage of flagged guides
- **Coverage warnings** — genes with 3 or fewer guides (sorted by count)
- **Plots** — score distribution, guides per gene, off-target distribution, genome coverage
- **Gene inspection examples** — detailed guide alignments for two randomly selected genes

## Inspecting individual genes

```python
from Bio import SeqIO
from crisprbact import generate_library, inspect_gene, inspect_gene_summary

library = generate_library("my_genome.gb", n=5)
records = list(SeqIO.parse("my_genome.gb", "genbank"))

# Compact table
print(inspect_gene_summary(library, "lacZ"))

# Detailed view with sequence context and guide alignment
print(inspect_gene(library, records, "lacZ"))
```

Example output from `inspect_gene()`:

```
Gene: lacZ | locus_tag: b0344 | 363230-366305 (-) | length: 3075 bp
================================================================================

Guide #1 | score: 1.797 | strand: + | pos: 366058 | ntargets: 1 | noff_12: 0
  guide: 5'-TGAGGGGACGACGACAGTAT-3'
--------------------------------------------------------------------------------
            234                           277
  coding 5'-CTTCCTGAGGccgATACTGTCGTCGTCCCCTCAAACTGGCAGA-3'
                         ||||||||||||||||||||
  guide  3'-             TATGACAGCAGCAGGGGAGT          -5'
                      PAM
```

## Generating a report from an existing library

```python
from Bio import SeqIO
from crisprbact import generate_report
import pandas as pd

library = pd.read_csv("my_library.csv")
records = list(SeqIO.parse("my_genome.gb", "genbank"))

generate_report(library, records, n=5, output_path="report.html")
```

## Individual plot functions

```python
from crisprbact import (
    plot_score_distribution,
    plot_guides_per_gene,
    plot_off_target_distribution,
    plot_genome_coverage,
)

fig = plot_score_distribution(library)
fig.savefig("scores.png", dpi=150)
```
