# Library Mapping

CRISPRbact can evaluate whether a guide library designed for one strain will work in another. Given a CSV with a `guide` column and a reference genome in GenBank format, it finds each guide's PAM site(s), annotates matches with gene information, predicts on-target activity, and counts off-targets.

This is useful for cross-strain evaluation: e.g. testing an *E. coli* MG1655 library against a pathogenic *E. coli* strain.

## Command line

```console
crisprbact library map --help
```

```
Usage: crisprbact library map [OPTIONS]

  Map an existing guide library against a genome.

  Finds each guide's PAM site in the genome, predicts on-target activity,
  counts off-targets, and flags bad seeds. Useful for cross-strain evaluation.

  Examples:
    crisprbact library map --ref genome.gb -l library.csv -o mapped.csv
    crisprbact library map --ref genome.gb -l library.csv --pam NGA -o mapped.csv
    crisprbact library map --ref genome.gb -l library.csv \
        --pam-index-cache pam_index.pkl --report report.html -o mapped.csv

Options:
  --ref PATH              Path to GenBank file of the reference genome.
                          [required]
  -l, --library PATH      Input CSV file with a 'guide' column.  [required]
  --pam TEXT              PAM sequence (IUPAC). Off-target analysis always
                          uses NGG dicts.  [default: NGG]
  --cache-dir TEXT        Directory to cache off-target dictionaries.
                          [default: off_dics]
  --ref-name TEXT         Genome name for caching off-target dicts. Default:
                          first record ID.
  --pam-index-cache PATH  Path to cache the PAM index (pickle). Speeds up
                          repeated runs.
  --badseeds TEXT         Comma-separated bad seed sequences to flag, or
                          'none' to disable. Auto-detects E. coli defaults if
                          not provided.
  --report PATH           Path to write an HTML quality report.
  -o, --output TEXT       Output CSV file path. If not set, prints to stdout.
  --help                  Show this message and exit.
```

Examples:

```console
crisprbact library map --ref genome.gb -l library.csv -o mapped.csv
crisprbact library map --ref genome.gb -l library.csv --pam NGA -o mapped.csv
crisprbact library map --ref genome.gb -l library.csv \
    --pam-index-cache pam_index.pkl --report report.html -o mapped.csv
```

## Python API

The `guides` parameter accepts multiple input types:

- **CSV file path** (string or path-like) — must contain a `guide` column
- **pandas DataFrame** — must contain a `guide` column
- **list or tuple** of guide sequences (20-nt strings)

```python
from crisprbact import map_library

# From a CSV file
result = map_library("library.csv", "genome.gb")

# From a DataFrame
import pandas as pd
df = pd.DataFrame({"guide": ["ACGTACGTACGTACGTACGT", "TGCATGCATGCATGCATGCA"]})
result = map_library(df, "genome.gb")

# From a list of guide sequences
result = map_library(["ACGTACGTACGTACGTACGT"], "genome.gb")
```

Full signature:

```python
result = map_library(
    guides,                 # CSV path, DataFrame, or list of guide sequences (required)
    ref_file,               # Path to GenBank genome file (required)
    pam="NGG",              # PAM sequence (IUPAC); off-target dicts always use NGG
    cache_dir="off_dics",   # Directory for cached off-target dictionaries
    ref_name=None,          # Genome name for caching (default: first record ID)
    badseeds=None,          # None=auto-detect, []=disable, or list of custom seeds
    pam_index_cache=None,   # Path to cache PAM index pickle (speeds up repeated runs)
    output_csv=None,        # Path to save result as CSV
    output_report=None,     # Path to save HTML report
)
```

## Output

The returned DataFrame contains one row per genomic match. A guide matching at multiple positions appears on multiple rows; a guide with no match appears once with NaN for all genomic columns.

<!-- columns:map -->

| Column | Description |
|---|---|
| `guide` | 20nt guide RNA sequence from the input CSV |
| `n_matches` | Total number of PAM-site matches in the reference genome |
| `recid` | Sequence record ID (NaN if no match) |
| `strand` | PAM strand (`+` or `−`; NaN if no match) |
| `pos` | Position of the N in the NGG PAM (NaN if no match) |
| `locus_tag` | Locus tag of the overlapping gene (NaN if intergenic or no match) |
| `gene` | Gene name (NaN if unavailable) |
| `gene_ori` | Gene orientation (1 or -1) |
| `targets_coding_strand` | Whether the guide targets the coding (non-template) strand |
| `on_target_score` | Predicted on-target activity (NaN if no match) |
| `score_quartile` | Score quartile using fixed boundaries (1 = best; NaN if no match) |
| `ntargets` | Same as `n_matches` |
| `noff_12` | Off-target sites with a matching 12nt seed and an NGG PAM |
| `noff_11_gene` | 11nt seed matches inside genes (coding strand, NGG PAM) |
| `noff_9_prom` | 9nt seed matches in promoter regions (−100 to +20 relative to gene starts) |
| `inbadseeds` | Whether the guide's PAM-proximal 5nt seed is in the bad seeds list |

<!-- /columns:map -->

## HTML report

When `output_report` is set, the report includes:

- **Library and genome summary** — guide count, match rate, gene coverage distribution
- **Score and off-target distributions** — plots for matched guides
- **Wrong-orientation targets** — guides that match within a gene but on the non-coding strand (not expected to provide strong CRISPRi silencing)
