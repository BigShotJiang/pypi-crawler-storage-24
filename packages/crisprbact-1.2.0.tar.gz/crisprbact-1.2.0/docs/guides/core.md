# Core-Genome CRISPRi Library Design

CRISPRbact can design a CRISPRi library targeting genes conserved across **multiple bacterial strains** (core genome). This produces a single guide RNA set that works across a diverse collection of strains — useful for studying essential genes in clinical isolates or creating a strain-agnostic knockdown library.

The pipeline implements the **EcoCG strategy** described in Rousset et al. (2021):

1. Clusters CDS proteins from all input genomes using **MMseqs2** to identify core gene families
2. Designs guides targeting each family, considering cross-strain coverage and off-target risk
3. Ranks guides by a **Global Penalty Score (GPS)** that balances on-target efficiency, off-target risk, and cross-strain coverage

**Reference:** Rousset F et al., "The impact of genetic diversity on gene essentiality within the *Escherichia coli* species." *Nature Microbiology* 6, 301–312 (2021) ([doi:10.1038/s41564-020-00839-y](https://doi.org/10.1038/s41564-020-00839-y))

## Requirements

MMseqs2 must be installed and available in `PATH`:

```console
conda install -c conda-forge -c bioconda mmseqs2
```

## Command line

```console
crisprbact library generate-core --help
```

```
Usage: crisprbact library generate-core [OPTIONS]

  Generate a core-genome CRISPRi library across multiple strains.

  Clusters proteins from all input genomes with MMseqs2 to identify core gene
  families, then designs guides targeting each family, ranked by a Global
  Penalty Score balancing efficiency, off-targets, and coverage.

  Pass genomes as a directory (--genomes-dir) or as individual files (--ref,
  repeatable). Exactly one of the two must be provided.

  Examples:
    crisprbact library generate-core --genomes-dir genomes/ -o core_lib.csv
    crisprbact library generate-core --genomes-dir genomes/ -n 3 \
        --min-presence 0.9 --cache-dir off_dics -o core_lib.csv \
        --strains-dir strains/ --report report.html
    crisprbact library generate-core --ref g1.gb --ref g2.gb -o core_lib.csv

Options:
  --genomes-dir DIRECTORY     Directory containing GenBank genome files (*.gb
                              / *.gbk).
  --ref PATH                  Path to a GenBank genome file. Repeat for each
                              strain. Use --genomes-dir to pass a folder
                              instead.
  -n, --n-guides INTEGER      Number of guides to select per core gene family.
                              [default: 3]
  --min-presence FLOAT        Minimum fraction of genomes a family must appear
                              in.  [default: 0.9]
  --mmseqs-identity FLOAT     MMseqs2 --min-seq-id clustering identity
                              threshold.  [default: 0.5]
  --mmseqs-coverage FLOAT     MMseqs2 -c coverage threshold.  [default: 0.8]
  --coverage-threshold FLOAT  Minimum collective coverage for 4th-guide
                              rescue.  [default: 0.8]
  --cache-dir TEXT            Directory to cache off-target dictionaries.
                              [default: off_dics]
  --tmp-dir PATH              Temporary directory for MMseqs2 (default: system
                              temp).
  --badseeds TEXT             Comma-separated bad seed sequences to flag, or
                              'none' to disable. Auto-detects E. coli defaults
                              if not provided.
  -o, --output TEXT           Output CSV file path. If not set, prints to
                              stdout.
  --strains-dir PATH          Directory to write per-strain guide CSV files.
  --report PATH               Path to write an HTML quality report.
  --help                      Show this message and exit.
```

## Python API

```python
from crisprbact import generate_core_library

library = generate_core_library(
    ref_files,               # List of paths to GenBank genome files (required)
    n=3,                     # Number of guides per core gene family
    min_presence=0.9,        # Min fraction of genomes a family must appear in
    max_copies=4,            # Max copies per genome for a family to be "core"
    mmseqs_min_identity=0.5, # MMseqs2 sequence identity threshold
    mmseqs_coverage=0.8,     # MMseqs2 coverage threshold
    cache_dir="off_dics",    # Directory for cached off-target dictionaries
    tmp_dir=None,            # Temp dir for MMseqs2 (system temp if None)
    coverage_threshold=0.8,  # Min collective coverage for 4th-guide rescue
    badseeds=None,           # None=auto-detect, []=disable, or custom list
    cluster_tsv_cache=None,  # Path to cache MMseqs2 cluster TSV; skips MMseqs2 if present
    output_csv=None,         # Path to save core library as CSV
    output_report=None,      # Path to save HTML quality report
    output_strains_dir=None, # Dir to write one CSV per strain
)
```

Returns a pandas DataFrame:

## Output

<!-- columns:core -->

| Column | Description |
|---|---|
| `family_id` | Core gene family identifier (F00001, F00002, … for CDS; R00001, … for RNA) |
| `gene` | Most common gene name across family members (if annotated) |
| `guide` | 20nt guide RNA sequence |
| `n_covered` | Number of strains where this guide has a genomic match |
| `coverage` | Fraction of strains covered by this guide |
| `gps` | Global Penalty Score — lower is better (0 = ideal) |
| `off_11_gene_score` | Fraction of strains with ≥1 off-target (11nt seed, gene coding strands) |
| `off_9_prom_score` | Fraction of strains with ≥1 off-target (9nt seed, promoter regions) |
| `mean_score` | Mean predicted on-target activity across all strain matches |
| `inbadseeds` | Whether the guide contains a known bad seed motif |
| `feature_type` | Feature type of the target family (CDS, rRNA, tRNA, or ncRNA) |

<!-- /columns:core -->

## Guide selection strategy

For each core gene family:

1. All candidate guides are identified across all member genes and strains
2. **Coverage filtering** — only guides with near-maximum cross-strain coverage are kept
3. **Off-target scoring** — cross-genome off-target fractions are computed
4. **GPS ranking** — guides are ranked by:
   `GPS = normalized(off-target score) + normalized(1 − efficiency) + (1 − coverage)`
5. **Top N guides** are selected; if their collective coverage falls below `coverage_threshold`, a rescue guide is added

## Off-target caching

Off-target dictionaries are cached per genome in `cache_dir`. The MMseqs2 cluster TSV can be cached with `cluster_tsv_cache` — on subsequent runs with the same genomes, both steps are skipped automatically.

## HTML report

When `output_report` is set, the report includes cross-strain coverage statistics, GPS distributions, families without guides, and per-strain summary plots.

## Per-strain output

When `output_strains_dir` is set, one CSV per strain is written with per-strain off-target counts in the same format as a single-genome library.

## After the core library: add-on guides

To ensure full gene coverage in a specific strain, use the [add-on library](addon.md) command:

```console
crisprbact library generate-addon --ref strain.gb -l core_lib.csv -o addon.csv
```
