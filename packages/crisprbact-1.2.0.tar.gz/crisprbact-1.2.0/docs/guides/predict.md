# Guide RNA Prediction

CRISPRbact predicts on-target activity for all NGG PAM sites in a given sequence. The model is a linear regression trained on ~92,000 guides from a genome-wide CRISPRi screen in *E. coli* MG1655 (Cui et al., *Nature Communications*, 2018). It predicts the ability of dCas9 to block RNA polymerase elongation when targeting the non-template (coding) strand.

**Score quartile boundaries:** Q1 > 0.4, Q2 > −0.08, Q3 > −0.59, Q4 (lowest)

**Reference:** Calvo-Villamañán, Wong Ng et al., "On-target activity predictions enable improved CRISPR–dCas9 screens in bacteria", *Nucleic Acids Research*, 2020, 48(11):e64 ([doi:10.1093/nar/gkaa294](https://doi.org/10.1093/nar/gkaa294))

## Python API

```python
from crisprbact import on_target_predict

guides = on_target_predict(
    "ACCACTGGCGTGCGCGTTACTCATCAGATGCTGTTCAATACCGATCAGGTTATCGAAGTG"
    "TTTGTGATTGTTTGCCGCGCGCGTGGCGAAGGCCCGTGATGAAGGAAAAGTTTTGCGCTA"
    "TGTTGGCAATATTGATGAAG"
)

for g in guides:
    print(g)
```

Output (one dict per guide):

```
{'target_id': 1, 'guide': 'GCAAAACTTTTCCTTCATCA', 'guide_start': 96, 'guide_end': 116, 'pam_pos': 93, 'score': -0.47192548737808, 'off_targets_per_seed': []}
{'target_id': 2, 'guide': 'CAAAACTTTTCCTTCATCAC', 'guide_start': 95, 'guide_end': 115, 'pam_pos': 92, 'score': 1.0491308060379676, 'off_targets_per_seed': []}
{'target_id': 3, 'guide': 'ACGGGCCTTCGCCACGCGCG', 'guide_start': 77, 'guide_end': 97, 'pam_pos': 74, 'score': -0.9021152826078698, 'off_targets_per_seed': []}
{'target_id': 4, 'guide': 'AAACACTTCGATAACCTGAT', 'guide_start': 43, 'guide_end': 63, 'pam_pos': 40, 'score': 0.2385325887331195, 'off_targets_per_seed': []}
```

Each guide dict contains:

<!-- columns:predict-dict -->

| Column | Description |
|---|---|
| `target_id` | Sequential guide index (1-based) |
| `guide` | 20nt guide RNA sequence |
| `guide_start` | Start position of the guide in the input sequence |
| `guide_end` | End position of the guide in the input sequence |
| `pam_pos` | Position of the N in the NGG PAM |
| `score` | Predicted on-target activity score (higher = stronger repression) |
| `off_targets_per_seed` | List of off-target counts per seed size (empty if no genome provided) |

<!-- /columns:predict-dict -->

## Command line

### From a string

```console
crisprbact predict from-str --help
```

```
Usage: crisprbact predict from-str [OPTIONS] [OUTPUT_FILE]

  Outputs candidate guide RNAs for the S. pyogenes dCas9 with predicted on-
  target activity from a target gene.

  [OUTPUT_FILE] file where the candidate guide RNAs are saved. Default =
  "stdout"

Options:
  -t, --target TEXT               Sequence file to target  [required]
  -s, --off-target-sequence FILENAME
                                  Sequence in which you want to find off-
                                  targets
  -w, --off-target-sequence-format [fasta|gb|genbank]
                                  Sequence in which you want to find off-
                                  targets format  [default: genbank]
  --help                          Show this message and exit.
```

Example:

```console
crisprbact predict from-str \
    -t ACCACTGGCGTGCGCGTTACTCATCAGATGCTGTTCAATACCGATCAGGTTATCGAAGTGTTTGTGATTGTTTGCCGCGCGCGTGGCGAAGGCCCGTGATGAAGGAAAAGTTTTGCGCTATGTTGGCAATATTGATGAAG \
    guide-rnas.tsv
```

Output TSV (`guide-rnas.tsv`):

```
target_id	guide	guide_start	guide_end	pam_pos	score	target_seq_id
1	GCAAAACTTTTCCTTCATCA	96	116	93	-0.47	N/A
2	CAAAACTTTTCCTTCATCAC	95	115	92	1.05	N/A
3	ACGGGCCTTCGCCACGCGCG	77	97	74	-0.90	N/A
4	AAACACTTCGATAACCTGAT	43	63	40	0.24	N/A
```

Output columns:

<!-- columns:predict-tsv -->

| Column | Description |
|---|---|
| `target_id` | Sequential guide index |
| `guide` | 20nt guide RNA sequence |
| `guide_start` | Start position of the guide in the input sequence |
| `guide_end` | End position of the guide in the input sequence |
| `pam_pos` | Position of the N in the NGG PAM |
| `score` | Predicted on-target activity score |
| `target_seq_id` | Sequence record ID (`N/A` for string input) |

<!-- /columns:predict-tsv -->

You can also pipe results:

```console
crisprbact predict from-str -t ACCACTGGCGTG... | tail -n +2 | wc -l
```

### From a sequence file

```console
crisprbact predict from-seq --help
```

```
Usage: crisprbact predict from-seq [OPTIONS] [OUTPUT_FILE]

  Outputs candidate guide RNAs for the S. pyogenes dCas9 with predicted on-
  target activity from a target gene.

  [OUTPUT_FILE] file where the candidate guide RNAs are saved. Default =
  "stdout"

Options:
  -t, --target FILENAME           Sequence file to target  [required]
  -f, --seq-format [fasta|gb|genbank]
                                  Sequence file to target format  [default:
                                  fasta]
  -s, --off-target-sequence FILENAME
                                  Sequence in which you want to find off-
                                  targets
  -w, --off-target-sequence-format [fasta|gb|genbank]
                                  Sequence in which you want to find off-
                                  targets format  [default: genbank]
  --help                          Show this message and exit.
```

Examples:

```console
# FASTA input (also works with multifasta)
crisprbact predict from-seq -t seq.fasta guide-rnas.tsv

# GenBank input
crisprbact predict from-seq -t seq.gb -f gb guide-rnas.tsv

# With off-target search against a genome
crisprbact predict from-seq -t seq.fasta -s genome.gb guide-rnas.tsv
```
