# Add-on Library Design

The add-on library command supplements an existing guide RNA library (such as a [core-genome library](core.md)) with strain-specific guides to achieve complete gene coverage in a target strain.

## When to use it

Use `generate-addon` when you have:

1. An **existing library** (e.g. a core-genome library covering conserved genes across strains)
2. A **target strain** where some genes are not adequately covered by the existing library

The add-on library fills the gap: for each gene in the target genome, it counts how many coding-strand guides the existing library already provides (`k`). If `k < n`, the add-on contributes up to `n − k` new guides (excluding any sequences already present in the existing library for that gene). Genes with `k ≥ n` are skipped entirely.

Combined, the existing library and add-on library provide `n` coding-strand guides per gene in the target strain.

## Pipeline steps

1. **Map the existing library** — runs `map_library()` to find which existing guides match in the target genome and on which strand
2. **Identify genes needing add-on** — counts coding-strand matches per gene; flags genes with fewer than `n`
3. **Generate a full library** for the target genome using `generate_library()`
4. **Select add-on guides** — for each gene needing more guides, picks the top-ranked guides from the full library that are not already in the existing library

## Command line

```console
crisprbact library generate-addon --help
```

```
Usage: crisprbact library generate-addon [OPTIONS]

  Generate an add-on library to complement an existing guide library.

  Maps the existing library against the target genome and, for each gene with
  fewer than n coding-strand guides, generates new guides to bring the total
  up to n. Guides already present in the existing library are not repeated.

  Examples:
    crisprbact library generate-addon --ref strain.gb -l core_lib.csv -o addon.csv
    crisprbact library generate-addon --ref strain.gb -l core_lib.csv \
        -n 5 --report addon_report.html -o addon.csv

Options:
  --ref PATH              Path to GenBank genome file for the target strain.
                          [required]
  -l, --library PATH      Existing library CSV with a 'guide' column to
                          supplement.  [required]
  -n, --n-guides INTEGER  Target total coding-strand guides per gene across
                          both libraries. Genes with fewer than n existing
                          guides receive add-on guides to reach n.  [default:
                          3]
  --cache-dir TEXT        Directory to cache off-target dictionaries.
                          [default: off_dics]
  --ref-name TEXT         Genome name for caching off-target dicts. Default:
                          first record ID.
  --badseeds TEXT         Comma-separated bad seed sequences to flag, or
                          'none' to disable. Auto-detects E. coli defaults if
                          not provided.
  --report PATH           Path to write an HTML report.
  -o, --output TEXT       Output CSV file path. If not set, prints to stdout.
  --help                  Show this message and exit.
```

## Python API

```python
from crisprbact import generate_addon_library

addon = generate_addon_library(
    ref_file,               # Path to GenBank genome file for the target strain (required)
    existing_library,       # Existing library CSV path or DataFrame with 'guide' column (required)
    n=5,                    # Target total coding-strand guides per gene across both libraries
    cache_dir="off_dics",   # Directory for cached off-target dictionaries
    ref_name=None,          # Genome name for caching (default: first record ID)
    badseeds=None,          # None=auto-detect, []=disable, or list of custom seeds
    output_csv=None,        # Path to write the add-on library CSV
    output_report=None,     # Path to write an HTML report
)
```

`existing_library` can be a path to a CSV file or a pandas DataFrame. The CSV / DataFrame must have a `guide` column.

Returns a pandas DataFrame with the same columns as `generate_library()` (see [Genome-wide library — Output](library.md#output)). Returns an empty DataFrame if all genes already have ≥ n coding-strand guides.

## Example workflow

```python
from crisprbact import generate_core_library, generate_addon_library

# Step 1 — design a core-genome library across your strains
core = generate_core_library(
    ["strain1.gb", "strain2.gb", "strain3.gb"],
    n=3,
    output_csv="core_library.csv",
)

# Step 2 — supplement for a specific target strain
addon = generate_addon_library(
    "strain1.gb",
    existing_library="core_library.csv",
    n=5,
    output_csv="addon_strain1.csv",
    output_report="addon_strain1_report.html",
)

# The combined library (core + addon) now provides up to 5 coding-strand
# guides per gene in strain1
import pandas as pd
combined = pd.concat([core, addon], ignore_index=True)
```

## HTML report

When `output_report` is set, the report includes a **coverage comparison table** showing, for each gene:

| Column | Description |
|---|---|
| Gene / locus tag | Gene identifier |
| Existing coverage | Number of coding-strand guides from the existing library |
| Add-on guides | Number of new guides contributed by the add-on |
| Combined coverage | Total coding-strand guides in the combined library |

The report also includes summary statistics (how many genes needed add-on, total guide counts) and the same score/off-target plots as the standard library report.

## Notes

- The add-on library uses the same [ranking logic](library.md#ranking-logic) and [bad seed filtering](library.md#bad-seeds) as `generate_library()`
- Off-target dictionaries are shared between the mapping and generation steps and are cached in `cache_dir`
- If the existing library is a DataFrame (not a CSV path), it is written to a temporary file internally before calling `map_library()`
