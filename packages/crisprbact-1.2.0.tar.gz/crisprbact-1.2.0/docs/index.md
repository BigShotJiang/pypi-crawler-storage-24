# CRISPRbact

**Tools to design and analyse CRISPRi experiments in bacteria.**

CRISPRbact is a Python library and command-line tool for designing CRISPRi (CRISPR interference) experiments with the *Streptococcus pyogenes* dCas9 protein in bacteria.

## Features

- **On-target activity prediction** — predicts how effectively each guide RNA will block gene expression, using a linear model trained on 2765 guides targeting essential genes in *E. coli*
- **Genome-wide library design** — designs optimized CRISPRi libraries for any bacterial genome, selecting the best guides per gene while avoiding off-targets
- **Library mapping** — evaluates an existing guide library against a new genome to assess coverage and predict activity
- **Add-on library design** — supplements an existing library (e.g. a core-genome library) with strain-specific guides to achieve full gene coverage
- **Core-genome library design** — designs guide libraries targeting genes conserved across multiple strains, enabling cross-strain CRISPRi screens
- **MCP server** — exposes prediction and off-target tools to AI assistants (Claude, etc.) via the Model Context Protocol

## Quick links

- [Installation](installation.md)
- [Quick start](quickstart.md)
- [Guide RNA prediction](guides/predict.md)
- [Genome-wide library design](guides/library.md)
- [Add-on library](guides/addon.md)
- [Core-genome library](guides/core.md)
- [MCP server](guides/mcp.md)

## References

- Calvo-Villamañán, Wong Ng et al., "On-target activity predictions enable improved CRISPR–dCas9 screens in bacteria", *Nucleic Acids Research*, 2020, 48(11):e64 ([doi:10.1093/nar/gkaa294](https://doi.org/10.1093/nar/gkaa294))
- Rousset F et al., "The impact of genetic diversity on gene essentiality within the *Escherichia coli* species." *Nature Microbiology* 6, 301–312 (2021) ([doi:10.1038/s41564-020-00839-y](https://doi.org/10.1038/s41564-020-00839-y))
- Rostain et al., "Cas9 off-target bindings as a source of far-reaching transcriptional noise", *Nucleic Acids Research*, 2023 ([doi:10.1093/nar/gkad170](https://doi.org/10.1093/nar/gkad170))
