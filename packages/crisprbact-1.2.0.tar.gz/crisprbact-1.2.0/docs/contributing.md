# Contributing

## Clone the repository

```console
git clone https://gitlab.pasteur.fr/dbikard/crisprbact.git
cd crisprbact
```

## Set up the development environment

Install [uv](https://docs.astral.sh/uv/getting-started/installation/), then:

```console
uv sync
```

This creates a virtual environment in `.venv/` and installs all dependencies.

## Install pre-commit hooks

Runs `flake8` and `black` automatically on each commit:

```console
uv run pre-commit install
```

## Run tests

```console
# All tests
uv run pytest

# Exclude slow integration tests
uv run pytest -m "not slow"
```

Tests marked `@pytest.mark.slow` run the full library pipeline against the E. coli MG1655 genome and may take several minutes.

## Code style

- Formatted with [black](https://black.readthedocs.io/) (target: Python 3.10, line length 89)
- Linted with [flake8](https://flake8.pycqa.org/)

## Build the documentation

```console
uv run mkdocs serve          # local preview at http://127.0.0.1:8000
uv run mkdocs build          # build static site into ./site/
```
