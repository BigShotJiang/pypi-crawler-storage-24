# Quick Start

## Predict guide RNA activity for a sequence

```python
from crisprbact import on_target_predict

guides = on_target_predict(
    "ACCACTGGCGTGCGCGTTACTCATCAGATGCTGTTCAATACCGATCAGGTTATCGAAGTG"
    "TTTGTGATTGTTTGCCGCGCGCGTGGCGAAGGCCCGTGATGAAGGAAAAGTTTTGCGCTA"
    "TGTTGGCAATATTGATGAAG"
)

for g in guides:
    print(g["guide"], g["pred"])
```

## Design a genome-wide library

```python
from crisprbact import generate_library

library = generate_library(
    "my_genome.gb",
    n=5,
    output_csv="my_library.csv",
    output_report="my_library_report.html",
)
print(library.head())
```

Or from the command line:

```console
crisprbact library generate --ref my_genome.gb -o my_library.csv --report report.html
```

## Supplement an existing library with strain-specific guides

```python
from crisprbact import generate_addon_library

addon = generate_addon_library(
    "strain.gb",
    existing_library="core_library.csv",
    n=5,
    output_csv="addon.csv",
    output_report="addon_report.html",
)
```

Or from the command line:

```console
crisprbact library generate-addon --ref strain.gb -l core_library.csv -o addon.csv --report addon_report.html
```

## Next steps

- [Guide RNA prediction](guides/predict.md) — full CLI and API reference
- [Genome-wide library](guides/library.md) — ranking, bad seeds, HTML report
- [Library mapping](guides/map.md) — cross-strain evaluation
- [Add-on library](guides/addon.md) — strain-specific supplementation
- [Core-genome library](guides/core.md) — multi-strain design with MMseqs2
