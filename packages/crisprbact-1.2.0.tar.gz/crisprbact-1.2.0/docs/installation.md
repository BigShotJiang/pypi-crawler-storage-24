# Installation

## Requirements

- Python ≥ 3.10
- Dependencies installed automatically: `numpy`, `click`, `biopython`, `pandas`, `tqdm`
- Optional: `matplotlib` (required for HTML reports and plot functions)

## Install from PyPI

```console
pip install crisprbact
```

To include plotting/reporting support:

```console
pip install "crisprbact[viz]"
```

To include [MCP server](guides/mcp.md) support (for AI assistants):

```console
pip install "crisprbact[mcp]"
```

Verify the installation:

```console
crisprbact --help
```

## Install from source

```console
git clone https://gitlab.pasteur.fr/dbikard/crisprbact.git
cd crisprbact
pip install -e ".[viz]"
```

## Optional: MMseqs2

The [core-genome library](guides/core.md) command requires **MMseqs2** to cluster proteins across strains. Install it via conda:

```console
conda install -c conda-forge -c bioconda mmseqs2
```

MMseqs2 is only needed for `crisprbact library generate-core`. All other commands work without it.
