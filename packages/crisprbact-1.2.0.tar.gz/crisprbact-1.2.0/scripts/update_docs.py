#!/usr/bin/env python3
"""Regenerate CLI help outputs, example outputs, and column tables in docs/.

Run from the repository root:
    python scripts/update_docs.py          # update files in place
    python scripts/update_docs.py --check  # diff only, exit 1 if stale

What gets updated
-----------------
1. Any ```console block whose sole crisprbact command ends with ``--help``
   is followed by a plain ``` output block that is replaced with actual output.

2. Two named sections in docs/guides/predict.md:
   - Python API example output (after the ``for g in guides:`` code block)
   - TSV output (after the predict from-str example command)

3. Column reference tables embedded in each How-to page, generated from
   scripts/_column_defs.py and (when test data is available) validated
   against actual function output.  Tables are delimited by HTML comments:
       <!-- columns:section-name -->  ...  <!-- /columns:section-name -->
   Markers are scanned across all docs/**/*.md files automatically.

Test data
---------
Column validation for generate_library / map_library requires a GenBank file.
The script looks for tests/data/genomes/mg1655_10kb.gb.  If absent it skips
runtime validation (safe for CI where test data is gitignored).
"""

import difflib
import glob
import os
import re
import subprocess
import sys
import tempfile

DOCS_DIR = "docs"
CRISPRBACT = os.path.join(os.path.dirname(sys.executable), "crisprbact")
TEST_GENOME = "tests/data/genomes/mg1655_10kb.gb"

SEQ = (
    "ACCACTGGCGTGCGCGTTACTCATCAGATGCTGTTCAATACCGATCAGGTTATCGAAGTG"
    "TTTGTGATTGTTTGCCGCGCGCGTGGCGAAGGCCCGTGATGAAGGAAAAGTTTTGCGCTA"
    "TGTTGGCAATATTGATGAAG"
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def run(cmd, suppress_warnings=True):
    """Run a shell command and return stripped stdout."""
    env = os.environ.copy()
    if suppress_warnings:
        env["PYTHONWARNINGS"] = "ignore"
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True, env=env)
    return result.stdout.rstrip()


def run_python(code):
    """Write code to a temp file and execute it; return stdout."""
    with tempfile.NamedTemporaryFile(suffix=".py", mode="w", delete=False) as f:
        f.write(code)
        tmp = f.name
    try:
        return run(f"{sys.executable} -W ignore {tmp}")
    finally:
        os.unlink(tmp)


# ---------------------------------------------------------------------------
# Named section output generators
# ---------------------------------------------------------------------------

def _python_api_output():
    code = (
        "from crisprbact import on_target_predict\n"
        f"guides = on_target_predict('{SEQ}')\n"
        "for g in guides:\n"
        "    print(g)\n"
    )
    return run_python(code)



NAMED_SECTIONS = [
    {
        "preceding_marker": "for g in guides:",
        "intertext": "Output (one dict per guide):",
        "output_fn": _python_api_output,
    },
]


# ---------------------------------------------------------------------------
# Column table generation and validation
# ---------------------------------------------------------------------------

def _generate_column_tables():
    """Return a dict mapping section marker → markdown table string."""
    # Import here so the script can run without the defs (graceful degradation)
    sys.path.insert(0, os.path.dirname(__file__))
    from _column_defs import (
        PREDICT_DICT_COLUMNS,
        PREDICT_TSV_COLUMNS,
        LIBRARY_PRIMARY_COLUMNS,
        MAP_COLUMNS,
        CORE_COLUMNS,
        _md_table,
    )

    lib_table = _md_table(LIBRARY_PRIMARY_COLUMNS)

    return {
        "predict-dict":   _md_table(PREDICT_DICT_COLUMNS),
        "predict-tsv":    _md_table(PREDICT_TSV_COLUMNS),
        "library":        lib_table,
        "map":            _md_table(MAP_COLUMNS),
        "core":           _md_table(CORE_COLUMNS),
    }


def _validate_columns():
    """Validate actual output columns match _column_defs.  Prints warnings."""
    sys.path.insert(0, os.path.dirname(__file__))
    from _column_defs import (
        PREDICT_DICT_COLUMNS,
        LIBRARY_PRIMARY_COLUMNS,
        MAP_COLUMNS,
    )

    # on_target_predict — always available
    from crisprbact import on_target_predict
    guides = on_target_predict(SEQ)
    actual = set(guides[0].keys())
    expected = {c for c, _ in PREDICT_DICT_COLUMNS}
    _check("on_target_predict", actual, expected)

    if not os.path.exists(TEST_GENOME):
        print(f"  [skip] {TEST_GENOME} not found — skipping generate_library / map_library validation")
        return

    from crisprbact import generate_library, map_library

    lib = generate_library(TEST_GENOME, n=1, badseeds=[], output_csv=None)
    actual_lib = set(lib.columns)
    expected_lib = {c for c, _ in LIBRARY_PRIMARY_COLUMNS}
    _check("generate_library", actual_lib, expected_lib)

    tmp_csv = tempfile.mktemp(suffix=".csv")
    try:
        lib[["guide"]].drop_duplicates().head(5).to_csv(tmp_csv, index=False)
        mapped = map_library(tmp_csv, TEST_GENOME, badseeds=[])
        actual_map = set(mapped.columns)
        expected_map = {c for c, _ in MAP_COLUMNS}
        _check("map_library", actual_map, expected_map)
    finally:
        os.unlink(tmp_csv)


def _check(func_name, actual, expected):
    missing = expected - actual
    extra = actual - expected
    if missing:
        print(f"  WARNING {func_name}: columns in defs but not in output: {sorted(missing)}", file=sys.stderr)
    if extra:
        print(f"  WARNING {func_name}: columns in output but not in defs: {sorted(extra)}", file=sys.stderr)
    if not missing and not extra:
        print(f"  OK  {func_name}: all {len(actual)} columns match")


def patch_output_formats(path, tables, dry_run=False):
    """Replace <!-- columns:X --> ... <!-- /columns:X --> blocks in *path*."""
    with open(path) as f:
        content = f.read()
    original = content

    for section, table in tables.items():
        open_tag = f"<!-- columns:{section} -->"
        close_tag = f"<!-- /columns:{section} -->"
        pattern = re.compile(
            re.escape(open_tag) + r"[\s\S]*?" + re.escape(close_tag),
            re.DOTALL,
        )
        replacement = f"{open_tag}\n\n{table}\n\n{close_tag}"
        content = pattern.sub(replacement, content)

    if content == original:
        return False

    if dry_run:
        diff = difflib.unified_diff(
            original.splitlines(keepends=True),
            content.splitlines(keepends=True),
            fromfile=f"{path} (old)",
            tofile=f"{path} (new)",
        )
        sys.stdout.writelines(diff)
    else:
        with open(path, "w") as f:
            f.write(content)
    return True


# ---------------------------------------------------------------------------
# Generic file patcher (--help blocks + named sections)
# ---------------------------------------------------------------------------

def _replace_output_block(content, preceding_marker, intertext, new_output):
    pattern = re.compile(
        r'(```[^\n]*\n'
        r'(?:(?!```)[\s\S])*?'
        + re.escape(preceding_marker[:40])
        + r'(?:(?!```)[\s\S])*?```)'
        r'([\s\S]*?'
        + re.escape(intertext[:20])
        + r'[\s\S]*?)'
        r'(```\n(?:(?!```)[\s\S])*?```)',
        re.DOTALL,
    )
    m = pattern.search(content)
    if not m:
        return content, False
    new_block = f"```\n{new_output}\n```"
    return content[:m.start(3)] + new_block + content[m.end(3):], True


def patch_file(path, dry_run=False):
    with open(path) as f:
        content = f.read()
    original = content

    # 1. --help blocks
    console_re = re.compile(
        r'(```console\n'
        r'((?:(?!```)[\s\S])*?)'
        r'```)'
        r'(\n\n?)'
        r'(```\n'
        r'(?:(?!```)[\s\S])*?'
        r'```)',
        re.DOTALL,
    )

    def _replace_help(m):
        console_block = m.group(1)
        block_body = m.group(2)
        separator = m.group(3)
        lines = [l.strip().lstrip("$").strip()
                 for l in block_body.splitlines() if l.strip()]
        crisprbact_lines = [l for l in lines if l.startswith("crisprbact ")]
        if len(crisprbact_lines) != 1 or not crisprbact_lines[0].endswith("--help"):
            return m.group(0)
        cmd = crisprbact_lines[0].replace("crisprbact ", f"{CRISPRBACT} ", 1)
        new_output = run(cmd)
        return f"{console_block}{separator}```\n{new_output}\n```"

    content = console_re.sub(_replace_help, content)

    # 2. Named sections (Python API output, TSV output)
    for section in NAMED_SECTIONS:
        new_output = section["output_fn"]()
        content, _ = _replace_output_block(
            content,
            preceding_marker=section["preceding_marker"],
            intertext=section["intertext"],
            new_output=new_output,
        )

    if content == original:
        return False

    if dry_run:
        diff = difflib.unified_diff(
            original.splitlines(keepends=True),
            content.splitlines(keepends=True),
            fromfile=f"{path} (old)",
            tofile=f"{path} (new)",
        )
        sys.stdout.writelines(diff)
    else:
        with open(path, "w") as f:
            f.write(content)
    return True


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    dry_run = "--check" in sys.argv or "--dry-run" in sys.argv
    validate = "--validate" in sys.argv or not dry_run

    changed = []

    # --- Collect all docs md files ---
    md_files = sorted(set(
        glob.glob(f"{DOCS_DIR}/**/*.md", recursive=True)
        + glob.glob(f"{DOCS_DIR}/*.md")
    ))

    # --- Column tables (scan every md file for <!-- columns:X --> markers) ---
    try:
        tables = _generate_column_tables()
        for path in md_files:
            if patch_output_formats(path, tables, dry_run=dry_run):
                changed.append(path)
                if not dry_run:
                    print(f"Updated: {path}")
    except ImportError as e:
        print(f"WARNING: could not import _column_defs: {e}", file=sys.stderr)

    # --- Validate column names against actual output (optional) ---
    if validate and not dry_run:
        print("Validating column names...")
        try:
            _validate_columns()
        except Exception as e:
            print(f"WARNING: validation failed: {e}", file=sys.stderr)

    # --- --help blocks and named sections in all .md files ---
    for path in md_files:
        if patch_file(path, dry_run=dry_run):
            changed.append(path)
            if not dry_run:
                print(f"Updated: {path}")

    if not changed:
        print("All docs up to date.")
    elif dry_run:
        print(f"\n{len(changed)} file(s) need updating: {', '.join(changed)}")
        sys.exit(1)


if __name__ == "__main__":
    main()
