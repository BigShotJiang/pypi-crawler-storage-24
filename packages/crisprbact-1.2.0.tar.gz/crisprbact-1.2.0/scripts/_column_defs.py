"""Column definitions for CRISPRbact output DataFrames.

This is the single source of truth for column names and descriptions used in
docs/reference/output-formats.md.  Update this file when columns change, then
run scripts/update_docs.py to regenerate the reference tables.

Each entry is (column_name, description).  For generate_library, columns are
split into "primary" (user-facing) and "intermediate" groups.
"""

# ---------------------------------------------------------------------------
# on_target_predict  —  list of dicts
# ---------------------------------------------------------------------------

PREDICT_DICT_COLUMNS = [
    ("target_id",           "Sequential guide index (1-based)"),
    ("guide",               "20nt guide RNA sequence"),
    ("guide_start",         "Start position of the guide in the input sequence"),
    ("guide_end",           "End position of the guide in the input sequence"),
    ("pam_pos",             "Position of the N in the NGG PAM"),
    ("score",               "Predicted on-target activity score (higher = stronger repression)"),
    ("off_targets_per_seed","List of off-target counts per seed size (empty if no genome provided)"),
]

# CLI TSV output (crisprbact predict from-str / from-seq)
PREDICT_TSV_COLUMNS = [
    ("target_id",     "Sequential guide index"),
    ("guide",         "20nt guide RNA sequence"),
    ("guide_start",   "Start position of the guide in the input sequence"),
    ("guide_end",     "End position of the guide in the input sequence"),
    ("pam_pos",       "Position of the N in the NGG PAM"),
    ("score",         "Predicted on-target activity score"),
    ("target_seq_id", "Sequence record ID (`N/A` for string input)"),
]

# ---------------------------------------------------------------------------
# generate_library  —  DataFrame
# ---------------------------------------------------------------------------

# Primary (user-facing) columns
LIBRARY_PRIMARY_COLUMNS = [
    ("guide",                "20nt guide RNA sequence"),
    ("strand",               "Strand of the PAM site (`+` or `-`)"),
    ("pos",                  "Genome position of the N in the NGG PAM"),
    ("recid",                "Sequence record ID"),
    ("gene",                 "Gene name"),
    ("locus_tag",            "Locus tag"),
    ("gene_ori",             "Gene orientation (1 or -1)"),
    ("score",                "Predicted on-target activity (higher = stronger repression)"),
    ("score_quartile",       "Score quartile (1 = best, 4 = worst). Boundaries: Q1 > 0.4, Q2 > −0.08, Q3 > −0.59"),
    ("gene_rank",            "Rank of this guide within its gene (1 = best)"),
    ("ntargets",             "Total NGG PAM sites matching the full 20nt guide (perfect matches in genome)"),
    ("noff_12",              "Off-target sites with a matching 12nt seed and an NGG PAM"),
    ("noff_11_gene",         "11nt seed matches inside genes (coding strand, NGG PAM)"),
    ("noff_9_prom",          "9nt seed matches in promoter regions (−100 to +20 relative to gene starts, NGG PAM)"),
    ("inbadseeds",           "Whether the guide's PAM-proximal 5nt seed is in the bad seeds list"),
    ("second_half_gene",     "Whether the guide targets the second half of the gene"),
    ("targets_coding_strand","Whether the guide targets the coding (non-template) strand"),
]

# ---------------------------------------------------------------------------
# map_library  —  DataFrame
# ---------------------------------------------------------------------------

MAP_COLUMNS = [
    ("guide",                "20nt guide RNA sequence from the input CSV"),
    ("n_matches",            "Total number of PAM-site matches in the reference genome"),
    ("recid",                "Sequence record ID (NaN if no match)"),
    ("strand",               "PAM strand (`+` or `−`; NaN if no match)"),
    ("pos",                  "Position of the N in the NGG PAM (NaN if no match)"),
    ("locus_tag",            "Locus tag of the overlapping gene (NaN if intergenic or no match)"),
    ("gene",                 "Gene name (NaN if unavailable)"),
    ("gene_ori",             "Gene orientation (1 or -1)"),
    ("targets_coding_strand","Whether the guide targets the coding (non-template) strand"),
    ("on_target_score",      "Predicted on-target activity (NaN if no match)"),
    ("score_quartile",       "Score quartile using fixed boundaries (1 = best; NaN if no match)"),
    ("ntargets",             "Same as `n_matches`"),
    ("noff_12",              "Off-target sites with a matching 12nt seed and an NGG PAM"),
    ("noff_11_gene",         "11nt seed matches inside genes (coding strand, NGG PAM)"),
    ("noff_9_prom",          "9nt seed matches in promoter regions (−100 to +20 relative to gene starts)"),
    ("inbadseeds",           "Whether the guide's PAM-proximal 5nt seed is in the bad seeds list"),
]

# ---------------------------------------------------------------------------
# generate_core_library  —  DataFrame
# ---------------------------------------------------------------------------

CORE_COLUMNS = [
    ("family_id",        "Core gene family identifier (F00001, F00002, … for CDS; R00001, … for RNA)"),
    ("gene",             "Most common gene name across family members (if annotated)"),
    ("guide",            "20nt guide RNA sequence"),
    ("n_covered",        "Number of strains where this guide has a genomic match"),
    ("coverage",         "Fraction of strains covered by this guide"),
    ("gps",              "Global Penalty Score — lower is better (0 = ideal)"),
    ("off_11_gene_score","Fraction of strains with ≥1 off-target (11nt seed, gene coding strands)"),
    ("off_9_prom_score", "Fraction of strains with ≥1 off-target (9nt seed, promoter regions)"),
    ("mean_score",       "Mean predicted on-target activity across all strain matches"),
    ("inbadseeds",       "Whether the guide contains a known bad seed motif"),
    ("feature_type",     "Feature type of the target family (CDS, rRNA, tRNA, or ncRNA)"),
]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _md_table(columns):
    """Render a list of (name, description) pairs as a markdown table."""
    rows = ["| Column | Description |", "|---|---|"]
    for name, desc in columns:
        rows.append(f"| `{name}` | {desc} |")
    return "\n".join(rows)
