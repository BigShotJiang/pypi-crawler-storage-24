"""Compute Q1/Q2/Q3 score boundaries from 1000 random sequences (seed=42).

Run once by a developer; paste the printed values into predict.py.

Usage:
    python scripts/compute_score_boundaries.py
"""

import numpy as np
from crisprbact import on_target_predict

rng = np.random.default_rng(42)
scores = [
    g["score"]
    for _ in range(1000)
    for g in on_target_predict("".join(rng.choice(list("ACGT"), 200)))
]
q1, q2, q3 = np.percentile(scores, [75, 50, 25])
print(f"SCORE_BOUNDARIES = ({q1:.4f}, {q2:.4f}, {q3:.4f})  # Q1/Q2/Q3 cut-points")
