"""
QuarterBit CLI entry point.

Usage:
    quarterbit info   - Show version and info
"""

def main():
    from . import __version__
    print(f"QuarterBit v{__version__}")
    print("Memory-efficient AI training")
    print("https://quarterbit.dev")

if __name__ == "__main__":
    main()
