
from setuptools import setup, find_packages
import os

# السطر ده بيضمن إن المسار يتقرأ صح حتى لو الـ Terminal مفتوح في مكان تاني
here = os.path.abspath(os.path.dirname(__file__))

# قراءة ملف الـ README بتشفير UTF-8 عشان العربي
with open(os.path.join(here, "README.md"), encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="pynoot",
    version="0.6",  # ارفع الإصدار لـ 0.6 عشان يقبل الرفع الجديد
    author="Nour Eldeen Ahmed",
    author_email="noureldeen262000@gmail.com", # حط إيميلك هنا
    description="بوابة لتعلم منطق لغة البرمجة باثيون بالمصري",
    
    # السطرين دول هما اللي هيحلوا الـ Warnings
    long_description=long_description,
    long_description_content_type="text/markdown",
    
    url="https://github.com/noureldeen216/PyNoot", # لينك الريبو بتاعك
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],

)