from __future__ import annotations

import json
import mimetypes
from pathlib import Path


def pick_ordered_config(raw: dict) -> dict:
    order = raw.get("order") or []
    if not order:
        raise RuntimeError("strategy order is empty")
    selected_key = order[0]
    if selected_key not in raw:
        raise RuntimeError(f"strategy config {selected_key!r} not found")
    return raw[selected_key]


def fetch_storage_upload_policy(api_client) -> dict:
    strategy_type = api_client.strategy_type()
    response = api_client.signed_request(
        "GET",
        f"{api_client.strategy_path()}?type={strategy_type}",
        None,
        base_url=api_client.strategy_base_url(),
    )

    if response.get("code") != 0:
        message = str(response.get("message") or "").strip() or "fetch upload strategy failed"
        raise RuntimeError(f"{message} (code={response.get('code')})")

    data = response.get("data") or {}
    if strategy_type not in data:
        raise RuntimeError(f"upload strategy for type {strategy_type!r} not found")

    upload_block = (data[strategy_type] or {}).get("upload")
    if not upload_block:
        raise RuntimeError("strategy config is empty")

    if isinstance(upload_block, str):
        upload_block = json.loads(upload_block)

    policy = pick_ordered_config(upload_block)
    required = [
        ("url", "upload strategy is missing url"),
        ("bucket", "upload strategy is missing bucket"),
        ("key", "upload strategy is missing key"),
        ("data", "upload strategy is missing data"),
    ]
    for key, message in required:
        if not str(policy.get(key, "")).strip():
            raise RuntimeError(message)

    credentials = policy.get("credentials") or {}
    if not str(credentials.get("access_key", "")).strip() or not str(credentials.get("secret_key", "")).strip():
        raise RuntimeError("upload strategy is missing storage credentials")

    return policy


def put_file_to_storage(file_path: str, endpoint_url: str, policy: dict) -> str:
    try:
        import boto3
        from botocore.config import Config
    except ModuleNotFoundError as exc:
        raise RuntimeError(
            "local file upload requires boto3; install the CLI with pipx/pip so dependencies are available"
        ) from exc

    path = Path(file_path)
    if not path.is_file():
        raise RuntimeError(f"upload file is not a file: {file_path}")

    credentials = policy["credentials"]
    use_virtual_host = bool(policy.get("use_virtual_host"))
    addressing_style = "virtual" if use_virtual_host else "path"
    # OBS rejects botocore's newer streaming trailer checksum mode, so force
    # a classic single-request upload with explicit content length.
    client = boto3.client(
        "s3",
        endpoint_url=endpoint_url,
        aws_access_key_id=credentials["access_key"],
        aws_secret_access_key=credentials["secret_key"],
        aws_session_token=credentials.get("session_token") or None,
        region_name=policy.get("region") or None,
        config=Config(
            s3={
                "addressing_style": addressing_style,
                "payload_signing_enabled": True,
            },
            request_checksum_calculation="when_required",
            response_checksum_validation="when_required",
        ),
    )

    content_type, _ = mimetypes.guess_type(path.name)
    body = path.read_bytes()
    extra_args = {}
    if content_type:
        extra_args["ContentType"] = content_type

    client.put_object(
        Bucket=policy["bucket"],
        Key=policy["key"],
        Body=body,
        **extra_args,
    )

    return str(policy["data"]).strip()


def upload_local_file(api_client, file_path: str) -> str:
    file_path = file_path.strip()
    if not file_path:
        raise RuntimeError("upload file path is required")

    policy = fetch_storage_upload_policy(api_client)
    try:
        return put_file_to_storage(file_path, policy["url"], policy)
    except Exception:
        backup_url = str(policy.get("backup_url") or "").strip()
        if not backup_url:
            raise
        return put_file_to_storage(file_path, backup_url, policy)
