from __future__ import annotations

import json
import os
import time
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

from .config import load_credentials
from .signer import canonical_body_bytes, sign_sdk_headers


DEFAULT_BASE_URL = "https://openapi.meitu.com"
DEFAULT_AUTH_VERIFY_PATH = "/demo/authorization"
DEFAULT_IMAGE_GENERATE_PATH = "/api/v1/sdk/push"
DEFAULT_TASK_STATUS_PATH = "/api/v1/sdk/status"
DEFAULT_STRATEGY_BASE_URL = "https://strategy.app.meitudata.com"
DEFAULT_STRATEGY_PATH = "/ai/token_policy"
DEFAULT_STRATEGY_TYPE = "mtai"
DEFAULT_GENERATE_POLL_INTERVAL_MS = 1000
DEFAULT_GENERATE_TIMEOUT_MS = 300000


def normalize_base_url(value: str) -> str:
    value = (value or "").strip().rstrip("/")
    if not value:
        return ""
    if "://" not in value:
        return f"https://{value}"
    return value


def path_from_env(env_key: str, fallback: str) -> str:
    value = os.getenv(env_key, "").strip()
    if not value:
        return fallback
    return value if value.startswith("/") else f"/{value}"


def decode_api_error_message(raw: bytes) -> str:
    try:
        payload = json.loads(raw.decode("utf-8"))
    except Exception:
        return ""

    message = str(payload.get("message") or "").strip()
    if not message:
        return ""

    try:
        nested = json.loads(message)
    except Exception:
        return message
    return str(nested.get("message") or "").strip() or message


def is_pending_task_status(status: int) -> bool:
    return status in {0, 1, 9}


class APIClient:
    def base_url(self) -> str:
        return normalize_base_url(os.getenv("OPENAPI_BASE_URL")) or DEFAULT_BASE_URL

    def image_base_url(self) -> str:
        return normalize_base_url(os.getenv("OPENAPI_IMAGE_BASE_URL")) or self.base_url()

    def strategy_base_url(self) -> str:
        return normalize_base_url(os.getenv("OPENAPI_STRATEGY_BASE_URL")) or DEFAULT_STRATEGY_BASE_URL

    def strategy_path(self) -> str:
        return path_from_env("OPENAPI_STRATEGY_PATH", DEFAULT_STRATEGY_PATH)

    def strategy_type(self) -> str:
        return os.getenv("OPENAPI_STRATEGY_TYPE", "").strip() or DEFAULT_STRATEGY_TYPE

    def signed_request(
        self,
        method: str,
        path: str,
        body: object | None,
        *,
        base_url: str = "",
    ) -> dict[str, Any]:
        credentials = load_credentials()
        if credentials is None:
            raise RuntimeError(
                "credentials not found, please run `meitu config set-ak` and `meitu config set-sk`, "
                "or set OPENAPI_ACCESS_KEY/OPENAPI_SECRET_KEY"
            )

        request_base_url = (base_url or "").strip() or self.base_url()
        request_url = f"{request_base_url}{path}"
        body_bytes = canonical_body_bytes(body)
        body_string = body_bytes.decode("utf-8")
        headers: dict[str, str] = {}
        if body is not None:
            headers["Content-Type"] = "application/json"

        _, _, signed_headers = sign_sdk_headers(
            request_url,
            method,
            headers,
            body_string,
            credentials.access_key,
            credentials.secret_key,
        )
        request = Request(
            request_url,
            data=body_bytes if body is not None else None,
            method=method.upper(),
            headers=signed_headers,
        )

        try:
            with urlopen(request, timeout=30) as response:
                raw = response.read()
                status = response.status
        except HTTPError as exc:
            raw = exc.read()
            message = decode_api_error_message(raw)
            raise RuntimeError(message or f"request failed: {exc.code}") from exc
        except URLError as exc:
            raise RuntimeError(f"request failed: {exc.reason}") from exc

        if not raw:
            if status < 200 or status >= 300:
                raise RuntimeError(f"request failed: {status}")
            return {}

        if status < 200 or status >= 300:
            raise RuntimeError(decode_api_error_message(raw) or f"request failed: {status}")

        try:
            return json.loads(raw.decode("utf-8"))
        except Exception as exc:
            raise RuntimeError(f"invalid json response: {raw.decode('utf-8', errors='replace')}") from exc

    def verify_auth(self, path_override: str = "") -> dict[str, Any]:
        path = path_override.strip()
        if path:
            if not path.startswith("/"):
                path = f"/{path}"
        else:
            path = path_from_env("OPENAPI_AUTH_VERIFY_PATH", DEFAULT_AUTH_VERIFY_PATH)
        return self.signed_request("POST", path, {})

    def create_image(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self.signed_request(
            "POST",
            path_from_env("OPENAPI_IMAGE_GENERATE_PATH", DEFAULT_IMAGE_GENERATE_PATH),
            payload,
            base_url=self.image_base_url(),
        )

    def get_task(self, task_id: str) -> dict[str, Any]:
        query = urlencode({"task_id": task_id})
        path = f"{path_from_env('OPENAPI_TASK_STATUS_PATH', DEFAULT_TASK_STATUS_PATH)}?{query}"
        return self.signed_request("GET", path, None, base_url=self.image_base_url())

    def wait_task(self, task_id: str, interval_ms: int, timeout_ms: int) -> dict[str, Any]:
        if interval_ms <= 0:
            raise RuntimeError("interval must be a positive number")
        if timeout_ms <= 0:
            raise RuntimeError("timeout must be a positive number")

        deadline = time.time() + timeout_ms / 1000.0
        while time.time() < deadline:
            task = self.get_task(task_id)
            if task.get("code") != 0:
                return task
            status = int((((task.get("data") or {}).get("status")) or 0))
            if status == 10 or not is_pending_task_status(status):
                return task
            time.sleep(interval_ms / 1000.0)

        raise RuntimeError(f"task wait timeout: {task_id}")


def normalize_params_json(value: str) -> str:
    value = (value or "").strip()
    if not value:
        return ""
    try:
        json.loads(value)
    except Exception as exc:
        raise RuntimeError("params json must be valid JSON") from exc
    return value


def normalize_resource_type(resource_type: str, media_data: str) -> str:
    normalized = (resource_type or "").strip().lower()
    if not normalized:
        if media_data.startswith(("https://", "http://")):
            return "url"
        return "file"
    if normalized == "url":
        return "url"
    if normalized in {"file", "file_path", "filepath", "path", "local_file"}:
        return "file"
    raise RuntimeError(f"invalid resource_type {resource_type!r}: expected url or file")


def normalize_init_image_profile(profile: dict[str, Any] | None, media_data_type: str, profile_version: str) -> dict[str, Any]:
    profile = dict(profile or {})
    media_profiles = dict(profile.get("media_profiles") or {})
    if media_data_type and not str(media_profiles.get("media_data_type") or "").strip():
        media_profiles["media_data_type"] = media_data_type
    if media_profiles:
        profile["media_profiles"] = media_profiles
    if profile_version and not str(profile.get("version") or "").strip():
        profile["version"] = profile_version
    return profile


def resolve_input_init_image(api_client: APIClient, item: dict[str, Any], media_data_type: str, profile_version: str) -> dict[str, Any]:
    url_value = str(item.get("url") or "").strip()
    file_value = str(item.get("file") or "").strip()
    media_data_value = str(item.get("media_data") or "").strip()

    source_count = sum(bool(x) for x in [url_value, file_value, media_data_value])
    if source_count == 0:
        raise RuntimeError("each init image must include a non-empty url, file, or media_data")
    if source_count > 1:
        raise RuntimeError("each init image must use only one of url, file, or media_data")

    if media_data_value:
        resource_type = normalize_resource_type(str(item.get("resource_type") or ""), media_data_value)
        if resource_type == "url":
            url_value = media_data_value
        else:
            file_value = media_data_value

    if file_value:
        from .upload import upload_local_file

        url_value = upload_local_file(api_client, file_value)

    return {
        "url": url_value,
        "profile": normalize_init_image_profile(item.get("profile"), media_data_type, profile_version),
    }


def normalize_init_images(
    api_client: APIClient,
    image_url: str,
    image_file: str,
    raw_json: str,
    media_data_type: str,
    profile_version: str,
) -> list[dict[str, Any]]:
    image_url = (image_url or "").strip()
    image_file = (image_file or "").strip()
    raw_json = (raw_json or "").strip()

    source_count = sum(bool(x) for x in [image_url, image_file, raw_json])
    if source_count > 1:
        raise RuntimeError("use one of --image-url, --image-file, or --init-images-json")

    if raw_json:
        try:
            input_images = json.loads(raw_json)
        except Exception as exc:
            raise RuntimeError("init-images-json must be a valid JSON array") from exc
        if not isinstance(input_images, list) or not input_images:
            raise RuntimeError("init-images-json must contain at least one image")
        return [
            resolve_input_init_image(api_client, item, media_data_type, profile_version)
            for item in input_images
        ]

    if image_file:
        from .upload import upload_local_file

        uploaded_url = upload_local_file(api_client, image_file)
        return [{"url": uploaded_url, "profile": normalize_init_image_profile({}, media_data_type, profile_version)}]

    if image_url:
        return [{"url": image_url, "profile": normalize_init_image_profile({}, media_data_type, profile_version)}]

    raise RuntimeError("one of --image-url, --image-file, or --init-images-json is required")


def create_task_id(response: dict[str, Any]) -> str:
    data = response.get("data") or {}
    return str(data.get("task_id") or ((data.get("result") or {}).get("id")) or "").strip()


def response_failed(response: dict[str, Any]) -> bool:
    if response.get("code") != 0:
        return True
    data = response.get("data") or {}
    status = data.get("status")
    if status is None:
        return False
    return int(status) != 10 and not is_pending_task_status(int(status))


def response_trace_id(response: dict[str, Any]) -> str:
    return str(response.get("trace_id") or ((response.get("data") or {}).get("trace_id")) or "").strip()


def finalize_image_response(api_client: APIClient, response: dict[str, Any]) -> dict[str, Any]:
    if response.get("code") != 0:
        return response

    data = response.get("data") or {}
    status = data.get("status")
    if status is not None and (int(status) == 10 or response_failed(response)):
        return response

    task_id = create_task_id(response)
    if not task_id:
        return response

    timeout_ms = DEFAULT_GENERATE_TIMEOUT_MS
    predict_elapsed = int(data.get("predict_elapsed") or 0)
    if predict_elapsed > 0:
        timeout_ms = max(timeout_ms, predict_elapsed + 30000)
    return api_client.wait_task(task_id, DEFAULT_GENERATE_POLL_INTERVAL_MS, timeout_ms)
