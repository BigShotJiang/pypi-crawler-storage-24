from __future__ import annotations

import argparse
import json
import sys
from typing import Any

from . import __version__
from .api import (
    APIClient,
    DEFAULT_GENERATE_POLL_INTERVAL_MS,
    normalize_init_images,
    normalize_params_json,
    response_failed,
    response_trace_id,
)
from .config import load_credentials, mask_key, save_credentials
from .download import download_result_files, media_data_list


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="meitu", description="Meitu CLI for OpenAPI image tasks")
    parser.add_argument("-V", "--version", action="version", version=__version__)
    subparsers = parser.add_subparsers(dest="command")

    config_parser = subparsers.add_parser("config", help="manage local config")
    config_subparsers = config_parser.add_subparsers(dest="config_command")
    config_set_ak = config_subparsers.add_parser("set-ak", help="save access key locally")
    config_set_ak.add_argument("--value", required=True)
    config_set_sk = config_subparsers.add_parser("set-sk", help="save secret key locally")
    config_set_sk.add_argument("--value", required=True)

    auth_parser = subparsers.add_parser("auth", help="auth commands")
    auth_subparsers = auth_parser.add_subparsers(dest="auth_command")
    auth_verify = auth_subparsers.add_parser("verify", help="verify current credentials")
    auth_verify.add_argument("--json", action="store_true")
    auth_verify.add_argument("--path", default="")

    generate_parser = subparsers.add_parser("generate", help="call an image effect API")
    _add_generate_arguments(generate_parser)

    image_parser = subparsers.add_parser("image", help="legacy image alias")
    image_subparsers = image_parser.add_subparsers(dest="image_command")
    image_generate = image_subparsers.add_parser("generate", help="same as `meitu generate`")
    _add_generate_arguments(image_generate)

    task_parser = subparsers.add_parser("task", help="task commands")
    task_subparsers = task_parser.add_subparsers(dest="task_command")
    task_wait = task_subparsers.add_parser("wait", help="wait for a task to finish")
    task_wait.add_argument("--interval-ms", type=int, default=1000)
    task_wait.add_argument("--timeout-ms", type=int, default=120000)
    task_wait.add_argument("--download-dir", default="")
    task_wait.add_argument("--json", action="store_true")
    task_wait.add_argument("task_id")

    return parser


def _add_generate_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--task", required=True)
    parser.add_argument("--task-type", default="mtlab")
    parser.add_argument("--image-url", default="")
    parser.add_argument("--image-file", default="")
    parser.add_argument("--init-images-json", default="")
    parser.add_argument("--params-json", default='{"parameter":{}}')
    parser.add_argument("--rsp-media-type", default="url")
    parser.add_argument("--media-data-type", default="url")
    parser.add_argument("--profile-version", default="v1")
    parser.add_argument("--download-dir", default="")
    parser.add_argument("--json", action="store_true")


def print_json(value: Any) -> None:
    print(json.dumps(value, indent=2, ensure_ascii=False))


def command_config_set_ak(value: str) -> int:
    value = value.strip()
    if not value:
        print("invalid access key", file=sys.stderr)
        return 2
    save_credentials(access_key=value)
    print("access key saved")
    return 0


def command_config_set_sk(value: str) -> int:
    value = value.strip()
    if not value:
        print("invalid secret key", file=sys.stderr)
        return 2
    save_credentials(secret_key=value)
    print("secret key saved")
    return 0


def command_auth_verify(api_client: APIClient, as_json: bool, path: str) -> int:
    try:
        credentials = load_credentials()
        if credentials is None:
            raise RuntimeError("credentials not found")
        response = api_client.verify_auth(path)
    except Exception as exc:
        print(str(exc), file=sys.stderr)
        return 3

    ok = response.get("code") == 0
    message = str(response.get("message") or "").strip() or ("verified" if ok else "verification failed")
    payload = {
        "ok": ok,
        "code": response.get("code"),
        "access_key": mask_key(credentials.access_key),
        "message": message,
    }
    if as_json:
        print_json(payload)
        return 0

    print(f"status: {'ok' if ok else 'failed'}")
    print(f"code: {response.get('code')}")
    print(f"access key: {mask_key(credentials.access_key)}")
    print(message)
    return 0


def maybe_download_files(response: dict[str, Any], download_dir: str):
    if not download_dir.strip() or response_failed(response):
        return []
    return download_result_files(response, download_dir.strip())


def print_response_json(response: dict[str, Any], downloaded_files: list) -> None:
    if not downloaded_files:
        print_json(response)
        return
    print_json(
        {
            "result": response,
            "downloaded_files": [
                {"url": item.url, "saved_path": item.saved_path} for item in downloaded_files
            ],
        }
    )


def finalize_image_response(api_client: APIClient, response: dict[str, Any]) -> dict[str, Any]:
    from .api import finalize_image_response as _finalize

    return _finalize(api_client, response)


def command_generate(api_client: APIClient, args: argparse.Namespace) -> int:
    try:
        params_json = normalize_params_json(args.params_json)
        init_images = normalize_init_images(
            api_client,
            args.image_url,
            args.image_file,
            args.init_images_json,
            args.media_data_type,
            args.profile_version,
        )
        response = api_client.create_image(
            {
                "task": args.task.strip(),
                "task_type": args.task_type.strip(),
                "params": params_json,
                "init_images": init_images,
                "rsp_media_type": args.rsp_media_type.strip(),
            }
        )
        final_response = finalize_image_response(api_client, response)
        downloaded_files = maybe_download_files(final_response, args.download_dir)
    except Exception as exc:
        print(str(exc), file=sys.stderr)
        return 6

    if args.json:
        print_response_json(final_response, downloaded_files)
        return 5 if response_failed(final_response) else 0

    _print_human_response(final_response, downloaded_files)
    return 5 if response_failed(final_response) else 0


def command_task_wait(api_client: APIClient, args: argparse.Namespace) -> int:
    try:
        response = api_client.wait_task(args.task_id.strip(), args.interval_ms, args.timeout_ms)
        downloaded_files = maybe_download_files(response, args.download_dir)
    except Exception as exc:
        print(str(exc), file=sys.stderr)
        return 6

    if args.json:
        print_response_json(response, downloaded_files)
        return 5 if response_failed(response) else 0

    _print_human_response(response, downloaded_files)
    return 5 if response_failed(response) else 0


def _print_human_response(response: dict[str, Any], downloaded_files: list) -> None:
    message = str(response.get("message") or "").strip()
    if not message:
        message = "request completed" if response.get("code") == 0 else "request failed"
    print(f"code: {response.get('code')}")
    print(f"message: {message}")
    if str(response.get("request_id") or "").strip():
        print(f"request_id: {response['request_id']}")
    trace_id = response_trace_id(response)
    if trace_id:
        print(f"trace_id: {trace_id}")
    data = response.get("data") or {}
    if data:
        if data.get("status") is not None:
            print(f"status: {data['status']}")
        if str(data.get("task_id") or "").strip():
            print(f"task_id: {data['task_id']}")
        progress = data.get("progress")
        if isinstance(progress, (int, float)) and progress > 0:
            print(f"progress: {progress}")
    for media_data in media_data_list(response):
        print(f"result: {media_data}")
    for item in downloaded_files:
        print(f"saved: {item.saved_path}")


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    api_client = APIClient()

    if args.command is None:
        parser.print_help(sys.stderr)
        return 1

    if args.command == "config":
        if args.config_command == "set-ak":
            return command_config_set_ak(args.value)
        if args.config_command == "set-sk":
            return command_config_set_sk(args.value)
        parser.parse_args([args.command, "--help"])
        return 0

    if args.command == "auth":
        if args.auth_command == "verify":
            return command_auth_verify(api_client, args.json, args.path)
        parser.parse_args([args.command, "--help"])
        return 0

    if args.command == "generate":
        return command_generate(api_client, args)

    if args.command == "image":
        if args.image_command == "generate":
            return command_generate(api_client, args)
        parser.parse_args([args.command, "--help"])
        return 0

    if args.command == "task":
        if args.task_command == "wait":
            return command_task_wait(api_client, args)
        parser.parse_args([args.command, "--help"])
        return 0

    parser.print_help(sys.stderr)
    return 1

    parser.print_help()
    return 0
