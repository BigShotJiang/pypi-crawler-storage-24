from __future__ import annotations

import base64
import hashlib
import hmac
import json
from datetime import datetime, timezone
from urllib.parse import parse_qsl, urlencode, urlsplit


ALGORITHM = "SDK-HMAC-SHA256"
HEADER_X_DATE = "X-Sdk-Date"
HEADER_HOST = "Host"
HEADER_AUTHORIZATION = "Authorization"
HEADER_CONTENT_SHA256 = "X-Sdk-Content-Sha256"
BASIC_DATE_FORMAT = "%Y%m%dT%H%M%SZ"


def hash_sha256_hex(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def canonical_body_bytes(body: object | None) -> bytes:
    if body is None:
        return b""
    return json.dumps(body, separators=(",", ":"), ensure_ascii=False, sort_keys=True).encode("utf-8")


def canonical_uri(path: str) -> str:
    if not path or not path.endswith("/"):
        return f"{path}/"
    return path


def canonical_query(query: str) -> str:
    if not query:
        return ""
    pairs = parse_qsl(query, keep_blank_values=True)
    pairs.sort()
    return urlencode(pairs, doseq=True)


def sign_string_to_sign(string_to_sign: str, secret: str) -> str:
    return hmac.new(secret.encode("utf-8"), string_to_sign.encode("utf-8"), hashlib.sha256).hexdigest()


def auth_header_value(signature: str, access_key: str, signed_headers: list[str]) -> str:
    raw = (
        f"{ALGORITHM} Access={access_key}, "
        f"SignedHeaders={';'.join(signed_headers)}, "
        f"Signature={signature}"
    )
    return "Bearer " + base64.b64encode(raw.encode("utf-8")).decode("utf-8")


def normalize_headers(headers: dict[str, str]) -> dict[str, str]:
    return {key: str(value).strip() for key, value in headers.items() if str(value).strip()}


def canonical_headers(headers: dict[str, str], signed_headers: list[str]) -> str:
    lowered = {key.lower(): value.strip() for key, value in headers.items()}
    lines = [f"{key}:{lowered.get(key, '')}" for key in signed_headers]
    lines.sort()
    return "\n".join(lines)


def signed_headers(headers: dict[str, str]) -> list[str]:
    return sorted(key.lower() for key in headers)


def canonical_request(method: str, request_url: str, headers: dict[str, str], body: str) -> str:
    parsed = urlsplit(request_url)
    signed = signed_headers(headers)
    body_hash = headers.get(HEADER_CONTENT_SHA256) or headers.get(HEADER_CONTENT_SHA256.lower()) or hash_sha256_hex(body)
    return "\n".join(
        [
            method.upper(),
            canonical_uri(parsed.path),
            canonical_query(parsed.query),
            canonical_headers(headers, signed),
            ";".join(signed),
            body_hash,
        ]
    )


def string_to_sign(canonical_request_value: str, time_value: str) -> str:
    return f"{ALGORITHM}\n{time_value}\n{hash_sha256_hex(canonical_request_value)}"


def sign_sdk_headers(
    request_url: str,
    method: str,
    headers: dict[str, str],
    body: str,
    access_key: str,
    secret_key: str,
) -> tuple[str, str, dict[str, str]]:
    parsed = urlsplit(request_url)
    normalized = normalize_headers(headers)
    normalized[HEADER_HOST] = normalized.get(HEADER_HOST, parsed.netloc)
    normalized[HEADER_X_DATE] = normalized.get(
        HEADER_X_DATE, datetime.now(timezone.utc).strftime(BASIC_DATE_FORMAT)
    )

    # validate date format if provided
    datetime.strptime(normalized[HEADER_X_DATE], BASIC_DATE_FORMAT)

    canonical_request_value = canonical_request(method, request_url, normalized, body)
    signature = sign_string_to_sign(
        string_to_sign(canonical_request_value, normalized[HEADER_X_DATE]), secret_key
    )
    normalized[HEADER_AUTHORIZATION] = auth_header_value(
        signature,
        access_key,
        signed_headers(normalized),
    )
    return normalized[HEADER_HOST], normalized[HEADER_X_DATE], normalized
