from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path


@dataclass
class Credentials:
    access_key: str
    secret_key: str


def credentials_dir() -> Path:
    return Path.home() / ".meitu"


def credentials_file() -> Path:
    return credentials_dir() / "credentials.json"


def load_stored_credentials() -> Credentials | None:
    file_path = credentials_file()
    if not file_path.exists():
        return None

    try:
        payload = json.loads(file_path.read_text(encoding="utf-8"))
    except Exception as exc:  # pragma: no cover - defensive path
        raise RuntimeError(f"parse credentials: {exc}") from exc

    access_key = str(payload.get("accessKey", "")).strip()
    secret_key = str(payload.get("secretKey", "")).strip()
    if not access_key or not secret_key:
        return None

    return Credentials(access_key=access_key, secret_key=secret_key)


def load_credentials() -> Credentials | None:
    env_access_key = os.getenv("OPENAPI_ACCESS_KEY", "").strip()
    env_secret_key = os.getenv("OPENAPI_SECRET_KEY", "").strip()
    if bool(env_access_key) != bool(env_secret_key):
        raise RuntimeError("OPENAPI_ACCESS_KEY and OPENAPI_SECRET_KEY must be set together")
    if env_access_key and env_secret_key:
        return Credentials(access_key=env_access_key, secret_key=env_secret_key)

    return load_stored_credentials()


def save_credentials(*, access_key: str | None = None, secret_key: str | None = None) -> None:
    dir_path = credentials_dir()
    dir_path.mkdir(mode=0o700, parents=True, exist_ok=True)
    os.chmod(dir_path, 0o700)

    file_path = credentials_file()
    current = {"accessKey": "", "secretKey": ""}
    if file_path.exists():
        current.update(json.loads(file_path.read_text(encoding="utf-8")))

    if access_key is not None:
        current["accessKey"] = access_key.strip()
    if secret_key is not None:
        current["secretKey"] = secret_key.strip()

    file_path.write_text(json.dumps(current, indent=2) + "\n", encoding="utf-8")
    os.chmod(file_path, 0o600)


def mask_key(value: str) -> str:
    value = value.strip()
    if len(value) <= 6:
        return "***"
    return f"{value[:3]}***{value[-3:]}"
