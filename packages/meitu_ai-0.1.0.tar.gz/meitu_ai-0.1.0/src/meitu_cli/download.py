from __future__ import annotations

import mimetypes
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlsplit
from urllib.request import urlopen


@dataclass
class DownloadedFile:
    url: str
    saved_path: str


def media_data_list(response: dict) -> list[str]:
    result = (((response.get("data") or {}).get("result")) or {})
    items: list[str] = []
    seen: set[str] = set()

    def append_item(value: str) -> None:
        value = str(value or "").strip()
        if not value or value in seen:
            return
        seen.add(value)
        items.append(value)

    append_item(result.get("url", ""))
    for value in result.get("urls", []) or []:
        append_item(value)
    for media in result.get("media_info_list", []) or []:
        append_item(media.get("media_data", ""))
    return items


def sanitize_filename(value: str) -> str:
    clean = "".join(ch if ch.isalnum() or ch in "-_" else "-" for ch in value.strip())
    return clean.strip("-") or "result"


def detect_file_extension(raw_url: str, content_type: str) -> str:
    path = urlsplit(raw_url).path
    suffix = Path(path).suffix
    if suffix and len(suffix) <= 10:
        return suffix
    if content_type:
        ext = mimetypes.guess_extension(content_type.split(";", 1)[0].strip())
        if ext:
            return ext
    return ".bin"


def unique_download_path(dir_path: Path, filename: str) -> Path:
    suffix = Path(filename).suffix
    stem = filename[: -len(suffix)] if suffix else filename
    for index in range(1, 10000):
        candidate_name = filename if index == 1 else f"{stem}-{index}{suffix}"
        candidate = dir_path / candidate_name
        if not candidate.exists():
            return candidate
    raise RuntimeError("unable to allocate a unique download file path")


def download_file(raw_url: str, dir_path: Path, prefix: str, index: int) -> str:
    with urlopen(raw_url, timeout=60) as response:
        if response.status < 200 or response.status >= 300:
            raise RuntimeError(f"download {raw_url} failed: {response.status}")
        content_type = response.headers.get("Content-Type", "")
        filename = f"{sanitize_filename(prefix)}-{index}{detect_file_extension(raw_url, content_type)}"
        target = unique_download_path(dir_path, filename)
        target.write_bytes(response.read())
        return str(target.resolve())


def download_result_files(response: dict, dir_name: str) -> list[DownloadedFile]:
    urls = media_data_list(response)
    if not urls:
        raise RuntimeError("no downloadable result urls found")

    dir_path = Path(dir_name)
    dir_path.mkdir(parents=True, exist_ok=True)

    task_id = str(((response.get("data") or {}).get("task_id")) or "").strip() or "result"
    files: list[DownloadedFile] = []
    for index, raw_url in enumerate(urls, start=1):
        files.append(DownloadedFile(url=raw_url, saved_path=download_file(raw_url, dir_path, task_id, index)))
    return files
