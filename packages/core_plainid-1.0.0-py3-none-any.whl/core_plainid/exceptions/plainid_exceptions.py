from typing import Optional


class PlainIDException(Exception):
    """Base exception for all PlainID-related errors."""

    def __init__(
        self, message: str, original_exception: Optional[Exception] = None
    ):
        self.message = message
        self.original_exception = original_exception
        
        super().__init__(message)


class PlainIDAuthClientException(PlainIDException):
    """Exception raised for errors in the PlainID Auth client."""


class PlainIDPermissionsException(PlainIDException):
    """Exception raised for errors in permissions processing."""


class PlainIDFilterException(PlainIDException):
    """Exception raised for errors in filter processing."""


class PlainIDRetrieverException(PlainIDException):
    """Exception raised for errors in the retriever components."""


class PlainIDCategorizerException(PlainIDException):
    """Exception raised for errors in the categorizer component."""


class PlainIDAnonymizerException(PlainIDException):
    """Exception raised for errors in the anonymizer component."""


class PlainIDSQLAuthorizerClientException(PlainIDException):
    """Exception raised for errors in the SQL Authorizer client."""


class LlmResponseException(PlainIDException):
    """Exception raised for malformed or unexpected LLM responses."""
