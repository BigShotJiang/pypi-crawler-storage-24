from __future__ import annotations

import json
from typing import Any, TypeVar

from litellm import acompletion, completion
from pydantic import BaseModel

from core_plainid.exceptions.plainid_exceptions import LlmResponseException

TStructuredOutput = TypeVar("TStructuredOutput", bound=BaseModel)


def structured_completion(
    model: str,
    system_prompt: str,
    user_query: str,
    response_model: type[TStructuredOutput],
    **kwargs: Any,
) -> TStructuredOutput:
    """Send a structured completion request via LiteLLM and return a parsed Pydantic model.

    Args:
        model: LiteLLM model identifier (e.g. ``"gpt-4o"``, ``"azure/gpt-4"``).
        system_prompt: System message content.
        user_query: User message content.
        response_model: Pydantic model class to validate the response against.
        **kwargs: Additional arguments forwarded to ``litellm.completion``.

    Returns:
        An instance of *response_model* parsed from the LLM response.

    Raises:
        LlmResponseException: If the response cannot be parsed or validated.
    """
    response = completion(
        model=model,
        messages=_build_messages(system_prompt, user_query),
        response_format=response_model,
        **kwargs,
    )

    return _parse_completion_response(response, response_model)


async def astructured_completion(
    model: str,
    system_prompt: str,
    user_query: str,
    response_model: type[TStructuredOutput],
    **kwargs: Any,
) -> TStructuredOutput:
    """Async version of :func:`structured_completion`."""
    response = await acompletion(
        model=model,
        messages=_build_messages(system_prompt, user_query),
        response_format=response_model,
        **kwargs,
    )

    return _parse_completion_response(response, response_model)


def _build_messages(system_prompt: str, user_query: str) -> list[dict[str, str]]:
    return [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_query},
    ]


def _parse_completion_response(
    response: Any, 
    response_model: type[TStructuredOutput]
) -> TStructuredOutput:
    choices = getattr(response, "choices", None)

    if not isinstance(choices, list):
        raise LlmResponseException("LiteLLM response did not include choices list")
    if len(choices) == 0:
        raise LlmResponseException("LiteLLM response choices list is empty")

    first_choice = choices[0]
    message = getattr(first_choice, "message", None)

    if message is None:
        raise LlmResponseException("LiteLLM response choice did not include message")

    content = getattr(message, "content", None)

    return _validate_content(content, response_model)


def _validate_content(
    content: Any,
    response_model: type[TStructuredOutput],
) -> TStructuredOutput:
    parsed = _parse_content(content)

    return response_model.model_validate(parsed)


def _parse_content(content: Any) -> dict:
    if isinstance(content, dict):
        return content

    if isinstance(content, str):
        try:
            return json.loads(content)
        except json.JSONDecodeError as e:
            raise LlmResponseException(
                f"LiteLLM response content is not valid JSON: {content}"
            ) from e

    raise LlmResponseException(
        f"LiteLLM response message content must be a dict or JSON string, got {type(content).__name__}"
    )
