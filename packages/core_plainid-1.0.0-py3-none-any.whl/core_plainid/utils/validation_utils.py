import os


def is_blank(value: str | None) -> bool:
    """Return True if the value is None, empty, or contains only whitespace."""

    return not value or not value.strip()


def validate_not_blank(**fields: str | None) -> None:
    """Raise ValueError if any of the provided fields are blank."""

    for name, value in fields.items():
        if is_blank(value):
            raise ValueError(f"{name} must be a non-empty string")


def validate_env_vars(*names: str) -> None:
    """Raise ValueError if any of the provided environment variables are missing or blank."""

    for name in names:
        if is_blank(os.getenv(name)):
            raise ValueError(f"{name} environment variable must be a non-empty string")
