def capitalize_header_names(headers: dict[str, str]) -> dict[str, str]:
    return {
        "-".join(word.capitalize() for word in key.split("-")): value
        for key, value in headers.items()
    }
