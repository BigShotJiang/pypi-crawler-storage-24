import logging
from contextlib import contextmanager
from typing import Any, Iterator, Optional

from core_plainid.clients.plainid_auth_client import PlainIDAuthClient
from core_plainid.exceptions.plainid_exceptions import PlainIDPermissionsException
from core_plainid.utils.validation_utils import validate_not_blank
from core_plainid.models.context.request_context import RequestContext
from core_plainid.models.permissions.plainid_entity_action import PlainIDEntityAction
from core_plainid.utils.regex_utils import is_valid_regex
from core_plainid.models.permissions.plainid_permissions import PlainIDPermissions
from core_plainid.models.response.user_access_token_response import (
    UserAccessTokenResponse,
    UserAccessTokenResponseItem,
)

logger = logging.getLogger(__name__)


class PlainIDPermissionsProvider:
    """
    Provides access to user permissions from PlainID.

    This provider calls the get_token endpoint from PlainID client
    to retrieve permissions information.
    """

    REGEX_PATH = "REGEX"
    REGEX_VALUE_ATTRIBUTE = "regexValue"

    def __init__(
        self,
        base_url: str,
        client_id: str,
        client_secret: str,
        request_context: Optional[RequestContext] = None,
        plainid_categories_resource_type: str = "Prompt_Control",
        plainid_entities_resource_type: str = "Output_Control",
        plainid_tools_resource_type: str = "Tools",
        **kwargs: Any
    ):
        """
        Initialize PlainIDPermissionsProvider with authentication credentials.

        Args:
            base_url (str): Base URL for PlainID service
            client_id (str): Client ID for authentication
            client_secret (str): Client secret for authentication
            request_context: Optional context to eagerly load permissions at init time.
            plainid_categories_resource_type (str): Resource type for categories in PlainID
            plainid_entities_resource_type (str): Resource type for entities in PlainID
            plainid_tools_resource_type (str): Resource type for tools in PlainID
        """
        validate_not_blank(
            base_url=base_url,
            client_id=client_id,
            client_secret=client_secret,
            plainid_categories_resource_type=plainid_categories_resource_type,
            plainid_entities_resource_type=plainid_entities_resource_type,
            plainid_tools_resource_type=plainid_tools_resource_type,
        )

        self._kwargs = kwargs
        self._plainid_categories_resource_type = plainid_categories_resource_type
        self._plainid_entities_resource_type = plainid_entities_resource_type
        self._plainid_tools_resource_type = plainid_tools_resource_type
        self._client = PlainIDAuthClient(base_url, client_id, client_secret)
        self._initial_request_context = request_context
        self._initial_permissions: Optional[PlainIDPermissions] = None

        self._load_initial_permissions_if_needed()

    def get_permissions(
        self, request_context: Optional[RequestContext] = None
    ) -> PlainIDPermissions:
        """Retrieve permissions from the PlainID token endpoint.

        Args:
            request_context: Identity context for the PlainID request.
                Falls back to the context provided at construction time.

        Returns:
            PlainIDPermissions containing categories, entities, and tools.

        Raises:
            PlainIDPermissionsException: If no request context is available
                or the PlainID call fails.
        """
        if request_context is None:
            return self._get_initial_permissions()
        
        return self._get_permissions_by_context(request_context)

    async def aget_permissions(
        self, request_context: Optional[RequestContext] = None
    ) -> PlainIDPermissions:
        """Async version of :meth:`get_permissions`."""
        if request_context is None:
            return self._get_initial_permissions()
        
        return await self._aget_permissions_by_context(request_context)

    def _get_initial_permissions(self) -> PlainIDPermissions:
        if self._initial_permissions is None:
            raise PlainIDPermissionsException(
                "request_context is required when provider is not initialized with an initial context"
            )

        return self._initial_permissions

    def _load_initial_permissions_if_needed(self) -> None:
        if self._initial_request_context is None:
            return

        self._initial_permissions = self._get_permissions_by_context(
            self._initial_request_context
        )

    def _get_permissions_by_context(
        self, request_context: RequestContext
    ) -> PlainIDPermissions:
        with self._error_handling():
            token_data = self._client.get_token(
                entity_id=request_context.entity_id,
                entity_type_id=request_context.entity_id_type,
                additional_identities=request_context.get_additional_identities_request(),
                **self._kwargs,
            )

            return self._process_token_data(token_data)

    async def _aget_permissions_by_context(
        self, request_context: RequestContext
    ) -> PlainIDPermissions:
        with self._error_handling():
            token_data = await self._client.aget_token(
                entity_id=request_context.entity_id,
                entity_type_id=request_context.entity_id_type,
                additional_identities=request_context.get_additional_identities_request(),
                **self._kwargs,
            )

            return self._process_token_data(token_data)

    def _process_token_data(
        self, token_data: Optional[UserAccessTokenResponse]
    ) -> PlainIDPermissions:
        if token_data is None:
            raise PlainIDPermissionsException(
                "Failed to retrieve token data from PlainID"
            )

        logger.debug("token retrieved: %s", token_data)

        return self._extract_permissions(token_data)

    def _extract_permissions(
        self, token_data: UserAccessTokenResponse
    ) -> PlainIDPermissions:
        normalized_items = self._normalize_response_items(token_data)

        if not normalized_items:
            return PlainIDPermissions()

        try:
            categories, entities, tools = self._aggregate_permissions(normalized_items)

            return PlainIDPermissions(categories=categories, entities=entities, tools=tools)

        except Exception as e:
            logger.error("Error extracting permissions from token data: %s", str(e))

            raise PlainIDPermissionsException(
                "Failed to extract permissions from token data", e
            )

    def _normalize_response_items(
        self, token_data: UserAccessTokenResponse
    ) -> list[UserAccessTokenResponseItem]:
        # token_data can have 2 token shapes:
        # 1) response: [...]
        # 2) response: {access: [...]}
        if isinstance(token_data.response, list):
            return token_data.response

        if isinstance(token_data.response, UserAccessTokenResponseItem):
            return [token_data.response]

        return []

    def _aggregate_permissions(
        self, items: list[UserAccessTokenResponseItem]
    ) -> tuple[list[str], list[PlainIDEntityAction], list[str]]:
        categories: list[str] = []
        entities: list[PlainIDEntityAction] = []
        tools: list[str] = []

        for item in items:
            item_categories, item_entities, item_tools = (
                self._process_access_permissions_from_item(item)
            )

            categories.extend(item_categories)
            entities.extend(item_entities)
            tools.extend(item_tools)

        return categories, entities, tools

    def _process_access_permissions_from_item(
        self,
        item: UserAccessTokenResponseItem,
    ) -> tuple[list[str], list[PlainIDEntityAction], list[str]]:
        categories: list[str] = []
        entities: list[PlainIDEntityAction] = []
        tools: list[str] = []

        for access_item in item.access:
            path = access_item.path
            resource_type = access_item.resource_type

            if not path or not resource_type:
                continue

            if resource_type == self._plainid_categories_resource_type:
                categories.append(path)

            elif resource_type == self._plainid_entities_resource_type:
                actions = [
                    action_item.action
                    for action_item in access_item.actions
                    if action_item.action
                ]

                if actions:
                    regex_pattern = None

                    if path.startswith(self.REGEX_PATH):
                        regex_pattern = self._extract_regex_pattern(access_item.attributes)

                    entities.append(PlainIDEntityAction(
                        name=path,
                        actions=actions,
                        regex_pattern=regex_pattern,
                    ))

            elif resource_type == self._plainid_tools_resource_type:
                tools.append(path)

        return categories, entities, tools

    def _extract_regex_pattern(self, attributes: dict) -> str:
        raw_value = attributes.get(self.REGEX_VALUE_ATTRIBUTE)

        if isinstance(raw_value, list):
            pattern = raw_value[0] if raw_value else None
        elif isinstance(raw_value, str):
            pattern = raw_value
        else:
            pattern = None

        if pattern is None:
            raise PlainIDPermissionsException(
                f"REGEX path requires a valid string '{self.REGEX_VALUE_ATTRIBUTE}' attribute"
            )

        if not is_valid_regex(pattern):
            raise PlainIDPermissionsException(
                f"Invalid regex pattern: '{pattern}'"
            )

        return pattern
    
    @contextmanager
    def _error_handling(self) -> Iterator[None]:
        try:
            yield
        except PlainIDPermissionsException as e:
            logger.error("Permissions error: %s", e)
            
            raise
        except Exception as e:
            logger.error("Error retrieving permissions: %s", e)
            
            raise PlainIDPermissionsException("Error retrieving permissions", e)
