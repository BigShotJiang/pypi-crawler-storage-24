import re

def is_valid_regex(pattern: str) -> bool:
    """Return True if *pattern* is a valid regular expression, False otherwise."""
    try:
        re.compile(pattern)

        return True
    except Exception:
        return False
