from string import Formatter
from typing import Any

def render_prompt_template(template: str, values: dict[str, Any]) -> str:
    """Render a Python format-string template with the given values.

    Args:
        template: A string with ``{field}`` placeholders.
        values: Mapping of field names to their substitution values.

    Returns:
        The rendered string.

    Raises:
        KeyError: If the template contains placeholders not present in *values*.
    """
    formatter = Formatter()
    missing_fields = [
        field_name
        for _, field_name, _, _ in formatter.parse(template)
        if field_name and field_name not in values
    ]
    if missing_fields:
        raise KeyError(
            f"Missing prompt template values for: {', '.join(sorted(set(missing_fields)))}"
        )

    return formatter.vformat(template, (), values)
