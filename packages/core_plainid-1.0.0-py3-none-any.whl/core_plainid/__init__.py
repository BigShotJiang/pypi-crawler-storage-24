import os
import sys

# Prevent OpenMP abort when both torch and faiss-cpu are installed.
# Both bundle their own libomp.dylib on macOS (and libiomp5md.dll on Windows),
# causing OMP Error #15 when the second copy initializes.
# Linux is unaffected because both link against the shared system OpenMP.
if sys.platform != "linux":
    os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")

from core_plainid.anonymization.base_anonymizer import BaseAnonymizer
from core_plainid.anonymization.presidio_anonymizer import PresidioAnonymizer
from core_plainid.categorization.base_categorizer import BaseCategorizer
from core_plainid.categorization.categorizer import Categorizer
from core_plainid.categorization.category_classifier_provider import CategoryClassifierProvider
from core_plainid.categorization.llm_category_classifier_provider import LLMCategoryClassifierProvider
from core_plainid.categorization.zeroshot_category_classifier_provider import ZeroShotCategoryClassifierProvider
from core_plainid.clients.base_plainid_client import BasePlainIDClient
from core_plainid.clients.plainid_auth_client import PlainIDAuthClient
from core_plainid.clients.plainid_sql_authorizer_client import PlainIDSQLAuthorizerClient
from core_plainid.enums.http_header import HttpHeader
from core_plainid.enums.plainid_client_headers import PlainIDClientHeader
from core_plainid.exceptions.plainid_exceptions import (
    LlmResponseException,
    PlainIDAnonymizerException,
    PlainIDAuthClientException,
    PlainIDCategorizerException,
    PlainIDException,
    PlainIDFilterException,
    PlainIDPermissionsException,
    PlainIDRetrieverException,
    PlainIDSQLAuthorizerClientException,
)
from core_plainid.models.base.plainid_api_model import PlainIDApiModel
from core_plainid.models.base.plainid_base_model import PlainIDBaseModel
from core_plainid.models.categorization.category_classification_structured_output import (
    CategoryClassificationStructuredOutput,
)
from core_plainid.models.context.request_context import AdditionalIdentity, RequestContext
from core_plainid.models.permissions.plainid_entity_action import PlainIDEntityAction
from core_plainid.models.permissions.plainid_permissions import PlainIDPermissions
from core_plainid.models.request.additional_identity_request import AdditionalIdentityRequest
from core_plainid.models.request.resolution_request import ResolutionRequest, ResolutionRequestEnvironment
from core_plainid.models.request.sql_authorizer_request import (
    PoliciesJoinOperation,
    SQLAuthorizerFlags,
    SQLAuthorizerRequest,
    SQLAuthorizerRuntimeFineTune,
)
from core_plainid.models.request.token_request import TokenRequest
from core_plainid.models.response.resolution_response import (
    ResolutionAction,
    ResolutionAllowedRule,
    ResolutionPrivileges,
    ResolutionResponse,
    ResolutionResponseItem,
)
from core_plainid.models.response.sql_authorizer_response import SQLAuthorizerResponse
from core_plainid.models.response.user_access_token_response import (
    UserAccessTokenAction,
    UserAccessTokenAccessItem,
    UserAccessTokenResponse,
    UserAccessTokenResponseItem,
)
from core_plainid.retrieval.base_retriever import BaseRetriever
from core_plainid.retrieval.filter_provider import FilterProvider
from core_plainid.utils.http_headers import capitalize_header_names
from core_plainid.utils.litellm_utils import astructured_completion, structured_completion
from core_plainid.utils.plainid_permissions_provider import PlainIDPermissionsProvider
from core_plainid.utils.prompt_utils import render_prompt_template
from core_plainid.utils.regex_utils import is_valid_regex
from core_plainid.utils.validation_utils import is_blank, validate_not_blank

__all__ = [
    "AdditionalIdentity",
    "AdditionalIdentityRequest",
    "BaseAnonymizer",
    "BaseCategorizer",
    "BasePlainIDClient",
    "BaseRetriever",
    "Categorizer",
    "CategoryClassificationStructuredOutput",
    "CategoryClassifierProvider",
    "FilterProvider",
    "HttpHeader",
    "LLMCategoryClassifierProvider",
    "LlmResponseException",
    "PlainIDAnonymizerException",
    "PlainIDApiModel",
    "PlainIDAuthClient",
    "PlainIDAuthClientException",
    "PlainIDBaseModel",
    "PlainIDCategorizerException",
    "PlainIDClientHeader",
    "PlainIDEntityAction",
    "PlainIDException",
    "PlainIDFilterException",
    "PlainIDPermissions",
    "PlainIDPermissionsException",
    "PlainIDPermissionsProvider",
    "PlainIDRetrieverException",
    "PlainIDSQLAuthorizerClient",
    "PlainIDSQLAuthorizerClientException",
    "PoliciesJoinOperation",
    "PresidioAnonymizer",
    "RequestContext",
    "ResolutionAction",
    "ResolutionAllowedRule",
    "ResolutionPrivileges",
    "ResolutionRequest",
    "ResolutionRequestEnvironment",
    "ResolutionResponse",
    "ResolutionResponseItem",
    "SQLAuthorizerFlags",
    "SQLAuthorizerRequest",
    "SQLAuthorizerResponse",
    "SQLAuthorizerRuntimeFineTune",
    "TokenRequest",
    "UserAccessTokenAction",
    "UserAccessTokenAccessItem",
    "UserAccessTokenResponse",
    "UserAccessTokenResponseItem",
    "ZeroShotCategoryClassifierProvider",
    "astructured_completion",
    "capitalize_header_names",
    "is_blank",
    "is_valid_regex",
    "render_prompt_template",
    "structured_completion",
    "validate_not_blank",
]
