from pydantic import ConfigDict

from core_plainid.models.base.plainid_base_model import PlainIDBaseModel


class PlainIDApiModel(PlainIDBaseModel):
    model_config = ConfigDict(validate_by_name=True, validate_by_alias=True)
