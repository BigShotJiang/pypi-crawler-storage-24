from pydantic import BaseModel, ConfigDict


class PlainIDBaseModel(BaseModel):
    model_config = ConfigDict(extra="ignore")
