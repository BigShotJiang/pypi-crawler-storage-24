from typing import Optional

from pydantic import Field

from core_plainid.models.base.plainid_api_model import PlainIDApiModel
from core_plainid.models.request.additional_identity_request import AdditionalIdentityRequest


class TokenRequest(PlainIDApiModel):
    client_id: str = Field(alias="clientId")
    client_secret: str = Field(alias="clientSecret")
    entity_id: str = Field(alias="entityId")
    entity_type_id: str = Field(alias="entityTypeId")
    include_attributes: bool = Field(default=True, alias="includeAttributes")
    additional_identities: Optional[list[AdditionalIdentityRequest]] = Field(
        default=None, alias="additionalIdentities"
    )
