from pydantic import Field

from core_plainid.models.base.plainid_api_model import PlainIDApiModel


class AdditionalIdentityRequest(PlainIDApiModel):
    entity_id: str = Field(alias="entityId")
    entity_type_id: str = Field(alias="entityTypeId")
