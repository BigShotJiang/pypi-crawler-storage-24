from typing import Optional

from pydantic import Field

from core_plainid.models.base.plainid_api_model import PlainIDApiModel
from core_plainid.models.request.additional_identity_request import AdditionalIdentityRequest


class ResolutionRequestEnvironment(PlainIDApiModel):
    resource_full_path: list[str] = Field(alias="resourceFullPath")


class ResolutionRequest(PlainIDApiModel):
    client_id: str = Field(alias="clientId")
    client_secret: str = Field(alias="clientSecret")
    entity_id: str = Field(alias="entityId")
    entity_type_id: str = Field(alias="entityTypeId")
    include_attributes: bool = Field(default=True, alias="includeAttributes")
    environment: Optional[ResolutionRequestEnvironment] = None
    additional_identities: Optional[list[AdditionalIdentityRequest]] = Field(
        default=None, alias="additionalIdentities"
    )
