from pydantic import Field

from core_plainid.models.base.plainid_base_model import PlainIDBaseModel

class CategoryClassificationStructuredOutput(PlainIDBaseModel):
    categories: list[str] = Field(default_factory=list)
