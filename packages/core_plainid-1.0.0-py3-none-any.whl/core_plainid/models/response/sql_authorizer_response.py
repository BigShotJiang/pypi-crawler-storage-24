from typing import Optional

from pydantic import Field

from core_plainid.models.base.plainid_api_model import PlainIDApiModel


class SQLAuthorizerResponse(PlainIDApiModel):
    """Response model from the SQL Authorizer /resql endpoint."""

    sql: str
    was_modified: bool = Field(alias="wasModified")
    error: Optional[str] = Field(default=None)
