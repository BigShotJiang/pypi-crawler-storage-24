from typing import Any
from pydantic import Field

from core_plainid.models.base.plainid_api_model import PlainIDApiModel


class ResolutionAction(PlainIDApiModel):
    """An action within an allowed privilege rule."""

    asset_attributes_filter: dict[str, Any] = Field(
        default_factory=dict, alias="asset-attributes-filter"
    )


class ResolutionAllowedRule(PlainIDApiModel):
    """A single allowed privilege rule scoped to a resource type."""

    resource_type: str = Field(alias="resourceType")
    actions: list[ResolutionAction] = Field(default_factory=list)


class ResolutionPrivileges(PlainIDApiModel):
    """The privileges block containing allowed and denied rules."""

    allowed: list[ResolutionAllowedRule] = Field(default_factory=list)


class ResolutionResponseItem(PlainIDApiModel):
    """A single item in the resolution response array."""

    privileges: ResolutionPrivileges = Field(default_factory=ResolutionPrivileges)


class ResolutionResponse(PlainIDApiModel):
    """Top-level resolution response from the PlainID API."""

    response: list[ResolutionResponseItem] = Field(default_factory=list)
