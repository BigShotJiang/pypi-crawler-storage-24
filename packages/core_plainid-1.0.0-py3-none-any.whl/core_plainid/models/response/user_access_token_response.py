from typing import Any, Optional, Union
from pydantic import Field

from core_plainid.models.base.plainid_api_model import PlainIDApiModel


class UserAccessTokenAction(PlainIDApiModel):
    action: Optional[str] = None


class UserAccessTokenAccessItem(PlainIDApiModel):
    path: Optional[str] = None
    attributes: dict[str, Any] = Field(default_factory=dict)
    resource_type: Optional[str] = Field(default=None, alias="resourceType")
    actions: list[UserAccessTokenAction] = Field(default_factory=list)


class UserAccessTokenResponseItem(PlainIDApiModel):
    access: list[UserAccessTokenAccessItem] = Field(default_factory=list)


class UserAccessTokenResponse(PlainIDApiModel):
    response: Optional[
        Union[list[UserAccessTokenResponseItem], UserAccessTokenResponseItem]
    ] = None
