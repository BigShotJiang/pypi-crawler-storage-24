from typing import Annotated, Optional
from pydantic import BaseModel, Field, StringConstraints

from core_plainid.models.request.additional_identity_request import AdditionalIdentityRequest


class AdditionalIdentity(BaseModel):
    entity_id: Annotated[str, StringConstraints(min_length=1)]
    entity_type_id: Annotated[str, StringConstraints(min_length=1)]


class RequestContext(BaseModel):
    entity_id: Annotated[
        str, StringConstraints(min_length=1)
    ]
    entity_id_type: Annotated[
        str, StringConstraints(min_length=1)
    ]
    auth_token: str = ""
    headers: dict[str, str] = Field(default_factory=dict)
    additional_identities: Optional[list[AdditionalIdentity]] = None

    def get_additional_identities_request(self) -> Optional[list[AdditionalIdentityRequest]]:
        if not self.additional_identities:
            return None

        return [
            AdditionalIdentityRequest(
                entity_id=identity.entity_id,
                entity_type_id=identity.entity_type_id,
            )
            for identity in self.additional_identities
        ]
