from dataclasses import dataclass, field
from core_plainid.models.permissions.plainid_entity_action import PlainIDEntityAction

@dataclass
class PlainIDPermissions:
    categories: list[str] = field(default_factory=list)
    entities: list[PlainIDEntityAction] = field(default_factory=list)
    tools: list[str] = field(default_factory=list)
