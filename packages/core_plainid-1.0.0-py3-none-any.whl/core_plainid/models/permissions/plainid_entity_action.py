from dataclasses import dataclass, field
from typing import Optional


@dataclass
class PlainIDEntityAction:
    name: str
    actions: list[str]
    regex_pattern: Optional[str] = None
