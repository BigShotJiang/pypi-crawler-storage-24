import logging
from typing import Any, Optional

from core_plainid.clients.base_plainid_client import BasePlainIDClient, PreparedRequest
from core_plainid.utils.validation_utils import validate_not_blank
from core_plainid.enums.http_header import HttpHeader
from core_plainid.enums.plainid_client_headers import PlainIDClientHeader
from core_plainid.exceptions.plainid_exceptions import PlainIDAuthClientException
from core_plainid.models.request.additional_identity_request import AdditionalIdentityRequest
from core_plainid.models.request.resolution_request import (
    ResolutionRequest,
    ResolutionRequestEnvironment,
)
from core_plainid.models.request.token_request import TokenRequest
from core_plainid.models.response.resolution_response import ResolutionResponse
from core_plainid.models.response.user_access_token_response import UserAccessTokenResponse
from core_plainid.utils.http_headers import capitalize_header_names

logger = logging.getLogger(__name__)


class PlainIDAuthClient(BasePlainIDClient):
    """Client for the PlainID runtime API (resolution and token endpoints)."""

    RESOLUTION_ENDPOINT = "/runtime/resolution/v3"
    TOKEN_ENDPOINT = "/runtime/token/v3"

    def __init__(
        self, base_url: str, client_id: str, client_secret: str
    ):
        """
        Initialize PlainIDAuthClient with authentication credentials.

        Args:
            base_url (str): Base URL for PlainID service
            client_id (str): Client ID for authentication
            client_secret (str): Client secret for authentication
        """
        validate_not_blank(client_secret=client_secret)

        super().__init__(
            base_url=base_url,
            client_id=client_id,
            client_secret=client_secret,
            exception_class=PlainIDAuthClientException,
        )

    def get_resolution(
        self,
        entity_id: str,
        entity_type_id: str,
        resource_full_paths: Optional[list[str]] = None,
        include_attributes: bool = True,
        auth_token: str = "",
        headers: Optional[dict[str, str]] = None,
        additional_identities: Optional[list[AdditionalIdentityRequest]] = None,
        **kwargs,
    ) -> ResolutionResponse:
        """
        Gets resolution data from PlainID API.

        Args:
            entity_id (str): The entity ID to get resolution for
            entity_type_id (str): The entity type ID for the request
            resource_full_paths: Optional resource paths to include in the request.
            include_attributes (bool): Whether to include attributes in the response
            auth_token (str): Optional authorization token
            headers: Optional additional HTTP headers
            additional_identities: Optional list of additional identity contexts.
            **kwargs: Additional fields to include in the request payload

        Returns:
            ResolutionResponse: Parsed resolution response from PlainID

        Raises:
            PlainIDAuthClientException: If there was an error fetching the resolution
        """
        prepared = self._prepare_resolution_request(
            entity_id, entity_type_id, include_attributes,
            resource_full_paths, auth_token, headers,
            additional_identities, kwargs,
        )

        return self._post_and_parse("resolution", prepared, ResolutionResponse)

    async def aget_resolution(
        self,
        entity_id: str,
        entity_type_id: str,
        resource_full_paths: Optional[list[str]] = None,
        include_attributes: bool = True,
        auth_token: str = "",
        headers: Optional[dict[str, str]] = None,
        additional_identities: Optional[list[AdditionalIdentityRequest]] = None,
        **kwargs,
    ) -> ResolutionResponse:
        """Async version of :meth:`get_resolution`."""
        prepared = self._prepare_resolution_request(
            entity_id, entity_type_id, include_attributes,
            resource_full_paths, auth_token, headers,
            additional_identities, kwargs,
        )

        return await self._apost_and_parse("resolution", prepared, ResolutionResponse)

    def get_token(
        self,
        entity_type_id: str,
        entity_id: str,
        include_attributes: bool = True,
        additional_identities: Optional[list[AdditionalIdentityRequest]] = None,
        **kwargs,
    ) -> UserAccessTokenResponse:
        """
        Gets token data from PlainID API.

        Args:
            entity_type_id (str): The entity type ID for the request
            entity_id (str): The entity ID to get token for
            include_attributes (bool): Whether to include attributes in the response
            additional_identities: Optional list of additional identities.
            **kwargs: Additional fields to include in the request payload

        Returns:
            UserAccessTokenResponse: Parsed user access token response

        Raises:
            PlainIDAuthClientException: If there was an error fetching the token
        """
        prepared = self._prepare_token_request(
            entity_id, entity_type_id, include_attributes,
            additional_identities, kwargs,
        )

        return self._post_and_parse("token", prepared, UserAccessTokenResponse)

    async def aget_token(
        self,
        entity_type_id: str,
        entity_id: str,
        include_attributes: bool = True,
        additional_identities: Optional[list[AdditionalIdentityRequest]] = None,
        **kwargs,
    ) -> UserAccessTokenResponse:
        """Async version of :meth:`get_token`."""
        prepared = self._prepare_token_request(
            entity_id, entity_type_id, include_attributes,
            additional_identities, kwargs,
        )
        
        return await self._apost_and_parse("token", prepared, UserAccessTokenResponse)

    def _prepare_resolution_request(
        self,
        entity_id: str,
        entity_type_id: str,
        include_attributes: bool,
        resource_full_paths: Optional[list[str]],
        auth_token: str,
        headers: Optional[dict[str, str]],
        additional_identities: Optional[list[AdditionalIdentityRequest]],
        extra_payload: dict[str, Any],
    ) -> PreparedRequest:
        logger.debug("getting resolution... %s", entity_id)

        request_headers = dict(headers or {})

        request_headers[HttpHeader.CONTENT_TYPE.value] = self.APPLICATION_JSON
        request_headers[PlainIDClientHeader.X_CLIENT_ID.value] = self._client_id
        request_headers[PlainIDClientHeader.X_CLIENT_SECRET.value] = self._client_secret

        self._set_auth_header(request_headers, auth_token)

        capitalized_headers = capitalize_header_names(request_headers)

        request_payload = ResolutionRequest(
            client_id=self._client_id,
            client_secret=self._client_secret,
            entity_id=entity_id,
            entity_type_id=entity_type_id,
            include_attributes=include_attributes,
            environment=(
                ResolutionRequestEnvironment(resource_full_path=resource_full_paths)
                if resource_full_paths
                else None
            ),
            additional_identities=additional_identities,
        )

        payload = request_payload.model_dump(by_alias=True, exclude_none=True)
        payload.update(extra_payload)

        logger.debug("payload: %s", payload)

        return PreparedRequest(
            url=f"{self._base_url}{self.RESOLUTION_ENDPOINT}",
            headers=capitalized_headers,
            payload=payload,
        )

    def _prepare_token_request(
        self,
        entity_id: str,
        entity_type_id: str,
        include_attributes: bool,
        additional_identities: Optional[list[AdditionalIdentityRequest]],
        extra_payload: dict[str, Any],
    ) -> PreparedRequest:
        headers = {
            HttpHeader.CONTENT_TYPE.value: self.APPLICATION_JSON,
        }

        request_payload = TokenRequest(
            client_id=self._client_id,
            client_secret=self._client_secret,
            entity_id=entity_id,
            entity_type_id=entity_type_id,
            include_attributes=include_attributes,
            additional_identities=additional_identities,
        )

        payload = request_payload.model_dump(by_alias=True)
        payload.update(extra_payload)

        logger.debug("payload: %s", payload)

        return PreparedRequest(
            url=f"{self._base_url}{self.TOKEN_ENDPOINT}",
            headers=headers,
            payload=payload,
        )
