import json
import logging
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Any, Iterator, NoReturn, Optional, TypeVar

import httpx
from pydantic import BaseModel, ValidationError

from core_plainid.enums.http_header import HttpHeader
from core_plainid.exceptions.plainid_exceptions import PlainIDException
from core_plainid.utils.validation_utils import validate_not_blank

logger = logging.getLogger(__name__)

ResponseModel = TypeVar("ResponseModel", bound=BaseModel)


@dataclass(frozen=True, slots=True)
class PreparedRequest:
    url: str
    headers: dict[str, str]
    payload: dict


class BasePlainIDClient:
    """Base class for PlainID API clients.

    Provides shared authentication parameters, constants, and a generic
    error-handling wrapper for HTTP operations.
    """

    APPLICATION_JSON = "application/json"

    def __init__(
        self,
        base_url: str,
        client_id: str,
        client_secret: Optional[str] = None,
        exception_class: type[PlainIDException] = PlainIDException,
    ) -> None:
        validate_not_blank(base_url=base_url, client_id=client_id)

        self._base_url = base_url
        self._client_id = client_id
        self._client_secret = client_secret
        self._exception_class = exception_class

    @contextmanager
    def _error_handling(self, operation_name: str) -> Iterator[None]:
        try:
            yield
        except Exception as error:
            self._raise_on_error(operation_name, error)

    def _post(self, request: PreparedRequest) -> Any:
        response = httpx.post(
            request.url, headers=request.headers, json=request.payload,
        )
        response.raise_for_status()
        
        return response.json()

    async def _apost(self, request: PreparedRequest) -> Any:
        async with httpx.AsyncClient() as client:
            response = await client.post(
                request.url, headers=request.headers, json=request.payload,
            )
        response.raise_for_status()
        
        return response.json()

    def _post_and_parse(
        self,
        operation_name: str,
        prepared: PreparedRequest,
        response_model: type[ResponseModel],
    ) -> ResponseModel:
        with self._error_handling(operation_name):
            response_data = self._post(prepared)
            
            logger.debug("response %s: %s", operation_name, response_data)
            
            return response_model.model_validate(response_data)

    async def _apost_and_parse(
        self,
        operation_name: str,
        prepared: PreparedRequest,
        response_model: type[ResponseModel],
    ) -> ResponseModel:
        with self._error_handling(operation_name):
            response_data = await self._apost(prepared)
            
            logger.debug("response %s: %s", operation_name, response_data)
            
            return response_model.model_validate(response_data)

    def _set_auth_header(
        self,
        headers: dict[str, str],
        auth_token: Optional[str],
    ) -> None:
        if auth_token:
            if auth_token.lower().startswith("bearer "):
                headers[HttpHeader.AUTHORIZATION.value] = auth_token
            else:
                headers[HttpHeader.AUTHORIZATION.value] = f"Bearer {auth_token}"

    def _raise_on_error(self, operation_name: str, error: Exception) -> NoReturn:
        if isinstance(error, PlainIDException):
            raise error

        if isinstance(error, httpx.HTTPStatusError):
            logger.error("HTTP error response: %s", error.response.text)
            raise self._exception_class(
                f"{operation_name} failed, status code: {error.response.status_code}, "
                f"response: {error.response.text}",
                error,
            )

        if isinstance(error, (httpx.RequestError, json.JSONDecodeError)):
            logger.error(
                "Error with %s request: %s", operation_name, str(error)
            )
            raise self._exception_class(
                f"Failed to process {operation_name} request: {str(error)}",
                error,
            )

        if isinstance(error, ValidationError):
            logger.error(
                "Error validating %s payload: %s", operation_name, str(error)
            )
            raise self._exception_class(
                f"Failed to validate {operation_name} payload: {str(error)}",
                error,
            )

        logger.error("Unexpected error in %s: %s", operation_name, str(error))
        
        raise self._exception_class(
            f"Unexpected error during {operation_name}",
            error,
        )

