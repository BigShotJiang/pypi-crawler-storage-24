import logging
from typing import Optional

from core_plainid.clients.base_plainid_client import BasePlainIDClient, PreparedRequest
from core_plainid.exceptions.plainid_exceptions import PlainIDSQLAuthorizerClientException
from core_plainid.models.request.sql_authorizer_request import SQLAuthorizerRequest
from core_plainid.models.response.sql_authorizer_response import SQLAuthorizerResponse

logger = logging.getLogger(__name__)


class PlainIDSQLAuthorizerClient(BasePlainIDClient):
    """Client for the PlainID SQL Database Authorizer API.

    Modifies an SQL query based on authorization policies.

    Authentication is performed using either client credentials (client_id +
    client_secret provided at construction time) or a per-request JWT token.
    At least one of client_secret or auth_token must be available when
    calling authorize_sql / aauthorize_sql.

    Limitation:
        The SQL Authorizer does not currently support the runtime interface
        for primary and secondary identities (User + Agent). Only a single
        identity context is supported.
    """

    SQL_AUTHORIZER_ENDPOINT = "/resql"

    def __init__(
        self,
        base_url: str,
        client_id: str,
        client_secret: Optional[str] = None,
    ) -> None:
        super().__init__(
            base_url=base_url,
            client_id=client_id,
            client_secret=client_secret,
            exception_class=PlainIDSQLAuthorizerClientException,
        )

    def authorize_sql(
        self,
        request: SQLAuthorizerRequest,
        auth_token: Optional[str] = None,
    ) -> SQLAuthorizerResponse:
        """Submit a SQL query to the SQL Authorizer and receive the modified query.

        Args:
            request: The SQL authorization request containing the query and
                optional parameters (entity_id, entity_type_id, flags, etc.).
            auth_token: Optional JWT token for authentication. If provided,
                it is sent in the Authorization header. Either this or
                client_secret (from the constructor) must be present.

        Returns:
            SQLAuthorizerResponse with the modified SQL, modification flag,
            and any error message.

        Raises:
            PlainIDSQLAuthorizerClientException: On missing credentials, validation
                errors, HTTP errors, or unexpected failures.
        """
        self._validate_credentials(auth_token)
        
        prepared = self._prepare_authorize_sql_request(request, auth_token)
        
        return self._post_and_parse("SQL authorization", prepared, SQLAuthorizerResponse)

    async def aauthorize_sql(
        self,
        request: SQLAuthorizerRequest,
        auth_token: Optional[str] = None,
    ) -> SQLAuthorizerResponse:
        """Async version of :meth:`authorize_sql`."""
        self._validate_credentials(auth_token)
        
        prepared = self._prepare_authorize_sql_request(request, auth_token)
        
        return await self._apost_and_parse("SQL authorization", prepared, SQLAuthorizerResponse)

    def _validate_credentials(self, auth_token: Optional[str]) -> None:
        if self._client_secret is None and auth_token is None:
            raise PlainIDSQLAuthorizerClientException(
                "Authentication required: provide either client_secret "
                "(at construction) or auth_token (per request)"
            )

    def _prepare_authorize_sql_request(
        self,
        request: SQLAuthorizerRequest,
        auth_token: Optional[str],
    ) -> PreparedRequest:
        payload = request.model_dump(by_alias=True, exclude_none=True)
        payload["clientID"] = self._client_id

        if self._client_secret is not None:
            payload["clientSecret"] = self._client_secret

        headers = {
            "Content-Type": self.APPLICATION_JSON,
        }

        self._set_auth_header(headers, auth_token)

        logger.debug("SQL Authorizer request payload: %s", payload)

        return PreparedRequest(
            url=f"{self._base_url}{self.SQL_AUTHORIZER_ENDPOINT}",
            headers=headers,
            payload=payload,
        )
