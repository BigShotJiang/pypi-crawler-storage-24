from enum import Enum


class PlainIDClientHeader(str, Enum):
    X_CLIENT_ID = "x-client-id"
    X_CLIENT_SECRET = "x-client-secret"
