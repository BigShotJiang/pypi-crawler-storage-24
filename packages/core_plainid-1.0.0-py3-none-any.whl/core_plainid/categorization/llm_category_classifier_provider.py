from typing import Any, Optional

from core_plainid.categorization.category_classifier_provider import CategoryClassifierProvider
from core_plainid.models.categorization.category_classification_structured_output import (
    CategoryClassificationStructuredOutput,
)
from core_plainid.utils.litellm_utils import astructured_completion, structured_completion
from core_plainid.utils.validation_utils import validate_not_blank
from core_plainid.utils.prompt_utils import render_prompt_template


CLASSIFICATION_PROMPT = """
You are a text classifier.
Classify the user query into zero or more categories from the list below.
If none match, return an empty categories list.

Available categories:
{categories}
"""


class LLMCategoryClassifierProvider(CategoryClassifierProvider):
    """Category classifier that uses an LLM via LiteLLM.

    Sends the user query and available categories to the configured LLM
    model and parses the structured response into a list of categories.
    """

    def __init__(
        self,
        model: str,
        prompt_template: Optional[str] = None,
        **completion_kwargs: Any,
    ):
        super().__init__()

        validate_not_blank(model=model)

        self._model = model
        self._prompt_template = prompt_template or CLASSIFICATION_PROMPT
        self._completion_kwargs = completion_kwargs

    def classify(
        self,
        query: str,
        all_categories: list[str],
    ) -> list[str]:
        with self._error_handling("LLM category classification"):
            system_prompt = self._build_system_prompt(all_categories)

            response = structured_completion(
                model=self._model,
                system_prompt=system_prompt,
                user_query=query,
                response_model=CategoryClassificationStructuredOutput,
                **self._completion_kwargs,
            )

            return response.categories

    async def aclassify(
        self,
        query: str,
        all_categories: list[str],
    ) -> list[str]:
        with self._error_handling("LLM category classification"):
            system_prompt = self._build_system_prompt(all_categories)

            response = await astructured_completion(
                model=self._model,
                system_prompt=system_prompt,
                user_query=query,
                response_model=CategoryClassificationStructuredOutput,
                **self._completion_kwargs,
            )

            return response.categories

    def _build_system_prompt(self, all_categories: list[str]) -> str:
        return render_prompt_template(
            self._prompt_template,
            values={"categories": all_categories},
        )
