import logging
from abc import ABC, abstractmethod
from contextlib import contextmanager
from typing import Iterator

from core_plainid.exceptions.plainid_exceptions import PlainIDCategorizerException

logger = logging.getLogger(__name__)


class CategoryClassifierProvider(ABC):
    """Abstract base for text classification providers.

    Implementations classify user input into zero or more categories
    from a provided list.
    """

    @abstractmethod
    def classify(self, query: str, all_categories: list[str]) -> list[str]:
        """
        Classifies the input text and returns the categories.

        Args:
            query (str): The input text to be classified
            all_categories (list[str]): List of categories to classify input into

        Returns:
            list[str]: The classified categories (possibly empty)
        """
        pass

    @abstractmethod
    async def aclassify(self, query: str, all_categories: list[str]) -> list[str]:
        """Async version of :meth:`classify`."""
        pass

    @contextmanager
    def _error_handling(self, operation_name: str) -> Iterator[None]:
        try:
            yield
        except PlainIDCategorizerException:
            raise
        except Exception as e:
            logger.error("%s failed: %s", operation_name, str(e))

            raise PlainIDCategorizerException(
                f"{operation_name} failed", original_exception=e
            )
