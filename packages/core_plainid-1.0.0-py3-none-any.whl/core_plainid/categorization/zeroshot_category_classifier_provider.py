import asyncio

from transformers import pipeline

from core_plainid.categorization.category_classifier_provider import CategoryClassifierProvider
from core_plainid.exceptions.plainid_exceptions import PlainIDCategorizerException
from core_plainid.utils.validation_utils import validate_not_blank


class ZeroShotCategoryClassifierProvider(CategoryClassifierProvider):
    """
    A zero-shot category classifier provider implementation.
    Uses Hugging Face transformers pipeline for classification.
    """

    def __init__(self, model_name: str, threshold: float = 0.5):
        validate_not_blank(model_name=model_name)
        
        if not 0.0 <= threshold <= 1.0:
            raise ValueError("threshold must be between 0.0 and 1.0")

        self._model_name = model_name
        self._zeroshot_classifier = pipeline(
            "zero-shot-classification", model=model_name
        )
        self._threshold = threshold

    def classify(
        self,
        query: str,
        all_categories: list[str],
    ) -> list[str]:
        with self._error_handling("Zero-shot category classification"):
            return self._classify_with_pipeline(query, all_categories)

    async def aclassify(
        self,
        query: str,
        all_categories: list[str],
    ) -> list[str]:
        with self._error_handling("Zero-shot category classification"):
            return await asyncio.to_thread(
                self._classify_with_pipeline, query, all_categories
            )

    def _classify_with_pipeline(
        self, query: str, all_categories: list[str]
    ) -> list[str]:
        categories_map = {
            category.lower(): category for category in all_categories
        }
        all_categories_lower = [category.lower() for category in all_categories]

        result = self._zeroshot_classifier(
            query,
            all_categories_lower,
            multi_label=True,
        )

        labels = result.get("labels", [])
        scores = result.get("scores", [])

        if len(labels) != len(scores):
            raise PlainIDCategorizerException(
                "Zero-shot classifier returned mismatched labels/scores"
            )

        return [
            categories_map[label]
            for label, score in zip(labels, scores)
            if score >= self._threshold and label in categories_map
        ]
