import logging
from typing import Optional

from core_plainid.categorization.base_categorizer import BaseCategorizer
from core_plainid.exceptions.plainid_exceptions import PlainIDCategorizerException
from core_plainid.models.context.request_context import RequestContext
from core_plainid.models.permissions.plainid_permissions import PlainIDPermissions

logger = logging.getLogger(__name__)


class Categorizer(BaseCategorizer):
    """Default categorizer implementation.

    Classifies user prompts using the configured classifier provider, then
    verifies the result against PlainID-allowed categories.
    """

    def categorize(
        self,
        query: str,
        request_context: Optional[RequestContext] = None,
    ) -> str:
        """Classify the prompt using the configured classifier provider and
        verify that the classified categories are in the PlainID-allowed set.

        Returns the original query if the classified categories are permitted.
        """
        with self._error_handling():
            permissions = self._permissions_provider.get_permissions(request_context)

            categories = self._classifier_provider.classify(
                query=query,
                all_categories=self._all_categories,
            )

            return self._verify_categories(query, categories, permissions)

    async def acategorize(
        self,
        query: str,
        request_context: Optional[RequestContext] = None,
    ) -> str:
        """Async version of :meth:`categorize`."""
        with self._error_handling():
            permissions = await self._permissions_provider.aget_permissions(request_context)

            categories = await self._classifier_provider.aclassify(
                query=query,
                all_categories=self._all_categories,
            )

            return self._verify_categories(query, categories, permissions)

    def _verify_categories(
        self,
        query: str,
        classified_categories: list[str],
        permissions: PlainIDPermissions,
    ) -> str:
        logger.debug("Categorizer result: %s", classified_categories)

        if not classified_categories:
            raise PlainIDCategorizerException(
                "No categories were classified for the query"
            )

        classified = {c.lower() for c in classified_categories}
        allowed = {c.lower() for c in permissions.categories}

        if classified.issubset(allowed):
            logger.debug("Classified '%s' as '%s'", query, classified_categories)

            return query

        raise PlainIDCategorizerException(
            f"Classified categories '{classified_categories}' are not all in "
            f"allowed categories: {permissions.categories}"
        )
