import logging
from abc import ABC, abstractmethod
from contextlib import contextmanager
from typing import Iterator, Optional

from core_plainid.categorization.category_classifier_provider import CategoryClassifierProvider
from core_plainid.exceptions.plainid_exceptions import PlainIDCategorizerException
from core_plainid.models.context.request_context import RequestContext
from core_plainid.utils.plainid_permissions_provider import PlainIDPermissionsProvider

logger = logging.getLogger(__name__)


class BaseCategorizer(ABC):
    """Abstract base for prompt categorizers that classify user input
    and verify the result against PlainID-allowed categories."""

    def __init__(
        self,
        classifier_provider: CategoryClassifierProvider,
        permissions_provider: PlainIDPermissionsProvider,
        all_categories: Optional[list[str]] = None,
    ):
        """
        Args:
            classifier_provider: Provider that performs the actual text
                classification.
            permissions_provider: Provider that retrieves category-level
                permissions from PlainID.
            all_categories: Full list of possible categories for classification.

        Raises:
            PlainIDCategorizerException: If all_categories is empty.
        """
        if not all_categories:
            raise PlainIDCategorizerException("Categories list cannot be empty")
        
        self._classifier_provider = classifier_provider
        self._permissions_provider = permissions_provider
        self._all_categories = all_categories

    @abstractmethod
    def categorize(
        self,
        query: str,
        request_context: Optional[RequestContext] = None,
    ) -> str:
        """Categorize the prompt and enforce PlainID category permissions.

        Args:
            query: The user prompt to categorize.
            request_context: Identity context for the PlainID resolution.
                Falls back to the context provided at construction time.

        Returns:
            A string (e.g. the original query).
        """

    @abstractmethod
    async def acategorize(
        self,
        query: str,
        request_context: Optional[RequestContext] = None,
    ) -> str:
        """Async version of :meth:`categorize`."""

    @contextmanager
    def _error_handling(self) -> Iterator[None]:
        try:
            yield
        except PlainIDCategorizerException as e:
            logger.error("Categorization error: %s", e)
            
            raise
        except Exception as e:
            logger.error("Error during categorization: %s", e)
            
            raise PlainIDCategorizerException("Error during categorization", e)
