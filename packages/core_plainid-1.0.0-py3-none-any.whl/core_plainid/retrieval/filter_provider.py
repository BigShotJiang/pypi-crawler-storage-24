import logging
from abc import ABC, abstractmethod
from contextlib import contextmanager
from typing import Any, Generic, Iterator, Optional, TypeVar

from core_plainid.clients.plainid_auth_client import PlainIDAuthClient
from core_plainid.exceptions.plainid_exceptions import PlainIDFilterException, PlainIDRetrieverException
from core_plainid.models.context.request_context import RequestContext
from core_plainid.models.response.resolution_response import ResolutionAction, ResolutionResponse

logger = logging.getLogger(__name__)

FilterType = TypeVar("FilterType")


class FilterProvider(ABC, Generic[FilterType]):
    """Abstract base for providers that translate PlainID resolution data
    into authorization filters."""

    LOGICAL_AND = "AND"
    LOGICAL_OR = "OR"

    CONDITION_KEY_ATTRIBUTE = "attribute"
    CONDITION_KEY_OPERATOR = "operator"
    CONDITION_KEY_VALUES = "values"
    CONDITION_KEY_TYPE = "type"
    CONDITION_TYPE_NUMERIC = "NUMERIC"
    CONDITION_TYPE_INTEGER = "INTEGER"
    NUMERIC_CONDITION_TYPES = {CONDITION_TYPE_NUMERIC, CONDITION_TYPE_INTEGER}

    OPERATOR_EQUALS = "EQUALS"
    OPERATOR_NOTEQUALS = "NOTEQUALS"
    OPERATOR_GREATE = "GREATE"
    OPERATOR_LESS = "LESS"
    OPERATOR_GREAT_EQUALS = "GREAT_EQUALS"
    OPERATOR_LESS_EQUALS = "LESS_EQUALS"
    OPERATOR_IN = "IN"
    OPERATOR_NOT_IN = "NOT_IN"
    OPERATOR_CONTAINS = "CONTAINS"
    OPERATOR_STARTWITH = "STARTWITH"
    OPERATOR_ENDWITH = "ENDWITH"

    UNRESTRICTED_FILTER: dict[str, Any] = {
        "OR": [
            {
                "OR": [
                    {
                        "AND": [
                            {
                                "attribute": "1",
                                "type": "INTEGER",
                                "operator": "EQUALS",
                                "values": ["1"],
                                "match": "any",
                            }
                        ]
                    }
                ]
            }
        ]
    }

    def __init__(
        self,
        base_url: str,
        client_id: str,
        client_secret: str,
        resource_types: Optional[list[str]] = None,
        request_context: Optional[RequestContext] = None,
        **kwargs: Any,
    ):
        """
        Initialize with PlainID client credentials and optional defaults.

        Args:
            base_url: Base URL for PlainID service.
            client_id: Client ID for authentication.
            client_secret: Client secret for authentication.
            resource_types: Optional list of resource types to use by default
                for resolution calls.
            request_context: Optional default request context containing
                entity_id, entity_id_type, auth_token, headers, and
                additional_identities.
            **kwargs: Additional fields forwarded to the resolution request.
        """
        self._client = PlainIDAuthClient(base_url, client_id, client_secret)
        self._resource_types = resource_types
        self._initial_request_context = request_context
        self._kwargs = kwargs

    def get_filter(
        self,
        request_context: Optional[RequestContext] = None,
        resource_types: Optional[list[str]] = None,
    ) -> dict[str, Optional[FilterType]]:
        """
        Returns a dict mapping each resource type to a filter built from PlainID
        resolution data.

        Falls back to the request context and resource types provided at
        construction time if none are passed directly.

        Resource types not found in the resolution response are excluded from
        the returned dict (meaning access is denied for that resource type).
        A ``None`` value means the resource is allowed with unrestricted access
        (no filter needed).

        Args:
            request_context: Context containing entity_id, entity_id_type,
                auth_token, headers, and additional_identities.
            resource_types: List of resource types to filter resolution rules by.

        Returns:
            dict[str, Optional[FilterType]]: Mapping of resource type to filter,
                None for unrestricted access, or absent for denied resources.

        Raises:
            PlainIDRetrieverException: If no request context or resource types are available.
            PlainIDFilterException: If there was an error processing the filter.
        """
        effective_context, effective_resource_types = self._resolve_filter_inputs(
            request_context, resource_types
        )

        with self._error_handling():
            resolution = self._client.get_resolution(
                entity_id=effective_context.entity_id,
                entity_type_id=effective_context.entity_id_type,
                resource_full_paths=effective_resource_types,
                auth_token=effective_context.auth_token,
                headers=effective_context.headers,
                additional_identities=effective_context.get_additional_identities_request(),
                **self._kwargs,
            )

            return self._build_filter_result(resolution, effective_resource_types)

    async def aget_filter(
        self,
        request_context: Optional[RequestContext] = None,
        resource_types: Optional[list[str]] = None,
    ) -> dict[str, Optional[FilterType]]:
        """Async version of :meth:`get_filter`."""
        effective_context, effective_resource_types = self._resolve_filter_inputs(
            request_context, resource_types
        )

        with self._error_handling():
            resolution = await self._client.aget_resolution(
                entity_id=effective_context.entity_id,
                entity_type_id=effective_context.entity_id_type,
                resource_full_paths=effective_resource_types,
                auth_token=effective_context.auth_token,
                headers=effective_context.headers,
                additional_identities=effective_context.get_additional_identities_request(),
                **self._kwargs,
            )

            return self._build_filter_result(resolution, effective_resource_types)

    def _resolve_filter_inputs(
        self,
        request_context: Optional[RequestContext],
        resource_types: Optional[list[str]],
    ) -> tuple[RequestContext, list[str]]:
        effective_context = request_context or self._initial_request_context

        if effective_context is None:
            raise PlainIDRetrieverException(
                "request_context is required either at construction time or when calling get_filter"
            )

        effective_resource_types = resource_types or self._resource_types

        if not effective_resource_types:
            raise PlainIDRetrieverException(
                "resource_types is required either at construction time or when calling get_filter"
            )

        return effective_context, effective_resource_types

    def _build_filter_result(
        self,
        resolution: ResolutionResponse,
        resource_types: list[str],
    ) -> dict[str, Optional[FilterType]]:
        filters = self._map_resolution_to_filters(resolution, resource_types)

        for resource_type, filter_value in filters.items():
            if filter_value is not None:
                logger.debug("Filter for %s: %s", resource_type, filter_value)

        return filters

    @contextmanager
    def _error_handling(self) -> Iterator[None]:
        try:
            yield
        except PlainIDFilterException as e:
            logger.error("Filter error: %s", e)
            
            raise
        except Exception as e:
            logger.error("Error retrieving filter: %s", e)
            
            raise PlainIDFilterException("Error retrieving filter", e)

    def _map_resolution_to_filters(
        self,
        resolution: ResolutionResponse,
        resource_types: list[str],
    ) -> dict[str, Optional[FilterType]]:
        requested_resource_types = set(resource_types)
        actions_by_resource: dict[str, list[ResolutionAction]] = {}

        for response_item in resolution.response:
            for allowed_rule in response_item.privileges.allowed:
                if allowed_rule.resource_type not in requested_resource_types:
                    continue

                actions_by_resource.setdefault(allowed_rule.resource_type, []).extend(
                    allowed_rule.actions
                )

        result: dict[str, Optional[FilterType]] = {}

        for resource_type, actions in actions_by_resource.items():
            result[resource_type] = self._build_filter_for_resource(actions)

        return result

    def _build_filter_for_resource(self, actions: list[ResolutionAction]) -> Optional[FilterType]:
        for action in actions:
            if action.asset_attributes_filter == self.UNRESTRICTED_FILTER:
                return None

        all_filters: list[FilterType] = []

        for action in actions:
            if action.asset_attributes_filter:
                result = self._convert_filter(action.asset_attributes_filter)

                if result:
                    all_filters.append(result)

        if not all_filters:
            return None

        if len(all_filters) == 1:
            return all_filters[0]

        return self._combine_or(all_filters)

    def _convert_filter(self, filter_part: dict[str, Any]) -> Optional[FilterType]:
        if self.LOGICAL_AND in filter_part:
            and_conditions = filter_part[self.LOGICAL_AND]
            converted = [self._convert_condition(c) for c in and_conditions if c]
            converted = [c for c in converted if c]

            if not converted:
                return None

            return self._combine_and(converted)
        elif self.LOGICAL_OR in filter_part:
            or_conditions = filter_part[self.LOGICAL_OR]
            converted: list[FilterType] = []

            for cond in or_conditions:
                if self.LOGICAL_AND in cond or self.LOGICAL_OR in cond:
                    result = self._convert_filter(cond)
                else:
                    result = self._convert_condition(cond)

                if result:
                    converted.append(result)

            if not converted:
                return None

            return self._combine_or(converted)

        return None

    @abstractmethod
    def _convert_condition(self, condition: dict[str, Any]) -> Optional[FilterType]:
        pass

    @abstractmethod
    def _combine_and(self, filters: list[FilterType]) -> FilterType:
        pass

    @abstractmethod
    def _combine_or(self, filters: list[FilterType]) -> FilterType:
        pass
