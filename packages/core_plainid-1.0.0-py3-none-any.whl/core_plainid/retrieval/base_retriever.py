from abc import ABC, abstractmethod
from typing import Generic, Optional, TypeVar

from core_plainid.models.context.request_context import RequestContext
from core_plainid.retrieval.filter_provider import FilterProvider

VST = TypeVar("VST")
DOC = TypeVar("DOC")


class BaseRetriever(ABC, Generic[VST, DOC]):
    """Abstract base for document retrievers that enforce PlainID
    authorization policies."""

    def __init__(
        self,
        filter_provider: FilterProvider,
        resource_types: list[str],
        vector_stores: list[VST],
        k: int = 4,
        k_values: Optional[list[int]] = None,
    ):
        pass

    @abstractmethod
    def retrieve(
        self,
        query: str,
        request_context: Optional[RequestContext] = None,
    ) -> list[DOC]:
        """Retrieve documents according to PlainID authorization policies.

        Args:
            query: The search query.
            request_context: Identity context for the PlainID resolution.
                Falls back to the context provided at construction time.

        Returns:
            List of retrieved documents.
        """

    @abstractmethod
    async def aretrieve(
        self,
        query: str,
        request_context: Optional[RequestContext] = None,
    ) -> list[DOC]:
        """Async version of :meth:`retrieve`."""