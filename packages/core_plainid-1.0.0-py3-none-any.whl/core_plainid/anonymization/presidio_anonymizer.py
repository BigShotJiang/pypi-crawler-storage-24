import logging
from typing import Optional

from presidio_analyzer import AnalyzerEngine, PatternRecognizer
from presidio_analyzer.pattern import Pattern
from presidio_anonymizer import AnonymizerEngine, OperatorConfig

from core_plainid.anonymization.base_anonymizer import BaseAnonymizer
from core_plainid.exceptions.plainid_exceptions import PlainIDAnonymizerException
from core_plainid.models.context.request_context import RequestContext
from core_plainid.models.permissions.plainid_entity_action import PlainIDEntityAction
from core_plainid.models.permissions.plainid_permissions import PlainIDPermissions
from core_plainid.utils.plainid_permissions_provider import PlainIDPermissionsProvider

logger = logging.getLogger(__name__)

class PresidioAnonymizer(BaseAnonymizer):
    """Anonymizer implementation backed by Microsoft Presidio.

    Detects PII entities using Presidio Analyzer and applies MASK or ENCRYPT
    actions as configured in PlainID. Supports built-in Presidio entities,
    custom regex entities, and Azure Health De-identification (AHDS) entities.
    """

    MASK_ACTION = "MASK"
    ENCRYPT_ACTION = "ENCRYPT"

    def __init__(
        self,
        permissions_provider: PlainIDPermissionsProvider,
        encrypt_key: Optional[str] = None,
        enable_ahds: bool = False,
    ) -> None:
        super().__init__(permissions_provider, encrypt_key)

        self._ahds_recognizer = None

        if enable_ahds:
            self._ahds_recognizer = self._create_ahds_recognizer()

    def anonymize(
        self,
        query: str,
        request_context: Optional[RequestContext] = None,
    ) -> str:
        with self._error_handling():
            permissions = self._permissions_provider.get_permissions(request_context)

            return self._anonymize_with_permissions(query, permissions)

    async def aanonymize(
        self,
        query: str,
        request_context: Optional[RequestContext] = None,
    ) -> str:
        with self._error_handling():
            permissions = await self._permissions_provider.aget_permissions(request_context)

            return self._anonymize_with_permissions(query, permissions)

    def _anonymize_with_permissions(
        self, query: str, permissions: PlainIDPermissions
    ) -> str:
        mask_entities, encode_entities, regex_entities = (
            self._classify_entities(permissions.entities)
        )

        if not mask_entities and not encode_entities:
            return query

        analyzer = AnalyzerEngine()

        self._register_regex_recognizers(analyzer, regex_entities)

        if self._ahds_recognizer is not None:
            analyzer.registry.add_recognizer(self._ahds_recognizer)

        try:
            analyzer_results = analyzer.analyze(
                text=query, entities=mask_entities + encode_entities, language="en"
            )

            if not analyzer_results:
                return query
        except Exception as e:
            logger.error("Failed to analyze text for anonymization: %s", e)
            
            raise PlainIDAnonymizerException(
                "Failed to analyze text for anonymization", e
            )

        operators = {"DEFAULT": OperatorConfig("replace", {"new_value": "***"})}

        if self._encrypt_key is not None:
            for entity in encode_entities:
                if entity not in mask_entities:
                    operators[entity] = OperatorConfig(
                        "encrypt", {"key": self._encrypt_key}
                    )

        for entity in mask_entities:
            operators[entity] = OperatorConfig("replace", {"new_value": "***"})

        try:
            anonymizer = AnonymizerEngine()

            anonymized_result = anonymizer.anonymize(
                text=query, analyzer_results=analyzer_results, operators=operators
            )
        except Exception as e:
            logger.error("Failed to anonymize text: %s", e)
            
            raise PlainIDAnonymizerException("Failed to anonymize text", e)

        logger.debug("anonymized input to %s", anonymized_result.text)

        return anonymized_result.text

    def _classify_entities(
        self, entities: list[PlainIDEntityAction]
    ) -> tuple[list[str], list[str], list[PlainIDEntityAction]]:
        mask_entities: list[str] = []
        encrypt_entities: list[str] = []
        regex_entities: list[PlainIDEntityAction] = []

        for entity in entities:
            if entity.regex_pattern is not None:
                regex_entities.append(entity)

            if self.MASK_ACTION in entity.actions:
                mask_entities.append(entity.name)

            if self.ENCRYPT_ACTION in entity.actions:
                encrypt_entities.append(entity.name)

        return mask_entities, encrypt_entities, regex_entities

    def _register_regex_recognizers(
        self, analyzer: AnalyzerEngine, regex_entities: list[PlainIDEntityAction]
    ) -> None:
        for entity in regex_entities:
            pattern = Pattern(name=entity.name, regex=entity.regex_pattern, score=1.0)

            recognizer = PatternRecognizer(
                supported_entity=entity.name, patterns=[pattern]
            )

            analyzer.registry.add_recognizer(recognizer)

    def _create_ahds_recognizer(self):
        import os

        from azure.health.deidentification import DeidentificationClient
        from azure.identity import DefaultAzureCredential
        from presidio_analyzer.predefined_recognizers import AzureHealthDeidRecognizer

        from core_plainid.utils.validation_utils import validate_env_vars

        validate_env_vars(
            "AHDS_ENDPOINT", "AZURE_TENANT_ID", "AZURE_CLIENT_ID", "AZURE_CLIENT_SECRET"
        )

        credential = DefaultAzureCredential()
        client = DeidentificationClient(os.environ["AHDS_ENDPOINT"], credential)

        return AzureHealthDeidRecognizer(client=client)

