import logging
from abc import ABC, abstractmethod
from contextlib import contextmanager
from typing import Iterator, Optional

from core_plainid.exceptions.plainid_exceptions import PlainIDAnonymizerException
from core_plainid.models.context.request_context import RequestContext
from core_plainid.utils.plainid_permissions_provider import PlainIDPermissionsProvider

logger = logging.getLogger(__name__)


class BaseAnonymizer(ABC):
    """Abstract base for text anonymizers that apply PlainID
    entity-level permissions to transform sensitive content."""

    def __init__(
        self,
        permissions_provider: PlainIDPermissionsProvider,
        encrypt_key: Optional[str] = None,
    ) -> None:
        """
        Args:
            permissions_provider: Provider that retrieves entity-level
                permissions from PlainID.
            encrypt_key: Optional encryption key passed to the underlying
                anonymization engine when encryption is used.
        """
        self._permissions_provider = permissions_provider
        self._encrypt_key = encrypt_key

    @abstractmethod
    def anonymize(
        self,
        query: str,
        request_context: Optional[RequestContext] = None,
    ) -> str:
        """Anonymize sensitive content in the given text based on PlainID permissions.

        Args:
            query: The text to anonymize.
            request_context: Identity context for the PlainID resolution.
                Falls back to the context provided at construction time.

        Returns:
            The processed text.
        """

    @abstractmethod
    async def aanonymize(
        self,
        query: str,
        request_context: Optional[RequestContext] = None,
    ) -> str:
        """Async version of :meth:`anonymize`."""

    @contextmanager
    def _error_handling(self) -> Iterator[None]:
        try:
            yield
        except PlainIDAnonymizerException as e:
            logger.error("Anonymization error: %s", e)
            
            raise
        except Exception as e:
            logger.error("Error during anonymization: %s", e)
            
            raise PlainIDAnonymizerException("Error during anonymization", e)