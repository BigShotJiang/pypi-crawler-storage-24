---
layout: default
title: CLI Reference
nav_order: 3
---

# CLI Reference

## `rimpack`

Running `rimpack` with no subcommand checks for the user-local config file and offers to create
it when missing.

## `rimpack init [DIRECTORY]`

Creates a new modpack project. If `DIRECTORY` is omitted, the current working directory is used.

Creates:

- `pack.toml`
- a project `README.md`
- default `.list` files in `mods/`
- `config/Mod_Configs/`
- `generated/`
- `local/mods/`

## `rimpack load-mods [ROOT]`

Loads RimWorld mod metadata from:

- a specific mod directory
- a directory containing many mod folders
- or, when `ROOT` is omitted, the current pack's local mods plus configured or detected
  RimWorld `Mods`, RimWorld `Data`, and Steam Workshop roots

Use it to inspect a single mod or sanity-check parser behavior across a mod root.

## `rimpack add <TARGET> <REFERENCE>`

Resolves a mod reference and appends it to a declared `.list` file in the current modpack.

`TARGET` may be:

- a pack-relative list path such as `mods/20_ui.list`
- an alias such as `@libraries`

`REFERENCE` may be:

- `steam:<id>`
- a Steam Workshop `sharedfiles` URL
- `packageid:<id>`
- `local:<name>`

Options:

- `--cleanup / --no-cleanup`: unsubscribe after temporary resolution when applicable

If the target list does not exist yet, `rimpack add` creates it and adds it to
`layout.mod_files`.

## `rimpack add-ordering-rule <before|after> <MOD> <TARGET>`

Appends an ordering rule in the current modpack.

Arguments use the same reference syntax as `.list` files:

- `steam:<id>`
- `packageid:<id>`
- `local:<name>`

Options:

- `--reason <text>`: add a human-readable explanation
- `--file <path-or-alias>`: choose or create the ordering rule file to append to

If no ordering rule file has been declared yet, the default target is
`rules/ordering/90_manual.toml`.

## `rimpack validate`

Validates the current modpack and prints a summary plus diagnostics.

The current validation scope includes:

- unresolved entries
- missing dependencies
- incompatible active mods
- activation-rule issues
- load-order cycles

Validation exits non-zero when any diagnostic has error severity.

## `rimpack launch`

Builds a launchable modpack runtime and starts RimWorld.

Current launch behavior:

1. loads the current modpack
2. resolves active entries
3. subscribes declared Workshop mods
4. generates final load order
5. builds a symlinked runtime tree
6. launches RimWorld against a pack-specific machine-local config root

Options:

- `--clean / --no-clean`: control cleanup after RimWorld exits

## `rimpack subscribe <WORKSHOP_ID_OR_URL>`

Subscribes to a Workshop item by numeric ID or `sharedfiles` URL.

## `rimpack unsubscribe <WORKSHOP_ID_OR_URL>`

Unsubscribes from a Workshop item by numeric ID or `sharedfiles` URL.

## `rimpack resolve steam <WORKSHOP_ID_OR_URL>`

Resolves a Workshop item and prints the discovered mod metadata.

Options:

- `--cleanup / --no-cleanup`: control temporary subscription cleanup

## Notes

- There is currently no dedicated CLI command for authoring activation rules.
- Activation rule files are still part of the supported pack format and are consumed by validation
  and launch behavior.
