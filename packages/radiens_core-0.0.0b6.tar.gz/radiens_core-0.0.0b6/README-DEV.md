# Developer Guide

## Setup

### Prerequisites

- Python 3.12+
- [uv](https://docs.astral.sh/uv/)

### Install

**Note:** This project requires Python 3.12 or higher.

```bash
uv sync
```

This creates the venv, installs all deps (including dev), and generates `uv.lock`.

### Editor (VS Code)

**Required extensions:**

- [Pylance](https://marketplace.visualstudio.com/items?itemName=ms-python.vscode-pylance) (type checking)
- [Ruff](https://marketplace.visualstudio.com/items?itemName=charliermarsh.ruff) (linting + formatting)

**Recommended extensions:**

- [Mypy Type Checker](https://marketplace.visualstudio.com/items?itemName=ms-python.mypy-type-checker) (real-time type checking)
- [markdownlint](https://marketplace.visualstudio.com/items?itemName=DavidAnson.vscode-markdownlint) (markdown formatting)

**Recommended settings** (`.vscode/settings.json`):

```json
{
  "evenBetterToml.schema.enabled": false, // doesn't work with ruff > 0.1.x apparently
  "ruff.configurationPreference": "filesystemFirst",
  "python.defaultInterpreterPath": ".venv/bin/python",
  "python.analysis.typeCheckingMode": "off",
  "python.analysis.useLibraryCodeForTypes": true,
  "python.analysis.extraPaths": ["src"],
  "[python]": {
    "editor.defaultFormatter": "charliermarsh.ruff",
    "editor.codeActionsOnSave": {
      "source.fixAll.ruff": "explicit",
    },
  },
  "[markdown]": {
    "editor.defaultFormatter": "DavidAnson.vscode-markdownlint",
    "editor.formatOnSave": true,
    "editor.formatOnSaveMode": "file",
  },
  "mypy-type-checker.interpreter": [".venv/bin/python"],
  "mypy-type-checker.args": ["--strict"],
  "mypy-type-checker.path": [".venv/bin/mypy"],
  "mypy-type-checker.severity": {
    "error": "Error",
    "note": "Information"
  }
}
```

## Pre-Commit Checklist

Run all three before every commit:

```bash
uv run mypy --strict src/ tests/  # Type check (the key gate)
uv run ruff check src/ tests/    # Lint
uv run pytest tests/unit/ -v     # Tests
```

`ruff check --fix` will auto-fix import sorting and other safe issues.

## Architecture

```text
src/radiens_core/
  __init__.py                 # Public API surface
  specs.py                    # TimeRangeSpec, SignalSpec (user-facing)
  exceptions.py               # Exception hierarchy
  models/                     # Pydantic v2, ZERO proto dependency
  _transport/                 # gRPC channel pool, auth, error mapping
  _converters/                # Proto <-> domain (ONLY place importing both)
  _services/                  # RPC wrappers (domain in, domain out)
  allego_client.py            # Real-time client
  videre_client.py            # Offline file client
  curate_client.py            # Curation client
  _generated/                 # Committed proto stubs (DO NOT EDIT)
```

### Layer Rules

| Layer | Can import from |
| --- | --- |
| `models/` | stdlib, pydantic, numpy |
| `_converters/` | `models/`, `_generated/` |
| `_services/` | `_converters/`, `_generated/`, `_transport/`, `models/` |
| Client classes | `_services/`, `_transport/`, `models/`, `specs` |

**Only `_converters/` and `_services/` may import from `_generated/`.** Nothing user-facing touches proto types.

### Proto-Driven Type Safety

This is the core design principle. When a proto definition changes and stubs are regenerated, `mypy --strict` will flag every location in `_converters/` that references a renamed/removed field. Fixing the converter then cascades type errors into `models/`, `_services/`, and up. The type system is the change-detection mechanism.

**The chain:** Proto `.pyi` stubs -> `_converters/` -> `models/` -> `_services/` -> clients

### Updating Protos

Proto generation is owned by the radix repo. When protos change:

1. Run the radix proto generation script (produces `_pb2.py` + `.pyi` stubs via `mypy-protobuf`)
2. Copy updated files into `src/radiens_core/_generated/`
3. Run `uv run mypy --strict src/` -- it will show you exactly what broke
4. Fix converters first, then follow the type errors outward
5. Commit the updated `_generated/` alongside your fixes

### Notable Conventions

- **`from __future__ import annotations`** is used everywhere. This makes all annotations strings at runtime, which enables `TYPE_CHECKING` imports.
- **Pydantic models** use `# type: ignore[explicit-any]` on the `class X(BaseModel):` line. This is required because Pydantic's `BaseModel` internally uses `Any`, which conflicts with `disallow_any_explicit = true`. The ignore is surgical and intentional.
- **Frozen models:** All Pydantic domain models use `model_config = ConfigDict(frozen=True)`. Data is immutable once created.
- **`_generated/`** is excluded from ruff and mypy error checking (but mypy still reads the `.pyi` stubs for type info).

## Publishing to PyPI

Publishing to PyPI is fully automated via GitHub Actions using Trusted Publishing (OIDC). You do not need local PyPI credentials or manual build steps.

### Local Safety Hook (Highly Recommended)

To prevent accidentally pushing a Git tag that doesn't match the version in `pyproject.toml`, install the provided pre-push Git hook:

```bash
chmod +x scripts/pre-push.sh
ln -sf ../../scripts/pre-push.sh .git/hooks/pre-push
```

### Release Workflow

1. **Update version** in `pyproject.toml`:

   ```toml
   version = "x.x.x"  # or whatever the new version should be
   ```

2. **Run pre-commit checks** to ensure everything is stable:

   ```bash
   uv run mypy --strict src/ tests/
   uv run ruff check src/ tests/
   uv run pytest tests/unit/ -v
   ```

3. **Commit the version bump**:

   ```bash
   git add pyproject.toml
   git commit -m "chore: bump version to x.x.x"
   ```

4. **Tag and Push**:

   ```bash
   git tag vx.x.x
   git push origin main
   git push origin vx.x.x
   ```

   Pushing the `v*` tag triggers the `.github/workflows/publish.yml` GitHub Action, which builds and publishes the package to PyPI automatically.

### Version Management

- `pyproject.toml` is the absolute source of truth for the package's internal metadata.
- The Git tag (e.g., `v1.2.3`) is the trigger for the release pipeline.
- Both must perfectly match (ignoring the `v` prefix in the tag) for the release to succeed.
- Use PEP 440 versioning: `0.0.0b1`, `0.0.0b2`, `0.0.0`, `0.1.0`, etc.
- Cannot overwrite published versions - increment for each release.
