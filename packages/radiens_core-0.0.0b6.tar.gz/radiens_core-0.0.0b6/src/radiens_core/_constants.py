"""Internal constants — ports, limits, defaults."""

DEFAULT_IP: str = "localhost"
DEFAULT_HUB_ID: str = "default"

# Server ports
ALLEGO_CORE_PORT: int = 50051
PCACHE_PORT: int = 50052
KPI_PORT: int = 50053
NEURONS1_PORT: int = 50054

# Default server addresses
ALLEGO_CORE_ADDR: str = f"{DEFAULT_IP}:{ALLEGO_CORE_PORT}"
PCACHE_ADDR: str = f"{DEFAULT_IP}:{PCACHE_PORT}"
KPI_ADDR: str = f"{DEFAULT_IP}:{KPI_PORT}"
NEURONS1_ADDR: str = f"{DEFAULT_IP}:{NEURONS1_PORT}"

# gRPC message size limits
MAX_GRPC_MSG_BYTES: int = 4 * 1024 * 1024  # 4 MB
MSG_OVERHEAD_BYTES: int = 10 * 1024  # 10 KB for metadata
BYTES_PER_SAMPLE: int = 4  # float32
MAX_SIG_CHUNK_SIZE_BYTES: int = MAX_GRPC_MSG_BYTES - MSG_OVERHEAD_BYTES

MAX_PB_MSG_SIZE_BYTES: int = 60_000_000  # ~60 MB (actual limit is 64 MB)

# Allego stream identifiers
PRIMARY_CACHE_STREAM_GROUP_ID: str = "Live Signals"
NEURONS_SINK_DSOURCE_ID: str = "sorter-sink:primary_cache"
SPIKE_SORTER_ID: str = PRIMARY_CACHE_STREAM_GROUP_ID

# Time format
TIME_SPEC: str = "%Y-%m-%d %H:%M:%S"

# Default time range
DEFAULT_LOOKBACK_SEC: float = 5.0

# Allego-reserved ports (excluded from radiensserver discovery)
ALLEGO_PORTS: frozenset[int] = frozenset(
    {ALLEGO_CORE_PORT, PCACHE_PORT, KPI_PORT, NEURONS1_PORT}
)

# Well-known allego service defaults
ALLEGO_SERVICE_DEFAULTS: dict[str, str] = {
    "ALLEGO_CORE": ALLEGO_CORE_ADDR,
    "ALLEGO_LIFECYCLE": ALLEGO_CORE_ADDR,
    "ALLEGO_PCACHE": PCACHE_ADDR,
    "ALLEGO_KPI": KPI_ADDR,
    "ALLEGO_NEURONS": NEURONS1_ADDR,
}
