# radiens-core

**Python client for the Radiens electrophysiology analytics platform.**

## Overview

This package provides a modern, type-safe Python interface to the Radiens platform for neuroscience research. It enables real-time data acquisition, offline analysis, and curation of electrophysiological recordings.

## Installation

```bash
pip install radiens-core
```

## Requirements

- Python 3.12+
- Radiens platform access
- Valid Radiens credentials

## Support

For technical support or questions about using this client:

- Contact: NeuroNexus Support
- Email: <support@neuronexus.com>

## License

See [LICENSE](LICENSE) file.
