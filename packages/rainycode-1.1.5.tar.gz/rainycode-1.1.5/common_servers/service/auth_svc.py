from datetime import datetime, timedelta
import uuid
import json
import re
from urllib.parse import urlencode
from fastapi.responses import RedirectResponse
from common_base.consts import (
    REDIS_PREFIX_BLOCKLIST,
    REDIS_PREFIX_REFRESH_TOKEN,
    REDIS_PREFIX_OAUTH_STATE,
    REDIS_PREFIX_USER_INFO,
    REDIS_PREFIX_WECHAT_CODE,
    REDIS_PREFIX_WECHAT_OAUTH_CODE,
    REDIS_PREFIX_LOGIN_LOCK_USER,
    REDIS_PREFIX_LOGIN_LOCK_IP,
)
from common_base.exception import CustomException
from common_base.logging import logger
from common_models.user_model import User
from common_models.wechat_model import WechatApp, WechatUser, AppTypeEnum
from common_utils.bcrypt_util import PwdUtil
from common_utils.jwt_util import JwtUtil
from common_utils.wechat_util import WechatUtil
from core.databases.aioredis import AioRedis
from common_servers.schemas.auth_schema import UserRegister, UserLogin, WechatLogin
from tortoise.transactions import atomic
from tortoise.expressions import Q
from core.base_config import base_config


# 登录限流配置
LOGIN_FAIL_LIMIT = 5  # 最大失败次数
LOGIN_LOCK_SECONDS = 900  # 锁定时间（15分钟）
IP_FAIL_LIMIT = 20  # 单 IP 最大失败次数


class AuthService:
    """认证服务逻辑"""

    @classmethod
    @atomic('main')
    async def register(cls, user_in: UserRegister) -> User:
        """
        用户注册
        """
        # 校验密码强度
        strength_error = PwdUtil.check_password_strength(user_in.password)
        if strength_error:
            raise CustomException(msg=strength_error)

        # 合并检查用户名、邮箱、手机号是否存在
        filters = Q(username=user_in.username)
        if user_in.email:
            filters = filters | Q(email=user_in.email)
        if user_in.phone:
            filters = filters | Q(phone=user_in.phone)

        existing_user = await User.filter(filters).first()

        if existing_user:
            if existing_user.username == user_in.username:
                raise CustomException(msg="用户名已存在",)
            if user_in.email and existing_user.email == user_in.email:
                raise CustomException(msg="邮箱已存在")
            if user_in.phone and existing_user.phone == user_in.phone:
                raise CustomException(msg="手机号已存在")

        # 创建用户
        user = await User.create(
            username=user_in.username,
            password=PwdUtil.set_password_hash(user_in.password),
            email=user_in.email,
            phone=user_in.phone,
            nickname=user_in.nickname
        )
        logger.info(f"用户注册成功: username={user.username}, user_id={user.id}")
        return user

    @classmethod
    async def login(cls, user_in: UserLogin, client_ip: str) -> dict:
        """
        用户密码登录
        """
        user = await cls._authenticate_password(user_in, client_ip)
        token_data = await cls._create_tokens(user)
        logger.info(f"用户登录成功: username={user.username}, user_id={user.id}, ip={client_ip}")
        return token_data

    @classmethod
    async def login_wechat_mini(cls, wechat_in: WechatLogin) -> dict:
        """
        微信小程序登录
        """
        user = await cls._authenticate_wechat_mini(wechat_in)
        return await cls._create_tokens(user)

    @classmethod
    async def refresh_token(cls, refresh_token: str) -> dict:
        """
        刷新 Token
        """
        user_id = await AioRedis.get(f"{REDIS_PREFIX_REFRESH_TOKEN}{refresh_token}")
        if not user_id:
            raise CustomException(msg="无效或已过期的刷新令牌")
        try:
            user_id = int(user_id)
        except (ValueError, TypeError):
            raise CustomException(msg="无效的刷新令牌")

        user = await User.get_or_none(id=user_id)
        if not user or not user.is_active:
            raise CustomException(msg="用户不存在或已被禁用")

        # Token 轮换：删除旧的，生成新的
        await AioRedis.delete(f"{REDIS_PREFIX_REFRESH_TOKEN}{refresh_token}")
        token_data = await cls._create_tokens(user)
        logger.info(f"Token刷新成功: username={user.username}, user_id={user.id}")
        return token_data

    @classmethod
    async def logout(cls, access_token: str, refresh_token: str):
        """
        登出
        1. 将 Access Token 加入黑名单
        2. 删除 Refresh Token
        """
        # 1. 处理 Access Token 黑名单
        payload = JwtUtil.decode_token(access_token)
        if payload:
            exp_timestamp = payload.get("exp")
            if exp_timestamp:
                now_timestamp = datetime.now().timestamp()
                expire_seconds = int(exp_timestamp - now_timestamp)
                if expire_seconds > 0:
                    # 添加 Token 到黑名单
                    await AioRedis.set(f"{REDIS_PREFIX_BLOCKLIST}{access_token}", "1", ex=expire_seconds)

        # 2. 删除 Refresh Token
        if refresh_token:
            await AioRedis.delete(f"{REDIS_PREFIX_REFRESH_TOKEN}{refresh_token}")

        # 记录登出日志
        if payload:
            user_id = payload.get("sub")
            username = payload.get("username")
            logger.info(f"用户登出: user_id={user_id}, username={username}")

    @classmethod
    async def get_wechat_oauth_url(cls, app_pk: int, redirect_uri: str, state: str | None = None) -> str:
        """
        生成微信网页授权链接（snsapi_base）

        :param app_pk: 微信应用主键ID
        :param redirect_uri: 授权成功后跳转的前端地址
        :param state: 自定义状态参数
        :return: 微信授权链接
        """
        # 验证公众号配置
        app_config = await WechatApp.get_or_none(id=app_pk, app_type=AppTypeEnum.OFFICIAL_ACCOUNT)
        if not app_config:
            raise CustomException(msg="无效的公众号配置")

        # 校验 state 格式
        if state:
            if not re.match(r'^[a-zA-Z0-9_]{1,64}$', state):
                raise CustomException(msg="state 参数格式无效")

        # 生成内部 state
        internal_state = state or str(uuid.uuid4())

        # 缓存 state -> (redirect_uri, app_pk) 映射，有效期 5 分钟
        cache_value = json.dumps({"redirect_uri": redirect_uri, "app_pk": app_pk})
        await AioRedis.set(f"{REDIS_PREFIX_OAUTH_STATE}{internal_state}", cache_value, ex=300)

        # 构建回调地址
        callback_url = f"{base_config.base_url}/wechat/oauth/callback"

        return WechatUtil.build_oauth_url(
            appid=app_config.app_id,
            redirect_uri=callback_url,
            scope="snsapi_base",
            state=internal_state
        )

    @classmethod
    async def handle_oauth_callback(cls, code: str, state: str | None) -> RedirectResponse:
        """
        处理微信网页授权回调

        :param code: 微信授权码
        :param state: 状态参数
        :return: 重定向响应
        """
        # 从 Redis 获取缓存的 state 信息
        cache_key = f"{REDIS_PREFIX_OAUTH_STATE}{state}"
        cache_value = await AioRedis.get(cache_key)

        if not cache_value:
            raise CustomException(msg="授权已过期，请重新获取")

        # 解析缓存数据（JSON 格式）
        try:
            cached_data = json.loads(cache_value)
            redirect_uri = cached_data.get("redirect_uri")
            app_pk = cached_data.get("app_pk")
        except (json.JSONDecodeError, TypeError):
            raise CustomException(msg="授权数据格式错误")

        if not redirect_uri or not app_pk:
            raise CustomException(msg="授权数据不完整")

        # 删除已使用的 state
        await AioRedis.delete(cache_key)

        # 检查 code 是否已使用（防重放）
        code_key = f"{REDIS_PREFIX_WECHAT_OAUTH_CODE}{code}"
        if await AioRedis.get(code_key):
            raise CustomException(msg="授权码已失效，请重新授权")

        # 获取公众号配置
        app_config = await WechatApp.get_or_none(id=app_pk, app_type=AppTypeEnum.OFFICIAL_ACCOUNT)
        if not app_config:
            raise CustomException(msg="公众号配置不存在")

        # 用 code 换取 access_token 和 openid
        wx_res = await WechatUtil.get_oauth_access_token(
            app_config.app_id,
            app_config.app_secret,
            code
        )
        openid = wx_res.get("openid")
        scope = wx_res.get("scope", "")

        if not openid:
            raise CustomException(msg="获取用户信息失败")

        # 标记 code 已使用
        await AioRedis.set(code_key, "1", ex=300)

        # 检查用户是否已存在
        wechat_user = await WechatUser.get_or_none(openid=openid, wechat_app=app_config).select_related("user")

        if wechat_user:
            # 用户已存在，直接登录
            token_data = await cls._create_tokens(wechat_user.user)
            return await cls._build_redirect_response(redirect_uri, token_data, state)

        # 用户不存在，检查是否是 snsapi_userinfo 回调
        if "snsapi_userinfo" in scope:
            access_token = wx_res.get("access_token")
            if not access_token:
                raise CustomException(msg="获取用户令牌失败")

            user_info = await WechatUtil.get_user_info(access_token, openid)

            # 使用 _bind_or_register_wechat_user 创建或绑定用户
            user = await cls._bind_or_register_wechat_user(
                openid=openid,
                app_config=app_config,
                unionid=wx_res.get("unionid"),
                nickname=user_info.get("nickname"),
                avatar=user_info.get("headimgurl")
            )

            token_data = await cls._create_tokens(user)
            return await cls._build_redirect_response(redirect_uri, token_data, state)

        # 新用户，需要 snsapi_userinfo 授权
        # 缓存 state 信息供二次回调使用
        new_state = str(uuid.uuid4())
        await AioRedis.set(f"{REDIS_PREFIX_OAUTH_STATE}{new_state}", cache_value, ex=300)

        # 构建 snsapi_userinfo 授权链接
        api_prefix = f"/api/{base_config.app_name}" if base_config.app_name else ""
        callback_url = f"{base_config.base_url}{api_prefix}/wechat/oauth/callback"
        userinfo_auth_url = WechatUtil.build_oauth_url(
            appid=app_config.app_id,
            redirect_uri=callback_url,
            scope="snsapi_userinfo",
            state=new_state
        )

        return RedirectResponse(url=userinfo_auth_url, status_code=302)

    # ==================== 私有方法 ====================

    @classmethod
    async def _authenticate_password(cls, data: UserLogin, client_ip: str) -> User:
        """用户名密码认证"""
        # 检查锁定状态
        await cls._check_login_lock(data.username, client_ip)

        user = await User.get_or_none(username=data.username)
        if not user:
            await cls._record_login_fail(data.username, client_ip)
            logger.warning(f"登录失败: 用户名不存在, username={data.username}, ip={client_ip}")
            raise CustomException(msg="用户名或密码错误")

        if not PwdUtil.verify_password(data.password, user.password):
            await cls._record_login_fail(data.username, client_ip)
            logger.warning(f"登录失败: 密码错误, username={data.username}, ip={client_ip}")
            raise CustomException(msg="用户名或密码错误")

        if not user.is_active:
            raise CustomException(msg="用户已被禁用")

        # 清除失败记录
        await cls._clear_login_fail(data.username, client_ip)

        # 更新最后登录时间
        user.last_login = datetime.now()
        await user.save(update_fields=['last_login'])

        # 清除缓存
        await AioRedis.delete(f"{REDIS_PREFIX_USER_INFO}{user.id}")

        return user

    @classmethod
    async def _authenticate_wechat_mini(cls, data: WechatLogin) -> User:
        """微信小程序认证"""
        # 1. 获取小程序配置
        app_config = await WechatApp.get_or_none(
            app_id=data.app_id, app_type=AppTypeEnum.MINI_PROGRAM
        )
        if not app_config:
            raise CustomException(msg="无效的小程序配置")

        # 2. 检查 code 是否已使用（防重放）
        code_key = f"{REDIS_PREFIX_WECHAT_CODE}{data.code}"
        if await AioRedis.get(code_key):
            raise CustomException(msg="登录凭证已失效，请重新获取")

        # 3. code 换取 session_key 和 openid
        wx_res = await WechatUtil.code2session(
            app_config.app_id, app_config.app_secret, data.code
        )
        openid = wx_res.get("openid")
        unionid = wx_res.get("unionid")
        session_key = wx_res.get("session_key")

        if not openid or not session_key:
            raise CustomException(msg="微信登录异常: 缺少必要信息")

        # 4. 标记 code 已使用
        await AioRedis.set(code_key, "1", ex=300)

        # 5. 一键登录（解密手机号）
        phone = None
        if data.encrypted_data and data.iv:
            phone_info = WechatUtil.decrypt_data(
                session_key, data.encrypted_data, data.iv, app_config.app_id
            )
            phone = phone_info.get("phoneNumber")
            # 校验手机号格式
            if phone and not re.match(r'^1[3-9]\d{9}$', phone):
                raise CustomException(msg="手机号格式不正确")

        # 6. 使用 _bind_or_register_wechat_user 处理用户绑定/注册
        return await cls._bind_or_register_wechat_user(
            openid=openid,
            app_config=app_config,
            unionid=unionid,
            phone=phone,
            session_key=session_key,
        )

    @classmethod
    async def _check_login_lock(cls, username: str, client_ip: str):
        """检查登录锁定状态"""
        # 检查用户名锁定
        user_key = f"{REDIS_PREFIX_LOGIN_LOCK_USER}{username}"
        fail_count = await AioRedis.get(user_key)
        if fail_count and int(fail_count) >= LOGIN_FAIL_LIMIT:
            raise CustomException(msg="登录失败次数过多，请 15 分钟后再试")

        # 检查 IP 锁定
        ip_key = f"{REDIS_PREFIX_LOGIN_LOCK_IP}{client_ip}"
        ip_fail_count = await AioRedis.get(ip_key)
        if ip_fail_count and int(ip_fail_count) >= IP_FAIL_LIMIT:
            raise CustomException(msg="请求过于频繁，请稍后再试")

    @classmethod
    async def _record_login_fail(cls, username: str, client_ip: str):
        """记录登录失败"""
        # 记录用户名失败
        user_key = f"{REDIS_PREFIX_LOGIN_LOCK_USER}{username}"
        count = await AioRedis.incrby(user_key, 1)
        if count == 1:
            await AioRedis.expire(user_key, LOGIN_LOCK_SECONDS)

        # 记录 IP 失败
        ip_key = f"{REDIS_PREFIX_LOGIN_LOCK_IP}{client_ip}"
        ip_count = await AioRedis.incrby(ip_key, 1)
        if ip_count == 1:
            await AioRedis.expire(ip_key, LOGIN_LOCK_SECONDS)

    @classmethod
    async def _clear_login_fail(cls, username: str, client_ip: str):
        """清除登录失败记录"""
        await AioRedis.delete(f"{REDIS_PREFIX_LOGIN_LOCK_USER}{username}")
        await AioRedis.delete(f"{REDIS_PREFIX_LOGIN_LOCK_IP}{client_ip}")

    @classmethod
    async def _create_tokens(cls, user: User) -> dict:
        """
        生成双Token并缓存用户信息
        """
        # Access Token
        token_data = {"sub": str(user.id), "username": user.username}
        # 显式传递配置中的过期时间
        expires_delta = timedelta(minutes=base_config.access_token_expire_minutes)
        access_token = JwtUtil.create_access_token(token_data, expires_delta=expires_delta)

        # Refresh Token
        refresh_token = str(uuid.uuid4())
        expire_seconds = base_config.refresh_token_expire_days * 24 * 60 * 60
        await AioRedis.set(f"{REDIS_PREFIX_REFRESH_TOKEN}{refresh_token}", str(user.id), ex=expire_seconds)

        return {
            "access_token": access_token,
            "refresh_token": refresh_token,
            "token_type": "bearer",
            "expires_in": base_config.access_token_expire_minutes * 60,
        }

    @classmethod
    @atomic("main")
    async def _bind_or_register_wechat_user(
        cls,
        openid: str,
        app_config: WechatApp,
        unionid: str | None = None,
        phone: str | None = None,
        nickname: str | None = None,
        avatar: str | None = None,
        session_key: str | None = None,
    ) -> User:
        """
        绑定已有用户或创建新用户（微信登录专用）

        Args:
            openid: 微信 OpenID
            app_config: 微信应用配置
            unionid: 微信 UnionID（可选，用于跨应用关联）
            phone: 手机号（可选，小程序一键登录获取）
            nickname: 微信昵称
            avatar: 微信头像
            session_key: 会话密钥（仅小程序）

        Returns:
            User: 用户对象
        """
        # 1. 检查 WechatUser 是否已存在
        wechat_user = await WechatUser.get_or_none(
            openid=openid, wechat_app=app_config
        ).select_related("user")

        if wechat_user:
            # 已存在关联，更新信息
            if session_key:
                wechat_user.session_key = session_key
            if nickname:
                wechat_user.nickname = nickname
            if avatar:
                wechat_user.avatar = avatar
            if phone and not wechat_user.user.phone:
                wechat_user.user.phone = phone
                await wechat_user.user.save()
            await wechat_user.save()
            return wechat_user.user

        # 2. 检查 User 是否存在（通过 phone 或 unionid）
        user = None
        if phone:
            user = await User.get_or_none(phone=phone)

        # 如果有 UnionID，检查其他应用下的 WechatUser 是否关联了 User
        if not user and unionid:
            other_wechat_user = (
                await WechatUser.filter(unionid=unionid)
                .exclude(wechat_app=app_config)
                .first()
                .select_related("user")
            )
            if other_wechat_user:
                user = other_wechat_user.user

        # 3. 创建 User（如不存在）
        if not user:
            # 使用 UUID 避免并发冲突
            username = f"wx_{uuid.uuid4().hex[:8]}"
            user = await User.create(
                username=username,
                password="",  # 微信用户无密码
                phone=phone,
                nickname=nickname or f"用户{username[-4:]}",
                avatar=avatar,
            )

        # 4. 创建 WechatUser 关联
        await WechatUser.create(
            user=user,
            wechat_app=app_config,
            openid=openid,
            unionid=unionid,
            session_key=session_key,
            nickname=nickname,
            avatar=avatar,
        )

        return user

    @classmethod
    async def _build_redirect_response(
        cls, redirect_uri: str, token_data: dict, state: str | None = None
    ) -> RedirectResponse:
        """构建带 token 的重定向响应（使用 URL Fragment）"""
        params = {
            "access_token": token_data["access_token"],
            "refresh_token": token_data["refresh_token"],
            "token_type": token_data["token_type"],
            "expires_in": str(token_data["expires_in"]),
        }
        if state:
            params["state"] = state

        # 使用 # fragment 传递 token，避免出现在服务器日志中
        fragment = urlencode(params)
        redirect_url = f"{redirect_uri}#{fragment}"
        return RedirectResponse(url=redirect_url, status_code=302)