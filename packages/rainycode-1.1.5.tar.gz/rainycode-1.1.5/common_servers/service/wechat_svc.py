import time
import hashlib
import xml.etree.ElementTree as ET
from common_base.exception import CustomException
from common_base.logging import logger
from common_models.wechat_model import WechatApp


class WechatService:
    @staticmethod
    async def verify_signature(app_pk: int, signature: str, timestamp: str, nonce: str) -> bool:
        """
        验证微信签名
        """
        app = await WechatApp.get_or_none(id=app_pk)
        if not app:
            raise CustomException(msg="微信应用不存在")

        token = app.token
        if not token:
            logger.error(f"App {app_pk} 未配置Callback Token")
            # 如果未配置Token，无法验证，视为失败
            return False

        try:
            tmp_list = [token, timestamp, nonce]
            tmp_list.sort()
            tmp_str = "".join(tmp_list)
            hash_str = hashlib.sha1(tmp_str.encode("utf-8")).hexdigest()
            return hash_str == signature
        except Exception as e:
            logger.error(f"签名验证异常: {e}")
            return False

    @staticmethod
    async def handle_message(app_pk: int, xml_data: str, signature: str, timestamp: str, nonce: str) -> str:
        """
        处理微信回调消息
        """
        # 再次验证签名确保安全
        if not await WechatService.verify_signature(app_pk, signature, timestamp, nonce):
            logger.warning(f"消息验证签名失败：{app_pk}，签名={signature}，时间戳={timestamp}，随机数={nonce}")
            return "fail"

        try:
            root = ET.fromstring(xml_data)
            msg_type = root.findtext("MsgType")
            to_user = root.findtext("ToUserName")
            from_user = root.findtext("FromUserName")
            if from_user is None or to_user is None:
                logger.error(f"消息格式错误：缺少FromUserName或ToUserName")
                return "fail"

            # 简单的事件分发
            if msg_type == "event":
                event = root.findtext("Event")
                if event == "subscribe":
                    # 可以在此处添加用户关注后的业务逻辑，如保存用户，发放优惠券等
                    logger.info(f"用户 {from_user} 关注了应用 {app_pk}")
                    return WechatService._reply_text(from_user, to_user, "欢迎关注！")
                elif event == "unsubscribe":
                    logger.info(f"用户 {from_user} 取消关注应用 {app_pk}")

            return "success"
        except Exception as e:
            logger.error(f"处理微信消息异常: {e}")
            return "fail"

    @staticmethod
    def _reply_text(to_user: str, from_user: str, content: str) -> str:
        create_time = int(time.time())
        return f"""<xml>
        <ToUserName><![CDATA[{to_user}]]></ToUserName>
        <FromUserName><![CDATA[{from_user}]]></FromUserName>
        <CreateTime>{create_time}</CreateTime>
        <MsgType><![CDATA[text]]></MsgType>
        <Content><![CDATA[{content}]]></Content>
        </xml>"""
