from common_models.user_model import User
from fastapi import APIRouter, Security, Body, Query, Request
from common_base.response import SuccessReturn
from common_depends.auth_depend import login_require
from common_servers.schemas.auth_schema import *
from common_servers.service.auth_svc import AuthService

router = APIRouter(prefix="/auth")

@router.post("/register", summary="用户注册")
async def register(user_in: UserRegister):
    user = await AuthService.register(user_in)
    return SuccessReturn(
        data={"id": str(user.id), "username": user.username}, msg="注册成功"
    )


@router.post("/login", summary="用户密码登录")
async def login(user_in: UserLogin, request: Request):
    client_ip = request.client.host if request.client else "unknown"
    token_data = await AuthService.login(user_in, client_ip)
    return SuccessReturn(data=token_data, msg="登录成功")


@router.post("/refresh", response_model=TokenResponse, summary="刷新令牌")
async def refresh_token(refresh_token: str = Body(..., embed=True)):
    token_data = await AuthService.refresh_token(refresh_token)
    return SuccessReturn(data=token_data, msg="刷新成功")


@router.post("/logout", summary="登出")
async def logout(
    request: Request,
    refresh_token: str = Body(..., embed=True),
    _: User = Security(login_require),
):
    token = request.state.token
    await AuthService.logout(token, refresh_token)
    return SuccessReturn(msg="登出成功")


@router.get("/me", response_model=UserInfo, summary="获取当前用户信息")
async def get_me(user: User = Security(login_require)):
    return SuccessReturn(data=user)


@router.post("/wechat/mini", response_model=TokenResponse, summary="微信小程序登录")
async def login_mini(wechat_in: WechatLogin):
    """
    微信小程序登录

    - 静默登录: 传 code + app_id
    - 一键登录(获取手机号): 额外传 encrypted_data + iv
    """
    token_data = await AuthService.login_wechat_mini(wechat_in)
    return SuccessReturn(data=token_data, msg="登录成功")


@router.get("/wechat/oauth", summary="获取微信网页授权链接 - 回调(/oauth/callback)")
async def get_wechat_oauth_url(
    app_pk: int = Query(..., description="微信应用主键ID"),
    redirect_uri: str = Query(..., description="授权成功后跳转地址"),
    state: str | None = Query(default=None, description="自定义状态参数"),
):
    """
    获取微信网页授权链接（snsapi_base 静默授权）

    - 首次请求返回 snsapi_base 授权链接
    - 如果用户已注册，回调后直接返回 token
    - 如果用户未注册，自动重定向到 snsapi_userinfo 授权
    """
    authorize_url = await AuthService.get_wechat_oauth_url(app_pk, redirect_uri, state)
    return SuccessReturn(data={"authorize_url": authorize_url})