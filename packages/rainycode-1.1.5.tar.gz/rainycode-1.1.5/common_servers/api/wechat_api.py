import json
from urllib.parse import urlencode
from fastapi import APIRouter, Request, Query, Response
from fastapi.responses import RedirectResponse
from common_base.consts import REDIS_PREFIX_OAUTH_STATE
from common_base.exception import CustomException
from common_servers.service.auth_svc import AuthService
from common_servers.service.wechat_svc import WechatService
from core.databases.aioredis import AioRedis

router = APIRouter(prefix="/wechat")


@router.get("/callback/{app_pk}", summary="微信回调验证")
async def verify_callback(
    app_pk: int,
    signature: str = Query(..., description="微信加密签名"),
    timestamp: str = Query(..., description="时间戳"),
    nonce: str = Query(..., description="随机数"),
    echostr: str = Query(..., description="随机字符串"),
):
    """
    微信服务器配置验证接口
    """
    is_valid = await WechatService.verify_signature(app_pk, signature, timestamp, nonce)
    if is_valid:
        # 必须直接返回 echostr 字符串，不能包含 json 格式
        return Response(content=echostr, media_type="text/plain")
    return Response(content="fail", media_type="text/plain")


@router.post("/callback/{app_pk}", summary="微信消息回调")
async def handle_callback(
    app_pk: int,
    request: Request,
    signature: str = Query(..., description="微信加密签名"),
    timestamp: str = Query(..., description="时间戳"),
    nonce: str = Query(..., description="随机数"),
    openid: str = Query(None, description="用户OpenID"),
    encrypt_type: str = Query(None, description="加密类型"),
    msg_signature: str = Query(None, description="消息体签名"),
):
    """
    接收微信推送的消息和事件
    """
    # 获取原始 XML 数据
    body = await request.body()
    xml_data = body.decode("utf-8")

    # 目前仅实现了明文模式，加密模式需要结合 msg_secret 解密
    # 如果 encrypt_type == "aes"，需要解密 (暂未实现，TODO)
    result = await WechatService.handle_message(
        app_pk, xml_data, signature, timestamp, nonce
    )
    return Response(content=result, media_type="application/xml")


@router.get("/oauth/callback", summary="微信网页授权回调")
async def wechat_oauth_callback(
    code: str | None = Query(default=None, description="微信授权码"),
    state: str | None = Query(default=None, description="状态参数"),
    error: str | None = Query(default=None, description="错误码"),
    error_description: str | None = Query(default=None, description="错误描述"),
):
    """
    处理微信网页授权回调

    - 用户已存在：重定向到前端（带 token）
    - 用户不存在：自动重定向到 snsapi_userinfo 授权
    - 用户拒绝授权：重定向到前端并附带错误信息
    """
    # 处理用户拒绝授权的情况
    if error:
        # 获取 redirect_uri
        cache_key = f"{REDIS_PREFIX_OAUTH_STATE}{state}"
        cache_value = await AioRedis.get(cache_key)
        if cache_value:
            try:
                cached_data = json.loads(cache_value)
                redirect_uri = cached_data.get("redirect_uri")
            except (json.JSONDecodeError, TypeError):
                redirect_uri = None

            if redirect_uri:
                await AioRedis.delete(cache_key)
                params = {
                    "error": error,
                    "error_description": error_description or "用户拒绝授权",
                }
                error_url = f"{redirect_uri}?{urlencode(params)}"
                return RedirectResponse(url=error_url, status_code=302)

        raise CustomException(msg="授权失败")

    if not code:
        raise CustomException(msg="缺少授权码")

    return await AuthService.handle_oauth_callback(code, state)
