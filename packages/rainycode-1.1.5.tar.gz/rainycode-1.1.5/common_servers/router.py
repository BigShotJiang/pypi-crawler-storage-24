from fastapi import APIRouter
from common_servers.api.auth_api import router as auth_router
from common_servers.api.wechat_api import router as wechat_router


base_router = APIRouter()

base_router.include_router(auth_router, tags=["认证模块"])
base_router.include_router(wechat_router, tags=["微信回调"])
