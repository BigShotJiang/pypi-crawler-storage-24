from pydantic import BaseModel, Field, EmailStr

class UserLogin(BaseModel):
    """用户登录模型"""
    username: str = Field(..., description="用户名")
    password: str = Field(..., description="密码")

class UserRegister(BaseModel):
    """用户注册模型"""
    username: str = Field(..., description="用户名")
    password: str = Field(..., min_length=6, description="密码")
    email: str | None = Field(None, description="邮箱")
    phone: str | None = Field(None, description="手机号")
    nickname: str | None = Field(None, description="昵称")

class TokenResponse(BaseModel):
    """Token响应模型"""
    access_token: str = Field(..., description="访问令牌")
    refresh_token: str = Field(..., description="刷新令牌")
    token_type: str = Field("bearer", description="令牌类型")
    expires_in: int = Field(..., description="过期时间(秒)")

class UserInfo(BaseModel):
    """用户信息模型"""
    id: int | str = Field(..., description="用户ID")
    username: str = Field(..., description="用户名")
    email: str | None = Field(None, description="邮箱")
    phone: str | None = Field(None, description="手机号")
    nickname: str | None = Field(None, description="昵称")
    avatar: str | None = Field(None, description="头像")
    is_active: bool = Field(..., description="是否激活")
    is_superuser: bool = Field(..., description="是否超级管理员")
    create_time: str | None = Field(None, description="创建时间")
    
    class Config:
        from_attributes = True

class WechatLogin(BaseModel):
    """微信小程序登录模型"""
    code: str = Field(..., description="微信登录Code (wx.login获取)")
    app_id: str = Field(..., description="小程序AppID")
    encrypted_data: str | None = Field(default=None, description="加密数据(一键登录手机号)")
    iv: str | None = Field(default=None, description="加密算法初始向量")
