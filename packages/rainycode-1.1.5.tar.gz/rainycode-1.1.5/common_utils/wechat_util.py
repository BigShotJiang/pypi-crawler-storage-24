from common_base import aiorequests
from common_base.exception import CustomException
from common_base.logging import logger
from Crypto.Cipher import AES
from urllib.parse import quote
import base64
import json

class WechatUtil:

    @classmethod
    def build_oauth_url(cls, appid: str, redirect_uri: str, state: str, scope: str = "snsapi_base") -> str:
        """
        构建微信公众号授权登录 URL
        https://developers.weixin.qq.com/doc/offiaccount/OA_Web_Apps/Wechat_webpage_authorization.html

        Args:
            appid: 微信公众号 appid
            redirect_uri: 授权回调地址
            state: 状态参数，用于防止 CSRF
            scope: 授权作用域，snsapi_base（静默授权）或 snsapi_userinfo（需用户同意）

        Returns:
            授权登录 URL
        """
        encoded_redirect_uri = quote(redirect_uri, safe='')
        url = f"https://open.weixin.qq.com/connect/oauth2/authorize?appid={appid}&redirect_uri={encoded_redirect_uri}&response_type=code&scope={scope}&state={state}#wechat_redirect"
        return url

    @classmethod
    async def code2session(cls, appid: str, secret: str, code: str) -> dict:
        """
        小程序登录凭证校验
        https://developers.weixin.qq.com/miniprogram/dev/api-backend/open-api/login/auth.code2Session.html
        """
        url = "https://api.weixin.qq.com/sns/jscode2session"
        params = {
            "appid": appid,
            "secret": secret,
            "js_code": code,
            "grant_type": "authorization_code"
        }
        try:
            data = await aiorequests.get(url, params=params)
            if "errcode" in data and data["errcode"] != 0:
                logger.error(f"Wechat code2session error: errcode={data.get('errcode')}, errmsg={data.get('errmsg')}")
                raise CustomException(msg=f"微信登录失败: {data.get('errmsg')}")
            return data
        except Exception as e:
            if isinstance(e, CustomException):
                raise e
            logger.error(f"Wechat API request error: {e}")
            raise CustomException(msg="微信服务暂时不可用")

    @classmethod
    async def get_oauth_access_token(cls, appid: str, secret: str, code: str) -> dict:
        """
        公众号通过code获取access_token
        """
        url = "https://api.weixin.qq.com/sns/oauth2/access_token"
        params = {
            "appid": appid,
            "secret": secret,
            "code": code,
            "grant_type": "authorization_code"
        }
        data = await aiorequests.get(url, params=params)
        if "errcode" in data and data["errcode"] != 0:
            logger.error(f"Wechat oauth access_token error: errcode={data.get('errcode')}, errmsg={data.get('errmsg')}")
            raise CustomException(msg=f"微信授权失败: {data.get('errmsg')}")
        return data

    @classmethod
    async def get_user_info(cls, access_token: str, openid: str) -> dict:
        """
        公众号获取用户信息
        """
        url = "https://api.weixin.qq.com/sns/userinfo"
        params = {
            "access_token": access_token,
            "openid": openid,
            "lang": "zh_CN"
        }
        data = await aiorequests.get(url, params=params)
        if "errcode" in data and data["errcode"] != 0:
            logger.error(f"Wechat get_user_info error: errcode={data.get('errcode')}, errmsg={data.get('errmsg')}")
            raise CustomException(msg=f"获取微信用户信息失败: {data.get('errmsg')}")
        return data

    @classmethod
    def decrypt_data(
        cls, session_key: str, encrypted_data: str, iv: str, appid: str
    ) -> dict:
        """
        小程序解密用户信息/手机号
        """
        try:
            session_key_b = base64.b64decode(session_key)
            encrypted_data_b = base64.b64decode(encrypted_data)
            iv_b = base64.b64decode(iv)

            cipher = AES.new(session_key_b, AES.MODE_CBC, iv_b)
            decrypted = cipher.decrypt(encrypted_data_b)

            # 去除PKCS#7填充
            unpad = lambda s: s[:-ord(s[len(s)-1:])]
            decrypted_json = unpad(decrypted)

            data = json.loads(decrypted_json)

            if data['watermark']['appid'] != appid:
                raise CustomException(msg="Invalid Buffer")

            return data
        except Exception as e:
            logger.error(f"Decrypt wechat data failed: {e}")
            raise CustomException(msg="微信数据解密失败")
