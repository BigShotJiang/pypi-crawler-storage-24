from pydantic_settings import BaseSettings, SettingsConfigDict


class BaseConfig(BaseSettings):
    app_debug: bool = False
    app_title: str = ''
    app_name: str = ''

    # 数据库
    redis_url: str = ''
    mysql_url: str = ''

    # 基础 URL
    base_url: str = ""

    # 跨域
    cors_origins: list[str] = ['*']
    cors_allow_credentials: bool = True
    cors_allow_methods: list[str] = ['GET', 'POST', 'PUT', 'DELETE']
    cors_allow_headers: list[str] = ['*']

    # JWT密钥
    jwt_secret_key: str = "bgb0tnl9d58+6n-6h-ea&u^1#s0ccp!794=krylacjq75vzps$"

    # Access Token 有效期
    access_token_expire_minutes: int = 30
    # Refresh Token 有效期
    refresh_token_expire_days: int = 30

    model_config = SettingsConfigDict(
        env_file=('envs/dev.env', 'envs/pro.env'),
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra='ignore'
    )

base_config = BaseConfig()
