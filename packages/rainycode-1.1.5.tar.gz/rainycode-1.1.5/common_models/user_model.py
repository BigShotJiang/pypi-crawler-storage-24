from tortoise import fields
from common_models.base_model import UpdateModel


class User(UpdateModel):
    """
    用户模型
    """
    id = fields.IntField(pk=True, description="主键")
    username = fields.CharField(max_length=50, unique=True, description="用户名")
    password = fields.CharField(max_length=128, description="密码(加密)")
    email = fields.CharField(max_length=100, null=True, unique=True, description="邮箱")
    phone = fields.CharField(max_length=20, null=True, unique=True, description="手机号")
    nickname = fields.CharField(max_length=50, null=True, description="昵称")
    avatar = fields.CharField(max_length=255, null=True, description="头像URL")
    is_active = fields.BooleanField(default=True, description="是否激活")
    is_superuser = fields.BooleanField(default=False, description="是否超级管理员")
    last_login = fields.DatetimeField(null=True, description="最后登录时间")

    class Meta:
        table = "user"
        table_description = "用户表"

    class PydanticMeta:
        exclude = ["password"]
