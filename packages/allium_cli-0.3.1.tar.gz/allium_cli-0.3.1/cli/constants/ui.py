from __future__ import annotations

from questionary import Style

ACCENT = "#be59c0"

PROMPT_STYLE = Style(
    [
        ("qmark", f"fg:{ACCENT} bold"),
        ("question", "bold"),
        ("pointer", f"fg:{ACCENT} bold"),
        ("highlighted", f"fg:{ACCENT} bold"),
        ("selected", f"fg:{ACCENT}"),
        ("answer", f"fg:{ACCENT} bold"),
        ("instruction", "fg:#6B7280 italic"),
        ("separator", "fg:#6B7280"),
    ]
)

LOGO = (
    "⠀⠀⣠⡴⠖⠛⠛⠛⠳⠶⣤⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n"
    "⢀⡾⢋⣴⠞⢛⣉⣙⠛⢶⡌⠻⣆⠀⠀⠀⠀⠀⣴⡄⠀⠀⠀⣶⠀⠀⢰⡆⠀⠸⠷⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n"
    "⣾⠁⣾⠃⣼⠋⠉⠙⢷⡄⢻⡄⢻⡆⠀⠀⠀⣼⠋⢻⡄⠀⠀⣿⠀⠀⢸⡇⠀⢰⡆⠀⢰⡆⠀⠀⠀⣶⠀⣶⡴⠶⠶⣦⠶⠶⠶⣆\n"
    "⢿⡀⢿⡄⢻⣄⣀⣠⡾⠃⣼⠃⣼⠇⠀⠀⣼⣧⣤⣤⣿⡄⠀⣿⠀⠀⢸⡇⠀⢸⡇⠀⢸⡇⠀⠀⠀⣿⠀⣿⠀⠀⠀⣿⠀⠀⠀⣿\n"
    "⠈⢷⣌⠻⢦⣬⣉⣩⣤⠾⢃⣴⠏⠀⠀⢰⠏⠀⠀⠀⠈⢿⠄⠻⣤⠄⠸⢧⡄⠸⡇⠀⠘⠧⣤⡤⠴⡿⠀⢿⠀⠀⠀⢿⠀⠀⠀⡿\n"
    "⠀⠀⠙⠳⠦⣤⣤⣤⡴⠶⠛⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀"
)
