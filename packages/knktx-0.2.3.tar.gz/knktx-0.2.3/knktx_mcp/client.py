"""HTTP client wrapping the knktx REST API."""

import os
import re
from typing import Any, Literal
from urllib.parse import quote

import httpx

_SAFE_PATH_RE = re.compile(r"^[a-zA-Z0-9_-]+$")
_UUID_RE = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$")
_AGENT_MODEL_RE = re.compile(r"^[a-zA-Z0-9._-]+$")
_AGENT_MODEL_MAX_LEN = 100


class ApiError(Exception):
    """Raised when the knktx API returns an error."""

    def __init__(self, status: int, detail: str) -> None:
        super().__init__(detail)
        self.status = status
        self.detail = detail


def _safe_path(value: str) -> str:
    """Validate and encode a path segment to prevent path traversal."""
    if _SAFE_PATH_RE.match(value) or _UUID_RE.match(value):
        return value
    return quote(value, safe="")


class KnktxClient:
    """Thin HTTP client for the knktx API.

    Config is read from environment variables:
    - KNKTX_API_URL: Base URL (e.g. https://knktx.dev/api/v1)
    - KNKTX_API_KEY: API key for authentication
    """

    def __init__(
        self,
        api_url: str | None = None,
        api_key: str | None = None,
    ) -> None:
        self.api_url = (api_url if api_url is not None else os.environ.get("KNKTX_API_URL", "")).rstrip("/")
        self._api_key = api_key if api_key is not None else os.environ.get("KNKTX_API_KEY", "")
        if not self.api_url:
            raise ValueError("KNKTX_API_URL is required")
        if not self._api_key:
            raise ValueError("KNKTX_API_KEY is required")
        self._client = httpx.AsyncClient(
            base_url=self.api_url,
            headers={"Authorization": f"Bearer {self._api_key}"},
            timeout=30.0,
        )

    async def aclose(self) -> None:
        """Close the underlying HTTP client."""
        await self._client.aclose()

    async def __aenter__(self) -> "KnktxClient":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.aclose()

    async def _request(
        self,
        method: str,
        path: str,
        *,
        json: Any = None,
        params: dict[str, Any] | None = None,
        agent_model: str | None = None,
    ) -> Any:
        headers: dict[str, str] = {}
        if agent_model:
            clean = agent_model.strip()[:_AGENT_MODEL_MAX_LEN]
            if clean and _AGENT_MODEL_RE.match(clean):
                headers["X-Agent-Model"] = clean
        try:
            resp = await self._client.request(method, path, json=json, params=params, headers=headers)
            resp.raise_for_status()
        except httpx.HTTPStatusError as e:
            try:
                body = e.response.json()
                detail = body.get("detail", str(e.response.status_code))
            except Exception:
                detail = str(e.response.status_code)
            raise ApiError(e.response.status_code, f"API error {e.response.status_code}: {detail}") from None
        except httpx.RequestError as e:
            raise ApiError(0, f"API unreachable: {type(e).__name__}") from None
        if resp.status_code == 204:
            return None
        return resp.json()

    # --- Projects ---

    async def list_projects(self, *, include_archived: bool = False) -> list[dict[str, Any]]:
        params: dict[str, str] = {}
        if include_archived:
            params["include_archived"] = "true"
        return await self._request("GET", "/projects", params=params)

    async def create_project(self, name: str, description: str | None = None, *, agent_model: str | None = None) -> dict[str, Any]:
        body: dict[str, Any] = {"name": name}
        if description is not None:
            body["description"] = description
        return await self._request("POST", "/projects", json=body, agent_model=agent_model)

    async def get_project(self, slug: str) -> dict[str, Any]:
        return await self._request("GET", f"/projects/{_safe_path(slug)}")

    async def update_project(
        self,
        slug: str,
        *,
        name: str | None = None,
        description: str | None = None,
        agent_model: str | None = None,
    ) -> dict[str, Any]:
        fields: dict[str, Any] = {}
        if name is not None:
            fields["name"] = name
        if description is not None:
            fields["description"] = description
        return await self._request("PATCH", f"/projects/{_safe_path(slug)}", json=fields, agent_model=agent_model)

    async def archive_project(self, slug: str, *, agent_model: str | None = None) -> dict[str, Any]:
        return await self._request("POST", f"/projects/{_safe_path(slug)}/archive", agent_model=agent_model)

    async def restore_project(self, slug: str, *, agent_model: str | None = None) -> dict[str, Any]:
        return await self._request("POST", f"/projects/{_safe_path(slug)}/restore", agent_model=agent_model)

    async def delete_project(self, slug: str, *, agent_model: str | None = None) -> None:
        await self._request("DELETE", f"/projects/{_safe_path(slug)}", agent_model=agent_model)

    # --- Boards ---

    async def list_boards(
        self,
        project_slug: str,
        q: str | None = None,
        *,
        status: Literal["active", "completed", "archived"] | None = None,
    ) -> list[dict[str, Any]]:
        params: dict[str, str] = {}
        if q:
            params["q"] = q
        if status is not None:
            params["status"] = status
        return await self._request("GET", f"/projects/{_safe_path(project_slug)}/boards", params=params)

    async def create_board(self, project_slug: str, name: str, description: str | None = None, *, agent_model: str | None = None) -> dict[str, Any]:
        body: dict[str, Any] = {"name": name}
        if description is not None:
            body["description"] = description
        return await self._request("POST", f"/projects/{_safe_path(project_slug)}/boards", json=body, agent_model=agent_model)

    async def get_board(self, project_slug: str, board_id: str) -> dict[str, Any]:
        return await self._request("GET", f"/projects/{_safe_path(project_slug)}/boards/{_safe_path(board_id)}")

    async def update_board(
        self,
        project_slug: str,
        board_id: str,
        *,
        name: str | None = None,
        description: str | None = None,
        status: str | None = None,
        agent_model: str | None = None,
    ) -> dict[str, Any]:
        fields: dict[str, Any] = {}
        if name is not None:
            fields["name"] = name
        if description is not None:
            fields["description"] = description
        if status is not None:
            fields["status"] = status
        return await self._request(
            "PATCH",
            f"/projects/{_safe_path(project_slug)}/boards/{_safe_path(board_id)}",
            json=fields,
            agent_model=agent_model,
        )

    async def delete_board(self, project_slug: str, board_id: str, *, agent_model: str | None = None) -> None:
        await self._request(
            "DELETE",
            f"/projects/{_safe_path(project_slug)}/boards/{_safe_path(board_id)}",
            agent_model=agent_model,
        )

    # --- Cards ---

    async def list_cards(self, project_slug: str, board_id: str, *, status: str | None = None) -> list[dict[str, Any]]:
        params: dict[str, str] = {}
        if status is not None:
            params["status"] = status
        return await self._request("GET", f"/projects/{_safe_path(project_slug)}/boards/{_safe_path(board_id)}/cards", params=params)

    async def create_card(
        self,
        project_slug: str,
        board_id: str,
        title: str,
        *,
        description: str | None = None,
        status: str = "inbox",
        assignee: str | None = None,
        agent_model: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"title": title, "status": status}
        if description is not None:
            body["description"] = description
        if assignee is not None:
            body["assignee"] = assignee
        return await self._request(
            "POST",
            f"/projects/{_safe_path(project_slug)}/boards/{_safe_path(board_id)}/cards",
            json=body,
            agent_model=agent_model,
        )

    async def update_card(
        self,
        project_slug: str,
        board_id: str,
        card_id: str,
        *,
        title: str | None = None,
        description: str | None = None,
        assignee: str | None = None,
        branch_name: str | None = None,
        pr_url: str | None = None,
        agent_model: str | None = None,
    ) -> dict[str, Any]:
        fields: dict[str, Any] = {}
        if title is not None:
            fields["title"] = title
        if description is not None:
            fields["description"] = description
        if assignee is not None:
            fields["assignee"] = assignee
        if branch_name is not None:
            fields["branch_name"] = branch_name
        if pr_url is not None:
            fields["pr_url"] = pr_url
        return await self._request(
            "PATCH",
            f"/projects/{_safe_path(project_slug)}/boards/{_safe_path(board_id)}/cards/{_safe_path(card_id)}",
            json=fields,
            agent_model=agent_model,
        )

    async def get_card(self, project_slug: str, board_id: str, card_id: str) -> dict[str, Any]:
        return await self._request(
            "GET",
            f"/projects/{_safe_path(project_slug)}/boards/{_safe_path(board_id)}/cards/{_safe_path(card_id)}",
        )

    async def delete_card(self, project_slug: str, board_id: str, card_id: str, *, agent_model: str | None = None) -> None:
        await self._request(
            "DELETE",
            f"/projects/{_safe_path(project_slug)}/boards/{_safe_path(board_id)}/cards/{_safe_path(card_id)}",
            agent_model=agent_model,
        )

    async def move_card(
        self,
        project_slug: str,
        board_id: str,
        card_id: str,
        status: str,
        *,
        agent_model: str | None = None,
    ) -> dict[str, Any]:
        return await self._request(
            "POST",
            f"/projects/{_safe_path(project_slug)}/boards/{_safe_path(board_id)}/cards/{_safe_path(card_id)}/move",
            json={"status": status},
            agent_model=agent_model,
        )

    async def reorder_card(
        self,
        project_slug: str,
        board_id: str,
        card_id: str,
        position: int,
        *,
        agent_model: str | None = None,
    ) -> dict[str, Any]:
        return await self._request(
            "POST",
            f"/projects/{_safe_path(project_slug)}/boards/{_safe_path(board_id)}/cards/{_safe_path(card_id)}/reorder",
            json={"position": position},
            agent_model=agent_model,
        )

    # --- Comments ---

    async def list_comments(self, project_slug: str, board_id: str, card_id: str) -> list[dict[str, Any]]:
        return await self._request(
            "GET",
            f"/projects/{_safe_path(project_slug)}/boards/{_safe_path(board_id)}/cards/{_safe_path(card_id)}/comments",
        )

    async def comment_on_card(
        self,
        project_slug: str,
        board_id: str,
        card_id: str,
        content: str,
        *,
        agent_model: str | None = None,
    ) -> dict[str, Any]:
        return await self._request(
            "POST",
            f"/projects/{_safe_path(project_slug)}/boards/{_safe_path(board_id)}/cards/{_safe_path(card_id)}/comments",
            json={"content": content},
            agent_model=agent_model,
        )

    async def update_comment(
        self,
        project_slug: str,
        board_id: str,
        card_id: str,
        comment_id: str,
        content: str,
        *,
        agent_model: str | None = None,
    ) -> dict[str, Any]:
        return await self._request(
            "PATCH",
            f"/projects/{_safe_path(project_slug)}/boards/{_safe_path(board_id)}/cards/{_safe_path(card_id)}/comments/{_safe_path(comment_id)}",
            json={"content": content},
            agent_model=agent_model,
        )

    async def delete_comment(
        self,
        project_slug: str,
        board_id: str,
        card_id: str,
        comment_id: str,
        *,
        agent_model: str | None = None,
    ) -> None:
        await self._request(
            "DELETE",
            f"/projects/{_safe_path(project_slug)}/boards/{_safe_path(board_id)}/cards/{_safe_path(card_id)}/comments/{_safe_path(comment_id)}",
            agent_model=agent_model,
        )

    # --- Documents ---

    async def list_documents(
        self,
        project_slug: str,
        *,
        doc_type: str | None = None,
        board_id: str | None = None,
        path: str | None = None,
        include_completed: bool = False,
    ) -> list[dict[str, Any]]:
        params: dict[str, str] = {}
        if doc_type is not None:
            params["doc_type"] = doc_type
        if board_id is not None:
            params["board_id"] = board_id
        if path is not None:
            params["path"] = path
        if include_completed:
            params["include_completed"] = "true"
        return await self._request("GET", f"/projects/{_safe_path(project_slug)}/documents", params=params)

    async def get_document_by_type(self, project_slug: str, doc_type: str, *, board_id: str | None = None) -> dict[str, Any]:
        params: dict[str, str] = {}
        if board_id is not None:
            params["board_id"] = board_id
        return await self._request("GET", f"/projects/{_safe_path(project_slug)}/documents/by-type/{_safe_path(doc_type)}", params=params)

    async def write_document(
        self,
        project_slug: str,
        doc_type: str,
        title: str,
        content: str,
        *,
        board_id: str | None = None,
        path: str | None = None,
        agent_model: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"doc_type": doc_type, "title": title, "content": content}
        if board_id is not None:
            body["board_id"] = board_id
        if path is not None:
            body["path"] = path
        return await self._request(
            "PUT",
            f"/projects/{_safe_path(project_slug)}/documents",
            json=body,
            agent_model=agent_model,
        )

    async def get_document_by_id(self, project_slug: str, document_id: str) -> dict[str, Any]:
        return await self._request("GET", f"/projects/{_safe_path(project_slug)}/documents/{_safe_path(document_id)}")

    async def delete_document(self, project_slug: str, document_id: str, *, agent_model: str | None = None) -> None:
        await self._request("DELETE", f"/projects/{_safe_path(project_slug)}/documents/{_safe_path(document_id)}", agent_model=agent_model)

    async def update_document(
        self,
        project_slug: str,
        document_id: str,
        *,
        title: str | None = None,
        content: str | None = None,
        path: str | None = None,
        agent_model: str | None = None,
    ) -> dict[str, Any]:
        fields: dict[str, Any] = {}
        if title is not None:
            fields["title"] = title
        if content is not None:
            fields["content"] = content
        if path is not None:
            fields["path"] = path
        return await self._request(
            "PATCH",
            f"/projects/{_safe_path(project_slug)}/documents/{_safe_path(document_id)}",
            json=fields,
            agent_model=agent_model,
        )

    # --- Notes ---

    async def list_notes(self, *, project_slug: str | None = None, status: str | None = None, board_id: str | None = None) -> list[dict[str, Any]]:
        params: dict[str, str] = {}
        if status is not None:
            params["status"] = status
        if board_id is not None:
            params["board_id"] = board_id
        if project_slug:
            return await self._request("GET", f"/projects/{_safe_path(project_slug)}/notes", params=params)
        return await self._request("GET", "/notes", params=params)

    async def search_notes(self, query: str, *, project_slug: str | None = None, status: str | None = None, board_id: str | None = None) -> list[dict[str, Any]]:
        params: dict[str, str] = {"q": query}
        if status is not None:
            params["status"] = status
        if board_id is not None:
            params["board_id"] = board_id
        if project_slug:
            return await self._request("GET", f"/projects/{_safe_path(project_slug)}/notes/search", params=params)
        return await self._request("GET", "/notes/search", params=params)

    async def delete_note(self, title: str, *, project_slug: str | None = None, agent_model: str | None = None) -> None:
        if project_slug:
            await self._request("DELETE", f"/projects/{_safe_path(project_slug)}/notes/{quote(title, safe='')}", agent_model=agent_model)
        else:
            await self._request("DELETE", f"/notes/{quote(title, safe='')}", agent_model=agent_model)

    async def write_note(
        self,
        title: str,
        content: str,
        *,
        agent: str | None = None,
        tags: list[str] | None = None,
        status: str | None = None,
        board_id: str | None = None,
        project_slug: str | None = None,
        agent_model: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"title": title, "content": content}
        if agent is not None:
            body["agent"] = agent
        if tags is not None:
            body["tags"] = tags
        if status is not None:
            body["status"] = status
        if board_id is not None:
            body["board_id"] = board_id
        if project_slug:
            return await self._request("POST", f"/projects/{_safe_path(project_slug)}/notes", json=body, agent_model=agent_model)
        return await self._request("POST", "/notes", json=body, agent_model=agent_model)

    # --- Skills ---

    async def list_skills(self, *, agent: str | None = None) -> list[dict[str, Any]]:
        params: dict[str, str] = {}
        if agent is not None:
            params["agent"] = agent
        return await self._request("GET", "/skills", params=params)

    async def get_skill(self, slug: str) -> dict[str, Any]:
        return await self._request("GET", f"/skills/{_safe_path(slug)}")

    async def create_skill(
        self,
        name: str,
        *,
        content: str = "",
        version: str = "1.0.0",
        description: str | None = None,
        metadata: dict[str, Any] | None = None,
        is_public: bool = False,
        enabled: bool = True,
        user_invocable: bool = False,
        allowed_tools: list[str] | None = None,
        agent_model: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"name": name, "content": content, "version": version, "is_public": is_public, "enabled": enabled, "user_invocable": user_invocable}
        if description is not None:
            body["description"] = description
        if metadata is not None:
            body["metadata"] = metadata
        if allowed_tools is not None:
            body["allowed_tools"] = allowed_tools
        return await self._request("POST", "/skills", json=body, agent_model=agent_model)

    async def update_skill(
        self,
        slug: str,
        *,
        name: str | None = None,
        content: str | None = None,
        version: str | None = None,
        description: str | None = None,
        metadata: dict[str, Any] | None = None,
        is_public: bool | None = None,
        enabled: bool | None = None,
        user_invocable: bool | None = None,
        allowed_tools: list[str] | None = None,
        agent_model: str | None = None,
    ) -> dict[str, Any]:
        fields: dict[str, Any] = {}
        if name is not None:
            fields["name"] = name
        if content is not None:
            fields["content"] = content
        if version is not None:
            fields["version"] = version
        if description is not None:
            fields["description"] = description
        if metadata is not None:
            fields["metadata"] = metadata
        if is_public is not None:
            fields["is_public"] = is_public
        if enabled is not None:
            fields["enabled"] = enabled
        if user_invocable is not None:
            fields["user_invocable"] = user_invocable
        if allowed_tools is not None:
            fields["allowed_tools"] = allowed_tools
        return await self._request("PATCH", f"/skills/{_safe_path(slug)}", json=fields, agent_model=agent_model)

    async def delete_skill(self, slug: str, *, agent_model: str | None = None) -> None:
        await self._request("DELETE", f"/skills/{_safe_path(slug)}", agent_model=agent_model)

    # --- MCP Configs ---

    async def list_mcp_configs(self, *, agent: str | None = None) -> list[dict[str, Any]]:
        params: dict[str, str] = {}
        if agent is not None:
            params["agent"] = agent
        return await self._request("GET", "/mcp-configs", params=params)

    async def get_mcp_config(self, name: str) -> dict[str, Any]:
        return await self._request("GET", f"/mcp-configs/{_safe_path(name)}")

    async def create_mcp_config(
        self,
        name: str,
        config: dict[str, Any],
        *,
        description: str | None = None,
        metadata: dict[str, Any] | None = None,
        is_public: bool = False,
        enabled: bool = True,
        install_command: str | None = None,
        agent_model: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"name": name, "config": config, "is_public": is_public, "enabled": enabled}
        if description is not None:
            body["description"] = description
        if metadata is not None:
            body["metadata"] = metadata
        if install_command is not None:
            body["install_command"] = install_command
        return await self._request("POST", "/mcp-configs", json=body, agent_model=agent_model)

    async def update_mcp_config(
        self,
        name: str,
        *,
        config: dict[str, Any] | None = None,
        description: str | None = None,
        metadata: dict[str, Any] | None = None,
        is_public: bool | None = None,
        enabled: bool | None = None,
        install_command: str | None = None,
        agent_model: str | None = None,
    ) -> dict[str, Any]:
        fields: dict[str, Any] = {}
        if config is not None:
            fields["config"] = config
        if description is not None:
            fields["description"] = description
        if metadata is not None:
            fields["metadata"] = metadata
        if is_public is not None:
            fields["is_public"] = is_public
        if enabled is not None:
            fields["enabled"] = enabled
        if install_command is not None:
            fields["install_command"] = install_command
        return await self._request("PATCH", f"/mcp-configs/{_safe_path(name)}", json=fields, agent_model=agent_model)

    async def delete_mcp_config(self, name: str, *, agent_model: str | None = None) -> None:
        await self._request("DELETE", f"/mcp-configs/{_safe_path(name)}", agent_model=agent_model)

    # --- Plugins ---

    async def list_plugins(self, *, agent: str | None = None) -> list[dict[str, Any]]:
        params: dict[str, str] = {}
        if agent is not None:
            params["agent"] = agent
        return await self._request("GET", "/plugins", params=params)

    async def get_plugin(self, slug: str) -> dict[str, Any]:
        return await self._request("GET", f"/plugins/{_safe_path(slug)}")

    async def create_plugin(
        self,
        name: str,
        *,
        content: str = "",
        description: str | None = None,
        metadata: dict[str, Any] | None = None,
        is_public: bool = False,
        enabled: bool = True,
        agent_model: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"name": name, "content": content, "is_public": is_public, "enabled": enabled}
        if description is not None:
            body["description"] = description
        if metadata is not None:
            body["metadata"] = metadata
        return await self._request("POST", "/plugins", json=body, agent_model=agent_model)

    async def update_plugin(
        self,
        slug: str,
        *,
        name: str | None = None,
        content: str | None = None,
        description: str | None = None,
        metadata: dict[str, Any] | None = None,
        is_public: bool | None = None,
        enabled: bool | None = None,
        agent_model: str | None = None,
    ) -> dict[str, Any]:
        fields: dict[str, Any] = {}
        if name is not None:
            fields["name"] = name
        if content is not None:
            fields["content"] = content
        if description is not None:
            fields["description"] = description
        if metadata is not None:
            fields["metadata"] = metadata
        if is_public is not None:
            fields["is_public"] = is_public
        if enabled is not None:
            fields["enabled"] = enabled
        return await self._request("PATCH", f"/plugins/{_safe_path(slug)}", json=fields, agent_model=agent_model)

    async def delete_plugin(self, slug: str, *, agent_model: str | None = None) -> None:
        await self._request("DELETE", f"/plugins/{_safe_path(slug)}", agent_model=agent_model)

    # --- Workflows ---

    async def list_workflows(self, project_slug: str | None = None, *, enabled: bool | None = None, agent: str | None = None) -> list[dict[str, Any]]:
        params: dict[str, str] = {}
        if project_slug:
            params["project_slug"] = project_slug
        if enabled is not None:
            params["enabled"] = str(enabled).lower()
        if agent is not None:
            params["agent"] = agent
        return await self._request("GET", "/workflows", params=params)

    async def get_workflow(self, workflow_id: str) -> dict[str, Any]:
        return await self._request("GET", f"/workflows/{_safe_path(workflow_id)}")

    async def create_workflow(
        self,
        name: str,
        *,
        description: str | None = None,
        project_slug: str | None = None,
        trigger_type: str | None = None,
        trigger_config: dict[str, Any] | None = None,
        steps: list[dict[str, Any]] | None = None,
        enabled: bool = True,
        agent_model: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"name": name, "enabled": enabled}
        if description is not None:
            body["description"] = description
        if project_slug is not None:
            body["project_slug"] = project_slug
        if trigger_type is not None:
            body["trigger_type"] = trigger_type
        if trigger_config is not None:
            body["trigger_config"] = trigger_config
        if steps is not None:
            body["steps"] = steps
        return await self._request("POST", "/workflows", json=body, agent_model=agent_model)

    async def update_workflow(
        self,
        workflow_id: str,
        *,
        name: str | None = None,
        description: str | None = None,
        trigger_type: str | None = None,
        trigger_config: dict[str, Any] | None = None,
        steps: list[dict[str, Any]] | None = None,
        enabled: bool | None = None,
        agent_model: str | None = None,
    ) -> dict[str, Any]:
        fields: dict[str, Any] = {}
        if name is not None:
            fields["name"] = name
        if description is not None:
            fields["description"] = description
        if trigger_type is not None:
            fields["trigger_type"] = trigger_type
        if trigger_config is not None:
            fields["trigger_config"] = trigger_config
        if steps is not None:
            fields["steps"] = steps
        if enabled is not None:
            fields["enabled"] = enabled
        return await self._request("PATCH", f"/workflows/{_safe_path(workflow_id)}", json=fields, agent_model=agent_model)

    async def delete_workflow(self, workflow_id: str, *, agent_model: str | None = None) -> None:
        await self._request("DELETE", f"/workflows/{_safe_path(workflow_id)}", agent_model=agent_model)

    async def duplicate_workflow(self, workflow_id: str, *, agent_model: str | None = None) -> dict[str, Any]:
        return await self._request("POST", f"/workflows/{_safe_path(workflow_id)}/duplicate", agent_model=agent_model)

    # --- Rules ---

    async def list_rules(
        self,
        project_slug: str | None = None,
        rule_type: str | None = None,
        enabled: bool | None = None,
        source: Literal["custom", "settings"] | None = None,
        agent: str | None = None,
    ) -> list[dict[str, Any]]:
        params: dict[str, str] = {}
        if project_slug is not None:
            params["project_slug"] = project_slug
        if rule_type is not None:
            params["rule_type"] = rule_type
        if enabled is not None:
            params["enabled"] = str(enabled).lower()
        if source is not None:
            params["source"] = source
        if agent is not None:
            params["agent"] = agent
        return await self._request("GET", "/rules", params=params)

    async def get_rule(self, rule_id: str) -> dict[str, Any]:
        return await self._request("GET", f"/rules/{_safe_path(rule_id)}")

    async def create_rule(
        self,
        name: str,
        rule_type: str,
        *,
        description: str | None = None,
        project_slug: str | None = None,
        config: dict[str, Any] | None = None,
        source: Literal["custom", "settings"] = "custom",
        enabled: bool = True,
        agent_model: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "name": name,
            "rule_type": rule_type,
            "source": source,
            "enabled": enabled,
        }
        if description is not None:
            body["description"] = description
        if project_slug is not None:
            body["project_slug"] = project_slug
        if config is not None:
            body["config"] = config
        return await self._request("POST", "/rules", json=body, agent_model=agent_model)

    async def update_rule(
        self,
        rule_id: str,
        *,
        name: str | None = None,
        description: str | None = None,
        rule_type: str | None = None,
        config: dict[str, Any] | None = None,
        enabled: bool | None = None,
        agent_model: str | None = None,
    ) -> dict[str, Any]:
        fields: dict[str, Any] = {}
        if name is not None:
            fields["name"] = name
        if description is not None:
            fields["description"] = description
        if rule_type is not None:
            fields["rule_type"] = rule_type
        if config is not None:
            fields["config"] = config
        if enabled is not None:
            fields["enabled"] = enabled
        return await self._request("PATCH", f"/rules/{_safe_path(rule_id)}", json=fields, agent_model=agent_model)

    async def delete_rule(self, rule_id: str, *, agent_model: str | None = None) -> None:
        await self._request("DELETE", f"/rules/{_safe_path(rule_id)}", agent_model=agent_model)

    # --- Activity ---

    async def get_activity(
        self,
        project_slug: str,
        *,
        limit: int = 50,
        offset: int = 0,
        entity_type: str | None = None,
        action: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if entity_type:
            params["entity_type"] = entity_type
        if action:
            params["action"] = action
        return await self._request("GET", f"/projects/{_safe_path(project_slug)}/activity", params=params)
