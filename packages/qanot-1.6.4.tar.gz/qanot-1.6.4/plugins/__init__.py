"""Built-in Qanot plugins."""
