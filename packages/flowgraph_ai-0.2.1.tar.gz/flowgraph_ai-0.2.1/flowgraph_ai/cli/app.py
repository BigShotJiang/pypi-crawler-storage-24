"""
FlowGraph-AI Developer CLI

Commands:
  flowgraph health              — Check DB, LLM, workflows
  flowgraph db set <url>        — Save database connection string
  flowgraph db test             — Test database connectivity
  flowgraph llm set <provider>  — Switch LLM provider
  flowgraph llm test            — Test LLM connectivity
  flowgraph init <project>      — Scaffold a complete demo project
  flowgraph new <name>          — Scaffold a new workflow interactively
  flowgraph list                — List all workflows
  flowgraph show <name>         — Show workflow node graph
  flowgraph validate [name]     — Validate workflow YAML
  flowgraph run <name>          — Chat with a workflow in the terminal
  flowgraph serve               — Start the API server

  # Observability stack (Langfuse + Jaeger + PostgreSQL via Docker)
  flowgraph stack up            — Start the observability stack
  flowgraph stack down          — Stop the observability stack
  flowgraph stack status        — Show status of all stack services
  flowgraph stack logs          — Tail logs from stack services
  flowgraph stack configure     — Save Langfuse API keys to config.yaml

  # One-command dev start
  flowgraph dev                 — Start stack + API server (full dev mode)

  # Testing
  flowgraph test                — Run unit tests
  flowgraph test --integration  — Run integration tests (needs DB + LLM)
  flowgraph test --coverage     — Run tests with coverage report
"""

import sys
import os
import time
import uuid

# Ensure project root is on sys.path when run as a script
_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

import typer
import yaml
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.tree import Tree
from rich import box
from rich.prompt import Prompt, Confirm
from rich.syntax import Syntax
from rich.progress import Progress, SpinnerColumn, TextColumn

app = typer.Typer(
    name="flowgraph",
    help="[bold cyan]FlowGraph-AI[/] — YAML-driven AI workflow engine",
    rich_markup_mode="rich",
    no_args_is_help=True,
    add_completion=True,
)

db_app    = typer.Typer(help="Database / checkpoint commands",              no_args_is_help=True)
llm_app   = typer.Typer(help="LLM provider commands",                       no_args_is_help=True)
stack_app = typer.Typer(help="Observability stack (Langfuse + Jaeger)",     no_args_is_help=True)
app.add_typer(db_app,    name="db")
app.add_typer(llm_app,   name="llm")
app.add_typer(stack_app, name="stack")

console = Console()
err     = Console(stderr=True)

_PROVIDERS = ["ollama", "claude", "openai", "openrouter", "lmstudio"]


# ── Helpers ────────────────────────────────────────────────────────────────────

def _load_cfg() -> dict:
    from flowgraph_ai.config import load_config
    return load_config()


def _save_cfg(cfg: dict) -> None:
    cfg_path = os.path.join(_ROOT, "config.yaml")
    with open(cfg_path, "w") as f:
        yaml.dump(cfg, f, default_flow_style=False, sort_keys=False, allow_unicode=True)


def _workflows_dir() -> str:
    return os.path.join(_ROOT, "workflows")


def _ok(msg: str)   -> None: console.print(f"[bold green]✓[/] {msg}")
def _fail(msg: str) -> None: console.print(f"[bold red]✗[/] {msg}")
def _info(msg: str) -> None: console.print(f"[dim]→[/] {msg}")


def _docker_dir() -> str:
    return os.path.join(_ROOT, "docker")


def _compose_cmd(*args: str) -> list[str]:
    """Build a docker compose command pointing at our compose file."""
    return [
        "docker", "compose",
        "-f", os.path.join(_docker_dir(), "docker-compose.yml"),
        "--project-name", "flowgraph",
        *args,
    ]


def _docker_available() -> bool:
    import subprocess
    try:
        subprocess.run(["docker", "info"], capture_output=True, timeout=5, check=True)
        return True
    except Exception:
        return False


# ══════════════════════════════════════════════════════════════════════════════
# flowgraph health
# ══════════════════════════════════════════════════════════════════════════════

@app.command()
def health():
    """Run a full health check: database, LLM, and workflow validation."""
    console.print()
    console.rule("[bold cyan]FlowGraph-AI Health Check[/]")

    cfg = _load_cfg()
    all_ok = True

    # ── 1. Config ─────────────────────────────────────────────────────────────
    console.print("\n[bold]Config[/]")
    _ok(f"config.yaml loaded")
    provider = cfg.get("llm", {}).get("provider", "?")
    _info(f"LLM provider : [cyan]{provider}[/]")
    conn = cfg.get("checkpoint", {}).get("connection_string", "")
    ckpt_type = "postgres" if conn.startswith(("postgresql://", "postgres://")) else ("sqlite" if conn else "memory")
    _info(f"Checkpoint   : [cyan]{ckpt_type}[/]")

    # ── 2. Database ───────────────────────────────────────────────────────────
    console.print("\n[bold]Database[/]")
    if ckpt_type == "memory":
        console.print("  [yellow]⚠[/]  Using in-memory storage — conversations reset on restart")
        console.print("     Run [cyan]flowgraph db set <url>[/] to configure persistence")
    elif ckpt_type == "sqlite":
        db_path = conn.removeprefix("sqlite:///").removeprefix("sqlite://")
        try:
            import sqlite3
            c = sqlite3.connect(db_path)
            c.close()
            _ok(f"SQLite  {db_path}")
        except Exception as e:
            _fail(f"SQLite  {db_path} — {e}")
            all_ok = False
    elif ckpt_type == "postgres":
        try:
            import psycopg
            c = psycopg.connect(conn, connect_timeout=3)
            c.close()
            _ok(f"PostgreSQL  {_redact(conn)}")
        except Exception as e:
            _fail(f"PostgreSQL  {_redact(conn)} — {e}")
            all_ok = False

    # ── 3. LLM ────────────────────────────────────────────────────────────────
    console.print("\n[bold]LLM[/]")
    from flowgraph_ai.llm.provider import get_llm
    try:
        llm = get_llm(cfg)
        with Progress(SpinnerColumn(), TextColumn("{task.description}"), transient=True, console=console) as p:
            p.add_task(f"Pinging {provider}…")
            result = llm.invoke("Reply with exactly: pong").content.strip().lower()
        if "pong" in result:
            _ok(f"{provider} responded correctly")
        else:
            console.print(f"  [yellow]⚠[/]  {provider} responded: [dim]{result[:80]}[/]")
    except Exception as e:
        _fail(f"{provider} — {e}")
        all_ok = False

    # ── 4. Observability ──────────────────────────────────────────────────────
    console.print("\n[bold]Observability[/]")
    import urllib.request as _req

    obs = cfg.get("observability", {})
    lf_cfg = obs.get("langfuse", {})
    tr_cfg = obs.get("tracing",  {})

    if lf_cfg.get("enabled"):
        lf_host = lf_cfg.get("host", "http://localhost:3000")
        try:
            _req.urlopen(f"{lf_host}/api/public/health", timeout=3)
            _ok(f"Langfuse reachable at [cyan]{lf_host}[/]")
        except Exception:
            _fail(f"Langfuse not reachable at [cyan]{lf_host}[/] — run [cyan]flowgraph stack up[/]")
            all_ok = False
        pk = lf_cfg.get("public_key", "")
        if not pk:
            console.print("  [yellow]⚠[/]  Langfuse keys not set — run [cyan]flowgraph stack configure[/]")
            all_ok = False
        else:
            _ok(f"Langfuse keys configured  (pk: [dim]{pk[:12]}…[/])")
    else:
        console.print("  [dim]Langfuse disabled[/]  enable via [cyan]flowgraph stack configure[/]")

    if tr_cfg.get("enabled"):
        jaeger_endpoint = tr_cfg.get("endpoint", "http://localhost:4317")
        try:
            _req.urlopen("http://localhost:16686/", timeout=3)
            _ok(f"Jaeger reachable at [cyan]http://localhost:16686[/]  OTLP → [cyan]{jaeger_endpoint}[/]")
        except Exception:
            _fail(f"Jaeger not reachable — run [cyan]flowgraph stack up[/]")
            all_ok = False
        try:
            import opentelemetry  # noqa: F401
            _ok("opentelemetry-sdk installed")
        except ImportError:
            _fail("opentelemetry-sdk not installed — run: [cyan]uv sync[/]")
            all_ok = False
    else:
        console.print("  [dim]Jaeger tracing disabled[/]  enable via [cyan]flowgraph stack configure[/]")

    # ── 5. Workflows ──────────────────────────────────────────────────────────
    console.print("\n[bold]Workflows[/]")
    from flowgraph_ai.engine.workflow_loader import WorkflowLoader
    loader = WorkflowLoader()
    names  = loader.list_workflows()
    if not names:
        console.print("  [yellow]⚠[/]  No workflows found in workflows/")
        all_ok = False
    for name in sorted(names):
        try:
            loader.load(name)
            _ok(name)
        except Exception as e:
            _fail(f"{name} — {e}")
            all_ok = False

    # ── Summary ───────────────────────────────────────────────────────────────
    console.print()
    if all_ok:
        console.print(Panel("[bold green]All checks passed — system is healthy[/]", box=box.ROUNDED))
    else:
        console.print(Panel("[bold red]Some checks failed — see above[/]", box=box.ROUNDED))
        raise typer.Exit(1)


# ══════════════════════════════════════════════════════════════════════════════
# flowgraph db set <url>
# flowgraph db test
# ══════════════════════════════════════════════════════════════════════════════

@db_app.command("set")
def db_set(
    url: str = typer.Argument(
        ...,
        help="Connection string.  Examples:\n"
             "  postgresql://user:pass@localhost:5432/mydb\n"
             "  ./flowgraph.db\n"
             "  (empty string for in-memory)",
    ),
):
    """Save the checkpoint database connection string to config.yaml."""
    cfg = _load_cfg()
    cfg.setdefault("checkpoint", {})["connection_string"] = url

    if not url:
        ckpt_label = "in-memory (dev only)"
    elif url.startswith(("postgresql://", "postgres://")):
        ckpt_label = f"PostgreSQL  {_redact(url)}"
    else:
        ckpt_label = f"SQLite  {url}"

    _save_cfg(cfg)
    _ok(f"Checkpoint set to: [cyan]{ckpt_label}[/]")
    console.print("  Run [cyan]flowgraph db test[/] to verify the connection.")


@db_app.command("test")
def db_test():
    """Test the configured database connection."""
    cfg  = _load_cfg()
    conn = cfg.get("checkpoint", {}).get("connection_string", "")

    if not conn or conn == ":memory:":
        console.print("[yellow]Using in-memory storage — no DB connection to test.[/]")
        return

    with Progress(SpinnerColumn(), TextColumn("{task.description}"), transient=True, console=console) as p:
        p.add_task("Connecting…")
        import flowgraph_ai.storage.checkpointer as ckpt
        ckpt.reset()
        try:
            checkpointer = ckpt.get_checkpointer(cfg)
            _ok(f"{type(checkpointer).__name__} connected — tables ready")
        except Exception as e:
            _fail(f"Connection failed: {e}")
            raise typer.Exit(1)


# ══════════════════════════════════════════════════════════════════════════════
# flowgraph llm set <provider>
# flowgraph llm test
# ══════════════════════════════════════════════════════════════════════════════

@llm_app.command("set")
def llm_set(
    provider: str = typer.Argument(..., help=f"Provider name: {', '.join(_PROVIDERS)}"),
    model: str = typer.Option(None, "--model", "-m", help="Model name (optional override)"),
    api_key: str = typer.Option(None, "--api-key", "-k", help="API key (saved to config)"),
    base_url: str = typer.Option(None, "--base-url", "-u", help="Custom base URL (OpenRouter / LM Studio)"),
):
    """Switch the active LLM provider in config.yaml."""
    if provider not in _PROVIDERS:
        _fail(f"Unknown provider '{provider}'. Choose from: {', '.join(_PROVIDERS)}")
        raise typer.Exit(1)

    cfg = _load_cfg()
    cfg.setdefault("llm", {})["provider"] = provider

    llm_cfg = cfg["llm"]
    if model:
        key = f"{provider}_model"
        llm_cfg[key] = model
        _info(f"model  → {model}")
    if api_key:
        llm_cfg[f"{provider}_api_key"] = api_key
        _info("api_key saved")
    if base_url:
        llm_cfg[f"{provider}_base_url"] = base_url
        _info(f"base_url → {base_url}")

    _save_cfg(cfg)
    _ok(f"LLM provider set to: [cyan]{provider}[/]")
    console.print("  Run [cyan]flowgraph llm test[/] to verify.")


@llm_app.command("test")
def llm_test():
    """Send a test prompt to the configured LLM."""
    cfg = _load_cfg()
    provider = cfg.get("llm", {}).get("provider", "ollama")
    console.print(f"Testing [cyan]{provider}[/]…")

    from flowgraph_ai.llm.provider import get_llm
    try:
        llm = get_llm(cfg)
        with Progress(SpinnerColumn(), TextColumn("Waiting for response…"), transient=True, console=console) as p:
            p.add_task("")
            response = llm.invoke("Respond with exactly: hello developer").content.strip()
        _ok(f"Response: [green]{response[:120]}[/]")
    except Exception as e:
        _fail(f"{provider} failed: {e}")
        raise typer.Exit(1)


# ══════════════════════════════════════════════════════════════════════════════
# flowgraph list
# ══════════════════════════════════════════════════════════════════════════════

@app.command("list")
def list_workflows():
    """List all available workflows with their descriptions."""
    from flowgraph_ai.engine.workflow_loader import WorkflowLoader
    loader = WorkflowLoader()
    names  = loader.list_workflows()

    if not names:
        console.print("[yellow]No workflows found in workflows/[/]")
        console.print("  Create one with [cyan]flowgraph new <name>[/]")
        return

    table = Table(box=box.ROUNDED, show_header=True, header_style="bold cyan")
    table.add_column("Workflow",    style="bold", min_width=20)
    table.add_column("Description", style="dim")
    table.add_column("Nodes",       justify="right")
    table.add_column("Start Node",  style="cyan")

    for name in sorted(names):
        try:
            cfg  = loader.load(name)
            meta = loader.load_metadata(name)
            table.add_row(name, meta["description"], str(len(cfg["nodes"])), cfg["start_node"])
        except Exception as e:
            table.add_row(f"[red]{name}[/]", f"[red]{e}[/]", "—", "—")

    console.print()
    console.print(table)
    console.print(f"\n  [dim]{len(names)} workflow(s) found[/]")


# ══════════════════════════════════════════════════════════════════════════════
# flowgraph show <name>
# ══════════════════════════════════════════════════════════════════════════════

@app.command()
def show(
    name: str = typer.Argument(..., help="Workflow name"),
    raw: bool = typer.Option(False, "--raw", "-r", help="Print raw YAML"),
):
    """Show a workflow's node graph and configuration."""
    from flowgraph_ai.engine.workflow_loader import WorkflowLoader

    yaml_path = os.path.join(_workflows_dir(), f"{name}.yaml")
    if not os.path.exists(yaml_path):
        _fail(f"Workflow '{name}' not found.")
        raise typer.Exit(1)

    if raw:
        with open(yaml_path) as f:
            content = f.read()
        console.print(Syntax(content, "yaml", theme="monokai", line_numbers=True))
        return

    loader = WorkflowLoader()
    try:
        cfg = loader.load(name)
    except Exception as e:
        _fail(f"Failed to load '{name}': {e}")
        raise typer.Exit(1)

    # ── Header ────────────────────────────────────────────────────────────────
    console.print()
    console.print(Panel(
        f"[bold cyan]{cfg['workflow']}[/]\n[dim]{cfg['description']}[/]",
        title="Workflow",
        box=box.ROUNDED,
    ))

    # ── Node tree ─────────────────────────────────────────────────────────────
    console.print()
    console.print("[bold]Node Graph[/]")

    node_map = {n["name"]: n for n in cfg["nodes"]}
    _NODE_STYLE = {
        "data_collector": ("📋", "cyan"),
        "custom_action":  ("⚙️ ", "yellow"),
        "response":       ("💬", "green"),
    }

    tree = Tree(f"[bold]START[/] → [cyan]{cfg['start_node']}[/]")

    def _add_node(parent_tree, node_name: str, visited: set):
        if node_name not in node_map or node_name in visited:
            return
        visited.add(node_name)
        n = node_map[node_name]
        icon, color = _NODE_STYLE.get(n["type"], ("?", "white"))
        label = f"{icon} [{color}]{node_name}[/]  [dim]{n['type']}[/]"

        if n["type"] == "data_collector":
            if "field" in n:
                label += f"  [dim]field=[/][bold]{n['field']}[/]"
            elif "fields" in n:
                fields = ", ".join(f["field"] for f in n["fields"])
                label += f"  [dim]fields=[/][bold]{fields}[/]"
        elif n["type"] == "custom_action":
            label += f"  [dim]→[/] [italic]{n.get('method', '?')}[/]"
        elif n["type"] == "response":
            if "template" in n:
                label += f"  [dim]\"{n['template'][:40]}…\"[/]"

        branch = parent_tree.add(label)

        # Follow edges
        nexts = set()
        if n["type"] == "data_collector":
            if "next" in n:      nexts.add(n["next"])
            if "on_max_retry" in n: nexts.add(n["on_max_retry"])
        elif n["type"] == "custom_action":
            for r in n.get("routes", []):
                if "next" in r:    nexts.add(r["next"])
                if "default" in r: nexts.add(r["default"])

        for nxt in sorted(nexts):
            _add_node(branch, nxt, visited)

    _add_node(tree, cfg["start_node"], set())

    # Add any unreachable nodes
    reachable = set()
    def _collect(name, vis):
        if name in node_map and name not in vis:
            vis.add(name)
            n = node_map[name]
            for r in n.get("routes", []):
                _collect(r.get("next", ""), vis)
                _collect(r.get("default", ""), vis)
            if "next" in n:       _collect(n["next"], vis)
            if "on_max_retry" in n: _collect(n["on_max_retry"], vis)
    _collect(cfg["start_node"], reachable)

    for node_name in node_map:
        if node_name not in reachable:
            n = node_map[node_name]
            icon, color = _NODE_STYLE.get(n["type"], ("?", "white"))
            tree.add(f"{icon} [{color}]{node_name}[/]  [dim]{n['type']}  (unreachable)[/]")

    console.print(tree)

    # ── State schema ──────────────────────────────────────────────────────────
    user_state = {k: v for k, v in cfg["state"].items() if not k.startswith("_") and k not in
                  ("user_message", "user_language", "output", "error", "messages")}
    if user_state:
        console.print("\n[bold]Custom State Fields[/]")
        for field, ftype in user_state.items():
            console.print(f"  [cyan]{field}[/]  [dim]{ftype}[/]")


# ══════════════════════════════════════════════════════════════════════════════
# flowgraph validate [name]
# ══════════════════════════════════════════════════════════════════════════════

@app.command()
def validate(
    name: str = typer.Argument(None, help="Workflow name (omit to validate all)"),
):
    """Validate workflow YAML files — syntax, node types, routing."""
    from flowgraph_ai.engine.workflow_loader import WorkflowLoader
    loader = WorkflowLoader()

    names = [name] if name else sorted(loader.list_workflows())
    if not names:
        console.print("[yellow]No workflows found.[/]")
        return

    errors = 0
    for n in names:
        try:
            loader.load(n)
            _ok(n)
        except Exception as e:
            _fail(f"{n} — {e}")
            errors += 1

    console.print()
    if errors:
        console.print(f"[red]{errors} workflow(s) failed validation[/]")
        raise typer.Exit(1)
    else:
        console.print(f"[green]All {len(names)} workflow(s) are valid[/]")


# ══════════════════════════════════════════════════════════════════════════════
# flowgraph new <name>
# ══════════════════════════════════════════════════════════════════════════════

@app.command("new")
def new_workflow(
    name: str = typer.Argument(..., help="Workflow name (snake_case, e.g. ticket_lookup)"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompts"),
):
    """Scaffold a new workflow YAML interactively."""
    name = name.lower().replace("-", "_").replace(" ", "_")
    dest = os.path.join(_workflows_dir(), f"{name}.yaml")

    if os.path.exists(dest) and not yes:
        if not Confirm.ask(f"[yellow]{dest} already exists. Overwrite?[/]"):
            raise typer.Abort()

    console.print()
    console.print(Panel(
        f"[bold cyan]New workflow:[/] {name}\n"
        f"[dim]Answer the prompts below. Press Enter to accept defaults.[/]",
        box=box.ROUNDED,
    ))

    description = Prompt.ask(
        "\n[bold]What does this workflow handle?[/] (used by intent classifier)",
        default=f"{name.replace('_', ' ').title()} requests",
    )

    # Choose a template
    console.print("\n[bold]Choose a starting template:[/]")
    console.print("  [cyan]1[/]  Simple Q&A          (custom_action → response)")
    console.print("  [cyan]2[/]  Single data collect  (data_collector → custom_action → response)")
    console.print("  [cyan]3[/]  Multi-step form      (3× data_collector → custom_action → response)")
    console.print("  [cyan]4[/]  Blank                (response only)")

    choice = Prompt.ask("Template", choices=["1", "2", "3", "4"], default="1")

    templates = {
        "1": _tpl_qa(name, description),
        "2": _tpl_single(name, description),
        "3": _tpl_form(name, description),
        "4": _tpl_blank(name, description),
    }
    content = templates[choice]

    os.makedirs(_workflows_dir(), exist_ok=True)
    with open(dest, "w") as f:
        f.write(content)

    console.print()
    _ok(f"Created [cyan]{dest}[/]")
    console.print()
    console.print(Syntax(content, "yaml", theme="monokai", line_numbers=True))
    console.print()
    console.print(f"  Next: [cyan]flowgraph show {name}[/]  ·  [cyan]flowgraph validate {name}[/]")


# ══════════════════════════════════════════════════════════════════════════════
# flowgraph run <name>
# ══════════════════════════════════════════════════════════════════════════════

@app.command()
def run(
    name: str = typer.Argument(..., help="Workflow name to chat with"),
    thread_id: str = typer.Option(None, "--thread", "-t", help="Resume an existing thread ID"),
):
    """Run a workflow interactively in the terminal (LLM required)."""
    from flowgraph_ai.engine.workflow_loader import WorkflowLoader
    from flowgraph_ai.engine.graph_builder import GraphBuilder
    from langgraph.types import Command

    cfg       = _load_cfg()
    loader    = WorkflowLoader()
    available = loader.list_workflows()

    if name not in available:
        _fail(f"Workflow '{name}' not found. Available: {', '.join(available)}")
        raise typer.Exit(1)

    from flowgraph_ai.llm.provider import get_llm
    import flowgraph_ai.storage.checkpointer as ckpt_module
    ckpt_module.reset()

    try:
        llm         = get_llm(cfg)
        checkpointer = ckpt_module.get_checkpointer(cfg)
    except Exception as e:
        _fail(f"Setup failed: {e}")
        raise typer.Exit(1)

    wf_config = loader.load(name)
    builder   = GraphBuilder(default_llm=llm, app_config=cfg)
    compiled  = builder.build(wf_config, checkpointer=checkpointer)

    tid       = thread_id or f"{name}:{uuid.uuid4().hex}"
    run_cfg   = {"configurable": {"thread_id": tid}}
    first_msg = True

    console.print()
    console.print(Panel(
        f"[bold cyan]{name}[/]  •  thread [dim]{tid}[/]\n"
        f"[dim]Type your message and press Enter. Ctrl+C to exit.[/]",
        box=box.ROUNDED,
    ))
    console.print()

    while True:
        try:
            user_input = Prompt.ask("[bold green]You[/]")
        except (KeyboardInterrupt, EOFError):
            console.print("\n[dim]Session ended.[/]")
            console.print(f"  Resume with: [cyan]flowgraph run {name} --thread {tid}[/]")
            break

        if not user_input.strip():
            continue

        try:
            if first_msg:
                initial_field = wf_config.get("initial_input_field", "user_message")
                payload = {"user_message": user_input, initial_field: user_input}
                first_msg = False
            else:
                payload = Command(resume=user_input)

            with Progress(SpinnerColumn(), TextColumn("Thinking…"), transient=True, console=console) as p:
                p.add_task("")
                compiled.invoke(payload, run_cfg)

            state = compiled.get_state(run_cfg)

            # Check for interrupt (waiting for more input)
            interrupted = False
            for task in state.tasks:
                if getattr(task, "interrupts", None):
                    q = task.interrupts[0].value
                    question = q.get("question", str(q)) if isinstance(q, dict) else str(q)
                    console.print(f"[bold blue]Bot[/]  {question}")
                    interrupted = True
                    break

            if not interrupted:
                values = state.values
                if values.get("error"):
                    console.print(f"[bold red]Bot[/]  {values['error']}")
                else:
                    output = values.get("output", "(workflow completed)")
                    console.print(f"[bold blue]Bot[/]  {output}")
                console.print(f"\n[dim]Workflow completed.[/]")
                break

        except Exception as e:
            console.print(f"[red]Error: {e}[/]")
            break


# ══════════════════════════════════════════════════════════════════════════════
# flowgraph serve
# ══════════════════════════════════════════════════════════════════════════════

@app.command()
def serve(
    host:   str = typer.Option("0.0.0.0", "--host", "-H"),
    port:   int = typer.Option(8000,      "--port", "-p"),
    reload: bool = typer.Option(False,    "--reload", "-r", help="Auto-reload on file changes"),
    workers: int = typer.Option(1,        "--workers", "-w", help="Number of worker processes"),
):
    """Start the FlowGraph-AI API server."""
    import subprocess

    cmd = [
        sys.executable, "-m", "uvicorn",
        "flowgraph_ai.api.server:app",
        "--host", host,
        "--port", str(port),
        "--workers", str(workers),
    ]
    if reload:
        cmd.append("--reload")

    console.print()
    console.print(Panel(
        f"[bold cyan]FlowGraph-AI API Server[/]\n\n"
        f"  Listening on  [green]http://{host}:{port}[/]\n"
        f"  Docs          [green]http://{host}:{port}/docs[/]\n"
        f"  Health        [green]http://{host}:{port}/health[/]\n"
        f"  Workflows     [green]http://{host}:{port}/workflows[/]\n\n"
        f"  Press [bold]Ctrl+C[/] to stop",
        box=box.ROUNDED,
    ))
    console.print()

    subprocess.run(cmd, cwd=_ROOT)


# ══════════════════════════════════════════════════════════════════════════════
# flowgraph stack up / down / status / logs / configure
# ══════════════════════════════════════════════════════════════════════════════

_STACK_URLS = {
    "Langfuse UI":  "http://localhost:3000",
    "Jaeger UI":    "http://localhost:16686",
    "OTLP gRPC":    "http://localhost:4317   (app → Jaeger)",
    "PostgreSQL":   "localhost:5433          (Langfuse DB only)",
}


@stack_app.command("up")
def stack_up(
    detach: bool = typer.Option(True, "--detach/--no-detach", "-d/-D",
                                help="Run in background (default: yes)"),
    wait:   bool = typer.Option(True,  "--wait/--no-wait",
                                help="Wait for services to become healthy"),
):
    """
    Start the observability stack: PostgreSQL + Langfuse + Jaeger via Docker.

    After first run, visit http://localhost:3000 to create your Langfuse
    account, then run: [cyan]flowgraph stack configure[/]
    """
    import subprocess

    if not _docker_available():
        _fail("Docker is not running. Please start Docker Desktop and retry.")
        raise typer.Exit(1)

    console.print()
    console.print(Panel(
        "[bold cyan]Starting Observability Stack[/]\n\n"
        "  [dim]Services: PostgreSQL · Langfuse · Jaeger[/]",
        box=box.ROUNDED,
    ))
    console.print()

    cmd = _compose_cmd("up", "--build")
    if detach:
        cmd.append("-d")
    if wait:
        cmd.append("--wait")

    with Progress(SpinnerColumn(), TextColumn("{task.description}"), transient=True, console=console) as p:
        p.add_task("Pulling images and starting services…")
        result = subprocess.run(cmd, cwd=_docker_dir(), capture_output=not detach)

    if result.returncode != 0 if detach else False:
        _fail("docker compose up failed. Run: [cyan]flowgraph stack logs[/] to debug.")
        raise typer.Exit(1)

    console.print()
    _ok("Stack is running")
    console.print()

    table = Table(box=box.SIMPLE, show_header=False, padding=(0, 2))
    table.add_column("Service", style="bold")
    table.add_column("URL", style="cyan")
    for svc, url in _STACK_URLS.items():
        table.add_row(svc, url)
    console.print(table)

    # ── Auto-detect if Langfuse keys already configured ───────────────────────
    cfg = _load_cfg()
    lf_cfg = cfg.get("observability", {}).get("langfuse", {})
    keys_configured = bool(lf_cfg.get("public_key") and lf_cfg.get("secret_key"))

    if keys_configured:
        console.print()
        _ok("Langfuse keys already configured — observability is ready!")
        console.print("  Start the API with: [cyan]flowgraph serve[/]  or  [cyan]flowgraph dev[/]")
    else:
        # ── Guide developer through Langfuse setup inline ─────────────────────
        console.print()
        console.print(Panel(
            "[bold yellow]Langfuse Setup Required[/]\n\n"
            "  Langfuse is running but needs API keys before it can track LLM calls.\n"
            "  This is a one-time setup — takes about 2 minutes.",
            box=box.ROUNDED,
        ))
        console.print()
        console.print("  [bold]Step 1:[/]  Open [cyan]http://localhost:3000[/] in your browser")
        console.print("  [bold]Step 2:[/]  Click [bold]Sign Up[/] → create your account")
        console.print("  [bold]Step 3:[/]  Create a new project (e.g. [italic]flowgraph-dev[/])")
        console.print("  [bold]Step 4:[/]  Go to [bold]Settings → API Keys → Create new key[/]")
        console.print("  [bold]Step 5:[/]  Copy your [bold]Public Key[/] (pk-lf-...) and [bold]Secret Key[/] (sk-lf-...)")
        console.print()

        do_setup = Confirm.ask(
            "  Have you created your Langfuse API keys and are ready to enter them?",
            default=False,
        )

        if do_setup:
            console.print()
            public_key = Prompt.ask("  [bold]Public Key[/]  (pk-lf-...)")
            secret_key = Prompt.ask("  [bold]Secret Key[/]  (sk-lf-...)", password=True)
            host       = Prompt.ask("  [bold]Host[/]", default="http://localhost:3000")

            if not public_key.startswith("pk-") or not secret_key.startswith("sk-"):
                console.print("  [yellow]⚠  Keys don't match expected format — saved anyway.[/]")

            obs = cfg.setdefault("observability", {})
            lf  = obs.setdefault("langfuse", {})
            lf["enabled"]    = True
            lf["host"]       = host
            lf["public_key"] = public_key
            lf["secret_key"] = secret_key
            obs.setdefault("tracing", {})["enabled"] = True
            _save_cfg(cfg)

            console.print()
            _ok("Langfuse keys saved")
            _ok("Langfuse tracing  → [cyan]enabled[/]")
            _ok("Jaeger tracing    → [cyan]enabled[/]  (http://localhost:16686)")
            console.print()
            console.print("  Start the API with: [cyan]flowgraph serve[/]  or  [cyan]flowgraph dev[/]")
        else:
            console.print()
            console.print("  No problem! When you're ready, run: [cyan]flowgraph stack configure[/]")
            console.print("  Or skip Langfuse — Jaeger tracing still works without API keys.")
    console.print()


@stack_app.command("down")
def stack_down(
    volumes: bool = typer.Option(False, "--volumes", "-v", help="Also delete persisted data volumes"),
):
    """Stop the observability stack."""
    import subprocess

    cmd = _compose_cmd("down")
    if volumes:
        cmd.append("-v")
        console.print("[yellow]Warning: This will delete all Langfuse data.[/]")
        if not Confirm.ask("Continue?"):
            raise typer.Abort()

    with Progress(SpinnerColumn(), TextColumn("Stopping services…"), transient=True, console=console) as p:
        p.add_task("")
        subprocess.run(cmd, cwd=_docker_dir(), capture_output=True)

    _ok("Stack stopped")


@stack_app.command("status")
def stack_status():
    """Show running status of all observability stack services."""
    import subprocess

    if not _docker_available():
        _fail("Docker is not running.")
        raise typer.Exit(1)

    result = subprocess.run(
        _compose_cmd("ps", "--format", "json"),
        cwd=_docker_dir(),
        capture_output=True,
        text=True,
    )

    console.print()
    console.print("[bold]Observability Stack Status[/]")
    console.print()

    # Parse and display service status
    import json
    services = []
    for line in result.stdout.strip().splitlines():
        try:
            services.append(json.loads(line))
        except json.JSONDecodeError:
            pass

    if not services:
        console.print("[yellow]No stack services are running.[/]")
        console.print("  Start with: [cyan]flowgraph stack up[/]")
        return

    table = Table(box=box.ROUNDED, show_header=True, header_style="bold cyan")
    table.add_column("Service",  min_width=20)
    table.add_column("Status",   min_width=12)
    table.add_column("Health",   min_width=12)
    table.add_column("Ports")

    for svc in services:
        name   = svc.get("Name", svc.get("Service", "?"))
        state  = svc.get("State", "?")
        health = svc.get("Health", "")
        ports  = svc.get("Publishers", [])

        state_str  = f"[green]{state}[/]"  if state == "running"  else f"[red]{state}[/]"
        health_str = f"[green]{health}[/]" if health == "healthy"  else (
                     f"[yellow]{health}[/]" if health else "[dim]—[/]")

        port_strs = ", ".join(
            f"{p.get('PublishedPort', '?')}→{p.get('TargetPort', '?')}"
            for p in (ports if isinstance(ports, list) else [])
            if p.get("PublishedPort")
        ) or "—"

        table.add_row(name, state_str, health_str, port_strs)

    console.print(table)
    console.print()

    # Check Langfuse + Jaeger connectivity
    import urllib.request
    for name, url, path in [
        ("Langfuse",  "http://localhost:3000",  "/api/public/health"),
        ("Jaeger UI", "http://localhost:16686",  "/"),
    ]:
        try:
            urllib.request.urlopen(f"{url}{path}", timeout=2)
            _ok(f"{name} reachable at [cyan]{url}[/]")
        except Exception:
            console.print(f"  [yellow]⚠[/]  {name} not yet reachable at [dim]{url}[/]")


@stack_app.command("logs")
def stack_logs(
    service: str = typer.Argument(None, help="Service: langfuse | jaeger | postgres (omit for all)"),
    follow:  bool = typer.Option(False, "--follow", "-f", help="Follow log output"),
    tail:    int  = typer.Option(50,   "--tail",   "-n", help="Number of lines to show"),
):
    """Tail logs from observability stack services."""
    import subprocess

    cmd = _compose_cmd("logs", f"--tail={tail}")
    if follow:
        cmd.append("--follow")
    if service:
        cmd.append(service)

    subprocess.run(cmd, cwd=_docker_dir())


@stack_app.command("configure")
def stack_configure():
    """
    Save Langfuse API keys to config.yaml and enable observability.

    Get keys from: http://localhost:3000 → Settings → API Keys
    """
    console.print()
    console.print(Panel(
        "[bold cyan]Configure Langfuse Observability[/]\n\n"
        "  Get keys from [cyan]http://localhost:3000[/]\n"
        "  → Sign in → Settings → API Keys → Create new key",
        box=box.ROUNDED,
    ))
    console.print()

    public_key = Prompt.ask("[bold]Langfuse Public Key[/]  (pk-lf-...)")
    secret_key = Prompt.ask("[bold]Langfuse Secret Key[/]  (sk-lf-...)", password=True)
    host       = Prompt.ask("[bold]Langfuse Host[/]", default="http://localhost:3000")

    if not public_key.startswith("pk-") or not secret_key.startswith("sk-"):
        console.print("[yellow]⚠  Keys don't match expected format (pk-... / sk-...). Saved anyway.[/]")

    cfg = _load_cfg()
    obs = cfg.setdefault("observability", {})
    lf  = obs.setdefault("langfuse", {})
    lf["enabled"]    = True
    lf["host"]       = host
    lf["public_key"] = public_key
    lf["secret_key"] = secret_key

    tr = obs.setdefault("tracing", {})
    tr["enabled"] = True

    _save_cfg(cfg)

    console.print()
    _ok("Langfuse keys saved to config.yaml")
    _ok("Langfuse tracing:  [cyan]enabled[/]")
    _ok("Jaeger tracing:    [cyan]enabled[/]  (endpoint: http://localhost:4317)")
    console.print()
    console.print("  Run [cyan]flowgraph serve[/] or [cyan]flowgraph dev[/] to start with full observability.")


# ══════════════════════════════════════════════════════════════════════════════
# flowgraph dev  — one-command full dev start
# ══════════════════════════════════════════════════════════════════════════════

@app.command()
def dev(
    host:       str  = typer.Option("0.0.0.0", "--host",     "-H"),
    port:       int  = typer.Option(8000,      "--port",     "-p"),
    reload:     bool = typer.Option(True,      "--reload/--no-reload",   help="Auto-reload on file changes"),
    no_stack:   bool = typer.Option(False,     "--no-stack",             help="Skip starting the observability stack"),
):
    """
    [bold green]Full dev mode:[/] Start observability stack + API server in one command.

    Starts:
      • PostgreSQL (Langfuse DB)  — port 5433
      • Langfuse UI               — http://localhost:3000
      • Jaeger UI                 — http://localhost:16686
      • FlowGraph API             — http://localhost:<port>
    """
    import subprocess

    console.print()
    console.print(Panel(
        "[bold cyan]FlowGraph-AI — Dev Mode[/]\n\n"
        "  [dim]Starting observability stack + API server[/]",
        box=box.ROUNDED,
    ))

    # ── 1. Start observability stack ──────────────────────────────────────────
    if not no_stack:
        if not _docker_available():
            console.print()
            console.print("[yellow]⚠  Docker not running — skipping observability stack.[/]")
            console.print("   Start Docker Desktop, then run [cyan]flowgraph stack up[/].")
        else:
            console.print()
            console.print("[bold]Step 1/2[/]  Starting observability stack…")
            result = subprocess.run(
                _compose_cmd("up", "-d", "--wait"),
                cwd=_docker_dir(),
                capture_output=True,
            )
            if result.returncode == 0:
                _ok("Stack running")
            else:
                console.print("[yellow]⚠  Stack may not be fully ready. Check: [cyan]flowgraph stack status[/]")

    # ── 2. Show all service URLs ───────────────────────────────────────────────
    cfg = _load_cfg()
    lf_enabled  = cfg.get("observability", {}).get("langfuse", {}).get("enabled", False)
    otel_enabled = cfg.get("observability", {}).get("tracing", {}).get("enabled", False)

    console.print()
    console.print("[bold]Step 2/2[/]  Starting API server…")
    console.print()

    table = Table(box=box.SIMPLE, show_header=False, padding=(0, 2))
    table.add_column("Service", style="bold")
    table.add_column("URL / Status", style="cyan")
    table.add_row("API Server",  f"http://{host if host != '0.0.0.0' else 'localhost'}:{port}")
    table.add_row("API Docs",    f"http://{'localhost'}:{port}/docs")
    if not no_stack:
        table.add_row("Langfuse UI",  f"http://localhost:3000   [{'[green]enabled[/]' if lf_enabled else '[yellow]needs configure[/]'}]")
        table.add_row("Jaeger UI",    f"http://localhost:16686  [{'[green]enabled[/]' if otel_enabled else '[yellow]needs configure[/]'}]")
    console.print(table)

    if not lf_enabled and not no_stack:
        console.print()
        console.print("  [yellow]Tip:[/] Langfuse not configured. Run [cyan]flowgraph stack configure[/] after first login.")

    console.print()
    console.print("  Press [bold]Ctrl+C[/] to stop\n")

    # ── 3. Start API server ────────────────────────────────────────────────────
    cmd = [sys.executable, "-m", "uvicorn", "api.server:app",
           "--host", host, "--port", str(port)]
    if reload:
        cmd.append("--reload")

    subprocess.run(cmd, cwd=_ROOT)


# ══════════════════════════════════════════════════════════════════════════════
# flowgraph test  — run unit and integration tests
# ══════════════════════════════════════════════════════════════════════════════

@app.command("test")
def run_tests(
    integration: bool = typer.Option(False, "--integration", "-i",  help="Run integration tests (requires DB + LLM)"),
    unit:        bool = typer.Option(False, "--unit",        "-u",  help="Run unit tests only"),
    coverage:    bool = typer.Option(False, "--coverage",    "-c",  help="Generate coverage report"),
    verbose:     bool = typer.Option(False, "--verbose",     "-v",  help="Verbose pytest output"),
    path:        str  = typer.Option("",   "--path",        "-p",  help="Run only tests at this path or pattern"),
):
    """
    [bold green]Run tests[/] — unit tests, integration tests, or all.

    Examples:

      [cyan]flowgraph test[/]                        Run all unit tests
      [cyan]flowgraph test --unit[/]                 Unit tests only
      [cyan]flowgraph test --integration[/]          Integration tests (needs DB + LLM)
      [cyan]flowgraph test --coverage[/]             Unit tests + coverage report
      [cyan]flowgraph test -p tests/unit/test_intent.py[/]   Run a specific test file
      [cyan]flowgraph test -v[/]                     Verbose output
    """
    import subprocess

    console.print()

    # ── Build pytest command ───────────────────────────────────────────────────
    cmd = [sys.executable, "-m", "pytest"]

    if verbose:
        cmd.append("-v")

    if coverage:
        cmd += ["--cov=.", "--cov-report=term-missing", "--cov-omit=.venv/*,tests/*"]

    if path:
        cmd.append(path)
    elif unit and not integration:
        cmd.append("tests/unit/")
    elif integration and not unit:
        cmd.append("tests/integration/")
    else:
        # default: unit tests only (integration tests are opt-in since they need DB + LLM)
        cmd.append("tests/unit/")

    # ── Check pytest is installed ──────────────────────────────────────────────
    check = subprocess.run([sys.executable, "-m", "pytest", "--version"],
                           capture_output=True, cwd=_ROOT)
    if check.returncode != 0:
        console.print("[red]✗  pytest not installed.[/]")
        console.print("   Fix: [cyan]uv add --dev pytest pytest-cov[/]")
        raise typer.Exit(1)

    # ── Run ────────────────────────────────────────────────────────────────────
    test_type = "integration" if (integration and not unit) else "unit" if (unit and not integration) else "unit"
    label = f"[bold]Running {test_type} tests…[/]"
    if path:
        label = f"[bold]Running tests at {path}…[/]"

    console.print(label)
    console.print(f"  [dim]Command: {' '.join(cmd)}[/]\n")

    result = subprocess.run(cmd, cwd=_ROOT)

    console.print()
    if result.returncode == 0:
        _ok("All tests passed")
    else:
        console.print("[red]✗  Some tests failed.[/]")
        console.print("   Check output above. Run with [cyan]-v[/] for verbose details.")
        raise typer.Exit(result.returncode)


# ══════════════════════════════════════════════════════════════════════════════
# Workflow YAML templates
# ══════════════════════════════════════════════════════════════════════════════

def _tpl_blank(name: str, desc: str) -> str:
    return f"""\
workflow: {name}
description: "{desc}"

# No custom state needed — user_message, output, error, user_language,
# messages are auto-injected by the framework.

start_node: respond

nodes:

  respond:
    type: response
    template: >
      Hello! You said: {{state.user_message}}
"""


def _tpl_qa(name: str, desc: str) -> str:
    module = name
    return f"""\
workflow: {name}
description: "{desc}"

# Custom state (add your own fields as needed)
# state:
#   my_field: str

start_node: answer

nodes:

  # Call your Python action to handle the request
  answer:
    type: custom_action
    method: "actions.{module}.answer"
    result_field: action_result
    routes:
      - value: "done"
        next: respond
      - default: respond

  # Send the final response (guardrails applied automatically)
  respond:
    type: response
    output_field: output
    error_field: error
"""


def _tpl_single(name: str, desc: str) -> str:
    module = name
    field  = "user_input"
    return f"""\
workflow: {name}
description: "{desc}"

state:
  {field}: str
  action_result: str

start_node: collect_{field}

nodes:

  # Step 1: Collect the required value from the user
  collect_{field}:
    type: data_collector
    role: "You are a helpful assistant."
    initial_message: "Please provide the required information."
    field: {field}
    description: "The value to collect"
    max_retry: 3
    next: process
    on_max_retry: error_response
    # validation:
    #   method: not_empty
    #   error_message: "This field cannot be empty."

  # Step 2: Process the collected value
  process:
    type: custom_action
    method: "actions.{module}.process"
    result_field: action_result
    routes:
      - value: "done"
        next: success_response
      - default: error_response

  # End nodes
  success_response:
    type: response
    template: >
      Done! You provided: {{state.{field}}}

  error_response:
    type: response
    output_field: output
    error_field: error
"""


def _tpl_form(name: str, desc: str) -> str:
    module = name
    return f"""\
workflow: {name}
description: "{desc}"

state:
  full_name:    str
  email:        str
  description:  str
  action_result: str

start_node: collect_name

nodes:

  # Step 1: Collect name
  collect_name:
    type: data_collector
    role: "You are a helpful assistant."
    initial_message: "What is your full name?"
    field: full_name
    description: "User's full name"
    max_retry: 3
    next: collect_email
    on_max_retry: error_response
    validation:
      method: not_empty

  # Step 2: Collect email
  collect_email:
    type: data_collector
    role: "You are a helpful assistant."
    initial_message: "What is your email address?"
    field: email
    description: "Email address"
    max_retry: 3
    next: collect_description
    on_max_retry: error_response
    validation:
      method: regex
      pattern: "^[\\\\w.-]+@[\\\\w.-]+\\\\.\\\\w+$"
      error_message: "Please enter a valid email (e.g. user@example.com)."

  # Step 3: Collect description
  collect_description:
    type: data_collector
    role: "You are a helpful assistant."
    initial_message: "Please describe what you need help with."
    field: description
    description: "Brief description"
    max_retry: 3
    next: submit
    on_max_retry: error_response
    validation:
      method: length
      min: 10
      error_message: "Please provide more detail (at least 10 characters)."

  # Step 4: Submit
  submit:
    type: custom_action
    method: "actions.{module}.submit"
    result_field: action_result
    routes:
      - value: "success"
        next: success_response
      - default: error_response

  # End nodes
  success_response:
    type: response
    template: >
      Thank you, {{state.full_name}}! Your request has been submitted.
      We'll contact you at {{state.email}}.

  error_response:
    type: response
    output_field: output
    error_field: error
"""


# ── Utility ───────────────────────────────────────────────────────────────────

def _redact(conn_str: str) -> str:
    import re
    return re.sub(r"(?<=://).+?(?=@)", "****:****", conn_str)


# ══════════════════════════════════════════════════════════════════════════════
# flowgraph init  — scaffold a new project directory
# ══════════════════════════════════════════════════════════════════════════════

_INIT_WORKFLOW_ORDER_YAML = """\
workflow: order_tracking
description: "Track an order status, check order updates, order delivery questions"

# user_message, output, error, messages, user_language auto-injected.
state:
  order_id: str
  order_date: str
  order_status: str

start_node: collect_order_info

nodes:

  collect_order_info:
    type: data_collector
    role: "You are a helpful order support agent."
    initial_message: "I'll help you track your order. Please share your order ID and the order date."
    max_retry: 3
    next: lookup_order
    on_max_retry: error_response
    allow_intent_escape: true
    # PRE-EXTRACTION: if user already says "my order ORD-123 from yesterday",
    # both fields are extracted immediately — no extra questions asked.
    fields:
      - field: order_id
        description: "Order ID (e.g. ORD-12345 or any order number)"
      - field: order_date
        description: "Order date or approximate date (e.g. yesterday, 10th Dec)"

  lookup_order:
    type: custom_action
    method: "actions.order_actions.lookup_order"
    next: success_response
    routes:
      - value: "error_response"
        next: error_response

  success_response:
    type: response
    output_field: output

  error_response:
    type: response
    error_field: error
    output_field: output
"""

_INIT_WORKFLOW_FAQ_YAML = """\
workflow: faq
description: "General questions, FAQ, help, how does it work, pricing, shipping"

start_node: answer_question

nodes:

  answer_question:
    type: data_collector
    role: "You are a helpful FAQ assistant for our online store."
    initial_message: "I'm happy to help! What would you like to know?"
    field: user_question
    description: "The user's question or topic they want to know about"
    max_retry: 3
    next: respond_faq
    allow_intent_escape: false

  respond_faq:
    type: custom_action
    method: "actions.faq_actions.answer_faq"
    next: final

  final:
    type: response
    output_field: output
"""

_INIT_ACTIONS_ORDER_PY = '''\
"""
Order tracking actions — example custom actions for FlowGraph-AI.

Replace the mock logic below with real database queries or API calls.
"""


def lookup_order(state: dict) -> str:
    """Look up an order by ID and date. Updates state with order_status."""
    order_id = state.get("order_id", "")
    order_date = state.get("order_date", "")

    # ── Replace this with your real order lookup logic ────────────────────────
    # e.g.: order = db.query("SELECT * FROM orders WHERE id = %s", order_id)
    # ─────────────────────────────────────────────────────────────────────────
    if not order_id:
        state["error"] = "I couldn\'t find an order ID in your message. Please provide your order number."
        return "error_response"

    # Mock response — replace with real data
    mock_statuses = {
        "ORD-001": "Processing — will ship within 24 hours",
        "ORD-002": "Shipped — estimated delivery: Dec 15",
        "ORD-003": "Delivered — delivered on Dec 10",
    }
    status = mock_statuses.get(order_id.upper(), "Processing — we\'ll update you soon")

    state["order_status"] = status
    state["output"] = (
        f"Here\'s your order update:\\n\\n"
        f"  Order ID : {order_id}\\n"
        f"  Date     : {order_date}\\n"
        f"  Status   : {status}\\n\\n"
        f"Is there anything else I can help you with?"
    )
    return "success_response"
'''

_INIT_ACTIONS_FAQ_PY = '''\
"""
FAQ actions — example custom actions for FlowGraph-AI.

Replace the knowledge base dict with your own content or a DB/API lookup.
"""

_FAQ_KNOWLEDGE_BASE = """
We are an online store selling electronics and accessories.

Shipping: Free shipping on orders over $50. Standard delivery 3-5 business days.
Returns: 30-day no-questions-asked returns. Refund issued within 5 business days.
Payment: We accept Visa, MasterCard, PayPal, and Apple Pay.
Contact: support@example.com | 1-800-EXAMPLE
"""


def answer_faq(state: dict) -> str:
    """Answer a general FAQ question using a knowledge base and LLM."""
    from flowgraph_ai.config import load_config
    from flowgraph_ai.llm.provider import get_llm

    question = state.get("user_question", state.get("user_message", ""))
    if not question:
        state["output"] = "I didn\'t catch your question. Could you please ask again?"
        return "final"

    try:
        cfg = load_config()
        llm = get_llm(cfg)
        prompt = (
            f"You are a helpful customer support agent.\\n\\n"
            f"Knowledge base:\\n{_FAQ_KNOWLEDGE_BASE}\\n\\n"
            f"Customer question: {question}\\n\\n"
            f"Answer the question based on the knowledge base above. "
            f"If you don\'t know, say so politely and offer to connect them to a human.\\n"
            f"Return ONLY the answer text."
        )
        state["output"] = llm.invoke(prompt).content.strip()
    except Exception as e:
        state["output"] = f"Sorry, I couldn\'t process your question right now. Please email support@example.com."

    return "final"
'''

_INIT_CONFIG_YAML = """\
# FlowGraph-AI config.yaml
# ─────────────────────────────────────────────────────────────────────────────
# Edit this file to configure your LLM provider, database, and guardrails.
# Run `flowgraph health` after changes to verify everything is working.

app:
  name: "My FlowGraph App"
  version: "0.1.0"

# ─── LLM Provider ────────────────────────────────────────────────────────────
# Choose one: ollama | claude | openai | openrouter | lmstudio
llm:
  provider: "ollama"                        # Change to "claude" for Claude, etc.
  ollama_model: "llama3.1:8b"              # Ollama: any model you have pulled
  ollama_base_url: "http://localhost:11434"

  # claude_model: "claude-sonnet-4-20250514"  # Claude: set ANTHROPIC_API_KEY in .env
  # openai_model: "gpt-4o-mini"               # OpenAI: set OPENAI_API_KEY in .env
  temperature: 0.7

# ─── Checkpoint / State Persistence ──────────────────────────────────────────
checkpoint:
  connection_string: ""                     # Empty = in-memory (dev)
  # connection_string: "./flowgraph.db"     # SQLite
  # connection_string: "postgresql://user:pass@localhost:5432/mydb"  # Postgres

# ─── Intent Classifier ────────────────────────────────────────────────────────
intent:
  fallback_workflow: "faq"

# ─── Guardrails ───────────────────────────────────────────────────────────────
guardrails:
  enabled: false                            # Set true to enable safety post-processing
  tone: "warm and professional"

# ─── Language Detection ───────────────────────────────────────────────────────
language_detection:
  enabled: true

# ─── Logging ──────────────────────────────────────────────────────────────────
logging:
  level: "WARNING"                          # Change to "INFO" or "DEBUG" for more output
  format: "text"

# ─── Observability (optional) ─────────────────────────────────────────────────
observability:
  langfuse:
    enabled: false
  tracing:
    enabled: false
"""

_INIT_ENV_EXAMPLE = """\
# Copy this file to .env and fill in your API keys.
# The .env file is loaded automatically at startup.

# Anthropic Claude
ANTHROPIC_API_KEY=sk-ant-...

# OpenAI
OPENAI_API_KEY=sk-...

# OpenRouter
OPENROUTER_API_KEY=sk-or-...
"""

_INIT_GITIGNORE = """\
.env
*.db
__pycache__/
*.pyc
.venv/
dist/
"""

_INIT_TOOL_EXAMPLE_PY = '''\
"""
Example tools for data_collector nodes.

These functions can be called by the LLM during field extraction when
the user\'s question requires live data — e.g. system info, DB lookups.

YAML usage:
  my_node:
    type: data_collector
    tools:
      - method: "actions.example_tools.get_system_info"
        name: "get_system_info"
        description: "Get current system CPU and memory usage"
"""

import os
import platform


def get_system_info() -> dict:
    """Get basic system information (CPU, memory, OS)."""
    try:
        import psutil
        return {
            "cpu_percent": psutil.cpu_percent(interval=0.5),
            "memory_percent": psutil.virtual_memory().percent,
            "os": platform.system(),
            "hostname": platform.node(),
        }
    except ImportError:
        return {
            "os": platform.system(),
            "hostname": platform.node(),
            "note": "Install psutil for CPU/memory data: pip install psutil",
        }


def get_current_time() -> str:
    """Get the current date and time."""
    from datetime import datetime
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")
'''


_VALID_PROVIDERS = ("ollama", "claude", "openai", "openrouter", "lmstudio")


@app.command("init")
def init_project(
    project_name: str = typer.Argument(..., help="Name for the new FlowGraph-AI project"),
    force: bool = typer.Option(False, "--force", "-f", help="Overwrite existing directory"),
    provider: str = typer.Option("ollama", "--provider", "-p",
                                 help=f"LLM provider: {', '.join(_VALID_PROVIDERS)}"),
):
    """Scaffold a complete working FlowGraph-AI demo project."""
    import os
    import sys
    from pathlib import Path

    if provider not in _VALID_PROVIDERS:
        console.print(f"[red]Invalid provider '{provider}'. Choose from: {', '.join(_VALID_PROVIDERS)}[/red]")
        raise typer.Exit(1)

    project_dir = Path(project_name)
    dir_is_empty = project_dir.exists() and not any(project_dir.iterdir())
    if project_dir.exists() and not force and not dir_is_empty:
        console.print(f"[red]Directory '{project_name}' already exists and is not empty. Use --force to overwrite.[/red]")
        raise typer.Exit(1)

    console.print(f"\n[bold cyan]⚡ FlowGraph-AI Init[/bold cyan]")
    console.print(f"Creating project: [bold]{project_name}[/bold]\n")

    # Create directory structure
    dirs = [
        project_dir / "workflows",
        project_dir / "actions",
        project_dir / "validations",
        project_dir / "tests",
    ]
    for d in dirs:
        d.mkdir(parents=True, exist_ok=True)

    # Write all files
    _write_init_files(project_dir, provider=provider)

    console.print("\n[bold green]✅ Project created![/bold green]\n")
    console.print(Panel(
        f"[bold]Next steps:[/bold]\n\n"
        f"  cd {project_name}\n"
        f"  cp .env.example .env\n"
        f"  # Edit .env with your API key, then:\n"
        f"  uv run python main.py\n\n"
        f"[dim]Or start the API server:[/dim]\n"
        f"  uv run uvicorn main:app --reload\n\n"
        f"[dim]Or run tests:[/dim]\n"
        f"  uv run pytest tests/ -v",
        title="[bold]🚀 Get Started[/bold]",
        border_style="green",
    ))


def _write_init_files(project_dir, provider: str = "ollama"):
    """Write all scaffold files for a new FlowGraph-AI project."""
    from pathlib import Path

    files = {
        # ── actions/__init__.py
        "actions/__init__.py": "",

        # ── actions/order_actions.py
        "actions/order_actions.py": '''"""Mock order tools for FlowGraph-AI demo."""
import random
from datetime import datetime, timedelta


def get_order_status(order_id: str) -> str:
    """Look up the status of an order by ID.

    Args:
        order_id: The order ID to look up (e.g. ORD-12345)

    Returns:
        A string describing the current order status.
    """
    statuses = [
        "Processing — your order is being prepared.",
        "Shipped — your order is on its way! Expected delivery in 2-3 days.",
        "Out for delivery — your order will arrive today.",
        "Delivered — your order was delivered.",
    ]
    # Deterministic based on last digit of order ID for demo stability
    try:
        idx = int(str(order_id)[-1]) % len(statuses)
    except (ValueError, IndexError):
        idx = 0
    return f"Order {order_id}: {statuses[idx]}"


def get_current_date() -> str:
    """Get the current date and time.

    Returns:
        Current date and time as a human-readable string.
    """
    return datetime.now().strftime("%A, %B %d, %Y at %I:%M %p")


def list_recent_orders(customer_id: str = "demo") -> str:
    """List recent orders for a customer (mock data).

    Args:
        customer_id: The customer identifier (optional, defaults to demo)

    Returns:
        A formatted list of recent orders.
    """
    today = datetime.now()
    orders = [
        {"id": "ORD-10001", "date": (today - timedelta(days=1)).strftime("%Y-%m-%d"), "status": "Delivered", "item": "Wireless Headphones"},
        {"id": "ORD-10002", "date": (today - timedelta(days=3)).strftime("%Y-%m-%d"), "status": "Shipped", "item": "USB-C Hub"},
        {"id": "ORD-10003", "date": today.strftime("%Y-%m-%d"), "status": "Processing", "item": "Laptop Stand"},
    ]
    lines = [f"- {o[\'id\']} ({o[\'date\']}): {o[\'item\']} — {o[\'status\']}" for o in orders]
    return "Recent orders:\\n" + "\\n".join(lines)
''',

        # ── actions/currency_tools.py
        "actions/currency_tools.py": '''"""Mock currency and financial tools for FlowGraph-AI demo."""


def get_exchange_rate(from_currency: str, to_currency: str) -> str:
    """Get the current exchange rate between two currencies (mock data).

    Args:
        from_currency: Source currency code (e.g. USD, EUR, GBP)
        to_currency: Target currency code (e.g. INR, JPY, CNY)

    Returns:
        A string describing the current exchange rate.
    """
    rates = {
        ("USD", "INR"): 83.45,
        ("EUR", "INR"): 89.12,
        ("GBP", "INR"): 105.67,
        ("USD", "EUR"): 0.92,
        ("USD", "GBP"): 0.78,
        ("USD", "JPY"): 149.5,
        ("EUR", "USD"): 1.09,
    }
    from_upper = from_currency.upper().strip()
    to_upper = to_currency.upper().strip()
    rate = rates.get((from_upper, to_upper))
    if rate:
        return f"1 {from_upper} = {rate} {to_upper} (mock rate, for demo only)"
    # Try reverse
    rev = rates.get((to_upper, from_upper))
    if rev:
        rate = round(1 / rev, 4)
        return f"1 {from_upper} = {rate} {to_upper} (mock rate, for demo only)"
    return f"Exchange rate for {from_upper}/{to_upper} not available in mock data."
''',

        # ── actions/faq_action.py
        "actions/faq_action.py": '''"""FAQ action for FlowGraph-AI demo."""


def answer_faq(question: str) -> str:
    """Answer a general FAQ question using a simple knowledge base.

    Args:
        question: The user\'s question.

    Returns:
        An answer string.
    """
    # Simple keyword-based fallback for demo (real apps use LLM)
    q_lower = question.lower()
    if "return" in q_lower or "refund" in q_lower:
        return "Our return policy allows returns within 30 days of purchase. Please contact support@example.com to initiate a return."
    if "shipping" in q_lower or "delivery" in q_lower:
        return "We offer standard shipping (5-7 days) and express shipping (1-2 days). Free shipping on orders over $50."
    if "payment" in q_lower or "pay" in q_lower:
        return "We accept Visa, Mastercard, American Express, PayPal, and bank transfers."
    if "contact" in q_lower or "support" in q_lower or "help" in q_lower:
        return "You can reach our support team at support@example.com or call 1-800-555-0100 (Mon-Fri 9am-5pm EST)."
    return "I\'m happy to help! For detailed assistance, please contact our support team at support@example.com"
''',

        # ── validations/__init__.py
        "validations/__init__.py": "",

        # ── validations/order_validators.py
        "validations/order_validators.py": '''"""Order validation functions for FlowGraph-AI demo."""
import re


def validate_order_id(value: str) -> tuple:
    """Validate that an order ID matches ORD-XXXXX format.

    Args:
        value: The order ID to validate.

    Returns:
        (is_valid, error_message) tuple.
    """
    pattern = r"^ORD-\\d{4,6}$"
    if re.match(pattern, value.strip().upper()):
        return True, ""
    return False, f"Order ID must be in format ORD-XXXXX (e.g. ORD-12345). Got: {value!r}"
''',

        # ── workflows/order_tracking.yaml
        "workflows/order_tracking.yaml": '''workflow: order_tracking
description: "Track the status of an order by order ID and date"

# Follow-up enabled: user can ask questions after the workflow ends
follow_up:
  enabled: true

# Guardrails applied to all bot messages
guardrails:
  enabled: true
  tone: "friendly and professional"

state:
  order_id:
    type: string
    required: true
  order_date:
    type: string
    required: true
  order_status:
    type: string
  user_language:
    type: string
  user_message:
    type: string
  output:
    type: string
  error:
    type: string
  messages:
    type: list

nodes:
  collect_order_info:
    type: data_collector
    role: "You are a helpful order tracking assistant."
    initial_message: "I can help you track your order! Please provide your order ID and order date."
    max_retry: 3
    next: lookup_order
    on_max_retry: error_response
    humanize: true
    allow_intent_escape: true
    hallucination_check: true

    # LLM parameter customization — use lower temperature for more precise extraction
    llm_params:
      temperature: 0.1
      max_tokens: 256

    fields:
      - field: order_id
        description: "Order ID in format ORD-XXXXX"
        validation:
          method: "validations.order_validators.validate_order_id"
      - field: order_date
        description: "Date when the order was placed (any date format)"

    # Tools available during collection
    tools:
      - method: "actions.order_tools.get_current_date"
        name: "get_current_date"
        description: "Get today\\'s date. Use this if user asks about today\\'s orders or says \\'today\\'."
      - method: "actions.order_tools.list_recent_orders"
        name: "list_recent_orders"
        description: "List recent orders for the customer. Use if user says \\'today\\'s orders\\'."

  lookup_order:
    type: custom_action
    method: "actions.order_tools.get_order_status"
    args_from_state:
      order_id: order_id
    result_field: order_status
    next: success_response
    on_error: error_response

  success_response:
    type: response
    template: |
      {{state.order_status}}

      Order ID: {{state.order_id}}
      Order Date: {{state.order_date}}

      Is there anything else you\\'d like to know about your order?

  error_response:
    type: response
    template: "I\\'m sorry, I couldn\\'t find information for your order. Please check the order ID and try again."

start: collect_order_info
''',

        # ── workflows/currency_lookup.yaml
        "workflows/currency_lookup.yaml": '''workflow: currency_lookup
description: "Look up exchange rates and currency conversions"

state:
  from_currency:
    type: string
    required: true
  to_currency:
    type: string
    required: true
  exchange_rate:
    type: string
  user_language:
    type: string
  user_message:
    type: string
  output:
    type: string
  error:
    type: string
  messages:
    type: list

nodes:
  collect_currencies:
    type: data_collector
    role: "You are a helpful currency exchange assistant."
    initial_message: "Which currencies would you like to compare? (e.g. \\'USD to INR\\')"
    max_retry: 3
    next: get_rate
    humanize: true
    allow_intent_escape: true
    hallucination_check: true

    # Use minimal tokens for simple field extraction
    llm_params:
      temperature: 0.0
      max_tokens: 128

    fields:
      - field: from_currency
        description: "Source currency code (e.g. USD, EUR, GBP)"
      - field: to_currency
        description: "Target currency code (e.g. INR, JPY, CNY)"

    tools:
      - method: "actions.currency_tools.get_exchange_rate"
        name: "get_exchange_rate"
        description: "Get the current exchange rate between two currencies. Use this to answer the user\\'s question about exchange rates."
      - method: "actions.order_tools.get_current_date"
        name: "get_current_date"
        description: "Get today\\'s date if the user needs to know current date."

  get_rate:
    type: custom_action
    method: "actions.currency_tools.get_exchange_rate"
    args_from_state:
      from_currency: from_currency
      to_currency: to_currency
    result_field: exchange_rate
    next: rate_response
    on_error: error_response

  rate_response:
    type: response
    template: "Exchange Rate: {{state.exchange_rate}}"

  error_response:
    type: response
    template: "Sorry, I couldn\\'t find that exchange rate. Please check the currency codes and try again."

start: collect_currencies
''',

        # ── workflows/faq.yaml
        "workflows/faq.yaml": '''workflow: faq
description: "Answer general questions and provide helpful information"

state:
  user_message:
    type: string
  user_language:
    type: string
  output:
    type: string
  error:
    type: string
  messages:
    type: list

nodes:
  answer:
    type: custom_action
    method: "actions.faq_action.answer_faq"
    args_from_state:
      question: user_message
    result_field: output
    next: respond
    on_error: respond

  respond:
    type: response
    output_field: output

start: answer
''',

        # ── config.yaml
        "config.yaml": '''app:
  name: "My FlowGraph-AI Project"
  version: "1.0.0"

llm:
  provider: "ollama"          # Change to "claude" or "openai" as needed
  ollama_model: "llama3"
  ollama_base_url: "http://localhost:11434"
  temperature: 0.7
  max_tokens: 2048
  top_p: 1.0

  # Claude / Anthropic
  # provider: "claude"
  # claude_model: "claude-sonnet-4-20250514"

  # OpenAI
  # provider: "openai"
  # openai_model: "gpt-4o-mini"

engine:
  max_steps: 50

guardrails:
  enabled: true
  tone: "friendly and professional"
  rules: []

checkpoint:
  connection_string: "./checkpoints.db"

observability:
  langfuse:
    enabled: false
  otel:
    enabled: false

tracking:
  db_path: "./tasks.db"

intent:
  fallback_workflow: "faq"

logging:
  level: "INFO"
''',

        # ── .env.example
        ".env.example": """# Copy this file to .env and fill in your API keys

# Anthropic Claude (if using claude provider)
ANTHROPIC_API_KEY=your-anthropic-api-key-here

# OpenAI (if using openai provider)
# OPENAI_API_KEY=your-openai-api-key-here

# Langfuse observability (optional)
# LANGFUSE_PUBLIC_KEY=your-langfuse-public-key
# LANGFUSE_SECRET_KEY=your-langfuse-secret-key
# LANGFUSE_HOST=https://cloud.langfuse.com
""",

        # ── main.py
        "main.py": '''"""Entry point for the FlowGraph-AI project.

Run with:
  uv run python main.py          # Interactive CLI chat
  uv run uvicorn main:app --reload  # FastAPI server
"""
import sys
from pathlib import Path

# Add the project directory to the Python path
sys.path.insert(0, str(Path(__file__).parent))

# ── CLI entry point ────────────────────────────────────────────────────────────
if __name__ == "__main__":
    try:
        from flowgraph_ai.main import main
        main()
    except ImportError:
        print("FlowGraph-AI not found. Install with: pip install flowgraph-ai")
        sys.exit(1)

# ── FastAPI app (for uvicorn) ──────────────────────────────────────────────────
try:
    from flowgraph_ai.api.server import app
except ImportError:
    app = None
''',

        # ── tests/__init__.py
        "tests/__init__.py": "",

        # ── tests/test_demo.py
        "tests/test_demo.py": '''"""Basic smoke tests for the demo project."""
import sys
from pathlib import Path
import pytest

# Ensure project root is on path
sys.path.insert(0, str(Path(__file__).parent.parent))


def test_order_validator_valid():
    from validations.order_validators import validate_order_id
    is_valid, msg = validate_order_id("ORD-12345")
    assert is_valid
    assert msg == ""


def test_order_validator_invalid():
    from validations.order_validators import validate_order_id
    is_valid, msg = validate_order_id("12345")
    assert not is_valid
    assert "ORD-XXXXX" in msg


def test_get_current_date():
    from actions.order_tools import get_current_date
    result = get_current_date()
    assert isinstance(result, str)
    assert len(result) > 0


def test_get_order_status():
    from actions.order_tools import get_order_status
    result = get_order_status("ORD-12345")
    assert "ORD-12345" in result
    assert isinstance(result, str)


def test_list_recent_orders():
    from actions.order_tools import list_recent_orders
    result = list_recent_orders()
    assert "ORD-" in result


def test_get_exchange_rate_known():
    from actions.currency_tools import get_exchange_rate
    result = get_exchange_rate("USD", "INR")
    assert "USD" in result
    assert "INR" in result


def test_get_exchange_rate_unknown():
    from actions.currency_tools import get_exchange_rate
    result = get_exchange_rate("XYZ", "ABC")
    assert "not available" in result.lower()


def test_workflow_yaml_exists():
    wf_dir = Path(__file__).parent.parent / "workflows"
    assert (wf_dir / "order_tracking.yaml").exists()
    assert (wf_dir / "currency_lookup.yaml").exists()
    assert (wf_dir / "faq.yaml").exists()


def test_config_yaml_exists():
    config = Path(__file__).parent.parent / "config.yaml"
    assert config.exists()
    import yaml
    with open(config) as f:
        data = yaml.safe_load(f)
    assert "llm" in data
    assert "workflows" in data or "intent" in data or data.get("llm")
''',

        # ── README.md
        "README.md": '''# My FlowGraph-AI Project

A YAML-driven AI workflow project built with FlowGraph-AI.

## Quick Start

```bash
# 1. Install FlowGraph-AI
pip install flowgraph-ai

# 2. Configure your LLM
cp .env.example .env
# Edit .env with your API key

# 3. Run interactive chat
python main.py

# 4. Or start the REST API
uvicorn main:app --reload
```

## Demo Workflows

### Order Tracking
- Collects order ID (validates ORD-XXXXX format) and order date
- Pre-extracts both fields from opening message when possible
- Uses tools: `get_current_date`, `list_recent_orders`
- Supports follow-up questions after completion
- Hallucination detection on extracted values

### Currency Lookup
- Accepts "USD to INR" style queries
- Uses exchange rate tool for live lookup
- Temperature 0.0 for precise field extraction

### FAQ
- General-purpose Q&A using LLM

## LLM Configuration

Edit `config.yaml` to change the LLM provider:

```yaml
llm:
  provider: "claude"   # or "openai", "ollama"
  claude_model: "claude-sonnet-4-20250514"
  temperature: 0.7
  max_tokens: 2048
```

## Tests

```bash
pytest tests/ -v
```

## Project Structure

```
workflows/    — YAML workflow definitions
actions/      — Python tool/action functions
validations/  — Custom field validators
tests/        — Test suite
config.yaml   — LLM + engine configuration
main.py       — Entry point
```
''',
    }

    for rel_path, content in files.items():
        full_path = project_dir / rel_path
        full_path.parent.mkdir(parents=True, exist_ok=True)
        full_path.write_text(content)
        console.print(f"  [dim]Created[/dim] {rel_path}")


def main():
    app()


if __name__ == "__main__":
    main()
