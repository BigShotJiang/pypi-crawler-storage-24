"""
Intent Classifier — V3.

Maps a user message to a workflow name by reading each workflow's
`description` field from YAML. No domain-specific hardcoding here.

Runs OUTSIDE the main workflow graph — it's called before the workflow
graph is built/resumed, so it can redirect to a different workflow if needed.
"""

import logging
import time
from flowgraph_ai.engine.workflow_loader import WorkflowLoader

logger = logging.getLogger("flowgraph.intent")


def classify_intent(
    user_message: str,
    llm,
    config: dict | None = None,
    workflows_dir: str | None = None,
    loader: "WorkflowLoader | None" = None,
) -> str:
    """Classify user message into a workflow name.

    Workflow descriptions are read dynamically from each YAML file's
    `description` field — adding a new workflow automatically makes it
    discoverable.

    Args:
        user_message: Raw user text.
        llm: LangChain LLM instance.
        config: Full app config (for fallback_workflow setting).
        workflows_dir: Optional custom path to workflows directory.

    Returns:
        Workflow name matching a .yaml file in the workflows directory.
    """
    intent_cfg = (config or {}).get("intent", {})
    fallback = intent_cfg.get("fallback_workflow", "greeting")

    if loader is None:
        loader = WorkflowLoader(workflows_dir, fallback_workflow=fallback)
    available = loader.list_workflows()

    if not available:
        logger.warning("[CLASSIFY_FALLBACK] reason=no_workflows  using=%s", fallback)
        return fallback

    # Read descriptions from each workflow's YAML
    descriptions = {}
    for name in available:
        meta = loader.load_metadata(name)
        descriptions[name] = meta.get("description", name.replace("_", " "))

    descriptions_text = "\n".join(
        f"- {name}: {desc}" for name, desc in sorted(descriptions.items())
    )

    custom_prompt = intent_cfg.get("custom_prompt")

    if custom_prompt:
        prompt = (
            f"{custom_prompt}\n\n"
            f'User message: "{user_message}"\n\n'
            f"Available workflows:\n{descriptions_text}\n\n"
        )
    else:
        prompt = (
            f"Classify the intent of this user message into the best matching workflow.\n\n"
            f'User message: "{user_message}"\n\n'
            f"Available workflows:\n{descriptions_text}\n\n"
            f"Rules:\n"
            f"- Choose the single best matching workflow name from the list above.\n"
            f"- Respond with ONLY the workflow name (e.g., 'greeting'), nothing else.\n"
            f"- If no workflow clearly matches, respond with '{fallback}'."
        )

    logger.debug(
        "[CLASSIFY_START] message=%r  workflows=%d  prompt_chars=%d",
        user_message[:60], len(available), len(prompt),
    )
    logger.debug("[CLASSIFY_PROMPT]\n%s", prompt)

    t0 = time.perf_counter()
    try:
        response = llm.invoke(prompt).content.strip().lower().rstrip(".")
        elapsed_ms = (time.perf_counter() - t0) * 1000
    except Exception as e:
        elapsed_ms = (time.perf_counter() - t0) * 1000
        logger.error(
            "[CLASSIFY_FAIL] error=%s  elapsed=%.0fms  using=%s\n"
            "  Fix: Check LLM provider is running (flowgraph llm test).",
            e, elapsed_ms, fallback,
        )
        return fallback

    if response not in available:
        logger.warning(
            "[CLASSIFY_FALLBACK] llm_returned=%r  not_in_workflows=%s  using=%s  elapsed=%.0fms",
            response, available, fallback, elapsed_ms,
        )
        return fallback

    logger.info(
        "[CLASSIFY_DONE] result=%s  elapsed=%.0fms  message=%r",
        response, elapsed_ms, user_message[:50],
    )
    return response
