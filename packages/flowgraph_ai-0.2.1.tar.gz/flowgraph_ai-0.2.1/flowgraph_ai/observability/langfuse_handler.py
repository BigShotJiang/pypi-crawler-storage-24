"""
Langfuse integration for FlowGraph-AI.

Injects a LangChain CallbackHandler into every workflow invocation.
When enabled, ALL LLM calls (prompts, completions, tokens, latency,
cost) are automatically captured and visible in the Langfuse UI.

Captured per invocation:
  - Full prompt sent to LLM
  - LLM response / completion
  - Token usage + cost estimate
  - Latency per LLM call
  - Node-level traces (data_collector questions, guardrails, language detection)
  - Session grouping by thread_id

Setup:
  1. flowgraph stack up
  2. Open http://localhost:3000 → create account → create project
  3. Settings → API Keys → copy public + secret keys
  4. flowgraph stack configure  (saves keys to config.yaml)
  5. Set observability.langfuse.enabled: true in config.yaml

config.yaml:
  observability:
    langfuse:
      enabled: true
      host: http://localhost:3000
      public_key: ""   # or env: LANGFUSE_PUBLIC_KEY
      secret_key: ""   # or env: LANGFUSE_SECRET_KEY

Environment variable overrides (take priority over config.yaml):
  LANGFUSE_PUBLIC_KEY
  LANGFUSE_SECRET_KEY
  LANGFUSE_HOST
"""

import logging
import os

logger = logging.getLogger(__name__)


def get_langfuse_handler(
    config: dict,
    session_id: str,
    trace_name: str,
    metadata: dict | None = None,
):
    """
    Create a Langfuse CallbackHandler for one workflow invocation.

    Pass the returned handler in the LangChain/LangGraph run config:
        compiled.invoke(input, {"callbacks": [handler], "configurable": {...}})

    Returns None if Langfuse is disabled or not configured.
    """
    obs_cfg = config.get("observability", {}).get("langfuse", {})
    if not obs_cfg.get("enabled", False):
        return None

    try:
        from langfuse.callback import CallbackHandler
    except ImportError:
        logger.error(
            "[Langfuse] Package not installed.\n"
            "  Fix: uv add langfuse\n"
            "  Then restart the server."
        )
        return None

    public_key = os.getenv("LANGFUSE_PUBLIC_KEY") or obs_cfg.get("public_key", "")
    secret_key = os.getenv("LANGFUSE_SECRET_KEY") or obs_cfg.get("secret_key", "")
    host = os.getenv("LANGFUSE_HOST") or obs_cfg.get("host", "http://localhost:3000")

    if not public_key or not secret_key:
        logger.warning(
            "[Langfuse] API keys not configured — LLM traces will NOT be captured.\n"
            "  Fix: flowgraph stack configure\n"
            "    OR set env vars: LANGFUSE_PUBLIC_KEY + LANGFUSE_SECRET_KEY\n"
            "  Get keys: %s → Settings → API Keys",
            host,
        )
        return None

    if not public_key.startswith("pk-"):
        logger.warning(
            "[Langfuse] Public key looks invalid (expected 'pk-lf-...'). Got: %s…\n"
            "  Fix: re-run flowgraph stack configure with the correct key from %s",
            public_key[:10], host,
        )

    try:
        handler = CallbackHandler(
            public_key=public_key,
            secret_key=secret_key,
            host=host,
            session_id=session_id,
            trace_name=trace_name,
            metadata=metadata or {},
        )
        logger.debug("Langfuse handler created  session=%s  trace=%s", session_id, trace_name)
        return handler
    except ConnectionError:
        logger.warning(
            "[Langfuse] Cannot connect to %s.\n"
            "  Fix: flowgraph stack up  (to start Langfuse container)\n"
            "  Or check that LANGFUSE_HOST points to the correct server.",
            host,
        )
        return None
    except Exception as e:
        logger.warning(
            "[Langfuse] Unexpected error creating handler: %s\n"
            "  Report this issue to the FlowGraph-AI team with the full stack trace.",
            e,
        )
        return None


def is_enabled(config: dict) -> bool:
    """Return True if Langfuse is enabled in config."""
    return config.get("observability", {}).get("langfuse", {}).get("enabled", False)


def flush(config: dict) -> None:
    """Flush any pending Langfuse events. Call at shutdown."""
    if not is_enabled(config):
        return
    try:
        from langfuse import Langfuse
        lf = Langfuse()
        lf.flush()
    except Exception:
        pass
