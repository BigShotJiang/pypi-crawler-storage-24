"""
Response Node — V3 End Node.

The ResponseNode is always the final node. It reads the output from state,
applies guardrails, and sets the final message.

Priority:
  1. If error_field has a value → send error message (guardrailed)
  2. Else if output_field has a value → send it (guardrailed)
  3. Else if template is defined → render it (guardrailed)
  4. Else → send a default completion message

YAML:
  final_response:
    type: response
    output_field: output       # Which state field is the main output (default: output)
    error_field: error         # Which state field is the error (default: error)

  OR with a template:
  confirm_response:
    type: response
    template: "Your request {{state.request_id}} has been submitted!"
    output_field: output
    error_field: error

  OR with per-node guardrails override:
  show_results:
    type: response
    output_field: output
    guardrails:
      enabled: false           # Disable guardrails for this node only
      # OR
      tone: "very formal"
      custom_rules:
        - "Always include a reference number"
      # OR (full prompt override)
      custom_prompt: |
        You are a strict reviewer. Return only the corrected response.

Guardrail configuration priority: node-level > workflow-level > config.yaml
See engine/guardrails.py for full documentation.
"""

import logging
import time
from flowgraph_ai.engine.guardrails import apply_guardrails, merge_guardrails_config
from flowgraph_ai.engine.template import render

logger = logging.getLogger("flowgraph.nodes.response")


def build_node(node_def: dict, default_llm, app_config: dict, workflow_guardrails: dict = None):
    """Return a LangGraph-compatible node function for a response node.

    Args:
        node_def:             The node configuration dict from workflow YAML.
        default_llm:          The LangChain LLM instance.
        app_config:           The full app config dict (from config.yaml).
        workflow_guardrails:  Optional workflow-level guardrails config.
    """

    output_field = node_def.get("output_field", "output")
    error_field = node_def.get("error_field", "error")
    template = node_def.get("template")

    # Node-level guardrails config (highest priority)
    node_guardrails = node_def.get("guardrails")

    # Merge: global → workflow → node
    guardrails_cfg = merge_guardrails_config(app_config, workflow_guardrails, node_guardrails)
    guardrails_enabled = guardrails_cfg["enabled"]

    node_name = node_def.get("name", "?")

    def node_fn(state: dict) -> dict:
        language = state.get("user_language", "English") or "English"

        # ── Determine the raw output text ────────────────────────────────────
        if state.get(error_field):
            raw_text = str(state[error_field])
            source = "error_field"
        elif state.get(output_field):
            raw_text = str(state[output_field])
            source = "output_field"
        elif template:
            raw_text = render(template, state)
            source = "template"
        else:
            raw_text = "Your request has been completed."
            source = "default"
            logger.warning(
                "[RESPONSE] node=%s  source=default  "
                "Fix: set output_field or template in this response node.",
                node_name,
            )

        logger.info(
            "[RESPONSE] node=%s  source=%s  chars=%d  language=%s",
            node_name, source, len(raw_text), language,
        )
        logger.debug("[RESPONSE_TEXT] node=%s  preview=%r", node_name, raw_text[:120])

        # ── Apply guardrails ─────────────────────────────────────────────────
        if guardrails_enabled:
            t0 = time.perf_counter()
            final_text = apply_guardrails(raw_text, default_llm, language, guardrails_cfg)
            elapsed_ms = (time.perf_counter() - t0) * 1000
            logger.info(
                "[GUARDRAILS] node=%s  elapsed=%.0fms  chars=%d→%d",
                node_name, elapsed_ms, len(raw_text), len(final_text),
            )
        else:
            final_text = raw_text
            logger.debug("[GUARDRAILS_SKIP] node=%s  reason=disabled", node_name)

        return {"output": final_text}

    return node_fn
