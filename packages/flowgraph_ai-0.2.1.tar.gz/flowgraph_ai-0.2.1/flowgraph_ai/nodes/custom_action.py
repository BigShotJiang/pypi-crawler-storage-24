"""
CustomAction Node — V3.

Executes developer-defined Python business logic.
The developer's method receives state, can mutate it, and returns the next node name.

Routing options (in YAML):
  1. routes[] — list of {value, next} pairs matched against result_field
  2. conditional_edges — {field, paths} for field-value based routing
  3. next — simple fixed routing (used with args_from_state mode)
  4. Direct routing (default) — return value IS the next node name

YAML (state-dict mode — traditional):
  check_billing:
    type: custom_action
    method: "actions.billing.check_status"
    result_field: billing_result   # default: action_result
    routes:
      - value: "verified"
        next: get_sr_status
      - value: "not_found"
        next: collect_sr
      - default: error_response

YAML (args_from_state mode — function receives explicit kwargs):
  lookup_order:
    type: custom_action
    method: "actions.order_tools.get_order_status"
    args_from_state:
      order_id: order_id          # function_kwarg: state_field
    result_field: order_status    # stores the return value
    next: success_response        # fixed routing when done
    on_error: error_response      # routing on exception

  When args_from_state is defined:
  - The function is called with explicit kwargs extracted from state.
  - The function may return any value (str, dict, int, etc.) — it is stored in result_field.
  - Routing is handled via `next` (fixed), `routes`, or `conditional_edges`.

  OR with conditional_edges:
  check_eligibility:
    type: custom_action
    method: "actions.hr.check_eligibility"
    result_field: is_eligible
    conditional_edges:
      field: is_eligible
      paths:
        "true": submit_form
        "false": ineligible_response
        default: error_response

  OR direct routing (no routes config, no args_from_state):
  do_something:
    type: custom_action
    method: "actions.my.do_something"
    # Return "next_node_name" or "END" from the function
"""

import importlib
import logging
import time

logger = logging.getLogger("flowgraph.nodes.custom_action")


def build_node(node_def: dict):
    """Return a LangGraph-compatible node function for a custom_action node."""

    method_path = node_def.get("method")
    result_field = node_def.get("result_field", "action_result")
    args_from_state = node_def.get("args_from_state")  # {kwarg_name: state_field}
    on_error_node = node_def.get("on_error")

    if not method_path:
        raise ValueError(
            f"custom_action node '{node_def.get('name')}' must specify 'method'."
        )

    node_name = node_def.get("name", "?")

    def node_fn(state: dict) -> dict:
        logger.info("[ACTION_START] node=%s  method=%s", node_name, method_path)
        t0 = time.perf_counter()
        try:
            module_name, func_name = method_path.rsplit(".", 1)
            module = importlib.import_module(module_name)
            func = getattr(module, func_name)

            if args_from_state:
                # ── args_from_state mode ──────────────────────────────────────
                # Extract kwargs from state and call function with explicit args.
                # The function return value (any type) is stored in result_field.
                kwargs = {
                    kwarg: state.get(state_field)
                    for kwarg, state_field in args_from_state.items()
                }
                result = func(**kwargs)
                elapsed_ms = (time.perf_counter() - t0) * 1000
                logger.info(
                    "[ACTION_DONE] node=%s  method=%s  mode=args_from_state  elapsed=%.0fms",
                    node_name, method_path, elapsed_ms,
                )
                return {result_field: result}

            else:
                # ── state-dict mode (traditional) ─────────────────────────────
                # Give the developer's action a mutable copy of state.
                # The function must return a str (next node name or 'END').
                state_copy = dict(state)
                result = func(state_copy)

                if not isinstance(result, str):
                    raise TypeError(
                        f"'{method_path}' must return str (next node name or 'END'), "
                        f"got {type(result).__name__}. "
                        f"Fix: ensure your action function returns a string, or add "
                        f"'args_from_state:' to the node YAML to use keyword-arg mode."
                    )

                elapsed_ms = (time.perf_counter() - t0) * 1000
                logger.info(
                    "[ACTION_DONE] node=%s  method=%s  result=%r  elapsed=%.0fms",
                    node_name, method_path, result, elapsed_ms,
                )

                # Merge state mutations + routing result
                updates = {result_field: result}
                for k, v in state_copy.items():
                    if k not in state or state[k] != v:
                        updates[k] = v
                        logger.debug("[STATE_UPDATE] key=%s  via=custom_action", k)

                return updates

        except Exception as e:
            elapsed_ms = (time.perf_counter() - t0) * 1000
            logger.error(
                "[ACTION_FAIL] node=%s  method=%s  error=%s  elapsed=%.0fms",
                node_name, method_path, e, elapsed_ms,
                exc_info=True,
            )
            return {
                result_field: on_error_node or "END",
                "error": f"Action '{method_path}' failed: {e}",
            }

    return node_fn


def make_router(node_def: dict, all_node_names: set):
    """Return a LangGraph conditional edge function for a custom_action node."""
    result_field = node_def.get("result_field", "action_result")
    on_error_node = node_def.get("on_error")

    # Option 0: args_from_state mode with fixed `next` routing
    if node_def.get("args_from_state") and "next" in node_def and "routes" not in node_def and "conditional_edges" not in node_def:
        next_node = node_def["next"]
        error_node = on_error_node

        def args_router(state: dict) -> str:
            # If an error was recorded, route to on_error
            if state.get("error") and error_node:
                return error_node if error_node in all_node_names else "__end__"
            return next_node if next_node in all_node_names else "__end__"

        return args_router

    # Option 1: routes[] list
    if "routes" in node_def:
        routes = node_def["routes"]
        def _route_default(r):
            d = r.get("default")
            if isinstance(d, str):
                return d
            return r.get("next")
        default_next = next(
            (_route_default(r) for r in routes if "default" in r or r.get("value") is None),
            "END"
        )
        value_map = {
            r["value"]: r["next"]
            for r in routes
            if "value" in r
        }

        def routes_router(state: dict) -> str:
            value = str(state.get(result_field, "")).strip()
            target = value_map.get(value, default_next)
            return target if target in all_node_names else "__end__"

        return routes_router

    # Option 2: conditional_edges {field, paths}
    if "conditional_edges" in node_def:
        ce = node_def["conditional_edges"]
        field = ce["field"]
        paths = ce["paths"]
        default = paths.get("default", "END")

        def ce_router(state: dict) -> str:
            value = state.get(field)
            key = str(value).lower() if isinstance(value, bool) else str(value)
            target = paths.get(key, default)
            return target if target in all_node_names else "__end__"

        return ce_router

    # Option 3: direct routing — return value IS the next node name
    def direct_router(state: dict) -> str:
        value = str(state.get(result_field, "")).strip()
        if value == "END" or not value:
            return "__end__"
        if value in all_node_names:
            return value
        logger.warning("Direct route target '%s' not in graph. Ending.", value)
        return "__end__"

    return direct_router
