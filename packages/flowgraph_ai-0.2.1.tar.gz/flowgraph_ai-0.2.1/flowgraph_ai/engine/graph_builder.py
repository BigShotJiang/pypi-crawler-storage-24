"""
Graph Builder — V3 Core Engine.

Dynamically builds a LangGraph StateGraph from a workflow YAML definition.

Node types:
  data_collector → LangGraph node + conditional edges
  custom_action  → LangGraph node + conditional edges
  response       → LangGraph node + unconditional edge to END

State:
  TypedDict created from workflow YAML state schema.
  Standard fields always injected: messages, user_language, output, error,
  user_message, _dc_next_node, _dc_failed, _dc_node.

Usage:
  from flowgraph_ai.engine.graph_builder import GraphBuilder
  builder = GraphBuilder(default_llm, app_config)
  compiled = builder.build(workflow_config, checkpointer)
  result = compiled.invoke({"user_message": "hello"}, {"configurable": {"thread_id": "abc"}})
"""

import operator
import logging
import time
from typing import Optional, Annotated

from typing_extensions import TypedDict
from langgraph.graph import StateGraph, START, END

import flowgraph_ai.nodes.data_collector as dc_node
import flowgraph_ai.nodes.custom_action as ca_node
import flowgraph_ai.nodes.response_node as rn_node

logger = logging.getLogger("flowgraph.engine.graph_builder")

_TYPE_MAP = {
    "str": str, "string": str,
    "bool": bool, "boolean": bool,
    "int": int, "integer": int,
    "float": float, "number": float,
    "list": list, "array": list,
    "dict": dict, "object": dict,
}


class GraphBuilder:
    """Builds compiled LangGraph StateGraphs from workflow config dicts."""

    def __init__(self, default_llm, app_config: dict) -> None:
        self._llm = default_llm
        self._config = app_config

    def build(self, workflow_config: dict, checkpointer=None):
        """Build and compile a LangGraph StateGraph.

        Args:
            workflow_config: Normalized workflow dict from WorkflowLoader.
            checkpointer: LangGraph checkpointer (MemorySaver or SqliteSaver).

        Returns:
            A compiled LangGraph graph.
        """
        t0 = time.perf_counter()
        wf_name = workflow_config["workflow"]
        node_count = len(workflow_config["nodes"])
        logger.info(
            "[BUILD_START] workflow=%s  nodes=%d  start=%s",
            wf_name, node_count, workflow_config.get("start_node"),
        )

        # ── 1. Create TypedDict state class ───────────────────────────────────
        State = _create_state_class(workflow_config["state"])

        # ── 2. Build graph ────────────────────────────────────────────────────
        graph = StateGraph(State)

        all_node_names = {n["name"] for n in workflow_config["nodes"]}

        # ── 3. Add nodes + edges ──────────────────────────────────────────────
        for node_def in workflow_config["nodes"]:
            name = node_def["name"]
            node_type = node_def["type"]

            if node_type == "data_collector":
                workflow_guardrails = workflow_config.get("guardrails")
                fn = dc_node.build_node(node_def, self._llm, self._config, workflow_guardrails)
                graph.add_node(name, fn)
                router = dc_node.make_router(node_def, all_node_names)
                graph.add_conditional_edges(name, router)
                logger.debug("[NODE_ADD] workflow=%s  name=%s  type=data_collector", wf_name, name)

            elif node_type == "custom_action":
                fn = ca_node.build_node(node_def)
                graph.add_node(name, fn)
                router = ca_node.make_router(node_def, all_node_names)
                graph.add_conditional_edges(name, router)
                logger.debug("[NODE_ADD] workflow=%s  name=%s  type=custom_action", wf_name, name)

            elif node_type == "response":
                workflow_guardrails = workflow_config.get("guardrails")
                fn = rn_node.build_node(node_def, self._llm, self._config, workflow_guardrails)
                graph.add_node(name, fn)
                graph.add_edge(name, END)
                logger.debug("[NODE_ADD] workflow=%s  name=%s  type=response", wf_name, name)

            else:
                raise ValueError(
                    f"Unknown node type '{node_type}' for node '{name}'. "
                    f"Valid types: data_collector, custom_action, response"
                )

        # ── 4. Entry point ────────────────────────────────────────────────────
        start_node = workflow_config["start_node"]
        graph.add_edge(START, start_node)

        # ── 5. Compile ────────────────────────────────────────────────────────
        compiled = graph.compile(checkpointer=checkpointer)
        elapsed_ms = (time.perf_counter() - t0) * 1000
        logger.info(
            "[BUILD_DONE] workflow=%s  nodes=%d  start=%s  elapsed=%.0fms",
            wf_name, node_count, start_node, elapsed_ms,
        )
        return compiled


# ─────────────────────────────────────────────────────────────────────────────
# State TypedDict generation
# ─────────────────────────────────────────────────────────────────────────────

def _create_state_class(schema: dict) -> type:
    """Dynamically create a TypedDict from the workflow state schema.

    List fields use Annotated[list, operator.add] so returning a list
    from a node appends rather than overwrites.
    """
    annotations = {}
    for key, type_def in schema.items():
        # Support both simple string ("str") and dict ({"type": "str"})
        if isinstance(type_def, dict):
            type_str = type_def.get("type", "str")
        else:
            type_str = str(type_def)

        python_type = _TYPE_MAP.get(type_str.lower(), str)

        if python_type is list:
            annotations[key] = Annotated[list, operator.add]
        else:
            annotations[key] = Optional[python_type]

    return TypedDict("WorkflowState", annotations)
