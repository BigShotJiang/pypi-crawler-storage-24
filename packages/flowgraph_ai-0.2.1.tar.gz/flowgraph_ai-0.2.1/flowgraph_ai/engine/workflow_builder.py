"""
FlowGraph Workflow Builder — fluent Python API.

Lets developers define workflows in code instead of (or alongside) YAML.
The output is the same normalized dict that WorkflowLoader produces,
so GraphBuilder.build() accepts it unchanged.

Quick example:
    from flowgraph_ai.engine.workflow_builder import workflow

    wf = (
        workflow("support", description="Customer support ticket flow")
        .state(ticket_id="str", resolved="bool")
        .collect(
            "ask_ticket",
            field="ticket_id",
            ask="Please share your ticket number.",
            next_node="check_ticket",
            on_max_retry="sorry",
            validation={"method": "regex", "pattern": r"^TKT-\\d+$"},
        )
        .action(
            "check_ticket",
            method="actions.support.check_ticket",
            routes={"found": "respond_ok", "_default": "sorry"},
        )
        .respond("respond_ok", template="Your ticket {state.ticket_id} is being processed.")
        .respond("sorry", error_field="error")
        .start("ask_ticket")
    )

    # Compile directly:
    compiled = wf.compile(llm, app_config, checkpointer=my_checkpointer)

    # Or get the config dict (compatible with GraphBuilder.build):
    config_dict = wf.build()
"""

from __future__ import annotations

from typing import Any


# ── Standard state fields injected by the engine ──────────────────────────────
_STANDARD_STATE = {
    "user_message": "str",
    "user_language": "str",
    "output": "str",
    "error": "str",
    "messages": "list",
    "_dc_next_node": "str",
    "_dc_failed": "bool",
    "_dc_node": "str",
}


class workflow:  # noqa: N801 — lowercase intentional for fluent DSL feel
    """Fluent builder for a FlowGraph workflow definition.

    Usage:
        wf = (
            workflow("my_flow", description="What this handles")
            .state(my_field="str")
            .collect("step1", field="my_field", ask="Enter value:", next_node="step2")
            .action("step2", method="actions.my.do_thing", routes={"ok": "done", "_default": "err"})
            .respond("done", template="Result: {state.my_field}")
            .respond("err", error_field="error")
            .start("step1")
        )
        compiled = wf.compile(llm, config)
    """

    def __init__(self, name: str, *, description: str = "") -> None:
        self._name = name
        self._description = description
        self._user_state: dict[str, str] = {}
        self._nodes: list[dict] = []
        self._start_node: str | None = None
        self._initial_input_field: str = "user_message"

    # ── State ──────────────────────────────────────────────────────────────────

    def state(self, **fields: str) -> "workflow":
        """Declare custom state fields.

        Args:
            **fields: field_name=type_string pairs.  Types: str, int, float, bool, list, dict.

        Example:
            .state(ticket_id="str", resolved="bool", count="int")
        """
        self._user_state.update(fields)
        return self

    def initial_input(self, field_name: str) -> "workflow":
        """Set which state field receives the first user message (default: user_message)."""
        self._initial_input_field = field_name
        return self

    # ── Node builders ──────────────────────────────────────────────────────────

    def collect(
        self,
        name: str,
        *,
        field: str,
        ask: str,
        next_node: str,
        on_max_retry: str = "error",
        max_retry: int = 3,
        role: str = "You are a helpful assistant.",
        description: str = "",
        validation: dict | None = None,
        allow_intent_escape: bool = False,
    ) -> "workflow":
        """Add a single-field data_collector node.

        Args:
            name:               Node name (unique within the workflow).
            field:              State field to collect.
            ask:                Message shown to the user when asking for input.
            next_node:          Next node when collection succeeds.
            on_max_retry:       Node to go to after max failed attempts.
            max_retry:          Max extraction attempts before on_max_retry.
            role:               LLM system role for this node.
            description:        Human-readable description of the field (helps LLM extract).
            validation:         Validation config dict, e.g. {"method": "regex", "pattern": "..."}.
            allow_intent_escape: Let users ask off-topic questions and still get answered.
        """
        node: dict[str, Any] = {
            "name": name,
            "type": "data_collector",
            "role": role,
            "initial_message": ask,
            "field": field,
            "description": description or f"Value for {field}",
            "max_retry": max_retry,
            "next": next_node,
            "on_max_retry": on_max_retry,
        }
        if validation:
            node["validation"] = validation
        if allow_intent_escape:
            node["allow_intent_escape"] = True
        self._nodes.append(node)
        return self

    def collect_multi(
        self,
        name: str,
        *,
        fields: list[dict],
        ask: str,
        next_node: str,
        on_max_retry: str = "error",
        max_retry: int = 3,
        role: str = "You are a helpful assistant.",
    ) -> "workflow":
        """Add a multi-field data_collector node.

        Args:
            name:       Node name.
            fields:     List of field dicts. Each dict: {field, description, validation?}.
            ask:        Message shown to the user.
            next_node:  Next node on success.
            on_max_retry: Node on failure.
            max_retry:  Max attempts.
            role:       LLM system role.

        Example:
            .collect_multi(
                "dates",
                ask="Provide start and end date (YYYY-MM-DD).",
                next_node="submit",
                fields=[
                    {"field": "start_date", "description": "Start date YYYY-MM-DD",
                     "validation": {"method": "regex", "pattern": r"^\\d{4}-\\d{2}-\\d{2}$"}},
                    {"field": "end_date",   "description": "End date YYYY-MM-DD",
                     "validation": {"method": "regex", "pattern": r"^\\d{4}-\\d{2}-\\d{2}$"}},
                ],
            )
        """
        self._nodes.append({
            "name": name,
            "type": "data_collector",
            "role": role,
            "initial_message": ask,
            "fields": fields,
            "max_retry": max_retry,
            "next": next_node,
            "on_max_retry": on_max_retry,
        })
        return self

    def action(
        self,
        name: str,
        *,
        method: str,
        result_field: str = "action_result",
        routes: dict[str, str] | None = None,
    ) -> "workflow":
        """Add a custom_action node.

        Args:
            name:         Node name.
            method:       Dotted import path to a Python function, e.g. "actions.hr.submit".
            result_field: State field that receives the function's return value.
            routes:       Routing map.  Key = return value, value = next node name.
                          Use "_default" as the fallback key.

        Example:
            .action(
                "submit",
                method="actions.hr.submit_leave",
                routes={"confirm": "done", "_default": "error"},
            )
        """
        node: dict[str, Any] = {
            "name": name,
            "type": "custom_action",
            "method": method,
            "result_field": result_field,
        }
        if routes:
            route_list = []
            for value, next_node in routes.items():
                if value == "_default":
                    route_list.append({"default": next_node})
                else:
                    route_list.append({"value": value, "next": next_node})
            node["routes"] = route_list
        self._nodes.append(node)
        return self

    def respond(
        self,
        name: str,
        *,
        template: str | None = None,
        output_field: str = "output",
        error_field: str | None = None,
    ) -> "workflow":
        """Add a response (end) node.

        Args:
            name:         Node name.
            template:     Template string with {state.field} placeholders.
            output_field: State field to read for the response text.
            error_field:  If set, read from this error field instead.

        Example:
            .respond("done", template="Request {state.request_id} submitted!")
            .respond("error", error_field="error")
        """
        node: dict[str, Any] = {"name": name, "type": "response"}
        if template:
            node["template"] = template
        else:
            node["output_field"] = output_field
        if error_field:
            node["error_field"] = error_field
        self._nodes.append(node)
        return self

    def start(self, node_name: str) -> "workflow":
        """Set the entry-point node for this workflow."""
        self._start_node = node_name
        return self

    # ── Output ─────────────────────────────────────────────────────────────────

    def build(self) -> dict:
        """Return the normalized workflow config dict.

        Compatible with GraphBuilder.build() — no WorkflowLoader needed.

        Raises:
            ValueError: If no nodes or no start_node have been set.
        """
        if not self._nodes:
            raise ValueError(f"Workflow '{self._name}' has no nodes defined.")

        start = self._start_node or self._nodes[0]["name"]
        node_names = {n["name"] for n in self._nodes}
        if start not in node_names:
            raise ValueError(
                f"start node '{start}' is not in the workflow's nodes {node_names}."
            )

        state = {**_STANDARD_STATE, **self._user_state}

        return {
            "workflow": self._name,
            "description": self._description,
            "initial_input_field": self._initial_input_field,
            "start_node": start,
            "state": state,
            "nodes": self._nodes,
        }

    def compile(self, llm, app_config: dict, checkpointer=None):
        """Build the workflow config and compile it into a LangGraph graph.

        Args:
            llm:          LangChain chat model instance.
            app_config:   Full app config dict (from load_config()).
            checkpointer: Optional LangGraph checkpointer. Uses MemorySaver if not given.

        Returns:
            A compiled LangGraph graph ready for invocation.
        """
        from flowgraph_ai.engine.graph_builder import GraphBuilder

        if checkpointer is None:
            from langgraph.checkpoint.memory import MemorySaver
            checkpointer = MemorySaver()

        return GraphBuilder(default_llm=llm, app_config=app_config).build(
            self.build(), checkpointer=checkpointer
        )
