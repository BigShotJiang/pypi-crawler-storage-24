"""
Response Guardrails — Customizable Safety Layer.

Applied automatically on every Response node output before sending to the user.
Uses the LLM to review and sanitize the response.

────────────────────────────────────────────────────────────────────────────
CONFIGURATION PRIORITY (highest → lowest)
────────────────────────────────────────────────────────────────────────────
  1. Node-level   — `guardrails:` inside a response node in YAML
  2. Workflow-level — `guardrails:` at the top of the workflow YAML
  3. Global        — `guardrails:` in config.yaml

Any option not specified at a higher level falls through to the lower level.

────────────────────────────────────────────────────────────────────────────
GLOBAL CONFIG (config.yaml)
────────────────────────────────────────────────────────────────────────────
  guardrails:
    enabled: true

    # Optional: override the default tone instruction
    tone: "professional and helpful"

    # Optional: extra rules appended to the default safety checklist
    custom_rules:
      - "Never mention competitor products"
      - "Always end with a helpful suggestion"

    # Optional: fully override the entire system prompt (overrides tone + custom_rules)
    custom_prompt: |
      You are a strict content reviewer. Return only safe content.

────────────────────────────────────────────────────────────────────────────
WORKFLOW-LEVEL OVERRIDE (workflow YAML — top level)
────────────────────────────────────────────────────────────────────────────
  guardrails:
    tone: "casual and friendly"
    custom_rules:
      - "Always offer to escalate to a human agent"

────────────────────────────────────────────────────────────────────────────
NODE-LEVEL OVERRIDE (individual response node)
────────────────────────────────────────────────────────────────────────────
  show_results:
    type: response
    output_field: output
    guardrails:
      enabled: false        # disable only for this node
      # OR
      tone: "very formal"
      custom_rules:
        - "Include a reference number in every response"
"""

import logging
import time
from typing import Optional

logger = logging.getLogger("flowgraph.engine.guardrails")

# Default base rules always applied (unless custom_prompt fully overrides)
_DEFAULT_RULES = [
    "Is professional, polite, and helpful",
    "Contains no offensive, harmful, or inappropriate content",
    "Uses clear, simple language",
]


def merge_guardrails_config(
    global_cfg: dict,
    workflow_cfg: Optional[dict],
    node_cfg: Optional[dict],
) -> dict:
    """Merge guardrails config from three levels (global → workflow → node).

    Higher-priority configs override lower-priority ones for scalar values.
    `custom_rules` from all levels are combined (not replaced).

    Args:
        global_cfg:   The full app config dict (from config.yaml).
        workflow_cfg: The workflow-level guardrails dict, or None.
        node_cfg:     The node-level guardrails dict, or None.

    Returns:
        Merged guardrails config dict with keys:
          enabled (bool), tone (str|None), custom_rules (list), custom_prompt (str|None)
    """
    base = global_cfg.get("guardrails", {})

    merged = {
        "enabled": base.get("enabled", True),
        "tone": base.get("tone"),
        "custom_rules": list(base.get("custom_rules") or []),
        "custom_prompt": base.get("custom_prompt"),
    }

    # Apply workflow-level overrides
    if workflow_cfg:
        if "enabled" in workflow_cfg:
            merged["enabled"] = workflow_cfg["enabled"]
        if "tone" in workflow_cfg:
            merged["tone"] = workflow_cfg["tone"]
        if "custom_rules" in workflow_cfg:
            merged["custom_rules"] = merged["custom_rules"] + list(workflow_cfg["custom_rules"] or [])
        if "custom_prompt" in workflow_cfg:
            merged["custom_prompt"] = workflow_cfg["custom_prompt"]

    # Apply node-level overrides (highest priority)
    if node_cfg:
        if "enabled" in node_cfg:
            merged["enabled"] = node_cfg["enabled"]
        if "tone" in node_cfg:
            merged["tone"] = node_cfg["tone"]
        if "custom_rules" in node_cfg:
            merged["custom_rules"] = merged["custom_rules"] + list(node_cfg["custom_rules"] or [])
        if "custom_prompt" in node_cfg:
            merged["custom_prompt"] = node_cfg["custom_prompt"]

    return merged


def apply_guardrails(text: str, llm, language: str = "English", guardrails_cfg: Optional[dict] = None) -> str:
    """Apply LLM safety guardrails to an output text.

    Args:
        text:           The raw response text to review.
        llm:            LangChain LLM instance.
        language:       User's language (to preserve in output).
        guardrails_cfg: Merged guardrails config dict. If None, uses defaults.

    Returns:
        Safe, reviewed response text. Returns original text on any failure.
    """
    # Nothing to review — return immediately to avoid a wasted LLM call
    if not text or not text.strip():
        return text

    cfg = guardrails_cfg or {}

    # Build the system prompt
    if cfg.get("custom_prompt"):
        # Full override — developer controls the entire prompt
        prompt = (
            f"{cfg['custom_prompt'].strip()}\n\n"
            f"The response is written in {language}. Preserve the language.\n\n"
            f"CRITICAL: Output ONLY the reviewed response. No notes, explanations, or meta-commentary.\n\n"
            f"Response to review:\n{text}"
        )
    else:
        # Build from rules + tone
        rules = list(_DEFAULT_RULES)
        rules.append(f"Is written in {language}")

        tone = cfg.get("tone")
        if tone:
            rules.append(f"Has a {tone} tone")

        for rule in cfg.get("custom_rules") or []:
            rules.append(rule)

        rule_list = "\n".join(f"{i + 1}. {r}" for i, r in enumerate(rules))

        prompt = (
            f"You are a content safety reviewer for a customer-facing chatbot.\n\n"
            f"Review this response and ensure it:\n"
            f"{rule_list}\n\n"
            f"CRITICAL INSTRUCTIONS:\n"
            f"- Output ONLY the reviewed response text\n"
            f"- Do NOT add notes, explanations, or comments about your changes\n"
            f"- Do NOT add meta-commentary like '(Note: ...)' or 'I changed X because Y'\n"
            f"- Do NOT wrap in quotes or add labels\n"
            f"- If the response is already safe, return it word-for-word unchanged\n\n"
            f"Response to review:\n{text}"
        )

    t0 = time.perf_counter()
    try:
        result = llm.invoke(prompt).content.strip()
        elapsed_ms = (time.perf_counter() - t0) * 1000
        logger.debug(
            "[GUARDRAILS] chars=%d→%d  elapsed=%.0fms",
            len(text), len(result), elapsed_ms,
        )
        return result
    except Exception as e:
        logger.error(
            "Guardrails LLM call failed: %s\n"
            "  Fix: Check LLM provider connectivity or disable guardrails in config.yaml.\n"
            "  Returning original text.",
            e
        )
        return text


def humanize_and_guard(
    text: str,
    llm,
    language: str = "English",
    guardrails_cfg: Optional[dict] = None,
) -> str:
    """Humanize AND apply safety guardrails in a single LLM call.

    When humanize is enabled alongside guardrails, this saves one LLM call
    per outgoing bot message by combining both operations into one prompt.

    Args:
        text:           The raw message text to improve.
        llm:            LangChain LLM instance.
        language:       User's language (to preserve in output).
        guardrails_cfg: Merged guardrails config dict. If None, uses defaults.

    Returns:
        Natural-sounding, safe response text. Returns original text on failure.
    """
    # Nothing to improve — return immediately to avoid a wasted LLM call
    if not text or not text.strip():
        return text

    cfg = guardrails_cfg or {}

    # Build safety rules list
    rules = list(_DEFAULT_RULES)
    rules.append(f"Is written in {language}")

    tone = cfg.get("tone")
    if tone:
        rules.append(f"Has a {tone} tone")

    for rule in cfg.get("custom_rules") or []:
        rules.append(rule)

    rule_list = "\n".join(f"{i + 1}. {r}" for i, r in enumerate(rules))

    prompt = (
        f"You are a content safety reviewer AND a natural language editor for a customer-facing chatbot.\n\n"
        f"Review and improve this message:\n"
        f"1. Make it sound natural and conversational (not robotic or like a form)\n"
        f"2. Ensure it follows these safety rules:\n"
        f"{rule_list}\n\n"
        f"CRITICAL: Output ONLY the improved message. No notes, labels, or explanations.\n\n"
        f"Message:\n{text}"
    )

    t0 = time.perf_counter()
    try:
        result = llm.invoke(prompt).content.strip().strip('"').strip("'")
        elapsed_ms = (time.perf_counter() - t0) * 1000
        if result:
            logger.debug(
                "[HUMANIZE+GUARDRAILS] chars=%d→%d  elapsed=%.0fms",
                len(text), len(result), elapsed_ms,
            )
            return result
        return text
    except Exception as e:
        logger.warning(
            "humanize_and_guard LLM call failed: %s. Using original message.", e
        )
        return text
