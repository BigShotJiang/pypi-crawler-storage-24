"""
FlowGraph-AI REST API — V3.

Endpoints:
  POST /workflow/start   — Classify intent + start a new graph thread
  POST /message          — Resume an existing thread with user reply
  GET  /session/{id}     — Inspect current thread state
  GET  /workflows        — List available workflows with descriptions
  GET  /health           — Health + system status

Thread IDs are self-describing: "{workflow_name}:{session_id}"
No in-memory session map needed — workflow name is decoded from the thread_id.

Run with:
  uvicorn api.server:app --reload
"""

import uuid
import time
import logging
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from typing import Any

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import Response, PlainTextResponse
from pydantic import BaseModel
from langgraph.types import Command

from flowgraph_ai.config import load_config
from flowgraph_ai.llm.provider import get_llm
from flowgraph_ai.intent import classify_intent
from flowgraph_ai.engine.graph_builder import GraphBuilder
from flowgraph_ai.engine.workflow_loader import WorkflowLoader
from flowgraph_ai.storage.checkpointer import get_checkpointer
from flowgraph_ai.observability import langfuse_handler as lf
from flowgraph_ai.observability import tracing as otel
from flowgraph_ai.tracking import tracker as task_tracker
from flowgraph_ai.tracking.models import TaskStatus

logger = logging.getLogger("flowgraph.api")


# ── App state (set up once during lifespan) ────────────────────────────────────

@dataclass
class _AppState:
    config: dict
    loader: WorkflowLoader
    builder: GraphBuilder
    checkpointer: Any
    graph_cache: dict = field(default_factory=dict)  # workflow_name → compiled graph

    def get_graph(self, workflow_name: str) -> tuple:
        """Lazy-compile and cache a workflow graph."""
        if workflow_name not in self.graph_cache:
            wf_config = self.loader.load(workflow_name)
            compiled = self.builder.build(wf_config, checkpointer=self.checkpointer)
            self.graph_cache[workflow_name] = (compiled, wf_config)
        return self.graph_cache[workflow_name]


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Bootstrap on startup, clean up on shutdown."""
    config = load_config()
    from flowgraph_ai.core.logging_setup import configure_logging
    configure_logging(config)
    llm = get_llm(config)
    checkpointer = get_checkpointer(config)
    loader = WorkflowLoader(
        fallback_workflow=config.get("intent", {}).get("fallback_workflow", "greeting")
    )
    builder = GraphBuilder(default_llm=llm, app_config=config)

    # Validate fallback workflow exists at startup
    fallback = config.get("intent", {}).get("fallback_workflow", "greeting")
    available = loader.list_workflows()
    if fallback not in available:
        logger.warning(
            "Fallback workflow '%s' not found. Available: %s", fallback, available
        )

    # Boot observability (no-op when disabled in config)
    otel.setup_tracing(config)

    # Initialize task tracker
    tracker_db = config.get("tracking", {}).get("db_path", ":memory:")
    task_tracker.setup_tracker(db_path=tracker_db)

    app.state.flowgraph = _AppState(
        config=config,
        loader=loader,
        builder=builder,
        checkpointer=checkpointer,
    )
    logger.info("FlowGraph-AI started. Workflows: %s", available)
    yield
    lf.flush(config)
    logger.info("FlowGraph-AI shutting down.")


app = FastAPI(
    title="FlowGraph-AI",
    description="YAML-driven AI workflow engine powered by LangGraph",
    version="3.0.0",
    lifespan=lifespan,
)


# ── Request / Response models ──────────────────────────────────────────────────

class StartRequest(BaseModel):
    session_id: str | None = None
    workflow_name: str | None = None
    message: str


class MessageRequest(BaseModel):
    session_id: str
    message: str


class WorkflowResponse(BaseModel):
    session_id: str
    workflow_name: str
    status: str           # waiting_input | completed | error | follow_up
    question: dict | None = None
    output: str | None = None
    error: str | None = None
    task_id: str | None = None
    correlation_id: str | None = None


# ── Thread ID helpers (self-describing, no session map needed) ─────────────────

def _make_thread_id(session_id: str, workflow_name: str) -> str:
    """Encode workflow name into the thread_id so it can be decoded without DB lookup."""
    return f"{workflow_name}:{session_id}"


def _decode_workflow(thread_id: str) -> str:
    """Extract workflow name from a thread_id."""
    return thread_id.split(":", 1)[0]


def _run_cfg(thread_id: str) -> dict:
    return {"configurable": {"thread_id": thread_id}}


# ── Graph invocation ───────────────────────────────────────────────────────────

def _invoke_and_respond(
    compiled, thread_id: str, input_data: Any, config: dict | None = None
) -> WorkflowResponse:
    """Run the graph and return the appropriate response."""
    run_cfg = _run_cfg(thread_id)

    # Inject Langfuse callback when enabled — tracks all LLM calls automatically
    if config:
        workflow_name = _decode_workflow(thread_id)
        handler = lf.get_langfuse_handler(
            config,
            session_id=thread_id,
            trace_name=f"workflow:{workflow_name}",
            metadata={"workflow": workflow_name},
        )
        if handler:
            run_cfg["callbacks"] = [handler]

    compiled.invoke(input_data, run_cfg)
    state = compiled.get_state(_run_cfg(thread_id))

    # Interrupted — waiting for user input
    for task in state.tasks:
        if getattr(task, "interrupts", None):
            question_data = task.interrupts[0].value
            return WorkflowResponse(
                session_id=thread_id,
                workflow_name=_decode_workflow(thread_id),
                status="waiting_input",
                question=question_data,
            )

    # Completed — check for errors first
    values = state.values
    if values.get("error"):
        return WorkflowResponse(
            session_id=thread_id,
            workflow_name=_decode_workflow(thread_id),
            status="error",
            error=values["error"],
        )
    # BUG-005: When max retries are exceeded, response_node may set no output and no error,
    # leaving `values.get("output")` empty. Fall back to a clear failure message rather than
    # the misleading "(completed)".
    output = values.get("output") or (
        "We were unable to complete your request after several attempts. Please try again."
        if values.get("_dc_failed") else "(completed)"
    )
    return WorkflowResponse(
        session_id=thread_id,
        workflow_name=_decode_workflow(thread_id),
        status="completed",
        output=output,
    )


def _handle_follow_up(
    llm, completed_output: str, conversation_history: list,
    user_message: str, workflow_name: str, config: dict
) -> str:
    """Answer a follow-up question in the context of a completed workflow.

    Uses the full conversation history and the bot's final answer as context.
    If the user's question is completely unrelated, gracefully suggests starting
    a new conversation.
    """
    from flowgraph_ai.core.history import format_history
    history_text = format_history(conversation_history or [], max_turns=6)

    prompt = (
        f"A customer service conversation for '{workflow_name}' has just completed.\n\n"
        f"Conversation history:\n{history_text}\n\n"
        f"Your last response was:\n{completed_output}\n\n"
        f"The user is now asking a follow-up question:\n\"{user_message}\"\n\n"
        f"Instructions:\n"
        f"- If the follow-up is related to the same topic (e.g. asking for more details, "
        f"raising a concern, requesting an escalation), answer it helpfully using the "
        f"context above. You may create tickets, provide timelines, or offer next steps.\n"
        f"- If it seems like a completely new request, acknowledge it and suggest starting "
        f"a new conversation: 'It looks like you have a new request — please start a new "
        f"message and I will route you to the right place.'\n"
        f"- Be concise, warm, and helpful.\n\n"
        f"Return ONLY the response text."
    )
    try:
        result = llm.invoke(prompt).content.strip()
        return result or "I'm here to help. Could you please clarify your question?"
    except Exception as e:
        logger.error("[FOLLOW_UP] LLM call failed: %s", e)
        return "I'm sorry, I encountered an error. Please try starting a new conversation."


def _get_state(request: Request) -> _AppState:
    return request.app.state.flowgraph


# ── Endpoints ──────────────────────────────────────────────────────────────────

@app.post("/workflow/start", response_model=WorkflowResponse)
async def start_workflow(req: StartRequest, request: Request) -> WorkflowResponse:
    """Start a new workflow. Intent is auto-classified if workflow_name is omitted."""
    app_state = _get_state(request)

    # BUG-001: Reject empty messages before hitting the LLM classifier
    if not req.message or not req.message.strip():
        raise HTTPException(status_code=422, detail="Message cannot be empty.")

    available = app_state.loader.list_workflows()

    if req.workflow_name:
        # BUG-004: Validate the caller-supplied workflow name; never silently fall back
        if req.workflow_name not in available:
            raise HTTPException(
                status_code=422,
                detail=f"Unknown workflow '{req.workflow_name}'. Available: {available}",
            )
        workflow_name = req.workflow_name
    else:
        workflow_name = classify_intent(
            req.message, app_state.builder._llm,
            config=app_state.config, loader=app_state.loader,
        )

    session_id = req.session_id or uuid.uuid4().hex
    thread_id = _make_thread_id(session_id, workflow_name)

    # Auto-create a task in the tracking system
    import uuid as _uuid
    correlation_id = _uuid.uuid4().hex
    task = task_tracker.create_task(
        session_id=thread_id,
        workflow_name=workflow_name,
        user_request=req.message,
        correlation_id=correlation_id,
    )
    task_tracker.update_task_status(task.task_id, TaskStatus.IN_PROGRESS, description="Workflow started")

    compiled, wf_config = app_state.get_graph(workflow_name)

    initial_field = wf_config.get("initial_input_field", "user_message")
    initial_input = {"user_message": req.message, initial_field: req.message}

    logger.info(
        "[START] workflow=%s  session=%s  message_chars=%d",
        workflow_name, thread_id, len(req.message),
    )
    t0 = time.perf_counter()

    with otel.workflow_span(workflow_name, session_id=thread_id, trigger="start",
                            correlation_id=correlation_id) as span:
        result = _invoke_and_respond(compiled, thread_id, initial_input, config=app_state.config)
        elapsed_ms = (time.perf_counter() - t0) * 1000
        logger.info(
            "[DONE] workflow=%s  session=%s  status=%s  elapsed=%.0fms",
            workflow_name, thread_id, result.status, elapsed_ms,
        )
        if span:
            span.set_attribute("workflow.status", result.status)

        # Update task based on result
        if result.status == "waiting_input":
            task_tracker.update_task_status(task.task_id, TaskStatus.WAITING_INPUT, description="Waiting for user input")
        elif result.status == "completed":
            task_tracker.complete_task(task.task_id, result_summary=result.output[:200] if result.output else None)
        elif result.status == "error":
            task_tracker.fail_task(task.task_id, result.error or "Unknown error")

        result.task_id = task.task_id
        result.correlation_id = correlation_id
        return result


@app.post("/message", response_model=WorkflowResponse)
async def send_message(req: MessageRequest, request: Request) -> WorkflowResponse:
    """Resume an existing session with the user's reply."""
    app_state = _get_state(request)
    thread_id = req.session_id

    workflow_name = _decode_workflow(thread_id)
    available = app_state.loader.list_workflows()
    if workflow_name not in available:
        raise HTTPException(
            status_code=404,
            detail=f"Session '{thread_id}' not found or workflow '{workflow_name}' does not exist.",
        )

    compiled, _ = app_state.get_graph(workflow_name)

    # If the graph has no pending nodes but has state values, it has finished.
    # Instead of rejecting the message, treat it as a follow-up question in context.
    existing_state = compiled.get_state(_run_cfg(thread_id))
    if not existing_state.next and existing_state.values:
        values = existing_state.values
        completed_output = values.get("output") or values.get("error") or ""
        conversation_history = values.get("messages") or []
        logger.info(
            "[FOLLOW_UP] workflow=%s  session=%s  message_chars=%d",
            workflow_name, thread_id, len(req.message),
        )
        # Look up existing task for correlation ID
        existing_task = task_tracker.get_task_by_session(thread_id)
        cid = existing_task.correlation_id if existing_task else ""

        with otel.follow_up_span(workflow_name, session_id=thread_id, correlation_id=cid):
            follow_up_answer = _handle_follow_up(
                llm=app_state.builder._llm,
                completed_output=completed_output,
                conversation_history=conversation_history,
                user_message=req.message,
                workflow_name=workflow_name,
                config=app_state.config,
            )

        # Update task board for follow-up
        if existing_task:
            task_tracker.add_task_event(
                existing_task.task_id, "follow_up",
                f"Follow-up: {req.message[:80]}",
                {"message": req.message[:200]},
            )

        return WorkflowResponse(
            session_id=thread_id,
            workflow_name=workflow_name,
            status="follow_up",
            output=follow_up_answer,
            task_id=existing_task.task_id if existing_task else None,
            correlation_id=cid or None,
        )

    logger.info(
        "[RESUME] workflow=%s  session=%s  message_chars=%d",
        workflow_name, thread_id, len(req.message),
    )
    t0 = time.perf_counter()

    # Look up existing task
    existing_task = task_tracker.get_task_by_session(thread_id)

    with otel.workflow_span(workflow_name, session_id=thread_id, trigger="resume",
                            correlation_id=existing_task.correlation_id if existing_task else "") as span:
        result = _invoke_and_respond(compiled, thread_id, Command(resume=req.message), config=app_state.config)
        elapsed_ms = (time.perf_counter() - t0) * 1000
        logger.info(
            "[DONE] workflow=%s  session=%s  status=%s  elapsed=%.0fms",
            workflow_name, thread_id, result.status, elapsed_ms,
        )
        if span:
            span.set_attribute("workflow.status", result.status)

        # Update task board
        if existing_task:
            if result.status == "waiting_input":
                task_tracker.update_task_status(
                    existing_task.task_id, TaskStatus.WAITING_INPUT,
                    description="Waiting for next user input",
                )
            elif result.status == "completed":
                task_tracker.complete_task(
                    existing_task.task_id,
                    result_summary=result.output[:200] if result.output else None,
                )
            elif result.status == "error":
                task_tracker.fail_task(existing_task.task_id, result.error or "Unknown error")

            result.task_id = existing_task.task_id
            result.correlation_id = existing_task.correlation_id

        return result


@app.get("/session/{session_id:path}")
async def get_session(session_id: str, request: Request) -> dict:
    """Return current state snapshot for a session thread."""
    app_state = _get_state(request)
    workflow_name = _decode_workflow(session_id)
    available = app_state.loader.list_workflows()
    if workflow_name not in available:
        raise HTTPException(status_code=404, detail=f"Session '{session_id}' not found.")

    compiled, _ = app_state.get_graph(workflow_name)
    state = compiled.get_state(_run_cfg(session_id))

    return {
        "session_id": session_id,
        "workflow": workflow_name,
        "next_nodes": list(state.next) if state.next else [],
        "state": {k: v for k, v in state.values.items() if not k.startswith("_")},
    }


@app.get("/workflows")
async def list_workflows(request: Request) -> dict:
    """List all available workflows with their descriptions."""
    app_state = _get_state(request)
    loader = app_state.loader
    workflows = []
    for name in loader.list_workflows():
        meta = loader.load_metadata(name)
        workflows.append({"name": meta["workflow"], "description": meta["description"]})
    return {"workflows": workflows, "count": len(workflows)}


@app.get("/health")
async def health(request: Request) -> dict:
    """System health and configuration summary."""
    app_state = _get_state(request)
    config = app_state.config

    ckpt_conn = config.get("checkpoint", {}).get("connection_string", "")
    if ckpt_conn.startswith(("postgresql://", "postgres://")):
        ckpt_type = "postgres"
    elif ckpt_conn:
        ckpt_type = "sqlite"
    else:
        ckpt_type = "memory"

    return {
        "status": "ok",
        "version": config.get("app", {}).get("version", "3.0.0"),
        "llm_provider": config.get("llm", {}).get("provider", "unknown"),
        "checkpointer": ckpt_type,
        "workflows": app_state.loader.list_workflows(),
        "guardrails": config.get("guardrails", {}).get("enabled", False),
    }

@app.get("/tasks")
async def list_tasks(
    request: Request,
    workflow: str | None = None,
    status: str | None = None,
    limit: int = 50
) -> dict:
    """List all agent tasks for the Kanban board."""
    status_filter = None
    if status:
        try:
            status_filter = TaskStatus(status)
        except ValueError:
            raise HTTPException(status_code=422, detail=f"Invalid status: {status}")

    tasks = task_tracker.list_tasks(limit=limit, workflow_name=workflow, status=status_filter)
    return {
        "tasks": [t.model_dump() for t in tasks],
        "count": len(tasks),
    }


@app.get("/tasks/stream/events")
async def stream_task_events(request: Request):
    """Server-Sent Events stream for real-time task board updates."""
    import asyncio
    from fastapi.responses import StreamingResponse
    import json

    queue: asyncio.Queue = asyncio.Queue()
    loop = asyncio.get_event_loop()

    def on_task_update(task):
        try:
            loop.call_soon_threadsafe(queue.put_nowait, task.model_dump_json())
        except Exception:
            pass

    task_tracker.subscribe(on_task_update)

    async def event_generator():
        try:
            # Send initial snapshot of all tasks
            tasks = task_tracker.list_tasks(limit=100)
            for t in tasks:
                yield f"data: {t.model_dump_json()}\n\n"

            # Stream live updates
            while True:
                if await request.is_disconnected():
                    break
                try:
                    data = await asyncio.wait_for(queue.get(), timeout=15.0)
                    yield f"data: {data}\n\n"
                except asyncio.TimeoutError:
                    yield ": ping\n\n"  # keepalive
        finally:
            task_tracker.unsubscribe(on_task_update)

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
            "Access-Control-Allow-Origin": "*",
        },
    )


@app.get("/tasks/session/{session_id:path}")
async def get_task_by_session(session_id: str, request: Request) -> dict:
    """Get the task for a session."""
    task = task_tracker.get_task_by_session(session_id)
    if not task:
        raise HTTPException(status_code=404, detail=f"No task found for session '{session_id}'.")
    return task.model_dump()


@app.get("/tasks/{task_id}")
async def get_task(task_id: str, request: Request) -> dict:
    """Get a single task by ID."""
    task = task_tracker.get_task(task_id)
    if not task:
        raise HTTPException(status_code=404, detail=f"Task '{task_id}' not found.")
    return task.model_dump()


@app.get("/workflow/{workflow_name}/mermaid")
async def get_workflow_mermaid(workflow_name: str, request: Request) -> PlainTextResponse:
    """Return the raw Mermaid architecture text for a workflow graph."""
    app_state = _get_state(request)
    available = app_state.loader.list_workflows()
    
    if workflow_name not in available:
        raise HTTPException(status_code=404, detail=f"Workflow '{workflow_name}' not found.")
        
    compiled, _ = app_state.get_graph(workflow_name)
    try:
        mermaid_text = compiled.get_graph().draw_mermaid()
        
        # Streamlit's Mermaid parser breaks if the graph has HTML labels. We must strip them.
        mermaid_text = mermaid_text.replace("<p>", "").replace("</p>", "").replace("<b>", "").replace("</b>", "")
        
        return PlainTextResponse(content=mermaid_text)
    except Exception as e:
        logger.error("Failed to generate graph for %s: %s", workflow_name, e)
        raise HTTPException(status_code=500, detail="Failed to generate graph text.")
