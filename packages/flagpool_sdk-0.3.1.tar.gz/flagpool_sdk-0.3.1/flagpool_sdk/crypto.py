"""
Crypto adapter interface for Flagpool SDK

The SDK has NO crypto dependencies. Consumers must provide their own
crypto adapter implementation for client-side target list decryption.
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, Optional
import json


class CryptoAdapter(ABC):
    """
    Abstract base class for crypto adapters.

    Implement this interface to enable client-side target list decryption.
    The SDK has no built-in crypto dependencies - YOU provide the implementation.
    """

    @abstractmethod
    def decrypt(self, ciphertext: str, key: str, iv: str, tag: str) -> str:
        """
        Decrypt AES-256-GCM encrypted data.

        Args:
            ciphertext: Base64 encoded ciphertext
            key: Decryption key string
            iv: Base64 encoded initialization vector (12 bytes)
            tag: Base64 encoded authentication tag (16 bytes)

        Returns:
            Decrypted plaintext string
        """
        pass

    def encrypt(self, plaintext: str, key: str) -> Dict[str, str]:
        """
        Encrypt plaintext with AES-256-GCM (optional).

        Args:
            plaintext: String to encrypt
            key: Encryption key string

        Returns:
            Dict with 'ciphertext', 'iv', 'tag' (all base64 encoded)
        """
        raise NotImplementedError("encrypt() is optional")


# Global crypto adapter instance
_crypto_adapter: Optional[CryptoAdapter] = None


def set_crypto_adapter(adapter: CryptoAdapter) -> None:
    """
    Set the crypto adapter for client-side decryption.

    Call this once at app startup if you need client-side target list evaluation.

    Example:
        from flagpool_sdk import set_crypto_adapter
        from my_crypto import create_python_crypto_adapter

        adapter = create_python_crypto_adapter()
        set_crypto_adapter(adapter)
    """
    global _crypto_adapter
    _crypto_adapter = adapter


def get_crypto_adapter() -> Optional[CryptoAdapter]:
    """Get the current crypto adapter."""
    return _crypto_adapter


def has_crypto_adapter() -> bool:
    """Check if a crypto adapter is available."""
    return _crypto_adapter is not None


def is_encrypted_target_lists(obj: Any) -> bool:
    """Check if an object is encrypted target lists."""
    if not isinstance(obj, dict):
        return False
    return obj.get('_encrypted') is True and obj.get('_algorithm') == 'AES-256-GCM'


def decrypt_target_lists(encrypted_data: Dict[str, Any], decryption_key: str) -> Dict[str, Any]:
    """
    Decrypt target lists with AES-256-GCM.

    Requires a crypto adapter to be set via set_crypto_adapter().

    Args:
        encrypted_data: Dict with _encrypted, _algorithm, _iv, _data, _tag
        decryption_key: The decryption key

    Returns:
        Decrypted target lists dict

    Raises:
        RuntimeError: If no crypto adapter is configured
        ValueError: If encrypted data format is invalid
    """
    if not _crypto_adapter:
        raise RuntimeError(
            "No crypto adapter configured. Either:\n"
            "1. Use server-side target list evaluation (recommended)\n"
            "2. Call set_crypto_adapter() with a platform-specific adapter"
        )

    if not is_encrypted_target_lists(encrypted_data):
        raise ValueError("Invalid encrypted data format")

    plaintext = _crypto_adapter.decrypt(
        ciphertext=encrypted_data['_data'],
        key=decryption_key,
        iv=encrypted_data['_iv'],
        tag=encrypted_data['_tag']
    )

    return json.loads(plaintext)

