"""
Analytics module for tracking flag evaluations.

Features:
- Buffers hits in memory for batching
- Fire-and-forget flush (never blocks evaluation)
- Configurable flush interval (min 30s) and threshold
- Sample rate support for high-volume apps
- Graceful shutdown handling
"""

import atexit
import json
import signal
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Dict, Optional
from urllib.request import Request, urlopen
from urllib.error import URLError

# SDK metadata
SDK_NAME = "python"
SDK_VERSION = "0.3.0"

# Analytics endpoint (Supabase Edge Function)
ANALYTICS_ENDPOINT = "https://tsmnohaxxiwpqvpyeubc.supabase.co/functions/v1/record-hits"

# Minimum flush interval (30 seconds)
MIN_FLUSH_INTERVAL = 30


@dataclass
class AnalyticsConfig:
    """Analytics configuration."""
    enabled: bool = False
    flush_interval: int = 60  # seconds
    flush_threshold: int = 100
    sample_rate: float = 1.0
    sync_flush_on_shutdown: bool = False


@dataclass
class AnalyticsState:
    """Analytics state for debugging."""
    enabled: bool
    buffer: Dict[str, int]
    buffer_size: int
    last_flush: Optional[float]  # timestamp
    total_flushes: int
    total_hits_sent: int
    config: AnalyticsConfig


class HitTracker:
    """
    Tracks flag evaluation hits for analytics.

    Example:
        tracker = HitTracker(
            api_key="env_xxx",
            config=AnalyticsConfig(enabled=True)
        )
        tracker.track("my-flag")
        tracker.destroy()
    """

    def __init__(self, api_key: str, config: Optional[AnalyticsConfig] = None):
        self._api_key = api_key
        self._config = config or AnalyticsConfig()

        # Enforce minimum flush interval
        if self._config.flush_interval < MIN_FLUSH_INTERVAL:
            self._config.flush_interval = MIN_FLUSH_INTERVAL

        self._buffer: Dict[str, int] = {}
        self._lock = threading.Lock()
        self._flush_timer: Optional[threading.Timer] = None
        self._last_flush: Optional[float] = None
        self._total_flushes = 0
        self._total_hits_sent = 0
        self._destroyed = False

        # Setup shutdown handlers if enabled
        if self._config.enabled:
            self._setup_shutdown_handlers()

    def track(self, flag_key: str) -> None:
        """Track a flag evaluation."""
        if not self._config.enabled or self._destroyed:
            return

        # Apply sample rate
        if self._config.sample_rate < 1.0:
            import random
            if random.random() > self._config.sample_rate:
                return

        with self._lock:
            self._buffer[flag_key] = self._buffer.get(flag_key, 0) + 1
            buffer_size = sum(self._buffer.values())

        # Check if we should flush due to threshold
        if buffer_size >= self._config.flush_threshold:
            self.flush_async()
        elif self._flush_timer is None:
            self._schedule_flush()

    def _get_buffer_size(self) -> int:
        """Get total hits in buffer."""
        return sum(self._buffer.values())

    def _schedule_flush(self) -> None:
        """Schedule a flush after the configured interval."""
        if self._flush_timer is not None or self._destroyed:
            return

        self._flush_timer = threading.Timer(
            self._config.flush_interval,
            self._timer_flush
        )
        self._flush_timer.daemon = True
        self._flush_timer.start()

    def _timer_flush(self) -> None:
        """Called by timer to flush."""
        self._flush_timer = None
        self.flush_async()

    def flush_async(self) -> None:
        """Async flush - fire and forget."""
        if self._destroyed:
            return

        with self._lock:
            if not self._buffer:
                return

            # Cancel timer if exists
            if self._flush_timer:
                self._flush_timer.cancel()
                self._flush_timer = None

            # Capture and reset buffer
            hits = self._build_hits_payload()
            hit_count = self._get_buffer_size()
            self._buffer.clear()

        # Fire and forget in background thread
        thread = threading.Thread(
            target=self._send_hits,
            args=(hits, hit_count),
            daemon=True
        )
        thread.start()

    def flush_sync(self) -> None:
        """Sync flush - blocks until complete."""
        if self._destroyed:
            return

        with self._lock:
            if not self._buffer:
                return

            # Cancel timer if exists
            if self._flush_timer:
                self._flush_timer.cancel()
                self._flush_timer = None

            # Capture and reset buffer
            hits = self._build_hits_payload()
            hit_count = self._get_buffer_size()
            self._buffer.clear()

        # Send synchronously
        self._send_hits(hits, hit_count)

    def _build_hits_payload(self) -> Dict[str, int]:
        """Build hits payload from buffer."""
        hits = {}
        for key, count in self._buffer.items():
            # Scale by sample rate if sampling
            if self._config.sample_rate < 1.0:
                hits[key] = round(count / self._config.sample_rate)
            else:
                hits[key] = count
        return hits

    def _send_hits(self, hits: Dict[str, int], hit_count: int) -> None:
        """Send hits to analytics endpoint."""
        try:
            payload = json.dumps({
                "env": self._api_key,
                "hits": hits,
                "sample_rate": self._config.sample_rate,
                "sdk": SDK_NAME,
                "version": SDK_VERSION,
            }).encode('utf-8')

            req = Request(
                ANALYTICS_ENDPOINT,
                data=payload,
                headers={"Content-Type": "application/json"},
                method="POST"
            )

            with urlopen(req, timeout=10) as response:
                # We don't care about the response
                pass

            self._last_flush = time.time()
            self._total_flushes += 1
            self._total_hits_sent += hit_count

        except (URLError, Exception):
            # Silently ignore errors - analytics should never break anything
            pass

    def _setup_shutdown_handlers(self) -> None:
        """Setup shutdown handlers for graceful flush."""
        # Register atexit handler
        atexit.register(self._shutdown_handler)

        # Try to register signal handlers (may fail in some environments)
        try:
            signal.signal(signal.SIGTERM, self._signal_handler)
            signal.signal(signal.SIGINT, self._signal_handler)
        except (ValueError, OSError):
            # Signal handlers can only be set from main thread
            pass

    def _shutdown_handler(self) -> None:
        """Called on process exit."""
        if self._config.sync_flush_on_shutdown:
            self.flush_sync()
        else:
            self.flush_async()

    def _signal_handler(self, signum: int, frame: Any) -> None:
        """Called on SIGTERM/SIGINT."""
        self.flush_sync()

    def get_state(self) -> AnalyticsState:
        """Get current analytics state for debugging."""
        with self._lock:
            buffer_copy = dict(self._buffer)
            buffer_size = sum(buffer_copy.values())

        return AnalyticsState(
            enabled=self._config.enabled,
            buffer=buffer_copy,
            buffer_size=buffer_size,
            last_flush=self._last_flush,
            total_flushes=self._total_flushes,
            total_hits_sent=self._total_hits_sent,
            config=AnalyticsConfig(
                enabled=self._config.enabled,
                flush_interval=self._config.flush_interval,
                flush_threshold=self._config.flush_threshold,
                sample_rate=self._config.sample_rate,
                sync_flush_on_shutdown=self._config.sync_flush_on_shutdown,
            )
        )

    def destroy(self) -> None:
        """Clean up resources."""
        if self._destroyed:
            return

        # Flush remaining hits
        if self._buffer:
            self.flush_sync()

        # Cancel timer
        if self._flush_timer:
            self._flush_timer.cancel()
            self._flush_timer = None

        self._destroyed = True

