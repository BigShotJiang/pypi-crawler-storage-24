"""
Flagpool SDK for Python

A feature flag SDK with local evaluation, deterministic rollouts,
and encrypted target lists.
"""

from .client import FlagpoolClient
from .evaluator import Evaluator
from .types import FlagDefinition, FlagRule, FlagValue
from .crypto import (
    CryptoAdapter,
    set_crypto_adapter,
    get_crypto_adapter,
    has_crypto_adapter,
    decrypt_target_lists,
    is_encrypted_target_lists,
)
from .analytics import AnalyticsConfig, AnalyticsState, HitTracker
from .utils import hash_string
from .hash import flagpool_hash, compute_cdn_url

__version__ = "0.3.0"

__all__ = [
    "FlagpoolClient",
    "Evaluator",
    "FlagDefinition",
    "FlagRule",
    "Variation",
    "CryptoAdapter",
    "set_crypto_adapter",
    "get_crypto_adapter",
    "has_crypto_adapter",
    "decrypt_target_lists",
    "is_encrypted_target_lists",
    "AnalyticsConfig",
    "AnalyticsState",
    "HitTracker",
    "hash_string",
    "flagpool_hash",
    "compute_cdn_url",
]

