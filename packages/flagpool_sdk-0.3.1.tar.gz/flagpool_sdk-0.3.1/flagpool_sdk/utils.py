"""
Utility functions for Flagpool SDK

The hash function MUST produce identical results to the TypeScript implementation
for conformance across all SDK languages.
"""


def hash_string(s: str) -> int:
    """
    Deterministic hash function for rollout bucketing.

    This is a djb2-variant hash that MUST produce identical results
    to the TypeScript implementation:

        hash = 0
        for char in string:
            hash = ((hash << 5) - hash) + charCode
            hash = hash | 0  # Convert to 32-bit signed integer
        return abs(hash)

    Args:
        s: The string to hash

    Returns:
        A positive integer hash value
    """
    hash_val = 0
    for char in s:
        # ((hash << 5) - hash) is equivalent to hash * 31
        hash_val = ((hash_val << 5) - hash_val) + ord(char)
        # Convert to 32-bit signed integer (handle overflow)
        hash_val = hash_val & 0xFFFFFFFF
        if hash_val >= 0x80000000:
            hash_val -= 0x100000000
    return abs(hash_val)


def in_rollout(user_id: str, flag_key: str, percentage: int) -> bool:
    """
    Check if a user is in the rollout for a flag.

    Args:
        user_id: The user identifier
        flag_key: The flag key
        percentage: The rollout percentage (0-100)

    Returns:
        True if the user is in the rollout, False otherwise
    """
    if not user_id:
        return True  # No userId = always in rollout

    hash_val = hash_string(user_id + flag_key)
    bucket = hash_val % 100
    return bucket < percentage

