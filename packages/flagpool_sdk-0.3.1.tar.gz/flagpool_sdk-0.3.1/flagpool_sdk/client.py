"""
Flagpool SDK Client

Main entry point for the Flagpool SDK.
"""

import threading
from typing import Any, Callable, Dict, List, Optional

from .evaluator import Evaluator
from .fetcher import Fetcher
from .hash import compute_cdn_url
from .crypto import (
    decrypt_target_lists,
    has_crypto_adapter,
    is_encrypted_target_lists,
)
from .analytics import HitTracker, AnalyticsConfig, AnalyticsState


class FlagpoolClient:
    """
    Flagpool SDK client for feature flag evaluation.

    Example:
        client = FlagpoolClient(
            project_id='uuid-xxx',
            api_key='fp_production_xxx',
            decryption_key='key_xxx',
            context={'userId': 'user-123', 'plan': 'pro'}
        )
        client.init()

        if client.is_enabled('new-feature'):
            show_new_feature()

        client.close()
    """

    def __init__(
        self,
        project_id: str,
        api_key: str,
        decryption_key: str,
        context: Optional[Dict[str, Any]] = None,
        polling_interval: int = 30,
        url_override: Optional[str] = None,
        analytics: Optional[AnalyticsConfig] = None,
    ):
        """
        Initialize the Flagpool client.

        Args:
            project_id: Project UUID (required for CDN URL generation)
            api_key: Environment-specific API key (required)
            decryption_key: Key for URL hash and target list decryption (required)
            context: User context for flag evaluation
            polling_interval: Polling interval in seconds (default: 30)
            url_override: Complete URL override (bypasses CDN URL computation)
            analytics: Analytics configuration (opt-in, paid plans only)
        """
        if not project_id:
            raise ValueError("project_id is required")
        if not api_key:
            raise ValueError("api_key is required")
        if not decryption_key:
            raise ValueError("decryption_key is required")

        self.project_id = project_id
        self.api_key = api_key
        self.decryption_key = decryption_key
        self._context = context or {}
        self._polling_interval = polling_interval
        self._url_override = url_override

        # Compute the URL to fetch flags from
        self._url = url_override or compute_cdn_url(project_id, decryption_key)

        self._fetcher = Fetcher(
            api_key=api_key,
            url=self._url
        )
        self._evaluator = Evaluator()

        self._flags: List[Dict[str, Any]] = []
        self._target_lists: Optional[Dict[str, Any]] = None
        self._initialized = False
        self._polling_timer: Optional[threading.Timer] = None
        self._change_callbacks: List[Callable[[str, Any], None]] = []
        self._lock = threading.Lock()

        # Track evaluated flags for debugging
        self._evaluated_flags: set = set()

        # Initialize analytics if configured
        self._hit_tracker: Optional[HitTracker] = None
        if analytics and analytics.enabled:
            self._hit_tracker = HitTracker(api_key, analytics)

    def init(self) -> None:
        """
        Initialize the client by fetching flags from the server.

        This must be called before evaluating flags.
        """
        self._fetch_and_update()
        self._initialized = True

        # Start polling if interval > 0
        if self._polling_interval > 0:
            self._start_polling()

    def close(self) -> None:
        """Clean up resources and stop polling."""
        if self._polling_timer:
            self._polling_timer.cancel()
            self._polling_timer = None

        # Clean up analytics
        if self._hit_tracker:
            self._hit_tracker.destroy()
            self._hit_tracker = None

    def is_enabled(self, key: str, default: bool = False) -> bool:
        """
        Check if a boolean flag is enabled.

        Args:
            key: The flag key
            default: Default value if flag not found

        Returns:
            True if flag is enabled, False otherwise
        """
        value = self.get_value(key)
        if value is None:
            return default
        return bool(value)

    def get_value(self, key: str, default: Any = None) -> Any:
        """
        Get the value of a flag.

        Args:
            key: The flag key
            default: Default value if flag not found

        Returns:
            The flag value, or default if not found
        """
        with self._lock:
            for flag in self._flags:
                if flag.get('key') == key:
                    # Track evaluation for analytics
                    self._evaluated_flags.add(key)
                    if self._hit_tracker:
                        self._hit_tracker.track(key)

                    return self._evaluator.evaluate(flag, self._context)
        return default

    def get_variation(self, key: str, default: Any = None) -> Any:
        """Alias for get_value."""
        return self.get_value(key, default)

    def get_all_flags(self) -> Dict[str, Any]:
        """
        Get all evaluated flag values.

        Returns:
            Dict mapping flag keys to evaluated values
        """
        result = {}
        with self._lock:
            for flag in self._flags:
                key = flag.get('key')
                if key:
                    result[key] = self._evaluator.evaluate(flag, self._context)
        return result

    def update_context(self, context: Dict[str, Any]) -> None:
        """
        Update the evaluation context.

        Args:
            context: New context values (merged with existing)
        """
        with self._lock:
            self._context.update(context)

    def on_change(self, callback: Callable[[str, Any], None]) -> None:
        """
        Register a callback for flag changes.

        Args:
            callback: Function called with (flag_key, new_value) on changes
        """
        self._change_callbacks.append(callback)

    def _fetch_and_update(self) -> None:
        """Fetch flags from server and update local state."""
        try:
            data = self._fetcher.fetch_flags(self._context)

            with self._lock:
                old_flags = {f.get('key'): self._evaluator.evaluate(f, self._context)
                            for f in self._flags}

                self._flags = data.get('flags', [])

                # Handle target lists (always client-side evaluation)
                target_lists_data = data.get('targetLists')
                if target_lists_data:
                    if is_encrypted_target_lists(target_lists_data):
                        # Encrypted target lists require a crypto adapter
                        if not has_crypto_adapter():
                            raise RuntimeError(
                                "Encrypted target lists received but no crypto adapter configured. "
                                "Either call set_crypto_adapter() or disable target list encryption "
                                "in the Flagpool dashboard. "
                                "See: https://flagpool.io/docs/sdks/python#target-lists"
                            )
                        # Decrypt target lists using decryption_key
                        self._target_lists = decrypt_target_lists(
                            target_lists_data,
                            self.decryption_key
                        )
                    else:
                        # Use plaintext target lists
                        self._target_lists = target_lists_data

                # Configure evaluator with target lists (always client-side)
                self._evaluator.set_target_lists(
                    self._target_lists,
                    True  # Always client-side evaluation
                )

                # Check for changes and notify
                for flag in self._flags:
                    key = flag.get('key')
                    if key:
                        new_value = self._evaluator.evaluate(flag, self._context)
                        old_value = old_flags.get(key)
                        if old_value != new_value:
                            for callback in self._change_callbacks:
                                try:
                                    callback(key, new_value)
                                except Exception:
                                    pass  # Don't let callback errors break polling

        except Exception as e:
            # Log error but don't crash
            print(f"[FlagpoolClient] Error fetching flags: {e}")

    def _start_polling(self) -> None:
        """Start the polling timer."""
        def poll():
            self._fetch_and_update()
            self._polling_timer = threading.Timer(
                self._polling_interval,
                poll
            )
            self._polling_timer.daemon = True
            self._polling_timer.start()

        self._polling_timer = threading.Timer(self._polling_interval, poll)
        self._polling_timer.daemon = True
        self._polling_timer.start()

    def get_analytics_state(self) -> Optional[AnalyticsState]:
        """
        Get current analytics state for debugging.

        Returns:
            AnalyticsState or None if analytics is not enabled
        """
        if self._hit_tracker:
            return self._hit_tracker.get_state()
        return None

    def get_all_flags_with_state(self) -> Dict[str, Dict[str, Any]]:
        """
        Get all flags with their values and evaluation status.

        Returns:
            Dict mapping flag keys to {value, evaluated} dicts
        """
        result = {}
        with self._lock:
            for flag in self._flags:
                key = flag.get('key')
                if key:
                    result[key] = {
                        'value': self._evaluator.evaluate(flag, self._context),
                        'evaluated': key in self._evaluated_flags,
                    }
        return result

    def flush_analytics(self) -> None:
        """Manually flush analytics buffer."""
        if self._hit_tracker:
            self._hit_tracker.flush_async()
