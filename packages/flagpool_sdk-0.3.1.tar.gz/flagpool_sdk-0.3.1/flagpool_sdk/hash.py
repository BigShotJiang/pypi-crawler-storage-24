"""
Flagpool Hash Function

DJB2 hash algorithm used for CDN URL generation.
This function produces identical output across all SDK languages.

IMPORTANT: Only the decryptionKey is hashed, NOT the apiKey.
This prevents potential API key exposure if the hash is reverse-engineered.
"""


def flagpool_hash(s: str) -> str:
    """
    DJB2 hash algorithm - produces an 8-character hex string

    Args:
        s: The string to hash (typically the decryption key)

    Returns:
        8-character lowercase hex string
    """
    h = 5381
    for c in s:
        h = ((h << 5) + h) ^ ord(c)
        h &= 0xFFFFFFFF  # Keep as 32-bit unsigned
    return format(h, '08x')


def compute_cdn_url(project_id: str, decryption_key: str, base_url: str = 'https://cdn.flagpool.io') -> str:
    """
    Compute the CDN URL for fetching flags

    Args:
        project_id: The project's unique identifier (UUID)
        decryption_key: The environment's decryption key
        base_url: Optional base URL (defaults to cdn.flagpool.io)

    Returns:
        Full URL to the flags JSON file

    URL structure: /flags/{project_id}/{hash}/flags.json
    The project_id ensures uniqueness even if two different projects
    happen to have the same decryption key hash.
    """
    hash_val = flagpool_hash(decryption_key)
    return f"{base_url}/flags/{project_id}/{hash_val}/flags.json"

