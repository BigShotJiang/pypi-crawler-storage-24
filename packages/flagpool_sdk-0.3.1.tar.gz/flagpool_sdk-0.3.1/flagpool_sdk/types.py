"""
Type definitions for Flagpool SDK
"""

from typing import Any, Dict, List, Optional, TypedDict, Union

# Flag value can be any JSON-serializable type
FlagValue = Union[bool, str, int, float, dict, list, None]


class FlagRule(TypedDict, total=False):
    """A targeting rule for flag evaluation"""
    attribute: str
    operator: str  # eq, neq, in, nin, contains, startsWith, inTargetList, notInTargetList
    value: Any
    target_list_key: Optional[str]
    variation: int
    priority: int


class FlagDefinition(TypedDict):
    """A feature flag definition"""
    key: str
    variations: List[FlagValue]  # Array of variation values (not objects)
    default_variation: int
    rollout_percentage: int
    rules: List[FlagRule]


class TargetList(TypedDict):
    """A target list definition"""
    attribute_key: str
    values: List[str]


class EncryptedData(TypedDict):
    """Encrypted target list data"""
    _encrypted: bool
    _algorithm: str
    _iv: str
    _data: str
    _tag: str


# Type alias for decrypted target lists
DecryptedTargetLists = Dict[str, TargetList]

# Type alias for context
Context = Dict[str, Any]

