"""
HTTP fetcher for Flagpool SDK
"""

import json
from typing import Any, Dict, Optional
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError


class Fetcher:
    """
    HTTP client for fetching flag configurations from Flagpool CDN.
    """

    def __init__(
        self,
        api_key: str,
        url: str,
        timeout: int = 10
    ):
        """
        Initialize the fetcher.

        Args:
            api_key: Environment-specific API key
            url: Full URL to fetch flags from (CDN URL or url_override)
            timeout: Request timeout in seconds
        """
        self.api_key = api_key
        self.url = url
        self.timeout = timeout

    def fetch_flags(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Fetch flag configurations from the CDN.

        Args:
            context: User context (for future use)

        Returns:
            Dict containing flags, environment, targetLists

        Raises:
            RuntimeError: If the request fails
        """
        # Make GET request to CDN
        try:
            request = Request(
                self.url,
                headers={
                    'Accept': 'application/json'
                },
                method='GET'
            )

            with urlopen(request, timeout=self.timeout) as response:
                data = json.loads(response.read().decode('utf-8'))
                return data

        except HTTPError as e:
            raise RuntimeError(f"HTTP error fetching flags: {e.code} {e.reason}")
        except URLError as e:
            raise RuntimeError(f"Network error fetching flags: {e.reason}")
        except json.JSONDecodeError as e:
            raise RuntimeError(f"Invalid JSON response: {e}")

