"""
Flag evaluator for Flagpool SDK

Evaluates flags against context using rules, rollout percentages,
and target lists.
"""

from typing import Any, Dict, List, Optional
from .utils import hash_string
from .types import FlagDefinition, FlagRule, DecryptedTargetLists


class Evaluator:
    """
    Evaluates feature flags against user context.

    The evaluation algorithm:
    1. Sort rules by priority (ascending - lower = higher priority)
    2. Evaluate each rule; first match wins
    3. If no rules match, check rollout percentage
    4. If in rollout, return default variation; otherwise return "off" variation
    """

    def __init__(self):
        self._target_lists: Optional[DecryptedTargetLists] = None
        self._client_side_target_lists: bool = False

    def set_target_lists(
        self,
        target_lists: Optional[DecryptedTargetLists],
        client_side_enabled: bool = False
    ) -> None:
        """
        Set target lists for client-side evaluation.

        Args:
            target_lists: Decrypted target lists dict
            client_side_enabled: Whether client-side evaluation is enabled
        """
        self._target_lists = target_lists
        self._client_side_target_lists = client_side_enabled

    def has_target_lists(self) -> bool:
        """Check if client-side target list evaluation is enabled."""
        return self._client_side_target_lists and self._target_lists is not None

    def evaluate(self, flag: Dict[str, Any], context: Dict[str, Any]) -> Any:
        """
        Evaluate a flag with priority-based rules.

        Args:
            flag: The flag definition dict
            context: User context for evaluation

        Returns:
            The evaluated flag value
        """
        # 1. Sort rules by priority (lower = higher priority)
        rules = flag.get('rules', [])
        sorted_rules = sorted(rules, key=lambda r: r.get('priority', 999))

        # 2. Evaluate rules in priority order
        for rule in sorted_rules:
            if self._matches_rule(rule, context):
                variation_index = rule.get('variation', 0)
                variations = flag.get('variations', [])
                if variation_index < len(variations):
                    return variations[variation_index]

        # 3. Check rollout percentage
        rollout_percentage = flag.get('rolloutPercentage', 100)
        if rollout_percentage < 100:
            user_id = context.get('userId') or context.get('id') or ''
            if user_id:
                hash_val = hash_string(str(user_id) + flag.get('key', ''))
                bucket = hash_val % 100
                if bucket >= rollout_percentage:
                    # Out of rollout - return "off" variation (index 1)
                    variations = flag.get('variations', [])
                    if len(variations) > 1:
                        return variations[1]
                    return False

        # 4. Return default variation
        default_idx = flag.get('defaultVariation', 0)
        variations = flag.get('variations', [])
        if default_idx < len(variations):
            return variations[default_idx]

        return None

    def _matches_rule(self, rule: Dict[str, Any], context: Dict[str, Any]) -> bool:
        """Check if a rule matches the given context."""
        operator = rule.get('operator', '')
        attribute = rule.get('attribute', '')

        # Handle target list operators
        if operator in ('inTargetList', 'notInTargetList'):
            return self._evaluate_target_list_rule(rule, context)

        # Get context value
        context_value = context.get(attribute)
        rule_value = rule.get('value')

        # Standard operators
        return self._compare(context_value, operator, rule_value)

    def _evaluate_target_list_rule(
        self,
        rule: Dict[str, Any],
        context: Dict[str, Any]
    ) -> bool:
        """Evaluate inTargetList/notInTargetList rules."""
        target_list_key = rule.get('targetListKey')
        operator = rule.get('operator', '')

        if not target_list_key:
            return False

        # If client-side target lists are enabled, evaluate locally
        if self._client_side_target_lists and self._target_lists:
            target_list = self._target_lists.get(target_list_key)

            if not target_list:
                return False

            attribute_key = target_list.get('attributeKey', '')
            context_value = context.get(attribute_key)

            if context_value is None:
                return operator == 'notInTargetList'

            values = target_list.get('values', [])
            is_in_list = str(context_value) in values

            return is_in_list if operator == 'inTargetList' else not is_in_list

        # Server-side evaluation fallback
        attribute = rule.get('attribute', '')
        context_value = context.get(attribute)
        return context_value is not None

    def _compare(self, context_value: Any, operator: str, rule_value: Any) -> bool:
        """Compare context value against rule value using the specified operator."""
        if operator == 'eq':
            return context_value == rule_value

        elif operator == 'neq':
            return context_value != rule_value

        elif operator == 'in':
            if not isinstance(rule_value, list):
                return False
            return context_value in rule_value

        elif operator == 'nin':
            if not isinstance(rule_value, list):
                return True
            return context_value not in rule_value

        elif operator == 'contains':
            if context_value is None:
                return False
            return str(rule_value) in str(context_value)

        elif operator == 'startsWith':
            if context_value is None:
                return False
            return str(context_value).startswith(str(rule_value))

        return False

