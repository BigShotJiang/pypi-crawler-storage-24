"""
Tests for the flagpool_hash function (DJB2 algorithm)

These test vectors must produce identical results across all SDK languages.
"""

import pytest
from flagpool_sdk.hash import flagpool_hash, compute_cdn_url


class TestFlagpoolHash:
    """Test the DJB2 hash function for CDN URL generation"""

    # Test vectors - these must produce identical results across all SDK languages
    test_vectors = [
        ("", "00001505", "Empty string"),
        ("a", "0002b5c4", "Single character"),
        ("abc", "0b873285", "Short string"),
        ("hello world", "f8c65345", "Common test string"),
        ("decryption-key-abc123", "e073d987", "Sample decryption key"),
        ("fp_dec_prod_a1b2c3d4e5f6", "682482a7", "Realistic decryption key"),
        ("fp_dec_staging_xyz789", "3c2446c2", "Another realistic key"),
        ("very-long-decryption-key-with-lots-of-characters-1234567890", "771defa1", "Long key"),
    ]

    @pytest.mark.parametrize("input_str,expected,description", test_vectors)
    def test_hash_vectors(self, input_str: str, expected: str, description: str):
        """Test that hash produces correct output for all test vectors"""
        actual = flagpool_hash(input_str)
        assert actual == expected, f"Failed for {description}: got {actual}, expected {expected}"

    def test_returns_8_char_lowercase_hex(self):
        """Test that hash always returns 8-character lowercase hex string"""
        test_inputs = ["", "a", "test", "longer-string-here", "12345"]
        for input_str in test_inputs:
            hash_val = flagpool_hash(input_str)
            assert len(hash_val) == 8, f"Hash of '{input_str}' should be 8 chars"
            assert all(c in "0123456789abcdef" for c in hash_val), f"Hash of '{input_str}' should be lowercase hex"
            # Ensure no uppercase letters
            assert hash_val == hash_val.lower(), f"Hash of '{input_str}' should not have uppercase"

    def test_deterministic(self):
        """Test that hash is deterministic"""
        input_str = "test-decryption-key"
        hash1 = flagpool_hash(input_str)
        hash2 = flagpool_hash(input_str)
        assert hash1 == hash2, "Hash should be deterministic"

    def test_different_inputs_different_hashes(self):
        """Test that different inputs produce different hashes"""
        hash1 = flagpool_hash("key1")
        hash2 = flagpool_hash("key2")
        assert hash1 != hash2, "Different inputs should produce different hashes"


class TestComputeCdnUrl:
    """Test CDN URL generation"""

    test_project_id = "550e8400-e29b-41d4-a716-446655440000"

    def test_default_base_url(self):
        """Test CDN URL with default base URL"""
        url = compute_cdn_url(self.test_project_id, "fp_dec_prod_a1b2c3d4e5f6")
        assert url == f"https://cdn.flagpool.io/flags/{self.test_project_id}/682482a7/flags.json"

    def test_custom_base_url(self):
        """Test CDN URL with custom base URL"""
        url = compute_cdn_url(self.test_project_id, "fp_dec_prod_a1b2c3d4e5f6", "https://custom.cdn.com")
        assert url == f"https://custom.cdn.com/flags/{self.test_project_id}/682482a7/flags.json"

    def test_uses_hash_in_url(self):
        """Test that the URL contains the hash of the decryption key"""
        decryption_key = "my-secret-key"
        expected_hash = flagpool_hash(decryption_key)
        url = compute_cdn_url(self.test_project_id, decryption_key)
        assert f"/flags/{self.test_project_id}/{expected_hash}/" in url

    def test_includes_project_id_in_url(self):
        """Test that the URL includes project_id in path"""
        project_id = "my-project-uuid"
        url = compute_cdn_url(project_id, "any-key")
        assert f"/flags/{project_id}/" in url

    def test_different_urls_for_different_projects(self):
        """Test that same key but different projects produce different URLs"""
        key = "same-decryption-key"
        url1 = compute_cdn_url("project-1", key)
        url2 = compute_cdn_url("project-2", key)
        assert url1 != url2
        # But the hash part should be the same
        assert url1.split("/")[-2] == url2.split("/")[-2]


