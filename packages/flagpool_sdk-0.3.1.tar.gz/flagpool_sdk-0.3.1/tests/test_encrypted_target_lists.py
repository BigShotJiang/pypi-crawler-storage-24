"""
Tests for encrypted target lists behavior when no crypto adapter is configured.
"""

import pytest
from flagpool_sdk.crypto import set_crypto_adapter, is_encrypted_target_lists, has_crypto_adapter


class TestEncryptedTargetListsNoCryptoAdapter:
    """Test that SDK throws error when encrypted target lists received without crypto adapter."""

    def setup_method(self):
        """Clear crypto adapter before each test."""
        set_crypto_adapter(None)

    def test_is_encrypted_target_lists_detection(self):
        """Test detection of encrypted target lists format."""
        encrypted = {
            "_encrypted": True,
            "_algorithm": "AES-256-GCM",
            "_iv": "dGVzdC1pdi0xMjM0",
            "_data": "ZW5jcnlwdGVkLWRhdGEtaGVyZQ==",
            "_tag": "dGVzdC10YWctMTIzNA=="
        }
        assert is_encrypted_target_lists(encrypted) is True

    def test_plaintext_target_lists_not_detected_as_encrypted(self):
        """Test that plaintext target lists are not detected as encrypted."""
        plaintext = {
            "beta-testers": {
                "attributeKey": "userId",
                "values": ["beta-1", "beta-2"]
            }
        }
        assert is_encrypted_target_lists(plaintext) is False

    def test_no_crypto_adapter_by_default(self):
        """Test that no crypto adapter is configured by default."""
        set_crypto_adapter(None)
        assert has_crypto_adapter() is False

    def test_error_message_mentions_crypto_adapter(self):
        """Test that error message mentions 'crypto adapter' when decryption fails."""
        from flagpool_sdk.crypto import decrypt_target_lists

        encrypted = {
            "_encrypted": True,
            "_algorithm": "AES-256-GCM",
            "_iv": "dGVzdC1pdi0xMjM0",
            "_data": "ZW5jcnlwdGVkLWRhdGEtaGVyZQ==",
            "_tag": "dGVzdC10YWctMTIzNA=="
        }

        with pytest.raises(RuntimeError) as exc_info:
            decrypt_target_lists(encrypted, "test-key")

        assert "crypto adapter" in str(exc_info.value).lower()


class TestPlaintextTargetLists:
    """Test that plaintext target lists work without crypto adapter."""

    def setup_method(self):
        """Clear crypto adapter before each test."""
        set_crypto_adapter(None)

    def test_plaintext_format_accepted(self):
        """Test that plaintext target lists are correctly identified."""
        plaintext = {
            "beta-testers": {
                "attributeKey": "userId",
                "values": ["beta-1", "beta-2", "qa-user-1"]
            },
            "blocked-users": {
                "attributeKey": "userId",
                "values": ["blocked-1", "spammer-1"]
            }
        }

        # Should not be detected as encrypted
        assert is_encrypted_target_lists(plaintext) is False

        # Each list should have the expected structure
        assert "attributeKey" in plaintext["beta-testers"]
        assert "values" in plaintext["beta-testers"]
        assert len(plaintext["beta-testers"]["values"]) == 3

