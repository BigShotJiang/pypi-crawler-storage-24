"""
Tests for the Analytics module (HitTracker, AnalyticsConfig, AnalyticsState).
"""

import time
import threading
import pytest
from flagpool_sdk.analytics import AnalyticsConfig, AnalyticsState, HitTracker, MIN_FLUSH_INTERVAL


# ---------------------------------------------------------------------------
# AnalyticsConfig
# ---------------------------------------------------------------------------

class TestAnalyticsConfig:
    def test_default_values(self):
        config = AnalyticsConfig()
        assert config.enabled is False
        assert config.flush_interval == 60
        assert config.flush_threshold == 100
        assert config.sample_rate == 1.0
        assert config.sync_flush_on_shutdown is False

    def test_custom_values(self):
        config = AnalyticsConfig(
            enabled=True,
            flush_interval=120,
            flush_threshold=50,
            sample_rate=0.5,
            sync_flush_on_shutdown=True,
        )
        assert config.enabled is True
        assert config.flush_interval == 120
        assert config.flush_threshold == 50
        assert config.sample_rate == 0.5
        assert config.sync_flush_on_shutdown is True


# ---------------------------------------------------------------------------
# HitTracker — creation & config
# ---------------------------------------------------------------------------

class TestHitTrackerCreation:
    def test_creates_with_default_config(self):
        tracker = HitTracker("env_xxx")
        state = tracker.get_state()
        assert state.enabled is False
        tracker.destroy()

    def test_creates_disabled_by_default(self):
        config = AnalyticsConfig()
        tracker = HitTracker("env_xxx", config)
        state = tracker.get_state()
        assert state.enabled is False
        tracker.destroy()

    def test_enforces_minimum_flush_interval(self):
        """Flush intervals below 30s should be clamped to 30s."""
        config = AnalyticsConfig(enabled=True, flush_interval=5)
        tracker = HitTracker("env_xxx", config)
        # The internal config should have been clamped
        assert tracker._config.flush_interval == MIN_FLUSH_INTERVAL
        tracker.destroy()

    def test_accepts_exactly_minimum_flush_interval(self):
        config = AnalyticsConfig(enabled=True, flush_interval=MIN_FLUSH_INTERVAL)
        tracker = HitTracker("env_xxx", config)
        assert tracker._config.flush_interval == MIN_FLUSH_INTERVAL
        tracker.destroy()

    def test_accepts_above_minimum_flush_interval(self):
        config = AnalyticsConfig(enabled=True, flush_interval=60)
        tracker = HitTracker("env_xxx", config)
        assert tracker._config.flush_interval == 60
        tracker.destroy()


# ---------------------------------------------------------------------------
# HitTracker — track()
# ---------------------------------------------------------------------------

class TestHitTrackerTrack:
    def _make_tracker(self, **kwargs):
        config = AnalyticsConfig(enabled=True, flush_threshold=10000, **kwargs)
        return HitTracker("env_xxx", config)

    def test_track_is_noop_when_disabled(self):
        config = AnalyticsConfig(enabled=False)
        tracker = HitTracker("env_xxx", config)
        tracker.track("flag-a")
        tracker.track("flag-a")
        state = tracker.get_state()
        assert state.buffer_size == 0
        assert state.buffer == {}
        tracker.destroy()

    def test_track_increments_buffer(self):
        tracker = self._make_tracker()
        tracker.track("flag-a")
        tracker.track("flag-a")
        tracker.track("flag-b")
        state = tracker.get_state()
        assert state.buffer["flag-a"] == 2
        assert state.buffer["flag-b"] == 1
        assert state.buffer_size == 3
        tracker.destroy()

    def test_track_multiple_flags(self):
        tracker = self._make_tracker()
        tracker.track("flag-1")
        tracker.track("flag-2")
        tracker.track("flag-3")
        tracker.track("flag-1")
        state = tracker.get_state()
        assert state.buffer["flag-1"] == 2
        assert state.buffer["flag-2"] == 1
        assert state.buffer["flag-3"] == 1
        assert state.buffer_size == 4
        tracker.destroy()

    def test_track_is_noop_after_destroy(self):
        tracker = self._make_tracker()
        tracker.destroy()
        tracker.track("flag-a")  # Should not raise
        # Can't check buffer after destroy, just ensure no exception

    def test_sample_rate_zero_never_tracks(self):
        tracker = self._make_tracker(sample_rate=0.0)
        for _ in range(100):
            tracker.track("flag-a")
        state = tracker.get_state()
        assert state.buffer_size == 0
        tracker.destroy()

    def test_sample_rate_one_always_tracks(self):
        tracker = self._make_tracker(sample_rate=1.0)
        for _ in range(10):
            tracker.track("flag-a")
        state = tracker.get_state()
        assert state.buffer_size == 10
        tracker.destroy()

    def test_sample_rate_partial(self):
        """With 50% sample rate over 1000 iterations, expect roughly 500 ± 200."""
        tracker = self._make_tracker(sample_rate=0.5)
        for _ in range(1000):
            tracker.track("flag-a")
        state = tracker.get_state()
        # Should be roughly 500, definitely not 0 or 1000
        assert 200 < state.buffer_size < 800
        tracker.destroy()

    def test_track_thread_safe(self):
        """Concurrent tracking from multiple threads should not lose counts."""
        tracker = self._make_tracker()
        threads = []
        count = 100
        num_threads = 10

        def do_track():
            for _ in range(count):
                tracker.track("flag-a")

        for _ in range(num_threads):
            t = threading.Thread(target=do_track)
            threads.append(t)
            t.start()

        for t in threads:
            t.join()

        state = tracker.get_state()
        assert state.buffer["flag-a"] == count * num_threads
        tracker.destroy()


# ---------------------------------------------------------------------------
# HitTracker — get_state()
# ---------------------------------------------------------------------------

class TestHitTrackerGetState:
    def test_initial_state(self):
        config = AnalyticsConfig(enabled=True, flush_threshold=10000)
        tracker = HitTracker("env_xxx", config)
        state = tracker.get_state()

        assert state.enabled is True
        assert state.buffer == {}
        assert state.buffer_size == 0
        assert state.last_flush is None
        assert state.total_flushes == 0
        assert state.total_hits_sent == 0
        tracker.destroy()

    def test_state_reflects_tracks(self):
        config = AnalyticsConfig(enabled=True, flush_threshold=10000)
        tracker = HitTracker("env_xxx", config)

        tracker.track("flag-x")
        tracker.track("flag-x")
        tracker.track("flag-y")

        state = tracker.get_state()
        assert state.buffer_size == 3
        assert state.buffer["flag-x"] == 2
        assert state.buffer["flag-y"] == 1
        tracker.destroy()

    def test_state_buffer_is_snapshot(self):
        """Modifying state.buffer after get_state() should not affect internal buffer."""
        config = AnalyticsConfig(enabled=True, flush_threshold=10000)
        tracker = HitTracker("env_xxx", config)

        tracker.track("flag-x")
        state = tracker.get_state()
        assert state.buffer["flag-x"] == 1

        tracker.track("flag-x")
        # The old snapshot should not have changed
        assert state.buffer["flag-x"] == 1
        tracker.destroy()


# ---------------------------------------------------------------------------
# HitTracker — flush_async()
# ---------------------------------------------------------------------------

class TestHitTrackerFlushAsync:
    def test_flush_async_clears_buffer(self):
        config = AnalyticsConfig(enabled=True, flush_threshold=10000)
        tracker = HitTracker("env_xxx", config)

        tracker.track("flag-a")
        tracker.track("flag-b")
        assert tracker.get_state().buffer_size == 2

        tracker.flush_async()

        # Buffer should be cleared immediately (HTTP is fire-and-forget in background)
        state = tracker.get_state()
        assert state.buffer_size == 0
        tracker.destroy()

    def test_flush_async_noop_on_empty_buffer(self):
        config = AnalyticsConfig(enabled=True, flush_threshold=10000)
        tracker = HitTracker("env_xxx", config)
        # Should not raise
        tracker.flush_async()
        tracker.destroy()

    def test_flush_async_noop_after_destroy(self):
        config = AnalyticsConfig(enabled=True, flush_threshold=10000)
        tracker = HitTracker("env_xxx", config)
        tracker.destroy()
        tracker.flush_async()  # Should not raise


# ---------------------------------------------------------------------------
# HitTracker — destroy()
# ---------------------------------------------------------------------------

class TestHitTrackerDestroy:
    def test_destroy_is_idempotent(self):
        config = AnalyticsConfig(enabled=True, flush_threshold=10000)
        tracker = HitTracker("env_xxx", config)
        tracker.destroy()
        tracker.destroy()  # Should not raise
        tracker.destroy()

    def test_destroy_sets_destroyed_flag(self):
        config = AnalyticsConfig(enabled=True, flush_threshold=10000)
        tracker = HitTracker("env_xxx", config)
        assert tracker._destroyed is False
        tracker.destroy()
        assert tracker._destroyed is True

    def test_destroy_cancels_flush_timer(self):
        config = AnalyticsConfig(enabled=True, flush_threshold=10000)
        tracker = HitTracker("env_xxx", config)
        # Force a timer to be scheduled by tracking
        tracker.track("flag-a")
        # Timer may or may not have started, but destroy should cancel it
        tracker.destroy()
        assert tracker._flush_timer is None

