"""
Test the evaluator for conformance with TypeScript SDK.

These tests verify that flag evaluation produces identical results
across all SDK languages.
"""

import pytest
from flagpool_sdk.evaluator import Evaluator


class TestEvaluator:
    """Test cases for the Evaluator class."""

    @pytest.fixture
    def evaluator(self):
        """Create a fresh evaluator for each test."""
        return Evaluator()

    # =========================================
    # BOOLEAN FLAG TESTS
    # =========================================

    def test_simple_boolean_default_true(self, evaluator):
        """Simple boolean flag with default true, 100% rollout."""
        flag = {
            'key': 'boolean-simple',
            'variations': [
                True,
                False
            ],
            'defaultVariation': 0,
            'rolloutPercentage': 100,
            'rules': []
        }
        result = evaluator.evaluate(flag, {'userId': 'any-user'})
        assert result is True

    def test_simple_boolean_no_user_id(self, evaluator):
        """Simple boolean flag works without userId."""
        flag = {
            'key': 'boolean-simple',
            'variations': [
                True,
                False
            ],
            'defaultVariation': 0,
            'rolloutPercentage': 100,
            'rules': []
        }
        result = evaluator.evaluate(flag, {})
        assert result is True

    def test_rollout_user_in_50_percent(self, evaluator):
        """User in 50% rollout should get default value."""
        flag = {
            'key': 'boolean-with-rollout',
            'variations': [
                True,
                False
            ],
            'defaultVariation': 0,
            'rolloutPercentage': 50,
            'rules': []
        }
        # rollout-user-3 has hash % 100 = 48 < 50
        result = evaluator.evaluate(flag, {'userId': 'rollout-user-3'})
        assert result is True

    def test_rollout_user_out_of_50_percent(self, evaluator):
        """User out of 50% rollout should get off value."""
        flag = {
            'key': 'boolean-with-rollout',
            'variations': [
                True,
                False
            ],
            'defaultVariation': 0,
            'rolloutPercentage': 50,
            'rules': []
        }
        # rollout-user-7 has hash % 100 = 96 >= 50
        result = evaluator.evaluate(flag, {'userId': 'rollout-user-7'})
        assert result is False

    # =========================================
    # CONTAINS OPERATOR TESTS
    # =========================================

    def test_contains_match(self, evaluator):
        """Contains operator should match substring."""
        flag = {
            'key': 'test-flag',
            'variations': [
                True,
                False
            ],
            'defaultVariation': 1,
            'rolloutPercentage': 100,
            'rules': [{
                'attribute': 'email',
                'operator': 'contains',
                'value': '@flagpool.io',
                'variation': 0,
                'priority': 1
            }]
        }
        result = evaluator.evaluate(flag, {'userId': 'u1', 'email': 'dev@flagpool.io'})
        assert result is True

    def test_contains_no_match(self, evaluator):
        """Contains operator should not match when substring missing."""
        flag = {
            'key': 'test-flag',
            'variations': [
                True,
                False
            ],
            'defaultVariation': 1,
            'rolloutPercentage': 100,
            'rules': [{
                'attribute': 'email',
                'operator': 'contains',
                'value': '@flagpool.io',
                'variation': 0,
                'priority': 1
            }]
        }
        result = evaluator.evaluate(flag, {'userId': 'u1', 'email': 'user@gmail.com'})
        assert result is False

    def test_contains_missing_attribute(self, evaluator):
        """Contains operator should not match when attribute missing."""
        flag = {
            'key': 'test-flag',
            'variations': [
                True,
                False
            ],
            'defaultVariation': 1,
            'rolloutPercentage': 100,
            'rules': [{
                'attribute': 'email',
                'operator': 'contains',
                'value': '@flagpool.io',
                'variation': 0,
                'priority': 1
            }]
        }
        result = evaluator.evaluate(flag, {'userId': 'u1'})
        assert result is False

    # =========================================
    # EQ OPERATOR TESTS
    # =========================================

    def test_eq_match(self, evaluator):
        """Eq operator should match exact value."""
        flag = {
            'key': 'test-flag',
            'variations': [
                True,
                False
            ],
            'defaultVariation': 1,
            'rolloutPercentage': 100,
            'rules': [{
                'attribute': 'plan',
                'operator': 'eq',
                'value': 'enterprise',
                'variation': 0,
                'priority': 1
            }]
        }
        result = evaluator.evaluate(flag, {'userId': 'u1', 'plan': 'enterprise'})
        assert result is True

    def test_eq_no_match(self, evaluator):
        """Eq operator should not match different value."""
        flag = {
            'key': 'test-flag',
            'variations': [
                True,
                False
            ],
            'defaultVariation': 1,
            'rolloutPercentage': 100,
            'rules': [{
                'attribute': 'plan',
                'operator': 'eq',
                'value': 'enterprise',
                'variation': 0,
                'priority': 1
            }]
        }
        result = evaluator.evaluate(flag, {'userId': 'u1', 'plan': 'pro'})
        assert result is False

    def test_eq_case_sensitive(self, evaluator):
        """Eq operator should be case sensitive."""
        flag = {
            'key': 'test-flag',
            'variations': [
                True,
                False
            ],
            'defaultVariation': 1,
            'rolloutPercentage': 100,
            'rules': [{
                'attribute': 'plan',
                'operator': 'eq',
                'value': 'enterprise',
                'variation': 0,
                'priority': 1
            }]
        }
        result = evaluator.evaluate(flag, {'userId': 'u1', 'plan': 'Enterprise'})
        assert result is False

    # =========================================
    # NEQ OPERATOR TESTS
    # =========================================

    def test_neq_match(self, evaluator):
        """Neq operator should match when values differ."""
        flag = {
            'key': 'test-flag',
            'variations': [
                True,
                False
            ],
            'defaultVariation': 1,
            'rolloutPercentage': 100,
            'rules': [{
                'attribute': 'plan',
                'operator': 'neq',
                'value': 'free',
                'variation': 0,
                'priority': 1
            }]
        }
        result = evaluator.evaluate(flag, {'userId': 'u1', 'plan': 'pro'})
        assert result is True

    def test_neq_no_match(self, evaluator):
        """Neq operator should not match when values equal."""
        flag = {
            'key': 'test-flag',
            'variations': [
                True,
                False
            ],
            'defaultVariation': 1,
            'rolloutPercentage': 100,
            'rules': [{
                'attribute': 'plan',
                'operator': 'neq',
                'value': 'free',
                'variation': 0,
                'priority': 1
            }]
        }
        result = evaluator.evaluate(flag, {'userId': 'u1', 'plan': 'free'})
        assert result is False

    def test_neq_missing_attribute(self, evaluator):
        """Neq operator should match when attribute is missing (None != value)."""
        flag = {
            'key': 'test-flag',
            'variations': [
                True,
                False
            ],
            'defaultVariation': 1,
            'rolloutPercentage': 100,
            'rules': [{
                'attribute': 'plan',
                'operator': 'neq',
                'value': 'free',
                'variation': 0,
                'priority': 1
            }]
        }
        result = evaluator.evaluate(flag, {'userId': 'u1'})
        assert result is True  # None != 'free'

    # =========================================
    # IN OPERATOR TESTS
    # =========================================

    def test_in_match(self, evaluator):
        """In operator should match when value in list."""
        flag = {
            'key': 'test-flag',
            'variations': [
                'blue',
                'green'
            ],
            'defaultVariation': 0,
            'rolloutPercentage': 100,
            'rules': [{
                'attribute': 'country',
                'operator': 'in',
                'value': ['US', 'CA'],
                'variation': 1,
                'priority': 1
            }]
        }
        result = evaluator.evaluate(flag, {'userId': 'u1', 'country': 'US'})
        assert result == 'green'

    def test_in_no_match(self, evaluator):
        """In operator should not match when value not in list."""
        flag = {
            'key': 'test-flag',
            'variations': [
                'blue',
                'green'
            ],
            'defaultVariation': 0,
            'rolloutPercentage': 100,
            'rules': [{
                'attribute': 'country',
                'operator': 'in',
                'value': ['US', 'CA'],
                'variation': 1,
                'priority': 1
            }]
        }
        result = evaluator.evaluate(flag, {'userId': 'u1', 'country': 'JP'})
        assert result == 'blue'

    # =========================================
    # NIN OPERATOR TESTS
    # =========================================

    def test_nin_match(self, evaluator):
        """Nin operator should match when value not in list."""
        flag = {
            'key': 'test-flag',
            'variations': [
                'standard',
                'restricted'
            ],
            'defaultVariation': 0,
            'rolloutPercentage': 100,
            'rules': [{
                'attribute': 'country',
                'operator': 'nin',
                'value': ['US', 'CA', 'UK'],
                'variation': 1,
                'priority': 1
            }]
        }
        result = evaluator.evaluate(flag, {'userId': 'u1', 'country': 'BR'})
        assert result == 'restricted'

    def test_nin_no_match(self, evaluator):
        """Nin operator should not match when value in list."""
        flag = {
            'key': 'test-flag',
            'variations': [
                'standard',
                'restricted'
            ],
            'defaultVariation': 0,
            'rolloutPercentage': 100,
            'rules': [{
                'attribute': 'country',
                'operator': 'nin',
                'value': ['US', 'CA', 'UK'],
                'variation': 1,
                'priority': 1
            }]
        }
        result = evaluator.evaluate(flag, {'userId': 'u1', 'country': 'US'})
        assert result == 'standard'

    # =========================================
    # STARTSWITH OPERATOR TESTS
    # =========================================

    def test_startswith_match(self, evaluator):
        """StartsWith operator should match prefix."""
        flag = {
            'key': 'test-flag',
            'variations': [
                True,
                False
            ],
            'defaultVariation': 1,
            'rolloutPercentage': 100,
            'rules': [{
                'attribute': 'userId',
                'operator': 'startsWith',
                'value': 'admin-',
                'variation': 0,
                'priority': 1
            }]
        }
        result = evaluator.evaluate(flag, {'userId': 'admin-123'})
        assert result is True

    def test_startswith_no_match(self, evaluator):
        """StartsWith operator should not match when prefix missing."""
        flag = {
            'key': 'test-flag',
            'variations': [
                True,
                False
            ],
            'defaultVariation': 1,
            'rolloutPercentage': 100,
            'rules': [{
                'attribute': 'userId',
                'operator': 'startsWith',
                'value': 'admin-',
                'variation': 0,
                'priority': 1
            }]
        }
        result = evaluator.evaluate(flag, {'userId': 'user-admin-123'})
        assert result is False

    # =========================================
    # PRIORITY TESTS
    # =========================================

    def test_priority_first_match_wins(self, evaluator):
        """Higher priority rule (lower number) should win."""
        flag = {
            'key': 'priority-test',
            'variations': [
                'default',
                'priority-1',
                'priority-2'
            ],
            'defaultVariation': 0,
            'rolloutPercentage': 100,
            'rules': [
                {
                    'attribute': 'tier',
                    'operator': 'eq',
                    'value': 'vip',
                    'variation': 1,
                    'priority': 1
                },
                {
                    'attribute': 'tier',
                    'operator': 'eq',
                    'value': 'premium',
                    'variation': 2,
                    'priority': 2
                }
            ]
        }
        result = evaluator.evaluate(flag, {'userId': 'u1', 'tier': 'vip'})
        assert result == 'priority-1'

    # =========================================
    # NUMBER FLAG TESTS
    # =========================================

    def test_number_flag_tiered(self, evaluator):
        """Number flag with tiered values."""
        flag = {
            'key': 'number-tiered',
            'variations': [
                100,
                500,
                2000
            ],
            'defaultVariation': 0,
            'rolloutPercentage': 100,
            'rules': [
                {
                    'attribute': 'plan',
                    'operator': 'eq',
                    'value': 'enterprise',
                    'variation': 2,
                    'priority': 1
                },
                {
                    'attribute': 'plan',
                    'operator': 'eq',
                    'value': 'pro',
                    'variation': 1,
                    'priority': 2
                }
            ]
        }

        assert evaluator.evaluate(flag, {'userId': 'u1', 'plan': 'enterprise'}) == 2000
        assert evaluator.evaluate(flag, {'userId': 'u1', 'plan': 'pro'}) == 500
        assert evaluator.evaluate(flag, {'userId': 'u1', 'plan': 'free'}) == 100

    # =========================================
    # JSON FLAG TESTS
    # =========================================

    def test_json_flag(self, evaluator):
        """JSON flag with complex object value."""
        flag = {
            'key': 'json-config',
            'variations': [
                {
                    'theme': 'modern',
                    'maxItems': 50,
                    'features': ['basic', 'advanced']
                },
                {
                    'theme': 'classic',
                    'maxItems': 10,
                    'features': ['basic']
                }
            ],
            'defaultVariation': 0,
            'rolloutPercentage': 100,
            'rules': [{
                'attribute': 'plan',
                'operator': 'eq',
                'value': 'free',
                'variation': 1,
                'priority': 1
            }]
        }

        result = evaluator.evaluate(flag, {'userId': 'u1', 'plan': 'pro'})
        assert result == {'theme': 'modern', 'maxItems': 50, 'features': ['basic', 'advanced']}

        result = evaluator.evaluate(flag, {'userId': 'u1', 'plan': 'free'})
        assert result == {'theme': 'classic', 'maxItems': 10, 'features': ['basic']}

    # =========================================
    # TARGET LIST TESTS
    # =========================================

    def test_in_target_list(self, evaluator):
        """InTargetList operator with client-side evaluation."""
        # Set up target lists
        evaluator.set_target_lists({
            'beta-testers': {
                'attributeKey': 'userId',
                'values': ['beta-1', 'beta-2', 'qa-user-1']
            }
        }, client_side_enabled=True)

        flag = {
            'key': 'target-list-test',
            'variations': [
                True,
                False
            ],
            'defaultVariation': 1,
            'rolloutPercentage': 100,
            'rules': [{
                'attribute': 'userId',
                'operator': 'inTargetList',
                'value': None,
                'targetListKey': 'beta-testers',
                'variation': 0,
                'priority': 1
            }]
        }

        # User in list
        result = evaluator.evaluate(flag, {'userId': 'beta-1'})
        assert result is True

        # User not in list
        result = evaluator.evaluate(flag, {'userId': 'random-user'})
        assert result is False

    def test_blocked_users(self, evaluator):
        """Blocked users test - users in list should be denied."""
        evaluator.set_target_lists({
            'blocked-users': {
                'attributeKey': 'userId',
                'values': ['blocked-1', 'blocked-2']
            }
        }, client_side_enabled=True)

        flag = {
            'key': 'blocked-users-test',
            'variations': [
                True,
                False
            ],
            'defaultVariation': 0,  # Normal users get True
            'rolloutPercentage': 100,
            'rules': [{
                'attribute': 'userId',
                'operator': 'inTargetList',
                'value': None,
                'targetListKey': 'blocked-users',
                'variation': 1,  # Blocked users get False
                'priority': 1
            }]
        }

        # Normal user gets feature
        result = evaluator.evaluate(flag, {'userId': 'normal-user'})
        assert result is True

        # Blocked user denied
        result = evaluator.evaluate(flag, {'userId': 'blocked-1'})
        assert result is False

