"""
Test the hash function for conformance with TypeScript SDK.

The hash function MUST produce identical results across all SDK languages.
"""

import pytest
from flagpool_sdk.utils import hash_string, in_rollout


class TestHashString:
    """Test cases for the hash_string function."""

    # These test vectors are from spec/test-vectors.json
    # All SDKs MUST produce these exact values
    HASH_TEST_VECTORS = [
        ("", 0),
        ("a", 97),
        ("abc", 96354),
        ("hello world", 1794106052),
        ("user-1new-dashboard", 126605400),
        ("qa-user-1checkout-redesign", 1225423156),
        ("rollout-user-3boolean-with-rollout", 1909490948),
        ("rollout-user-7boolean-with-rollout", 1064087296),
    ]

    @pytest.mark.parametrize("input_str,expected_hash", HASH_TEST_VECTORS)
    def test_hash_conformance(self, input_str: str, expected_hash: int):
        """Test that hash produces identical results to TypeScript SDK."""
        actual = hash_string(input_str)
        assert actual == expected_hash, (
            f"Hash mismatch for '{input_str}': "
            f"expected {expected_hash}, got {actual}"
        )

    def test_hash_empty_string(self):
        """Empty string should hash to 0."""
        assert hash_string("") == 0

    def test_hash_single_char(self):
        """Single char should hash to its char code."""
        assert hash_string("a") == 97  # ord('a') = 97

    def test_hash_deterministic(self):
        """Same input should always produce same output."""
        for _ in range(100):
            assert hash_string("test-user-123") == hash_string("test-user-123")

    def test_hash_different_inputs(self):
        """Different inputs should (usually) produce different outputs."""
        h1 = hash_string("user-1")
        h2 = hash_string("user-2")
        assert h1 != h2


class TestInRollout:
    """Test cases for rollout bucketing."""

    def test_empty_user_id_always_in_rollout(self):
        """Empty userId should always be in rollout."""
        assert in_rollout("", "any-flag", 50) is True
        assert in_rollout("", "any-flag", 0) is True

    def test_100_percent_rollout(self):
        """100% rollout should include everyone."""
        assert in_rollout("any-user", "any-flag", 100) is True

    def test_0_percent_rollout(self):
        """0% rollout should exclude everyone."""
        assert in_rollout("any-user", "any-flag", 0) is False

    def test_rollout_user_3_in_50_percent(self):
        """rollout-user-3 should be in 50% rollout for boolean-with-rollout."""
        # hash % 100 = 48, which is < 50
        assert in_rollout("rollout-user-3", "boolean-with-rollout", 50) is True

    def test_rollout_user_7_out_of_50_percent(self):
        """rollout-user-7 should be out of 50% rollout for boolean-with-rollout."""
        # hash % 100 = 96, which is >= 50
        assert in_rollout("rollout-user-7", "boolean-with-rollout", 50) is False

    def test_rollout_is_deterministic(self):
        """Same user+flag should always get same result."""
        for _ in range(100):
            result1 = in_rollout("test-user", "test-flag", 50)
            result2 = in_rollout("test-user", "test-flag", 50)
            assert result1 == result2

