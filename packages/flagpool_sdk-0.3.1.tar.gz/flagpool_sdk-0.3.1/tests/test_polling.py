"""
Test polling functionality for Python SDK.

This test verifies that the SDK correctly polls for flag updates
and maintains consistent values.
"""

import pytest
import time
import threading
from unittest.mock import patch, MagicMock

from flagpool_sdk.client import FlagpoolClient

# Test constants
TEST_PROJECT_ID = 'test-project-id'
TEST_API_KEY = 'test-key'
TEST_DECRYPTION_KEY = 'test-decryption-key'


class TestPolling:
    """Test cases for polling functionality."""

    def test_polling_interval_set(self):
        """Verify polling interval is correctly set."""
        client = FlagpoolClient(
            project_id=TEST_PROJECT_ID,
            api_key=TEST_API_KEY,
            decryption_key=TEST_DECRYPTION_KEY,
            polling_interval=5
        )
        assert client._polling_interval == 5
        client.close()

    def test_polling_disabled_when_zero(self):
        """Verify polling is disabled when interval is 0."""
        client = FlagpoolClient(
            project_id=TEST_PROJECT_ID,
            api_key=TEST_API_KEY,
            decryption_key=TEST_DECRYPTION_KEY,
            polling_interval=0
        )

        with patch.object(client._fetcher, 'fetch_flags') as mock_fetch:
            mock_fetch.return_value = {'flags': [], 'environment': {'key': 'dev'}}
            client.init()

            # Polling timer should not be set
            assert client._polling_timer is None

        client.close()

    def test_polling_timer_started(self):
        """Verify polling timer is started after init."""
        client = FlagpoolClient(
            project_id=TEST_PROJECT_ID,
            api_key=TEST_API_KEY,
            decryption_key=TEST_DECRYPTION_KEY,
            polling_interval=10
        )

        with patch.object(client._fetcher, 'fetch_flags') as mock_fetch:
            mock_fetch.return_value = {'flags': [], 'environment': {'key': 'dev'}}
            client.init()

            # Polling timer should be set
            assert client._polling_timer is not None
            assert isinstance(client._polling_timer, threading.Timer)

        client.close()

    def test_polling_timer_stopped_on_close(self):
        """Verify polling timer is stopped when client is closed."""
        client = FlagpoolClient(
            project_id=TEST_PROJECT_ID,
            api_key=TEST_API_KEY,
            decryption_key=TEST_DECRYPTION_KEY,
            polling_interval=10
        )

        with patch.object(client._fetcher, 'fetch_flags') as mock_fetch:
            mock_fetch.return_value = {'flags': [], 'environment': {'key': 'dev'}}
            client.init()

            timer = client._polling_timer
            assert timer is not None

            client.close()

            # Timer should be cancelled
            assert client._polling_timer is None

    def test_polling_fetches_updates(self):
        """Verify polling actually fetches flag updates."""
        client = FlagpoolClient(
            project_id=TEST_PROJECT_ID,
            api_key=TEST_API_KEY,
            decryption_key=TEST_DECRYPTION_KEY,
            polling_interval=1,  # 1 second for fast testing
            context={'userId': 'test-user'}
        )

        call_count = [0]

        def mock_fetch(context):
            call_count[0] += 1
            return {
                'flags': [
                    {
                        'key': 'test-flag',
                        'variations': [
                            True,
                            False
                        ],
                        'defaultVariation': 0,
                        'rolloutPercentage': 100,
                        'rules': []
                    }
                ],
                'environment': {'key': 'dev'}
            }

        with patch.object(client._fetcher, 'fetch_flags', side_effect=mock_fetch):
            client.init()

            # Initial fetch
            assert call_count[0] == 1

            # Wait for polling cycle
            time.sleep(1.5)

            # Should have fetched again
            assert call_count[0] >= 2

        client.close()

    def test_change_callback_on_flag_update(self):
        """Verify change callbacks are called when flags change."""
        client = FlagpoolClient(
            project_id=TEST_PROJECT_ID,
            api_key=TEST_API_KEY,
            decryption_key=TEST_DECRYPTION_KEY,
            polling_interval=1,
            context={'userId': 'test-user'}
        )

        changes = []
        call_count = [0]

        def on_change(key, value):
            changes.append({'key': key, 'value': value})

        client.on_change(on_change)

        def mock_fetch(context):
            call_count[0] += 1
            # Return different value on second call
            value = call_count[0] == 1
            return {
                'flags': [
                    {
                        'key': 'test-flag',
                        'variations': [
                            True,
                            False
                        ],
                        'defaultVariation': 0 if value else 1,
                        'rolloutPercentage': 100,
                        'rules': []
                    }
                ],
                'environment': {'key': 'dev'}
            }

        with patch.object(client._fetcher, 'fetch_flags', side_effect=mock_fetch):
            client.init()

            # Initial value
            assert client.is_enabled('test-flag') is True

            # Wait for polling cycle
            time.sleep(1.5)

            # Value should have changed
            assert client.is_enabled('test-flag') is False

            # Change callback should have been called
            assert len(changes) >= 1
            assert any(c['key'] == 'test-flag' and c['value'] is False for c in changes)

        client.close()

    def test_values_consistent_without_server_changes(self):
        """Verify values remain consistent when server doesn't change."""
        client = FlagpoolClient(
            project_id=TEST_PROJECT_ID,
            api_key=TEST_API_KEY,
            decryption_key=TEST_DECRYPTION_KEY,
            polling_interval=1,
            context={'userId': 'test-user'}
        )

        # Always return same flags
        flags_data = {
            'flags': [
                {
                    'key': 'stable-flag',
                    'variations': [
                        'stable-value'
                    ],
                    'defaultVariation': 0,
                    'rolloutPercentage': 100,
                    'rules': []
                }
            ],
            'environment': {'key': 'dev'}
        }

        with patch.object(client._fetcher, 'fetch_flags', return_value=flags_data):
            client.init()

            initial_value = client.get_value('stable-flag')

            # Wait for multiple polling cycles
            time.sleep(2.5)

            final_value = client.get_value('stable-flag')

            # Values should be identical
            assert initial_value == final_value == 'stable-value'

        client.close()


if __name__ == '__main__':
    pytest.main([__file__, '-v'])

