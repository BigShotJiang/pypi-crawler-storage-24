"""
Conformance tests for Python SDK against spec/test-vectors.json

These tests verify that the Python SDK produces identical results
to the TypeScript SDK for all test vectors.
"""

import json
import os
import pytest
from pathlib import Path

from flagpool_sdk.utils import hash_string
from flagpool_sdk.evaluator import Evaluator


# Load test vectors
SPEC_DIR = Path(__file__).parent.parent.parent.parent / 'spec'
TEST_VECTORS_PATH = SPEC_DIR / 'test-vectors.json'

with open(TEST_VECTORS_PATH) as f:
    TEST_VECTORS = json.load(f)


class TestHashConformance:
    """Test hash function conformance with spec."""

    @pytest.mark.parametrize("vector", TEST_VECTORS['hashTests']['vectors'])
    def test_hash_vector(self, vector):
        """Each hash test vector should produce the expected value."""
        input_str = vector['input']
        expected = vector['expectedHash']
        actual = hash_string(input_str)

        assert actual == expected, (
            f"Hash conformance failed for '{input_str}': "
            f"expected {expected}, got {actual}"
        )


class TestRolloutConformance:
    """Test rollout bucketing conformance with spec."""

    @pytest.mark.parametrize("vector", TEST_VECTORS['rolloutTests']['vectors'])
    def test_rollout_vector(self, vector):
        """Each rollout test vector should produce the expected result."""
        user_id = vector['userId']
        flag_key = vector['flagKey']
        percentage = vector['rolloutPercentage']
        expected = vector['expectedInRollout']

        # Calculate actual rollout result
        if not user_id:
            actual = True
        else:
            hash_val = hash_string(user_id + flag_key)
            bucket = hash_val % 100
            actual = bucket < percentage

        assert actual == expected, (
            f"Rollout conformance failed for {vector['name']}: "
            f"expected {expected}, got {actual}"
        )


class TestEvaluationConformance:
    """Test flag evaluation conformance with spec."""

    @pytest.fixture
    def evaluator(self):
        """Create evaluator with target lists."""
        ev = Evaluator()
        ev.set_target_lists(TEST_VECTORS['targetLists'], client_side_enabled=True)
        return ev

    def _run_evaluation_tests(self, evaluator, test_cases):
        """Run a list of evaluation test cases."""
        for test in test_cases:
            flag_key = test['flagKey']
            context = test['context']
            expected = test['expected']

            flag = TEST_VECTORS['flags'].get(flag_key)
            if not flag:
                pytest.fail(f"Flag '{flag_key}' not found in test vectors")

            actual = evaluator.evaluate(flag, context)

            assert actual == expected, (
                f"Evaluation conformance failed for '{test['name']}': "
                f"expected {expected!r}, got {actual!r}. "
                f"Reason: {test.get('reason', 'N/A')}"
            )

    def test_boolean_flags(self, evaluator):
        """Test boolean flag evaluation."""
        self._run_evaluation_tests(
            evaluator,
            TEST_VECTORS['evaluationTests']['booleanFlags']
        )

    def test_contains_operator(self, evaluator):
        """Test contains operator."""
        self._run_evaluation_tests(
            evaluator,
            TEST_VECTORS['evaluationTests']['containsOperator']
        )

    def test_eq_operator(self, evaluator):
        """Test eq operator."""
        self._run_evaluation_tests(
            evaluator,
            TEST_VECTORS['evaluationTests']['eqOperator']
        )

    def test_neq_operator(self, evaluator):
        """Test neq operator."""
        self._run_evaluation_tests(
            evaluator,
            TEST_VECTORS['evaluationTests']['neqOperator']
        )

    def test_startswith_operator(self, evaluator):
        """Test startsWith operator."""
        self._run_evaluation_tests(
            evaluator,
            TEST_VECTORS['evaluationTests']['startsWithOperator']
        )

    def test_in_operator(self, evaluator):
        """Test in operator."""
        self._run_evaluation_tests(
            evaluator,
            TEST_VECTORS['evaluationTests']['inOperator']
        )

    def test_nin_operator(self, evaluator):
        """Test nin operator."""
        self._run_evaluation_tests(
            evaluator,
            TEST_VECTORS['evaluationTests']['ninOperator']
        )

    def test_number_flags(self, evaluator):
        """Test number flag evaluation."""
        self._run_evaluation_tests(
            evaluator,
            TEST_VECTORS['evaluationTests']['numberFlags']
        )

    def test_json_flags(self, evaluator):
        """Test JSON flag evaluation."""
        self._run_evaluation_tests(
            evaluator,
            TEST_VECTORS['evaluationTests']['jsonFlags']
        )

    def test_priority(self, evaluator):
        """Test rule priority."""
        self._run_evaluation_tests(
            evaluator,
            TEST_VECTORS['evaluationTests']['priorityTests']
        )

    def test_target_lists(self, evaluator):
        """Test target list evaluation."""
        self._run_evaluation_tests(
            evaluator,
            TEST_VECTORS['evaluationTests']['targetListTests']
        )

    def test_rollout_with_rules(self, evaluator):
        """Test rollout with rules."""
        self._run_evaluation_tests(
            evaluator,
            TEST_VECTORS['evaluationTests']['rolloutWithRuleTests']
        )

    def test_edge_cases(self, evaluator):
        """Test edge cases."""
        self._run_evaluation_tests(
            evaluator,
            TEST_VECTORS['evaluationTests']['edgeCases']
        )


if __name__ == '__main__':
    pytest.main([__file__, '-v'])

