"""
Tests for non-existent flag behavior.

Verifies that the Python SDK handles missing flags gracefully
without throwing exceptions, as specified in evaluation-spec.md.
"""

import pytest
from unittest.mock import patch, MagicMock

from flagpool_sdk.client import FlagpoolClient

# Test constants
TEST_PROJECT_ID = 'test-project-id'
TEST_API_KEY = 'test-key'
TEST_DECRYPTION_KEY = 'test-decryption-key'


class TestMissingFlags:
    """Test cases for non-existent flag handling."""

    @pytest.fixture
    def client(self):
        """Create a client with mocked fetcher that returns empty flags."""
        client = FlagpoolClient(
            project_id=TEST_PROJECT_ID,
            api_key=TEST_API_KEY,
            decryption_key=TEST_DECRYPTION_KEY,
            polling_interval=0
        )

        with patch.object(client._fetcher, 'fetch_flags') as mock_fetch:
            mock_fetch.return_value = {
                'flags': [],
                'environment': {'key': 'test'}
            }
            client.init()

        return client

    def test_get_value_returns_none_for_non_existent_flag(self, client):
        """getValue should return None for a flag that doesn't exist."""
        result = client.get_value('this-flag-does-not-exist')
        assert result is None, "Expected None for non-existent flag"

    def test_get_value_returns_default_for_non_existent_flag(self, client):
        """getValue should return the default value for a flag that doesn't exist."""
        result = client.get_value('this-flag-does-not-exist', default='my-default')
        assert result == 'my-default', "Expected default value for non-existent flag"

    def test_is_enabled_returns_false_for_non_existent_flag(self, client):
        """isEnabled should return False for a flag that doesn't exist."""
        result = client.is_enabled('this-flag-does-not-exist')
        assert result is False, "Expected False for non-existent flag"

    def test_is_enabled_returns_default_for_non_existent_flag(self, client):
        """isEnabled should return the default value for a flag that doesn't exist."""
        result = client.is_enabled('this-flag-does-not-exist', default=True)
        assert result is True, "Expected default value (True) for non-existent flag"

    def test_get_variation_returns_none_for_non_existent_flag(self, client):
        """getVariation should return None for a flag that doesn't exist."""
        result = client.get_variation('this-flag-does-not-exist')
        assert result is None, "Expected None for non-existent flag"

    def test_no_exception_for_non_existent_flag_with_context(self, client):
        """No exception should be raised even with complex context."""
        # This should not raise any exception
        try:
            result = client.get_value('missing-flag')
            assert result is None
        except Exception as e:
            pytest.fail(f"Should not raise exception for non-existent flag: {e}")

    def test_multiple_non_existent_flags(self, client):
        """Multiple non-existent flag lookups should all return defaults."""
        flags_to_check = [
            'feature-1',
            'feature-2',
            'some-random-flag',
            'another-missing-flag'
        ]

        for flag_key in flags_to_check:
            assert client.get_value(flag_key) is None
            assert client.is_enabled(flag_key) is False


class TestMissingFlagsWithExistingFlags:
    """Test non-existent flags when other flags exist."""

    @pytest.fixture
    def client_with_flags(self):
        """Create a client with some existing flags."""
        client = FlagpoolClient(
            project_id=TEST_PROJECT_ID,
            api_key=TEST_API_KEY,
            decryption_key=TEST_DECRYPTION_KEY,
            polling_interval=0
        )

        with patch.object(client._fetcher, 'fetch_flags') as mock_fetch:
            mock_fetch.return_value = {
                'flags': [
                    {
                        'key': 'existing-flag',
                        'variations': [True, False],
                        'defaultVariation': 0,
                        'rolloutPercentage': 100,
                        'rules': []
                    }
                ],
                'environment': {'key': 'test'}
            }
            client.init()

        return client

    def test_existing_flag_works(self, client_with_flags):
        """Existing flags should evaluate normally."""
        assert client_with_flags.is_enabled('existing-flag') is True

    def test_non_existent_flag_returns_default(self, client_with_flags):
        """Non-existent flags should return default even when other flags exist."""
        assert client_with_flags.is_enabled('non-existent-flag') is False
        assert client_with_flags.get_value('non-existent-flag') is None

