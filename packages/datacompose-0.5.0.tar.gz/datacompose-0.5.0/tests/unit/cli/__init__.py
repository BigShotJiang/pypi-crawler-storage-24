"""CLI tests package."""
