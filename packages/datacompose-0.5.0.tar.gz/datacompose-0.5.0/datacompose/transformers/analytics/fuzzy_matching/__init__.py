"""Fuzzy matching transformer."""
