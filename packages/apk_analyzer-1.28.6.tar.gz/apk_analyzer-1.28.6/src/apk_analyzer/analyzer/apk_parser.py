"""APK Parser - extracts DEX, manifest, native libs, resources.arsc from APK (ZIP)."""
import hashlib
import re
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

from apk_analyzer.models import APKInfo
from apk_analyzer.analyzer.pyaxml_logging import suppress_pyaxmlparser_warnings

_REQUIRED_32 = "armeabi-v7a"
_REQUIRED_64 = "arm64-v8a"
_ABI_ALIASES = {
    "arm64_v8a": "arm64-v8a",
    "armeabi_v7a": "armeabi-v7a",
    "x86-64": "x86_64",
    "aarch64": "arm64-v8a",
}

_CHANNEL_FILE_PATTERNS = [
    re.compile(r"^meta-inf/(?:channel|mtchannel)[_-]([a-z0-9._-]+)$", re.IGNORECASE),
    re.compile(r"^meta-inf/(?:channel|mtchannel)/([a-z0-9._-]+)$", re.IGNORECASE),
]

_CHANNEL_TEXT_FILES = {
    "meta-inf/channel",
    "meta-inf/channel.txt",
    "meta-inf/wallechannel",
    "assets/channel",
    "assets/channel.txt",
}

_STORE_MARKER_FILES = {
    "meta-inf/com.android.vending": "google_play",
    "meta-inf/com.huawei.appmarket": "huawei_appgallery",
    "meta-inf/com.xiaomi.market": "xiaomi_store",
    "meta-inf/com.tencent.android.qqdownloader": "tencent_appstore",
    "meta-inf/com.bbk.appstore": "vivo_store",
    "meta-inf/com.oppo.market": "oppo_store",
}


def _normalize_zip_name(name: str) -> str:
    normalized = name.replace("\\", "/")
    while normalized.startswith("./"):
        normalized = normalized[2:]
    return normalized.lstrip("/")


def _normalize_abi_name(abi: str) -> str:
    normalized = abi.strip().lower()
    return _ABI_ALIASES.get(normalized, normalized)


def _classify_abi_support(lib_abis: dict[str, set[str]]) -> str:
    if not lib_abis:
        return "Other"

    all_have_32 = all(_REQUIRED_32 in abis for abis in lib_abis.values())
    all_have_64 = all(_REQUIRED_64 in abis for abis in lib_abis.values())

    if all_have_32 and all_have_64:
        return "32/64-bit"
    if all_have_64:
        return "64-bit"
    if all_have_32:
        return "32-bit"
    return "Other"


# Common DPI qualifiers in order
_DPI_ORDER = ["ldpi", "mdpi", "tvdpi", "hdpi", "xhdpi", "xxhdpi", "xxxhdpi", "nodpi", "anydpi"]
_DPI_ALIASES = {
    "ldpi": "ldpi",
    "mdpi": "mdpi",
    "tvdpi": "tvdpi",
    "hdpi": "hdpi",
    "xhdpi": "xhdpi",
    "xxhdpi": "xxhdpi",
    "xxxhdpi": "xxxhdpi",
    "nodpi": "nodpi",
    "anydpi": "anydpi",
}


def _normalize_dpi_name(dpi: str) -> str:
    """Normalize DPI qualifier name."""
    normalized = dpi.strip().lower()
    return _DPI_ALIASES.get(normalized, normalized)


def _extract_dpi_from_dir(dir_name: str) -> str | None:
    """Extract DPI qualifier from directory name like 'drawable-mdpi' or 'mipmap-xxhdpi'."""
    parts = dir_name.split("-")
    if len(parts) < 2:
        return None
    dpi_part = "-".join(parts[1:])  # Handle cases like "drawable-anydpi-v21"
    # Extract just the DPI part (before any additional qualifiers like -v21)
    dpi_base = dpi_part.split("-")[0]
    normalized = _normalize_dpi_name(dpi_base)
    return normalized if normalized in _DPI_ORDER else None


def _classify_dpi_support(resource_dpis: dict[str, set[str]]) -> str:
    """Classify DPI support summary."""
    if not resource_dpis:
        return "No image resources"
    
    all_dpis = set()
    for dpis in resource_dpis.values():
        all_dpis.update(dpis)
    
    if not all_dpis:
        return "No image resources"
    
    # Common DPI sets
    common_dpis = {"mdpi", "hdpi", "xhdpi", "xxhdpi"}
    has_all_common = common_dpis.issubset(all_dpis)
    
    if has_all_common and len(all_dpis) >= 4:
        return "Full DPI support"
    
    # Sort by standard order
    sorted_dpis = sorted(all_dpis, key=lambda d: _DPI_ORDER.index(d) if d in _DPI_ORDER else 999)
    return "/".join(sorted_dpis)


# Common locale qualifiers for string resources (values-*)
# Order for display: default first, then common languages
_LOCALE_ORDER = [
    "default", "en", "zh", "zh-CN", "zh-TW", "ja", "ko", "de", "fr", "es", "pt", "pt-BR",
    "ru", "ar", "hi", "th", "vi", "id", "tr", "it", "nl", "pl", "uk",
]


def _extract_locale_from_values_dir(dir_name: str) -> str | None:
    """Extract locale qualifier from directory name like 'values', 'values-en', 'values-zh-rCN'."""
    if not dir_name.startswith("values"):
        return None
    if dir_name == "values":
        return "default"
    # values-en, values-zh, values-ja, values-zh-rCN, values-pt-rBR
    suffix = dir_name[len("values"):].lstrip("-")
    if not suffix:
        return "default"
    # Normalize: zh-rCN -> zh-CN, pt-rBR -> pt-BR
    parts = suffix.split("-")
    if len(parts) == 1:
        return parts[0].lower()
    if len(parts) >= 2 and parts[1].lower().startswith("r"):
        # values-zh-rCN -> zh-CN
        region = parts[1][1:].upper()  # rCN -> CN
        return f"{parts[0].lower()}-{region}"
    return suffix.lower()


def _normalize_pyaxml_locale(loc) -> str:
    """Normalize pyaxmlparser locale to display string (e.g. default, en, zh-CN)."""
    if loc is None:
        return "default"
    if isinstance(loc, bytes):
        s = loc.decode("utf-8", errors="replace").replace("\x00", "").strip()
    else:
        s = str(loc).replace("\x00", "").strip()
    if not s:
        return "default"
    return s.replace("_", "-") if "_" in s else s


def _extract_string_names_from_pyaxmlparser(
    apk_path: Path,
) -> tuple[dict[str, set[str]], set[str]]:
    """Extract string names and locales from APK using pyaxmlparser. Returns (string_dirs, detected_locales)."""
    string_dirs: dict[str, set[str]] = {}
    detected_locales: set[str] = set()
    try:
        with suppress_pyaxmlparser_warnings():
            import pyaxmlparser
            apk = pyaxmlparser.APK(str(apk_path))
            res = apk.get_android_resources()
            if not res:
                return string_dirs, detected_locales
            res._analyse()
            for pkg in res.get_packages_names():
                for loc in res.get_locales(pkg):
                    loc_str = _normalize_pyaxml_locale(loc)
                    detected_locales.add(loc_str)
                    try:
                        for item in res.values[pkg][loc]["string"]:
                            name = item[0] if isinstance(item, (list, tuple)) else item.get("name", "")
                            if name:
                                if name not in string_dirs:
                                    string_dirs[name] = set()
                                string_dirs[name].add(loc_str)
                    except (KeyError, TypeError, IndexError):
                        pass
    except Exception:
        pass
    return string_dirs, detected_locales


def _parse_string_names_from_xml(content: bytes) -> set[str]:
    """Extract string resource names from strings.xml. Returns empty set for binary XML."""
    names: set[str] = set()
    try:
        # Binary XML typically starts with chunk header (0x03 0x00 or similar)
        if len(content) < 4 or content[:2] in (b"\x03\x00", b"\x01\x00"):
            return names
        text = content.decode("utf-8", errors="replace")
        if not text.strip().startswith(("<?xml", "<resources", "<")):
            return names
        root = ET.fromstring(content)
        for elem in root.iter():
            if elem.tag in ("string", "{*}string"):
                name = elem.get("name") or elem.get("{http://schemas.android.com/apk/res/android}name")
                if name:
                    names.add(name)
    except ET.ParseError:
        pass
    except Exception:
        pass
    return names


def _classify_string_support(string_dirs: dict[str, set[str]]) -> str:
    """Classify string locale support summary."""
    if not string_dirs:
        return "No string resources"
    all_locales = set()
    for locales in string_dirs.values():
        all_locales.update(locales)
    if not all_locales:
        return "No string resources"
    # Common locales for many apps
    common = {"default", "en", "zh", "zh-CN", "ja", "ko"}
    has_common = len(common & all_locales) >= 3
    if has_common and len(all_locales) >= 3:
        return "Multi-language support"
    sorted_locales = sorted(all_locales, key=lambda l: (_LOCALE_ORDER.index(l) if l in _LOCALE_ORDER else 999, l))
    return "/".join(sorted_locales)


def _extract_resource_references_from_xml(xml_content: bytes) -> set[str]:
    """Extract resource references from XML content (layout files, etc.)."""
    references = set()
    try:
        text = xml_content.decode("utf-8", errors="ignore")
        # Match @drawable/resource_name or @mipmap/resource_name
        patterns = [
            r'@drawable/([a-zA-Z0-9_]+)',
            r'@mipmap/([a-zA-Z0-9_]+)',
            r'android:src="@drawable/([a-zA-Z0-9_]+)"',
            r'android:icon="@mipmap/([a-zA-Z0-9_]+)"',
            r'android:background="@drawable/([a-zA-Z0-9_]+)"',
        ]
        for pattern in patterns:
            matches = re.findall(pattern, text)
            references.update(matches)
    except Exception:
        pass
    return references


def _extract_resource_references_from_strings(strings: list[str]) -> set[str]:
    """Extract resource name references from DEX string pool."""
    references = set()
    # Look for resource names in strings (common patterns)
    resource_patterns = [
        r'R\.(drawable|mipmap)\.([a-zA-Z0-9_]+)',
        r'/(drawable|mipmap)/([a-zA-Z0-9_]+)',
    ]
    for s in strings:
        for pattern in resource_patterns:
            matches = re.findall(pattern, s)
            for match in matches:
                if isinstance(match, tuple) and len(match) == 2:
                    references.add(match[1])  # Resource name
                elif isinstance(match, str):
                    references.add(match)
    return references


def _normalize_digest(value) -> str:
    if value is None:
        return ""
    if isinstance(value, bytes):
        return value.hex()
    text = str(value).strip().lower().replace(":", "")
    return text


def _human_friendly_name(name_obj) -> str:
    if name_obj is None:
        return ""
    human = getattr(name_obj, "human_friendly", None)
    if human:
        return str(human)
    native = getattr(name_obj, "native", None)
    if isinstance(native, dict):
        return ", ".join(f"{k}={v}" for k, v in native.items())
    if native is not None:
        return str(native)
    return str(name_obj)


def _extract_organization_from_subject(subject_obj) -> str:
    if subject_obj is None:
        return ""

    native = getattr(subject_obj, "native", None)
    if isinstance(native, dict):
        org = native.get("organization_name")
        if isinstance(org, list):
            org = ", ".join(str(i).strip() for i in org if str(i).strip())
        if org:
            return str(org).strip()

    text = _human_friendly_name(subject_obj)
    if not text:
        return ""
    for pattern in (
        r"(?:^|[,/])\s*O\s*=\s*([^,/]+)",
        r"organization_name\s*=\s*([^,]+)",
        r"Organization\s*:\s*([^,]+)",
    ):
        match = re.search(pattern, text, flags=re.IGNORECASE)
        if match:
            return match.group(1).strip()
    return ""


def _extract_signing_info(apk_path: Path) -> tuple[list[str], list[dict[str, str]]]:
    schemes: list[str] = []
    certs: list[dict[str, str]] = []

    try:
        with suppress_pyaxmlparser_warnings():
            import pyaxmlparser
            apk = pyaxmlparser.APK(str(apk_path))
    except Exception:
        return schemes, certs

    for scheme_name, checker in (
        ("v1", getattr(apk, "is_signed_v1", None)),
        ("v2", getattr(apk, "is_signed_v2", None)),
        ("v3", getattr(apk, "is_signed_v3", None)),
    ):
        if checker is None:
            continue
        try:
            if checker():
                schemes.append(scheme_name)
        except Exception:
            continue

    seen_fingerprints: set[str] = set()
    for getter_name in ("get_certificates_v1", "get_certificates_v2", "get_certificates_v3"):
        getter = getattr(apk, getter_name, None)
        if getter is None:
            continue
        try:
            certificates = getter() or []
        except Exception:
            continue
        for cert in certificates:
            subject = getattr(cert, "subject", None)
            sha256 = _normalize_digest(getattr(cert, "sha256", ""))
            if sha256 and sha256 in seen_fingerprints:
                continue
            if sha256:
                seen_fingerprints.add(sha256)
            certs.append({
                "sha256": sha256,
                "sha1": _normalize_digest(getattr(cert, "sha1", "")),
                "subject": _human_friendly_name(subject),
                "issuer": _human_friendly_name(getattr(cert, "issuer", None)),
                "serial_number": str(getattr(cert, "serial_number", "")),
                "organization": _extract_organization_from_subject(subject),
            })

    return schemes, certs


def _extract_archive_channel_hints(
    zf: zipfile.ZipFile, names: list[str]
) -> tuple[str, list[str]]:
    path_map: dict[str, str] = {}
    for raw_name in names:
        path_map[_normalize_zip_name(raw_name).lower()] = raw_name

    hints: list[str] = []
    channel_value = ""

    for normalized_name in sorted(path_map.keys()):
        for pattern in _CHANNEL_FILE_PATTERNS:
            match = pattern.match(normalized_name)
            if match:
                detected = match.group(1).strip()
                if detected and not channel_value:
                    channel_value = detected
                hints.append(f"archive-file:{normalized_name}")
                break

        marker = _STORE_MARKER_FILES.get(normalized_name)
        if marker:
            hints.append(f"store-marker:{marker}")

    if not channel_value:
        for channel_file in _CHANNEL_TEXT_FILES:
            raw_name = path_map.get(channel_file)
            if not raw_name:
                continue
            try:
                text = zf.read(raw_name).decode("utf-8", errors="ignore").strip()
            except Exception:
                continue
            if not text:
                continue
            first_line = text.splitlines()[0].strip()
            if first_line:
                channel_value = first_line
                hints.append(f"archive-content:{channel_file}")
                break

    return channel_value, list(dict.fromkeys(hints))


class APKParser:
    def __init__(self, apk_path: Path):
        self.apk_path = apk_path

    def parse(self) -> APKInfo:
        info = APKInfo()
        info.file_size_bytes = self.apk_path.stat().st_size
        sha = hashlib.sha256()
        with open(self.apk_path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                sha.update(chunk)
        info.signature_sha256 = sha.hexdigest()

        with zipfile.ZipFile(self.apk_path, "r") as zf:
            names = zf.namelist()
            source_channel_raw, channel_hints = _extract_archive_channel_hints(zf, names)
            info.source_channel_raw = source_channel_raw
            info.channel_hints = channel_hints

            dex_names = sorted(n for n in names if n.endswith(".dex"))
            info.dex_count = len(dex_names)
            info.dex_files = [zf.read(dn) for dn in dex_names]

            if "AndroidManifest.xml" in names:
                info.manifest_data = zf.read("AndroidManifest.xml")

            if "resources.arsc" in names:
                info.resources_arsc = zf.read("resources.arsc")

            seen_libs = set()
            lib_abis: dict[str, set[str]] = {}
            for raw_name in names:
                n = _normalize_zip_name(raw_name)
                if not n.startswith("lib/"):
                    continue

                parts = n.split("/")
                if len(parts) < 3 or not parts[1] or not parts[-1]:
                    continue

                if not n.endswith(".so"):
                    continue

                abi_name = _normalize_abi_name(parts[1])
                lib_name = parts[-1]
                if lib_name not in seen_libs:
                    seen_libs.add(lib_name)
                    info.native_libs.append(lib_name)
                    lib_abis[lib_name] = set()
                lib_abis[lib_name].add(abi_name)

            info.native_lib_arches = {k: sorted(v) for k, v in lib_abis.items()}
            info.native_abis = sorted({abi for abis in lib_abis.values() for abi in abis})
            info.abi_support = _classify_abi_support(lib_abis)

            # Parse resource directories (drawable/mipmap DPI support)
            # Two structures: standard (res/drawable-mdpi/icon.png) and flattened (res/06.png)
            # Flattened: R8/AGP resource optimization renames files directly under res/
            resource_dirs: dict[str, set[str]] = {}
            image_extensions = {".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp", ".xml"}
            for raw_name in names:
                n = _normalize_zip_name(raw_name)
                if not n.startswith("res/"):
                    continue
                
                parts = n.split("/")
                file_name = parts[-1]
                if not any(file_name.lower().endswith(ext) for ext in image_extensions):
                    continue
                
                base_name = file_name.rsplit(".", 1)[0] if "." in file_name else file_name
                
                if len(parts) == 2:
                    # Flattened: res/06.png, res/0H.9.png (R8/AGP resource obfuscation)
                    resource_key = f"drawable/{base_name}"
                    if resource_key not in resource_dirs:
                        resource_dirs[resource_key] = set()
                    resource_dirs[resource_key].add("nodpi")
                    continue
                
                if len(parts) < 3:
                    continue
                
                # Standard: res/drawable-mdpi/icon.png or res/drawable/icon.png
                dir_name = parts[1]
                is_drawable_mipmap = (
                    dir_name.startswith("drawable-") or dir_name.startswith("mipmap-")
                    or dir_name == "drawable" or dir_name == "mipmap"
                )
                if not is_drawable_mipmap:
                    continue
                
                if dir_name in ("drawable", "mipmap"):
                    dpi = "nodpi"
                else:
                    dpi = _extract_dpi_from_dir(dir_name)
                if not dpi:
                    continue
                
                resource_key = f"{dir_name.split('-')[0]}/{base_name}"
                if resource_key not in resource_dirs:
                    resource_dirs[resource_key] = set()
                resource_dirs[resource_key].add(dpi)
            
            info.resource_dirs = {k: sorted(v, key=lambda d: _DPI_ORDER.index(d) if d in _DPI_ORDER else 999) 
                                 for k, v in resource_dirs.items()}
            info.resource_dpis = sorted({dpi for dpis in resource_dirs.values() for dpi in dpis},
                                        key=lambda d: _DPI_ORDER.index(d) if d in _DPI_ORDER else 999)
            info.dpi_support = _classify_dpi_support(resource_dirs)

            # Extract resource references from XML files and DEX strings
            resource_refs = set()
            # Parse XML layout files
            for raw_name in names:
                n = _normalize_zip_name(raw_name)
                if n.startswith("res/layout") or n.startswith("res/xml") or n.startswith("res/menu"):
                    if n.endswith(".xml"):
                        try:
                            xml_content = zf.read(raw_name)
                            refs = _extract_resource_references_from_xml(xml_content)
                            resource_refs.update(refs)
                        except Exception:
                            pass
            
            # Store resource references (will be matched with resource names later)
            info.resource_references = resource_refs

            # Parse string resources (values-* locale support)
            string_dirs: dict[str, set[str]] = {}
            detected_locales: set[str] = set()
            for raw_name in names:
                n = _normalize_zip_name(raw_name)
                if not n.startswith("res/") or not n.endswith(".xml"):
                    continue
                parts = n.split("/")
                if len(parts) < 3:
                    continue
                dir_name = parts[1]
                if not dir_name.startswith("values"):
                    continue
                locale = _extract_locale_from_values_dir(dir_name)
                if locale is None:
                    continue
                # Only parse strings.xml for string resource names
                file_name = parts[-1].lower()
                if file_name != "strings.xml":
                    continue
                detected_locales.add(locale)
                try:
                    xml_content = zf.read(raw_name)
                    string_names = _parse_string_names_from_xml(xml_content)
                    for name in string_names:
                        if name not in string_dirs:
                            string_dirs[name] = set()
                        string_dirs[name].add(locale)
                except Exception:
                    pass
            # Fallback: extract string names from resources.arsc (compiled APKs)
            if not string_dirs and info.resources_arsc:
                try:
                    from apk_analyzer.analyzer.resource_parser import ResourceParser
                    arsc_parser = ResourceParser(info.resources_arsc)
                    arsc_names = arsc_parser.get_string_names()
                    for name in arsc_names:
                        string_dirs[name] = {"default"}
                        detected_locales.add("default")
                    if not arsc_names and arsc_parser.has_string_resources():
                        detected_locales.add("default")
                    elif not arsc_names and len(info.resources_arsc) > 200:
                        # Best-effort: arsc exists but we couldn't parse names (format varies)
                        detected_locales.add("default")
                except Exception:
                    pass
            # Fallback: use pyaxmlparser to extract string names from resources.arsc
            if not string_dirs:
                _pyaxml_string_dirs, _pyaxml_locales = _extract_string_names_from_pyaxmlparser(
                    self.apk_path
                )
                if _pyaxml_string_dirs:
                    string_dirs = _pyaxml_string_dirs
                    detected_locales.update(_pyaxml_locales)
                elif _pyaxml_locales:
                    detected_locales.update(_pyaxml_locales)
            # When binary XML can't be parsed, use file-level locale detection
            if not string_dirs and detected_locales:
                sort_key = lambda l: (_LOCALE_ORDER.index(l) if l in _LOCALE_ORDER else 999, l)
                string_dirs = {"strings": sorted(detected_locales, key=sort_key)}
            info.string_dirs = {
                k: sorted(v, key=lambda l: (_LOCALE_ORDER.index(l) if l in _LOCALE_ORDER else 999, l))
                for k, v in string_dirs.items()
            }
            all_locales = {loc for locs in string_dirs.values() for loc in locs} or detected_locales
            info.string_locales = sorted(
                all_locales,
                key=lambda l: (_LOCALE_ORDER.index(l) if l in _LOCALE_ORDER else 999, l),
            )
            info.string_support = _classify_string_support(string_dirs) if string_dirs else (
                "/".join(sorted(detected_locales, key=lambda l: (_LOCALE_ORDER.index(l) if l in _LOCALE_ORDER else 999, l)))
                if detected_locales else "No string resources"
            )

            for n in names:
                if n.startswith("META-INF/") and n.endswith(".version"):
                    key = n[len("META-INF/"):-len(".version")]
                    try:
                        val = zf.read(n).decode("utf-8", errors="ignore").strip()
                        if val:
                            info.metainf_versions[key] = val
                    except Exception:
                        pass

        signing_schemes, signing_certs = _extract_signing_info(self.apk_path)
        info.signing_schemes = signing_schemes
        info.signing_certificates = signing_certs
        info.signing_organization = next(
            (cert.get("organization", "").strip() for cert in signing_certs if cert.get("organization", "").strip()),
            "",
        )
        return info
