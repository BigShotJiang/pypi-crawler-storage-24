import c_candyfloss as cc

__all__ = [
    'Caps', 
    'Extractor', 'ImageExtractor', 'AudioExtractor',
    'Pipeline', 'PipelineEl', 'Pad',
    'deftransform', 'NANOS_PER_SECOND']

NANOS_PER_SECOND = 1000000000

class PipelineError(Exception):
    "Generic exception for any errors produced by GStreamer"

    def __init__(self, *messages):
        self.message = ' @ '.join(messages)
        self.stack_info = None

    def add_stack_info(self, v):
        self.stack_info = '\n'.join(traceback.StackSummary(v).format())

    def __str__(self):
        info = self.stack_info or ''
        return '%s %s' % (info, self.message)

    def __repr__(self):
        return 'PipelineError: %s' % str(self)

cc.set_exception_class(PipelineError)

import os
import threading
import queue
from inspect import signature
import traceback
import time
import operator
from functools import reduce, partial, wraps
from collections import namedtuple

from PIL import Image
import numpy as np

def parse_dict(inp):
    "convert caps dicts into a form that the C code can handle"
    res = []
    for k, v in inp.items():
        if type(v) == str:
            v = v.encode('utf-8')
        res.append((k, v))
    return res


class Caps:
    'Wrapper around GstCaps ojects.'

    def __init__(self, fmt, **params):
        self.fmt = fmt
        self.params = params
        if fmt is not None:
            self.caps = cc.make_caps(fmt, parse_dict(params))

    @classmethod
    def from_cc(cls, v):
        "Wraps a reference to a C caps object"
        res = cls(None)
        res.caps = v
        return res

    def __getitem__(self, k):
        "Get caps props using the pythonic item accessor (x[v]) syntax"
        res = cc.caps_get_prop(self.caps, k)
        if res is None:
            raise KeyError(k)
        return res

    def is_compatible(self, other_caps):
        "Returns bool indicating whether the intersection with other_caps is non-null"
        return cc.caps_is_compatible(self.caps, other_caps.caps)

    def to_list(self):
        '''
        Returns a list of tuples representing the k/v pairs of the structure returned by .get_stucture()

        List of pairs, first elements are strings (field names), values can be any type.
        '''
        return cc.caps_to_list(self.caps)

    def __iter__(self):
        return iter(self.to_list())

    def __str__(self):
        l = self.to_list()
        return 'Caps(%s, %s)' % (
            l[0].decode('utf-8'), 
            ', '.join('%s=%r' % (k.decode('utf-8'),v)  for k,v in l[1:]))

    def union(self, other_caps):
        return Caps.from_cc(cc.caps_union(self.caps, other_caps.caps))

    def __or__(self, other):
        return self.union(other)

class Extractor:
    '''
    An Extractor converts between python objects and GstBuffer's

    Which Extractor an element (like one constructed with PipelineEl.map) is constructed with determines both what its caps are and how buffers are marshalled.

    An Extractor must implement three things:

    1. A `__static_caps__` field; a Caps object that determines the element's static caps
    2. a `pack()` method, which takes a bytes object and a Caps object and unpacks the bytes into a python object
    3. an `unpack()` method, which takes a python object an a Caps object (representing downstream caps) and returns a bytes object
    '''

    @classmethod
    def with_props(cls, **props):
        '''
        Makes a copy of this extractor with the given caps props as kwargs

        eg: `ImageExtractor.with_props(width=300, height=300)`
        '''

        old_caps = cls.__static_caps__
        new_caps = Caps(old_caps.fmt, **dict(old_caps.params, **props))
        class res(cls):
            __static_caps__ = new_caps
        res.__name__ == '%s.with_props' % cls.__name__
        return res


class ImageExtractor(Extractor):
    "An Extractor for PIL Image objects to/from video/x-raw buffers"

    __static_caps__ = Caps('video/x-raw', format='RGB')

    def unpack(data, caps):
        return Image.frombytes(caps['format'].decode('utf-8'), (caps['width'], caps['height']), data)

    @classmethod
    def pack(cls, image, target_caps):
        if not cls.__static_caps__.is_compatible(target_caps):
            raise ValueError('incompatible: %s, %s' % (target_caps, cls.__static_caps__))
        try:
            if image.width != target_caps['width'] or image.height != target_caps['height']:
                image = image.resize((target_caps['width'], target_caps['height']))
        except KeyError:
            pass
        image = image.convert(cls.__static_caps__['format'].decode('utf-8'))
        return image.tobytes()



class AudioExtractor(Extractor):
    "An extractor for numpy arrays to/from audo/x-raw buffers"

    # TODO: handle 24-bit PCM (numpy doesn't have native 24-bit integer types)
    format_dtype = {
        b'U8': np.uint8,
        b'S16BE': np.dtype('>i2'),
        b'S16LE': np.dtype('<i2'),
        b'S32BE': np.dtype('>i4'),
        b'S32LE': np.dtype('<i4'),
        b'F32LE': np.float32,
        b'F32BE': np.float32,
        b'F64LE': np.float64,
        b'F64BE': np.float64
    }

    __static_caps__ = reduce(operator.or_, 
        (Caps('audio/x-raw',format=k) for k in format_dtype.keys()))
    
    def unpack(data, caps):
        return np.frombuffer(data, dtype=AudioExtractor.format_dtype[caps['format']])

    def pack(arr, target_caps):
        return arr.astype(AudioExtractor.format_dtype[target_caps['format']]).tobytes()

class PipelineMember:
    
    def set_interval(self, cb, interval):
        """
        Call the function cb every interval nanoseconds in timeline time.
        That is, not necessarily in wall time, but at the 'playback speed'.
        The interval is disabled when the callback returns False
        """
        self.pipeline.set_interval(cb, interval)

    def _add_interval_reactive(self, k, v):
        if callable(v):
            self.set_interval(self._prop_updater(k, v), NANOS_PER_SECOND // 120)
            return True
        elif type(v) == tuple and len(v) == 2 and callable(v[1]):
            self.set_interval(self._prop_updater(k, v[1]), v[0])
            return True
        else:
            return False
    
    def _prop_updater(self, k, cb):
        return partial(self._update_prop, k, cb)

    def _update_prop(self, k, cb, timestamp):
        try:
            self[k] = cb(timestamp)
        except:
            traceback.print_exc()

class El(PipelineMember):

    @staticmethod
    def to_el(upstream, pipeline, v, rec=False):
        "construct PipelineEl from syntax if it isn't already one"
        if isinstance(v, PipelineEl):
            return v
        else:
            try:
                return PipelineEl(pipeline, v)
            except TypeError as e:
                if callable(v):
                    return v(upstream)
                else:
                    raise e
                
    def __rshift__(self, other):
        other = self.to_el(self, self.pipeline, other)
        self.link(other)
        return other

        
def _require_running(f):
    @wraps(f)
    def _res(self, *args, **kwargs):
        if not self.pipeline.is_running:
            raise ValueError('%s can only be called when pipeline is running' % f.__name__)
        return f(self, *args, **kwargs)
    return _res

class Pad(PipelineMember):

    def __init__(self, pipeline, obj):
        self.obj = obj
        self.pipeline = pipeline

    def __getitem__(self, k):
        return cc.get_element_property(self.obj, '', k)

    def __setitem__(self, k, v):
        if hasattr(v, 'obj'):
            v = v.obj
        if type(v) == str:
            v = v.encode('utf-8')
        cc.set_element_property(self.obj, '', k, v)

    def peer(self):
        return Pad(self.pipeline, cc.pad_get_peer(self.obj))

    def name(self):
        return cc.pad_get_name(self.obj).decode('utf-8')

    def __repr__(self):
        return '<pad %s>' % self.name()

    def _add_maybe_reactive(self, k, v):
        if not self._add_interval_reactive(k, v):
            self[k] = v

class PadAddsReactive:

    def __init__(self, pad_name, key, val):
        self.pad_name = pad_name
        self.key = key
        self.val = val

    def __call__(self, pad):
        assert pad.name() == self.pad_name
        pad._add_maybe_reactive(self.key, self.val)

class PipelineEl(El):
    '''
    Wrapper around GstElement objects.

    This is also where most of the syntactic sugar for constructing pipelines is implemented. 
    When using a Pipeline as a context manager, the context object is an instance of this class.

    When you do

    ```
    with Pipeline() as p:
        p
    ```
    or

    ```
    Pipeline(lambda p: p)
    ```

    p is a PipelineEl
    '''

    def __init__(self, pipeline, arg):
        """
        `arg` here is the literal (list, tuple, etc) written as part of the syntax sugar.

        eg: in 

        ```
        with Pipeline() as p:
            p >> 'autovideosink'
        ```

        a PipelineEl is constructed with the string 'autovideosink' as its arg
        """
        self.pipeline = pipeline
        self.pad_name = None
        self._on_pads = []
        self.obj = None

        if arg is None:
            self.obj = None
        elif type(arg) == tuple:
            self.set_obj(cc.make_capsfilter(pipeline.pipeline, arg[0], parse_dict(arg[1])), 
                'pipeline:%d' % hash(self))
        elif type(arg) == str:
            self.set_obj(*cc.construct_element(pipeline.pipeline, arg, []))
        elif type(arg) == list:
            self.set_obj(*cc.construct_element(
                pipeline.pipeline, arg[0], 
                self._parse_reactive(arg[1])))
        else:
            raise TypeError('invalid argument type: %r' % type(arg))

        for k, cb in self._on_pads:
            self._on_pad(k, cb)
        self._on_pads = []

    def _on_pad(self, k, cb):
        if self.obj is None:
            self._on_pads.append((k, cb))
        else:
            def _pad_cb(p):
                pad = Pad(self.pipeline, p)
                assert pad.name() == k
                try:
                    cb(pad)
                except:
                    traceback.print_exc()
            cc.on_pad(self.obj, k.encode('utf-8'), _pad_cb)

    def _parse_reactive(self, kvs):
        res = []
        for k, v in kvs.items():
            if type(v) == dict:
                for prop_key, vv in v.items():
                    self._on_pad(k, PadAddsReactive(k, prop_key, vv))
            elif type(k) == tuple:
                # pad prop
                pad_name, prop_key = k
                self._on_pad(pad_name, PadAddsReactive(pad_name, prop_key, v))
            elif not self._add_interval_reactive(k, v):
                if type(v) == str:
                    v = v.encode('utf-8')
                res.append((k, v))
        return res

    def copy(self):
        res = PipelineEl(self.pipeline, None)
        res.obj = self.obj
        return res

    def _pad_name(self, name):
        "returns a PipelineEl representing only the named pad"
        res = self.copy()
        res.pad_name = name.encode('utf-8')
        return res

    @_require_running
    def pad(self, name):
        return Pad(self.pipeline, cc.get_pad_by_name(self.obj, name))

    @_require_running
    def pads(self):
        if self.obj is None:
            return []
        return list(frozenset(v.decode('utf-8') for v in cc.list_pad_names(self.obj)))

    def __floordiv__(self, name):
        return self._pad_name(name)

    def __str__(self):
        return cc.get_element_name(self.obj).decode('utf-8')

    def set_obj(self, obj, name):
        """
        Set the underlying C reference this object wraps

        `name` is used for error messages and stack traces
        """
        self.obj = obj
        self.pipeline.stacks[name] = traceback.extract_stack()

    @_require_running
    def __getitem__(self, k):
        if self.obj is None:
            raise KeyError(k)
        if type(k) == tuple:
            pad, k = k
            return self.pad(pad)[k]
        if self.pad_name is not None:
            try:
                return cc.get_element_property(self.obj, self.pad_name, k)
            except KeyError:
                pass
        return cc.get_element_property(self.obj, '', k)

    @_require_running
    def __setitem__(self, k, v):
        if hasattr(v, 'obj'):
            v = v.obj
        if self.obj is None:
            raise ValueError('element is not set')
        if type(k) == tuple:
            pad, k = k
            self.pad(pad)[k] = v
            return
        if type(v) == str:
            v = v.encode('utf-8')
        if self.pad_name is not None:
            try:
                cc.set_element_property(self.obj, self.pad_name, k, v)
                return
            except KeyError:
                pass
        cc.set_element_property(self.obj, '', k, v)

    def keys(self):
        return [v.decode('utf-8') for v in cc.property_keys(self.obj, self.pad_name)]

    def link(self, other):
        "Try to link this to another downstream PipelineEl"
        if self.obj is not None:
            cc.link_elements(self.obj, other.obj, self.pad_name, other.pad_name)

    def call(self, f, **kwargs):
        "A sink element that calls the given function on each buffer"
        return CallbackIterEl(self.pipeline, f, **kwargs)
    

    def from_iter(self, inp, framerate=30, extractor=ImageExtractor, returns_timestamp=False):
        '''
        Returns a PipelineEl that wraps an appsrc element and produces buffers from the iterator passed in to `inp`

        Keyword args:

        * extractor: an Extractor used to convert to/from python objects. this is also where the element's caps come from
        * framerate: the frame rate of the source in frames per second
        * returns_timestamp: if this is True, the iterator produces tuples of `(timestamp in nanoseconds, duration in nanoseconds, value)` instead of simply producing values
        '''
        return IteratorSourceWrapper(self.pipeline, inp,
            framerate=framerate, extractor=extractor, returns_timestamp=returns_timestamp)

    def map(self, f, inp_extractor=ImageExtractor, outp_extractor=ImageExtractor, **kwargs):
        '''
        Returns a PipelineEl that wraps a filter element and passes buffers through the supplied function

        Keyword args:
            inp_extractor: Extractor to convert upstream buffers to python objects to pass to f
            outp_extractor: Extractor to convert values returned from f to buffers
            pass_meta: if True, f takes a second argument which is a tuple of (pts, duration, offset)
        '''
        return MapElement(self.pipeline, inp_extractor, outp_extractor, f, **kwargs)

    def multimap(self, *args, **kwargs):
        '''
        Returns a PipelineEl that wraps an aggregator element and passes buffers from multiple upstreams as separate arguments to the spplied function.

        Positional args:

        * inp_extractors: collection of Extractors for the upstreams. the number of arguments passed to the callback will be the length of this collection.
        * outp_extractor: the Extractor to handle values returned by the callback
        * callback: the function this element will wrap

        The caps for the various pads of this element are set by the given Extractors

        '''
        return MultiMap(self.pipeline, *args, **kwargs)

    def to_iter(self, **kwargs):
        '''
        Returns an iterator over the buffers downstream of this element.

        Keyword args:
            extractor: the Extractor to use to unmarshal the upstream buffers. defaults to ImageExtractor (so the iterator will produce PIL Image objects)
        '''
        return CallbackIterSink(self.pipeline, self, **kwargs)

    def filter_meta(self, f):
        '''
        Calls the given function to filter upstream buffers.
        The function is called with three arguments: pts, duration and offset
        If the function returns False, the buffer is dropped.
        
        Returns self (so method chaining works)
        '''
        cc.add_meta_filter(self.obj, f)
        return self

class PipelineElNoNamedPads(PipelineEl):

    def copy(self):
        raise TypeError()

    pad_name = None

class CallbackIterEl(PipelineElNoNamedPads):

    def __init__(self, pipeline, f, extractor=ImageExtractor):
        self.pipeline = pipeline
        self.extractor = extractor
        self.f = f
        self.obj = cc.make_callback_iter_el(pipeline.pipeline, self._on_cb)
        self.pad_name = None

    def _on_cb(self, data, caps, pts, duration):
        try:
            if self.extractor is None:
                self.f(data, caps, pts, duration)
            else:
                caps = Caps.from_cc(caps)
                self.f(self.extractor.unpack(data, caps))
        except Exception as e:
            traceback.print_exc()
            self.pipeline.exc = e

class MapElement(PipelineElNoNamedPads):

    def __init__(self, pipeline, inp_extractor, outp_extractor, callback, pass_meta=False):
        self.pipeline = pipeline
        self.pad_name = None
        self.callback = callback
        self.inp_extractor = inp_extractor
        self.outp_extractor = outp_extractor
        name = 'udf:%d' % hash(self)
        self.set_obj(cc.make_callback_transform(
            self.pipeline.pipeline, 
            inp_extractor.__static_caps__.caps, outp_extractor.__static_caps__.caps, 
            self._on_callback, name, pass_meta), 
            name)

    def _on_callback(self, inp_caps, outp_caps, data, *extra_args):
        inp_caps = Caps.from_cc(inp_caps)
        outp_caps = Caps.from_cc(outp_caps)
        try:
            inp = self.inp_extractor.unpack(data, inp_caps)
            outp = self.callback(inp, *extra_args)
            res = self.outp_extractor.pack(outp, outp_caps)
        except Exception as e:
            self.pipeline.exc = e
            raise e
        return res 

class MultiMap(PipelineElNoNamedPads):

    def __init__(self, pipeline, inp_extractors, outp_extractor, callback):
        self.pipeline = pipeline
        self.inp_extractors = inp_extractors
        self.outp_extractor = outp_extractor
        self.callback = callback

        if len(inp_extractors) < 1:
            raise ValueError('no input extractors specified')

        self.set_obj(cc.make_multi_map(
            pipeline.pipeline,
            self._on_callback,
            tuple(v.__static_caps__.caps for v in inp_extractors),
            outp_extractor.__static_caps__.caps), 'multimap:%d' % hash(self))

    def _on_callback(self, inp_buffers, outp_caps):
        try:
            res = self.outp_extractor.pack(
                self.callback(*[
                    x.unpack(v, Caps.from_cc(c)) for x,(v,c) in zip(self.inp_extractors, inp_buffers)
                    ]), Caps.from_cc(outp_caps))
            if type(res) != bytes:
                raise TypeError
            return res
        except Exception as e:
            self.pipeline.exc = e

class IteratorSourceWrapper(PipelineElNoNamedPads):

    def __init__(self, pipeline, inp_iter, 
        framerate=30, extractor=ImageExtractor, returns_timestamp=False):

        self.returns_timestamp = returns_timestamp
        self.inp_iter = inp_iter
        self.extractor = extractor
        self.pipeline = pipeline
        self.pad_name = None
        self.nanos_per_frame = int(NANOS_PER_SECOND / framerate)

        self.set_obj(cc.make_iterator_source(
            pipeline.pipeline,
            self,
            extractor.__static_caps__.caps),
            'appsrc:%d' % hash(self))


    def __iter__(self):
        total_time = 0
        try:
            for i, obj in enumerate(self.inp_iter):
                if obj is None:
                    raise RuntimeError('%r returned none' % type(self.inp_iter))
                caps = Caps.from_cc(cc.get_static_pad_caps(self.obj, 'src'))
                if self.returns_timestamp:
                    ts, duration, obj = obj
                    yield (
                        self.extractor.pack(obj, caps),
                        ts, duration, i)
                else:
                    yield (
                        self.extractor.pack(obj, caps),
                        total_time,
                        self.nanos_per_frame,
                        i)
                    total_time += self.nanos_per_frame
        except Exception as e:
            self.pipeline.exc = e

class deftransform:
    '''
    function decorator that turns a python function into a value that can be used in a pipeline

    eg:

    ```python
    @deftransform(ImageExtractor, ImageExtractor)
    def emboss(frame):
        return frame.filter(ImageFilter.EMBOSS)

    with Pipeline() as p:
        p >> 'videotestsrc' >> emboss() >> 'autovideosink'
    ```
    '''

    def __init__(self, inp_extractor, outp_extractor):
        self._inp_extractor = inp_extractor
        self._outp_extractor = outp_extractor
        self._callback = None

    def __call__(self, callback):
        self._callback = callback
        return self._take_args

    def _take_args(self, *args, **kwargs):
        return partial(self._construct, args, kwargs)

    def _construct(self, args, kwargs, pipeline):
        return MapElement(pipeline, self._inp_extractor, self._outp_extractor, 
            partial(self._callback, *args, **kwargs))

BufferPull = namedtuple('BufferPull', 'data caps pts duration offset')

class CallbackIterSink(PipelineElNoNamedPads):

    def __init__(self, pipeline, end_el, extractor=ImageExtractor):
        self.pipeline = pipeline
        self.pad_name = None
        self.obj = cc.make_callback_sink(pipeline.pipeline, 
            extractor.__static_caps__.caps if extractor is not None else None,
            1)
        self.extractor = extractor
        end_el.link(self)

    def __iter__(self):
        while 1:
            v = cc.appsink_pull_buffer(self.obj, NANOS_PER_SECOND // 10)
            if v is False:
                if self.pipeline.is_done:
                    if self.pipeline.exc is not None:
                        raise self.pipeline.exc
                    break
                else:
                    continue
            if v is None:
                break

            if self.extractor is None:
                yield v
            else:
                buf, caps, timestamp, duration, offset = v
                yield self.extractor.unpack(buf, Caps.from_cc(caps))


def buffers_overlap(a, b):
    if a is None:
        return False
    if b is None:
        return False
    if a.pts == b.pts:
        return True
    if a.pts < b.pts:
        return (a.pts + a.duration) > b.pts
    else:
        return (b.pts + b.duration) > a.pts

class MultiCallbackSink(PipelineElNoNamedPads):

    def __init__(self, pipeline, elements, extractors=None):
        if extractors is None:
            extractors = [ImageExtractor] * len(elements)
        self.pipeline = pipeline
        self.pad_name = None
        self.elements = elements
        self.extractors = extractors
        sinks = []
        for extractor, element in zip(extractors, elements):
            sink = cc.make_callback_sink(pipeline.pipeline, extractor.__static_caps__.caps, 999)
            cc.link_elements(element.obj, sink)
            sinks.append(sink)
        self.sinks = sinks
        self.buffers = [None] * len(elements)

    def min_idx(self):
        res = None
        res_i = 0
        for i, buf in enumerate(self.buffers):
            if self.buffers[i] is None:
                return i
            buf = buf[0]
            if res is None:
                res = buf
            if buf.pts < res.pts:
                res = buf
                res_i = i
        return res_i

    def pull_idx(self, idx):
        el = self.sinks[idx]
        buf = cc.appsink_pull_buffer(el, NANOS_PER_SECOND // 10)
        if buf in (None, False):
            return buf
        buf = BufferPull(*buf)
        val = self.extractors[idx].unpack(buf.data, Caps.from_cc(buf.caps))
        return (buf, val)

    def all_buffers_overlap(self):
        for v in self.buffers:
            if not v:
                return False
            a, _ = v
            for v in self.buffers:
                if not v:
                    return False
                b, _ = v
                if a == b:
                    continue
                if not buffers_overlap(a, b):
                    return False
        return True

    def __iter__(self):
        while 1:
            idx = self.min_idx()
            buf = self.pull_idx(idx)
            if buf is None:
                break
            if buf is False:
                continue
            self.buffers[idx] = buf
            if self.all_buffers_overlap():
                yield tuple([v[1] for v in self.buffers])
        self.pipeline._post_run()


import webbrowser, socketserver
from http.server import BaseHTTPRequestHandler
def browser_open(data, mime=None):
    class Handler(BaseHTTPRequestHandler):

        def do_GET(self):
            self.send_response(200)
            if mime is not None:
                self.send_header('Content-Type', mime)
            self.end_headers()
            self.wfile.write(data)
            self.wfile.close()

    def _opener(port):
        time.sleep(0.5)
        webbrowser.open('http://127.0.0.1:%d/' % port)

    with socketserver.TCPServer(('127.0.0.1', 0), Handler) as server:
        open_thread = threading.Thread(target=_opener, args=(server.server_address[1],))
        open_thread.start()
        server.handle_request()

class Pipeline:

    def __init__(self, 
        gen_fn=None, 
        name=None, 
        debug_viz=False, 
        iter_extractor=ImageExtractor,
        cutlist=None):
        if name is None:
            name = str(hash(self))

        self._intervals = []

        self.stacks = {}
        "@private"

        self.error_stack = None
        "@private"

        self.exc = None
        "@private"

        self.run_lock = threading.Lock()
        "@private"

        self.run_lock.acquire(blocking=False)

        self.pipeline = cc.make_pipeline(name, self._on_done)
        "@private"

        self.is_done = False
        "@private"

        self.gen_el = None
        "@private"

        self.debug_viz = debug_viz
        "@private"

        self.iter_extractor = iter_extractor
        "@private"

        self.cutlist = cutlist
        "@private"

        self.is_running = False
        "@private"


        if gen_fn is not None:
            self.gen_el = gen_fn(PipelineEl(self, None))

    def _on_done(self, exc, el_names):
        self.is_running = False
        if not self.is_done:
            if el_names is not None:
                for name in reversed(el_names):
                    try:
                        self.error_stack = self.stacks[name]
                        break
                    except KeyError:
                        pass
            if self.exc is None:
                self.exc = exc
            self.is_done = True
            self.run_lock.release()

    def run_async(self):
        "Start the pipeline and return immediately"

        if self.is_done:
            return
        if self.is_running:
            return
        if self.debug_viz:
            import graphviz
            debug_dot = cc.dot_viz(self.pipeline)
            svg = graphviz.pipe('dot', 'svg', debug_dot)
            browser_open(svg, 'image/svg+xml')
        if self.cutlist is not None:
            self._load_cutlist()
        cc.run_pipeline(self.pipeline)
        self.is_running = True

        for cb, interval in self._intervals:
            self._set_interval(cb, interval)
        self._intervals = []

    def run(self):
        "Start the pipeline and block until complete"

        self.run_async()
        try:
            self.run_lock.acquire()
            self.run_lock.release()
        except KeyboardInterrupt:
            self.close()
            raise KeyboardInterrupt
        self._post_run()

    def _post_run(self):
        if self.exc is not None:
            if self.error_stack is not None:
                try:
                    self.exc.add_stack_info(self.error_stack)
                except AttributeError:
                    pass
            raise self.exc

    def set_interval(self, cb, interval):
        """
        Call the function cb every interval nanoseconds in timeline time.
        That is, not necessarily in wall time, but at the 'playback speed'.
        The interval is disabled when the callback returns False
        """
        if self.is_running:
            self._set_interval(cb, interval)
        else:
            self._intervals.append((cb, interval))

    def _set_interval(self, cb, interval):
        return cc.set_interval(self.pipeline, cb, interval)

    def _load_cutlist(self):
        self.cutlist.sort()
        self.cutlist_idx = 0
        prev_cut = None
        shortest_cut = None
        for cut_start, cut_end in self.cutlist:
            if prev_cut is not None:
                duration = cut - prev_cut
                if shortest_cut is None or duration < shortest_cut:
                    shortest_cut = duration
        self.set_interval(self._cutlist_cb, shortest_cut)

    def _cutlist_cb(self, cur_timestamp):
        while 1:
            cut_start, cut_end = self.cutlist[self.cutlist_idx]
            if cur_timestamp < cut_start:
                self.seek(cut_start)
                return
            if cur_timestamp > cut_end:
                self.cutlist_idx += 1
                if self.cutlist_idx >= len(self.cutlist)-1:
                    self.close()
                    return False
                continue
            break
           
    def seek(self, timestamp):
        "seek the timeline to the given time in nanoseconds"
        cc.seek(self.pipeline, timestamp)

    def close(self):
        "Stop and clean up the pipeline"

        cc.stop_pipeline(self.pipeline)
        self._post_run()

    def __enter__(self):
        return PipelineEl(self, None)

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is not None:
            raise exc_val
        
        self.run()

    def __iter__(self):
        if self.gen_el is None:
            return []

        res = CallbackIterSink(self, self.gen_el, extractor=self.iter_extractor)
        self.run_async()
        for frame in res:
            yield frame
        self._post_run()
