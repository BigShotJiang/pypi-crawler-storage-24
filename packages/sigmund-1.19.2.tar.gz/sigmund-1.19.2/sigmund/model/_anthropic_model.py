from . import BaseModel
from .. import config, utils
import logging
import json
logger = logging.getLogger('sigmund')


class AnthropicModel(BaseModel):

    supports_not_done_yet = False

    def __init__(self, sigmund, model, **kwargs):
        from anthropic import Anthropic, AsyncAnthropic
        super().__init__(sigmund, model, **kwargs)
        self._tool_use_id = 0
        self._client = Anthropic(api_key=config.anthropic_api_key)
        self._async_client = AsyncAnthropic(api_key=config.anthropic_api_key)

    def predict(self, messages, attachments=None, track_tokens=True,
                stream=False):
        if isinstance(messages, str):
            return super().predict([self.convert_message(messages)],
                                   attachments, track_tokens, stream=stream)
        messages = utils.prepare_messages(messages, allow_ai_first=False,
                                          allow_ai_last=False,
                                          merge_consecutive=True)
        messages = [self.convert_message(message) for message in messages]
        # The Anthropic messages API expects thinking blocks if thinking mode is
        # enabled. These thinking blocks are embedded in plain text in the 
        # responses and should be extracted. This also changes the message 
        # content from plain text to a list of blocks.
        if self._thinking:
            for message in messages:
                # only AI messages have thinking blocks
                if message['role'] != 'assistant':
                    continue                
                content = message['content']
                blocks = self.extract_thinking_blocks(content)
                if blocks is None:
                    continue
                message['content'] = blocks
                n_thinking = sum(
                    1 for b in blocks if b['type'] == 'thinking')
                logger.info(
                    f'extracted {n_thinking} thinking block(s)')
        # The Anthropic messages API doesn't accept tool results in a separate
        # message. Instead, tool results are included as a special content 
        # block in a user message. Since two subsequent user messages aren't
        # allowed, we need to convert a tool message to a user message and if
        # necessary merge it with the next user message.
        while True:
            logger.info('entering message postprocessing loop')
            for i, message in enumerate(messages):
                if message['role'] == 'tool':
                    if i == 0:
                        raise ValueError(
                            'The first message cannot be a tool message')
                    logger.info('converting tool message to user message')
                    try:
                        tool_info = json.loads(message['content'])
                    except json.JSONDecodeError:
                        # This appears to happen under rare edge cases
                        logger.warning('tool message content is not valid JSON')
                        tool_info = {'content': '',
                                     'args': '',
                                     'name': 'missing_tool'}
                    message['role'] = 'user'
                    if tool_info['content'] is None:
                        tool_info['content'] = ''
                    message['content'] = [{
                        'type': 'tool_result',
                        # IDs formatted like this: toolu_01WaeSyitUGJFaaPe68cJuEv
                        'tool_use_id': f'toolu_{self._tool_use_id:024}',
                        'content': [{
                            'type': 'text',
                            'text': tool_info['content']
                        }]
                    }]
                    # The previous message needs to have a tool-use block. If
                    # necessary, this means that the content is changed to a
                    # list of blocks from a plain text.
                    prev_message = messages[i - 1]
                    if isinstance(prev_message['content'], str):                        
                        prev_message['content'] = [
                            {'type': 'text',
                             'text': prev_message['content']}
                        ]
                    prev_message['content'].append(
                        {'type': 'tool_use',
                         'id': f'toolu_{self._tool_use_id:024}',
                         'input': {'args': tool_info['args']},
                         'name': tool_info['name']
                        }
                    )
                    self._tool_use_id += 1
                    if len(messages) > i + 1:
                        next_message = messages[i + 1]
                        if next_message['role'] == 'user':
                            logger.info('merging tool and user message')
                            message['content'].append({
                                "type": "text",
                                "text": next_message['content']
                            })
                            break
            else:
                break
            logger.info('dropping duplicate user message')
            messages.remove(next_message)
        # The first message is used as the system message. This has to be a 
        # text-only, which means that any tool_use block needs to be removed.
        # By extension, this means that any tool_result block in the subsequent
        # user message should also be removed, because a tool_result block needs
        # to be preceded by a tool_use block.
        if isinstance(messages[0]['content'], list):
            logger.info('removing tool use and result from first two messages')
            messages[0]['content'] = messages[0]['content'][0]['text']
            messages[1]['content'] = messages[1]['content'][0]['content'][0]['text']
            if not messages[1]['content'].strip():
                logger.info('filling leading empty user message')
                messages[1]['content'] = '(This user message was empty.)'
        # Attachments are included with the last message. The content is now
        # no longer a single str, but a list of dict
        if attachments:
            logger.info('adding attachments to last message')
            content = messages[-1]['content']
            # If the content is plain text, convert it to a list of blocks
            if isinstance(content, str):
                content = [{'type': 'text', 'text': content}]
            for attachment in attachments:
                # Decompose the HTML-style data into a mimetype and the 
                # actual data
                url = attachment['url']
                mimetype = url[5:url.find(';')]
                data = url[url.find(',') + 1:]
                if attachment['type'] == 'image':
                    content.append({
                        'type': 'image',
                        'source': {'type': 'base64',
                                   'media_type': mimetype,
                                   'data': utils.limit_image_size(data)}
                    })
                elif attachment['type'] == 'document':
                    content.append({
                        'type': 'document',
                        'source': {'type': 'base64',
                                   'media_type': mimetype,
                                   'data': data}
                    })
            messages[-1]['content'] = content
        return super().predict(messages, attachments, track_tokens,
                               stream=stream)

    def get_response(self, response):
        """Converts an Anthropic response into a flat HTML string,
        preserving the interleaved order of thinking and text blocks."""
        parts = []
        tool_message_prefix = ''
        for block in response.content:
            if block.type == 'tool_use':
                if self._tools:
                    for tool in self._tools:
                        if tool.name == block.name:
                            return tool.bind(
                                json.dumps(block.input),
                                message_prefix=tool_message_prefix + '\n\n')
                return self.invalid_tool
            if block.type == 'text':
                parts.append(block.text)
                tool_message_prefix += block.text
            if block.type == 'thinking':
                thinking_html = self.embed_thinking_block(
                    block.signature, block.thinking)
                parts.append(thinking_html)
                tool_message_prefix += thinking_html
        return '\n'.join(parts)

    def _tool_args(self):
        if not self._tools:
            return {}
        alternative_format_tools = []
        for tool in self.tools():
            if tool['type'] == 'function':
                function = tool['function']
                alt_tool = {
                    "name": function['name'],
                    "description": function['description'],
                    "input_schema": function['parameters']
                }
                alternative_format_tools.append(alt_tool)
        return {'tools': alternative_format_tools}

    def _prepare_invoke_kwargs(self, messages):
        """Prepares the keyword arguments and messages for the Anthropic API
        call. Returns a (messages, kwargs) tuple."""
        kwargs = self._tool_args()
        kwargs.update(config.anthropic_kwargs)
        # If the first message is the system prompt, we need to separate this
        # from the user and assistant messages, because the Anthropic messages
        # API takes this as a separate keyword argument.
        if messages[0]['role'] == 'system':
            kwargs['system'] = messages[0]['content']
            messages = messages[1:]
        # Claude 4.6 Sonnet/ Opus use adaptive thinking
        if '4-6' in self._model:
            kwargs['thinking'] = {"type": "adaptive"}
        else:
            if self._thinking:
                kwargs['thinking'] = {
                    "type": "enabled",
                    "budget_tokens": config.anthropic_max_thinking_tokens
                }
        return messages, kwargs
        
    def _print_error(self, messages, kwargs):
        import pprint
        print('=== an error occurred while sending messages')
        pprint.pprint(messages)
        print('=== system message')
        print(kwargs.get('system', '(none)'))
        print('***')

    def invoke(self, messages):
        messages, kwargs = self._prepare_invoke_kwargs(messages)
        try:
            with self._client.messages.stream(
                model=self._model, messages=messages, **kwargs
            ) as stream:                
                return stream.get_final_message()
        except Exception:
            self._print_error(messages, kwargs)
            raise

    def stream_invoke(self, messages):
        """A generator that returns (text, complete) tuples. During streaming
        complete is False. For the final message, it is True.
        """
        messages, kwargs = self._prepare_invoke_kwargs(messages)
        try:
            with self._client.messages.stream(
                model=self._model, messages=messages, **kwargs
            ) as stream:
                all_text = ''
                for text in stream.text_stream:
                    if config.log_replies:
                        logger.info(f'streaming: {text}')
                    all_text += text
                    yield all_text, False
                if config.log_replies:
                    logger.info('stream ended')
                yield stream.get_final_message(), True
        except Exception:
            self._print_error(messages, kwargs)
            raise

    async def async_invoke(self, messages):
        messages, kwargs = self._prepare_invoke_kwargs(messages)
        try:
            async with self._async_client.messages.stream(
                model=self._model, messages=messages, **kwargs
            ) as stream:
                return await stream.get_final_message()
        except Exception:
            self._print_error(messages, kwargs)
            raise
