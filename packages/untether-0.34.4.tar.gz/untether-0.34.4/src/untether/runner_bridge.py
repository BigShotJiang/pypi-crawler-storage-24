from __future__ import annotations

import time
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import Any

import anyio

from .context import RunContext
from .error_hints import get_error_hint as _get_error_hint
from .logging import bind_run_context, get_logger
from .model import ActionEvent, CompletedEvent, ResumeToken, StartedEvent, UntetherEvent
from .presenter import Presenter
from .markdown import format_meta_line, render_event_cli
from .runner import Runner
from .progress import ProgressTracker
from .transport import (
    ChannelId,
    MessageId,
    MessageRef,
    RenderedMessage,
    SendOptions,
    ThreadId,
    Transport,
)

logger = get_logger(__name__)

# ---------------------------------------------------------------------------
# Ephemeral message registry
# ---------------------------------------------------------------------------
# Callback handlers (e.g. approve/deny) can register messages here so that
# ProgressEdits.delete_ephemeral() cleans them up when the run finishes.
# Keyed by (channel_id, progress_message_id).

_EPHEMERAL_MSGS: dict[tuple[ChannelId, MessageId], list[MessageRef]] = {}


def register_ephemeral_message(
    channel_id: ChannelId,
    anchor_message_id: MessageId,
    ref: MessageRef,
) -> None:
    """Register a message for deletion when the anchored run finishes."""
    key = (channel_id, anchor_message_id)
    _EPHEMERAL_MSGS.setdefault(key, []).append(ref)


# Usage alert thresholds (percentage of 5h window)
_USAGE_WARN_PCT = 70
_USAGE_CRITICAL_PCT = 90


def _load_footer_settings():
    """Load footer settings from config, returning defaults if unavailable."""
    try:
        from .settings import FooterSettings, load_settings_if_exists

        result = load_settings_if_exists()
        if result is None:
            return FooterSettings()
        settings, _ = result
        return settings.footer
    except Exception:  # noqa: BLE001
        logger.debug("footer_settings.load_failed", exc_info=True)
        from .settings import FooterSettings

        return FooterSettings()


def _load_watchdog_settings():
    """Load watchdog settings from config, returning None if unavailable."""
    try:
        from .settings import load_settings_if_exists

        result = load_settings_if_exists()
        if result is None:
            return None
        settings, _ = result
        return settings.watchdog
    except Exception:  # noqa: BLE001
        logger.debug("watchdog_settings.load_failed", exc_info=True)
        return None


_DEFAULT_PREAMBLE = (
    "[Untether] You are running via Untether, a Telegram bridge for coding agents. "
    "The user is interacting through Telegram on a mobile device.\n\n"
    "Key constraints:\n"
    "- The user can ONLY see your final assistant text messages\n"
    "- Tool calls, thinking blocks, file contents, and terminal output are invisible\n"
    "- Keep the user informed by writing clear status updates as visible text\n"
    "- If hooks fire at session end, your final response MUST still contain the "
    "user's requested content. Hook concerns are secondary — briefly note them "
    "AFTER the main content, never instead of it.\n\n"
    "Every response that completes work MUST end with a structured summary:\n"
    "  ## Summary\n"
    "  ### Completed\n"
    "  - [What was done, with specific file paths and line numbers where relevant]\n"
    "  - [Key decisions made and why]\n"
    "  ### Plan/Document Created (if applicable)\n"
    "  - [Path and concise summary of any plan, design doc, or document created — "
    "the user cannot easily open files from Telegram]\n"
    "  ### Next Steps\n"
    "  - [Remaining work, if any]\n"
    "  ### Decisions Needed (if any)\n"
    "  - [Blocking questions — state your recommended option clearly]"
)


def _load_preamble_settings():
    """Load preamble settings from config, returning defaults if unavailable."""
    try:
        from .settings import PreambleSettings, load_settings_if_exists

        result = load_settings_if_exists()
        if result is None:
            return PreambleSettings()
        settings, _ = result
        return settings.preamble
    except Exception:  # noqa: BLE001
        logger.debug("preamble_settings.load_failed", exc_info=True)
        from .settings import PreambleSettings

        return PreambleSettings()


def _apply_preamble(prompt: str) -> str:
    """Prepend the context preamble to the prompt if enabled."""
    cfg = _load_preamble_settings()
    if not cfg.enabled:
        logger.debug("preamble.disabled")
        return prompt
    text = cfg.text if cfg.text is not None else _DEFAULT_PREAMBLE
    if not text:
        logger.debug("preamble.disabled")
        return prompt

    # Append AskUserQuestion guidance based on per-chat toggle
    from .runners.run_options import get_run_options

    run_opts = get_run_options()
    # Default is ON (ask_questions=None treated as True)
    ask_questions = run_opts.ask_questions if run_opts else None
    if ask_questions is False:
        text += (
            "\n\nDo NOT call AskUserQuestion. Proceed with reasonable defaults. "
            "State any assumptions in your Decisions Needed summary section."
        )
    else:
        text += (
            "\n\nWhen you need clarification from the user, use AskUserQuestion "
            "with clear options. The user will see interactive buttons to choose from."
        )

    logger.info("preamble.applied", preamble_len=len(text))
    return f"{text}\n\n---\n\n{prompt}"


def _resolve_presenter(
    default_presenter: Presenter, channel_id: ChannelId
) -> Presenter:
    """Return a presenter with the effective verbosity for this channel.

    Checks for a per-chat /verbose override. If one exists and differs from
    the default presenter's formatter, creates a new presenter with the
    overridden verbosity. Otherwise returns the default.
    """
    try:
        from .telegram.commands.verbose import get_verbosity_override
        from .telegram.bridge import TelegramPresenter
        from .markdown import MarkdownFormatter

        override = get_verbosity_override(channel_id)
        if override is None:
            return default_presenter
        # Only create a new presenter if the override differs
        if (
            isinstance(default_presenter, TelegramPresenter)
            and default_presenter._formatter.verbosity == override
        ):
            return default_presenter
        if isinstance(default_presenter, TelegramPresenter):
            formatter = MarkdownFormatter(
                max_actions=default_presenter._formatter.max_actions,
                command_width=default_presenter._formatter.command_width,
                verbosity=override,
            )
            return TelegramPresenter(
                formatter=formatter,
                message_overflow=default_presenter._message_overflow,
            )
    except Exception:  # noqa: BLE001
        logger.debug("resolve_presenter.failed", exc_info=True)
    return default_presenter


async def _maybe_append_usage_footer(
    msg: RenderedMessage,
    *,
    always_show: bool = False,
) -> RenderedMessage:
    """Fetch Claude Code usage and append a footer.

    When *always_show* is True, always appends a compact usage line.
    When False (default), only appends warnings at >=70% threshold.
    """
    try:
        from .telegram.commands.usage import (
            _time_until,
            fetch_claude_usage,
            format_usage_compact,
        )

        data = await fetch_claude_usage()

        if always_show:
            compact = format_usage_compact(data)
            if compact:
                footer = f"\n\u26a1 {compact}"
                return RenderedMessage(text=msg.text + footer, extra=msg.extra)
            return msg

        # Threshold-based warning (existing behaviour)
        five_hour = data.get("five_hour")
        seven_day = data.get("seven_day")
        if not five_hour:
            return msg

        pct_5h = five_hour["utilization"]
        if pct_5h < _USAGE_WARN_PCT:
            return msg

        pct_7d = seven_day["utilization"] if seven_day else 0
        reset = _time_until(five_hour["resets_at"])

        if pct_5h >= 100:
            footer = f"\n\U0001f6d1 5h limit hit \u2014 resets in {reset}"
        elif pct_5h >= _USAGE_CRITICAL_PCT:
            footer = f"\n\u26a0\ufe0f 5h: {pct_5h:.0f}% | Weekly: {pct_7d:.0f}% \u2014 approaching limit (resets in {reset})"
        else:
            footer = f"\n\u26a1 5h: {pct_5h:.0f}% | Weekly: {pct_7d:.0f}% (resets in {reset})"

        return RenderedMessage(text=msg.text + footer, extra=msg.extra)
    except Exception:  # noqa: BLE001 — cosmetic footer must never block final message
        logger.debug("usage_footer.failed", exc_info=True)
        return msg


def _format_run_cost(usage: dict[str, Any] | None) -> str | None:
    """Format run cost/usage from CompletedEvent into a footer line."""
    if not usage:
        return None
    cost = usage.get("total_cost_usd")
    token_usage = usage.get("usage")
    has_tokens = isinstance(token_usage, dict) and (
        token_usage.get("input_tokens", 0) or token_usage.get("output_tokens", 0)
    )
    if cost is None and not has_tokens:
        return None
    parts: list[str] = []
    if cost is not None:
        if cost >= 0.01:
            parts.append(f"${cost:.2f}")
        else:
            parts.append(f"${cost:.4f}")
    turns = usage.get("num_turns")
    if turns:
        parts.append(f"{turns} turns")
    duration_ms = usage.get("duration_ms")
    if duration_ms:
        secs = duration_ms / 1000
        if secs >= 60:
            mins = int(secs // 60)
            remaining = int(secs % 60)
            parts.append(f"{mins}m {remaining}s API")
        else:
            parts.append(f"{secs:.1f}s API")
    if has_tokens:
        input_tokens = token_usage.get("input_tokens", 0)
        output_tokens = token_usage.get("output_tokens", 0)
        if input_tokens or output_tokens:

            def _fmt_tokens(n: int) -> str:
                if n >= 1_000_000:
                    return f"{n / 1_000_000:.1f}M"
                if n >= 1_000:
                    return f"{n / 1_000:.1f}k"
                return str(n)

            parts.append(
                f"{_fmt_tokens(input_tokens)} in / {_fmt_tokens(output_tokens)} out"
            )
    return " · ".join(parts) or None


def _check_cost_budget(usage: dict[str, Any] | None) -> str | None:
    """Check run cost against budget and return an alert string if needed."""
    if not usage:
        return None
    cost = usage.get("total_cost_usd")
    if cost is None or cost <= 0:
        return None
    try:
        from .cost_tracker import (
            CostBudget,
            check_run_budget,
            format_cost_alert,
            record_run_cost,
        )
        from .settings import load_settings_if_exists

        record_run_cost(cost)

        result = load_settings_if_exists()
        if result is None:
            return None
        settings, _ = result
        budget_cfg = settings.cost_budget
        if not budget_cfg.enabled:
            return None
        budget = CostBudget(
            max_cost_per_run=budget_cfg.max_cost_per_run,
            max_cost_per_day=budget_cfg.max_cost_per_day,
            warn_at_pct=budget_cfg.warn_at_pct,
            auto_cancel=budget_cfg.auto_cancel,
        )
        alert = check_run_budget(cost, budget)
        if alert is not None:
            return format_cost_alert(alert)
    except Exception as exc:  # noqa: BLE001
        logger.warning(
            "cost_budget.check_failed",
            error=str(exc),
            error_type=exc.__class__.__name__,
        )
    return None


def _record_export_event(
    evt: UntetherEvent, resume: ResumeToken | None, *, channel_id: ChannelId = 0
) -> None:
    """Record an event for the /export command."""
    try:
        from .telegram.commands.export import record_session_event, record_session_usage

        session_id = resume.value if resume else None
        if not session_id and isinstance(evt, StartedEvent) and evt.resume:
            session_id = evt.resume.value
        if not session_id:
            return
        event_dict: dict[str, Any] = {"type": evt.type}
        if isinstance(evt, StartedEvent):
            event_dict["engine"] = evt.engine
            event_dict["title"] = evt.title
        elif isinstance(evt, ActionEvent):
            event_dict["phase"] = evt.phase
            event_dict["ok"] = evt.ok
            event_dict["action"] = {
                "id": evt.action.id,
                "kind": evt.action.kind,
                "title": evt.action.title,
            }
        elif isinstance(evt, CompletedEvent):
            event_dict["ok"] = evt.ok
            event_dict["answer"] = evt.answer
            event_dict["error"] = evt.error
            if evt.usage:
                record_session_usage(session_id, evt.usage, channel_id=channel_id)
        record_session_event(session_id, event_dict, channel_id=channel_id)
    except Exception as exc:  # noqa: BLE001
        logger.warning(
            "export_event.record_failed",
            error=str(exc),
            error_type=exc.__class__.__name__,
        )


def _log_runner_event(evt: UntetherEvent) -> None:
    for line in render_event_cli(evt):
        logger.debug(
            "runner.event.cli",
            line=line,
            event_type=getattr(evt, "type", None),
            engine=getattr(evt, "engine", None),
        )


def _strip_resume_lines(text: str, *, is_resume_line: Callable[[str], bool]) -> str:
    prompt = "\n".join(
        line for line in text.splitlines() if not is_resume_line(line)
    ).strip()
    return prompt or "continue"


def _flatten_exception_group(error: BaseException) -> list[BaseException]:
    if isinstance(error, BaseExceptionGroup):
        flattened: list[BaseException] = []
        for exc in error.exceptions:
            flattened.extend(_flatten_exception_group(exc))
        return flattened
    return [error]


def _format_error(error: BaseException) -> str:
    cancel_exc = anyio.get_cancelled_exc_class()
    flattened = [
        exc
        for exc in _flatten_exception_group(error)
        if not isinstance(exc, cancel_exc)
    ]
    if len(flattened) == 1:
        return str(flattened[0]) or flattened[0].__class__.__name__
    if not flattened:
        return str(error) or error.__class__.__name__
    messages = [str(exc) for exc in flattened if str(exc)]
    if not messages:
        return str(error) or error.__class__.__name__
    if len(messages) == 1:
        return messages[0]
    return "\n".join(messages)


@dataclass(frozen=True, slots=True)
class IncomingMessage:
    channel_id: ChannelId
    message_id: MessageId
    text: str
    reply_to: MessageRef | None = None
    thread_id: ThreadId | None = None


@dataclass(frozen=True, slots=True)
class ExecBridgeConfig:
    transport: Transport
    presenter: Presenter
    final_notify: bool
    min_render_interval: float = 0.0


@dataclass(slots=True)
class RunningTask:
    resume: ResumeToken | None = None
    resume_ready: anyio.Event = field(default_factory=anyio.Event)
    cancel_requested: anyio.Event = field(default_factory=anyio.Event)
    done: anyio.Event = field(default_factory=anyio.Event)
    context: RunContext | None = None


RunningTasks = dict[MessageRef, RunningTask]


async def _send_or_edit_message(
    transport: Transport,
    *,
    channel_id: ChannelId,
    message: RenderedMessage,
    edit_ref: MessageRef | None = None,
    reply_to: MessageRef | None = None,
    notify: bool = True,
    replace_ref: MessageRef | None = None,
    thread_id: ThreadId | None = None,
) -> tuple[MessageRef | None, bool]:
    msg = message
    followups = message.extra.get("followups")
    if followups:
        extra = dict(message.extra)
        if reply_to is not None:
            extra.setdefault("followup_reply_to_message_id", reply_to.message_id)
        if thread_id is not None:
            extra.setdefault("followup_thread_id", thread_id)
        extra.setdefault("followup_notify", notify)
        msg = RenderedMessage(text=message.text, extra=extra)
    if edit_ref is not None:
        logger.debug(
            "transport.edit_message",
            channel_id=edit_ref.channel_id,
            message_id=edit_ref.message_id,
            rendered=msg.text,
        )
        edited = await transport.edit(ref=edit_ref, message=msg)
        if edited is not None:
            return edited, True
        logger.warning(
            "transport.edit_failed_fallback_send",
            channel_id=channel_id,
            edit_message_id=edit_ref.message_id,
        )

    logger.debug(
        "transport.send_message",
        channel_id=channel_id,
        reply_to_message_id=reply_to.message_id if reply_to else None,
        rendered=msg.text,
    )
    sent = await transport.send(
        channel_id=channel_id,
        message=msg,
        options=SendOptions(
            reply_to=reply_to,
            notify=notify,
            replace=replace_ref,
            thread_id=thread_id,
        ),
    )
    return sent, False


class ProgressEdits:
    def __init__(
        self,
        *,
        transport: Transport,
        presenter: Presenter,
        channel_id: ChannelId,
        progress_ref: MessageRef | None,
        tracker: ProgressTracker,
        started_at: float,
        clock: Callable[[], float],
        last_rendered: RenderedMessage | None,
        resume_formatter: Callable[[ResumeToken], str] | None = None,
        label: str = "working",
        context_line: str | None = None,
        thread_id: ThreadId | None = None,
        min_render_interval: float = 0.0,
        sleep: Callable[[float], Awaitable[None]] = anyio.sleep,
    ) -> None:
        self.transport = transport
        self.presenter = presenter
        self.channel_id = channel_id
        self.progress_ref = progress_ref
        self.tracker = tracker
        self.started_at = started_at
        self.clock = clock
        self.last_rendered = last_rendered
        self.resume_formatter = resume_formatter
        self.label = label
        self.context_line = context_line
        self.thread_id = thread_id
        self._approval_notified: bool = False
        self._approval_notify_ref: MessageRef | None = None
        self._min_render_interval = min_render_interval
        self._sleep = sleep
        self._last_render_at: float = 0.0
        self._has_rendered: bool = False
        self._last_event_at: float = clock()
        self._stall_warned: bool = False
        self._stall_warn_count: int = 0
        self._last_stall_warn_at: float = 0.0
        self._peak_idle: float = 0.0
        self._prev_diag: Any = None
        self._stall_check_interval: float = 60.0
        self._stall_repeat_seconds: float = 180.0
        self.pid: int | None = None
        self.stream: Any = None  # JsonlStreamState, set from run_runner_with_cancel
        self.cancel_event: anyio.Event | None = None  # threaded from RunningTask
        self.event_seq = 0
        self.rendered_seq = 0
        self.signal_send, self.signal_recv = anyio.create_memory_object_stream(1)

    async def run(self) -> None:
        if self.progress_ref is None:
            return
        stall_scope = anyio.CancelScope()

        async def _monitor() -> None:
            with stall_scope:
                await self._stall_monitor()

        async with anyio.create_task_group() as bg_tg:
            bg_tg.start_soon(_monitor)
            await self._run_loop(bg_tg)
            stall_scope.cancel()

    async def _stall_monitor(self) -> None:
        """Periodically check for event stalls, log diagnostics, and notify."""
        from .utils.proc_diag import collect_proc_diag, format_diag, is_cpu_active

        while True:
            await anyio.sleep(self._stall_check_interval)
            elapsed = self.clock() - self._last_event_at
            self._peak_idle = max(self._peak_idle, elapsed)

            # Use longer threshold when waiting for user approval or running a tool
            if self._has_pending_approval():
                threshold = self._STALL_THRESHOLD_APPROVAL
                threshold_reason = "pending_approval"
            elif self._has_running_tool():
                threshold = self._STALL_THRESHOLD_TOOL
                threshold_reason = "running_tool"
            else:
                threshold = self._STALL_THRESHOLD_SECONDS
                threshold_reason = "normal"
            if elapsed < threshold:
                continue
            logger.info(
                "progress_edits.stall_threshold_selected",
                channel_id=self.channel_id,
                threshold=threshold,
                reason=threshold_reason,
                elapsed=round(elapsed, 1),
            )
            now = self.clock()
            if (
                self._stall_warned
                and (now - self._last_stall_warn_at) < self._stall_repeat_seconds
            ):
                continue

            self._stall_warned = True
            self._stall_warn_count += 1
            self._last_stall_warn_at = now

            diag = collect_proc_diag(self.pid) if self.pid else None
            last_action = self._last_action_summary()

            recent = list(self.stream.recent_events) if self.stream else []
            stderr_hint = (
                self.stream.stderr_capture[-3:]
                if self.stream and self.stream.stderr_capture
                else None
            )

            logger.warning(
                "progress_edits.stall_detected",
                channel_id=self.channel_id,
                seconds_since_last_event=round(elapsed, 1),
                last_event_seq=self.event_seq,
                stall_warn_count=self._stall_warn_count,
                pid=self.pid,
                last_action=last_action,
                last_event_type=(self.stream.last_event_type if self.stream else None),
                process_alive=diag.alive if diag else None,
                process_state=diag.state if diag else None,
                tcp_established=diag.tcp_established if diag else None,
                tcp_total=diag.tcp_total if diag else None,
                rss_kb=diag.rss_kb if diag else None,
                fd_count=diag.fd_count if diag else None,
                cpu_active=(
                    is_cpu_active(self._prev_diag, diag)
                    if self._prev_diag and diag
                    else None
                ),
                recent_events=[(round(t, 1), lbl) for t, lbl in recent[-5:]],
                stderr_hint=stderr_hint,
            )
            self._prev_diag = diag

            # Auto-cancel: dead process, no-PID zombie, or absolute cap
            auto_cancel_reason: str | None = None
            if diag and diag.alive is False:
                auto_cancel_reason = "process_dead"
            elif (
                self.pid is None
                and self.event_seq == 0
                and self._stall_warn_count >= self._STALL_MAX_WARNINGS_NO_PID
            ):
                auto_cancel_reason = "no_pid_no_events"
            elif self._stall_warn_count >= self._STALL_MAX_WARNINGS:
                auto_cancel_reason = "max_warnings"

            if auto_cancel_reason is not None:
                logger.warning(
                    "progress_edits.stall_auto_cancel",
                    channel_id=self.channel_id,
                    reason=auto_cancel_reason,
                    stall_warn_count=self._stall_warn_count,
                    pid=self.pid,
                    event_seq=self.event_seq,
                )
                if self.cancel_event is not None:
                    self.cancel_event.set()
                try:
                    await self.transport.send(
                        channel_id=self.channel_id,
                        message=RenderedMessage(
                            text=f"Auto-cancelled: session appears stuck ({auto_cancel_reason})."
                        ),
                        options=SendOptions(thread_id=self.thread_id),
                    )
                except Exception:  # noqa: BLE001
                    logger.debug(
                        "progress_edits.stall_auto_cancel_notify_failed", exc_info=True
                    )
                # Close signal stream so _run_loop exits
                self.signal_send.close()
                return

            # Telegram notification
            parts = [f"⏳ No progress for {int(elapsed // 60)} min"]
            if self._stall_warn_count > 1:
                parts[0] += f" (warned {self._stall_warn_count}x)"
            parts.append("— session may be stuck.")
            if last_action:
                parts.append(f"Last: {last_action}")
            if diag:
                parts.append(f"PID {diag.pid}: {format_diag(diag)}")
            parts.append("/cancel to stop.")
            text = "\n".join(parts)
            try:
                await self.transport.send(
                    channel_id=self.channel_id,
                    message=RenderedMessage(text=text),
                    options=SendOptions(
                        thread_id=self.thread_id,
                    ),
                )
            except Exception:  # noqa: BLE001
                logger.debug(
                    "progress_edits.stall_notify_failed",
                    exc_info=True,
                )

    def _has_pending_approval(self) -> bool:
        """Check if the most recent non-completed action is waiting for user approval."""
        for action_state in reversed(list(self.tracker._actions.values())):
            if not action_state.completed:
                return bool(action_state.action.detail.get("inline_keyboard"))
            break  # only check the most recent
        return False

    def _has_running_tool(self) -> bool:
        """Check if any action is still running (e.g. Bash command, TaskOutput)."""
        for action_state in reversed(list(self.tracker._actions.values())):
            if not action_state.completed:
                return True
            break  # only check the most recent
        return False

    def _last_action_summary(self) -> str | None:
        """Return a short description of the most recent action."""
        for action_state in reversed(list(self.tracker._actions.values())):
            a = action_state.action
            status = "running" if not action_state.completed else "done"
            return f"{a.kind}:{a.title} ({status})"
        return None

    async def _run_loop(self, bg_tg: anyio.abc.TaskGroup) -> None:
        while True:
            while self.rendered_seq == self.event_seq:
                try:
                    await self.signal_recv.receive()
                except anyio.EndOfStream:
                    return

            # Debounce: never delay the first render; after that, batch events.
            if self._has_rendered and self._min_render_interval > 0:
                elapsed_since = self.clock() - self._last_render_at
                if elapsed_since < self._min_render_interval:
                    await self._sleep(self._min_render_interval - elapsed_since)

            seq_at_render = self.event_seq
            now = self.clock()
            state = self.tracker.snapshot(
                resume_formatter=self.resume_formatter,
                context_line=self.context_line,
                meta_formatter=format_meta_line,
            )
            rendered = self.presenter.render_progress(
                state, elapsed_s=now - self.started_at, label=self.label
            )
            # Detect approval button transitions for push notification
            new_kb = rendered.extra.get("reply_markup", {}).get("inline_keyboard", [])
            old_kb = (
                self.last_rendered.extra.get("reply_markup", {}).get(
                    "inline_keyboard", []
                )
                if self.last_rendered
                else []
            )
            has_approval = len(new_kb) > 1
            had_approval = len(old_kb) > 1

            try:
                if has_approval and not had_approval and not self._approval_notified:
                    self._approval_notified = True
                    # Contextual notification text
                    notify_text = "Action required \u2014 approval needed"
                    for a in state.actions:
                        if not a.completed and a.action.detail.get("ask_question"):
                            notify_text = "Question from Claude Code"
                            break

                    async def _send_notify(text: str) -> None:
                        try:
                            self._approval_notify_ref = await self.transport.send(
                                channel_id=self.channel_id,
                                message=RenderedMessage(text=text),
                                options=SendOptions(
                                    notify=True,
                                    reply_to=self.progress_ref,
                                    thread_id=self.thread_id,
                                ),
                            )
                        except Exception:  # noqa: BLE001
                            logger.debug(
                                "progress_edits.notify_send_failed", exc_info=True
                            )

                    bg_tg.start_soon(_send_notify, notify_text)
                elif had_approval and not has_approval:
                    ref_to_delete = self._approval_notify_ref
                    self._approval_notify_ref = None
                    self._approval_notified = False
                    if ref_to_delete is not None:

                        async def _delete_notify(ref: MessageRef) -> None:
                            try:
                                await self.transport.delete(ref=ref)
                            except Exception:  # noqa: BLE001
                                logger.debug(
                                    "progress_edits.notify_delete_failed",
                                    exc_info=True,
                                )

                        bg_tg.start_soon(_delete_notify, ref_to_delete)

                if rendered != self.last_rendered:
                    # Log keyboard transitions at info level for #103/#104 diagnostics
                    if has_approval and not had_approval:
                        logger.info(
                            "progress_edits.keyboard_attach",
                            channel_id=self.channel_id,
                            message_id=self.progress_ref.message_id,
                            keyboard_rows=len(new_kb),
                        )
                    logger.debug(
                        "transport.edit_message",
                        channel_id=self.channel_id,
                        message_id=self.progress_ref.message_id,
                        rendered=rendered.text,
                    )
                    edited = await self.transport.edit(
                        ref=self.progress_ref,
                        message=rendered,
                        wait=has_approval and not had_approval,
                    )
                    if edited is not None:
                        self.last_rendered = rendered
                        self._last_render_at = self.clock()
                        self._has_rendered = True
                    elif has_approval:
                        logger.warning(
                            "progress_edits.keyboard_edit_failed",
                            channel_id=self.channel_id,
                            message_id=self.progress_ref.message_id,
                            keyboard_rows=len(new_kb),
                        )
            except Exception:  # noqa: BLE001
                # Transport errors (timeouts, network issues) are best-effort —
                # never crash a run because a progress edit failed to send.
                logger.warning("progress_edits.transport_error", exc_info=True)

            self.rendered_seq = seq_at_render

    _STALL_THRESHOLD_SECONDS: float = 300.0  # 5 minutes
    _STALL_THRESHOLD_TOOL: float = 600.0  # 10 minutes when a tool is actively running
    _STALL_THRESHOLD_APPROVAL: float = 1800.0  # 30 minutes when waiting for approval
    _STALL_MAX_WARNINGS: int = 10  # absolute cap
    _STALL_MAX_WARNINGS_NO_PID: int = 3  # aggressive cap when pid=None + no events

    async def on_event(self, evt: UntetherEvent) -> None:
        if not self.tracker.note_event(evt):
            return
        if self.progress_ref is None:
            return
        now = self.clock()
        if self._stall_warned:
            elapsed_stall = now - self._last_event_at
            logger.info(
                "progress_edits.stall_recovered",
                channel_id=self.channel_id,
                stall_seconds=round(elapsed_stall, 1),
                stall_warn_count=self._stall_warn_count,
            )
            self._stall_warned = False
            self._stall_warn_count = 0
            self._prev_diag = None
        self._last_event_at = now
        self.event_seq += 1
        try:
            self.signal_send.send_nowait(None)
        except anyio.WouldBlock:
            pass
        except (anyio.BrokenResourceError, anyio.ClosedResourceError):
            pass

    async def delete_ephemeral(self) -> None:
        """Delete any tracked ephemeral notification messages."""
        if self._approval_notify_ref is not None:
            await self.transport.delete(ref=self._approval_notify_ref)
            self._approval_notify_ref = None
        # Drain messages registered by callback handlers (e.g. approve/deny feedback).
        if self.progress_ref is not None:
            key = (self.channel_id, self.progress_ref.message_id)
            refs = _EPHEMERAL_MSGS.pop(key, [])
            for ref in refs:
                await self.transport.delete(ref=ref)


@dataclass(frozen=True, slots=True)
class ProgressMessageState:
    ref: MessageRef | None
    last_rendered: RenderedMessage | None


async def send_initial_progress(
    cfg: ExecBridgeConfig,
    *,
    channel_id: ChannelId,
    reply_to: MessageRef,
    label: str,
    tracker: ProgressTracker,
    progress_ref: MessageRef | None = None,
    resume_formatter: Callable[[ResumeToken], str] | None = None,
    context_line: str | None = None,
    thread_id: ThreadId | None = None,
) -> ProgressMessageState:
    last_rendered: RenderedMessage | None = None

    state = tracker.snapshot(
        resume_formatter=resume_formatter,
        context_line=context_line,
    )
    initial_rendered = cfg.presenter.render_progress(
        state,
        elapsed_s=0.0,
        label=label,
    )
    sent_ref, _ = await _send_or_edit_message(
        cfg.transport,
        channel_id=channel_id,
        message=initial_rendered,
        edit_ref=progress_ref,
        reply_to=reply_to,
        notify=False,
        replace_ref=progress_ref,
        thread_id=thread_id,
    )
    if sent_ref is not None:
        last_rendered = initial_rendered
        logger.debug(
            "progress.sent",
            channel_id=sent_ref.channel_id,
            message_id=sent_ref.message_id,
        )

    return ProgressMessageState(
        ref=sent_ref,
        last_rendered=last_rendered,
    )


@dataclass(slots=True)
class RunOutcome:
    cancelled: bool = False
    completed: CompletedEvent | None = None
    resume: ResumeToken | None = None


async def run_runner_with_cancel(
    runner: Runner,
    *,
    prompt: str,
    resume_token: ResumeToken | None,
    edits: ProgressEdits,
    running_task: RunningTask | None,
    on_thread_known: Callable[[ResumeToken, anyio.Event], Awaitable[None]] | None,
    channel_id: ChannelId = 0,
) -> RunOutcome:
    outcome = RunOutcome()
    start_time = time.monotonic()
    try:
        async with anyio.create_task_group() as tg:

            async def run_runner() -> None:
                try:
                    async for evt in runner.run(prompt, resume_token):
                        _log_runner_event(evt)
                        if isinstance(evt, StartedEvent):
                            outcome.resume = evt.resume
                            bind_run_context(resume=evt.resume.value)
                            # Thread PID and stream to ProgressEdits
                            if evt.meta:
                                pid = evt.meta.get("pid")
                                if isinstance(pid, int):
                                    edits.pid = pid
                            _cs = getattr(runner, "current_stream", None)
                            if _cs is not None:
                                edits.stream = _cs
                            if running_task is not None and running_task.resume is None:
                                running_task.resume = evt.resume
                                try:
                                    if on_thread_known is not None:
                                        await on_thread_known(
                                            evt.resume, running_task.done
                                        )
                                finally:
                                    running_task.resume_ready.set()
                        elif isinstance(evt, CompletedEvent):
                            outcome.resume = evt.resume or outcome.resume
                            outcome.completed = evt
                        # A3: Record events for /export
                        _record_export_event(evt, outcome.resume, channel_id=channel_id)
                        await edits.on_event(evt)
                finally:
                    tg.cancel_scope.cancel()

            async def wait_cancel(task: RunningTask) -> None:
                await task.cancel_requested.wait()
                outcome.cancelled = True
                tg.cancel_scope.cancel()

            async def thread_pid() -> None:
                """Poll for early PID from subprocess spawn before StartedEvent."""
                for _ in range(50):  # poll up to 5s
                    pid = getattr(runner, "last_pid", None)
                    if isinstance(pid, int):
                        edits.pid = pid
                        cs = getattr(runner, "current_stream", None)
                        if cs is not None:
                            edits.stream = cs
                        return
                    await anyio.sleep(0.1)

            tg.start_soon(run_runner)
            tg.start_soon(thread_pid)
            if running_task is not None:
                edits.cancel_event = running_task.cancel_requested
                tg.start_soon(wait_cancel, running_task)
    except BaseExceptionGroup as eg:
        # Unwrap ExceptionGroup from anyio TaskGroup so callers' `except Exception`
        # handlers can catch the real error.  Filter out cancellation exceptions
        # (normal TaskGroup shutdown) and re-raise the first real exception.
        cancel_exc = anyio.get_cancelled_exc_class()
        non_cancelled = [
            exc
            for exc in _flatten_exception_group(eg)
            if not isinstance(exc, cancel_exc)
        ]
        if non_cancelled:
            raise non_cancelled[0] from eg

    # Session completion summary
    duration = time.monotonic() - start_time
    event_count = edits.stream.event_count if edits.stream else 0
    logger.info(
        "session.summary",
        session_id=outcome.resume.value if outcome.resume else None,
        engine=runner.engine,
        duration_seconds=round(duration, 1),
        event_count=event_count,
        stall_warnings=edits._stall_warn_count,
        peak_idle_seconds=round(edits._peak_idle, 1),
        last_event_type=edits.stream.last_event_type if edits.stream else None,
        cancelled=outcome.cancelled,
        ok=outcome.completed.ok if outcome.completed else None,
    )
    if event_count == 0 and not outcome.cancelled:
        logger.warning(
            "session.summary.no_events",
            session_id=outcome.resume.value if outcome.resume else None,
            engine=runner.engine,
            duration_seconds=round(duration, 1),
        )

    return outcome


def sync_resume_token(
    tracker: ProgressTracker, resume: ResumeToken | None
) -> ResumeToken | None:
    resume = resume or tracker.resume
    tracker.set_resume(resume)
    return resume


async def send_result_message(
    cfg: ExecBridgeConfig,
    *,
    channel_id: ChannelId,
    reply_to: MessageRef,
    progress_ref: MessageRef | None,
    message: RenderedMessage,
    notify: bool,
    edit_ref: MessageRef | None,
    replace_ref: MessageRef | None = None,
    delete_tag: str = "final",
    thread_id: ThreadId | None = None,
) -> None:
    final_msg, edited = await _send_or_edit_message(
        cfg.transport,
        channel_id=channel_id,
        message=message,
        edit_ref=edit_ref,
        reply_to=reply_to,
        notify=notify,
        replace_ref=replace_ref,
        thread_id=thread_id,
    )
    if final_msg is None:
        return
    if (
        progress_ref is not None
        and (edit_ref is None or not edited)
        and replace_ref is None
    ):
        logger.debug(
            "transport.delete_message",
            channel_id=progress_ref.channel_id,
            message_id=progress_ref.message_id,
            tag=delete_tag,
        )
        await cfg.transport.delete(ref=progress_ref)


async def handle_message(
    cfg: ExecBridgeConfig,
    *,
    runner: Runner,
    incoming: IncomingMessage,
    resume_token: ResumeToken | None,
    context: RunContext | None = None,
    context_line: str | None = None,
    strip_resume_line: Callable[[str], bool] | None = None,
    running_tasks: RunningTasks | None = None,
    on_thread_known: Callable[[ResumeToken, anyio.Event], Awaitable[None]]
    | None = None,
    on_resume_failed: Callable[[ResumeToken], Awaitable[None]] | None = None,
    progress_ref: MessageRef | None = None,
    clock: Callable[[], float] = time.monotonic,
) -> None:
    logger.info(
        "handle.incoming",
        channel_id=incoming.channel_id,
        user_msg_id=incoming.message_id,
        resume=resume_token.value if resume_token else None,
        text=incoming.text,
    )
    started_at = clock()
    is_resume_line = runner.is_resume_line
    resume_strip = strip_resume_line or is_resume_line
    runner_text = _strip_resume_lines(incoming.text, is_resume_line=resume_strip)
    runner_text = _apply_preamble(runner_text)

    progress_tracker = ProgressTracker(engine=runner.engine)

    # Resolve effective presenter: check for per-chat verbose override
    effective_presenter = _resolve_presenter(cfg.presenter, incoming.channel_id)

    user_ref = MessageRef(
        channel_id=incoming.channel_id,
        message_id=incoming.message_id,
    )
    progress_state = await send_initial_progress(
        cfg,
        channel_id=incoming.channel_id,
        reply_to=user_ref,
        label="starting",
        tracker=progress_tracker,
        progress_ref=progress_ref,
        resume_formatter=runner.format_resume,
        context_line=context_line,
        thread_id=incoming.thread_id,
    )
    progress_ref = progress_state.ref

    edits = ProgressEdits(
        transport=cfg.transport,
        presenter=effective_presenter,
        channel_id=incoming.channel_id,
        progress_ref=progress_ref,
        tracker=progress_tracker,
        started_at=started_at,
        clock=clock,
        last_rendered=progress_state.last_rendered,
        resume_formatter=runner.format_resume,
        context_line=context_line,
        thread_id=incoming.thread_id,
        min_render_interval=cfg.min_render_interval,
    )

    # Apply watchdog settings to runner and edits
    watchdog = _load_watchdog_settings()
    if watchdog is not None:
        edits._stall_repeat_seconds = watchdog.stall_repeat_seconds
        if hasattr(runner, "_LIVENESS_TIMEOUT_SECONDS"):
            runner._LIVENESS_TIMEOUT_SECONDS = watchdog.liveness_timeout
        if hasattr(runner, "_stall_auto_kill"):
            runner._stall_auto_kill = watchdog.stall_auto_kill

    running_task: RunningTask | None = None
    if running_tasks is not None and progress_ref is not None:
        running_task = RunningTask(context=context)
        running_tasks[progress_ref] = running_task

    cancel_exc_type = anyio.get_cancelled_exc_class()
    edits_scope = anyio.CancelScope()

    async def run_edits() -> None:
        try:
            with edits_scope:
                await edits.run()
        except cancel_exc_type:
            # Edits are best-effort; cancellation should not bubble into the task group.
            return

    outcome = RunOutcome()
    error: Exception | None = None

    async with anyio.create_task_group() as tg:
        if progress_ref is not None:
            tg.start_soon(run_edits)

        try:
            outcome = await run_runner_with_cancel(
                runner,
                prompt=runner_text,
                resume_token=resume_token,
                edits=edits,
                running_task=running_task,
                on_thread_known=on_thread_known,
                channel_id=incoming.channel_id,
            )
        except Exception as exc:
            error = exc
            logger.exception(
                "handle.runner_failed",
                error=str(exc),
                error_type=exc.__class__.__name__,
            )
        finally:
            if running_task is not None and running_tasks is not None:
                running_task.done.set()
                if progress_ref is not None:
                    running_tasks.pop(progress_ref, None)
            if not outcome.cancelled and error is None:
                # Give pending progress edits a chance to flush if they're ready.
                await anyio.sleep(0)
            # Clean up any remaining ephemeral notification messages.
            await edits.delete_ephemeral()
            edits_scope.cancel()

    elapsed = clock() - started_at

    if error is not None:
        sync_resume_token(progress_tracker, outcome.resume)
        err_body = _format_error(error)
        hint = _get_error_hint(err_body)
        if hint:
            err_body = f"{err_body}\n\n\N{ELECTRIC LIGHT BULB} {hint}"
        state = progress_tracker.snapshot(
            resume_formatter=runner.format_resume,
            context_line=context_line,
            meta_formatter=format_meta_line,
        )
        final_rendered = effective_presenter.render_final(
            state,
            elapsed_s=elapsed,
            status="error",
            answer=err_body,
        )

        # Append usage footer for Claude Code engine runs (even on error)
        if runner.engine == "claude":
            footer_cfg = _load_footer_settings()
            from .runners.run_options import get_run_options

            _err_run_opts = get_run_options()
            _show_sub = footer_cfg.show_subscription_usage
            if _err_run_opts and _err_run_opts.show_subscription_usage is not None:
                _show_sub = _err_run_opts.show_subscription_usage
            final_rendered = await _maybe_append_usage_footer(
                final_rendered, always_show=_show_sub
            )

        logger.debug(
            "handle.error.rendered",
            error=err_body,
            rendered=final_rendered.text,
        )
        await send_result_message(
            cfg,
            channel_id=incoming.channel_id,
            reply_to=user_ref,
            progress_ref=progress_ref,
            message=final_rendered,
            notify=False,
            edit_ref=progress_ref,
            replace_ref=progress_ref,
            delete_tag="error",
            thread_id=incoming.thread_id,
        )
        return

    if outcome.cancelled:
        resume = sync_resume_token(progress_tracker, outcome.resume)
        logger.info(
            "handle.cancelled",
            resume=resume.value if resume else None,
            elapsed_s=elapsed,
        )
        state = progress_tracker.snapshot(
            resume_formatter=runner.format_resume,
            context_line=context_line,
            meta_formatter=format_meta_line,
        )
        final_rendered = effective_presenter.render_progress(
            state,
            elapsed_s=elapsed,
            label="`cancelled`",
        )
        await send_result_message(
            cfg,
            channel_id=incoming.channel_id,
            reply_to=user_ref,
            progress_ref=progress_ref,
            message=final_rendered,
            notify=False,
            edit_ref=progress_ref,
            replace_ref=progress_ref,
            delete_tag="cancel",
            thread_id=incoming.thread_id,
        )
        return

    if outcome.completed is None:
        raise RuntimeError("runner finished without a completed event")

    completed = outcome.completed
    run_ok = completed.ok
    run_error = completed.error

    final_answer = completed.answer

    # If there's a plan outline stored in a synthetic warning action,
    # prepend it to the final answer so the user can read it.
    # (The progress message that showed the outline gets replaced by
    # the final message, so the outline would otherwise be lost.)
    _outline_prefix = "Plan outline:\n"
    for _action_state in progress_tracker.snapshot(
        resume_formatter=runner.format_resume,
        context_line=None,
    ).actions:
        _title = _action_state.action.title or ""
        if _action_state.action.kind == "warning" and _title.startswith(
            _outline_prefix
        ):
            _outline_body = _title[len(_outline_prefix) :]
            if _outline_body.strip():
                final_answer = f"{_outline_body}\n\n{final_answer}"
            break

    # Auto-clear broken session: if a resumed run failed with 0 turns,
    # clear the saved session so the next message starts fresh.
    if run_ok is False and resume_token is not None and on_resume_failed is not None:
        _num_turns = 0
        if completed.usage:
            _num_turns = completed.usage.get("num_turns", 0) or 0
        if _num_turns == 0:
            try:
                await on_resume_failed(resume_token)
                logger.info(
                    "session.auto_cleared",
                    engine=resume_token.engine,
                    resume=resume_token.value,
                )
            except Exception:  # noqa: BLE001
                logger.debug("session.auto_clear_failed", exc_info=True)

    if run_ok is False and run_error:
        error_text = str(run_error)
        hint = _get_error_hint(error_text)
        if hint:
            error_text = f"{error_text}\n\n\N{ELECTRIC LIGHT BULB} {hint}"
        if final_answer.strip():
            # Deduplicate: if the answer already starts with the error's first
            # line (common when runner sets both answer and error from the same
            # source, e.g. Claude Code subscription limits), only append the
            # diagnostic context and hint — not the repeated summary.
            error_head = error_text.split("\n", 1)[0].strip()
            answer_head = final_answer.strip().split("\n", 1)[0].strip()
            if error_head and error_head == answer_head:
                _, _, remainder = error_text.partition("\n")
                if remainder.strip():
                    final_answer = f"{final_answer}\n\n{remainder.strip()}"
            else:
                final_answer = f"{final_answer}\n\n{error_text}"
        else:
            final_answer = error_text

    status = (
        "error" if run_ok is False else ("done" if final_answer.strip() else "error")
    )
    resume_value = None
    resume_token = completed.resume or outcome.resume
    if resume_token is not None:
        resume_value = resume_token.value
    usage_log: dict[str, object] = {}
    if completed.usage:
        for key in ("num_turns", "total_cost_usd", "duration_api_ms"):
            val = completed.usage.get(key)
            if val is not None:
                usage_log[key] = val
    logger.info(
        "runner.completed",
        ok=run_ok,
        error=run_error,
        answer_len=len(final_answer or ""),
        elapsed_s=round(elapsed, 2),
        action_count=progress_tracker.action_count,
        resume=resume_value,
        **usage_log,
    )
    # Record session stats for /stats command
    from .session_stats import record_run as _record_stats_run

    _record_stats_run(
        engine=runner.engine,
        actions=progress_tracker.action_count,
        duration_ms=int(elapsed * 1000),
    )
    sync_resume_token(progress_tracker, completed.resume or outcome.resume)

    # Post-outline guidance: if the session was outline-pending (user clicked
    # "Pause & Outline Plan" but Claude Code ended the run instead of calling
    # ExitPlanMode), append resume instructions so the user knows how to proceed.
    if runner.engine == "claude" and resume_value:
        from .runners.claude import _OUTLINE_PENDING

        if resume_value in _OUTLINE_PENDING and final_answer and final_answer.strip():
            final_answer += (
                "\n\n---\n"
                "Plan outline complete. Resume and say "
                '"approved" to proceed, or send feedback to revise.'
            )

    state = progress_tracker.snapshot(
        resume_formatter=runner.format_resume,
        context_line=context_line,
        meta_formatter=format_meta_line,
    )
    final_rendered = effective_presenter.render_final(
        state,
        elapsed_s=elapsed,
        status=status,
        answer=final_answer,
    )

    # Load footer display config (global defaults + per-chat overrides)
    footer_cfg = _load_footer_settings()
    from .runners.run_options import get_run_options

    _footer_run_opts = get_run_options()

    # Append run cost footer (from CompletedEvent.usage)
    _show_cost = footer_cfg.show_api_cost
    if _footer_run_opts and _footer_run_opts.show_api_cost is not None:
        _show_cost = _footer_run_opts.show_api_cost
    if _show_cost:
        cost_line = _format_run_cost(completed.usage)
        if cost_line:
            final_rendered = RenderedMessage(
                text=final_rendered.text + f"\n\U0001f4b0 {cost_line}",
                extra=final_rendered.extra,
            )

    # A4: Cost budget tracking and alerts (always, regardless of footer config)
    _cost_alert_text = _check_cost_budget(completed.usage)
    if _cost_alert_text:
        final_rendered = RenderedMessage(
            text=final_rendered.text + f"\n{_cost_alert_text}",
            extra=final_rendered.extra,
        )

    # Append usage footer for Claude Code engine runs
    if runner.engine == "claude":
        _show_sub = footer_cfg.show_subscription_usage
        if _footer_run_opts and _footer_run_opts.show_subscription_usage is not None:
            _show_sub = _footer_run_opts.show_subscription_usage
        final_rendered = await _maybe_append_usage_footer(
            final_rendered, always_show=_show_sub
        )

    logger.debug(
        "handle.final.rendered",
        rendered=final_rendered.text,
        status=status,
    )

    can_edit_final = progress_ref is not None
    edit_ref = None if cfg.final_notify or not can_edit_final else progress_ref

    await send_result_message(
        cfg,
        channel_id=incoming.channel_id,
        reply_to=user_ref,
        progress_ref=progress_ref,
        message=final_rendered,
        notify=cfg.final_notify,
        edit_ref=edit_ref,
        replace_ref=progress_ref,
        delete_tag="final",
        thread_id=incoming.thread_id,
    )
