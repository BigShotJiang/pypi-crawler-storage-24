import os
import shutil

from nerdcore.base_entities.command_class import Command
from nerdcore.defs import COMMANDS_PATH, DEPLOYMENTS_PATH
from nerdcore.errors import NerdUserError
from nerdcore.ncdefs import NC_EXAMPLE_COMMAND_PATH, NC_EXAMPLE_DEPLOYMENT_PATH


class Make(Command):
    help_text = "Scaffold a new command or deployment from a template"
    category = "utility"

    # Specify args that are required (must be initialized as None)
    required_arg_keys = ['entity_type', 'entity_name']

    # Specify unnamed args (passed without --name) (define in passing order)
    unnamed_arg_keys = ['entity_type', 'entity_name']

    # Define and set defaults for all args (incl required)
    # Setting type-hints will provide validation in CliRunnable base class.
    entity_type: str = None
    entity_name: str = None

    ENTITY_TYPE_INFO = {
        'command': (COMMANDS_PATH, NC_EXAMPLE_COMMAND_PATH, 'ExampleCommand'),
        'deployment': (DEPLOYMENTS_PATH, NC_EXAMPLE_DEPLOYMENT_PATH, 'ExampleDeployment'),
    }

    def run(self):

        if not self.entity_name.replace('-', '').isalpha():
            raise NerdUserError(f"Invalid name: {self.entity_name}. Please specify in kebab-case (e.g. entity-name).")

        # Get info based on the entity type
        entity_path, example_path, example_name = self.ENTITY_TYPE_INFO.get(self.entity_type)

        new_entity_path = os.path.join(entity_path, f'{self.entity_name}.py')
        shutil.copy(example_path, new_entity_path)

        with open(new_entity_path, 'r') as f:
            file_contents = f.read()

        file_contents = file_contents.replace(example_name, self.entity_name.title().replace('-', ''))

        with open(new_entity_path, 'w') as f:
            f.write(file_contents)

        from nerdcore.utils.nerd.theme_functions import print_t
        print_t(f"Created {self.entity_type}: {new_entity_path}", 'done')

        # Auto-regenerate shell completions if the completions/ directory exists
        from nerdcore.defs import ROOT_PATH
        completions_dir = os.path.join(ROOT_PATH, 'completions')
        if os.path.isdir(completions_dir):
            try:
                from commands.completion import Completion
                import argparse
                for shell_flag in ['zsh', 'bash']:
                    gen = Completion(argparse.Namespace(), {f'--{shell_flag}': True, '--install': True}, [])
                    gen.run()
                print_t("Shell completions regenerated.", 'info')
            except Exception:
                print_t("Could not auto-regenerate completions. Run: nerd completion --zsh --install", 'warning')
