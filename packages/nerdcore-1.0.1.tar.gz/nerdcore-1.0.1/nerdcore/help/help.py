import ast
import importlib.util
import os
import sys
from typing import Dict, List, Tuple

from nerdcore.defs import COMMANDS_PATH, DEPLOYMENTS_PATH
from nerdcore.ncdefs import NC_COMMANDS_PATH
from nerdcore.utils.nerd.theme_functions import print_banner, print_table, apply_t


# Category display order
CATEGORY_ORDER = ['deploy', 'testing', 'aws', 'server-ops', 'utility', 'general']

CATEGORY_LABELS = {
    'deploy': 'Deploy',
    'testing': 'Testing',
    'aws': 'AWS',
    'server-ops': 'Server Ops',
    'utility': 'Utility',
    'general': 'General',
}


def _extract_metadata_from_file(filepath: str) -> Tuple[str, str, str]:
    """
    Use ast.parse() to extract help_text, category, and entity_type from a Python file
    without importing it. Returns (help_text, category, entity_type).
    """
    help_text = ""
    category = "general"
    entity_type = "command"

    try:
        with open(filepath, 'r') as f:
            tree = ast.parse(f.read(), filename=filepath)
    except (SyntaxError, OSError):
        return help_text, category, entity_type

    for node in tree.body:
        if isinstance(node, ast.ClassDef):
            # Detect entity type from base classes
            for base in node.bases:
                base_name = base.attr if isinstance(base, ast.Attribute) else getattr(base, 'id', '')
                if base_name == 'Deployment':
                    entity_type = 'deployment'

            # Extract class-level assignments
            for item in node.body:
                if isinstance(item, (ast.Assign, ast.AnnAssign)):
                    # Handle ast.Assign: help_text = "..."
                    if isinstance(item, ast.Assign) and len(item.targets) == 1:
                        target = item.targets[0]
                        if isinstance(target, ast.Name) and isinstance(item.value, ast.Constant):
                            if target.id == 'help_text':
                                help_text = item.value.value
                            elif target.id == 'category':
                                category = item.value.value
                    # Handle ast.AnnAssign: help_text: str = "..."
                    elif isinstance(item, ast.AnnAssign) and item.target:
                        if isinstance(item.target, ast.Name) and item.value and isinstance(item.value, ast.Constant):
                            if item.target.id == 'help_text':
                                help_text = item.value.value
                            elif item.target.id == 'category':
                                category = item.value.value
            break  # Only process the first class

    return help_text, category, entity_type


def _scan_entity_dirs(include_nerdcore=True) -> Dict[str, List[Tuple[str, str, str]]]:
    """
    Scan entity directories and return commands grouped by category.
    Each entry is (entity_name, help_text, entity_type).
    """
    categories: Dict[str, List[Tuple[str, str, str]]] = {}

    dirs_to_scan = [
        (COMMANDS_PATH, 'command'),
        (DEPLOYMENTS_PATH, 'deployment'),
    ]
    if include_nerdcore:
        dirs_to_scan.append((NC_COMMANDS_PATH, 'command'))

    for dir_path, default_type in dirs_to_scan:
        if not os.path.isdir(dir_path):
            continue
        for filename in sorted(os.listdir(dir_path)):
            if filename.startswith(('.', '_')):
                continue
            filepath = os.path.join(dir_path, filename)
            if not os.path.isfile(filepath):
                continue

            name, ext = os.path.splitext(filename)

            if ext == '.py':
                help_text, category, entity_type = _extract_metadata_from_file(filepath)
            elif ext == '.sh':
                help_text = ""
                category = "utility"
                entity_type = "command"
            else:
                continue

            if category not in categories:
                categories[category] = []
            categories[category].append((name, help_text, entity_type))

    return categories


def run_default_help(nerd_args=None):
    """Dynamic, categorized help page."""
    print_banner()

    print(f"  {apply_t('Welcome to Nerd CLI.', 'white')} Run {apply_t('nerd help <command>', 'light_cyan')} for detailed help on any command.")
    print()

    # Usage section
    usage_table = {
        "headers": ["Command", "Description", ""],
        "show_headers": False,
        "rows": [
            ["nerd <command>", "Run a command", ""],
            ["nerd -d <deployment>", "Run a deployment", ""],
            ["nerd help <command>", "Detailed help for a command", ""],
            ["nerd list", "List all commands", "--all"],
            ["nerd -v", "Print version", ""],
            ["nerd -e <entity>", "Open entity in vim", ""],
        ]
    }
    print_table(usage_table, apply_t("Usage", 'special'), min_col_width=[25, 30, 8])

    # Dynamic command listing by category
    categories = _scan_entity_dirs(include_nerdcore=False)

    for cat_key in CATEGORY_ORDER:
        entries = categories.get(cat_key, [])
        if not entries:
            continue

        label = CATEGORY_LABELS.get(cat_key, cat_key.title())
        rows = []
        for name, help_text, entity_type in entries:
            prefix = "nerd -d " if entity_type == 'deployment' else "nerd "
            rows.append([f"{prefix}{name}", help_text or ""])

        table = {
            "headers": ["Command", "Description"],
            "show_headers": False,
            "rows": rows,
        }
        print_table(table, apply_t(label, 'special'), min_col_width=[25, 40])

    print(f"  {apply_t('Run', 'dark_grey')} {apply_t('nerd list --all', 'light_cyan')} {apply_t('to include nerdcore built-in commands.', 'dark_grey')}")
    sys.exit(0)


def run_entity_help(entity_path: str):
    """Per-command help: show detailed info by importing the entity module."""
    entity_name = os.path.splitext(os.path.basename(entity_path))[0]
    _, ext = os.path.splitext(entity_path)

    if ext == '.sh':
        print()
        print(f"  {apply_t(entity_name, 'light_yellow')}  {apply_t('(shell script)', 'dark_grey')}")
        print(f"  Run with: {apply_t(f'nerd {entity_name}', 'light_cyan')}")
        print()
        return

    # Extract metadata via ast first (fast, no imports)
    help_text, category, entity_type = _extract_metadata_from_file(entity_path)

    # Import the module to get runtime class info (args, type hints)
    entity_class = None
    try:
        class_name = ''.join(word.capitalize() for word in entity_name.split('-'))
        spec = importlib.util.spec_from_file_location(class_name, entity_path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        entity_class = getattr(module, class_name, None)
    except Exception:
        pass

    # Header
    print()
    type_label = 'deployment' if entity_type == 'deployment' else 'command'
    cat_label = CATEGORY_LABELS.get(category, category.title())
    print(f"  {apply_t(entity_name, 'light_yellow')}  {apply_t(f'({type_label}, {cat_label})', 'dark_grey')}")

    if help_text:
        print(f"  {apply_t(help_text, 'white')}")
    print()

    if entity_class is None:
        return

    # Usage line
    prefix = "nerd -d " if entity_type == 'deployment' else "nerd "
    usage_parts = [f"{prefix}{entity_name}"]

    unnamed_keys = getattr(entity_class, 'unnamed_arg_keys', [])
    named_keys = getattr(entity_class, 'named_arg_keys', [])
    required_keys = set(getattr(entity_class, 'required_arg_keys', []))

    for key in unnamed_keys:
        if key in required_keys:
            usage_parts.append(f"<{key}>")
        else:
            usage_parts.append(f"[{key}]")

    # Named args that aren't also unnamed (avoid duplicates like 'dirs')
    named_only = [k for k in named_keys if k not in unnamed_keys]
    for key in named_only:
        if key == 'config':
            continue  # inherited from Deployment base, not user-facing
        if key in required_keys:
            usage_parts.append(f"--{key}=<value>")
        else:
            usage_parts.append(f"[--{key}=<value>]")

    print(f"  {apply_t('Usage:', 'light_cyan')}  {apply_t(' '.join(usage_parts), 'green')}")
    print()

    # Arguments table
    from typing import get_type_hints
    try:
        hints = get_type_hints(entity_class)
    except Exception:
        hints = {}

    all_arg_keys = list(dict.fromkeys(unnamed_keys + named_keys))  # preserve order, dedup
    if all_arg_keys:
        rows = []
        for key in all_arg_keys:
            if key == 'config' and entity_type == 'deployment':
                continue
            # Determine how it's passed
            is_unnamed = key in unnamed_keys
            is_named = key in named_keys
            is_required = key in required_keys

            if is_unnamed and is_named:
                pass_style = f"<{key}> or --{key}"
            elif is_unnamed:
                pass_style = f"<{key}>"
            else:
                pass_style = f"--{key}"

            # Type and default
            hint = hints.get(key)
            type_str = ""
            if hint:
                origin = getattr(hint, '__origin__', None)
                if origin:
                    args = getattr(hint, '__args__', ())
                    type_str = ' | '.join(a.__name__ for a in args if a is not type(None))
                else:
                    type_str = hint.__name__ if hasattr(hint, '__name__') else str(hint)

            default = getattr(entity_class, key, None)
            default_str = "" if default is None else f"default: {default}"

            req_str = "required" if is_required else default_str
            info = f"{type_str}  {req_str}".strip() if type_str else req_str

            rows.append([pass_style, info])

        table = {
            "headers": ["Argument", "Info"],
            "show_headers": True,
            "header_color": "magenta",
            "rows": rows,
        }
        print_table(table, apply_t("Arguments", 'special'), min_col_width=[25, 30])

    # Docstring (if present)
    if entity_class.__doc__:
        doc = entity_class.__doc__.strip()
        if doc:
            print(f"  {apply_t('Details:', 'light_cyan')}")
            for line in doc.split('\n'):
                print(f"    {apply_t(line.strip(), 'dark_grey')}")
            print()
