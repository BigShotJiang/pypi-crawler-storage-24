"""
Sync orchestrator for syncing leads to FXiaoke CRM.
Accepts leads directly (no external fetching).
"""

import logging
from dataclasses import dataclass
from typing import List, Dict, Any, Optional
from datetime import datetime

from .crm import CRMClient, CreateClientResult

logger = logging.getLogger('sync')


@dataclass
class SyncStats:
    """Statistics from a sync operation."""
    total_leads: int = 0
    created: int = 0
    duplicates: int = 0
    failures: int = 0
    duration_seconds: float = 0.0

    def summary(self) -> str:
        """Generate summary string."""
        return (
            f"Total: {self.total_leads}, "
            f"Created: {self.created}, "
            f"Duplicates: {self.duplicates}, "
            f"Failures: {self.failures}"
        )


@dataclass
class SyncLeadResult:
    """Result of syncing a single lead."""
    lead_id: str
    company_name: str
    email: str
    success: bool
    is_duplicate: bool = False
    crm_client_id: Optional[str] = None
    error: Optional[str] = None
    warning: Optional[str] = None


class SyncOrchestrator:
    """Orchestrates syncing leads to CRM."""

    def __init__(self, crm_client: CRMClient):
        """
        Initialize sync orchestrator.

        Args:
            crm_client: CRM client instance
        """
        self.crm_client = crm_client

    def sync_leads(
        self,
        leads: List[Dict[str, Any]],
        dry_run: bool = False,
        progress_callback=None
    ) -> SyncStats:
        """
        Sync leads to CRM.

        Args:
            leads: List of lead dictionaries with fields:
                - company: Company name (required)
                - email: Email address (optional)
                - phone: Phone number (optional)
                - country: Country code (optional)
                - source_id: External reference ID (optional)
            dry_run: If True, don't actually create clients in CRM
            progress_callback: Optional callback for progress updates

        Returns:
            SyncStats with operation statistics
        """
        start_time = datetime.now()
        stats = SyncStats()

        logger.info(f"Starting sync: total_leads={len(leads)}, dry_run={dry_run}")

        stats.total_leads = len(leads)

        if not leads:
            logger.info("No leads to sync")
            stats.duration_seconds = (datetime.now() - start_time).total_seconds()
            return stats

        # Sync each lead to CRM
        for i, lead in enumerate(leads, 1):
            if dry_run:
                result = self._simulate_sync(lead)
                logger.info(f"[{i}/{stats.total_leads}] {result.company_name} (dry run)")
            else:
                result = self._sync_single_lead(lead)

                if result.success:
                    stats.created += 1
                    logger.info(
                        f"[{i}/{stats.total_leads}] {result.company_name} → "
                        f"Created (CRM ID: {result.crm_client_id})"
                    )
                elif result.is_duplicate:
                    stats.duplicates += 1
                    if result.warning:
                        logger.info(
                            f"[{i}/{stats.total_leads}] {result.company_name} → "
                            f"Duplicate: {result.warning}"
                        )
                    else:
                        logger.info(
                            f"[{i}/{stats.total_leads}] {result.company_name} → "
                            f"Duplicate skipped"
                        )
                else:
                    stats.failures += 1
                    logger.warning(
                        f"[{i}/{stats.total_leads}] {result.company_name} → "
                        f"Failed: {result.error}"
                    )

            if progress_callback:
                progress_callback(i, stats.total_leads, result)

        stats.duration_seconds = (datetime.now() - start_time).total_seconds()
        logger.info(f"Sync complete in {stats.duration_seconds:.1f}s: {stats.summary()}")

        return stats

    def _sync_single_lead(self, lead: Dict[str, Any]) -> SyncLeadResult:
        """Sync a single lead to CRM."""
        company_name = lead.get('company', 'Unknown Company')
        email = lead.get('email', '')

        # Map to internal format expected by CRM
        crm_lead_data = {
            'id': lead.get('source_id', ''),
            'company_name': company_name,
            'email': email,
            'phone_number': lead.get('phone', ''),
            'country': lead.get('country', ''),
        }

        result = self.crm_client.create_client(crm_lead_data)

        return SyncLeadResult(
            lead_id=lead.get('source_id', ''),
            company_name=company_name,
            email=email,
            success=result.success,
            is_duplicate=result.is_duplicate,
            crm_client_id=result.crm_client_id,
            error=result.error,
            warning=result.warning
        )

    def _simulate_sync(self, lead: Dict[str, Any]) -> SyncLeadResult:
        """Simulate syncing a lead (dry run mode)."""
        return SyncLeadResult(
            lead_id=lead.get('source_id', ''),
            company_name=lead.get('company', 'Unknown'),
            email=lead.get('email', ''),
            success=True
        )