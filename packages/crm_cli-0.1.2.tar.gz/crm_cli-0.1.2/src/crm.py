"""
FXiaoke CRM (纷享销客) API client.
Provides methods for creating/updating clients from leads.
"""

import logging
import time
from datetime import datetime
from typing import Dict, Any, Optional, List
from dataclasses import dataclass

import requests

from .fxiaoke_auth import TokenManager

logger = logging.getLogger('crm_client')

# Field mappings from reference docs (name-field-map.md, reference-data-example.md)
# Field API names discovered via Object Describe API - see docs/field-mappings.md
FIELD_MAP = {
    "follow_status": "field_7dDlL__c",       # Not field_h5Ezh__c
    "follow_status_s1": "7e8T541Vr",          # Not "S1-待跟进:b1LR27thA"
    "phone": "field_S737R__c",                # Not field_50Fqg__c
    "s1_timestamp": "field_aw71X__c",         # Not field_lskUm__c
    "record_type": "default__c",              # Not "603dabc14ae65400011aec90"
    "object_api": "LeadsObj",                 # Changed from AccountObj - leads go to lead pool
    "region_europe": "1dKGudtaC",
    "region_asia": "5yF9DohVi",
    "country_china": "kaYz89Lwq",
    "source_company": "2",                    # 公司投放
    "secondary_source_facebook": "6A7SBTmqi", # Facebook
    # New fields discovered Mar 2025 - see docs/field-mappings.md
    "primary_industry": "field_e2eon__c",      # 一级行业
    "secondary_industry": "field_e1Gqm__c",    # 二级行业
    "website": "field_xmuU5__c",                # 公司网址
    "company_linkedin": "field_Z4Ieq__c",       # LinkedIn profile
    "lead_type": "TBD",                         # 客户类型 - NOT FOUND, placeholder for future
}

# CRM API endpoint
CREATE_ENDPOINT = "https://open.fxiaoke.com/cgi/crm/v2/data/create"


@dataclass
class CreateClientResult:
    """Result of creating a client in CRM."""
    success: bool
    crm_client_id: Optional[str] = None
    is_duplicate: bool = False
    warning: Optional[str] = None  # Non-fatal warnings
    error: Optional[str] = None
    error_code: Optional[int] = None


class CRMClient:
    """FXiaoke CRM API client with TokenManager."""

    def __init__(
        self,
        token_manager: TokenManager,
        owner_fsuid: Optional[str] = None,
        pool_id: Optional[str] = None
    ):
        """
        Initialize CRM client.

        Args:
            token_manager: TokenManager instance for authentication
            owner_fsuid: Optional FSUID of the owner to assign to created leads.
                        If None, uses the current user (from token).
                        Example: "FSUID_C3F0FA243B2B385385D570C8968C8AB3" for 瞿吉笑 (欧洲区)
            pool_id: Optional lead pool ID override.
                    If None, pool is determined by country routing.
                    Example: "643d87b17be47e0a000190a715" for Europe pool
        """
        self.token_manager = token_manager
        self.session = token_manager.session  # Reuse session
        self.owner_fsuid = owner_fsuid  # Optional owner override
        self.pool_id = pool_id  # Optional pool override

    def create_client(
        self,
        lead_data: Dict[str, Any],
        allow_update: bool = False
    ) -> CreateClientResult:
        """
        Create a lead in CRM from Facebook lead data.

        Creates LeadsObj (线索) which goes to the lead pool (e.g., 欧洲线索公海池).

        Args:
            lead_data: Facebook lead data with fields:
                - full_name or company_name: Company name
                - email: Email address
                - phone_number: Phone number
                - country: Country code
                - created_time: Lead creation timestamp
                - id: Facebook lead ID
            allow_update: If True, update existing client on duplicate
                         If False, only warn (default)

        Returns:
            CreateClientResult with success status
        """
        # Build payload
        payload = self._build_create_payload(lead_data)

        try:
            response = self.session.post(
                CREATE_ENDPOINT,
                json=payload,
                timeout=30
            )
            return self._parse_response(response, lead_data, allow_update)

        except requests.exceptions.Timeout:
            logger.warning(f"Timeout creating client for lead {lead_data.get('id')}")
            return CreateClientResult(
                success=False,
                error="Request timeout",
                error_code=408
            )
        except requests.exceptions.RequestException as e:
            logger.error(f"Error creating client: {e}")
            return CreateClientResult(
                success=False,
                error=str(e),
                error_code=500
            )

    def _build_create_payload(self, lead_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Build the CRM create client payload.

        Args:
            lead_data: Facebook lead data

        Returns:
            CRM API payload dictionary
        """
        auth = self.token_manager.get_auth_headers()
        if not auth:
            raise ValueError("Authentication failed - no valid token")

        # Extract and map fields
        company_name = self._extract_company_name(lead_data)
        email = lead_data.get('email', '')
        phone = lead_data.get('phone_number', '')
        created_time = self._parse_created_time(lead_data.get('created_time'))
        country = lead_data.get('country', '')

        # Build payload according to CRM API spec
        payload = {
            **auth,
            "hasSpecifyTime": True,
            "hasSpecifyCreatedBy": False,
            "triggerApprovalFlow": False,
            "triggerWorkFlow": False,
            "data": {
                "object_data": {
                    "dataObjectApiName": FIELD_MAP["object_api"],
                    "name": company_name,
                    "record_type": FIELD_MAP["record_type"],
                    FIELD_MAP["follow_status"]: FIELD_MAP["follow_status_s1"],  # S1
                    # Required for LeadsObj
                    "object_describe_api_name": "LeadsObj",
                    "biz_status": "un_assigned",
                    "life_status": "normal",
                    # Lead pool assignment (use override or route by country)
                    "leads_pool_id": self._get_leads_pool_id(country),
                    # Owner assignment (if configured)
                    **({"owner": [self.owner_fsuid]} if self.owner_fsuid else {}),
                },
                "optionInfo": {
                    "skipFuncValidate": False,
                    "useValidationRule": True,
                    "isDuplicateSearch": True  # Enable duplicate detection
                }
            }
        }

        # Add optional fields if present
        object_data = payload["data"]["object_data"]

        if email:
            object_data["email"] = email

        if phone:
            object_data[FIELD_MAP["phone"]] = self._clean_phone(phone)

        if created_time:
            object_data[FIELD_MAP["s1_timestamp"]] = created_time

        # Add company name field
        if lead_data.get('company_name'):
            object_data["field_veV5x__c"] = lead_data.get('company_name')

        # Add country/region if available
        if country:
            # Map country to region field (field_g60ab__c)
            region_value = self._get_region_for_country(country)
            if region_value:
                object_data["field_g60ab__c"] = region_value

        # Add remark for lead pool routing
        object_data["remark"] = "This should be updated according to the lead generation country"

        return payload

    def _get_leads_pool_id(self, country: str) -> str:
        """
        Get the lead pool ID based on country or override.

        Pool IDs from CRM documentation:
        - 643d87b17be47e0a000190a715:【欧洲】线索公海池 (Europe)
        - 643d87cda34e0a0001336093:【亚洲】线索公海池 (Asia)
        - 6464a6451a3c2c0001c12369: 日本线索池 (Japan)

        Args:
            country: Country code (e.g., 'GB', 'DE', 'US', 'CN')

        Returns:
            Lead pool ID string
        """
        # Use override if provided
        if self.pool_id:
            return self.pool_id

        # Europe countries → 欧洲线索公海池
        europe_countries = ['GB', 'DE', 'FR', 'IT', 'ES', 'NL', 'SE', 'NO', 'DK',
                           'FI', 'PL', 'AT', 'BE', 'CH', 'PT', 'GR', 'CZ', 'HU',
                           'RO', 'BG', 'HR', 'SK', 'SI', 'LT', 'LV', 'EE', 'IE',
                           'LU', 'MT', 'CY']

        # Asia countries → 亚洲线索公海池
        asia_countries = ['CN', 'JP', 'KR', 'TH', 'VN', 'PH', 'MY', 'SG', 'ID',
                         'IN', 'PK', 'BD', 'LK']

        country_upper = country.upper() if country else ''

        if country_upper in europe_countries:
            return "643d87b17be47e0a000190a715"  # 【欧洲】线索公海池 (CORRECT!)
        elif country_upper in asia_countries:
            return "643d87cda34e0a0001336093"  # 【亚洲】线索公海池
        else:
            # Default to Europe for unknown countries
            return "643d87b17be47e0a000190a715"  # 【欧洲】线索公海池

    def _get_region_for_country(self, country: str) -> Optional[str]:
        """
        Get the region field value based on country.

        Region values from CRM documentation:
        - 1dKGudtaC: 欧洲 (Europe)
        - 5yF9DohVi: 亚洲 (Asia)

        Args:
            country: Country code (e.g., 'GB', 'DE', 'US', 'CN')

        Returns:
            Region value string or None
        """
        # Europe countries
        europe_countries = ['GB', 'DE', 'FR', 'IT', 'ES', 'NL', 'SE', 'NO', 'DK',
                           'FI', 'PL', 'AT', 'BE', 'CH', 'PT', 'GR', 'CZ', 'HU',
                           'RO', 'BG', 'HR', 'SK', 'SI', 'LT', 'LV', 'EE', 'IE',
                           'LU', 'MT', 'CY']

        # Asia countries
        asia_countries = ['CN', 'JP', 'KR', 'TH', 'VN', 'PH', 'MY', 'SG', 'ID',
                         'IN', 'PK', 'BD', 'LK']

        country_upper = country.upper() if country else ''

        if country_upper in europe_countries:
            return "1dKGudtaC"  # 欧洲
        elif country_upper in asia_countries:
            return "5yF9DohVi"  # 亚洲
        return None

    def _extract_company_name(self, lead_data: Dict[str, Any]) -> str:
        """Extract company name from lead data.

        Priority: company_name > company > full_name > name
        Note: full_name is a person's name, company_name is the business.
        For B2B CRM, we prefer the company name as the record name.
        """
        # Try multiple fields in order of preference for B2B
        for field in ['company_name', 'company', 'full_name', 'name']:
            if lead_data.get(field):
                return lead_data[field]
        return "Unknown Company"

    def _clean_phone(self, phone: str) -> str:
        """Clean phone number for CRM."""
        if not phone:
            return ""
        # Remove common prefixes and special characters
        cleaned = phone.replace('+', '').replace(' ', '').replace('-', '')
        cleaned = cleaned.replace('(', '').replace(')', '')
        return cleaned

    def _parse_created_time(self, created_time: Any) -> Optional[int]:
        """
        Parse created_time to milliseconds timestamp.

        Args:
            created_time: Facebook's ISO format timestamp

        Returns:
            Milliseconds timestamp or None
        """
        if not created_time:
            return None

        try:
            if isinstance(created_time, int):
                # Already a timestamp, convert to milliseconds if seconds
                if created_time < 10000000000:  # Seconds
                    return created_time * 1000
                return created_time

            # Parse ISO string
            created_time_str = created_time.replace('Z', '+00:00')
            if '+' in created_time_str and ':' not in created_time_str[-5:]:
                created_time_str = created_time_str[:-2] + ':' + created_time_str[-2:]

            dt = datetime.fromisoformat(created_time_str)
            return int(dt.timestamp() * 1000)
        except Exception as e:
            logger.warning(f"Could not parse created_time '{created_time}': {e}")
            return None

    def _parse_response(
        self,
        response: requests.Response,
        lead_data: Dict[str, Any],
        allow_update: bool
    ) -> CreateClientResult:
        """
        Parse CRM API response with retry logic for 20016 (token expired).

        Args:
            response: HTTP response
            lead_data: Facebook lead data
            allow_update: If True, would update on duplicate (future feature)

        Returns:
            CreateClientResult
        """
        try:
            data = response.json()
        except ValueError:
            logger.error(f"Invalid JSON response: {response.text[:200]}")
            return CreateClientResult(
                success=False,
                error="Invalid JSON response",
                error_code=response.status_code
            )

        error_code = data.get('errorCode')

        # Handle token expiry (20016) - refresh and retry once
        if error_code == 20016:
            logger.info("Token expired (20016), refreshing and retrying...")
            self.token_manager.get_corp_access_token(force_refresh=True)
            # Retry once with new token
            payload = self._build_create_payload(lead_data)
            retry_response = self.session.post(CREATE_ENDPOINT, json=payload, timeout=30)
            return self._parse_response(retry_response, lead_data, allow_update)

        # Check for success (errorCode == 0)
        if response.status_code == 200 and error_code == 0:
            client_id = self._extract_client_id(data)
            logger.info(f"Created client {client_id} for lead {lead_data.get('id')}")
            return CreateClientResult(
                success=True,
                crm_client_id=client_id
            )

        # Check for duplicate
        error_msg = data.get('errorDescription') or data.get('errorMessage', '')
        if error_code and 'duplicate' in str(error_msg).lower():
            if allow_update:
                # Would need update logic here (separate endpoint)
                logger.info(f"Duplicate found for lead {lead_data.get('id')}, update requested (not implemented)")
                return CreateClientResult(
                    success=False,
                    is_duplicate=True,
                    warning="Duplicate found - update not implemented"
                )
            else:
                # Just warn, don't fail
                logger.info(f"Duplicate detected for lead {lead_data.get('id')}")
                return CreateClientResult(
                    success=False,
                    is_duplicate=True,
                    warning="Company already exists in CRM"
                )

        # Other errors
        actual_error_msg = data.get('errorDescription') or data.get('errorMessage', 'Unknown error')
        logger.error(f"Lead {lead_data.get('id')}: CRM error - {actual_error_msg}")
        return CreateClientResult(
            success=False,
            error=actual_error_msg,
            error_code=error_code
        )

    def _extract_client_id(self, data: Dict[str, Any]) -> Optional[str]:
        """Extract client ID from successful response."""
        # CRM returns dataId at root level: {"dataId": "xxx", "errorCode": 0, ...}
        if data.get('dataId'):
            return data['dataId']
        # Fallback for other response formats
        if 'data' in data and isinstance(data['data'], dict):
            return data['data'].get('_id') or data['data'].get('id')
        return data.get('_id') or data.get('id')

    def close(self):
        """Close the HTTP session (but not TokenManager's session)."""
        pass  # TokenManager manages the session lifecycle
