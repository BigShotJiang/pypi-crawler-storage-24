"""
Benchmark: DRSC vs SDID — performance under few donor units.

The core question: when is Doubly Robust Synthetic Control (DRSC) worth
using over plain SDID?

Answer in short: when N_co is small (fewer than ~10 donor units). With few
control units, SC weight estimation is underdetermined — the optimiser
concentrates weight on a handful of units and the resulting synthetic control
has high variance. DRSC's outcome model (a ridge-regularised time trend per
unit) provides an independent counterfactual prediction that absorbs the
weight misspecification bias.

This benchmark tests two scenarios:
  1. Small N_co (5-8 control units): the fragile-weights regime.
     Theory predicts DRSC should show lower bias and RMSE.
  2. Large N_co (30+ control units): the well-identified regime.
     Both methods should perform similarly — SDID weights are stable.

DGP: standard factor model
  Y_it = alpha_i + beta_t + tau * D_it + epsilon_it

alpha_i ~ N(0, 0.06)  — unit fixed effects
beta_t  = 0.003 * t   — common time trend (claims inflation)
tau     = -0.06       — true ATT
epsilon ~ N(0, 0.03)

The factor model is the natural habitat for SDID; the outcome model
(linear/quadratic trend) is misspecified relative to the true DGP only
at the unit-level curvature, so both components of double robustness are
approximately satisfied. In practice, the outcome model adds value when
weights are concentrated on very few units.

Run
---
Locally (for syntax/import check only — crashes Pi if you add many sims):
    cd /home/ralph/repos/insurance-causal-policy
    uv run python benchmarks/drsc_vs_sdid.py

On Databricks:
    Upload the project and run via the notebooks/drsc_vs_sdid.py notebook.
    The notebook does: %pip install insurance-causal-policy and runs this
    script with N_SIMS = 100 for statistically meaningful results.
"""

from __future__ import annotations

import sys
import time
import warnings

import numpy as np

warnings.filterwarnings("ignore")

BENCHMARK_START = time.time()

print("=" * 72)
print("Benchmark: DRSC vs SDID (insurance-causal-policy)")
print("=" * 72)
print()

# ---------------------------------------------------------------------------
# Import the library
# ---------------------------------------------------------------------------

try:
    from insurance_causal_policy import (
        SDIDEstimator,
        DoublyRobustSCEstimator,
        make_synthetic_panel_direct,
    )
    print("insurance-causal-policy imported OK")
    print()
except ImportError as e:
    print(f"ERROR: Could not import insurance-causal-policy: {e}")
    print("Install with: pip install insurance-causal-policy")
    sys.exit(1)


# ---------------------------------------------------------------------------
# DGP parameters
# ---------------------------------------------------------------------------

TRUE_ATT     = -0.06   # true causal effect on loss ratio
T_PRE        = 8       # pre-treatment periods
T_POST       = 4       # post-treatment periods
N_TREATED    = 5       # treated units — fixed across scenarios
NOISE_SD     = 0.03    # within-unit noise
BASE_LR      = 0.70    # base loss ratio
TREND        = 0.003   # common time trend per period

# Number of Monte Carlo simulations
# 30 is enough for a quick check; use 100+ on Databricks for stable results
N_SIMS = int(getattr(sys, "_drsc_bench_n_sims", 30))

# Inference method: jackknife is fastest for MC; bootstrap is more reliable
INFERENCE_SDID  = "jackknife"
INFERENCE_DRSC  = "jackknife"


# ---------------------------------------------------------------------------
# Helper: extract ATT and coverage from a fitted result
# ---------------------------------------------------------------------------

def _run_sdid(panel, inference, seed):
    est = SDIDEstimator(
        panel,
        outcome="loss_ratio",
        inference=inference,
        n_replicates=50,
        random_seed=seed,
    )
    r = est.fit()
    return r.att, r.se, r.ci_low <= TRUE_ATT <= r.ci_high


def _run_drsc(panel, inference, seed, ridge_alpha=1.0):
    est = DoublyRobustSCEstimator(
        panel,
        outcome="loss_ratio",
        inference=inference,
        n_replicates=50,
        ridge_alpha=ridge_alpha,
        random_seed=seed,
    )
    r = est.fit()
    return r.att, r.se, r.ci_low <= TRUE_ATT <= r.ci_high


# ---------------------------------------------------------------------------
# Monte Carlo runner
# ---------------------------------------------------------------------------

def run_scenario(label: str, n_co: int, n_sims: int) -> dict:
    """Run N_SIMS Monte Carlo replications for both estimators."""
    print(f"Scenario: {label}  (N_co={n_co}, N_tr={N_TREATED}, {n_sims} sims)")

    sdid_atts, sdid_ses, sdid_covers = [], [], []
    drsc_atts, drsc_ses, drsc_covers = [], [], []

    for sim_idx in range(n_sims):
        seed = 1000 + sim_idx

        panel = make_synthetic_panel_direct(
            n_control=n_co,
            n_treated=N_TREATED,
            t_pre=T_PRE,
            t_post=T_POST,
            true_att=TRUE_ATT,
            noise_sd=NOISE_SD,
            base_lr=BASE_LR,
            trend=TREND,
            random_seed=seed,
        )

        # SDID
        try:
            att, se, covers = _run_sdid(panel, INFERENCE_SDID, seed)
            sdid_atts.append(att)
            sdid_ses.append(se)
            sdid_covers.append(covers)
        except Exception as exc:
            pass  # skip failed replicates

        # DRSC
        try:
            att, se, covers = _run_drsc(panel, INFERENCE_DRSC, seed)
            drsc_atts.append(att)
            drsc_ses.append(se)
            drsc_covers.append(covers)
        except Exception as exc:
            pass

        if (sim_idx + 1) % 10 == 0:
            print(f"  {sim_idx + 1}/{n_sims} sims complete")

    def _summarise(atts, ses, covers, name):
        arr = np.array(atts)
        return {
            "name": name,
            "n_valid": len(arr),
            "mean_att": float(np.mean(arr)) if len(arr) > 0 else float("nan"),
            "bias": float(np.mean(arr) - TRUE_ATT) if len(arr) > 0 else float("nan"),
            "abs_bias": float(abs(np.mean(arr) - TRUE_ATT)) if len(arr) > 0 else float("nan"),
            "rmse": float(np.sqrt(np.mean((arr - TRUE_ATT) ** 2))) if len(arr) > 0 else float("nan"),
            "std": float(np.std(arr)) if len(arr) > 0 else float("nan"),
            "mean_se": float(np.mean(ses)) if len(ses) > 0 else float("nan"),
            "coverage": float(np.mean(covers)) if len(covers) > 0 else float("nan"),
        }

    sdid_stats = _summarise(sdid_atts, sdid_ses, sdid_covers, "SDID")
    drsc_stats = _summarise(drsc_atts, drsc_ses, drsc_covers, "DRSC")
    print()
    return {"label": label, "n_co": n_co, "sdid": sdid_stats, "drsc": drsc_stats}


# ---------------------------------------------------------------------------
# Run both scenarios
# ---------------------------------------------------------------------------

scenarios = [
    ("Few donors (N_co=6)", 6, N_SIMS),
    ("Many donors (N_co=40)", 40, N_SIMS),
]

results = []
for label, n_co, n_sims in scenarios:
    res = run_scenario(label, n_co, n_sims)
    results.append(res)


# ---------------------------------------------------------------------------
# Print summary tables
# ---------------------------------------------------------------------------

def _pct(x: float) -> str:
    if np.isnan(x):
        return "  n/a"
    return f"{x:>6.1%}"


def _f(x: float, fmt=".4f") -> str:
    if np.isnan(x):
        return "   n/a"
    return f"{x:>{6 + len(fmt)}}"


print()
print("=" * 72)
print("RESULTS SUMMARY")
print("=" * 72)
print(f"True ATT = {TRUE_ATT:.4f}  |  Inference: {INFERENCE_SDID}/{INFERENCE_DRSC}")
print()

for res in results:
    label   = res["label"]
    sdid    = res["sdid"]
    drsc    = res["drsc"]

    print(f"--- {label} ---")
    print()
    print(f"{'Metric':<38} {'SDID':>10} {'DRSC':>10}  {'Winner'}")
    print("-" * 68)

    # Mean ATT
    sdid_att_s = f"{sdid['mean_att']:>10.4f}"
    drsc_att_s = f"{drsc['mean_att']:>10.4f}"
    print(f"{'Mean ATT (true = ' + str(TRUE_ATT) + ')':<38} {sdid_att_s} {drsc_att_s}")

    # Absolute bias
    w_bias = "DRSC" if drsc["abs_bias"] < sdid["abs_bias"] else ("SDID" if sdid["abs_bias"] < drsc["abs_bias"] else "tie")
    print(f"{'Absolute bias':<38} {sdid['abs_bias']:>10.4f} {drsc['abs_bias']:>10.4f}  {w_bias}")

    # RMSE
    w_rmse = "DRSC" if drsc["rmse"] < sdid["rmse"] else ("SDID" if sdid["rmse"] < drsc["rmse"] else "tie")
    print(f"{'RMSE':<38} {sdid['rmse']:>10.4f} {drsc['rmse']:>10.4f}  {w_rmse}")

    # Std dev
    print(f"{'Std dev of estimates':<38} {sdid['std']:>10.4f} {drsc['std']:>10.4f}")

    # Mean SE
    print(f"{'Mean reported SE':<38} {sdid['mean_se']:>10.4f} {drsc['mean_se']:>10.4f}")

    # CI coverage
    w_cov = "DRSC" if abs(drsc["coverage"] - 0.95) < abs(sdid["coverage"] - 0.95) else "SDID"
    print(f"{'95% CI coverage':<38} {_pct(sdid['coverage']):>10} {_pct(drsc['coverage']):>10}  closest to 95%: {w_cov}")

    print(f"{'Valid replications':<38} {sdid['n_valid']:>10} {drsc['n_valid']:>10}")
    print()


# ---------------------------------------------------------------------------
# Interpretation
# ---------------------------------------------------------------------------

print("INTERPRETATION")
print("-" * 72)

few_res  = results[0]
many_res = results[1]

few_sdid_bias  = few_res["sdid"]["abs_bias"]
few_drsc_bias  = few_res["drsc"]["abs_bias"]
many_sdid_bias = many_res["sdid"]["abs_bias"]
many_drsc_bias = many_res["drsc"]["abs_bias"]

few_sdid_rmse  = few_res["sdid"]["rmse"]
few_drsc_rmse  = few_res["drsc"]["rmse"]

# Relative improvement
if few_sdid_bias > 1e-6:
    bias_improvement = (few_sdid_bias - few_drsc_bias) / few_sdid_bias * 100
else:
    bias_improvement = 0.0

if few_sdid_rmse > 1e-6:
    rmse_improvement = (few_sdid_rmse - few_drsc_rmse) / few_sdid_rmse * 100
else:
    rmse_improvement = 0.0

print()
print(f"Few donors (N_co={few_res['n_co']}):")
print(f"  SDID abs bias: {few_sdid_bias:.4f}  DRSC abs bias: {few_drsc_bias:.4f}")
if bias_improvement > 5:
    print(f"  DRSC reduces bias by {bias_improvement:.1f}% relative to SDID.")
elif bias_improvement < -5:
    print(f"  SDID has lower bias ({-bias_improvement:.1f}% better than DRSC).")
else:
    print(f"  Bias difference is small ({abs(bias_improvement):.1f}%).")

if rmse_improvement > 5:
    print(f"  DRSC reduces RMSE by {rmse_improvement:.1f}% relative to SDID.")
elif rmse_improvement < -5:
    print(f"  SDID has lower RMSE ({-rmse_improvement:.1f}% better than DRSC).")
else:
    print(f"  RMSE difference is small ({abs(rmse_improvement):.1f}%).")

print()
print(f"Many donors (N_co={many_res['n_co']}):")
print(f"  SDID abs bias: {many_sdid_bias:.4f}  DRSC abs bias: {many_drsc_bias:.4f}")
print(f"  At high N_co, weights are well-determined and the augmentation")
print(f"  term is small. Both methods should perform similarly.")

print()
print("Practical guidance:")
print("  - Use DRSC when N_co < 10 (few donor segments available).")
print("  - Use SDID when N_co >= 20 (weights are stable, augmentation adds noise).")
print("  - The 10-20 range is a judgment call; run both and compare.")
print()

elapsed = time.time() - BENCHMARK_START
print(f"Benchmark completed in {elapsed:.1f}s")
