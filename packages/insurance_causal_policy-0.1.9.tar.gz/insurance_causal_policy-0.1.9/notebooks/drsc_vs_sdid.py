# Databricks notebook source
# MAGIC %md
# MAGIC # DRSC vs SDID: Benchmark under few donor units
# MAGIC
# MAGIC **Library:** `insurance-causal-policy` — Doubly Robust Synthetic Control (DRSC)
# MAGIC vs Synthetic Difference-in-Differences (SDID)
# MAGIC
# MAGIC ## The question
# MAGIC
# MAGIC SDID builds a weighted synthetic control from donor (control) units. When
# MAGIC you have 30+ donors, the weight optimisation is well-determined and SDID works
# MAGIC well. But in insurance you often have fewer:
# MAGIC
# MAGIC - A new product with only 5 comparable territories
# MAGIC - A niche channel with 7 comparable segments
# MAGIC - A regional product where only 4 other regions exist
# MAGIC
# MAGIC With few donors, the weight optimisation is underdetermined. The optimiser
# MAGIC concentrates mass on a handful of units and the resulting synthetic control
# MAGIC has high variance. Small perturbations in pre-treatment data can flip the
# MAGIC weights substantially.
# MAGIC
# MAGIC **DRSC** (Ben-Michael, Feller & Rothstein, 2021) augments the SC estimate
# MAGIC with an outcome model fitted on control units. The bias correction term is:
# MAGIC
# MAGIC     ATT_DRSC = ATT_SC + correction
# MAGIC
# MAGIC where correction adjusts for the misfit between the SC weights and the
# MAGIC outcome model prediction. If either the weights OR the outcome model is
# MAGIC correctly specified, DRSC is consistent. This doubly robust property is
# MAGIC most valuable when weights are noisy — i.e., when N_co is small.
# MAGIC
# MAGIC ## This benchmark
# MAGIC
# MAGIC - **Scenario 1 (few donors):** N_co = 6, N_tr = 5, 100 Monte Carlo sims
# MAGIC - **Scenario 2 (many donors):** N_co = 40, N_tr = 5, 100 Monte Carlo sims
# MAGIC - True ATT = -0.06, standard factor model DGP
# MAGIC - Compare: bias, RMSE, SE, 95% CI coverage
# MAGIC
# MAGIC **Date:** 2026-03-21  |  **Library version:** 0.1.9

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Setup

# COMMAND ----------

%pip install insurance-causal-policy==0.1.9 cvxpy matplotlib numpy scipy polars pandas

# COMMAND ----------

import warnings
import sys
import time
import numpy as np

warnings.filterwarnings("ignore")

# Set number of simulations — increase for more stable results
N_SIMS = 100
# Pass to the benchmark script
sys._drsc_bench_n_sims = N_SIMS

print(f"Monte Carlo simulations per scenario: {N_SIMS}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Import estimators and DGP

# COMMAND ----------

from insurance_causal_policy import (
    SDIDEstimator,
    DoublyRobustSCEstimator,
    make_synthetic_panel_direct,
)

print("Imports OK")
print(f"  SDIDEstimator: {SDIDEstimator}")
print(f"  DoublyRobustSCEstimator: {DoublyRobustSCEstimator}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. DGP parameters

# COMMAND ----------

# DGP settings — these match the benchmark script
TRUE_ATT  = -0.06   # true causal effect on loss ratio
T_PRE     = 8       # pre-treatment periods (8 quarters = 2 years)
T_POST    = 4       # post-treatment periods
N_TREATED = 5       # treated units (fixed across scenarios)
NOISE_SD  = 0.03    # within-unit noise
BASE_LR   = 0.70    # base loss ratio
TREND     = 0.003   # common time trend per period (claims inflation)

INFERENCE = "jackknife"  # fastest for MC; bootstrap more reliable in production

print(f"True ATT       = {TRUE_ATT}")
print(f"Pre periods    = {T_PRE}  |  Post periods = {T_POST}")
print(f"Treated units  = {N_TREATED}")
print(f"Noise SD       = {NOISE_SD}  |  Trend = {TREND}/period")
print(f"Inference      = {INFERENCE}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Monte Carlo runner

# COMMAND ----------

def run_scenario(label: str, n_co: int, n_sims: int) -> dict:
    """Run N_SIMS MC replications for both SDID and DRSC."""
    print(f"\nScenario: {label}  (N_co={n_co}, N_tr={N_TREATED})")

    sdid_atts, sdid_ses, sdid_covers = [], [], []
    drsc_atts, drsc_ses, drsc_covers = [], [], []

    for sim_idx in range(n_sims):
        seed = 1000 + sim_idx
        panel = make_synthetic_panel_direct(
            n_control=n_co,
            n_treated=N_TREATED,
            t_pre=T_PRE,
            t_post=T_POST,
            true_att=TRUE_ATT,
            noise_sd=NOISE_SD,
            base_lr=BASE_LR,
            trend=TREND,
            random_seed=seed,
        )

        # SDID
        try:
            est = SDIDEstimator(
                panel, outcome="loss_ratio",
                inference=INFERENCE, n_replicates=50, random_seed=seed,
            )
            r = est.fit()
            sdid_atts.append(r.att)
            sdid_ses.append(r.se)
            sdid_covers.append(r.ci_low <= TRUE_ATT <= r.ci_high)
        except Exception:
            pass

        # DRSC
        try:
            est = DoublyRobustSCEstimator(
                panel, outcome="loss_ratio",
                inference=INFERENCE, n_replicates=50, random_seed=seed,
            )
            r = est.fit()
            drsc_atts.append(r.att)
            drsc_ses.append(r.se)
            drsc_covers.append(r.ci_low <= TRUE_ATT <= r.ci_high)
        except Exception:
            pass

        if (sim_idx + 1) % 20 == 0:
            print(f"  {sim_idx + 1}/{n_sims} sims")

    def _stats(atts, ses, covers, name):
        arr = np.array(atts)
        if len(arr) == 0:
            return {"name": name, "n_valid": 0, "mean_att": float("nan"),
                    "abs_bias": float("nan"), "rmse": float("nan"),
                    "std": float("nan"), "mean_se": float("nan"),
                    "coverage": float("nan")}
        return {
            "name": name,
            "n_valid": len(arr),
            "mean_att": float(np.mean(arr)),
            "abs_bias": float(abs(np.mean(arr) - TRUE_ATT)),
            "rmse": float(np.sqrt(np.mean((arr - TRUE_ATT) ** 2))),
            "std": float(np.std(arr)),
            "mean_se": float(np.mean(ses)) if ses else float("nan"),
            "coverage": float(np.mean(covers)) if covers else float("nan"),
        }

    return {
        "label": label,
        "n_co": n_co,
        "sdid": _stats(sdid_atts, sdid_ses, sdid_covers, "SDID"),
        "drsc": _stats(drsc_atts, drsc_ses, drsc_covers, "DRSC"),
    }

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. Run scenario 1: few donors (N_co=6)

# COMMAND ----------

t0 = time.time()
res_few = run_scenario("Few donors (N_co=6)", n_co=6, n_sims=N_SIMS)
print(f"Completed in {time.time() - t0:.1f}s")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 6. Run scenario 2: many donors (N_co=40)

# COMMAND ----------

t0 = time.time()
res_many = run_scenario("Many donors (N_co=40)", n_co=40, n_sims=N_SIMS)
print(f"Completed in {time.time() - t0:.1f}s")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 7. Results table

# COMMAND ----------

def print_results(res: dict) -> None:
    label = res["label"]
    sdid  = res["sdid"]
    drsc  = res["drsc"]

    print(f"\n{'=' * 68}")
    print(f"  {label}")
    print(f"{'=' * 68}")
    print(f"  True ATT = {TRUE_ATT:.4f}  |  {sdid['n_valid']} SDID / {drsc['n_valid']} DRSC valid replications")
    print()
    print(f"  {'Metric':<35} {'SDID':>10} {'DRSC':>10}  Winner")
    print(f"  {'-' * 62}")

    metrics = [
        ("Mean ATT", "mean_att", ".4f"),
        ("Absolute bias", "abs_bias", ".4f"),
        ("RMSE", "rmse", ".4f"),
        ("Std dev of estimates", "std", ".4f"),
        ("Mean reported SE", "mean_se", ".4f"),
    ]

    for label_m, key, fmt in metrics:
        sv = sdid[key]
        dv = drsc[key]
        if key in ("abs_bias", "rmse", "std", "mean_se"):
            w = "DRSC" if dv < sv else ("SDID" if sv < dv else "tie")
        else:
            w = ""
        sv_s = f"{sv:>10{fmt}}" if not np.isnan(sv) else "       n/a"
        dv_s = f"{dv:>10{fmt}}" if not np.isnan(dv) else "       n/a"
        print(f"  {label_m:<35} {sv_s} {dv_s}  {w}")

    # Coverage
    sc = sdid["coverage"]
    dc = drsc["coverage"]
    w_cov = "DRSC" if abs(dc - 0.95) < abs(sc - 0.95) else "SDID"
    sc_s = f"{sc:>9.1%}" if not np.isnan(sc) else "      n/a"
    dc_s = f"{dc:>9.1%}" if not np.isnan(dc) else "      n/a"
    print(f"  {'95% CI coverage (target=95%)':<35} {sc_s} {dc_s}  {w_cov}")
    print()


print_results(res_few)
print_results(res_many)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 8. Visual comparison

# COMMAND ----------

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

fig, axes = plt.subplots(1, 2, figsize=(13, 5))
fig.suptitle("DRSC vs SDID: Performance by Donor Pool Size", fontsize=14, fontweight="bold")

colors = {"SDID": "#1f77b4", "DRSC": "#ff7f0e"}

for ax, res in zip(axes, [res_few, res_many]):
    sdid = res["sdid"]
    drsc = res["drsc"]

    metrics = ["abs_bias", "rmse", "std"]
    labels  = ["Abs Bias", "RMSE", "Std Dev"]
    x = np.arange(len(metrics))
    w = 0.35

    sdid_vals = [sdid[m] for m in metrics]
    drsc_vals = [drsc[m] for m in metrics]

    bars1 = ax.bar(x - w/2, sdid_vals, w, label="SDID", color=colors["SDID"], alpha=0.85)
    bars2 = ax.bar(x + w/2, drsc_vals, w, label="DRSC", color=colors["DRSC"], alpha=0.85)

    ax.set_title(res["label"])
    ax.set_xticks(x)
    ax.set_xticklabels(labels)
    ax.set_ylabel("Value (loss ratio units)")
    ax.legend()

    # Annotate coverage
    sc = sdid["coverage"]
    dc = drsc["coverage"]
    cov_text = f"Coverage: SDID={sc:.0%}  DRSC={dc:.0%}"
    ax.text(0.5, 0.97, cov_text, transform=ax.transAxes,
            ha="center", va="top", fontsize=9,
            bbox=dict(boxstyle="round,pad=0.3", facecolor="lightyellow", alpha=0.8))

plt.tight_layout()
plt.savefig("/tmp/drsc_vs_sdid_benchmark.png", dpi=150, bbox_inches="tight")
plt.show()
print("Plot saved to /tmp/drsc_vs_sdid_benchmark.png")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 9. Interpretation and practical guidance

# COMMAND ----------

few_sdid_bias = res_few["sdid"]["abs_bias"]
few_drsc_bias = res_few["drsc"]["abs_bias"]
many_sdid_bias = res_many["sdid"]["abs_bias"]
many_drsc_bias = res_many["drsc"]["abs_bias"]

few_sdid_rmse = res_few["sdid"]["rmse"]
few_drsc_rmse = res_few["drsc"]["rmse"]

if few_sdid_bias > 1e-6:
    bias_improvement = (few_sdid_bias - few_drsc_bias) / few_sdid_bias * 100
else:
    bias_improvement = 0.0

if few_sdid_rmse > 1e-6:
    rmse_improvement = (few_sdid_rmse - few_drsc_rmse) / few_sdid_rmse * 100
else:
    rmse_improvement = 0.0

print("INTERPRETATION")
print("=" * 68)
print()
print(f"Few donors (N_co=6):")
print(f"  SDID abs bias: {few_sdid_bias:.4f}   DRSC abs bias: {few_drsc_bias:.4f}")
if bias_improvement > 5:
    print(f"  DRSC reduces bias by {bias_improvement:.1f}% over SDID.")
    print(f"  The outcome model is absorbing weight misspecification noise.")
elif bias_improvement < -5:
    print(f"  SDID has lower bias ({-bias_improvement:.1f}% better than DRSC).")
    print(f"  Outcome model extrapolation may be adding noise in this regime.")
else:
    print(f"  Bias difference is small ({abs(bias_improvement):.1f}%).")
    print(f"  The augmentation correction is near-zero — weights are adequate.")

print()
print(f"  SDID RMSE: {few_sdid_rmse:.4f}   DRSC RMSE: {few_drsc_rmse:.4f}")
if rmse_improvement > 5:
    print(f"  DRSC reduces RMSE by {rmse_improvement:.1f}% over SDID.")
elif rmse_improvement < -5:
    print(f"  SDID has lower RMSE ({-rmse_improvement:.1f}% better).")
else:
    print(f"  RMSE difference is small.")

print()
print(f"Many donors (N_co=40):")
print(f"  SDID abs bias: {many_sdid_bias:.4f}   DRSC abs bias: {many_drsc_bias:.4f}")
print(f"  At large N_co, SDID weights are stable and the augmentation term")
print(f"  is near-zero. Both methods should perform similarly.")
print()
print("PRACTICAL GUIDANCE")
print("-" * 68)
print("  N_co < 10 : Use DRSC. Weights are fragile; outcome model helps.")
print("  N_co 10-20: Run both; compare bias and CI coverage.")
print("  N_co > 20 : SDID is sufficient and slightly simpler to explain.")
print()
print("  Both estimators accept the same panel format and return SDIDResult.")
print("  Switching between them is one line: s/SDIDEstimator/DoublyRobustSCEstimator/")
