from typing import Any

from ..types import CancelOrderRequest, GetOrderList, ModifyOrderRequest, OrderDetail, OrderStatus, PlaceOrderRequest
from ..exceptions import ServiceError


class OrderService:
    def __init__(self, sdk : Any) -> None:
        self._sdk = sdk.client

    def place_order(self, request: PlaceOrderRequest) -> dict[str, Any]:
        try:
            return self._sdk.place_order(**request.to_payload())
        except Exception as exc:
            raise ServiceError(
                'Error in placing order',
                status_code=500,
                operation='PLACING_ORDER',
                details={'reason': 'Error in placing method'},
            ) from exc

    def modify_order(self, request: ModifyOrderRequest) -> dict[str, Any]:
        try:
            return self._sdk.modify_order(**request.to_payload())
        except Exception as exc:
            raise ServiceError(
                'Error in modifying order',
                status_code=500,
                operation='MODIFYING_ORDER',
                details={'reason': 'Error in modify method'},
            ) from exc

    def cancel_order(self, request: CancelOrderRequest) -> dict[str, Any]:
        try:
            return self._sdk.cancel_order(**request.to_payload())
        except Exception as exc:
            raise ServiceError(
                'Error in canceling order',
                status_code=500,
                operation='CANCELING_ORDER',
                details={'reason': 'Error in cancel method'},
            ) from exc

    def get_order_status(self, request: OrderStatus) -> dict[str, Any]:
        try:
            return self._sdk.get_order_status(**request.to_payload())
        except Exception as exc:
            raise ServiceError(
                'Error in getting order status',
                status_code=500,
                operation='GET_ORDER_STATUS',
                details={'reason': 'Error in get order status method'},
            ) from exc

    def get_order_list(self, request: GetOrderList) -> dict[str, Any]:
        try:
            return self._sdk.get_order_list(**request.to_payload())
        except Exception as exc:
            raise ServiceError(
                'Error in getting order list',
                status_code=500,
                operation='GET_ORDER_LIST',
                details={'reason': 'Error in get order list method'},
            ) from exc

    def get_order_detail(self, request: OrderDetail) -> dict[str, Any]:
        try:
            return self._sdk.get_order_detail(**request.to_payload())
        except Exception as exc:
            raise ServiceError(
                'Error in getting order detail',
                status_code=500,
                operation='GET_ORDER_DETAIL',
                details={'reason': 'Error in get order detail method'},
            ) from exc