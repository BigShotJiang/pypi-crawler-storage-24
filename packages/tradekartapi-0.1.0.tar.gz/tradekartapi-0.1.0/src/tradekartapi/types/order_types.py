from __future__ import annotations

from dataclasses import dataclass
from typing import Any
from ..utils.validators import require_non_empty, require_positive_int
from .annexures import Exchange, Segment, Product, OrderType, TransactionType, Validity


@dataclass(frozen=True, slots=True)
class PlaceOrderRequest:
    trading_symbol: str
    quantity : int
    validity : Validity
    exchange: Exchange
    segment : Segment
    product : Product
    order_type : OrderType
    transaction_type : TransactionType
    price: float | None = None
    trigger_price: float | None = None
    order_reference_id: str | None = None

    def __post_init__(self) -> None:
        require_non_empty(self.trading_symbol, 'trading_symbol')
        require_positive_int(self.quantity, 'quantity')
        #Todo Add Valodation for price and trigger_price

    def to_payload(self) -> dict[str, Any]:
        payload = {
            'trading_symbol': self.trading_symbol,
            'quantity': self.quantity,
            'validity': self.validity.value,
            'exchange': self.exchange.value,
            'segment': self.segment.value,
            'product': self.product.value,
            'order_type': self.order_type.value,
            'transaction_type': self.transaction_type.value,
        }

        if self.price is not None:
            payload['price'] = self.price
        if self.trigger_price is not None:
            payload['trigger_price'] = self.trigger_price
        if self.order_reference_id is not None:
            payload['order_reference_id'] = self.order_reference_id
        return payload
    

@dataclass(frozen=True, slots=True)
class ModifyOrderRequest:
    quantity : int
    order_type : OrderType
    segment : Segment
    groww_order_id : str
    price : float | None = None 
    trigger_price: float | None = None

    def __post_init__(self) -> None:
        require_positive_int(self.quantity, 'quantity')
        require_non_empty(self.groww_order_id, 'groww_order_id')
        #Todo Add Valodation for price and trigger_price

    def to_payload(self) -> dict[str, Any]:
        payload = {
            'quantity': self.quantity,
            'order_type': self.order_type.value,
            'segment': self.segment.value,
            'groww_order_id': self.groww_order_id
        }

        if self.price is not None:
            payload['price'] = self.price

        if self.trigger_price is not None:
            payload['trigger_price'] = self.trigger_price

        return payload


@dataclass(frozen=True, slots=True)
class CancelOrderRequest:
    segment : Segment
    groww_order_id : str

    def __post_init__(self) -> None:
        require_non_empty(self.groww_order_id, 'groww_order_id')

    def to_payload(self) -> dict[str, Any]:
        return {
            'segment': self.segment.value,
            'groww_order_id': self.groww_order_id
        }


@dataclass(frozen=True, slots=True)
class OrderStatus:
    segment : Segment
    groww_order_id : str

    def __post_init__(self) -> None:
        require_non_empty(self.groww_order_id, 'groww_order_id')

    def to_payload(self) -> dict[str, Any]:
        return {
            'segment': self.segment.value,
            'groww_order_id': self.groww_order_id
        }


@dataclass(frozen=True, slots=True)
class OrderStatsByRefId:
    order_reference_id : str
    segment : Segment

    def __post_init__(self) -> None:
        require_non_empty(self.order_reference_id, 'order_reference_id')

    def to_payload(self) -> dict[str, Any]:
        return {
            'order_reference_id': self.order_reference_id,
            'segment': self.segment.value
        }
        

@dataclass(frozen=True, slots=True)
class GetOrderList:
    segment : Segment | None = None
    page : int | None = None 
    page_size : int | None = None 

    def __post_init__(self) -> None:
        if self.page is not None:
            require_positive_int(self.page, 'page')
        if self.page_size is not None:
            require_positive_int(self.page_size, 'page_size')

    def to_payload(self) -> dict[str, Any]:
        payload = {}
        if self.segment is not None:
            payload['segment'] = self.segment.value
        if self.page is not None:
            payload['page'] = self.page
        if self.page_size is not None:
            payload['page_size'] = self.page_size
        return payload


@dataclass(frozen=True, slots=True)
class OrderDetail:
    segment : Segment
    groww_order_id : str

    def __post_init__(self) -> None:
        require_non_empty(self.groww_order_id, 'groww_order_id')

    def to_payload(self) -> dict[str, Any]:
        return {
            'segment': self.segment.value,
            'groww_order_id': self.groww_order_id
        }