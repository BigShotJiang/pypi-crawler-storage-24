from ..exceptions import ValidationError

def require_non_empty(value: str, field_name: str) -> None:
    if not value or not value.strip():
        raise ValidationError(f"{field_name} is required and cannot be empty.")

def require_positive_int(value: int, field_name: str) -> None:
    if value <= 0:
        raise ValidationError(f"{field_name} must be greater than 0.")

def validate_access_token(access_token: str) -> None:
    if not access_token or not access_token.strip():
        raise ValidationError("Access token is required and cannot be empty.")