from typing import Any

from .adapter import GrowwSDKAdapter
from .services import OrderService


class TradeKartClient:
    """
    Main facade for app developers.

    Example:
        from growwapi import GrowwAPI
        from tradekartapi.client import TradeKartClient
        client = TradeKartClient.from_access_token("token", GrowwAPI)
    """

    def __init__(self, adapter: GrowwSDKAdapter):
        self._adapter = adapter
        self.order_service = OrderService(adapter)

    @classmethod
    def from_access_token(cls, access_token: str, groww_sdk_client: Any) -> 'GrowwClient':
        adapter = GrowwSDKAdapter.from_access_token(access_token, groww_sdk_client)
        return cls(adapter=adapter)

    @property
    def raw_sdk(self) -> Any:
        return self._adapter.client
        