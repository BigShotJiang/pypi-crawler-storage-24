# for future configuration like retry, timeout, env config

DEFAULT_TIMEOUT_SECONDS = 15
PACKAGE_NAME = "tradekart-groww-api"