import json, os

def create_notebooks():
    base = os.path.join(os.path.dirname(__file__), "codes")

    for file in os.listdir(base):
        if file.endswith(".py"):
            with open(os.path.join(base, file)) as f:
                code = f.read()

            notebook = {
                "cells": [
                    {"cell_type": "markdown", "source": [f"# {file}\n"]},
                    {"cell_type": "code", "source": code.split("\n")}
                ],
                "metadata": {},
                "nbformat": 4,
                "nbformat_minor": 5
            }

            with open(file.replace(".py", ".ipynb"), "w") as f:
                json.dump(notebook, f)

    print("✅ Notebooks created!")