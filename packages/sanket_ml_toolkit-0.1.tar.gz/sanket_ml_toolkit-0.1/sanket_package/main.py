import os
import argparse
from .notebook_generator import create_notebooks

BASE_PATH = os.path.join(os.path.dirname(__file__), "codes")

# Mapping practical → file
PRACTICAL_MAP = {
    "1": "matrix_tf.py",
    "2": "xor_nn.py",
    "3": "dnn_classification.py",
    "4": "autoencoder_dense.py",
    "5": "cnn_mnist.py",
    "6": "denoising_autoencoder.py"
}


def show_code(file):
    path = os.path.join(BASE_PATH, file)
    print(f"\n📜 Showing {file}:\n")
    print(open(path, encoding="utf-8").read())


def create_py(file):
    path = os.path.join(BASE_PATH, file)
    with open(path, encoding="utf-8") as src:
        open(file, "w").write(src.read())
    print(f"✅ {file} created!")


def create_ipynb(file):
    import json

    path = os.path.join(BASE_PATH, file)
    code = open(path, encoding="utf-8").read()

    notebook = {
        "cells": [
            {"cell_type": "markdown", "source": [f"# {file}\n"]},
            {"cell_type": "code", "source": code.split("\n")}
        ],
        "metadata": {},
        "nbformat": 4,
        "nbformat_minor": 5
    }

    nb_name = file.replace(".py", ".ipynb")
    with open(nb_name, "w", encoding="utf-8") as f:
        json.dump(notebook, f, indent=4)

    print(f"✅ {nb_name} created!")


def main():
    parser = argparse.ArgumentParser(description="Sanket ML Toolkit")
    parser.add_argument("--practical", help="Choose practical number (1-6)")

    args = parser.parse_args()

    if not args.practical:
        print("❌ Please provide --practical number (1-6)")
        return

    file = PRACTICAL_MAP.get(args.practical)

    if not file:
        print("❌ Invalid practical number")
        return

    print(f"""
🔥 Practical {args.practical} Selected

1. Show code
2. Create .py file
3. Create .ipynb
""")

    choice = input("Enter choice: ")

    if choice == "1":
        show_code(file)
    elif choice == "2":
        create_py(file)
    elif choice == "3":
        create_ipynb(file)
    else:
        print("❌ Invalid choice")