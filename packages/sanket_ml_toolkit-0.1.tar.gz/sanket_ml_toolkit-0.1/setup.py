from setuptools import setup, find_packages

setup(
    name="sanket-ml-toolkit",
    version="0.1",
    packages=find_packages(),
    install_requires=["tensorflow","numpy","matplotlib","scikit-learn"],
    entry_points={
        'console_scripts': [
            'sanket-code=sanket_package.main:main',
        ],
    }
)
