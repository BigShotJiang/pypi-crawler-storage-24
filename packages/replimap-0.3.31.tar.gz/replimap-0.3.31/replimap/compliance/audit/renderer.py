"""SOC 2 audit evidence report renderer.

Generates comprehensive markdown reports showing PASS/FAIL/EXEMPTED
status for every compliance-covered resource, organized by SOC 2
Trust Service Criteria.

Key difference from drift --compliance output:
- Shows ALL resources (including PASS), not just findings
- Organized by SOC 2 control area, not by severity
- Includes coverage statistics per control
- Designed as audit evidence, not as a drift report
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

from replimap.compliance.drift.mapping import (
    ComplianceDriftFinding,
    ComplianceDriftReport,
)
from replimap.compliance.drift.rules import COMPLIANCE_RULES, ComplianceRule
from replimap.drift.state_parser import TFResource

_REPLIMAP_VERSION = "3.8.0"


# =============================================================================
# SOC 2 Control Area definitions
# =============================================================================


@dataclass(frozen=True)
class ControlArea:
    """A SOC 2 Trust Service Criteria control area."""

    control_id: str
    name: str
    scope: str
    rules: tuple[str, ...]  # rule_ids that map to this control


# The four control areas covered by Phase 1 rules
SOC2_CONTROL_AREAS: tuple[ControlArea, ...] = (
    ControlArea(
        control_id="CC6.1",
        name="Logical and Physical Access Controls",
        scope="Encryption at rest for data stores, key management rotation, IAM trust policies.",
        rules=(
            "s3-encryption-enabled",
            "rds-encryption-enabled",
            "kms-key-rotation-enabled",
            "iam-trust-policy",
        ),
    ),
    ControlArea(
        control_id="CC6.6",
        name="System Boundaries",
        scope="Network access controls, public exposure prevention, security group restrictions.",
        rules=(
            "s3-no-public-acl",
            "rds-not-publicly-accessible",
            "sg-no-unrestricted-ingress",
            "sg-no-unrestricted-egress",
        ),
    ),
    ControlArea(
        control_id="CC7.1",
        name="System Monitoring",
        scope="Logging, audit trails, availability configuration, backup retention.",
        rules=("s3-logging-enabled", "rds-multi-az-enabled", "rds-backup-retention"),
    ),
    ControlArea(
        control_id="CC8.1",
        name="Change Management",
        scope="Infrastructure changes tracked via Terraform state comparison.",
        rules=("s3-versioning-enabled",),
    ),
)

# Control areas NOT covered by automated checks
_UNCOVERED_CONTROLS = (
    "CC6.2",
    "CC6.3",
    "CC6.4",
    "CC6.5",
    "CC6.7",
    "CC6.8",
    "CC7.2",
    "CC7.3",
    "CC7.4",
    "CC8.2",
    "CC8.3",
    "CC9.1",
    "CC9.2",
    "A1.1",
    "A1.2",
    "A1.3",
    "C1.1",
    "C1.2",
    "PI1.1",
    "PI1.2",
)

# Build rule lookup: rule_id → ComplianceRule
_RULES_BY_ID: dict[str, ComplianceRule] = {r.rule_id: r for r in COMPLIANCE_RULES}


# =============================================================================
# Check result model
# =============================================================================


@dataclass
class ResourceCheck:
    """Result of a single compliance check on a resource."""

    tf_address: str
    resource_id: str
    resource_type: str
    check_description: str
    status: str  # "PASS", "FAIL", "EXEMPTED"
    evidence: str  # Human-readable evidence string
    rule_id: str
    finding: ComplianceDriftFinding | None = None


@dataclass
class ControlSection:
    """All checks for a single SOC 2 control area."""

    control: ControlArea
    checks: list[ResourceCheck] = field(default_factory=list)

    @property
    def pass_count(self) -> int:
        return sum(1 for c in self.checks if c.status == "PASS")

    @property
    def fail_count(self) -> int:
        return sum(1 for c in self.checks if c.status == "FAIL")

    @property
    def exempt_count(self) -> int:
        return sum(1 for c in self.checks if c.status == "EXEMPTED")


# =============================================================================
# Renderer
# =============================================================================


class AuditEvidenceRenderer:
    """Renders SOC 2 audit evidence reports from compliance drift data.

    Takes the full list of TF resources (for PASS status) and the
    ComplianceDriftReport (for FAIL/EXEMPTED status), then produces
    a comprehensive evidence document organized by SOC 2 control area.
    """

    def __init__(
        self,
        tf_resources: list[TFResource],
        compliance_report: ComplianceDriftReport,
        company: str = "",
        period: str = "",
    ) -> None:
        self._tf_resources = tf_resources
        self._compliance_report = compliance_report
        self._company = company
        self._period = period

        # Index findings by (tf_address, attribute) for O(1) lookup
        self._fail_index: dict[tuple[str, str], ComplianceDriftFinding] = {}
        for f in compliance_report.findings:
            self._fail_index[(f.tf_address, f.attribute)] = f

        # Index exempted findings
        self._exempt_index: dict[tuple[str, str], ComplianceDriftFinding] = {}
        for f in compliance_report.exempted:
            self._exempt_index[(f.tf_address, f.attribute)] = f

        # Cache for build_sections() — avoids recomputation
        self._cached_sections: list[ControlSection] | None = None

    def build_sections(self) -> list[ControlSection]:
        """Build all control sections with PASS/FAIL/EXEMPTED checks.

        Results are cached — safe to call multiple times.
        """
        if self._cached_sections is not None:
            return self._cached_sections

        sections = []
        for control_area in SOC2_CONTROL_AREAS:
            section = ControlSection(control=control_area)

            for rule_id in control_area.rules:
                rule = _RULES_BY_ID.get(rule_id)
                if rule is None:
                    continue

                # Find all TF resources matching this rule's resource_type
                matching_resources = [
                    r for r in self._tf_resources if r.type == rule.resource_type
                ]

                for tf_res in matching_resources:
                    check = self._evaluate_resource(tf_res, rule)
                    section.checks.append(check)

            sections.append(section)

        self._cached_sections = sections
        return sections

    def _evaluate_resource(
        self, tf_res: TFResource, rule: ComplianceRule
    ) -> ResourceCheck:
        """Evaluate a single resource against a compliance rule."""
        tf_address = tf_res.address

        # Check if this resource has a FAIL finding
        fail_key = (tf_address, rule.attribute)
        finding = self._fail_index.get(fail_key)
        if finding is not None:
            return ResourceCheck(
                tf_address=tf_address,
                resource_id=tf_res.id,
                resource_type=tf_res.type,
                check_description=rule.description,
                status="FAIL",
                evidence=_format_fail_evidence(finding),
                rule_id=rule.rule_id,
                finding=finding,
            )

        # Check if exempted
        exempt_finding = self._exempt_index.get(fail_key)
        if exempt_finding is not None:
            return ResourceCheck(
                tf_address=tf_address,
                resource_id=tf_res.id,
                resource_type=tf_res.type,
                check_description=rule.description,
                status="EXEMPTED",
                evidence=f"Exempted: {exempt_finding.exemption_reason}",
                rule_id=rule.rule_id,
                finding=exempt_finding,
            )

        # Check for removal finding (attribute = "(resource deleted)")
        removal_key = (tf_address, "(resource deleted)")
        removal_finding = self._fail_index.get(removal_key)
        if removal_finding is not None:
            return ResourceCheck(
                tf_address=tf_address,
                resource_id=tf_res.id,
                resource_type=tf_res.type,
                check_description=rule.description,
                status="FAIL",
                evidence="Resource deleted outside Terraform",
                rule_id=rule.rule_id,
                finding=removal_finding,
            )

        # PASS — extract evidence from TF state attributes
        evidence = _format_pass_evidence(tf_res, rule)
        return ResourceCheck(
            tf_address=tf_address,
            resource_id=tf_res.id,
            resource_type=tf_res.type,
            check_description=rule.description,
            status="PASS",
            evidence=evidence,
            rule_id=rule.rule_id,
        )

    def render(self) -> str:
        """Render the complete SOC 2 audit evidence markdown report."""
        sections = self.build_sections()
        lines: list[str] = []

        total_checks = sum(len(s.checks) for s in sections)
        total_pass = sum(s.pass_count for s in sections)
        total_fail = sum(s.fail_count for s in sections)
        total_exempt = sum(s.exempt_count for s in sections)
        compliance_rate = (total_pass / total_checks * 100) if total_checks > 0 else 0

        # ── Header ─────────────────────────────────────────────────
        lines.append("# SOC 2 Compliance Evidence Report")
        lines.append("")
        lines.append("## Report Information")
        lines.append("")
        lines.append("| Field | Value |")
        lines.append("|-------|-------|")
        if self._company:
            lines.append(f"| Company | {self._company} |")
        if self._period:
            lines.append(f"| Audit Period | {self._period} |")
        lines.append(
            f"| Generated | {self._compliance_report.scanned_at.strftime('%Y-%m-%d %H:%M:%S UTC')} |"
        )
        lines.append(f"| Tool | RepliMap v{_REPLIMAP_VERSION} |")
        lines.append(f"| Region | {self._compliance_report.region} |")
        lines.append(f"| State File | {self._compliance_report.state_file} |")
        lines.append("")
        lines.append(
            "> **Data sovereignty notice:** This report was generated locally. "
            "No infrastructure data was transmitted to any external service."
        )
        lines.append("")

        # ── Executive Summary ──────────────────────────────────────
        lines.append("## Executive Summary")
        lines.append("")

        if total_checks == 0:
            lines.append(
                "No resources to evaluate. The Terraform state file contains "
                "no resources covered by the current compliance rule set."
            )
            lines.append("")
        else:
            control_area_count = sum(1 for s in sections if s.checks)
            lines.append(
                f"{total_checks} checks performed across "
                f"{control_area_count} SOC 2 control areas."
            )
            lines.append("")
            lines.append("| Status | Count |")
            lines.append("|--------|-------|")
            lines.append(f"| ✅ Compliant | {total_pass} |")
            lines.append(f"| ❌ Non-Compliant | {total_fail} |")
            lines.append(f"| ⚠️ Exempted | {total_exempt} |")
            lines.append("")
            lines.append(f"Overall compliance rate: **{compliance_rate:.0f}%**")
            lines.append("")

        # ── Control Sections ───────────────────────────────────────
        for section in sections:
            lines.extend(self._render_control_section(section))

        # ── Accepted Risks ─────────────────────────────────────────
        if self._compliance_report.exempted:
            lines.append("## Accepted Risks")
            lines.append("")
            lines.append("| Resource | Control | Reason | Approved By | Expires |")
            lines.append("|----------|---------|--------|-------------|---------|")
            for f in self._compliance_report.exempted:
                controls_str = ", ".join(
                    f"{c.framework} {c.control_id}" for c in f.controls
                )
                lines.append(
                    f"| `{f.tf_address}` | {controls_str} "
                    f"| {_escape_md(f.exemption_reason)} | - | - |"
                )
            lines.append("")

        # ── Expired Exemptions ─────────────────────────────────────
        if self._compliance_report.expired_exemptions:
            lines.append("## Expired Exemptions \u26a0\ufe0f")
            lines.append("")
            lines.append("| Resource | Control | Reason | Expired On |")
            lines.append("|----------|---------|--------|------------|")
            for f in self._compliance_report.expired_exemptions:
                controls_str = ", ".join(
                    f"{c.framework} {c.control_id}" for c in f.controls
                )
                lines.append(
                    f"| `{f.tf_address}` | {controls_str} | {_escape_md(f.exemption_reason)} | - |"
                )
            lines.append("")

        # ── Scope Limitations ──────────────────────────────────────
        lines.append("## Scope Limitations")
        lines.append("")
        lines.append(
            "The following SOC 2 control areas are not covered by this automated "
            "assessment and require manual evidence collection:"
        )
        lines.append("")
        lines.append(", ".join(_UNCOVERED_CONTROLS))
        lines.append("")

        # ── Footer ─────────────────────────────────────────────────
        lines.append("---")
        lines.append("")
        lines.append(
            f"*Report generated by RepliMap v{_REPLIMAP_VERSION} on "
            f"{datetime.now(UTC).strftime('%Y-%m-%d %H:%M:%S UTC')}*"
        )
        lines.append("")

        return "\n".join(lines)

    def _render_control_section(self, section: ControlSection) -> list[str]:
        """Render a single SOC 2 control section."""
        lines: list[str] = []
        ctrl = section.control

        lines.append(f"## {ctrl.control_id} — {ctrl.name}")
        lines.append("")
        lines.append(f"**Scope:** {ctrl.scope}")
        lines.append("")

        if not section.checks:
            lines.append(
                "No resources of the applicable types found in Terraform state."
            )
            lines.append("")
            return lines

        lines.append("### Checks Performed")
        lines.append("")
        lines.append("| Resource | Check | Status | Evidence |")
        lines.append("|----------|-------|--------|----------|")
        for check in section.checks:
            status_icon = _status_icon(check.status)
            # Truncate evidence for table readability
            evidence = (
                check.evidence[:80] if len(check.evidence) > 80 else check.evidence
            )
            lines.append(
                f"| `{check.tf_address}` | {check.check_description} "
                f"| {status_icon} {check.status} | {evidence} |"
            )
        lines.append("")

        if section.fail_count > 0:
            lines.append(
                f"{section.fail_count} non-compliant resource(s) in this control area."
            )
            lines.append("")
            lines.append("### Remediation Required")
            lines.append("")
            for check in section.checks:
                if check.status == "FAIL" and check.finding:
                    lines.append(
                        f"1. `{check.tf_address}` — {check.finding.remediation}"
                    )
            lines.append("")
        else:
            lines.append("All resources compliant in this control area.")
            lines.append("")

        lines.append("---")
        lines.append("")
        return lines


# =============================================================================
# Evidence formatting helpers
# =============================================================================


def _escape_md(value: str) -> str:
    """Escape characters that break markdown table formatting."""
    return value.replace("|", "\\|").replace("\n", " ")


def _status_icon(status: str) -> str:
    return {"PASS": "✅", "FAIL": "❌", "EXEMPTED": "⚠️"}.get(status, "")


def _format_fail_evidence(finding: ComplianceDriftFinding) -> str:
    """Format evidence string for a FAIL finding."""
    actual = finding.actual
    if actual is None:
        return "Not configured"
    if isinstance(actual, bool):
        return str(actual).lower()
    if isinstance(actual, list) and len(actual) > 0:
        return f"{len(actual)} rule(s) — see drift report for details"
    return str(actual)[:80]


def _format_pass_evidence(tf_res: TFResource, rule: ComplianceRule) -> str:
    """Extract evidence string from TF state for a PASS check."""
    attr_value = tf_res.attributes.get(rule.attribute)

    if attr_value is None:
        # Attribute not in state — likely inherited default
        return "Default configuration"

    if isinstance(attr_value, bool):
        return str(attr_value).lower()

    if isinstance(attr_value, dict):
        # Encryption config, versioning config, etc.
        if rule.attribute == "server_side_encryption_configuration":
            algo = _extract_sse_algorithm(attr_value)
            return f"Encrypted ({algo})" if algo else "Encryption configured"
        if rule.attribute == "versioning":
            status = attr_value.get("Status", attr_value.get("status", ""))
            return f"Versioning: {status}" if status else "Versioning configured"
        if rule.attribute == "logging":
            target = attr_value.get("target_bucket", attr_value.get("TargetBucket", ""))
            return f"Logging to {target}" if target else "Logging enabled"
        return "Configured"

    if isinstance(attr_value, (int, float)):
        if rule.attribute == "backup_retention_period":
            return f"{attr_value} days"
        return str(attr_value)

    if isinstance(attr_value, str):
        if rule.attribute == "acl":
            return f"ACL: {attr_value}"
        return attr_value[:60]

    if isinstance(attr_value, list):
        return f"{len(attr_value)} rule(s) configured"

    return str(attr_value)[:60]


def _extract_sse_algorithm(config: dict[str, Any]) -> str:
    """Extract SSE algorithm from encryption configuration."""
    rules = config.get("rule", config.get("Rule", []))
    if not isinstance(rules, list) or not rules:
        return ""
    first = rules[0]
    default_enc = first.get(
        "apply_server_side_encryption_by_default",
        first.get("ApplyServerSideEncryptionByDefault", {}),
    )
    if isinstance(default_enc, dict):
        return str(
            default_enc.get("sse_algorithm", default_enc.get("SSEAlgorithm", ""))
        )
    return ""
