"""SOC 2 audit evidence report generator.

Produces comprehensive audit evidence documents that show PASS/FAIL/EXEMPTED
status for every compliance-covered resource, organized by SOC 2 Trust
Service Criteria (CC6.1, CC6.6, CC7.1, CC8.1).

This module consumes the same ComplianceDriftReport as drift --compliance,
but renders it as full-coverage evidence rather than just findings.
"""
