"""RepliMap Compliance Module.

Provides compliance-specific engines for sovereign cloud requirements:
- Data residency validation (NZ/AU region constraints)
- Cross-region data flow analysis
- Compliance framework selection
- compliance.tf registry mapping for compliant Terraform module sources
"""

from replimap.compliance.compliance_tf_registry import (
    COMPLIANCE_TF_FRAMEWORK_IDS,
    COMPLIANCE_TF_FRAMEWORKS,
    MODULE_SOURCE_MAPPINGS,
    SUPPORTED_MODULES,
    ComplianceTfFramework,
    ComplianceTfFrameworkId,
    ModuleSourceMapping,
    detect_module_key_from_source,
    get_compliant_source,
    get_original_source,
    is_compliance_tf_source,
    parse_compliance_tf_source,
)
from replimap.compliance.data_residency import (
    DataResidencyPolicy,
    DataResidencyValidator,
    DataResidencyViolation,
    ResidencyReport,
)

__all__ = [
    # Data Residency
    "DataResidencyPolicy",
    "DataResidencyValidator",
    "DataResidencyViolation",
    "ResidencyReport",
    # compliance.tf Registry
    "COMPLIANCE_TF_FRAMEWORK_IDS",
    "COMPLIANCE_TF_FRAMEWORKS",
    "SUPPORTED_MODULES",
    "MODULE_SOURCE_MAPPINGS",
    "ComplianceTfFramework",
    "ComplianceTfFrameworkId",
    "ModuleSourceMapping",
    "get_compliant_source",
    "get_original_source",
    "is_compliance_tf_source",
    "parse_compliance_tf_source",
    "detect_module_key_from_source",
]
