"""Data Residency Validation Engine.

Graph-aware engine that validates data stays within approved regions.
Critical for NZ/AU sovereign compliance (RBNZ BS11.7, NZISM, APRA CPS 234).

Detects:
- S3 cross-region replication to non-approved regions
- RDS read replicas outside approved regions
- CloudFront distributions with non-approved edge locations
- DynamoDB global tables in non-approved regions
- Aurora global clusters spanning non-approved regions
- Lambda@Edge and CloudFront functions (global execution)
- EFS cross-region replication

Usage:
    from replimap.compliance.data_residency import (
        DataResidencyValidator,
        DataResidencyPolicy,
    )

    policy = DataResidencyPolicy.nz_au()
    validator = DataResidencyValidator(policy)
    report = validator.validate(graph)

    for violation in report.violations:
        print(f"{violation.resource_id}: {violation.reason}")
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)


# Pre-defined region sets for common sovereignty requirements
NZ_AU_REGIONS = frozenset(
    {
        "ap-southeast-2",  # Sydney
        "ap-southeast-4",  # Melbourne
        # ap-southeast-5 reserved for Auckland when available
    }
)

AU_ONLY_REGIONS = frozenset(
    {
        "ap-southeast-2",  # Sydney
        "ap-southeast-4",  # Melbourne
    }
)

# CloudFront edge locations in NZ/AU (by prefix)
NZ_AU_EDGE_PREFIXES = frozenset(
    {
        "SYD",  # Sydney
        "MEL",  # Melbourne
        "PER",  # Perth
        "AKL",  # Auckland
    }
)


class ViolationSeverity(str, Enum):
    """Severity of a data residency violation."""

    CRITICAL = "critical"  # Data actively leaving approved region
    HIGH = "high"  # Configuration allows data to leave
    MEDIUM = "medium"  # Potential data residency risk
    INFO = "info"  # Advisory (e.g., global service usage)


@dataclass(frozen=True)
class DataResidencyPolicy:
    """Defines which regions are approved for data storage and processing.

    Attributes:
        name: Policy name (e.g., "NZ/AU Sovereignty")
        approved_regions: Set of approved AWS region identifiers
        approved_edge_prefixes: Approved CloudFront edge location prefixes
        allow_global_services: Whether to allow IAM, Route53, CloudFront
        description: Human-readable description of the policy
    """

    name: str
    approved_regions: frozenset[str]
    approved_edge_prefixes: frozenset[str] = field(default_factory=frozenset)
    allow_global_services: bool = True
    description: str = ""

    @classmethod
    def nz_au(cls) -> DataResidencyPolicy:
        """Create a policy for NZ/AU data sovereignty."""
        return cls(
            name="NZ/AU Data Sovereignty",
            approved_regions=NZ_AU_REGIONS,
            approved_edge_prefixes=NZ_AU_EDGE_PREFIXES,
            allow_global_services=True,
            description=(
                "Data must remain within Australia and New Zealand regions. "
                "Aligns with RBNZ BS11.7, NZISM ISM-0109, and APRA CPS 234."
            ),
        )

    @classmethod
    def au_only(cls) -> DataResidencyPolicy:
        """Create a policy for Australia-only data sovereignty."""
        return cls(
            name="Australia Only",
            approved_regions=AU_ONLY_REGIONS,
            approved_edge_prefixes=frozenset({"SYD", "MEL", "PER"}),
            allow_global_services=True,
            description="Data must remain within Australian regions only.",
        )

    @classmethod
    def custom(
        cls,
        name: str,
        regions: list[str],
        edge_prefixes: list[str] | None = None,
    ) -> DataResidencyPolicy:
        """Create a custom data residency policy."""
        return cls(
            name=name,
            approved_regions=frozenset(regions),
            approved_edge_prefixes=frozenset(edge_prefixes or []),
        )


@dataclass(frozen=True)
class DataResidencyViolation:
    """A detected data residency violation."""

    resource_id: str
    resource_type: str
    violation_type: str
    severity: ViolationSeverity
    source_region: str
    target_region: str
    reason: str
    remediation: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "resource_id": self.resource_id,
            "resource_type": self.resource_type,
            "violation_type": self.violation_type,
            "severity": self.severity.value,
            "source_region": self.source_region,
            "target_region": self.target_region,
            "reason": self.reason,
            "remediation": self.remediation,
        }


@dataclass
class ResidencyReport:
    """Result of data residency validation."""

    policy: DataResidencyPolicy
    violations: list[DataResidencyViolation] = field(default_factory=list)
    resources_checked: int = 0
    resources_compliant: int = 0

    @property
    def is_compliant(self) -> bool:
        """True if no violations found."""
        return len(self.violations) == 0

    @property
    def critical_count(self) -> int:
        return sum(
            1 for v in self.violations if v.severity == ViolationSeverity.CRITICAL
        )

    @property
    def high_count(self) -> int:
        return sum(1 for v in self.violations if v.severity == ViolationSeverity.HIGH)

    def to_dict(self) -> dict[str, Any]:
        return {
            "policy": self.policy.name,
            "policy_description": self.policy.description,
            "approved_regions": sorted(self.policy.approved_regions),
            "is_compliant": self.is_compliant,
            "resources_checked": self.resources_checked,
            "resources_compliant": self.resources_compliant,
            "violation_count": len(self.violations),
            "severity_breakdown": {
                "critical": self.critical_count,
                "high": self.high_count,
                "medium": sum(
                    1 for v in self.violations if v.severity == ViolationSeverity.MEDIUM
                ),
                "info": sum(
                    1 for v in self.violations if v.severity == ViolationSeverity.INFO
                ),
            },
            "violations": [v.to_dict() for v in self.violations],
        }


class DataResidencyValidator:
    """Validates that infrastructure data stays within approved regions.

    This engine walks the dependency graph looking for cross-region
    data flows that violate the configured residency policy.

    Args:
        policy: The data residency policy to enforce
    """

    def __init__(self, policy: DataResidencyPolicy) -> None:
        self._policy = policy

    def validate(self, graph: Any) -> ResidencyReport:
        """Validate a graph against the data residency policy.

        Args:
            graph: GraphEngine or GraphEngineAdapter with scanned resources

        Returns:
            ResidencyReport with any violations found
        """
        report = ResidencyReport(policy=self._policy)
        nodes = list(graph.nodes)
        report.resources_checked = len(nodes)

        violating_ids: set[str] = set()

        for node in nodes:
            node_violations = self._check_node(node)
            for v in node_violations:
                report.violations.append(v)
                violating_ids.add(v.resource_id)

        report.resources_compliant = report.resources_checked - len(violating_ids)
        return report

    def _check_node(self, node: Any) -> list[DataResidencyViolation]:
        """Check a single resource node for residency violations."""
        violations: list[DataResidencyViolation] = []
        resource_type = self._get_attr(node, "resource_type", "unknown")
        resource_id = self._get_attr(node, "id", "unknown")
        config = self._get_attr(node, "config", {})
        region = self._get_attr(node, "region", "")

        # Check if the resource itself is in a non-approved region
        if region and region not in self._policy.approved_regions:
            violations.append(
                DataResidencyViolation(
                    resource_id=resource_id,
                    resource_type=resource_type,
                    violation_type="resource_in_non_approved_region",
                    severity=ViolationSeverity.CRITICAL,
                    source_region=region,
                    target_region=region,
                    reason=f"Resource exists in non-approved region {region}",
                    remediation=f"Migrate resource to an approved region: {sorted(self._policy.approved_regions)}",
                )
            )

        # Type-specific checks
        checkers = {
            "aws_s3_bucket": self._check_s3_replication,
            "aws_db_instance": self._check_rds_replica,
            "aws_rds_cluster": self._check_aurora_global,
            "aws_dynamodb_table": self._check_dynamodb_global,
            "aws_cloudfront_distribution": self._check_cloudfront,
            "aws_efs_file_system": self._check_efs_replication,
            "aws_elasticache_global_replication_group": self._check_elasticache_global,
        }

        checker = checkers.get(resource_type)
        if checker:
            violations.extend(checker(resource_id, resource_type, config, region))

        return violations

    def _check_s3_replication(
        self, resource_id: str, resource_type: str, config: dict, region: str
    ) -> list[DataResidencyViolation]:
        """Check S3 cross-region replication destinations."""
        violations = []
        replication = config.get("replication_configuration") or config.get(
            "replication", {}
        )
        if not replication:
            return violations

        rules = replication.get("rules") or replication.get("rule", [])
        if isinstance(rules, dict):
            rules = [rules]

        for rule in rules:
            dest = rule.get("destination", {})
            dest_bucket = dest.get("bucket", "")
            dest_region = dest.get("region", "") or self._infer_region_from_arn(
                dest_bucket
            )

            if dest_region and dest_region not in self._policy.approved_regions:
                violations.append(
                    DataResidencyViolation(
                        resource_id=resource_id,
                        resource_type=resource_type,
                        violation_type="s3_cross_region_replication",
                        severity=ViolationSeverity.CRITICAL,
                        source_region=region,
                        target_region=dest_region,
                        reason=f"S3 bucket replicates to non-approved region {dest_region}",
                        remediation="Remove or reconfigure replication to target only approved regions",
                    )
                )

        return violations

    def _check_rds_replica(
        self, resource_id: str, resource_type: str, config: dict, region: str
    ) -> list[DataResidencyViolation]:
        """Check RDS read replica regions."""
        violations = []

        # Check source ARN for cross-region replica
        source_arn = config.get("read_replica_source_db_instance_identifier", "")
        if source_arn:
            source_region = self._infer_region_from_arn(source_arn)
            if source_region and source_region not in self._policy.approved_regions:
                violations.append(
                    DataResidencyViolation(
                        resource_id=resource_id,
                        resource_type=resource_type,
                        violation_type="rds_cross_region_replica",
                        severity=ViolationSeverity.CRITICAL,
                        source_region=source_region,
                        target_region=region,
                        reason=f"RDS replica sources data from non-approved region {source_region}",
                        remediation="Ensure all RDS replicas are within approved regions",
                    )
                )

        return violations

    def _check_aurora_global(
        self, resource_id: str, resource_type: str, config: dict, region: str
    ) -> list[DataResidencyViolation]:
        """Check Aurora global cluster member regions."""
        violations = []

        global_cluster = config.get("global_cluster_identifier", "")
        if not global_cluster:
            return violations

        members = config.get("global_cluster_members", [])
        for member in members:
            member_arn = member.get("db_cluster_arn", "")
            member_region = self._infer_region_from_arn(member_arn)
            if member_region and member_region not in self._policy.approved_regions:
                violations.append(
                    DataResidencyViolation(
                        resource_id=resource_id,
                        resource_type=resource_type,
                        violation_type="aurora_global_cluster",
                        severity=ViolationSeverity.CRITICAL,
                        source_region=region,
                        target_region=member_region,
                        reason=f"Aurora global cluster spans non-approved region {member_region}",
                        remediation="Remove global cluster members in non-approved regions",
                    )
                )

        return violations

    def _check_dynamodb_global(
        self, resource_id: str, resource_type: str, config: dict, region: str
    ) -> list[DataResidencyViolation]:
        """Check DynamoDB global table replica regions."""
        violations = []

        replicas = config.get("replicas", []) or config.get("replica", [])
        for replica in replicas:
            replica_region = replica.get("region_name", "") or replica.get("region", "")
            if replica_region and replica_region not in self._policy.approved_regions:
                violations.append(
                    DataResidencyViolation(
                        resource_id=resource_id,
                        resource_type=resource_type,
                        violation_type="dynamodb_global_table",
                        severity=ViolationSeverity.CRITICAL,
                        source_region=region,
                        target_region=replica_region,
                        reason=f"DynamoDB global table replicates to non-approved region {replica_region}",
                        remediation="Remove replicas in non-approved regions",
                    )
                )

        return violations

    def _check_cloudfront(
        self, resource_id: str, resource_type: str, config: dict, region: str
    ) -> list[DataResidencyViolation]:
        """Check CloudFront distribution geographic restrictions."""
        violations = []

        # CloudFront is inherently global — check for geo restrictions
        restrictions = config.get("restrictions", {})
        geo = restrictions.get("geo_restriction", {})
        restriction_type = geo.get("restriction_type", "none")

        if restriction_type == "none":
            # No geo restriction means content served globally
            violations.append(
                DataResidencyViolation(
                    resource_id=resource_id,
                    resource_type=resource_type,
                    violation_type="cloudfront_no_geo_restriction",
                    severity=ViolationSeverity.HIGH,
                    source_region="global",
                    target_region="global",
                    reason="CloudFront distribution has no geographic restriction — content served from all edge locations worldwide",
                    remediation=(
                        "Add geo_restriction with restriction_type='whitelist' "
                        "limiting to NZ (NZ) and AU (AU) country codes"
                    ),
                )
            )

        return violations

    def _check_efs_replication(
        self, resource_id: str, resource_type: str, config: dict, region: str
    ) -> list[DataResidencyViolation]:
        """Check EFS cross-region replication."""
        violations = []

        replication = config.get("replication_configuration", {})
        destinations = replication.get("destinations", [])
        for dest in destinations:
            dest_region = dest.get("region", "")
            if dest_region and dest_region not in self._policy.approved_regions:
                violations.append(
                    DataResidencyViolation(
                        resource_id=resource_id,
                        resource_type=resource_type,
                        violation_type="efs_cross_region_replication",
                        severity=ViolationSeverity.CRITICAL,
                        source_region=region,
                        target_region=dest_region,
                        reason=f"EFS replicates to non-approved region {dest_region}",
                        remediation="Reconfigure replication to target only approved regions",
                    )
                )

        return violations

    def _check_elasticache_global(
        self, resource_id: str, resource_type: str, config: dict, region: str
    ) -> list[DataResidencyViolation]:
        """Check ElastiCache global replication group regions."""
        violations = []

        members = config.get("members", [])
        for member in members:
            member_region = member.get("replication_group_region", "")
            if member_region and member_region not in self._policy.approved_regions:
                violations.append(
                    DataResidencyViolation(
                        resource_id=resource_id,
                        resource_type=resource_type,
                        violation_type="elasticache_global_replication",
                        severity=ViolationSeverity.CRITICAL,
                        source_region=region,
                        target_region=member_region,
                        reason=f"ElastiCache global datastore spans non-approved region {member_region}",
                        remediation="Remove members in non-approved regions",
                    )
                )

        return violations

    @staticmethod
    def _infer_region_from_arn(arn: str) -> str:
        """Extract region from an ARN string."""
        if not arn or not arn.startswith("arn:"):
            return ""
        parts = arn.split(":")
        if len(parts) >= 4:
            return parts[3]
        return ""

    @staticmethod
    def _get_attr(node: Any, attr: str, default: Any = None) -> Any:
        """Safely get attribute from a graph node (dict or object)."""
        if isinstance(node, dict):
            return node.get(attr, default)
        return getattr(node, attr, default)
