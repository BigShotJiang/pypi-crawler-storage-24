"""Compliance drift report formatters.

Generates markdown audit evidence reports from ComplianceDriftReport.
"""

from __future__ import annotations

from pathlib import Path

from replimap.compliance.drift.mapping import (
    ComplianceDriftFinding,
    ComplianceDriftReport,
)

DATA_SOVEREIGNTY_NOTICE = (
    "DATA SOVEREIGNTY: RepliMap drift runs entirely on your local machine. "
    "No state data, credentials, or results are sent to any external service."
)

_SEVERITY_ICON: dict[str, str] = {
    "critical": "\U0001f534",  # 🔴
    "high": "\U0001f7e1",  # 🟡
    "medium": "\U0001f535",  # 🔵
    "low": "\u26aa",  # ⚪
}

_REPLIMAP_VERSION = "3.8.0"


def to_markdown(report: ComplianceDriftReport) -> str:
    """Generate a markdown compliance audit evidence report."""
    lines: list[str] = []
    summary = report.summary()

    lines.append("# Compliance Drift Report")
    lines.append("")

    # ── Metadata table ─────────────────────────────────────────────────
    lines.append("| Field | Value |")
    lines.append("|-------|-------|")
    lines.append(
        f"| Generated | {report.scanned_at.strftime('%Y-%m-%d %H:%M:%S UTC')} |"
    )
    lines.append(f"| Tool | RepliMap v{_REPLIMAP_VERSION} |")
    lines.append(f"| Region | {report.region} |")
    lines.append(f"| State File | {report.state_file} |")
    lines.append(f"| Framework | {report.framework} |")
    lines.append("")

    lines.append(f"> **{DATA_SOVEREIGNTY_NOTICE}**")
    lines.append("")

    # ── Executive Summary ──────────────────────────────────────────────
    lines.append("## Executive Summary")
    lines.append("")
    lines.append(
        f"{report.total_resources_scanned} resources scanned. "
        f"{report.compliance_relevant_drifts} compliance-relevant drift findings."
    )
    lines.append("")

    lines.append("| Severity | Count |")
    lines.append("|----------|-------|")
    lines.append(f"| {_SEVERITY_ICON['critical']} Critical | {summary['critical']} |")
    lines.append(f"| {_SEVERITY_ICON['high']} High | {summary['high']} |")
    lines.append(f"| {_SEVERITY_ICON['medium']} Medium | {summary['medium']} |")
    lines.append(f"| {_SEVERITY_ICON['low']} Low | {summary['low']} |")
    lines.append(f"| Exempted | {summary['exempted']} |")
    lines.append("")

    # ── Findings grouped by severity ───────────────────────────────────
    if report.findings:
        for severity in ("critical", "high", "medium", "low"):
            severity_findings = [f for f in report.findings if f.severity == severity]
            if not severity_findings:
                continue
            icon = _SEVERITY_ICON.get(severity, "")
            lines.append(f"## {icon} {severity.title()} Findings")
            lines.append("")
            for finding in severity_findings:
                lines.extend(_render_finding(finding))
    else:
        lines.append("## Findings")
        lines.append("")
        lines.append("No compliance drift detected.")
        lines.append("")

    # ── Accepted Risks (exempted findings) ─────────────────────────────
    if report.exempted:
        lines.append("## Accepted Risks")
        lines.append("")
        lines.append("| Resource | Attribute | Reason | Approved By | Expires |")
        lines.append("|----------|-----------|--------|-------------|---------|")
        for f in report.exempted:
            reason = (
                _escape_table_cell(f.exemption_reason) if f.exemption_reason else "-"
            )
            lines.append(f"| `{f.tf_address}` | `{f.attribute}` | {reason} | - | - |")
        lines.append("")

    # ── Expired Exemptions ─────────────────────────────────────────────
    if report.expired_exemptions:
        lines.append("## Expired Exemptions \u26a0\ufe0f")
        lines.append("")
        lines.append(
            "> These exemptions have expired and the findings are now active. "
            "Renew the exemption or remediate the finding."
        )
        lines.append("")
        lines.append("| Resource | Attribute | Reason | Expired On |")
        lines.append("|----------|-----------|--------|------------|")
        for f in report.expired_exemptions:
            reason = (
                _escape_table_cell(f.exemption_reason) if f.exemption_reason else "-"
            )
            lines.append(f"| `{f.tf_address}` | `{f.attribute}` | {reason} | - |")
        lines.append("")

    # ── Controls reference ─────────────────────────────────────────────
    controls_seen: dict[str, set[str]] = {}
    for finding in report.findings:
        for control in finding.controls:
            fw = control.framework
            if fw not in controls_seen:
                controls_seen[fw] = set()
            controls_seen[fw].add(f"{control.control_id} — {control.control_name}")

    if controls_seen:
        lines.append("## Controls Reference")
        lines.append("")
        for fw in sorted(controls_seen.keys()):
            lines.append(f"### {fw}")
            lines.append("")
            for ctrl in sorted(controls_seen[fw]):
                lines.append(f"- {ctrl}")
            lines.append("")

    # ── Footer ─────────────────────────────────────────────────────────
    lines.append("---")
    lines.append("")
    lines.append(
        f"*Generated by RepliMap v{_REPLIMAP_VERSION} | "
        f"{report.scanned_at.strftime('%Y-%m-%d %H:%M:%S UTC')} | "
        f"{DATA_SOVEREIGNTY_NOTICE}*"
    )
    lines.append("")

    return "\n".join(lines)


def _render_finding(finding: ComplianceDriftFinding) -> list[str]:
    """Render a single finding as markdown."""
    lines: list[str] = []
    icon = _SEVERITY_ICON.get(finding.severity, "")

    lines.append(f"### {finding.tf_address}")
    lines.append("")
    lines.append(f"- **Rule**: {finding.rule.description}")
    lines.append(f"- **Attribute**: `{finding.attribute}`")
    lines.append(f"- **Expected**: `{_format_value(finding.expected)}`")
    lines.append(f"- **Actual**: `{_format_value(finding.actual)}`")
    lines.append(f"- **Severity**: {icon} {finding.severity.title()}")

    controls_str = ", ".join(f"{c.framework} {c.control_id}" for c in finding.controls)
    lines.append(f"- **Controls**: {controls_str}")
    lines.append(f"- **Remediation**: {finding.remediation}")
    lines.append("")

    if finding.exemption_expired:
        lines.append(f"> **Expired exemption:** {finding.exemption_reason}")
        lines.append("")

    lines.append("---")
    lines.append("")

    return lines


def _escape_table_cell(value: str) -> str:
    """Escape characters that break markdown table formatting."""
    return value.replace("|", "\\|").replace("\n", " ")


def _format_value(value: object) -> str:
    """Format a value for markdown display, truncating long values."""
    s = repr(value)
    if len(s) > 120:
        return s[:117] + "..."
    return s


def write_markdown_report(report: ComplianceDriftReport, output_path: Path) -> Path:
    """Write a markdown compliance report to a file."""
    content = to_markdown(report)
    output_path.write_text(content)
    return output_path
