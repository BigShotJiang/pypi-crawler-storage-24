"""Risk exemption manager for compliance drift findings.

Reads .replimap-ignore.yml to apply approved exemptions.
Expired exemptions are automatically restored as active findings.

Format:
    exceptions:
      - resource: aws_s3_bucket.public_website
        attribute: public_access_block
        reason: "Public website bucket, approved by CISO 2026-01-15"
        approved_by: "jane.smith@acme.com"
        expires: "2026-12-31"
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, replace
from datetime import date, datetime
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class ExemptionConfig:
    """A single compliance exemption entry."""

    resource: str  # TF address: "aws_s3_bucket.public_website"
    attribute: str  # "public_access_block"
    reason: str
    approved_by: str
    expires: date | None  # None = never expires

    @property
    def is_expired(self) -> bool:
        if self.expires is None:
            return False
        return date.today() > self.expires


class ExemptionManager:
    """Load and apply compliance exemptions from YAML config.

    Exemptions match on (tf_address, attribute) or (resource_type.resource_name, attribute).
    Expired exemptions are tracked separately so they appear in reports.
    """

    def __init__(self, exemptions: list[ExemptionConfig] | None = None) -> None:
        self._exemptions = exemptions or []
        # Build lookup index: (resource, attribute) → ExemptionConfig
        self._index: dict[tuple[str, str], ExemptionConfig] = {
            (e.resource, e.attribute): e for e in self._exemptions
        }

    @classmethod
    def from_file(cls, path: Path) -> ExemptionManager:
        """Load exemptions from a YAML file.

        Args:
            path: Path to .replimap-ignore.yml

        Returns:
            ExemptionManager with loaded exemptions

        Raises:
            FileNotFoundError: If the file doesn't exist
        """
        try:
            import yaml
        except ImportError as e:
            raise ImportError(
                "PyYAML is required for exemption files. "
                "Install with: pip install pyyaml"
            ) from e

        content = path.read_text()
        data = yaml.safe_load(content)

        if not data or "exceptions" not in data:
            logger.warning("No exceptions found in %s", path)
            return cls([])

        exemptions = []
        for entry in data["exceptions"]:
            expires = _parse_date(entry.get("expires"))
            exemptions.append(
                ExemptionConfig(
                    resource=entry["resource"],
                    attribute=entry.get("attribute", ""),
                    reason=entry.get("reason", ""),
                    approved_by=entry.get("approved_by", ""),
                    expires=expires,
                )
            )

        logger.info("Loaded %d exemptions from %s", len(exemptions), path)
        return cls(exemptions)

    @classmethod
    def empty(cls) -> ExemptionManager:
        """Create an ExemptionManager with no exemptions."""
        return cls([])

    def apply(self, report: Any) -> Any:
        """Apply exemptions to a ComplianceDriftReport.

        Moves matching findings from findings → exempted (if not expired)
        or findings → expired_exemptions (if expired).

        Modifies the report in place and returns it.

        Args:
            report: ComplianceDriftReport to process

        Returns:
            The same report with exemptions applied
        """
        if not self._exemptions:
            return report

        active_findings = []
        for finding in report.findings:
            exemption = self._find_exemption(finding.tf_address, finding.attribute)

            if exemption is None:
                active_findings.append(finding)
                continue

            if exemption.is_expired:
                expired_finding = replace(
                    finding,
                    exemption_expired=True,
                    exemption_reason=exemption.reason,
                )
                report.expired_exemptions.append(expired_finding)
                # Expired exemptions go back to active findings
                active_findings.append(expired_finding)
                logger.info(
                    "Expired exemption for %s.%s (expired %s)",
                    finding.tf_address,
                    finding.attribute,
                    exemption.expires,
                )
            else:
                exempted_finding = replace(
                    finding,
                    exempted=True,
                    exemption_reason=exemption.reason,
                )
                report.exempted.append(exempted_finding)
                logger.info(
                    "Exempted %s.%s: %s",
                    finding.tf_address,
                    finding.attribute,
                    exemption.reason,
                )

        report.findings = active_findings
        # Update the drift count to reflect exemptions
        report.compliance_relevant_drifts = len(active_findings)
        return report

    def _find_exemption(
        self, tf_address: str, attribute: str
    ) -> ExemptionConfig | None:
        """Find a matching exemption for a finding.

        Matches on:
        1. Exact (tf_address, attribute)
        2. (tf_address, "") — exempts all attributes for that resource
        """
        # Exact match
        match = self._index.get((tf_address, attribute))
        if match is not None:
            return match

        # Resource-level exemption (all attributes)
        match = self._index.get((tf_address, ""))
        if match is not None:
            return match

        return None

    @property
    def exemption_count(self) -> int:
        return len(self._exemptions)


def _parse_date(value: Any) -> date | None:
    """Parse a date from YAML (may be string, date, or datetime)."""
    if value is None:
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    if isinstance(value, str):
        return date.fromisoformat(value)
    return None
