"""Compliance mapping engine.

Takes a standard DriftReport from the existing drift engine and produces
a ComplianceDriftReport by:
1. Filtering to compliance-relevant attribute diffs
2. Mapping each diff to compliance framework controls
3. Assigning compliance-specific severity (may differ from generic drift severity)
4. Checking actual AWS state against compliance requirements (not just diff direction)
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

from replimap.compliance.drift.rules import (
    COMPLIANCE_RULES,
    ComplianceControl,
    ComplianceRule,
    get_rules_for_framework,
)
from replimap.drift.models import AttributeDiff, DriftReport, DriftType

logger = logging.getLogger(__name__)

# Ports considered sensitive — unrestricted access (0.0.0.0/0) on these is critical
_SENSITIVE_PORTS: frozenset[int] = frozenset({22, 3389, 3306, 5432, 6379, 27017})

# Ports considered safe for public access (web servers)
_WEB_PORTS: frozenset[int] = frozenset({80, 443})


@dataclass(frozen=True)
class ComplianceDriftFinding:
    """A single compliance-relevant drift finding."""

    rule: ComplianceRule
    resource_type: str
    resource_id: str
    resource_name: str
    tf_address: str
    attribute: str
    expected: Any
    actual: Any
    controls: tuple[ComplianceControl, ...]
    severity: str  # From ComplianceRule, not DriftSeverity
    remediation: str
    exempted: bool = False
    exemption_reason: str = ""
    exemption_expired: bool = False


@dataclass
class ComplianceDriftReport:
    """Complete compliance drift report.

    Produced by ComplianceMappingEngine.map() from a standard DriftReport.
    """

    # Framework filter (or "all")
    framework: str = "all"

    # Counts
    total_resources_scanned: int = 0
    compliance_relevant_drifts: int = 0

    # Findings
    findings: list[ComplianceDriftFinding] = field(default_factory=list)
    exempted: list[ComplianceDriftFinding] = field(default_factory=list)
    expired_exemptions: list[ComplianceDriftFinding] = field(default_factory=list)

    # Metadata (carried from source DriftReport)
    state_file: str = ""
    region: str = ""
    scanned_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    scan_duration_seconds: float = 0.0

    @property
    def has_findings(self) -> bool:
        return len(self.findings) > 0

    @property
    def critical_findings(self) -> list[ComplianceDriftFinding]:
        return [f for f in self.findings if f.severity == "critical"]

    @property
    def high_findings(self) -> list[ComplianceDriftFinding]:
        return [f for f in self.findings if f.severity == "high"]

    @property
    def has_critical_or_high(self) -> bool:
        return any(f.severity in ("critical", "high") for f in self.findings)

    def summary(self) -> dict[str, int]:
        """Summary counts by severity."""
        counts: dict[str, int] = {
            "critical": 0,
            "high": 0,
            "medium": 0,
            "low": 0,
        }
        for f in self.findings:
            counts[f.severity] = counts.get(f.severity, 0) + 1
        return {
            **counts,
            "total": len(self.findings),
            "exempted": len(self.exempted),
            "expired_exemptions": len(self.expired_exemptions),
        }

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dict for JSON output."""
        return {
            "framework": self.framework,
            "total_resources_scanned": self.total_resources_scanned,
            "compliance_relevant_drifts": self.compliance_relevant_drifts,
            "summary": self.summary(),
            "findings": [
                {
                    "rule_id": f.rule.rule_id,
                    "severity": f.severity,
                    "resource_type": f.resource_type,
                    "resource_id": f.resource_id,
                    "resource_name": f.resource_name,
                    "tf_address": f.tf_address,
                    "attribute": f.attribute,
                    "expected": f.expected,
                    "actual": f.actual,
                    "description": f.rule.description,
                    "remediation": f.remediation,
                    "expired_exemption": f.exemption_expired or None,
                    "controls": [
                        {
                            "framework": c.framework,
                            "control_id": c.control_id,
                            "control_name": c.control_name,
                        }
                        for c in f.controls
                    ],
                }
                for f in self.findings
                if not f.exemption_expired
            ],
            "exempted": [
                {
                    "rule_id": f.rule.rule_id,
                    "resource_id": f.resource_id,
                    "attribute": f.attribute,
                    "reason": f.exemption_reason,
                }
                for f in self.exempted
            ],
            "expired_exemptions": [
                {
                    "rule_id": f.rule.rule_id,
                    "resource_id": f.resource_id,
                    "attribute": f.attribute,
                    "reason": f.exemption_reason,
                }
                for f in self.expired_exemptions
            ],
            "metadata": {
                "state_file": self.state_file,
                "region": self.region,
                "scanned_at": self.scanned_at.isoformat(),
                "scan_duration_seconds": self.scan_duration_seconds,
            },
        }


class ComplianceMappingEngine:
    """Maps standard DriftReport findings to compliance controls.

    This is a post-processing overlay: it does NOT modify the DriftReport
    or the drift engine. It consumes the report and filters/enriches it.
    """

    def __init__(self, framework: str = "all") -> None:
        self.framework = framework

        if framework == "all":
            self._rules = COMPLIANCE_RULES
        else:
            self._rules = tuple(get_rules_for_framework(framework))

        # Build lookup index for active rules
        self._rules_by_attr: dict[tuple[str, str], ComplianceRule] = {
            (r.resource_type, r.attribute): r for r in self._rules
        }

    def map(self, drift_report: DriftReport) -> ComplianceDriftReport:
        """Map a DriftReport to a ComplianceDriftReport.

        For MODIFIED resources: checks each AttributeDiff against compliance
        rules, applying check_type-specific violation logic.

        For REMOVED resources: generates critical findings for all applicable
        rules on that resource type.
        """
        findings: list[ComplianceDriftFinding] = []

        for resource_drift in drift_report.drifts:
            if resource_drift.drift_type == DriftType.UNCHANGED:
                continue

            # REMOVED resource = critical compliance event
            if resource_drift.drift_type == DriftType.REMOVED:
                removal_findings = self._create_removal_findings(resource_drift)
                findings.extend(removal_findings)
                continue

            # Only MODIFIED is compliance-relevant for attribute checks
            if resource_drift.drift_type != DriftType.MODIFIED:
                continue

            for diff in resource_drift.diffs:
                rule = self._rules_by_attr.get(
                    (resource_drift.resource_type, diff.attribute)
                )
                if rule is None:
                    continue

                # Check if this is actually a violation
                if not self._is_violation(rule, diff):
                    logger.debug(
                        "Skipping %s.%s: actual value is compliant",
                        resource_drift.tf_address,
                        diff.attribute,
                    )
                    continue

                # Filter controls to selected framework
                if self.framework == "all":
                    controls = rule.controls
                else:
                    controls = tuple(
                        c for c in rule.controls if c.framework == self.framework
                    )
                    if not controls:
                        continue

                finding = ComplianceDriftFinding(
                    rule=rule,
                    resource_type=resource_drift.resource_type,
                    resource_id=resource_drift.resource_id,
                    resource_name=resource_drift.resource_name,
                    tf_address=resource_drift.tf_address,
                    attribute=diff.attribute,
                    expected=diff.expected,
                    actual=diff.actual,
                    controls=controls,
                    severity=rule.severity,
                    remediation=rule.remediation,
                )
                findings.append(finding)

        # Sort: critical first, then high, medium, low
        severity_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
        findings.sort(key=lambda f: severity_order.get(f.severity, 99))

        return ComplianceDriftReport(
            framework=self.framework,
            total_resources_scanned=drift_report.total_resources,
            compliance_relevant_drifts=len(findings),
            findings=findings,
            state_file=drift_report.state_file,
            region=drift_report.region,
            scanned_at=drift_report.scanned_at,
            scan_duration_seconds=drift_report.scan_duration_seconds,
        )

    def _is_violation(self, rule: ComplianceRule, diff: AttributeDiff) -> bool:
        """Determine whether an attribute diff constitutes a compliance violation.

        Checks the ACTUAL AWS state (diff.actual), not the diff direction.
        A drift from non-compliant→compliant is NOT a violation.
        """
        if rule.check_type == "drift":
            # Any change to the attribute is a violation
            return True

        if rule.check_type == "value":
            # Violation = actual value doesn't match expected compliant value
            return diff.actual != rule.expected_compliant

        if rule.check_type == "min_value":
            # Violation = actual value is below the minimum threshold
            try:
                return _to_number(diff.actual) < rule.expected_compliant
            except (TypeError, ValueError):
                # Can't compare — treat as violation (fail-safe)
                logger.warning(
                    "Cannot compare %r < %r for rule %s",
                    diff.actual,
                    rule.expected_compliant,
                    rule.rule_id,
                )
                return True

        if rule.check_type == "sg_ingress":
            return _has_unrestricted_sensitive_ingress(diff.actual)

        logger.warning(
            "Unknown check_type %r for rule %s", rule.check_type, rule.rule_id
        )
        return True  # Fail-safe: unknown check_type treated as violation

    def _create_removal_findings(
        self, resource_drift: Any
    ) -> list[ComplianceDriftFinding]:
        """Generate compliance findings for a REMOVED resource.

        A deleted resource violates all applicable compliance rules for its type.
        Uses the highest-severity applicable rule.
        """
        applicable_rules = [
            r for r in self._rules if r.resource_type == resource_drift.resource_type
        ]
        if not applicable_rules:
            return []

        # Pick the highest-severity rule for the removal finding
        severity_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
        best_rule = min(
            applicable_rules, key=lambda r: severity_order.get(r.severity, 99)
        )

        # Collect all controls from all applicable rules
        all_controls: list[ComplianceControl] = []
        seen: set[tuple[str, str]] = set()
        for rule in applicable_rules:
            for ctrl in rule.controls:
                key = (ctrl.framework, ctrl.control_id)
                if key not in seen:
                    seen.add(key)
                    if self.framework == "all" or ctrl.framework == self.framework:
                        all_controls.append(ctrl)

        if not all_controls:
            return []

        return [
            ComplianceDriftFinding(
                rule=best_rule,
                resource_type=resource_drift.resource_type,
                resource_id=resource_drift.resource_id,
                resource_name=resource_drift.resource_name,
                tf_address=resource_drift.tf_address,
                attribute="(resource deleted)",
                expected="exists",
                actual="REMOVED",
                controls=tuple(all_controls),
                severity="critical",
                remediation=(
                    f"Resource {resource_drift.tf_address} was deleted outside Terraform. "
                    "Investigate unauthorized deletion. Restore from backup if needed."
                ),
            )
        ]


def _to_number(value: Any) -> int | float:
    """Coerce a value to a number for min_value comparison."""
    if isinstance(value, bool):
        raise TypeError("Cannot convert bool to number")
    if isinstance(value, (int, float)):
        return value
    if isinstance(value, str):
        try:
            return int(value)
        except ValueError:
            return float(value)
    raise TypeError(f"Cannot convert {type(value).__name__} to number")


def _has_unrestricted_sensitive_ingress(actual: Any) -> bool:
    """Check if security group ingress rules allow unrestricted access on sensitive ports.

    Parses the ingress rules list from the SG scanner output format:
    [{"protocol": "tcp", "from_port": 22, "to_port": 22, "cidr_blocks": ["0.0.0.0/0"]}]

    Returns True (violation) if:
    - Any rule has 0.0.0.0/0 or ::/0 on a sensitive port (22, 3389, 3306, 5432, 6379, 27017)
    - Any rule has 0.0.0.0/0 or ::/0 with from_port=0, to_port=65535 (all ports)
    Returns False (no violation) if:
    - Only 80/443 are exposed to 0.0.0.0/0 (web server scenario)
    - No unrestricted access at all
    """
    if not isinstance(actual, list):
        return True  # Can't parse — fail-safe

    for rule in actual:
        if not isinstance(rule, dict):
            continue

        cidrs = rule.get("cidr_blocks", [])
        ipv6_cidrs = rule.get("ipv6_cidr_blocks", [])
        all_cidrs = (cidrs or []) + (ipv6_cidrs or [])

        has_unrestricted = any(c in ("0.0.0.0/0", "::/0") for c in all_cidrs)
        if not has_unrestricted:
            continue

        # Protocol -1 means all traffic — check first
        if rule.get("protocol") in ("-1", "all"):
            return True

        from_port = rule.get("from_port", 0)
        to_port = rule.get("to_port", 0)

        # All ports open (handles 0/65535 and -1/-1 representations)
        if from_port <= 0 and to_port >= 65535:
            return True

        # Check if the port range overlaps with sensitive ports
        if _port_range_overlaps_sensitive(from_port, to_port):
            return True

    return False


def _port_range_overlaps_sensitive(from_port: int, to_port: int) -> bool:
    """Check if a port range includes any sensitive ports.

    Returns True if the range [from_port, to_port] overlaps with any
    port in _SENSITIVE_PORTS (22, 3389, 3306, 5432, 6379, 27017).
    Web-only ranges (80, 443) return False.
    """
    return any(from_port <= port <= to_port for port in _SENSITIVE_PORTS)
