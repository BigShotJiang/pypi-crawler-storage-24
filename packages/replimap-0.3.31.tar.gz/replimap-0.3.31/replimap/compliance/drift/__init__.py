"""Compliance drift detection overlay for RepliMap.

Post-processes standard DriftReport output from the existing drift engine,
filtering to compliance-relevant attributes and mapping findings to
framework controls (SOC 2, PCI DSS, HIPAA, etc.).

Architecture:
    1. Existing DriftEngine.detect() produces DriftReport (unchanged)
    2. ComplianceMappingEngine.map() filters + maps → ComplianceDriftReport
    3. ExemptionManager.apply() removes exempted findings
    4. Report formatters output markdown/json/console

This module does NOT modify existing drift engine behavior.
"""
