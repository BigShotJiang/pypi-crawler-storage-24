"""Compliance rules mapping drift attributes to framework controls.

Each ComplianceRule ties a specific resource attribute (matching a key in
drift/comparator.py COMPARABLE_ATTRIBUTES) to one or more compliance
framework controls (SOC 2, PCI DSS, HIPAA, etc.).

Phase 1 scope: only attributes already in COMPARABLE_ATTRIBUTES.
Phase 2 will add EKS, DynamoDB, CloudTrail, S3 Public Access Block.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal


@dataclass(frozen=True)
class ComplianceControl:
    """A specific control within a compliance framework."""

    framework: str  # "SOC 2", "PCI DSS", "HIPAA"
    control_id: str  # "CC6.1", "3.4.1", "§164.312(a)(2)(iv)"
    control_name: str  # Human-readable control name


@dataclass(frozen=True)
class ComplianceRule:
    """Maps a resource attribute drift to compliance controls.

    The ``attribute`` field MUST match a key in COMPARABLE_ATTRIBUTES
    from drift/comparator.py exactly.

    check_type controls how violations are detected:
    - "drift": any change to the attribute is a violation
    - "value": actual != expected_compliant is a violation
    - "min_value": actual < expected_compliant is a violation
    - "sg_ingress": special parser for security group ingress rules
    """

    rule_id: str  # Unique ID: "s3-encryption-enabled"
    resource_type: str  # "aws_s3_bucket" — matches TFResource.type
    attribute: str  # Key from COMPARABLE_ATTRIBUTES
    check_type: Literal["drift", "value", "min_value", "sg_ingress"]
    expected_compliant: Any  # Expected compliant value (for value/min_value checks)
    severity: Literal["critical", "high", "medium", "low"]
    controls: tuple[ComplianceControl, ...]
    description: str
    remediation: str


# =============================================================================
# Compliance Controls (reused across rules)
# =============================================================================

# SOC 2 Trust Services Criteria
_SOC2_CC6_1 = ComplianceControl(
    framework="SOC 2",
    control_id="CC6.1",
    control_name="Logical and Physical Access Controls",
)
_SOC2_CC6_6 = ComplianceControl(
    framework="SOC 2",
    control_id="CC6.6",
    control_name="Restrictions on System Access",
)
_SOC2_CC7_1 = ComplianceControl(
    framework="SOC 2",
    control_id="CC7.1",
    control_name="Detection and Monitoring",
)
_SOC2_CC8_1 = ComplianceControl(
    framework="SOC 2",
    control_id="CC8.1",
    control_name="Change Management",
)

# PCI DSS v4.0
_PCI_1_2_1 = ComplianceControl(
    framework="PCI DSS",
    control_id="1.2.1",
    control_name="Restrict inbound/outbound traffic",
)
_PCI_1_3 = ComplianceControl(
    framework="PCI DSS",
    control_id="1.3",
    control_name="Prohibit direct public access",
)
_PCI_3_4 = ComplianceControl(
    framework="PCI DSS",
    control_id="3.4",
    control_name="Render PAN unreadable anywhere it is stored",
)
_PCI_3_4_1 = ComplianceControl(
    framework="PCI DSS",
    control_id="3.4.1",
    control_name="Disk-level or partition-level encryption",
)
_PCI_10_1 = ComplianceControl(
    framework="PCI DSS",
    control_id="10.1",
    control_name="Audit trails for system components",
)

# HIPAA
_HIPAA_ENCRYPTION = ComplianceControl(
    framework="HIPAA",
    control_id="§164.312(a)(2)(iv)",
    control_name="Encryption and Decryption",
)
_HIPAA_AUDIT = ComplianceControl(
    framework="HIPAA",
    control_id="§164.312(b)",
    control_name="Audit Controls",
)
_HIPAA_TRANSMISSION = ComplianceControl(
    framework="HIPAA",
    control_id="§164.312(e)(1)",
    control_name="Transmission Security",
)


# =============================================================================
# Phase 1 Compliance Rules (12 rules, aligned with COMPARABLE_ATTRIBUTES)
# =============================================================================

COMPLIANCE_RULES: tuple[ComplianceRule, ...] = (
    # ── Encryption (compliance severity: critical) ─────────────────────
    ComplianceRule(
        rule_id="s3-encryption-enabled",
        resource_type="aws_s3_bucket",
        attribute="server_side_encryption_configuration",
        check_type="drift",
        expected_compliant=None,
        severity="critical",
        controls=(_SOC2_CC6_1, _PCI_3_4_1, _HIPAA_ENCRYPTION),
        description="S3 bucket must have server-side encryption enabled",
        remediation=(
            "Enable default encryption on the S3 bucket using AES-256 or aws:kms. "
            "Apply via: aws s3api put-bucket-encryption --bucket BUCKET "
            "--server-side-encryption-configuration '...'"
        ),
    ),
    ComplianceRule(
        rule_id="rds-encryption-enabled",
        resource_type="aws_db_instance",
        attribute="storage_encrypted",
        check_type="value",
        expected_compliant=True,
        severity="critical",
        controls=(_SOC2_CC6_1, _PCI_3_4, _HIPAA_ENCRYPTION),
        description="RDS instance must have storage encryption enabled",
        remediation=(
            "Storage encryption can only be enabled at creation time. "
            "To encrypt an existing instance: create encrypted snapshot, "
            "restore from snapshot, update DNS/connection strings."
        ),
    ),
    ComplianceRule(
        rule_id="kms-key-rotation-enabled",
        resource_type="aws_kms_key",
        attribute="enable_key_rotation",
        check_type="value",
        expected_compliant=True,
        severity="high",
        controls=(_SOC2_CC6_1,),
        description="KMS customer-managed keys must have automatic key rotation enabled",
        remediation=(
            "Enable key rotation: aws kms enable-key-rotation --key-id KEY_ID"
        ),
    ),
    # ── Access Control (compliance severity: critical) ─────────────────
    ComplianceRule(
        rule_id="s3-no-public-acl",
        resource_type="aws_s3_bucket",
        attribute="acl",
        check_type="value",
        expected_compliant="private",
        severity="critical",
        controls=(_SOC2_CC6_6, _PCI_1_3, _HIPAA_TRANSMISSION),
        description=(
            "S3 bucket must not have public ACL "
            "(public-read or public-read-write is a compliance violation)"
        ),
        remediation=(
            "Set ACL to private: aws s3api put-bucket-acl --bucket BUCKET --acl private"
        ),
    ),
    ComplianceRule(
        rule_id="rds-not-publicly-accessible",
        resource_type="aws_db_instance",
        attribute="publicly_accessible",
        check_type="value",
        expected_compliant=False,
        severity="critical",
        controls=(_SOC2_CC6_6, _PCI_1_3),
        description="RDS instance must not be publicly accessible",
        remediation=(
            "Disable public access: aws rds modify-db-instance "
            "--db-instance-identifier INSTANCE --no-publicly-accessible"
        ),
    ),
    ComplianceRule(
        rule_id="sg-no-unrestricted-ingress",
        resource_type="aws_security_group",
        attribute="ingress",
        check_type="sg_ingress",
        expected_compliant=None,
        severity="critical",
        controls=(_SOC2_CC6_6, _PCI_1_2_1),
        description=(
            "Security group must not allow unrestricted ingress (0.0.0.0/0) "
            "on non-standard ports (except 80/443)"
        ),
        remediation=(
            "Remove overly permissive ingress rules. Restrict source CIDR blocks "
            "to known IP ranges. Use VPC endpoints for AWS service access."
        ),
    ),
    ComplianceRule(
        rule_id="sg-no-unrestricted-egress",
        resource_type="aws_security_group",
        attribute="egress",
        check_type="drift",
        expected_compliant=None,
        severity="critical",
        controls=(_SOC2_CC6_6,),
        description="Security group should restrict egress to required destinations only",
        remediation=(
            "Replace 0.0.0.0/0 egress rules with specific CIDR ranges or "
            "security group references for required destinations."
        ),
    ),
    ComplianceRule(
        rule_id="iam-trust-policy",
        resource_type="aws_iam_role",
        attribute="assume_role_policy",
        check_type="drift",
        expected_compliant=None,
        severity="critical",
        controls=(_SOC2_CC6_1,),
        description=(
            "IAM role trust policy must not use overly permissive principals "
            "(e.g., * or broad account-level access)"
        ),
        remediation=(
            "Restrict the trust policy Principal to specific IAM roles, users, "
            "or services. Avoid Principal: '*' or Principal: AWS: '*'."
        ),
    ),
    # ── Logging / Audit (compliance severity: high) ────────────────────
    ComplianceRule(
        rule_id="s3-logging-enabled",
        resource_type="aws_s3_bucket",
        attribute="logging",
        check_type="drift",
        expected_compliant=None,
        severity="high",
        controls=(_SOC2_CC7_1, _PCI_10_1, _HIPAA_AUDIT),
        description="S3 bucket should have access logging enabled for audit trail",
        remediation=(
            "Enable access logging: aws s3api put-bucket-logging --bucket BUCKET "
            "--bucket-logging-status '...'"
        ),
    ),
    # ── Availability / Resilience (compliance severity: medium) ────────
    ComplianceRule(
        rule_id="s3-versioning-enabled",
        resource_type="aws_s3_bucket",
        attribute="versioning",
        check_type="drift",
        expected_compliant=None,
        severity="medium",
        controls=(_SOC2_CC8_1,),
        description="S3 bucket should have versioning enabled for change management",
        remediation=(
            "Enable versioning: aws s3api put-bucket-versioning --bucket BUCKET "
            "--versioning-configuration Status=Enabled"
        ),
    ),
    ComplianceRule(
        rule_id="rds-multi-az-enabled",
        resource_type="aws_db_instance",
        attribute="multi_az",
        check_type="value",
        expected_compliant=True,
        severity="medium",
        controls=(_SOC2_CC7_1,),
        description="RDS instance should have Multi-AZ enabled for availability",
        remediation=(
            "Enable Multi-AZ: aws rds modify-db-instance "
            "--db-instance-identifier INSTANCE --multi-az"
        ),
    ),
    ComplianceRule(
        rule_id="rds-backup-retention",
        resource_type="aws_db_instance",
        attribute="backup_retention_period",
        check_type="min_value",
        expected_compliant=7,
        severity="medium",
        controls=(_SOC2_CC7_1,),
        description=(
            "RDS instance should have backup retention >= 7 days "
            "(0 means automated backups disabled)"
        ),
        remediation=(
            "Set backup retention: aws rds modify-db-instance "
            "--db-instance-identifier INSTANCE --backup-retention-period 7"
        ),
    ),
)


# =============================================================================
# Lookup Helpers
# =============================================================================

# Index by (resource_type, attribute) for O(1) lookup during mapping
_RULES_BY_RESOURCE_ATTR: dict[tuple[str, str], ComplianceRule] = {
    (rule.resource_type, rule.attribute): rule for rule in COMPLIANCE_RULES
}
assert len(_RULES_BY_RESOURCE_ATTR) == len(COMPLIANCE_RULES), (
    "Duplicate (resource_type, attribute) keys in COMPLIANCE_RULES — "
    "each rule must have a unique (resource_type, attribute) pair"
)

# All supported frameworks (derived from rules)
SUPPORTED_FRAMEWORKS: frozenset[str] = frozenset(
    control.framework for rule in COMPLIANCE_RULES for control in rule.controls
)


def get_rule(resource_type: str, attribute: str) -> ComplianceRule | None:
    """Look up the compliance rule for a resource type + attribute pair."""
    return _RULES_BY_RESOURCE_ATTR.get((resource_type, attribute))


def get_rules_for_resource(resource_type: str) -> list[ComplianceRule]:
    """Get all compliance rules applicable to a resource type."""
    return [r for r in COMPLIANCE_RULES if r.resource_type == resource_type]


def get_rules_for_framework(framework: str) -> list[ComplianceRule]:
    """Get all rules that map to a specific compliance framework."""
    return [
        r for r in COMPLIANCE_RULES if any(c.framework == framework for c in r.controls)
    ]
