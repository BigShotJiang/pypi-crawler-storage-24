"""
compliance.tf Registry Mapping for RepliMap Codify.

Maps terraform-aws-modules to compliance.tf private registry sources.
compliance.tf (by Anton Babenko, terraform-aws-modules maintainer) provides
compliant module wrappers that enforce security controls by replacing the
standard Terraform Registry source URL with a framework-specific subdomain.

RepliMap strategy: brownfield IaC adoption + compliance drift detection,
complementary to compliance.tf's greenfield compliance controls.

Source of truth: @replimap/config src/compliance-tf-registry.json
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

# =============================================================================
# Framework Definitions
# =============================================================================

ComplianceTfFrameworkId = Literal[
    "soc2",
    "hipaa",
    "pcidss",
    "pcidssv321",
    "cisv140",
    "cisv500",
    "cisv600",
    "nist80053",
    "nist800171",
    "fedrampmoderate",
    "fedramplow",
    "iso27001",
    "gdpr",
    "cisv80ig1",
    "awscontroltower",
]

COMPLIANCE_TF_FRAMEWORK_IDS: tuple[ComplianceTfFrameworkId, ...] = (
    "soc2",
    "hipaa",
    "pcidss",
    "pcidssv321",
    "cisv140",
    "cisv500",
    "cisv600",
    "nist80053",
    "nist800171",
    "fedrampmoderate",
    "fedramplow",
    "iso27001",
    "gdpr",
    "cisv80ig1",
    "awscontroltower",
)


@dataclass(frozen=True)
class ComplianceTfFramework:
    """A compliance.tf registry framework definition."""

    id: ComplianceTfFrameworkId
    name: str
    registry_subdomain: str
    description: str
    standard_version: str | None
    region: str


COMPLIANCE_TF_FRAMEWORKS: dict[ComplianceTfFrameworkId, ComplianceTfFramework] = {
    "soc2": ComplianceTfFramework(
        id="soc2",
        name="SOC 2",
        registry_subdomain="soc2.compliance.tf",
        description="Service Organization Control 2 - Trust Services Criteria",
        standard_version=None,
        region="GLOBAL",
    ),
    "hipaa": ComplianceTfFramework(
        id="hipaa",
        name="HIPAA",
        registry_subdomain="hipaa.compliance.tf",
        description="Health Insurance Portability and Accountability Act",
        standard_version=None,
        region="US",
    ),
    "pcidss": ComplianceTfFramework(
        id="pcidss",
        name="PCI DSS v4.0",
        registry_subdomain="pcidss.compliance.tf",
        description="Payment Card Industry Data Security Standard v4.0",
        standard_version="4.0",
        region="GLOBAL",
    ),
    "pcidssv321": ComplianceTfFramework(
        id="pcidssv321",
        name="PCI DSS v3.2.1",
        registry_subdomain="pcidssv321.compliance.tf",
        description="Payment Card Industry Data Security Standard v3.2.1 (legacy)",
        standard_version="3.2.1",
        region="GLOBAL",
    ),
    "cisv140": ComplianceTfFramework(
        id="cisv140",
        name="CIS Benchmark v1.4.0",
        registry_subdomain="cisv140.compliance.tf",
        description="Center for Internet Security AWS Foundations Benchmark v1.4.0",
        standard_version="1.4.0",
        region="GLOBAL",
    ),
    "cisv500": ComplianceTfFramework(
        id="cisv500",
        name="CIS Benchmark v5.0.0",
        registry_subdomain="cisv500.compliance.tf",
        description="Center for Internet Security AWS Foundations Benchmark v5.0.0",
        standard_version="5.0.0",
        region="GLOBAL",
    ),
    "cisv600": ComplianceTfFramework(
        id="cisv600",
        name="CIS Benchmark v6.0.0",
        registry_subdomain="cisv600.compliance.tf",
        description="Center for Internet Security AWS Foundations Benchmark v6.0.0",
        standard_version="6.0.0",
        region="GLOBAL",
    ),
    "nist80053": ComplianceTfFramework(
        id="nist80053",
        name="NIST 800-53 Rev 5",
        registry_subdomain="nist80053.compliance.tf",
        description="NIST Special Publication 800-53 Revision 5 - Security and Privacy Controls",
        standard_version="Rev 5",
        region="US",
    ),
    "nist800171": ComplianceTfFramework(
        id="nist800171",
        name="NIST 800-171",
        registry_subdomain="nist800171.compliance.tf",
        description="NIST Special Publication 800-171 - Protecting Controlled Unclassified Information",
        standard_version=None,
        region="US",
    ),
    "fedrampmoderate": ComplianceTfFramework(
        id="fedrampmoderate",
        name="FedRAMP Moderate Rev 4",
        registry_subdomain="fedrampmoderate.compliance.tf",
        description="Federal Risk and Authorization Management Program - Moderate Impact Level Rev 4",
        standard_version="Rev 4",
        region="US",
    ),
    "fedramplow": ComplianceTfFramework(
        id="fedramplow",
        name="FedRAMP Low",
        registry_subdomain="fedramplow.compliance.tf",
        description="Federal Risk and Authorization Management Program - Low Impact Level",
        standard_version=None,
        region="US",
    ),
    "iso27001": ComplianceTfFramework(
        id="iso27001",
        name="ISO 27001",
        registry_subdomain="iso27001.compliance.tf",
        description="Information Security Management System - International Standard",
        standard_version=None,
        region="GLOBAL",
    ),
    "gdpr": ComplianceTfFramework(
        id="gdpr",
        name="GDPR",
        registry_subdomain="gdpr.compliance.tf",
        description="General Data Protection Regulation - EU Data Privacy",
        standard_version=None,
        region="EU",
    ),
    "cisv80ig1": ComplianceTfFramework(
        id="cisv80ig1",
        name="CIS Controls v8.0 IG1",
        registry_subdomain="cisv80ig1.compliance.tf",
        description="CIS Controls v8.0 Implementation Group 1",
        standard_version="8.0",
        region="GLOBAL",
    ),
    "awscontroltower": ComplianceTfFramework(
        id="awscontroltower",
        name="AWS Control Tower",
        registry_subdomain="awscontroltower.compliance.tf",
        description="AWS Control Tower guardrails and landing zone best practices",
        standard_version=None,
        region="AWS",
    ),
}


# =============================================================================
# Supported terraform-aws-modules (34 modules)
# =============================================================================


@dataclass(frozen=True)
class ModuleSourceMapping:
    """Maps a terraform-aws-modules module to its compliance.tf source pattern."""

    module_key: str
    original_source: str
    compliant_template: str


SUPPORTED_MODULES: tuple[str, ...] = (
    "s3-bucket",
    "vpc",
    "eks",
    "rds",
    "lambda",
    "alb",
    "dynamodb",
    "cloudfront",
    "iam",
    "security-group",
    "ec2-instance",
    "autoscaling",
    "ecs",
    "sns",
    "sqs",
    "kms",
    "route53",
    "acm",
    "cloudwatch",
    "elasticache",
    "eventbridge",
    "kinesis",
    "msk",
    "opensearch",
    "rds-aurora",
    "redshift",
    "step-functions",
    "transit-gateway",
    "vpn-gateway",
    "elb",
    "apigateway",
    "ecr",
    "key-pair",
    "ebs-optimized",
)

# Module key -> registry module name (most are identical, some differ)
_MODULE_REGISTRY_NAMES: dict[str, str] = {
    "dynamodb": "dynamodb-table",
    "msk": "msk-kafka-cluster",
    "apigateway": "apigateway-v2",
}

MODULE_SOURCE_MAPPINGS: dict[str, ModuleSourceMapping] = {}
for _mod in SUPPORTED_MODULES:
    _registry_name = _MODULE_REGISTRY_NAMES.get(_mod, _mod)
    MODULE_SOURCE_MAPPINGS[_mod] = ModuleSourceMapping(
        module_key=_mod,
        original_source=f"terraform-aws-modules/{_registry_name}/aws",
        compliant_template=f"{{framework}}.compliance.tf/terraform-aws-modules/{_registry_name}/aws",
    )


# =============================================================================
# Helper Functions
# =============================================================================


def get_compliant_source(
    module_key: str,
    framework_id: ComplianceTfFrameworkId,
) -> str:
    """
    Get the compliance.tf registry source for a module + framework.

    Args:
        module_key: Module key (e.g., "s3-bucket", "vpc")
        framework_id: Framework ID (e.g., "soc2", "hipaa")

    Returns:
        Compliant source string for use in Terraform module blocks.

    Raises:
        ValueError: If module_key or framework_id is not supported.

    Example:
        >>> get_compliant_source("s3-bucket", "soc2")
        'soc2.compliance.tf/terraform-aws-modules/s3-bucket/aws'
    """
    if module_key not in MODULE_SOURCE_MAPPINGS:
        raise ValueError(
            f"Unsupported module: {module_key}. "
            f"Supported: {', '.join(SUPPORTED_MODULES)}"
        )
    if framework_id not in COMPLIANCE_TF_FRAMEWORKS:
        raise ValueError(
            f"Unsupported framework: {framework_id}. "
            f"Supported: {', '.join(COMPLIANCE_TF_FRAMEWORK_IDS)}"
        )

    mapping = MODULE_SOURCE_MAPPINGS[module_key]
    return mapping.compliant_template.format(framework=framework_id)


def get_original_source(module_key: str) -> str:
    """
    Get the standard terraform-aws-modules registry source.

    Args:
        module_key: Module key (e.g., "s3-bucket", "vpc")

    Returns:
        Original source string (e.g., "terraform-aws-modules/s3-bucket/aws")
    """
    if module_key not in MODULE_SOURCE_MAPPINGS:
        raise ValueError(
            f"Unsupported module: {module_key}. "
            f"Supported: {', '.join(SUPPORTED_MODULES)}"
        )
    return MODULE_SOURCE_MAPPINGS[module_key].original_source


def is_compliance_tf_source(source: str) -> bool:
    """Check if a Terraform module source uses compliance.tf registry."""
    return ".compliance.tf/" in source


def parse_compliance_tf_source(source: str) -> tuple[str, str] | None:
    """
    Parse a compliance.tf source into (framework_id, original_source).

    Args:
        source: A compliance.tf source string

    Returns:
        Tuple of (framework_id, original_source) or None if not a compliance.tf source.

    Example:
        >>> parse_compliance_tf_source("soc2.compliance.tf/terraform-aws-modules/s3-bucket/aws")
        ('soc2', 'terraform-aws-modules/s3-bucket/aws')
    """
    if not is_compliance_tf_source(source):
        return None

    parts = source.split(".compliance.tf/", 1)
    if len(parts) != 2:
        return None

    framework_id = parts[0]
    original_source = parts[1]

    if framework_id not in COMPLIANCE_TF_FRAMEWORK_IDS:
        return None

    return (framework_id, original_source)


def detect_module_key_from_source(source: str) -> str | None:
    """
    Detect the module key from either an original or compliance.tf source.

    Args:
        source: A Terraform module source string

    Returns:
        Module key (e.g., "s3-bucket") or None if not recognized.
    """
    # Strip compliance.tf prefix if present
    actual_source = source
    parsed = parse_compliance_tf_source(source)
    if parsed is not None:
        actual_source = parsed[1]

    for mod_key, mapping in MODULE_SOURCE_MAPPINGS.items():
        if mapping.original_source == actual_source:
            return mod_key

    return None
