"""RepliMap MCP Server - Model Context Protocol integration for AI agents.

This module exposes RepliMap capabilities as MCP tools that AI agents
(Claude, Cursor, Copilot, etc.) can call natively without shelling out
to the CLI.

Usage:
    # Start the server (typically configured in MCP settings)
    python -m replimap.mcp_server

    # Or via the CLI
    replimap mcp-serve

The server registers these tools:
    - replimap_scan: Scan AWS infrastructure
    - replimap_audit: Run security audit
    - replimap_codify: Generate Terraform code
    - replimap_deps: Analyze resource dependencies
    - replimap_cost: Estimate infrastructure costs
    - replimap_dr: Assess disaster recovery readiness
    - replimap_graph: Generate infrastructure visualization

Requires: mcp package (pip install mcp)
"""

from __future__ import annotations

import json
import logging
import sys
from typing import Any

logger = logging.getLogger(__name__)

# MCP SDK availability check
try:
    from mcp.server import Server
    from mcp.server.stdio import stdio_server
    from mcp.types import TextContent, Tool

    MCP_AVAILABLE = True
except ImportError:
    MCP_AVAILABLE = False


def _make_tool(
    name: str,
    description: str,
    properties: dict[str, Any],
    required: list[str] | None = None,
) -> Any:
    """Create an MCP Tool definition."""
    return Tool(
        name=name,
        description=description,
        inputSchema={
            "type": "object",
            "properties": properties,
            "required": required or [],
        },
    )


TOOLS = [
    {
        "name": "replimap_scan",
        "description": (
            "Scan AWS infrastructure and build a dependency graph. "
            "Returns resource counts by type, dependency counts, and scanner status."
        ),
        "properties": {
            "profile": {
                "type": "string",
                "description": "AWS profile name",
                "default": "default",
            },
            "region": {
                "type": "string",
                "description": "AWS region to scan",
                "default": "us-east-1",
            },
            "refresh": {
                "type": "boolean",
                "description": "Force fresh scan (ignore cache)",
                "default": False,
            },
        },
        "required": ["region"],
    },
    {
        "name": "replimap_audit",
        "description": (
            "Run a security audit on AWS infrastructure using Checkov. "
            "Returns compliance score, grade, severity breakdown, and findings."
        ),
        "properties": {
            "profile": {
                "type": "string",
                "description": "AWS profile name",
                "default": "default",
            },
            "region": {
                "type": "string",
                "description": "AWS region to audit",
                "default": "us-east-1",
            },
            "refresh": {
                "type": "boolean",
                "description": "Force fresh scan before audit",
                "default": False,
            },
        },
        "required": ["region"],
    },
    {
        "name": "replimap_codify",
        "description": (
            "Generate Terraform configurations from scanned AWS resources. "
            "Returns the output directory, generated files, and import counts."
        ),
        "properties": {
            "profile": {
                "type": "string",
                "description": "AWS profile name",
                "default": "default",
            },
            "region": {
                "type": "string",
                "description": "AWS region",
                "default": "us-east-1",
            },
            "output_dir": {
                "type": "string",
                "description": "Output directory for Terraform files",
                "default": "./terraform",
            },
        },
        "required": ["region"],
    },
    {
        "name": "replimap_deps",
        "description": (
            "Analyze the dependency blast radius for a specific AWS resource. "
            "Returns affected resources, depth, and blast radius score."
        ),
        "properties": {
            "resource_id": {
                "type": "string",
                "description": "AWS resource ID to analyze (e.g., i-0123456789abcdef0)",
            },
            "profile": {
                "type": "string",
                "description": "AWS profile name",
                "default": "default",
            },
            "region": {
                "type": "string",
                "description": "AWS region",
                "default": "us-east-1",
            },
            "max_depth": {
                "type": "integer",
                "description": "Maximum traversal depth",
                "default": 3,
            },
        },
        "required": ["resource_id", "region"],
    },
    {
        "name": "replimap_cost",
        "description": (
            "Estimate monthly AWS infrastructure costs from scanned resources. "
            "Returns cost breakdown by service, top resources, and recommendations."
        ),
        "properties": {
            "profile": {
                "type": "string",
                "description": "AWS profile name",
                "default": "default",
            },
            "region": {
                "type": "string",
                "description": "AWS region",
                "default": "us-east-1",
            },
        },
        "required": ["region"],
    },
    {
        "name": "replimap_dr",
        "description": (
            "Assess disaster recovery readiness of AWS infrastructure. "
            "Returns readiness score, grade, gaps, and recommendations."
        ),
        "properties": {
            "profile": {
                "type": "string",
                "description": "AWS profile name",
                "default": "default",
            },
            "region": {
                "type": "string",
                "description": "AWS region",
                "default": "us-east-1",
            },
            "target_tier": {
                "type": "string",
                "description": "Target DR tier (tier_0 through tier_4)",
                "default": "tier_2",
                "enum": ["tier_0", "tier_1", "tier_2", "tier_3", "tier_4"],
            },
        },
        "required": ["region"],
    },
    {
        "name": "replimap_graph",
        "description": (
            "Generate infrastructure dependency visualization. "
            "Returns graph metadata (node/edge counts, resource types)."
        ),
        "properties": {
            "profile": {
                "type": "string",
                "description": "AWS profile name",
                "default": "default",
            },
            "region": {
                "type": "string",
                "description": "AWS region",
                "default": "us-east-1",
            },
            "output_format": {
                "type": "string",
                "description": "Output format",
                "default": "html",
                "enum": ["html", "mermaid", "json"],
            },
        },
        "required": ["region"],
    },
    {
        "name": "replimap_validate",
        "description": (
            "Validate infrastructure against topology constraints defined in YAML. "
            "Checks tagging, encryption, public access, and cross-region policies. "
            "Returns validation status, violation counts, and details."
        ),
        "properties": {
            "profile": {
                "type": "string",
                "description": "AWS profile name",
                "default": "default",
            },
            "region": {
                "type": "string",
                "description": "AWS region",
                "default": "us-east-1",
            },
            "constraints_file": {
                "type": "string",
                "description": "Path to constraints YAML file",
                "default": "constraints.yaml",
            },
        },
        "required": ["region"],
    },
    {
        "name": "replimap_residency",
        "description": (
            "Validate data residency compliance for NZ/AU sovereignty. "
            "Detects cross-region replication, global tables, read replicas, "
            "and CloudFront distributions without geo-restriction."
        ),
        "properties": {
            "profile": {
                "type": "string",
                "description": "AWS profile name",
                "default": "default",
            },
            "region": {
                "type": "string",
                "description": "AWS region",
                "default": "ap-southeast-2",
            },
            "policy": {
                "type": "string",
                "description": "Residency policy preset",
                "default": "nz_au",
                "enum": ["nz_au", "au_only", "custom"],
            },
            "custom_regions": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Approved regions (for custom policy)",
            },
            "refresh": {
                "type": "boolean",
                "description": "Force fresh scan (ignore cache)",
                "default": False,
            },
        },
        "required": ["region"],
    },
]


def _handle_tool_call(name: str, arguments: dict[str, Any]) -> dict[str, Any]:
    """Execute a tool call and return the result dict."""
    from replimap.api import RepliMap

    profile = arguments.get("profile", "default")
    region = arguments.get("region", "us-east-1")
    rm = RepliMap(profile=profile, region=region)

    if name == "replimap_scan":
        result = rm.scan(refresh=arguments.get("refresh", False))
    elif name == "replimap_audit":
        result = rm.audit(refresh=arguments.get("refresh", False))
    elif name == "replimap_codify":
        result = rm.codify(output_dir=arguments.get("output_dir", "./terraform"))
    elif name == "replimap_deps":
        result = rm.deps(
            resource_id=arguments["resource_id"],
            max_depth=arguments.get("max_depth", 3),
        )
    elif name == "replimap_cost":
        result = rm.cost()
    elif name == "replimap_dr":
        result = rm.dr_readiness(
            target_tier=arguments.get("target_tier", "tier_2"),
        )
    elif name == "replimap_graph":
        result = rm.graph(
            output_format=arguments.get("output_format", "html"),
        )
    elif name == "replimap_validate":
        result = rm.validate(
            constraints_file=arguments.get("constraints_file", "constraints.yaml"),
        )
    elif name == "replimap_residency":
        result = rm.residency(
            policy=arguments.get("policy", "nz_au"),
            custom_regions=arguments.get("custom_regions"),
            refresh=arguments.get("refresh", False),
        )
    else:
        return {"error": f"Unknown tool: {name}"}

    return result.to_dict()


def create_server() -> Any:
    """Create and configure the MCP server with RepliMap tools."""
    if not MCP_AVAILABLE:
        raise ImportError("MCP SDK not installed. Install with: pip install mcp")

    server = Server("replimap")

    @server.list_tools()
    async def list_tools() -> list[Tool]:
        return [
            _make_tool(
                t["name"],
                t["description"],
                t["properties"],
                t.get("required"),
            )
            for t in TOOLS
        ]

    @server.call_tool()
    async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
        try:
            result = _handle_tool_call(name, arguments)
            return [
                TextContent(type="text", text=json.dumps(result, indent=2, default=str))
            ]
        except Exception as e:
            logger.exception("Tool call failed: %s", name)
            error_result = {
                "error": True,
                "type": type(e).__name__,
                "message": str(e),
            }
            return [TextContent(type="text", text=json.dumps(error_result))]

    return server


async def main() -> None:
    """Run the MCP server via stdio transport."""
    if not MCP_AVAILABLE:
        sys.stderr.write(
            "Error: MCP SDK not installed.\n"
            "Install with: pip install mcp\n"
            "Then retry: python -m replimap.mcp_server\n"
        )
        sys.exit(1)

    server = create_server()
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream)


if __name__ == "__main__":
    import asyncio

    asyncio.run(main())
