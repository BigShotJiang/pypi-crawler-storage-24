"""Validate command for topology constraints.

V3 Architecture:
- Uses @enhanced_cli_error_handler for structured error handling
- Uses ctx.obj.output for stdout hygiene (stderr for progress, stdout for results)
- JSON mode available via global --format flag
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

import typer

from replimap.cli.errors import (
    EXIT_GENERAL_ERROR,
    EXIT_SUCCESS,
    EXIT_USAGE_ERROR,
    enhanced_cli_error_handler,
)
from replimap.cli.utils import get_profile_region

if TYPE_CHECKING:
    from replimap.cli.context import GlobalContext


def validate_command(
    ctx: typer.Context,
    profile: str | None = typer.Option(
        None,
        "--profile",
        "-p",
        help="AWS profile name",
    ),
    region: str | None = typer.Option(
        None,
        "--region",
        "-r",
        help="AWS region to validate",
    ),
    config: Path = typer.Option(
        Path("constraints.yaml"),
        "--config",
        "-c",
        help="Path to constraints YAML file",
    ),
    output_file: Path | None = typer.Option(
        None,
        "--output",
        "-o",
        help="Output file for validation report (JSON or Markdown)",
    ),
    fail_on: str = typer.Option(
        "critical",
        "--fail-on",
        help="Fail on severity level: critical, high, medium, low, info",
    ),
    generate_defaults: bool = typer.Option(
        False,
        "--generate-defaults",
        help="Generate default constraints file",
    ),
    refresh: bool = typer.Option(
        False,
        "--refresh",
        "-R",
        help="Force fresh AWS scan (ignore cached graph)",
    ),
) -> None:
    """Validate infrastructure against topology constraints.

    \b

    Checks your AWS infrastructure against policy rules defined in a
    constraints YAML file. Perfect for enforcing security policies,
    tagging standards, and architectural patterns.

    \b

    Examples:

        replimap validate --generate-defaults              # Generate defaults

        replimap validate -p prod -r us-east-1             # Validate

        replimap validate -p prod -r us-east-1 -c my.yaml  # Custom config

        replimap validate -p prod -r us-east-1 --fail-on high  # CI/CD

        replimap validate -p prod -r us-east-1 -o report.json
    """
    import boto3

    from replimap.core import GraphEngine
    from replimap.core.topology_constraints import (
        ConstraintSeverity,
        TopologyConstraint,
        TopologyValidator,
    )
    from replimap.scanners.base import run_all_scanners

    gctx: GlobalContext = ctx.obj
    output = gctx.output

    # Handle generate-defaults
    if generate_defaults:
        default_constraints = """# RepliMap Topology Constraints
# See: https://replimap.com/docs/topology-constraints

version: "1.0"

constraints:
  # Require Environment tag on all resources
  - name: require-environment-tag
    constraint_type: require_tag
    severity: high
    description: All resources must have Environment tag
    required_tags:
      Environment: null  # Any value accepted

  # Require Owner tag
  - name: require-owner-tag
    constraint_type: require_tag
    severity: medium
    description: All resources should have Owner tag
    required_tags:
      Owner: null

  # Require encryption on RDS instances
  - name: require-rds-encryption
    constraint_type: require_encryption
    severity: critical
    description: All RDS instances must be encrypted
    source_type: aws_db_instance

  # Require encryption on S3 buckets
  - name: require-s3-encryption
    constraint_type: require_encryption
    severity: critical
    description: All S3 buckets must have encryption enabled
    source_type: aws_s3_bucket

  # Prohibit public RDS instances
  - name: prohibit-public-rds
    constraint_type: prohibit_public_access
    severity: critical
    description: RDS instances must not be publicly accessible
    source_type: aws_db_instance
"""
        config.write_text(default_constraints)
        output.success(f"Generated default constraints: {config}")
        raise typer.Exit(EXIT_SUCCESS)

    # Check constraints file exists
    if not config.exists():
        output.error(
            f"Constraints file not found: {config}\n"
            "Run with --generate-defaults to create one:\n"
            "  replimap validate --generate-defaults"
        )
        raise typer.Exit(EXIT_GENERAL_ERROR)

    # Parse fail-on severity
    severity_map = {
        "critical": ConstraintSeverity.CRITICAL,
        "high": ConstraintSeverity.HIGH,
        "medium": ConstraintSeverity.MEDIUM,
        "low": ConstraintSeverity.LOW,
        "info": ConstraintSeverity.INFO,
    }
    fail_severity = severity_map.get(fail_on.lower(), ConstraintSeverity.CRITICAL)

    # Load constraints
    import yaml

    with open(config) as f:
        config_data = yaml.safe_load(f)

    constraints = []
    for c in config_data.get("constraints", []):
        constraints.append(
            TopologyConstraint(
                name=c["name"],
                constraint_type=c["constraint_type"],
                severity=ConstraintSeverity(c.get("severity", "medium")),
                description=c.get("description", ""),
                source_type=c.get("source_type"),
                target_type=c.get("target_type"),
                required_tags=c.get("required_tags", {}),
                config=c.get("config", {}),
            )
        )

    if not constraints:
        output.warn("No constraints defined in config file")
        raise typer.Exit(EXIT_SUCCESS)

    output.progress(f"Loaded {len(constraints)} constraints from {config}")

    # Determine region
    effective_profile = profile or gctx.profile
    effective_region = region or gctx.region

    if not region:
        profile_region = get_profile_region(profile)
        if profile_region:
            effective_region = profile_region

    output.progress(f"Region: {effective_region}")

    # Try to load from cache first
    from replimap.core.cache_manager import get_or_load_graph, save_graph_to_cache

    cached_graph, cache_meta = get_or_load_graph(
        profile=effective_profile,
        region=effective_region,
        console=output._stderr_console,
        refresh=refresh,
    )

    if cached_graph is not None:
        graph = cached_graph
    else:
        with output.spinner("Scanning infrastructure..."):
            session = boto3.Session(profile_name=effective_profile)
            graph = GraphEngine()
            run_all_scanners(session, graph, effective_region)

        save_graph_to_cache(
            graph=graph,
            profile=effective_profile,
            region=effective_region,
            console=output._stderr_console,
        )

    # Validate
    validator = TopologyValidator(constraints)
    result = validator.validate(graph)

    # JSON output for agents
    if output.is_json:
        result_data = result.to_dict()
        result_data["region"] = effective_region
        result_data["resource_count"] = len(graph.nodes)
        result_data["constraint_count"] = len(constraints)
        output.present(result_data)
    else:
        # Display results
        output.panel(
            f"Region: {effective_region}\n"
            f"Resources: {len(graph.nodes)}\n"
            f"Constraints: {len(constraints)}",
            title="Validation Results",
        )

        if result.is_valid:
            output.success("All constraints passed!")
        else:
            by_severity: dict[str, list] = {}
            for v in result.violations:
                sev = v.severity.value
                if sev not in by_severity:
                    by_severity[sev] = []
                by_severity[sev].append(v)

            output.error(f"Found {len(result.violations)} violations")

            for severity in ["critical", "high", "medium", "low", "info"]:
                if severity in by_severity:
                    output.log(
                        f"\n[bold]{severity.upper()}[/bold] ({len(by_severity[severity])})"
                    )
                    for v in by_severity[severity][:5]:
                        output.log(f"  - {v.constraint_name}: {v.resource_id}")
                        if v.message:
                            output.log(f"    {v.message}")
                    if len(by_severity[severity]) > 5:
                        output.log(f"  ... and {len(by_severity[severity]) - 5} more")

    # Export if requested
    if output_file:
        if output_file.suffix == ".json":
            import json as json_module

            with open(output_file, "w") as f:
                json_module.dump(result.to_dict(), f, indent=2)
            output.success(f"Saved report: {output_file}")
        else:
            with open(output_file, "w") as f:
                f.write("# Topology Validation Report\n\n")
                f.write(f"- Region: {effective_region}\n")
                f.write(f"- Resources: {len(graph.nodes)}\n")
                f.write(f"- Valid: {'Yes' if result.is_valid else 'No'}\n")
                f.write(f"- Violations: {len(result.violations)}\n\n")
                for v in result.violations:
                    f.write(
                        f"- **{v.constraint_name}** ({v.severity.value}): {v.resource_id}\n"
                    )
            output.success(f"Saved report: {output_file}")

    # Exit code based on severity
    if not result.is_valid:
        max_severity = max(v.severity for v in result.violations)
        if max_severity.value in ["critical", "high"] and fail_severity in [
            ConstraintSeverity.CRITICAL,
            ConstraintSeverity.HIGH,
        ]:
            raise typer.Exit(
                EXIT_GENERAL_ERROR
                if max_severity == ConstraintSeverity.HIGH
                else EXIT_USAGE_ERROR
            )


def register(app: typer.Typer, panel: str | None = None) -> None:
    """Register the validate command with the Typer app."""
    app.command(name="validate", rich_help_panel=panel)(
        enhanced_cli_error_handler(validate_command)
    )
