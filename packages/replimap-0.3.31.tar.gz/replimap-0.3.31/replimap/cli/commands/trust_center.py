"""Trust Center command group for RepliMap CLI.

V3 Architecture:
- Uses @enhanced_cli_error_handler for structured error handling
- Uses ctx.obj.output for stdout hygiene (stderr for progress, stdout for results)
- JSON mode available via global --format flag
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

import typer

from replimap.cli.errors import (
    EXIT_GENERAL_ERROR,
    EXIT_SUCCESS,
    enhanced_cli_error_handler,
)

if TYPE_CHECKING:
    from replimap.cli.context import GlobalContext


def create_trust_center_app() -> typer.Typer:
    """Create and return the trust_center subcommand app."""
    trust_center_app = typer.Typer(help="Trust Center API auditing for compliance")

    @trust_center_app.command("report")
    @enhanced_cli_error_handler
    def trust_center_report(
        ctx: typer.Context,
        output_file: Path | None = typer.Option(
            None, "--output", "-o", help="Output file path (JSON, CSV, or TXT)"
        ),
        format_type: str = typer.Option(
            "text", "--report-format", help="Report format: json, csv, text"
        ),
        include_records: bool = typer.Option(
            False,
            "--include-records",
            help="Include detailed API call records in JSON output",
        ),
    ) -> None:
        """Generate Trust Center compliance report."""
        from replimap.audit import TrustCenter

        gctx: GlobalContext = ctx.obj
        output = gctx.output

        tc = TrustCenter.get_instance()
        tc.load_sessions_from_disk()

        if tc.session_count == 0:
            output.warn(
                "No audit sessions found.\n"
                "Run a scan with --trust-center to enable API auditing:\n"
                "  replimap scan --profile prod --trust-center"
            )
            raise typer.Exit(EXIT_SUCCESS)

        report = tc.generate_report()

        if output.is_json:
            # In global JSON mode, present the report directly to stdout
            report_data = report.to_dict()
            if include_records:
                all_records = []
                for s in tc.list_sessions():
                    session = tc._sessions.get(s.session_id)
                    if session:
                        all_records.extend([r.to_dict() for r in session.records])
                report_data["records"] = all_records
            output.present(report_data)
        elif format_type == "json":
            output_path = output_file or Path("trust_center_report.json")
            tc.export_json(report, output_path, include_records=include_records)
            output.success(f"Saved JSON report: {output_path}")
        elif format_type == "csv":
            output_path = output_file or Path("trust_center_records.csv")
            sessions = tc.list_sessions()
            tc.export_csv(sessions, output_path)
            output.success(f"Saved CSV report: {output_path}")
        elif format_type == "text":
            if output_file:
                tc.save_compliance_text(report, output_file)
                output.success(f"Saved compliance report: {output_file}")
            else:
                text = tc.generate_compliance_text(report)
                output.log(text)
        else:
            output.error(f"Unknown format: {format_type}")
            raise typer.Exit(EXIT_GENERAL_ERROR)

    @trust_center_app.command("status")
    @enhanced_cli_error_handler
    def trust_center_status(ctx: typer.Context) -> None:
        """Show Trust Center status and session summary."""
        from replimap.audit import TrustCenter

        gctx: GlobalContext = ctx.obj
        output = gctx.output

        tc = TrustCenter.get_instance()
        tc.load_sessions_from_disk()

        sessions = tc.list_sessions()

        if output.is_json:
            output.present(
                {
                    "active_sessions": tc.session_count,
                    "sessions": [
                        {
                            "session_id": s.session_id,
                            "name": s.session_name,
                            "total_calls": s.total_calls,
                            "read_only_percentage": round(s.read_only_percentage, 1),
                            "is_read_only": s.is_read_only,
                        }
                        for s in sessions
                    ],
                }
            )
            return

        output.panel(
            f"Active Sessions: {tc.session_count}",
            title="Trust Center Status",
        )

        if sessions:
            output.table(
                [
                    {
                        "Session ID": s.session_id[:12] + "...",
                        "Name": s.session_name or "-",
                        "API Calls": str(s.total_calls),
                        "Read-Only %": f"{s.read_only_percentage:.1f}%",
                        "Status": ("Read-Only" if s.is_read_only else "Has Writes"),
                    }
                    for s in sessions[-5:]
                ],
                title="Recent Sessions",
            )
        else:
            output.progress("No sessions recorded yet.")

    @trust_center_app.command("clear")
    @enhanced_cli_error_handler
    def trust_center_clear(
        ctx: typer.Context,
        force: bool = typer.Option(
            False, "--force", "-f", help="Skip confirmation prompt"
        ),
    ) -> None:
        """Clear all Trust Center audit sessions."""
        from replimap.audit import TrustCenter

        gctx: GlobalContext = ctx.obj
        output = gctx.output

        tc = TrustCenter.get_instance()
        tc.load_sessions_from_disk()

        if tc.session_count == 0:
            output.progress("No sessions to clear.")
            raise typer.Exit(EXIT_SUCCESS)

        if not force:
            if not output.confirm(f"Clear {tc.session_count} audit sessions?"):
                output.progress("Cancelled")
                raise typer.Exit(EXIT_SUCCESS)

        tc.clear_sessions()

        session_files = list(tc._storage_dir.glob("session_*.json"))
        for f in session_files:
            f.unlink()

        cleared_count = len(session_files)
        if output.is_json:
            output.present({"cleared": cleared_count})
        else:
            output.success(
                f"Cleared all audit sessions ({cleared_count} files removed)"
            )

    return trust_center_app


def register(app: typer.Typer, panel: str | None = None) -> None:
    """Register the trust_center command group with the Typer app."""
    trust_center_app = create_trust_center_app()
    app.add_typer(trust_center_app, name="trust-center", rich_help_panel=panel)
