"""Audit command for RepliMap CLI.

V3 Architecture:
- Uses @enhanced_cli_error_handler for structured error handling
- Console output goes to stderr for stdout hygiene
- JSON mode available via global --format flag
"""

from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

import typer
from rich.progress import Progress, SpinnerColumn, TextColumn

from replimap.audit.terminal_reporter import print_audit_summary
from replimap.cli.errors import (
    EXIT_GENERAL_ERROR,
    EXIT_SUCCESS,
    enhanced_cli_error_handler,
)
from replimap.cli.utils import get_aws_session, resolve_effective_region
from replimap.core.browser import open_in_browser
from replimap.licensing import check_audit_ci_mode_allowed, check_audit_fix_allowed
from replimap.ui import print_audit_findings_fomo

if TYPE_CHECKING:
    from replimap.audit.checkov_runner import CheckovResults
    from replimap.cli.context import GlobalContext
    from replimap.cli.output import OutputManager


def _get_compliance_mappers(framework: str) -> list[tuple[str, Any]]:
    """Get compliance mapping functions for the specified framework(s).

    Returns list of (framework_name, get_mapping_func) tuples.
    """
    from replimap.audit.apra_cps234_mapping import get_cps234_mapping
    from replimap.audit.nzism_mapping import get_nzism_mapping
    from replimap.audit.rbnz_bs11_mapping import get_bs11_mapping
    from replimap.audit.soc2_mapping import get_soc2_mapping

    all_mappers = [
        ("soc2", get_soc2_mapping),
        ("rbnz_bs11", get_bs11_mapping),
        ("nzism", get_nzism_mapping),
        ("apra_cps234", get_cps234_mapping),
    ]

    if framework == "all":
        return all_mappers

    mapper_map = dict(all_mappers)
    if framework in mapper_map:
        return [(framework, mapper_map[framework])]

    # Default to SOC2
    return [("soc2", get_soc2_mapping)]


def _build_compliance_mappings(
    findings: list,
    framework: str,
) -> dict[str, dict]:
    """Build compliance control summaries for the specified framework(s)."""
    mappers = _get_compliance_mappers(framework)
    result: dict[str, dict] = {}

    for fw_name, get_mapping in mappers:
        summary: dict = {}
        for f in findings:
            if f.check_result != "FAILED":
                continue
            mapping = get_mapping(f.check_id)
            if mapping:
                control = mapping.control
                if control not in summary:
                    summary[control] = {
                        "control": control,
                        "category": mapping.category,
                        "count": 0,
                        "checks": [],
                    }
                summary[control]["count"] += 1
                if f.check_id not in summary[control]["checks"]:
                    summary[control]["checks"].append(f.check_id)
        result[fw_name] = summary

    return result


def _get_finding_compliance(check_id: str, framework: str) -> dict[str, Any] | None:
    """Get compliance mapping for a single finding across selected frameworks."""
    mappers = _get_compliance_mappers(framework)
    mappings: dict[str, Any] = {}

    for fw_name, get_mapping in mappers:
        mapping = get_mapping(check_id)
        if mapping:
            mappings[fw_name] = {
                "control": mapping.control,
                "category": mapping.category,
                "description": mapping.description,
            }

    return mappings if mappings else None


def _output_audit_json(
    results: CheckovResults,
    output_path: Path,
    region: str,
    profile: str | None,
    vpc_id: str | None,
    framework: str = "soc2",
) -> Path:
    """
    Output audit results as JSON with multi-framework compliance mapping.

    Args:
        results: Checkov scan results
        output_path: Base path for output (will change extension to .json)
        region: AWS region
        profile: AWS profile name
        vpc_id: VPC ID if specified
        framework: Compliance framework(s): soc2, rbnz_bs11, nzism, apra_cps234, all

    Returns:
        Path to the generated JSON file
    """
    from replimap.audit.fix_suggestions import FIX_SUGGESTIONS

    # Build compliance summaries for selected framework(s)
    compliance_summaries = _build_compliance_mappings(results.findings, framework)

    # Build JSON output
    json_output = {
        "summary": {
            "score": results.score,
            "grade": results.grade,
            "passed": results.passed,
            "failed": results.failed,
            "skipped": results.skipped,
            "total": results.total,
            "high_severity_count": len(results.high_severity),
        },
        "metadata": {
            "region": region,
            "profile": profile,
            "vpc_id": vpc_id,
            "framework": framework,
            "generated_at": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
        },
        "severity_breakdown": {
            "critical": len(results.findings_by_severity["CRITICAL"]),
            "high": len(results.findings_by_severity["HIGH"]),
            "medium": len(results.findings_by_severity["MEDIUM"]),
            "low": len(results.findings_by_severity["LOW"]),
        },
        "findings": [
            {
                "check_id": f.check_id,
                "check_name": f.check_name,
                "severity": f.severity,
                "result": f.check_result,
                "resource": f.resource,
                "file_path": f.file_path,
                "line_range": list(f.file_line_range),
                "compliance": _get_finding_compliance(f.check_id, framework),
                "has_fix_suggestion": f.check_id in FIX_SUGGESTIONS,
                "guideline": f.guideline,
            }
            for f in results.findings
            if f.check_result == "FAILED"
        ],
        "compliance_summary": compliance_summaries,
    }

    # Determine output path
    json_path = output_path.with_suffix(".json")
    json_path.parent.mkdir(parents=True, exist_ok=True)
    json_path.write_text(json.dumps(json_output, indent=2))

    return json_path


def _generate_remediation(
    results: CheckovResults, output_dir: Path, output: OutputManager
) -> None:
    """
    Generate Terraform remediation code from audit results.

    Args:
        results: Checkov scan results containing findings
        output_dir: Directory to write remediation files
        output: OutputManager for V3 compliance
    """
    from rich.panel import Panel

    from replimap.audit.remediation import RemediationGenerator
    from replimap.audit.remediation.models import RemediationSeverity

    output.log("")
    output._stderr_console.print(
        Panel(
            "[bold blue]Generating Remediation Code[/bold blue]\n\n"
            f"Output: [cyan]{output_dir}[/]",
            border_style="blue",
        )
    )

    generator = RemediationGenerator(results.findings, output_dir)
    plan = generator.generate()

    if plan.files:
        # Write all files
        plan.write_all(output_dir)

        output.log("")
        output._stderr_console.print(
            Panel(
                f"[bold]Remediation Generated[/bold]\n\n"
                f"[green]✓ Files:[/] {len(plan.files)}\n"
                f"[green]✓ Coverage:[/] {plan.coverage_percent}%\n"
                f"[dim]Skipped:[/] {plan.skipped_findings} (no template available)",
                title="Remediation Summary",
                border_style="green",
            )
        )

        # Show by severity
        by_severity = plan.files_by_severity()

        severity_info = []
        if by_severity[RemediationSeverity.CRITICAL]:
            severity_info.append(
                f"[red]CRITICAL: {len(by_severity[RemediationSeverity.CRITICAL])}[/]"
            )
        if by_severity[RemediationSeverity.HIGH]:
            severity_info.append(
                f"[orange1]HIGH: {len(by_severity[RemediationSeverity.HIGH])}[/]"
            )
        if by_severity[RemediationSeverity.MEDIUM]:
            severity_info.append(
                f"[yellow]MEDIUM: {len(by_severity[RemediationSeverity.MEDIUM])}[/]"
            )
        if by_severity[RemediationSeverity.LOW]:
            severity_info.append(
                f"[green]LOW: {len(by_severity[RemediationSeverity.LOW])}[/]"
            )

        if severity_info:
            output.log(f"  Fixes by severity: {' | '.join(severity_info)}")

        output.log("")
        output.success(f"Remediation: {output_dir.absolute()}")
        output.success(f"README: {output_dir.absolute()}/README.md")

        if plan.has_imports:
            output.warn(f"Import script: {output_dir.absolute()}/import.sh")
            output.log("")
            output.log(
                "[dim]Some fixes require terraform import. "
                "Run import.sh before terraform apply.[/dim]"
            )

        if plan.warnings:
            output.log("")
            for warning in plan.warnings:
                output.warn(warning)
    else:
        output.log("")
        output.warn("No remediation templates available for the detected findings.")


def _run_evidence_audit(
    *,
    ctx: typer.Context,
    state: Path,
    profile: str | None,
    region: str | None,
    effective_region: str,
    region_source: str,
    framework: str,
    company: str,
    audit_period: str,
    ignore_file: Path | None,
    output_file: Path,
    report_format: str,
    no_cache: bool,
    refresh: bool,
    vpc: str | None,
    output: OutputManager,
) -> None:
    """Run SOC 2 evidence audit using drift detection pipeline.

    This is the --state mode: parses TF state, runs drift detection,
    maps to compliance controls, and generates a full evidence report
    showing PASS/FAIL/EXEMPTED for every covered resource.
    """
    from replimap.compliance.audit.renderer import AuditEvidenceRenderer
    from replimap.compliance.drift.exemptions import ExemptionManager
    from replimap.compliance.drift.mapping import ComplianceMappingEngine
    from replimap.drift import DriftEngine

    # Map framework shorthand
    framework_map = {
        "soc2": "SOC 2",
        "pcidss": "PCI DSS",
        "hipaa": "HIPAA",
        "all": "all",
    }
    mapped_framework = framework_map.get(framework, framework)

    output.log("")
    output.panel(
        f"[bold blue]SOC 2 Evidence Audit[/bold blue]\n\n"
        f"Region: [cyan]{effective_region}[/] [dim](from {region_source})[/]\n"
        f"Profile: [cyan]{profile or 'default'}[/]\n"
        f"State: [cyan]{state}[/]\n"
        + (f"Company: [cyan]{company}[/]\n" if company else "")
        + (f"Period: [cyan]{audit_period}[/]\n" if audit_period else "")
        + f"Framework: [cyan]{mapped_framework}[/]",
        border_style="blue",
    )

    # Get AWS session + run drift detection
    session = get_aws_session(profile, effective_region, use_cache=not no_cache)

    from replimap.core.cache_manager import get_or_load_graph, save_graph_to_cache

    cached_graph, _ = get_or_load_graph(
        profile=profile or "default",
        region=effective_region,
        console=output._stderr_console,
        refresh=refresh,
        vpc=vpc,
    )

    engine = DriftEngine(
        session=session,
        region=effective_region,
        profile=profile,
    )

    with output.spinner("Running drift detection..."):
        try:
            drift_report = engine.detect(
                state_path=state,
                vpc_id=vpc,
                graph=cached_graph,
            )
        except FileNotFoundError as e:
            output.error(f"State file not found: {e}")
            raise typer.Exit(EXIT_GENERAL_ERROR)
        except Exception as e:
            output.error(f"Drift detection failed: {e}")
            raise typer.Exit(EXIT_GENERAL_ERROR)

    # Save graph to cache if we did a fresh scan
    if cached_graph is None and hasattr(engine, "_graph"):
        save_graph_to_cache(
            graph=engine._graph,
            profile=profile or "default",
            region=effective_region,
            console=output._stderr_console,
            vpc=vpc,
        )

    # Get TF resources for full-coverage evidence (PASS status)
    from replimap.drift.state_parser import TerraformStateParser

    try:
        parser = TerraformStateParser()
        tf_state = parser.parse(state)
        tf_resources = tf_state.resources
    except (FileNotFoundError, ValueError, KeyError) as e:
        output.error(f"Failed to parse state file for evidence report: {e}")
        raise typer.Exit(EXIT_GENERAL_ERROR)

    # Compliance mapping
    compliance_engine = ComplianceMappingEngine(framework=mapped_framework)
    compliance_report = compliance_engine.map(drift_report)

    # Apply exemptions
    effective_ignore = ignore_file or Path(".replimap-ignore.yml")
    if effective_ignore.exists():
        exemptions = ExemptionManager.from_file(effective_ignore)
        exemptions.apply(compliance_report)
        if exemptions.exemption_count > 0:
            output.log(
                f"Applied {exemptions.exemption_count} exemption(s) "
                f"from {effective_ignore}"
            )

    # Render evidence report
    renderer = AuditEvidenceRenderer(
        tf_resources=tf_resources,
        compliance_report=compliance_report,
        company=company,
        period=audit_period,
    )

    # Detect if user explicitly set --output (default is the Checkov HTML path)
    _CHECKOV_DEFAULT = Path("audit_report.html")
    user_set_output = output_file.resolve() != Path.cwd() / _CHECKOV_DEFAULT

    if report_format in ("markdown", "md"):
        out_path = output_file if user_set_output else Path("./soc2-evidence.md")
        out_path.write_text(renderer.render())
        output.success(f"Evidence report: {out_path.absolute()}")
    elif report_format == "json":
        import json as json_mod

        out_path = output_file if user_set_output else Path("./soc2-evidence.json")
        out_path.write_text(json_mod.dumps(compliance_report.to_dict(), indent=2))
        output.success(f"JSON report: {out_path.absolute()}")
    else:
        # Default: markdown for evidence reports
        out_path = output_file if user_set_output else Path("./soc2-evidence.md")
        out_path.write_text(renderer.render())
        output.success(f"Evidence report: {out_path.absolute()}")

    # JSON mode (V3 global --format json): present to stdout
    if output.is_json:
        output.present(compliance_report.to_dict())

    # Summary (reuse sections already built during render)
    sections = renderer.build_sections()
    total_pass = sum(s.pass_count for s in sections)
    total_fail = sum(s.fail_count for s in sections)
    total_exempt = sum(s.exempt_count for s in sections)
    total_checks = total_pass + total_fail + total_exempt

    if total_checks > 0:
        rate = total_pass / total_checks * 100
        output.log("")
        if total_fail == 0:
            output.panel(
                f"[bold green]COMPLIANT[/bold green]\n\n"
                f"✅ {total_pass} PASS | ⚠️ {total_exempt} exempted\n"
                f"Compliance rate: {rate:.0f}%",
                border_style="green",
            )
        else:
            output.panel(
                f"[bold red]NON-COMPLIANT[/bold red]\n\n"
                f"✅ {total_pass} PASS | ❌ {total_fail} FAIL | ⚠️ {total_exempt} exempted\n"
                f"Compliance rate: {rate:.0f}%",
                border_style="red",
            )

    # Exit codes
    if compliance_report.has_critical_or_high:
        raise typer.Exit(EXIT_GENERAL_ERROR)
    elif compliance_report.has_findings:
        raise typer.Exit(2)

    output.log("")


def audit_command(
    ctx: typer.Context,
    # === Common Options ===
    profile: str | None = typer.Option(
        None,
        "--profile",
        "-p",
        help="AWS profile name",
    ),
    region: str | None = typer.Option(
        None,
        "--region",
        "-r",
        help="AWS region to audit",
    ),
    vpc: str | None = typer.Option(
        None,
        "--vpc",
        "-v",
        help="VPC ID to scope the audit (optional)",
    ),
    output_file: Path = typer.Option(
        Path("./audit_report.html"),
        "--output",
        "-o",
        help="Path for HTML/JSON report",
    ),
    report_format: str = typer.Option(
        "html",
        "--format",
        "-f",
        help="Output format: html or json",
    ),
    # === Output Options ===
    terraform_dir: Path = typer.Option(
        Path("./audit_output"),
        "--terraform-dir",
        "-t",
        help="Directory for generated Terraform files",
        rich_help_panel="Output",
    ),
    open_report: bool = typer.Option(
        True,
        "--open/--no-open",
        help="Open report in browser after generation",
        rich_help_panel="Output",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-V",
        help="Show all findings in terminal (default: summary only)",
        rich_help_panel="Output",
    ),
    # === CI/CD Integration ===
    fail_on_high: bool = typer.Option(
        False,
        "--fail-on-high",
        help="Exit with code 1 if HIGH/CRITICAL issues found (for CI/CD)",
        rich_help_panel="CI/CD Integration",
    ),
    fail_on_score: int | None = typer.Option(
        None,
        "--fail-on-score",
        help="Exit with code 1 if score below threshold (e.g., --fail-on-score 70)",
        rich_help_panel="CI/CD Integration",
    ),
    # === Remediation ===
    fix: bool = typer.Option(
        False,
        "--fix",
        help="Generate Terraform remediation code for findings",
        rich_help_panel="Remediation",
    ),
    fix_output: Path = typer.Option(
        Path("./remediation"),
        "--fix-output",
        help="Directory for remediation Terraform files",
        rich_help_panel="Remediation",
    ),
    # === Compliance Framework ===
    framework: str = typer.Option(
        "soc2",
        "--framework",
        help="Compliance framework: soc2, rbnz_bs11, nzism, apra_cps234, all",
        rich_help_panel="Auditing & Compliance",
    ),
    # === SOC 2 Evidence Mode (state-based) ===
    state: Path | None = typer.Option(
        None,
        "--state",
        "-s",
        help=(
            "Terraform state file path. When provided, generates a SOC 2 "
            "compliance evidence report using drift detection (instead of Checkov)."
        ),
        rich_help_panel="Auditing & Compliance",
    ),
    company: str | None = typer.Option(
        None,
        "--company",
        help="Company name for audit report header",
        rich_help_panel="Auditing & Compliance",
    ),
    audit_period: str | None = typer.Option(
        None,
        "--period",
        help='Audit period (e.g., "2026-Q1" or "2026-01 to 2026-03")',
        rich_help_panel="Auditing & Compliance",
    ),
    ignore_file: Path | None = typer.Option(
        None,
        "--ignore-file",
        help="Path to .replimap-ignore.yml exemption file",
        rich_help_panel="Auditing & Compliance",
    ),
    # === Cache & Performance ===
    no_cache: bool = typer.Option(
        False,
        "--no-cache",
        help="Don't use cached credentials",
        rich_help_panel="Cache & Performance",
    ),
    refresh: bool = typer.Option(
        False,
        "--refresh",
        "-R",
        help="Force fresh AWS scan (ignore cached graph)",
        rich_help_panel="Cache & Performance",
    ),
) -> None:
    """Run security audit on AWS infrastructure.

    \b

    Scans your AWS environment, generates a forensic Terraform snapshot,
    runs Checkov security analysis, and produces an HTML report with
    findings mapped to SOC2 controls.

    \b

    Requires Checkov to be installed: pip install checkov

    \b

    Examples:

        replimap audit --region us-east-1

        replimap audit -p prod -r ap-southeast-2 -v vpc-abc123

        replimap audit -r us-west-2 --no-open

        replimap audit -r us-east-1 --fail-on-high --no-open  # CI/CD mode

        replimap audit -r us-east-1 --fail-on-score 70 --no-open

        replimap audit -r us-east-1 --format json

        replimap audit -r us-east-1 --fix --fix-output ./remediation

        replimap audit -r us-east-1 --verbose  # Show all findings
    """
    from rich.panel import Panel

    # Get V3 context
    gctx: GlobalContext = ctx.obj
    output = gctx.output

    # Determine region: flag > profile config > default
    effective_region, region_source = resolve_effective_region(region, profile)

    # ── SOC 2 Evidence Mode (when --state is provided) ─────────────────
    if state is not None:
        _run_evidence_audit(
            ctx=ctx,
            state=state,
            profile=profile,
            region=region,
            effective_region=effective_region,
            region_source=region_source,
            framework=framework,
            company=company or "",
            audit_period=audit_period or "",
            ignore_file=ignore_file,
            output_file=output_file,
            report_format=report_format,
            no_cache=no_cache,
            refresh=refresh,
            vpc=vpc,
            output=output,
        )
        return

    # ── Checkov-based audit (existing behavior) ─────────────────────────
    from replimap.audit import AuditEngine, CheckovNotInstalledError

    output.log("")
    output._stderr_console.print(
        Panel(
            f"[bold blue]RepliMap Security Audit[/bold blue]\n\n"
            f"Region: [cyan]{effective_region}[/] [dim](from {region_source})[/]\n"
            f"Profile: [cyan]{profile or 'default'}[/]\n"
            + (f"VPC: [cyan]{vpc}[/]\n" if vpc else "")
            + f"Output: [cyan]{output_file}[/]\n"
            f"Terraform: [cyan]{terraform_dir}[/]",
            border_style="blue",
        )
    )

    # Get AWS session
    session = get_aws_session(profile, effective_region, use_cache=not no_cache)

    # Check Checkov is installed
    try:
        engine = AuditEngine(
            session=session,
            region=effective_region,
            profile=profile,
            vpc_id=vpc,
        )
    except CheckovNotInstalledError:
        output.log("")
        output._stderr_console.print(
            Panel(
                "[red]Checkov is not installed.[/]\n\n"
                "Install Checkov with:\n"
                "  [bold]pipx install checkov[/]  (recommended)\n\n"
                "Or:\n"
                "  [bold]pip install checkov[/]",
                title="Missing Dependency",
                border_style="red",
            )
        )
        raise typer.Exit(EXIT_GENERAL_ERROR)

    # Try to load from cache first
    from replimap.core import GraphEngine
    from replimap.core.cache_manager import get_or_load_graph, save_graph_to_cache
    from replimap.scanners.base import run_all_scanners

    # Try to load from cache first (global signal handler handles Ctrl-C)
    output.log("")
    stderr_console = output._stderr_console
    cached_graph, cache_meta = get_or_load_graph(
        profile=profile or "default",
        region=effective_region,
        console=stderr_console,
        refresh=refresh,
        vpc=vpc,
    )

    # If no cached graph, do the scan and cache it
    graph = cached_graph
    if graph is None:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=stderr_console,
        ) as progress:
            task = progress.add_task("Scanning AWS resources...", total=None)
            graph = GraphEngine()
            run_all_scanners(session, effective_region, graph)
            progress.update(task, completed=True)

        # Apply VPC filter if specified
        if vpc:
            from replimap.core import ScanFilter, apply_filter_to_graph

            filter_config = ScanFilter(
                vpc_ids=[vpc],
                include_vpc_resources=True,
            )
            graph = apply_filter_to_graph(graph, filter_config)

        # Save to cache (cache is per vpc if specified)
        save_graph_to_cache(
            graph=graph,
            profile=profile or "default",
            region=effective_region,
            console=stderr_console,
            vpc=vpc,
        )

    # Apply VPC filter if specified (for cached graph)
    if cached_graph is not None and vpc:
        from replimap.core import ScanFilter, apply_filter_to_graph

        filter_config = ScanFilter(
            vpc_ids=[vpc],
            include_vpc_resources=True,
        )
        graph = apply_filter_to_graph(graph, filter_config)

    # Run audit with the graph (skip scanning since we have it)
    output.log("")
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=stderr_console,
    ) as progress:
        task = progress.add_task("Running security checks...", total=None)

        try:
            results, report_path = engine.run(
                output_dir=terraform_dir,
                report_path=output_file,
                skip_scan=True,
                graph=graph,
            )
        except Exception as e:
            from rich.panel import Panel

            progress.stop()
            output.log("")
            stderr_console.print(
                Panel(
                    f"[red]Audit failed:[/]\n{e}",
                    title="Error",
                    border_style="red",
                )
            )
            raise typer.Exit(EXIT_GENERAL_ERROR)

        progress.update(task, completed=True)

    # JSON mode (V3 global --format json): present structured result to stdout
    if output.is_json:
        severity_breakdown = {
            "critical": len(results.findings_by_severity.get("CRITICAL", [])),
            "high": len(results.findings_by_severity.get("HIGH", [])),
            "medium": len(results.findings_by_severity.get("MEDIUM", [])),
            "low": len(results.findings_by_severity.get("LOW", [])),
        }
        compliance_summaries = _build_compliance_mappings(results.findings, framework)
        json_result = {
            "status": "success",
            "summary": {
                "score": results.score,
                "grade": results.grade,
                "passed": results.passed,
                "failed": results.failed,
                "skipped": results.skipped,
                "total": results.total,
            },
            "metadata": {
                "region": effective_region,
                "region_source": region_source,
                "profile": profile or "default",
                "vpc_id": vpc,
                "framework": framework,
                "generated_at": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
            },
            "severity_breakdown": severity_breakdown,
            "high_severity_count": len(results.high_severity),
            "findings": [
                {
                    "check_id": f.check_id,
                    "check_name": f.check_name,
                    "severity": f.severity,
                    "result": f.check_result,
                    "resource": f.resource,
                    "file_path": f.file_path,
                    "line_range": list(f.file_line_range),
                    "guideline": f.guideline,
                    "compliance": _get_finding_compliance(f.check_id, framework),
                }
                for f in results.findings
                if f.check_result == "FAILED"
            ],
            "compliance_summary": compliance_summaries,
            "report_path": str(report_path.absolute()) if report_path else None,
            "terraform_dir": str(terraform_dir.absolute()),
        }
        output.present(json_result)

    # Handle JSON output format (file-based --format json flag)
    if report_format.lower() == "json":
        json_path = _output_audit_json(
            results,
            output_file,
            effective_region,
            profile,
            vpc,
            framework=framework,
        )
        output.log("")
        output.success(f"JSON Report: {json_path.absolute()}")
        output.success(f"Terraform: {terraform_dir.absolute()}")
    else:
        # Display results based on verbosity
        output.log("")
        if verbose:
            # Verbose mode: Show all findings with FOMO design
            # This shows ALL issue titles (even for FREE users)
            # First CRITICAL gets 2-line remediation preview
            # Remaining remediation details are gated by plan
            print_audit_findings_fomo(results, console_out=stderr_console)
        else:
            # Default: Compact summary + top 5 critical issues
            print_audit_summary(results, stderr_console, verbose=False)

        # Output paths
        output.log("")
        output.success(f"Report: {report_path.absolute()}")
        output.success(f"Terraform: {terraform_dir.absolute()}")

        # Open report in browser (only for HTML format)
        if open_report:
            output.log("")
            open_in_browser(report_path, console=stderr_console)

    # Generate remediation if requested (PRO+ feature)
    if fix:
        fix_gate = check_audit_fix_allowed()
        if not fix_gate.allowed:
            output.log(fix_gate.prompt)
            raise typer.Exit(EXIT_GENERAL_ERROR)
        if results.findings:
            _generate_remediation(results, fix_output, output)

    # CI/CD checks (PRO+ feature)
    exit_code = EXIT_SUCCESS

    if fail_on_high or fail_on_score is not None:
        ci_gate = check_audit_ci_mode_allowed()
        if not ci_gate.allowed:
            output.log(ci_gate.prompt)
            raise typer.Exit(EXIT_GENERAL_ERROR)

    if fail_on_high and results.high_severity:
        output.log("")
        output.error(
            f"CI/CD FAILED: {len(results.high_severity)} HIGH/CRITICAL issues found"
        )
        for f in results.high_severity[:5]:
            output.log(f"   • {f.check_id}: {f.check_name}")
        if len(results.high_severity) > 5:
            output.log(f"   ... and {len(results.high_severity) - 5} more")
        exit_code = EXIT_GENERAL_ERROR

    if fail_on_score is not None and results.score < fail_on_score:
        output.log("")
        output.error(
            f"CI/CD FAILED: Score {results.score} below threshold {fail_on_score}"
        )
        exit_code = EXIT_GENERAL_ERROR

    if exit_code == EXIT_SUCCESS and (fail_on_high or fail_on_score is not None):
        output.log("")
        output.success("CI/CD PASSED")

    output.log("")

    if exit_code != EXIT_SUCCESS:
        raise typer.Exit(exit_code)


def register(app: typer.Typer, panel: str | None = None) -> None:
    """Register the audit command with the Typer app."""
    app.command(name="audit", rich_help_panel=panel)(
        enhanced_cli_error_handler(audit_command)
    )
