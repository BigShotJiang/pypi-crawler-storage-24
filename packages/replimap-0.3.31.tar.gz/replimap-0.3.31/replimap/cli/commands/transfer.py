"""Data transfer analysis command for RepliMap CLI.

V3 Architecture:
- Uses @enhanced_cli_error_handler for structured error handling
- Uses ctx.obj.output for stdout hygiene (stderr for progress, stdout for results)
- JSON mode available via global --format flag
"""

from __future__ import annotations

import json as json_module
from pathlib import Path
from typing import TYPE_CHECKING

import typer

from replimap.cli.errors import EXIT_GENERAL_ERROR, enhanced_cli_error_handler
from replimap.cli.utils import get_aws_session, resolve_effective_region
from replimap.core import GraphEngine
from replimap.scanners.base import run_all_scanners

if TYPE_CHECKING:
    from replimap.cli.context import GlobalContext


def transfer_command(
    ctx: typer.Context,
    profile: str | None = typer.Option(
        None,
        "--profile",
        "-p",
        help="AWS profile name",
    ),
    region: str | None = typer.Option(
        None,
        "--region",
        "-r",
        help="AWS region to analyze",
    ),
    output_file: Path | None = typer.Option(
        None,
        "--output",
        "-o",
        help="Output file path",
    ),
    output_format: str = typer.Option(
        "console",
        "--format",
        "-f",
        help="Output format: console, json",
    ),
    no_cache: bool = typer.Option(
        False,
        "--no-cache",
        help="Don't use cached credentials",
    ),
    refresh: bool = typer.Option(
        False,
        "--refresh",
        "-R",
        help="Force fresh AWS scan (ignore cached graph)",
    ),
) -> None:
    """Analyze data transfer costs and optimization opportunities.

    \b

    Identifies costly data transfer patterns.

    \b

    Examples:

        replimap transfer -r us-east-1

        replimap transfer -r us-east-1 -f json -o transfer.json
    """
    from replimap.cost.transfer_analyzer import DataTransferAnalyzer
    from replimap.licensing import check_cost_allowed

    # Get V3 context
    gctx: GlobalContext = ctx.obj
    output = gctx.output
    stderr_console = output._stderr_console

    cost_gate = check_cost_allowed()
    if not cost_gate.allowed:
        output.log(cost_gate.prompt)
        raise typer.Exit(EXIT_GENERAL_ERROR)

    # Use context defaults
    effective_profile = profile or gctx.profile or "default"

    # Determine region using consolidated resolution
    effective_region, region_source = resolve_effective_region(
        region, effective_profile, default=gctx.region or "us-east-1"
    )
    if region_source == "default" and gctx.region:
        region_source = "context"

    output.panel(
        f"[bold cyan]Data Transfer Analyzer[/bold cyan]\n\n"
        f"Region: [cyan]{effective_region}[/] [dim](from {region_source})[/]\n"
        f"Profile: [cyan]{effective_profile}[/]",
        border_style="cyan",
    )

    session = get_aws_session(
        effective_profile, effective_region, use_cache=not no_cache
    )

    # Try to load from cache first (global signal handler handles Ctrl-C)
    from replimap.core.cache_manager import get_or_load_graph, save_graph_to_cache

    output.log("")
    cached_graph, cache_meta = get_or_load_graph(
        profile=effective_profile,
        region=effective_region,
        console=stderr_console,
        refresh=refresh,
    )

    if cached_graph is not None:
        graph = cached_graph
    else:
        with output.spinner("Scanning infrastructure..."):
            graph = GraphEngine()
            run_all_scanners(session, effective_region, graph)

        # Save to cache
        save_graph_to_cache(
            graph=graph,
            profile=effective_profile,
            region=effective_region,
            console=stderr_console,
        )

    # Analyze transfer paths
    try:
        with output.spinner("Analyzing transfer paths..."):
            analyzer = DataTransferAnalyzer(session, effective_region)
            report = analyzer.analyze_from_graph(graph)
    except Exception as e:
        output.error(f"Error: {e}")
        raise typer.Exit(EXIT_GENERAL_ERROR)

    output.log("")

    if output_format == "console":
        output.log("[bold]Transfer Cost Summary[/bold]")
        output.log(f"  Total paths analyzed: {report.total_paths}")
        output.log(f"  Estimated monthly cost: ${report.total_monthly_cost:.2f}")
        output.log("")

        if report.cross_az_paths:
            output.log(
                f"[bold yellow]Cross-AZ Traffic ({len(report.cross_az_paths)} paths)[/bold yellow]"
            )
            output.log("  [dim]Cross-AZ traffic incurs $0.01/GB each way[/dim]")
            for path in report.cross_az_paths[:5]:
                output.log(
                    f"  * {path.source_type} -> {path.destination_type}: "
                    f"~{path.estimated_gb_month} GB/mo (${float(path.estimated_gb_month) * 0.02:.2f})"
                )
            output.log("")

        if report.nat_gateway_paths:
            output.log(
                f"[bold yellow]NAT Gateway Traffic ({len(report.nat_gateway_paths)} paths)[/bold yellow]"
            )
            output.log("  [dim]NAT Gateway: $0.045/hour + $0.045/GB processed[/dim]")
            for path in report.nat_gateway_paths[:5]:
                output.log(
                    f"  * {path.source_type} -> Internet: ~{path.estimated_gb_month} GB/mo"
                )
            output.log("")

        if report.optimizations:
            output.log(
                f"[bold green]Optimization Recommendations ({len(report.optimizations)})[/bold green]"
            )
            for opt in report.optimizations[:5]:
                output.log(f"  - {opt.description}")
                output.log(
                    f"    [dim]Potential savings: ${opt.estimated_savings:.2f}/mo[/dim]"
                )
            output.log("")

    elif output_format == "json":
        output_path = output_file or Path("transfer_analysis.json")
        with open(output_path, "w") as f:
            json_module.dump(report.to_dict(), f, indent=2)
        output.success(f"Saved to {output_path}")

    # JSON mode output
    if output.is_json:
        output.present(report.to_dict())

    output.log("")


def register(app: typer.Typer, panel: str | None = None) -> None:
    """Register the transfer command with the Typer app."""
    app.command(name="transfer", rich_help_panel=panel)(
        enhanced_cli_error_handler(transfer_command)
    )
