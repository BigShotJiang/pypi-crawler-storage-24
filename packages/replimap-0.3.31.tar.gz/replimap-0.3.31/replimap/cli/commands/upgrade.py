"""Upgrade command group for RepliMap CLI.

V3 Architecture:
- Uses @enhanced_cli_error_handler for structured error handling
- Uses ctx.obj.output for stdout hygiene (stderr for progress, stdout for results)
- JSON mode available via global --format flag
- Updated pricing: PRO ($29), TEAM ($99), SOVEREIGN ($2,500)
"""

from __future__ import annotations

import webbrowser
from typing import TYPE_CHECKING

import typer

from replimap.cli.errors import EXIT_GENERAL_ERROR, enhanced_cli_error_handler

if TYPE_CHECKING:
    from replimap.cli.context import GlobalContext
    from replimap.cli.output import OutputManager

# Constants
PRICING_URL = "https://replimap.com/pricing"
CHECKOUT_URLS = {
    "pro": "https://replimap.com/checkout/pro",
    "team": "https://replimap.com/checkout/team",
    "sovereign": "https://replimap.com/contact",
}


def _show_upgrade_info(plan_name: str, output: OutputManager) -> None:
    """Show upgrade information and open browser."""
    from replimap.licensing.models import Plan, get_plan_features

    plan_map = {
        "pro": Plan.PRO,
        "team": Plan.TEAM,
        "sovereign": Plan.SOVEREIGN,
    }

    plan = plan_map.get(plan_name.lower())
    if not plan:
        output.error(f"Unknown plan: {plan_name}")
        raise typer.Exit(EXIT_GENERAL_ERROR)

    config = get_plan_features(plan)

    output.panel(
        f"[bold blue]{config.plan.value.upper()} Plan[/bold blue]\n\n"
        f"[dim]Price:[/] ${config.price_monthly}/month\n"
        f"       ${config.price_annual_monthly}/month (billed annually)",
        border_style="blue",
    )

    features = []

    if config.max_scans_per_month is None:
        features.append("Unlimited scans")
        output.log("  [green]✓[/] Unlimited scans")

    if config.clone_download_enabled:
        features.append("Download Terraform code")
        output.log("  [green]✓[/] Download Terraform code")

    if config.audit_visible_findings is None:
        features.append("Full audit reports")
        output.log("  [green]✓[/] Full audit reports")

    if config.audit_ci_mode:
        features.append("CI/CD integration")
        output.log("  [green]✓[/] CI/CD integration")

    if config.drift_enabled:
        features.append("Drift detection")
        output.log("  [green]✓[/] Drift detection")

    if config.drift_watch_enabled:
        features.append("Drift watch mode")
        output.log("  [green]✓[/] Drift watch mode")

    if config.drift_alerts_enabled:
        features.append("Alert notifications")
        output.log("  [green]✓[/] Alert notifications")

    if config.cost_enabled:
        features.append("Cost estimation")
        output.log("  [green]✓[/] Cost estimation")

    if config.deps_enabled:
        features.append("Dependency exploration")
        output.log("  [green]✓[/] Dependency exploration")

    if config.max_aws_accounts is None or config.max_aws_accounts > 1:
        accounts = (
            "Unlimited"
            if config.max_aws_accounts is None
            else str(config.max_aws_accounts)
        )
        features.append(f"{accounts} AWS accounts")
        output.log(f"  [green]✓[/] {accounts} AWS accounts")

    url = CHECKOUT_URLS.get(plan_name.lower(), PRICING_URL)
    output.progress(f"Opening {url}...")
    webbrowser.open(url)

    # JSON mode output
    if output.is_json:
        output.present(
            {
                "plan": config.plan.value.upper(),
                "price_monthly": config.price_monthly,
                "price_annual_monthly": config.price_annual_monthly,
                "features": features,
                "url": url,
            }
        )


def create_upgrade_app() -> typer.Typer:
    """Create and return the upgrade subcommand app."""
    upgrade_app = typer.Typer(
        help="Upgrade your RepliMap plan",
        no_args_is_help=True,
    )

    @upgrade_app.command("pro")
    @enhanced_cli_error_handler
    def upgrade_pro(ctx: typer.Context) -> None:
        """Upgrade to Pro plan ($29/mo)."""
        gctx: GlobalContext = ctx.obj
        _show_upgrade_info("pro", gctx.output)

    @upgrade_app.command("team")
    @enhanced_cli_error_handler
    def upgrade_team(ctx: typer.Context) -> None:
        """Upgrade to Team plan ($99/mo)."""
        gctx: GlobalContext = ctx.obj
        _show_upgrade_info("team", gctx.output)

    @upgrade_app.command("sovereign")
    @enhanced_cli_error_handler
    def upgrade_sovereign(ctx: typer.Context) -> None:
        """Contact us for Sovereign plan ($2,500/mo)."""
        gctx: GlobalContext = ctx.obj
        _show_upgrade_info("sovereign", gctx.output)

    @upgrade_app.callback(invoke_without_command=True)
    def upgrade_default(ctx: typer.Context) -> None:
        """Show available plans."""
        if ctx.invoked_subcommand is None:
            gctx: GlobalContext = ctx.obj
            output = gctx.output

            output.panel(
                "[bold blue]RepliMap Plans[/bold blue]\n\n"
                "[dim]Pro[/]       $29/mo    - Download code, full reports, 30-day history\n"
                "[dim]Team[/]      $99/mo    - Drift alerts, CI --fail-on-drift, Trust Center\n"
                "[dim]Sovereign[/] $2,500/mo - Offline, signatures, compliance, white-label",
                border_style="blue",
            )

            output.log("Usage: [bold]replimap upgrade <plan>[/]")
            output.log("  [dim]replimap upgrade pro[/]")
            output.log("  [dim]replimap upgrade team[/]")
            output.log("  [dim]replimap upgrade sovereign[/]")

            output.progress(f"Opening {PRICING_URL}...")
            webbrowser.open(PRICING_URL)

            # JSON mode output
            if output.is_json:
                output.present(
                    {
                        "plans": [
                            {"name": "Pro", "price": "$29/mo"},
                            {"name": "Team", "price": "$99/mo"},
                            {"name": "Sovereign", "price": "$2,500/mo"},
                        ],
                        "url": PRICING_URL,
                    }
                )

    return upgrade_app


def register(app: typer.Typer, panel: str | None = None) -> None:
    """Register the upgrade command group with the Typer app."""
    upgrade_app = create_upgrade_app()
    app.add_typer(upgrade_app, name="upgrade", rich_help_panel=panel)
