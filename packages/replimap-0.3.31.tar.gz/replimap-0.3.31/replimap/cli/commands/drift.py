"""Drift detection command for RepliMap CLI.

V3 Architecture:
- Uses @enhanced_cli_error_handler for structured error handling
- Uses ctx.obj.output for stdout hygiene (NEVER use console.print directly)
- JSON mode available via global --format flag
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import TYPE_CHECKING, Any

import typer
from rich import box
from rich.table import Table

from replimap.cli.errors import (
    EXIT_GENERAL_ERROR,
    EXIT_SUCCESS,
    enhanced_cli_error_handler,
)
from replimap.cli.utils import get_aws_session, resolve_effective_region
from replimap.core.browser import open_in_browser
from replimap.licensing import check_drift_allowed

if TYPE_CHECKING:
    from replimap.cli.context import GlobalContext
    from replimap.cli.output import OutputManager


def _load_graph(graph_file: Path):
    """Load a graph from file (supports both JSON and SQLite formats)."""
    suffix = graph_file.suffix.lower()

    if suffix == ".db":
        from replimap.core.unified_storage import GraphEngineAdapter

        return GraphEngineAdapter(db_path=str(graph_file))
    elif suffix == ".json":
        from replimap.core.graph_engine import GraphEngine

        return GraphEngine.load(graph_file)
    else:
        # Try SQLite first
        try:
            with open(graph_file, "rb") as f:
                if f.read(16).startswith(b"SQLite format"):
                    from replimap.core.unified_storage import GraphEngineAdapter

                    return GraphEngineAdapter(db_path=str(graph_file))
        except (OSError, ValueError):
            pass  # Fall through to JSON loader
        from replimap.core.graph_engine import GraphEngine

        return GraphEngine.load(graph_file)


# Create a Typer app for drift subcommands
drift_app = typer.Typer(
    help="Infrastructure drift detection commands",
    no_args_is_help=False,
)


def drift_command(
    ctx: typer.Context,
    profile: str | None = typer.Option(
        None,
        "--profile",
        "-p",
        help="AWS profile name",
    ),
    region: str | None = typer.Option(
        None,
        "--region",
        "-r",
        help="AWS region to scan",
    ),
    state: Path | None = typer.Option(
        None,
        "--state",
        "-s",
        help="Path to terraform.tfstate file",
    ),
    state_bucket: str | None = typer.Option(
        None,
        "--state-bucket",
        help="S3 bucket for remote state",
    ),
    state_key: str | None = typer.Option(
        None,
        "--state-key",
        help="S3 key for remote state",
    ),
    vpc: str | None = typer.Option(
        None,
        "--vpc",
        "-v",
        help="VPC ID to scope the scan (optional)",
    ),
    output_file: Path | None = typer.Option(
        None,
        "--output",
        "-o",
        help="Output file path (HTML or JSON)",
    ),
    report_format: str = typer.Option(
        "console",
        "--format",
        "-f",
        help="Output format: console, html, or json",
    ),
    fail_on_drift: bool = typer.Option(
        False,
        "--fail-on-drift",
        help="Exit with code 1 if any drift detected (for CI/CD)",
    ),
    fail_on_high: bool = typer.Option(
        False,
        "--fail-on-high",
        help="Exit with code 1 only for HIGH/CRITICAL drift (for CI/CD)",
    ),
    open_report: bool = typer.Option(
        True,
        "--open/--no-open",
        help="Open HTML report in browser after generation",
    ),
    no_cache: bool = typer.Option(
        False,
        "--no-cache",
        help="Don't use cached credentials",
    ),
    refresh: bool = typer.Option(
        False,
        "--refresh",
        "-R",
        help="Force fresh AWS scan (ignore cached graph)",
    ),
    # === Compliance Options ===
    compliance: str | None = typer.Option(
        None,
        "--compliance",
        "-c",
        help=(
            "Enable compliance drift mode. Filter to compliance-relevant attributes "
            "and map findings to framework controls. "
            "Values: soc2, pcidss, hipaa, all"
        ),
        rich_help_panel="Auditing & Compliance",
    ),
    ignore_file: Path | None = typer.Option(
        None,
        "--ignore-file",
        help="Path to .replimap-ignore.yml exemption file [default: .replimap-ignore.yml]",
        rich_help_panel="Auditing & Compliance",
    ),
) -> None:
    """Detect infrastructure drift between Terraform state and AWS.

    \b

    Compares your Terraform state file against the actual AWS resources
    to identify changes made outside of Terraform (console, CLI, etc).

    \b

    State Sources:

    - Local file: --state ./terraform.tfstate

    - S3 remote: --state-bucket my-bucket --state-key path/terraform.tfstate

    \b

    Output formats:

    - console: Rich terminal output (default)

    - html: Professional HTML report

    - json: Machine-readable JSON

    \b

    Examples:

        replimap drift -r us-east-1 -s ./terraform.tfstate

        replimap drift -r us-east-1 --state-bucket my-bucket
            --state-key prod/tf.tfstate

        replimap drift -r us-east-1 -s ./tf.tfstate -f html -o report.html

        replimap drift -r us-east-1 -s ./tf.tfstate --fail-on-drift --no-open

        replimap drift -r us-east-1 -s ./tf.tfstate --fail-on-high --no-open
    \b
        # Compliance mode: SOC 2 drift analysis
        replimap drift -r us-east-1 -s ./tf.tfstate --compliance soc2
    \b
        # Compliance with exemptions
        replimap drift -r us-east-1 -s ./tf.tfstate -c all --ignore-file .replimap-ignore.yml
    \b
        # Compliance markdown report
        replimap drift -r us-east-1 -s ./tf.tfstate -c soc2 -f markdown -o report.md

    \b
    DATA SOVEREIGNTY: RepliMap drift runs entirely on your local machine.
    No state data, credentials, or results are sent to any external service.
    """
    from replimap.drift import DriftEngine, DriftReporter

    # Get V3 context
    gctx: GlobalContext = ctx.obj
    output = gctx.output

    # Check drift feature access (Pro+ feature)
    drift_gate = check_drift_allowed()
    if not drift_gate.allowed:
        output.error(drift_gate.prompt)
        raise typer.Exit(EXIT_GENERAL_ERROR)

    # Determine region: flag > profile config > default
    effective_region, region_source = resolve_effective_region(region, profile)

    # Validate inputs
    if not state and not (state_bucket and state_key):
        output.panel(
            "[red]Either --state or --state-bucket/--state-key is required.[/]\n\n"
            "Examples:\n"
            "  [bold]replimap drift -r us-east-1 -s ./terraform.tfstate[/]\n"
            "  [bold]replimap drift -r us-east-1 --state-bucket my-bucket --state-key prod/terraform.tfstate[/]",
            title="Missing State Source",
            border_style="red",
        )
        raise typer.Exit(EXIT_GENERAL_ERROR)

    # Determine state source for display
    if state:
        state_display = str(state)
    else:
        state_display = f"s3://{state_bucket}/{state_key}"

    output.log("")
    output.panel(
        f"[bold orange1]RepliMap Drift Detector[/bold orange1]\n\n"
        f"Region: [cyan]{effective_region}[/] [dim](from {region_source})[/]\n"
        f"Profile: [cyan]{profile or 'default'}[/]\n"
        + (f"VPC: [cyan]{vpc}[/]\n" if vpc else "")
        + f"State: [cyan]{state_display}[/]\n"
        f"Format: [cyan]{report_format}[/]",
        border_style="orange1",
    )

    # Get AWS session
    session = get_aws_session(profile, effective_region, use_cache=not no_cache)

    # Build remote backend config if using S3
    remote_backend = None
    if state_bucket and state_key:
        remote_backend = {
            "bucket": state_bucket,
            "key": state_key,
            "region": effective_region,
        }

    # Try to use cached graph for AWS state
    from replimap.core.cache_manager import get_or_load_graph, save_graph_to_cache

    # Run drift detection (global signal handler handles Ctrl-C)
    try:
        output.log("")
        cached_graph, cache_meta = get_or_load_graph(
            profile=profile or "default",
            region=effective_region,
            console=output._stderr_console,
            refresh=refresh,
            vpc=vpc,
        )
        with output.spinner("Detecting drift..."):
            engine = DriftEngine(
                session=session,
                region=effective_region,
                profile=profile,
            )

            report = engine.detect(
                state_path=state,
                remote_backend=remote_backend,
                vpc_id=vpc,
                graph=cached_graph,
            )

            # Save to cache if we did a fresh scan
            if cached_graph is None and hasattr(engine, "_graph"):
                save_graph_to_cache(
                    graph=engine._graph,
                    profile=profile or "default",
                    region=effective_region,
                    console=output._stderr_console,
                    vpc=vpc,
                )
    except FileNotFoundError as e:
        output.log("")
        output.panel(
            f"[red]State file not found:[/]\n{e}",
            title="Error",
            border_style="red",
        )
        raise typer.Exit(EXIT_GENERAL_ERROR)
    except Exception as e:
        output.log("")
        output.panel(
            f"[red]Drift detection failed:[/]\n{e}",
            title="Error",
            border_style="red",
        )
        raise typer.Exit(EXIT_GENERAL_ERROR)

    # ── Compliance post-processing (when --compliance is set) ──────────
    compliance_report = None
    if compliance is not None:
        from replimap.compliance.drift.exemptions import ExemptionManager
        from replimap.compliance.drift.mapping import ComplianceMappingEngine

        # Map CLI shorthand to framework names
        framework_map = {
            "soc2": "SOC 2",
            "pcidss": "PCI DSS",
            "hipaa": "HIPAA",
            "all": "all",
        }
        framework = framework_map.get(compliance, compliance)

        engine = ComplianceMappingEngine(framework=framework)
        compliance_report = engine.map(report)

        # Apply exemptions
        effective_ignore = ignore_file or Path(".replimap-ignore.yml")
        if effective_ignore.exists():
            exemptions = ExemptionManager.from_file(effective_ignore)
            exemptions.apply(compliance_report)
            if exemptions.exemption_count > 0:
                output.log(
                    f"Applied {exemptions.exemption_count} exemption(s) "
                    f"from {effective_ignore}"
                )

    # ── Output ──────────────────────────────────────────────────────────

    # If compliance mode is active, show compliance report instead
    if compliance_report is not None:
        _display_compliance_report(
            compliance_report, report_format, output_file, output
        )

        # Compliance-specific exit codes
        exit_code = EXIT_SUCCESS
        if compliance_report.has_critical_or_high:
            exit_code = EXIT_GENERAL_ERROR  # 1 = critical/high findings
        elif compliance_report.has_findings:
            exit_code = 2  # 2 = medium/low only

        # JSON mode
        if output.is_json:
            output.present(compliance_report.to_dict())

        if exit_code != EXIT_SUCCESS:
            raise typer.Exit(exit_code)
        return

    # ── Standard (non-compliance) output ────────────────────────────────
    reporter = DriftReporter()

    # Console output (always show summary)
    if report_format == "console" or not output_file:
        output.log("")
        if report.has_drift:
            output.panel(
                f"[bold red]DRIFT DETECTED[/bold red]\n\n"
                f"[red]Total drifts:[/] {report.drifted_resources}\n"
                f"[green]  Added (not in TF):[/] {report.added_resources}\n"
                f"[red]  Removed (deleted):[/] {report.removed_resources}\n"
                f"[yellow]  Modified:[/] {report.modified_resources}",
                border_style="red",
            )

            # Show high priority drifts
            critical_high = report.critical_drifts + report.high_drifts
            if critical_high:
                output.log("")
                output.log("[bold red]High Priority Drifts:[/bold red]")
                for d in critical_high[:5]:
                    drift_icon = {"added": "+", "removed": "-", "modified": "~"}.get(
                        d.drift_type.value, "?"
                    )
                    output.log(
                        f"  [{d.severity.value.upper()}] [{drift_icon}] {d.resource_type}: {d.resource_id}"
                    )
                if len(critical_high) > 5:
                    output.progress(f"  ... and {len(critical_high) - 5} more")
        else:
            output.panel(
                f"[bold green]NO DRIFT[/bold green]\n\n"
                f"Your AWS resources match your Terraform state.\n"
                f"Total resources checked: {report.total_resources}",
                border_style="green",
            )

    # HTML output
    if report_format == "html" or (output_file and output_file.suffix == ".html"):
        out_path = output_file or Path("./drift-report.html")
        reporter.to_html(report, out_path)
        output.log("")
        output.success(f"HTML report: {out_path.absolute()}")
        if open_report:
            open_in_browser(out_path, console=output._stderr_console)

    # JSON output
    if report_format == "json" or (output_file and output_file.suffix == ".json"):
        out_path = output_file or Path("./drift-report.json")
        reporter.to_json(report, out_path)
        output.log("")
        output.success(f"JSON report: {out_path.absolute()}")

    # CI/CD exit codes
    exit_code = EXIT_SUCCESS

    if fail_on_drift and report.has_drift:
        output.log("")
        output.error(f"CI/CD FAILED: {report.drifted_resources} drift(s) detected")
        exit_code = EXIT_GENERAL_ERROR

    if fail_on_high and (report.critical_drifts or report.high_drifts):
        high_count = len(report.critical_drifts) + len(report.high_drifts)
        output.log("")
        output.error(f"CI/CD FAILED: {high_count} HIGH/CRITICAL drift(s)")
        exit_code = EXIT_GENERAL_ERROR

    if exit_code == EXIT_SUCCESS and (fail_on_drift or fail_on_high):
        output.log("")
        output.success("CI/CD PASSED: No significant drift")

    output.log("")
    output.progress(f"Scan completed in {report.scan_duration_seconds}s")
    output.log("")

    # JSON mode: present structured data
    if output.is_json:
        output.present(
            {
                "has_drift": report.has_drift,
                "total_resources": report.total_resources,
                "drifted_resources": report.drifted_resources,
                "added_resources": report.added_resources,
                "removed_resources": report.removed_resources,
                "modified_resources": report.modified_resources,
                "scan_duration_seconds": report.scan_duration_seconds,
            }
        )

    if exit_code != EXIT_SUCCESS:
        raise typer.Exit(exit_code)


@drift_app.command("offline")
@enhanced_cli_error_handler
def offline_detect_command(
    ctx: typer.Context,
    profile: str = typer.Option(
        "default",
        "-p",
        "--profile",
        help="RepliMap profile (cached scan)",
    ),
    state_file: str = typer.Option(
        "./terraform.tfstate",
        "-s",
        "--state",
        help="Path to terraform.tfstate",
    ),
    output_file: str | None = typer.Option(
        None,
        "-o",
        "--output",
        help="Output JSON report file",
    ),
    sarif: str | None = typer.Option(
        None,
        "--sarif",
        help="Output SARIF file for GitHub Security",
    ),
    fail_on_drift: bool = typer.Option(
        False,
        "--fail-on-drift",
        help="Exit code 1 if drift detected (for CI/CD)",
    ),
    severity: str = typer.Option(
        "low",
        "--severity",
        help="Minimum severity to report: critical, high, medium, low",
    ),
    ignore_config: str | None = typer.Option(
        None,
        "--ignore",
        help="Path to .replimapignore file",
    ),
    quiet: bool = typer.Option(
        False,
        "-q",
        "--quiet",
        help="Minimal output (for scripts)",
    ),
) -> None:
    """Offline drift detection using cached RepliMap scan.

    \b

    This is an "offline terraform plan" - faster and doesn't require
    AWS connection or Terraform installation. Uses cached scan data.

    \b

    Examples:

        # Basic offline drift detection
        replimap drift offline -p prod -s ./terraform.tfstate

        # For CI/CD (fail on drift)
        replimap drift offline -p prod --fail-on-drift

        # Only critical/high severity
        replimap drift offline -p prod --severity high

        # With custom ignore rules
        replimap drift offline -p prod --ignore .replimapignore

        # Output for GitHub Security
        replimap drift offline -p prod --sarif drift-results.sarif
    """
    from replimap.core.cache_manager import get_cache_path
    from replimap.core.drift import DriftFilter, DriftSeverity, OfflineDriftDetector

    # Get V3 context
    gctx: GlobalContext = ctx.obj
    output = gctx.output

    state_path = Path(state_file)

    if not state_path.exists():
        output.error(f"State file not found: {state_path}")
        output.log("")
        output.progress("To create the state file:")
        output.log("  terraform state pull > terraform.tfstate")
        raise typer.Exit(EXIT_GENERAL_ERROR)

    # Load cached scan
    try:
        cache_path = get_cache_path(profile)
        if not cache_path.exists():
            output.error(f"No cached scan found for profile '{profile}'.")
            output.log(f"Run 'replimap scan -p {profile}' first.")
            raise typer.Exit(EXIT_GENERAL_ERROR)

        graph = _load_graph(cache_path)
        resources = list(graph.get_all_resources())
    except Exception as e:
        output.error(f"Failed to load cached scan: {e}")
        raise typer.Exit(EXIT_GENERAL_ERROR)

    # Convert resources to dict format for detector
    live_resources = []
    for resource in resources:
        resource_dict = {
            "id": resource.id,
            "type": getattr(resource, "terraform_type", str(resource.resource_type)),
            "name": getattr(resource, "original_name", resource.id),
            "attributes": getattr(resource, "config", {}) or {},
        }
        live_resources.append(resource_dict)

    # Load ignore rules
    drift_filter = None
    if ignore_config:
        ignore_path = Path(ignore_config)
        if ignore_path.exists():
            drift_filter = DriftFilter.from_config(ignore_path)
            if not quiet:
                output.progress(f"Loaded ignore rules from {ignore_config}")

    if not quiet:
        output.progress(
            f"Comparing {len(live_resources)} cached resources "
            f"against Terraform state..."
        )

    # Run detection
    detector = OfflineDriftDetector(ignore_filter=drift_filter)
    report = detector.detect(live_resources, state_path)

    # Filter by severity
    severity_map = {
        "critical": DriftSeverity.CRITICAL,
        "high": DriftSeverity.HIGH,
        "medium": DriftSeverity.MEDIUM,
        "low": DriftSeverity.LOW,
    }
    min_severity = severity_map.get(severity.lower(), DriftSeverity.LOW)

    severity_order = [
        DriftSeverity.CRITICAL,
        DriftSeverity.HIGH,
        DriftSeverity.MEDIUM,
        DriftSeverity.LOW,
        DriftSeverity.INFO,
    ]
    min_index = severity_order.index(min_severity)

    report.findings = [
        f
        for f in report.findings
        if severity_order.index(f.max_change_severity) <= min_index
    ]

    # Output JSON
    if output_file:
        Path(output_file).write_text(report.to_json())
        if not quiet:
            output.success(f"Report saved to {output_file}")

    # Output SARIF
    if sarif:
        sarif_data = report.to_sarif()
        Path(sarif).write_text(json.dumps(sarif_data, indent=2))
        if not quiet:
            output.success(f"SARIF saved to {sarif}")

    # Display report
    if not quiet:
        _display_offline_report(report, output)
    else:
        _display_quiet(report, output)

    # JSON mode: present structured data
    if output.is_json:
        summary = report.summary
        output.present(
            {
                "has_drift": report.has_drift,
                "findings_count": len(report.findings),
                "summary": summary,
            }
        )

    # Exit code
    if fail_on_drift and report.has_drift:
        raise typer.Exit(EXIT_GENERAL_ERROR)


@drift_app.command("compare-scans")
@enhanced_cli_error_handler
def compare_scans_command(
    ctx: typer.Context,
    profile: str = typer.Option(
        "default",
        "-p",
        "--profile",
        help="Current RepliMap profile",
    ),
    previous: str = typer.Option(
        ...,
        "--previous",
        help="Path to previous scan cache file",
    ),
    output_file: str | None = typer.Option(
        None,
        "-o",
        "--output",
        help="Output JSON report file",
    ),
) -> None:
    """Compare current scan against a previous scan.

    Useful for detecting AWS changes over time without Terraform.

    Example:

        replimap drift compare-scans -p prod --previous baseline.db
    """
    from replimap.core.cache_manager import get_cache_path
    from replimap.core.drift import ScanComparator

    # Get V3 context
    gctx: GlobalContext = ctx.obj
    output = gctx.output

    try:
        cache_path = get_cache_path(profile)
        if not cache_path.exists():
            output.error(f"No cached scan found for profile '{profile}'.")
            raise typer.Exit(EXIT_GENERAL_ERROR)

        current_graph = _load_graph(cache_path)
    except Exception as e:
        output.error(f"Failed to load current scan: {e}")
        raise typer.Exit(EXIT_GENERAL_ERROR)

    prev_path = Path(previous)
    if not prev_path.exists():
        output.error(f"Previous scan not found: {previous}")
        raise typer.Exit(EXIT_GENERAL_ERROR)

    try:
        prev_graph = _load_graph(prev_path)
    except Exception as e:
        output.error(f"Failed to load previous scan: {e}")
        raise typer.Exit(EXIT_GENERAL_ERROR)

    current_resources = list(current_graph.get_all_resources())
    prev_resources = list(prev_graph.get_all_resources())

    output.progress(
        f"Comparing {len(current_resources)} current vs "
        f"{len(prev_resources)} previous resources..."
    )

    # Convert to dict format
    def resources_to_list(resources):
        result = []
        for r in resources:
            result.append(
                {
                    "id": r.id,
                    "type": getattr(r, "terraform_type", str(r.resource_type)),
                    "name": getattr(r, "original_name", r.id),
                    "attributes": getattr(r, "config", {}) or {},
                }
            )
        return result

    comparator = ScanComparator()
    report = comparator.compare(
        resources_to_list(current_resources),
        resources_to_list(prev_resources),
    )

    if output_file:
        Path(output_file).write_text(report.to_json())
        output.success(f"Report saved to {output_file}")

    _display_offline_report(report, output)

    # JSON mode: present structured data
    if output.is_json:
        summary = report.summary
        output.present(
            {
                "has_drift": report.has_drift,
                "findings_count": len(report.findings),
                "summary": summary,
            }
        )


def _display_compliance_report(
    compliance_report: Any,
    report_format: str,
    output_file: Path | None,
    output: OutputManager,
) -> None:
    """Display compliance drift report in the requested format."""
    from rich.table import Table
    from rich.text import Text

    from replimap.compliance.drift.report import (
        write_markdown_report,
    )

    summary = compliance_report.summary()

    _SEVERITY_STYLE = {
        "critical": "bold red",
        "high": "yellow",
        "medium": "cyan",
        "low": "dim",
    }

    # Console output (always show)
    if report_format in ("console", "markdown") or not output_file:
        output.log("")
        if compliance_report.has_findings or compliance_report.exempted:
            # Rich Table with columns: Severity, Resource, Attribute, Controls
            table = Table(
                title=f"Compliance Drift — {compliance_report.framework}",
                show_header=True,
                header_style="bold cyan",
            )
            table.add_column("Severity", width=10)
            table.add_column("Resource", min_width=20)
            table.add_column("Attribute", min_width=15)
            table.add_column("Controls", min_width=20)

            for f in compliance_report.findings:
                style = _SEVERITY_STYLE.get(f.severity, "")
                controls_str = ", ".join(
                    f"{c.framework} {c.control_id}" for c in f.controls
                )
                table.add_row(
                    Text(f.severity.upper(), style=style),
                    Text(f.tf_address),
                    Text(f.attribute),
                    Text(controls_str),
                )

            # Exempted items with strikethrough
            for f in compliance_report.exempted:
                controls_str = ", ".join(
                    f"{c.framework} {c.control_id}" for c in f.controls
                )
                table.add_row(
                    Text(f.severity.upper(), style="strike dim"),
                    Text(f.tf_address, style="strike dim"),
                    Text(f.attribute, style="strike dim"),
                    Text("Exempted", style="strike dim"),
                )

            output._stderr_console.print(table)

            # Summary line
            output.log(
                f"\nSummary: "
                f"[red]{summary['critical']} critical[/], "
                f"[yellow]{summary['high']} high[/], "
                f"{summary['medium']} medium, "
                f"{summary['low']} low"
                f" | {summary['exempted']} exempted"
            )
        else:
            output.panel(
                f"[bold green]COMPLIANT[/bold green]\n\n"
                f"Framework: [cyan]{compliance_report.framework}[/]\n"
                f"No compliance drift detected.\n"
                f"Exempted: {summary['exempted']}",
                border_style="green",
            )

    # Markdown output
    if report_format == "markdown":
        out_path = output_file or Path("./compliance-drift-report.md")
        write_markdown_report(compliance_report, out_path)
        output.log("")
        output.success(f"Markdown report: {out_path.absolute()}")

    # JSON output
    if report_format == "json":
        import json as json_mod

        out_path = output_file or Path("./compliance-drift-report.json")
        out_path.write_text(json_mod.dumps(compliance_report.to_dict(), indent=2))
        output.log("")
        output.success(f"JSON report: {out_path.absolute()}")

    # HTML (generate markdown as content for now)
    if report_format == "html":
        out_path = output_file or Path("./compliance-drift-report.md")
        write_markdown_report(compliance_report, out_path)
        output.log("")
        output.success(f"Report: {out_path.absolute()}")

    output.log("")
    output.progress(f"Scan completed in {compliance_report.scan_duration_seconds:.1f}s")
    output.log("")


def _display_offline_report(report, output: OutputManager) -> None:
    """Display drift report with rich formatting."""
    from replimap.core.drift import DriftType

    output.log("")

    if not report.has_drift:
        output.panel(
            "[bold green]No drift detected![/bold green]\n\nInfrastructure is in sync.",
            title="Drift Report",
            border_style="green",
        )
        return

    # Summary panel
    summary = report.summary
    border_color = "red" if report.critical_count > 0 else "yellow"

    unmanaged = summary.get("by_drift_type", {}).get("unmanaged", 0)
    missing = summary.get("by_drift_type", {}).get("missing", 0)
    drifted = summary.get("by_drift_type", {}).get("drifted", 0)

    critical = summary.get("by_severity", {}).get("critical", 0)
    high = summary.get("by_severity", {}).get("high", 0)
    medium = summary.get("by_severity", {}).get("medium", 0)
    low = summary.get("by_severity", {}).get("low", 0)

    output.panel(
        f"[bold]Found {len(report.findings)} drift findings[/bold]\n\n"
        f"By Type:\n"
        f"   Unmanaged: {unmanaged}\n"
        f"   Missing: {missing}\n"
        f"   Drifted: {drifted}\n\n"
        f"By Severity:\n"
        f"   Critical: {critical}\n"
        f"   High: {high}\n"
        f"   Medium: {medium}\n"
        f"   Low: {low}",
        title="Drift Report",
        border_style=border_color,
    )

    # Group findings by type
    by_type: dict = {}
    for finding in report.findings:
        if finding.drift_type not in by_type:
            by_type[finding.drift_type] = []
        by_type[finding.drift_type].append(finding)

    # Display each type
    for drift_type in [DriftType.MISSING, DriftType.DRIFTED, DriftType.UNMANAGED]:
        findings = by_type.get(drift_type, [])
        if not findings:
            continue

        output.log("")
        output.log(f"[bold]{drift_type.value.upper()} ({len(findings)})[/bold]")

        table = Table(box=box.ROUNDED, show_header=True)
        table.add_column("Resource", style="cyan", width=35)
        table.add_column("Type", width=25)
        table.add_column("Changes / Status", width=45)

        for finding in findings[:10]:
            # Build changes display
            if finding.changes:
                changes_text = ""
                for c in finding.changes[:3]:
                    changes_text += (
                        f"[{c.severity.value}] {c.field}: "
                        f"[red]{_truncate(c.expected)}[/] -> "
                        f"[green]{_truncate(c.actual)}[/]\n"
                    )
                if len(finding.changes) > 3:
                    changes_text += f"[dim]...and {len(finding.changes) - 3} more[/dim]"
            else:
                changes_text = f"[dim]{drift_type.value}[/dim]"

            # Resource info
            resource_text = finding.resource_name
            if finding.terraform_address:
                resource_text += f"\n[dim]{finding.terraform_address}[/dim]"
            resource_id_display = finding.resource_id
            if len(resource_id_display) > 40:
                resource_id_display = resource_id_display[:40] + "..."
            resource_text += f"\n[dim]{resource_id_display}[/dim]"

            table.add_row(
                resource_text,
                finding.resource_type,
                changes_text.strip(),
            )

        output._stderr_console.print(table)

        if len(findings) > 10:
            output.progress(f"  ...and {len(findings) - 10} more")

        # Remediation hint
        output.log("")
        output.progress(f"   {findings[0].remediation_hint}")


def _display_quiet(report, output: OutputManager) -> None:
    """Minimal output for scripts."""
    if not report.has_drift:
        output.log("NO_DRIFT")
        return

    output.log(f"DRIFT_FOUND:{len(report.findings)}")
    output.log(f"CRITICAL:{report.critical_count}")
    output.log(f"HIGH:{report.high_count}")


def _truncate(val, max_len: int = 25) -> str:
    """Truncate value for display."""
    if val is None:
        return "null"
    s = str(val)
    if len(s) > max_len:
        return s[: max_len - 3] + "..."
    return s


def register(app: typer.Typer, panel: str | None = None) -> None:
    """Register the drift command with the Typer app."""
    # Register the main drift command (online detection)
    app.command(name="drift", rich_help_panel=panel)(
        enhanced_cli_error_handler(drift_command)
    )
    # Also add drift as a subcommand group for offline detection
    app.add_typer(
        drift_app,
        name="drift-offline",
        help="Offline drift detection",
        rich_help_panel=panel,
    )
