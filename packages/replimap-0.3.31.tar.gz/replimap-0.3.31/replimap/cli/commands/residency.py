"""Data Residency validation command for RepliMap CLI.

V3 Architecture:
- Uses @enhanced_cli_error_handler for structured error handling
- Uses ctx.obj.output for stdout hygiene (stderr for progress, stdout for results)
- JSON mode available via global --format flag

Validates that infrastructure data stays within approved NZ/AU regions.
Detects cross-region replication, global tables, and CloudFront without geo-restriction.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import typer

from replimap.cli.errors import EXIT_USAGE_ERROR, enhanced_cli_error_handler
from replimap.cli.utils import get_aws_session, resolve_effective_region

if TYPE_CHECKING:
    from replimap.cli.context import GlobalContext


_POLICY_CHOICES = ["nz_au", "au_only", "custom"]


def residency_command(
    ctx: typer.Context,
    # === Common Options ===
    profile: str | None = typer.Option(
        None,
        "--profile",
        "-p",
        help="AWS profile name",
    ),
    region: str | None = typer.Option(
        None,
        "--region",
        "-r",
        help="AWS region",
    ),
    vpc: str | None = typer.Option(
        None,
        "--vpc",
        "-v",
        help="VPC ID to scope the check (optional)",
    ),
    # === Policy Configuration ===
    policy: str = typer.Option(
        "nz_au",
        "--policy",
        help="Residency policy preset: nz_au, au_only, custom",
        rich_help_panel="Policy Configuration",
    ),
    custom_regions: list[str] | None = typer.Option(
        None,
        "--approved-region",
        help="Approved region (repeatable, for --policy custom)",
        rich_help_panel="Policy Configuration",
    ),
    # === Cache & Performance ===
    no_cache: bool = typer.Option(
        False,
        "--no-cache",
        help="Don't use cached credentials",
        rich_help_panel="Cache & Performance",
    ),
    refresh: bool = typer.Option(
        False,
        "--refresh",
        "-R",
        help="Force fresh AWS scan (ignore cached graph)",
        rich_help_panel="Cache & Performance",
    ),
) -> None:
    """Validate data residency compliance for NZ/AU sovereignty.

    \b

    Checks that infrastructure data stays within approved regions.
    Detects cross-region replication, global tables, read replicas,
    and CloudFront distributions without geo-restriction.

    \b

    Supports three policy presets:
    - nz_au: Australia + New Zealand regions (default)
    - au_only: Australia regions only
    - custom: Specify approved regions with --approved-region

    \b

    Examples:

        replimap residency -p prod -r ap-southeast-2

        replimap residency --policy au_only -r ap-southeast-2

        replimap residency --policy custom --approved-region us-east-1 --approved-region eu-west-1

        replimap residency -r ap-southeast-2 --format json
    """
    from rich.progress import Progress, SpinnerColumn, TextColumn

    from replimap.compliance.data_residency import (
        DataResidencyPolicy,
        DataResidencyValidator,
        ViolationSeverity,
    )
    from replimap.core import GraphEngine
    from replimap.core.cache_manager import get_or_load_graph, save_graph_to_cache
    from replimap.scanners.base import run_all_scanners

    # Get V3 context
    gctx: GlobalContext = ctx.obj
    output = gctx.output

    # Determine region
    effective_region, region_source = resolve_effective_region(region, profile)

    # Build policy
    if policy == "au_only":
        residency_policy = DataResidencyPolicy.au_only()
    elif policy == "custom":
        if not custom_regions:
            output.error("--policy custom requires at least one --approved-region")
            raise typer.Exit(EXIT_USAGE_ERROR)
        residency_policy = DataResidencyPolicy.custom(
            name="Custom Policy",
            regions=custom_regions,
        )
    else:
        residency_policy = DataResidencyPolicy.nz_au()

    output.log("")
    output.panel(
        f"[bold blue]Data Residency Validation[/bold blue]\n\n"
        f"Region: [cyan]{effective_region}[/] [dim](from {region_source})[/]\n"
        f"Profile: [cyan]{profile or 'default'}[/]\n"
        + (f"VPC: [cyan]{vpc}[/]\n" if vpc else "")
        + f"Policy: [cyan]{residency_policy.name}[/]\n"
        f"Approved: [cyan]{', '.join(sorted(residency_policy.approved_regions))}[/]",
        border_style="blue",
    )

    # Get AWS session
    session = get_aws_session(profile, effective_region, use_cache=not no_cache)
    stderr_console = output._stderr_console

    # Try to load from cache first
    output.log("")
    cached_graph, _ = get_or_load_graph(
        profile=profile or "default",
        region=effective_region,
        console=stderr_console,
        refresh=refresh,
        vpc=vpc,
    )

    graph = cached_graph
    if graph is None:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=stderr_console,
        ) as progress:
            task = progress.add_task("Scanning AWS resources...", total=None)
            graph = GraphEngine()
            run_all_scanners(session, effective_region, graph)
            progress.update(task, completed=True)

        # Apply VPC filter if specified
        if vpc:
            from replimap.core import ScanFilter, apply_filter_to_graph

            filter_config = ScanFilter(
                vpc_ids=[vpc],
                include_vpc_resources=True,
            )
            graph = apply_filter_to_graph(graph, filter_config)

        # Save to cache
        save_graph_to_cache(
            graph=graph,
            profile=profile or "default",
            region=effective_region,
            console=stderr_console,
            vpc=vpc,
        )

    # Apply VPC filter for cached graph
    if cached_graph is not None and vpc:
        from replimap.core import ScanFilter, apply_filter_to_graph

        filter_config = ScanFilter(
            vpc_ids=[vpc],
            include_vpc_resources=True,
        )
        graph = apply_filter_to_graph(graph, filter_config)

    # Run validation
    with output.spinner("Validating data residency..."):
        validator = DataResidencyValidator(residency_policy)
        report = validator.validate(graph)

    output.log("")

    # JSON mode: present structured result to stdout
    if output.is_json:
        output.present(report.to_dict())
        return

    # Human-readable output
    if report.is_compliant:
        output.success(
            f"COMPLIANT — All {report.resources_checked} resources within approved regions"
        )
    else:
        severity_colors = {
            ViolationSeverity.CRITICAL: "red",
            ViolationSeverity.HIGH: "orange1",
            ViolationSeverity.MEDIUM: "yellow",
            ViolationSeverity.INFO: "dim",
        }

        output.error(
            f"NON-COMPLIANT — {len(report.violations)} violation(s) found "
            f"across {report.resources_checked} resources"
        )
        output.log("")

        # Severity breakdown
        breakdown = report.to_dict()["severity_breakdown"]
        parts = []
        if breakdown["critical"]:
            parts.append(f"[red]CRITICAL: {breakdown['critical']}[/]")
        if breakdown["high"]:
            parts.append(f"[orange1]HIGH: {breakdown['high']}[/]")
        if breakdown["medium"]:
            parts.append(f"[yellow]MEDIUM: {breakdown['medium']}[/]")
        if breakdown["info"]:
            parts.append(f"[dim]INFO: {breakdown['info']}[/]")
        if parts:
            output.log(f"  Severity: {' | '.join(parts)}")
            output.log("")

        # Show violations grouped by type
        violations_by_type: dict[str, list] = {}
        for v in report.violations:
            violations_by_type.setdefault(v.violation_type, []).append(v)

        for vtype, violations in violations_by_type.items():
            output.log(f"[bold]{vtype}[/bold] ({len(violations)})")
            for v in violations[:10]:
                color = severity_colors.get(v.severity, "white")
                output.log(
                    f"  [{color}]{v.severity.value.upper()}[/] "
                    f"{v.resource_id} — {v.reason}"
                )
                output.log(f"    [dim]Remediation: {v.remediation}[/]")
            if len(violations) > 10:
                output.log(f"  [dim]... and {len(violations) - 10} more[/]")
            output.log("")

    # Summary
    output.log(
        f"[bold]Summary:[/] {report.resources_compliant}/{report.resources_checked} "
        f"resources compliant with {residency_policy.name}"
    )
    output.log("")


def register(app: typer.Typer, panel: str | None = None) -> None:
    """Register the residency command with the Typer app."""
    app.command(name="residency", rich_help_panel=panel)(
        enhanced_cli_error_handler(residency_command)
    )
