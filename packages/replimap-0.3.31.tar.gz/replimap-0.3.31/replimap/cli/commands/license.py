"""
License commands - License management for RepliMap.

V3 Architecture:
- Uses @enhanced_cli_error_handler for structured error handling
- Uses ctx.obj.output for stdout hygiene (stderr for progress, stdout for results)
- JSON mode available via global --format flag
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import typer
from rich.table import Table

from replimap.cli.errors import (
    EXIT_GENERAL_ERROR,
    EXIT_SUCCESS,
    enhanced_cli_error_handler,
)
from replimap.licensing import Feature, LicenseStatus, LicenseValidationError
from replimap.licensing.manager import get_license_manager
from replimap.licensing.tracker import get_usage_tracker

if TYPE_CHECKING:
    from replimap.cli.context import GlobalContext


def create_license_app() -> typer.Typer:
    """Create the license sub-command group."""
    license_app = typer.Typer(
        name="license",
        help="License management commands",
        rich_markup_mode="rich",
        context_settings={"help_option_names": ["-h", "--help"]},
    )

    @license_app.command("activate")
    @enhanced_cli_error_handler
    def license_activate(
        ctx: typer.Context,
        license_key: str = typer.Argument(
            ...,
            help="License key (format: RM-XXXX-XXXX-XXXX-XXXX)",
        ),
    ) -> None:
        """
        Activate a license key.

        Examples:
            replimap license activate RM-7P0A-QB0G-ADFS-2TWU
        """
        gctx: GlobalContext = ctx.obj
        output = gctx.output

        manager = get_license_manager()

        try:
            license_obj = manager.activate(license_key)
            expires = (
                license_obj.expires_at.strftime("%Y-%m-%d")
                if license_obj.expires_at
                else "Never"
            )
            output.panel(
                f"[green]License activated successfully![/]\n\n"
                f"Plan: [bold cyan]{license_obj.plan.value.upper()}[/]\n"
                f"Email: {license_obj.email}\n"
                f"Expires: {expires}",
                title="License Activated",
                border_style="green",
            )

            # JSON mode: present structured data
            if output.is_json:
                output.present(
                    {
                        "status": "activated",
                        "plan": license_obj.plan.value,
                        "email": license_obj.email,
                        "expires": expires,
                    }
                )
        except LicenseValidationError as e:
            output.panel(
                f"[red]License activation failed:[/]\n{e}",
                title="Activation Error",
                border_style="red",
            )
            raise typer.Exit(EXIT_GENERAL_ERROR)

    @license_app.command("status")
    @enhanced_cli_error_handler
    def license_status(
        ctx: typer.Context,
    ) -> None:
        """
        Show current license status.

        Examples:
            replimap license status
        """
        gctx: GlobalContext = ctx.obj
        output = gctx.output

        manager = get_license_manager()
        status, message = manager.validate()
        license_obj = manager.current_license
        features = manager.current_features

        # Status panel
        if status == LicenseStatus.VALID:
            status_color = "green"
            status_icon = "[green]Valid[/]"
        elif status == LicenseStatus.EXPIRED:
            status_color = "red"
            status_icon = "[red]Expired[/]"
        else:
            status_color = "yellow"
            status_icon = f"[yellow]{status.value}[/]"

        plan_name = manager.current_plan.value.upper()
        if license_obj:
            expires = (
                license_obj.expires_at.strftime("%Y-%m-%d")
                if license_obj.expires_at
                else "Never"
            )
            info = (
                f"Plan: [bold cyan]{plan_name}[/]\n"
                f"Status: {status_icon}\n"
                f"Email: {license_obj.email}\n"
                f"Expires: {expires}"
            )
        else:
            expires = None
            info = (
                f"Plan: [bold cyan]{plan_name}[/]\n"
                f"Status: {status_icon}\n"
                f"[dim]No license key activated. Using free tier.[/]"
            )

        output.panel(info, title="License Status", border_style=status_color)

        # Features table
        output.log("")
        table = Table(title="Plan Features", show_header=True, header_style="bold cyan")
        table.add_column("Feature", style="dim")
        table.add_column("Available", justify="center")

        feature_display = [
            (Feature.UNLIMITED_RESOURCES, "Unlimited Resources"),
            (Feature.ASYNC_SCANNING, "Async Scanning"),
            (Feature.MULTI_ACCOUNT, "Multi-Account Support"),
            (Feature.CUSTOM_TEMPLATES, "Custom Templates"),
            (Feature.WEB_DASHBOARD, "Web Dashboard"),
            (Feature.COLLABORATION, "Team Collaboration"),
            (Feature.SSO, "SSO Integration"),
            (Feature.AUDIT_LOGS, "Audit Logs"),
        ]

        features_data = []
        for feature, display_name in feature_display:
            available = features.has_feature(feature)
            icon = "[green]Yes[/]" if available else "[dim]No[/]"
            table.add_row(display_name, icon)
            features_data.append(
                {
                    "feature": display_name,
                    "available": available,
                }
            )

        output._stderr_console.print(table)

        # Limits
        output.log("")
        limits_table = Table(
            title="Usage Limits", show_header=True, header_style="bold cyan"
        )
        limits_table.add_column("Limit", style="dim")
        limits_table.add_column("Value", justify="right")

        max_resources = (
            str(features.max_resources_per_scan)
            if features.max_resources_per_scan
            else "Unlimited"
        )
        max_scans = (
            str(features.max_scans_per_month)
            if features.max_scans_per_month
            else "Unlimited"
        )
        max_accounts = (
            str(features.max_aws_accounts) if features.max_aws_accounts else "Unlimited"
        )

        limits_table.add_row("Resources per Scan", max_resources)
        limits_table.add_row("Scans per Month", max_scans)
        limits_table.add_row("AWS Accounts", max_accounts)

        output._stderr_console.print(limits_table)

        # Usage stats
        tracker = get_usage_tracker()
        stats = tracker.get_stats()

        usage_data = None
        if stats.total_scans > 0:
            output.log("")
            usage_table = Table(
                title="Usage This Month",
                show_header=True,
                header_style="bold cyan",
            )
            usage_table.add_column("Metric", style="dim")
            usage_table.add_column("Value", justify="right")

            usage_table.add_row("Scans", str(stats.scans_this_month))
            usage_table.add_row("Resources Scanned", str(stats.resources_this_month))
            usage_table.add_row("Regions Used", str(len(stats.unique_regions)))

            output._stderr_console.print(usage_table)
            usage_data = {
                "scans_this_month": stats.scans_this_month,
                "resources_this_month": stats.resources_this_month,
                "unique_regions": len(stats.unique_regions),
            }

        output.log("")

        # JSON mode: present structured data
        if output.is_json:
            result_data = {
                "plan": plan_name,
                "status": status.value,
                "email": license_obj.email if license_obj else None,
                "expires": expires,
                "features": features_data,
                "limits": {
                    "resources_per_scan": max_resources,
                    "scans_per_month": max_scans,
                    "aws_accounts": max_accounts,
                },
            }
            if usage_data:
                result_data["usage"] = usage_data
            output.present(result_data)

    @license_app.command("deactivate")
    @enhanced_cli_error_handler
    def license_deactivate(
        ctx: typer.Context,
        confirm: bool = typer.Option(
            False,
            "--yes",
            "-y",
            help="Skip confirmation",
        ),
    ) -> None:
        """
        Deactivate the current license.

        Examples:
            replimap license deactivate --yes
        """
        gctx: GlobalContext = ctx.obj
        output = gctx.output

        manager = get_license_manager()

        if manager.current_license is None:
            output.warn("No license is currently active.")
            raise typer.Exit(EXIT_SUCCESS)

        if not confirm:
            confirm = typer.confirm("Are you sure you want to deactivate your license?")
            if not confirm:
                output.progress("Cancelled.")
                raise typer.Exit(EXIT_SUCCESS)

        manager.deactivate()
        output.success("License deactivated. You are now on the free tier.")

        # JSON mode: present structured data
        if output.is_json:
            output.present({"status": "deactivated"})

    @license_app.command("usage")
    @enhanced_cli_error_handler
    def license_usage(
        ctx: typer.Context,
    ) -> None:
        """
        Show detailed usage statistics.

        Examples:
            replimap license usage
        """
        gctx: GlobalContext = ctx.obj
        output = gctx.output

        tracker = get_usage_tracker()
        stats = tracker.get_stats()

        last_scan_str = (
            stats.last_scan.strftime("%Y-%m-%d %H:%M") if stats.last_scan else "Never"
        )

        output.panel(
            f"Total Scans: [bold]{stats.total_scans}[/]\n"
            f"Total Resources Scanned: [bold]{stats.total_resources_scanned}[/]\n"
            f"Unique Regions: [bold]{len(stats.unique_regions)}[/]\n"
            f"Last Scan: [bold]{last_scan_str}[/]",
            title="Usage Overview",
            border_style="cyan",
        )

        # Recent scans
        recent = tracker.get_recent_scans(10)
        recent_data = []
        if recent:
            output.log("")
            table = Table(
                title="Recent Scans", show_header=True, header_style="bold cyan"
            )
            table.add_column("Date", style="dim")
            table.add_column("Region")
            table.add_column("Resources", justify="right")
            table.add_column("Duration", justify="right")

            for scan in recent:
                table.add_row(
                    scan.timestamp.strftime("%Y-%m-%d %H:%M"),
                    scan.region,
                    str(scan.resource_count),
                    f"{scan.duration_seconds:.1f}s",
                )
                recent_data.append(
                    {
                        "date": scan.timestamp.strftime("%Y-%m-%d %H:%M"),
                        "region": scan.region,
                        "resources": scan.resource_count,
                        "duration_seconds": scan.duration_seconds,
                    }
                )

            output._stderr_console.print(table)

        # Resource type breakdown
        resource_type_data = {}
        if stats.resource_type_counts:
            output.log("")
            type_table = Table(
                title="Resources by Type",
                show_header=True,
                header_style="bold cyan",
            )
            type_table.add_column("Resource Type", style="dim")
            type_table.add_column("Count", justify="right")

            for rtype, count in sorted(
                stats.resource_type_counts.items(),
                key=lambda x: x[1],
                reverse=True,
            ):
                type_table.add_row(rtype, str(count))

            resource_type_data = dict(stats.resource_type_counts)

            output._stderr_console.print(type_table)

        output.log("")

        # JSON mode: present structured data
        if output.is_json:
            output.present(
                {
                    "total_scans": stats.total_scans,
                    "total_resources_scanned": stats.total_resources_scanned,
                    "unique_regions": len(stats.unique_regions),
                    "last_scan": last_scan_str,
                    "recent_scans": recent_data,
                    "resource_type_counts": resource_type_data,
                }
            )

    return license_app


def register(app: typer.Typer, panel: str | None = None) -> None:
    """Register license commands with the app."""
    app.add_typer(create_license_app(), name="license", rich_help_panel=panel)
