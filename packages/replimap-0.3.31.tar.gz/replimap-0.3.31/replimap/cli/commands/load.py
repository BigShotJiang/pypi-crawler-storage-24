"""
Load command - Load and display a saved graph.

V3 Architecture:
- Uses @enhanced_cli_error_handler for structured error handling
- Uses ctx.obj.output for stdout hygiene (stderr for progress, stdout for results)
- JSON mode available via global --format flag
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

import typer
from rich.table import Table

from replimap.cli.errors import EXIT_GENERAL_ERROR, enhanced_cli_error_handler
from replimap.cli.utils import print_graph_stats_to_output

if TYPE_CHECKING:
    from replimap.cli.context import GlobalContext


def _load_graph(graph_file: Path):
    """Load a graph from file (supports both JSON and SQLite formats)."""
    suffix = graph_file.suffix.lower()

    if suffix == ".db":
        from replimap.core.unified_storage import GraphEngineAdapter

        return GraphEngineAdapter(db_path=str(graph_file))
    elif suffix == ".json":
        from replimap.core.graph_engine import GraphEngine

        return GraphEngine.load(graph_file)
    else:
        # Try SQLite first
        try:
            with open(graph_file, "rb") as f:
                if f.read(16).startswith(b"SQLite format"):
                    from replimap.core.unified_storage import GraphEngineAdapter

                    return GraphEngineAdapter(db_path=str(graph_file))
        except (OSError, ValueError):
            pass  # Fall through to JSON loader
        from replimap.core.graph_engine import GraphEngine

        return GraphEngine.load(graph_file)


def register(app: typer.Typer, panel: str | None = None) -> None:
    """Register the load command with the app."""

    @app.command(rich_help_panel=panel)
    @enhanced_cli_error_handler
    def load(
        ctx: typer.Context,
        input_file: Path = typer.Argument(
            ...,
            help="Path to graph file (.db for SQLite, .json for legacy)",
        ),
    ) -> None:
        """Load and display a saved graph.

        Examples:

            replimap load graph.db

            replimap load graph.json
        """
        gctx: GlobalContext = ctx.obj
        output = gctx.output

        if not input_file.exists():
            output.error(f"File not found: {input_file}")
            raise typer.Exit(EXIT_GENERAL_ERROR)

        graph = _load_graph(input_file)

        output.panel(
            f"Loaded graph from [bold]{input_file}[/]",
            title="Graph Loaded",
            border_style="green",
        )

        # Print statistics
        print_graph_stats_to_output(graph, output)

        # Show resources table
        output.log("")
        table = Table(
            title="Resources (first 20)",
            show_header=True,
            header_style="bold cyan",
        )
        table.add_column("Type", style="dim")
        table.add_column("ID")
        table.add_column("Dependencies", justify="right")

        # Use safe dependency order to handle cycles
        resources = graph.get_safe_dependency_order()[:20]
        for resource in resources:
            deps = graph.get_dependencies(resource.id)
            table.add_row(
                str(resource.resource_type),
                resource.id,
                str(len(deps)) if deps else "-",
            )

        output._stderr_console.print(table)

        stats = graph.statistics()
        if stats["total_resources"] > 20:
            output.progress(f"... and {stats['total_resources'] - 20} more")

        output.log("")

        # JSON mode: present structured data
        if output.is_json:
            resource_list = []
            for resource in resources:
                deps = graph.get_dependencies(resource.id)
                resource_list.append(
                    {
                        "type": str(resource.resource_type),
                        "id": resource.id,
                        "dependencies": len(deps) if deps else 0,
                    }
                )
            output.present(
                {
                    "file": str(input_file),
                    "total_resources": stats["total_resources"],
                    "total_edges": stats["total_edges"],
                    "resources_by_type": stats.get("resources_by_type", {}),
                    "has_cycles": stats.get("has_cycles", False),
                    "resources": resource_list,
                }
            )
