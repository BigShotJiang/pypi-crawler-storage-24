"""
Profiles command - List available AWS profiles.

V3 Architecture:
- Uses @enhanced_cli_error_handler for structured error handling
- Uses ctx.obj.output for stdout hygiene (stderr for progress, stdout for results)
- JSON mode available via global --format flag
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import typer
from rich.table import Table

from replimap.cli.errors import enhanced_cli_error_handler
from replimap.cli.utils import (
    get_available_profiles,
    get_cached_credentials,
    get_profile_region,
)

if TYPE_CHECKING:
    from replimap.cli.context import GlobalContext


def register(app: typer.Typer, panel: str | None = None) -> None:
    """Register the profiles command with the app."""

    @app.command(rich_help_panel=panel)
    @enhanced_cli_error_handler
    def profiles(
        ctx: typer.Context,
    ) -> None:
        """List available AWS profiles.

        \b

        Shows all configured AWS profiles from ~/.aws/config and ~/.aws/credentials.

        \b

        Examples:

            replimap profiles
        """
        gctx: GlobalContext = ctx.obj
        output = gctx.output

        available = get_available_profiles()

        table = Table(
            title="Available AWS Profiles",
            show_header=True,
            header_style="bold cyan",
        )
        table.add_column("Profile", style="cyan")
        table.add_column("Region", style="dim")
        table.add_column("Status")

        profile_data = []
        for profile_name in available:
            region = get_profile_region(profile_name) or "[dim]not set[/]"

            # Check if credentials are cached
            cached = get_cached_credentials(profile_name)
            if cached:
                status = "[green]cached[/]"
                status_raw = "cached"
            else:
                status = "[dim]-[/]"
                status_raw = "-"

            table.add_row(profile_name, region, status)
            profile_data.append(
                {
                    "profile": profile_name,
                    "region": get_profile_region(profile_name) or "not set",
                    "status": status_raw,
                }
            )

        output._stderr_console.print(table)

        output.log("")
        output.progress("Tip: Use --profile <name> to select a profile")
        output.progress("Tip: Use --interactive or -i for guided setup")
        output.log("")

        # JSON mode: present structured data
        if output.is_json:
            output.present(
                {
                    "profiles": profile_data,
                    "total": len(profile_data),
                }
            )
