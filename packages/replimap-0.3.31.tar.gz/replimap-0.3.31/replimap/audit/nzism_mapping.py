"""
NZISM (New Zealand Information Security Manual) Compliance Mapping for Checkov Findings.

Maps Checkov check IDs to NZISM controls for compliance reporting.
The NZISM is published by the NZ Government Communications Security Bureau (GCSB)
and provides mandatory baseline security controls for NZ government agencies.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class NZISMControl:
    """NZISM control mapping."""

    control: str
    category: str
    description: str


# Mapping of Checkov check IDs to NZISM controls
# Comprehensive mapping covering 160+ Checkov AWS checks across NZISM control families
NZISM_MAPPING: dict[str, NZISMControl] = {
    # =========================================================================
    # ISM-0120 - Access Control: Identification and Authentication
    # =========================================================================
    "CKV_AWS_40": NZISMControl("ISM-0120", "Access Control", "IAM Password Policy"),
    "CKV_AWS_41": NZISMControl("ISM-0120", "Access Control", "Root Account MFA"),
    "CKV_AWS_49": NZISMControl(
        "ISM-0120", "Access Control", "IAM Policy Least Privilege"
    ),
    "CKV_AWS_107": NZISMControl(
        "ISM-0120", "Access Control", "IAM Policy Wildcard Actions"
    ),
    "CKV_AWS_108": NZISMControl(
        "ISM-0120", "Access Control", "IAM Policy Wildcard Resources"
    ),
    "CKV_AWS_109": NZISMControl(
        "ISM-0120", "Access Control", "IAM Policy Permissions Boundary"
    ),
    "CKV_AWS_110": NZISMControl(
        "ISM-0120", "Access Control", "IAM Policy Allow Privilege Escalation"
    ),
    "CKV_AWS_111": NZISMControl(
        "ISM-0120", "Access Control", "IAM Policy Write Access"
    ),
    "CKV_AWS_13": NZISMControl(
        "ISM-0120", "Access Control", "Root Account Hardware MFA"
    ),
    "CKV_AWS_14": NZISMControl(
        "ISM-0120", "Access Control", "Root Account Virtual MFA"
    ),
    "CKV_AWS_142": NZISMControl("ISM-0120", "Access Control", "RDS IAM Auth Enabled"),
    "CKV_AWS_214": NZISMControl("ISM-0120", "Access Control", "Cognito MFA Enabled"),
    "CKV_AWS_79": NZISMControl("ISM-0120", "Access Control", "EC2 IMDSv2 Required"),
    "CKV_AWS_97": NZISMControl(
        "ISM-0120", "Access Control", "ECS Task Definition User"
    ),
    "CKV_AWS_249": NZISMControl("ISM-0120", "Access Control", "Neptune IAM Auth"),
    "CKV_AWS_224": NZISMControl(
        "ISM-0120", "Access Control", "EKS Service Account Token"
    ),
    "CKV_AWS_305": NZISMControl(
        "ISM-0120", "Access Control", "EC2 Serial Console Disabled"
    ),
    "CKV_AWS_326": NZISMControl("ISM-0120", "Access Control", "KMS Key Policy"),
    "CKV_AWS_9": NZISMControl("ISM-0120", "Access Control", "IAM CloudShell Access"),
    # =========================================================================
    # ISM-0459 - Cryptography: Encryption Requirements
    # =========================================================================
    # --- Encryption at Rest ---
    "CKV_AWS_19": NZISMControl("ISM-0459", "Cryptography", "S3 Bucket Encryption"),
    "CKV_AWS_3": NZISMControl("ISM-0459", "Cryptography", "EBS Volume Encryption"),
    "CKV_AWS_16": NZISMControl("ISM-0459", "Cryptography", "RDS Instance Encryption"),
    "CKV_AWS_17": NZISMControl("ISM-0459", "Cryptography", "RDS Snapshot Encryption"),
    "CKV_AWS_27": NZISMControl("ISM-0459", "Cryptography", "SQS Queue Encryption"),
    "CKV_AWS_7": NZISMControl("ISM-0459", "Cryptography", "KMS Key Rotation"),
    "CKV_AWS_33": NZISMControl("ISM-0459", "Cryptography", "KMS CMK Policy"),
    "CKV_AWS_26": NZISMControl("ISM-0459", "Cryptography", "SNS Topic Encryption"),
    "CKV_AWS_64": NZISMControl(
        "ISM-0459", "Cryptography", "Redshift Cluster Encryption"
    ),
    "CKV_AWS_65": NZISMControl("ISM-0459", "Cryptography", "ECR Repository Encryption"),
    "CKV_AWS_84": NZISMControl(
        "ISM-0459", "Cryptography", "ElastiCache Encryption at Rest"
    ),
    "CKV_AWS_34": NZISMControl(
        "ISM-0459", "Cryptography", "CloudWatch Log Group Encryption"
    ),
    "CKV_AWS_37": NZISMControl(
        "ISM-0459", "Cryptography", "ECS Task Definition Encryption"
    ),
    "CKV_AWS_47": NZISMControl("ISM-0459", "Cryptography", "DAX Cluster Encryption"),
    "CKV_AWS_58": NZISMControl("ISM-0459", "Cryptography", "EKS Secrets Encryption"),
    "CKV_AWS_63": NZISMControl(
        "ISM-0459", "Cryptography", "CloudWatch Log Group Encryption v2"
    ),
    "CKV_AWS_68": NZISMControl(
        "ISM-0459", "Cryptography", "Neptune Cluster Encryption"
    ),
    "CKV_AWS_69": NZISMControl(
        "ISM-0459", "Cryptography", "OpenSearch Domain Encryption"
    ),
    "CKV_AWS_74": NZISMControl(
        "ISM-0459", "Cryptography", "DocumentDB Cluster Encryption"
    ),
    "CKV_AWS_89": NZISMControl(
        "ISM-0459", "Cryptography", "DMS Replication Instance Encryption"
    ),
    "CKV_AWS_90": NZISMControl(
        "ISM-0459", "Cryptography", "OpenSearch Encryption at Rest"
    ),
    "CKV_AWS_99": NZISMControl(
        "ISM-0459", "Cryptography", "Glue Data Catalog Encryption"
    ),
    "CKV_AWS_101": NZISMControl(
        "ISM-0459", "Cryptography", "Neptune Storage Encryption"
    ),
    "CKV_AWS_119": NZISMControl("ISM-0459", "Cryptography", "DynamoDB Encryption"),
    "CKV_AWS_120": NZISMControl(
        "ISM-0459", "Cryptography", "API Gateway Cache Encryption"
    ),
    "CKV_AWS_122": NZISMControl(
        "ISM-0459", "Cryptography", "CodeBuild Project Encryption"
    ),
    "CKV_AWS_135": NZISMControl(
        "ISM-0459", "Cryptography", "EC2 EBS Default Encryption"
    ),
    "CKV_AWS_149": NZISMControl(
        "ISM-0459", "Cryptography", "Secrets Manager KMS Encryption"
    ),
    "CKV_AWS_189": NZISMControl("ISM-0459", "Cryptography", "EFS Encryption at Rest"),
    "CKV_AWS_191": NZISMControl(
        "ISM-0459", "Cryptography", "Lambda Environment Encryption"
    ),
    "CKV_AWS_4": NZISMControl("ISM-0459", "Cryptography", "EBS Snapshot Encryption"),
    "CKV_AWS_10": NZISMControl("ISM-0459", "Cryptography", "Launch Config Encrypted"),
    "CKV_AWS_205": NZISMControl("ISM-0459", "Cryptography", "Backup Vault Encryption"),
    "CKV_AWS_213": NZISMControl(
        "ISM-0459", "Cryptography", "Cognito User Pool Encryption"
    ),
    "CKV_AWS_218": NZISMControl(
        "ISM-0459", "Cryptography", "EBS Snapshot Encryption v2"
    ),
    "CKV_AWS_228": NZISMControl(
        "ISM-0459", "Cryptography", "EventBridge Bus Encryption"
    ),
    "CKV_AWS_292": NZISMControl(
        "ISM-0459", "Cryptography", "CloudTrail KMS Encryption"
    ),
    "CKV_AWS_239": NZISMControl("ISM-0459", "Cryptography", "Lambda Code Signing"),
    "CKV_AWS_263": NZISMControl("ISM-0459", "Cryptography", "Secrets Manager CMK"),
    "CKV_AWS_309": NZISMControl(
        "ISM-0459", "Cryptography", "EKS Node Group Encryption"
    ),
    "CKV_AWS_335": NZISMControl("ISM-0459", "Cryptography", "MemoryDB Encryption"),
    # --- Encryption in Transit ---
    "CKV_AWS_2": NZISMControl("ISM-0459", "Cryptography", "ALB HTTPS/TLS"),
    "CKV_AWS_20": NZISMControl("ISM-0459", "Cryptography", "S3 Bucket SSL Only"),
    "CKV_AWS_83": NZISMControl(
        "ISM-0459", "Cryptography", "ElastiCache Encryption in Transit"
    ),
    "CKV_AWS_103": NZISMControl("ISM-0459", "Cryptography", "ALB TLS 1.2+"),
    "CKV_AWS_85": NZISMControl("ISM-0459", "Cryptography", "DocDB TLS Enabled"),
    "CKV_AWS_92": NZISMControl("ISM-0459", "Cryptography", "ELB v2 Listener TLS"),
    "CKV_AWS_93": NZISMControl("ISM-0459", "Cryptography", "CloudFront Viewer TLS 1.2"),
    "CKV_AWS_94": NZISMControl(
        "ISM-0459", "Cryptography", "CloudFront Encryption in Transit"
    ),
    "CKV_AWS_100": NZISMControl("ISM-0459", "Cryptography", "Glue Connection SSL"),
    "CKV_AWS_105": NZISMControl("ISM-0459", "Cryptography", "RDS TLS Enforcement"),
    "CKV_AWS_106": NZISMControl(
        "ISM-0459", "Cryptography", "OpenSearch Node-to-Node Encryption"
    ),
    "CKV_AWS_131": NZISMControl("ISM-0459", "Cryptography", "ALB Listener HTTPS"),
    "CKV_AWS_172": NZISMControl("ISM-0459", "Cryptography", "CloudFront SSL Protocol"),
    "CKV_AWS_173": NZISMControl("ISM-0459", "Cryptography", "API Gateway TLS 1.2"),
    "CKV_AWS_204": NZISMControl("ISM-0459", "Cryptography", "AppSync TLS"),
    "CKV_AWS_225": NZISMControl(
        "ISM-0459", "Cryptography", "Elasticsearch HTTPS Required"
    ),
    "CKV_AWS_260": NZISMControl("ISM-0459", "Cryptography", "S3 Bucket TLS Enforced"),
    "CKV_AWS_280": NZISMControl("ISM-0459", "Cryptography", "API GW V2 TLS"),
    "CKV_AWS_302": NZISMControl("ISM-0459", "Cryptography", "DMS Endpoint SSL Mode"),
    "CKV_AWS_336": NZISMControl("ISM-0459", "Cryptography", "MemoryDB TLS Enabled"),
    "CKV_AWS_216": NZISMControl("ISM-0459", "Cryptography", "DocumentDB TLS Required"),
    "CKV_AWS_266": NZISMControl(
        "ISM-0459", "Cryptography", "SES Configuration Set TLS"
    ),
    "CKV_AWS_273": NZISMControl(
        "ISM-0459", "Cryptography", "Transfer Server SFTP Only"
    ),
    "CKV_AWS_351": NZISMControl(
        "ISM-0459", "Cryptography", "SES Configuration TLS Required"
    ),
    # =========================================================================
    # ISM-0260 - Network Security: Network Segmentation and Protection
    # =========================================================================
    "CKV_AWS_23": NZISMControl(
        "ISM-0260", "Network Security", "Security Group Ingress Restriction"
    ),
    "CKV_AWS_24": NZISMControl(
        "ISM-0260", "Network Security", "Security Group SSH Restriction"
    ),
    "CKV_AWS_25": NZISMControl(
        "ISM-0260", "Network Security", "Security Group RDP Restriction"
    ),
    "CKV_AWS_130": NZISMControl("ISM-0260", "Network Security", "VPC Subnet Public IP"),
    "CKV_AWS_12": NZISMControl("ISM-0260", "Network Security", "Default VPC Not Used"),
    "CKV_AWS_88": NZISMControl("ISM-0260", "Network Security", "EC2 in VPC"),
    "CKV_AWS_8": NZISMControl(
        "ISM-0260", "Network Security", "Launch Config Public IP"
    ),
    "CKV_AWS_29": NZISMControl("ISM-0260", "Network Security", "Elasticsearch in VPC"),
    "CKV_AWS_38": NZISMControl(
        "ISM-0260", "Network Security", "EKS Public Access Disabled"
    ),
    "CKV_AWS_87": NZISMControl(
        "ISM-0260", "Network Security", "Redshift Enhanced VPC Routing"
    ),
    "CKV_AWS_134": NZISMControl("ISM-0260", "Network Security", "VPC Internet Gateway"),
    "CKV_AWS_138": NZISMControl("ISM-0260", "Network Security", "EKS Private Endpoint"),
    "CKV_AWS_150": NZISMControl(
        "ISM-0260", "Network Security", "EKS Endpoint Private Access"
    ),
    "CKV_AWS_161": NZISMControl(
        "ISM-0260", "Network Security", "RDS Publicly Accessible"
    ),
    "CKV_AWS_274": NZISMControl("ISM-0260", "Network Security", "VPC Endpoint Policy"),
    "CKV_AWS_310": NZISMControl(
        "ISM-0260", "Network Security", "Elasticsearch VPC Endpoint"
    ),
    "CKV_AWS_363": NZISMControl(
        "ISM-0260", "Network Security", "VPC Peering DNS Resolution"
    ),
    "CKV_AWS_60": NZISMControl("ISM-0260", "Network Security", "Lambda VPC Config"),
    "CKV_AWS_117": NZISMControl("ISM-0260", "Network Security", "Lambda in VPC"),
    # =========================================================================
    # ISM-0580 - System Monitoring: Logging and Monitoring
    # =========================================================================
    "CKV_AWS_67": NZISMControl("ISM-0580", "System Monitoring", "CloudTrail Enabled"),
    "CKV_AWS_35": NZISMControl(
        "ISM-0580", "System Monitoring", "CloudTrail Log Validation"
    ),
    "CKV_AWS_36": NZISMControl(
        "ISM-0580", "System Monitoring", "CloudTrail S3 Bucket Access Logging"
    ),
    "CKV_AWS_48": NZISMControl(
        "ISM-0580", "System Monitoring", "VPC Flow Logs Enabled"
    ),
    "CKV_AWS_21": NZISMControl("ISM-0580", "System Monitoring", "S3 Bucket Logging"),
    "CKV_AWS_50": NZISMControl("ISM-0580", "System Monitoring", "Lambda X-Ray Tracing"),
    "CKV_AWS_76": NZISMControl(
        "ISM-0580", "System Monitoring", "API Gateway Access Logging"
    ),
    "CKV_AWS_91": NZISMControl(
        "ISM-0580", "System Monitoring", "RDS Enhanced Monitoring"
    ),
    "CKV_AWS_104": NZISMControl("ISM-0580", "System Monitoring", "ALB Access Logging"),
    "CKV_AWS_66": NZISMControl(
        "ISM-0580", "System Monitoring", "CloudWatch Log Group Retention"
    ),
    "CKV_AWS_73": NZISMControl(
        "ISM-0580", "System Monitoring", "API Gateway Execution Logging"
    ),
    "CKV_AWS_75": NZISMControl(
        "ISM-0580", "System Monitoring", "API Gateway Detailed Metrics"
    ),
    "CKV_AWS_80": NZISMControl("ISM-0580", "System Monitoring", "MSK Cluster Logging"),
    "CKV_AWS_95": NZISMControl("ISM-0580", "System Monitoring", "WAF Web ACL Logging"),
    "CKV_AWS_118": NZISMControl(
        "ISM-0580", "System Monitoring", "RDS Performance Insights"
    ),
    "CKV_AWS_126": NZISMControl(
        "ISM-0580", "System Monitoring", "Postgres Log Connections"
    ),
    "CKV_AWS_127": NZISMControl(
        "ISM-0580", "System Monitoring", "Postgres Log Disconnections"
    ),
    "CKV_AWS_129": NZISMControl(
        "ISM-0580", "System Monitoring", "Postgres Log Hostname"
    ),
    "CKV_AWS_133": NZISMControl(
        "ISM-0580", "System Monitoring", "CloudTrail CloudWatch Logs"
    ),
    "CKV_AWS_158": NZISMControl(
        "ISM-0580", "System Monitoring", "Lambda Tracing Active"
    ),
    "CKV_AWS_162": NZISMControl(
        "ISM-0580", "System Monitoring", "Transfer Server Logging"
    ),
    "CKV_AWS_184": NZISMControl(
        "ISM-0580", "System Monitoring", "OpenSearch Audit Logging"
    ),
    "CKV_AWS_39": NZISMControl(
        "ISM-0580", "System Monitoring", "EKS Control Plane Logging"
    ),
    "CKV_AWS_279": NZISMControl(
        "ISM-0580", "System Monitoring", "API GW V2 Access Logging"
    ),
    "CKV_AWS_291": NZISMControl(
        "ISM-0580", "System Monitoring", "CloudTrail Insight Enabled"
    ),
    "CKV_AWS_308": NZISMControl(
        "ISM-0580", "System Monitoring", "ECS Container Insights"
    ),
    "CKV_AWS_344": NZISMControl(
        "ISM-0580", "System Monitoring", "Route53 Query Logging"
    ),
    "CKV_AWS_364": NZISMControl(
        "ISM-0580", "System Monitoring", "VPC Endpoint Logging"
    ),
    # --- Incident Detection and Response ---
    "CKV_AWS_52": NZISMControl("ISM-0580", "System Monitoring", "GuardDuty Enabled"),
    "CKV_AWS_78": NZISMControl("ISM-0580", "System Monitoring", "Config Rule Enabled"),
    "CKV_AWS_121": NZISMControl(
        "ISM-0580", "System Monitoring", "Security Hub Enabled"
    ),
    "CKV_AWS_160": NZISMControl(
        "ISM-0580", "System Monitoring", "GuardDuty S3 Protection"
    ),
    "CKV_AWS_234": NZISMControl(
        "ISM-0580", "System Monitoring", "GuardDuty EKS Protection"
    ),
    "CKV_AWS_235": NZISMControl(
        "ISM-0580", "System Monitoring", "Inspector V2 Enabled"
    ),
    "CKV_AWS_352": NZISMControl(
        "ISM-0580", "System Monitoring", "Shield Advanced Protection"
    ),
    # =========================================================================
    # ISM-0109 - Information Management: Data Classification and Handling
    # =========================================================================
    "CKV_AWS_1": NZISMControl(
        "ISM-0109", "Information Management", "S3 Bucket ACL Not Public"
    ),
    "CKV_AWS_53": NZISMControl(
        "ISM-0109", "Information Management", "S3 Public Access Block Account"
    ),
    "CKV_AWS_54": NZISMControl(
        "ISM-0109", "Information Management", "S3 Block Public ACLs"
    ),
    "CKV_AWS_55": NZISMControl(
        "ISM-0109", "Information Management", "S3 Block Public Policy"
    ),
    "CKV_AWS_56": NZISMControl(
        "ISM-0109", "Information Management", "S3 Ignore Public ACLs"
    ),
    "CKV_AWS_57": NZISMControl(
        "ISM-0109", "Information Management", "S3 Restrict Public Buckets"
    ),
    "CKV_AWS_62": NZISMControl(
        "ISM-0109", "Information Management", "Lambda Not Public"
    ),
    "CKV_AWS_258": NZISMControl(
        "ISM-0109", "Information Management", "S3 Account Public Block"
    ),
    "CKV_AWS_345": NZISMControl(
        "ISM-0109", "Information Management", "S3 Access Point VPC"
    ),
    "CKV_AWS_45": NZISMControl(
        "ISM-0109", "Information Management", "Lambda Env Encryption"
    ),
    "CKV_AWS_153": NZISMControl(
        "ISM-0109", "Information Management", "Lambda Function URLs Auth"
    ),
    "CKV_AWS_240": NZISMControl(
        "ISM-0109", "Information Management", "Lambda Public URL Auth"
    ),
    "CKV_AWS_46": NZISMControl(
        "ISM-0109", "Information Management", "Secrets Manager Rotation"
    ),
    "CKV_AWS_264": NZISMControl(
        "ISM-0109", "Information Management", "Secrets Manager Rotation Days"
    ),
    # --- Data-at-Rest Protection (classification-driven encryption) ---
    "CKV_AWS_132": NZISMControl("ISM-0109", "Information Management", "S3 Object Lock"),
    "CKV_AWS_145": NZISMControl(
        "ISM-0109", "Information Management", "S3 Bucket Key Enabled"
    ),
    "CKV_AWS_18": NZISMControl(
        "ISM-0109", "Information Management", "S3 Bucket Versioning"
    ),
    "CKV_AWS_144": NZISMControl(
        "ISM-0109", "Information Management", "S3 Cross-Region Replication"
    ),
    # =========================================================================
    # ISM-1315 - Gateway Security: Perimeter Protection
    # =========================================================================
    "CKV_AWS_226": NZISMControl(
        "ISM-1315", "Gateway Security", "ALB Drop Invalid Headers"
    ),
    "CKV_AWS_59": NZISMControl(
        "ISM-1315", "Gateway Security", "API Gateway Authorizer"
    ),
    "CKV_AWS_86": NZISMControl(
        "ISM-1315", "Gateway Security", "CloudFront Origin Access Identity"
    ),
    "CKV_AWS_102": NZISMControl(
        "ISM-1315", "Gateway Security", "CloudFront Field Level Encryption"
    ),
    "CKV_AWS_208": NZISMControl(
        "ISM-1315", "Gateway Security", "CloudFront Response Headers"
    ),
    "CKV_AWS_209": NZISMControl(
        "ISM-1315", "Gateway Security", "CloudFront Origin Failover"
    ),
    "CKV_AWS_275": NZISMControl(
        "ISM-1315", "Gateway Security", "WAF Rule Group Metric"
    ),
    "CKV_AWS_276": NZISMControl(
        "ISM-1315", "Gateway Security", "WAFv2 Logging Enabled"
    ),
    "CKV_AWS_227": NZISMControl(
        "ISM-1315", "Gateway Security", "EMR Block Public Access"
    ),
    "CKV_AWS_281": NZISMControl(
        "ISM-1315", "Gateway Security", "AppConfig Deletion Protection"
    ),
    # =========================================================================
    # ISM-0974 - Software Security: Secure Configuration
    # =========================================================================
    # --- RDS Secure Configuration ---
    "CKV_AWS_15": NZISMControl("ISM-0974", "Software Security", "RDS Multi-AZ"),
    "CKV_AWS_128": NZISMControl(
        "ISM-0974", "Software Security", "RDS Deletion Protection"
    ),
    "CKV_AWS_139": NZISMControl(
        "ISM-0974", "Software Security", "RDS Backup Retention 7+ Days"
    ),
    "CKV_AWS_157": NZISMControl(
        "ISM-0974", "Software Security", "RDS Backup Retention Set"
    ),
    "CKV_AWS_254": NZISMControl("ISM-0974", "Software Security", "RDS Proxy TLS"),
    "CKV_AWS_77": NZISMControl(
        "ISM-0974", "Software Security", "OpenSearch Fine-Grained Access"
    ),
    # --- EC2 and Compute Secure Configuration ---
    "CKV_AWS_70": NZISMControl(
        "ISM-0974", "Software Security", "Sagemaker Endpoint Config Encryption"
    ),
    "CKV_AWS_98": NZISMControl(
        "ISM-0974", "Software Security", "Sagemaker Notebook Root Access"
    ),
    "CKV_AWS_137": NZISMControl("ISM-0974", "Software Security", "AMI Encryption"),
    "CKV_AWS_136": NZISMControl(
        "ISM-0974", "Software Security", "ECR Image Tag Immutable"
    ),
    "CKV_AWS_163": NZISMControl(
        "ISM-0974", "Software Security", "ECR Image Scan on Push"
    ),
    "CKV_AWS_207": NZISMControl(
        "ISM-0974", "Software Security", "Batch Compute Privileged"
    ),
    "CKV_AWS_211": NZISMControl(
        "ISM-0974", "Software Security", "CodeBuild Privileged Mode"
    ),
    "CKV_AWS_220": NZISMControl(
        "ISM-0974", "Software Security", "ECS Fargate Latest Platform"
    ),
    "CKV_AWS_222": NZISMControl(
        "ISM-0974", "Software Security", "EKS Cluster Secrets Encryption"
    ),
    "CKV_AWS_307": NZISMControl(
        "ISM-0974", "Software Security", "ECS Execute Command Logging"
    ),
    # --- Lambda Secure Configuration ---
    "CKV_AWS_61": NZISMControl(
        "ISM-0974", "Software Security", "Lambda DLQ Configured"
    ),
    "CKV_AWS_115": NZISMControl(
        "ISM-0974", "Software Security", "Lambda Reserved Concurrency"
    ),
    "CKV_AWS_116": NZISMControl(
        "ISM-0974", "Software Security", "Lambda DLQ or OnFailure"
    ),
    # --- Container Security ---
    "CKV_AWS_51": NZISMControl("ISM-0974", "Software Security", "ECR Lifecycle Policy"),
    # --- General Secure Configuration ---
    "CKV_AWS_96": NZISMControl(
        "ISM-0974", "Software Security", "EMR Security Configuration"
    ),
    "CKV_AWS_313": NZISMControl(
        "ISM-0974", "Software Security", "EMR Security Configuration v2"
    ),
    "CKV_AWS_81": NZISMControl("ISM-0974", "Software Security", "MSK Cluster TLS"),
    "CKV_AWS_256": NZISMControl(
        "ISM-0974", "Software Security", "Redshift Require SSL"
    ),
    # =========================================================================
    # ISM-0785 - Resilience: Backup and Recovery
    # =========================================================================
    "CKV_AWS_5": NZISMControl("ISM-0785", "Resilience", "DocumentDB Backup Retention"),
    "CKV_AWS_28": NZISMControl("ISM-0785", "Resilience", "DynamoDB Backup Enabled"),
    "CKV_AWS_6": NZISMControl("ISM-0785", "Resilience", "ElastiCache Failover"),
    "CKV_AWS_44": NZISMControl("ISM-0785", "Resilience", "Neptune Multi-AZ"),
    "CKV_AWS_71": NZISMControl("ISM-0785", "Resilience", "Redshift Cluster Backup"),
    "CKV_AWS_123": NZISMControl("ISM-0785", "Resilience", "Auto-Scaling Multi-AZ"),
    "CKV_AWS_143": NZISMControl("ISM-0785", "Resilience", "DynamoDB PITR"),
    "CKV_AWS_165": NZISMControl("ISM-0785", "Resilience", "Auto-Scaling Health Check"),
    "CKV_AWS_206": NZISMControl("ISM-0785", "Resilience", "Backup Plan Rules"),
    "CKV_AWS_252": NZISMControl("ISM-0785", "Resilience", "RDS Aurora Cluster Backup"),
    "CKV_AWS_287": NZISMControl("ISM-0785", "Resilience", "Aurora Global Database"),
    "CKV_AWS_304": NZISMControl("ISM-0785", "Resilience", "DocDB Global Cluster"),
    "CKV_AWS_229": NZISMControl("ISM-0785", "Resilience", "FSx Backup Retention"),
    "CKV_AWS_332": NZISMControl("ISM-0785", "Resilience", "Lightsail Instance Backup"),
    "CKV_AWS_337": NZISMControl(
        "ISM-0785", "Resilience", "MemoryDB Snapshot Retention"
    ),
    "CKV_AWS_346": NZISMControl("ISM-0785", "Resilience", "S3 Bucket Replication"),
}


def get_nzism_mapping(check_id: str) -> NZISMControl | None:
    """
    Get NZISM control mapping for a Checkov check ID.

    Args:
        check_id: Checkov check ID (e.g., "CKV_AWS_19")

    Returns:
        NZISMControl if mapping exists, None otherwise
    """
    return NZISM_MAPPING.get(check_id)


def get_nzism_summary(check_ids: list[str]) -> dict[str, dict[str, int]]:
    """
    Generate NZISM control summary from a list of check IDs.

    Args:
        check_ids: List of failed Checkov check IDs

    Returns:
        Dictionary mapping control IDs to category and count
    """
    summary: dict[str, dict[str, int]] = {}

    for check_id in check_ids:
        control = get_nzism_mapping(check_id)
        if control:
            if control.control not in summary:
                summary[control.control] = {
                    "category": control.category,
                    "count": 0,
                }
            summary[control.control]["count"] += 1

    return summary


def get_nzism_statistics() -> dict[str, int]:
    """
    Get statistics about the NZISM mapping coverage.

    Returns:
        Dictionary with mapping statistics by control and category
    """
    stats: dict[str, int] = {
        "total_mappings": len(NZISM_MAPPING),
        "by_control": {},
        "by_category": {},
    }

    for control in NZISM_MAPPING.values():
        # Count by control ID
        if control.control not in stats["by_control"]:
            stats["by_control"][control.control] = 0
        stats["by_control"][control.control] += 1

        # Count by category
        if control.category not in stats["by_category"]:
            stats["by_category"][control.category] = 0
        stats["by_category"][control.category] += 1

    return stats


# NZISM control descriptions for reporting
NZISM_CONTROL_DESCRIPTIONS: dict[str, str] = {
    "ISM-0120": "Access Control - Agencies must implement identification and authentication mechanisms to control access to systems and information",
    "ISM-0459": "Cryptography - Agencies must use approved cryptographic algorithms and protocols to protect the confidentiality and integrity of information",
    "ISM-0260": "Network Security - Agencies must implement network segmentation and protection controls to restrict network traffic to authorised communications",
    "ISM-0580": "System Monitoring - Agencies must implement event logging and monitoring to detect cyber security events and support incident response",
    "ISM-0109": "Information Management - Agencies must classify, label, and handle information according to its sensitivity and criticality",
    "ISM-1315": "Gateway Security - Agencies must implement gateway security controls to protect the boundary between internal networks and external networks",
    "ISM-0974": "Software Security - Agencies must implement secure configuration baselines for all systems and applications",
    "ISM-0785": "Resilience - Agencies must implement backup and recovery controls to ensure the availability of critical systems and information",
}
