"""
RBNZ BS11 (Reserve Bank of New Zealand Banking Standard 11 - Outsourcing) Mapping for Checkov Findings.

Maps Checkov check IDs to RBNZ BS11 controls for compliance reporting.

BS11 is the RBNZ standard governing outsourcing arrangements for registered banks
in New Zealand, with specific requirements for cloud service providers.

Key controls mapped:
- BS11.4: Risk Management - Risk assessment, data security, encryption
- BS11.5: Exit Planning - Data portability, backup, vendor lock-in mitigation
- BS11.6: Reporting - Audit and monitoring capabilities
- BS11.7: Cloud-Specific Requirements - Data residency, access controls, key management
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class BS11Control:
    """RBNZ BS11 Outsourcing Standard control mapping."""

    control: str
    category: str
    description: str


# Mapping of Checkov check IDs to RBNZ BS11 controls
# Comprehensive mapping covering 130+ Checkov AWS checks across all BS11 control areas
BS11_MAPPING: dict[str, BS11Control] = {
    # =========================================================================
    # BS11.4 - Risk Management
    # Risk assessment, data security, encryption controls
    # =========================================================================
    # Encryption at Rest - Data security risk mitigation
    "CKV_AWS_19": BS11Control("BS11.4", "Risk Management", "S3 Bucket Encryption"),
    "CKV_AWS_3": BS11Control("BS11.4", "Risk Management", "EBS Volume Encryption"),
    "CKV_AWS_16": BS11Control("BS11.4", "Risk Management", "RDS Instance Encryption"),
    "CKV_AWS_17": BS11Control("BS11.4", "Risk Management", "RDS Snapshot Encryption"),
    "CKV_AWS_27": BS11Control("BS11.4", "Risk Management", "SQS Queue Encryption"),
    "CKV_AWS_7": BS11Control("BS11.4", "Risk Management", "KMS Key Rotation"),
    "CKV_AWS_84": BS11Control(
        "BS11.4", "Risk Management", "ElastiCache Encryption at Rest"
    ),
    "CKV_AWS_64": BS11Control(
        "BS11.4", "Risk Management", "Redshift Cluster Encryption"
    ),
    "CKV_AWS_65": BS11Control("BS11.4", "Risk Management", "ECR Repository Encryption"),
    "CKV_AWS_34": BS11Control(
        "BS11.4", "Risk Management", "CloudWatch Log Group Encryption"
    ),
    "CKV_AWS_47": BS11Control("BS11.4", "Risk Management", "DAX Cluster Encryption"),
    "CKV_AWS_58": BS11Control("BS11.4", "Risk Management", "EKS Secrets Encryption"),
    "CKV_AWS_68": BS11Control(
        "BS11.4", "Risk Management", "Neptune Cluster Encryption"
    ),
    "CKV_AWS_69": BS11Control(
        "BS11.4", "Risk Management", "OpenSearch Domain Encryption"
    ),
    "CKV_AWS_74": BS11Control(
        "BS11.4", "Risk Management", "DocumentDB Cluster Encryption"
    ),
    "CKV_AWS_89": BS11Control(
        "BS11.4", "Risk Management", "DMS Replication Instance Encryption"
    ),
    "CKV_AWS_90": BS11Control(
        "BS11.4", "Risk Management", "OpenSearch Encryption at Rest"
    ),
    "CKV_AWS_99": BS11Control(
        "BS11.4", "Risk Management", "Glue Data Catalog Encryption"
    ),
    "CKV_AWS_119": BS11Control("BS11.4", "Risk Management", "DynamoDB Encryption"),
    "CKV_AWS_135": BS11Control(
        "BS11.4", "Risk Management", "EC2 EBS Default Encryption"
    ),
    "CKV_AWS_149": BS11Control(
        "BS11.4", "Risk Management", "Secrets Manager KMS Encryption"
    ),
    "CKV_AWS_189": BS11Control("BS11.4", "Risk Management", "EFS Encryption at Rest"),
    "CKV_AWS_191": BS11Control(
        "BS11.4", "Risk Management", "Lambda Environment Encryption"
    ),
    # Encryption in Transit - Data security in motion
    "CKV_AWS_2": BS11Control("BS11.4", "Risk Management", "ALB HTTPS/TLS"),
    "CKV_AWS_20": BS11Control("BS11.4", "Risk Management", "S3 Bucket SSL Only"),
    "CKV_AWS_83": BS11Control(
        "BS11.4", "Risk Management", "ElastiCache Encryption in Transit"
    ),
    "CKV_AWS_103": BS11Control("BS11.4", "Risk Management", "ALB TLS 1.2+"),
    "CKV_AWS_85": BS11Control("BS11.4", "Risk Management", "DocDB TLS Enabled"),
    "CKV_AWS_92": BS11Control("BS11.4", "Risk Management", "ELB v2 Listener TLS"),
    "CKV_AWS_93": BS11Control("BS11.4", "Risk Management", "CloudFront Viewer TLS 1.2"),
    "CKV_AWS_100": BS11Control("BS11.4", "Risk Management", "Glue Connection SSL"),
    "CKV_AWS_105": BS11Control("BS11.4", "Risk Management", "RDS TLS Enforcement"),
    "CKV_AWS_106": BS11Control(
        "BS11.4", "Risk Management", "OpenSearch Node-to-Node Encryption"
    ),
    "CKV_AWS_131": BS11Control("BS11.4", "Risk Management", "ALB Listener HTTPS"),
    "CKV_AWS_172": BS11Control("BS11.4", "Risk Management", "CloudFront SSL Protocol"),
    "CKV_AWS_173": BS11Control("BS11.4", "Risk Management", "API Gateway TLS 1.2"),
    # Monitoring - Risk detection and alerting
    "CKV_AWS_35": BS11Control("BS11.4", "Risk Management", "CloudTrail Log Validation"),
    "CKV_AWS_36": BS11Control(
        "BS11.4", "Risk Management", "CloudTrail S3 Bucket Access Logging"
    ),
    "CKV_AWS_48": BS11Control("BS11.4", "Risk Management", "VPC Flow Logs Enabled"),
    "CKV_AWS_50": BS11Control("BS11.4", "Risk Management", "Lambda X-Ray Tracing"),
    "CKV_AWS_91": BS11Control("BS11.4", "Risk Management", "RDS Enhanced Monitoring"),
    "CKV_AWS_118": BS11Control("BS11.4", "Risk Management", "RDS Performance Insights"),
    # Incident Response - Risk handling
    "CKV_AWS_52": BS11Control("BS11.4", "Risk Management", "GuardDuty Enabled"),
    "CKV_AWS_121": BS11Control("BS11.4", "Risk Management", "Security Hub Enabled"),
    "CKV_AWS_160": BS11Control("BS11.4", "Risk Management", "GuardDuty S3 Protection"),
    # =========================================================================
    # BS11.5 - Exit Planning
    # Data portability, backup, vendor lock-in mitigation
    # =========================================================================
    # Backup and Recovery - Data portability
    "CKV_AWS_133": BS11Control("BS11.5", "Exit Planning", "CloudTrail CloudWatch Logs"),
    "CKV_AWS_134": BS11Control("BS11.5", "Exit Planning", "VPC Internet Gateway"),
    "CKV_AWS_139": BS11Control(
        "BS11.5", "Exit Planning", "RDS Backup Retention 7+ Days"
    ),
    "CKV_AWS_5": BS11Control("BS11.5", "Exit Planning", "DocumentDB Backup Retention"),
    "CKV_AWS_28": BS11Control("BS11.5", "Exit Planning", "DynamoDB Backup Enabled"),
    "CKV_AWS_143": BS11Control("BS11.5", "Exit Planning", "DynamoDB PITR"),
    "CKV_AWS_157": BS11Control("BS11.5", "Exit Planning", "RDS Backup Retention Set"),
    "CKV_AWS_252": BS11Control("BS11.5", "Exit Planning", "RDS Aurora Cluster Backup"),
    "CKV_AWS_71": BS11Control("BS11.5", "Exit Planning", "Redshift Cluster Backup"),
    "CKV_AWS_128": BS11Control("BS11.5", "Exit Planning", "RDS Deletion Protection"),
    # Versioning and Replication - Data durability for exit
    "CKV_AWS_18": BS11Control("BS11.5", "Exit Planning", "S3 Bucket Versioning"),
    "CKV_AWS_132": BS11Control("BS11.5", "Exit Planning", "S3 Object Lock"),
    "CKV_AWS_144": BS11Control(
        "BS11.5", "Exit Planning", "S3 Cross-Region Replication"
    ),
    "CKV_AWS_4": BS11Control("BS11.5", "Exit Planning", "EBS Snapshot Encryption"),
    # Multi-AZ and Failover - Service continuity during exit
    "CKV_AWS_15": BS11Control("BS11.5", "Exit Planning", "RDS Multi-AZ"),
    "CKV_AWS_6": BS11Control("BS11.5", "Exit Planning", "ElastiCache Failover"),
    "CKV_AWS_44": BS11Control("BS11.5", "Exit Planning", "Neptune Multi-AZ"),
    "CKV_AWS_123": BS11Control("BS11.5", "Exit Planning", "Auto-Scaling Multi-AZ"),
    "CKV_AWS_165": BS11Control("BS11.5", "Exit Planning", "Auto-Scaling Health Check"),
    "CKV_AWS_287": BS11Control("BS11.5", "Exit Planning", "Aurora Global Database"),
    "CKV_AWS_304": BS11Control("BS11.5", "Exit Planning", "DocDB Global Cluster"),
    "CKV_AWS_229": BS11Control("BS11.5", "Exit Planning", "FSx Backup Retention"),
    "CKV_AWS_324": BS11Control(
        "BS11.5", "Exit Planning", "Kinesis Data Firehose Backup"
    ),
    "CKV_AWS_332": BS11Control("BS11.5", "Exit Planning", "Lightsail Instance Backup"),
    "CKV_AWS_337": BS11Control(
        "BS11.5", "Exit Planning", "MemoryDB Snapshot Retention"
    ),
    "CKV_AWS_346": BS11Control("BS11.5", "Exit Planning", "S3 Bucket Replication"),
    # =========================================================================
    # BS11.6 - Reporting
    # Audit and monitoring capabilities for regulatory reporting
    # =========================================================================
    # CloudTrail - Audit trail for regulatory reporting
    "CKV_AWS_67": BS11Control("BS11.6", "Reporting", "CloudTrail Enabled"),
    "CKV_AWS_291": BS11Control("BS11.6", "Reporting", "CloudTrail Insight Enabled"),
    "CKV_AWS_292": BS11Control("BS11.6", "Reporting", "CloudTrail KMS Encryption"),
    # AWS Config - Configuration compliance reporting
    "CKV_AWS_78": BS11Control("BS11.6", "Reporting", "Config Rule Enabled"),
    "CKV_AWS_298": BS11Control("BS11.6", "Reporting", "Config Aggregator All Regions"),
    # Logging and Monitoring - Reporting capabilities
    "CKV_AWS_21": BS11Control("BS11.6", "Reporting", "S3 Bucket Logging"),
    "CKV_AWS_66": BS11Control("BS11.6", "Reporting", "CloudWatch Log Group Retention"),
    "CKV_AWS_76": BS11Control("BS11.6", "Reporting", "API Gateway Access Logging"),
    "CKV_AWS_73": BS11Control("BS11.6", "Reporting", "API Gateway Execution Logging"),
    "CKV_AWS_75": BS11Control("BS11.6", "Reporting", "API Gateway Detailed Metrics"),
    "CKV_AWS_80": BS11Control("BS11.6", "Reporting", "MSK Cluster Logging"),
    "CKV_AWS_95": BS11Control("BS11.6", "Reporting", "WAF Web ACL Logging"),
    "CKV_AWS_104": BS11Control("BS11.6", "Reporting", "ALB Access Logging"),
    "CKV_AWS_72": BS11Control("BS11.6", "Reporting", "Redshift Audit Logging"),
    "CKV_AWS_126": BS11Control("BS11.6", "Reporting", "Postgres Log Connections"),
    "CKV_AWS_127": BS11Control("BS11.6", "Reporting", "Postgres Log Disconnections"),
    "CKV_AWS_129": BS11Control("BS11.6", "Reporting", "Postgres Log Hostname"),
    "CKV_AWS_158": BS11Control("BS11.6", "Reporting", "Lambda Tracing Active"),
    "CKV_AWS_162": BS11Control("BS11.6", "Reporting", "Transfer Server Logging"),
    "CKV_AWS_184": BS11Control("BS11.6", "Reporting", "OpenSearch Audit Logging"),
    "CKV_AWS_279": BS11Control("BS11.6", "Reporting", "API GW V2 Access Logging"),
    "CKV_AWS_300": BS11Control("BS11.6", "Reporting", "Connect Instance Logging"),
    "CKV_AWS_303": BS11Control("BS11.6", "Reporting", "DMS Replication Logging"),
    "CKV_AWS_308": BS11Control("BS11.6", "Reporting", "ECS Container Insights"),
    "CKV_AWS_311": BS11Control(
        "BS11.6", "Reporting", "ElasticBeanstalk Enhanced Health"
    ),
    "CKV_AWS_344": BS11Control("BS11.6", "Reporting", "Route53 Query Logging"),
    "CKV_AWS_352": BS11Control("BS11.6", "Reporting", "Shield Advanced Protection"),
    "CKV_AWS_364": BS11Control("BS11.6", "Reporting", "VPC Endpoint Logging"),
    # Security Tooling - Incident reporting
    "CKV_AWS_235": BS11Control("BS11.6", "Reporting", "Inspector V2 Enabled"),
    "CKV_AWS_243": BS11Control("BS11.6", "Reporting", "Macie Enabled"),
    "CKV_AWS_286": BS11Control("BS11.6", "Reporting", "Audit Manager Enabled"),
    # =========================================================================
    # BS11.7 - Cloud-Specific Requirements
    # Data residency, access controls, key management, network security, audit trail
    # =========================================================================
    # Access Control - Identity and access management
    "CKV_AWS_40": BS11Control("BS11.7", "Cloud Security", "IAM Password Policy"),
    "CKV_AWS_41": BS11Control("BS11.7", "Cloud Security", "Root Account MFA"),
    "CKV_AWS_23": BS11Control(
        "BS11.7", "Cloud Security", "Security Group Ingress Restriction"
    ),
    "CKV_AWS_24": BS11Control(
        "BS11.7", "Cloud Security", "Security Group SSH Restriction"
    ),
    "CKV_AWS_25": BS11Control(
        "BS11.7", "Cloud Security", "Security Group RDP Restriction"
    ),
    "CKV_AWS_49": BS11Control("BS11.7", "Cloud Security", "IAM Policy Least Privilege"),
    "CKV_AWS_1": BS11Control("BS11.7", "Cloud Security", "S3 Bucket ACL Not Public"),
    "CKV_AWS_53": BS11Control(
        "BS11.7", "Cloud Security", "S3 Public Access Block Account"
    ),
    "CKV_AWS_54": BS11Control("BS11.7", "Cloud Security", "S3 Block Public ACLs"),
    "CKV_AWS_55": BS11Control("BS11.7", "Cloud Security", "S3 Block Public Policy"),
    "CKV_AWS_56": BS11Control("BS11.7", "Cloud Security", "S3 Ignore Public ACLs"),
    "CKV_AWS_57": BS11Control("BS11.7", "Cloud Security", "S3 Restrict Public Buckets"),
    "CKV_AWS_62": BS11Control("BS11.7", "Cloud Security", "Lambda Not Public"),
    "CKV_AWS_79": BS11Control("BS11.7", "Cloud Security", "EC2 IMDSv2 Required"),
    "CKV_AWS_8": BS11Control("BS11.7", "Cloud Security", "Launch Config Public IP"),
    "CKV_AWS_88": BS11Control("BS11.7", "Cloud Security", "EC2 in VPC"),
    "CKV_AWS_97": BS11Control("BS11.7", "Cloud Security", "ECS Task Definition User"),
    "CKV_AWS_107": BS11Control(
        "BS11.7", "Cloud Security", "IAM Policy Wildcard Actions"
    ),
    "CKV_AWS_108": BS11Control(
        "BS11.7", "Cloud Security", "IAM Policy Wildcard Resources"
    ),
    "CKV_AWS_109": BS11Control(
        "BS11.7", "Cloud Security", "IAM Policy Permissions Boundary"
    ),
    "CKV_AWS_110": BS11Control(
        "BS11.7", "Cloud Security", "IAM Policy Allow Privilege Escalation"
    ),
    "CKV_AWS_111": BS11Control("BS11.7", "Cloud Security", "IAM Policy Write Access"),
    "CKV_AWS_130": BS11Control("BS11.7", "Cloud Security", "VPC Subnet Public IP"),
    "CKV_AWS_142": BS11Control("BS11.7", "Cloud Security", "RDS IAM Auth Enabled"),
    "CKV_AWS_153": BS11Control("BS11.7", "Cloud Security", "Lambda Function URLs Auth"),
    "CKV_AWS_161": BS11Control("BS11.7", "Cloud Security", "RDS Publicly Accessible"),
    "CKV_AWS_226": BS11Control("BS11.7", "Cloud Security", "ALB Drop Invalid Headers"),
    # IAM - Identity governance for cloud
    "CKV_AWS_9": BS11Control("BS11.7", "Cloud Security", "IAM CloudShell Access"),
    "CKV_AWS_13": BS11Control("BS11.7", "Cloud Security", "Root Account Hardware MFA"),
    "CKV_AWS_14": BS11Control("BS11.7", "Cloud Security", "Root Account Virtual MFA"),
    # Key Management - KMS and encryption key controls
    "CKV_AWS_33": BS11Control("BS11.7", "Key Management", "KMS CMK Policy"),
    "CKV_AWS_145": BS11Control("BS11.7", "Key Management", "S3 Bucket Key Enabled"),
    "CKV_AWS_122": BS11Control(
        "BS11.7", "Key Management", "CodeBuild Project Encryption"
    ),
    "CKV_AWS_326": BS11Control("BS11.7", "Key Management", "KMS Key Policy"),
    "CKV_AWS_327": BS11Control("BS11.7", "Key Management", "KMS Key Deletion Window"),
    "CKV_AWS_263": BS11Control("BS11.7", "Key Management", "Secrets Manager CMK"),
    "CKV_AWS_46": BS11Control("BS11.7", "Key Management", "Secrets Manager Rotation"),
    # Network Security - VPC, Security Groups, network isolation
    "CKV_AWS_12": BS11Control("BS11.7", "Network Security", "Default VPC Not Used"),
    "CKV_AWS_29": BS11Control("BS11.7", "Network Security", "Elasticsearch in VPC"),
    "CKV_AWS_38": BS11Control(
        "BS11.7", "Network Security", "EKS Public Access Disabled"
    ),
    "CKV_AWS_60": BS11Control("BS11.7", "Network Security", "Lambda VPC Config"),
    "CKV_AWS_87": BS11Control(
        "BS11.7", "Network Security", "Redshift Enhanced VPC Routing"
    ),
    "CKV_AWS_117": BS11Control("BS11.7", "Network Security", "Lambda in VPC"),
    "CKV_AWS_138": BS11Control("BS11.7", "Network Security", "EKS Private Endpoint"),
    "CKV_AWS_150": BS11Control(
        "BS11.7", "Network Security", "EKS Endpoint Private Access"
    ),
    "CKV_AWS_274": BS11Control("BS11.7", "Network Security", "VPC Endpoint Policy"),
    "CKV_AWS_310": BS11Control(
        "BS11.7", "Network Security", "Elasticsearch VPC Endpoint"
    ),
    "CKV_AWS_363": BS11Control(
        "BS11.7", "Network Security", "VPC Peering DNS Resolution"
    ),
    # Audit Trail - Cloud-specific logging and traceability
    "CKV_AWS_39": BS11Control("BS11.7", "Audit Trail", "EKS Control Plane Logging"),
    "CKV_AWS_59": BS11Control("BS11.7", "Audit Trail", "API Gateway Authorizer"),
    "CKV_AWS_77": BS11Control(
        "BS11.7", "Audit Trail", "OpenSearch Fine-Grained Access"
    ),
    "CKV_AWS_82": BS11Control("BS11.7", "Audit Trail", "Athena Workgroup Encryption"),
    "CKV_AWS_223": BS11Control("BS11.7", "Audit Trail", "EKS Control Plane Audit"),
    "CKV_AWS_234": BS11Control("BS11.7", "Audit Trail", "GuardDuty EKS Protection"),
    "CKV_AWS_271": BS11Control("BS11.7", "Audit Trail", "Step Functions Logging"),
    "CKV_AWS_307": BS11Control("BS11.7", "Audit Trail", "ECS Execute Command Logging"),
    # Data Protection - Cloud data residency and classification
    "CKV_AWS_10": BS11Control("BS11.7", "Cloud Security", "Launch Config Encrypted"),
    "CKV_AWS_45": BS11Control("BS11.7", "Cloud Security", "Lambda Env Encryption"),
    "CKV_AWS_98": BS11Control(
        "BS11.7", "Cloud Security", "Sagemaker Notebook Root Access"
    ),
    "CKV_AWS_136": BS11Control("BS11.7", "Cloud Security", "ECR Image Tag Immutable"),
    "CKV_AWS_163": BS11Control("BS11.7", "Cloud Security", "ECR Image Scan on Push"),
    "CKV_AWS_207": BS11Control("BS11.7", "Cloud Security", "Batch Compute Privileged"),
    "CKV_AWS_211": BS11Control("BS11.7", "Cloud Security", "CodeBuild Privileged Mode"),
    "CKV_AWS_214": BS11Control("BS11.7", "Cloud Security", "Cognito MFA Enabled"),
    "CKV_AWS_220": BS11Control(
        "BS11.7", "Cloud Security", "ECS Fargate Latest Platform"
    ),
    "CKV_AWS_222": BS11Control(
        "BS11.7", "Cloud Security", "EKS Cluster Secrets Encryption"
    ),
    "CKV_AWS_224": BS11Control("BS11.7", "Cloud Security", "EKS Service Account Token"),
    "CKV_AWS_227": BS11Control("BS11.7", "Cloud Security", "EMR Block Public Access"),
    "CKV_AWS_240": BS11Control("BS11.7", "Cloud Security", "Lambda Public URL Auth"),
    "CKV_AWS_249": BS11Control("BS11.7", "Cloud Security", "Neptune IAM Auth"),
    "CKV_AWS_254": BS11Control("BS11.7", "Cloud Security", "RDS Proxy TLS"),
    "CKV_AWS_256": BS11Control("BS11.7", "Cloud Security", "Redshift Require SSL"),
    "CKV_AWS_258": BS11Control("BS11.7", "Cloud Security", "S3 Account Public Block"),
    "CKV_AWS_305": BS11Control(
        "BS11.7", "Cloud Security", "EC2 Serial Console Disabled"
    ),
    "CKV_AWS_345": BS11Control("BS11.7", "Cloud Security", "S3 Access Point VPC"),
}


def get_bs11_mapping(check_id: str) -> BS11Control | None:
    """
    Get RBNZ BS11 control mapping for a Checkov check ID.

    Args:
        check_id: Checkov check ID (e.g., "CKV_AWS_19")

    Returns:
        BS11Control if mapping exists, None otherwise
    """
    return BS11_MAPPING.get(check_id)


def get_bs11_summary(check_ids: list[str]) -> dict[str, dict[str, int]]:
    """
    Generate RBNZ BS11 control summary from a list of check IDs.

    Args:
        check_ids: List of failed Checkov check IDs

    Returns:
        Dictionary mapping control IDs to category and count
    """
    summary: dict[str, dict[str, int]] = {}

    for check_id in check_ids:
        control = get_bs11_mapping(check_id)
        if control:
            if control.control not in summary:
                summary[control.control] = {
                    "category": control.category,
                    "count": 0,
                }
            summary[control.control]["count"] += 1

    return summary


def get_bs11_statistics() -> dict[str, int]:
    """
    Get statistics about the RBNZ BS11 mapping coverage.

    Returns:
        Dictionary with mapping statistics by control and category
    """
    stats: dict[str, int] = {
        "total_mappings": len(BS11_MAPPING),
        "by_control": {},
        "by_category": {},
    }

    for control in BS11_MAPPING.values():
        # Count by control ID
        if control.control not in stats["by_control"]:
            stats["by_control"][control.control] = 0
        stats["by_control"][control.control] += 1

        # Count by category
        if control.category not in stats["by_category"]:
            stats["by_category"][control.category] = 0
        stats["by_category"][control.category] += 1

    return stats


# RBNZ BS11 control descriptions for reporting
BS11_CONTROL_DESCRIPTIONS: dict[str, str] = {
    "BS11.4": "Risk Management - Registered banks must have robust risk management frameworks covering outsourced services, including data security, encryption, and continuous monitoring of service provider risks",
    "BS11.5": "Exit Planning - Registered banks must maintain viable exit strategies for outsourcing arrangements, including data portability, backup retention, and vendor lock-in mitigation measures",
    "BS11.6": "Reporting - Registered banks must maintain comprehensive audit trails and reporting capabilities to demonstrate compliance with outsourcing requirements to the RBNZ",
    "BS11.7": "Cloud-Specific Requirements - Additional requirements for cloud outsourcing including data residency controls, identity and access management, key management, network security, and cloud-native audit trails",
}
