"""
APRA CPS 234 (Information Security) Compliance Mapping for Checkov Findings.

Maps Checkov check IDs to APRA CPS 234 controls for compliance reporting.

APRA CPS 234 is the Australian Prudential Regulation Authority's prudential
standard on information security, applicable to all APRA-regulated entities
including banks, insurers, and superannuation trustees.

Key obligations:
- Paragraph 15: Information asset identification and classification
- Paragraph 17: Information security capability proportionate to threats
- Paragraph 21: Access control to information assets
- Paragraph 25: Incident management and detection
- Paragraph 28: Testing of security control effectiveness
- Paragraph 33: Internal audit review of information security
- Paragraph 36: Notification to APRA of material incidents
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class CPS234Control:
    """APRA CPS 234 Information Security control mapping."""

    control: str
    category: str
    description: str


# Mapping of Checkov check IDs to APRA CPS 234 controls
# Comprehensive mapping covering 130+ Checkov AWS checks across all CPS 234 paragraphs
CPS234_MAPPING: dict[str, CPS234Control] = {
    # =========================================================================
    # CPS234.15 - Information Asset Identification and Classification
    # "An APRA-regulated entity must classify its information assets,
    #  including those managed by related parties and third parties,
    #  by criticality and sensitivity."
    # =========================================================================
    "CKV_AWS_18": CPS234Control(
        "CPS234.15", "Asset Classification", "S3 Bucket Versioning"
    ),
    "CKV_AWS_21": CPS234Control(
        "CPS234.15", "Asset Classification", "S3 Bucket Logging"
    ),
    "CKV_AWS_144": CPS234Control(
        "CPS234.15", "Asset Classification", "S3 Cross-Region Replication"
    ),
    "CKV_AWS_145": CPS234Control(
        "CPS234.15", "Asset Classification", "S3 Bucket Key Enabled"
    ),
    "CKV_AWS_132": CPS234Control("CPS234.15", "Asset Classification", "S3 Object Lock"),
    "CKV_AWS_136": CPS234Control(
        "CPS234.15", "Asset Classification", "ECR Image Tag Immutable"
    ),
    "CKV_AWS_163": CPS234Control(
        "CPS234.15", "Asset Classification", "ECR Image Scan on Push"
    ),
    "CKV_AWS_259": CPS234Control(
        "CPS234.15", "Asset Classification", "S3 Object Lock Enabled"
    ),
    "CKV_AWS_346": CPS234Control(
        "CPS234.15", "Asset Classification", "S3 Bucket Replication"
    ),
    "CKV_AWS_347": CPS234Control(
        "CPS234.15", "Asset Classification", "S3 Inventory Encryption"
    ),
    # =========================================================================
    # CPS234.17 - Information Security Capability
    # "An APRA-regulated entity must maintain an information security
    #  capability commensurate with the size and extent of threats to
    #  its information assets."
    # =========================================================================
    # --- Encryption at Rest ---
    "CKV_AWS_19": CPS234Control(
        "CPS234.17", "Security Capability", "S3 Bucket Encryption"
    ),
    "CKV_AWS_3": CPS234Control(
        "CPS234.17", "Security Capability", "EBS Volume Encryption"
    ),
    "CKV_AWS_16": CPS234Control(
        "CPS234.17", "Security Capability", "RDS Instance Encryption"
    ),
    "CKV_AWS_17": CPS234Control(
        "CPS234.17", "Security Capability", "RDS Snapshot Encryption"
    ),
    "CKV_AWS_7": CPS234Control("CPS234.17", "Security Capability", "KMS Key Rotation"),
    "CKV_AWS_27": CPS234Control(
        "CPS234.17", "Security Capability", "SQS Queue Encryption"
    ),
    "CKV_AWS_26": CPS234Control(
        "CPS234.17", "Security Capability", "SNS Topic Encryption"
    ),
    "CKV_AWS_33": CPS234Control("CPS234.17", "Security Capability", "KMS CMK Policy"),
    "CKV_AWS_34": CPS234Control(
        "CPS234.17", "Security Capability", "CloudWatch Log Group Encryption"
    ),
    "CKV_AWS_37": CPS234Control(
        "CPS234.17", "Security Capability", "ECS Task Definition Encryption"
    ),
    "CKV_AWS_47": CPS234Control(
        "CPS234.17", "Security Capability", "DAX Cluster Encryption"
    ),
    "CKV_AWS_58": CPS234Control(
        "CPS234.17", "Security Capability", "EKS Secrets Encryption"
    ),
    "CKV_AWS_63": CPS234Control(
        "CPS234.17", "Security Capability", "CloudWatch Log Group Encryption v2"
    ),
    "CKV_AWS_64": CPS234Control(
        "CPS234.17", "Security Capability", "Redshift Cluster Encryption"
    ),
    "CKV_AWS_65": CPS234Control(
        "CPS234.17", "Security Capability", "ECR Repository Encryption"
    ),
    "CKV_AWS_68": CPS234Control(
        "CPS234.17", "Security Capability", "Neptune Cluster Encryption"
    ),
    "CKV_AWS_69": CPS234Control(
        "CPS234.17", "Security Capability", "OpenSearch Domain Encryption"
    ),
    "CKV_AWS_74": CPS234Control(
        "CPS234.17", "Security Capability", "DocumentDB Cluster Encryption"
    ),
    "CKV_AWS_84": CPS234Control(
        "CPS234.17", "Security Capability", "ElastiCache Encryption at Rest"
    ),
    "CKV_AWS_89": CPS234Control(
        "CPS234.17", "Security Capability", "DMS Replication Instance Encryption"
    ),
    "CKV_AWS_90": CPS234Control(
        "CPS234.17", "Security Capability", "OpenSearch Encryption at Rest"
    ),
    "CKV_AWS_99": CPS234Control(
        "CPS234.17", "Security Capability", "Glue Data Catalog Encryption"
    ),
    "CKV_AWS_101": CPS234Control(
        "CPS234.17", "Security Capability", "Neptune Storage Encryption"
    ),
    "CKV_AWS_119": CPS234Control(
        "CPS234.17", "Security Capability", "DynamoDB Encryption"
    ),
    "CKV_AWS_120": CPS234Control(
        "CPS234.17", "Security Capability", "API Gateway Cache Encryption"
    ),
    "CKV_AWS_122": CPS234Control(
        "CPS234.17", "Security Capability", "CodeBuild Project Encryption"
    ),
    "CKV_AWS_135": CPS234Control(
        "CPS234.17", "Security Capability", "EC2 EBS Default Encryption"
    ),
    "CKV_AWS_149": CPS234Control(
        "CPS234.17", "Security Capability", "Secrets Manager KMS Encryption"
    ),
    "CKV_AWS_189": CPS234Control(
        "CPS234.17", "Security Capability", "EFS Encryption at Rest"
    ),
    "CKV_AWS_191": CPS234Control(
        "CPS234.17", "Security Capability", "Lambda Environment Encryption"
    ),
    "CKV_AWS_205": CPS234Control(
        "CPS234.17", "Security Capability", "Backup Vault Encryption"
    ),
    "CKV_AWS_213": CPS234Control(
        "CPS234.17", "Security Capability", "Cognito User Pool Encryption"
    ),
    "CKV_AWS_218": CPS234Control(
        "CPS234.17", "Security Capability", "EBS Snapshot Encryption"
    ),
    "CKV_AWS_228": CPS234Control(
        "CPS234.17", "Security Capability", "EventBridge Bus Encryption"
    ),
    "CKV_AWS_230": CPS234Control(
        "CPS234.17", "Security Capability", "FSx Lustre Encryption"
    ),
    "CKV_AWS_231": CPS234Control(
        "CPS234.17", "Security Capability", "FSx Windows Encryption"
    ),
    "CKV_AWS_233": CPS234Control(
        "CPS234.17", "Security Capability", "Glue Dev Endpoint Encryption"
    ),
    "CKV_AWS_239": CPS234Control(
        "CPS234.17", "Security Capability", "Lambda Code Signing"
    ),
    "CKV_AWS_244": CPS234Control(
        "CPS234.17", "Security Capability", "MQ Broker Encryption"
    ),
    "CKV_AWS_263": CPS234Control(
        "CPS234.17", "Security Capability", "Secrets Manager CMK"
    ),
    "CKV_AWS_292": CPS234Control(
        "CPS234.17", "Security Capability", "CloudTrail KMS Encryption"
    ),
    # --- Encryption in Transit ---
    "CKV_AWS_2": CPS234Control("CPS234.17", "Security Capability", "ALB HTTPS/TLS"),
    "CKV_AWS_20": CPS234Control(
        "CPS234.17", "Security Capability", "S3 Bucket SSL Only"
    ),
    "CKV_AWS_83": CPS234Control(
        "CPS234.17", "Security Capability", "ElastiCache Encryption in Transit"
    ),
    "CKV_AWS_85": CPS234Control(
        "CPS234.17", "Security Capability", "DocDB TLS Enabled"
    ),
    "CKV_AWS_92": CPS234Control(
        "CPS234.17", "Security Capability", "ELB v2 Listener TLS"
    ),
    "CKV_AWS_93": CPS234Control(
        "CPS234.17", "Security Capability", "CloudFront Viewer TLS 1.2"
    ),
    "CKV_AWS_94": CPS234Control(
        "CPS234.17", "Security Capability", "CloudFront Encryption in Transit"
    ),
    "CKV_AWS_100": CPS234Control(
        "CPS234.17", "Security Capability", "Glue Connection SSL"
    ),
    "CKV_AWS_103": CPS234Control("CPS234.17", "Security Capability", "ALB TLS 1.2+"),
    "CKV_AWS_105": CPS234Control(
        "CPS234.17", "Security Capability", "RDS TLS Enforcement"
    ),
    "CKV_AWS_106": CPS234Control(
        "CPS234.17", "Security Capability", "OpenSearch Node-to-Node Encryption"
    ),
    "CKV_AWS_131": CPS234Control(
        "CPS234.17", "Security Capability", "ALB Listener HTTPS"
    ),
    "CKV_AWS_172": CPS234Control(
        "CPS234.17", "Security Capability", "CloudFront SSL Protocol"
    ),
    "CKV_AWS_173": CPS234Control(
        "CPS234.17", "Security Capability", "API Gateway TLS 1.2"
    ),
    "CKV_AWS_216": CPS234Control(
        "CPS234.17", "Security Capability", "DocumentDB TLS Required"
    ),
    "CKV_AWS_225": CPS234Control(
        "CPS234.17", "Security Capability", "Elasticsearch HTTPS Required"
    ),
    "CKV_AWS_260": CPS234Control(
        "CPS234.17", "Security Capability", "S3 Bucket TLS Enforced"
    ),
    "CKV_AWS_336": CPS234Control(
        "CPS234.17", "Security Capability", "MemoryDB TLS Enabled"
    ),
    # --- Network Security ---
    "CKV_AWS_79": CPS234Control(
        "CPS234.17", "Security Capability", "EC2 IMDSv2 Required"
    ),
    "CKV_AWS_88": CPS234Control("CPS234.17", "Security Capability", "EC2 in VPC"),
    "CKV_AWS_87": CPS234Control(
        "CPS234.17", "Security Capability", "Redshift Enhanced VPC Routing"
    ),
    "CKV_AWS_96": CPS234Control(
        "CPS234.17", "Security Capability", "EMR Security Configuration"
    ),
    "CKV_AWS_4": CPS234Control(
        "CPS234.17", "Security Capability", "EBS Snapshot Encryption"
    ),
    "CKV_AWS_10": CPS234Control(
        "CPS234.17", "Security Capability", "Launch Config Encrypted"
    ),
    # =========================================================================
    # CPS234.21 - Access Control
    # "An APRA-regulated entity must have controls to restrict access
    #  to information assets commensurate with the sensitivity and
    #  criticality of those information assets, and to minimise the
    #  impact of a breach."
    # =========================================================================
    # --- IAM Controls ---
    "CKV_AWS_40": CPS234Control("CPS234.21", "Access Control", "IAM Password Policy"),
    "CKV_AWS_41": CPS234Control("CPS234.21", "Access Control", "Root Account MFA"),
    "CKV_AWS_49": CPS234Control(
        "CPS234.21", "Access Control", "IAM Policy Least Privilege"
    ),
    "CKV_AWS_107": CPS234Control(
        "CPS234.21", "Access Control", "IAM Policy Wildcard Actions"
    ),
    "CKV_AWS_108": CPS234Control(
        "CPS234.21", "Access Control", "IAM Policy Wildcard Resources"
    ),
    "CKV_AWS_109": CPS234Control(
        "CPS234.21", "Access Control", "IAM Policy Permissions Boundary"
    ),
    "CKV_AWS_110": CPS234Control(
        "CPS234.21", "Access Control", "IAM Policy Allow Privilege Escalation"
    ),
    "CKV_AWS_111": CPS234Control(
        "CPS234.21", "Access Control", "IAM Policy Write Access"
    ),
    "CKV_AWS_142": CPS234Control("CPS234.21", "Access Control", "RDS IAM Auth Enabled"),
    "CKV_AWS_214": CPS234Control("CPS234.21", "Access Control", "Cognito MFA Enabled"),
    "CKV_AWS_9": CPS234Control("CPS234.21", "Access Control", "IAM CloudShell Access"),
    "CKV_AWS_13": CPS234Control(
        "CPS234.21", "Access Control", "Root Account Hardware MFA"
    ),
    "CKV_AWS_14": CPS234Control(
        "CPS234.21", "Access Control", "Root Account Virtual MFA"
    ),
    "CKV_AWS_249": CPS234Control("CPS234.21", "Access Control", "Neptune IAM Auth"),
    # --- S3 Public Access Controls ---
    "CKV_AWS_1": CPS234Control(
        "CPS234.21", "Access Control", "S3 Bucket ACL Not Public"
    ),
    "CKV_AWS_53": CPS234Control(
        "CPS234.21", "Access Control", "S3 Public Access Block Account"
    ),
    "CKV_AWS_54": CPS234Control("CPS234.21", "Access Control", "S3 Block Public ACLs"),
    "CKV_AWS_55": CPS234Control(
        "CPS234.21", "Access Control", "S3 Block Public Policy"
    ),
    "CKV_AWS_56": CPS234Control("CPS234.21", "Access Control", "S3 Ignore Public ACLs"),
    "CKV_AWS_57": CPS234Control(
        "CPS234.21", "Access Control", "S3 Restrict Public Buckets"
    ),
    "CKV_AWS_258": CPS234Control(
        "CPS234.21", "Access Control", "S3 Account Public Block"
    ),
    "CKV_AWS_345": CPS234Control("CPS234.21", "Access Control", "S3 Access Point VPC"),
    # --- Security Group Controls ---
    "CKV_AWS_23": CPS234Control(
        "CPS234.21", "Access Control", "Security Group Ingress Restriction"
    ),
    "CKV_AWS_24": CPS234Control(
        "CPS234.21", "Access Control", "Security Group SSH Restriction"
    ),
    "CKV_AWS_25": CPS234Control(
        "CPS234.21", "Access Control", "Security Group RDP Restriction"
    ),
    # --- Network Access Controls ---
    "CKV_AWS_8": CPS234Control(
        "CPS234.21", "Access Control", "Launch Config Public IP"
    ),
    "CKV_AWS_130": CPS234Control("CPS234.21", "Access Control", "VPC Subnet Public IP"),
    "CKV_AWS_161": CPS234Control(
        "CPS234.21", "Access Control", "RDS Publicly Accessible"
    ),
    "CKV_AWS_62": CPS234Control("CPS234.21", "Access Control", "Lambda Not Public"),
    "CKV_AWS_38": CPS234Control(
        "CPS234.21", "Access Control", "EKS Public Access Disabled"
    ),
    "CKV_AWS_59": CPS234Control(
        "CPS234.21", "Access Control", "API Gateway Authorizer"
    ),
    "CKV_AWS_77": CPS234Control(
        "CPS234.21", "Access Control", "OpenSearch Fine-Grained Access"
    ),
    "CKV_AWS_86": CPS234Control(
        "CPS234.21", "Access Control", "CloudFront Origin Access Identity"
    ),
    "CKV_AWS_97": CPS234Control(
        "CPS234.21", "Access Control", "ECS Task Definition User"
    ),
    "CKV_AWS_138": CPS234Control("CPS234.21", "Access Control", "EKS Private Endpoint"),
    "CKV_AWS_150": CPS234Control(
        "CPS234.21", "Access Control", "EKS Endpoint Private Access"
    ),
    "CKV_AWS_153": CPS234Control(
        "CPS234.21", "Access Control", "Lambda Function URLs Auth"
    ),
    "CKV_AWS_207": CPS234Control(
        "CPS234.21", "Access Control", "Batch Compute Privileged"
    ),
    "CKV_AWS_211": CPS234Control(
        "CPS234.21", "Access Control", "CodeBuild Privileged Mode"
    ),
    "CKV_AWS_226": CPS234Control(
        "CPS234.21", "Access Control", "ALB Drop Invalid Headers"
    ),
    "CKV_AWS_227": CPS234Control(
        "CPS234.21", "Access Control", "EMR Block Public Access"
    ),
    "CKV_AWS_240": CPS234Control(
        "CPS234.21", "Access Control", "Lambda Public URL Auth"
    ),
    "CKV_AWS_254": CPS234Control("CPS234.21", "Access Control", "RDS Proxy TLS"),
    "CKV_AWS_256": CPS234Control("CPS234.21", "Access Control", "Redshift Require SSL"),
    "CKV_AWS_268": CPS234Control("CPS234.21", "Access Control", "SQS Queue Policy"),
    "CKV_AWS_274": CPS234Control("CPS234.21", "Access Control", "VPC Endpoint Policy"),
    "CKV_AWS_305": CPS234Control(
        "CPS234.21", "Access Control", "EC2 Serial Console Disabled"
    ),
    "CKV_AWS_310": CPS234Control(
        "CPS234.21", "Access Control", "Elasticsearch VPC Endpoint"
    ),
    "CKV_AWS_354": CPS234Control(
        "CPS234.21", "Access Control", "SQS Queue Access Policy"
    ),
    "CKV_AWS_363": CPS234Control(
        "CPS234.21", "Access Control", "VPC Peering DNS Resolution"
    ),
    # =========================================================================
    # CPS234.25 - Incident Management
    # "An APRA-regulated entity must have robust mechanisms in place
    #  to detect and respond to information security incidents in a
    #  timely manner."
    # =========================================================================
    # --- CloudTrail ---
    "CKV_AWS_67": CPS234Control(
        "CPS234.25", "Incident Management", "CloudTrail Enabled"
    ),
    "CKV_AWS_35": CPS234Control(
        "CPS234.25", "Incident Management", "CloudTrail Log Validation"
    ),
    "CKV_AWS_36": CPS234Control(
        "CPS234.25", "Incident Management", "CloudTrail S3 Bucket Access Logging"
    ),
    "CKV_AWS_133": CPS234Control(
        "CPS234.25", "Incident Management", "CloudTrail CloudWatch Logs"
    ),
    "CKV_AWS_291": CPS234Control(
        "CPS234.25", "Incident Management", "CloudTrail Insight Enabled"
    ),
    # --- GuardDuty ---
    "CKV_AWS_52": CPS234Control(
        "CPS234.25", "Incident Management", "GuardDuty Enabled"
    ),
    "CKV_AWS_160": CPS234Control(
        "CPS234.25", "Incident Management", "GuardDuty S3 Protection"
    ),
    "CKV_AWS_234": CPS234Control(
        "CPS234.25", "Incident Management", "GuardDuty EKS Protection"
    ),
    # --- AWS Config ---
    "CKV_AWS_78": CPS234Control(
        "CPS234.25", "Incident Management", "Config Rule Enabled"
    ),
    "CKV_AWS_298": CPS234Control(
        "CPS234.25", "Incident Management", "Config Aggregator All Regions"
    ),
    # --- Security Hub / Inspector ---
    "CKV_AWS_121": CPS234Control(
        "CPS234.25", "Incident Management", "Security Hub Enabled"
    ),
    "CKV_AWS_235": CPS234Control(
        "CPS234.25", "Incident Management", "Inspector V2 Enabled"
    ),
    "CKV_AWS_265": CPS234Control(
        "CPS234.25", "Incident Management", "SecurityHub Standard ARN"
    ),
    "CKV_AWS_286": CPS234Control(
        "CPS234.25", "Incident Management", "Audit Manager Enabled"
    ),
    # =========================================================================
    # CPS234.28 - Testing of Security Controls
    # "An APRA-regulated entity must test the effectiveness of its
    #  information security controls through a systematic testing
    #  program."
    # =========================================================================
    # --- Vulnerability Scanning ---
    "CKV_AWS_321": CPS234Control(
        "CPS234.28", "Testing", "Inspector Assessment Template"
    ),
    "CKV_AWS_243": CPS234Control("CPS234.28", "Testing", "Macie Enabled"),
    "CKV_AWS_295": CPS234Control("CPS234.28", "Testing", "CodeGuru Profiler Enabled"),
    # --- Security Group Audit ---
    "CKV_AWS_12": CPS234Control("CPS234.28", "Testing", "Default VPC Not Used"),
    "CKV_AWS_134": CPS234Control("CPS234.28", "Testing", "VPC Internet Gateway"),
    # --- Backup and Recovery Testing ---
    "CKV_AWS_5": CPS234Control("CPS234.28", "Testing", "DocumentDB Backup Retention"),
    "CKV_AWS_28": CPS234Control("CPS234.28", "Testing", "DynamoDB Backup Enabled"),
    "CKV_AWS_128": CPS234Control("CPS234.28", "Testing", "RDS Deletion Protection"),
    "CKV_AWS_139": CPS234Control(
        "CPS234.28", "Testing", "RDS Backup Retention 7+ Days"
    ),
    "CKV_AWS_143": CPS234Control("CPS234.28", "Testing", "DynamoDB PITR"),
    "CKV_AWS_157": CPS234Control("CPS234.28", "Testing", "RDS Backup Retention Set"),
    "CKV_AWS_206": CPS234Control("CPS234.28", "Testing", "Backup Plan Rules"),
    "CKV_AWS_252": CPS234Control("CPS234.28", "Testing", "RDS Aurora Cluster Backup"),
    # --- Availability Controls ---
    "CKV_AWS_15": CPS234Control("CPS234.28", "Testing", "RDS Multi-AZ"),
    "CKV_AWS_6": CPS234Control("CPS234.28", "Testing", "ElastiCache Failover"),
    "CKV_AWS_44": CPS234Control("CPS234.28", "Testing", "Neptune Multi-AZ"),
    "CKV_AWS_123": CPS234Control("CPS234.28", "Testing", "Auto-Scaling Multi-AZ"),
    "CKV_AWS_165": CPS234Control("CPS234.28", "Testing", "Auto-Scaling Health Check"),
    # =========================================================================
    # CPS234.33 - Internal Audit
    # "The internal audit function of an APRA-regulated entity must
    #  review the design and operating effectiveness of information
    #  security controls, including those maintained by related parties
    #  and third parties."
    # =========================================================================
    # --- CloudTrail and Audit Logging ---
    "CKV_AWS_48": CPS234Control("CPS234.33", "Internal Audit", "VPC Flow Logs Enabled"),
    "CKV_AWS_50": CPS234Control("CPS234.33", "Internal Audit", "Lambda X-Ray Tracing"),
    "CKV_AWS_66": CPS234Control(
        "CPS234.33", "Internal Audit", "CloudWatch Log Group Retention"
    ),
    "CKV_AWS_76": CPS234Control(
        "CPS234.33", "Internal Audit", "API Gateway Access Logging"
    ),
    "CKV_AWS_91": CPS234Control(
        "CPS234.33", "Internal Audit", "RDS Enhanced Monitoring"
    ),
    "CKV_AWS_104": CPS234Control("CPS234.33", "Internal Audit", "ALB Access Logging"),
    "CKV_AWS_73": CPS234Control(
        "CPS234.33", "Internal Audit", "API Gateway Execution Logging"
    ),
    "CKV_AWS_75": CPS234Control(
        "CPS234.33", "Internal Audit", "API Gateway Detailed Metrics"
    ),
    "CKV_AWS_80": CPS234Control("CPS234.33", "Internal Audit", "MSK Cluster Logging"),
    "CKV_AWS_95": CPS234Control("CPS234.33", "Internal Audit", "WAF Web ACL Logging"),
    "CKV_AWS_118": CPS234Control(
        "CPS234.33", "Internal Audit", "RDS Performance Insights"
    ),
    "CKV_AWS_126": CPS234Control(
        "CPS234.33", "Internal Audit", "Postgres Log Connections"
    ),
    "CKV_AWS_127": CPS234Control(
        "CPS234.33", "Internal Audit", "Postgres Log Disconnections"
    ),
    "CKV_AWS_129": CPS234Control(
        "CPS234.33", "Internal Audit", "Postgres Log Hostname"
    ),
    "CKV_AWS_158": CPS234Control(
        "CPS234.33", "Internal Audit", "Lambda Tracing Active"
    ),
    "CKV_AWS_162": CPS234Control(
        "CPS234.33", "Internal Audit", "Transfer Server Logging"
    ),
    "CKV_AWS_184": CPS234Control(
        "CPS234.33", "Internal Audit", "OpenSearch Audit Logging"
    ),
    "CKV_AWS_72": CPS234Control(
        "CPS234.33", "Internal Audit", "Redshift Audit Logging"
    ),
    "CKV_AWS_174": CPS234Control(
        "CPS234.33", "Internal Audit", "CloudWatch Log Group TLS"
    ),
    "CKV_AWS_232": CPS234Control("CPS234.33", "Internal Audit", "Glue Crawler Logging"),
    "CKV_AWS_238": CPS234Control(
        "CPS234.33", "Internal Audit", "Kinesis Enhanced Monitoring"
    ),
    "CKV_AWS_245": CPS234Control(
        "CPS234.33", "Internal Audit", "MQ Broker Audit Logging"
    ),
    "CKV_AWS_248": CPS234Control("CPS234.33", "Internal Audit", "MWAA Logging"),
    "CKV_AWS_253": CPS234Control(
        "CPS234.33", "Internal Audit", "RDS Enhanced Monitoring Role"
    ),
    "CKV_AWS_255": CPS234Control(
        "CPS234.33", "Internal Audit", "Redshift Cluster Audit"
    ),
    "CKV_AWS_275": CPS234Control(
        "CPS234.33", "Internal Audit", "WAF Rule Group Metric"
    ),
    "CKV_AWS_276": CPS234Control(
        "CPS234.33", "Internal Audit", "WAFv2 Logging Enabled"
    ),
    "CKV_AWS_279": CPS234Control(
        "CPS234.33", "Internal Audit", "API GW V2 Access Logging"
    ),
    "CKV_AWS_283": CPS234Control(
        "CPS234.33", "Internal Audit", "AppRunner Observability"
    ),
    "CKV_AWS_300": CPS234Control(
        "CPS234.33", "Internal Audit", "Connect Instance Logging"
    ),
    "CKV_AWS_303": CPS234Control(
        "CPS234.33", "Internal Audit", "DMS Replication Logging"
    ),
    "CKV_AWS_308": CPS234Control(
        "CPS234.33", "Internal Audit", "ECS Container Insights"
    ),
    "CKV_AWS_311": CPS234Control(
        "CPS234.33", "Internal Audit", "ElasticBeanstalk Enhanced Health"
    ),
    "CKV_AWS_318": CPS234Control("CPS234.33", "Internal Audit", "Glue Job Logging"),
    "CKV_AWS_330": CPS234Control("CPS234.33", "Internal Audit", "Lex Bot Logging"),
    "CKV_AWS_338": CPS234Control(
        "CPS234.33", "Internal Audit", "Cloud9 Environment Logging"
    ),
    "CKV_AWS_344": CPS234Control(
        "CPS234.33", "Internal Audit", "Route53 Query Logging"
    ),
    "CKV_AWS_352": CPS234Control(
        "CPS234.33", "Internal Audit", "Shield Advanced Protection"
    ),
    "CKV_AWS_356": CPS234Control(
        "CPS234.33", "Internal Audit", "SSM Maintenance Window Logging"
    ),
    "CKV_AWS_359": CPS234Control(
        "CPS234.33", "Internal Audit", "Synthetics Canary Logging"
    ),
    "CKV_AWS_364": CPS234Control("CPS234.33", "Internal Audit", "VPC Endpoint Logging"),
    "CKV_AWS_39": CPS234Control(
        "CPS234.33", "Internal Audit", "EKS Control Plane Logging"
    ),
    "CKV_AWS_223": CPS234Control(
        "CPS234.33", "Internal Audit", "EKS Control Plane Audit"
    ),
    "CKV_AWS_212": CPS234Control(
        "CPS234.33", "Internal Audit", "CodePipeline Stage Logs"
    ),
    # =========================================================================
    # CPS234.36 - Notification to APRA
    # "An APRA-regulated entity must notify APRA of material
    #  information security incidents as soon as possible and
    #  no later than 72 hours after becoming aware."
    # =========================================================================
    # --- SNS and Alerting ---
    "CKV_AWS_267": CPS234Control("CPS234.36", "Notification", "SNS Topic Logging"),
    "CKV_AWS_353": CPS234Control(
        "CPS234.36", "Notification", "SNS Topic FIFO Encryption"
    ),
    # --- CloudWatch Alarms and Monitoring ---
    "CKV_AWS_208": CPS234Control(
        "CPS234.36", "Notification", "CloudFront Response Headers"
    ),
    "CKV_AWS_289": CPS234Control("CPS234.36", "Notification", "Budgets Action Enabled"),
    "CKV_AWS_334": CPS234Control("CPS234.36", "Notification", "Lookout Metrics Alert"),
    # --- Secrets Rotation (detect compromise) ---
    "CKV_AWS_46": CPS234Control(
        "CPS234.36", "Notification", "Secrets Manager Rotation"
    ),
    "CKV_AWS_264": CPS234Control(
        "CPS234.36", "Notification", "Secrets Manager Rotation Days"
    ),
    # --- Step Functions and Workflow Alerting ---
    "CKV_AWS_271": CPS234Control("CPS234.36", "Notification", "Step Functions Logging"),
}


def get_cps234_mapping(check_id: str) -> CPS234Control | None:
    """
    Get APRA CPS 234 control mapping for a Checkov check ID.

    Args:
        check_id: Checkov check ID (e.g., "CKV_AWS_19")

    Returns:
        CPS234Control if mapping exists, None otherwise
    """
    return CPS234_MAPPING.get(check_id)


def get_cps234_summary(check_ids: list[str]) -> dict[str, dict[str, int]]:
    """
    Generate APRA CPS 234 control summary from a list of check IDs.

    Args:
        check_ids: List of failed Checkov check IDs

    Returns:
        Dictionary mapping control IDs to category and count
    """
    summary: dict[str, dict[str, int]] = {}

    for check_id in check_ids:
        control = get_cps234_mapping(check_id)
        if control:
            if control.control not in summary:
                summary[control.control] = {
                    "category": control.category,
                    "count": 0,
                }
            summary[control.control]["count"] += 1

    return summary


def get_cps234_statistics() -> dict[str, int]:
    """
    Get statistics about the APRA CPS 234 mapping coverage.

    Returns:
        Dictionary with mapping statistics by control and category
    """
    stats: dict[str, int] = {
        "total_mappings": len(CPS234_MAPPING),
        "by_control": {},
        "by_category": {},
    }

    for control in CPS234_MAPPING.values():
        # Count by control ID
        if control.control not in stats["by_control"]:
            stats["by_control"][control.control] = 0
        stats["by_control"][control.control] += 1

        # Count by category
        if control.category not in stats["by_category"]:
            stats["by_category"][control.category] = 0
        stats["by_category"][control.category] += 1

    return stats


# APRA CPS 234 control descriptions for reporting
CPS234_CONTROL_DESCRIPTIONS: dict[str, str] = {
    "CPS234.15": (
        "Information Asset Identification - An APRA-regulated entity must "
        "classify its information assets, including those managed by related "
        "parties and third parties, by criticality and sensitivity"
    ),
    "CPS234.17": (
        "Information Security Capability - An APRA-regulated entity must "
        "maintain an information security capability commensurate with the "
        "size and extent of threats to its information assets"
    ),
    "CPS234.21": (
        "Access Control - An APRA-regulated entity must have controls to "
        "restrict access to information assets commensurate with the "
        "sensitivity and criticality of those information assets"
    ),
    "CPS234.25": (
        "Incident Management - An APRA-regulated entity must have robust "
        "mechanisms in place to detect and respond to information security "
        "incidents in a timely manner"
    ),
    "CPS234.28": (
        "Testing - An APRA-regulated entity must test the effectiveness "
        "of its information security controls through a systematic testing "
        "program"
    ),
    "CPS234.33": (
        "Internal Audit - The internal audit function must review the "
        "design and operating effectiveness of information security "
        "controls, including those maintained by related parties and "
        "third parties"
    ),
    "CPS234.36": (
        "Notification - An APRA-regulated entity must notify APRA of "
        "material information security incidents as soon as possible "
        "and no later than 72 hours after becoming aware"
    ),
}
