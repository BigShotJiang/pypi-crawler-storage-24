"""
Graph-Based Fallback Analyzer.

Uses the cached infrastructure graph to provide dependency analysis
for ANY resource type, not just the ones with dedicated AWS API analyzers.

This enables `replimap deps <resource-id> --analyze` to work for all
resource types present in the scanned graph.
"""

from __future__ import annotations

from typing import Any

from replimap.deps.models import (
    RESOURCE_WEIGHTS,
    Dependency,
    DependencyAnalysis,
    RelationType,
    ResourceCriticality,
    Severity,
)

# Relation type inference based on resource type pairs
_RELATION_HINTS: dict[tuple[str, str], RelationType] = {
    # Network context
    ("aws_instance", "aws_vpc"): RelationType.NETWORK,
    ("aws_instance", "aws_subnet"): RelationType.NETWORK,
    ("aws_db_instance", "aws_vpc"): RelationType.NETWORK,
    ("aws_db_instance", "aws_subnet"): RelationType.NETWORK,
    ("aws_lambda_function", "aws_vpc"): RelationType.NETWORK,
    ("aws_lambda_function", "aws_subnet"): RelationType.NETWORK,
    # Identity / permissions
    ("aws_instance", "aws_iam_role"): RelationType.IDENTITY,
    ("aws_instance", "aws_iam_instance_profile"): RelationType.IDENTITY,
    ("aws_lambda_function", "aws_iam_role"): RelationType.IDENTITY,
    ("aws_ecs_task_definition", "aws_iam_role"): RelationType.IDENTITY,
    # Manager relationships
    ("aws_autoscaling_group", "aws_instance"): RelationType.MANAGED,
    ("aws_ecs_service", "aws_ecs_task_definition"): RelationType.MANAGED,
    # Security
    ("aws_instance", "aws_security_group"): RelationType.DEPENDENCY,
    ("aws_db_instance", "aws_security_group"): RelationType.DEPENDENCY,
    ("aws_lambda_function", "aws_security_group"): RelationType.DEPENDENCY,
    # Replication
    ("aws_db_instance", "aws_db_instance"): RelationType.REPLICATION,
    ("aws_s3_bucket", "aws_s3_bucket"): RelationType.REPLICATION,
}


def _infer_relation_type(source_type: str, target_type: str) -> RelationType:
    """Infer the relation type between two resource types."""
    # Check explicit hints
    hint = _RELATION_HINTS.get((source_type, target_type))
    if hint:
        return hint

    # VPC/subnet targets are always network context
    if target_type in ("aws_vpc", "aws_subnet"):
        return RelationType.NETWORK

    # IAM targets are identity
    if target_type.startswith("aws_iam_"):
        return RelationType.IDENTITY

    # Security group targets are dependencies
    if target_type == "aws_security_group":
        return RelationType.DEPENDENCY

    # KMS targets are dependencies
    if target_type.startswith("aws_kms_"):
        return RelationType.DEPENDENCY

    # Default to generic dependency
    return RelationType.DEPENDENCY


def _severity_for_resource(resource_type: str) -> Severity:
    """Determine severity based on resource criticality weight."""
    weight = RESOURCE_WEIGHTS.get(resource_type, ResourceCriticality.DEFAULT)
    if weight.value >= 9:
        return Severity.CRITICAL
    if weight.value >= 7:
        return Severity.HIGH
    if weight.value >= 5:
        return Severity.MEDIUM
    return Severity.INFO


class GraphFallbackAnalyzer:
    """
    Analyzer that uses the cached graph instead of live AWS API calls.

    Works for any resource type in the graph. Provides the same
    DependencyAnalysis output as the resource-specific analyzers,
    using graph edges to discover dependencies and dependents.
    """

    def __init__(self, graph: Any) -> None:
        """
        Initialize with a graph engine.

        Args:
            graph: GraphEngine or GraphEngineAdapter instance
        """
        self._graph = graph

    @property
    def resource_type(self) -> str:
        return "graph_fallback"

    def analyze(self, resource_id: str, region: str) -> DependencyAnalysis:
        """
        Analyze dependencies using the cached graph.

        Args:
            resource_id: The AWS resource ID
            region: AWS region

        Returns:
            Complete DependencyAnalysis

        Raises:
            ValueError: If resource not found in graph
        """
        resource = self._graph.get_resource(resource_id)
        if resource is None:
            raise ValueError(f"Resource {resource_id} not found in graph")

        # Build center resource
        center = Dependency(
            resource_type=resource.resource_type,
            resource_id=resource.id,
            relation_type=RelationType.DEPENDENCY,
            severity=Severity.INFO,
            resource_name=self._get_name(resource),
        )

        # Collect dependencies (what this resource depends on)
        dependencies: dict[RelationType, list[Dependency]] = {}

        # Downstream dependencies (this resource -> targets)
        downstream = self._graph.get_dependencies(resource_id)
        for dep_node in downstream:
            rel = _infer_relation_type(resource.resource_type, dep_node.resource_type)
            dep = Dependency(
                resource_type=dep_node.resource_type,
                resource_id=dep_node.id,
                relation_type=rel,
                severity=_severity_for_resource(dep_node.resource_type),
                resource_name=self._get_name(dep_node),
            )
            dependencies.setdefault(rel, []).append(dep)

        # Upstream dependents (sources -> this resource) = consumers
        dependents = self._graph.get_dependents(resource_id)
        for dep_node in dependents:
            dep = Dependency(
                resource_type=dep_node.resource_type,
                resource_id=dep_node.id,
                relation_type=RelationType.CONSUMER,
                severity=_severity_for_resource(dep_node.resource_type),
                resource_name=self._get_name(dep_node),
            )
            dependencies.setdefault(RelationType.CONSUMER, []).append(dep)

        # Build context from resource metadata
        context: dict[str, Any] = {
            "region": region,
            "resource_type": resource.resource_type,
            "source": "graph_fallback",
        }
        if hasattr(resource, "tags") and resource.tags:
            context["tags"] = dict(resource.tags)

        # Detect IaC status from tags
        iac_status = self._detect_iac_status(
            resource.tags if hasattr(resource, "tags") and resource.tags else {}
        )

        # Calculate blast radius
        from replimap.deps.blast_radius import calculate_blast_radius

        blast_radius = calculate_blast_radius(dependencies)

        # Generate warnings
        warnings = self._generate_warnings(dependencies, blast_radius)

        return DependencyAnalysis(
            center_resource=center,
            dependencies=dependencies,
            warnings=warnings,
            blast_radius=blast_radius,
            context=context,
            iac_status=iac_status,
        )

    @staticmethod
    def _get_name(resource: Any) -> str | None:
        """Extract friendly name from resource tags."""
        tags = getattr(resource, "tags", None)
        if tags and isinstance(tags, dict):
            return tags.get("Name")
        return None

    @staticmethod
    def _detect_iac_status(tags: dict[str, str]) -> dict[str, Any]:
        """Detect IaC management status from resource tags."""
        status: dict[str, Any] = {
            "managed": False,
            "tool": None,
            "stack": None,
        }

        if "aws:cloudformation:stack-name" in tags:
            status["managed"] = True
            status["tool"] = "cloudformation"
            status["stack"] = tags["aws:cloudformation:stack-name"]
        elif any(k.lower() in ("terraform", "tf_workspace") for k in tags):
            status["managed"] = True
            status["tool"] = "terraform"
        elif "ManagedBy" in tags or "CreatedBy" in tags:
            status["managed"] = True
            status["tool"] = tags.get("ManagedBy") or tags.get("CreatedBy")

        return status

    @staticmethod
    def _generate_warnings(
        dependencies: dict[RelationType, list[Dependency]],
        blast_radius: Any,
    ) -> list[str]:
        """Generate warnings based on analysis results."""
        warnings = []

        # High blast radius
        if blast_radius and blast_radius.level in ("CRITICAL", "HIGH"):
            warnings.append(
                f"High blast radius: {blast_radius.summary}. "
                "Review all affected resources before making changes."
            )

        # Many consumers
        consumers = dependencies.get(RelationType.CONSUMER, [])
        if len(consumers) > 10:
            warnings.append(
                f"This resource has {len(consumers)} consumers. "
                "Changes may have wide-reaching impact."
            )

        # Note about graph-based analysis limitations
        warnings.append(
            "Analysis based on cached graph data. "
            "Use resource-specific analyzers (--analyze) for deeper inspection "
            "when available."
        )

        return warnings
