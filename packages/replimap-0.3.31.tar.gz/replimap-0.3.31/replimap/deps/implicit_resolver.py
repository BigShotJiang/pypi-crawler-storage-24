"""
Implicit Dependency Resolver.

Discovers dependencies that are not captured by explicit config field
patterns (DEPENDENCY_PATTERNS), including:

1. ARN references in IAM policies → resource dependencies
2. Resource ID patterns in string values (env vars, config blocks)
3. CloudFormation stack grouping via tags
4. Endpoint/DNS references pointing to other resources

This resolver scans all string values in resource configs looking for
patterns that reference other known resources in the graph.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)

# AWS resource ID patterns: prefix → resource type
_ID_PATTERNS: dict[str, str] = {
    "vpc-": "aws_vpc",
    "subnet-": "aws_subnet",
    "sg-": "aws_security_group",
    "i-": "aws_instance",
    "vol-": "aws_ebs_volume",
    "snap-": "aws_ebs_snapshot",
    "igw-": "aws_internet_gateway",
    "nat-": "aws_nat_gateway",
    "rtb-": "aws_route_table",
    "acl-": "aws_network_acl",
    "eni-": "aws_network_interface",
    "eipalloc-": "aws_eip",
    "dbi-": "aws_db_instance",
    "db-": "aws_db_instance",
    "tgw-": "aws_ec2_transit_gateway",
}

# Regex to extract AWS resource IDs from arbitrary strings
_ID_REGEX = re.compile(
    r"\b("
    + "|".join(re.escape(prefix) for prefix in _ID_PATTERNS)
    + r")[0-9a-f]{8,17}\b"
)

# ARN regex (captures service, region, account, resource)
_ARN_REGEX = re.compile(
    r"arn:aws[a-zA-Z-]*:"  # partition
    r"([a-zA-Z0-9-]+):"  # service
    r"([a-z0-9-]*):"  # region (may be empty for global)
    r"(\d{12}|):"  # account (may be empty)
    r"(.+)"  # resource
)


@dataclass(frozen=True)
class ImplicitDependency:
    """An implicitly discovered dependency."""

    source_id: str
    target_id: str
    discovery_method: str  # "arn_reference", "id_in_value", "stack_grouping"
    context: str  # Where the reference was found (e.g., field path)

    def __hash__(self) -> int:
        return hash((self.source_id, self.target_id, self.discovery_method))


@dataclass
class ImplicitResolutionReport:
    """Report of implicit dependency resolution."""

    dependencies: list[ImplicitDependency] = field(default_factory=list)
    arn_references_found: int = 0
    id_references_found: int = 0
    stack_groups_found: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "total_implicit_dependencies": len(self.dependencies),
            "arn_references_found": self.arn_references_found,
            "id_references_found": self.id_references_found,
            "stack_groups_found": self.stack_groups_found,
            "dependencies": [
                {
                    "source_id": d.source_id,
                    "target_id": d.target_id,
                    "method": d.discovery_method,
                    "context": d.context,
                }
                for d in self.dependencies
            ],
        }


class ImplicitDependencyResolver:
    """
    Discovers implicit dependencies by scanning resource configs.

    Works with the cached graph — no AWS API calls needed.
    Scans all string values in resource configurations for references
    to other known resources in the graph.
    """

    def __init__(self, graph: Any) -> None:
        """
        Initialize with a graph engine.

        Args:
            graph: GraphEngine or GraphEngineAdapter with scanned resources
        """
        self._graph = graph
        self._known_ids: set[str] = set()
        self._arn_to_id: dict[str, str] = {}
        self._build_index()

    def _build_index(self) -> None:
        """Build lookup indexes from all resources in the graph."""
        for resource in self._graph.get_all_resources():
            self._known_ids.add(resource.id)
            # Index from ResourceNode.arn attribute
            if hasattr(resource, "arn") and resource.arn:
                self._arn_to_id[resource.arn] = resource.id
            # Also index ARN stored in config (common for many AWS resources)
            config = getattr(resource, "config", None)
            if config and isinstance(config, dict):
                config_arn = config.get("arn", "")
                if (
                    config_arn
                    and isinstance(config_arn, str)
                    and config_arn.startswith("arn:")
                ):
                    self._arn_to_id[config_arn] = resource.id

    def resolve(self) -> ImplicitResolutionReport:
        """
        Scan all resources and discover implicit dependencies.

        Returns:
            Report with all discovered implicit dependencies
        """
        report = ImplicitResolutionReport()
        seen: set[tuple[str, str]] = set()

        for resource in self._graph.get_all_resources():
            # Skip if resource has no config
            config = getattr(resource, "config", None)
            if not config:
                continue

            resource_id = resource.id

            # 1. Scan all string values for ARN references
            arns = self._extract_arns(config)
            for arn, context in arns:
                target_id = self._arn_to_id.get(arn)
                if target_id and target_id != resource_id:
                    pair = (resource_id, target_id)
                    if pair not in seen:
                        seen.add(pair)
                        report.dependencies.append(
                            ImplicitDependency(
                                source_id=resource_id,
                                target_id=target_id,
                                discovery_method="arn_reference",
                                context=context,
                            )
                        )
                        report.arn_references_found += 1

            # 2. Scan for resource ID patterns in string values
            ids = self._extract_resource_ids(config)
            for ref_id, context in ids:
                if ref_id in self._known_ids and ref_id != resource_id:
                    pair = (resource_id, ref_id)
                    if pair not in seen:
                        seen.add(pair)
                        report.dependencies.append(
                            ImplicitDependency(
                                source_id=resource_id,
                                target_id=ref_id,
                                discovery_method="id_in_value",
                                context=context,
                            )
                        )
                        report.id_references_found += 1

        # 3. Stack-based grouping (CloudFormation)
        stack_deps = self._resolve_stack_groups()
        for dep in stack_deps:
            pair = (dep.source_id, dep.target_id)
            if pair not in seen:
                seen.add(pair)
                report.dependencies.append(dep)
                report.stack_groups_found += 1

        return report

    def _extract_arns(
        self, config: dict[str, Any], path: str = ""
    ) -> list[tuple[str, str]]:
        """Extract ARN strings from a config dict recursively."""
        results: list[tuple[str, str]] = []
        for key, value in config.items():
            current_path = f"{path}.{key}" if path else key
            if isinstance(value, str):
                if _ARN_REGEX.match(value):
                    results.append((value, current_path))
            elif isinstance(value, dict):
                results.extend(self._extract_arns(value, current_path))
            elif isinstance(value, list):
                for idx, item in enumerate(value):
                    item_path = f"{current_path}[{idx}]"
                    if isinstance(item, str) and _ARN_REGEX.match(item):
                        results.append((item, item_path))
                    elif isinstance(item, dict):
                        results.extend(self._extract_arns(item, item_path))
        return results

    def _extract_resource_ids(
        self, config: dict[str, Any], path: str = ""
    ) -> list[tuple[str, str]]:
        """Extract AWS resource IDs from config string values."""
        results: list[tuple[str, str]] = []
        for key, value in config.items():
            current_path = f"{path}.{key}" if path else key
            if isinstance(value, str):
                for match in _ID_REGEX.finditer(value):
                    results.append((match.group(), current_path))
            elif isinstance(value, dict):
                results.extend(self._extract_resource_ids(value, current_path))
            elif isinstance(value, list):
                for idx, item in enumerate(value):
                    item_path = f"{current_path}[{idx}]"
                    if isinstance(item, str):
                        for match in _ID_REGEX.finditer(item):
                            results.append((match.group(), item_path))
                    elif isinstance(item, dict):
                        results.extend(self._extract_resource_ids(item, item_path))
        return results

    def _resolve_stack_groups(self) -> list[ImplicitDependency]:
        """
        Group resources by CloudFormation stack name.

        Resources in the same stack have an implicit relationship.
        Creates edges from child resources to the stack's "root" resource
        (the one with the most dependencies).
        """
        stacks: dict[str, list[str]] = {}
        for resource in self._graph.get_all_resources():
            tags = getattr(resource, "tags", None)
            if not tags or not isinstance(tags, dict):
                continue
            stack_name = tags.get("aws:cloudformation:stack-name")
            if stack_name:
                stacks.setdefault(stack_name, []).append(resource.id)

        deps: list[ImplicitDependency] = []
        for stack_name, member_ids in stacks.items():
            if len(member_ids) < 2:
                continue

            # Pick the first member as the "anchor" (arbitrary but stable)
            anchor = sorted(member_ids)[0]
            for member_id in member_ids:
                if member_id != anchor:
                    deps.append(
                        ImplicitDependency(
                            source_id=member_id,
                            target_id=anchor,
                            discovery_method="stack_grouping",
                            context=f"cloudformation:{stack_name}",
                        )
                    )

        return deps
