"""RepliMap CLI - AWS Infrastructure Intelligence Engine.

This is the main entry point for the RepliMap CLI.
It delegates to cli/__init__.py's create_app() which is the single source
of truth for V3 architecture (--format, --verbose, envvar, stdout hygiene).

All command implementations are in replimap/cli/commands/*.py.
"""

from __future__ import annotations

from replimap.cli import app
from replimap.cli.utils import console
from replimap.core.signals import setup_signal_handlers


def main() -> None:
    """Entry point for the CLI."""
    # Install global signal handlers for graceful Ctrl-C handling.
    # This prevents ugly threading shutdown exceptions by:
    # 1. Shutting down all tracked thread pools
    # 2. Using os._exit() to skip Python cleanup
    setup_signal_handlers(console)

    # Run the V3 app (created by cli/__init__.py's create_app())
    app()


if __name__ == "__main__":
    main()
