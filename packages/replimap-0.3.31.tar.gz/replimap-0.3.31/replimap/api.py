"""RepliMap Programmatic API - Python-native interface for AI agents and integrations.

This module provides a typed, import-friendly API for RepliMap's core capabilities.
Instead of shelling out to the CLI, Python programs and AI agents can call these
methods directly.

Usage:
    from replimap.api import RepliMap

    rm = RepliMap(profile="prod", region="us-east-1")

    # Scan and cache
    scan_result = rm.scan()

    # Run security audit
    audit_result = rm.audit()

    # Generate Terraform
    codify_result = rm.codify(output_dir="./terraform")

    # Analyze dependencies
    deps_result = rm.deps(resource_id="i-0123456789abcdef0")

    # Estimate costs
    cost_result = rm.cost()

    # DR readiness
    dr_result = rm.dr_readiness()

All methods return dataclasses with .to_dict() for JSON serialization.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import boto3

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class ScanResult:
    """Result of an infrastructure scan."""

    total_resources: int
    total_dependencies: int
    resources_by_type: dict[str, int]
    failed_scanners: list[str]
    region: str
    profile: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "total_resources": self.total_resources,
            "total_dependencies": self.total_dependencies,
            "resources_by_type": dict(self.resources_by_type),
            "failed_scanners": list(self.failed_scanners),
            "region": self.region,
            "profile": self.profile,
        }


@dataclass(frozen=True)
class AuditResult:
    """Result of a security audit."""

    score: float
    grade: str
    passed: int
    failed: int
    skipped: int
    severity_breakdown: dict[str, int]
    findings: list[dict[str, Any]]
    report_path: str | None

    def to_dict(self) -> dict[str, Any]:
        return {
            "score": self.score,
            "grade": self.grade,
            "passed": self.passed,
            "failed": self.failed,
            "skipped": self.skipped,
            "severity_breakdown": dict(self.severity_breakdown),
            "findings": list(self.findings),
            "report_path": self.report_path,
        }


@dataclass(frozen=True)
class CodifyResult:
    """Result of Terraform code generation."""

    output_dir: str
    files_generated: dict[str, str]
    resource_count: int
    import_count: int

    def to_dict(self) -> dict[str, Any]:
        return {
            "output_dir": self.output_dir,
            "files_generated": dict(self.files_generated),
            "resource_count": self.resource_count,
            "import_count": self.import_count,
        }


@dataclass(frozen=True)
class DepsResult:
    """Result of dependency analysis."""

    center_resource: str
    total_affected: int
    max_depth: int
    blast_radius_score: float
    affected_resources: list[dict[str, Any]]

    def to_dict(self) -> dict[str, Any]:
        return {
            "center_resource": self.center_resource,
            "total_affected": self.total_affected,
            "max_depth": self.max_depth,
            "blast_radius_score": self.blast_radius_score,
            "affected_resources": list(self.affected_resources),
        }


@dataclass(frozen=True)
class CostResult:
    """Result of cost estimation."""

    monthly_estimate: float
    annual_estimate: float
    daily_estimate: float
    resource_count: int
    cost_by_service: dict[str, float]
    top_resources: list[dict[str, Any]]
    recommendations: list[dict[str, Any]]

    def to_dict(self) -> dict[str, Any]:
        return {
            "monthly_estimate": self.monthly_estimate,
            "annual_estimate": self.annual_estimate,
            "daily_estimate": self.daily_estimate,
            "resource_count": self.resource_count,
            "cost_by_service": dict(self.cost_by_service),
            "top_resources": list(self.top_resources),
            "recommendations": list(self.recommendations),
        }


@dataclass(frozen=True)
class DRResult:
    """Result of DR readiness assessment."""

    overall_score: float
    grade: str
    tier: str
    gaps: list[dict[str, Any]]
    recommendations: list[dict[str, Any]]

    def to_dict(self) -> dict[str, Any]:
        return {
            "overall_score": self.overall_score,
            "grade": self.grade,
            "tier": self.tier,
            "gaps": list(self.gaps),
            "recommendations": list(self.recommendations),
        }


@dataclass(frozen=True)
class ResidencyResult:
    """Result of data residency validation."""

    policy_name: str
    is_compliant: bool
    resources_checked: int
    resources_compliant: int
    violation_count: int
    severity_breakdown: dict[str, int]
    violations: list[dict[str, Any]]

    def to_dict(self) -> dict[str, Any]:
        return {
            "policy_name": self.policy_name,
            "is_compliant": self.is_compliant,
            "resources_checked": self.resources_checked,
            "resources_compliant": self.resources_compliant,
            "violation_count": self.violation_count,
            "severity_breakdown": dict(self.severity_breakdown),
            "violations": list(self.violations),
        }


@dataclass(frozen=True)
class ValidateResult:
    """Result of topology constraint validation."""

    is_valid: bool
    total_violations: int
    critical_count: int
    high_count: int
    resources_checked: int
    constraints_evaluated: int
    violations: list[dict[str, Any]]
    warnings: list[str]

    def to_dict(self) -> dict[str, Any]:
        return {
            "is_valid": self.is_valid,
            "total_violations": self.total_violations,
            "critical_count": self.critical_count,
            "high_count": self.high_count,
            "resources_checked": self.resources_checked,
            "constraints_evaluated": self.constraints_evaluated,
            "violations": list(self.violations),
            "warnings": list(self.warnings),
        }


@dataclass(frozen=True)
class GraphResult:
    """Result of graph generation."""

    output_path: str
    node_count: int
    edge_count: int
    resource_types: dict[str, int]

    def to_dict(self) -> dict[str, Any]:
        return {
            "output_path": self.output_path,
            "node_count": self.node_count,
            "edge_count": self.edge_count,
            "resource_types": dict(self.resource_types),
        }


class RepliMap:
    """Programmatic API for RepliMap operations.

    This class provides a Python-native interface to RepliMap's core
    capabilities. It handles AWS session management, caching, and
    graph lifecycle internally.

    Args:
        profile: AWS profile name (default: "default")
        region: AWS region (default: "us-east-1")
        cache: Enable disk caching of scan results (default: True)
    """

    def __init__(
        self,
        profile: str = "default",
        region: str = "us-east-1",
        cache: bool = True,
    ) -> None:
        self._profile = profile
        self._region = region
        self._cache_enabled = cache
        self._graph: Any = None  # Lazy-loaded GraphEngine

    def _get_session(self) -> boto3.Session:
        """Create a boto3 session for the configured profile."""
        return boto3.Session(profile_name=self._profile)

    def _ensure_graph(self, refresh: bool = False) -> Any:
        """Ensure graph is loaded (from cache or fresh scan)."""
        if self._graph is not None and not refresh:
            return self._graph

        from replimap.core import GraphEngine
        from replimap.core.cache_manager import get_or_load_graph, save_graph_to_cache
        from replimap.scanners.base import run_all_scanners

        if self._cache_enabled and not refresh:
            cached_graph, _meta = get_or_load_graph(
                profile=self._profile,
                region=self._region,
                console=None,
                refresh=False,
            )
            if cached_graph is not None:
                self._graph = cached_graph
                return self._graph

        session = self._get_session()
        graph = GraphEngine()
        scanner_results = run_all_scanners(session, graph, self._region)

        failed = [name for name, err in scanner_results.items() if err is not None]
        if failed:
            logger.warning("Scanners failed: %s", ", ".join(failed))

        if self._cache_enabled:
            save_graph_to_cache(
                graph=graph,
                profile=self._profile,
                region=self._region,
                console=None,
            )

        self._graph = graph
        return self._graph

    def scan(self, refresh: bool = False) -> ScanResult:
        """Scan AWS infrastructure and build dependency graph.

        Args:
            refresh: Force fresh scan (ignore cache)

        Returns:
            ScanResult with resource counts and scanner status
        """
        from replimap.core import GraphEngine
        from replimap.core.cache_manager import save_graph_to_cache
        from replimap.scanners.base import run_all_scanners

        session = self._get_session()
        graph = GraphEngine()
        scanner_results = run_all_scanners(session, graph, self._region)

        failed = [name for name, err in scanner_results.items() if err is not None]

        if self._cache_enabled:
            save_graph_to_cache(
                graph=graph,
                profile=self._profile,
                region=self._region,
                console=None,
            )

        self._graph = graph

        # Count resources by type
        by_type: dict[str, int] = {}
        for node in graph.nodes:
            rtype = node.get("resource_type", "unknown")
            by_type[rtype] = by_type.get(rtype, 0) + 1

        return ScanResult(
            total_resources=len(graph.nodes),
            total_dependencies=len(graph.edges),
            resources_by_type=by_type,
            failed_scanners=failed,
            region=self._region,
            profile=self._profile,
        )

    def audit(
        self,
        output_dir: str | Path | None = None,
        refresh: bool = False,
    ) -> AuditResult:
        """Run security audit on infrastructure.

        Args:
            output_dir: Directory for audit Terraform output (for Checkov)
            refresh: Force fresh scan before audit

        Returns:
            AuditResult with findings and compliance score
        """
        import tempfile

        from replimap.audit import AuditEngine

        graph = self._ensure_graph(refresh=refresh)

        audit_dir = Path(output_dir) if output_dir else Path(tempfile.mkdtemp())
        report_path = audit_dir / "audit_report.json"

        engine = AuditEngine()
        results, report = engine.run(
            output_dir=str(audit_dir),
            report_path=str(report_path),
            skip_scan=False,
            graph=graph,
        )

        # Build severity breakdown
        severity_breakdown: dict[str, int] = {
            "critical": 0,
            "high": 0,
            "medium": 0,
            "low": 0,
        }
        findings_list = []
        for finding in results.failed_checks:
            sev = getattr(finding, "severity", "medium") or "medium"
            sev_lower = sev.lower() if isinstance(sev, str) else "medium"
            if sev_lower in severity_breakdown:
                severity_breakdown[sev_lower] += 1
            findings_list.append(
                {
                    "check_id": getattr(finding, "check_id", ""),
                    "check_name": getattr(finding, "name", ""),
                    "severity": sev_lower,
                    "resource": getattr(finding, "resource", ""),
                }
            )

        return AuditResult(
            score=results.score,
            grade=results.grade,
            passed=results.passed_count,
            failed=results.failed_count,
            skipped=results.skipped_count,
            severity_breakdown=severity_breakdown,
            findings=findings_list,
            report_path=str(report_path) if report_path.exists() else None,
        )

    def codify(
        self,
        output_dir: str | Path = "./terraform",
        primary_region: str | None = None,
        include_global: bool = False,
        refresh: bool = False,
    ) -> CodifyResult:
        """Generate Terraform configurations from scanned resources.

        Args:
            output_dir: Directory for generated Terraform files
            primary_region: Primary region for global resources
            include_global: Include IAM/Route53 global resources
            refresh: Force fresh scan

        Returns:
            CodifyResult with generated files info
        """
        from replimap.codify import CodifyOutputGenerator, get_codify_pipeline

        graph = self._ensure_graph(refresh=refresh)

        pipeline = get_codify_pipeline(
            region=self._region,
            primary_region=primary_region or self._region,
            include_global=include_global,
        )
        transformed_graph = pipeline.execute(graph)

        out_path = Path(output_dir)
        generator = CodifyOutputGenerator()
        generated_files = generator.generate(transformed_graph, out_path)

        return CodifyResult(
            output_dir=str(out_path),
            files_generated={name: str(path) for name, path in generated_files.items()},
            resource_count=len(transformed_graph.nodes),
            import_count=sum(1 for n in transformed_graph.nodes if n.get("_import_id")),
        )

    def deps(
        self,
        resource_id: str,
        max_depth: int = 3,
        refresh: bool = False,
    ) -> DepsResult:
        """Analyze dependency blast radius for a resource.

        Args:
            resource_id: AWS resource ID to analyze
            max_depth: Maximum traversal depth
            refresh: Force fresh scan

        Returns:
            DepsResult with blast radius analysis
        """
        from replimap.dependencies import DependencyGraphBuilder, ImpactCalculator

        graph = self._ensure_graph(refresh=refresh)

        builder = DependencyGraphBuilder()
        dep_graph = builder.build_from_graph_engine(graph, self._region)

        calculator = ImpactCalculator(dep_graph)
        result = calculator.calculate_blast_radius(
            resource_id=resource_id,
            max_depth=max_depth,
        )

        result_dict = result.to_dict()
        affected = result_dict.get("affected_resources", [])

        return DepsResult(
            center_resource=resource_id,
            total_affected=result_dict.get("summary", {}).get("total_affected", 0),
            max_depth=max_depth,
            blast_radius_score=result_dict.get("summary", {}).get(
                "estimated_score", 0.0
            ),
            affected_resources=affected,
        )

    def cost(self, refresh: bool = False) -> CostResult:
        """Estimate infrastructure costs.

        Args:
            refresh: Force fresh scan

        Returns:
            CostResult with cost breakdown
        """
        from replimap.cost import CostEstimator

        graph = self._ensure_graph(refresh=refresh)

        estimator = CostEstimator()
        estimate = estimator.estimate_from_graph_engine(graph)
        est_dict = estimate.to_dict()
        summary = est_dict.get("summary", {})

        # Extract cost by service/category
        cost_by_service: dict[str, float] = {}
        for cat in est_dict.get("by_category", []):
            name = cat.get("category", "unknown")
            cost_by_service[name] = cat.get("monthly", 0.0)

        return CostResult(
            monthly_estimate=summary.get("monthly_estimate", 0.0),
            annual_estimate=summary.get("annual_estimate", 0.0),
            daily_estimate=summary.get("daily_estimate", 0.0),
            resource_count=summary.get("total_resources", 0),
            cost_by_service=cost_by_service,
            top_resources=est_dict.get("top_resources", [])[:10],
            recommendations=est_dict.get("recommendations", []),
        )

    def dr_readiness(
        self,
        target_tier: str = "tier_2",
        dr_region: str | None = None,
        refresh: bool = False,
    ) -> DRResult:
        """Assess disaster recovery readiness.

        Args:
            target_tier: Target DR tier (tier_0 through tier_4)
            dr_region: DR region for replica checks
            refresh: Force fresh scan

        Returns:
            DRResult with readiness score and recommendations
        """
        from replimap.dr.readiness import DRReadinessAssessor, DRTier

        graph = self._ensure_graph(refresh=refresh)

        tier_map = {
            "tier_0": DRTier.TIER_0,
            "tier_1": DRTier.TIER_1,
            "tier_2": DRTier.TIER_2,
            "tier_3": DRTier.TIER_3,
            "tier_4": DRTier.TIER_4,
        }
        tier = tier_map.get(target_tier, DRTier.TIER_2)

        assessor = DRReadinessAssessor()
        result = assessor.assess(graph=graph, target_tier=tier)
        result_dict = result.to_dict()

        return DRResult(
            overall_score=result_dict.get("overall_score", 0.0),
            grade=result_dict.get("grade", "F"),
            tier=target_tier,
            gaps=result_dict.get("gaps", []),
            recommendations=result_dict.get("recommendations", []),
        )

    def residency(
        self,
        policy: str = "nz_au",
        custom_regions: list[str] | None = None,
        refresh: bool = False,
    ) -> ResidencyResult:
        """Validate data residency compliance.

        Args:
            policy: Policy preset: "nz_au", "au_only", or "custom"
            custom_regions: List of approved regions (for "custom" policy)
            refresh: Force fresh scan

        Returns:
            ResidencyResult with compliance status and violations
        """
        from replimap.compliance.data_residency import (
            DataResidencyPolicy,
            DataResidencyValidator,
        )

        graph = self._ensure_graph(refresh=refresh)

        if policy == "au_only":
            residency_policy = DataResidencyPolicy.au_only()
        elif policy == "custom":
            residency_policy = DataResidencyPolicy.custom(
                name="Custom Policy",
                regions=custom_regions or [],
            )
        else:
            residency_policy = DataResidencyPolicy.nz_au()

        validator = DataResidencyValidator(residency_policy)
        report = validator.validate(graph)
        report_dict = report.to_dict()

        return ResidencyResult(
            policy_name=residency_policy.name,
            is_compliant=report.is_compliant,
            resources_checked=report.resources_checked,
            resources_compliant=report.resources_compliant,
            violation_count=len(report.violations),
            severity_breakdown=report_dict["severity_breakdown"],
            violations=report_dict["violations"],
        )

    def validate(
        self,
        constraints_file: str | Path = "constraints.yaml",
        refresh: bool = False,
    ) -> ValidateResult:
        """Validate infrastructure against topology constraints.

        Args:
            constraints_file: Path to constraints YAML file
            refresh: Force fresh scan

        Returns:
            ValidateResult with validation status and violations
        """
        from replimap.core.topology_constraints import (
            TopologyConstraintsConfig,
            TopologyValidator,
        )

        graph = self._ensure_graph(refresh=refresh)

        config_path = Path(constraints_file)
        if not config_path.exists():
            return ValidateResult(
                is_valid=False,
                total_violations=0,
                critical_count=0,
                high_count=0,
                resources_checked=0,
                constraints_evaluated=0,
                violations=[],
                warnings=[f"Constraints file not found: {constraints_file}"],
            )

        config = TopologyConstraintsConfig.from_yaml(config_path)
        validator = TopologyValidator(config)
        result = validator.validate(graph)
        result_dict = result.to_dict()
        summary = result_dict.get("summary", {})

        return ValidateResult(
            is_valid=result.is_valid,
            total_violations=summary.get("total_violations", 0),
            critical_count=summary.get("critical", 0),
            high_count=summary.get("high", 0),
            resources_checked=summary.get("resources_checked", 0),
            constraints_evaluated=summary.get("constraints_evaluated", 0),
            violations=result_dict.get("violations", []),
            warnings=result_dict.get("warnings", []),
        )

    def graph(
        self,
        output_path: str | Path = "infrastructure_graph.html",
        output_format: str = "html",
        refresh: bool = False,
    ) -> GraphResult:
        """Generate infrastructure visualization.

        Args:
            output_path: Output file path
            output_format: Output format (html, mermaid, json)
            refresh: Force fresh scan

        Returns:
            GraphResult with graph metadata
        """
        from replimap.graph import GraphVisualizer

        graph = self._ensure_graph(refresh=refresh)

        visualizer = GraphVisualizer()
        result_path = visualizer.generate(
            graph=graph,
            output_path=str(output_path),
            output_format=output_format,
        )

        # Count resource types
        by_type: dict[str, int] = {}
        for node in graph.nodes:
            rtype = node.get("resource_type", "unknown")
            by_type[rtype] = by_type.get(rtype, 0) + 1

        return GraphResult(
            output_path=str(result_path),
            node_count=len(graph.nodes),
            edge_count=len(graph.edges),
            resource_types=by_type,
        )


__all__ = [
    "AuditResult",
    "CodifyResult",
    "CostResult",
    "DRResult",
    "DepsResult",
    "GraphResult",
    "RepliMap",
    "ResidencyResult",
    "ScanResult",
    "ValidateResult",
]
