<!--
<p align="center">
  <img src="docs/assets/logo.png" alt="RepliMap Logo" width="120" />
</p>
-->

<h1 align="center">RepliMap</h1>

<p align="center">
  <strong>AWS Infrastructure Intelligence Engine</strong>
</p>

<p align="center">
  Scan existing AWS infrastructure, generate Terraform code, and detect compliance drift against SOC 2, HIPAA, and PCI DSS.
</p>

<p align="center">
  <a href="#quick-start">Quick Start</a> •
  <a href="#features">Features</a> •
  <a href="#compliance-coverage">Compliance</a> •
  <a href="#installation">Installation</a> •
  <a href="#documentation">Docs</a>
</p>

<p align="center">
  <a href="https://pypi.org/project/replimap/">
    <img src="https://img.shields.io/pypi/v/replimap?color=blue&label=PyPI" alt="PyPI" />
  </a>
  <img src="https://img.shields.io/badge/python-3.10+-blue.svg" alt="Python 3.10+" />
  <a href="https://github.com/RepliMap/replimap/actions/workflows/auto-release.yml">
    <img src="https://github.com/RepliMap/replimap/actions/workflows/auto-release.yml/badge.svg?branch=main" alt="Build" />
  </a>
  <a href="https://github.com/RepliMap/replimap/blob/main/LICENSE">
    <img src="https://img.shields.io/badge/license-BSL--1.1-green.svg" alt="License" />
  </a>
</p>

<p align="center">
  <img src="docs/assets/demo.gif" alt="RepliMap Demo" width="700" />
</p>

---

## Features

- **Reverse Terraform** — Scan any AWS account and generate clean, modular HCL
- **Drift Detection** — Compare Terraform state against actual AWS configuration
- **Compliance Lens** — Map infrastructure drift to SOC 2, HIPAA, PCI DSS controls
- **Audit-Ready Reports** — Generate markdown reports your auditor can read directly
- **Risk Exemptions** — Document and track accepted risks with expiry dates
- **Data Sovereignty** — Everything runs locally. No data leaves your machine.

---

## Quick Start

### Installation

```bash
# Using pipx (recommended)
pipx install replimap

# Using pip
pip install replimap

# Verify
replimap --version
```

### Scan and Generate Terraform

```bash
# Scan your AWS account
replimap -p prod -r us-east-1 scan

# Generate Terraform from scanned infrastructure
replimap -p prod -r us-east-1 codify -o ./terraform
```

### Check Compliance Drift

```bash
# Compare TF state against AWS and check SOC 2 compliance
replimap drift -s terraform.tfstate --compliance soc2

# Generate audit-ready markdown report
replimap drift -s terraform.tfstate -c soc2 -f markdown -o compliance-report.md

# Check all frameworks at once
replimap drift -s terraform.tfstate -c all

# Use risk exemptions
replimap drift -s terraform.tfstate -c all --ignore-file .replimap-ignore.yml
```

### Generate SOC 2 Evidence Report

```bash
# Full evidence report with PASS/FAIL for every resource
replimap audit -s terraform.tfstate --company "Acme Corp" --period "2026-Q1" -o soc2-evidence.md
```

---

## Compliance Coverage

RepliMap maps 12 infrastructure checks to SOC 2, HIPAA, and PCI DSS controls.

| Rule | Resource | Check | SOC 2 | HIPAA | PCI DSS |
|------|----------|-------|-------|-------|---------|
| s3-encryption-enabled | S3 Bucket | Default encryption | CC6.1 | §164.312(a)(2)(iv) | 3.4.1 |
| rds-encryption-enabled | RDS Instance | Storage encryption | CC6.1 | §164.312(a)(2)(iv) | 3.4 |
| kms-key-rotation-enabled | KMS Key | Key rotation | CC6.1 | — | — |
| s3-no-public-acl | S3 Bucket | ACL not public | CC6.6 | §164.312(e)(1) | 1.3 |
| rds-not-publicly-accessible | RDS Instance | Not publicly accessible | CC6.6 | — | 1.3 |
| sg-no-unrestricted-ingress | Security Group | No 0.0.0.0/0 on sensitive ports | CC6.6 | — | 1.2.1 |
| sg-no-unrestricted-egress | Security Group | Egress restrictions | CC6.6 | — | — |
| iam-trust-policy | IAM Role | Trust policy review | CC6.1 | — | — |
| s3-logging-enabled | S3 Bucket | Access logging | CC7.1 | §164.312(b) | 10.1 |
| s3-versioning-enabled | S3 Bucket | Versioning enabled | CC8.1 | — | — |
| rds-multi-az-enabled | RDS Instance | Multi-AZ availability | CC7.1 | — | — |
| rds-backup-retention | RDS Instance | Backup >= 7 days | CC7.1 | — | — |

### How It Works

1. `DriftEngine` compares your Terraform state against actual AWS resources
2. `ComplianceMappingEngine` maps attribute diffs to framework controls
3. Value-aware checking prevents false positives (e.g., fixing `publicly_accessible: True → False` is not a violation)
4. Port-aware SG analysis: 0.0.0.0/0 on SSH/RDP/DB ports is critical; HTTP/HTTPS is acceptable

---

## Risk Exemptions

Document accepted risks in `.replimap-ignore.yml`:

```yaml
exceptions:
  - resource: aws_s3_bucket.public_website
    attribute: acl
    reason: "Public website bucket, approved by CISO"
    approved_by: "jane@acme.com"
    expires: "2026-12-31"
```

Exemptions appear as "Accepted Risks" in reports. Expired exemptions are automatically flagged and restored as active findings.

---

## Commands

| Command | Description |
|---------|-------------|
| `replimap scan` | Scan AWS resources and build dependency graph |
| `replimap codify` | Generate Terraform from scanned infrastructure |
| `replimap drift` | Detect infrastructure drift between TF state and AWS |
| `replimap audit` | Security audit (Checkov-based or SOC 2 evidence with `--state`) |
| `replimap graph` | Generate visual dependency graph |
| `replimap analyze` | Analyze for critical resources, SPOFs, blast radius |
| `replimap cost` | Estimate monthly AWS costs |
| `replimap deps` | Explore dependencies for a resource |
| `replimap unused` | Detect unused and underutilized resources |

<details>
<summary>View all commands</summary>

```bash
replimap --help
```

Additional commands: `clone`, `snapshot`, `dr`, `trends`, `transfer`, `iam`, `trust-center`, `remediate`, `validate`, `residency`, `doctor`, `license`, `upgrade`

</details>

---

## Architecture

RepliMap is built around a **Graph Engine** powered by NetworkX. It transforms discrete cloud resources into a connected dependency graph, enabling impact analysis, visualization, and intelligent code generation.

```
┌──────────────────────────────────────────────────────────────────┐
│                         RepliMap Architecture                    │
├──────────────────────────────────────────────────────────────────┤
│                                                                  │
│   ┌─────────────┐     ┌─────────────┐     ┌─────────────┐       │
│   │  Scanners   │────>│   Graph     │────>│  Renderers  │       │
│   │  (AWS API)  │     │   Engine    │     │  (Terraform)│       │
│   └─────────────┘     └──────┬──────┘     └─────────────┘       │
│                              │                                   │
│         ┌────────────────────┼────────────────────┐             │
│         │                    │                    │             │
│         v                    v                    v             │
│   ┌───────────┐      ┌─────────────┐      ┌───────────┐        │
│   │ Compliance │      │ Right-Sizer │      │   Drift   │        │
│   │   Engine   │      │   Engine    │      │  Detector │        │
│   └───────────┘      └─────────────┘      └───────────┘        │
│                                                                  │
└──────────────────────────────────────────────────────────────────┘
```

### Supported Resources

<details>
<summary>View all 24 supported resource types</summary>

| Category | Resources |
|----------|-----------|
| **Compute** | EC2, Lambda, ECS, EKS |
| **Database** | RDS, Aurora, DynamoDB, ElastiCache |
| **Network** | VPC, Subnet, Security Group, Route Table, NAT Gateway, Internet Gateway, ALB/NLB |
| **Storage** | S3, EBS, EFS |
| **Security** | IAM Role, IAM Policy, KMS Key, Secrets Manager |
| **Other** | CloudWatch, SNS, SQS |

</details>

---

## Configuration

### AWS Credentials

RepliMap uses standard AWS credential chain:

```bash
# AWS CLI profile (recommended)
replimap -p my-profile scan

# Environment variables
export AWS_ACCESS_KEY_ID=xxx
export AWS_SECRET_ACCESS_KEY=xxx
replimap scan

# IAM role (EC2/ECS/Lambda)
replimap scan  # Auto-detects instance role
```

### Required IAM Permissions

RepliMap only needs **read-only** access. See [IAM_POLICY.md](IAM_POLICY.md) for the minimal policy.

---

## Security & Privacy

**Your data never leaves your machine.**

- RepliMap runs entirely client-side
- No cloud account required
- Read-only AWS access (no modifications)
- Sensitive data (passwords, keys) automatically redacted
- SOC 2-compliant design

See [SECURITY.md](SECURITY.md) for details.

---

## Roadmap

- [ ] compliance.tf integration for scan output
- [ ] EKS, DynamoDB, CloudTrail, VPC Flow Logs coverage
- [ ] CI/CD integration templates (GitHub Actions, Azure DevOps)
- [ ] Pulumi and CDK output formats

---

## Pricing

| | Community (Free) | Pro ($29/mo) | Team ($99/mo) | Sovereign ($2,500/mo) |
|---|---|---|---|---|
| Unlimited scans | ✅ | ✅ | ✅ | ✅ |
| Terraform preview | ✅ | ✅ | ✅ | ✅ |
| Download Terraform | — | ✅ | ✅ | ✅ |
| Compliance audit | Basic | Full | Full | Full |
| Drift detection | — | — | ✅ | ✅ |
| CI/CD integration | — | — | ✅ | ✅ |
| APRA/RBNZ compliance | — | — | — | ✅ |

[View full pricing](https://replimap.com/pricing)

---

## Contributing

We welcome contributions. See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

```bash
git clone git@github.com:RepliMap/replimap.git
cd replimap
pip install -e ".[dev]"
pytest
```

---

## Documentation

- [Installation Guide](docs/installation.md)
- [Quick Start Tutorial](docs/quickstart.md)
- [CLI Reference](docs/cli-reference.md)
- [IAM Policy](IAM_POLICY.md)

## Support

| Purpose | Contact |
|---------|---------|
| General inquiries | [hello@replimap.com](mailto:hello@replimap.com) |
| Technical support | [support@replimap.com](mailto:support@replimap.com) |
| Enterprise & Sales | [david@replimap.com](mailto:david@replimap.com) |
| Bug reports | [GitHub Issues](https://github.com/RepliMap/replimap/issues) |

---

## License

RepliMap is licensed under the [Business Source License 1.1](LICENSE.md).

[View full pricing](https://replimap.com/pricing)

---

<p align="center">
  <a href="https://replimap.com">Website</a> •
  <a href="https://docs.replimap.com">Docs</a> •
  <a href="https://twitter.com/replimap">Twitter</a>
</p>

<p align="center">
  Made with ☕ in New Zealand
</p>
