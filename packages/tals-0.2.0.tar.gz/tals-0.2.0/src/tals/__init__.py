from ._slicer import slice_objects

__all__ = ["slice_objects"]
__version__ = "0.2.0"
