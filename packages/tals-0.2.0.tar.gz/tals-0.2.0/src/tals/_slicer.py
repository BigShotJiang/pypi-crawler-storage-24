from datetime import datetime
from typing import Any

from ._parser import (
    CalendarBound,
    DeltaBound,
    IndexPosition,
    IntBound,
    SlicePosition,
    parse_position,
)
from ._resolver import resolve_to_datetime


def _get(obj: Any, key: str) -> Any:
    return obj[key] if isinstance(obj, dict) else getattr(obj, key)


def _is_temporal(bound) -> bool:
    return isinstance(bound, (DeltaBound, CalendarBound))


def _validate_tz(objects: list, reference_dt: datetime, timestamp_key: str) -> None:
    ref_aware = reference_dt.tzinfo is not None
    for i, obj in enumerate(objects):
        ts = _get(obj, timestamp_key)  # AttributeError propagates naturally
        obj_aware = ts.tzinfo is not None
        if obj_aware != ref_aware:
            ref_state = "aware" if ref_aware else "naive"
            obj_state = "aware" if obj_aware else "naive"
            raise TypeError(
                f"Timezone awareness mismatch: reference_dt is {ref_state} but "
                f"object at index {i} has a {obj_state} timestamp."
            )


def slice_objects(
    objects: list[Any],
    position: str,
    timestamp_key: str,
    reference_dt: datetime,
    week_start: int = 0,
    presorted: bool = False,
    inclusive_end: bool = False,
) -> "Any | list[Any]":
    """Slice a list of objects or dicts using time-aware position expressions.

    The list is stable-sorted ascending by timestamp_key before slicing unless
    presorted=True. All index and time references operate on the sorted list.

    Args:
        objects:      List of objects or dicts to slice.
        position:     Slice expression. Supports integer indices, time-delta
                      bounds (-7d, +2h, -30m), and calendar-period bounds
                      (0M, -1W, +1Y). Examples: "-1", "0M:", "-1M:0M",
                      "-7d:-1", "[:]".
        timestamp_key: Attribute name (objects) or key (dicts) holding each
                      item's datetime value.
        reference_dt: The anchor for all relative expressions. The library
                      never calls datetime.now() — the caller supplies this.
        week_start:   First day of the week for W period resolution.
                      0 = Monday (default), 6 = Sunday.
        presorted:    Set to True to skip sorting when the list is already in
                      ascending timestamp order.
        inclusive_end: Set to True to make the end bound inclusive. For
                      temporal bounds, items whose timestamp equals end_dt are
                      included. For integer bounds, the item at the end index
                      is included.

    Returns:
        A single object (or None if out of bounds) for index expressions such
        as "-1" or "0". A list (possibly empty) for slice expressions such as
        "0M:" or ":-1".

    Raises:
        TypeError:    If timezone awareness is inconsistent across reference_dt
                      and object timestamps.
        AttributeError: If an object is missing the timestamp_key attribute.
        KeyError:     If a dict is missing the timestamp_key key.
        ValueError:   If the position expression is invalid.
    """
    _validate_tz(objects, reference_dt, timestamp_key)
    sorted_objs = objects if presorted else sorted(objects, key=lambda o: _get(o, timestamp_key))

    parsed = parse_position(position)

    if isinstance(parsed, IndexPosition):
        try:
            return sorted_objs[parsed.bound.value]
        except IndexError:
            return None

    assert isinstance(parsed, SlicePosition)
    start, end = parsed.start, parsed.end

    if not (_is_temporal(start) or _is_temporal(end)):
        s = start.value if isinstance(start, IntBound) else None
        e = end.value if isinstance(end, IntBound) else None
        if inclusive_end and e is not None:
            e = (e + 1) or None
        return sorted_objs[s:e]

    # Temporal path: resolve datetime thresholds, filter, then apply integer bounds.
    start_dt = (
        resolve_to_datetime(start, reference_dt, week_start)
        if _is_temporal(start)
        else None
    )
    end_dt = (
        resolve_to_datetime(end, reference_dt, week_start)
        if _is_temporal(end)
        else None
    )

    # Inclusive start; end is exclusive by default, inclusive when inclusive_end=True.
    end_op = (lambda ts, threshold: ts <= threshold) if inclusive_end else (lambda ts, threshold: ts < threshold)
    filtered = [
        obj
        for obj in sorted_objs
        if (start_dt is None or _get(obj, timestamp_key) >= start_dt)
        and (end_dt is None or end_op(_get(obj, timestamp_key), end_dt))
    ]

    s = start.value if isinstance(start, IntBound) else None
    e = end.value if isinstance(end, IntBound) else None
    if inclusive_end and e is not None:
        e = (e + 1) or None
    return filtered[s:e]
