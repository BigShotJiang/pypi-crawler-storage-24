"""Spec example table.

Objects:
    A: start = 2026-01-10
    B: start = 2026-02-05
    C: start = 2026-03-01
    D: start = 2026-03-10  ← reference_dt

reference_dt = 2026-03-10, timestamp_key = "start", week_start = 0

Note on [-60d:]: reference_dt - 60d = 2026-01-09. A (Jan 10) >= Jan 9, so A
is included. The spec example comment says [B, C, D] but that appears to be an
error — the threshold is Jan 9, not Jan 10.
"""

from datetime import datetime
from types import SimpleNamespace

import pytest

from tals import slice_objects


def obj(year, month, day, name):
    o = SimpleNamespace(start=datetime(year, month, day), name=name)
    return o


A = obj(2026, 1, 10, "A")
B = obj(2026, 2, 5, "B")
C = obj(2026, 3, 1, "C")
D = obj(2026, 3, 10, "D")

OBJECTS = [A, B, C, D]
REF = datetime(2026, 3, 10)


def sl(position):
    return slice_objects(OBJECTS, position, "start", REF, week_start=0)


@pytest.mark.parametrize(
    "position,expected",
    [
        ("[-1]", D),
        ("[-2]", C),
        ("[0]", A),
        ("[:]", [A, B, C, D]),
        ("[:-1]", [A, B, C]),
        ("[0M:]", [C, D]),
        ("[-1M:0M]", [B]),
        ("[-1M:]", [B, C, D]),
        ("[0Y:]", [A, B, C, D]),
        ("[0M:-1]", [C]),
        ("[:-2]", [A, B]),
    ],
)
def test_spec_example(position, expected):
    assert sl(position) == expected


def test_spec_example_60d():
    # reference_dt - 60d = 2026-01-09; A (Jan 10) >= Jan 9 → A is included
    assert sl("[-60d:]") == [A, B, C, D]
