from datetime import datetime, timezone
from types import SimpleNamespace


def make_obj(dt: datetime) -> SimpleNamespace:
    return SimpleNamespace(start=dt)


def dt(year, month, day, hour=0, minute=0, tz=None):
    return datetime(year, month, day, hour, minute, tzinfo=tz)


REF = datetime(2026, 3, 10)
UTC = timezone.utc
