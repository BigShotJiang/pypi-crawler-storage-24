from setuptools import setup, find_packages
import os

# Read README for long description
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

# Read requirements
with open("requirements.txt", "r", encoding="utf-8") as fh:
    requirements = [line.strip() for line in fh if line.strip() and not line.startswith("#")]

setup(
    name="inventpay",
    version="1.2.1",
    author="InventPay",
    author_email="support@inventpay.io",
    description="Official Python SDK for InventPay - Accept crypto payments with ease",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://docs.inventpay.io",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    python_requires=">=3.7",
    install_requires=requirements,
    keywords="inventpay, cryptocurrency, payments, bitcoin, ethereum, crypto, sdk, digital-products, storefront, withdrawal",
    project_urls={
        "Documentation": "https://docs.inventpay.io",
    },
)