"""Capabilities module for robomotion."""
import sys

# Re-export from runtime for backwards compatibility
from robomotion.runtime import IsLMOCapable


class Capability:
    CapabilityLMO = 1 << 4


capabilities = []
_robot_capabilities = 0


def add_capability(capability):
    capabilities.append(capability)


def get_capabilities():
    _capabilities = sys.maxsize
    for cap in capabilities:
        _capabilities &= cap
    return _capabilities


def set_robot_capabilities(caps):
    """Store the robot's capability bitmask (received from deskbot)."""
    global _robot_capabilities
    _robot_capabilities = int(caps)


def has_capability(cap):
    """Two-way intersection: both robot and package must declare the capability."""
    return (_robot_capabilities & get_capabilities() & cap) != 0


def init_capabilities():
    add_capability(Capability.CapabilityLMO)


init_capabilities()
