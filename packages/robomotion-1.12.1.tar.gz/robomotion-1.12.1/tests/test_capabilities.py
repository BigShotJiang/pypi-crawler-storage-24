"""Tests for robomotion.capabilities — capability intersection logic."""
import pytest

import robomotion.capabilities as caps_mod
from robomotion.capabilities import Capability


@pytest.fixture(autouse=True)
def reset_robot_caps():
    """Reset robot capabilities before each test."""
    caps_mod._robot_capabilities = 0
    yield
    caps_mod._robot_capabilities = 0


class TestSetRobotCapabilities:
    def test_set_and_read(self):
        caps_mod.set_robot_capabilities(Capability.CapabilityLMO)
        assert caps_mod._robot_capabilities == Capability.CapabilityLMO

    def test_set_float_cast(self):
        caps_mod.set_robot_capabilities(16.0)
        assert caps_mod._robot_capabilities == 16

    def test_set_zero(self):
        caps_mod.set_robot_capabilities(Capability.CapabilityLMO)
        caps_mod.set_robot_capabilities(0)
        assert caps_mod._robot_capabilities == 0


class TestHasCapability:
    def test_both_declare_lmo(self):
        """Package declares LMO (via init_capabilities), robot also declares it."""
        caps_mod.set_robot_capabilities(Capability.CapabilityLMO)
        assert caps_mod.has_capability(Capability.CapabilityLMO) is True

    def test_robot_missing_lmo(self):
        """Robot doesn't declare LMO — intersection is 0."""
        caps_mod.set_robot_capabilities(0)
        assert caps_mod.has_capability(Capability.CapabilityLMO) is False

    def test_robot_has_other_bits(self):
        """Robot has some bits set but not LMO."""
        caps_mod.set_robot_capabilities(0b00001)  # bit 0 only
        assert caps_mod.has_capability(Capability.CapabilityLMO) is False

    def test_robot_has_multiple_bits_including_lmo(self):
        """Robot has LMO plus other bits."""
        caps_mod.set_robot_capabilities(0b11111)  # bits 0-4
        assert caps_mod.has_capability(Capability.CapabilityLMO) is True

    def test_unknown_capability(self):
        """Query a capability bit that neither side declares."""
        caps_mod.set_robot_capabilities(Capability.CapabilityLMO)
        unknown_bit = 1 << 10
        assert caps_mod.has_capability(unknown_bit) is False


class TestGetCapabilities:
    def test_includes_lmo(self):
        """init_capabilities adds LMO — it should be in the result."""
        result = caps_mod.get_capabilities()
        assert (result & Capability.CapabilityLMO) != 0
