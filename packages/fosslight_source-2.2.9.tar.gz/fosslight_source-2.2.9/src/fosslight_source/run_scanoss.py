#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Copyright (c) 2020 LG Electronics Inc.
# SPDX-License-Identifier: Apache-2.0

import os
import importlib_metadata
import warnings
import logging
import json
from typing import Tuple
import fosslight_util.constant as constant
from ._parsing_scanoss_file import parsing_scan_result  # scanoss
from ._parsing_scanoss_file import parsing_extra_info  # scanoss
from scanoss.scanner import Scanner, ScanType
from scanoss.scanoss_settings import ScanossSettings
import io
import contextlib

logger = logging.getLogger(constant.LOGGER_NAME)
warnings.filterwarnings("ignore", category=FutureWarning)
_PKG_NAME = "fosslight_source"
SCANOSS_RESULT_FILE = "scanner_output.wfp"
SCANOSS_OUTPUT_FILE = "scanoss_raw_result.json"


def get_scanoss_extra_info(scanned_result: dict) -> list:
    return parsing_extra_info(scanned_result)


def run_scanoss_py(path_to_scan: str, output_path: str = "", format: list = [],
                   called_by_cli: bool = False, num_threads: int = -1,
                   path_to_exclude: list = [], excluded_files: set = None,
                   write_json_file: bool = False) -> Tuple[list, bool]:
    """
    Run scanoss.py for the given path.

    :param path_to_scan: path of sourcecode to scan.
    :param output_file_name: file name for the output.
    :param format: Output file format (not being used except when calling check_output_format).
    :param called_by_cli: if not called by cli, initialize logger.
    :param write_json_file: if requested, keep the raw files.
    :return scanoss_file_list: list of ScanItem (scanned result by files).
    """

    scanoss_file_list = []
    api_limit_exceed = False
    try:
        importlib_metadata.distribution("scanoss")
    except Exception as error:
        logger.warning(f"{error}. Skipping scan with scanoss.")
        logger.warning("Please install scanoss and dataclasses before run fosslight_source with scanoss option.")
        return scanoss_file_list, api_limit_exceed

    output_json_file = os.path.join(output_path, SCANOSS_OUTPUT_FILE)
    output_wfp_file = os.path.join(output_path, SCANOSS_RESULT_FILE)
    if os.path.exists(output_json_file):
        os.remove(output_json_file)

    try:
        scanoss_settings = ScanossSettings()
        scanner = Scanner(
            ignore_cert_errors=True,
            skip_folders=list(path_to_exclude) if path_to_exclude else [],
            scan_output=output_json_file,
            scan_options=ScanType.SCAN_SNIPPETS.value,
            nb_threads=num_threads if num_threads > 0 else 10,
            scanoss_settings=scanoss_settings
        )

        output_buffer = io.StringIO()
        with contextlib.redirect_stdout(output_buffer), contextlib.redirect_stderr(output_buffer):
            scanner.scan_folder_with_options(scan_dir=path_to_scan)
        captured_output = output_buffer.getvalue()
        api_limit_exceed = "due to service limits being exceeded" in captured_output

        if os.path.isfile(output_json_file):
            with open(output_json_file, "r") as st_json:
                st_python = json.load(st_json)
                for key_to_exclude in excluded_files:
                    if key_to_exclude in st_python:
                        del st_python[key_to_exclude]
            with open(output_json_file, 'w') as st_json:
                json.dump(st_python, st_json, indent=4)
            with open(output_json_file, "r") as st_json:
                st_python = json.load(st_json)
                scanoss_file_list = parsing_scan_result(st_python, excluded_files)
    except Exception as error:
        logger.debug(f"SCANOSS Parsing {path_to_scan}: {error}")

    if not write_json_file:
        if os.path.isfile(output_json_file):
            os.remove(output_json_file)
        if os.path.isfile(output_wfp_file):
            os.remove(output_wfp_file)

    logger.info(f"|---Number of files detected with SCANOSS: {(len(scanoss_file_list))}")

    return scanoss_file_list, api_limit_exceed
