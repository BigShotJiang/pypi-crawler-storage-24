"""MCGhidra package entry point.

Allows running with: python -m mcghidra
"""

from .server import main

if __name__ == "__main__":
    main()
