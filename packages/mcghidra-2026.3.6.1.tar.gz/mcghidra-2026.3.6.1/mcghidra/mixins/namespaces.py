"""Namespaces mixin for MCGhidra.

Provides tools for querying namespaces and class definitions.
"""

from typing import Any, Dict, List, Optional

from fastmcp import Context
from fastmcp.contrib.mcp_mixin import mcp_resource, mcp_tool

from ..config import get_config
from .base import MCGhidraMixinBase


class NamespacesMixin(MCGhidraMixinBase):
    """Mixin for namespace and class operations.

    Provides tools for:
    - Listing all non-global namespaces
    - Listing class namespaces with qualified names
    """

    @mcp_tool()
    def namespaces_list(
        self,
        port: Optional[int] = None,
        page_size: int = 50,
        grep: Optional[str] = None,
        grep_ignorecase: bool = True,
        return_all: bool = False,
        fields: Optional[List[str]] = None,
        ctx: Optional[Context] = None,
    ) -> Dict[str, Any]:
        """List all non-global namespaces with pagination.

        Args:
            port: Ghidra instance port (optional)
            page_size: Namespaces per page (default: 50, max: 500)
            grep: Regex pattern to filter namespace names
            grep_ignorecase: Case-insensitive grep (default: True)
            return_all: Return all namespaces without pagination
            fields: Field names to keep (e.g. ['name', 'id']). Reduces response size.
            ctx: FastMCP context (auto-injected)

        Returns:
            Paginated list of namespaces
        """
        try:
            port = self.get_instance_port(port)
        except ValueError as e:
            return {"success": False, "error": {"code": "NO_INSTANCE", "message": str(e)}}

        config = get_config()
        cap = config.resource_caps.get("namespaces", 500)
        response = self.safe_get(port, "namespaces", {"limit": cap})
        simplified = self.simplify_response(response)

        if not simplified.get("success", True):
            return simplified

        namespaces = simplified.get("result", [])
        if not isinstance(namespaces, list):
            namespaces = []

        query_params = {"tool": "namespaces_list", "port": port, "grep": grep}
        session_id = self._get_session_id(ctx)

        return self.filtered_paginate(
            data=namespaces,
            query_params=query_params,
            tool_name="namespaces_list",
            session_id=session_id,
            page_size=min(page_size, config.max_page_size),
            grep=grep,
            grep_ignorecase=grep_ignorecase,
            return_all=return_all,
            fields=fields,
        )

    @mcp_tool()
    def classes_list(
        self,
        port: Optional[int] = None,
        page_size: int = 50,
        grep: Optional[str] = None,
        grep_ignorecase: bool = True,
        return_all: bool = False,
        fields: Optional[List[str]] = None,
        ctx: Optional[Context] = None,
    ) -> Dict[str, Any]:
        """List class namespaces with qualified names.

        Args:
            port: Ghidra instance port (optional)
            page_size: Classes per page (default: 50, max: 500)
            grep: Regex pattern to filter class names
            grep_ignorecase: Case-insensitive grep (default: True)
            return_all: Return all classes without pagination
            fields: Field names to keep (e.g. ['name', 'qualified_name']). Reduces response size.
            ctx: FastMCP context (auto-injected)

        Returns:
            Paginated list of class namespaces
        """
        try:
            port = self.get_instance_port(port)
        except ValueError as e:
            return {"success": False, "error": {"code": "NO_INSTANCE", "message": str(e)}}

        config = get_config()
        cap = config.resource_caps.get("classes", 500)
        response = self.safe_get(port, "classes", {"limit": cap})
        simplified = self.simplify_response(response)

        if not simplified.get("success", True):
            return simplified

        classes = simplified.get("result", [])
        if not isinstance(classes, list):
            classes = []

        query_params = {"tool": "classes_list", "port": port, "grep": grep}
        session_id = self._get_session_id(ctx)

        return self.filtered_paginate(
            data=classes,
            query_params=query_params,
            tool_name="classes_list",
            session_id=session_id,
            page_size=min(page_size, config.max_page_size),
            grep=grep,
            grep_ignorecase=grep_ignorecase,
            return_all=return_all,
            fields=fields,
        )

    # Resources

    @mcp_resource(uri="ghidra://instance/{port}/namespaces")
    def resource_namespaces_list(self, port: Optional[int] = None) -> Dict[str, Any]:
        """MCP Resource: List namespaces (capped).

        Args:
            port: Ghidra instance port

        Returns:
            List of namespaces (capped)
        """
        try:
            port = self.get_instance_port(port)
        except ValueError as e:
            return {"error": str(e)}

        config = get_config()
        cap = config.resource_caps.get("namespaces", 500)

        response = self.safe_get(port, "namespaces", {"limit": cap})
        simplified = self.simplify_response(response)

        if not simplified.get("success", True):
            return simplified

        namespaces = simplified.get("result", [])
        if not isinstance(namespaces, list):
            namespaces = []

        return {
            "namespaces": namespaces[:cap],
            "count": len(namespaces),
            "capped_at": cap if len(namespaces) >= cap else None,
            "_hint": "Use namespaces_list() tool for full pagination"
            if len(namespaces) >= cap
            else None,
        }

    @mcp_resource(uri="ghidra://instance/{port}/classes")
    def resource_classes_list(self, port: Optional[int] = None) -> Dict[str, Any]:
        """MCP Resource: List classes (capped).

        Args:
            port: Ghidra instance port

        Returns:
            List of class namespaces (capped)
        """
        try:
            port = self.get_instance_port(port)
        except ValueError as e:
            return {"error": str(e)}

        config = get_config()
        cap = config.resource_caps.get("classes", 500)

        response = self.safe_get(port, "classes", {"limit": cap})
        simplified = self.simplify_response(response)

        if not simplified.get("success", True):
            return simplified

        classes = simplified.get("result", [])
        if not isinstance(classes, list):
            classes = []

        return {
            "classes": classes[:cap],
            "count": len(classes),
            "capped_at": cap if len(classes) >= cap else None,
            "_hint": "Use classes_list() tool for full pagination"
            if len(classes) >= cap
            else None,
        }
