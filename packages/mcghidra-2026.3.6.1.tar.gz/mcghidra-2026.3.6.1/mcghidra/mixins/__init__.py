"""MCP Mixins for MCGhidra.

Domain-specific mixins that organize tools, resources, and prompts by functionality.
Uses FastMCP's contrib.mcp_mixin pattern for clean modular organization.
"""

from .analysis import AnalysisMixin
from .base import MCGhidraMixinBase
from .bookmarks import BookmarksMixin
from .cursors import CursorsMixin
from .data import DataMixin
from .datatypes import DataTypesMixin
from .docker import DockerMixin
from .functions import FunctionsMixin
from .instances import InstancesMixin
from .memory import MemoryMixin
from .namespaces import NamespacesMixin
from .segments import SegmentsMixin
from .structs import StructsMixin
from .symbols import SymbolsMixin
from .variables import VariablesMixin
from .xrefs import XrefsMixin

__all__ = [
    "MCGhidraMixinBase",
    "InstancesMixin",
    "FunctionsMixin",
    "DataMixin",
    "StructsMixin",
    "AnalysisMixin",
    "MemoryMixin",
    "XrefsMixin",
    "CursorsMixin",
    "DockerMixin",
    "SymbolsMixin",
    "SegmentsMixin",
    "VariablesMixin",
    "NamespacesMixin",
    "BookmarksMixin",
    "DataTypesMixin",
]
