"""MCGhidra - Reverse engineering bridge for Ghidra.

Multi-instance Ghidra plugin with HATEOAS REST API and MCP server
for decompilation, analysis & binary manipulation.
"""

try:
    from importlib.metadata import version
    __version__ = version("mcghidra")
except Exception:
    __version__ = "2025.12.1"

from .server import create_server, main

__all__ = ["create_server", "main", "__version__"]
