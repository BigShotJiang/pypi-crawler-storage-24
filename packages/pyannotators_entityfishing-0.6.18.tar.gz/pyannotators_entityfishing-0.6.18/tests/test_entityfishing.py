import pytest
from pymultirole_plugins.v1.schema import Annotation, Document, Sentence

from pyannotators_entityfishing.ef_client import EntityFishingClient
from pyannotators_entityfishing.entityfishing import (
    EntityFishingAnnotator,
    EntityFishingParameters,
    _build_annotation,
    _document_language,
    _enrich_concepts_with_properties,
    _filter_annotations,
    _map_concepts_to_labels,
)


def test_model():
    model = EntityFishingAnnotator.get_model()
    model_class = model.model_construct().__class__
    assert model_class == EntityFishingParameters


def test_entityfishing_default_label():
    annotator = EntityFishingAnnotator()
    parameters = EntityFishingParameters(
        default_label="ENTITY",
    )
    docs: list[Document] = annotator.annotate(
        [
            Document(
                text="Albert Einstein was a German-born theoretical physicist who is widely held to be one of the greatest and most influential scientists of all time.",
                metadata={"language": "en"},
            )
        ],
        parameters,
    )
    doc0 = docs[0]
    assert doc0.annotations is not None
    assert len(doc0.annotations) > 0
    for ann in doc0.annotations:
        assert ann.labelName == "ENTITY"
        assert ann.score is not None
        assert ann.terms is not None
        assert len(ann.terms) > 0
        assert ann.terms[0].lexicon == "wikidata"
        assert ann.terms[0].identifier.startswith("Q")


def test_entityfishing_mapped_labels():
    annotator = EntityFishingAnnotator()
    parameters = EntityFishingParameters(
        mapped_labels={
            "PER": '{"statements": {"$elemMatch": {"propertyName": "instance of", "valueName": "human"}}}',
            "LOC": '{"statements": {"$elemMatch": {"propertyName": "GeoNames ID"}}}',
        },
        default_label="MISC",
    )
    docs: list[Document] = annotator.annotate(
        [
            Document(
                text="Albert Einstein was born in Ulm, Germany, and later moved to Princeton, New Jersey.",
                metadata={"language": "en"},
            )
        ],
        parameters,
    )
    doc0 = docs[0]
    assert doc0.annotations is not None
    assert len(doc0.annotations) > 0
    labels = {ann.labelName for ann in doc0.annotations}
    # We expect at least one of the mapped labels or MISC
    assert labels.intersection({"PER", "LOC", "MISC"})


def test_entityfishing_french():
    annotator = EntityFishingAnnotator()
    parameters = EntityFishingParameters(
        default_label="ENTITY",
    )
    docs: list[Document] = annotator.annotate(
        [
            Document(
                text="Victor Hugo est un poete, dramaturge, ecrivain, romancier et dessinateur romantique francais, ne le 26 fevrier 1802 a Besancon.",
                metadata={"language": "fr"},
            )
        ],
        parameters,
    )
    doc0 = docs[0]
    assert doc0.annotations is not None
    assert len(doc0.annotations) > 0


def test_entityfishing_no_labels():
    """When no default_label or mapped_labels, documents should be returned untouched."""
    annotator = EntityFishingAnnotator()
    parameters = EntityFishingParameters()
    docs: list[Document] = annotator.annotate(
        [
            Document(
                text="Albert Einstein was a genius.",
                metadata={"language": "en"},
            )
        ],
        parameters,
    )
    doc0 = docs[0]
    assert doc0.annotations is None


def test_entityfishing_with_sentences():
    annotator = EntityFishingAnnotator()

    parameters = EntityFishingParameters(
        default_label="ENTITY",
    )
    text = "Albert Einstein was born in Ulm. He later moved to Princeton."
    docs: list[Document] = annotator.annotate(
        [
            Document(
                text=text,
                metadata={"language": "en"},
                sentences=[Sentence(start=0, end=31), Sentence(start=32, end=60)],
            )
        ],
        parameters,
    )
    doc0 = docs[0]
    assert doc0.annotations is not None
    assert len(doc0.annotations) > 0


# ---- Unit tests for helper functions (no network) ----


def test_document_language():
    doc_with_lang = Document(text="hello", metadata={"language": "fr"})
    assert _document_language(doc_with_lang) == "fr"

    doc_no_meta = Document(text="hello")
    assert _document_language(doc_no_meta) is None
    assert _document_language(doc_no_meta, default="en") == "en"

    doc_empty_meta = Document(text="hello", metadata={})
    assert _document_language(doc_empty_meta) is None


def test_filter_annotations_no_overlap():
    anns = [
        Annotation(start=0, end=5, labelName="A"),
        Annotation(start=10, end=15, labelName="B"),
    ]
    result = _filter_annotations(anns, longest_match=True)
    assert len(result) == 2


def test_filter_annotations_longest_match_false():
    anns = [
        Annotation(start=0, end=10, labelName="A"),
        Annotation(start=5, end=15, labelName="B"),
    ]
    result = _filter_annotations(anns, longest_match=False)
    assert len(result) == 2  # no filtering


def test_filter_annotations_overlap_keeps_longest():
    anns = [
        Annotation(start=0, end=5, labelName="short"),
        Annotation(start=0, end=10, labelName="long"),
    ]
    result = _filter_annotations(anns, longest_match=True)
    assert len(result) == 1
    assert result[0].labelName == "long"


def test_enrich_concepts_with_properties():
    concepts = {
        "Q42": {
            "wikidataId": "Q42",
            "statements": [
                {"propertyId": "P31", "value": "Q5"},
                {"propertyId": "P21", "value": "Q6581097"},
                {"propertyId": "P999", "value": "irrelevant"},
            ],
        },
        "Q99": None,  # should be skipped
    }
    _enrich_concepts_with_properties(concepts, ["P31", "P21"])
    assert "wikidata_properties" in concepts["Q42"]
    assert concepts["Q42"]["wikidata_properties"]["P31"] == ["Q5"]
    assert concepts["Q42"]["wikidata_properties"]["P21"] == ["Q6581097"]


def test_enrich_concepts_no_matching_props():
    concepts = {
        "Q42": {
            "wikidataId": "Q42",
            "statements": [
                {"propertyId": "P999", "value": "irrelevant"},
            ],
        },
    }
    _enrich_concepts_with_properties(concepts, ["P31"])
    # No matching properties, so no wikidata_properties key should be added
    assert "wikidata_properties" not in concepts["Q42"]


def test_map_concepts_to_labels():
    concepts = {
        "Q42": {
            "wikidataId": "Q42",
            "statements": [{"propertyName": "instance of", "valueName": "human"}],
        },
        "Q183": {
            "wikidataId": "Q183",
            "statements": [{"propertyName": "instance of", "valueName": "country"}],
        },
    }
    mapping = {
        "PER": {"statements": {"$elemMatch": {"propertyName": "instance of", "valueName": "human"}}},
    }
    result = _map_concepts_to_labels(concepts, mapping)
    assert result == {"Q42": "PER"}


def test_build_annotation_basic():
    entity = {
        "wikidataId": "Q42",
        "offsetStart": 0,
        "offsetEnd": 14,
        "rawName": "Douglas Adams",
        "confidence_score": 0.95,
        "wikipediaExternalRef": 42,
    }
    ann = _build_annotation(entity, "PER", None, "en", [], [], False)
    assert ann.start == 0
    assert ann.end == 14
    assert ann.labelName == "PER"
    assert ann.score == 0.95
    assert ann.terms[0].identifier == "Q42"
    assert ann.terms[0].properties["wikipediaExternalRef"] == "42"


def test_build_annotation_with_concept_and_fingerprint():
    entity = {
        "wikidataId": "Q42",
        "offsetStart": 0,
        "offsetEnd": 14,
        "rawName": "Douglas Adams",
        "confidence_score": 0.9,
    }
    concept = {
        "preferredTerm": "Douglas Noel Adams",
        "multilingual": [{"lang": "en", "term": "Douglas Adams"}, {"lang": "fr", "term": "Douglas Adams"}],
        "wikidata_properties": {
            "P31": ["Q5"],
            "P21": ["Q6581097", "Q6581072"],
        },
    }
    ann = _build_annotation(entity, "PER", concept, "en", ["P31", "P21"], ["P31"], False)
    term = ann.terms[0]
    assert "fingerprint" in term.properties
    assert "P31:Q5" in term.properties["fingerprint"]
    assert term.properties["P31"] == "Q5"
    assert term.preferredForm == "Douglas Adams"


def test_build_annotation_multivalued_fingerprint():
    entity = {
        "wikidataId": "Q42",
        "offsetStart": 0,
        "offsetEnd": 5,
        "rawName": "test",
    }
    concept = {
        "wikidata_properties": {
            "P31": ["Q5", "Q15632617"],
        },
    }
    ann = _build_annotation(entity, "PER", concept, "en", ["P31"], [], True)
    fp = ann.terms[0].properties["fingerprint"]
    assert "P31:Q15632617" in fp
    assert "P31:Q5" in fp


def test_build_annotation_wikidata_multivalued_property():
    entity = {
        "wikidataId": "Q42",
        "offsetStart": 0,
        "offsetEnd": 5,
        "rawName": "test",
    }
    concept = {
        "wikidata_properties": {
            "P31": ["Q5", "Q15632617"],
        },
    }
    ann = _build_annotation(entity, "PER", concept, "en", [], ["P31"], False)
    # Multiple values -> stored as list
    assert ann.terms[0].properties["P31"] == ["Q5", "Q15632617"]


def test_group_sentences():
    text = "A" * 500 + "B" * 500 + "C" * 500
    sentences = [
        {"offsetStart": 0, "offsetEnd": 500},
        {"offsetStart": 500, "offsetEnd": 1000},
        {"offsetStart": 1000, "offsetEnd": 1500},
    ]
    chunks = list(EntityFishingClient.group_sentences(text, sentences, chunk_size=600))
    assert len(chunks) >= 1
    for cstart, cend, sstart, send in chunks:
        assert cend > cstart
        assert send > sstart


def test_chunk_sentences_merges_small_last():
    text = "A" * 1000 + "B" * 50
    sentences = [
        {"offsetStart": 0, "offsetEnd": 1000},
        {"offsetStart": 1000, "offsetEnd": 1050},
    ]
    chunks = EntityFishingClient.chunk_sentences(text, sentences, chunk_size=1000)
    # The small last chunk (50 chars < 1000/10=100) should be merged
    assert len(chunks) == 1
    assert chunks[0][1] == 1050


def test_chunk_sentences_single_chunk():
    text = "Hello world"
    sentences = [{"offsetStart": 0, "offsetEnd": 11}]
    chunks = EntityFishingClient.chunk_sentences(text, sentences, chunk_size=1000)
    assert len(chunks) == 1
    assert chunks[0] == (0, 11, 0, 1)


# ---- Integration tests (hit the real API) ----


def test_entityfishing_multiple_documents():
    """Test batch disamb_queries path (multiple docs, no chunking)."""
    annotator = EntityFishingAnnotator()
    parameters = EntityFishingParameters(default_label="ENTITY")
    docs: list[Document] = annotator.annotate(
        [
            Document(text="Albert Einstein was a physicist.", metadata={"language": "en"}),
            Document(text="Victor Hugo est un écrivain.", metadata={"language": "fr"}),
        ],
        parameters,
    )
    assert len(docs) == 2
    for doc in docs:
        assert doc.annotations is not None
        assert len(doc.annotations) > 0


def test_entityfishing_output_labels():
    """Test output_labels filtering."""
    annotator = EntityFishingAnnotator()
    parameters = EntityFishingParameters(
        mapped_labels={
            "PER": '{"statements": {"$elemMatch": {"propertyName": "instance of", "valueName": "human"}}}',
        },
        default_label="MISC",
        output_labels=["PER"],
    )
    docs: list[Document] = annotator.annotate(
        [
            Document(
                text="Albert Einstein was born in Ulm, Germany.",
                metadata={"language": "en"},
            )
        ],
        parameters,
    )
    doc0 = docs[0]
    if doc0.annotations:
        for ann in doc0.annotations:
            assert ann.labelName == "PER"


def test_entityfishing_do_chunking():
    """Test do_chunking=True path."""
    annotator = EntityFishingAnnotator()
    parameters = EntityFishingParameters(
        default_label="ENTITY",
        do_chunking=True,
    )
    text = "Albert Einstein was a physicist. " * 20
    docs: list[Document] = annotator.annotate(
        [
            Document(
                text=text,
                metadata={"language": "en"},
                sentences=[Sentence(start=i * 32, end=(i + 1) * 32 - 1) for i in range(20)],
            )
        ],
        parameters,
    )
    doc0 = docs[0]
    assert doc0.annotations is not None


def test_entityfishing_short_text():
    """Test short_text=True mode."""
    annotator = EntityFishingAnnotator()
    parameters = EntityFishingParameters(
        default_label="ENTITY",
        short_text=True,
    )
    docs: list[Document] = annotator.annotate(
        [
            Document(text="Einstein", metadata={"language": "en"}),
        ],
        parameters,
    )
    doc0 = docs[0]
    assert doc0.annotations is not None
    assert len(doc0.annotations) > 0


def test_entityfishing_ef_full():
    """Test ef_full=True mode (concepts from entity response)."""
    annotator = EntityFishingAnnotator()
    parameters = EntityFishingParameters(
        default_label="ENTITY",
        ef_full=True,
    )
    docs: list[Document] = annotator.annotate(
        [
            Document(
                text="Albert Einstein was a theoretical physicist.",
                metadata={"language": "en"},
            )
        ],
        parameters,
    )
    doc0 = docs[0]
    assert doc0.annotations is not None
    assert len(doc0.annotations) > 0


def test_entityfishing_with_fingerprint():
    """Test fingerprint and wikidata_properties parameters."""
    annotator = EntityFishingAnnotator()
    parameters = EntityFishingParameters(
        default_label="ENTITY",
        fingerprint="P31",
        wikidata_properties="P31",
    )
    docs: list[Document] = annotator.annotate(
        [
            Document(
                text="Albert Einstein was a theoretical physicist.",
                metadata={"language": "en"},
            )
        ],
        parameters,
    )
    doc0 = docs[0]
    assert doc0.annotations is not None
    assert len(doc0.annotations) > 0
    has_fp = any(ann.terms and ann.terms[0].properties and "fingerprint" in ann.terms[0].properties for ann in doc0.annotations)
    assert has_fp, "Expected at least one annotation with a fingerprint property"


def test_entityfishing_unsupported_language():
    """Unsupported language should raise AttributeError."""
    annotator = EntityFishingAnnotator()
    parameters = EntityFishingParameters(default_label="ENTITY")
    with pytest.raises(AttributeError, match="language"):
        annotator.annotate(
            [Document(text="Some text", metadata={"language": "xx"})],
            parameters,
        )


def test_entityfishing_no_language_metadata():
    """Missing language metadata should raise AttributeError."""
    annotator = EntityFishingAnnotator()
    parameters = EntityFishingParameters(default_label="ENTITY")
    with pytest.raises(AttributeError, match="language"):
        annotator.annotate(
            [Document(text="Some text")],
            parameters,
        )
