"""Annotator based on entity-fishing"""

__version__ = "0.6.18"
