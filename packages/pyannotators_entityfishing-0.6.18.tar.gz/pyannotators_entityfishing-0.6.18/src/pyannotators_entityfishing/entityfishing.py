import json
import logging
import os
import time
from collections import defaultdict
from collections.abc import Iterable
from typing import cast

import mongoquery
from collections_extended import RangeMap
from pydantic import BaseModel, ConfigDict, Field
from pymultirole_plugins.util import comma_separated_to_list
from pymultirole_plugins.v1.annotator import AnnotatorBase, AnnotatorParameters
from pymultirole_plugins.v1.schema import Annotation, Document, Term

from pyannotators_entityfishing.ef_client import EntityFishingClient

logger = logging.getLogger("ef-annotator")

SUPPORTED_LANGUAGES = "en,fr,de,es,it,pt,ar,fa,ja,zh,ru,uk,sv,bn,hi,ko,nl,pl"


class EntityFishingParameters(AnnotatorParameters):
    model_config = ConfigDict(field_title_generator=lambda field_name, _field_info: field_name)
    ef_uri: str = Field(
        os.getenv("APP_EF_URI", "https://sherpa-entityfishing.kairntech.com"),
        title="Entity-fishing URI",
        description="Base URL of the entity-fishing service",
        json_schema_extra={"extra": "advanced"},
    )
    minSelectorScore: float = Field(
        0.3,
        description="Minimum selector threshold to retain a concept",
    )
    maxTermFrequency: float | None = Field(
        None,
        description="""Maximum term frequency above which terms are skipped.<br/>
        Expressed as Zipf (typically 0-8). Lower values speed up processing but may miss entities.""",
    )
    mapped_labels: dict[str, str] | None = Field(
        None,
        description="Mapping from label name to a JSON mongo-query expression matching Wikidata concept properties",
        json_schema_extra={"extra": "key:label,val:json"},
    )
    default_label: str | None = Field(
        None,
        description="Default label for unmapped concepts (if None, unmapped concepts are ignored)",
        json_schema_extra={"extra": "label"},
    )
    output_labels: list[str] | None = Field(
        None,
        description="Subset of labels to keep in the output",
        json_schema_extra={"extra": "label"},
    )
    noun_forms_only: bool = Field(
        False,
        description="Filter out terms that do not include at least one noun or proper name (requires spacy)",
        json_schema_extra={"extra": "advanced"},
    )
    fingerprint: str | None = Field(
        None,
        description="Comma-separated list of Wikidata properties to consider for the fingerprint",
        json_schema_extra={"extra": "advanced"},
    )
    wikidata_properties: str | None = Field(
        None,
        description="Comma-separated list of Wikidata properties to retrieve",
        json_schema_extra={"extra": "advanced"},
    )
    do_chunking: bool = Field(
        False,
        description="Split input document into chunks and process them in parallel",
        json_schema_extra={"extra": "advanced"},
    )
    short_text: bool = Field(
        False,
        description="Use short-text disambiguation mode (for search queries or titles)",
        json_schema_extra={"extra": "advanced"},
    )
    multivalued_props: bool = Field(
        False,
        description="Use all property values in fingerprint (default keeps only one)",
        json_schema_extra={"extra": "advanced"},
    )
    ef_pool_size: int = Field(
        int(os.getenv("APP_EF_CLIENT_POOLSIZE", "8")),
        description="Number of parallel HTTP connections to entity-fishing",
        json_schema_extra={"extra": "internal"},
    )
    ef_full: bool = Field(
        False,
        description="Request full concept data from entity-fishing (avoids separate KB lookups)",
        json_schema_extra={"extra": "internal"},
    )


def _get_spacy_tagger(lang: str):
    """Lazily load a spacy model for POS tagging."""
    try:
        import spacy
    except ImportError as e:
        raise ImportError("spacy is required when noun_forms_only=True. Install with: pip install spacy") from e

    model_map = {
        "en": "en_core_web_sm",
        "fr": "fr_core_news_sm",
        "de": "de_core_news_sm",
        "es": "es_core_news_sm",
        "it": "it_core_news_sm",
        "pt": "pt_core_news_sm",
        "nl": "nl_core_news_sm",
        "zh": "zh_core_web_sm",
        "ja": "ja_core_news_sm",
        "ru": "ru_core_news_sm",
        "pl": "pl_core_news_sm",
    }
    model_name = model_map.get(lang)
    if model_name is None:
        raise ValueError(f"No spacy model configured for language '{lang}'. Disable noun_forms_only or add a model mapping.")
    try:
        return spacy.load(model_name, disable=["parser", "ner", "lemmatizer"])
    except OSError as e:
        raise OSError(f"Spacy model '{model_name}' not found. Install with: python -m spacy download {model_name}") from e


def _document_language(doc: Document, default: str | None = None) -> str | None:
    if doc.metadata is not None and "language" in doc.metadata:
        return doc.metadata["language"]
    return default


def _filter_annotations(annotations: Iterable[Annotation], longest_match: bool = True) -> list[Annotation]:
    """Filter annotations and remove overlaps. Longest span wins."""
    if not longest_match:
        return list(annotations)

    sorted_annotations = sorted(annotations, key=lambda ann: (ann.end - ann.start, -ann.start), reverse=True)
    result = []
    seen_offsets = RangeMap()
    for ann in sorted_annotations:
        if seen_offsets.get(ann.start) is None and seen_offsets.get(ann.end - 1) is None:
            result.append(ann)
            seen_offsets[ann.start : ann.end] = ann
    return sorted(result, key=lambda ann: ann.start)


def _enrich_concepts_with_properties(concepts: dict, wiki_props: list[str], multivalued_props: bool = False):  # noqa: ARG001
    """Enrich concept dicts with extracted wikidata_properties."""
    for concept in concepts.values():
        if concept is not None and "statements" in concept:
            fingerprint = defaultdict(list)
            for wp in wiki_props:
                fingerprint[wp] = []
            for st in concept["statements"]:
                if st["propertyId"] in wiki_props:
                    fingerprint[st["propertyId"]].append(st["value"])
            if sum(len(v) for v in fingerprint.values()) > 0:
                concept["wikidata_properties"] = dict(fingerprint)


def _map_concepts_to_labels(concepts: dict, mapping: dict) -> dict:
    """Apply mongoquery mappings to assign labels to wikidata concepts."""
    mapped = {}
    for key, condition in mapping.items():
        query = mongoquery.Query(condition)
        for qid, concept in concepts.items():
            if concept is not None and query.match(concept):
                mapped[qid] = key
    return mapped


def _build_annotation(entity: dict, label: str, concept: dict | None, lang: str, fingerprints: list[str], wikidata_properties: list[str], multivalued_props: bool) -> Annotation:
    """Build an Annotation from an entity-fishing entity and its resolved concept."""
    qid = entity["wikidataId"]
    ann_term = Term(
        identifier=qid,
        lexicon="wikidata",
        score=entity.get("confidence_score", 1.0),
        properties={},
    )
    ann_term.properties["wikidataId"] = qid

    if concept and "wikidata_properties" in concept:
        if fingerprints:
            fp_parts = []
            for f in fingerprints:
                fvals = concept["wikidata_properties"].get(f, [])
                if fvals:
                    fingers = [f"{f}:{v}" for v in sorted(fvals) if isinstance(v, str)]
                    if multivalued_props:
                        fp_parts.extend(fingers)
                    elif fingers:
                        fp_parts.append(fingers[0])
            ann_term.properties["fingerprint"] = ",".join(fp_parts)
        if wikidata_properties:
            for wp in wikidata_properties:
                fvals = concept["wikidata_properties"].get(wp, [])
                if len(fvals) == 1:
                    ann_term.properties[wp] = fvals[0]
                elif len(fvals) > 1:
                    ann_term.properties[wp] = fvals

    # Preferred form: use multilingual term for the document language, else preferredTerm, else rawName
    if "rawName" in entity:
        ann_term.preferredForm = entity["rawName"]
    if concept:
        if "preferredTerm" in concept:
            ann_term.preferredForm = concept["preferredTerm"]
        if "multilingual" in concept:
            multi_terms = {m["lang"]: m["term"] for m in concept["multilingual"]}
            if lang in multi_terms:
                ann_term.preferredForm = multi_terms[lang]
    if "wikipediaExternalRef" in entity:
        ann_term.properties["wikipediaExternalRef"] = str(entity["wikipediaExternalRef"])

    return Annotation(
        start=entity["offsetStart"],
        end=entity["offsetEnd"],
        labelName=label,
        score=entity.get("confidence_score", 1.0),
        terms=[ann_term],
        properties=None,
    )


def _check_noun_form(spacy_doc, entity: dict) -> bool:
    """Check if the entity span contains at least one noun or proper noun."""
    from spacy.parts_of_speech import NOUN, NUM, PROPN, PUNCT

    span = spacy_doc.char_span(entity["offsetStart"], entity["offsetEnd"])
    if span is None:
        return False
    pos_set = {PUNCT if t.is_punct else NUM if t.is_digit else t.pos for t in span}
    return bool(pos_set.intersection({NOUN, PROPN}))


class EntityFishingAnnotator(AnnotatorBase):
    __doc__ = (
        """[entity-fishing](https://github.com/kermitt2/entity-fishing) annotator for named entity recognition and disambiguation against Wikidata.
    #need-segments
    #languages:"""
        + SUPPORTED_LANGUAGES
    )

    def annotate(self, documents: list[Document], parameters: AnnotatorParameters) -> list[Document]:
        params: EntityFishingParameters = cast(EntityFishingParameters, parameters)

        supported_languages = comma_separated_to_list(SUPPORTED_LANGUAGES)

        # Parse parameters
        mapping = {k: json.loads(v) for k, v in params.mapped_labels.items()} if params.mapped_labels else {}
        fingerprints = comma_separated_to_list(params.fingerprint)
        wp_list = comma_separated_to_list(params.wikidata_properties)
        wiki_props = fingerprints + wp_list
        do_chunking = params.do_chunking and not params.short_text
        noun_forms_only = params.noun_forms_only

        # Build the set of valid output classes
        classes = list(mapping.keys())
        if params.default_label:
            classes.append(params.default_label)
        if params.output_labels:
            classes = [c for c in classes if c in params.output_labels]

        if not classes:
            # Nothing to produce: return documents untouched
            return documents

        # Create client
        client = EntityFishingClient(
            base_url=params.ef_uri,
            pool_size=params.ef_pool_size,
            full=params.ef_full,
        )

        # Validate languages
        langs = []
        for doc in documents:
            lang = _document_language(doc)
            if lang is None or lang not in supported_languages:
                raise AttributeError(f"Metadata language '{lang}' is required and must be in {SUPPORTED_LANGUAGES}")
            langs.append(lang)

        # Load spacy taggers if needed
        spacy_docs = None
        if noun_forms_only:
            spacy_docs = []
            for doc, lang in zip(documents, langs, strict=True):
                tagger = _get_spacy_tagger(lang)
                spacy_docs.append(tagger(doc.text))

        # Disambiguate: parallel batch if multiple docs, else single-doc (with optional chunking)
        if len(documents) > 1 and not do_chunking:
            all_results = client.disamb_queries(documents, langs, params.minSelectorScore, params.maxTermFrequency, params.short_text)
        else:
            all_results = []
            for doc, lang in zip(documents, langs, strict=True):
                sents = tuple((s.start, s.end) for s in doc.sentences) if doc.sentences else ((0, len(doc.text)),)
                if do_chunking:
                    result = client.disamb_query_chunks(doc.text, lang, params.minSelectorScore, params.maxTermFrequency, sents, params.short_text)
                else:
                    result = client.disamb_query(doc.text, lang, params.minSelectorScore, params.maxTermFrequency, sents, params.short_text)
                all_results.append(result)

        # Process results for each document
        for doc_idx, (doc, lang, result) in enumerate(zip(documents, langs, all_results, strict=True)):
            start = time.time()
            entities = [e for e in result if "wikidataId" in e]

            # Resolve concepts
            if params.ef_full:
                concepts = {e["wikidataId"]: e for e in entities}
            else:
                qids = {e["wikidataId"] for e in entities}
                concepts = client.get_kb_concepts(qids) if qids else {}

            # Enrich with wikidata properties
            if wiki_props:
                _enrich_concepts_with_properties(concepts, wiki_props, params.multivalued_props)

            # Map concepts to labels
            mapped_concepts = _map_concepts_to_labels(concepts, mapping)

            # Build annotations
            spacy_doc = spacy_docs[doc_idx] if spacy_docs else None
            anns = []
            for entity in entities:
                qid = entity["wikidataId"]
                label = mapped_concepts.get(qid, params.default_label)
                if not label or label not in classes:
                    continue
                concept = concepts.get(qid)

                # Noun form filtering
                if spacy_doc and noun_forms_only and not _check_noun_form(spacy_doc, entity):
                    continue

                ann = _build_annotation(entity, label, concept, lang, fingerprints, wp_list, params.multivalued_props)
                anns.append(ann)

            doc.annotations = _filter_annotations(anns)
            duration = time.time() - start
            logger.debug("EF annotator doc %d chars done in %0.3fs", len(doc.text), duration)

        return documents

    @classmethod
    def get_model(cls) -> type[BaseModel]:
        return EntityFishingParameters
