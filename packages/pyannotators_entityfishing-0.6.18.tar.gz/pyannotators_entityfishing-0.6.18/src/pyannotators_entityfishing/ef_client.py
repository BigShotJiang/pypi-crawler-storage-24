import hashlib
import logging
import time
from collections.abc import Iterable
from concurrent.futures import as_completed
from datetime import timedelta

import requests
from collections_extended import RangeMap
from pymultirole_plugins.v1.schema import Document
from requests.adapters import DEFAULT_POOLSIZE, HTTPAdapter
from requests_cache import CachedSession
from requests_futures.sessions import FuturesSession

logger = logging.getLogger("ef-client")

DEFAULT_CHUNK_SIZE = 1000


class EntityFishingClient:
    def __init__(
        self,
        base_url: str = "https://sherpa-entityfishing.kairntech.com",
        chunk_size: int = DEFAULT_CHUNK_SIZE,
        cache_disamb: int = -1,
        cache_concept: int = -1,
        pool_size: int = 8,
        full: bool = False,
    ):
        self.base_url = base_url.rstrip("/")
        self.chunk_size = chunk_size
        self.full = full

        self.dsession = (
            CachedSession(
                "file:disamb_cache?mode=memory&cache=shared",
                backend="sqlite",
                uri=True,
                wal=True,
                cache_control=True,
                expire_after=timedelta(seconds=cache_disamb),
                allowable_methods=["POST"],
            )
            if cache_disamb > 0
            else requests.Session()
        )
        self.dsession.mount("http://", HTTPAdapter(pool_maxsize=max(DEFAULT_POOLSIZE, pool_size)))
        self.dsession.mount("https://", HTTPAdapter(pool_maxsize=max(DEFAULT_POOLSIZE, pool_size)))
        self.dsession.headers.update({"Content-Type": "application/json", "Accept": "application/json"})
        self.dsession.verify = False
        self.fdsession = FuturesSession(session=self.dsession, max_workers=pool_size)

        self.ksession = (
            CachedSession(
                "file:concept_cache?mode=memory&cache=shared",
                backend="sqlite",
                uri=True,
                wal=True,
                cache_control=True,
                expire_after=timedelta(seconds=cache_concept),
                allowable_methods=["GET"],
            )
            if cache_concept > 0
            else requests.Session()
        )
        self.ksession.mount("http://", HTTPAdapter(pool_maxsize=max(DEFAULT_POOLSIZE, pool_size)))
        self.ksession.mount("https://", HTTPAdapter(pool_maxsize=max(DEFAULT_POOLSIZE, pool_size)))
        self.ksession.headers.update({"Content-Type": "application/json", "Accept": "application/json"})
        self.ksession.verify = False
        self.fksession = FuturesSession(session=self.ksession, max_workers=pool_size)

        self.disamb_url = "/service/disambiguate/"
        self.kb_url = "/service/kb/concept/"
        self.term_url = "/service/kb/term/"

    def _build_disamb_query(self, text: str, sentences: list[dict], lang: str, minSelectorScore: float, maxTermFrequency: float | None, short_text: bool = False) -> dict:
        text = text.replace("\r\n", " \n")
        disamb_query = {
            "sentences": sentences,
            "language": {"lang": lang},
            "mentions": ["wikipedia"],
            "nbest": short_text,
            "sentence": False,
            "full": self.full,
            "customisation": "generic",
            "minSelectorScore": minSelectorScore,
        }
        if short_text:
            disamb_query["shortText"] = text
        else:
            disamb_query["text"] = text
        if maxTermFrequency is not None and isinstance(maxTermFrequency, float):
            disamb_query["maxTermFrequency"] = maxTermFrequency
        return disamb_query

    def disamb_query(self, text: str, lang: str, minSelectorScore: float, maxTermFrequency: float | None, sents: tuple, short_text: bool = False) -> list:
        sentences = [{"offsetStart": s[0], "offsetEnd": s[1]} for s in sents]
        disamb_query = self._build_disamb_query(text, sentences, lang, minSelectorScore, maxTermFrequency, short_text)
        try:
            start = time.time()
            resp = self.dsession.post(self.base_url + self.disamb_url, json=disamb_query, timeout=(30, 300))
            duration = time.time() - start
            logger.debug("EF disamb duration %0.3fs", duration)
            if resp.ok:
                result = resp.json()
                return result.get("entities", [])
            else:
                resp.raise_for_status()
        except Exception:
            logging.warning("An exception was thrown!", exc_info=True)
        return []

    def disamb_queries(self, inputs: list[Document], langs: list[str], minSelectorScore: float, maxTermFrequency: float | None, short_text: bool = False) -> list[list]:
        futures = []
        results: list[list] = [[] for _ in range(len(inputs))]
        start = time.time()

        for idx, (doc, lang) in enumerate(zip(inputs, langs, strict=True)):
            sents = [(s.start, s.end) for s in doc.sentences] if doc.sentences else [(0, len(doc.text))]
            sentences = [{"offsetStart": s[0], "offsetEnd": s[1]} for s in sents]
            disamb_query = self._build_disamb_query(doc.text, sentences, lang, minSelectorScore, maxTermFrequency, short_text)
            future = self.fdsession.post(self.base_url + self.disamb_url, json=disamb_query, timeout=(30, 300))
            future.idx = idx
            futures.append(future)

        for future in as_completed(futures):
            try:
                resp = future.result()
                if resp.ok:
                    result = resp.json()
                    results[future.idx] = result.get("entities", [])
                else:
                    resp.raise_for_status()
            except Exception:
                logging.warning("An exception was thrown!", exc_info=True)
        duration = time.time() - start
        logger.debug("EF disamb duration with %d docs %0.3fs", len(inputs), duration)
        return results

    @staticmethod
    def group_sentences(text: str, sentences: list[dict], chunk_size: int = DEFAULT_CHUNK_SIZE):
        chunks = RangeMap()
        for sent in sentences:
            if sent["offsetStart"] < sent["offsetEnd"]:
                chunks[sent["offsetStart"] : sent["offsetEnd"]] = sent
        cstart = 0
        cend = 0
        sstart = 0
        while cend < len(text):
            ranges = chunks.get_range(cstart, cstart + chunk_size)
            if ranges.start is None or ranges.end is None:
                break
            send = sstart + len(ranges)
            first_sent = ranges[ranges.start]
            last_sent = ranges[ranges.end - 1]
            if first_sent is not None and "offsetStart" in first_sent:
                cstart = first_sent["offsetStart"]
                if last_sent is not None and "offsetEnd" in last_sent:
                    cend = last_sent["offsetEnd"]
                    yield (cstart, cend, sstart, send)
                    cstart = cend
                    sstart = send

    @staticmethod
    def chunk_sentences(text: str, sentences: list[dict], chunk_size: int = DEFAULT_CHUNK_SIZE) -> list[tuple]:
        chunks = list(EntityFishingClient.group_sentences(text, sentences, chunk_size))
        # If last chunk is too small aggregate it to the previous
        if len(chunks) > 1 and (chunks[-1][1] - chunks[-1][0]) < chunk_size / 10:
            last_chunk = chunks.pop()
            chunks[-1] = (chunks[-1][0], last_chunk[1], chunks[-1][2], last_chunk[3])
        return chunks

    def disamb_query_chunks(self, text: str, lang: str, minSelectorScore: float, maxTermFrequency: float | None, sents: tuple, short_text: bool = False) -> list:
        sentences = [{"offsetStart": s[0], "offsetEnd": s[1]} for s in sents]
        if self.chunk_size < 0:
            return self.disamb_query(text, lang, minSelectorScore, maxTermFrequency, sents, short_text)

        start = time.time()
        text = text.replace("\r\n", " \n")
        entities = []
        chunks = self.chunk_sentences(text, sentences, self.chunk_size)
        futures = []
        cstarts = {}
        for cstart, cend, sstart, send in chunks:
            ctext = text[cstart:cend]
            cid = int(hashlib.md5(ctext.encode("utf-8")).hexdigest(), 16)
            csentences = [{"offsetStart": s["offsetStart"] - cstart, "offsetEnd": s["offsetEnd"] - cstart} for s in sentences[sstart:send]]
            disamb_query = self._build_disamb_query(ctext, csentences, lang, minSelectorScore, maxTermFrequency, short_text)
            cstarts[cid] = cstart
            futures.append(self.fdsession.post(self.base_url + self.disamb_url, json=disamb_query, timeout=(30, 300)))

        for future in as_completed(futures):
            try:
                resp = future.result()
                if resp.ok:
                    result = resp.json()
                    rtext = result["shortText"] if short_text else result["text"]
                    cid = int(hashlib.md5(rtext.encode("utf-8")).hexdigest(), 16)
                    cstart = cstarts[cid]
                    ents = result.get("entities", [])
                    for ent in ents:
                        ent["offsetStart"] += cstart
                        ent["offsetEnd"] += cstart
                    entities.extend(ents)
                else:
                    resp.raise_for_status()
            except Exception:
                logging.warning("An exception was thrown!", exc_info=True)
        duration = time.time() - start
        logger.debug("EF disamb duration with %d chunks %0.3fs", len(chunks), duration)
        return entities

    def get_kb_concept(self, qid: str) -> dict:
        try:
            resp = self.ksession.get(self.base_url + self.kb_url + qid)
            if resp.ok:
                return resp.json()
            else:
                resp.raise_for_status()
        except Exception:
            logging.warning("An exception was thrown!", exc_info=True)
        return {}

    def get_kb_concepts(self, qids: Iterable[str]) -> dict:
        qids = list(qids)
        start = time.time()
        futures = [self.fksession.get(self.base_url + self.kb_url + qid) for qid in qids]
        concepts = dict.fromkeys(qids)
        for future in as_completed(futures):
            try:
                resp = future.result()
                if resp.ok:
                    concept = resp.json()
                    if "wikidataId" in concept:
                        concepts[concept["wikidataId"]] = concept
                else:
                    resp.raise_for_status()
            except Exception:
                logging.warning("An exception was thrown!", exc_info=True)
        duration = time.time() - start
        logger.debug("EF get kb %d concepts duration %0.3fs", len(qids), duration)
        return concepts
