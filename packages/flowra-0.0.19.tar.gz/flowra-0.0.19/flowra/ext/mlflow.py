"""MLflow tracing integration for flowra via span-hooks.

Uses ``mlflow.start_span_no_context()`` for manual span creation combined with
the flowing execution context for parent-child tracking. MLflow's context APIs
(``set_span_in_context``/``detach_span_from_context``) are used in LLM/tool
handlers for W3C ``traceparent`` propagation.

Usage::

    from flowra.ext.mlflow import install_mlflow_tracing
    from flowra.agent import HookSubscription

    hooks = HookSubscription()
    install_mlflow_tracing(hooks, experiment_name="my-experiment")

    # With session tracking (multi-turn chat):
    install_mlflow_tracing(hooks, session_id="chat-session-123")
"""

import json
from collections.abc import Callable
from typing import Any

import mlflow
from mlflow.entities.span import LiveSpan
from mlflow.tracing.provider import detach_span_from_context, set_span_in_context

from ..agent import AgentSpan, FlowingContextVar, HookSubscription, StepSpan
from ..llm import (
    AssistantMessage,
    ImageBlock,
    LLMCallSpan,
    LLMRequest,
    Message,
    SystemMessage,
    TextBlock,
    ThinkingBlock,
    ToolCallSpan,
    ToolResultBlock,
    ToolUseBlock,
    UserMessage,
)

__all__ = ["install_mlflow_tracing"]


# -- Flowing context vars for MLflow span tracking --
# Engine fork/restore ensures sibling isolation; asyncio tasks inherit via ContextVar copy.

_mlflow_parent: FlowingContextVar[LiveSpan | None] = FlowingContextVar("mlflow.parent_span", default=None)


def install_mlflow_tracing(
    hooks: HookSubscription,
    *,
    experiment_name: str = "flowra",
    session_id: str | Callable[[], str | None] | None = None,
    trace_agents: bool = True,
    trace_steps: bool = False,
    trace_llm_calls: bool = True,
    trace_tool_calls: bool = True,
) -> None:
    """Install MLflow tracing span-hooks.

    Args:
        hooks: HookSubscription to register span handlers on.
        experiment_name: MLflow experiment name (created if missing).
        session_id: Session ID for grouping traces (multi-turn chat).
            String for a fixed ID, callable for dynamic (e.g. ``lambda: runtime.current_session_id``).
        trace_agents: Trace agent lifecycle (AgentSpan).
        trace_steps: Trace individual step invocations (StepSpan). Disabled by default — usually too verbose.
        trace_llm_calls: Trace LLM calls (LLMCallSpan).
        trace_tool_calls: Trace tool calls (ToolCallSpan).
    """
    client = mlflow.MlflowClient()
    experiment = client.get_experiment_by_name(experiment_name)
    experiment_id = client.create_experiment(experiment_name) if experiment is None else experiment.experiment_id

    if trace_agents:
        hooks.on_span(AgentSpan, _make_agent_handler(experiment_id, session_id))
    if trace_steps:
        hooks.on_span(StepSpan, _make_step_handler(experiment_id, session_id))
    if trace_llm_calls:
        hooks.on_span(LLMCallSpan, _make_llm_handler())
    if trace_tool_calls:
        hooks.on_span(ToolCallSpan, _make_tool_handler())


# -- Span handlers --


def _resolve_session_id(session_id: str | Callable[[], str | None] | None) -> str | None:
    if session_id is None:
        return None
    if callable(session_id):
        return session_id()
    return session_id


def _preview(obj: Any) -> str:
    """Use __preview__() if available, otherwise str()."""
    fn = getattr(obj, "__preview__", None)
    return fn() if fn is not None else str(obj)


def _root_metadata(session_id: str | Callable[[], str | None] | None) -> dict[str, str] | None:
    sid = _resolve_session_id(session_id)
    if sid is None:
        return None
    return {"mlflow.trace.session": sid}


def _make_agent_handler(
    experiment_id: str,
    session_id: str | Callable[[], str | None] | None,
) -> Callable[[AgentSpan], Callable[..., None] | None]:
    def on_enter(span: AgentSpan) -> Callable[..., None]:
        parent = _mlflow_parent.get()
        is_root = parent is None

        inputs: dict[str, Any] = {}
        if span.spec is not None:
            inputs["spec"] = _preview(span.spec)
        if span.is_resume:
            inputs["is_resume"] = True

        mlflow_span = mlflow.start_span_no_context(
            name=span.agent_info.path,
            span_type="AGENT",
            parent_span=parent,
            inputs=inputs or None,
            experiment_id=experiment_id if is_root else None,
            metadata=_root_metadata(session_id) if is_root else None,
        )

        _mlflow_parent.set(mlflow_span)
        context_token = set_span_in_context(mlflow_span)

        if is_root and span.spec is not None:
            mlflow.update_current_trace(request_preview=_preview(span.spec))

        def on_exit(error: BaseException | None = None) -> None:
            outputs: dict[str, Any] = {}
            if span.result is not None:
                result_preview = _preview(span.result)
                outputs["result"] = result_preview
                if is_root:
                    mlflow.update_current_trace(response_preview=result_preview)
            if error is not None:
                outputs["error"] = str(error)
            if outputs:
                mlflow_span.set_outputs(outputs)
            detach_span_from_context(context_token)
            mlflow_span.end()

        return on_exit

    return on_enter


def _make_step_handler(
    experiment_id: str,
    session_id: str | Callable[[], str | None] | None,
) -> Callable[[StepSpan], Callable[..., None] | None]:
    def on_enter(span: StepSpan) -> Callable[..., None]:
        parent = _mlflow_parent.get()

        is_root = parent is None
        mlflow_span = mlflow.start_span_no_context(
            name=span.step if not is_root else f"{span.agent_info.path}:{span.step}",
            span_type="CHAIN",
            parent_span=parent,
            inputs={"step": span.step, **({"spec": _preview(span.spec)} if span.spec is not None else {})},
            experiment_id=experiment_id if is_root else None,
            metadata=_root_metadata(session_id) if is_root else None,
        )

        _mlflow_parent.set(mlflow_span)
        context_token = set_span_in_context(mlflow_span)

        def on_exit(error: BaseException | None = None) -> None:
            outputs: dict[str, Any] = {}
            if span.result is not None:
                outputs["result"] = _preview(span.result)
            if error is not None:
                outputs["error"] = str(error)
            if outputs:
                mlflow_span.set_outputs(outputs)
            detach_span_from_context(context_token)
            mlflow_span.end()

        return on_exit

    return on_enter


def _make_llm_handler() -> Callable[[LLMCallSpan], Callable[..., None] | None]:
    def on_enter(span: LLMCallSpan) -> Callable[..., None] | None:
        parent = _mlflow_parent.get()
        if parent is None:
            return None

        model_short = span.request.model.split("/")[-1]
        inputs = _format_chat_inputs(span.request)

        attributes: dict[str, str] = {
            "mlflow.message.format": "openai",
            "mlflow.llm.model": span.request.model,
        }

        mlflow_span = mlflow.start_span_no_context(
            name=f"llm_call ({model_short})",
            span_type="CHAT_MODEL",
            parent_span=parent,
            inputs=inputs,
            attributes=attributes,
        )

        if span.request.tools:
            mlflow_span.set_attribute(
                "mlflow.chat.tools",
                [
                    {
                        "type": "function",
                        "function": {
                            "name": t.name,
                            "description": t.description,
                            **({"parameters": t.input_schema} if t.input_schema else {}),
                        },
                    }
                    for t in span.request.tools
                ],
            )

        # Set in MLflow context for W3C traceparent propagation
        context_token = set_span_in_context(mlflow_span)

        def on_exit(error: BaseException | None = None) -> None:
            detach_span_from_context(context_token)
            if span.response is not None:
                mlflow_span.set_outputs(_format_chat_outputs(span))
                mlflow_span.set_attributes(_format_chat_attributes(span))
            elif error is not None:
                mlflow_span.set_outputs({"error": str(error)})
            mlflow_span.end()

        return on_exit

    return on_enter


def _make_tool_handler() -> Callable[[ToolCallSpan], Callable[..., None] | None]:
    def on_enter(span: ToolCallSpan) -> Callable[..., None] | None:
        parent = _mlflow_parent.get()
        if parent is None:
            return None

        mlflow_span = mlflow.start_span_no_context(
            name=f"tool:{span.tool_use.name}",
            span_type="TOOL",
            parent_span=parent,
            inputs={"tool_name": span.tool_use.name, "input": span.tool_use.input},
        )

        # Set in MLflow context for W3C traceparent propagation
        context_token = set_span_in_context(mlflow_span)

        def on_exit(error: BaseException | None = None) -> None:
            detach_span_from_context(context_token)
            outputs: dict[str, Any] = {}
            if span.result is not None:
                outputs["content"] = span.result.content
                outputs["is_error"] = span.result.is_error
            if error is not None:
                outputs["error"] = str(error)
            if outputs:
                mlflow_span.set_outputs(outputs)
            mlflow_span.end()

        return on_exit

    return on_enter


# -- Chat formatting (OpenAI-compatible for MLflow UI) --


def _format_chat_inputs(req: LLMRequest) -> dict[str, Any]:
    inputs: dict[str, Any] = {"model": req.model}
    if req.temperature is not None:
        inputs["temperature"] = req.temperature
    if req.max_tokens is not None:
        inputs["max_tokens"] = req.max_tokens

    messages: list[dict[str, Any]] = []
    for msg in req.system:
        messages.extend(_message_to_openai(msg))
    for msg in req.messages:
        messages.extend(_message_to_openai(msg))
    inputs["messages"] = messages
    return inputs


def _format_chat_outputs(span: LLMCallSpan) -> dict[str, Any]:
    resp = span.response
    assert resp is not None

    assistant_msg = _assistant_message_to_openai(resp.message)
    stop_reason_map = {"end_turn": "stop", "tool_use": "tool_calls", "max_tokens": "length"}
    finish_reason = stop_reason_map.get(str(resp.stop_reason), str(resp.stop_reason))

    outputs: dict[str, Any] = {
        "choices": [{"index": 0, "message": assistant_msg, "finish_reason": finish_reason}],
        "model": span.request.model,
    }
    if resp.usage:
        outputs["usage"] = {
            "prompt_tokens": resp.usage.input_tokens,
            "completion_tokens": resp.usage.output_tokens,
            "total_tokens": resp.usage.input_tokens
            + resp.usage.cache_read_input_tokens
            + resp.usage.cache_creation_input_tokens
            + resp.usage.output_tokens,
        }
    return outputs


def _format_chat_attributes(span: LLMCallSpan) -> dict[str, Any]:
    resp = span.response
    assert resp is not None
    attributes: dict[str, Any] = {}
    if resp.usage:
        token_usage: dict[str, int] = {
            "input_tokens": resp.usage.input_tokens,
            "output_tokens": resp.usage.output_tokens,
            "total_tokens": resp.usage.input_tokens
            + resp.usage.cache_read_input_tokens
            + resp.usage.cache_creation_input_tokens
            + resp.usage.output_tokens,
        }
        if resp.usage.cache_read_input_tokens:
            token_usage["cache_read_input_tokens"] = resp.usage.cache_read_input_tokens
        if resp.usage.cache_creation_input_tokens:
            token_usage["cache_creation_input_tokens"] = resp.usage.cache_creation_input_tokens
        attributes["mlflow.chat.tokenUsage"] = token_usage
        if resp.usage.cost is not None:
            cost = resp.usage.cost
            attributes["mlflow.llm.cost"] = {
                "input_cost": cost.input + cost.cache_read + cost.cache_creation,
                "output_cost": cost.output,
                "total_cost": cost.total,
            }
        elif resp.usage.cost_usd is not None:
            attributes["mlflow.llm.cost"] = {"total_cost": resp.usage.cost_usd}
    return attributes


# -- Message conversion to OpenAI format --


def _message_to_openai(msg: Message) -> list[dict[str, Any]]:
    match msg:
        case SystemMessage():
            return [_system_message_to_openai(msg)]
        case UserMessage():
            return _user_message_to_openai(msg)
        case AssistantMessage():
            return [_assistant_message_to_openai(msg)]


def _system_message_to_openai(msg: SystemMessage) -> dict[str, Any]:
    texts = [b.text for b in msg.blocks]
    return {"role": "system", "content": "\n".join(texts)}


def _user_message_to_openai(msg: UserMessage) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    text_parts: list[str] = []
    for block in msg.blocks:
        match block:
            case TextBlock(text=text):
                text_parts.append(text)
            case ToolResultBlock(tool_use_id=tool_use_id, content=content):
                if text_parts:
                    result.append({"role": "user", "content": "\n".join(text_parts)})
                    text_parts = []
                result.append(
                    {
                        "role": "tool",
                        "content": content,
                        "tool_call_id": tool_use_id,
                    }
                )
            case ImageBlock():
                text_parts.append("[image]")
    if text_parts:
        result.append({"role": "user", "content": "\n".join(text_parts)})
    return result or [{"role": "user", "content": ""}]


def _assistant_message_to_openai(msg: AssistantMessage) -> dict[str, Any]:
    text_parts: list[str] = []
    tool_calls: list[dict[str, Any]] = []
    reasoning: str | None = None

    for block in msg.blocks:
        match block:
            case TextBlock(text=text):
                text_parts.append(text)
            case ToolUseBlock(id=id_, name=name, input=input_):
                tool_calls.append(
                    {
                        "id": id_,
                        "type": "function",
                        "function": {
                            "name": name,
                            "arguments": json.dumps(input_),
                        },
                    }
                )
            case ThinkingBlock(text=text):
                reasoning = text

    result: dict[str, Any] = {"role": "assistant"}
    if text_parts:
        result["content"] = "\n".join(text_parts)
    if tool_calls:
        result["tool_calls"] = tool_calls
    if reasoning:
        result["reasoning"] = reasoning
    return result
