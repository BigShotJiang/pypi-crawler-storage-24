import contextlib
import dataclasses
import inspect
import logging
from collections.abc import Sequence
from typing import Any, Self

from ..llm import Tool
from .local_tool import LocalTool, ToolExecutionContext
from .mcp_connection import McpConnection
from .tool_group import LocalToolGroup, McpToolGroup, ToolGroup
from .types import ToolDefinition, ToolResult

__all__ = ["ToolRegistry", "ToolSource"]

logger = logging.getLogger(__name__)

_NAME_SEPARATOR = "__"

type ToolSource = ToolGroup | LocalTool


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class _LocalRegistrySource:
    local_tool: LocalTool
    prefix: str | None


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class _McpRegistrySource:
    mcp_connection: McpConnection
    prefix: str | None


type _RegistrySource = _LocalRegistrySource | _McpRegistrySource


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class _LocalEntry:
    tool_definition: ToolDefinition
    local_tool: LocalTool


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class _McpEntry:
    tool_definition: ToolDefinition
    mcp_connection: McpConnection
    original_tool_name: str


type _RegistryEntry = _LocalEntry | _McpEntry


class ToolRegistry:
    __slots__ = ("__callback_tokens", "__exit_stack", "__registry", "__sources")

    def __init__(
        self,
        *,
        exit_stack: contextlib.AsyncExitStack,
        sources: list[_RegistrySource],
    ) -> None:
        self.__exit_stack = exit_stack
        self.__sources = sources
        self.__registry = self.__build_registry(sources)
        self.__callback_tokens: list[tuple[McpConnection, int]] = []
        for source in sources:
            if not isinstance(source, _McpRegistrySource):
                continue
            token = source.mcp_connection.add_on_tools_changed(self.__on_mcp_tools_changed)
            self.__callback_tokens.append((source.mcp_connection, token))

    @classmethod
    async def create(cls, tool_sources: Sequence[ToolSource]) -> Self:
        cls.__validate_local_tools(tool_sources)

        exit_stack = contextlib.AsyncExitStack()
        async with exit_stack:
            sources: list[_RegistrySource] = []

            for source in tool_sources:
                match source:
                    case LocalTool() as local_tool:
                        sources.append(_LocalRegistrySource(local_tool=local_tool, prefix=None))

                    case LocalToolGroup(prefix=prefix, tools=tools):
                        for local_tool in tools:
                            sources.append(_LocalRegistrySource(local_tool=local_tool, prefix=prefix))

                    case McpToolGroup(prefix=prefix, url=url, headers=headers):
                        connection = await McpConnection.connect(url, headers)
                        exit_stack.push_async_callback(connection.close)
                        sources.append(_McpRegistrySource(mcp_connection=connection, prefix=prefix))

            exit_stack = exit_stack.pop_all()

        return cls(
            exit_stack=exit_stack,
            sources=sources,
        )

    def get_tools(self) -> list[ToolDefinition]:
        return [entry.tool_definition for entry in self.__registry.values()]

    def get_llm_tools(self) -> list[Tool]:
        return [
            Tool(name=td.name, description=td.description, input_schema=td.input_schema, output_schema=td.output_schema)
            for td in self.get_tools()
        ]

    async def execute(
        self,
        name: str,
        args: dict[str, Any] | None = None,
        *,
        services: dict[type, Any] | None = None,
    ) -> ToolResult:
        entry = self.__registry.get(name)
        if entry is None:
            logger.warning("Unknown tool: %s", name)
            return ToolResult(content=f"Unknown tool: {name}", is_error=True)

        match entry:
            case _LocalEntry(local_tool=local_tool):
                try:
                    ctx = ToolExecutionContext(input=args or {}, services=services or {})
                    result = local_tool.handler(ctx)
                    if inspect.isawaitable(result):
                        result = await result
                    return result
                except Exception as e:
                    logger.exception("Local tool %s failed", name)
                    return ToolResult(content=f"Error: {e}", is_error=True)

            case _McpEntry(mcp_connection=mcp_connection, original_tool_name=original_tool_name):
                try:
                    return await mcp_connection.call_tool(original_tool_name, args)
                except Exception as e:
                    logger.exception("MCP tool %s failed", name)
                    return ToolResult(content=f"Error: {e}", is_error=True)

    async def close(self) -> None:
        for connection, token in self.__callback_tokens:
            connection.remove_on_tools_changed(token)
        await self.__exit_stack.aclose()

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.close()

    @classmethod
    def __validate_local_tools(cls, sources: Sequence[ToolSource]) -> None:
        seen: set[str] = set()
        for source in sources:
            match source:
                case LocalTool() as local_tool:
                    if local_tool.definition.name in seen:
                        raise ValueError(f"Duplicate local tool name: '{local_tool.definition.name}'")
                    seen.add(local_tool.definition.name)

                case LocalToolGroup(prefix=prefix, tools=tools):
                    for lt in tools:
                        prefixed = cls.__prefixed_name(prefix, lt.definition.name)
                        if prefixed in seen:
                            raise ValueError(f"Duplicate local tool name: '{prefixed}'")
                        seen.add(prefixed)

                case McpToolGroup():
                    # We can't validate MCP tool names ahead of time, so we skip them here.
                    pass

    @classmethod
    def __build_registry(
        cls,
        sources: list[_RegistrySource],
    ) -> dict[str, _RegistryEntry]:
        registry: dict[str, _RegistryEntry] = {}

        for source in sources:
            match source:
                case _LocalRegistrySource(local_tool=local_tool, prefix=prefix):
                    prefixed = cls.__prefixed_name(prefix, local_tool.definition.name)
                    if prefixed in registry:
                        logger.error("Tool '%s' already exists, ignoring duplicate", prefixed)
                        continue

                    registry[prefixed] = _LocalEntry(
                        tool_definition=dataclasses.replace(local_tool.definition, name=prefixed),
                        local_tool=local_tool,
                    )

                case _McpRegistrySource(mcp_connection=mcp_connection, prefix=prefix):
                    for mcp_tool in mcp_connection.get_tools():
                        prefixed = cls.__prefixed_name(prefix, mcp_tool.name)
                        if prefixed in registry:
                            logger.error("Tool '%s' already exists, ignoring duplicate", prefixed)
                            continue

                        registry[prefixed] = _McpEntry(
                            tool_definition=dataclasses.replace(mcp_tool, name=prefixed),
                            mcp_connection=mcp_connection,
                            original_tool_name=mcp_tool.name,
                        )

        return registry

    @staticmethod
    def __prefixed_name(prefix: str | None, tool_name: str) -> str:
        if prefix is None:
            return tool_name
        return f"{prefix}{_NAME_SEPARATOR}{tool_name}"

    def __on_mcp_tools_changed(self) -> None:
        self.__registry = self.__build_registry(self.__sources)
