import dataclasses
from typing import Any

__all__ = ["ToolDefinition", "ToolResult"]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ToolDefinition:
    name: str
    description: str
    input_schema: dict[str, Any] | None = None
    output_schema: dict[str, Any] | None = None


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ToolResult:
    content: str
    is_error: bool = False
