"""Annotated markers for tool parameter binding.

Usage::

    from flowra.tools import tool_arg

    @tool("fetch")
    def fetch(
        params: Annotated[FetchParams, tool_arg.INPUT],
        svc: Annotated[MyService, tool_arg.SERVICE],
    ) -> str: ...
"""

__all__ = [
    "INPUT",
    "SERVICE",
]

INPUT = object()
SERVICE = object()
