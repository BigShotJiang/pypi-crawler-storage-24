import dataclasses
import enum
from typing import Any

from .messages import AssistantMessage

__all__ = ["CostBreakdown", "LLMResponse", "StopReason", "Usage"]


class StopReason(enum.StrEnum):
    END_TURN = "end_turn"
    MAX_TOKENS = "max_tokens"
    TOOL_USE = "tool_use"
    STOP_SEQUENCE = "stop_sequence"
    SCHEMA_VALIDATION_FAILED = "schema_validation_failed"
    OTHER = "other"


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class CostBreakdown:
    """Per-category cost breakdown in USD."""

    input: float = 0.0
    output: float = 0.0
    cache_read: float = 0.0
    cache_creation: float = 0.0

    @property
    def total(self) -> float:
        return self.input + self.output + self.cache_read + self.cache_creation

    def __add__(self, other: "CostBreakdown") -> "CostBreakdown":
        return CostBreakdown(
            input=self.input + other.input,
            output=self.output + other.output,
            cache_read=self.cache_read + other.cache_read,
            cache_creation=self.cache_creation + other.cache_creation,
        )


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class Usage:
    """Token usage and cost for a single LLM call (or aggregated via __add__).

    Token contract: each token is counted in exactly one category.
    ``input_tokens`` does NOT include cached tokens — those go into
    ``cache_read_input_tokens`` and ``cache_creation_input_tokens``.
    """

    input_tokens: int
    output_tokens: int
    cache_read_input_tokens: int = 0
    cache_creation_input_tokens: int = 0
    cost_usd: float | None = None
    cost: CostBreakdown | None = None
    extra: dict[str, Any] = dataclasses.field(default_factory=dict)

    def __add__(self, other: "Usage") -> "Usage":
        merged_extra = {**self.extra}
        for k, v in other.extra.items():
            if k in merged_extra and isinstance(v, int | float):
                merged_extra[k] = merged_extra[k] + v
            else:
                merged_extra[k] = v

        cost_usd: float | None = None
        if self.cost_usd is not None and other.cost_usd is not None:
            cost_usd = self.cost_usd + other.cost_usd
        elif self.cost_usd is not None:
            cost_usd = self.cost_usd
        elif other.cost_usd is not None:
            cost_usd = other.cost_usd

        cost: CostBreakdown | None = None
        if self.cost is not None and other.cost is not None:
            cost = self.cost + other.cost
        elif self.cost is not None:
            cost = self.cost
        elif other.cost is not None:
            cost = other.cost

        return Usage(
            input_tokens=self.input_tokens + other.input_tokens,
            output_tokens=self.output_tokens + other.output_tokens,
            cache_read_input_tokens=self.cache_read_input_tokens + other.cache_read_input_tokens,
            cache_creation_input_tokens=self.cache_creation_input_tokens + other.cache_creation_input_tokens,
            cost_usd=cost_usd,
            cost=cost,
            extra=merged_extra,
        )


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class LLMResponse:
    message: AssistantMessage
    stop_reason: StopReason
    stop_sequence: str | None = None
    usage: Usage | None = None
    extra: dict[str, Any] = dataclasses.field(default_factory=dict)
