import dataclasses
from typing import Any

from .base import LLMData

__all__ = ["Tool"]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class Tool(LLMData):
    name: str
    description: str
    input_schema: dict[str, Any] | None = None
    output_schema: dict[str, Any] | None = None
