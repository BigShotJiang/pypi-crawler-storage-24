"""Observability types for LLM interactions — shared across agents.

Span types (for span-hooks) and streaming events (for regular hooks).
"""

import dataclasses

from .blocks import ToolResultBlock, ToolUseBlock
from .request import LLMRequest
from .response import LLMResponse

__all__ = [
    "LLMCallSpan",
    "TextDeltaEvent",
    "ThinkingDeltaEvent",
    "ToolCallSpan",
]


# -- Span types (span-hooks: guaranteed enter/exit) --


# Mutable: request set at open, response set before close.
@dataclasses.dataclass(slots=True, kw_only=True)
class LLMCallSpan:
    request: LLMRequest
    response: LLMResponse | None = None


# Mutable: tool_use set at open, result set before close.
@dataclasses.dataclass(slots=True, kw_only=True)
class ToolCallSpan:
    tool_use: ToolUseBlock
    result: ToolResultBlock | None = None


# -- Streaming events (regular hooks: observation-only) --


@dataclasses.dataclass(slots=True, kw_only=True)
class TextDeltaEvent:
    """Emitted during streaming for each text chunk.

    Observation-only — use for real-time text display.
    Registering a handler enables streaming mode automatically.
    """

    text: str


@dataclasses.dataclass(slots=True, kw_only=True)
class ThinkingDeltaEvent:
    """Emitted during streaming for each thinking chunk.

    Observation-only — use for real-time thinking display.
    Registering a handler enables streaming mode automatically.
    """

    text: str
