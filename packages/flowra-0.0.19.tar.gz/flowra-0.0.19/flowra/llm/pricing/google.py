"""Pricing for Google Gemini models (via Vertex AI).

Google charges for input, output, and cache reads.
Cache creation is free (automatic).
"""

from dataclasses import dataclass

from ..response import CostBreakdown

__all__ = ["estimate_cost"]


# Not kw_only — constructed positionally in pricing tables for readability.
@dataclass(frozen=True, slots=True)
class _ModelPricing:
    input: float  # $ per 1M tokens
    output: float  # $ per 1M tokens
    cache_read: float  # $ per 1M tokens


# Ordered longest-key-first so the first substring match is the most specific.
_PRICING: list[tuple[str, _ModelPricing]] = [
    ("gemini-3.1-flash-lite-preview", _ModelPricing(0.25, 1.50, 0.03)),
    ("gemini-3.1-pro-preview", _ModelPricing(2.00, 12.00, 0.20)),
    ("gemini-3-flash-preview", _ModelPricing(0.50, 3.00, 0.05)),
    ("gemini-2.5-flash-lite", _ModelPricing(0.10, 0.40, 0.01)),
    ("gemini-2.0-flash-lite", _ModelPricing(0.075, 0.30, 0)),
    ("gemini-3-pro-preview", _ModelPricing(2.00, 12.00, 0.20)),
    ("gemini-2.0-flash", _ModelPricing(0.15, 0.60, 0)),
    ("gemini-2.5-flash", _ModelPricing(0.30, 2.50, 0.03)),
    ("gemini-2.5-pro", _ModelPricing(1.25, 10.00, 0.125)),
]


def estimate_cost(
    model: str,
    input_tokens: int,
    output_tokens: int,
    cache_read_tokens: int,
) -> CostBreakdown | None:
    """Estimate dollar cost for a Google Gemini model.

    Returns None if the model is not in the pricing table.

    Contract: ``input_tokens`` must NOT include cache tokens.
    Each token is counted in exactly one category.
    """
    for key, p in _PRICING:
        if key in model:
            return CostBreakdown(
                input=input_tokens * p.input / 1_000_000,
                output=output_tokens * p.output / 1_000_000,
                cache_read=cache_read_tokens * p.cache_read / 1_000_000,
            )
    return None
