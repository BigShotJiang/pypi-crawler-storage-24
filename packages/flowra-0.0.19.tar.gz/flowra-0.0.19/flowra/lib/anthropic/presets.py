"""Composite presets for common Anthropic caching configurations."""

from typing import Protocol

from ...agent import HookSubscription
from .cache import (
    AnthropicCacheAllMessages,
    AnthropicCacheAllSystemMessages,
    AnthropicCacheAllTools,
    AnthropicCacheHistoryMessages,
)

__all__ = ["ANTHROPIC_CACHE_ALL", "ANTHROPIC_CACHE_SESSION"]


class _Installable(Protocol):
    def install(self, hooks: HookSubscription) -> None: ...


class _CompositeExtension:
    __slots__ = ("_extensions",)

    def __init__(self, *extensions: _Installable) -> None:
        self._extensions = extensions

    def install(self, hooks: HookSubscription) -> None:
        for ext in self._extensions:
            ext.install(hooks)


ANTHROPIC_CACHE_ALL = _CompositeExtension(
    AnthropicCacheAllSystemMessages(),
    AnthropicCacheAllTools(),
    AnthropicCacheAllMessages(),
)

ANTHROPIC_CACHE_SESSION = _CompositeExtension(
    AnthropicCacheAllSystemMessages(),
    AnthropicCacheAllTools(),
    AnthropicCacheHistoryMessages(),
)
