"""Anthropic tool search hook bundle.

Deferred tool loading for large tool sets — marks tools with
``defer_loading: true`` and adds the Anthropic server-side search tool.
"""

import dataclasses
import enum
from collections.abc import Callable

from ...agent import Event, HookSubscription
from ...llm import LLMRequest, Tool
from ..tool_loop import PrepareLLMRequestEvent

__all__ = ["AnthropicToolSearch", "ToolSearchVariant"]


class ToolSearchVariant(enum.StrEnum):
    BM25 = "bm25"
    REGEX = "regex"


_SEARCH_TOOL_TYPES: dict[ToolSearchVariant, str] = {
    ToolSearchVariant.BM25: "tool_search_tool_bm25_20251119",
    ToolSearchVariant.REGEX: "tool_search_tool_regex_20251119",
}


class AnthropicToolSearch:
    """Defer tool loading and add the Anthropic tool search tool.

    Marks tools with ``defer_loading: true`` so Claude sees only names and
    descriptions (not full schemas). Adds a server-side search tool that
    Claude calls to discover full tool definitions on demand.

    Reduces token usage by ~85% when using many tools (50+).

    Args:
        variant: Search tool variant — ``BM25`` (natural language, default)
            or ``REGEX`` (Claude constructs regex patterns).
        predicate: Optional callable ``(Tool) -> bool`` to select which tools
            to defer. By default all tools are deferred.
    """

    __slots__ = ("__predicate", "__search_tool_name", "__search_tool_type")

    def __init__(
        self,
        *,
        variant: ToolSearchVariant = ToolSearchVariant.BM25,
        predicate: Callable[[Tool], bool] | None = None,
    ) -> None:
        self.__search_tool_type = _SEARCH_TOOL_TYPES[variant]
        self.__search_tool_name = f"tool_search_tool_{variant}"
        self.__predicate = predicate

    def install(self, hooks: HookSubscription) -> None:
        hooks.on(PrepareLLMRequestEvent, self.on_prepare)

    def on_prepare(self, event: Event[PrepareLLMRequestEvent]) -> None:
        request: LLMRequest = event.data.request
        if not request.tools:
            return

        has_deferred = False
        tools: list[Tool] = []
        for tool in request.tools:
            if self.__predicate is None or self.__predicate(tool):
                tools.append(dataclasses.replace(tool, extra={**tool.extra, "defer_loading": True}))
                has_deferred = True
            else:
                tools.append(tool)

        if not has_deferred:
            return

        # Add the search tool
        search_tool = Tool(
            name=self.__search_tool_name,
            description="",
            extra={"type": self.__search_tool_type},
        )
        tools.insert(0, search_tool)

        event.data.request = dataclasses.replace(request, tools=tools)
