"""Anthropic prompt caching hook bundles.

Composable hook bundles that set ``cache_control: {"type": "ephemeral"}``
on blocks and tools via the ``PrepareLLMRequestEvent`` hook.

Each bundle handles one caching slot (system, tools, or messages).
The ``NonTransient*`` bundles respect the ``transient`` hint on
blocks/messages — transient content is not cached. The ``*All*``
bundles cache the last block regardless of ``transient``.
"""

import dataclasses

from ...agent import Event, HookSubscription
from ...llm import LLMData, LLMRequest, Message
from ..chat import SaveHistoryEvent
from ..tool_loop import PrepareLLMRequestEvent

__all__ = [
    "AnthropicCacheAllMessages",
    "AnthropicCacheAllSystemMessages",
    "AnthropicCacheAllTools",
    "AnthropicCacheHistoryMessages",
    "AnthropicCacheNonTransientMessages",
    "AnthropicCacheNonTransientSystemMessages",
]

_HISTORY_BREAKPOINT_KEY = "_anthropic_history_cache_breakpoint"


# -- Helpers --


def _set_cache[T: LLMData](obj: T) -> T:
    return dataclasses.replace(obj, extra={**obj.extra, "cache_control": {"type": "ephemeral"}})


def _clear_cache[T: LLMData](obj: T) -> T:
    if "cache_control" not in obj.extra:
        return obj
    new_extra = {k: v for k, v in obj.extra.items() if k != "cache_control"}
    return dataclasses.replace(obj, extra=new_extra)


def _clear_message_cache[T: Message](messages: list[T]) -> list[T]:
    result = list(messages)
    for i, m in enumerate(result):
        if any("cache_control" in b.extra for b in m.blocks):
            result[i] = dataclasses.replace(m, blocks=[_clear_cache(b) for b in m.blocks])
    return result


def _cache_last_block[T: Message](messages: list[T]) -> list[T]:
    if not messages:
        return messages
    result = _clear_message_cache(messages)
    last = result[-1]
    if last.blocks:
        new_blocks = list(last.blocks)
        new_blocks[-1] = _set_cache(new_blocks[-1])
        result[-1] = dataclasses.replace(last, blocks=new_blocks)
    return result


def _cache_last_non_transient_block[T: Message](messages: list[T]) -> list[T]:
    if not messages:
        return messages
    result = _clear_message_cache(messages)
    # Find last non-transient message
    target_idx = -1
    for i in range(len(result) - 1, -1, -1):
        if not result[i].transient:
            target_idx = i
            break
    if target_idx >= 0:
        msg = result[target_idx]
        if msg.blocks:
            new_blocks = list(msg.blocks)
            # Find last non-transient block
            block_idx = -1
            for j in range(len(new_blocks) - 1, -1, -1):
                if not new_blocks[j].transient:
                    block_idx = j
                    break
            if block_idx >= 0:
                new_blocks[block_idx] = _set_cache(new_blocks[block_idx])
                result[target_idx] = dataclasses.replace(msg, blocks=new_blocks)
    return result


# -- System message caching --


class AnthropicCacheAllSystemMessages:
    """Cache the last block of the last system message."""

    __slots__ = ()

    def install(self, hooks: HookSubscription) -> None:
        hooks.on(PrepareLLMRequestEvent, self.on_prepare)

    def on_prepare(self, event: Event[PrepareLLMRequestEvent]) -> None:
        request: LLMRequest = event.data.request
        if request.system:
            event.data.request = dataclasses.replace(request, system=_cache_last_block(request.system))


class AnthropicCacheNonTransientSystemMessages:
    """Cache the last non-transient block of the last non-transient system message."""

    __slots__ = ()

    def install(self, hooks: HookSubscription) -> None:
        hooks.on(PrepareLLMRequestEvent, self.on_prepare)

    def on_prepare(self, event: Event[PrepareLLMRequestEvent]) -> None:
        request: LLMRequest = event.data.request
        if request.system:
            event.data.request = dataclasses.replace(request, system=_cache_last_non_transient_block(request.system))


# -- Tool caching --


class AnthropicCacheAllTools:
    """Cache the last tool definition."""

    __slots__ = ()

    def install(self, hooks: HookSubscription) -> None:
        hooks.on(PrepareLLMRequestEvent, self.on_prepare)

    def on_prepare(self, event: Event[PrepareLLMRequestEvent]) -> None:
        request: LLMRequest = event.data.request
        if not request.tools:
            return
        tools = [_clear_cache(t) for t in request.tools]
        tools[-1] = _set_cache(tools[-1])
        event.data.request = dataclasses.replace(request, tools=tools)


# -- Message caching --


class AnthropicCacheAllMessages:
    """Cache the last block of the last message."""

    __slots__ = ()

    def install(self, hooks: HookSubscription) -> None:
        hooks.on(PrepareLLMRequestEvent, self.on_prepare)

    def on_prepare(self, event: Event[PrepareLLMRequestEvent]) -> None:
        request: LLMRequest = event.data.request
        if request.messages:
            event.data.request = dataclasses.replace(request, messages=_cache_last_block(request.messages))


class AnthropicCacheNonTransientMessages:
    """Cache the last non-transient block of the last non-transient message."""

    __slots__ = ()

    def install(self, hooks: HookSubscription) -> None:
        hooks.on(PrepareLLMRequestEvent, self.on_prepare)

    def on_prepare(self, event: Event[PrepareLLMRequestEvent]) -> None:
        request: LLMRequest = event.data.request
        if request.messages:
            event.data.request = dataclasses.replace(
                request, messages=_cache_last_non_transient_block(request.messages)
            )


class AnthropicCacheHistoryMessages:
    """Cache the last message that was in history before the current turn.

    Hooks into ``SaveHistoryEvent`` to mark the last message with a metadata
    breakpoint. In ``PrepareLLMRequestEvent``, finds that marker and sets
    ``cache_control`` on its last block. This avoids cache invalidation on
    every new user message — the cache breakpoint stays on the history boundary.

    Requires ``ChatAgent`` (which emits ``SaveHistoryEvent``).
    """

    __slots__ = ()

    def install(self, hooks: HookSubscription) -> None:
        hooks.on(SaveHistoryEvent, self.on_save_history)
        hooks.on(PrepareLLMRequestEvent, self.on_prepare)

    @staticmethod
    def on_save_history(event: Event[SaveHistoryEvent]) -> None:
        messages = event.data.messages
        if not messages:
            return
        last = messages[-1]
        if last.blocks:
            messages[-1] = dataclasses.replace(last, metadata={**last.metadata, _HISTORY_BREAKPOINT_KEY: True})

    def on_prepare(self, event: Event[PrepareLLMRequestEvent]) -> None:
        request: LLMRequest = event.data.request
        if not request.messages:
            return

        messages = _clear_message_cache(request.messages)

        # Find last message with the breakpoint marker
        breakpoint_idx = -1
        for i, m in enumerate(messages):
            if m.metadata.get(_HISTORY_BREAKPOINT_KEY):
                breakpoint_idx = i

        if breakpoint_idx >= 0:
            msg = messages[breakpoint_idx]
            if msg.blocks:
                new_blocks = list(msg.blocks)
                new_blocks[-1] = _set_cache(new_blocks[-1])
                messages[breakpoint_idx] = dataclasses.replace(msg, blocks=new_blocks)

        event.data.request = dataclasses.replace(request, messages=messages)
