import dataclasses

from ...llm import AssistantMessage, SystemMessage, Usage, UserMessage

__all__ = ["LLMCallResult", "LLMCallSpec"]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class LLMCallSpec:
    system: list[SystemMessage] = dataclasses.field(default_factory=list)
    messages: list[UserMessage | AssistantMessage] = dataclasses.field(default_factory=list)


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class LLMCallResult:
    message: AssistantMessage
    usage: Usage | None = None
    elapsed: float = 0.0
