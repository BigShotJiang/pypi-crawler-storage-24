import inspect
from collections.abc import Awaitable, Callable

__all__ = ["ConfigValue", "resolve_config_value"]

type ConfigValue[T] = Callable[[], T | Awaitable[T]] | T


async def resolve_config_value[T](value: ConfigValue[T]) -> T:
    """Resolve a ConfigValue to its underlying value.

    Handles: plain values, sync callables, and async callables.
    """
    if callable(value):
        result = value()
        if inspect.isawaitable(result):
            return await result
        return result  # type: ignore[return-value]  # callable() narrows but pyright can't see T through Awaitable
    return value
