import dataclasses
import enum
from typing import Any

from ...llm import AssistantMessage, StopReason, TextBlock, Usage, UserMessage

__all__ = ["ToolLoopResult", "ToolLoopSpec", "ToolLoopStatus"]


class ToolLoopStatus(enum.StrEnum):
    COMPLETED = "completed"
    MAX_LLM_CALLS = "max_llm_calls"
    INTERRUPTED = "interrupted"
    FINISH_REQUESTED = "finish_requested"


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ToolLoopSpec:
    user_message: str
    metadata: dict[str, Any] | None = None

    def __preview__(self) -> str:
        return self.user_message


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ToolLoopResult:
    messages: list[UserMessage | AssistantMessage]
    status: ToolLoopStatus
    stop_reason: StopReason | None = None
    result_message: AssistantMessage | None = None
    usage: Usage | None = None

    def __preview__(self) -> str:
        if self.result_message is None:
            return self.status
        texts = [b.text for b in self.result_message.blocks if isinstance(b, TextBlock)]
        return "\n".join(texts) if texts else self.status
