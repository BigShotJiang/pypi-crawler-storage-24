__all__ = ["ToolLoopAgentContext"]


class ToolLoopAgentContext:
    """Context available to tools during ToolLoopAgent execution.

    Tools can request that the agent stop the tool loop by calling
    request_finish(). The loop will complete the current iteration
    and return a result with status FINISH_REQUESTED.
    """

    __slots__ = ("__finish_requested",)

    def __init__(self) -> None:
        self.__finish_requested = False

    def request_finish(self) -> None:
        self.__finish_requested = True

    def is_finish_requested(self) -> bool:
        return self.__finish_requested
