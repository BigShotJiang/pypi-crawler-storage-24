import dataclasses
from fnmatch import fnmatch
from typing import Any

from ...llm import AssistantMessage, SystemMessage, UserMessage
from ..config_value import ConfigValue
from ..llm_config import LLMConfig

__all__ = ["ToolLoopConfig", "matches_tool_filter"]


def matches_tool_filter(name: str, patterns: set[str]) -> bool:
    """Check if a tool name matches any of the patterns (supports wildcards via fnmatch)."""
    return any(fnmatch(name, p) for p in patterns)


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ToolLoopConfig:
    """Configuration for ToolLoopAgent.

    Data providers accept ConfigValue[T] — a plain value, sync callable, or async callable.
    """

    llm_config: ConfigValue[LLMConfig]
    system: ConfigValue[list[SystemMessage]]
    history: ConfigValue[list[UserMessage | AssistantMessage]]
    json_schema: ConfigValue[dict[str, Any] | None] = None
    max_llm_calls: ConfigValue[int] = 10
    allowed_tools: ConfigValue[set[str] | None] = None
    denied_tools: ConfigValue[set[str] | None] = None
    max_consecutive_errors: ConfigValue[int | None] = None
