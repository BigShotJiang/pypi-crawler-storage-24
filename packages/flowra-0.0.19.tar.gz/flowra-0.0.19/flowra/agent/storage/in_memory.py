from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Any

from .session_storage import ChangeSet, SessionStorage

__all__ = ["InMemorySessionStorage"]


class InMemorySessionStorage(SessionStorage):
    __slots__ = ("__execution", "__node_states")

    def __init__(self) -> None:
        self.__execution: dict[str, Any] | None = None
        self.__node_states: dict[str, dict[str, Any]] = {}

    @asynccontextmanager
    async def begin_transaction(self) -> AsyncIterator[None]:
        yield

    async def has_execution(self) -> bool:
        return self.__execution is not None

    async def save_execution(self, execution: dict[str, Any]) -> None:
        self.__execution = execution

    async def save_node_state(self, key: str, changes: ChangeSet) -> None:
        if key not in self.__node_states:
            self.__node_states[key] = {}
        state = self.__node_states[key]
        state.update(changes.scalars)
        for k, items in changes.appends.items():
            if k not in state:
                state[k] = []
            state[k].extend(items)

    async def load_execution(self) -> dict[str, Any] | None:
        return self.__execution

    async def load_node_state(self, key: str) -> dict[str, Any] | None:
        state = self.__node_states.get(key)
        if state is None:
            return None
        return dict(state)

    async def clear_execution(self) -> None:
        self.__execution = None
