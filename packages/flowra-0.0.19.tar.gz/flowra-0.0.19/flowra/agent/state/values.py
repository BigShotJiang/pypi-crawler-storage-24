from collections.abc import Iterable, Sequence

from ..._sentinel import UNSET, Unset

__all__ = [
    "AppendOnlyList",
    "Scalar",
]


class Scalar[T]:
    __slots__ = ("__dirty", "__value")

    def __init__(self) -> None:
        self.__value: T | Unset = UNSET
        self.__dirty = False

    def get(self, default: T | Unset = UNSET) -> T:
        if not isinstance(self.__value, Unset):
            return self.__value
        if not isinstance(default, Unset):
            return default
        raise LookupError("Scalar has no value and no default was provided")

    def has_value(self) -> bool:
        return not isinstance(self.__value, Unset)

    def set(self, value: T) -> None:
        self.__value = value
        self.__dirty = True

    def restore(self, value: T) -> None:
        self.__value = value
        self.__dirty = False

    def is_dirty(self) -> bool:
        return self.__dirty

    def mark_clean(self) -> None:
        self.__dirty = False


class AppendOnlyList[T]:
    __slots__ = ("__items", "__unflushed_count")

    def __init__(self, items: Sequence[T] = ()) -> None:
        self.__items: list[T] = list(items)
        self.__unflushed_count = 0

    def get_all(self) -> list[T]:
        return list(self.__items)

    def append(self, item: T) -> None:
        self.__items.append(item)
        self.__unflushed_count += 1

    def extend(self, items: Iterable[T]) -> None:
        new_items = list(items)
        self.__items.extend(new_items)
        self.__unflushed_count += len(new_items)

    def restore(self, items: Sequence[T]) -> None:
        self.__items = list(items)
        self.__unflushed_count = 0

    def get_unflushed(self) -> list[T]:
        if self.__unflushed_count == 0:
            return []
        return list(self.__items[-self.__unflushed_count :])

    def mark_clean(self) -> None:
        self.__unflushed_count = 0
