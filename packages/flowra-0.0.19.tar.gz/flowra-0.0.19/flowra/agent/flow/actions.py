import dataclasses
from typing import Any

from ..definition import AgentRef, StepRef, resolve_step_ref
from ..state.markers import Fork, NewScope

__all__ = [
    "CallAgent",
    "CallStep",
    "GotoAgent",
    "GotoStep",
]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True, init=False)
class GotoStep:
    step: str
    spec: Any | None
    storage_key: str | NewScope | Fork | None

    def __init__(
        self,
        *,
        step: StepRef,
        spec: Any | None = None,
        storage_key: str | NewScope | Fork | None = None,
    ) -> None:
        object.__setattr__(self, "step", resolve_step_ref(step))
        object.__setattr__(self, "spec", spec)
        object.__setattr__(self, "storage_key", storage_key)


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True, init=False)
class CallStep:
    step: str
    spec: Any | None
    storage_key: str | NewScope | Fork | None
    tag: str | None

    def __init__(
        self,
        *,
        step: StepRef,
        spec: Any | None = None,
        storage_key: str | NewScope | Fork | None = None,
        tag: str | None = None,
    ) -> None:
        object.__setattr__(self, "step", resolve_step_ref(step))
        object.__setattr__(self, "spec", spec)
        object.__setattr__(self, "storage_key", storage_key)
        object.__setattr__(self, "tag", tag)


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class GotoAgent:
    agent: AgentRef
    spec: Any | None = None
    storage_key: str | NewScope | Fork | None = None


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class CallAgent:
    agent: AgentRef
    spec: Any | None = None
    storage_key: str | NewScope | Fork | None = None
    tag: str | None = None
