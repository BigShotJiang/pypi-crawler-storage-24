"""Flowing context — typed variables that flow with agent execution.

The engine manages the lifecycle: forking for child nodes, restoring after
sibling creation, snapshotting for task inheritance. Integrations (MLflow,
HTTP middleware, logging) read/write ``FlowingContextVar`` instances.

Usage (integration side)::

    from flowra.agent.flow.flowing import FlowingContextVar

    my_var = FlowingContextVar[str | None]("my_ns.current_value", default=None)

    # In a span handler:
    parent_value = my_var.get()
    my_var.set("new_value")

Usage (engine side)::

    from flowra.agent.flow.flowing import fork_flowing_context, restore_flowing_context, ...

    token = fork_flowing_context()       # snapshot + copy for child
    ...                                   # child creation, handlers modify vars
    child.snapshot = snapshot_flowing_context()
    restore_flowing_context(token)        # back to parent state
"""

import contextvars
from typing import Any

__all__ = [
    "FlowingContextVar",
    "apply_flowing_context",
    "fork_flowing_context",
    "restore_flowing_context",
    "snapshot_flowing_context",
]

type FlowingSnapshot = dict[int, Any]

_SENTINEL: Any = object()

_store: contextvars.ContextVar[FlowingSnapshot] = contextvars.ContextVar("_flowra_flowing", default={})


class FlowingContextVar[T]:
    """A typed variable in the flowing context.

    Create at module level. The engine ensures proper isolation between
    sibling children and inheritance into async tasks.
    """

    __slots__ = ("_default", "_key", "_name")

    def __init__(self, name: str, *, default: T = _SENTINEL) -> None:
        self._name = name
        self._default = default
        self._key = id(self)

    def get(self) -> T:
        """Read the current value (or default)."""
        val = _store.get().get(self._key, self._default)
        if val is _SENTINEL:
            raise LookupError(f"FlowingContextVar {self._name!r} has no value and no default")
        return val

    def set(self, value: T) -> None:
        """Set the value in the current flowing context scope."""
        _store.set({**_store.get(), self._key: value})

    def __repr__(self) -> str:
        return f"FlowingContextVar({self._name!r})"


# -- Engine API --


def fork_flowing_context() -> contextvars.Token[FlowingSnapshot]:
    """Create a new scope (copy of current state). Returns token for restore."""
    return _store.set(dict(_store.get()))


def restore_flowing_context(token: contextvars.Token[FlowingSnapshot]) -> None:
    """Restore to the state before the corresponding fork/apply."""
    _store.reset(token)


def snapshot_flowing_context() -> FlowingSnapshot:
    """Capture current state for later replay (e.g., before ensure_future)."""
    return _store.get()


def apply_flowing_context(snapshot: FlowingSnapshot) -> contextvars.Token[FlowingSnapshot]:
    """Apply a previously captured snapshot. Returns token for restore."""
    return _store.set(snapshot)
