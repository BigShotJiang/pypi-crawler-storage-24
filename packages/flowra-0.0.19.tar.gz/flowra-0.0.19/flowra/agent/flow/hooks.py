import dataclasses
import inspect
import logging
from collections.abc import AsyncIterator, Callable
from contextlib import asynccontextmanager
from typing import Any

from .context import ExecutionContext

__all__ = [
    "Event",
    "HookEmitter",
    "HookSubscription",
]

_logger = logging.getLogger(__name__)


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class Event[T]:
    """Generic envelope wrapping event data with execution context."""

    data: T
    context: ExecutionContext


class HookSubscription:
    """User-facing registry for event handlers and span handlers.

    Users create this, register handlers via on()/on_span(), and pass it to AgentRuntime.
    """

    __slots__ = ("__handlers", "__span_handlers")

    def __init__(self) -> None:
        self.__handlers: dict[type, list[Callable[..., Any]]] = {}
        self.__span_handlers: dict[type, list[Callable[..., Any]]] = {}

    # -- Regular event hooks --

    def on[E](self, event_type: type[E], handler: Callable[[Event[E]], Any], *, prepend: bool = False) -> None:
        handlers = self.__handlers.setdefault(event_type, [])
        if prepend:
            handlers.insert(0, handler)
        else:
            handlers.append(handler)

    def has_handlers(self, event_type: type) -> bool:
        handlers = self.__handlers.get(event_type)
        return handlers is not None and len(handlers) > 0

    def get_handlers(self) -> dict[type, list[Callable[..., Any]]]:
        return {k: list(v) for k, v in self.__handlers.items()}

    # -- Span hooks --

    def on_span[T](self, span_type: type[T], handler: Callable[[T], Any]) -> None:
        """Register a span handler. Later registrations are "more outer"."""
        self.__span_handlers.setdefault(span_type, []).append(handler)

    def has_span_handlers(self, span_type: type) -> bool:
        handlers = self.__span_handlers.get(span_type)
        return handlers is not None and len(handlers) > 0

    def get_span_handlers(self) -> dict[type, list[Callable[..., Any]]]:
        return {k: list(v) for k, v in self.__span_handlers.items()}


class HookEmitter:
    """Agent-facing emitter injected by the runtime.

    Agents use this to emit events, open/close spans, and check for handlers.
    """

    __slots__ = ("__context", "__exit_handlers", "__handlers", "__span_handlers")

    def __init__(
        self,
        handlers: dict[type, list[Callable[..., Any]]],
        context: ExecutionContext,
        span_handlers: dict[type, list[Callable[..., Any]]] | None = None,
    ) -> None:
        self.__handlers = handlers
        self.__context = context
        self.__span_handlers = span_handlers or {}
        self.__exit_handlers: dict[int, list[Callable[..., Any]]] = {}

    # -- Regular event hooks --

    def has_handlers(self, event_type: type) -> bool:
        handlers = self.__handlers.get(event_type)
        return handlers is not None and len(handlers) > 0

    async def emit[T](self, data: T) -> T:
        """Wrap data in Event, call all handlers, return (potentially mutated) data."""
        event = Event(data=data, context=self.__context)
        handlers = self.__handlers.get(type(data))
        if handlers:
            for handler in handlers:
                result = handler(event)
                if inspect.isawaitable(result):
                    await result
        return event.data

    # -- Span hooks --

    def has_span_handlers(self, span_type: type) -> bool:
        handlers = self.__span_handlers.get(span_type)
        return handlers is not None and len(handlers) > 0

    async def open_span[T](self, span: T) -> T:
        """Open a span. Calls enter handlers (last registered = outermost, called first)."""
        handlers = self.__span_handlers.get(type(span))
        if handlers:
            exit_list: list[Callable[..., Any]] = []
            for handler in reversed(handlers):
                try:
                    exit_handler = handler(span)
                    if inspect.isawaitable(exit_handler):
                        exit_handler = await exit_handler
                    if exit_handler is not None:
                        exit_list.append(exit_handler)
                except Exception:
                    _logger.exception("Span enter handler failed")
            if exit_list:
                self.__exit_handlers[id(span)] = exit_list
        return span

    async def close_span(self, span: Any, *, error: BaseException | None = None) -> None:
        """Close a span. Calls exit handlers in LIFO order (innermost first)."""
        exit_list = self.__exit_handlers.pop(id(span), None)
        if exit_list is None:
            return
        for exit_handler in reversed(exit_list):
            try:
                r = exit_handler(error)
                if inspect.isawaitable(r):
                    await r
            except Exception:
                _logger.exception("Span exit handler failed")

    @asynccontextmanager
    async def span[T](self, span: T) -> AsyncIterator[T]:
        """Context manager: open span, yield, close on exit (with error on exception)."""
        await self.open_span(span)
        try:
            yield span
            await self.close_span(span)
        except BaseException as e:
            await self.close_span(span, error=e)
            raise

    # -- Propagation --

    def propagate_to(
        self,
        target: "HookEmitter",
        *,
        only: list[type] | None = None,
        exclude: list[type] | None = None,
    ) -> None:
        """Register forwarding handlers that re-emit events and spans to target."""
        source_types: set[type] = set(self.__handlers.keys())
        if only is not None:
            source_types = set(only)
        if exclude is not None:
            source_types -= set(exclude)

        for event_type in source_types:
            handlers = self.__handlers.setdefault(event_type, [])

            async def _forward(event: Event[Any], _target: "HookEmitter" = target) -> None:
                await _target.emit(event.data)

            handlers.append(_forward)

        # Span forwarding
        span_source_types: set[type] = set(self.__span_handlers.keys())
        if only is not None:
            span_source_types = set(only)
        if exclude is not None:
            span_source_types -= set(exclude)

        for span_type in span_source_types:
            span_handlers = self.__span_handlers.setdefault(span_type, [])

            def _make_span_forwarder(_target: "HookEmitter" = target) -> Callable[..., Any]:
                async def _forward_enter(span: Any) -> Callable[..., Any] | None:
                    await _target.open_span(span)

                    async def _forward_exit(error: BaseException | None = None) -> None:
                        await _target.close_span(span, error=error)

                    return _forward_exit

                return _forward_enter

            span_handlers.append(_make_span_forwarder())
