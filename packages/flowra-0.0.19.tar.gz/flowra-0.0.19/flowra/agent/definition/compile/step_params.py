import dataclasses
import types
from typing import Annotated, Any, Union, get_args, get_origin

from .. import step_arg
from .type_helpers import flatten_types, get_type_hints, is_nullable, resolve_hint, to_isinstance_type, unwrap_optional

__all__ = ["StepParam", "compile_step_params", "find_spec_types"]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class StepParam:
    name: str
    match_type: type | tuple[type, ...]
    is_list: bool = False
    nullable: bool = False
    check_spec: bool = True
    check_children: bool = True
    child_tag: str | None = None


def compile_step_params(method: Any) -> tuple[StepParam, ...]:
    """Compile step method parameters into binding descriptors."""
    hints = get_type_hints(method)
    params: list[StepParam] = []
    for name, hint in hints.items():
        if name == "self" or name == "return":
            continue

        marker, inner_type = _find_marker(hint)
        raw_type = inner_type if marker is not None else hint

        check_spec = True
        check_children = True
        child_tag: str | None = None

        if marker is step_arg.SPEC:
            check_children = False
        elif isinstance(marker, type(step_arg.CHILD)):
            check_spec = False
            child_tag = marker.tag

        match_type, is_list = _extract_match_info(raw_type)
        _validate_step_param_type(match_type, name, method)

        params.append(
            StepParam(
                name=name,
                match_type=match_type,
                is_list=is_list,
                nullable=is_nullable(raw_type),
                check_spec=check_spec,
                check_children=check_children,
                child_tag=child_tag,
            )
        )
    return tuple(params)


def find_spec_types(method: Any) -> frozenset[type]:
    """Find spec types from a step method's step_arg.SPEC-annotated parameter."""
    hints = get_type_hints(method)
    for name, hint in hints.items():
        if name == "self" or name == "return":
            continue
        marker, inner_type = _find_marker(hint)
        if marker is step_arg.SPEC:
            unwrapped = unwrap_optional(inner_type)
            flat = flatten_types(unwrapped)
            concrete = [t for t in flat if t is not type(None) and isinstance(t, type)]
            if concrete:
                return frozenset(concrete)
    return frozenset()


def _find_marker(hint: Any) -> tuple[Any, Any]:
    """Find a step_arg marker in an Annotated type hint."""
    if get_origin(hint) is Annotated:
        return _check_annotated_metadata(hint)
    if isinstance(hint, types.UnionType) or get_origin(hint) is Union:
        for arg in get_args(hint):
            if arg is type(None):
                continue
            if get_origin(arg) is Annotated:
                return _check_annotated_metadata(arg)
    return None, None


def _check_annotated_metadata(annotated_hint: Any) -> tuple[Any, Any]:
    args = get_args(annotated_hint)
    if len(args) < 2:
        return None, None
    inner_type = args[0]
    for meta in args[1:]:
        if _is_step_marker(meta):
            return meta, inner_type
    return None, None


def _is_step_marker(meta: Any) -> bool:
    return meta is step_arg.SPEC or isinstance(meta, type(step_arg.CHILD))


def _extract_match_info(hint: Any) -> tuple[type | tuple[type, ...], bool]:
    """Extract (match_type, is_list) from a type hint."""
    unwrapped = unwrap_optional(hint)
    resolved = resolve_hint(unwrapped)
    origin = get_origin(resolved)
    if origin is list:
        args = get_args(resolved)
        if args:
            return to_isinstance_type(args[0]), True
        return object, True
    return to_isinstance_type(unwrapped), False


def _validate_step_param_type(match_type: type | tuple[type, ...], param_name: str, method: Any) -> None:
    if match_type is object:
        return
    types_to_check = match_type if isinstance(match_type, tuple) else (match_type,)
    for t in types_to_check:
        if not dataclasses.is_dataclass(t):
            step_name = getattr(method, "__qualname__", getattr(method, "__name__", repr(method)))
            raise TypeError(f"Step {step_name!r} parameter {param_name!r}: type {t.__name__} must be a dataclass")
