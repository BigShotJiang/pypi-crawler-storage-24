import inspect
from typing import Any

from ...services import ServiceLocator
from ..model import AgentInstance, ChildOutput
from .init_params import InitParam
from .steps import CompiledStep

__all__ = ["create_instance"]


def create_instance(
    agent_cls: type,
    init_params: tuple[InitParam, ...],
    compiled_steps: dict[str, CompiledStep],
    sl: ServiceLocator,
    agent_spec: Any | None = None,
) -> AgentInstance:
    """Instantiate agent and return an AgentInstance with a bound call_step closure."""
    all_services = dict(sl.services)
    kwargs: dict[str, Any] = {}
    for ip in init_params:
        if ip.is_spec:
            if agent_spec is not None and isinstance(agent_spec, ip.service_type):
                kwargs[ip.name] = agent_spec
            elif ip.nullable:
                kwargs[ip.name] = None
        else:
            if ip.service_type in all_services:
                kwargs[ip.name] = all_services[ip.service_type]
            elif ip.nullable:
                kwargs[ip.name] = None
    agent = agent_cls(**kwargs)

    def bind_step_args(
        step: CompiledStep,
        *,
        spec: Any | None = None,
        child_outputs: list[ChildOutput] | None = None,
    ) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for param in step.params:
            candidates: list[Any] = []
            mt = param.match_type

            if param.check_spec and spec is not None and isinstance(spec, mt):
                candidates.append(spec)

            if param.check_children and child_outputs:
                for co in child_outputs:
                    if param.child_tag is not None and co.tag != param.child_tag:
                        continue
                    if isinstance(co.result, mt):
                        candidates.append(co.result)

            if param.is_list:
                result[param.name] = candidates
            elif len(candidates) == 1:
                result[param.name] = candidates[0]
            elif len(candidates) > 1:
                raise RuntimeError(
                    f"Ambiguous binding for parameter '{param.name}' in step '{step.tag}': "
                    f"{len(candidates)} candidates match type {mt!r}"
                )
            elif param.nullable:
                result[param.name] = None
        return result

    async def call_step(
        tag: str,
        spec: Any | None = None,
        child_outputs: list[ChildOutput] | None = None,
    ) -> Any:
        step = compiled_steps.get(tag)
        if step is None:
            raise RuntimeError(f"Step {tag!r} not found in {agent_cls.__name__}")
        step_kwargs = bind_step_args(step, spec=spec, child_outputs=child_outputs or [])
        result = getattr(agent, step.method_name)(**step_kwargs)
        if inspect.isawaitable(result):
            return await result
        return result

    return AgentInstance(call_step=call_step)
