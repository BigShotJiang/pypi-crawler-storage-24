import dataclasses
from typing import Any, TypeAliasType, get_args, get_origin

from ...flow import CallAgent, CallStep, GotoAgent, GotoStep, Spawn, WhenAll, WhenAny, WhenN
from ..step_helpers import get_step_tag
from .type_helpers import get_type_hints

__all__ = ["build_type_registry", "collect_dataclass_types"]

_ACTION_TYPES = (GotoStep, GotoAgent, CallStep, CallAgent, Spawn, WhenAll, WhenAny, WhenN)


def collect_dataclass_types(typ: Any, registry: dict[str, type], seen: set[int] | None = None) -> None:
    """Recursively walk a type hint and register every dataclass type found."""
    if seen is None:
        seen = set()
    typ_id = id(typ)
    if typ_id in seen:
        return
    seen.add(typ_id)

    if isinstance(typ, TypeAliasType):
        collect_dataclass_types(typ.__value__, registry, seen)
        return

    origin = get_origin(typ)
    if origin is not None:
        for arg in get_args(typ):
            collect_dataclass_types(arg, registry, seen)
        return

    if not isinstance(typ, type):
        return

    if dataclasses.is_dataclass(typ) and not issubclass(typ, _ACTION_TYPES):
        tag = typ.__qualname__
        existing = registry.get(tag)
        if existing is not None and existing is not typ:
            raise ValueError(f"Duplicate type tag {tag!r}: {existing!r} vs {typ!r}")
        registry[tag] = typ


def build_type_registry(
    agent_cls: type,
    agent_spec_types: frozenset[type],
    agent_result_types: frozenset[type],
) -> dict[str, type]:
    """Collect all dataclass types needed for serialization."""
    registry: dict[str, type] = {}
    for klass in reversed(agent_cls.__mro__):
        for attr_name in vars(klass):
            val = getattr(klass, attr_name, None)
            if not callable(val):
                continue
            if get_step_tag(val) is None:
                continue
            for name, hint in get_type_hints(val).items():
                if name == "self":
                    continue
                collect_dataclass_types(hint, registry)
    for t in agent_spec_types:
        collect_dataclass_types(t, registry)
    for t in agent_result_types:
        collect_dataclass_types(t, registry)
    return registry
