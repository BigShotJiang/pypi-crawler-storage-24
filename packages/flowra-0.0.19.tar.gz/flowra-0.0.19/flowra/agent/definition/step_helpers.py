from collections.abc import Callable
from typing import Any

__all__ = [
    "StepRef",
    "get_step_tag",
    "resolve_step_ref",
    "set_agent_class",
    "set_step_tag",
]

_STEP_TAG_ATTR = "__step_tag__"
_AGENT_CLASS_ATTR = "__agent_class__"

type StepRef = str | Callable[..., Any]


def get_step_tag(fn: Callable[..., Any]) -> str | None:
    return getattr(fn, _STEP_TAG_ATTR, None)


def set_step_tag(fn: Callable[..., Any], tag: str) -> None:
    setattr(fn, _STEP_TAG_ATTR, tag)


def set_agent_class(fn: Callable[..., Any], cls: type) -> None:
    setattr(fn, _AGENT_CLASS_ATTR, cls)


def resolve_step_ref(ref: StepRef) -> str:
    if isinstance(ref, str):
        return ref
    func = getattr(ref, "__func__", ref)
    tag = get_step_tag(func)
    if tag is None:
        raise TypeError(f"{ref!r} is not a @step-decorated method")
    return tag
