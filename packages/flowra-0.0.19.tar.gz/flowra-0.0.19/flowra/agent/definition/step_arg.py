"""Annotated markers for step parameter binding.

Usage::

    from flowra.agent import step_arg

    @step
    async def finish(
        self,
        r1: Annotated[ResearchResult | None, step_arg.CHILD("r1")],
        results: Annotated[list[SubResult], step_arg.CHILD],
        spec: Annotated[ChatSpec, step_arg.SPEC],
    ) -> RaceResult: ...
"""

__all__ = [
    "CHILD",
    "SPEC",
]


class _Child:
    __slots__ = ("tag",)

    def __init__(self, tag: str | None = None) -> None:
        self.tag = tag

    def __call__(self, tag: str) -> "_Child":
        return _Child(tag)


SPEC = object()
CHILD = _Child()
