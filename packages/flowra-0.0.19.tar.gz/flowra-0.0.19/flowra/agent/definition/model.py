import dataclasses
from typing import Any, ClassVar, Protocol

from ..services import ServiceLocator

__all__ = [
    "AbstractAgent",
    "AgentDefinition",
    "AgentDefinitionRef",
    "AgentInstance",
    "AgentRef",
    "CallStepHandler",
    "ChildOutput",
    "CreateInstance",
    "StepMeta",
]


class AbstractAgent:
    __slots__ = ()
    __agent_definition__: ClassVar["AgentDefinition"]


type AgentRef = str | type[AbstractAgent]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ChildOutput:
    result: Any
    tag: str | None = None


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class StepMeta:
    spec_types: frozenset[type] = frozenset()
    result_types: frozenset[type] = frozenset()


class CallStepHandler(Protocol):
    async def __call__(
        self,
        tag: str,
        spec: Any | None = None,
        child_outputs: list[ChildOutput] | None = None,
    ) -> Any: ...


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class AgentInstance:
    call_step: CallStepHandler


class CreateInstance(Protocol):
    def __call__(self, sl: ServiceLocator, agent_spec: Any | None = None) -> AgentInstance: ...


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class AgentDefinition:
    steps: dict[str, StepMeta]
    type_registry: dict[str, type]
    create_instance: CreateInstance
    entry_step: str
    subagents: "dict[str, AgentDefinitionRef]" = dataclasses.field(default_factory=dict)
    spec_types: frozenset[type] = frozenset()
    result_types: frozenset[type] = frozenset()
    source_type: "type[AbstractAgent] | None" = None


type AgentDefinitionRef = AgentDefinition | type[AbstractAgent]
