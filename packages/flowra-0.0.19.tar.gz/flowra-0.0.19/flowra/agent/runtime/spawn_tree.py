"""Spawn tree: types, build/serialize, and satisfaction algorithm.

Determines which children are needed/unneeded based on WhenAll/WhenAny/WhenN strategies.
"""

import asyncio
import dataclasses
from typing import Any

from ..flow import CallAgent, CallStep, Interrupted, SpawnNode, WhenAll, WhenAny, WhenN

__all__ = [
    "SpawnTreeAll",
    "SpawnTreeAny",
    "SpawnTreeLeaf",
    "SpawnTreeN",
    "SpawnTreeNode",
    "build_spawn_tree",
    "collect_needed_indices",
    "deserialize_spawn_tree",
    "interrupt_unneeded_from_tasks",
    "is_tree_satisfied",
    "satisfied_set_from_children",
    "satisfied_set_from_tasks",
    "serialize_spawn_tree",
]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class SpawnTreeLeaf:
    child_index: int


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class SpawnTreeAll:
    nodes: tuple["SpawnTreeNode", ...]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class SpawnTreeAny:
    nodes: tuple["SpawnTreeNode", ...]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class SpawnTreeN:
    nodes: tuple["SpawnTreeNode", ...]
    n: int


type SpawnTreeNode = SpawnTreeLeaf | SpawnTreeAll | SpawnTreeAny | SpawnTreeN


def build_spawn_tree(node: SpawnNode, index_counter: list[int]) -> SpawnTreeNode:
    match node:
        case CallStep() | CallAgent():
            idx = index_counter[0]
            index_counter[0] += 1
            return SpawnTreeLeaf(child_index=idx)
        case WhenAll(nodes=nodes):
            return SpawnTreeAll(nodes=tuple(build_spawn_tree(node, index_counter) for node in nodes))
        case WhenAny(nodes=nodes):
            return SpawnTreeAny(nodes=tuple(build_spawn_tree(node, index_counter) for node in nodes))
        case WhenN(nodes=nodes, n=n):
            return SpawnTreeN(nodes=tuple(build_spawn_tree(node, index_counter) for node in nodes), n=n)


def serialize_spawn_tree(tree: SpawnTreeNode) -> dict[str, Any]:
    match tree:
        case SpawnTreeLeaf(child_index=idx):
            return {"type": "leaf", "child_index": idx}
        case SpawnTreeAll(nodes=nodes):
            return {"type": "all", "nodes": [serialize_spawn_tree(n) for n in nodes]}
        case SpawnTreeAny(nodes=nodes):
            return {"type": "any", "nodes": [serialize_spawn_tree(n) for n in nodes]}
        case SpawnTreeN(nodes=nodes, n=n):
            return {"type": "n", "nodes": [serialize_spawn_tree(nd) for nd in nodes], "n": n}


def deserialize_spawn_tree(data: dict[str, Any]) -> SpawnTreeNode:
    match data["type"]:
        case "leaf":
            return SpawnTreeLeaf(child_index=data["child_index"])
        case "all":
            return SpawnTreeAll(nodes=tuple(deserialize_spawn_tree(n) for n in data["nodes"]))
        case "any":
            return SpawnTreeAny(nodes=tuple(deserialize_spawn_tree(n) for n in data["nodes"]))
        case "n":
            return SpawnTreeN(nodes=tuple(deserialize_spawn_tree(nd) for nd in data["nodes"]), n=data["n"])
        case _:
            msg = f"Unknown spawn tree type: {data['type']!r}"
            raise TypeError(msg)


def satisfied_set_from_children(children: "list[_ExecutionNode]") -> set[int]:
    """Build set of child indices that completed with real (non-Interrupted) results."""
    from .execution import ExecutionStatus

    return {
        i
        for i, c in enumerate(children)
        if c.status == ExecutionStatus.COMPLETED and not isinstance(c.result, Interrupted)
    }


def satisfied_set_from_tasks(parent: "_ExecutionNode", task_map: dict[int, asyncio.Task[Any]]) -> set[int]:
    """Build set of child indices satisfied so far (from tasks and already-COMPLETED nodes)."""
    from .execution import ExecutionStatus

    assert parent.children is not None
    satisfied: set[int] = set()
    for i, child in enumerate(parent.children):
        if child.status == ExecutionStatus.COMPLETED and not isinstance(child.result, Interrupted):
            satisfied.add(i)
        elif i in task_map:
            task = task_map[i]
            if task.done() and not task.cancelled():
                try:
                    result = task.result()
                    if not isinstance(result, Interrupted):
                        satisfied.add(i)
                except Exception:
                    pass
    return satisfied


def is_tree_satisfied(tree: SpawnTreeNode, satisfied: set[int]) -> bool:
    match tree:
        case SpawnTreeLeaf(child_index=idx):
            return idx in satisfied
        case SpawnTreeAll(nodes=nodes):
            return all(is_tree_satisfied(n, satisfied) for n in nodes)
        case SpawnTreeAny(nodes=nodes):
            return any(is_tree_satisfied(n, satisfied) for n in nodes)
        case SpawnTreeN(nodes=nodes, n=n):
            return sum(1 for nd in nodes if is_tree_satisfied(nd, satisfied)) >= n


def collect_needed_indices(tree: SpawnTreeNode, satisfied: set[int]) -> set[int]:
    result: set[int] = set()
    _collect_needed(tree, satisfied, result)
    return result


def _collect_needed(tree: SpawnTreeNode, satisfied: set[int], out: set[int]) -> None:
    match tree:
        case SpawnTreeLeaf(child_index=idx):
            if idx in satisfied:
                out.add(idx)
        case SpawnTreeAll(nodes=nodes):
            for n in nodes:
                _collect_needed(n, satisfied, out)
        case SpawnTreeAny(nodes=nodes):
            for n in nodes:
                if is_tree_satisfied(n, satisfied):
                    _collect_needed(n, satisfied, out)
                    return
            for n in nodes:
                _collect_needed(n, satisfied, out)
        case SpawnTreeN(nodes=nodes, n=n):
            count = 0
            for nd in nodes:
                if count < n and is_tree_satisfied(nd, satisfied):
                    _collect_needed(nd, satisfied, out)
                    count += 1
            if count < n:
                for nd in nodes:
                    if not is_tree_satisfied(nd, satisfied):
                        _collect_needed(nd, satisfied, out)


def interrupt_unneeded_from_tasks(parent: "_ExecutionNode", task_map: dict[int, asyncio.Task[Any]]) -> None:
    """Done-callback: interrupt unneeded children when spawn tree is satisfied mid-execution."""
    if parent.spawn_tree is None or parent.children is None:
        return
    satisfied = satisfied_set_from_tasks(parent, task_map)
    if not is_tree_satisfied(parent.spawn_tree, satisfied):
        return
    needed = collect_needed_indices(parent.spawn_tree, satisfied)
    for i, child in enumerate(parent.children):
        if i not in needed and child.interrupt_source is not None:
            child.interrupt_source.interrupt()


# Type alias for forward reference — avoids circular import with execution.py
type _ExecutionNode = Any
