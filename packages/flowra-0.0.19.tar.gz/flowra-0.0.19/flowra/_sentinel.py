from typing import Final


class Unset:
    """Sentinel type for distinguishing 'not provided' from ``None``."""

    __slots__ = ()

    def __repr__(self) -> str:
        return "UNSET"


UNSET: Final = Unset()
"""Singleton sentinel value. Use ``isinstance(x, Unset)`` to check."""
