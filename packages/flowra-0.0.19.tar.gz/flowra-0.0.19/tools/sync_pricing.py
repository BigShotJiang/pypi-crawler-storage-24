#!/usr/bin/env python3
"""Sync LLM pricing tables from litellm's model_prices_and_context_window.json.

Usage:
    python tools/sync_pricing.py           # show diff only
    python tools/sync_pricing.py --apply   # update pricing files

Fetches the latest pricing data from litellm's GitHub repository and compares
with our local pricing tables. With --apply, rewrites the pricing files.
"""

import json
import sys
import urllib.request
from dataclasses import dataclass
from pathlib import Path

LITELLM_URL = "https://raw.githubusercontent.com/BerriAI/litellm/main/model_prices_and_context_window.json"

PRICING_DIR = Path(__file__).parent.parent / "flowra" / "llm" / "pricing"


@dataclass(frozen=True, slots=True, kw_only=True)
class OpenAIPrice:
    input: float
    output: float
    cache_read: float


@dataclass(frozen=True, slots=True, kw_only=True)
class AnthropicPrice:
    input: float
    output: float
    cache_read: float
    cache_creation_5m: float
    cache_creation_1h: float


@dataclass(frozen=True, slots=True, kw_only=True)
class GooglePrice:
    input: float
    output: float
    cache_read: float


def fetch_litellm() -> dict:
    with urllib.request.urlopen(LITELLM_URL) as resp:
        return json.loads(resp.read())


def per_m(cost_per_token: float | None) -> float:
    if cost_per_token is None:
        return 0.0
    return round(cost_per_token * 1_000_000, 6)


def extract_openai(data: dict, key: str) -> OpenAIPrice | None:
    entry = data.get(key)
    if entry is None or entry.get("litellm_provider") != "openai":
        return None
    return OpenAIPrice(
        input=per_m(entry.get("input_cost_per_token")),
        output=per_m(entry.get("output_cost_per_token")),
        cache_read=per_m(entry.get("cache_read_input_token_cost")),
    )


def extract_anthropic(data: dict, key: str) -> AnthropicPrice | None:
    entry = data.get(key)
    if entry is None:
        return None
    provider = entry.get("litellm_provider", "")
    if "anthropic" not in provider:
        return None
    return AnthropicPrice(
        input=per_m(entry.get("input_cost_per_token")),
        output=per_m(entry.get("output_cost_per_token")),
        cache_read=per_m(entry.get("cache_read_input_token_cost")),
        cache_creation_5m=per_m(entry.get("cache_creation_input_token_cost")),
        cache_creation_1h=per_m(entry.get("cache_creation_input_token_cost_above_1hr")),
    )


def extract_google(data: dict, key: str) -> GooglePrice | None:
    entry = data.get(key)
    if entry is None:
        return None
    provider = entry.get("litellm_provider", "")
    if "vertex" not in provider:
        return None
    return GooglePrice(
        input=per_m(entry.get("input_cost_per_token")),
        output=per_m(entry.get("output_cost_per_token")),
        cache_read=per_m(entry.get("cache_read_input_token_cost")),
    )


def parse_current_openai() -> list[tuple[str, OpenAIPrice]]:
    """Parse current openai.py pricing table."""
    text = (PRICING_DIR / "openai.py").read_text()
    results = []
    for line in text.splitlines():
        line = line.strip()
        if line.startswith('("') and "_ModelPricing(" in line:
            key = line.split('"')[1]
            nums = line.split("_ModelPricing(")[1].rstrip("),").split(",")
            nums = [float(n.strip()) for n in nums]
            results.append((key, OpenAIPrice(input=nums[0], output=nums[1], cache_read=nums[2])))
    return results


def parse_current_anthropic() -> list[tuple[str, AnthropicPrice]]:
    """Parse current anthropic.py pricing table."""
    text = (PRICING_DIR / "anthropic.py").read_text()
    results = []
    for line in text.splitlines():
        line = line.strip()
        if line.startswith('("') and "_ModelPricing(" in line:
            key = line.split('"')[1]
            nums = line.split("_ModelPricing(")[1].rstrip("),").split(",")
            nums = [float(n.strip()) for n in nums]
            results.append((key, AnthropicPrice(
                input=nums[0], output=nums[1], cache_read=nums[2],
                cache_creation_5m=nums[3], cache_creation_1h=nums[4],
            )))
    return results


def parse_current_google() -> list[tuple[str, GooglePrice]]:
    """Parse current google.py pricing table."""
    text = (PRICING_DIR / "google.py").read_text()
    results = []
    for line in text.splitlines():
        line = line.strip()
        if line.startswith('("') and "_ModelPricing(" in line:
            key = line.split('"')[1]
            nums = line.split("_ModelPricing(")[1].rstrip("),").split(",")
            nums = [float(n.strip()) for n in nums]
            results.append((key, GooglePrice(input=nums[0], output=nums[1], cache_read=nums[2])))
    return results


def fmt(val: float) -> str:
    s = f"{val:.6g}"
    return s


def compare_openai(data: dict) -> list[tuple[str, OpenAIPrice, OpenAIPrice | None]]:
    """Compare current OpenAI prices with litellm. Returns list of (key, current, litellm)."""
    diffs = []
    for key, current in parse_current_openai():
        litellm = extract_openai(data, key)
        if litellm is None:
            diffs.append((key, current, None))
        elif (current.input != litellm.input or current.output != litellm.output
              or current.cache_read != litellm.cache_read):
            diffs.append((key, current, litellm))
    return diffs


def compare_anthropic(data: dict) -> list[tuple[str, AnthropicPrice, AnthropicPrice | None]]:
    diffs = []
    for key, current in parse_current_anthropic():
        litellm = extract_anthropic(data, key)
        if litellm is None:
            diffs.append((key, current, None))
        elif (current.input != litellm.input or current.output != litellm.output
              or current.cache_read != litellm.cache_read
              or current.cache_creation_5m != litellm.cache_creation_5m
              or current.cache_creation_1h != litellm.cache_creation_1h):
            diffs.append((key, current, litellm))
    return diffs


def compare_google(data: dict) -> list[tuple[str, GooglePrice, GooglePrice | None]]:
    diffs = []
    for key, current in parse_current_google():
        litellm = extract_google(data, key)
        if litellm is None:
            diffs.append((key, current, None))
        elif (current.input != litellm.input or current.output != litellm.output
              or current.cache_read != litellm.cache_read):
            diffs.append((key, current, litellm))
    return diffs


def rewrite_openai(data: dict) -> None:
    path = PRICING_DIR / "openai.py"
    current = parse_current_openai()
    updated = []
    for key, price in current:
        litellm = extract_openai(data, key)
        updated.append((key, litellm if litellm is not None else price))

    lines = []
    for key, p in updated:
        lines.append(f'    ("{key}", _ModelPricing({fmt(p.input)}, {fmt(p.output)}, {fmt(p.cache_read)})),')

    text = path.read_text()
    start = text.index("_PRICING: list[tuple[str, _ModelPricing]] = [")
    end = text.index("\n]", start) + 2

    before = text[:start]
    after = text[end:]

    # Rebuild with comments preserved
    new_table = "_PRICING: list[tuple[str, _ModelPricing]] = [\n"
    in_mercury = False
    for key, p in updated:
        if key == "mercury-coder" and not in_mercury:
            new_table += "    # Mercury (Inception)\n"
            in_mercury = True
        elif key == "gpt-4.1-mini" and not in_mercury:
            new_table += "    # OpenAI\n"
        new_table += f'    ("{key}", _ModelPricing({fmt(p.input)}, {fmt(p.output)}, {fmt(p.cache_read)})),\n'
    new_table += "]"

    path.write_text(before + new_table + after)


def rewrite_anthropic(data: dict) -> None:
    path = PRICING_DIR / "anthropic.py"
    current = parse_current_anthropic()
    updated = []
    for key, price in current:
        litellm = extract_anthropic(data, key)
        updated.append((key, litellm if litellm is not None else price))

    text = path.read_text()
    start = text.index("_PRICING: list[tuple[str, _ModelPricing]] = [")
    end = text.index("\n]", start) + 2

    before = text[:start]
    after = text[end:]

    new_table = "_PRICING: list[tuple[str, _ModelPricing]] = [\n"
    for key, p in updated:
        new_table += (
            f'    ("{key}", _ModelPricing('
            f'{fmt(p.input)}, {fmt(p.output)}, {fmt(p.cache_read)}, '
            f'{fmt(p.cache_creation_5m)}, {fmt(p.cache_creation_1h)})),\n'
        )
    new_table += "]"

    path.write_text(before + new_table + after)


def rewrite_google(data: dict) -> None:
    path = PRICING_DIR / "google.py"
    current = parse_current_google()
    updated = []
    for key, price in current:
        litellm = extract_google(data, key)
        updated.append((key, litellm if litellm is not None else price))

    text = path.read_text()
    start = text.index("_PRICING: list[tuple[str, _ModelPricing]] = [")
    end = text.index("\n]", start) + 2

    before = text[:start]
    after = text[end:]

    new_table = "_PRICING: list[tuple[str, _ModelPricing]] = [\n"
    for key, p in updated:
        new_table += f'    ("{key}", _ModelPricing({fmt(p.input)}, {fmt(p.output)}, {fmt(p.cache_read)})),\n'
    new_table += "]"

    path.write_text(before + new_table + after)


def main() -> None:
    apply = "--apply" in sys.argv

    print("Fetching litellm pricing data...")
    data = fetch_litellm()
    print(f"Loaded {len(data)} models from litellm\n")

    any_diff = False

    # OpenAI
    openai_diffs = compare_openai(data)
    if openai_diffs:
        any_diff = True
        print("=== OpenAI ===")
        for key, current, litellm in openai_diffs:
            if litellm is None:
                print(f"  {key}: NOT IN LITELLM (keeping current)")
            else:
                print(f"  {key}:")
                if current.input != litellm.input:
                    print(f"    input:      ${fmt(current.input)} → ${fmt(litellm.input)}")
                if current.output != litellm.output:
                    print(f"    output:     ${fmt(current.output)} → ${fmt(litellm.output)}")
                if current.cache_read != litellm.cache_read:
                    print(f"    cache_read: ${fmt(current.cache_read)} → ${fmt(litellm.cache_read)}")
        print()

    # Anthropic
    anthropic_diffs = compare_anthropic(data)
    if anthropic_diffs:
        any_diff = True
        print("=== Anthropic ===")
        for key, current, litellm in anthropic_diffs:
            if litellm is None:
                print(f"  {key}: NOT IN LITELLM (keeping current)")
            else:
                print(f"  {key}:")
                if current.input != litellm.input:
                    print(f"    input:            ${fmt(current.input)} → ${fmt(litellm.input)}")
                if current.output != litellm.output:
                    print(f"    output:           ${fmt(current.output)} → ${fmt(litellm.output)}")
                if current.cache_read != litellm.cache_read:
                    print(f"    cache_read:       ${fmt(current.cache_read)} → ${fmt(litellm.cache_read)}")
                if current.cache_creation_5m != litellm.cache_creation_5m:
                    print(f"    cache_creation_5m: ${fmt(current.cache_creation_5m)} → ${fmt(litellm.cache_creation_5m)}")
                if current.cache_creation_1h != litellm.cache_creation_1h:
                    print(f"    cache_creation_1h: ${fmt(current.cache_creation_1h)} → ${fmt(litellm.cache_creation_1h)}")
        print()

    # Google
    google_diffs = compare_google(data)
    if google_diffs:
        any_diff = True
        print("=== Google ===")
        for key, current, litellm in google_diffs:
            if litellm is None:
                print(f"  {key}: NOT IN LITELLM (keeping current)")
            else:
                print(f"  {key}:")
                if current.input != litellm.input:
                    print(f"    input:      ${fmt(current.input)} → ${fmt(litellm.input)}")
                if current.output != litellm.output:
                    print(f"    output:     ${fmt(current.output)} → ${fmt(litellm.output)}")
                if current.cache_read != litellm.cache_read:
                    print(f"    cache_read: ${fmt(current.cache_read)} → ${fmt(litellm.cache_read)}")
        print()

    if not any_diff:
        print("All prices match litellm. No changes needed.")
        return

    if not apply:
        print("Run with --apply to update pricing files.")
        return

    print("Applying changes...")
    if openai_diffs:
        rewrite_openai(data)
        print("  Updated flowra/llm/pricing/openai.py")
    if anthropic_diffs:
        rewrite_anthropic(data)
        print("  Updated flowra/llm/pricing/anthropic.py")
    if google_diffs:
        rewrite_google(data)
        print("  Updated flowra/llm/pricing/google.py")
    print("Done. Run tests to verify: make test name=pricing")


if __name__ == "__main__":
    main()
