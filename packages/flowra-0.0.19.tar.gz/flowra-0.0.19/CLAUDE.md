# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

**This is a pre-1.0 library in active development (0.0.x). Never worry about breaking changes, backward compatibility, or migration. Just make the change.**

## Commands

- `make deps` — install dependencies (`uv sync`; in CI with `MODE=ci` uses `--locked --no-cache`)
- `make lock` — upgrade all dependencies (`uv lock --upgrade`)
- `make lint` — ruff check + ruff format + pyright (auto-fixes locally; in CI with `MODE=ci` checks only)
- `make test` — run all tests in parallel (`-n auto`)
- `make test name="some_name"` — filter tests by name (`-k`)
- `make test parallel=0` — run tests sequentially
- `make test args="-vv"` — pass extra pytest arguments
- `make check` — lint + test
- `make example1` — run menu agent (functional style)
- `make example2` — run menu agent (class-based style)
- `make chat` — run interactive console chat example
- `make chat resume=last` — resume the last chat session
- `make chat resume=<session_id>` — resume a specific session
- `make chat input="..."` — send a single message (batch mode)
- `make chat crash=0.5 input="..."` — crash recovery demo
- `make chat-tui` — run TUI chat with interrupt support
- `make chat-tui resume=last` — resume the last TUI session
- `make race` — run race example (two LLMs answer the same question, first wins)
- `make race model1=... model2=... question="..." timeout=10` — race with custom params

## Environment

A `.env` file in the project root contains real LLM provider credentials (API keys, project IDs, etc.). The Makefile loads it automatically. All examples and E2E tests use these credentials — don't say you can't run something because of missing credentials, just run it.

## Architecture

Python 3.12+ library. Package manager: **uv**. All config in `pyproject.toml`.

### LLM abstraction (`flowra/llm/`)

Provider-agnostic interface for calling LLMs:

- `LLMProvider` (abc) — `async call(LLMRequest) -> LLMResponse` and `async stream(LLMRequest) -> AsyncIterator[StreamEvent]`
- `LLMRequest` — model, system (`list[SystemMessage]`), messages (`list[UserMessage | AssistantMessage]`), tools, json_schema, temperature, max_tokens, stop_sequences, additional_config, max_schema_retries
- `LLMResponse` — message (AssistantMessage), stop_reason, usage
- `StreamEvent` = `TextDelta | ThinkingDelta | ContentComplete` — stream events for real-time token delivery
- `Usage` — input_tokens, output_tokens, cache_read_input_tokens, cache_creation_input_tokens, cost_usd, cost (`CostBreakdown` with input/output/cache_read/cache_creation). Token contract: `input_tokens` excludes cached tokens
- Messages: `SystemMessage`, `UserMessage`, `AssistantMessage` — system messages are separate in `LLMRequest.system`
- Blocks: `TextBlock`, `ImageBlock`, `ToolUseBlock`, `ToolResultBlock`, `ThinkingBlock` — all inherit `LLMData` (metadata, extra, transient)
- `Tool` — inherits from `LLMData` (has metadata, extra, transient). Fields: name, description, input_schema, output_schema
- Span types: `LLMCallSpan` (request + response), `ToolCallSpan` (tool_use + result) — mutable, for observability via span-hooks

Providers live in `flowra/llm/providers/`. Currently: `AnthropicVertexProvider`, `OpenAIProvider`, `GoogleVertexProvider`.

Pricing utilities live in `flowra/llm/pricing/` — per-protocol cost estimation (anthropic, openai, google). Providers use these to populate `Usage.cost_usd` and `Usage.cost` (`CostBreakdown`).

### Flowing context (`flowra/agent/flow/flowing.py`)

`FlowingContextVar[T]` — typed variables that flow with agent execution. The engine manages lifecycle (fork/restore for sibling isolation, snapshot/apply for task inheritance). All instances share one `ContextVar[dict]` internally. Used by MLflow and OTel integrations for parent span tracking.

### Tracing integrations (`flowra/ext/`)

- `flowra/ext/mlflow.py` — MLflow tracing via span-hooks. Uses `FlowingContextVar` for parent tracking, MLflow's `set_span_in_context` for W3C propagation. OpenAI-format chat messages for MLflow UI.
- `flowra/ext/otel.py` — OpenTelemetry tracing with GenAI semantic conventions. Uses `FlowingContextVar` for parent tracking. Users configure their own `TracerProvider`.

## Code Review

Review prompts live in `docs/review_prompts/`:

- `step1_structure.md` — package structure and responsibility
- `step2_code_style.md` — code style rules (**canonical source of all style rules**)
- `step3_documentation.md` — documentation completeness and quality
- `step4_doc_readability.md` — documentation readability (as a first-time reader)
- `step5_doc_audit.md` — documentation audit against source code
- `step6_tests.md` — test quality and coverage

### Tests

Test directory structure mirrors `flowra/`. E2E tests use `_e2e` suffix (e.g., `test_anthropic_e2e.py`). Environment variables loaded from `.env` via Makefile.

## Releases

CI workflow: `.github/workflows/publish.yml` (manual trigger via `workflow_dispatch`).

### Pre-release

No preparation needed. Tell the user to trigger the `publish` workflow with `type: pre-release` in GitHub Actions. Do NOT trigger it yourself. CI appends `.dev{run_number}` to the current version automatically.

### Release

**Preparation (manual):**

1. Check that `flowra/version.py` has the correct version (CI bumps it automatically after each release, so it should already be set)
2. Rename the `[Unreleased]` section in `CHANGELOG.md` to `[X.Y.Z] - YYYY-MM-DD` matching the version in `version.py`
3. Verify documentation is up to date with code changes (especially `docs/llm.md`, `docs/agent.md`, `context7.json`)
4. Run `make check` — lint + all tests must pass
5. Commit, push to `master`

**Publishing:**

Tell the user to trigger the `publish` workflow manually in GitHub Actions. Do NOT trigger it yourself.

CI (`type: release`) will:
- Validate that the branch is `master`
- Validate that `CHANGELOG.md` has a section matching the version
- Run lint + tests
- Build and publish to PyPI
- Create git tag `v{version}` and GitHub Release
- Bump version for next cycle (patch increment) and add `[Unreleased]` section
- Push the version bump commit to `master`

**Do NOT** create git tags manually — CI handles this.

## Maintenance

- **`context7.json`** — project description for [Context7](https://context7.com). Must be updated when adding new features, changing public APIs, or modifying architecture. Keep rules in sync with actual capabilities.
