# Model Fallback on Tool Call Failure — Research (March 2026)

Research date: 2026-03-22

## Problem

When using a weak/fast model (e.g. Claude Haiku, Gemini Flash Lite) for tool
calling, the model occasionally produces invalid tool calls:
- Malformed JSON in `tool_use.input`
- Wrong argument types or missing required fields
- Calling a non-existent tool name
- Invalid function call structure (Gemini's `MALFORMED_FUNCTION_CALL`)

The cheap model handles 95% of cases correctly, but the 5% failure rate is
unacceptable in production. Currently, failures are returned as error
`ToolResultBlock`s to the LLM, which often leads to repeated failures on the
same tool.

## Goal

Automatically escalate to a stronger model when a tool call fails, without
changing the agent's code. The user configures a fallback model, and the system
handles retry transparently.

## Current architecture (what exists)

### Tool execution flow

1. `ToolLoopAgent.call_llm()` sends `LLMRequest` to the provider
2. Provider returns `LLMResponse` with `stop_reason=TOOL_USE` and `ToolUseBlock`s
3. `ToolLoopAgent` spawns `ToolCallAgent` for each `ToolUseBlock`
4. `ToolCallAgent.execute()` calls `ToolRegistry.execute(name, input)`
5. `ToolRegistry.execute()` catches exceptions, returns `ToolResult(is_error=True)`
6. `ToolCallAgent` wraps result into `ToolResultBlock` and returns `ToolCallResult`
7. `ToolLoopAgent.collect_results()` fires `AfterToolCallEvent` for each result
8. Error results are appended to turn messages and sent back to LLM

### Where failures are detected

| Failure type | Where detected | How reported |
|---|---|---|
| Unknown tool name | `ToolCallAgent.execute()` line 84 | `ToolCallResult(is_error=True, content="Unknown tool: X")` |
| Tool handler exception | `ToolRegistry.execute()` line 131 | `ToolResult(is_error=True, content="Error: ...")` |
| Schema validation error | Not validated — tool handler receives raw dict | Depends on handler implementation |
| Malformed JSON from LLM | Provider parses it — usually arrives as valid dict | Not an issue at tool level |
| Interrupt during execution | `ToolCallAgent.execute()` line 95 | `ToolCallResult(is_error=True, content="interrupted")` |

**Key insight:** There is no tool input schema validation step. The LLM's
`tool_use.input` dict is passed directly to the tool handler without checking
it against `tool.input_schema`. Validation happens (or doesn't) inside each
tool handler.

### Existing hooks and extension points

- **`BeforeToolCallEvent`** — fired before each tool execution. Mutable field:
  `tool_use`. Handler can replace the `ToolUseBlock` (sanitize input, inject
  defaults). Could be used to validate input against schema before execution.

- **`AfterToolCallEvent`** — fired after each tool execution. Mutable fields:
  `result`, `additional_messages`. Handler can replace the result or inject
  messages. Could be used to detect errors and trigger retry logic.

- **`PrepareLLMRequestEvent`** — fired before each LLM call. Mutable field:
  `request`. Handler can replace the entire `LLMRequest` (change model,
  messages, tools).

- **`ConfigValue[LLMConfig]`** — `ToolLoopConfig.llm_config` is a `ConfigValue`
  (can be a callable). Model can be switched dynamically between iterations.
  But this is per-iteration, not per-tool-call.

- **`max_consecutive_errors`** — `ToolLoopConfig` has this field. After N
  consecutive errors on the same tool, the agent sends a "try a different
  approach" message instead of the error. This is a blunt instrument.

### JSON schema validation in providers

The Anthropic provider has a retry loop for `json_schema` validation (structured
output), but this is for the LLM's text response, not for tool call input. The
pattern is instructive:

1. LLM responds with text
2. Provider validates against `json_schema`
3. On failure, appends the error to messages and retries with the same model
4. After `max_schema_retries`, returns `SCHEMA_VALIDATION_FAILED`

This pattern (validate → feedback → retry) could inspire the fallback design,
but at the tool call level instead of the response level.

## Design options

### Option A: Hook-based (AfterToolCallEvent)

A hook bundle (like `AnthropicCacheAllMessages`) that:
1. Subscribes to `AfterToolCallEvent`
2. When `result.is_error` is True, checks if it's a retryable error
3. Somehow triggers a retry with a different model

**Problem:** `AfterToolCallEvent` can modify the result and inject messages,
but it cannot:
- Re-execute the tool call with corrected input
- Switch the model for the next iteration only
- Trigger an immediate retry (the flow continues to the next iteration)

The handler could modify `ToolLoopAgentContext` to signal a model switch,
but this requires the `LLMConfig` callable to check that signal — coupling.

### Option B: Pre-validation in BeforeToolCallEvent

A hook that:
1. Subscribes to `BeforeToolCallEvent`
2. Validates `tool_use.input` against `tool.input_schema` (from the registry)
3. If invalid, replaces `tool_use` with a corrected version (but how?)

**Problem:** The hook doesn't have access to a "better model" to fix the input.
It can only validate and reject, not fix.

### Option C: Provider-level retry (LLMProvider wrapper)

Wrap the LLM provider with a fallback decorator:

```python
class FallbackProvider(LLMProvider):
    def __init__(self, primary: LLMProvider, fallback: LLMProvider):
        ...

    async def call(self, request: LLMRequest) -> LLMResponse:
        response = await self.__primary.call(request)
        if self.__should_retry(response):
            return await self.__fallback.call(request)
        return response
```

**Problem:** The provider doesn't know if a tool call will fail — it only sees
the LLM's response with `ToolUseBlock`s. It can't validate tool input against
schemas (it doesn't have access to the tool registry). And retrying the whole
LLM call is wasteful — only one tool out of many might have failed.

### Option D: New hook point — `ToolCallValidationFailedEvent`

Add input validation to `ToolCallAgent` (or `ToolLoopAgent`) and a new event:

1. Before executing a tool, validate `tool_use.input` against `tool.input_schema`
2. If validation fails, fire `ToolCallValidationFailedEvent`
3. The handler can:
   - Request retry with the same model (append error feedback)
   - Request retry with a fallback model
   - Let it fail (default — current behavior, no validation)

**This is the most targeted approach** but requires:
- Adding schema validation to the tool execution path
- A new event type
- A mechanism to "retry this LLM call with a different model"

### Option E: Retry at the iteration level (recommended)

Instead of retrying individual tool calls, retry the entire LLM iteration with
a stronger model when any tool call fails:

1. After `collect_results`, check if any result has `is_error=True`
2. If yes, and a fallback model is configured, re-run `call_llm` with the
   fallback model (appending the error feedback)
3. If the fallback also fails, proceed normally (error goes back to LLM)

This can be implemented as:
- A `ConfigValue[LLMConfig]` that switches model after error (stateful callable)
- Or a new `ToolCallErrorStrategy` in `ToolLoopConfig`
- Or a hook-based extension like the caching bundles

**Implementation sketch using hooks:**

```python
class ModelFallback:
    def __init__(self, fallback_model: str):
        self.__fallback_model = fallback_model
        self.__use_fallback = False

    def install(self, hooks: HookSubscription):
        hooks.on(AfterToolCallEvent, self.on_after_tool_call)
        hooks.on(PrepareLLMRequestEvent, self.on_prepare)

    def on_after_tool_call(self, event):
        if event.data.result.is_error:
            self.__use_fallback = True

    def on_prepare(self, event):
        if self.__use_fallback:
            request = event.data.request
            event.data.request = dataclasses.replace(
                request,
                additional_config={**request.additional_config, "model": self.__fallback_model},
            )
            self.__use_fallback = False
```

**Problem with this sketch:** `additional_config` doesn't override `model` —
that's a separate field on `LLMRequest`. And the hook state (`__use_fallback`)
is shared across all tool calls in a turn, not per-tool. And the model is set
from `LLMConfig`, not from `LLMRequest.model` directly.

**Better approach:** use `PrepareLLMRequestEvent` to replace the model:

```python
def on_prepare(self, event):
    if self.__use_fallback:
        request = event.data.request
        event.data.request = dataclasses.replace(request, model=self.__fallback_model)
        self.__use_fallback = False
```

This works because `PrepareLLMRequestEvent` fires before every LLM call. After
tool errors, the next iteration's request gets the fallback model. After a
successful iteration, it resets to the primary model.

**Limitation:** retries the entire LLM call, not just the failed tool. But in
practice, the cost of one extra LLM call on a stronger model is acceptable —
the alternative is a failed interaction.

## Recommendation

**Start with Option E (iteration-level retry via hooks).** It's:
- Simple — ~30 lines of code
- Composable — same `install(hooks)` pattern as caching/tool search
- No core changes — works with existing `PrepareLLMRequestEvent`
- Stateful but scoped — state resets each iteration

**Future enhancement:** Option D (tool input validation + targeted retry) is
more precise but requires core changes. Keep it as a follow-up if Option E
proves insufficient.

## Open questions

1. **Should the fallback be per-tool or per-iteration?** Option E retries the
   whole iteration. If only one tool out of five failed, the other four get
   re-executed too. Is this acceptable?

2. **How many retries?** One retry on the fallback model? Or N retries with
   escalating models (fast → medium → strong)?

3. **What counts as "retryable"?** Any `is_error=True`? Or specific error
   patterns (schema validation, unknown tool, etc.)?

4. **Should we add tool input validation?** Currently there is none. Adding
   `jsonschema.validate(tool_use.input, tool.input_schema)` before execution
   would catch malformed input before the tool handler runs. This is useful
   independently of fallback.

5. **State management.** The hook holds mutable state (`__use_fallback`). In
   parallel tool execution (multiple `ToolCallAgent`s), `AfterToolCallEvent`
   fires for each. The flag should be set if ANY tool fails. Since events
   fire sequentially in `collect_results`, this works — but needs careful
   testing.

## Building blocks summary

| What exists | How it helps |
|---|---|
| `PrepareLLMRequestEvent` | Replace `request.model` before LLM call |
| `AfterToolCallEvent` | Detect tool failures, set fallback flag |
| `ConfigValue[LLMConfig]` | Alternative: dynamic model via callable |
| `max_consecutive_errors` | Existing blunt retry mechanism |
| `ToolCallSpan` | Observability for tool call errors |
| `install(hooks)` pattern | Composable, same as caching/tool search |
