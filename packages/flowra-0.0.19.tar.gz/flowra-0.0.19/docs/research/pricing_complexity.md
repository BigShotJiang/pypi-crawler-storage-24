# LLM Pricing Complexity — Research (March 2026)

Research date: 2026-03-18

## Problem

Our pricing is a flat table `(model_key → input, output, cache_read)` per API protocol.
Real LLM pricing is significantly more complex.

## Dimensions that affect price

### 1. Access provider

The same model costs differently depending on how you access it:

| Model | Direct API | Vertex AI | Bedrock | Azure |
|---|---|---|---|---|
| Claude Sonnet 4.6 | $3/$15 | different | different | N/A |
| GPT-4o | $2.50/$10 | N/A | N/A | different |
| Gemini 2.5 Pro | N/A | $1.25/$10 | N/A | N/A |

litellm tracks this — each model has separate entries per provider:
- `claude-sonnet-4-6` (litellm_provider: "anthropic")
- `vertex_ai/claude-sonnet-4-6` (litellm_provider: "vertex_ai")
- `bedrock/anthropic.claude-sonnet-4-6` (litellm_provider: "bedrock")

### 2. Context length tiers

Anthropic and Google charge more for long contexts:

**Anthropic (>200k tokens):**
- Input: 2x base price
- Output: 1.5x base price
- Cache read: 2x base price
- Cache creation: 2.5x base price

**Google Gemini 2.5 Pro (>200k tokens):**
- Input: 2x ($1.25 → $2.50)
- Output: 1.5x ($10 → $15)
- Cache read: 2x ($0.125 → $0.25)

litellm fields: `input_cost_per_token_above_200k_tokens`,
`output_cost_per_token_above_200k_tokens`, etc.

### 3. Cache creation TTL (Anthropic)

Anthropic has two cache creation tiers:
- 5-minute ephemeral: 1.25x input price
- 1-hour: 2x input price

litellm fields: `cache_creation_input_token_cost` (5m default),
`cache_creation_input_token_cost_above_1hr` (1h).

### 4. Thinking/reasoning tokens

Extended thinking tokens are billed at output rate for Anthropic.
OpenAI reasoning models (o1, o3, o4-mini) also bill reasoning tokens at output rate.
These are reported in `usage.extra` but not accounted for separately in our pricing.

### 5. Batch API discounts

OpenAI Batch API: 50% off input and output.
Google Batch: different rates.
Currently we don't track this.

## Data source: litellm

`https://raw.githubusercontent.com/BerriAI/litellm/main/model_prices_and_context_window.json`

2500+ model entries with fields:
- `input_cost_per_token`, `output_cost_per_token`
- `input_cost_per_token_above_200k_tokens`, `output_cost_per_token_above_200k_tokens`
- `cache_read_input_token_cost`, `cache_read_input_token_cost_above_200k_tokens`
- `cache_creation_input_token_cost`, `cache_creation_input_token_cost_above_1hr`
- `litellm_provider` — identifies the access provider

We already have `tools/sync_pricing.py` that fetches this file and compares with our
tables. Could be extended to generate our pricing modules automatically.

## Current state

`flowra/llm/pricing/` has three files keyed by API protocol:
- `anthropic.py` — `_ModelPricing(input, output, cache_read, cache_5m, cache_1h)`
- `openai.py` — `_ModelPricing(input, output, cache_read)`
- `google.py` — `_ModelPricing(input, output, cache_read)`

`CostBreakdown(input, output, cache_read, cache_creation)` returned by `estimate_cost()`.

Pricing is called by providers: `AnthropicVertexProvider` uses `anthropic_pricing`,
`OpenAIProvider` uses `openai_pricing`, `GoogleVertexProvider` uses `google_pricing`.

## Possible approaches

### A. Enrich existing tables with context tiers

Add `_above_200k` variants to `_ModelPricing`. `estimate_cost()` gets a
`total_input_tokens` parameter and picks the right tier. Providers pass
total token count.

Pros: minimal change. Cons: still flat per-protocol, doesn't handle provider differences.

### B. Auto-generate pricing from litellm

`tools/sync_pricing.py --generate` produces the pricing modules from litellm JSON.
Each `LLMProvider` declares its litellm provider key (e.g. `"vertex_ai"`).
Pricing lookup uses `(litellm_provider, model_name, token_count)`.

Pros: always up to date, handles provider differences. Cons: dependency on litellm
data format, need to map our providers to litellm keys.

### C. Let providers own their pricing entirely

Move `estimate_cost()` into `LLMProvider` as a method. Each provider knows its
access path and can compute cost accurately. Pricing tables become provider-internal.

Pros: most accurate. Cons: duplicates pricing logic across providers, harder to
keep up to date.

### D. Hybrid: litellm-generated data + provider context

Generate a pricing database from litellm at build/release time. Providers pass
their litellm key + model + token counts to a shared `estimate_cost()` that does
the full lookup including tiers.

This is probably the right long-term approach.
