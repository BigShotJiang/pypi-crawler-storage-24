# MLflow Context Migration — Research (March 2026)

Research date: 2026-03-22
Implemented: 2026-03-22

## Status: Implemented

Implemented via `FlowingContextVar` (see `flowing_context.md`). The MLflow
handler uses `_mlflow_parent: FlowingContextVar[LiveSpan | None]` for parent
tracking. The engine's fork/restore mechanism handles sibling isolation.

## Problem

`flowra/ext/mlflow.py` manually managed span parent-child relationships via a
hand-rolled `_current_parent: ContextVar[LiveSpan | None]`. This had three
consequences:

1. **Sibling bug.** When engine created Spawn children sequentially in the
   advance task, each child's `on_enter` mutated `_current_parent`, causing
   siblings to chain instead of being parallel under the same parent.

2. **Used internal MLflow API.** `InMemoryTraceManager` (from
   `mlflow.tracing.trace_manager`) was used to set trace previews because the
   public `mlflow.update_current_trace()` requires the fluent context stack.

3. **No distributed tracing propagation.** `get_tracing_context_headers_for_http_request()`
   returned empty because MLflow's context stack was never populated.

## Solution

### FlowingContextVar

A new `FlowingContextVar[T]` type (in `flowra/agent/flow/flowing.py`) — a typed
variable stored in a shared `ContextVar[dict]`. The engine manages the lifecycle:

- **fork** before each child creation (copies the dict)
- **restore** after (reverts to parent state — next sibling sees clean parent)
- **snapshot** after child creation (captures child's state)
- **apply** before `ensure_future` (seeds each asyncio task with correct state)

### MLflow handler

The handler became trivial:

```python
_mlflow_parent = FlowingContextVar[LiveSpan | None]("mlflow.parent_span", default=None)

def on_enter(agent_span):
    parent = _mlflow_parent.get()
    mlflow_span = create_span(parent_span=parent)
    _mlflow_parent.set(mlflow_span)
    context_token = set_span_in_context(mlflow_span)  # for MLflow's own context

    def on_exit():
        detach_span_from_context(context_token)
        mlflow_span.end()
```

### What was removed

- `_current_parent: ContextVar` — replaced by `FlowingContextVar`
- `_set_trace_preview()` — replaced by `mlflow.update_current_trace()`
- `InMemoryTraceManager` import — no longer needed
- `_span_registry` dict — no longer needed (FlowingContextVar handles isolation)

### What was added

- `set_span_in_context()` / `detach_span_from_context()` in all handlers — populates
  MLflow's context stack for `update_current_trace()` and W3C `traceparent` propagation
- `FlowingContextVar` mechanism in the engine

## Key insight: asyncio Tasks copy contextvars

The original concern was that `contextvars` break across asyncio tasks. This is
**incorrect**. `asyncio.create_task()` copies the current `contextvars.Context`
into the new Task. Each Task gets its own isolated copy. This is exactly the
behavior needed for span parent-child tracking.

The real problem was **sibling pollution in the advance task** — the engine
creates sibling children sequentially, and ContextVar mutations from one sibling
leaked to the next. The FlowingContextVar + engine fork/restore fixes this.
