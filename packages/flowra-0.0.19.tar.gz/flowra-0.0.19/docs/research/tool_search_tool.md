# Anthropic Tool Search Tool — Research (March 2026)

> **Note:** This research has been implemented as `AnthropicToolSearch` in
> `flowra.lib.anthropic.tool_search`. See `docs/lib/anthropic.md` for usage.

Research date: 2026-03-17
Source: https://platform.claude.com/docs/en/agents-and-tools/tool-use/tool-search-tool

## Problem

When an agent has 50+ tools, two compounding issues arise:

- **Context bloat.** Tool definitions consume context budget fast. A typical multi-server
  setup (GitHub, Slack, Sentry, Grafana, Splunk) can eat ~55k tokens in definitions alone.
- **Tool selection accuracy.** Claude's ability to pick the right tool degrades significantly
  beyond 30–50 tools.

## How it works

Tool Search Tool is a server-side Anthropic API feature for lazy (on-demand) tool loading.

1. All tools are sent in the request with `defer_loading: true`. Claude sees only names and
   descriptions — no full `input_schema`.
2. A special tool (`tool_search_tool_regex_20251119` or `tool_search_tool_bm25_20251119`)
   is included in the tools list.
3. When Claude needs a tool, it calls the search tool with a query.
4. The API returns 3–5 `tool_reference` content blocks containing fully expanded tool
   definitions.
5. These references are automatically injected into the conversation — Claude can then
   invoke the discovered tools normally.

Two search variants:
- **Regex** (`tool_search_tool_regex_20251119`) — Claude constructs regex patterns to search.
- **BM25** (`tool_search_tool_bm25_20251119`) — Claude uses natural language queries.

Reduces token usage by ~85% while maintaining high selection accuracy.

## API shape

### Request

Tools list includes the search tool plus deferred tools:

```python
tools = [
    # The search tool itself (no input_schema needed)
    {"type": "tool_search_tool_regex_20251119", "name": "tool_search_tool_regex"},

    # Deferred tools — only name + description visible to Claude
    {
        "name": "get_weather",
        "description": "Get the weather at a specific location",
        "input_schema": {
            "type": "object",
            "properties": {"location": {"type": "string"}},
            "required": ["location"],
        },
        "defer_loading": True,  # <-- key flag
    },
]
```

### Response

Claude's response includes `tool_reference` blocks alongside normal `tool_use`:

```json
{
  "content": [
    {"type": "tool_reference", "tool_name": "get_weather"},
    {
      "type": "tool_use",
      "name": "get_weather",
      "input": {"location": "San Francisco", "unit": "celsius"}
    }
  ]
}
```

The `tool_reference` block signals that the tool was discovered via search. The full
definition is automatically available for subsequent turns.

### Client-side implementation

You can also implement tool search client-side by returning `tool_reference` blocks from
your own search handler. This avoids vendor lock-in and works with any model — the client
intercepts the search tool call, performs its own lookup (embedding search, database, etc.),
and returns `tool_reference` blocks in the tool result.

## Relevance to flowra

### What needs to change in `flowra/llm/`

1. **`Tool` model** — add `defer_loading: bool = False` field.
2. **`LLMRequest`** — potentially a field for tool search configuration (variant, max_results).
3. **Anthropic provider** — serialize `defer_loading` flag, add the search tool to the request
   when deferred tools are present, handle `tool_reference` blocks in the response.
4. **Response model** — possibly a new `ToolReferenceBlock` or handle transparently.

### What needs to change in `flowra/agent/`

`ToolLoopAgent` orchestrates the tool loop. Two approaches:

- **Transparent (provider-level).** The provider handles tool search internally — deferred
  tools are sent with `defer_loading`, search tool is auto-injected, `tool_reference` blocks
  are consumed silently. The agent never sees the search — it just gets `tool_use` blocks
  as usual. Simple, but hides the mechanism.
- **Explicit (agent-level).** The agent knows about deferred tools and manages the search
  step. More control (e.g. custom search logic, caching discovered tools across iterations),
  but more complex.

Transparent approach seems right for v1 — tool search is an optimization, not a semantic
change to the agent's behavior.

### Cross-provider considerations

Tool search is Anthropic-specific. Other providers may have equivalents in the future, or
we can implement client-side search (embedding-based) that works with any provider. The
`defer_loading` flag on `Tool` is provider-agnostic — providers that don't support it
simply ignore it and send full definitions.

### Client-side tool search

The more interesting long-term approach. Flowra could provide a generic tool search
mechanism: given a large tool catalog, automatically defer tools and implement search
client-side. This would work with any LLM provider, not just Anthropic.
