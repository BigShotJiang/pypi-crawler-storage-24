# Provider-Specific Extensions — Research (March 2026)

> **Note:** This research has been implemented. The "proposed" approach below is now
> the current system (`flowra.lib.anthropic`). The "current" state described here
> refers to the OLD system that has been removed (`CacheConfig`, `cache: bool`).

Research date: 2026-03-20

## Problem

Provider-specific mechanics (prompt caching, deferred tool loading) are handled
inconsistently:

- **Caching** is baked into the core: `cache: bool` on `TextBlock`/`Tool`,
  `CacheConfig` with strategies in `tool_loop/cache.py`. But prompt caching
  is Anthropic-specific (Google has a different model, OpenAI doesn't have it).
- **Deferred tools** (Tool Search Tool) was prototyped via `Tool.extra` — a
  generic bag. No strategy layer, no typed config.
- Both are Anthropic-specific, but architecturally treated differently.

## Proposed approach: pluggable provider extensions

Provider-specific logic should live in pluggable modules that work through
standard mechanisms (metadata on messages/tools + provider-aware serialization).

### Pattern

Each extension has two parts:

1. **Strategy** — marks messages/tools with metadata according to configurable rules.
   Runs at the flowra level (in ToolLoopAgent, hooks, or tool registry).
2. **Provider adapter** — reads metadata during serialization, generates
   provider-specific API parameters. Lives inside the provider.

Both parts are pluggable and configurable.

### Example: Caching (current → proposed)

**Current:** `CacheConfig` with `SystemPromptCacheStrategy`, `ToolsCacheStrategy`,
`MessagesCacheStrategy`. These directly set `cache: bool` on `TextBlock`/`Tool` objects.
The Anthropic provider reads `block.cache` and emits `cache_control: {type: ephemeral}`.

**Proposed:**
- Strategy module sets `metadata["cache"] = True` on messages/blocks
  according to the configured policy (session messages only, up to first
  transient message, last N messages, etc.)
- Anthropic provider reads `metadata["cache"]` and generates `cache_control`
- Google provider reads `metadata["cache"]` and generates its own caching format
- OpenAI provider ignores it (no caching support)

This decouples "what to cache" (strategy) from "how to cache" (provider).

### Example: Tool Search (deferred tool loading)

**Proposed:**
- Strategy: mark tools for deferral. Options:
  - Explicit: user sets `extra["defer_loading"] = True` on specific tools
  - By callback: `lambda tool: tool.name.startswith("admin_")` → defer all admin tools
  - All: defer everything when total tool count > N
- Provider adapter (Anthropic): reads `extra["defer_loading"]`, serializes
  with `defer_loading: true`, auto-injects the search tool
- Search tool variant configurable: BM25 (natural language) or regex
- Other providers: ignore `defer_loading`, send full schemas as usual

### Example: Extended thinking

Already handled via `additional_config` — could follow the same pattern:
- Strategy: "enable thinking for this request" (based on complexity, tool count, etc.)
- Provider adapter: Anthropic adds `thinking_budget_tokens`, Google adds `thinking_level`

## Design questions

### Where do strategies live?

Options:
- **In ToolLoopAgent config** (current approach for caching) — `CacheConfig`
  is part of `ToolLoopConfig`. Simple, but couples strategy to agent type.
- **As hooks** — a `StartIterationEvent` handler that marks messages before
  each LLM call. More flexible, works with any agent.
- **In a separate "provider extension" module** — e.g.
  `flowra.lib.anthropic.caching`. Most decoupled, but more wiring.

### How does the provider know which adapter to apply?

Options:
- **Convention:** provider checks `metadata`/`extra` for known keys during serialization.
  No registration needed. Current approach for `extra`.
- **Registered adapters:** provider has a list of adapters, each gets a chance
  to modify the serialized request. More extensible, but more complex.
- **Typed config dataclass per provider:** e.g. `AnthropicToolExtra(defer_loading=True)`.
  Provider deserializes `extra` into the dataclass, gets typed access and validation.

### Backward compatibility with current caching

Current `cache: bool` on `TextBlock`/`Tool` works fine. Migration path:
- Keep `cache: bool` as-is for now (it's simple and works)
- New extensions use `metadata`/`extra` pattern
- Eventually, caching could migrate to `metadata["cache"]` too, but no rush

## Current state (prototype)

The `feat/tool-search` branch has a working prototype:
- `Tool.extra: dict[str, Any]` — provider-specific data
- `ToolDefinition.extra` — propagated from `@tool()` kwargs
- `@tool("name", description="...", defer_loading=True)` — kwargs → extra
- Anthropic provider reads `extra["defer_loading"]`, injects search tool
- Example with 12 business tools works end-to-end

This prototype is intentionally NOT released — we want to design the full
extension system (caching + tool search + future features) together.

## Next steps

1. Design the typed provider-extra dataclasses (e.g. `AnthropicToolExtra`)
2. Decide on strategy placement (config vs hooks vs extension module)
3. Prototype caching-as-extension alongside tool search
4. Migrate both to the unified pattern
5. Release together
