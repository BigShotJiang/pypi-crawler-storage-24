# OpenTelemetry Integration for Agent Framework — Research (March 2026)

Research date: 2026-03-22
Implemented: 2026-03-22

## Status: Implemented

Phase 1 implemented as `flowra/ext/otel.py`. Span-hook integration with GenAI
semantic conventions. Uses `FlowingContextVar` for parent tracking (same as MLflow).
Optional dependency: `flowra[otel]` (`opentelemetry-api`, `opentelemetry-sdk`).

## 1. MLflow + OTel Relationship

### Architecture

MLflow Tracing SDK (since 3.6.0) is **built on top of the OpenTelemetry SDK**. Internally:

- MLflow maintains a `_TracerProviderWrapper` that wraps an OTel `TracerProvider`.
- By default (`MLFLOW_USE_DEFAULT_TRACER_PROVIDER=true`), MLflow uses an **isolated** provider with its own `ContextVarsRuntimeContext` so it does not interfere with other OTel users in the same process.
- Setting `MLFLOW_USE_DEFAULT_TRACER_PROVIDER=false` tells MLflow to attach its span processors to the **global** OTel `TracerProvider`, merging MLflow spans into the same trace tree as other OTel instrumentation (FastAPI, Django, HTTP clients, etc.).

### Three instrumentation methods that merge into one trace

1. **MLflow auto-logging** — captures LLM framework calls (OpenAI, LangChain, DSPy, LlamaIndex)
2. **MLflow `@trace` decorator** — custom span creation for application logic
3. **OTel auto-instrumentation** — framework-level tracing (FastAPI, Django, Flask, HTTP clients)

When `MLFLOW_USE_DEFAULT_TRACER_PROVIDER=false`, all three produce spans in a **single unified trace**.

### Export modes

| Mode | Config | Description |
|------|--------|-------------|
| MLflow only (default) | No extra env vars | Traces go to MLflow Tracking Server only |
| OTel only | `OTEL_EXPORTER_OTLP_TRACES_ENDPOINT` | Traces go to OTel Collector only |
| Dual export | `MLFLOW_TRACE_ENABLE_OTLP_DUAL_EXPORT=true` + endpoint | Traces go to both MLflow and OTel Collector |

### MLflow as OTel receiver

MLflow Server exposes an OTLP/HTTP endpoint at `/v1/traces`. Any OTel-instrumented application (in any language) can send traces directly to MLflow. Config:
- `OTEL_EXPORTER_OTLP_TRACES_ENDPOINT=http://mlflow-host:5000/v1/traces`
- `OTEL_EXPORTER_OTLP_TRACES_HEADERS=x-mlflow-experiment-id=123`

Limitation: only OTLP/HTTP supported, not gRPC. Compression (gzip/deflate) supported since MLflow 3.7.0.

MLflow recognizes OTel GenAI semantic conventions and treats these spans as "first-class citizens" in the UI.

---

## 2. OTel GenAI Semantic Conventions

**Status: Experimental (Development).** Not yet GA/stable. Transition plan via `OTEL_SEMCONV_STABILITY_OPT_IN=gen_ai_latest_experimental`.

### Span types and naming

| Span Type | Operation Name | Span Name Format | Kind |
|-----------|---------------|-------------------|------|
| Chat/inference | `chat`, `text_completion`, `generate_content` | `{operation} {model}` (e.g. `chat gpt-4o`) | CLIENT |
| Embeddings | `embeddings` | `embeddings {model}` | CLIENT |
| Tool execution | `execute_tool` | `execute_tool {tool_name}` | INTERNAL |
| Retrieval | `retrieval` | `retrieval {data_source_id}` | CLIENT |
| Agent creation | `create_agent` | `create_agent {agent_name}` | CLIENT |
| Agent invocation | `invoke_agent` | `invoke_agent {agent_name}` | CLIENT/INTERNAL |

### Core attributes

**Required:**
- `gen_ai.operation.name` — `chat`, `embeddings`, `execute_tool`, `invoke_agent`, etc.
- `gen_ai.provider.name` — `openai`, `anthropic`, `gcp.vertex_ai`, `aws.bedrock`, etc.

**Conditionally required:**
- `gen_ai.request.model` — model identifier (e.g. `gpt-4`, `claude-sonnet-4-20250514`)
- `gen_ai.agent.id`, `gen_ai.agent.name` — for agent spans
- `gen_ai.conversation.id` — session tracking
- `gen_ai.tool.name`, `gen_ai.tool.call.id` — for tool spans
- `error.type` — on failure
- `server.address`, `server.port`

**Recommended:**
- `gen_ai.response.model` — actual model used
- `gen_ai.response.id` — provider response ID
- `gen_ai.response.finish_reasons` — `["stop"]`, `["length"]`
- `gen_ai.usage.input_tokens`, `gen_ai.usage.output_tokens`
- `gen_ai.usage.cache_read.input_tokens`, `gen_ai.usage.cache_creation.input_tokens`
- `gen_ai.request.temperature`, `gen_ai.request.max_tokens`, `gen_ai.request.top_p`, etc.

**Opt-in (sensitive, not captured by default):**
- `gen_ai.input.messages` — full chat history (structured)
- `gen_ai.output.messages` — model responses (structured)
- `gen_ai.system_instructions` — system prompts
- `gen_ai.tool.definitions` — tool schemas
- `gen_ai.tool.call.arguments`, `gen_ai.tool.call.result`

### Events

- `gen_ai.client.inference.operation.details` — captures full request/response details independently from traces
- `gen_ai.evaluation.result` — evaluation scores (name, score value/label, explanation)

### Metrics

| Metric | Type | Unit | Description |
|--------|------|------|-------------|
| `gen_ai.client.token.usage` | Histogram | `{token}` | Input/output token counts |
| `gen_ai.client.operation.duration` | Histogram | `s` | End-to-end operation duration |
| `gen_ai.server.request.duration` | Histogram | `s` | Server-side request duration |
| `gen_ai.server.time_to_first_token` | Histogram | `s` | TTFT |
| `gen_ai.server.time_per_output_token` | Histogram | `s` | Inter-token latency |

### Provider-specific conventions

OTel defines provider-specific pages for: Anthropic, OpenAI, AWS Bedrock, Azure AI Inference, and MCP (Model Context Protocol).

---

## 3. Industry Approach

### LangChain / LangSmith

- LangSmith (March 2025+) has **full end-to-end OTel support**. SDK >= 0.4.1 (recommended >= 0.4.25).
- Can send traces to LangSmith via OTLP, or to any other OTel-compatible backend.
- Also supports receiving OTel traces from non-LangChain applications.
- Separate community package: `opentelemetry-instrumentation-langchain` (from OpenLLMetry/Traceloop).

### LlamaIndex

- Has `llama-index-observability-otel` package for native OTel export.
- Also supported via OpenLLMetry's `opentelemetry-instrumentation-llamaindex`.
- Workflow steps, LLM calls, and custom events are automatically captured as OTel spans.

### OpenLLMetry (Traceloop)

- **The most comprehensive OTel-native LLM instrumentation library.** Open source, Apache 2.0.
- Provides standard OTel instrumentations for LLM providers (OpenAI, Anthropic, Cohere, Bedrock, etc.) and vector DBs.
- Available in Python, TypeScript, Go, Ruby.
- Works with any OTel-compatible backend (Datadog, Honeycomb, Grafana, Jaeger, etc.).
- Latest version 0.53.2 (March 2026). Also instruments MCP.
- Uses GenAI semantic conventions.

### Arize Phoenix

- **OTel-native** from the ground up. Accepts traces via standard OTLP.
- Developed **OpenInference** — a set of conventions complementary to OTel for AI tracing.
- First-class instrumentation for LangChain, LlamaIndex, DSPy, OpenAI, Anthropic, Bedrock.
- `arize-phoenix-otel` package provides simplified OTel setup with Phoenix-aware defaults.

### Langfuse

- Open source LLM observability. Supports OTel trace ingestion.
- Can receive traces from MLflow via OTel dual export.
- Has cookbook for MLflow-to-Langfuse via OTLP.

### Key pattern: OTel is becoming the standard wire format

Every major LLM observability tool either natively speaks OTel or has an OTel ingestion path. The ecosystem is converging on OTel as the interchange protocol, even when tools have their own internal trace formats.

---

## 4. Dual Tracing Pattern (MLflow + OTel)

### Is it common?

Yes, dual tracing is a recognized pattern. MLflow explicitly supports it with `MLFLOW_TRACE_ENABLE_OTLP_DUAL_EXPORT=true`. The use case:

- **MLflow** for: experiment tracking, prompt management, model registry, evaluation, the data science workflow
- **OTel backends** (Datadog, Grafana, etc.) for: production monitoring, alerting, distributed tracing across microservices, the SRE/platform workflow

### How they coexist

MLflow 3.6.0+ makes this straightforward:
1. Set `MLFLOW_USE_DEFAULT_TRACER_PROVIDER=false` to merge MLflow spans into the global OTel trace.
2. Set `MLFLOW_TRACE_ENABLE_OTLP_DUAL_EXPORT=true` to send to both backends.
3. Both backends see the same trace tree.

### Challenges

- Dual export adds latency (two export paths per span).
- There were bugs in early dual export (OTLP processor interfering with MLflow trace lifecycle) — fixed in recent versions.
- Two UIs to look at, two retention policies to manage.

---

## 5. OTel as Foundation vs. Two Independent Trees

### Option A: OTel as primary, MLflow consumes via OTLP

**How it works:** Framework produces standard OTel spans with GenAI semantic conventions. MLflow Server ingests them via its `/v1/traces` endpoint. Other backends (Datadog, etc.) get the same spans via standard OTLP export.

**Pros:**
- Single instrumentation layer — one span tree, not two
- Any OTel-compatible backend works out of the box
- Standard attributes (GenAI semconv) recognized by all tools
- No vendor lock-in
- Simpler architecture — no need to maintain parallel tracing systems

**Cons:**
- MLflow's GenAI-specific UI features (auto-tracing previews, prompt rendering) may not work as well with raw OTel spans vs. MLflow-native spans
- OTel GenAI conventions are still experimental — attribute names may change
- MLflow's `/v1/traces` is OTLP/HTTP only, no gRPC
- Lose MLflow-specific span enrichment (auto-tracing decorators, framework-specific metadata)

### Option B: MLflow tracing as primary, OTel export as secondary

**How it works:** Use MLflow SDK for instrumentation (`mlflow.start_span`, auto-tracing). Enable dual export to send OTel-compatible spans to other backends.

**Pros:**
- MLflow UI works perfectly (auto-tracing, prompt previews, evaluation integration)
- MLflow handles framework-specific instrumentation (auto-tracing for OpenAI, LangChain, etc.)
- Still get OTel compatibility via dual export

**Cons:**
- Tied to MLflow SDK for instrumentation
- MLflow span format is not 100% aligned with GenAI semantic conventions
- Harder to integrate with non-MLflow observability workflows

### Option C: OTel instrumentation in the framework, adapter layer for MLflow

**How it works:** Framework produces OTel spans with GenAI semantic conventions. A thin adapter converts these to MLflow spans for users who want MLflow UI. MLflow users can also just point MLflow at the OTel collector.

**Pros:**
- Best of both worlds
- Framework is vendor-neutral
- Users choose their backend

**Cons:**
- More code to maintain (adapter layer)
- Two code paths to test

### Recommendation

**Option C is the industry direction**, and it is what MLflow itself is moving toward (their "full OTel support" story). The framework should:

1. **Produce OTel spans with GenAI semantic conventions** as the primary tracing mechanism.
2. **Let users configure their OTel exporter** to send to whatever backend they want (MLflow, Datadog, Grafana, Langfuse, Phoenix, etc.).
3. **Keep the existing MLflow span-hook as an alternative** for users who prefer MLflow-native instrumentation (it already works via FlowingContextVar).
4. Do NOT try to maintain two parallel span trees in the framework core.

---

## 6. MLflow's OTel Export Configuration

### Exporting MLflow traces to OTel Collector

```bash
pip install opentelemetry-exporter-otlp

# Trace export
export OTEL_EXPORTER_OTLP_TRACES_ENDPOINT="http://localhost:4317/v1/traces"
export OTEL_SERVICE_NAME="my-app"
export OTEL_EXPORTER_OTLP_TRACES_PROTOCOL="http/protobuf"

# Optional: dual export (traces go to both MLflow and OTel)
export MLFLOW_TRACE_ENABLE_OTLP_DUAL_EXPORT="true"

# Optional: custom headers (for auth)
export OTEL_EXPORTER_OTLP_TRACES_HEADERS="Authorization=Bearer xxx"
```

### Metrics export

MLflow exports `mlflow.trace.span.duration` histogram via OTLP:
```bash
export OTEL_EXPORTER_OTLP_METRICS_ENDPOINT="http://localhost:4317/v1/metrics"
export OTEL_EXPORTER_OTLP_METRICS_PROTOCOL="http/protobuf"
```

### Merging MLflow + OTel spans

```bash
export MLFLOW_USE_DEFAULT_TRACER_PROVIDER="false"
```
Then call `mlflow.tracing.set_destination()` to add MLflow processors to the global OTel provider. This creates unified traces combining FastAPI/Django spans with MLflow LLM spans.

---

## 7. Recommendations for Flowra

### What to implement

**Phase 1: OTel span-hook (similar to existing MLflow hook)**
- New `flowra/ext/otel.py` with a span-hook that creates OTel spans using the standard `opentelemetry-api`.
- Map flowra's span lifecycle (`on_enter` / `on_exit`) to OTel span start/end.
- Set GenAI semantic convention attributes:
  - `gen_ai.operation.name` = `invoke_agent` for agent spans, `chat` for LLM calls, `execute_tool` for tool calls
  - `gen_ai.provider.name` from the LLM provider
  - `gen_ai.request.model`, `gen_ai.response.model`
  - `gen_ai.usage.input_tokens`, `gen_ai.usage.output_tokens`
  - `gen_ai.response.finish_reasons`
  - `gen_ai.agent.name` for agent spans
  - `gen_ai.tool.name`, `gen_ai.tool.call.id` for tool spans
- Use `FlowingContextVar` for parent span tracking (same pattern as MLflow hook).
- Users configure their own `TracerProvider` and exporter — flowra just creates spans.

**Phase 2: Optional content capture**
- Opt-in capture of `gen_ai.input.messages`, `gen_ai.output.messages`, `gen_ai.system_instructions` as span attributes or events.
- Respect privacy: off by default.

**Phase 3: Metrics**
- `gen_ai.client.token.usage` histogram
- `gen_ai.client.operation.duration` histogram

### What NOT to do

- Do NOT make OTel a hard dependency. Use optional import (`opentelemetry-api` as extra).
- Do NOT try to replace the MLflow hook — keep both as independent options.
- Do NOT implement provider-specific OTel conventions (Anthropic, OpenAI) — use the generic `gen_ai.*` attributes. Provider-specific details can come later.
- Do NOT wait for GenAI semconv to stabilize — the attribute names are unlikely to change drastically, and the `OTEL_SEMCONV_STABILITY_OPT_IN` mechanism provides a migration path.

### Attribute mapping from Flowra's existing types

| Flowra concept | OTel attribute | Source |
|---------------|---------------|--------|
| Agent name | `gen_ai.agent.name` | Agent class/config |
| LLM provider | `gen_ai.provider.name` | LLMProvider type |
| Model name (request) | `gen_ai.request.model` | LLMRequest.model |
| Model name (response) | `gen_ai.response.model` | LLMResponse (if available) |
| Input tokens | `gen_ai.usage.input_tokens` | Usage.input_tokens |
| Output tokens | `gen_ai.usage.output_tokens` | Usage.output_tokens |
| Cache read tokens | `gen_ai.usage.cache_read.input_tokens` | Usage.cache_read_input_tokens |
| Cache creation tokens | `gen_ai.usage.cache_creation.input_tokens` | Usage.cache_creation_input_tokens |
| Stop reason | `gen_ai.response.finish_reasons` | LLMResponse.stop_reason |
| Temperature | `gen_ai.request.temperature` | LLMRequest.temperature |
| Max tokens | `gen_ai.request.max_tokens` | LLMRequest.max_tokens |
| Tool name | `gen_ai.tool.name` | Tool.name |
| Tool call ID | `gen_ai.tool.call.id` | ToolUseBlock.id |
| Cost | (no standard attribute) | Usage.cost_usd — set as custom attribute |

---

## Sources

- [Full OpenTelemetry Support in MLflow Tracing](https://mlflow.org/blog/opentelemetry-tracing-support)
- [MLflow OTel Integration Overview](https://mlflow.org/docs/latest/genai/tracing/opentelemetry/)
- [Export MLflow Traces/Metrics via OTLP](https://mlflow.org/docs/latest/genai/tracing/opentelemetry/export/)
- [Collect OTel Traces into MLflow](https://mlflow.org/docs/latest/genai/tracing/opentelemetry/ingest/)
- [Tracing with OpenTelemetry (MLflow)](https://mlflow.org/docs/latest/genai/tracing/app-instrumentation/opentelemetry/)
- [OTel GenAI Semantic Conventions](https://opentelemetry.io/docs/specs/semconv/gen-ai/)
- [OTel GenAI Span Conventions](https://opentelemetry.io/docs/specs/semconv/gen-ai/gen-ai-spans/)
- [OTel GenAI Agent Span Conventions](https://opentelemetry.io/docs/specs/semconv/gen-ai/gen-ai-agent-spans/)
- [OTel GenAI Event Conventions](https://opentelemetry.io/docs/specs/semconv/gen-ai/gen-ai-events/)
- [OTel GenAI Metrics Conventions](https://opentelemetry.io/docs/specs/semconv/gen-ai/gen-ai-metrics/)
- [LangSmith End-to-End OTel Support](https://blog.langchain.com/end-to-end-opentelemetry-langsmith/)
- [LlamaIndex Observability](https://developers.llamaindex.ai/python/framework/module_guides/observability/)
- [OpenLLMetry (Traceloop)](https://github.com/traceloop/openllmetry)
- [Arize Phoenix — OTel for LLM Observability](https://arize.com/blog/the-role-of-opentelemetry-in-llm-observability/)
- [OpenInference (Arize)](https://github.com/Arize-ai/openinference)
- [MLflow Integration via OTel — Langfuse](https://langfuse.com/guides/cookbook/otel_integration_mlflow)
- [OTel Databricks Export](https://docs.databricks.com/aws/en/mlflow3/genai/tracing/integrations/open-telemetry)
- [OTel Standardizes LLM Tracing — Implementation Guide](https://earezki.com/ai-news/2026-03-21-opentelemetry-just-standardized-llm-tracing-heres-what-it-actually-looks-like-in-code/)
