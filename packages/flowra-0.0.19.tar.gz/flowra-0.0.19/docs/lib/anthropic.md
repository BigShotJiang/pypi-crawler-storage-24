# Anthropic extensions (`flowra.lib.anthropic`)

Composable hook bundles for Anthropic-specific features: prompt caching and
tool search. All work through the `PrepareLLMRequestEvent` hook.

## Prompt caching

Bundles that set `cache_control: {"type": "ephemeral"}` on blocks and tools.
Each handles one caching slot (system, tools, or messages). The `NonTransient*`
bundles respect the `transient` hint — transient content is not cached.
The `*All*` bundles cache the last block regardless of `transient`.

## Usage

```python
from flowra.agent import HookSubscription
from flowra.lib.anthropic import ANTHROPIC_CACHE_ALL

hooks = HookSubscription()
ANTHROPIC_CACHE_ALL.install(hooks)
# pass hooks to AgentRuntime via services={HookSubscription: hooks, ...}
```

## Available bundles

| Bundle                                     | What it caches                                                                           |
|--------------------------------------------|------------------------------------------------------------------------------------------|
| `AnthropicCacheAllSystemMessages`          | Last block of the last system message                                                    |
| `AnthropicCacheNonTransientSystemMessages` | Last non-transient block of the last non-transient system message                        |
| `AnthropicCacheAllTools`                   | Last tool definition                                                                     |
| `AnthropicCacheAllMessages`                | Last block of the last message                                                           |
| `AnthropicCacheNonTransientMessages`       | Last non-transient block of the last non-transient message                               |
| `AnthropicCacheHistoryMessages`            | Last message that was in history before the current turn (via `SaveHistoryEvent` marker) |

## Presets

- **`ANTHROPIC_CACHE_ALL`** — composite of `AnthropicCacheAllSystemMessages` +
  `AnthropicCacheAllTools` + `AnthropicCacheAllMessages`. Caches all three slots.
- **`ANTHROPIC_CACHE_SESSION`** — composite of `AnthropicCacheAllSystemMessages` +
  `AnthropicCacheAllTools` + `AnthropicCacheHistoryMessages`. Caches system and tools,
  plus the last history message (excludes current turn). Requires `ChatAgent`.

## `transient` hint

Bundles with "NonTransient" in the name skip blocks and messages where
`transient=True`. This is useful when hooks inject temporary context (e.g.
iteration-specific instructions) that changes on every LLM call — caching such
content would cause cache invalidation.

```python
from flowra.llm import TextBlock

# This block will be skipped by NonTransient caching bundles
TextBlock(text="Current time: 12:00", transient=True)
```

## Custom bundles

To implement your own caching logic, subscribe to `PrepareLLMRequestEvent`
and modify `event.data.request`:

```python
from flowra.lib.tool_loop import PrepareLLMRequestEvent

def my_cache_hook(event):
    request = event.data.request
    # modify request.system, request.tools, request.messages
    # set extra={"cache_control": {"type": "ephemeral"}} on target blocks
    event.data.request = modified_request

hooks.on(PrepareLLMRequestEvent, my_cache_hook)
```

---

## Tool search (`AnthropicToolSearch`)

When an agent has many tools (50+), two problems arise: tool definitions consume
a large portion of the context budget (~55k tokens for a typical multi-server setup),
and Claude's ability to pick the right tool degrades significantly.

`AnthropicToolSearch` solves this with deferred tool loading — tools are sent with
only names and descriptions (no full `input_schema`), and a server-side search tool
is added. When Claude needs a tool, it calls the search tool with a query, and the
API returns the full definitions of the matching tools. Claude then invokes the
discovered tools normally.

Two search variants are available: **BM25** (Claude uses natural language queries)
and **Regex** (Claude constructs regex patterns to match tool names/descriptions).

This reduces token usage by ~85% while maintaining high tool selection accuracy.

### Usage

```python
from flowra.lib.anthropic import AnthropicToolSearch, ToolSearchVariant

ext = AnthropicToolSearch()
ext.install(hooks)
```

### Parameters

| Parameter   | Default                  | Description                                                               |
|-------------|--------------------------|---------------------------------------------------------------------------|
| `variant`   | `ToolSearchVariant.BM25` | Search variant: `BM25` (natural language) or `REGEX` (regex patterns)     |
| `predicate` | `None`                   | Optional `(Tool) -> bool` — only defer matching tools. Default: defer all |

### `ToolSearchVariant`

```python
class ToolSearchVariant(StrEnum):
    BM25 = "bm25"    # natural language search
    REGEX = "regex"   # Claude constructs regex patterns
```

### Examples

```python
# Defer all tools (BM25 by default)
AnthropicToolSearch().install(hooks)

# Defer only admin tools
AnthropicToolSearch(predicate=lambda t: t.name.startswith("admin_")).install(hooks)

# Use regex search variant
AnthropicToolSearch(variant=ToolSearchVariant.REGEX).install(hooks)
```

### How it works

1. Before each LLM call, the extension marks selected tools with `defer_loading: true`
   and adds the search tool to the request
2. Claude receives only tool names and descriptions — no full schemas
3. When Claude needs a tool, it calls the search tool with a query
4. The Anthropic API returns full definitions of matching tools (`tool_reference` blocks)
5. Claude invokes the discovered tools normally — the agent sees regular `tool_use` blocks

The entire search/discovery process is handled server-side by the Anthropic API.
The agent doesn't need any special handling — it works transparently within the
existing tool loop.
