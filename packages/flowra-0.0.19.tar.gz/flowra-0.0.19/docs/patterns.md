# Multi-Agent Patterns

Recipes showing how to implement common multi-agent patterns using existing
primitives. No dedicated Graph/Workflow DSL needed — the state machine covers
all these cases.

Imports used across examples:

```python
import dataclasses
from typing import Annotated

from flowra.agent import (
    Agent, AgentStore, CallAgent, GotoStep, Scalar, Spawn,
    WhenAll, WhenAny, WhenN, step, step_arg, timeout,
    TimeoutExpired, Interrupted,
)
```

---

## Router

Classify input, then delegate to a specialized agent.

```python
@dataclasses.dataclass
class Query:
    text: str

@dataclasses.dataclass
class Answer:
    text: str


class Router(Agent[Query, Answer]):
    @step(entry=True)
    async def classify(self, spec: Query) -> Spawn:
        # Classification logic (could also be an LLM call)
        if any(w in spec.text.lower() for w in ("calculate", "math", "sum")):
            agent = MathAgent
        else:
            agent = GeneralAgent

        return Spawn(
            CallAgent(agent=agent, spec=spec),
            then=self.forward,
        )

    @step
    async def forward(self, result: Answer) -> Answer:
        return result
```

---

## Pipeline

Sequential stages — each step transforms data and passes it to the next.

```python
@dataclasses.dataclass
class Document:
    text: str

@dataclasses.dataclass
class Extracted:
    entities: list[str]

@dataclasses.dataclass
class Report:
    summary: str


class Pipeline(Agent[Document, Report]):
    @step(entry=True)
    async def extract(self, spec: Document) -> GotoStep:
        entities = [...]  # extract entities from spec.text
        return GotoStep(step=self.summarize, spec=Extracted(entities=entities))

    @step
    async def summarize(self, data: Extracted) -> Report:
        summary = f"Found {len(data.entities)} entities"
        return Report(summary=summary)
```

For heavier stages, delegate to sub-agents:

```python
class Pipeline(Agent[Document, Report]):
    @step(entry=True)
    async def start(self, spec: Document) -> Spawn:
        return Spawn(
            CallAgent(agent=ExtractorAgent, spec=spec),
            then=self.after_extract,
        )

    @step
    async def after_extract(self, extracted: Extracted) -> Spawn:
        return Spawn(
            CallAgent(agent=SummarizerAgent, spec=extracted),
            then=self.finish,
        )

    @step
    async def finish(self, report: Report) -> Report:
        return report
```

---

## Fan-out / Fan-in

Dispatch work to parallel workers, collect all results.

```python
@dataclasses.dataclass
class SearchSpec:
    query: str
    source: str

@dataclasses.dataclass
class SearchResult:
    source: str
    items: list[str]

@dataclasses.dataclass
class MergedResults:
    all_items: list[str]


@dataclasses.dataclass
class SearchQuery:
    query: str


class FanOutFanIn(Agent[SearchQuery, MergedResults]):
    @step(entry=True)
    async def search(self, spec: SearchQuery) -> Spawn:
        return Spawn(
            children=[
                CallAgent(agent=SearchAgent, spec=SearchSpec(query=spec.query, source=src))
                for src in ["web", "docs", "code"]
            ],
            then=self.merge,
        )

    @step
    async def merge(self, results: list[SearchResult]) -> MergedResults:
        all_items = [item for r in results for item in r.items]
        return MergedResults(all_items=all_items)
```

Use tags when workers return different types:

```python
@step(entry=True)
async def analyze(self, spec: AnalysisSpec) -> Spawn:
    return Spawn(
        CallAgent(agent=SentimentAgent, spec=spec, tag="sentiment"),
        CallAgent(agent=SummaryAgent, spec=spec, tag="summary"),
        then=self.combine,
    )

@step
async def combine(
    self,
    sentiment: Annotated[SentimentResult, step_arg.CHILD("sentiment")],
    summary: Annotated[SummaryResult, step_arg.CHILD("summary")],
) -> CombinedResult:
    return CombinedResult(sentiment=sentiment, summary=summary)
```

---

## Race (first wins)

Launch competing workers, take the first result, cancel the rest.

```python
@dataclasses.dataclass
class RaceResult:
    winner: str
    answer: str


@dataclasses.dataclass
class RaceSpec:
    question: str


class Race(Agent[RaceSpec, RaceResult]):
    @step(entry=True)
    async def start(self, spec: RaceSpec) -> Spawn:
        return Spawn(
            WhenAny(
                CallAgent(agent=FastModel, spec=spec, tag="fast"),
                CallAgent(agent=SmartModel, spec=spec, tag="smart"),
                timeout(seconds=30),
            ),
            then=self.finish,
        )

    @step
    async def finish(
        self,
        fast: Annotated[Answer | None, step_arg.CHILD("fast")],
        smart: Annotated[Answer | None, step_arg.CHILD("smart")],
        expired: TimeoutExpired | None,
    ) -> RaceResult:
        if expired:
            return RaceResult(winner="none", answer="Timed out")
        winner = fast or smart
        assert winner is not None
        return RaceResult(winner="fast" if fast else "smart", answer=winner.text)
```

---

## Feedback loop

Writer produces a draft, reviewer critiques it, writer revises — up to N
iterations.

```python
@dataclasses.dataclass
class Draft:
    text: str
    feedback: str | None = None

@dataclasses.dataclass
class Review:
    approved: bool
    feedback: str

@dataclasses.dataclass
class FinalDraft:
    text: str
    iterations: int


@dataclasses.dataclass
class WritingTask:
    topic: str


class FeedbackLoop(Agent[WritingTask, FinalDraft]):
    MAX_ITERATIONS = 3

    def __init__(self, spec: WritingTask, store: AgentStore) -> None:
        self.topic = spec.topic
        self.iteration = store.slot(Scalar[int], "iteration")
        self.last_feedback = store.slot(Scalar[str], "last_feedback")

    @step(entry=True)
    async def write(self) -> Spawn:
        feedback = self.last_feedback.get(None)
        return Spawn(
            CallAgent(agent=WriterAgent, spec=Draft(text=self.topic, feedback=feedback)),
            then=self.review,
        )

    @step
    async def review(self, draft: Draft) -> Spawn | FinalDraft:
        iteration = self.iteration.get(0) + 1
        self.iteration.set(iteration)

        if iteration >= self.MAX_ITERATIONS:
            return FinalDraft(text=draft.text, iterations=iteration)

        return Spawn(
            CallAgent(agent=ReviewerAgent, spec=draft),
            then=self.decide,
        )

    @step
    async def decide(self, review: Review) -> GotoStep | FinalDraft:
        if review.approved:
            return FinalDraft(text="...", iterations=self.iteration.get(0))

        self.last_feedback.set(review.feedback)
        return GotoStep(step=self.write)
```

---

## Partial results (WhenN)

Wait for N out of M workers, cancel the rest.

```python
class BestOfThree(Agent[SearchQuery, MergedResults]):
    @step(entry=True)
    async def start(self, spec: SearchQuery) -> Spawn:
        return Spawn(
            WhenN(
                CallAgent(agent=WorkerAgent, spec=WorkSpec(query=spec.query, strategy="a")),
                CallAgent(agent=WorkerAgent, spec=WorkSpec(query=spec.query, strategy="b")),
                CallAgent(agent=WorkerAgent, spec=WorkSpec(query=spec.query, strategy="c")),
                n=2,  # take first 2, cancel the slowest
            ),
            then=self.merge,
        )

    @step
    async def merge(self, results: list[SearchResult]) -> MergedResults:
        return MergedResults(all_items=[item for r in results for item in r.items])
```

---

## Work with timeout

Any pattern can be wrapped with a timeout using `WhenAny` + `timeout()`:

```python
@step(entry=True)
async def start(self, spec: TaskSpec) -> Spawn:
    return Spawn(
        WhenAny(
            CallAgent(agent=SlowAgent, spec=spec),
            timeout(seconds=60),
        ),
        then=self.handle,
    )

@step
async def handle(
    self,
    result: TaskResult | None,
    expired: TimeoutExpired | None,
) -> FinalResult:
    if expired:
        return FinalResult(status="timeout")
    assert result is not None
    return FinalResult(status="done", data=result)
```

Timeouts compose with other strategies:

```python
# Fan-out with global timeout
Spawn(
    WhenAny(
        WhenAll(worker_a, worker_b, worker_c),
        timeout(minutes=5),
    ),
    then=self.collect,
)

# Race with per-contestant + global timeout
Spawn(
    WhenAny(
        WhenAny(contestant_a, timeout(seconds=10)),  # per-contestant
        WhenAny(contestant_b, timeout(seconds=10)),
        timeout(seconds=30),                          # global
    ),
    then=self.finish,
)
```
