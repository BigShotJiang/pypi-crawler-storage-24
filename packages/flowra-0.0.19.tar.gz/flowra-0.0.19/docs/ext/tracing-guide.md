# Tracing guide

Flowra provides two tracing integrations: MLflow and OpenTelemetry. This guide
helps you choose the right setup for your use case.

## Quick summary

| Setup | Best for | What you get |
|-------|----------|--------------|
| [MLflow only](#mlflow-only) | ML experiments, prompt debugging | Rich LLM UI, chat preview, cost tracking, sessions |
| [OTel only](#otel-only) | Production services with existing OTel | Standard GenAI spans in Jaeger/Grafana/Datadog |
| [Both independently](#both-independently) | Full picture, two UIs | MLflow for LLM details + OTel for distributed tracing |
| [MLflow with OTel export](#mlflow-with-otel-export) | MLflow UI + OTel backend, single instrumentation | MLflow spans forwarded to OTel collector |

## MLflow only

**Use when:** You want to see LLM requests/responses, compare prompts, track
costs, group multi-turn conversations into sessions.

**What you get:** MLflow UI with structured chat rendering, token usage, cost
breakdown, session grouping, experiment comparison.

**What you don't get:** Integration with your service's distributed traces
(HTTP handlers, database calls, message queues).

```python
from flowra.agent import HookSubscription
from flowra.ext.mlflow import install_mlflow_tracing

hooks = HookSubscription()
install_mlflow_tracing(hooks, experiment_name="my-experiment", session_id="chat-123")
```

```bash
pip install flowra[mlflow]
uv run mlflow ui --port 5050  # view at http://localhost:5050
```

Details: [MLflow tracing docs](mlflow.md)

## OTel only

**Use when:** Your service already uses OpenTelemetry (Jaeger, Grafana Tempo,
Datadog, Honeycomb) and you want agent spans in the same trace tree as your
HTTP handlers, database calls, gRPC, etc.

**What you get:** Standard GenAI semantic convention spans with model, provider,
token usage, cost. Appear in your existing OTel backend alongside all other
service spans.

**What you don't get:** MLflow's rich LLM-specific UI (chat message rendering,
prompt comparison, experiment tracking).

```python
from opentelemetry import trace
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter

# Standard OTel setup — send to your collector
provider = TracerProvider(resource=Resource.create({"service.name": "my-service"}))
provider.add_span_processor(BatchSpanProcessor(OTLPSpanExporter()))
trace.set_tracer_provider(provider)

from flowra.agent import HookSubscription
from flowra.ext.otel import install_otel_tracing

hooks = HookSubscription()
install_otel_tracing(hooks)
```

```bash
pip install flowra[otel] opentelemetry-exporter-otlp
```

Details: [OpenTelemetry tracing docs](otel.md)

## Both independently

**Use when:** You want MLflow's rich LLM UI for prompt debugging AND OTel spans
in your production monitoring stack. Each creates its own span tree in its own
backend.

**What you get:** Two independent views — MLflow for LLM-specific analysis, OTel
backend for distributed tracing and production monitoring.

**Trade-off:** Two span trees, two sets of spans. Slightly more overhead (two
handler chains per span event). The traces are not linked — an MLflow trace and
an OTel trace for the same request have different trace IDs.

```python
from flowra.agent import HookSubscription
from flowra.ext.mlflow import install_mlflow_tracing
from flowra.ext.otel import install_otel_tracing

hooks = HookSubscription()
install_mlflow_tracing(hooks, experiment_name="my-experiment")
install_otel_tracing(hooks)
```

```bash
pip install flowra[mlflow,otel] opentelemetry-exporter-otlp
```

## MLflow with OTel export

**Use when:** You want MLflow's rich UI AND the same spans in your OTel backend,
without running two separate instrumentations.

**How it works:** MLflow is built on top of OTel internally. With dual export
enabled, MLflow sends its spans to both the MLflow backend and an OTel collector.
You only install the MLflow integration — no `install_otel_tracing` needed.

**What you get:** MLflow UI with full LLM features, plus the same spans in your
OTel backend (Jaeger, Grafana, etc.). Single trace ID shared between both.

**Trade-off:** MLflow span attributes are not identical to GenAI semantic
conventions — OTel backends won't recognize them as standard GenAI spans.
MLflow uses its own attribute names (`mlflow.chat.tokenUsage`, `mlflow.llm.cost`,
etc.) rather than `gen_ai.*`.

```python
from flowra.agent import HookSubscription
from flowra.ext.mlflow import install_mlflow_tracing

hooks = HookSubscription()
install_mlflow_tracing(hooks, experiment_name="my-experiment")
```

```bash
pip install flowra[mlflow] opentelemetry-exporter-otlp

# Enable dual export via environment variables:
export OTEL_EXPORTER_OTLP_TRACES_ENDPOINT="http://localhost:4317"
export MLFLOW_TRACE_ENABLE_OTLP_DUAL_EXPORT="true"
export OTEL_SERVICE_NAME="my-service"
```

To merge flowra's MLflow spans into the same trace as your service's OTel spans
(e.g., FastAPI HTTP handler → flowra agent → LLM call):

```bash
export MLFLOW_USE_DEFAULT_TRACER_PROVIDER="false"
```

This tells MLflow to use the global OTel `TracerProvider` instead of its own
isolated one. All spans — from your web framework, from flowra, from any other
OTel-instrumented library — appear in a single unified trace.

## Choosing the right setup

```
Do you use OTel in your service already?
├── No → MLflow only (simplest, best LLM UI)
└── Yes
    ├── Do you need MLflow's LLM-specific UI?
    │   ├── No → OTel only (standard, lightweight)
    │   └── Yes
    │       ├── Do you want one trace ID across both?
    │       │   ├── Yes → MLflow with OTel export
    │       │   └── No → Both independently
    │       └── Do you need standard GenAI semconv attributes?
    │           ├── Yes → Both independently (OTel handler uses gen_ai.*)
    │           └── No → MLflow with OTel export (simpler)
```
