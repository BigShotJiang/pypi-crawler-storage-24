# Package `flowra.lib`

Pre-built agents for LLM interactions: single LLM call, multi-turn chat, and
tool-calling loop with hooks, caching, and interrupt support.

- **LLMCallAgent** — single LLM call with streaming and hook events
- **ChatAgent** — multi-turn chat with session history and turn persistence
- **ToolLoopAgent** — LLM tool loop with iteration control and full hook lifecycle
- **Agents as tools** — expose any agent as an LLM-callable tool
- **ConfigValue** — static or dynamic configuration

Imports:

```python
from flowra.lib import LLMConfig, LLMCallAgent
from flowra.lib.chat import ChatAgent, ChatConfig, ChatResult, ChatSpec
from flowra.lib.tool_loop import ToolLoopAgent, ToolLoopConfig, ToolLoopResult, ToolLoopSpec
from flowra.lib.tool_loop import agent_tool, get_agent_tool, make_agent_tool
```

## Quick start

Minimal multi-turn chat with a tool:

```python
from flowra.agent import AgentRuntime
from flowra.lib.chat import ChatAgent, ChatConfig, ChatResult, ChatSpec
from flowra.lib import LLMConfig
from flowra.llm import LLMProvider, SystemMessage, TextBlock
from flowra.tools import ToolRegistry

runtime = AgentRuntime(
    agents={"chat": ChatAgent},
    services={
        LLMProvider: provider,
        ToolRegistry: registry,
        ChatConfig: ChatConfig(
            llm_config=LLMConfig(model="claude-sonnet-4-5@20250929"),
            system=[SystemMessage(blocks=[TextBlock(text="You are helpful.")])],
        ),
    },
)

result = await runtime.run(agent=ChatAgent, spec=ChatSpec(user_message="Hello!"))
```

## LLMCallAgent

Single LLM call — messages in, response out. No tool loop, no history.

```python
from flowra.agent import AgentRuntime
from flowra.lib import LLMCallAgent, LLMConfig
from flowra.lib.llm_call import LLMCallResult, LLMCallSpec
from flowra.llm import LLMProvider, SystemMessage, TextBlock, UserMessage

runtime = AgentRuntime(
    agents={"call": LLMCallAgent},
    services={LLMProvider: provider, LLMConfig: LLMConfig(model="claude-sonnet-4-5@20250929")},
)

result = await runtime.run(
    agent=LLMCallAgent,
    spec=LLMCallSpec(
        system=[SystemMessage(blocks=[TextBlock(text="You are helpful.")])],
        messages=[UserMessage(blocks=[TextBlock(text="What is 2+2?")])],
    ),
)
# result: LLMCallResult with .message (AssistantMessage), .usage, .elapsed
```

### Streaming

When `TextDeltaEvent` or `ThinkingDeltaEvent` handlers are registered, `LLMCallAgent`
automatically switches from `provider.call()` to `provider.stream()`:

```python
from flowra.agent import HookSubscription
from flowra.llm import TextDeltaEvent

hooks = HookSubscription()
hooks.on(TextDeltaEvent, lambda e: print(e.data.text, end="", flush=True))

runtime = AgentRuntime(
    agents={"call": LLMCallAgent},
    services={LLMProvider: provider, LLMConfig: LLMConfig(model="..."), HookSubscription: hooks},
)
```

LLMCallAgent uses `LLMCallSpan` span-hook (from `flowra.llm`) for LLM call
observability. Streaming events: `TextDeltaEvent`, `ThinkingDeltaEvent`
(from `flowra.llm` — shared with `ToolLoopAgent`).

---

## ChatAgent

Multi-turn chat with session history. Each call is one user turn: the agent
delegates to `ToolLoopAgent`, then saves all messages back to the session.

```python
result = await runtime.run(agent=ChatAgent, spec=ChatSpec(user_message="Hello!"))
# result: ChatResult with .response (str | None) and .usage
```

`ChatSpec` also accepts `metadata: dict[str, Any] | None` — passed through to
`ToolLoopSpec` and `MessageAcceptedEvent`, useful for tracking message IDs in
interrupt/resume scenarios.

`ChatResult.response` is `None` when the LLM didn't produce text (interrupted
or max LLM calls reached).

Conversation history persists across turns — the LLM sees full history.

### ChatConfig

Pass as a service to `AgentRuntime`. All fields accept `ConfigValue[T]` — a plain
value, sync callable, or async callable:

```python
ChatConfig(
    llm_config=LLMConfig(model="claude-sonnet-4-5@20250929"),
    system=[SystemMessage(blocks=[TextBlock(text="You are helpful.")])],
    max_llm_calls=10,          # per turn
    json_schema={...},         # structured output (optional)
    allowed_tools={"calculate", "search"},  # fnmatch patterns
    denied_tools={"debug_*"},  # fnmatch exclusion patterns
)
```

`ChatConfig` has `system: list[SystemMessage]` — passed directly to `LLMRequest.system`.
The chat agent manages conversation history automatically.

### Chat hook: `SaveHistoryEvent`

Emitted before turn messages are saved to session history. Mutate `messages` in
place to filter out transient messages:

```python
from flowra.lib.chat import SaveHistoryEvent

def filter_transient(event):
    event.data.messages = [m for m in event.data.messages if not m.transient]

hooks.on(SaveHistoryEvent, filter_transient)
```

---

## ToolLoopAgent

LLM tool loop: send messages → execute tool calls → feed results back → repeat
until `END_TURN` or a limit is reached. `ChatAgent` delegates to this internally.

```python
from flowra.lib.tool_loop import ToolLoopAgent, ToolLoopConfig, ToolLoopResult, ToolLoopSpec

config = ToolLoopConfig(
    llm_config=LLMConfig(model="claude-sonnet-4-5@20250929"),
    system=[SystemMessage(blocks=[TextBlock(text="You are helpful.")])],
    history=[],
    max_llm_calls=5,
)

runtime = AgentRuntime(
    agents={"loop": ToolLoopAgent},
    services={LLMProvider: provider, ToolRegistry: registry, ToolLoopConfig: config},
)

result = await runtime.run(
    agent=ToolLoopAgent,
    spec=ToolLoopSpec(user_message="Calculate 3*7"),  # also accepts metadata={}
)
# result: ToolLoopResult with .messages, .status, .stop_reason, .result_message, .usage
```

### How the loop works

1. **`start`** — wraps user message, fires `UserMessageEvent` (mutable),
   flushes state, fires `MessageAcceptedEvent`
2. **`call_llm`** — checks interrupt, fires `StartIterationEvent` (inject context),
   calls LLM (streaming if delta handlers registered), processes response:
   - `END_TURN` → fires `ResultMessageEvent` (set `continue_messages` to keep going) → done
   - `TOOL_USE` → fires `BeforeToolCallEvent` per tool (modify params) → spawns tool execution → step 3
   - Other (`MAX_TOKENS`, `STOP_SEQUENCE`, `SCHEMA_VALIDATION_FAILED`) → returns immediately
3. **`collect_results`** — fires `AfterToolCallEvent` per tool (replace result,
   inject messages), checks `max_consecutive_errors`, loops back to step 2

### ToolLoopConfig

Has `system` (`list[SystemMessage]`) and `history`
(`list[UserMessage | AssistantMessage]`). Turn messages are accumulated during the
current run (user input, assistant responses, tool results). All three are sent to
the LLM on every call.

Tool filtering: `allowed_tools` / `denied_tools` accept fnmatch patterns
(e.g., `{"mcp_*"}`, `{"debug_?"}`).

### ToolLoopResult status

| Status             | Meaning                                          |
|--------------------|--------------------------------------------------|
| `COMPLETED`        | LLM returned a final response                    |
| `MAX_LLM_CALLS`    | Iteration limit reached                          |
| `FINISH_REQUESTED` | A tool or hook called `context.request_finish()` |

### Hook events

| Event                    | Mutable fields                  | When                        |
|--------------------------|---------------------------------|-----------------------------|
| `UserMessageEvent`       | `messages`                      | Once at loop start          |
| `MessageAcceptedEvent`   | —                               | After messages accepted     |
| `StartIterationEvent`    | `additional_messages`           | Each iteration start        |
| `PrepareLLMRequestEvent` | `request`                       | Before each LLM call        |
| `TextDeltaEvent`*        | —                               | Streaming text chunk        |
| `ThinkingDeltaEvent`*    | —                               | Streaming thinking chunk    |
| `TextReasoningEvent`     | —                               | Each TextBlock in response  |
| `ThinkingEvent`          | —                               | Each ThinkingBlock          |
| `BeforeToolCallEvent`    | `tool_use`                      | Before tool execution       |
| `AfterToolCallEvent`     | `result`, `additional_messages` | After tool execution        |
| `ResultMessageEvent`     | `continue_messages`             | On END_TURN                 |

\* `TextDeltaEvent` and `ThinkingDeltaEvent` are imported from `flowra.llm` (shared with `LLMCallAgent`).

### Tool services

Tools receive all services from the agent's scope. Add a typed parameter to
the tool handler:

```python
from flowra.agent import InterruptToken
from flowra.lib.tool_loop import ToolLoopAgentContext

@tool("process")
async def process(params: Params, interrupt: InterruptToken) -> str:
    interrupt.check()
    return "done"

@tool("finish")
def finish(params: Params, context: ToolLoopAgentContext) -> str:
    context.request_finish()  # loop stops after current iteration
    return "stopping"
    # also: context.is_finish_requested() -> bool
```

---

## Prompt caching

Prompt caching is handled via composable hook bundles that subscribe to
`PrepareLLMRequestEvent` and set provider-specific cache hints (e.g.
`cache_control`) via `extra` on blocks and tools.

For Anthropic, use the extensions in `flowra.lib.anthropic`:

```python
from flowra.agent import HookSubscription
from flowra.lib.anthropic import ANTHROPIC_CACHE_ALL

hooks = HookSubscription()
ANTHROPIC_CACHE_ALL.install(hooks)
# pass hooks to AgentRuntime via services={HookSubscription: hooks, ...}
```

`ANTHROPIC_CACHE_ALL` is a composite preset that caches system messages, tools,
and conversation messages. Individual bundles are also available — see
`docs/lib/anthropic.md` for the full list.

The `transient` hint on blocks and messages lets caching bundles skip non-permanent
content when placing cache breakpoints. For example,
`AnthropicCacheNonTransientMessages` only caches the last non-transient message.

To implement custom caching logic for other providers, subscribe to
`PrepareLLMRequestEvent` and modify `event.data.request` directly.

---

## Agents as tools

Expose any agent as an LLM-callable tool. The LLM decides when to delegate;
the sub-agent handles how.

### `@agent_tool` decorator

```python
from flowra.agent import Agent, step
from flowra.lib.tool_loop import agent_tool, get_agent_tool

@agent_tool(name="poet", description="Write a poem on a topic")
class PoetAgent(Agent[PoetSpec, PoetResult]):
    @step(entry=True)
    async def write(self, spec: PoetSpec) -> PoetResult:
        return PoetResult(poem="...")

# Register:
poet_tool = get_agent_tool(PoetAgent)
async with await ToolRegistry.create([poet_tool]) as registry:
    runtime = AgentRuntime(
        agents={"chat": ChatAgent, "poet": PoetAgent},
        services={ToolRegistry: registry, ...},
    )
```

The tool's input schema is derived from the agent's spec type. The sub-agent's
result is serialized and returned to the LLM as a tool result.

**Constraint:** the agent must have exactly one spec type (a single dataclass).
Union types are not supported — LLM APIs require `type: "object"` at the root
of the tool input schema.

### `make_agent_tool`

For agents you can't decorate (third-party, same agent under different names):

```python
from flowra.lib.tool_loop import make_agent_tool

poet_tool = make_agent_tool(PoetAgent, name="poet", description="Write a poem")
```

### `ToolCallAgentContext`

For custom delegation logic in regular tools:

```python
from flowra.lib.tool_loop import ToolCallAgentContext

@tool("delegate")
def delegate(params: DelegateParams, ctx: ToolCallAgentContext) -> None:
    ctx.call_agent(PoetAgent, PoetSpec(topic=params.topic))
```

The tool's return value is ignored — the sub-agent's result becomes the tool result.
`call_agent()` can only be called once per tool execution.

---

## ConfigValue

Configuration fields that can be static or dynamic:

```python
# Static
config = ToolLoopConfig(max_llm_calls=10, ...)

# Sync callable
config = ToolLoopConfig(max_llm_calls=lambda: settings.max_calls, ...)

# Async callable
config = ToolLoopConfig(max_llm_calls=get_max_llm_calls, ...)
```

## LLMConfig

Shared LLM configuration used by all lib agents:

```python
LLMConfig(
    model="claude-sonnet-4-5@20250929",
    temperature=0.7,           # optional
    max_tokens=4096,           # optional
    stop_sequences=["END"],    # optional
    additional_config={},      # provider-specific
)
```
