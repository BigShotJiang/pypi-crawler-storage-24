# Prompt: Package Structure and Responsibility Review

You are reviewing the internal structure of a Python package. Your goal is to verify that the package is well-organized: every file has a clear responsibility, file names match their contents, and the package as a whole forms a coherent unit with a clean public API.

## Context

You will be given:
- The full source code of every file in the package (including `__init__.py`)
- The package name

This library is brand new with no users — there are no backwards compatibility constraints. Any renaming, restructuring, or redesign is acceptable if it improves clarity.

## What to analyze

### Per-file analysis

For each `.py` file in the package (excluding `__init__.py`):

1. **Responsibility:** what is this file's single responsibility? State it in one sentence. If you can't — the file might be doing too much.
2. **Naming:** does the file name accurately describe its contents? After refactors, names can become stale (e.g. a file called `types.py` that now contains business logic, or `utils.py` that grew into a core module).
3. **Cohesion:** does everything in the file belong together? Look for:
   - Classes/functions that serve a different purpose than the file's main responsibility
   - Groups of related items that could be their own module
   - A single file doing two unrelated jobs

### Package-level analysis

4. **Package responsibility:** can you explain the package's purpose in one sentence? If not, it may be trying to do too much or its boundaries are unclear.
5. **File set:** do the files together cover the package's responsibility without gaps or overlaps? Look for:
   - Duplicated responsibilities across files
   - Missing files (a concept that should exist but doesn't have a home)
   - Files that don't belong in this package
6. **Internal dependency flow:** do the files form a clean dependency DAG within the package? Look for circular imports or tangled dependencies between modules.

### Public API analysis

7. **`__init__.py` exports:** review what the package exports via `__all__`:
   - Are all public types exported? Any missing?
   - Are there exports that shouldn't be public? (Internal implementation details leaking out)
   - Is the API convenient? Can a user import what they need without knowing the internal file structure?
   - Are the exported names clear and unambiguous?

## Output format

Produce a structured report:

```
# Structure Review: flowra.<package_name>

## Package responsibility
<One sentence describing the package's purpose>

## Per-file analysis

### <filename>.py
- **Responsibility:** <one sentence>
- **Name accuracy:** OK | ISSUE: <description>
- **Cohesion:** OK | ISSUE: <description>

### <filename>.py
...

## Package-level issues
<List any issues with the package as a whole, or "No issues found.">

## Public API issues
<List any issues with __init__.py / __all__, or "No issues found.">

## Summary
- Files reviewed: N
- Issues found: N
- <Numbered list of all issues, if any>
```

## Important

- Be specific. Don't say "this file seems unclear" — say exactly what's wrong and suggest a concrete fix.
- Don't flag things that are fine. Only report actual issues.
- Consider the package in isolation — don't review code style, documentation, or tests here. Those are separate steps.
- If a file starts with `_` (single underscore), it's internal to the package. It should NOT appear in `__all__` but may still have naming/cohesion issues.
