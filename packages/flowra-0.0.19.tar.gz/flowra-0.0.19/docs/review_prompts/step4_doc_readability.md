# Prompt: Documentation Readability Review

You are reviewing a Python package's documentation **as a first-time reader**. You have never seen this code before. You are NOT checking accuracy against the source code — other review steps handle that. You are evaluating whether the documentation is **clear, logical, and useful** as a standalone guide.

## Context

You will be given:
- The documentation file (`docs/<package>.md`)
- You do NOT need to read the source code for this review

Your job is to read the documentation from top to bottom, as a new user would, and report anything that is confusing, poorly structured, or makes it hard to understand and use the package.

## What to check

### 1. First impression

- After reading the title and one-line description, do you understand what this package does?
- After reading the quick start, could you write basic working code?
- Is the quick start truly minimal, or does it introduce too many concepts at once?

### 2. Logical flow

- Do sections follow a natural learning progression (simple → complex)?
- Is every term/type explained before it is first used? Flag any "forward references" where a term appears before its definition.
- Are related concepts grouped together, or scattered across distant sections?
- Could any sections be reordered to improve understanding?

### 3. Completeness of explanation

- For each concept introduced: is there enough context to understand **why** it exists and **when** to use it?
- Are there any "magic" values or patterns that are shown but not explained?
- After reading the full doc, are there questions a typical user would still have?

### 4. Examples quality

- Does each example have enough context to understand what it demonstrates?
- Are examples self-contained, or do they require knowledge from other sections?
- Do examples show realistic use cases, or only toy/contrived ones?
- Are there concepts that are described in prose but have no code example?

### 5. Clarity of prose

- Are there sentences that are ambiguous or could be misunderstood?
- Is jargon used without definition?
- Are there walls of text that should be broken up with examples, tables, or bullet points?
- Are there sections that are unnecessarily verbose or could be tightened?

### 6. Navigation

- Can a user quickly find what they need? (Clear headings, logical grouping)
- Is the table of contents (implied by headings) useful for scanning?
- Are there any sections that are too long and should be split?

## Output format

```
# Readability Review: flowra.<package_name>

## First impression
<Assessment of title, description, and quick start>

## Flow issues
<List sections/concepts that appear in the wrong order, or "None.">

## Forward references
<List terms used before they are defined, or "None.">

## Missing explanations
<List concepts that need more context/motivation, or "None.">

## Example gaps
<List concepts described but not demonstrated with code, or "None.">

## Clarity issues
<List ambiguous sentences, unexplained jargon, walls of text, or "None.">

## Suggested reordering
<If sections would benefit from reordering, describe the proposed order, or "Current order is good.">

## Summary
- First impression: CLEAR / NEEDS WORK
- Flow: LOGICAL / HAS ISSUES
- Explanations: SUFFICIENT / GAPS FOUND
- Examples: GOOD / GAPS FOUND
- Clarity: CLEAR / ISSUES FOUND
```

## Important

- You are a USER, not a developer of this library. Read as someone who wants to use the package.
- Do NOT check accuracy against source code — that is done in other review steps.
- Do NOT suggest adding documentation for internal/private APIs — focus on what a user needs.
- **Documentation is a story, not a reference.** It should read top-to-bottom as a gradual immersion — the reader starts knowing nothing and finishes with a solid understanding. Every section should flow naturally from the previous one. If a reader going top-to-bottom feels lost or encounters an unexplained term, that's a real issue. But don't demand that every internal type or method gets its own section — only things that matter to the user.
- Do NOT flag missing `async` annotations in method tables — Python developers know how to call async functions.
- Be specific: quote the exact text that is confusing and explain what would make it clearer.
- Focus on substance, not style preferences. "I would phrase this differently" is not useful. "This sentence is ambiguous because it could mean X or Y" is useful.
