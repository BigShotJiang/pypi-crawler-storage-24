import dataclasses

import pytest

from flowra.tools import McpToolGroup, create_local_tool_group, tool


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class Params:
    x: int


@tool("tool_a")
def tool_a(params: Params) -> str:
    """Tool A."""
    return str(params.x)


@tool("tool_b")
def tool_b() -> str:
    """Tool B."""
    return "b"


class TestLocalToolGroup:
    def test_create_with_prefix(self) -> None:
        group = create_local_tool_group([tool_a, tool_b], prefix="my_group")
        assert group.prefix == "my_group"
        assert len(group.tools) == 2
        assert group.tools[0].definition.name == "tool_a"
        assert group.tools[1].definition.name == "tool_b"

    def test_create_without_prefix(self) -> None:
        group = create_local_tool_group([tool_a, tool_b])
        assert group.prefix is None
        assert len(group.tools) == 2

    def test_undecorated_handler_raises(self) -> None:
        def plain() -> None:
            pass

        with pytest.raises(ValueError, match="is not decorated with @tool"):
            create_local_tool_group([plain])

    def test_duplicate_tool_names_raises(self) -> None:
        with pytest.raises(ValueError, match="Duplicate tool names"):
            create_local_tool_group([tool_a, tool_a])


class TestMcpToolGroup:
    def test_basic(self) -> None:
        group = McpToolGroup(url="http://localhost:8080/mcp")
        assert group.prefix is None
        assert group.url == "http://localhost:8080/mcp"
        assert group.headers is None

    def test_with_prefix(self) -> None:
        group = McpToolGroup(prefix="mcp", url="http://localhost/mcp")
        assert group.prefix == "mcp"

    def test_with_headers(self) -> None:
        group = McpToolGroup(url="http://localhost/mcp", headers={"X-Key": "val"})
        assert group.headers == {"X-Key": "val"}
