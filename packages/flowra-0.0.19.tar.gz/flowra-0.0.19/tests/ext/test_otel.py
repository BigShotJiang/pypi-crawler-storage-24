"""Tests for flowra.ext.otel — OpenTelemetry tracing via span-hooks."""

from collections.abc import Iterator
from contextlib import contextmanager
from typing import Any
from unittest.mock import MagicMock, patch

from opentelemetry.trace import SpanKind, StatusCode

from flowra.agent import AgentInfo, AgentSpan, ExecutionContext, ExecutionFrame, HookEmitter, HookSubscription, StepSpan
from flowra.agent.flow import fork_flowing_context, restore_flowing_context
from flowra.ext.otel import install_otel_tracing
from flowra.llm import (
    AssistantMessage,
    LLMCallSpan,
    LLMRequest,
    LLMResponse,
    StopReason,
    TextBlock,
    ToolCallSpan,
    ToolUseBlock,
    Usage,
)


def _make_agent_info(name: str = "test", path: str = "test") -> AgentInfo:
    return AgentInfo(name=name, path=path, source_type=None, parent=None)


def _make_context(agent_info: AgentInfo | None = None) -> ExecutionContext:
    agent = agent_info or _make_agent_info()
    frame = ExecutionFrame(agent=agent, spec=None, tag=None)
    return ExecutionContext(frame=frame, stack=(frame,))


@contextmanager
def _flowing() -> Iterator[None]:
    token = fork_flowing_context()
    try:
        yield
    finally:
        restore_flowing_context(token)


def _emitter(sub: HookSubscription, agent_info: AgentInfo | None = None) -> HookEmitter:
    ctx = _make_context(agent_info)
    return HookEmitter(sub.get_handlers(), ctx, span_handlers=sub.get_span_handlers())


class _OtelContext:
    def __init__(self) -> None:
        self.spans: list[MagicMock] = []


def _install(hooks: HookSubscription, **kwargs: Any) -> tuple[MagicMock, _OtelContext]:
    """Install tracing with mocked OTel tracer. Returns (mock_tracer, context)."""
    ctx = _OtelContext()
    mock_tracer = MagicMock()

    def _fake_start_span(name: str, **kw: Any) -> MagicMock:
        span = MagicMock()
        span.name = name
        ctx.spans.append(span)
        return span

    mock_tracer.start_span.side_effect = _fake_start_span

    with patch("flowra.ext.otel.trace") as mock_trace:
        mock_trace.get_tracer.return_value = mock_tracer
        mock_trace.set_span_in_context = lambda span: MagicMock()
        mock_trace.SpanKind = SpanKind
        install_otel_tracing(hooks, **kwargs)

    return mock_tracer, ctx


class TestInstallOtelTracing:
    def test_registers_span_handlers(self) -> None:
        hooks = HookSubscription()
        _install(hooks)
        assert hooks.has_span_handlers(AgentSpan)
        assert hooks.has_span_handlers(StepSpan)
        assert hooks.has_span_handlers(LLMCallSpan)
        assert hooks.has_span_handlers(ToolCallSpan)

    def test_disable_steps(self) -> None:
        hooks = HookSubscription()
        _install(hooks, trace_steps=False)
        assert not hooks.has_span_handlers(StepSpan)


class TestAgentSpanTracing:
    async def test_root_agent_creates_span(self) -> None:
        hooks = HookSubscription()
        mock_tracer, octx = _install(hooks)

        agent_info = _make_agent_info(path="my_agent", name="my_agent")
        emitter = _emitter(hooks, agent_info)
        span = AgentSpan(agent_info=agent_info, spec=None)

        with _flowing():
            await emitter.open_span(span)
            await emitter.close_span(span)

        mock_tracer.start_span.assert_called_once()
        kw = mock_tracer.start_span.call_args
        assert kw[0][0] == "invoke_agent my_agent"
        octx.spans[0].set_status.assert_called_with(StatusCode.OK)
        octx.spans[0].end.assert_called_once()

    async def test_child_agent_has_parent(self) -> None:
        hooks = HookSubscription()
        mock_tracer, _octx = _install(hooks)

        parent_info = _make_agent_info(path="parent", name="parent")
        child_info = _make_agent_info(path="parent/child", name="child")

        parent_emitter = _emitter(hooks, parent_info)
        child_emitter = _emitter(hooks, child_info)

        with _flowing():
            await parent_emitter.open_span(AgentSpan(agent_info=parent_info, spec=None))
            with _flowing():
                await child_emitter.open_span(AgentSpan(agent_info=child_info, spec=None))

        assert mock_tracer.start_span.call_count == 2
        # Child call should have context (parent set)
        child_call = mock_tracer.start_span.call_args_list[1]
        assert child_call[1].get("context") is not None

    async def test_error_sets_status(self) -> None:
        hooks = HookSubscription()
        _mock_tracer, octx = _install(hooks)

        agent_info = _make_agent_info()
        emitter = _emitter(hooks, agent_info)
        span = AgentSpan(agent_info=agent_info, spec=None)

        with _flowing():
            await emitter.open_span(span)
            await emitter.close_span(span, error=RuntimeError("boom"))

        octx.spans[0].set_status.assert_called_with(StatusCode.ERROR, description="boom")
        octx.spans[0].set_attribute.assert_any_call("error.type", "RuntimeError")
        octx.spans[0].record_exception.assert_called_once()


class TestLLMCallSpanTracing:
    async def test_llm_span_with_genai_attributes(self) -> None:
        hooks = HookSubscription()
        mock_tracer, octx = _install(hooks)

        agent_info = _make_agent_info()
        emitter = _emitter(hooks, agent_info)

        with _flowing():
            await emitter.open_span(AgentSpan(agent_info=agent_info, spec=None))

            request = LLMRequest(model="anthropic/claude-test", messages=[], tools=[], temperature=0.5)
            llm_span = LLMCallSpan(request=request)
            await emitter.open_span(llm_span)

            assert mock_tracer.start_span.call_count == 2
            llm_call = mock_tracer.start_span.call_args_list[1]
            assert llm_call[0][0] == "chat claude-test"
            attrs = llm_call[1]["attributes"]
            assert attrs["gen_ai.operation.name"] == "chat"
            assert attrs["gen_ai.provider.name"] == "anthropic"
            assert attrs["gen_ai.request.model"] == "claude-test"
            assert attrs["gen_ai.request.temperature"] == 0.5

            llm_span.response = LLMResponse(
                message=AssistantMessage(blocks=[TextBlock(text="hello")]),
                stop_reason=StopReason.END_TURN,
                usage=Usage(input_tokens=100, output_tokens=20, cost_usd=0.01),
            )
            await emitter.close_span(llm_span)

        # Verify usage attributes were set on the LLM span mock
        octx.spans[1].set_attribute.assert_any_call("gen_ai.usage.input_tokens", 100)
        octx.spans[1].set_attribute.assert_any_call("gen_ai.usage.output_tokens", 20)

    async def test_llm_span_without_parent_is_noop(self) -> None:
        hooks = HookSubscription()
        mock_tracer, _octx = _install(hooks)

        emitter = _emitter(hooks)
        request = LLMRequest(model="test/model", messages=[], tools=[])
        llm_span = LLMCallSpan(request=request)
        await emitter.open_span(llm_span)
        await emitter.close_span(llm_span)

        mock_tracer.start_span.assert_not_called()


class TestToolCallSpanTracing:
    async def test_tool_span_with_genai_attributes(self) -> None:
        hooks = HookSubscription()
        mock_tracer, _octx = _install(hooks)

        agent_info = _make_agent_info()
        emitter = _emitter(hooks, agent_info)

        with _flowing():
            await emitter.open_span(AgentSpan(agent_info=agent_info, spec=None))

            tool_use = ToolUseBlock(id="tu-1", name="calculate", input={"expr": "2+2"})
            tool_span = ToolCallSpan(tool_use=tool_use)
            await emitter.open_span(tool_span)

            assert mock_tracer.start_span.call_count == 2
            tool_call = mock_tracer.start_span.call_args_list[1]
            assert tool_call[0][0] == "execute_tool calculate"
            attrs = tool_call[1]["attributes"]
            assert attrs["gen_ai.tool.name"] == "calculate"
            assert attrs["gen_ai.tool.call.id"] == "tu-1"
            assert "gen_ai.tool.call.arguments" not in attrs  # capture_content=False

    async def test_capture_content_includes_arguments(self) -> None:
        hooks = HookSubscription()
        mock_tracer, _octx = _install(hooks, capture_content=True)

        agent_info = _make_agent_info()
        emitter = _emitter(hooks, agent_info)

        with _flowing():
            await emitter.open_span(AgentSpan(agent_info=agent_info, spec=None))

            tool_use = ToolUseBlock(id="tu-1", name="calc", input={"a": 1})
            tool_span = ToolCallSpan(tool_use=tool_use)
            await emitter.open_span(tool_span)

            tool_call = mock_tracer.start_span.call_args_list[1]
            attrs = tool_call[1]["attributes"]
            assert "gen_ai.tool.call.arguments" in attrs


class TestSessionId:
    async def test_session_id_set_on_agent_span(self) -> None:
        hooks = HookSubscription()
        mock_tracer, _octx = _install(hooks, session_id="sess-42")

        agent_info = _make_agent_info()
        emitter = _emitter(hooks, agent_info)

        with _flowing():
            await emitter.open_span(AgentSpan(agent_info=agent_info, spec=None))

        attrs = mock_tracer.start_span.call_args[1]["attributes"]
        assert attrs["gen_ai.conversation.id"] == "sess-42"


class TestSiblingChildren:
    async def test_siblings_have_same_parent(self) -> None:
        hooks = HookSubscription()
        mock_tracer, _octx = _install(hooks)

        parent_info = _make_agent_info(path="root", name="root")
        child0_info = _make_agent_info(path="root/tool_call", name="tool_call")
        child1_info = _make_agent_info(path="root/tool_call", name="tool_call")

        parent_emitter = _emitter(hooks, parent_info)
        child0_emitter = _emitter(hooks, child0_info)
        child1_emitter = _emitter(hooks, child1_info)

        with _flowing():
            await parent_emitter.open_span(AgentSpan(agent_info=parent_info, spec=None))

            with _flowing():
                await child0_emitter.open_span(AgentSpan(agent_info=child0_info, spec=None))

            with _flowing():
                await child1_emitter.open_span(AgentSpan(agent_info=child1_info, spec=None))

        assert mock_tracer.start_span.call_count == 3
        # Both children should have context set (meaning they have a parent)
        child0_call = mock_tracer.start_span.call_args_list[1]
        child1_call = mock_tracer.start_span.call_args_list[2]
        assert child0_call[1].get("context") is not None
        assert child1_call[1].get("context") is not None
        # Both should have the same parent context
        assert child0_call[1]["context"] == child1_call[1]["context"]
