from flowra.lib.tool_loop.config import matches_tool_filter


class TestMatchesToolFilter:
    def test_exact_match(self) -> None:
        assert matches_tool_filter("add", {"add"})

    def test_exact_no_match(self) -> None:
        assert not matches_tool_filter("add", {"subtract"})

    def test_wildcard_star(self) -> None:
        assert matches_tool_filter("mcp_search", {"mcp_*"})

    def test_wildcard_star_no_match(self) -> None:
        assert not matches_tool_filter("add", {"mcp_*"})

    def test_wildcard_question_mark(self) -> None:
        assert matches_tool_filter("tool_a", {"tool_?"})
        assert not matches_tool_filter("tool_ab", {"tool_?"})

    def test_multiple_patterns(self) -> None:
        assert matches_tool_filter("mcp_search", {"add", "mcp_*"})
        assert matches_tool_filter("add", {"add", "mcp_*"})
        assert not matches_tool_filter("subtract", {"add", "mcp_*"})

    def test_star_matches_all(self) -> None:
        assert matches_tool_filter("anything", {"*"})

    def test_mixed_exact_and_wildcard(self) -> None:
        assert matches_tool_filter("debug_trace", {"debug_*", "add"})
        assert matches_tool_filter("add", {"debug_*", "add"})
        assert not matches_tool_filter("subtract", {"debug_*", "add"})
