import base64
import json
import os
from collections.abc import AsyncIterator

import pytest
from anthropic import AsyncAnthropicVertex
from google.oauth2 import service_account

from flowra.llm import (
    ContentComplete,
    LLMRequest,
    StopReason,
    SystemMessage,
    TextBlock,
    TextDelta,
    ThinkingBlock,
    ThinkingDelta,
    Tool,
    ToolResultBlock,
    ToolUseBlock,
    UserMessage,
)
from flowra.llm.providers.anthropic_vertex import AnthropicVertexProvider


@pytest.fixture
async def provider() -> AsyncIterator[AnthropicVertexProvider]:
    project = os.environ["VERTEX_PROJECT_NAME"]
    location = os.environ["VERTEX_LOCATION"]
    creds_json = base64.b64decode(os.environ["VERTEX_CREDENTIALS"].encode()).decode()
    creds_info = json.loads(creds_json)
    creds = service_account.Credentials.from_service_account_info(creds_info).with_scopes(
        ["https://www.googleapis.com/auth/cloud-platform.read-only"]
    )
    client = AsyncAnthropicVertex(region=location, project_id=project, credentials=creds)
    async with AnthropicVertexProvider(client=client, owns_client=True) as p:
        yield p


async def test_simple_text_response(provider: AnthropicVertexProvider) -> None:
    request = LLMRequest(
        model="claude-haiku-4-5@20251001",
        messages=[
            UserMessage(blocks=[TextBlock(text="Reply with exactly: hello")]),
        ],
        max_tokens=64,
    )
    response = await provider.call(request)
    print(response)

    assert response.stop_reason == StopReason.END_TURN
    assert len(response.message.blocks) > 0
    text = "".join(b.text for b in response.message.blocks if isinstance(b, TextBlock))
    assert "hello" in text.lower()


async def test_system_message(provider: AnthropicVertexProvider) -> None:
    request = LLMRequest(
        model="claude-haiku-4-5@20251001",
        system=[
            SystemMessage(blocks=[TextBlock(text="You are a bot that only replies with the word 'pong'.")]),
        ],
        messages=[
            UserMessage(blocks=[TextBlock(text="ping")]),
        ],
        max_tokens=64,
    )
    response = await provider.call(request)
    print(response)

    assert response.stop_reason == StopReason.END_TURN
    text = "".join(b.text for b in response.message.blocks if isinstance(b, TextBlock))
    assert "pong" in text.lower()


async def test_multiple_system_messages(provider: AnthropicVertexProvider) -> None:
    request = LLMRequest(
        model="claude-haiku-4-5@20251001",
        system=[
            SystemMessage(blocks=[TextBlock(text="You are a bot that only replies in uppercase.")]),
            SystemMessage(blocks=[TextBlock(text="You must always start your reply with 'OK:'.")]),
        ],
        messages=[
            UserMessage(blocks=[TextBlock(text="hi")]),
        ],
        max_tokens=64,
    )
    response = await provider.call(request)
    print(response)

    assert response.stop_reason == StopReason.END_TURN
    text = "".join(b.text for b in response.message.blocks if isinstance(b, TextBlock))
    assert text.startswith("OK:")
    # After "OK:" the rest should be uppercase
    after_prefix = text[3:].strip()
    assert after_prefix == after_prefix.upper()


async def test_tool_use(provider: AnthropicVertexProvider) -> None:
    tool = Tool(
        name="get_weather",
        description="Get the current weather for a city.",
        input_schema={
            "type": "object",
            "properties": {
                "city": {"type": "string", "description": "City name"},
            },
            "required": ["city"],
        },
    )
    request = LLMRequest(
        model="claude-haiku-4-5@20251001",
        messages=[
            UserMessage(blocks=[TextBlock(text="What's the weather in Paris?")]),
        ],
        tools=[tool],
        max_tokens=256,
    )
    response = await provider.call(request)
    print(response)

    assert response.stop_reason == StopReason.TOOL_USE
    tool_uses = [b for b in response.message.blocks if isinstance(b, ToolUseBlock)]
    assert len(tool_uses) == 1
    assert tool_uses[0].name == "get_weather"
    assert tool_uses[0].input["city"].lower() == "paris"
    assert tool_uses[0].id != ""


async def test_tool_use_roundtrip(provider: AnthropicVertexProvider) -> None:
    tool = Tool(
        name="get_temperature",
        description="Get temperature for a city. Returns temperature in Celsius.",
        input_schema={
            "type": "object",
            "properties": {
                "city": {"type": "string"},
            },
            "required": ["city"],
        },
    )

    # First call: LLM should request tool use
    request1 = LLMRequest(
        model="claude-haiku-4-5@20251001",
        messages=[
            UserMessage(blocks=[TextBlock(text="What is the temperature in London?")]),
        ],
        tools=[tool],
        max_tokens=256,
    )
    response1 = await provider.call(request1)
    print(response1)

    assert response1.stop_reason == StopReason.TOOL_USE
    tool_use = next(b for b in response1.message.blocks if isinstance(b, ToolUseBlock))

    # Second call: provide tool result, LLM should respond with text
    request2 = LLMRequest(
        model="claude-haiku-4-5@20251001",
        messages=[
            UserMessage(blocks=[TextBlock(text="What is the temperature in London?")]),
            response1.message,
            UserMessage(blocks=[ToolResultBlock(tool_use_id=tool_use.id, content="15")]),
        ],
        tools=[tool],
        max_tokens=256,
    )
    response2 = await provider.call(request2)
    print(response2)

    assert response2.stop_reason == StopReason.END_TURN
    text = "".join(b.text for b in response2.message.blocks if isinstance(b, TextBlock))
    assert "15" in text


async def test_json_schema(provider: AnthropicVertexProvider) -> None:
    request = LLMRequest(
        model="claude-haiku-4-5@20251001",
        messages=[
            UserMessage(blocks=[TextBlock(text="List three European capital cities.")]),
        ],
        json_schema={
            "type": "object",
            "properties": {
                "cities": {
                    "type": "array",
                    "items": {"type": "string"},
                },
            },
            "required": ["cities"],
        },
        max_tokens=256,
    )
    response = await provider.call(request)
    print(response)

    assert response.stop_reason == StopReason.END_TURN
    text = "".join(b.text for b in response.message.blocks if isinstance(b, TextBlock))
    # Provider must strip markdown fences — text should be clean JSON
    parsed = json.loads(text)
    assert "cities" in parsed
    assert isinstance(parsed["cities"], list)
    assert len(parsed["cities"]) == 3


async def test_stop_sequence(provider: AnthropicVertexProvider) -> None:
    request = LLMRequest(
        model="claude-haiku-4-5@20251001",
        messages=[
            UserMessage(blocks=[TextBlock(text="Count from 1 to 10, one number per line.")]),
        ],
        stop_sequences=["5"],
        max_tokens=256,
    )
    response = await provider.call(request)
    print(response)

    assert response.stop_reason == StopReason.STOP_SEQUENCE
    assert response.stop_sequence == "5"
    text = "".join(b.text for b in response.message.blocks if isinstance(b, TextBlock))
    assert "5" not in text


async def test_usage_is_returned(provider: AnthropicVertexProvider) -> None:
    request = LLMRequest(
        model="claude-haiku-4-5@20251001",
        messages=[
            UserMessage(blocks=[TextBlock(text="Say hi")]),
        ],
        max_tokens=64,
    )
    response = await provider.call(request)
    print(response)

    assert response.usage is not None
    assert response.usage.input_tokens > 0
    assert response.usage.output_tokens > 0


async def test_prompt_caching_does_not_error(provider: AnthropicVertexProvider) -> None:
    request = LLMRequest(
        model="claude-haiku-4-5@20251001",
        system=[
            SystemMessage(
                blocks=[
                    TextBlock(
                        text="You are a helpful assistant. " * 500, extra={"cache_control": {"type": "ephemeral"}}
                    )
                ]
            ),
        ],
        messages=[
            UserMessage(blocks=[TextBlock(text="Say hello")]),
        ],
        max_tokens=64,
    )
    response = await provider.call(request)
    print(response)

    assert response.stop_reason == StopReason.END_TURN
    assert response.usage is not None


async def test_stream_simple_text(provider: AnthropicVertexProvider) -> None:
    request = LLMRequest(
        model="claude-haiku-4-5@20251001",
        messages=[
            UserMessage(blocks=[TextBlock(text="Reply with exactly: hello")]),
        ],
        max_tokens=64,
    )

    events = []
    async for event in provider.stream(request):
        events.append(event)

    # Should have text deltas and a final ContentComplete
    text_deltas = [e for e in events if isinstance(e, TextDelta)]
    completes = [e for e in events if isinstance(e, ContentComplete)]
    assert len(text_deltas) > 0
    assert len(completes) == 1
    assert completes[0].response.stop_reason == StopReason.END_TURN

    # Concatenated deltas should match the full response text
    delta_text = "".join(d.text for d in text_deltas)
    full_text = "".join(b.text for b in completes[0].response.message.blocks if isinstance(b, TextBlock))
    assert delta_text == full_text


async def test_extended_thinking(provider: AnthropicVertexProvider) -> None:
    request = LLMRequest(
        model="claude-sonnet-4-5@20250929",
        messages=[
            UserMessage(blocks=[TextBlock(text="What is 15 * 37? Think step by step.")]),
        ],
        max_tokens=8192,
        additional_config={"thinking_budget_tokens": 4000},
    )
    response = await provider.call(request)
    print(response)

    assert response.stop_reason == StopReason.END_TURN
    thinking_blocks = [b for b in response.message.blocks if isinstance(b, ThinkingBlock)]
    text_blocks = [b for b in response.message.blocks if isinstance(b, TextBlock)]
    assert len(thinking_blocks) > 0
    assert len(text_blocks) > 0
    assert "555" in text_blocks[0].text


async def test_stream_thinking(provider: AnthropicVertexProvider) -> None:
    request = LLMRequest(
        model="claude-sonnet-4-5@20250929",
        messages=[
            UserMessage(blocks=[TextBlock(text="What is 15 * 37? Think step by step.")]),
        ],
        max_tokens=8192,
        additional_config={"thinking_budget_tokens": 4000},
    )

    events = []
    async for event in provider.stream(request):
        events.append(event)

    thinking_deltas = [e for e in events if isinstance(e, ThinkingDelta)]
    text_deltas = [e for e in events if isinstance(e, TextDelta)]
    completes = [e for e in events if isinstance(e, ContentComplete)]

    assert len(thinking_deltas) > 0
    assert len(text_deltas) > 0
    assert len(completes) == 1
    assert completes[0].response.stop_reason == StopReason.END_TURN


async def test_tool_use_with_union_schema(provider: AnthropicVertexProvider) -> None:
    import dataclasses

    import marshmallow_recipe as mr

    @dataclasses.dataclass
    class Dog:
        breed: str

    @dataclasses.dataclass
    class Cat:
        color: str

    @dataclasses.dataclass
    class AnimalSpec:
        animal: Dog | Cat
        nickname: str

    schema = mr.json_schema(AnimalSpec)
    tool = Tool(
        name="register_animal",
        description="Register an animal. If it's a dog, provide breed. If it's a cat, provide color.",
        input_schema=schema,
    )
    request = LLMRequest(
        model="claude-haiku-4-5@20251001",
        messages=[
            UserMessage(blocks=[TextBlock(text="Register a golden retriever dog with nickname Buddy.")]),
        ],
        tools=[tool],
        max_tokens=256,
    )
    response = await provider.call(request)
    print(response)

    assert response.stop_reason == StopReason.TOOL_USE
    tool_uses = [b for b in response.message.blocks if isinstance(b, ToolUseBlock)]
    assert len(tool_uses) == 1
    assert tool_uses[0].name == "register_animal"

    spec = mr.load(AnimalSpec, tool_uses[0].input)
    assert isinstance(spec.animal, Dog)
    assert "retriever" in spec.animal.breed.lower() or "golden" in spec.animal.breed.lower()
    assert "buddy" in spec.nickname.lower()


async def test_json_schema_with_union(provider: AnthropicVertexProvider) -> None:
    import dataclasses

    import marshmallow_recipe as mr

    @dataclasses.dataclass
    class Dog:
        breed: str

    @dataclasses.dataclass
    class Cat:
        color: str

    @dataclasses.dataclass
    class AnimalSpec:
        animal: Dog | Cat
        nickname: str

    schema = mr.json_schema(AnimalSpec)

    request_dog = LLMRequest(
        model="claude-haiku-4-5@20251001",
        messages=[
            UserMessage(blocks=[TextBlock(text="Describe a golden retriever dog named Buddy.")]),
        ],
        json_schema=schema,
        max_tokens=256,
    )
    response = await provider.call(request_dog)
    print(response)
    text = "".join(b.text for b in response.message.blocks if isinstance(b, TextBlock))
    spec = mr.load(AnimalSpec, json.loads(text))
    assert isinstance(spec.animal, Dog)
    assert "buddy" in spec.nickname.lower()

    request_cat = LLMRequest(
        model="claude-haiku-4-5@20251001",
        messages=[
            UserMessage(blocks=[TextBlock(text="Describe a black cat named Whiskers.")]),
        ],
        json_schema=schema,
        max_tokens=256,
    )
    response = await provider.call(request_cat)
    print(response)
    text = "".join(b.text for b in response.message.blocks if isinstance(b, TextBlock))
    spec = mr.load(AnimalSpec, json.loads(text))
    assert isinstance(spec.animal, Cat)
    assert "whiskers" in spec.nickname.lower()


async def test_max_tokens_truncation(provider: AnthropicVertexProvider) -> None:
    request = LLMRequest(
        model="claude-haiku-4-5@20251001",
        messages=[
            UserMessage(blocks=[TextBlock(text="Write a long essay about the history of mathematics.")]),
        ],
        max_tokens=5,
    )
    response = await provider.call(request)
    print(response)

    assert response.stop_reason == StopReason.MAX_TOKENS
