import base64
from typing import Any
from unittest.mock import AsyncMock, MagicMock

import pytest
from google.genai import types as genai_types

from flowra.llm import (
    AssistantMessage,
    ImageBlock,
    LLMRequest,
    StopReason,
    TextBlock,
    ThinkingBlock,
    ToolResultBlock,
    ToolUseBlock,
    UserMessage,
)
from flowra.llm.providers.google_vertex import GoogleVertexProvider


@pytest.fixture
def mock_client() -> MagicMock:
    return MagicMock()


@pytest.fixture
def provider(mock_client: MagicMock) -> GoogleVertexProvider:
    return GoogleVertexProvider(client=mock_client)


def _mock_response(
    parts: list[genai_types.Part],
    finish_reason: str = "STOP",
) -> genai_types.GenerateContentResponse:
    candidate = MagicMock()
    candidate.content = MagicMock()
    candidate.content.parts = parts
    candidate.finish_reason = finish_reason

    response = MagicMock(spec=genai_types.GenerateContentResponse)
    response.candidates = [candidate]
    response.usage_metadata = MagicMock()
    response.usage_metadata.prompt_token_count = 10
    response.usage_metadata.candidates_token_count = 20
    response.usage_metadata.cached_content_token_count = 0
    response.usage_metadata.thoughts_token_count = 0
    return response


class TestThoughtSignature:
    async def test_thought_signature_preserved_in_response(
        self, provider: GoogleVertexProvider, mock_client: MagicMock
    ) -> None:
        """thought_signature from Gemini response is stored as base64 string in ToolUseBlock."""
        signature_bytes = b"test-thought-signature"
        signature_b64 = base64.b64encode(signature_bytes).decode()

        fc_part = MagicMock()
        fc_part.thought = False
        fc_part.text = None
        fc_part.function_call = MagicMock()
        fc_part.function_call.name = "get_weather"
        fc_part.function_call.args = {"city": "Paris"}
        fc_part.thought_signature = signature_bytes

        response = _mock_response([fc_part])
        mock_client.aio.models.generate_content = AsyncMock(return_value=response)

        result = await provider.call(
            LLMRequest(
                model="test",
                messages=[UserMessage(blocks=[TextBlock(text="weather?")])],
            )
        )

        assert result.stop_reason == StopReason.TOOL_USE
        assert len(result.message.blocks) == 1
        tool_block = result.message.blocks[0]
        assert isinstance(tool_block, ToolUseBlock)
        assert tool_block.extra.get("thought_signature") == signature_b64
        assert tool_block.name == "get_weather"

    async def test_thought_signature_sent_back_in_request(
        self, provider: GoogleVertexProvider, mock_client: MagicMock
    ) -> None:
        """thought_signature base64 string from ToolUseBlock is decoded back to bytes for Gemini."""
        signature_bytes = b"test-thought-signature"
        signature_b64 = base64.b64encode(signature_bytes).decode()

        text_response = MagicMock()
        text_response.thought = False
        text_response.text = "Done"
        text_response.function_call = None
        text_response.thought_signature = None

        response = _mock_response([text_response])
        mock_generate = AsyncMock(return_value=response)
        mock_client.aio.models.generate_content = mock_generate

        await provider.call(
            LLMRequest(
                model="test",
                messages=[
                    UserMessage(blocks=[TextBlock(text="weather?")]),
                    AssistantMessage(
                        blocks=[
                            ToolUseBlock(
                                id="call_1",
                                name="get_weather",
                                input={"city": "Paris"},
                                extra={"thought_signature": signature_b64},
                            ),
                        ]
                    ),
                    UserMessage(
                        blocks=[
                            ToolResultBlock(tool_use_id="call_1", content='{"temp": 20}'),
                        ]
                    ),
                ],
            )
        )

        call_args = mock_generate.call_args
        contents = call_args.kwargs["contents"]
        # Find the model (assistant) content
        model_content = [c for c in contents if c.role == "model"]
        assert len(model_content) == 1
        fc_part = model_content[0].parts[0]
        assert fc_part.thought_signature == signature_bytes

    async def test_thinking_parts_converted_to_thinking_block(
        self, provider: GoogleVertexProvider, mock_client: MagicMock
    ) -> None:
        """Parts with thought=True are converted to ThinkingBlock."""
        thinking_part = MagicMock()
        thinking_part.thought = True
        thinking_part.text = "Let me think..."
        thinking_part.function_call = None
        thinking_part.thought_signature = None

        text_part = MagicMock()
        text_part.thought = False
        text_part.text = "The answer is 42"
        text_part.function_call = None
        text_part.thought_signature = None

        response = _mock_response([thinking_part, text_part])
        mock_client.aio.models.generate_content = AsyncMock(return_value=response)

        result = await provider.call(
            LLMRequest(
                model="test",
                messages=[UserMessage(blocks=[TextBlock(text="question")])],
            )
        )

        assert len(result.message.blocks) == 2
        assert isinstance(result.message.blocks[0], ThinkingBlock)
        assert result.message.blocks[0].text == "Let me think..."
        assert isinstance(result.message.blocks[1], TextBlock)
        assert result.message.blocks[1].text == "The answer is 42"

    async def test_thinking_block_sent_back_with_thought_flag(
        self, provider: GoogleVertexProvider, mock_client: MagicMock
    ) -> None:
        """ThinkingBlock in AssistantMessage is sent back to Gemini with thought=True."""
        text_response = MagicMock()
        text_response.thought = False
        text_response.text = "Done"
        text_response.function_call = None
        text_response.thought_signature = None

        response = _mock_response([text_response])
        mock_generate = AsyncMock(return_value=response)
        mock_client.aio.models.generate_content = mock_generate

        await provider.call(
            LLMRequest(
                model="test",
                messages=[
                    UserMessage(blocks=[TextBlock(text="question")]),
                    AssistantMessage(
                        blocks=[
                            ThinkingBlock(text="internal reasoning"),
                            TextBlock(text="visible answer"),
                        ]
                    ),
                    UserMessage(blocks=[TextBlock(text="follow up")]),
                ],
            )
        )

        call_args = mock_generate.call_args
        contents = call_args.kwargs["contents"]
        model_content = [c for c in contents if c.role == "model"]
        assert len(model_content) == 1
        assert len(model_content[0].parts) == 2
        # ThinkingBlock is sent back with thought=True
        thinking_part = model_content[0].parts[0]
        assert thinking_part.text == "internal reasoning"
        assert thinking_part.thought is True
        # TextBlock follows
        text_part = model_content[0].parts[1]
        assert text_part.text == "visible answer"

    async def test_thoughts_tokens_in_usage(self, provider: GoogleVertexProvider, mock_client: MagicMock) -> None:
        """thoughts_token_count is stored in usage.extra."""
        text_part = MagicMock()
        text_part.thought = False
        text_part.text = "answer"
        text_part.function_call = None
        text_part.thought_signature = None

        response = _mock_response([text_part])
        assert response.usage_metadata is not None
        response.usage_metadata.thoughts_token_count = 500
        mock_client.aio.models.generate_content = AsyncMock(return_value=response)

        result = await provider.call(
            LLMRequest(
                model="test",
                messages=[UserMessage(blocks=[TextBlock(text="question")])],
            )
        )

        assert result.usage is not None
        assert result.usage.extra["thoughts_tokens"] == 500


class TestConstructorValidation:
    def test_no_args_raises_value_error(self) -> None:
        with pytest.raises(ValueError, match="Either 'client' or all of"):
            GoogleVertexProvider()

    def test_partial_args_raises_value_error(self) -> None:
        with pytest.raises(ValueError, match="Either 'client' or all of"):
            GoogleVertexProvider(project="x", location="y")


class TestSchemaAdaptation:
    async def test_refs_flattened_inline(self, provider: GoogleVertexProvider, mock_client: MagicMock) -> None:
        """Schema with $defs and $ref gets refs flattened."""
        text_part = MagicMock()
        text_part.thought = False
        text_part.text = '{"item": {"value": "hello"}}'
        text_part.function_call = None
        text_part.thought_signature = None

        response = _mock_response([text_part])
        mock_generate = AsyncMock(return_value=response)
        mock_client.aio.models.generate_content = mock_generate

        schema: dict[str, Any] = {
            "type": "object",
            "properties": {
                "item": {"$ref": "#/$defs/Item"},
            },
            "$defs": {
                "Item": {
                    "type": "object",
                    "properties": {"value": {"type": "string"}},
                },
            },
        }
        request = LLMRequest(
            model="test",
            messages=[UserMessage(blocks=[TextBlock(text="json please")])],
            json_schema=schema,
        )
        await provider.call(request)

        call_kwargs = mock_generate.call_args.kwargs
        adapted_schema = call_kwargs["config"].response_schema

        # $defs should be removed and $ref should be replaced with inline definition
        assert "$defs" not in adapted_schema
        item_prop = adapted_schema["properties"]["item"]
        assert "$ref" not in item_prop
        assert item_prop["type"] == "object"
        assert "value" in item_prop["properties"]

    async def test_additional_properties_and_schema_stripped(
        self, provider: GoogleVertexProvider, mock_client: MagicMock
    ) -> None:
        """additionalProperties and $schema keys are stripped."""
        text_part = MagicMock()
        text_part.thought = False
        text_part.text = '{"name": "test"}'
        text_part.function_call = None
        text_part.thought_signature = None

        response = _mock_response([text_part])
        mock_generate = AsyncMock(return_value=response)
        mock_client.aio.models.generate_content = mock_generate

        schema: dict[str, Any] = {
            "$schema": "http://json-schema.org/draft-07/schema#",
            "type": "object",
            "properties": {
                "name": {"type": "string"},
            },
            "additionalProperties": False,
        }
        request = LLMRequest(
            model="test",
            messages=[UserMessage(blocks=[TextBlock(text="json please")])],
            json_schema=schema,
        )
        await provider.call(request)

        call_kwargs = mock_generate.call_args.kwargs
        adapted_schema = call_kwargs["config"].response_schema

        assert "$schema" not in adapted_schema
        assert "additionalProperties" not in adapted_schema

    async def test_type_arrays_converted_to_anyof(self, provider: GoogleVertexProvider, mock_client: MagicMock) -> None:
        """Type arrays converted to anyOf."""
        text_part = MagicMock()
        text_part.thought = False
        text_part.text = '{"value": "test"}'
        text_part.function_call = None
        text_part.thought_signature = None

        response = _mock_response([text_part])
        mock_generate = AsyncMock(return_value=response)
        mock_client.aio.models.generate_content = mock_generate

        schema: dict[str, Any] = {
            "type": "object",
            "properties": {
                "value": {"type": ["string", "null"]},
            },
        }
        request = LLMRequest(
            model="test",
            messages=[UserMessage(blocks=[TextBlock(text="json please")])],
            json_schema=schema,
        )
        await provider.call(request)

        call_kwargs = mock_generate.call_args.kwargs
        adapted_schema = call_kwargs["config"].response_schema

        value_prop = adapted_schema["properties"]["value"]
        assert "type" not in value_prop
        assert "anyOf" in value_prop
        assert {"type": "string"} in value_prop["anyOf"]
        assert {"type": "null"} in value_prop["anyOf"]


class TestAdditionalConfig:
    async def test_thinking_level_config(self, provider: GoogleVertexProvider, mock_client: MagicMock) -> None:
        """additional_config with thinking_level passes ThinkingConfig to API."""
        text_part = MagicMock()
        text_part.thought = False
        text_part.text = "answer"
        text_part.function_call = None
        text_part.thought_signature = None

        response = _mock_response([text_part])
        mock_generate = AsyncMock(return_value=response)
        mock_client.aio.models.generate_content = mock_generate

        await provider.call(
            LLMRequest(
                model="test",
                messages=[UserMessage(blocks=[TextBlock(text="question")])],
                additional_config={"thinking_level": "MEDIUM"},
            )
        )

        call_kwargs = mock_generate.call_args.kwargs
        thinking_config = call_kwargs["config"].thinking_config
        assert thinking_config is not None
        assert thinking_config.thinking_level == "MEDIUM"
        assert thinking_config.include_thoughts is True

    async def test_thinking_budget_config(self, provider: GoogleVertexProvider, mock_client: MagicMock) -> None:
        """additional_config with thinking_budget passes ThinkingConfig to API."""
        text_part = MagicMock()
        text_part.thought = False
        text_part.text = "answer"
        text_part.function_call = None
        text_part.thought_signature = None

        response = _mock_response([text_part])
        mock_generate = AsyncMock(return_value=response)
        mock_client.aio.models.generate_content = mock_generate

        await provider.call(
            LLMRequest(
                model="test",
                messages=[UserMessage(blocks=[TextBlock(text="question")])],
                additional_config={"thinking_budget": 4096},
            )
        )

        call_kwargs = mock_generate.call_args.kwargs
        thinking_config = call_kwargs["config"].thinking_config
        assert thinking_config is not None
        assert thinking_config.thinking_budget == 4096
        assert thinking_config.include_thoughts is True

    async def test_thinking_level_and_budget_combined(
        self, provider: GoogleVertexProvider, mock_client: MagicMock
    ) -> None:
        """Both thinking_level and thinking_budget can be set together."""
        text_part = MagicMock()
        text_part.thought = False
        text_part.text = "answer"
        text_part.function_call = None
        text_part.thought_signature = None

        response = _mock_response([text_part])
        mock_generate = AsyncMock(return_value=response)
        mock_client.aio.models.generate_content = mock_generate

        await provider.call(
            LLMRequest(
                model="test",
                messages=[UserMessage(blocks=[TextBlock(text="question")])],
                additional_config={"thinking_level": "HIGH", "thinking_budget": 8192},
            )
        )

        call_kwargs = mock_generate.call_args.kwargs
        thinking_config = call_kwargs["config"].thinking_config
        assert thinking_config is not None
        assert thinking_config.thinking_level == "HIGH"
        assert thinking_config.thinking_budget == 8192
        assert thinking_config.include_thoughts is True


class TestImageBlockConversion:
    async def test_image_block_converted_to_inline_data(
        self, provider: GoogleVertexProvider, mock_client: MagicMock
    ) -> None:
        """ImageBlock in UserMessage is converted to Gemini inline_data Part."""
        image_data = b"\x89PNG\r\n\x1a\n"

        text_part = MagicMock()
        text_part.thought = False
        text_part.text = "I see an image"
        text_part.function_call = None
        text_part.thought_signature = None

        response = _mock_response([text_part])
        mock_generate = AsyncMock(return_value=response)
        mock_client.aio.models.generate_content = mock_generate

        request = LLMRequest(
            model="test",
            messages=[
                UserMessage(
                    blocks=[
                        ImageBlock(data=image_data, media_type="image/png"),
                    ]
                ),
            ],
        )
        await provider.call(request)

        call_kwargs = mock_generate.call_args.kwargs
        contents = call_kwargs["contents"]
        assert len(contents) == 1
        parts = contents[0].parts
        assert len(parts) == 1
        assert parts[0].inline_data is not None
        assert parts[0].inline_data.mime_type == "image/png"
        assert parts[0].inline_data.data == image_data


class TestEmptyCandidates:
    async def test_empty_candidates_returns_stop_reason_other(
        self, provider: GoogleVertexProvider, mock_client: MagicMock
    ) -> None:
        """Response with empty candidates list returns StopReason.OTHER."""
        response = MagicMock(spec=genai_types.GenerateContentResponse)
        response.candidates = []
        response.usage_metadata = MagicMock()
        response.usage_metadata.prompt_token_count = 10
        response.usage_metadata.candidates_token_count = 0
        response.usage_metadata.cached_content_token_count = 0
        response.usage_metadata.thoughts_token_count = 0

        mock_client.aio.models.generate_content = AsyncMock(return_value=response)

        result = await provider.call(
            LLMRequest(
                model="test",
                messages=[UserMessage(blocks=[TextBlock(text="hello")])],
            )
        )

        assert result.stop_reason == StopReason.OTHER
        assert result.message.blocks == []


class TestStopSequenceDetection:
    async def test_stop_sequence_detected_in_response_text(
        self, provider: GoogleVertexProvider, mock_client: MagicMock
    ) -> None:
        """When response text ends with a stop sequence, stop_reason is STOP_SEQUENCE."""
        text_part = MagicMock()
        text_part.thought = False
        text_part.text = "Some text<END>"
        text_part.function_call = None
        text_part.thought_signature = None

        response = _mock_response([text_part], finish_reason="STOP")
        mock_client.aio.models.generate_content = AsyncMock(return_value=response)

        result = await provider.call(
            LLMRequest(
                model="test",
                messages=[UserMessage(blocks=[TextBlock(text="hello")])],
                stop_sequences=["<END>", "<STOP>"],
            )
        )

        assert result.stop_reason == StopReason.STOP_SEQUENCE
        assert result.stop_sequence == "<END>"


class TestFindToolNameFallback:
    async def test_unknown_tool_use_id_returns_unknown(
        self, provider: GoogleVertexProvider, mock_client: MagicMock
    ) -> None:
        """ToolResultBlock with unmatched tool_use_id uses 'unknown' as tool name."""
        text_part = MagicMock()
        text_part.thought = False
        text_part.text = "Done"
        text_part.function_call = None
        text_part.thought_signature = None

        response = _mock_response([text_part])
        mock_generate = AsyncMock(return_value=response)
        mock_client.aio.models.generate_content = mock_generate

        await provider.call(
            LLMRequest(
                model="test",
                messages=[
                    UserMessage(blocks=[TextBlock(text="call tool")]),
                    AssistantMessage(
                        blocks=[
                            ToolUseBlock(id="call_1", name="my_tool", input={}),
                        ]
                    ),
                    UserMessage(
                        blocks=[
                            ToolResultBlock(tool_use_id="nonexistent_id", content="result"),
                        ]
                    ),
                ],
            )
        )

        call_kwargs = mock_generate.call_args.kwargs
        contents = call_kwargs["contents"]
        # Find the user content with function_response
        user_contents = [c for c in contents if c.role == "user"]
        # The last user content should have the tool result
        last_user = user_contents[-1]
        fr_parts = [p for p in last_user.parts if p.function_response is not None]
        assert len(fr_parts) == 1
        assert fr_parts[0].function_response.name == "unknown"
