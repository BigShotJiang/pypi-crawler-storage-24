from flowra.llm.schema_validation import strip_markdown_code_block, validate_json_schema


class TestStripMarkdownCodeBlock:
    def test_no_fences(self) -> None:
        assert strip_markdown_code_block('{"a": 1}') == '{"a": 1}'

    def test_both_fences(self) -> None:
        text = '```json\n{"a": 1}\n```'
        assert strip_markdown_code_block(text) == '{"a": 1}'

    def test_opening_fence_only(self) -> None:
        text = '```json\n{"a": 1}'
        assert strip_markdown_code_block(text) == '{"a": 1}'

    def test_strips_whitespace(self) -> None:
        text = '  \n{"a": 1}\n  '
        assert strip_markdown_code_block(text) == '{"a": 1}'

    def test_multiline_content(self) -> None:
        text = '```\n{\n  "a": 1,\n  "b": 2\n}\n```'
        assert strip_markdown_code_block(text) == '{\n  "a": 1,\n  "b": 2\n}'

    def test_fence_with_language_tag(self) -> None:
        text = '```json\n{"x": true}\n```'
        assert strip_markdown_code_block(text) == '{"x": true}'


SIMPLE_SCHEMA: dict = {
    "type": "object",
    "properties": {
        "name": {"type": "string"},
        "age": {"type": "integer"},
    },
    "required": ["name"],
}


class TestValidateJsonSchema:
    def test_valid_json_valid_schema(self) -> None:
        error, cleaned = validate_json_schema('{"name": "Alice", "age": 30}', SIMPLE_SCHEMA)
        assert error is None
        assert cleaned == '{"name": "Alice", "age": 30}'

    def test_valid_json_invalid_schema(self) -> None:
        error, _ = validate_json_schema('{"age": 30}', SIMPLE_SCHEMA)
        assert error is not None
        assert "Schema validation error" in error

    def test_invalid_json(self) -> None:
        error, _ = validate_json_schema("not json", SIMPLE_SCHEMA)
        assert error is not None
        assert "Invalid JSON" in error

    def test_empty_string(self) -> None:
        error, _ = validate_json_schema("", SIMPLE_SCHEMA)
        assert error is not None
        assert "Invalid JSON" in error

    def test_strips_markdown_before_validating(self) -> None:
        error, cleaned = validate_json_schema('```json\n{"name": "Bob"}\n```', SIMPLE_SCHEMA)
        assert error is None
        assert cleaned == '{"name": "Bob"}'

    def test_wrong_type(self) -> None:
        error, _ = validate_json_schema('{"name": 123}', SIMPLE_SCHEMA)
        assert error is not None
        assert "Schema validation error" in error
        assert "123" in error

    def test_minimal_valid(self) -> None:
        error, _ = validate_json_schema('{"name": "x"}', SIMPLE_SCHEMA)
        assert error is None

    def test_error_includes_path_and_context(self) -> None:
        schema = {
            "type": "object",
            "properties": {
                "items": {
                    "type": "array",
                    "items": {"type": "string"},
                },
            },
            "required": ["items"],
        }
        error, _ = validate_json_schema('{"items": [1, 2]}', schema)
        assert error is not None
        assert "Schema validation error" in error
        assert "1" in error
