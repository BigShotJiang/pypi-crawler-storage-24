import pytest

from flowra.llm.pricing import google as google_pricing


class TestGooglePricing:
    def test_known_model(self) -> None:
        cost = google_pricing.estimate_cost(
            model="gemini-2.5-pro", input_tokens=1_000_000, output_tokens=1_000_000, cache_read_tokens=0
        )
        assert cost is not None
        assert cost.input == pytest.approx(1.25)
        assert cost.output == pytest.approx(10.0)
        assert cost.total == pytest.approx(1.25 + 10.0)

    def test_with_cache_read(self) -> None:
        cost = google_pricing.estimate_cost(
            model="gemini-2.5-pro",
            input_tokens=500_000,
            output_tokens=0,
            cache_read_tokens=500_000,
        )
        assert cost is not None
        assert cost.input == pytest.approx(500_000 * 1.25 / 1e6)
        assert cost.cache_read == pytest.approx(500_000 * 0.125 / 1e6)
        assert cost.total == pytest.approx(500_000 * 1.25 / 1e6 + 500_000 * 0.125 / 1e6)

    def test_unknown_model(self) -> None:
        assert (
            google_pricing.estimate_cost(model="unknown", input_tokens=100, output_tokens=100, cache_read_tokens=0)
            is None
        )

    def test_free_cache_read(self) -> None:
        # gemini-2.0-flash-lite has cache_read=0
        cost = google_pricing.estimate_cost(
            model="gemini-2.0-flash-lite",
            input_tokens=0,
            output_tokens=0,
            cache_read_tokens=1_000_000,
        )
        assert cost is not None
        assert cost.total == pytest.approx(0.0)
