import dataclasses
from typing import Annotated

from flowra.agent import Agent, step, step_arg
from flowra.agent.definition import AgentDefinition

# -- Fixtures -----------------------------------------------------------------


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ASpec:
    msg: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class AResult:
    v: str


# -- Test agents --------------------------------------------------------------


class SimpleAgent(Agent[ASpec, AResult]):
    @step(entry=True)
    async def start(self, spec: Annotated[ASpec, step_arg.SPEC]) -> AResult:
        return AResult(v=spec.msg)

    @step
    async def finish(self) -> AResult:
        return AResult(v="done")


class OtherAgent(Agent[ASpec, AResult]):
    @step(entry=True)
    async def compute(self, spec: Annotated[ASpec, step_arg.SPEC]) -> AResult:
        return AResult(v="other")


class ParentAgent(Agent[None, AResult]):
    @step(entry=True)
    async def shared(self) -> AResult:
        return AResult(v="parent")


class ChildAgent(ParentAgent):
    @step
    async def added(self) -> AResult:
        return AResult(v="child")


class OverridingChild(ParentAgent):
    @step("shared")
    async def shared_v2(self) -> AResult:
        return AResult(v="overridden")


# -- Tests: auto-compilation -------------------------------------------------


class TestAutoCompilation:
    def test_auto_compiles_agent_definition(self) -> None:
        defn = SimpleAgent.__agent_definition__
        assert isinstance(defn, AgentDefinition)
        assert defn.entry_step == "start"
        assert set(defn.steps) == {"start", "finish"}

    def test_child_inherits_parent_steps(self) -> None:
        assert "shared" in ChildAgent.__agent_definition__.steps
        assert "added" in ChildAgent.__agent_definition__.steps

    def test_overriding_child_replaces_parent_step(self) -> None:
        defn = OverridingChild.__agent_definition__
        assert "shared" in defn.steps
        assert len(defn.steps) == 1
