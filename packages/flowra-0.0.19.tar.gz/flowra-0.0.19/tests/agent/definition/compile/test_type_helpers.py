import dataclasses
from typing import Annotated, Any, get_args

from flowra.agent.definition.compile.type_helpers import (
    extract_service_type,
    flatten_types,
    get_type_hints,
    is_nullable,
    resolve_hint,
    to_isinstance_type,
    unwrap_optional,
)


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class Spec:
    value: int


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class Result:
    data: str


type MyAlias = Spec | Result


class TestResolveHint:
    def test_passthrough_for_regular_type(self) -> None:
        assert resolve_hint(Spec) is Spec

    def test_unwraps_type_alias(self) -> None:
        resolved = resolve_hint(MyAlias)
        args = set(resolved.__args__)
        assert args == {Spec, Result}

    def test_passthrough_for_none(self) -> None:
        assert resolve_hint(type(None)) is type(None)


class TestFlattenTypes:
    def test_single_type(self) -> None:
        assert flatten_types(Spec) == [Spec]

    def test_union(self) -> None:
        result = flatten_types(Spec | Result)
        assert set(result) == {Spec, Result}

    def test_union_with_none(self) -> None:
        result = flatten_types(Spec | None)
        assert set(result) == {Spec, type(None)}

    def test_nested_union_via_alias(self) -> None:
        result = flatten_types(MyAlias)
        assert set(result) == {Spec, Result}

    def test_none_type(self) -> None:
        assert flatten_types(type(None)) == [type(None)]


class TestIsNullable:
    def test_plain_type_is_not_nullable(self) -> None:
        assert is_nullable(Spec) is False

    def test_union_with_none_is_nullable(self) -> None:
        assert is_nullable(Spec | None) is True

    def test_union_without_none_is_not_nullable(self) -> None:
        assert is_nullable(Spec | Result) is False

    def test_annotated_with_none_inside(self) -> None:
        assert is_nullable(Annotated[Spec | None, "marker"]) is True

    def test_annotated_without_none(self) -> None:
        assert is_nullable(Annotated[Spec, "marker"]) is False


class TestUnwrapOptional:
    def test_strips_none_from_union(self) -> None:
        assert unwrap_optional(Spec | None) is Spec

    def test_multi_type_union_strips_none(self) -> None:
        result = unwrap_optional(Spec | Result | None)
        assert set(get_args(result)) == {Spec, Result}

    def test_passthrough_for_non_union(self) -> None:
        assert unwrap_optional(Spec) is Spec

    def test_passthrough_for_union_without_none(self) -> None:
        result = unwrap_optional(Spec | Result)
        args = set(result.__args__)
        assert args == {Spec, Result}


class TestGetTypeHints:
    def test_returns_hints(self) -> None:
        def fn(x: int, y: str) -> bool: ...

        hints = get_type_hints(fn)
        assert hints["x"] is int
        assert hints["y"] is str
        assert hints["return"] is bool

    def test_returns_empty_on_failure(self) -> None:
        # A non-function object should return empty
        hints = get_type_hints(42)
        assert hints == {}


class TestExtractServiceType:
    def test_plain_type(self) -> None:
        assert extract_service_type(Spec) is Spec

    def test_annotated(self) -> None:
        assert extract_service_type(Annotated[Spec, "meta"]) is Spec

    def test_optional(self) -> None:
        assert extract_service_type(Spec | None) is Spec

    def test_ambiguous_union_returns_none(self) -> None:
        assert extract_service_type(Spec | Result) is None

    def test_multi_type_union_returns_none(self) -> None:
        assert extract_service_type(Spec | Result) is None


class TestToIsinstanceType:
    def test_single_type(self) -> None:
        assert to_isinstance_type(Spec) is Spec

    def test_union_returns_tuple(self) -> None:
        result = to_isinstance_type(Spec | Result)
        assert isinstance(result, tuple)
        assert set(result) == {Spec, Result}

    def test_any_returns_object(self) -> None:
        assert to_isinstance_type(Any) is object

    def test_optional_strips_none(self) -> None:
        assert to_isinstance_type(Spec | None) is Spec
