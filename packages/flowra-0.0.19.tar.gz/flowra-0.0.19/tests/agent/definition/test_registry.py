from typing import ClassVar

import pytest

from flowra.agent import Agent, AgentDefinitionRef, step
from flowra.agent.definition import AgentDefinition, AgentRegistry, StepMeta


def _defn(**kwargs: object) -> AgentDefinition:
    return AgentDefinition(
        steps={"start": StepMeta()},
        type_registry={},
        create_instance=lambda sl: None,  # type: ignore[arg-type,return-value]
        entry_step="start",
        **kwargs,  # type: ignore[arg-type]
    )


class _AgentA(Agent[None, None]):
    @step(entry=True)
    async def start(self) -> None:
        return None


class _AgentB(Agent[None, None]):
    @step(entry=True)
    async def start(self) -> None:
        return None


class TestNameValidation:
    def test_valid_names(self) -> None:
        AgentRegistry({"foo": _defn(), "bar-baz": _defn(), "agent_1": _defn()})

    def test_rejects_dots(self) -> None:
        with pytest.raises(ValueError, match="Invalid agent name"):
            AgentRegistry({"a.b": _defn()})

    def test_rejects_slashes(self) -> None:
        with pytest.raises(ValueError, match="Invalid agent name"):
            AgentRegistry({"a/b": _defn()})

    def test_rejects_spaces(self) -> None:
        with pytest.raises(ValueError, match="Invalid agent name"):
            AgentRegistry({"a b": _defn()})

    def test_rejects_empty(self) -> None:
        with pytest.raises(ValueError, match="Invalid agent name"):
            AgentRegistry({"": _defn()})


class TestResolveByAbsoluteName:
    def test_resolves_top_level(self) -> None:
        defn = _defn()
        reg = AgentRegistry({"alpha": defn})
        result = reg.resolve("alpha")
        assert result.name == "alpha"
        assert result.definition is defn

    def test_resolves_nested(self) -> None:
        child_defn = _defn()
        parent_defn = _defn(subagents={"child": child_defn})
        reg = AgentRegistry({"parent": parent_defn})
        result = reg.resolve("parent/child")
        assert result.name == "parent/child"
        assert result.definition is child_defn

    def test_unknown_name_raises(self) -> None:
        reg = AgentRegistry({"a": _defn()})
        with pytest.raises(KeyError, match="Unknown agent"):
            reg.resolve("nonexistent")


class TestResolveByRelativeName:
    def test_child_ref(self) -> None:
        child_defn = _defn()
        parent_defn = _defn(subagents={"helper": child_defn})
        reg = AgentRegistry({"parent": parent_defn})
        result = reg.resolve("./helper", context="parent")
        assert result.name == "parent/helper"
        assert result.definition is child_defn

    def test_without_context_raises(self) -> None:
        reg = AgentRegistry({"a": _defn()})
        with pytest.raises(ValueError, match="requires a context"):
            reg.resolve("./child")

    def test_nested_child(self) -> None:
        gc_defn = _defn()
        child_defn = _defn(subagents={"gc": gc_defn})
        parent_defn = _defn(subagents={"child": child_defn})
        reg = AgentRegistry({"parent": parent_defn})
        result = reg.resolve("./gc", context="parent/child")
        assert result.name == "parent/child/gc"
        assert result.definition is gc_defn


class TestResolveByRelativePathUp:
    def test_sibling_ref(self) -> None:
        sibling_defn = _defn()
        child_defn = _defn()
        parent_defn = _defn(subagents={"child": child_defn, "sibling": sibling_defn})
        reg = AgentRegistry({"parent": parent_defn})
        result = reg.resolve("../sibling", context="parent/child")
        assert result.name == "parent/sibling"
        assert result.definition is sibling_defn

    def test_grandparent_ref(self) -> None:
        uncle_defn = _defn()
        child_defn = _defn()
        parent_defn = _defn(subagents={"child": child_defn})
        reg = AgentRegistry({"parent": parent_defn, "uncle": uncle_defn})
        result = reg.resolve("../../uncle", context="parent/child")
        assert result.name == "uncle"
        assert result.definition is uncle_defn

    def test_deeper_path_after_going_up(self) -> None:
        nephew_defn = _defn()
        sibling_defn = _defn(subagents={"nephew": nephew_defn})
        child_defn = _defn()
        parent_defn = _defn(subagents={"child": child_defn, "sibling": sibling_defn})
        reg = AgentRegistry({"parent": parent_defn})
        result = reg.resolve("../sibling/nephew", context="parent/child")
        assert result.name == "parent/sibling/nephew"
        assert result.definition is nephew_defn

    def test_above_root_raises(self) -> None:
        reg = AgentRegistry({"a": _defn()})
        with pytest.raises(ValueError, match="goes above root"):
            reg.resolve("../../x", context="a")

    def test_empty_remainder_raises(self) -> None:
        reg = AgentRegistry({"parent": _defn(subagents={"child": _defn()})})
        with pytest.raises(ValueError, match="resolves to a context"):
            reg.resolve("../", context="parent/child")

    def test_bare_dot_prefix_rejected(self) -> None:
        child_defn = _defn()
        parent_defn = _defn(subagents={"helper": child_defn})
        reg = AgentRegistry({"parent": parent_defn})
        with pytest.raises(ValueError, match=r"use './' or '../'"):
            reg.resolve(".helper", context="parent")

    def test_relative_without_context_raises(self) -> None:
        reg = AgentRegistry({"a": _defn()})
        with pytest.raises(ValueError, match="requires a context"):
            reg.resolve("../sibling")


class TestResolveByType:
    def test_resolves_top_level_type(self) -> None:
        reg = AgentRegistry({"a": _AgentA})
        result = reg.resolve(_AgentA)
        assert result.name == "a"
        assert result.definition is _AgentA.__agent_definition__

    def test_resolves_subagent_type_from_parent_context(self) -> None:
        class _Sub(Agent[None, None]):
            @step(entry=True)
            async def start(self) -> None:
                return None

        class _Parent(Agent[None, None]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {"sub": _Sub}

            @step(entry=True)
            async def start(self) -> None:
                return None

        reg = AgentRegistry({"parent": _Parent})
        result = reg.resolve(_Sub, context="parent")
        assert result.name == "parent/sub"
        assert result.definition is _Sub.__agent_definition__

    def test_walks_hierarchy_upward(self) -> None:
        reg = AgentRegistry({"a": _AgentA, "b": _AgentB})
        result = reg.resolve(_AgentA, context="b")
        assert result.name == "a"
        assert result.definition is _AgentA.__agent_definition__

    def test_unregistered_type_raises(self) -> None:
        reg = AgentRegistry({"a": _AgentA})
        with pytest.raises(KeyError, match="Unregistered agent class"):
            reg.resolve(_AgentB)


class TestContextualTypeResolution:
    def test_same_type_at_different_levels(self) -> None:
        class _Worker(Agent[None, None]):
            @step(entry=True)
            async def run(self) -> None:
                return None

        class _TeamA(Agent[None, None]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {"worker": _Worker}

            @step(entry=True)
            async def start(self) -> None:
                return None

        class _TeamB(Agent[None, None]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {"worker": _Worker}

            @step(entry=True)
            async def start(self) -> None:
                return None

        reg = AgentRegistry({"team_a": _TeamA, "team_b": _TeamB})
        assert reg.resolve(_Worker, context="team_a").name == "team_a/worker"
        assert reg.resolve(_Worker, context="team_b").name == "team_b/worker"

    def test_closer_scope_wins(self) -> None:
        class _Helper(Agent[None, None]):
            @step(entry=True)
            async def start(self) -> None:
                return None

        class _Child(Agent[None, None]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {"helper": _Helper}

            @step(entry=True)
            async def start(self) -> None:
                return None

        class _Parent(Agent[None, None]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {"helper": _Helper, "child": _Child}

            @step(entry=True)
            async def start(self) -> None:
                return None

        reg = AgentRegistry({"parent": _Parent})
        assert reg.resolve(_Helper, context="parent/child").name == "parent/child/helper"
        assert reg.resolve(_Helper, context="parent").name == "parent/helper"


class TestGet:
    def test_get_existing(self) -> None:
        defn = _defn()
        reg = AgentRegistry({"x": defn})
        assert reg.get("x") is defn

    def test_get_unknown_raises(self) -> None:
        reg = AgentRegistry({})
        with pytest.raises(KeyError, match="Unknown agent"):
            reg.get("nope")


class TestNameForType:
    def test_returns_full_name(self) -> None:
        reg = AgentRegistry({"my_agent": _AgentA})
        assert reg.name_for_type(_AgentA) == "my_agent"

    def test_with_context(self) -> None:
        class _Sub(Agent[None, None]):
            @step(entry=True)
            async def start(self) -> None:
                return None

        class _Parent(Agent[None, None]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {"sub": _Sub}

            @step(entry=True)
            async def start(self) -> None:
                return None

        reg = AgentRegistry({"p": _Parent})
        assert reg.name_for_type(_Sub, context="p") == "p/sub"


class TestThreeLevelNesting:
    def test_deeply_nested_agents(self) -> None:
        gc_defn = _defn()
        child_defn = _defn(subagents={"grandchild": gc_defn})
        parent_defn = _defn(subagents={"child": child_defn})
        reg = AgentRegistry({"root_agent": parent_defn})

        assert reg.get("root_agent") is parent_defn
        assert reg.get("root_agent/child") is child_defn
        assert reg.get("root_agent/child/grandchild") is gc_defn

        result = reg.resolve("root_agent/child/grandchild")
        assert result.definition is gc_defn

        result = reg.resolve("./grandchild", context="root_agent/child")
        assert result.definition is gc_defn


class TestAllDefinitions:
    def test_returns_all_including_nested(self) -> None:
        child_defn = _defn()
        parent_defn = _defn(subagents={"child": child_defn})
        reg = AgentRegistry({"parent": parent_defn})
        all_defs = reg.all_definitions()
        assert parent_defn in all_defs
        assert child_defn in all_defs
        assert len(all_defs) == 2


class TestAllNamedDefinitions:
    def test_returns_names_and_definitions(self) -> None:
        child_defn = _defn()
        parent_defn = _defn(subagents={"child": child_defn})
        other_defn = _defn()
        reg = AgentRegistry({"parent": parent_defn, "other": other_defn})
        named = reg.all_named_definitions()
        by_name = dict(named)
        assert len(named) == 3
        assert by_name["parent"] is parent_defn
        assert by_name["parent/child"] is child_defn
        assert by_name["other"] is other_defn


class TestDuplicateAgentClass:
    def test_duplicate_class_at_same_level_raises(self) -> None:
        with pytest.raises(ValueError, match="Duplicate agent class"):
            AgentRegistry({"a": _AgentA, "b": _AgentA})
