import json
import os
import tempfile

from flowra.agent.storage import ChangeSet, FileSessionStorage


class TestFileSessionStorage:
    def _make_storage(self, base_dir: str) -> FileSessionStorage:
        return FileSessionStorage(base_dir=base_dir, session_id="test-session")

    async def test_empty_initial_state(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = self._make_storage(tmp)
            assert await storage.has_execution() is False
            assert await storage.load_execution() is None
            assert await storage.load_node_state("x") is None

    async def test_save_and_load_execution(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = self._make_storage(tmp)
            snapshot = {"node_id": "root", "status": "pending_step"}
            async with storage.begin_transaction():
                await storage.save_execution(snapshot)
            assert await storage.has_execution() is True
            loaded = await storage.load_execution()
            assert loaded == snapshot

    async def test_clear_execution(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = self._make_storage(tmp)
            async with storage.begin_transaction():
                await storage.save_execution({"node_id": "root"})
            await storage.clear_execution()
            assert await storage.has_execution() is False
            assert await storage.load_execution() is None

    async def test_clear_nonexistent_execution(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = self._make_storage(tmp)
            await storage.clear_execution()  # should not raise

    async def test_save_and_load_node_state_scalars(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = self._make_storage(tmp)
            changes = ChangeSet(scalars={"counter": 1, "name": "test"}, appends={})
            async with storage.begin_transaction():
                await storage.save_node_state("main", changes)
            state = await storage.load_node_state("main")
            assert state == {"counter": 1, "name": "test"}

    async def test_save_and_load_node_state_appends(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = self._make_storage(tmp)
            changes = ChangeSet(scalars={}, appends={"log": ["a", "b"]})
            async with storage.begin_transaction():
                await storage.save_node_state("main", changes)
            state = await storage.load_node_state("main")
            assert state == {"log": ["a", "b"]}

    async def test_node_state_merges_across_saves(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = self._make_storage(tmp)
            async with storage.begin_transaction():
                await storage.save_node_state("k", ChangeSet(scalars={"x": 1}, appends={"log": ["a"]}))
            async with storage.begin_transaction():
                await storage.save_node_state("k", ChangeSet(scalars={"x": 2}, appends={"log": ["b"]}))
            state = await storage.load_node_state("k")
            assert state == {"x": 2, "log": ["a", "b"]}

    async def test_files_created_on_disk(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = self._make_storage(tmp)
            async with storage.begin_transaction():
                await storage.save_execution({"data": True})
                await storage.save_node_state("my-key", ChangeSet(scalars={"v": 1}, appends={"log": ["a"]}))

            session_dir = os.path.join(tmp, "test-session")
            assert os.path.isfile(os.path.join(session_dir, "execution.json"))
            assert os.path.isfile(os.path.join(session_dir, "nodes", "my-key.json"))
            assert os.path.isfile(os.path.join(session_dir, "nodes", "my-key.log.jsonl"))

    async def test_sanitizes_key(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = self._make_storage(tmp)
            async with storage.begin_transaction():
                await storage.save_node_state("root.0", ChangeSet(scalars={"v": 1}, appends={}))
            state = await storage.load_node_state("root.0")
            assert state == {"v": 1}
            # Dots in keys are sanitized to underscores
            session_dir = os.path.join(tmp, "test-session")
            assert os.path.isfile(os.path.join(session_dir, "nodes", "root_0.json"))

    async def test_persists_across_instances(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            s1 = self._make_storage(tmp)
            async with s1.begin_transaction():
                await s1.save_execution({"status": "ok"})
                await s1.save_node_state("main", ChangeSet(scalars={"x": 42}, appends={}))

            s2 = self._make_storage(tmp)
            assert await s2.has_execution() is True
            assert await s2.load_execution() == {"status": "ok"}
            assert await s2.load_node_state("main") == {"x": 42}

    async def test_json_content_valid(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = self._make_storage(tmp)
            async with storage.begin_transaction():
                await storage.save_node_state("k", ChangeSet(scalars={"msg": "hello"}, appends={"items": [1, 2]}))

            scalar_path = os.path.join(tmp, "test-session", "nodes", "k.json")
            with open(scalar_path) as f:
                data = json.load(f)
            assert data == {"msg": "hello"}

            jsonl_path = os.path.join(tmp, "test-session", "nodes", "k.items.jsonl")
            with open(jsonl_path) as f:
                lines = [json.loads(line) for line in f if line.strip()]
            assert lines == [1, 2]

    async def test_appends_are_truly_append_only(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = self._make_storage(tmp)
            async with storage.begin_transaction():
                await storage.save_node_state("k", ChangeSet(scalars={}, appends={"log": ["a", "b"]}))
            async with storage.begin_transaction():
                await storage.save_node_state("k", ChangeSet(scalars={}, appends={"log": ["c"]}))

            jsonl_path = os.path.join(tmp, "test-session", "nodes", "k.log.jsonl")
            with open(jsonl_path) as f:
                lines = f.readlines()
            assert len(lines) == 3

    async def test_scalars_only_no_jsonl_created(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = self._make_storage(tmp)
            async with storage.begin_transaction():
                await storage.save_node_state("k", ChangeSet(scalars={"x": 1}, appends={}))

            nodes_dir = os.path.join(tmp, "test-session", "nodes")
            files = os.listdir(nodes_dir)
            assert files == ["k.json"]

    async def test_appends_only_no_json_created(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = self._make_storage(tmp)
            async with storage.begin_transaction():
                await storage.save_node_state("k", ChangeSet(scalars={}, appends={"log": ["a"]}))

            nodes_dir = os.path.join(tmp, "test-session", "nodes")
            files = os.listdir(nodes_dir)
            assert files == ["k.log.jsonl"]

    async def test_sanitization_key_collision(self) -> None:
        """Keys 'root.0' and 'root_0' both sanitize to 'root_0', causing a collision."""
        with tempfile.TemporaryDirectory() as tmp:
            storage = self._make_storage(tmp)
            async with storage.begin_transaction():
                await storage.save_node_state("root.0", ChangeSet(scalars={"v": 1}, appends={}))
                await storage.save_node_state("root_0", ChangeSet(scalars={"v": 2}, appends={}))

            # Both keys map to the same file — second write overwrites the first
            state_dot = await storage.load_node_state("root.0")
            state_underscore = await storage.load_node_state("root_0")
            # They return the same data because sanitization maps both to "root_0"
            assert state_dot == state_underscore
            assert state_dot == {"v": 2}
