from flowra.agent.storage import ChangeSet, InMemorySessionStorage
from tests.agent.storage import TrackingSessionStorage


class TestInMemorySessionStorage:
    async def test_empty_initial_state(self) -> None:
        storage = InMemorySessionStorage()
        assert await storage.has_execution() is False
        assert await storage.load_execution() is None
        assert await storage.load_node_state("x") is None

    async def test_save_and_load_execution(self) -> None:
        storage = InMemorySessionStorage()
        snapshot = {"node_id": "root", "status": "pending_step"}
        async with storage.begin_transaction():
            await storage.save_execution(snapshot)
        assert await storage.has_execution() is True
        assert await storage.load_execution() == snapshot

    async def test_clear_execution(self) -> None:
        storage = InMemorySessionStorage()
        async with storage.begin_transaction():
            await storage.save_execution({"node_id": "root"})
        await storage.clear_execution()
        assert await storage.has_execution() is False
        assert await storage.load_execution() is None

    async def test_save_node_state_scalars(self) -> None:
        storage = InMemorySessionStorage()
        changes = ChangeSet(scalars={"counter": 1}, appends={})
        async with storage.begin_transaction():
            await storage.save_node_state("main", changes)
        state = await storage.load_node_state("main")
        assert state == {"counter": 1}

    async def test_save_node_state_appends(self) -> None:
        storage = InMemorySessionStorage()
        changes = ChangeSet(scalars={}, appends={"log": ["a", "b"]})
        async with storage.begin_transaction():
            await storage.save_node_state("main", changes)
        state = await storage.load_node_state("main")
        assert state == {"log": ["a", "b"]}

    async def test_save_node_state_merges(self) -> None:
        storage = InMemorySessionStorage()
        async with storage.begin_transaction():
            await storage.save_node_state("k", ChangeSet(scalars={"x": 1}, appends={"log": ["a"]}))
        async with storage.begin_transaction():
            await storage.save_node_state("k", ChangeSet(scalars={"x": 2}, appends={"log": ["b"]}))
        state = await storage.load_node_state("k")
        assert state == {"x": 2, "log": ["a", "b"]}

    async def test_load_node_state_returns_copy(self) -> None:
        storage = InMemorySessionStorage()
        async with storage.begin_transaction():
            await storage.save_node_state("k", ChangeSet(scalars={"x": 1}, appends={}))
        state1 = await storage.load_node_state("k")
        state2 = await storage.load_node_state("k")
        assert state1 is not state2


class TestTrackingSessionStorage:
    async def test_tracks_calls(self) -> None:
        storage = TrackingSessionStorage()
        async with storage.begin_transaction():
            await storage.save_execution({"a": 1})
            await storage.save_node_state("k", ChangeSet(scalars={"x": 1}, appends={}))
        assert len(storage.save_execution_calls) == 1
        assert len(storage.save_node_state_calls) == 1
        assert storage.transaction_count == 1
