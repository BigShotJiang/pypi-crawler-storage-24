"""Tests that ExecutionContext is correctly populated during multi-agent execution."""

import dataclasses
from typing import Annotated, ClassVar

from flowra.agent import (
    Agent,
    AgentDefinitionRef,
    AgentRuntime,
    CallAgent,
    ExecutionContext,
    HookEmitter,
    HookSubscription,
    Spawn,
    step,
    step_arg,
)


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class DoneResult:
    value: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class MyEvent:
    label: str


class TestExecutionContextSingleAgent:
    async def test_root_agent_gets_context(self) -> None:
        captured: list[ExecutionContext] = []

        class Root(Agent[None, DoneResult]):
            def __init__(self, hooks: HookEmitter) -> None:
                self._hooks = hooks

            @step(entry=True)
            async def start(self) -> DoneResult:
                await self._hooks.emit(MyEvent(label="hello"))
                return DoneResult(value="done")

        subscription = HookSubscription()
        subscription.on(MyEvent, lambda e: captured.append(e.context))

        runtime = AgentRuntime(agents={"root": Root}, services={HookSubscription: subscription})
        await runtime.run(agent="root")

        assert len(captured) == 1
        ctx = captured[0]

        assert ctx.frame.agent.name == "root"
        assert ctx.frame.agent.path == "root"
        assert ctx.frame.agent.source_type is Root
        assert ctx.frame.agent.parent is None
        assert len(ctx.stack) == 1
        assert ctx.stack[0] is ctx.frame

    async def test_root_agent_with_spec(self) -> None:
        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class MySpec:
            name: str

        captured: list[ExecutionContext] = []

        class Root(Agent[MySpec, DoneResult]):
            def __init__(self, hooks: HookEmitter) -> None:
                self._hooks = hooks

            @step(entry=True)
            async def start(self, spec: Annotated[MySpec, step_arg.SPEC]) -> DoneResult:
                await self._hooks.emit(MyEvent(label="with_spec"))
                return DoneResult(value=spec.name)

        subscription = HookSubscription()
        subscription.on(MyEvent, lambda e: captured.append(e.context))

        runtime = AgentRuntime(agents={"root": Root}, services={HookSubscription: subscription})
        await runtime.run(agent="root", spec=MySpec(name="test"))

        assert len(captured) == 1
        ctx = captured[0]

        assert isinstance(ctx.frame.spec, MySpec)
        assert ctx.frame.spec.name == "test"


class TestExecutionContextParentChild:
    async def test_child_agent_sees_execution_stack(self) -> None:
        """When a child agent emits an event, the context should contain
        the full execution stack from root to child."""
        captured: list[ExecutionContext] = []

        class Child(Agent[None, DoneResult]):
            def __init__(self, hooks: HookEmitter) -> None:
                self._hooks = hooks

            @step(entry=True)
            async def work(self) -> DoneResult:
                await self._hooks.emit(MyEvent(label="from_child"))
                return DoneResult(value="child_done")

        class Parent(Agent[None, DoneResult]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {"child": Child}

            @step(entry=True)
            async def start(self) -> Spawn:
                return Spawn(children=[CallAgent(agent="parent/child")], then=self.collect)

            @step
            async def collect(self, result: Annotated[DoneResult, step_arg.CHILD]) -> DoneResult:
                return result

        subscription = HookSubscription()
        subscription.on(MyEvent, lambda e: captured.append(e.context))

        runtime = AgentRuntime(agents={"parent": Parent}, services={HookSubscription: subscription})
        await runtime.run(agent="parent")

        assert len(captured) == 1
        ctx = captured[0]

        # Current frame is the child
        assert ctx.frame.agent.name == "child"
        assert ctx.frame.agent.path == "parent/child"
        assert ctx.frame.agent.source_type is Child

        # Stack has 2 frames: parent -> child
        assert len(ctx.stack) == 2
        assert ctx.stack[0].agent.name == "parent"
        assert ctx.stack[0].agent.path == "parent"
        assert ctx.stack[0].agent.source_type is Parent
        assert ctx.stack[1] is ctx.frame

    async def test_parent_handler_sees_both_own_and_child_events(self) -> None:
        """with_context shares handlers, so parent's handler fires for child events too."""
        parent_captured: list[ExecutionContext] = []

        class Child(Agent[None, DoneResult]):
            def __init__(self, hooks: HookEmitter) -> None:
                self._hooks = hooks

            @step(entry=True)
            async def work(self) -> DoneResult:
                await self._hooks.emit(MyEvent(label="child"))
                return DoneResult(value="child_done")

        class Parent(Agent[None, DoneResult]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {"child": Child}

            def __init__(self, hooks: HookEmitter) -> None:
                self._hooks = hooks

            @step(entry=True)
            async def start(self) -> Spawn:
                await self._hooks.emit(MyEvent(label="parent"))
                return Spawn(children=[CallAgent(agent="parent/child")], then=self.collect)

            @step
            async def collect(self, result: Annotated[DoneResult, step_arg.CHILD]) -> DoneResult:
                return result

        subscription = HookSubscription()
        subscription.on(MyEvent, lambda e: parent_captured.append(e.context))

        runtime = AgentRuntime(agents={"parent": Parent}, services={HookSubscription: subscription})
        await runtime.run(agent="parent")

        # Parent's handler fires twice: once from parent's emit, once from child's emit
        # (child's emitter shares parent's handlers via _get_handlers)
        assert len(parent_captured) == 2

        # First event: parent context
        pctx = parent_captured[0]
        assert pctx is not None
        assert pctx.frame.agent.name == "parent"
        assert len(pctx.stack) == 1

        # Second event: child context (handler shared via _get_handlers)
        cctx = parent_captured[1]
        assert cctx is not None
        assert cctx.frame.agent.name == "child"
        assert len(cctx.stack) == 2


class TestExecutionContextThreeLevels:
    async def test_grandchild_has_full_stack(self) -> None:
        captured: list[ExecutionContext] = []

        class Grandchild(Agent[None, DoneResult]):
            def __init__(self, hooks: HookEmitter) -> None:
                self._hooks = hooks

            @step(entry=True)
            async def work(self) -> DoneResult:
                await self._hooks.emit(MyEvent(label="grandchild"))
                return DoneResult(value="gc_done")

        class Middle(Agent[None, DoneResult]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {"gc": Grandchild}

            @step(entry=True)
            async def start(self) -> Spawn:
                return Spawn(children=[CallAgent(agent="root/mid/gc")], then=self.collect)

            @step
            async def collect(self, result: Annotated[DoneResult, step_arg.CHILD]) -> DoneResult:
                return result

        class Root(Agent[None, DoneResult]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {"mid": Middle}

            @step(entry=True)
            async def start(self) -> Spawn:
                return Spawn(children=[CallAgent(agent="root/mid")], then=self.collect)

            @step
            async def collect(self, result: Annotated[DoneResult, step_arg.CHILD]) -> DoneResult:
                return result

        subscription = HookSubscription()
        subscription.on(MyEvent, lambda e: captured.append(e.context))

        runtime = AgentRuntime(agents={"root": Root}, services={HookSubscription: subscription})
        await runtime.run(agent="root")

        assert len(captured) == 1
        ctx = captured[0]

        # Full execution stack: root -> mid -> gc
        assert len(ctx.stack) == 3
        assert ctx.stack[0].agent.name == "root"
        assert ctx.stack[0].agent.path == "root"
        assert ctx.stack[0].agent.source_type is Root
        assert ctx.stack[0].agent.parent is None  # root has no parent
        assert ctx.stack[1].agent.name == "mid"
        assert ctx.stack[1].agent.path == "root/mid"
        assert ctx.stack[1].agent.source_type is Middle
        # Intermediate stack frames also get registration hierarchy parent chain
        assert ctx.stack[1].agent.parent is not None
        assert ctx.stack[1].agent.parent.name == "root"
        assert ctx.stack[1].agent.parent.path == "root"
        assert ctx.stack[2].agent.name == "gc"
        assert ctx.stack[2].agent.path == "root/mid/gc"
        assert ctx.stack[2].agent.source_type is Grandchild


class TestExecutionContextRegistrationHierarchy:
    async def test_agent_info_parent_chain(self) -> None:
        """AgentInfo.parent should reflect the registration hierarchy based on path."""
        captured: list[ExecutionContext] = []

        class Grandchild(Agent[None, DoneResult]):
            def __init__(self, hooks: HookEmitter) -> None:
                self._hooks = hooks

            @step(entry=True)
            async def work(self) -> DoneResult:
                await self._hooks.emit(MyEvent(label="gc"))
                return DoneResult(value="done")

        class Middle(Agent[None, DoneResult]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {"gc": Grandchild}

            @step(entry=True)
            async def start(self) -> Spawn:
                return Spawn(children=[CallAgent(agent="root/mid/gc")], then=self.collect)

            @step
            async def collect(self, result: Annotated[DoneResult, step_arg.CHILD]) -> DoneResult:
                return result

        class Root(Agent[None, DoneResult]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {"mid": Middle}

            @step(entry=True)
            async def start(self) -> Spawn:
                return Spawn(children=[CallAgent(agent="root/mid")], then=self.collect)

            @step
            async def collect(self, result: Annotated[DoneResult, step_arg.CHILD]) -> DoneResult:
                return result

        subscription = HookSubscription()
        subscription.on(MyEvent, lambda e: captured.append(e.context))

        runtime = AgentRuntime(agents={"root": Root}, services={HookSubscription: subscription})
        await runtime.run(agent="root")

        ctx = captured[0]

        # The grandchild's AgentInfo should have parent chain
        gc_info = ctx.frame.agent
        assert gc_info.name == "gc"
        assert gc_info.path == "root/mid/gc"
        assert gc_info.source_type is Grandchild

        # parent is "mid" (intermediate in registration hierarchy)
        mid_info = gc_info.parent
        assert mid_info is not None
        assert mid_info.name == "mid"
        assert mid_info.path == "root/mid"
        # Intermediate parents don't have source_type (built from path segments)
        assert mid_info.source_type is None

        # grandparent is "root"
        root_info = mid_info.parent
        assert root_info is not None
        assert root_info.name == "root"
        assert root_info.path == "root"
        assert root_info.parent is None


class TestExecutionContextWithSpec:
    async def test_child_spec_in_context(self) -> None:
        """Execution frames carry the spec passed to the agent."""

        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class ChildSpec:
            task: str

        captured: list[ExecutionContext] = []

        class Worker(Agent[ChildSpec, DoneResult]):
            def __init__(self, hooks: HookEmitter) -> None:
                self._hooks = hooks

            @step(entry=True)
            async def work(self, spec: Annotated[ChildSpec, step_arg.SPEC]) -> DoneResult:
                await self._hooks.emit(MyEvent(label="worker"))
                return DoneResult(value=spec.task)

        class Orchestrator(Agent[None, DoneResult]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {"worker": Worker}

            @step(entry=True)
            async def start(self) -> Spawn:
                return Spawn(
                    children=[CallAgent(agent="orch/worker", spec=ChildSpec(task="analyze"))],
                    then=self.collect,
                )

            @step
            async def collect(self, result: Annotated[DoneResult, step_arg.CHILD]) -> DoneResult:
                return result

        subscription = HookSubscription()
        subscription.on(MyEvent, lambda e: captured.append(e.context))

        runtime = AgentRuntime(agents={"orch": Orchestrator}, services={HookSubscription: subscription})
        await runtime.run(agent="orch")

        assert len(captured) == 1
        ctx = captured[0]

        # Child frame has the spec
        assert isinstance(ctx.frame.spec, ChildSpec)
        assert ctx.frame.spec.task == "analyze"

        # Parent frame in stack has None spec (no spec)
        assert ctx.stack[0].spec is None


class TestExecutionContextPropagation:
    async def test_shared_handler_gets_child_context(self) -> None:
        """Handler registered on subscription sees child's context when child emits
        (because HookEmitter copies handlers from subscription)."""
        received: list[ExecutionContext] = []

        class Worker(Agent[None, DoneResult]):
            def __init__(self, hooks: HookEmitter) -> None:
                self._hooks = hooks

            @step(entry=True)
            async def work(self) -> DoneResult:
                await self._hooks.emit(MyEvent(label="from_worker"))
                return DoneResult(value="done")

        class Boss(Agent[None, DoneResult]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {"worker": Worker}

            @step(entry=True)
            async def start(self) -> Spawn:
                return Spawn(children=[CallAgent(agent="boss/worker")], then=self.collect)

            @step
            async def collect(self, result: Annotated[DoneResult, step_arg.CHILD]) -> DoneResult:
                return result

        subscription = HookSubscription()
        subscription.on(MyEvent, lambda e: received.append(e.context))

        runtime = AgentRuntime(agents={"boss": Boss}, services={HookSubscription: subscription})
        await runtime.run(agent="boss")

        # The shared handler fires with worker's context (child's emitter context)
        assert len(received) == 1
        ctx = received[0]

        assert ctx.frame.agent.name == "worker"
        assert ctx.frame.agent.path == "boss/worker"
        assert len(ctx.stack) == 2
        assert ctx.stack[0].agent.name == "boss"


class TestExecutionContextWithTag:
    async def test_tag_appears_in_child_frame(self) -> None:
        captured: list[ExecutionContext] = []

        class Worker(Agent[None, DoneResult]):
            def __init__(self, hooks: HookEmitter) -> None:
                self._hooks = hooks

            @step(entry=True)
            async def work(self) -> DoneResult:
                await self._hooks.emit(MyEvent(label="tagged"))
                return DoneResult(value="done")

        class Boss(Agent[None, DoneResult]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {"worker": Worker}

            @step(entry=True)
            async def start(self) -> Spawn:
                return Spawn(
                    children=[CallAgent(agent="boss/worker", tag="fast")],
                    then=self.collect,
                )

            @step
            async def collect(self, result: Annotated[DoneResult, step_arg.CHILD]) -> DoneResult:
                return result

        subscription = HookSubscription()
        subscription.on(MyEvent, lambda e: captured.append(e.context))

        runtime = AgentRuntime(agents={"boss": Boss}, services={HookSubscription: subscription})
        await runtime.run(agent="boss")

        assert len(captured) == 1
        ctx = captured[0]

        assert ctx.frame.tag == "fast"
        assert ctx.frame.agent.name == "worker"
