import asyncio
import dataclasses
from typing import Annotated, Any, ClassVar

import pytest

from flowra.agent import (
    Agent,
    AgentDefinitionRef,
    AgentRuntime,
    AgentStore,
    CallAgent,
    CallStep,
    ChildOutput,
    GotoAgent,
    GotoStep,
    Interrupted,
    InterruptedError,
    InterruptToken,
    Scalar,
    ServiceLocator,
    Spawn,
    TimeoutExpired,
    WhenAll,
    WhenAny,
    WhenN,
    step,
    step_arg,
    timeout,
)
from flowra.agent.definition import AgentDefinition, AgentInstance, CallStepHandler, StepMeta


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class SimpleResult:
    value: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class SimpleSpec:
    message: str


def make_defn(steps: dict[str, StepMeta], handler: CallStepHandler, *, entry_step: str = "start") -> AgentDefinition:
    """Build an AgentDefinition with a given call_step handler factory."""

    def create(sl: ServiceLocator, agent_spec: Any | None = None) -> AgentInstance:
        return AgentInstance(call_step=handler)

    return AgentDefinition(steps=steps, type_registry={}, create_instance=create, entry_step=entry_step)


class TestSingleStep:
    async def test_returns_agent_result_immediately(self) -> None:
        async def handler(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            return SimpleResult(value="done")

        defn = make_defn({"start": StepMeta()}, handler)
        runtime = AgentRuntime(agents={"a": defn})
        result = await runtime.run(agent="a")
        assert isinstance(result, SimpleResult)
        assert result.value == "done"

    async def test_returns_none(self) -> None:
        async def handler(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            return None

        defn = make_defn({"start": StepMeta()}, handler)
        runtime = AgentRuntime(agents={"a": defn})
        result = await runtime.run(agent="a")
        assert result is None


class TestGotoStep:
    async def test_chain_step_a_to_step_b(self) -> None:
        async def handler(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            if tag == "a":
                return GotoStep(step="b")
            return SimpleResult(value="from_b")

        defn = make_defn({"a": StepMeta(), "b": StepMeta()}, handler, entry_step="a")
        runtime = AgentRuntime(agents={"agent": defn})
        result = await runtime.run(agent="agent")
        assert isinstance(result, SimpleResult)
        assert result.value == "from_b"

    async def test_goto_step_passes_spec(self) -> None:
        async def handler(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            if tag == "a":
                return GotoStep(step="b", spec=SimpleSpec(message="hello"))
            assert isinstance(spec, SimpleSpec)
            return SimpleResult(value=spec.message)

        defn = make_defn({"a": StepMeta(), "b": StepMeta()}, handler, entry_step="a")
        runtime = AgentRuntime(agents={"agent": defn})
        result = await runtime.run(agent="agent")
        assert isinstance(result, SimpleResult)
        assert result.value == "hello"


class TestGotoAgent:
    async def test_transfers_to_another_agent(self) -> None:
        async def handler_a(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            return GotoAgent(agent="b")

        async def handler_b(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            return SimpleResult(value="from_agent_b")

        defn_a = make_defn({"start": StepMeta()}, handler_a)
        defn_b = make_defn({"start": StepMeta()}, handler_b)
        runtime = AgentRuntime(agents={"a": defn_a, "b": defn_b})
        result = await runtime.run(agent="a")
        assert isinstance(result, SimpleResult)
        assert result.value == "from_agent_b"


class TestSpawnCallAgent:
    async def test_spawn_children_and_collect_results(self) -> None:
        async def parent_handler(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            if tag == "start":
                return Spawn(
                    children=[
                        CallAgent(agent="child", spec=SimpleSpec(message="x")),
                        CallAgent(agent="child", spec=SimpleSpec(message="y")),
                    ],
                    then="collect",
                )
            # then step
            assert child_outputs is not None
            results = [r.result for r in child_outputs if isinstance(r.result, SimpleResult)]
            return SimpleResult(value=",".join(r.value for r in results))

        async def child_handler(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            assert isinstance(spec, SimpleSpec)
            return SimpleResult(value=spec.message)

        parent_defn = make_defn({"start": StepMeta(), "collect": StepMeta()}, parent_handler)
        child_defn = make_defn({"work": StepMeta()}, child_handler, entry_step="work")
        runtime = AgentRuntime(agents={"parent": parent_defn, "child": child_defn})
        result = await runtime.run(agent="parent")
        assert isinstance(result, SimpleResult)
        assert result.value == "x,y"


class TestSpawnCallStep:
    async def test_spawn_fork_children_and_collect(self) -> None:
        call_log: list[str] = []

        async def handler(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            call_log.append(tag)
            if tag == "start":
                return Spawn(
                    children=[
                        CallStep(step="task", spec=SimpleSpec(message="1")),
                        CallStep(step="task", spec=SimpleSpec(message="2")),
                    ],
                    then="join",
                )
            if tag == "task":
                assert isinstance(spec, SimpleSpec)
                return SimpleResult(value=f"task_{spec.message}")
            # join step
            assert child_outputs is not None
            results = [r.result for r in child_outputs if isinstance(r.result, SimpleResult)]
            return SimpleResult(value="+".join(r.value for r in results))

        defn = make_defn(
            {"start": StepMeta(), "task": StepMeta(), "join": StepMeta()},
            handler,
        )
        runtime = AgentRuntime(agents={"agent": defn})
        result = await runtime.run(agent="agent")
        assert isinstance(result, SimpleResult)
        assert result.value == "task_1+task_2"


class TestUnknownAgent:
    async def test_raises_key_error(self) -> None:
        runtime = AgentRuntime(agents={})
        with pytest.raises(KeyError):
            await runtime.run(agent="nonexistent")


# -- Type-based agent registration -------------------------------------------


class TestAutoCompileType:
    async def test_agent_subclass_auto_compiles(self) -> None:

        class MyAgent(Agent[None, SimpleResult]):
            @step(entry=True)
            async def start(self) -> SimpleResult:
                return SimpleResult(value="from_agent_class")

        runtime = AgentRuntime(agents={"a": MyAgent})
        result = await runtime.run(agent="a")
        assert isinstance(result, SimpleResult)
        assert result.value == "from_agent_class"

    async def test_class_based_and_defn_based_agents_both_runnable(self) -> None:

        class MyAgent(Agent[None, SimpleResult]):
            @step(entry=True)
            async def start(self) -> SimpleResult:
                return SimpleResult(value="class_based")

        async def handler(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            return SimpleResult(value="defn_based")

        defn = make_defn({"start": StepMeta()}, handler)
        runtime = AgentRuntime(agents={"a": MyAgent, "b": defn})

        r1 = await runtime.run(agent="a")
        assert isinstance(r1, SimpleResult)
        assert r1.value == "class_based"

        r2 = await runtime.run(agent="b")
        assert isinstance(r2, SimpleResult)
        assert r2.value == "defn_based"

    def test_duplicate_agent_class_raises(self) -> None:

        class MyAgent(Agent[None, SimpleResult]):
            @step(entry=True)
            async def start(self) -> SimpleResult:
                return SimpleResult(value="x")

        with pytest.raises(ValueError, match=r"Duplicate agent class.*MyAgent"):
            AgentRuntime(agents={"a": MyAgent, "b": MyAgent})


class TestRunWithAgentRef:
    async def test_run_with_agent_type(self) -> None:

        class Greeter(Agent[None, SimpleResult]):
            @step(entry=True)
            async def greet(self) -> SimpleResult:
                return SimpleResult(value="hello")

        runtime = AgentRuntime(agents={"g": Greeter})
        result = await runtime.run(agent=Greeter)
        assert isinstance(result, SimpleResult)
        assert result.value == "hello"

    async def test_run_with_agent_type_and_spec(self) -> None:

        class Greeter(Agent[SimpleSpec, SimpleResult]):
            @step(entry=True)
            async def greet(self, spec: Annotated[SimpleSpec, step_arg.SPEC]) -> SimpleResult:
                return SimpleResult(value=spec.message)

        runtime = AgentRuntime(agents={"g": Greeter})
        result = await runtime.run(agent=Greeter, spec=SimpleSpec(message="world"))
        assert isinstance(result, SimpleResult)
        assert result.value == "world"

    async def test_run_with_agent_string(self) -> None:

        class Greeter(Agent[None, SimpleResult]):
            @step(entry=True)
            async def greet(self) -> SimpleResult:
                return SimpleResult(value="string")

        runtime = AgentRuntime(agents={"g": Greeter})
        result = await runtime.run(agent="g")
        assert isinstance(result, SimpleResult)
        assert result.value == "string"

    async def test_run_with_unregistered_class_raises(self) -> None:

        class Registered(Agent[None, SimpleResult]):
            @step(entry=True)
            async def start(self) -> SimpleResult:
                return SimpleResult(value="ok")

        class NotRegistered(Agent[None, SimpleResult]):
            @step(entry=True)
            async def start(self) -> SimpleResult:
                return SimpleResult(value="nope")

        runtime = AgentRuntime(agents={"r": Registered})
        with pytest.raises(KeyError, match="NotRegistered"):
            await runtime.run(agent=NotRegistered)


class TestSubagentRegistration:
    async def test_subagents_automatically_registered(self) -> None:
        """Subagents declared in __subagents__ are registered with namespaced names."""

        class HelperAgent(Agent[None, SimpleResult]):
            @step(entry=True)
            async def execute(self) -> SimpleResult:
                return SimpleResult(value="helper_result")

        class MainAgent(Agent[None, SimpleResult]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {
                "helper": HelperAgent,
            }

            @step(entry=True)
            async def start(self) -> Spawn:
                return Spawn(
                    children=[CallAgent(agent="main/helper")],
                    then=self.collect,
                )

            @step
            async def collect(self, result: Annotated[SimpleResult, step_arg.CHILD]) -> SimpleResult:
                return SimpleResult(value=f"collected:{result.value}")

        runtime = AgentRuntime(agents={"main": MainAgent})
        result = await runtime.run(agent="main")
        assert isinstance(result, SimpleResult)
        assert result.value == "collected:helper_result"

    async def test_nested_subagents(self) -> None:
        """Nested subagents are registered with slash-separated names."""

        class GrandchildAgent(Agent[None, SimpleResult]):
            @step(entry=True)
            async def work(self) -> SimpleResult:
                return SimpleResult(value="grandchild")

        class ChildAgent(Agent[None, SimpleResult]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {
                "grandchild": GrandchildAgent,
            }

            @step(entry=True)
            async def process(self) -> Spawn:
                return Spawn(
                    children=[CallAgent(agent="parent/child/grandchild")],
                    then=self.done,
                )

            @step
            async def done(self, result: Annotated[SimpleResult, step_arg.CHILD]) -> SimpleResult:
                return SimpleResult(value=f"child:{result.value}")

        class ParentAgent(Agent[None, SimpleResult]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {
                "child": ChildAgent,
            }

            @step(entry=True)
            async def start(self) -> Spawn:
                return Spawn(
                    children=[CallAgent(agent="parent/child")],
                    then=self.finish,
                )

            @step
            async def finish(self, result: Annotated[SimpleResult, step_arg.CHILD]) -> SimpleResult:
                return SimpleResult(value=f"parent:{result.value}")

        runtime = AgentRuntime(agents={"parent": ParentAgent})
        result = await runtime.run(agent="parent")
        assert isinstance(result, SimpleResult)
        assert result.value == "parent:child:grandchild"

    async def test_subagent_type_reference(self) -> None:
        """Subagents can be referenced by type via CallAgent(agent=SubAgent)."""

        class HelperAgent(Agent[None, SimpleResult]):
            @step(entry=True)
            async def execute(self) -> SimpleResult:
                return SimpleResult(value="typed_helper")

        class MainAgent(Agent[None, SimpleResult]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {
                "helper": HelperAgent,
            }

            @step(entry=True)
            async def start(self) -> Spawn:
                return Spawn(
                    children=[CallAgent(agent=HelperAgent)],
                    then=self.collect,
                )

            @step
            async def collect(self, result: Annotated[SimpleResult, step_arg.CHILD]) -> SimpleResult:
                return SimpleResult(value=f"got:{result.value}")

        runtime = AgentRuntime(agents={"main": MainAgent})
        result = await runtime.run(agent="main")
        assert isinstance(result, SimpleResult)
        assert result.value == "got:typed_helper"

    async def test_subagent_relative_name(self) -> None:
        """Subagents can be referenced by relative name (e.g., './helper')."""

        class HelperAgent(Agent[None, SimpleResult]):
            @step(entry=True)
            async def execute(self) -> SimpleResult:
                return SimpleResult(value="relative_helper")

        class MainAgent(Agent[None, SimpleResult]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {
                "helper": HelperAgent,
            }

            @step(entry=True)
            async def start(self) -> Spawn:
                return Spawn(
                    children=[CallAgent(agent="./helper")],
                    then=self.collect,
                )

            @step
            async def collect(self, result: Annotated[SimpleResult, step_arg.CHILD]) -> SimpleResult:
                return SimpleResult(value=f"got:{result.value}")

        runtime = AgentRuntime(agents={"main": MainAgent})
        result = await runtime.run(agent="main")
        assert isinstance(result, SimpleResult)
        assert result.value == "got:relative_helper"

    async def test_same_type_multiple_parents(self) -> None:
        """Same subagent type under different parents resolves contextually."""

        class SharedWorker(Agent[None, SimpleResult]):
            @step(entry=True)
            async def work(self) -> SimpleResult:
                return SimpleResult(value="shared")

        class TeamA(Agent[None, SimpleResult]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {"worker": SharedWorker}

            @step(entry=True)
            async def start(self) -> Spawn:
                return Spawn(
                    children=[CallAgent(agent=SharedWorker)],
                    then=self.done,
                )

            @step
            async def done(self, result: Annotated[SimpleResult, step_arg.CHILD]) -> SimpleResult:
                return SimpleResult(value=f"a:{result.value}")

        class TeamB(Agent[None, SimpleResult]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {"worker": SharedWorker}

            @step(entry=True)
            async def start(self) -> Spawn:
                return Spawn(
                    children=[CallAgent(agent=SharedWorker)],
                    then=self.done,
                )

            @step
            async def done(self, result: Annotated[SimpleResult, step_arg.CHILD]) -> SimpleResult:
                return SimpleResult(value=f"b:{result.value}")

        runtime = AgentRuntime(agents={"team_a": TeamA, "team_b": TeamB})
        r1 = await runtime.run(agent="team_a")
        assert isinstance(r1, SimpleResult)
        assert r1.value == "a:shared"

        r2 = await runtime.run(agent="team_b")
        assert isinstance(r2, SimpleResult)
        assert r2.value == "b:shared"

    def test_invalid_agent_name_rejected(self) -> None:
        """Agent names with dots or special chars are rejected."""
        defn = make_defn({"start": StepMeta()}, lambda s, sp, cr, a: None)  # type: ignore[arg-type,return-value]
        with pytest.raises(ValueError, match="Invalid agent name"):
            AgentRuntime(agents={"invalid.name": defn})

        with pytest.raises(ValueError, match="Invalid agent name"):
            AgentRuntime(agents={"invalid name": defn})


class TestInterruptIntegration:
    async def test_agent_sees_interrupt_signal(self) -> None:
        """Agent receives InterruptToken via DI and sees runtime.interrupt() signal."""

        class InterruptableAgent(Agent[None, SimpleResult]):
            def __init__(self, interrupt: InterruptToken) -> None:
                self.interrupt = interrupt

            @step(entry=True)
            async def run(self) -> SimpleResult:
                if self.interrupt.interrupted:
                    return SimpleResult(value="interrupted")
                return SimpleResult(value="normal")

        runtime = AgentRuntime(agents={"a": InterruptableAgent})
        # Normal run — not interrupted
        result = await runtime.run(agent="a")
        assert isinstance(result, SimpleResult)
        assert result.value == "normal"

    async def test_interrupt_during_multi_step_agent(self) -> None:
        """Interrupt signal is visible to agent across steps."""
        interrupt_ref: list[InterruptToken] = []

        class MultiStepAgent(Agent[None, SimpleResult]):
            def __init__(self, interrupt: InterruptToken) -> None:
                self.interrupt = interrupt
                interrupt_ref.append(interrupt)

            @step(entry=True)
            async def start(self) -> GotoStep | SimpleResult:
                return GotoStep(step="check")

            @step
            async def check(self) -> SimpleResult:
                if self.interrupt.interrupted:
                    return SimpleResult(value="stopped")
                return SimpleResult(value="continued")

        runtime = AgentRuntime(agents={"a": MultiStepAgent})
        # Interrupt before second step executes — but runtime.interrupt()
        # must be called while the agent is running. Since steps are sync
        # from the test perspective, we interrupt between run() calls.
        # Instead, we test the token is the same one the runtime controls.
        runtime.interrupt()
        result = await runtime.run(agent="a")
        assert isinstance(result, SimpleResult)
        assert result.value == "stopped"


class TestSealedScopeProvide:
    async def test_provide_after_construction_raises(self) -> None:
        """Agent cannot call provide() on ServiceLocator after construction."""

        class BadAgent(Agent[None, SimpleResult]):
            def __init__(self, sl: ServiceLocator) -> None:
                self.sl = sl

            @step(entry=True)
            async def run(self) -> SimpleResult:
                self.sl.provide(str, "late")  # type: ignore[arg-type]
                return SimpleResult(value="should not reach")

        runtime = AgentRuntime(agents={"a": BadAgent})
        with pytest.raises(RuntimeError, match=r"provide.*during agent construction"):
            await runtime.run(agent="a")


class TestSealedScopeSlot:
    async def test_slot_after_construction_raises(self) -> None:
        """Agent cannot call slot() on AgentStore after construction."""

        class BadAgent(Agent[None, SimpleResult]):
            def __init__(self, sl: ServiceLocator) -> None:

                self.store: AgentStore = sl.services[AgentStore]

            @step(entry=True)
            async def run(self) -> SimpleResult:

                self.store.slot(Scalar[int], "late_slot")
                return SimpleResult(value="should not reach")

        runtime = AgentRuntime(agents={"a": BadAgent})
        with pytest.raises(RuntimeError, match=r"slot.*during agent construction"):
            await runtime.run(agent="a")


class TestMaxIterations:
    async def test_max_iterations_on_run(self) -> None:
        class LoopAgent(Agent[None, SimpleResult]):
            @step(entry=True)
            async def loop(self) -> GotoStep:
                return GotoStep(step=self.loop)

        runtime = AgentRuntime(agents={"a": LoopAgent})
        with pytest.raises(RuntimeError, match=r"max_iterations.*3"):
            await runtime.run(agent="a", max_iterations=3)

    async def test_max_iterations_default_from_constructor(self) -> None:
        class LoopAgent(Agent[None, SimpleResult]):
            @step(entry=True)
            async def loop(self) -> GotoStep:
                return GotoStep(step=self.loop)

        runtime = AgentRuntime(agents={"a": LoopAgent}, max_iterations=5)
        with pytest.raises(RuntimeError, match=r"max_iterations.*5"):
            await runtime.run(agent="a")

    async def test_run_overrides_constructor_default(self) -> None:
        class LoopAgent(Agent[None, SimpleResult]):
            @step(entry=True)
            async def loop(self) -> GotoStep:
                return GotoStep(step=self.loop)

        runtime = AgentRuntime(agents={"a": LoopAgent}, max_iterations=100)
        with pytest.raises(RuntimeError, match=r"max_iterations.*2"):
            await runtime.run(agent="a", max_iterations=2)

    async def test_none_overrides_constructor_default(self) -> None:
        """Passing max_iterations=None to run() disables the limit even if constructor set one."""
        call_count = 0

        class CountAgent(Agent[None, SimpleResult]):
            @step(entry=True)
            async def loop(self) -> GotoStep | SimpleResult:
                nonlocal call_count
                call_count += 1
                if call_count >= 10:
                    return SimpleResult(value="done")
                return GotoStep(step=self.loop)

        runtime = AgentRuntime(agents={"a": CountAgent}, max_iterations=3)
        result = await runtime.run(agent="a", max_iterations=None)
        assert isinstance(result, SimpleResult)
        assert result.value == "done"

    async def test_normal_completion_within_limit(self) -> None:
        class OkAgent(Agent[None, SimpleResult]):
            @step(entry=True)
            async def start(self) -> SimpleResult:
                return SimpleResult(value="ok")

        runtime = AgentRuntime(agents={"a": OkAgent}, max_iterations=10)
        result = await runtime.run(agent="a")
        assert isinstance(result, SimpleResult)
        assert result.value == "ok"


class TestTimeout:
    async def test_timeout_on_run(self) -> None:

        class SlowAgent(Agent[None, SimpleResult]):
            @step(entry=True)
            async def slow(self) -> SimpleResult:
                await asyncio.sleep(10)
                return SimpleResult(value="done")

        runtime = AgentRuntime(agents={"a": SlowAgent})
        with pytest.raises(asyncio.TimeoutError):
            await runtime.run(agent="a", timeout=0.05)

    async def test_timeout_default_from_constructor(self) -> None:

        class SlowAgent(Agent[None, SimpleResult]):
            @step(entry=True)
            async def slow(self) -> SimpleResult:
                await asyncio.sleep(10)
                return SimpleResult(value="done")

        runtime = AgentRuntime(agents={"a": SlowAgent}, timeout=0.05)
        with pytest.raises(asyncio.TimeoutError):
            await runtime.run(agent="a")

    async def test_run_overrides_constructor_timeout(self) -> None:

        class SlowAgent(Agent[None, SimpleResult]):
            @step(entry=True)
            async def slow(self) -> SimpleResult:
                await asyncio.sleep(10)
                return SimpleResult(value="done")

        runtime = AgentRuntime(agents={"a": SlowAgent}, timeout=10)
        with pytest.raises(asyncio.TimeoutError):
            await runtime.run(agent="a", timeout=0.05)

    async def test_normal_completion_within_timeout(self) -> None:
        class OkAgent(Agent[None, SimpleResult]):
            @step(entry=True)
            async def start(self) -> SimpleResult:
                return SimpleResult(value="ok")

        runtime = AgentRuntime(agents={"a": OkAgent}, timeout=5)
        result = await runtime.run(agent="a")
        assert isinstance(result, SimpleResult)
        assert result.value == "ok"


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class WorkResult:
    value: str


class TestInterruptedAutoPropagation:
    async def test_all_children_interrupted_auto_propagates(self) -> None:
        """When all children return Interrupted, parent auto-propagates."""

        class Worker(Agent[None, WorkResult]):
            def __init__(self, interrupt: InterruptToken) -> None:
                self.interrupt = interrupt

            @step(entry=True)
            async def run(self) -> WorkResult:
                self.interrupt.check()
                return WorkResult(value="ok")

        class Parent(Agent[None, WorkResult]):
            @step(entry=True)
            async def start(self) -> Spawn:
                return Spawn(
                    children=[
                        CallAgent(agent="worker", tag="w1"),
                        CallAgent(agent="worker", tag="w2"),
                    ],
                    then=self.join,
                )

            @step
            async def join(
                self,
                r1: Annotated[WorkResult, step_arg.CHILD("w1")],
                r2: Annotated[WorkResult, step_arg.CHILD("w2")],
            ) -> WorkResult:
                return WorkResult(value=f"{r1.value}+{r2.value}")

        runtime = AgentRuntime(agents={"parent": Parent, "worker": Worker})
        runtime.interrupt()
        result = await runtime.run(agent="parent")
        assert isinstance(result, Interrupted)

    async def test_all_children_interrupted_nullable_params_calls_step(self) -> None:
        """When all children interrupted but join step has nullable params, step is called with None."""

        class Worker(Agent[None, WorkResult]):
            def __init__(self, interrupt: InterruptToken) -> None:
                self.interrupt = interrupt

            @step(entry=True)
            async def run(self) -> WorkResult:
                self.interrupt.check()
                return WorkResult(value="ok")

        class Parent(Agent[None, WorkResult]):
            @step(entry=True)
            async def start(self) -> Spawn:
                return Spawn(
                    children=[
                        CallAgent(agent="worker", tag="w1"),
                        CallAgent(agent="worker", tag="w2"),
                    ],
                    then=self.join,
                )

            @step
            async def join(
                self,
                r1: Annotated[WorkResult | None, step_arg.CHILD("w1")],
                r2: Annotated[WorkResult | None, step_arg.CHILD("w2")],
            ) -> WorkResult:
                assert r1 is None
                assert r2 is None
                return WorkResult(value="handled")

        runtime = AgentRuntime(agents={"parent": Parent, "worker": Worker})
        runtime.interrupt()
        result = await runtime.run(agent="parent")
        assert isinstance(result, WorkResult)
        assert result.value == "handled"

    async def test_non_nullable_param_with_interrupted_child_propagates(self) -> None:
        """When a required param can't bind because child was interrupted, auto-propagate."""

        class Worker(Agent[None, WorkResult]):
            def __init__(self, interrupt: InterruptToken) -> None:
                self.interrupt = interrupt

            @step(entry=True)
            async def run(self) -> WorkResult:
                self.interrupt.check()
                return WorkResult(value="ok")

        class Parent(Agent[None, WorkResult]):
            @step(entry=True)
            async def start(self) -> Spawn:
                return Spawn(
                    children=[CallAgent(agent="worker")],
                    then=self.join,
                )

            @step
            async def join(self, result: Annotated[WorkResult, step_arg.CHILD]) -> WorkResult:
                return WorkResult(value=result.value)

        runtime = AgentRuntime(agents={"parent": Parent, "worker": Worker})
        runtime.interrupt()
        result = await runtime.run(agent="parent")
        assert isinstance(result, Interrupted)

    async def test_mixed_results_nullable_params(self) -> None:
        """One child completes, one interrupted. Nullable params bind correctly."""

        async def fast_handler(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:
            return WorkResult(value="fast_done")

        async def slow_handler(
            tag: str,
            spec: Any = None,
            child_outputs: list[ChildOutput] | None = None,
            agent_spec: Any = None,
        ) -> Any:

            raise InterruptedError

        class Parent(Agent[None, WorkResult]):
            @step(entry=True)
            async def start(self) -> Spawn:
                return Spawn(
                    children=[
                        CallAgent(agent="fast", tag="fast"),
                        CallAgent(agent="slow", tag="slow"),
                    ],
                    then=self.join,
                )

            @step
            async def join(
                self,
                fast: Annotated[WorkResult | None, step_arg.CHILD("fast")],
                slow: Annotated[WorkResult | None, step_arg.CHILD("slow")],
            ) -> WorkResult:
                fast_val = fast.value if fast else "none"
                slow_val = slow.value if slow else "none"
                return WorkResult(value=f"{fast_val}+{slow_val}")

        fast_defn = make_defn({"run": StepMeta()}, fast_handler, entry_step="run")
        slow_defn = make_defn({"run": StepMeta()}, slow_handler, entry_step="run")
        runtime = AgentRuntime(agents={"parent": Parent, "fast": fast_defn, "slow": slow_defn})
        result = await runtime.run(agent="parent")
        assert isinstance(result, WorkResult)
        assert result.value == "fast_done+none"


class TestWhenAllBackwardCompat:
    async def test_spawn_children_kwarg_still_works(self) -> None:
        """Spawn(children=[...], then=...) is backward compatible."""

        class Parent(Agent[None, WorkResult]):
            @step(entry=True)
            async def start(self) -> Spawn:
                return Spawn(
                    children=[
                        CallAgent(agent="w1", tag="a"),
                        CallAgent(agent="w2", tag="b"),
                    ],
                    then=self.join,
                )

            @step
            async def join(
                self,
                a: Annotated[WorkResult, step_arg.CHILD("a")],
                b: Annotated[WorkResult, step_arg.CHILD("b")],
            ) -> WorkResult:
                return WorkResult(value=f"{a.value}+{b.value}")

        class W1(Agent[None, WorkResult]):
            @step(entry=True)
            async def run(self) -> WorkResult:
                return WorkResult(value="one")

        class W2(Agent[None, WorkResult]):
            @step(entry=True)
            async def run(self) -> WorkResult:
                return WorkResult(value="two")

        runtime = AgentRuntime(agents={"parent": Parent, "w1": W1, "w2": W2})
        result = await runtime.run(agent="parent")
        assert isinstance(result, WorkResult)
        assert result.value == "one+two"


class TestWhenAny:
    async def test_first_wins_others_interrupted(self) -> None:
        """WhenAny: first child to complete wins, others get interrupted."""
        completed_order: list[str] = []

        class Fast(Agent[None, WorkResult]):
            @step(entry=True)
            async def run(self) -> WorkResult:
                completed_order.append("fast")
                return WorkResult(value="fast_result")

        class Slow(Agent[None, WorkResult]):
            def __init__(self, interrupt: InterruptToken) -> None:
                self.interrupt = interrupt

            @step(entry=True)
            async def run(self) -> WorkResult:
                await self.interrupt.wait()
                self.interrupt.check()
                return WorkResult(value="slow_result")

        class Parent(Agent[None, WorkResult]):
            @step(entry=True)
            async def start(self) -> Spawn:
                return Spawn(
                    WhenAny(
                        CallAgent(agent="fast", tag="fast"),
                        CallAgent(agent="slow", tag="slow"),
                    ),
                    then=self.join,
                )

            @step
            async def join(
                self,
                fast: Annotated[WorkResult | None, step_arg.CHILD("fast")],
                slow: Annotated[WorkResult | None, step_arg.CHILD("slow")],
            ) -> WorkResult:
                fast_val = fast.value if fast else "none"
                slow_val = slow.value if slow else "none"
                return WorkResult(value=f"{fast_val}+{slow_val}")

        runtime = AgentRuntime(agents={"parent": Parent, "fast": Fast, "slow": Slow})
        result = await runtime.run(agent="parent")
        assert isinstance(result, WorkResult)
        assert result.value == "fast_result+none"

    async def test_when_any_all_interrupted_propagates(self) -> None:
        """WhenAny: if all children interrupted, parent auto-propagates."""

        class Worker(Agent[None, WorkResult]):
            def __init__(self, interrupt: InterruptToken) -> None:
                self.interrupt = interrupt

            @step(entry=True)
            async def run(self) -> WorkResult:
                self.interrupt.check()
                return WorkResult(value="ok")

        class Parent(Agent[None, WorkResult]):
            @step(entry=True)
            async def start(self) -> Spawn:
                return Spawn(
                    WhenAny(
                        CallAgent(agent="worker", tag="w1"),
                        CallAgent(agent="worker", tag="w2"),
                    ),
                    then=self.join,
                )

            @step
            async def join(
                self,
                w1: Annotated[WorkResult, step_arg.CHILD("w1")],
                w2: Annotated[WorkResult, step_arg.CHILD("w2")],
            ) -> WorkResult:
                return WorkResult(value="joined")

        runtime = AgentRuntime(agents={"parent": Parent, "worker": Worker})
        runtime.interrupt()
        result = await runtime.run(agent="parent")
        assert isinstance(result, Interrupted)


class TestWhenN:
    async def test_when_n_two_of_three(self) -> None:
        """WhenN(n=2): first 2 completions win, third gets interrupted."""

        class Fast1(Agent[None, WorkResult]):
            @step(entry=True)
            async def run(self) -> WorkResult:
                return WorkResult(value="f1")

        class Fast2(Agent[None, WorkResult]):
            @step(entry=True)
            async def run(self) -> WorkResult:
                return WorkResult(value="f2")

        class Slow(Agent[None, WorkResult]):
            def __init__(self, interrupt: InterruptToken) -> None:
                self.interrupt = interrupt

            @step(entry=True)
            async def run(self) -> WorkResult:
                await self.interrupt.wait()
                self.interrupt.check()
                return WorkResult(value="slow")

        class Parent(Agent[None, WorkResult]):
            @step(entry=True)
            async def start(self) -> Spawn:
                return Spawn(
                    WhenN(
                        CallAgent(agent="f1", tag="a"),
                        CallAgent(agent="f2", tag="b"),
                        CallAgent(agent="slow", tag="c"),
                        n=2,
                    ),
                    then=self.join,
                )

            @step
            async def join(
                self,
                a: Annotated[WorkResult | None, step_arg.CHILD("a")],
                b: Annotated[WorkResult | None, step_arg.CHILD("b")],
                c: Annotated[WorkResult | None, step_arg.CHILD("c")],
            ) -> WorkResult:
                vals = [x.value if x else "none" for x in [a, b, c]]
                return WorkResult(value="+".join(vals))

        runtime = AgentRuntime(agents={"parent": Parent, "f1": Fast1, "f2": Fast2, "slow": Slow})
        result = await runtime.run(agent="parent")
        assert isinstance(result, WorkResult)
        assert result.value == "f1+f2+none"


class TestNestedCombinators:
    async def test_when_any_of_when_all(self) -> None:
        """WhenAny(WhenAll(a, b), c) — first group to complete wins."""

        class Instant(Agent[None, WorkResult]):
            @step(entry=True)
            async def run(self) -> WorkResult:
                return WorkResult(value="instant")

        class Slow(Agent[None, WorkResult]):
            def __init__(self, interrupt: InterruptToken) -> None:
                self.interrupt = interrupt

            @step(entry=True)
            async def run(self) -> WorkResult:
                await self.interrupt.wait()
                self.interrupt.check()
                return WorkResult(value="slow")

        class Parent(Agent[None, WorkResult]):
            @step(entry=True)
            async def start(self) -> Spawn:
                return Spawn(
                    WhenAny(
                        WhenAll(
                            CallAgent(agent="instant", tag="a"),
                            CallAgent(agent="instant", tag="b"),
                        ),
                        CallAgent(agent="slow", tag="c"),
                    ),
                    then=self.join,
                )

            @step
            async def join(
                self,
                a: Annotated[WorkResult | None, step_arg.CHILD("a")],
                b: Annotated[WorkResult | None, step_arg.CHILD("b")],
                c: Annotated[WorkResult | None, step_arg.CHILD("c")],
            ) -> WorkResult:
                vals = [x.value if x else "none" for x in [a, b, c]]
                return WorkResult(value="+".join(vals))

        runtime = AgentRuntime(agents={"parent": Parent, "instant": Instant, "slow": Slow})
        result = await runtime.run(agent="parent")
        assert isinstance(result, WorkResult)
        # WhenAll(a,b) satisfies instantly, c gets interrupted
        assert result.value == "instant+instant+none"


class TestTimeoutAgent:
    async def test_when_any_with_timeout_worker_wins(self) -> None:
        """WhenAny(worker, timeout): worker completes before timeout."""

        class Fast(Agent[None, WorkResult]):
            @step(entry=True)
            async def run(self) -> WorkResult:
                return WorkResult(value="fast")

        class Parent(Agent[None, WorkResult]):
            @step(entry=True)
            async def start(self) -> Spawn:
                return Spawn(
                    WhenAny(
                        CallAgent(agent="fast", tag="worker"),
                        timeout(seconds=10),
                    ),
                    then=self.join,
                )

            @step
            async def join(
                self,
                worker: Annotated[WorkResult | None, step_arg.CHILD("worker")],
                expired: Annotated[TimeoutExpired | None, step_arg.CHILD],
            ) -> WorkResult:
                assert worker is not None
                assert expired is None
                return WorkResult(value=worker.value)

        runtime = AgentRuntime(agents={"parent": Parent, "fast": Fast})
        result = await runtime.run(agent="parent")
        assert isinstance(result, WorkResult)
        assert result.value == "fast"

    async def test_when_any_with_timeout_timeout_wins(self) -> None:
        """WhenAny(worker, timeout): timeout fires, worker gets interrupted."""

        class Slow(Agent[None, WorkResult]):
            def __init__(self, interrupt: InterruptToken) -> None:
                self.interrupt = interrupt

            @step(entry=True)
            async def run(self) -> WorkResult:
                await self.interrupt.wait()
                self.interrupt.check()
                return WorkResult(value="slow")

        class Parent(Agent[None, WorkResult]):
            @step(entry=True)
            async def start(self) -> Spawn:
                return Spawn(
                    WhenAny(
                        CallAgent(agent="slow", tag="worker"),
                        timeout(seconds=0.01),
                    ),
                    then=self.join,
                )

            @step
            async def join(
                self,
                worker: Annotated[WorkResult | None, step_arg.CHILD("worker")],
                expired: Annotated[TimeoutExpired | None, step_arg.CHILD],
            ) -> WorkResult:
                assert worker is None
                assert expired is not None
                assert expired.seconds == 0.01
                return WorkResult(value="timeout")

        runtime = AgentRuntime(agents={"parent": Parent, "slow": Slow})
        result = await runtime.run(agent="parent")
        assert isinstance(result, WorkResult)
        assert result.value == "timeout"
