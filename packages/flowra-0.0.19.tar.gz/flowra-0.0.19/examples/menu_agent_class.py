"""Pure state-machine agent demo using Agent base class.

Same menu/calc/echo demo as menu_agent.py, but using the Agent base class
with type-based references and direct GotoStep/CallAgent/Spawn constructors.

Usage:
    uv run python examples/menu_agent_class.py
"""

import asyncio
import dataclasses

from examples.tools import eval_expression
from flowra.agent import (
    Agent,
    AgentDefinitionRef,
    AgentRuntime,
    AgentStore,
    AppendOnlyList,
    CallAgent,
    GotoStep,
    InMemorySessionStorage,
    Scalar,
    Spawn,
    step,
)

# -- Specs & Results ----------------------------------------------------------


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class UserInput:
    text: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class PromptResult:
    text: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class DoneResult:
    text: str


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class QuitResult:
    pass


# -- Calculator ---------------------------------------------------------------


def _calculate(expression: str) -> str:
    try:
        return eval_expression(expression)
    except Exception as e:
        return f"Error: {e}"


class CalcAgent(Agent):
    __slots__ = ("__history",)

    def __init__(self, store: AgentStore) -> None:
        self.__history = store.slot(AppendOnlyList[str], "history")

    @step(entry=True)
    async def main(self, spec: UserInput | None = None) -> PromptResult | QuitResult:
        if isinstance(spec, UserInput):
            expr = spec.text.strip()
            if expr.lower() in ("q", "quit", "back"):
                return QuitResult()
            result = _calculate(expr)
            self.__history.append(f"{expr} = {result}")
            return PromptResult(text=f"  = {result}\ncalc> ")
        return PromptResult(text="calc> ")


# -- Echo ---------------------------------------------------------------------


class EchoAgent(Agent):
    __slots__ = ("__count",)

    def __init__(self, store: AgentStore) -> None:
        self.__count = store.slot(Scalar[int], "count")

    @step(entry=True)
    async def main(self, spec: UserInput | None = None) -> PromptResult | QuitResult:
        if isinstance(spec, UserInput):
            text = spec.text.strip()
            if text.lower() in ("q", "quit", "back"):
                return QuitResult()
            self.__count.set(self.__count.get(0) + 1)
            return PromptResult(text=f"  echo: {text}\necho> ")
        return PromptResult(text="echo> ")


# -- Menu (root) --------------------------------------------------------------

_MENU_TEXT = """
=== Menu ===
1. Calculator
2. Echo
q. Quit
choice> """


class MenuAgent(Agent):
    __slots__ = ("__mode",)

    def __init__(self, store: AgentStore) -> None:
        self.__mode = store.slot(Scalar[str], "mode")

    @step(entry=True)
    async def main(self, spec: UserInput | None = None) -> GotoStep | DoneResult | PromptResult | Spawn:
        current = self.__mode.get("")
        if isinstance(spec, UserInput):
            if not current:
                choice = spec.text.strip().lower()
                if choice == "1":
                    self.__mode.set("calc")
                    return GotoStep(step=self.show_prompt)
                if choice == "2":
                    self.__mode.set("echo")
                    return GotoStep(step=self.show_prompt)
                if choice in ("q", "quit"):
                    return DoneResult(text="Bye!")
                return PromptResult(text=f"  Unknown: {spec.text!r}\nchoice> ")
            if current == "calc":
                call = CallAgent(agent=CalcAgent, spec=spec, storage_key="calc")
            else:
                call = CallAgent(agent=EchoAgent, spec=spec, storage_key="echo")
            return Spawn(children=[call], then=self.handle_child)
        return GotoStep(step=self.show_prompt)

    @step
    async def show_prompt(self) -> PromptResult | Spawn:
        current = self.__mode.get("")
        if current == "calc":
            return Spawn(
                children=[CallAgent(agent=CalcAgent, storage_key="calc")],
                then=self.forward,
            )
        if current == "echo":
            return Spawn(
                children=[CallAgent(agent=EchoAgent, storage_key="echo")],
                then=self.forward,
            )
        return PromptResult(text=_MENU_TEXT)

    @step
    async def forward(self, cr: list[PromptResult | QuitResult]) -> PromptResult | QuitResult:
        return cr[0]

    @step
    async def handle_child(self, cr: list[PromptResult | QuitResult]) -> GotoStep | PromptResult:
        child_result = cr[0]
        if isinstance(child_result, QuitResult):
            self.__mode.set("")
            return GotoStep(step=self.show_prompt)
        return child_result


# -- Main ---------------------------------------------------------------------


async def main() -> None:
    agents: dict[str, AgentDefinitionRef] = {
        "menu": MenuAgent,
        "calc": CalcAgent,
        "echo": EchoAgent,
    }
    storage = InMemorySessionStorage()
    runtime = AgentRuntime(agents=agents, storage=storage)

    spec: UserInput | None = None
    while True:
        result = await runtime.run(agent="menu", spec=spec)
        if isinstance(result, DoneResult):
            print(result.text)
            break
        assert isinstance(result, PromptResult)
        user_input = input(result.text)
        spec = UserInput(text=user_input)


if __name__ == "__main__":
    asyncio.run(main())
