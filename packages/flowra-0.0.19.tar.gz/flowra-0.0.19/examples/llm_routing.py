"""LLM router for chat examples — routes requests to providers by model key."""

import dataclasses
from collections.abc import AsyncIterator
from typing import Any

from flowra.llm import LLMProvider, LLMRequest, LLMResponse, StreamEvent

__all__ = ["ChatLLMRouter", "ModelEntry"]


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class ModelEntry:
    provider: LLMProvider
    model_id: str
    additional_config: dict[str, Any] = dataclasses.field(default_factory=dict)


class ChatLLMRouter(LLMProvider):
    __slots__ = ("__models",)

    def __init__(self, models: dict[str, ModelEntry]) -> None:
        self.__models = models

    @property
    def available_models(self) -> list[str]:
        return sorted(self.__models)

    def __resolve(self, request: LLMRequest) -> tuple[LLMProvider, LLMRequest]:
        entry = self.__models[request.model]
        actual_request = dataclasses.replace(
            request,
            model=entry.model_id,
            additional_config={**entry.additional_config, **request.additional_config},
        )
        return entry.provider, actual_request

    async def call(self, request: LLMRequest) -> LLMResponse:
        provider, actual_request = self.__resolve(request)
        return await provider.call(actual_request)

    async def stream(self, request: LLMRequest) -> AsyncIterator[StreamEvent]:
        provider, actual_request = self.__resolve(request)
        async for event in provider.stream(actual_request):
            yield event
