"""LLM request/response logging via span-hooks.

Usage::

    from examples.llm_logging import install_llm_logging, setup_file_logging
    from flowra.agent import HookSubscription

    setup_file_logging("console_chat")
    hooks = HookSubscription()
    install_llm_logging(hooks)
"""

import datetime
import logging
import os
from typing import Any

from flowra.agent import HookSubscription
from flowra.llm import ImageBlock, LLMCallSpan, Message, TextBlock, ThinkingBlock, ToolResultBlock, ToolUseBlock

_LOGS_DIR = ".logs"

logger = logging.getLogger(__name__)


def setup_file_logging(prefix: str) -> logging.FileHandler:
    """Configure file logging for LLM calls and return the handler."""
    os.makedirs(_LOGS_DIR, exist_ok=True)
    filename = datetime.datetime.now().strftime(f"{prefix}_%Y%m%d_%H%M%S.log")
    handler = logging.FileHandler(os.path.join(_LOGS_DIR, filename), mode="w", encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(asctime)s.%(msecs)03d  %(message)s", datefmt="%H:%M:%S"))

    logger.setLevel(logging.DEBUG)
    logger.addHandler(handler)
    return handler


def install_llm_logging(hooks: HookSubscription) -> None:
    """Register an LLM call span handler that logs requests and responses."""
    hooks.on_span(LLMCallSpan, _on_llm_span)


def _on_llm_span(span: LLMCallSpan) -> Any:
    if logger.isEnabledFor(logging.DEBUG):
        logger.debug(
            "LLM request: model=%s, messages=%d, tools=%d\n%s",
            span.request.model,
            len(span.request.system) + len(span.request.messages),
            len(span.request.tools) if span.request.tools else 0,
            _format_messages(list(span.request.system) + list(span.request.messages)),
        )

    def on_end(error: BaseException | None = None) -> None:
        if not logger.isEnabledFor(logging.DEBUG):
            return
        if span.response is not None:
            logger.debug(
                "LLM response: stop_reason=%s, usage=%s\n%s",
                span.response.stop_reason,
                span.response.usage,
                _format_messages([span.response.message]),
            )
        elif error is not None:
            logger.debug("LLM call failed: %s", error)

    return on_end


def _format_messages(messages: list[Message]) -> str:
    parts: list[str] = []
    for i, msg in enumerate(messages):
        parts.append(f"  [{i}] {msg.role}:")
        for block in msg.blocks:
            match block:
                case TextBlock(text=text):
                    parts.append(f"       text: {text}")
                case ToolUseBlock(id=tid, name=name, input=inp):
                    parts.append(f"       tool_use: {name} (id={tid}) input={inp}")
                case ToolResultBlock(tool_use_id=tid, content=content, is_error=is_error):
                    error_marker = " [ERROR]" if is_error else ""
                    parts.append(f"       tool_result: (id={tid}){error_marker} {content}")
                case ThinkingBlock(text=text):
                    parts.append(f"       thinking: {text[:200]}...")
                case ImageBlock(media_type=media_type):
                    parts.append(f"       image: {media_type}")
    return "\n".join(parts)
