"""Model registry — creates ChatLLMRouter from environment configuration."""

import os

from google.genai import types as genai_types

from examples.llm_routing import ChatLLMRouter, ModelEntry
from flowra.llm.providers.anthropic_vertex import AnthropicVertexProvider
from flowra.llm.providers.google_vertex import GoogleVertexProvider
from flowra.llm.providers.openai import OpenAIProvider

__all__ = ["DEFAULT_MODEL", "create_router"]

DEFAULT_MODEL = "anthropic/sonnet-4-5"


def create_router() -> ChatLLMRouter:
    """Build a ChatLLMRouter with all configured model providers."""
    models: dict[str, ModelEntry] = {}

    # --- Vertex AI (shared credentials for Google + Anthropic) ---
    project = os.environ.get("VERTEX_PROJECT_NAME")
    location = os.environ.get("VERTEX_LOCATION")
    credentials_b64 = os.environ.get("VERTEX_CREDENTIALS")

    if project and location and credentials_b64:
        # Google Vertex provider (default location)
        google_provider = GoogleVertexProvider(project=project, location=location, credentials=credentials_b64)

        models["google/gemini-2.5-flash"] = ModelEntry(provider=google_provider, model_id="gemini-2.5-flash")
        models["google/gemini-2.5-pro"] = ModelEntry(provider=google_provider, model_id="gemini-2.5-pro")

        # Google Vertex provider (global location for gemini-3.x)
        google_global_provider = GoogleVertexProvider(project=project, location="global", credentials=credentials_b64)

        models["google/gemini-3.1-flash-lite"] = ModelEntry(
            provider=google_global_provider, model_id="gemini-3.1-flash-lite-preview"
        )
        models["google/gemini-3.1-flash-lite-think-low"] = ModelEntry(
            provider=google_global_provider,
            model_id="gemini-3.1-flash-lite-preview",
            additional_config={"thinking_level": genai_types.ThinkingLevel.LOW},
        )
        models["google/gemini-3.1-flash-lite-think-medium"] = ModelEntry(
            provider=google_global_provider,
            model_id="gemini-3.1-flash-lite-preview",
            additional_config={"thinking_level": genai_types.ThinkingLevel.MEDIUM},
        )
        models["google/gemini-3.1-flash-lite-think-high"] = ModelEntry(
            provider=google_global_provider,
            model_id="gemini-3.1-flash-lite-preview",
            additional_config={"thinking_level": genai_types.ThinkingLevel.HIGH},
        )

        # Anthropic via Vertex
        anthropic_provider = AnthropicVertexProvider(project=project, location=location, credentials=credentials_b64)

        models["anthropic/sonnet-4-5"] = ModelEntry(provider=anthropic_provider, model_id="claude-sonnet-4-5@20250929")
        models["anthropic/sonnet-4-5-think"] = ModelEntry(
            provider=anthropic_provider,
            model_id="claude-sonnet-4-5@20250929",
            additional_config={"thinking_budget_tokens": 4000},
        )
        models["anthropic/haiku-4-5"] = ModelEntry(provider=anthropic_provider, model_id="claude-haiku-4-5@20251001")

    # --- OpenAI ---
    openai_api_key = os.environ.get("OPENAI_API_KEY")
    if openai_api_key:
        openai_provider = OpenAIProvider(api_key=openai_api_key)

        models["openai/gpt-4.1-mini"] = ModelEntry(provider=openai_provider, model_id="gpt-4.1-mini")
        models["openai/gpt-4.1"] = ModelEntry(provider=openai_provider, model_id="gpt-4.1")

    # --- Inception ---
    inception_api_key = os.environ.get("INCEPTION_API_KEY")
    if inception_api_key:
        inception_base_url = os.environ.get("INCEPTION_BASE_URL", "https://api.inceptionlabs.ai/v1")
        inception_provider = OpenAIProvider(api_key=inception_api_key, base_url=inception_base_url)

        models["inception/mercury-2"] = ModelEntry(provider=inception_provider, model_id="mercury-2")

    return ChatLLMRouter(models)


def available_models(router: ChatLLMRouter) -> str:
    return "\n".join(f"- {k}" for k in router.available_models)
