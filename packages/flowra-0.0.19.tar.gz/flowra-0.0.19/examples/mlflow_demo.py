"""MLflow tracing demo — runs a single chat request with MLflow tracing.

Usage:
    make mlflow-demo
    # or directly (with .env loaded):
    uv run python examples/mlflow_demo.py

Then view traces:
    uv run mlflow ui --port 5050
    # open http://localhost:5050, experiment "flowra-demo", Traces tab
"""

import asyncio
import pathlib

from examples.app_agent import AppAgent, AppConfig
from examples.model_registry import DEFAULT_MODEL, create_router
from examples.tools import calculate, random_numbers
from flowra.agent import AgentRuntime, HookSubscription, InMemorySessionStorage
from flowra.ext.mlflow import install_mlflow_tracing
from flowra.lib.chat import ChatResult, ChatSpec
from flowra.llm import LLMProvider, SystemMessage, TextBlock
from flowra.tools import ToolRegistry, get_local_tool

_EXAMPLES_DIR = pathlib.Path(__file__).parent
_SYSTEM_PROMPT = (_EXAMPLES_DIR / "system_prompt.txt").read_text()


async def main() -> None:
    router = create_router()

    async with await ToolRegistry.create([get_local_tool(calculate), get_local_tool(random_numbers)]) as registry:
        app_config = AppConfig(
            default_model=DEFAULT_MODEL,
            system=lambda: [
                SystemMessage(blocks=[TextBlock(text=_SYSTEM_PROMPT)]),
            ],
        )

        hooks = HookSubscription()
        install_mlflow_tracing(hooks, experiment_name="flowra-demo", trace_steps=True)

        runtime = AgentRuntime(
            agents={"app": AppAgent},
            storage=InMemorySessionStorage(),
            services={
                ToolRegistry: registry,
                AppConfig: app_config,
                HookSubscription: hooks,
                LLMProvider: router,
            },
        )

        print("Sending: What is 2+2? Use the calculator tool.")
        result = await runtime.run(
            agent=AppAgent,
            spec=ChatSpec(user_message="What is 2+2? Use the calculator tool."),
        )

        if isinstance(result, ChatResult):
            print(f"\nAssistant: {result.response}")
            if result.usage:
                print(f"Tokens: {result.usage.input_tokens} in, {result.usage.output_tokens} out")
                if result.usage.cost_usd is not None:
                    print(f"Cost: ${result.usage.cost_usd:.4f}")

    print("\nDone! View traces: uv run mlflow ui --port 5050")


if __name__ == "__main__":
    asyncio.run(main())
