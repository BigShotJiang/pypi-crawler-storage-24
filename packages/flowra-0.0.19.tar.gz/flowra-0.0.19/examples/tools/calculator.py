"""Calculator tool — safe math expression evaluator with interrupt support."""

import ast
import asyncio
import dataclasses
import logging
import operator
import os
import random
import sys
from typing import Any

from flowra.agent import InterruptToken
from flowra.tools import tool

log = logging.getLogger(__name__)

TOOL_DELAY = float(os.environ.get("TOOL_DELAY", "0"))  # seconds; set >0 to simulate slow tools
CRASH_CHANCE = float(os.environ.get("CRASH_CHANCE", "0"))  # 0.0 to 1.0

# -- Safe math eval -----------------------------------------------------------

_SAFE_OPS: dict[type, Any] = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.Pow: operator.pow,
    ast.USub: operator.neg,
    ast.UAdd: operator.pos,
    ast.Mod: operator.mod,
    ast.FloorDiv: operator.floordiv,
}


def _safe_eval(node: ast.expr) -> float:
    match node:
        case ast.Constant(value=v) if isinstance(v, int | float):
            return float(v)
        case ast.BinOp(left=left, op=op, right=right):
            fn = _SAFE_OPS.get(type(op))
            if fn is None:
                raise ValueError(f"Unsupported operator: {type(op).__name__}")
            return float(fn(_safe_eval(left), _safe_eval(right)))
        case ast.UnaryOp(op=op, operand=operand):
            fn = _SAFE_OPS.get(type(op))
            if fn is None:
                raise ValueError(f"Unsupported unary: {type(op).__name__}")
            return float(fn(_safe_eval(operand)))
        case _:
            raise ValueError(f"Unsupported expression: {ast.dump(node)}")


def eval_expression(expression: str) -> str:
    tree = ast.parse(expression, mode="eval")
    result = _safe_eval(tree.body)
    if result == int(result):
        return str(int(result))
    return str(result)


# -- Tool definition ----------------------------------------------------------


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class CalculateParams:
    expression: str


@tool("calculate")
async def calculate(params: CalculateParams, interrupt: InterruptToken) -> str:
    """Evaluate a math expression. Supports +, -, *, /, **, //, %, and parentheses."""
    log.info("TOOL calculate(%s) — sleeping %.1fs", params.expression, TOOL_DELAY)
    try:
        await asyncio.wait_for(interrupt.wait(), timeout=TOOL_DELAY)
        log.info("TOOL calculate(%s) — interrupted during sleep", params.expression)
        return "Error: computation interrupted"
    except TimeoutError:
        pass
    if CRASH_CHANCE > 0 and random.random() < CRASH_CHANCE:
        log.info("TOOL calculate(%s) — CRASH! (chance=%.0f%%)", params.expression, CRASH_CHANCE * 100)
        print(f"\n💥 CRASH during calculate({params.expression})!", flush=True)
        sys.exit(1)
    try:
        answer = eval_expression(params.expression)
        log.info("TOOL calculate(%s) => %s", params.expression, answer)
        return answer
    except Exception as e:
        log.info("TOOL calculate(%s) => ERROR: %s", params.expression, e)
        return f"Error: {e}"
