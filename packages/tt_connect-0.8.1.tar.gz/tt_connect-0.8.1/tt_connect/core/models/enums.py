"""Canonical enums used across the public tt-connect API."""

from enum import StrEnum


class Exchange(StrEnum):
    """Supported exchanges/segments in canonical form."""

    NSE = "NSE"
    BSE = "BSE"
    NFO = "NFO"   # NSE F&O
    BFO = "BFO"   # BSE F&O
    CDS = "CDS"   # Currency derivatives
    MCX = "MCX"   # Commodity


class OptionType(StrEnum):
    """Option side."""

    CE = "CE"
    PE = "PE"


class ProductType(StrEnum):
    """Broker product/margin categories."""

    CNC  = "CNC"   # Cash and carry (delivery)
    MIS  = "MIS"   # Margin intraday
    NRML = "NRML"  # Normal (F&O carry forward)


class OrderType(StrEnum):
    """Supported order execution types."""

    MARKET = "MARKET"
    LIMIT  = "LIMIT"
    SL     = "SL"    # Stop-loss limit
    SL_M   = "SL_M"  # Stop-loss market


class Side(StrEnum):
    """Order direction."""

    BUY  = "BUY"
    SELL = "SELL"


class OrderStatus(StrEnum):
    """Normalized order lifecycle statuses."""

    PENDING   = "PENDING"
    OPEN      = "OPEN"
    COMPLETE  = "COMPLETE"
    CANCELLED = "CANCELLED"
    REJECTED  = "REJECTED"


class OnStale(StrEnum):
    """Behavior when local instrument data is stale."""

    FAIL = "fail"
    WARN = "warn"


class AuthMode(StrEnum):
    """Authentication strategy selection."""

    MANUAL = "manual"   # User supplies access_token; library never logs in autonomously
    AUTO   = "auto"     # Library performs TOTP login + token refresh automatically


class ClientState(StrEnum):
    """Lifecycle state of an AsyncTTConnect / TTConnect client."""

    CREATED   = "created"
    CONNECTED = "connected"
    CLOSED    = "closed"


class FeedState(StrEnum):
    """Live state of a broker WebSocket feed."""

    CONNECTING   = "connecting"    # initial / attempting first connect
    CONNECTED    = "connected"     # socket open, ticks flowing normally
    RECONNECTING = "reconnecting"  # socket dropped, backoff in progress
    STALE        = "stale"         # connected but no tick within threshold
    CLOSED       = "closed"        # deliberately shut down


class CandleInterval(StrEnum):
    """Canonical OHLC candle intervals, broker-agnostic."""

    MINUTE_1  = "1minute"
    MINUTE_3  = "3minute"
    MINUTE_5  = "5minute"
    MINUTE_10 = "10minute"
    MINUTE_15 = "15minute"
    MINUTE_30 = "30minute"
    HOUR_1    = "60minute"
    DAY       = "day"
