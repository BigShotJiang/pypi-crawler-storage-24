"""Canonical response models — what comes back from the broker."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict

from tt_connect.core.timezone import ISTDatetime

from tt_connect.core.models.enums import OrderStatus, OrderType, ProductType, Side
from tt_connect.core.models.instruments import Instrument
from tt_connect.core.models.requests import GttLeg


class Gtt(BaseModel):
    """Normalized GTT rule record returned by get_gtt / get_gtts."""

    model_config = ConfigDict(frozen=True)

    gtt_id: str
    status: str          # raw broker status string (differs per broker)
    symbol: str          # broker's own trading symbol
    exchange: str
    legs: list[GttLeg]   # 1 for single, 2 for OCO


class Profile(BaseModel):
    """Normalized broker account profile."""

    model_config = ConfigDict(frozen=True)

    client_id: str
    name: str
    email: str
    phone: str | None = None


class Fund(BaseModel):
    """Normalized funds/margin summary."""

    model_config = ConfigDict(frozen=True)

    available: float
    used: float
    total: float
    collateral: float = 0.0
    m2m_unrealized: float = 0.0
    m2m_realized: float = 0.0


class Holding(BaseModel):
    """Normalized demat holding record."""

    model_config = ConfigDict(frozen=True)

    instrument: Instrument
    qty: int
    avg_price: float
    ltp: float
    pnl: float
    pnl_percent: float = 0.0


class Position(BaseModel):
    """Normalized open position record."""

    model_config = ConfigDict(frozen=True)

    instrument: Instrument
    qty: int
    avg_price: float
    ltp: float
    pnl: float
    product: ProductType


class Order(BaseModel):
    """Normalized order record."""

    model_config = ConfigDict(frozen=True)

    id: str
    instrument: Instrument | None = None
    side: Side
    qty: int
    filled_qty: int
    product: ProductType
    order_type: OrderType
    status: OrderStatus
    price: float | None = None
    trigger_price: float | None = None
    avg_price: float | None = None
    timestamp: ISTDatetime | None = None


class Trade(BaseModel):
    """Normalized trade-book entry."""

    model_config = ConfigDict(frozen=True)

    order_id: str
    instrument: Instrument
    side: Side
    qty: int
    avg_price: float
    trade_value: float
    product: ProductType
    timestamp: ISTDatetime | None = None


class Margin(BaseModel):
    """Normalized margin estimation result."""

    model_config = ConfigDict(frozen=True)

    total: float            # initial total margin required
    span: float
    exposure: float
    option_premium: float = 0.0
    final_total: float      # after portfolio netting / spread benefit
    benefit: float          # = total - final_total


class Tick(BaseModel):
    """Normalized streaming market data tick."""

    model_config = ConfigDict(frozen=True)

    instrument: Instrument
    ltp: float
    volume: int | None = None
    oi: int | None = None
    bid: float | None = None
    ask: float | None = None
    timestamp: ISTDatetime | None = None


class Candle(BaseModel):
    """Normalized OHLC candle for one interval period."""

    model_config = ConfigDict(frozen=True)

    instrument: Instrument
    timestamp: ISTDatetime
    open: float
    high: float
    low: float
    close: float
    volume: int
    oi: int | None = None
