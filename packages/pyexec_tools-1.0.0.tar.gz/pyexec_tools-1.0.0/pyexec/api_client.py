"""
API client for PyExecutor backend
"""

import requests
from typing import Optional, Dict, Any, List
from .config import config


class APIClient:
    """Client for PyExecutor REST API"""
    
    def __init__(self):
        self.base_url = config.api_url
        self.api_key = config.api_key
        self.timeout = config.timeout
        self.session = requests.Session()
        self.session.headers.update({
            'Authorization': f'Bearer {self.api_key}',
            'Content-Type': 'application/json',
        })
    
    def _request(self, method: str, endpoint: str, **kwargs) -> Dict[Any, Any]:
        """Make HTTP request to API"""
        url = f"{self.base_url.rstrip('/')}/{endpoint.lstrip('/')}"
        
        try:
            response = self.session.request(
                method,
                url,
                timeout=kwargs.pop('timeout', self.timeout),
                **kwargs
            )
            response.raise_for_status()
            
            if response.status_code == 204:
                return {}
            
            return response.json()
        
        except requests.exceptions.HTTPError as e:
            # Try to extract error message from response
            try:
                error_data = e.response.json()
                error_msg = error_data.get('error', error_data.get('detail', str(e)))
            except:
                error_msg = str(e)
            
            raise APIError(f"API Error: {error_msg}", status_code=e.response.status_code)
        
        except requests.exceptions.RequestException as e:
            raise APIError(f"Connection error: {str(e)}")
    
    # Workflows
    def list_workflows(self, filter_params: Optional[Dict] = None) -> List[Dict]:
        """List all workflows"""
        params = filter_params or {}
        return self._request('GET', '/api/workflows/', params=params)
    
    def get_workflow_id(self, name_or_id: str) -> str:
        """Resolve workflow name to ID. Returns ID if already an ID."""
        # If it's already numeric, assume it's an ID
        if name_or_id.isdigit():
            return name_or_id
        
        # Otherwise, search by name
        workflows_data = self.list_workflows()
        workflows = workflows_data.get('results', workflows_data) if isinstance(workflows_data, dict) else workflows_data
        
        for workflow in workflows:
            if workflow.get('name') == name_or_id:
                return str(workflow.get('id'))
        
        raise APIError(f"Workflow '{name_or_id}' not found")
    
    def get_workflow(self, name_or_id: str) -> Dict:
        """Get workflow details by name or ID"""
        workflow_id = self.get_workflow_id(name_or_id)
        return self._request('GET', f'/api/workflows/{workflow_id}/')
    
    def create_workflow(self, data: Dict) -> Dict:
        """Create new workflow"""
        return self._request('POST', '/api/workflows/', json=data)
    
    def execute_workflow(self, name_or_id: str, context: Optional[Dict] = None) -> Dict:
        """Execute a workflow by name or ID"""
        workflow_id = self.get_workflow_id(name_or_id)
        return self._request('POST', f'/api/workflows/{workflow_id}/run/', json=context or {})
    
    def enable_workflow(self, name_or_id: str) -> Dict:
        """Enable a workflow by name or ID"""
        workflow_id = self.get_workflow_id(name_or_id)
        return self._request('POST', f'/api/workflows/{workflow_id}/enable/')
    
    def disable_workflow(self, name_or_id: str) -> Dict:
        """Disable a workflow by name or ID"""
        workflow_id = self.get_workflow_id(name_or_id)
        return self._request('POST', f'/api/workflows/{workflow_id}/disable/')
    
    def delete_workflow(self, name_or_id: str) -> Dict:
        """Delete a workflow by name or ID"""
        workflow_id = self.get_workflow_id(name_or_id)
        return self._request('DELETE', f'/api/workflows/{workflow_id}/')
    
    # Jobs
    def list_jobs(self, filter_params: Optional[Dict] = None) -> List[Dict]:
        """List all jobs"""
        params = filter_params or {}
        return self._request('GET', '/api/jobs/', params=params)
    
    def get_job(self, job_id: int) -> Dict:
        """Get job details"""
        return self._request('GET', f'/api/jobs/{job_id}/')
    
    def cancel_job(self, job_id: int, reason: Optional[str] = None) -> Dict:
        """Cancel a running job"""
        data = {'reason': reason} if reason else {}
        return self._request('POST', f'/api/jobs/{job_id}/cancel/', json=data)
    
    def get_job_logs(self, job_id: int) -> Dict:
        """Get job logs"""
        return self._request('GET', f'/api/jobs/{job_id}/logs/')
    
    # Secrets
    def list_secrets(self) -> List[Dict]:
        """List all secrets (without values)"""
        return self._request('GET', '/api/secrets/')
    
    def get_secret(self, key: str) -> Dict:
        """Get secret value"""
        return self._request('GET', f'/api/secrets/{key}/')
    
    def set_secret(self, key: str, value: str) -> Dict:
        """Set secret value"""
        data = {'key': key, 'value': value}
        return self._request('POST', '/api/secrets/', json=data)
    
    def delete_secret(self, key: str) -> Dict:
        """Delete a secret"""
        return self._request('DELETE', f'/api/secrets/{key}/')

    # Approvals
    def list_approvals(self, status: Optional[str] = None) -> List[Dict]:
        """List approval requests"""
        params = {}
        if status:
            params['status'] = status
        return self._request('GET', '/api/approvals/', params=params)

    def get_approval(self, approval_id: int) -> Dict:
        """Get approval request details"""
        return self._request('GET', f'/api/approvals/{approval_id}/')

    def approve_request(self, token: str, comment: str = '', approver_email: str = '') -> Dict:
        """Approve a pending request by token"""
        data = {}
        if comment:
            data['comment'] = comment
        if approver_email:
            data['approver_email'] = approver_email
        return self._request('POST', f'/api/approvals/token/{token}/approve/', json=data)

    def reject_request(self, token: str, reason: str = '', approver_email: str = '') -> Dict:
        """Reject a pending request by token"""
        data = {}
        if reason:
            data['reason'] = reason
        if approver_email:
            data['approver_email'] = approver_email
        return self._request('POST', f'/api/approvals/token/{token}/reject/', json=data)

    # MCP
    def get_mcp_config(self) -> Dict:
        """GET /api/users/me-mcp-config/ — return signature, orgs, keys, and template configs."""
        return self._request('GET', '/api/users/me-mcp-config/')

    def generate_mcp_key(self, org_id: str, key_name: str = '', client_type: str = 'lm_studio') -> Dict:
        """POST /api/users/me-mcp-config-generate-key/ — create a new API key and return embedded config."""
        return self._request('POST', '/api/users/me-mcp-config-generate-key/', json={
            'org_id': org_id,
            'key_name': key_name,
            'client_type': client_type,
        })


class APIError(Exception):
    """API client error"""
    
    def __init__(self, message: str, status_code: Optional[int] = None):
        self.message = message
        self.status_code = status_code
        super().__init__(self.message)
