"""
Configuration management for PyExecutor CLI
"""

import os
import json
from pathlib import Path
from typing import Optional

CONFIG_DIR = Path.home() / ".pyexec"
CONFIG_FILE = CONFIG_DIR / "config.json"


class Config:
    """Manage PyExecutor CLI configuration"""
    
    def __init__(self):
        self.api_url = None
        self.api_key = None
        self.organization = None
        self.timeout = 60
        self.output_format = "table"
        self.load()
    
    def load(self):
        """Load configuration from file and environment variables"""
        # Load from config file
        if CONFIG_FILE.exists():
            with open(CONFIG_FILE, 'r') as f:
                data = json.load(f)
                self.api_url = data.get('api_url')
                self.api_key = data.get('api_key')
                self.organization = data.get('organization')
                self.timeout = data.get('timeout', 60)
                self.output_format = data.get('output_format', 'table')
        
        # Environment variables override config file
        self.api_url = os.getenv('PYEXEC_API_URL', self.api_url)
        self.api_key = os.getenv('PYEXEC_API_KEY', self.api_key)
        self.organization = os.getenv('PYEXEC_ORG', self.organization)
    
    def save(self):
        """Save configuration to file"""
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        
        data = {
            'api_url': self.api_url,
            'api_key': self.api_key,
            'organization': self.organization,
            'timeout': self.timeout,
            'output_format': self.output_format,
        }
        
        with open(CONFIG_FILE, 'w') as f:
            json.dump(data, f, indent=2)
    
    def set(self, key: str, value: str):
        """Set a configuration value"""
        if key == 'api-url':
            self.api_url = value
        elif key == 'api-key':
            self.api_key = value
        elif key == 'organization' or key == 'org':
            self.organization = value
        elif key == 'timeout':
            self.timeout = int(value)
        elif key == 'output-format':
            self.output_format = value
        else:
            raise ValueError(f"Unknown configuration key: {key}")
        
        self.save()
    
    def get(self, key: str) -> Optional[str]:
        """Get a configuration value"""
        if key == 'api-url':
            return self.api_url
        elif key == 'api-key':
            return self.api_key
        elif key == 'organization' or key == 'org':
            return self.organization
        elif key == 'timeout':
            return str(self.timeout)
        elif key == 'output-format':
            return self.output_format
        return None
    
    def show(self) -> dict:
        """Show all configuration"""
        return {
            'api_url': self.api_url or '(not set)',
            'api_key': '***' + (self.api_key[-4:] if self.api_key else '(not set)'),
            'organization': self.organization or '(not set)',
            'timeout': self.timeout,
            'output_format': self.output_format,
            'config_file': str(CONFIG_FILE),
        }
    
    def validate(self):
        """Validate required configuration"""
        if not self.api_url:
            raise ValueError(
                "API URL not configured. Set with:\n"
                "  pyexec config set --api-url https://api.example.com\n"
                "Or set PYEXEC_API_URL environment variable"
            )
        
        if not self.api_key:
            raise ValueError(
                "API key not configured. Set with:\n"
                "  pyexec config set --api-key sk_your_key\n"
                "Or set PYEXEC_API_KEY environment variable"
            )


# Global config instance
config = Config()
