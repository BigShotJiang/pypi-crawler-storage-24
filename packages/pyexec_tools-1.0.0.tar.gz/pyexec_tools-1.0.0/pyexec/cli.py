#!/usr/bin/env python
"""
PyExecutor CLI - Main entry point
"""

import click
import sys
import warnings

# Suppress urllib3 OpenSSL warnings on systems with LibreSSL
warnings.filterwarnings('ignore', message='.*OpenSSL.*')
warnings.filterwarnings('ignore', category=DeprecationWarning)

from . import __version__
from .config import config
from .api_client import APIClient, APIError
from .output import (
    print_table, print_json, print_detail, print_success,
    print_error, print_warning, print_info, format_output, console
)
from rich.table import Table
from rich import box


@click.group()
@click.version_option(version=__version__, prog_name="pyexec")
@click.pass_context
def cli(ctx):
    """
    PyExecutor CLI - Manage workflows, jobs, and automation
    
    \b
    Example commands:
        pyexec workflows list
        pyexec workflows run my-workflow --context key=value
        pyexec jobs get 12345
        pyexec secrets set API_KEY
    
    \b
    Configuration:
        Set API URL:  pyexec config set --api-url https://api.example.com
        Set API key:  pyexec config set --api-key sk_your_key
    """
    ctx.ensure_object(dict)


# ============================================================================
# CONFIG COMMANDS
# ============================================================================

@cli.group()
def config_cmd():
    """Manage configuration settings"""
    pass


@config_cmd.command('show')
def config_show():
    """Show current configuration"""
    print_detail(config.show(), "Configuration")


@config_cmd.command('set')
@click.option('--api-url', help='API endpoint URL')
@click.option('--api-key', help='API key for authentication')
@click.option('--org', '--organization', help='Organization name')
@click.option('--timeout', type=int, help='Request timeout in seconds')
@click.option('--output-format', type=click.Choice(['table', 'json', 'yaml']), help='Default output format')
def config_set(api_url, api_key, org, timeout, output_format):
    """Set configuration values"""
    if api_url:
        config.set('api-url', api_url)
        print_success(f"API URL set to: {api_url}")
    
    if api_key:
        config.set('api-key', api_key)
        print_success("API key updated")
    
    if org:
        config.set('organization', org)
        print_success(f"Organization set to: {org}")
    
    if timeout:
        config.set('timeout', str(timeout))
        print_success(f"Timeout set to: {timeout}s")
    
    if output_format:
        config.set('output-format', output_format)
        print_success(f"Output format set to: {output_format}")


# ============================================================================
# WORKFLOW COMMANDS
# ============================================================================

@cli.group()
def workflows():
    """Manage workflows"""
    pass


@workflows.command('list')
@click.option('--filter', 'filter_str', help='Filter workflows (e.g., status=active)')
@click.option('--output', type=click.Choice(['table', 'json', 'yaml']), help='Output format')
def workflows_list(filter_str, output):
    """List all workflows"""
    try:
        config.validate()
        client = APIClient()
        
        # Parse filter
        filter_params = {}
        if filter_str:
            for item in filter_str.split(','):
                if '=' in item:
                    key, value = item.split('=', 1)
                    filter_params[key.strip()] = value.strip()
        
        workflows_data = client.list_workflows(filter_params)
        
        # Handle paginated response
        workflows_list = workflows_data.get('results', workflows_data) if isinstance(workflows_data, dict) else workflows_data
        
        output_format = output or config.output_format
        
        if output_format == 'json':
            print_json(workflows_list)
        elif output_format == 'yaml':
            import yaml
            console.print(yaml.dump({'workflows': workflows_list}, default_flow_style=False))
        else:
            # Table format
            headers = ['name', 'trigger_type', 'status', 'is_active']
            print_table(workflows_list, headers, "Workflows")
    
    except APIError as e:
        print_error(f"Failed to list workflows: {e.message}")
        sys.exit(1)
    except Exception as e:
        print_error(f"Error: {str(e)}")
        sys.exit(1)


@workflows.command('get')
@click.argument('name')
@click.option('--verbose', '-v', is_flag=True, help='Show full configuration')
@click.option('--output', type=click.Choice(['table', 'json', 'yaml']), help='Output format')
def workflows_get(name, verbose, output):
    """Get workflow details"""
    try:
        config.validate()
        client = APIClient()
        
        workflow = client.get_workflow(name)
        
        output_format = output or config.output_format
        
        if output_format == 'json':
            print_json(workflow)
        else:
            print_detail(workflow, f"Workflow: {name}")
    
    except APIError as e:
        print_error(f"Failed to get workflow: {e.message}")
        sys.exit(1)


@workflows.command('run')
@click.argument('name')
@click.option('--context', '-c', multiple=True, help='Context variable (key=value)')
@click.option('--context-file', type=click.Path(exists=True), help='JSON file with context')
@click.option('--wait', is_flag=True, help='Wait for execution to complete')
@click.option('--follow-logs', is_flag=True, help='Follow logs in real-time (implies --wait)')
@click.option('--timeout', type=int, help='Timeout in seconds')
def workflows_run(name, context, context_file, wait, follow_logs, timeout):
    """Run a workflow"""
    try:
        config.validate()
        client = APIClient()
        
        # Build context dict
        context_dict = {}
        
        # From file
        if context_file:
            import json
            with open(context_file) as f:
                context_dict.update(json.load(f))
        
        # From command line (overrides file)
        for item in context:
            if '=' in item:
                key, value = item.split('=', 1)
                context_dict[key.strip()] = value.strip()
        
        print_info(f"Executing workflow: {name}")
        if context_dict:
            print_info(f"Context: {context_dict}")
        
        # Execute workflow
        result = client.execute_workflow(name, context_dict)
        job_id = result.get('id')
        
        print_success(f"Workflow execution started: Job #{job_id}")
        
        if wait or follow_logs:
            import time
            print_info("Waiting for completion...")
            
            while True:
                job = client.get_job(job_id)
                status = job.get('status')
                
                if follow_logs and job.get('logs'):
                    console.print(job['logs'])
                
                if status in ['SUCCESS', 'FAILED', 'CANCELLED', 'success', 'failed', 'cancelled']:
                    if status.upper() == 'SUCCESS':
                        print_success(f"Job completed successfully")
                        if job.get('output'):
                            print_detail(job['output'], "Output")
                    elif status.upper() == 'FAILED':
                        print_error(f"Job failed: {job.get('error', 'Unknown error')}")
                        sys.exit(1)
                    else:
                        print_warning(f"Job was cancelled")
                        sys.exit(1)
                    break
                
                time.sleep(2)
        else:
            print_info(f"Track execution: pyexec jobs get {job_id}")
    
    except APIError as e:
        print_error(f"Failed to run workflow: {e.message}")
        sys.exit(1)


@workflows.command('enable')
@click.argument('name')
def workflows_enable(name):
    """Enable a workflow"""
    try:
        config.validate()
        client = APIClient()
        
        client.enable_workflow(name)
        print_success(f"Workflow '{name}' enabled")
    
    except APIError as e:
        print_error(f"Failed to enable workflow: {e.message}")
        sys.exit(1)


@workflows.command('disable')
@click.argument('name')
def workflows_disable(name):
    """Disable a workflow"""
    try:
        config.validate()
        client = APIClient()
        
        client.disable_workflow(name)
        print_success(f"Workflow '{name}' disabled")
    
    except APIError as e:
        print_error(f"Failed to disable workflow: {e.message}")
        sys.exit(1)


# ============================================================================
# JOB COMMANDS
# ============================================================================

@cli.group()
def jobs():
    """Manage job executions"""
    pass


@jobs.command('list')
@click.option('--workflow', help='Filter by workflow name')
@click.option('--filter', 'filter_str', help='Filter jobs (e.g., status=failed)')
@click.option('--limit', type=int, default=50, help='Maximum number of results')
@click.option('--output', type=click.Choice(['table', 'json', 'yaml']), help='Output format')
def jobs_list(workflow, filter_str, limit, output):
    """List job executions"""
    try:
        config.validate()
        client = APIClient()
        
        # Parse filters
        filter_params = {'limit': limit}
        if workflow:
            filter_params['workflow'] = workflow
        
        if filter_str:
            for item in filter_str.split(','):
                if '=' in item:
                    key, value = item.split('=', 1)
                    filter_params[key.strip()] = value.strip()
        
        jobs_data = client.list_jobs(filter_params)
        
        # Handle paginated response
        jobs_list = jobs_data.get('results', jobs_data) if isinstance(jobs_data, dict) else jobs_data
        
        output_format = output or config.output_format
        
        if output_format == 'json':
            print_json(jobs_list)
        else:
            headers = ['id', 'workflow', 'status', 'created_at', 'duration']
            print_table(jobs_list, headers, "Jobs")
    
    except APIError as e:
        print_error(f"Failed to list jobs: {e.message}")
        sys.exit(1)


@jobs.command('get')
@click.argument('job_id', type=int)
@click.option('--verbose', '-v', is_flag=True, help='Show full details')
@click.option('--show-steps', is_flag=True, help='Show step-by-step results')
@click.option('--logs-only', is_flag=True, help='Show only logs')
@click.option('--output', type=click.Choice(['table', 'json', 'yaml']), help='Output format')
def jobs_get(job_id, verbose, show_steps, logs_only, output):
    """Get job details"""
    try:
        config.validate()
        client = APIClient()
        
        job = client.get_job(job_id)
        
        if logs_only:
            console.print(job.get('logs', 'No logs available'))
        else:
            output_format = output or config.output_format
            
            if output_format == 'json':
                print_json(job)
            else:
                print_detail(job, f"Job #{job_id}")
                
                if show_steps and job.get('steps'):
                    console.print("\n[bold cyan]Steps:[/bold cyan]")
                    for step in job['steps']:
                        console.print(f"  {step.get('name')}: {step.get('status')}")
    
    except APIError as e:
        print_error(f"Failed to get job: {e.message}")
        sys.exit(1)


@jobs.command('cancel')
@click.argument('job_id', type=int)
@click.option('--reason', help='Cancellation reason')
@click.option('--force', is_flag=True, help='Force cancel without confirmation')
def jobs_cancel(job_id, reason, force):
    """Cancel a running job"""
    try:
        config.validate()
        client = APIClient()
        
        if not force:
            if not click.confirm(f"Cancel job #{job_id}?"):
                print_info("Cancelled")
                return
        
        client.cancel_job(job_id, reason)
        print_success(f"Job #{job_id} cancelled")
    
    except APIError as e:
        print_error(f"Failed to cancel job: {e.message}")
        sys.exit(1)


@jobs.command('follow')
@click.argument('job_id', type=int)
@click.option('--tail', type=int, help='Show last N lines')
def jobs_follow(job_id, tail):
    """Follow job logs in real-time"""
    try:
        config.validate()
        client = APIClient()
        
        import time
        
        print_info(f"Following job #{job_id} (Ctrl+C to stop)")
        
        last_log_length = 0
        
        while True:
            job = client.get_job(job_id)
            status = job.get('status')
            logs = job.get('logs', '')
            
            # Print new logs
            if len(logs) > last_log_length:
                new_logs = logs[last_log_length:]
                console.print(new_logs, end='')
                last_log_length = len(logs)
            
            # Check if job finished
            if status in ['success', 'failed', 'cancelled']:
                console.print()
                if status == 'success':
                    print_success("Job completed")
                elif status == 'failed':
                    print_error(f"Job failed: {job.get('error')}")
                else:
                    print_warning("Job cancelled")
                break
            
            time.sleep(2)
    
    except KeyboardInterrupt:
        print_info("\nStopped following")
    except APIError as e:
        print_error(f"Failed to follow job: {e.message}")
        sys.exit(1)


# ============================================================================
# SECRET COMMANDS
# ============================================================================

@cli.group()
def secrets():
    """Manage secrets"""
    pass


@secrets.command('list')
@click.option('--show-usage', is_flag=True, help='Show usage information')
def secrets_list(show_usage):
    """List all secrets (without values)"""
    try:
        config.validate()
        client = APIClient()
        
        secrets_data = client.list_secrets()
        
        # Handle paginated response
        secrets_list = secrets_data.get('results', secrets_data) if isinstance(secrets_data, dict) else secrets_data
        
        headers = ['key', 'created_at']
        if show_usage:
            headers.append('last_used')
        
        print_table(secrets_list, headers, "Secrets")
    
    except APIError as e:
        print_error(f"Failed to list secrets: {e.message}")
        sys.exit(1)


@secrets.command('get')
@click.argument('key')
@click.option('--force', is_flag=True, help='Skip confirmation')
def secrets_get(key, force):
    """Get secret value"""
    try:
        config.validate()
        client = APIClient()
        
        if not force:
            if not click.confirm(f"⚠️  Reveal secret '{key}'?"):
                print_info("Cancelled")
                return
        
        secret = client.get_secret(key)
        console.print(f"\n[bold]{key}:[/bold] {secret.get('value')}\n")
    
    except APIError as e:
        print_error(f"Failed to get secret: {e.message}")
        sys.exit(1)


@secrets.command('set')
@click.argument('key')
@click.argument('value', required=False)
@click.option('--from-env', help='Read value from environment variable')
@click.option('--from-file', type=click.Path(exists=True), help='Read value from file')
def secrets_set(key, value, from_env, from_file):
    """Set a secret"""
    try:
        config.validate()
        client = APIClient()
        
        # Determine value source
        if from_env:
            import os
            value = os.getenv(from_env)
            if value is None:
                print_error(f"Environment variable '{from_env}' not found")
                sys.exit(1)
        elif from_file:
            with open(from_file) as f:
                value = f.read()
        elif value is None:
            # Interactive prompt
            value = click.prompt(f"Enter value for '{key}'", hide_input=True)
        
        client.set_secret(key, value)
        print_success(f"Secret '{key}' set")
    
    except APIError as e:
        print_error(f"Failed to set secret: {e.message}")
        sys.exit(1)


@secrets.command('delete')
@click.argument('key')
@click.option('--confirm', is_flag=True, help='Skip confirmation')
def secrets_delete(key, confirm):
    """Delete a secret"""
    try:
        config.validate()
        client = APIClient()
        
        if not confirm:
            if not click.confirm(f"Delete secret '{key}'?"):
                print_info("Cancelled")
                return
        
        client.delete_secret(key)
        print_success(f"Secret '{key}' deleted")
    
    except APIError as e:
        print_error(f"Failed to delete secret: {e.message}")
        sys.exit(1)


# ============================================================================
# LOGS COMMANDS
# ============================================================================

@cli.group()
def logs():
    """View logs"""
    pass


@logs.command('workflow')
@click.argument('workflow_name')
@click.option('--limit', type=int, default=100, help='Number of log lines')
def logs_workflow(workflow_name, limit):
    """Get logs for a workflow"""
    try:
        config.validate()
        client = APIClient()
        
        # Resolve name to ID for the backend filter
        workflow_id = client.get_workflow_id(workflow_name)
        
        # Get recent jobs for this workflow
        jobs_data = client.list_jobs({'workflow': workflow_id})
        jobs_list = jobs_data.get('results', jobs_data) if isinstance(jobs_data, dict) else jobs_data
        
        if not jobs_list:
            print_warning(f"No jobs found for workflow '{workflow_name}'")
            return
        
        job = jobs_list[0]
        job_logs = client.get_job_logs(job['id'])
        
        console.print(job_logs.get('logs', 'No logs available'))
    
    except APIError as e:
        print_error(f"Failed to get logs: {e.message}")
        sys.exit(1)


@logs.command('job')
@click.argument('job_id', type=int)
@click.option('--level', type=click.Choice(['error', 'warning', 'info', 'debug']), help='Filter by level')
def logs_job(job_id, level):
    """Get logs for a specific job"""
    try:
        config.validate()
        client = APIClient()
        
        job_logs = client.get_job_logs(job_id)
        logs = job_logs.get('logs', '')
        
        # Filter by level if specified
        if level and logs:
            filtered_lines = [
                line for line in logs.split('\n')
                if level.upper() in line
            ]
            console.print('\n'.join(filtered_lines))
        else:
            console.print(logs or 'No logs available')
    
    except APIError as e:
        print_error(f"Failed to get logs: {e.message}")
        sys.exit(1)


# ============================================================================
# APPROVAL COMMANDS
# ============================================================================

@cli.group()
def approvals():
    """Manage workflow approval requests"""
    pass


@approvals.command('list')
@click.option('--status', type=click.Choice(['pending', 'approved', 'rejected', 'expired']), help='Filter by status')
@click.option('--output', '-o', type=click.Choice(['table', 'json']), default='table', help='Output format')
def approvals_list(status, output):
    """List approval requests"""
    try:
        client = get_client()
        data = client.list_approvals(status=status)
        results = data.get('results', data) if isinstance(data, dict) else data

        if output == 'json':
            console.print_json(data=results)
            return

        if not results:
            console.print('[yellow]No approval requests found.[/yellow]')
            return

        table = Table(title='Approval Requests', box=box.ROUNDED)
        table.add_column('ID', style='cyan')
        table.add_column('Workflow', style='white')
        table.add_column('Job', style='dim')
        table.add_column('Status', style='bold')
        table.add_column('Approver(s)', style='dim')
        table.add_column('Created', style='dim')

        for req in results:
            status_val = req.get('status', '')
            style = {'pending': 'yellow', 'approved': 'green', 'rejected': 'red', 'expired': 'dim'}.get(status_val, '')
            config = req.get('approval_config') or {}
            emails = config.get('approver_emails', []) if isinstance(config, dict) else []
            table.add_row(
                str(req.get('id', '')),
                req.get('workflow_name', ''),
                str(req.get('job', '')),
                f'[{style}]{status_val}[/{style}]',
                ', '.join(emails) if emails else 'Any',
                req.get('created_at', '')[:10],
            )

        console.print(table)

    except APIError as e:
        print_error(f"Failed to list approvals: {e.message}")
        sys.exit(1)


@approvals.command('get')
@click.argument('approval_id', type=int)
@click.option('--output', '-o', type=click.Choice(['table', 'json']), default='table', help='Output format')
def approvals_get(approval_id, output):
    """Get details for an approval request"""
    try:
        client = get_client()
        req = client.get_approval(approval_id)

        if output == 'json':
            console.print_json(data=req)
            return

        config = req.get('approval_config') or {}
        emails = config.get('approver_emails', []) if isinstance(config, dict) else []

        console.print(f'\n[bold cyan]Approval Request #{req.get("id")}[/bold cyan]')
        console.print(f'  Workflow: {req.get("workflow_name", "N/A")}')
        console.print(f'  Job:      {req.get("job", "N/A")}')
        console.print(f'  Status:   {req.get("status", "N/A")}')
        console.print(f'  Token:    {req.get("approval_token", "N/A")}')
        console.print(f'  Created:  {req.get("created_at", "N/A")}')
        console.print(f'  Expires:  {req.get("expires_at", "N/A")}')
        console.print(f'  Approver(s): {", ".join(emails) if emails else "Any authorized user"}')
        if req.get('approval_comment'):
            console.print(f'  Comment:  {req["approval_comment"]}')
        if req.get('approved_by_name'):
            console.print(f'  Acted by: {req["approved_by_name"]}')

    except APIError as e:
        print_error(f"Failed to get approval: {e.message}")
        sys.exit(1)


@approvals.command('approve')
@click.argument('approval_id', type=int)
@click.option('--comment', '-c', default='', help='Approval comment')
def approvals_approve(approval_id, comment):
    """Approve a pending approval request"""
    try:
        client = get_client()
        req = client.get_approval(approval_id)

        if req.get('status') != 'pending':
            print_error(f"Request is already {req.get('status')}")
            sys.exit(1)

        token = req.get('approval_token')
        if not token:
            print_error('No approval token found')
            sys.exit(1)

        if not comment:
            comment = click.prompt('Comment (optional)', default='', show_default=False)

        result = client.approve_request(token, comment=comment)
        console.print(f'[green]✓ Approval request {approval_id} has been approved.[/green]')

    except APIError as e:
        print_error(f"Failed to approve: {e.message}")
        sys.exit(1)


@approvals.command('reject')
@click.argument('approval_id', type=int)
@click.option('--reason', '-r', default='', help='Rejection reason')
def approvals_reject(approval_id, reason):
    """Reject a pending approval request"""
    try:
        client = get_client()
        req = client.get_approval(approval_id)

        if req.get('status') != 'pending':
            print_error(f"Request is already {req.get('status')}")
            sys.exit(1)

        token = req.get('approval_token')
        if not token:
            print_error('No approval token found')
            sys.exit(1)

        if not reason:
            reason = click.prompt('Reason (optional)', default='', show_default=False)

        result = client.reject_request(token, reason=reason)
        console.print(f'[red]✗ Approval request {approval_id} has been rejected.[/red]')

    except APIError as e:
        print_error(f"Failed to reject: {e.message}")
        sys.exit(1)


# ============================================================================
# MCP COMMANDS
# ============================================================================

@cli.group()
def mcp():
    """MCP client tools — generate signatures and downloadable configs"""
    pass


@mcp.command('signature')
@click.option('--secret', envvar='PYEXEC_MCP_CLIENT_SECRET', help='Server HMAC secret (can also be set via PYEXEC_MCP_CLIENT_SECRET env var)')
@click.option('--identifier', help='Override identifier (default: your profile email or username)')
def mcp_signature(secret, identifier):
    """
    Compute and display your per-user MCP client signature.

    The signature is HMAC-SHA256(secret, identifier) where identifier is
    your profile email (preferred) or username. Provide the same secret
    that is configured as PYEXEC_MCP_CLIENT_SECRET on the MCP server.

    \b
    Example:
        pyexec mcp signature --secret MY_SERVER_SECRET
        # or set the env var and call without --secret:
        PYEXEC_MCP_CLIENT_SECRET=MY_SERVER_SECRET pyexec mcp signature
    """
    import hmac as _hmac
    import hashlib as _hashlib

    # Fetch identifier from server if not overridden
    if not identifier:
        try:
            config.validate()
            client = APIClient()
            data = client._request('GET', '/api/users/me/')
            identifier = (data.get('email') or data.get('username') or '').strip()
        except Exception as e:
            print_error(f"Could not fetch your profile from the API: {e}")
            print_info("Use --identifier to supply it manually.")
            sys.exit(1)

    if not identifier:
        print_error("No identifier found in your profile. Set an email address or use --identifier.")
        sys.exit(1)

    if not secret:
        print_warning("No secret supplied. Use --secret or set PYEXEC_MCP_CLIENT_SECRET.")
        print_info("Signature verification is disabled on the server when no secret is configured.")
        print_info(f"Identifier that would be used: {identifier}")
        sys.exit(0)

    mac = _hmac.new(secret.encode('utf-8'), msg=identifier.encode('utf-8'), digestmod=_hashlib.sha256)
    sig = mac.hexdigest()

    console.print()
    console.print("[bold]Your MCP Client Signature[/bold]")
    console.print(f"  Identifier : [cyan]{identifier}[/cyan]")
    console.print(f"  Signature  : [green]{sig}[/green]")
    console.print()
    console.print("Add to your LM Studio SSE URL:")
    console.print(f"  [dim]...&signature={sig}[/dim]")
    console.print()
    console.print("Or as a header (Claude Desktop / VS Code):")
    console.print(f"  [dim]X-Client-Signature: {sig}[/dim]")
    console.print()


@mcp.command('config')
@click.option('--client', 'client_type', type=click.Choice(['lm_studio', 'cursor', 'claude_desktop', 'vscode']), default='lm_studio', show_default=True, help='Target LLM client')
@click.option('--org', 'org_id', help='Organisation UUID (fetched from API when omitted)')
@click.option('--api-key', 'api_key', help='API key to embed (generates a new one when omitted)')
@click.option('--key-name', default='', help='Name for the generated API key')
@click.option('--output', '-o', type=click.Path(), help='Write config JSON to this file instead of stdout')
@click.option('--secret', envvar='PYEXEC_MCP_CLIENT_SECRET', help='HMAC secret for signature (env: PYEXEC_MCP_CLIENT_SECRET)')
def mcp_config(client_type, org_id, api_key, key_name, output, secret):
    """
    Generate a ready-to-use MCP client configuration JSON.

    When --api-key is omitted, a new API key is generated on the server
    (execute-scoped, 365-day expiry) and its plaintext token is embedded
    in the config — save it, as it will not be shown again.

    \b
    Examples:
        # Show LM Studio config (generates new key)
        pyexec mcp config --client lm_studio

        # Embed an existing key and write to a file
        pyexec mcp config --client cursor --api-key sk_... --org ORG_UUID -o cursor-mcp.json

        # Generate config with embedded signature
        PYEXEC_MCP_CLIENT_SECRET=mysecret pyexec mcp config --client claude_desktop
    """
    import json as _json
    import hmac as _hmac
    import hashlib as _hashlib

    try:
        config.validate()
        client = APIClient()

        if not api_key:
            # Ensure org_id
            if not org_id:
                mcp_data = client._request('GET', '/api/users/me/mcp-config/')
                orgs = mcp_data.get('orgs', [])
                if not orgs:
                    print_error("No organisations found for your account. Supply --org explicitly.")
                    sys.exit(1)
                org_id = orgs[0]['id']
                print_info(f"Using organisation: {orgs[0]['name']} ({org_id})")

            kname = key_name or f"MCP Key – {client_type}"
            print_info(f"Generating new API key '{kname}'…")
            result = client._request('POST', '/api/users/me/mcp-config/generate-key/', json={
                'org_id': org_id,
                'key_name': kname,
                'client_type': client_type,
            })
            cfg = result.get('config') or result
            plain_token = result.get('token')
            sig = result.get('signature')

            console.print()
            if plain_token:
                console.print(f"[bold yellow]⚠  API Token (save it — shown once):[/bold yellow] [green]{plain_token}[/green]")
            if sig:
                console.print(f"[bold]Signature:[/bold] [cyan]{sig}[/cyan]")
            console.print()
        else:
            # User supplied their own key — compute signature locally if secret provided
            if not org_id:
                mcp_data = client._request('GET', '/api/users/me/mcp-config/')
                orgs = mcp_data.get('orgs', [])
                if not orgs:
                    print_error("No organisations found. Supply --org.")
                    sys.exit(1)
                org_id = orgs[0]['id']

            mcp_base_url = config.api_url.rstrip('/').replace(':8000', ':8001').replace('/api', '')
            sse_url = f"{mcp_base_url}/sse?api_key={api_key}&org_id={org_id}"

            # Compute signature if secret is available
            sig = None
            if secret:
                me = client._request('GET', '/api/users/me/')
                identifier = (me.get('email') or me.get('username') or '').strip()
                if identifier:
                    mac = _hmac.new(secret.encode('utf-8'), msg=identifier.encode('utf-8'), digestmod=_hashlib.sha256)
                    sig = mac.hexdigest()
                    sse_url += f"&signature={sig}"

            configs = {
                'lm_studio': {'name': 'PyExecutor Workflows', 'transport': 'sse', 'url': sse_url},
                'cursor': {'mcpServers': {'pyexecutor': {'url': sse_url}}},
                'claude_desktop': {
                    'mcpServers': {
                        'pyexecutor': {
                            'url': mcp_base_url + '/sse',
                            'headers': {
                                'Authorization': f'Bearer {api_key}',
                                'X-Organization-ID': org_id,
                                **({'X-Client-Signature': sig} if sig else {}),
                            },
                        }
                    }
                },
                'vscode': {
                    'servers': {
                        'pyexecutor': {
                            'type': 'sse',
                            'url': mcp_base_url + '/sse',
                            'headers': {
                                'Authorization': f'Bearer {api_key}',
                                'X-Organization-ID': org_id,
                                **({'X-Client-Signature': sig} if sig else {}),
                            },
                        }
                    }
                },
            }
            cfg = configs.get(client_type, configs['lm_studio'])
            if sig:
                console.print(f"[bold]Signature:[/bold] [cyan]{sig}[/cyan]")

        json_out = _json.dumps(cfg, indent=2)

        if output:
            with open(output, 'w') as fh:
                fh.write(json_out + '\n')
            print_success(f"Config written to {output}")
        else:
            console.print("[bold]MCP Config JSON:[/bold]")
            console.print(json_out)

    except APIError as e:
        print_error(f"API error: {e.message}")
        sys.exit(1)
    except Exception as e:
        print_error(f"Error: {e}")
        sys.exit(1)


# ============================================================================
# MAIN
# ============================================================================

if __name__ == '__main__':
    cli()
