"""
Output formatting utilities
"""

import json
from typing import Any, List, Dict
from tabulate import tabulate
from rich.console import Console
from rich.table import Table
from rich.syntax import Syntax
from rich import print as rprint

console = Console()


def print_table(data: List[Dict], headers: List[str], title: str = None):
    """Print data as a rich table"""
    if not data:
        console.print(f"[dim]No {title or 'items'} found[/dim]")
        return
    
    table = Table(title=title, show_header=True, header_style="bold cyan")
    
    for header in headers:
        table.add_column(header)
    
    for row in data:
        table.add_row(*[str(row.get(h, '')) for h in headers])
    
    console.print(table)


def print_json(data: Any, pretty: bool = True):
    """Print data as JSON"""
    if pretty:
        syntax = Syntax(
            json.dumps(data, indent=2),
            "json",
            theme="monokai",
            line_numbers=False
        )
        console.print(syntax)
    else:
        print(json.dumps(data))


def print_yaml(data: Dict):
    """Print data as YAML"""
    import yaml
    console.print(yaml.dump(data, default_flow_style=False))


def print_detail(data: Dict, title: str = None):
    """Print detailed key-value pairs"""
    if title:
        console.print(f"\n[bold cyan]{title}[/bold cyan]")
    
    for key, value in data.items():
        if isinstance(value, (dict, list)):
            value = json.dumps(value, indent=2)
        console.print(f"[bold]{key}:[/bold] {value}")


def print_success(message: str):
    """Print success message"""
    console.print(f"[bold green]✓[/bold green] {message}")


def print_error(message: str):
    """Print error message"""
    console.print(f"[bold red]✗[/bold red] {message}")


def print_warning(message: str):
    """Print warning message"""
    console.print(f"[bold yellow]⚠[/bold yellow] {message}")


def print_info(message: str):
    """Print info message"""
    console.print(f"[bold blue]ℹ[/bold blue] {message}")


def format_output(data: Any, format_type: str = 'table', headers: List[str] = None, title: str = None):
    """Format and print output based on format type"""
    if format_type == 'json':
        print_json(data)
    elif format_type == 'yaml':
        print_yaml(data if isinstance(data, dict) else {'items': data})
    elif format_type == 'table' and isinstance(data, list):
        print_table(data, headers or list(data[0].keys()) if data else [], title)
    elif format_type == 'detail' and isinstance(data, dict):
        print_detail(data, title)
    else:
        # Fallback to JSON
        print_json(data)
