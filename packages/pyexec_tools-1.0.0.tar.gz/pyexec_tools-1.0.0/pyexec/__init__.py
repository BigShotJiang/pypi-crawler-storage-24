"""
PyExecutor CLI Tool
Command-line interface for PyExecutor workflow orchestration platform
"""

__version__ = "1.0.0"
__author__ = "PyExecutor"
__license__ = "MIT"
