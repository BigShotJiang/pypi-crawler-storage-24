# PyExecutor CLI Tool

Command-line interface for managing PyExecutor workflows, jobs, secrets, and automation.

**Version**: 1.0.0 | **Status**: All 21 commands working ✅

## Installation

```bash
cd cli/
pip install -e .

# Verify
pyexec --version
```

## Quick Start

### 1. Configure Authentication

```bash
pyexec config-cmd set --api-url http://localhost:8000
pyexec config-cmd set --api-key your_token_here

# Verify
pyexec config-cmd show
```

### 2. List Workflows

```bash
pyexec workflows list
```

### 3. Run a Workflow

```bash
pyexec workflows run 15 --wait
# or by name
pyexec workflows run "My Workflow" --context key=value --wait
```

## Commands

### Configuration

```bash
# Show current config
pyexec config-cmd show

# Set configuration values
pyexec config-cmd set --api-url http://localhost:8000
pyexec config-cmd set --api-key your_token
pyexec config-cmd set --timeout 120
pyexec config-cmd set --output-format json  # table | json | yaml
```

### Workflows

```bash
# List workflows
pyexec workflows list
pyexec workflows list --filter "status=active"
pyexec workflows list --output json
pyexec workflows list --output yaml

# Get workflow details (by ID or name)
pyexec workflows get 15
pyexec workflows get "KPI Score Pipeline"
pyexec workflows get 15 --output json

# Run workflow (by ID or name)
pyexec workflows run 15
pyexec workflows run "KPI Score Pipeline"
pyexec workflows run 15 --context key=value --context key2=value2
pyexec workflows run 15 --context-file payload.json
pyexec workflows run 15 --wait               # wait for completion
pyexec workflows run 15 --wait --follow-logs  # wait + stream logs

# Enable/disable
pyexec workflows enable 15
pyexec workflows disable 15
pyexec workflows enable "KPI Score Pipeline"   # by name works too
```

### Jobs

```bash
# List jobs
pyexec jobs list
pyexec jobs list --output json

# Get job details
pyexec jobs get 907
pyexec jobs get 907 --output json

# Stream live logs
pyexec jobs follow 907

# Cancel job
pyexec jobs cancel 907
```

### Logs

```bash
# View historical logs for a job
pyexec logs job 907
pyexec logs job 907 --level error
pyexec logs job 907 --level warning
pyexec logs job 907 --level info

# View logs from the most recent run of a workflow (by ID or name)
pyexec logs workflow 12
pyexec logs workflow "Service Health Monitor"
```

### Secrets

```bash
# List secrets (values are hidden)
pyexec secrets list
pyexec secrets list --output json

# Get secret value
pyexec secrets get API_KEY
pyexec secrets get API_KEY --force  # skip confirmation

# Set secret
pyexec secrets set API_KEY                  # interactive prompt
pyexec secrets set API_KEY "secret_value"   # direct value

# Delete secret
pyexec secrets delete API_KEY
pyexec secrets delete API_KEY --force
```

### Approvals

```bash
# List all pending approvals
pyexec approvals list
pyexec approvals list --status pending
pyexec approvals list --status approved
pyexec approvals list --output json

# Get approval details
pyexec approvals get 30
pyexec approvals get 30 --output json

# Approve a pending request
pyexec approvals approve 30
pyexec approvals approve 30 --comment "Looks good, ship it"

# Reject a pending request
pyexec approvals reject 30
pyexec approvals reject 30 --reason "Not ready for production"
```

## Output Formats

All list/get commands support `--output table` (default), `--output json`, `--output yaml`.

Change default:

```bash
pyexec config-cmd set --output-format json
```

## Configuration File

Settings are stored in `~/.pyexec/config.json`:

```json
{
  "api_url": "http://localhost:8000",
  "api_key": "your_token_here",
  "timeout": 60,
  "output_format": "table"
}
```

## Examples

### Run workflow and wait for completion

```bash
pyexec workflows run "Order Processing" \
  --context order_id="ORD-12345" \
  --context customer_email="user@example.com" \
  --wait
```

### Monitor a job in real-time

```bash
# Start a job, then follow its logs
pyexec workflows run 15
pyexec jobs follow 914
```

### Export data for analysis

```bash
pyexec workflows list --output json > workflows.json
pyexec jobs list --output json > jobs.json
pyexec secrets list --output json > secrets.json
```

### Check logs from the last run of a workflow

```bash
pyexec logs workflow "Service Health Monitor"

# Or filter to errors only
pyexec logs job 907 --level error
```

## License

MIT


## Commands

### Configuration

```bash
# Show current config
pyexec config show

# Set configuration values
pyexec config set --api-url https://api.example.com
pyexec config set --api-key sk_your_key
pyexec config set --org "My Organization"
pyexec config set --timeout 120
pyexec config set --output-format json
```

### Workflows

```bash
# List workflows
pyexec workflows list
pyexec workflows list --filter status=active
pyexec workflows list --output json

# Get workflow details
pyexec workflows get order-processing
pyexec workflows get order-processing --verbose

# Run workflow
pyexec workflows run order-processing
pyexec workflows run order-processing --context key=value
pyexec workflows run order-processing --context-file payload.json
pyexec workflows run order-processing --wait --follow-logs

# Enable/disable workflow
pyexec workflows enable order-processing
pyexec workflows disable order-processing
```

### Jobs

```bash
# List jobs
pyexec jobs list
pyexec jobs list --workflow order-processing
pyexec jobs list --filter status=failed
pyexec jobs list --limit 100

# Get job details
pyexec jobs get 12345
pyexec jobs get 12345 --verbose
pyexec jobs get 12345 --show-steps
pyexec jobs get 12345 --logs-only

# Follow job logs
pyexec jobs follow 12345

# Cancel job
pyexec jobs cancel 12345
pyexec jobs cancel 12345 --reason "User requested"
pyexec jobs cancel 12345 --force
```

### Secrets

```bash
# List secrets (without values)
pyexec secrets list
pyexec secrets list --show-usage

# Get secret value
pyexec secrets get API_KEY
pyexec secrets get API_KEY --force

# Set secret
pyexec secrets set API_KEY                      # Interactive prompt
pyexec secrets set API_KEY "secret_value"       # Command line
pyexec secrets set API_KEY --from-env MY_VAR    # From env variable
pyexec secrets set API_KEY --from-file key.txt  # From file

# Delete secret
pyexec secrets delete API_KEY
pyexec secrets delete API_KEY --confirm
```

### Logs

```bash
# Get workflow logs
pyexec logs workflow order-processing
pyexec logs workflow order-processing --limit 50

# Get job logs
pyexec logs job 12345
pyexec logs job 12345 --level error
```

## Output Formats

All list/get commands support multiple output formats:

```bash
# Table format (default, human-readable)
pyexec workflows list --output table

# JSON format (for scripting)
pyexec workflows list --output json

# YAML format
pyexec workflows list --output yaml
```

## Configuration File

Configuration is stored in `~/.pyexec/config.json`:

```json
{
  "api_url": "https://api.example.com",
  "api_key": "sk_your_key",
  "organization": "My Org",
  "timeout": 60,
  "output_format": "table"
}
```

Environment variables override config file:
- `PYEXEC_API_URL`
- `PYEXEC_API_KEY`
- `PYEXEC_ORG`

## Examples

### Run workflow and wait for completion

```bash
pyexec workflows run order-processing \
  --context order_id="ORD-12345" \
  --context customer_email="user@example.com" \
  --wait --follow-logs
```

### Get failed jobs from last 24 hours

```bash
pyexec jobs list \
  --filter status=failed \
  --filter since="2024-01-01" \
  --output json
```

### Monitor job execution

```bash
JOB_ID=$(pyexec workflows run daily-report --output json | jq -r '.id')
pyexec jobs follow $JOB_ID
```

### Bulk operations with bash

```bash
# Process multiple orders
while IFS=',' read -r order_id email; do
  pyexec workflows run order-processing \
    --context order_id="$order_id" \
    --context customer_email="$email" \
    --wait
done < orders.csv
```

### Set secret from environment

```bash
export MY_API_KEY="secret_value"
pyexec secrets set MY_API_KEY --from-env MY_API_KEY
```

## Development

### Install in development mode

```bash
cd cli/
pip install -e .
```

### Run tests

```bash
pytest tests/
```

## License

MIT License

## Support

- Documentation: https://pyexecutor.com/cli-guide.html
- Issues: https://github.com/pyexecutor/cli/issues
- Website: https://pyexecutor.com
