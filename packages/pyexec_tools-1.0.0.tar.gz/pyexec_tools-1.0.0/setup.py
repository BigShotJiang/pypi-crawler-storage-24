#!/usr/bin/env python
"""
PyExecutor CLI Tool
Enterprise-grade command-line interface for managing PyExecutor workflows, jobs, secrets, and more.
"""

from setuptools import setup, find_packages
import os

# Read long description from README
long_description = """
PyExecutor CLI Tool

Command-line interface for managing PyExecutor workflows, jobs, and automation.

Features:
- Workflow management (list, get, run, test, archive)
- Job execution monitoring (list, get, follow, cancel)
- Secrets management (set, get, rotate, export)
- Logs & debugging tools
- Workflow templates
- Batch operations

Installation:
    pip install pyexec

Usage:
    pyexec workflows list
    pyexec workflows run my-workflow --context key=value
    pyexec jobs get 12345 --follow-logs
    pyexec secrets set API_KEY

Documentation: https://pyexecutor.com/cli-guide.html
"""

setup(
    name="pyexec",
    version="1.0.0",
    description="Command-line tool for PyExecutor workflow orchestration platform",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="PyExecutor",
    author_email="info@pyexecutor.com",
    url="https://pyexecutor.com",
    packages=find_packages(),
    install_requires=[
        "click>=8.1.0",
        "requests>=2.31.0",
        "rich>=13.0.0",
        "python-dotenv>=1.0.0",
        "tabulate>=0.9.0",
        "pyyaml>=6.0",
    ],
    entry_points={
        "console_scripts": [
            "pyexec=pyexec.cli:cli",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: System Administrators",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: System :: Systems Administration",
    ],
    python_requires=">=3.8",
    keywords="workflow orchestration automation devops cli python",
    project_urls={
        "Documentation": "https://pyexecutor.com/cli-guide.html",
        "Source": "https://github.com/pyexecutor/cli",
        "Bug Reports": "https://github.com/pyexecutor/cli/issues",
    },
)
