from setuptools import setup, find_packages
from pathlib import Path

classifiers = """
Development Status :: 1 - Planning
Intended Audience :: Science/Research
Natural Language :: English
Operating System :: OS Independent
Programming Language :: Python :: 3.5
Programming Language :: Python :: 3.6
Programming Language :: Python :: 3.7
Programming Language :: Python :: 3.8
Programming Language :: Python :: 3.9
Programming Language :: Python :: 3.10
Programming Language :: Python :: 3.11
Topic :: Utilities
Topic :: Scientific/Engineering
Topic :: Scientific/Engineering :: Artificial Intelligence
Topic :: Software Development :: Libraries :: Python Modules
License :: OSI Approved :: MIT License
"""
try:
    from Accuinsight import __about__
    about = __about__.__dict__
except ImportError:
    about = dict()
    # 수정됨: encoding="utf-8" 추가
    exec(open("modeler/__about__.py", encoding="utf-8").read(), about)

setup(
    name='Accuinsight',
    version=about['__version__'],
    url=about['__url__'],
    author=about['__author__'],
    description='Model life cycle and monitoring library in Accuinsight+',
    # 이미 잘 되어 있음
    long_description=Path("README.rst").read_text(encoding="utf-8"),
    packages=find_packages(exclude=['tests', 'tests.*']),
    # 수정됨: encoding="utf-8" 추가
    install_requires=[
        line.split('#')[0].strip()
        for line in Path("requirements.txt").read_text(encoding="utf-8").splitlines()
        if line.strip() and not line.strip().startswith('#')
    ],
    setup_requires=['pytest-runner'],
    tests_require=["mock>=0.8, <3.0", "pytest==4.3.0"],
    classifiers=list(filter(None, classifiers.split("\n"))),
    zip_safe=False
)