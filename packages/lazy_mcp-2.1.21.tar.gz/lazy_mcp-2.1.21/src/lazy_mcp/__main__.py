"""Allow running as `python -m lazy_mcp`."""

from lazy_mcp import main

main()
