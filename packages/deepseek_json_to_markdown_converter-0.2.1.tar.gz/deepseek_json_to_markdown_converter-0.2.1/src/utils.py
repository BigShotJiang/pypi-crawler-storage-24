import re
from datetime import datetime

def format_timestamp(ts_str):
    """
    Parses ISO timestamp string to datetime object.
    Example: 2026-02-09T15:17:15.356000+08:00
    """
    try:
        if not ts_str:
            return None
        dt = datetime.fromisoformat(ts_str)
        return dt
    except Exception:
        return None


def to_template_datetime(dt_obj):
    """
    Format datetime for template placeholders.
    Output format: YYYY-MM-DDTHH:MM:SS
    """
    if not dt_obj:
        return ""
    return dt_obj.strftime('%Y-%m-%dT%H:%M:%S')

def sanitize_filename(filename, date_obj=None):
    """
    Sanitize title to a clean, route-friendly filename.

    Rules:
    - Remove common punctuation (both CJK and ASCII).
    - Replace whitespace/newlines with '-'.
    - Keep only URL-safe unreserved ASCII chars and CJK chars.
    - Collapse repeated separators.
    - Prepend YYYYMMDD- if date_obj provided.
    """
    if not filename:
        filename = "Untitled"

    # Normalize line breaks and whitespace first.
    clean_name = filename.replace('\n', ' ').replace('\r', ' ').strip()
    clean_name = re.sub(r'\s+', '-', clean_name)

    # Remove common punctuation in Chinese/English contexts.
    clean_name = re.sub(
        r"[，。！？；：、“”‘’（）【】《》〈〉·…—、,.;:!?\"'`~@#$%^&*+=|\\/<>\[\]{}()]",
        "",
        clean_name,
    )

    # Keep URL-friendly characters (RFC 3986 unreserved) plus CJK.
    clean_name = re.sub(r'[^A-Za-z0-9._~\-\u4e00-\u9fff]+', '-', clean_name)

    # Normalize repeated separators and trim edge separators.
    clean_name = re.sub(r'-{2,}', '-', clean_name)
    clean_name = re.sub(r'_{2,}', '_', clean_name)
    clean_name = clean_name.strip('-_.~')

    if not clean_name:
        clean_name = "Untitled"

    # Add date prefix if available.
    if date_obj:
        date_prefix = date_obj.strftime('%Y%m%d')
        return f"~{date_prefix}-{clean_name}"

    return clean_name

def senitize_title_for_template(title):
    """
    Sanitize title for template usage.
    - Replace newlines with spaces.
    - Remove leading/trailing whitespace.
    """
    if not title:
        return "Untitled"
    clean_title = title.replace('\n', ' ').replace('\r', ' ').strip()
    return clean_title if clean_title else "Untitled"
