import argparse
import json
import os
import sys
from datetime import datetime

# Import local modules
# Assuming script is run from workspace root, append src to path if needed
sys.path.append(os.path.join(os.path.dirname(__file__)))

import utils
import parser
import renderer


def parse_args():
    """Parse required CLI arguments."""
    parser_obj = argparse.ArgumentParser(
        description="Convert DeepSeek conversations JSON to Markdown files."
    )
    parser_obj.add_argument(
        "-i",
        "--input",
        required=True,
        help="Path to DeepSeek conversations.json file",
    )
    parser_obj.add_argument(
        "-o",
        "--output-dir",
        required=True,
        help="Output directory for generated markdown files",
    )
    parser_obj.add_argument(
        "-t",
        "--template",
        required=True,
        help="Markdown template path",
    )
    parser_obj.add_argument(
        "-f",
        "--force",
        action="store_true",
        help="Overwrite existing files and continue export",
    )
    return parser_obj.parse_args()


def validate_paths(input_file, output_dir, template_file):
    """Validate input/template paths and ensure output directory exists."""
    if not os.path.isfile(input_file):
        raise ValueError(f"Input file not found: {input_file}")
    if not os.access(input_file, os.R_OK):
        raise ValueError(f"Input file is not readable: {input_file}")

    if not os.path.isfile(template_file):
        raise ValueError(f"Template file not found: {template_file}")
    if not os.access(template_file, os.R_OK):
        raise ValueError(f"Template file is not readable: {template_file}")

    os.makedirs(output_dir, exist_ok=True)
    if not os.path.isdir(output_dir):
        raise ValueError(f"Output path is not a directory: {output_dir}")


def load_template(template_file):
    """Read template file text."""
    with open(template_file, 'r', encoding='utf-8') as f:
        template_text = f.read()
    renderer.validate_template_placeholders(template_text)
    return template_text


def load_conversations(input_file):
    """Load and validate conversation list from JSON."""
    with open(input_file, 'r', encoding='utf-8') as f:
        data = json.load(f)

    if not isinstance(data, list):
        raise ValueError("JSON root must be a list of conversations")
    return data


def build_output_filepath(conv, output_dir):
    """Build markdown output file path from conversation metadata."""
    title = conv.get('title', 'Untitled')
    create_time_str = conv.get('inserted_at')

    create_date = utils.format_timestamp(create_time_str)
    filename = utils.sanitize_filename(title, create_date) + ".md"
    return os.path.join(output_dir, filename)

def build_obsidian_link(conv, output_dir):
    """Build Obsidian link for the conversation file."""
    title = utils.senitize_title_for_template(conv.get('title', 'Untitled'))
    create_time_str = conv.get('inserted_at')
    create_date = utils.format_timestamp(create_time_str)
    filename = utils.sanitize_filename(title, create_date) + ".md"
    return f"[[{filename}|{title}]]"

def process_single_conversation(conv, output_dir, template_text, export_time_str):
    title = conv.get('title', 'Untitled')
    create_time_str = conv.get('inserted_at')
    filepath = build_output_filepath(conv, output_dir)

    create_date = utils.format_timestamp(create_time_str)

    mapping = conv.get('mapping', {})
    root_id = None
    if 'root' in mapping:
        root_id = 'root'
    else:
        for k, v in mapping.items():
            if v.get('parent') is None:
                root_id = k
                break

    if not root_id:
        return False, "No root node found"

    messages = parser.traverse_mapping(mapping, root_id)

    if not messages:
        return False, "No valid messages found"

    content = renderer.render_content(messages)
    created_time = utils.to_template_datetime(create_date)
    md_content = renderer.render_with_template(
        template_text,
        {
            "title": title,
            "conversion_created_time": created_time,
            "conversion_export_time": export_time_str,
            "content": content,
        },
    )

    try:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(md_content)
        return True, filepath
    except Exception as e:
        return False, str(e)


def main():
    try:
        args = parse_args()
        input_file = args.input
        output_dir = args.output_dir
        template_file = args.template
        force = args.force

        validate_paths(input_file, output_dir, template_file)
        template_text = load_template(template_file)
        conversations = load_conversations(input_file)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)

    export_time_str = datetime.now().strftime('%Y-%m-%dT%H:%M:%S')

    print(f"Starting conversion from {input_file} to {output_dir}...")

    success_count = 0
    fail_count = 0
    # Prepare for obsidian link
    filename_index_string = ""
    filename_index_string_count = 1


    for conv in reversed(conversations):
        target_path = build_output_filepath(conv, output_dir)
        if (not force) and os.path.exists(target_path):
            print(
                "Detected existing file, assuming remaining conversations are already exported. "
                "Stopping export. Use -f/--force to overwrite and continue."
            )
            break
        filename_index_string += str(filename_index_string_count) + ". " + build_obsidian_link(conv, output_dir) + "\n"
        filename_index_string_count += 1
        success, result = process_single_conversation(
            conv,
            output_dir,
            template_text,
            export_time_str,
        )
        if success:
            success_count += 1
        else:
            fail_count += 1
            print(f"Failed conversation export: {result}")
    
    print(f"Completed.")
    print(f"Success: {success_count}")
    print(f"Failed:  {fail_count}")
    print(f"Obsidian Links: \n{filename_index_string}")

if __name__ == "__main__":
    main()
