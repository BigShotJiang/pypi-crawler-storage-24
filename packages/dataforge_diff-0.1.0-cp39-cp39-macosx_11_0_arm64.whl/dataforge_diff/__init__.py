"""DataForge Diff: High-Performance Data Diffing."""

__version__ = "0.1.0"

from .dataforge_diff import diff, version

__all__ = ["diff", "version"]
