"""Configuration management for aloud."""

import json
import os

CONFIG_DIR = os.path.join(
    os.environ.get("XDG_CONFIG_HOME", os.path.expanduser("~/.config")),
    "aloud",
)
CONFIG_PATH = os.path.join(CONFIG_DIR, "config.json")

DEFAULTS = {
    "feed_dir": os.path.expanduser("~/Projects/read-aloud-feed"),
    "feed_url": "https://xuefei-wang.github.io/read-aloud-feed",
    "speed": "+20%",
    "voice": "en-US-AndrewMultilingualNeural",
}


def load_config():
    try:
        with open(CONFIG_PATH) as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}


def save_config(cfg):
    os.makedirs(os.path.dirname(CONFIG_PATH), exist_ok=True)
    with open(CONFIG_PATH, "w") as f:
        json.dump(cfg, f, indent=2)
        f.write("\n")


def run_config_wizard():
    print("\naloud configuration\n")
    feed_dir = input(f"Feed directory [{DEFAULTS['feed_dir']}]: ").strip()
    feed_url = input(f"Feed URL [{DEFAULTS['feed_url']}]: ").strip()
    speed = input(f"Default speed [{DEFAULTS['speed']}]: ").strip()

    cfg = load_config()
    cfg["feed_dir"] = feed_dir or DEFAULTS["feed_dir"]
    cfg["feed_url"] = feed_url or DEFAULTS["feed_url"]
    cfg["speed"] = speed or DEFAULTS["speed"]
    cfg.setdefault("voice", DEFAULTS["voice"])
    save_config(cfg)
    print(f"\nConfig saved to {CONFIG_PATH}")
