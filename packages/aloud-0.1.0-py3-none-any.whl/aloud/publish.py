"""Episode publishing to podcast feed repo."""

import re
import shutil
import subprocess
import sys
from datetime import date
from pathlib import Path

from aloud import feed


def _check_git():
    if not shutil.which("git"):
        print(
            "error: git not found. Install with: sudo apt install git", file=sys.stderr
        )
        sys.exit(1)


def _sanitize(name: str) -> str:
    name = name.lower().replace(" ", "-").replace("_", "-")
    return re.sub(r"[^a-z0-9-]", "", name)


def _make_episode_name(source: str | None, text: str) -> str:
    today = date.today().isoformat()
    if source == "__clipboard__":
        words = text.split()[:6]
        slug = "clipboard-" + "-".join(words)
        return f"{today}-{_sanitize(slug)}.mp3"
    elif source is None:
        words = text.split()[:6]
        slug = "stdin-" + "-".join(words)
        return f"{today}-{_sanitize(slug)}.mp3"
    else:
        slug = Path(source).stem
        return f"{today}-{_sanitize(slug)}.mp3"


def publish(mp3_path: Path, title: str, config: dict) -> None:
    feed_dir = Path(config["feed_dir"])
    feed_url = config["feed_url"]
    episodes_dir = feed_dir / "episodes"
    episodes_dir.mkdir(parents=True, exist_ok=True)

    dest = episodes_dir / f"{title}"
    shutil.copy2(mp3_path, dest)
    mp3_path.unlink(missing_ok=True)
    print(f"Saved: {dest}", file=sys.stderr)

    feed.generate(feed_dir, feed_url)

    # Git add, commit, push
    _check_git()
    subprocess.run(["git", "add", "feed.xml", "episodes/"], cwd=feed_dir, check=True)
    result = subprocess.run(["git", "diff", "--cached", "--quiet"], cwd=feed_dir)
    if result.returncode != 0:
        # There are staged changes — title is already like "2026-03-13-my-article.mp3"
        episode_slug = Path(title).stem  # "2026-03-13-my-article"
        subprocess.run(
            ["git", "commit", "-m", f"add: {episode_slug}"],
            cwd=feed_dir,
            check=True,
        )
        subprocess.run(["git", "push"], cwd=feed_dir, check=True)
        print("Pushed to remote", file=sys.stderr)
    else:
        print("No changes to commit", file=sys.stderr)
