def get_time_slices(metadata: dict) -> list[dict]:
    """从 metadata 中读取 time_slices 列表。

    路径: metadata["label"]["time_slice_label"]["time_slices"]
    无数据或缺键时返回 []。
    """
    raw = metadata.get("metadata", {}).get("label", {}).get("time_slice_label", {}).get("time_slices", [])

    time_slices = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        action = item.get("action")
        start_time = item.get("start_time")
        end_time = item.get("end_time")
        if action is None or start_time is None or end_time is None:
            continue
        try:
            time_slices.append({
                "action": str(action),
                "start_time": float(start_time),
                "end_time": float(end_time),
            })
        except (TypeError, ValueError):
            continue

    return time_slices


def get_action_at_time(time_slices: list[dict], relative_time: float) -> str:
    """根据相对时间（秒）找到包含该时刻的 slice，返回其 action。

    按数组顺序优先：取第一个满足 start_time <= relative_time < end_time 的 slice。
    重叠时只返回第一个匹配项；不在任何区间内返回 ""。
    """
    for slice_item in time_slices:
        start = slice_item.get("start_time")
        end = slice_item.get("end_time")
        if start is None or end is None:
            continue
        if start <= relative_time < end:
            action = slice_item.get("action")
            return "" if action is None else str(action)
    return ""
