from io import BytesIO

import numpy as np
from PIL import Image
from data_pipeline.data_process.utils.config_manager import config_manager


def resize_jpeg_image(data):
    """
    将 JPEG 图像数据解码、调整大小并重新编码为 JPEG 格式

    Args:
        data: JPEG 图像的字节数据

    Returns:
        numpy.ndarray: 调整大小后的 JPEG 图像字节数据的 numpy 数组
    """
    config = config_manager.config.get("resize_image")

    target_width = config.get("width")
    target_height = config.get("height")
    jpeg_quality = 95

    # 将字节数据解码为 PIL Image
    image = Image.open(BytesIO(data))

    # 调整图像大小
    resized_image = image.resize((target_width, target_height), Image.Resampling.LANCZOS)

    # 将调整后的图像编码回 JPEG 格式
    output_buffer = BytesIO()
    resized_image.save(output_buffer, format='JPEG', quality=jpeg_quality)
    jpeg_bytes = output_buffer.getvalue()

    # 返回 numpy 数组
    return np.frombuffer(jpeg_bytes, dtype=np.uint8)


def convert_message(msg, data_type=None):
    msg_type = type(msg).__name__
    if msg_type == "_sensor_msgs__CompressedImage":
        return convert_compressed_image(msg, data_type)
    if msg_type == "_data_msgs__ComponentObservation":
        return convert_component_observation(msg, data_type)
    if msg_type == "_data_msgs__ComponentAction":
        return convert_component_action(msg, data_type)
    if msg_type == "str":
        return msg

    raise ValueError(f"message type {msg_type} not supported")


def convert_compressed_image(msg, data_type):
    if config_manager.config.get("resize_image") and data_type != "depth_image":
        return resize_jpeg_image(msg.data)

    return np.frombuffer(msg.data, dtype=np.uint8)


def convert_component_observation(msg, data_type):
    if data_type == "pose":
        pose = msg.multibody_pose.pose
        return np.array([
            pose.position.x, pose.position.y, pose.position.z,
            pose.orientation.x, pose.orientation.y, pose.orientation.z, pose.orientation.w
        ])
    if data_type == "joint":
        return np.array([state_msg.q for state_msg in msg.multibody_state.states])
    if data_type == "ft":
        wrench = msg.force_torques[0].wrench
        return np.array([wrench.force.x, wrench.force.y, wrench.force.z,
                         wrench.torque.x, wrench.torque.y, wrench.torque.z])
    raise ValueError(f"data_type {data_type} not supported")


def convert_component_action(msg, data_type):
    if data_type == "pose":
        pose = msg.pose_command.pose
        return np.array([
            pose.position.x, pose.position.y, pose.position.z,
            pose.orientation.x, pose.orientation.y, pose.orientation.z, pose.orientation.w
        ])
    if data_type == "joint":
        return np.array(msg.joint_commands)
    raise ValueError(f"data_type {data_type} not supported")
