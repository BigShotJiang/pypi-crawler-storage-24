"""Auto-generated example: Aggregate Over Time — 2D sweep to scalar curve with error bounds."""

from typing import Any

import math
import bencher as bch
from datetime import datetime, timedelta


class ThermalPlate(bch.ParametrizedSweep):
    """Measures temperature across a 2D plate that cools over time.

    A 2D sweep (x, y) is run at each time snapshot. Both dimensions are
    then collapsed via agg_over_dims, producing a single mean +/- std per
    time point. The curve shows how the plate-wide average temperature
    decays, with error bounds from the spatial variation across the grid.
    """

    x = bch.FloatSweep(default=0.5, bounds=[0.0, 1.0], doc="Horizontal position on plate")
    y = bch.FloatSweep(default=0.5, bounds=[0.0, 1.0], doc="Vertical position on plate")

    temperature = bch.ResultVar(units="C", doc="Measured temperature")

    _time_offset = 0.0  # set externally per snapshot

    def __call__(self, **kwargs: Any) -> Any:
        self.update_params_from_kwargs(**kwargs)
        # Hot spot at centre, decaying over time
        self.temperature = (
            100
            * math.sin(math.pi * self.x)
            * math.sin(math.pi * self.y)
            * math.exp(-0.3 * self._time_offset)
            + 20
        )
        return super().__call__()


def example_advanced_agg_over_time(run_cfg: bch.BenchRunCfg | None = None) -> bch.Bench:
    """Aggregate Over Time — 2D sweep to scalar curve with error bounds."""
    run_cfg = run_cfg or bch.BenchRunCfg()
    run_cfg.over_time = True

    benchable = ThermalPlate()
    bench = benchable.to_bench(run_cfg)

    base_time = datetime(2024, 1, 1)
    for i, offset in enumerate([0.0, 1.0, 2.0, 3.0, 4.0]):
        benchable._time_offset = offset
        run_cfg.clear_cache = True
        run_cfg.clear_history = i == 0
        run_cfg.auto_plot = False
        bench.plot_sweep(
            "thermal_plate",
            input_vars=["x", "y"],
            result_vars=["temperature"],
            run_cfg=run_cfg,
            time_src=base_time + timedelta(seconds=i),
        )

    res = bench.results[-1]

    # 1) Raw 2D heatmap with over_time slider
    bench.report.append(res.to(bch.HeatmapResult))

    # 2) Aggregate the full 2D grid down to a scalar: mean +/- std at each time point
    bench.report.append(res.to(bch.CurveResult, agg_over_dims=["x", "y"]))

    return bench


if __name__ == "__main__":
    bch.run(example_advanced_agg_over_time, level=4)
