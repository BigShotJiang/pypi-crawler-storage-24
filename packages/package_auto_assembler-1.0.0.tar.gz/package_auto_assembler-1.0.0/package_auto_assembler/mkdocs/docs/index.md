# Intro

[![PyPiVersion](https://img.shields.io/pypi/v/package-auto-assembler)](https://pypi.org/project/package-auto-assembler/) [![License](https://img.shields.io/github/license/Kiril-Mordan/reusables)](https://github.com/Kiril-Mordan/reusables/blob/main/LICENSE)

`package-auto-assembler` is a tool designed to streamline creation of `single module packages`.
Its primary goal is to automate as many aspects of python package creation as possible,
thereby shortening the development cycle of reusable components and maintaining a high standard of quality for reusable code.

With `package-auto-assembler`, you can simplify the package creation process to the point where it can be seamlessly triggered within CI/CD pipelines, requiring minimal setup and preparation for new modules.

## Key features

- [Set up new Python packaging repositories](https://kiril-mordan.github.io/reusables/package_auto_assembler/concepts/python_packaging_repo/) for Github and Azure DevOps.
- [Create and validate packages](https://kiril-mordan.github.io/reusables/package_auto_assembler/interfaces/cli/) with `make-package` and `test-install`.
- [Check module dependencies](https://kiril-mordan.github.io/reusables/package_auto_assembler/concepts/dependency_management/) for vulnerabilities, compatibility, and license constraints.
- [Run and expose interfaces](https://kiril-mordan.github.io/reusables/package_auto_assembler/interfaces/mcp/) through MCP, and via [FastAPI](https://kiril-mordan.github.io/reusables/package_auto_assembler/interfaces/fastapi/) or [Streamlit](https://kiril-mordan.github.io/reusables/package_auto_assembler/interfaces/streamlit/) integrations.
- [Extract artifacts and files](https://kiril-mordan.github.io/reusables/package_auto_assembler/components/artifacts/) packaged alongside code.
- [Show detailed module information](https://kiril-mordan.github.io/reusables/package_auto_assembler/interfaces/cli/) for installed packages built with PAA.
- [Create and navigate package history checkpoints](https://kiril-mordan.github.io/reusables/package_auto_assembler/concepts/checkpoint_history/) including list/show/prune/checkout flows.
- [Infer requirements from imports](https://kiril-mordan.github.io/reusables/package_auto_assembler/components/import_mapping/) with mapping overrides and optional compatibility checks.


## Installation

```bash
pip install package-auto-assembler
```

