from setuptools import setup

import codecs
import os

here = os.path.abspath(os.path.dirname(__file__))
path_to_readme = os.path.join(here, "README.md")

long_description = """# Package auto assembler

`package-auto-assembler` is a tool designed to streamline creation of `single module packages`.
Its primary goal is to automate as many aspects of python package creation as possible,
thereby shortening the development cycle of reusable components and maintaining a high standard of quality for reusable code.

With `package-auto-assembler`, you can simplify the package creation process to the point where it can be seamlessly triggered within CI/CD pipelines, requiring minimal setup and preparation for new modules.

## Key features

- [Set up new Python packaging repositories](https://kiril-mordan.github.io/reusables/package_auto_assembler/concepts/python_packaging_repo/) for Github and Azure DevOps.
- [Create and validate packages](https://kiril-mordan.github.io/reusables/package_auto_assembler/interfaces/cli/) with `make-package` and `test-install`.
- [Check module dependencies](https://kiril-mordan.github.io/reusables/package_auto_assembler/concepts/dependency_management/) for vulnerabilities, compatibility, and license constraints.
- [Run and expose interfaces](https://kiril-mordan.github.io/reusables/package_auto_assembler/interfaces/mcp/) through MCP, and via [FastAPI](https://kiril-mordan.github.io/reusables/package_auto_assembler/interfaces/fastapi/) or [Streamlit](https://kiril-mordan.github.io/reusables/package_auto_assembler/interfaces/streamlit/) integrations.
- [Extract artifacts and files](https://kiril-mordan.github.io/reusables/package_auto_assembler/components/artifacts/) packaged alongside code.
- [Show detailed module information](https://kiril-mordan.github.io/reusables/package_auto_assembler/interfaces/cli/) for installed packages built with PAA.
- [Create and navigate package history checkpoints](https://kiril-mordan.github.io/reusables/package_auto_assembler/concepts/checkpoint_history/) including list/show/prune/checkout flows.
- [Infer requirements from imports](https://kiril-mordan.github.io/reusables/package_auto_assembler/components/import_mapping/) with mapping overrides and optional compatibility checks.

"""

if os.path.exists(path_to_readme):
  with codecs.open(path_to_readme, encoding="utf-8") as fh:
      long_description += fh.read()

setup(
    name="package_auto_assembler",
    packages=["package_auto_assembler"],
    install_requires=['setuptools>=78.1.1', 'nbformat', 'mkdocs-mermaid2-plugin>=1.2.1', 'mkdocs>=1.6.0,<2.0', 'pyyaml', 'attrs>=22.2.0', 'twine>=5.1.1', 'click==8.1.7', 'mcp', 'fastapi', 'pandas', 'mkdocs-material>=9.5.30', 'streamlit>=1.39.0', 'nbconvert>=7.16.4', 'uvicorn', 'jupyter>=1.1.1', 'packaging', 'wheel>=0.44.0', 'numpy==1.26.0', 'stdlib-list', 'pip_audit==2.7.3', 'attrsx', 'requests'],
    classifiers=['Intended Audience :: Developers', 'Intended Audience :: Science/Research', 'Programming Language :: Python :: 3', 'Programming Language :: Python :: 3.10', 'Programming Language :: Python :: 3.11', 'Programming Language :: Python :: 3.12', 'License :: OSI Approved :: MIT License', 'Topic :: Scientific/Engineering', 'Development Status :: 5 - Production/Stable'],
    long_description=long_description,
    long_description_content_type='text/markdown',
    author="Kyrylo Mordan",
    author_email="parachute.repo@gmail.com",
    description="A tool to automate package creation within ci based on just .py and optionally .ipynb file.",
    keywords=['python', 'packaging', 'aa-paa-tool'],
    url="https://kiril-mordan.github.io/reusables/package_auto_assembler/",
    version="1.0.0",
    entry_points = {'console_scripts': ['paa = package_auto_assembler.cli:cli']},

    license = "mit",
    include_package_data = True,
    package_data = {'package_auto_assembler': ['mkdocs/**/*', 'artifacts/.paa.tracking/git/**/*', 'artifacts/.paa.tracking/git_repo/**/*', 'artifacts/package_mapping.json', 'artifacts/examples/**/*', 'artifacts/package_licenses.json', 'artifacts/ppr_workflows/**/*', 'artifacts/tools/**/*', '.paa.tracking/version_logs.csv', '.paa.tracking/release_notes.md', '.paa.tracking/lsts_package_versions.yml', '.paa.tracking/package_mapping.json', '.paa.tracking/package_licenses.json', '.paa.tracking/.drawio', '.paa.tracking/extra_docs/**/*', '.paa.tracking/skills/**/*', 'tests/**/*', '.paa.tracking/.paa.config', '.paa.tracking/LICENSE', '.paa.tracking/pyproject.toml', '.paa.tracking/git/**/*', '.paa.tracking/git_repo/**/*', '.paa.tracking/python_modules/package_auto_assembler.py', '.paa.tracking/python_modules/components/paa_deps/drawio_handler.py', '.paa.tracking/python_modules/components/paa_deps/requirements_handler.py', '.paa.tracking/python_modules/components/paa_deps/fastapi_handler.py', '.paa.tracking/python_modules/components/paa_deps/import_mapping_handler.py', '.paa.tracking/python_modules/components/paa_deps/mkdocs_handler.py', '.paa.tracking/python_modules/components/paa_deps/local_dependencies_handler.py', '.paa.tracking/python_modules/components/paa_deps/tests_handler.py', '.paa.tracking/python_modules/components/paa_deps/metadata_handler.py', '.paa.tracking/python_modules/components/paa_deps/version_handler.py', '.paa.tracking/python_modules/components/paa_deps/skills_handler.py', '.paa.tracking/python_modules/components/paa_deps/cli_handler.py', '.paa.tracking/python_modules/components/paa_deps/streamlit_handler.py', '.paa.tracking/python_modules/components/paa_deps/ppr_handler.py', '.paa.tracking/python_modules/components/paa_deps/release_notes_handler.py', '.paa.tracking/python_modules/components/paa_deps/mcp_handler.py', '.paa.tracking/python_modules/components/paa_deps/setup_dir_handler.py', '.paa.tracking/python_modules/components/paa_deps/dependencies_analyzer.py', '.paa.tracking/python_modules/components/paa_deps/long_doc_handler.py', '.paa.tracking/python_modules/components/paa_deps/artifacts_handler.py', '.paa.tracking/python_modules/components/paa_deps/checkpoint_handler.py', '.paa.tracking/.paa.version']} ,
    license_files = ["LICENSE", "NOTICE"],
    )
