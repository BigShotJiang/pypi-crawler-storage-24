"""
Examples for MetaDefender Python SDK

To run the example:
    export METADEFENDER_APIKEY="your-api-key"
    python -m exemples.exemple_all_workflows
"""
