import os
import time
import json
from mcl_platform_sdk import ApiClient, Configuration
from mcl_platform_sdk.api import apikey_api, file_scanning_api, data_sanitization_cdr_api, dynamic_analysis_api, hash_lookups_api, reputation_service_api

def main():
    # Check for API key
    if not os.environ.get("METADEFENDER_APIKEY"):
        print("METADEFENDER_APIKEY environment variable is not set.")
        print("Please set it using: export METADEFENDER_APIKEY='your-api-key'")
        return

    test_file_path = os.environ.get(
        "METADEFENDER_TEST_FILE_PATH", "tests/Test.pdf"
    )
    if not os.path.exists(test_file_path):
        print(f"Test file does not exist: {test_file_path}")
        return

    client = ApiClient()

    print("=" * 60)
    print("  MetaDefender SDK - Test Workflow")

    # 1. Verify API Key
    print("\n1. Testing API Key Info...")
    api_instance = apikey_api.ApikeyApi(client)
    apikey_info = api_instance.get_api_key()
    print(f"✓ API key nickname: {apikey_info.nickname or 'Valid'}")
    print("API key data:", json.dumps(apikey_info.to_dict(), indent=2))

    # 2. API key limits
    print("\n2. Testing API Key Limits...")
    limits = api_instance.get_api_key_limits()
    print("✓ API key limits retrieved")
    print("API key limits:", json.dumps(limits.to_dict(), indent=2))

    # 3. Upload file
    print("\n3. Uploading file for scanning...")
    with open(test_file_path, "rb") as f:
        file_bytes = f.read()

    fs_api = file_scanning_api.FileScanningApi(client)
    print(f"   File: {os.path.basename(test_file_path)} ({len(file_bytes)} bytes)")

    upload_resp = fs_api.analyze_file(
        file=file_bytes,
        headers={
            "filename": os.path.basename(test_file_path),
            "rule": "sanitize",
            "sandbox": "windows10",
        },
    )

    data_id = upload_resp.data_id
    print("✓ File uploaded successfully")
    print("Upload response:", json.dumps(upload_resp.to_dict(), indent=2))

    # 4. Polling scan results (using the new automatic polling method)
    print("\n4. Waiting for scan to complete (with automatic polling)...")
    try:
        lookup = fs_api.get_file_analysis(
            data_id,
            headers={
                "timeout": 120,
                "poll_interval": 2,
            },
        )
        print("✓ Scan completed!")
        print(f"   Status: {lookup.scan_results.scan_all_result_a}")
        print("Scan results:", json.dumps(lookup.to_dict(), indent=2))
    except TimeoutError:
        print("⚠ Scan timeout - fetching latest status...")
        lookup = fs_api.get_file_analysis(data_id)
        print(f"  ✓ Current Status: {lookup.scan_results.scan_all_result_a}")
    except Exception as e:
        print(f"✗ Error during scan: {e}")
        return

    # Get final results
    lookup = fs_api.get_file_analysis(data_id)

    # 5. Fetch sanitized file
    if getattr(lookup, "sanitized", False):
        print("\n5. Testing Sanitized File Retrieval...")
        cdr_api = data_sanitization_cdr_api.DataSanitizationCDRApi(client)
        sanitized_file_resp = cdr_api.download_sanitized_file(data_id)

        if sanitized_file_resp.sanitized_file_path:
            print("✓ Sanitization completed")
            print("✓ Sanitized file retrieved")
            print(f"   URL: {sanitized_file_resp.sanitized_file_path}")

        # cleanup - delete sanitized file
        cdr_api.delete_sanitized_file(data_id=data_id)
        print("  ✓ Cleanup: File deleted")

    # 6. Sandbox Analysis
    print("\n6. Testing Sandbox Analysis...")

    sandbox_id = getattr(upload_resp, 'sandbox_id', None)
    print(f"Sandbox ID: {sandbox_id}")

    if sandbox_id:
        try:
            print("   Polling for sandbox results (max 15 minutes)...")
            sandbox_api = dynamic_analysis_api.DynamicAnalysisApi(client)

            # Poll for up to 15 minutes (900 seconds)
            timeout = 900
            poll_interval = 30
            start_time = time.time()
            max_time = start_time + timeout
            attempt = 0

            sandbox_res = None
            while time.time() < max_time:
                attempt += 1
                sandbox_res = sandbox_api.get_sandbox(sandbox_id)

                # Debug: show what we got
                print(f"   Attempt {attempt}: Checking sandbox status...")
                # sandbox_lookup returns a oneOf wrapper (SandboxLookup200Response).
                # Use dict view so we can consistently read keys.
                sandbox_dict = (
                    sandbox_res.to_dict()
                    if hasattr(sandbox_res, "to_dict") and callable(sandbox_res.to_dict)
                    else (sandbox_res if isinstance(sandbox_res, dict) else {})
                )
                final_verdict = sandbox_dict.get("final_verdict")
                status = sandbox_dict.get("status")
                print(f"   final_verdict: {final_verdict}, status: {status}")

                # Check if analysis is complete
                if final_verdict or status == "completed":
                    print("✓ Sandbox analysis completed")
                    print("Sandbox results:", json.dumps(sandbox_res.to_dict(), indent=2))
                    break

                print("   Analysis in progress, waiting 30 seconds...")
                time.sleep(poll_interval)
            else:
                print("⚠ Sandbox analysis did not complete within 15 minutes")
                if sandbox_res:
                    print("Latest status:", json.dumps(sandbox_res.to_dict(), indent=2))

        except Exception as e:
            print(f"⚠ Sandbox analysis failed: {e}")
    else:
        print("⚠ No sandbox ID available in upload response")
        print("   Use sandbox parameter in file upload to trigger sandbox analysis")

    # 7. Hash lookups
    print("\n7. Testing Hash Lookup...")
    hash_api = hash_lookups_api.HashLookupsApi(client)
    uploaded_sha1 = getattr(upload_resp, 'sha1', None)
    if not uploaded_sha1:
        print("⚠ No SHA1 hash available in upload response")
        return

    hash_result = hash_api.lookup_hash(hash=uploaded_sha1)
    print("✓ Hash lookup completed")
    print(f"   Hash: {uploaded_sha1}")
    print("Hash lookup result:", json.dumps(hash_result.to_dict(), indent=2))

    # 8. Reputation service
    print("\n8. Testing Reputation Services...")
    rep_api = reputation_service_api.ReputationServiceApi(client)

    # IP reputation
    ip_rep = rep_api.lookup_ip(observable_ip="198.15.127.171")
    print("✓ IP reputation check: 198.15.127.171")
    print("IP reputation:", json.dumps(ip_rep.to_dict(), indent=2))

    # Domain reputation
    domain_rep = rep_api.lookup_domain(observable_domain="example.com")
    print("  ✓ Domain: example.com - Checked")
    print("Domain reputation:", json.dumps(domain_rep.to_dict(), indent=2))

    # URL reputation
    url_rep = rep_api.lookup_url(observable_url="http://hdfc.pp.ru/permit/gate.php")
    print("\n✓ URL reputation check: http://hdfc.pp.ru/permit/gate.php")
    print("URL reputation:", json.dumps(url_rep.to_dict(), indent=2))

    print("\n" + "=" * 60)
    print("✓ All workflows completed successfully!")
    print("=" * 60)


if __name__ == "__main__":
    try:
        main()
    except Exception as err:
        print("\n" + "=" * 60)
        print("✗ Test Failed")
        print("=" * 60)
        print(f"Error: {err}")

        # Check if it's an API exception
        if hasattr(err, 'status'):
            print(f"HTTP Status: {err.status}")
        if hasattr(err, 'body'):
            print("Error details:")
            try:
                error_data = json.loads(err.body)
                print(json.dumps(error_data, indent=2))
            except:
                print(err.body)
        print("=" * 60)
        exit(1)
