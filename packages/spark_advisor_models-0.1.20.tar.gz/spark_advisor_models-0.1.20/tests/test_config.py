from spark_advisor_models.config import AiSettings


def test_ai_settings_has_base_url_and_api_key():
    settings = AiSettings()
    assert settings.base_url == "https://openrouter.ai/api/v1"
    assert settings.api_key == ""
    assert settings.model == "qwen/qwen3-coder:free"


def test_ai_settings_custom_provider():
    settings = AiSettings(base_url="http://localhost:11434/v1", api_key="ollama", model="llama3.3")
    assert settings.base_url == "http://localhost:11434/v1"
    assert settings.api_key == "ollama"
