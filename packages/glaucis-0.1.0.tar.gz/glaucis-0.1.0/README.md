# glaucis

Knowledge platform for AI coding agents.

> This package is reserved. Full release coming soon.

## About

**glaucis** makes AI coding agents smarter by giving them structured access
to knowledge about your codebase — modules, dependencies, patterns, and more.

- GitHub: https://github.com/glaucis
