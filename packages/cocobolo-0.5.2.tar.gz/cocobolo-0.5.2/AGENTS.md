# AGENTS.md - Coding Guidelines for Cocobolo

## Build/Lint/Test Commands

```bash
# Install dependencies (uses hatchling build backend and uv)
uv pip install -e .

# Run the application
cocobolo --config config.json
# Or directly
python -m cocobolo.cli --config config.json

# Run a single test file (when tests exist)
pytest tests/test_file.py -v

# Run a single test
pytest tests/test_file.py::test_function_name -v

# Run all tests
pytest

# Check types with pyright
pyright src/cocobolo

# Alternative: Check types with mypy
mypy src/cocobolo

# Format code with ruff
ruff format src/
ruff check --fix src/
```

## Project Structure

- `src/cocobolo/` - Main source code
  - `cli/` - Typer-based CLI commands
  - `sources/` - Event sources (MQTT, watch, mail, heartbeat, etc.)
  - `actions/` - Action handlers (exec, db_insert, mqtt_publish, etc.)
  - `server/` - FastAPI web server and dashboard
  - `services/` - Business logic services
  - `utils/` - Utility modules
- `config.json` - Example configuration
- `pyproject.toml` - Project configuration

## Code Style Guidelines

### Imports
- Use `from __future__ import annotations` as the first import
- Group imports: stdlib, third-party, local (each group separated by blank line)
- Use absolute imports for cross-package references
- Use relative imports (e.g., `from ..event import Event`) within the same package
- Sort imports alphabetically within groups

### Type Hints
- Use Python 3.11+ modern syntax: `str | None` instead of `Optional[str]`
- Use `list[str]` instead of `List[str]` (PEP 585)
- Use `dict[str, Any]` instead of `Dict[str, Any]`
- Type all function parameters and return types
- Use `Any` sparingly; prefer specific types
- Use Pydantic models for configuration/data classes

### Naming Conventions
- `snake_case` for functions, variables, modules
- `PascalCase` for classes, Pydantic models
- `UPPER_CASE` for constants
- Private functions/variables prefixed with `_`
- Abstract base classes should inherit from `ABC`

### Formatting
- 4 spaces for indentation
- 88-100 character line length (Black default compatible)
- Two blank lines between top-level definitions
- One blank line between methods in a class
- Use double quotes for strings

### Pydantic Models
- Use `model_config = ConfigDict(extra="allow")` for flexible models
- Use `ConfigDict(frozen=True)` for immutable models
- Use `Field()` for descriptions and defaults
- Implement polymorphic validation via `__get_pydantic_core_schema__`

### Error Handling
- Use specific exceptions (ValueError, TypeError, RuntimeError)
- Propagate errors with context
- Use OpenTelemetry spans for error tracking in async handlers
- Handle `asyncio.CancelledError` explicitly in cleanup code
- Use `try/finally` for resource cleanup

### Async Patterns
- Use `asyncio.create_task()` for background tasks
- Name tasks using the `name=` parameter
- Always await cleanup in `stop()` methods
- Handle `CancelledError` gracefully in long-running tasks
- Use `asyncio.Queue` for event passing

### Registration Pattern
- Use decorators for plugin registration:
  - `@register_source_spec("type")` for source specs
  - `@register_source_factory("type")` for source factories  
  - `@register_action("type")` for action models
  - `@register_action_handler("type")` for action handlers

### Module Exports
- Define `__all__` in each module's `__init__.py`
- Keep `__all__` explicit and up-to-date

### Configuration
- Use Pydantic models for all config structures
- Support flexible input via `from_user_value()` classmethods
- Use environment variable expansion via `expand_pattern()`

## Key Dependencies

- **FastAPI** - Web framework
- **Typer** - CLI framework
- **Pydantic v2** - Data validation
- **paho-mqtt** - MQTT client
- **SQLAlchemy** - Database ORM
- **Jinja2** - Template rendering
- **OpenTelemetry** - Distributed tracing
- **python-fasthtml** - HTML rendering

## Plugin Development

### Adding a New Source

1. Create spec class inheriting from `SourceSpec`:
```python
@register_source_spec("my_source")
class MySourceSpec(SourceSpec):
    type: Literal["my_source"] = "my_source"
    # additional fields
```

2. Create source class inheriting from `Source`:
```python
class MySource(Source):
    def __init__(self, *, name: str, ...):
        super().__init__(name=name, type="my_source")
    
    async def run(self) -> None:
        # Implementation
        pass
```

3. Register factory:
```python
@register_source_factory("my_source")
def create_my_source(spec: SourceSpec, deps: Any) -> MySource:
    return MySource(...)
```

### Adding a New Action

1. Create action model:
```python
@register_action("my.action")
class MyAction(Action):
    type: Literal["my.action"] = "my.action"
    # fields
```

2. Create handler:
```python
@register_action_handler("my.action")
async def handle_my_action(action: MyAction, ctx: dict[str, Any]) -> None:
    # Implementation
    pass
```

## Testing Notes

- Project now has basic test suite in `tests/` directory
- Use pytest fixtures for dependencies (see `conftest.py`)
- Mock external services (MQTT, databases)
- Test both success and error paths
- Run `pytest` to execute all tests
- Run `pytest tests/test_config.py -v` for verbose output

## See Also

- [DEVELOPMENT.md](docs/DEVELOPMENT.md) - Detailed development patterns and feature documentation
- [README.md](README.md) - Project overview and setup
