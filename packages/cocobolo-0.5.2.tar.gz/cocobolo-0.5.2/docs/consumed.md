# Consumed Items Tracking

The "Consumed" feature allows you to track when consumable items (like water filters, air filters, etc.) are replaced. Similar to Events, it stores a timestamp in the database when you click a button or run a CLI command.

## Setup

### 1. Create Database Table

Run this SQL to create the `consumed` table in your SQLite database:

```sql
CREATE TABLE consumed (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    ts REAL NOT NULL,
    payload TEXT
);
```

### 2. Add Consumed Items to Config

Add a `consumed` section to your `config.json`:

```json
{
  "consumed": [
    "waterfilter",
    {
      "name": "airfilter",
      "title": "Air Filter",
      "description": "Replace the HVAC air filter"
    },
    {
      "name": "coffee-filter",
      "title": "Coffee Filter",
      "color": "#8B4513",
      "color_dark": "#A0522D"
    }
  ]
}
```

**Supported fields:**
- `name` (required): Item identifier
- `title` (optional): Display name (defaults to `name`)
- `description` (optional): Tooltip/hover text
- `color` (optional): Button background color (light mode)
- `color_dark` (optional): Button background color (dark mode)
- `css` (optional): Additional CSS (light mode)
- `css_dark` (optional): Additional CSS (dark mode)

### 3. Add Route to Store Consumption

Add a route to your `config.json` to store consumption records in the database:

```json
{
  "routes": [
    {
      "pattern": "consumed/+",
      "actions": [
        {
          "type": "db.insert",
          "table": "consumed",
          "fields": {
            "name": "{{ event.topic.split('/')[-1] }}",
            "ts": "sql:julianday('now')",
            "payload": "{{ event.payload | tojson }}"
          }
        }
      ]
    }
  ]
}
```

## Usage

### Web UI

Navigate to the **Consumables** page in the web UI. You'll see buttons for each configured item. Click a button to record that the item was replaced.

The **Consumption History** page shows when each item was last recorded.

### CLI

```bash
# List available consumable items
cocobolo consumed --list

# Record that an item was replaced
cocobolo consumed waterfilter

# Preview what would be sent (dry run)
cocobolo consumed waterfilter --dry-run
```

## How It Works

1. When you click a button in the web UI or run the CLI command, an MQTT message is published to `consumed/{item-name}`
2. The Cocobolo router receives the message via the `consumed/+` pattern
3. The `db.insert` action stores the record in the `consumed` table with the current timestamp
4. The web UI displays the history from this table

## Database Schema

| Column | Type | Description |
|--------|------|-------------|
| `id` | INTEGER | Auto-incrementing primary key |
| `name` | TEXT | Name of the consumed item |
| `ts` | REAL | Julian day timestamp |
| `payload` | TEXT | JSON payload (usually empty `{}`) |

## Comparison with Events

| Feature | Events | Consumed |
|---------|--------|----------|
| MQTT Topic | `event/{name}` | `consumed/{name}` |
| Database Table | `events` | `consumed` |
| Purpose | General notifications | Track item replacements |
| Web UI Page | Events | Consumables |
| History Page | History | Consumption History |
| CLI Command | `cocobolo event` | `cocobolo consumed` |
