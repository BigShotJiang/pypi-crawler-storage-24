# Command Execution Tracking

This document describes the distributed command tracking architecture in Cocobolo, where worker nodes execute commands and publish status via MQTT, while central nodes listen and store execution history in a database.

## Architecture Overview

```
┌─────────────────┐     MQTT: cmd/pi1/start/radio1      ┌──────────────────┐
│   User/Admin    │ ───────────────────────────────────> │   Worker Node    │
│  (mosquitto_pub)│                                    │   (pi1)          │
└─────────────────┘                                    └──────────────────┘
                                                              │
                                                              │ Process starts
                                                              ▼
┌─────────────────┐     MQTT: status/cmd/pi1/started  ┌──────────────────┐
│  Central Node   │ <────────────────────────────────── │   Worker Node    │
│  (with database)│     {pid, argv, groups, ...}       │   Publishes      │
└─────────────────┘                                    └──────────────────┘
                                                              │
                                                              │ Process ends
                                                              ▼
┌─────────────────┐     MQTT: status/cmd/pi1/finished ┌──────────────────┐
│  Central Node   │ <────────────────────────────────── │   Worker Node    │
│  (with database)│     {pid, returncode, ...}         │   Publishes      │
└─────────────────┘                                    └──────────────────┘
```

### Worker Nodes

Worker nodes receive commands via MQTT and execute them. They automatically publish command lifecycle events to MQTT topics:

- **`status/cmd/{host}/started`** - When a command begins execution
- **`status/cmd/{host}/finished`** - When a command exits successfully (returncode = 0)
- **`status/cmd/{host}/crashed`** - When a command fails (returncode ≠ 0)
- **`status/cmd/{host}/stopped`** - When a command is terminated via `exec.stop`

These are **default routes** added automatically when an MQTT source is configured. You don't need to configure them manually.

### Central Node

The central node listens to command status messages from all worker nodes and inserts records into a database for tracking and monitoring.

## Database Schema

### Commands Table

```sql
CREATE TABLE commands (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    pid INTEGER,
    command TEXT,
    command_name TEXT,  -- Command identifier (e.g., "radio1")
    cmd_group TEXT,
    host TEXT,
    ts REAL,  -- Julian date, consistent with heartbeat table
    status TEXT,  -- 'running', 'finished', 'crashed', 'stopped'
    returncode INTEGER
);

-- Indexes for efficient queries
CREATE INDEX idx_commands_host_pid ON commands(host, pid);
CREATE INDEX idx_commands_ts ON commands(ts);
CREATE INDEX idx_commands_status ON commands(status);
```

### Heartbeat Table (existing)

```sql
CREATE TABLE heartbeat (
    id INTEGER PRIMARY KEY,
    host TEXT,
    ts REAL,
    utilization REAL,
    temperature REAL,
    uptime REAL
);
```

## Event Flow

### 1. Command Start

**Worker Node publishes to:** `status/cmd/{host}/started`

**Payload:**
```json
{
  "pid": 1234,
  "argv": ["mplayer", "https://icecast.omroep.nl/radio1-bb-mp3"],
  "groups": ["audio", "radio"],
  "command_name": "radio1"
}
```

**Central Node Configuration:**
```json
{
  "source": "mqtt",
  "pattern": "status/cmd/+/started",
  "actions": [
    {
      "type": "db.insert",
      "table": "commands",
      "fields": {
        "pid": "{{ event.payload.pid }}",
        "command": "{{ event.payload.argv | join(' ') }}",
        "command_name": "{{ event.payload.command_name }}",
        "cmd_group": "{{ event.payload.groups[0] }}",
        "host": "{{ event.topic.split('/')[1] }}",
        "ts": "sql:julianday('now')",
        "status": "running"
      }
    }
  ]
}
```

### 2. Command Finish

**Worker Node publishes to:** `status/cmd/{host}/finished`

**Payload:**
```json
{
  "pid": 1234,
  "argv": ["mplayer", "https://..."],
  "groups": ["audio"],
  "returncode": 0,
  "status": "success"
}
```

**Central Node Configuration:**
```json
{
  "source": "mqtt",
  "pattern": "status/cmd/+/finished",
  "actions": [
    {
      "type": "db.insert",
      "table": "commands",
      "fields": {
        "pid": "{{ event.payload.pid }}",
        "host": "{{ event.topic.split('/')[1] }}",
        "ts": "sql:julianday('now')",
        "status": "finished",
        "returncode": "{{ event.payload.returncode }}"
      }
    }
  ]
}
```

### 3. Command Crash

**Worker Node publishes to:** `status/cmd/{host}/crashed`

**Payload:**
```json
{
  "pid": 1234,
  "argv": ["mplayer", "https://..."],
  "groups": ["audio"],
  "returncode": 1,
  "status": "failed"
}
```

**Central Node Configuration:**
```json
{
  "source": "mqtt",
  "pattern": "status/cmd/+/crashed",
  "actions": [
    {
      "type": "db.insert",
      "table": "commands",
      "fields": {
        "pid": "{{ event.payload.pid }}",
        "host": "{{ event.topic.split('/')[1] }}",
        "ts": "sql:julianday('now')",
        "status": "crashed",
        "returncode": "{{ event.payload.returncode }}"
      }
    }
  ]
}
```

### 4. Command Stop

**Worker Node publishes to:** `status/cmd/{host}/stopped`

**Payload:**
```json
{
  "pid": 1234,
  "argv": ["mplayer", "https://..."],
  "groups": ["audio"],
  "returncode": -15,
  "status": "stopped"
}
```

**Central Node Configuration:**
```json
{
  "source": "mqtt",
  "pattern": "status/cmd/+/stopped",
  "actions": [
    {
      "type": "db.insert",
      "table": "commands",
      "fields": {
        "pid": "{{ event.payload.pid }}",
        "host": "{{ event.topic.split('/')[1] }}",
        "ts": "sql:julianday('now')",
        "status": "stopped"
      }
    }
  ]
}
```

## Configuration Examples

### Central Node Configuration

See `config-exec.json` for a complete example. The central node needs routes for all command lifecycle events:

```json
{
  "server": "http://localhost:15315/",
  "database": "~/cocobolo.db",
  "routes": [
    {
      "source": "mqtt",
      "pattern": "status/cmd/+/started",
      "actions": [
        {
          "type": "db.insert",
          "table": "commands",
          "fields": {
            "pid": "{{ event.payload.pid }}",
            "command": "{{ event.payload.argv | join(' ') }}",
            "command_name": "{{ event.payload.command_name }}",
            "cmd_group": "{{ event.payload.groups[0] }}",
            "host": "{{ event.topic.split('/')[1] }}",
            "ts": "sql:julianday('now')",
            "status": "running"
          }
        }
      ]
    },
    {
      "source": "mqtt",
      "pattern": "status/cmd/+/finished",
      "actions": [
        {
          "type": "db.insert",
          "table": "commands",
          "fields": {
            "pid": "{{ event.payload.pid }}",
            "host": "{{ event.topic.split('/')[1] }}",
            "ts": "sql:julianday('now')",
            "status": "finished",
            "returncode": "{{ event.payload.returncode }}"
          }
        }
      ]
    },
    {
      "source": "mqtt",
      "pattern": "status/cmd/+/crashed",
      "actions": [
        {
          "type": "db.insert",
          "table": "commands",
          "fields": {
            "pid": "{{ event.payload.pid }}",
            "host": "{{ event.topic.split('/')[1] }}",
            "ts": "sql:julianday('now')",
            "status": "crashed",
            "returncode": "{{ event.payload.returncode }}"
          }
        }
      ]
    },
    {
      "source": "mqtt",
      "pattern": "status/cmd/+/stopped",
      "actions": [
        {
          "type": "db.insert",
          "table": "commands",
          "fields": {
            "pid": "{{ event.payload.pid }}",
            "host": "{{ event.topic.split('/')[1] }}",
            "ts": "sql:julianday('now')",
            "status": "stopped"
          }
        }
      ]
    },
    {
      "pattern": "heartbeat/#",
      "actions": [
        {
          "type": "mqtt.publish",
          "topic": "status/heartbeat"
        }
      ]
    },
    {
      "pattern": "status/heartbeat",
      "actions": [
        {
          "type": "db.insert",
          "fields": {
            "host": "{{ event.payload.host }}",
            "temperature": "{{ event.payload.cpu.temperature }}",
            "uptime": "{{ event.payload.uptime }}",
            "ts": "sql:julianday('{{ event.payload.time }}')",
            "utilization": "{{ event.payload.cpu.utilization }}"
          },
          "table": "heartbeat"
        }
      ]
    }
  ],
  "sources": [
    {
      "type": "mqtt",
      "broker": {
        "host": "mqtt.example.com",
        "port": 1883,
        "username": "central",
        "password": "secret"
      },
      "qos": 1
    },
    {
      "type": "heartbeat"
    }
  ]
}
```

**Note:** MQTT subscriptions (`cmd/#`, `status/#`, `event/#`) are added automatically when an MQTT source is configured.

**Note for Central Nodes:** When `server: true` and `database` are configured, the following database insert routes are also added automatically (no need to include them in config):
- `status/cmd/+/started` → `db.insert` into `commands` table
- `status/cmd/+/finished` → `db.insert` into `commands` table  
- `status/cmd/+/crashed` → `db.insert` into `commands` table
- `status/cmd/+/stopped` → `db.insert` into `commands` table
- `status/heartbeat` → `db.insert` into `heartbeat` table

### Worker Node Configuration

Worker nodes need minimal configuration - just the commands they can execute and MQTT broker settings:

```json
{
  "commands": [
    {
      "name": "radio1",
      "title": "Radio 1",
      "argv": ["mplayer", "https://icecast.omroep.nl/radio1-bb-mp3"],
      "groups": ["audio"]
    }
  ],
  "sources": [
    {
      "type": "mqtt",
      "broker": {
        "host": "mqtt.example.com",
        "port": 1883,
        "username": "worker",
        "password": "secret"
      },
      "qos": 1
    }
  ]
}
```

The default routes for publishing command lifecycle events are added automatically when MQTT is configured.

## Usage Examples

### Starting a Command

```bash
mosquitto_pub -t "cmd/pi1/start/radio1" -m '{}'
```

This will:
1. Worker node `pi1` starts the `radio1` command
2. Publishes `cmd/pi1/started` with command details
3. Central node inserts record with `status = 'running'`
4. When command finishes, publishes `cmd/pi1/finished`
5. Central node updates record with final status

### Stopping a Command

```bash
mosquitto_pub -t "cmd/pi1/stop/audio" -m '{}'
```

This will:
1. Stop the command in the `audio` group on `pi1`
2. Publishes `cmd/pi1/stopped` with termination details
3. Central node updates record with `status = 'stopped'`

### Querying Running Commands with Heartbeat

Since each command creates two rows (start and finish), we use a window function to find the most recent command per host+pid and join it with heartbeat data:

```sql
WITH latest_commands AS (
    SELECT 
        s.id,
        s.pid,
        s.command,
        s.cmd_group,
        s.host,
        s.ts as started_at,
        f.ts as finished_at,
        f.status as final_status,
        f.returncode,
        ROW_NUMBER() OVER (PARTITION BY s.host, s.pid ORDER BY s.ts DESC) as rn
    FROM commands s
    LEFT JOIN commands f 
        ON s.pid = f.pid 
        AND s.host = f.host
        AND f.status IN ('finished', 'crashed', 'stopped')
        AND f.ts = (
            SELECT MIN(ts) 
            FROM commands f2 
            WHERE f2.pid = s.pid 
            AND f2.host = s.host 
            AND f2.status IN ('finished', 'crashed', 'stopped')
            AND f2.ts > s.ts
        )
    WHERE s.status = 'running'
)
SELECT 
    id,
    pid,
    command,
    cmd_group,
    host,
    started_at,
    finished_at,
    final_status,
    returncode,
    h.ts as last_heartbeat,
    h.utilization,
    h.temperature
FROM latest_commands c
LEFT JOIN (
    SELECT host, ts, utilization, temperature
    FROM heartbeat h1
    WHERE h1.id = (SELECT MAX(id) FROM heartbeat h2 WHERE h2.host = h1.host)
) h ON c.host = h.host
WHERE rn = 1
ORDER BY started_at DESC;
```

## Dashboard Integration

The dashboard can use this data to show:

1. **Active Commands**: Currently running commands per node
2. **Command History**: Completed commands with duration and exit status
3. **Node Health**: CPU and temperature alongside running commands
4. **Alerts**: Notifications when commands crash

### Example API Query

```python
async def get_running_commands_with_heartbeat(db):
    query = """
    WITH latest_commands AS (
        SELECT 
            s.id,
            s.pid,
            s.command,
            s.cmd_group,
            s.host,
            s.ts as started_at,
            ROW_NUMBER() OVER (PARTITION BY s.host, s.pid ORDER BY s.ts DESC) as rn
        FROM commands s
        WHERE s.status = 'running'
        AND NOT EXISTS (
            SELECT 1 FROM commands f
            WHERE f.pid = s.pid AND f.host = s.host
            AND f.status IN ('finished', 'crashed', 'stopped')
            AND f.ts > s.ts
        )
    )
    SELECT 
        c.pid,
        c.command,
        c.cmd_group,
        c.host,
        c.started_at,
        h.temperature,
        h.utilization,
        (julianday('now') - h.ts) * 24 * 60 * 60 as seconds_since_heartbeat
    FROM latest_commands c
    LEFT JOIN heartbeat h ON c.host = h.host
    WHERE c.rn = 1
    """
    return await db.fetch_all(query)
```

## Implementation Details

### Worker Node Event Emission

The event emission is implemented in `src/cocobolo/actions/plugins/exec.py`:

- **`exec.started`**: Emitted after process creation in `handle_exec_start()`
- **`exec.finished`**: Emitted when process exits with returncode 0 in `_waiter()`
- **`exec.crashed`**: Emitted when process exits with returncode ≠ 0 in `_waiter()`
- **`exec.stopped`**: Emitted when process is terminated via `asyncio.CancelledError` in `_waiter()`

### Default Route Registration

Default routes are automatically added in `src/cocobolo/cli/core/runner.py` when an MQTT source is detected:

**For all nodes with MQTT:**
- Routes that publish to `status/cmd/$host/started`, `status/cmd/$host/finished`, etc. using `mqtt.publish`
- Route that forwards `heartbeat/#` to `status/heartbeat`
- Routes for command execution (`cmd/$host/start/#`, `cmd/all/start/#`, etc.)

**For central nodes (when `server: true` and `database` configured):**
- Routes that insert command status into `commands` table via `db.insert`
- Route that inserts heartbeat data into `heartbeat` table via `db.insert`

The `$host` variable is expanded to the node's hostname using `router.pattern_vars()`.

### Event Payloads

All exec events include the following fields:

- **pid**: Process ID
- **argv**: Command arguments (array)
- **groups**: Associated groups (array)
- **command_name**: Command identifier (for `exec.started` only)
- **returncode**: Exit code (for finished/crashed/stopped events)
- **status**: Status string ("success", "failed", "stopped")

This ensures the central node has all necessary information to track command execution history.
