# Session Summary: Default Routes, Command Tracking, and Web UI Improvements

This document summarizes the changes made during this development session.

## Overview

This session focused on three main areas:
1. Auto-adding default MQTT routes and sources
2. Implementing command execution tracking with lifecycle events
3. Improving the Web UI for command and group management

## 1. Auto-Added Default Routes and Sources

### Implementation

Modified `src/cocobolo/cli/core/runner.py` to automatically add routes and sources when they're not explicitly configured.

#### Heartbeat Source
- Automatically added if no heartbeat source exists in config
- Uses default settings (interval=60s)

#### Default Routes (only when MQTT source exists)

| Pattern | Action | Purpose |
|---------|--------|---------|
| `cmd/$host/start/#` | `exec.start_from_config` | Start commands on specific host |
| `cmd/all/start/#` | `exec.start_from_config` | Start commands on all hosts |
| `cmd/$host/stop/#` | `exec.stop` | Stop group on specific host |
| `cmd/all/stop/#` | `exec.stop` | Stop group on all hosts |
| `heartbeat/#` | `mqtt.publish` | Forward heartbeats to `status/heartbeat` |
| *(source=exec, type=exec.finished)* | `mqtt.publish` | Publish finished events |
| *(source=exec, type=exec.crashed)* | `mqtt.publish` | Publish crash events |
| *(source=exec, type=exec.stopped)* | `mqtt.publish` | Publish stopped events |
| **Central Node Only (auto-added when `server: true` + `database`):** |
| `status/cmd/+/started` | `db.insert` | Insert command start to DB |
| `status/cmd/+/finished` | `db.insert` | Insert command finish to DB |
| `status/cmd/+/crashed` | `db.insert` | Insert command crash to DB |
| `status/cmd/+/stopped` | `db.insert` | Insert command stop to DB |
| `status/heartbeat` | `db.insert` | Insert heartbeat to DB |

### Helper Functions Added

- `_has_route_with_source_and_type()` - Check for existing source+type combinations
- `_has_route_with_pattern()` - Check for existing pattern routes
- `_has_source_of_type()` - Check for existing source types

### New Action: `exec.start_from_config`

Created in `src/cocobolo/actions/plugins/exec.py`:
- Extracts command name from MQTT topic (last segment)
- Looks up command in `config.commands`
- Executes with proper argv, groups, cwd, env, kill_after settings

## 2. Command Execution Tracking

### Event Types

Commands emit three lifecycle event types:

#### `exec.finished`
Emitted when a command exits successfully (returncode = 0).

**Payload:**
```json
{
  "pid": 1234,
  "argv": ["mplayer", "https://..."],
  "groups": ["audio", "radio"],
  "returncode": 0,
  "status": "success",
  "stopped_externally": false
}
```

#### `exec.crashed`
Emitted when a command fails (returncode ≠ 0).

**Payload:**
```json
{
  "pid": 1234,
  "argv": ["mplayer", "https://..."],
  "groups": ["audio"],
  "returncode": 1,
  "status": "failed",
  "stopped_externally": false
}
```

#### `exec.stopped`
Emitted when a command is terminated via `exec.stop`.

**Payload:**
```json
{
  "pid": 1234,
  "argv": ["mplayer", "https://..."],
  "groups": ["audio"],
  "returncode": -15,
  "status": "stopped",
  "stopped_externally": true
}
```

### Database Schema

```sql
CREATE TABLE commands (
    pid INTEGER,
    command TEXT,
    cmd_group TEXT,  -- Note: renamed from 'group' to avoid SQL reserved word
    host TEXT,
    started_at DATETIME,
    finished_at DATETIME,
    status TEXT,  -- 'running', 'finished', 'crashed', 'stopped'
    returncode INTEGER
);
```

See `docs/exec.md` for complete documentation on command execution tracking.

## 3. Web UI Improvements

### Host Selection
- Added "All Hosts" option to the host dropdown
- Selecting "All" sends commands to `cmd/all/{command}` pattern

### Group Configuration

#### New Model: `GroupSpec`

Created in `src/cocobolo/config.py`:

```python
class GroupSpec(BaseModel):
    name: str                    # Group identifier
    title: str | None           # Display name (defaults to name)
    description: str | None     # Tooltip/hover text
    color: str | None           # Button background color (light mode)
    color_dark: str | None      # Button background color (dark mode)
    css: str | None             # Additional CSS (light mode)
    css_dark: str | None        # Additional CSS (dark mode)
```

#### Configuration Format

Groups can be configured as strings or objects:

```json
{
  "groups": [
    "audio",
    {
      "name": "radio",
      "title": "Radio Stations",
      "color": "#ff6b6b",
      "color_dark": "#ee5a5a"
    }
  ]
}
```

### Group Buttons UI

Replaced the Stop dropdown with big button grid:
- Same visual style as command buttons
- Each button shows the group name
- Clicking immediately stops that group
- Supports custom colors and CSS
- Uses the host dropdown selection (including "All Hosts")

### API Updates

#### `/api/commands`
Now returns groups with full specs:
```json
{
  "commands": [...],
  "hosts": [...],
  "groups": [
    {
      "name": "audio",
      "title": "Audio",
      "color": "#4CAF50",
      ...
    }
  ],
  "mqtt_connected": true
}
```

#### `/api/groups/stop`
- Accepts `host: "all"` for broadcasting
- MQTT topic format: `cmd/{host}/stop/{group}`
- Minimal JSON payload: `{}`

#### `/api/commands/send`
- Accepts `host: "all"` for broadcasting
- Publishes to `cmd/{host}/start/{command}` topic

### JavaScript Updates

- `sendCommand(command)` - Now handles "all" host case
- `sendStop(group)` - Now accepts group name parameter
- Success messages updated to show "all hosts" when applicable

## 4. Configuration Changes

### Removed Auto-Generated Command Routes

Previously, each command in `config.commands` generated its own route like `cmd/$host/radio1`. This has been replaced with the single default route `cmd/$host/start/#` that uses `exec.start_from_config` to look up commands dynamically.

### Database Column Rename

Changed `group` to `cmd_group` in:
- `docs/exec.md` - SQL schema and queries
- `src/cocobolo/server/dashboard.py` - Python code accessing the column

## Files Modified

### Core Changes
- `src/cocobolo/cli/core/runner.py` - Auto-add default routes/sources
- `src/cocobolo/actions/plugins/exec.py` - Added `exec.start_from_config` action
- `src/cocobolo/config.py` - Added `GroupSpec` model and `groups` config field

### Web UI Changes
- `src/cocobolo/server/commands.py` - Updated UI with group buttons, "All Hosts" option

### Documentation
- `docs/exec.md` - Command execution tracking (schema, events, queries)

## Usage Examples

### Starting a Command

```bash
# Start on specific host
mosquitto_pub -t "cmd/pi1/radio1" -m "{}"

# Start on all hosts
mosquitto_pub -t "cmd/all/radio1" -m "{}"
```

### Stopping a Group

```bash
# Stop on specific host
mosquitto_pub -t "cmd/pi1/stop/audio" -m "{}"

# Stop on all hosts
mosquitto_pub -t "cmd/all/stop/audio" -m "{}"
```

### Configuring Groups

```json
{
  "groups": [
    "audio",
    {
      "name": "radio",
      "title": "Radio Stations",
      "color": "#4CAF50",
      "description": "Stop all radio stations"
    }
  ]
}
```

## Notes

- YAML users: Quote color values to avoid comment interpretation (e.g., `color: "#111111"` not `color: #111111`)
- All default routes are only added if no explicit route with the same pattern exists
- The heartbeat source is always auto-added if not configured
- Groups are now configured separately from commands (not derived from command groups)

---

# Session Summary 2026-02-12: MQTT Topic Restructure and Distributed Command Tracking

This document summarizes the changes made during this development session.

## Overview

This session focused on three main areas:
1. Restructuring MQTT command topics for better organization
2. Implementing automatic default MQTT subscriptions
3. Building distributed command tracking architecture

## 1. MQTT Topic Restructure

### Command Topics Changed

**Before:**
- `cmd/{host}/{command}` - Start commands (hard to differentiate from stop commands)
- `cmd/{host}/stop/{group}` - Stop commands

**After:**
- `cmd/{host}/start/{command}` - Start commands
- `cmd/{host}/stop/{group}` - Stop commands

This creates a clear hierarchy where the second segment indicates the action type (start/stop).

### Files Modified

- `src/cocobolo/cli/core/runner.py` - Updated default route patterns
- `src/cocobolo/server/commands.py` - Updated API endpoint topics
- `src/cocobolo/actions/plugins/exec.py` - Updated comment
- `docs/exec.md` - Updated documentation
- `config.json` - Updated example route patterns
- `config-exec.json` - Updated example route patterns

## 2. Automatic MQTT Subscriptions

### Default Subscriptions Added

When an MQTT source is configured, these subscriptions are automatically added:
- `cmd/#` - Listen for command control messages
- `status/#` - Listen for status messages
- `event/#` - Listen for event messages

Subscriptions are merged with any user-defined subscriptions.

### Files Modified

- `src/cocobolo/cli/core/runner.py` - Added `DEFAULT_MQTT_SUBSCRIPTIONS` constant and `_ensure_default_mqtt_subscriptions()` function

## 3. Distributed Command Tracking Architecture

### Overview

Implemented a distributed architecture where:
- **Worker Nodes**: Execute commands and publish status via MQTT
- **Central Node**: Listens to status messages and stores in database

### Event Flow

**Worker Node** (where commands run):
1. Receives `cmd/{host}/start/{name}` → starts command
2. Publishes `status/cmd/{host}/started` with command details
3. When command ends → publishes `status/cmd/{host}/finished|crashed|stopped`

**Central Node** (with database):
- Listens to `status/cmd/+/started` → inserts "running" record
- Listens to `status/cmd/+/finished|crashed|stopped` → updates record with final status

### Exec Events

Four lifecycle events are now emitted:

#### `exec.started`
Emitted when a command begins execution.

**Payload:**
```json
{
  "pid": 1234,
  "argv": ["mplayer", "https://..."],
  "groups": ["audio", "radio"],
  "command_name": "radio1"
}
```

**Published to:** `status/cmd/{host}/started`

#### `exec.finished`
Emitted when a command exits successfully (returncode = 0).

**Payload:**
```json
{
  "pid": 1234,
  "argv": ["mplayer", "https://..."],
  "groups": ["audio"],
  "returncode": 0,
  "status": "success"
}
```

**Published to:** `status/cmd/{host}/finished`

#### `exec.crashed`
Emitted when a command fails (returncode ≠ 0).

**Payload:**
```json
{
  "pid": 1234,
  "argv": ["mplayer", "https://..."],
  "groups": ["audio"],
  "returncode": 1,
  "status": "failed"
}
```

**Published to:** `status/cmd/{host}/crashed`

#### `exec.stopped`
Emitted when a command is terminated via `exec.stop`.

**Payload:**
```json
{
  "pid": 1234,
  "argv": ["mplayer", "https://..."],
  "groups": ["audio"],
  "returncode": -15,
  "status": "stopped"
}
```

**Published to:** `status/cmd/{host}/stopped`

### Default Routes for Publishing

These routes are automatically added when an MQTT source is configured:

| Event Type | Publishes To | Purpose |
|------------|--------------|---------|
| `exec.started` | `status/cmd/$host/started` | Report command start |
| `exec.finished` | `status/cmd/$host/finished` | Report successful completion |
| `exec.crashed` | `status/cmd/$host/crashed` | Report command failure |
| `exec.stopped` | `status/cmd/$host/stopped` | Report command termination |

### Files Modified

- `src/cocobolo/actions/plugins/exec.py`:
  - Added `name` field to `ExecStartAction`
  - Added `exec.started` event emission in `handle_exec_start()`
  - Updated `handle_exec_start_from_config()` to pass command name

- `src/cocobolo/cli/core/runner.py`:
  - Added default routes for all four exec events
  - Routes publish to `status/cmd/$host/<state>` topics
  - Include full payload (pid, argv, groups, returncode, status)

- `docs/exec.md`:
  - Completely rewritten to explain distributed architecture
  - Added architecture diagram
  - Documented all event payloads and topics
  - Provided central node configuration examples

- `config-exec.json`:
  - Updated to show central node configuration
  - Added routes for `status/cmd/+/started`, `status/cmd/+/finished`, etc.
  - Shows how to extract host from topic and insert into database

## 4. Topic Organization

### Clean Separation

- **Control topics** (`cmd/{host}/start/{name}`, `cmd/{host}/stop/{group}`) - for commanding nodes
- **Status topics** (`status/cmd/{host}/<state>`, `status/heartbeat`) - for reporting state

### Complete Topic Hierarchy

```
cmd/
  {host}/
    start/{command}     # Start a command
    stop/{group}        # Stop a group

status/
  cmd/{host}/
    started             # Command started
    finished            # Command finished successfully
    crashed             # Command failed
    stopped             # Command was stopped
  heartbeat             # Node heartbeat
```

## Files Modified Summary

### Core Changes
- `src/cocobolo/cli/core/runner.py` - Default routes, MQTT subscriptions
- `src/cocobolo/actions/plugins/exec.py` - Exec events, command tracking
- `src/cocobolo/server/commands.py` - Updated API topics

### Configuration
- `config.json` - Updated example patterns
- `config-exec.json` - Central node configuration example

### Documentation
- `docs/exec.md` - Distributed command tracking documentation
- `docs/session-summary-2026-02-11.md` - This summary

---

# Session Summary 2026-02-12: Command Name Tracking, Dashboard Improvements, and Events Restructure

This document summarizes the changes made during this development session.

## Overview

This session focused on four main areas:
1. Adding command name tracking to database
2. Improving dashboard display for running commands
3. Restructuring events configuration to match commands pattern
4. Web UI label improvements

## 1. Command Name Tracking

### Problem
The commands table stored command details but not the friendly command name (e.g., "radio1"), making it hard to identify running commands in the dashboard.

### Solution
Added `command_name` field to the database and event payloads.

### Changes Made

#### Database Schema Update
Added `command_name` column to commands table:
```sql
CREATE TABLE commands (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    pid INTEGER,
    command TEXT,
    command_name TEXT,  -- NEW: Command identifier (e.g., "radio1")
    cmd_group TEXT,
    host TEXT,
    ts REAL,
    status TEXT,
    returncode INTEGER
);
```

#### Event Payload Update
The `exec.started` event now includes `command_name`:
```json
{
  "pid": 1234,
  "argv": ["mplayer", "https://..."],
  "groups": ["audio"],
  "command_name": "radio1"
}
```

### Files Modified
- `src/cocobolo/cli/core/runner.py` - Added `command_name` field to db.insert for started commands
- `docs/exec.md` - Updated database schema and configuration examples

## 2. Dashboard Improvements

### Running Commands Display

#### Dashboard List View
Changed the main dashboard to show:
- `-` when 0 commands running
- Command name (e.g., "radio1") when exactly 1 command running
- Count (e.g., "3") when multiple commands running

#### Node Detail View
Converted running commands list to a table with columns:
| Name | Started | PID | Command |
|------|---------|-----|---------|
| **radio1** | 5m ago | 1234 | mplayer https://... |

- Command name is bold and blue
- Shows relative time (e.g., "5m ago")
- PID is dimmed with smaller monospace font
- Command truncated to 50 chars

### Files Modified
- `src/cocobolo/server/dashboard.py`:
  - Updated `get_running_commands_count_by_host()` to return command_name when count==1
  - Updated dashboard display logic
  - Rewrote `create_running_commands_section()` as a table
  - Added `command_name` to `get_running_commands()` return value

## 3. Events Configuration Restructure

### Problem
Events were configured as a dictionary with arbitrary keys as names, which:
- Didn't preserve order
- Required a separate `topic_suffix` field
- Was inconsistent with commands configuration

### Solution
Restructured events to match the commands pattern:

#### Before (Dictionary)
```yaml
events:
  e1:
    title: '1'
    topic_suffix: '1'
  brushing_teeth:
    title: brushing teeth
    topic_suffix: brushing-teeth
```

#### After (List)
```yaml
events:
  - e1
  - name: e2
    title: '2'
    color: red
  - name: brushing_teeth
    title: brushing teeth
  - ibuprofen
  - insane
```

### Key Features
- Events are now a list (preserves config file order)
- Can use string shorthand: `- my_event`
- `title` defaults to `name` if not specified
- Topic is generated from event name (spaces → dashes)
- Removed `topic_suffix` field

### Files Modified
- `src/cocobolo/config.py`:
  - Added `name` field to `EventSpec`
  - Removed `topic_suffix` field
  - Added `from_config_value()` classmethod
  - Added `display_title` property
  - Changed `EventsConfig` to list type
  - Added `get_event_spec()` and `get_all_events()` methods
- `src/cocobolo/server/events.py`:
  - Updated to use new list-based structure
  - Generate topic from event name
  - Preserve list order (no sorting)
- `config.yaml` - Updated to new format
- `tests/test_config.py` - Updated tests for new structure

## 4. Web UI Label Improvements

### Commands Page

#### Host Selection
- Changed label from "Target Host" to "Target"
- Placed label and dropdown on same line using flexbox
- Dropdown width: auto (200-300px range) with 15px gap

#### Section Labels
- "Commands" → "Start"
- "Stop Group" → "Stop"

### Files Modified
- `src/cocobolo/server/commands.py`:
  - Changed labels
  - Added CSS for inline form layout
  - Added CSS for host select sizing

## Summary of Changes

### New Features
1. Command names displayed in dashboard (instead of just count)
2. Events preserve config file order
3. Cleaner, more compact web UI labels

### Configuration Changes
- **Events**: Must update from dict to list format
- **No migration needed** for existing databases (new column auto-created)

### Files Modified Summary

#### Core Changes
- `src/cocobolo/cli/core/runner.py` - Command name tracking
- `src/cocobolo/config.py` - Events restructure
- `src/cocobolo/server/dashboard.py` - Dashboard improvements
- `src/cocobolo/server/events.py` - Events API updates
- `src/cocobolo/server/commands.py` - UI label improvements

#### Configuration
- `config.yaml` - Updated events format

#### Documentation
- `docs/exec.md` - Updated schema
- `docs/session-summary.md` - This summary

#### Tests
- `tests/test_config.py` - Updated for events changes
- `tests/conftest.py` - Updated fixtures
