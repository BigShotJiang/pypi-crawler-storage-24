# Development Guide for Cocobolo

This document contains detailed development patterns, configuration examples, and feature documentation for the Cocobolo MQTT router.

## Table of Contents

1. [Dashboard Development](#dashboard-development)
2. [CLI Display Formatting](#cli-display-formatting)
3. [Event System](#event-system)
4. [Database Integration](#database-integration)
5. [UI Development Patterns](#ui-development-patterns)
6. [Configuration Patterns](#configuration-patterns)
7. [Testing](#testing)

---

## Dashboard Development

### Adding Columns with Conditional Styling

The dashboard table uses python-fasthtml with CSS classes for conditional coloring:

```python
# In dashboard_fragment(), determine CSS class based on value
temp_cls = ""
if temperature is not None and status != "offline":
    if temperature > 80:
        temp_cls = "temp-hot"  # Red
    elif temperature >= 60:
        temp_cls = "temp-warm"  # Orange

# Apply class to table cell
ft.ft("td", temp_str, cls=temp_cls)
```

**CSS classes** (defined in app.py style block):
```css
.temp-warm { color: #ff9800; font-weight: 600; }
.temp-hot { color: #f44336; font-weight: 600; }
```

### Offline State Handling

When host is offline (> 2 days), cells should inherit row styling instead of value-based colors:

```python
if status == "offline":
    # Don't apply temperature colors - let row-offline class handle it
    temp_cls = ""
```

---

## CLI Display Formatting

### Rich Table Styling

When using Rich for CLI tables, apply styles selectively:

```python
from ..utils.formatting import get_host_style, get_temp_style

host_style = get_host_style(last_seen)
temp_style = get_temp_style(temperature, last_seen)

# Only color specific columns, not entire row
table.add_row(
    f"[{host_style}]{host}[/{host_style}]",  # Colored
    relative_time,  # No color
    uptime_str,     # No color
    temp_cell if not temp_style else f"[{temp_style}]{temp_cell}[/{temp_style}]",
)
```

---

## Event System

### Event Configuration

Events are defined in config with visual styling support:

```json
{
  "events": {
    "restart_service": {
      "title": "Restart Service",
      "topic_suffix": "system/restart",
      "description": "Trigger a service restart",
      "color": "#e3f2fd",
      "color_dark": "#1565c0",
      "css": "font-weight: bold;",
      "css_dark": "border: 2px solid #64b5f6;"
    }
  }
}
```

**Field priority for colors/CSS:**
- `color_light/dark` → `color` → default
- `css_light/dark` → `css` → ""

### Storing Events in Database

Use `db.insert` action with `event/+` pattern:

```json
{
  "pattern": "event/+",
  "actions": [
    {
      "type": "db.insert",
      "table": "events",
      "fields": {
        "name": "{{ event.topic.split('/')[-1] }}",
        "ts": "sql:julianday('now')",
        "payload": "{{ event.payload | tojson }}"
      }
    }
  ]
}
```

**Required events table schema:**
```sql
CREATE TABLE events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    ts REAL NOT NULL,
    payload TEXT
);
```

### Event UI Components

The events UI uses a responsive button grid instead of dropdowns:

```css
.event-grid {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 15px;
}
.event-button {
    width: 140px;
    height: 140px;
}
```

**Dynamic CSS generation:** Create per-event classes with light/dark mode support:

```css
.event-btn-restart-service {
    background-color: #e3f2fd;
    font-weight: bold;
}
@media (prefers-color-scheme: dark) {
    .event-btn-restart-service {
        background-color: #1565c0;
        border: 2px solid #64b5f6;
    }
}
```

---

## Database Integration

### db.insert Action

Store event data using the db.insert action with template support:

```json
{
  "type": "db.insert",
  "table": "events",
  "fields": {
    "column_name": "{{ event.payload.field }}",
    "timestamp": "sql:julianday('now')",
    "json_data": "{{ event.payload | tojson }}"
  }
}
```

**Special syntax:**
- Use `sql:` prefix for raw SQL expressions (e.g., `sql:julianday('now')`)
- Templates use Jinja2 with `event` variable

---

## UI Development Patterns

### Shared Navigation

All web UI pages share a common navigation bar. Use the shared `create_nav` function from `navigation.py`:

```python
from .navigation import create_nav

# In your route handler
ft.Body(
    create_nav(request, active="your_route_name"),
    # ... rest of page content
)
```

**Navigation items** (defined in `server/navigation.py`):
- Dashboard
- Commands
- Events
- History
- Mails

When adding a new page, update the nav_items list in `navigation.py` only.

### Route Registration Pattern

Server routes are registered in `app.py` using dedicated register functions:

```python
from .dashboard import register_dashboard_routes
from .commands import register_command_routes
from .events import register_event_routes
from .mail_viewer import register_mail_routes

# Register routes
register_dashboard_routes(app_fastapi, db_path=db_path, config=config)
register_command_routes(app_fastapi, db_path=db_path, config=config)
register_event_routes(app_fastapi, db_path=db_path, config=config)
register_mail_routes(app_fastapi, db_path=db_path, config=config)
```

### FastHTML Tips

#### Type Checking with pyright

Run pyright to catch type errors:
```bash
pyright src/cocobolo
pyright tests/
```

Common issues:
- FastHTML Label with `for` attribute needs `# type: ignore`
- Pydantic model validation errors
- Optional field handling

#### Responsive Button Grids

For centered button grids that work with any number of items:

```css
.event-grid {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 15px;
}
.event-button {
    width: 140px;
    height: 140px;
}
```

---

## Configuration Patterns

### Command Configuration

Commands support both string and object forms in the config:

**String form** (display-only, no execution):
```json
{
  "commands": ["command1", "command2"]
}
```

**Object form** (full specification):
```json
{
  "commands": [
    {
      "name": "radio1",
      "title": "Radio 1",
      "argv": ["mplayer", "https://example.com/stream.mp3"],
      "groups": ["audio"],
      "host": "living-room-pi"
    }
  ]
}
```

**Command fields:**
- `name` (required) - Command identifier
- `title` - Display name in UI
- `description` - Tooltip text
- `argv` - Command arguments for execution
- `groups` - Command groups for organizing/stopping
- `host` - Target host for this command. When set, the command runs on this host without requiring manual host selection in the web UI.
- `color` / `color_dark` - Button colors
- `css` / `css_dark` - Custom CSS

**Predefined Host:**
Setting the `host` field on a command is useful for devices tied to specific hosts (like lights). When a command has `host` set:
- Web UI sends the command immediately without requiring host selection
- The API endpoint accepts the host from the command config if not provided in the request

### Time Formatting

Use Julian day for timestamps (like heartbeat table):

```python
# Convert to Julian day for storage
ts = "sql:julianday('{{ event.payload.time }}')"

# Convert back to datetime for display
def julian_to_datetime(jd: float) -> datetime:
    J2000 = 2451545.0
    J2000_DATETIME = datetime(2000, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    days_since_j2000 = jd - J2000
    return J2000_DATETIME + timedelta(days=days_since_j2000)
```

### Event History Display

Show both absolute and relative times:
- **Time column**: ISO UTC format (`2025-02-10T14:30:00Z`)
- **Ago column**: Relative time (`5m ago`)

Remove payload column from display - use hover tooltips if needed.

---

## Testing

### Pytest Configuration

Configure pytest in `pyproject.toml`:
```toml
[tool.pytest.ini_options]
testpaths = ["tests"]
addopts = "-v"
```

### Test Fixtures

Create shared fixtures in `tests/conftest.py`:

```python
@pytest.fixture
def sample_event_spec() -> EventSpec:
    return EventSpec(
        title="Test Event",
        topic_suffix="test/event",
        color="#e3f2fd",
    )

@pytest.fixture
def full_config_dict() -> dict[str, Any]:
    return {
        "database": ":memory:",
        "sources": [],
        "routes": [],
        "events": {
            "test_event": {
                "title": "Test Event",
                "topic_suffix": "test/event",
            }
        },
    }
```

### Writing Config Tests

Test both valid and invalid configurations:

```python
class TestEventSpec:
    def test_create_event_spec(self, sample_event_spec: EventSpec) -> None:
        assert sample_event_spec.title == "Test Event"
        assert sample_event_spec.color == "#e3f2fd"

    def test_create_event_spec_minimal(self) -> None:
        spec = EventSpec(title="Minimal", topic_suffix="test/minimal")
        assert spec.color is None  # Optional fields
```

### Running Tests

```bash
# Run all tests
pytest

# Run specific test file with verbose output
pytest tests/test_config.py -v

# Run specific test
pytest tests/test_config.py::TestEventSpec::test_create_event_spec -v
```

---

## See Also

- [AGENTS.md](AGENTS.md) - Coding guidelines for AI agents
- [README.md](README.md) - Project overview and setup
