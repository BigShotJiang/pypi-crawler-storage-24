from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Optional

import inceptum
import typer

from ...actions.plugins import load as load_actions
from ...config import Config
from ...server.app import run as run_fastapi_server
from ...sources.plugins import load as load_sources
from ..app import app


@app.command()
def serve(
    config: Optional[Path] = typer.Option(
        None,
        "--config",
        "-c",
        exists=True,
        file_okay=True,
        dir_okay=False,
        readable=True,
        resolve_path=True,
        help="Path to the JSON config file.",
    ),
    host: str = typer.Option(
        "127.0.0.1",
        "--host",
        "-h",
        help="Host to bind the server to.",
    ),
    port: int = typer.Option(
        15315,
        "--port",
        "-p",
        help="Port to bind the server to.",
    ),
) -> None:
    """Serve a FastAPI dashboard showing heartbeat data."""
    # Load plugins first so Config validation works properly
    load_sources()
    load_actions()

    # Load configuration
    if config:
        cfg = Config.model_validate_json(config.read_text(encoding="utf-8"))
    else:
        cfg = Config.model_validate(inceptum.config("cocobolo"))

    if not cfg.database:
        typer.echo("Error: No database configured in config file", err=True)
        raise typer.Exit(1)

    db_path = Path(cfg.database).expanduser()
    if not db_path.exists():
        typer.echo(f"Error: Database file not found: {db_path}", err=True)
        raise typer.Exit(1)

    asyncio.run(run_fastapi_server(db_path, cfg, host, port))
