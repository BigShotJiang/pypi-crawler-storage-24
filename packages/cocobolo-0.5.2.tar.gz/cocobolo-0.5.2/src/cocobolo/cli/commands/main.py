from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Optional

import typer

from ...actions.plugins import load as load_actions
from ...sources.plugins import load as load_sources
from ..app import app
from ..core.runner import run


@app.command()
def main(
    config: Optional[Path] = typer.Option(
        None,
        "--config",
        "-c",
        exists=True,
        file_okay=True,
        dir_okay=False,
        readable=True,
        resolve_path=True,
        help="Path to the JSON config file. If omitted, uses the built-in repo config.json location.",
    ),
    no_tracing: bool = typer.Option(
        False,
        "--no-tracing",
        help="Disable tracing (OpenTelemetry). Tracing is enabled by default when configured.",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="Enable verbose output.",
    ),
) -> None:
    load_sources()
    load_actions()
    asyncio.run(run(config, tracing=not no_tracing, verbose=verbose))
