from __future__ import annotations

import asyncio
import json
import socket
from pathlib import Path
from typing import Any, Optional

import inceptum
import typer
from rich.console import Console
from rich.table import Table

from ...actions.plugins import load as load_actions
from ...config import Config
from ...render import render
from ...sources.plugins import load as load_sources
from ...sources.plugins.mqtt import BrokerConfig, MqttBroker
from ..app import app


def _get_mqtt_broker(config: Config) -> BrokerConfig | None:
    """Get MQTT broker config - prefer 'main', else use the only one."""
    mqtt_sources = []
    for source in config.sources:
        if getattr(source, "type", None) == "mqtt":
            mqtt_sources.append(source)

    if not mqtt_sources:
        return None

    # Prefer broker named "main"
    for source in mqtt_sources:
        broker = getattr(source, "broker", None)
        if broker and getattr(broker, "client_id", None) == "main":
            return broker

    # Otherwise use the first one
    return getattr(mqtt_sources[0], "broker", None)


def _parse_params(params: list[str] | None) -> dict[str, Any]:
    """Parse --param key=value into a dictionary."""
    if not params:
        return {}

    result = {}
    for param in params:
        if "=" not in param:
            raise typer.BadParameter(f"Parameter must be in key=value format: {param}")
        key, value = param.split("=", 1)
        # Try to convert to appropriate type
        if value.lower() == "true":
            value = True
        elif value.lower() == "false":
            value = False
        else:
            try:
                if "." in value:
                    value = float(value)
                else:
                    value = int(value)
            except ValueError:
                pass  # Keep as string
        result[key] = value
    return result


def _list_commands(config: Config) -> None:
    """Display available commands in a table."""
    console = Console()
    table = Table(title="Available Commands")
    table.add_column("Name", style="cyan")
    table.add_column("Title", style="green")
    table.add_column("Host", style="yellow")
    table.add_column("Parameters", style="magenta")

    commands = config.get_all_commands()
    if not commands:
        console.print("[yellow]No commands configured.[/yellow]")
        return

    for cmd in commands:
        params = ", ".join(p.name for p in (cmd.parameters or [])) or "-"
        host = cmd.host or "-"
        table.add_row(cmd.name, cmd.display_title, host, params)

    console.print(table)


@app.command()
def start(
    name: Optional[str] = typer.Argument(None, help="Command name to send"),
    host: Optional[str] = typer.Argument(None, help="Target host (or use --all)"),
    all_hosts: bool = typer.Option(
        False, "--all", help="Send to all hosts instead of specific host"
    ),
    list_commands: bool = typer.Option(
        False, "--list", "-l", help="List available commands"
    ),
    params: Optional[list[str]] = typer.Option(
        None,
        "--param",
        "-p",
        help="Parameters in key=value format (can be used multiple times)",
    ),
    dry_run: bool = typer.Option(
        False, "--dry-run", help="Show what would be sent without publishing"
    ),
    config_path: Optional[Path] = typer.Option(
        None,
        "--config",
        "-c",
        exists=True,
        file_okay=True,
        dir_okay=False,
        readable=True,
        resolve_path=True,
        help="Path to the JSON config file.",
    ),
) -> None:
    """Send a command to a host via MQTT."""
    # Load plugins first so Config validation works properly
    load_sources()
    load_actions()

    # Load configuration
    if config_path:
        cfg = Config.model_validate_json(config_path.read_text(encoding="utf-8"))
    else:
        cfg = Config.model_validate(inceptum.config("cocobolo"))

    # Handle list command
    if list_commands:
        _list_commands(cfg)
        return

    # Validate required arguments
    if not name:
        typer.echo("Error: Command name is required (unless using --list)", err=True)
        raise typer.Exit(1)

    # Get command spec (may be None if not in local config)
    cmd_spec = cfg.get_command_spec(name)

    # Determine target host: CLI arg, --all flag, command's predefined host,
    # or current node if command has argv (is_executable)
    if all_hosts:
        target_host = "all"
    elif host:
        target_host = host
    elif cmd_spec and cmd_spec.host:
        target_host = cmd_spec.host
    elif cmd_spec and cmd_spec.is_executable:
        # Command can execute locally, use current node as target
        target_host = socket.gethostname()
    else:
        typer.echo(
            "Error: Either <host> argument, --all flag, or command host config is required",
            err=True,
        )
        raise typer.Exit(1)

    # Get MQTT broker
    broker_config = _get_mqtt_broker(cfg)
    if not broker_config:
        typer.echo("Error: No MQTT broker configured in config", err=True)
        raise typer.Exit(1)

    # Parse parameters
    try:
        user_params = _parse_params(params)
    except typer.BadParameter as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)

    # Build payload
    if cmd_spec is not None and cmd_spec.payload_template:
        # Build context with defaults from parameter definitions
        params_context: dict[str, Any] = {}
        if cmd_spec.parameters:
            for param_def in cmd_spec.parameters:
                param_name = param_def.name
                if param_name in user_params:
                    params_context[param_name] = user_params[param_name]
                elif param_def.default is not None:
                    params_context[param_name] = param_def.default
                else:
                    params_context[param_name] = None
        # Render the payload template with params
        final_payload = render(
            cmd_spec.payload_template, data={"params": params_context}
        )
    else:
        # No template or no cmd_spec, use provided payload or empty dict
        final_payload = user_params if user_params else {}

    # Build topic
    topic = f"cmd/{target_host}/start/{name}"
    payload_bytes = json.dumps(final_payload).encode("utf-8")

    # Dry run mode
    if dry_run:
        console = Console()
        console.print("[bold]Dry Run - Would send:[/bold]")
        console.print(f"  Topic: [cyan]{topic}[/cyan]")
        console.print(f"  Payload: [green]{json.dumps(final_payload)}[/green]")
        return

    # Publish via MQTT
    async def send():
        broker = MqttBroker(config=broker_config)
        broker.start()
        await broker.ready()
        broker.publish(topic, payload_bytes, qos=1)
        broker.stop()

    try:
        asyncio.run(send())
    except Exception as e:
        typer.echo(f"Error sending command: {e}", err=True)
        raise typer.Exit(1)
