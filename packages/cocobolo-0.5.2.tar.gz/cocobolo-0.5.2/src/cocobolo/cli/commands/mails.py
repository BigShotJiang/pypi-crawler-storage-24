from __future__ import annotations

import asyncio
from pathlib import Path
from typing import List, Optional

import inceptum
import typer
from rich import box
from rich.console import Console
from rich.table import Table

from ...actions.plugins import load as load_actions
from ...config import Config
from ...services.mail_service import (
    get_mail,
    list_mails,
)
from ...sources.plugins import load as load_sources
from ..app import app
from ..utils.formatting import format_relative_time


def _load_config(config_path: Optional[Path]) -> Config:
    """Load config with plugins registered."""
    load_sources()
    load_actions()
    if config_path:
        return Config.model_validate_json(config_path.read_text(encoding="utf-8"))
    else:
        return Config.model_validate(inceptum.config("cocobolo"))


def _get_server_url(cfg: Config) -> Optional[str]:
    """Get server URL if configured as a remote endpoint."""
    if isinstance(cfg.server, str):
        return cfg.server.rstrip("/")
    return None


def _get_db_path(cfg: Config) -> Path:
    """Get database path from config."""
    if not cfg.database:
        raise typer.BadParameter("No database configured in config file")

    db_path = Path(cfg.database).expanduser()
    if not db_path.exists():
        raise typer.BadParameter(f"Database file not found: {db_path}")

    return db_path


def _format_mails_table(mails: List[dict], hours: int) -> None:
    """Format and print mails as a Rich table."""
    from datetime import datetime

    console = Console()
    table = Table(
        title=f"Emails (last {hours} hours)",
        box=box.ROUNDED,
        show_header=True,
        header_style="bold",
        padding=(0, 1),
    )
    table.add_column("ID", style="cyan", no_wrap=True, justify="right")
    table.add_column("Subject", style="white")
    table.add_column("From", style="green")
    table.add_column("To", style="blue")
    table.add_column("Att", style="yellow", justify="center")
    table.add_column("Time", style="cyan", no_wrap=True)
    table.add_column("Received", style="magenta")

    for mail in mails:
        received_dt = datetime.fromisoformat(mail["received_at"])
        relative_time = format_relative_time(received_dt)

        # Format exact time as ISO with seconds in UTC
        time_str = received_dt.strftime("%Y-%m-%dT%H:%M:%SZ")

        # Truncate long fields
        subject_str = (mail.get("subject") or "(no subject)")[:40]
        sender_str = (mail.get("sender") or "N/A")[:25]
        recipient_str = (mail.get("recipient") or "N/A")[:25]

        table.add_row(
            str(mail["id"]),
            subject_str,
            sender_str,
            recipient_str,
            str(mail.get("attachment_count", 0)),
            time_str,
            relative_time,
        )

    console.print(table)


def _format_mail_detail(mail: dict, headers_only: bool = False) -> None:
    """Format and print mail details."""
    from datetime import datetime

    received_dt = datetime.fromisoformat(mail["received_at"])

    output = []
    output.append(f"ID: {mail['id']}")
    output.append(f"Filename: {mail['filename']}")
    output.append(f"From: {mail.get('sender') or 'N/A'}")
    output.append(f"To: {mail.get('recipient') or 'N/A'}")
    output.append(f"Subject: {mail.get('subject') or '(no subject)'}")
    output.append(f"Received: {received_dt.isoformat()}")
    output.append(f"Attachments: {mail.get('attachment_count', 0)}")

    if headers_only:
        typer.echo("\n".join(output))
        return

    output.append("")
    output.append("--- Headers ---")
    output.append("")

    # Print all headers
    headers = mail.get("headers", {})
    for key, value in headers.items():
        output.append(f"{key}: {value}")

    output.append("")
    output.append("--- Body ---")
    output.append("")
    output.append(mail.get("body", "(no body)"))

    # List attachments
    attachments = mail.get("attachments", [])
    if attachments:
        output.append("")
        output.append("--- Attachments ---")
        output.append("")
        for attach in attachments:
            output.append(f"  - {attach['filename']} ({attach['content_type']})")

    typer.echo("\n".join(output))


@app.command()
def mails(
    config: Optional[Path] = typer.Option(
        None,
        "--config",
        "-c",
        exists=True,
        file_okay=True,
        dir_okay=False,
        readable=True,
        resolve_path=True,
        help="Path to the JSON config file.",
    ),
    hours: int = typer.Option(
        24,
        "--hours",
        "-h",
        help="Show emails from the last N hours.",
        min=1,
    ),
    limit: int = typer.Option(
        100,
        "--limit",
        "-n",
        help="Maximum number of emails to show.",
        min=1,
        max=1000,
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        "-j",
        help="Output as JSON lines.",
    ),
) -> None:
    """List recent emails from the database."""

    async def run():
        cfg = _load_config(config)
        server_url = _get_server_url(cfg)

        if server_url:
            # Fetch from remote
            import httpx
            import json

            try:
                async with httpx.AsyncClient() as client:
                    response = await client.get(
                        f"{server_url}/api/mails",
                        params={"hours": hours, "limit": limit},
                    )
                    response.raise_for_status()
                    mails_list = response.json()
            except Exception as e:
                typer.echo(f"Error fetching mails from {server_url}: {e}", err=True)
                raise typer.Exit(1)
        else:
            # Use local database
            db_path = _get_db_path(cfg)
            from ...services.mail_service import mail_summary_to_dict

            mails = await list_mails(db_path, hours=hours, limit=limit)
            mails_list = [mail_summary_to_dict(mail) for mail in mails]

        if not mails_list:
            typer.echo("No emails found.")
            return

        if json_output:
            import json

            for mail in mails_list:
                typer.echo(json.dumps(mail))
        else:
            _format_mails_table(mails_list, hours)

    asyncio.run(run())


@app.command()
def mail(
    mail_id: int = typer.Argument(..., help="Email ID to display."),
    config: Optional[Path] = typer.Option(
        None,
        "--config",
        "-c",
        exists=True,
        file_okay=True,
        dir_okay=False,
        readable=True,
        resolve_path=True,
        help="Path to the JSON config file.",
    ),
    raw: bool = typer.Option(
        False,
        "--raw",
        "-r",
        help="Show raw email content (headers + body).",
    ),
    headers_only: bool = typer.Option(
        False,
        "--headers-only",
        help="Show only email headers.",
    ),
) -> None:
    """Show a specific email by ID."""

    async def run():
        cfg = _load_config(config)
        server_url = _get_server_url(cfg)

        if server_url:
            # Fetch from remote
            import httpx

            try:
                if raw:
                    # Get raw email
                    async with httpx.AsyncClient() as client:
                        response = await client.get(
                            f"{server_url}/api/mails/{mail_id}/raw"
                        )
                        response.raise_for_status()
                        typer.echo(response.text)
                        return
                else:
                    # Get email details
                    async with httpx.AsyncClient() as client:
                        response = await client.get(f"{server_url}/api/mails/{mail_id}")
                        response.raise_for_status()
                        mail_detail = response.json()
            except httpx.HTTPStatusError as e:
                if e.response.status_code == 404:
                    raise typer.BadParameter(f"Email with ID {mail_id} not found")
                raise
            except Exception as e:
                typer.echo(f"Error fetching mail from {server_url}: {e}", err=True)
                raise typer.Exit(1)
        else:
            # Use local database
            db_path = _get_db_path(cfg)
            from ...services.mail_service import mail_detail_to_dict

            mail_obj = await get_mail(db_path, mail_id, include_raw=raw)
            if not mail_obj:
                raise typer.BadParameter(f"Email with ID {mail_id} not found")

            if raw:
                if mail_obj.raw_bytes:
                    typer.echo(mail_obj.raw_bytes.decode("utf-8", errors="replace"))
                else:
                    typer.echo("Raw content not available")
                return

            mail_detail = mail_detail_to_dict(mail_obj)

        _format_mail_detail(mail_detail, headers_only=headers_only)

    asyncio.run(run())
