from __future__ import annotations

import asyncio
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Optional

import aiosqlite
import inceptum
import typer
from rich import box
from rich.console import Console
from rich.table import Table

from ...actions.plugins import load as load_actions
from ...config import Config
from ...sources.plugins import load as load_sources
from ..app import app
from ..utils.formatting import (
    format_relative_time,
    format_uptime,
    get_host_style,
    get_temp_style,
)


def _julian_to_datetime(jd: float) -> datetime:
    """Convert Julian day to UTC datetime."""
    J2000 = 2451545.0
    J2000_DATETIME = datetime(2000, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    days_since_j2000 = jd - J2000
    return J2000_DATETIME + timedelta(days=days_since_j2000)


def _render_nodes_table(nodes_data: list[dict[str, Any]]) -> None:
    """Render nodes data as a Rich table."""
    console = Console()
    table = Table(
        title="Nodes",
        box=box.ROUNDED,
        show_header=True,
        header_style="bold",
        padding=(0, 1),
    )
    table.add_column("Host", style="cyan", no_wrap=True)
    table.add_column("Last Seen")
    table.add_column("Uptime")
    table.add_column("Temp", no_wrap=True)

    for node in nodes_data:
        host = node["host"]
        last_seen = node["last_seen"]
        uptime = node.get("uptime")
        temperature = node.get("temperature")

        relative_time = format_relative_time(last_seen)
        uptime_str = format_uptime(uptime) if uptime else "N/A"
        host_style = get_host_style(last_seen)
        temp_style = get_temp_style(temperature, last_seen)

        temp_str = ""
        if temperature is not None:
            temp_str = f"{temperature:.1f}°C"

        temp_cell = temp_str
        if temp_style:
            temp_cell = f"[{temp_style}]{temp_str}[/{temp_style}]"

        table.add_row(
            f"[{host_style}]{host}[/{host_style}]",
            relative_time,
            uptime_str,
            temp_cell,
        )

    console.print(table)


@app.command()
def nodes(
    config: Optional[Path] = typer.Option(
        None,
        "--config",
        "-c",
        exists=True,
        file_okay=True,
        dir_okay=False,
        readable=True,
        resolve_path=True,
        help="Path to the JSON config file.",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        "-j",
        help="Output as JSON lines with raw seconds",
    ),
) -> None:
    """List computers with their last seen time and uptime."""
    # Load plugins first so Config validation works properly
    load_sources()
    load_actions()

    async def list_nodes_remote(url: str) -> list[dict[str, Any]]:
        """Fetch nodes from remote URL."""
        import httpx

        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(url)
                response.raise_for_status()
                return response.json()
        except Exception as e:
            typer.echo(f"Error fetching nodes from {url}: {e}", err=True)
            raise typer.Exit(1)

    async def list_nodes_local(db_path: Path) -> list[dict[str, Any]]:
        """List nodes from local database."""
        async with aiosqlite.connect(str(db_path)) as db:
            # Get latest heartbeat for each host, ordered by uptime (longest first)
            cursor = await db.execute(
                """
                SELECT h1.host, h1.ts, h1.utilization, h1.temperature, h1.uptime
                FROM heartbeat h1
                INNER JOIN (
                    SELECT host, MAX(id) as max_id
                    FROM heartbeat
                    GROUP BY host
                ) h2 ON h1.host = h2.host AND h1.id = h2.max_id
                ORDER BY h1.uptime DESC
                """
            )
            rows = await cursor.fetchall()

            result = []
            for row in rows:
                host, ts, utilization, temperature, uptime = row
                last_seen_dt = _julian_to_datetime(ts)
                now = datetime.now(timezone.utc)
                diff = now - last_seen_dt
                last_seen_seconds = int(diff.total_seconds())
                uptime_seconds = int(uptime) if uptime else None

                result.append(
                    {
                        "host": host,
                        "last_seen": last_seen_seconds,
                        "uptime": uptime_seconds,
                        "temperature": temperature,
                    }
                )

            return result

    async def list_nodes():
        # Load configuration
        if config:
            cfg = Config.model_validate_json(config.read_text(encoding="utf-8"))
        else:
            cfg = Config.model_validate(inceptum.config("cocobolo"))

        # Fetch nodes data
        if isinstance(cfg.server, str):
            nodes_data = await list_nodes_remote(f"{cfg.server.rstrip('/')}/api/nodes")
        else:
            if not cfg.database:
                typer.echo("Error: No database configured in config file", err=True)
                raise typer.Exit(1)

            db_path = Path(cfg.database).expanduser()
            if not db_path.exists():
                typer.echo(f"Error: Database file not found: {db_path}", err=True)
                raise typer.Exit(1)

            nodes_data = await list_nodes_local(db_path)

        if not nodes_data:
            typer.echo("No computers found.")
            return

        if json_output:
            import json

            for node in nodes_data:
                typer.echo(json.dumps(node))
        else:
            _render_nodes_table(nodes_data)

    asyncio.run(list_nodes())
