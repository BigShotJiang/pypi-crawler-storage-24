from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Optional

import inceptum
import typer
from rich.console import Console
from rich.table import Table

from ...actions.plugins import load as load_actions
from ...config import Config
from ...sources.plugins import load as load_sources
from ...sources.plugins.mqtt import BrokerConfig, MqttBroker
from ..app import app


def _get_mqtt_broker(config: Config) -> BrokerConfig | None:
    """Get MQTT broker config - prefer 'main', else use the only one."""
    mqtt_sources = []
    for source in config.sources:
        if getattr(source, "type", None) == "mqtt":
            mqtt_sources.append(source)

    if not mqtt_sources:
        return None

    # Prefer broker named "main"
    for source in mqtt_sources:
        broker = getattr(source, "broker", None)
        if broker and getattr(broker, "client_id", None) == "main":
            return broker

    # Otherwise use the first one
    return getattr(mqtt_sources[0], "broker", None)


def _list_consumed(config: Config) -> None:
    """Display available consumable items in a table."""
    console = Console()
    table = Table(title="Available Consumable Items")
    table.add_column("Name", style="cyan")
    table.add_column("Title", style="green")
    table.add_column("Description", style="yellow")

    items = config.get_all_consumed()
    if not items:
        console.print("[yellow]No consumable items configured.[/yellow]")
        return

    for item in items:
        desc = item.description or "-"
        table.add_row(item.name, item.display_title, desc)

    console.print(table)


@app.command()
def consumed(
    name: Optional[str] = typer.Argument(None, help="Item name to record"),
    list_items: bool = typer.Option(
        False, "--list", "-l", help="List available consumable items"
    ),
    dry_run: bool = typer.Option(
        False, "--dry-run", help="Show what would be sent without publishing"
    ),
    config_path: Optional[Path] = typer.Option(
        None,
        "--config",
        "-c",
        exists=True,
        file_okay=True,
        dir_okay=False,
        readable=True,
        resolve_path=True,
        help="Path to the JSON config file.",
    ),
) -> None:
    """Record that a consumable item was replaced via MQTT."""
    # Load plugins first so Config validation works properly
    load_sources()
    load_actions()

    # Load configuration
    if config_path:
        cfg = Config.model_validate_json(config_path.read_text(encoding="utf-8"))
    else:
        cfg = Config.model_validate(inceptum.config("cocobolo"))

    # Handle list command
    if list_items:
        _list_consumed(cfg)
        return

    # Validate required argument
    if not name:
        typer.echo("Error: Item name is required (unless using --list)", err=True)
        raise typer.Exit(1)

    # Get consumed item spec
    item_spec = cfg.get_consumed_spec(name)
    if not item_spec:
        typer.echo(f"Error: Unknown consumable item: {name}", err=True)
        raise typer.Exit(1)

    # Get MQTT broker
    broker_config = _get_mqtt_broker(cfg)
    if not broker_config:
        typer.echo("Error: No MQTT broker configured in config", err=True)
        raise typer.Exit(1)

    # Build topic
    topic = f"consumed/{item_spec.name.replace(' ', '-')}"
    payload = b"{}"

    # Dry run mode
    if dry_run:
        console = Console()
        console.print("[bold]Dry Run - Would send:[/bold]")
        console.print(f"  Topic: [cyan]{topic}[/cyan]")
        console.print("  Payload: [green]{}[/green]")
        return

    # Publish via MQTT
    async def send():
        broker = MqttBroker(config=broker_config)
        broker.start()
        await broker.ready()
        broker.publish(topic, payload, qos=1)
        broker.stop()

    try:
        asyncio.run(send())
    except Exception as e:
        typer.echo(f"Error recording consumption: {e}", err=True)
        raise typer.Exit(1)
