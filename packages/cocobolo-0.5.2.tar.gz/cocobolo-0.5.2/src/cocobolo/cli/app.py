from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Optional

import typer

from ..actions.plugins import load as load_actions
from ..sources.plugins import load as load_sources

from .core.runner import run


app = typer.Typer(add_completion=False, no_args_is_help=False)


@app.callback(invoke_without_command=True)
def default(
    ctx: typer.Context,
    config: Optional[Path] = typer.Option(
        None,
        "--config",
        "-c",
        file_okay=True,
        dir_okay=False,
        help="Path to the JSON config file.",
    ),
    no_tracing: bool = typer.Option(
        False,
        "--no-tracing",
        help="Disable tracing (OpenTelemetry).",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="Enable verbose output.",
    ),
) -> None:
    """Default to main command if none specified."""
    if ctx.invoked_subcommand is None:
        load_sources()
        load_actions()
        asyncio.run(run(config, tracing=not no_tracing, verbose=verbose))


# Import commands to register them with the app
from .commands import (  # noqa: E402, F401
    command,
    consumed,
    event,
    main,
    mails,
    nodes,
    serve,
    stop,
)
