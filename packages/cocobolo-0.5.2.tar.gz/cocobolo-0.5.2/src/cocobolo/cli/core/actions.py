from __future__ import annotations

from typing import Any, Dict

from ...actions.base import Action
from ...config import CommandSpec


def command_spec_to_action(spec: CommandSpec) -> Action | None:
    """
    Convert a CommandSpec into a *validated* Action instance
    of type exec.start, so router.dispatch can use action.type and handler lookup.

    Returns None if the command is not executable (display-only string command).
    """
    # Skip display-only commands (string commands without argv)
    if not spec.is_executable:
        return None

    action_dict: Dict[str, Any] = {
        "type": "exec.start",
        "argv": spec.argv,
        "kill_after": spec.kill_after,
    }
    if spec.groups is not None:
        action_dict["groups"] = spec.groups
    if spec.cwd is not None:
        action_dict["cwd"] = spec.cwd
    if spec.env is not None:
        action_dict["env"] = spec.env

    # Critical: this returns a concrete Action subclass (ExecStartAction) via registry.
    return Action.model_validate(action_dict)
