from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import inceptum

from ...actions.plugins.db_insert import DbInsertAction
from ...actions.plugins.exec import ExecStartFromConfigAction, ExecStopAction
from ...actions.plugins.mqtt_publish import MqttPublishAction
from ...actions.base import Action
from ...actions.registry import register_action, register_action_handler
from ...config import Config
from ...config import Route as ConfigRoute
from ...opentelemetry import opentelemetry_init
from ...router import Router, Route as RouterRoute
from ...server.app import run as run_fastapi_server
from ...sources.plugins.heartbeat import HeartbeatSourceSpec
from ...sources.registry import get_source_factory

from .deps import Deps

# Default MQTT subscriptions that are always added automatically
DEFAULT_MQTT_SUBSCRIPTIONS = ["cmd/#", "status/#", "event/#", "consumed/#"]

# Track heartbeat data per host for dashboard display
_host_heartbeat_data: dict[str, dict] = {}


@register_action("track_host_started")
class TrackHostStartedAction(Action):
    type: str = "track_host_started"


@register_action_handler("track_host_started")
async def handle_track_host_started(action: TrackHostStartedAction, ctx: dict) -> None:
    """Track heartbeat data including running commands."""
    global _host_heartbeat_data

    event = ctx.get("event")
    if not event:
        return

    payload = event.payload if hasattr(event, "payload") else {}
    host = payload.get("host")

    if not host:
        return

    commands = payload.get("commands", [])

    # Store all relevant heartbeat data for dashboard
    _host_heartbeat_data[host] = {
        "commands": commands,
        "last_seen": datetime.now(timezone.utc).isoformat(),
    }


def _has_route_with_source_and_type(
    config: Config, source: str, event_type: str
) -> bool:
    """Check if any route matches the given source and type."""
    for r in config.routes:
        if r.source == source and r.type == event_type:
            return True
    return False


def _ensure_default_mqtt_subscriptions(config: Config) -> None:
    """Ensure all MQTT sources have default subscriptions."""
    from typing import cast

    from ...sources.plugins.mqtt import MqttSourceSpec

    for s in config.sources:
        if s.type == "mqtt":
            # Cast to MqttSourceSpec to access subscriptions
            mqtt_spec = cast(MqttSourceSpec, s)
            # Get existing subscriptions or initialize empty list
            existing = list(mqtt_spec.subscriptions) if mqtt_spec.subscriptions else []
            # Add default subscriptions that aren't already present
            for sub in DEFAULT_MQTT_SUBSCRIPTIONS:
                if sub not in existing:
                    existing.append(sub)
            mqtt_spec.subscriptions = existing


def _has_route_with_pattern(config: Config, pattern: str) -> bool:
    """Check if any route has the given pattern."""
    for r in config.routes:
        if r.pattern == pattern:
            return True
    return False


def _has_source_of_type(config: Config, source_type: str) -> bool:
    """Check if any source of the given type exists."""
    for s in config.sources:
        if s.type == source_type:
            return True
    return False


async def run(
    config_path: Optional[Path], tracing: bool, verbose: bool = False
) -> None:
    if config_path:
        try:
            with open(config_path, encoding="utf-8") as f:
                config_text = f.read()
        except FileNotFoundError:
            raise FileNotFoundError(f"Config file not found: {config_path}") from None
        except PermissionError:
            raise PermissionError(f"Cannot read config file: {config_path}") from None
        except OSError as e:
            raise OSError(f"Error reading config file {config_path}: {e}") from e
        config = Config.model_validate_json(config_text)
    else:
        config = Config.model_validate(inceptum.config("cocobolo"))

    if tracing and config.opentelemetry:
        opentelemetry_init(config.opentelemetry)

    deps = Deps(config=config)

    router = Router(verbose=verbose, deps=deps)

    # Ensure MQTT sources have default subscriptions
    _ensure_default_mqtt_subscriptions(config)

    # Add sources
    for s in config.sources:
        factory = get_source_factory(s.type)
        if factory is None:
            raise ValueError(f"Unknown source type: {s.type}")
        src = factory(s, deps)
        await router.add_source(src)

    # Auto-add heartbeat source if not configured
    if not _has_source_of_type(config, "heartbeat"):
        heartbeat_spec = HeartbeatSourceSpec(name="heartbeat")
        factory = get_source_factory("heartbeat")
        if factory:
            src = factory(heartbeat_spec, deps)
            await router.add_source(src)

    # Collect all routes (explicit + defaults)
    all_routes: list[ConfigRoute] = list(config.routes)

    # Auto-add default routes for exec events and heartbeat if MQTT is configured
    if _has_source_of_type(config, "mqtt"):
        # Default exec.started route - publishes command start to MQTT
        if not _has_route_with_source_and_type(config, "exec", "exec.started"):
            all_routes.append(
                ConfigRoute(
                    pattern="",
                    actions=[
                        MqttPublishAction(
                            topic="status/cmd/$host/started",
                            payload={
                                "pid": "{{ event.payload.pid }}",
                                "argv": "{{ event.payload.argv }}",
                                "groups": "{{ event.payload.groups }}",
                                "name": "{{ event.payload.name }}",
                            },
                        )
                    ],
                    source="exec",
                    type="exec.started",
                )
            )

        # Default exec.finished route - publishes command completion to MQTT
        if not _has_route_with_source_and_type(config, "exec", "exec.finished"):
            all_routes.append(
                ConfigRoute(
                    pattern="",
                    actions=[
                        MqttPublishAction(
                            topic="status/cmd/$host/finished",
                            payload={
                                "pid": "{{ event.payload.pid }}",
                                "argv": "{{ event.payload.argv }}",
                                "groups": "{{ event.payload.groups }}",
                                "returncode": "{{ event.payload.returncode }}",
                                "status": "{{ event.payload.status }}",
                            },
                        )
                    ],
                    source="exec",
                    type="exec.finished",
                )
            )

        # Default exec.crashed route - publishes command crash to MQTT
        if not _has_route_with_source_and_type(config, "exec", "exec.crashed"):
            all_routes.append(
                ConfigRoute(
                    pattern="",
                    actions=[
                        MqttPublishAction(
                            topic="status/cmd/$host/crashed",
                            payload={
                                "pid": "{{ event.payload.pid }}",
                                "argv": "{{ event.payload.argv }}",
                                "groups": "{{ event.payload.groups }}",
                                "returncode": "{{ event.payload.returncode }}",
                                "status": "{{ event.payload.status }}",
                            },
                        )
                    ],
                    source="exec",
                    type="exec.crashed",
                )
            )

        # Default exec.stopped route - publishes command stop to MQTT
        if not _has_route_with_source_and_type(config, "exec", "exec.stopped"):
            all_routes.append(
                ConfigRoute(
                    pattern="",
                    actions=[
                        MqttPublishAction(
                            topic="status/cmd/$host/stopped",
                            payload={
                                "pid": "{{ event.payload.pid }}",
                                "argv": "{{ event.payload.argv }}",
                                "groups": "{{ event.payload.groups }}",
                                "returncode": "{{ event.payload.returncode }}",
                                "status": "{{ event.payload.status }}",
                            },
                        )
                    ],
                    source="exec",
                    type="exec.stopped",
                )
            )

        # Auto-add db.insert routes for central nodes (server + database configured)
        if config.server is True and config.database:
            # Default db.insert route for started commands
            if not _has_route_with_pattern(config, "status/cmd/+/started"):
                all_routes.append(
                    ConfigRoute(
                        pattern="status/cmd/+/started",
                        actions=[
                            DbInsertAction(
                                table="commands",
                                fields={
                                    "pid": "{{ event.payload.pid }}",
                                    "command": "{{ event.payload.argv | join(' ') }}",
                                    "name": "{{ event.payload.name }}",
                                    "cmd_group": "{{ event.payload.groups[0] }}",
                                    "host": "{{ event.topic.split('/')[2] }}",
                                    "ts": "sql:julianday('now')",
                                    "status": "running",
                                },
                            )
                        ],
                        source=None,
                        type=None,
                    )
                )

            # Default db.insert route for finished commands
            if not _has_route_with_pattern(config, "status/cmd/+/finished"):
                all_routes.append(
                    ConfigRoute(
                        pattern="status/cmd/+/finished",
                        actions=[
                            DbInsertAction(
                                table="commands",
                                fields={
                                    "pid": "{{ event.payload.pid }}",
                                    "host": "{{ event.topic.split('/')[2] }}",
                                    "ts": "sql:julianday('now')",
                                    "status": "finished",
                                    "returncode": "{{ event.payload.returncode }}",
                                },
                            )
                        ],
                        source=None,
                        type=None,
                    )
                )

            # Default db.insert route for crashed commands
            if not _has_route_with_pattern(config, "status/cmd/+/crashed"):
                all_routes.append(
                    ConfigRoute(
                        pattern="status/cmd/+/crashed",
                        actions=[
                            DbInsertAction(
                                table="commands",
                                fields={
                                    "pid": "{{ event.payload.pid }}",
                                    "host": "{{ event.topic.split('/')[2] }}",
                                    "ts": "sql:julianday('now')",
                                    "status": "crashed",
                                    "returncode": "{{ event.payload.returncode }}",
                                },
                            )
                        ],
                        source=None,
                        type=None,
                    )
                )

            # Default db.insert route for stopped commands
            if not _has_route_with_pattern(config, "status/cmd/+/stopped"):
                all_routes.append(
                    ConfigRoute(
                        pattern="status/cmd/+/stopped",
                        actions=[
                            DbInsertAction(
                                table="commands",
                                fields={
                                    "pid": "{{ event.payload.pid }}",
                                    "host": "{{ event.topic.split('/')[2] }}",
                                    "ts": "sql:julianday('now')",
                                    "status": "stopped",
                                },
                            )
                        ],
                        source=None,
                        type=None,
                    )
                )

            # Default db.insert route for heartbeat
            if not _has_route_with_pattern(config, "status/heartbeat"):
                all_routes.append(
                    ConfigRoute(
                        pattern="status/heartbeat",
                        actions=[
                            DbInsertAction(
                                table="heartbeat",
                                fields={
                                    "host": "{{ event.payload.host }}",
                                    "temperature": "{{ event.payload.cpu.temperature }}",
                                    "ts": "sql:julianday('{{ event.payload.time }}')",
                                    "uptime": "{{ event.payload.uptime }}",
                                    "utilization": "{{ event.payload.cpu.utilization }}",
                                },
                            )
                        ],
                        source=None,
                        type=None,
                    )
                )

            # Default db.insert route for events
            if not _has_route_with_pattern(config, "event/+"):
                all_routes.append(
                    ConfigRoute(
                        pattern="event/+",
                        actions=[
                            DbInsertAction(
                                table="events",
                                fields={
                                    "name": "{{ event.topic.split('/')[-1] }}",
                                    "ts": "sql:julianday('now')",
                                    "payload": "{{ event.payload | tojson }}",
                                },
                            )
                        ],
                        source=None,
                        type=None,
                    )
                )

            # Default db.insert route for consumed items
            if not _has_route_with_pattern(config, "consumed/+"):
                all_routes.append(
                    ConfigRoute(
                        pattern="consumed/+",
                        actions=[
                            DbInsertAction(
                                table="consumed",
                                fields={
                                    "name": "{{ event.topic.split('/')[-1] }}",
                                    "ts": "sql:julianday('now')",
                                    "payload": "{{ event.payload | tojson }}",
                                },
                            )
                        ],
                        source=None,
                        type=None,
                    )
                )

        # Default heartbeat route - publishes local heartbeats to MQTT
        if not _has_route_with_pattern(config, "heartbeat/#"):
            all_routes.append(
                ConfigRoute(
                    pattern="heartbeat/#",
                    actions=[
                        MqttPublishAction(topic="status/heartbeat"),
                    ],
                    source=None,
                    type=None,
                )
            )

        # Route to track heartbeats from MQTT (status/heartbeat)
        if not _has_route_with_pattern(config, "status/heartbeat"):
            all_routes.append(
                ConfigRoute(
                    pattern="status/heartbeat",
                    actions=[
                        TrackHostStartedAction(),
                    ],
                    source=None,
                    type=None,
                )
            )

        # Default command start route for specific host
        if not _has_route_with_pattern(config, "cmd/$host/start/#"):
            all_routes.append(
                ConfigRoute(
                    pattern="cmd/$host/start/#",
                    actions=[ExecStartFromConfigAction()],
                    source=None,
                    type=None,
                )
            )

        # Default command start route for all hosts
        if not _has_route_with_pattern(config, "cmd/all/start/#"):
            all_routes.append(
                ConfigRoute(
                    pattern="cmd/all/start/#",
                    actions=[ExecStartFromConfigAction()],
                    source=None,
                    type=None,
                )
            )

        # Default stop route for specific host (group in topic suffix)
        if not _has_route_with_pattern(config, "cmd/$host/stop/#"):
            all_routes.append(
                ConfigRoute(
                    pattern="cmd/$host/stop/#",
                    actions=[ExecStopAction(group="{{ event.topic.split('/')[-1] }}")],
                    source=None,
                    type=None,
                )
            )

        # Default stop route for all hosts (group in topic suffix)
        if not _has_route_with_pattern(config, "cmd/all/stop/#"):
            all_routes.append(
                ConfigRoute(
                    pattern="cmd/all/stop/#",
                    actions=[ExecStopAction(group="{{ event.topic.split('/')[-1] }}")],
                    source=None,
                    type=None,
                )
            )

    # Add all routes to router
    for r in all_routes:
        router.add_route(
            RouterRoute(
                pattern=r.pattern, actions=r.actions, source=r.source, type=r.type
            )
        )

    # Start FastAPI server in background if server is set to True
    server_task = None
    if config.server is True and config.database:
        db_path = Path(config.database).expanduser()
        if db_path.exists():
            server_task = asyncio.create_task(
                run_fastapi_server(db_path, config, host="127.0.0.1", port=15315)
            )

    await router.start()
