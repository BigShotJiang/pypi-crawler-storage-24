from __future__ import annotations

from dataclasses import dataclass

from ...config import Config


@dataclass
class Deps:
    config: Config
