from __future__ import annotations

from datetime import datetime, timezone
from typing import Union


def format_relative_time(value: Union[int, float, datetime]) -> str:
    """Format a datetime or seconds as relative time (e.g., '2 minutes ago')."""
    if isinstance(value, datetime):
        now = datetime.now(timezone.utc)
        diff = now - value
        seconds = diff.total_seconds()
    else:
        seconds = float(value)

    if seconds < 60:
        return f"{int(seconds)}s ago"
    elif seconds < 3600:
        return f"{int(seconds / 60)}m ago"
    elif seconds < 86400:
        return f"{int(seconds / 3600)}h ago"
    elif seconds < 604800:
        return f"{int(seconds / 86400)}d ago"
    else:
        return f"{int(seconds / 604800)}w ago"


def format_uptime(uptime_s: Union[int, float, None]) -> str:
    """Format uptime in seconds to human readable format."""
    if uptime_s is None:
        return "N/A"

    uptime_s = float(uptime_s)
    if uptime_s < 60:
        return f"{int(uptime_s)}s"
    elif uptime_s < 3600:
        return f"{int(uptime_s / 60)}m"
    elif uptime_s < 86400:
        hours = int(uptime_s / 3600)
        mins = int((uptime_s % 3600) / 60)
        return f"{hours}h {mins}m"
    else:
        days = int(uptime_s / 86400)
        hours = int((uptime_s % 86400) / 3600)
        return f"{days}d {hours}h"


def get_row_style(seconds: Union[int, float]) -> str:
    """Get row style based on last seen time in seconds.

    Returns:
        Rich style string: 'green' for < 2 min, 'red' for < 2 days, 'dim' otherwise.
    """
    if seconds < 120:  # < 2 minutes
        return "green"
    elif seconds < 172800:  # < 2 days
        return "red"
    else:
        return "dim"


def get_host_style(seconds: Union[int, float]) -> str:
    """Get host column style based on last seen time in seconds.

    Returns:
        Rich style string: 'green' for < 2 min, 'red' for < 2 days, 'dim' otherwise.
    """
    if seconds < 120:  # < 2 minutes
        return "green"
    elif seconds < 172800:  # < 2 days
        return "red"
    else:
        return "dim"


def get_temp_style(
    temperature: Union[int, float, None], seconds: Union[int, float]
) -> str:
    """Get temperature column style based on temperature value and last seen time.

    Args:
        temperature: Temperature in Celsius, or None if not available.
        seconds: Seconds since last seen.

    Returns:
        Rich style string: 'dark_orange3' for >= 60, 'red' for > 80, 'dim' if offline, '' otherwise.
    """
    if temperature is None:
        return ""

    # If offline (> 2 days), show as dim
    if seconds >= 172800:
        return "dim"

    if temperature > 80:
        return "red"
    elif temperature >= 60:
        return "dark_orange3"
    else:
        return ""
