from __future__ import annotations

import gzip
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from email import policy
from email.message import Message
from email.parser import BytesParser
from pathlib import Path
from typing import Any, List, Optional, Tuple

import html2text
import sqlalchemy as sa
from sqlalchemy.ext.asyncio import create_async_engine


# Import Mail model
from ..sources.plugins.mail import Mail


@dataclass
class MailSummary:
    """Summary of an email for listing."""

    id: int
    filename: str
    received_at: float  # Julian date
    sender: Optional[str]
    recipient: Optional[str]
    subject: Optional[str]
    attachment_count: int


@dataclass
class MailDetail:
    """Full email details with parsed content."""

    id: int
    filename: str
    received_at: float  # Julian date
    sender: Optional[str]
    recipient: Optional[str]
    subject: Optional[str]
    attachment_count: int
    headers: dict[str, str]
    body: str
    attachments: List[dict[str, str]]  # [{filename, content_type}]
    raw_bytes: Optional[bytes] = None  # Only populated when explicitly requested


def julian_to_datetime(jd: float) -> datetime:
    """Convert Julian day to UTC datetime."""
    J2000 = 2451545.0
    J2000_DATETIME = datetime(2000, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    days_since_j2000 = jd - J2000
    return J2000_DATETIME + timedelta(days=days_since_j2000)


def datetime_to_julian(dt: datetime) -> float:
    """Convert UTC datetime to Julian day."""
    J2000 = 2451545.0
    J2000_DATETIME = datetime(2000, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    days_since_j2000 = (dt - J2000_DATETIME).total_seconds() / 86400
    return J2000 + days_since_j2000


async def list_mails(
    db_path: Path,
    hours: int = 24,
    limit: int = 100,
) -> List[MailSummary]:
    """List emails from the last N hours."""
    db_url = f"sqlite+aiosqlite:///{db_path}"
    engine = create_async_engine(db_url, future=True)

    # Calculate Julian date cutoff
    cutoff_dt = datetime.now(timezone.utc) - timedelta(hours=hours)
    cutoff_jd = datetime_to_julian(cutoff_dt)

    try:
        async with engine.connect() as conn:
            result = await conn.execute(
                sa.select(Mail)
                .where(Mail.received_at >= cutoff_jd)
                .where(~Mail.recipient.contains("hgremmen@xs4all.nl"))
                .order_by(Mail.received_at.desc())
                .limit(limit)
            )
            rows = result.all()
    finally:
        await engine.dispose()

    mails = []
    for row in rows:
        (
            mail_id,
            filename,
            received_at,
            sender,
            recipient,
            subject,
            attachment_count,
            raw,
        ) = row
        mails.append(
            MailSummary(
                id=mail_id,
                filename=filename,
                received_at=received_at,
                sender=sender,
                recipient=recipient,
                subject=subject,
                attachment_count=attachment_count,
            )
        )

    return mails


async def get_mail(
    db_path: Path,
    mail_id: int,
    include_raw: bool = False,
) -> Optional[MailDetail]:
    """Get a specific email by ID with parsed content."""
    db_url = f"sqlite+aiosqlite:///{db_path}"
    engine = create_async_engine(db_url, future=True)

    try:
        async with engine.connect() as conn:
            result = await conn.execute(sa.select(Mail).where(Mail.id == mail_id))
            row = result.first()
    finally:
        await engine.dispose()

    if not row:
        return None

    # Row is a tuple: (id, filename, received_at, sender, recipient, subject, attachment_count, raw)
    (
        mail_id_val,
        filename,
        received_at,
        sender,
        recipient,
        subject,
        attachment_count,
        raw_data,
    ) = row

    # Decompress the raw email
    try:
        raw_bytes = gzip.decompress(raw_data)
    except Exception:
        return None

    # Parse the email
    try:
        msg: Message = BytesParser(policy=policy.default).parsebytes(raw_bytes)
    except Exception:
        return None

    # Extract headers
    headers = {key: value for key, value in msg.items()}

    # Extract body
    body = ""
    html_body = ""
    if msg.is_multipart():
        # First: look for text/plain
        for part in msg.walk():
            if part.get_content_type() == "text/plain":
                try:
                    body = part.get_content()
                    break
                except Exception:
                    continue
        # Second: if no plain text, look for text/html and convert
        if not body:
            for part in msg.walk():
                if part.get_content_type() == "text/html":
                    try:
                        html_body = part.get_content()
                        break
                    except Exception:
                        continue
            if html_body:
                # Convert HTML to plain text
                h = html2text.HTML2Text()
                h.ignore_links = False
                h.ignore_images = True
                h.ignore_emphasis = False
                h.body_width = 0  # No wrapping
                body = h.handle(html_body)
            else:
                body = "(multipart message - no text content found)"
    else:
        # Single part message
        content_type = msg.get_content_type()
        try:
            content = msg.get_content()
            if content_type == "text/html":
                # Convert HTML to plain text
                h = html2text.HTML2Text()
                h.ignore_links = False
                h.ignore_images = True
                h.ignore_emphasis = False
                h.body_width = 0  # No wrapping
                body = h.handle(content)
            elif content_type == "text/plain":
                body = content
            else:
                body = f"(unsupported content type: {content_type})"
        except Exception as e:
            body = f"(could not extract body: {e})"

    # Extract attachments
    attachments = []
    for part in msg.walk():
        if part.get_content_disposition() == "attachment":
            attach_filename = part.get_filename() or "(unnamed)"
            content_type = part.get_content_type()
            attachments.append(
                {"filename": attach_filename, "content_type": content_type}
            )

    return MailDetail(
        id=mail_id_val,
        filename=filename,
        received_at=received_at,
        sender=sender,
        recipient=recipient,
        subject=subject,
        attachment_count=attachment_count,
        headers=headers,
        body=body,
        attachments=attachments,
        raw_bytes=raw_bytes if include_raw else None,
    )


async def get_mail_attachment(
    db_path: Path,
    mail_id: int,
    attachment_index: int,
) -> Optional[Tuple[str, bytes, str]]:
    """
    Get a specific attachment from an email.

    Returns:
        Tuple of (filename, content_bytes, content_type) or None if not found.
    """
    db_url = f"sqlite+aiosqlite:///{db_path}"
    engine = create_async_engine(db_url, future=True)

    try:
        async with engine.connect() as conn:
            result = await conn.execute(sa.select(Mail).where(Mail.id == mail_id))
            row = result.first()
    finally:
        await engine.dispose()

    if not row:
        return None

    # Get raw bytes
    raw_data = row[7]  # raw column
    try:
        raw_bytes = gzip.decompress(raw_data)
    except Exception:
        return None

    # Parse and find attachment
    try:
        msg: Message = BytesParser(policy=policy.default).parsebytes(raw_bytes)
    except Exception:
        return None

    # Find the Nth attachment
    current_index = 0
    for part in msg.walk():
        if part.get_content_disposition() == "attachment":
            if current_index == attachment_index:
                filename = part.get_filename() or "unnamed"
                content_type = part.get_content_type()
                try:
                    _content: Any = part.get_payload(decode=True)
                    if _content is None:
                        return None
                    if isinstance(_content, str):
                        _content = _content.encode("utf-8")
                    elif not isinstance(_content, bytes):
                        return None
                    return filename, _content, content_type
                except Exception:
                    return None
            current_index += 1

    return None


def mail_summary_to_dict(mail: MailSummary) -> dict[str, Any]:
    """Convert MailSummary to dict for JSON serialization."""
    received_dt = julian_to_datetime(mail.received_at)
    return {
        "id": mail.id,
        "filename": mail.filename,
        "sender": mail.sender,
        "recipient": mail.recipient,
        "subject": mail.subject,
        "attachment_count": mail.attachment_count,
        "received_at": received_dt.isoformat(),
    }


def mail_detail_to_dict(mail: MailDetail, include_raw: bool = False) -> dict[str, Any]:
    """Convert MailDetail to dict for JSON serialization."""
    received_dt = julian_to_datetime(mail.received_at)
    result = {
        "id": mail.id,
        "filename": mail.filename,
        "sender": mail.sender,
        "recipient": mail.recipient,
        "subject": mail.subject,
        "attachment_count": mail.attachment_count,
        "received_at": received_dt.isoformat(),
        "headers": mail.headers,
        "body": mail.body,
        "attachments": mail.attachments,
    }
    if include_raw and mail.raw_bytes:
        # Return raw as base64 encoded string
        import base64

        result["raw"] = base64.b64encode(mail.raw_bytes).decode("ascii")
    return result


async def get_mail_html_body(
    db_path: Path,
    mail_id: int,
) -> tuple[str | None, Message | None]:
    """
    Get the raw HTML body from an email.

    Returns:
        Tuple of (html_content, parsed_message) or (None, None) if not found.
        The parsed_message is returned so inline images can be extracted later.
    """
    db_url = f"sqlite+aiosqlite:///{db_path}"
    engine = create_async_engine(db_url, future=True)

    try:
        async with engine.connect() as conn:
            result = await conn.execute(sa.select(Mail).where(Mail.id == mail_id))
            row = result.first()
    finally:
        await engine.dispose()

    if not row:
        return None, None

    # Get raw bytes
    raw_data = row[7]  # raw column
    try:
        raw_bytes = gzip.decompress(raw_data)
    except Exception:
        return None, None

    # Parse the email
    try:
        msg: Message = BytesParser(policy=policy.default).parsebytes(raw_bytes)
    except Exception:
        return None, None

    # Extract HTML body
    html_body = ""
    if msg.is_multipart():
        for part in msg.walk():
            if part.get_content_type() == "text/html":
                try:
                    html_body = part.get_content()
                    break
                except Exception:
                    continue
    else:
        content_type = msg.get_content_type()
        if content_type == "text/html":
            try:
                html_body = msg.get_content()
            except Exception:
                pass

    return html_body if html_body else None, msg


async def get_mail_inline_image(
    db_path: Path,
    mail_id: int,
    content_id: str,
) -> Optional[Tuple[str, bytes, str]]:
    """
    Get an inline image by Content-ID.

    Args:
        content_id: The Content-ID (with or without angle brackets)

    Returns:
        Tuple of (filename, content_bytes, content_type) or None if not found.
    """
    # Normalize content_id (remove angle brackets if present)
    cid = content_id.strip()
    if cid.startswith("<") and cid.endswith(">"):
        cid = cid[1:-1]

    db_url = f"sqlite+aiosqlite:///{db_path}"
    engine = create_async_engine(db_url, future=True)

    try:
        async with engine.connect() as conn:
            result = await conn.execute(sa.select(Mail).where(Mail.id == mail_id))
            row = result.first()
    finally:
        await engine.dispose()

    if not row:
        return None

    # Get raw bytes
    raw_data = row[7]  # raw column
    try:
        raw_bytes = gzip.decompress(raw_data)
    except Exception:
        return None

    # Parse the email
    try:
        msg: Message = BytesParser(policy=policy.default).parsebytes(raw_bytes)
    except Exception:
        return None

    # Find the part with matching Content-ID
    for part in msg.walk():
        part_cid = part.get("Content-ID", "")
        if part_cid:
            # Normalize
            part_cid = part_cid.strip()
            if part_cid.startswith("<") and part_cid.endswith(">"):
                part_cid = part_cid[1:-1]

            if part_cid == cid:
                filename = part.get_filename() or f"inline-{cid[:8]}.bin"
                content_type = part.get_content_type()
                try:
                    _content: Any = part.get_payload(decode=True)
                    if _content is None:
                        return None
                    if isinstance(_content, str):
                        _content = _content.encode("utf-8")
                    elif not isinstance(_content, bytes):
                        return None
                    return filename, _content, content_type
                except Exception:
                    return None

    return None


def build_cid_map(
    msg: Message,
    base_url: str,
) -> dict[str, str]:
    """
    Build a mapping of Content-ID to URL for inline images.

    Args:
        msg: Parsed email message
        base_url: Base URL for inline image endpoints (e.g., '/mails/123/inline/')

    Returns:
        Dictionary mapping CID (without angle brackets) to URL
    """
    cid_map = {}

    for part in msg.walk():
        part_cid = part.get("Content-ID", "")
        if part_cid:
            # Normalize
            part_cid = part_cid.strip()
            if part_cid.startswith("<") and part_cid.endswith(">"):
                part_cid = part_cid[1:-1]

            # Build URL
            cid_url = f"{base_url}{part_cid}"
            cid_map[part_cid] = cid_url

    return cid_map
