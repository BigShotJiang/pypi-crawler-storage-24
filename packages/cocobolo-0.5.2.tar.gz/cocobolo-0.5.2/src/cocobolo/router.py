from __future__ import annotations

import asyncio
import re
import socket
from typing import Any, Dict, List

from paho.mqtt.client import topic_matches_sub

from opentelemetry import trace

from .event import Event
from .actions.base import Action
from .actions.registry import get_action_handler
from .sources.base import Source


tracer = trace.get_tracer("router")


_VAR_PATTERN = re.compile(r"\$(?P<name>[A-Za-z_][A-Za-z0-9_]*)")


def default_pattern_vars(*, deps: Any = None) -> dict[str, str]:
    """
    Default variables available for pattern expansion.

    This is intentionally tiny and centrally defined so it is easy to extend with
    more variables later (for example: environment, instance name, site, region).
    """
    # Prefer deps.config.host if you add it later; fall back to system hostname.
    host = None
    try:
        host = getattr(getattr(deps, "config", None), "host", None)
    except Exception:
        host = None

    if not host:
        host = socket.gethostname()

    return {
        "host": str(host),
    }


def expand_pattern(text: str, *, vars: dict[str, str]) -> str:
    """
    Expand $variables inside a pattern string.

    Rules:
    - `$name` is replaced by `vars["name"]` if present.
    - Unknown variables are left unchanged, to avoid breaking existing configs.
      (If you prefer strictness, change this to raise a ValueError instead.)
    """

    def repl(m: re.Match) -> str:
        name = m.group("name")
        if name in vars:
            return str(vars[name])
        return m.group(0)

    return _VAR_PATTERN.sub(repl, text)


class Route:
    def __init__(
        self,
        *,
        pattern: str,
        actions: List[Action],
        source: str | None = None,
        type: str | None = None,
    ):
        self.pattern = pattern
        self.actions = actions
        self.source = source
        self.type = type


class Router:
    def __init__(self, *, verbose: bool = False, deps: Any = None):
        self.verbose = verbose
        self.deps = deps
        self._queue: "asyncio.Queue[Event]" = asyncio.Queue()
        self._routes: List[Route] = []
        self._sources: Dict[str, Source] = {}

        self._main_task: asyncio.Task | None = None
        self._stop = asyncio.Event()

    def add_route(self, route: Route) -> None:
        self._routes.append(route)

    async def add_source(self, source: Source) -> None:
        if source.name in self._sources:
            raise ValueError(f"Source already exists: {source.name}")
        source.bind(self)
        self._sources[source.name] = source
        await source.start()

    def get_source(self, name: str) -> Source | None:
        return self._sources.get(name)

    def find_sources(self, *, type: str | None = None) -> dict[str, Source]:
        if type is None:
            return dict(self._sources)
        return {n: s for n, s in self._sources.items() if s.type == type}

    def resolve_source(
        self,
        *,
        type: str,
        name: str | None = None,
        unique: bool = True,
    ) -> Source | None:
        """
        Resolve a source by registered type name plus optional instance name.

        If name is provided: return that source if it exists and matches type, else None.
        If name is None:
          - if unique: return the only source of that type, else None
          - else: return None (caller can use find_sources)
        """
        if name is not None:
            s = self._sources.get(name)
            if s is None or s.type != type:
                return None
            return s

        match [s for s in self._sources.values() if s.type == type]:
            case [single]:
                return single
            case [first, *_rest] if not unique:
                return first
            case _:
                return None

    def pattern_vars(self) -> dict[str, str]:
        """
        Variables available for expanding patterns in both routes and subscriptions.
        """
        return default_pattern_vars(deps=self.deps)

    async def emit(self, event: Event) -> None:
        await self._queue.put(event)

    def emit_nowait(self, event: Event) -> None:
        self._queue.put_nowait(event)

    async def start(self) -> None:
        self._stop.clear()
        if self._main_task and not self._main_task.done():
            return
        self._main_task = asyncio.create_task(self._run(), name="router:main")
        await self._main_task

    async def stop(self) -> None:
        self._stop.set()
        if self._main_task:
            self._main_task.cancel()
            try:
                await self._main_task
            except asyncio.CancelledError:
                pass

        for src in list(self._sources.values()):
            await src.stop()
        self._sources.clear()

    async def _run(self) -> None:
        while not self._stop.is_set():
            event = await self._queue.get()
            await self.dispatch(event)

    async def dispatch(self, event: Event) -> None:
        with tracer.start_as_current_span("dispatch") as span_dispatch:
            span_dispatch.set_attribute("source", event.source)
            span_dispatch.set_attribute("type", event.type)
            if event.topic:
                span_dispatch.set_attribute("topic", event.topic)
            if self.verbose:
                print(
                    f"[router] event source={event.source!r} type={event.type!r} topic={event.topic!r}",
                    flush=True,
                )

            vars = self.pattern_vars()

            for route in self._routes:
                if route.source and route.source != event.source:
                    continue
                if route.type and route.type != event.type:
                    continue
                if route.pattern:
                    if event.topic is None:
                        continue

                    expanded_pattern = expand_pattern(route.pattern, vars=vars)
                    if not topic_matches_sub(expanded_pattern, event.topic):
                        continue

                for action in route.actions:
                    with tracer.start_as_current_span("action") as span_action:
                        span_action.set_attribute("type", action.type)
                        try:
                            handler = get_action_handler(action.type)
                            if handler is None:
                                raise ValueError(f"Unknown action type: {action.type}")
                            await handler(
                                action, {"event": event, "deps": self.deps, "router": self}
                            )
                        except Exception as e:
                            span_action.record_exception(e)
                            span_action.set_status(
                                trace.Status(
                                    trace.StatusCode.ERROR, f"{action.type} failed"
                                )
                            )
