"""HTML sanitization utilities for safe mail viewing."""

from __future__ import annotations

import re
from urllib.parse import urlparse

import bleach
from bleach.css_sanitizer import CSSSanitizer


# Allowed tags - structural and formatting only
ALLOWED_TAGS = [
    # Document structure
    "div",
    "span",
    "p",
    "br",
    "hr",
    # Headings
    "h1",
    "h2",
    "h3",
    "h4",
    "h5",
    "h6",
    # Text formatting
    "strong",
    "b",
    "em",
    "i",
    "u",
    "strike",
    "del",
    "s",
    "sub",
    "sup",
    "small",
    "mark",
    "ins",
    # Lists
    "ul",
    "ol",
    "li",
    "dl",
    "dt",
    "dd",
    # Tables
    "table",
    "thead",
    "tbody",
    "tfoot",
    "tr",
    "td",
    "th",
    "caption",
    "colgroup",
    "col",
    # Links and media
    "a",
    "img",
    # Quotes
    "blockquote",
    "q",
    "cite",
    # Code
    "pre",
    "code",
    "kbd",
    "samp",
    "var",
    # Sections
    "header",
    "footer",
    "section",
    "article",
    "aside",
    "nav",
    "main",
    "figure",
    "figcaption",
    "details",
    "summary",
]

# Allowed attributes per tag
ALLOWED_ATTRIBUTES = {
    "*": ["class", "id", "style", "title", "dir", "lang"],
    "a": ["href", "target", "rel"],
    "img": ["src", "alt", "title", "width", "height", "loading"],
    "table": ["border", "cellpadding", "cellspacing", "width"],
    "td": ["colspan", "rowspan", "align", "valign", "width", "height"],
    "th": ["colspan", "rowspan", "align", "valign", "width", "height"],
    "col": ["span", "width"],
    "colgroup": ["span", "width"],
}

# Allowed CSS properties (inline styles)
ALLOWED_CSS_PROPERTIES = [
    # Text
    "color",
    "background-color",
    "background",
    "font-family",
    "font-size",
    "font-weight",
    "font-style",
    "text-align",
    "text-decoration",
    "text-indent",
    "text-transform",
    "line-height",
    "letter-spacing",
    "word-spacing",
    # Box model
    "margin",
    "margin-top",
    "margin-right",
    "margin-bottom",
    "margin-left",
    "padding",
    "padding-top",
    "padding-right",
    "padding-bottom",
    "padding-left",
    "border",
    "border-top",
    "border-right",
    "border-bottom",
    "border-left",
    "border-color",
    "border-style",
    "border-width",
    "border-radius",
    # Display
    "display",
    "width",
    "height",
    "max-width",
    "max-height",
    "min-width",
    "min-height",
    "overflow",
    "overflow-x",
    "overflow-y",
    # Positioning (safe values only)
    "position",
    "top",
    "right",
    "bottom",
    "left",
    # Flexbox/Grid (safe)
    "flex",
    "flex-direction",
    "flex-wrap",
    "flex-flow",
    "flex-grow",
    "flex-shrink",
    "flex-basis",
    "justify-content",
    "align-items",
    "align-content",
    "grid",
    "grid-template",
    "grid-template-columns",
    "grid-template-rows",
    "grid-gap",
    "gap",
    "column-gap",
    "row-gap",
    # Lists
    "list-style",
    "list-style-type",
    "list-style-position",
    # Tables
    "border-collapse",
    "border-spacing",
    "vertical-align",
    # Misc
    "opacity",
    "visibility",
    "z-index",
    "box-shadow",
    "text-shadow",
]


class ImageHandling:
    """Configuration for image handling."""

    BLOCK_REMOTE = "block"
    ALLOW_REMOTE = "allow"


def is_remote_url(url: str) -> bool:
    """Check if URL is remote (http/https)."""
    if not url:
        return False
    parsed = urlparse(url)
    return parsed.scheme in ("http", "https")


def is_data_uri(url: str) -> bool:
    """Check if URL is a data URI."""
    if not url:
        return False
    return url.startswith("data:")


def is_cid_url(url: str) -> bool:
    """Check if URL is a CID (Content-ID) reference."""
    if not url:
        return False
    return url.startswith("cid:")


def _remove_style_blocks(html: str) -> str:
    """Remove <style> blocks (both tags and content) before sanitization."""
    # Pattern to match <style> tags and their content (non-greedy, case-insensitive, multiline)
    style_pattern = re.compile(r"<style[^>]*>.*?</style>", re.IGNORECASE | re.DOTALL)
    return style_pattern.sub("", html)


def sanitize_html(
    html: str,
    image_handling: str = ImageHandling.BLOCK_REMOTE,
    placeholder_src: str | None = None,
) -> str:
    """
    Sanitize HTML for safe display.

    Args:
        html: Raw HTML content
        image_handling: How to handle images (BLOCK_REMOTE or ALLOW_REMOTE)
        placeholder_src: URL for blocked image placeholder (default: inline SVG)

    Returns:
        Sanitized HTML string
    """
    if not html:
        return ""

    # Remove style blocks before sanitization to prevent CSS-based attacks
    html = _remove_style_blocks(html)

    # Default placeholder: inline SVG with "Image blocked" text
    if placeholder_src is None:
        placeholder_src = (
            "data:image/svg+xml,"
            "%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22100%22 height=%2260%22%3E"
            "%3Crect fill=%22%23f0f0f0%22 stroke=%22%23999%22 stroke-width=%221%22 "
            "width=%22100%25%22 height=%22100%25%22/%3E"
            "%3Ctext x=%2250%25%22 y=%2250%25%22 text-anchor=%22middle%22 "
            "dy=%22.3em%22 fill=%22%23666%22 font-size=%2212%22%3EImage blocked%3C/text%3E"
            "%3C/svg%3E"
        )

    # Clean with bleach
    css_sanitizer = CSSSanitizer(allowed_css_properties=ALLOWED_CSS_PROPERTIES)

    cleaned = bleach.clean(
        html,
        tags=ALLOWED_TAGS,
        attributes=ALLOWED_ATTRIBUTES,
        css_sanitizer=css_sanitizer,
        strip=True,  # Remove disallowed tags completely
    )

    # Post-process: handle images
    if image_handling == ImageHandling.BLOCK_REMOTE:
        cleaned = _block_remote_images(cleaned, placeholder_src)

    # Post-process: sanitize links (remove javascript:)
    cleaned = _sanitize_links(cleaned)

    return cleaned


def _block_remote_images(html: str, placeholder_src: str) -> str:
    """Replace remote image sources with placeholder."""
    # Pattern to find img tags with src attribute
    img_pattern = re.compile(
        r'<img([^>]+?)src=["\']([^"\']+)["\']([^>]*)>', re.IGNORECASE | re.DOTALL
    )

    def replace_img(match):
        before = match.group(1)
        src = match.group(2)
        after = match.group(3)

        # Allow data URIs and CID references
        if is_data_uri(src) or is_cid_url(src):
            return match.group(0)

        # Block remote URLs
        if is_remote_url(src):
            # Replace src with placeholder, add data-original-src for possible unblocking
            return (
                f"<img{before}"
                f'src="{placeholder_src}" '
                f'data-original-src="{src}" '
                f'data-blocked="remote"{after}>'
            )

        return match.group(0)

    return img_pattern.sub(replace_img, html)


def _sanitize_links(html: str) -> str:
    """Remove dangerous URLs from href attributes."""
    # Pattern to find javascript: or data: in href
    dangerous_pattern = re.compile(
        r'href=["\'](javascript:|data:text/html|data:application|vbscript:)',
        re.IGNORECASE,
    )

    # Replace with empty href
    return dangerous_pattern.sub('href="', html)


def sanitize_with_inline_images(
    html: str,
    cid_map: dict[str, str],
    image_handling: str = ImageHandling.BLOCK_REMOTE,
) -> str:
    """
    Sanitize HTML and replace CID references with actual URLs.

    Args:
        html: Raw HTML content
        cid_map: Mapping of CID -> URL for inline images
        image_handling: How to handle remote images

    Returns:
        Sanitized HTML with CID references replaced
    """

    # First, replace CID references
    def replace_cid(match):
        before = match.group(1)
        src = match.group(2)
        after = match.group(3)

        if src.startswith("cid:"):
            cid = src[4:]  # Remove 'cid:' prefix
            # Handle angle brackets in CID
            if cid.startswith("<") and cid.endswith(">"):
                cid = cid[1:-1]

            if cid in cid_map:
                new_src = cid_map[cid]
                return f'<img{before}src="{new_src}"{after} data-cid="{cid}">'

        return match.group(0)

    img_pattern = re.compile(
        r'<img([^>]+?)src=["\']([^"\']+)["\']([^>]*)>', re.IGNORECASE | re.DOTALL
    )

    html_with_cids = img_pattern.sub(replace_cid, html)

    # Then apply normal sanitization
    return sanitize_html(html_with_cids, image_handling=image_handling)
