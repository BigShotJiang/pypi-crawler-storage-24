"""Utility modules for cocobolo."""

from __future__ import annotations
