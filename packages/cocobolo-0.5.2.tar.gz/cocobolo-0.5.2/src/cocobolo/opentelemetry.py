import socket

from opentelemetry import trace
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor

from .config import OpenTelemetryConfig


def opentelemetry_init(config: OpenTelemetryConfig) -> None:
    """
    Minimal OTLP-over-HTTP tracing setup.
    """
    if not config.traces:
        return

    exporter = OTLPSpanExporter(
        endpoint=config.traces.endpoint, headers=config.traces.headers
    )
    provider = TracerProvider(
        resource=Resource.create(
            {
                "service.name": "cocobolo",
                "host.name": socket.gethostname(),
            }
        )
    )
    provider.add_span_processor(BatchSpanProcessor(exporter))
    trace.set_tracer_provider(provider)


__all__ = ["opentelemetry_init"]
