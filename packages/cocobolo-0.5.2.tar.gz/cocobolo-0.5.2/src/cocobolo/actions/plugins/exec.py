from __future__ import annotations

import asyncio
import os
import signal
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Mapping, Optional, Sequence, Set, Tuple

from opentelemetry import trace

from ...event import Event
from ...render import render
from ...router import Router
from ..base import Action
from ..registry import register_action, register_action_handler


@dataclass
class ManagedProcess:
    pid: int
    argv: List[str]
    proc: asyncio.subprocess.Process
    waiter: asyncio.Task[None]
    groups: Set[str]
    name: str = ""
    started_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


def _get_exec_tables(
    router: Router,
) -> Tuple[Dict[int, ManagedProcess], Dict[str, int]]:
    """
    Router-attached registries.

    **procs**: pid -> ManagedProcess
    **groups**: group -> pid

    This avoids duplicating ManagedProcess instances when a single process belongs
    to multiple groups.
    """
    procs = getattr(router, "_exec_procs", None)
    groups = getattr(router, "_exec_groups", None)
    if procs is None or groups is None:
        procs = {}
        groups = {}
        setattr(router, "_exec_procs", procs)
        setattr(router, "_exec_groups", groups)
    return procs, groups


def get_running_commands(router: Router) -> list[dict]:
    """Get list of currently running commands with their metadata."""
    procs, _ = _get_exec_tables(router)

    commands = []
    now = datetime.now(timezone.utc)

    for pid, mp in procs.items():
        duration = int((now - mp.started_at).total_seconds())
        commands.append(
            {
                "name": mp.name if mp.name else (mp.argv[0] if mp.argv else "unknown"),
                "duration": duration,
            }
        )

    return commands


def _normalize_group(group: Optional[str]) -> Optional[str]:
    """
    Treat None/empty/whitespace-only as absent.
    """
    if group is None:
        return None
    g = str(group).strip()
    return g if g else None


def _normalize_groups_value(value: Any) -> List[str]:
    """
    Normalize a rendered value that may be a scalar or a sequence into a list of groups.

    De-duplicates while preserving first-seen order.
    """
    if value is None:
        return []

    if isinstance(value, (str, int, float, bool)):
        raw: Sequence[Any] = [value]
    elif isinstance(value, (list, tuple, set)):
        raw = list(value)
    else:
        raw = [value]

    out: List[str] = []
    seen: Set[str] = set()
    for item in raw:
        g = _normalize_group(item)  # type: ignore[arg-type]
        if g is None or g in seen:
            continue
        seen.add(g)
        out.append(g)
    return out


def _new_group() -> str:
    """
    Generate a unique group id for ungrouped exec.start invocations.
    """
    return f"exec:{uuid.uuid4().hex}"


def _render_stop_group(action: Any, *, data: Mapping[str, Any]) -> Optional[str]:
    """
    Stop semantics: use **group** only (may be templated).

    Render **group** and normalize to a single key.
    """
    rendered_group = render(getattr(action, "group", None), data=data)
    return _normalize_group(rendered_group)  # type: ignore[arg-type]


async def _terminate_proc(
    proc: asyncio.subprocess.Process, *, kill_after: float = 5.0
) -> None:
    """
    Terminate with SIGTERM, then escalate to SIGKILL after kill_after seconds.
    Uses process groups when available so children are terminated too.
    """
    if proc.returncode is not None:
        return

    # SIGTERM
    try:
        if hasattr(os, "killpg"):
            os.killpg(proc.pid, signal.SIGTERM)
        else:
            proc.terminate()
    except ProcessLookupError:
        return
    except Exception:
        try:
            proc.terminate()
        except Exception:
            return

    try:
        await asyncio.wait_for(proc.wait(), timeout=kill_after)
        return
    except asyncio.TimeoutError:
        pass

    # SIGKILL
    try:
        if hasattr(os, "killpg"):
            os.killpg(proc.pid, signal.SIGKILL)
        else:
            proc.kill()
    except ProcessLookupError:
        return
    except Exception:
        try:
            proc.kill()
        except Exception:
            return

    await proc.wait()


async def _waiter(mp: ManagedProcess, *, router: Router) -> None:
    """
    Wait for process completion; emit finish/crash event, then remove the process
    and any group mappings that still point to it.
    """
    stopped_externally = False
    try:
        await mp.proc.wait()
    except asyncio.CancelledError:
        stopped_externally = True
        raise
    finally:
        procs, groups = _get_exec_tables(router)

        cur = procs.get(mp.pid)
        if cur is mp:
            procs.pop(mp.pid, None)

        for g in list(groups.keys()):
            if groups.get(g) == mp.pid:
                groups.pop(g, None)

        # Emit event for process completion
        returncode = mp.proc.returncode

        if stopped_externally:
            event_type = "exec.stopped"
            status = "stopped"
        elif returncode == 0:
            event_type = "exec.finished"
            status = "success"
        else:
            event_type = "exec.crashed"
            status = "failed"

        await router.emit(
            Event(
                source="exec",
                type=event_type,
                topic=f"exec/completed/{mp.pid}",
                payload={
                    "pid": mp.pid,
                    "argv": mp.argv,
                    "groups": list(mp.groups),
                    "returncode": returncode,
                    "status": status,
                    "stopped_externally": stopped_externally,
                },
                meta={
                    "pid": mp.pid,
                    "groups": list(mp.groups),
                },
            )
        )


@register_action("exec.start")
class ExecStartAction(Action):
    type: str = "exec.start"

    groups: List[Any] | None = None
    argv: List[Any]
    cwd: str | None = None
    env: Dict[str, str] | None = None
    kill_after: float = 5.0
    name: str | None = None  # Command name for tracking purposes


@register_action("exec.stop")
class ExecStopAction(Action):
    type: str = "exec.stop"

    group: Optional[str] = None
    kill_after: float = 5.0


@register_action_handler("exec.start")
async def handle_exec_start(action: ExecStartAction, ctx: Dict[str, Any]) -> None:
    router = ctx.get("router")
    if not isinstance(router, Router):
        raise RuntimeError("exec.start requires ctx['router']")

    event = ctx.get("event")
    if not isinstance(event, Event):
        raise ValueError("exec.start requires ctx['event']")

    data: Mapping[str, Any] = {"event": event}
    procs, group_index = _get_exec_tables(router)

    groups = _normalize_groups_value(getattr(action, "groups", None))
    provided_any_group = len(groups) > 0
    if not provided_any_group:
        groups = [_new_group()]

    rendered_argv = render(action.argv, data=data)
    if not isinstance(rendered_argv, list):
        raise ValueError("exec.start argv must render to a list")

    argv = [str(x) for x in rendered_argv if str(x) != ""]
    if not argv:
        raise ValueError("exec.start argv rendered to empty command")

    span = trace.get_current_span()
    span.set_attribute("exec.groups", ",".join(groups))
    span.set_attribute("exec.argv", " ".join(argv))

    # Replace semantics only when caller provided explicit groups.
    if provided_any_group:
        pids_to_stop: Set[int] = set()
        for g in groups:
            pid = group_index.get(g)
            if pid is not None:
                pids_to_stop.add(pid)

        for pid in pids_to_stop:
            mp_prev = procs.get(pid)
            if mp_prev is not None:
                await _terminate_proc(mp_prev.proc, kill_after=action.kill_after)

    preexec = os.setsid if hasattr(os, "setsid") else None
    proc = await asyncio.create_subprocess_exec(
        *argv,
        cwd=action.cwd,
        env=action.env,
        preexec_fn=preexec,
        stdout=asyncio.subprocess.DEVNULL,
        stderr=asyncio.subprocess.DEVNULL,
    )

    pid = int(proc.pid)
    span.set_attribute("exec.pid", pid)

    command_name = action.name or (argv[0] if argv else "unknown")
    mp = ManagedProcess(
        pid=pid,
        argv=argv,
        proc=proc,
        waiter=None,
        groups=set(groups),
        name=command_name,
    )  # type: ignore[assignment]
    mp.waiter = asyncio.create_task(_waiter(mp, router=router), name=f"exec:{pid}")

    procs[pid] = mp

    for g in groups:
        group_index[g] = pid

    # Emit exec.started event for distributed tracking
    await router.emit(
        Event(
            source="exec",
            type="exec.started",
            topic=f"exec/started/{pid}",
            payload={
                "pid": pid,
                "argv": argv,
                "groups": list(groups),
                "name": command_name,
            },
            meta={
                "pid": pid,
                "groups": list(groups),
            },
        )
    )


@register_action_handler("exec.stop")
async def handle_exec_stop(action: ExecStopAction, ctx: Dict[str, Any]) -> None:
    router = ctx.get("router")
    if not isinstance(router, Router):
        raise RuntimeError("exec.stop requires ctx['router']")

    event = ctx.get("event")
    if not isinstance(event, Event):
        raise ValueError("exec.stop requires ctx['event']")

    data: Mapping[str, Any] = {"event": event}
    group = _render_stop_group(action, data=data)

    if not group:
        return

    span = trace.get_current_span()
    span.set_attribute("exec.group", group)

    procs, group_index = _get_exec_tables(router)

    pid = group_index.get(group)
    if pid is None:
        span.set_attribute("exec.stopped", False)
        return

    span.set_attribute("exec.pid", int(pid))

    mp = procs.get(pid)
    if mp is not None:
        await _terminate_proc(mp.proc, kill_after=action.kill_after)

    group_index.pop(group, None)

    span.set_attribute("exec.stopped", True)


@register_action("exec.start_from_config")
class ExecStartFromConfigAction(Action):
    type: str = "exec.start_from_config"


@register_action_handler("exec.start_from_config")
async def handle_exec_start_from_config(
    action: ExecStartFromConfigAction, ctx: Dict[str, Any]
) -> None:
    """Start a command by looking up its name from config.commands."""
    from ...cli.core.deps import Deps

    router = ctx.get("router")
    if not isinstance(router, Router):
        raise RuntimeError("exec.start_from_config requires ctx['router']")

    event = ctx.get("event")
    if not isinstance(event, Event):
        raise ValueError("exec.start_from_config requires ctx['event']")

    deps = ctx.get("deps")
    if not isinstance(deps, Deps):
        raise RuntimeError("exec.start_from_config requires ctx['deps']")

    # Extract command name from topic (e.g., "cmd/pi1/start/radio1" -> "radio1")
    if not event.topic:
        raise ValueError("exec.start_from_config requires event.topic")

    command_name = event.topic.split("/")[-1]

    # Look up command in config
    config = deps.config
    cmd_spec = config.get_command_spec(command_name)

    if cmd_spec is None:
        raise ValueError(f"Command not found in config: {command_name}")

    if not cmd_spec.is_executable:
        raise ValueError(f"Command is not executable: {command_name}")

    # Create an ExecStartAction and execute it
    exec_action = ExecStartAction(
        argv=cmd_spec.argv or [],
        groups=cmd_spec.groups,
        cwd=cmd_spec.cwd,
        env=cmd_spec.env,
        name=command_name,
        kill_after=cmd_spec.kill_after,
    )

    await handle_exec_start(exec_action, ctx)


def init() -> None:
    return
