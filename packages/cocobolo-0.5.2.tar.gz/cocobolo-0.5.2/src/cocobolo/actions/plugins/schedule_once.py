from __future__ import annotations

from datetime import datetime
from typing import Any, Dict

from opentelemetry import trace
from pydantic import Field

from ...event import Event
from ...render import render
from ...router import Router
from ...sources.base import Source
from ..base import Action
from ..registry import register_action, register_action_handler


@register_action("schedule.once")
class ScheduleOnceAction(Action):
    type: str = "schedule.once"

    # Target scheduler instance name; if omitted, must be uniquely resolvable.
    source: str | None = None

    # Exactly one of these must be provided:
    at: datetime | None = Field(default=None, description="Absolute ISO8601 time")
    after: float | None = Field(
        default=None, ge=0, description="Relative delay in seconds"
    )

    # Optional overrides for the scheduled event:
    topic: str | None = None
    event_type: str | None = None
    meta: Dict[str, Any] | None = None

    # If payload is omitted, we default to current event.payload (like mqtt.publish).
    # Also supports templating via cocobolo.render with data={'event': event}.
    payload: Any = None


def _get_scheduler(src: Source) -> Any:
    # Avoid importing SchedulerSource type directly; keep plugin loosely coupled.
    if not hasattr(src, "schedule_once"):
        raise TypeError("Resolved scheduler source does not provide schedule_once()")
    return src


@register_action_handler("schedule.once")
async def handle_schedule_once(action: ScheduleOnceAction, ctx: Dict[str, Any]) -> None:
    router = ctx.get("router")
    if not isinstance(router, Router):
        raise RuntimeError("schedule.once requires ctx['router']")

    event = ctx.get("event")
    if not isinstance(event, Event):
        raise ValueError("schedule.once requires ctx['event']")

    src = router.resolve_source(type="scheduler", name=action.source)
    if src is None:
        if action.source is None:
            raise ValueError(
                "schedule.once: no unique scheduler source; specify 'source'"
            )
        raise ValueError(f"schedule.once: scheduler source {action.source!r} not found")

    scheduler = _get_scheduler(src)

    if (action.at is None) == (action.after is None):
        raise ValueError("schedule.once requires exactly one of: 'at' or 'after'")

    payload = action.payload if action.payload is not None else event.payload
    rendered_payload = render(payload, data={"event": event})

    span = trace.get_current_span()
    span.set_attribute("scheduler.source", getattr(src, "name", "scheduler"))
    if action.topic is not None:
        span.set_attribute("scheduled.topic", action.topic)
    if action.event_type is not None:
        span.set_attribute("scheduled.type", action.event_type)
    if action.at is not None:
        span.set_attribute("scheduled.at", action.at.isoformat())
    if action.after is not None:
        span.set_attribute("scheduled.after", float(action.after))

    await scheduler.schedule_once(
        at=action.at,
        after=action.after,
        topic=action.topic,
        event_type=action.event_type,
        payload=rendered_payload,
        meta=action.meta,
    )


def init() -> None:
    return
