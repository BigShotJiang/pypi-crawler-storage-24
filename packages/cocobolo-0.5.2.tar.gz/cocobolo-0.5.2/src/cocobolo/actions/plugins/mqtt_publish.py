from __future__ import annotations

import json
from typing import Any, Dict

from opentelemetry import trace

from ...event import Event
from ...render import render
from ...router import Router, expand_pattern
from ...sources.plugins.mqtt import MqttSource
from ..base import Action
from ..registry import register_action, register_action_handler


@register_action("mqtt.publish")
class MqttPublishAction(Action):
    type: str = "mqtt.publish"
    topic: str
    source: str | None = None


@register_action_handler("mqtt.publish")
async def handle_mqtt_publish(action: MqttPublishAction, ctx: Dict[str, Any]) -> None:
    router = ctx.get("router")
    if not isinstance(router, Router):
        raise RuntimeError("mqtt.publish requires ctx['router']")

    event = ctx.get("event")
    if not isinstance(event, Event):
        raise ValueError("mqtt.publish requires ctx['event']")

    src = router.resolve_source(type="mqtt", name=action.source)
    if src is None:
        if action.source is None:
            raise ValueError("mqtt.publish: no unique mqtt source; specify 'source'")
        raise ValueError(f"mqtt.publish: mqtt source {action.source!r} not found")

    if not isinstance(src, MqttSource):
        raise ValueError(f"mqtt.publish: source {action.source!r} is not an MqttSource")

    payload = action.payload if action.payload is not None else event.payload
    rendered = render(payload, data={"event": event})
    data = json.dumps(rendered, ensure_ascii=False).encode("utf-8")

    span = trace.get_current_span()
    span.set_attribute("topic", action.topic)
    span.set_attribute("data", data)

    vars = router.pattern_vars()
    expanded_topic = expand_pattern(action.topic, vars=vars)
    src.service.publish(expanded_topic, data)


def init() -> None:
    return
