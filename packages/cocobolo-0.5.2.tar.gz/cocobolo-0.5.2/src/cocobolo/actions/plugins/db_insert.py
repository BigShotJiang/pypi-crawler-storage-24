from __future__ import annotations

import asyncio
import json
import re
from pathlib import Path
from typing import Any, Dict
from urllib.parse import urlsplit, urlunsplit

from opentelemetry import trace
from pydantic import Field
from sqlalchemy import MetaData, Table, insert, text
from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    async_sessionmaker,
    create_async_engine,
)

from ...config import Config
from ...event import Event
from ...render import render
from ..base import Action
from ..registry import register_action, register_action_handler


_SCHEME_RE = re.compile(r"^[a-zA-Z][a-zA-Z0-9+.-]*://")

_ENGINES: dict[str, AsyncEngine] = {}
_SESSIONMAKERS: dict[str, async_sessionmaker] = {}
_TABLES: dict[tuple[str, str], Table] = {}
_LOCKS: dict[str, asyncio.Lock] = {}

_ASYNC_SCHEME_MAP: dict[str, str] = {
    "postgresql": "postgresql+asyncpg",
    "mysql": "mysql+aiomysql",
    "mariadb": "mariadb+aiomysql",
    "sqlite": "sqlite+aiosqlite",
}

# Only treat this prefix as special if it exists in the *original config value* (pre-render).
_SQL_PREFIX = "sql:"

# Avoid huge trace attributes. This is a pragmatic limit for observability backends.
_TRACE_FIELDS_JSON_MAX = 8192


def _is_url(s: str) -> bool:
    return bool(_SCHEME_RE.match(s.strip()))


def _with_async_driver(db_url: str) -> str:
    parts = urlsplit(db_url)
    scheme = parts.scheme

    if not scheme:
        return db_url

    if "+" in scheme:
        return db_url

    mapped = _ASYNC_SCHEME_MAP.get(scheme.lower())
    if mapped is None:
        return db_url

    return urlunsplit((mapped, parts.netloc, parts.path, parts.query, parts.fragment))


def _normalize_database(database: str) -> tuple[str, str]:
    database = database.strip()

    if _is_url(database):
        async_url = _with_async_driver(database)
        return async_url, "sqlalchemy-url"

    p = Path(database).expanduser()
    if p.parent:
        p.parent.mkdir(parents=True, exist_ok=True)
    p = p.resolve()
    return f"sqlite+aiosqlite:///{p}", "sqlite-file"


def _get_lock(db_url: str) -> asyncio.Lock:
    lock = _LOCKS.get(db_url)
    if lock is None:
        lock = asyncio.Lock()
        _LOCKS[db_url] = lock
    return lock


async def _get_engine_and_sessionmaker(
    db_url: str,
) -> tuple[AsyncEngine, async_sessionmaker]:
    engine = _ENGINES.get(db_url)
    sm = _SESSIONMAKERS.get(db_url)
    if engine is not None and sm is not None:
        return engine, sm

    async with _get_lock(db_url):
        engine = _ENGINES.get(db_url)
        sm = _SESSIONMAKERS.get(db_url)
        if engine is not None and sm is not None:
            return engine, sm

        engine = create_async_engine(db_url, future=True)
        sm = async_sessionmaker(engine, expire_on_commit=False)

        _ENGINES[db_url] = engine
        _SESSIONMAKERS[db_url] = sm
        return engine, sm


async def _get_reflected_table(
    engine: AsyncEngine, db_url: str, table_name: str
) -> Table:
    key = (db_url, table_name)
    t = _TABLES.get(key)
    if t is not None:
        return t

    async with _get_lock(db_url):
        t = _TABLES.get(key)
        if t is not None:
            return t

        metadata = MetaData()

        async with engine.connect() as conn:

            def _reflect(sync_conn):
                Table(table_name, metadata, autoload_with=sync_conn)

            await conn.run_sync(_reflect)

        t = metadata.tables.get(table_name)
        if t is None:
            raise ValueError(f"Table reflection failed for table={table_name!r}")

        _TABLES[key] = t
        return t


def _safe_jsonable(v: Any) -> Any:
    """
    Produce a JSON-safe, reasonably compact representation for tracing.

    This is *observability*, not persistence: we prefer "something readable" over
    perfect round-tripping. For unknown objects we fall back to `repr(v)`.
    """
    if v is None or isinstance(v, (bool, int, float, str)):
        return v
    if isinstance(v, (list, tuple)):
        return [_safe_jsonable(x) for x in v]
    if isinstance(v, dict):
        return {str(k): _safe_jsonable(val) for k, val in v.items()}
    return repr(v)


def _trace_fields_payload(fields_info: Dict[str, Any]) -> tuple[str, bool]:
    """
    Return a JSON string suitable for a span attribute and a truncation flag.
    """
    s = json.dumps(
        _safe_jsonable(fields_info), ensure_ascii=False, separators=(",", ":")
    )
    if len(s) <= _TRACE_FIELDS_JSON_MAX:
        return s, False
    return s[:_TRACE_FIELDS_JSON_MAX] + "…", True


def _render_fields_with_sql_prefix_support(
    fields_template: Dict[str, Any], *, event: Event
) -> tuple[Dict[str, Any], Dict[str, Any]]:
    """
    Render `fields_template` with Jinja, but treat `sql:` specially only if it appears
    in the *original* template string (pre-render).

    Returns:
      (rendered_fields, trace_fields)
    """
    out: Dict[str, Any] = {}
    trace_fields: Dict[str, Any] = {}

    for k, v in fields_template.items():
        if isinstance(v, str):
            stripped = v.lstrip()
            if stripped.startswith(_SQL_PREFIX):
                # SQL mode is decided *before* rendering, so data cannot "create" sql:.
                expr_template = stripped[len(_SQL_PREFIX) :].lstrip()
                rendered_expr = render(expr_template, data={"event": event})

                if not isinstance(rendered_expr, str):
                    raise ValueError(
                        f"db.insert: sql: field {k!r} must render to a string SQL expression"
                    )

                expr = rendered_expr.strip()
                if not expr:
                    raise ValueError(
                        f"db.insert: field {k!r} uses sql: prefix but rendered empty expression"
                    )

                out[k] = text(expr)
                trace_fields[k] = expr
                continue

        rendered_value = render(v, data={"event": event})
        out[k] = rendered_value
        trace_fields[k] = _safe_jsonable(rendered_value)

    return out, trace_fields


@register_action("db.insert")
class DbInsertAction(Action):
    """
    Insert one row into a database table (database-agnostic via SQLAlchemy URL).

    Resolution rules:
    - If `database` is a SQLAlchemy URL (e.g. 'postgresql+asyncpg://...'), use it as-is.
    - Otherwise treat it as a filesystem path (expand '~') and use SQLite async driver.

    `fields` is a dict of column->value; values can be Jinja2-templated with `event`.

    Special behavior:
    - If a field value (in the original config) is a string prefixed with 'sql:',
      it is treated as a raw SQL expression (via SQLAlchemy text()) after rendering
      the remainder of the string.
    """

    type: str = "db.insert"

    database: str | None = Field(
        default=None,
        description="SQLAlchemy URL or file path (file path -> sqlite). If omitted, uses top-level config.database.",
    )
    table: str = Field(..., description="Target table name")
    fields: Dict[str, Any] = Field(
        default_factory=dict, description="Column->value mapping"
    )


@register_action_handler("db.insert")
async def handle_db_insert(action: DbInsertAction, ctx: Dict[str, Any]) -> None:
    event = ctx.get("event")
    if not isinstance(event, Event):
        raise ValueError("db.insert requires ctx['event'] to be an Event")

    deps = ctx.get("deps")
    config = getattr(deps, "config", None)
    if not isinstance(config, Config):
        raise ValueError("db.insert action requires deps.config to be a Config")

    span = trace.get_current_span()

    database = action.database or config.database
    if not isinstance(database, str) or not database.strip():
        raise ValueError(
            "db.insert requires a database; set action.database or top-level config.database"
        )

    db_url, db_kind = _normalize_database(database)

    span.set_attribute("db.table", action.table)

    if not isinstance(action.fields, dict):
        raise ValueError("db.insert: fields must be a dict")

    rendered_fields, trace_fields = _render_fields_with_sql_prefix_support(
        action.fields, event=event
    )

    fields_json, truncated = _trace_fields_payload(trace_fields)
    if fields_json:
        span.set_attribute("db.insert.fields", fields_json)
    if truncated:
        span.set_attribute("db.insert.fields_truncated", truncated)

    engine, Session = await _get_engine_and_sessionmaker(db_url)
    table = await _get_reflected_table(engine, db_url, action.table)

    async with Session() as session:
        await session.execute(insert(table).values(**rendered_fields))
        await session.commit()


def init() -> None:
    return


__all__ = ["DbInsertAction", "init"]
