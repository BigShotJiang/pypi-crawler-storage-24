from __future__ import annotations

from importlib.metadata import entry_points
from typing import Any


def load(*, group: str = "cocobolo.actions") -> None:
    """
    Load action plugins via packaging entry points.

    Each entry point must resolve to a callable with signature `() -> Any`
    (typically named `plugin_init`) which, when called, imports/registers
    action models/handlers.

    This replaces "scan internal folder" discovery; it is packaging-driven.
    """
    eps = entry_points()
    selected = eps.select(group=group)

    for ep in selected:
        init = ep.load()
        if not callable(init):
            raise TypeError(
                f"Entry point {ep.name!r} in group {group!r} did not load a callable"
            )
        init()
