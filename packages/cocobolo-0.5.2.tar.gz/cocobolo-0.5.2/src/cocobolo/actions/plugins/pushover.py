from __future__ import annotations

from mimetypes import guess_type
from pathlib import Path
from typing import Any, Dict

import httpx
from opentelemetry import trace
from pydantic import Field

from ...event import Event
from ...render import render
from ..base import Action
from ..registry import register_action, register_action_handler


@register_action("pushover")
class PushoverAction(Action):
    """
    Send a Pushover notification.

    Notes:
    - **token** and **user** are read from `deps.config.pushover.token` and
      `deps.config.pushover.user`.
    - `message` defaults to a simple topic/payload rendering.
    - `payload` is *not* used as the message body; this action has explicit fields.
    """

    type: str = "pushover"

    title: str | None = None
    message: str | None = None
    device: str | None = None
    html: bool | None = None
    priority: int | None = None
    url: str | None = None
    url_title: str | None = None
    image: str | None = None

    timeout: float | None = Field(default=10.0, description="HTTP timeout seconds")


async def _send_pushover(
    *,
    token: str,
    user: str,
    message: str,
    title: str | None = None,
    image: str | None = None,
    device: str | None = None,
    html: bool | None = None,
    priority: int | None = None,
    url: str | None = None,
    url_title: str | None = None,
    timeout: float = 10.0,
) -> Any:
    data: dict[str, Any] = {
        "token": token,
        "user": user,
        "message": message,
    }
    if title is not None:
        data["title"] = title
    if device is not None:
        data["device"] = device
    if html is True:
        data["html"] = 1
    if priority is not None:
        data["priority"] = int(priority)
    if url is not None:
        data["url"] = url
        if url_title is not None:
            data["url_title"] = url_title

    files = None
    file_handle = None
    try:
        if image:
            p = Path(image)
            media, _ = guess_type(str(p), strict=False)
            file_handle = p.open("rb")
            files = {
                "attachment": (p.name, file_handle, media or "application/octet-stream")
            }

        async with httpx.AsyncClient(timeout=timeout) as client:
            r = await client.post(
                "https://api.pushover.net/1/messages.json",
                data=data,
                files=files,
            )
        r.raise_for_status()
        return r.json()
    finally:
        if file_handle is not None:
            try:
                file_handle.close()
            except Exception:
                pass


@register_action_handler("pushover")
async def handle_pushover(action: PushoverAction, ctx: Dict[str, Any]) -> None:
    event = ctx.get("event")
    if not isinstance(event, Event):
        raise ValueError("pushover requires ctx['event'] to be an Event")

    deps = ctx.get("deps")
    if deps is None:
        raise ValueError("pushover requires ctx['deps']")
    if not hasattr(deps, "config") or deps.config is None:
        raise ValueError("pushover requires deps.config")
    if not hasattr(deps.config, "pushover") or deps.config.pushover is None:
        raise ValueError("pushover requires pushover config in deps.config")
    credentials = deps.config.pushover

    raw_message = action.message or "{{ event.topic }}: {{ event.payload }}"

    data = {"event": event}

    kwargs = {
        "message": render(raw_message, data=data),
        "title": render(action.title, data=data),
        "device": render(action.device, data=data),
        "html": action.html,
        "priority": action.priority,
        "url": render(action.url, data=data),
        "url_title": render(action.url_title, data=data),
        "image": render(action.image, data=data),
    }

    span = trace.get_current_span()
    for key, value in kwargs.items():
        if value is None:
            continue
        span.set_attribute(key, value)

    await _send_pushover(
        token=credentials.token,
        user=credentials.user,
        timeout=float(action.timeout or 10.0),
        **kwargs,
    )


def init() -> None:
    return


__all__ = ["PushoverAction", "init"]
