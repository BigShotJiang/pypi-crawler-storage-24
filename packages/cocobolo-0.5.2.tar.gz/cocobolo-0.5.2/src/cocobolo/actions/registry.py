from __future__ import annotations

from typing import Any, Awaitable, Callable, Dict, Type, TypeVar

from .base import Action

ActionT = TypeVar("ActionT", bound=Action)
ActionHandler = Callable[[Any, Dict[str, Any]], Awaitable[None]]

_ACTION_MODELS: Dict[str, Type[Action]] = {}
_ACTION_HANDLERS: Dict[str, ActionHandler] = {}


def reset_actions_registry() -> None:
    """
    Clear registered action models and handlers.

    Intended for tests (e.g. pytest) to ensure isolation between runs.
    """
    _ACTION_MODELS.clear()
    _ACTION_HANDLERS.clear()


def register_action(action_type: str):
    def decorator(cls: Type[ActionT]) -> Type[ActionT]:
        existing = _ACTION_MODELS.get(action_type)
        if existing and existing is not cls:
            raise ValueError(f"Action type already registered: {action_type}")
        _ACTION_MODELS[action_type] = cls
        return cls

    return decorator


def register_action_handler(action_type: str):
    def decorator(fn: ActionHandler) -> ActionHandler:
        _ACTION_HANDLERS[action_type] = fn
        return fn

    return decorator


def get_action_model(action_type: str) -> Type[Action] | None:
    return _ACTION_MODELS.get(action_type)


def get_action_handler(action_type: str) -> ActionHandler | None:
    return _ACTION_HANDLERS.get(action_type)
