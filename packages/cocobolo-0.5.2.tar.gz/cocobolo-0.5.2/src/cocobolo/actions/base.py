from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field, GetCoreSchemaHandler
from pydantic_core import core_schema


class Action(BaseModel):
    """
    Polymorphic action model.
    A dict with {"type": "..."} will be validated into the registered concrete model.
    """

    model_config = ConfigDict(extra="allow")

    type: str = Field(...)
    timeout: float | None = None
    payload: Any = None

    @classmethod
    def __get_pydantic_core_schema__(
        cls,
        source: type[Any],
        handler: GetCoreSchemaHandler,
    ) -> core_schema.CoreSchema:
        if cls.__name__ != "Action":
            return handler(source)
        return core_schema.no_info_plain_validator_function(cls._validate)

    @staticmethod
    def _validate(value: Any) -> "Action":
        from .registry import get_action_model

        if isinstance(value, Action) and type(value) is not Action:
            return value

        if isinstance(value, dict):
            t = value.get("type")
            if not isinstance(t, str):
                raise ValueError("Action requires string field 'type'")
            model = get_action_model(t)
            if model is None:
                raise ValueError(f"Unknown action type: {t}")
            return model.model_validate(value)

        raise TypeError("Action must be a dict or a concrete Action model")
