from __future__ import annotations

import re
from typing import Any, Mapping, Sequence

import jinja2


_EXACT_EXPR_RE = re.compile(r"^\s*{{\s*(?P<expr>.+?)\s*}}\s*$", re.S)

env = jinja2.Environment(
    autoescape=False,
    undefined=jinja2.StrictUndefined,  # fail fast on missing variables
    trim_blocks=True,
    lstrip_blocks=True,
)


def _bytes_to_str(v: Any) -> Any:
    if isinstance(v, (bytes, bytearray, memoryview)):
        try:
            return bytes(v).decode("utf-8")
        except Exception:
            return bytes(v).decode("utf-8", errors="replace")
    return v


def render(
    obj: Any,
    *,
    data: Mapping[str, Any] | None = None,
) -> Any:
    """
    Render Jinja2 templates inside a string, list, tuple, or dict.

    Type rules:
    - If a string is exactly a single Jinja2 expression in {{ ... }},
      return the evaluated Python value *as-is*, except bytes -> decoded string.
    - Otherwise, render as a normal Jinja2 template (result is a string).

    Recursion:
    - dict keys and values are rendered (change if you do not want keys templated).
    - lists/tuples are rendered element-wise.
    """
    if obj is None:
        return None

    if data is None:
        data = {}

    # dict / mapping
    if isinstance(obj, Mapping):
        return {
            render(k, data=data): render(v, data=data)
            for k, v in obj.items()
        }

    # list / tuple / other sequences (but not string/bytes)
    if isinstance(obj, Sequence) and not isinstance(obj, (str, bytes, bytearray, memoryview)):
        rendered = [render(v, data=data) for v in obj]
        return tuple(rendered) if isinstance(obj, tuple) else rendered

    # bytes-like: decode
    if isinstance(obj, (bytes, bytearray, memoryview)):
        return _bytes_to_str(obj)

    # string: render
    if isinstance(obj, str):
        if m := _EXACT_EXPR_RE.match(obj):
            expr = m.group("expr")
            # This supports full Jinja2 expressions: filters, tests, math, etc.
            compiled = env.compile_expression(expr, undefined_to_none=False)
            value = compiled(**data)
            return _bytes_to_str(value)

        # Full template rendering (may include blocks, macros, filters, etc.)
        template = env.from_string(obj)
        rendered = template.render(**data)
        # rendered is always a string
        return rendered

    # everything else: untouched
    return obj


__all__ = ['render']
