from __future__ import annotations

from typing import Any, Dict, List, Literal, Union

from pydantic import BaseModel, Field

from .actions.base import Action
from .sources.base import SourceSpec


class OpenTelemetryTracesConfig(BaseModel):
    endpoint: str
    headers: dict[str, str] | None = None


class OpenTelemetryConfig(BaseModel):
    traces: OpenTelemetryTracesConfig


class PushoverConfig(BaseModel):
    user: str
    token: str


class ParameterDef(BaseModel):
    """
    Definition of a parameter for a command's payload template.

    Example:
        {
            "name": "volume",
            "type": "integer",
            "label": "Volume (0-100)",
            "default": 50
        }
    """

    name: str = Field(..., description="Parameter identifier (used in templates)")
    type: Literal["string", "integer", "number", "boolean"] = Field(
        default="string", description="Parameter type"
    )
    label: str | None = Field(None, description="Display label for the UI")
    default: Any | None = Field(None, description="Default value")


class CommandSpec(BaseModel):
    """
    A reusable named command that expands to an exec.start action.

    Supported user-facing shapes:
      - string form: "cmdname" (display only, no local execution)
      - object form: {"name": "cmdname", "argv": [...], ...}

    UI fields for button display:
      - title: Display name (defaults to name)
      - description: Tooltip/hover text
      - color: Button background color (light mode)
      - color_dark: Button background color (dark mode)
      - css: Additional CSS (light mode)
      - css_dark: Additional CSS (dark mode)

    Payload template for MQTT commands:
      - payload_template: Jinja2 template dict for MQTT payload
      - parameters: List of parameter definitions for UI input

    Example with payload template:
        {
            "name": "volume",
            "title": "Set Volume",
            "parameters": [
                {"name": "level", "type": "integer", "label": "Volume", "default": 50}
            ],
            "payload_template": {"value": "{{ params.level }}"}
        }
    """

    name: str = Field(..., description="Command identifier")
    title: str | None = Field(None, description="Display name")
    description: str | None = Field(None, description="Tooltip/hover text")
    color: str | None = Field(None, description="Button background color (light)")
    color_dark: str | None = Field(None, description="Button background color (dark)")
    css: str | None = Field(None, description="Additional CSS (light)")
    css_dark: str | None = Field(None, description="Additional CSS (dark)")

    # exec.start fields (optional for display-only commands)
    argv: List[Any] | None = Field(None, description="Argument vector for exec.start")
    groups: List[str] | None = None
    cwd: str | None = None
    env: Dict[str, str] | None = None
    kill_after: float = 5.0
    host: str | None = Field(
        None,
        description="Target host for this command (optional). When set, the command runs on this host without requiring host selection.",
    )

    # Payload template for MQTT commands
    payload_template: Dict[str, Any] | None = Field(
        None, description="Jinja2 template dict for MQTT payload"
    )
    parameters: List[ParameterDef] | None = Field(
        None, description="Parameter definitions for UI input"
    )

    @classmethod
    def from_config_value(cls, value: Any) -> "CommandSpec":
        """Parse command from config - string or dict."""
        if isinstance(value, str):
            # String form: display only, no local execution
            return cls(
                name=value,
                title=value,
                description=None,
                color=None,
                color_dark=None,
                css=None,
                css_dark=None,
                argv=None,
                groups=None,
                cwd=None,
                env=None,
                kill_after=5.0,
                host=None,
                payload_template=None,
                parameters=None,
            )
        if isinstance(value, dict):
            # Dict form: full specification
            return cls.model_validate(value)
        raise TypeError("Command must be a string (name) or an object with 'name'")

    @property
    def display_title(self) -> str:
        """Get the display title, falling back to name."""
        return self.title or self.name

    @property
    def is_executable(self) -> bool:
        """Check if this command can execute locally (has argv)."""
        return self.argv is not None and len(self.argv) > 0


# CommandsConfig is now a list to preserve order
CommandsConfig = List[Union[str, CommandSpec, Dict[str, Any]]]


class EventSpec(BaseModel):
    """
    A reusable named event that can be sent via MQTT.

    Supported user-facing shapes:
      - string form: "eventname" (uses name as title)
      - object form: {"name": "eventname", "title": "...", ...}

    Example:
        {
            "name": "system_restart",
            "title": "Restart Service",
            "description": "Trigger a service restart",
            "color": "#e3f2fd",
            "color_dark": "#1565c0"
        }
    """

    name: str = Field(..., description="Event identifier")
    title: str | None = Field(None, description="Display name")
    description: str | None = Field(None, description="Tooltip/hover text")
    color: str | None = Field(None, description="Button background color (light)")
    color_light: str | None = Field(None, description="Button background color (light)")
    color_dark: str | None = Field(None, description="Button background color (dark)")
    css: str | None = Field(None, description="Additional CSS (light)")
    css_light: str | None = Field(None, description="Additional CSS (light)")
    css_dark: str | None = Field(None, description="Additional CSS (dark)")

    @classmethod
    def from_config_value(cls, value: Any) -> "EventSpec":
        """Parse event from config - string or dict."""
        if isinstance(value, str):
            # String form: name only, title defaults to name
            return cls(
                name=value,
                title=value,
                description=None,
                color=None,
                color_light=None,
                color_dark=None,
                css=None,
                css_light=None,
                css_dark=None,
            )
        if isinstance(value, dict):
            # Dict form: full specification
            return cls.model_validate(value)
        raise TypeError("Event must be a string (name) or an object with 'name'")

    @property
    def display_title(self) -> str:
        """Get the display title, falling back to name."""
        return self.title or self.name


# EventsConfig is a list to preserve order
EventsConfig = List[Union[str, EventSpec, Dict[str, Any]]]


class ConsumedSpec(BaseModel):
    """
    A reusable named consumable item for tracking when items are replaced.

    Supported user-facing shapes:
      - string form: "itemname" (uses name as title)
      - object form: {"name": "itemname", "title": "...", ...}

    Example:
        {
            "name": "waterfilter",
            "title": "Water Filter",
            "description": "Replace the water filter"
        }
    """

    name: str = Field(..., description="Item identifier")
    title: str | None = Field(None, description="Display name")
    description: str | None = Field(None, description="Tooltip/hover text")
    color: str | None = Field(None, description="Button background color (light)")
    color_light: str | None = Field(None, description="Button background color (light)")
    color_dark: str | None = Field(None, description="Button background color (dark)")
    css: str | None = Field(None, description="Additional CSS (light)")
    css_light: str | None = Field(None, description="Additional CSS (light)")
    css_dark: str | None = Field(None, description="Additional CSS (dark)")

    @classmethod
    def from_config_value(cls, value: Any) -> "ConsumedSpec":
        """Parse consumed item from config - string or dict."""
        if isinstance(value, str):
            # String form: name only, title defaults to name
            return cls(
                name=value,
                title=value,
                description=None,
                color=None,
                color_light=None,
                color_dark=None,
                css=None,
                css_light=None,
                css_dark=None,
            )
        if isinstance(value, dict):
            # Dict form: full specification
            return cls.model_validate(value)
        raise TypeError(
            "Consumed item must be a string (name) or an object with 'name'"
        )

    @property
    def display_title(self) -> str:
        """Get the display title, falling back to name."""
        return self.title or self.name


# ConsumedConfig is a list to preserve order
ConsumedConfig = List[Union[str, ConsumedSpec, Dict[str, Any]]]


class GroupSpec(BaseModel):
    """
    A group definition for command grouping.

    Supported user-facing shapes:
      - string form: "groupname" (just the name)
      - object form: {"name": "groupname", "title": "...", ...}

    UI fields for button display:
      - title: Display name (defaults to name)
      - description: Tooltip/hover text
      - color: Button background color (light mode)
      - color_dark: Button background color (dark mode)
      - css: Additional CSS (light mode)
      - css_dark: Additional CSS (dark mode)
    """

    name: str = Field(..., description="Group identifier")
    title: str | None = Field(None, description="Display name")
    description: str | None = Field(None, description="Tooltip/hover text")
    color: str | None = Field(None, description="Button background color (light)")
    color_dark: str | None = Field(None, description="Button background color (dark)")
    css: str | None = Field(None, description="Additional CSS (light)")
    css_dark: str | None = Field(None, description="Additional CSS (dark)")

    @classmethod
    def from_config_value(cls, value: Any) -> "GroupSpec":
        """Parse group from config - string or dict."""
        if isinstance(value, str):
            return cls(
                name=value,
                title=value,
                description=None,
                color=None,
                color_dark=None,
                css=None,
                css_dark=None,
            )
        if isinstance(value, dict):
            return cls.model_validate(value)
        raise TypeError("Group must be a string (name) or an object with 'name'")

    @property
    def display_title(self) -> str:
        """Get the display title, falling back to name."""
        return self.title or self.name


# GroupsConfig is a list to preserve order
GroupsConfig = List[Union[str, GroupSpec, Dict[str, Any]]]


class Route(BaseModel):
    pattern: str = Field(..., description="MQTT subscription-style pattern")
    actions: List[Action] = Field(default_factory=list)
    source: str | None = None
    type: str | None = None


class Config(BaseModel):
    opentelemetry: OpenTelemetryConfig | None = None
    pushover: PushoverConfig | None = None
    sources: List[SourceSpec] = Field(default_factory=list)
    routes: List[Route] = Field(default_factory=list)
    database: str | None = None
    server: str | bool | None = None

    # Optional: top-level command registry (auto-generates routes in cli.py)
    commands: CommandsConfig | None = None

    # Optional: top-level event registry for sending explicit events via MQTT
    events: EventsConfig | None = None

    # Optional: top-level group registry
    groups: GroupsConfig | None = None

    # Optional: top-level consumed items registry for tracking replacements
    consumed: ConsumedConfig | None = None

    def get_group_spec(self, name: str) -> GroupSpec | None:
        """Get group spec by name from the groups list."""
        if not self.groups:
            return None
        for grp in self.groups:
            if isinstance(grp, str) and grp == name:
                return GroupSpec.from_config_value(grp)
            if isinstance(grp, dict) and grp.get("name") == name:
                return GroupSpec.model_validate(grp)
            if isinstance(grp, GroupSpec) and grp.name == name:
                return grp
        return None

    def get_all_groups(self) -> List[GroupSpec]:
        """Get all groups as GroupSpec objects."""
        if not self.groups:
            return []
        result = []
        for grp in self.groups:
            if isinstance(grp, GroupSpec):
                result.append(grp)
            else:
                result.append(GroupSpec.from_config_value(grp))
        return result

    def get_command_spec(self, name: str) -> CommandSpec | None:
        """Get command spec by name from the commands list."""
        if not self.commands:
            return None
        for cmd in self.commands:
            if isinstance(cmd, str) and cmd == name:
                return CommandSpec.from_config_value(cmd)
            if isinstance(cmd, dict) and cmd.get("name") == name:
                return CommandSpec.model_validate(cmd)
            if isinstance(cmd, CommandSpec) and cmd.name == name:
                return cmd
        return None

    def get_all_commands(self) -> List[CommandSpec]:
        """Get all commands as CommandSpec objects."""
        if not self.commands:
            return []
        result = []
        for cmd in self.commands:
            if isinstance(cmd, CommandSpec):
                result.append(cmd)
            else:
                result.append(CommandSpec.from_config_value(cmd))
        return result

    def get_event_spec(self, name: str) -> EventSpec | None:
        """Get event spec by name from the events list."""
        if not self.events:
            return None
        for evt in self.events:
            if isinstance(evt, str) and evt == name:
                return EventSpec.from_config_value(evt)
            if isinstance(evt, dict) and evt.get("name") == name:
                return EventSpec.model_validate(evt)
            if isinstance(evt, EventSpec) and evt.name == name:
                return evt
        return None

    def get_all_events(self) -> List[EventSpec]:
        """Get all events as EventSpec objects."""
        if not self.events:
            return []
        result = []
        for evt in self.events:
            if isinstance(evt, EventSpec):
                result.append(evt)
            else:
                result.append(EventSpec.from_config_value(evt))
        return result

    def get_consumed_spec(self, name: str) -> ConsumedSpec | None:
        """Get consumed item spec by name from the consumed list."""
        if not self.consumed:
            return None
        for item in self.consumed:
            if isinstance(item, str) and item == name:
                return ConsumedSpec.from_config_value(item)
            if isinstance(item, dict) and item.get("name") == name:
                return ConsumedSpec.model_validate(item)
            if isinstance(item, ConsumedSpec) and item.name == name:
                return item
        return None

    def get_all_consumed(self) -> List[ConsumedSpec]:
        """Get all consumed items as ConsumedSpec objects."""
        if not self.consumed:
            return []
        result = []
        for item in self.consumed:
            if isinstance(item, ConsumedSpec):
                result.append(item)
            else:
                result.append(ConsumedSpec.from_config_value(item))
        return result
