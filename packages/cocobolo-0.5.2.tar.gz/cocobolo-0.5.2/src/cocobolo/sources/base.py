from __future__ import annotations

import asyncio
from abc import ABC, abstractmethod
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, GetCoreSchemaHandler
from pydantic_core import core_schema

from ..event import Event


class Source(ABC):
    def __init__(self, *, name: str, type: str | None = None):
        self.name = name
        self.type = type
        self._router = None
        self._task: asyncio.Task | None = None

    def bind(self, router) -> None:
        self._router = router

    @property
    def router(self):
        if self._router is None:
            raise RuntimeError(f"Source {self.name!r} not bound")
        return self._router

    async def emit(self, event: Event) -> None:
        await self.router.emit(event)

    def emit_nowait(self, event: Event) -> None:
        self.router.emit_nowait(event)

    async def start(self) -> None:
        if self._task and not self._task.done():
            return
        self._task = asyncio.create_task(self.run(), name=f"source:{self.name}")
        await self.ready()

    async def stop(self) -> None:
        if self._task and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass

    async def ready(self) -> None: ...

    @abstractmethod
    async def run(self) -> None:
        pass


class SourceSpec(BaseModel):
    """
    Polymorphic source spec model used in Config.sources.
    """

    model_config = ConfigDict(extra="allow")

    type: str = Field(...)
    name: str | None = None

    @classmethod
    def __get_pydantic_core_schema__(
        cls,
        source: type[Any],
        handler: GetCoreSchemaHandler,
    ) -> core_schema.CoreSchema:
        if cls.__name__ != "SourceSpec":
            return handler(source)
        return core_schema.no_info_plain_validator_function(cls._validate)

    @staticmethod
    def _validate(value: Any) -> "SourceSpec":
        from .registry import get_source_spec_model

        if isinstance(value, SourceSpec) and type(value) is not SourceSpec:
            return value

        if isinstance(value, dict):
            t = value.get("type")
            if not isinstance(t, str):
                raise ValueError("SourceSpec requires string field 'type'")
            model = get_source_spec_model(t)
            if model is None:
                raise ValueError(f"Unknown source type: {t}")
            return model.model_validate(value)

        raise TypeError("SourceSpec must be a dict or a concrete SourceSpec model")
