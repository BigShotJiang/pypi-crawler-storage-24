from __future__ import annotations

import asyncio
from typing import Any

from pydantic import Field

from ...event import Event
from ..base import Source, SourceSpec
from ..registry import register_source_factory, register_source_spec


@register_source_spec("interval")
class IntervalSourceSpec(SourceSpec):
    type: str = "interval"

    interval: float = Field(..., gt=0, description="Interval in seconds")
    topic: str = Field(default="timer/interval/$name", description="Event topic")
    event_type: str = Field(default="timer.tick", description="Event type")
    payload: Any = Field(
        default=None, description="Event payload (any JSON-like object)"
    )
    meta: dict[str, Any] = Field(default_factory=dict, description="Event meta map")


class IntervalSource(Source):
    def __init__(
        self,
        *,
        name: str,
        interval: float,
        topic: str,
        event_type: str,
        payload: Any,
        meta: dict[str, Any] | None = None,
    ):
        super().__init__(name=name, type="interval")
        self.interval = interval
        self.topic = topic
        self.event_type = event_type
        self.payload = payload
        self.meta = meta or {}

    async def run(self) -> None:
        # Expand $name in topic with the instance name; also allow router vars ($host, etc.).
        # We reuse Router's pattern_vars() and expand_pattern() rules.
        from ...router import expand_pattern

        vars = {}
        try:
            vars = self.router.pattern_vars()
        except Exception:
            vars = {}
        vars = dict(vars)
        vars.setdefault("name", self.name)

        topic = expand_pattern(self.topic, vars=vars)

        try:
            while True:
                await asyncio.sleep(self.interval)
                event = Event(
                    source=self.name,
                    type=self.event_type,
                    topic=topic,
                    payload=self.payload,
                    meta=dict(self.meta),
                )
                await self.emit(event)
        except asyncio.CancelledError:
            raise


@register_source_factory("interval")
def create_interval_source(spec: SourceSpec, deps: Any) -> IntervalSource:
    s = spec  # already validated into IntervalSourceSpec
    return IntervalSource(
        name=s.name or "interval",
        interval=getattr(s, "interval"),
        topic=getattr(s, "topic", "timer/interval/$name"),
        event_type=getattr(s, "event_type", "timer.tick"),
        payload=getattr(s, "payload", None),
        meta=getattr(s, "meta", {}),
    )


def init() -> None:
    return
