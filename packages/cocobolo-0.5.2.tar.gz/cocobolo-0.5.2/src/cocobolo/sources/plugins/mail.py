from __future__ import annotations

import asyncio
import gzip
import platform
import traceback
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Tuple, Optional

from email import policy
from email.message import Message
from email.parser import BytesParser

from watchdog.events import FileSystemEventHandler
from watchdog.observers import Observer

from sqlalchemy import Float, Integer, LargeBinary, String
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

from opentelemetry import trace

from ...config import Config
from ...event import Event
from ..base import Source, SourceSpec
from ..registry import register_source_factory, register_source_spec


@register_source_spec("mail")
class MailSourceSpec(SourceSpec):
    type: str = "mail"

    directory: str | None = None
    database: str | None = None

    settle_checks: int | None = None
    settle_interval: float | None = None
    gzip_level: int | None = None


class Base(DeclarativeBase):
    pass


class Mail(Base):
    __tablename__ = "mail"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)

    filename: Mapped[str] = mapped_column(String(512))
    received_at: Mapped[float] = mapped_column(Float)

    sender: Mapped[str | None] = mapped_column(String(1024), nullable=True)
    recipient: Mapped[str | None] = mapped_column(String(1024), nullable=True)
    subject: Mapped[str | None] = mapped_column(String(2048), nullable=True)
    attachment_count: Mapped[int] = mapped_column(Integer, default=0)

    # Store bytes compressed with gzip.
    raw: Mapped[bytes] = mapped_column(LargeBinary)


@dataclass(frozen=True)
class MailPaths:
    root: Path
    new_dir: Path
    old_dir: Path


class _MailHandler(FileSystemEventHandler):
    def __init__(self, src: "MailSource"):
        self.src = src

    def on_created(self, event):
        if event.is_directory:
            return
        src_path = event.src_path
        if isinstance(src_path, bytes):
            src_path = src_path.decode("utf-8")
        self.src._bridge_path(src_path)

    def on_modified(self, event):
        if event.is_directory:
            return
        src_path = event.src_path
        if isinstance(src_path, bytes):
            src_path = src_path.decode("utf-8")
        self.src._bridge_path(src_path)


class MailSource(Source):
    """
    Watches Postfix maildir 'new/' and for each new file:
    (1) waits briefly for it to settle,
    (2) parses headers + attachment count,
    (3) inserts into SQLite via SQLAlchemy (async), storing raw bytes gzip-compressed,
    (4) archives it into 'old/' as <filename>.gz.

    Compression is mandatory and unconditional.
    Timestamps are stored as Julian dates (float) in received_at.
    """

    def __init__(
        self,
        name: str = "mail",
        *,
        directory: str,
        database: str,
        settle_checks: int,
        settle_interval: float,
        gzip_level: int,
        host: str | None = None,
        logger: Any | None = None,
    ):
        super().__init__(name=name, type="mail")
        root = Path(directory).expanduser()
        self.paths = MailPaths(
            root=root,
            new_dir=root / "new",
            old_dir=root / "old",
        )
        self.settle_checks = settle_checks
        self.settle_interval = settle_interval
        self.gzip_level = gzip_level

        self.host = host or platform.node()

        self._observer: Any = None
        self._loop: Any = None
        self._q: asyncio.Queue[str] = asyncio.Queue()

        db_path = Path(database).expanduser()
        db_url = f"sqlite+aiosqlite:///{db_path}"
        db_path.parent.mkdir(parents=True, exist_ok=True)
        self._engine = create_async_engine(db_url, future=True)
        self._sessionmaker = async_sessionmaker(self._engine, expire_on_commit=False)

        self._tracer = trace.get_tracer("cocobolo.mail")
        self.logger = logger

    def _bridge_path(self, path: str) -> None:
        try:
            apath = Path(path).resolve()
            anew = self.paths.new_dir.resolve()

            # Accept files that are directly in new_dir.
            # (We schedule with recursive=False, but this keeps the guard explicit.)
            if apath.parent != anew:
                return
        except Exception:
            return

        if self._loop:
            self._loop.call_soon_threadsafe(self._q.put_nowait, path)

    async def _ensure_dirs(self) -> None:
        self.paths.new_dir.mkdir(parents=True, exist_ok=True)
        self.paths.old_dir.mkdir(parents=True, exist_ok=True)

    async def _init_db(self) -> None:
        async with self._engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)

    async def _wait_for_settle(self, path: str) -> bool:
        p = Path(path)
        last_size = None
        stable = 0

        for _ in range(self.settle_checks * 2):
            try:
                size = p.stat().st_size
            except FileNotFoundError:
                return False

            if last_size is not None and size == last_size:
                stable += 1
                if stable >= self.settle_checks:
                    return True
            else:
                stable = 0
                last_size = size

            await asyncio.sleep(self.settle_interval)

        return False

    @staticmethod
    def _read_bytes(path: Path) -> bytes:
        return path.read_bytes()

    @staticmethod
    def _gzip_compress_bytes(raw: bytes, *, level: int) -> bytes:
        return gzip.compress(raw, compresslevel=level)

    @staticmethod
    def _parse_email_metadata(
        raw: bytes,
    ) -> Tuple[Optional[str], Optional[str], Optional[str], int]:
        """
        Extract sender/recipient/subject and count "real" attachments.

        Attachment counting rule:
        We count parts with Content-Disposition == 'attachment'.
        This excludes most inline images used for rendering (typically 'inline').
        """
        try:
            msg: Message = BytesParser(policy=policy.default).parsebytes(raw)
        except Exception:
            return None, None, None, 0

        sender = msg.get("from")
        recipient = msg.get("to")
        subject = msg.get("subject")

        attachment_count = 0
        if msg.is_multipart():
            for part in msg.walk():
                if part.is_multipart():
                    continue

                disp = (part.get_content_disposition() or "").lower()
                if disp != "attachment":
                    continue

                # Stronger "real attachment" signal than MIME type:
                filename = part.get_filename()
                if not filename:
                    continue

                attachment_count += 1

        return sender, recipient, subject, attachment_count

    @staticmethod
    def _gzip_write_bytes(dest: Path, gz_bytes: bytes) -> None:
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(gz_bytes)

    @staticmethod
    def _to_julian_date(dt: datetime) -> float:
        """
        Convert a timezone-aware UTC datetime to Julian Date (JD) as float.

        JD = unix_seconds / 86400 + 2440587.5
        """
        if dt.tzinfo is None:
            raise ValueError("datetime must be timezone-aware")
        dt_utc = dt.astimezone(timezone.utc)
        return dt_utc.timestamp() / 86400.0 + 2440587.5

    async def _archive_message(
        self,
        *,
        src_path: Path,
        dest_dir: Path,
        filename: str,
        gz_bytes: bytes,
        received_dt: datetime,
    ) -> Path:
        dt_utc = received_dt.astimezone(timezone.utc)
        subdir = dest_dir / f"{dt_utc.year:04d}" / f"{dt_utc.month:02d}"
        dest = subdir / f"{filename}.gz"

        await asyncio.to_thread(self._gzip_write_bytes, dest, gz_bytes)
        try:
            src_path.unlink(missing_ok=True)
        except Exception:
            pass
        return dest

    async def _store_and_move(self, path: str) -> None:
        p = Path(path)
        filename = p.name

        with self._tracer.start_as_current_span("mail.process") as span:
            span.set_attribute("mail.path", str(p))

            if not await self._wait_for_settle(path):
                span.add_event("mail.not_settled_or_missing")
                return

            received_dt = datetime.now(timezone.utc)
            received_at = self._to_julian_date(received_dt)

            try:
                raw = await asyncio.to_thread(self._read_bytes, p)
                span.set_attribute("mail.raw_size", len(raw))
            except FileNotFoundError:
                span.add_event("mail.missing_after_settle")
                return
            except Exception as e:
                span.record_exception(e)
                span.set_status(trace.Status(trace.StatusCode.ERROR, "read_failed"))
                return

            with self._tracer.start_as_current_span("mail.parse") as pspan:
                try:
                    sender, recipient, subject, attachment_count = (
                        self._parse_email_metadata(raw)
                    )
                    if sender is not None:
                        pspan.set_attribute("mail.sender", sender)
                    if recipient is not None:
                        pspan.set_attribute("mail.recipient", recipient)
                    if subject is not None:
                        pspan.set_attribute("mail.subject", subject)
                    pspan.set_attribute("mail.attachment_count", attachment_count)
                except Exception as e:
                    pspan.record_exception(e)
                    pspan.set_status(
                        trace.Status(trace.StatusCode.ERROR, "parse_failed")
                    )
                    return

            with self._tracer.start_as_current_span("mail.compress") as cspan:
                try:
                    gz_bytes = await asyncio.to_thread(
                        self._gzip_compress_bytes, raw, level=self.gzip_level
                    )
                    cspan.set_attribute("mail.gz_size", len(gz_bytes))
                except Exception as e:
                    cspan.record_exception(e)
                    cspan.set_status(
                        trace.Status(trace.StatusCode.ERROR, "compress_failed")
                    )
                    return

            with self._tracer.start_as_current_span("mail.db_insert") as dspan:
                try:
                    async with self._sessionmaker() as session:
                        session.add(
                            Mail(
                                filename=filename,
                                received_at=received_at,
                                sender=sender,
                                recipient=recipient,
                                subject=subject,
                                attachment_count=attachment_count,
                                raw=gz_bytes,
                            )
                        )
                        await session.commit()
                except Exception as e:
                    dspan.record_exception(e)
                    dspan.set_status(
                        trace.Status(trace.StatusCode.ERROR, "db_insert_failed")
                    )
                    return

            with self._tracer.start_as_current_span("mail.archive") as aspan:
                try:
                    dest = await self._archive_message(
                        src_path=p,
                        dest_dir=self.paths.old_dir,
                        filename=filename,
                        gz_bytes=gz_bytes,
                        received_dt=received_dt,
                    )
                    aspan.set_attribute("mail.archive_path", str(dest))
                except Exception as e:
                    aspan.record_exception(e)
                    aspan.set_status(
                        trace.Status(trace.StatusCode.ERROR, "archive_failed")
                    )
                    return

            with self._tracer.start_as_current_span("mail.emit_event") as espan:
                try:
                    await self.emit(
                        Event(
                            source=self.name,
                            type="mail.received",
                            topic=f"mail/{filename}",
                            payload={
                                "filename": filename,
                                "sender": sender,
                                "recipient": recipient,
                                "subject": subject,
                                "attachment_count": attachment_count,
                                "received_at": received_dt.astimezone(timezone.utc)
                                .isoformat(timespec="seconds")
                                .replace("+00:00", "Z"),
                            },
                            meta={"path": str(p), "host": self.host},
                        )
                    )
                except Exception as e:
                    espan.record_exception(e)
                    espan.set_status(
                        trace.Status(trace.StatusCode.ERROR, "emit_failed")
                    )
                    return

    async def run(self) -> None:
        self._loop = asyncio.get_running_loop()

        try:
            await self._ensure_dirs()
            await self._init_db()

            self._observer = Observer()
            handler = _MailHandler(self)
            if self._observer is None:
                raise RuntimeError("Failed to create observer")
            self._observer.schedule(handler, str(self.paths.new_dir), recursive=False)
            self._observer.start()

            while True:
                path = await self._q.get()
                with self._tracer.start_as_current_span("mail.queue_item") as qspan:
                    qspan.set_attribute("mail.queued_path", path)
                    try:
                        await self._store_and_move(path)
                    except Exception as e:
                        qspan.record_exception(e)
                        qspan.set_status(
                            trace.Status(trace.StatusCode.ERROR, "processing_exception")
                        )
                        if self.logger:
                            self.logger.error(
                                f"[mail] exception while processing path={path!r}: {e}",
                                exc_info=True,
                            )
                        elif getattr(self.router, "verbose", False):
                            print(
                                f"[mail] exception while processing path={path!r}: {e}",
                                flush=True,
                            )
                            traceback.print_exc()
        finally:
            if self._observer:
                self._observer.stop()
                self._observer.join(timeout=5)
            self._observer = None
            self._loop = None
            await self._engine.dispose()


@register_source_factory("mail")
def create_mail_source(spec: SourceSpec, deps: Any) -> MailSource:
    """Create mail source from spec."""
    config = getattr(deps, "config", None)
    if not isinstance(config, Config):
        raise ValueError("mail source factory requires deps.config to be a Config")

    database = getattr(spec, "database", None) or config.database
    if not isinstance(database, str) or not database.strip():
        raise ValueError(
            "mail source requires a database; set source.database or top-level config.database"
        )

    return MailSource(
        name=spec.name or "mail",
        directory=getattr(spec, "directory"),
        database=database,
        settle_checks=getattr(spec, "settle_checks", None) or 5,
        settle_interval=getattr(spec, "settle_interval", None) or 0.05,
        gzip_level=getattr(spec, "gzip_level", None) or 6,
        logger=getattr(deps, "logger", None),
    )


def init() -> None:
    return


__all__ = ["MailSource", "MailSourceSpec", "MailPaths", "create_mail_source", "init"]
