from __future__ import annotations

import asyncio
import platform
from typing import Any

from datetime import datetime, timezone
import psutil

from ...event import Event
from ..base import Source, SourceSpec
from ..registry import register_source_spec, register_source_factory


@register_source_spec("heartbeat")
class HeartbeatSourceSpec(SourceSpec):
    type: str = "heartbeat"
    interval: int = 60
    host: str | None = None


class HeartbeatSource(Source):
    def __init__(
        self, name: str = "heartbeat", *, host: str | None = None, interval: int = 60
    ):
        super().__init__(name=name, type="heartbeat")
        self.interval = interval
        self.host = host or platform.node()
        self.started = (
            datetime.now(timezone.utc)
            .isoformat(timespec="seconds")
            .replace("+00:00", "Z")
        )
        psutil.cpu_percent(interval=None)

    def _timestamp(self) -> str:
        return (
            datetime.now(timezone.utc)
            .isoformat(timespec="seconds")
            .replace("+00:00", "Z")
        )

    def _uptime_s(self) -> float:
        now = datetime.now(timezone.utc).timestamp()
        return max(0.0, now - float(psutil.boot_time()))

    def _cpu_percent(self) -> float:
        return float(psutil.cpu_percent(interval=None))

    def _cpu_temp_c(self) -> float | None:
        temps = psutil.sensors_temperatures(fahrenheit=False)
        if not temps:
            return None

        # Pick a reasonable sensor reading: highest current value across all sensors.
        best: float | None = None
        for entries in temps.values():
            for t in entries:
                if t.current is None:
                    continue
                cur = float(t.current)
                best = cur if best is None else max(best, cur)
        return best

    async def run(self) -> None:
        from ...actions.plugins.exec import get_running_commands

        await asyncio.sleep(1)
        while True:
            # Get running commands if router is available
            commands = []
            if self._router:
                commands = get_running_commands(self._router)

            await self.emit(
                Event(
                    source=self.name,
                    type="heartbeat",
                    topic=f"heartbeat/{self.host}",
                    payload={
                        "host": self.host,
                        "time": self._timestamp(),
                        "started": self.started,
                        "uptime": self._uptime_s(),
                        "cpu": {
                            "utilization": self._cpu_percent(),
                            "temperature": self._cpu_temp_c(),
                        },
                        "commands": commands,
                    },
                    meta={"host": self.host},
                )
            )
            await asyncio.sleep(self.interval)


@register_source_factory("heartbeat")
def create_heartbeat_source(spec: SourceSpec, deps: Any) -> HeartbeatSource:
    """Create heartbeat source from spec"""
    host = getattr(spec, "host", None) or getattr(deps, "node_name", None)
    return HeartbeatSource(
        name=spec.name or "heartbeat",
        host=host,
        interval=getattr(spec, "interval", 60),
    )


def init() -> None:
    """
    Packaging entry point initializer.

    The module-level decorators already performed registration at import time.
    This function exists so the entry point can call something explicit and
    future-proof.
    """
    return


__all__ = ["HeartbeatSource", "HeartbeatSourceSpec", "create_heartbeat_source", "init"]
