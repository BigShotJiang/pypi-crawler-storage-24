from __future__ import annotations

import asyncio
import platform
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Sequence

from watchdog.events import FileSystemEventHandler
from watchdog.observers import Observer

from ...event import Event
from ..base import Source, SourceSpec
from ..registry import register_source_factory, register_source_spec


@register_source_spec("watch")
class WatchSourceSpec(SourceSpec):
    type: str = "watch"

    paths: Sequence[str]
    recursive: bool = False

    # Which event types to emit. If empty/None, emit all supported.
    events: Sequence[str] | None = (
        None  # e.g. ["created", "modified", "deleted", "moved"]
    )

    # If True, also emit directory events (watchdog often emits dir events too).
    include_directories: bool = False

    # If True, resolve to absolute real paths.
    resolve: bool = True


@dataclass(frozen=True)
class _WatchItem:
    root: Path
    recursive: bool


class _WatchHandler(FileSystemEventHandler):
    def __init__(self, src: "WatchSource"):
        self.src = src

    def on_any_event(self, event):
        # watchdog calls us from an observer thread; do not touch asyncio directly
        self.src._bridge_event(event)


class WatchSource(Source):
    """
    Watches one or more filesystem paths and emits events:
      type: "watch.<kind>"  (created|modified|deleted|moved)
      topic: "watch/<name>/<relative_or_basename>"
      payload: structured dict including src/dest paths, is_directory, etc.

    Bridge design:
    - watchdog Observer runs in a separate thread
    - we push raw watchdog events into an asyncio.Queue via call_soon_threadsafe
    - the async task drains queue and emits cocobolo Events
    """

    def __init__(
        self,
        name: str = "watch",
        *,
        paths: Sequence[str],
        recursive: bool = False,
        events: Sequence[str] | None = None,
        include_directories: bool = False,
        resolve: bool = True,
        host: str | None = None,
        logger: Any | None = None,
    ):
        super().__init__(name=name, type="watch")
        if not paths:
            raise ValueError("watch source requires non-empty 'paths'")

        self.host = host or platform.node()
        self.logger = logger

        self.include_directories = include_directories
        self.resolve = resolve

        allowed = {"created", "modified", "deleted", "moved"}
        if events is None:
            self.events = allowed
        else:
            bad = [e for e in events if e not in allowed]
            if bad:
                raise ValueError(f"watch.events contains unsupported values: {bad!r}")
            self.events = set(events)

        items: list[_WatchItem] = []
        for p in paths:
            root = Path(p).expanduser()
            if self.resolve:
                root = root.resolve()
            items.append(_WatchItem(root=root, recursive=recursive))
        self._items = items

        self._observer: Any = None
        self._loop: Any = None
        self._q: asyncio.Queue[Any] = asyncio.Queue()

    def _bridge_event(self, ev: Any) -> None:
        if self._loop is None:
            return
        # Filter directory events early if requested.
        if getattr(ev, "is_directory", False) and not self.include_directories:
            return
        self._loop.call_soon_threadsafe(self._q.put_nowait, ev)

    def _event_kind(self, ev: Any) -> str:
        # watchdog event types are strings like 'modified', 'created', etc.
        return str(getattr(ev, "event_type", "")).lower()

    def _pick_root(self, path: Path) -> Path | None:
        # Choose the deepest matching root (best relative path).
        best: Path | None = None
        for item in self._items:
            try:
                path.relative_to(item.root)
            except Exception:
                continue
            if best is None or len(str(item.root)) > len(str(best)):
                best = item.root
        return best

    def _topic_for(self, p: Path) -> str:
        root = self._pick_root(p)
        if root is None:
            # Fall back to basename to keep topic "safe" and short.
            rel = p.name
        else:
            try:
                rel = str(p.relative_to(root))
            except Exception:
                rel = p.name
        # Normalize to MQTT-ish forward slashes.
        rel = rel.replace("\\", "/")
        return f"watch/{self.name}/{rel}"

    async def run(self) -> None:
        self._loop = asyncio.get_running_loop()

        self._observer = Observer()
        handler = _WatchHandler(self)
        if self._observer is None:
            raise RuntimeError("Failed to create observer")

        # Schedule each root separately (watchdog requires directory scheduling;
        # if a file is provided, schedule its parent and filter by prefix).
        for item in self._items:
            root = item.root
            if root.is_dir():
                watch_dir = root
            else:
                watch_dir = root.parent

            watch_dir.mkdir(parents=True, exist_ok=True)
            self._observer.schedule(handler, str(watch_dir), recursive=item.recursive)

        self._observer.start()

        try:
            while True:
                ev = await self._q.get()
                kind = self._event_kind(ev)
                if kind not in self.events:
                    continue

                src_path = Path(getattr(ev, "src_path", "")).expanduser()
                if self.resolve:
                    try:
                        src_path = src_path.resolve()
                    except Exception:
                        pass

                dest_path = None
                if kind == "moved":
                    dp = getattr(ev, "dest_path", None)
                    if dp:
                        dest_path = Path(dp).expanduser()
                        if self.resolve:
                            try:
                                dest_path = dest_path.resolve()
                            except Exception:
                                pass

                payload = {
                    "event": kind,
                    "src_path": str(src_path),
                    "dest_path": str(dest_path) if dest_path else None,
                    "is_directory": bool(getattr(ev, "is_directory", False)),
                    "host": self.host,
                }

                # For "moved", the more useful topic is often the destination.
                topic_path = dest_path or src_path
                await self.emit(
                    Event(
                        source=self.name,
                        type=f"watch.{kind}",
                        topic=self._topic_for(topic_path),
                        payload=payload,
                        meta={"host": self.host},
                    )
                )
        finally:
            if self._observer:
                self._observer.stop()
                self._observer.join(timeout=5)
            self._observer = None
            self._loop = None


@register_source_factory("watch")
def create_watch_source(spec: SourceSpec, deps: Any) -> WatchSource:
    s = spec  # already validated to WatchSourceSpec
    return WatchSource(
        name=s.name or "watch",
        paths=getattr(s, "paths", []),
        recursive=getattr(s, "recursive", False),
        events=getattr(s, "events", None),
        include_directories=getattr(s, "include_directories", False),
        resolve=getattr(s, "resolve", True),
        host=getattr(deps, "node_name", None),
        logger=getattr(deps, "logger", None),
    )


def init() -> None:
    return


__all__ = ["WatchSource", "WatchSourceSpec", "create_watch_source", "init"]
