from __future__ import annotations

import asyncio
import heapq
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from typing import Any

from pydantic import Field

from ...event import Event
from ...router import expand_pattern
from ..base import Source, SourceSpec
from ..registry import register_source_factory, register_source_spec


def _ensure_aware_utc(dt: datetime) -> datetime:
    # If user passes naive datetime, treat it as UTC (explicit, predictable).
    # If you want strictness, change this to raise ValueError instead.
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


@dataclass(order=True)
class _Job:
    when: float
    job_id: str = field(compare=False)
    topic: str = field(compare=False)
    event_type: str = field(compare=False)
    payload: Any = field(compare=False)
    meta: dict[str, Any] = field(compare=False, default_factory=dict)
    source_name: str = field(compare=False, default="")


@register_source_spec("scheduler")
class SchedulerSourceSpec(SourceSpec):
    type: str = "scheduler"

    default_topic: str = Field(
        default="timer/scheduled/$name",
        description="Default topic for scheduled events (can be overridden per job)",
    )
    default_event_type: str = Field(
        default="timer.once",
        description="Default event type for scheduled events (can be overridden per job)",
    )


class SchedulerSource(Source):
    """
    In-memory one-shot scheduler. Jobs are lost on restart.

    Threading model: purely asyncio. Jobs are enqueued by action handlers running
    in the same event loop as Router.dispatch.
    """

    def __init__(
        self,
        *,
        name: str,
        default_topic: str,
        default_event_type: str,
    ):
        super().__init__(name=name, type="scheduler")
        self.default_topic = default_topic
        self.default_event_type = default_event_type

        self._cv = asyncio.Condition()
        self._heap: list[_Job] = []
        self._stopped = False

    async def schedule_once(
        self,
        *,
        at: datetime | None = None,
        after: float | None = None,
        topic: str | None = None,
        event_type: str | None = None,
        payload: Any = None,
        meta: dict[str, Any] | None = None,
        job_id: str | None = None,
    ) -> str:
        if (at is None) == (after is None):
            raise ValueError("Provide exactly one of: at (datetime) or after (seconds)")

        if after is not None:
            if after < 0:
                raise ValueError("'after' must be >= 0")

            when_dt = datetime.now(timezone.utc) + timedelta(seconds=after)
        else:
            when_dt = _ensure_aware_utc(at)  # type: ignore[arg-type]

        when_ts = when_dt.timestamp()

        # Expand topic defaults and $variables ($host from router, $name from source name).
        vars = {}
        try:
            vars = self.router.pattern_vars()
        except Exception:
            vars = {}
        vars = dict(vars)
        vars.setdefault("name", self.name)

        final_topic = expand_pattern(topic or self.default_topic, vars=vars)
        final_type = event_type or self.default_event_type

        job_id = job_id or str(uuid.uuid4())
        job = _Job(
            when=when_ts,
            job_id=job_id,
            topic=final_topic,
            event_type=final_type,
            payload=payload,
            meta=dict(meta or {}),
            source_name=self.name,
        )

        async with self._cv:
            heapq.heappush(self._heap, job)
            self._cv.notify()

        return job_id

    async def run(self) -> None:
        try:
            while True:
                job: _Job | None = None
                now = datetime.now(timezone.utc).timestamp()

                async with self._cv:
                    while True:
                        if not self._heap:
                            await self._cv.wait()
                            continue

                        next_job = self._heap[0]
                        delay = next_job.when - now
                        if delay <= 0:
                            job = heapq.heappop(self._heap)
                            break

                        try:
                            await asyncio.wait_for(self._cv.wait(), timeout=delay)
                        except TimeoutError:
                            # Time reached; loop will pop
                            now = datetime.now(timezone.utc).timestamp()
                            continue

                if job is not None:
                    event = Event(
                        source=self.name,
                        type=job.event_type,
                        topic=job.topic,
                        payload=job.payload,
                        meta=job.meta,
                    )
                    await self.emit(event)

        except asyncio.CancelledError:
            raise


@register_source_factory("scheduler")
def create_scheduler_source(spec: SourceSpec, deps: Any) -> SchedulerSource:
    s = spec  # already validated into SchedulerSourceSpec
    return SchedulerSource(
        name=s.name or "scheduler",
        default_topic=getattr(s, "default_topic", "timer/scheduled/$name"),
        default_event_type=getattr(s, "default_event_type", "timer.once"),
    )


def init() -> None:
    return
