from __future__ import annotations

import asyncio
import json
from typing import Any, Sequence

from pydantic import BaseModel, Field
import paho.mqtt.client as mqtt  # type: ignore

from ...event import Event
from ...router import expand_pattern  # variable expansion shared with Router
from ..base import Source, SourceSpec
from ..registry import register_source_spec, register_source_factory


class BrokerConfig(BaseModel):
    host: str = "localhost"
    port: int = 1883
    tls: bool = False
    username: str | None = None
    password: str | None = None
    client_id: str | None = None


class MqttBroker:
    """
    Minimal wrapper around paho-mqtt.
    Intentionally tiny: connect/start/stop/publish.
    """

    def __init__(
        self, *, config: BrokerConfig, loop: asyncio.AbstractEventLoop | None = None
    ):
        self.config = config

        if not loop:
            loop = asyncio.get_running_loop()
        self._loop = loop
        self._ready = loop.create_future()

        self.client = mqtt.Client(
            client_id=config.client_id,
            callback_api_version=mqtt.CallbackAPIVersion.VERSION2,  # type: ignore
        )

        if config.username is not None:
            self.client.username_pw_set(config.username, config.password)
        if config.tls:
            self.client.tls_set()

        self._connected = False

        self.client.on_connect = self._on_connect
        self.client.on_disconnect = self._on_disconnect

    def _on_connect(self, client, userdata, flags, reason_code, properties=None):
        def resolve():
            if self._ready is None or self._ready.done():
                return
            if not reason_code.is_failure:
                self._connected = True
                self._ready.set_result(True)
            else:
                self._ready.set_exception(
                    Exception(f"MQTT connect failed: {reason_code}")
                )

        self._loop.call_soon_threadsafe(resolve)

    def _on_disconnect(self, client, userdata, flags, reason_code, properties=None):
        self._connected = False

    def ready(self):
        return self._ready

    def start(self):
        self.client.connect(self.config.host, self.config.port, keepalive=60)
        self.client.loop_start()

    def stop(self) -> None:
        try:
            self.client.disconnect()
        finally:
            self.client.loop_stop()

    def publish(
        self, topic: str, payload: bytes, *, qos: int = 1, retain: bool = False
    ) -> None:
        self.client.publish(topic, payload, qos=qos, retain=retain)


@register_source_spec("mqtt")
class MqttSourceSpec(SourceSpec):
    type: str = "mqtt"
    subscriptions: Sequence[str]
    qos: int = 1
    json_decode: bool = True

    broker: BrokerConfig = Field(default_factory=BrokerConfig)


class MqttSource(Source):
    """
    Clean minimal async/thread bridge:

    - Paho runs callbacks on its own thread (loop_start()).
    - We *never* create tasks in that thread.
    - We use loop.call_soon_threadsafe(queue.put_nowait, event) via router.emit_nowait.
    """

    def __init__(
        self,
        *,
        name: str,
        subscriptions: Sequence[str],
        qos: int = 1,
        json_decode: bool = True,
        broker: BrokerConfig,
    ):
        super().__init__(name=name, type="mqtt")
        self.service = MqttBroker(config=broker)
        self.subscriptions = list(subscriptions)
        self.qos = qos
        self.json_decode = json_decode

    async def ready(self) -> None:
        await self.service.ready()

    async def run(self) -> None:
        loop = asyncio.get_running_loop()

        self.service.start()

        def on_message(client, userdata, msg, properties=None):
            payload: Any = msg.payload
            if self.json_decode:
                try:
                    payload = json.loads(msg.payload.decode("utf-8"))
                except Exception:
                    pass

            event = Event(
                source=self.name,
                type="mqtt.message",
                topic=msg.topic,
                payload=payload,
            )
            loop.call_soon_threadsafe(self.emit_nowait, event)

        # Expand subscriptions using router-provided variables (e.g. $host).
        vars = {}
        try:
            vars = self.router.pattern_vars()
        except Exception:
            vars = {}

        for sub in self.subscriptions:
            expanded_sub = expand_pattern(sub, vars=vars)
            self.service.client.message_callback_add(expanded_sub, on_message)
            self.service.client.subscribe(expanded_sub, qos=self.qos)

        try:
            while True:
                await asyncio.sleep(3600)
        finally:
            for sub in self.subscriptions:
                expanded_sub = expand_pattern(sub, vars=vars)
                try:
                    self.service.client.message_callback_remove(expanded_sub)
                except Exception:
                    pass
            self.service.stop()


@register_source_factory("mqtt")
def create_mqtt_source(spec: SourceSpec, deps: Any) -> MqttSource:
    s = spec  # already validated into MqttSourceSpec
    return MqttSource(
        name=s.name or "mqtt",
        subscriptions=getattr(s, "subscriptions", []),
        qos=getattr(s, "qos", 1),
        json_decode=getattr(s, "json_decode", True),
        broker=getattr(s, "broker"),
    )


def init() -> None:
    return
