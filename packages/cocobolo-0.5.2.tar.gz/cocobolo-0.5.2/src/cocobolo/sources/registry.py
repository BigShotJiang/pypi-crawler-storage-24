from __future__ import annotations

from typing import Any, Callable, Dict, Type, TypeVar

from .base import Source, SourceSpec

SourceT = TypeVar("SourceT", bound=Source)
SpecT = TypeVar("SpecT", bound=SourceSpec)

_SOURCE_SPECS: Dict[str, Type[SourceSpec]] = {}
_SOURCE_FACTORIES: Dict[str, Callable[[SourceSpec, Any], Source]] = {}


def reset_sources_registry() -> None:
    """
    Clear registered source specs and factories.

    Intended for tests (e.g. pytest) to ensure isolation between runs.
    """
    _SOURCE_SPECS.clear()
    _SOURCE_FACTORIES.clear()


def register_source_spec(source_type: str):
    def decorator(cls: Type[SpecT]) -> Type[SpecT]:
        existing = _SOURCE_SPECS.get(source_type)
        if existing and existing is not cls:
            raise ValueError(f"Source spec already registered: {source_type}")
        _SOURCE_SPECS[source_type] = cls
        return cls

    return decorator


def register_source_factory(source_type: str):
    def decorator(fn: Callable[[SourceSpec, Any], Source]):
        _SOURCE_FACTORIES[source_type] = fn
        return fn

    return decorator


def get_source_spec_model(source_type: str) -> Type[SourceSpec] | None:
    return _SOURCE_SPECS.get(source_type)


def get_source_factory(source_type: str):
    return _SOURCE_FACTORIES.get(source_type)
