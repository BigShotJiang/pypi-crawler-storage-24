from __future__ import annotations

from pathlib import Path

import uvicorn
from fastapi import Request


async def run(
    db_path: Path, config, host: str = "127.0.0.1", port: int = 15315
) -> None:
    """Run the FastAPI server for the dashboard."""
    # Lazy imports - only loaded when server is started
    from fastapi import FastAPI
    from fastapi.responses import HTMLResponse
    from fasthtml import ft
    from fasthtml.core import to_xml

    from .dashboard import register_dashboard_routes
    from .mail_viewer import register_mail_routes
    from .commands import register_command_routes
    from .events import register_event_routes
    from .consumed import register_consumed_routes
    from .navigation import create_nav, NAV_CSS
    from .middleware import ForwardedPrefixMiddleware

    app_fastapi = FastAPI(title="cocobolo")

    # Add middleware to handle reverse proxy headers
    app_fastapi.add_middleware(ForwardedPrefixMiddleware)

    # Add CORS middleware to allow API requests from the same origin
    from fastapi.middleware.cors import CORSMiddleware

    app_fastapi.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Register dashboard API routes (HTML fragments + JSON endpoints)
    register_dashboard_routes(app_fastapi, db_path=db_path, config=config)

    # Register mail viewer routes
    register_mail_routes(app_fastapi, db_path=db_path, config=config)

    # Register command execution routes
    register_command_routes(app_fastapi, db_path=db_path, config=config)

    # Register event routes
    register_event_routes(app_fastapi, db_path=db_path, config=config)

    # Register consumed item routes
    register_consumed_routes(app_fastapi, db_path=db_path, config=config)

    @app_fastapi.get("/", name="index")
    async def index(request: Request):
        """Main page with htmx auto-refresh."""
        page = ft.Html(
            ft.Head(
                ft.Title("cocobolo"),
                ft.Script(src="https://unpkg.com/htmx.org@2.0.4"),
                ft.Style(
                    """
                    :root {
                        --bg-color: #f5f5f5;
                        --container-bg: #ffffff;
                        --text-color: #333333;
                        --text-secondary: #666666;
                        --border-color: #dddddd;
                        --table-header-bg: #f8f8f8;
                        --table-row-hover: #f5f5f5;

                        --panel-shadow: 0 2px 4px rgba(0,0,0,0.1);

                        --chart-bg: #fafafa;

                        --status-online: #4caf50;
                        --status-stale: #f44336;
                        --status-offline: #9e9e9e;

                        --nav-bg: #ffffff;
                        --nav-border: #e0e0e0;
                        --nav-link-color: #666666;
                        --nav-link-active: #2196f3;
                        --nav-link-hover: #333333;
                    }
                    @media (prefers-color-scheme: dark) {
                        :root {
                            --bg-color: #1a1a1a;
                            --container-bg: #2d2d2d;
                            --text-color: #e0e0e0;
                            --text-secondary: #a0a0a0;
                            --border-color: #444444;
                            --table-header-bg: #3d3d3d;
                            --table-row-hover: #3a3a3a;

                            --panel-shadow: 0 2px 6px rgba(0,0,0,0.4);

                            --chart-bg: #262626;

                            --nav-bg: #2d2d2d;
                            --nav-border: #444444;
                            --nav-link-color: #a0a0a0;
                            --nav-link-active: #64b5f6;
                            --nav-link-hover: #e0e0e0;
                        }
                    }
                    body {
                        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                        margin: 0;
                        padding: 0;
                        background: var(--bg-color);
                        color: var(--text-color);
                        transition: background 0.3s, color 0.3s;
                    }
                    .container {
                        max-width: 800px;
                        margin: 0 auto;
                        padding: 20px;
                    }

                    h1 { color: var(--text-color); margin-bottom: 20px; }

                    .panel {
                        background: var(--container-bg);
                        border: 1px solid var(--border-color);
                        border-radius: 8px;
                        padding: 15px;
                        box-shadow: var(--panel-shadow);
                        overflow-x: auto;
                    }

                    table {
                        width: 100%;
                        border-collapse: collapse;
                        font-size: 14px;
                        background: var(--container-bg);
                    }
                    th {
                        text-align: left;
                        padding: 12px;
                        border-bottom: 2px solid var(--border-color);
                        background: var(--table-header-bg);
                        color: var(--text-color);
                    }
                    td {
                        padding: 12px;
                        border-bottom: 1px solid var(--border-color);
                        color: var(--text-color);
                    }
                    tr:hover { background-color: var(--table-row-hover); }

                    .hint {
                        color: var(--text-secondary);
                        font-size: 12px;
                        margin-bottom: 10px;
                        font-style: italic;
                    }

                    .row-clickable { cursor: pointer; }

                    .host-online { color: var(--status-online); font-weight: 600; }
                    .host-stale { color: var(--status-stale); font-weight: 600; }

                    .row-offline td {
                        color: var(--status-offline);
                        font-style: italic;
                    }

                    .temp-warm { color: #ff9800; font-weight: 600; }
                    .temp-hot { color: #f44336; font-weight: 600; }

                    .has-commands {
                        color: #2196f3;
                        font-weight: 600;
                    }

                    button {
                        background: #2196f3;
                        color: white;
                        border: none;
                        padding: 8px 16px;
                        border-radius: 4px;
                        cursor: pointer;
                    }
                    button:hover { background: #1976d2; }

                    .status-badge {
                        color: white;
                        padding: 4px 12px;
                        border-radius: 4px;
                        font-size: 14px;
                        font-weight: bold;
                        display: inline-block;
                        margin-bottom: 15px;
                    }

                    .chart {
                        background: var(--chart-bg);
                        border-radius: 4px;
                    }

                    """,
                ),
                ft.Style(NAV_CSS),
            ),
            ft.Body(
                create_nav(request, active="index"),
                ft.Div(
                    ft.H1("Dashboard"),
                    ft.Div(
                        id="dashboard-content",
                        hx_get="api/dashboard",
                        hx_trigger="load, every 10s",
                        hx_swap="innerHTML",
                        style="min-height: 200px;",
                    ),
                    cls="container",
                ),
            ),
        )
        return HTMLResponse(to_xml(page))

    print(f"Starting server at http://{host}:{port}", flush=True)
    config_uvicorn = uvicorn.Config(app_fastapi, host=host, port=port, log_level="info")
    server = uvicorn.Server(config_uvicorn)
    await server.serve()
