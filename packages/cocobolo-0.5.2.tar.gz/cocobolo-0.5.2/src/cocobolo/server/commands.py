from __future__ import annotations

import json
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any, Dict

from fastapi import Request, HTTPException
from fastapi.responses import HTMLResponse
from fasthtml import ft
from fasthtml.core import to_xml

from ..config import Config
from ..sources.plugins.mqtt import BrokerConfig, MqttBroker
from .navigation import create_nav


def register_command_routes(app_fastapi: Any, db_path: Path, config: Config) -> None:
    """Register command execution routes onto an existing FastAPI app."""

    from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker
    from sqlalchemy import select, func, Table, MetaData

    db_url = f"sqlite+aiosqlite:///{db_path}"
    engine = create_async_engine(db_url, future=True)
    async_session = async_sessionmaker(engine, expire_on_commit=False)

    async def load_table():
        async with engine.connect() as conn:
            metadata = MetaData()
            return await conn.run_sync(
                lambda sync_conn: Table("heartbeat", metadata, autoload_with=sync_conn)
            )

    table_holder: dict[str, Any] = {"table": None}

    async def ensure_table() -> Any:
        if table_holder["table"] is None:
            table_holder["table"] = await load_table()
        return table_holder["table"]

    def get_mqtt_broker() -> BrokerConfig | None:
        """Get MQTT broker config - prefer 'main', else use the only one."""
        mqtt_sources = []
        for source in config.sources:
            if getattr(source, "type", None) == "mqtt":
                mqtt_sources.append(source)

        if not mqtt_sources:
            return None

        # Prefer broker named "main"
        for source in mqtt_sources:
            broker = getattr(source, "broker", None)
            if broker and getattr(broker, "client_id", None) == "main":
                return broker

        # Otherwise use the first one
        return getattr(mqtt_sources[0], "broker", None)

    async def get_online_hosts() -> list[str]:
        """Get list of online hosts from heartbeat table (active in last 2 minutes)."""
        table = await ensure_table()
        async with async_session() as session:
            # Get latest heartbeat per host
            subq = (
                select(func.max(table.c.id).label("max_id"), table.c.host)
                .group_by(table.c.host)
                .subquery()
            )
            stmt = select(table).join(subq, table.c.id == subq.c.max_id)
            result = await session.execute(stmt)
            rows = result.fetchall()

            online_hosts = []
            now = datetime.now(timezone.utc)

            for row in rows:
                host = row.host
                # Convert julian day to datetime
                J2000 = 2451545.0
                J2000_DATETIME = datetime(2000, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
                last_seen = J2000_DATETIME + timedelta(days=row.ts - J2000)

                # Host is online if seen in last 2 minutes
                if (now - last_seen).total_seconds() < 120:
                    online_hosts.append(host)

            return sorted(online_hosts)

    @app_fastapi.get("/api/commands")
    async def api_commands():
        """Get available commands and online hosts."""
        commands_list = []
        if config.commands:
            for cmd in config.get_all_commands():
                cmd_dict = {
                    "name": cmd.name,
                    "title": cmd.display_title,
                    "description": cmd.description,
                    "color": cmd.color,
                    "color_dark": cmd.color_dark,
                    "css": cmd.css,
                    "css_dark": cmd.css_dark,
                    "groups": cmd.groups or [],
                    "is_executable": cmd.is_executable,
                    "host": cmd.host,
                    "payload_template": cmd.payload_template,
                    "parameters": [
                        {
                            "name": p.name,
                            "type": p.type,
                            "label": p.label or p.name,
                            "default": p.default,
                        }
                        for p in (cmd.parameters or [])
                    ],
                }
                commands_list.append(cmd_dict)

        # Get groups from config.groups (not from commands)
        groups_list = []
        if config.groups:
            for grp in config.get_all_groups():
                grp_dict = {
                    "name": grp.name,
                    "title": grp.display_title,
                    "description": grp.description,
                    "color": grp.color,
                    "color_dark": grp.color_dark,
                    "css": grp.css,
                    "css_dark": grp.css_dark,
                }
                groups_list.append(grp_dict)

        hosts = await get_online_hosts()
        broker = get_mqtt_broker()

        return {
            "commands": commands_list,
            "hosts": hosts,
            "groups": groups_list,
            "mqtt_connected": broker is not None,
        }

    @app_fastapi.post("/api/commands/send")
    @app_fastapi.post("/api/commands/send/")
    async def api_send_command(request: Request):
        """Send a command to a host via MQTT."""
        from pydantic import BaseModel, ValidationError

        from ..render import render

        class CommandRequest(BaseModel):
            host: str | None = None
            command: str
            payload: Dict[str, Any] | None = None
            parameters: Dict[str, Any] | None = None

        try:
            data = await request.json()
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Invalid JSON body: {str(e)}")

        # Debug: log what we received
        import logging

        logging.getLogger("cocobolo").debug(f"Received command request data: {data}")

        try:
            cmd_req = CommandRequest(**data)
        except ValidationError as e:
            error_details = e.errors()[0]
            field = ".".join(str(x) for x in error_details.get("loc", []))
            msg = error_details.get("msg", "Unknown validation error")
            actual_type = (
                type(data.get("command", "N/A")).__name__
                if isinstance(data, dict)
                else "N/A"
            )
            raise HTTPException(
                status_code=400,
                detail=f"Invalid request: {field} - {msg} (command type: {actual_type}, value: {data.get('command', 'N/A')})",
            )

        # Validate command exists (or is the special "stop" command)
        command_spec = None
        if cmd_req.command != "stop":
            if not config.commands:
                raise HTTPException(status_code=400, detail="No commands configured")

            command_spec = config.get_command_spec(cmd_req.command)
            if not command_spec:
                raise HTTPException(
                    status_code=400, detail=f"Unknown command: {cmd_req.command}"
                )

        # Determine host: use request host, or command's predefined host
        host = cmd_req.host
        if not host:
            if command_spec and command_spec.host:
                host = command_spec.host
            else:
                raise HTTPException(
                    status_code=400,
                    detail="Host not specified and command has no predefined host",
                )

        # Validate host is online (skip validation for "all")
        online_hosts = await get_online_hosts()
        if host != "all" and host not in online_hosts:
            raise HTTPException(status_code=400, detail=f"Host not online: {host}")

        # Get MQTT broker
        broker_config = get_mqtt_broker()
        if not broker_config:
            raise HTTPException(status_code=500, detail="No MQTT broker configured")

        # Build payload: render template if command has one, else use provided payload
        if command_spec and command_spec.payload_template:
            # Use user-provided parameters or empty dict
            user_params = cmd_req.parameters or {}
            # Build context with defaults from parameter definitions
            params_context = {}
            if command_spec.parameters:
                for param_def in command_spec.parameters:
                    param_name = param_def.name
                    if param_name in user_params:
                        params_context[param_name] = user_params[param_name]
                    elif param_def.default is not None:
                        params_context[param_name] = param_def.default
                    else:
                        params_context[param_name] = None
            # Render the payload template with params
            rendered_payload = render(
                command_spec.payload_template, data={"params": params_context}
            )
            final_payload = rendered_payload
        else:
            # No template, use provided payload or empty dict
            final_payload = cmd_req.payload or {}

        # Publish command via MQTT
        try:
            broker = MqttBroker(config=broker_config)
            broker.start()
            await broker.ready()

            topic = f"cmd/{host}/start/{cmd_req.command}"
            payload = json.dumps(final_payload).encode("utf-8")

            broker.publish(topic, payload, qos=1)
            broker.stop()

            return {"success": True, "topic": topic}
        except Exception as e:
            raise HTTPException(
                status_code=500, detail=f"Failed to send command: {str(e)}"
            )

    @app_fastapi.get("/api/groups")
    async def api_groups():
        """Get available groups from config."""
        groups_list = []
        if config.groups:
            for grp in config.get_all_groups():
                groups_list.append(
                    {
                        "name": grp.name,
                        "title": grp.display_title,
                        "description": grp.description,
                        "color": grp.color,
                        "color_dark": grp.color_dark,
                        "css": grp.css,
                        "css_dark": grp.css_dark,
                    }
                )
        return {"groups": groups_list}

    @app_fastapi.post("/api/groups/stop")
    async def api_stop_group(request: Request):
        """Stop a group on a host or all hosts via MQTT."""
        from pydantic import BaseModel, ValidationError

        class StopGroupRequest(BaseModel):
            host: str
            group: str

        try:
            data = await request.json()
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Invalid JSON body: {str(e)}")

        try:
            req = StopGroupRequest(**data)
        except ValidationError as e:
            raise HTTPException(
                status_code=400, detail=f"Invalid request: {e.errors()[0]['msg']}"
            )

        # Get MQTT broker
        broker_config = get_mqtt_broker()
        if not broker_config:
            raise HTTPException(status_code=500, detail="No MQTT broker configured")

        # Validate host is online (only for specific host, not "all")
        if req.host != "all":
            online_hosts = await get_online_hosts()
            if req.host not in online_hosts:
                raise HTTPException(
                    status_code=400, detail=f"Host not online: {req.host}"
                )

        # Publish stop command via MQTT
        try:
            broker = MqttBroker(config=broker_config)
            broker.start()
            await broker.ready()

            # Group is now in topic suffix instead of payload
            topic = f"cmd/{req.host}/stop/{req.group}"
            payload = b"{}"

            broker.publish(topic, payload, qos=1)
            broker.stop()

            return {"success": True, "topic": topic, "group": req.group}
        except Exception as e:
            raise HTTPException(
                status_code=500, detail=f"Failed to stop group: {str(e)}"
            )

    @app_fastapi.get("/commands", name="commands_ui")
    async def commands_page(request: Request):
        """Command execution UI page with big buttons."""
        # Get data for the page
        commands = config.get_all_commands()
        hosts = await get_online_hosts()

        # Collect groups for stop functionality
        groups = set()
        for cmd in commands:
            if cmd.groups:
                groups.update(cmd.groups)

        # Build command buttons and generate CSS
        command_buttons = []
        command_css = []
        default_color = "#e0e0e0"
        default_color_dark = "#424242"

        for cmd in commands:
            title = cmd.display_title
            description = cmd.description or ""
            name = cmd.name

            # Determine colors (priority: color_light/dark -> color -> default)
            color_light = cmd.color or default_color
            color_dark = cmd.color_dark or cmd.color or default_color_dark

            # Generate CSS class for this command
            css_class = f"cmd-btn-{name.replace(' ', '-').replace('_', '-').lower()}"
            css_light = cmd.css or ""
            css_dark = cmd.css_dark or ""

            command_css.append(f"""
                .{css_class} {{
                    background-color: {color_light};
                    {css_light}
                }}
                @media (prefers-color-scheme: dark) {{
                    .{css_class} {{
                        background-color: {color_dark};
                        {css_dark}
                    }}
                }}
            """)

            # Pass predefined host to JavaScript if command has one
            host_param = f"'{cmd.host}'" if cmd.host else "null"
            command_buttons.append(
                ft.Button(
                    title,
                    type="button",
                    cls=f"command-button {css_class}",
                    title=description,
                    onclick=f"sendCommand('{name}', {host_param})",
                )
            )

        # Build host dropdown options (with "All" option)
        host_options = [
            ft.Option(value="", label="Select host...", disabled=True, selected=True),
            ft.Option(value="all", label="All Hosts"),
        ]
        for host in hosts:
            host_options.append(ft.Option(value=host, label=host))

        # Build group buttons (similar to command buttons)
        group_buttons = []
        group_css = []
        default_group_color = "#ff6b6b"  # Red-ish for stop actions
        default_group_color_dark = "#ee5a5a"

        if config.groups:
            for grp in config.get_all_groups():
                title = grp.display_title
                description = grp.description or f"Stop {grp.name} group"
                name = grp.name

                # Determine colors (priority: color_light/dark -> color -> default)
                color_light = grp.color or default_group_color
                color_dark = grp.color_dark or grp.color or default_group_color_dark

                # Generate CSS class for this group
                css_class = (
                    f"grp-btn-{name.replace(' ', '-').replace('_', '-').lower()}"
                )
                css_light = grp.css or ""
                css_dark = grp.css_dark or ""

                group_css.append(f"""
                    .{css_class} {{
                        background-color: {color_light};
                        {css_light}
                    }}
                    @media (prefers-color-scheme: dark) {{
                        .{css_class} {{
                            background-color: {color_dark};
                            {css_dark}
                        }}
                    }}
                """)

                group_buttons.append(
                    ft.Button(
                        title,
                        type="button",
                        cls=f"command-button {css_class}",
                        title=description,
                        onclick=f"sendStop('{name}')",
                    )
                )

        # Empty state message
        empty_state = ""
        if not commands:
            empty_state = ft.Div(
                "No commands configured in config file.",
                style="color: var(--text-secondary); font-style: italic; margin: 20px 0;",
            )
        elif not hosts:
            empty_state = ft.Div(
                "No online hosts available. Hosts must send heartbeats to appear here.",
                style="color: var(--text-secondary); font-style: italic; margin: 20px 0;",
            )

        # Build command buttons grid
        command_grid = (
            ft.Div(
                *command_buttons,
                cls="command-grid",
            )
            if command_buttons
            else ""
        )

        page = (
            ft.Html(
                ft.Head(
                    ft.Title("Commands - cocobolo"),
                    ft.Script(src="https://unpkg.com/htmx.org@2.0.4"),
                    ft.Style(
                        f"""
                    :root {{
                        --bg-color: #f5f5f5;
                        --container-bg: #ffffff;
                        --text-color: #333333;
                        --text-secondary: #666666;
                        --border-color: #dddddd;
                        --link-color: #2196f3;
                        --panel-shadow: 0 2px 4px rgba(0,0,0,0.1);
                        --success-color: #4caf50;
                        --error-color: #f44336;

                        --nav-bg: #ffffff;
                        --nav-border: #e0e0e0;
                        --nav-link-color: #666666;
                        --nav-link-active: #2196f3;
                        --nav-link-hover: #333333;
                    }}
                    @media (prefers-color-scheme: dark) {{
                        :root {{
                            --bg-color: #1a1a1a;
                            --container-bg: #2d2d2d;
                            --text-color: #e0e0e0;
                            --text-secondary: #a0a0a0;
                            --border-color: #444444;
                            --link-color: #64b5f6;
                            --panel-shadow: 0 2px 6px rgba(0,0,0,0.4);

                            --nav-bg: #2d2d2d;
                            --nav-border: #444444;
                            --nav-link-color: #a0a0a0;
                            --nav-link-active: #64b5f6;
                            --nav-link-hover: #e0e0e0;
                        }}
                    }}
                    body {{
                        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                        margin: 0;
                        padding: 0;
                        background: var(--bg-color);
                        color: var(--text-color);
                    }}
                    .container {{
                        max-width: 800px;
                        margin: 0 auto;
                        padding: 20px;
                    }}
                    .panel {{
                        background: var(--container-bg);
                        border: 1px solid var(--border-color);
                        border-radius: 8px;
                        padding: 20px;
                        box-shadow: var(--panel-shadow);
                    }}
                    h1 {{ margin: 0 0 20px 0; color: var(--text-color); }}
                    .form-group {{
                        margin-bottom: 15px;
                    }}
                    label {{
                        display: block;
                        margin-bottom: 5px;
                        font-weight: 500;
                        color: var(--text-color);
                    }}
                    select {{
                        width: 100%;
                        padding: 8px 12px;
                        border: 1px solid var(--border-color);
                        border-radius: 4px;
                        background: var(--container-bg);
                        color: var(--text-color);
                        font-size: 14px;
                        cursor: pointer;
                    }}
                    select:focus {{
                        outline: none;
                        border-color: var(--link-color);
                    }}
                    .form-group-inline {{
                        display: flex;
                        align-items: center;
                        gap: 15px;
                    }}
                    .form-group-inline label {{
                        flex-shrink: 0;
                        margin-bottom: 0;
                    }}
                    .host-select {{
                        width: auto;
                        min-width: 200px;
                        max-width: 300px;
                    }}

                    /* Command Button Grid - Same as events */
                    .command-grid {{
                        display: flex;
                        flex-wrap: wrap;
                        justify-content: center;
                        gap: 15px;
                        margin: 20px 0;
                    }}
                    .command-button {{
                        width: 140px;
                        height: 140px;
                        border: none;
                        border-radius: 8px;
                        cursor: pointer;
                        font-size: 16px;
                        font-weight: 500;
                        color: var(--text-color);
                        transition: all 0.2s ease;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        text-align: center;
                        word-wrap: break-word;
                        padding: 10px;
                    }}
                    .command-button:hover {{
                        transform: scale(1.05);
                        opacity: 0.9;
                    }}
                    .command-button:active {{
                        transform: scale(0.95);
                    }}

                    /* Stop section */
                    .stop-section {{
                        margin-top: 30px;
                        padding-top: 20px;
                        border-top: 1px solid var(--border-color);
                    }}
                    .stop-button {{
                        background: #f44336;
                        color: white;
                        border: none;
                        padding: 10px 20px;
                        border-radius: 4px;
                        cursor: pointer;
                        font-size: 14px;
                    }}
                    .stop-button:hover {{
                        background: #d32f2f;
                    }}

                    .result {{
                        margin-top: 15px;
                        padding: 10px;
                        border-radius: 4px;
                        display: none;
                    }}
                    .result.success {{
                        background: rgba(76, 175, 80, 0.1);
                        border: 1px solid var(--success-color);
                        color: var(--success-color);
                        display: block;
                    }}
                    .result.error {{
                        background: rgba(244, 67, 54, 0.1);
                        border: 1px solid var(--error-color);
                        color: var(--error-color);
                        display: block;
                    }}

                    /* Navigation Bar */
                    .navbar {{
                        background: var(--nav-bg);
                        border-bottom: 1px solid var(--nav-border);
                        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
                        margin-bottom: 30px;
                    }}
                    .nav-container {{
                        max-width: 1000px;
                        margin: 0 auto;
                        padding: 0 20px;
                        display: flex;
                        align-items: center;
                        justify-content: space-between;
                        height: 60px;
                    }}
                    .nav-brand {{
                        font-size: 20px;
                        font-weight: 600;
                        color: var(--text-color);
                        text-decoration: none;
                        letter-spacing: -0.5px;
                    }}
                    .nav-brand:hover {{
                        color: var(--nav-link-active);
                    }}
                    .nav-links {{
                        display: flex;
                        gap: 8px;
                    }}
                    .nav-link {{
                        padding: 8px 16px;
                        color: var(--nav-link-color);
                        text-decoration: none;
                        font-size: 14px;
                        font-weight: 500;
                        border-radius: 6px;
                        transition: all 0.2s ease;
                    }}
                    .nav-link:hover {{
                        color: var(--nav-link-hover);
                        background: var(--bg-color);
                    }}
                    .nav-link.active {{
                        color: var(--nav-link-active);
                        background: rgba(33, 150, 243, 0.1);
                    }}
                    @media (prefers-color-scheme: dark) {{
                        .nav-link.active {{
                            background: rgba(100, 181, 246, 0.15);
                        }}
                    }}

                    /* Modal styles */
                    .modal {{
                        display: none;
                        position: fixed;
                        z-index: 1000;
                        left: 0;
                        top: 0;
                        width: 100%;
                        height: 100%;
                        background-color: rgba(0, 0, 0, 0.5);
                        align-items: center;
                        justify-content: center;
                    }}
                    .modal-content {{
                        background: var(--container-bg);
                        border: 1px solid var(--border-color);
                        border-radius: 8px;
                        padding: 20px;
                        max-width: 400px;
                        width: 90%;
                        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
                    }}
                    .modal-header {{
                        margin-bottom: 20px;
                    }}
                    .modal-header h3 {{
                        margin: 0;
                        color: var(--text-color);
                    }}
                    .modal-body {{
                        margin-bottom: 20px;
                    }}
                    .modal-footer {{
                        display: flex;
                        justify-content: flex-end;
                        gap: 10px;
                    }}
                    .modal-footer button {{
                        padding: 8px 16px;
                        border: none;
                        border-radius: 4px;
                        cursor: pointer;
                        font-size: 14px;
                    }}
                    .modal-footer .btn-primary {{
                        background: var(--link-color);
                        color: white;
                    }}
                    .modal-footer .btn-primary:hover {{
                        opacity: 0.9;
                    }}
                    .modal-footer .btn-secondary {{
                        background: var(--border-color);
                        color: var(--text-color);
                    }}
                    .modal-footer .btn-secondary:hover {{
                        opacity: 0.9;
                    }}
                    #parameterForm input[type="text"],
                    #parameterForm input[type="number"] {{
                        width: 100%;
                        padding: 8px 12px;
                        border: 1px solid var(--border-color);
                        border-radius: 4px;
                        background: var(--container-bg);
                        color: var(--text-color);
                        font-size: 14px;
                        box-sizing: border-box;
                    }}
                    #parameterForm input[type="checkbox"] {{
                        width: 18px;
                        height: 18px;
                        cursor: pointer;
                    }}

                    /* Per-command colors */
                    {" ".join(command_css)}
                    /* Per-group colors */
                    {" ".join(group_css)}
                    """
                    ),
                ),
                ft.Body(
                    create_nav(request, active="commands_ui"),
                    ft.Div(
                        ft.H1("Send Command"),
                        ft.Div(
                            ft.Div(
                                empty_state if empty_state else "",
                                ft.Form(
                                    # Host selection at top
                                    ft.Div(
                                        ft.Label("Target", **{"for": "host"}),  # type: ignore
                                        ft.Select(
                                            *host_options,
                                            id="host",
                                            name="host",
                                            required=True,
                                            cls="host-select",
                                        ),
                                        cls="form-group form-group-inline",
                                        style="margin-bottom: 25px;",
                                    ),
                                    # Command buttons grid
                                    ft.Div(
                                        ft.Label("Start"),
                                        command_grid,
                                        cls="form-group",
                                    ),
                                    # Group buttons section for stopping groups
                                    ft.Div(
                                        ft.Label("Stop"),
                                        ft.Div(
                                            *group_buttons,
                                            cls="command-grid",
                                        )
                                        if group_buttons
                                        else ft.Div(
                                            "No groups configured.",
                                            style="color: var(--text-secondary); font-style: italic; margin: 10px 0;",
                                        ),
                                        cls="stop-section",
                                    ),
                                    ft.Div(id="result", cls="result"),
                                    onsubmit="event.preventDefault();",
                                ),
                                # Parameter modal
                                ft.Div(
                                    ft.Div(
                                        ft.Div(
                                            ft.H3(
                                                "Command Parameters", id="modalTitle"
                                            ),
                                            cls="modal-header",
                                        ),
                                        ft.Div(
                                            ft.Form(id="parameterForm"),
                                            cls="modal-body",
                                        ),
                                        ft.Div(
                                            ft.Button(
                                                "Cancel",
                                                type="button",
                                                cls="btn-secondary",
                                                onclick="closeModal()",
                                            ),
                                            ft.Button(
                                                "Send",
                                                type="button",
                                                cls="btn-primary",
                                                onclick="submitParameters()",
                                            ),
                                            cls="modal-footer",
                                        ),
                                        cls="modal-content",
                                    ),
                                    id="parameterModal",
                                    cls="modal",
                                    onclick="if(event.target===this)closeModal()",
                                ),
                                ft.Script(
                                    """
                                // Store command configuration globally
                                let commandsConfig = [];
                                let currentCommand = null;
                                let currentHost = null;

                                // Fetch commands config on load
                                async function loadCommandsConfig() {
                                    try {
                                        const currentPath = window.location.pathname;
                                        const basePath = currentPath.substring(0, currentPath.lastIndexOf('/'));
                                        const apiUrl = basePath + '/api/commands';
                                        const response = await fetch(apiUrl);
                                        if (response.ok) {
                                            const data = await response.json();
                                            commandsConfig = data.commands || [];
                                        }
                                    } catch (e) {
                                        console.error('Failed to load commands config:', e);
                                    }
                                }

                                // Load config immediately
                                loadCommandsConfig();

                                async function sendCommand(command, predefinedHost) {
                                    const host = predefinedHost || document.getElementById('host').value;
                                    const resultDiv = document.getElementById('result');

                                    if (!host) {
                                        resultDiv.className = 'result error';
                                        resultDiv.textContent = 'Please select a host first';
                                        setTimeout(() => {
                                            resultDiv.className = 'result';
                                            resultDiv.textContent = '';
                                        }, 3000);
                                        return;
                                    }

                                    // Check if command has parameters
                                    const cmdConfig = commandsConfig.find(c => c.name === command);
                                    if (cmdConfig && cmdConfig.parameters && cmdConfig.parameters.length > 0) {
                                        // Show modal for parameter input
                                        currentCommand = command;
                                        currentHost = host;
                                        showParameterModal(cmdConfig);
                                        return;
                                    }

                                    // No parameters, send command directly
                                    await executeCommand(host, command, {});
                                }

                                function showParameterModal(cmdConfig) {
                                    const modal = document.getElementById('parameterModal');
                                    const title = document.getElementById('modalTitle');
                                    const form = document.getElementById('parameterForm');

                                    title.textContent = cmdConfig.title || cmdConfig.name;
                                    form.innerHTML = '';

                                    cmdConfig.parameters.forEach(param => {
                                        const formGroup = document.createElement('div');
                                        formGroup.className = 'form-group';

                                        const label = document.createElement('label');
                                        label.textContent = param.label || param.name;
                                        label.htmlFor = 'param_' + param.name;
                                        formGroup.appendChild(label);

                                        let input;
                                        if (param.type === 'boolean') {
                                            input = document.createElement('input');
                                            input.type = 'checkbox';
                                            input.id = 'param_' + param.name;
                                            input.name = param.name;
                                            if (param.default) input.checked = true;
                                        } else if (param.type === 'integer' || param.type === 'number') {
                                            input = document.createElement('input');
                                            input.type = 'number';
                                            input.id = 'param_' + param.name;
                                            input.name = param.name;
                                            if (param.default !== null && param.default !== undefined) {
                                                input.value = param.default;
                                            }
                                            input.step = param.type === 'integer' ? '1' : 'any';
                                        } else {
                                            input = document.createElement('input');
                                            input.type = 'text';
                                            input.id = 'param_' + param.name;
                                            input.name = param.name;
                                            if (param.default) input.value = param.default;
                                        }

                                        formGroup.appendChild(input);
                                        form.appendChild(formGroup);
                                    });

                                    modal.style.display = 'flex';
                                }

                                function closeModal() {
                                    document.getElementById('parameterModal').style.display = 'none';
                                    currentCommand = null;
                                    currentHost = null;
                                }

                                async function submitParameters() {
                                    const form = document.getElementById('parameterForm');
                                    const cmdConfig = commandsConfig.find(c => c.name === currentCommand);

                                    const parameters = {};
                                    cmdConfig.parameters.forEach(param => {
                                        const input = document.getElementById('param_' + param.name);
                                        if (param.type === 'boolean') {
                                            parameters[param.name] = input.checked;
                                        } else if (param.type === 'integer') {
                                            parameters[param.name] = parseInt(input.value) || 0;
                                        } else if (param.type === 'number') {
                                            parameters[param.name] = parseFloat(input.value) || 0;
                                        } else {
                                            parameters[param.name] = input.value;
                                        }
                                    });

                                    const cmdHost = currentHost;
                                    const cmdName = currentCommand;
                                    closeModal();
                                    await executeCommand(cmdHost, cmdName, parameters);
                                }

                                async function executeCommand(host, command, parameters) {
                                    const resultDiv = document.getElementById('result');

                                    try {
                                        const currentPath = window.location.pathname;
                                        const basePath = currentPath.substring(0, currentPath.lastIndexOf('/'));
                                        const apiUrl = basePath + '/api/commands/send';

                                        const requestBody = {host: host, command: command};
                                        if (Object.keys(parameters).length > 0) {
                                            requestBody.parameters = parameters;
                                        }

                                        const response = await fetch(apiUrl, {
                                            method: 'POST',
                                            headers: {'Content-Type': 'application/json'},
                                            body: JSON.stringify(requestBody)
                                        });

                                        const responseText = await response.text();
                                        let data;
                                        try {
                                            data = JSON.parse(responseText);
                                        } catch (parseErr) {
                                            resultDiv.className = 'result error';
                                            resultDiv.textContent = 'JSON parse error: ' + parseErr.message;
                                            return;
                                        }

                                        if (response.ok) {
                                            resultDiv.className = 'result success';
                                            const hostText = host === 'all' ? 'all hosts' : host;
                                            resultDiv.textContent = 'Command "' + command + '" sent to ' + hostText;
                                            setTimeout(() => {
                                                resultDiv.className = 'result';
                                                resultDiv.textContent = '';
                                            }, 3000);
                                        } else {
                                            resultDiv.className = 'result error';
                                            resultDiv.textContent = data.detail || 'Failed to send command';
                                            setTimeout(() => {
                                                resultDiv.className = 'result';
                                                resultDiv.textContent = '';
                                            }, 3000);
                                        }
                                    } catch (e) {
                                        resultDiv.className = 'result error';
                                        resultDiv.textContent = 'Error: ' + e.message;
                                        setTimeout(() => {
                                            resultDiv.className = 'result';
                                            resultDiv.textContent = '';
                                        }, 3000);
                                    }
                                }

                                async function sendStop(group) {
                                    const host = document.getElementById('host').value;
                                    const resultDiv = document.getElementById('result');

                                    if (!host) {
                                        resultDiv.className = 'result error';
                                        resultDiv.textContent = 'Please select a host first';
                                        setTimeout(() => {
                                            resultDiv.className = 'result';
                                            resultDiv.textContent = '';
                                        }, 3000);
                                        return;
                                    }

                                    try {
                                        // Build URL that works with proxy prefix
                                        const currentPath = window.location.pathname;
                                        const basePath = currentPath.substring(0, currentPath.lastIndexOf('/'));
                                        const apiUrl = basePath + '/api/groups/stop';

                                        const response = await fetch(apiUrl, {
                                            method: 'POST',
                                            headers: {'Content-Type': 'application/json'},
                                            body: JSON.stringify({host: host, group: group})
                                        });

                                        const responseText = await response.text();
                                        let data;
                                        try {
                                            data = JSON.parse(responseText);
                                        } catch (parseErr) {
                                            resultDiv.className = 'result error';
                                            resultDiv.textContent = 'JSON parse error: ' + parseErr.message;
                                            return;
                                        }

                                        if (response.ok) {
                                            resultDiv.className = 'result success';
                                            const hostText = host === 'all' ? 'all hosts' : host;
                                            resultDiv.textContent = 'Group "' + group + '" stopped on ' + hostText;
                                            setTimeout(() => {
                                                resultDiv.className = 'result';
                                                resultDiv.textContent = '';
                                            }, 3000);
                                        } else {
                                            resultDiv.className = 'result error';
                                            resultDiv.textContent = data.detail || 'Failed to stop group';
                                            setTimeout(() => {
                                                resultDiv.className = 'result';
                                                resultDiv.textContent = '';
                                            }, 3000);
                                        }
                                    } catch (e) {
                                        resultDiv.className = 'result error';
                                        resultDiv.textContent = 'Error: ' + e.message;
                                        setTimeout(() => {
                                            resultDiv.className = 'result';
                                            resultDiv.textContent = '';
                                        }, 3000);
                                    }
                                }
                                """
                                ),
                            ),
                            cls="panel",
                        ),
                        cls="container",
                    ),
                ),
            ),
        )
        return HTMLResponse(to_xml(page))
