"""Shared navigation utility for web UI."""

from __future__ import annotations

from typing import Any

from fastapi import Request
from fasthtml import ft


# Shared navigation CSS styles
NAV_CSS = """
/* Navigation Bar */
.navbar {
    background: var(--nav-bg);
    border-bottom: 1px solid var(--nav-border);
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    margin-bottom: 30px;
}
.nav-container {
    max-width: 1000px;
    margin: 0 auto;
    padding: 0 20px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: 60px;
}
.nav-brand {
    font-size: 20px;
    font-weight: 600;
    color: var(--text-color);
    text-decoration: none;
    letter-spacing: -0.5px;
}
.nav-brand:hover {
    color: var(--nav-link-active);
}
.nav-links {
    display: flex;
    gap: 8px;
}
.nav-link {
    padding: 8px 16px;
    color: var(--nav-link-color);
    text-decoration: none;
    font-size: 14px;
    font-weight: 500;
    border-radius: 6px;
    transition: all 0.2s ease;
}
.nav-link:hover {
    color: var(--nav-link-hover);
    background: var(--bg-color);
}
.nav-link.active {
    color: var(--nav-link-active);
    background: rgba(33, 150, 243, 0.1);
}
@media (prefers-color-scheme: dark) {
    .nav-link.active {
        background: rgba(100, 181, 246, 0.15);
    }
}
"""


def create_nav(request: Request, active: str = "") -> Any:
    """Create navigation bar component.

    This is a shared utility used across all web UI pages to ensure
    consistent navigation across the application.

    Args:
        request: The current FastAPI request
        active: The name of the currently active route

    Returns:
        FastHTML Div component containing the navigation bar
    """
    nav_items = [
        ("Dashboard", "index"),
        ("Commands", "commands_ui"),
        ("Events", "events_ui"),
        ("Consumables", "consumables_ui"),
        ("Mails", "mails_list"),
    ]

    nav_links = []
    for label, route_name in nav_items:
        is_active = active == route_name
        href = str(request.url_for(route_name))
        active_class = "nav-link active" if is_active else "nav-link"
        nav_links.append(ft.A(label, href=href, cls=active_class))

    return ft.Div(
        ft.Div(
            ft.A("cocobolo", href=str(request.url_for("index")), cls="nav-brand"),
            ft.Div(*nav_links, cls="nav-links"),
            cls="nav-container",
        ),
        cls="navbar",
    )
