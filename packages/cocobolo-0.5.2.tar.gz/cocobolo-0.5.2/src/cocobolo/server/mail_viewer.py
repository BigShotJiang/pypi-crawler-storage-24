"""Mail viewer routes for browser-based email viewing."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from fastapi import Request
from fastapi.responses import HTMLResponse, Response, RedirectResponse
from fasthtml import ft
from fasthtml.core import to_xml

from ..services.mail_service import (
    list_mails,
    get_mail,
    get_mail_html_body,
    get_mail_inline_image,
    build_cid_map,
    julian_to_datetime,
)
from ..utils.html_sanitizer import (
    sanitize_html,
    sanitize_with_inline_images,
    ImageHandling,
)
from .navigation import create_nav


def register_mail_routes(app_fastapi: Any, db_path: Path, config) -> None:
    """Register mail viewer routes onto an existing FastAPI app."""

    def format_relative_time(dt: datetime) -> str:
        """Format datetime as relative time (e.g., '2h ago')."""
        now = datetime.now(timezone.utc)
        diff = now - dt

        if diff.total_seconds() < 60:
            return f"{int(diff.total_seconds())}s ago"
        elif diff.total_seconds() < 3600:
            return f"{int(diff.total_seconds() // 60)}m ago"
        elif diff.total_seconds() < 86400:
            return f"{int(diff.total_seconds() // 3600)}h ago"
        else:
            return f"{int(diff.total_seconds() // 86400)}d ago"

    def truncate_text(text: str | None, max_len: int = 60) -> str:
        """Truncate text with ellipsis."""
        if not text:
            return "(no subject)"
        if len(text) <= max_len:
            return text
        return text[: max_len - 3] + "..."

    def truncate_email(email: str | None, max_len: int = 40) -> str:
        """Truncate email address."""
        if not email:
            return "(unknown)"
        if len(email) <= max_len:
            return email
        # Try to keep domain part
        if "@" in email:
            local, domain = email.rsplit("@", 1)
            avail = max_len - len(domain) - 4  # @ + ...
            if avail > 3:
                return f"{local[:avail]}...@{domain}"
        return email[: max_len - 3] + "..."

    @app_fastapi.get("/mails", name="mails_list")
    async def mails_overview(request: Request, hours: int = 24):
        """Mail overview page - list of recent emails."""
        # Validate hours
        hours = max(1, min(168, hours))

        mails = await list_mails(db_path, hours=hours, limit=100)

        # Build table rows
        rows = []
        for mail in mails:
            received_dt = julian_to_datetime(mail.received_at)
            relative_time = format_relative_time(received_dt)
            time_str = received_dt.strftime("%Y-%m-%d %H:%M:%S")

            row = ft.Tr(
                ft.Td(
                    ft.A(
                        truncate_text(mail.subject),
                        href=str(request.url_for("mail_text_view", mail_id=mail.id)),
                        style="text-decoration: none; color: var(--link-color, #2196f3);",
                    ),
                    style="max-width: 300px;",
                ),
                ft.Td(truncate_email(mail.sender)),
                ft.Td(truncate_email(mail.recipient)),
                ft.Td(time_str, style="white-space: nowrap;"),
                ft.Td(relative_time, style="white-space: nowrap;"),
                style="cursor: pointer;",
                onclick=f"window.location.href='{request.url_for('mail_text_view', mail_id=mail.id)}'",
                onmouseover="this.style.backgroundColor='var(--table-row-hover)'",
                onmouseout="this.style.backgroundColor=''",
            )
            rows.append(row)

        # Empty state
        if not rows:
            rows.append(
                ft.Tr(
                    ft.Td(
                        "No emails found in the last {} hour(s).".format(hours),
                        colspan="5",
                        style="text-align: center; padding: 40px; color: var(--text-secondary); font-style: italic;",
                    )
                )
            )

        # Hours selector
        hour_options = [1, 6, 12, 24, 48, 72, 168]
        hour_buttons = []
        for h in hour_options:
            active_style = (
                "background: var(--link-color, #2196f3); color: white;"
                if h == hours
                else "background: transparent; color: var(--text-color); border: 1px solid var(--border-color);"
            )
            hour_buttons.append(
                ft.A(
                    f"{h}h" if h < 24 else f"{h // 24}d" if h == 24 else f"{h // 24}d",
                    href=str(request.url_for("mails_list")) + f"?hours={h}",
                    style=(
                        f"display: inline-block; padding: 4px 12px; margin-right: 8px; "
                        f"border-radius: 4px; text-decoration: none; font-size: 13px; "
                        f"{active_style}"
                    ),
                )
            )

        page = ft.Html(
            ft.Head(
                ft.Title("Mails - cocobolo"),
                ft.Script(src="https://unpkg.com/htmx.org@2.0.4"),
                ft.Style(
                    """
                    :root {
                        --bg-color: #f5f5f5;
                        --container-bg: #ffffff;
                        --text-color: #333333;
                        --text-secondary: #666666;
                        --border-color: #dddddd;
                        --table-header-bg: #f8f8f8;
                        --table-row-hover: #f5f5f5;
                        --link-color: #2196f3;
                        --panel-shadow: 0 2px 4px rgba(0,0,0,0.1);

                        --nav-bg: #ffffff;
                        --nav-border: #e0e0e0;
                        --nav-link-color: #666666;
                        --nav-link-active: #2196f3;
                        --nav-link-hover: #333333;
                    }
                    @media (prefers-color-scheme: dark) {
                        :root {
                            --bg-color: #1a1a1a;
                            --container-bg: #2d2d2d;
                            --text-color: #e0e0e0;
                            --text-secondary: #a0a0a0;
                            --border-color: #444444;
                            --table-header-bg: #3d3d3d;
                            --table-row-hover: #3a3a3a;
                            --link-color: #64b5f6;
                            --panel-shadow: 0 2px 6px rgba(0,0,0,0.4);

                            --nav-bg: #2d2d2d;
                            --nav-border: #444444;
                            --nav-link-color: #a0a0a0;
                            --nav-link-active: #64b5f6;
                            --nav-link-hover: #e0e0e0;
                        }
                    }
                    body {
                        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                        margin: 0;
                        padding: 0;
                        background: var(--bg-color);
                        color: var(--text-color);
                    }
                    .container {
                        max-width: 1000px;
                        margin: 0 auto;
                        padding: 20px;
                    }
                    h1 { color: var(--text-color); margin-bottom: 10px; }
                    .subtitle { color: var(--text-secondary); margin-bottom: 20px; font-size: 14px; }
                    .panel {
                        background: var(--container-bg);
                        border: 1px solid var(--border-color);
                        border-radius: 8px;
                        padding: 15px;
                        box-shadow: var(--panel-shadow);
                        overflow-x: auto;
                    }
                    table {
                        width: 100%;
                        border-collapse: collapse;
                        font-size: 14px;
                        background: var(--container-bg);
                    }
                    th {
                        text-align: left;
                        padding: 12px;
                        border-bottom: 2px solid var(--border-color);
                        background: var(--table-header-bg);
                        color: var(--text-color);
                        font-weight: 600;
                    }
                    td {
                        padding: 10px 12px;
                        border-bottom: 1px solid var(--border-color);
                        color: var(--text-color);
                    }
                    tr:hover { background-color: var(--table-row-hover); }

                    /* Navigation Bar */
                    .navbar {
                        background: var(--nav-bg);
                        border-bottom: 1px solid var(--nav-border);
                        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
                        margin-bottom: 30px;
                    }
                    .nav-container {
                        max-width: 1000px;
                        margin: 0 auto;
                        padding: 0 20px;
                        display: flex;
                        align-items: center;
                        justify-content: space-between;
                        height: 60px;
                    }
                    .nav-brand {
                        font-size: 20px;
                        font-weight: 600;
                        color: var(--text-color);
                        text-decoration: none;
                        letter-spacing: -0.5px;
                    }
                    .nav-brand:hover {
                        color: var(--nav-link-active);
                    }
                    .nav-links {
                        display: flex;
                        gap: 8px;
                    }
                    .nav-link {
                        padding: 8px 16px;
                        color: var(--nav-link-color);
                        text-decoration: none;
                        font-size: 14px;
                        font-weight: 500;
                        border-radius: 6px;
                        transition: all 0.2s ease;
                    }
                    .nav-link:hover {
                        color: var(--nav-link-hover);
                        background: var(--bg-color);
                    }
                    .nav-link.active {
                        color: var(--nav-link-active);
                        background: rgba(33, 150, 243, 0.1);
                    }
                    @media (prefers-color-scheme: dark) {
                        .nav-link.active {
                            background: rgba(100, 181, 246, 0.15);
                        }
                    }
                    """
                ),
            ),
            ft.Body(
                create_nav(request, active="mails_list"),
                ft.Div(
                    ft.H1("Mails"),
                    ft.Div(
                        f"{len(mails)} email(s) in the last {hours} hour(s)",
                        cls="subtitle",
                    ),
                    ft.Div(*hour_buttons, style="margin-bottom: 15px;"),
                    ft.Div(
                        ft.Table(
                            ft.Thead(
                                ft.Tr(
                                    ft.Th("Subject"),
                                    ft.Th("From"),
                                    ft.Th("To"),
                                    ft.Th("Time"),
                                    ft.Th("Received"),
                                )
                            ),
                            ft.Tbody(*rows),
                        ),
                        cls="panel",
                    ),
                    cls="container",
                ),
            ),
        )
        return HTMLResponse(to_xml(page))

    @app_fastapi.get("/mails/{mail_id}", name="mail_redirect")
    async def mail_redirect(request: Request, mail_id: int):
        """Redirect /mails/{id} to text viewer (default)."""
        return RedirectResponse(
            url=str(request.url_for("mail_text_view", mail_id=mail_id))
        )

    @app_fastapi.get("/mails/{mail_id}/view", name="mail_view")
    async def mail_viewer(request: Request, mail_id: int):
        """Mail viewer page with HTML preview."""
        mail = await get_mail(db_path, mail_id)
        if not mail:
            return HTMLResponse(
                f"<h1>Email not found</h1><p>Email {mail_id} does not exist.</p>",
                status_code=404,
            )

        received_dt = julian_to_datetime(mail.received_at)

        # Build attachment links
        attach_links = []
        for i, att in enumerate(mail.attachments):
            attach_links.append(
                ft.A(
                    f"📎 {att['filename']}",
                    href=str(
                        request.url_for(
                            "api_mail_attachment", mail_id=mail_id, attachment_index=i
                        )
                    ),
                    style="margin-right: 15px; color: var(--link-color); text-decoration: none;",
                )
            )

        # Check if email has HTML content
        html_content, _ = await get_mail_html_body(db_path, mail_id)
        has_html = html_content is not None and len(html_content) > 0

        # If no HTML, redirect to text view
        if not has_html:
            return RedirectResponse(
                url=str(request.url_for("mail_text_view", mail_id=mail_id))
            )

        # Image warning banner
        warning_banner = ft.Div(
            ft.Div("⚠️ External images are blocked for security.", style="flex: 1;"),
            ft.A(
                "Show remote images",
                href=str(request.url_for("mail_view", mail_id=mail_id))
                + "?remote_images=1",
                style="color: var(--link-color); text-decoration: none; font-size: 13px;",
            ),
            style=(
                "display: flex; align-items: center; justify-content: space-between; "
                "padding: 10px 15px; background: #fff3cd; border: 1px solid #ffc107; "
                "border-radius: 4px; margin-bottom: 15px; font-size: 13px; "
                "color: #856404;"
            ),
            id="image-warning",
        )

        # Tabs for switching between text and HTML - Plain Text first
        text_tab = ft.A(
            "Plain Text",
            href=str(request.url_for("mail_text_view", mail_id=mail_id)),
        )

        html_tab = ft.A(
            "HTML",
            href=str(request.url_for("mail_view", mail_id=mail_id)),
            cls="active",
        )

        # Iframe for HTML content
        iframe = ft.Iframe(
            src=str(request.url_for("mail_html_content", mail_id=mail_id)),
            style="width: 100%; height: 600px; border: 1px solid var(--border-color); border-radius: 4px;",
            sandbox="allow-same-origin",
        )

        # Tabs for switching between text and HTML - Plain Text first
        tab_style_active = (
            "padding: 8px 16px; border: 1px solid var(--border-color); "
            "border-bottom: none; border-radius: 4px 4px 0 0; "
            "background: var(--container-bg); color: var(--text-color); "
            "text-decoration: none; font-size: 13px;"
        )
        tab_style_inactive = (
            "padding: 8px 16px; border: 1px solid transparent; "
            "border-bottom: 1px solid var(--border-color); "
            "background: transparent; color: var(--text-secondary); "
            "text-decoration: none; font-size: 13px;"
        )

        text_tab = ft.A(
            "Plain Text",
            href=str(request.url_for("mail_text_view", mail_id=mail_id)),
            style=tab_style_inactive,
        )

        html_tab = ft.A(
            "HTML",
            href=str(request.url_for("mail_view", mail_id=mail_id)),
            style=tab_style_active,
        )

        # Iframe for HTML content
        iframe = ft.Iframe(
            src=str(request.url_for("mail_html_content", mail_id=mail_id)),
            style="width: 100%; height: 600px; border: 1px solid var(--border-color); border-radius: 4px;",
            sandbox="allow-same-origin",
        )

        page = ft.Html(
            ft.Head(
                ft.Title(f"{mail.subject or '(no subject)'} - Mail"),
                ft.Style(
                    """
                    :root {
                        --bg-color: #f5f5f5;
                        --container-bg: #ffffff;
                        --text-color: #333333;
                        --text-secondary: #666666;
                        --border-color: #dddddd;
                        --link-color: #2196f3;
                        --panel-shadow: 0 2px 4px rgba(0,0,0,0.1);
                    }
                    @media (prefers-color-scheme: dark) {
                        :root {
                            --bg-color: #1a1a1a;
                            --container-bg: #2d2d2d;
                            --text-color: #e0e0e0;
                            --text-secondary: #a0a0a0;
                            --border-color: #444444;
                            --link-color: #64b5f6;
                            --panel-shadow: 0 2px 6px rgba(0,0,0,0.4);
                        }
                    }
                    body {
                        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                        margin: 0;
                        padding: 20px;
                        background: var(--bg-color);
                        color: var(--text-color);
                    }
                    .container { max-width: 900px; margin: 0 auto; }
                    .nav {
                        margin-bottom: 15px;
                    }
                    .nav a {
                        color: var(--link-color);
                        text-decoration: none;
                        font-size: 14px;
                    }
                    .nav a:hover { text-decoration: underline; }
                    .header-panel {
                        background: var(--container-bg);
                        border: 1px solid var(--border-color);
                        border-radius: 8px;
                        padding: 20px;
                        box-shadow: var(--panel-shadow);
                        margin-bottom: 15px;
                    }
                    .subject {
                        font-size: 20px;
                        font-weight: 600;
                        margin-bottom: 15px;
                        color: var(--text-color);
                        word-break: break-word;
                    }
                    .meta-row {
                        display: flex;
                        margin-bottom: 8px;
                        font-size: 14px;
                    }
                    .meta-label {
                        width: 80px;
                        color: var(--text-secondary);
                        flex-shrink: 0;
                    }
                    .meta-value {
                        color: var(--text-color);
                        word-break: break-all;
                    }
                    .tabs {
                        display: flex;
                        gap: 4px;
                        padding-left: 5px;
                        position: relative;
                        z-index: 1;
                    }
                    .tabs a {
                        padding: 8px 16px;
                        border: 1px solid transparent;
                        border-bottom: 1px solid var(--border-color);
                        background: transparent;
                        color: var(--text-secondary);
                        text-decoration: none;
                        font-size: 13px;
                        border-radius: 4px 4px 0 0;
                        cursor: pointer;
                    }
                    .tabs a.active {
                        background: var(--container-bg);
                        border: 1px solid var(--border-color);
                        border-bottom: 1px solid var(--container-bg);
                        color: var(--text-color);
                    }
                    .content-panel {
                        background: var(--container-bg);
                        border: 1px solid var(--border-color);
                        border-radius: 0 4px 4px 4px;
                        padding: 15px;
                        box-shadow: var(--panel-shadow);
                        margin-top: -1px;
                        position: relative;
                        z-index: 0;
                    }
                    .attachments {
                        margin-top: 15px;
                        padding-top: 15px;
                        border-top: 1px solid var(--border-color);
                    }
                    """
                ),
            ),
            ft.Body(
                ft.Div(
                    ft.Div(
                        ft.A(
                            "← Back to mail list",
                            href=str(request.url_for("mails_list")),
                        ),
                        cls="nav",
                    ),
                    ft.Div(
                        ft.Div(
                            mail.subject or "(no subject)",
                            cls="subject",
                        ),
                        ft.Div(
                            ft.Div(
                                ft.Div("From:", cls="meta-label"),
                                ft.Div(mail.sender or "(unknown)", cls="meta-value"),
                                cls="meta-row",
                            ),
                            ft.Div(
                                ft.Div("To:", cls="meta-label"),
                                ft.Div(mail.recipient or "(unknown)", cls="meta-value"),
                                cls="meta-row",
                            ),
                            ft.Div(
                                ft.Div("Date:", cls="meta-label"),
                                ft.Div(
                                    received_dt.strftime("%Y-%m-%d %H:%M:%S UTC"),
                                    cls="meta-value",
                                ),
                                cls="meta-row",
                            ),
                        ),
                        cls="header-panel",
                    ),
                    warning_banner if warning_banner else "",
                    ft.Div(
                        text_tab,
                        html_tab,
                        cls="tabs",
                    ),
                    ft.Div(
                        iframe,
                        cls="content-panel",
                    ),
                    ft.Div(
                        *attach_links
                        if attach_links
                        else [
                            ft.Span(
                                "No attachments",
                                style="color: var(--text-secondary); font-size: 13px;",
                            )
                        ],
                        cls="attachments",
                    )
                    if attach_links
                    else "",
                    cls="container",
                )
            ),
        )
        return HTMLResponse(to_xml(page))

    @app_fastapi.get("/mails/{mail_id}/text", name="mail_text_view")
    async def mail_text_view(request: Request, mail_id: int):
        """Plain text mail view."""
        mail = await get_mail(db_path, mail_id)
        if not mail:
            return HTMLResponse(
                f"<h1>Email not found</h1><p>Email {mail_id} does not exist.</p>",
                status_code=404,
            )

        received_dt = julian_to_datetime(mail.received_at)

        # Build attachment links
        attach_links = []
        for i, att in enumerate(mail.attachments):
            attach_links.append(
                ft.A(
                    f"📎 {att['filename']}",
                    href=str(
                        request.url_for(
                            "api_mail_attachment", mail_id=mail_id, attachment_index=i
                        )
                    ),
                    style="margin-right: 15px; color: var(--link-color); text-decoration: none;",
                )
            )

        # Check if email has HTML
        html_content, _ = await get_mail_html_body(db_path, mail_id)
        has_html = html_content is not None and len(html_content) > 0

        # Tabs - Plain Text always shown first, HTML only if it exists
        text_tab = ft.A(
            "Plain Text",
            href=str(request.url_for("mail_text_view", mail_id=mail_id)),
            cls="active",
        )

        html_tab = (
            ft.A(
                "HTML",
                href=str(request.url_for("mail_view", mail_id=mail_id)),
            )
            if has_html
            else ""
        )

        # Body content (preserve whitespace)
        body_text = mail.body or "(no body)"
        body_div = ft.Pre(
            body_text,
            style=(
                "font-family: monospace; font-size: 13px; line-height: 1.5; "
                "white-space: pre-wrap; word-wrap: break-word; "
                "margin: 0; color: var(--text-color);"
            ),
        )

        page = ft.Html(
            ft.Head(
                ft.Title(f"{mail.subject or '(no subject)'} - Mail"),
                ft.Style(
                    """
                    :root {
                        --bg-color: #f5f5f5;
                        --container-bg: #ffffff;
                        --text-color: #333333;
                        --text-secondary: #666666;
                        --border-color: #dddddd;
                        --link-color: #2196f3;
                        --panel-shadow: 0 2px 4px rgba(0,0,0,0.1);
                    }
                    @media (prefers-color-scheme: dark) {
                        :root {
                            --bg-color: #1a1a1a;
                            --container-bg: #2d2d2d;
                            --text-color: #e0e0e0;
                            --text-secondary: #a0a0a0;
                            --border-color: #444444;
                            --link-color: #64b5f6;
                            --panel-shadow: 0 2px 6px rgba(0,0,0,0.4);
                        }
                    }
                    body {
                        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                        margin: 0;
                        padding: 20px;
                        background: var(--bg-color);
                        color: var(--text-color);
                    }
                    .container { max-width: 900px; margin: 0 auto; }
                    .nav {
                        margin-bottom: 15px;
                    }
                    .nav a {
                        color: var(--link-color);
                        text-decoration: none;
                        font-size: 14px;
                    }
                    .nav a:hover { text-decoration: underline; }
                    .header-panel {
                        background: var(--container-bg);
                        border: 1px solid var(--border-color);
                        border-radius: 8px;
                        padding: 20px;
                        box-shadow: var(--panel-shadow);
                        margin-bottom: 15px;
                    }
                    .subject {
                        font-size: 20px;
                        font-weight: 600;
                        margin-bottom: 15px;
                        color: var(--text-color);
                        word-break: break-word;
                    }
                    .meta-row {
                        display: flex;
                        margin-bottom: 8px;
                        font-size: 14px;
                    }
                    .meta-label {
                        width: 80px;
                        color: var(--text-secondary);
                        flex-shrink: 0;
                    }
                    .meta-value {
                        color: var(--text-color);
                        word-break: break-all;
                    }
                    .tabs {
                        display: flex;
                        gap: 4px;
                        padding-left: 5px;
                        position: relative;
                        z-index: 1;
                    }
                    .tabs a {
                        padding: 8px 16px;
                        border: 1px solid transparent;
                        border-bottom: 1px solid var(--border-color);
                        background: transparent;
                        color: var(--text-secondary);
                        text-decoration: none;
                        font-size: 13px;
                        border-radius: 4px 4px 0 0;
                        cursor: pointer;
                    }
                    .tabs a.active {
                        background: var(--container-bg);
                        border: 1px solid var(--border-color);
                        border-bottom: 1px solid var(--container-bg);
                        color: var(--text-color);
                    }
                    .content-panel {
                        background: var(--container-bg);
                        border: 1px solid var(--border-color);
                        border-radius: 0 4px 4px 4px;
                        padding: 15px;
                        box-shadow: var(--panel-shadow);
                        margin-top: -1px;
                        position: relative;
                        z-index: 0;
                    }
                    .attachments {
                        margin-top: 15px;
                        padding-top: 15px;
                        border-top: 1px solid var(--border-color);
                    }
                    """
                ),
            ),
            ft.Body(
                ft.Div(
                    ft.Div(
                        ft.A(
                            "← Back to mail list",
                            href=str(request.url_for("mails_list")),
                        ),
                        cls="nav",
                    ),
                    ft.Div(
                        ft.Div(
                            mail.subject or "(no subject)",
                            cls="subject",
                        ),
                        ft.Div(
                            ft.Div(
                                ft.Div("From:", cls="meta-label"),
                                ft.Div(mail.sender or "(unknown)", cls="meta-value"),
                                cls="meta-row",
                            ),
                            ft.Div(
                                ft.Div("To:", cls="meta-label"),
                                ft.Div(mail.recipient or "(unknown)", cls="meta-value"),
                                cls="meta-row",
                            ),
                            ft.Div(
                                ft.Div("Date:", cls="meta-label"),
                                ft.Div(
                                    received_dt.strftime("%Y-%m-%d %H:%M:%S UTC"),
                                    cls="meta-value",
                                ),
                                cls="meta-row",
                            ),
                        ),
                        cls="header-panel",
                    ),
                    ft.Div(
                        text_tab,
                        html_tab,
                        cls="tabs",
                    ),
                    ft.Div(
                        body_div,
                        cls="content-panel",
                    ),
                    ft.Div(
                        *attach_links
                        if attach_links
                        else [
                            ft.Span(
                                "No attachments",
                                style="color: var(--text-secondary); font-size: 13px;",
                            )
                        ],
                        cls="attachments",
                    )
                    if attach_links
                    else "",
                    cls="container",
                )
            ),
        )
        return HTMLResponse(to_xml(page))

    @app_fastapi.get("/mails/{mail_id}/html", name="mail_html_content")
    async def mail_html_content(
        request: Request,
        mail_id: int,
        remote_images: bool = False,
        raw: bool = False,
    ):
        """
        Get sanitized HTML content for mail.

        Query params:
            remote_images: If true, allow remote (http/https) images
            raw: If true, return unsanitized HTML (for reference)
        """
        # Get HTML body and parsed message
        html_body, msg = await get_mail_html_body(db_path, mail_id)

        if html_body is None:
            return HTMLResponse(
                "<html><body><p>No HTML content available.</p></body></html>",
                status_code=404,
            )

        # Build CID map for inline images
        cid_base_url = str(
            request.url_for("mail_inline_image", mail_id=mail_id, content_id="")
        ).rstrip("/")
        cid_map = build_cid_map(msg, cid_base_url + "/") if msg else {}

        if raw:
            # Return original HTML (with inline images converted but not sanitized)
            if cid_map:
                html_body = sanitize_with_inline_images(
                    html_body, cid_map, image_handling=ImageHandling.ALLOW_REMOTE
                )
            return HTMLResponse(
                html_body,
                headers={
                    "Content-Security-Policy": "default-src 'none'; img-src 'self' data:; style-src 'unsafe-inline';"
                },
            )

        # Sanitize the HTML
        image_handling = (
            ImageHandling.ALLOW_REMOTE if remote_images else ImageHandling.BLOCK_REMOTE
        )

        if cid_map:
            sanitized = sanitize_with_inline_images(
                html_body, cid_map, image_handling=image_handling
            )
        else:
            sanitized = sanitize_html(html_body, image_handling=image_handling)

        # Wrap in a basic HTML structure if not already present
        if "<html" not in sanitized.lower():
            sanitized = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 100%;
            margin: 0;
            padding: 15px;
            word-wrap: break-word;
        }}
        img {{
            max-width: 100%;
            height: auto;
        }}
        pre {{
            white-space: pre-wrap;
            word-wrap: break-word;
            background: #f5f5f5;
            padding: 10px;
            border-radius: 4px;
            overflow-x: auto;
        }}
        table {{
            max-width: 100%;
            border-collapse: collapse;
        }}
        @media (prefers-color-scheme: dark) {{
            body {{ color: #e0e0e0; background: #1a1a1a; }}
            pre {{ background: #2d2d2d; }}
        }}
    </style>
</head>
<body>
{sanitized}
</body>
</html>"""

        return HTMLResponse(
            sanitized,
            headers={
                "Content-Security-Policy": (
                    "default-src 'none'; "
                    "img-src 'self' data: blob:; "
                    "style-src 'unsafe-inline'; "
                )
            },
        )

    @app_fastapi.get(
        "/mails/{mail_id}/inline/{content_id:path}", name="mail_inline_image"
    )
    async def mail_inline_image(request: Request, mail_id: int, content_id: str):
        """Serve inline image by Content-ID."""
        result = await get_mail_inline_image(db_path, mail_id, content_id)
        if not result:
            return Response(
                content="Image not found", status_code=404, media_type="text/plain"
            )

        filename, content, content_type = result

        # Ensure content is bytes
        if isinstance(content, str):
            content = content.encode("utf-8")

        return Response(
            content=content,
            media_type=content_type or "application/octet-stream",
            headers={
                "Content-Disposition": f'inline; filename="{filename}"',
                "Cache-Control": "public, max-age=3600",
            },
        )
