"""ASGI middleware for handling reverse proxy headers."""

from __future__ import annotations

from typing import Any, Awaitable, Callable


class ForwardedPrefixMiddleware:
    """
    Middleware to handle X-Forwarded-Prefix header from reverse proxies.

    This allows FastAPI's url_for() to generate correct URLs when the app
    is behind a reverse proxy with a path prefix (e.g., /cocobolo).

    Usage:
        In nginx: proxy_set_header X-Forwarded-Prefix /cocobolo;
        In app: app.add_middleware(ForwardedPrefixMiddleware)
    """

    def __init__(self, app: Callable[..., Awaitable[Any]]) -> None:
        self.app = app

    async def __call__(self, scope: dict, receive: Callable, send: Callable) -> None:
        if scope["type"] == "http":
            # Parse headers from scope
            headers = dict(scope.get("headers", []))

            # Check for X-Forwarded-Prefix header
            prefix_header = headers.get(b"x-forwarded-prefix")
            if prefix_header:
                prefix = prefix_header.decode("utf-8")
                # Ensure prefix starts with / but doesn't end with /
                if not prefix.startswith("/"):
                    prefix = "/" + prefix
                if prefix.endswith("/"):
                    prefix = prefix[:-1]
                # Set root_path which FastAPI uses for url_for
                scope["root_path"] = prefix

        await self.app(scope, receive, send)
