from __future__ import annotations

import asyncio
from pathlib import Path
from datetime import datetime, timezone, timedelta
from typing import Any

from fastapi import Request

# This module intentionally contains the dashboard "feature":
# - DB access for heartbeat data
# - HTML fragments (FastHTML) for list + detail views
# - FastAPI route registration (no app creation, no uvicorn boot)


def register_dashboard_routes(app_fastapi: Any, db_path: Path, config) -> None:
    """Register dashboard-related endpoints onto an existing FastAPI app."""
    # Lazy imports
    from fastapi.responses import HTMLResponse
    from fasthtml import ft
    from fasthtml.core import to_xml
    from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker
    from sqlalchemy import select, desc, func, Table, MetaData

    db_url = f"sqlite+aiosqlite:///{db_path}"
    engine = create_async_engine(db_url, future=True)
    async_session = async_sessionmaker(engine, expire_on_commit=False)

    async def load_table():
        async with engine.connect() as conn:
            metadata = MetaData()
            return await conn.run_sync(
                lambda sync_conn: Table("heartbeat", metadata, autoload_with=sync_conn)
            )

    async def load_commands_table():
        async with engine.connect() as conn:
            metadata = MetaData()
            return await conn.run_sync(
                lambda sync_conn: Table("commands", metadata, autoload_with=sync_conn)
            )

    # Load table once at startup of route registration (still async-safe)
    # because we need a reflected Table object.
    # Note: If you prefer pure async startup events, move this into a lifespan handler.
    table_holder: dict[str, Any] = {"table": None}
    commands_table_holder: dict[str, Any] = {"table": None}

    async def ensure_table() -> Any:
        if table_holder["table"] is None:
            table_holder["table"] = await load_table()
        return table_holder["table"]

    async def ensure_commands_table() -> Any:
        if commands_table_holder["table"] is None:
            try:
                commands_table_holder["table"] = await load_commands_table()
            except Exception:
                # Commands table might not exist yet
                commands_table_holder["table"] = None
        return commands_table_holder["table"]

    async def get_latest_heartbeats():
        """Get the most recent heartbeat for each host."""
        table = await ensure_table()
        async with async_session() as session:
            subq = (
                select(func.max(table.c.id).label("max_id"), table.c.host)
                .group_by(table.c.host)
                .subquery()
            )
            stmt = select(table).join(subq, table.c.id == subq.c.max_id)
            result = await session.execute(stmt)
            rows = result.fetchall()

            heartbeats = []
            for row in rows:
                hb = {
                    "host": row.host,
                    "ts": row.ts,
                    "utilization": row.utilization,
                    "temperature": row.temperature,
                    "uptime": row.uptime,
                }
                heartbeats.append(hb)

                # Commands are retrieved from live heartbeat data via _latest_heartbeat_data
                # which is populated by the TrackHostStartedAction in the runner

            return heartbeats

    async def get_timeseries_data(host: str, limit: int = 50):
        """Get last N data points for a host for time series."""
        table = await ensure_table()
        async with async_session() as session:
            stmt = (
                select(table)
                .where(table.c.host == host)
                .order_by(desc(table.c.ts))
                .limit(limit)
            )
            result = await session.execute(stmt)
            rows = result.fetchall()

            return [
                {
                    "ts": row.ts,
                    "utilization": row.utilization,
                    "temperature": row.temperature,
                }
                for row in reversed(rows)
            ]

    # Import shared heartbeat data from runner
    from ..cli.core.runner import _host_heartbeat_data as _latest_heartbeat_data

    async def get_running_commands(host: str) -> list[dict]:
        """Get running commands for a specific host from latest heartbeat data."""
        data = _latest_heartbeat_data.get(host, {})
        return data.get("commands", [])

    def create_svg_chart(data, field: str, color: str):
        """Create a simple SVG line chart."""
        if not data:
            return ft.Div(
                "No data", style="color: var(--text-secondary); font-style: italic;"
            )

        width = 300
        height = 100
        padding = 10

        values = [d[field] for d in data if d[field] is not None]
        if not values:
            return ft.Div(
                "No data", style="color: var(--text-secondary); font-style: italic;"
            )

        min_val = min(values)
        max_val = max(values)
        val_range = max_val - min_val if max_val != min_val else 1

        points = []
        for i, d in enumerate(data):
            if d[field] is None:
                continue
            x = (
                padding + (i / (len(data) - 1)) * (width - 2 * padding)
                if len(data) > 1
                else width / 2
            )
            y = (
                height
                - padding
                - ((d[field] - min_val) / val_range) * (height - 2 * padding)
            )
            points.append(f"{x},{y}")

        points_str = " ".join(points)

        return ft.Svg(
            ft.ft(
                "polyline",
                points=points_str,
                fill="none",
                stroke=color,
                stroke_width="2",
            ),
            width=width,
            height=height,
            viewBox=f"0 0 {width} {height}",
            cls="chart",
        )

    def format_relative_time(seconds: int) -> str:
        """Format seconds as relative time."""
        if seconds < 60:
            return f"{seconds}s ago"
        if seconds < 3600:
            return f"{seconds // 60}m ago"
        if seconds < 86400:
            return f"{seconds // 3600}h ago"
        if seconds < 604800:
            return f"{seconds // 86400}d ago"
        return f"{seconds // 604800}w ago"

    def format_uptime(uptime_s: float) -> str:
        """Format uptime in seconds to human readable format."""
        if uptime_s < 60:
            return f"{int(uptime_s)}s"
        if uptime_s < 3600:
            return f"{int(uptime_s / 60)}m"
        if uptime_s < 86400:
            hours = int(uptime_s / 3600)
            mins = int((uptime_s % 3600) / 60)
            return f"{hours}h {mins}m"
        days = int(uptime_s / 86400)
        hours = int((uptime_s % 86400) / 3600)
        return f"{days}d {hours}h"

    def julian_to_datetime(jd: float) -> datetime:
        """Convert Julian day to UTC datetime."""
        J2000 = 2451545.0
        J2000_DATETIME = datetime(2000, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        days_since_j2000 = jd - J2000
        return J2000_DATETIME + timedelta(days=days_since_j2000)

    def classify_status(last_seen_seconds: int) -> str:
        if last_seen_seconds < 120:
            return "online"
        if last_seen_seconds < 172800:
            return "stale"
        return "offline"

    def format_duration(seconds: int) -> str:
        """Format duration in seconds to human readable format."""
        if seconds < 60:
            return f"{seconds}s"
        if seconds < 3600:
            return f"{seconds // 60}m"
        if seconds < 86400:
            hours = seconds // 3600
            mins = (seconds % 3600) // 60
            return f"{hours}h {mins}m"
        days = seconds // 86400
        hours = (seconds % 86400) // 3600
        return f"{days}d {hours}h"

    def create_running_commands_section(commands: list) -> Any:
        """Create HTML section for running commands as a table."""
        if not commands:
            return ft.Div(
                ft.Div(
                    "Running Commands",
                    style="font-size: 14px; color: var(--text-color); margin-bottom: 5px; font-weight: 600;",
                ),
                ft.Div(
                    "No active commands",
                    style="color: var(--text-secondary); font-style: italic;",
                ),
            )

        table_rows = []

        for cmd in commands:
            cmd_name = cmd.get("name", "Unknown")
            duration = cmd.get("duration", 0)
            duration_str = format_duration(duration)

            table_rows.append(
                ft.ft(
                    "tr",
                    ft.ft(
                        "td",
                        ft.ft(
                            "span",
                            cmd_name,
                            style="font-weight: 600; color: #2196f3;",
                        ),
                        style="padding: 8px 12px; border-bottom: 1px solid var(--border-color);",
                    ),
                    ft.ft(
                        "td",
                        duration_str,
                        style="padding: 8px 12px; border-bottom: 1px solid var(--border-color); color: var(--text-secondary); font-family: monospace;",
                    ),
                )
            )

        table = ft.ft(
            "table",
            ft.ft(
                "thead",
                ft.ft(
                    "tr",
                    ft.ft(
                        "th",
                        "Name",
                        style="text-align: left; padding: 8px 12px; border-bottom: 2px solid var(--border-color); font-weight: 600; color: var(--text-color);",
                    ),
                    ft.ft(
                        "th",
                        "Duration",
                        style="text-align: left; padding: 8px 12px; border-bottom: 2px solid var(--border-color); font-weight: 600; color: var(--text-color);",
                    ),
                ),
            ),
            ft.ft("tbody", *table_rows),
            style="width: 100%; border-collapse: collapse; margin-top: 10px;",
        )

        return ft.Div(
            ft.Div(
                f"Running Commands ({len(commands)})",
                style="font-size: 14px; color: var(--text-color); margin-bottom: 10px; font-weight: 600;",
            ),
            table,
            style="margin-top: 20px; padding-top: 15px; border-top: 1px solid var(--border-color);",
        )

    async def dashboard_fragment(node_detail_url_fn=None):
        """Generate the dashboard table fragment.

        Args:
            node_detail_url_fn: Optional function that takes host name and returns URL
        """
        rows = await get_latest_heartbeats()

        if not rows:
            return ft.Div(
                "No heartbeat data found",
                style="text-align: center; padding: 40px; color: var(--text-secondary);",
            )

        rows.sort(key=lambda x: x.get("uptime") or 0, reverse=True)

        table_rows = []
        for row in rows:
            host_ = row["host"]
            ts = row["ts"]
            uptime = row.get("uptime")
            temperature = row.get("temperature")

            last_seen_dt = julian_to_datetime(ts)
            now = datetime.now(timezone.utc)
            last_seen_seconds = int((now - last_seen_dt).total_seconds())

            status = classify_status(last_seen_seconds)

            uptime_str = format_uptime(uptime) if uptime else "N/A"
            last_seen_str = format_relative_time(last_seen_seconds)

            temp_str = ""
            temp_cls = ""
            if temperature is not None and status != "offline":
                temp_str = f"{temperature:.1f}°C"
                if temperature > 80:
                    temp_cls = "temp-hot"
                elif temperature >= 60:
                    temp_cls = "temp-warm"

            # Get running commands info for this host - show all command names
            commands = _latest_heartbeat_data.get(host_, {}).get("commands", [])
            if not commands:
                cmd_str = ""
                cmd_cls = ""
            else:
                # Show all command names comma-separated
                cmd_names = [cmd.get("name", "unknown") for cmd in commands]
                cmd_str = ", ".join(cmd_names)
                cmd_cls = "has-commands"

            host_cls = {
                "online": "host-online",
                "stale": "host-stale",
                "offline": "",
            }[status]

            tr_cls = "row-clickable"
            if status == "offline":
                tr_cls += " row-offline"

            # Generate URL using provided function or fallback to hardcoded
            if node_detail_url_fn:
                detail_url = node_detail_url_fn(host_)
            else:
                detail_url = f"/node/{host_}"

            table_rows.append(
                ft.ft(
                    "tr",
                    ft.ft(
                        "td",
                        ft.ft(
                            "a",
                            host_,
                            href=detail_url,
                            style="text-decoration: none; color: inherit;",
                        ),
                        cls=host_cls,
                    ),
                    ft.ft("td", last_seen_str),
                    ft.ft("td", uptime_str),
                    ft.ft("td", temp_str, cls=temp_cls),
                    ft.ft("td", cmd_str, cls=cmd_cls),
                    cls=tr_cls,
                )
            )

        table = ft.ft(
            "table",
            ft.ft(
                "thead",
                ft.ft(
                    "tr",
                    ft.ft("th", "Host"),
                    ft.ft("th", "Last Seen"),
                    ft.ft("th", "Uptime"),
                    ft.ft("th", "Temp"),
                    ft.ft("th", "Commands"),
                ),
            ),
            ft.ft("tbody", *table_rows),
        )

        return ft.Div(
            ft.Div("Click a host to view detailed information", cls="hint"),
            table,
            cls="panel",
        )

    async def node_detail_fragment(host_: str, back_url: str = "/"):
        """Generate detailed view for a single node.

        Args:
            host_: The hostname to display details for
            back_url: URL for the back button (defaults to "/")
        """
        table = await ensure_table()
        async with async_session() as session:
            stmt = (
                select(table)
                .where(table.c.host == host_)
                .order_by(desc(table.c.ts))
                .limit(1)
            )
            result = await session.execute(stmt)
            row = result.fetchone()

        back_link = ft.A("← Back to dashboard", href=back_url)

        if not row:
            return ft.Div(
                ft.Div(back_link, cls="nav"),
                ft.Div(
                    f"Node '{host_}' not found",
                    style="color: var(--text-secondary); text-align: center; padding: 40px;",
                ),
            )

        ts_data = await get_timeseries_data(host_, limit=50)

        ts = row.ts
        utilization = row.utilization
        temperature = row.temperature
        uptime = row.uptime

        last_seen_dt = julian_to_datetime(ts)
        now = datetime.now(timezone.utc)
        last_seen_seconds = int((now - last_seen_dt).total_seconds())

        status = classify_status(last_seen_seconds)
        status_text = {"online": "Online", "stale": "Stale", "offline": "Offline"}[
            status
        ]
        status_color = {
            "online": "var(--status-online)",
            "stale": "var(--status-stale)",
            "offline": "var(--status-offline)",
        }[status]

        uptime_str = format_uptime(uptime) if uptime else "N/A"
        last_seen_str = format_relative_time(last_seen_seconds)
        timestamp_str = last_seen_dt.strftime("%Y-%m-%d %H:%M:%S UTC")

        # Fetch running commands for this host
        running_commands = await get_running_commands(host_)

        return ft.Div(
            ft.Div(back_link, cls="nav"),
            ft.Div(
                ft.H2(
                    host_,
                    style="margin: 0 0 15px 0; color: var(--text-color); font-size: 24px;",
                ),
                ft.Div(
                    ft.Span(
                        status_text,
                        cls="status-badge",
                        style=f"background: {status_color};",
                    )
                ),
                ft.Div(
                    ft.Div(
                        f"Last seen: {last_seen_str}",
                        style="color: var(--text-secondary); margin-bottom: 5px;",
                    ),
                    ft.Div(
                        f"Timestamp: {timestamp_str}",
                        style="color: var(--text-secondary); margin-bottom: 5px; font-size: 12px;",
                    ),
                    ft.Div(
                        f"Uptime: {uptime_str}",
                        style="color: var(--text-secondary); margin-bottom: 15px;",
                    ),
                ),
                ft.Div(
                    ft.Div(
                        f"CPU Utilization: {utilization:.1f}%"
                        if utilization is not None
                        else "CPU: N/A",
                        style="font-size: 14px; color: var(--text-color); margin-bottom: 5px;",
                    ),
                    create_svg_chart(ts_data, "utilization", "#2196f3")
                    if ts_data
                    else ft.Div("No data", style="color: var(--text-secondary);"),
                    style="margin-bottom: 20px;",
                ),
                ft.Div(
                    ft.Div(
                        f"Temperature: {temperature:.1f}°C"
                        if temperature is not None
                        else "Temperature: N/A",
                        style="font-size: 14px; color: var(--text-color); margin-bottom: 5px;",
                    ),
                    create_svg_chart(ts_data, "temperature", "#ff9800")
                    if ts_data
                    else ft.Div("No data", style="color: var(--text-secondary);"),
                    style="margin-bottom: 20px;",
                ),
                create_running_commands_section(running_commands),
                cls="panel",
                style="padding: 20px;",
            ),
        )

    @app_fastapi.get("/api/dashboard")
    async def api_dashboard(request: Request):
        """API endpoint for dashboard data (used by htmx)."""

        # Generate node detail URLs with proper prefix support
        def node_detail_url_fn(hostname: str) -> str:
            return str(request.url_for("node_detail", host_=hostname))

        content = await dashboard_fragment(node_detail_url_fn=node_detail_url_fn)
        return HTMLResponse(to_xml(content))

    @app_fastapi.get("/api/node/{host_}")
    async def api_node_detail(request: Request, host_: str):
        """API endpoint for detailed node view."""
        content = await node_detail_fragment(host_)
        return HTMLResponse(to_xml(content))

    @app_fastapi.get("/node/{host_}", name="node_detail")
    async def node_detail_page(request: Request, host_: str):
        """Full page view for a specific host."""
        from .navigation import create_nav, NAV_CSS

        # Generate back URL with proper prefix support
        back_url = str(request.url_for("index"))
        content = await node_detail_fragment(host_, back_url=back_url)
        page = ft.Html(
            ft.Head(
                ft.Title(f"{host_} - cocobolo"),
                ft.Style(
                    """
                    :root {
                        --bg-color: #f5f5f5;
                        --container-bg: #ffffff;
                        --text-color: #333333;
                        --text-secondary: #666666;
                        --border-color: #dddddd;
                        --table-header-bg: #f8f8f8;
                        --table-row-hover: #f5f5f5;
                        --panel-shadow: 0 2px 4px rgba(0,0,0,0.1);
                        --chart-bg: #fafafa;
                        --status-online: #4caf50;
                        --status-stale: #f44336;
                        --status-offline: #9e9e9e;
                        --nav-bg: #ffffff;
                        --nav-border: #e0e0e0;
                        --nav-link-color: #666666;
                        --nav-link-active: #2196f3;
                        --nav-link-hover: #333333;
                    }
                    @media (prefers-color-scheme: dark) {
                        :root {
                            --bg-color: #1a1a1a;
                            --container-bg: #2d2d2d;
                            --text-color: #e0e0e0;
                            --text-secondary: #a0a0a0;
                            --border-color: #444444;
                            --table-header-bg: #3d3d3d;
                            --table-row-hover: #3a3a3a;
                            --panel-shadow: 0 2px 6px rgba(0,0,0,0.4);
                            --chart-bg: #262626;
                            --status-online: #66bb6a;
                            --status-stale: #ef5350;
                            --status-offline: #757575;
                            --nav-bg: #2d2d2d;
                            --nav-border: #444444;
                            --nav-link-color: #b0b0b0;
                            --nav-link-active: #90caf9;
                            --nav-link-hover: #e0e0e0;
                        }
                    }
                    body {
                        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                        background: var(--bg-color);
                        margin: 0;
                        padding: 0;
                        color: var(--text-color);
                    }
                    .container {
                        max-width: 1200px;
                        margin: 0 auto;
                        padding: 20px;
                    }
                    .panel {
                        background: var(--container-bg);
                        border-radius: 8px;
                        box-shadow: var(--panel-shadow);
                        padding: 20px;
                        margin-bottom: 20px;
                    }
                    h1 {
                        margin: 0 0 20px 0;
                        color: var(--text-color);
                        font-size: 24px;
                        font-weight: 600;
                    }
                    .status-badge {
                        display: inline-block;
                        padding: 4px 12px;
                        border-radius: 12px;
                        font-size: 12px;
                        font-weight: 600;
                        text-transform: uppercase;
                        color: white;
                    }
                    .chart {
                        background: var(--chart-bg);
                        border: 1px solid var(--border-color);
                        border-radius: 4px;
                    }
                    .hint {
                        color: var(--text-secondary);
                        font-size: 14px;
                        margin-bottom: 15px;
                    }
                    .nav {
                        margin-bottom: 15px;
                    }
                    .nav a {
                        color: var(--nav-link-active);
                        text-decoration: none;
                        font-size: 14px;
                    }
                    .nav a:hover { text-decoration: underline; }
                    """
                ),
                ft.Style(NAV_CSS),
            ),
            ft.Body(
                create_nav(request, active="index"),
                ft.Div(
                    ft.H1(f"Host: {host_}"),
                    content,
                    cls="container",
                ),
            ),
        )
        return HTMLResponse(to_xml(page))

    @app_fastapi.get("/api/nodes")
    async def api_nodes():
        """API endpoint for nodes data (JSON)."""
        rows = await get_latest_heartbeats()
        result = []

        for row in rows:
            host_ = row["host"]
            ts = row["ts"]
            uptime = row.get("uptime")
            temperature = row.get("temperature")

            last_seen_dt = julian_to_datetime(ts)
            now = datetime.now(timezone.utc)
            last_seen_seconds = int((now - last_seen_dt).total_seconds())
            uptime_seconds = int(uptime) if uptime else None

            result.append(
                {
                    "host": host_,
                    "last_seen": last_seen_seconds,
                    "uptime": uptime_seconds,
                    "temperature": temperature,
                }
            )

        result.sort(key=lambda x: x.get("uptime") or 0, reverse=True)
        return result

    # Mail API endpoints
    from fastapi import Query, HTTPException
    from fastapi.responses import Response, PlainTextResponse

    @app_fastapi.get("/api/mails")
    async def api_mails(
        hours: int = Query(default=24, ge=1, le=168, description="Hours to look back"),
        limit: int = Query(default=100, ge=1, le=1000, description="Max results"),
    ):
        """API endpoint for listing emails."""
        from ..services.mail_service import list_mails, mail_summary_to_dict

        mails = await list_mails(db_path, hours=hours, limit=limit)
        return [mail_summary_to_dict(mail) for mail in mails]

    @app_fastapi.get("/api/mails/{mail_id}")
    async def api_mail_detail(
        mail_id: int,
        include_raw: bool = Query(
            default=False, description="Include base64-encoded raw email"
        ),
    ):
        """API endpoint for detailed email view."""
        from ..services.mail_service import get_mail, mail_detail_to_dict

        mail = await get_mail(db_path, mail_id, include_raw=include_raw)
        if not mail:
            raise HTTPException(status_code=404, detail=f"Email {mail_id} not found")

        return mail_detail_to_dict(mail, include_raw=include_raw)

    @app_fastapi.get("/api/mails/{mail_id}/raw")
    async def api_mail_raw(mail_id: int):
        """API endpoint for raw email content."""
        from ..services.mail_service import get_mail

        mail = await get_mail(db_path, mail_id, include_raw=True)
        if not mail or not mail.raw_bytes:
            raise HTTPException(
                status_code=404, detail=f"Email {mail_id} not found or raw unavailable"
            )

        return PlainTextResponse(
            content=mail.raw_bytes.decode("utf-8", errors="replace"),
            media_type="message/rfc822",
        )

    @app_fastapi.get(
        "/api/mails/{mail_id}/attachments/{attachment_index}",
        name="api_mail_attachment",
    )
    async def api_mail_attachment(mail_id: int, attachment_index: int):
        """API endpoint for downloading email attachments."""
        from ..services.mail_service import get_mail_attachment

        result = await get_mail_attachment(db_path, mail_id, attachment_index)
        if not result:
            raise HTTPException(
                status_code=404,
                detail=f"Attachment {attachment_index} not found in email {mail_id}",
            )

        filename, content, content_type = result
        return Response(
            content=content,
            media_type=content_type,
            headers={"Content-Disposition": f'attachment; filename="{filename}"'},
        )
