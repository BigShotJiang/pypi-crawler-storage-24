"""Event routes for sending MQTT events to hosts."""

from __future__ import annotations

import json
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any

from fastapi import Request, HTTPException
from fastapi.responses import HTMLResponse
from fasthtml import ft
from fasthtml.core import to_xml

from ..config import Config
from ..sources.plugins.mqtt import BrokerConfig, MqttBroker
from .navigation import create_nav


def register_event_routes(app_fastapi: Any, db_path: Path, config: Config) -> None:
    """Register event routes onto an existing FastAPI app."""

    from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker
    from sqlalchemy import select, func, Table, MetaData

    db_url = f"sqlite+aiosqlite:///{db_path}"
    engine = create_async_engine(db_url, future=True)
    async_session = async_sessionmaker(engine, expire_on_commit=False)

    async def load_table():
        async with engine.connect() as conn:
            metadata = MetaData()
            return await conn.run_sync(
                lambda sync_conn: Table("heartbeat", metadata, autoload_with=sync_conn)
            )

    table_holder: dict[str, Any] = {"table": None}

    async def ensure_table() -> Any:
        if table_holder["table"] is None:
            table_holder["table"] = await load_table()
        return table_holder["table"]

    def get_mqtt_broker() -> BrokerConfig | None:
        """Get MQTT broker config - prefer 'main', else use the only one."""
        mqtt_sources = []
        for source in config.sources:
            if getattr(source, "type", None) == "mqtt":
                mqtt_sources.append(source)

        if not mqtt_sources:
            return None

        # Prefer broker named "main"
        for source in mqtt_sources:
            broker = getattr(source, "broker", None)
            if broker and getattr(broker, "client_id", None) == "main":
                return broker

        # Otherwise use the first one
        return getattr(mqtt_sources[0], "broker", None)

    async def get_online_hosts() -> list[str]:
        """Get list of online hosts from heartbeat table (active in last 2 minutes)."""
        table = await ensure_table()
        async with async_session() as session:
            # Get latest heartbeat per host
            subq = (
                select(func.max(table.c.id).label("max_id"), table.c.host)
                .group_by(table.c.host)
                .subquery()
            )
            stmt = select(table).join(subq, table.c.id == subq.c.max_id)
            result = await session.execute(stmt)
            rows = result.fetchall()

            online_hosts = []
            now = datetime.now(timezone.utc)

            for row in rows:
                host = row.host
                # Convert julian day to datetime
                J2000 = 2451545.0
                J2000_DATETIME = datetime(2000, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
                last_seen = J2000_DATETIME + timedelta(days=row.ts - J2000)

                # Host is online if seen in last 2 minutes
                if (now - last_seen).total_seconds() < 120:
                    online_hosts.append(host)

            return sorted(online_hosts)

    @app_fastapi.get("/api/events")
    async def api_events():
        """Get available events."""
        events = {}
        for spec in config.get_all_events():
            events[spec.name] = {
                "title": spec.display_title,
                "description": spec.description,
            }

        broker = get_mqtt_broker()

        return {
            "events": events,
            "mqtt_connected": broker is not None,
        }

    @app_fastapi.post("/api/events/send")
    @app_fastapi.post("/api/events/send/")
    async def api_send_event(request: Request):
        """Send an event via MQTT."""
        from pydantic import BaseModel, ValidationError

        class EventRequest(BaseModel):
            event: str

        try:
            data = await request.json()
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Invalid JSON body: {str(e)}")

        try:
            event_req = EventRequest(**data)
        except ValidationError as e:
            raise HTTPException(
                status_code=400, detail=f"Invalid request: {e.errors()[0]['msg']}"
            )

        # Validate event exists
        event_spec = config.get_event_spec(event_req.event)
        if event_spec is None:
            raise HTTPException(
                status_code=400, detail=f"Unknown event: {event_req.event}"
            )

        # Get MQTT broker
        broker_config = get_mqtt_broker()
        if not broker_config:
            raise HTTPException(status_code=500, detail="No MQTT broker configured")

        # Publish event via MQTT
        try:
            broker = MqttBroker(config=broker_config)
            broker.start()
            await broker.ready()

            # Topic format: event/{name} (with spaces converted to dashes)
            topic = f"event/{event_spec.name.replace(' ', '-')}"
            payload = json.dumps({}).encode("utf-8")

            broker.publish(topic, payload, qos=1)
            broker.stop()

            return {"success": True, "topic": topic}
        except Exception as e:
            raise HTTPException(
                status_code=500, detail=f"Failed to send event: {str(e)}"
            )

    async def load_events_table():
        async with engine.connect() as conn:
            metadata = MetaData()
            return await conn.run_sync(
                lambda sync_conn: Table("events", metadata, autoload_with=sync_conn)
            )

    events_table_holder: dict[str, Any] = {"table": None}

    async def ensure_events_table() -> Any:
        if events_table_holder["table"] is None:
            events_table_holder["table"] = await load_events_table()
        return events_table_holder["table"]

    def julian_to_datetime(jd: float) -> datetime:
        """Convert Julian day to UTC datetime."""
        J2000 = 2451545.0
        J2000_DATETIME = datetime(2000, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        days_since_j2000 = jd - J2000
        return J2000_DATETIME + timedelta(days=days_since_j2000)

    def format_relative_time(seconds: int) -> str:
        """Format seconds as relative time."""
        if seconds < 60:
            return f"{seconds}s ago"
        if seconds < 3600:
            return f"{seconds // 60}m ago"
        if seconds < 86400:
            return f"{seconds // 3600}h ago"
        if seconds < 604800:
            return f"{seconds // 86400}d ago"
        return f"{seconds // 604800}w ago"

    async def get_recent_events(limit: int = 100):
        """Get recent events from database."""
        table = await ensure_events_table()
        async with async_session() as session:
            stmt = select(table).order_by(table.c.id.desc()).limit(limit)
            result = await session.execute(stmt)
            rows = result.fetchall()

            return [
                {
                    "id": row.id,
                    "name": row.name,
                    "ts": row.ts,
                    "payload": row.payload,
                }
                for row in rows
            ]

    @app_fastapi.get("/api/events/history")
    async def api_events_history():
        """Get recent events history."""
        try:
            events = await get_recent_events(limit=100)
            return {"events": events}
        except Exception as e:
            raise HTTPException(
                status_code=500, detail=f"Failed to fetch events: {str(e)}"
            )

    @app_fastapi.get("/history", name="history_ui")
    async def events_history_page(request: Request):
        """Events history viewer page."""
        page = ft.Html(
            ft.Head(
                ft.Title("History - cocobolo"),
                ft.Script(src="https://unpkg.com/htmx.org@2.0.4"),
                ft.Style(
                    """
                    :root {
                        --bg-color: #f5f5f5;
                        --container-bg: #ffffff;
                        --text-color: #333333;
                        --text-secondary: #666666;
                        --border-color: #dddddd;
                        --link-color: #2196f3;
                        --panel-shadow: 0 2px 4px rgba(0,0,0,0.1);

                        --nav-bg: #ffffff;
                        --nav-border: #e0e0e0;
                        --nav-link-color: #666666;
                        --nav-link-active: #2196f3;
                        --nav-link-hover: #333333;
                    }
                    @media (prefers-color-scheme: dark) {
                        :root {
                            --bg-color: #1a1a1a;
                            --container-bg: #2d2d2d;
                            --text-color: #e0e0e0;
                            --text-secondary: #a0a0a0;
                            --border-color: #444444;
                            --link-color: #64b5f6;
                            --panel-shadow: 0 2px 6px rgba(0,0,0,0.4);

                            --nav-bg: #2d2d2d;
                            --nav-border: #444444;
                            --nav-link-color: #a0a0a0;
                            --nav-link-active: #64b5f6;
                            --nav-link-hover: #e0e0e0;
                        }
                    }
                    body {
                        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                        margin: 0;
                        padding: 0;
                        background: var(--bg-color);
                        color: var(--text-color);
                    }
                    .container {
                        max-width: 900px;
                        margin: 0 auto;
                        padding: 20px;
                    }
                    .panel {
                        background: var(--container-bg);
                        border: 1px solid var(--border-color);
                        border-radius: 8px;
                        padding: 15px;
                        box-shadow: var(--panel-shadow);
                        overflow-x: auto;
                    }
                    h1 { color: var(--text-color); margin-bottom: 20px; }
                    table {
                        width: 100%;
                        border-collapse: collapse;
                        font-size: 14px;
                        background: var(--container-bg);
                    }
                    th {
                        text-align: left;
                        padding: 12px;
                        border-bottom: 2px solid var(--border-color);
                        background: var(--table-header-bg, var(--nav-bg));
                        color: var(--text-color);
                        font-weight: 600;
                    }
                    td {
                        padding: 12px;
                        border-bottom: 1px solid var(--border-color);
                        color: var(--text-color);
                    }
                    tr:hover { background-color: var(--table-row-hover, rgba(128,128,128,0.1)); }
                    .event-name { font-weight: 500; }
                    .event-time-absolute { color: var(--text-color); font-family: monospace; font-size: 13px; }
                    .event-time-relative { color: var(--text-secondary); }
                    .hint {
                        color: var(--text-secondary);
                        font-size: 12px;
                        margin-bottom: 10px;
                        font-style: italic;
                    }

                    /* Navigation Bar */
                    .navbar {
                        background: var(--nav-bg);
                        border-bottom: 1px solid var(--nav-border);
                        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
                        margin-bottom: 30px;
                    }
                    .nav-container {
                        max-width: 1000px;
                        margin: 0 auto;
                        padding: 0 20px;
                        display: flex;
                        align-items: center;
                        justify-content: space-between;
                        height: 60px;
                    }
                    .nav-brand {
                        font-size: 20px;
                        font-weight: 600;
                        color: var(--text-color);
                        text-decoration: none;
                        letter-spacing: -0.5px;
                    }
                    .nav-brand:hover {
                        color: var(--nav-link-active);
                    }
                    .nav-links {
                        display: flex;
                        gap: 8px;
                    }
                    .nav-link {
                        padding: 8px 16px;
                        color: var(--nav-link-color);
                        text-decoration: none;
                        font-size: 14px;
                        font-weight: 500;
                        border-radius: 6px;
                        transition: all 0.2s ease;
                    }
                    .nav-link:hover {
                        color: var(--nav-link-hover);
                        background: var(--bg-color);
                    }
                    .nav-link.active {
                        color: var(--nav-link-active);
                        background: rgba(33, 150, 243, 0.1);
                    }
                    @media (prefers-color-scheme: dark) {
                        .nav-link.active {
                            background: rgba(100, 181, 246, 0.15);
                        }
                    }
                    """
                ),
            ),
            ft.Body(
                create_nav(request, active="history_ui"),
                ft.Div(
                    ft.H1("History"),
                    ft.Div(
                        ft.Div("Recent events (auto-refresh every 10s)", cls="hint"),
                        ft.Div(
                            id="events-content",
                            hx_get=str(request.url_for("api_events_history_fragment")),
                            hx_trigger="load, every 10s",
                            hx_swap="innerHTML",
                            style="min-height: 100px;",
                        ),
                        cls="panel",
                    ),
                    cls="container",
                ),
            ),
        )
        return HTMLResponse(to_xml(page))

    @app_fastapi.get("/api/events/history/fragment")
    async def api_events_history_fragment():
        """API endpoint for events history table fragment (used by htmx)."""
        try:
            events = await get_recent_events(limit=100)
        except Exception:
            return HTMLResponse("<div>Error loading events</div>")

        if not events:
            return HTMLResponse(
                to_xml(
                    ft.Div(
                        "No events found in database.",
                        style="text-align: center; padding: 40px; color: var(--text-secondary);",
                    )
                )
            )

        table_rows = []
        for event in events:
            event_dt = julian_to_datetime(event["ts"])
            now = datetime.now(timezone.utc)
            seconds_ago = int((now - event_dt).total_seconds())
            time_str = format_relative_time(seconds_ago)

            # Format absolute time as ISO UTC
            iso_time = event_dt.strftime("%Y-%m-%dT%H:%M:%SZ")

            table_rows.append(
                ft.ft(
                    "tr",
                    ft.ft("td", event["name"], cls="event-name"),
                    ft.ft("td", iso_time, cls="event-time-absolute"),
                    ft.ft("td", time_str, cls="event-time-relative"),
                )
            )

        table = ft.ft(
            "table",
            ft.ft(
                "thead",
                ft.ft(
                    "tr",
                    ft.ft("th", "Event"),
                    ft.ft("th", "Time"),
                    ft.ft("th", "Ago"),
                ),
            ),
            ft.ft("tbody", *table_rows),
        )

        return HTMLResponse(to_xml(table))

    @app_fastapi.get("/events", name="events_ui")
    async def events_page(request: Request):
        """Event sending UI page."""
        # Get all events preserving list order
        events = config.get_all_events()

        # Empty state message
        empty_state = ""
        if not events:
            empty_state = ft.Div(
                "No events configured in config file.",
                style="color: var(--text-secondary); font-style: italic; margin: 20px 0;",
            )

        # Build event buttons and generate CSS
        event_buttons = []
        event_css = []
        default_color = "#e0e0e0"
        default_color_dark = "#424242"

        for spec in events:
            title = spec.display_title
            description = spec.description or ""

            # Determine colors (priority: color_light/dark -> color -> default)
            color_light = (
                getattr(spec, "color_light", None)
                or getattr(spec, "color", None)
                or default_color
            )
            color_dark = (
                getattr(spec, "color_dark", None)
                or getattr(spec, "color", None)
                or default_color_dark
            )

            # Determine CSS (priority: css_light/dark -> css -> "")
            css_light = (
                getattr(spec, "css_light", None) or getattr(spec, "css", None) or ""
            )
            css_dark = (
                getattr(spec, "css_dark", None) or getattr(spec, "css", None) or ""
            )

            # Generate CSS class for this event
            event_name = spec.name
            css_class = f"event-btn-{event_name.replace(' ', '-').lower()}"
            event_css.append(f"""
                .{css_class} {{
                    background-color: {color_light};
                    {css_light}
                }}
                @media (prefers-color-scheme: dark) {{
                    .{css_class} {{
                        background-color: {color_dark};
                        {css_dark}
                    }}
                }}
            """)

            event_buttons.append(
                ft.Button(
                    title,
                    type="button",
                    cls=f"event-button {css_class}",
                    title=description,
                    onclick=f"sendEvent('{event_name}')",
                )
            )

        # Build event grid
        event_grid = (
            ft.Div(
                *event_buttons,
                cls="event-grid",
            )
            if event_buttons
            else ""
        )

        page = (
            ft.Html(
                ft.Head(
                    ft.Title("Events - cocobolo"),
                    ft.Script(src="https://unpkg.com/htmx.org@2.0.4"),
                    ft.Style(
                        f"""
                    :root {{
                        --bg-color: #f5f5f5;
                        --container-bg: #ffffff;
                        --text-color: #333333;
                        --text-secondary: #666666;
                        --border-color: #dddddd;
                        --link-color: #2196f3;
                        --panel-shadow: 0 2px 4px rgba(0,0,0,0.1);
                        --success-color: #4caf50;
                        --error-color: #f44336;

                        --nav-bg: #ffffff;
                        --nav-border: #e0e0e0;
                        --nav-link-color: #666666;
                        --nav-link-active: #2196f3;
                        --nav-link-hover: #333333;
                    }}
                    @media (prefers-color-scheme: dark) {{
                        :root {{
                            --bg-color: #1a1a1a;
                            --container-bg: #2d2d2d;
                            --text-color: #e0e0e0;
                            --text-secondary: #a0a0a0;
                            --border-color: #444444;
                            --link-color: #64b5f6;
                            --panel-shadow: 0 2px 6px rgba(0,0,0,0.4);

                            --nav-bg: #2d2d2d;
                            --nav-border: #444444;
                            --nav-link-color: #a0a0a0;
                            --nav-link-active: #64b5f6;
                            --nav-link-hover: #e0e0e0;
                        }}
                    }}
                    body {{
                        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                        margin: 0;
                        padding: 0;
                        background: var(--bg-color);
                        color: var(--text-color);
                    }}
                    .container {{
                        max-width: 900px;
                        margin: 0 auto;
                        padding: 20px;
                    }}
                    .panel {{
                        background: var(--container-bg);
                        border: 1px solid var(--border-color);
                        border-radius: 8px;
                        padding: 20px;
                        box-shadow: var(--panel-shadow);
                    }}
                    h1 {{ margin: 0 0 20px 0; color: var(--text-color); }}
                    .event-grid {{
                        display: flex;
                        flex-wrap: wrap;
                        justify-content: center;
                        gap: 15px;
                        margin-bottom: 20px;
                    }}
                    .event-button {{
                        width: 140px;
                        height: 140px;
                        border: none;
                        border-radius: 8px;
                        cursor: pointer;
                        font-size: 16px;
                        font-weight: 500;
                        color: var(--text-color);
                        transition: all 0.2s ease;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        text-align: center;
                        word-wrap: break-word;
                        padding: 10px;
                    }}
                    .event-button:hover {{
                        transform: scale(1.05);
                        opacity: 0.9;
                    }}
                    .event-button:active {{
                        transform: scale(0.95);
                    }}
                    .result {{
                        margin-top: 15px;
                        padding: 10px;
                        border-radius: 4px;
                        display: none;
                    }}
                    .result.success {{
                        background: rgba(76, 175, 80, 0.1);
                        border: 1px solid var(--success-color);
                        color: var(--success-color);
                        display: block;
                    }}
                    .result.error {{
                        background: rgba(244, 67, 54, 0.1);
                        border: 1px solid var(--error-color);
                        color: var(--error-color);
                        display: block;
                    }}

                    /* Event-specific styles */
                    {" ".join(event_css)}

                    /* Navigation Bar */
                    .navbar {{
                        background: var(--nav-bg);
                        border-bottom: 1px solid var(--nav-border);
                        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
                        margin-bottom: 30px;
                    }}
                    .nav-container {{
                        max-width: 1000px;
                        margin: 0 auto;
                        padding: 0 20px;
                        display: flex;
                        align-items: center;
                        justify-content: space-between;
                        height: 60px;
                    }}
                    .nav-brand {{
                        font-size: 20px;
                        font-weight: 600;
                        color: var(--text-color);
                        text-decoration: none;
                        letter-spacing: -0.5px;
                    }}
                    .nav-brand:hover {{
                        color: var(--nav-link-active);
                    }}
                    .nav-links {{
                        display: flex;
                        gap: 8px;
                    }}
                    .nav-link {{
                        padding: 8px 16px;
                        color: var(--nav-link-color);
                        text-decoration: none;
                        font-size: 14px;
                        font-weight: 500;
                        border-radius: 6px;
                        transition: all 0.2s ease;
                    }}
                    .nav-link:hover {{
                        color: var(--nav-link-hover);
                        background: var(--bg-color);
                    }}
                    .nav-link.active {{
                        color: var(--nav-link-active);
                        background: rgba(33, 150, 243, 0.1);
                    }}
                    @media (prefers-color-scheme: dark) {{
                        .nav-link.active {{
                            background: rgba(100, 181, 246, 0.15);
                        }}
                    }}
                    """
                    ),
                ),
                ft.Body(
                    create_nav(request, active="events_ui"),
                    ft.Div(
                        ft.Div(
                            ft.H1(
                                "Send Event", style="margin: 0; display: inline-block;"
                            ),
                            ft.A(
                                "View History →",
                                href=str(request.url_for("history_ui")),
                                style="color: var(--link-color); text-decoration: none; font-size: 14px; margin-left: 15px;",
                            ),
                            style="display: flex; align-items: center; margin-bottom: 20px;",
                        ),
                        ft.Div(
                            empty_state if empty_state else event_grid,
                            ft.Div(id="result", cls="result"),
                            ft.Script(
                                """
                            async function sendEvent(eventName) {
                                const resultDiv = document.getElementById('result');

                                try {
                                    // Build URL that works with proxy prefix
                                    const currentPath = window.location.pathname;
                                    const basePath = currentPath.substring(0, currentPath.lastIndexOf('/'));
                                    const apiUrl = basePath + '/api/events/send';

                                    const response = await fetch(apiUrl, {
                                        method: 'POST',
                                        headers: {'Content-Type': 'application/json'},
                                        body: JSON.stringify({event: eventName})
                                    });

                                    // Get raw text first to debug
                                    const responseText = await response.text();
                                    let data;
                                    try {
                                        data = JSON.parse(responseText);
                                    } catch (parseErr) {
                                        resultDiv.className = 'result error';
                                        resultDiv.textContent = 'JSON parse error: ' + parseErr.message + ' | Raw response: ' + responseText.substring(0, 200);
                                        return;
                                    }

                                    if (response.ok) {
                                        resultDiv.className = 'result success';
                                        resultDiv.textContent = 'Event sent successfully';
                                        setTimeout(() => {
                                            resultDiv.className = 'result';
                                            resultDiv.textContent = '';
                                        }, 3000);
                                    } else {
                                        resultDiv.className = 'result error';
                                        resultDiv.textContent = 'Error: ' + (data.detail || 'Unknown error');
                                        setTimeout(() => {
                                            resultDiv.className = 'result';
                                            resultDiv.textContent = '';
                                        }, 5000);
                                    }
                                } catch (err) {
                                    resultDiv.className = 'result error';
                                    resultDiv.textContent = 'Network error: ' + err.message;
                                    setTimeout(() => {
                                        resultDiv.className = 'result';
                                        resultDiv.textContent = '';
                                    }, 5000);
                                }
                            }
                            """
                            ),
                            cls="panel",
                        ),
                        cls="container",
                    ),
                ),
            ),
        )
        return HTMLResponse(to_xml(page))
