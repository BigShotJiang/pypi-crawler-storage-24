"""Pytest fixtures for cocobolo tests."""

from __future__ import annotations

import tempfile
from pathlib import Path
from typing import Any

import pytest

from cocobolo.config import Config, EventSpec, CommandSpec, Route


@pytest.fixture
def temp_db_path() -> Path:
    """Create a temporary database file path."""
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        return Path(f.name)


@pytest.fixture
def sample_event_spec() -> EventSpec:
    """Create a sample EventSpec."""
    return EventSpec(
        name="test_event",
        title="Test Event",
        description="A test event for testing",
        color="#e3f2fd",
        color_light=None,
        color_dark="#1565c0",
        css="font-weight: bold;",
        css_light=None,
        css_dark=None,
    )


@pytest.fixture
def sample_command_spec_string() -> CommandSpec:
    """Create a sample CommandSpec from string form (display-only)."""
    return CommandSpec.from_config_value("display_only_cmd")


@pytest.fixture
def sample_command_spec_dict() -> CommandSpec:
    """Create a sample CommandSpec from dict form."""
    return CommandSpec.from_config_value(
        {
            "name": "test_cmd",
            "argv": ["echo", "hello"],
            "groups": ["test"],
            "cwd": "/tmp",
        }
    )


@pytest.fixture
def minimal_config_dict() -> dict[str, Any]:
    """Create a minimal valid config dictionary."""
    return {
        "database": ":memory:",
        "sources": [],
        "routes": [],
    }


@pytest.fixture
def full_config_dict() -> dict[str, Any]:
    """Create a full config dictionary with all optional fields."""
    return {
        "database": ":memory:",
        "sources": [],
        "routes": [
            {
                "pattern": "test/#",
                "actions": [],
            }
        ],
        "commands": [
            {"name": "test_cmd", "argv": ["echo", "test"]},
        ],
        "events": [
            {
                "name": "test_event",
                "title": "Test Event",
            }
        ],
    }


@pytest.fixture
def minimal_config(minimal_config_dict: dict[str, Any]) -> Config:
    """Create a minimal Config instance."""
    return Config.model_validate(minimal_config_dict)


@pytest.fixture
def full_config(full_config_dict: dict[str, Any]) -> Config:
    """Create a full Config instance."""
    return Config.model_validate(full_config_dict)
