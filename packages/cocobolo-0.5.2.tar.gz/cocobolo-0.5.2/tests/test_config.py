"""Tests for cocobolo configuration."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from cocobolo.config import Config, EventSpec, CommandSpec


class TestEventSpec:
    """Tests for EventSpec model."""

    def test_create_event_spec(self, sample_event_spec: EventSpec) -> None:
        """Test creating an EventSpec with all fields."""
        assert sample_event_spec.name == "test_event"
        assert sample_event_spec.title == "Test Event"
        assert sample_event_spec.description == "A test event for testing"
        assert sample_event_spec.color == "#e3f2fd"
        assert sample_event_spec.color_dark == "#1565c0"
        assert sample_event_spec.css == "font-weight: bold;"

    def test_create_event_spec_minimal(self) -> None:
        """Test creating an EventSpec with minimal fields."""
        spec = EventSpec(
            name="minimal",
            title=None,
            description=None,
            color=None,
            color_light=None,
            color_dark=None,
            css=None,
            css_light=None,
            css_dark=None,
        )
        assert spec.name == "minimal"
        assert spec.title is None
        assert spec.description is None
        assert spec.color is None
        assert spec.color_light is None
        assert spec.color_dark is None
        assert spec.css is None
        assert spec.css_light is None
        assert spec.css_dark is None

    def test_from_string_form(self) -> None:
        """Test creating EventSpec from string form."""
        spec = EventSpec.from_config_value("my_event")
        assert spec.name == "my_event"
        assert spec.title == "my_event"
        assert spec.description is None

    def test_from_dict_form(self) -> None:
        """Test creating EventSpec from dict form."""
        spec = EventSpec.from_config_value(
            {"name": "test_event", "title": "Test Event", "color": "blue"}
        )
        assert spec.name == "test_event"
        assert spec.title == "Test Event"
        assert spec.color == "blue"

    def test_from_config_value_invalid(self) -> None:
        """Test that invalid config values raise TypeError."""
        with pytest.raises(TypeError, match="Event must be a string"):
            EventSpec.from_config_value(123)

    def test_display_title_fallback(self) -> None:
        """Test that display_title falls back to name."""
        spec = EventSpec.from_config_value("my_event")
        assert spec.display_title == "my_event"

    def test_display_title_override(self) -> None:
        """Test that display_title uses title when provided."""
        spec = EventSpec.from_config_value({"name": "evt", "title": "My Event"})
        assert spec.display_title == "My Event"


class TestCommandSpec:
    """Tests for CommandSpec model."""

    def test_from_string_form(self, sample_command_spec_string: CommandSpec) -> None:
        """Test creating CommandSpec from string form (display-only)."""
        assert sample_command_spec_string.name == "display_only_cmd"
        assert sample_command_spec_string.argv is None
        assert not sample_command_spec_string.is_executable

    def test_from_dict_form(self, sample_command_spec_dict: CommandSpec) -> None:
        """Test creating CommandSpec from dict form."""
        assert sample_command_spec_dict.name == "test_cmd"
        assert sample_command_spec_dict.argv == ["echo", "hello"]
        assert sample_command_spec_dict.groups == ["test"]
        assert sample_command_spec_dict.cwd == "/tmp"
        assert sample_command_spec_dict.is_executable

    def test_from_config_value_invalid(self) -> None:
        """Test that invalid config values raise TypeError."""
        with pytest.raises(TypeError, match="Command must be a string"):
            CommandSpec.from_config_value(123)

    def test_default_kill_after(self, sample_command_spec_dict: CommandSpec) -> None:
        """Test default kill_after value."""
        assert sample_command_spec_dict.kill_after == 5.0

    def test_display_title_fallback(self) -> None:
        """Test that display_title falls back to name."""
        spec = CommandSpec.from_config_value("my_command")
        assert spec.display_title == "my_command"

    def test_display_title_override(self) -> None:
        """Test that display_title uses title when provided."""
        spec = CommandSpec.from_config_value(
            {"name": "cmd", "title": "My Command", "argv": ["echo"]}
        )
        assert spec.display_title == "My Command"


class TestConfig:
    """Tests for Config model."""

    def test_minimal_config(self, minimal_config: Config) -> None:
        """Test creating a minimal valid config."""
        assert minimal_config.database == ":memory:"
        assert minimal_config.sources == []
        assert minimal_config.routes == []
        assert minimal_config.commands is None
        assert minimal_config.events is None

    def test_full_config(self, full_config: Config) -> None:
        """Test creating a config with all optional fields."""
        assert full_config.database == ":memory:"
        assert len(full_config.routes) == 1
        assert full_config.commands is not None
        # Commands is now a list
        commands_list = full_config.get_all_commands()
        assert len(commands_list) == 1
        assert commands_list[0].name == "test_cmd"
        assert full_config.events is not None
        # Events is now a list
        events_list = full_config.get_all_events()
        assert len(events_list) == 1
        assert events_list[0].name == "test_event"

    def test_get_event_spec_existing(self, full_config: Config) -> None:
        """Test getting an existing event spec."""
        spec = full_config.get_event_spec("test_event")
        assert spec is not None
        assert spec.display_title == "Test Event"

    def test_get_event_spec_missing(self, full_config: Config) -> None:
        """Test getting a non-existent event spec."""
        spec = full_config.get_event_spec("nonexistent")
        assert spec is None

    def test_get_event_spec_no_events(self, minimal_config: Config) -> None:
        """Test getting event spec when no events configured."""
        spec = minimal_config.get_event_spec("any")
        assert spec is None

    def test_get_all_events(self, full_config: Config) -> None:
        """Test getting all events as EventSpec objects."""
        events = full_config.get_all_events()
        assert len(events) == 1
        assert all(isinstance(e, EventSpec) for e in events)

    def test_get_command_spec_existing(self, full_config: Config) -> None:
        """Test getting an existing command spec."""
        spec = full_config.get_command_spec("test_cmd")
        assert spec is not None
        assert spec.argv == ["echo", "test"]

    def test_get_command_spec_missing(self, full_config: Config) -> None:
        """Test getting a non-existent command spec."""
        spec = full_config.get_command_spec("nonexistent")
        assert spec is None

    def test_get_command_spec_no_commands(self, minimal_config: Config) -> None:
        """Test getting command spec when no commands configured."""
        spec = minimal_config.get_command_spec("any")
        assert spec is None

    def test_invalid_config_missing_database(self) -> None:
        """Test that config without database is valid."""
        config = Config.model_validate({"sources": [], "routes": []})
        assert config.database is None

    def test_config_with_server_string(self) -> None:
        """Test config with server as string URL."""
        config = Config.model_validate(
            {
                "server": "http://localhost:15315",
                "sources": [],
                "routes": [],
            }
        )
        assert config.server == "http://localhost:15315"

    def test_config_with_server_bool(self) -> None:
        """Test config with server as boolean."""
        config = Config.model_validate(
            {
                "server": True,
                "sources": [],
                "routes": [],
            }
        )
        assert config.server is True


class TestConfigValidation:
    """Tests for config validation edge cases."""

    def test_empty_events_list(self) -> None:
        """Test that empty events list is valid."""
        config = Config.model_validate(
            {
                "events": [],
                "sources": [],
                "routes": [],
            }
        )
        assert config.events == []
        assert config.get_all_events() == []

    def test_empty_commands_list(self) -> None:
        """Test that empty commands list is valid."""
        config = Config.model_validate(
            {
                "commands": [],
                "sources": [],
                "routes": [],
            }
        )
        assert config.commands == []

    def test_event_spec_validation_missing_name(self) -> None:
        """Test EventSpec validation with missing name."""
        with pytest.raises(ValidationError):
            EventSpec.model_validate({"title": "Missing name"})

    def test_command_with_env(self) -> None:
        """Test CommandSpec with environment variables."""
        spec = CommandSpec.from_config_value(
            {
                "name": "env_test",
                "argv": ["echo", "$HOME"],
                "env": {"VAR": "value"},
            }
        )
        assert spec.env == {"VAR": "value"}
