"""
config.py
─────────────────────────────────────────────────────────────
역할: Claude Desktop 설정 파일에서 주입된 환경변수를 읽고
      서버 전체에서 공통으로 사용할 값을 제공합니다.

Claude Desktop 설정 예시 (claude_desktop_config.json):
  {
    "mcpServers": {
      "narajangteo": {
        "command": "uvx",
        "args": ["narajangteo-mcp@latest"],
        "env": {
          "API_KEY": "발급받은_인증키"   ← 이 값을 읽어옵니다
        }
      }
    }
  }
─────────────────────────────────────────────────────────────
"""

import os

# ── API 인증키 ───────────────────────────────────────────────
# Claude Desktop "env.API_KEY" 값을 읽습니다
SERVICE_KEY: str = os.environ.get("API_KEY", "")

# ── 나라장터 API 베이스 URL ───────────────────────────────────
# 새 서비스 추가 시 이 딕셔너리에만 등록하면 됩니다
BASE_URLS: dict[str, str] = {
    "bid_notice":  "https://apis.data.go.kr/1230000/ad/BidPublicInfoService",
    # "bid_result":  "https://apis.data.go.kr/1230000/ad/BidResultInfoService",
    # "open_result": "https://apis.data.go.kr/1230000/ad/OpenResultInfoService",
    # "vendor":      "https://apis.data.go.kr/1230000/vd/VendorInfoService",
}

# ── 공통 기본값 ──────────────────────────────────────────────
DEFAULT_PAGE_NO:     int = 1
DEFAULT_NUM_OF_ROWS: int = 10
REQUEST_TIMEOUT:     int = 30
