"""
tools/bid_notice.py
─────────────────────────────────────────────────────────────
역할: 나라장터 공사 입찰공고 관련 MCP tool 정의 및 등록.

현재 구현된 tool:
  - get_bid_notice_list : 공사 입찰공고 목록 조회

추후 추가 가능한 tool:
  - get_bid_notice_detail  : 입찰공고 상세 조회
  - get_bid_notice_service : 용역 입찰공고 목록 조회
  - get_bid_notice_goods   : 물품 입찰공고 목록 조회
─────────────────────────────────────────────────────────────
"""

import json
from mcp.server.fastmcp import FastMCP
from narajangteo_mcp.api import fetch
from narajangteo_mcp.config import BASE_URLS, DEFAULT_PAGE_NO, DEFAULT_NUM_OF_ROWS

# ── 표시 필드 정의 ────────────────────────────────────────────
# 키: API 원본 필드명 / 값: Claude 응답에 표시할 한글 레이블
# 필요한 필드 생기면 여기에만 추가하면 됩니다
DISPLAY_FIELDS: dict[str, str] = {
    "bidNtceNo":              "입찰공고번호",
    "bidNtceOrd":             "차수",
    "bidNtceNm":              "입찰공고명",
    "ntceKindNm":             "공고종류",
    "ntceInsttNm":            "공고기관",
    "dminsttNm":              "수요기관",
    "bidNtceDt":              "공고일시",
    "bidBeginDt":             "입찰시작일시",
    "bidClseDt":              "입찰마감일시",
    "opengDt":                "개찰일시",
    "presmptPrce":            "추정가격(원)",
    "bdgtAmt":                "기초금액(원)",
    "bidMethdNm":             "입찰방식",
    "sucsfbidMthdNm":         "낙찰방법",
    "cntrctCnclsMthdNm":      "계약방법",
    "mainCnsttyNm":           "주요공종",
    "cnstrtsiteRgnNm":        "공사현장지역",
    "pqEvalYn":               "사전심사여부",
    "dsgntCmptYn":            "지명경쟁여부",
    "rgnDutyJntcontrctYn":    "지역의무공동수급여부",
    "ntceInsttOfclNm":        "담당자",
    "ntceInsttOfclTelNo":     "담당자연락처",
    "ntceInsttOfclEmailAdrs": "담당자이메일",
    "bidNtceDtlUrl":          "공고상세URL",
}


def register(mcp: FastMCP) -> None:
    """
    이 모듈의 모든 tool을 MCP 서버에 등록합니다.
    server.py 에서 bid_notice.register(mcp) 으로 호출됩니다.
    """

    @mcp.tool()
    async def get_bid_notice_list(
        inqry_bgn_dt: str,
        inqry_end_dt: str,
        page_no: int = DEFAULT_PAGE_NO,
        num_of_rows: int = DEFAULT_NUM_OF_ROWS,
        inqry_div: int = 1,
        bid_ntce_nm: str = "",
        ntce_instt_nm: str = "",
        main_cnstty_nm: str = "",
        cnstwk_site_rgn_nm: str = "",
    ) -> str:
        """
        나라장터 공사 입찰공고 목록을 조회합니다.

        Args:
            inqry_bgn_dt       : 조회 시작일시 — YYYYMMDDHHMM (예: 202503010000)
            inqry_end_dt       : 조회 종료일시 — YYYYMMDDHHMM (예: 202503312359)
            page_no            : 페이지 번호 (기본: 1)
            num_of_rows        : 페이지당 결과 수 (기본: 10, 최대: 999)
            inqry_div          : 1: 공고일시 기준, 2: 개찰일시 기준 (기본: 1)
            bid_ntce_nm        : 입찰공고명 검색어 (선택)
            ntce_instt_nm      : 공고기관명 검색어 (선택)
            main_cnstty_nm     : 주요공종명 검색어 (선택)
            cnstwk_site_rgn_nm : 공사현장 지역 검색어 (선택)
        """
        params: dict = {
            "pageNo":     str(page_no),
            "numOfRows":  str(num_of_rows),
            "inqryDiv":   str(inqry_div),
            "inqryBgnDt": inqry_bgn_dt,
            "inqryEndDt": inqry_end_dt,
        }
        if bid_ntce_nm:
            params["bidNtceNm"] = bid_ntce_nm
        if ntce_instt_nm:
            params["ntceInsttNm"] = ntce_instt_nm
        if main_cnstty_nm:
            params["mainCnsttyNm"] = main_cnstty_nm
        if cnstwk_site_rgn_nm:
            params["cnstrtsiteRgnNm"] = cnstwk_site_rgn_nm

        body = await fetch(
            BASE_URLS["bid_notice"],
            "getBidPblancListInfoCnstwk",
            params,
        )

        total_count = body.get("totalCount", "0")
        items_raw   = body.get("items") or {}
        raw_list    = items_raw.get("item", [])

        if isinstance(raw_list, dict):
            raw_list = [raw_list]

        items = [
            {
                label: item.get(key, "")
                for key, label in DISPLAY_FIELDS.items()
                if item.get(key)
            }
            for item in raw_list
        ]

        return json.dumps({
            "총건수":      total_count,
            "페이지":      page_no,
            "페이지당건수": num_of_rows,
            "목록":        items,
        }, ensure_ascii=False, indent=2)

    # ── 추후 Tool 추가 공간 ───────────────────────────────────
    # @mcp.tool()
    # async def get_bid_notice_detail(bid_ntce_no: str, bid_ntce_ord: str) -> str:
    #     """입찰공고 상세 조회"""
    #     params = {"bidNtceNo": bid_ntce_no, "bidNtceOrd": bid_ntce_ord}
    #     body = await fetch(BASE_URLS["bid_notice"], "getBidPblancInfoCnstwk", params)
    #     return json.dumps(body, ensure_ascii=False, indent=2)
