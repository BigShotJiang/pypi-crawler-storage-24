﻿from . import bid_notice
__all__ = ["bid_notice"]
