"""
server.py
─────────────────────────────────────────────────────────────
역할: MCP 서버 생성, tool 등록, 실행.

uvx 실행 흐름:
  uvx narajangteo-mcp
    → pyproject.toml 의 [project.scripts] 참조
    → narajangteo_mcp.server:main 호출
    → main() 이 register_all() + mcp.run() 실행

API 키 흐름:
  claude_desktop_config.json "env.API_KEY"
    → Claude Desktop이 환경변수로 주입
    → config.py os.environ.get("API_KEY")
    → api/client.py 모든 요청에 자동 포함
─────────────────────────────────────────────────────────────
"""

from mcp.server.fastmcp import FastMCP
from narajangteo_mcp.tools import bid_notice
# 추후 추가 예시:
# from narajangteo_mcp.tools import bid_result
# from narajangteo_mcp.tools import vendor

mcp = FastMCP(
    "나라장터 MCP 서버",
    instructions=(
        "나라장터(국가종합전자조달시스템) 공공 입찰 정보를 조회합니다. "
        "날짜는 반드시 YYYYMMDDHHMM 형식으로 입력하세요. (예: 202503010000)"
    ),
)


def register_all() -> None:
    """모든 tool 모듈을 MCP 서버에 등록합니다."""
    bid_notice.register(mcp)
    # 추후 추가 예시:
    # bid_result.register(mcp)
    # vendor.register(mcp)


def main() -> None:
    """
    uvx 및 직접 실행 시 호출되는 진입점.
    pyproject.toml [project.scripts] 에 등록되어 있습니다.
    """
    register_all()
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
