﻿from .client import fetch
__all__ = ["fetch"]
