"""
api/client.py
─────────────────────────────────────────────────────────────
역할: 나라장터 API 공통 HTTP GET 요청 함수.
      모든 tool은 이 fetch()를 통해서만 API를 호출합니다.

공통 처리 항목:
  - API_KEY 자동 주입
  - resultCode 검사 및 에러 raise
  - JSON 파싱 후 body 반환
─────────────────────────────────────────────────────────────
"""

import httpx
from narajangteo_mcp.config import SERVICE_KEY, REQUEST_TIMEOUT


async def fetch(base_url: str, endpoint: str, params: dict) -> dict:
    """
    나라장터 API GET 요청 공통 함수.

    Args:
        base_url : config.BASE_URLS 의 값
        endpoint : API 엔드포인트 함수명
        params   : 서비스 고유 파라미터 (serviceKey/type 자동 추가)

    Returns:
        response.body dict

    Raises:
        ValueError      : API 키 미설정 또는 API 에러 코드 반환 시
        httpx.HTTPError : 네트워크 / HTTP 오류 시
    """
    if not SERVICE_KEY:
        raise ValueError(
            "API 키가 설정되지 않았습니다.\n"
            "claude_desktop_config.json 의 env.API_KEY 를 확인하세요."
        )

    full_params = {
        "serviceKey": SERVICE_KEY,
        "type": "json",
        **params,
    }

    async with httpx.AsyncClient(timeout=REQUEST_TIMEOUT) as client:
        response = await client.get(f"{base_url}/{endpoint}", params=full_params)
        response.raise_for_status()
        data = response.json()

    header      = data.get("response", {}).get("header", {})
    result_code = header.get("resultCode", "")
    result_msg  = header.get("resultMsg", "알 수 없는 오류")

    if result_code != "00":
        raise ValueError(f"[나라장터 API 오류 {result_code}] {result_msg}")

    return data.get("response", {}).get("body", {})
