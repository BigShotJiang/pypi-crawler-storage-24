# narajangteo-mcp

나라장터(국가종합전자조달시스템) 공공데이터 API를 Claude Desktop에서 직접 조회할 수 있는 MCP 서버입니다.

---

## Claude Desktop 설정 (사용자용)

설정 파일 위치:
- **macOS**: `~/Library/Application Support/Claude/claude_desktop_config.json`
- **Windows**: `%APPDATA%\Claude\claude_desktop_config.json`

아래 내용을 추가하고 Claude Desktop을 재시작하세요.

```json
{
  "mcpServers": {
    "narajangteo": {
      "command": "uvx",
      "args": ["narajangteo-mcp@latest"],
      "env": {
        "API_KEY": "여기에_공공데이터포털_API_키_입력"
      }
    }
  }
}
```

> **API 키 발급**: [공공데이터포털](https://www.data.go.kr) → "나라장터 입찰공고정보" 검색 → 활용신청

재시작 후 Claude Desktop 좌측 하단 🔧 아이콘이 표시되면 연결 완료입니다.

---

## 사용 예시

```
2025년 3월 한 달간 서울특별시 공사 입찰공고 20건 조회해줘
```
```
경기도 도로포장 관련 입찰공고 찾아줘 (기간: 202503010000 ~ 202503312359)
```

---

## 현재 Tool 목록

### `get_bid_notice_list` — 공사 입찰공고 목록 조회

| 파라미터 | 필수 | 설명 | 예시 |
|---|:---:|---|---|
| `inqry_bgn_dt` | ✅ | 조회 시작일시 (YYYYMMDDHHMM) | `202503010000` |
| `inqry_end_dt` | ✅ | 조회 종료일시 (YYYYMMDDHHMM) | `202503312359` |
| `page_no` | | 페이지 번호 (기본: 1) | `2` |
| `num_of_rows` | | 페이지당 건수 (기본: 10) | `20` |
| `inqry_div` | | 1: 공고일 기준, 2: 개찰일 기준 | `1` |
| `bid_ntce_nm` | | 공고명 검색어 | `도로포장` |
| `ntce_instt_nm` | | 공고기관 검색어 | `서울특별시` |
| `main_cnstty_nm` | | 주요공종 검색어 | `토공` |
| `cnstwk_site_rgn_nm` | | 공사현장 지역 검색어 | `경기` |

---

## 개발자용: 로컬 개발 & 배포

### 로컬 테스트

```bash
# uv 설치 (없는 경우)
curl -LsSf https://astral.sh/uv/install.sh | sh

# 의존성 설치 및 실행
uv sync
uv run narajangteo-mcp
```

### PyPI 배포

```bash
# 빌드
uv build

# 배포 (PyPI 계정 필요)
uv publish
```

배포 후 버전 올릴 때: `pyproject.toml` 의 `version` 수정 → `uv build` → `uv publish`

---

## 새 기능 추가 방법

| 단계 | 파일 | 작업 |
|:---:|---|---|
| 1 | `src/narajangteo_mcp/tools/새모듈.py` | `bid_notice.py` 구조 참고해서 `register(mcp)` 작성 |
| 2 | `src/narajangteo_mcp/config.py` | `BASE_URLS` 에 새 서비스 URL 등록 |
| 3 | `src/narajangteo_mcp/tools/__init__.py` | `from . import 새모듈` 추가 |
| 4 | `src/narajangteo_mcp/server.py` | `register_all()` 에 `새모듈.register(mcp)` 추가 |
