"""Tests for extracted slash command handlers and model manager."""

from __future__ import annotations

from unittest.mock import MagicMock

from natshell.commands import (
    handle_exeplan_command,
    handle_load,
    handle_save,
    handle_sessions,
    show_keys,
    show_model_info,
    show_profile_list,
)
from natshell.config import NatShellConfig, OllamaConfig, ProfileConfig, RemoteConfig
from natshell.inference.engine import EngineInfo
from natshell.model_manager import (
    find_local_model,
    format_model_info,
    format_model_list,
    get_remote_base_url,
    resolve_local_model_path,
)
from natshell.tools.limits import ToolLimits

# ─── ToolLimits ──────────────────────────────────────────────────────────────


class TestToolLimits:
    def test_defaults(self):
        lim = ToolLimits()
        assert lim.max_output_chars == 4000
        assert lim.read_file_lines == 200

    def test_custom_values(self):
        lim = ToolLimits(max_output_chars=16000, read_file_lines=1000)
        assert lim.max_output_chars == 16000
        assert lim.read_file_lines == 1000


# ─── get_remote_base_url ─────────────────────────────────────────────────────


class TestGetRemoteBaseUrl:
    def test_ollama_url_preferred(self):
        config = NatShellConfig(
            ollama=OllamaConfig(url="http://ollama:11434"),
            remote=RemoteConfig(url="http://remote:8080"),
        )
        info = EngineInfo(engine_type="remote", base_url="http://engine:9999")
        url = get_remote_base_url(config, info)
        assert "ollama" in url

    def test_remote_url_fallback(self):
        config = NatShellConfig(remote=RemoteConfig(url="http://remote:8080"))
        info = EngineInfo(engine_type="remote")
        url = get_remote_base_url(config, info)
        assert "remote" in url

    def test_none_when_empty(self):
        config = NatShellConfig()
        info = EngineInfo(engine_type="local")
        assert get_remote_base_url(config, info) is None


# ─── format_model_info ───────────────────────────────────────────────────────


class TestFormatModelInfo:
    def test_remote_engine_info(self):
        info = EngineInfo(
            engine_type="remote",
            model_name="qwen3:4b",
            base_url="http://localhost:11434/v1",
            n_ctx=8192,
        )
        config = NatShellConfig()
        result = format_model_info(info, config)
        assert "remote" in result
        assert "qwen3:4b" in result
        assert "8192" in result


# ─── format_model_list ───────────────────────────────────────────────────────


class TestFormatModelList:
    def test_marks_active_model(self):
        from natshell.inference.ollama import OllamaModel

        models = [
            OllamaModel(name="model-a", size_gb=2.5, parameter_size="4B"),
            OllamaModel(name="model-b", size_gb=7.0, parameter_size="8B"),
        ]
        result = format_model_list(models, "model-a")
        assert "active" in result
        assert "model-a" in result
        assert "model-b" in result


# ─── find_local_model ────────────────────────────────────────────────────────


class TestFindLocalModel:
    def test_find_by_name(self, tmp_path):
        model = tmp_path / "model.gguf"
        model.touch()
        assert find_local_model("model.gguf", [model]) == model

    def test_find_by_stem(self, tmp_path):
        model = tmp_path / "model.gguf"
        model.touch()
        assert find_local_model("model", [model]) == model

    def test_not_found(self, tmp_path):
        model = tmp_path / "model.gguf"
        model.touch()
        assert find_local_model("other", [model]) is None


# ─── resolve_local_model_path ────────────────────────────────────────────────


class TestResolveLocalModelPath:
    def test_auto_expands(self):
        config = NatShellConfig()
        path = resolve_local_model_path(config)
        assert "natshell" in path
        assert "models" in path

    def test_explicit_path(self):
        config = NatShellConfig()
        config.model.path = "/custom/model.gguf"
        assert resolve_local_model_path(config) == "/custom/model.gguf"


# ─── Extracted command functions ────────────────────────────────────────────


def _mock_conversation():
    """Create a mock conversation container that records mounted widgets."""
    conv = MagicMock()
    conv.mounted = []

    def _mount(widget):
        conv.mounted.append(widget)

    conv.mount = _mount
    return conv


def _mock_agent(**kwargs):
    """Create a mock agent with engine info."""
    agent = MagicMock()
    info = EngineInfo(
        engine_type=kwargs.get("engine_type", "local"),
        model_name=kwargs.get("model_name", "test-model"),
        n_ctx=kwargs.get("n_ctx", 4096),
    )
    agent.engine.engine_info.return_value = info
    agent.messages = kwargs.get("messages", [])
    return agent


class TestShowKeys:
    def test_shows_keyboard_shortcuts(self):
        conv = _mock_conversation()
        show_keys(conv)
        assert len(conv.mounted) == 1
        text = conv.mounted[0]._raw_text
        assert "Ctrl+C" in text
        assert "Ctrl+E" in text


class TestHandleSave:
    def test_saves_session(self):
        conv = _mock_conversation()
        agent = _mock_agent()
        session_mgr = MagicMock()
        session_mgr.save.return_value = "a" * 32
        handle_save(agent, session_mgr, "my-session", conv)
        session_mgr.save.assert_called_once()
        assert len(conv.mounted) == 1


class TestHandleLoad:
    def test_loads_session(self):
        conv = _mock_conversation()
        agent = _mock_agent()
        session_mgr = MagicMock()
        session_mgr.load.return_value = {
            "messages": [{"role": "user", "content": "hi"}],
            "name": "test",
        }
        handle_load(agent, session_mgr, "a" * 32, conv)
        assert len(agent.messages) == 1
        assert len(conv.mounted) == 1

    def test_not_found(self):
        conv = _mock_conversation()
        agent = _mock_agent()
        session_mgr = MagicMock()
        session_mgr.load.return_value = None
        handle_load(agent, session_mgr, "missing", conv)
        assert len(conv.mounted) == 1
        text = conv.mounted[0]._raw_text
        assert "not found" in text.lower()

    def test_no_id_lists_sessions(self):
        conv = _mock_conversation()
        agent = _mock_agent()
        session_mgr = MagicMock()
        session_mgr.list_sessions.return_value = []
        handle_load(agent, session_mgr, "", conv)
        session_mgr.list_sessions.assert_called_once()


class TestHandleSessions:
    def test_empty_sessions(self):
        conv = _mock_conversation()
        session_mgr = MagicMock()
        session_mgr.list_sessions.return_value = []
        handle_sessions(session_mgr, conv)
        assert len(conv.mounted) == 1
        text = conv.mounted[0]._raw_text
        assert "no saved" in text.lower()

    def test_lists_sessions(self):
        conv = _mock_conversation()
        session_mgr = MagicMock()
        session_mgr.list_sessions.return_value = [
            {
                "id": "a" * 32,
                "name": "test-session",
                "message_count": 5,
                "updated": "2026-01-01T00:00:00",
            },
        ]
        handle_sessions(session_mgr, conv)
        assert len(conv.mounted) == 1
        text = conv.mounted[0]._raw_text
        assert "test-session" in text


class TestShowModelInfo:
    def test_shows_info(self):
        conv = _mock_conversation()
        agent = _mock_agent(model_name="qwen3:4b", n_ctx=8192)
        config = NatShellConfig()
        show_model_info(agent, config, conv)
        assert len(conv.mounted) == 1


class TestShowProfileList:
    def test_no_profiles(self):
        conv = _mock_conversation()
        config = NatShellConfig()
        show_profile_list(config, conv)
        assert len(conv.mounted) == 1
        text = conv.mounted[0]._raw_text
        assert "no profiles" in text.lower()

    def test_with_profiles(self):
        conv = _mock_conversation()
        config = NatShellConfig()
        config.profiles = {"fast": ProfileConfig(ollama_model="qwen3:4b")}
        show_profile_list(config, conv)
        assert len(conv.mounted) == 1
        text = conv.mounted[0]._raw_text
        assert "fast" in text


class TestHandleExeplanCommand:
    def test_no_args_shows_usage(self):
        conv = _mock_conversation()
        result = handle_exeplan_command("", conv)
        assert result is None
        assert len(conv.mounted) == 1
        text = conv.mounted[0]._raw_text
        assert "usage" in text.lower()

    def test_preview_file(self, tmp_path):
        plan_file = tmp_path / "PLAN.md"
        plan_file.write_text(
            "# Test Plan\n\n## Step 1: Do thing\n\nDo it.\n"
        )
        conv = _mock_conversation()
        result = handle_exeplan_command(str(plan_file), conv)
        assert result is None  # preview, not run
        assert len(conv.mounted) == 1

    def test_run_returns_plan(self, tmp_path):
        plan_file = tmp_path / "PLAN.md"
        plan_file.write_text(
            "# Test Plan\n\n## Step 1: Do thing\n\nDo it.\n"
        )
        conv = _mock_conversation()
        result = handle_exeplan_command(f"run {plan_file}", conv)
        assert result is not None
        assert result.title == "Test Plan"
        assert len(result.steps) == 1

    def test_file_not_found(self):
        conv = _mock_conversation()
        result = handle_exeplan_command("run /nonexistent/PLAN.md", conv)
        assert result is None
        assert len(conv.mounted) == 1
