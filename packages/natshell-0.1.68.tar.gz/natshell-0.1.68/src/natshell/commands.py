"""Standalone slash-command handlers extracted from app.py."""

from __future__ import annotations

from textual.containers import ScrollableContainer

from natshell.agent.loop import AgentLoop
from natshell.agent.plan import Plan, parse_plan_file
from natshell.config import NatShellConfig, list_profiles
from natshell.model_manager import (
    fetch_model_list,
    format_local_models,
    format_model_info,
    format_model_list,
    get_remote_base_url,
    set_default_model,
)
from natshell.session import SessionManager
from natshell.ui import clipboard
from natshell.ui.commands import MODELS_DIR
from natshell.ui.widgets import HelpMessage, SystemMessage, _escape


def show_help(conversation: ScrollableContainer) -> None:
    """Show available slash commands."""
    help_text = (
        "[bold]Available Commands[/]\n\n"
        "  [bold cyan]/help[/]                  Show this help message\n"
        "  [bold cyan]/clear[/]                 Clear chat and model context\n"
        "  [bold cyan]/compact[/]               Compact context, keeping key facts\n"
        "  [bold cyan]/cmd <command>[/]         Execute a shell command directly\n"
        "  [bold cyan]/exeplan <file>[/]        Preview a multi-step plan\n"
        "  [bold cyan]/exeplan run <file>[/]    Execute all plan steps\n"
        "  [bold cyan]/plan <description>[/]    Generate a multi-step plan\n"
        "  [bold cyan]/model[/]                 Show current engine/model info\n"
        "  [bold cyan]/model list[/]            List models on remote server\n"
        "  [bold cyan]/model use <name>[/]      Switch to a remote model\n"
        "  [bold cyan]/model switch[/]          Switch local model (or Ctrl+P)\n"
        "  [bold cyan]/model local[/]           Switch back to local model\n"
        "  [bold cyan]/model default <name>[/]  Save default remote model\n"
        "  [bold cyan]/model download[/]         Download a bundled model tier\n"
        "  [bold cyan]/profile[/]               List configuration profiles\n"
        "  [bold cyan]/profile <name>[/]        Apply a configuration profile\n"
        "  [bold cyan]/keys[/]                  Show keyboard shortcuts\n"
        "  [bold cyan]/history[/]               Show conversation context size\n"
        "  [bold cyan]/undo[/]                  Undo last file edit or write\n"
        "  [bold cyan]/save [name][/]           Save current session\n"
        "  [bold cyan]/load [id][/]             Load a saved session\n"
        "  [bold cyan]/sessions[/]              List saved sessions\n\n"
        "[bold]Copy & Paste[/]\n\n"
        "  Click [bold cyan]\U0001f4cb[/] on any message to copy it.\n"
        "  Click [bold cyan]\U0001f4cb Copy Chat[/] or press"
        " [bold cyan]Ctrl+E[/] to copy entire chat.\n"
        "  [bold cyan]Shift+drag[/] to select text, then use terminal copy.\n"
        "  [bold cyan]Right-click[/] or [bold cyan]Ctrl+Y[/] to copy Textual selection.\n"
        "  [bold cyan]Ctrl+Shift+V[/] or terminal paste to paste.\n"
        f"  Clipboard: [bold cyan]{clipboard.backend_name()}[/]\n\n"
        "[dim]Tip: Use /cmd when you know the exact command to run.[/]"
    )
    conversation.mount(HelpMessage(help_text))


def compact_chat(agent: AgentLoop, conversation: ScrollableContainer) -> None:
    """Compact conversation context, keeping key facts."""
    # Dry-run to preview what will happen
    preview = agent.compact_history(dry_run=True)
    if not preview["compacted"]:
        conversation.mount(SystemMessage("Nothing to compact — conversation is too short."))
        return

    # Actually compact
    stats = agent.compact_history()

    conversation.remove_children()
    saved_tokens = stats["before_tokens"] - stats["after_tokens"]
    dropped_msgs = stats["before_msgs"] - stats["after_msgs"]
    summary_lines = [
        "[bold]Context compacted[/]\n",
        f"  Messages: {stats['before_msgs']} \u2192 {stats['after_msgs']}"
        f" ({dropped_msgs} dropped)",
        f"  Tokens:   ~{stats['before_tokens']} \u2192 ~{stats['after_tokens']}"
        f" (~{saved_tokens} freed)",
    ]
    if stats["summary"]:
        summary_lines.append(f"\n[dim]Preserved facts:[/]\n{_escape(stats['summary'])}")
    conversation.mount(SystemMessage("\n".join(summary_lines)))


def show_history_info(agent: AgentLoop, conversation: ScrollableContainer) -> None:
    """Show conversation context size and context window usage."""
    msg_count = len(agent.messages)
    char_count = sum(len(str(m.get("content", ""))) for m in agent.messages)

    parts = [f"Conversation: {msg_count} messages, ~{char_count} chars"]

    cm = agent._context_manager
    if cm:
        used = cm.estimate_tokens(agent.messages)
        budget = cm.context_budget
        pct = min(100, int(used / budget * 100)) if budget > 0 else 0
        bar_len = 20
        filled = int(bar_len * pct / 100)
        bar = "\u2588" * filled + "\u2591" * (bar_len - filled)

        if pct >= 90:
            color = "red"
        elif pct >= 70:
            color = "yellow"
        else:
            color = "green"

        parts.append(f"  Context: [{color}]{bar}[/] {pct}% ({used}/{budget} tokens)")

        if cm.trimmed_count > 0:
            parts.append(f"  Trimmed: {cm.trimmed_count} messages compressed")

    conversation.mount(SystemMessage("\n".join(parts)))


def handle_undo(conversation: ScrollableContainer) -> None:
    """Undo the last file edit or write by restoring from backup."""
    from natshell.backup import get_backup_manager

    success, message = get_backup_manager().undo_last()
    conversation.mount(SystemMessage(message))


def show_keys(conversation: ScrollableContainer) -> None:
    """Show keyboard shortcuts."""
    keys_text = (
        "[bold]Keyboard Shortcuts[/]\n\n"
        "  [bold cyan]Enter[/]       Send message\n"
        "  [bold cyan]Up/Down[/]     Navigate input history\n"
        "  [bold cyan]Ctrl+C[/]      Quit\n"
        "  [bold cyan]Ctrl+E[/]      Copy entire chat\n"
        "  [bold cyan]Ctrl+L[/]      Clear chat\n"
        "  [bold cyan]Ctrl+P[/]      Command palette (model switcher)\n"
        "  [bold cyan]Ctrl+Y[/]      Copy selection"
    )
    conversation.mount(SystemMessage(keys_text))


def handle_save(
    agent: AgentLoop,
    session_mgr: SessionManager,
    args: str,
    conversation: ScrollableContainer,
) -> None:
    """Save current conversation to a session file."""
    name = args.strip()
    info = agent.engine.engine_info()
    engine_dict = {
        "engine_type": info.engine_type,
        "model_name": info.model_name,
        "base_url": info.base_url,
        "n_ctx": info.n_ctx,
    }
    sid = session_mgr.save(
        messages=agent.messages,
        engine_info=engine_dict,
        name=name,
    )
    display_name = name or sid[:12]
    conversation.mount(
        SystemMessage(f"Session saved: [bold]{_escape(display_name)}[/]\nID: {sid}")
    )


def handle_load(
    agent: AgentLoop,
    session_mgr: SessionManager,
    args: str,
    conversation: ScrollableContainer,
) -> None:
    """Load a saved session, or list sessions if no ID given."""
    session_id = args.strip()
    if not session_id:
        handle_sessions(session_mgr, conversation)
        return

    data = session_mgr.load(session_id)
    if data is None:
        conversation.mount(
            SystemMessage(f"Session not found: {_escape(session_id)}")
        )
        return

    agent.messages = data["messages"]
    name = data.get("name", session_id)
    msg_count = len(data["messages"])
    conversation.mount(
        SystemMessage(
            f"Loaded session: [bold]{_escape(name)}[/]\n"
            f"Messages restored: {msg_count}"
        )
    )


def handle_sessions(
    session_mgr: SessionManager,
    conversation: ScrollableContainer,
) -> None:
    """List all saved sessions."""
    sessions = session_mgr.list_sessions()
    if not sessions:
        conversation.mount(SystemMessage("No saved sessions."))
        return

    lines = ["[bold]Saved Sessions[/]\n"]
    for s in sessions:
        name = s["name"] or "(unnamed)"
        msg_count = s["message_count"]
        updated = s["updated"][:19].replace("T", " ")  # trim to readable
        lines.append(
            f"  [bold cyan]{s['id'][:12]}[/]  "
            f"{_escape(name)}  "
            f"[dim]({msg_count} msgs, {updated})[/]"
        )
    lines.append("\n[dim]Use /load <id> to restore a session.[/]")
    conversation.mount(SystemMessage("\n".join(lines)))


# ─── /model helpers ──────────────────────────────────────────────────────


def show_model_info(
    agent: AgentLoop,
    config: NatShellConfig,
    conversation: ScrollableContainer,
) -> None:
    """Show current model/engine information."""
    info = agent.engine.engine_info()
    text = format_model_info(info, config)
    conversation.mount(SystemMessage(text))


async def model_list(
    agent: AgentLoop,
    config: NatShellConfig,
    conversation: ScrollableContainer,
) -> None:
    """Ping server and list available models."""
    base_url = get_remote_base_url(config, agent.engine.engine_info())
    if not base_url:
        conversation.mount(
            SystemMessage(
                "No remote server configured.\n"
                "Set [ollama] url in ~/.config/natshell/config.toml\n"
                "or use --remote <url> at startup."
            )
        )
        return

    conversation.mount(SystemMessage(f"Checking {base_url}..."))

    reachable, models, error = await fetch_model_list(base_url)
    if not reachable or models is None:
        conversation.mount(SystemMessage(error or "Unknown error"))
        return

    current_info = agent.engine.engine_info()
    conversation.mount(
        SystemMessage(format_model_list(models, current_info.model_name))
    )


def model_set_default(
    agent: AgentLoop,
    config: NatShellConfig,
    model_name: str,
    conversation: ScrollableContainer,
) -> None:
    """Persist the default model and remote URL to user config."""
    info = agent.engine.engine_info()
    text = set_default_model(model_name, config, info)
    conversation.mount(SystemMessage(text))


def show_model_switch_list(
    agent: AgentLoop,
    conversation: ScrollableContainer,
) -> None:
    """List available local models for switching."""
    if not MODELS_DIR.is_dir():
        conversation.mount(
            SystemMessage(
                f"No models directory found at {MODELS_DIR}\n"
                "Run natshell --download to fetch a model."
            )
        )
        return

    available = sorted(MODELS_DIR.glob("*.gguf"))
    if not available:
        conversation.mount(
            SystemMessage("No .gguf models found. Run natshell --download to fetch one.")
        )
        return

    current = agent.engine.engine_info().model_name
    conversation.mount(
        SystemMessage(format_local_models(available, current))
    )


# ─── /profile helpers ───────────────────────────────────────────────────


def show_profile_list(
    config: NatShellConfig,
    conversation: ScrollableContainer,
) -> None:
    """List available configuration profiles."""
    names = list_profiles(config)
    if not names:
        conversation.mount(
            SystemMessage(
                "No profiles configured.\n"
                "Add [profiles.<name>] sections to "
                "~/.config/natshell/config.toml"
            )
        )
        return
    lines = ["[bold]Available Profiles[/]\n"]
    for n in names:
        p = config.profiles[n]
        parts: list[str] = []
        if p.ollama_model:
            parts.append(p.ollama_model)
        elif p.remote_model:
            parts.append(p.remote_model)
        if p.engine:
            parts.append(f"engine={p.engine}")
        if p.n_ctx:
            parts.append(f"n_ctx={p.n_ctx}")
        summary = ", ".join(parts) if parts else "(empty)"
        lines.append(f"  [bold cyan]{n}[/]  [dim]{summary}[/]")
    lines.append("\n[dim]Use /profile <name> to apply.[/]")
    conversation.mount(SystemMessage("\n".join(lines)))


# ─── /exeplan helpers ────────────────────────────────────────────────────


def handle_exeplan_command(
    args: str,
    conversation: ScrollableContainer,
) -> Plan | None:
    """Dispatch /exeplan subcommands.

    Returns a Plan object when ``run`` is requested (caller must execute it),
    or None if the command was fully handled (preview/error).
    """
    parts = args.strip().split(maxsplit=1)

    if not parts:
        conversation.mount(
            SystemMessage(
                "Usage: /exeplan <file>       \u2014 preview plan steps\n"
                "       /exeplan run <file>   \u2014 execute all steps\n"
                "       /exeplan show <file>  \u2014 same as bare /exeplan"
            )
        )
        return None

    subcmd = parts[0].lower()

    if subcmd == "run":
        file_path = parts[1].strip() if len(parts) > 1 else ""
        if not file_path:
            conversation.mount(SystemMessage("Usage: /exeplan run <file>"))
            return None
        try:
            return parse_plan_file(file_path)
        except FileNotFoundError as e:
            conversation.mount(SystemMessage(f"[red]{e}[/]"))
            return None
        except ValueError as e:
            conversation.mount(SystemMessage(f"[red]Parse error: {e}[/]"))
            return None

    if subcmd == "show":
        file_path = parts[1].strip() if len(parts) > 1 else ""
        if not file_path:
            conversation.mount(SystemMessage("Usage: /exeplan show <file>"))
            return None
        show_plan_preview(file_path, conversation)
        return None

    # Bare /exeplan <file> — treat as show
    file_path = args.strip()
    show_plan_preview(file_path, conversation)
    return None


def show_plan_preview(
    file_path: str,
    conversation: ScrollableContainer,
) -> None:
    """Parse and display a plan preview (dry-run)."""
    try:
        plan = parse_plan_file(file_path)
    except FileNotFoundError as e:
        conversation.mount(SystemMessage(f"[red]{e}[/]"))
        return
    except ValueError as e:
        conversation.mount(SystemMessage(f"[red]Parse error: {e}[/]"))
        return

    from natshell.ui.widgets import PlanOverviewMessage

    conversation.mount(PlanOverviewMessage(plan.title, [s.title for s in plan.steps]))
