"""Headless (non-interactive) mode — single-shot CLI execution.

Usage: natshell --headless "scan my network" | grep host

RESPONSE text goes to stdout (pipeable), everything else to stderr.
"""

from __future__ import annotations

import re
import sys
import time
from pathlib import Path
from typing import Any

from natshell.agent.loop import AgentLoop, EventType


async def run_headless(
    agent: AgentLoop,
    prompt: str,
    auto_approve: bool = False,
) -> int:
    """Run a single prompt through the agent, printing results to stdout/stderr.

    Args:
        agent: Initialized AgentLoop instance.
        prompt: The user's natural language request.
        auto_approve: If True, auto-approve all confirmation prompts.
                      If False, auto-decline (safer default).

    Returns:
        Exit code (0 = success, 1 = error).
    """

    async def _confirm_callback(tool_call: Any) -> bool:
        if auto_approve:
            _err(f"[auto-approved] {tool_call.name}: {tool_call.arguments}")
            return True
        _err(f"[declined — use --danger-fast to auto-approve] {tool_call.name}")
        return False

    had_error = False

    async for event in agent.handle_user_message(
        prompt,
        confirm_callback=_confirm_callback,
    ):
        match event.type:
            case EventType.RESPONSE:
                # Final text → stdout (pipeable)
                print(event.data, flush=True)

            case EventType.TOOL_RESULT:
                # Tool output → stderr for debugging
                if event.tool_result and event.tool_result.output:
                    _err(event.tool_result.output)
                if event.tool_result and event.tool_result.error:
                    _err(f"[stderr] {event.tool_result.error}")

            case EventType.PLANNING:
                _err(f"[thinking] {event.data}")

            case EventType.EXECUTING:
                if event.tool_call:
                    _err(f"[executing] {event.tool_call.name}")

            case EventType.BLOCKED:
                if event.tool_call:
                    _err(f"[BLOCKED] {event.tool_call.name}: {event.tool_call.arguments}")

            case EventType.ERROR:
                _err(f"[error] {event.data}")
                had_error = True

            case EventType.CONFIRM_NEEDED:
                pass  # Handled by _confirm_callback

            case EventType.QUEUED_MESSAGE:
                pass  # Headless is single-shot; queuing doesn't apply

            case EventType.RUN_STATS:
                if event.metrics:
                    steps = event.metrics.get("steps", "?")
                    wall = event.metrics.get("total_wall_ms", 0)
                    _err(f"[stats] {steps} steps in {wall}ms")

    if had_error:
        return 1
    return 0


def _err(msg: str) -> None:
    """Print a message to stderr."""
    print(msg, file=sys.stderr, flush=True)


_SUMMARY_RE = re.compile(r"^SUMMARY:\s*(.+)$", re.MULTILINE)


async def run_headless_plan(
    agent: AgentLoop,
    description: str,
    auto_approve: bool = False,
) -> int:
    """Generate a PLAN.md from a description in headless mode.

    Returns:
        Exit code (0 = PLAN.md created, 1 = error).
    """
    from natshell.agent.plan_executor import _build_plan_prompt, _shallow_tree
    from natshell.tools.registry import PLAN_SAFE_TOOLS

    async def _confirm_callback(tool_call: Any) -> bool:
        if auto_approve:
            _err(f"[auto-approved] {tool_call.name}: {tool_call.arguments}")
            return True
        _err(f"[declined — use --danger-fast to auto-approve] {tool_call.name}")
        return False

    try:
        n_ctx = agent.engine.engine_info().n_ctx or 4096
    except (AttributeError, TypeError):
        n_ctx = 4096

    agent.clear_history()
    tree = _shallow_tree(Path.cwd())
    prompt = _build_plan_prompt(description, tree, n_ctx=n_ctx)

    _err(f"[plan] Generating plan for: {description}")
    had_error = False

    async for event in agent.handle_user_message(
        prompt,
        confirm_callback=_confirm_callback,
        tool_filter=PLAN_SAFE_TOOLS,
        skip_intent_detection=True,
    ):
        match event.type:
            case EventType.RESPONSE:
                print(event.data, flush=True)
            case EventType.TOOL_RESULT:
                if event.tool_result and event.tool_result.output:
                    _err(event.tool_result.output)
                if event.tool_result and event.tool_result.error:
                    _err(f"[stderr] {event.tool_result.error}")
            case EventType.PLANNING:
                _err(f"[thinking] {event.data}")
            case EventType.EXECUTING:
                if event.tool_call:
                    _err(f"[executing] {event.tool_call.name}")
            case EventType.ERROR:
                _err(f"[error] {event.data}")
                had_error = True
            case EventType.RUN_STATS:
                if event.metrics:
                    steps = event.metrics.get("steps", "?")
                    wall = event.metrics.get("total_wall_ms", 0)
                    _err(f"[stats] {steps} steps in {wall}ms")

    if had_error:
        return 1

    plan_path = Path.cwd() / "PLAN.md"
    if plan_path.exists():
        _err(f"[plan] Written to {plan_path}")
        return 0

    _err("[plan] PLAN.md was not created")
    return 1


async def run_headless_exeplan(
    agent: AgentLoop,
    plan_file: str,
    auto_approve: bool = False,
) -> int:
    """Execute a plan file step-by-step in headless mode.

    Returns:
        Exit code (0 = all steps passed, 1 = any failure).
    """
    from natshell.agent.plan import parse_plan_file
    from natshell.agent.plan_executor import (
        _annotate_file,
        _build_step_prompt,
        _effective_plan_max_steps,
    )
    from natshell.tools.execute_shell import execute_shell

    async def _confirm_callback(tool_call: Any) -> bool:
        if auto_approve:
            _err(f"[auto-approved] {tool_call.name}: {tool_call.arguments}")
            return True
        _err(f"[declined — use --danger-fast to auto-approve] {tool_call.name}")
        return False

    confirm_cb = _confirm_callback if not auto_approve else _confirm_callback

    try:
        plan = parse_plan_file(plan_file)
    except FileNotFoundError as e:
        _err(f"[error] {e}")
        return 1
    except ValueError as e:
        _err(f"[error] Parse error: {e}")
        return 1

    try:
        n_ctx = agent.engine.engine_info().n_ctx or 4096
    except (AttributeError, TypeError):
        n_ctx = 4096

    _err(f"[exeplan] Executing: {plan.title} ({len(plan.steps)} steps)")
    plan_t0 = time.monotonic()

    completed_summaries: list[str] = []
    completed_files: list[str] = []
    completed_count = 0
    failed_count = 0

    for step in plan.steps:
        _err(f"\n[step {step.number}/{len(plan.steps)}] {step.title}")

        agent.clear_history()
        plan_max = _effective_plan_max_steps(n_ctx, agent.config.plan_max_steps)
        original_max = agent.config.max_steps
        agent.config.max_steps = plan_max
        effective_max = max(getattr(agent, "_max_steps", plan_max), plan_max)

        prompt = _build_step_prompt(
            step,
            plan,
            completed_summaries,
            max_steps=effective_max,
            completed_files=completed_files or None,
            n_ctx=n_ctx,
        )

        hit_max_steps = False
        step_files: list[str] = []
        step_response_text: str = ""

        try:
            async for event in agent.handle_user_message(
                prompt,
                confirm_callback=confirm_cb,
            ):
                match event.type:
                    case EventType.RESPONSE:
                        if event.data:
                            step_response_text = event.data
                            if "maximum number of steps" in event.data:
                                hit_max_steps = True
                    case EventType.TOOL_RESULT:
                        if event.tool_result and event.tool_result.output:
                            _err(event.tool_result.output)
                        if event.tool_result and event.tool_result.error:
                            _err(f"[stderr] {event.tool_result.error}")
                        # Track file changes
                        if (
                            event.tool_call
                            and event.tool_call.name in ("write_file", "edit_file")
                            and event.tool_result
                            and event.tool_result.exit_code == 0
                        ):
                            path = event.tool_call.arguments.get("path", "")
                            if path:
                                if event.tool_call.name == "write_file":
                                    content = event.tool_call.arguments.get("content", "")
                                    annotation = _annotate_file(path, content)
                                    entry = f"{path} (created in step {step.number})"
                                    if annotation:
                                        entry += f" [{annotation}]"
                                    step_files.append(entry)
                                else:
                                    step_files.append(
                                        f"{path} (modified in step {step.number})"
                                    )
                    case EventType.EXECUTING:
                        if event.tool_call:
                            _err(f"[executing] {event.tool_call.name}")
                    case EventType.PLANNING:
                        _err(f"[thinking] {event.data}")
                    case EventType.ERROR:
                        _err(f"[error] {event.data}")
                    case EventType.RUN_STATS:
                        if event.metrics:
                            steps = event.metrics.get("steps", "?")
                            wall = event.metrics.get("total_wall_ms", 0)
                            _err(f"[stats] {steps} steps in {wall}ms")

        except Exception as e:
            _err(f"[step {step.number}] ERROR: {e}")
            failed_count += 1
            completed_summaries.append(f"{step.number}. {step.title} \u2717")
            agent.config.max_steps = original_max
            continue

        finally:
            agent.config.max_steps = original_max

        completed_files.extend(step_files)

        # Extract summary
        step_summary = ""
        if step_response_text and not hit_max_steps:
            _m = _SUMMARY_RE.search(step_response_text)
            if _m:
                step_summary = _m.group(1).strip()
            else:
                step_summary = step_response_text[:300].replace("\n", " ").strip()

        # Run verification if present
        verify_failed = False
        if step.verification and not hit_max_steps:
            verify_cmd = step.verification
            _err(f"[verify] {verify_cmd}")
            verify_result = await execute_shell(verify_cmd)
            _err(
                f"[verify] exit={verify_result.exit_code}"
                + (f" {verify_result.output}" if verify_result.output else "")
            )
            if verify_result.exit_code != 0:
                verify_failed = True
                _err(f"[verify] FAILED: {verify_result.error or verify_result.output}")

        if verify_failed:
            failed_count += 1
            summary = f"{step.number}. {step.title} \u2717 (verify failed)"
            if step_summary:
                summary += f" \u2014 {step_summary}"
            completed_summaries.append(summary)
            _err(f"[step {step.number}] FAILED")
        elif hit_max_steps:
            failed_count += 1
            summary = f"{step.number}. {step.title} \u26a0 (partial)"
            if step_summary:
                summary += f" \u2014 {step_summary}"
            completed_summaries.append(summary)
            _err(f"[step {step.number}] PARTIAL (hit max steps)")
        else:
            completed_count += 1
            summary = f"{step.number}. {step.title} \u2713"
            if step_summary:
                summary += f" \u2014 {step_summary}"
            completed_summaries.append(summary)
            _err(f"[step {step.number}] OK")

    wall_s = time.monotonic() - plan_t0
    print(
        f"Plan complete: {completed_count} passed, {failed_count} failed, "
        f"{len(plan.steps) - completed_count - failed_count} skipped "
        f"({wall_s:.1f}s)",
        flush=True,
    )

    return 0 if failed_count == 0 else 1
