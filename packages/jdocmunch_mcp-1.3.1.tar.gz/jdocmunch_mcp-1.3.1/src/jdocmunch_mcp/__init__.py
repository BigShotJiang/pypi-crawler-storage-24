"""jDocMunch MCP — structured documentation retrieval server."""

__version__ = "1.3.0"
