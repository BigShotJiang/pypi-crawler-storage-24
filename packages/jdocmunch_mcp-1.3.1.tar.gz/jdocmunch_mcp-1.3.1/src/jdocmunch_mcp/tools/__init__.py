"""Tools module for jDocMunch."""
