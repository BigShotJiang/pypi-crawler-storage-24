"""Extraction client — PDF creation and document data extraction.

Covers all /squid-api/v1/extraction/* endpoints from the OpenAPI spec.
"""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any, Optional

from squidcloud.types import CreatePdfOutputOptions, ExtractDataFromDocumentOptions

if TYPE_CHECKING:
    from squidcloud.http import HttpTransport


class ExtractionClient:
    """Document extraction and PDF creation."""

    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    async def create_pdf_from_html(
        self,
        inner_html: str,
        *,
        title: Optional[str] = None,
        css_url: Optional[str] = None,
        output_options: Optional[CreatePdfOutputOptions] = None,
    ) -> dict:
        """Create a PDF from HTML content.

        Returns CreatePdfResponse with 'url' and 'fileName'.
        """
        body: dict[str, Any] = {"type": "html", "innerHtml": inner_html}
        if title is not None:
            body["title"] = title
        if css_url is not None:
            body["cssUrl"] = css_url
        if output_options is not None:
            body["outputOptions"] = output_options
        return await self._http.post("squid-api/v1/extraction/createPdf", body)

    async def create_pdf_from_url(
        self,
        url: str,
        *,
        title: Optional[str] = None,
        output_options: Optional[CreatePdfOutputOptions] = None,
    ) -> dict:
        """Create a PDF from a URL.

        Returns CreatePdfResponse with 'url' and 'fileName'.
        """
        body: dict[str, Any] = {"type": "url", "url": url}
        if title is not None:
            body["title"] = title
        if output_options is not None:
            body["outputOptions"] = output_options
        return await self._http.post("squid-api/v1/extraction/createPdf", body)

    async def extract_data_from_document_url(
        self,
        url: str,
        options: Optional[ExtractDataFromDocumentOptions] = None,
    ) -> dict:
        """Extract structured data from a document URL.

        Returns ExtractDataFromDocumentResponse with 'pages' and optional 'longTermStoragePath'.
        """
        body: dict[str, Any] = {"url": url}
        if options is not None:
            body["options"] = options
        return await self._http.post(
            "squid-api/v1/extraction/extractDataFromDocumentUrl", body
        )

    async def extract_data_from_document_file(
        self,
        file_data: bytes,
        filename: str,
        content_type: str = "application/pdf",
        options: Optional[ExtractDataFromDocumentOptions] = None,
    ) -> dict:
        """Extract structured data from a document file.

        Returns ExtractDataFromDocumentResponse with 'pages' and optional 'longTermStoragePath'.
        """
        form_data: dict[str, str] = {}
        if options is not None:
            form_data["optionsJson"] = json.dumps(options)

        return await self._http.post_form(
            "squid-api/v1/extraction/extractDataFromDocumentFile",
            data=form_data,
            files=[("file", (filename, file_data, content_type))],
        )
