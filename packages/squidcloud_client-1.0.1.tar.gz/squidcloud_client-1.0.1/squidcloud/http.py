"""Low-level HTTP transport layer.

Mirrors the TypeScript RpcManager — handles URL building, authentication,
request/response serialization, and error handling.
"""

from __future__ import annotations

import uuid
from typing import Any, Optional

import httpx

# Controllers that live on the Kotlin port (8001) in local dev.
_KOTLIN_CONTROLLERS = frozenset([
    "aiData", "api", "application", "application-kotlin", "auth",
    "backend-function", "integration", "internal-storage",
    "internalCodeExecutor", "management-secret", "mutation",
    "native-query", "notification", "observability", "query", "queue",
    "quota", "scheduler", "secret", "storage", "ws", "internal-extraction",
])


def _is_local(region: str) -> bool:
    return region.startswith("local")


def build_url(region: str, app_id: str, path: str) -> str:
    """Build the platform URL for an API call.

    Mirrors ``getApplicationUrl()`` from ``internal-common/src/utils/http.ts``.

    Args:
        region: The deployment region (e.g., ``'us-east-1.aws'``, ``'local'``).
        app_id: The full application ID (may include environment/developer suffix).
        path: The API path (e.g., ``'squid-api/v1/ai/agent/ask'``).

    Returns:
        The full URL string.

    URL patterns:
        - Cloud: ``https://{appId}.{region}.squid.cloud/{path}``
        - Local: ``http://localhost:{port}/{path}``
            - Port 8001 for Kotlin controllers (query, mutation, storage, etc.)
            - Port 8000 for TypeScript controllers (webhooks, OpenAPI, etc.)
    """
    base_domain = "squid.cloud"
    clean_path = path.lstrip("/")
    first_segment = clean_path.split("/")[0] if clean_path else ""

    if _is_local(region):
        port = "8001" if first_segment in _KOTLIN_CONTROLLERS else "8000"
        origin = f"http://localhost:{port}"
    else:
        host = f"{app_id}.{region}.{base_domain}"
        origin = f"https://{host}"

    return f"{origin}/{clean_path}" if clean_path else origin


class SquidHttpError(Exception):
    """Raised when the Squid API returns an HTTP error response (status >= 400).

    Attributes:
        status_code: The HTTP status code.
        url: The URL that was requested.
        body: The parsed response body, if available.
    """

    def __init__(self, status_code: int, message: str, url: str, body: Any = None):
        self.status_code = status_code
        self.url = url
        self.body = body
        super().__init__(f"HTTP {status_code}: {message} (url={url})")


class HttpTransport:
    """Low-level HTTP client wrapping httpx.

    Handles authentication headers, request tracing, JSON serialization,
    multipart form uploads, and error handling. Used internally by all
    sub-clients — not intended for direct use.

    Args:
        app_id: The full application ID.
        region: The deployment region.
        api_key: Optional API key for ``Authorization: ApiKey ...`` header.
    """

    def __init__(
        self,
        app_id: str,
        region: str,
        api_key: Optional[str] = None,
    ) -> None:
        self._app_id = app_id
        self._region = region
        self._api_key = api_key
        self._client_id = str(uuid.uuid4())
        self._client: Optional[httpx.AsyncClient] = None

    @property
    def client_id(self) -> str:
        """The unique client instance ID (UUID), sent as ``x-squid-clientid`` header."""
        return self._client_id

    def _get_client(self) -> httpx.AsyncClient:
        """Get or create the httpx async client with default headers."""
        if self._client is None or self._client.is_closed:
            headers: dict[str, str] = {
                "x-squid-clientid": self._client_id,
                "Content-Type": "application/json",
            }
            if self._api_key:
                headers["Authorization"] = f"ApiKey {self._api_key}"

            self._client = httpx.AsyncClient(
                headers=headers,
                timeout=httpx.Timeout(60.0, connect=10.0),
            )
        return self._client

    def _url(self, path: str) -> str:
        """Build the full URL for a given API path."""
        return build_url(self._region, self._app_id, path)

    async def post(
        self,
        path: str,
        body: Any = None,
        *,
        extra_headers: Optional[dict[str, str]] = None,
    ) -> Any:
        """Send a POST request with a JSON body.

        Args:
            path: The API path (e.g., ``'squid-api/v1/ai/agent/ask'``).
            body: The request body (will be serialized to JSON).
            extra_headers: Additional HTTP headers to include.

        Returns:
            The parsed JSON response body, or ``None`` for 204 responses.

        Raises:
            SquidHttpError: If the response status is >= 400.
        """
        url = self._url(path)
        headers = {"x-squid-traceid": str(uuid.uuid4())}
        if extra_headers:
            headers.update(extra_headers)
        client = self._get_client()
        resp = await client.post(url, json=body, headers=headers)
        return self._handle_response(resp, url)

    async def get(
        self,
        path: str,
        params: Optional[dict[str, str]] = None,
    ) -> Any:
        """Send a GET request.

        Args:
            path: The API path.
            params: Optional query parameters.

        Returns:
            The parsed JSON response body, or ``None`` for 204 responses.

        Raises:
            SquidHttpError: If the response status is >= 400.
        """
        url = self._url(path)
        headers = {"x-squid-traceid": str(uuid.uuid4())}
        client = self._get_client()
        resp = await client.get(url, params=params, headers=headers)
        return self._handle_response(resp, url)

    async def post_form(
        self,
        path: str,
        data: dict[str, str],
        files: list[tuple[str, tuple[str, bytes, str]]],
    ) -> Any:
        """Send a POST request with multipart form data.

        Used for file uploads (e.g., audio transcription, image processing,
        knowledge base file contexts).

        Args:
            path: The API path.
            data: Form data fields as string key-value pairs.
            files: File fields as a list of
                ``(field_name, (filename, data_bytes, content_type))`` tuples.

        Returns:
            The parsed JSON response body, or ``None`` for 204 responses.

        Raises:
            SquidHttpError: If the response status is >= 400.
        """
        url = self._url(path)
        headers = {"x-squid-traceid": str(uuid.uuid4())}
        client = self._get_client()
        resp = await client.post(url, data=data, files=files, headers=headers)
        return self._handle_response(resp, url)

    def _handle_response(self, resp: httpx.Response, url: str) -> Any:
        """Parse the response, raising SquidHttpError on error status codes."""
        if resp.status_code >= 400:
            body = None
            try:
                body = resp.json()
            except Exception:
                pass
            message = ""
            if isinstance(body, dict):
                message = body.get("message", body.get("error", resp.reason_phrase))
            else:
                message = resp.reason_phrase or str(resp.status_code)
            raise SquidHttpError(resp.status_code, message, url, body)

        if resp.status_code == 204 or not resp.content:
            return None
        return resp.json()

    async def close(self) -> None:
        """Close the underlying httpx client and release connections."""
        if self._client and not self._client.is_closed:
            await self._client.aclose()
