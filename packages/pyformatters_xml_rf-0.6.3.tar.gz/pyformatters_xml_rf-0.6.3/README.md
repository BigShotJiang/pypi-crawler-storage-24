## Requirements

- Python 3.12+
- uv for package management
- Pydantic for the data parts.

## Installation
```
pip install uv
uv sync
```

## Running tests
```
uv run pytest
```

## Linting
```
uv run ruff check .
uv run ruff format --check .
```

## Publish the Python Package to PyPI
```
uv build
uv publish
```
