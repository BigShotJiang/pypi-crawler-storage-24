"""Integration tests init."""
