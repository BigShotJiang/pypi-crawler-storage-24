# 🔐 p2private

<p align="center">
  <img src="https://img.shields.io/badge/Python-3.11%2B-blue?style=for-the-badge&logo=python" alt="Python 3.11+">
  <img src="https://img.shields.io/badge/Cython-0.29%2B-green?style=for-the-badge&logo=c" alt="Cython">
  <img src="https://img.shields.io/badge/License-MIT-yellow?style=for-the-badge" alt="License: MIT">
  <img src="https://img.shields.io/badge/PyPI-v1.0.3-orange?style=for-the-badge&logo=pypi" alt="PyPI">
</p>

<p align="center">
  <strong>Python to Private Executable Converter</strong><br>
  Encrypt your Python scripts to standalone executables using Cython
</p>

---

## 📋 Table of Contents

- [Features](#-features)
- [Installation](#-installation)
- [Quick Start](#-quick-start)
- [CLI Usage](#-cli-usage)
- [Python API](#-python-api)
- [Version Checker](#-version-checker)
- [Complete Setup Guide](#-complete-setup-guide)
- [Examples](#-examples)
- [Requirements](#-requirements)
- [Troubleshooting](#-troubleshooting)
- [License](#-license)

---

## ✨ Features

- 🔒 **Encrypt Python scripts** to C code using Cython
- 🚀 **Generate standalone executables** that compile on first run
- 🛡️ **Optional version checking** for Python compatibility
- 📁 **Custom output naming** and directory support
- 🧹 **Automatic cleanup** of temporary files
- 💻 **Cross-platform** support (Linux, macOS, Windows)
- 🎯 **Simple CLI** and Python API
- 🔧 **Auto-fixes mixed tabs/spaces** indentation issues
- ✅ **Python 3.11+ compatible** - no deprecated warnings

---

## 📦 Installation

### From PyPI (Recommended)

```bash
pip install p2private
```

### From Source

```bash
git clone https://github.com/pooraddy/p2private.git
cd p2private
pip install -e .
```

### Development Installation

```bash
git clone https://github.com/pooraddy/p2private.git
cd p2private
pip install -e ".[dev]"
```

---

## 🚀 Quick Start

### 1. Create a Python Script

```python
# hello.py
print("Hello, World!")
name = input("What's your name? ")
print(f"Nice to meet you, {name}!")
```

### 2. Encrypt It

```bash
p2private hello.py
```

### 3. Run the Encrypted File

```bash
python Enc_hello.py
```

---

## 💻 CLI Usage

### Basic Encryption

```bash
p2private script.py
```

### Custom Output Name

```bash
p2private script.py -o myapp
```

### Specify Output Directory

```bash
p2private script.py -d ./output
```

### Add Version Check

```bash
p2private script.py -v 3.11
```

### Full Example

```bash
p2private script.py -o myapp -d ./build -v 3.12
```

### CLI Options

| Option | Short | Description | Example |
|--------|-------|-------------|---------|
| `--output` | `-o` | Custom output filename | `-o myapp` |
| `--directory` | `-d` | Output directory | `-d ./build` |
| `--version-check` | `-v` | Python version requirement | `-v 3.11` |
| `--version` | - | Show version | `--version` |
| `--help` | `-h` | Show help | `--help` |

---

## 🐍 Python API

### Method 1: Using P2PrivateEncryptor Class

```python
from p2private import P2PrivateEncryptor

encryptor = P2PrivateEncryptor()
output_path = encryptor.encrypt('script.py')
print(f"Encrypted file: {output_path}")
```

### Method 2: With Version Check

```python
from p2private import P2PrivateEncryptor

encryptor = P2PrivateEncryptor(version_check='3.11')
output_path = encryptor.encrypt('script.py')
```

### Method 3: Custom Output

```python
from p2private import P2PrivateEncryptor

encryptor = P2PrivateEncryptor()
output_path = encryptor.encrypt(
    file_path='script.py',
    output_dir='./build',
    output_name='myapp.py'
)
```

### Method 4: Using encrypt_file Function

```python
from p2private import encrypt_file

encrypt_file('script.py')
```

### Method 5: encrypt_file with Options

```python
from p2private import encrypt_file

encrypt_file(
    file_path='script.py',
    output_dir='./build',
    output_name='myapp.py',
    version_check='3.12'
)
```

---

## 🛡️ Version Checker

When you use the `-v` or `--version-check` option, the encrypted file will include a version check at the beginning:

### CLI Usage

```bash
p2private script.py -v 3.11
```

### Python API Usage

```python
from p2private import encrypt_file

encrypt_file('script.py', version_check='3.11')
```

### Generated Code

This adds the following code to the encrypted output:

```python
PYTHON_VERSION = ".".join(sys.version.split(" ")[0].split(".")[:-1])
if PYTHON_VERSION != "3.11":
    print('[!] No support for 3.11')
    exit(0)
```

### Use Cases

- Ensure compatibility with specific Python versions
- Prevent running on unsupported Python versions
- Add version-specific behavior

---

## 🔧 Complete Setup Guide

### Local Installation

#### Step 1: Clone the Repository

```bash
git clone https://github.com/pooraddy/p2private.git
cd p2private
```

#### Step 2: Create Virtual Environment (Recommended)

```bash
python -m venv venv
```

Activate on Linux/macOS:
```bash
source venv/bin/activate
```

Activate on Windows:
```bash
venv\Scripts\activate
```

#### Step 3: Install Dependencies

```bash
pip install -r requirements.txt
```

#### Step 4: Install in Development Mode

```bash
pip install -e .
```

#### Step 5: Verify Installation

```bash
p2private --version
```

---

## 📝 Examples

### Example 1: Simple Script Encryption

**Original script (calculator.py):**

```python
def add(a, b):
    return a + b

def subtract(a, b):
    return a - b

if __name__ == "__main__":
    print("Simple Calculator")
    x = float(input("Enter first number: "))
    y = float(input("Enter second number: "))
    print(f"Sum: {add(x, y)}")
    print(f"Difference: {subtract(x, y)}")
```

**Encrypt:**

```bash
p2private calculator.py -o calc
```

**Run:**

```bash
python calc.py
```

---

### Example 2: With Version Check

```bash
p2private myapp.py -v 3.11 -o secure_app
```

---

### Example 3: Batch Encryption

```bash
for file in *.py; do
    p2private "$file" -d ./encrypted
done
```

---

### Example 4: Python API in Script

```python
#!/usr/bin/env python3
# batch_encrypt.py

import os
from p2private import P2PrivateEncryptor

encryptor = P2PrivateEncryptor(version_check='3.11')

scripts = ['app1.py', 'app2.py', 'app3.py']

for script in scripts:
    if os.path.exists(script):
        try:
            output = encryptor.encrypt(script, output_dir='./encrypted')
            print(f"✓ Encrypted: {script} -> {output}")
        except Exception as e:
            print(f"✗ Failed: {script} - {e}")
    else:
        print(f"✗ Not found: {script}")
```

---

### Example 5: Using encrypt_file Function

```python
from p2private import encrypt_file

# Encrypt single file
encrypt_file('script.py')

# Encrypt with options
encrypt_file(
    file_path='script.py',
    output_dir='./output',
    output_name='myapp',
    version_check='3.12'
)
```

---

## 📋 Requirements

### System Requirements

- Python 3.11 or higher
- GCC compiler (for compiling C code)
- Cython 0.29.0 or higher

### Install System Dependencies

**Ubuntu/Debian:**

```bash
sudo apt-get update
sudo apt-get install python3-dev gcc
```

**CentOS/RHEL/Fedora:**

```bash
sudo yum install python3-devel gcc
```

**macOS:**

```bash
xcode-select --install
```

**Windows:**

- Install [MinGW-w64](https://www.mingw-w64.org/) or [Visual Studio Build Tools](https://visualstudio.microsoft.com/downloads/)

### Python Dependencies

```
Cython>=0.29.0
autopep8>=1.6.0
```

---

## 🔍 Troubleshooting

### Common Issues

#### Issue: `gcc: command not found`

**Solution:** Install GCC compiler

```bash
# Ubuntu/Debian
sudo apt-get install gcc

# macOS
xcode-select --install
```

---

#### Issue: `Python.h: No such file or directory`

**Solution:** Install Python development headers

```bash
# Ubuntu/Debian
sudo apt-get install python3-dev

# CentOS/RHEL
sudo yum install python3-devel
```

---

#### Issue: `cythonize: command not found`

**Solution:** Install Cython

```bash
pip install Cython
```

---

#### Issue: `Permission denied` when running encrypted file

**Solution:** Make the file executable

```bash
chmod +x Enc_script.py
```

---

#### Issue: Compilation fails on Windows

**Solution:** Ensure you have Visual C++ Build Tools installed

```bash
# Or use MinGW
pip install --global-option=build_ext --global-option="-c mingw32" Cython
```

---

#### Issue: `Mixed use of tabs and spaces` Error

**Solution:** This is now automatically fixed by p2private! The tool automatically converts tabs to spaces before compilation.

---

#### Issue: Deprecated warnings (Py_SetProgramName, PySys_SetArgv)

**Solution:** Fixed in version 1.0.3! The code now uses conditional compilation to avoid deprecated functions on Python 3.11+.

---

### Debug Mode

To see detailed error messages:

```python
import traceback
traceback.print_exc()
```

---

## 📂 Project Structure

```
p2private/
├── p2private/              # Main package
│   ├── __init__.py         # Package initialization
│   ├── encryptor.py        # Core encryption logic
│   └── cli.py              # Command line interface
├── tests/                  # Test suite
│   ├── __init__.py
│   ├── test_encryptor.py
│   └── test_cli.py
├── .github/workflows/      # GitHub Actions
│   ├── publish.yml         # PyPI publishing
│   └── tests.yml           # Test runner
├── setup.py                # Package setup
├── pyproject.toml          # Modern Python packaging
├── requirements.txt        # Dependencies
├── LICENSE                 # MIT License
├── CHANGELOG.md            # Version history
├── MANIFEST.in             # Package manifest
├── .gitignore              # Git ignore rules
└── README.md               # This file
```

---

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

---

## 📜 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

---

## 🙏 Acknowledgments

- [Cython](https://cython.org/) - C-Extensions for Python
- [autopep8](https://github.com/hhatto/autopep8) - Automatic Python code formatter

---

## 📧 Contact

- **Author:** addy
- **Email:** poor4ddy@gmail.com
- **GitHub:** [@pooraddy](https://github.com/pooraddy)
- **PyPI:** [p2private](https://pypi.org/project/p2private/)

---

<p align="center">
  Made with ❤️ using Python & Cython
</p>
