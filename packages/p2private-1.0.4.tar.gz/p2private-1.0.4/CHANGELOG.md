# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.3] - 2024-01-01

### Fixed
- Fixed deprecated Python C API warnings (Py_SetProgramName, PySys_SetArgv) for Python 3.11+
- Fixed zlib error by removing comments from C source properly
- Removed all comments from encrypted output files

### Changed
- Updated C main code to use conditional compilation for deprecated functions
- Improved comment removal in generated C code

## [1.0.2] - 2024-01-01

### Added
- Fixed mixed tabs and spaces indentation issue
- Added `_fix_indentation()` method to handle tab-to-spaces conversion
- Added `encrypt_file` to package exports

### Changed
- Updated Python version requirement to >=3.11
- Updated author information

## [1.0.0] - 2024-01-01

### Added
- Initial release of p2private
- Python to C compilation using Cython
- Standalone executable generation
- Version checker option for encrypted files
- CLI interface with argparse
- Support for Python 3.11 - 3.13
- Cross-platform support (Linux, macOS, Windows)

### Features
- Encrypt Python scripts to standalone executables
- Optional Python version checking
- Custom output naming
- Directory output support
- Automatic cleanup of temporary files
