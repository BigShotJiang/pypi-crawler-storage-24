"""
Tests for p2private CLI module
"""

import os
import sys
import tempfile
import unittest
from unittest.mock import patch, MagicMock
from io import StringIO

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from p2private.cli import create_parser, main


class TestCLIParser(unittest.TestCase):
    """Test cases for CLI argument parser."""
    
    def test_create_parser(self):
        """Test parser creation."""
        parser = create_parser()
        self.assertIsNotNone(parser)
    
    def test_parser_file_argument(self):
        """Test file argument parsing."""
        parser = create_parser()
        args = parser.parse_args(['script.py'])
        self.assertEqual(args.file, 'script.py')
    
    def test_parser_output_argument(self):
        """Test output argument parsing."""
        parser = create_parser()
        args = parser.parse_args(['script.py', '-o', 'output'])
        self.assertEqual(args.output, 'output')
        
        args = parser.parse_args(['script.py', '--output', 'output2'])
        self.assertEqual(args.output, 'output2')
    
    def test_parser_directory_argument(self):
        """Test directory argument parsing."""
        parser = create_parser()
        args = parser.parse_args(['script.py', '-d', './output'])
        self.assertEqual(args.directory, './output')
        
        args = parser.parse_args(['script.py', '--directory', './output2'])
        self.assertEqual(args.directory, './output2')
    
    def test_parser_version_check_argument(self):
        """Test version check argument parsing."""
        parser = create_parser()
        args = parser.parse_args(['script.py', '-v', '3.10'])
        self.assertEqual(args.version_check, '3.10')
        
        args = parser.parse_args(['script.py', '--version-check', '3.9'])
        self.assertEqual(args.version_check, '3.9')


class TestCLIMain(unittest.TestCase):
    """Test cases for CLI main function."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.temp_dir = tempfile.mkdtemp()
        self.test_file = os.path.join(self.temp_dir, "test_script.py")
        with open(self.test_file, 'w') as f:
            f.write('print("Hello, World!")')
    
    def tearDown(self):
        """Clean up test fixtures."""
        import shutil
        if os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)
    
    @patch('sys.argv', ['p2private', 'nonexistent.py'])
    def test_main_file_not_found(self):
        """Test main with non-existent file."""
        with self.assertRaises(SystemExit) as cm:
            main()
        self.assertEqual(cm.exception.code, 1)
    
    @patch('sys.argv', ['p2private', '--version'])
    def test_main_version(self):
        """Test version flag."""
        with self.assertRaises(SystemExit) as cm:
            main()
        self.assertEqual(cm.exception.code, 0)


if __name__ == '__main__':
    unittest.main()
