"""
Tests for p2private encryptor module
"""

import os
import sys
import tempfile
import unittest
from unittest.mock import patch, MagicMock

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from p2private.encryptor import P2PrivateEncryptor, encrypt_file


class TestP2PrivateEncryptor(unittest.TestCase):
    """Test cases for P2PrivateEncryptor class."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.temp_dir = tempfile.mkdtemp()
        self.test_file = os.path.join(self.temp_dir, "test_script.py")
        with open(self.test_file, 'w') as f:
            f.write('print("Hello, World!")')
    
    def tearDown(self):
        """Clean up test fixtures."""
        import shutil
        if os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)
    
    def test_init(self):
        """Test encryptor initialization."""
        encryptor = P2PrivateEncryptor()
        self.assertIsNone(encryptor.version_check)
        
        encryptor_with_version = P2PrivateEncryptor(version_check="3.10")
        self.assertEqual(encryptor_with_version.version_check, "3.10")
    
    def test_generate_random_word(self):
        """Test random word generation."""
        encryptor = P2PrivateEncryptor()
        word = encryptor._generate_random_word(10)
        self.assertEqual(len(word), 10)
        self.assertTrue(word.isalpha())
        self.assertTrue(word.islower())
    
    def test_remove_comments(self):
        """Test C-style comment removal."""
        encryptor = P2PrivateEncryptor()
        content = "/* comment */ code /* another */"
        result = encryptor._remove_comments(content)
        self.assertEqual(result.strip(), "code")
    
    def test_get_version_checker_code(self):
        """Test version checker code generation."""
        encryptor = P2PrivateEncryptor(version_check="3.10")
        code = encryptor._get_version_checker_code()
        self.assertIn('PYTHON_VERSION', code)
        self.assertIn('3.10', code)
        
        # Test without version check
        encryptor_no_version = P2PrivateEncryptor()
        code = encryptor_no_version._get_version_checker_code()
        self.assertEqual(code, '')
    
    def test_encrypt_file_not_found(self):
        """Test encryption with non-existent file."""
        encryptor = P2PrivateEncryptor()
        with self.assertRaises(FileNotFoundError):
            encryptor.encrypt("/nonexistent/file.py")


class TestEncryptFileFunction(unittest.TestCase):
    """Test cases for encrypt_file convenience function."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.temp_dir = tempfile.mkdtemp()
        self.test_file = os.path.join(self.temp_dir, "test_script.py")
        with open(self.test_file, 'w') as f:
            f.write('print("Hello, World!")')
    
    def tearDown(self):
        """Clean up test fixtures."""
        import shutil
        if os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)
    
    def test_encrypt_file_not_found(self):
        """Test encrypt_file with non-existent file."""
        with self.assertRaises(FileNotFoundError):
            encrypt_file("/nonexistent/file.py")


if __name__ == '__main__':
    unittest.main()
