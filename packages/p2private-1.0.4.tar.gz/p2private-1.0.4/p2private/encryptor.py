"""
Main encryption module for p2private
"""

import os
import random
import string
import sys
import subprocess
import tempfile
import shutil
import re


class P2PrivateEncryptor:
    
    def __init__(self, version_check=None):
        self.version_check = version_check
        self.temp_dir = None
        
    def _generate_random_word(self, length=8):
        letters = string.ascii_lowercase
        return ''.join(random.choice(letters) for _ in range(length))
    
    def _remove_comments(self, content):
        output_content = ''
        in_comment = False
        i = 0
        while i < len(content):
            if content[i:i+2] == '/*':
                in_comment = True
                i += 2
                continue
            elif content[i:i+2] == '*/':
                in_comment = False
                i += 2
                continue
            if not in_comment:
                output_content += content[i]
            i += 1
        return output_content
    
    def _fix_indentation(self, content):
        lines = content.split('\n')
        fixed_lines = []
        
        for line in lines:
            leading = ''
            for char in line:
                if char == '\t':
                    leading += '    '
                elif char == ' ':
                    leading += ' '
                else:
                    break
            
            rest = line.lstrip()
            rest = rest.replace('\t', '    ')
            fixed_lines.append(leading + rest)
        
        return '\n'.join(fixed_lines)
    
    def _get_version_checker_code(self):
        if self.version_check:
            return f'''PYTHON_VERSION = ".".join(sys.version.split(" ")[0].split(".")[:-1])
if PYTHON_VERSION != "{self.version_check}":
    print('[!] No support for {self.version_check}')
    exit(0)
'''
        return ''
    
    def _get_c_main_code(self, module_name):
        return f'''
#ifdef __FreeBSD__
#include <dede.h>
#endif

#if PY_MAJOR_VERSION < 3
int main(int argc, char** argv) {{
#elif defined(Win32) || defined(MS_WINDOWS)
int wmain(int argc, wchar_t **argv) {{
#else
static int __Pyx_main(int argc, wchar_t **argv) {{
#endif
#ifdef __FreeBSD__
    fp_except_t m;
    m = fpgetmask();
    fpsetmask(m & ~FP_X_OFL);
#endif
#if PY_VERSION_HEX < 0x030B0000
    if (argc && argv)
        Py_SetProgramName(argv[0]);
#endif
    Py_Initialize();
#if PY_VERSION_HEX < 0x030B0000
    if (argc && argv)
        PySys_SetArgv(argc, argv);
#endif
    {{
      PyObject* m = NULL;
      __pyx_module_is_main_{module_name} = 1;
      #if PY_MAJOR_VERSION < 3
          init{module_name}();
      #elif CYTHON_PEP489_MULTI_PHASE_INIT
          m = PyInit_{module_name}();
          if (!PyModule_Check(m)) {{
              PyModuleDef *mdef = (PyModuleDef *) m;
              PyObject *modname = PyUnicode_FromString("__main__");
              m = NULL;
              if (modname) {{
                  m = PyModule_NewObject(modname);
                  Py_DECREF(modname);
                  if (m) PyModule_ExecDef(m, mdef);
              }}
          }}
      #else
          m = PyInit_{module_name}();
      #endif
      if (PyErr_Occurred()) {{
          PyErr_Print();
          #if PY_MAJOR_VERSION < 3
          if (Py_FlushLine()) PyErr_Clear();
          #endif
          return 1;
      }}
      Py_XDECREF(m);
    }}
#if PY_VERSION_HEX < 0x03060000
    Py_Finalize();
#else
    if (Py_FinalizeEx() < 0)
        return 2;
#endif
    return 0;
}}

#if PY_MAJOR_VERSION >= 3 && !defined(Win32) && !defined(MS_WINDOWS)
#include <locale.h>
static wchar_t*
__Pyx_char2wchar(char* arg)
{{
    wchar_t *res;
#ifdef HAVE_BROKEN_MBSTOWCS
    size_t argsize = strlen(arg);
#else
    size_t argsize = mbstowcs(NULL, arg, 0);
#endif
    size_t count;
    unsigned char *in;
    wchar_t *out;
#ifdef HAVE_MBRTOWC
    mbstate_t mbs;
#endif
    if (argsize != (size_t)-1) {{
        res = (wchar_t *)malloc((argsize+1)*sizeof(wchar_t));
        if (!res)
            goto oom;
        count = mbstowcs(res, arg, argsize+1);
        if (count != (size_t)-1) {{
            wchar_t *tmp;
            for (tmp = res; *tmp != 0 &&
                     (*tmp < 0xd800 || *tmp > 0xdfff); tmp++)
                ;
            if (*tmp == 0)
                return res;
        }}
        free(res);
    }}
#ifdef HAVE_MBRTOWC
    argsize = strlen(arg) + 1;
    res = (wchar_t *)malloc(argsize*sizeof(wchar_t));
    if (!res) goto oom;
    in = (unsigned char*)arg;
    out = res;
    memset(&mbs, 0, sizeof mbs);
    while (argsize) {{
        size_t converted = mbrtowc(out, (char*)in, argsize, &mbs);
        if (converted == 0)
            break;
        if (converted == (size_t)-2) {{
            fprintf(stderr, "unexpected mbrtowc result -2");
            free(res);
            return NULL;
        }}
        if (converted == (size_t)-1) {{
            *out++ = 0xdc00 + *in++;
            argsize--;
            memset(&mbs, 0, sizeof mbs);
            continue;
        }}
        if (*out >= 0xd800 && *out <= 0xdfff) {{
            argsize -= converted;
            while (converted--)
                *out++ = 0xdc00 + *in++;
            continue;
        }}
        in += converted;
        argsize -= converted;
        out++;
    }}
#else
    res = (wchar_t *)malloc((strlen(arg)+1)*sizeof(wchar_t));
    if (!res) goto oom;
    in = (unsigned char*)arg;
    out = res;
    while(*in)
        if(*in < 128)
            *out++ = *in++;
        else
            *out++ = 0xdc00 + *in++;
    *out = 0;
#endif
    return res;
oom:
    fprintf(stderr, "out of memory");
    return NULL;
}}
int
main(int argc, char **argv)
{{
    if (!argc) {{
        return __Pyx_main(0, NULL);
    }}
    else {{
        int i, res;
        wchar_t **argv_copy = (wchar_t **)malloc(sizeof(wchar_t*)*argc);
        wchar_t **argv_copy2 = (wchar_t **)malloc(sizeof(wchar_t*)*argc);
        char *oldloc = strdup(setlocale(LC_ALL, NULL));
        if (!argv_copy || !argv_copy2 || !oldloc) {{
            fprintf(stderr, "out of memory");
            free(argv_copy);
            free(argv_copy2);
            free(oldloc);
            return 1;
        }}
        res = 0;
        setlocale(LC_ALL, "");
        for (i = 0; i < argc; i++) {{
            argv_copy2[i] = argv_copy[i] = __Pyx_char2wchar(argv[i]);
            if (!argv_copy[i]) res = 1;
        }}
        setlocale(LC_ALL, oldloc);
        free(oldloc);
        if (res == 0)
            res = __Pyx_main(argc, argv_copy);
        for (i = 0; i < argc; i++) {{
#if PY_VERSION_HEX < 0x03050000
            free(argv_copy2[i]);
#else
            PyMem_RawFree(argv_copy2[i]);
#endif
        }}
        free(argv_copy);
        free(argv_copy2);
        return res;
    }}
}}
#endif
'''
    
    def encrypt(self, file_path, output_dir=None, output_name=None):
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")
        
        self.temp_dir = tempfile.mkdtemp(prefix="p2private_")
        work_dir = os.path.join(self.temp_dir, "work")
        os.makedirs(work_dir, exist_ok=True)
        
        try:
            name = os.path.basename(file_path)
            name_without_ext = name.replace(".py", "")
            
            with open(file_path, "r", encoding="utf-8") as f:
                content = f.read()
            
            content = self._fix_indentation(content)
            
            prefix_code = "import os\nos.system('clear')\n"
            version_checker = self._get_version_checker_code()
            
            full_content = prefix_code + version_checker + "\n" + content
            
            temp_py_file = os.path.join(work_dir, name)
            with open(temp_py_file, 'w', encoding="utf-8") as f:
                f.write(full_content)
            
            print("[*] Compiling with Cython...")
            result = subprocess.run(
                ["cythonize", temp_py_file],
                capture_output=True,
                text=True
            )
            
            if result.returncode != 0:
                raise RuntimeError(f"Cython compilation failed: {result.stderr}")
            
            c_file_path = os.path.join(work_dir, f"{name_without_ext}.c")
            if not os.path.exists(c_file_path):
                raise RuntimeError(f"C file not generated: {c_file_path}")
            
            with open(c_file_path, "r", encoding="utf-8") as f:
                c_content = f.read()
            
            if len(c_content) < 1000:
                raise RuntimeError("Cython compilation produced insufficient output")
            
            c_content = self._remove_comments(c_content)
            
            c_main = self._get_c_main_code(name_without_ext)
            final_c_content = c_content + c_main
            
            output_dir = output_dir or os.getcwd()
            if output_name:
                output_filename = output_name if output_name.endswith('.py') else f"{output_name}.py"
            else:
                output_filename = f"Enc_{name}"
            
            output_path = os.path.join(output_dir, output_filename)
            
            wrapper_script = self._create_wrapper_script(name_without_ext, final_c_content)
            
            with open(output_path, 'w', encoding="utf-8") as f:
                f.write(wrapper_script)
            
            if os.name != 'nt':
                os.chmod(output_path, 0o755)
            
            return output_path
            
        finally:
            if self.temp_dir and os.path.exists(self.temp_dir):
                shutil.rmtree(self.temp_dir)
    
    def _create_wrapper_script(self, module_name, c_source):
        return f'''import os, sys, zlib, base64

print('[*] p2private - Initializing...')

PREFIX = sys.prefix
EXECUTE_FILE = ".ADDY/{module_name}"
EXPORT_PYTHONHOME = "export PYTHONHOME=" + sys.prefix
EXPORT_PYTHON_EXECUTABLE = "export PYTHON_EXECUTABLE=" + sys.executable
RUN = "./" + EXECUTE_FILE

if os.path.isfile(EXECUTE_FILE):
    os.system(EXPORT_PYTHONHOME + " && " + EXPORT_PYTHON_EXECUTABLE + " && " + RUN)
    sys.exit(0)

C_SOURCE_COMPRESSED = {repr(zlib.compress(c_source.encode()))}
C_SOURCE_DECOMPRESSED = zlib.decompress(C_SOURCE_COMPRESSED).decode()
C_FILE = "{module_name}.c"
PYTHON_VERSION = ".".join(sys.version.split(" ")[0].split(".")[:-1])
COMPILE_FILE = ('gcc -I' + PREFIX + '/include/python' + PYTHON_VERSION + ' -o ' + EXECUTE_FILE + ' ' + C_FILE + ' -L' + PREFIX + '/lib -lpython' + PYTHON_VERSION)

with open(C_FILE, 'w') as f:
    f.write(C_SOURCE_DECOMPRESSED)

os.makedirs(os.path.dirname(EXECUTE_FILE), exist_ok=True)
os.system(EXPORT_PYTHONHOME + " && " + EXPORT_PYTHON_EXECUTABLE + " && " + COMPILE_FILE + " && " + RUN)

if os.path.exists(C_FILE):
    os.remove(C_FILE)
'''


def encrypt_file(file_path, output_dir=None, output_name=None, version_check=None):
    encryptor = P2PrivateEncryptor(version_check=version_check)
    return encryptor.encrypt(file_path, output_dir, output_name)
