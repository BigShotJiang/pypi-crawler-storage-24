#!/usr/bin/env python3
"""
Command Line Interface for p2private
"""

import argparse
import sys
import os
from .encryptor import P2PrivateEncryptor


def create_parser():
    """Create and return the argument parser."""
    parser = argparse.ArgumentParser(
        prog='p2private',
        description='''
    ____  ____  _________       ____  ____  _   ________
   / __ \/ __ \/ ____/ (_)___  / __ \/ __ \/ | / / ____/
  / /_/ / /_/ / __/ / / / __ \/ /_/ / / / /  |/ / /     
 / ____/ ____/ /___/ / / /_/ / ____/ /_/ / /|  / /___   
/_/   /_/   /_____/_/_/ .___/_/    \____/_/ |_/\____/   
                     /_/                                

Python to Private Executable Converter
Encrypt your Python scripts to standalone executables using Cython.
        ''',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
Examples:
  p2private script.py                    # Encrypt script.py
  p2private script.py -o myapp           # Encrypt with custom output name
  p2private script.py -v 3.11            # Add version check for Python 3.11
  p2private script.py -d ./output        # Specify output directory
        '''
    )
    
    parser.add_argument(
        'file',
        help='Python file to encrypt'
    )
    
    parser.add_argument(
        '-o', '--output',
        metavar='NAME',
        help='Output filename (default: Enc_<input_filename>)'
    )
    
    parser.add_argument(
        '-d', '--directory',
        metavar='DIR',
        help='Output directory (default: current directory)'
    )
    
    parser.add_argument(
        '-v', '--version-check',
        metavar='VERSION',
        help='Add Python version check (e.g., 3.11, 3.12, 3.13)'
    )
    
    parser.add_argument(
        '--version',
        action='version',
        version='%(prog)s 1.0.4'
    )
    
    return parser


def main():
    """Main entry point for CLI."""
    parser = create_parser()
    args = parser.parse_args()
    
    if not os.path.exists(args.file):
        print(f"[ERROR] File not found: {args.file}")
        sys.exit(1)
    
    if not args.file.endswith('.py'):
        print("[WARNING] Input file does not have .py extension")
    
    if args.version_check:
        if not args.version_check.replace('.', '').isdigit():
            print("[ERROR] Version check must be in format like '3.11', '3.12', etc.")
            sys.exit(1)
        print(f"[*] Version check enabled: Python {args.version_check} required")
    
    if args.directory and not os.path.exists(args.directory):
        try:
            os.makedirs(args.directory)
            print(f"[*] Created output directory: {args.directory}")
        except Exception as e:
            print(f"[ERROR] Cannot create directory: {e}")
            sys.exit(1)
    
    try:
        encryptor = P2PrivateEncryptor(version_check=args.version_check)
        output_path = encryptor.encrypt(
            file_path=args.file,
            output_dir=args.directory,
            output_name=args.output
        )
        
        print(f"\n[✓] Encryption successful!")
        print(f"[✓] Output file: {output_path}")
        print(f"\n[*] Run with: python {os.path.basename(output_path)}")
        
    except FileNotFoundError as e:
        print(f"[ERROR] {e}")
        sys.exit(1)
    except RuntimeError as e:
        print(f"[ERROR] {e}")
        sys.exit(1)
    except KeyboardInterrupt:
        print("\n[!] Operation cancelled by user")
        sys.exit(1)
    except Exception as e:
        print(f"[ERROR] Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    main()
