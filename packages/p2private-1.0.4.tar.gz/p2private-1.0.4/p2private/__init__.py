"""
p2private - Python to Private Executable Converter
A tool to encrypt/compile Python scripts to standalone executables using Cython.
"""

__version__ = "1.0.3"
__author__ = "addy"
__email__ = "poor4ddy@gmail.com"
__description__ = "Python to Private Executable Converter"
__github__ = "pooraddy"

from .encryptor import P2PrivateEncryptor, encrypt_file

__all__ = ["P2PrivateEncryptor", "encrypt_file"]
