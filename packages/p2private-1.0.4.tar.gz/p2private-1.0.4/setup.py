#!/usr/bin/env python3
"""
Setup script for p2private
"""

from setuptools import setup, find_packages
import os

here = os.path.abspath(os.path.dirname(__file__))
try:
    with open(os.path.join(here, 'README.md'), encoding='utf-8') as f:
        long_description = f.read()
except FileNotFoundError:
    long_description = 'Python to Private Executable Converter'

try:
    with open(os.path.join(here, 'requirements.txt'), encoding='utf-8') as f:
        requirements = [line.strip() for line in f if line.strip() and not line.startswith('#')]
except FileNotFoundError:
    requirements = [
        'Cython>=0.29.0',
        'autopep8>=1.6.0',
    ]

setup(
    name='p2private',
    version='1.0.4',
    author='addy',
    author_email='poor4ddy@gmail.com',
    description='Python to Private Executable Converter - Encrypt Python scripts to standalone executables',
    long_description=long_description,
    long_description_content_type='text/markdown',
    url='https://github.com/pooraddy/p2private',
    packages=find_packages(),
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'Topic :: Software Development :: Build Tools',
        'Topic :: Security :: Cryptography',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Programming Language :: Python :: 3.13',
        'Programming Language :: C',
        'Operating System :: OS Independent',
    ],
    keywords='python encryption cython compiler obfuscator executable',
    python_requires='>=3.11',
    install_requires=requirements,
    entry_points={
        'console_scripts': [
            'p2private=p2private.cli:main',
        ],
    },
    include_package_data=True,
    zip_safe=False,
    project_urls={
        'Bug Reports': 'https://github.com/pooraddy/p2private/issues',
        'Source': 'https://github.com/pooraddy/p2private',
        'Documentation': 'https://github.com/pooraddy/p2private#readme',
    },
)
