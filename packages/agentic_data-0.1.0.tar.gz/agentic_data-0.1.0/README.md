# AgenticData Python SDK

Pure-Python SDK that wraps the `adat` CLI binary.

```bash
pip install agentic-data
```
