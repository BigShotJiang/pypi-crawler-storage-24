"""AgenticData — Universal data comprehension for AI agents.

Pure-Python SDK that wraps the ``adat`` CLI binary via subprocess.
Zero required dependencies; only stdlib: subprocess, json, pathlib, dataclasses.
"""

from __future__ import annotations

import json
import logging
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

__version__ = "0.1.0"

logger = logging.getLogger(__name__)


class DataError(Exception):
    """Raised when an adat CLI command fails."""


@dataclass
class DataStore:
    """Interface to an ``.adat`` data store file.

    Parameters
    ----------
    path : str | Path
        Path to the ``.adat`` file. Created automatically on first write
        if it does not exist.
    binary : str
        Name or path of the ``adat`` CLI binary.
    """

    path: str | Path
    binary: str = "adat"
    _resolved_binary: Optional[str] = field(default=None, repr=False, init=False)

    def __post_init__(self) -> None:
        self.path = Path(self.path)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _find_binary(self) -> str:
        if self._resolved_binary is not None:
            return self._resolved_binary

        import shutil

        found = shutil.which(self.binary)
        if found is None:
            raise DataError(
                f"Cannot find '{self.binary}' on PATH. "
                "Install AgenticData: curl -fsSL https://agentralabs.tech/install/data | bash"
            )
        self._resolved_binary = found
        return found

    def _run(self, *args: str, check: bool = True) -> str:
        """Execute an adat CLI command and return stdout."""
        cmd = [self._find_binary(), "--file", str(self.path), *args]
        logger.debug("Running: %s", " ".join(cmd))
        result = subprocess.run(cmd, capture_output=True, text=True)
        if check and result.returncode != 0:
            raise DataError(
                f"adat command failed (exit {result.returncode}): {result.stderr.strip()}"
            )
        return result.stdout.strip()

    def _run_json(self, *args: str) -> Any:
        """Execute a command and parse JSON output."""
        raw = self._run(*args, "--format", "json")
        return json.loads(raw) if raw else {}

    # ------------------------------------------------------------------
    # Data operations
    # ------------------------------------------------------------------

    def detect_format(self, source: str) -> dict[str, Any]:
        """Detect the format of a data source. Returns format metadata."""
        return self._run_json("format", "detect", source)

    def ingest(
        self,
        source: str,
        *,
        format: Optional[str] = None,
        schema: Optional[str] = None,
    ) -> str:
        """Ingest data from a source. Returns the ingestion ID."""
        args = ["ingest", source]
        if format:
            args.extend(["--format", format])
        if schema:
            args.extend(["--schema", schema])
        return self._run(*args)

    def query(self, expression: str, *, limit: Optional[int] = None) -> list[dict[str, Any]]:
        """Query data with an expression. Returns matching records."""
        args = ["query", expression, "--format", "json"]
        if limit is not None:
            args.extend(["--limit", str(limit)])
        raw = self._run(*args)
        return json.loads(raw) if raw else []

    def quality_score(self, source: Optional[str] = None) -> dict[str, Any]:
        """Compute data quality score. Returns quality metrics."""
        args = ["quality", "score", "--format", "json"]
        if source:
            args.append(source)
        raw = self._run(*args)
        return json.loads(raw) if raw else {}

    # ------------------------------------------------------------------
    # Stats
    # ------------------------------------------------------------------

    def stats(self) -> dict[str, Any]:
        """Get data store statistics."""
        raw = self._run("stats", "--format", "json")
        return json.loads(raw) if raw else {}

    # ------------------------------------------------------------------
    # File operations
    # ------------------------------------------------------------------

    def save(self) -> None:
        """Explicit save (most operations auto-save)."""
        pass

    @property
    def exists(self) -> bool:
        """Whether the .adat file exists on disk."""
        return self.path.exists()
