"""
LanguageServer API 客户端。

解决的已知问题：
- 自签名证书 → verify=False + 禁用 urllib3 警告
- 未索引对话按需加载 → 直接用 cascadeId 调用即可
- API 仅运行时可用 → 所有调用有 timeout + 友好错误提示
"""

from typing import Any, Optional

import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

BASE_PATH = "exa.language_server_pb.LanguageServerService"


def call_api(
    port: int,
    csrf_token: str,
    method: str,
    params: Optional[dict] = None,
    timeout: int = 15,
) -> Optional[dict]:
    """调用 LanguageServer gRPC-Web API。

    Args:
        port: 本地端口
        csrf_token: 从进程参数提取的 CSRF Token
        method: API 方法名 (e.g. "GetAllCascadeTrajectories")
        params: 请求体
        timeout: 超时秒数

    Returns:
        响应 JSON dict，失败返回 None
    """
    url = f"https://localhost:{port}/{BASE_PATH}/{method}"
    headers = {
        "Content-Type": "application/json",
        "Connect-Protocol-Version": "1",
        "X-Codeium-Csrf-Token": csrf_token,
    }
    try:
        resp = requests.post(
            url, headers=headers, json=params or {}, verify=False, timeout=timeout
        )
        if resp.status_code == 200:
            return resp.json()
    except requests.exceptions.ConnectionError:
        pass
    except requests.exceptions.Timeout:
        pass
    except Exception:
        pass
    return None


def get_all_trajectories(port: int, csrf: str) -> dict[str, Any]:
    """获取单个 LS 实例的所有对话摘要。"""
    result = call_api(port, csrf, "GetAllCascadeTrajectories")
    if not result:
        return {}
    return result.get("trajectorySummaries", {})


def get_all_trajectories_merged(endpoints: list[dict]) -> tuple[dict[str, Any], dict[str, dict]]:
    """查询所有 LS 实例，合并去重全部对话摘要。

    Args:
        endpoints: [{"port": int, "csrf": str, "pid": int}, ...]

    Returns:
        (merged_summaries, cascade_to_endpoint)
        - merged_summaries: {cascadeId: summary_dict}
        - cascade_to_endpoint: {cascadeId: {"port": int, "csrf": str}}
          记录每个对话应该用哪个端点去获取 steps
    """
    merged = {}
    cascade_ep = {}

    for ep in endpoints:
        summaries = get_all_trajectories(ep["port"], ep["csrf"])
        for cid, info in summaries.items():
            if cid not in merged:
                merged[cid] = info
                cascade_ep[cid] = {"port": ep["port"], "csrf": ep["csrf"]}

    return merged, cascade_ep


def get_trajectory_steps(
    port: int, csrf: str, cascade_id: str, step_count: int = 1000
) -> list[dict]:
    """获取某个对话的所有步骤。

    支持未索引对话的按需加载 — 直接用 cascadeId 请求即可。

    Args:
        cascade_id: 对话 UUID
        step_count: 预估步骤数（用于设置 endIndex）

    Returns:
        步骤列表
    """
    result = call_api(
        port, csrf, "GetCascadeTrajectorySteps",
        {"cascadeId": cascade_id, "startIndex": 0, "endIndex": step_count + 10},
        timeout=30,
    )
    if not result:
        return []
    return result.get("steps", result.get("messages", []))
