"""gjalla Pre-commit Analysis CLI."""

__version__ = "0.5.2"
