from setuptools import setup, find_packages

setup(
    name='autoupb',
    version='1.0.1',
    description='A professional tool for U-Pb geochronology data processing.',
    author='peng yu',
    packages=find_packages(), # 自动寻找 upbapp 文件夹里的代码
    include_package_data=True,
    # 核心：告诉程序需要自动下载哪些环境依赖！
    install_requires=[
        'numpy',
        'scipy',
        'matplotlib',
        'PyQt6',
        'pyqtgraph',
        'uncertainties',
        'pandas', 
        'openpyxl',
        'lmfit',
        'scikit-learn',
        'statsmodels',
        'patsy',
        'xlsxwriter'
    ],
    # 终极魔法：安装后，在终端敲 `autoupb` 就能直接启动软件！
    entry_points={
        'console_scripts': [
            'autoupb=upbapp.__main__:main', # 假设你的主入口在 upbapp/__main__.py 里的 main() 函数
        ],
    },
)