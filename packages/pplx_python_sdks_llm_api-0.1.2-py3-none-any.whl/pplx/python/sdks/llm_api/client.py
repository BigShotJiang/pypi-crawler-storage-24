import asyncio
import logging
import os
import random
import time
from collections.abc import AsyncIterator, Awaitable, Callable, Sequence
from contextlib import nullcontext
from dataclasses import dataclass, field
from typing import Self, cast, final

try:
    import ddtrace
    from ddtrace.propagation.http import HTTPPropagator
except ImportError:
    _DDTRACER = None
    HTTPPropagator = None  # type: ignore[assignment, misc]
else:
    try:
        _DDTRACER: ddtrace.Tracer | None = ddtrace.tracer  # type: ignore[no-redef]
    except AttributeError:
        _DDTRACER = ddtrace.tracer

import grpc
import jiter
from pplx.python.sdks.llm_api.errors import (
    BadRequestError,
    LLMAPIError,
    ModelErrorDebugInfo,
    ModelPoolExhaustedError,
    error_event_to_exception,
    model_error_type_to_string,
)
from pplx.python.sdks.llm_api.metrics import (
    ErrorType,
    RequestMethod,
    RequestStatus,
    send_dd_metric,
)
from pplx.python.sdks.llm_api.types import (
    AnalyticsParams,
    ApproximateCostEvent,
    Betas,
    CachingParams,
    ContentBlockDeltaEvent,
    ContentBlockEvent,
    ContentBlockStartEvent,
    ContentBlockStopEvent,
    Conversation,
    FinishReason,
    FixedRetryPolicy,
    GeneratedAudioBlockEvent,
    GeneratedAudioDelta,
    GeneratedImageBlockEvent,
    GeneratedImageDelta,
    GeneratedVideoBlockEvent,
    GeneratedVideoDelta,
    Identity,
    InputJsonDelta,
    MediaGenParams,
    MessageDeltaData,
    MessageDeltaEvent,
    MessageDeltaUsage,
    MessageEvent,
    MessageStartEvent,
    MessageStopEvent,
    Modality,
    ModelErrorDebugInfoEvent,
    ModelErrorEvent,
    ModelId,
    ModelWithPolicy,
    MultiModelRetryPolicy,
    Omit,
    RetryPolicy,
    Role,
    SamplingParams,
    ServiceTier,
    SignatureDelta,
    SingleModelRetryPolicy,
    StreamEvent,
    StructuredOutputParams,
    TextBlockEvent,
    TextDelta,
    ThinkingBlockEvent,
    ThinkingDelta,
    ThinkingParams,
    TokenUsage,
    ToolParams,
    ToolUseBlockEvent,
    TranscriptionBlockEvent,
    TranscriptionDelta,
    TranscriptionWord,
    omit,
)
from protobuf.perplexity_pb.llm_api import (
    LlmApi_pb2 as proto,
    LlmApi_pb2_grpc,
)


def _from_omit[T](value: T | Omit) -> T | None:
    if value is omit:
        return None
    return cast(T, value)


_REQUEST_ID_HEADER = "x-request-id"
_API_KEY_HEADER = "x-api-key"

_GrpcMetadata = tuple[tuple[str, str], ...]

MetadataProvider = Callable[[], Sequence[tuple[str, str]]]


def _get_ddtrace_metadata() -> list[tuple[str, str]]:
    if _DDTRACER is None:
        return []
    span = _DDTRACER.current_span()
    if span is None:
        return []
    headers: dict[str, str] = {}
    HTTPPropagator.inject(span.context, headers)
    return list(headers.items())


def _build_metadata(
    request_id: str | None,
    api_key: str | None = None,
    metadata_provider: MetadataProvider | None = None,
) -> _GrpcMetadata | None:
    entries: list[tuple[str, str]] = []
    if api_key:
        entries.append((_API_KEY_HEADER, api_key))
    if request_id:
        entries.append((_REQUEST_ID_HEADER, request_id))
    entries.extend(_get_ddtrace_metadata())
    if metadata_provider is not None:
        entries.extend(metadata_provider())
    if not entries:
        return None
    return tuple(entries)


class _StreamEventAccumulator:
    def __init__(self) -> None:
        self._blocks: list[ContentBlockEvent] = []
        self._tool_json: str = ""
        self._media_b64: str = ""
        self.cache_signature: str | None = None
        self.conversation_id: str | None = None
        self.approximate_cost: ApproximateCostEvent | None = None
        self.model_id: str | None = None
        self.usage: TokenUsage = TokenUsage()
        self.finish_reason: FinishReason | None = None
        self.request_id: str = ""

    def reset(self) -> None:
        _StreamEventAccumulator.__init__(self)

    def copy_from(self, other: Self) -> None:
        self.__dict__.update(other.__dict__)

    def start_block(self, block: ContentBlockEvent) -> None:
        copy = block.model_copy(deep=True)
        copy.partial = True
        self._blocks.append(copy)
        self._tool_json = ""
        self._media_b64 = ""

    def accumulate_delta(self, delta: ContentBlockDeltaEvent) -> ContentBlockDeltaEvent:
        if not self._blocks:
            return delta
        match (self._blocks[-1], delta.delta):
            case (TextBlockEvent() as block, TextDelta() as d):
                block.text += d.text
            case (ToolUseBlockEvent(), InputJsonDelta() as d):
                self._tool_json += d.partial_json
                parsed = self._try_parse_partial_json()
                if parsed is not None:
                    return ContentBlockDeltaEvent(
                        delta=InputJsonDelta(
                            partial_json=d.partial_json,
                            parsed_json=parsed,
                        )
                    )
            case (ThinkingBlockEvent() as block, ThinkingDelta() as d):
                block.thinking += d.thinking
            case (ThinkingBlockEvent() as block, SignatureDelta() as d):
                block.signature += d.signature
            case (GeneratedImageBlockEvent(), GeneratedImageDelta() as d):
                self._media_b64 += d.b64_chunk
            case (GeneratedVideoBlockEvent(), GeneratedVideoDelta() as d):
                self._media_b64 += d.b64_chunk
            case (GeneratedAudioBlockEvent(), GeneratedAudioDelta() as d):
                self._media_b64 += d.b64_chunk
            case (TranscriptionBlockEvent() as block, TranscriptionDelta() as d):
                block.text += d.text
                block.words.extend(d.words)
                if d.language_code:
                    block.language_code = d.language_code
            case _:
                pass
        return delta

    def flush_block(self) -> None:
        if not self._blocks:
            return
        block = self._blocks[-1]
        match block:
            case ToolUseBlockEvent() if self._tool_json:
                block.input = self._tool_json
            case GeneratedImageBlockEvent() if self._media_b64:
                block.b64_data = self._media_b64
            case GeneratedVideoBlockEvent() if self._media_b64:
                block.b64_data = self._media_b64
            case GeneratedAudioBlockEvent() if self._media_b64:
                block.b64_data = self._media_b64

    def stop_block(self) -> None:
        self.flush_block()
        if self._blocks:
            self._blocks[-1].partial = False

    def _try_parse_partial_json(self) -> dict[str, object] | None:
        if not self._tool_json:
            return None
        try:
            parsed = jiter.from_json(
                self._tool_json.encode(), partial_mode="trailing-strings"
            )
        except ValueError:
            return None
        if isinstance(parsed, dict):
            return parsed
        return None

    def merge_token_usage(self, usage: proto.TokenUsage | None) -> None:
        if not usage:
            return
        modality = Modality.from_proto(usage.modality)
        new = TokenUsage(
            uncached_input_tokens=usage.uncached_input_tokens or 0,
            cached_input_tokens=usage.cached_input_tokens or 0,
            cache_write_tokens=usage.cache_write_tokens or 0,
            cache_write_1h_tokens=usage.cache_write_1h_tokens or 0,
            output_tokens=usage.output_tokens or 0,
            reasoning_tokens=usage.reasoning_tokens or 0,
            modality=modality,
        )
        self.usage = TokenUsage(
            uncached_input_tokens=max(
                self.usage.uncached_input_tokens, new.uncached_input_tokens
            ),
            cached_input_tokens=max(
                self.usage.cached_input_tokens, new.cached_input_tokens
            ),
            cache_write_tokens=max(
                self.usage.cache_write_tokens, new.cache_write_tokens
            ),
            cache_write_1h_tokens=max(
                self.usage.cache_write_1h_tokens, new.cache_write_1h_tokens
            ),
            output_tokens=max(self.usage.output_tokens, new.output_tokens),
            reasoning_tokens=max(self.usage.reasoning_tokens, new.reasoning_tokens),
            modality=new.modality,
        )

    @property
    def blocks(self) -> list[ContentBlockEvent]:
        return self._blocks


@final
class StreamResponse:
    def __init__(
        self,
        stream: AsyncIterator[StreamEvent],
        accumulator: _StreamEventAccumulator,
    ) -> None:
        self._iterator = stream
        self._accumulator = accumulator

    @property
    def request_id(self) -> str:
        return self._accumulator.request_id

    @property
    def approximate_cost(self) -> ApproximateCostEvent | None:
        return self._accumulator.approximate_cost

    @property
    def model(self) -> str | None:
        return self._accumulator.model_id

    @property
    def model_id(self) -> str | None:
        return self._accumulator.model_id

    @property
    def usage(self) -> TokenUsage:
        return self._accumulator.usage

    @property
    def content(self) -> list[ContentBlockEvent]:
        return self._accumulator.blocks

    @property
    def cache_signature(self) -> str | None:
        return self._accumulator.cache_signature

    @property
    def conversation_id(self) -> str | None:
        return self._accumulator.conversation_id

    @property
    def finish_reason(self) -> FinishReason | None:
        return self._accumulator.finish_reason

    async def __anext__(self) -> StreamEvent:
        return await self._iterator.__anext__()

    async def __aiter__(self) -> AsyncIterator[StreamEvent]:
        async for item in self._iterator:
            yield item


@final
class Messages:
    def __init__(
        self,
        channel: grpc.aio.Channel,
        address: str,
        api_key: str | None = None,
        *,
        use_channel_cache: bool = True,
        metadata_provider: MetadataProvider | None = None,
    ) -> None:
        self._channel = channel
        self._address = address
        self._api_key = api_key
        self._use_channel_cache = use_channel_cache
        self._metadata_provider = metadata_provider
        self._stub = LlmApi_pb2_grpc.LlmApiServiceStub(channel)

    def _reconnect(self) -> None:
        if self._use_channel_cache:
            _channel_cache.pop(self._address, None)
            self._channel = _get_or_create_channel(self._address)
        else:
            self._channel = _create_channel(self._address)
        self._stub = LlmApi_pb2_grpc.LlmApiServiceStub(self._channel)

    async def stream(
        self,
        *,
        model: ModelId,
        convo: Conversation,
        identity: Identity,
        sampling_params: SamplingParams | Omit = omit,
        tool_params: ToolParams | Omit = omit,
        thinking_params: ThinkingParams | Omit = omit,
        caching_params: CachingParams | Omit = omit,
        media_gen_params: MediaGenParams | Omit = omit,
        retry_policy: RetryPolicy | Omit = omit,
        structured_output_params: StructuredOutputParams | Omit = omit,
        betas: Betas | Omit = omit,
        analytics_params: AnalyticsParams | Omit = omit,
        service_tier: ServiceTier | None = None,
        request_id: str | None = None,
    ) -> StreamResponse:
        start_time = time.perf_counter()
        nullable_sampling_params = _from_omit(sampling_params)
        nullable_tool_params = _from_omit(tool_params)
        nullable_thinking_params = _from_omit(thinking_params)
        nullable_caching_params = _from_omit(caching_params)
        nullable_media_gen_params = _from_omit(media_gen_params)
        nullable_retry_policy = cast(RetryPolicy | None, _from_omit(retry_policy))
        nullable_structured_output_params = _from_omit(structured_output_params)
        nullable_betas = _from_omit(betas)
        nullable_analytics_params = _from_omit(analytics_params)

        # Multi-model fallback: when a MultiModelRetryPolicy is provided, we
        # intercept here and drive the fallback loop client-side instead of
        # forwarding the policy to the server. Each model is tried via a
        # recursive self.stream() call with its own per-model RetryPolicy.
        if isinstance(nullable_retry_policy, MultiModelRetryPolicy):
            return self._start_multi_model_stream(
                policy=nullable_retry_policy,
                model=model,
                convo=convo,
                identity=identity,
                sampling_params=sampling_params,
                tool_params=tool_params,
                thinking_params=thinking_params,
                caching_params=caching_params,
                media_gen_params=media_gen_params,
                structured_output_params=structured_output_params,
                betas=betas,
                analytics_params=analytics_params,
                service_tier=service_tier,
                request_id=request_id,
            )

        cache_last_message = (
            nullable_caching_params is not None
            and nullable_caching_params.cache_last_message
        )
        with convo.caching() if cache_last_message else nullcontext():
            request = self._build_request(
                model=model,
                convo=convo,
                identity=identity,
                sampling_params=nullable_sampling_params,
                tool_params=nullable_tool_params,
                thinking_params=nullable_thinking_params,
                caching_params=nullable_caching_params,
                media_gen_params=nullable_media_gen_params,
                retry_policy=nullable_retry_policy,
                structured_output_params=nullable_structured_output_params,
                betas=nullable_betas,
                analytics_params=nullable_analytics_params,
                service_tier=service_tier,
            )

        metadata = _build_metadata(request_id, self._api_key, self._metadata_provider)

        error_type: ErrorType | None = None
        grpc_code: grpc.StatusCode | None = None
        model_value = str(model)
        try:
            return await self._start_stream_with_retry(
                request, model_value, start_time, metadata
            )
        except grpc.aio.AioRpcError as e:
            error_type = ErrorType.GRPC_ERROR
            grpc_code = e.code()
            raise
        except Exception:
            error_type = ErrorType.UNKNOWN
            raise
        finally:
            if error_type is not None:
                send_dd_metric(
                    start_time=start_time,
                    method=RequestMethod.RESPONSES,
                    model=model_value,
                    status=RequestStatus.ERROR,
                    error_type=error_type,
                    grpc_code=grpc_code,
                )

    def _start_multi_model_stream(
        self,
        *,
        policy: MultiModelRetryPolicy,
        model: ModelId,
        convo: Conversation,
        identity: Identity,
        sampling_params: SamplingParams | Omit,
        tool_params: ToolParams | Omit,
        thinking_params: ThinkingParams | Omit,
        caching_params: CachingParams | Omit,
        media_gen_params: MediaGenParams | Omit,
        structured_output_params: StructuredOutputParams | Omit,
        betas: Betas | Omit,
        analytics_params: AnalyticsParams | Omit,
        service_tier: ServiceTier | None,
        request_id: str | None,
    ) -> StreamResponse:
        if not policy.models:
            raise ValueError("MultiModelRetryPolicy.models must not be empty")
        if policy.models[0].model != model:
            raise ValueError("model must match first model in MultiModelRetryPolicy")

        async def call_stream(entry: ModelWithPolicy) -> StreamResponse:
            return await self.stream(
                model=entry.model,
                convo=convo,
                identity=identity,
                sampling_params=sampling_params,
                tool_params=tool_params,
                thinking_params=thinking_params,
                caching_params=caching_params,
                media_gen_params=media_gen_params,
                retry_policy=entry.policy or FixedRetryPolicy(attempts=1),
                structured_output_params=structured_output_params,
                betas=betas,
                analytics_params=analytics_params,
                service_tier=service_tier,
                request_id=request_id,
            )

        accumulator = _StreamEventAccumulator()
        fallback_iter = self._iterate_with_fallback(
            models=policy.models,
            accumulator=accumulator,
            call_stream=call_stream,
        )
        return StreamResponse(fallback_iter, accumulator)

    async def _iterate_with_fallback(
        self,
        models: list[ModelWithPolicy],
        accumulator: _StreamEventAccumulator,
        call_stream: Callable[[ModelWithPolicy], Awaitable[StreamResponse]],
    ) -> AsyncIterator[StreamEvent]:
        all_debug_info: list[ModelErrorDebugInfo] = []
        last_request_id = ""

        for entry in models:
            try:
                stream = await call_stream(entry)
            except BadRequestError:
                raise
            except LLMAPIError as e:
                all_debug_info.extend(e.debug_info)
                last_request_id = e.request_id or last_request_id
                continue

            try:
                async for event in stream:
                    accumulator.copy_from(stream._accumulator)
                    yield event
                return
            except BadRequestError:
                raise
            except LLMAPIError as e:
                all_debug_info.extend(e.debug_info)
                last_request_id = e.request_id or last_request_id
                accumulator.reset()

        raise ModelPoolExhaustedError(
            message="All models exhausted",
            debug_info=all_debug_info,
            request_id=last_request_id,
        )

    async def _start_stream(
        self,
        request: proto.ResponsesRequest,
        model_value: str,
        start_time: float,
        metadata: _GrpcMetadata | None = None,
    ) -> StreamResponse:
        grpc_stream = self._stub.Responses(request, metadata=metadata)
        response_metadata = await grpc_stream.initial_metadata()  # type: ignore[misc]
        accumulator = _StreamEventAccumulator()
        rid = response_metadata.get("x-request-id", "")
        accumulator.request_id = rid.decode() if isinstance(rid, bytes) else rid
        return StreamResponse(
            self._stream_response_timed(
                cast(AsyncIterator[proto.ResponseEvent], grpc_stream),
                accumulator,
                model_value,
                start_time,
            ),
            accumulator,
        )

    async def _start_stream_with_retry(
        self,
        request: proto.ResponsesRequest,
        model_value: str,
        start_time: float,
        metadata: _GrpcMetadata | None = None,
    ) -> StreamResponse:
        try:
            return await self._start_stream(request, model_value, start_time, metadata)
        except grpc.aio.AioRpcError as e:
            match e.code():
                case grpc.StatusCode.UNAVAILABLE | grpc.StatusCode.RESOURCE_EXHAUSTED:
                    _logger.warning(
                        "%s on stream start, reconnecting and retrying once",
                        e.code().name,
                    )
                    self._reconnect()
                    return await self._start_stream(
                        request, model_value, start_time, metadata
                    )
                case _:
                    raise

    async def create(
        self,
        *,
        model: ModelId,
        convo: Conversation,
        identity: Identity,
        sampling_params: SamplingParams | Omit = omit,
        tool_params: ToolParams | Omit = omit,
        thinking_params: ThinkingParams | Omit = omit,
        caching_params: CachingParams | Omit = omit,
        media_gen_params: MediaGenParams | Omit = omit,
        retry_policy: RetryPolicy | Omit = omit,
        structured_output_params: StructuredOutputParams | Omit = omit,
        analytics_params: AnalyticsParams | Omit = omit,
        service_tier: ServiceTier | None = None,
        request_id: str | None = None,
    ) -> MessageEvent:
        stream_response = await self.stream(
            model=model,
            convo=convo,
            identity=identity,
            sampling_params=sampling_params,
            tool_params=tool_params,
            thinking_params=thinking_params,
            caching_params=caching_params,
            media_gen_params=media_gen_params,
            retry_policy=retry_policy,
            structured_output_params=structured_output_params,
            analytics_params=analytics_params,
            service_tier=service_tier,
            request_id=request_id,
        )
        async for _ in stream_response:
            pass
        return MessageEvent(
            role=Role.ASSISTANT,
            content=stream_response.content,
            cache_signature=stream_response.cache_signature,
            conversation_id=stream_response.conversation_id,
            model=stream_response.model,
            model_id=stream_response.model_id,
            usage=stream_response.usage,
            approximate_cost=stream_response.approximate_cost,
            finish_reason=stream_response.finish_reason,
        )

    async def tokens(
        self,
        *,
        model: ModelId,
        convo: Conversation,
        identity: Identity,
        tool_params: ToolParams | Omit = omit,
        request_id: str | None = None,
    ) -> int:
        start_time = time.perf_counter()
        nullable_tool_params = _from_omit(tool_params)
        request = self._build_count_tokens_request(
            model=model,
            convo=convo,
            identity=identity,
            tool_params=nullable_tool_params,
        )

        metadata = _build_metadata(request_id, self._api_key, self._metadata_provider)

        status = RequestStatus.SUCCESS
        error_type: ErrorType | None = None
        grpc_code: grpc.StatusCode | None = None
        try:
            return await self._count_tokens_with_retry(request, metadata)
        except grpc.aio.AioRpcError as e:
            status = RequestStatus.ERROR
            grpc_code = e.code()
            match e.code():
                case grpc.StatusCode.INVALID_ARGUMENT:
                    error_type = ErrorType.BAD_REQUEST
                    raise BadRequestError(
                        message=e.details() or "Invalid request",
                        debug_info=[],
                        request_id="",
                    ) from e
                case _:
                    error_type = ErrorType.GRPC_ERROR
                    raise LLMAPIError(
                        message=e.details() or "Unknown error",
                        debug_info=[],
                        request_id="",
                    ) from e
        except Exception:
            status = RequestStatus.ERROR
            error_type = ErrorType.UNKNOWN
            raise
        finally:
            send_dd_metric(
                start_time=start_time,
                method=RequestMethod.COUNT_TOKENS,
                model=str(model),
                status=status,
                error_type=error_type,
                grpc_code=grpc_code,
            )

    async def clone_voice(
        self,
        *,
        name: str,
        audio_data: bytes,
        filename: str,
        mime_type: str,
        provider: str = "elevenlabs",
        timeout: float = 60.0,
        request_id: str | None = None,
    ) -> str:
        start_time = time.perf_counter()
        request = proto.CloneVoiceRequest(
            name=name,
            audio_data=audio_data,
            filename=filename,
            mime_type=mime_type,
            provider=provider,
        )
        metadata = _build_metadata(request_id, self._api_key, self._metadata_provider)

        status = RequestStatus.SUCCESS
        error_type: ErrorType | None = None
        grpc_code: grpc.StatusCode | None = None
        try:
            return await self._clone_voice_with_retry(request, metadata, timeout)
        except grpc.aio.AioRpcError as e:
            status = RequestStatus.ERROR
            grpc_code = e.code()
            match e.code():
                case grpc.StatusCode.INVALID_ARGUMENT:
                    error_type = ErrorType.BAD_REQUEST
                    raise BadRequestError(
                        message=e.details() or "Invalid request",
                        debug_info=[],
                        request_id=request_id or "",
                    ) from e
                case _:
                    error_type = ErrorType.GRPC_ERROR
                    raise LLMAPIError(
                        message=e.details() or "Unknown error",
                        debug_info=[],
                        request_id=request_id or "",
                    ) from e
        except Exception:
            status = RequestStatus.ERROR
            error_type = ErrorType.UNKNOWN
            raise
        finally:
            send_dd_metric(
                start_time=start_time,
                method=RequestMethod.CLONE_VOICE,
                model=provider,
                status=status,
                error_type=error_type,
                grpc_code=grpc_code,
            )

    async def _clone_voice(
        self,
        request: proto.CloneVoiceRequest,
        metadata: _GrpcMetadata | None = None,
        timeout: float = 60.0,
    ) -> str:
        response = await self._stub.CloneVoice(
            request, metadata=metadata, timeout=timeout
        )  # type: ignore[misc]
        return response.voice_id

    async def _clone_voice_with_retry(
        self,
        request: proto.CloneVoiceRequest,
        metadata: _GrpcMetadata | None = None,
        timeout: float = 60.0,
    ) -> str:
        try:
            return await self._clone_voice(request, metadata, timeout)
        except grpc.aio.AioRpcError as e:
            match e.code():
                case grpc.StatusCode.UNAVAILABLE | grpc.StatusCode.RESOURCE_EXHAUSTED:
                    _logger.warning(
                        "%s on CloneVoice, reconnecting and retrying once",
                        e.code().name,
                    )
                    self._reconnect()
                    return await self._clone_voice(request, metadata, timeout)
                case _:
                    raise

    async def _count_tokens(
        self,
        request: proto.CountTokensRequest,
        metadata: _GrpcMetadata | None = None,
    ) -> int:
        response = await self._stub.CountTokens(request, metadata=metadata)  # type: ignore[misc]
        return response.input_tokens

    async def _count_tokens_with_retry(
        self,
        request: proto.CountTokensRequest,
        metadata: _GrpcMetadata | None = None,
    ) -> int:
        try:
            return await self._count_tokens(request, metadata)
        except grpc.aio.AioRpcError as e:
            match e.code():
                case grpc.StatusCode.UNAVAILABLE | grpc.StatusCode.RESOURCE_EXHAUSTED:
                    _logger.warning(
                        "%s on CountTokens, reconnecting and retrying once",
                        e.code().name,
                    )
                    self._reconnect()
                    return await self._count_tokens(request, metadata)
                case _:
                    raise

    def _build_count_tokens_request(
        self,
        model: ModelId,
        convo: Conversation,
        identity: Identity,
        tool_params: ToolParams | None,
    ) -> proto.CountTokensRequest:
        proto_convo = convo.to_proto()
        tool_call_args = self._build_tool_call_args(tool_params)

        return proto.CountTokensRequest(
            model_id=str(model),
            conversation=proto_convo,
            tool_call_args=tool_call_args,
            identity=identity.to_proto(),
        )

    def _build_request(
        self,
        model: ModelId,
        convo: Conversation,
        identity: Identity,
        sampling_params: SamplingParams | None,
        tool_params: ToolParams | None,
        thinking_params: ThinkingParams | None,
        caching_params: CachingParams | None,
        media_gen_params: MediaGenParams | None,
        retry_policy: SingleModelRetryPolicy | None,
        structured_output_params: StructuredOutputParams | None,
        betas: Betas | None,
        analytics_params: AnalyticsParams | None,
        service_tier: ServiceTier | None = None,
    ) -> proto.ResponsesRequest:
        proto_convo = convo.to_proto()

        sampling = self._build_sampling_params(
            sampling_params, thinking_params, structured_output_params, betas
        )
        tool_call_args = self._build_tool_call_args(tool_params)

        return proto.ResponsesRequest(
            model_id=str(model),
            conversation=proto_convo,
            sampling=sampling,
            tool_call_args=tool_call_args,
            identity=identity.to_proto(),
            media_gen_params=media_gen_params.to_proto() if media_gen_params else None,
            retry_policy=retry_policy.to_proto() if retry_policy else None,
            analytics_params=analytics_params.to_proto() if analytics_params else None,
            prompt_cache_key=caching_params.prompt_cache_key
            if caching_params
            else None,
            service_tier=service_tier.to_proto()
            if service_tier
            else proto.SERVICE_TIER_UNSPECIFIED,
        )

    def _build_sampling_params(
        self,
        sampling_params: SamplingParams | None,
        thinking_params: ThinkingParams | None,
        structured_output_params: StructuredOutputParams | None,
        betas: Betas | None,
    ) -> proto.SamplingParams:
        max_tokens = sampling_params.max_tokens if sampling_params else None
        sampling = proto.SamplingParams(max_tokens=max_tokens or 1024)
        if sampling_params and sampling_params.temperature is not None:
            sampling.temperature = sampling_params.temperature
        if sampling_params and sampling_params.top_p is not None:
            sampling.top_p = sampling_params.top_p
        if sampling_params and sampling_params.stop_sequences is not None:
            sampling.stop_sequences.extend(sampling_params.stop_sequences)
        if thinking_params and thinking_params.reasoning_effort is not None:
            sampling.reasoning_effort = thinking_params.reasoning_effort.to_proto()
        if thinking_params and thinking_params.auto_thinking is not None:
            sampling.auto_thinking = thinking_params.auto_thinking.to_proto()
        if structured_output_params:
            sampling.response_format.CopyFrom(
                structured_output_params.response_format.to_proto()
            )
        if betas:
            sampling.betas.CopyFrom(betas.to_proto())
        if sampling_params and sampling_params.verbosity is not None:
            sampling.verbosity = sampling_params.verbosity.to_proto()
        return sampling

    def _build_tool_call_args(
        self, tool_params: ToolParams | None
    ) -> proto.ToolCallArgs:
        tools: list[proto.Tool] = []
        tool_choice = proto.TOOL_CHOICE_AUTO
        parallel = False
        if tool_params and tool_params.tools is not None:
            tools = [tool.to_proto() for tool in tool_params.tools]
        if tool_params and tool_params.tool_choice is not None:
            tool_choice = tool_params.tool_choice.to_proto()
        if tool_params:
            parallel = tool_params.parallel_tool_calls
        return proto.ToolCallArgs(
            tools=tools,
            tool_choice=tool_choice,
            parallel_tool_calls=parallel,
        )

    async def _stream_response_timed(
        self,
        grpc_stream: AsyncIterator[proto.ResponseEvent],
        accumulator: _StreamEventAccumulator,
        model_name: str,
        start_time: float,
    ) -> AsyncIterator[StreamEvent]:
        status = RequestStatus.SUCCESS
        error_type: ErrorType | None = None
        grpc_code: grpc.StatusCode | None = None
        try:
            async for event in self._stream_response(grpc_stream, accumulator):
                yield event
        except LLMAPIError as e:
            status = RequestStatus.ERROR
            error_type = e.metric_error_type
            raise
        except grpc.aio.AioRpcError as e:
            status = RequestStatus.ERROR
            error_type = ErrorType.GRPC_ERROR
            grpc_code = e.code()
            if e.code() == grpc.StatusCode.UNAVAILABLE:
                self._reconnect()
            raise
        except GeneratorExit:
            status = RequestStatus.CANCELLED
            raise
        except Exception:
            status = RequestStatus.ERROR
            error_type = ErrorType.UNKNOWN
            raise
        finally:
            send_dd_metric(
                start_time=start_time,
                method=RequestMethod.RESPONSES,
                model=model_name,
                status=status,
                error_type=error_type,
                grpc_code=grpc_code,
            )

    async def _stream_response(
        self,
        grpc_stream: AsyncIterator[proto.ResponseEvent],
        accumulator: _StreamEventAccumulator,
    ) -> AsyncIterator[StreamEvent]:
        async for response_event in grpc_stream:
            match response_event.WhichOneof("event"):
                case "error":
                    raise error_event_to_exception(response_event.error)
                case None:
                    continue
                case _:
                    pass

            stream = response_event.stream

            match stream.WhichOneof("event"):
                case "message_start":
                    accumulator.merge_token_usage(stream.message_start.usage)
                    yield MessageStartEvent(
                        message=MessageEvent(role=Role.ASSISTANT, content=[]),
                    )
                case "message_delta":
                    accumulator.merge_token_usage(stream.message_delta.usage)
                    yield MessageDeltaEvent(
                        delta=MessageDeltaData(),
                        usage=MessageDeltaUsage(
                            uncached_input_tokens=accumulator.usage.uncached_input_tokens,
                            cached_input_tokens=accumulator.usage.cached_input_tokens,
                            cache_write_tokens=accumulator.usage.cache_write_tokens,
                            output_tokens=accumulator.usage.output_tokens,
                            reasoning_tokens=accumulator.usage.reasoning_tokens,
                        ),
                    )
                case "message_stop":
                    accumulator.merge_token_usage(stream.message_stop.usage)
                    accumulator.model_id = stream.message_stop.model_id or None
                    if stream.message_stop.cache_signature:
                        accumulator.cache_signature = (
                            stream.message_stop.cache_signature
                        )
                    if stream.message_stop.conversation_id:
                        accumulator.conversation_id = (
                            stream.message_stop.conversation_id
                        )
                    if stream.message_stop.finish_reason:
                        try:
                            accumulator.finish_reason = FinishReason(
                                stream.message_stop.finish_reason
                            )
                        except ValueError:
                            pass
                case "content_block_start":
                    event = self._handle_content_block_start(stream.content_block_start)
                    accumulator.start_block(event.content_block)
                    yield event
                case "content_block_delta":
                    delta_event = self._handle_content_block_delta(
                        stream.content_block_delta
                    )
                    yield accumulator.accumulate_delta(delta_event)
                case "content_block_stop":
                    accumulator.stop_block()
                    yield ContentBlockStopEvent()
                case "approximate_cost":
                    cost_event = ApproximateCostEvent(
                        total_cost=stream.approximate_cost.total_cost or 0.0,
                        uncached_input_cost=stream.approximate_cost.uncached_input_cost
                        or 0.0,
                        cached_input_cost=stream.approximate_cost.cached_input_cost
                        or 0.0,
                        cache_write_cost=stream.approximate_cost.cache_write_cost
                        or 0.0,
                        output_cost=stream.approximate_cost.output_cost or 0.0,
                        image_cost=stream.approximate_cost.image_cost or None,
                        video_cost=stream.approximate_cost.video_cost or None,
                        audio_cost=stream.approximate_cost.audio_cost or None,
                        total_undiscounted_cost=stream.approximate_cost.total_undiscounted_cost
                        or 0.0,
                    )
                    accumulator.approximate_cost = cost_event
                    yield cost_event
                case "model_error":
                    accumulator.reset()
                    debug = stream.model_error.debug_info
                    yield ModelErrorEvent(
                        debug_info=ModelErrorDebugInfoEvent(
                            model_id=debug.model_id,
                            api_base=debug.api_base,
                            error_type=model_error_type_to_string(debug.error_type),
                            message=debug.message,
                        ),
                    )
                case _:
                    pass

        accumulator.flush_block()

        yield MessageStopEvent(
            message=MessageEvent(
                role=Role.ASSISTANT,
                content=accumulator.blocks,
                cache_signature=accumulator.cache_signature,
                conversation_id=accumulator.conversation_id,
                model=accumulator.model_id,
                model_id=accumulator.model_id,
                usage=accumulator.usage,
                approximate_cost=accumulator.approximate_cost,
                finish_reason=accumulator.finish_reason,
            ),
        )

    def _handle_content_block_start(
        self, event: proto.ContentBlockStartEvent
    ) -> ContentBlockStartEvent:
        match event.WhichOneof("content_block"):
            case "tool_use":
                return ContentBlockStartEvent(
                    content_block=ToolUseBlockEvent(
                        id=event.tool_use.tool_use_id or "",
                        name=event.tool_use.name or "",
                    ),
                )
            case "thinking":
                return ContentBlockStartEvent(
                    content_block=ThinkingBlockEvent(
                        endpoint_signature=event.thinking.endpoint_signature or "",
                        reasoning_item_id=event.thinking.reasoning_item_id or "",
                    ),
                )
            case "generated_image":
                return ContentBlockStartEvent(
                    content_block=GeneratedImageBlockEvent(
                        index=event.generated_image.index or 0,
                    ),
                )
            case "generated_video":
                return ContentBlockStartEvent(
                    content_block=GeneratedVideoBlockEvent(
                        index=event.generated_video.index or 0,
                    ),
                )
            case "generated_audio":
                return ContentBlockStartEvent(
                    content_block=GeneratedAudioBlockEvent(
                        index=event.generated_audio.index or 0,
                    ),
                )
            case "transcription":
                return ContentBlockStartEvent(
                    content_block=TranscriptionBlockEvent(),
                )
            case _:
                return ContentBlockStartEvent(content_block=TextBlockEvent(text=""))

    def _handle_content_block_delta(
        self, event: proto.ContentBlockDeltaEvent
    ) -> ContentBlockDeltaEvent:
        match event.WhichOneof("delta"):
            case "text_delta":
                return ContentBlockDeltaEvent(
                    delta=TextDelta(text=event.text_delta.text or "")
                )
            case "input_json_delta":
                return ContentBlockDeltaEvent(
                    delta=InputJsonDelta(
                        partial_json=event.input_json_delta.partial_json or ""
                    )
                )
            case "thinking_delta":
                return ContentBlockDeltaEvent(
                    delta=ThinkingDelta(thinking=event.thinking_delta.text or "")
                )
            case "signature_delta":
                return ContentBlockDeltaEvent(
                    delta=SignatureDelta(signature=event.signature_delta.data or "")
                )
            case "generated_image_delta":
                return ContentBlockDeltaEvent(
                    delta=GeneratedImageDelta(
                        b64_chunk=event.generated_image_delta.b64_chunk or ""
                    )
                )
            case "generated_video_delta":
                return ContentBlockDeltaEvent(
                    delta=GeneratedVideoDelta(
                        b64_chunk=event.generated_video_delta.b64_chunk or ""
                    )
                )
            case "generated_audio_delta":
                return ContentBlockDeltaEvent(
                    delta=GeneratedAudioDelta(
                        b64_chunk=event.generated_audio_delta.b64_chunk or ""
                    )
                )
            case "transcription_delta":
                td = event.transcription_delta
                words = [
                    TranscriptionWord(
                        text=w.text,
                        start=w.start,
                        end=w.end,
                        speaker_id=w.speaker_id,
                    )
                    for w in td.words
                ]
                return ContentBlockDeltaEvent(
                    delta=TranscriptionDelta(
                        text=td.text or "",
                        words=words,
                        language_code=td.language_code or "",
                    )
                )
            case _:
                return ContentBlockDeltaEvent()


_GRPC_MAX_RECEIVE_MESSAGE_LENGTH = (
    500 * 1024 * 1024
)  # 500 MB (supports 4K video responses)
_GRPC_MAX_SEND_MESSAGE_LENGTH = 500 * 1024 * 1024  # 500 MB

_GRPC_KEEPALIVE_TIME_MS = 60_000
_GRPC_KEEPALIVE_TIMEOUT_MS = 20_000

_logger = logging.getLogger("pplx.python.sdks.llm_api.client")

_GRPC_CHANNEL_OPTIONS: list[tuple[str, int | bool]] = [
    ("grpc.max_receive_message_length", _GRPC_MAX_RECEIVE_MESSAGE_LENGTH),
    ("grpc.max_send_message_length", _GRPC_MAX_SEND_MESSAGE_LENGTH),
    ("grpc.keepalive_time_ms", _GRPC_KEEPALIVE_TIME_MS),
    ("grpc.keepalive_timeout_ms", _GRPC_KEEPALIVE_TIMEOUT_MS),
    ("grpc.keepalive_permit_without_calls", True),
    ("grpc.http2.max_pings_without_data", 0),
]


def _parse_env_float(name: str, default: str) -> float:
    raw = os.getenv(name, default)
    try:
        return max(float(raw), 0.0)
    except ValueError:
        return 0.0


# Channel TTL configuration — read once at module load.
# Set PPLX_LLM_API_CHANNEL_TTL_SECONDS to a positive value to enable periodic
# gRPC channel recycling (client-side load balancing).  A value of 0 (default)
# disables the feature.  PPLX_LLM_API_CHANNEL_TTL_JITTER_SECONDS (default 15)
# adds per-entry random jitter to stagger reconnections across clients.
_CHANNEL_TTL_SECONDS: float = _parse_env_float("PPLX_LLM_API_CHANNEL_TTL_SECONDS", "0")
_CHANNEL_TTL_JITTER_SECONDS: float = _parse_env_float(
    "PPLX_LLM_API_CHANNEL_TTL_JITTER_SECONDS", "15"
)


@dataclass
class _ChannelEntry:
    channel: grpc.aio.Channel
    created_at: float = field(default_factory=time.monotonic)
    # Jitter is computed once at creation so each entry has a fixed, deterministic
    # expiry time.  Cross-client stagger comes from different entries drawing
    # independent jitter values.
    jitter: float = 0.0

    def is_expired(self, ttl_seconds: float) -> bool:
        if ttl_seconds <= 0:
            return False
        return (time.monotonic() - self.created_at) > (ttl_seconds + self.jitter)


_channel_cache: dict[str, _ChannelEntry] = {}


def _create_channel(address: str) -> grpc.aio.Channel:
    if address.startswith("https://"):
        target = address[len("https://") :]
        return grpc.aio.secure_channel(
            target, grpc.ssl_channel_credentials(), options=_GRPC_CHANNEL_OPTIONS
        )
    return grpc.aio.insecure_channel(address, options=_GRPC_CHANNEL_OPTIONS)


def _is_channel_on_current_loop(channel: grpc.aio.Channel) -> bool:
    try:
        running_loop = asyncio.get_running_loop()
    except RuntimeError:
        return True
    return getattr(channel, "_loop", None) is running_loop


def _is_channel_usable(channel: grpc.aio.Channel) -> bool:
    if not _is_channel_on_current_loop(channel):
        return False
    try:
        state = channel.get_state(try_to_connect=False)
        return state != grpc.ChannelConnectivity.SHUTDOWN
    except Exception:
        return False


def _get_or_create_channel(address: str) -> grpc.aio.Channel:
    """Return a cached gRPC channel, recycling it when the TTL has elapsed."""
    entry = _channel_cache.get(address)

    if (
        entry is not None
        and not entry.is_expired(_CHANNEL_TTL_SECONDS)
        and _is_channel_usable(entry.channel)
    ):
        return entry.channel

    # Channel is missing, expired, or in SHUTDOWN state — create a fresh one.
    # NOTE: the old channel (if any) is intentionally NOT closed here.  Existing
    # LLMAPIClient / Messages instances still hold a reference to it and may
    # have in-progress streams.  The old channel will be garbage-collected once
    # all references are dropped.
    new_channel = _create_channel(address)
    jitter = random.uniform(0, _CHANNEL_TTL_JITTER_SECONDS)
    _channel_cache[address] = _ChannelEntry(channel=new_channel, jitter=jitter)
    return new_channel


async def close_all_channels() -> None:
    channels = [entry.channel for entry in _channel_cache.values()]
    _channel_cache.clear()
    await asyncio.gather(*(ch.close() for ch in channels))


_PREVIEW_HOSTNAME_SUFFIX = ".preview.i.perplexity.ai"

# PPL_DEPLOY_ENV → ALB address mapping.
_DEPLOY_ENV_TO_ALB: dict[str, str] = {
    "BETA": "https://llm-api-rust.prod.p.perplexity.ai",
    "STAGING": "https://llm-api-rust.staging.p.perplexity.ai",
    "TESTING": "https://llm-api-rust.testing.p.perplexity.ai",
    "SANDBOX": "https://llm-api-rust.testing.p.perplexity.ai",
    "AI_API_PRODUCTION": "https://llm-api-rust.prod.p.perplexity.ai",
}

_LOCAL_DEV_FALLBACK = "https://llm-api-rust.testing.p.perplexity.ai"


def resolve_llm_api_address(address: str | None = None) -> str:
    """Resolve the LLM API gRPC address.

    Priority order:
        1. Explicit *address* passed by the caller.
        2. ``PPLX_LLM_API_ADDRESS`` environment variable.
        3. Preview environment → ``llm-api-rust:50051`` (co-deployed instance).
        4. ALB address derived from ``PPL_DEPLOY_ENV``
           (prod / staging / testing).
        5. Fallback (local dev) → testing ALB.
    """
    # 1. Explicit address from caller
    if address:
        return address

    # 2. Environment variable override
    env_address = os.getenv("PPLX_LLM_API_ADDRESS")
    if env_address:
        return env_address

    # 3. Preview environment — use the co-deployed preview instance
    deploy_env = os.getenv("PPL_DEPLOY_ENV", "")
    if deploy_env == "TESTING" and os.getenv("PPL_SUPPORTED_HOSTNAMES", "").endswith(
        _PREVIEW_HOSTNAME_SUFFIX
    ):
        return "llm-api-rust:50051"

    # 4. ALB address based on deploy environment
    alb = _DEPLOY_ENV_TO_ALB.get(deploy_env)
    if alb:
        return alb

    # 5. Fallback for local dev / unknown environments
    return _LOCAL_DEV_FALLBACK


class LLMAPIClient:
    def __init__(
        self,
        address: str | None = None,
        api_key: str | None = None,
        *,
        use_channel_cache: bool = True,
        metadata_provider: MetadataProvider | None = None,
    ) -> None:
        resolved = resolve_llm_api_address(address)

        resolved_api_key = api_key or os.getenv("PPLX_LLM_API_KEY") or None

        self._address = resolved
        self._channel = (
            _get_or_create_channel(resolved)
            if use_channel_cache
            else _create_channel(resolved)
        )
        self.messages = Messages(
            self._channel,
            resolved,
            resolved_api_key,
            use_channel_cache=use_channel_cache,
            metadata_provider=metadata_provider,
        )
