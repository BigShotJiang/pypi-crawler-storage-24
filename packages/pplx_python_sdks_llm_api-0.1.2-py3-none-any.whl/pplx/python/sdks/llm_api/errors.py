from pplx.python.sdks.llm_api.metrics import ErrorType
from protobuf.perplexity_pb.llm_api import LlmApi_pb2 as proto


class ModelErrorDebugInfo:
    __slots__ = ("model_id", "api_base", "error_type", "message")

    def __init__(
        self, model_id: str, api_base: str, error_type: str, message: str
    ) -> None:
        self.model_id = model_id
        self.api_base = api_base
        self.error_type = error_type
        self.message = message

    def __repr__(self) -> str:
        return f"ModelErrorDebugInfo({self.model_id}@{self.api_base}: {self.error_type} - {self.message})"


class LLMAPIError(Exception):
    metric_error_type: ErrorType = ErrorType.API_ERROR

    def __init__(
        self,
        message: str,
        debug_info: list[ModelErrorDebugInfo],
        request_id: str,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.debug_info = debug_info
        self.request_id = request_id

    def __str__(self) -> str:
        parts = [f"Error: {self.message}"]
        if self.request_id:
            parts.append(f"Request ID: {self.request_id}")
        if self.debug_info:
            debug_lines = [f"  - {info}" for info in self.debug_info]
            parts.append("Debug info:\n" + "\n".join(debug_lines))
        return "\n".join(parts)


class ModelPoolExhaustedError(LLMAPIError):
    metric_error_type: ErrorType = ErrorType.MODEL_POOL_EXHAUSTED


class InternalError(LLMAPIError):
    metric_error_type: ErrorType = ErrorType.INTERNAL


class BadRequestError(LLMAPIError):
    metric_error_type: ErrorType = ErrorType.BAD_REQUEST


class PromptTooLongError(BadRequestError):
    metric_error_type: ErrorType = ErrorType.PROMPT_TOO_LONG


InputLengthExceededError = PromptTooLongError


def model_error_type_to_string(
    error_type: proto.ModelErrorType.ValueType,
) -> str:
    match error_type:
        case proto.MODEL_ERROR_TYPE_BAD_REQUEST:
            return "bad_request"
        case proto.MODEL_ERROR_TYPE_TIMEOUT:
            return "timeout"
        case proto.MODEL_ERROR_TYPE_STREAMING:
            return "streaming"
        case proto.MODEL_ERROR_TYPE_RATE_LIMITED:
            return "rate_limited"
        case proto.MODEL_ERROR_TYPE_PROMPT_TOO_LONG:
            return "prompt_too_long"
        case _:
            return "unknown"


def _parse_debug_info(
    debug_info: list[proto.ModelErrorDebugInfo],
) -> list[ModelErrorDebugInfo]:
    return [
        ModelErrorDebugInfo(
            model_id=info.model_id,
            api_base=info.api_base,
            error_type=model_error_type_to_string(info.error_type),
            message=info.message,
        )
        for info in debug_info
    ]


def error_event_to_exception(error: proto.ErrorEvent) -> LLMAPIError:
    debug_info = _parse_debug_info(list(error.debug_info))
    request_id = error.request_id
    match error.error_type:
        case proto.API_ERROR_TYPE_MODEL_POOL_EXHAUSTED:
            return ModelPoolExhaustedError(error.message, debug_info, request_id)
        case proto.API_ERROR_TYPE_INTERNAL:
            return InternalError(error.message, debug_info, request_id)
        case proto.API_ERROR_TYPE_BAD_REQUEST:
            return BadRequestError(error.message, debug_info, request_id)
        case proto.API_ERROR_TYPE_PROMPT_TOO_LONG:
            return PromptTooLongError(error.message, debug_info, request_id)
        case _:
            return LLMAPIError(error.message, debug_info, request_id)
