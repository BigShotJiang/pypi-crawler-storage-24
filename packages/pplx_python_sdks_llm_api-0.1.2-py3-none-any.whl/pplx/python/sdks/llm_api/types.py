import uuid as uuid_mod
from collections.abc import Iterator, Sequence
from contextlib import contextmanager
from enum import StrEnum, auto
from typing import Annotated, Any, Literal, Self, TypeAlias

import orjson
from google.protobuf.json_format import MessageToDict, ParseDict
from protobuf.perplexity_pb.llm_api import (
    LlmApi_pb2 as proto,
)
from pydantic import BaseModel, Discriminator, Field, model_validator
from uuid_extensions import uuid7


class Omit:
    __slots__ = ()

    def __repr__(self) -> str:
        return "omit"

    def __bool__(self) -> bool:
        return False


omit = Omit()


ModelId: TypeAlias = str


class Client(StrEnum):
    DEV = auto()
    AGI = auto()
    ASI = auto()
    AI_API = auto()
    DISCOVER = auto()
    EVAL_PLATFORM = auto()
    EVAL_SERVICE = auto()
    RESEARCH_EVAL = auto()
    AGENT_PROXY = auto()
    MEMORY_SERVICE = auto()
    RELATED_QUERIES = auto()
    THREAD_QUALITY = auto()
    SEARCH_EVALS = auto()
    CI_TEST = auto()


class Identity(BaseModel):
    client: Client
    use_case: str

    def to_proto(self) -> proto.Identity:
        return proto.Identity(client_id=self.client.value, use_case=self.use_case)


class ToolChoiceType(StrEnum):
    AUTO = auto()
    ANY = auto()
    NONE = auto()


class ReasoningEffort(StrEnum):
    NONE = auto()
    MINIMAL = auto()
    LOW = auto()
    MEDIUM = auto()
    HIGH = auto()
    XHIGH = auto()
    MAX = auto()

    def to_proto(self) -> proto.ReasoningEffort.ValueType:
        match self:
            case ReasoningEffort.NONE:
                return proto.REASONING_EFFORT_NONE
            case ReasoningEffort.MINIMAL:
                return proto.REASONING_EFFORT_MINIMAL
            case ReasoningEffort.LOW:
                return proto.REASONING_EFFORT_LOW
            case ReasoningEffort.MEDIUM:
                return proto.REASONING_EFFORT_MEDIUM
            case ReasoningEffort.HIGH:
                return proto.REASONING_EFFORT_HIGH
            case ReasoningEffort.XHIGH:
                return proto.REASONING_EFFORT_XHIGH
            case ReasoningEffort.MAX:
                return proto.REASONING_EFFORT_MAX


class AutoThinking(StrEnum):
    DISABLED = auto()
    AUTO = auto()

    def to_proto(self) -> proto.AutoThinking.ValueType:
        match self:
            case AutoThinking.DISABLED:
                return proto.AUTO_THINKING_DISABLED
            case AutoThinking.AUTO:
                return proto.AUTO_THINKING_AUTO


class Verbosity(StrEnum):
    LOW = auto()
    MEDIUM = auto()
    HIGH = auto()

    def to_proto(self) -> proto.Verbosity.ValueType:
        match self:
            case Verbosity.LOW:
                return proto.VERBOSITY_LOW
            case Verbosity.MEDIUM:
                return proto.VERBOSITY_MEDIUM
            case Verbosity.HIGH:
                return proto.VERBOSITY_HIGH


class MediaResolution(StrEnum):
    LOW = auto()
    MEDIUM = auto()
    HIGH = auto()

    def to_proto(self) -> proto.MediaResolution.ValueType:
        match self:
            case MediaResolution.LOW:
                return proto.MEDIA_RESOLUTION_LOW
            case MediaResolution.MEDIUM:
                return proto.MEDIA_RESOLUTION_MEDIUM
            case MediaResolution.HIGH:
                return proto.MEDIA_RESOLUTION_HIGH


class ImageGenSize(StrEnum):
    UNSPECIFIED = auto()
    SIZE_1024X1024 = auto()
    SIZE_1536X1024 = auto()
    SIZE_1024X1536 = auto()
    AUTO = auto()

    def to_proto(self) -> proto.ImageGenSize.ValueType:
        match self:
            case ImageGenSize.UNSPECIFIED:
                return proto.IMAGE_GEN_SIZE_UNSPECIFIED
            case ImageGenSize.SIZE_1024X1024:
                return proto.IMAGE_GEN_SIZE_1024X1024
            case ImageGenSize.SIZE_1536X1024:
                return proto.IMAGE_GEN_SIZE_1536X1024
            case ImageGenSize.SIZE_1024X1536:
                return proto.IMAGE_GEN_SIZE_1024X1536
            case ImageGenSize.AUTO:
                return proto.IMAGE_GEN_SIZE_AUTO


class ImageGenAspectRatio(StrEnum):
    UNSPECIFIED = auto()
    RATIO_1_1 = auto()
    RATIO_3_4 = auto()
    RATIO_4_3 = auto()
    RATIO_9_16 = auto()
    RATIO_16_9 = auto()

    def to_proto(self) -> proto.ImageGenAspectRatio.ValueType:
        match self:
            case ImageGenAspectRatio.UNSPECIFIED:
                return proto.IMAGE_GEN_ASPECT_RATIO_UNSPECIFIED
            case ImageGenAspectRatio.RATIO_1_1:
                return proto.IMAGE_GEN_ASPECT_RATIO_1_1
            case ImageGenAspectRatio.RATIO_3_4:
                return proto.IMAGE_GEN_ASPECT_RATIO_3_4
            case ImageGenAspectRatio.RATIO_4_3:
                return proto.IMAGE_GEN_ASPECT_RATIO_4_3
            case ImageGenAspectRatio.RATIO_9_16:
                return proto.IMAGE_GEN_ASPECT_RATIO_9_16
            case ImageGenAspectRatio.RATIO_16_9:
                return proto.IMAGE_GEN_ASPECT_RATIO_16_9


class ImageGenQuality(StrEnum):
    UNSPECIFIED = auto()
    LOW = auto()
    MEDIUM = auto()
    HIGH = auto()

    def to_proto(self) -> proto.ImageGenQuality.ValueType:
        match self:
            case ImageGenQuality.UNSPECIFIED:
                return proto.IMAGE_GEN_QUALITY_UNSPECIFIED
            case ImageGenQuality.LOW:
                return proto.IMAGE_GEN_QUALITY_LOW
            case ImageGenQuality.MEDIUM:
                return proto.IMAGE_GEN_QUALITY_MEDIUM
            case ImageGenQuality.HIGH:
                return proto.IMAGE_GEN_QUALITY_HIGH


class ImageGenOutputFormat(StrEnum):
    UNSPECIFIED = auto()
    PNG = auto()
    JPEG = auto()
    WEBP = auto()

    def to_proto(self) -> proto.ImageGenOutputFormat.ValueType:
        match self:
            case ImageGenOutputFormat.UNSPECIFIED:
                return proto.IMAGE_GEN_OUTPUT_FORMAT_UNSPECIFIED
            case ImageGenOutputFormat.PNG:
                return proto.IMAGE_GEN_OUTPUT_FORMAT_PNG
            case ImageGenOutputFormat.JPEG:
                return proto.IMAGE_GEN_OUTPUT_FORMAT_JPEG
            case ImageGenOutputFormat.WEBP:
                return proto.IMAGE_GEN_OUTPUT_FORMAT_WEBP


class ImageGenBackground(StrEnum):
    UNSPECIFIED = auto()
    TRANSPARENT = auto()
    OPAQUE = auto()
    AUTO = auto()

    def to_proto(self) -> proto.ImageGenBackground.ValueType:
        match self:
            case ImageGenBackground.UNSPECIFIED:
                return proto.IMAGE_GEN_BACKGROUND_UNSPECIFIED
            case ImageGenBackground.TRANSPARENT:
                return proto.IMAGE_GEN_BACKGROUND_TRANSPARENT
            case ImageGenBackground.OPAQUE:
                return proto.IMAGE_GEN_BACKGROUND_OPAQUE
            case ImageGenBackground.AUTO:
                return proto.IMAGE_GEN_BACKGROUND_AUTO


class VideoGenDuration(StrEnum):
    UNSPECIFIED = auto()
    DURATION_4S = auto()
    DURATION_6S = auto()
    DURATION_8S = auto()
    DURATION_12S = auto()

    def to_proto(self) -> proto.VideoGenDuration.ValueType:
        match self:
            case VideoGenDuration.UNSPECIFIED:
                return proto.VIDEO_GEN_DURATION_UNSPECIFIED
            case VideoGenDuration.DURATION_4S:
                return proto.VIDEO_GEN_DURATION_4S
            case VideoGenDuration.DURATION_6S:
                return proto.VIDEO_GEN_DURATION_6S
            case VideoGenDuration.DURATION_8S:
                return proto.VIDEO_GEN_DURATION_8S
            case VideoGenDuration.DURATION_12S:
                return proto.VIDEO_GEN_DURATION_12S


class FixedRetryPolicy(BaseModel):
    attempts: int = 1

    def to_proto(self) -> proto.RetryPolicy:
        return proto.RetryPolicy(fixed=proto.FixedRetryPolicy(attempts=self.attempts))


class RoundRobinRetryPolicy(BaseModel):
    rounds: int = 1

    def to_proto(self) -> proto.RetryPolicy:
        return proto.RetryPolicy(
            round_robin=proto.RoundRobinRetryPolicy(rounds=self.rounds)
        )


SingleModelRetryPolicy: TypeAlias = FixedRetryPolicy | RoundRobinRetryPolicy


class ModelWithPolicy(BaseModel):
    """A model with an optional per-model retry policy for client-side fallback."""

    model: str
    policy: SingleModelRetryPolicy | None = None


class MultiModelRetryPolicy(BaseModel):
    """Client-side multi-model fallback policy.

    The SDK drives the fallback loop locally: each model is tried in order
    via a recursive ``stream()`` call with its own per-model RetryPolicy.
    This is never sent to the server over the wire.
    """

    models: list[ModelWithPolicy]


RetryPolicy: TypeAlias = (
    FixedRetryPolicy | RoundRobinRetryPolicy | MultiModelRetryPolicy
)


class ImageGenParams(BaseModel):
    number_of_images: int = 1
    size: ImageGenSize = ImageGenSize.UNSPECIFIED
    aspect_ratio: ImageGenAspectRatio = ImageGenAspectRatio.UNSPECIFIED
    quality: ImageGenQuality = ImageGenQuality.UNSPECIFIED
    output_format: ImageGenOutputFormat = ImageGenOutputFormat.UNSPECIFIED
    background: ImageGenBackground = ImageGenBackground.UNSPECIFIED

    def to_proto(self) -> proto.ImageGenParams:
        return proto.ImageGenParams(
            number_of_images=self.number_of_images,
            size=self.size.to_proto(),
            aspect_ratio=self.aspect_ratio.to_proto(),
            quality=self.quality.to_proto(),
            output_format=self.output_format.to_proto(),
            background=self.background.to_proto(),
        )


class VideoGenParams(BaseModel):
    number_of_videos: int = 1
    duration: VideoGenDuration = VideoGenDuration.UNSPECIFIED
    generate_audio: bool = True
    aspect_ratio: ImageGenAspectRatio = ImageGenAspectRatio.UNSPECIFIED

    def to_proto(self) -> proto.VideoGenParams:
        return proto.VideoGenParams(
            number_of_videos=self.number_of_videos,
            duration=self.duration.to_proto(),
            generate_audio=self.generate_audio,
            aspect_ratio=self.aspect_ratio.to_proto(),
        )


class DialogueInput(BaseModel):
    voice: str
    text: str

    def to_proto(self) -> proto.DialogueInput:
        return proto.DialogueInput(voice=self.voice, text=self.text)


class AudioGenParams(BaseModel):
    voice: str = "sarah"
    output_format: str = ""
    dialogue_inputs: list[DialogueInput] = Field(default_factory=list)

    def to_proto(self) -> proto.AudioGenParams:
        return proto.AudioGenParams(
            voice=self.voice,
            output_format=self.output_format,
            dialogue_inputs=[d.to_proto() for d in self.dialogue_inputs],
        )


class SpeechToTextParams(BaseModel):
    diarize: bool = False
    num_speakers: int | None = Field(default=None, ge=1, le=32)
    timestamps_granularity: str = "none"
    language_code: str | None = None

    def to_proto(self) -> proto.SpeechToTextParams:
        params = proto.SpeechToTextParams(
            diarize=self.diarize,
            timestamps_granularity=self.timestamps_granularity,
            language_code=self.language_code or "",
        )
        if self.num_speakers is not None:
            params.num_speakers = self.num_speakers
        return params


class MediaGenParams(BaseModel):
    image: ImageGenParams | None = None
    video: VideoGenParams | None = None
    audio: AudioGenParams | None = None
    speech_to_text: SpeechToTextParams | None = None
    media_resolution: MediaResolution | None = None

    def to_proto(self) -> proto.MediaGenParams:
        params = proto.MediaGenParams(
            image=self.image.to_proto() if self.image else None,
            video=self.video.to_proto() if self.video else None,
            audio=self.audio.to_proto() if self.audio else None,
            speech_to_text=self.speech_to_text.to_proto()
            if self.speech_to_text
            else None,
        )
        if self.media_resolution is not None:
            params.media_resolution = self.media_resolution.to_proto()
        return params


class ContentBlockEventType(StrEnum):
    TEXT = auto()
    TOOL_USE = auto()
    THINKING = auto()
    GENERATED_IMAGE = auto()
    GENERATED_VIDEO = auto()
    GENERATED_AUDIO = auto()
    TRANSCRIPTION = auto()


class StreamEventType(StrEnum):
    MESSAGE_START = auto()
    MESSAGE_DELTA = auto()
    MESSAGE_STOP = auto()
    CONTENT_BLOCK_START = auto()
    CONTENT_BLOCK_DELTA = auto()
    CONTENT_BLOCK_STOP = auto()
    APPROXIMATE_COST = auto()
    MODEL_ERROR = auto()


class DeltaType(StrEnum):
    TEXT_DELTA = auto()
    INPUT_JSON_DELTA = auto()
    THINKING_DELTA = auto()
    SIGNATURE_DELTA = auto()
    GENERATED_IMAGE_DELTA = auto()
    GENERATED_VIDEO_DELTA = auto()
    GENERATED_AUDIO_DELTA = auto()
    TRANSCRIPTION_DELTA = auto()


class ContentBlockType(StrEnum):
    TEXT = auto()
    IMAGE = auto()
    FILE = auto()
    AUDIO = auto()
    TOOL_USE = auto()
    TOOL_RESULT = auto()
    THINKING = auto()
    GENERATED_IMAGE = auto()
    GENERATED_VIDEO = auto()
    GENERATED_AUDIO = auto()
    TRANSCRIPTION = auto()


class ImageSourceType(StrEnum):
    BASE64 = auto()
    URL = auto()


class FileSourceType(StrEnum):
    BASE64 = auto()


class CacheTTL(StrEnum):
    FIVE_MINUTES = auto()
    ONE_HOUR = auto()

    def to_proto(self) -> proto.CacheTTL.ValueType:
        match self:
            case CacheTTL.FIVE_MINUTES:
                return proto.CACHE_TTL_5M
            case CacheTTL.ONE_HOUR:
                return proto.CACHE_TTL_1H


class CacheControl(BaseModel):
    ttl: CacheTTL = CacheTTL.FIVE_MINUTES

    def to_proto(self) -> proto.CacheControl:
        return proto.CacheControl(ttl=self.ttl.to_proto())

    @classmethod
    def from_proto(cls, pb: proto.CacheControl) -> Self | None:
        if not pb.ByteSize():
            return None
        match pb.ttl:
            case proto.CACHE_TTL_1H:
                ttl = CacheTTL.ONE_HOUR
            case proto.CACHE_TTL_5M:
                ttl = CacheTTL.FIVE_MINUTES
            case proto.CACHE_TTL_UNSPECIFIED:
                ttl = CacheTTL.FIVE_MINUTES
            case unknown:
                raise ValueError(f"Unknown cache TTL: {unknown}")
        return cls(ttl=ttl)


class Role(StrEnum):
    USER = auto()
    ASSISTANT = auto()

    def to_proto(self) -> proto.Role.ValueType:
        match self:
            case Role.USER:
                return proto.ROLE_USER
            case Role.ASSISTANT:
                return proto.ROLE_ASSISTANT


class FinishReason(StrEnum):
    END_TURN = auto()
    MAX_TOKENS = auto()
    TOOL_USE = auto()
    STOP_SEQUENCE = auto()
    CONTENT_FILTER = auto()
    ERROR = auto()


class MessageType(StrEnum):
    SYSTEM = auto()
    USER_MESSAGE = auto()
    ASSISTANT_MESSAGE = auto()
    TOOL_USE_MESSAGE = auto()
    TOOL_RESULT_MESSAGE = auto()
    THINKING_MESSAGE = auto()


class ToolChoiceAuto(BaseModel):
    type: Literal[ToolChoiceType.AUTO] = ToolChoiceType.AUTO

    def to_proto(self) -> proto.ToolChoice.ValueType:
        return proto.TOOL_CHOICE_AUTO


class ToolChoiceAny(BaseModel):
    type: Literal[ToolChoiceType.ANY] = ToolChoiceType.ANY

    def to_proto(self) -> proto.ToolChoice.ValueType:
        return proto.TOOL_CHOICE_ANY


class ToolChoiceNone(BaseModel):
    type: Literal[ToolChoiceType.NONE] = ToolChoiceType.NONE

    def to_proto(self) -> proto.ToolChoice.ValueType:
        return proto.TOOL_CHOICE_NONE


ToolChoice: TypeAlias = ToolChoiceAuto | ToolChoiceAny | ToolChoiceNone


class Tool(BaseModel):
    """A caller-defined function tool.

    The model sees the name, description, and parameter schema, and may generate
    structured calls that the caller is responsible for executing.
    """

    type: Literal["function"] = "function"
    name: str
    description: str | None = None
    input_schema: dict[str, Any] = Field(default_factory=dict)
    strict: bool = True

    def to_proto(self) -> proto.Tool:
        return proto.Tool(
            name=self.name,
            description=self.description or "",
            parameters_json=orjson.dumps(self.input_schema).decode(),
            strict=self.strict,
            type=proto.TOOL_TYPE_FUNCTION,
        )


class OpenAIBuiltInWebSearch(BaseModel):
    type: Literal["web_search"] = "web_search"
    search_context_size: Literal["low", "medium", "high"] | None = None
    user_location: dict[str, Any] | None = None

    def to_proto(self) -> proto.Tool:
        config: dict[str, Any] = {}
        if self.search_context_size is not None:
            config["search_context_size"] = self.search_context_size
        if self.user_location is not None:
            config["user_location"] = self.user_location
        return proto.Tool(
            type=proto.TOOL_TYPE_WEB_SEARCH,
            builtin_tool_config_json=orjson.dumps(config).decode() if config else "",
        )


class OpenAIBuiltInFileSearch(BaseModel):
    type: Literal["file_search"] = "file_search"
    vector_store_ids: list[str] = Field(default_factory=list)
    max_num_results: int | None = None

    def to_proto(self) -> proto.Tool:
        config: dict[str, Any] = {}
        if self.vector_store_ids:
            config["vector_store_ids"] = self.vector_store_ids
        if self.max_num_results is not None:
            config["max_num_results"] = self.max_num_results
        return proto.Tool(
            type=proto.TOOL_TYPE_FILE_SEARCH,
            builtin_tool_config_json=orjson.dumps(config).decode() if config else "",
        )


class OpenAIBuiltInCodeInterpreter(BaseModel):
    type: Literal["code_interpreter"] = "code_interpreter"
    container: dict[str, Any] | None = None

    def to_proto(self) -> proto.Tool:
        config: dict[str, Any] = {}
        if self.container is not None:
            config["container"] = self.container
        return proto.Tool(
            type=proto.TOOL_TYPE_CODE_INTERPRETER,
            builtin_tool_config_json=orjson.dumps(config).decode() if config else "",
        )


AnyTool: TypeAlias = (
    Tool
    | OpenAIBuiltInWebSearch
    | OpenAIBuiltInFileSearch
    | OpenAIBuiltInCodeInterpreter
)


class ServiceTier(StrEnum):
    FLEX = auto()
    PRIORITY = auto()

    def to_proto(self) -> proto.ServiceTier.ValueType:
        match self:
            case ServiceTier.FLEX:
                return proto.SERVICE_TIER_FLEX
            case ServiceTier.PRIORITY:
                return proto.SERVICE_TIER_PRIORITY
            case _:
                raise ValueError(f"Unknown service tier: {self}")


class SamplingParams(BaseModel):
    max_tokens: int | None = None
    temperature: float | None = None
    top_p: float | None = None
    stop_sequences: list[str] | None = None
    verbosity: Verbosity | None = None


class ToolParams(BaseModel):
    tools: Sequence[AnyTool] | None = None
    tool_choice: ToolChoice | None = None
    parallel_tool_calls: bool = False


class ThinkingParams(BaseModel):
    reasoning_effort: ReasoningEffort | None = None
    auto_thinking: AutoThinking | None = None


class Betas(BaseModel):
    context_1m: bool = False
    tool_streaming: bool = False

    def to_proto(self) -> proto.Betas:
        return proto.Betas(
            context_1m=self.context_1m,
            tool_streaming=self.tool_streaming,
        )


class CachingParams(BaseModel):
    cache_last_message: bool = False
    prompt_cache_key: str | None = None


class AnalyticsParams(BaseModel):
    turn_id: str | None = None
    session_id: str | None = None
    skip_pii: bool = False
    user_id: str | None = None
    metadata: dict[str, Any] | None = None
    dd_logging_vars: dict[str, str] | None = None

    @model_validator(mode="after")
    def _validate_uuid_fields(self) -> Self:
        for field_name, value in {
            proto.AnalyticsParams.DESCRIPTOR.fields_by_name[
                "session_id"
            ].name: self.session_id,
            proto.AnalyticsParams.DESCRIPTOR.fields_by_name[
                "turn_id"
            ].name: self.turn_id,
        }.items():
            if value is not None:
                try:
                    uuid_mod.UUID(value)
                except ValueError:
                    raise ValueError(
                        f"{field_name} must be a valid UUID, got {value!r}. "
                        f"Use uuid7() for random IDs or uuid.uuid5() for deterministic IDs."
                    ) from None
        return self

    def to_proto(self) -> proto.AnalyticsParams:
        params = proto.AnalyticsParams(
            turn_id=self.turn_id or "",
            session_id=self.session_id or "",
            user_id=self.user_id or "",
            skip_pii=self.skip_pii,
        )
        if self.metadata:
            params.metadata.update(self.metadata)
        if self.dd_logging_vars:
            params.dd_logging_vars.update(self.dd_logging_vars)
        return params


class ResponseFormat(BaseModel):
    name: str
    schema_: dict[str, Any] = Field(alias="schema")

    def to_proto(self) -> proto.ResponseFormat:
        return proto.ResponseFormat(
            name=self.name,
            schema_json=orjson.dumps(self.schema_).decode(),
        )


class StructuredOutputParams(BaseModel):
    response_format: ResponseFormat


class Modality(StrEnum):
    TEXT = auto()
    IMAGE = auto()
    VIDEO = auto()
    AUDIO = auto()

    @classmethod
    def from_proto(cls, value: proto.Modality.ValueType) -> Self:
        match value:
            case proto.MODALITY_TEXT:
                return cls.TEXT
            case proto.MODALITY_IMAGE:
                return cls.IMAGE
            case proto.MODALITY_VIDEO:
                return cls.VIDEO
            case proto.MODALITY_AUDIO:
                return cls.AUDIO
            case _:
                return cls.TEXT

    def to_proto(self) -> proto.Modality.ValueType:
        match self:
            case Modality.TEXT:
                return proto.MODALITY_TEXT
            case Modality.IMAGE:
                return proto.MODALITY_IMAGE
            case Modality.VIDEO:
                return proto.MODALITY_VIDEO
            case Modality.AUDIO:
                return proto.MODALITY_AUDIO


class TokenUsage(BaseModel):
    uncached_input_tokens: int = 0
    cached_input_tokens: int = 0
    cache_write_tokens: int = 0
    cache_write_1h_tokens: int = 0
    output_tokens: int = 0
    reasoning_tokens: int = 0
    modality: Modality = Modality.TEXT

    @property
    def total_input_tokens(self) -> int:
        return (
            self.uncached_input_tokens
            + self.cached_input_tokens
            + self.cache_write_tokens
            + self.cache_write_1h_tokens
        )


class BaseBlockEvent(BaseModel):
    partial: bool = False


class TextBlockEvent(BaseBlockEvent):
    type: Literal[ContentBlockEventType.TEXT] = ContentBlockEventType.TEXT
    text: str = ""

    def to_block(self) -> "TextBlock":
        return TextBlock(type=ContentBlockType.TEXT, text=self.text)


class ToolUseBlockEvent(BaseBlockEvent):
    type: Literal[ContentBlockEventType.TOOL_USE] = ContentBlockEventType.TOOL_USE
    id: str = ""
    name: str = ""
    input: str = "{}"

    def to_block(self) -> "ToolUseBlock":
        return ToolUseBlock(
            type=ContentBlockType.TOOL_USE,
            id=self.id,
            name=self.name,
            input=self.input,
        )


class ThinkingBlockEvent(BaseBlockEvent):
    type: Literal[ContentBlockEventType.THINKING] = ContentBlockEventType.THINKING
    thinking: str = ""
    signature: str = ""
    endpoint_signature: str = ""
    reasoning_item_id: str = ""

    def to_block(self) -> "ThinkingBlock":
        return ThinkingBlock(
            type=ContentBlockType.THINKING,
            thinking=self.thinking,
            signature=self.signature,
            endpoint_signature=self.endpoint_signature,
            reasoning_item_id=self.reasoning_item_id,
        )


class GeneratedImageBlockEvent(BaseBlockEvent):
    type: Literal[ContentBlockEventType.GENERATED_IMAGE] = (
        ContentBlockEventType.GENERATED_IMAGE
    )
    index: int = 0
    b64_data: str = ""
    media_type: str = "image/png"
    revised_prompt: str = ""

    def to_block(self) -> "GeneratedImageOutputBlock":
        return GeneratedImageOutputBlock(
            type=ContentBlockType.GENERATED_IMAGE,
            index=self.index,
            b64_data=self.b64_data,
            media_type=self.media_type,
            revised_prompt=self.revised_prompt,
        )


class GeneratedVideoBlockEvent(BaseBlockEvent):
    type: Literal[ContentBlockEventType.GENERATED_VIDEO] = (
        ContentBlockEventType.GENERATED_VIDEO
    )
    index: int = 0
    b64_data: str = ""
    media_type: str = "video/mp4"

    def to_block(self) -> "GeneratedVideoOutputBlock":
        return GeneratedVideoOutputBlock(
            type=ContentBlockType.GENERATED_VIDEO,
            index=self.index,
            b64_data=self.b64_data,
            media_type=self.media_type,
        )


class GeneratedAudioBlockEvent(BaseBlockEvent):
    type: Literal[ContentBlockEventType.GENERATED_AUDIO] = (
        ContentBlockEventType.GENERATED_AUDIO
    )
    index: int = 0
    b64_data: str = ""
    media_type: str = "audio/mpeg"

    def to_block(self) -> "GeneratedAudioOutputBlock":
        return GeneratedAudioOutputBlock(
            type=ContentBlockType.GENERATED_AUDIO,
            index=self.index,
            b64_data=self.b64_data,
            media_type=self.media_type,
        )


class TranscriptionWord(BaseModel):
    text: str = ""
    start: float = 0.0
    end: float = 0.0
    speaker_id: str = ""


class TranscriptionBlockEvent(BaseBlockEvent):
    type: Literal[ContentBlockEventType.TRANSCRIPTION] = (
        ContentBlockEventType.TRANSCRIPTION
    )
    text: str = ""
    words: list[TranscriptionWord] = Field(default_factory=list)
    language_code: str = ""

    def to_block(self) -> "TranscriptionOutputBlock":
        return TranscriptionOutputBlock(
            type=ContentBlockType.TRANSCRIPTION,
            text=self.text,
            words=self.words,
            language_code=self.language_code,
        )


ContentBlockEvent: TypeAlias = Annotated[
    TextBlockEvent
    | ToolUseBlockEvent
    | ThinkingBlockEvent
    | GeneratedImageBlockEvent
    | GeneratedVideoBlockEvent
    | GeneratedAudioBlockEvent
    | TranscriptionBlockEvent,
    Discriminator("type"),
]


class ApproximateCostEvent(BaseModel):
    type: Literal[StreamEventType.APPROXIMATE_COST] = StreamEventType.APPROXIMATE_COST
    total_cost: float = 0.0
    uncached_input_cost: float = 0.0
    cached_input_cost: float = 0.0
    cache_write_cost: float = 0.0
    output_cost: float = 0.0
    image_cost: float | None = None
    video_cost: float | None = None
    audio_cost: float | None = None
    total_undiscounted_cost: float = 0.0


class ModelErrorDebugInfoEvent(BaseModel):
    model_id: str = ""
    api_base: str = ""
    error_type: str = ""
    message: str = ""


class ModelErrorEvent(BaseModel):
    type: Literal[StreamEventType.MODEL_ERROR] = StreamEventType.MODEL_ERROR
    debug_info: ModelErrorDebugInfoEvent = Field(
        default_factory=ModelErrorDebugInfoEvent
    )


class MessageEvent(BaseModel):
    role: Literal[Role.ASSISTANT] = Role.ASSISTANT
    content: list[ContentBlockEvent] = Field(default_factory=list)
    cache_signature: str | None = None
    conversation_id: str | None = None
    model: str | None = None
    model_id: str | None = None
    usage: TokenUsage = Field(default_factory=TokenUsage)
    approximate_cost: ApproximateCostEvent | None = None
    finish_reason: FinishReason | None = None

    @property
    def text(self) -> str:
        return "".join(
            b.text for b in self.content if b.type == ContentBlockEventType.TEXT
        )

    @property
    def tools(self) -> list[ToolUseBlockEvent]:
        return [b for b in self.content if b.type == ContentBlockEventType.TOOL_USE]

    @property
    def images(self) -> list[GeneratedImageBlockEvent]:
        return [
            b for b in self.content if b.type == ContentBlockEventType.GENERATED_IMAGE
        ]

    @property
    def videos(self) -> list[GeneratedVideoBlockEvent]:
        return [
            b for b in self.content if b.type == ContentBlockEventType.GENERATED_VIDEO
        ]

    @property
    def audios(self) -> list[GeneratedAudioBlockEvent]:
        return [
            b for b in self.content if b.type == ContentBlockEventType.GENERATED_AUDIO
        ]

    @property
    def transcriptions(self) -> list[TranscriptionBlockEvent]:
        return [
            b for b in self.content if b.type == ContentBlockEventType.TRANSCRIPTION
        ]

    def to_message(self) -> "Message":
        content_blocks: list[ContentBlock] = [
            block.to_block() for block in self.content
        ]
        return Message(role=self.role, content=content_blocks)


class MessageStartEvent(BaseModel):
    type: Literal[StreamEventType.MESSAGE_START] = StreamEventType.MESSAGE_START
    message: MessageEvent = Field(default_factory=MessageEvent)


class ContentBlockStartEvent(BaseModel):
    type: Literal[StreamEventType.CONTENT_BLOCK_START] = (
        StreamEventType.CONTENT_BLOCK_START
    )
    content_block: ContentBlockEvent = Field(default_factory=TextBlockEvent)


class TextDelta(BaseModel):
    type: Literal[DeltaType.TEXT_DELTA] = DeltaType.TEXT_DELTA
    text: str = ""


class InputJsonDelta(BaseModel):
    type: Literal[DeltaType.INPUT_JSON_DELTA] = DeltaType.INPUT_JSON_DELTA
    partial_json: str = ""
    parsed_json: dict[str, object] | None = None


class ThinkingDelta(BaseModel):
    type: Literal[DeltaType.THINKING_DELTA] = DeltaType.THINKING_DELTA
    thinking: str = ""


class SignatureDelta(BaseModel):
    type: Literal[DeltaType.SIGNATURE_DELTA] = DeltaType.SIGNATURE_DELTA
    signature: str = ""


class GeneratedImageDelta(BaseModel):
    type: Literal[DeltaType.GENERATED_IMAGE_DELTA] = DeltaType.GENERATED_IMAGE_DELTA
    b64_chunk: str = ""


class GeneratedVideoDelta(BaseModel):
    type: Literal[DeltaType.GENERATED_VIDEO_DELTA] = DeltaType.GENERATED_VIDEO_DELTA
    b64_chunk: str = ""


class GeneratedAudioDelta(BaseModel):
    type: Literal[DeltaType.GENERATED_AUDIO_DELTA] = DeltaType.GENERATED_AUDIO_DELTA
    b64_chunk: str = ""


class TranscriptionDelta(BaseModel):
    type: Literal[DeltaType.TRANSCRIPTION_DELTA] = DeltaType.TRANSCRIPTION_DELTA
    text: str = ""
    words: list[TranscriptionWord] = Field(default_factory=list)
    language_code: str = ""


Delta: TypeAlias = Annotated[
    TextDelta
    | InputJsonDelta
    | ThinkingDelta
    | SignatureDelta
    | GeneratedImageDelta
    | GeneratedVideoDelta
    | GeneratedAudioDelta
    | TranscriptionDelta,
    Discriminator("type"),
]


class ContentBlockDeltaEvent(BaseModel):
    type: Literal[StreamEventType.CONTENT_BLOCK_DELTA] = (
        StreamEventType.CONTENT_BLOCK_DELTA
    )
    delta: Delta = Field(default_factory=TextDelta)


class ContentBlockStopEvent(BaseModel):
    type: Literal[StreamEventType.CONTENT_BLOCK_STOP] = (
        StreamEventType.CONTENT_BLOCK_STOP
    )


class MessageDeltaUsage(BaseModel):
    uncached_input_tokens: int = 0
    cached_input_tokens: int = 0
    cache_write_tokens: int = 0
    output_tokens: int = 0
    reasoning_tokens: int = 0


class MessageDeltaData(BaseModel):
    pass


class MessageDeltaEvent(BaseModel):
    type: Literal[StreamEventType.MESSAGE_DELTA] = StreamEventType.MESSAGE_DELTA
    delta: MessageDeltaData = Field(default_factory=MessageDeltaData)
    usage: MessageDeltaUsage = Field(default_factory=MessageDeltaUsage)


class MessageStopEvent(BaseModel):
    type: Literal[StreamEventType.MESSAGE_STOP] = StreamEventType.MESSAGE_STOP
    message: MessageEvent = Field(default_factory=MessageEvent)


StreamEvent: TypeAlias = Annotated[
    MessageStartEvent
    | ContentBlockStartEvent
    | ContentBlockDeltaEvent
    | ContentBlockStopEvent
    | MessageDeltaEvent
    | MessageStopEvent
    | ApproximateCostEvent
    | ModelErrorEvent,
    Discriminator("type"),
]


class BlockBase(BaseModel):
    cache_control: CacheControl | None = None

    def cache(self, ttl: CacheTTL = CacheTTL.FIVE_MINUTES) -> None:
        self.cache_control = CacheControl(ttl=ttl)


class TextBlock(BlockBase):
    type: Literal[ContentBlockType.TEXT] = ContentBlockType.TEXT
    text: str = ""

    def to_proto(self) -> proto.ContentBlock:
        return proto.ContentBlock(
            text=proto.TextBlock(
                text=self.text,
                cache_control=self.cache_control.to_proto()
                if self.cache_control
                else None,
            )
        )

    @classmethod
    def from_proto(cls, pb: proto.TextBlock) -> Self:
        return cls(
            text=pb.text, cache_control=CacheControl.from_proto(pb.cache_control)
        )


def _image_media_type_from_proto(pb: proto.ImageMediaType.ValueType) -> str:
    match pb:
        case proto.IMAGE_MEDIA_TYPE_JPEG:
            return "image/jpeg"
        case proto.IMAGE_MEDIA_TYPE_PNG:
            return "image/png"
        case proto.IMAGE_MEDIA_TYPE_GIF:
            return "image/gif"
        case proto.IMAGE_MEDIA_TYPE_WEBP:
            return "image/webp"
        case proto.IMAGE_MEDIA_TYPE_UNSPECIFIED:
            return "image/jpeg"
        case _:
            raise ValueError(f"Unknown image media type: {pb}")


def _video_media_type_from_proto(pb: proto.VideoMediaType.ValueType) -> str:
    match pb:
        case proto.VIDEO_MEDIA_TYPE_MP4:
            return "video/mp4"
        case proto.VIDEO_MEDIA_TYPE_MPEG:
            return "video/mpeg"
        case proto.VIDEO_MEDIA_TYPE_MOV:
            return "video/mov"
        case proto.VIDEO_MEDIA_TYPE_WEBM:
            return "video/webm"
        case proto.VIDEO_MEDIA_TYPE_UNSPECIFIED:
            return "video/mp4"
        case _:
            raise ValueError(f"Unknown video media type: {pb}")


def _audio_media_type_from_proto(pb: proto.AudioMediaType.ValueType) -> str:
    match pb:
        case proto.AUDIO_MEDIA_TYPE_MP3:
            return "audio/mpeg"
        case proto.AUDIO_MEDIA_TYPE_WAV:
            return "audio/wav"
        case proto.AUDIO_MEDIA_TYPE_OGG:
            return "audio/ogg"
        case proto.AUDIO_MEDIA_TYPE_AAC:
            return "audio/aac"
        case proto.AUDIO_MEDIA_TYPE_FLAC:
            return "audio/flac"
        case proto.AUDIO_MEDIA_TYPE_MP4:
            return "audio/mp4"
        case proto.AUDIO_MEDIA_TYPE_WEBM:
            return "audio/webm"
        case proto.AUDIO_MEDIA_TYPE_UNSPECIFIED:
            return "audio/mpeg"
        case _:
            raise ValueError(f"Unknown audio media type: {pb}")


class ImageSource(BaseModel):
    type: Literal[ImageSourceType.BASE64, ImageSourceType.URL] = ImageSourceType.BASE64
    media_type: str = "image/jpeg"
    data: str = ""

    def _media_type_to_proto(self) -> proto.ImageMediaType.ValueType:
        match self.media_type:
            case "image/jpeg":
                return proto.IMAGE_MEDIA_TYPE_JPEG
            case "image/png":
                return proto.IMAGE_MEDIA_TYPE_PNG
            case "image/gif":
                return proto.IMAGE_MEDIA_TYPE_GIF
            case "image/webp":
                return proto.IMAGE_MEDIA_TYPE_WEBP
            case _:
                return proto.IMAGE_MEDIA_TYPE_UNSPECIFIED


class ImageBlock(BlockBase):
    type: Literal[ContentBlockType.IMAGE] = ContentBlockType.IMAGE
    source: ImageSource = Field(default_factory=ImageSource)

    def to_proto(self) -> proto.ContentBlock:
        cache_control = self.cache_control.to_proto() if self.cache_control else None
        match self.source.type:
            case ImageSourceType.URL:
                image = proto.ImageBlock(
                    url=proto.URLImageSource(url=self.source.data),
                    cache_control=cache_control,
                )
            case _:
                image = proto.ImageBlock(
                    base64=proto.Base64ImageSource(
                        media_type=self.source._media_type_to_proto(),
                        data=self.source.data,
                    ),
                    cache_control=cache_control,
                )
        return proto.ContentBlock(image=image)

    @classmethod
    def from_proto(cls, pb: proto.ImageBlock) -> Self:
        match pb.WhichOneof("source"):
            case "url":
                source = ImageSource(type=ImageSourceType.URL, data=pb.url.url)
            case "base64":
                source = ImageSource(
                    type=ImageSourceType.BASE64,
                    media_type=_image_media_type_from_proto(pb.base64.media_type),
                    data=pb.base64.data,
                )
            case unknown:
                raise ValueError(f"Unknown ImageBlock source type: {unknown}")
        return cls(
            source=source, cache_control=CacheControl.from_proto(pb.cache_control)
        )


class FileSource(BaseModel):
    type: Literal[FileSourceType.BASE64] = FileSourceType.BASE64
    media_type: str = "application/pdf"
    data: str = ""

    def _media_type_to_proto(self) -> proto.FileMediaType.ValueType:
        match self.media_type:
            case "application/pdf":
                return proto.FILE_MEDIA_TYPE_PDF
            case _:
                return proto.FILE_MEDIA_TYPE_UNSPECIFIED


class FileBlock(BlockBase):
    type: Literal[ContentBlockType.FILE] = ContentBlockType.FILE
    source: FileSource = Field(default_factory=FileSource)

    def to_proto(self) -> proto.ContentBlock:
        return proto.ContentBlock(
            file=proto.FileBlock(
                source=proto.Base64FileSource(
                    media_type=self.source._media_type_to_proto(),
                    data=self.source.data,
                ),
                cache_control=self.cache_control.to_proto()
                if self.cache_control
                else None,
            )
        )

    @classmethod
    def from_proto(cls, pb: proto.FileBlock) -> Self:
        source = FileSource(
            type=FileSourceType.BASE64,
            media_type="application/pdf",
            data=pb.source.data,
        )
        return cls(
            source=source, cache_control=CacheControl.from_proto(pb.cache_control)
        )


ToolResultContent = TextBlock | ImageBlock


class ToolResultBlock(BlockBase):
    type: Literal[ContentBlockType.TOOL_RESULT] = ContentBlockType.TOOL_RESULT
    tool_use_id: str = ""
    content: list[ToolResultContent] = Field(default_factory=list)
    is_error: bool = False

    @property
    def text(self) -> str:
        return "\n".join(
            b.text for b in self.content if b.type == ContentBlockType.TEXT
        )

    def to_proto(self) -> proto.ContentBlock:
        content: list[proto.ToolResultContentBlock] = []
        for block in self.content:
            match block.type:
                case ContentBlockType.TEXT:
                    content.append(
                        proto.ToolResultContentBlock(
                            text=proto.TextBlock(
                                text=block.text,
                                cache_control=block.cache_control.to_proto()
                                if block.cache_control
                                else None,
                            )
                        )
                    )
                case ContentBlockType.IMAGE:
                    image_block = block.to_proto().image
                    content.append(proto.ToolResultContentBlock(image=image_block))

        return proto.ContentBlock(
            tool_result=proto.ToolResultBlock(
                tool_use_id=self.tool_use_id,
                content=content,
                cache_control=self.cache_control.to_proto()
                if self.cache_control
                else None,
                is_error=self.is_error,
            )
        )

    @classmethod
    def from_proto(cls, pb: proto.ToolResultBlock) -> Self:
        content: list[ToolResultContent] = []
        for block in pb.content:
            match block.WhichOneof("content"):
                case "text":
                    content.append(TextBlock.from_proto(block.text))
                case "image":
                    content.append(ImageBlock.from_proto(block.image))
                case unknown:
                    raise ValueError(f"Unknown tool result content type: {unknown}")
        return cls(
            tool_use_id=pb.tool_use_id,
            content=content,
            is_error=pb.is_error,
            cache_control=CacheControl.from_proto(pb.cache_control),
        )


class ToolUseBlock(BlockBase):
    type: Literal[ContentBlockType.TOOL_USE] = ContentBlockType.TOOL_USE
    id: str = ""
    name: str = ""
    input: str = "{}"

    def to_proto(self) -> proto.ContentBlock:
        return proto.ContentBlock(
            tool_use=proto.ToolUseBlock(
                tool_use_id=self.id,
                name=self.name,
                input_json=self.input,
                cache_control=self.cache_control.to_proto()
                if self.cache_control
                else None,
            )
        )

    @classmethod
    def from_proto(cls, pb: proto.ToolUseBlock) -> Self:
        return cls(
            id=pb.tool_use_id,
            name=pb.name,
            input=pb.input_json,
            cache_control=CacheControl.from_proto(pb.cache_control),
        )


class ThinkingBlock(BlockBase):
    type: Literal[ContentBlockType.THINKING] = ContentBlockType.THINKING
    thinking: str = ""
    signature: str = ""
    reasoning_item_id: str = ""
    endpoint_signature: str = ""

    def to_proto(self) -> proto.ContentBlock:
        return proto.ContentBlock(
            thinking=proto.ThinkingBlock(
                reasoning_content=self.thinking,
                reasoning_signature=self.signature,
                reasoning_item_id=self.reasoning_item_id,
                endpoint_signature=self.endpoint_signature,
                cache_control=self.cache_control.to_proto()
                if self.cache_control
                else None,
            )
        )

    @classmethod
    def from_proto(cls, pb: proto.ThinkingBlock) -> Self:
        return cls(
            thinking=pb.reasoning_content,
            signature=pb.reasoning_signature,
            reasoning_item_id=pb.reasoning_item_id,
            endpoint_signature=pb.endpoint_signature,
            cache_control=CacheControl.from_proto(pb.cache_control),
        )


class GeneratedImageOutputBlock(BlockBase):
    type: Literal[ContentBlockType.GENERATED_IMAGE] = ContentBlockType.GENERATED_IMAGE
    index: int = 0
    b64_data: str = ""
    media_type: str = "image/png"
    revised_prompt: str = ""

    def to_proto(self) -> proto.ContentBlock:
        media_type_proto = self._media_type_to_proto()
        return proto.ContentBlock(
            generated_image=proto.GeneratedImageBlock(
                index=self.index,
                b64_data=self.b64_data,
                media_type=media_type_proto,
                revised_prompt=self.revised_prompt,
            )
        )

    def _media_type_to_proto(self) -> proto.ImageMediaType.ValueType:
        match self.media_type:
            case "image/jpeg":
                return proto.IMAGE_MEDIA_TYPE_JPEG
            case "image/png":
                return proto.IMAGE_MEDIA_TYPE_PNG
            case "image/webp":
                return proto.IMAGE_MEDIA_TYPE_WEBP
            case _:
                return proto.IMAGE_MEDIA_TYPE_PNG

    @classmethod
    def from_proto(cls, pb: proto.GeneratedImageBlock) -> Self:
        return cls(
            index=pb.index,
            b64_data=pb.b64_data,
            media_type=_image_media_type_from_proto(pb.media_type),
            revised_prompt=pb.revised_prompt,
        )


class GeneratedVideoOutputBlock(BlockBase):
    type: Literal[ContentBlockType.GENERATED_VIDEO] = ContentBlockType.GENERATED_VIDEO
    index: int = 0
    b64_data: str = ""
    media_type: str = "video/mp4"

    def to_proto(self) -> proto.ContentBlock:
        media_type_proto = self._media_type_to_proto()
        return proto.ContentBlock(
            generated_video=proto.GeneratedVideoBlock(
                index=self.index,
                b64_data=self.b64_data,
                media_type=media_type_proto,
            )
        )

    def _media_type_to_proto(self) -> proto.VideoMediaType.ValueType:
        match self.media_type:
            case "video/mp4":
                return proto.VIDEO_MEDIA_TYPE_MP4
            case "video/mpeg":
                return proto.VIDEO_MEDIA_TYPE_MPEG
            case "video/mov":
                return proto.VIDEO_MEDIA_TYPE_MOV
            case "video/webm":
                return proto.VIDEO_MEDIA_TYPE_WEBM
            case _:
                return proto.VIDEO_MEDIA_TYPE_MP4

    @classmethod
    def from_proto(cls, pb: proto.GeneratedVideoBlock) -> Self:
        return cls(
            index=pb.index,
            b64_data=pb.b64_data,
            media_type=_video_media_type_from_proto(pb.media_type),
        )


class GeneratedAudioOutputBlock(BlockBase):
    type: Literal[ContentBlockType.GENERATED_AUDIO] = ContentBlockType.GENERATED_AUDIO
    index: int = 0
    b64_data: str = ""
    media_type: str = "audio/mpeg"

    def to_proto(self) -> proto.ContentBlock:
        media_type_proto = self._media_type_to_proto()
        return proto.ContentBlock(
            generated_audio=proto.GeneratedAudioBlock(
                index=self.index,
                b64_data=self.b64_data,
                media_type=media_type_proto,
            )
        )

    def _media_type_to_proto(self) -> proto.AudioMediaType.ValueType:
        match self.media_type:
            case "audio/mpeg":
                return proto.AUDIO_MEDIA_TYPE_MP3
            case "audio/wav":
                return proto.AUDIO_MEDIA_TYPE_WAV
            case "audio/ogg":
                return proto.AUDIO_MEDIA_TYPE_OGG
            case "audio/aac":
                return proto.AUDIO_MEDIA_TYPE_AAC
            case "audio/flac":
                return proto.AUDIO_MEDIA_TYPE_FLAC
            case "audio/mp4":
                return proto.AUDIO_MEDIA_TYPE_MP4
            case "audio/webm":
                return proto.AUDIO_MEDIA_TYPE_WEBM
            case _:
                return proto.AUDIO_MEDIA_TYPE_MP3

    @classmethod
    def from_proto(cls, pb: proto.GeneratedAudioBlock) -> Self:
        return cls(
            index=pb.index,
            b64_data=pb.b64_data,
            media_type=_audio_media_type_from_proto(pb.media_type),
        )


class AudioSource(BaseModel):
    media_type: str = "audio/mpeg"
    data: str = ""

    def _media_type_to_proto(self) -> proto.AudioMediaType.ValueType:
        match self.media_type:
            case "audio/mpeg":
                return proto.AUDIO_MEDIA_TYPE_MP3
            case "audio/wav":
                return proto.AUDIO_MEDIA_TYPE_WAV
            case "audio/ogg":
                return proto.AUDIO_MEDIA_TYPE_OGG
            case "audio/aac":
                return proto.AUDIO_MEDIA_TYPE_AAC
            case "audio/flac":
                return proto.AUDIO_MEDIA_TYPE_FLAC
            case "audio/mp4":
                return proto.AUDIO_MEDIA_TYPE_MP4
            case "audio/webm":
                return proto.AUDIO_MEDIA_TYPE_WEBM
            case _:
                return proto.AUDIO_MEDIA_TYPE_MP3


class AudioBlock(BlockBase):
    type: Literal[ContentBlockType.AUDIO] = ContentBlockType.AUDIO
    source: AudioSource = Field(default_factory=AudioSource)

    def to_proto(self) -> proto.ContentBlock:
        return proto.ContentBlock(
            audio=proto.AudioBlock(
                source=proto.Base64AudioSource(
                    media_type=self.source._media_type_to_proto(),
                    data=self.source.data,
                ),
                cache_control=self.cache_control.to_proto()
                if self.cache_control
                else None,
            )
        )

    @classmethod
    def from_proto(cls, pb: proto.AudioBlock) -> Self:
        source = AudioSource(
            media_type=_audio_media_type_from_proto(pb.source.media_type),
            data=pb.source.data,
        )
        return cls(
            source=source, cache_control=CacheControl.from_proto(pb.cache_control)
        )


class TranscriptionOutputBlock(BlockBase):
    type: Literal[ContentBlockType.TRANSCRIPTION] = ContentBlockType.TRANSCRIPTION
    text: str = ""
    words: list[TranscriptionWord] = Field(default_factory=list)
    language_code: str = ""

    def to_proto(self) -> proto.ContentBlock:
        return proto.ContentBlock(
            transcription=proto.TranscriptionBlock(
                text=self.text,
                words=[
                    proto.TranscriptionWord(
                        text=w.text,
                        start=w.start,
                        end=w.end,
                        speaker_id=w.speaker_id,
                    )
                    for w in self.words
                ],
                language_code=self.language_code,
            )
        )

    @classmethod
    def from_proto(cls, pb: proto.TranscriptionBlock) -> Self:
        return cls(
            text=pb.text,
            words=[
                TranscriptionWord(
                    text=w.text,
                    start=w.start,
                    end=w.end,
                    speaker_id=w.speaker_id,
                )
                for w in pb.words
            ],
            language_code=pb.language_code,
        )


UserContentBlock: TypeAlias = (
    TextBlock | ImageBlock | FileBlock | AudioBlock | ToolResultBlock
)
AssistantContentBlock: TypeAlias = (
    TextBlock
    | ToolUseBlock
    | ThinkingBlock
    | GeneratedImageOutputBlock
    | GeneratedVideoOutputBlock
    | GeneratedAudioOutputBlock
    | TranscriptionOutputBlock
)

ContentBlock: TypeAlias = Annotated[
    TextBlock
    | ImageBlock
    | FileBlock
    | AudioBlock
    | ToolResultBlock
    | ToolUseBlock
    | ThinkingBlock
    | GeneratedImageOutputBlock
    | GeneratedVideoOutputBlock
    | GeneratedAudioOutputBlock
    | TranscriptionOutputBlock,
    Discriminator("type"),
]


class Message(BaseModel):
    role: Role = Role.USER
    content: list[ContentBlock] = Field(default_factory=list)
    id: str = Field(default_factory=lambda: uuid7().hex)
    phase: str | None = None

    @property
    def text(self) -> str:
        return "".join(b.text for b in self.content if b.type == ContentBlockType.TEXT)

    @property
    def tool_results(self) -> list[ToolResultBlock]:
        return [b for b in self.content if b.type == ContentBlockType.TOOL_RESULT]

    @property
    def tool_uses(self) -> list[ToolUseBlock]:
        return [b for b in self.content if b.type == ContentBlockType.TOOL_USE]

    def to_proto(self) -> proto.Message:
        return proto.Message(
            role=self.role.to_proto(),
            content=[block.to_proto() for block in self.content],
            id=self.id,
            phase=self.phase,
        )

    @staticmethod
    def _content_block_from_proto(pb: proto.ContentBlock) -> "ContentBlock":
        field = pb.WhichOneof("block")
        match field:
            case "text":
                return TextBlock.from_proto(pb.text)
            case "image":
                return ImageBlock.from_proto(pb.image)
            case "file":
                return FileBlock.from_proto(pb.file)
            case "tool_use":
                return ToolUseBlock.from_proto(pb.tool_use)
            case "tool_result":
                return ToolResultBlock.from_proto(pb.tool_result)
            case "thinking":
                return ThinkingBlock.from_proto(pb.thinking)
            case "generated_image":
                return GeneratedImageOutputBlock.from_proto(pb.generated_image)
            case "generated_video":
                return GeneratedVideoOutputBlock.from_proto(pb.generated_video)
            case "generated_audio":
                return GeneratedAudioOutputBlock.from_proto(pb.generated_audio)
            case "audio":
                return AudioBlock.from_proto(pb.audio)
            case "transcription":
                return TranscriptionOutputBlock.from_proto(pb.transcription)
            case unknown:
                raise ValueError(f"Unknown content block type: {unknown}")

    @classmethod
    def from_proto(cls, pb: proto.Message) -> Self:
        match pb.role:
            case proto.ROLE_USER:
                role = Role.USER
            case proto.ROLE_ASSISTANT:
                role = Role.ASSISTANT
            case proto.ROLE_UNSPECIFIED:
                role = Role.USER
            case unknown:
                raise ValueError(f"Unknown role: {unknown}")
        content = [cls._content_block_from_proto(b) for b in pb.content]
        return cls(
            id=pb.id or uuid7().hex,
            role=role,
            content=content,
            phase=pb.phase or None,
        )


class Conversation(BaseModel):
    messages: list[Message] = Field(default_factory=list)
    system: list[TextBlock] | None = None
    cache_signature: str | None = None
    id: str | None = None

    def to_proto(self) -> proto.Conversation:
        system = (
            [
                proto.TextBlock(
                    text=b.text,
                    cache_control=b.cache_control.to_proto()
                    if b.cache_control
                    else None,
                )
                for b in self.system
            ]
            if self.system
            else []
        )
        return proto.Conversation(
            system=system,
            messages=[msg.to_proto() for msg in self.messages],
            cache_signature=self.cache_signature,
            id=self.id,
        )

    @classmethod
    def from_proto(cls, proto_conv: proto.Conversation) -> Self:
        system = (
            [TextBlock.from_proto(b) for b in proto_conv.system]
            if proto_conv.system
            else None
        )
        messages = [Message.from_proto(m) for m in proto_conv.messages]
        return cls(
            messages=messages,
            system=system,
            cache_signature=proto_conv.cache_signature or None,
            id=proto_conv.id or None,
        )

    def system_text(self) -> str | None:
        if not self.system:
            return None
        return "\n".join(block.text for block in self.system)

    def set_system(self, text: str | TextBlock | list[TextBlock] | None) -> None:
        match text:
            case None:
                self.system = None
            case str():
                self.system = [TextBlock(type=ContentBlockType.TEXT, text=text)]
            case list():
                self.system = text
            case _:
                self.system = [text]

    def _add_block(
        self,
        block: list[ContentBlock] | ContentBlock | str,
        role: Role,
        new_message: bool,
    ) -> None:
        content_blocks: list[ContentBlock]
        match block:
            case str():
                content_blocks = [TextBlock(type=ContentBlockType.TEXT, text=block)]
            case list():
                content_blocks = block
            case _:
                content_blocks = [block]
        if new_message or not self.messages or self.messages[-1].role != role:
            self.messages.append(Message(role=role, content=[]))
        self.messages[-1].content.extend(content_blocks)

    def add_user(
        self,
        content: UserContentBlock | list[UserContentBlock] | str,
        new_message: bool = False,
    ) -> None:
        self._add_block(content, Role.USER, new_message)  # type: ignore[arg-type]

    def add_assistant(
        self,
        content: AssistantContentBlock | list[AssistantContentBlock] | str,
        new_message: bool = False,
    ) -> None:
        self._add_block(content, Role.ASSISTANT, new_message)  # type: ignore[arg-type]

    def set_single_audio_prompt(self, prompt: str) -> None:
        """Reset conversation to a single user message for audio/TTS generation."""
        self.system = None
        self.messages = [
            Message(
                role=Role.USER,
                content=[TextBlock(type=ContentBlockType.TEXT, text=prompt)],
            )
        ]

    def set_single_audio_input(
        self, b64_data: str, media_type: str = "audio/mpeg"
    ) -> None:
        """Reset conversation to a single user message with an AudioBlock for STT."""
        self.system = None
        self.messages = [
            Message(
                role=Role.USER,
                content=[
                    AudioBlock(
                        type=ContentBlockType.AUDIO,
                        source=AudioSource(media_type=media_type, data=b64_data),
                    )
                ],
            )
        ]

    def set_dialogue_prompt(self, inputs: list[DialogueInput]) -> None:
        self.system = None
        prompt = "\n".join(f"{inp.voice}: {inp.text}" for inp in inputs)
        self.messages = [
            Message(
                role=Role.USER,
                content=[TextBlock(type=ContentBlockType.TEXT, text=prompt)],
            )
        ]

    def add_message(self, message: Message | MessageEvent) -> None:
        match message:
            case MessageEvent():
                self.messages.append(message.to_message())
                if message.cache_signature:
                    self.cache_signature = message.cache_signature
                if message.conversation_id:
                    self.id = message.conversation_id
            case Message():
                self.messages.append(message)

    def cache(self, ttl: CacheTTL = CacheTTL.FIVE_MINUTES) -> ContentBlock | None:
        """Set a cache breakpoint on the end of the conversation."""
        blocks = (b for msg in reversed(self.messages) for b in reversed(msg.content))
        if block := next(blocks, None):
            block.cache(ttl)
            return block

        if self.system:
            self.system[-1].cache(ttl)
            return self.system[-1]
        return None

    @contextmanager
    def caching(self, ttl: CacheTTL = CacheTTL.FIVE_MINUTES) -> Iterator[None]:
        """
        Context manager that sets a cache breakpoint for the duration of the block, then clears it.
        Useful for not persisting cache breakpoint within the convo across multiple calls.
        """
        block = self.cache(ttl)
        try:
            yield None
        finally:
            if block:
                block.cache_control = None

    def set_single_image_prompt(self, prompt: str) -> None:
        """Reset conversation to a single user message for image generation."""
        self.messages = [
            Message(
                role=Role.USER,
                content=[TextBlock(type=ContentBlockType.TEXT, text=prompt)],
            )
        ]

    def clone(self) -> Self:
        return self.model_copy(deep=True)

    def to_proto_json(self) -> str:
        """Serialize the conversation to a JSON string using protobuf format."""
        return orjson.dumps(MessageToDict(self.to_proto())).decode()

    @classmethod
    def from_proto_json(cls, json_str: str) -> Self:
        """Deserialize a conversation from a protobuf JSON string."""
        proto_conv = ParseDict(orjson.loads(json_str), proto.Conversation())
        return cls.from_proto(proto_conv)
