#!/usr/bin/env python3
import argparse
import asyncio
import base64
import mimetypes
import sys
from pathlib import Path
from typing import cast

import orjson
from pplx.python.sdks.llm_api import (
    AutoThinking,
    Client,
    ContentBlockEventType,
    Conversation,
    DeltaType,
    FileBlock,
    FileSource,
    FileSourceType,
    Identity,
    ImageGenAspectRatio,
    LLMAPIClient,
    LLMAPIError,
    MediaGenParams,
    Omit,
    ReasoningEffort,
    ResponseFormat,
    SamplingParams,
    StreamEvent,
    StreamEventType,
    StructuredOutputParams,
    TextBlock,
    ThinkingBlock,
    ThinkingParams,
    Tool,
    ToolChoice,
    ToolChoiceAny,
    ToolChoiceAuto,
    ToolChoiceNone,
    ToolChoiceType,
    ToolParams,
    UserContentBlock,
    VideoGenDuration,
    VideoGenParams,
    omit,
)

SPINNER_FRAMES = ["-", "\\", "|", "/"]


def _load_file_as_block(file_path: Path) -> FileBlock:
    with open(file_path, "rb") as f:
        data = base64.b64encode(f.read()).decode("utf-8")

    media_type = mimetypes.guess_type(str(file_path))[0] or "application/octet-stream"
    return FileBlock(
        source=FileSource(
            type=FileSourceType.BASE64,
            media_type=media_type,
            data=data,
        )
    )


def _print_debug_request(
    model: str,
    convo: Conversation,
    max_tokens: int,
    tools: list[Tool],
    tool_choice: ToolChoice,
    parallel_tool_calls: bool,
    reasoning_effort: ReasoningEffort | None,
    auto_thinking: AutoThinking | None,
    structured_output_params: StructuredOutputParams | Omit,
) -> None:
    print(f"\n{'=' * 60}")
    print("[DEBUG] Request Parameters")
    print(f"{'=' * 60}")
    print(f"Model: {model}")
    print(f"Max Tokens: {max_tokens}")
    print(f"Tool Choice: {tool_choice}")
    print(f"Parallel Tool Calls: {parallel_tool_calls}")
    print(f"Reasoning Effort: {reasoning_effort}")
    print(f"Auto Thinking: {auto_thinking}")
    print(f"Cache Signature: {convo.cache_signature}")
    print(f"Tools: {[t.name for t in tools]}")
    if structured_output_params is not omit:
        rf = cast(StructuredOutputParams, structured_output_params).response_format
        print(f"Response Format: {rf.name}")
        print(
            f"Response Schema: {orjson.dumps(rf.schema_, option=orjson.OPT_INDENT_2).decode()}"
        )
    print(f"\nSystem: {convo.system}")
    print(f"\nConversation ({len(convo.messages)} messages):")
    for i, msg in enumerate(convo.messages):
        content_str = orjson.dumps(
            [c.model_dump() for c in msg.content], option=orjson.OPT_INDENT_2
        ).decode()
        print(f"  [{i}] {msg.role}:")
        for line in content_str.split("\n"):
            print(f"    {line}")
    print(f"{'=' * 60}\n")


def _print_debug_event(event: StreamEvent) -> None:
    print(f"\n{'=' * 60}")
    print(f"[DEBUG] Event: {event.type}")
    print(f"{'=' * 60}")
    print(orjson.dumps(event.model_dump(), option=orjson.OPT_INDENT_2).decode())


DUMMY_TOOLS = [
    Tool(
        name="get_weather",
        description="Get the current weather for a location",
        input_schema={
            "type": "object",
            "properties": {
                "location": {"type": "string"},
                "unit": {"type": "string", "enum": ["celsius", "fahrenheit"]},
            },
            "required": ["location", "unit"],
            "additionalProperties": False,
        },
    ),
    Tool(
        name="search_web",
        description="Search the web for information",
        input_schema={
            "type": "object",
            "properties": {
                "query": {"type": "string"},
                "num_results": {"type": "integer"},
            },
            "required": ["query", "num_results"],
            "additionalProperties": False,
        },
    ),
    Tool(
        name="calculate",
        description="Perform mathematical calculations",
        input_schema={
            "type": "object",
            "properties": {
                "expression": {"type": "string"},
            },
            "required": ["expression"],
            "additionalProperties": False,
        },
    ),
    Tool(
        name="get_current_time",
        description="Get the current time in a timezone",
        input_schema={
            "type": "object",
            "properties": {
                "timezone": {"type": "string"},
            },
            "required": ["timezone"],
            "additionalProperties": False,
        },
    ),
]


async def chat_loop(
    client: LLMAPIClient,
    model: str,
    identity: Identity,
    system: str,
    max_tokens: int,
    tools: list[Tool],
    tool_choice: ToolChoice,
    parallel_tool_calls: bool,
    debug: bool = False,
    reasoning_effort: ReasoningEffort | None = None,
    auto_thinking: AutoThinking | None = None,
    files: list[Path] | None = None,
    structured_output_params: StructuredOutputParams | Omit = omit,
    media_gen_params: MediaGenParams | Omit = omit,
) -> None:
    convo = Conversation()
    convo.set_system(system)

    file_blocks: list[FileBlock] = []
    if files:
        for file_path in files:
            print(f"Loading file: {file_path}")
            file_blocks.append(_load_file_as_block(file_path))
        print(f"Loaded {len(file_blocks)} file(s)")

    print(f"LLM API CLI - Model: {model}")
    print(f"Identity: {identity.client}:{identity.use_case}")
    print(f"Tools: {', '.join(t.name for t in tools)}")
    print(f"Parallel Tool Calls Enabled: {parallel_tool_calls}")
    if files:
        print(f"Files attached: {', '.join(str(f) for f in files)}")
    if reasoning_effort:
        print(f"Reasoning Effort: {reasoning_effort}")
    if auto_thinking:
        print(f"Auto Thinking: {auto_thinking}")
    print("Type 'quit' or 'exit' to end, 'clear' to reset conversation")
    print("-" * 50)

    while True:
        try:
            user_input = input("\nYou: ").strip()

            if not user_input:
                continue

            if user_input.lower() in ("quit", "exit"):
                print("Goodbye!")
                break

            if user_input.lower() == "clear":
                convo = Conversation()
                convo.set_system(system)
                print("[Conversation cleared]")
                continue

            user_content: list[UserContentBlock] = [TextBlock(text=user_input)]
            if file_blocks:
                user_content.extend(file_blocks)
                file_blocks = []
            convo.add_user(user_content)

            print("\nAssistant: ", end="", flush=True)
            assistant_response = ""
            thinking = ThinkingBlock()

            async def spin() -> None:
                i = 0
                while True:
                    print(
                        f"\r\033[KAssistant: {SPINNER_FRAMES[i % 4]}",
                        end="",
                        flush=True,
                    )
                    i += 1
                    await asyncio.sleep(0.1)

            spinner_task: asyncio.Task[None] | None = asyncio.create_task(spin())

            def stop_spinner() -> None:
                nonlocal spinner_task
                if spinner_task:
                    spinner_task.cancel()
                    spinner_task = None
                    print("\r\033[KAssistant: ", end="", flush=True)

            stream = await client.messages.stream(
                model=model,
                convo=convo,
                identity=identity,
                sampling_params=SamplingParams(max_tokens=max_tokens),
                tool_params=ToolParams(
                    tools=tools,
                    tool_choice=tool_choice,
                    parallel_tool_calls=parallel_tool_calls,
                ),
                thinking_params=ThinkingParams(
                    reasoning_effort=reasoning_effort,
                    auto_thinking=auto_thinking,
                ),
                structured_output_params=structured_output_params,
                media_gen_params=media_gen_params,
            )

            if debug:
                _print_debug_request(
                    model,
                    convo,
                    max_tokens,
                    tools,
                    tool_choice,
                    parallel_tool_calls,
                    reasoning_effort,
                    auto_thinking,
                    structured_output_params,
                )

            async for event in stream:
                if debug:
                    _print_debug_event(event)
                match event.type:
                    case StreamEventType.CONTENT_BLOCK_START:
                        stop_spinner()
                        match event.content_block.type:
                            case ContentBlockEventType.TOOL_USE:
                                print(
                                    f"[Tool: {event.content_block.name}] ",
                                    end="",
                                    flush=True,
                                )
                            case ContentBlockEventType.THINKING:
                                thinking.endpoint_signature = (
                                    event.content_block.endpoint_signature
                                )
                                thinking.reasoning_item_id = (
                                    event.content_block.reasoning_item_id
                                )
                            case _:
                                pass
                    case StreamEventType.CONTENT_BLOCK_DELTA:
                        match event.delta.type:
                            case DeltaType.TEXT_DELTA:
                                print(event.delta.text, end="", flush=True)
                                assistant_response += event.delta.text
                            case DeltaType.INPUT_JSON_DELTA:
                                print(event.delta.partial_json, end="", flush=True)
                            case DeltaType.THINKING_DELTA:
                                thinking.thinking += event.delta.thinking
                            case DeltaType.SIGNATURE_DELTA:
                                thinking.signature += event.delta.signature
                            case DeltaType.GENERATED_IMAGE_DELTA:
                                print("[image data received]", end="", flush=True)
                            case DeltaType.GENERATED_VIDEO_DELTA:
                                print("[video data received]", end="", flush=True)
                            case DeltaType.GENERATED_AUDIO_DELTA:
                                print("[audio data received]", end="", flush=True)
                            case _:
                                pass
                    case StreamEventType.CONTENT_BLOCK_STOP:
                        pass
                    case StreamEventType.MESSAGE_DELTA:
                        u = event.usage
                        parts = [f"input={u.uncached_input_tokens}"]
                        if u.cached_input_tokens:
                            parts.append(f"cached={u.cached_input_tokens}")
                        if u.cache_write_tokens:
                            parts.append(f"cache_write={u.cache_write_tokens}")
                        parts.append(f"output={u.output_tokens}")
                        if u.reasoning_tokens:
                            parts.append(f"reasoning={u.reasoning_tokens}")
                        print(f"\n[{' | '.join(parts)}]")
                    case StreamEventType.MESSAGE_STOP:
                        convo.add_message(event.message)
                    case _:
                        pass

            stop_spinner()

            if debug:
                if request_id := stream.request_id:
                    print(f"[Request ID: {request_id}]")
                if cost := stream.approximate_cost:
                    print(
                        f"[Cost: ${cost.total_cost:.6f} "
                        f"(uncached=${cost.uncached_input_cost:.6f}, "
                        f"cached=${cost.cached_input_cost:.6f}, "
                        f"cache_write=${cost.cache_write_cost:.6f}, "
                        f"output=${cost.output_cost:.6f})]"
                    )

            print()

        except KeyboardInterrupt:
            print("\n\nInterrupted. Type 'quit' to exit.")
        except LLMAPIError as e:
            print(f"\n[Error: {type(e).__name__}] {e}")
        except Exception as e:
            print(f"\n[Error: {repr(e)}]")


async def run_count_tokens(
    client: LLMAPIClient,
    model: str,
    identity: Identity,
    text: str,
    system: str,
) -> None:
    convo = Conversation()
    convo.set_system(system)
    convo.add_user([TextBlock(text=text)])

    token_count = await client.messages.tokens(
        model=model,
        convo=convo,
        identity=identity,
    )
    print(f"Token count: {token_count}")


async def run(args: argparse.Namespace) -> None:
    client = LLMAPIClient(address=args.host)
    model: str = args.model
    identity = Identity(client=Client.DEV, use_case="unclassified")

    if args.count_tokens is not None:
        await run_count_tokens(
            client=client,
            model=model,
            identity=identity,
            text=args.count_tokens,
            system=args.system_prompt,
        )
        return

    tool_choice: ToolChoice
    match args.tool_choice:
        case ToolChoiceType.AUTO:
            tool_choice = ToolChoiceAuto()
        case ToolChoiceType.ANY:
            tool_choice = ToolChoiceAny()
        case ToolChoiceType.NONE:
            tool_choice = ToolChoiceNone()
        case _:
            tool_choice = ToolChoiceAuto()

    structured_output_params: StructuredOutputParams | Omit = omit
    if args.response_format_schema_file:
        with open(args.response_format_schema_file, encoding="utf-8") as f:
            schema = orjson.loads(f.read())
        structured_output_params = StructuredOutputParams(
            response_format=ResponseFormat(
                name="schema",
                schema=schema,
            )
        )

    media_gen_params: MediaGenParams | Omit = omit
    if args.video_duration is not None:
        media_gen_params = MediaGenParams(
            video=VideoGenParams(
                duration=args.video_duration,
                aspect_ratio=args.video_aspect_ratio,
                generate_audio=not args.no_audio,
            ),
        )

    await chat_loop(
        client=client,
        model=model,
        identity=identity,
        system=args.system_prompt,
        max_tokens=args.max_tokens or 4096,
        tools=DUMMY_TOOLS,
        tool_choice=tool_choice,
        parallel_tool_calls=args.parallel_tool_calls,
        debug=args.debug,
        reasoning_effort=args.reasoning_effort,
        auto_thinking=args.auto_thinking,
        files=args.files,
        structured_output_params=structured_output_params,
        media_gen_params=media_gen_params,
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--host",
        default=None,
        help="LLM API gRPC server address (uses resolve_llm_api_address() when omitted)",
    )
    parser.add_argument(
        "--model",
        default="claude_sonnet_4_5",
        type=str,
        help="Model ID to use (e.g. claude_sonnet_4_5, gpt5_mini, gemini_3_pro)",
    )
    parser.add_argument(
        "--system_prompt",
        default="You are an AI assistant. Keep responses concise, accurate, and helpful.",
    )
    parser.add_argument("--max_tokens", type=int, default=None)
    parser.add_argument(
        "--tool_choice",
        choices=[ToolChoiceType.AUTO, ToolChoiceType.ANY, ToolChoiceType.NONE],
        default=ToolChoiceType.AUTO,
        type=ToolChoiceType,
    )
    parser.add_argument(
        "--parallel_tool_calls",
        action="store_true",
        help="Enable parallel tool calls",
    )
    parser.add_argument(
        "--count-tokens",
        type=str,
        default=None,
        help="Count tokens for the given text instead of starting chat",
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Print request parameters and all stream events",
    )
    parser.add_argument(
        "--reasoning_effort",
        choices=list(ReasoningEffort),
        default=None,
        type=ReasoningEffort,
        help="Reasoning effort level for extended thinking",
    )
    parser.add_argument(
        "--auto_thinking",
        choices=list(AutoThinking),
        default=None,
        type=AutoThinking,
        help="Auto thinking mode (auto or disabled)",
    )
    parser.add_argument(
        "--file",
        dest="files",
        action="append",
        type=Path,
        default=[],
        help="File to include in the first message",
    )
    parser.add_argument(
        "--response_format_schema_file",
        type=Path,
        default=None,
        help="Path to JSON file containing the response schema",
    )
    parser.add_argument(
        "--video_duration",
        choices=list(VideoGenDuration),
        default=None,
        type=VideoGenDuration,
        help="Video generation duration (enables video gen params)",
    )
    parser.add_argument(
        "--video_aspect_ratio",
        choices=list(ImageGenAspectRatio),
        default=ImageGenAspectRatio.RATIO_16_9,
        type=ImageGenAspectRatio,
        help="Video aspect ratio",
    )
    parser.add_argument(
        "--no_audio",
        action="store_true",
        help="Disable audio generation for video",
    )

    args = parser.parse_args()

    for file_path in args.files:
        if not file_path.exists():
            print(f"Error: File not found: {file_path}", file=sys.stderr)
            sys.exit(1)

    try:
        asyncio.run(run(args))
    except KeyboardInterrupt:
        print("\nGoodbye!")
        sys.exit(0)


if __name__ == "__main__":
    main()
