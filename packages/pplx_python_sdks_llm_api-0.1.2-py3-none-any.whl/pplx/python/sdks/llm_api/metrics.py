import os
import time
from enum import StrEnum, auto

import grpc
from datadog.dogstatsd.base import DogStatsd


class RequestStatus(StrEnum):
    SUCCESS = auto()
    ERROR = auto()
    CANCELLED = auto()


class RequestMethod(StrEnum):
    RESPONSES = "Responses"
    COUNT_TOKENS = "CountTokens"
    CLONE_VOICE = "CloneVoice"


class ErrorType(StrEnum):
    API_ERROR = auto()
    MODEL_POOL_EXHAUSTED = auto()
    INTERNAL = auto()
    BAD_REQUEST = auto()
    PROMPT_TOO_LONG = auto()
    GRPC_ERROR = auto()
    UNKNOWN = auto()


_PREFIX = os.getenv("PPL_DD_METRICS_NAMESPACE", "ppl")
_REQUEST_TIME_METRIC = f"{_PREFIX}.llm_api.client.request.time"
_APP = os.environ.get("PPL_WEB_ROLE", "unknown")
_FLEET_CATEGORY = os.environ.get("PPL_FLEET_CATEGORY", "main")
_TEAM = os.environ.get("PPL_TEAM", "")

# Standalone DogStatsd client to avoid pulling in pplx.common.core.metrics
# and its heavy transitive dependencies (aiohttp, ddtrace, etc.) into the SDK wheel.
_client: DogStatsd | None = None
try:
    _client = DogStatsd(
        host=os.getenv("DD_AGENT_HOST", os.getenv("STATSD_HOST", "localhost")),
        port=int(os.getenv("DD_DOGSTATSD_PORT", os.getenv("STATSD_PORT", "8125"))),
    )
except Exception:
    pass


def _make_tags(
    *,
    method: RequestMethod,
    model: str,
    status: RequestStatus,
    error_type: ErrorType | None,
    grpc_code: grpc.StatusCode | None,
) -> list[str]:
    tags = [
        f"app:{_APP}",
        f"fleet_category:{_FLEET_CATEGORY}",
        f"method:{method}",
        f"model:{model}",
        f"status:{status}",
    ]
    if _TEAM:
        tags.append(f"team:{_TEAM}")
    if error_type is not None:
        tags.append(f"error_type:{error_type}")
    if grpc_code is not None:
        tags.append(f"grpc_code:{grpc_code.name.lower()}")
    return tags


def send_dd_metric(
    *,
    start_time: float,
    method: RequestMethod,
    model: str,
    status: RequestStatus,
    error_type: ErrorType | None = None,
    grpc_code: grpc.StatusCode | None = None,
) -> None:
    if _client is None:
        return
    duration = time.perf_counter() - start_time
    tags = _make_tags(
        method=method,
        model=model,
        status=status,
        error_type=error_type,
        grpc_code=grpc_code,
    )
    try:
        _client.distribution(_REQUEST_TIME_METRIC, duration, tags=tags)
    except Exception:
        pass
