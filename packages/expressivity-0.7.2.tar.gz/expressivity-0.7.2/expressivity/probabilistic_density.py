import time
import os
import json
import contextlib
from concurrent.futures import ThreadPoolExecutor, as_completed

import psutil
import torch
from torch import nn, optim
from expressivity.space import ArchitecturalSpace
from expressivity.monitor import HardwareMonitor
import matplotlib.pyplot as plt
from rich.console import Console
from rich.progress import (
    Progress,
    SpinnerColumn,
    BarColumn,
    TextColumn,
    TimeElapsedColumn,
)


console = Console()


class ArchitectureComparator:
    def __init__(
        self,
        A_space: ArchitecturalSpace,
        B_space: ArchitecturalSpace,
        base_space: ArchitecturalSpace = None,
        criterion=nn.MSELoss(),
        law=torch.distributions.Normal(0, 1),
    ) -> None:
        """
        Initialize the ArchitectureComparator.

        Parameters:
        - A_space (ArchitecturalSpace): The first architectural space.
        - B_space (ArchitecturalSpace): The second architectural space.
        - base_space (ArchitecturalSpace, optional): The base architectural space used for comparison.
        - criterion (nn.Module): Loss function used for training (default: nn.MSELoss).
        - law (torch.distributions.Distribution): Data distribution for sampling (default: Normal(0, 1)).
        """
        self.A_space = A_space
        self.B_space = B_space
        self.base_space = base_space
        self.criterion = criterion
        self.law = law

        assert (
            A_space.input_size == B_space.input_size
        ), "The input size of the two models must be the same"

        self.input_size = A_space.input_size

        assert len(A_space.parameters) == len(
            B_space.parameters
        ), "The number of architectures must be the same in space A and B"
        self.count = len(A_space.parameters)

        assert (
            A_space.automatic_mesurement_mode == B_space.automatic_mesurement_mode
            or A_space.automatic_mesurement_mode is None
            or B_space.automatic_mesurement_mode is None
        ), "The automatic mesurement mode must be the same in space A and B"

        if A_space.mesurement != B_space.mesurement:
            console.print(
                "[yellow]Warning:[/yellow] The mesurements of space A and B are different, you may not compare both model on an equal footing"
            )

        try:
            test_tensor = torch.zeros((1, *self.input_size))
            A_output_size = self._create_model(A_space, 0)(test_tensor).shape
            B_output_size = self._create_model(B_space, 0)(test_tensor).shape

            assert (
                A_output_size == B_output_size
            ), "The output size of the two models must be the same"

            self.output_size = A_output_size[1:]

            if base_space is not None:
                assert (
                    self.input_size == base_space.input_size
                ), "The input size of the two models must be the same"
                base_output_size = self._create_model(base_space, 0)(
                    test_tensor
                ).shape
                assert (
                    self.output_size == base_output_size[1:]
                ), "The output size of the two models must be the same"
                assert len(base_space.parameters) == self.count

        except Exception as e:
            console.print(f"[red]The input size is not correct:[/red] {e}")

    def compare(
        self,
        max_iterations: int = 10,
        sub_iterations: int = 1,
        variance_threashold: float | None = None,
        plot_mode: str | None = None,
        save_path: str | None = os.path.join(os.getcwd(), "results"),
        monitor: bool = False,
    ) -> tuple[list[float]]:
        """
        Compare architectures by fitting one to the other and evaluating performance.

        Parameters:
        - max_iterations (int): Maximum number of gradient descent iterations.
        - sub_iterations (int): Number of attempts of the source architecture to minimize error at each iteration.
        - variance_threashold (float, optional): Threshold to stop iterations based on variance.
        - plot_mode (str, optional): Plot comparison results; "min" or "mean".
        - save_path (str | None): Directory to save results (images + data). Defaults to <cwd>/results/. Set to None to disable saving.
        - monitor (bool): If True, display a live hardware monitor (CPU, RAM, GPU, VRAM, temp, power).

        Returns:
        - tuple[list[float]]: Minimum and mean losses for architectures A and B.
        """

        self.max_iterations = max_iterations
        self.sub_iterations = sub_iterations
        if variance_threashold is None:
            self.variance_threashold = 0
        else:
            self.variance_threashold = variance_threashold

        self.min_A_fit = [None for _ in range(self.count)]
        self.mean_A_fit = [None for _ in range(self.count)]
        self.min_B_fit = [None for _ in range(self.count)]
        self.mean_B_fit = [None for _ in range(self.count)]
        self.time_A = [None for _ in range(self.count)]
        self.time_B = [None for _ in range(self.count)]

        fits_per_model = 2
        total_steps = self.count * fits_per_model * max_iterations * sub_iterations

        hw_monitor = None
        if monitor:
            hw_monitor = HardwareMonitor(interval=0.5)
            hw_monitor.start(console)

        with Progress(
            SpinnerColumn(),
            TextColumn("[bold blue]{task.description}"),
            BarColumn(),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(),
            console=console,
        ) as progress:
            global_task = progress.add_task("Overall", total=total_steps)

            for i in range(self.count):
                console.print(f"\n[bold]Model {i+1}/{self.count}[/bold]")

                if self.base_space is None:
                    source_A, target_A = self.A_space, self.B_space
                    source_B, target_B = self.B_space, self.A_space
                else:
                    source_A, target_A = self.A_space, self.base_space
                    source_B, target_B = self.B_space, self.base_space

                console.print(
                    f"  [cyan]{source_A.name}[/cyan] fits [magenta]{target_A.name}[/magenta]"
                )
                t0 = time.time()
                self.min_A_fit[i], self.mean_A_fit[i] = self._fit_source_to_target(
                    source_A, target_A, i, progress, global_task
                )
                self.time_A[i] = time.time() - t0

                console.print(
                    f"  [cyan]{source_B.name}[/cyan] fits [magenta]{target_B.name}[/magenta]"
                )
                t0 = time.time()
                self.min_B_fit[i], self.mean_B_fit[i] = self._fit_source_to_target(
                    source_B, target_B, i, progress, global_task
                )
                self.time_B[i] = time.time() - t0

                if self.min_B_fit[i] > self.min_A_fit[i]:
                    self.winnner = "A"
                    console.print(
                        f"  [bold green]Winner (min): {self.A_space.name}[/bold green]"
                    )
                else:
                    self.winnner = "B"
                    console.print(
                        f"  [bold green]Winner (min): {self.B_space.name}[/bold green]"
                    )

                if self.mean_B_fit[i] > self.mean_A_fit[i]:
                    if self.winnner == "A":
                        console.print(
                            f"  [bold green]{self.A_space.name} wins by all metrics[/bold green]"
                        )
                    else:
                        console.print(
                            f"  [yellow]However, {self.A_space.name} shows better mean convergence[/yellow]"
                        )
                else:
                    if self.winnner == "B":
                        console.print(
                            f"  [bold green]{self.B_space.name} wins by all metrics[/bold green]"
                        )
                    else:
                        console.print(
                            f"  [yellow]However, {self.B_space.name} shows better mean convergence[/yellow]"
                        )

        if hw_monitor is not None:
            hw_monitor.stop()
            hw_monitor.print_summary(console)

        if save_path is not None:
            os.makedirs(save_path, exist_ok=True)
            self._save_data(save_path)
            self._save_plots(save_path)
            console.print(f"\n[bold green]Results saved to {save_path}[/bold green]")

        if plot_mode is not None:
            self.plot(plot_mode)

        return self.min_A_fit, self.mean_A_fit, self.min_B_fit, self.mean_B_fit

    def _create_model(self, space: ArchitecturalSpace, index: int) -> nn.Module:
        return space.architecture(**space.parameters[index])

    # ------------------------------------------------------------------ #
    #  Memory estimation & adaptive parallelism                           #
    # ------------------------------------------------------------------ #

    def _estimate_model_memory(
        self, space: ArchitecturalSpace, model_index: int
    ) -> int:
        model = self._create_model(space, model_index)
        param_bytes = sum(p.numel() * p.element_size() for p in model.parameters())
        del model
        # params + grads + optimizer state (adam: 2x) + activation headroom
        return param_bytes * 6

    def _compute_max_parallel(
        self, source_space: ArchitecturalSpace, model_index: int
    ) -> int:
        total_runs = self.max_iterations * self.sub_iterations
        model_mem = self._estimate_model_memory(source_space, model_index)
        if model_mem == 0:
            return total_runs
        if torch.cuda.is_available():
            free_mem = torch.cuda.mem_get_info()[0]
        else:
            free_mem = psutil.virtual_memory().available
        max_p = int(free_mem * 0.7 / model_mem)
        return max(1, min(max_p, total_runs))

    @staticmethod
    def _get_device():
        return "cuda" if torch.cuda.is_available() else "cpu"

    # ------------------------------------------------------------------ #
    #  Dispatcher                                                         #
    # ------------------------------------------------------------------ #

    def _fit_source_to_target(
        self,
        source_space: ArchitecturalSpace,
        target_space: ArchitecturalSpace,
        model_index: int,
        progress: Progress = None,
        global_task=None,
    ) -> tuple[float]:
        max_parallel = self._compute_max_parallel(source_space, model_index)
        device = self._get_device()
        total_runs = self.max_iterations * self.sub_iterations
        n_chunks = (total_runs + max_parallel - 1) // max_parallel

        if max_parallel > 1:
            backend = "CUDA streams" if device == "cuda" else "threads"
            if n_chunks == 1:
                console.print(
                    f"    [bold green]⚡ Parallel mode ({backend})[/bold green] — "
                    f"{total_runs} runs ({self.max_iterations} iter × {self.sub_iterations} sub) "
                    f"in a single batch on [bold]{device.upper()}[/bold]"
                )
            else:
                console.print(
                    f"    [bold green]⚡ Parallel mode ({backend})[/bold green] — "
                    f"{total_runs} runs ({self.max_iterations} iter × {self.sub_iterations} sub) "
                    f"in {n_chunks} chunks of ≤{max_parallel} on [bold]{device.upper()}[/bold]"
                )
            return self._parallel_fit(
                source_space, target_space, model_index,
                max_parallel, device, progress, global_task,
            )

        console.print(
            f"    [dim]Sequential mode — 1 run at a time on {device.upper()}[/dim]"
        )
        return self._sequential_fit(
            source_space, target_space, model_index, device, progress, global_task
        )

    # ------------------------------------------------------------------ #
    #  Parallel fit — CUDA streams (GPU) or ThreadPool (CPU)               #
    # ------------------------------------------------------------------ #

    def _parallel_fit(
        self,
        source_space: ArchitecturalSpace,
        target_space: ArchitecturalSpace,
        model_index: int,
        max_parallel: int,
        device: str,
        progress: Progress = None,
        global_task=None,
    ) -> tuple[float]:

        total_runs = self.max_iterations * self.sub_iterations
        epochs = source_space.epoch[model_index]
        grad_clamp = source_space.grad_clamp[model_index]
        lr = source_space.lr[model_index]
        criterion = self.criterion

        mini_batch_count = (
            target_space.batch_size[model_index]
            // source_space.mini_batch_size[model_index]
        )
        mini_batch_size = source_space.mini_batch_size[model_index]
        shape = (mini_batch_count, mini_batch_size, *self.input_size)

        # -------------------------------------------------------------- #
        # 1) Pre-generate ALL data (one X + target per iteration)         #
        # -------------------------------------------------------------- #
        console.print("    [dim]Generating targets...[/dim]")
        all_X = []
        all_targets = []
        for i in range(self.max_iterations):
            X = self.law.sample(shape).to(device)
            target_model = self._create_model(target_space, model_index).to(device)
            target_model.eval()
            with torch.no_grad():
                t_out = target_model(
                    X.view(mini_batch_count * mini_batch_size, *self.input_size)
                )
                t_out = t_out.view(
                    mini_batch_count, mini_batch_size, *self.output_size
                )
            all_X.append(X)
            all_targets.append(t_out)
            del target_model

        # Map each run to its iteration:
        # runs 0..sub-1 → iter 0, runs sub..2sub-1 → iter 1, etc.
        iter_for_run = [r // self.sub_iterations for r in range(total_runs)]

        # -------------------------------------------------------------- #
        # 2) Process runs in chunks                                       #
        # -------------------------------------------------------------- #
        all_losses = [0.0] * total_runs
        run_idx = 0

        while run_idx < total_runs:
            chunk_end = min(run_idx + max_parallel, total_runs)
            chunk_size = chunk_end - run_idx

            console.print(
                f"    [dim]Chunk: runs {run_idx + 1}..{chunk_end}/{total_runs} "
                f"({chunk_size} models in parallel)[/dim]"
            )

            # Per-run data (reference, not copy — they share data within same iteration)
            run_X = [all_X[iter_for_run[run_idx + i]] for i in range(chunk_size)]
            run_targets = [all_targets[iter_for_run[run_idx + i]] for i in range(chunk_size)]

            # Create models + optimizers sequentially (safe for class-var tricks like StelLAAdamW)
            models = []
            optimizers = []
            for i in range(chunk_size):
                m = self._create_model(source_space, model_index).to(device)
                o = source_space.optimizer(m.parameters(), lr)
                models.append(m)
                optimizers.append(o)

            if device == "cuda":
                self._parallel_fit_cuda(
                    models, optimizers, run_X, run_targets,
                    epochs, mini_batch_count, grad_clamp, criterion,
                    all_losses, run_idx, chunk_size,
                )
            else:
                self._parallel_fit_cpu(
                    models, optimizers, run_X, run_targets,
                    epochs, mini_batch_count, grad_clamp, criterion,
                    all_losses, run_idx, chunk_size,
                )

            if progress is not None:
                progress.advance(global_task, chunk_size)

            # Show chunk losses summary
            chunk_losses = all_losses[run_idx:chunk_end]
            console.print(
                f"      Loss — min: {min(chunk_losses):.6f}, "
                f"mean: {sum(chunk_losses)/len(chunk_losses):.6f}"
            )

            del models, optimizers
            if device == "cuda":
                torch.cuda.empty_cache()
            run_idx = chunk_end

        del all_X, all_targets

        # -------------------------------------------------------------- #
        # 3) Reshape (max_iterations, sub_iterations) and aggregate       #
        # -------------------------------------------------------------- #
        losses_t = torch.tensor(all_losses).view(
            self.max_iterations, self.sub_iterations
        )
        minimum = losses_t.min(dim=1).values  # best sub per iteration
        mean_vals = losses_t.mean(dim=1)  # mean sub per iteration

        console.print("    [bold]Per-iteration results:[/bold]")
        for i in range(self.max_iterations):
            console.print(
                f"      Iteration {i + 1}/{self.max_iterations}: "
                f"min={minimum[i].item():.6f}, mean={mean_vals[i].item():.6f}"
            )

        return minimum.mean().item(), mean_vals.mean().item()

    # ------------------------------------------------------------------ #
    #  GPU backend: CUDA streams + torch.compile + flattened batches        #
    # ------------------------------------------------------------------ #

    def _parallel_fit_cuda(
        self, models, optimizers, run_X, run_targets,
        epochs, mini_batch_count, grad_clamp, criterion,
        all_losses, run_idx, chunk_size,
    ):
        # Flatten mini-batches into one big tensor per run → 1 forward pass
        # per epoch instead of mini_batch_count, massively reducing kernel launches.
        flat_X = []
        flat_targets = []
        for i in range(chunk_size):
            # run_X[i] shape: (mini_batch_count, mini_batch_size, *input_size)
            flat_X.append(run_X[i].view(-1, *run_X[i].shape[2:]))
            flat_targets.append(run_targets[i].view(-1, *run_targets[i].shape[2:]))

        # Try torch.compile to fuse small kernels into larger ones
        # mode="reduce-overhead" uses CUDA graphs internally
        compiled_models = []
        for m in models:
            try:
                compiled_models.append(torch.compile(m, mode="reduce-overhead"))
            except Exception:
                compiled_models = models
                break

        # Cap streams to avoid overhead (more streams than GPU SMs is wasteful)
        n_streams = min(chunk_size, 32)
        streams = [torch.cuda.Stream() for _ in range(n_streams)]

        default_event = torch.cuda.Event()
        default_event.record()
        for s in streams:
            s.wait_event(default_event)

        # ---- Training: single forward pass per epoch per model, no sync ----
        for epoch in range(epochs):
            for i in range(chunk_size):
                s = streams[i % n_streams]
                with torch.cuda.stream(s):
                    optimizers[i].zero_grad()
                    output = compiled_models[i](flat_X[i])
                    loss = criterion(output, flat_targets[i])
                    loss.backward()
                    torch.nn.utils.clip_grad_value_(
                        models[i].parameters(), grad_clamp
                    )
                    optimizers[i].step()

        # Single sync after all training
        torch.cuda.synchronize()

        # ---- Eval: one forward pass per model, accumulate on GPU ----
        eval_losses = torch.zeros(chunk_size, device="cuda")
        for i in range(chunk_size):
            models[i].eval()
            s = streams[i % n_streams]
            with torch.cuda.stream(s):
                with torch.no_grad():
                    output = compiled_models[i](flat_X[i])
                    eval_losses[i] = criterion(output, flat_targets[i])

        torch.cuda.synchronize()
        eval_losses_cpu = eval_losses.cpu().tolist()
        for i in range(chunk_size):
            all_losses[run_idx + i] = eval_losses_cpu[i]

        del streams, compiled_models, flat_X, flat_targets

    # ------------------------------------------------------------------ #
    #  CPU backend: ThreadPoolExecutor                                     #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _train_single_run(
        model, optimizer, X, targets,
        epochs, mini_batch_count, grad_clamp, criterion,
        intra_threads,
    ) -> float:
        """Train a single model and return its eval loss. Runs in a worker thread."""
        torch.set_num_threads(intra_threads)
        model.train()
        for epoch in range(epochs):
            for mb_idx in range(mini_batch_count):
                optimizer.zero_grad()
                output = model(X[mb_idx])
                loss = criterion(output, targets[mb_idx])
                loss.backward()
                torch.nn.utils.clip_grad_value_(model.parameters(), grad_clamp)
                optimizer.step()

        model.eval()
        eval_loss = 0.0
        with torch.no_grad():
            for mb_idx in range(mini_batch_count):
                output = model(X[mb_idx])
                eval_loss += criterion(output, targets[mb_idx]).item()
        return eval_loss / mini_batch_count

    def _parallel_fit_cpu(
        self, models, optimizers, run_X, run_targets,
        epochs, mini_batch_count, grad_clamp, criterion,
        all_losses, run_idx, chunk_size,
    ):
        total_cores = os.cpu_count() or 4
        n_workers = min(chunk_size, total_cores)
        # Split cores across workers so each thread's PyTorch uses its fair share
        intra_threads = max(1, total_cores // n_workers)
        console.print(f"      [dim]{n_workers} threads × {intra_threads} cores each[/dim]")

        # Save and restore the main thread's setting after the pool finishes
        original_threads = torch.get_num_threads()

        with ThreadPoolExecutor(max_workers=n_workers) as pool:
            futures = {}
            for i in range(chunk_size):
                fut = pool.submit(
                    self._train_single_run,
                    models[i], optimizers[i],
                    run_X[i], run_targets[i],
                    epochs, mini_batch_count, grad_clamp, criterion,
                    intra_threads,
                )
                futures[fut] = i

            for fut in as_completed(futures):
                i = futures[fut]
                all_losses[run_idx + i] = fut.result()

        torch.set_num_threads(original_threads)

    # ------------------------------------------------------------------ #
    #  Sequential fit (fallback / CPU)                                    #
    # ------------------------------------------------------------------ #

    def _sequential_fit(
        self,
        source_space: ArchitecturalSpace,
        target_space: ArchitecturalSpace,
        model_index: int,
        device: str,
        progress: Progress = None,
        global_task=None,
    ) -> tuple[float]:

        minimum = torch.tensor([torch.inf] * self.max_iterations)
        mean = torch.zeros(self.max_iterations)

        epochs = source_space.epoch[model_index]
        grad_clamp = source_space.grad_clamp[model_index]
        criterion = self.criterion

        mini_batch_count = (
            target_space.batch_size[model_index]
            // source_space.mini_batch_size[model_index]
        )
        mini_batch_size = source_space.mini_batch_size[model_index]
        shape = (mini_batch_count, mini_batch_size, *self.input_size)

        for i in range(self.max_iterations):
            console.print(f"    [dim]Iteration {i+1}/{self.max_iterations}[/dim]")

            X = self.law.sample(shape).to(device)

            target_model = self._create_model(target_space, model_index).to(device)
            target_model.eval()
            with torch.no_grad():
                target_output = target_model(
                    X.view(mini_batch_count * mini_batch_size, *self.input_size)
                )
                target_output = target_output.view(
                    mini_batch_count, mini_batch_size, *self.output_size
                )
            del target_model

            for j in range(self.sub_iterations):
                console.print(
                    f"      [dim]Sub-iteration {j+1}/{self.sub_iterations}[/dim]"
                )
                source_model = self._create_model(source_space, model_index).to(device)
                optimizer = source_space.optimizer(
                    source_model.parameters(), source_space.lr[model_index]
                )

                # Train
                source_model.train()
                for epoch in range(epochs):
                    for mini_batch, target in zip(X, target_output):
                        optimizer.zero_grad()
                        output = source_model(mini_batch)
                        loss = criterion(output, target)
                        loss.backward()
                        torch.nn.utils.clip_grad_value_(
                            source_model.parameters(), grad_clamp
                        )
                        optimizer.step()
                    console.print(
                        f"        Epoch {epoch + 1}/{epochs}, Loss: {loss.item():.6f}"
                    )

                # Eval
                source_model.eval()
                eval_loss = 0
                with torch.no_grad():
                    for mini_batch, target in zip(X, target_output):
                        output = source_model(mini_batch)
                        eval_loss += criterion(output, target)
                eval_loss /= X.shape[0]
                loss_val = eval_loss.item()
                console.print(f"        [bold]Final loss: {loss_val:.6f}[/bold]")

                minimum[i] = min(minimum[i], loss_val)
                mean[i] += loss_val
                del source_model, optimizer

                if progress is not None:
                    progress.advance(global_task)

            mean[i] /= self.sub_iterations

            min_var = torch.var(minimum, unbiased=True)
            mean_var = torch.var(mean, unbiased=True)
            if max(min_var, mean_var) < self.variance_threashold:
                break

        return minimum.mean().item(), mean.mean().item()

    # ------------------------------------------------------------------ #
    #  Saving results                                                     #
    # ------------------------------------------------------------------ #

    def _save_data(self, save_path: str) -> None:
        data = {
            "A_space": self.A_space.name,
            "B_space": self.B_space.name,
            "mesurement_mode": self.A_space.automatic_mesurement_mode
            or self.B_space.automatic_mesurement_mode,
            "mesurements_A": self.A_space.mesurement,
            "mesurements_B": self.B_space.mesurement,
            "min_A_fit": self.min_A_fit,
            "mean_A_fit": self.mean_A_fit,
            "min_B_fit": self.min_B_fit,
            "mean_B_fit": self.mean_B_fit,
            "time_A": self.time_A,
            "time_B": self.time_B,
            "max_iterations": self.max_iterations,
            "sub_iterations": self.sub_iterations,
        }
        with open(os.path.join(save_path, "results.json"), "w") as f:
            json.dump(data, f, indent=2)

    def _save_plots(self, save_path: str) -> None:
        for mode in ["min", "mean"]:
            if mode == "min":
                values_A = self.min_A_fit
                values_B = self.min_B_fit
            else:
                values_A = self.mean_A_fit
                values_B = self.mean_B_fit

            if any(v is None for v in values_A + values_B):
                continue

            fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))

            ax1.plot(
                self.A_space.mesurement,
                values_A,
                label=f"{self.A_space.name} ({mode})",
                marker="o",
            )
            ax1.plot(
                self.B_space.mesurement,
                values_B,
                label=f"{self.B_space.name} ({mode})",
                marker="o",
            )
            ax1.set_xlabel("Number of Parameters")
            ax1.set_ylabel(f"{mode.capitalize()} Loss")
            ax1.set_title(f"{mode.capitalize()} Loss vs Parameters")
            ax1.legend()
            ax1.grid(True)

            ax2.plot(
                self.time_A,
                values_A,
                label=f"{self.A_space.name} ({mode})",
                marker="o",
            )
            ax2.plot(
                self.time_B,
                values_B,
                label=f"{self.B_space.name} ({mode})",
                marker="o",
            )
            ax2.set_xlabel("Time (s)")
            ax2.set_ylabel(f"{mode.capitalize()} Loss")
            ax2.set_title(f"{mode.capitalize()} Loss vs Time")
            ax2.legend()
            ax2.grid(True)

            plt.tight_layout()
            fig.savefig(os.path.join(save_path, f"{mode}_comparison.png"), dpi=150)
            plt.close(fig)

    # ------------------------------------------------------------------ #
    #  Plotting                                                           #
    # ------------------------------------------------------------------ #

    def plot(self, mode: str) -> None:
        if mode not in ["min", "mean"]:
            raise ValueError("Mode must be 'min' or 'mean'")

        if mode == "min":
            values_A = self.min_A_fit
            values_B = self.min_B_fit
        elif mode == "mean":
            values_A = self.mean_A_fit
            values_B = self.mean_B_fit

        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))

        # Plot 1: Performance vs number of parameters
        ax1.plot(
            self.A_space.mesurement,
            values_A,
            label=f"{self.A_space.name} ({mode})",
            marker="o",
        )
        ax1.plot(
            self.B_space.mesurement,
            values_B,
            label=f"{self.B_space.name} ({mode})",
            marker="o",
        )
        ax1.set_xlabel("Number of Parameters")
        ax1.set_ylabel(f"{mode.capitalize()} Loss")
        ax1.set_title(f"{mode.capitalize()} Loss vs Parameters")
        ax1.legend()
        ax1.grid(True)

        # Plot 2: Performance vs time
        ax2.plot(
            self.time_A,
            values_A,
            label=f"{self.A_space.name} ({mode})",
            marker="o",
        )
        ax2.plot(
            self.time_B,
            values_B,
            label=f"{self.B_space.name} ({mode})",
            marker="o",
        )
        ax2.set_xlabel("Time (s)")
        ax2.set_ylabel(f"{mode.capitalize()} Loss")
        ax2.set_title(f"{mode.capitalize()} Loss vs Time")
        ax2.legend()
        ax2.grid(True)

        plt.tight_layout()
        plt.show()

    def get_densities(self):
        """
        Compute and return the density of the comparison.

        Returns:
        - To be implemented if mathematically cool.
        """
        pass
