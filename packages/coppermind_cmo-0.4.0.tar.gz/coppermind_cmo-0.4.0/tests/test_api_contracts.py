"""API contract tests for all 10 MCP tool interfaces.

Verifies response shapes (required keys, correct types) and error codes
match the documented contracts in MCP_TOOLS.md and SERVER_SPEC.md.

These tests complement unit and integration tests by focusing exclusively
on the *shape* of return values rather than behavioral correctness.
"""

import json
from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

from coppermind_cmo.errors import (
    NO_ACTIVE_MIND,
    INVALID_INPUT,
    MIND_NOT_FOUND,
    MIND_ARCHIVED,
    INVALID_MEMORY_TYPE,
    INVALID_BRAND_DNA,
    SERVICE_UNAVAILABLE,
    MEMORY_NOT_FOUND,
    INVALID_QUERY,
    tool_error,
)
from coppermind_cmo.tools.brand import _get_brand_voice, _set_brand_voice
from coppermind_cmo.tools.intelligence import _prep_meeting, _get_campaign_history
from coppermind_cmo.tools.memories import (
    _store_memory,
    _search_memory,
    _quick_note,
    _hide_memory,
)
from coppermind_cmo.tools.minds import _switch_client, _list_minds


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _dt(day: int = 1) -> datetime:
    """Create a timezone-aware datetime for March 2026."""
    return datetime(2026, 3, day, 0, 0, 0, tzinfo=timezone.utc)


def assert_has_keys(result, keys_types):
    """Verify result dict has all expected keys with correct types.

    keys_types: dict mapping key name to expected type (or None to skip type check).
    """
    for key, expected_type in keys_types.items():
        assert key in result, f"Missing key: {key}"
        if expected_type is not None:
            assert isinstance(result[key], expected_type), (
                f"Key '{key}' expected {expected_type.__name__}, "
                f"got {type(result[key]).__name__}"
            )


def assert_error_shape(result, expected_code):
    """Verify result is a valid error response per SERVER_SPEC.md."""
    assert isinstance(result, dict), f"Error must be dict, got {type(result).__name__}"
    assert result["error"] is True, "error field must be True"
    assert result["code"] == expected_code, (
        f"Expected code '{expected_code}', got '{result.get('code')}'"
    )
    assert isinstance(result["message"], str), "message must be a string"
    assert len(result["message"]) > 0, "message must not be empty"


# ---------------------------------------------------------------------------
# 1. switch_client
# ---------------------------------------------------------------------------

class TestSwitchClientContract:
    """Verify switch_client response shape matches MCP_TOOLS.md contract."""

    EXPECTED_KEYS = {
        "mind_id": str,
        "name": str,
        "slug": str,
        "is_new": bool,
        "memory_count": int,
    }

    def test_success_existing_mind_shape(self):
        db = MagicMock()
        db.fetch_one.side_effect = [
            ("uuid-1", "Acme Corp", "acme-corp", None, False, None),
            (10,),
        ]
        set_mind = MagicMock()
        result = _switch_client("Acme Corp", False, db, set_mind, customer_id="test-customer")
        assert_has_keys(result, self.EXPECTED_KEYS)
        assert result["is_new"] is False

    def test_success_create_new_mind_shape(self):
        db = MagicMock()
        db.fetch_one.side_effect = [None, None]
        db.execute_returning.return_value = ("uuid-new", "NewClient", "newclient")
        set_mind = MagicMock()
        result = _switch_client("NewClient", True, db, set_mind, customer_id="test-customer")
        assert_has_keys(result, self.EXPECTED_KEYS)
        assert result["is_new"] is True
        assert result["memory_count"] == 0

    def test_error_empty_name(self):
        db = MagicMock()
        set_mind = MagicMock()
        result = _switch_client("", False, db, set_mind)
        assert_error_shape(result, "INVALID_INPUT")

    def test_error_whitespace_name(self):
        db = MagicMock()
        set_mind = MagicMock()
        result = _switch_client("   ", False, db, set_mind)
        assert_error_shape(result, "INVALID_INPUT")

    def test_error_mind_not_found(self):
        db = MagicMock()
        db.fetch_one.return_value = None
        db.fetch_all.return_value = [("Acme Corp",)]
        set_mind = MagicMock()
        result = _switch_client("Nonexistent", False, db, set_mind, customer_id="test-customer")
        assert_error_shape(result, "MIND_NOT_FOUND")

    def test_error_mind_archived(self):
        db = MagicMock()
        db.fetch_one.return_value = (
            "uuid-1", "Old Client", "old-client", "2026-01-01T00:00:00Z", False, None,
        )
        set_mind = MagicMock()
        result = _switch_client("Old Client", False, db, set_mind, customer_id="test-customer")
        assert_error_shape(result, "MIND_ARCHIVED")

    def test_no_extra_keys_on_success(self):
        """Success response should not contain error-related keys."""
        db = MagicMock()
        db.fetch_one.side_effect = [
            ("uuid-1", "Acme", "acme", None, False, None),
            (5,),
        ]
        set_mind = MagicMock()
        result = _switch_client("Acme", False, db, set_mind, customer_id="test-customer")
        assert "error" not in result
        assert "code" not in result


# ---------------------------------------------------------------------------
# 2. list_minds
# ---------------------------------------------------------------------------

class TestListMindsContract:
    """Verify list_minds response shape matches MCP_TOOLS.md contract."""

    EXPECTED_ITEM_KEYS = {
        "mind_id": str,
        "name": str,
        "slug": str,
        "archived_at": None,  # str or None -- checked manually
        "memory_count": int,
        "created_at": None,   # str or None -- checked manually
        "updated_at": None,   # str or None -- checked manually
    }

    def test_success_shape_with_items(self):
        db = MagicMock()
        db.fetch_all.return_value = [
            ("uuid-1", "Acme Corp", "acme-corp", None, 47, _dt(1), _dt(5)),
            ("uuid-2", "Beta Inc", "beta-inc", _dt(3), 0, _dt(2), _dt(4)),
        ]
        result = _list_minds(50, 0, db, customer_id="test-customer")
        assert isinstance(result, list)
        assert len(result) == 2

        for item in result:
            assert isinstance(item, dict)
            for key in self.EXPECTED_ITEM_KEYS:
                assert key in item, f"Missing key: {key}"

        # First item: no archive
        assert isinstance(result[0]["mind_id"], str)
        assert isinstance(result[0]["name"], str)
        assert isinstance(result[0]["slug"], str)
        assert result[0]["archived_at"] is None
        assert isinstance(result[0]["memory_count"], int)
        assert isinstance(result[0]["created_at"], str)
        assert isinstance(result[0]["updated_at"], str)

        # Second item: archived
        assert isinstance(result[1]["archived_at"], str)

    def test_empty_list_shape(self):
        db = MagicMock()
        db.fetch_all.return_value = []
        result = _list_minds(50, 0, db)
        assert isinstance(result, list)
        assert len(result) == 0

    def test_nullable_datetime_fields(self):
        """created_at and updated_at can be None."""
        db = MagicMock()
        db.fetch_all.return_value = [
            ("uuid-1", "Acme", "acme", None, 0, None, None),
        ]
        result = _list_minds(50, 0, db, customer_id="test-customer")
        assert result[0]["created_at"] is None
        assert result[0]["updated_at"] is None

    def test_return_type_is_list_not_dict(self):
        """list_minds always returns a list, never an error dict."""
        db = MagicMock()
        db.fetch_all.return_value = []
        result = _list_minds(50, 0, db)
        assert not isinstance(result, dict)
        assert isinstance(result, list)


# ---------------------------------------------------------------------------
# 3. store_memory
# ---------------------------------------------------------------------------

class TestStoreMemoryContract:
    """Verify store_memory response shape matches MCP_TOOLS.md contract."""

    EXPECTED_KEYS = {
        "memory_id": str,
        "summary": str,
        "memory_type": str,
        "classified_by": str,
        "has_embedding": bool,
        "mind_id": str,
    }

    VALID_CLASSIFIED_BY = {"user", "default", "llm", "fallback"}

    def _make_deps(self, mind=("mind-1", "Acme")):
        db = MagicMock()
        config = MagicMock()
        config.embedding_url = "http://localhost:8400"
        config.ollama_url = "http://localhost:11434"
        config.ollama_model = "gemma3:12b"
        return db, config, mind

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1, 0.2])
    def test_success_shape_ollama_classification(self, mock_emb):
        db, config, mind = self._make_deps()
        db.execute_returning.return_value = ("mem-uuid-1",)
        result = _store_memory("We decided to pause ads", None, ["q2"], db, config, mind)
        assert_has_keys(result, self.EXPECTED_KEYS)
        assert result["classified_by"] in self.VALID_CLASSIFIED_BY
        assert result["classified_by"] == "default"
        assert result["has_embedding"] is True
        assert "error" not in result

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1])
    def test_success_shape_user_classification(self, mock_emb):
        db, config, mind = self._make_deps()
        db.execute_returning.return_value = ("mem-uuid-2",)
        result = _store_memory("content", "commitment", [], db, config, mind)
        assert_has_keys(result, self.EXPECTED_KEYS)
        assert result["classified_by"] == "user"
        assert result["classified_by"] in self.VALID_CLASSIFIED_BY

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=None)
    def test_success_shape_fallback_classification(self, mock_emb):
        db, config, mind = self._make_deps()
        db.execute_returning.return_value = ("mem-uuid-3",)
        result = _store_memory("some content", None, [], db, config, mind)
        assert_has_keys(result, self.EXPECTED_KEYS)
        assert result["classified_by"] == "default"
        assert result["classified_by"] in self.VALID_CLASSIFIED_BY
        assert result["has_embedding"] is False

    def test_error_no_active_mind(self):
        db, config, _ = self._make_deps()
        result = _store_memory("content", None, [], db, config, None)
        assert_error_shape(result, "NO_ACTIVE_MIND")

    def test_error_empty_content(self):
        db, config, mind = self._make_deps()
        result = _store_memory("", None, [], db, config, mind)
        assert_error_shape(result, "INVALID_INPUT")

    def test_error_content_too_long(self):
        db, config, mind = self._make_deps()
        result = _store_memory("x" * 10001, None, [], db, config, mind)
        assert_error_shape(result, "INVALID_INPUT")

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1])
    def test_invalid_memory_type_auto_classifies(self, mock_emb):
        """Invalid memory_type falls back to 'fact' with classified_by='default'."""
        db, config, mind = self._make_deps()
        db.execute_returning.return_value = ("mem-auto",)
        result = _store_memory("content", "not_a_real_type", [], db, config, mind)
        assert "error" not in result
        assert result["classified_by"] == "default"


# ---------------------------------------------------------------------------
# 4. search_memory
# ---------------------------------------------------------------------------

class TestSearchMemoryContract:
    """Verify search_memory response shape matches MCP_TOOLS.md contract."""

    EXPECTED_ITEM_KEYS = {
        "memory_id": str,
        "content": str,
        "summary": str,
        "memory_type": str,
        "confidence": float,
        "similarity": float,
        "tags": list,
        "source_type": str,
        "created_at": None,  # str or None -- checked manually
    }

    def _make_deps(self, mind=("mind-1", "Acme")):
        db = MagicMock()
        config = MagicMock()
        config.embedding_url = "http://localhost:8400"
        return db, config, mind

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1, 0.2])
    def test_success_shape_with_results(self, mock_emb):
        db, config, mind = self._make_deps()
        db.fetch_all.return_value = [
            ("mem-1", "Pausing ads", "Pausing LinkedIn ads", "decision",
             1.0, 0.87, ["ads"], "manual", _dt(5)),
        ]
        result = _search_memory("ad budget", None, 10, 0, db, config, mind)
        assert isinstance(result, list)
        assert len(result) == 1

        item = result[0]
        for key, expected_type in self.EXPECTED_ITEM_KEYS.items():
            assert key in item, f"Missing key: {key}"
            if expected_type is not None:
                assert isinstance(item[key], expected_type), (
                    f"Key '{key}' expected {expected_type.__name__}, "
                    f"got {type(item[key]).__name__}"
                )

        assert isinstance(item["created_at"], str)

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1, 0.2])
    def test_success_shape_nullable_created_at(self, mock_emb):
        db, config, mind = self._make_deps()
        db.fetch_all.return_value = [
            ("mem-1", "Content", "Summary", "fact", 0.9, 0.85, ["tag"], "manual", None),
        ]
        result = _search_memory("query", None, 10, 0, db, config, mind)
        assert result[0]["created_at"] is None

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1, 0.2])
    def test_success_shape_null_tags_returns_empty_list(self, mock_emb):
        db, config, mind = self._make_deps()
        db.fetch_all.return_value = [
            ("mem-1", "Content", "Summary", "fact", 0.9, 0.85, None, "manual", _dt(1)),
        ]
        result = _search_memory("query", None, 10, 0, db, config, mind)
        assert result[0]["tags"] == []
        assert isinstance(result[0]["tags"], list)

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1, 0.2])
    def test_empty_results_returns_list(self, mock_emb):
        db, config, mind = self._make_deps()
        db.fetch_all.return_value = []
        result = _search_memory("query", None, 10, 0, db, config, mind)
        assert isinstance(result, list)
        assert len(result) == 0

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=None)
    def test_embedding_down_returns_service_unavailable(self, mock_emb):
        """Per spec: returns SERVICE_UNAVAILABLE error when embedding service is down."""
        db, config, mind = self._make_deps()
        result = _search_memory("query", None, 10, 0, db, config, mind)
        assert isinstance(result, dict)
        assert result["error"] is True
        assert result["code"] == "SERVICE_UNAVAILABLE"

    def test_error_no_active_mind(self):
        db, config, _ = self._make_deps()
        result = _search_memory("query", None, 10, 0, db, config, None)
        assert_error_shape(result, "NO_ACTIVE_MIND")

    def test_error_empty_query(self):
        db, config, mind = self._make_deps()
        result = _search_memory("", None, 10, 0, db, config, mind)
        assert_error_shape(result, "INVALID_QUERY")

    def test_error_whitespace_query(self):
        db, config, mind = self._make_deps()
        result = _search_memory("   ", None, 10, 0, db, config, mind)
        assert_error_shape(result, "INVALID_QUERY")


# ---------------------------------------------------------------------------
# 5. quick_note
# ---------------------------------------------------------------------------

class TestQuickNoteContract:
    """Verify quick_note response shape matches MCP_TOOLS.md contract."""

    EXPECTED_KEYS = {
        "memory_id": str,
        "mind_id": str,
    }

    def _make_deps(self, mind=("mind-1", "Acme")):
        db = MagicMock()
        config = MagicMock()
        config.embedding_url = "http://localhost:8400"
        return db, config, mind

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.5])
    def test_success_shape(self, mock_emb):
        db, config, mind = self._make_deps()
        db.execute_returning.return_value = ("note-uuid",)
        result = _quick_note("Quick thought here", db, config, mind)
        assert_has_keys(result, self.EXPECTED_KEYS)
        assert "error" not in result

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=None)
    def test_success_shape_without_embedding(self, mock_emb):
        db, config, mind = self._make_deps()
        db.execute_returning.return_value = ("note-deg",)
        result = _quick_note("A quick note", db, config, mind)
        assert_has_keys(result, self.EXPECTED_KEYS)
        assert "error" not in result

    def test_success_has_only_expected_keys(self):
        """quick_note returns exactly memory_id and mind_id, nothing extra."""
        with patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.5]):
            db, config, mind = self._make_deps()
            db.execute_returning.return_value = ("note-uuid",)
            result = _quick_note("content", db, config, mind)
            assert set(result.keys()) == {"memory_id", "mind_id"}

    def test_error_no_active_mind(self):
        db, config, _ = self._make_deps()
        result = _quick_note("note", db, config, None)
        assert_error_shape(result, "NO_ACTIVE_MIND")

    def test_error_empty_content(self):
        db, config, mind = self._make_deps()
        result = _quick_note("", db, config, mind)
        assert_error_shape(result, "INVALID_INPUT")

    def test_error_content_too_long(self):
        db, config, mind = self._make_deps()
        result = _quick_note("x" * 10001, db, config, mind)
        assert_error_shape(result, "INVALID_INPUT")


# ---------------------------------------------------------------------------
# 6. hide_memory
# ---------------------------------------------------------------------------

_MEM_UUID = "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
_MEM_UUID_2 = "b2c3d4e5-f6a7-8901-bcde-f12345678901"


class TestHideMemoryContract:
    """Verify hide_memory response shape matches MCP_TOOLS.md contract."""

    EXPECTED_KEYS = {
        "memory_id": str,
        "hidden": bool,
        "summary": str,
    }

    def test_success_shape(self):
        db = MagicMock()
        db.fetch_one.return_value = (_MEM_UUID, "Summary text")
        mind = ("mind-1", "Acme")
        result = _hide_memory(_MEM_UUID, db, mind)
        assert_has_keys(result, self.EXPECTED_KEYS)
        assert result["hidden"] is True  # must always be True on success
        assert "error" not in result

    def test_hidden_is_always_true(self):
        """The contract specifies hidden must be True on success."""
        db = MagicMock()
        db.fetch_one.return_value = (_MEM_UUID_2, "Some summary")
        mind = ("mind-1", "Acme")
        result = _hide_memory(_MEM_UUID_2, db, mind)
        assert result["hidden"] is True
        assert isinstance(result["hidden"], bool)

    def test_error_no_active_mind(self):
        db = MagicMock()
        result = _hide_memory(_MEM_UUID, db, None)
        assert_error_shape(result, "NO_ACTIVE_MIND")

    def test_idempotent_already_hidden_returns_success(self):
        """Per spec: hiding an already-hidden memory returns success (idempotent)."""
        db = MagicMock()
        # fetch_one finds the memory regardless of is_current status
        db.fetch_one.return_value = (_MEM_UUID, "Already hidden summary")
        mind = ("mind-1", "Acme")
        result = _hide_memory(_MEM_UUID, db, mind)
        assert_has_keys(result, self.EXPECTED_KEYS)
        assert result["hidden"] is True
        assert "error" not in result

    def test_error_memory_not_found(self):
        db = MagicMock()
        db.fetch_one.return_value = None
        mind = ("mind-1", "Acme")
        result = _hide_memory(_MEM_UUID, db, mind)
        assert_error_shape(result, "MEMORY_NOT_FOUND")


# ---------------------------------------------------------------------------
# 7. get_brand_voice
# ---------------------------------------------------------------------------

class TestGetBrandVoiceContract:
    """Verify get_brand_voice response shape matches MCP_TOOLS.md contract."""

    EXPECTED_KEYS = {
        "name": str,
        "brand_voice": dict,
        "brand_positioning": dict,
        "approved_messaging": dict,
        "stakeholders": list,
        "content_themes": list,
    }

    def test_success_shape_populated(self):
        db = MagicMock()
        db.fetch_one.return_value = (
            "Acme Corp",
            json.dumps({"tone": ["casual"]}),
            json.dumps({"category": "API platform"}),
            json.dumps({"elevator_pitch": "We do things"}),
            json.dumps([{"name": "Sarah", "title": "VP"}]),
            ["dev education", "tutorials"],
        )
        mind = ("mind-1", "Acme Corp")
        result = _get_brand_voice(db, mind)
        assert_has_keys(result, self.EXPECTED_KEYS)
        assert "error" not in result

    def test_success_shape_empty_defaults(self):
        """When all brand DNA fields are empty, types must still be correct."""
        db = MagicMock()
        db.fetch_one.return_value = ("New Client", "{}", "{}", "{}", None, None)
        mind = ("mind-1", "New Client")
        result = _get_brand_voice(db, mind)
        assert_has_keys(result, self.EXPECTED_KEYS)
        assert result["brand_voice"] == {}
        assert result["brand_positioning"] == {}
        assert result["approved_messaging"] == {}
        assert result["stakeholders"] == []
        assert result["content_themes"] == []

    def test_error_no_active_mind(self):
        db = MagicMock()
        result = _get_brand_voice(db, None)
        assert_error_shape(result, "NO_ACTIVE_MIND")


# ---------------------------------------------------------------------------
# 8. set_brand_voice
# ---------------------------------------------------------------------------

class TestSetBrandVoiceContract:
    """Verify set_brand_voice response shape matches MCP_TOOLS.md contract."""

    EXPECTED_KEYS = {
        "name": str,
        "brand_voice": dict,
        "brand_positioning": dict,
        "approved_messaging": dict,
        "stakeholders": list,
        "content_themes": list,
        "previous": dict,
    }

    def _make_db_with_connection(self):
        """Create a mock db that supports the connection() context manager."""
        db = MagicMock()
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_conn.cursor.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)
        db.connection.return_value.__enter__ = MagicMock(return_value=mock_conn)
        db.connection.return_value.__exit__ = MagicMock(return_value=False)
        db._mock_cursor = mock_cursor  # expose for tests
        return db

    def test_success_shape_with_previous(self):
        db = self._make_db_with_connection()
        # Current values read via cursor inside transaction
        db._mock_cursor.fetchone.return_value = (
            "Acme Corp",
            json.dumps({"tone": ["formal"]}),
            json.dumps({}),
            json.dumps({}),
            json.dumps([]),
            [],
        )
        # After update, read new values via db.fetch_one
        db.fetch_one.return_value = (
            "Acme Corp",
            json.dumps({"tone": ["casual", "direct"]}),
            json.dumps({}),
            json.dumps({}),
            json.dumps([]),
            [],
        )
        mind = ("mind-1", "Acme Corp")
        result = _set_brand_voice(
            {"brand_voice": {"tone": ["casual", "direct"]}},
            db, mind,
        )
        assert_has_keys(result, self.EXPECTED_KEYS)
        assert "error" not in result

        # previous contains only changed fields with old values
        assert isinstance(result["previous"], dict)
        assert "brand_voice" in result["previous"]

    def test_previous_only_contains_changed_fields(self):
        """When updating only brand_voice, previous should contain only brand_voice."""
        db = self._make_db_with_connection()
        # Current values read via cursor inside transaction
        db._mock_cursor.fetchone.return_value = (
            "Acme Corp",
            json.dumps({"tone": ["formal"]}),
            json.dumps({"category": "SaaS"}),
            json.dumps({}),
            json.dumps([]),
            [],
        )
        # After update, read new values via db.fetch_one
        db.fetch_one.return_value = (
            "Acme Corp",
            json.dumps({"tone": ["casual"]}),
            json.dumps({"category": "SaaS"}),
            json.dumps({}),
            json.dumps([]),
            [],
        )
        mind = ("mind-1", "Acme Corp")
        result = _set_brand_voice(
            {"brand_voice": {"tone": ["casual"]}},
            db, mind,
        )
        assert "brand_voice" in result["previous"]
        # Only the changed field should be in previous
        assert len(result["previous"]) == 1

    def test_error_no_active_mind(self):
        db = MagicMock()
        result = _set_brand_voice({"brand_voice": {"tone": ["casual"]}}, db, None)
        assert_error_shape(result, "NO_ACTIVE_MIND")

    def test_error_no_valid_fields(self):
        db = MagicMock()
        mind = ("mind-1", "Acme")
        result = _set_brand_voice({}, db, mind)
        assert_error_shape(result, "INVALID_INPUT")

    def test_error_unknown_fields_only(self):
        db = MagicMock()
        mind = ("mind-1", "Acme")
        result = _set_brand_voice({"unknown_key": "value"}, db, mind)
        assert_error_shape(result, "INVALID_INPUT")

    def test_error_invalid_brand_voice_shape(self):
        db = MagicMock()
        mind = ("mind-1", "Acme")
        result = _set_brand_voice(
            {"brand_voice": {"avoid": ["jargon"]}},  # missing tone
            db, mind,
        )
        assert_error_shape(result, "INVALID_BRAND_DNA")

    def test_error_invalid_brand_positioning_shape(self):
        db = MagicMock()
        mind = ("mind-1", "Acme")
        result = _set_brand_voice(
            {"brand_positioning": {"target_market": "SaaS"}},  # missing category
            db, mind,
        )
        assert_error_shape(result, "INVALID_BRAND_DNA")

    def test_error_invalid_stakeholders_shape(self):
        db = MagicMock()
        mind = ("mind-1", "Acme")
        result = _set_brand_voice(
            {"stakeholders": [{"title": "VP"}]},  # missing name
            db, mind,
        )
        assert_error_shape(result, "INVALID_BRAND_DNA")


# ---------------------------------------------------------------------------
# 9. prep_meeting
# ---------------------------------------------------------------------------

class TestPrepMeetingContract:
    """Verify prep_meeting response shape matches MCP_TOOLS.md contract."""

    BASE_KEYS = {
        "client_name": str,
        "memories_by_type": dict,
        "stakeholders": list,
        "brand_voice": dict,
        "memory_count": int,
        "cadence": dict,
        "mode": str,
        "reason": None,        # str or None -- checked per mode
        "brief_markdown": None,  # str or None -- checked per mode
    }

    VALID_MODES = {"structured", "raw"}
    VALID_RAW_REASONS = {"llm_unavailable", "insufficient_data"}

    def _make_config(self):
        config = MagicMock()
        config.ollama_url = "http://localhost:11434"
        config.ollama_model = "gemma3:12b"
        config.embedding_url = "http://localhost:8400"
        config.llm_provider = "ollama"
        config.embedding_provider = "local"
        config.embedding_dims = 384
        config.max_prompt_chars = 13000
        return config

    def _make_context_row(self, name="Acme", brand_voice=None, brand_positioning=None,
                          approved_messaging=None, stakeholders=None, content_themes=None,
                          cadence=None, company_info=None):
        """Build an 8-column context_row tuple for _prep_meeting's db.fetch_one."""
        return (
            name,
            brand_voice or "{}",
            brand_positioning or "{}",
            approved_messaging or "{}",
            stakeholders or "[]",
            content_themes or [],
            cadence,
            company_info,
        )

    def _mem_row(self, mid, content, summary, mtype, dt_val, embedding=None,
                 quarter_year=None, quarter=None, sprint=None):
        """Build a 9-column memory row for _collect_meeting_memories DB queries."""
        return (mid, content, summary, mtype, dt_val, embedding, quarter_year, quarter, sprint)

    def test_synthesized_mode_shape(self):
        db = MagicMock()
        config = self._make_config()

        # fetch_one calls: context_row (8 cols), then cadence from _get_mind_cadence (1 col)
        db.fetch_one.side_effect = [
            self._make_context_row(
                name="Acme",
                brand_voice=json.dumps({"tone": ["casual"]}),
                stakeholders=json.dumps([{"name": "Sarah"}]),
            ),
            (None,),  # cadence lookup from _get_mind_cadence
        ]

        # fetch_all calls from _collect_meeting_memories:
        # 1. agenda items, 2. commitments, 3. permanent knowledge, 4. backfill
        db.fetch_all.side_effect = [
            [],  # agenda items
            [    # commitments
                self._mem_row("m1", "c1", "s1", "commitment", _dt(1)),
                self._mem_row("m2", "c2", "s2", "commitment", _dt(2)),
            ],
            [    # permanent knowledge
                self._mem_row("m3", "c3", "s3", "fact", _dt(3)),
                self._mem_row("m4", "c4", "s4", "stakeholder", _dt(4)),
            ],
            [],  # backfill
        ]
        mind = ("mind-1", "Acme")
        result = _prep_meeting(None, None, 50, db, config, mind)

        # Check all base keys exist
        for key in self.BASE_KEYS:
            assert key in result, f"Missing key: {key}"

        assert result["mode"] == "structured"
        assert result["mode"] in self.VALID_MODES
        assert isinstance(result["brief_markdown"], str)  # must be str when structured
        assert result["reason"] is None  # must be None when structured
        assert isinstance(result["client_name"], str)
        assert isinstance(result["memories_by_type"], dict)
        assert isinstance(result["stakeholders"], list)
        assert isinstance(result["brand_voice"], dict)
        assert isinstance(result["memory_count"], int)
        assert isinstance(result["cadence"], dict)
        assert "error" not in result

    def test_raw_mode_insufficient_data_shape(self):
        db = MagicMock()
        config = self._make_config()

        # fetch_one: context_row then cadence
        db.fetch_one.side_effect = [
            self._make_context_row(),
            (None,),  # cadence
        ]

        # fetch_all from _collect_meeting_memories:
        # agenda, commitments, permanent, backfill
        db.fetch_all.side_effect = [
            [],  # agenda
            [self._mem_row("m1", "c1", "s1", "commitment", _dt(1))],  # commitments (1 memory)
            [],  # permanent
            [],  # backfill
        ]
        mind = ("mind-1", "Acme")
        result = _prep_meeting(None, None, 50, db, config, mind)

        for key in self.BASE_KEYS:
            assert key in result, f"Missing key: {key}"

        assert result["mode"] == "raw"
        assert result["mode"] in self.VALID_MODES
        assert result["reason"] == "insufficient_data"
        assert result["reason"] in self.VALID_RAW_REASONS
        assert result["brief_markdown"] is None
        assert isinstance(result["client_name"], str)
        assert isinstance(result["memory_count"], int)

    def test_structured_mode_with_enough_memories_shape(self):
        db = MagicMock()
        config = self._make_config()

        # fetch_one: context_row then cadence
        db.fetch_one.side_effect = [
            self._make_context_row(),
            (None,),  # cadence
        ]

        # fetch_all from _collect_meeting_memories:
        # agenda, commitments, permanent, backfill
        db.fetch_all.side_effect = [
            [],  # agenda
            [],  # commitments
            [    # permanent -- 4 memories to exceed MIN_MEMORIES_FOR_SYNTHESIS
                self._mem_row("m1", "c1", "s1", "fact", _dt(1)),
                self._mem_row("m2", "c2", "s2", "fact", _dt(2)),
                self._mem_row("m3", "c3", "s3", "preference", _dt(3)),
                self._mem_row("m4", "c4", "s4", "stakeholder", _dt(4)),
            ],
            [],  # backfill
        ]
        mind = ("mind-1", "Acme")
        result = _prep_meeting(None, None, 50, db, config, mind)

        for key in self.BASE_KEYS:
            assert key in result, f"Missing key: {key}"

        assert result["mode"] == "structured"
        assert result["reason"] is None
        assert result["brief_markdown"] is not None

    def test_error_no_active_mind(self):
        db = MagicMock()
        config = self._make_config()
        result = _prep_meeting(None, None, 50, db, config, None)
        assert_error_shape(result, "NO_ACTIVE_MIND")

    def test_memories_by_type_item_shape(self):
        """Each item in memories_by_type values should have summary and created_at."""
        db = MagicMock()
        config = self._make_config()

        # fetch_one: context_row then cadence
        db.fetch_one.side_effect = [
            self._make_context_row(
                brand_voice=json.dumps({"tone": ["casual"]}),
                stakeholders=json.dumps([]),
            ),
            (None,),  # cadence
        ]

        # fetch_all from _collect_meeting_memories:
        # agenda, commitments, permanent, backfill
        db.fetch_all.side_effect = [
            [],  # agenda
            [],  # commitments
            [    # permanent -- 3 memories
                self._mem_row("m1", "c1", "summary1", "fact", _dt(1)),
                self._mem_row("m2", "c2", "summary2", "fact", _dt(2)),
                self._mem_row("m3", "c3", "summary3", "preference", _dt(3)),
            ],
            [],  # backfill
        ]
        mind = ("mind-1", "Acme")
        result = _prep_meeting(None, None, 50, db, config, mind)

        for mem_type, items in result["memories_by_type"].items():
            assert isinstance(mem_type, str)
            assert isinstance(items, list)
            for item in items:
                assert "summary" in item
                assert "created_at" in item
                assert isinstance(item["summary"], str)
                # created_at is str or None
                if item["created_at"] is not None:
                    assert isinstance(item["created_at"], str)


# ---------------------------------------------------------------------------
# 10. get_campaign_history
# ---------------------------------------------------------------------------

class TestGetCampaignHistoryContract:
    """Verify get_campaign_history response shape matches MCP_TOOLS.md contract."""

    EXPECTED_ITEM_KEYS = {
        "memory_id": str,
        "content": str,
        "summary": str,
        "tags": list,
        "created_at": None,  # str or None
    }

    def test_success_shape_with_results(self):
        db = MagicMock()
        db.fetch_all.return_value = [
            ("mem-1", "Q1 email: 34% open rate", "Q1 email results",
             ["email"], _dt(5)),
            ("mem-2", "Q2 social: 12% engagement", "Q2 social results",
             ["social", "q2"], _dt(7)),
        ]
        mind = ("mind-1", "Acme")
        result = _get_campaign_history(10, 0, db, mind)

        assert isinstance(result, list)
        assert len(result) == 2

        for item in result:
            assert isinstance(item, dict)
            for key, expected_type in self.EXPECTED_ITEM_KEYS.items():
                assert key in item, f"Missing key: {key}"
                if expected_type is not None:
                    assert isinstance(item[key], expected_type), (
                        f"Key '{key}' expected {expected_type.__name__}, "
                        f"got {type(item[key]).__name__}"
                    )
            # created_at should be str when present
            assert isinstance(item["created_at"], str)

    def test_success_shape_nullable_created_at(self):
        db = MagicMock()
        db.fetch_all.return_value = [
            ("mem-1", "content", "summary", ["tag"], None),
        ]
        mind = ("mind-1", "Acme")
        result = _get_campaign_history(10, 0, db, mind)
        assert result[0]["created_at"] is None

    def test_success_shape_null_tags_returns_empty_list(self):
        db = MagicMock()
        db.fetch_all.return_value = [
            ("mem-1", "content", "summary", None, _dt(5)),
        ]
        mind = ("mind-1", "Acme")
        result = _get_campaign_history(10, 0, db, mind)
        assert result[0]["tags"] == []
        assert isinstance(result[0]["tags"], list)

    def test_empty_list_shape(self):
        db = MagicMock()
        db.fetch_all.return_value = []
        mind = ("mind-1", "Acme")
        result = _get_campaign_history(10, 0, db, mind)
        assert isinstance(result, list)
        assert len(result) == 0

    def test_return_type_is_list_not_dict_on_success(self):
        db = MagicMock()
        db.fetch_all.return_value = []
        mind = ("mind-1", "Acme")
        result = _get_campaign_history(10, 0, db, mind)
        assert not isinstance(result, dict)

    def test_error_no_active_mind(self):
        db = MagicMock()
        result = _get_campaign_history(10, 0, db, None)
        assert_error_shape(result, "NO_ACTIVE_MIND")


# ---------------------------------------------------------------------------
# Error Response Contract — all 9 error helpers
# ---------------------------------------------------------------------------

class TestErrorResponseContract:
    """Verify all error helpers in errors.py produce valid error shapes."""

    def test_no_active_mind_shape(self):
        result = NO_ACTIVE_MIND()
        assert_error_shape(result, "NO_ACTIVE_MIND")

    def test_invalid_input_shape(self):
        result = INVALID_INPUT("test message")
        assert_error_shape(result, "INVALID_INPUT")

    def test_mind_not_found_shape(self):
        result = MIND_NOT_FOUND()
        assert_error_shape(result, "MIND_NOT_FOUND")

    def test_mind_not_found_directs_to_list_minds(self):
        result = MIND_NOT_FOUND()
        assert_error_shape(result, "MIND_NOT_FOUND")

    def test_mind_archived_shape(self):
        result = MIND_ARCHIVED("Old Client")
        assert_error_shape(result, "MIND_ARCHIVED")

    def test_invalid_memory_type_shape(self):
        result = INVALID_MEMORY_TYPE("bad_type")
        assert_error_shape(result, "INVALID_MEMORY_TYPE")

    def test_invalid_brand_dna_shape(self):
        result = INVALID_BRAND_DNA("tone must be a list")
        assert_error_shape(result, "INVALID_BRAND_DNA")

    def test_service_unavailable_shape(self):
        result = SERVICE_UNAVAILABLE("Ollama")
        assert_error_shape(result, "SERVICE_UNAVAILABLE")

    def test_memory_not_found_shape(self):
        result = MEMORY_NOT_FOUND("mem-123")
        assert_error_shape(result, "MEMORY_NOT_FOUND")

    def test_invalid_query_shape(self):
        result = INVALID_QUERY()
        assert_error_shape(result, "INVALID_QUERY")

    def test_tool_error_generic_shape(self):
        result = tool_error("CUSTOM_CODE", "Custom message")
        assert_error_shape(result, "CUSTOM_CODE")

    def test_all_errors_have_exactly_three_keys(self):
        """Every error response must have exactly error, code, message."""
        errors = [
            NO_ACTIVE_MIND(),
            INVALID_INPUT("msg"),
            MIND_NOT_FOUND(),
            MIND_ARCHIVED("X"),
            INVALID_MEMORY_TYPE("bad"),
            INVALID_BRAND_DNA("err"),
            SERVICE_UNAVAILABLE("svc"),
            MEMORY_NOT_FOUND("id"),
            INVALID_QUERY(),
        ]
        for err in errors:
            assert set(err.keys()) == {"error", "code", "message"}, (
                f"Error with code '{err['code']}' has unexpected keys: {set(err.keys())}"
            )
