"""Tests for embedding_client.py — gateway-only embedding client."""

import httpx
from unittest.mock import patch, MagicMock
from coppermind_cmo.embedding_client import (
    get_embedding, check_health, _get_embedding_gateway,
)


def _gateway_config():
    config = MagicMock()
    config.embedding_provider = "gateway"
    config.gateway_url = "https://api.coppermind.dev"
    config.api_key = "test-key"
    config.embedding_dims = 512
    return config


class TestGetEmbedding:
    def test_returns_embedding_on_success(self):
        config = _gateway_config()
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        valid_emb = [0.1] * 512
        mock_resp.json.return_value = {"embedding": valid_emb, "dimensions": 512}
        mock_resp.raise_for_status = MagicMock()

        with patch("coppermind_cmo.embedding_client.httpx") as mock_httpx:
            mock_httpx.post.return_value = mock_resp
            result = get_embedding("hello world", config)
            assert result == valid_emb

    def test_returns_none_on_connection_error(self):
        config = _gateway_config()
        with patch("coppermind_cmo.embedding_client.httpx") as mock_httpx:
            mock_httpx.post.side_effect = Exception("Connection refused")
            result = get_embedding("hello", config)
            assert result is None

    def test_returns_none_on_timeout(self):
        config = _gateway_config()
        with patch("coppermind_cmo.embedding_client.httpx") as mock_httpx:
            mock_httpx.post.side_effect = httpx.TimeoutException("timeout")
            result = get_embedding("hello", config)
            assert result is None


class TestCheckHealth:
    def test_healthy_gateway(self):
        config = _gateway_config()
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        with patch("coppermind_cmo.embedding_client.httpx") as mock_httpx:
            mock_httpx.get.return_value = mock_resp
            assert check_health(config) is True

    def test_unhealthy_gateway(self):
        config = _gateway_config()
        with patch("coppermind_cmo.embedding_client.httpx") as mock_httpx:
            mock_httpx.get.side_effect = Exception("unreachable")
            assert check_health(config) is False

    def test_non_200_returns_false(self):
        config = _gateway_config()
        mock_resp = MagicMock()
        mock_resp.status_code = 503
        with patch("coppermind_cmo.embedding_client.httpx") as mock_httpx:
            mock_httpx.get.return_value = mock_resp
            assert check_health(config) is False


class TestStructuredLogging:
    def test_embedding_client_uses_tool_logger(self):
        """embedding_client.py must use ToolLogger, not stdlib logging."""
        from coppermind_cmo.embedding_client import logger
        from coppermind_cmo.log import ToolLogger
        assert isinstance(logger, ToolLogger)


class TestEmbeddingValidation:
    @patch("coppermind_cmo.embedding_client.httpx")
    def test_non_list_embedding_returns_none(self, mock_httpx):
        config = _gateway_config()
        mock_resp = MagicMock()
        mock_resp.json.return_value = {"embedding": "not-a-list"}
        mock_resp.raise_for_status = MagicMock()
        mock_httpx.post.return_value = mock_resp
        assert get_embedding("test", config) is None

    @patch("coppermind_cmo.embedding_client.httpx")
    def test_empty_embedding_returns_none(self, mock_httpx):
        config = _gateway_config()
        mock_resp = MagicMock()
        mock_resp.json.return_value = {"embedding": []}
        mock_resp.raise_for_status = MagicMock()
        mock_httpx.post.return_value = mock_resp
        assert get_embedding("test", config) is None

    @patch("coppermind_cmo.embedding_client.httpx")
    def test_wrong_dimension_returns_none(self, mock_httpx):
        config = _gateway_config()
        mock_resp = MagicMock()
        # Gateway returns 256 dims but config expects 512
        mock_resp.json.return_value = {"embedding": [0.1] * 256, "dimensions": 512}
        mock_resp.raise_for_status = MagicMock()
        mock_httpx.post.return_value = mock_resp
        assert get_embedding("test", config) is None

    @patch("coppermind_cmo.embedding_client.httpx")
    def test_non_numeric_elements_returns_none(self, mock_httpx):
        config = _gateway_config()
        mock_resp = MagicMock()
        mock_resp.json.return_value = {"embedding": ["a", "b", "c"]}
        mock_resp.raise_for_status = MagicMock()
        mock_httpx.post.return_value = mock_resp
        assert get_embedding("test", config) is None

    @patch("coppermind_cmo.embedding_client.httpx")
    def test_valid_embedding_returns_list(self, mock_httpx):
        config = _gateway_config()
        mock_resp = MagicMock()
        valid_emb = [0.1] * 512
        mock_resp.json.return_value = {"embedding": valid_emb, "dimensions": 512}
        mock_resp.raise_for_status = MagicMock()
        mock_httpx.post.return_value = mock_resp
        assert get_embedding("test", config) == valid_emb


class TestGatewayEmbedding:
    @patch("coppermind_cmo.embedding_client.httpx")
    def test_gateway_embedding_success(self, mock_httpx):
        config = _gateway_config()
        mock_resp = MagicMock()
        valid_emb = [0.1] * 512
        mock_resp.json.return_value = {"embedding": valid_emb, "dimensions": 512}
        mock_resp.raise_for_status = MagicMock()
        mock_httpx.post.return_value = mock_resp
        result = get_embedding("test", config)
        assert result == valid_emb

    @patch("coppermind_cmo.embedding_client.httpx")
    def test_gateway_embedding_failure(self, mock_httpx):
        config = _gateway_config()
        mock_httpx.post.side_effect = Exception("gateway down")
        result = get_embedding("test", config)
        assert result is None

    @patch("coppermind_cmo.embedding_client.httpx")
    def test_gateway_sends_auth_header(self, mock_httpx):
        config = _gateway_config()
        mock_resp = MagicMock()
        mock_resp.json.return_value = {"embedding": [0.1] * 512, "dimensions": 512}
        mock_resp.raise_for_status = MagicMock()
        mock_httpx.post.return_value = mock_resp
        get_embedding("test", config)
        call_kwargs = mock_httpx.post.call_args
        assert "Authorization" in call_kwargs.kwargs.get("headers", {})
