"""Tests for raw document preservation (schema 011)."""

import hashlib
from unittest.mock import MagicMock, patch, call

import pytest

import coppermind_cmo.ingest as ingest_mod
from coppermind_cmo.ingest import _store_raw_document, _has_raw_documents_table


@pytest.fixture(autouse=True)
def reset_table_cache():
    """Reset the cached table check between tests."""
    ingest_mod._has_raw_docs_table = None
    yield
    ingest_mod._has_raw_docs_table = None


@pytest.fixture
def mock_db_with_table():
    """Mock DB where raw_documents table exists."""
    db = MagicMock()
    # Default: table exists, no existing doc
    db.fetch_one.side_effect = lambda sql, params=None: (
        (1,) if "information_schema" in sql else None
    )
    db.execute_returning.return_value = ("new-doc-uuid",)
    return db


@pytest.fixture
def mock_db_without_table():
    """Mock DB where raw_documents table does NOT exist."""
    db = MagicMock()
    db.fetch_one.return_value = None  # table check returns None
    return db


class TestStoreRawDocument:
    def test_stores_full_text(self, mock_db_with_table):
        """Stores full text, returns doc ID."""
        doc_id = _store_raw_document("Hello world content", "mind-1", mock_db_with_table)
        assert doc_id == "new-doc-uuid"
        # Verify INSERT was called with the full content
        insert_call = mock_db_with_table.execute_returning.call_args
        assert "INSERT INTO raw_documents" in insert_call[0][0]
        params = insert_call[0][1]
        assert params[1] == "Hello world content"  # content
        assert params[0] == "mind-1"  # mind_id

    def test_dedup_same_content(self, mock_db_with_table):
        """Same text twice returns same ID, only one row."""
        text = "Duplicate content"
        content_hash = hashlib.sha256(text.encode()).hexdigest()

        # First call: table exists, no existing doc
        ingest_mod._has_raw_docs_table = True
        mock_db_with_table.fetch_one.side_effect = None
        mock_db_with_table.fetch_one.return_value = None  # no existing
        mock_db_with_table.execute_returning.return_value = ("doc-1",)

        doc_id_1 = _store_raw_document(text, "mind-1", mock_db_with_table)

        # Second call: existing doc found
        mock_db_with_table.fetch_one.return_value = ("doc-1",)
        doc_id_2 = _store_raw_document(text, "mind-1", mock_db_with_table)

        assert doc_id_1 == "doc-1"
        assert doc_id_2 == "doc-1"
        # INSERT should only be called once
        assert mock_db_with_table.execute_returning.call_count == 1

    def test_different_minds_not_deduped(self, mock_db_with_table):
        """Same text, different minds, two rows."""
        text = "Same content"
        ingest_mod._has_raw_docs_table = True
        mock_db_with_table.fetch_one.return_value = None  # no existing
        mock_db_with_table.execute_returning.side_effect = [("doc-1",), ("doc-2",)]

        doc_id_1 = _store_raw_document(text, "mind-1", mock_db_with_table)
        doc_id_2 = _store_raw_document(text, "mind-2", mock_db_with_table)

        assert doc_id_1 == "doc-1"
        assert doc_id_2 == "doc-2"
        assert mock_db_with_table.execute_returning.call_count == 2

    def test_word_count_calculated(self):
        """500-word text stores word_count=500."""
        text = " ".join(["word"] * 500)
        db = MagicMock()
        ingest_mod._has_raw_docs_table = True
        db.fetch_one.return_value = None
        db.execute_returning.return_value = ("doc-1",)

        _store_raw_document(text, "mind-1", db)

        params = db.execute_returning.call_args[0][1]
        assert params[5] == 500  # word_count


class TestExtractionPassIncremented:
    def test_pass_incremented_after_extraction(self):
        """After extraction, passes = 1."""
        db = MagicMock()
        ingest_mod._has_raw_docs_table = True
        # Table check: exists
        # Store raw doc: no existing
        # IngestEngine queries
        fetch_one_calls = iter([
            None,  # no existing raw doc
            ("source-id",),  # _get_or_create_source
        ])
        db.fetch_one.side_effect = lambda sql, params=None: next(fetch_one_calls, None)
        db.execute_returning.side_effect = [
            ("raw-doc-id",),  # raw doc insert
            ("mem-1",),  # memory insert
        ]
        db.fetch_all.return_value = []  # no existing chunks

        config = MagicMock()
        config.max_prompt_chars = 13000

        with patch("coppermind_cmo.ingest.extract_memories_from_chunk") as mock_extract, \
             patch("coppermind_cmo.ingest._store_memory") as mock_store:
            mock_extract.return_value = [{"content": "A decision", "memory_type": "decision", "confidence": 0.9}]
            mock_store.return_value = {"memory_id": "mem-1"}

            from coppermind_cmo.ingest import IngestEngine
            engine = IngestEngine(db, config, ("mind-1", "Test"))
            result = engine.process_source("meeting", "ref-1", "Some content here.")

        # Verify extraction pass update was called
        update_calls = [c for c in db.execute.call_args_list
                        if "UPDATE raw_documents" in str(c)]
        assert len(update_calls) == 1
        assert "extraction_passes = extraction_passes + 1" in update_calls[0][0][0]


class TestIngestStoresRawDocument:
    def test_process_source_stores_raw(self):
        """Full IngestEngine.process_source() stores in raw_documents."""
        db = MagicMock()
        ingest_mod._has_raw_docs_table = True
        # fetch_one calls: raw doc check, get_or_create_source, _check_hash per chunk
        db.fetch_one.side_effect = [
            None,  # no existing raw doc
            ("source-id",),  # _get_or_create_source
            None,  # _check_hash (chunk not seen before)
        ]
        db.execute_returning.side_effect = [
            ("raw-doc-id",),  # raw doc INSERT
        ]

        config = MagicMock()
        config.max_prompt_chars = 13000

        with patch("coppermind_cmo.ingest.extract_memories_from_chunk") as mock_extract:
            mock_extract.return_value = []  # no memories extracted

            from coppermind_cmo.ingest import IngestEngine
            engine = IngestEngine(db, config, ("mind-1", "Test"))
            engine.process_source("meeting", "ref-1", "Short doc content.")

        # Verify raw doc INSERT happened
        insert_calls = [c for c in db.execute_returning.call_args_list
                        if "INSERT INTO raw_documents" in str(c)]
        assert len(insert_calls) == 1


class TestStoreMemoryRawDoc:
    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=None)
    @patch("coppermind_cmo.ingest._store_raw_document")
    def test_long_content_stores_raw(self, mock_store_raw, mock_emb, mock_db, mock_config, active_mind):
        """store_memory with >4000 chars stores raw doc."""
        mock_db.execute_returning.return_value = ("mem-1",)

        from coppermind_cmo.tools.memories import _store_memory
        long_content = "word " * 1000  # >4000 chars

        _store_memory(long_content, None, [], mock_db, mock_config, active_mind,
                      source_type="manual")

        mock_store_raw.assert_called_once()
        call_args = mock_store_raw.call_args[0]
        assert call_args[0] == long_content
        assert call_args[1] == active_mind[0]

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=None)
    @patch("coppermind_cmo.ingest._store_raw_document")
    def test_short_content_skips_raw(self, mock_store_raw, mock_emb, mock_db, mock_config, active_mind):
        """store_memory with <4000 chars does NOT store raw doc."""
        mock_db.execute_returning.return_value = ("mem-1",)

        from coppermind_cmo.tools.memories import _store_memory
        _store_memory("short note", None, [], mock_db, mock_config, active_mind,
                      source_type="manual")

        mock_store_raw.assert_not_called()


class TestGracefulWithoutTable:
    def test_no_table_returns_none(self, mock_db_without_table):
        """No raw_documents table — returns None, no crash."""
        doc_id = _store_raw_document("content", "mind-1", mock_db_without_table)
        assert doc_id is None
        mock_db_without_table.execute_returning.assert_not_called()

    def test_ingest_works_without_table(self):
        """IngestEngine still works when raw_documents table doesn't exist."""
        db = MagicMock()
        ingest_mod._has_raw_docs_table = None
        # First fetch_one: schema check (None = no table), then source lookup
        db.fetch_one.side_effect = [
            None,              # _has_raw_documents_table → table doesn't exist
            ("source-id",),    # _get_or_create_source
            None,              # _check_hash
        ]

        config = MagicMock()
        config.max_prompt_chars = 13000

        with patch("coppermind_cmo.ingest.extract_memories_from_chunk") as mock_extract:
            mock_extract.return_value = []

            from coppermind_cmo.ingest import IngestEngine
            engine = IngestEngine(db, config, ("mind-1", "Test"))
            result = engine.process_source("meeting", "ref-1", "Content here.")

        # Should complete without error
        assert "new" in result
        assert "skipped" in result


class TestListDocuments:
    def test_returns_stored_docs(self):
        """_list_documents returns stored docs with correct fields."""
        from datetime import datetime
        from coppermind_cmo.tools.minds import _list_documents

        db = MagicMock()
        ingest_mod._has_raw_docs_table = True
        db.fetch_all.return_value = [
            ("doc-uuid-1", "meeting", "ref-1", 500, 1,
             datetime(2026, 3, 16, 10, 0), datetime(2026, 3, 15, 9, 0)),
        ]

        result = _list_documents(10, db, ("mind-1", "Test Client"))

        assert len(result) == 1
        assert result[0]["doc_id"] == "doc-uuid-1"
        assert result[0]["word_count"] == 500
        assert result[0]["extraction_passes"] == 1
        assert result[0]["source_type"] == "meeting"

    def test_no_table_returns_message(self):
        """When table doesn't exist, returns message dict."""
        from coppermind_cmo.tools.minds import _list_documents

        db = MagicMock()
        db.fetch_one.return_value = None  # table doesn't exist
        ingest_mod._has_raw_docs_table = None  # force re-check

        result = _list_documents(10, db, ("mind-1", "Test"))
        assert isinstance(result, dict)
        assert "Document storage" in result["message"] or "migration" in result["message"]

    def test_no_active_mind(self):
        """Returns NO_ACTIVE_MIND when no mind is set."""
        from coppermind_cmo.tools.minds import _list_documents

        db = MagicMock()
        result = _list_documents(10, db, None)
        assert result.get("code") == "NO_ACTIVE_MIND"
