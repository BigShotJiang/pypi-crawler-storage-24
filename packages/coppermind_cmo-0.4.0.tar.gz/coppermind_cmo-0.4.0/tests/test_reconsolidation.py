"""Tests for memory reconsolidation — find, merge, update."""

import json
from unittest.mock import MagicMock, patch

import pytest

# Capture the real function before autouse fixtures replace it
from coppermind_cmo.tools.memories import _find_similar_memory as _real_find_similar


RECONSOLIDATION_THRESHOLD = 0.85


class TestFindSimilarMemory:
    @pytest.fixture(autouse=True)
    def enable_find_similar(self, monkeypatch):
        """Restore real _find_similar_memory for these tests."""
        monkeypatch.setattr(
            "coppermind_cmo.tools.memories._find_similar_memory",
            _real_find_similar,
        )
    def test_returns_none_when_no_embedding(self, mock_db, mock_config, active_mind):
        from coppermind_cmo.tools.memories import _find_similar_memory
        result = _find_similar_memory(None, mock_db, active_mind)
        assert result is None

    def test_returns_none_when_no_match_above_threshold(self, mock_db, mock_config, active_mind):
        from coppermind_cmo.tools.memories import _find_similar_memory
        mock_db.fetch_one.return_value = None
        embedding = [0.1] * 384
        result = _find_similar_memory(embedding, mock_db, active_mind)
        assert result is None

    def test_returns_match_above_threshold(self, mock_db, mock_config, active_mind):
        from coppermind_cmo.tools.memories import _find_similar_memory
        mock_db.fetch_one.return_value = (
            "memory-uuid-123",  # id
            "Old content here",  # content
            "Old summary",  # summary
            "decision",  # memory_type
            0.92,  # similarity
        )
        embedding = [0.1] * 384
        result = _find_similar_memory(embedding, mock_db, active_mind)
        assert result is not None
        assert result["memory_id"] == "memory-uuid-123"
        assert result["content"] == "Old content here"
        assert result["similarity"] == 0.92

    def test_queries_correct_mind_id(self, mock_db, mock_config, active_mind):
        from coppermind_cmo.tools.memories import _find_similar_memory
        mock_db.fetch_one.return_value = None
        embedding = [0.1] * 384
        _find_similar_memory(embedding, mock_db, active_mind)
        call_args = mock_db.fetch_one.call_args
        # mind_id should be in the params
        assert active_mind[0] in call_args[0][1]

    def test_only_searches_current_memories(self, mock_db, mock_config, active_mind):
        from coppermind_cmo.tools.memories import _find_similar_memory
        mock_db.fetch_one.return_value = None
        embedding = [0.1] * 384
        _find_similar_memory(embedding, mock_db, active_mind)
        sql = mock_db.fetch_one.call_args[0][0]
        assert "is_current = true" in sql


class TestUpdateMemory:
    def test_updates_content_and_summary(self, mock_db, active_mind):
        from coppermind_cmo.tools.memories import _update_memory
        embedding = [0.1] * 384
        _update_memory(
            "memory-uuid-123",
            "Updated content",
            "Updated summary",
            embedding,
            mock_db,
            active_mind,
        )
        mock_db.execute.assert_called_once()
        sql = mock_db.execute.call_args[0][0]
        assert "UPDATE memories" in sql
        assert "content" in sql
        assert "summary" in sql
        assert "last_accessed_at" in sql
        assert "mind_id" in sql

    def test_does_not_update_created_at(self, mock_db, active_mind):
        from coppermind_cmo.tools.memories import _update_memory
        embedding = [0.1] * 384
        _update_memory("memory-uuid-123", "content", "summary", embedding, mock_db, active_mind)
        sql = mock_db.execute.call_args[0][0]
        assert "created_at" not in sql

    def test_handles_null_embedding(self, mock_db, active_mind):
        from coppermind_cmo.tools.memories import _update_memory
        _update_memory("memory-uuid-123", "content", "summary", None, mock_db, active_mind)
        sql = mock_db.execute.call_args[0][0]
        assert "embedding" not in sql

    def test_includes_mind_id_in_where_clause(self, mock_db, active_mind):
        from coppermind_cmo.tools.memories import _update_memory
        _update_memory("memory-uuid-123", "content", "summary", None, mock_db, active_mind)
        params = mock_db.execute.call_args[0][1]
        assert active_mind[0] in params


class TestStoreMemoryReconsolidation:
    """Test that _store_memory uses reconsolidation."""

    @patch("coppermind_cmo.tools.memories._update_memory")
    @patch("coppermind_cmo.tools.memories._find_similar_memory")
    @patch("coppermind_cmo.tools.memories.get_embedding")
    def test_updates_when_similar_found(
        self, mock_embed, mock_find, mock_update,
        mock_db, mock_config, active_mind,
    ):
        from coppermind_cmo.tools.memories import _store_memory
        mock_embed.return_value = [0.1] * 384
        mock_find.return_value = {
            "memory_id": "existing-uuid",
            "content": "Old content",
            "summary": "Old summary",
            "memory_type": "decision",
            "similarity": 0.92,
        }

        result = _store_memory(
            "New content about same topic",
            None, [], mock_db, mock_config, active_mind,
        )

        mock_find.assert_called_once()
        mock_update.assert_called_once()
        mock_db.execute_returning.assert_not_called()  # No INSERT when reconsolidating
        assert result["memory_id"] == "existing-uuid"
        assert result["reconsolidated"] is True

    @patch("coppermind_cmo.tools.memories._find_similar_memory")
    @patch("coppermind_cmo.tools.memories.get_embedding")
    def test_inserts_when_no_similar_found(
        self, mock_embed, mock_find, mock_db, mock_config, active_mind,
    ):
        from coppermind_cmo.tools.memories import _store_memory
        mock_embed.return_value = [0.1] * 384
        mock_find.return_value = None
        mock_db.execute_returning.return_value = ("new-uuid",)

        result = _store_memory(
            "Brand new content",
            None, [], mock_db, mock_config, active_mind,
        )

        mock_find.assert_called_once()
        assert result["memory_id"] == "new-uuid"
        assert "reconsolidated" not in result or result.get("reconsolidated") is False

    @patch("coppermind_cmo.tools.memories._find_similar_memory")
    @patch("coppermind_cmo.tools.memories.get_embedding")
    def test_skips_reconsolidation_when_no_embedding(
        self, mock_embed, mock_find, mock_db, mock_config, active_mind,
    ):
        from coppermind_cmo.tools.memories import _store_memory
        mock_embed.return_value = None  # embedding service down
        mock_db.execute_returning.return_value = ("new-uuid",)

        result = _store_memory(
            "Some content",
            None, [], mock_db, mock_config, active_mind,
        )

        mock_find.assert_not_called()  # can't search without embedding
        assert result["memory_id"] == "new-uuid"
