"""Tests for PID file management and single-instance enforcement."""

import os
import signal
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

import coppermind_cmo.server as server_mod
from coppermind_cmo.server import (
    _kill_stale_pid, _ensure_single_instance, _cleanup,
    PID_FILE, WATCHER_PID_FILE,
)

# Save real _start_watcher before conftest replaces it
_start_watcher_real = server_mod._start_watcher


@pytest.fixture
def pid_paths(tmp_path, monkeypatch):
    """Override PID file paths to use tmp_path."""
    server_pid = tmp_path / "server.pid"
    watcher_pid = tmp_path / "watcher.pid"
    monkeypatch.setattr(server_mod, "PID_FILE", server_pid)
    monkeypatch.setattr(server_mod, "WATCHER_PID_FILE", watcher_pid)
    return server_pid, watcher_pid


class TestPidFileCreation:
    def test_pid_file_created(self, pid_paths):
        """_ensure_single_instance writes PID file with correct PID."""
        server_pid, _ = pid_paths
        _ensure_single_instance()
        assert server_pid.exists()
        assert int(server_pid.read_text().strip()) == os.getpid()

    def test_pid_file_directory_created(self, tmp_path, monkeypatch):
        """~/.coppermind/ created if missing."""
        nested = tmp_path / "subdir" / "server.pid"
        monkeypatch.setattr(server_mod, "PID_FILE", nested)
        monkeypatch.setattr(server_mod, "WATCHER_PID_FILE", tmp_path / "subdir" / "watcher.pid")
        _ensure_single_instance()
        assert nested.parent.exists()
        assert nested.exists()


class TestPidFileCleanup:
    def test_pid_file_cleaned_on_exit(self, pid_paths):
        """_cleanup removes PID file when PID matches current process."""
        server_pid, _ = pid_paths
        server_pid.write_text(str(os.getpid()))
        _cleanup()
        assert not server_pid.exists()

    def test_cleanup_only_removes_own_pid(self, pid_paths):
        """_cleanup does NOT remove PID file if it contains a different PID."""
        server_pid, _ = pid_paths
        server_pid.write_text("99999999")  # not our PID
        _cleanup()
        assert server_pid.exists()  # should NOT be removed


class TestStalePidHandling:
    def test_stale_pid_file_handled(self, pid_paths):
        """Fake PID (dead process) in PID file — startup succeeds and overwrites."""
        server_pid, _ = pid_paths
        server_pid.write_text("99999999")  # dead PID
        _ensure_single_instance()
        assert int(server_pid.read_text().strip()) == os.getpid()

    @patch("coppermind_cmo.server.os.kill")
    def test_startup_does_not_kill_other_servers(self, mock_kill, pid_paths):
        """Regression: _ensure_single_instance must NOT kill other server PIDs.

        Multiple Claude Code sessions run concurrently, each with its own MCP
        server. Killing another session's server causes 'tools not available'.
        """
        server_pid, _ = pid_paths
        server_pid.write_text("12345")  # another server's PID

        _ensure_single_instance()

        # os.kill should NOT have been called with the server PID
        for call in mock_kill.call_args_list:
            pid_arg = call[0][0]
            assert pid_arg != 12345, "Must not kill another server's PID"

        # Our PID should overwrite the file
        assert int(server_pid.read_text().strip()) == os.getpid()


class TestWatcherPidTracking:
    @patch.dict(os.environ, {"COPPERMIND_WATCHER_ENABLED": "true"})
    def test_watcher_pid_file_created(self, pid_paths):
        """Watcher spawn writes watcher PID file."""
        _, watcher_pid = pid_paths
        mock_proc = MagicMock()
        mock_proc.pid = 54321

        with patch("coppermind_cmo.server.subprocess.Popen", return_value=mock_proc):
            server_mod._watcher_process = None
            _start_watcher_real()

        assert watcher_pid.exists()
        assert int(watcher_pid.read_text().strip()) == 54321

    def test_cleanup_removes_watcher_pid(self, pid_paths):
        """_cleanup removes watcher PID file."""
        server_pid, watcher_pid = pid_paths
        server_pid.write_text(str(os.getpid()))
        watcher_pid.write_text("54321")
        _cleanup()
        assert not watcher_pid.exists()

    @patch("coppermind_cmo.server.os.kill")
    def test_startup_kills_old_watcher(self, mock_kill, pid_paths):
        """Old watcher PID file exists — new startup kills it."""
        server_pid, watcher_pid = pid_paths
        watcher_pid.write_text("67890")

        # kill(67890, 0) succeeds, SIGTERM sent, then dead
        mock_kill.side_effect = [
            None,  # kill(67890, 0) — alive
            None,  # kill(67890, SIGTERM)
            ProcessLookupError,  # kill(67890, 0) — dead
        ]

        _ensure_single_instance()
        # Watcher should have been killed, server PID written
        assert int(server_pid.read_text().strip()) == os.getpid()
