"""Simulate real CMO user journeys after LLM removal.

These tests walk through the exact flows a beta tester would hit,
calling the real tool functions with mocked DB and embedding service.
No LLM mocks anywhere — that's the whole point.
"""

import json
from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

from coppermind_cmo.tools.minds import _switch_client
from coppermind_cmo.tools.memories import _store_memory, _search_memory, _quick_note, _hide_memory
from coppermind_cmo.tools.brand import _set_brand_voice, _get_brand_voice
from coppermind_cmo.tools.intelligence import _prep_meeting


def _dt(day):
    return datetime(2026, 3, day, 10, 0, 0, tzinfo=timezone.utc)


def _make_config():
    config = MagicMock()
    config.embedding_provider = "local"
    config.embedding_url = "http://localhost:8400"
    config.embedding_dims = 384
    config.max_prompt_chars = 13000
    return config


class TestSimulateNewClientOnboarding:
    """Simulate: CMO opens Claude, creates a new client, stores memories,
    preps for a meeting. No LLM calls anywhere."""

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1] * 384)
    def test_full_onboarding_journey(self, mock_emb):
        db = MagicMock()
        config = _make_config()
        mind_state = {}

        def set_mind(mid, mname):
            mind_state["id"] = mid
            mind_state["name"] = mname

        # --- 1. Switch to new client ---
        db.fetch_one.side_effect = [None, None, None]
        db.execute_returning.return_value = ("uuid-acme", "Acme Corp", "acme-corp")
        switch = _switch_client("Acme Corp", True, db, set_mind, customer_id="test-cust")
        assert switch["is_new"] is True
        mind = (mind_state["id"], mind_state["name"])

        # --- 2. Claude provides type + summary (the new way) ---
        db.fetch_one.side_effect = None
        db.fetch_one.return_value = ({"type": "eos", "year": 2026, "quarter": 1},)
        db.execute_returning.return_value = ("mem-1",)
        r1 = _store_memory(
            "Sarah Chen is VP Marketing, reports to CEO, primary contact for all campaigns",
            memory_type="stakeholder",
            summary="Sarah Chen — VP Marketing, primary contact",
            tags=["team"],
            db=db, config=config, active_mind=mind,
        )
        assert r1["memory_id"] == "mem-1"
        assert r1["memory_type"] == "stakeholder"
        assert r1["classified_by"] == "user"
        assert r1["summary"] == "Sarah Chen — VP Marketing, primary contact"

        # --- 3. Store without type/summary (fallback path) ---
        db.execute_returning.return_value = ("mem-2",)
        r2 = _store_memory(
            "They prefer a casual, friendly brand voice",
            None, [],
            db, config, mind,
        )
        assert r2["memory_type"] == "fact"  # default when no type provided
        assert r2["classified_by"] == "default"
        assert r2["summary"] == "They prefer a casual, friendly brand voice"  # content[:100]

        # --- 4. Store a decision with type but no summary ---
        db.execute_returning.return_value = ("mem-3",)
        r3 = _store_memory(
            "We decided to pause LinkedIn ads through Q2 and reallocate budget to content",
            "decision", [],
            db, config, mind,
        )
        assert r3["memory_type"] == "decision"
        assert r3["classified_by"] == "user"
        # Summary should be content[:100]
        assert r3["summary"] == "We decided to pause LinkedIn ads through Q2 and reallocate budget to content"

        # --- 5. Quick note (still works, no LLM) ---
        db.execute_returning.return_value = ("note-1",)
        note = _quick_note("Ask about Q2 revenue targets next call", db, config, mind)
        assert note["memory_id"] == "note-1"

        # --- 6. Search (embeddings still work) ---
        db.fetch_all.return_value = [
            ("mem-1", "Sarah Chen is VP Marketing...", "Sarah Chen — VP Marketing",
             "stakeholder", 1.0, 0.91, ["team"], "manual", _dt(5)),
        ]
        results = _search_memory("who is our contact?", None, 10, 0, db, config, mind)
        assert len(results) == 1
        assert results[0]["memory_type"] == "stakeholder"

        # --- 7. Prep meeting (structured data, no LLM) ---
        db.fetch_one.side_effect = [
            ("Acme Corp", json.dumps({"tone": ["casual"]}), "{}", "{}",
             json.dumps([{"name": "Sarah Chen", "title": "VP Marketing"}]),
             [], json.dumps({"type": "eos", "year": 2026, "quarter": 1}), "{}"),
            ({"type": "eos", "year": 2026, "quarter": 1},),
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            [("mem-3", "We decided to pause LinkedIn ads...", "Pause ads",
              "commitment", _dt(3), None, 2026, 1, None)],  # commitments
            [("mem-1", "Sarah Chen is VP Marketing...", "Sarah Chen",
              "stakeholder", _dt(1), None, 2026, 1, None),
             ("mem-2", "They prefer casual...", "Casual voice",
              "preference", _dt(2), None, 2026, 1, None)],  # permanent
            [],  # backfill
        ]
        brief = _prep_meeting(["Q2 planning"], "planning", 50, db, config, mind)
        assert brief["mode"] == "structured"
        assert brief["reason"] is None
        assert brief["client_name"] == "Acme Corp"
        assert brief["memory_count"] == 3
        assert "# Meeting Brief" in brief["brief_markdown"]
        assert brief["stakeholders"] == [{"name": "Sarah Chen", "title": "VP Marketing"}]
        # Claude Code would now take this structured data and write a polished brief


class TestSimulateTranscriptExtraction:
    """Simulate: CMO pastes a meeting transcript. Claude extracts individual
    memories and calls store_memory for each one with type and summary."""

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.2] * 384)
    def test_transcript_extraction_pattern(self, mock_emb):
        db = MagicMock()
        config = _make_config()
        mind = ("mind-1", "Acme Corp")
        db.fetch_one.return_value = (None,)  # no cadence

        # Simulate what Claude would do: extract 4 memories from a transcript
        extractions = [
            {
                "content": "Sarah confirmed Q2 revenue target is $2.5M",
                "memory_type": "commitment",
                "summary": "Q2 revenue target: $2.5M (confirmed by Sarah)",
            },
            {
                "content": "Team agreed to pause LinkedIn ads and shift budget to SEO",
                "memory_type": "decision",
                "summary": "Pausing LinkedIn ads, shifting to SEO",
            },
            {
                "content": "New CMO Jessica Huang starts April 15, replacing interim lead",
                "memory_type": "stakeholder",
                "summary": "Jessica Huang — new CMO starting April 15",
            },
            {
                "content": "Email campaign hit 42% open rate, best in 6 months",
                "memory_type": "campaign_outcome",
                "summary": "Email open rate 42% — 6-month high",
            },
        ]

        for i, ext in enumerate(extractions):
            db.execute_returning.return_value = (f"mem-{i}",)
            result = _store_memory(
                ext["content"],
                memory_type=ext["memory_type"],
                summary=ext["summary"],
                tags=[],
                db=db, config=config, active_mind=mind,
            )
            assert result["memory_id"] == f"mem-{i}"
            assert result["memory_type"] == ext["memory_type"]
            assert result["summary"] == ext["summary"]
            assert result["classified_by"] == "user"
            assert result["has_embedding"] is True

        # Verify 4 INSERT calls were made
        assert db.execute_returning.call_count == 4


class TestSimulateInvalidTypeGraceful:
    """Simulate: Claude accidentally passes an invalid memory_type.
    Should fall back gracefully, not crash."""

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.3] * 384)
    def test_invalid_type_stores_as_fact(self, mock_emb):
        db = MagicMock()
        config = _make_config()
        mind = ("mind-1", "Acme")
        db.fetch_one.return_value = (None,)
        db.execute_returning.return_value = ("mem-inv",)

        result = _store_memory(
            "Some content here",
            memory_type="meeting_note",  # not a valid type
            summary="A note from the meeting",
            tags=[],
            db=db, config=config, active_mind=mind,
        )
        assert result["memory_type"] == "fact"  # falls back to fact
        assert result["classified_by"] == "default"
        assert result["summary"] == "A note from the meeting"  # summary still used


class TestSimulatePrepMeetingTooFewMemories:
    """Simulate: New client with only 1-2 memories. prep_meeting returns raw mode."""

    def test_raw_mode_with_insufficient_data(self):
        db = MagicMock()
        config = _make_config()
        mind = ("mind-1", "New Client")

        db.fetch_one.side_effect = [
            ("New Client", "{}", "{}", "{}", "[]", [], None, None),
            (None,),
        ]
        db.fetch_all.side_effect = [
            [],  # agenda
            [],  # commitments
            [("m1", "One fact", "One fact", "fact", _dt(1), None, None, None, None)],  # 1 memory
            [],  # backfill
        ]
        result = _prep_meeting(None, None, 50, db, config, mind)
        assert result["mode"] == "raw"
        assert result["reason"] == "insufficient_data"
        assert result["brief_markdown"] is None
        assert result["memory_count"] == 1


class TestSimulateReconsolidationWithoutLLM:
    """Simulate: Store a memory similar to an existing one.
    Should reconsolidate (replace) without LLM confirmation."""

    @patch("coppermind_cmo.tools.memories._find_similar_memory")
    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.5] * 384)
    def test_reconsolidation_replaces_directly(self, mock_emb, mock_find):
        db = MagicMock()
        config = _make_config()
        mind = ("mind-1", "Acme")
        db.fetch_one.return_value = (None,)  # no cadence

        mock_find.return_value = {
            "memory_id": "old-mem-id",
            "content": "LinkedIn ads paused for Q2",
            "summary": "LinkedIn ads paused",
            "memory_type": "decision",
            "similarity": 0.85,
        }

        result = _store_memory(
            "LinkedIn ads paused through Q2, budget moving to content marketing",
            memory_type="decision",
            summary="LinkedIn ads paused, budget → content marketing",
            tags=[],
            db=db, config=config, active_mind=mind,
            skip_reconsolidation=False,
        )

        assert result["reconsolidated"] is True
        assert result["memory_id"] == "old-mem-id"
        assert result["summary"] == "LinkedIn ads paused, budget → content marketing"
        # Should have called UPDATE, not INSERT
        db.execute.assert_called_once()
        db.execute_returning.assert_not_called()


class TestSimulateLongContentStillWorksInline:
    """Simulate: Store content >4000 chars. Should still work inline
    (no background mode since we removed it)."""

    @patch("coppermind_cmo.ingest._store_raw_document")
    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1] * 384)
    def test_long_content_stored_inline(self, mock_emb, mock_store_raw):
        db = MagicMock()
        config = _make_config()
        mind = ("mind-1", "Acme")
        db.fetch_one.return_value = (None,)
        db.execute_returning.return_value = ("mem-long",)

        long_content = "Meeting notes: " + "discussion point. " * 300  # >4000 chars
        result = _store_memory(
            long_content,
            memory_type="fact",
            summary="Extended meeting notes from March planning session",
            tags=["meeting"],
            db=db, config=config, active_mind=mind,
        )

        assert result["memory_id"] == "mem-long"
        assert result["summary"] == "Extended meeting notes from March planning session"
        # Raw document should still be preserved
        mock_store_raw.assert_called_once()
