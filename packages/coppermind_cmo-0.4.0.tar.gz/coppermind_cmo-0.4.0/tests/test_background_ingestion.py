"""Tests for background ingestion: time estimates, progress tracking, and async processing."""

import threading
import time
from unittest.mock import MagicMock, patch

import pytest

from coppermind_cmo.ingest import estimate_ingestion_time, IngestProgress
from coppermind_cmo.background import (
    BackgroundResult,
    start_background_ingestion,
    get_completed_notifications,
    _background_results,
    _background_lock,
)


def _poll_notifications(timeout=5.0):
    """Poll for completed notifications instead of sleep-based sync."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        notifications = get_completed_notifications()
        if notifications:
            return notifications
        time.sleep(0.01)
    return []


@pytest.fixture(autouse=True)
def clear_background_results():
    """Clear background results between tests."""
    with _background_lock:
        _background_results.clear()
    yield
    with _background_lock:
        _background_results.clear()


class TestEstimateIngestionTime:
    def test_estimate_word_count(self):
        """1000 words → correct word_count."""
        text = " ".join(["word"] * 1000)
        estimate = estimate_ingestion_time(text)
        assert estimate["word_count"] == 1000

    def test_estimate_chunks(self):
        """10000 chars → 5 chunks."""
        text = "x" * 10000
        estimate = estimate_ingestion_time(text)
        assert estimate["chunks"] == 5

    def test_estimate_seconds(self):
        """5 chunks → ~15 seconds."""
        text = "x" * 10000
        estimate = estimate_ingestion_time(text)
        assert estimate["estimated_seconds"] == 15

    def test_estimate_minimum_one_chunk(self):
        """Short text → at least 1 chunk."""
        estimate = estimate_ingestion_time("hello")
        assert estimate["chunks"] == 1
        assert estimate["estimated_seconds"] == 3


class TestIngestProgress:
    def test_initial_state(self):
        estimate = {"word_count": 100, "chunks": 3, "estimated_seconds": 9}
        progress = IngestProgress(total_chunks=3, estimate=estimate)
        assert progress.completed_chunks == 0
        assert progress.memories_found == 0
        assert progress.by_type == {}

    def test_update_increments(self):
        """IngestProgress.update increments correctly, summary string looks right."""
        estimate = {"word_count": 100, "chunks": 3, "estimated_seconds": 9}
        progress = IngestProgress(total_chunks=3, estimate=estimate)

        progress.update(1, [{"memory_type": "decision"}, {"memory_type": "fact"}])
        assert progress.completed_chunks == 1
        assert progress.memories_found == 2
        assert progress.by_type == {"decision": 1, "fact": 1}

        progress.update(2, [{"memory_type": "decision"}])
        assert progress.completed_chunks == 2
        assert progress.memories_found == 3
        assert progress.by_type == {"decision": 2, "fact": 1}

    def test_summary_with_memories(self):
        estimate = {"word_count": 100, "chunks": 5, "estimated_seconds": 15}
        progress = IngestProgress(total_chunks=5, estimate=estimate)
        progress.update(3, [{"memory_type": "fact"}, {"memory_type": "decision"}])
        summary = progress.summary
        assert "3/5" in summary
        assert "2 memories" in summary

    def test_summary_no_memories(self):
        estimate = {"word_count": 100, "chunks": 5, "estimated_seconds": 15}
        progress = IngestProgress(total_chunks=5, estimate=estimate)
        progress.update(1, [])
        assert "1/5" in progress.summary
        assert "memories" not in progress.summary

    def test_as_dict(self):
        estimate = {"word_count": 100, "chunks": 3, "estimated_seconds": 9}
        progress = IngestProgress(total_chunks=3, estimate=estimate)
        progress.update(2, [{"memory_type": "commitment"}])
        d = progress.as_dict
        assert d["completed"] == 2
        assert d["total"] == 3
        assert d["memories_found"] == 1
        assert d["by_type"] == {"commitment": 1}


class TestBackgroundIngestion:
    @patch("coppermind_cmo.ingest.IngestEngine")
    def test_returns_immediately(self, MockEngine):
        """start_background_ingestion returns without waiting for completion."""
        text = "word " * 5000  # Long enough

        # Make ingestion slow
        def slow_process(*a, **kw):
            time.sleep(5)
            return {"new": 0, "updated": 0}
        MockEngine.return_value.process_source = slow_process

        start = time.monotonic()
        result = start_background_ingestion(
            text=text,
            mind_id="test-mind",
            mind_name="Test Client",
            db_factory=MagicMock,
            config=MagicMock(),
        )
        elapsed = time.monotonic() - start

        assert elapsed < 1.0  # Should return nearly instantly
        assert result["status"] == "processing"
        assert "task_id" in result
        assert result["estimate"]["word_count"] == 5000

    @patch("coppermind_cmo.ingest.IngestEngine")
    def test_result_appears_in_notifications(self, MockEngine):
        """Start ingestion with mock, wait for thread, check get_completed_notifications."""
        text = "word " * 1000

        def mock_process(*a, **kw):
            return {"new": 5, "updated": 2}
        MockEngine.return_value.process_source = mock_process

        start_background_ingestion(
            text=text,
            mind_id="test-mind",
            mind_name="Acme Corp",
            db_factory=MagicMock,
            config=MagicMock(),
        )

        notifications = _poll_notifications()
        assert len(notifications) == 1
        assert notifications[0]["type"] == "ingestion_complete"
        assert notifications[0]["mind_name"] == "Acme Corp"
        assert notifications[0]["memories_created"] == 7

    @patch("coppermind_cmo.ingest.IngestEngine")
    def test_notification_shown_once(self, MockEngine):
        """get_completed_notifications returns result first time, empty second time."""
        text = "word " * 1000

        def mock_process(*a, **kw):
            return {"new": 3, "updated": 0}
        MockEngine.return_value.process_source = mock_process

        start_background_ingestion(
            text=text,
            mind_id="test-mind",
            mind_name="Test",
            db_factory=MagicMock,
            config=MagicMock(),
        )

        first = _poll_notifications()
        second = get_completed_notifications()
        assert len(first) == 1
        assert len(second) == 0

    @patch("coppermind_cmo.ingest.IngestEngine")
    def test_notification_includes_error_on_failure(self, MockEngine):
        """Mock ingestion to fail, verify error in notification."""
        text = "word " * 1000

        def mock_process(*a, **kw):
            raise RuntimeError("mysterious internal failure")
        MockEngine.return_value.process_source = mock_process

        start_background_ingestion(
            text=text,
            mind_id="test-mind",
            mind_name="Broken Client",
            db_factory=MagicMock,
            config=MagicMock(),
        )

        notifications = _poll_notifications()
        assert len(notifications) == 1
        assert notifications[0]["type"] == "ingestion_error"
        assert "task ID" in notifications[0]["error"]  # sanitized, not raw exception

    def test_estimate_in_return(self):
        """start_background_ingestion returns estimate dict."""
        text = "x " * 2000
        result = start_background_ingestion(
            text=text,
            mind_id="m",
            mind_name="Test",
            db_factory=MagicMock,
            config=MagicMock(),
        )
        assert "estimate" in result
        assert result["estimate"]["word_count"] == 2000
        assert result["estimate"]["chunks"] >= 1
        assert result["estimate"]["estimated_seconds"] >= 3

    @patch("coppermind_cmo.ingest.IngestEngine")
    def test_notification_includes_memory_count(self, MockEngine):
        """Verify memories_created and by_type in notification."""
        text = "word " * 1000

        def mock_process(*a, **kw):
            return {"new": 10, "updated": 3}
        MockEngine.return_value.process_source = mock_process

        start_background_ingestion(
            text=text,
            mind_id="test-mind",
            mind_name="CountTest",
            db_factory=MagicMock,
            config=MagicMock(),
        )

        # Poll until we find the notification for *this* test's task.
        # Earlier tests may leave late-finishing background threads whose
        # notifications leak across test boundaries despite the fixture clear.
        deadline = time.monotonic() + 5.0
        n = None
        while time.monotonic() < deadline:
            for note in get_completed_notifications():
                if note.get("mind_name") == "CountTest":
                    n = note
                    break
            if n is not None:
                break
            time.sleep(0.01)

        assert n is not None, "CountTest notification never arrived"
        assert n["memories_created"] == 13
        assert "13 new memories extracted" in n["message"]


class TestStoreMemoryBackgroundFlag:
    @patch("coppermind_cmo.background.start_background_ingestion")
    def test_background_true_long_content(self, mock_start_bg):
        """store_memory with background=True and long content uses background ingestion."""
        mock_start_bg.return_value = {
            "status": "processing",
            "task_id": "abc123",
            "estimate": {"word_count": 5000, "chunks": 12, "estimated_seconds": 36},
            "message": "Processing...",
        }

        # Test the branching logic directly (the registered tool requires MCP server)
        from coppermind_cmo.background import start_background_ingestion

        content = "word " * 5000  # >4000 chars
        active_mind = ("mind-id", "Test Client")

        # This mirrors the logic in the registered store_memory function
        result = start_background_ingestion(
            text=content,
            mind_id=active_mind[0],
            mind_name=active_mind[1],
            db_factory=MagicMock,
            config=MagicMock(),
        )

        assert result["status"] == "processing"
        assert result["estimate"]["word_count"] == 5000
        mock_start_bg.assert_called()

    def test_short_content_ignores_background_flag(self):
        """Short content (<4000 chars) should never trigger background mode."""
        content = "short note"
        active_mind = ("mind-id", "Test Client")

        # The condition is: background=True AND active_mind AND len(content) > 4000
        # Short content should fail the length check
        assert not (len(content) > 4000)
