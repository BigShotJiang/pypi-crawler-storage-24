"""HTTP client for the embedding gateway.

Routes through the Coppermind gateway → Voyage AI (512 dims).
Returns None on any failure — callers handle degraded mode.
"""

from typing import Optional

import httpx

from coppermind_cmo.config import Config
from coppermind_cmo.log import ToolLogger

logger = ToolLogger("embedding")


def _gateway_headers(config: Config) -> dict:
    """Build headers for gateway requests including session tracking."""
    from coppermind_cmo.server import get_session_id
    return {
        "Authorization": f"Bearer {config.api_key}",
        "X-Session-Id": get_session_id(),
    }


def _get_embedding_gateway(text: str, config: Config, timeout: float = 10) -> Optional[list[float]]:
    """Get embedding from the Coppermind gateway → Voyage AI."""
    try:
        resp = httpx.post(
            f"{config.gateway_url.rstrip('/')}/v1/embed",
            json={"text": text},
            headers=_gateway_headers(config),
            timeout=timeout,
        )
        resp.raise_for_status()
        data = resp.json()
        embedding = data["embedding"]

        if not isinstance(embedding, list) or len(embedding) == 0:
            logger.warn("Invalid gateway embedding shape: expected non-empty list")
            return None
        if not all(isinstance(x, (int, float)) for x in embedding):
            logger.warn("Invalid gateway embedding: contains non-numeric elements")
            return None
        expected = data.get("dimensions", config.embedding_dims)
        if len(embedding) != expected:
            logger.warn(f"Gateway embedding dimension mismatch: got {len(embedding)}, expected {expected}")
            return None

        return embedding
    except Exception as e:
        logger.warn(f"Gateway embedding request failed: {e}")
        return None


def get_embedding(text: str, config: Config, timeout: float = 10) -> Optional[list[float]]:
    """Get embedding vector for text via the gateway."""
    return _get_embedding_gateway(text, config, timeout)


def check_health(config: Config, timeout: float = 5) -> bool:
    """Check if the embedding gateway is healthy."""
    try:
        resp = httpx.get(
            f"{config.gateway_url.rstrip('/')}/v1/health",
            headers=_gateway_headers(config),
            timeout=timeout,
        )
        return resp.status_code == 200
    except Exception:
        return False
