"""Background ingestion system for long transcripts.

Allows store_memory to return immediately with a time estimate while
processing happens in a background thread. Completed results are attached
as notifications to the next tool call response.
"""

from __future__ import annotations

import threading
import uuid as _uuid
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FuturesTimeoutError
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Callable

from coppermind_cmo.log import ToolLogger

logger = ToolLogger("background")

# Limit concurrent background ingestion jobs
_background_semaphore = threading.Semaphore(2)

# Wall-clock timeout for background ingestion (10 minutes)
BACKGROUND_TIMEOUT_SECONDS = 600


@dataclass
class BackgroundResult:
    """Result from a completed background ingestion."""

    task_id: str
    mind_name: str
    started_at: datetime
    completed_at: datetime | None = None
    memories_created: int = 0
    by_type: dict = field(default_factory=dict)
    error: str | None = None
    shown_to_user: bool = False


# Module-level storage for background results
_background_results: list[BackgroundResult] = []
_background_lock = threading.Lock()


def attach_notifications(result: dict | list) -> dict | list:
    """Attach any pending background ingestion notifications to a dict result.

    Call this from any tool's registered function before returning.
    List results are returned unchanged (notifications only attach to dicts).
    """
    if isinstance(result, dict):
        notifications = get_completed_notifications()
        if notifications:
            result["notifications"] = notifications
    return result


def _classify_ingest_error(exc: Exception, task_id: str) -> str:
    """Return a user-friendly error description with an actionable hint."""
    exc_type = type(exc).__name__.lower()
    exc_str = str(exc).lower()

    if "timeout" in exc_type or "timeout" in exc_str:
        return (
            "The AI service timed out while extracting memories. "
            "Try again with a shorter transcript (under 2,000 words works best), "
            "or paste it in sections."
        )

    if "httpstatuserror" in exc_type or "statuserror" in exc_type:
        if "401" in exc_str or "403" in exc_str:
            return (
                "Authentication failed with the AI service. "
                "Your API key may have expired — restart Claude to refresh your connection."
            )
        if "429" in exc_str:
            return (
                "The AI service is rate-limited right now. "
                "Wait a minute and try again."
            )
        if any(c in exc_str for c in ("500", "502", "503", "504")):
            return (
                "The AI service returned a server error. "
                "Try again in a few minutes."
            )

    if "operationalerror" in exc_type or (
        "connection" in exc_str and "postgres" not in exc_str
    ):
        return (
            "Lost the database connection during processing — usually temporary. "
            "Try again."
        )

    if "integrityerror" in exc_type or "checkviolation" in exc_type or "constraint" in exc_str:
        return (
            "A database validation error occurred. "
            "Try upgrading: pip install --upgrade coppermind-cmo"
        )

    return (
        f"An unexpected error occurred ({type(exc).__name__}). "
        f"Try again. If the problem persists, contact coppermind@volacci.com "
        f"with task ID: {task_id}"
    )


def start_background_ingestion(
    text: str,
    mind_id: str,
    mind_name: str,
    db_factory: Callable,
    config: Any,
    source_type: str = "meeting",
    source_ref: str | None = None,
) -> dict:
    """Start ingestion in a background thread. Returns immediately with estimate."""
    from coppermind_cmo.ingest import estimate_ingestion_time

    task_id = str(_uuid.uuid4())[:8]
    estimate = estimate_ingestion_time(text)

    def _do_ingest():
        """Actual ingestion work — runs inside semaphore and timeout."""
        from coppermind_cmo.ingest import IngestEngine

        db = db_factory()
        engine = IngestEngine(
            db, config,
            active_mind=(mind_id, mind_name),
            memory_source_type="meeting",
        )
        ref = source_ref or f"background-{task_id}"
        return engine.process_source(
            source_type=source_type,
            source_ref=ref,
            content=text,
        )

    def _run():
        result = BackgroundResult(
            task_id=task_id,
            mind_name=mind_name,
            started_at=datetime.now(),
        )
        acquired = _background_semaphore.acquire(timeout=30)
        if not acquired:
            result.error = (
                "Too many background ingestion jobs running. "
                "Wait for a current job to finish and try again."
            )
            result.completed_at = datetime.now()
            with _background_lock:
                if len(_background_results) > 50:
                    _background_results[:] = _background_results[-50:]
                _background_results.append(result)
            return
        try:
            # Run with wall-clock timeout
            with ThreadPoolExecutor(max_workers=1) as executor:
                future = executor.submit(_do_ingest)
                try:
                    ingest_result = future.result(timeout=BACKGROUND_TIMEOUT_SECONDS)
                except FuturesTimeoutError:
                    result.error = (
                        "Background ingestion timed out after 10 minutes. "
                        "Try a shorter transcript (under 5,000 words)."
                    )
                    result.completed_at = datetime.now()
                    logger.error(
                        "Background ingestion timed out",
                        task_id=task_id,
                        mind_name=mind_name,
                    )
                    with _background_lock:
                        if len(_background_results) > 50:
                            _background_results[:] = _background_results[-50:]
                        _background_results.append(result)
                    return

            result.memories_created = ingest_result.get("new", 0) + ingest_result.get("updated", 0)
            result.by_type = ingest_result.get("by_type", {})
            result.completed_at = datetime.now()
            elapsed_ms = int((result.completed_at - result.started_at).total_seconds() * 1000)
            logger.info(
                "Background ingestion complete",
                task_id=task_id,
                mind_name=mind_name,
                memories_created=result.memories_created,
                duration_ms=elapsed_ms,
            )
        except Exception as e:
            result.error = _classify_ingest_error(e, task_id)
            result.completed_at = datetime.now()
            elapsed_ms = int((result.completed_at - result.started_at).total_seconds() * 1000)
            logger.error(
                "Background ingestion failed",
                task_id=task_id,
                mind_name=mind_name,
                error_type=type(e).__name__,
                error=str(e),
                duration_ms=elapsed_ms,
            )
        finally:
            _background_semaphore.release()

        with _background_lock:
            if len(_background_results) > 50:
                _background_results[:] = _background_results[-50:]
            _background_results.append(result)

    thread = threading.Thread(target=_run, daemon=True)
    thread.start()

    return {
        "status": "processing",
        "task_id": task_id,
        "estimate": estimate,
        "message": (
            f"Meeting saved. Extracting memories in the background "
            f"(~{estimate['word_count']} words, ~{estimate['estimated_seconds']}s). "
            "IMPORTANT: Do NOT run list_minds or check memory counts now — the count "
            "will be wrong until extraction finishes. Tell the user their meeting was "
            "saved and you'll notify them automatically when memories are ready."
        ),
    }


def get_completed_notifications() -> list[dict]:
    """Get any completed background ingestion results not yet shown to the user."""
    with _background_lock:
        results = []
        for r in _background_results:
            if r.completed_at and not r.shown_to_user:
                r.shown_to_user = True
                if r.error:
                    results.append({
                        "type": "ingestion_error",
                        "mind_name": r.mind_name,
                        "error": r.error,
                        "message": (
                            f"⚠ Meeting ingestion failed for {r.mind_name}. "
                            f"{r.error} "
                            "IMPORTANT: Tell the user this NOW — their meeting data was NOT saved."
                        ),
                    })
                else:
                    elapsed = int((r.completed_at - r.started_at).total_seconds())
                    type_str = (
                        ", ".join(f"{v} {k}s" for k, v in sorted(r.by_type.items()))
                        if r.by_type else ""
                    )
                    if r.memories_created == 0:
                        message = (
                            f"⚠ Transcript processed for {r.mind_name} but no memories were "
                            "extracted. The content may not contain clear decisions, commitments, "
                            "or facts — or it may have been a duplicate. "
                            "IMPORTANT: Tell the user this now so they know ingestion ran but "
                            "found nothing to save."
                        )
                    else:
                        message = (
                            f"✓ Meeting saved — {r.memories_created} new memories extracted "
                            f"for {r.mind_name}"
                            f"{' (' + type_str + ')' if type_str else ''}. "
                            "IMPORTANT: Tell the user this NOW before doing anything else."
                        )
                    results.append({
                        "type": "ingestion_complete",
                        "mind_name": r.mind_name,
                        "memories_created": r.memories_created,
                        "by_type": r.by_type,
                        "elapsed_seconds": elapsed,
                        "message": message,
                    })
        # Clean up: keep all in-progress/unshown items, cap shown history at 10
        _background_results[:] = (
            [r for r in _background_results if not r.shown_to_user]
            + [r for r in _background_results if r.shown_to_user][-10:]
        )
        return results
