"""switch_client and list_minds tool implementations.

Reference: docs/MCP_TOOLS.md switch_client and list_minds sections.
"""

import re
from typing import Any

from coppermind_cmo.db import Database
from coppermind_cmo.active_client import update_active_client
import json

from coppermind_cmo.errors import (
    INVALID_INPUT, NO_ACTIVE_MIND, MIND_NOT_FOUND, MIND_ARCHIVED, ACCESS_DENIED,
    tool_error,
)
from coppermind_cmo.utils import parse_jsonb
from coppermind_cmo.log import ToolLogger
from coppermind_cmo.tips import get_next_tip

logger = ToolLogger("minds")


def _get_tip_for_switch(mind_id: str, mind_name: str, company_info: dict, db: Database) -> dict | None:
    """Get personalized tip for this session. Returns None if no tip to show."""
    try:
        from coppermind_cmo.server import get_config
        config = get_config()
        customer_id = getattr(config, 'customer_id', None)
        if not company_info:
            row = db.fetch_one(
                "SELECT company_info FROM client_minds WHERE id = %s",
                [mind_id],
            )
            if row and row[0] and isinstance(row[0], dict):
                company_info = row[0]
        return get_next_tip(customer_id, mind_id, mind_name, company_info, db)
    except Exception:
        return None

_has_internal_col: bool | None = None


def _has_is_internal(db: Database) -> bool:
    """Check if is_internal column exists (migration 007). Only caches True."""
    global _has_internal_col
    if _has_internal_col is None:
        row = db.fetch_one(
            "SELECT 1 FROM information_schema.columns "
            "WHERE table_name = 'client_minds' AND column_name = 'is_internal'"
        )
        if row is not None:
            _has_internal_col = True
        return row is not None
    return _has_internal_col


def _verify_mind_access(mind_id: str, customer_id: str | None, db: Database) -> bool:
    """Verify the customer has access to this mind. Returns True if allowed.

    Default-deny: customer_id must be set (hosted mode always provides it).
    The customer must own the mind OR have an explicit access mapping.
    """
    if not customer_id:
        logger.warn("Access denied — no customer_id", mind_id=mind_id)
        return False
    row = db.fetch_one(
        "SELECT 1 FROM client_minds WHERE id = %s AND customer_id = %s",
        [mind_id, customer_id],
    )
    if row:
        return True
    row = db.fetch_one(
        "SELECT 1 FROM customer_mind_access WHERE mind_id = %s AND customer_id = %s",
        [mind_id, customer_id],
    )
    if row is not None:
        return True
    logger.warn("Access denied", mind_id=mind_id, customer_id=customer_id)
    return False


def _make_slug(name: str) -> str:
    """Generate URL-safe slug from client name."""
    slug = name.lower()
    slug = re.sub(r'[^a-z0-9]+', '-', slug)
    slug = slug.strip('-')
    slug = re.sub(r'-+', '-', slug)
    return slug


def _switch_client(
    client_name: str,
    create_new: bool,
    db: Database,
    set_mind_fn,
    is_internal: bool = False,
    customer_id: str | None = None,
) -> dict[str, Any]:
    if not client_name or not client_name.strip():
        return INVALID_INPUT("client_name cannot be empty")

    client_name = client_name.strip()
    if len(client_name) > 200:
        return INVALID_INPUT("client_name exceeds 200 character limit")

    if not customer_id:
        return tool_error("PROVISIONING_ERROR",
                          "Your account could not be identified. "
                          "This usually means your API key is misconfigured. "
                          "Contact coppermind@volacci.com for help.")

    slug = _make_slug(client_name)
    has_internal = _has_is_internal(db)

    # Filter by customer_id: owner or explicit access mapping
    access_filter = (
        "AND (cm.customer_id = %s OR EXISTS ("
        "    SELECT 1 FROM customer_mind_access cma "
        "    WHERE cma.mind_id = cm.id AND cma.customer_id = %s"
        "))"
    )
    access_params = [customer_id, customer_id]

    if has_internal:
        row = db.fetch_one(
            "SELECT cm.id, cm.name, cm.slug, cm.archived_at, cm.is_internal, cm.cadence "
            "FROM client_minds cm "
            "WHERE (LOWER(cm.name) = LOWER(%s) OR cm.slug = %s) "
            + access_filter,
            [client_name, slug] + access_params,
        )
    else:
        row = db.fetch_one(
            "SELECT cm.id, cm.name, cm.slug, cm.archived_at, cm.cadence "
            "FROM client_minds cm "
            "WHERE (LOWER(cm.name) = LOWER(%s) OR cm.slug = %s) "
            + access_filter,
            [client_name, slug] + access_params,
        )

    if row:
        if has_internal:
            mind_id, name, slug, archived_at, row_is_internal, raw_cadence = row
        else:
            mind_id, name, slug, archived_at, raw_cadence = row
            row_is_internal = False
        if archived_at is not None:
            return MIND_ARCHIVED(name)

        cadence = raw_cadence if isinstance(raw_cadence, dict) else {}

        count_row = db.fetch_one(
            "SELECT COUNT(*) FROM memories WHERE mind_id = %s AND is_current = true",
            [mind_id],
        )
        memory_count = count_row[0] if count_row else 0

        set_mind_fn(str(mind_id), name)
        logger.info(f"Switched to {name}", mind_id=str(mind_id))
        update_active_client(name, str(mind_id), memory_count, cadence)

        result = {
            "mind_id": str(mind_id),
            "name": name,
            "slug": slug,
            "is_new": False,
            "memory_count": memory_count,
        }
        if row_is_internal:
            result["is_internal"] = True

        tip = _get_tip_for_switch(str(mind_id), name, {}, db)
        if tip:
            result["daily_tip"] = tip

        return result

    if not create_new:
        return MIND_NOT_FOUND()

    # --- CREATE ---
    existing_slug = db.fetch_one(
        "SELECT 1 FROM client_minds WHERE slug = %s", [slug]
    )
    if existing_slug:
        suffix = 2
        while db.fetch_one(
            "SELECT 1 FROM client_minds WHERE slug = %s", [f"{slug}-{suffix}"]
        ):
            suffix += 1
            if suffix > 100:
                return INVALID_INPUT("Too many clients with similar names. Use a more specific name.")
        slug = f"{slug}-{suffix}"

    try:
        if has_internal:
            new_row = db.execute_returning(
                "INSERT INTO client_minds (name, slug, customer_id, is_internal) "
                "VALUES (%s, %s, %s, %s) RETURNING id, name, slug",
                [client_name, slug, customer_id, is_internal],
            )
        else:
            new_row = db.execute_returning(
                "INSERT INTO client_minds (name, slug, customer_id) "
                "VALUES (%s, %s, %s) RETURNING id, name, slug",
                [client_name, slug, customer_id],
            )
    except Exception as e:
        if "unique" in str(e).lower() or "duplicate" in str(e).lower():
            return INVALID_INPUT("A client with a similar name already exists. Try a more specific name.")
        raise

    mind_id, name, slug = new_row

    # Create access mapping for the owner
    db.execute(
        "INSERT INTO customer_mind_access (customer_id, mind_id, access_level) "
        "VALUES (%s, %s, 'owner') ON CONFLICT (customer_id, mind_id) DO NOTHING",
        [customer_id, str(mind_id)],
    )

    set_mind_fn(str(mind_id), name)
    logger.info(f"Created new mind: {name}", mind_id=str(mind_id))
    update_active_client(name, str(mind_id), 0)

    result = {
        "mind_id": str(mind_id),
        "name": name,
        "slug": slug,
        "is_new": True,
        "memory_count": 0,
    }
    if is_internal:
        result["is_internal"] = True

    tip = _get_tip_for_switch(str(mind_id), name, {}, db)
    if tip:
        result["daily_tip"] = tip

    return result


def _list_minds(limit: int, offset: int, db: Database, include_internal: bool = False,
                customer_id: str | None = None) -> list[dict[str, Any]]:
    limit = min(max(1, limit), 200)
    offset = max(0, offset)

    if not customer_id:
        logger.warn("list_minds called without customer_id — returning empty list")
        return []

    where_clauses = [
        "(cm.customer_id = %s OR EXISTS ("
        "    SELECT 1 FROM customer_mind_access cma "
        "    WHERE cma.mind_id = cm.id AND cma.customer_id = %s"
        "))"
    ]
    params: list = [customer_id, customer_id]

    if not include_internal and _has_is_internal(db):
        where_clauses.append("cm.is_internal = false")

    base_sql = (
        "SELECT cm.id, cm.name, cm.slug, cm.archived_at, "
        "COUNT(m.id) AS memory_count, cm.created_at, cm.updated_at "
        "FROM client_minds cm "
        "LEFT JOIN memories m ON m.mind_id = cm.id AND m.is_current = true "
        "WHERE " + " AND ".join(where_clauses) + " "
        "GROUP BY cm.id "
        "ORDER BY cm.updated_at DESC "
        "LIMIT %s OFFSET %s"
    )
    params.extend([limit, offset])
    rows = db.fetch_all(base_sql, params)

    return [
        {
            "mind_id": str(r[0]),
            "name": r[1],
            "slug": r[2],
            "archived_at": r[3].isoformat() if r[3] else None,
            "memory_count": r[4],
            "created_at": r[5].isoformat() if r[5] else None,
            "updated_at": r[6].isoformat() if r[6] else None,
        }
        for r in rows
    ]


VALID_CADENCE_TYPES = {"eos", "custom", "none"}


def _configure_mind(
    cadence: dict | None,
    company_info: dict | None,
    db: Database,
    active_mind: tuple[str, str] | None,
) -> dict[str, Any]:
    if active_mind is None:
        return NO_ACTIVE_MIND()

    mind_id, mind_name = active_mind

    if not cadence and not company_info:
        return INVALID_INPUT("Provide cadence and/or company_info")

    # Validate cadence
    if cadence:
        if not isinstance(cadence, dict):
            return INVALID_INPUT("cadence must be a dict")

        ctype = cadence.get("type")
        if ctype is not None and ctype not in VALID_CADENCE_TYPES:
            return INVALID_INPUT(f"cadence.type must be one of: {', '.join(VALID_CADENCE_TYPES)}")

        q = cadence.get("quarter")
        if q is not None and (not isinstance(q, int) or q < 1 or q > 4):
            return INVALID_INPUT("cadence.quarter must be an integer 1-4")

        y = cadence.get("year")
        if y is not None and (not isinstance(y, int) or y < 2020 or y > 2100):
            return INVALID_INPUT("cadence.year must be an integer 2020-2100")

        s = cadence.get("sprint")
        if s is not None and (not isinstance(s, int) or s < 1):
            return INVALID_INPUT("cadence.sprint must be an integer >= 1")

        spq = cadence.get("sprints_per_quarter")
        if spq is not None and (not isinstance(spq, int) or spq < 1 or spq > 12):
            return INVALID_INPUT("cadence.sprints_per_quarter must be an integer 1-12")

    # Validate company_info
    if company_info:
        if not isinstance(company_info, dict):
            return INVALID_INPUT("company_info must be a dict")

        url = company_info.get("url")
        if url is not None and (not isinstance(url, str) or len(url) > 500):
            return INVALID_INPUT("company_info.url must be a string <= 500 chars")

        industry = company_info.get("industry")
        if industry is not None and (not isinstance(industry, str) or len(industry) > 200):
            return INVALID_INPUT("company_info.industry must be a string <= 200 chars")

    # Build UPDATE query based on what's provided
    updated_fields = []
    if cadence and company_info:
        updated_fields = ["cadence", "company_info"]
        row = db.execute_returning(
            "UPDATE client_minds "
            "SET cadence = COALESCE(cadence, '{}'::jsonb) || %s::jsonb, "
            "    company_info = COALESCE(company_info, '{}'::jsonb) || %s::jsonb, "
            "    updated_at = now() "
            "WHERE id = %s "
            "RETURNING cadence, company_info",
            [json.dumps(cadence), json.dumps(company_info), mind_id],
        )
    elif cadence:
        updated_fields = ["cadence"]
        row = db.execute_returning(
            "UPDATE client_minds "
            "SET cadence = COALESCE(cadence, '{}'::jsonb) || %s::jsonb, "
            "    updated_at = now() "
            "WHERE id = %s "
            "RETURNING cadence, company_info",
            [json.dumps(cadence), mind_id],
        )
    else:
        updated_fields = ["company_info"]
        row = db.execute_returning(
            "UPDATE client_minds "
            "SET company_info = COALESCE(company_info, '{}'::jsonb) || %s::jsonb, "
            "    updated_at = now() "
            "WHERE id = %s "
            "RETURNING cadence, company_info",
            [json.dumps(company_info), mind_id],
        )

    if not row:
        from coppermind_cmo.errors import tool_error
        return tool_error("INTERNAL_ERROR", "Something went wrong updating the client settings. Try switching to the client again with switch_client first.")

    result_cadence = parse_jsonb(row[0])
    result_company_info = parse_jsonb(row[1])

    logger.info(f"Configured mind: {mind_name}", mind_id=mind_id)

    return {
        "mind_id": mind_id,
        "name": mind_name,
        "cadence": result_cadence,
        "company_info": result_company_info,
        "updated_fields": updated_fields,
    }


def _list_documents(
    limit: int,
    db: Database,
    active_mind: tuple[str, str] | None,
) -> list[dict] | dict:
    """List stored raw documents for the active client."""
    if active_mind is None:
        return NO_ACTIVE_MIND()
    mind_id, mind_name = active_mind

    from coppermind_cmo.ingest import _has_raw_documents_table
    if not _has_raw_documents_table(db):
        return {"message": "Document storage isn't set up yet for this account. Contact coppermind@volacci.com to enable it."}

    limit = min(max(1, limit), 50)
    rows = db.fetch_all(
        "SELECT id, source_type, source_ref, word_count, extraction_passes, "
        "last_extracted_at, created_at "
        "FROM raw_documents WHERE mind_id = %s ORDER BY created_at DESC LIMIT %s",
        [mind_id, limit],
    )
    return [
        {
            "doc_id": str(r[0]),
            "source_type": r[1],
            "source_ref": r[2],
            "word_count": r[3],
            "extraction_passes": r[4],
            "last_extracted_at": r[5].isoformat() if r[5] else None,
            "created_at": r[6].isoformat() if r[6] else None,
        }
        for r in rows
    ]


def register(mcp_server):
    from coppermind_cmo.server import get_db, get_active_mind, set_active_mind, set_last_tool_call, get_customer_id
    from coppermind_cmo.background import attach_notifications

    @mcp_server.tool()
    def switch_client(client_name: str, create_new: bool = False, is_internal: bool = False) -> dict:
        """Set the active client mind. All subsequent operations are scoped to this client.

        Use is_internal=True to create a mind for internal/product notes that won't appear in list_minds.

        If the response includes a `daily_tip`, share it with the user casually after confirming the switch — like "By the way, here's a tip..."

        If the response includes `notifications`, share each one with the user before proceeding.
        Example: "By the way, your Acme transcript finished processing — 23 new memories extracted."
        """
        set_last_tool_call("switch_client")
        result = _switch_client(client_name, create_new, get_db(), set_active_mind,
                                is_internal=is_internal, customer_id=get_customer_id())
        return attach_notifications(result)

    @mcp_server.tool()
    def list_minds(limit: int = 50, offset: int = 0, include_internal: bool = False) -> list[dict]:
        """List all client minds with memory counts. Internal minds are excluded by default."""
        set_last_tool_call("list_minds")
        return _list_minds(limit, offset, get_db(), include_internal=include_internal,
                           customer_id=get_customer_id())

    @mcp_server.tool()
    def configure_mind(
        cadence: dict | None = None,
        company_info: dict | None = None,
    ) -> dict:
        """Configure the active client's business context — cadence (EOS quarter/sprint tracking) and company information.

        Call this during client onboarding to set up the business rhythm. Both fields use JSONB merge — you can update incrementally.

        cadence example: {"type": "eos", "year": 2026, "quarter": 1, "sprint": 4, "sprints_per_quarter": 6}
        company_info example: {"url": "https://acme.com", "industry": "SaaS", "primary_contact": {"name": "Jane", "title": "CEO"}}
        """
        set_last_tool_call("configure_mind")
        active_mind = get_active_mind()
        if active_mind is None:
            return NO_ACTIVE_MIND()
        if not _verify_mind_access(active_mind[0], get_customer_id(), get_db()):
            return ACCESS_DENIED()
        result = _configure_mind(cadence, company_info, get_db(), active_mind)
        return attach_notifications(result)

    @mcp_server.tool()
    def list_documents(limit: int = 10) -> list[dict] | dict:
        """List stored documents for the active client. Shows what's been ingested and extraction status."""
        set_last_tool_call("list_documents")
        active_mind = get_active_mind()
        if active_mind is None:
            return NO_ACTIVE_MIND()
        if not _verify_mind_access(active_mind[0], get_customer_id(), get_db()):
            return ACCESS_DENIED()
        return _list_documents(limit, get_db(), active_mind)
