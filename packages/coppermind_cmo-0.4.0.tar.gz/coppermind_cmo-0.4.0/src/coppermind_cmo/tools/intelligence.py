"""Intelligence tools: prep_meeting, get_campaign_history.

Reference: docs/MCP_TOOLS.md -- prep_meeting (type-balanced retrieval, synthesis),
get_campaign_history (filtered by campaign_outcome type).
"""

import json
from typing import Any

from coppermind_cmo.config import Config
from coppermind_cmo.db import Database
from coppermind_cmo.embedding_client import get_embedding
# LLM synthesis removed — see llm_client.py for future re-enablement
from coppermind_cmo.errors import NO_ACTIVE_MIND, tool_error
from coppermind_cmo.log import ToolLogger
from coppermind_cmo.utils import parse_jsonb, get_mind_cadence, touch_memories

logger = ToolLogger("intelligence")

# Default token budget for self-hosted (gemma3:12b, ~3.25 chars/token, 4000 token limit).
# Overridden by config.max_prompt_chars at runtime.
MAX_PROMPT_CHARS = 13000
RECENCY_WEIGHT = 0.6
SIMILARITY_WEIGHT = 0.4
MIN_MEMORIES_FOR_SYNTHESIS = 3
SIMILARITY_THRESHOLD = 0.3
MAX_LIMIT = 200

PERMANENT_TYPES = {"stakeholder", "preference", "fact"}
TEMPORAL_TYPES = {"decision", "commitment", "campaign_outcome"}

QUARTER_WEIGHTS = {0: 1.0, 1: 0.7, 2: 0.4, 3: 0.2}  # distance -> weight
DEFAULT_QUARTER_WEIGHT = 0.1  # 4+ quarters ago
UNTAGGED_QUARTER_WEIGHT = 0.5


def _quarter_weight(memory_year, memory_quarter, current_year, current_quarter):
    """Weight temporal memories by distance from current quarter."""
    if memory_year is None or memory_quarter is None:
        return UNTAGGED_QUARTER_WEIGHT
    distance = (current_year * 4 + current_quarter) - (memory_year * 4 + memory_quarter)
    if distance < 0:
        distance = 0  # future quarter treated as current
    return QUARTER_WEIGHTS.get(distance, DEFAULT_QUARTER_WEIGHT)


def _get_campaign_history(
    limit: int,
    offset: int,
    db: Database,
    active_mind: tuple[str, str] | None,
) -> dict | list:
    if active_mind is None:
        return NO_ACTIVE_MIND()

    mind_id, _ = active_mind
    limit = min(max(1, limit), MAX_LIMIT)
    offset = max(0, offset)

    rows = db.fetch_all(
        "SELECT id, content, summary, tags, created_at "
        "FROM memories "
        "WHERE mind_id = %s AND memory_type = 'campaign_outcome' AND is_current = true "
        "ORDER BY created_at DESC LIMIT %s OFFSET %s",
        [mind_id, limit, offset],
    )

    if rows:
        touch_memories(db, [str(r[0]) for r in rows])

    return [
        {
            "memory_id": str(r[0]),
            "content": r[1],
            "summary": r[2],
            "tags": r[3] if r[3] else [],
            "created_at": r[4].isoformat() if r[4] else None,
        }
        for r in rows
    ]


def _collect_type_balanced(mind_id: str, limit: int, db: Database) -> list[tuple]:
    """Type-balanced retrieval per MCP_TOOLS.md prep_meeting spec.

    Returns list of tuples: (id, content, summary, memory_type, created_at, tag, embedding).
    Tag is 'type_balanced' or 'fill'.
    """
    type_balanced = []
    fill_memories = []
    seen_ids = set()

    # Get populated types
    type_rows = db.fetch_all(
        "SELECT DISTINCT memory_type FROM memories "
        "WHERE mind_id = %s AND is_current = true",
        [mind_id],
    )
    populated_types = [r[0] for r in type_rows]

    if not populated_types:
        return []

    # Per-type allocation: floor(limit / populated_types), can be 0
    per_type = limit // len(populated_types)

    for mem_type in populated_types:
        rows = db.fetch_all(
            "SELECT id, content, summary, memory_type, created_at, embedding "
            "FROM memories "
            "WHERE mind_id = %s AND memory_type = %s AND is_current = true "
            "ORDER BY created_at DESC LIMIT %s",
            [mind_id, mem_type, per_type],
        )
        for r in rows:
            if str(r[0]) not in seen_ids:
                seen_ids.add(str(r[0]))
                type_balanced.append((*r[:5], "type_balanced", r[5]))

    # Fill remaining slots
    remaining = limit - len(type_balanced)
    if remaining > 0:
        fill = db.fetch_all(
            "SELECT id, content, summary, memory_type, created_at, embedding "
            "FROM memories "
            "WHERE mind_id = %s AND is_current = true AND id != ALL(%s::uuid[]) "
            "ORDER BY created_at DESC LIMIT %s",
            [mind_id, list(seen_ids), remaining],
        )
        for r in fill:
            fill_memories.append((*r[:5], "fill", r[5]))

    return type_balanced + fill_memories


def _collect_meeting_memories(
    mind_id: str,
    topics: list[str] | None,
    limit: int,
    db: Database,
    config: Config,
) -> list[tuple]:
    """Smart retrieval for meeting prep: agenda items + topic search + commitments + permanent knowledge + backfill.

    Returns list of tuples: (id, content, summary, memory_type, created_at, tag, embedding, quarter_year, quarter, sprint).
    Tag is 'agenda', 'topic', 'commitment', 'permanent', or 'backfill'.
    """
    memories = []
    seen_ids = set()

    cadence = get_mind_cadence(mind_id, db)
    current_year = cadence.get("year")
    current_quarter = cadence.get("quarter")

    # --- Step 1: Agenda items (all memories tagged 'agenda') ---
    agenda_rows = db.fetch_all(
        "SELECT id, content, summary, memory_type, created_at, embedding, "
        "quarter_year, quarter, sprint "
        "FROM memories "
        "WHERE mind_id = %s AND is_current = true AND 'agenda' = ANY(tags) "
        "ORDER BY created_at DESC",
        [mind_id],
    )
    for r in agenda_rows:
        rid = str(r[0])
        if rid not in seen_ids:
            seen_ids.add(rid)
            memories.append((*r[:5], "agenda", r[5], r[6], r[7], r[8]))

    # --- Step 2: Topic-driven semantic search ---
    if topics:
        for topic_text in topics[:5]:  # max 5 topics to limit embedding calls
            topic_emb = get_embedding(topic_text, config)
            if topic_emb is None:
                continue
            emb_str = "[" + ",".join(str(x) for x in topic_emb) + "]"
            rows = db.fetch_all(
                "SELECT id, content, summary, memory_type, created_at, embedding, "
                "quarter_year, quarter, sprint, "
                "1 - (embedding <=> %s::vector) as similarity "
                "FROM memories "
                "WHERE mind_id = %s AND is_current = true "
                "AND embedding IS NOT NULL "
                "AND 1 - (embedding <=> %s::vector) > %s "
                "ORDER BY similarity DESC LIMIT 5",
                [emb_str, mind_id, emb_str, SIMILARITY_THRESHOLD],
            )
            for r in rows:
                rid = str(r[0])
                if rid not in seen_ids:
                    seen_ids.add(rid)
                    memories.append((*r[:5], "topic", r[5], r[6], r[7], r[8]))

    # --- Step 3: Recent commitments (current + previous quarter) ---
    if current_year is not None and current_quarter is not None:
        prev_quarter = current_quarter - 1 if current_quarter > 1 else 4
        prev_year = current_year if current_quarter > 1 else current_year - 1
        commitment_rows = db.fetch_all(
            "SELECT id, content, summary, memory_type, created_at, embedding, "
            "quarter_year, quarter, sprint "
            "FROM memories "
            "WHERE mind_id = %s AND is_current = true "
            "AND memory_type = 'commitment' "
            "AND ((quarter_year = %s AND quarter = %s) OR (quarter_year = %s AND quarter = %s)) "
            "ORDER BY created_at DESC LIMIT 10",
            [mind_id, current_year, current_quarter, prev_year, prev_quarter],
        )
    else:
        # No cadence set — fall back to most recent commitments
        commitment_rows = db.fetch_all(
            "SELECT id, content, summary, memory_type, created_at, embedding, "
            "quarter_year, quarter, sprint "
            "FROM memories "
            "WHERE mind_id = %s AND is_current = true AND memory_type = 'commitment' "
            "ORDER BY created_at DESC LIMIT 10",
            [mind_id],
        )
    for r in commitment_rows:
        rid = str(r[0])
        if rid not in seen_ids:
            seen_ids.add(rid)
            memories.append((*r[:5], "commitment", r[5], r[6], r[7], r[8]))

    # --- Step 4: Permanent knowledge (stakeholder, preference, fact) ---
    permanent_rows = db.fetch_all(
        "SELECT id, content, summary, memory_type, created_at, embedding, "
        "quarter_year, quarter, sprint "
        "FROM memories "
        "WHERE mind_id = %s AND is_current = true "
        "AND memory_type IN ('stakeholder', 'preference', 'fact') "
        "ORDER BY created_at DESC LIMIT 15",
        [mind_id],
    )
    for r in permanent_rows:
        rid = str(r[0])
        if rid not in seen_ids:
            seen_ids.add(rid)
            memories.append((*r[:5], "permanent", r[5], r[6], r[7], r[8]))

    # --- Step 5: Type-balanced backfill ---
    remaining = limit - len(memories)
    if remaining > 0:
        exclude_list = list(seen_ids)
        backfill = db.fetch_all(
            "SELECT id, content, summary, memory_type, created_at, embedding, "
            "quarter_year, quarter, sprint "
            "FROM memories "
            "WHERE mind_id = %s AND is_current = true AND id != ALL(%s::uuid[]) "
            "ORDER BY created_at DESC LIMIT %s",
            [mind_id, exclude_list, remaining],
        )
        for r in backfill:
            memories.append((*r[:5], "backfill", r[5], r[6], r[7], r[8]))

    # --- Step 6: Apply quarter weighting to temporal memories ---
    if current_year is not None and current_quarter is not None:
        weighted = []
        for m in memories:
            mem_type = m[3]
            tag = m[5]
            m_year, m_quarter = m[7], m[8]

            if tag == "agenda":
                weight = 1.0  # agenda items always top priority
            elif mem_type in PERMANENT_TYPES:
                weight = 1.0  # permanent knowledge never decays
            else:
                weight = _quarter_weight(m_year, m_quarter, current_year, current_quarter)

            # Append weight as last element
            weighted.append((*m, weight))

        # Sort: agenda first, then by weight descending, then by created_at descending
        weighted.sort(key=lambda x: (
            x[5] == "agenda",  # agenda items first (True > False)
            x[-1],             # weight
            x[4].timestamp() if x[4] and hasattr(x[4], 'timestamp') else 0,
        ), reverse=True)

        # Strip weight from tuple (keep same shape as input)
        memories = [m[:-1] for m in weighted]

    return memories


def _rerank_by_topic(
    memories: list[tuple],
    topic: str,
    config: Config,
) -> list[tuple]:
    """Re-rank memories by blended recency + topic similarity score.

    Per spec: 0.6 * recency_score + 0.4 * cosine_similarity.
    Type-balanced memories are preserved in order; only fill slots are re-ranked.
    Uses stored embedding vectors from DB -- only calls get_embedding once for the topic.
    """
    topic_embedding = get_embedding(topic, config)
    if topic_embedding is None:
        logger.warn("Embedding service unreachable for topic re-ranking, using recency only")
        return memories

    # Separate type-balanced from fill
    type_balanced = [m for m in memories if m[5] == "type_balanced"]
    fill = [m for m in memories if m[5] == "fill"]

    if not fill:
        return memories

    # Compute recency scores for fill memories
    timestamps = []
    for m in fill:
        ts = m[4]
        if ts is not None and hasattr(ts, 'timestamp'):
            timestamps.append(ts.timestamp())
        else:
            timestamps.append(0.0)

    # timestamps is always non-empty here (fill is non-empty, checked above)
    min_ts = min(timestamps)
    max_ts = max(timestamps)
    ts_range = max_ts - min_ts if max_ts != min_ts else 1.0

    # Score and sort fill memories using stored embeddings
    scored_fill = []
    for i, m in enumerate(fill):
        recency = (timestamps[i] - min_ts) / ts_range if ts_range > 0 else 1.0

        # Use stored embedding from DB (index 6)
        mem_embedding = None
        if m[6] is not None:
            mem_embedding = json.loads(m[6]) if isinstance(m[6], str) else m[6]

        if mem_embedding is not None and topic_embedding is not None:
            dot = sum(a * b for a, b in zip(topic_embedding, mem_embedding))
            norm_a = sum(a * a for a in topic_embedding) ** 0.5
            norm_b = sum(b * b for b in mem_embedding) ** 0.5
            similarity = dot / (norm_a * norm_b) if norm_a > 0 and norm_b > 0 else 0.0
        else:
            similarity = 0.0

        blended = RECENCY_WEIGHT * recency + SIMILARITY_WEIGHT * similarity
        scored_fill.append((blended, m))

    scored_fill.sort(key=lambda x: x[0], reverse=True)
    return type_balanced + [m for _, m in scored_fill]


def _build_structured_brief(
    memories: list[tuple],
    brand_dna: dict,
    mind_name: str,
    cadence: dict | None = None,
    company_info: dict | None = None,
) -> str:
    """Build a structured brief from memories and brand DNA for Claude Code to polish."""
    lines = [f"# Meeting Brief: {mind_name}", ""]

    # Position header
    if cadence and cadence.get("type") == "eos":
        pos = f"**EOS Position:** {cadence.get('year', '?')} Q{cadence.get('quarter', '?')}"
        if cadence.get("sprint") is not None and cadence.get("sprints_per_quarter") is not None:
            pos += f", Sprint {cadence['sprint']} of {cadence['sprints_per_quarter']}"
        lines.append(pos)
        lines.append("")

    # Group memories by type
    by_type: dict[str, list] = {}
    for m in memories:
        mt = m[3]
        summary = m[2] or (m[1][:150] if m[1] else "")
        if mt not in by_type:
            by_type[mt] = []
        by_type[mt].append(summary)

    # Key Stakeholders from brand DNA
    stakeholders = brand_dna.get("stakeholders", [])
    if stakeholders:
        lines.append("## Key Stakeholders")
        for s in stakeholders:
            name = s.get("name", "Unknown")
            title = s.get("title", "")
            role = s.get("role", "")
            entry = f"- **{name}**"
            if title:
                entry += f", {title}"
            if role:
                entry += f" ({role})"
            lines.append(entry)
        lines.append("")

    # Action Items (from commitments)
    if "commitment" in by_type:
        lines.append("## Action Items")
        for item in by_type["commitment"]:
            lines.append(f"- [ ] {item}")
        lines.append("")

    # Recent Decisions
    if "decision" in by_type:
        lines.append("## Recent Decisions")
        for item in by_type["decision"]:
            lines.append(f"- {item}")
        lines.append("")

    # Active Campaigns
    if "campaign_outcome" in by_type:
        lines.append("## Active Campaigns")
        for item in by_type["campaign_outcome"]:
            lines.append(f"- {item}")
        lines.append("")

    # Key Facts & Preferences
    facts_prefs = by_type.get("fact", []) + by_type.get("preference", [])
    if facts_prefs:
        lines.append("## Key Context")
        for item in facts_prefs:
            lines.append(f"- {item}")
        lines.append("")

    # Stakeholder memories (different from brand DNA stakeholders)
    if "stakeholder" in by_type:
        lines.append("## Stakeholder Notes")
        for item in by_type["stakeholder"]:
            lines.append(f"- {item}")
        lines.append("")

    if not by_type:
        lines.append("*No memories available for this client.*")
        lines.append("")

    lines.append("---")

    return "\n".join(lines)


def _prep_meeting(
    topics: list[str] | None,
    meeting_type: str | None,
    limit: int,
    db: Database,
    config: Config,
    active_mind: tuple[str, str] | None,
    save: bool = False,
) -> dict[str, Any]:
    if active_mind is None:
        return NO_ACTIVE_MIND()

    mind_id, mind_name = active_mind
    limit = min(max(1, limit), MAX_LIMIT)

    # Validate meeting_type if provided
    valid_meeting_types = {"review", "catchup", "planning", "topic"}
    if meeting_type and meeting_type not in valid_meeting_types:
        return tool_error("INVALID_INPUT", f"meeting_type must be one of: {', '.join(valid_meeting_types)}")

    # Fetch cadence and company info
    context_row = db.fetch_one(
        "SELECT name, brand_voice, brand_positioning, approved_messaging, "
        "stakeholders, content_themes, cadence, company_info "
        "FROM client_minds WHERE id = %s",
        [mind_id],
    )
    if not context_row:
        return tool_error("INTERNAL_ERROR", "Active mind not found in database")

    brand_dna = {
        "brand_voice": parse_jsonb(context_row[1]),
        "brand_positioning": parse_jsonb(context_row[2]),
        "approved_messaging": parse_jsonb(context_row[3]),
        "stakeholders": parse_jsonb(context_row[4]) if context_row[4] else [],
        "content_themes": context_row[5] if context_row[5] else [],
    }
    cadence = parse_jsonb(context_row[6]) if context_row[6] else {}
    company_info = parse_jsonb(context_row[7]) if context_row[7] else {}

    # Smart retrieval (replaces type-balanced for prep_meeting)
    memories = _collect_meeting_memories(mind_id, topics, limit, db, config)

    # Group memories by type for structured return
    memories_by_type: dict[str, list] = {}
    for m in memories:
        mt = m[3]
        if mt not in memories_by_type:
            memories_by_type[mt] = []
        memories_by_type[mt].append({
            "summary": m[2] or (m[1][:150] if m[1] else ""),
            "created_at": m[4].isoformat() if m[4] else None,
        })

    # Update last_accessed_at
    if memories:
        touch_memories(db, [str(m[0]) for m in memories])

    base_response = {
        "client_name": mind_name,
        "memories_by_type": memories_by_type,
        "stakeholders": brand_dna["stakeholders"],
        "brand_voice": brand_dna["brand_voice"],
        "memory_count": len(memories),
        "cadence": cadence,
    }

    if len(memories) < MIN_MEMORIES_FOR_SYNTHESIS:
        raw_response = {
            **base_response,
            "mode": "raw",
            "reason": "insufficient_data",
            "brief_markdown": None,
            "message": f"Only {len(memories)} memories found (minimum {MIN_MEMORIES_FOR_SYNTHESIS} needed for synthesis). "
                       "Store more memories to enable meeting briefs.",
        }
        if save:
            raw_response["saved"] = False
        return raw_response

    # Build structured brief — Claude Code writes the polished version
    structured_brief = _build_structured_brief(
        memories, brand_dna, mind_name, cadence=cadence, company_info=company_info,
    )

    response = {
        **base_response,
        "mode": "structured",
        "reason": None,
        "brief_markdown": structured_brief,
    }

    if save:
        row = db.execute_returning(
            "INSERT INTO meeting_briefs (mind_id, brief_markdown, meeting_type, topics, memory_count) "
            "VALUES (%s, %s, %s, %s, %s) RETURNING id",
            [mind_id, structured_brief, meeting_type, topics or [], len(memories)],
        )
        if row:
            response["brief_id"] = str(row[0])
            response["saved"] = True
            logger.info("Saved meeting brief", mind_id=mind_id, brief_id=str(row[0]))
        else:
            response["saved"] = False
            logger.error("Failed to save meeting brief", mind_id=mind_id)

    return response


def _get_last_brief(
    db: Database,
    active_mind: tuple[str, str] | None,
) -> dict[str, Any]:
    if active_mind is None:
        return NO_ACTIVE_MIND()

    mind_id, mind_name = active_mind

    row = db.fetch_one(
        "SELECT id, brief_markdown, meeting_type, topics, memory_count, created_at "
        "FROM meeting_briefs "
        "WHERE mind_id = %s "
        "ORDER BY created_at DESC LIMIT 1",
        [mind_id],
    )

    if not row:
        return {
            "client_name": mind_name,
            "brief_markdown": None,
            "message": "No saved briefs found. Use prep_meeting with save=true to save a brief.",
        }

    return {
        "brief_id": str(row[0]),
        "client_name": mind_name,
        "brief_markdown": row[1],
        "meeting_type": row[2],
        "topics": row[3] if row[3] else [],
        "memory_count": row[4],
        "created_at": row[5].isoformat() if row[5] else None,
    }


def register(mcp_server):
    """Register intelligence tools on the MCP server."""
    from coppermind_cmo.server import get_db, get_config, get_active_mind, set_last_tool_call, get_customer_id
    from coppermind_cmo.background import attach_notifications
    from coppermind_cmo.tools.minds import _verify_mind_access
    from coppermind_cmo.errors import ACCESS_DENIED

    @mcp_server.tool()
    def prep_meeting(
        topics: list[str] | None = None,
        meeting_type: str | None = None,
        limit: int = 50,
        save: bool = False,
    ) -> dict:
        """Retrieve structured client data for meeting prep. You write the polished brief.

        For best results, provide topics and meeting_type. If not specified,
        all client memories are returned unfiltered.

        You receive structured data (memories by type, stakeholders, brand voice, cadence).
        Write a polished, conversational brief from it.

        Parameters:
        - topics: List of discussion topics (recommended for best results)
        - meeting_type: review, catchup, planning, or topic (optional)
        - limit: Maximum memories to consider, default 50 (optional)
        - save: If true, persist the brief for later retrieval via get_last_brief (default false)
        """
        set_last_tool_call("prep_meeting")
        active_mind = get_active_mind()
        if active_mind and not _verify_mind_access(active_mind[0], get_customer_id(), get_db()):
            return ACCESS_DENIED()
        result = _prep_meeting(topics, meeting_type, limit, get_db(), get_config(), active_mind, save=save)
        return attach_notifications(result)

    @mcp_server.tool()
    def get_campaign_history(limit: int = 10, offset: int = 0) -> list | dict:
        """Review campaign results and learnings for the active client."""
        set_last_tool_call("get_campaign_history")
        active_mind = get_active_mind()
        if active_mind and not _verify_mind_access(active_mind[0], get_customer_id(), get_db()):
            return ACCESS_DENIED()
        return _get_campaign_history(limit, offset, get_db(), active_mind)

    @mcp_server.tool()
    def get_last_brief() -> dict:
        """Retrieve the most recently saved meeting brief for the active client."""
        set_last_tool_call("get_last_brief")
        active_mind = get_active_mind()
        if active_mind and not _verify_mind_access(active_mind[0], get_customer_id(), get_db()):
            return ACCESS_DENIED()
        result = _get_last_brief(get_db(), active_mind)
        return attach_notifications(result)
