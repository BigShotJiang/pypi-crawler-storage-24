"""Brand DNA tools: get_brand_voice, set_brand_voice.

Reference: docs/MCP_TOOLS.md and docs/SCHEMA.md Brand DNA section.
"""

import json
from typing import Any

from psycopg2 import sql as pgsql

from coppermind_cmo.db import Database
from coppermind_cmo.errors import NO_ACTIVE_MIND, INVALID_INPUT, INVALID_BRAND_DNA, tool_error
from coppermind_cmo.log import ToolLogger
from coppermind_cmo.utils import parse_jsonb

logger = ToolLogger("brand")

BRAND_DNA_FIELDS = [
    "brand_voice", "brand_positioning", "approved_messaging",
    "stakeholders", "content_themes",
]


def _validate_brand_voice(data: dict) -> str | None:
    if not isinstance(data, dict):
        return "brand_voice must be an object"
    if "tone" not in data or not isinstance(data["tone"], list):
        return "brand_voice requires 'tone' (list of strings)"
    return None


def _validate_brand_positioning(data: dict) -> str | None:
    if not isinstance(data, dict):
        return "brand_positioning must be an object"
    if "category" not in data or not isinstance(data["category"], str):
        return "brand_positioning requires 'category' (string)"
    return None


def _validate_stakeholders(data: list) -> str | None:
    if not isinstance(data, list):
        return "stakeholders must be an array"
    if len(data) > 50:
        return "stakeholders limited to 50 entries"
    for i, s in enumerate(data):
        if not isinstance(s, dict) or "name" not in s:
            return f"stakeholders[{i}] requires 'name'"
    return None


def _get_brand_voice(
    db: Database,
    active_mind: tuple[str, str] | None,
) -> dict[str, Any]:
    if active_mind is None:
        return NO_ACTIVE_MIND()

    mind_id, _ = active_mind

    row = db.fetch_one(
        "SELECT name, brand_voice, brand_positioning, approved_messaging, "
        "stakeholders, content_themes FROM client_minds WHERE id = %s",
        [mind_id],
    )
    if not row:
        return tool_error("INTERNAL_ERROR", "Something went wrong loading client data. Try switching to the client again with switch_client.")

    return {
        "name": row[0],
        "brand_voice": parse_jsonb(row[1]),
        "brand_positioning": parse_jsonb(row[2]),
        "approved_messaging": parse_jsonb(row[3]),
        "stakeholders": parse_jsonb(row[4]) if row[4] else [],
        "content_themes": row[5] if row[5] else [],
    }


def _set_brand_voice(
    fields: dict[str, Any],
    db: Database,
    active_mind: tuple[str, str] | None,
) -> dict[str, Any]:
    if active_mind is None:
        return NO_ACTIVE_MIND()

    mind_id, _ = active_mind

    # Filter to valid brand DNA fields only
    updates = {k: v for k, v in fields.items() if k in BRAND_DNA_FIELDS}
    if not updates:
        return INVALID_INPUT("At least one brand DNA field is required")

    # Validate shapes
    if "brand_voice" in updates:
        err = _validate_brand_voice(updates["brand_voice"])
        if err:
            return INVALID_BRAND_DNA(err)

    if "brand_positioning" in updates:
        err = _validate_brand_positioning(updates["brand_positioning"])
        if err:
            return INVALID_BRAND_DNA(err)

    if "stakeholders" in updates:
        err = _validate_stakeholders(updates["stakeholders"])
        if err:
            return INVALID_BRAND_DNA(err)

    if "content_themes" in updates:
        themes = updates["content_themes"]
        if not isinstance(themes, list):
            return INVALID_INPUT("content_themes must be a list")
        if len(themes) > 20:
            return INVALID_INPUT("Maximum 20 content_themes allowed")
        if any(len(str(t)) > 100 for t in themes):
            return INVALID_INPUT("Each content_theme must be 100 characters or fewer")

    previous = {}

    # Build UPDATE and history inserts — read + write in same transaction
    try:
        with db.connection() as conn:
            with conn.cursor() as cur:
                # Read current values inside the transaction
                cur.execute(
                    "SELECT name, brand_voice, brand_positioning, approved_messaging, "
                    "stakeholders, content_themes FROM client_minds WHERE id = %s",
                    [mind_id],
                )
                row = cur.fetchone()
                if not row:
                    return tool_error("INTERNAL_ERROR", "Something went wrong loading client data. Try switching to the client again with switch_client.")
                current = {
                    "brand_voice": parse_jsonb(row[1]),
                    "brand_positioning": parse_jsonb(row[2]),
                    "approved_messaging": parse_jsonb(row[3]),
                    "stakeholders": parse_jsonb(row[4]) if row[4] else [],
                    "content_themes": row[5] if row[5] else [],
                }

                for field_name, new_value in updates.items():
                    previous[field_name] = current.get(field_name, {})

                    # Update the field (use sql.Identifier for safe column interpolation)
                    if field_name == "content_themes":
                        # Cast Python list to text[] explicitly for psycopg2
                        cur.execute(
                            pgsql.SQL("UPDATE client_minds SET {} = %s::text[] WHERE id = %s").format(
                                pgsql.Identifier(field_name)
                            ),
                            [new_value, mind_id],
                        )
                        prev_jsonb = json.dumps(current.get(field_name, []))
                        new_jsonb = json.dumps(new_value)
                    else:
                        cur.execute(
                            pgsql.SQL("UPDATE client_minds SET {} = %s::jsonb WHERE id = %s").format(
                                pgsql.Identifier(field_name)
                            ),
                            [json.dumps(new_value), mind_id],
                        )
                        prev_jsonb = json.dumps(current.get(field_name, {}))
                        new_jsonb = json.dumps(new_value)

                    # Insert history row
                    cur.execute(
                        "INSERT INTO brand_dna_history "
                        "(mind_id, field_name, previous_value, new_value, changed_by) "
                        "VALUES (%s, %s, %s::jsonb, %s::jsonb, 'set_brand_voice')",
                        [mind_id, field_name, prev_jsonb, new_jsonb],
                    )

                conn.commit()
    except Exception as e:
        logger.error(f"Failed to update brand DNA: {e}", mind_id=mind_id)
        return tool_error("DB_ERROR", "Failed to save brand settings — the database rejected the update. Try again, and if it keeps failing contact coppermind@volacci.com.")

    logger.info(f"Updated brand DNA: {list(updates.keys())}", mind_id=mind_id)

    # Read updated values
    updated_row = db.fetch_one(
        "SELECT name, brand_voice, brand_positioning, approved_messaging, "
        "stakeholders, content_themes FROM client_minds WHERE id = %s",
        [mind_id],
    )
    if not updated_row:
        return tool_error("INTERNAL_ERROR", "Brand settings were saved but couldn't be reloaded. Try get_brand_voice to confirm the update took.")

    return {
        "name": updated_row[0],
        "brand_voice": parse_jsonb(updated_row[1]),
        "brand_positioning": parse_jsonb(updated_row[2]),
        "approved_messaging": parse_jsonb(updated_row[3]),
        "stakeholders": parse_jsonb(updated_row[4]) if updated_row[4] else [],
        "content_themes": updated_row[5] if updated_row[5] else [],
        "previous": previous,
    }


def register(mcp_server):
    """Register brand DNA tools on the MCP server."""
    from coppermind_cmo.server import get_db, get_active_mind, set_last_tool_call, get_customer_id
    from coppermind_cmo.background import attach_notifications
    from coppermind_cmo.tools.minds import _verify_mind_access
    from coppermind_cmo.errors import ACCESS_DENIED

    @mcp_server.tool()
    def get_brand_voice() -> dict:
        """Retrieve the active client's brand DNA."""
        set_last_tool_call("get_brand_voice")
        active_mind = get_active_mind()
        if active_mind is None:
            return NO_ACTIVE_MIND()
        if not _verify_mind_access(active_mind[0], get_customer_id(), get_db()):
            return ACCESS_DENIED()
        result = _get_brand_voice(get_db(), active_mind)
        return attach_notifications(result)

    @mcp_server.tool()
    def set_brand_voice(
        brand_voice: dict | None = None,
        brand_positioning: dict | None = None,
        approved_messaging: dict | None = None,
        stakeholders: list[dict] | None = None,
        content_themes: list[str] | None = None,
    ) -> dict:
        """Update the active client's brand DNA fields."""
        set_last_tool_call("set_brand_voice")
        fields = {}
        if brand_voice is not None:
            fields["brand_voice"] = brand_voice
        if brand_positioning is not None:
            fields["brand_positioning"] = brand_positioning
        if approved_messaging is not None:
            fields["approved_messaging"] = approved_messaging
        if stakeholders is not None:
            fields["stakeholders"] = stakeholders
        if content_themes is not None:
            fields["content_themes"] = content_themes
        active_mind = get_active_mind()
        if active_mind is None:
            return NO_ACTIVE_MIND()
        if not _verify_mind_access(active_mind[0], get_customer_id(), get_db()):
            return ACCESS_DENIED()
        result = _set_brand_voice(fields, get_db(), active_mind)
        return attach_notifications(result)
