import hashlib
import os
import threading
import time
import typing as t
from datetime import datetime, timezone
from pathlib import Path
from uuid import UUID

import fsspec
from fsspec import AbstractFileSystem
from loguru import logger

from dreadnode.app.api.models import StorageCredentials
from dreadnode.app.server.session import Session
from dreadnode.storage.providers import StorageProvider, from_provider

if t.TYPE_CHECKING:
    from dreadnode.app.api.client import ApiClient

T = t.TypeVar("T")

PackageType = t.Literal["datasets", "models", "environments", "capabilities"]


class Storage:
    """Storage manager for local and remote storage.

    Directory structure:
        ~/.dreadnode/
          packages/
            datasets/
            agents/
            models/
            tools/
            environments/
          capabilities/
            <capability_name>/
              capability.yaml
          cas/
            sha256/
              ab/cd/...
          artifacts/
          projects/
            <project_key>/
              <run_id>/
                spans.jsonl
                metrics.jsonl
          sessions/
            <session_id>/
              chat_<session_id>.json
              chat_<session_id>.jsonl

    When running in a sandbox, ~/.dreadnode is mounted via s3fs to the user's
    workspace storage, with the S3 prefix already scoped to {org_id}/workspaces/{workspace_id}.
    """

    def __init__(
        self,
        session: Session | None = None,
        cache: Path | None = None,
        api: "ApiClient | None" = None,
        provider: StorageProvider | None = None,
        *,
        default_project: str | None = None,
    ):
        """Create storage manager.

        Args:
            session: Authenticated session for RBAC context.
            cache: Root cache directory. Defaults to ~/.dreadnode.
            api: API client for remote operations (blob credentials + registry uploads).
            provider: Storage provider for remote operations (s3, r2, minio).
            default_project: Default project key.
        """
        self._session = session
        self._cache = cache or Path.home() / ".dreadnode"
        self._api = api
        self._provider = provider
        self._default_project = default_project

        # Remote filesystem state
        self._remote_fs: AbstractFileSystem | None = None
        self._local_fs: AbstractFileSystem | None = None
        self._credentials: StorageCredentials | None = None
        self._expiration: datetime | None = None
        self._lock = threading.Lock()

    @property
    def session(self) -> Session | None:
        """Get the current session."""
        return self._session

    @property
    def api(self) -> "ApiClient | None":
        """Get the API client."""
        return self._api

    @property
    def project_key(self) -> str:
        """Get the project key."""
        if self._session is not None:
            return self._session.project_key or "default"
        return self._default_project or "default"

    @property
    def can_sync(self) -> bool:
        """Whether remote sync is possible (has API client and session,)."""
        return self._api is not None and self._session is not None and not self._provider

    # =========================================================================
    # Path Properties
    # =========================================================================

    @property
    def packages_path(self) -> Path:
        """Path to packages directory."""
        return self._cache / "packages"

    @property
    def cas_path(self) -> Path:
        """Path to CAS directory."""
        return self._cache / "cas"

    @property
    def artifacts_path(self) -> Path:
        """Path to artifacts CAS."""
        return self._cache / "artifacts"

    @property
    def capabilities_path(self) -> Path:
        """Path to capabilities directory."""
        return self._cache / "capabilities"

    @property
    def workspace_capabilities_path(self) -> Path:
        """Path to workspace capability cache directory (CAP-LOAD-007)."""
        override = os.environ.get("DREADNODE_WORKSPACE_CAPABILITIES_DIR")
        if override:
            return Path(override)
        return self._cache / "workspace-capabilities"

    @property
    def local_capability_state_path(self) -> Path:
        """Path to persisted local capability state."""
        return self._cache / "local-capability-state.json"

    @property
    def sessions_path(self) -> Path:
        """Path to sessions directory."""
        return self._cache / "sessions"

    def session_path(self, session_id: str | UUID) -> Path:
        """Path to a session directory."""
        return self.sessions_path / str(session_id)

    def session_chat_path(self, session_id: str | UUID, ext: str = "json") -> Path:
        """Path to a session chat file.

        Args:
            session_id: The session identifier.
            ext: File extension without the leading dot.

        Returns:
            Full path to the session chat file.
        """
        session_dir = self.session_path(session_id)
        session_dir.mkdir(parents=True, exist_ok=True)
        session_str = str(session_id)
        return session_dir / f"chat_{session_str}.{ext}"

    def session_runtime_path(self, session_id: str | UUID, ext: str = "json") -> Path:
        """Path to a session runtime manifest file.

        Args:
            session_id: The session identifier.
            ext: File extension without the leading dot.

        Returns:
            Full path to the session runtime manifest file.
        """
        session_dir = self.session_path(session_id)
        session_dir.mkdir(parents=True, exist_ok=True)
        session_str = str(session_id)
        return session_dir / f"runtime_{session_str}.{ext}"

    @property
    def projects_path(self) -> Path:
        """Path to projects directory."""
        return self._cache / "projects"

    @property
    def project_path(self) -> Path:
        """Path to current project directory."""
        return self.projects_path / self.project_key

    def run_path(self, run_id: str | UUID) -> Path:
        """Path to run directory for trace data."""
        return self.project_path / str(run_id)

    def trace_path(self, run_id: str | UUID, filename: str = "spans.jsonl") -> Path:
        """Path to trace file within a run directory.

        Args:
            run_id: The run identifier.
            filename: Full filename with extension (e.g., 'spans.jsonl', 'spans.parquet').

        Returns:
            Full path to the trace file.
        """
        run_dir = self.run_path(run_id)
        run_dir.mkdir(parents=True, exist_ok=True)
        return run_dir / filename


    # =========================================================================
    # Remote Filesystem
    # =========================================================================

    @property
    def remote_prefix(self) -> str:
        """Get the remote storage prefix from credentials."""
        if self._credentials is None:
            self._get_filesystem()
        if self._credentials is None:
            raise RuntimeError("No credentials available for remote storage")
        return self._credentials.prefix

    def _get_filesystem(self) -> AbstractFileSystem:
        """Get filesystem, refreshing credentials if needed.

        Falls back to local filesystem if no API client.
        """
        with self._lock:
            if self._remote_fs is not None and not self._credentials_expired():
                return self._remote_fs

            if not self.can_sync:
                self._remote_fs = from_provider("local")
                return self._remote_fs

            try:
                self._credentials = self._refresh_credentials()
                provider = self._provider or ("minio" if self._credentials.endpoint else "s3")

                self._remote_fs = from_provider(
                    provider,
                    {
                        "access_key_id": self._credentials.access_key_id,
                        "secret_access_key": self._credentials.secret_access_key,
                        "session_token": self._credentials.session_token,
                        "endpoint_url": self._credentials.endpoint,
                        "region": self._credentials.region,
                    },
                )
                self._expiration = self._credentials.expiration

            except Exception as exc:
                logger.debug("Remote storage credentials unavailable, using local filesystem: {}", exc)
                self._remote_fs = from_provider("local")

            return self._remote_fs

    def _refresh_credentials(self) -> StorageCredentials:
        """Refresh storage credentials from the API."""
        if self._api is None:
            raise RuntimeError("No API client configured for remote storage")
        if self._session is None or self._session.workspace is None:
            raise RuntimeError("No workspace configured for storage credentials")
        return self._api.get_storage_access(
            self._session.organization.key,
            self._session.workspace.key,
        )

    def _credentials_expired(self) -> bool:
        """Check if credentials are expired or about to expire."""
        if self._expiration is None:
            return False
        now = datetime.now(timezone.utc)
        expiry = self._expiration
        if expiry.tzinfo is None:
            expiry = expiry.replace(tzinfo=timezone.utc)
        # Refresh 15 minutes before expiry
        return (expiry - now).total_seconds() < 900

    def _is_local_filesystem(self) -> bool:
        """Check if the current filesystem is local."""
        from fsspec.implementations.local import LocalFileSystem

        fs = self._get_filesystem()
        return isinstance(fs, LocalFileSystem)

    def _execute_with_retry(
        self,
        operation: t.Callable[[], T],
        max_retries: int = 3,
        sleep_fn: t.Callable[[float], None] = time.sleep,
    ) -> T:
        """Execute a remote fs operation with retry on auth errors.

        On auth failure (expired/invalid STS credentials), invalidates the
        cached filesystem so the next _get_filesystem() call refreshes
        credentials, then retries with linear backoff.
        """
        for attempt in range(max_retries):
            try:
                return operation()
            except Exception as e:
                if _is_auth_error(e) and attempt < max_retries - 1:
                    logger.debug(
                        "Auth error on attempt {}/{}, refreshing credentials: {}",
                        attempt + 1,
                        max_retries,
                        e,
                    )
                    with self._lock:
                        self._remote_fs = None
                    sleep_fn(attempt + 1)
                    continue
                raise
        raise RuntimeError("Max retries exhausted")  # unreachable

    # =========================================================================
    # Blob Operations (CAS)
    # =========================================================================

    def blob_path(self, oid: str) -> Path:
        """Path to blob in CAS."""
        algo, hash_val = oid.split(":", 1)
        return self.cas_path / algo / hash_val[:2] / hash_val[2:4] / hash_val

    def remote_blob_path(self, oid: str) -> str:
        """Remote path for blob (includes bucket for s3fs)."""
        algo, hash_val = oid.split(":", 1)
        bucket = self._credentials.bucket if self._credentials else "user-data"
        return f"{bucket}/{self.remote_prefix}/cas/{algo}/{hash_val[:2]}/{hash_val[2:4]}/{hash_val}"

    def blob_exists(self, oid: str) -> bool:
        """Check if blob exists in local CAS."""
        return self.blob_path(oid).exists()

    def remote_blob_exists(self, oid: str) -> bool:
        """Check if blob exists in remote storage."""

        def _op() -> bool:
            fs = self._get_filesystem()
            return bool(fs.exists(self.remote_blob_path(oid)))

        return self._execute_with_retry(_op)

    def store_blob(self, oid: str, source: Path) -> Path:
        """Store blob in local CAS."""
        dest = self.blob_path(oid)
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(source.read_bytes())
        return dest

    def get_blob(self, oid: str) -> Path:
        """Get blob from local CAS."""
        path = self.blob_path(oid)
        if not path.exists():
            raise FileNotFoundError(f"Blob not found: {oid}")
        return path

    # =========================================================================
    # Artifact Operations (Workspace-scoped CAS)
    # =========================================================================

    def artifact_blob_path(self, oid: str) -> Path:
        """Path to artifact blob in workspace CAS."""
        algo, hash_val = oid.split(":", 1)
        return self.artifacts_path / algo / hash_val[:2] / hash_val[2:4] / hash_val

    def remote_artifact_path(self, oid: str) -> str:
        """Remote path for artifact blob."""
        algo, hash_val = oid.split(":", 1)
        bucket = self._credentials.bucket if self._credentials else "user-data"
        return f"{bucket}/{self.remote_prefix}/artifacts/{algo}/{hash_val[:2]}/{hash_val[2:4]}/{hash_val}"

    def store_artifact(self, source: Path, *, upload: bool = True) -> str:
        """Store artifact in workspace CAS and optionally upload to remote.

        Args:
            source: Path to the file to store.
            upload: Whether to upload to remote storage immediately.

        Returns:
            The oid (sha256:<hash>) of the stored artifact.
        """
        file_hash = hash_file(source)
        oid = f"sha256:{file_hash}"

        # Store locally
        dest = self.artifact_blob_path(oid)
        if not dest.exists():
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(source.read_bytes())

        # Upload to remote if enabled
        if upload and self.can_sync:
            self.upload_artifact(oid)

        return oid

    def upload_artifact(self, oid: str) -> None:
        """Upload artifact from workspace CAS to remote storage."""
        source = self.artifact_blob_path(oid)
        if not source.exists():
            raise FileNotFoundError(f"Artifact not found locally: {oid}")

        if not self.can_sync:
            return

        def _op() -> None:
            from fsspec.implementations.local import LocalFileSystem

            fs = self._get_filesystem()
            if isinstance(fs, LocalFileSystem):
                return

            remote_path = self.remote_artifact_path(oid)
            if not fs.exists(remote_path):
                fs.put_file(str(source), remote_path)

        self._execute_with_retry(_op)

    def get_artifact(self, oid: str) -> Path:
        """Get artifact from workspace CAS, downloading if needed."""
        local_path = self.artifact_blob_path(oid)
        if local_path.exists():
            return local_path

        # Try to download from remote
        if not self.can_sync:
            raise FileNotFoundError(f"Artifact not found: {oid}")

        def _op() -> Path:
            from fsspec.implementations.local import LocalFileSystem

            fs = self._get_filesystem()
            if isinstance(fs, LocalFileSystem):
                raise FileNotFoundError(f"Artifact not found: {oid}")

            remote_path = self.remote_artifact_path(oid)
            local_path.parent.mkdir(parents=True, exist_ok=True)
            fs.get_file(remote_path, str(local_path))

            # Verify hash
            _algo, expected = oid.split(":", 1)
            actual = hash_file(local_path)
            if actual != expected:
                local_path.unlink()
                raise ValueError(f"Artifact hash mismatch: expected {expected}, got {actual}")

            return local_path

        return self._execute_with_retry(_op)

    # =========================================================================
    # Batch Operations
    # =========================================================================

    def hash_files(self, paths: list[Path], algo: str = "sha256") -> dict[Path, str]:
        """Compute hashes for multiple files.

        Args:
            paths: Files to hash.
            algo: Hash algorithm.

        Returns:
            Mapping of path to hash.
        """
        return {p: hash_file(p, algo) for p in paths}

    def upload_blobs(
        self,
        files: dict[Path, str],
        *,
        skip_existing: bool = True,
    ) -> tuple[int, int]:
        """Upload multiple blobs to remote storage.

        Args:
            files: Mapping of local path to oid.
            skip_existing: Skip blobs that already exist remotely.

        Returns:
            Tuple of (uploaded_count, skipped_count).
        """

        def _op() -> tuple[int, int]:
            from fsspec.implementations.local import LocalFileSystem

            fs = self._get_filesystem()
            is_local = isinstance(fs, LocalFileSystem)

            sources: list[str] = []
            targets: list[str] = []
            skipped = 0

            for local_path, oid in files.items():
                target_path = str(self.blob_path(oid)) if is_local else self.remote_blob_path(oid)

                if skip_existing and fs.exists(target_path):
                    skipped += 1
                    continue

                sources.append(str(local_path))
                targets.append(target_path)

            if sources:
                if is_local:
                    for target in targets:
                        Path(target).parent.mkdir(parents=True, exist_ok=True)
                fs.put(sources, targets)

            return len(sources), skipped

        return self._execute_with_retry(_op)

    def download_blobs(
        self,
        oids: list[str],
        *,
        skip_existing: bool = True,
    ) -> tuple[int, int]:
        """Download multiple blobs from remote storage.

        Args:
            oids: Object IDs to download.
            skip_existing: Skip blobs that already exist locally.

        Returns:
            Tuple of (downloaded_count, skipped_count).
        """

        def _op() -> tuple[int, int]:
            fs = self._get_filesystem()

            sources: list[str] = []
            targets: list[str] = []
            downloaded_oids: list[str] = []
            skipped = 0

            for oid in oids:
                local_path = self.blob_path(oid)

                if skip_existing and local_path.exists():
                    skipped += 1
                    continue

                local_path.parent.mkdir(parents=True, exist_ok=True)
                sources.append(self.remote_blob_path(oid))
                targets.append(str(local_path))
                downloaded_oids.append(oid)

            if sources:
                fs.get(sources, targets)

                # Verify hashes
                for oid, target in zip(downloaded_oids, targets, strict=True):
                    algo, expected = oid.split(":", 1)
                    actual = hash_file(Path(target), algo)
                    if actual != expected:
                        Path(target).unlink()
                        raise ValueError(f"Hash mismatch for {oid}")

            return len(sources), skipped

        return self._execute_with_retry(_op)

    # =========================================================================
    # Single Blob Remote Operations
    # =========================================================================

    def download_blob(self, oid: str) -> Path:
        """Download blob from remote to local CAS."""
        dest = self.blob_path(oid)
        if dest.exists():
            return dest

        def _op() -> Path:
            fs = self._get_filesystem()
            remote_path = self.remote_blob_path(oid)

            dest.parent.mkdir(parents=True, exist_ok=True)
            fs.get_file(remote_path, str(dest))

            # Verify
            algo, expected = oid.split(":", 1)
            actual = hash_file(dest, algo)
            if actual != expected:
                dest.unlink()
                raise ValueError(f"Hash mismatch: expected {expected}, got {actual}")

            return dest

        return self._execute_with_retry(_op)

    def upload_blob(self, oid: str) -> None:
        """Upload blob from local CAS to remote."""
        source = self.blob_path(oid)
        if not source.exists():
            raise FileNotFoundError(f"Blob not found: {oid}")

        def _op() -> None:
            fs = self._get_filesystem()
            remote_path = self.remote_blob_path(oid)
            fs.put_file(str(source), remote_path)

        self._execute_with_retry(_op)

    # =========================================================================
    # Package Operations
    # =========================================================================

    def package_path(
        self,
        package_type: PackageType,
        name: str,
        version: str | None = None,
    ) -> Path:
        """Path to package directory.

        Returns: ~/.dreadnode/packages/<package_type>/<name>/[version/]
        """
        base = self.packages_path / package_type / name
        if version:
            return base / version
        return base

    def manifest_path(
        self,
        package_type: PackageType,
        name: str,
        version: str,
    ) -> Path:
        """Path to manifest.json."""
        return self.package_path(package_type, name, version) / "manifest.json"

    def store_manifest(
        self,
        package_type: PackageType,
        name: str,
        version: str,
        content: str,
    ) -> Path:
        """Store manifest.json."""
        path = self.manifest_path(package_type, name, version)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content)
        return path

    def get_manifest(
        self,
        package_type: PackageType,
        name: str,
        version: str,
    ) -> str:
        """Get manifest.json content."""
        return self.manifest_path(package_type, name, version).read_text()

    def manifest_exists(
        self,
        package_type: PackageType,
        name: str,
        version: str,
    ) -> bool:
        """Check if manifest exists."""
        return self.manifest_path(package_type, name, version).exists()

    def list_versions(
        self,
        package_type: PackageType,
        name: str,
    ) -> list[str]:
        """List available versions."""
        import re

        base = self.package_path(package_type, name)
        if not base.exists():
            return []
        version_pattern = re.compile(r"^\d+\.\d+\.\d+.*$")
        versions = [v.name for v in base.iterdir() if v.is_dir() and version_pattern.match(v.name)]
        return sorted(versions, reverse=True)

    def latest_version(
        self,
        package_type: PackageType,
        name: str,
    ) -> str | None:
        """Get latest version."""
        versions = self.list_versions(package_type, name)
        return versions[0] if versions else None

    # =========================================================================
    # OCI Registry
    # =========================================================================

    @property
    def oci_registry_url(self) -> str:
        """Get the OCI Distribution v2 registry URL."""
        if self._api is None:
            raise RuntimeError("No API client configured")
        return self._api.oci_registry_url

    def oci_client(self) -> "RegistryClient":
        """Create an OCI registry client for push/pull operations."""
        from dreadnode.packaging.oci import RegistryClient

        if self._api is None:
            raise RuntimeError("No API client configured")
        return RegistryClient(
            self._api.oci_registry_url,
            auth=self._api.oci_basic_auth,
        )

    # =========================================================================
    # URI Resolution
    # =========================================================================

    def resolve(self, uri: str, **storage_options: t.Any) -> tuple[AbstractFileSystem, str]:
        """Resolve URI to filesystem and path."""
        fs, path = fsspec.url_to_fs(uri, **storage_options)
        return fs, path


def hash_file(path: Path, algo: str = "sha256") -> str:
    """Compute hash of file."""
    hasher = hashlib.new(algo)
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            hasher.update(chunk)
    return hasher.hexdigest()


def _is_auth_error(exc: Exception) -> bool:
    """Check if exception is a botocore auth error (expired/invalid credentials).

    Also checks the __cause__ chain to catch s3fs-wrapped exceptions
    (e.g. PermissionError wrapping botocore ClientError).
    """
    current: BaseException | None = exc
    while current is not None:
        if (
            type(current).__name__ == "ClientError"
            and hasattr(current, "response")
            and getattr(type(current), "__module__", "").startswith("botocore")
        ):
            error_code = current.response.get("Error", {}).get("Code", "")
            if error_code in ("ExpiredToken", "InvalidAccessKeyId", "SignatureDoesNotMatch"):
                return True
        current = getattr(current, "__cause__", None)
    return False
