from __future__ import annotations

from typing import TYPE_CHECKING, Any

from dreadnode.packaging.loader import BaseLoader
from dreadnode.packaging.manifest import DatasetManifest

if TYPE_CHECKING:
    from pathlib import Path

    import datasets  # type: ignore[import-untyped]
    import pyarrow as pa


class Dataset(BaseLoader[DatasetManifest]):
    """Loader for dataset components."""

    entry_point_group = "dreadnode.datasets"
    manifest_class = DatasetManifest

    @property
    def format(self) -> str:
        return self.manifest.format

    @property
    def schema(self) -> dict[str, str]:
        return self.manifest.data_schema

    @property
    def row_count(self) -> int | None:
        return self.manifest.row_count

    def load(self, split: str | None = None) -> pa.Table:
        """Load dataset as PyArrow Table."""
        files: list[str] = self.files
        if split:
            matches = [f for f in files if split in f]
            if not matches:
                raise ValueError(f"No file matching split '{split}'")
            path = self.resolve(matches[0])
        else:
            path = self.resolve(files[0])

        return self._load_file(path)

    def _load_file(self, path: Path) -> pa.Table:
        fmt = self.format or path.suffix.lstrip(".")

        if fmt == "parquet":
            import pyarrow.parquet as pq

            return pq.read_table(path)
        if fmt == "csv":
            from pyarrow import csv

            return csv.read_csv(path)
        if fmt in ("arrow", "feather"):
            from pyarrow import feather

            return feather.read_table(path)
        raise ValueError(f"Unknown format: {fmt}")

    def to_pandas(self, split: str | None = None) -> Any:
        """Load as pandas DataFrame."""
        return self.load(split).to_pandas()

    def to_hf(self, split: str | None = None) -> datasets.Dataset:
        """Load and convert to HuggingFace Dataset.

        This enables using HuggingFace dataset features like .map(),
        .filter(), .shuffle(), and DataLoader integration.

        Args:
            split: Optional split to load.

        Returns:
            HuggingFace Dataset with full functionality.

        Example:
            >>> ds = load_dataset("my-data")
            >>> hf_ds = ds.to_hf()
            >>> hf_ds = hf_ds.map(lambda x: {"lower": x["text"].lower()})
            >>> hf_ds.set_format("torch")
        """
        from dreadnode.datasets.hf import arrow_to_hf, require_datasets

        require_datasets()
        table = self.load(split)
        return arrow_to_hf(table)


def load_dataset(name: str) -> Dataset:
    """Load a dataset component by name.

    Args:
        name: Dataset component name (entry point name).

    Returns:
        Loaded Dataset.
    """
    return Dataset(name)
