"""High-level capability loader object."""

from __future__ import annotations

import asyncio
import json
import typing as t
from dataclasses import dataclass, field
from pathlib import Path

from dreadnode.capabilities.loader import (
    LoadOptions,
    get_default_capabilities_dir,
    load_capabilities_from_search_paths,
    load_capability as load_capability_definition,
    resolve_search_paths,
)
from dreadnode.capabilities.types import LoadedCapability, MCPServerDef
from dreadnode.capabilities.wrapper import WrappedCapability, wrap_capability
from dreadnode.storage.storage import Storage


@dataclass
class DiscoverResult:
    """Result of capability discovery for a single host type."""

    capabilities: dict[str, Capability] = field(default_factory=dict)
    disabled: dict[str, Capability] = field(default_factory=dict)
    failures: list[dict[str, t.Any]] = field(default_factory=list)


def read_local_capability_state(path: Path) -> dict[str, bool]:
    """Read persisted local capability state keyed by bare capability name."""
    return {
        key: record.get("enabled", True)
        for key, record in read_local_capability_records(path).items()
    }


def read_local_capability_records(path: Path) -> dict[str, dict[str, t.Any]]:
    """Read persisted local capability records keyed by bare capability name."""
    if not path.exists():
        return {}
    try:
        raw = json.loads(path.read_text())
    except Exception:
        return {}
    if not isinstance(raw, dict):
        return {}

    records: dict[str, dict[str, t.Any]] = {}
    for key, value in raw.items():
        if not isinstance(key, str):
            continue
        if isinstance(value, bool):
            records[key] = {"enabled": value}
            continue
        if not isinstance(value, dict):
            continue
        record = dict(value)
        enabled = record.get("enabled", True)
        if not isinstance(enabled, bool):
            enabled = True
        record["enabled"] = enabled
        records[key] = record
    return records


def write_local_capability_state(path: Path, state: dict[str, bool]) -> None:
    """Persist local capability state keyed by bare capability name."""
    existing = read_local_capability_records(path)
    records: dict[str, dict[str, t.Any]] = {}
    for key, enabled in state.items():
        if not isinstance(key, str):
            continue
        record = dict(existing.get(key, {}))
        record["enabled"] = enabled
        records[key] = record
    write_local_capability_records(path, records)


def write_local_capability_records(path: Path, state: dict[str, dict[str, t.Any]]) -> None:
    """Persist structured local capability records keyed by bare capability name."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(state, indent=2, sort_keys=True))


class Capability:
    """Loaded capability object with wrapped runtime components."""

    def __init__(
        self,
        capability: str | Path,
        *,
        cwd: Path | None = None,
        storage: Storage | None = None,
        capability_dirs: list[str | Path] | None = None,
    ) -> None:
        self._ref = capability
        self._cwd = Path(cwd) if cwd is not None else Path.cwd()
        self._storage = storage
        self._capability_dirs = capability_dirs

        loaded = self._resolve_loaded()
        self._loaded = loaded
        self._wrapped = wrap_capability(loaded)

    @classmethod
    def _from_loaded(
        cls,
        loaded: LoadedCapability,
        *,
        cwd: Path | None = None,
        storage: Storage | None = None,
        capability_dirs: list[str | Path] | None = None,
    ) -> Capability:
        instance = cls.__new__(cls)
        instance._ref = loaded.name
        instance._cwd = Path(cwd) if cwd is not None else Path.cwd()
        instance._storage = storage
        instance._capability_dirs = capability_dirs
        instance._loaded = loaded
        instance._wrapped = wrap_capability(loaded)
        return instance

    @classmethod
    def list(
        cls,
        *,
        cwd: Path | None = None,
        storage: Storage | None = None,
        capability_dirs: list[str | Path] | None = None,
    ) -> list[str]:
        """List capability names visible from the configured search paths."""
        search_paths = resolve_search_paths(
            cwd=Path(cwd) if cwd is not None else Path.cwd(),
            user_dir=storage.capabilities_path if storage is not None else get_default_capabilities_dir(),
            capability_dirs=capability_dirs,
        )
        result = asyncio.run(
            load_capabilities_from_search_paths(search_paths, LoadOptions())
        )
        return [cap.name for cap in result.capabilities]

    @classmethod
    def discover(
        cls,
        *,
        cwd: Path | None = None,
        storage: Storage | None = None,
        capability_dirs: list[str | Path] | None = None,
        workspace_dir: Path | None = None,
        host: str = "local",
    ) -> DiscoverResult:
        """Discover capabilities for a specific host type.

        CAP-LOAD-014: host type determines the only active source.
        CAP-LOAD-015: no cross-source mixing in v1.
        """
        resolved_cwd = Path(cwd) if cwd is not None else Path.cwd()
        all_failures: list[dict[str, t.Any]] = []

        if host == "sandbox":
            # Sandbox host: project source only (CAP-LOAD-004)
            effective: dict[str, Capability] = {}
            if workspace_dir and workspace_dir.exists():
                ws_result = asyncio.run(
                    load_capabilities_from_search_paths(
                        [workspace_dir], LoadOptions(), source="project"
                    )
                )
                for cap in ws_result.capabilities:
                    effective[cap.name] = cls._from_loaded(
                        cap, cwd=resolved_cwd, storage=storage, capability_dirs=capability_dirs,
                    )
                for f in ws_result.failures:
                    all_failures.append({"name": f.name, "path": str(f.path), "error": f.error, "source": "project"})
            return DiscoverResult(capabilities=effective, failures=all_failures)

        # Local host: local source only (CAP-LOAD-003)
        search_paths = resolve_search_paths(
            cwd=resolved_cwd,
            user_dir=storage.capabilities_path if storage is not None else get_default_capabilities_dir(),
            capability_dirs=capability_dirs,
        )
        local_result = asyncio.run(
            load_capabilities_from_search_paths(search_paths, LoadOptions())
        )
        effective = {}
        for cap in local_result.capabilities:
            effective[cap.name] = cls._from_loaded(
                cap, cwd=resolved_cwd, storage=storage, capability_dirs=capability_dirs,
            )
        for f in local_result.failures:
            all_failures.append({"name": f.name, "path": str(f.path), "error": f.error, "source": "local"})

        # Apply local state — enable/disable (CAP-RT-024: sandbox runtimes do not read this)
        local_state_path = (
            storage.local_capability_state_path
            if storage is not None
            else Storage().local_capability_state_path
        )
        local_state = read_local_capability_state(local_state_path)
        disabled: dict[str, Capability] = {}
        for name in list(effective.keys()):
            if local_state.get(name, True) is False:
                disabled[name] = effective.pop(name)

        return DiscoverResult(capabilities=effective, disabled=disabled, failures=all_failures)

    @property
    def name(self) -> str:
        return self._loaded.name

    @property
    def version(self) -> str:
        return self._loaded.version

    @property
    def description(self) -> str | None:
        return self._loaded.manifest.description

    @property
    def path(self) -> Path:
        return self._loaded.path

    @property
    def source(self) -> str:
        return self._loaded.source

    @property
    def component_health(self) -> list[dict[str, t.Any]]:
        return self._loaded.component_health

    @property
    def manifest(self) -> t.Any:
        return self._loaded.manifest

    @property
    def contract(self) -> t.Any:
        return self._loaded.contract

    @property
    def tools(self) -> list[t.Any]:
        return self._wrapped.tools

    @property
    def agents(self) -> list[t.Any]:
        return self._wrapped.agents

    @property
    def skills_path(self) -> Path | None:
        return self._wrapped.skills_path

    @property
    def mcp_server_defs(self) -> list[MCPServerDef]:
        return self._wrapped.mcp_server_defs

    @property
    def skills_paths(self) -> list[Path] | None:
        return self._wrapped.skills_paths

    @property
    def loaded(self) -> LoadedCapability:
        return self._loaded

    @property
    def wrapped(self) -> WrappedCapability:
        return self._wrapped

    def _resolve_loaded(self) -> LoadedCapability:
        load_options = LoadOptions()
        capability_path = Path(self._ref)

        if capability_path.exists():
            return asyncio.run(load_capability_definition(capability_path, load_options))

        search_paths = resolve_search_paths(
            cwd=self._cwd,
            user_dir=(
                self._storage.capabilities_path
                if self._storage is not None
                else get_default_capabilities_dir()
            ),
            capability_dirs=self._capability_dirs,
        )
        result = asyncio.run(load_capabilities_from_search_paths(search_paths, load_options))

        target_name = str(self._ref)
        for capability in result.capabilities:
            if capability.name == target_name:
                return capability

        searched = ", ".join(str(path) for path in search_paths)
        raise FileNotFoundError(f"Capability not found: {target_name}. Searched: {searched}")

    def __repr__(self) -> str:
        return f"Capability(name={self.name!r}, path={str(self.path)!r})"
