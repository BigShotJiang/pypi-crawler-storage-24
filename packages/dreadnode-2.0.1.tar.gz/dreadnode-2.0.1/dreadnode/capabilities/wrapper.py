"""
Capability wrappers — v1 spec.

Wrap capability definitions into SDK primitives (Tool from @tool discovery).
"""

from __future__ import annotations

import importlib.util
import sys
import typing as t
from dataclasses import dataclass, field
from pathlib import Path

from loguru import logger

from dreadnode.capabilities.types import (
    AgentDef,
    LoadedCapability,
    MCPServerDef,
)

if t.TYPE_CHECKING:
    from dreadnode.agents.tools import Tool


# ============================================================================
# Python Tool Discovery
# ============================================================================


def _is_within(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False


def _python_export_paths(
    capability: LoadedCapability,
    configured_paths: list[str] | None,
    default_dir: str,
) -> list[Path]:
    # Explicit empty list = disabled
    if configured_paths is not None and len(configured_paths) == 0:
        return []

    seen_roots: set[Path] = set()
    roots: list[Path] = []

    for relative in [default_dir, *(configured_paths or [])]:
        resolved = (capability.path / relative).resolve()
        if not resolved.exists() or not _is_within(resolved, capability.path):
            continue
        if resolved in seen_roots:
            continue
        seen_roots.add(resolved)
        roots.append(resolved)

    files: list[Path] = []
    for root in roots:
        if root.is_dir():
            files.extend(
                file
                for file in sorted(root.rglob("*.py"))
                if file.name != "__init__.py"
            )
        elif root.suffix.lower() == ".py" and root.name != "__init__.py":
            files.append(root)
    return files


def _load_python_module(file_path: Path, capability: LoadedCapability, kind: str) -> t.Any:
    relative = file_path.resolve().relative_to(capability.path.resolve())
    module_name = (
        f"dreadnode.capabilities.{kind}."
        f"{capability.name.replace('-', '_')}."
        f"{str(relative.with_suffix('')).replace('/', '_').replace('-', '_')}"
    )
    spec = importlib.util.spec_from_file_location(module_name, file_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Could not load module spec for {file_path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def _instantiate_toolset(toolset_cls: type[t.Any]) -> t.Any | None:
    try:
        return toolset_cls()
    except TypeError:
        return None


def _discover_python_tools(capability: LoadedCapability) -> list[t.Any]:
    """Discover Python tools from @dreadnode.tool and Toolset classes."""
    from dreadnode.agents.tools import Tool, Toolset

    tools: list[t.Any] = []
    seen: set[str] = set()
    for file_path in _python_export_paths(capability, capability.contract.tools, "tools/"):
        try:
            module = _load_python_module(file_path, capability, "tool")
        except Exception as e:
            logger.warning(f"[{capability.name}] Failed to import {file_path}: {e}")
            capability.component_health.append({
                "kind": "tool",
                "name": file_path.stem,
                "status": "error",
                "error": str(e),
                "detail": "Check that all dependencies are installed in the runtime environment",
            })
            continue

        for value in vars(module).values():
            if isinstance(value, Tool):
                if value.name not in seen:
                    tools.append(value)
                    seen.add(value.name)
                    capability.component_health.append({
                        "kind": "tool", "name": value.name, "status": "ok", "error": None, "detail": None,
                    })
                continue

            if isinstance(value, Toolset):
                for tool in value.get_tools():
                    if tool.name in seen:
                        continue
                    tools.append(tool)
                    seen.add(tool.name)
                    capability.component_health.append({
                        "kind": "tool", "name": tool.name, "status": "ok", "error": None, "detail": None,
                    })
                continue

            if isinstance(value, type) and issubclass(value, Toolset) and value is not Toolset:
                toolset = _instantiate_toolset(value)
                if toolset is None:
                    logger.warning(
                        f"[{capability.name}] Toolset {value.__name__} requires constructor "
                        f"arguments — skipping auto-instantiation"
                    )
                    capability.component_health.append({
                        "kind": "tool", "name": value.__name__, "status": "error",
                        "error": f"Toolset {value.__name__} requires constructor arguments",
                        "detail": "Provide a no-arg constructor or instantiate the Toolset manually",
                    })
                    continue
                for tool in toolset.get_tools():
                    if tool.name in seen:
                        continue
                    tools.append(tool)
                    seen.add(tool.name)
                    capability.component_health.append({
                        "kind": "tool", "name": tool.name, "status": "ok", "error": None, "detail": None,
                    })
    return tools


# ============================================================================
# Wrapped Capability
# ============================================================================


@dataclass
class WrappedCapability:
    """A fully wrapped capability ready for use with an Agent."""

    name: str
    version: str
    agents: list[AgentDef] = field(default_factory=list)
    tools: list[t.Any] = field(default_factory=list)
    skills_paths: list[Path] | None = None
    skills_path: Path | None = None
    mcp_server_defs: list[MCPServerDef] = field(default_factory=list)


def wrap_capability(capability: LoadedCapability) -> WrappedCapability:
    """Wrap all definitions in a capability."""
    manifest = capability.manifest

    # Tag agents with capability name
    agents = [
        AgentDef(
            name=a.name,
            description=a.description,
            model=a.model,
            system_prompt=a.system_prompt,
            tools=dict(a.tools),
            skills=list(a.skills),
            metadata=a.metadata,
            capability=capability.name,
        )
        for a in manifest.agents
    ]

    # Discover Python @tool functions and Toolset classes
    python_tools = _discover_python_tools(capability)

    return WrappedCapability(
        name=capability.name,
        version=capability.version,
        agents=agents,
        tools=python_tools,
        skills_paths=capability.skills_paths,
        skills_path=capability.skills_path,
        mcp_server_defs=capability.mcp_server_defs,
    )
