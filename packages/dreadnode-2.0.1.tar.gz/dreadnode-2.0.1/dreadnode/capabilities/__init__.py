"""
Dreadnode Capabilities — v1 spec.

Load and use capability packages that extend agent functionality with
agents, tools, skills, and MCP servers.

Example::

    from dreadnode.capabilities import Capability

    capability = Capability("./capabilities/threat-hunting")

    for agent in capability.agents:
        print(agent.name, agent.model)
"""

# Types
from dreadnode.capabilities.types import (
    AgentDef,
    ContractV1,
    LoadedCapability,
    LoadFailure,
    LoadOptions,
    LoadResult,
    MCPServerDef,
    Manifest,
)

# Loader functions
from dreadnode.capabilities.capability import Capability, DiscoverResult
from dreadnode.capabilities.loader import (
    discover_installed_capabilities,
    get_default_capabilities_dir,
    list_capabilities,
    load_and_wrap_capabilities,
    load_and_wrap_capabilities_from_search_paths,
    load_and_wrap_capability,
    load_capabilities,
    load_capabilities_from_search_paths,
    load_capability,
    merge_capabilities,
    resolve_search_paths,
)

# Sync types
from dreadnode.capabilities.sync import (
    SyncError,
    SyncResult,
    WorkspaceSyncClient,
)

# Wrapper types and functions
from dreadnode.capabilities.wrapper import (
    WrappedCapability,
    wrap_capability,
)

__all__ = [
    # Types
    "AgentDef",
    "ContractV1",
    "LoadedCapability",
    "LoadFailure",
    "LoadOptions",
    "LoadResult",
    "MCPServerDef",
    "Manifest",
    "Capability",
    "DiscoverResult",
    # Loader
    "discover_installed_capabilities",
    "get_default_capabilities_dir",
    "list_capabilities",
    "load_and_wrap_capabilities",
    "load_and_wrap_capabilities_from_search_paths",
    "load_and_wrap_capability",
    "load_capabilities",
    "load_capabilities_from_search_paths",
    "load_capability",
    "merge_capabilities",
    "resolve_search_paths",
    # Sync
    "SyncError",
    "SyncResult",
    "WorkspaceSyncClient",
    # Wrapper
    "WrappedCapability",
    "wrap_capability",
]
