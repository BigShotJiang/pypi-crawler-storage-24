"""
Capability type definitions — v1 spec.

See docs/domains/capabilities/contract.md for the canonical schema.
"""

from __future__ import annotations

import typing as t
from dataclasses import dataclass, field
from pathlib import Path


# ============================================================================
# Component Definitions
# ============================================================================


@dataclass
class AgentDef:
    """Agent definition resolved from markdown frontmatter."""

    name: str
    description: str
    model: str = "inherit"
    system_prompt: str = ""
    tools: dict[str, bool] = field(default_factory=dict)
    skills: list[str] = field(default_factory=list)
    metadata: dict[str, t.Any] | None = None
    capability: str | None = None


@dataclass
class MCPServerDef:
    """Parsed MCP server definition from a capability manifest.

    CAP-MCP-002: transport is inferred from fields (command -> stdio, url -> streamable-http).
    """

    name: str
    transport: t.Literal["stdio", "streamable-http"]
    # stdio fields
    command: str | None = None
    args: list[str] = field(default_factory=list)
    env: dict[str, str] | None = None
    cwd: str | Path | None = None
    # streamable-http fields
    url: str | None = None
    headers: dict[str, str] | None = None

    def to_server_config(self) -> t.Any:
        """Convert to an MCPClient-compatible ServerConfig."""
        from dreadnode.agents.mcp.config import HttpServerConfig, StdioServerConfig

        if self.transport == "stdio":
            return StdioServerConfig(
                command=self.command or "",
                args=self.args,
                env=self.env,
                cwd=self.cwd,
            )
        return HttpServerConfig(
            url=self.url or "",
            headers=self.headers,
        )


# ============================================================================
# Capability Contract (capability.yaml on-disk shape)
# ============================================================================


@dataclass
class ContractV1:
    """On-disk capability.yaml — v1 spec.

    See docs/domains/capabilities/contract.md for field semantics.
    Only canonical v1 fields are represented here. Unknown keys in the
    YAML are ignored per CAP-VALID-005.
    """

    schema_version: int  # must be 1 (CAP-VALID-004)
    name: str  # [a-z0-9][a-z0-9-]* (CAP-VALID-002)
    version: str  # semver (CAP-VALID-003)
    description: str  # required (CAP-VALID-001)
    agents: list[str] | None = None  # None=omitted (auto-discover), []=disabled
    tools: list[str] | None = None
    skills: list[str] | None = None
    mcp: dict[str, t.Any] | None = None
    author: dict[str, str] | None = None
    license: str | None = None
    repository: str | None = None
    keywords: list[str] = field(default_factory=list)


# ============================================================================
# Manifest (resolved runtime representation)
# ============================================================================


@dataclass
class Manifest:
    """Resolved runtime manifest from a loaded capability."""

    name: str
    version: str
    description: str = ""
    agents: list[AgentDef] = field(default_factory=list)
    skills: list[str] = field(default_factory=list)
    mcp: dict[str, t.Any] | None = None
    mcp_server_defs: list[MCPServerDef] = field(default_factory=list)


# ============================================================================
# Loaded Capability
# ============================================================================


@dataclass
class LoadedCapability:
    """A loaded and validated capability ready for wrapping."""

    name: str
    version: str
    path: Path
    manifest: Manifest
    contract: ContractV1
    skills_paths: list[Path] | None = None
    skills_path: Path | None = None
    mcp_server_defs: list[MCPServerDef] = field(default_factory=list)
    source: t.Literal["project", "local", "package"] = "local"
    component_health: list[dict[str, t.Any]] = field(default_factory=list)


@dataclass
class LoadFailure:
    """A capability that failed to load."""

    name: str
    path: Path
    error: str


@dataclass
class LoadResult:
    """Result of loading capabilities from search paths."""

    capabilities: list[LoadedCapability] = field(default_factory=list)
    failures: list[LoadFailure] = field(default_factory=list)


@dataclass
class LoadOptions:
    """Options for loading a capability."""

    base_dir: Path | None = None
