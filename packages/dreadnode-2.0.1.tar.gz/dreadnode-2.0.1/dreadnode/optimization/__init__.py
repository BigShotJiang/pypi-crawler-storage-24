from dreadnode.optimization import events, sampling, stopping
from dreadnode.optimization.events import (
    NewBestTrial,
    NewBestTrialFound,
    StudyEnd,
    StudyEvent,
    StudyStart,
    TrialComplete,
    TrialEvent,
    TrialFailed,
    TrialPruned,
    TrialStart,
)
from dreadnode.optimization.result import StudyResult
from dreadnode.optimization.sampler import Sample, Sampler
from dreadnode.optimization.search import (
    Categorical,
    Distribution,
    Float,
    Int,
    SearchSpace,
)
from dreadnode.optimization.stopping import StudyStopCondition
from dreadnode.optimization.study import Direction, Study
from dreadnode.optimization.trial import Trial, TrialStatus

# Backwards compatibility alias
Attack = Study

# Rebuild models to resolve forward references (Trial forward reference)
TrialEvent.model_rebuild()
TrialStart.model_rebuild()
TrialComplete.model_rebuild()
TrialPruned.model_rebuild()
TrialFailed.model_rebuild()
NewBestTrial.model_rebuild()
StudyEnd.model_rebuild()

__all__ = [
    "Categorical",
    "Direction",
    "Distribution",
    "Float",
    "Int",
    "NewBestTrial",
    "NewBestTrialFound",  # backwards compat alias
    "Sample",
    "Sampler",
    "SearchSpace",
    "Study",
    "StudyEnd",
    "StudyEvent",
    "StudyResult",
    "StudyStart",
    "StudyStopCondition",
    "Trial",
    "TrialComplete",
    "TrialEvent",
    "TrialFailed",
    "TrialPruned",
    "TrialStart",
    "TrialStatus",
    "events",
    "sampling",
    "stopping",
]
