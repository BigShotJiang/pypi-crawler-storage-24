import typing as t
from datetime import datetime, timezone
from uuid import UUID, uuid4

import typing_extensions as te
from pydantic import BaseModel, ConfigDict, Field

from dreadnode.tracing.constants import (
    STUDY_ATTRIBUTE_MAX_TRIALS,
    STUDY_ATTRIBUTE_OBJECTIVES,
    STUDY_ATTRIBUTE_SEARCH_STRATEGY,
    TRIAL_ATTRIBUTE_CANDIDATE,
    TRIAL_ATTRIBUTE_ID,
    TRIAL_ATTRIBUTE_SCORES,
    TRIAL_ATTRIBUTE_STATUS,
    TRIAL_ATTRIBUTE_STEP,
)

if t.TYPE_CHECKING:
    from dreadnode.optimization.result import StudyResult
    from dreadnode.optimization.trial import Trial
    from dreadnode.tracing.span import TaskSpan

CandidateT = te.TypeVar("CandidateT", default=t.Any)


# =============================================================================
# Study Events (study-level, emitted to study span)
# =============================================================================


class StudyEvent(BaseModel, t.Generic[CandidateT]):
    """Base class for study-level events."""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc), kw_only=True)
    study_id: UUID = Field(default_factory=uuid4)
    study_name: str | None = None

    def as_dict(self) -> dict[str, t.Any]:
        """Serialize event for transport."""
        return {
            "type": self.__class__.__name__.lower(),
            "timestamp": self.timestamp.isoformat(),
            "study_id": str(self.study_id),
            "study_name": self.study_name,
            "data": self._get_data(),
        }

    def _get_data(self) -> dict[str, t.Any]:
        """Override to provide event-specific data for serialization."""
        return {}

    def emit(self, span: "TaskSpan") -> None:
        """Emit this event's telemetry to the span."""
        span.log_event(
            f"study.{self.__class__.__name__}",
            {"event_type": self.__class__.__name__, "timestamp": self.timestamp.isoformat()},
        )


class StudyStart(StudyEvent[CandidateT]):
    """Signals the beginning of a study."""

    max_trials: int = 0
    objectives: list[str] = Field(default_factory=list)
    search_strategy: str | None = None

    def _get_data(self) -> dict[str, t.Any]:
        return {
            "max_trials": self.max_trials,
            "objectives": self.objectives,
            "search_strategy": self.search_strategy,
        }

    def emit(self, span: "TaskSpan") -> None:
        span.set_attribute(STUDY_ATTRIBUTE_MAX_TRIALS, self.max_trials)
        span.set_attribute(STUDY_ATTRIBUTE_OBJECTIVES, self.objectives)
        if self.search_strategy:
            span.set_attribute(STUDY_ATTRIBUTE_SEARCH_STRATEGY, self.search_strategy)
        span.log_param("max_trials", self.max_trials)
        super().emit(span)


class StudyEnd(StudyEvent[CandidateT]):
    """Signals the end of the study."""

    result: "StudyResult[CandidateT] | None" = Field(default=None, repr=False)
    stop_reason: str = ""
    stop_explanation: str | None = None
    total_trials: int = 0
    finished_trials: int = 0
    failed_trials: int = 0
    pruned_trials: int = 0
    best_trial_id: UUID | None = None
    best_trial_step: int | None = None
    best_score: float | None = None
    best_candidate: t.Any = None
    best_scores: dict[str, float] | None = None

    def _get_data(self) -> dict[str, t.Any]:
        data: dict[str, t.Any] = {
            "stop_reason": self.stop_reason,
            "total_trials": self.total_trials,
            "finished_trials": self.finished_trials,
            "failed_trials": self.failed_trials,
            "pruned_trials": self.pruned_trials,
        }
        if self.stop_explanation:
            data["stop_explanation"] = self.stop_explanation
        if self.best_trial_id is not None:
            data["best_trial_id"] = str(self.best_trial_id)
        if self.best_scores:
            data["best_scores"] = self.best_scores
        return data

    def emit(self, span: "TaskSpan") -> None:
        outputs: dict[str, t.Any] = {
            "stop_reason": self.stop_reason,
            "stop_explanation": self.stop_explanation,
            "completed_trials": self.total_trials,
            "finished_trials": self.finished_trials,
            "failed_trials": self.failed_trials,
            "pruned_trials": self.pruned_trials,
        }
        if self.best_trial_id is not None:
            outputs["best_trial_id"] = str(self.best_trial_id)
            outputs["best_trial_step"] = self.best_trial_step
            outputs["best_score"] = self.best_score
            outputs["best_candidate"] = self.best_candidate
            outputs["best_scores"] = self.best_scores
        span.log_output("study_result", outputs)
        span.log_metric("study/completed_trials", self.total_trials)
        super().emit(span)


# =============================================================================
# Trial Events (trial-level, emitted to trial span - linked via span hierarchy)
# =============================================================================


class TrialEvent(BaseModel, t.Generic[CandidateT]):
    """Base class for trial-level events. Linked to study via span hierarchy."""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc), kw_only=True)
    trial_id: UUID = Field(default_factory=uuid4)
    trial_step: int = 0
    trial: "Trial[CandidateT] | None" = Field(default=None, repr=False, exclude=True)

    def as_dict(self) -> dict[str, t.Any]:
        """Serialize event for transport."""
        return {
            "type": self.__class__.__name__.lower(),
            "timestamp": self.timestamp.isoformat(),
            "trial_id": str(self.trial_id),
            "trial_step": self.trial_step,
            "data": self._get_data(),
        }

    def _get_data(self) -> dict[str, t.Any]:
        """Override to provide event-specific data for serialization."""
        return {}

    def emit(self, span: "TaskSpan") -> None:
        """Emit this event's telemetry to the span."""
        span.log_event(
            f"trial.{self.__class__.__name__}",
            {"event_type": self.__class__.__name__, "timestamp": self.timestamp.isoformat()},
        )


class TrialStart(TrialEvent[CandidateT]):
    """Signals the start of a trial."""

    candidate: t.Any = None

    def _get_data(self) -> dict[str, t.Any]:
        data: dict[str, t.Any] = {}
        if self.candidate is not None:
            data["candidate"] = self.candidate
        return data

    def emit(self, span: "TaskSpan") -> None:
        span.set_attribute(TRIAL_ATTRIBUTE_ID, str(self.trial_id))
        span.set_attribute(TRIAL_ATTRIBUTE_STEP, self.trial_step)
        if self.candidate is not None:
            span.set_attribute(TRIAL_ATTRIBUTE_CANDIDATE, self.candidate)
            span.log_input("candidate", self.candidate)
        super().emit(span)


class TrialComplete(TrialEvent[CandidateT]):
    """Signals that a trial has completed successfully."""

    scores: dict[str, float] = Field(default_factory=dict)

    def _get_data(self) -> dict[str, t.Any]:
        data: dict[str, t.Any] = {}
        if self.scores:
            data["scores"] = self.scores
        return data

    def emit(self, span: "TaskSpan") -> None:
        span.set_attribute(TRIAL_ATTRIBUTE_ID, str(self.trial_id))
        span.set_attribute(TRIAL_ATTRIBUTE_STATUS, "finished")
        if self.scores:
            span.set_attribute(TRIAL_ATTRIBUTE_SCORES, self.scores)
            span.log_output("scores", self.scores)
            for name, score in self.scores.items():
                span.log_metric(f"trial/{name}", score, step=self.trial_step)
        super().emit(span)


class TrialFailed(TrialEvent[CandidateT]):
    """Signals that a trial has failed."""

    error: str = ""

    def _get_data(self) -> dict[str, t.Any]:
        data: dict[str, t.Any] = {}
        if self.error:
            data["error"] = self.error
        return data

    def emit(self, span: "TaskSpan") -> None:
        span.set_attribute(TRIAL_ATTRIBUTE_ID, str(self.trial_id))
        span.set_attribute(TRIAL_ATTRIBUTE_STATUS, "failed")
        if self.error:
            span.log_output("error", self.error[:500])
        super().emit(span)


class TrialPruned(TrialEvent[CandidateT]):
    """Signals that a trial was pruned (constraint not satisfied)."""

    def _get_data(self):
        return {}

    def emit(self, span: "TaskSpan") -> None:
        span.set_attribute(TRIAL_ATTRIBUTE_ID, str(self.trial_id))
        span.set_attribute(TRIAL_ATTRIBUTE_STATUS, "pruned")
        super().emit(span)


class NewBestTrial(TrialEvent[CandidateT]):
    """Signals that a new best trial has been found."""

    candidate: t.Any = None
    scores: dict[str, float] = Field(default_factory=dict)

    def _get_data(self) -> dict[str, t.Any]:
        data: dict[str, t.Any] = {}
        if self.scores:
            data["scores"] = self.scores
        if self.candidate is not None:
            data["candidate"] = self.candidate
        return data

    def emit(self, span: "TaskSpan") -> None:
        span.set_attribute(TRIAL_ATTRIBUTE_ID, str(self.trial_id))
        if self.scores:
            span.set_attribute(TRIAL_ATTRIBUTE_SCORES, self.scores)
            span.log_output("best_scores", self.scores)
        if self.candidate is not None:
            span.log_output("best_candidate", self.candidate)
        super().emit(span)


# Backwards compatibility alias
NewBestTrialFound = NewBestTrial
