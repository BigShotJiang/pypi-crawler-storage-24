import asyncio
import inspect
import typing as t
from contextlib import AsyncExitStack, asynccontextmanager, suppress
from copy import deepcopy
from pathlib import Path
from textwrap import dedent
from time import time
from uuid import UUID, uuid4

from loguru import logger
from pydantic import (
    AfterValidator,
    ConfigDict,
    Field,
    PrivateAttr,
    field_validator,
    model_validator,
)

import dreadnode
from dreadnode.agents.events import (
    AgentEnd,
    AgentError,
    AgentEvent,
    AgentStalled,
    AgentStart,
    AgentStep,
    AgentStopReason,
    GenerationEnd,
    GenerationError,
    GenerationStart,
    GenerationStep,
    ReactStep,
    ToolEnd,
    ToolError,
    ToolStart,
    ToolStep,
)
from dreadnode.agents.reactions import (
    Continue,
    Fail,
    Finish,
    Reaction,
    Retry,
    RetryWithFeedback,
)
from dreadnode.agents.tools import Tool, ToolCall, ToolMode, Toolset, discover_tools_on_obj
from dreadnode.agents.trajectory import Trajectory
from dreadnode.core.exceptions import warn_at_user_stacklevel
from dreadnode.core.execution import Executor
from dreadnode.core.hook import Hook
from dreadnode.core.judge import Judge, Rubric
from dreadnode.core.meta import Component, Config, component
from dreadnode.core.stopping import StopCondition
from dreadnode.core.task import Task, task
from dreadnode.core.transforms import PostTransform, Transform
from dreadnode.core.util import flatten_list, safe_repr
from dreadnode.generators import caching
from dreadnode.generators.chat import Chat
from dreadnode.generators.generator import GenerateParams, Generator, Usage, get_generator
from dreadnode.generators.message import Message, inject_system_content
from dreadnode.generators.models import SystemErrorModel
from dreadnode.transforms import (
    make_tools_to_xml_transform,
    tools_to_json_in_xml_transform,
    tools_to_json_transform,
    tools_to_json_with_tag_transform,
    tools_to_pythonic_transform,
)


class AgentWarning(UserWarning):
    """Warning raised when an agent is used in a way that may not be safe or intended."""


class Agent(Executor[AgentEvent, Trajectory]):
    """
    Agent abstraction for applying tools, event logic, and message state to LLM generation.

    Now extends Executor for consistent streaming/tracing patterns.

    Args:

        name: The name of the agent.
        description: A brief description of the agent.
        tags: Tags associated with the agent.
        label: An optional label for the agent.
        agent_id: The unique identifier for this agent instance.
        model: Inference model (generator or identifier).
        instructions: The agent's core instructions.
        skills: Path(s) to scan for skills. Each path is scanned for directories
            containing SKILL.md files. Skill tools are automatically added when
            skills are found.
        cache: How to handle cache_control entries on inference messages.
        tools: Tools the agent can use.
        tool_mode: The tool calling mode to use.
        stop_conditions: The logical condition for successfully stopping a run.
        hooks: Hooks to apply during agent execution.
        trajectory: Stateful trajectory for this agent.
    """

    model_config = ConfigDict(arbitrary_types_allowed=True, use_attribute_docstrings=True)

    agent_id: UUID = Field(default_factory=uuid4)
    model: str | Generator | None = Config(default=None, expose_as=str | None)
    instructions: t.Annotated[str | None, AfterValidator(lambda x: dedent(x) if x else x)] = Config(
        default=None
    )
    cache: caching.CacheMode | None = Config(default=None, repr=False)
    tools: list[Tool | Toolset] = Config(default_factory=list, validate_default=False)
    tool_mode: ToolMode = Config(default="auto", repr=False)
    hooks: list[Hook] = Config(default_factory=list, repr=False)
    stop_conditions: list[StopCondition[t.Sequence[AgentEvent]]] = Config(
        default_factory=list,
        repr=False,
    )
    judge: Judge[Rubric] | None = Config(default=None, repr=False)
    trajectory: Trajectory = Field(default_factory=Trajectory, exclude=True, repr=False)
    generation_timeout: int | None = Config(default=None)
    """Timeout in seconds for each LLM generation call. None = no timeout."""
    generate_params_extra: dict[str, t.Any] = Config(default_factory=dict)
    """Extra parameters merged into GenerateParams for every generation (e.g. thinking config)."""
    working_dir: Path | None = Config(default=None)
    """Working directory used for tool output offloading and other IO."""

    # Private state
    _generator: Generator | None = PrivateAttr(None, init=False)
    _current_input: str = PrivateAttr("", init=False)

    @field_validator("tools", mode="before")
    @classmethod
    def validate_tools(cls, value: t.Any) -> t.Any:
        resolved = flatten_list(value)

        tools: list[Tool | Toolset] = []
        for tool in resolved:
            if isinstance(tool, (Toolset, Tool)):
                tools.append(tool)
            elif interior_tools := discover_tools_on_obj(tool):
                tools.extend(interior_tools)
            else:
                tools.append(
                    Tool.from_callable(tool if isinstance(tool, Component) else component(tool))
                )
        return tools

    @field_validator("hooks", mode="before")
    @classmethod
    def validate_hooks(cls, value: t.Any) -> list[Hook]:
        if value is None:
            return []
        if callable(value):
            return [value]
        return list(value)

    @field_validator("stop_conditions", mode="before")
    @classmethod
    def validate_stop_conditions(
        cls,
        value: t.Any,
    ) -> list[StopCondition[t.Sequence[AgentEvent]]]:
        return StopCondition.fit_many(value)

    @model_validator(mode="before")
    @classmethod
    def translate_max_steps_to_hook(cls, value: t.Any) -> t.Any:
        if not isinstance(value, dict) or "max_steps" not in value:
            return value

        data = dict(value)
        max_steps = data.pop("max_steps")
        if max_steps is None:
            return data

        from dreadnode.agents import stopping

        step_limit_hook = stopping.step_count(int(max_steps))
        existing_hooks = data.get("hooks")
        if existing_hooks is None:
            data["hooks"] = [step_limit_hook]
        elif isinstance(existing_hooks, list) or isinstance(existing_hooks, tuple):
            data["hooks"] = [*existing_hooks, step_limit_hook]
        else:
            data["hooks"] = [existing_hooks, step_limit_hook]

        return data

    @model_validator(mode="after")
    def bind_tool_working_dir(self) -> "Agent":
        working_dir = self.working_dir or Path.cwd()
        for tool in self.all_tools:
            if tool.working_dir is None:
                tool.working_dir = working_dir
        return self

    def _cleanup_tool_output(self, working_dir: Path) -> None:
        output_dir = working_dir / ".dreadnode" / "tool-output"
        if not output_dir.exists():
            return
        cutoff = time() - (24 * 60 * 60)
        for path in output_dir.iterdir():
            if not path.is_file():
                continue
            with suppress(OSError):
                if path.stat().st_mtime < cutoff:
                    path.unlink()

    @property
    def model_name(self) -> str | None:
        if self.model is not None:
            return self.generator.to_identifier(short=True)
        return None

    @property
    def generator(self) -> Generator:
        if self._generator is not None:
            return self._generator

        if isinstance(self.model, str):
            self._generator = get_generator(self.model)
        elif isinstance(self.model, Generator):
            self._generator = self.model
        else:
            raise TypeError("Model must be a string or a Generator instance.")

        return self._generator

    @property
    def all_tools(self) -> list[Tool]:
        flat_tools: list[Tool] = []
        for item in self.tools:
            if isinstance(item, Toolset):
                flat_tools.extend(item.get_tools())
            elif isinstance(item, Tool):
                flat_tools.append(item)
        return flat_tools

    @property
    def history(self) -> list[Message]:
        """Get conversation history."""
        return self.trajectory.messages

    def _get_transforms(self) -> list[Transform]:
        """Resolve message transforms for the current configuration."""
        transforms = []
        if self.tools:
            match self.tool_mode:
                case "xml":
                    transforms.append(
                        make_tools_to_xml_transform(self.all_tools, add_tool_stop_token=True)
                    )
                case "json-in-xml":
                    transforms.append(tools_to_json_in_xml_transform)
                case "json-with-tag":
                    transforms.append(tools_to_json_with_tag_transform)
                case "json":
                    transforms.append(tools_to_json_transform)
                case "pythonic":
                    transforms.append(tools_to_pythonic_transform)
        return transforms

    async def _generate(self, messages: list[Message]) -> Chat:
        """Execute a single LLM generation step."""
        messages = list(messages)
        extra = dict(self.generate_params_extra) if self.generate_params_extra else {}
        params = GenerateParams(
            tools=[tool.api_definition for tool in self.all_tools],
            timeout=self.generation_timeout,
            extra=extra,
        )

        if self.tool_mode == "auto" and self.tools:
            self.tool_mode = (
                "api" if await self.generator.supports_function_calling() else "json-in-xml"
            )

        transforms = self._get_transforms()
        post_transforms: list[PostTransform | None] = []
        for transform_callback in transforms:
            messages, params, post_transform = await transform_callback(messages, params)
            post_transforms.append(post_transform)

        try:
            messages = caching.apply_cache_mode_to_messages(self.cache, [messages])[0]
            logger.trace(f"Generating with model '{self.generator.model}'. Messages: {messages!r}")

            generated = (await self.generator.generate_messages([messages], [params]))[0]
            if isinstance(generated, BaseException):
                raise generated

            chat = Chat(
                messages,
                [generated.message],
                generator=self.generator,
                params=params,
                stop_reason=generated.stop_reason,
                usage=generated.usage,
                extra=generated.extra,
            )
        except Exception as error:
            logger.opt(exception=True).error("Error during generation")
            chat = Chat(
                messages,
                [],
                generator=self.generator,
                params=params,
                failed=True,
                error=error,
            )

        for post_transform in [tf for tf in post_transforms if tf]:
            chat = await post_transform(chat) or chat

        return chat

    async def _dispatch(self, event: AgentEvent) -> t.AsyncIterator[AgentEvent]:
        """
        Dispatch an event through hooks and handle reactions.

        Hooks are evaluated in order. Each hook may:
        1. Check `when` conditions (ScoringConditions attach metrics as side effects)
        2. Run `scorers` and attach metrics to the event
        3. Return a Reaction to control agent flow

        Metrics attached by hooks are available on event.metrics after dispatch.
        """
        # Run all hooks first (may attach metrics to event)
        hook_reactions: dict[str, Reaction | None] = {}
        for hook in self.hooks:
            hook_name = getattr(hook, "__name__", getattr(hook, "__qualname__", safe_repr(hook)))

            reaction: Reaction | None = None
            try:
                reaction = hook(event)
                if inspect.isawaitable(reaction):
                    reaction = t.cast("Reaction", await reaction)
            except Reaction as r:
                reaction = r

            if reaction is None:
                continue

            logger.debug(f"Hook '{hook_name}' returned reaction: {reaction!r}")

            if not isinstance(reaction, Reaction):
                warn_at_user_stacklevel(
                    f"Hook '{hook_name}' returned {reaction}, expected a Reaction.",
                    AgentWarning,
                )
                continue

            if isinstance(event, (AgentEnd, ReactStep)):
                warn_at_user_stacklevel(
                    f"Hook '{hook_name}' returned {reaction} during {type(event).__name__}, ignored.",
                    AgentWarning,
                )
                continue

            hook_reactions[hook_name] = reaction

        # Yield event after hooks have attached metrics
        yield event

        if not hook_reactions:
            return

        # Priority: Finish > Fail > Retry > Continue
        winning_reaction = next((r for r in hook_reactions.values() if isinstance(r, Finish)), None)
        winning_reaction = winning_reaction or next(
            (r for r in hook_reactions.values() if isinstance(r, Fail)), None
        )
        winning_reaction = winning_reaction or next(
            (r for r in hook_reactions.values() if isinstance(r, (Retry, RetryWithFeedback))), None
        )
        winning_reaction = winning_reaction or next(
            (r for r in hook_reactions.values() if isinstance(r, Continue)), None
        )
        winning_reaction = winning_reaction or next(
            (r for r in hook_reactions.values() if r is not None), None
        )

        if winning_reaction is None:
            return

        winning_hook_name = next(
            (name for name, r in hook_reactions.items() if r is winning_reaction), "unknown"
        )

        async for _event in self._dispatch(
            ReactStep(
                agent_id=self.agent_id,
                hook_name=winning_hook_name,
                reaction=winning_reaction,
            )
        ):
            yield _event

        if isinstance(winning_reaction, Continue):
            messages = list(winning_reaction.messages)
            if winning_reaction.feedback:
                messages.append(Message("user", winning_reaction.feedback))
            raise Continue(messages=messages)
        if isinstance(winning_reaction, RetryWithFeedback):
            messages = [Message("user", winning_reaction.feedback)]
            raise Retry(messages=messages)

        raise winning_reaction

    async def _process_tool_call(
        self, tool_call: "ToolCall", step_count: int
    ) -> t.AsyncGenerator[AgentEvent, None]:
        """Process a single tool call with its own span."""
        with dreadnode.task_span(
            f"tool:{tool_call.name}",
            type="tool",
            label=tool_call.id[:8],
            tags=["tool", tool_call.name],
        ) as t_span:
            start_event = ToolStart(
                agent_id=self.agent_id,
                agent_name=self.name,
                status="running",
                tool_call=tool_call,
            )
            start_event.emit(t_span)
            async for event in self._dispatch(start_event):
                yield event

            tool = next((t for t in self.all_tools if t.name == tool_call.name), None)

            if tool is None:
                error_msg = f"Tool '{tool_call.name}' not found."
                logger.warning(error_msg)

                error_event = ToolError(
                    agent_id=self.agent_id,
                    agent_name=self.name,
                    tool_call=tool_call,
                    error=NameError(error_msg),
                )
                error_event.emit(t_span)
                async for event in self._dispatch(error_event):
                    yield event

                message = Message.from_model(
                    SystemErrorModel(content=f"Tool '{tool_call.name}' not found.")
                )

                step_event = ToolStep(
                    agent_id=self.agent_id,
                    agent_name=self.name,
                    status="running",
                    step=step_count,
                    messages=[message],
                    error=None,
                    stop=False,
                    tool_call=tool_call,
                )
                async for event in self._dispatch(step_event):
                    yield event
                step_event.emit(t_span)  # Emit after dispatch - metrics attached

                return

            if tool.working_dir is None:
                tool.working_dir = self.working_dir or Path.cwd()

            try:
                message, stop = await tool.handle_tool_call(tool_call)

                end_event = ToolEnd(
                    agent_id=self.agent_id,
                    agent_name=self.name,
                    tool_call=tool_call,
                    result=message.content,
                    output_file=message.metadata.get("output_file"),
                    stop=stop,
                )
                async for event in self._dispatch(end_event):
                    yield event
                end_event.emit(t_span)  # Emit after dispatch - metrics attached

                step_event = ToolStep(
                    agent_id=self.agent_id,
                    agent_name=self.name,
                    status="running",
                    step=step_count,
                    messages=[message],
                    error=None,
                    stop=stop,
                    tool_call=tool_call,
                )
                async for event in self._dispatch(step_event):
                    yield event
                step_event.emit(t_span)  # Emit after dispatch - metrics attached

            except Exception as e:
                if isinstance(e, Reaction):
                    raise

                logger.opt(exception=True).error(f"Error executing tool '{tool_call.name}'")

                error_event = ToolError(
                    agent_id=self.agent_id,
                    agent_name=self.name,
                    status="errored",
                    tool_call=tool_call,
                    error=e,
                )
                error_event.emit(t_span)
                async for event in self._dispatch(error_event):
                    yield event
                raise

    async def _stream_batch(self, batch: list[t.Any]) -> t.AsyncGenerator[AgentEvent, None]:
        """
        Batch execution is not supported for agents.

        Use stream() for single-goal execution or run multiple agents concurrently.
        """
        raise NotImplementedError("Agent does not support batch execution. Use stream() instead.")
        yield  # type: ignore[misc]  # Required for generator signature

    async def _stream(self) -> t.AsyncGenerator[AgentEvent, None]:
        """
        Core agent execution loop with inline tracing.

        Events own their telemetry via emit(span). This method just creates
        spans, creates events, calls event.emit(span), and yields.
        """
        messages = [
            *deepcopy(self.trajectory.messages),
            Message("user", str(self._current_input)),
        ]
        messages = inject_system_content(messages, self.instructions)

        self._cleanup_tool_output(self.working_dir or Path.cwd())

        # The user message we just added - needed for trajectory on first step
        user_message = messages[-1]

        step_count = 0
        error: Exception | str | None = None

        async for event in self._dispatch(
            AgentStart(
                agent_id=self.agent_id,
                agent_name=self.name,
                inputs={"goal": self._current_input},
                params={
                    "session_id": str(self.trajectory.session_id),
                    **({"model": self.model_name} if self.model_name else {}),
                    **({"tools": [tool.name for tool in self.all_tools]} if self.all_tools else {}),
                },
            )
        ):
            yield event

        # Core step loop
        while True:
            step_count += 1

            try:
                # Keep generation span open for entire step (generation + tools)
                # This ensures tool spans are children of the generation span
                with dreadnode.task_span(
                    "generation",
                    type="generation",
                    label=f"step:{step_count}",
                    tags=["llm", "generation", self.model_name]
                    if self.model_name
                    else ["llm", "generation"],
                ) as gen_span:
                    # Emit GenerationStart before LLM call
                    gen_start = GenerationStart(
                        agent_id=self.agent_id,
                        agent_name=self.name,
                        generator=self._generator,
                        step=step_count,
                        messages=list(messages),
                    )
                    gen_start.emit(gen_span)
                    async for event in self._dispatch(gen_start):
                        yield event

                    step_chat = await self._generate(messages)

                    if step_chat.failed and step_chat.error:
                        error_event = GenerationError(
                            agent_id=self.agent_id,
                            agent_name=self.name,
                            generator=self._generator,
                            error=step_chat.error,
                            step=step_count,
                        )
                        error_event.emit(gen_span)
                        async for event in self._dispatch(error_event):
                            yield event
                        error = t.cast("Exception", step_chat.error)
                        break

                    step_chat.generated[-1].metadata.update(step_chat.extra)
                    messages.extend(step_chat.generated)

                    # Check stop conditions INSIDE span
                    if any(cond(self.trajectory.steps) for cond in self.stop_conditions):
                        logger.info("A stop condition was met. Ending run.")
                        gen_end = GenerationEnd(
                            agent_id=self.agent_id,
                            agent_name=self.name,
                            generator=self._generator,
                            messages=step_chat.generated,
                            step=step_count,
                            usage=step_chat.usage or Usage(),
                            stop_reason=step_chat.stop_reason,
                        )
                        gen_end.emit(gen_span)
                        async for event in self._dispatch(gen_end):
                            yield event

                        # First step includes user message, subsequent steps only assistant
                        step_messages = (
                            [user_message, *step_chat.generated]
                            if step_count == 1
                            else list(step_chat.generated)
                        )
                        gen_event = GenerationStep(
                            agent_id=self.agent_id,
                            agent_name=self.name,
                            status="running",
                            generator=self._generator,
                            messages=step_messages,
                            step=step_count,
                            usage=step_chat.usage or Usage(),
                            stop_reason=step_chat.stop_reason,
                            extra=step_chat.extra,
                            generation_failed=step_chat.failed,
                        )
                        async for event in self._dispatch(gen_event):
                            yield event
                        gen_event.emit(gen_span)  # Emit after dispatch - metrics attached
                        break

                    # Check if no tool calls - emit GenerationEnd and GenerationStep
                    if not messages[-1].tool_calls:
                        gen_end = GenerationEnd(
                            agent_id=self.agent_id,
                            agent_name=self.name,
                            generator=self._generator,
                            messages=step_chat.generated,
                            step=step_count,
                            usage=step_chat.usage or Usage(),
                            stop_reason=step_chat.stop_reason,
                        )
                        gen_end.emit(gen_span)
                        async for event in self._dispatch(gen_end):
                            yield event

                        # First step includes user message, subsequent steps only assistant
                        step_messages = (
                            [user_message, *step_chat.generated]
                            if step_count == 1
                            else list(step_chat.generated)
                        )
                        gen_event = GenerationStep(
                            agent_id=self.agent_id,
                            agent_name=self.name,
                            status="running",
                            generator=self._generator,
                            messages=step_messages,
                            step=step_count,
                            usage=step_chat.usage or Usage(),
                            stop_reason=step_chat.stop_reason,
                            extra=step_chat.extra,
                            generation_failed=step_chat.failed,
                        )
                        async for event in self._dispatch(gen_event):
                            yield event
                        gen_event.emit(gen_span)  # Emit after dispatch - metrics attached

                        if not self.stop_conditions:
                            break

                        logger.warning(
                            f"Agent '{self.name}' stalled: No tool calls and no stop conditions met."
                        )
                        async for event in self._dispatch(
                            AgentStalled(
                                agent_id=self.agent_id, agent_name=self.name, status="stalled"
                            )
                        ):
                            yield event
                        break

                    # Process tool calls in parallel with streaming events
                    stopped_by_tool_call: ToolCall | None = None
                    tool_messages: list[Message] = []
                    tool_execution_error: Exception | None = None

                    # Queue for events from parallel tool execution
                    event_queue: asyncio.Queue[AgentEvent | None] = asyncio.Queue()

                    async def run_tool_with_queue(tc: ToolCall) -> None:
                        """Run tool and put events in queue."""
                        async for event in self._process_tool_call(tc, step_count):
                            await event_queue.put(event)

                    async def run_all_tools() -> None:
                        """Run all tools and signal completion."""
                        nonlocal tool_execution_error
                        try:
                            await asyncio.gather(
                                *[run_tool_with_queue(tc) for tc in messages[-1].tool_calls]
                            )
                        except Exception as exc:
                            tool_execution_error = exc
                        finally:
                            await event_queue.put(None)  # Signal done

                    # Start tools in background
                    tools_task = asyncio.create_task(run_all_tools())

                    # Yield events as they arrive
                    while True:
                        event = await event_queue.get()
                        if event is None:
                            break
                        yield event
                        if isinstance(event, ToolStep):
                            tool_messages.extend(event.messages)
                            if stopped_by_tool_call is None and event.stop:
                                stopped_by_tool_call = event.tool_call

                    await tools_task  # Ensure task completes
                    if tool_execution_error is not None:
                        raise tool_execution_error
                    messages.extend(tool_messages)

                    # Emit GenerationEnd AFTER tools (closes generation span)
                    gen_end = GenerationEnd(
                        agent_id=self.agent_id,
                        agent_name=self.name,
                        generator=self._generator,
                        messages=step_chat.generated,
                        step=step_count,
                        usage=step_chat.usage or Usage(),
                        stop_reason=step_chat.stop_reason,
                    )
                    gen_end.emit(gen_span)
                    async for event in self._dispatch(gen_end):
                        yield event

                    # GenerationStep for trajectory
                    # First step includes user message, subsequent steps only assistant
                    # Tool results are captured by ToolStep events separately
                    step_messages = (
                        [user_message, *step_chat.generated]
                        if step_count == 1
                        else list(step_chat.generated)
                    )
                    gen_event = GenerationStep(
                        agent_id=self.agent_id,
                        agent_name=self.name,
                        status="running",
                        generator=self._generator,
                        messages=step_messages,
                        step=step_count,
                        usage=step_chat.usage or Usage(),
                        stop_reason=step_chat.stop_reason,
                        extra=step_chat.extra,
                        generation_failed=step_chat.failed,
                    )
                    async for event in self._dispatch(gen_event):
                        yield event
                    gen_event.emit(gen_span)  # Emit after dispatch - metrics attached

                    if stopped_by_tool_call:
                        raise Finish(
                            f"Tool '{stopped_by_tool_call.name}' requested to stop the agent."
                        )

                    # Check stop conditions again INSIDE span
                    if any(cond(self.trajectory.steps) for cond in self.stop_conditions):
                        break

            except Continue as e:
                # Continue with feedback - append messages and proceed
                if e.messages:
                    messages.extend(e.messages)
                continue
            except Retry as e:
                messages = e.messages or messages
                continue
            except Fail as e:
                error = e.error
                break
            except Finish:
                break
            except Exception as e:
                error = e
                break

        # Determine stop reason
        stop_reason: AgentStopReason = "finished"
        if error is not None:
            stop_reason = "error"
        elif self.trajectory.steps and isinstance(self.trajectory.steps[-1], AgentStalled):
            stop_reason = "stalled"

        async for event in self._dispatch(
            AgentEnd(
                agent_id=self.agent_id,
                agent_name=self.name,
                status="errored" if error else "finished",
                stop_reason=stop_reason,
                error=error,
            )
        ):
            yield event

    @asynccontextmanager
    async def stream(
        self, goal: str, *, reset: bool = True
    ) -> t.AsyncIterator[t.AsyncGenerator[AgentEvent, None]]:
        """
        Stream agent execution.

        Args:
            goal: Input message for the agent.
            reset: If True, start new conversation. If False, continue existing.
        """
        self._current_input = goal

        if reset:
            self.trajectory = Trajectory(
                agent_id=self.agent_id,
                system_prompt=self.instructions,
            )

        async with AsyncExitStack() as stack:
            # Enter tool contexts
            for tool_container in self.tools:
                if hasattr(tool_container, "__aenter__") and hasattr(tool_container, "__aexit__"):
                    await stack.enter_async_context(tool_container)

            display_name = self.name or str(self.agent_id)[:8]
            with dreadnode.task_span(
                f"agent:{display_name}",
                type="agent",
                label=display_name,
                tags=["agent"],
            ) as parent_span:

                async def _events() -> t.AsyncGenerator[AgentEvent, None]:
                    async for event in self._stream():
                        # Emit agent-level events to parent span
                        if isinstance(event, (AgentStart, AgentEnd, AgentStalled, AgentError)):
                            event.emit(parent_span)

                        # Track steps in trajectory
                        if isinstance(event, AgentStep):
                            self.trajectory.add_event(event)

                        yield event

                yield _events()

    async def run(self, goal: str, *, reset: bool = True) -> Trajectory:
        """Execute the agent and return the trajectory."""
        async with self.stream(goal, reset=reset) as events:
            async for event in events:
                if isinstance(event, AgentEnd):
                    return self.trajectory

        raise RuntimeError("Agent run finished unexpectedly.")

    def reset(self) -> Trajectory:
        """Reset the agent's internal state."""
        previous = self.trajectory
        self.trajectory = Trajectory(
            agent_id=self.agent_id,
            system_prompt=self.instructions,
        )
        return previous

    def task(self, *, name: str | None = None) -> Task[[str], Trajectory]:
        """
        Convert this agent to a Task for use with Evaluation or Study.

        The resulting Task takes a goal string and returns a Trajectory.
        This is the bridge between Agent and the evaluation/optimization systems.

        Args:
            name: Optional name for the task. Defaults to agent name.

        Returns:
            A Task that wraps agent.run().

        Example:
            ```python
            agent = Agent(name="my_agent", ...)

            # Use with Evaluation
            evaluation = Evaluation(
                task=agent.as_task(),
                dataset=[{"goal": "..."}],
                scorers=[my_scorer],
            )
            result = await evaluation.run()

            # Use with Study
            study = Study(
                task_factory=lambda params: agent.with_(**params).as_task(),
                ...
            )
            ```
        """
        agent = self
        task_name = name or self.name

        @task(name=task_name)
        async def agent_task(goal: str) -> Trajectory:
            return await agent.run(goal)

        return agent_task
