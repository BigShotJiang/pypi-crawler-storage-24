from __future__ import annotations

import json
import typing as t
from dataclasses import dataclass

from dreadnode.app.api.models import HumanPrompt, HumanPromptOption
from dreadnode.app.tui.commands import _extract_generation_text


@dataclass(slots=True)
class NormalizedEvent:
    """Normalized chat event consumed by the TUI reducer."""

    type: str
    session_id: str
    timestamp: str | None = None
    status: str | None = None
    tool_call_id: str | None = None
    tool_name: str | None = None
    tool_args: dict[str, t.Any] | None = None
    assistant_delta: str | None = None
    error_text: str | None = None
    usage_total_tokens: int | None = None
    request_id: str | None = None
    prompt_text: str | None = None
    prompt_options: list[str] | None = None
    human_prompt: HumanPrompt | None = None
    raw: dict[str, t.Any] | None = None
    reasoning_content: str | None = None


def _extract_reasoning_content(payload: dict[str, t.Any]) -> str | None:
    """Extract reasoning/thinking content from event extra dict."""
    extra = payload.get("extra")
    if not isinstance(extra, dict):
        return None
    # OpenAI/DeepSeek: reasoning_content is a plain string
    rc = extra.get("reasoning_content")
    if isinstance(rc, str) and rc:
        return rc
    # Anthropic: thinking_blocks is a list of {type, thinking} dicts
    blocks = extra.get("thinking_blocks")
    if isinstance(blocks, list):
        parts = [
            b["thinking"]
            for b in blocks
            if isinstance(b, dict) and isinstance(b.get("thinking"), str)
        ]
        return "\n".join(parts) if parts else None
    return None


def normalize_event(raw: dict[str, t.Any], session_id: str) -> NormalizedEvent:
    """Convert raw server SSE event payload into a stable normalized shape."""
    event_type = str(raw.get("type", "")).lower()
    payload = raw.get("data") if isinstance(raw.get("data"), dict) else raw
    if not isinstance(payload, dict):
        payload = raw

    timestamp = raw.get("timestamp")
    status = raw.get("status")
    usage_total_tokens = _usage_total_tokens(payload.get("usage"))
    tool_call_id, tool_name, tool_args = _extract_tool_fields(payload)
    base: dict[str, t.Any] = {
        "session_id": session_id,
        "timestamp": _as_str(timestamp),
        "status": _as_str(status),
        "raw": raw,
    }
    normalized = NormalizedEvent(type="unknown", **base)

    if event_type == "generationstart":
        normalized = NormalizedEvent(
            type="generation_start", usage_total_tokens=usage_total_tokens, **base
        )
    elif event_type == "generationstep":
        normalized = NormalizedEvent(
            type="generation_step",
            assistant_delta=_extract_generation_text(payload) or None,
            usage_total_tokens=usage_total_tokens,
            reasoning_content=_extract_reasoning_content(payload),
            **base,
        )
    elif event_type == "generationend":
        normalized = NormalizedEvent(
            type="generation_end", usage_total_tokens=usage_total_tokens, **base
        )
    elif event_type == "generationerror":
        normalized = NormalizedEvent(
            type="generation_error",
            error_text=_as_str(payload.get("error")) or "Generation error",
            **base,
        )
    elif event_type == "toolstart":
        normalized = NormalizedEvent(
            type="tool_start",
            tool_call_id=tool_call_id,
            tool_name=tool_name,
            tool_args=tool_args or {},
            **base,
        )
    elif event_type == "toolend":
        normalized = NormalizedEvent(
            type="tool_end",
            tool_call_id=tool_call_id,
            tool_name=tool_name,
            tool_args=tool_args or {},
            **base,
        )
    elif event_type == "toolerror":
        normalized = NormalizedEvent(
            type="tool_error",
            tool_call_id=tool_call_id,
            tool_name=tool_name,
            tool_args=tool_args or {},
            error_text=_as_str(payload.get("error")) or "Tool error",
            **base,
        )
    elif event_type == "toolstep":
        normalized = NormalizedEvent(
            type="tool_step",
            tool_call_id=tool_call_id,
            tool_name=tool_name,
            tool_args=tool_args or {},
            **base,
        )
    elif event_type == "permissionrequired":
        tool_name = _as_str(payload.get("tool_name"))
        question = (
            _as_str(payload.get("description"))
            or _as_str(payload.get("tool_args"))
            or (f"Approve {tool_name}?" if tool_name else "Approval required")
        )
        prompt = HumanPrompt(
            request_id=_as_str(payload.get("request_id") or payload.get("requestId")) or "",
            kind="approval",
            question=question,
            details=_as_str(payload.get("details")),
            allow_free_text=False,
            default_option=_as_str(payload.get("default_option")),
            severity=_as_str(payload.get("severity")),
            source_tool_name=tool_name,
            source_tool_call_id=_as_str(payload.get("tool_call_id")),
        )
        normalized = NormalizedEvent(
            type="human_prompt",
            request_id=prompt.request_id,
            tool_name=tool_name,
            prompt_text=prompt.question,
            human_prompt=prompt,
            **base,
        )
    elif event_type == "userinputrequired":
        options = payload.get("options")
        prompt_options: list[HumanPromptOption] | None = None
        if isinstance(options, list):
            prompt_options = [
                HumanPromptOption(
                    label=str(o.get("label")),
                    description=_as_str(o.get("description")),
                )
                if isinstance(o, dict)
                else HumanPromptOption(label=str(o))
                for o in options
            ]
        kind = _as_str(payload.get("kind"))
        inferred_kind = kind if kind in {"input", "choice", "approval"} else None
        if inferred_kind is None:
            inferred_kind = "choice" if prompt_options else "input"
        allow_free_text = payload.get("allow_free_text")
        if allow_free_text is None:
            allow_free_text = inferred_kind == "input"
        prompt = HumanPrompt(
            request_id=_as_str(payload.get("request_id") or payload.get("requestId")) or "",
            kind=inferred_kind,
            question=_as_str(payload.get("question")) or "",
            details=_as_str(payload.get("details")),
            options=prompt_options,
            allow_free_text=bool(allow_free_text),
            default_option=_as_str(payload.get("default_option")),
            severity=_as_str(payload.get("severity")),
            source_tool_name=_as_str(payload.get("source_tool_name")),
            source_tool_call_id=_as_str(payload.get("source_tool_call_id")),
        )
        normalized = NormalizedEvent(
            type="human_prompt",
            request_id=prompt.request_id,
            prompt_text=prompt.question,
            prompt_options=[opt.label for opt in prompt.options] if prompt.options else None,
            human_prompt=prompt,
            **base,
        )
    elif event_type == "heartbeat":
        normalized = NormalizedEvent(
            type="heartbeat",
            prompt_text=_as_str(payload.get("message")),
            **base,
        )
    elif event_type == "agentstart":
        normalized = NormalizedEvent(type="agent_start", **base)
    elif event_type == "agentend":
        normalized = NormalizedEvent(
            type="agent_end", error_text=_as_str(payload.get("error")), **base
        )
    elif event_type == "agenterror":
        normalized = NormalizedEvent(
            type="agent_error", error_text=_as_str(payload.get("error")), **base
        )
    elif event_type == "agentstalled":
        normalized = NormalizedEvent(
            type="agent_stalled",
            error_text=_as_str(payload.get("reason")) or "Agent stalled",
            **base,
        )
    elif event_type == "error":
        normalized = NormalizedEvent(
            type="runtime_error",
            error_text=_as_str(raw.get("error"))
            or _as_str(payload.get("error"))
            or "Runtime error",
            **base,
        )
    return normalized


def _extract_tool_fields(
    payload: dict[str, t.Any],
) -> tuple[str | None, str | None, dict[str, t.Any] | None]:
    tool_call = payload.get("tool_call")
    if not isinstance(tool_call, dict):
        tool_call = payload.get("toolCall")
    if not isinstance(tool_call, dict):
        return (None, None, None)

    call_id = _as_str(tool_call.get("id"))
    name = _as_str(tool_call.get("name"))
    args = tool_call.get("arguments")
    if args is None and isinstance(tool_call.get("function"), dict):
        args = tool_call["function"].get("arguments")
    parsed_args = _parse_tool_args(args)
    return (call_id, name, parsed_args)


def _parse_tool_args(value: t.Any) -> dict[str, t.Any] | None:
    if isinstance(value, dict):
        return value
    if isinstance(value, str):
        stripped = value.strip()
        if not stripped:
            return {}
        try:
            loaded = json.loads(stripped)
        except (json.JSONDecodeError, TypeError):
            return {"raw": stripped}
        if isinstance(loaded, dict):
            return loaded
        return {"raw": stripped}
    return {}


def _as_str(value: t.Any) -> str | None:
    if value is None:
        return None
    if isinstance(value, str):
        return value
    return str(value)


def _usage_total_tokens(usage: t.Any) -> int | None:
    if not isinstance(usage, dict):
        return None
    total = usage.get("total_tokens")
    if total is None:
        return None
    try:
        return int(total)
    except (TypeError, ValueError):
        return None
