from __future__ import annotations

import argparse
import asyncio
import json
import logging
import os
import re
import time
import typing as t
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

import httpx
from textual import on, work
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.events import Key
from textual.reactive import reactive
from textual.theme import Theme
from textual.widgets import Static, TextArea

from dreadnode.app.api.client import ApiClient, AuthenticationError
from dreadnode.app.api.models import HumanInputResponse, HumanPrompt, HumanPromptOption
from dreadnode.app.server.session import ServerConfig, UserConfig
from dreadnode.app.tui.client import (
    DEFAULT_MODEL,
    RuntimeInfo,
    RuntimeServerClient,
    SessionInfo,
)
from dreadnode.app.tui.commands import (
    DEFAULT_PLATFORM_URL,
    _active_profile,
    _default_project_for_workspace,
    _delete_active_profile,
    _format_tool_label,
    _login_with_api_key,
    _parse_login_args,
    _platform_client,
    _save_profile,
    _summarize_tool_result,
)
from dreadnode.app.tui.event_contract import NormalizedEvent, normalize_event
from dreadnode.app.tui.screens import (
    AuthModal,
    CapabilitiesScreen,
    ConsoleScreen,
    EnvironmentScreen,
    EvaluationsScreen,
    HubScreen,
    RuntimeScreen,
    SandboxScreen,
    SecretsScreen,
    TracesScreen,
)
from dreadnode.app.tui.screens.model_picker import ModelPickerOverlay
from dreadnode.app.tui.theme import (
    ACCENT,
    BG,
    ERROR,
    FG,
    FG_FAINTEST,
    FG_MUTED,
    FG_SUBTLE,
    INFO,
    SUCCESS,
    WARNING,
)
from dreadnode.app.tui.turn_reducer import (
    ToolRun,
    TurnState,
    reduce_event,
    reduce_human_prompt_response,
)
from dreadnode.app.tui.widgets import (
    ConversationView,
    Flash,
    MentionOverlay,
    MessageQueue,
    PermissionPrompt,
    SessionListEntry,
    SlashOverlay,
    StreamingDraft,
    ToolProgress,
    TranscriptEntry,
    Welcome,
    render_help,
)
from dreadnode.app.tui.widgets.agent_dialog import AgentDialog
from dreadnode.app.tui.widgets.composer import ComposerInput
from dreadnode.app.tui.widgets.context_bar import PageStatus, SessionContextBar
from dreadnode.app.tui.widgets.mcp_dialog import McpDialog
from dreadnode.app.tui.widgets.nav_sidebar import NavSidebar
from dreadnode.app.tui.widgets.status_bar import StatusBar
from dreadnode.app.tui.widgets.tools_dialog import ToolsDialog
from dreadnode.core.log import (
    configure_logging,
    enable_tui_capture,
    install_stdlib_intercept,
    log_buffer,
)

logger = logging.getLogger(__name__)


@dataclass(slots=True)
class SessionRecord:
    """UI-side cache for one runtime session."""

    info: SessionInfo
    transcript: list[TranscriptEntry] = field(default_factory=list)
    title: str | None = None


_MAX_HISTORY = 500
_HISTORY_FILE = Path.home() / ".dreadnode" / "prompt-history.jsonl"


class DreadnodeTextualApp(App[None]):
    """Server-first Textual frontend for the Dreadnode runtime."""

    CSS_PATH = "dreadnode.tcss"
    ENABLE_COMMAND_PALETTE = False

    BINDINGS = [
        Binding("ctrl+b", "toggle_sidebar", "Sidebar", show=False),
        Binding("ctrl+t", "open_traces", "Traces", show=False),
        Binding("ctrl+s", "open_sandboxes", "Sandbox", show=False),
        Binding("ctrl+e", "open_evaluations", "Evals", show=False),
        Binding("ctrl+y", "open_runtimes", "Runs", show=False),
        Binding("f5", "open_console", "Console", show=False),
        Binding("f6", "open_secrets", "Secrets", show=False),
        Binding("f7", "open_hub", "Hub", show=False),
        Binding("ctrl+a", "select_agent", "Agent", show=False),
        Binding("f8", "open_environments", "Env", show=True),
        Binding("ctrl+k", "select_model", "Model", show=False),
        Binding("ctrl+shift+k", "cycle_effort", "Effort", show=False),
        Binding("ctrl+n", "new_session", "New", show=False),
        Binding("ctrl+r", "reset_session", "Reset", show=False),
        Binding("ctrl+c", "request_quit", "Quit", show=False),
        Binding("tab", "cycle_focus", "Focus", show=False),
        Binding("escape", "handle_escape", "Escape", show=False),
    ]

    # -- Reactives bound to widgets via data_bind --
    status_text: reactive[str] = reactive("Booting")
    session_label: reactive[str] = reactive("none")
    busy: reactive[bool] = reactive(False)
    authenticated: reactive[bool] = reactive(False)
    agent_name: reactive[str] = reactive("default")
    working_dir: reactive[str] = reactive("")
    connection: reactive[str] = reactive("local")
    total_tokens: reactive[int] = reactive(0)
    workspace_label: reactive[str] = reactive("")
    model_name: reactive[str] = reactive("")
    effort_label: reactive[str] = reactive("")
    runtime_health: reactive[str] = reactive("")

    def __init__(self, server_url: str | None = None, platform_url: str | None = None) -> None:
        super().__init__()
        self.scroll_sensitivity_y = 5
        self.server_url = server_url
        self._platform_override = platform_url
        self.model: str = DEFAULT_MODEL
        self.server_client = RuntimeServerClient(
            server_url=server_url,
            auto_start=server_url is None,
        )
        self.runtime_info: RuntimeInfo | None = None
        self.sessions: dict[str, SessionRecord] = {}
        self.active_session_id: str | None = None
        self._draft_active = False
        self._turn_state: dict[str, TurnState] = {}
        self._tool_details_mode: t.Literal["compact", "expanded"] = "compact"
        self.thinking_enabled: bool = False
        # Per-model variant state: model_id → effort label (e.g. "high")
        self._model_variants: dict[str, str] = {}
        self._show_thinking: bool = True  # Expanded by default
        self._inline_activity_sessions: set[str] = set()

        # Prompt history
        self._prompt_history: list[str] = []
        self._history_index: int = -1
        self._history_stash: str = ""

        # Turn counting for separators
        self._turn_counts: dict[str, int] = {}

        # Message queue (per-session)
        self._pending_messages: dict[str, list[str]] = {}

        # Permission tracking
        self._session_allowlist: dict[str, set[str]] = {}

        # Sidebar state — tracks manual toggle so on_resize won't override
        self._sidebar_manually_hidden = False

        # Double-tap tracking for quit (shared by Escape and Ctrl+C)
        self._last_quit_time: float = 0.0

        # Load persistent prompt history
        self._load_prompt_history()

        # Sync model name to status bar
        self.model_name = self.model

        self.register_theme(
            Theme(
                name="dreadnode",
                primary=ACCENT,
                secondary=SUCCESS,
                accent=INFO,
                warning=WARNING,
                error=ERROR,
                success=SUCCESS,
                dark=True,
                background=BG,
                surface=BG,
                panel=BG,
            )
        )
        self.theme = "dreadnode"

    @property
    def generate_params_extra(self) -> dict[str, t.Any]:
        """Build generate_params_extra from current thinking/effort settings."""
        if not self.thinking_enabled or not self.effort_label:
            return {}
        from dreadnode.app.tui.model_variants import get_variants

        variants = get_variants(self.model)
        if self.effort_label in variants:
            return dict(variants[self.effort_label])
        return {}

    # ==================================================================
    # Compose
    # ==================================================================

    def compose(self) -> ComposeResult:
        with Vertical(id="main-body"):
            yield NavSidebar(id="sidebar")
            yield self._build_welcome()
            yield ConversationView(
                id="conversation",
            )
            yield PermissionPrompt(id="human-prompt")
            yield SlashOverlay(id="slash-overlay")
            yield MentionOverlay(id="mention-overlay")
            yield ModelPickerOverlay(id="model-picker-overlay")
            yield AgentDialog(id="agent-dialog")
            yield McpDialog(id="mcp-dialog")
            yield ToolsDialog(id="tools-dialog")
            yield Flash(id="flash")
            yield MessageQueue(id="message-queue")
            yield self._build_session_context_bar()  # Zone 1
            yield Horizontal(  # Zone 2
                Static("> ", id="prompt-char"),
                ComposerInput(id="composer"),
                id="composer-bar",
            )
            yield self._build_page_status()  # Zone 3
        yield self._build_status_bar()  # Zone 4

    def _build_welcome(self) -> Welcome:
        try:
            from dreadnode.version import VERSION
        except Exception:
            VERSION = ""
        welcome = Welcome(id="welcome")
        welcome.version = VERSION
        welcome.working_dir = str(Path.cwd())
        return welcome

    def _build_session_context_bar(self) -> SessionContextBar:
        bar = SessionContextBar(id="session-context-bar")
        bar.data_bind(
            agent_name=DreadnodeTextualApp.agent_name,
            model_name=DreadnodeTextualApp.model_name,
            effort_label=DreadnodeTextualApp.effort_label,
            busy=DreadnodeTextualApp.busy,
            status_text=DreadnodeTextualApp.status_text,
        )
        return bar

    def _build_page_status(self) -> PageStatus:
        status = PageStatus(id="page-status")
        status.data_bind(
            total_tokens=DreadnodeTextualApp.total_tokens,
        )
        return status

    def _build_status_bar(self) -> StatusBar:
        bar = StatusBar(id="status-bar")
        bar.data_bind(
            connection=DreadnodeTextualApp.connection,
            workspace_label=DreadnodeTextualApp.workspace_label,
            runtime_health=DreadnodeTextualApp.runtime_health,
        )
        return bar

    # ==================================================================
    # Watchers
    # ==================================================================

    def watch_authenticated(self, value: bool) -> None:
        try:
            from textual.app import ScreenStackError
            from textual.css.query import NoMatches

            composer = self.query_one("#composer", ComposerInput)
        except (NoMatches, ScreenStackError):
            return
        composer.disabled = not value
        try:
            composer_bar = self.query_one("#composer-bar")
            composer_bar.set_class(not value, "-disabled")
        except Exception:
            pass
        if value:
            composer.focus()

    # ==================================================================
    # Lifecycle
    # ==================================================================

    def on_mount(self) -> None:
        enable_tui_capture()
        install_stdlib_intercept()
        self._set_composer_enabled(False)
        # Hide conversation while welcome is showing
        self.query_one("#conversation", ConversationView).display = False
        self._sync_conversation()
        self._sync_sessions()
        self._update_context()
        self._boot()

    async def on_unmount(self) -> None:
        await self.server_client.close()

    def on_resize(self) -> None:
        # Auto-hide sidebar at narrow widths to preserve content space
        sidebar = self.query_one("#sidebar", NavSidebar)
        if self.size.width < 80:
            sidebar.add_class("-hidden")
        elif sidebar.has_class("-hidden") and not self._sidebar_manually_hidden:
            sidebar.remove_class("-hidden")

    # ==================================================================
    # Input handling (using @on for explicit event binding)
    # ==================================================================

    @on(TextArea.Changed, "#composer")
    def _on_composer_changed(self, event: TextArea.Changed) -> None:
        slash_overlay = self.query_one("#slash-overlay", SlashOverlay)
        mention_overlay = self.query_one("#mention-overlay", MentionOverlay)
        value = event.text_area.text

        if self._active_human_prompt() is not None:
            slash_overlay.hide()
            mention_overlay.hide()
            return

        # Slash commands: /foo
        if value.startswith("/") and " " not in value:
            mention_overlay.hide()
            slash_overlay.filter_commands(value)
            return

        # @ mentions: show agents from capabilities
        at_match = re.search(r"@(\S*)$", value)
        if at_match:
            slash_overlay.hide()
            mention_overlay.filter(at_match.group(1))
            return

        slash_overlay.hide()
        mention_overlay.hide()

    @on(ComposerInput.Submitted)
    def _on_composer_submitted(self, event: ComposerInput.Submitted) -> None:
        value = event.value
        self.query_one("#slash-overlay", SlashOverlay).hide()
        self.query_one("#mention-overlay", MentionOverlay).hide()
        self._dismiss_welcome()

        if not value:
            return

        prompt = self._active_human_prompt()
        if prompt is not None:
            self._submit_human_prompt_response(prompt, value)
            return

        # Slash commands always execute immediately (never queued)
        if value.startswith("/"):
            self._handle_command(value)
            return

        # Shell commands always execute immediately
        if value.startswith("!"):
            shell_cmd = value[1:].strip()
            if shell_cmd:
                self._execute_shell(shell_cmd)
            return

        # Bare exit/quit commands (matches OpenCode behavior)
        if value.strip().lower() in {"exit", "quit", ":q"}:
            self.exit()
            return

        # Store in history (in-memory + persistent file)
        if value and (not self._prompt_history or self._prompt_history[-1] != value):
            self._prompt_history.append(value)
            if len(self._prompt_history) > _MAX_HISTORY:
                self._prompt_history.pop(0)
            self._save_prompt_entry(value)
        self._history_index = -1

        # If busy, queue the message instead of sending
        if self.busy:
            self._enqueue_message(value)
            return

        if at_match := re.match(r"^@(\S+)\s+([\s\S]+)$", value):
            self._send_chat_to_agent(at_match.group(2), at_match.group(1))
        else:
            # Show user message + thinking indicator immediately (before @work schedules)
            # so the first render frame already shows the conversation with user input.
            session = self._active_session()
            if session is not None:
                sid = session.info.session_id
                self._turn_counts.setdefault(sid, 0)
                self._turn_counts[sid] += 1
                entry = TranscriptEntry(
                    kind="user", title="user", body=value, turn=self._turn_counts[sid]
                )
                record = self.sessions.get(sid)
                if record is not None:
                    record.transcript.append(entry)
                conv = self.query_one("#conversation", ConversationView)
                conv.append_entry(entry)
                self._set_status("Thinking", busy=True)
                conv.query_one(ToolProgress).show_activity("thinking")
                self._send_chat(value, _user_entry_shown=True)
            else:
                self._send_chat(value)

    def _submit_human_prompt_response(self, prompt: HumanPrompt, raw_value: str) -> None:
        """Handle composer submission while a human prompt is active."""
        value = raw_value.strip()
        if not value:
            return

        action = "submit"
        text: str | None = value
        selected_option: str | None = None

        if prompt.kind == "approval":
            lowered = value.lower()
            if lowered in {"allow_session", "allow session", "session"}:
                action = "allow_session"
                text = None
            elif lowered in {"deny", "no", "n"}:
                action = "deny"
                text = None
            elif lowered in {"allow", "approve", "yes", "y"}:
                action = "approve"
                text = None
            else:
                action = "deny"
                text = None

        if prompt.kind in {"input", "choice"} and prompt.options:
            matched = self._match_prompt_option(prompt.options, value)
            if matched is not None:
                selected_option = matched
                text = None
            elif not prompt.allow_free_text:
                self._flash("Please select a valid option", severity="warning")
                return

        sid = self.active_session_id
        if sid:
            self._append_transcript(
                TranscriptEntry(kind="user", title="user", body=value),
                sid,
            )
            status_body = "Prompt response sent"
            if action in {"cancel", "deny"}:
                status_body = "Prompt cancelled"
            elif action in {"approve", "allow_session"}:
                status_body = "Prompt approved"
            self._append_transcript(
                TranscriptEntry(kind="system", title="system", body=status_body),
                sid,
            )

        self.query_one("#human-prompt", PermissionPrompt).hide_prompt()
        self.query_one("#composer", ComposerInput).placeholder = ""

        self._send_human_input_response(
            prompt.request_id,
            action,
            text=text,
            selected_option=selected_option,
            tool_name=prompt.source_tool_name,
        )

    @staticmethod
    def _match_prompt_option(options: list[HumanPromptOption], value: str) -> str | None:
        value = value.strip()
        if not value:
            return None
        if value.isdigit():
            idx = int(value) - 1
            if 0 <= idx < len(options):
                return options[idx].label
        lowered = value.lower()
        for option in options:
            if option.label.lower() == lowered:
                return option.label
        return None

    @on(ComposerInput.HelpRequested)
    def _on_help_requested(self) -> None:
        """Show help inline when ? is pressed in empty composer."""
        self._show_help()

    def on_key(self, event: Key) -> None:
        """Global key routing for history and vim-style navigation."""
        # Only handle keys on the main screen where composer/conversation exist
        composer_results = self.screen.query(ComposerInput)
        conversation_results = self.screen.query(ConversationView)
        if not len(composer_results) or not len(conversation_results):
            return
        composer = composer_results.first()
        conversation = conversation_results.first()

        # ? shows help when conversation is focused (composer handled via HelpRequested)
        if event.key == "question_mark" and conversation.has_focus:
            event.prevent_default()
            event.stop()
            self._show_help()
            return

        # Prompt history & queue retract: Up when cursor is on first line
        if event.key == "up" and composer.has_focus:
            if not self._has_active_overlay() and composer.cursor_location[0] == 0:
                # If composer is empty and queue has items, retract from queue
                if not composer.text and self._has_queued_messages():
                    event.prevent_default()
                    message = self._retract_last_queued()
                    if message:
                        self._set_composer_text(composer, message)
                    return
                event.prevent_default()
                self._history_navigate(-1)
                return

        if event.key == "down" and composer.has_focus:
            last_row = len(composer.document.lines) - 1
            if not self._has_active_overlay() and composer.cursor_location[0] >= last_row:
                event.prevent_default()
                self._history_navigate(1)
                return

        # Vim-like navigation when conversation is focused
        if conversation.has_focus:
            if event.key == "j":
                event.prevent_default()
                conversation.scroll_down(animate=False)
                return
            if event.key == "k":
                event.prevent_default()
                conversation.scroll_up(animate=False)
                return
            if event.key == "g":
                event.prevent_default()
                conversation.scroll_home(animate=False)
                return
            if event.key == "G":
                event.prevent_default()
                conversation.scroll_end(animate=False)
                return
            if event.key == "ctrl+u":
                event.prevent_default()
                conversation.scroll_up(animate=False)
                conversation.scroll_up(animate=False)
                conversation.scroll_up(animate=False)
                return
            if event.key == "ctrl+d":
                event.prevent_default()
                conversation.scroll_down(animate=False)
                conversation.scroll_down(animate=False)
                conversation.scroll_down(animate=False)
                return
            if event.key == "y":
                event.prevent_default()
                self._copy_last_assistant()
                return

    def _has_active_overlay(self) -> bool:
        """Check if any overlay (slash/mention/model/agent/mcp/tools) is currently visible."""
        slash = self.query_one("#slash-overlay", SlashOverlay)
        mention = self.query_one("#mention-overlay", MentionOverlay)
        picker = self.query_one("#model-picker-overlay", ModelPickerOverlay)
        agent = self.query_one("#agent-dialog", AgentDialog)
        mcp = self.query_one("#mcp-dialog", McpDialog)
        tools = self.query_one("#tools-dialog", ToolsDialog)
        return (
            slash.is_visible
            or mention.is_visible
            or picker.is_visible
            or agent.is_visible
            or mcp.is_visible
            or tools.is_visible
        )

    @on(SlashOverlay.SlashSelected)
    def _on_slash_selected(self, event: SlashOverlay.SlashSelected) -> None:
        composer = self.query_one("#composer", ComposerInput)
        text = event.command + " "
        composer.load_text(text)
        composer.move_cursor_relative(rows=0, columns=len(text))
        composer.focus()

    @on(MentionOverlay.AgentSelected)
    def _on_agent_mentioned(self, event: MentionOverlay.AgentSelected) -> None:
        composer = self.query_one("#composer", ComposerInput)
        # Replace the @prefix at the end with the selected agent name
        current = composer.value
        at_match = re.search(r"@\S*$", current)
        if at_match:
            before = current[: at_match.start()]
            text = f"{before}@{event.agent_name} "
        else:
            text = f"{current}@{event.agent_name} "
        composer.load_text(text)
        composer.move_cursor_relative(rows=0, columns=len(text))
        composer.focus()

    @on(PermissionPrompt.Action)
    def _on_human_prompt_action(self, event: PermissionPrompt.Action) -> None:
        self._send_human_input_response(event.request_id, event.action)

    # ==================================================================
    # Actions (keybindings)
    # ==================================================================

    def action_toggle_sidebar(self) -> None:
        sidebar = self.query_one("#sidebar", NavSidebar)
        sidebar.toggle_class("-hidden")
        self._sidebar_manually_hidden = sidebar.has_class("-hidden")

    @on(NavSidebar.SessionSelected)
    def _on_sidebar_session_selected(self, event: NavSidebar.SessionSelected) -> None:
        self._switch_session(event.session_id)

    def action_new_session(self) -> None:
        self._create_new_session()

    def action_reset_session(self) -> None:
        self._reset_active_session()

    def action_select_model(self) -> None:
        """Toggle model picker overlay."""
        self._open_model_picker()

    def _open_model_picker(self) -> None:
        """Show the inline model picker overlay."""
        from dreadnode.app.tui.model_variants import KNOWN_MODELS

        overlay = self.query_one("#model-picker-overlay", ModelPickerOverlay)
        if overlay.is_visible:
            overlay.hide()
            return

        models = list(KNOWN_MODELS)
        if self.model not in models:
            models.insert(0, self.model)
        overlay.show_models(models, self.model)

    @on(ModelPickerOverlay.ModelSelected)
    def _on_model_picker_selected(self, event: ModelPickerOverlay.ModelSelected) -> None:
        if event.model_id != self.model:
            self._on_model_changed(event.model_id)
            self._flash(f"Model: {event.model_id}", severity="info")

    def action_select_agent(self) -> None:
        """Toggle agent picker dialog."""
        dialog = self.query_one("#agent-dialog", AgentDialog)
        if dialog.is_visible:
            dialog.hide()
            return
        if not self.runtime_info:
            self._flash("No runtime info available", severity="warning")
            return
        dialog.show_agents(self._collect_agents(), current=self.agent_name)

    @on(AgentDialog.AgentSelected)
    def _on_agent_dialog_selected(self, event: AgentDialog.AgentSelected) -> None:
        if event.agent_name != self.agent_name:
            self._set_active_session_agent(event.agent_name)
            self._flash(f"Agent: {event.agent_name}", severity="info")

    def _open_mcp_dialog(self) -> None:
        """Toggle MCP status dialog."""
        dialog = self.query_one("#mcp-dialog", McpDialog)
        if dialog.is_visible:
            dialog.hide()
            return
        servers = self._collect_mcp_servers()
        dialog.show_servers(servers)

    def _collect_mcp_servers(self) -> list[dict[str, str | None]]:
        """Extract MCP server health from runtime info components."""
        if not self.runtime_info:
            return []
        servers: list[dict[str, str | None]] = []
        for cap in self.runtime_info.capabilities:
            for comp in cap.components or []:
                kind = comp.get("kind") if isinstance(comp, dict) else getattr(comp, "kind", None)
                if kind == "mcp_server":
                    _get = (
                        comp.get
                        if isinstance(comp, dict)
                        else lambda k, d=None: getattr(comp, k, d)
                    )
                    servers.append(
                        {
                            "name": _get("name", "?"),
                            "status": _get("status", "?"),
                            "error": _get("error"),
                            "detail": _get("detail"),
                        }
                    )
        return servers

    def _update_runtime_health(self) -> None:
        """Compute runtime_health from MCP server status for Zone 4."""
        servers = self._collect_mcp_servers()
        errors = [s for s in servers if s.get("status") == "error"]
        if errors:
            names = ", ".join(s.get("name", "?") for s in errors[:2])
            suffix = f" +{len(errors) - 2}" if len(errors) > 2 else ""
            self.runtime_health = f"{names}{suffix}"
        else:
            self.runtime_health = ""

    def action_cycle_effort(self) -> None:
        """Cycle through thinking effort levels for the current model."""
        from dreadnode.app.tui.model_variants import cycle_variant, get_variants

        variants = get_variants(self.model)
        if not variants:
            return  # Silent no-op for unsupported models

        current = self.effort_label if self.thinking_enabled else None
        next_label = cycle_variant(variants, current)

        if next_label is None:
            # Cycling past max → disable
            self.thinking_enabled = False
            self._model_variants.pop(self.model, None)
            self.effort_label = ""
            self._flash("Thinking disabled", severity="info")
        else:
            self.thinking_enabled = True
            self._model_variants[self.model] = next_label
            self.effort_label = next_label
            self._flash(f"Thinking: {next_label}", severity="info")

    def action_open_console(self) -> None:
        self.push_screen(ConsoleScreen(log_buffer))

    def action_open_traces(self) -> None:
        if not self._require_authenticated():
            return
        self._open_platform_screen("traces")

    def action_open_sandboxes(self) -> None:
        if not self._require_authenticated():
            return
        self._open_platform_screen("sandboxes")

    def action_open_evaluations(self) -> None:
        if not self._require_authenticated():
            return
        self._open_platform_screen("evaluations")

    def action_open_runtimes(self) -> None:
        if not self._require_authenticated():
            return
        self._open_platform_screen("runtimes")

    def action_open_hub(self) -> None:
        if not self._require_authenticated():
            return
        self._open_platform_screen("hub")

    def action_open_environments(self) -> None:
        if not self._require_authenticated():
            return
        self._open_platform_screen("environments")

    def action_open_secrets(self) -> None:
        if not self._require_authenticated():
            return
        self._open_platform_screen("secrets")

    def action_cycle_focus(self) -> None:
        """Cycle focus between composer and conversation."""
        composer = self.query_one("#composer", ComposerInput)
        conversation = self.query_one("#conversation", ConversationView)
        if composer.has_focus:
            conversation.focus()
        else:
            composer.focus()

    def action_request_quit(self) -> None:
        """Ctrl+C: interrupt if busy, then double-press to quit."""
        now = time.monotonic()

        # If busy, interrupt first
        if self.busy:
            if self._cancel_active_prompt():
                self._flash("Prompt cancelled", severity="warning")
                self._last_quit_time = now
                return
            self.workers.cancel_group(self, "session")
            self._set_status("Interrupted", busy=False)
            self._set_composer_enabled(True)
            self.query_one("#composer", ComposerInput).focus()
            self._flash("Interrupted — press again to quit", severity="warning")
            self._last_quit_time = now
            return

        # Double-press to quit
        if (now - self._last_quit_time) < 3.0:
            self.exit()
            return

        self._last_quit_time = now
        self._flash("Press Ctrl+C again to quit", severity="warning")

    def action_handle_escape(self) -> None:
        """Escape priority: dismiss overlays → clear composer → interrupt (double-tap) → quit (double-tap)."""
        composer = self.query_one("#composer", ComposerInput)

        # 1. Dismiss overlays if visible
        if self._has_active_overlay():
            self.query_one("#slash-overlay", SlashOverlay).hide()
            self.query_one("#mention-overlay", MentionOverlay).hide()
            self.query_one("#model-picker-overlay", ModelPickerOverlay).hide()
            self.query_one("#agent-dialog", AgentDialog).hide()
            self.query_one("#mcp-dialog", McpDialog).hide()
            self.query_one("#tools-dialog", ToolsDialog).hide()
            return

        # 2. Clear composer if non-empty
        if composer.value:
            composer.clear_pastes()
            composer.value = ""
            return

        # 3. Single escape to interrupt busy agent (hint is visible on spinner)
        if self.busy:
            if self._cancel_active_prompt():
                self._flash("Prompt cancelled", severity="warning")
                self._last_quit_time = time.monotonic()
                return
            self.workers.cancel_group(self, "session")
            self._set_status("Interrupted", busy=False)
            self._set_composer_enabled(True)
            composer.focus()
            self._flash("Interrupted", severity="warning")
            self._last_quit_time = time.monotonic()
            return

        # 4. Not busy — double-escape to quit
        now = time.monotonic()
        if (now - self._last_quit_time) < 3.0:
            self.exit()
            return

        self._last_quit_time = now
        self._flash("Press Escape again to quit", severity="warning")
        composer.focus()

    def _require_authenticated(self) -> bool:
        if not self.authenticated:
            self._flash("Not authenticated", severity="warning")
            return False
        return True

    # ==================================================================
    # Boot & runtime
    # ==================================================================

    def _resolved_server_url(self) -> str:
        """Return resolved server URL: --platform > DREADNODE_SERVER > profile URL > default."""
        if self._platform_override:
            return self._platform_override
        env_override = os.environ.get("DREADNODE_SERVER")
        if env_override:
            return env_override
        try:
            _name, profile = _active_profile()
        except Exception:
            profile = None
        if profile and profile.url:
            return profile.url
        return DEFAULT_PLATFORM_URL

    def _platform_override_url(self) -> str | None:
        """Return an explicit platform URL override, if set."""
        if self._platform_override:
            return self._platform_override
        env_override = os.environ.get("DREADNODE_SERVER")
        if env_override:
            return env_override
        return None

    def _profile_for_server_url(self, server_url: str) -> ServerConfig | None:
        """Return the first saved profile matching a server URL."""
        try:
            user_config = UserConfig.read(Path.home() / ".dreadnode" / "config.yaml")
        except Exception:
            return None
        for profile in user_config.servers.values():
            if profile.url == server_url:
                return profile
        return None

    def _show_auth_modal(
        self,
        server_url: str | None = None,
        force_new_key: bool = False,
        reason: str | None = None,
    ) -> None:
        resolved_url = server_url or self._resolved_server_url()
        self.push_screen(
            AuthModal(resolved_url, force_new_key=force_new_key, reason=reason),
            callback=self._on_auth_complete,
        )

    def _on_auth_complete(self, result: ServerConfig | None) -> None:
        if result is None:
            self.exit()
            return
        self._run_command(self._apply_auth_profile, result)

    async def _apply_auth_profile(self, profile: ServerConfig) -> None:
        self.server_client.set_platform_profile(profile)

        if self.server_client.is_started:
            self._set_status("Restarting server", busy=True)
            await self.server_client.restart()
        else:
            self._set_status("Starting server", busy=True)
            await self.server_client.start()

        await self._refresh_runtime()
        await self._refresh_server_sessions()
        if self.active_session_id is None:
            await self.__create_new_session()
        self.authenticated = True
        self._flash(
            f"Logged in as {profile.username or profile.user_key or 'user'}",
            severity="success",
        )
        self._flash("Connected to Dreadnode runtime", severity="success")
        self._write_activity("Connected to Dreadnode runtime", style="success")
        self._set_status("Ready", busy=False)
        self._set_composer_enabled(True)
        self.query_one("#composer", ComposerInput).focus()

    @work(exit_on_error=False)
    async def _boot(self) -> None:
        self._set_status("Starting runtime", busy=True)
        override_url = self._platform_override_url()
        if override_url:
            profile = self._profile_for_server_url(override_url)
        else:
            try:
                _name, profile = _active_profile()
            except Exception:
                profile = None

        self.authenticated = False

        if override_url and profile is None:
            self._set_status("Authentication required", busy=False)
            self._show_auth_modal(override_url)
            return

        platform_profile: ServerConfig | None = None
        if (
            profile
            and profile.api_key
            and profile.default_organization
            and profile.default_workspace
        ):
            platform_profile = profile

        if platform_profile is None:
            self._set_status("Authentication required", busy=False)
            self._show_auth_modal()
            return

        masked = (
            platform_profile.api_key[:6] + "..." if len(platform_profile.api_key) > 6 else "***"
        )
        logger.info(
            "Boot: validating key %s against %s (org=%s, workspace=%s)",
            masked,
            platform_profile.url,
            platform_profile.default_organization,
            platform_profile.default_workspace,
        )

        api = ApiClient(platform_profile.url, api_key=platform_profile.api_key)
        backoffs = [1.0, 2.0, 4.0]
        response: httpx.Response | None = None
        for attempt in range(len(backoffs) + 1):
            try:
                response = await asyncio.to_thread(api._request, "GET", "/user")
            except httpx.RequestError as exc:
                logger.warning("Boot: connection attempt %d failed: %s", attempt + 1, exc)
                if attempt < len(backoffs):
                    await asyncio.sleep(backoffs[attempt])
                    continue
                self._set_status("Connection failed", busy=False)
                logger.warning(
                    "Boot: cannot reach %s after %d attempts", platform_profile.url, attempt + 1
                )
                self._show_auth_modal(reason=f"Cannot connect to {platform_profile.url}")
                return

            if response.status_code == 401:
                self._set_status("Authentication required", busy=False)
                logger.warning("Boot: API key rejected (401) by %s", platform_profile.url)
                self._show_auth_modal(reason="Your session has expired — please sign in again")
                return

            if response.is_success:
                break

            # Server error (5xx) — retry with backoff
            if response.status_code >= 500 and attempt < len(backoffs):
                await asyncio.sleep(backoffs[attempt])
                continue

            self._set_status("Connection failed", busy=False)
            logger.warning(
                "Boot: server error (%d) from %s", response.status_code, platform_profile.url
            )
            self._show_auth_modal(reason="Server error — please try again")
            return

        org = platform_profile.default_organization
        workspace = platform_profile.default_workspace
        if not org or not workspace:
            self._set_status("Authentication required", busy=False)
            self._show_auth_modal(reason="Incomplete profile — please sign in again")
            return

        try:
            await asyncio.to_thread(api.get_organization, org)
            workspaces = await asyncio.to_thread(api.list_workspaces, org)
        except Exception as exc:
            self._set_status("Authentication required", busy=False)
            logger.warning("Boot: failed to validate org/workspace: %s", exc)
            self._show_auth_modal(reason="Could not verify your account — please sign in again")
            return

        if not any(getattr(ws, "key", None) == workspace for ws in workspaces):
            self._set_status("Authentication required", busy=False)
            logger.warning("Boot: workspace %r not found in org %r", workspace, org)
            self._show_auth_modal(reason="Workspace not found — please sign in again")
            return

        try:
            self.server_client.set_platform_profile(platform_profile)
            await self.server_client.start()
            await self._refresh_runtime()
            await self._refresh_server_sessions()
            if self.active_session_id is None:
                await self.__create_new_session()
            self.authenticated = True
            self._flash("Connected to Dreadnode runtime", severity="success")
            self._write_activity("Connected to Dreadnode runtime", style="success")
            self._set_status("Ready", busy=False)
            self._set_composer_enabled(True)
            self.query_one("#composer", ComposerInput).focus()
        except Exception as exc:
            self.authenticated = False
            self._write_activity(str(exc), style="error")
            self._flash(str(exc), severity="error")
            self._set_status("Connection failed", busy=False)
            self._set_composer_enabled(False)

    def _collect_agents(self) -> list[dict[str, str]]:
        """Build agent list from loaded capabilities, always including 'default'."""
        agents: list[dict[str, str]] = [
            {
                "name": "default",
                "description": "Default agent",
                "model": "inherit",
                "capability": "built-in",
            },
        ]
        seen = {"default"}
        if self.runtime_info:
            for cap in self.runtime_info.capabilities:
                for agent in cap.agents:
                    if agent.name not in seen:
                        agents.append(
                            {
                                "name": agent.name,
                                "description": agent.description or "",
                                "model": agent.model or "inherit",
                                "capability": cap.name,
                            }
                        )
                        seen.add(agent.name)
        return agents

    async def _refresh_runtime(self) -> None:
        self.runtime_info = await self.server_client.fetch_runtime_info()
        self._update_runtime_health()
        self.query_one("#mention-overlay", MentionOverlay).set_agents(self._collect_agents())
        self.working_dir = self.runtime_info.working_dir or ""
        self._sync_sessions()
        self._update_context()

    async def _refresh_server_sessions(self) -> None:
        session_infos = await self.server_client.list_sessions()
        refreshed: dict[str, SessionRecord] = {}
        for si in session_infos:
            record = self.sessions.get(si.session_id)
            if record is None:
                refreshed[si.session_id] = SessionRecord(info=si)
            else:
                refreshed[si.session_id] = SessionRecord(
                    info=si,
                    transcript=record.transcript,
                    title=record.title,
                )
        self.sessions = refreshed
        self._turn_state = {
            sid: self._turn_state.get(sid, TurnState.empty(sid)) for sid in refreshed
        }
        if self.active_session_id not in self.sessions:
            self.active_session_id = next(iter(self.sessions), None)
        self._sync_sessions()
        self._sync_conversation()
        self._update_context()

    # ==================================================================
    # Session management (all async methods use @work)
    # ==================================================================

    @work(exclusive=True, group="session")
    async def _create_new_session(self, agent: str | None = None) -> None:
        await self.__create_new_session(agent)

    async def __create_new_session(self, agent: str | None = None) -> None:
        """Inner implementation -- callable from both @work and plain await."""
        self._set_status("Creating session", busy=True)
        session_info = await self.server_client.create_session(
            agent=agent, model=self.model, generate_params_extra=self.generate_params_extra or None
        )
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")
        title = f"Session {timestamp}"
        self.sessions[session_info.session_id] = SessionRecord(
            info=session_info,
            title=title,
        )
        self.active_session_id = session_info.session_id
        self._turn_state[session_info.session_id] = TurnState.empty(session_info.session_id)
        self._inline_activity_sessions.discard(session_info.session_id)
        self._turn_counts[session_info.session_id] = 0

        self.total_tokens = 0
        self._sync_conversation()
        self.query_one("#draft", StreamingDraft).clear_stream()
        self._draft_active = False
        self._sync_sessions()
        self._update_context()
        self._set_status("Ready", busy=False)
        self._write_activity(
            f"Started session {title} {'for agent ' + agent if agent else 'with default runtime'}",
            style="info",
        )

    @work(exclusive=True, group="session")
    async def _reset_active_session(self) -> None:
        session = self._active_session()
        if session is None:
            self._flash("No active session to reset", severity="warning")
            return
        await self.server_client.reset_session(session.info.session_id)
        session.transcript.clear()
        session.info.message_count = 0
        self._turn_state[session.info.session_id] = TurnState.empty(session.info.session_id)
        self._inline_activity_sessions.discard(session.info.session_id)
        self._turn_counts.pop(session.info.session_id, None)
        self._pending_messages.pop(session.info.session_id, None)

        self._sync_conversation()
        self.query_one("#draft", StreamingDraft).clear_stream()
        self._draft_active = False
        self._sync_sessions()
        self._sync_queue()
        display = session.title or session.info.session_id[:8]
        self._flash(f"Reset session {display}", severity="info")
        self._write_activity(f"Reset session {display}", style="info")

    @work(exclusive=True, group="session")
    async def _switch_session(self, session_id: str) -> None:
        if self.active_session_id is not None:
            self._inline_activity_sessions.discard(self.active_session_id)
        self.active_session_id = session_id
        self._turn_state.setdefault(session_id, TurnState.empty(session_id))

        self.total_tokens = 0
        self._sync_conversation()
        self.query_one("#draft", StreamingDraft).clear_stream()
        self._draft_active = False
        self._sync_sessions()
        self._sync_queue()
        self._update_context()
        display = self.sessions[session_id].title if session_id in self.sessions else session_id[:8]
        self._write_activity(f"Switched to session {display}", style="info")

    @work(exclusive=True, group="session")
    async def _switch_session_by_prefix(self, prefix: str) -> None:
        await self._refresh_server_sessions()
        matches = [sid for sid in self.sessions if sid.startswith(prefix)]
        if len(matches) != 1:
            self._flash(
                f"Expected 1 session matching {prefix}, found {len(matches)}", severity="warning"
            )
            return
        if self.active_session_id is not None:
            self._inline_activity_sessions.discard(self.active_session_id)
        self.active_session_id = matches[0]
        self._turn_state.setdefault(self.active_session_id, TurnState.empty(self.active_session_id))

        self.total_tokens = 0
        self._sync_conversation()
        self.query_one("#draft", StreamingDraft).clear_stream()
        self._draft_active = False
        self._sync_sessions()
        self._sync_queue()
        self._update_context()

    @work(exclusive=True, group="session")
    async def _delete_session_by_prefix(self, prefix: str) -> None:
        await self._refresh_server_sessions()
        matches = [sid for sid in self.sessions if sid.startswith(prefix)]
        if len(matches) != 1:
            self._flash(
                f"Expected 1 session matching {prefix}, found {len(matches)}", severity="warning"
            )
            return
        session_id = matches[0]
        await self.server_client.delete_session(session_id)
        self.sessions.pop(session_id, None)
        self._pending_messages.pop(session_id, None)
        if self.active_session_id == session_id:
            self.active_session_id = next(iter(self.sessions), None) if self.sessions else None
            if self.active_session_id is None:
                await self.__create_new_session()
                return
        self._sync_conversation()
        self._sync_sessions()
        self._sync_queue()
        self._update_context()
        self._flash(f"Deleted session {session_id[:8]}", severity="success")
        self._write_activity(f"Deleted session {session_id[:8]}", style="success")

    @work(exclusive=True, group="session")
    async def _start_agent_session(self, agent_name: str) -> None:
        if self.runtime_info is None:
            self._flash("Runtime metadata is not loaded", severity="warning")
            return
        available = {"default"} | {a.name for c in self.runtime_info.capabilities for a in c.agents}
        if agent_name not in available:
            self._flash(f"Unknown agent: {agent_name}", severity="warning")
            return
        if self._active_session() is None:
            await self.__create_new_session(agent=agent_name)
            return
        self._set_active_session_agent(agent_name)

    # ==================================================================
    # Chat
    # ==================================================================

    @work(exit_on_error=False, exclusive=True, group="session")
    async def _send_chat(self, message: str, _user_entry_shown: bool = False) -> None:
        session = self._active_session()
        if session is None:
            await self.__create_new_session()
            session = self._active_session()
            if session is None:
                self._flash("Failed to create a session", severity="error")
                return

        tp = self.query_one(ConversationView).query_one(ToolProgress)
        if not _user_entry_shown:
            self._set_status("Thinking", busy=True)
            tp.show_activity("thinking")

            sid = session.info.session_id
            self._turn_counts.setdefault(sid, 0)
            self._turn_counts[sid] += 1
            self._append_transcript(
                TranscriptEntry(
                    kind="user", title="user", body=message, turn=self._turn_counts[sid]
                ),
                sid,
            )

        try:
            async for event in self.server_client.stream_chat(
                session_id=session.info.session_id,
                message=message,
                agent=session.info.agent,
                generate_params_extra=self.generate_params_extra or None,
            ):
                self._handle_event(event, session.info.session_id)
        except AuthenticationError:
            self._handle_authentication_error("Session expired — please sign in again")
        except Exception as exc:
            self._append_transcript(
                TranscriptEntry(kind="error", title="error", body=str(exc)), session.info.session_id
            )
            self._write_activity(str(exc), style="error")
        finally:
            self._commit_draft_to_transcript(session.info.session_id)
            tp.hide_tool()

            if session.info.session_id in self.sessions:
                self.sessions[session.info.session_id].info.message_count = len(
                    self.sessions[session.info.session_id].transcript
                )
                self._sync_sessions()

            self._drain_queue(session.info.session_id)

    @work(exit_on_error=False, exclusive=True, group="session")
    async def _execute_shell(self, command: str) -> None:
        session = self._active_session()
        sid = session.info.session_id if session else "shell"
        self._append_transcript(
            TranscriptEntry(kind="user", title="shell", body=f"$ {command}"), sid
        )
        self._set_status("Running", busy=True)
        tp = self.query_one(ConversationView).query_one(ToolProgress)
        tp.show_activity("running")
        try:
            result = await self.server_client.execute_shell(command)
            stdout = result.get("stdout", "").strip()
            stderr = result.get("stderr", "").strip()
            exit_code = result.get("exitCode", 0)
            output = stdout
            if stderr:
                output = f"{output}\n{stderr}" if output else stderr
            if exit_code != 0:
                output = f"{output}\n[exit {exit_code}]"
            self._append_transcript(
                TranscriptEntry(
                    kind="tool" if exit_code == 0 else "error",
                    title="shell",
                    body=output or "(no output)",
                    meta=f"exit {exit_code}",
                ),
                sid,
            )
        except Exception as exc:
            self._append_transcript(
                TranscriptEntry(kind="error", title="shell", body=str(exc)), sid
            )
        finally:
            tp.hide_tool()
            self._set_status("Ready", busy=False)

    @work(exit_on_error=False, exclusive=True, group="session")
    async def _send_chat_to_agent(self, message: str, agent_name: str) -> None:
        session = self._active_session()
        if session is None:
            await self.__create_new_session()
            session = self._active_session()
        if session is None:
            return
        # Inline the chat logic to avoid nesting @work calls
        self._set_status("Thinking", busy=True)
        tp = self.query_one(ConversationView).query_one(ToolProgress)
        tp.show_activity("thinking")

        try:
            sid = session.info.session_id
            self._turn_counts.setdefault(sid, 0)
            self._turn_counts[sid] += 1
            self._append_transcript(
                TranscriptEntry(
                    kind="user", title="user", body=message, turn=self._turn_counts[sid]
                ),
                sid,
            )

            async for event in self.server_client.stream_chat(
                session_id=session.info.session_id,
                message=message,
                agent=agent_name,
                generate_params_extra=self.generate_params_extra or None,
            ):
                self._handle_event(event, session.info.session_id)
        except AuthenticationError:
            self._handle_authentication_error("Session expired — please sign in again")
        except Exception as exc:
            self._append_transcript(
                TranscriptEntry(kind="error", title="error", body=str(exc)), session.info.session_id
            )
            self._write_activity(str(exc), style="error")
        finally:
            self._commit_draft_to_transcript(session.info.session_id)
            tp.hide_tool()

            if session.info.session_id in self.sessions:
                self.sessions[session.info.session_id].info.message_count = len(
                    self.sessions[session.info.session_id].transcript
                )
                self._sync_sessions()

            self._drain_queue(session.info.session_id)

    # ==================================================================
    # Permission handling
    # ==================================================================

    @work(exit_on_error=False)
    async def _send_permission_response(
        self, request_id: str, decision: str, tool_name: str = ""
    ) -> None:
        """Send a permission decision back to the server."""
        session = self._active_session()
        if session is None:
            return

        # Track allow_session decisions by tool name
        if decision == "allow_session" and tool_name:
            sid = session.info.session_id
            if sid not in self._session_allowlist:
                self._session_allowlist[sid] = set()
            self._session_allowlist[sid].add(tool_name)

        try:
            await self.server_client.send_permission_response(
                session.info.session_id,
                request_id,
                decision,
            )
            self._set_status("Resuming", busy=True)
        except AuthenticationError:
            self._handle_authentication_error("Session expired — please sign in again")
        except Exception as exc:
            self._write_activity(f"Permission response error: {exc}", style="error")
            self._set_composer_enabled(self.authenticated)
            if self.authenticated:
                self.query_one("#composer", ComposerInput).focus()
            self._set_status("Ready", busy=False)

    @work(exit_on_error=False)
    async def _send_human_input_response(
        self,
        request_id: str,
        action: str,
        *,
        text: str | None = None,
        selected_option: str | None = None,
        tool_name: str | None = None,
    ) -> None:
        """Send a human input response back to the server."""
        session = self._active_session()
        if session is None:
            return

        if action == "allow_session" and tool_name:
            sid = session.info.session_id
            if sid not in self._session_allowlist:
                self._session_allowlist[sid] = set()
            self._session_allowlist[sid].add(tool_name)

        response = HumanInputResponse(
            request_id=request_id,
            action=action,
            text=text,
            selected_option=selected_option,
        )

        try:
            await self.server_client.send_human_input_response(session.info.session_id, response)
            if action in {"submit", "approve", "allow_session"}:
                self._set_status("Resuming", busy=True)
            else:
                self._set_status("Ready", busy=False)
            self._apply_human_prompt_response(session.info.session_id, action)
        except AuthenticationError:
            self._handle_authentication_error("Session expired — please sign in again")
        except Exception as exc:
            self._write_activity(f"Human response error: {exc}", style="error")
            self._set_composer_enabled(self.authenticated)
            if self.authenticated:
                self.query_one("#composer", ComposerInput).focus()
            self._set_status("Ready", busy=False)

    # ==================================================================
    # Event handling
    # ==================================================================

    def _handle_event(self, event: dict[str, t.Any], session_id: str) -> None:
        normalized = normalize_event(event, session_id)
        prev_state = self._turn_state.get(session_id, TurnState.empty(session_id))
        next_state = reduce_event(prev_state, normalized)
        self._turn_state[session_id] = next_state

        event_type = normalized.type
        payload = self._event_payload(normalized)

        if normalized.usage_total_tokens is not None:
            self.total_tokens = max(self.total_tokens, normalized.usage_total_tokens)

        if event_type == "generation_step":
            # Render reasoning/thinking content (expanded, muted, left-border)
            if normalized.reasoning_content and self._show_thinking:
                self._append_transcript(
                    TranscriptEntry(
                        kind="thinking",
                        title="Thinking",
                        body=normalized.reasoning_content,
                    ),
                    session_id,
                )

            text = normalized.assistant_delta or ""
            if text:
                draft = self.query_one("#draft", StreamingDraft)
                if not self._draft_active:
                    draft.start_stream()
                    self._draft_active = True
                draft.append_token(text)
                self.query_one(ConversationView).query_one(ToolProgress).show_activity("streaming")
            return

        if event_type == "generation_end":
            return

        if event_type == "tool_start":
            self._commit_draft_to_transcript(session_id)
            tool_name = normalized.tool_name or "tool"
            self.query_one(ConversationView).query_one(ToolProgress).show_tool(tool_name)
            return

        if event_type == "tool_end":
            run = self._tool_run_for_event(next_state, normalized)
            tool_name = run.tool_name if run is not None else (normalized.tool_name or "tool")
            label = (
                run.label
                if run is not None
                else _format_tool_label(tool_name, normalized.tool_args or {})
            )
            summary = _summarize_tool_result(
                tool_name, normalized.tool_args or {}, payload.get("result")
            )
            details = (
                self._tool_result_details(payload.get("result"))
                if self._tool_details_mode == "expanded"
                else ""
            )
            self._append_transcript(
                TranscriptEntry(kind="tool", title=label, body=details, meta=summary),
                session_id,
            )
            self.query_one(ConversationView).query_one(ToolProgress).show_activity("thinking")
            return

        if event_type == "tool_step":
            return

        if event_type == "tool_error":
            run = self._tool_run_for_event(next_state, normalized)
            label = (
                run.label
                if run is not None
                else _format_tool_label(
                    normalized.tool_name or "tool",
                    normalized.tool_args or {},
                )
            )
            error = normalized.error_text or "Tool error"
            self._append_transcript(
                TranscriptEntry(kind="error", title=label, body=error),
                session_id,
            )
            return

        if event_type == "generation_error":
            self._append_transcript(
                TranscriptEntry(
                    kind="error",
                    title="generation",
                    body=normalized.error_text or "Generation error",
                ),
                session_id,
            )
            return

        if event_type == "agent_stalled":
            self._append_transcript(
                TranscriptEntry(
                    kind="error", title="agent", body=normalized.error_text or "Agent stalled"
                ),
                session_id,
            )
            return

        if event_type == "agent_error":
            if normalized.error_text:
                self._append_transcript(
                    TranscriptEntry(kind="error", title="agent", body=normalized.error_text),
                    session_id,
                )
            return

        if event_type == "agent_end":
            stop_reason = str(payload.get("stop_reason", "")).lower()
            if normalized.error_text:
                self._append_transcript(
                    TranscriptEntry(kind="error", title="agent", body=normalized.error_text),
                    session_id,
                )
            elif normalized.status == "errored" or stop_reason == "error":
                self._append_transcript(
                    TranscriptEntry(kind="error", title="agent", body="run ended with an error"),
                    session_id,
                )
            return

        if event_type == "human_prompt":
            prompt = normalized.human_prompt
            if prompt is None:
                return

            sid = self.active_session_id or ""
            if prompt.kind == "approval" and prompt.source_tool_name:
                if (
                    sid in self._session_allowlist
                    and prompt.source_tool_name in self._session_allowlist[sid]
                ):
                    self._send_human_input_response(
                        prompt.request_id,
                        "approve",
                        tool_name=prompt.source_tool_name,
                    )
                    return

            self._set_composer_enabled(self.authenticated)
            status = "Awaiting approval" if prompt.kind == "approval" else "Awaiting input"
            self._set_status(status, busy=True)
            widget = self.query_one("#human-prompt", PermissionPrompt)
            self.call_after_refresh(widget.show_prompt, prompt)
            if prompt.kind != "approval":
                composer = self.query_one("#composer", ComposerInput)
                composer.placeholder = "Type your response and press Enter..."
                self.call_after_refresh(composer.focus)
            else:
                self.query_one("#composer", ComposerInput).placeholder = ""
            if prompt.question:
                prompt_body = prompt.question
                if prompt.options:
                    options_text = "\n".join(
                        f"{idx}. {option.label}"
                        for idx, option in enumerate(prompt.options, start=1)
                    )
                    prompt_body = f"{prompt_body}\n{options_text}"
                self._append_transcript(
                    TranscriptEntry(kind="tool", title="ask_user", body=prompt_body),
                    session_id,
                )
            return

        if event_type == "runtime_error":
            status = payload.get("status") if isinstance(payload, dict) else None
            if status is None and isinstance(payload, dict):
                status = payload.get("status_code")
            try:
                status_code = int(status) if status is not None else None
            except (TypeError, ValueError):
                status_code = None
            if status_code == 401:
                logger.warning("Runtime returned 401 during chat — triggering re-auth")
                raise AuthenticationError("401: Unauthorized")
            self._write_activity(
                normalized.error_text or str(payload.get("error", "Runtime error")),
                style="error",
            )
            if normalized.error_text:
                self._append_transcript(
                    TranscriptEntry(kind="error", title="runtime", body=normalized.error_text),
                    session_id,
                )
            return

    def _event_payload(self, event: NormalizedEvent) -> dict[str, t.Any]:
        raw = event.raw if isinstance(event.raw, dict) else {}
        payload = raw.get("data") if isinstance(raw.get("data"), dict) else raw
        if isinstance(payload, dict):
            return payload
        return {}

    def _tool_run_for_event(self, state: TurnState, event: NormalizedEvent) -> ToolRun | None:
        if event.tool_call_id:
            run = state.tool_runs.get(event.tool_call_id)
            if run is not None:
                return run
        if event.tool_name:
            for key in reversed(state.tool_order):
                run = state.tool_runs.get(key)
                if run is None:
                    continue
                if run.tool_name == event.tool_name:
                    return run
        return None

    def _tool_result_details(self, result: t.Any, max_len: int = 1600) -> str:
        """Render detailed tool result text for expanded transcript mode."""
        if result is None:
            return ""

        if isinstance(result, str):
            text = result.strip()
        elif isinstance(result, (dict, list)):
            try:
                text = json.dumps(result, indent=2, sort_keys=True)
            except TypeError:
                text = str(result)
        else:
            text = str(result)

        if not text:
            return ""
        if len(text) > max_len:
            return f"{text[:max_len]}..."
        return text

    def _active_human_prompt(self, session_id: str | None = None) -> HumanPrompt | None:
        """Return the active human prompt for a session, if any."""
        sid = session_id or self.active_session_id
        if not sid:
            return None
        state = self._turn_state.get(sid)
        if state is None:
            return None
        return state.pending_human_prompt

    def _apply_human_prompt_response(self, session_id: str, action: str) -> None:
        """Apply a local human prompt response to turn state."""
        state = self._turn_state.get(session_id)
        if state is None:
            return
        self._turn_state[session_id] = reduce_human_prompt_response(state, action=action)

    def _cancel_active_prompt(self) -> bool:
        """Cancel the active human prompt if one is present."""
        prompt = self._active_human_prompt()
        if prompt is None:
            return False
        self.query_one("#human-prompt", PermissionPrompt).hide_prompt()
        self.query_one("#composer", ComposerInput).placeholder = ""
        self._send_human_input_response(
            prompt.request_id,
            "cancel",
            tool_name=prompt.source_tool_name,
        )
        return True

    # ==================================================================
    # Message queue
    # ==================================================================

    def _enqueue_message(self, message: str) -> None:
        """Add a message to the queue for the active session."""
        sid = self.active_session_id
        if not sid:
            return
        self._pending_messages.setdefault(sid, []).append(message)
        self._sync_queue()

    def _has_queued_messages(self) -> bool:
        """Check if the active session has queued messages."""
        sid = self.active_session_id
        if not sid:
            return False
        return bool(self._pending_messages.get(sid))

    def _retract_last_queued(self) -> str | None:
        """Pop the last queued message and return it (for editing)."""
        sid = self.active_session_id
        if not sid:
            return None
        queue = self._pending_messages.get(sid, [])
        if not queue:
            return None
        message = queue.pop()
        self._sync_queue()
        return message

    def _sync_queue(self) -> None:
        """Update the queue widget to reflect current state."""
        sid = self.active_session_id
        queue = self._pending_messages.get(sid, []) if sid else []
        self.query_one("#message-queue", MessageQueue).set_messages(queue)

    def _drain_queue(self, session_id: str) -> None:
        """After a turn ends, auto-send the next queued message or go idle."""
        # If busy was already cleared by an interrupt handler, don't auto-send
        if not self.busy:
            return

        queue = self._pending_messages.get(session_id, [])
        if queue and self.active_session_id == session_id:
            message = queue.pop(0)
            self._sync_queue()
            # Route @agent messages to the correct agent
            if at_match := re.match(r"^@(\S+)\s+([\s\S]+)$", message):
                self._send_chat_to_agent(at_match.group(2), at_match.group(1))
            else:
                self._send_chat(message)
        else:
            self._set_status("Ready", busy=False)
            if self.authenticated:
                self.query_one("#composer", ComposerInput).focus()

    # ==================================================================
    # Command dispatch
    # ==================================================================

    def _handle_command(self, raw: str) -> None:
        parts = raw[1:].split()
        cmd = parts[0].lower() if parts else ""
        args = parts[1:]

        if not self.authenticated and cmd not in {"quit", "exit", "q", "console", "thinking"}:
            self._flash("Not authenticated", severity="warning")
            return

        dispatch: dict[str, t.Callable[[], None]] = {
            "quit": self.exit,
            "exit": self.exit,
            "q": self.exit,
            "help": self._show_help,
            "new": lambda: self._create_new_session(),
            "reset": lambda: self._reset_active_session(),
            "sessions": lambda: self._run_command(self._list_sessions_command),
            "agents": self._write_agent_listing,
            "reload": lambda: self._run_command(self._reload_capabilities_command),
            "runtime": lambda: self._run_command(self._refresh_runtime_command),
            "login": lambda: self._run_command(self._login_command, args),
            "logout": lambda: self._run_command(self._logout_command),
            "workspace": lambda: self._run_command(self._workspace_info_command)
            if not args
            else self._run_command(self._switch_workspace_command, args),
            "workspaces": lambda: self._run_command(self._workspaces_command),
            "models": self._open_model_picker,
            "runtimes": lambda: self._open_platform_screen("runtimes"),
            "rt": lambda: self._open_platform_screen("runtimes"),
            "hub": lambda: self._open_platform_screen("hub"),
            "environments": lambda: self._open_platform_screen("environments"),
            "env": lambda: self._open_platform_screen("environments"),
            "secrets": lambda: self._open_platform_screen("secrets"),
            "sec": lambda: self._open_platform_screen("secrets"),
            "console": self.action_open_console,
            "traces": lambda: self._open_platform_screen("traces"),
            "sandboxes": lambda: self._open_platform_screen("sandboxes"),
            "evaluations": lambda: self._open_platform_screen("evaluations"),
            "capabilities": lambda: self._open_capabilities_screen(),
            "caps": lambda: self._open_capabilities_screen(),
            "mcp": self._open_mcp_dialog,
            "copy": self._copy_last_assistant,
            "tools": lambda: self._tools_mode_command(args),
        }

        if cmd in dispatch:
            dispatch[cmd]()
            return

        # Commands with required args
        if cmd == "use":
            if not args:
                self._flash("Usage: /use <id>", severity="warning")
            else:
                self._switch_session_by_prefix(args[0])
            return

        if cmd == "delete":
            if not args:
                self._flash("Usage: /delete <id>", severity="warning")
            else:
                self._delete_session_by_prefix(args[0])
            return

        if cmd == "agent":
            if not args:
                self._flash("Usage: /agent <name>", severity="warning")
            else:
                self._start_agent_session(args[0])
            return

        if cmd == "model":
            if not args:
                self._flash(f"Current model: {self.model}", severity="info")
            else:
                self._on_model_changed(args[0])
                self._flash(f"Model set to {args[0]}", severity="info")
            return

        if cmd in {"whoami", "getuid"}:
            self._run_command(self._whoami_command)
            return

        if cmd == "projects":
            self._run_command(self._projects_command, args)
            return

        if cmd == "rename":
            if not args:
                self._flash("Usage: /rename <title>", severity="warning")
            else:
                new_title = " ".join(args)
                self._rename_session(new_title)
            return

        if cmd == "export":
            filename = args[0] if args else None
            self._export_session(filename)
            return

        if cmd == "thinking":
            self._handle_thinking_command(args)
            return

        self._flash(f"Unknown command: /{cmd}", severity="warning")

    @work(group="command", exclusive=True)
    async def _run_command(self, coro_fn: t.Callable[..., t.Awaitable[None]], *args: t.Any) -> None:
        """Generic worker for async command implementations."""
        try:
            await coro_fn(*args)
        except AuthenticationError:
            self._handle_authentication_error("Session expired — please sign in again")
        except Exception as exc:
            logger.exception("Command %s failed", getattr(coro_fn, "__name__", coro_fn))
            self._flash(str(exc), severity="warning")

    def _handle_thinking_command(self, args: list[str]) -> None:
        """Handle /thinking command for effort level control."""
        from dreadnode.app.tui.model_variants import get_variants

        if not args:
            if self.thinking_enabled and self.effort_label:
                self._flash(f"Thinking: enabled ({self.effort_label})", severity="info")
            else:
                self._flash("Thinking: disabled", severity="info")
            return

        arg = args[0].lower()

        if arg == "show":
            self._show_thinking = True
            self._flash("Thinking blocks visible", severity="info")
            return

        if arg == "hide":
            self._show_thinking = False
            self._flash("Thinking blocks hidden", severity="info")
            return

        if arg == "off":
            self.thinking_enabled = False
            self._model_variants.pop(self.model, None)
            self.effort_label = ""
            self._flash("Thinking disabled", severity="info")
            return

        variants = get_variants(self.model)

        if arg == "on":
            if not variants:
                self._flash(f"Model {self.model} does not support thinking", severity="warning")
                return
            self.thinking_enabled = True
            label = list(variants.keys())[0]
            self._model_variants[self.model] = label
            self.effort_label = label
            self._flash(f"Thinking enabled ({label})", severity="info")
            return

        # Named effort level
        if arg in variants:
            self.thinking_enabled = True
            self._model_variants[self.model] = arg
            self.effort_label = arg
            self._flash(f"Thinking: {arg}", severity="info")
            return

        available = ", ".join(variants.keys()) if variants else "none for this model"
        self._flash(f"Unknown effort level '{arg}'. Available: {available}", severity="warning")

    # ==================================================================
    # Command implementations
    # ==================================================================

    async def _list_sessions_command(self) -> None:
        await self._refresh_server_sessions()
        self._write_session_listing()

    async def _reload_capabilities_command(self) -> None:
        self.runtime_info = await self.server_client.reload_capabilities()
        self._update_runtime_health()
        self.query_one("#mention-overlay", MentionOverlay).set_agents(self._collect_agents())
        self.working_dir = self.runtime_info.working_dir or ""
        self._sync_sessions()
        self._update_context()
        cap_count = len(self.runtime_info.capabilities)
        agent_count = sum(len(c.agents) for c in self.runtime_info.capabilities)
        self._flash(
            f"Reloaded {cap_count} capabilities, {agent_count} agents",
            severity="success",
        )

    async def _refresh_runtime_command(self) -> None:
        await self._refresh_runtime()
        self._flash("Runtime metadata refreshed", severity="success")

    async def _login_command(self, args: list[str] | None = None) -> None:
        self._set_status("Logging in", busy=True)
        try:
            server_url, api_key = _parse_login_args(
                args or [],
                default_platform_url=self._resolved_server_url(),
            )
        except ValueError as exc:
            self._flash(str(exc), severity="warning")
            self._set_status("Ready", busy=False)
            return
        if api_key is None:
            self._set_status("Authentication required", busy=False)
            self._show_auth_modal(server_url)
            return

        try:
            profile = await asyncio.to_thread(_login_with_api_key, server_url, api_key)
        except Exception as exc:
            self._set_status("Authentication required", busy=False)
            logger.warning("Login failed: %s", exc)
            self._show_auth_modal(server_url, reason="Login failed — please try again")
            return
        self._write_activity(f"Logged in on {profile.url}", style="success")
        self._write_activity(
            "Restarting runtime to apply platform authentication. Active runs will stop; local chat history is preserved.",
            style="warning",
        )
        self._flash(
            "Restarting runtime to apply platform authentication",
            severity="warning",
        )
        await self._apply_auth_profile(profile)

    async def _logout_command(self) -> None:
        logout_server_url = self._resolved_server_url()
        try:
            _name, profile = _active_profile()
        except Exception:
            profile = None
            logger.warning("Failed to read active profile for API key revocation", exc_info=True)
        if profile and profile.api_key and profile.url:
            try:
                api = ApiClient(profile.url, api_key=profile.api_key)
                await asyncio.to_thread(api.revoke_self_api_key)
            except Exception:
                logger.warning("Failed to revoke API key during logout", exc_info=True)
        removed: str | None = None
        try:
            removed = _delete_active_profile()
        except Exception as exc:
            self._flash(f"Failed to delete saved credentials: {exc}", severity="warning")
        self._write_activity(
            "Deleting saved credentials. Restarting runtime without platform sync. "
            "Active runs will stop; local chat history is preserved.",
            style="warning",
        )
        if removed:
            self._flash(
                f"Logged out from {removed}; saved credentials deleted; restarting runtime without platform sync",
                severity="warning",
            )
        else:
            self._flash(
                "No saved profile found; restarting runtime without platform sync",
                severity="warning",
            )
        self.server_client.clear_platform_profile()
        self.authenticated = False

        if self.server_client.is_started:
            self._set_status("Restarting server", busy=True)
            await self.server_client.restart()
            await self._refresh_runtime()
            await self._refresh_server_sessions()
            if self.active_session_id is None:
                await self.__create_new_session()
        self._set_status("Ready", busy=False)
        self._show_auth_modal(logout_server_url, force_new_key=True)

    async def _whoami_command(self) -> None:
        if not self.authenticated:
            self._flash("Not logged in", severity="warning")
            return
        name, profile = _active_profile()
        if name is None or profile is None:
            self._flash("Not logged in. Use /login first.", severity="warning")
            return
        self._write_activity(f"profile {name} \u00b7 {profile.url}", style="success")
        for label, value in [
            ("user", profile.username),
            ("email", profile.email),
            ("org", profile.default_organization),
            ("workspace", profile.default_workspace),
            ("project", profile.default_project),
        ]:
            if value:
                self._write_activity(f"{label} {value}", style="info")

    async def _workspace_info_command(self) -> None:
        try:
            _name, profile = _active_profile()
        except Exception as exc:
            self._flash(str(exc), severity="warning")
            return
        if profile is None:
            self._flash("Not logged in. Use /login first.", severity="warning")
            return
        for label, value in [
            ("org", profile.default_organization),
            ("workspace", profile.default_workspace),
            ("project", profile.default_project),
        ]:
            if value:
                self._write_activity(f"{label} {value}", style="info")

    async def _switch_workspace_command(self, args: list[str]) -> None:
        if not self.authenticated:
            self._flash("Not authenticated", severity="warning")
            return
        if not args:
            self._flash("Usage: /workspace <key>", severity="warning")
            return
        workspace_key = args[0]

        try:
            profile_name, profile = _active_profile()
        except Exception as exc:
            self._flash(str(exc), severity="warning")
            return
        if profile_name is None or profile is None:
            self._flash("Not logged in. Use /login first.", severity="warning")
            return

        org = profile.default_organization
        if not org:
            self._flash("No organization configured. Use /login first.", severity="warning")
            return

        try:
            api, _profile = await asyncio.to_thread(_platform_client)
            workspace = await asyncio.to_thread(api.get_workspace, org, workspace_key)
        except Exception as exc:
            self._flash(str(exc), severity="warning")
            return

        if workspace is None:
            self._flash(f"Workspace not found: {workspace_key}", severity="error")
            return

        if profile.default_workspace == workspace_key:
            self._flash(f"Already on workspace: {workspace_key}", severity="info")
            return

        default_project = await asyncio.to_thread(
            _default_project_for_workspace,
            api,
            org,
            workspace_key,
        )
        updated_profile = profile.model_copy(
            update={
                "default_workspace": workspace_key,
                "default_project": default_project,
            }
        )

        try:
            await asyncio.to_thread(_save_profile, profile_name, updated_profile)
        except Exception as exc:
            self._flash(f"Failed to save profile: {exc}", severity="error")
            return

        await self._apply_auth_profile(updated_profile)
        self._flash(
            f"Switched to workspace: {workspace.name} — sessions cleared",
            severity="success",
        )

    async def _workspaces_command(self) -> None:
        api, profile = await asyncio.to_thread(_platform_client)
        workspaces = await asyncio.to_thread(api.list_workspaces, profile.default_organization)
        if not workspaces:
            self._flash("No workspaces found", severity="warning")
            return
        for ws in workspaces:
            is_active = ws.key == profile.default_workspace
            marker = " \u2190 active" if is_active else ""
            default_marker = " (default)" if ws.is_default else ""
            self._write_activity(
                f"{ws.key} \u00b7 {ws.name}{marker}{default_marker}",
                style="success" if is_active else "info",
            )

    async def _projects_command(self, args: list[str] | None = None) -> None:
        api, profile = await asyncio.to_thread(_platform_client)
        org = profile.default_organization
        workspace = args[0] if args else profile.default_workspace
        if not org or not workspace:
            self._flash("No org/workspace. Use /login first.", severity="warning")
            return
        projects = await asyncio.to_thread(api.list_projects, org, workspace)
        if not projects:
            self._flash("No projects found", severity="warning")
            return
        for p in projects:
            self._write_activity(f"{p.key} \u00b7 {p.name}", style="info")

    async def _models_command(self) -> None:
        api, profile = await asyncio.to_thread(_platform_client)
        models = await asyncio.to_thread(api.list_models, profile.default_organization)
        if not models:
            self._flash("No models found", severity="warning")
            return
        for m in models:
            self._write_activity(f"{m.name} \u00b7 {m.latest_version or 'n/a'}", style="info")

    def _tools_mode_command(self, args: list[str]) -> None:
        """Open tools browser or set tool transcript detail mode."""
        if not args:
            self._open_tools_dialog()
            return

        mode = args[0].strip().lower()
        if mode not in {"compact", "expanded"}:
            self._flash("Usage: /tools or /tools <compact|expanded>", severity="warning")
            return

        self._tool_details_mode = mode
        self._flash(f"Tool details: {mode}", severity="info")

    @work(exclusive=True, group="tools_fetch")
    async def _open_tools_dialog(self) -> None:
        """Fetch tools and open the tools browser dialog."""
        dialog = self.query_one("#tools-dialog", ToolsDialog)
        if dialog.is_visible:
            dialog.hide()
            return
        try:
            tools = await self.server_client.fetch_tools()
        except Exception:
            self._flash("Failed to fetch tools", severity="warning")
            return
        dialog.show_tools(tools)

    # ==================================================================
    # Platform screens
    # ==================================================================

    def _open_platform_screen(self, screen_name: str) -> None:
        """Open a platform browser screen (traces, sandboxes, evaluations)."""
        try:
            api, profile = _platform_client()

            org = profile.default_organization
            workspace = profile.default_workspace
            project = profile.default_project
            if not org or not workspace:
                self._flash("No org/workspace. Use /login first.", severity="warning")
                return

            if screen_name == "traces" and not project:
                project = _default_project_for_workspace(api, org, workspace)
                if project:
                    name, current_profile = _active_profile()
                    if name and current_profile is not None:
                        current_profile.default_project = project
                        user_config = UserConfig.read(Path.home() / ".dreadnode" / "config.yaml")
                        user_config.servers[name] = current_profile
                        user_config.write(Path.home() / ".dreadnode" / "config.yaml")

            if screen_name == "traces":
                if not project:
                    self._flash("No default project. Use /projects first.", severity="warning")
                    return
                self.push_screen(TracesScreen(api, org, workspace, project))
            elif screen_name == "runtimes":
                self.push_screen(RuntimeScreen(api, org, workspace))
            elif screen_name == "hub":
                self.push_screen(HubScreen(api, org))
            elif screen_name == "environments":
                self.push_screen(EnvironmentScreen(api, org, workspace))
            elif screen_name == "secrets":
                self.push_screen(SecretsScreen(api))
            elif screen_name == "sandboxes":
                self.push_screen(SandboxScreen(api, org, workspace))
            elif screen_name == "evaluations":
                self.push_screen(EvaluationsScreen(api, org, workspace))
        except AuthenticationError:
            self._handle_authentication_error("Session expired — please sign in again")
        except Exception as exc:
            logger.exception("Failed to open %s screen", screen_name)
            self._flash(str(exc), severity="warning")

    def _open_capabilities_screen(self) -> None:
        """Open the dedicated capabilities manager for the active runtime."""
        try:
            api: ApiClient | None = None
            org: str | None = None
            workspace: str | None = None
            project: str | None = None

            try:
                api_client, profile = _platform_client()
                api = api_client
                org = profile.default_organization
                workspace = profile.default_workspace
            except AuthenticationError:
                raise  # re-raise auth errors for the outer handler
            except Exception:
                pass  # Not logged in to platform — screen works with local-only

            if api and org and workspace:
                project = getattr(profile, "default_project", None) if profile else None
                if not project:
                    # Profile may predate the default_project field — resolve it
                    try:
                        project = api.get_default_project_key(org, workspace)
                    except Exception:
                        pass

            is_sandbox = getattr(self.runtime_info, "host_type", "local") == "sandbox"
            self.push_screen(
                CapabilitiesScreen(
                    runtime_client=self.server_client,
                    api=api,
                    org=org,
                    workspace=workspace,
                    project=project,
                    is_sandbox=is_sandbox,
                ),
                callback=self._on_capabilities_dismiss,
            )
        except AuthenticationError:
            self._handle_authentication_error("Session expired — please sign in again")
        except Exception as exc:
            logger.exception("Failed to open capabilities screen")
            self._flash(str(exc), severity="warning")

    def _on_capabilities_dismiss(self, _result: t.Any) -> None:
        """Refresh runtime info after capabilities screen closes."""
        self._run_command(self._refresh_runtime)

    # ==================================================================
    # Prompt history
    # ==================================================================

    def _load_prompt_history(self) -> None:
        """Load prompt history from persistent JSONL file."""
        try:
            if not _HISTORY_FILE.is_file():
                return
            entries: list[str] = []
            for line in _HISTORY_FILE.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    text = json.loads(line).get("text", "")
                except (json.JSONDecodeError, AttributeError):
                    continue
                if text and (not entries or entries[-1] != text):
                    entries.append(text)
            self._prompt_history = entries[-_MAX_HISTORY:]
        except OSError:
            pass

    def _save_prompt_entry(self, text: str) -> None:
        """Append a single prompt entry to the persistent history file."""
        try:
            _HISTORY_FILE.parent.mkdir(parents=True, exist_ok=True)
            with _HISTORY_FILE.open("a", encoding="utf-8") as f:
                f.write(json.dumps({"text": text}) + "\n")
        except OSError:
            pass

    def _history_navigate(self, direction: int) -> None:
        """Navigate prompt history. direction: -1 for up, 1 for down."""
        if not self._prompt_history:
            return
        composer = self.query_one("#composer", ComposerInput)

        if self._history_index == -1:
            if direction == -1:
                self._history_stash = composer.value
                self._history_index = len(self._prompt_history) - 1
            else:
                return
        else:
            new_index = self._history_index + direction
            if new_index < 0:
                return
            if new_index >= len(self._prompt_history):
                self._history_index = -1
                self._set_composer_text(composer, self._history_stash)
                return
            self._history_index = new_index

        self._set_composer_text(composer, self._prompt_history[self._history_index])

    def _set_composer_text(self, composer: ComposerInput, text: str) -> None:
        """Replace composer text and move cursor to end."""
        composer.clear_pastes()
        composer.load_text(text)
        end = composer.document.end
        composer.move_cursor(end)

    # ==================================================================
    # Copy and export
    # ==================================================================

    def _copy_to_os_clipboard(self, text: str) -> None:
        """Copy text to OS clipboard with fallback for terminals without OSC 52."""
        import shutil
        import subprocess
        import sys

        # Try Textual's OSC 52 first (works in iTerm2, WezTerm, kitty, etc.)
        self.copy_to_clipboard(text)

        # Also try native clipboard commands as fallback
        if sys.platform == "darwin":
            cmd = "pbcopy"
        elif shutil.which("xclip"):
            cmd = "xclip -selection clipboard"
        elif shutil.which("xsel"):
            cmd = "xsel --clipboard --input"
        elif shutil.which("wl-copy"):
            cmd = "wl-copy"
        else:
            return
        try:
            subprocess.run(
                cmd.split(),
                input=text.encode(),
                check=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        except (subprocess.SubprocessError, FileNotFoundError):
            pass

    def _copy_last_assistant(self) -> None:
        """Copy the last assistant message to clipboard."""
        session = self._active_session()
        if session is None:
            return
        for entry in reversed(session.transcript):
            if entry.kind == "assistant":
                self._copy_to_os_clipboard(entry.body)
                self._flash("Copied to clipboard", severity="success")
                return
        self._flash("No assistant message to copy", severity="warning")

    @work(group="command", exclusive=True)
    async def _export_session(self, filename: str | None = None) -> None:
        """Export session transcript to a markdown file."""
        session = self._active_session()
        if session is None:
            self._flash("No active session to export", severity="warning")
            return

        if filename is None:
            sid_prefix = session.info.session_id[:8]
            filename = f"session-{sid_prefix}.md"

        lines: list[str] = []
        title = session.title or session.info.session_id[:8]
        lines.append(f"# {title}\n")

        for entry in session.transcript:
            if entry.kind == "user":
                lines.append(f"> {entry.body}\n")
            elif entry.kind == "assistant":
                lines.append(f"{entry.body}\n")
            elif entry.kind == "tool":
                lines.append(f"```\n{entry.title}: {entry.body}\n```\n")
            elif entry.kind == "error":
                lines.append(f"**Error:** {entry.body}\n")

        content = "\n".join(lines)
        try:
            Path(filename).write_text(content, encoding="utf-8")
            self._flash(f"Exported to {filename}", severity="success")
        except Exception as exc:
            self._flash(f"Export failed: {exc}", severity="error")

    # ==================================================================
    # Session title
    # ==================================================================

    def _rename_session(self, new_title: str) -> None:
        """Rename the active session."""
        session = self._active_session()
        if session is None:
            self._flash("No active session to rename", severity="warning")
            return
        session.title = new_title
        self._sync_sessions()
        self._update_context()
        self._flash(f"Session renamed to '{new_title}'", severity="success")

    # ==================================================================
    # Internal helpers
    # ==================================================================

    def _active_session(self) -> SessionRecord | None:
        if self.active_session_id is None:
            return None
        return self.sessions.get(self.active_session_id)

    def _set_active_session_agent(self, agent_name: str) -> None:
        """Update the active session's primary agent without recreating the session."""
        session = self._active_session()
        if session is None:
            return
        session.info.agent = agent_name
        capability_name = self._capability_for_agent(agent_name)
        if capability_name is not None:
            session.info.capability = capability_name
        self._sync_sessions()
        self._update_context()

    def _append_transcript(self, entry: TranscriptEntry, session_id: str) -> None:
        record = self.sessions.get(session_id)
        if record is None:
            return
        record.transcript.append(entry)
        if self.active_session_id == session_id:
            self.call_after_refresh(
                self.query_one("#conversation", ConversationView).append_entry, entry
            )

    def _commit_draft_to_transcript(self, session_id: str) -> None:
        """Flush live draft text into transcript and reset draft widget state."""
        draft = self.query_one("#draft", StreamingDraft)
        content = draft.finish_stream()
        turn_state = self._turn_state.get(session_id)
        if turn_state is not None:
            turn_state.draft_text = ""
            if turn_state.phase == "generating":
                turn_state.phase = "idle"
        if content.strip():
            self._append_transcript(
                TranscriptEntry(kind="assistant", title="assistant", body=content),
                session_id,
            )
        draft.clear_stream()
        self._draft_active = False

    def _sync_conversation(self) -> None:
        conversation = self.query_one("#conversation", ConversationView)
        session = self._active_session()
        if session is None:
            conversation.show_empty()
        else:
            conversation.load_session(session.transcript)

    def _sync_sessions(self) -> None:
        """Push session state to the sidebar."""
        try:
            sidebar = self.query_one("#sidebar", NavSidebar)
        except Exception:
            return
        entries = [
            SessionListEntry(
                session_id=sid,
                caption=record.info.agent or record.info.capability or "default",
                message_count=record.info.message_count,
                is_active=(sid == self.active_session_id),
                title=record.title,
            )
            for sid, record in self.sessions.items()
        ]
        sidebar.set_sessions(entries)

    def _capability_for_agent(self, agent_name: str) -> str | None:
        """Return the loaded capability name for a unique agent match."""
        if self.runtime_info is None:
            return None
        matches = [
            capability.name
            for capability in self.runtime_info.capabilities
            for agent in capability.agents
            if agent.name == agent_name
        ]
        if len(matches) == 1:
            return matches[0]
        return None

    def _on_model_changed(self, new_model: str) -> None:
        """Restore per-model variant state after model switch."""
        self.model = new_model
        stored = self._model_variants.get(new_model)
        if stored:
            from dreadnode.app.tui.model_variants import get_variants

            variants = get_variants(new_model)
            if stored in variants:
                self.thinking_enabled = True
                self.effort_label = stored
            else:
                # Model doesn't support this variant anymore
                self._model_variants.pop(new_model, None)
                self.thinking_enabled = False
                self.effort_label = ""
        else:
            self.thinking_enabled = False
            self.effort_label = ""
        self._update_context()

    def _update_context(self) -> None:
        active = self._active_session()
        if active:
            display = active.title or active.info.session_id[:8]
            self.session_label = display
            self.agent_name = active.info.agent or active.info.capability or "default"
        else:
            self.session_label = "none"
            self.agent_name = "default"
        self.connection = "local auto" if self.server_url is None else self.server_client.server_url
        self.model_name = self.model
        try:
            _name, profile = _active_profile()
        except Exception:
            profile = None
        if profile and profile.default_workspace:
            if profile.default_project:
                self.workspace_label = f"{profile.default_workspace}/{profile.default_project}"
            else:
                self.workspace_label = profile.default_workspace
        else:
            self.workspace_label = ""

    def _dismiss_welcome(self) -> None:
        """Hide the welcome screen and show the conversation."""
        welcome = self.query_one("#welcome", Welcome)
        if welcome.is_visible:
            welcome.dismiss()
            self.query_one("#conversation", ConversationView).display = True

    def _show_inline_activity(self, session_id: str, label: str) -> None:
        """Render a removable activity indicator inline in the conversation."""
        if session_id in self._inline_activity_sessions:
            return
        self._inline_activity_sessions.add(session_id)
        if self.active_session_id != session_id:
            return
        conv = self.query_one("#conversation", ConversationView)
        conv.write_activity(f"{label}...")

    def _clear_inline_activity(self, session_id: str) -> None:
        """Remove the inline activity indicator."""
        if session_id not in self._inline_activity_sessions:
            return
        self._inline_activity_sessions.discard(session_id)
        conv = self.query_one("#conversation", ConversationView)
        conv.clear_activity()

    def _set_composer_enabled(self, enabled: bool) -> None:
        """Toggle composer and its visual state."""
        self.query_one("#composer", ComposerInput).disabled = not enabled
        bar = self.query_one("#composer-bar")
        if enabled:
            bar.remove_class("-disabled")
        else:
            bar.add_class("-disabled")

    def _set_status(self, text: str, *, busy: bool | None = None) -> None:
        self.status_text = text
        if busy is not None:
            self.busy = busy

    def _flash(self, message: str, *, severity: str = "info") -> None:
        self.call_after_refresh(self.query_one("#flash", Flash).flash, message, severity=severity)

    def _handle_authentication_error(self, message: str) -> None:
        logger.warning("Auth error triggered: %s", message)
        self.authenticated = False
        self._show_auth_modal(self._resolved_server_url(), reason=message)

    def _write_activity(self, message: str, *, style: str = "info") -> None:
        """Write an activity message inline in the conversation."""
        color = {
            "info": FG_MUTED,
            "success": FG_MUTED,
            "warning": WARNING,
            "error": ERROR,
        }.get(style, FG_MUTED)
        self.call_after_refresh(
            self.query_one("#conversation", ConversationView).write_system,
            message,
            style=color,
        )

    def _show_help(self) -> None:
        """Write help content inline into the conversation view."""
        self._dismiss_welcome()
        conv = self.query_one("#conversation", ConversationView)
        conv.write(render_help())

    def _write_session_listing(self) -> None:
        """Write formatted session list inline in the conversation."""
        from rich.text import Text as RichText

        if not self.sessions:
            self._flash("No active sessions", severity="warning")
            return

        conversation = self.query_one("#conversation", ConversationView)
        header = RichText()
        header.append("· ", style=INFO)
        header.append(f"Sessions ({len(self.sessions)})", style=f"bold {INFO}")
        conversation.write(header)

        for sid in sorted(self.sessions.keys(), reverse=True):
            rec = self.sessions[sid]
            display = rec.title or sid[:8]
            line = RichText()
            is_active = sid == self.active_session_id
            line.append("  ● " if is_active else "  ○ ", style=ACCENT if is_active else FG_FAINTEST)
            line.append(f"{display:<20}", style=FG if is_active else FG_SUBTLE)
            line.append(rec.info.agent or rec.info.capability or "default", style=FG_MUTED)
            line.append(f"  {rec.info.message_count} msgs", style=FG_FAINTEST)
            line.append(f"  {sid[:8]}", style=FG_FAINTEST)
            conversation.write(line)

    def _write_agent_listing(self) -> None:
        """Write formatted agent list inline in the conversation."""
        from rich.text import Text as RichText

        if self.runtime_info is None:
            self._flash("Runtime not loaded", severity="warning")
            return
        agents = [a for c in self.runtime_info.capabilities for a in c.agents]
        if not agents:
            self._flash("No agents loaded", severity="warning")
            return

        conversation = self.query_one("#conversation", ConversationView)
        header = RichText()
        header.append("· ", style=INFO)
        header.append(f"Agents ({len(agents)})", style=f"bold {INFO}")
        conversation.write(header)

        for a in agents:
            line = RichText()
            line.append(f"  {a.name:<20}", style=f"bold {FG}")
            line.append(a.capability, style=FG_MUTED)
            if a.model and a.model != "inherit":
                line.append(f"  {a.model}", style=FG_FAINTEST)
            conversation.write(line)


# ======================================================================
# Entry points
# ======================================================================


def main() -> None:
    """Parse CLI arguments and launch the Textual TUI or agent server."""
    parser = argparse.ArgumentParser(prog="dreadnode", description="Dreadnode TUI")
    subparsers = parser.add_subparsers(dest="command")
    parser.add_argument(
        "--server",
        "-s",
        default=None,
        help="Runtime server URL override (disables local auto-start; not the platform API)",
    )
    parser.add_argument(
        "--platform",
        "-p",
        default=None,
        help="Platform API URL override for authentication and profiles",
    )

    serve_parser = subparsers.add_parser("serve", help="Run the agent server directly")
    serve_parser.add_argument("--host", default=None)
    serve_parser.add_argument("--port", type=int, default=None)
    serve_parser.add_argument("--working-dir", default=None, dest="serve_working_dir")
    serve_parser.add_argument("--platform-server", default=None)
    serve_parser.add_argument("--api-key", default=None)
    serve_parser.add_argument("--organization", default=None)
    serve_parser.add_argument("--workspace", default=None)
    serve_parser.add_argument("--project", default=None)
    serve_parser.add_argument(
        "--verbose",
        action="store_true",
        help="Enable verbose trace logging for the local server",
    )

    args = parser.parse_args()

    if args.command == "serve":
        _run_serve(args)
        return

    app = DreadnodeTextualApp(server_url=args.server, platform_url=args.platform)
    app.run()


def _run_serve(args: argparse.Namespace) -> None:
    from dreadnode.app.server import run_server

    if args.verbose:
        configure_logging("trace", verbose=True)
    if args.serve_working_dir:
        os.chdir(args.serve_working_dir)
    run_server(
        host=args.host,
        port=args.port,
        server=args.platform_server,
        api_key=args.api_key,
        organization=args.organization,
        workspace=args.workspace,
        project=args.project,
    )
