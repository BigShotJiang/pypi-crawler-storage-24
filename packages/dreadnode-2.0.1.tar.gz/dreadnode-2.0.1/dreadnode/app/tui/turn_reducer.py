from __future__ import annotations

import time
import typing as t
from dataclasses import dataclass, field, replace

from dreadnode.app.api.models import HumanPrompt
from dreadnode.app.tui.commands import _format_tool_label

if t.TYPE_CHECKING:
    from dreadnode.app.tui.event_contract import NormalizedEvent

TurnPhase = t.Literal[
    "idle",
    "generating",
    "running_tools",
    "awaiting_permission",
    "awaiting_input",
    "completed",
    "failed",
]

ToolStatus = t.Literal["running", "completed", "errored"]


@dataclass(slots=True)
class ToolRun:
    """Tool lifecycle state for one tool call."""

    tool_call_id: str
    tool_name: str
    tool_args: dict[str, t.Any]
    label: str
    status: ToolStatus
    started_at: float
    ended_at: float | None = None
    summary: str | None = None
    error: str | None = None
    partial: bool = False


@dataclass(slots=True)
class TurnState:
    """Reducer state for one session turn."""

    session_id: str
    phase: TurnPhase
    draft_text: str
    tool_runs: dict[str, ToolRun] = field(default_factory=dict)
    tool_order: list[str] = field(default_factory=list)
    pending_human_prompt: HumanPrompt | None = None
    usage_total_tokens: int = 0
    final_error: str | None = None
    last_heartbeat_at: str | None = None

    @classmethod
    def empty(cls, session_id: str) -> TurnState:
        """Create a fresh empty turn state."""
        return cls(session_id=session_id, phase="idle", draft_text="")


def reduce_event(
    state: TurnState,
    event: NormalizedEvent,
    *,
    now: t.Callable[[], float] = time.monotonic,
) -> TurnState:
    """Reduce one normalized event into next turn state."""
    if event.session_id != state.session_id:
        return state

    next_state = _clone_state(state)
    if event.type == "generation_start":
        next_state.phase = "generating"
        next_state.usage_total_tokens = _merge_usage(
            next_state.usage_total_tokens, event.usage_total_tokens
        )
    elif event.type == "generation_step":
        next_state.phase = "generating"
        if event.assistant_delta:
            next_state.draft_text += event.assistant_delta
        next_state.usage_total_tokens = _merge_usage(
            next_state.usage_total_tokens, event.usage_total_tokens
        )
    elif event.type == "generation_end":
        next_state.usage_total_tokens = _merge_usage(
            next_state.usage_total_tokens, event.usage_total_tokens
        )
        if not _has_running_tools(next_state):
            next_state.phase = "idle"
    elif event.type == "tool_start":
        key = _tool_key(next_state, event)
        tool_name = event.tool_name or "tool"
        tool_args = event.tool_args or {}
        next_state.tool_runs[key] = ToolRun(
            tool_call_id=key,
            tool_name=tool_name,
            tool_args=tool_args,
            label=_format_tool_label(tool_name, tool_args),
            status="running",
            started_at=now(),
        )
        if key not in next_state.tool_order:
            next_state.tool_order.append(key)
        next_state.phase = "running_tools"
    elif event.type == "tool_end":
        next_state = _finish_tool(next_state, event, status="completed", now=now)
    elif event.type == "tool_error":
        next_state = _finish_tool(next_state, event, status="errored", now=now)
        if event.error_text:
            key = _tool_key(next_state, event)
            run = next_state.tool_runs.get(key)
            if run is not None:
                run.error = event.error_text
    elif event.type == "human_prompt":
        prompt = event.human_prompt
        next_state.pending_human_prompt = prompt
        if prompt is not None and prompt.kind == "approval":
            next_state.phase = "awaiting_permission"
        else:
            next_state.phase = "awaiting_input"
    elif event.type == "heartbeat":
        next_state.last_heartbeat_at = event.timestamp
    elif event.type == "agent_end":
        next_state.pending_human_prompt = None
        if event.error_text:
            next_state.phase = "failed"
            next_state.final_error = event.error_text
        else:
            next_state.phase = "completed"
    elif event.type in {"generation_error", "agent_error", "runtime_error", "agent_stalled"}:
        next_state.phase = "failed"
        next_state.final_error = event.error_text or "unknown error"
    return next_state


def _clone_state(state: TurnState) -> TurnState:
    return TurnState(
        session_id=state.session_id,
        phase=state.phase,
        draft_text=state.draft_text,
        tool_runs={key: replace(run) for key, run in state.tool_runs.items()},
        tool_order=list(state.tool_order),
        pending_human_prompt=state.pending_human_prompt,
        usage_total_tokens=state.usage_total_tokens,
        final_error=state.final_error,
        last_heartbeat_at=state.last_heartbeat_at,
    )


def reduce_human_prompt_response(state: TurnState, *, action: str) -> TurnState:
    """Apply a local human prompt response to the turn state."""
    next_state = _clone_state(state)
    next_state.pending_human_prompt = None
    if action in {"submit", "approve", "allow_session"}:
        next_state.phase = "running_tools"
    elif action in {"cancel", "deny"}:
        next_state.phase = "idle"
    return next_state


def _merge_usage(current: int, incoming: int | None) -> int:
    if incoming is None:
        return current
    if incoming > current:
        return incoming
    return current


def _tool_key(state: TurnState, event: NormalizedEvent) -> str:
    if event.tool_call_id:
        return event.tool_call_id

    tool_name = event.tool_name or "tool"
    if event.type in {"tool_end", "tool_error"}:
        for key in reversed(state.tool_order):
            run = state.tool_runs.get(key)
            if run is None:
                continue
            if run.status == "running" and run.tool_name == tool_name:
                return key

    base = f"missing:{tool_name}"
    if base not in state.tool_runs:
        return base
    index = 2
    while f"{base}:{index}" in state.tool_runs:
        index += 1
    return f"{base}:{index}"


def _finish_tool(
    state: TurnState,
    event: NormalizedEvent,
    *,
    status: ToolStatus,
    now: t.Callable[[], float],
) -> TurnState:
    key = _tool_key(state, event)
    run = state.tool_runs.get(key)
    if run is None:
        tool_name = event.tool_name or "tool"
        tool_args = event.tool_args or {}
        run = ToolRun(
            tool_call_id=key,
            tool_name=tool_name,
            tool_args=tool_args,
            label=_format_tool_label(tool_name, tool_args),
            status=status,
            started_at=now(),
            partial=True,
        )
        state.tool_runs[key] = run
        state.tool_order.append(key)
    run.status = status
    run.ended_at = now()
    if not _has_running_tools(state):
        state.phase = "idle"
    return state


def _has_running_tools(state: TurnState) -> bool:
    return any(run.status == "running" for run in state.tool_runs.values())
