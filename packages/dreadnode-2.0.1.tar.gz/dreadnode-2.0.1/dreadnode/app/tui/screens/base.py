"""Base screen that includes Zone 4 global nav bar on all pushed screens."""

from __future__ import annotations

import logging

from textual.app import ComposeResult
from textual.screen import Screen

from dreadnode.app.tui.widgets.status_bar import StatusBar

logger = logging.getLogger(__name__)


class DreadnodeScreen(Screen[None]):
    """Base class for all pushed screens — automatically includes Zone 4 StatusBar.

    Subclasses override ``compose_content()`` instead of ``compose()``.
    """

    def compose_content(self) -> ComposeResult:
        """Override this in subclasses to yield screen-specific content."""
        return
        yield  # Make it a generator

    def compose(self) -> ComposeResult:
        yield from self.compose_content()
        yield StatusBar(id="global-status-bar")

    def on_mount(self) -> None:
        """Bind StatusBar reactives to app-level state via data_bind().

        Uses data_bind() so Zone 4 stays in sync with app reactives
        (not a one-time copy). Imports DreadnodeTextualApp locally
        to avoid circular imports.
        """
        try:
            from dreadnode.app.tui.app import DreadnodeTextualApp

            bar = self.query_one("#global-status-bar", StatusBar)
            bar.data_bind(
                connection=DreadnodeTextualApp.connection,
                workspace_label=DreadnodeTextualApp.workspace_label,
                runtime_health=DreadnodeTextualApp.runtime_health,
            )
        except Exception:
            logger.debug("Failed to bind StatusBar reactives", exc_info=True)
