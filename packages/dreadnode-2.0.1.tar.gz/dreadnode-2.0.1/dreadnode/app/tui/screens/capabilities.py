"""Capabilities manager screen — discover, install, and manage capabilities.

Single-column layout matching Claude Code's plugin manager pattern:
  List view:   tab bar → search → scrollable item list with ❯ cursor
  Detail view: item info → action list with ❯ cursor
  Enter: list→detail or execute action
  Esc:   detail→list or dismiss
"""

import asyncio
import typing as t

from packaging.version import InvalidVersion, Version
from rich.text import Text
from textual import work
from textual.app import ComposeResult
from textual.containers import VerticalScroll
from textual.events import Key
from textual.widgets import Static

from dreadnode.app.tui.screens.base import DreadnodeScreen
from dreadnode.app.tui.theme import (
    ACCENT,
    BRAND,
    ERROR,
    FG,
    FG_FAINTEST,
    FG_MUTED,
    FG_SUBTLE,
    INFO,
    SUCCESS,
    WARNING,
)
from dreadnode.capabilities.sync import LocalInstallClient

if t.TYPE_CHECKING:
    from dreadnode.app.api.client import ApiClient
    from dreadnode.app.tui.client import RuntimeServerClient

# ── Tab identifiers ──────────────────────────────────────────────────────────

_TAB_AVAILABLE = "available"
_TAB_INSTALLED = "installed"
_TABS = [_TAB_AVAILABLE, _TAB_INSTALLED]


# ── Helpers ──────────────────────────────────────────────────────────────────

def _display_name(item: dict[str, t.Any]) -> str:
    """Best user-facing name for a capability."""
    dn = item.get("display_name")
    if isinstance(dn, str) and dn.strip():
        return dn
    return str(item.get("name", "?"))


def _version_cmp(available: str | None, installed: str | None) -> str:
    """Compare versions → 'install' | 'installed' | 'update'."""
    if installed is None:
        return "install"
    if not isinstance(available, str) or not isinstance(installed, str):
        return "installed"
    try:
        if Version(available) > Version(installed):
            return "update"
    except InvalidVersion:
        if available != installed:
            return "update"
    return "installed"


def _filter(items: list[dict[str, t.Any]], query: str) -> list[dict[str, t.Any]]:
    if not query:
        return items
    q = query.lower()
    return [
        i for i in items
        if q in i.get("name", "").lower()
        or q in (i.get("description") or i.get("summary") or "").lower()
    ]


def _component_summary(item: dict[str, t.Any]) -> str:
    """One-line component summary: '3 skills · 1 agent · 2 tools'."""
    counts = item.get("component_counts", {})
    if counts:
        parts = []
        for kind in ("agent", "skill", "tool", "mcp_server"):
            n = counts.get(kind, counts.get(f"{kind}s", 0))
            if n:
                label = kind.replace("_", " ") + ("s" if n != 1 else "")
                parts.append(f"{n} {label}")
        return " · ".join(parts) if parts else ""

    components = item.get("components", [])
    agents = item.get("agents", [])
    if not components and not agents:
        return ""
    kind_counts: dict[str, int] = {}
    if agents:
        kind_counts["agent"] = len(agents)
    for c in components:
        k = c.get("kind", "?") if isinstance(c, dict) else getattr(c, "kind", "?")
        if k == "agent":
            continue
        kind_counts[k] = kind_counts.get(k, 0) + 1
    parts = []
    for kind in ("agent", "skill", "tool", "mcp_server"):
        n = kind_counts.get(kind, 0)
        if n:
            label = kind.replace("_", " ") + ("s" if n != 1 else "")
            parts.append(f"{n} {label}")
    return " · ".join(parts) if parts else ""


def _health_summary(item: dict[str, t.Any]) -> tuple[int, int, int]:
    """Return (ok, warning, error) counts from components."""
    ok = warn = err = 0
    for c in item.get("components", []):
        status = c.get("status", "ok") if isinstance(c, dict) else getattr(c, "status", "ok")
        if status == "ok":
            ok += 1
        elif status == "error":
            err += 1
        else:
            warn += 1
    return ok, warn, err


def _merge_available_sources(
    org_items: list[dict[str, t.Any]],
    public_items: list[dict[str, t.Any]],
) -> list[dict[str, t.Any]]:
    """Merge org/public available items, collapsing public visibility duplicates."""
    merged: dict[str, dict[str, t.Any]] = {}

    for item in org_items:
        merged[item["name"]] = dict(item)

    for item in public_items:
        name = item["name"]
        if name in merged:
            merged[name]["source"] = "public"
            continue
        merged[name] = dict(item)

    return list(merged.values())


def _build_actions(
    item: dict[str, t.Any],
    *,
    is_installed: bool,
    is_sandbox: bool,
    has_platform: bool,
    project: str | None,
) -> list[tuple[str, str]]:
    """Return list of (action_id, label) for the action list.

    CAP-RT-002: local runtimes expose local management only.
    CAP-RT-003: sandbox runtimes expose project management only.
    """
    actions: list[tuple[str, str]] = []

    if is_installed:
        state = item.get("state", "enabled")
        source = item.get("source", "local")

        if state == "enabled":
            actions.append(("toggle", "Disable capability"))
        else:
            actions.append(("toggle", "Enable capability"))

        if is_sandbox and source == "project" and item.get("binding_id"):
            actions.append(("remove", "Uninstall"))
        elif not is_sandbox and source in ("local", "package"):
            actions.append(("remove_local", "Remove from disk"))
    else:
        install_state = item.get("install_state", "install")
        if install_state == "install":
            if has_platform and (project or not is_sandbox):
                actions.append(("install", "Install"))
            elif not has_platform:
                actions.append(("noop", "Install unavailable (not authenticated)"))
            else:
                actions.append(("noop", "Install unavailable (no project)"))
        elif install_state == "update":
            if has_platform and (project or not is_sandbox):
                actions.append(("update", "Update to latest"))
            elif not has_platform:
                actions.append(("noop", "Update unavailable (not authenticated)"))
            else:
                actions.append(("noop", "Update unavailable (no project)"))
        elif install_state == "installed":
            actions.append(("noop", "Already installed"))
        elif install_state == "disabled":
            actions.append(("noop", "Installed (disabled)"))

    return actions


def _format_provenance(provenance: str | None) -> str | None:
    """Return the user-facing provenance label for installed local capabilities."""
    if provenance == "local":
        return "local (authored)"
    if provenance in {"org", "public"}:
        return provenance
    return None


# ── Main screen ──────────────────────────────────────────────────────────────

class CapabilitiesScreen(DreadnodeScreen):
    """Full-screen capability manager — discover, install, manage."""

    def __init__(
        self,
        runtime_client: "RuntimeServerClient",
        api: "ApiClient | None" = None,
        org: str | None = None,
        workspace: str | None = None,
        project: str | None = None,
        is_sandbox: bool = False,
        **kwargs: t.Any,
    ) -> None:
        super().__init__(**kwargs)
        self._runtime_client = runtime_client
        self._api = api
        self._org = org
        self._workspace = workspace
        self._project = project
        self._is_sandbox = is_sandbox

        self._active_tab: str = _TAB_INSTALLED
        self._installed_items: list[dict[str, t.Any]] = []
        self._available_items: list[dict[str, t.Any]] = []

        # View state
        self._view: str = "list"  # "list" or "detail"
        self._cursor: int = 0
        self._action_cursor: int = 0
        self._search_query: str = ""
        self._visible_items: list[dict[str, t.Any]] = []
        self._selected_item: dict[str, t.Any] | None = None
        self._current_actions: list[tuple[str, str]] = []
        self._pending_local_overwrite_key: str | None = None
        self._detail_notice: tuple[str, str] | None = None

    @property
    def _has_platform(self) -> bool:
        return self._api is not None and self._org is not None

    @property
    def _tabs(self) -> list[str]:
        """Visible tabs for the current host type."""
        return [_TAB_AVAILABLE, _TAB_INSTALLED]

    # ── Compose ──────────────────────────────────────────────────────────

    def compose_content(self) -> ComposeResult:
        yield Static(id="cap-header")
        with VerticalScroll(id="cap-scroll"):
            yield Static(id="cap-content")
        yield Static(id="cap-hint-bar")

    def on_mount(self) -> None:
        super().on_mount()
        self._render_header()
        self._render_hints()
        self._load_data()

    # ── Keyboard handling ────────────────────────────────────────────────

    def on_key(self, event: Key) -> None:
        """Single handler for all keyboard input."""
        key = event.key

        # Let control sequences and function keys pass through to app bindings
        if key.startswith("ctrl+") or (key.startswith("f") and key[1:].isdigit()):
            return

        if self._view == "detail":
            self._handle_detail_key(key)
        else:
            self._handle_list_key(key, event)

        event.prevent_default()
        event.stop()

    def _handle_list_key(self, key: str, event: Key) -> None:
        if key == "up":
            if self._visible_items:
                self._cursor = max(0, self._cursor - 1)
                self._render_current_view()
        elif key == "down":
            if self._visible_items:
                self._cursor = min(len(self._visible_items) - 1, self._cursor + 1)
                self._render_current_view()
        elif key == "enter":
            if self._visible_items and 0 <= self._cursor < len(self._visible_items):
                self._selected_item = self._visible_items[self._cursor]
                self._pending_local_overwrite_key = None
                self._detail_notice = None
                self._action_cursor = 0
                self._view = "detail"
                self._render_current_view()
        elif key == "escape":
            if self._search_query:
                self._search_query = ""
                self._cursor = 0
                self._render_current_view()
            else:
                self.dismiss()
        elif key in ("tab", "right"):
            self._switch_tab(1)
        elif key in ("shift+tab", "left"):
            self._switch_tab(-1)
        elif key == "space":
            self._toggle_current()
        elif key == "backspace":
            if self._search_query:
                self._search_query = self._search_query[:-1]
                self._cursor = 0
                self._render_current_view()
        elif event.character and event.character.isprintable() and len(event.character) == 1:
            self._search_query += event.character
            self._cursor = 0
            self._render_current_view()

    def _handle_detail_key(self, key: str) -> None:
        total_actions = len(self._current_actions) + 1  # +1 for "Back"
        if key == "up":
            self._action_cursor = max(0, self._action_cursor - 1)
            self._render_current_view()
        elif key == "down":
            self._action_cursor = min(total_actions - 1, self._action_cursor + 1)
            self._render_current_view()
        elif key == "enter":
            if self._action_cursor >= len(self._current_actions):
                self._back_to_list()
            else:
                action_id = self._current_actions[self._action_cursor][0]
                if action_id != "noop":
                    self._execute_action(action_id)
        elif key == "escape":
            self._back_to_list()

    # ── Tab switching ────────────────────────────────────────────────────

    def _switch_tab(self, direction: int) -> None:
        tabs = self._tabs
        idx = tabs.index(self._active_tab) if self._active_tab in tabs else 0
        self._active_tab = tabs[(idx + direction) % len(tabs)]
        self._search_query = ""
        self._cursor = 0
        self._view = "list"
        self._pending_local_overwrite_key = None
        self._detail_notice = None
        self._render_current_view()

    def _back_to_list(self) -> None:
        self._view = "list"
        self._pending_local_overwrite_key = None
        self._detail_notice = None
        self._render_current_view()

    # ── Rendering ────────────────────────────────────────────────────────

    def _render_current_view(self) -> None:
        self._render_header()
        if self._view == "detail":
            self._render_detail_view()
        else:
            self._render_list_view()
        self._render_hints()

    def _render_header(self) -> None:
        text = Text()
        text.append(" Capabilities", style=f"bold {BRAND}")
        text.append("  ")
        for tab in self._tabs:
            label = tab.capitalize()
            count = len(self._installed_items) if tab == _TAB_INSTALLED else len(self._available_items)
            if tab == self._active_tab:
                text.append(f" {label}", style=f"bold reverse {BRAND}")
                if count:
                    text.append(f" ({count})", style=f"reverse {BRAND}")
                text.append(" ", style=f"reverse {BRAND}")
            else:
                text.append(f" {label}", style=FG_MUTED)
                if count:
                    text.append(f" ({count})", style=FG_FAINTEST)
                text.append(" ")
            text.append("  ")
        text.append("(Tab to switch)", style=FG_FAINTEST)
        self.query_one("#cap-header", Static).update(text)

    def _render_hints(self) -> None:
        if self._view == "detail":
            hints = [("Enter", "select"), ("Esc", "back")]
        else:
            hints = [("Type", "search"), ("Space", "toggle"), ("Enter", "details"), ("Esc", "close")]
        text = Text()
        text.append(" ")
        for i, (key, action) in enumerate(hints):
            if i > 0:
                text.append(" · ", style=FG_FAINTEST)
            text.append(key, style=FG_MUTED)
            text.append(f" {action}", style=FG_FAINTEST)
        self.query_one("#cap-hint-bar", Static).update(text)

    def _render_list_view(self) -> None:
        items = self._current_items()
        visible = _filter(items, self._search_query)
        self._visible_items = visible
        self._cursor = min(self._cursor, max(0, len(visible) - 1))

        text = Text()

        # Search area
        if self._search_query:
            text.append(f" ⌕ {self._search_query}", style=FG)
            text.append("▏", style=FG_FAINTEST)
        else:
            text.append(" ⌕ Search…", style=FG_FAINTEST)
        if visible:
            text.append(f"  {self._cursor + 1}/{len(visible)}", style=FG_FAINTEST)
        text.append("\n\n")

        if not visible:
            if self._search_query:
                text.append(f'  No matches for "{self._search_query}"\n', style=FG_MUTED)
            elif not items:
                if self._active_tab == _TAB_AVAILABLE:
                    if not self._has_platform:
                        text.append("  No capabilities available\n\n", style=FG_MUTED)
                        text.append("  Sign in with ", style=FG_FAINTEST)
                        text.append("dn auth", style=FG_SUBTLE)
                        text.append(" to browse the capability registry.\n", style=FG_FAINTEST)
                    else:
                        text.append("  No capabilities available\n\n", style=FG_MUTED)
                        text.append("  Check the capability registry at ", style=FG_FAINTEST)
                        text.append("app.dreadnode.io", style=FG_SUBTLE)
                        text.append(" for new capabilities.\n", style=FG_FAINTEST)
                else:
                    text.append("  No capabilities installed\n\n", style=FG_MUTED)
                    text.append("  Switch to the ", style=FG_FAINTEST)
                    text.append("Available", style=FG_SUBTLE)
                    text.append(" tab to discover and install capabilities.\n", style=FG_FAINTEST)
                    text.append("  Or place a ", style=FG_FAINTEST)
                    text.append("capability.yaml", style=FG_SUBTLE)
                    text.append(" in your working directory.\n", style=FG_FAINTEST)
        else:
            installed_names = {
                i.get("canonical_name") or i.get("name")
                for i in self._installed_items
            }

            for i, item in enumerate(visible):
                # Cursor marker
                if i == self._cursor:
                    text.append(" ❯ ", style=f"bold {ACCENT}")
                else:
                    text.append("   ")

                # Status dot + name + version
                if self._active_tab == _TAB_AVAILABLE:
                    is_inst = item["name"] in installed_names
                    text.append("● " if is_inst else "◯ ", style=SUCCESS if is_inst else FG_FAINTEST)
                    text.append(_display_name(item), style=FG)
                    version = item.get("version")
                    if version:
                        text.append(f" v{version}", style=FG_FAINTEST)
                    source = item.get("source", "")
                    if source:
                        text.append(f" · {source}", style=FG_MUTED)
                else:
                    state = item.get("state", "enabled")
                    if state == "enabled":
                        text.append("● ", style=SUCCESS)
                    elif state == "disabled":
                        text.append("◯ ", style=WARNING)
                    else:
                        text.append("◯ ", style=FG_FAINTEST)
                    text.append(_display_name(item), style=FG)
                    version = item.get("version")
                    if version:
                        text.append(f" v{version}", style=FG_FAINTEST)

                    # Status suffix
                    _, _, err_count = _health_summary(item)
                    if state == "disabled":
                        text.append(" · ◯ disabled", style=WARNING)
                    elif err_count:
                        text.append(
                            f" · ✗ {err_count} error{'s' if err_count != 1 else ''}",
                            style=ERROR,
                        )

                text.append("\n")

                # Description
                desc = item.get("description") or item.get("summary") or ""
                meta_parts: list[str] = []
                author = item.get("author")
                if isinstance(author, dict):
                    author_name = author.get("name")
                    if isinstance(author_name, str) and author_name.strip():
                        meta_parts.append(author_name)
                elif isinstance(author, str) and author.strip():
                    meta_parts.append(author)
                components = _component_summary(item)
                if components:
                    meta_parts.append(components)

                if len(desc) > 70:
                    desc = desc[:67] + "..."
                if desc:
                    text.append(f"     {desc}\n", style=FG_SUBTLE)
                if meta_parts:
                    text.append(f"     {' · '.join(meta_parts)}\n", style=FG_MUTED)

                text.append("\n")

            if len(visible) > 10:
                text.append("  ↓ more below\n", style=FG_FAINTEST)

        self.query_one("#cap-content", Static).update(text)

    def _render_detail_view(self) -> None:
        item = self._selected_item
        if not item:
            return

        is_installed = self._active_tab == _TAB_INSTALLED
        text = Text()

        if self._detail_notice is not None:
            message, severity = self._detail_notice
            notice_style = {
                "error": ERROR,
                "success": SUCCESS,
                "warning": WARNING,
            }.get(severity, INFO)
            text.append(f" {message}\n\n", style=notice_style)

        # Name with status dot for installed items
        if is_installed:
            state = item.get("state", "enabled")
            dot_style = SUCCESS if state == "enabled" else WARNING
            text.append(f" {'●' if state == 'enabled' else '◯'} ", style=dot_style)
        else:
            text.append(" ")
        text.append(_display_name(item), style=f"bold {FG}")
        if item.get("version"):
            text.append(f"  v{item['version']}", style=FG_MUTED)
        text.append("\n")

        # Description
        desc = item.get("description") or item.get("summary") or ""
        if desc:
            text.append(f" {desc}\n", style=FG_SUBTLE)

        text.append("\n")

        # Structured metadata fields
        if is_installed and not self._is_sandbox:
            provenance = _format_provenance(t.cast(str | None, item.get("provenance")))
            if provenance is not None:
                text.append(" Provenance: ", style=FG_MUTED)
                text.append(f"{provenance}\n", style=FG_SUBTLE)
        elif not is_installed:
            source = item.get("source", "")
            if source:
                text.append(" Source: ", style=FG_MUTED)
                text.append(f"{source}\n", style=FG_SUBTLE)

        if item.get("author"):
            author = item["author"]
            if isinstance(author, dict):
                author = author.get("name", str(author))
            text.append(" Author: ", style=FG_MUTED)
            text.append(f"{author}\n", style=FG_SUBTLE)

        if item.get("license"):
            text.append(" License: ", style=FG_MUTED)
            text.append(f"{item['license']}\n", style=FG_SUBTLE)

        if is_installed:
            state = item.get("state", "enabled")
            text.append(" Status: ", style=FG_MUTED)
            if state == "enabled":
                text.append("Enabled\n", style=SUCCESS)
            elif state == "disabled":
                text.append("Disabled\n", style=WARNING)

        # Components — individual listing for installed, summary for available
        components = item.get("components", [])
        agents_list = item.get("agents", [])
        if is_installed and (components or agents_list):
            text.append("\n Components\n", style=f"bold {FG_SUBTLE}")
            for agent in agents_list:
                aname = agent.get("name", "?") if isinstance(agent, dict) else getattr(agent, "name", "?")
                text.append("   agent      ", style=FG_MUTED)
                text.append(f"{aname}\n", style=FG_SUBTLE)
            for c in components:
                kind = c.get("kind", "?") if isinstance(c, dict) else getattr(c, "kind", "?")
                cname = c.get("name", "?") if isinstance(c, dict) else getattr(c, "name", "?")
                status = c.get("status", "ok") if isinstance(c, dict) else getattr(c, "status", "ok")
                error = c.get("error", "") if isinstance(c, dict) else getattr(c, "error", "")
                kind_label = kind.replace("_", " ").ljust(10)
                text.append(f"   {kind_label}  ", style=FG_MUTED)
                if status == "error":
                    text.append(f"✗ {cname}", style=ERROR)
                    if error:
                        text.append(f" ({error})", style=FG_SUBTLE)
                elif status == "degraded":
                    text.append(f"{cname}", style=WARNING)
                else:
                    text.append(f"{cname}", style=FG_SUBTLE)
                text.append("\n")
        elif not is_installed:
            comp = _component_summary(item)
            if comp:
                text.append("\n Components: ", style=FG_MUTED)
                text.append(f"{comp}\n", style=FG_SUBTLE)

        text.append("\n")

        # Action list
        if (
            not is_installed
            and not self._is_sandbox
            and self._pending_local_overwrite_key == item.get("row_key")
        ):
            actions = [
                ("overwrite_install", "Overwrite existing local install"),
                ("cancel_overwrite", "Cancel"),
            ]
        else:
            actions = _build_actions(
                item,
                is_installed=is_installed,
                is_sandbox=self._is_sandbox,
                has_platform=self._has_platform,
                project=self._project,
            )
        self._current_actions = actions

        for i, (action_id, label) in enumerate(actions):
            if i == self._action_cursor:
                text.append(" ❯ ", style=f"bold {ACCENT}")
            else:
                text.append("   ")
            if action_id == "noop":
                text.append(f"{label}\n", style=FG_FAINTEST)
            elif action_id in ("remove", "remove_local"):
                text.append(f"{label}\n", style=ERROR)
            elif action_id in ("install", "update"):
                text.append(f"{label}\n", style=INFO)
            else:
                text.append(f"{label}\n", style=FG)

        # "Back to list" is always the last action
        back_idx = len(actions)
        if self._action_cursor == back_idx:
            text.append(" ❯ ", style=f"bold {ACCENT}")
        else:
            text.append("   ")
        text.append("Back to capability list\n", style=FG_SUBTLE)

        self.query_one("#cap-content", Static).update(text)

    # ── Toggle from list ─────────────────────────────────────────────────

    def _toggle_current(self) -> None:
        if not self._visible_items or self._cursor >= len(self._visible_items):
            return
        item = self._visible_items[self._cursor]

        if self._active_tab == _TAB_INSTALLED:
            if item.get("source") == "project" and item.get("binding_id"):
                new_enabled = item.get("state") != "enabled"
                self._do_toggle(item["binding_id"], enabled=new_enabled)
            elif item.get("source") in ("local", "package"):
                new_enabled = item.get("state") != "enabled"
                self._do_toggle_local(item["name"], enabled=new_enabled)
        else:
            install_state = item.get("install_state", "install")
            if install_state == "install" and self._has_platform and (self._project or not self._is_sandbox):
                self._show_action_notice(item["name"], "Installing")
                self._do_install(item["name"], item.get("version"))

    # ── Data loading ─────────────────────────────────────────────────────

    def _current_items(self) -> list[dict[str, t.Any]]:
        if self._active_tab == _TAB_INSTALLED:
            return self._installed_items
        return self._available_items

    @work(exclusive=True, group="cap-load")
    async def _load_data(self) -> None:
        await self._fetch_installed()
        await self._fetch_available()
        self._refresh_selected_item()
        self._render_current_view()

    def _refresh_selected_item(self) -> None:
        """Refresh the selected item from the latest loaded data when possible."""
        if self._selected_item is None:
            return

        items = self._installed_items if self._active_tab == _TAB_INSTALLED else self._available_items
        selected_row_key = self._selected_item.get("row_key")
        selected_name = self._selected_item.get("name")

        for item in items:
            if selected_row_key and item.get("row_key") == selected_row_key:
                self._selected_item = item
                return
            if selected_name and item.get("name") == selected_name:
                self._selected_item = item
                return

    async def _fetch_installed(self) -> None:
        items: list[dict[str, t.Any]] = []
        try:
            runtime_info = await self._runtime_client.fetch_runtime_info()
            for cap in runtime_info.capabilities:
                if not cap.enabled:
                    state = "disabled"
                else:
                    state = "enabled"

                source = cap.source or "local"

                items.append({
                    "row_key": f"{source}:{cap.name}:{cap.binding_id or ''}",
                    "name": cap.name,
                    "display_name": cap.display_name,
                    "canonical_name": cap.canonical_name,
                    "summary": cap.description or "",
                    "description": cap.description or "",
                    "source": source,
                    "provenance": cap.provenance,
                    "state": state,
                    "version": cap.version,
                    "binding_id": cap.binding_id,
                    "author": cap.author,
                    "license": cap.license,
                    "origin": cap.origin,
                    "agents": [
                        {"name": a.name, "description": a.description, "model": a.model}
                        for a in cap.agents
                    ],
                    "components": cap.components,
                })
        except Exception:
            pass

        self._installed_items = sorted(items, key=lambda i: i["name"])

    async def _fetch_available(self) -> None:
        org_items: list[dict[str, t.Any]] = []
        public_items: list[dict[str, t.Any]] = []

        if self._has_platform:
            assert self._api is not None
            assert self._org is not None

            try:
                org_caps = await asyncio.to_thread(self._api.list_capabilities, self._org)
                for cap in org_caps.get("items", []):
                    name = cap.get("name", "?")
                    org_items.append({
                        "row_key": f"org:{name}",
                        "name": name,
                        "summary": cap.get("description") or cap.get("summary") or "",
                        "description": cap.get("description") or cap.get("summary") or "",
                        "source": "org",
                        "version": cap.get("version", ""),
                        "author": cap.get("author"),
                        "versions": cap.get("versions", []),
                        "component_counts": cap.get("component_counts", {}),
                        "component_details": cap.get("component_details", []),
                    })
            except Exception:
                pass

            try:
                public_caps = await asyncio.to_thread(self._api.list_public_capabilities)
                for cap in public_caps.get("items", []):
                    name = cap.get("name", "?")
                    public_items.append({
                        "row_key": f"public:{name}",
                        "name": name,
                        "summary": cap.get("description") or cap.get("summary") or "",
                        "description": cap.get("description") or cap.get("summary") or "",
                        "source": "public",
                        "version": cap.get("version", ""),
                        "author": cap.get("author"),
                        "versions": cap.get("versions", []),
                        "component_counts": cap.get("component_counts", {}),
                        "component_details": cap.get("component_details", []),
                    })
            except Exception:
                pass

        items = _merge_available_sources(org_items, public_items)

        # Derive install state
        installed_by_name: dict[str, dict[str, t.Any]] = {}
        for inst in self._installed_items:
            for key in (inst.get("canonical_name"), inst.get("display_name"), inst.get("name")):
                if isinstance(key, str) and key:
                    installed_by_name.setdefault(key, inst)

        filtered_items: list[dict[str, t.Any]] = []
        for item in items:
            inst = installed_by_name.get(item["name"])
            if inst is None:
                item["install_state"] = "install"
                item["binding_id"] = None
            elif not inst.get("enabled", True):
                item["install_state"] = "disabled"
                item["binding_id"] = inst.get("binding_id")
            else:
                item["install_state"] = _version_cmp(item.get("version"), inst.get("version"))
                item["binding_id"] = inst.get("binding_id")
            if item["install_state"] in {"installed", "disabled"}:
                continue
            filtered_items.append(item)

        self._available_items = sorted(filtered_items, key=lambda i: i["name"])

    # ── Feedback ──────────────────────────────────────────────────────────

    def _show_action_notice(self, name: str, verb: str) -> None:
        """Show immediate feedback for an in-progress action.

        Called synchronously on the UI thread before dispatching the worker.
        """
        scope = "project" if self._is_sandbox else "locally"
        message = f"{verb} {scope}..."
        if self._view == "detail" and self._selected_item and self._selected_item.get("name") == name:
            self._detail_notice = (message, "info")
            self._render_current_view()
        else:
            self.notify(message)

    # ── Action execution ─────────────────────────────────────────────────

    def _execute_action(self, action_id: str) -> None:
        if self._selected_item is None or action_id == "noop":
            return

        item = self._selected_item
        if action_id == "toggle":
            if item.get("source") == "project" and item.get("binding_id"):
                new_enabled = item.get("state") != "enabled"
                self._do_toggle(item["binding_id"], enabled=new_enabled)
            elif item.get("source") in ("local", "package"):
                new_enabled = item.get("state") != "enabled"
                self._do_toggle_local(item["name"], enabled=new_enabled)
        elif action_id == "remove":
            if item.get("binding_id"):
                self._do_remove(item["binding_id"], item["name"])
        elif action_id == "remove_local":
            self._do_remove_local(item["name"])
        elif action_id == "install":
            self._show_action_notice(item["name"], "Installing")
            self._do_install(item["name"], item.get("version"))
        elif action_id == "overwrite_install":
            self._show_action_notice(item["name"], "Installing")
            self._do_install(item["name"], item.get("version"), overwrite=True)
        elif action_id == "cancel_overwrite":
            self._pending_local_overwrite_key = None
            self._detail_notice = None
            self._action_cursor = 0
            self._render_current_view()
        elif action_id == "update":
            if item.get("binding_id"):
                self._show_action_notice(item["name"], "Updating")
                self._do_update(item["binding_id"], item["name"], item.get("version"))

    # ── Platform operations ──────────────────────────────────────────────

    @work(exclusive=True, group="cap-action")
    async def _do_toggle(self, binding_id: str, *, enabled: bool) -> None:
        if not (self._api and self._org and self._workspace and self._project):
            self.notify("No project selected — cannot toggle workspace capability", severity="warning")
            return
        try:
            await asyncio.to_thread(
                self._api.toggle_project_capability,
                self._org, self._workspace, self._project,
                binding_id, enabled=enabled,
            )
            await self._runtime_client.reload_capabilities()
        except Exception as exc:
            self.notify(f"Toggle failed: {exc}", severity="error")
        self._load_data()

    @work(exclusive=True, group="cap-action")
    async def _do_install(self, name: str, version: str | None, *, overwrite: bool = False) -> None:
        if not (self._api and self._org):
            self.notify("Not authenticated — cannot install capability", severity="warning")
            return
        if version is None:
            self.notify("Capability version unavailable — cannot install", severity="warning")
            return
        try:
            if self._is_sandbox:
                if not (self._workspace and self._project):
                    self.notify("No project selected — cannot install capability", severity="warning")
                    return
                await asyncio.to_thread(
                    self._api.install_project_capability,
                    self._org, self._workspace, self._project,
                    name=name, version=version,
                )
            else:
                from dreadnode.storage.storage import Storage

                storage = Storage()
                installer = LocalInstallClient(
                    api=self._api,
                    org=self._org,
                    local_dir=storage.capabilities_path,
                    state_path=storage.local_capability_state_path,
                )
                source = "public" if "/" in name else "org"
                await installer.install(
                    name=name,
                    version=version,
                    source=source,
                    overwrite=overwrite,
                )
                self._pending_local_overwrite_key = None
                self._detail_notice = ("Installed locally.", "success")
                if self._selected_item is not None and self._selected_item.get("name") == name:
                    self._selected_item = {
                        **self._selected_item,
                        "install_state": "installed",
                    }
            await self._runtime_client.reload_capabilities()
        except FileExistsError:
            if not self._is_sandbox and self._selected_item is not None and self._selected_item.get("name") == name:
                self._pending_local_overwrite_key = t.cast(str | None, self._selected_item.get("row_key"))
                self._detail_notice = ("Capability already exists locally.", "warning")
                self._action_cursor = 0
                self._render_current_view()
                return
            self.notify("Capability already exists locally.", severity="warning")
        except Exception as exc:
            self.notify(f"Install failed: {exc}", severity="error")
        self._load_data()

    @work(exclusive=True, group="cap-action")
    async def _do_update(self, binding_id: str, name: str, version: str | None) -> None:
        if not (self._api and self._org and self._workspace and self._project):
            self.notify("No project selected — cannot update capability", severity="warning")
            return
        if not version:
            return
        try:
            await asyncio.to_thread(
                self._api.update_project_capability,
                self._org, self._workspace, self._project,
                binding_id, version=version,
            )
            await self._runtime_client.reload_capabilities()
        except Exception as exc:
            self.notify(f"Update failed: {exc}", severity="error")
        self._load_data()

    @work(exclusive=True, group="cap-action")
    async def _do_toggle_local(self, name: str, *, enabled: bool) -> None:
        from dreadnode.capabilities.capability import (
            read_local_capability_state,
            write_local_capability_state,
        )
        from dreadnode.storage.storage import Storage

        state_path = Storage().local_capability_state_path
        state = read_local_capability_state(state_path)
        state[name] = enabled
        write_local_capability_state(state_path, state)
        if self._selected_item is not None and self._selected_item.get("name") == name:
            self._selected_item = {**self._selected_item, "state": "enabled" if enabled else "disabled"}
            self._detail_notice = (
                ("Capability enabled.", "success") if enabled else ("Capability disabled.", "success")
            )

        await self._runtime_client.reload_capabilities()
        self._load_data()

    @work(exclusive=True, group="cap-action")
    async def _do_remove_local(self, name: str) -> None:
        import shutil

        from dreadnode.capabilities.capability import (
            read_local_capability_state,
            write_local_capability_state,
        )
        from dreadnode.storage.storage import Storage

        storage = Storage()

        # Remove from local state file
        state_path = storage.local_capability_state_path
        state = read_local_capability_state(state_path)
        state.pop(name, None)
        write_local_capability_state(state_path, state)

        # Remove the capability directory from disk
        cap_dir = storage.capabilities_path / name
        if cap_dir.is_dir():
            await asyncio.to_thread(shutil.rmtree, cap_dir)

        await self._runtime_client.reload_capabilities()
        self._back_to_list()
        self._load_data()

    @work(exclusive=True, group="cap-action")
    async def _do_remove(self, binding_id: str, name: str) -> None:
        if not (self._api and self._org and self._workspace and self._project):
            self.notify("No project selected — cannot remove capability", severity="warning")
            return
        try:
            await asyncio.to_thread(
                self._api.uninstall_project_capability,
                self._org, self._workspace, self._project,
                binding_id,
            )
            await self._runtime_client.reload_capabilities()
        except Exception as exc:
            self.notify(f"Remove failed: {exc}", severity="error")
        self._load_data()
