"""Hub screen -- browse datasets, models, tasks, and capabilities."""

from __future__ import annotations

import asyncio
import typing as t
from datetime import datetime

from textual import on, work
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.widgets import DataTable, Static, Tree

from dreadnode.app.tui.screens.base import DreadnodeScreen

from dreadnode.app.api.client import ApiClient
from dreadnode.app.api.models import Package
from dreadnode.app.tui.theme import BRAND, ERROR, FG, FG_SUBTLE, INFO, SUCCESS


def _fmt_timestamp(ts: str | datetime | None) -> str:
    if ts is None:
        return "-"
    if isinstance(ts, str):
        return ts[:19]
    return ts.strftime("%Y-%m-%d %H:%M:%S")


class HubScreen(DreadnodeScreen):
    """Catalog browser for reusable platform assets."""

    BINDINGS = [
        Binding("escape", "go_back", "Back", show=True),
        Binding("j", "cursor_down", "Down", show=False),
        Binding("k", "cursor_up", "Up", show=False),
        Binding("r", "refresh_hub", "Refresh", show=True),
    ]

    def __init__(self, api: ApiClient, org: str, **kwargs: t.Any) -> None:
        super().__init__(**kwargs)
        self._api = api
        self._org = org
        self._items: list[dict[str, t.Any]] = []

    def compose_content(self) -> ComposeResult:
        yield Static(
            f"[bold {BRAND}]Hub[/] [{FG_SUBTLE}]{self._org}[/]",
            id="hub-title",
        )
        with Horizontal(id="hub-body"):
            with Vertical(id="hub-left"):
                yield DataTable(id="hub-table")
            with Vertical(id="hub-right"):
                yield Tree("Detail", id="hub-detail")

    def on_mount(self) -> None:
        super().on_mount()
        table = self.query_one("#hub-table", DataTable)
        table.cursor_type = "row"
        table.zebra_stripes = True
        table.add_columns("Kind", "Name", "Version", "Visibility", "Summary")
        self._load_hub()

    def action_go_back(self) -> None:
        self.dismiss()

    def action_cursor_down(self) -> None:
        self.query_one("#hub-table", DataTable).action_cursor_down()

    def action_cursor_up(self) -> None:
        self.query_one("#hub-table", DataTable).action_cursor_up()

    def action_refresh_hub(self) -> None:
        self._load_hub()

    def _flash_title(self, message: str, colour: str = FG_SUBTLE) -> None:
        self.query_one("#hub-title", Static).update(
            f"[bold {BRAND}]Hub[/] [{colour}]{message}[/]"
        )

    @work(exclusive=True, group="hub")
    async def _load_hub(self) -> None:
        table = self.query_one("#hub-table", DataTable)
        table.clear()
        self._flash_title(f"{self._org} \u00b7 loading...")

        try:
            datasets, models, tasks, capabilities = await asyncio.gather(
                asyncio.to_thread(self._api.list_datasets, self._org),
                asyncio.to_thread(self._api.list_models, self._org),
                asyncio.to_thread(self._api.list_tasks, self._org),
                asyncio.to_thread(self._api.list_capabilities, self._org),
            )
        except Exception as exc:
            self._flash_title(f"Error: {exc}", ERROR)
            return

        items: list[dict[str, t.Any]] = []
        items.extend(self._from_packages("dataset", datasets))
        items.extend(self._from_packages("model", models))
        items.extend(self._from_tasks(tasks))
        items.extend(self._from_capabilities(capabilities))
        self._items = items

        if not self._items:
            self._flash_title(f"{self._org} \u00b7 no assets found")
            self._clear_detail()
            return

        for item in self._items:
            summary = (item.get("summary") or "").strip()[:40]
            table.add_row(
                str(item.get("kind", "?")),
                str(item.get("name", "?")),
                str(item.get("version", "-")),
                str(item.get("visibility", "-")),
                summary,
                key=str(item.get("row_key")),
            )

        self._flash_title(f"{self._org} \u00b7 {len(self._items)} assets")
        self._show_item_detail(self._items[0])

    def _from_packages(self, kind: str, packages: list[Package]) -> list[dict[str, t.Any]]:
        items: list[dict[str, t.Any]] = []
        for package in packages:
            items.append(
                {
                    "row_key": f"{kind}:{package.name}",
                    "kind": kind,
                    "name": package.name,
                    "version": package.latest_version or "-",
                    "visibility": package.visibility,
                    "summary": package.summary or "",
                    "created_at": package.created_at,
                    "updated_at": package.updated_at,
                    "full_name": package.full_name,
                    "raw": package,
                }
            )
        return items

    def _from_tasks(self, payload: dict[str, t.Any]) -> list[dict[str, t.Any]]:
        tasks = payload.get("tasks", [])
        items: list[dict[str, t.Any]] = []
        for task in tasks:
            items.append(
                {
                    "row_key": f"task:{task.get('name', '?')}",
                    "kind": "task",
                    "name": task.get("name", "?"),
                    "version": task.get("version", "-"),
                    "visibility": "public" if task.get("is_public") else "private",
                    "summary": task.get("category") or task.get("difficulty") or "",
                    "created_at": task.get("created_at"),
                    "raw": task,
                }
            )
        return items

    def _from_capabilities(self, payload: dict[str, t.Any]) -> list[dict[str, t.Any]]:
        capabilities = payload.get("items", [])
        items: list[dict[str, t.Any]] = []
        for capability in capabilities:
            items.append(
                {
                    "row_key": f"capability:{capability.get('name', '?')}:{capability.get('version', '-')}",
                    "kind": "capability",
                    "name": capability.get("name", "?"),
                    "version": capability.get("version", "-"),
                    "visibility": "public" if capability.get("is_public") else "private",
                    "summary": capability.get("summary") or "",
                    "created_at": capability.get("created_at"),
                    "raw": capability,
                }
            )
        return items

    @on(DataTable.RowHighlighted, "#hub-table")
    def _on_item_highlighted(self, event: DataTable.RowHighlighted) -> None:
        if event.row_key is None:
            return
        row_key = str(event.row_key.value)
        for item in self._items:
            if str(item.get("row_key")) == row_key:
                self._show_item_detail(item)
                break

    def _clear_detail(self) -> None:
        detail = self.query_one("#hub-detail", Tree)
        detail.clear()
        detail.root.set_label("[dim]No asset selected[/]")

    def _show_item_detail(self, item: dict[str, t.Any]) -> None:
        detail = self.query_one("#hub-detail", Tree)
        detail.clear()
        detail.root.set_label(f"[bold]{item.get('kind', 'asset').title()}: {item.get('name', '?')}[/]")

        info = detail.root.add("Info", expand=True)
        info.add_leaf(f"Name: [{FG}]{item.get('name', 'n/a')}[/]")
        info.add_leaf(f"Version: [{FG}]{item.get('version', 'n/a')}[/]")
        info.add_leaf(f"Visibility: [{FG_SUBTLE}]{item.get('visibility', 'n/a')}[/]")
        info.add_leaf(f"Summary: [{FG_SUBTLE}]{item.get('summary') or 'n/a'}[/]")

        raw = item.get("raw", {})
        metadata = detail.root.add("Metadata", expand=True)
        if isinstance(raw, Package):
            metadata.add_leaf(f"Full Name: [{FG_SUBTLE}]{raw.full_name}[/]")
            metadata.add_leaf(f"Package Type: [{FG_SUBTLE}]{raw.package_type or raw.type or item.get('kind', 'n/a')}[/]")
            metadata.add_leaf(f"Created: [{FG_SUBTLE}]{_fmt_timestamp(raw.created_at)}[/]")
            metadata.add_leaf(f"Updated: [{FG_SUBTLE}]{_fmt_timestamp(raw.updated_at)}[/]")
        elif isinstance(raw, dict):
            for key in ("category", "difficulty", "author_name", "template_status", "created_at"):
                value = raw.get(key)
                if value:
                    metadata.add_leaf(f"{key}: [{FG_SUBTLE}]{value}[/]")

        detail.root.expand()
