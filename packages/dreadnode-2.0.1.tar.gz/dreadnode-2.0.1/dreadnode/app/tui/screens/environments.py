"""Environments Browser screen -- browse and inspect platform environments."""

from __future__ import annotations

import asyncio
import typing as t
from datetime import datetime

from textual import on, work
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.screen import Screen
from textual.widgets import DataTable, Footer, Static, Tree

from dreadnode.app.api.client import ApiClient
from dreadnode.app.tui.theme import BRAND, ERROR, FG, FG_SUBTLE


def _fmt_timestamp(ts: str | datetime | None) -> str:
    """Format an ISO timestamp for display."""
    if ts is None:
        return "-"
    if isinstance(ts, str):
        try:
            dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        except ValueError:
            return ts[:19]
    else:
        dt = ts
    return dt.strftime("%Y-%m-%d %H:%M:%S")


def _fmt_visibility(is_public: bool | None) -> str:
    return "public" if is_public else "private"


def _fmt_template_status(status: str | None) -> str:
    return status if status else "n/a"


def _fmt_tags(tags: t.Any) -> str:
    if isinstance(tags, list):
        cleaned = [str(tag) for tag in tags if tag]
        return ", ".join(cleaned) if cleaned else "n/a"
    if isinstance(tags, str) and tags.strip():
        return tags
    return "n/a"


def _fmt_file_size(size: t.Any) -> str:
    if size is None:
        return "n/a"
    if isinstance(size, str):
        try:
            size = float(size)
        except ValueError:
            return size
    if not isinstance(size, (int, float)):
        return "n/a"
    if size < 1024:
        return f"{int(size)} B"
    if size < 1024**2:
        return f"{size / 1024:.1f} KB"
    if size < 1024**3:
        return f"{size / 1024**2:.1f} MB"
    return f"{size / 1024**3:.1f} GB"


class EnvironmentScreen(Screen[None]):
    """Browser for environments (legacy tasks)."""

    BINDINGS = [
        Binding("escape", "go_back", "Back", show=True),
        Binding("down", "cursor_down", show=False),
        Binding("up", "cursor_up", show=False),
        Binding("j", "cursor_down", "Down", show=False),
        Binding("k", "cursor_up", "Up", show=False),
        Binding("r", "refresh_environments", "Refresh", show=True),
        Binding("n", "next_page", "Next", show=True),
        Binding("p", "prev_page", "Prev", show=True),
    ]

    def __init__(
        self,
        api: ApiClient,
        org: str,
        workspace: str | None = None,
        **kwargs: t.Any,
    ) -> None:
        super().__init__(**kwargs)
        self._api = api
        self._org = org
        self._workspace = workspace
        self._environments: list[dict[str, t.Any]] = []
        self._page = 1
        self._total_pages = 1
        self._has_next = False
        self._has_previous = False
        self._total = 0
        self._limit = 50

    def compose(self) -> ComposeResult:
        yield Static(
            f"[bold {BRAND}]Environments[/] [{FG_SUBTLE}]{self._org}[/]",
            id="environments-title",
        )
        with Horizontal(id="environments-body"):
            with Vertical(id="environments-left"):
                yield DataTable(id="environments-table")
                yield Static("", id="environments-pagination")
            with Vertical(id="environments-right"):
                yield Tree("Detail", id="environments-detail")
        yield Footer()

    def on_mount(self) -> None:
        table = self.query_one("#environments-table", DataTable)
        table.cursor_type = "row"
        table.zebra_stripes = True
        table.add_columns(
            "Name",
            "Version",
            "Category",
            "Difficulty",
            "Visibility",
            "Template",
            "Created",
        )
        self._load_environments(self._page)

    def action_go_back(self) -> None:
        self.dismiss()

    def action_cursor_down(self) -> None:
        self.query_one("#environments-table", DataTable).action_cursor_down()

    def action_cursor_up(self) -> None:
        self.query_one("#environments-table", DataTable).action_cursor_up()

    def action_refresh_environments(self) -> None:
        self._load_environments(self._page)

    def action_next_page(self) -> None:
        if not self._has_next:
            return
        self._load_environments(self._page + 1)

    def action_prev_page(self) -> None:
        if not self._has_previous:
            return
        self._load_environments(self._page - 1)

    def _flash_title(self, message: str, colour: str = FG_SUBTLE) -> None:
        self.query_one("#environments-title", Static).update(
            f"[bold {BRAND}]Environments[/] [{colour}]{message}[/]"
        )

    def _update_pagination(self) -> None:
        label = (
            f"Page {self._page}/{self._total_pages} \u00b7 "
            f"{self._total} environment{'s' if self._total != 1 else ''}"
        )
        self.query_one("#environments-pagination", Static).update(label)

    @work(exclusive=True, group="environments")
    async def _load_environments(self, page: int) -> None:
        table = self.query_one("#environments-table", DataTable)
        table.clear()
        self._flash_title(f"{self._org} \u00b7 loading page {page}...")

        try:
            tasks_data = await asyncio.to_thread(
                self._api.list_tasks,
                self._org,
                page=page,
                limit=self._limit,
            )
        except Exception as exc:
            self._flash_title(f"Error: {exc}", ERROR)
            return

        tasks = tasks_data.get("tasks", [])
        self._page = int(tasks_data.get("page", page) or page)
        self._total = int(tasks_data.get("total", len(tasks)) or len(tasks))
        total_pages_raw = tasks_data.get("total_pages")
        total_pages = None
        if isinstance(total_pages_raw, int):
            total_pages = total_pages_raw
        elif isinstance(total_pages_raw, str) and total_pages_raw.isdigit():
            total_pages = int(total_pages_raw)
        if total_pages is None or total_pages < 1:
            total_pages = max(1, (self._total + self._limit - 1) // self._limit)
        self._total_pages = total_pages
        self._has_next = bool(tasks_data.get("has_next", False))
        self._has_previous = bool(tasks_data.get("has_previous", False))

        self._environments = self._from_tasks(tasks)
        self._update_pagination()

        if not self._environments:
            self._flash_title(f"{self._org} \u00b7 no environments found")
            self._clear_detail()
            return

        for env in self._environments:
            table.add_row(
                str(env.get("name", "?")),
                str(env.get("version", "-")),
                str(env.get("category", "-")),
                str(env.get("difficulty", "-")),
                str(env.get("visibility", "-")),
                str(env.get("template_status", "-")),
                str(env.get("created", "-")),
                key=str(env.get("row_key")),
            )

        self._flash_title(
            f"{self._org} \u00b7 {self._total} environment{'s' if self._total != 1 else ''}"
        )
        self._show_environment_detail(self._environments[0])

    def _from_tasks(
        self,
        tasks: list[dict[str, t.Any]],
    ) -> list[dict[str, t.Any]]:
        items: list[dict[str, t.Any]] = []
        for task in tasks:
            created_at = task.get("created_at")
            template_status = _fmt_template_status(task.get("template_status"))
            name = task.get("name", "?")
            items.append(
                {
                    "row_key": name,
                    "name": name,
                    "version": task.get("version", "-"),
                    "category": task.get("category") or "-",
                    "difficulty": task.get("difficulty") or "-",
                    "visibility": _fmt_visibility(task.get("is_public")),
                    "template_status": template_status,
                    "created": _fmt_timestamp(created_at),
                    "raw": task,
                }
            )
        return items

    @on(DataTable.RowHighlighted, "#environments-table")
    def _on_environment_highlighted(self, event: DataTable.RowHighlighted) -> None:
        if event.row_key is None:
            return
        row_key = str(event.row_key.value)
        for env in self._environments:
            if str(env.get("row_key")) == row_key:
                self._show_environment_detail(env)
                break

    def _clear_detail(self) -> None:
        detail = self.query_one("#environments-detail", Tree)
        detail.clear()
        detail.root.set_label("[dim]No environment selected[/]")

    def _show_environment_detail(self, env: dict[str, t.Any]) -> None:
        detail = self.query_one("#environments-detail", Tree)
        detail.clear()

        detail.root.set_label(f"[bold]Environment: {env.get('name', 'unknown')}[/]")

        raw = env.get("raw", {})
        info = detail.root.add("Info", expand=True)
        info.add_leaf(f"Name: [{FG}]{env.get('name', 'n/a')}[/]")
        info.add_leaf(f"Version: [{FG}]{env.get('version', 'n/a')}[/]")
        info.add_leaf(f"Category: [{FG_SUBTLE}]{env.get('category', 'n/a')}[/]")
        info.add_leaf(f"Difficulty: [{FG_SUBTLE}]{env.get('difficulty', 'n/a')}[/]")
        info.add_leaf(f"Visibility: [{FG_SUBTLE}]{env.get('visibility', 'n/a')}[/]")

        metadata = detail.root.add("Metadata", expand=True)
        if isinstance(raw, dict):
            author = raw.get("author_name") or "n/a"
            tags = _fmt_tags(raw.get("tags"))
            template_status = _fmt_template_status(raw.get("template_status"))
            file_size = _fmt_file_size(
                raw.get("file_size_bytes") or raw.get("file_size") or raw.get("size_bytes")
            )
            created = _fmt_timestamp(raw.get("created_at"))

            metadata.add_leaf(f"Author: [{FG_SUBTLE}]{author}[/]")
            metadata.add_leaf(f"Tags: [{FG_SUBTLE}]{tags}[/]")
            metadata.add_leaf(f"Template Status: [{FG_SUBTLE}]{template_status}[/]")
            metadata.add_leaf(f"File Size: [{FG_SUBTLE}]{file_size}[/]")
            metadata.add_leaf(f"Created: [{FG_SUBTLE}]{created}[/]")

        detail.root.expand()

    def _selected_environment(self) -> dict[str, t.Any] | None:
        table = self.query_one("#environments-table", DataTable)
        if table.cursor_row is None:
            return None
        try:
            row_key = table.coordinate_to_cell_key((table.cursor_row, 0)).row_key
        except Exception:
            return None
        if row_key is None:
            return None
        key = str(row_key.value)
        for env in self._environments:
            if str(env.get("row_key")) == key:
                return env
        return None
