"""Runtimes Browser screen -- interactive workspace runtimes."""

from __future__ import annotations

import asyncio
import typing as t
from datetime import datetime, timezone

from textual import on, work
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.timer import Timer
from textual.widgets import DataTable, Static, Tree

from dreadnode.app.tui.screens.base import DreadnodeScreen

from dreadnode.app.api.client import ApiClient
from dreadnode.app.tui.theme import BRAND, ERROR, FG, FG_SUBTLE, INFO, SUCCESS, WARNING

_STATUS_DOT: dict[str, str] = {
    "running": f"[{SUCCESS}]\u25cf[/]",
    "paused": f"[{WARNING}]\u25cf[/]",
    "killed": f"[{ERROR}]\u25cf[/]",
}


def _status_dot(state: str) -> str:
    return _STATUS_DOT.get(state, f"[{FG_SUBTLE}]\u25cf[/]")


def _fmt_runtime(seconds: int) -> str:
    if seconds < 60:
        return f"{seconds}s"
    minutes = seconds // 60
    secs = seconds % 60
    if minutes < 60:
        return f"{minutes}m{secs:02d}s"
    hours = minutes // 60
    mins = minutes % 60
    return f"{hours}h{mins:02d}m"


def _fmt_timestamp(ts: str | datetime | None) -> str:
    if ts is None:
        return "-"
    if isinstance(ts, str):
        try:
            dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        except ValueError:
            return ts[:19]
    else:
        dt = ts
    return dt.strftime("%Y-%m-%d %H:%M:%S")


def _time_until(ts: str | datetime | None) -> str:
    if ts is None:
        return "-"
    if isinstance(ts, str):
        try:
            dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        except ValueError:
            return ts[:19]
    else:
        dt = ts
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    now = datetime.now(tz=timezone.utc)
    delta = int((dt - now).total_seconds())
    if delta <= 0:
        return "expired"
    if delta < 60:
        return f"{delta}s"
    minutes = delta // 60
    secs = delta % 60
    if minutes < 60:
        return f"{minutes}m{secs:02d}s"
    hours = minutes // 60
    mins = minutes % 60
    return f"{hours}h{mins:02d}m"


class RuntimeScreen(DreadnodeScreen):
    """Live-updating view of workspace interactive runtimes."""

    BINDINGS = [
        Binding("escape", "go_back", "Back", show=True),
        Binding("j", "cursor_down", "Down", show=False),
        Binding("k", "cursor_up", "Up", show=False),
        Binding("r", "refresh_runtimes", "Refresh", show=True),
        Binding("p", "pause_runtime", "Pause", show=True),
        Binding("u", "resume_runtime", "Resume", show=True),
        Binding("d", "delete_runtime", "Delete", show=True),
        Binding("a", "keepalive_runtime", "Keepalive", show=True),
    ]

    def __init__(self, api: ApiClient, org: str, workspace: str, **kwargs: t.Any) -> None:
        super().__init__(**kwargs)
        self._api = api
        self._org = org
        self._workspace = workspace
        self._runtimes: list[dict[str, t.Any]] = []
        self._refresh_timer: Timer | None = None

    def compose_content(self) -> ComposeResult:
        yield Static(
            f"[bold {BRAND}]Runtimes[/] [{FG_SUBTLE}]{self._workspace}[/]",
            id="runtime-title",
        )
        with Horizontal(id="runtime-body"):
            with Vertical(id="runtime-left"):
                yield DataTable(id="runtime-table")
            with Vertical(id="runtime-right"):
                yield Tree("Detail", id="runtime-detail")

    def on_mount(self) -> None:
        super().on_mount()
        table = self.query_one("#runtime-table", DataTable)
        table.cursor_type = "row"
        table.zebra_stripes = True
        table.add_columns("", "Runtime ID", "Provider", "State", "Runtime", "Expires", "Project")
        self._load_runtimes()
        self._refresh_timer = self.set_interval(10.0, self._load_runtimes)

    def action_go_back(self) -> None:
        if self._refresh_timer is not None:
            self._refresh_timer.stop()
        self.dismiss()

    def action_cursor_down(self) -> None:
        self.query_one("#runtime-table", DataTable).action_cursor_down()

    def action_cursor_up(self) -> None:
        self.query_one("#runtime-table", DataTable).action_cursor_up()

    def action_refresh_runtimes(self) -> None:
        self._load_runtimes()

    def action_pause_runtime(self) -> None:
        runtime_id = self._selected_runtime_id()
        if runtime_id:
            self._do_pause(runtime_id)

    def action_resume_runtime(self) -> None:
        runtime_id = self._selected_runtime_id()
        if runtime_id:
            self._do_resume(runtime_id)

    def action_delete_runtime(self) -> None:
        runtime_id = self._selected_runtime_id()
        if runtime_id:
            self._do_delete(runtime_id)

    def action_keepalive_runtime(self) -> None:
        runtime_id = self._selected_runtime_id()
        if runtime_id:
            self._do_keepalive(runtime_id)

    def _selected_runtime_id(self) -> str | None:
        table = self.query_one("#runtime-table", DataTable)
        if table.cursor_row is None:
            return None
        try:
            row_key = table.coordinate_to_cell_key((table.cursor_row, 0)).row_key
            return str(row_key.value) if row_key else None
        except Exception:
            return None

    def _flash_title(self, message: str, colour: str = FG_SUBTLE) -> None:
        self.query_one("#runtime-title", Static).update(
            f"[bold {BRAND}]Runtimes[/] [{colour}]{message}[/]"
        )

    @work(exclusive=True, group="runtimes")
    async def _load_runtimes(self) -> None:
        table = self.query_one("#runtime-table", DataTable)
        table.clear()
        self._flash_title(f"{self._workspace} \u00b7 loading...")
        try:
            data = await asyncio.to_thread(
                self._api.list_runtimes,
                self._org,
                self._workspace,
                state="running,paused,killed",
                limit=50,
            )
            self._runtimes = data.get("items", [])
        except Exception as exc:
            self._flash_title(f"Error: {exc}", ERROR)
            return

        if not self._runtimes:
            self._flash_title(f"{self._workspace} \u00b7 no runtimes found")
            self._clear_detail()
            return

        for runtime in self._runtimes:
            state = runtime.get("state", "unknown")
            runtime_id = str(runtime.get("id", "?"))
            table.add_row(
                _status_dot(state),
                runtime_id[:8],
                runtime.get("provider", "?"),
                state,
                _fmt_runtime(int(runtime.get("total_runtime_seconds", 0))),
                _time_until(runtime.get("expires_at")),
                runtime.get("project_key") or runtime.get("project_name") or "-",
                key=runtime_id,
            )

        total = len(self._runtimes)
        self._flash_title(
            f"{self._workspace} \u00b7 {total} runtime{'s' if total != 1 else ''}"
        )
        self._show_runtime_detail(self._runtimes[0])

    @on(DataTable.RowHighlighted, "#runtime-table")
    def _on_runtime_highlighted(self, event: DataTable.RowHighlighted) -> None:
        if event.row_key is None:
            return
        runtime_id = str(event.row_key.value)
        for runtime in self._runtimes:
            if str(runtime.get("id", "")) == runtime_id:
                self._show_runtime_detail(runtime)
                break

    def _clear_detail(self) -> None:
        detail = self.query_one("#runtime-detail", Tree)
        detail.clear()
        detail.root.set_label("[dim]No runtime selected[/]")

    def _show_runtime_detail(self, runtime: dict[str, t.Any]) -> None:
        detail = self.query_one("#runtime-detail", Tree)
        detail.clear()
        runtime_id = str(runtime.get("id", "unknown"))
        detail.root.set_label(f"[bold]Runtime: {runtime_id}[/]")

        info = detail.root.add("Info", expand=True)
        info.add_leaf(f"ID: [{FG_SUBTLE}]{runtime_id}[/]")
        info.add_leaf(f"Provider: [{FG_SUBTLE}]{runtime.get('provider', 'n/a')}[/]")
        info.add_leaf(f"State: [{FG_SUBTLE}]{runtime.get('state', 'n/a')}[/]")
        info.add_leaf(f"Build Ref: [{FG_SUBTLE}]{runtime.get('build_ref', 'n/a')}[/]")

        timing = detail.root.add("Timing", expand=True)
        timing.add_leaf(f"Created: [{FG_SUBTLE}]{_fmt_timestamp(runtime.get('created_at'))}[/]")
        timing.add_leaf(f"Expires: [{FG_SUBTLE}]{_fmt_timestamp(runtime.get('expires_at'))}[/]")
        timing.add_leaf(f"Runtime: [{FG}]{_fmt_runtime(int(runtime.get('total_runtime_seconds', 0)))}[/]")

        grouping = detail.root.add("Grouping", expand=True)
        grouping.add_leaf(
            f"Project: [{FG_SUBTLE}]{runtime.get('project_key') or runtime.get('project_name') or 'n/a'}[/]"
        )
        grouping.add_leaf(f"Workspace: [{FG_SUBTLE}]{runtime.get('workspace_key', self._workspace)}[/]")

        cost = detail.root.add("Credits", expand=True)
        cost.add_leaf(f"Billed: [{FG}]{runtime.get('billed_credits', 0)}[/]")
        cost.add_leaf(f"Running: [{FG}]{runtime.get('running_credits', 0)}[/]")
        cost.add_leaf(f"Est. Total: [{FG}]{runtime.get('estimated_total_credits', 0)}[/]")

        detail.root.expand()

    @work(exclusive=True, group="runtime-action")
    async def _do_pause(self, runtime_id: str) -> None:
        self._flash_title(f"Pausing {runtime_id[:8]}...", WARNING)
        try:
            await asyncio.to_thread(self._api.pause_runtime, self._org, self._workspace, runtime_id)
            self._flash_title(f"Paused {runtime_id[:8]}", SUCCESS)
        except Exception as exc:
            self._flash_title(f"Pause failed: {exc}", ERROR)
        self._load_runtimes()

    @work(exclusive=True, group="runtime-action")
    async def _do_resume(self, runtime_id: str) -> None:
        self._flash_title(f"Resuming {runtime_id[:8]}...", INFO)
        try:
            await asyncio.to_thread(self._api.resume_runtime, self._org, self._workspace, runtime_id)
            self._flash_title(f"Resumed {runtime_id[:8]}", SUCCESS)
        except Exception as exc:
            self._flash_title(f"Resume failed: {exc}", ERROR)
        self._load_runtimes()

    @work(exclusive=True, group="runtime-action")
    async def _do_delete(self, runtime_id: str) -> None:
        self._flash_title(f"Deleting {runtime_id[:8]}...", ERROR)
        try:
            await asyncio.to_thread(self._api.delete_runtime, self._org, self._workspace, runtime_id)
            self._flash_title(f"Deleted {runtime_id[:8]}", SUCCESS)
        except Exception as exc:
            self._flash_title(f"Delete failed: {exc}", ERROR)
        self._load_runtimes()

    @work(exclusive=True, group="runtime-action")
    async def _do_keepalive(self, runtime_id: str) -> None:
        self._flash_title(f"Extending {runtime_id[:8]}...", INFO)
        try:
            await asyncio.to_thread(
                self._api.keepalive_runtime,
                self._org,
                self._workspace,
                runtime_id,
                extend_seconds=300,
            )
            self._flash_title(f"Extended {runtime_id[:8]} by 5 min", SUCCESS)
        except Exception as exc:
            self._flash_title(f"Keepalive failed: {exc}", ERROR)
        self._load_runtimes()
