"""Inline model picker overlay for the Dreadnode TUI.

Renders as an OptionList above the composer (same pattern as SlashOverlay),
toggled visible/hidden via CSS class. The composer routes arrow keys to it
when active.
"""

from __future__ import annotations

from rich.text import Text
from textual.message import Message
from textual.widgets import OptionList
from textual.widgets.option_list import Option

from dreadnode.app.tui.model_variants import display_name
from dreadnode.app.tui.theme import FG, FG_FAINTEST, FG_MUTED


def _extract_provider(model_id: str) -> str:
    """Extract provider from model ID (e.g. 'anthropic/claude-opus-4-6' -> 'anthropic')."""
    if "/" in model_id:
        return model_id.split("/")[0]
    return ""


class ModelPickerOverlay(OptionList):
    """Inline overlay for selecting an LLM model."""

    class ModelSelected(Message):
        """Posted when a model is selected."""

        def __init__(self, model_id: str) -> None:
            self.model_id = model_id
            super().__init__()

    def show_models(self, models: list[str], current: str) -> None:
        """Populate the list with dot markers and provider names."""
        self.clear_options()
        current_index = 0
        for i, model_id in enumerate(models):
            label = Text()
            name = display_name(model_id)
            is_current = model_id == current

            # Selection dot
            if is_current:
                label.append("\u25cf ", style=FG)
                current_index = i
            else:
                label.append("\u25cb ", style=FG_FAINTEST)

            # Model name
            label.append(name, style="bold" if is_current else "")

            # Provider on the right
            provider = _extract_provider(model_id)
            if provider:
                label.append(f"  {provider}", style=FG_MUTED)

            self.add_option(Option(label, id=model_id))

        self.highlighted = current_index
        self.add_class("-visible")

    def hide(self) -> None:
        """Hide the overlay."""
        self.remove_class("-visible")

    @property
    def is_visible(self) -> bool:
        return self.has_class("-visible")

    def move_highlight(self, direction: int) -> None:
        """Move the highlight up (-1) or down (+1)."""
        if self.option_count == 0:
            return
        current = self.highlighted or 0
        self.highlighted = max(0, min(current + direction, self.option_count - 1))

    def select_highlighted(self) -> bool:
        """Select the currently highlighted option. Returns True if handled."""
        if not self.is_visible or self.option_count == 0:
            return False
        idx = self.highlighted
        if idx is not None and 0 <= idx < self.option_count:
            option = self.get_option_at_index(idx)
            if option.id:
                self.post_message(self.ModelSelected(option.id))
                self.hide()
                return True
        return False

    def on_option_list_option_selected(self, event: OptionList.OptionSelected) -> None:
        """Handle click/enter on an option."""
        if event.option.id:
            self.post_message(self.ModelSelected(event.option.id))
            self.hide()
