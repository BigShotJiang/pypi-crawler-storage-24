"""Slash commands, auth helpers, and event parsing for the Dreadnode TUI."""

from __future__ import annotations

import contextlib
import json
import re
import typing as t
from dataclasses import dataclass
from pathlib import Path

from dreadnode.app.api.client import ApiClient
from dreadnode.app.server.session import ServerConfig, UserConfig

DEFAULT_PLATFORM_URL = "https://app.dreadnode.io"

_PROFILE_NAME_PATTERN = re.compile(r"^[a-zA-Z0-9_.-]+$")


@dataclass(slots=True)
class SlashCommand:
    """A TUI slash command definition."""

    name: str
    description: str
    hint: str = ""


SLASH_COMMANDS: list[SlashCommand] = [
    SlashCommand("/help", "Show available commands"),
    SlashCommand("/new", "Create a new session"),
    SlashCommand("/reset", "Reset current session"),
    SlashCommand("/sessions", "List all sessions"),
    SlashCommand("/use", "Switch to a session", "<id>"),
    SlashCommand("/delete", "Delete a session", "<id>"),
    SlashCommand("/agents", "List loaded agents"),
    SlashCommand("/agent", "Start agent session", "<name>"),
    SlashCommand("/model", "Get or set model", "[provider/model]"),
    SlashCommand("/reload", "Re-discover capabilities and rebuild registry"),
    SlashCommand("/runtime", "Refresh runtime info"),
    SlashCommand(
        "/login", "Authenticate with platform (restarts runtime)", "[api-key] [--server <url>]"
    ),
    SlashCommand("/logout", "Delete current saved creds and restart local-only"),
    SlashCommand("/whoami", "Show current identity"),
    SlashCommand("/workspace", "View or switch workspace (restarts runtime)", "[key]"),
    SlashCommand("/workspaces", "List workspaces"),
    SlashCommand("/projects", "List projects", "[workspace]"),
    SlashCommand("/models", "Open model picker"),
    SlashCommand("/thinking", "Toggle thinking/reasoning effort", "[on|off|low|medium|high|max]"),
    SlashCommand("/runtimes", "View workspace interactive runtimes"),
    SlashCommand("/rt", "Alias for /runtimes"),
    SlashCommand("/environments", "Browse available environments"),
    SlashCommand("/env", "Alias for /environments"),
    SlashCommand("/hub", "Browse datasets, models, tasks, and capabilities"),
    SlashCommand("/capabilities", "Manage runtime capabilities"),
    SlashCommand("/caps", "Alias for /capabilities"),
    SlashCommand("/mcp", "View MCP server status"),
    SlashCommand("/secrets", "View configured secrets and provider presets"),
    SlashCommand("/sec", "Alias for /secrets"),
    SlashCommand("/rename", "Rename current session", "<title>"),
    SlashCommand("/tools", "Set tool details mode", "<compact|expanded>"),
    SlashCommand("/export", "Export session transcript", "[filename]"),
    SlashCommand("/traces", "Browse traces for current project"),
    SlashCommand("/sandboxes", "Monitor your sandboxes"),
    SlashCommand("/evaluations", "View workspace evaluation jobs"),
    SlashCommand("/console", "View backend logs"),
    SlashCommand("/copy", "Copy last assistant message (or press y)"),
    SlashCommand("/quit", "Exit the TUI"),
]


# ---------------------------------------------------------------------------
# Auth helpers
# ---------------------------------------------------------------------------


def _parse_login_args(args: list[str], default_platform_url: str) -> tuple[str, str | None]:
    """Parse /login arguments into ``(server_url, api_key)``."""
    server_url = default_platform_url
    api_key: str | None = None

    index = 0
    while index < len(args):
        arg = args[index]
        if arg in {"--server", "-s"}:
            index += 1
            if index >= len(args):
                raise ValueError("Usage: /login [api-key] [--server <url>]")
            server_url = args[index]
        elif arg == "apikey":
            index += 1
            if index >= len(args):
                raise ValueError("Usage: /login [api-key] [--server <url>]")
            api_key = args[index]
        elif api_key is None:
            api_key = arg
        else:
            raise ValueError(f"Unknown /login argument: {arg}")
        index += 1

    return server_url, api_key


def _default_workspace_for_org(api: ApiClient, org_key: str) -> str | None:
    """Return the default workspace key for an organization."""
    workspaces = api.list_workspaces(org_key)
    for workspace in workspaces:
        if getattr(workspace, "is_default", False):
            return workspace.key
    return workspaces[0].key if workspaces else None


def _default_project_for_workspace(
    api: ApiClient, org_key: str, workspace_key: str | None
) -> str | None:
    """Return the default project key for a workspace."""
    if workspace_key is None:
        return None
    return api.get_default_project_key(org_key, workspace_key)


def _save_profile(profile_name: str, profile: ServerConfig) -> ServerConfig:
    """Persist a server profile to the local config directory."""
    _validate_profile_name(profile_name)
    cache_dir = Path.home() / ".dreadnode"
    profile_path = cache_dir / "orgs" / profile_name / "profile.yaml"
    profile.save(profile_path)

    user_config = UserConfig.read(cache_dir / "config.yaml")
    user_config.servers[profile_name] = profile
    user_config.active = profile_name
    user_config.write(cache_dir / "config.yaml")
    return profile


def _login_with_api_key(server_url: str, api_key: str) -> ServerConfig:
    """Authenticate with the platform using an API key."""
    api = ApiClient(server_url, api_key=api_key)
    user = api.get_user()
    orgs = api.list_user_organizations()
    if not orgs:
        raise RuntimeError("No organizations found for this account.")

    default_org = orgs[0].key
    default_workspace = _default_workspace_for_org(api, default_org)
    default_project = _default_project_for_workspace(api, default_org, default_workspace)

    profile = ServerConfig(
        url=server_url,
        user_key=user.username,
        email=user.email_address,
        username=user.username,
        api_key=api_key,
        default_organization=default_org,
        default_workspace=default_workspace,
        default_project=default_project,
    )
    return _save_profile(user.username, profile)


def _active_profile() -> tuple[str | None, ServerConfig | None]:
    """Return the active profile name and config, or (None, None)."""
    user_config = UserConfig.read(Path.home() / ".dreadnode" / "config.yaml")
    profile_name = user_config.active_profile_name
    if profile_name is None:
        return None, None
    return profile_name, user_config.servers.get(profile_name)


def _active_profile_name() -> str | None:
    """Return the active profile name, if any."""
    user_config = UserConfig.read(Path.home() / ".dreadnode" / "config.yaml")
    return user_config.active_profile_name


def _delete_active_profile() -> str | None:
    """Delete the active saved profile from disk and user config."""
    cache_dir = Path.home() / ".dreadnode"
    config_path = cache_dir / "config.yaml"
    user_config = UserConfig.read(config_path)
    profile_name = user_config.active_profile_name
    if profile_name is None:
        return None

    _validate_profile_name(profile_name)

    user_config.servers.pop(profile_name, None)
    if user_config.active == profile_name:
        user_config.active = None
    user_config.write(config_path)

    profile_path = cache_dir / "orgs" / profile_name / "profile.yaml"
    with contextlib.suppress(FileNotFoundError):
        profile_path.unlink()
    return profile_name


def _validate_profile_name(profile_name: str) -> str:
    """Validate profile names used for local filesystem paths."""
    if not profile_name or profile_name.strip(".") == "":
        raise ValueError("Profile name must not be empty or only dots.")
    if ".." in profile_name:
        raise ValueError("Profile name cannot contain '..'.")
    if _PROFILE_NAME_PATTERN.fullmatch(profile_name) is None:
        raise ValueError("Profile name contains invalid characters.")
    return profile_name


def _platform_client() -> tuple[ApiClient, ServerConfig]:
    """Create an ApiClient from the active profile."""
    profile_name, profile = _active_profile()
    if profile_name is None or profile is None:
        raise RuntimeError("Not logged in. Use /login first.")
    api = ApiClient(
        profile.url,
        api_key=profile.api_key or None,
    )
    return api, profile


# ---------------------------------------------------------------------------
# Event parsing helpers
# ---------------------------------------------------------------------------


def _extract_generation_text(payload: dict[str, t.Any]) -> str:
    """Extract generated text from a GenerationStep event payload."""
    messages = payload.get("messages")
    if isinstance(messages, list):
        parts: list[str] = []
        for message in messages:
            if not isinstance(message, dict) or message.get("role") != "assistant":
                continue
            parts.append(_extract_content_text(message.get("content")))
        return "".join(parts)
    return _extract_content_text(payload.get("content"))


def _extract_content_text(content: t.Any) -> str:
    """Extract plain text from various content payload shapes."""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for item in content:
            if isinstance(item, str):
                parts.append(item)
            elif isinstance(item, dict):
                text = item.get("text")
                if isinstance(text, str):
                    parts.append(text)
        return "".join(parts)
    if isinstance(content, dict):
        text = content.get("text")
        if isinstance(text, str):
            return text
    return ""


def _extract_tool_call(payload: dict[str, t.Any]) -> tuple[str, dict[str, t.Any]]:
    """Extract tool call name and arguments from event payload."""
    tool_call = payload.get("tool_call") or payload.get("toolCall")
    if not isinstance(tool_call, dict):
        return "tool", {}

    name = tool_call.get("name") or "tool"
    raw_args = tool_call.get("arguments")
    function_payload = tool_call.get("function")
    if raw_args is None and isinstance(function_payload, dict):
        raw_args = function_payload.get("arguments")

    if isinstance(raw_args, dict):
        return name, raw_args
    if isinstance(raw_args, str):
        try:
            parsed = json.loads(raw_args)
        except json.JSONDecodeError:
            return name, {}
        if isinstance(parsed, dict):
            return name, parsed
    return name, {}


def _extract_tool_name(payload: dict[str, t.Any]) -> str:
    """Extract tool name from event payload."""
    name, _ = _extract_tool_call(payload)
    return name


# Key argument to show inline for each tool category
_TOOL_KEY_ARGS: dict[str, list[str]] = {
    "bash": ["command"],
    "shell": ["command"],
    "read": ["file_path", "path", "filename", "url"],
    "read_file": ["file_path", "path"],
    "write": ["file_path", "path"],
    "write_file": ["file_path", "path"],
    "edit": ["file_path", "path"],
    "edit_file": ["file_path", "path"],
    "grep": ["pattern", "query"],
    "search": ["pattern", "query"],
    "glob": ["pattern"],
    "find": ["pattern", "path"],
    "web_search": ["query"],
    "fetch": ["url"],
}


def _format_tool_label(name: str, args: dict[str, t.Any], max_arg_len: int = 60) -> str:
    """Format tool name with its key argument: `read(pyproject.toml)`."""
    key_names = _TOOL_KEY_ARGS.get(name.lower(), [])
    for key in key_names:
        val = args.get(key)
        if isinstance(val, str) and val.strip():
            short = val.strip().replace("\n", " ")
            if len(short) > max_arg_len:
                short = short[:max_arg_len] + "..."
            return f"{name}({short})"
    # Fallback: show first string arg if short enough
    for val in args.values():
        if isinstance(val, str) and val.strip() and len(val) < 40:
            short = val.strip().replace("\n", " ")
            return f"{name}({short})"
    return name


def _summarize_tool_result(name: str, args: dict[str, t.Any], result: t.Any) -> str | None:
    """Return a compact one-line summary of a tool result."""
    if result is None:
        return None

    def _first_line(text: str) -> str:
        lines = [line.strip() for line in text.splitlines() if line.strip()]
        if not lines:
            return ""
        first = lines[0]
        if len(lines) > 1:
            return f"{first[:100]}..."
        return first[:120] + ("..." if len(first) > 120 else "")

    def _get_text(res: t.Any) -> str:
        if isinstance(res, str):
            return res
        if isinstance(res, dict):
            return (
                str(res.get("stdout", ""))
                or str(res.get("output", ""))
                or str(res.get("error", ""))
                or str(res.get("stderr", ""))
            )
        if isinstance(res, list):
            return "\n".join(str(x) for x in res)
        return str(res)

    text = _get_text(result)
    if not text.strip():
        return None

    offload_match = re.search(
        r"\.\.\. \[(?P<lines>\d+) lines truncated — full output saved to (?P<path>[^\]]+)\] \.\.\.",
        text,
    )
    if offload_match:
        lines = offload_match.group("lines")
        path = offload_match.group("path")
        return f"Output truncated ({lines} lines). Saved to {path}."

    if "full output saved to" in text:
        path_match = re.search(r"full output saved to (?P<path>[^\s\]]+)", text)
        if path_match:
            return f"Output saved to {path_match.group('path')}."

    name_lower = name.lower()

    # Tool-specific smart summaries
    if name_lower in ("read", "read_file"):
        lines = len(text.splitlines())
        return f"Read {lines} line{'s' if lines != 1 else ''}."

    if name_lower in ("glob", "find", "search", "grep"):
        lines = len([l for l in text.splitlines() if l.strip()])
        return f"Found {lines} result{'s' if lines != 1 else ''}."

    if name_lower in ("ls", "list_directory", "list"):
        items = len(text.split())
        return f"Listed {items} item{'s' if items != 1 else ''}."

    if name_lower in ("bash", "shell", "run_command", "execute"):
        cmd = str(args.get("command", "") or args.get("cmd", "") or "").strip()
        if cmd.startswith("ls"):
            items = len(text.split())
            return f"Listed {items} item{'s' if items != 1 else ''}."

    if name_lower in ("edit", "replace", "write", "write_file", "patch"):
        return "Succeeded. File edited."

    # Fallback: Just show the first line of the output
    summary = _first_line(text)
    return summary if summary else None
