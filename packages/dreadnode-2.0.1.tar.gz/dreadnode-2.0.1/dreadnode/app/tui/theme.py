"""UI color palette and theme for Rich integration.

This module centralizes the color scheme and provides a Rich theme object
for consistent styling of Markdown and other Rich-rendered content.

The palette is aligned with the variables in `dreadnode.tcss`.
"""

from __future__ import annotations

# --- Color Palette -----------------------------------------------------------
# Single source of truth.  When changing values here, also update the matching
# CSS variables in dreadnode.tcss (they cannot be auto-generated).

BG = "#0b0f14"
BG_LIGHT = "#0f141c"
BG_LIGHTER = "#141922"

FG = "#e1e4e8"
FG_SUBTLE = "#8b949e"
FG_MUTED = "#6e7681"
FG_FAINTEST = "#3b4450"

BORDER = "#1e2733"
BORDER_LIGHT = "#2a3240"

ACCENT = "#ef562f"
INFO = "#58a6ff"
SUCCESS = "#2ea043"
WARNING = "#d29922"
ERROR = "#f85149"

# Extended palette — platform screens, data visualization
BRAND = "#d37962"
PURPLE = "#a650fb"
TEAL = "#20dfc8"

# Logo accent colors
LOGO_PRIMARY = "#6b3520"
LOGO_SECONDARY = "#b5462a"

LOGO = r"""
██████   ██████   ███████   █████   ██████   ██   ██  ██████  ██████  ███████
 ██   ██  ██   ██  ██       ██   ██  ██   ██  ███  ██  ██  ██  ██   ██ ██     
 ██   ██  █████    █████    ███████  ██   ██  ██ ████  ██  ██  ██   ██ █████  
 ██   ██  ██  ██   ██       ██   ██  ██   ██  ██  ███  ██  ██  ██   ██ ██     
 ██████   ██   ██  ███████  ██   ██  ██████   ██   ██  ██████  ██████  ███████
""".strip("\n")
