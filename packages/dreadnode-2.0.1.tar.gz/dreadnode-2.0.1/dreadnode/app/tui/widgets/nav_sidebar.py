"""Collapsible left sidebar — session list."""

from __future__ import annotations

from rich.text import Text
from textual.app import ComposeResult
from textual.containers import Vertical
from textual.message import Message
from textual.widgets import OptionList, Static
from textual.widgets.option_list import Option

from dreadnode.app.tui.theme import ACCENT, FG, FG_FAINTEST, FG_MUTED, FG_SUBTLE
from dreadnode.app.tui.widgets.session_sidebar import SessionListEntry


class NavSidebar(Vertical):
    """Collapsible left sidebar — session list."""

    class SessionSelected(Message):
        """Posted when a session is selected from the list."""

        def __init__(self, session_id: str) -> None:
            self.session_id = session_id
            super().__init__()

    def compose(self) -> ComposeResult:
        yield Static("\u2590 Sessions", id="sidebar-sessions-heading", classes="sidebar-heading")
        yield OptionList(id="sidebar-sessions")

    def set_sessions(self, entries: list[SessionListEntry]) -> None:
        """Replace the session list with the given entries."""
        heading = self.query_one("#sidebar-sessions-heading", Static)
        count = len(entries)
        heading.update(f"\u2590 Sessions ({count})" if count else "\u2590 Sessions")

        option_list = self.query_one("#sidebar-sessions", OptionList)
        option_list.clear_options()

        if not entries:
            empty_text = Text()
            empty_text.append("  No sessions yet\n", style=f"italic {FG_MUTED}")
            empty_text.append("  Ctrl+N to create one", style=FG_FAINTEST)
            option_list.add_option(Option(empty_text, disabled=True))
            return

        highlight_index: int | None = None
        for index, entry in enumerate(entries):
            label = Text()
            if entry.is_active:
                label.append("\u25cf ", style=ACCENT)
            else:
                label.append("\u25cb ", style=FG_FAINTEST)
            display_name = entry.title if entry.title else entry.session_id[:8]
            label.append(display_name, style=FG if entry.is_active else FG_SUBTLE)
            label.append(f" ({entry.message_count})", style=FG_FAINTEST)
            option_list.add_option(Option(label, id=entry.session_id))
            if entry.is_active:
                highlight_index = index

        if highlight_index is not None:
            option_list.highlighted = highlight_index

    def on_option_list_option_selected(self, event: OptionList.OptionSelected) -> None:
        """Forward session selection as a message."""
        option_id = event.option.id
        if option_id:
            self.post_message(self.SessionSelected(option_id))
