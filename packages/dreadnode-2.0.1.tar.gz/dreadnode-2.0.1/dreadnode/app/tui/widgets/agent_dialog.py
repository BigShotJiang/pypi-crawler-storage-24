"""Agent picker dialog — shows available agents for selection."""

from __future__ import annotations

import typing as t

from rich.text import Text
from textual.message import Message
from textual.widgets import OptionList
from textual.widgets.option_list import Option

from dreadnode.app.tui.theme import FG, FG_FAINTEST, FG_MUTED, FG_SUBTLE


class AgentDialog(OptionList):
    """Popup dialog triggered by ^A — lists agents from loaded capabilities.

    Each agent row shows:
      ● agent_name                              capability_source
        Description text
        Model: inherit
    """

    class AgentSelected(Message):
        """Posted when an agent is selected from the dialog."""

        def __init__(self, agent_name: str) -> None:
            self.agent_name = agent_name
            super().__init__()

    def __init__(self, **kwargs: t.Any) -> None:
        super().__init__(**kwargs)
        self._agents: list[dict[str, str]] = []

    def show_agents(self, agents: list[dict[str, str]], current: str = "default") -> None:
        """Populate the dialog with agents and show it.

        Each dict has keys: name, description, model, capability.
        """
        self._agents = agents
        self.clear_options()

        if not agents:
            self.add_option(
                Option(
                    Text("No agents loaded", style=f"italic {FG_MUTED}"),
                    disabled=True,
                )
            )
            self.add_class("-visible")
            return

        for agent in agents:
            name = agent.get("name", "?")
            is_current = name == current

            label = Text()
            # Selection dot
            if is_current:
                label.append("● ", style=FG)
            else:
                label.append("○ ", style=FG_FAINTEST)

            # Agent name
            label.append(name, style=f"bold {FG}" if is_current else FG_SUBTLE)

            # Capability source (right-aligned visually via spaces)
            cap = agent.get("capability", "")
            if cap:
                label.append(f"  {cap}", style=FG_MUTED)

            # Description on next conceptual line (within the same option)
            desc = agent.get("description", "")
            if desc:
                label.append(f"\n  {desc}", style=FG_MUTED)

            # Model on next line
            model = agent.get("model", "inherit")
            label.append(f"\n  Model: {model}", style=FG_FAINTEST)

            self.add_option(Option(label, id=name))

        self.highlighted = 0
        self.add_class("-visible")

    def hide(self) -> None:
        self.remove_class("-visible")

    @property
    def is_visible(self) -> bool:
        return self.has_class("-visible")

    def move_highlight(self, direction: int) -> None:
        if self.option_count == 0:
            return
        current = self.highlighted or 0
        self.highlighted = max(0, min(current + direction, self.option_count - 1))

    def select_highlighted(self) -> bool:
        if not self.is_visible or self.option_count == 0:
            return False
        idx = self.highlighted
        if idx is not None and 0 <= idx < self.option_count:
            option = self.get_option_at_index(idx)
            if option.id:
                self.post_message(self.AgentSelected(option.id))
                self.hide()
                return True
        return False

    def on_option_list_option_selected(
        self, event: OptionList.OptionSelected
    ) -> None:
        option_id = event.option.id
        if option_id:
            self.post_message(self.AgentSelected(option_id))
            self.hide()
