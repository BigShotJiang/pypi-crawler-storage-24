"""Conversation view — single scrollable stream.

Design: Clear visual hierarchy with breathing room between messages.
  › user message (orange, bold prompt)
  assistant markdown (primary content, flows naturally)
  · tool_name (dim, compact — tools are implementation detail)
  · system info (dim)
"""

from __future__ import annotations

import asyncio
import typing as t
from dataclasses import dataclass

from rich.text import Text
from textual.app import ComposeResult
from textual.containers import VerticalScroll
from textual.widgets import Markdown, Static

from dreadnode.app.tui.theme import ACCENT, ERROR, FG, FG_FAINTEST, FG_MUTED, FG_SUBTLE
from dreadnode.app.tui.widgets.tool import ToolCall
from dreadnode.app.tui.widgets.tool_progress import ToolProgress


@dataclass(slots=True)
class TranscriptEntry:
    """One rendered transcript item."""

    kind: t.Literal["user", "assistant", "system", "error", "tool", "thinking"]
    title: str
    body: str
    meta: str | None = None
    turn: int | None = None


def _render_entry(entry: TranscriptEntry) -> list[t.Any]:
    """Render a transcript entry. Returns a list of renderables (for spacing control)."""
    if entry.kind == "user":
        text = Text()
        text.append("› ", style=f"bold {ACCENT}")
        text.append(entry.body, style=FG)
        return [text]

    if entry.kind == "assistant":
        # Return a Textual Markdown widget — styled via dreadnode.tcss
        return [Markdown(entry.body or "_(empty)_", classes=f"entry {entry.kind}-entry")]

    if entry.kind == "tool":
        details = entry.body.strip()
        if details:
            lines = details.splitlines()
            if len(lines) > 8:
                omitted = len(lines) - 6
                details = "\n".join(lines[:3] + [f"... {omitted} lines omitted ..."] + lines[-3:])
        return [
            ToolCall(
                name=entry.title,
                details=details,
                meta=entry.meta,
                classes=f"entry {entry.kind}-entry",
            )
        ]

    if entry.kind == "error":
        text = Text()
        text.append("✗ ", style=ERROR)
        text.append(entry.title or "error", style=f"bold {ERROR}")
        if entry.body:
            text.append(f" — {entry.body[:200]}", style=ERROR)
        return [text]

    if entry.kind == "thinking":
        text = Text()
        text.append("  │ ", style=FG_FAINTEST)
        text.append("Thinking: ", style=f"italic {FG_FAINTEST}")
        # Indent each line with the border
        lines = entry.body.splitlines()
        if lines:
            text.append(lines[0], style=FG_FAINTEST)
            for line in lines[1:]:
                text.append("\n")
                text.append("  │ ", style=FG_FAINTEST)
                text.append(line, style=FG_FAINTEST)
        return [text]

    # system / fallback
    text = Text()
    text.append("· ", style=FG_FAINTEST)
    text.append(entry.body, style=FG_FAINTEST)
    return [text]


class ConversationView(VerticalScroll):
    """Main chat area — single scrollable stream.

    Everything lives here: messages, tool calls, streaming text, activity.
    StreamingDraft is mounted as the last child so streaming text appears
    right after the latest message with no gap.
    """

    def compose(self) -> ComposeResult:
        """Compose the content of the conversation view."""
        yield StreamingDraft(id="draft", classes="-empty")
        yield ToolProgress(id="tool-progress")

    def show_empty(self) -> None:
        """Show an empty-state hint."""
        self._remove_entries()
        if self.query("#empty-hint"):
            return
        hint = Text()
        hint.append("Type a message, ", style=FG_MUTED)
        hint.append("/help", style=ACCENT)
        hint.append(", or ", style=FG_MUTED)
        hint.append("?", style=ACCENT)
        hint.append(" to get started.", style=FG_MUTED)
        self.mount(Static(hint, id="empty-hint", classes="entry"))

    def load_session(self, entries: list[TranscriptEntry]) -> None:
        """Replace the conversation with the given entries."""
        self._remove_entries()
        if not entries:
            self.show_empty()
            return
        widgets: list[Static | Markdown | ToolCall] = []
        for entry in entries:
            for item in _render_entry(entry):
                if isinstance(item, (Markdown, ToolCall)):
                    widgets.append(item)
                else:
                    widgets.append(Static(item, classes=f"entry {entry.kind}-entry"))
        try:
            draft = self.query_one("#draft")
            self.mount_all(widgets, before=draft)
        except Exception:
            self.mount_all(widgets)
        self.call_after_refresh(self.scroll_end, animate=False)

    def append_entry(self, entry: TranscriptEntry) -> None:
        """Add a single message to the stream."""
        # Remove empty-state hint if present
        for w in self.query("#empty-hint"):
            w.remove()
        widgets: list[Static | Markdown | ToolCall] = []
        for item in _render_entry(entry):
            if isinstance(item, (Markdown, ToolCall)):
                widgets.append(item)
            else:
                widgets.append(Static(item, classes=f"entry {entry.kind}-entry"))
        try:
            draft = self.query_one("#draft")
            self.mount_all(widgets, before=draft)
        except Exception:
            self.mount_all(widgets)
        self.call_after_refresh(self.scroll_end, animate=False)

    def write(self, renderable: t.Any) -> None:
        """Write a renderable to the stream."""
        widget = Static(renderable, classes="entry")
        try:
            self.mount(widget, before=self.query_one("#draft"))
        except Exception:
            self.mount(widget)
        self.call_after_refresh(self.scroll_end, animate=False)

    def write_system(self, message: str, *, style: str = FG_FAINTEST) -> None:
        """Write an inline system/activity message."""
        text = Text()
        text.append("· ", style=style)
        text.append(message, style=style)
        self.write(text)

    def write_activity(self, message: str) -> None:
        """Write a removable activity indicator (replaces any existing one)."""
        self.clear_activity()
        text = Text()
        text.append("· ", style=FG_SUBTLE)
        text.append(message, style=FG_SUBTLE)
        widget = Static(text, id="inline-activity", classes="entry")
        try:
            self.mount(widget, before=self.query_one("#draft"))
        except Exception:
            self.mount(widget)
        self.call_after_refresh(self.scroll_end, animate=False)

    def clear_activity(self) -> None:
        """Remove the activity indicator if present."""
        for w in self.query("#inline-activity"):
            w.remove()

    def _remove_entries(self) -> None:
        """Remove all entry widgets, keeping StreamingDraft."""
        for child in list(self.query(".entry")):
            child.remove()


class StreamingDraft(Markdown):
    """Live streaming markdown preview."""

    DEFAULT_CSS = f"""
    StreamingDraft {{
        display: none;
        height: auto;
        padding: 0;
        margin: 0;
        color: {FG_SUBTLE};
    }}
    StreamingDraft.-active {{
        display: block;
        margin-top: 1;
    }}
    StreamingDraft.-empty {{
        display: none;
    }}
    """

    def __init__(self, **kwargs: t.Any) -> None:
        super().__init__("", **kwargs)
        self._stream: t.Any | None = None
        self._buffer = ""

    def start_stream(self) -> None:
        """Begin a new streaming response."""
        if self._stream is not None:
            return
        self._buffer = ""
        self._stream = self.get_stream(self)
        self.remove_class("-empty")
        self.add_class("-active")

    def append_token(self, text: str) -> None:
        """Append a token — MarkdownStream batches re-renders automatically."""
        if self._stream is None:
            self.start_stream()
        self._buffer += text
        if self._stream is not None:
            asyncio.ensure_future(self._stream.write(text))

    def finish_stream(self) -> str:
        """End the stream and return accumulated text."""
        content = self._buffer
        self._stream = None
        return content

    def clear_stream(self) -> None:
        """Reset to empty idle state."""
        self._stream = None
        self._buffer = ""
        self.update("")
        self.add_class("-empty")
        self.remove_class("-active")
