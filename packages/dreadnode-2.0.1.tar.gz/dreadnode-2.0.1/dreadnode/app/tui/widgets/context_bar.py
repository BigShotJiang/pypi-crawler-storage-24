"""Session context bar (Zone 1) and page status (Zone 3).

SessionContextBar (Zone 1, 2 lines):
  Line 1: @agent_name · active                        Opus 4.6 (High)
  Line 2: ^A agent                                ^K model, ^⇧K reasoning

PageStatus (Zone 3, 1 line):
                                                   1,234 tok · ? help
"""

from __future__ import annotations

from rich.text import Text
from textual.reactive import reactive
from textual.widgets import Static

from dreadnode.app.tui.model_variants import display_name_with_effort
from dreadnode.app.tui.theme import ACCENT, FG_FAINTEST, FG_MUTED, FG_SUBTLE, WARNING
from dreadnode.app.tui.widgets.status_bar import _pad_right


class SessionContextBar(Static):
    """Zone 1 — two-line bar showing agent + model context above the composer."""

    agent_name: reactive[str] = reactive("default")
    model_name: reactive[str] = reactive("")
    effort_label: reactive[str] = reactive("")
    busy: reactive[bool] = reactive(False)
    status_text: reactive[str] = reactive("Ready")

    def render(self) -> Text:
        w = self.size.width

        # === Line 1: @agent (+ status)          Model (Effort) ===
        left = Text(no_wrap=True, overflow="ellipsis")
        left.append(f"@{self.agent_name or 'default'}", style=FG_SUBTLE)

        if self.busy:
            left.append(" · ", style=FG_FAINTEST)
            status = (self.status_text or "").strip().lower()
            if status.startswith("awaiting"):
                left.append(status, style=WARNING)
            else:
                left.append("active", style=ACCENT)

        right = Text(no_wrap=True)
        if self.model_name:
            effort = self.effort_label or None
            right.append(
                display_name_with_effort(self.model_name, effort), style="bold"
            )

        line1 = _pad_right(left, right, w)

        # === Line 2: keybind hints ===
        hints_left = Text(no_wrap=True)
        hints_left.append("^A", style=FG_FAINTEST)
        hints_left.append(" agent", style=FG_FAINTEST)

        hints_right = Text(no_wrap=True)
        hints_right.append("^K", style=FG_FAINTEST)
        hints_right.append(" model, ", style=FG_FAINTEST)
        hints_right.append("^⇧K", style=FG_FAINTEST)
        hints_right.append(" reasoning", style=FG_FAINTEST)

        line2 = _pad_right(hints_left, hints_right, w)

        result = line1.copy()
        result.append("\n")
        result.append_text(line2)
        return result


class PageStatus(Static):
    """Zone 3 — single-line page status below the composer."""

    total_tokens: reactive[int] = reactive(0)

    def render(self) -> Text:
        w = self.size.width

        left = Text(no_wrap=True)  # Empty — right-aligned content only

        right = Text(no_wrap=True)
        if self.total_tokens > 0:
            right.append(f"{self.total_tokens:,} tok", style=FG_MUTED)
            right.append(" · ", style=FG_FAINTEST)
        right.append("? help", style=FG_FAINTEST)

        return _pad_right(left, right, w)


# Backward-compat aliases — used by app.py until Task 6 updates it
ContextBar = SessionContextBar
