"""Tools browser dialog — shows all available tools grouped by capability."""

from __future__ import annotations

import typing as t

from rich.text import Text
from textual.widgets import OptionList
from textual.widgets.option_list import Option

from dreadnode.app.tui.theme import FG, FG_FAINTEST, FG_MUTED


class ToolsDialog(OptionList):
    """Popup dialog triggered by /tools — shows tools grouped by capability source.

    Tools are grouped under capability headers:
      recon-kit
        nmap_scan       Run nmap scan against target
        port_check      Check if port is open
      built-in
        read_file       Read file contents
    """

    def __init__(self, **kwargs: t.Any) -> None:
        super().__init__(**kwargs)

    def show_tools(self, tools: list[dict[str, str]]) -> None:
        """Populate with tools grouped by capability and show.

        Each dict has keys: name, description, capability.
        """
        self.clear_options()

        if not tools:
            self.add_option(
                Option(
                    Text("No tools available", style=f"italic {FG_MUTED}"),
                    disabled=True,
                )
            )
            self.add_class("-visible")
            return

        # Group by capability
        groups: dict[str, list[dict[str, str]]] = {}
        for tool in tools:
            cap = tool.get("capability", "unknown")
            groups.setdefault(cap, []).append(tool)

        first = True
        for cap_name, cap_tools in groups.items():
            if not first:
                self.add_option(Option(Text("─" * 40, style=FG_FAINTEST), disabled=True))
            first = False

            # Group header
            header = Text(cap_name, style=f"bold {FG_MUTED}")
            self.add_option(Option(header, disabled=True))

            # Tools
            for tool in cap_tools:
                line = Text()
                line.append(f"  {tool.get('name', '?')}", style=FG)
                desc = tool.get("description", "")
                if desc:
                    # Truncate long descriptions
                    if len(desc) > 50:
                        desc = desc[:47] + "..."
                    line.append(f"  {desc}", style=FG_FAINTEST)
                self.add_option(Option(line, disabled=True))  # Read-only

        count = len(tools)
        # Update with count in the title area (rendered via CSS border-title if available)
        self.border_title = f"Tools ({count})"
        self.add_class("-visible")

    def hide(self) -> None:
        self.remove_class("-visible")

    @property
    def is_visible(self) -> bool:
        return self.has_class("-visible")

    def move_highlight(self, direction: int) -> None:
        if self.option_count == 0:
            return
        current = self.highlighted or 0
        self.highlighted = max(0, min(current + direction, self.option_count - 1))

    def select_highlighted(self) -> bool:
        """No-op — tools browser is read-only."""
        return False
