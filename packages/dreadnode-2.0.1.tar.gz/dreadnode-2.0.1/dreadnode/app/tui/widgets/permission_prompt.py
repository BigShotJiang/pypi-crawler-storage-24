"""Unified human prompt widget for input/choice/approval."""

from __future__ import annotations

import typing as t

from rich.text import Text
from textual.app import ComposeResult
from textual.containers import Horizontal
from textual.message import Message
from textual.widgets import Button, Static

from dreadnode.app.api.models import HumanPrompt
from dreadnode.app.tui.theme import BG_LIGHTER, FG, FG_SUBTLE, WARNING


class HumanPromptWidget(Static):
    """Inline widget for human prompts (input, choice, approval)."""

    class Action(Message):
        """Posted when the user triggers a prompt action."""

        def __init__(self, request_id: str, action: str) -> None:
            self.request_id = request_id
            self.action = action
            super().__init__()

    DEFAULT_CSS = f"""
    PermissionPrompt {{
        display: none;
        height: auto;
        padding: 1 2;
        background: {BG_LIGHTER};
        border: solid {WARNING};
    }}
    PermissionPrompt.-active {{
        display: block;
    }}
    PermissionPrompt .perm-label {{
        height: auto;
        margin-bottom: 1;
    }}
    PermissionPrompt .perm-detail {{
        height: auto;
        color: {FG_SUBTLE};
        margin-bottom: 1;
    }}
    PermissionPrompt .perm-buttons {{
        height: 3;
    }}
    PermissionPrompt Button {{
        margin-right: 1;
    }}
    """

    def __init__(self, **kwargs: t.Any) -> None:
        super().__init__(**kwargs)
        self._request_id: str = ""
        self._prompt: HumanPrompt | None = None

    def compose(self) -> ComposeResult:
        yield Static("", id="perm-label", classes="perm-label")
        yield Static("", id="perm-detail", classes="perm-detail")
        yield Static("", id="perm-options", classes="perm-detail")
        yield Horizontal(
            Button("Allow", id="perm-allow", variant="success"),
            Button("Allow Session", id="perm-allow-session", variant="warning"),
            Button("Deny", id="perm-deny", variant="error"),
            Button("Cancel", id="perm-cancel"),
            classes="perm-buttons",
        )
        yield Static("", id="perm-hint", classes="perm-detail")

    def show_prompt(self, prompt: HumanPrompt) -> None:
        """Display a structured human prompt."""
        self._prompt = prompt
        self._request_id = prompt.request_id

        label_text = Text()
        if prompt.kind == "approval":
            label_text.append("Approval required: ", style=f"bold {WARNING}")
        else:
            label_text.append("Input required: ", style=f"bold {WARNING}")
        label_text.append(prompt.question, style=f"bold {FG}")
        self.query_one("#perm-label", Static).update(label_text)

        detail = prompt.details or ""
        if len(detail) > 120:
            detail = detail[:117] + "..."
        self.query_one("#perm-detail", Static).update(detail)

        options_text = ""
        if prompt.options:
            formatted: list[str] = []
            for idx, option in enumerate(prompt.options, 1):
                suffix = " (default)" if option.label == prompt.default_option else ""
                formatted.append(f"{idx}. {option.label}{suffix}")
            options_text = "\n".join(formatted)
        self.query_one("#perm-options", Static).update(options_text)

        self._sync_buttons(prompt)
        self.add_class("-active")

    def _sync_buttons(self, prompt: HumanPrompt) -> None:
        approval = prompt.kind == "approval"
        buttons_row = self.query_one(".perm-buttons", Horizontal)
        buttons_row.display = approval

        for button_id in ("perm-allow", "perm-allow-session", "perm-deny"):
            self.query_one(f"#{button_id}", Button).display = approval
        self.query_one("#perm-cancel", Button).display = approval

        hint = self.query_one("#perm-hint", Static)
        if approval:
            hint.display = False
            hint.update("")
            return

        hint.display = True
        hint_text = "Enter to submit · Esc to cancel"
        if prompt.options:
            hint_text = "Enter to submit · Type option number or text · Esc to cancel"
        hint.update(hint_text)

    def hide_prompt(self) -> None:
        """Hide the permission prompt."""
        self.remove_class("-active")
        self._request_id = ""
        self._prompt = None

    @property
    def is_active(self) -> bool:
        """Whether a permission prompt is currently showing."""
        return self.has_class("-active")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button presses."""
        if not self._request_id:
            return
        action_map = {
            "perm-allow": "approve",
            "perm-allow-session": "allow_session",
            "perm-deny": "deny",
            "perm-cancel": "cancel",
        }
        action = action_map.get(event.button.id or "", "cancel")
        self.post_message(self.Action(self._request_id, action))
        self.hide_prompt()


class PermissionPrompt(HumanPromptWidget):
    """Backward-compatible alias for the unified human prompt widget."""
