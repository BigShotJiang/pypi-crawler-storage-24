"""Widgets for the Dreadnode Textual client."""

from dreadnode.app.tui.widgets.agent_dialog import AgentDialog
from dreadnode.app.tui.widgets.context_bar import ContextBar, SessionContextBar, PageStatus
from dreadnode.app.tui.widgets.status_bar import StatusBar
from dreadnode.app.tui.widgets.conversation import (
    ConversationView,
    StreamingDraft,
    TranscriptEntry,
)
from dreadnode.app.tui.widgets.flash import Flash
from dreadnode.app.tui.widgets.message_queue import MessageQueue

# Legacy imports — kept for backward compatibility but no longer used in compose()
from dreadnode.app.tui.widgets.header_bar import HeaderBar
from dreadnode.app.tui.widgets.help_panel import render_help
from dreadnode.app.tui.widgets.mention_overlay import MentionOverlay
from dreadnode.app.tui.widgets.nav_sidebar import NavSidebar
from dreadnode.app.tui.widgets.permission_prompt import HumanPromptWidget, PermissionPrompt
from dreadnode.app.tui.widgets.session_sidebar import SessionListEntry, SessionSidebar
from dreadnode.app.tui.widgets.slash_overlay import SlashOverlay
from dreadnode.app.tui.widgets.throbber import Throbber
from dreadnode.app.tui.widgets.tool_progress import ToolProgress
from dreadnode.app.tui.widgets.welcome import Welcome

__all__ = [
    "AgentDialog",
    "StatusBar",
    "ContextBar",
    "SessionContextBar",
    "PageStatus",
    "ConversationView",
    "render_help",
    "MentionOverlay",
    "Flash",
    "MessageQueue",
    "NavSidebar",
    "HumanPromptWidget",
    "PermissionPrompt",
    "SessionListEntry",
    "SlashOverlay",
    "StreamingDraft",
    "ToolProgress",
    "TranscriptEntry",
    "Welcome",
    # Legacy
    "HeaderBar",
    "SessionSidebar",
    "Throbber",
]
