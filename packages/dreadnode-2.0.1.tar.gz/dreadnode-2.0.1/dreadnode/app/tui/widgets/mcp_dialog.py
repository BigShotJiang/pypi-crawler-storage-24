"""MCP server status dialog — shows health of all MCP servers."""

from __future__ import annotations

import typing as t

from rich.text import Text
from textual.widgets import OptionList
from textual.widgets.option_list import Option

from dreadnode.app.tui.theme import ERROR, FG_MUTED, SUCCESS, WARNING


class McpDialog(OptionList):
    """Popup dialog triggered by /mcp — lists MCP server health status.

    Each row shows:
      ● server_name                    connected
      ✗ server_name        needs auth (run /login)
    """

    def __init__(self, **kwargs: t.Any) -> None:
        super().__init__(**kwargs)

    def show_servers(self, servers: list[dict[str, str | None]]) -> None:
        """Populate with server data and show.

        Each dict has keys: name, status, error, detail.
        Status values: "ok", "error", or anything else (treated as warning/degraded).
        """
        self.clear_options()

        if not servers:
            self.add_option(
                Option(
                    Text("No MCP servers configured", style=f"italic {FG_MUTED}"),
                    disabled=True,
                )
            )
            self.add_class("-visible")
            return

        for s in servers:
            line = Text(no_wrap=True)
            status = s.get("status", "?")

            # Status dot
            if status == "ok":
                line.append("● ", style=SUCCESS)
            elif status == "error":
                line.append("✗ ", style=ERROR)
            else:
                line.append("● ", style=WARNING)

            # Server name
            line.append(s.get("name", "?"), style="bold")

            # Status text on the right
            if s.get("error"):
                detail = s["error"]
                if s.get("detail"):
                    detail += f" ({s['detail']})"
                line.append(f"  {detail}", style=FG_MUTED)
            elif status == "ok":
                line.append("  connected", style=FG_MUTED)
            else:
                line.append(f"  {status}", style=FG_MUTED)

            self.add_option(Option(line, id=s.get("name")))

        self.highlighted = 0
        self.add_class("-visible")

    def hide(self) -> None:
        self.remove_class("-visible")

    @property
    def is_visible(self) -> bool:
        return self.has_class("-visible")

    def move_highlight(self, direction: int) -> None:
        if self.option_count == 0:
            return
        current = self.highlighted or 0
        self.highlighted = max(0, min(current + direction, self.option_count - 1))

    def select_highlighted(self) -> bool:
        """No-op for MCP dialog — read-only, no selection action."""
        return False
