"""Slash command overlay with fuzzy filtering and descriptions."""

from __future__ import annotations

from rich.text import Text
from textual.message import Message
from textual.widgets import OptionList
from textual.widgets.option_list import Option

from dreadnode.app.tui.commands import SLASH_COMMANDS, SlashCommand
from dreadnode.app.tui.theme import ACCENT, FG_MUTED, FG_SUBTLE


class SlashOverlay(OptionList):
    """Popup overlay that filters slash commands as the user types."""

    class SlashSelected(Message):
        """Posted when a slash command is selected."""

        def __init__(self, command: str) -> None:
            self.command = command
            super().__init__()

    def filter_commands(self, prefix: str) -> None:
        """Update the option list with commands matching the prefix."""
        query = prefix.lstrip("/").lower()
        matches: list[SlashCommand] = []
        for cmd in SLASH_COMMANDS:
            name_lower = cmd.name.lstrip("/").lower()
            if not query or query in name_lower:
                matches.append(cmd)

        self.clear_options()
        if not matches:
            self.add_class("-visible")
            self.add_option(Option("No matching commands", disabled=True))
            return

        for cmd in matches:
            label = Text()
            label.append(cmd.name, style=f"bold {ACCENT}")
            if cmd.hint:
                label.append(f" {cmd.hint}", style=FG_MUTED)
            label.append(f"  {cmd.description}", style=FG_SUBTLE)
            self.add_option(Option(label, id=cmd.name))

        self.highlighted = 0
        self.add_class("-visible")

    def hide(self) -> None:
        """Hide the overlay."""
        self.remove_class("-visible")

    @property
    def is_visible(self) -> bool:
        return self.has_class("-visible")

    def move_highlight(self, direction: int) -> None:
        """Move the highlight up (-1) or down (+1)."""
        if self.option_count == 0:
            return
        current = self.highlighted or 0
        self.highlighted = max(0, min(current + direction, self.option_count - 1))

    def select_highlighted(self) -> bool:
        """Select the currently highlighted option. Returns True if handled."""
        if not self.is_visible or self.option_count == 0:
            return False
        idx = self.highlighted
        if idx is not None and 0 <= idx < self.option_count:
            option = self.get_option_at_index(idx)
            if option.id:
                self.post_message(self.SlashSelected(option.id))
                self.hide()
                return True
        return False

    def on_option_list_option_selected(self, event: OptionList.OptionSelected) -> None:
        """Post a SlashSelected message when a command is chosen."""
        option_id = event.option.id
        if option_id:
            self.post_message(self.SlashSelected(option_id))
            self.hide()
