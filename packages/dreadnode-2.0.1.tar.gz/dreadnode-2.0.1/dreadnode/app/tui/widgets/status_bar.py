"""Zone 4 — Global nav bar with runtime health and app navigation.

Always visible, even on pushed full-screen views. Shows:
  Left:  ✓ local · dreadnode/pentest     (or ✗ error message)
  Right: ^B sidebar  ^T traces  ^S sandbox  ^E evals  F5 console
"""

from __future__ import annotations

from rich.cells import cell_len
from rich.text import Text
from textual.reactive import reactive
from textual.widgets import Static

from dreadnode.app.tui.theme import (
    BG,
    ERROR,
    FG_FAINTEST,
    FG_MUTED,
    SUCCESS,
)


def _pad_right(left: Text, right: Text, width: int, padding: int = 4) -> Text:
    """Join left and right text with space-fill to target width."""
    gap = max(width - cell_len(left.plain) - cell_len(right.plain) - padding, 1)
    result = left.copy()
    result.append(" " * gap)
    result.append_text(right)
    return result


class StatusBar(Static):
    """Single-line global nav bar — runtime health + navigation."""

    DEFAULT_CSS = f"""
    StatusBar {{
        height: auto;
        padding: 1 2 0 2;
        color: {FG_FAINTEST};
        background: {BG};
    }}
    """

    connection: reactive[str] = reactive("local")
    workspace_label: reactive[str] = reactive("")
    runtime_health: reactive[str] = reactive("")

    def render(self) -> Text:
        w = self.size.width

        # === Left: runtime health ===
        left = Text(no_wrap=True, overflow="ellipsis")

        if self.runtime_health:
            left.append("✗ ", style=ERROR)
            left.append(self.runtime_health, style=ERROR)
        else:
            left.append("✓ ", style=SUCCESS)
            conn = "platform" if self.connection.startswith("http") else self.connection
            left.append(conn, style=FG_MUTED)

        if self.workspace_label and not self.runtime_health:
            left.append(" · ", style=FG_FAINTEST)
            left.append(self.workspace_label, style=FG_MUTED)

        # === Right: navigation shortcuts ===
        right = Text(no_wrap=True)
        for key, label, last in [
            ("^B", "sidebar", False),
            ("^T", "traces", False),
            ("^S", "sandbox", False),
            ("^E", "evals", False),
            ("F5", "console", True),
        ]:
            right.append(key, style=FG_FAINTEST)
            right.append(f" {label}", style=FG_FAINTEST)
            if not last:
                right.append("  ", style=FG_FAINTEST)

        return _pad_right(left, right, w)
