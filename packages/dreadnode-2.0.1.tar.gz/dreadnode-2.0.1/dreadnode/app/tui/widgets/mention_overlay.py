"""@ mention overlay — shows capability agents for selection."""

from __future__ import annotations

import typing as t

from rich.text import Text
from textual.message import Message
from textual.widgets import OptionList
from textual.widgets.option_list import Option

from dreadnode.app.tui.theme import ACCENT, FG, FG_FAINTEST, FG_MUTED


class MentionOverlay(OptionList):
    """Popup overlay triggered by @ — lists agents from loaded capabilities."""

    class AgentSelected(Message):
        """Posted when an agent is selected."""

        def __init__(self, agent_name: str) -> None:
            self.agent_name = agent_name
            super().__init__()

    def __init__(self, **kwargs: t.Any) -> None:
        super().__init__(**kwargs)
        self._agents: list[dict[str, str]] = []

    def set_agents(self, agents: list[dict[str, str]]) -> None:
        """Update the agent list from runtime info."""
        self._agents = agents

    def filter(self, query: str) -> None:
        """Filter agents by query and show the overlay."""
        query_lower = query.lower()
        self.clear_options()

        matches = [a for a in self._agents if query_lower in a["name"].lower()]

        if not matches:
            self.add_option(Option(Text("No matching agents", style=f"italic {FG_MUTED}"), disabled=True))
            self.add_class("-visible")
            return

        for agent in matches:
            label = Text()
            label.append("\u25b6 ", style=ACCENT)
            label.append(agent["name"], style=f"bold {FG}")
            label.append(f"  {agent.get('capability', '')}", style=FG_MUTED)
            if agent.get("model") and agent["model"] != "inherit":
                label.append(f"  {agent['model']}", style=FG_FAINTEST)
            self.add_option(Option(label, id=agent["name"]))

        self.highlighted = 0
        self.add_class("-visible")

    def hide(self) -> None:
        self.remove_class("-visible")

    @property
    def is_visible(self) -> bool:
        return self.has_class("-visible")

    def move_highlight(self, direction: int) -> None:
        if self.option_count == 0:
            return
        current = self.highlighted or 0
        self.highlighted = max(0, min(current + direction, self.option_count - 1))

    def select_highlighted(self) -> bool:
        if not self.is_visible or self.option_count == 0:
            return False
        idx = self.highlighted
        if idx is not None and 0 <= idx < self.option_count:
            option = self.get_option_at_index(idx)
            if option.id:
                self.post_message(self.AgentSelected(option.id))
                self.hide()
                return True
        return False

    def on_option_list_option_selected(self, event: OptionList.OptionSelected) -> None:
        option_id = event.option.id
        if option_id:
            self.post_message(self.AgentSelected(option_id))
            self.hide()
