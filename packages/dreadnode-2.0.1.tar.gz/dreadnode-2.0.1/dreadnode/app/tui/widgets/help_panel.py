"""Render inline help content into the conversation view.

Triggered by `?` (empty composer) or `/help`. Writes directly into the
ConversationView — no separate panel widget, no scrolling issues.
"""

from __future__ import annotations

from rich.text import Text

from dreadnode.app.tui.commands import SLASH_COMMANDS
from dreadnode.app.tui.theme import ACCENT, BORDER_LIGHT, FG_MUTED, FG_SUBTLE

_CMD_LOOKUP = {cmd.name: cmd for cmd in SLASH_COMMANDS}

# Grouped for scannability — most useful first, one section per concern
_INPUT: list[tuple[str, str]] = [
    ("Enter", "send message"),
    ("\\ + Enter", "new line"),
    ("/", "commands"),
    ("@", "mention agent"),
    ("!", "shell mode"),
    ("?", "this help"),
]

_NAVIGATION: list[tuple[str, str]] = [
    ("Up/Down", "prompt history"),
    ("j/k", "scroll conversation"),
    ("Ctrl+U/D", "half-page scroll"),
    ("g/G", "top / bottom"),
    ("Tab", "cycle focus"),
    ("Esc", "dismiss / clear / interrupt"),
]

_SESSION: list[tuple[str, str]] = [
    ("Ctrl+N", "new session"),
    ("Ctrl+R", "reset session"),
    ("Ctrl+K", "model picker"),
    ("Ctrl+Shift+K", "cycle effort"),
    ("y", "copy last response to clipboard"),
    ("/copy", "copy last response to clipboard"),
]

_VIEWS: list[tuple[str, str]] = [
    ("Ctrl+T", "traces"),
    ("Ctrl+S", "sandboxes"),
    ("Ctrl+E", "evals"),
    ("Ctrl+Y", "runtimes"),
    ("F5", "console logs"),
    ("F6", "secrets"),
    ("F7", "hub"),
    ("F8", "environments"),
]

_COMMAND_GROUPS: list[tuple[str, list[str]]] = [
    ("Session", ["/new", "/reset", "/sessions", "/use", "/rename", "/delete", "/export"]),
    ("Agents", ["/agents", "/agent", "/model", "/models", "/thinking"]),
    ("Platform", ["/login", "/logout", "/whoami", "/workspace", "/workspaces", "/projects"]),
    ("Views", ["/traces", "/sandboxes", "/evaluations", "/runtimes", "/console", "/hub", "/secrets", "/environments"]),
    ("Other", ["/help", "/copy", "/quit"]),
]

# Colors
_HEADING = FG_SUBTLE
_KEY = ACCENT
_DESC = FG_MUTED
_CMD = FG_SUBTLE
_SEP = BORDER_LIGHT


def _section(t: Text, title: str, items: list[tuple[str, str]]) -> None:
    """Append a key/description section."""
    t.append(f"  {title}\n", style=f"bold {_HEADING}")
    for key, desc in items:
        t.append(f"    {key:<14}", style=_KEY)
        t.append(f" {desc}\n", style=_DESC)


def render_help() -> Text:
    """Build the help content as a Rich Text renderable."""
    t = Text()

    _section(t, "Input", _INPUT)
    t.append("\n")
    _section(t, "Navigation", _NAVIGATION)
    t.append("\n")
    _section(t, "Session", _SESSION)
    t.append("\n")
    _section(t, "Views", _VIEWS)

    t.append("\n")
    t.append("  Commands\n", style=f"bold {_HEADING}")
    for group, cmd_names in _COMMAND_GROUPS:
        commands = [n for n in cmd_names if n in _CMD_LOOKUP]
        t.append(f"    {group:<12}", style=_DESC)
        t.append(" ".join(commands), style=_CMD)
        t.append("\n")

    t.append("\n")
    t.append(
        "  Note: /workspace restarts the runtime and clears in-memory sessions\n",
        style=_DESC,
    )

    return t
