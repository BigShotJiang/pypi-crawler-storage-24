"""Welcome screen shown on startup before first interaction."""

from __future__ import annotations

from rich.text import Text
from textual.reactive import reactive
from textual.widgets import Static

from dreadnode.app.tui.theme import BG, FG_FAINTEST, FG_MUTED, LOGO, LOGO_PRIMARY, LOGO_SECONDARY

# Minimum width to show the full ASCII art logo (logo is ~78 chars + padding)
_LOGO_MIN_WIDTH = 82


class Welcome(Static):
    """Centered welcome screen with branding and key hints."""

    DEFAULT_CSS = f"""
    Welcome {{
        height: 1fr;
        content-align: center middle;
        background: {BG};
        padding: 0 2;
    }}
    Welcome.-hidden {{
        display: none;
    }}
    """

    version: reactive[str] = reactive("")
    working_dir: reactive[str] = reactive("")

    def render(self) -> Text:
        w = self.size.width
        t = Text(justify="center")

        # Logo — full ASCII art when wide enough, styled text otherwise
        if w >= _LOGO_MIN_WIDTH:
            for line in LOGO.strip().splitlines():
                t.append(line, style=LOGO_PRIMARY)
                t.append("\n")
        else:
            t.append("dreadnode", style=f"bold {LOGO_SECONDARY}")
            t.append("\n")

        # Version
        if self.version:
            t.append(f"\n{self.version}\n", style=FG_FAINTEST)
        t.append("\n")

        # Tagline
        t.append("Type a message to get started.\n\n", style=FG_MUTED)

        # Key hints — adapt column width to available space
        hints = [
            ("Enter", "send"),
            ("\\ + Enter", "new line"),
            ("@", "mention agent"),
            ("/", "commands"),
            ("?", "help"),
            ("Esc", "dismiss / clear / interrupt"),
        ]

        col = min(16, max(w // 4, 10))
        for key, desc in hints:
            t.append(f"  {key:<{col}}", style=LOGO_SECONDARY)
            t.append(f"{desc}\n", style=FG_FAINTEST)

        # Working dir
        if self.working_dir:
            t.append(f"\n{self.working_dir}", style=FG_FAINTEST)

        return t

    def dismiss(self) -> None:
        """Hide the welcome screen."""
        self.add_class("-hidden")

    @property
    def is_visible(self) -> bool:
        return not self.has_class("-hidden")
