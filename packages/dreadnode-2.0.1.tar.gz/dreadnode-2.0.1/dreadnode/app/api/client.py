"""Main API client used by the Python SDK and CLI."""

import typing as t

import httpx

from dreadnode.app.api.models import (
    CreateTrainingJobBase,
    HealthCheck,
    Organization,
    Package,
    Project,
    ProviderPresetsList,
    StorageCredentials,
    TrainingJob,
    TrainingJobArtifacts,
    TrainingJobCreateRequest,
    TrainingJobList,
    TrainingJobLogList,
    UsageLimits,
    User,
    UserSecret,
    UserSecretsList,
    Workspace,
)
from dreadnode.version import VERSION


class AuthenticationError(RuntimeError):
    """Raised when the platform returns HTTP 401."""


class ApiClient:
    """
    Main API client implementing the routes used by the Python SDK and CLI.
    """

    def __init__(
        self,
        base_url: str,
        *,
        api_key: str | None = None,
        timeout: int = 30,
    ):
        """
        Initialize the API client.

        Args:
            base_url: The base URL of the Dreadnode API.
            api_key: API key for authentication (X-API-Key header).
            timeout: Request timeout in seconds.
        """
        api_base_url, server_root_url = self._normalize_base_urls(base_url)
        self._base_url = api_base_url
        self._server_root_url = server_root_url
        self._api_key = api_key

        headers = {
            "User-Agent": f"dreadnode-sdk/{VERSION}",
            "Accept": "application/json",
        }
        if api_key:
            headers["X-API-Key"] = api_key

        self._client = httpx.Client(
            headers=headers,
            base_url=self._base_url,
            timeout=httpx.Timeout(timeout, connect=5),
        )

    @staticmethod
    def _normalize_base_urls(base_url: str) -> tuple[str, str]:
        base_url = base_url.rstrip("/")
        if base_url.endswith("/api/v1"):
            return base_url, base_url.removesuffix("/api/v1")
        if base_url.endswith("/api"):
            return base_url, base_url.removesuffix("/api")
        return f"{base_url}/api/v1", base_url

    def _get_error_message(self, response: httpx.Response) -> str:
        """Extract error message from HTTP response."""
        try:
            obj = response.json()
            detail = obj.get("detail", str(obj))
            return f"{response.status_code}: {detail}"
        except Exception:
            return f"{response.status_code}: {response.content!r}"

    def _request(
        self,
        method: str,
        path: str,
        params: dict[str, t.Any] | None = None,
        json_data: dict[str, t.Any] | None = None,
        data: dict[str, t.Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> httpx.Response:
        """Make a raw HTTP request without raising on errors."""
        return self._client.request(
            method,
            path,
            params=params,
            json=json_data,
            data=data,
            headers=headers,
        )

    def request(
        self,
        method: str,
        path: str,
        params: dict[str, t.Any] | None = None,
        json_data: dict[str, t.Any] | None = None,
        data: dict[str, t.Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> httpx.Response:
        """Make an HTTP request and raise on errors."""
        response = self._request(method, path, params, json_data, data, headers)
        if response.status_code == 401:
            raise AuthenticationError(self._get_error_message(response))
        try:
            response.raise_for_status()
        except httpx.HTTPStatusError as e:
            raise RuntimeError(self._get_error_message(response)) from e
        return response

    # =========================================================================
    # Health & Config (public routes)
    # =========================================================================

    def health_check(self) -> HealthCheck:
        """GET /api/ or GET /api/health - Health check."""
        response = self.request("GET", "/health")
        return HealthCheck(**response.json())

    # =========================================================================
    # Auth (public routes)
    # =========================================================================

    def create_device_code(self) -> dict[str, t.Any]:
        """POST /api/v1/auth/device/code - Create a device code."""
        response = self.request(
            "POST",
            "/auth/device/code",
        )
        return t.cast("dict[str, t.Any]", response.json())

    def poll_device_code(self, device_code: str) -> tuple[int, dict[str, t.Any] | None]:
        """GET /api/v1/auth/device/code/{device_code} - Poll device code status."""
        response = self._request(
            "GET",
            f"/auth/device/code/{device_code}",
        )
        if response.is_success:
            return response.status_code, t.cast("dict[str, t.Any]", response.json())
        return response.status_code, None

    def exchange_device_code(self, device_code: str) -> dict[str, t.Any]:
        """POST /api/v1/auth/device/token - Exchange device code for tokens."""
        response = self.request(
            "POST",
            "/auth/device/token",
            json_data={"device_code": device_code},
        )
        return t.cast("dict[str, t.Any]", response.json())

    def create_api_key_with_jwt(
        self,
        access_token: str,
        name: str | None = None,
        *,
        allow_self_revoke: bool = False,
    ) -> dict[str, t.Any]:
        """POST /api/user/api-keys - Create an API key using JWT bearer auth."""
        response = self.request(
            "POST",
            "/user/api-keys",
            json_data={"name": name, "allow_self_revoke": allow_self_revoke},
            headers={"Authorization": f"Bearer {access_token}"},
        )
        return t.cast("dict[str, t.Any]", response.json())

    def revoke_self_api_key(self) -> None:
        """DELETE /api/user/api-keys/self - Revoke the current API key."""
        self.request("DELETE", "/user/api-keys/self")

    # =========================================================================
    # User (authenticated routes)
    # =========================================================================

    def get_user(self) -> User:
        """GET /api/user - Get current user."""
        response = self.request("GET", "/user")
        return User(**response.json())

    # =========================================================================
    # Secrets
    # =========================================================================

    def list_secrets(self) -> UserSecretsList:
        """GET /api/user/secrets - List all user secrets."""
        response = self.request("GET", "/user/secrets")
        return UserSecretsList(**response.json())

    def get_secret(self, secret_id: str) -> UserSecret:
        """GET /api/user/secrets/{secret_id} - Get a specific secret."""
        response = self.request("GET", f"/user/secrets/{secret_id}")
        return UserSecret(**response.json())

    def get_secret_presets(self) -> ProviderPresetsList:
        """GET /api/user/secrets/presets - Get available provider presets."""
        response = self.request("GET", "/user/secrets/presets")
        return ProviderPresetsList(**response.json())

    def create_secret(self, name: str, value: str) -> UserSecret:
        """POST /api/user/secrets - Create a custom secret."""
        response = self.request(
            "POST",
            "/user/secrets",
            json_data={"name": name, "value": value},
        )
        return UserSecret(**response.json())

    def create_secret_from_preset(self, provider: str, value: str) -> UserSecret:
        """POST /api/user/secrets/preset - Create a secret from a provider preset."""
        response = self.request(
            "POST",
            "/user/secrets/preset",
            json_data={"provider": provider, "value": value},
        )
        return UserSecret(**response.json())

    def update_secret(self, secret_id: str, value: str) -> UserSecret:
        """PUT /api/user/secrets/{secret_id} - Update a secret's value."""
        response = self.request(
            "PUT",
            f"/user/secrets/{secret_id}",
            json_data={"value": value},
        )
        return UserSecret(**response.json())

    def delete_secret(self, secret_id: str) -> None:
        """DELETE /api/user/secrets/{secret_id} - Delete a secret."""
        self.request("DELETE", f"/user/secrets/{secret_id}")

    # =========================================================================
    # Limits
    # =========================================================================

    def get_usage_limits(self) -> UsageLimits:
        """GET /api/user/limits - Get usage limits for current user."""
        response = self.request("GET", "/user/limits")
        return UsageLimits(**response.json())

    def get_limits(self) -> UsageLimits:
        """Compatibility alias for get_usage_limits()."""
        return self.get_usage_limits()

    # =========================================================================
    # OTEL Ingestion
    # =========================================================================

    def ingest_traces(self, org: str, traces: list[dict[str, t.Any]]) -> dict[str, t.Any]:
        """POST /api/org/{org}/otel/traces - Ingest traces from SDK."""
        response = self.request(
            "POST",
            f"/org/{org}/otel/traces",
            json_data={"traces": traces},
        )
        return t.cast("dict[str, t.Any]", response.json())

    # =========================================================================
    # Organization
    # =========================================================================

    def get_organization(self, org: str) -> Organization:
        """GET /api/org/{org} - Get org details."""
        response = self.request("GET", f"/org/{org}")
        return Organization(**response.json())

    def list_user_organizations(self) -> list[Organization]:
        """GET /api/user/organizations - List organizations visible to the current user."""
        response = self.request("GET", "/user/organizations")
        return [Organization(**org) for org in response.json()]

    def list_organization_workspaces(self, org: str) -> list[Workspace]:
        """GET /api/org/{org}/ws - List workspaces in an organization."""
        response = self.request("GET", f"/org/{org}/ws")
        data = response.json()
        items = data.get("workspaces", data) if isinstance(data, dict) else data
        return [Workspace(**ws) for ws in items]

    def list_workspaces(self, org: str) -> list[Workspace]:
        """Compatibility alias for list_organization_workspaces()."""
        return self.list_organization_workspaces(org)

    # =========================================================================
    # Packages - Type Aliases
    # =========================================================================

    def list_datasets(self, org: str) -> list[Package]:
        """GET /api/org/{org}/datasets - List datasets."""
        response = self.request("GET", f"/org/{org}/datasets")
        return [Package(**p) for p in response.json()]

    def get_dataset(self, org: str, name: str) -> Package:
        """GET /api/org/{org}/datasets/{name} - Get dataset details."""
        response = self.request("GET", f"/org/{org}/datasets/{name}")
        return Package(**response.json())

    def list_agents(self, org: str) -> list[Package]:
        """GET /api/org/{org}/agents - List agents."""
        response = self.request("GET", f"/org/{org}/agents")
        return [Package(**p) for p in response.json()]

    def get_agent(self, org: str, name: str) -> Package:
        """GET /api/org/{org}/agents/{name} - Get agent details."""
        response = self.request("GET", f"/org/{org}/agents/{name}")
        return Package(**response.json())

    def list_models(self, org: str) -> list[Package]:
        """GET /api/org/{org}/models - List models."""
        response = self.request("GET", f"/org/{org}/models")
        return [Package(**p) for p in response.json()]

    def get_model(self, org: str, name: str) -> Package:
        response = self.request("GET", f"/org/{org}/models/{name}")
        return Package(**response.json())

    @staticmethod
    def _normalize_package_type(package_type: str) -> str:
        """Normalize legacy package type aliases to the main API values."""
        return "toolsets" if package_type == "tools" else package_type

    def list_org_packages(self, org: str, package_type: str) -> list[Package]:
        """GET /api/org/{org}/packages/{package_type} - List organization packages.

        Args:
            org: Organization key.
            package_type: Package type (datasets, models, agents, tools, environments).

        Returns:
            List of Package objects.
        """
        normalized_package_type = self._normalize_package_type(package_type)
        response = self.request("GET", f"/org/{org}/packages/{normalized_package_type}")
        return [Package(**package) for package in response.json()]

    # =========================================================================
    # Storage
    # =========================================================================

    def get_storage_access(self, org: str, key: str) -> StorageCredentials:
        """GET /org/{org}/ws/{key}/storage/credentials - Get credentials."""
        response = self.request("GET", f"/org/{org}/ws/{key}/storage/credentials")
        return StorageCredentials(**response.json())

    # =========================================================================
    # Workspace
    # =========================================================================

    def get_workspace(self, org: str, workspace: str) -> Workspace:
        """GET /org/{org}/ws/{workspace} - Get workspace details."""
        response = self.request("GET", f"/org/{org}/ws/{workspace}")
        return Workspace(**response.json())

    # =========================================================================
    # Projects
    # =========================================================================

    def list_projects(self, org: str, workspace: str) -> list[Project]:
        """GET /org/{org}/ws/{workspace}/projects - List projects."""
        response = self.request("GET", f"/org/{org}/ws/{workspace}/projects")
        return [Project(**p) for p in response.json()]

    def get_default_project_key(self, org: str, workspace: str) -> str | None:
        """Return the default project key for a workspace, falling back to the first project."""
        projects = self.list_projects(org, workspace)
        for project in projects:
            if project.is_default or project.key == "default":
                return project.key
        return projects[0].key if projects else None

    def get_project(self, org: str, workspace: str, project: str) -> Project:
        """GET /org/{org}/ws/{workspace}/projects/{project} - Get project details."""
        response = self.request("GET", f"/org/{org}/ws/{workspace}/projects/{project}")
        return Project(**response.json())

    def create_project(
        self,
        org: str,
        workspace: str,
        name: str,
        key: str,
        description: str | None = None,
    ) -> Project:
        """POST /org/{org}/ws/{workspace}/projects - Create a new project."""
        payload: dict[str, t.Any] = {"name": name, "key": key}
        if description:
            payload["description"] = description
        response = self.request("POST", f"/org/{org}/ws/{workspace}/projects", json_data=payload)
        return Project(**response.json())

    # =========================================================================
    # OCI Registry
    # =========================================================================

    @property
    def oci_registry_url(self) -> str:
        """Get the OCI Distribution v2 registry URL."""
        return f"{self._server_root_url}/v2"

    @property
    def oci_basic_auth(self) -> tuple[str, str] | None:
        """Get basic auth credentials for OCI registry."""
        if self._api_key:
            return ("__token__", self._api_key)
        return None

    # =========================================================================
    # Trace Endpoints
    # =========================================================================

    def execute_workspace_query(
        self,
        org: str,
        workspace: str,
        query: str,
        *,
        project_id: str | None = None,
        max_rows: int = 10_000,
    ) -> dict[str, t.Any]:
        """POST /org/{org}/ws/{workspace}/query - Execute a workspace-scoped OTEL query."""
        payload: dict[str, t.Any] = {"query": query, "max_rows": max_rows}
        if project_id is not None:
            payload["project_id"] = project_id
        response = self.request(
            "POST",
            f"/org/{org}/ws/{workspace}/query",
            json_data=payload,
        )
        return t.cast("dict[str, t.Any]", response.json())

    @staticmethod
    def _raise_query_exception(result: dict[str, t.Any]) -> None:
        """Raise a RuntimeError if the query endpoint returned an exception payload."""
        exception = result.get("exception")
        if exception:
            raise RuntimeError(str(exception))

    def get_trace_spans(
        self,
        org: str,
        workspace: str,
        project: str,
        trace_id: str,
        *,
        limit: int = 100,
        offset: int = 0,
        order_by: str = "Timestamp",
        order_dir: str = "ASC",
    ) -> dict[str, t.Any]:
        """Get paginated spans for a trace from remote storage.

        Args:
            org: Organization key.
            workspace: Workspace key.
            project: Project key.
            trace_id: Trace identifier.
            limit: Number of spans per page (1-1000).
            offset: Number of spans to skip.
            order_by: Column to sort by.
            order_dir: Sort direction (ASC or DESC).

        Returns:
            Dict with 'data', 'rows', and 'meta' keys.
        """
        response = self.request(
            "GET",
            f"/org/{org}/ws/{workspace}/traces/{trace_id}/spans",
            params={
                "limit": limit,
                "offset": offset,
                "order_by": order_by,
                "order_dir": order_dir,
            },
        )
        return t.cast("dict[str, t.Any]", response.json())

    def get_run_spans(
        self,
        org: str,
        workspace: str,
        project: str,
        run_id: str,
        *,
        limit: int = 100,
        offset: int = 0,
        order_by: str = "Timestamp",
        order_dir: str = "ASC",
    ) -> dict[str, t.Any]:
        """Compatibility alias for get_trace_spans()."""
        return self.get_trace_spans(
            org,
            workspace,
            project,
            run_id,
            limit=limit,
            offset=offset,
            order_by=order_by,
            order_dir=order_dir,
        )

    def get_trace_stats(
        self,
        org: str,
        workspace: str,
        project: str,
        trace_id: str,
    ) -> dict[str, t.Any]:
        """Get aggregated statistics for a trace from remote storage.

        Args:
            org: Organization key.
            workspace: Workspace key.
            project: Project key.
            trace_id: Trace identifier.

        Returns:
            Dict with trace statistics (total_spans, error_spans, duration, etc.).
        """
        response = self.request(
            "GET",
            f"/org/{org}/ws/{workspace}/traces/{trace_id}/stats",
        )
        return t.cast("dict[str, t.Any]", response.json())

    def get_run_stats(
        self,
        org: str,
        workspace: str,
        project: str,
        run_id: str,
    ) -> dict[str, t.Any]:
        """Compatibility alias for get_trace_stats()."""
        return self.get_trace_stats(org, workspace, project, run_id)

    def list_traces(
        self,
        org: str,
        workspace: str,
        project: str | None,
        *,
        page: int = 1,
        page_size: int = 50,
        span_type: str | None = None,
    ) -> dict[str, t.Any]:
        """List workspace traces with explicit filters.

        Returns:
            Dict with 'traces', 'total', 'page', 'limit', 'total_pages',
            'has_next', 'has_previous'.
        """
        params: dict[str, t.Any] = {"page": page, "page_size": page_size}
        if project is not None:
            project_record = self.get_project(org, workspace, project)
            params["project_id"] = project_record.id
        if span_type is not None:
            params["span_type"] = span_type
        response = self.request(
            "GET",
            f"/org/{org}/ws/{workspace}/traces",
            params=params,
        )
        return t.cast("dict[str, t.Any]", response.json())

    def get_trace(
        self,
        org: str,
        workspace: str,
        project: str | None,
        trace_id: str,
    ) -> dict[str, t.Any]:
        """Get root trace details for a workspace-visible trace."""
        _ = project
        response = self.request(
            "GET",
            f"/org/{org}/ws/{workspace}/traces/{trace_id}",
        )
        return t.cast("dict[str, t.Any]", response.json())

    # =========================================================================
    # Sandboxes
    # =========================================================================

    def list_sandboxes(
        self,
        org: str,
        *,
        state: str | list[str] | None = None,
        project_id: str | None = None,
        limit: int = 50,
        cursor: str | None = None,
    ) -> dict[str, t.Any]:
        """GET /org/{org}/sandboxes - List sandboxes.

        Returns:
            Dict with 'items' (list of sandbox dicts) and 'next_cursor'.
        """
        params: dict[str, t.Any] = {"limit": limit}
        if state is not None:
            params["state"] = ",".join(state) if isinstance(state, list) else state
        if project_id is not None:
            params["project_id"] = project_id
        if cursor is not None:
            params["cursor"] = cursor
        response = self.request("GET", f"/org/{org}/sandboxes", params=params)
        return t.cast("dict[str, t.Any]", response.json())

    def provision_sandbox(
        self,
        org: str,
        build_id: str,
        *,
        project_id: str | None = None,
        workspace_key: str | None = None,
        secret_ids: list[str] | None = None,
    ) -> dict[str, t.Any]:
        """POST /org/{org}/sandboxes - Provision a sandbox."""
        payload: dict[str, t.Any] = {"build_id": build_id}
        if project_id is not None:
            payload["project_id"] = project_id
        if workspace_key is not None:
            payload["workspace_key"] = workspace_key
        if secret_ids is not None:
            payload["secret_ids"] = secret_ids
        response = self.request("POST", f"/org/{org}/sandboxes", json_data=payload)
        return t.cast("dict[str, t.Any]", response.json())

    # =========================================================================
    # Runtimes
    # =========================================================================

    def list_runtimes(
        self,
        org: str,
        workspace: str,
        *,
        state: str | list[str] | None = None,
        project_id: str | None = None,
        limit: int = 50,
        cursor: str | None = None,
    ) -> dict[str, t.Any]:
        """GET /org/{org}/ws/{workspace}/runtimes - List interactive runtimes."""
        params: dict[str, t.Any] = {"limit": limit}
        if state is not None:
            params["state"] = ",".join(state) if isinstance(state, list) else state
        if project_id is not None:
            params["project_id"] = project_id
        if cursor is not None:
            params["cursor"] = cursor
        response = self.request(
            "GET",
            f"/org/{org}/ws/{workspace}/runtimes",
            params=params,
        )
        return t.cast("dict[str, t.Any]", response.json())

    def get_runtime(self, org: str, workspace: str, runtime_id: str) -> dict[str, t.Any]:
        """GET /org/{org}/ws/{workspace}/runtimes/{runtime_id} - Get runtime details."""
        response = self.request(
            "GET",
            f"/org/{org}/ws/{workspace}/runtimes/{runtime_id}",
        )
        return t.cast("dict[str, t.Any]", response.json())

    def pause_runtime(self, org: str, workspace: str, runtime_id: str) -> dict[str, t.Any]:
        """POST /org/{org}/ws/{workspace}/runtimes/{runtime_id}/pause - Pause a runtime."""
        response = self.request(
            "POST",
            f"/org/{org}/ws/{workspace}/runtimes/{runtime_id}/pause",
        )
        return t.cast("dict[str, t.Any]", response.json())

    def resume_runtime(self, org: str, workspace: str, runtime_id: str) -> dict[str, t.Any]:
        """POST /org/{org}/ws/{workspace}/runtimes/{runtime_id}/resume - Resume a runtime."""
        response = self.request(
            "POST",
            f"/org/{org}/ws/{workspace}/runtimes/{runtime_id}/resume",
        )
        return t.cast("dict[str, t.Any]", response.json())

    def delete_runtime(self, org: str, workspace: str, runtime_id: str) -> None:
        """DELETE /org/{org}/ws/{workspace}/runtimes/{runtime_id} - Delete a runtime."""
        self.request("DELETE", f"/org/{org}/ws/{workspace}/runtimes/{runtime_id}")

    def keepalive_runtime(
        self,
        org: str,
        workspace: str,
        runtime_id: str,
        *,
        extend_seconds: int = 300,
    ) -> dict[str, t.Any]:
        """POST /org/{org}/ws/{workspace}/runtimes/{runtime_id}/keepalive - Extend timeout."""
        response = self.request(
            "POST",
            f"/org/{org}/ws/{workspace}/runtimes/{runtime_id}/keepalive",
            json_data={"extend_seconds": extend_seconds},
        )
        return t.cast("dict[str, t.Any]", response.json())

    def pause_sandbox(self, org: str, sandbox_id: str) -> dict[str, t.Any]:
        """POST /org/{org}/sandboxes/{sandbox_id}/pause - Pause a sandbox."""
        response = self.request("POST", f"/org/{org}/sandboxes/{sandbox_id}/pause")
        return t.cast("dict[str, t.Any]", response.json())

    def resume_sandbox(self, org: str, sandbox_id: str) -> dict[str, t.Any]:
        """POST /org/{org}/sandboxes/{sandbox_id}/resume - Resume a sandbox."""
        response = self.request("POST", f"/org/{org}/sandboxes/{sandbox_id}/resume")
        return t.cast("dict[str, t.Any]", response.json())

    def delete_sandbox(self, org: str, sandbox_id: str) -> None:
        """DELETE /org/{org}/sandboxes/{sandbox_id} - Delete (kill) a sandbox."""
        self.request("DELETE", f"/org/{org}/sandboxes/{sandbox_id}")

    def keepalive_sandbox(
        self, org: str, sandbox_id: str, *, extend_seconds: int = 300
    ) -> dict[str, t.Any]:
        """POST /org/{org}/sandboxes/{sandbox_id}/keepalive - Extend sandbox timeout.

        Returns:
            Dict with 'expires_at' (new expiration timestamp).
        """
        response = self.request(
            "POST",
            f"/org/{org}/sandboxes/{sandbox_id}/keepalive",
            json_data={"extend_seconds": extend_seconds},
        )
        return t.cast("dict[str, t.Any]", response.json())

    # =========================================================================
    # Evaluations
    # =========================================================================

    def list_evaluation_jobs(
        self,
        org: str,
        workspace: str,
        *,
        page: int = 1,
        page_size: int = 50,
        project_id: str | None = None,
        status: str | None = None,
    ) -> dict[str, t.Any]:
        """GET /org/{org}/ws/{workspace}/evaluations - List evaluation jobs.

        Returns:
            Dict with 'items', 'total', 'page', 'page_size'.
        """
        params: dict[str, t.Any] = {"page": page, "page_size": page_size}
        if project_id is not None:
            params["project_id"] = project_id
        if status is not None:
            params["status"] = status
        response = self.request(
            "GET",
            f"/org/{org}/ws/{workspace}/evaluations",
            params=params,
        )
        return t.cast("dict[str, t.Any]", response.json())

    def cancel_evaluation(self, org: str, workspace: str, evaluation_id: str) -> dict[str, t.Any]:
        """POST /org/{org}/ws/{workspace}/evaluation/{id}/cancel - Cancel an evaluation."""
        response = self.request(
            "POST",
            f"/org/{org}/ws/{workspace}/evaluation/{evaluation_id}/cancel",
        )
        return t.cast("dict[str, t.Any]", response.json())

    def retry_failed_evaluation(
        self, org: str, workspace: str, evaluation_id: str
    ) -> dict[str, t.Any]:
        """POST /org/{org}/ws/{workspace}/evaluation/{id}/retry-failed - Retry failed items."""
        response = self.request(
            "POST",
            f"/org/{org}/ws/{workspace}/evaluation/{evaluation_id}/retry-failed",
        )
        return t.cast("dict[str, t.Any]", response.json())

    # =========================================================================
    # Training
    # =========================================================================

    def create_training_job(
        self,
        org: str,
        workspace: str,
        request: TrainingJobCreateRequest | dict[str, t.Any],
    ) -> TrainingJob:
        """POST /org/{org}/ws/{workspace}/training/jobs - Create a training job."""
        json_data: dict[str, t.Any]
        if isinstance(request, CreateTrainingJobBase):
            json_data = request.model_dump(mode="json", exclude_none=True)
        else:
            json_data = request
        response = self.request(
            "POST",
            f"/org/{org}/ws/{workspace}/training/jobs",
            json_data=json_data,
        )
        return TrainingJob(**response.json())

    def list_training_jobs(
        self,
        org: str,
        workspace: str,
        *,
        page: int = 1,
        page_size: int = 20,
        status: str | None = None,
        backend: str | None = None,
        trainer_type: str | None = None,
        project_ref: str | None = None,
    ) -> TrainingJobList:
        """GET /org/{org}/ws/{workspace}/training/jobs - List training jobs."""
        params: dict[str, t.Any] = {"page": page, "page_size": page_size}
        if status is not None:
            params["status"] = status
        if backend is not None:
            params["backend"] = backend
        if trainer_type is not None:
            params["trainer_type"] = trainer_type
        if project_ref is not None:
            params["project_ref"] = project_ref
        response = self.request(
            "GET",
            f"/org/{org}/ws/{workspace}/training/jobs",
            params=params,
        )
        return TrainingJobList(**response.json())

    def get_training_job(self, org: str, workspace: str, job_id: str) -> TrainingJob:
        """GET /org/{org}/ws/{workspace}/training/jobs/{job_id} - Get a training job."""
        response = self.request(
            "GET",
            f"/org/{org}/ws/{workspace}/training/jobs/{job_id}",
        )
        return TrainingJob(**response.json())

    def cancel_training_job(self, org: str, workspace: str, job_id: str) -> TrainingJob:
        """POST /org/{org}/ws/{workspace}/training/jobs/{job_id}/cancel - Cancel a training job."""
        response = self.request(
            "POST",
            f"/org/{org}/ws/{workspace}/training/jobs/{job_id}/cancel",
        )
        return TrainingJob(**response.json())

    def retry_training_job(self, org: str, workspace: str, job_id: str) -> TrainingJob:
        """POST /org/{org}/ws/{workspace}/training/jobs/{job_id}/retry - Retry a training job."""
        response = self.request(
            "POST",
            f"/org/{org}/ws/{workspace}/training/jobs/{job_id}/retry",
        )
        return TrainingJob(**response.json())

    def list_training_job_logs(self, org: str, workspace: str, job_id: str) -> TrainingJobLogList:
        """GET /org/{org}/ws/{workspace}/training/jobs/{job_id}/logs - List training logs."""
        response = self.request(
            "GET",
            f"/org/{org}/ws/{workspace}/training/jobs/{job_id}/logs",
        )
        return TrainingJobLogList(**response.json())

    def get_training_job_artifacts(
        self, org: str, workspace: str, job_id: str
    ) -> TrainingJobArtifacts:
        """GET /org/{org}/ws/{workspace}/training/jobs/{job_id}/artifacts - Get training artifacts."""
        response = self.request(
            "GET",
            f"/org/{org}/ws/{workspace}/training/jobs/{job_id}/artifacts",
        )
        return TrainingJobArtifacts(**response.json())

    # =========================================================================
    # Capabilities
    # =========================================================================

    def list_capabilities(
        self,
        org: str,
        *,
        name: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> dict[str, t.Any]:
        """GET /org/{org}/capabilities - List capability artifacts."""
        params: dict[str, t.Any] = {"limit": limit, "offset": offset}
        if name is not None:
            params["name"] = name
        response = self.request("GET", f"/org/{org}/capabilities", params=params)
        return t.cast("dict[str, t.Any]", response.json())

    def list_capability_versions(self, org: str, name: str) -> dict[str, t.Any]:
        """GET /org/{org}/capabilities/{name}/versions - List all versions."""
        response = self.request("GET", f"/org/{org}/capabilities/{name}/versions")
        return t.cast("dict[str, t.Any]", response.json())

    def get_capability(self, org: str, name: str, version: str) -> dict[str, t.Any]:
        """GET /org/{org}/capabilities/{name}/{version} - Get artifact detail."""
        response = self.request("GET", f"/org/{org}/capabilities/{name}/{version}")
        return t.cast("dict[str, t.Any]", response.json())

    def get_capability_file(self, org: str, name: str, version: str, file_path: str) -> bytes:
        """GET /org/{org}/capabilities/{name}/{version}/files/{path} - Download file."""
        response = self.request(
            "GET", f"/org/{org}/capabilities/{name}/{version}/files/{file_path}"
        )
        return response.content

    def delete_capability(self, org: str, name: str, version: str) -> None:
        """DELETE /org/{org}/capabilities/{name}/{version} - Delete artifact."""
        self.request("DELETE", f"/org/{org}/capabilities/{name}/{version}")

    def list_public_capabilities(
        self,
        *,
        name: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> dict[str, t.Any]:
        """GET /capabilities - List public catalog capabilities."""
        params: dict[str, t.Any] = {"limit": limit, "offset": offset}
        if name is not None:
            params["name"] = name
        response = self.request("GET", "/capabilities", params=params)
        return t.cast("dict[str, t.Any]", response.json())

    def get_public_capability(self, owner: str, name: str, version: str) -> dict[str, t.Any]:
        """GET /capabilities/{owner}/{name}/{version} - Get public capability detail."""
        response = self.request("GET", f"/capabilities/{owner}/{name}/{version}")
        return t.cast("dict[str, t.Any]", response.json())

    def get_public_capability_file(
        self,
        owner: str,
        name: str,
        version: str,
        file_path: str,
    ) -> bytes:
        """GET /capabilities/{owner}/{name}/{version}/files/{path} - Download public file."""
        response = self.request(
            "GET",
            f"/capabilities/{owner}/{name}/{version}/files/{file_path}",
        )
        return response.content

    def list_project_capabilities(
        self, org: str, workspace: str, project: str
    ) -> dict[str, t.Any]:
        """GET /org/{org}/ws/{workspace}/projects/{project}/capabilities - List bindings."""
        response = self.request(
            "GET",
            f"/org/{org}/ws/{workspace}/projects/{project}/capabilities",
        )
        return t.cast("dict[str, t.Any]", response.json())

    def install_project_capability(
        self,
        org: str,
        workspace: str,
        project: str,
        *,
        name: str,
        version: str | None = None,
    ) -> dict[str, t.Any]:
        """POST /org/{org}/ws/{workspace}/projects/{project}/capabilities."""
        payload: dict[str, t.Any] = {"name": name}
        if version is not None:
            payload["version"] = version
        response = self.request(
            "POST",
            f"/org/{org}/ws/{workspace}/projects/{project}/capabilities",
            json_data=payload,
        )
        return t.cast("dict[str, t.Any]", response.json())

    def toggle_project_capability(
        self,
        org: str,
        workspace: str,
        project: str,
        binding_id: str,
        *,
        enabled: bool,
    ) -> dict[str, t.Any]:
        """PATCH /org/{org}/ws/{workspace}/projects/{project}/capabilities/{binding_id}."""
        response = self.request(
            "PATCH",
            f"/org/{org}/ws/{workspace}/projects/{project}/capabilities/{binding_id}",
            json_data={"enabled": enabled},
        )
        return t.cast("dict[str, t.Any]", response.json())

    def update_project_capability(
        self,
        org: str,
        workspace: str,
        project: str,
        binding_id: str,
        *,
        version: str,
    ) -> dict[str, t.Any]:
        """PATCH /org/{org}/ws/{workspace}/projects/{project}/capabilities/{binding_id}."""
        response = self.request(
            "PATCH",
            f"/org/{org}/ws/{workspace}/projects/{project}/capabilities/{binding_id}",
            json_data={"version": version},
        )
        return t.cast("dict[str, t.Any]", response.json())

    def uninstall_project_capability(
        self, org: str, workspace: str, project: str, binding_id: str
    ) -> None:
        """DELETE /org/{org}/ws/{workspace}/projects/{project}/capabilities/{binding_id}."""
        self.request(
            "DELETE",
            f"/org/{org}/ws/{workspace}/projects/{project}/capabilities/{binding_id}",
        )

    def get_project_capabilities_resolved(
        self, org: str, workspace: str, project: str
    ) -> dict[str, t.Any]:
        """GET /org/{org}/ws/{workspace}/projects/{project}/capabilities/resolved."""
        response = self.request(
            "GET",
            f"/org/{org}/ws/{workspace}/projects/{project}/capabilities/resolved",
        )
        return t.cast("dict[str, t.Any]", response.json())

    # =========================================================================
    # Tasks
    # =========================================================================

    def list_tasks(
        self,
        org: str,
        *,
        page: int = 1,
        limit: int = 50,
        category: str | None = None,
        difficulty: str | None = None,
        tags: str | None = None,
        search: str | None = None,
    ) -> dict[str, t.Any]:
        """GET /org/{org}/tasks - List tasks."""
        params: dict[str, t.Any] = {}
        params["page"] = page
        params["limit"] = limit
        if category is not None:
            params["category"] = category
        if difficulty is not None:
            params["difficulty"] = difficulty
        if tags is not None:
            params["tags"] = tags
        if search is not None:
            params["search"] = search
        response = self.request("GET", f"/org/{org}/tasks", params=params)
        return t.cast("dict[str, t.Any]", response.json())

    def get_task(self, org: str, name: str) -> dict[str, t.Any]:
        """GET /org/{org}/tasks/{name} - Get task details."""
        response = self.request("GET", f"/org/{org}/tasks/{name}")
        return t.cast("dict[str, t.Any]", response.json())

    def get_task_instruction(
        self,
        org: str,
        task_name: str,
        *,
        sandbox_id: str | None = None,
    ) -> dict[str, t.Any]:
        """GET /org/{org}/tasks/{task_name}/instruction - Get task instructions."""
        params = {"sandbox_id": sandbox_id} if sandbox_id is not None else None
        response = self.request(
            "GET",
            f"/org/{org}/tasks/{task_name}/instruction",
            params=params,
        )
        return t.cast("dict[str, t.Any]", response.json())

    # =========================================================================
    # Sessions (platform)
    # =========================================================================

    def save_session(
        self,
        org: str,
        workspace: str,
        session_id: str,
        model: str,
        *,
        title: str | None = None,
        message_count: int = 0,
        project_id: str | None = None,
    ) -> dict[str, t.Any]:
        """POST /org/{org}/ws/{workspace}/sessions - Create or save a session."""
        payload: dict[str, t.Any] = {
            "id": session_id,
            "model": model,
            "message_count": message_count,
        }
        if title is not None:
            payload["title"] = title
        if project_id is not None:
            payload["project_id"] = project_id
        response = self.request("POST", f"/org/{org}/ws/{workspace}/sessions", json_data=payload)
        return t.cast("dict[str, t.Any]", response.json())

    def update_session(
        self,
        org: str,
        workspace: str,
        session_id: str,
        *,
        title: str | None = None,
        message_count: int | None = None,
    ) -> dict[str, t.Any]:
        """PATCH /org/{org}/ws/{workspace}/sessions/{session_id} - Update a session."""
        payload: dict[str, t.Any] = {}
        if title is not None:
            payload["title"] = title
        if message_count is not None:
            payload["message_count"] = message_count
        response = self.request(
            "PATCH",
            f"/org/{org}/ws/{workspace}/sessions/{session_id}",
            json_data=payload,
        )
        return t.cast("dict[str, t.Any]", response.json())

    def list_sessions(
        self,
        org: str,
        workspace: str,
        *,
        page: int = 1,
        page_size: int = 20,
        project_id: str | None = None,
    ) -> dict[str, t.Any]:
        """GET /org/{org}/ws/{workspace}/sessions - List sessions."""
        params: dict[str, t.Any] = {"page": page, "page_size": page_size}
        if project_id is not None:
            params["project_id"] = project_id
        response = self.request("GET", f"/org/{org}/ws/{workspace}/sessions", params=params)
        return t.cast("dict[str, t.Any]", response.json())

    def get_session(
        self,
        org: str,
        workspace: str,
        session_id: str,
        *,
        limit: int = 1000,
        after_sequence: int | None = None,
    ) -> dict[str, t.Any]:
        """GET /org/{org}/ws/{workspace}/sessions/{session_id} - Get session with events."""
        params: dict[str, t.Any] = {"limit": limit}
        if after_sequence is not None:
            params["after_sequence"] = after_sequence
        response = self.request(
            "GET",
            f"/org/{org}/ws/{workspace}/sessions/{session_id}",
            params=params,
        )
        return t.cast("dict[str, t.Any]", response.json())

    def ingest_session_events(
        self,
        org: str,
        workspace: str,
        session_id: str,
        events: list[dict[str, t.Any]],
        wal_offset: int,
    ) -> dict[str, t.Any]:
        """POST /org/{org}/ws/{workspace}/sessions/{session_id}/events - Ingest events."""
        response = self.request(
            "POST",
            f"/org/{org}/ws/{workspace}/sessions/{session_id}/events",
            json_data={"events": events, "wal_offset": wal_offset},
        )
        return t.cast("dict[str, t.Any]", response.json())

    # =========================================================================
    # AIRT (AI Red Teaming)
    # =========================================================================

    def create_airt_assessment(
        self,
        org: str,
        workspace: str,
        *,
        name: str,
        project_id: str,
        description: str | None = None,
        session_id: str | None = None,
        target_config: dict[str, t.Any] | None = None,
        attacker_config: dict[str, t.Any] | None = None,
        attack_manifest: dict[str, t.Any] | None = None,
        workflow_run_id: str | None = None,
        workflow_script: str | None = None,
    ) -> dict[str, t.Any]:
        """POST /org/{org}/ws/{workspace}/airt/assessments - Create an AIRT assessment."""
        payload: dict[str, t.Any] = {"name": name}
        if description is not None:
            payload["description"] = description
        if session_id is not None:
            payload["session_id"] = session_id
        if target_config is not None:
            payload["target_config"] = target_config
        if attacker_config is not None:
            payload["attacker_config"] = attacker_config
        if attack_manifest is not None:
            payload["attack_manifest"] = attack_manifest
        if workflow_run_id is not None:
            payload["workflow_run_id"] = workflow_run_id
        if workflow_script is not None:
            payload["workflow_script"] = workflow_script
        response = self.request(
            "POST",
            f"/org/{org}/ws/{workspace}/airt/assessments",
            json_data=payload,
            params={"project_id": project_id},
        )
        return t.cast("dict[str, t.Any]", response.json())

    def update_airt_assessment(
        self,
        org: str,
        workspace: str,
        assessment_id: str,
        *,
        status: str | None = None,
        name: str | None = None,
        description: str | None = None,
    ) -> dict[str, t.Any]:
        """PATCH /org/{org}/ws/{workspace}/airt/assessments/{id} - Update an AIRT assessment."""
        payload: dict[str, t.Any] = {}
        if status is not None:
            payload["status"] = status
        if name is not None:
            payload["name"] = name
        if description is not None:
            payload["description"] = description
        response = self.request(
            "PATCH",
            f"/org/{org}/ws/{workspace}/airt/assessments/{assessment_id}",
            json_data=payload,
        )
        return t.cast("dict[str, t.Any]", response.json())

    def register_airt_attack_run(
        self,
        org: str,
        workspace: str,
        assessment_id: str,
        *,
        attack_name: str,
        goal: str,
        goal_category: str | None = None,
        transforms_applied: list[str] | None = None,
        compliance_tags: dict[str, t.Any] | None = None,
        study_run_id: str | None = None,
        trace_id: str | None = None,
    ) -> dict[str, t.Any]:
        """POST /org/{org}/ws/{workspace}/airt/assessments/{id}/attacks - Register an attack run."""
        payload: dict[str, t.Any] = {"attack_name": attack_name, "goal": goal}
        if goal_category is not None:
            payload["goal_category"] = goal_category
        if transforms_applied is not None:
            payload["transforms_applied"] = transforms_applied
        if compliance_tags is not None:
            payload["compliance_tags"] = compliance_tags
        if study_run_id is not None:
            payload["study_run_id"] = study_run_id
        if trace_id is not None:
            payload["trace_id"] = trace_id
        response = self.request(
            "POST",
            f"/org/{org}/ws/{workspace}/airt/assessments/{assessment_id}/attacks",
            json_data=payload,
        )
        return t.cast("dict[str, t.Any]", response.json())

    def upload_airt_attack_result(
        self,
        org: str,
        workspace: str,
        assessment_id: str,
        run_id: str,
        *,
        attack_result_json: dict[str, t.Any],
        best_score: float | None = None,
        total_trials: int = 0,
        finished_trials: int = 0,
        execution_time_s: float | None = None,
        status: str = "completed",
    ) -> dict[str, t.Any]:
        """PUT /org/{org}/ws/{workspace}/airt/assessments/{id}/attacks/{run_id}/result - Upload result."""
        payload: dict[str, t.Any] = {
            "attack_result_json": attack_result_json,
            "total_trials": total_trials,
            "finished_trials": finished_trials,
            "status": status,
        }
        if best_score is not None:
            payload["best_score"] = best_score
        if execution_time_s is not None:
            payload["execution_time_s"] = execution_time_s
        response = self.request(
            "PUT",
            f"/org/{org}/ws/{workspace}/airt/assessments/{assessment_id}/attacks/{run_id}/result",
            json_data=payload,
        )
        return t.cast("dict[str, t.Any]", response.json())

    def upload_airt_analytics(
        self,
        org: str,
        workspace: str,
        assessment_id: str,
        *,
        analytics_snapshot: dict[str, t.Any],
    ) -> dict[str, t.Any]:
        """POST /org/{org}/ws/{workspace}/airt/assessments/{id}/analytics - Upload analytics snapshot."""
        response = self.request(
            "POST",
            f"/org/{org}/ws/{workspace}/airt/assessments/{assessment_id}/analytics",
            json_data={"analytics_snapshot": analytics_snapshot},
        )
        return t.cast("dict[str, t.Any]", response.json())

    def upload_airt_report(
        self,
        org: str,
        workspace: str,
        assessment_id: str,
        *,
        report_type: str,
        content: str | None = None,
        content_json: dict[str, t.Any] | None = None,
    ) -> dict[str, t.Any]:
        """POST /org/{org}/ws/{workspace}/airt/assessments/{id}/reports - Upload a report."""
        payload: dict[str, t.Any] = {"report_type": report_type}
        if content is not None:
            payload["content"] = content
        if content_json is not None:
            payload["content_json"] = content_json
        response = self.request(
            "POST",
            f"/org/{org}/ws/{workspace}/airt/assessments/{assessment_id}/reports",
            json_data=payload,
        )
        return t.cast("dict[str, t.Any]", response.json())

    def get_airt_assessment(
        self,
        org: str,
        workspace: str,
        assessment_id: str,
    ) -> dict[str, t.Any]:
        """GET /org/{org}/ws/{workspace}/airt/assessments/{id} - Get assessment details."""
        response = self.request(
            "GET", f"/org/{org}/ws/{workspace}/airt/assessments/{assessment_id}"
        )
        return t.cast("dict[str, t.Any]", response.json())

    def list_airt_assessments(
        self,
        org: str,
        workspace: str,
        *,
        project_id: str | None = None,
        page: int = 1,
        page_size: int = 50,
    ) -> dict[str, t.Any]:
        """GET /org/{org}/ws/{workspace}/airt/assessments - List assessments."""
        params: dict[str, t.Any] = {"page": page, "page_size": page_size}
        if project_id is not None:
            params["project_id"] = project_id
        response = self.request("GET", f"/org/{org}/ws/{workspace}/airt/assessments", params=params)
        return t.cast("dict[str, t.Any]", response.json())

    def delete_airt_assessment(self, org: str, workspace: str, assessment_id: str) -> None:
        """DELETE /org/{org}/ws/{workspace}/airt/assessments/{id}."""
        self.request(
            "DELETE",
            f"/org/{org}/ws/{workspace}/airt/assessments/{assessment_id}",
        )

    def list_airt_reports(
        self, org: str, workspace: str, assessment_id: str
    ) -> list[dict[str, t.Any]]:
        """GET /org/{org}/ws/{workspace}/airt/assessments/{id}/reports."""
        response = self.request(
            "GET",
            f"/org/{org}/ws/{workspace}/airt/assessments/{assessment_id}/reports",
        )
        return t.cast("list[dict[str, t.Any]]", response.json())

    def get_airt_report(
        self, org: str, workspace: str, assessment_id: str, report_id: str
    ) -> dict[str, t.Any]:
        """GET /org/{org}/ws/{workspace}/airt/assessments/{id}/reports/{rid}."""
        response = self.request(
            "GET",
            f"/org/{org}/ws/{workspace}/airt/assessments/{assessment_id}/reports/{report_id}",
        )
        return t.cast("dict[str, t.Any]", response.json())

    def get_airt_analytics(self, org: str, workspace: str, assessment_id: str) -> dict[str, t.Any]:
        """GET /org/{org}/ws/{workspace}/airt/assessments/{id}/analytics."""
        response = self.request(
            "GET",
            f"/org/{org}/ws/{workspace}/airt/assessments/{assessment_id}/analytics",
        )
        return t.cast("dict[str, t.Any]", response.json())

    def get_airt_trace_stats(
        self, org: str, workspace: str, assessment_id: str
    ) -> dict[str, t.Any]:
        """GET /org/{org}/ws/{workspace}/airt/assessments/{id}/traces."""
        response = self.request(
            "GET",
            f"/org/{org}/ws/{workspace}/airt/assessments/{assessment_id}/traces",
        )
        return t.cast("dict[str, t.Any]", response.json())

    def get_airt_attack_spans(
        self, org: str, workspace: str, assessment_id: str
    ) -> list[dict[str, t.Any]]:
        """GET /org/{org}/ws/{workspace}/airt/assessments/{id}/traces/attacks."""
        response = self.request(
            "GET",
            f"/org/{org}/ws/{workspace}/airt/assessments/{assessment_id}/traces/attacks",
        )
        return t.cast("list[dict[str, t.Any]]", response.json())

    def get_airt_trial_spans(
        self,
        org: str,
        workspace: str,
        assessment_id: str,
        *,
        attack_name: str | None = None,
        min_score: float | None = None,
        jailbreaks_only: bool = False,
        limit: int = 100,
    ) -> list[dict[str, t.Any]]:
        """GET /org/{org}/ws/{workspace}/airt/assessments/{id}/traces/trials."""
        params: dict[str, t.Any] = {"limit": limit}
        if attack_name is not None:
            params["attack_name"] = attack_name
        if min_score is not None:
            params["min_score"] = min_score
        if jailbreaks_only:
            params["jailbreaks_only"] = True
        response = self.request(
            "GET",
            f"/org/{org}/ws/{workspace}/airt/assessments/{assessment_id}/traces/trials",
            params=params,
        )
        return t.cast("list[dict[str, t.Any]]", response.json())

    def get_airt_project_summary(self, org: str, workspace: str, project: str) -> dict[str, t.Any]:
        """GET /org/{org}/ws/{workspace}/airt/projects/{project}/summary."""
        response = self.request(
            "GET",
            f"/org/{org}/ws/{workspace}/airt/projects/{project}/summary",
        )
        return t.cast("dict[str, t.Any]", response.json())

    def get_airt_project_findings(
        self,
        org: str,
        workspace: str,
        project: str,
        *,
        severity: str | None = None,
        category: str | None = None,
        attack_name: str | None = None,
        min_score: float | None = None,
        sort_by: str = "score",
        sort_dir: str = "desc",
        page: int = 1,
        page_size: int = 50,
    ) -> dict[str, t.Any]:
        """GET /org/{org}/ws/{workspace}/airt/projects/{project}/findings."""
        params: dict[str, t.Any] = {
            "sort_by": sort_by,
            "sort_dir": sort_dir,
            "page": page,
            "page_size": page_size,
        }
        if severity is not None:
            params["severity"] = severity
        if category is not None:
            params["category"] = category
        if attack_name is not None:
            params["attack_name"] = attack_name
        if min_score is not None:
            params["min_score"] = min_score
        response = self.request(
            "GET",
            f"/org/{org}/ws/{workspace}/airt/projects/{project}/findings",
            params=params,
        )
        return t.cast("dict[str, t.Any]", response.json())

    def generate_airt_project_report(
        self,
        org: str,
        workspace: str,
        project: str,
        *,
        fmt: str = "both",
        model_profile: str | None = None,
    ) -> dict[str, t.Any]:
        """POST /org/{org}/ws/{workspace}/airt/projects/{project}/reports/generate."""
        payload: dict[str, t.Any] = {"format": fmt}
        if model_profile is not None:
            payload["model_profile"] = model_profile
        response = self.request(
            "POST",
            f"/org/{org}/ws/{workspace}/airt/projects/{project}/reports/generate",
            json_data=payload,
        )
        return t.cast("dict[str, t.Any]", response.json())


def create_api_client(*, profile: str | None = None) -> ApiClient:
    """Create an authenticated API client using stored API key configuration data."""
    from dreadnode.app.server.session import UserConfig

    user_config = UserConfig.read()
    api_config = user_config.get_server_config(profile)

    if not api_config.api_key:
        raise RuntimeError("API key missing, use [bold]dreadnode login <api-key>[/]")

    return ApiClient(api_config.url, api_key=api_config.api_key)
