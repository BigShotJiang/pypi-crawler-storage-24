"""Pydantic models for the server API."""

from __future__ import annotations

import typing as t

if t.TYPE_CHECKING:
    from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field

# API Models - Complete models for all documented API routes.
# This module contains Pydantic models for all API responses defined in
# API_ROUTES.md, plus additional models used by the SDK for runs, tasks,
# traces, and objects.

AnyDict = dict[str, t.Any]

# -----------------------------------------------------------------------------
# Type Aliases for Exports
# -----------------------------------------------------------------------------

ExportFormat = t.Literal["csv", "json", "jsonl", "parquet"]
"""Available export formats for traces and runs"""

StatusFilter = t.Literal["all", "completed", "failed"]
"""Filter for trace and run statuses"""

TimeAxisType = t.Literal["wall", "relative", "step"]
"""Type of time axis for traces and runs"""

TimeAggregationType = t.Literal["max", "min", "sum", "count"]
"""How to aggregate time in traces and runs"""

MetricAggregationType = t.Literal[
    "avg",
    "median",
    "min",
    "max",
    "sum",
    "first",
    "last",
    "count",
    "std",
    "var",
]
"""How to aggregate metrics in traces and runs"""

# -----------------------------------------------------------------------------
# Health & Config
# -----------------------------------------------------------------------------


class AppConfig(BaseModel):
    """Application configuration returned by /api/config."""

    version: str
    """API version."""
    features: dict[str, bool] = Field(default_factory=dict)
    """Feature flags."""


class HealthCheck(BaseModel):
    """Health check response."""

    status: str = "ok"
    """Health status."""


# -----------------------------------------------------------------------------
# User
# -----------------------------------------------------------------------------


class UserAPIKey(BaseModel):
    """User API key."""

    id: str
    """API key ID."""
    key: str | None = None
    """The API key value (only returned on creation)."""
    masked_key: str | None = None
    """Masked API key (returned by GET /user)."""
    active: bool = True
    """Whether the key is active."""
    name: str | None = None
    """Optional name for the key."""
    allowed_scopes: list[str] | None = None
    """Scopes allowed for this key."""
    created_at: datetime | None = None
    """When the key was created."""
    last_used_at: datetime | None = None
    """When the key was last used."""


class User(BaseModel):
    """Current user information."""

    id: str
    """User ID."""
    email_address: str
    """User's email address."""
    username: str
    """User's username."""


# -----------------------------------------------------------------------------
# Secrets
# -----------------------------------------------------------------------------


class UserSecret(BaseModel):
    """User secret details."""

    id: str
    """Secret ID."""
    name: str
    """Secret name."""
    provider: str | None = None
    """Provider associated with the secret, if any."""
    masked_value: str
    """Masked secret value."""
    created_at: str
    """Creation timestamp."""
    updated_at: str
    """Last update timestamp."""


class UserSecretsList(BaseModel):
    """Response wrapper for list of user secrets."""

    secrets: list[UserSecret]
    """List of user secrets."""
    total: int
    """Total number of secrets."""


class ProviderPreset(BaseModel):
    """Provider preset details."""

    provider: str
    """Provider name."""
    env_var_name: str
    """Environment variable name for the provider."""
    configured: bool
    """Whether the preset is configured for the user."""


class ProviderPresetsList(BaseModel):
    """Response wrapper for provider presets."""

    presets: list[ProviderPreset]
    """List of provider presets."""


# -----------------------------------------------------------------------------
# Organization
# -----------------------------------------------------------------------------


class Organization(BaseModel):
    """Organization details."""

    id: str
    """Unique identifier for the organization."""
    name: str
    """Name of the organization."""
    key: str
    """URL-friendly identifier for the organization."""
    description: str | None = None
    """Description of the organization."""
    is_active: bool = True
    """Is the organization active?"""
    allow_external_invites: bool = False
    """Allow external invites to the organization?"""
    max_members: int = 0
    """Maximum number of members allowed in the organization."""
    created_at: datetime
    """Creation timestamp."""
    updated_at: datetime
    """Last update timestamp."""


class OrgMember(BaseModel):
    """Member of an organization."""

    id: str
    """User ID."""
    email_address: str
    """User's email address."""
    username: str | None = None
    """User's username."""
    role: str
    """Role in the organization (owner, contributor, reader)."""
    joined_at: datetime
    """When the user joined the organization."""


class Team(BaseModel):
    """Team within an organization."""

    id: str
    """Team ID."""
    name: str
    """Team name."""
    description: str | None = None
    """Team description."""
    member_count: int = 0
    """Number of members in the team."""
    created_at: datetime
    """When the team was created."""


# -----------------------------------------------------------------------------
# Workspace
# -----------------------------------------------------------------------------


class Workspace(BaseModel):
    """Workspace details."""

    id: str
    """Unique identifier for the workspace."""
    name: str
    """Name of the workspace."""
    key: str
    """Unique key for the workspace."""
    description: str | None = None
    """Description of the workspace."""
    created_by: str | None = None
    """Unique identifier for the user who created the workspace."""
    org_id: str
    """Unique identifier for the organization the workspace belongs to."""
    org_name: str | None = None
    """Name of the organization the workspace belongs to."""
    is_active: bool = True
    """Is the workspace active?"""
    is_default: bool = False
    """Is the workspace the default one?"""
    project_count: int | None = None
    """Number of projects in the workspace."""
    created_at: datetime
    """Creation timestamp."""
    updated_at: datetime
    """Last update timestamp."""


# -----------------------------------------------------------------------------
# Project
# -----------------------------------------------------------------------------


class Project(BaseModel):
    """Project metadata."""

    id: str = Field(repr=False)
    """Unique identifier for the project."""
    key: str
    """Key for the project."""
    name: str
    """Name of the project."""
    description: str | None = Field(default=None, repr=False)
    """Description of the project."""
    workspace_id: str | None = None
    """Unique identifier for the workspace the project belongs to."""
    is_default: bool = False
    """Whether this is the workspace default grouping bucket."""
    created_at: datetime
    """Timestamp when the project was created."""
    updated_at: datetime
    """Timestamp when the project was last updated."""
    run_count: int = 0
    """Number of runs associated with the project."""


# -----------------------------------------------------------------------------
# Runs & Traces
# -----------------------------------------------------------------------------

SpanStatus = t.Literal["pending", "completed", "failed"]


class SpanException(BaseModel):
    """Exception details for a span."""

    type: str
    message: str
    stacktrace: str


class Metric(BaseModel):
    """Metric data point."""

    value: float | None
    step: int
    timestamp: datetime
    attributes: AnyDict = {}


class RunSummary(BaseModel):
    """Summary of a run."""

    id: str
    """Unique identifier for the run."""
    name: str
    """Name of the run."""
    span_id: str = Field(repr=False)
    trace_id: str = Field(repr=False)
    timestamp: datetime
    """Timestamp when the run started."""
    duration: int
    """Duration of the run in milliseconds."""
    status: SpanStatus
    """Status of the run."""
    exception: SpanException | None = None
    """Exception details if the run failed."""
    tags: set[str] = set()
    """Tags associated with the run."""
    params: AnyDict = Field(default_factory=dict, repr=False)
    """Parameters logged for the run."""
    metrics: dict[str, list[Metric]] = Field(default_factory=dict, repr=False)
    """Metrics logged for the run."""


# -----------------------------------------------------------------------------
# Run Sharing
# -----------------------------------------------------------------------------


class ShareInfo(BaseModel):
    """Information about a shared run."""

    token: str
    """Share token."""
    run_id: str
    """Run ID."""
    created_at: datetime
    """When the share was created."""
    created_by: str
    """User who created the share."""
    expires_at: datetime | None = None
    """When the share expires, if set."""


class SharedRun(BaseModel):
    """Publicly shared run data (from GET /api/s/{token})."""

    id: str
    """Run ID."""
    name: str
    """Run name."""
    timestamp: datetime
    """Run timestamp."""
    duration: int
    """Duration in milliseconds."""
    status: SpanStatus
    """Run status."""
    params: AnyDict = {}
    """Run parameters."""
    metrics: dict[str, list[Metric]] = {}
    """Run metrics."""


# -----------------------------------------------------------------------------
# Packages
# -----------------------------------------------------------------------------


class PackageVersion(BaseModel):
    """Package version information."""

    version: str
    """Version string."""
    created_at: datetime
    """When this version was created."""
    size_bytes: int = 0
    """Size of this version in bytes."""
    download_count: int = 0
    """Number of downloads for this version."""


class Package(BaseModel):
    """Package metadata."""

    id: str | None = None
    """Package ID."""
    name: str
    """Package name."""
    full_name: str
    """Full package name (org/type/name)."""
    package_type: str | None = None
    """Package type (datasets, models, agents, toolsets, environments)."""
    type: str | None = None
    """Package type (alias for package_type)."""
    summary: str | None = None
    """Package summary/description."""
    visibility: t.Literal["private", "org", "public"] = "private"
    """Package visibility."""
    org_id: str | None = None
    """Organization ID."""
    created_at: datetime | None = None
    """Creation timestamp."""
    updated_at: datetime | None = None
    """Last update timestamp."""
    versions: list[PackageVersion] | list[str] = []
    """Available versions."""
    latest_version: str | None = None
    """Latest version string."""
    download_count: int = 0
    """Total download count."""
    requires_python: str | None = None
    """Python version requirement."""
    requires_dist: list[str] = []
    """Distribution requirements."""
    upload_time: datetime | None = None
    """When the package was uploaded."""
    uploader: str | None = None
    """Username of uploader."""


class PackageAccessGrant(BaseModel):
    """Access grant for a package."""

    id: str
    """Grant ID."""
    user_id: str
    """User ID with access."""
    username: str | None = None
    """Username."""
    email_address: str | None = None
    """Email address."""
    permission: str
    """Permission level (read, write, admin)."""
    granted_at: datetime
    """When access was granted."""
    granted_by: str | None = None
    """User who granted access."""


class PackageAuditEntry(BaseModel):
    """Audit log entry for a package."""

    id: str
    """Entry ID."""
    action: str
    """Action performed (created, updated, downloaded, etc.)."""
    user_id: str
    """User who performed the action."""
    username: str | None = None
    """Username."""
    timestamp: datetime
    """When the action occurred."""
    details: AnyDict = {}
    """Additional details about the action."""


# -----------------------------------------------------------------------------
# Storage
# -----------------------------------------------------------------------------


class StorageCredentials(BaseModel):
    """S3 credentials for storage access."""

    access_key_id: str
    secret_access_key: str
    session_token: str
    expiration: datetime
    region: str
    bucket: str
    prefix: str
    endpoint: str | None = None


class StorageResource(BaseModel):
    """Storage resource in an organization."""

    id: str
    """Storage resource ID."""
    key: str
    """Storage key."""
    name: str
    """Display name."""
    description: str | None = None
    """Description."""
    org_id: str
    """Organization ID."""
    created_by: str | None = None
    """User who created the storage."""
    created_at: datetime
    """Creation timestamp."""
    updated_at: datetime
    """Last update timestamp."""
    size_bytes: int = 0
    """Total size in bytes."""
    version_count: int = 0
    """Number of versions."""


class StoragePermission(BaseModel):
    """Permission for a storage resource."""

    user_id: str
    """User ID."""
    username: str | None = None
    """Username."""
    permission: str
    """Permission level (read, write, admin)."""


# -----------------------------------------------------------------------------
# Explore
# -----------------------------------------------------------------------------


class ExplorePackage(BaseModel):
    """Package in the explore/browse view."""

    name: str
    """Package name."""
    full_name: str
    """Full package name (org/name)."""
    type: str
    """Package type (datasets, models, agents, etc.)."""
    summary: str | None = None
    """Package summary."""
    org_name: str
    """Organization name."""
    download_count: int = 0
    """Number of downloads."""
    latest_version: str | None = None
    """Latest version."""


class ExploreResponse(BaseModel):
    """Response from GET /api/explore."""

    packages: list[ExplorePackage]
    """List of packages."""
    total: int
    """Total number of results."""
    limit: int
    """Page size."""
    offset: int
    """Current offset."""


# -----------------------------------------------------------------------------
# Limits
# -----------------------------------------------------------------------------


class UsageLimits(BaseModel):
    """Usage limits for the current user."""

    max_runs: int | None = None
    """Maximum number of runs."""
    max_storage_bytes: int | None = None
    """Maximum storage in bytes."""
    max_members: int | None = None
    """Maximum organization members."""
    current_runs: int = 0
    """Current number of runs."""
    current_storage_bytes: int = 0
    """Current storage usage in bytes."""


# -----------------------------------------------------------------------------
# Platform Admin
# -----------------------------------------------------------------------------


class PlatformRelease(BaseModel):
    """Platform release information."""

    version: str
    """Release version."""
    release_date: datetime
    """Release date."""
    notes: str | None = None
    """Release notes."""
    images: list[dict[str, t.Any]] = []
    """Container images for this release."""


class RegistryToken(BaseModel):
    """Container registry token."""

    token: str
    """Registry token."""
    registry: str
    """Registry URL."""
    expires_at: datetime
    """Token expiration."""


class Template(BaseModel):
    """Project template."""

    id: str
    """Template ID."""
    name: str
    """Template name."""
    description: str | None = None
    """Template description."""
    type: str
    """Template type."""


# -----------------------------------------------------------------------------
# OTEL Ingestion
# -----------------------------------------------------------------------------


class OTELTraceResponse(BaseModel):
    """Response from trace ingestion."""

    accepted: int = 0
    """Number of spans accepted."""
    rejected: int = 0
    """Number of spans rejected."""


# -----------------------------------------------------------------------------
# User Data
# -----------------------------------------------------------------------------


class UserDataStore(BaseModel):
    """User data store information."""

    id: str
    """Store ID."""
    user_id: str
    """User ID."""
    created_at: datetime
    """Creation timestamp."""


class PermissionResponse(BaseModel):
    """Response to a permission request from the agent."""

    request_id: str
    decision: t.Literal["allow", "allow_session", "deny"]


class HumanPromptOption(BaseModel):
    """Structured option for a human prompt."""

    label: str
    description: str | None = None


class HumanPrompt(BaseModel):
    """Prompt sent to a human for input, choice, or approval."""

    request_id: str
    kind: t.Literal["input", "choice", "approval"]
    question: str
    details: str | None = None
    options: list[HumanPromptOption] | None = None
    allow_free_text: bool | None = None
    default_option: str | None = None
    severity: str | None = None
    source_tool_name: str | None = None
    source_tool_call_id: str | None = None


class HumanInputResponse(BaseModel):
    """Structured response from a human prompt."""

    request_id: str
    action: t.Literal["submit", "cancel", "approve", "deny", "allow_session"]
    text: str | None = None
    selected_option: str | None = None


class ChatRequest(BaseModel):
    """Request body for chat endpoint."""

    message: str
    session_id: str = Field(min_length=1, validation_alias="sessionId")
    agent: str | None = None
    reset: bool = False
    request_id: str | None = Field(default=None, validation_alias="requestId")
    permission_response: PermissionResponse | None = Field(
        default=None,
        validation_alias="permissionResponse",
    )
    human_input_response: HumanInputResponse | None = Field(
        default=None,
        validation_alias="humanInputResponse",
    )
    generate_params_extra: dict[str, t.Any] | None = Field(
        default=None,
        validation_alias="generateParamsExtra",
    )

    model_config = ConfigDict(populate_by_name=True)


class ChatResponse(BaseModel):
    """Response body for chat completion."""

    status: str
    session_id: str | None = None
    events: int = 0
    final_content: str | None = None
    error: str | None = None


class SessionInfo(BaseModel):
    """Information about an agent session."""

    session_id: str
    model: str
    project: str | None
    created_at: datetime
    message_count: int = 0
    session_dir: str | None = None
    capability: str | None = None
    agent: str | None = None
    title: str | None = None


class SessionMessage(BaseModel):
    """Simple message payload used to seed a server-side session."""

    role: t.Literal["user", "assistant", "system", "tool"]
    content: str


class SessionCreateRequest(BaseModel):
    """Request body for creating a new session."""

    session_id: str | None = Field(default=None, validation_alias="sessionId")
    model: str | None = None
    project: str | None = None
    capability: str | None = None
    agent: str | None = None
    messages: list[SessionMessage] = Field(default_factory=list)
    generate_params_extra: dict[str, t.Any] | None = Field(
        default=None,
        validation_alias="generateParamsExtra",
    )

    model_config = ConfigDict(populate_by_name=True)


class SessionRestoreRequest(BaseModel):
    """Request body for restoring a server-side session runtime."""

    model: str | None = None
    project: str | None = None
    capability: str | None = None
    agent: str | None = None
    messages: list[SessionMessage] = Field(default_factory=list)
    trajectory: dict[str, t.Any] | None = None


class SessionRestoreResponse(BaseModel):
    """Response returned after restoring a server-side session runtime."""

    status: str = "restored"
    session_id: str = Field(serialization_alias="sessionId")
    message_count: int = Field(serialization_alias="messageCount")
    step_count: int = Field(serialization_alias="stepCount")
    capability: str | None = None
    agent: str | None = None
    model: str
    project: str | None = None

    model_config = ConfigDict(populate_by_name=True)


class SavedSessionInfo(BaseModel):
    """Persisted session snapshot available in server storage."""

    session_id: str
    created_at: datetime | None = None
    model: str | None = None
    project: str | None = None
    capability: str | None = None
    agent: str | None = None


class SavedSessionRestoreResponse(BaseModel):
    """Response returned after restoring a saved session snapshot."""

    session: SessionInfo
    messages: list[SessionMessage] = []


class CapabilityAgentInfo(BaseModel):
    """Agent metadata exposed by the local runtime."""

    name: str
    description: str
    model: str = "inherit"
    capability: str


class ComponentStatusInfo(BaseModel):
    """Component-level load/runtime status."""

    kind: t.Literal["agent", "tool", "skill", "mcp_server", "capability"]
    name: str
    status: t.Literal["ok", "error", "degraded"]
    error: str | None = None
    detail: str | None = None


class CapabilityInfo(BaseModel):
    """Capability metadata exposed by the local runtime."""

    name: str
    display_name: str
    canonical_name: str | None = None
    source: t.Literal["project", "local", "package"] | None = None
    provenance: t.Literal["local", "org", "public"] | None = None
    version: str | None = None
    description: str | None = None
    author: dict[str, t.Any] | None = None
    license: str | None = None
    origin: dict[str, t.Any] | None = None
    enabled: bool = True
    binding_id: str | None = None
    components: list[ComponentStatusInfo] = []
    # Existing fields retained for backward compat
    entry_agent: str | None = None
    skills_paths: list[str] = []
    agents: list[CapabilityAgentInfo] = []


class RuntimeInfoResponse(BaseModel):
    """Summary of the local runtime state."""

    status: str = "ok"
    version: str = "1.0.0"
    host_type: str = "local"
    working_dir: str
    default_capability: str | None = None
    capabilities: list[CapabilityInfo] = []


class HealthResponse(BaseModel):
    """Response body for health check."""

    status: str
    version: str = "1.0.0"


class ToolInfo(BaseModel):
    """Info about a single tool."""

    name: str
    description: str = ""
    capability: str = ""


class ToolsResponse(BaseModel):
    """List of all available tools."""

    tools: list[ToolInfo] = []


# -----------------------------------------------------------------------------
# Platform Sessions
# -----------------------------------------------------------------------------


class PlatformSessionCreate(BaseModel):
    """Request body for creating a platform session (maps to API SessionCreateRequest)."""

    id: str
    """Client-generated session UUID."""
    model: str
    """Model used for the session."""
    title: str | None = None
    """Optional session title."""
    message_count: int = 0
    """Number of messages so far."""
    project_id: str | None = None
    """Optional project UUID to associate."""


class PlatformSessionResponse(BaseModel):
    """Response from platform session endpoints (maps to API SessionResponse)."""

    id: str
    """Session UUID."""
    title: str | None = None
    """Session title."""
    model: str | None = None
    """Model used."""
    message_count: int = 0
    """Message count."""
    token_count: int = 0
    """Token count."""
    last_message_at: datetime | None = None
    """Last message timestamp."""
    workspace_id: str | None = None
    """Workspace UUID."""
    project_id: str | None = None
    """Project UUID."""
    project_name: str | None = None
    """Project name."""
    created_at: datetime | None = None
    """Creation timestamp."""
    updated_at: datetime | None = None
    """Update timestamp."""


class PlatformSessionEvent(BaseModel):
    """Session event for platform ingestion (maps to API SessionEventCreate)."""

    event_type: str
    """Event type (e.g. 'message', 'tool_use')."""
    data: dict[str, t.Any] = Field(default_factory=dict)
    """Event payload."""
    timestamp: datetime | None = None
    """Event timestamp."""


# -----------------------------------------------------------------------------
# Training
# -----------------------------------------------------------------------------

TrainingBackend = t.Literal["tinker", "ray"]
TrainingTrainerType = t.Literal["sft", "rl"]
TrainingAlgorithm = t.Literal["grpo", "importance_sampling", "ppo"]
TrainingJobStatus = t.Literal[
    "pending",
    "queued",
    "running",
    "completed",
    "failed",
    "cancelled",
]
TrainingLogLevel = t.Literal["debug", "info", "warning", "error"]


class CapabilityRef(BaseModel):
    """Versioned capability reference for hosted training jobs."""

    model_config = ConfigDict(extra="forbid")

    name: str
    version: str


class DatasetRef(BaseModel):
    """Versioned dataset reference for hosted training jobs."""

    model_config = ConfigDict(extra="forbid")

    name: str
    version: str


class RewardRecipe(BaseModel):
    """Server-side reward recipe reference."""

    model_config = ConfigDict(extra="forbid")

    name: str
    params: dict[str, t.Any] = Field(default_factory=dict)


class TinkerSFTJobConfig(BaseModel):
    """Hosted Tinker SFT configuration."""

    model_config = ConfigDict(extra="forbid")

    dataset_ref: DatasetRef
    eval_dataset_ref: DatasetRef | None = None
    max_sequence_length: int | None = None
    batch_size: int | None = None
    gradient_accumulation_steps: int | None = None
    learning_rate: float | None = None
    steps: int | None = None
    epochs: int | None = None
    lora_rank: int | None = None
    lora_alpha: int | None = None
    checkpoint_interval: int | None = None


class TinkerRLJobConfig(BaseModel):
    """Hosted Tinker RL configuration."""

    model_config = ConfigDict(extra="forbid")

    algorithm: t.Literal["importance_sampling", "ppo"]
    task_ref: str
    prompt_dataset_ref: DatasetRef
    reward_recipe: RewardRecipe | None = None
    prompt_split: str | None = None
    steps: int | None = None
    lora_rank: int | None = None
    max_turns: int | None = None
    max_episode_steps: int | None = None
    num_rollouts: int | None = None
    batch_size: int | None = None
    learning_rate: float | None = None
    weight_sync_interval: int | None = None
    max_new_tokens: int | None = None
    temperature: float | None = None
    stop: list[str] | None = None
    checkpoint_interval: int | None = None


class RayGRPOJobConfig(BaseModel):
    """Hosted Ray GRPO configuration."""

    model_config = ConfigDict(extra="forbid")

    algorithm: t.Literal["grpo"] = "grpo"
    task_ref: str
    prompt_dataset_ref: DatasetRef
    reward_recipe: RewardRecipe | None = None
    execution_mode: t.Literal["async", "colocated", "distributed"] = "async"
    max_turns: int | None = None
    max_episode_steps: int | None = None
    num_rollouts: int | None = None
    batch_size: int | None = None
    learning_rate: float | None = None
    num_rollout_workers: int | None = None
    buffer_size: int | None = None
    checkpoint_interval: int | None = None


class CreateTrainingJobBase(BaseModel):
    """Shared fields for hosted training job submission."""

    model_config = ConfigDict(extra="forbid")

    name: str | None = None
    model: str
    project_ref: str | None = None
    run_ref: str | None = None
    capability_ref: CapabilityRef
    tags: list[str] = Field(default_factory=list)


class CreateTinkerSFTJobRequest(CreateTrainingJobBase):
    """Request to create a hosted Tinker SFT job."""

    backend: t.Literal["tinker"] = "tinker"
    trainer_type: t.Literal["sft"] = "sft"
    config: TinkerSFTJobConfig


class CreateTinkerRLJobRequest(CreateTrainingJobBase):
    """Request to create a hosted Tinker RL job."""

    backend: t.Literal["tinker"] = "tinker"
    trainer_type: t.Literal["rl"] = "rl"
    config: TinkerRLJobConfig


class CreateRayGRPOJobRequest(CreateTrainingJobBase):
    """Request to create a hosted Ray GRPO job."""

    backend: t.Literal["ray"] = "ray"
    trainer_type: t.Literal["rl"] = "rl"
    config: RayGRPOJobConfig


TrainingJobCreateRequest = (
    CreateTinkerSFTJobRequest | CreateTinkerRLJobRequest | CreateRayGRPOJobRequest
)


class TrainingCapabilitySnapshot(BaseModel):
    """Resolved capability metadata attached to a training job."""

    model_config = ConfigDict(extra="forbid")

    artifact_id: str | None = None
    name: str
    version: str
    runtime_digest: str | None = None


class TrainingJob(BaseModel):
    """Hosted training job detail."""

    model_config = ConfigDict(extra="forbid")

    id: str
    organization_id: str
    workspace_id: str
    status: TrainingJobStatus
    name: str | None = None
    backend: TrainingBackend
    trainer_type: TrainingTrainerType
    algorithm: TrainingAlgorithm | None = None
    model: str
    project_ref: str | None = None
    run_ref: str | None = None
    dataset_ref: DatasetRef | None = None
    task_ref: str | None = None
    prompt_dataset_ref: DatasetRef | None = None
    capability: TrainingCapabilitySnapshot
    metrics: dict[str, t.Any] = Field(default_factory=dict)
    artifacts: dict[str, t.Any] = Field(default_factory=dict)
    tags: list[str] = Field(default_factory=list)
    error: str | None = None
    created_at: datetime
    started_at: datetime | None = None
    completed_at: datetime | None = None
    cancel_requested_at: datetime | None = None


class TrainingJobList(BaseModel):
    """Paginated training job list."""

    model_config = ConfigDict(extra="forbid")

    items: list[TrainingJob] = Field(default_factory=list)
    total: int = 0
    page: int = 1
    page_size: int = 20


class TrainingJobLogEntry(BaseModel):
    """Structured training log line."""

    model_config = ConfigDict(extra="forbid")

    timestamp: datetime
    level: TrainingLogLevel
    message: str
    data: dict[str, t.Any] = Field(default_factory=dict)


class TrainingJobLogList(BaseModel):
    """Training log response."""

    model_config = ConfigDict(extra="forbid")

    items: list[TrainingJobLogEntry] = Field(default_factory=list)


class TrainingJobArtifacts(BaseModel):
    """Training artifact response."""

    model_config = ConfigDict(extra="forbid")

    artifacts: dict[str, t.Any] = Field(default_factory=dict)


def _rebuild_models_with_runtime_types() -> None:
    from datetime import datetime

    for value in globals().values():
        if isinstance(value, type) and value is not BaseModel and issubclass(value, BaseModel):
            value.model_rebuild(
                force=True,
                _types_namespace={"datetime": datetime},
            )


_rebuild_models_with_runtime_types()
