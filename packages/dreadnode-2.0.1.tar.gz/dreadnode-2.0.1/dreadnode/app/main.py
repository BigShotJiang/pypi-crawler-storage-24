from __future__ import annotations

import contextlib
import random
import typing as t
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urljoin

import coolname
import logfire
from logfire._internal.exporters.remove_pending import RemovePendingSpansExporter
from opentelemetry import propagate
from opentelemetry.exporter.otlp.proto.http import Compression
from opentelemetry.sdk.trace.export import BatchSpanProcessor

from dreadnode.app.api.client import ApiClient
from dreadnode.app.api.models import Organization, Project, Workspace
from dreadnode.app.server.session import ServerConfig, Session, UserConfig, resolve_session
from dreadnode.core.exceptions import (
    DreadnodeUsageWarning,
    handle_internal_errors,
    warn_at_user_stacklevel,
)
from dreadnode.core.load import load as load_package_util
from dreadnode.core.log import configure_logging
from dreadnode.core.metric import (
    Metric,
    MetricAggMode,
    MetricDict,
    MetricsLike,
)
from dreadnode.packaging.package import (
    BuildResult,
    Package,
    PackageInfo,
    PackageType,
    PullResult,
    PushResult,
)
from dreadnode.core.scorer import ScorersLike
from dreadnode.storage import Storage, StorageProvider
from dreadnode.core.task import P, R, ScoredTaskDecorator, Task, TaskDecorator
from dreadnode.tracing.exporter import CustomOTLPSpanExporter
from dreadnode.tracing.exporters import (
    LocalStorageSpanExporter,
    TraceBackend,
    TraceExportConfig,
)
from dreadnode.tracing.span import (
    Span,
    TaskContext,
    TaskSpan,
    current_task_span,
)
from dreadnode.core.types.common import (
    INHERITED,
    AnyDict,
    Inherited,
    JsonValue,
)
from dreadnode.core.util import (
    clean_str,
)

from dreadnode.version import VERSION

if t.TYPE_CHECKING:
    from opentelemetry.sdk.trace import SpanProcessor
    from opentelemetry.trace import Tracer

    from dreadnode.capabilities.capability import Capability
    from dreadnode.tracing.constants import SpanType


configure_logging()


@dataclass
class Dreadnode:
    """
    The core Dreadnode SDK class.

    A default instance is created and can be used directly with `dreadnode.*`.
    Otherwise, create your own instance with `Dreadnode().configure()`.
    """

    def __init__(self) -> None:
        self.server: str | None = None
        self.api_key: str | None = None
        self.cache: Path = Path.home() / ".dreadnode"
        self.storage_provider: StorageProvider | None = None
        self.trace_backend: TraceBackend | None = None

        self.organization: str | uuid.UUID | None = None
        self.workspace: str | uuid.UUID | None = None
        self.project: str | uuid.UUID | None = None

        self.otel_scope: str = "dreadnode"
        self.console: logfire.ConsoleOptions | bool = False

        self._api: ApiClient | None = None
        self._session: Session | None = None
        self._storage: Storage | None = None
        self._logfire: logfire.Logfire = logfire.DEFAULT_LOGFIRE_INSTANCE
        self._logfire.config.ignore_no_config = True

        self._initialized: bool = False
        self._version: str = VERSION

        self._trace_config: TraceExportConfig | None = None
        self._local_exporter: LocalStorageSpanExporter | None = None

    @property
    def api(self) -> ApiClient:
        if self._api is None:
            raise RuntimeError("No API client - configure with server and API key")
        return self._api

    @property
    def session(self) -> Session:
        if self._session is None:
            raise RuntimeError("No session - configure with server and API key")
        return self._session

    @property
    def storage(self) -> Storage:
        if self._storage is None:
            raise RuntimeError("Call configure() first")
        return self._storage

    @property
    def can_sync(self) -> bool:
        """Whether remote sync is possible (has credentials)."""
        return self._session is not None


    def configure(
        self,
        *,
        server: str | None = None,
        api_key: str | None = None,
        organization: str | uuid.UUID | None = None,
        workspace: str | uuid.UUID | None = None,
        project: str | uuid.UUID | None = None,
        cache: Path | str | None = None,
        storage_provider: StorageProvider | None = None,
        trace_backend: TraceBackend | None = None,
        console: logfire.ConsoleOptions | bool | None = None,
        otel_scope: str = "dreadnode",
    ) -> "Dreadnode":
        """
        Configure the Dreadnode SDK.

        Args:
            server: The Dreadnode server URL.
            api_key: The Dreadnode API key.
            organization: Organization name/key/UUID. If provided without server/auth credentials,
                attempts to load credentials from saved profile.
            workspace: Default workspace name/key/UUID.
            project: Default project name/key/UUID.
            cache: Local cache directory (default: ~/.dreadnode).
            storage_provider: Remote storage provider (s3, r2, minio). Auto-detected if not specified.
            trace_backend: Controls remote OTLP streaming.
            console: Log span information to the console.
            otel_scope: The OpenTelemetry scope name.

        Returns:
            Dreadnode SDK instance.
        """
        if self._initialized:
            return self
        if cache:
            self.cache = Path(cache)
        elif self.cache == Path.home() / ".dreadnode":
            pass
        self.storage_provider = storage_provider
        self.trace_backend = trace_backend
        self.console = console if console is not None else self.console
        self.otel_scope = otel_scope
        default_organization: str | None = None
        default_workspace: str | None = None
        default_project: str | None = None
        profile: ServerConfig | None = None

        should_load_profile = not (
            server is not None
            and api_key is not None
            and organization is not None
            and workspace is not None
        )
        if should_load_profile:
            user_config = UserConfig.read(self.cache / "config.yaml")
            if user_config.active and user_config.active in user_config.servers:
                profile = user_config.servers[user_config.active]
                default_organization = profile.default_organization
                default_workspace = profile.default_workspace
                default_project = profile.default_project

                if not server:
                    server = profile.url
                if not api_key:
                    api_key = profile.api_key

        self.server = server
        self.api_key = api_key
        self.organization = organization or default_organization
        self.workspace = workspace or default_workspace
        self.project = project or default_project

        if server and api_key and organization:
            self._api = ApiClient(server, api_key=api_key)
            self._session = resolve_session(
                api=self._api,
                organization=self.organization,
                workspace=self.workspace,
                project=self.project,
            )
        else:
            self._api = None
            self._session = None

        self._storage = Storage(
            session=self._session,
            cache=self.cache,
            api=self._api,
            provider=self.storage_provider,
            default_project=self.project,
        )
        self._local_exporter = LocalStorageSpanExporter(self._storage)
        span_processors: list[SpanProcessor] = []
        span_processors.append(BatchSpanProcessor(self._local_exporter))


        if (
            self._api is not None
            and self._session is not None
            and self.trace_backend != "local"
        ):
            org_key = self._session.organization.key
            span_processors.append(
                BatchSpanProcessor(
                    RemovePendingSpansExporter(
                        CustomOTLPSpanExporter(
                            endpoint=urljoin(self.server, f"/api/v1/org/{org_key}/otel/traces"),
                            headers={"X-Api-Key": self.api_key},
                            compression=Compression.Gzip,
                        ),
                    ),
                ),
            )

        console_opt: logfire.ConsoleOptions | t.Literal[False] | None
        if self.console is True:
            console_opt = logfire.ConsoleOptions()
        elif self.console is False:
            console_opt = False
        else:
            console_opt = self.console

        self._logfire = logfire.configure(
            send_to_logfire=False,
            console=console_opt,
            additional_span_processors=span_processors if span_processors else None,
            scrubbing=False,
        )

        self._initialized = True
        return self
    
    def _get_storage_credentials(self) -> t.Any:
        """Get storage credentials from the API."""
        if self._session is None:
            raise RuntimeError("Session not configured")
        if self._session.workspace is None:
            raise RuntimeError("Workspace not configured")
        return self.api.get_storage_access(
            self._session.organization.key,
            self._session.workspace.key,
        )
    
    def _setup_trace_infrastructure(
        self,
        *,
        project: str | None = None,
        root_id: str | None = None,
    ) -> str:
        """
        Set up trace infrastructure (exporters, config) without creating a span.

        This is called internally when a top-level span (agent/evaluation/study)
        needs to be created and no trace context exists yet.

        Args:
            project: The project name for trace storage.
            root_id: The root ID for grouping spans. If not provided, generates one.

        Returns:
            The root_id used for this trace session.
        """
        if not self._initialized:
            self.configure()

        root_id = root_id or str(uuid.uuid4().hex)
        trace_config = TraceExportConfig(
            storage=self.storage,
            run_id=root_id,  # Still called run_id in config for file routing
        )
        self._trace_config = trace_config

        return root_id


    def get_current_run(self) -> TaskSpan[t.Any] | None:
        """Get the current task span (backwards compatibility alias)."""
        return current_task_span.get()

    def get_current_task(self) -> TaskSpan[t.Any] | None:
        """Get the current task span."""
        return current_task_span.get()

    def _resolve_trace_project(self, project: str | uuid.UUID | None = None) -> str:
        """
        Resolve the project identifier to stamp onto root spans.

        Remote analytics APIs filter traces by project UUID, not project key.
        When a configured session is available, prefer the resolved project ID.
        Fall back to an explicit UUID, then the configured key for local-only use.
        """
        if isinstance(project, uuid.UUID):
            return str(project)

        active_project = getattr(self._session, "project", None)
        active_project_id = getattr(active_project, "id", None)
        active_project_key = getattr(active_project, "key", None)

        if project is None:
            if active_project_id is not None:
                return str(active_project_id)
            return self.project or "default"

        if active_project_id is not None:
            if project == str(active_project_id):
                return str(active_project_id)
            if active_project_key is not None and project == active_project_key:
                return str(active_project_id)

        if self._api is not None and self._session is not None and isinstance(project, str):
            try:
                resolved_project = self._api.get_project(
                    self._session.organization.key,
                    self._session.workspace.key,
                    project,
                )
            except RuntimeError:
                pass
            else:
                return str(resolved_project.id)

        return project

    def get_tracer(self, *, is_span_tracer: bool = True) -> "Tracer":
        """
        Get an OpenTelemetry Tracer instance.

        Args:
            is_span_tracer: Whether the tracer is for creating spans.

        Returns:
            An OpenTelemetry Tracer.
        """
        return self._logfire._tracer_provider.get_tracer(  # noqa: SLF001
            self.otel_scope,
            self._version,
            is_span_tracer=is_span_tracer,
        )

    @handle_internal_errors()
    def shutdown(self) -> None:
        """
        Shutdown any associate OpenTelemetry components and flush any pending spans.

        It is not required to call this method, as the SDK will automatically
        flush and shutdown when the process exits.

        However, if you want to ensure that all spans are flushed before
        exiting, you can call this method manually.
        """
        if not self._initialized:
            return

        self._logfire.shutdown()

    def login(
        self,
        server: str,
        api_key: str,
        organization: str | uuid.UUID,
        *,
        workspace: str | uuid.UUID | None = None,
        project: str | uuid.UUID | None = None,
        cache: Path | str | None = None,
        set_default_workspace: bool = True,
        set_default_project: bool = True,
    ) -> "Organization":
        """
        Login to a Dreadnode server and save credentials to profile.

        Authenticates with the server, resolves the organization, and saves
        the profile to ~/.dreadnode/orgs/<org>/profile.yaml for future use.

        Args:
            server: The Dreadnode server URL.
            api_key: The Dreadnode API key.
            organization: Organization key or ID to login to.
            workspace: Default workspace to use.
            project: Default project to use.
            cache: Local cache directory (default: ~/.dreadnode).
            set_default_workspace: Save workspace as default in profile.
            set_default_project: Save project as default in profile.

        Returns:
            The resolved Organization.

        Raises:
            RuntimeError: If authentication fails or organization not found.
        """
        cache_path = Path(cache) if cache else Path.home() / ".dreadnode"

        # Create API client and authenticate
        api = ApiClient(server, api_key=api_key)
        user = api.get_user()

        # Get organization by key/id
        org = api.get_organization(str(organization))

        # Resolve workspace - use specified or find default
        resolved_workspace: str | None = None
        if workspace:
            ws = api.get_workspace(org.key, str(workspace))
            if ws:
                resolved_workspace = ws.key
        else:
            # Auto-select default workspace if none specified
            workspaces = api.list_workspaces(org.key)
            if workspaces:
                # Prefer default workspace, otherwise use first one
                for ws in workspaces:
                    if getattr(ws, "is_default", False):
                        resolved_workspace = ws.key
                        break
                if not resolved_workspace:
                    resolved_workspace = workspaces[0].key

        # Resolve project if specified
        resolved_project: str | None = None
        if project and resolved_workspace:
            proj = api.get_project(org.key, resolved_workspace, str(project))
            if proj:
                resolved_project = proj.key
        elif resolved_workspace and set_default_project:
            resolved_project = api.get_default_project_key(org.key, resolved_workspace)

        # Use username as the user_key for storage paths
        user_key = user.username
        if not user_key:
            raise RuntimeError("User has no username set. Please set a username first.")

        # Create and save profile
        profile = ServerConfig(
            url=server,
            user_key=user_key,
            email=user.email_address,
            username=user.username,
            api_key=api_key,
            default_organization=org.key,
            default_workspace=resolved_workspace if set_default_workspace else None,
            default_project=resolved_project if set_default_project else None,
        )

        # Save profile under user_key, not org.key
        profile_path = cache_path / "orgs" / user_key / "profile.yaml"
        profile.save(profile_path)

        # Also update the global user config
        user_config = UserConfig.read(cache_path / "config.yaml")
        user_config.servers[user_key] = profile
        user_config.active = user_key
        user_config.write(cache_path / "config.yaml")

        # Configure the SDK with this organization
        self.configure(
            server=server,
            api_key=api_key,
            organization=org.key,
            workspace=resolved_workspace,
            project=resolved_project,
            cache=cache_path,
        )

        return org

    def list_workspaces(self, org: str | None = None) -> list["Workspace"]:
        """
        List workspaces the user has access to.

        Args:
            org: Organization key. Uses configured org if not provided.

        Returns:
            List of workspaces.
        """
        if self._api is None or self._session is None:
            raise RuntimeError("Call configure() first")
        org = org or self._session.org_key
        return self._api.list_workspaces(org)

    def list_projects(
        self,
        org: str | None = None,
        workspace: str | None = None,
    ) -> list["Project"]:
        """
        List projects in a workspace.

        Args:
            org: Organization key. Uses configured org if not provided.
            workspace: Workspace key. Uses configured workspace if not provided.

        Returns:
            List of projects.
        """
        if self._api is None or self._session is None:
            raise RuntimeError("Call configure() first")
        org = org or self._session.org_key
        workspace = workspace or self._session.workspace_key
        return self._api.list_projects(org, workspace)

    def list_agents(
        self,
        org: str | None = None,
    ) -> list[PackageInfo]:
        """
        List agents in a workspace.

        Args:
            org: Organization key. Uses configured org if not provided.
            workspace: Workspace key. Uses configured workspace if not provided.

        Returns:
            List of agent PackageInfo.
        """
        if self._api is None or self._session is None:
            raise RuntimeError("Call configure() first")
        org = org or self._session.org_key
        return self._api.list_agents(org)

    def span(
        self,
        name: str,
        *,
        tags: t.Sequence[str] | None = None,
        attributes: AnyDict | None = None,
    ) -> Span:
        """
        Create a new OpenTelemety span.

        Spans are more lightweight than tasks, but still let you track
        work being performed and view it in the UI. You cannot
        log parameters, inputs, or outputs to spans.

        Example:
            ```
            with dreadnode.span("my_span") as span:
                # do some work here
                pass
            ```

        Args:
            name: The name of the span.
            tags: A list of tags to attach to the span.
            attributes: A dictionary of attributes to attach to the span.

        Returns:
            A Span object.
        """
        return Span(
            name=name,
            attributes=attributes,
            tracer=self.get_tracer(),
            tags=tags,
        )

    def task(
        self,
        func: t.Callable[P, t.Awaitable[R]] | t.Callable[P, R] | None = None,
        /,
        *,
        scorers: ScorersLike[t.Any] | None = None,
        name: str | None = None,
        label: str | None = None,
        log_inputs: t.Sequence[str] | bool | Inherited = INHERITED,
        log_output: bool | Inherited = INHERITED,
        log_execution_metrics: bool = False,
        tags: t.Sequence[str] | None = None,
        attributes: AnyDict | None = None,
        entrypoint: bool = False,
    ) -> TaskDecorator | ScoredTaskDecorator[R] | Task[P, R]:
        """Create a new task from a function. See `task()` for details."""
        from dreadnode.core.task import task as task_factory

        return task_factory(
            func,  # type: ignore[arg-type]
            tracer=self.get_tracer(),
            scorers=scorers,  # type: ignore[arg-type]
            name=name,
            label=label,
            log_inputs=log_inputs,
            log_output=log_output,
            log_execution_metrics=log_execution_metrics,
            tags=tags,
            attributes=attributes,
            entrypoint=entrypoint,
        )

    def task_span(
        self,
        name: str,
        *,
        type: "SpanType" = "task",
        label: str | None = None,
        tags: t.Sequence[str] | None = None,
        attributes: AnyDict | None = None,
        _tracer: "Tracer | None" = None,
    ) -> TaskSpan[t.Any]:
        """
        Create a task span without an explicit associated function.

        This is useful for creating tasks on the fly without having to
        define a function.

        Example:
            ```
            async with dreadnode.task_span("my_task") as task:
                # do some work here
                pass
            ```
        Args:
            name: The name of the task.
            type: The type of span (task, evaluation, etc.).
            label: The label of the task - useful for filtering in the UI.
            tags: A list of tags to attach to the task span.
            attributes: A dictionary of attributes to attach to the task span.

        Returns:
            A TaskSpan object.
        """
        parent_task = current_task_span.get()
        label = clean_str(label or name)

        return TaskSpan(
            name=name,
            tracer=_tracer or self.get_tracer(),
            storage=self.storage,
            project=parent_task.project_id if parent_task else self._resolve_trace_project(),
            type=type,
            label=label,
            attributes=attributes,
            tags=tags,
        )

    def scorer(
        self,
        func: t.Callable[..., t.Any] | None = None,
        *,
        name: str | None = None,
        assert_: bool = False,
        attributes: AnyDict | None = None,
    ) -> t.Any:
        """Create a scorer decorator. See `scorer()` for details."""
        from dreadnode.core.scorer import scorer as scorer_factory

        return scorer_factory(func, name=name, assert_=assert_, attributes=attributes)  # type: ignore[arg-type]

    def evaluation(
        self,
        func: t.Callable[..., t.Any] | None = None,
        /,
        *,
        dataset: t.Any | None = None,
        dataset_file: str | None = None,
        name: str | None = None,
        description: str = "",
        tags: list[str] | None = None,
        concurrency: int = 1,
        iterations: int = 1,
        max_errors: int | None = None,
        max_consecutive_errors: int = 10,
        dataset_input_mapping: list[str] | dict[str, str] | None = None,
        parameters: dict[str, list[t.Any]] | None = None,
        scorers: "ScorersLike[t.Any] | None" = None,
        assert_scores: list[str] | t.Literal[True] | None = None,
    ) -> t.Any:
        """Decorator to create an Evaluation from a function. See `evaluation()` for details."""
        from dreadnode.core.evaluations import evaluation as evaluation_factory

        return evaluation_factory(
            func,
            dataset=dataset,
            dataset_file=dataset_file,
            name=name,
            description=description,
            tags=tags,
            concurrency=concurrency,
            iterations=iterations,
            max_errors=max_errors,
            max_consecutive_errors=max_consecutive_errors,
            dataset_input_mapping=dataset_input_mapping,
            parameters=parameters,
            scorers=scorers,
            assert_scores=assert_scores,
        )

    def study(
        self,
        func: t.Callable[..., t.Any] | None = None,
        /,
        *,
        name: str | None = None,
        search_strategy: t.Any | None = None,
        dataset: t.Any | None = None,
        dataset_file: str | None = None,
        objectives: "ScorersLike[t.Any] | None" = None,
        directions: list[Direction] | None = None,
        constraints: "ScorersLike[t.Any] | None" = None,
        max_trials: int = 100,
        concurrency: int = 1,
        stop_conditions: list[t.Any] | None = None,
    ) -> t.Any:
        """Decorator to create a Study from a task factory. See `study()` for details."""
        from dreadnode.optimization import study as study_factory

        return study_factory(
            func,
            name=name,
            search_strategy=search_strategy,
            dataset=dataset,
            dataset_file=dataset_file,
            objectives=objectives,
            directions=directions,
            constraints=constraints,
            max_trials=max_trials,
            concurrency=concurrency,
            stop_conditions=stop_conditions,
        )

    def train(
        self,
        config: str | Path | dict[str, t.Any],
        *,
        prompts: list[str] | None = None,
        reward_fn: t.Callable[[list[str], list[str]], list[float]] | None = None,
        scorers: "ScorersLike[t.Any] | None" = None,
    ) -> t.Any:
        """
        Train a model using a YAML configuration file.

        This is the main entry point for training LLMs with GRPO, SFT, DPO, PPO,
        or other training methods supported by the Ray training framework.

        Example YAML config (grpo.yaml):
            ```yaml
            trainer: grpo
            model_name: Qwen/Qwen2.5-1.5B-Instruct
            max_steps: 100
            num_prompts_per_step: 4
            num_generations_per_prompt: 4
            learning_rate: 1e-6
            temperature: 0.7

            # Dataset - supports dreadnode datasets, huggingface, jsonl, or inline
            dataset:
              type: dreadnode  # or huggingface, jsonl, list
              name: my-dataset  # dreadnode dataset name
              prompt_field: question

            # Reward - supports dreadnode scorers or built-in types
            reward:
              type: scorer  # Use dreadnode scorer
              # or type: correctness, length, contains
            ```

        Usage:
            ```python
            import dreadnode as dn

            # Train from YAML config
            result = dn.train("config/grpo.yaml")

            # Train with dreadnode dataset and scorers
            @dn.scorer
            def correctness(completion: str) -> float:
                return 1.0 if "answer" in completion else 0.0

            result = dn.train(
                {"trainer": "grpo", "model_name": "..."},
                prompts=dn.load("my-dataset").to_prompts("question"),
                scorers=[correctness],
            )

            # Train with custom prompts and reward function
            result = dn.train(
                "config/grpo.yaml",
                prompts=["What is 2+2?", "What is 3*4?"],
                reward_fn=my_reward_fn,
            )
            ```

        Args:
            config: Path to YAML config file, or dict with config values.
            prompts: Optional list of prompts (overrides dataset in config).
            reward_fn: Optional reward function (overrides reward/scorers).
            scorers: Optional dreadnode Scorers to use as reward (converted to reward_fn).

        Returns:
            Training result (trainer-specific).
        """
        import yaml

        from dreadnode.core.scorer import Scorer

        # Load config
        if isinstance(config, (str, Path)):
            config_path = Path(config)
            if not config_path.exists():
                raise FileNotFoundError(f"Config file not found: {config_path}")

            with open(config_path) as f:
                config_dict = yaml.safe_load(f)
        else:
            config_dict = dict(config)  # Copy to avoid mutating input

        # Determine trainer type
        trainer_type = config_dict.pop("trainer", "grpo").lower()

        # Load prompts from dataset if not provided
        if prompts is None and "dataset" in config_dict:
            prompts = _load_training_dataset(config_dict.pop("dataset"))

        if prompts is None:
            raise ValueError("Either 'prompts' argument or 'dataset' in config is required")

        # Build reward function from scorers if provided
        if scorers is not None:
            fitted_scorers = Scorer.fit_many(scorers)
            reward_fn = _scorers_to_reward_fn(fitted_scorers)

        # Build reward function from config if not provided
        if reward_fn is None and "reward" in config_dict:
            reward_fn = _build_reward_fn(config_dict.pop("reward"), prompts)

        # For SFT, reward is optional
        if reward_fn is None and trainer_type not in ("sft",):
            raise ValueError(
                "Either 'reward_fn', 'scorers', or 'reward' in config is required for "
                f"{trainer_type} training"
            )

        # Create and run trainer
        if trainer_type == "grpo":
            assert reward_fn is not None  # Validated above
            return train_grpo(config_dict, prompts, reward_fn)
        if trainer_type == "sft":
            return train_sft(config_dict, prompts)
        if trainer_type == "dpo":
            return train_dpo(config_dict, prompts)
        if trainer_type == "ppo":
            assert reward_fn is not None  # Validated above
            return train_ppo(config_dict, prompts, reward_fn)
        raise ValueError(f"Unknown trainer type: {trainer_type}")


    def run(
        self,
        name: str | None = None,
        *,
        tags: t.Sequence[str] | None = None,
        params: AnyDict | None = None,
        project: str | None = None,
        name_prefix: str | None = None,
        attributes: AnyDict | None = None,
        _tracer: "Tracer | None" = None,
    ) -> TaskSpan[t.Any]:
        """
        Create a new top-level task span.

        This sets up trace infrastructure and creates a task span that can
        contain agents, evaluations, studies, or other work.

        Example:
            ```
            with dreadnode.run("my_experiment"):
                # Run an agent, evaluation, or other work
                await agent.run("do something")
            ```

        Args:
            name: The name of the task. If not provided, a random name will be generated.
            tags: A list of tags to attach to the task.
            params: A dictionary of parameters to attach to the task.
            project: The project name to associate with. If not provided,
                the project passed to `configure()` will be used, or
                a default project will be used.
            attributes: Additional attributes to attach to the span.

        Returns:
            A TaskSpan object that can be used as a context manager.
        """
        name_prefix = clean_str(name_prefix or coolname.generate_slug(2), replace_with="-")
        name = name or f"{name_prefix}-{random.randint(100, 999)}"  # noqa: S311 # nosec

        # Resolve project to string
        resolved_project = self._resolve_trace_project(project)

        # Set up trace infrastructure
        task_id = self._setup_trace_infrastructure(project=resolved_project)

        return TaskSpan(
            name=name,
            tracer=_tracer or self.get_tracer(),
            storage=self.storage,
            project=resolved_project,
            task_id=task_id,
            type="task",  # Just a task, not a special "run" type
            params=params,
            attributes=attributes,
            tags=tags,
        )

    @contextlib.contextmanager
    def task_and_run(
        self,
        name: str,
        *,
        task_name: str | None = None,
        task_type: "SpanType" = "task",
        project: str | None = None,
        tags: t.Sequence[str] | None = None,
        params: AnyDict | None = None,
        inputs: AnyDict | None = None,
        label: str | None = None,
        _tracer: "Tracer | None" = None,
    ) -> t.Iterator[TaskSpan[t.Any]]:
        """
        Create a task span, setting up trace infrastructure if needed.

        If no trace context exists, this sets up exporters and creates the
        span as a top-level span. The span type (evaluation, study, agent, etc.)
        becomes the root of the trace.

        Args:
            name: Name for the task span.
            task_name: Optional separate name for the task span. If not provided, uses name.
            task_type: The type of span to create (task, evaluation, study, agent, etc.).
            project: Project for trace storage.
            tags: Tags to attach to the span.
            params: Parameters to log.
            inputs: Inputs to log.
            label: Display label for the span.
        """
        needs_infrastructure = current_task_span.get() is None

        # Set up trace infrastructure if this is a top-level span
        if needs_infrastructure:
            # Resolve project
            resolved_project = self._resolve_trace_project(project)
            self._setup_trace_infrastructure(project=resolved_project)

        with self.task_span(
            task_name or name,
            type=task_type,
            label=label,
            tags=tags,
            _tracer=_tracer,
        ) as task_span:
            # Log inputs and params
            self.log_inputs(**(inputs or {}))
            self.log_params(**(params or {}))
            yield task_span

    def get_task_context(self) -> TaskContext:
        """
        Capture the current task context for transfer to another host, thread, or process.

        Use `continue_task()` to continue the task anywhere else.

        Returns:
            TaskContext containing task state and trace propagation headers.

        Raises:
            RuntimeError: If called outside of an active task.
        """
        if (task := current_task_span.get()) is None:
            raise RuntimeError("get_task_context() must be called within a task")

        trace_context: dict[str, str] = {}
        propagate.inject(trace_context)

        return {
            "task_id": task.task_id,
            "task_name": task.name,
            "project": task.project_id,
            "trace_context": trace_context,
        }


    def continue_task(self, task_context: TaskContext) -> TaskSpan[t.Any]:
        """
        Continue a task from captured context on a remote host.

        Args:
            task_context: The TaskContext captured from get_task_context().

        Returns:
            A TaskSpan object that can be used as a context manager.
        """
        if not self._initialized:
            self.configure()

        return TaskSpan.from_context(
            context=task_context,
            tracer=self.get_tracer(),
            storage=self.storage,
        )


    def tag(self, *tag: str) -> None:
        """
        Add one or many tags to the current span.

        Example:
            ```
            with dreadnode.run("my_run"):
                dreadnode.tag("my_tag")
            ```

        Args:
            tag: The tag(s) to attach.
        """
        task = current_task_span.get()
        if task is None:
            warn_at_user_stacklevel(
                "tag() was called outside of a task or run.",
                category=DreadnodeUsageWarning,
            )
            return

        task.add_tags(tag)

    def load_package(
        self,
        uri: str | Path | None = None,
        type: PackageType | None = None,
    ) -> t.Any:
        """
        Load a package (dataset, model, or agent) from the server.

        Downloads and installs the package if not already installed,
        then loads it via entry points. Artifacts are fetched from
        CAS on demand.

        Args:
            uri: Package URI (e.g., "dataset://org/name", "model://org/name").
            type: Package type hint if not specified in URI.

        Returns:
            The loaded package object (Dataset, Model, or Agent).
        """
        return load_package_util(uri, type=type, storage=self.storage, session=self._session)  # type: ignore[arg-type]

    def load_dataset(
        self,
        path: str,
        config: str | None = None,
        *,
        dataset_name: str | None = None,
        split: str | None = None,
        format: t.Literal["parquet", "arrow", "feather"] = "parquet",
        version: str = "0.1.0",
        **kwargs: t.Any,
    ) -> t.Any:
        """
        Load a dataset from HuggingFace Hub and store in local CAS.

        This downloads the dataset from HuggingFace and stores it in the
        Content-Addressable Storage for later use with packaging.

        Args:
            path: HuggingFace dataset path (e.g., "squad", "imdb", "glue").
            config: Dataset configuration name (e.g., "cola" for glue dataset).
            dataset_name: Name to store the dataset as locally. Defaults to the path.
            split: Dataset split to load (e.g., "train", "test", "train[:100]").
            format: Storage format (parquet, arrow, feather).
            version: Version string for the stored dataset.
            **kwargs: Additional arguments passed to HuggingFace's load_dataset.

        Returns:
            LocalDataset instance with the loaded data.

        Example:
            >>> import dreadnode as dn
            >>> dn.configure(...)
            >>> ds = dn.load_dataset("glue", "cola", split="train[:100]")
        """
        from dreadnode.datasets.local import load_dataset as local_load_dataset

        return local_load_dataset(
            path,
            dataset_name=dataset_name,
            storage=self.storage,
            split=split,
            format=format,
            version=version,
            **({"name": config} if config else {}),
            **kwargs,
        )

    def load_model(
        self,
        path: str,
        *,
        model_name: str | None = None,
        task: str | None = None,
        format: t.Literal["safetensors", "pytorch"] = "safetensors",
        version: str = "0.1.0",
        **kwargs: t.Any,
    ) -> t.Any:
        """
        Load a model from HuggingFace Hub and store in local CAS.

        This downloads the model from HuggingFace and stores it in the
        Content-Addressable Storage for later use with packaging.

        Args:
            path: HuggingFace model path (e.g., "bert-base-uncased", "gpt2").
            model_name: Name to store the model as locally. Defaults to the path.
            task: Task type for the model (e.g., "classification", "generation").
            format: Storage format (safetensors or pytorch).
            version: Version string for the stored model.
            **kwargs: Additional arguments passed to from_pretrained.

        Returns:
            LocalModel instance with the loaded model.

        Example:
            >>> import dreadnode as dn
            >>> dn.configure(...)
            >>> model = dn.load_model("bert-base-uncased", task="classification")
        """
        from dreadnode.models.local import load_model as local_load_model

        return local_load_model(
            path,
            model_name=model_name,
            storage=self.storage,
            task=task,
            format=format,
            version=version,
            **kwargs,
        )

    def load_capability(
        self,
        capability: str | Path,
        *,
        config: dict[str, t.Any] | None = None,
    ) -> "Capability":
        """
        Load a capability from an explicit path or from the configured capability search paths.

        Returns a high-level ``Capability`` object that exposes the loaded manifest plus wrapped
        tools, hooks, agents, and scorers.

        Args:
            capability: Capability directory path or capability name.
            config: Optional config overrides to apply when loading the capability.

        Returns:
            Capability ready to attach to an agent or server runtime.

        Raises:
            FileNotFoundError: If no capability with the requested name can be found.
        """
        from dreadnode.capabilities import Capability

        return Capability(
            capability,
            config=config,
            cwd=Path.cwd(),
            storage=self.storage,
        )

    def build_package(
        self,
        path: str | Path,
    ) -> BuildResult:
        """
        Build a local repository into an OCI image.

        Args:
            path: Path to the package source directory.

        Returns:
            BuildResult with success status and OCI image.
        """
        return Package(path=Path(path)).build()

    def push_package(
        self,
        path: str | Path,
        *,
        skip_upload: bool = False,
    ) -> "PushResult":
        """
        Build and push a local package to the Dreadnode OCI Registry.

        Handles artifact upload to CAS (for datasets/models) and OCI image
        push automatically.

        Args:
            path: Path to the package source directory.
            skip_upload: Skip uploading to remote (local only).

        Returns:
            PushResult with status and details.
        """
        import warnings

        is_local_mode = self.server == "local" or self._session is None
        if is_local_mode and not skip_upload:
            warnings.warn(
                "No remote credentials configured. Artifacts will be stored locally only. "
                "Use dn.configure() with server credentials to enable remote upload.",
                stacklevel=2,
            )
            skip_upload = True

        # Package.push() now handles the full flow: CAS upload + OCI build + OCI push
        return Package(path=Path(path)).push(storage=self.storage, skip_upload=skip_upload)

    def pull_package(
        self,
        packages: list[str],
        *,
        upgrade: bool = False,
    ) -> "PullResult":
        """
        Download packages from the registry.

        Args:
            packages: Package names to install.
            upgrade: Upgrade if already installed.

        Returns:
            PullResult with status.
        """
        return Package.pull(*packages, upgrade=upgrade, _storage=self.storage)

    def change_workspace(self, workspace: str | uuid.UUID) -> Workspace:
        """
        Change the current workspace within the current organization.

        This re-resolves the workspace and updates the storage paths accordingly.
        The organization remains unchanged.

        Args:
            workspace: The workspace name, key, or uuid.UUID to switch to.

        Returns:
            The resolved Workspace object.

        Raises:
            RuntimeError: If not configured or workspace not found.
        """
        if self._session is None or self._api is None:
            raise RuntimeError("Call configure() first")

        # Re-resolve session with new workspace
        self._session = resolve_session(
            api=self._api,
            organization=self._session.org_key,
            workspace=workspace,
            project=self.project,
        )
        self.workspace = workspace

        # Update storage with new workspace context
        self._storage = Storage(
            session=self._session,
            cache=self.cache,
            api=self._api,
            provider=self.storage_provider
        )

        return self._session.workspace

    def list_registry(
        self,
        project_type: PackageType,
        *,
        org: str | None = None,
    ) -> list[PackageInfo]:
        """
        List packages available in the registry.

        Currently lists packages from local storage. Remote registry support
        will be added when the API endpoint is available.

        Args:
            package_type: Type of package to list (datasets, models, tools, agents, environments).
            org: Organization to filter

        Returns:
            List of PackageInfo objects.
        """
        packages: list[PackageInfo] = []

        # List from local storage
        projects_dir = self.storage.projects_path / project_type
        if projects_dir.exists():
            for pkg_dir in projects_dir.iterdir():
                if pkg_dir.is_dir():
                    # Get latest version
                    versions = self.storage.list_versions(project_type, pkg_dir.name)
                    latest = versions[0] if versions else None

                    packages.append(
                        PackageInfo(
                            name=pkg_dir.name,
                            project_type=project_type,
                            version=latest,
                            is_local=True,
                        )
                    )

        if self._session is not None and self._api is not None:
            org = org or self._session.org_key
            remote_packages = self._api.list_org_packages(org, project_type)
            for pkg in remote_packages:
                packages.append(
                    PackageInfo(
                        name=pkg.name,
                        project_type=project_type,
                        version=pkg.latest_version,
                        description=pkg.summary,
                        org=org,
                        is_local=False,
                    )
                )

        return packages

    @handle_internal_errors()
    def push_update(self) -> None:
        """
        Push any pending run data to the server before run completion.

        This is useful for ensuring that the UI is up to date with the
        latest data. Data is automatically pushed periodically, but
        you can call this method to force a push.

        Example:
            ```
            with dreadnode.run("my_run"):
                dreadnode.log_params(...)
                dreadnode.log_metric(...)
                dreadnode.push_update()

                # do more work
        """
        if (run := current_task_span.get()) is None:
            warn_at_user_stacklevel(
                "push_update() was called outside of a run.",
                category=DreadnodeUsageWarning,
            )
            return

        run.push_update(force=True)

    @handle_internal_errors()
    def log_param(
        self,
        key: str,
        value: JsonValue,
    ) -> None:
        """
        Log a single parameter to the current run.

        Parameters are key-value pairs that are associated with the run
        and can be used to track configuration values, hyperparameters, or other
        metadata.

        Example:
            ```
            with dreadnode.run("my_run"):
                dreadnode.log_param("param_name", "param_value")
            ```

        Args:
            key: The name of the parameter.
            value: The value of the parameter.
        """
        self.log_params(**{key: value})

    @handle_internal_errors()
    def log_params(self, **params: JsonValue) -> None:
        """
        Log multiple parameters to the current run.

        Parameters are key-value pairs that are associated with the run
        and can be used to track configuration values, hyperparameters, or other
        metadata.

        Example:
            ```
            with dreadnode.run("my_run"):
                dreadnode.log_params(
                    param1="value1",
                    param2="value2"
                )
            ```

        Args:
            **params: The parameters to log. Each parameter is a key-value pair.
        """
        if (run := current_task_span.get()) is None:
            warn_at_user_stacklevel(
                "log_params() was called outside of a run.",
                category=DreadnodeUsageWarning,
            )
            return

        run.log_params(**params)

    @t.overload
    def log_metric(
        self,
        name: str,
        value: float | bool,  # noqa: FBT001
        *,
        step: int = 0,
        origin: t.Any | None = None,
        timestamp: datetime | None = None,
        aggregation: MetricAggMode | None = None,
        attributes: AnyDict | None = None,
    ) -> Metric:
        """
        Log a single metric to the current task or run.

        Metrics are some measurement or recorded value related to the task or run.
        They can be used to track performance, resource usage, or other quantitative data.

        Example:
            ```
            with dreadnode.run("my_run"):
                dreadnode.log_metric("metric_name", 42.0)
            ```

        Args:
            name: The name of the metric.
            value: The value of the metric.
            step: The step of the metric.
            origin: The origin of the metric - can be provided any object which was logged
                as an input or output anywhere in the run.
            timestamp: The timestamp of the metric - defaults to the current time.
            aggregation: The aggregation to use for the metric. Helpful when you want to let
                the library take care of translating your raw values into better representations.
                - direct: do not modify the value at all (default)
                - min: the lowest observed value reported for this metric
                - max: the highest observed value reported for this metric
                - avg: the average of all reported values for this metric
                - sum: the cumulative sum of all reported values for this metric
                - count: increment every time this metric is logged - disregard value
            attributes: A dictionary of additional attributes to attach to the metric.
            to: The target object to log the metric to. Can be "task-or-run" or "run".
                Defaults to "task-or-run". If "task-or-run", the metric will be logged
                to the current task or run, whichever is the nearest ancestor.

        Returns:
            The logged metric object.
        """

    @t.overload
    def log_metric(
        self,
        name: str,
        value: Metric,
        *,
        origin: t.Any | None = None,
        aggregation: MetricAggMode | None = None,
    ) -> Metric:
        """
        Log a single metric to the current task or run.

        Metrics are some measurement or recorded value related to the task or run.
        They can be used to track performance, resource usage, or other quantitative data.

        Example:
            ```
            with dreadnode.run("my_run"):
                dreadnode.log_metric("metric_name", 42.0)
            ```

        Args:
            name: The name of the metric.
            value: The metric object.
            origin: The origin of the metric - can be provided any object which was logged
                as an input or output anywhere in the run.
            aggregation: The aggregation to use for the metric. Helpful when you want to let
                the library take care of translating your raw values into better representations.
                - min: always report the lowest ovbserved value for this metric
                - max: always report the highest observed value for this metric
                - avg: report the average of all values for this metric
                - sum: report a rolling sum of all values for this metric
                - count: report the number of times this metric has been logged
            to: The target object to log the metric to. Can be "task-or-run" or "run".
                Defaults to "task-or-run". If "task-or-run", the metric will be logged
                to the current task or run, whichever is the nearest ancestor.

        Returns:
            The logged metric object.
        """

    @handle_internal_errors()
    def log_metric(
        self,
        name: str,
        value: float | bool | Metric,  # noqa: FBT001
        *,
        step: int = 0,
        origin: t.Any | None = None,
        timestamp: datetime | None = None,
        aggregation: MetricAggMode | None = None,
        attributes: AnyDict | None = None,
    ) -> Metric:
        """
        Log a single metric to the current task or run.

        Metrics are some measurement or recorded value related to the task or run.
        They can be used to track performance, resource usage, or other quantitative data.

        Examples:
            With a raw value:
            ```
            with dreadnode.run("my_run"):
                dreadnode.log_metric("accuracy", 0.95, step=10)
                dreadnode.log_metric("loss", 0.05, step=10, aggregation="min")
            ```

            With a Metric object:
            ```
            with dreadnode.run("my_run"):
                metric = Metric(0.95, step=10, timestamp=datetime.now(timezone.utc))
                dreadnode.log_metric("accuracy", metric)
            ```

        Args:
            name: The name of the metric.
            value: The value of the metric, either as a raw float/bool or a Metric object.
            step: The step of the metric.
            origin: The origin of the metric - can be provided any object which was logged
                as an input or output anywhere in the run.
            timestamp: The timestamp of the metric - defaults to the current time.
            aggregation: The aggregation to use for the metric. Helpful when you want to let
                the library take care of translating your raw values into better representations.
                - direct: do not modify the value at all (default)
                - min: the lowest observed value reported for this metric
                - max: the highest observed value reported for this metric
                - avg: the average of all reported values for this metric
                - sum: the cumulative sum of all reported values for this metric
                - count: increment every time this metric is logged - disregard value
            attributes: A dictionary of additional attributes to attach to the metric.
            to: The target object to log the metric to. Can be "task-or-run" or "run".
                Defaults to "task-or-run". If "task-or-run", the metric will be logged
                to the current task or run, whichever is the nearest ancestor.

        Returns:
            The logged metric object.
        """
        metric = (
            value
            if isinstance(value, Metric)
            else Metric(
                float(value),
                step,
                timestamp or datetime.now(timezone.utc),
                attributes or {},
            )
        )

        task = current_task_span.get()
        if task is None:
            warn_at_user_stacklevel(
                "log_metric() was called outside of a task or run.",
                category=DreadnodeUsageWarning,
            )
            return metric

        return task.log_metric(name, metric, origin=origin, aggregation=aggregation)

    @t.overload
    def log_metrics(
        self,
        metrics: dict[str, float | bool],
        *,
        step: int = 0,
        timestamp: datetime | None = None,
        aggregation: MetricAggMode | None = None,
        attributes: AnyDict | None = None,
        origin: t.Any | None = None,
    ) -> list[Metric]:
        """
        Log multiple metrics from a dictionary of name/value pairs.

        Examples:
            ```
            dreadnode.log_metrics(
                {
                    "accuracy": 0.95,
                    "loss": 0.05,
                    "f1_score": 0.92
                },
                step=10
            )
            ```

        Args:
            metrics: Dictionary of name/value pairs to log as metrics.
            step: Step value for all metrics.
            timestamp: Timestamp for all metrics.
            aggregation: Aggregation for all metrics.
            attributes: Attributes for all metrics.
            to: The target object to log metrics to. Can be "task-or-run" or "run".
                Defaults to "task-or-run". If "task-or-run", the metrics will be logged
                to the current task or run, whichever is the nearest ancestor.

        Returns:
            List of logged Metric objects.
        """

    @t.overload
    def log_metrics(
        self,
        metrics: list[MetricDict],
        *,
        step: int = 0,
        timestamp: datetime | None = None,
        aggregation: MetricAggMode | None = None,
        attributes: AnyDict | None = None,
        origin: t.Any | None = None,
    ) -> list[Metric]:
        """
        Log multiple metrics from a list of metric configurations.

        Example:
            ```
            dreadnode.log_metrics(
                [
                    {"name": "accuracy", "value": 0.95},
                    {"name": "loss", "value": 0.05, "aggregation": "min"}
                ],
                step=10
            )
            ```

        Args:
            metrics: List of metric configurations to log.
            step: Default step value for metrics if not supplied.
            timestamp: Default timestamp for metrics if not supplied.
            aggregation: Default aggregation for metrics if not supplied.
            attributes: Default attributes for metrics if not supplied.
            to: The target object to log metrics to. Can be "task-or-run" or "run".
                Defaults to "task-or-run". If "task-or-run", the metrics will be logged
                to the current task or run, whichever is the nearest ancestor.

        Returns:
            List of logged Metric objects.
        """

    @handle_internal_errors()
    def log_metrics(
        self,
        metrics: MetricsLike,
        *,
        step: int = 0,
        timestamp: datetime | None = None,
        aggregation: MetricAggMode | None = None,
        attributes: AnyDict | None = None,
        origin: t.Any | None = None,
    ) -> list[Metric]:
        """
        Log multiple metrics to the current task or run.

        Examples:
            Log metrics from a dictionary:
            ```
            dreadnode.log_metrics(
                {
                    "accuracy": 0.95,
                    "loss": 0.05,
                    "f1_score": 0.92
                },
                step=10
            )
            ```

            Log metrics from a list of MetricDicts:
            ```
            dreadnode.log_metrics(
                [
                    {"name": "accuracy", "value": 0.95},
                    {"name": "loss", "value": 0.05, "aggregation": "min"}
                ],
                step=10
            )
            ```

        Args:
            metrics: Either a dictionary of name/value pairs or a list of MetricDicts to log.
            step: Default step value for metrics if not supplied.
            timestamp: Default timestamp for metrics if not supplied.
            aggregation: Default aggregation for metrics if not supplied.
            attributes: Default attributes for metrics if not supplied.
            origin: The origin of the metrics - can be provided any object which was logged
            to: The target object to log metrics to. Can be "task-or-run" or "run".
                Defaults to "task-or-run". If "task-or-run", the metrics will be logged
                to the current task or run, whichever is the nearest ancestor.

        Returns:
            List of logged Metric objects.
        """

        task = current_task_span.get()
        if task is None:
            warn_at_user_stacklevel(
                "log_metrics() was called outside of a task or run.",
                category=DreadnodeUsageWarning,
            )
            return []

        logged_metrics: list[Metric] = []

        # Dictionary of name/value pairs
        if isinstance(metrics, dict):
            logged_metrics = [
                task.log_metric(
                    name,
                    value,
                    step=step,
                    timestamp=timestamp,
                    aggregation=aggregation,
                    attributes=attributes,
                    origin=origin,
                )
                for name, value in metrics.items()
            ]

        # List of MetricDicts
        else:
            logged_metrics = [
                task.log_metric(
                    metric["name"],
                    metric["value"],
                    step=metric.get("step", step),
                    timestamp=metric.get("timestamp", timestamp),
                    aggregation=metric.get("aggregation", aggregation),
                    attributes=metric.get("attributes", attributes) or {},
                    origin=origin,
                )
                for metric in metrics
            ]

        return logged_metrics

    # @handle_internal_errors()
    def log_artifact(
        self,
        local_uri: str | Path,
        *,
        name: str | None = None,
    ) -> None:
        """
        Log a file or directory artifact to the current run.

        This stores the artifact in the workspace CAS and uploads it to remote storage.
        Artifact metadata is recorded in artifacts.jsonl for tracking.

        Examples:
            Log a single file:
            ```
            with dreadnode.run("my_run"):
                # Save a file
                with open("results.json", "w") as f:
                    json.dump(results, f)

                # Log it as an artifact
                dreadnode.log_artifact("results.json")
            ```

            Log a directory:
            ```
            with dreadnode.run("my_run"):
                # Create a directory with model files
                os.makedirs("model_output", exist_ok=True)
                save_model("model_output/model.pkl")
                save_config("model_output/config.yaml")

                # Log the entire directory as an artifact
                dreadnode.log_artifact("model_output")
            ```

        Args:
            local_uri: The local path to the file or directory to upload.
            name: Optional name for the artifact (defaults to filename).
        """
        if (run := current_task_span.get()) is None:
            warn_at_user_stacklevel(
                "log_artifact() was called outside of a run.",
                category=DreadnodeUsageWarning,
            )
            return

        # Store/upload artifact and get metadata
        artifact_metadata = run.log_artifact(local_uri=local_uri, name=name)

        # Write metadata to artifacts.jsonl
        if artifact_metadata and self._trace_config:
            if artifact_metadata.get("type") == "directory":
                # For directories, write each file's metadata
                for file_meta in artifact_metadata.get("files", []):
                    self._trace_config.write_artifact(file_meta)
            else:
                self._trace_config.write_artifact(artifact_metadata)

    @handle_internal_errors()
    def log_input(
        self,
        name: str,
        value: t.Any,
        *,
        label: str | None = None,
        attributes: AnyDict | None = None,
    ) -> None:
        """
        Log a single input to the current span.

        Inputs can be any runtime object, which are serialized, stored, and tracked
        in the Dreadnode UI.

        Args:
            name: The name of the input.
            value: The input value to log.
            label: Optional display label.
            attributes: Optional additional attributes.

        Example:
            ```
            @dreadnode.task
            async def my_task(x: int) -> int:
                dreadnode.log_input("input_name", x)
                return x * 2
            ```
        """
        task = current_task_span.get()
        if task is None:
            warn_at_user_stacklevel(
                "log_input() was called outside of a task or run.",
                category=DreadnodeUsageWarning,
            )
            return

        task.log_input(name, value, label=label, attributes=attributes)

    @handle_internal_errors()
    def log_inputs(self, **inputs: t.Any) -> None:
        """
        Log multiple inputs to the current span.

        See `log_input()` for more details.
        """
        for name, value in inputs.items():
            self.log_input(name, value)

    @handle_internal_errors()
    def log_output(
        self,
        name: str,
        value: t.Any,
        *,
        label: str | None = None,
        attributes: AnyDict | None = None,
    ) -> None:
        """
        Log a single output to the current span.

        Outputs can be any runtime object, which are serialized, stored, and tracked
        in the Dreadnode UI.

        Args:
            name: The name of the output.
            value: The value of the output.
            label: An optional label for the output, useful for filtering in the UI.
            attributes: Additional attributes to attach to the output.

        Example:
            ```
            @dreadnode.task
            async def my_task(x: int) -> int:
                result = x * 2
                dreadnode.log_output("result", result)
                return result
            ```
        """
        task = current_task_span.get()
        if task is None:
            warn_at_user_stacklevel(
                "log_output() was called outside of a task or run.",
                category=DreadnodeUsageWarning,
            )
            return

        task.log_output(name, value, label=label, attributes=attributes)

    @handle_internal_errors()
    def log_outputs(self, **outputs: t.Any) -> None:
        """
        Log multiple outputs to the current span.

        See `log_output()` for more details.
        """
        for name, value in outputs.items():
            self.log_output(name, value)

    @handle_internal_errors()
    def log_sample(
        self,
        label: str,
        input: t.Any,
        output: t.Any,
        metrics: MetricsLike | None = None,
        *,
        step: int = 0,
    ) -> None:
        """
        Convenience method to log an input/output pair with metrics as a ephemeral task.

        This is useful for logging a single sample of input and output data
        along with any metrics that were computed during the process.
        """

        with self.task_span(name=label, label=label):
            self.log_input("input", input)
            self.log_output("output", output)
            self.link_objects(output, input)
            if metrics is not None:
                self.log_metrics(metrics, step=step, origin=output)

    @handle_internal_errors()
    def log_samples(
        self,
        name: str,
        samples: list[tuple[t.Any, t.Any] | tuple[t.Any, t.Any, MetricsLike]],
    ) -> None:
        """
        Log multiple input/output samples as ephemeral tasks.

        This is useful for logging a batch of input/output pairs with metrics
        in a single run.

        Example:
            ```
            dreadnode.log_samples(
                "my_samples",
                [
                    (input1, output1, {"accuracy": 0.95}),
                    (input2, output2, {"accuracy": 0.90}),
                ]
            )
            ```

        Args:
            name: The name of the task to create for each sample.
            samples: A list of tuples containing (input, output, metrics [optional]).
        """
        for sample in samples:
            metrics: MetricsLike | None = None
            if len(sample) == 3:
                input_data, output_data, metrics = sample
            elif len(sample) == 2:
                input_data, output_data = sample
            else:
                raise ValueError(
                    "Each sample must be a tuple of (input, output) or (input, output, metrics)",
                )

            # Log each sample as an ephemeral task
            self.log_sample(name, input_data, output_data, metrics=metrics)

    @handle_internal_errors()
    def link_objects(
        self,
        origin: t.Any,
        link: t.Any,
        attributes: AnyDict | None = None,
    ) -> None:
        """
        Associate two runtime objects with each other.

        This is useful for linking any two objects which are related to
        each other, such as a model and its training data, or an input
        prompt and the resulting output.

        Example:
            ```
            with dreadnode.run("my_run"):
                model = SomeModel()
                data = SomeData()

                dreadnode.link_objects(model, data)
            ```

        Args:
            origin: The origin object to link from.
            link: The linked object to link to.
            attributes: Additional attributes to attach to the link.
        """
        if (run := current_task_span.get()) is None:
            warn_at_user_stacklevel(
                "link_objects() was called outside of a run.",
                category=DreadnodeUsageWarning,
            )
            return

        origin_hash = run.log_object(origin)
        link_hash = run.log_object(link)
        run.link_objects(origin_hash, link_hash, attributes=attributes)

    def serve(
        self,
        host: str | None = None,
        port: int | None = None,
    ) -> None:
        """Start the agent server.

        This starts a FastAPI server that provides REST + SSE endpoints
        for agent communication.

        Args:
            host: Host to bind to. Defaults to DREADNODE_SERVER_HOST or 127.0.0.1.
            port: Port to bind to. Defaults to DREADNODE_SERVER_PORT or 8787.
            model: Default model for agent sessions.

        Example:
            ```python
            import dreadnode as dn
            dn.configure()
            dn.serve(port=8787)
            ```
        """
        from dreadnode.app.server import run_server

        if not self._initialized:
            self.configure()

        run_server(self, host=host, port=port)


DEFAULT_INSTANCE = Dreadnode()
