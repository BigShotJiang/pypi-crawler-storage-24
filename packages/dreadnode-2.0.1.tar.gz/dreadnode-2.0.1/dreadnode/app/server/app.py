"""Dreadnode Agent Server.

FastAPI server with REST endpoints and SSE streaming for agent communication.
"""

from __future__ import annotations

import asyncio
import os
import typing as t
from collections import deque
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from uuid import UUID, uuid4

import uvicorn
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from loguru import logger
from starlette.responses import JSONResponse, StreamingResponse

from dreadnode.app.api.models import (
    CapabilityAgentInfo,
    CapabilityInfo,
    ChatRequest,
    ComponentStatusInfo,
    HealthResponse,
    RuntimeInfoResponse,
    SessionCreateRequest,
    SessionInfo,
    SessionMessage,
    SessionRestoreRequest,
    SessionRestoreResponse,
    ToolInfo,
    ToolsResponse,
)
from dreadnode.app.server.utils import safe_json_dumps
from dreadnode.tracing.span import bind_session_id

if t.TYPE_CHECKING:
    from dreadnode.agents import Agent
    from dreadnode.capabilities.capability import Capability
    from dreadnode.capabilities.types import AgentDef

EventPayload = dict[str, t.Any]
_TERMINAL_CHAT_EVENT_TYPES = frozenset({"agentend", "error"})


@dataclass(slots=True)
class CapabilityRegistry:
    """Registry of capabilities available to the local server."""

    capabilities: dict[str, Capability] = field(default_factory=dict)
    disabled_local: dict[str, Capability] = field(default_factory=dict)
    default_capability_name: str | None = None
    mcp_manager: MCPLifecycleManager | None = None
    workspace_bindings: list[dict[str, t.Any]] = field(default_factory=list)
    load_failures: list[dict[str, t.Any]] = field(default_factory=list)
    local_capability_records: dict[str, dict[str, t.Any]] = field(default_factory=dict)

    def get(self, name: str | None) -> Capability | None:
        if not name:
            return None
        return self.capabilities.get(name)

    def default(self) -> Capability | None:
        if self.default_capability_name:
            return self.capabilities.get(self.default_capability_name)
        if self.capabilities:
            return next(iter(self.capabilities.values()))
        return None

    def resolve(
        self,
        *,
        capability_name: str | None = None,
        agent_name: str | None = None,
    ) -> tuple[str | None, Capability | None, AgentDef | None]:
        """Resolve a capability + agent pair for a new session."""
        if capability_name:
            capability = self.get(capability_name)
            if capability is None:
                raise ValueError(f"Unknown capability: {capability_name}")

            if agent_name:
                agent_def = next(
                    (agent for agent in capability.agents if agent.name == agent_name), None
                )
                if agent_def is None:
                    raise ValueError(
                        f"Agent '{agent_name}' is not defined in capability '{capability_name}'"
                    )
                return capability_name, capability, agent_def

            agent_def = capability.agents[0] if capability.agents else None
            if agent_def is None:
                raise ValueError(f"Capability '{capability_name}' does not define an entry agent")
            return capability_name, capability, agent_def

        if agent_name:
            matches = [
                (loaded_capability_name, capability, agent_def)
                for loaded_capability_name, capability in self.capabilities.items()
                for agent_def in capability.agents
                if agent_def.name == agent_name
            ]
            if len(matches) == 1:
                return matches[0]
            if len(matches) > 1:
                matched_capabilities = ", ".join(
                    sorted(capability_name for capability_name, _, _ in matches)
                )
                raise ValueError(
                    f"Agent '{agent_name}' is defined in multiple capabilities: "
                    f"{matched_capabilities}. Choose a capability explicitly."
                )
            logger.warning(
                "Requested agent '{}' was not found in loaded capabilities; "
                "falling back to the default capability",
                agent_name,
            )

        capability = self.default()
        if capability is None:
            return None, None, None
        capability_name = self.default_capability_name
        if capability_name is None and self.capabilities:
            capability_name = next(iter(self.capabilities))
        agent_def = capability.agents[0] if capability.agents else None
        return capability_name, capability, agent_def

    def all_tools(self) -> list[t.Any]:
        """All tools from all capabilities + MCP servers, deduped by name."""
        seen: set[str] = set()
        tools: list[t.Any] = []
        # Python tools first
        for cap in self.capabilities.values():
            for tool in cap.tools:
                name = _tool_name(tool)
                if name and name not in seen:
                    tools.append(tool)
                    seen.add(name)
                elif name in seen:
                    logger.debug(
                        "Tool '{}' already registered, skipping duplicate",
                        name,
                    )
        # MCP tools
        if self.mcp_manager:
            for tool in self.mcp_manager.all_tools():
                name = _tool_name(tool)
                if name and name not in seen:
                    tools.append(tool)
                    seen.add(name)
                elif name in seen:
                    logger.debug("Tool '%s' already registered (MCP), skipping", name)
        return tools

    def all_skills(self) -> list[t.Any]:
        """Discover skills from all capabilities' skills_paths, deduped by name."""
        from dreadnode.agents.skills import Skill, discover_skills

        seen: set[str] = set()
        skills: list[Skill] = []
        for cap in self.capabilities.values():
            for skills_path in cap.skills_paths or []:
                for skill in discover_skills(skills_path):
                    if skill.name not in seen:
                        skills.append(skill)
                        seen.add(skill.name)
                    else:
                        logger.debug(
                            "Skill '%s' already registered, skipping duplicate",
                            skill.name,
                        )
        return skills

    def find_agent(self, agent_name: str) -> tuple[str, t.Any, AgentDef] | None:
        """Find an agent by name across all capabilities.

        Returns (capability_name, capability, agent_def) or None.
        """
        for cap_name, cap in self.capabilities.items():
            for agent_def in cap.agents:
                if agent_def.name == agent_name:
                    return (cap_name, cap, agent_def)
        return None

    def to_runtime_info(self, *, working_dir: Path) -> RuntimeInfoResponse:
        """Serialize registry state for CLI/runtime introspection (CAP-LOAD-022)."""
        from dreadnode.capabilities.sync import bare_capability_name

        def _provenance_for(*, bare_name: str, source: str) -> str | None:
            if source == "project":
                return None
            record = self.local_capability_records.get(bare_name, {})
            persisted = record.get("source")
            if persisted in {"org", "public"}:
                return t.cast(str, persisted)
            return "local"

        def _display_identity(
            *,
            bare_name: str,
            source: str,
            binding: dict[str, t.Any] | None = None,
        ) -> tuple[str, str | None]:
            canonical_name = None
            if binding is not None:
                binding_name = binding.get("capability_name")
                if isinstance(binding_name, str) and binding_name.strip():
                    canonical_name = binding_name
            if canonical_name is not None:
                return canonical_name, canonical_name
            if source in {"local", "package"}:
                record = self.local_capability_records.get(bare_name, {})
                artifact_identity = record.get("artifact_identity")
                if isinstance(artifact_identity, str) and artifact_identity.strip():
                    return bare_name, artifact_identity
                return bare_name, None
            return f"{source}/{bare_name}", None

        def _capability_metadata(capability: t.Any) -> tuple[str | None, dict[str, t.Any] | None, str | None, dict[str, t.Any] | None]:
            contract = getattr(capability, "contract", None)
            description = getattr(capability, "description", None)
            if description is None and contract is not None:
                description = getattr(contract, "description", None)

            author = getattr(capability, "author", None)
            if author is None and contract is not None:
                author = getattr(contract, "author", None)

            license_name = getattr(capability, "license", None)
            if license_name is None and contract is not None:
                license_name = getattr(contract, "license", None)

            origin = getattr(capability, "origin", None)
            if origin is None and contract is not None:
                repository = getattr(contract, "repository", None)
                if isinstance(repository, str) and repository.strip():
                    origin = {"type": "repository", "url": repository}

            return description, author, license_name, origin

        capabilities_out: list[CapabilityInfo] = []

        # Build binding lookup: bare_name -> binding dict
        binding_by_bare: dict[str, dict[str, t.Any]] = {}
        for binding in self.workspace_bindings:
            bare = bare_capability_name(binding.get("capability_name", ""))
            binding_by_bare[bare] = binding

        # 1. Effective capabilities
        for name, capability in self.capabilities.items():
            source = getattr(capability, "source", "local")
            version = getattr(capability, "version", None)
            health = getattr(capability, "component_health", [])

            # Match binding by bare name
            binding = binding_by_bare.pop(name, None)
            binding_id = binding.get("id") if binding else None
            display_name, canonical_name = _display_identity(
                bare_name=name,
                source=source,
                binding=binding,
            )
            description, author, license_name, origin = _capability_metadata(capability)

            capabilities_out.append(CapabilityInfo(
                name=name,
                display_name=display_name,
                canonical_name=canonical_name,
                source=source,
                provenance=_provenance_for(bare_name=name, source=source),
                version=version,
                description=description,
                author=author,
                license=license_name,
                origin=origin,
                enabled=True,
                binding_id=binding_id,
                components=[ComponentStatusInfo(**entry) for entry in health],
                entry_agent=None,
                skills_paths=[
                    str(p) for p in (
                        capability.skills_paths
                        or ([] if capability.skills_path is None else [capability.skills_path])
                    )
                ],
                agents=[
                    CapabilityAgentInfo(
                        name=a.name, description=a.description, model=a.model, capability=name,
                    )
                    for a in capability.agents
                ],
            ))

        # 2. Disabled workspace bindings (remaining in binding_by_bare after effective caps consumed theirs)
        for bare, binding in binding_by_bare.items():
            if not binding.get("enabled", True):
                display_name, canonical_name = _display_identity(
                    bare_name=bare,
                    source="project",
                    binding=binding,
                )
                capabilities_out.append(CapabilityInfo(
                    name=bare,
                    display_name=display_name,
                    canonical_name=canonical_name,
                    source="project",
                    provenance=None,
                    version=binding.get("version"),
                    enabled=False,
                    binding_id=binding.get("id"),
                    components=[],
                ))

        # 3. Disabled local capabilities
        for name, capability in self.disabled_local.items():
            source = getattr(capability, "source", "local")
            version = getattr(capability, "version", None)
            display_name, canonical_name = _display_identity(
                bare_name=name,
                source=source,
                binding=None,
            )
            description, author, license_name, origin = _capability_metadata(capability)
            capabilities_out.append(CapabilityInfo(
                name=name,
                display_name=display_name,
                canonical_name=canonical_name,
                source=source,
                provenance=_provenance_for(bare_name=name, source=source),
                version=version,
                description=description,
                author=author,
                license=license_name,
                origin=origin,
                enabled=False,
                components=[],
            ))

        # 4. Load failures
        for failure in self.load_failures:
            name = failure.get("name", "unknown")
            display_name, canonical_name = _display_identity(
                bare_name=name,
                source="local",
                binding=None,
            )
            capabilities_out.append(CapabilityInfo(
                name=name,
                display_name=display_name,
                canonical_name=canonical_name,
                source="local",
                provenance=_provenance_for(bare_name=name, source="local"),
                enabled=True,
                components=[ComponentStatusInfo(
                    kind="capability",
                    name=name,
                    status="error",
                    error=failure.get("error"),
                    detail="Check capability.yaml format and directory structure",
                )],
            ))

        host = "sandbox" if os.environ.get("DREADNODE_PROJECT_ID", "").strip() else "local"
        return RuntimeInfoResponse(
            host_type=host,
            working_dir=str(working_dir),
            default_capability=self.default_capability_name,
            capabilities=capabilities_out,
        )


@dataclass
class MCPLifecycleManager:
    """Manages MCP server connections for all capabilities.

    Owns connect/disconnect lifecycle. Tools from connected servers
    are exposed via all_tools().
    """

    _clients: dict[str, t.Any] = field(default_factory=dict)

    async def start(self, registry: CapabilityRegistry) -> None:
        """Connect to all MCP servers from all capabilities (CAP-MCP-007: best-effort)."""
        from dreadnode.agents.mcp.client import MCPClient

        for cap in registry.capabilities.values():
            cap_health = getattr(cap, "component_health", None)

            for server_def in cap.mcp_server_defs:
                qualified = f"{cap.name}:{server_def.name}"
                try:
                    config = server_def.to_server_config()
                    client = MCPClient.from_config(config)
                    await client.connect()
                    self._clients[qualified] = client
                    logger.info("MCP server connected: %s", qualified)
                except Exception as exc:
                    logger.warning(
                        "MCP server '%s' failed to start — skipping",
                        qualified,
                        exc_info=True,
                    )
                    # Update component_health entry for this server
                    if cap_health is not None:
                        for entry in cap_health:
                            if entry.get("kind") == "mcp_server" and entry.get("name") == server_def.name:
                                entry["status"] = "error"
                                entry["error"] = str(exc)
                                entry["detail"] = "Check server command/URL and authentication credentials"
                                break

    async def stop(self) -> None:
        """Disconnect all MCP servers."""
        for name, client in self._clients.items():
            try:
                await client.disconnect()
            except Exception:
                logger.warning("Error disconnecting MCP server '%s'", name, exc_info=True)
        self._clients.clear()

    def all_tools(self) -> list[t.Any]:
        """Collect tools from all connected MCP servers."""
        tools: list[t.Any] = []
        for client in self._clients.values():
            tools.extend(client.tools)
        return tools


def _format_session_binding(
    capability_name: str | None,
    agent_name: str | None,
) -> str:
    """Render a human-readable capability/agent binding."""
    parts: list[str] = []
    if capability_name:
        parts.append(f"capability '{capability_name}'")
    if agent_name:
        parts.append(f"agent '{agent_name}'")
    return " / ".join(parts) if parts else "the default runtime"


def _resolve_session_model(
    requested_model: str | None,
    agent_def: AgentDef | None,
) -> str:
    """Resolve the model for a session from the request or the selected agent."""
    if requested_model:
        return requested_model

    if agent_def and agent_def.model and agent_def.model != "inherit":
        return agent_def.model

    agent_name = agent_def.name if agent_def else "default"
    raise ValueError(
        f"Agent '{agent_name}' does not define a model. Pass one explicitly when creating the session."
    )


def _tool_name(tool: t.Any) -> str:
    """Get the name of a tool object."""
    return getattr(tool, "name", "")


_CORE_SYSTEM_PROMPT: str | None = None


def _get_core_system_prompt() -> str:
    """Read the core system prompt, cached after first load."""
    global _CORE_SYSTEM_PROMPT
    if _CORE_SYSTEM_PROMPT is None:
        prompt_path = Path(__file__).parent / "system-prompt.md"
        _CORE_SYSTEM_PROMPT = prompt_path.read_text().strip() if prompt_path.exists() else ""
    return _CORE_SYSTEM_PROMPT


def _final_assistant_message(trajectory: t.Any) -> str:
    """Extract the last assistant message text from a trajectory."""
    for message in reversed(trajectory.messages):
        if getattr(message, "role", None) == "assistant":
            content = getattr(message, "content", "")
            if isinstance(content, str):
                return content
            if isinstance(content, list):
                texts = [
                    block.get("text", "") if isinstance(block, dict) else str(block)
                    for block in content
                ]
                return "".join(texts)
    return ""




def create_agent(
    model: str | None,
    *,
    capability: Capability | None = None,
    agent_def: AgentDef | None = None,
    extra_tools: list[t.Any] | None = None,
) -> Agent:
    """Create an agent from a loaded capability.

    Tool assembly order:
    1. Inherent tools (from default_tools()) — always present
    2. Extra tools (from global capability pool) — additive, skip duplicates
    3. Link tools (synthetic delegation tools) — always added
    4. Agent tool rules filter the combined pool (empty rules = all tools)
    """
    from dreadnode.agents import Agent
    from dreadnode.capabilities.tool_rules import filter_tools
    from dreadnode.tools import default_tools

    effective_model = model
    if agent_def and agent_def.model and agent_def.model != "inherit":
        effective_model = agent_def.model
    if not effective_model or effective_model == "inherit":
        raise ValueError(
            f"Agent '{agent_def.name if agent_def else 'dreadnode-agent'}' does not define a model"
        )

    working_dir = Path.cwd()
    home_dir = Path.home()
    context = f"\nYour working directory is {working_dir}.\nYour home directory is {home_dir}.\n"

    # System prompt: agent_def overrides core prompt; capability prompt layers on top
    core_prompt = _get_core_system_prompt()
    agent_prompt = agent_def.system_prompt if agent_def and agent_def.system_prompt else ""
    base_prompt = agent_prompt or core_prompt
    instructions = base_prompt + context
    capability_system_prompt = (
        _read_capability_system_prompt(capability.path) if capability is not None else ""
    )
    if capability_system_prompt:
        instructions = instructions + "\n" + capability_system_prompt

    # 1. Inherent tools — always present
    base = default_tools()
    pool: list[t.Any] = list(base.values())
    pool_names = set(base.keys())

    # 2. Extra tools from global capability pool — skip duplicates
    for tool in extra_tools or []:
        name = _tool_name(tool)
        if name and name not in pool_names:
            pool.append(tool)
            pool_names.add(name)

    # 3. Apply agent's tool rules (empty dict = all tools pass)
    rules = agent_def.tools if agent_def else {}
    tools = filter_tools(pool, rules, name_fn=_tool_name)

    # Core hooks — always present
    from dreadnode.agents.hooks import default_hooks

    hooks = default_hooks()

    return Agent(
        name=agent_def.name if agent_def else "dreadnode-agent",
        model=effective_model,
        instructions=instructions,
        tools=tools,
        hooks=hooks,
    )


@dataclass(slots=True)
class QueuedChatRequest:
    """Single chat turn waiting to be processed for a session."""

    message: str
    agent: str | None
    reset: bool
    event_queue: asyncio.Queue[EventPayload | None]
    generate_params_extra: dict[str, t.Any] | None = None


# =============================================================================
# FastAPI Application
# =============================================================================


@asynccontextmanager
async def _lifespan(app_instance: t.Any) -> t.AsyncIterator[None]:
    """FastAPI lifespan: start MCP servers on startup, stop on shutdown."""
    state = get_state()
    registry = state.capability_registry
    if registry and registry.mcp_manager is None:
        registry.mcp_manager = MCPLifecycleManager()
    if registry and registry.mcp_manager:
        await registry.mcp_manager.start(registry)
    yield
    if registry and registry.mcp_manager:
        await registry.mcp_manager.stop()


app = FastAPI(
    title="Dreadnode Agent Server",
    description="REST + SSE server for Dreadnode agents",
    version="1.0.0",
    lifespan=_lifespan,
)


class ServerState:
    """Server state container stored on app.state."""

    def __init__(self) -> None:
        self.capability_registry: CapabilityRegistry | None = None
        self._sessions: dict[str, SessionRuntime] = {}

    def get_session(self, session_id: str) -> SessionRuntime | None:
        """Get a session by ID."""
        return self._sessions.get(session_id)

    def has_session(self, session_id: str) -> bool:
        """Check if a session exists."""
        return session_id in self._sessions

    def list_sessions(self) -> list[SessionRuntime]:
        """List all sessions."""
        return list(self._sessions.values())

    def create_session(
        self,
        *,
        session_id: str | None = None,
        model: str | None = None,
        project: str | None = None,
        capability: str | None = None,
        agent: str | None = None,
        messages: list[SessionMessage] | None = None,
    ) -> SessionRuntime:
        """Create a new session or return an existing compatible one."""
        if session_id is not None and not session_id:
            raise ValueError("session_id must be a non-empty string")
        resolved_id = session_id or str(uuid4())

        if resolved_id in self._sessions:
            session = self._sessions[resolved_id]
            if agent is not None and session.agent_name is not None and agent != session.agent_name:
                raise ValueError(
                    f"Session '{resolved_id}' already started with agent '{session.agent_name}'. "
                    f"Create a new session to start with agent '{agent}'."
                )
            return session

        capability_name, capability_obj, agent_def = (
            self.capability_registry.resolve(capability_name=capability, agent_name=agent)
            if self.capability_registry is not None
            else (None, None, None)
        )

        session = SessionRuntime(
            resolved_id,
            model=_resolve_session_model(model, agent_def),
            project=project,
            registry=self.capability_registry,
            capability_name=capability_name,
            capability=capability_obj,
            agent_def=agent_def,
        )
        if messages:
            session.restore_messages(messages)
        session.persist_manifest()
        self._sessions[resolved_id] = session

        # Best-effort registration with platform
        _register_session_with_platform(session)

        # Eagerly create the agent so first chat doesn't pay tool-assembly cost
        try:
            session.get_agent()
        except Exception:
            logger.debug("Eager agent creation deferred", exc_info=True)

        return session

    def delete_session(self, session_id: str) -> bool:
        """Delete a session. Returns True if deleted, False if not found."""
        session = self._sessions.pop(session_id, None)
        if session is None:
            return False
        session.close()
        return True


def _register_session_with_platform(session: SessionRuntime) -> None:
    """Best-effort registration of a new session with the platform API.

    Fire-and-forget: logs warnings on failure but never raises.
    """
    try:
        from dreadnode import _get_default_instance

        instance = _get_default_instance()
        if not instance.can_sync:
            return

        api = instance.api
        org = instance.organization
        ws = instance.workspace

        if not isinstance(org, str) or not isinstance(ws, str):
            return

        project_key = session.project_key
        if project_key is None:
            default_project_key = getattr(instance, "project", None)
            if isinstance(default_project_key, str):
                project_key = default_project_key

        project_id: str | None = None
        active_session = getattr(instance, "session", None)
        active_project = getattr(active_session, "project", None)
        active_project_id = getattr(active_project, "id", None)
        active_project_key = getattr(active_project, "key", None)
        if (
            project_key
            and active_project_id is not None
            and (active_project_key is None or active_project_key == project_key)
        ):
            project_id = str(active_project_id)
        elif project_key:
            project = api.get_project(org, ws, project_key)
            project_id = str(project.id)

        api.save_session(
            org,
            ws,
            session.session_id,
            session.model,
            title=session.title,
            message_count=session.message_count,
            project_id=project_id,
        )
    except Exception:
        logger.debug("Failed to register session with platform (best-effort)")


def get_state() -> ServerState:
    """Get the server state from app.state."""
    if not hasattr(app.state, "server"):
        app.state.server = ServerState()
    return app.state.server


# =============================================================================
# Session Runtime
# =============================================================================


class SessionRuntime:
    """Encapsulates the runtime state for a single persisted session."""

    def __init__(
        self,
        session_id: str,
        *,
        model: str,
        project: str | None = None,
        registry: CapabilityRegistry | None = None,
        capability_name: str | None = None,
        capability: Capability | None = None,
        agent_def: AgentDef | None = None,
    ) -> None:
        self.session_id = session_id
        self.model = model
        self.project_key = project
        self.created_at = datetime.now(timezone.utc)
        self.title: str | None = None

        self._agent: Agent | None = None
        self._session_dir: Path | None = None
        self._queue: deque[QueuedChatRequest] = deque()
        self._queue_lock = asyncio.Lock()
        self._processing_task: asyncio.Task[None] | None = None
        self._registry = registry
        self._capability_name = capability_name
        self._capability = capability
        self._agent_def = agent_def
        self._generate_params_extra: dict[str, t.Any] = {}
        self._message_count: int = 0
        # Session owns the trajectory — agents are ephemeral
        from dreadnode.agents.trajectory import Trajectory as TrajectoryModel

        self._trajectory = TrajectoryModel()

        # Permission handling
        self._pending_permissions: dict[str, asyncio.Event] = {}
        self._permission_decisions: dict[str, str] = {}
        self._session_allowlist: set[str] = set()

        # Human prompt handling
        self._pending_human_prompts: dict[str, HumanPrompt] = {}
        self._pending_human_inputs: dict[str, asyncio.Future[HumanInputResponse]] = {}
        self._resolved_human_inputs: dict[str, HumanInputResponse] = {}

    @property
    def _storage(self) -> t.Any:
        from dreadnode import _get_default_instance

        return _get_default_instance().storage

    @property
    def manifest_file(self) -> Path:
        """Path to the minimal session manifest."""
        return self._storage.session_runtime_path(self.session_id, ext="json")

    @property
    def capability_name(self) -> str | None:
        """Name of the capability bound to this session."""
        return self._capability_name

    @property
    def agent_name(self) -> str | None:
        """Name of the primary agent for this session."""
        return self._agent_def.name if self._agent_def else None

    def is_compatible(self) -> bool:
        """Check whether the session can be reused.

        Sessions are no longer scoped to a single capability — all
        capability tools are globally visible via the registry.
        """
        return True

    def _ensure_session_dir(self) -> Path:
        """Create and return the session directory."""
        if self._session_dir is None:
            self._session_dir = self._storage.session_path(self.session_id)
            self._session_dir.mkdir(parents=True, exist_ok=True)
        return self._session_dir

    def _create_agent(
        self,
        *,
        agent_name: str | None = None,
        generate_params_extra: dict[str, t.Any] | None = None,
    ) -> Agent:
        """Create a fresh agent for this turn.

        Agents are ephemeral — created per-turn with current params.
        Trajectory lives on the session, not the agent.
        """
        self._ensure_session_dir()
        capability = self._capability
        agent_def = self._agent_def
        if agent_name and self._registry is not None:
            _, capability, agent_def = self._registry.resolve(agent_name=agent_name)
        extra_tools = self._registry.all_tools() if self._registry else []
        agent = create_agent(
            self.model,
            capability=capability,
            agent_def=agent_def,
            extra_tools=extra_tools,
        )
        self._wire_server_tools(agent)

        # Apply generate_params_extra (per-message overrides session default)
        effective_extra = generate_params_extra or self._generate_params_extra
        if effective_extra:
            agent.generate_params_extra = dict(effective_extra)

        return agent

    def get_agent(self) -> Agent:
        """Get or create agent (backward compat for restore paths).

        For chat turns, use _create_agent() which creates fresh agents.
        """
        if self._agent is None:
            self._agent = self._create_agent()
        return self._agent

    def _wire_server_tools(self, agent: Agent) -> None:
        """Add tools that need server context to an already-created agent."""
        from dreadnode.agents.subagent import create_subagent_tool

        agent.tools.append(create_subagent_tool(agent))

        # Skills — pooled from all capabilities, or standalone capability
        all_skills: list = []
        if self._registry:
            all_skills = self._registry.all_skills()
        elif self._capability:
            from dreadnode.agents.skills import discover_skills

            for skills_path in getattr(self._capability, "skills_paths", None) or []:
                all_skills.extend(discover_skills(skills_path))

        if all_skills:
            from dreadnode.agents.skills import create_skill_tool

            agent.tools.append(create_skill_tool(all_skills))

        # Trajectory search (requires storage)
        try:
            from dreadnode.tools.trajectory_search import TrajectorySearch

            storage = self._storage
            if storage is not None:
                agent.tools.append(TrajectorySearch(storage=storage))
        except Exception:
            logger.debug("TrajectorySearch not available", exc_info=True)

    @property
    def trajectory(self) -> t.Any:
        """Get session trajectory (owned by session, not agent)."""
        return self._trajectory

    @property
    def message_count(self) -> int:
        """Number of completed chat turns."""
        return self._message_count

    def reset(self) -> None:
        """Reset the conversation history."""
        from dreadnode.agents.trajectory import Trajectory as TrajectoryModel

        self._trajectory = TrajectoryModel()
        self._message_count = 0
        self._agent = None

    def restore_messages(self, messages: list[SessionMessage]) -> None:
        """Seed the session agent trajectory from a simple message list."""
        from dreadnode.agents.trajectory import trajectory_from_openai_format

        if not messages:
            return

        agent = self.get_agent()
        trajectory = trajectory_from_openai_format(
            [
                {
                    "role": message.role,
                    "content": message.content,
                }
                for message in messages
            ]
        )
        trajectory.agent_id = agent.agent_id
        trajectory.system_prompt = agent.instructions
        try:
            trajectory.session_id = UUID(self.session_id)
        except ValueError:
            pass
        self._trajectory = trajectory
        self._agent = None  # Clear so next turn creates fresh

    def restore_trajectory(self, trajectory_data: dict[str, t.Any]) -> None:
        """Restore the session agent from a serialized trajectory."""
        from dreadnode.agents.trajectory import Trajectory as TrajectoryModel

        agent = self.get_agent()
        trajectory = TrajectoryModel.from_dict(trajectory_data)
        trajectory.agent_id = agent.agent_id
        trajectory.system_prompt = agent.instructions
        try:
            trajectory.session_id = UUID(self.session_id)
        except ValueError:
            pass
        self._trajectory = trajectory
        self._agent = None

    def resolve_permission(self, request_id: str, decision: str) -> None:
        """Resolve a pending permission request with a user decision."""
        self._permission_decisions[request_id] = decision
        if decision == "allow_session":
            # Store the tool name for auto-approval
            self._session_allowlist.add(request_id)
        event = self._pending_permissions.get(request_id)
        if event is not None:
            event.set()

    def register_human_prompt(self, prompt: HumanPrompt) -> asyncio.Future[HumanInputResponse]:
        """Register a pending human prompt and return its response future."""
        existing = self._pending_human_inputs.get(prompt.request_id)
        if existing is not None:
            return existing
        loop = asyncio.get_running_loop()
        future: asyncio.Future[HumanInputResponse] = loop.create_future()
        self._pending_human_prompts[prompt.request_id] = prompt
        self._pending_human_inputs[prompt.request_id] = future
        return future

    def resolve_human_input_response(self, response: HumanInputResponse) -> bool:
        """Resolve a pending human prompt response. Returns True if applied."""
        request_id = response.request_id
        if request_id in self._resolved_human_inputs:
            return True
        future = self._pending_human_inputs.pop(request_id, None)
        self._pending_human_prompts.pop(request_id, None)
        if future is None:
            return False
        if not future.done():
            future.set_result(response)
        self._resolved_human_inputs[request_id] = response
        return True

    def resolve_human_response(self, response: HumanInputResponse) -> bool:
        """Resolve a human response against prompts or permissions."""
        if self.resolve_human_input_response(response):
            return True
        if response.action in {"approve", "deny", "allow_session"}:
            if response.request_id in self._pending_permissions:
                decision_map = {
                    "approve": "allow",
                    "deny": "deny",
                    "allow_session": "allow_session",
                }
                self.resolve_permission(response.request_id, decision_map[response.action])
                return True
        return False

    def close(self) -> None:
        """Stop any background processing associated with this session."""
        if self._processing_task is not None and not self._processing_task.done():
            self._processing_task.cancel()

    def persist_manifest(self) -> None:
        """Persist minimal runtime metadata needed to rebind the session."""
        self._ensure_session_dir()

        data: dict[str, t.Any] = {
            "session_id": self.session_id,
            "model": self.model,
            "project": self.project_key,
            "created_at": self.created_at.isoformat(),
        }
        if self.capability_name is not None:
            data["capability"] = self.capability_name
        if self.agent_name is not None:
            data["agent"] = self.agent_name

        self.manifest_file.write_text(safe_json_dumps(data), encoding="utf-8")

    async def enqueue_chat(
        self,
        message: str,
        *,
        agent: str | None = None,
        reset: bool = False,
        generate_params_extra: dict[str, t.Any] | None = None,
    ) -> asyncio.Queue[EventPayload | None]:
        """Queue a chat turn and ensure the session processor is running."""
        event_queue: asyncio.Queue[EventPayload | None] = asyncio.Queue()
        request = QueuedChatRequest(
            message=message,
            agent=agent,
            reset=reset,
            event_queue=event_queue,
            generate_params_extra=generate_params_extra,
        )

        async with self._queue_lock:
            self._queue.append(request)
            task_running = self._processing_task is not None and not self._processing_task.done()
            if not task_running:
                self._processing_task = asyncio.create_task(self._process_queue())
            else:
                logger.debug(
                    "Session {}: queued message (task still running, queue={})",
                    self.session_id[:8],
                    len(self._queue),
                )

        return event_queue

    async def _process_queue(self) -> None:
        """Process queued chat turns sequentially for this session."""
        while True:
            async with self._queue_lock:
                if not self._queue:
                    self._processing_task = None
                    return
                request = self._queue.popleft()

            logger.debug(
                "Session {}: processing chat (message={}...)",
                self.session_id[:8],
                request.message[:40],
            )

            try:
                # Fresh agent per turn — reads current params
                agent = self._create_agent(
                    agent_name=request.agent,
                    generate_params_extra=request.generate_params_extra,
                )

                # Inject session trajectory (agent borrows it for this turn)
                agent.trajectory = self._trajectory

                from dreadnode.tools.interaction import (
                    reset_human_prompt_handler,
                    set_human_prompt_handler,
                )

                async def _human_prompt_handler(prompt: HumanPrompt) -> HumanInputResponse:
                    future = self.register_human_prompt(prompt)
                    await request.event_queue.put(
                        {
                            "type": "userinputrequired",
                            "data": prompt.model_dump(),
                        }
                    )
                    return await future

                token = set_human_prompt_handler(_human_prompt_handler)
                try:
                    with bind_session_id(self.session_id):
                        async with agent.stream(request.message, reset=request.reset) as stream:
                            async for event in stream:
                                await request.event_queue.put(event.as_dict())
                finally:
                    reset_human_prompt_handler(token)

                # After streaming, update session trajectory reference
                self._trajectory = agent.trajectory
                self._message_count += 1

                # Clear cached agent so restore paths create fresh
                self._agent = None
            except Exception as exc:
                logger.exception("Error during chat for session {}", self.session_id)
                await request.event_queue.put({"type": "error", "error": str(exc)})
            finally:
                logger.debug("Session {}: chat turn complete", self.session_id[:8])
                await request.event_queue.put(None)

    def to_info(self) -> SessionInfo:
        """Convert to SessionInfo for API responses."""
        return SessionInfo(
            session_id=self.session_id,
            model=self.model,
            project=self.project_key,
            created_at=self.created_at,
            message_count=self.message_count,
            session_dir=str(self._session_dir) if self._session_dir else None,
            capability=self.capability_name,
            agent=self.agent_name,
            title=self.title,
        )


# =============================================================================
# Routes
# =============================================================================


@app.get("/api/sessions", response_model=list[SessionInfo])
async def list_sessions() -> list[SessionInfo]:
    """List all active agent sessions."""
    return [session.to_info() for session in get_state().list_sessions()]


@app.post("/api/sessions", response_model=SessionInfo)
async def create_session(request: SessionCreateRequest) -> SessionInfo:
    """Create or resolve a capability-bound session runtime."""
    try:
        session = get_state().create_session(
            session_id=request.session_id,
            model=request.model,
            project=request.project,
            capability=request.capability,
            agent=request.agent,
            messages=request.messages,
        )
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    return session.to_info()


@app.post("/api/sessions/{session_id}/restore", response_model=SessionRestoreResponse)
async def restore_session(
    session_id: str,
    request: SessionRestoreRequest,
) -> SessionRestoreResponse:
    """Restore a bound session runtime from saved messages or trajectory data."""
    try:
        session = get_state().create_session(
            session_id=session_id,
            model=request.model,
            project=request.project,
            capability=request.capability,
            agent=request.agent,
        )
        if request.trajectory is not None:
            session.restore_trajectory(request.trajectory)
        elif request.messages:
            session.restore_messages(request.messages)
        session.persist_manifest()
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    step_count = len(session.trajectory.steps) if session.trajectory is not None else 0
    return SessionRestoreResponse(
        session_id=session.session_id,
        message_count=session.message_count,
        step_count=step_count,
        capability=session.capability_name,
        agent=session.agent_name,
        model=session.model,
        project=session.project_key,
    )


@app.get("/api/sessions/{session_id}", response_model=SessionInfo)
async def get_session(session_id: str) -> SessionInfo:
    """Get information about a specific session."""
    session = get_state().get_session(session_id)
    if session is None:
        raise HTTPException(status_code=404, detail=f"Session not found: {session_id}")
    return session.to_info()


@app.delete("/api/sessions/{session_id}")
async def delete_session(session_id: str) -> JSONResponse:
    """Delete an agent session."""
    if not get_state().delete_session(session_id):
        raise HTTPException(status_code=404, detail=f"Session not found: {session_id}")
    return JSONResponse(content={"status": "deleted", "session_id": session_id})


@app.post("/api/chat", response_model=None)
async def chat_endpoint(request: ChatRequest) -> StreamingResponse | JSONResponse:
    """Send a message to the agent with SSE streaming."""
    session = get_state().get_session(request.session_id)
    if session is None:
        # Auto-create session if it doesn't exist (e.g. frontend sends chat before POST /api/sessions)
        session = get_state().create_session(session_id=request.session_id)

    # Handle human input response
    if request.human_input_response is not None:
        if session.resolve_human_response(request.human_input_response):
            return JSONResponse({"status": "human_prompt_resolved"})
        raise HTTPException(
            status_code=409,
            detail=f"Unknown or expired request_id: {request.human_input_response.request_id}",
        )

    # Handle permission response
    if request.permission_response is not None:
        session.resolve_permission(
            request.permission_response.request_id,
            request.permission_response.decision,
        )
        return JSONResponse({"status": "permission_resolved"})

    event_queue = await session.enqueue_chat(
        request.message,
        agent=request.agent,
        reset=request.reset,
        generate_params_extra=request.generate_params_extra,
    )

    async def generate_events() -> t.AsyncIterator[str]:
        while True:
            event = await event_queue.get()
            if event is None:
                break
            yield f"data: {safe_json_dumps(event)}\n\n"
            event_type = str(event.get("type", "")).lower()
            if event_type in _TERMINAL_CHAT_EVENT_TYPES:
                break

    return StreamingResponse(
        generate_events(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "Connection": "keep-alive"},
    )


@app.post("/api/sessions/{session_id}/title")
async def set_session_title(session_id: str, body: dict[str, t.Any]) -> JSONResponse:
    """Set the session title."""
    session = get_state().get_session(session_id)
    if session is None:
        raise HTTPException(status_code=404, detail=f"Session not found: {session_id}")
    title = body.get("title", "")
    session.title = title if title else None
    return JSONResponse({"status": "ok", "session_id": session_id, "title": session.title})


@app.post("/api/sessions/{session_id}/reset")
async def reset_session(session_id: str) -> JSONResponse:
    """Reset the agent conversation."""
    session = get_state().get_session(session_id)
    if session is None:
        raise HTTPException(status_code=404, detail=f"Session not found: {session_id}")
    session.reset()
    return JSONResponse(content={"status": "reset", "session_id": session_id})


# =============================================================================
# File & Shell Endpoints
# =============================================================================

IGNORED_NAMES = frozenset(
    {
        ".git",
        ".hg",
        ".svn",
        "node_modules",
        "__pycache__",
        ".venv",
        "venv",
        ".tox",
        ".mypy_cache",
        ".pytest_cache",
        ".ruff_cache",
        "dist",
        "build",
        ".eggs",
    }
)


@app.get("/api/files")
async def list_files(
    path: str | None = None,
    depth: int = 10,
) -> JSONResponse:
    """List directory contents recursively."""

    # When DREADNODE_PROJECT_ROOT is set (E2B sandboxes), scope the file
    # browser to the workspace directory instead of showing the entire
    # home directory (which may contain pip-installed SDK source trees).
    project_root = os.environ.get("DREADNODE_PROJECT_ROOT")
    if project_root:
        base = Path(project_root)
    elif path:
        base = Path(path)
    else:
        base = Path.cwd()
    if not base.is_dir():
        return JSONResponse({"path": str(base), "entries": [], "error": "Not a directory"})

    entries: list[dict[str, t.Any]] = []

    async def _walk(dir_path: Path, current_depth: int) -> None:
        try:
            items = sorted(dir_path.iterdir())
        except PermissionError:
            return
        for item in items:
            if item.name.startswith(".") or item.name in IGNORED_NAMES:
                continue
            is_dir = item.is_dir()
            size = None
            if not is_dir:
                try:
                    size = item.stat().st_size
                except OSError:
                    pass
            entries.append(
                {
                    "name": item.name,
                    "path": str(item.relative_to(base)),
                    "isDir": is_dir,
                    "size": size,
                }
            )
            if is_dir and current_depth < depth:
                await _walk(item, current_depth + 1)

    await _walk(base, 0)
    return JSONResponse({"path": str(base), "entries": entries})


@app.get("/api/files/read")
async def read_file(path: str) -> JSONResponse:
    """Read a file's content."""
    file_path = Path(path)
    if not file_path.is_file():
        return JSONResponse(
            {"path": path, "content": "", "error": "File not found"}, status_code=404
        )
    try:
        content = file_path.read_text(encoding="utf-8", errors="replace")
        return JSONResponse({"path": path, "content": content})
    except Exception as exc:
        return JSONResponse({"path": path, "content": "", "error": str(exc)}, status_code=500)


@app.post("/api/shell")
async def execute_shell(
    command: str = "",
    cwd: str | None = None,
    timeout: int = 30,
) -> JSONResponse:
    """Execute a shell command directly (not through agent)."""
    import asyncio as _asyncio

    if not command.strip():
        return JSONResponse({"error": "Empty command"}, status_code=400)

    work_dir = cwd or str(Path.cwd())
    try:
        proc = await _asyncio.create_subprocess_shell(
            command,
            stdout=_asyncio.subprocess.PIPE,
            stderr=_asyncio.subprocess.PIPE,
            cwd=work_dir,
        )
        stdout_bytes, stderr_bytes = await _asyncio.wait_for(proc.communicate(), timeout=timeout)
        return JSONResponse(
            {
                "stdout": stdout_bytes.decode("utf-8", errors="replace"),
                "stderr": stderr_bytes.decode("utf-8", errors="replace"),
                "exitCode": proc.returncode,
                "command": command,
            }
        )
    except _asyncio.TimeoutError:
        proc.kill()
        return JSONResponse(
            {"error": f"Command timed out after {timeout}s", "command": command}, status_code=408
        )
    except Exception as exc:
        return JSONResponse({"error": str(exc), "command": command}, status_code=500)


@app.get("/api/health", response_model=HealthResponse)
async def health_check() -> HealthResponse:
    """Health check endpoint."""
    return HealthResponse(status="ok")


@app.get("/api/runtime", response_model=RuntimeInfoResponse)
async def runtime_info() -> RuntimeInfoResponse:
    """Expose loaded capability metadata for CLI/runtime synchronization."""
    registry = get_state().capability_registry
    if registry is None:
        return RuntimeInfoResponse(working_dir=str(Path.cwd()))
    return registry.to_runtime_info(working_dir=Path.cwd())


@app.get("/api/tools", response_model=ToolsResponse)
async def list_tools() -> ToolsResponse:
    """List all available tools grouped by source capability."""
    registry = get_state().capability_registry
    if registry is None:
        return ToolsResponse()
    items: list[ToolInfo] = []
    for cap_name, capability in registry.capabilities.items():
        for tool in capability.tools:
            name = _tool_name(tool)
            desc = ""
            if hasattr(tool, "description"):
                desc = tool.description or ""
            elif hasattr(tool, "__doc__"):
                desc = (tool.__doc__ or "").split("\n")[0]
            items.append(ToolInfo(name=name or "?", description=desc, capability=cap_name))
    if registry.mcp_manager:
        for tool in registry.mcp_manager.all_tools():
            name = _tool_name(tool)
            desc = getattr(tool, "description", "") or ""
            items.append(ToolInfo(name=name or "?", description=desc, capability="mcp"))
    return ToolsResponse(tools=items)


@app.post("/api/reload", response_model=RuntimeInfoResponse)
async def reload_capabilities() -> RuntimeInfoResponse:
    """Re-discover capabilities and rebuild the registry.

    Active sessions detect the change on their next turn and recreate
    agents with the updated tool/skill set.
    """
    from dreadnode import _get_default_instance

    # Stop old MCP servers before replacing the registry
    old_registry = get_state().capability_registry
    if old_registry and old_registry.mcp_manager:
        await old_registry.mcp_manager.stop()

    instance = _get_default_instance()
    await asyncio.to_thread(_populate_registry, instance)

    # Start MCP servers for the new registry
    registry = get_state().capability_registry
    if registry:
        registry.mcp_manager = MCPLifecycleManager()
        await registry.mcp_manager.start(registry)

    if registry is None:
        return RuntimeInfoResponse(working_dir=str(Path.cwd()))
    return registry.to_runtime_info(working_dir=Path.cwd())


# =============================================================================
# Server Entry Point
# =============================================================================


def _read_capability_system_prompt(path: Path) -> str:
    """Read and normalize an optional capability-level system prompt."""
    import re

    prompt_file = path / "system-prompt.md"
    if not prompt_file.exists():
        return ""

    content = prompt_file.read_text().strip()
    frontmatter_match = re.match(r"^---\s*\n[\s\S]*?\n---\s*\n([\s\S]*)", content)
    if frontmatter_match:
        content = frontmatter_match.group(1).strip()
    return content


def _sync_workspace_if_available(instance: t.Any) -> tuple[Path | None, list[dict[str, t.Any]]]:
    """Run workspace sync if platform credentials are available.

    Returns (workspace_cache_dir, workspace_bindings).
    """
    project_id = os.environ.get("DREADNODE_PROJECT_ID", "").strip()
    if not instance.can_sync or not project_id:
        return None, []

    from dreadnode.capabilities.sync import WorkspaceSyncClient

    try:
        cache_dir = instance.storage.workspace_capabilities_path
        # asyncio.run() is safe here because _populate_registry runs inside
        # asyncio.to_thread(), which means we're in a thread pool worker with
        # no running event loop. asyncio.run() creates a fresh loop.
        client = WorkspaceSyncClient(
            api=instance.api,
            org=str(instance.organization),
            workspace=str(instance.workspace),
            project_id=project_id,
            cache_dir=cache_dir,
        )
        result = asyncio.run(client.sync())
        if result.synced:
            logger.info("Synced workspace capabilities: {}", result.synced)
        if result.removed:
            logger.info("Removed stale workspace capabilities: {}", result.removed)
        if result.errors:
            for err in result.errors:
                logger.warning("Failed to sync '{}': {}", err.name, err.error)
        return cache_dir, result.bindings
    except Exception:
        logger.warning("Workspace capability sync failed — using local only", exc_info=True)
        return None, []


def _populate_registry(instance: t.Any) -> None:
    """Discover capabilities and install them into app state."""
    from dreadnode.capabilities import Capability
    from dreadnode.capabilities.capability import read_local_capability_records

    state = get_state()
    registry = CapabilityRegistry()

    # 1. Sync workspace capabilities if platform credentials available
    workspace_dir, workspace_bindings = _sync_workspace_if_available(instance)
    registry.workspace_bindings = workspace_bindings

    # 2. Determine host type: sandbox if DREADNODE_PROJECT_ID is set, local otherwise
    host = "sandbox" if os.environ.get("DREADNODE_PROJECT_ID", "").strip() else "local"

    # 3. Discover with host-exclusive source (CAP-LOAD-014)
    try:
        result = Capability.discover(
            cwd=Path.cwd(),
            storage=instance.storage,
            workspace_dir=workspace_dir,
            host=host,
        )
        for cap in result.capabilities.values():
            registry.capabilities[cap.name] = cap
        registry.disabled_local = result.disabled
        registry.load_failures = result.failures
        registry.local_capability_records = read_local_capability_records(
            instance.storage.local_capability_state_path
        )
    except Exception:
        logger.exception("Failed to discover capabilities")

    if registry.capabilities:
        registry.default_capability_name = next(iter(registry.capabilities))

    state.capability_registry = registry
    logger.info("Loaded {} capabilities", len(registry.capabilities))


def initialize_app(
    *,
    server: str | None = None,
    api_key: str | None = None,
    organization: str | None = None,
    workspace: str | None = None,
    project: str | None = None,
) -> None:
    """Initialize app state: configure a Dreadnode instance and discover capabilities.

    Creates a fresh ``Dreadnode`` instance (bypassing the singleton's idempotent
    guard) and replaces ``DEFAULT_INSTANCE`` so that server-side code using
    ``_get_default_instance()`` picks up the new credentials.

    Must be called via ``asyncio.to_thread()`` from async contexts because
    ``Capability.discover()`` internally calls ``asyncio.run()``.
    """
    import dreadnode.app.main as main_mod

    instance = main_mod.Dreadnode()
    instance.configure(
        server=server,
        api_key=api_key,
        organization=organization,
        workspace=workspace,
        project=project,
    )
    main_mod.DEFAULT_INSTANCE = instance

    _populate_registry(instance)


def reset_app_state() -> None:
    """Clear all server state: close sessions and reset the capability registry.

    Called before re-running ``initialize_app()`` on restart.
    """
    if not hasattr(app.state, "server"):
        return

    state: ServerState = app.state.server

    # Stop MCP servers if running (best-effort, sync context)
    if state.capability_registry and state.capability_registry.mcp_manager:
        manager = state.capability_registry.mcp_manager
        try:
            asyncio.get_running_loop()
            # In async context — schedule and let it complete
            asyncio.ensure_future(manager.stop())
        except RuntimeError:
            # No running loop — safe to run synchronously
            asyncio.run(manager.stop())

    for session in state.list_sessions():
        session.close()

    app.state.server = ServerState()


def run_server(
    instance: t.Any | None = None,
    *,
    host: str | None = None,
    port: int | None = None,
    server: str | None = None,
    api_key: str | None = None,
    organization: str | None = None,
    workspace: str | None = None,
    project: str | None = None,
) -> None:
    """Run the FastAPI server with uvicorn."""
    from dreadnode import _get_default_instance

    if instance is None:
        instance = _get_default_instance()
    instance.configure(
        server=server,
        api_key=api_key,
        organization=organization,
        workspace=workspace,
        project=project,
    )

    _populate_registry(instance)

    resolved_host = host or os.environ.get("DREADNODE_SERVER_HOST", "127.0.0.1")
    resolved_port = port or int(os.environ.get("DREADNODE_SERVER_PORT", "8787"))
    logger.info(f"Starting server at http://{resolved_host}:{resolved_port}")

    app.add_middleware(
        CORSMiddleware,
        allow_origin_regex=r".*",
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    uvicorn.run(app, host=resolved_host, port=resolved_port)
