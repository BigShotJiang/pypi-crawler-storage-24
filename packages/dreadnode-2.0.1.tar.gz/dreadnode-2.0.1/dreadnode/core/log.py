"""
Logging utilities using loguru with rich formatting.

Usage:
    from log import logger, console, configure_logging

    configure_logging("debug")  # optional, defaults to "info"

    logger.info("Hello")
    logger.success("Done!")
"""

import logging
import os
import pathlib
import threading
import typing as t
from collections import deque
from dataclasses import dataclass
from datetime import datetime

from loguru import logger
from rich.console import Console
from rich.prompt import Confirm
from rich.theme import Theme

__all__ = [
    "LogBuffer",
    "LogEntry",
    "LogLevel",
    "configure_logging",
    "confirm",
    "console",
    "enable_tui_capture",
    "install_stdlib_intercept",
    "log_buffer",
    "logger",
]

LogLevel = t.Literal["trace", "debug", "info", "success", "warning", "error", "critical"]

console = Console(
    theme=Theme(
        {
            "logging.level.success": "green",
            "logging.level.trace": "dim blue",
        }
    )
)

# In vscode jupyter, disable rich's jupyter detection to avoid issues with styling
if "VSCODE_PID" in os.environ:
    console.is_jupyter = False


def _rich_sink(message: str) -> None:
    """Sink that writes to rich console."""
    console.print(message, end="")


# ======================================================================
# TUI log capture
# ======================================================================


@dataclass(slots=True)
class LogEntry:
    """A single captured log entry."""

    timestamp: datetime
    level: str
    source: str
    message: str
    level_no: int


class LogBuffer:
    """Thread-safe ring buffer for captured log entries."""

    def __init__(self, maxlen: int = 5000) -> None:
        self._entries: deque[LogEntry] = deque(maxlen=maxlen)
        self._lock = threading.Lock()
        self._listeners: list[t.Callable[[LogEntry], None]] = []

    def push(self, entry: LogEntry) -> None:
        with self._lock:
            self._entries.append(entry)
            listeners = list(self._listeners)
        for listener in listeners:
            listener(entry)

    def snapshot(self) -> list[LogEntry]:
        with self._lock:
            return list(self._entries)

    def clear(self) -> None:
        with self._lock:
            self._entries.clear()

    def add_listener(self, fn: t.Callable[[LogEntry], None]) -> None:
        with self._lock:
            self._listeners.append(fn)

    def remove_listener(self, fn: t.Callable[[LogEntry], None]) -> None:
        with self._lock:
            self._listeners = [f for f in self._listeners if f != fn]

    def __len__(self) -> int:
        with self._lock:
            return len(self._entries)


log_buffer = LogBuffer()

# Track TUI capture state so configure_logging() can re-add the sink
_tui_capture_level: str | None = None
_tui_capture_sink_id: int | None = None


def _tui_sink(message: str) -> None:
    """Loguru sink that captures entries into the TUI log buffer."""
    record = message.record
    msg = record["message"]
    # Append exception traceback if present
    exc = record.get("exception")
    if exc and exc.traceback:
        import traceback as tb

        msg += "\n" + "".join(tb.format_exception(type(exc.value), exc.value, exc.traceback))
    entry = LogEntry(
        timestamp=record["time"].replace(tzinfo=None),
        level=record["level"].name,
        source=record["name"] or "loguru",
        message=msg,
        level_no=record["level"].no,
    )
    log_buffer.push(entry)


def enable_tui_capture(level: str = "debug") -> int:
    """Add the TUI buffer sink to loguru. Returns the sink ID for removal."""
    global _tui_capture_level, _tui_capture_sink_id
    _tui_capture_level = level
    _tui_capture_sink_id = logger.add(
        _tui_sink,
        format="{message}",
        level=level.upper(),
        colorize=False,
        backtrace=False,
        diagnose=False,
    )
    return _tui_capture_sink_id


class _InterceptHandler(logging.Handler):
    """Route stdlib logging into loguru so it appears in the TUI console."""

    def emit(self, record: logging.LogRecord) -> None:
        try:
            level = logger.level(record.levelname).name
        except ValueError:
            level = str(record.levelno)

        frame, depth = logging.currentframe(), 2
        while frame and frame.f_code.co_filename == logging.__file__:
            frame = frame.f_back
            depth += 1

        logger.opt(depth=depth, exception=record.exc_info).log(level, record.getMessage())


def install_stdlib_intercept() -> None:
    """Install handler that routes stdlib logging into loguru."""
    logging.basicConfig(handlers=[_InterceptHandler()], level=0, force=True)


# ======================================================================
# Configuration
# ======================================================================


def configure_logging(
    level: LogLevel | None = None,
    log_file: pathlib.Path | None = None,
    log_file_level: LogLevel = "debug",
    *,
    verbose: bool = False,
) -> None:
    """
    Configure loguru with rich console output.

    Args:
        level: Console log level. If omitted, defaults to the
            ``DREADNODE_LOG_LEVEL`` env var or ``info``.
        log_file: Optional file path for logging.
        log_file_level: Log level for file output.
        verbose: Enable richer tracebacks for local debugging.
    """
    resolved_level = (level if level is not None else os.environ.get("DREADNODE_LOG_LEVEL", "info")).lower()
    if resolved_level not in t.get_args(LogLevel):
        resolved_level = "info"

    global _tui_capture_sink_id

    logger.remove()
    logger.enable("dreadnode")

    # Rich-formatted console output
    logger.add(
        _rich_sink,
        format="<level>{level.icon}</level> {message}",
        level=resolved_level.upper(),
        colorize=True,
        backtrace=verbose,
        diagnose=False,
    )

    # Re-add TUI capture sink if it was previously enabled
    if _tui_capture_level is not None:
        _tui_capture_sink_id = logger.add(
            _tui_sink,
            format="{message}",
            level=_tui_capture_level.upper(),
            colorize=False,
            backtrace=False,
            diagnose=False,
        )

    if log_file is not None:
        logger.add(log_file, level=log_file_level.upper())
        logger.info(f"Logging to {log_file}")


def confirm(action: str) -> bool:
    """Prompt user for confirmation."""
    return Confirm.ask(
        f"[bold magenta]↔[/] {action}",
        default=False,
        case_sensitive=False,
        console=console,
    )


# Configure with defaults on import
configure_logging()
