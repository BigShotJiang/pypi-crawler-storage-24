"""Dreadnode entry point."""

def run() -> None:
    """Run the Dreadnode Textual client or local runtime server."""
    from dreadnode.app.tui.app import main

    main()


if __name__ == "__main__":
    run()
