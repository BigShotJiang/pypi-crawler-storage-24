import typing as t
from pathlib import Path

from dreadnode.core.environment import Environment
from dreadnode.environments.containers import ContainerConfig, container

if t.TYPE_CHECKING:
    from dreadnode.environments.containers import (
        ContainerContext,
        HealthCheckConfig,
    )


class DockerEnvironment(Environment):
    """Docker container execution environment."""

    def __init__(
        self,
        image: str,
        *,
        name: str | None = None,
        hostname: str | None = None,
        ports: list[int] | None = None,
        env: dict[str, str] | None = None,
        volumes: dict[str | Path, str] | None = None,
        command: list[str] | None = None,
        memory_limit: str | None = None,
        network_name: str | None = None,
        network_isolation: bool = False,
        health_check: "HealthCheckConfig | None" = None,
        keep_alive: bool = True,
    ):
        self.image = image
        effective_command = command
        if keep_alive and command is None:
            effective_command = ["sh", "-c", "sleep infinity"]

        self.config = ContainerConfig(
            name=name,
            hostname=hostname,
            ports=ports or [],
            env=env or {},
            volumes=volumes or {},
            command=effective_command,
            memory_limit=memory_limit,
            network_name=network_name,
            network_isolation=network_isolation,
            health_check=health_check,
        )

        self._context: ContainerContext | None = None
        self._cm: t.Any = None

    @property
    def container(self) -> "ContainerContext":
        """Access the running container context."""
        if self._context is None:
            raise RuntimeError("Environment not setup - call setup() first")
        return self._context

    async def setup(self) -> dict[str, t.Any]:
        self._cm = container(self.image, self.config)
        self._context = await self._cm.__aenter__()

        return {
            "container_id": self._context.id,
            "hostname": self._context.hostname,
            "ip_address": self._context.ip_address,
            "ports": self._context.ports,
        }

    async def teardown(self) -> None:
        if self._cm:
            await self._cm.__aexit__(None, None, None)
        self._context = None
        self._cm = None

    async def get_state(self) -> dict[str, t.Any]:
        if self._context is None:
            return {"status": "not_running"}
        info = await self._context.container.show()
        return {
            "status": info["State"]["Status"],
            "container_id": self._context.id,
        }
