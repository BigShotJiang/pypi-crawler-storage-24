"""Strikes CTF platform environment integration."""

import contextlib
import typing as t
from dataclasses import dataclass, field

import httpx

from dreadnode.core.environment import Environment
from dreadnode.core.tool import tool


@dataclass
class StrikesConfig:
    """Configuration for Strikes environment."""

    api_url: str = "http://localhost:8080"
    api_key: str | None = None
    timeout: int = 600

    # Sandbox mode (generic isolated execution)
    sandbox_mode: bool = True
    sandbox_image: str = "ubuntu:22.04"
    sandbox_memory: str = "512Mi"
    sandbox_cpu: str = "500m"
    sandbox_network: bool = False
    sandbox_env: dict[str, str] = field(default_factory=dict)


class StrikesClient:
    """HTTP client for Strikes API."""

    def __init__(self, config: StrikesConfig) -> None:
        self.config = config
        headers = {}
        if config.api_key:
            headers["Authorization"] = f"Bearer {config.api_key}"

        self._client = httpx.AsyncClient(
            base_url=config.api_url,
            headers=headers,
            timeout=httpx.Timeout(config.timeout),
        )

    async def close(self) -> None:
        await self._client.aclose()

    async def create_sandbox(
        self,
        image: str,
        memory: str = "512Mi",
        cpu: str = "500m",
        network_enabled: bool = False,
        env: dict[str, str] | None = None,
        timeout: int = 3600,
    ) -> dict[str, t.Any]:
        """POST /sandbox - Create isolated sandbox."""
        response = await self._client.post(
            "/sandbox",
            json={
                "image": image,
                "resources": {
                    "memory": memory,
                    "cpu": cpu,
                    "network_enabled": network_enabled,
                },
                "env": env or {},
                "timeout": timeout,
            },
        )
        response.raise_for_status()
        return response.json()

    async def get_sandbox(self, sandbox_id: str) -> dict[str, t.Any]:
        """GET /sandbox/{id} - Get sandbox status."""
        response = await self._client.get(f"/sandbox/{sandbox_id}")
        response.raise_for_status()
        return response.json()

    async def exec_in_sandbox(
        self,
        sandbox_id: str,
        command: str,
        timeout: int = 30,
    ) -> dict[str, t.Any]:
        """POST /sandbox/{id}/exec - Execute command in sandbox."""
        response = await self._client.post(
            f"/sandbox/{sandbox_id}/exec",
            json={"command": command, "timeout": timeout},
        )
        response.raise_for_status()
        return response.json()

    async def delete_sandbox(self, sandbox_id: str) -> None:
        """DELETE /sandbox/{id} - Teardown sandbox."""
        response = await self._client.delete(f"/sandbox/{sandbox_id}")
        response.raise_for_status()

    async def list_sandboxes(self) -> list[dict[str, t.Any]]:
        """GET /sandbox - List sandboxes."""
        response = await self._client.get("/sandbox")
        response.raise_for_status()
        return response.json()


class StrikesEnvironment(Environment):
    """
    Environment for interacting with Strikes platform.

    Provides isolated sandbox execution via the Strikes API.

    Example:
        ```python
        from dreadnode.environments.strikes import StrikesEnvironment, StrikesConfig

        config = StrikesConfig(
            api_url="http://localhost:8080",
            api_key="sk-1234",
            sandbox_image="python:3.11",
        )

        env = StrikesEnvironment(config)

        async with env:
            tools = env.tools()
            result = await tools[0]("echo hello")  # run_command
            print(result)
        ```
    """

    def __init__(self, config: StrikesConfig | None = None) -> None:
        self.config = config or StrikesConfig()
        self._client: StrikesClient | None = None
        self._sandbox_id: str | None = None
        self._state: dict[str, t.Any] = {}

    async def setup(self) -> dict[str, t.Any]:
        """Initialize the Strikes environment."""
        self._client = StrikesClient(self.config)

        result = await self._client.create_sandbox(
            image=self.config.sandbox_image,
            memory=self.config.sandbox_memory,
            cpu=self.config.sandbox_cpu,
            network_enabled=self.config.sandbox_network,
            env=self.config.sandbox_env,
            timeout=self.config.timeout,
        )

        self._sandbox_id = result["id"]
        self._state = {
            "sandbox_id": self._sandbox_id,
            "status": result["status"],
            "image": result["image"],
            "ip_address": result.get("ip_address"),
        }

        return self._state

    async def teardown(self) -> None:
        """Cleanup Strikes resources."""
        if self._client and self._sandbox_id:
            with contextlib.suppress(Exception):
                await self._client.delete_sandbox(self._sandbox_id)
        if self._client:
            await self._client.close()
            self._client = None
        self._sandbox_id = None

    async def reset(self) -> dict[str, t.Any]:
        """Reset environment to initial state."""
        await self.teardown()
        return await self.setup()

    async def get_state(self) -> dict[str, t.Any]:
        """Return current environment state."""
        if self._client and self._sandbox_id:
            try:
                result = await self._client.get_sandbox(self._sandbox_id)
                self._state["status"] = result["status"]
            except Exception:
                pass
        return self._state.copy()

    def tools(self) -> list[t.Callable[..., t.Any]]:
        """Return tools available in this environment."""
        env = self

        @tool
        async def run_command(command: str, timeout: int = 30) -> str:
            """
            Execute a shell command in the sandbox environment.

            Args:
                command: Shell command to execute
                timeout: Command timeout in seconds (default 30)

            Returns:
                Command output as string. Includes exit code if non-zero.
            """
            if not env._client or not env._sandbox_id:
                raise RuntimeError("Environment not set up")

            result = await env._client.exec_in_sandbox(env._sandbox_id, command, timeout)

            output = result.get("output", "")
            exit_code = result.get("exit_code", 0)

            if exit_code != 0:
                return f"[Exit code: {exit_code}]\n{output}"
            return output or "(no output)"

        @tool
        async def read_file(path: str) -> str:
            """
            Read contents of a file in the sandbox.

            Args:
                path: Absolute path to file

            Returns:
                File contents as string
            """
            if not env._client or not env._sandbox_id:
                raise RuntimeError("Environment not set up")

            result = await env._client.exec_in_sandbox(env._sandbox_id, f"cat {path}", timeout=30)

            if result.get("exit_code", 0) != 0:
                raise FileNotFoundError(f"Cannot read {path}: {result.get('output', '')}")

            return result.get("output", "")

        @tool
        async def write_file(path: str, content: str) -> str:
            """
            Write content to a file in the sandbox.

            Args:
                path: Absolute path to file
                content: Content to write

            Returns:
                Success message
            """
            if not env._client or not env._sandbox_id:
                raise RuntimeError("Environment not set up")

            escaped = content.replace("'", "'\"'\"'")
            cmd = f"mkdir -p $(dirname {path}) && printf '%s' '{escaped}' > {path}"

            result = await env._client.exec_in_sandbox(env._sandbox_id, cmd, timeout=30)

            if result.get("exit_code", 0) != 0:
                raise OSError(f"Failed to write {path}: {result.get('output', '')}")

            return f"Wrote {len(content)} bytes to {path}"

        @tool
        async def list_files(path: str = ".", recursive: bool = False) -> str:
            """
            List files in a directory.

            Args:
                path: Directory path (default: current directory)
                recursive: Whether to list recursively

            Returns:
                Directory listing
            """
            if not env._client or not env._sandbox_id:
                raise RuntimeError("Environment not set up")

            flag = "-laR" if recursive else "-la"
            result = await env._client.exec_in_sandbox(
                env._sandbox_id, f"ls {flag} {path}", timeout=30
            )

            return result.get("output", "") or "(empty)"

        return [run_command, read_file, write_file, list_files]
