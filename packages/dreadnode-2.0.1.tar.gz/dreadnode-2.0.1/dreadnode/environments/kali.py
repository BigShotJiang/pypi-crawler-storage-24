"""Kali Linux execution tools implemented as a Toolset."""

from __future__ import annotations

import asyncio
import shlex
import typing as t

from loguru import logger
from web.tools import tool_counter
from web.tools.code_formatter import format_json_data

import dreadnode as dn
from dreadnode import Config
from dreadnode.agents.tools import Toolset, tool_method


class KaliTools(Toolset):
    """
    Toolset for executing bash commands inside the Kali container.
    """

    timeout: int = Config(default=60)
    """Default timeout for commands in seconds."""
    max_timeout: int = Config(default=600)
    """Maximum allowed timeout (hard cap) in seconds."""
    max_output_chars: int = Config(default=50_000)
    """Maximum characters returned from command output."""

    @tool_method(name="execute_bash", catch=True, truncate=50000)
    async def execute_bash(
        self,
        command: t.Annotated[str, "Bash command to execute"],
        timeout: t.Annotated[
            int | None, "Override timeout in seconds (capped at max_timeout, default 600s)"
        ] = None,
        max_output_chars: t.Annotated[int | None, "Override output truncation threshold"] = None,
    ) -> str:
        """Execute a bash command in the Kali container."""
        progress = tool_counter.increment()
        requested_timeout = timeout if timeout is not None else self.timeout
        # Enforce maximum timeout cap
        cmd_timeout = min(requested_timeout, self.max_timeout)
        if requested_timeout > self.max_timeout:
            logger.warning(
                f"[bash] Requested timeout {requested_timeout}s exceeds max {self.max_timeout}s, capping at {self.max_timeout}s"
            )
        output_limit = max_output_chars if max_output_chars is not None else self.max_output_chars

        wrapped_command = f"timeout --kill-after=10s {cmd_timeout}s bash -c {shlex.quote(command)}"

        logger.info(
            f"\033[96m[Tool {progress}] [bash] executing ({len(command)} chars, timeout={cmd_timeout}s):\033[0m\n\033[94m{command}\033[0m"
        )

        try:
            process = await asyncio.create_subprocess_shell(
                wrapped_command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
        except Exception as exc:  # pragma: no cover - create_subprocess failure is rare
            logger.error(f"[bash] Failed to start command: {exc}")
            return f"Error: Failed to start command: {exc}"

        stdout, stderr = await process.communicate()

        output_parts: list[str] = []
        if stdout:
            output_parts.append(stdout.decode(errors="replace"))
        if stderr:
            if output_parts:
                output_parts.append("\n--- STDERR ---\n")
            output_parts.append(stderr.decode(errors="replace"))

        output = "".join(output_parts)
        if not output:
            output = f"(command completed with exit code {process.returncode}, no output)"

        # Check if command was terminated by timeout utility
        # Exit code 124 = timeout (SIGTERM), 137 = timeout + SIGKILL
        if process.returncode == 124:
            # Discard partial output on timeout - it's incomplete and useless
            output = f"[TIMEOUT] Command exceeded {cmd_timeout}s timeout and was terminated.\n"
            if cmd_timeout < self.max_timeout:
                output += f"TIP: Retry with execute_bash(command, timeout={self.max_timeout}) to extend timeout up to {self.max_timeout}s."
            logger.error(f"[bash] Command timed out after {cmd_timeout}s")
        elif process.returncode == 137:
            # Discard partial output on timeout - it's incomplete and useless
            output = f"[TIMEOUT] Command exceeded {cmd_timeout}s timeout and was force-killed.\n"
            if cmd_timeout < self.max_timeout:
                output += f"TIP: Retry with execute_bash(command, timeout={self.max_timeout}) to extend timeout up to {self.max_timeout}s."
            logger.error(f"[bash] Command force-killed after {cmd_timeout}s + 10s grace period")

        if len(output) > output_limit:
            truncated_length = len(output)
            output = (
                output[:output_limit]
                + f"\n\n... [OUTPUT TRUNCATED: {truncated_length} chars total, showing first {output_limit}]"
            )
            logger.warning(
                f"[bash] Output truncated from {truncated_length} to {output_limit} chars"
            )

        # Console logging with colors (matching Python tool exactly)
        logger.info(
            f"\033[92m[Tool {progress}] [bash] output ({len(output)} chars):\033[0m\n\033[95m{output}\033[0m"
        )

        # Format output data with syntax-highlighted code
        output_data = {
            "command": dn.Code(command, language="bash"),
            "returncode": process.returncode,
        }
        # Add truncated output
        output_data.update(format_json_data({"output": output[:5000]}, key="output"))

        dn.log_output(
            "bash_execution",
            output_data,
            label=f"Bash Execution: {command[:50]}...",
        )

        logger.info(f"[Tool {progress}] [bash] completed with exit code {process.returncode}")
        return output
