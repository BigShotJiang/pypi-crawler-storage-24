"""Kubernetes-based sandbox environment for secure agent execution."""

import contextlib
import json
import typing as t
import uuid
from dataclasses import dataclass
from enum import Enum

from dreadnode.core.environment import Environment

# Optional kubernetes import
try:
    from kubernetes_asyncio import client as kclient
    from kubernetes_asyncio import config as kconfig
    from kubernetes_asyncio.client.api_client import ApiClient
    from kubernetes_asyncio.stream.ws_client import (
        ERROR_CHANNEL,
        STDERR_CHANNEL,
        STDOUT_CHANNEL,
        WsApiClient,
    )

    K8S_AVAILABLE = True
except ImportError:
    K8S_AVAILABLE = False
    kclient = None  # type: ignore
    kconfig = None  # type: ignore
    ApiClient = None  # type: ignore
    WsApiClient = None  # type: ignore
    ERROR_CHANNEL = 3
    STDERR_CHANNEL = 2
    STDOUT_CHANNEL = 1


class SandboxStatus(str, Enum):
    """Status of a sandbox instance."""

    PENDING = "pending"
    CREATING = "creating"
    RUNNING = "running"
    STOPPED = "stopped"
    FAILED = "failed"


@dataclass
class SandboxResources:
    """Resource limits for sandbox."""

    memory: str = "512Mi"
    cpu: str = "500m"
    network_enabled: bool = False


@dataclass
class ExecResult:
    """Result of command execution."""

    output: str = ""
    exit_code: int = 0
    timed_out: bool = False


class KubernetesEnvironment(Environment):
    """
    Kubernetes-based sandbox environment for secure agent execution.

    Uses native kubernetes-asyncio for:
    - Per-sandbox namespace isolation
    - Network policies for network control
    - Resource limits via pod spec

    Args:
        image: Container image to use
        namespace_prefix: Prefix for sandbox namespaces
        resources: Resource limits (memory, cpu, network)
        env: Environment variables for the container
        context: Kubernetes context to use (defaults to current)
        incluster: Whether running inside a Kubernetes cluster

    Example:
        ```python
        from dreadnode.environments.kubernetes import KubernetesEnvironment

        env = KubernetesEnvironment(
            image="python:3.11",
            resources=SandboxResources(memory="1Gi", cpu="1000m"),
        )

        agent = Agent(name="secure-executor", tools=[run_command])
        result = await env.run(agent.run("Execute the Python script"))
        ```
    """

    def __init__(
        self,
        image: str = "python:3.11-slim",
        *,
        namespace_prefix: str = "sandbox",
        resources: SandboxResources | None = None,
        env: dict[str, str] | None = None,
        context: str | None = None,
        incluster: bool = False,
    ):
        if not K8S_AVAILABLE:
            raise ImportError(
                "kubernetes-asyncio is required for KubernetesEnvironment. "
                "Install it with: pip install kubernetes-asyncio"
            )

        self.image = image
        self.namespace_prefix = namespace_prefix
        self.resources = resources or SandboxResources()
        self.env = env or {}
        self.context = context
        self.incluster = incluster

        self._sandbox_id: str | None = None
        self._namespace: str | None = None
        self._api_client: t.Any = None
        self._v1: t.Any = None
        self._v1_ws: t.Any = None
        self._networking_v1: t.Any = None

    async def _ensure_clients(self) -> None:
        """Initialize Kubernetes API clients."""
        if self._v1 is not None:
            return

        config = kclient.Configuration()
        if self.incluster:
            kconfig.load_incluster_config(client_configuration=config)
        else:
            await kconfig.load_kube_config(
                client_configuration=config,
                context=self.context,
            )

        self._api_client = ApiClient(config)
        self._v1 = kclient.CoreV1Api(api_client=self._api_client)
        self._v1_ws = kclient.CoreV1Api(api_client=WsApiClient())
        self._networking_v1 = kclient.NetworkingV1Api(api_client=self._api_client)

    async def setup(self) -> dict[str, t.Any]:
        """Create the Kubernetes sandbox."""
        await self._ensure_clients()

        self._sandbox_id = uuid.uuid4().hex[:12]
        self._namespace = f"{self.namespace_prefix}-{self._sandbox_id}"

        # Create namespace
        ns_labels = {"sandbox.dreadnode.io/id": self._sandbox_id}
        await self._v1.create_namespace(
            kclient.V1Namespace(
                metadata=kclient.V1ObjectMeta(name=self._namespace, labels=ns_labels)
            )
        )

        # Create network policy if network is disabled
        if not self.resources.network_enabled:
            network_policy = kclient.V1NetworkPolicy(
                metadata=kclient.V1ObjectMeta(
                    name="deny-all",
                    namespace=self._namespace,
                ),
                spec=kclient.V1NetworkPolicySpec(
                    pod_selector=kclient.V1LabelSelector(),
                    policy_types=["Ingress", "Egress"],
                    ingress=[],
                    egress=[],
                ),
            )
            await self._networking_v1.create_namespaced_network_policy(
                namespace=self._namespace, body=network_policy
            )

        # Create pod
        resource_requirements = kclient.V1ResourceRequirements(
            limits={"memory": self.resources.memory, "cpu": self.resources.cpu},
            requests={"memory": self.resources.memory, "cpu": self.resources.cpu},
        )

        pod = kclient.V1Pod(
            metadata=kclient.V1ObjectMeta(
                name="sandbox",
                namespace=self._namespace,
                labels={"app": "sandbox", "sandbox-id": self._sandbox_id},
            ),
            spec=kclient.V1PodSpec(
                containers=[
                    kclient.V1Container(
                        name="sandbox",
                        image=self.image,
                        command=["sleep", "infinity"],
                        env=[kclient.V1EnvVar(name=k, value=v) for k, v in self.env.items()],
                        resources=resource_requirements,
                    )
                ],
                restart_policy="Never",
            ),
        )

        await self._v1.create_namespaced_pod(namespace=self._namespace, body=pod)

        # Wait for pod to be ready
        await self._wait_ready(timeout=120)

        return {
            "sandbox_id": self._sandbox_id,
            "namespace": self._namespace,
            "image": self.image,
        }

    async def _wait_ready(self, timeout: int = 60) -> None:
        """Wait for the sandbox pod to be running."""
        import asyncio

        elapsed = 0.0
        poll_interval = 1.0

        while elapsed < timeout:
            pod = await self._v1.read_namespaced_pod(name="sandbox", namespace=self._namespace)
            phase = pod.status.phase

            if phase == "Running":
                return
            if phase == "Failed":
                raise RuntimeError("Sandbox pod failed to start")

            await asyncio.sleep(poll_interval)
            elapsed += poll_interval

        raise TimeoutError(f"Sandbox not ready after {timeout}s")

    async def teardown(self) -> None:
        """Delete the Kubernetes sandbox."""
        if self._v1 and self._namespace:
            with contextlib.suppress(Exception):
                await self._v1.delete_namespace(name=self._namespace)

        if self._api_client:
            await self._api_client.close()
            self._api_client = None
            self._v1 = None
            self._v1_ws = None
            self._networking_v1 = None

        self._sandbox_id = None
        self._namespace = None

    async def reset(self) -> dict[str, t.Any]:
        """Reset by recreating the sandbox."""
        await self.teardown()
        return await self.setup()

    async def get_state(self) -> dict[str, t.Any]:
        """Get current sandbox state."""
        if not self._v1 or not self._namespace:
            return {"status": "not_running"}

        try:
            pod = await self._v1.read_namespaced_pod(name="sandbox", namespace=self._namespace)
            phase = pod.status.phase
            status_map = {
                "Pending": SandboxStatus.CREATING,
                "Running": SandboxStatus.RUNNING,
                "Succeeded": SandboxStatus.STOPPED,
                "Failed": SandboxStatus.FAILED,
            }
            status = status_map.get(phase, SandboxStatus.PENDING)

            return {
                "status": status.value,
                "sandbox_id": self._sandbox_id,
                "namespace": self._namespace,
                "pod_ip": pod.status.pod_ip,
            }
        except Exception:
            return {"status": "error"}

    async def exec(
        self,
        command: str,
        timeout: int = 30,
        shell: str = "/bin/sh",
    ) -> ExecResult:
        """Execute a command in the sandbox."""
        if not self._v1_ws or not self._namespace:
            raise RuntimeError("Environment not setup - call setup() first")

        websocket = await self._v1_ws.connect_get_namespaced_pod_exec(
            "sandbox",
            self._namespace,
            command=["timeout", str(timeout), shell, "-c", command],
            stderr=True,
            stdin=False,
            stdout=True,
            tty=False,
            _preload_content=False,
        )

        output_parts: list[str] = []
        exit_code = 0

        async for msg in websocket:
            data = msg.data.decode() if isinstance(msg.data, bytes) else str(msg.data)
            if len(data) <= 1:
                continue

            channel = ord(data[0])
            data = data[1:]
            if not data:
                continue

            if channel in [STDOUT_CHANNEL, STDERR_CHANNEL]:
                output_parts.append(data)
            elif channel == ERROR_CHANNEL:
                error_data = json.loads(data)
                causes = error_data.get("details", {}).get("causes", [])
                exit_code_cause = next((c for c in causes if c.get("reason") == "ExitCode"), None)
                if exit_code_cause:
                    exit_code = int(exit_code_cause.get("message", 0))

        return ExecResult(
            output="".join(output_parts),
            exit_code=exit_code,
            timed_out=exit_code == 124,
        )

    def tools(self) -> list:
        """Create tools for the Kubernetes sandbox."""
        from dreadnode import tool

        env = self

        @tool
        async def run_command(command: str, timeout: int = 60) -> str:
            """
            Execute a shell command in the Kubernetes sandbox.
            The sandbox provides namespace isolation for security.
            """
            result = await env.exec(command, timeout=timeout)

            output = result.output or ""
            if result.exit_code != 0:
                output = f"Exit code {result.exit_code}\n{output}"
            if result.timed_out:
                output = f"Command timed out after {timeout}s\n{output}"

            return output or "(no output)"

        @tool
        async def execute_python(code: str) -> str:
            """Execute Python code in the sandbox."""
            import uuid as uuid_mod

            filename = f"/tmp/code_{uuid_mod.uuid4().hex[:8]}.py"

            # Write code to file
            escaped = code.replace("'", "'\"'\"'")
            write_result = await env.exec(f"printf '%s' '{escaped}' > {filename}")
            if write_result.exit_code != 0:
                return f"Failed to write code: {write_result.output}"

            # Execute
            result = await env.exec(f"python3 {filename}")

            output = result.output or ""
            if result.exit_code != 0:
                output = f"Error (exit {result.exit_code}):\n{output}"

            return output or "(no output)"

        @tool
        async def read_file(path: str) -> str:
            """Read contents of a file in the sandbox."""
            result = await env.exec(f"cat {path}")
            if result.exit_code != 0:
                raise FileNotFoundError(f"Cannot read {path}: {result.output}")
            return result.output

        @tool
        async def write_file(path: str, content: str) -> str:
            """Write content to a file in the sandbox."""
            escaped = content.replace("'", "'\"'\"'")
            result = await env.exec(
                f"mkdir -p $(dirname {path}) && printf '%s' '{escaped}' > {path}"
            )
            if result.exit_code != 0:
                raise OSError(f"Failed to write {path}: {result.output}")
            return f"Wrote {len(content)} bytes to {path}"

        return [run_command, execute_python, read_file, write_file]
