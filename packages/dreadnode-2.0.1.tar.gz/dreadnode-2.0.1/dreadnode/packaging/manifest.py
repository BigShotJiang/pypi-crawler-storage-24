from __future__ import annotations

import typing as t

from pydantic import BaseModel, Field


class BaseManifest(BaseModel):
    """Base manifest with artifact tracking."""

    artifacts: dict[str, str] = Field(default_factory=dict)  # path -> oid
    artifacts_hash: str | None = None


class DatasetManifest(BaseManifest):
    """Dataset-specific manifest."""

    format: str = "parquet"
    data_schema: dict[str, str] = Field(default_factory=dict)
    row_count: int | None = None
    splits: dict[str, str] | None = None  # split_name -> artifact_path


class ModelManifest(BaseManifest):
    """Model-specific manifest."""

    framework: str = "safetensors"
    task: str | None = None
    architecture: str | None = None


class EnvironmentManifest(BaseManifest):
    """Environment-specific manifest."""


# ============================================================================
# Capability Manifest
# ============================================================================


class CapabilityManifest(BaseManifest):
    """Capability manifest — raw v1 contract stored as dict.

    The registry stores the full v1 contract as JSONB.
    This class adds artifact tracking from BaseManifest.
    """

    manifest: dict[str, t.Any] = Field(default_factory=dict)


# Mapping from singular type name to manifest class
MANIFEST_TYPES: dict[str, type[BaseManifest]] = {
    "dataset": DatasetManifest,
    "model": ModelManifest,
    "environment": EnvironmentManifest,
    "capability": CapabilityManifest,
}
