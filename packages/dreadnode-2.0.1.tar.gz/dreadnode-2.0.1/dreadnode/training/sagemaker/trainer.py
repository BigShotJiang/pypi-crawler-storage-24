"""AWS SageMaker training backend implementation.

Provides training job submission and management for AWS SageMaker.
Supports both the high-level SageMaker Python SDK (estimators) and
low-level boto3 API for maximum flexibility.

Usage:
    from dreadnode.training.sagemaker import SageMakerTrainer, SageMakerTrainingConfig

    config = SageMakerTrainingConfig(
        job_name="my-training",
        model_name="meta-llama/Llama-3.1-8B-Instruct",
        resource_config=ResourceConfig(
            instance_type=InstanceType.ML_P4D_24XLARGE,
            instance_count=2,
        ),
        output_path="s3://my-bucket/output",
    )

    trainer = SageMakerTrainer(config)
    result = await trainer.train()
"""

from __future__ import annotations

import asyncio
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Protocol

from .config import (
    Framework,
    SageMakerTrainingConfig,
    TrainingJobStatus,
)


class TrainingCallback(Protocol):
    """Protocol for training job callbacks."""

    def on_job_created(self, job_name: str, job_arn: str) -> None:
        """Called when job is created."""
        ...

    def on_status_update(self, job_name: str, status: TrainingJobStatus, message: str) -> None:
        """Called on status updates."""
        ...

    def on_job_completed(self, job_name: str, status: TrainingJobStatus, result: dict) -> None:
        """Called when job completes."""
        ...


@dataclass
class TrainingMetrics:
    """Metrics from a training job."""

    train_loss: float | None = None
    """Final training loss."""

    eval_loss: float | None = None
    """Final evaluation loss."""

    train_runtime: float | None = None
    """Training runtime in seconds."""

    train_samples_per_second: float | None = None
    """Training throughput."""

    custom_metrics: dict[str, float] = field(default_factory=dict)
    """Additional custom metrics."""


@dataclass
class TrainingResult:
    """Result from a SageMaker training job."""

    job_name: str
    """Training job name."""

    job_arn: str | None = None
    """Training job ARN."""

    status: TrainingJobStatus = TrainingJobStatus.IN_PROGRESS
    """Final job status."""

    started_at: datetime | None = None
    """Job start time."""

    completed_at: datetime | None = None
    """Job completion time."""

    model_artifacts_uri: str | None = None
    """S3 URI of model artifacts."""

    output_uri: str | None = None
    """S3 URI of output data."""

    metrics: TrainingMetrics = field(default_factory=TrainingMetrics)
    """Training metrics."""

    billable_seconds: int = 0
    """Billable training seconds."""

    failure_reason: str | None = None
    """Failure reason if job failed."""

    cloudwatch_log_url: str | None = None
    """CloudWatch logs URL."""

    def elapsed_seconds(self) -> float:
        """Return job duration in seconds."""
        if self.started_at is None:
            return 0.0
        end = self.completed_at or datetime.now()
        return (end - self.started_at).total_seconds()

    @property
    def succeeded(self) -> bool:
        """Return True if job succeeded."""
        return self.status == TrainingJobStatus.COMPLETED


class SageMakerClient:
    """Low-level client for SageMaker API.

    Wraps boto3 SageMaker client for training job management.
    """

    def __init__(
        self,
        region: str | None = None,
        role_arn: str | None = None,
    ) -> None:
        """Initialize SageMaker client.

        Args:
            region: AWS region.
            role_arn: IAM role ARN for SageMaker.
        """
        self.region = region
        self.role_arn = role_arn
        self._client: Any = None
        self._session: Any = None

    def _get_client(self) -> Any:
        """Get or create boto3 SageMaker client."""
        if self._client is None:
            try:
                import boto3
            except ImportError as e:
                raise ImportError("boto3 not installed. Install with: pip install boto3") from e

            self._session = boto3.Session(region_name=self.region)
            self._client = self._session.client("sagemaker")

        return self._client

    def _get_role(self) -> str:
        """Get IAM role ARN."""
        if self.role_arn:
            return self.role_arn

        # Try to get default SageMaker execution role
        try:
            import sagemaker

            return sagemaker.get_execution_role()
        except Exception:
            pass

        raise ValueError("No IAM role provided. Set role_arn or run in SageMaker environment.")

    def create_training_job(
        self,
        config: SageMakerTrainingConfig,
    ) -> str:
        """Create a training job using boto3.

        Args:
            config: Training configuration.

        Returns:
            Training job name.
        """
        client = self._get_client()

        job_name = config.job_name or f"{config.job_name_prefix}-{uuid.uuid4().hex[:8]}"

        # Build algorithm specification
        algorithm_spec = self._build_algorithm_spec(config)

        # Build hyperparameters
        hyperparameters = config.to_hyperparameters()

        # Build input data config
        input_data_config = self._build_input_data_config(config)

        # Build output data config
        output_config = {
            "S3OutputPath": config.output_path or f"s3://sagemaker-{self.region}/output",
        }

        # Build resource config
        resource_config = config.resource_config.to_dict()

        # Build stopping condition
        stopping_condition = config.stopping_condition.to_dict()

        # Create job request
        request = {
            "TrainingJobName": job_name,
            "AlgorithmSpecification": algorithm_spec,
            "RoleArn": config.role or self._get_role(),
            "OutputDataConfig": output_config,
            "ResourceConfig": resource_config,
            "StoppingCondition": stopping_condition,
            "HyperParameters": hyperparameters,
            "EnableManagedSpotTraining": config.spot_config.use_spot,
            "EnableInterContainerTrafficEncryption": config.encrypt_inter_container_traffic,
            "EnableNetworkIsolation": config.enable_network_isolation,
        }

        if input_data_config:
            request["InputDataConfig"] = input_data_config

        if config.vpc_config:
            request["VpcConfig"] = config.vpc_config

        if config.checkpoint_s3_uri:
            request["CheckpointConfig"] = {
                "S3Uri": config.checkpoint_s3_uri,
                "LocalPath": config.checkpoint_local_path,
            }

        if config.tags:
            request["Tags"] = [{"Key": k, "Value": v} for k, v in config.tags.items()]

        if config.metric_definitions:
            request["AlgorithmSpecification"]["MetricDefinitions"] = config.metric_definitions

        # Create the training job
        client.create_training_job(**request)

        return job_name

    def _build_algorithm_spec(self, config: SageMakerTrainingConfig) -> dict:
        """Build algorithm specification."""
        # Get container image for framework
        image_uri = self._get_framework_image(config)

        spec = {
            "TrainingImage": image_uri,
            "TrainingInputMode": "File",
        }

        if config.enable_sagemaker_metrics:
            spec["EnableSageMakerMetricsTimeSeries"] = True

        return spec

    def _get_framework_image(self, config: SageMakerTrainingConfig) -> str:
        """Get Docker image URI for the framework."""
        try:
            import sagemaker
            from sagemaker import image_uris

            region = self.region or sagemaker.Session().boto_region_name

            if config.framework == Framework.HUGGINGFACE:
                return image_uris.retrieve(
                    framework="huggingface",
                    region=region,
                    version=config.transformers_version,
                    py_version=config.python_version,
                    image_scope="training",
                    instance_type=str(config.resource_config.instance_type.value)
                    if hasattr(config.resource_config.instance_type, "value")
                    else config.resource_config.instance_type,
                )

            if config.framework == Framework.PYTORCH:
                return image_uris.retrieve(
                    framework="pytorch",
                    region=region,
                    version=config.pytorch_version,
                    py_version=config.python_version,
                    image_scope="training",
                    instance_type=str(config.resource_config.instance_type.value)
                    if hasattr(config.resource_config.instance_type, "value")
                    else config.resource_config.instance_type,
                )

        except Exception:
            pass

        # Fallback to a known image
        region = self.region or "us-east-1"
        return f"763104351884.dkr.ecr.{region}.amazonaws.com/huggingface-pytorch-training:2.1.0-transformers4.36.0-gpu-py310-cu121-ubuntu20.04"

    def _build_input_data_config(self, config: SageMakerTrainingConfig) -> list[dict] | None:
        """Build input data configuration."""
        channels = []

        if config.train_data_uri:
            channels.append(
                {
                    "ChannelName": "train",
                    "DataSource": {
                        "S3DataSource": {
                            "S3DataType": "S3Prefix",
                            "S3Uri": config.train_data_uri,
                            "S3DataDistributionType": "FullyReplicated",
                        }
                    },
                }
            )

        if config.validation_data_uri:
            channels.append(
                {
                    "ChannelName": "validation",
                    "DataSource": {
                        "S3DataSource": {
                            "S3DataType": "S3Prefix",
                            "S3Uri": config.validation_data_uri,
                            "S3DataDistributionType": "FullyReplicated",
                        }
                    },
                }
            )

        return channels if channels else None

    def describe_training_job(self, job_name: str) -> dict:
        """Get training job details."""
        client = self._get_client()
        return client.describe_training_job(TrainingJobName=job_name)

    def get_job_status(self, job_name: str) -> TrainingJobStatus:
        """Get training job status."""
        response = self.describe_training_job(job_name)
        status_str = response.get("TrainingJobStatus", "Unknown")

        try:
            return TrainingJobStatus(status_str)
        except ValueError:
            return TrainingJobStatus.IN_PROGRESS

    def stop_training_job(self, job_name: str) -> None:
        """Stop a training job."""
        client = self._get_client()
        client.stop_training_job(TrainingJobName=job_name)

    def list_training_jobs(
        self,
        name_contains: str | None = None,
        status_equals: TrainingJobStatus | None = None,
        max_results: int = 100,
    ) -> list[dict]:
        """List training jobs."""
        client = self._get_client()

        kwargs: dict[str, Any] = {"MaxResults": max_results}

        if name_contains:
            kwargs["NameContains"] = name_contains

        if status_equals:
            kwargs["StatusEquals"] = status_equals.value

        response = client.list_training_jobs(**kwargs)
        return response.get("TrainingJobSummaries", [])

    def get_training_job_logs(self, job_name: str, log_group: str | None = None) -> list[str]:
        """Get CloudWatch logs for a training job."""
        try:
            import boto3

            logs_client = boto3.client("logs", region_name=self.region)

            log_group = log_group or "/aws/sagemaker/TrainingJobs"

            response = logs_client.filter_log_events(
                logGroupName=log_group,
                logStreamNamePrefix=f"{job_name}/",
                limit=1000,
            )

            return [event["message"] for event in response.get("events", [])]

        except Exception:
            return []


class SageMakerTrainer:
    """Trainer for AWS SageMaker.

    Supports both high-level SageMaker Python SDK (HuggingFace/PyTorch estimators)
    and low-level boto3 API for job submission.

    Example:
        config = SageMakerTrainingConfig(
            model_name="meta-llama/Llama-3.1-8B-Instruct",
            resource_config=ResourceConfig(
                instance_type=InstanceType.ML_P4D_24XLARGE,
                instance_count=2,
            ),
            output_path="s3://my-bucket/output",
        )

        trainer = SageMakerTrainer(config)

        # Using estimator (recommended)
        result = await trainer.train_with_estimator()

        # Or using boto3 directly
        result = await trainer.train_with_boto3()
    """

    def __init__(
        self,
        config: SageMakerTrainingConfig,
        client: SageMakerClient | None = None,
        callbacks: list[TrainingCallback] | None = None,
    ) -> None:
        """Initialize SageMaker trainer.

        Args:
            config: Training configuration.
            client: Optional SageMaker client.
            callbacks: Optional callbacks.
        """
        self.config = config
        self.client = client or SageMakerClient(
            region=config.region,
            role_arn=config.role,
        )
        self.callbacks = callbacks or []
        self._current_job_name: str | None = None

    def train_with_estimator(
        self,
        wait: bool = True,
        logs: str = "All",
    ) -> TrainingResult:
        """Train using SageMaker Python SDK estimator.

        This is the recommended approach as it handles many details
        automatically.

        Args:
            wait: Wait for training to complete.
            logs: Log level ("All", "None", or "Training").

        Returns:
            TrainingResult with job details.
        """
        try:
            from sagemaker.huggingface import HuggingFace
            from sagemaker.pytorch import PyTorch
        except ImportError as e:
            raise ImportError(
                "sagemaker SDK not installed. Install with: pip install sagemaker"
            ) from e

        # Build estimator kwargs
        estimator_kwargs = self._build_estimator_kwargs()

        # Create appropriate estimator
        if self.config.framework == Framework.HUGGINGFACE:
            estimator = HuggingFace(
                transformers_version=self.config.transformers_version,
                pytorch_version=self.config.pytorch_version,
                **estimator_kwargs,
            )
        else:
            estimator = PyTorch(
                framework_version=self.config.pytorch_version,
                **estimator_kwargs,
            )

        # Build input channels
        inputs = {}
        if self.config.train_data_uri:
            inputs["train"] = self.config.train_data_uri
        if self.config.validation_data_uri:
            inputs["validation"] = self.config.validation_data_uri

        # Start training
        started_at = datetime.now()

        job_name = self.config.job_name or f"{self.config.job_name_prefix}-{uuid.uuid4().hex[:8]}"
        self._current_job_name = job_name

        estimator.fit(
            inputs=inputs if inputs else None,
            job_name=job_name,
            wait=wait,
            logs=logs,
        )

        # Notify callbacks
        for callback in self.callbacks:
            callback.on_job_created(job_name, estimator.latest_training_job.job_name)

        # Get result
        if wait:
            status = TrainingJobStatus.COMPLETED
            model_artifacts = estimator.model_data
        else:
            status = TrainingJobStatus.IN_PROGRESS
            model_artifacts = None

        return TrainingResult(
            job_name=job_name,
            status=status,
            started_at=started_at,
            completed_at=datetime.now() if wait else None,
            model_artifacts_uri=model_artifacts,
        )

    def _build_estimator_kwargs(self) -> dict:
        """Build kwargs for SageMaker estimator."""
        instance_type = self.config.resource_config.instance_type
        if hasattr(instance_type, "value"):
            instance_type = instance_type.value

        kwargs = {
            "entry_point": self.config.entry_point,
            "py_version": self.config.python_version,
            "instance_type": instance_type,
            "instance_count": self.config.resource_config.instance_count,
            "role": self.config.role or self.client._get_role(),
            "hyperparameters": self.config.to_hyperparameters(),
            "output_path": self.config.output_path,
            "volume_size": self.config.resource_config.volume_size_gb,
            "max_run": self.config.stopping_condition.max_runtime_seconds,
            "use_spot_instances": self.config.spot_config.use_spot,
            "enable_sagemaker_metrics": self.config.enable_sagemaker_metrics,
        }

        if self.config.source_dir:
            kwargs["source_dir"] = self.config.source_dir

        if self.config.dependencies:
            kwargs["dependencies"] = self.config.dependencies

        if self.config.checkpoint_s3_uri:
            kwargs["checkpoint_s3_uri"] = self.config.checkpoint_s3_uri
            kwargs["checkpoint_local_path"] = self.config.checkpoint_local_path

        # Distribution
        distribution = self.config.distribution.to_dict()
        if distribution:
            kwargs["distribution"] = distribution

        # Spot config
        if self.config.spot_config.use_spot:
            kwargs["max_wait"] = self.config.spot_config.max_wait_seconds

        # Tags
        if self.config.tags:
            kwargs["tags"] = [{"Key": k, "Value": v} for k, v in self.config.tags.items()]

        return kwargs

    async def train_with_boto3(
        self,
        poll_interval_s: float = 60,
        timeout_s: float = 86400,
    ) -> TrainingResult:
        """Train using boto3 API directly.

        Use this for more control over the training job.

        Args:
            poll_interval_s: Status polling interval.
            timeout_s: Maximum wait time.

        Returns:
            TrainingResult with job details.
        """
        job_name = self.client.create_training_job(self.config)
        self._current_job_name = job_name
        started_at = datetime.now()

        # Get job ARN
        job_info = self.client.describe_training_job(job_name)
        job_arn = job_info.get("TrainingJobArn")

        # Notify callbacks
        for callback in self.callbacks:
            callback.on_job_created(job_name, job_arn)

        # Poll for completion
        deadline = time.time() + timeout_s
        final_status = TrainingJobStatus.IN_PROGRESS

        while time.time() < deadline:
            status = self.client.get_job_status(job_name)

            # Notify callbacks
            for callback in self.callbacks:
                callback.on_status_update(job_name, status, f"Job is {status.value}")

            if status in (
                TrainingJobStatus.COMPLETED,
                TrainingJobStatus.FAILED,
                TrainingJobStatus.STOPPED,
            ):
                final_status = status
                break

            await asyncio.sleep(poll_interval_s)

        # Get final job details
        job_info = self.client.describe_training_job(job_name)

        result = TrainingResult(
            job_name=job_name,
            job_arn=job_arn,
            status=final_status,
            started_at=started_at,
            completed_at=datetime.now(),
            model_artifacts_uri=job_info.get("ModelArtifacts", {}).get("S3ModelArtifacts"),
            output_uri=job_info.get("OutputDataConfig", {}).get("S3OutputPath"),
            billable_seconds=job_info.get("BillableTimeInSeconds", 0),
            failure_reason=job_info.get("FailureReason"),
        )

        # Extract metrics
        metrics = job_info.get("FinalMetricDataList", [])
        for metric in metrics:
            name = metric.get("MetricName", "")
            value = metric.get("Value", 0.0)

            if "loss" in name.lower():
                if "train" in name.lower():
                    result.metrics.train_loss = value
                elif "eval" in name.lower() or "valid" in name.lower():
                    result.metrics.eval_loss = value
            else:
                result.metrics.custom_metrics[name] = value

        # Notify callbacks
        for callback in self.callbacks:
            callback.on_job_completed(job_name, final_status, {"result": result})

        return result

    async def train(
        self,
        use_estimator: bool = True,
        **kwargs: Any,
    ) -> TrainingResult:
        """Train model on SageMaker.

        Args:
            use_estimator: Use SageMaker Python SDK estimator.
            **kwargs: Additional arguments for training method.

        Returns:
            TrainingResult with job details.
        """
        if use_estimator:
            # Run in thread pool since estimator.fit() is blocking
            loop = asyncio.get_event_loop()
            return await loop.run_in_executor(
                None,
                lambda: self.train_with_estimator(**kwargs),
            )
        return await self.train_with_boto3(**kwargs)

    def stop(self) -> None:
        """Stop the current training job."""
        if self._current_job_name:
            self.client.stop_training_job(self._current_job_name)

    def get_status(self) -> TrainingJobStatus:
        """Get current job status."""
        if self._current_job_name:
            return self.client.get_job_status(self._current_job_name)
        return TrainingJobStatus.IN_PROGRESS

    def get_logs(self) -> list[str]:
        """Get CloudWatch logs for current job."""
        if self._current_job_name:
            return self.client.get_training_job_logs(self._current_job_name)
        return []

    def add_callback(self, callback: TrainingCallback) -> None:
        """Add a training callback."""
        self.callbacks.append(callback)


def generate_training_script(
    model_name: str,
    training_type: str = "sft",
    use_peft: bool = True,
    use_flash_attention: bool = True,
) -> str:
    """Generate a training script for SageMaker.

    Args:
        model_name: HuggingFace model name.
        training_type: Type of training (sft, dpo).
        use_peft: Use PEFT/LoRA.
        use_flash_attention: Use Flash Attention 2.

    Returns:
        Python training script content.
    """
    script = f'''#!/usr/bin/env python3
"""Auto-generated SageMaker training script."""

import os
import argparse
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    TrainingArguments,
    Trainer,
)
from datasets import load_from_disk

def parse_args():
    parser = argparse.ArgumentParser()

    # Model
    parser.add_argument("--model_name", type=str, default="{model_name}")

    # Training
    parser.add_argument("--learning_rate", type=float, default=1e-5)
    parser.add_argument("--per_device_train_batch_size", type=int, default=4)
    parser.add_argument("--gradient_accumulation_steps", type=int, default=1)
    parser.add_argument("--max_steps", type=int, default=1000)
    parser.add_argument("--warmup_steps", type=int, default=100)
    parser.add_argument("--weight_decay", type=float, default=0.01)
    parser.add_argument("--max_seq_length", type=int, default=2048)
    parser.add_argument("--output_dir", type=str, default="/opt/ml/model")
    parser.add_argument("--save_strategy", type=str, default="steps")
    parser.add_argument("--save_steps", type=int, default=500)

    # SageMaker paths
    parser.add_argument("--train", type=str, default=os.environ.get("SM_CHANNEL_TRAIN"))
    parser.add_argument("--model_dir", type=str, default=os.environ.get("SM_MODEL_DIR", "/opt/ml/model"))

    return parser.parse_args()


def main():
    args = parse_args()

    print(f"Loading model: {{args.model_name}}")

    # Load tokenizer
    tokenizer = AutoTokenizer.from_pretrained(args.model_name)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    # Load model
    model_kwargs = {{"torch_dtype": "auto"}}
'''

    if use_flash_attention:
        script += """    model_kwargs["attn_implementation"] = "flash_attention_2"
"""

    script += """    model = AutoModelForCausalLM.from_pretrained(
        args.model_name,
        **model_kwargs,
    )
"""

    if use_peft:
        script += """
    # Apply LoRA
    from peft import LoraConfig, get_peft_model

    lora_config = LoraConfig(
        r=16,
        lora_alpha=32,
        target_modules=["q_proj", "v_proj", "k_proj", "o_proj"],
        lora_dropout=0.05,
        bias="none",
        task_type="CAUSAL_LM",
    )
    model = get_peft_model(model, lora_config)
    model.print_trainable_parameters()
"""

    script += """
    # Load dataset
    if args.train:
        dataset = load_from_disk(args.train)
    else:
        # Fallback: create dummy dataset
        from datasets import Dataset
        dataset = Dataset.from_dict({
            "text": ["Hello, world!"] * 100,
        })

    # Training arguments
    training_args = TrainingArguments(
        output_dir=args.output_dir,
        learning_rate=args.learning_rate,
        per_device_train_batch_size=args.per_device_train_batch_size,
        gradient_accumulation_steps=args.gradient_accumulation_steps,
        max_steps=args.max_steps,
        warmup_steps=args.warmup_steps,
        weight_decay=args.weight_decay,
        save_strategy=args.save_strategy,
        save_steps=args.save_steps,
        logging_steps=10,
        bf16=True,
        gradient_checkpointing=True,
    )

    # Trainer
    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=dataset,
        tokenizer=tokenizer,
    )

    # Train
    trainer.train()

    # Save
    trainer.save_model(args.model_dir)
    tokenizer.save_pretrained(args.model_dir)

    print("Training complete!")


if __name__ == "__main__":
    main()
"""

    return script


__all__ = [
    "SageMakerClient",
    "SageMakerTrainer",
    "TrainingCallback",
    "TrainingMetrics",
    "TrainingResult",
    "generate_training_script",
]
