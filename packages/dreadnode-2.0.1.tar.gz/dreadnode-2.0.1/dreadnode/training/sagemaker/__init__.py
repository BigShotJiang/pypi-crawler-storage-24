"""AWS SageMaker training backend for managed ML training.

AWS SageMaker provides fully managed infrastructure for training machine
learning models at scale.

Example:
    from dreadnode.training.sagemaker import train_on_sagemaker

    result = await train_on_sagemaker(
        config={
            "model_name": "meta-llama/Llama-3.1-8B-Instruct",
            "max_steps": 1000,
        },
        instance_type="ml.p4d.24xlarge",
        instance_count=2,
        train_data_uri="s3://my-bucket/data/train",
        output_path="s3://my-bucket/output",
    )

Requirements:
    - boto3: pip install boto3
    - sagemaker SDK (optional but recommended): pip install sagemaker
    - AWS credentials configured
    - IAM role with SageMaker permissions
"""

from __future__ import annotations

import typing as t

from dreadnode.training.sagemaker.config import (
    DistributionConfig,
    DistributionStrategy,
    Framework,
    InstanceType,
    ResourceConfig,
    S3DataConfig,
    SageMakerTrainingConfig,
    SpotConfig,
    StoppingCondition,
    TrainingJobStatus,
)
from dreadnode.training.sagemaker.trainer import (
    SageMakerClient,
    SageMakerTrainer,
    TrainingCallback,
    TrainingMetrics,
    TrainingResult,
    generate_training_script,
)


async def train_on_sagemaker(
    config: dict[str, t.Any] | None = None,
    job_name: str | None = None,
    instance_type: str = "ml.g5.2xlarge",
    instance_count: int = 1,
    train_data_uri: str | None = None,
    validation_data_uri: str | None = None,
    output_path: str | None = None,
    role: str | None = None,
    region: str | None = None,
    use_spot: bool = False,
    max_runtime_hours: float = 24,
    use_estimator: bool = True,
    wait: bool = True,
    **kwargs: t.Any,
) -> TrainingResult:
    """Train a model on AWS SageMaker.

    Args:
        config: Training configuration dict.
        job_name: Training job name (auto-generated if not provided).
        instance_type: SageMaker instance type (e.g., "ml.p4d.24xlarge").
        instance_count: Number of instances.
        train_data_uri: S3 URI for training data.
        validation_data_uri: S3 URI for validation data.
        output_path: S3 URI for output artifacts.
        role: IAM role ARN.
        region: AWS region.
        use_spot: Use managed spot training.
        max_runtime_hours: Maximum runtime in hours.
        use_estimator: Use SageMaker Python SDK estimator.
        wait: Wait for training to complete.
        **kwargs: Additional configuration options.

    Returns:
        TrainingResult with job details and model artifacts.
    """
    # Build configuration
    config_dict = config or {}

    if job_name:
        config_dict["job_name"] = job_name

    # Resource config
    try:
        instance_type_enum = InstanceType(instance_type)
    except ValueError:
        instance_type_enum = instance_type

    resource_config = ResourceConfig(
        instance_type=instance_type_enum,
        instance_count=instance_count,
        volume_size_gb=kwargs.pop("volume_size_gb", 100),
    )
    config_dict["resource_config"] = resource_config

    # Stopping condition
    stopping_condition = StoppingCondition(
        max_runtime_seconds=int(max_runtime_hours * 3600),
    )
    config_dict["stopping_condition"] = stopping_condition

    # Spot config
    if use_spot:
        spot_config = SpotConfig(
            use_spot=True,
            max_wait_seconds=int(max_runtime_hours * 3600 * 1.5),
            checkpoint_s3_uri=kwargs.pop("checkpoint_s3_uri", None),
        )
        config_dict["spot_config"] = spot_config

    # Distribution config
    distribution = kwargs.pop("distribution", None)
    if distribution and isinstance(distribution, dict):
        strategy = distribution.get("strategy", "none")
        try:
            strategy_enum = DistributionStrategy(strategy)
        except ValueError:
            strategy_enum = DistributionStrategy.NONE

        dist_config = DistributionConfig(strategy=strategy_enum)
        config_dict["distribution"] = dist_config

    # Data URIs
    if train_data_uri:
        config_dict["train_data_uri"] = train_data_uri
    if validation_data_uri:
        config_dict["validation_data_uri"] = validation_data_uri
    if output_path:
        config_dict["output_path"] = output_path

    # AWS settings
    if role:
        config_dict["role"] = role
    if region:
        config_dict["region"] = region

    # Apply remaining kwargs
    config_dict.update(kwargs)

    training_config = SageMakerTrainingConfig(**config_dict)
    trainer = SageMakerTrainer(training_config)

    return await trainer.train(use_estimator=use_estimator, wait=wait)


def submit_sagemaker_job(
    config: dict[str, t.Any] | None = None,
    **kwargs: t.Any,
) -> str:
    """Submit a training job to SageMaker without waiting.

    Returns:
        Training job name for tracking.
    """
    # Build config similar to train_on_sagemaker but simplified
    config_dict = config or {}
    config_dict.update(kwargs)

    training_config = SageMakerTrainingConfig(**config_dict)
    client = SageMakerClient(
        region=training_config.region,
        role_arn=training_config.role,
    )

    return client.create_training_job(training_config)


def get_sagemaker_job_status(
    job_name: str,
    region: str | None = None,
) -> str:
    """Get the status of a SageMaker training job.

    Args:
        job_name: Training job name.
        region: AWS region.

    Returns:
        Job status string.
    """
    client = SageMakerClient(region=region)
    status = client.get_job_status(job_name)
    return status.value


def stop_sagemaker_job(
    job_name: str,
    region: str | None = None,
) -> None:
    """Stop a SageMaker training job.

    Args:
        job_name: Training job name.
        region: AWS region.
    """
    client = SageMakerClient(region=region)
    client.stop_training_job(job_name)


__all__ = [
    # Configuration
    "DistributionConfig",
    "DistributionStrategy",
    "Framework",
    "InstanceType",
    "ResourceConfig",
    "S3DataConfig",
    # Trainer and client
    "SageMakerClient",
    "SageMakerTrainer",
    "SageMakerTrainingConfig",
    "SpotConfig",
    "StoppingCondition",
    "TrainingCallback",
    "TrainingJobStatus",
    "TrainingMetrics",
    "TrainingResult",
    # Utilities
    "generate_training_script",
    # High-level functions
    "get_sagemaker_job_status",
    "stop_sagemaker_job",
    "submit_sagemaker_job",
    "train_on_sagemaker",
]
