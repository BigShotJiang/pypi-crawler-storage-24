"""Configuration for AWS SageMaker training backend.

AWS SageMaker provides managed infrastructure for training machine learning
models at scale. This module provides configuration for training jobs
using SageMaker's PyTorch and HuggingFace estimators.
"""

from __future__ import annotations

import sys
from dataclasses import dataclass, field
from enum import Enum

if sys.version_info >= (3, 11):
    pass
else:
    pass


class InstanceType(Enum):
    """Common SageMaker instance types for training."""

    # GPU instances
    ML_P3_2XLARGE = "ml.p3.2xlarge"  # 1x V100
    ML_P3_8XLARGE = "ml.p3.8xlarge"  # 4x V100
    ML_P3_16XLARGE = "ml.p3.16xlarge"  # 8x V100
    ML_P3DN_24XLARGE = "ml.p3dn.24xlarge"  # 8x V100 + 100Gbps network
    ML_P4D_24XLARGE = "ml.p4d.24xlarge"  # 8x A100
    ML_P4DE_24XLARGE = "ml.p4de.24xlarge"  # 8x A100 80GB
    ML_P5_48XLARGE = "ml.p5.48xlarge"  # 8x H100

    # G5 instances (A10G)
    ML_G5_XLARGE = "ml.g5.xlarge"
    ML_G5_2XLARGE = "ml.g5.2xlarge"
    ML_G5_4XLARGE = "ml.g5.4xlarge"
    ML_G5_8XLARGE = "ml.g5.8xlarge"
    ML_G5_12XLARGE = "ml.g5.12xlarge"
    ML_G5_16XLARGE = "ml.g5.16xlarge"
    ML_G5_24XLARGE = "ml.g5.24xlarge"
    ML_G5_48XLARGE = "ml.g5.48xlarge"

    # Trainium instances
    ML_TRN1_2XLARGE = "ml.trn1.2xlarge"
    ML_TRN1_32XLARGE = "ml.trn1.32xlarge"
    ML_TRN1N_32XLARGE = "ml.trn1n.32xlarge"

    # CPU instances (for testing)
    ML_M5_LARGE = "ml.m5.large"
    ML_M5_XLARGE = "ml.m5.xlarge"


class TrainingJobStatus(Enum):
    """SageMaker training job status."""

    IN_PROGRESS = "InProgress"
    COMPLETED = "Completed"
    FAILED = "Failed"
    STOPPING = "Stopping"
    STOPPED = "Stopped"


class Framework(Enum):
    """Supported training frameworks."""

    PYTORCH = "pytorch"
    HUGGINGFACE = "huggingface"
    TENSORFLOW = "tensorflow"


class DistributionStrategy(Enum):
    """Distributed training strategies."""

    NONE = "none"
    PYTORCH_DDP = "pytorchddp"
    TORCH_DISTRIBUTED = "torch_distributed"
    SMDISTRIBUTED_DATAPARALLEL = "smdistributed_dataparallel"
    SMDISTRIBUTED_MODELPARALLEL = "smdistributed_modelparallel"


@dataclass
class S3DataConfig:
    """Configuration for S3 data input/output."""

    bucket: str
    """S3 bucket name."""

    prefix: str = ""
    """S3 key prefix."""

    region: str | None = None
    """AWS region (uses default if not specified)."""

    @property
    def uri(self) -> str:
        """Return full S3 URI."""
        if self.prefix:
            return f"s3://{self.bucket}/{self.prefix}"
        return f"s3://{self.bucket}"


@dataclass
class ResourceConfig:
    """Configuration for training compute resources."""

    instance_type: InstanceType | str = InstanceType.ML_G5_XLARGE
    """Instance type for training."""

    instance_count: int = 1
    """Number of instances."""

    volume_size_gb: int = 100
    """EBS volume size in GB."""

    volume_kms_key_id: str | None = None
    """KMS key for volume encryption."""

    keep_alive_period_seconds: int | None = None
    """Keep instances alive for warm pools."""

    def to_dict(self) -> dict:
        """Convert to SageMaker API format."""
        instance = self.instance_type
        if hasattr(instance, "value"):
            instance = instance.value

        config = {
            "InstanceType": instance,
            "InstanceCount": self.instance_count,
            "VolumeSizeInGB": self.volume_size_gb,
        }

        if self.volume_kms_key_id:
            config["VolumeKmsKeyId"] = self.volume_kms_key_id

        if self.keep_alive_period_seconds:
            config["KeepAlivePeriodInSeconds"] = self.keep_alive_period_seconds

        return config


@dataclass
class StoppingCondition:
    """Configuration for training job stopping conditions."""

    max_runtime_seconds: int = 86400  # 24 hours
    """Maximum training runtime in seconds."""

    max_wait_seconds: int | None = None
    """Maximum wait time for spot instances."""

    max_pending_seconds: int | None = None
    """Maximum pending time before failure."""

    def to_dict(self) -> dict:
        """Convert to SageMaker API format."""
        config = {"MaxRuntimeInSeconds": self.max_runtime_seconds}

        if self.max_wait_seconds:
            config["MaxWaitTimeInSeconds"] = self.max_wait_seconds

        if self.max_pending_seconds:
            config["MaxPendingTimeInSeconds"] = self.max_pending_seconds

        return config


@dataclass
class SpotConfig:
    """Configuration for spot/managed spot training."""

    use_spot: bool = False
    """Use managed spot training."""

    max_wait_seconds: int = 7200
    """Maximum wait time for spot capacity."""

    checkpoint_s3_uri: str | None = None
    """S3 URI for spot checkpoints."""

    checkpoint_local_path: str = "/opt/ml/checkpoints"
    """Local path for checkpoints."""


@dataclass
class DistributionConfig:
    """Configuration for distributed training."""

    strategy: DistributionStrategy = DistributionStrategy.NONE
    """Distribution strategy."""

    processes_per_host: int | None = None
    """Number of processes per host."""

    custom_mpi_options: str | None = None
    """Custom MPI options."""

    def to_dict(self) -> dict | None:
        """Convert to SageMaker distribution format."""
        if self.strategy == DistributionStrategy.NONE:
            return None

        if self.strategy == DistributionStrategy.PYTORCH_DDP:
            return {"pytorchddp": {"enabled": True}}

        if self.strategy == DistributionStrategy.TORCH_DISTRIBUTED:
            return {"torch_distributed": {"enabled": True}}

        if self.strategy == DistributionStrategy.SMDISTRIBUTED_DATAPARALLEL:
            config = {"smdistributed": {"dataparallel": {"enabled": True}}}
            if self.custom_mpi_options:
                config["smdistributed"]["dataparallel"]["custom_mpi_options"] = (
                    self.custom_mpi_options
                )
            return config

        if self.strategy == DistributionStrategy.SMDISTRIBUTED_MODELPARALLEL:
            return {"smdistributed": {"modelparallel": {"enabled": True}}}

        return None


@dataclass
class SageMakerTrainingConfig:
    """Configuration for SageMaker training jobs.

    This configuration provides all settings needed to launch a training
    job on AWS SageMaker using PyTorch or HuggingFace estimators.

    Example:
        config = SageMakerTrainingConfig(
            job_name="my-training-job",
            model_name="meta-llama/Llama-3.1-8B-Instruct",
            resource_config=ResourceConfig(
                instance_type=InstanceType.ML_P4D_24XLARGE,
                instance_count=2,
            ),
            output_path="s3://my-bucket/output",
        )
    """

    # Job identification
    job_name: str | None = None
    """Training job name (auto-generated if not provided)."""

    job_name_prefix: str = "dreadnode"
    """Prefix for auto-generated job names."""

    # Framework and versions
    framework: Framework = Framework.HUGGINGFACE
    """Training framework."""

    transformers_version: str = "4.36.0"
    """Transformers library version (for HuggingFace)."""

    pytorch_version: str = "2.1.0"
    """PyTorch version."""

    python_version: str = "py310"
    """Python version."""

    # Training script
    entry_point: str = "train.py"
    """Training script entry point."""

    source_dir: str | None = None
    """Directory containing training code."""

    dependencies: list[str] | None = None
    """Additional pip dependencies."""

    # Model configuration
    model_name: str = "meta-llama/Llama-3.1-8B-Instruct"
    """Model name or HuggingFace model ID."""

    # Training hyperparameters
    learning_rate: float = 1e-5
    """Learning rate."""

    batch_size: int = 4
    """Per-device batch size."""

    max_steps: int = 1000
    """Maximum training steps."""

    num_epochs: int | None = None
    """Number of epochs (alternative to max_steps)."""

    gradient_accumulation_steps: int = 1
    """Gradient accumulation steps."""

    warmup_steps: int = 100
    """Warmup steps."""

    weight_decay: float = 0.01
    """Weight decay."""

    max_seq_length: int = 2048
    """Maximum sequence length."""

    # Additional hyperparameters
    extra_hyperparameters: dict[str, str] = field(default_factory=dict)
    """Additional hyperparameters passed to training script."""

    # Resources
    resource_config: ResourceConfig = field(default_factory=ResourceConfig)
    """Compute resource configuration."""

    stopping_condition: StoppingCondition = field(default_factory=StoppingCondition)
    """Training stopping conditions."""

    # Distribution
    distribution: DistributionConfig = field(default_factory=DistributionConfig)
    """Distributed training configuration."""

    # Spot training
    spot_config: SpotConfig = field(default_factory=SpotConfig)
    """Managed spot training configuration."""

    # Input/Output
    train_data_uri: str | None = None
    """S3 URI for training data."""

    validation_data_uri: str | None = None
    """S3 URI for validation data."""

    output_path: str | None = None
    """S3 URI for output artifacts."""

    checkpoint_s3_uri: str | None = None
    """S3 URI for checkpoints."""

    checkpoint_local_path: str = "/opt/ml/checkpoints"
    """Local checkpoint path in container."""

    # AWS settings
    role: str | None = None
    """IAM role ARN (uses default if not provided)."""

    region: str | None = None
    """AWS region."""

    vpc_config: dict | None = None
    """VPC configuration for network isolation."""

    encrypt_inter_container_traffic: bool = True
    """Encrypt traffic between containers."""

    enable_network_isolation: bool = False
    """Enable network isolation."""

    # Logging and monitoring
    enable_sagemaker_metrics: bool = True
    """Enable SageMaker metrics."""

    metric_definitions: list[dict] | None = None
    """Custom metric definitions for CloudWatch."""

    # Tags
    tags: dict[str, str] = field(default_factory=dict)
    """Tags for the training job."""

    # Dreadnode integration
    dreadnode_project: str | None = None
    """Dreadnode project for metrics."""

    dreadnode_run_name: str | None = None
    """Dreadnode run name."""

    def __post_init__(self) -> None:
        """Validate configuration."""
        if self.max_steps <= 0 and self.num_epochs is None:
            raise ValueError("Either max_steps or num_epochs must be positive")

    def to_hyperparameters(self) -> dict[str, str]:
        """Convert training config to hyperparameters dict."""
        hp = {
            "model_name": self.model_name,
            "learning_rate": str(self.learning_rate),
            "per_device_train_batch_size": str(self.batch_size),
            "gradient_accumulation_steps": str(self.gradient_accumulation_steps),
            "warmup_steps": str(self.warmup_steps),
            "weight_decay": str(self.weight_decay),
            "max_seq_length": str(self.max_seq_length),
        }

        if self.max_steps > 0:
            hp["max_steps"] = str(self.max_steps)

        if self.num_epochs:
            hp["num_train_epochs"] = str(self.num_epochs)

        # Add checkpoint settings
        hp["output_dir"] = "/opt/ml/model"
        hp["save_strategy"] = "steps"
        hp["save_steps"] = "500"

        # Add extra hyperparameters
        hp.update(self.extra_hyperparameters)

        return hp


__all__ = [
    "DistributionConfig",
    "DistributionStrategy",
    "Framework",
    "InstanceType",
    "ResourceConfig",
    "S3DataConfig",
    "SageMakerTrainingConfig",
    "SpotConfig",
    "StoppingCondition",
    "TrainingJobStatus",
]
