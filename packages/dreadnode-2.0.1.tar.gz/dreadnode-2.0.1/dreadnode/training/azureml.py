"""High-level Azure ML training functions.

Provides convenient functions for submitting training jobs to Azure Machine Learning.

Example:
    from dreadnode.training import train_on_azureml

    result = await train_on_azureml(
        config={
            "model_name": "meta-llama/Llama-3.1-8B-Instruct",
            "max_steps": 1000,
        },
        subscription_id="...",
        resource_group="...",
        workspace_name="...",
        vm_size="Standard_NC24ads_A100_v4",
    )
"""

from __future__ import annotations

import typing as t

if t.TYPE_CHECKING:
    from dreadnode.training.azureml.trainer import TrainingResult


async def train_on_azureml(
    config: dict[str, t.Any] | None = None,
    subscription_id: str | None = None,
    resource_group: str | None = None,
    workspace_name: str | None = None,
    job_name: str | None = None,
    experiment_name: str = "dreadnode-training",
    vm_size: str = "Standard_NC6s_v3",
    min_instances: int = 0,
    max_instances: int = 4,
    instance_count: int = 1,
    use_serverless: bool = False,
    train_data_path: str | None = None,
    validation_data_path: str | None = None,
    code_path: str = "./src",
    command: str = "python train.py",
    wait: bool = True,
    stream_logs: bool = False,
    **kwargs: t.Any,
) -> TrainingResult:
    """Train a model on Azure Machine Learning.

    This function provides a high-level interface for running training
    jobs on Azure ML's managed infrastructure.

    Args:
        config: Training configuration dict. Common options:
            - model_name: HuggingFace model name
            - max_steps: Maximum training steps
            - batch_size: Per-device batch size
            - learning_rate: Learning rate
        subscription_id: Azure subscription ID.
        resource_group: Azure resource group name.
        workspace_name: Azure ML workspace name.
        job_name: Training job name (auto-generated if not provided).
        experiment_name: Experiment name for grouping jobs.
        vm_size: Azure VM size (e.g., "Standard_NC24ads_A100_v4").
        min_instances: Minimum compute instances (0 for auto-scale down).
        max_instances: Maximum compute instances.
        instance_count: Number of instances for this job.
        use_serverless: Use serverless compute.
        train_data_path: Path to training data (Azure blob or datastore).
        validation_data_path: Path to validation data.
        code_path: Path to training code directory.
        command: Training command to execute.
        wait: Wait for training to complete.
        stream_logs: Stream logs to console.
        **kwargs: Additional configuration options.

    Returns:
        TrainingResult with job details and model artifacts.

    Example:
        # Basic training
        result = await train_on_azureml(
            config={
                "model_name": "meta-llama/Llama-3.1-8B-Instruct",
                "max_steps": 1000,
            },
            subscription_id="your-subscription-id",
            resource_group="your-resource-group",
            workspace_name="your-workspace",
            vm_size="Standard_NC24ads_A100_v4",
            train_data_path="azureml://datastores/workspaceblobstore/paths/data/train",
        )

        # Distributed training
        result = await train_on_azureml(
            config={
                "model_name": "meta-llama/Llama-3.1-70B-Instruct",
                "max_steps": 500,
            },
            subscription_id="...",
            resource_group="...",
            workspace_name="...",
            vm_size="Standard_ND96asr_v4",
            instance_count=4,
            distribution_type="pytorch",
            process_count_per_instance=8,
        )

        # Serverless compute
        result = await train_on_azureml(
            config={"model_name": "...", "max_steps": 1000},
            subscription_id="...",
            resource_group="...",
            workspace_name="...",
            use_serverless=True,
        )
    """
    from dreadnode.training.azureml import (
        AzureMLTrainer,
        AzureMLTrainingConfig,
        ComputeConfig,
        DataConfig,
        VMSize,
        WorkspaceConfig,
    )

    # Build configuration
    config_dict = config or {}

    # Workspace config
    if subscription_id and resource_group and workspace_name:
        workspace_config = WorkspaceConfig(
            subscription_id=subscription_id,
            resource_group=resource_group,
            workspace_name=workspace_name,
        )
        config_dict["workspace"] = workspace_config

    # Job identification
    if job_name:
        config_dict["job_name"] = job_name
    config_dict["experiment_name"] = experiment_name

    # Compute config
    try:
        vm_size_enum = VMSize(vm_size)
    except ValueError:
        vm_size_enum = vm_size

    compute_config = ComputeConfig(
        name=kwargs.pop("compute_name", "gpu-cluster"),
        vm_size=vm_size_enum,
        min_instances=min_instances,
        max_instances=max_instances,
    )
    config_dict["compute"] = compute_config
    config_dict["use_serverless"] = use_serverless
    config_dict["instance_count"] = instance_count

    # Distribution config
    distribution_type = kwargs.pop("distribution_type", None)
    if distribution_type:
        config_dict["distribution_type"] = distribution_type
        config_dict["process_count_per_instance"] = kwargs.pop("process_count_per_instance", 1)

    # Data config
    if train_data_path:
        config_dict["train_data"] = DataConfig(
            name="train_data",
            path=train_data_path,
            type=kwargs.pop("train_data_type", "uri_folder"),
            mode=kwargs.pop("train_data_mode", "ro_mount"),
        )

    if validation_data_path:
        config_dict["validation_data"] = DataConfig(
            name="validation_data",
            path=validation_data_path,
            type=kwargs.pop("validation_data_type", "uri_folder"),
            mode=kwargs.pop("validation_data_mode", "ro_mount"),
        )

    # Code and command
    config_dict["code_path"] = code_path
    config_dict["command"] = command

    # Apply remaining kwargs
    config_dict.update(kwargs)

    training_config = AzureMLTrainingConfig(**config_dict)
    trainer = AzureMLTrainer(training_config)

    return await trainer.train(wait=wait, stream_logs=stream_logs)


def submit_azureml_job(
    config: dict[str, t.Any] | None = None,
    **kwargs: t.Any,
) -> str:
    """Submit a training job to Azure ML without waiting.

    Same parameters as train_on_azureml, but returns job name immediately.

    Returns:
        Training job name for tracking.
    """
    from dreadnode.training.azureml import (
        AzureMLClient,
        AzureMLTrainingConfig,
        WorkspaceConfig,
    )

    # Build config similar to train_on_azureml
    config_dict = config or {}

    # Extract workspace params
    subscription_id = kwargs.pop("subscription_id", None)
    resource_group = kwargs.pop("resource_group", None)
    workspace_name = kwargs.pop("workspace_name", None)

    if subscription_id and resource_group and workspace_name:
        workspace_config = WorkspaceConfig(
            subscription_id=subscription_id,
            resource_group=resource_group,
            workspace_name=workspace_name,
        )
        config_dict["workspace"] = workspace_config

    config_dict.update(kwargs)

    training_config = AzureMLTrainingConfig(**config_dict)
    client = AzureMLClient(workspace_config=training_config.workspace)

    # Ensure compute
    if not training_config.use_serverless:
        client.ensure_compute(training_config.compute)

    # Create and submit job
    command_job = client.create_command_job(training_config)
    returned_job = client.submit_job(command_job)

    return returned_job.name


def get_azureml_job_status(
    job_name: str,
    subscription_id: str | None = None,
    resource_group: str | None = None,
    workspace_name: str | None = None,
) -> str:
    """Get the status of an Azure ML training job.

    Args:
        job_name: Training job name.
        subscription_id: Azure subscription ID.
        resource_group: Azure resource group name.
        workspace_name: Azure ML workspace name.

    Returns:
        Job status string.
    """
    from dreadnode.training.azureml import AzureMLClient, WorkspaceConfig

    workspace_config = None
    if subscription_id and resource_group and workspace_name:
        workspace_config = WorkspaceConfig(
            subscription_id=subscription_id,
            resource_group=resource_group,
            workspace_name=workspace_name,
        )

    client = AzureMLClient(workspace_config=workspace_config)
    status = client.get_job_status(job_name)
    return status.value


def cancel_azureml_job(
    job_name: str,
    subscription_id: str | None = None,
    resource_group: str | None = None,
    workspace_name: str | None = None,
) -> None:
    """Cancel an Azure ML training job.

    Args:
        job_name: Training job name.
        subscription_id: Azure subscription ID.
        resource_group: Azure resource group name.
        workspace_name: Azure ML workspace name.
    """
    from dreadnode.training.azureml import AzureMLClient, WorkspaceConfig

    workspace_config = None
    if subscription_id and resource_group and workspace_name:
        workspace_config = WorkspaceConfig(
            subscription_id=subscription_id,
            resource_group=resource_group,
            workspace_name=workspace_name,
        )

    client = AzureMLClient(workspace_config=workspace_config)
    client.cancel_job(job_name)


def download_azureml_model(
    job_name: str,
    download_path: str = "./model",
    subscription_id: str | None = None,
    resource_group: str | None = None,
    workspace_name: str | None = None,
) -> str:
    """Download model artifacts from a completed Azure ML job.

    Args:
        job_name: Training job name.
        download_path: Local download path.
        subscription_id: Azure subscription ID.
        resource_group: Azure resource group name.
        workspace_name: Azure ML workspace name.

    Returns:
        Downloaded path.
    """
    from dreadnode.training.azureml import AzureMLClient, WorkspaceConfig

    workspace_config = None
    if subscription_id and resource_group and workspace_name:
        workspace_config = WorkspaceConfig(
            subscription_id=subscription_id,
            resource_group=resource_group,
            workspace_name=workspace_name,
        )

    client = AzureMLClient(workspace_config=workspace_config)
    return client.download_outputs(job_name, "model_output", download_path)


__all__ = [
    "cancel_azureml_job",
    "download_azureml_model",
    "get_azureml_job_status",
    "submit_azureml_job",
    "train_on_azureml",
]
