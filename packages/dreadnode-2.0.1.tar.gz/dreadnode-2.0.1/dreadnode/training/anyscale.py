"""High-level Anyscale training functions.

Provides convenient functions for submitting training jobs to Anyscale's
managed Ray platform.

Example:
    from dreadnode.training import train_on_anyscale

    result = await train_on_anyscale(
        config={
            "model_name": "meta-llama/Llama-3.1-8B-Instruct",
            "max_steps": 1000,
            "num_workers": 4,
        },
        training_type="grpo",
    )
"""

from __future__ import annotations

import typing as t

if t.TYPE_CHECKING:
    from dreadnode.training.anyscale.trainer import JobResult


async def train_on_anyscale(
    config: dict[str, t.Any] | None = None,
    training_type: str = "grpo",
    name: str | None = None,
    compute_config: dict[str, t.Any] | str | None = None,
    requirements: str | list[str] | None = None,
    env_vars: dict[str, str] | None = None,
    cloud: str | None = None,
    project: str | None = None,
    max_retries: int = 1,
    timeout_s: float = 3600,
    follow_logs: bool = False,
) -> JobResult:
    """Submit and run a training job on Anyscale.

    This function provides a high-level interface for running Ray-based
    training jobs on Anyscale's managed infrastructure.

    Args:
        config: Training configuration dict. Common options:
            - model_name: Model name or path
            - max_steps: Maximum training steps
            - batch_size: Batch size per device
            - learning_rate: Learning rate
            - num_workers: Number of training workers
            - gpus_per_worker: GPUs per worker
        training_type: Type of training (grpo, sft, dpo, ppo).
        name: Job name.
        compute_config: Compute configuration (dict or named config).
        requirements: Python dependencies.
        env_vars: Environment variables.
        cloud: Anyscale cloud name.
        project: Anyscale project name.
        max_retries: Maximum job retries.
        timeout_s: Job timeout in seconds.
        follow_logs: Stream logs while waiting.

    Returns:
        JobResult with final state, logs, and metrics.

    Example:
        # Simple GRPO training
        result = await train_on_anyscale(
            config={
                "model_name": "Qwen/Qwen2.5-1.5B-Instruct",
                "max_steps": 500,
                "num_workers": 2,
            },
            training_type="grpo",
        )

        # SFT with custom compute
        result = await train_on_anyscale(
            config={
                "model_name": "meta-llama/Llama-3.1-8B-Instruct",
                "max_steps": 1000,
            },
            training_type="sft",
            compute_config={
                "max_workers": 4,
                "use_spot": True,
            },
        )
    """
    from dreadnode.training.anyscale import (
        AnyscaleTrainer,
        AnyscaleTrainingConfig,
        ComputeConfig,
        create_ray_training_entrypoint,
    )

    # Build configuration
    config_dict = config or {}
    config_dict["name"] = name or config_dict.get("name", f"dreadnode-{training_type}")
    config_dict["entrypoint"] = create_ray_training_entrypoint(training_type)
    config_dict["max_retries"] = max_retries

    if compute_config:
        if isinstance(compute_config, dict):
            config_dict["compute_config"] = ComputeConfig(**compute_config)
        else:
            config_dict["compute_config"] = compute_config

    if requirements:
        config_dict["requirements"] = requirements

    if env_vars:
        config_dict["env_vars"] = env_vars

    if cloud:
        config_dict["cloud"] = cloud

    if project:
        config_dict["project"] = project

    training_config = AnyscaleTrainingConfig(**config_dict)
    trainer = AnyscaleTrainer(training_config)

    return await trainer.submit_and_wait(
        timeout_s=timeout_s,
        follow_logs=follow_logs,
    )


def submit_anyscale_job(
    config: dict[str, t.Any] | None = None,
    training_type: str = "grpo",
    **kwargs: t.Any,
) -> str:
    """Submit a training job to Anyscale without waiting.

    Same parameters as train_on_anyscale, but returns job ID immediately.

    Returns:
        Job ID for tracking.
    """
    from dreadnode.training.anyscale import (
        AnyscaleTrainer,
        AnyscaleTrainingConfig,
        create_ray_training_entrypoint,
    )

    config_dict = config or {}
    config_dict["entrypoint"] = create_ray_training_entrypoint(training_type)
    config_dict.update(kwargs)

    training_config = AnyscaleTrainingConfig(**config_dict)
    trainer = AnyscaleTrainer(training_config)

    return trainer.submit()


__all__ = ["submit_anyscale_job", "train_on_anyscale"]
