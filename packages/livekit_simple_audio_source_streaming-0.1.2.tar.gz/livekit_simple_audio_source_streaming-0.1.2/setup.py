"""Setup for livekit-simple-audio-source-streaming."""

from setuptools import find_packages, setup

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

with open("requirements.txt", "r", encoding="utf-8") as fh:
    requirements = [line.strip() for line in fh if line.strip() and not line.startswith("#")]

setup(
    name="livekit-simple-audio-source-streaming",
    version="0.1.2",
    author="Aníbal Muñoz",
    author_email="anbal.mc@hotmail.com",
    description="A Python library for streaming audio to LiveKit voice channels using FFmpeg",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/ANBAL534/livekit-simple-audio-source-streaming",
    classifiers=[
        "Intended Audience :: Developers",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Programming Language :: Python :: 3.14",
        "Topic :: Multimedia :: Sound/Audio",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    packages=find_packages(where=["src"]),
    package_dir={"": "src"},
    python_requires=">=3.10",
    install_requires=requirements,
    extras_require={
        "dev": [
            "stoat.py>=1.2.1",
            "ruff>=0.1.0",
            "mypy>=1.0.0",
        ],
    },
    entry_points={
        "console_scripts": [],
    },
    keywords=[
        "livekit",
        "audio",
        "streaming",
        "ffmpeg",
        "voice",
        "stoat",
        "stoatchat",
        "revolt",
        "bot",
    ],
    project_urls={
        "Bug Reports": "https://github.com/ANBAL534/livekit-simple-audio-source-streaming/issues",
        "Source": "https://github.com/ANBAL534/livekit-simple-audio-source-streaming",
    },
)
