"""Quality standards YAML resources."""
