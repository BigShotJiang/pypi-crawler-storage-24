#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

if ! command -v helm >/dev/null 2>&1; then
  echo "helm not available, skipping chart lint/render test"
  exit 0
fi

helm lint "$ROOT_DIR/helm"
rendered_default="$(mktemp)"
rendered_router_scouter="$(mktemp)"
trap 'rm -f "$rendered_default" "$rendered_router_scouter"' EXIT

helm template shenron "$ROOT_DIR/helm" -f "$ROOT_DIR/helm/models.yaml" >"$rendered_default"

if ! grep -q "app.kubernetes.io/component: caddy" "$rendered_default"; then
  echo "expected caddy resources to be rendered in default profile" >&2
  exit 1
fi

if ! grep -q "handle_path /llm/*" "$rendered_default"; then
  echo "expected caddy to route /llm/* in default profile" >&2
  exit 1
fi

if ! grep -q "name: shenron-replica-manager" "$rendered_default"; then
  echo "expected replica manager resources to be rendered in default profile" >&2
  exit 1
fi

if ! grep -q "REPLICA_MANAGER_TOKEN" "$rendered_default"; then
  echo "expected replica manager auth env var wiring in default profile" >&2
  exit 1
fi

if grep -q "app.kubernetes.io/component: router" "$rendered_default"; then
  echo "did not expect router resources when router.enabled=false in models profile" >&2
  exit 1
fi

if grep -q "http://shenron-router-" "$rendered_default"; then
  echo "did not expect onwards targets to point to router services when router.enabled=false" >&2
  exit 1
fi

if ! grep -q '"url": "http://shenron-' "$rendered_default"; then
  echo "expected onwards targets to point to model services in default profile" >&2
  exit 1
fi

if grep -q "app.kubernetes.io/component: scouter-reporter" "$rendered_default"; then
  echo "did not expect scouter reporter resources when scouterReporter.enabled=false in models profile" >&2
  exit 1
fi

helm template shenron "$ROOT_DIR/helm" -f "$ROOT_DIR/helm/models.yaml" \
  --set router.enabled=true \
  --set scouterReporter.enabled=true >"$rendered_router_scouter"

if ! grep -q "app.kubernetes.io/component: router" "$rendered_router_scouter"; then
  echo "expected router resources to be rendered when router.enabled=true" >&2
  exit 1
fi

if ! grep -q -- "--service-discovery" "$rendered_router_scouter"; then
  echo "expected router deployments to enable service discovery" >&2
  exit 1
fi

if ! grep -q "http://shenron-router-" "$rendered_router_scouter"; then
  echo "expected onwards targets to point to router services when router.enabled=true" >&2
  exit 1
fi

if ! grep -q "app.kubernetes.io/component: scouter-reporter" "$rendered_router_scouter"; then
  echo "expected scouter reporter resources when scouterReporter.enabled=true" >&2
  exit 1
fi

if ! grep -q "SCOUTER_MODE" "$rendered_router_scouter"; then
  echo "expected scouter reporter env wiring when scouterReporter.enabled=true" >&2
  exit 1
fi

if ! grep -q "SCOUTER_INGEST_API_KEY" "$rendered_router_scouter"; then
  echo "expected scouter reporter API key secret wiring when scouterReporter.enabled=true" >&2
  exit 1
fi

if ! grep -q 'value: "http://shenron-prometheus:9090"' "$rendered_router_scouter"; then
  echo "expected scouter reporter to target in-cluster prometheus service by default" >&2
  exit 1
fi

# --- Telemetry tests ---

# telemetry disabled by default: no OTEL env vars or trace flags
if grep -q "OTEL_EXPORTER_OTLP_ENDPOINT" "$rendered_default"; then
  echo "did not expect OTEL env vars when telemetry is disabled" >&2
  exit 1
fi

if grep -q "\-\-enable-trace" "$rendered_default"; then
  echo "did not expect --enable-trace when telemetry is disabled" >&2
  exit 1
fi

# telemetry enabled with empty endpoint should fail validation
if helm template shenron "$ROOT_DIR/helm" -f "$ROOT_DIR/helm/models.yaml" \
  --set telemetry.enabled=true --set telemetry.otlpEndpoint="" 2>/dev/null; then
  echo "expected helm template to fail when telemetry.enabled=true and otlpEndpoint is empty" >&2
  exit 1
fi

# telemetry enabled with endpoint: model pods get trace flags and OTEL env vars
rendered_telemetry="$(mktemp)"
trap 'rm -f "$rendered_default" "$rendered_router_scouter" "$rendered_telemetry"' EXIT

helm template shenron "$ROOT_DIR/helm" -f "$ROOT_DIR/helm/models.yaml" \
  --set telemetry.enabled=true \
  --set telemetry.otlpEndpoint=http://alloy-receiver:4318 >"$rendered_telemetry"

if ! grep -q "\-\-enable-trace" "$rendered_telemetry"; then
  echo "expected --enable-trace flag on model pods when telemetry is enabled" >&2
  exit 1
fi

if ! grep -q "\-\-otlp-traces-endpoint" "$rendered_telemetry"; then
  echo "expected --otlp-traces-endpoint flag on model pods when telemetry is enabled" >&2
  exit 1
fi

if ! grep -q "OTEL_EXPORTER_OTLP_ENDPOINT" "$rendered_telemetry"; then
  echo "expected OTEL_EXPORTER_OTLP_ENDPOINT env var when telemetry is enabled" >&2
  exit 1
fi

if ! grep -q "OTEL_RESOURCE_ATTRIBUTES" "$rendered_telemetry"; then
  echo "expected OTEL_RESOURCE_ATTRIBUTES env var on model pods when telemetry is enabled" >&2
  exit 1
fi

if ! grep -q 'shenron.model=' "$rendered_telemetry"; then
  echo "expected shenron.model resource attribute in OTEL_RESOURCE_ATTRIBUTES" >&2
  exit 1
fi

# onwards gets OTEL env vars when telemetry is enabled
if ! grep -q 'value: "onwards"' "$rendered_telemetry"; then
  echo "expected OTEL_SERVICE_NAME=onwards on onwards pod when telemetry is enabled" >&2
  exit 1
fi

echo "helm chart lint/template succeeded for default, router+scouter, and telemetry profiles"
