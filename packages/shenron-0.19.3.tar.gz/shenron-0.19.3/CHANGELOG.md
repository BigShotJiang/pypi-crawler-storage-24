# Changelog

## [0.19.3](https://github.com/doublewordai/shenron/compare/v0.19.2...v0.19.3) (2026-03-13)


### Bug Fixes

* install cudnn after sglang in sglang images ([6e943dd](https://github.com/doublewordai/shenron/commit/6e943dd422987c14ff85177620c810b4e6272710))
* install cudnn after sglang in sglang images ([b653050](https://github.com/doublewordai/shenron/commit/b653050e818664405744c2f08e9bf39645811d0d))

## [0.19.2](https://github.com/doublewordai/shenron/compare/v0.19.1...v0.19.2) (2026-03-12)


### Bug Fixes

* install OCR dependencies in cu130 sglang image ([#88](https://github.com/doublewordai/shenron/issues/88)) ([1d00540](https://github.com/doublewordai/shenron/commit/1d00540cc623d577ae7e43436b4142f66893a22d))

## [0.19.1](https://github.com/doublewordai/shenron/compare/v0.19.0...v0.19.1) (2026-03-12)


### Bug Fixes

* restore sglang image and release path ([#86](https://github.com/doublewordai/shenron/issues/86)) ([b42c0f0](https://github.com/doublewordai/shenron/commit/b42c0f0830ce609a308e67e5bbf0ef9ef225fff5))

## [0.19.0](https://github.com/doublewordai/shenron/compare/v0.18.5...v0.19.0) (2026-03-10)


### Features

* add distributed tracing support to Helm charts ([#84](https://github.com/doublewordai/shenron/issues/84)) ([1e4a82c](https://github.com/doublewordai/shenron/commit/1e4a82c8c11e3dc765fe7a48c6838cde2c2c533c))

## [0.18.5](https://github.com/doublewordai/shenron/compare/v0.18.4...v0.18.5) (2026-03-10)


### Bug Fixes

* increase Qwen 397 /dev/shm to 16Gi ([#82](https://github.com/doublewordai/shenron/issues/82)) ([43ea000](https://github.com/doublewordai/shenron/commit/43ea0003693531313d82854b64dc5c937a4cfbc7))

## [0.18.4](https://github.com/doublewordai/shenron/compare/v0.18.3...v0.18.4) (2026-03-10)


### Bug Fixes

* default model /dev/shm to 8Gi ([#80](https://github.com/doublewordai/shenron/issues/80)) ([9b29008](https://github.com/doublewordai/shenron/commit/9b29008e9239dd32dd457187720a3cb3e87db84d))

## [0.18.2](https://github.com/doublewordai/shenron/compare/v0.18.1...v0.18.2) (2026-03-05)


### Bug Fixes

* microk8s config ([052e34c](https://github.com/doublewordai/shenron/commit/052e34c5679d6f97942c1716edf32b3f16355ec6))

## [0.18.1](https://github.com/doublewordai/shenron/compare/v0.18.0...v0.18.1) (2026-03-05)


### Bug Fixes

* doublewordai/fix/apply-fixes-models-yaml ([744896e](https://github.com/doublewordai/shenron/commit/744896e4ff6c1e18ba058675b42dbb6b137d1fc5))

## [0.18.0](https://github.com/doublewordai/shenron/compare/v0.17.0...v0.18.0) (2026-03-04)


### Features

* endpoint setup ([#67](https://github.com/doublewordai/shenron/issues/67)) ([c98aeca](https://github.com/doublewordai/shenron/commit/c98aecaa98acadbe441683aeef213da99d83bb6e))

## [0.17.0](https://github.com/doublewordai/shenron/compare/v0.16.1...v0.17.0) (2026-03-02)


### Features

* **helm:** add router, replica manager, and scouter reporter support ([f06b839](https://github.com/doublewordai/shenron/commit/f06b8396719c38ca911f75c7c2c7276e37ab12ad))
* **helm:** add router, replica manager, and scouter reporter support ([12fb798](https://github.com/doublewordai/shenron/commit/12fb7987526ae945cbfc90e8de8d2789517e3e36))

## [0.16.1](https://github.com/doublewordai/shenron/compare/v0.16.0...v0.16.1) (2026-02-27)


### Bug Fixes

* **helm:** tune model sampling defaults and correct memory unit ([103daca](https://github.com/doublewordai/shenron/commit/103dacab61db5866db957ebd65168dfb0fec925e))
* **helm:** tune model sampling defaults and correct memory unit ([d03e4a1](https://github.com/doublewordai/shenron/commit/d03e4a11cad7ca732d2d616ee3b80e2b53eac626))

## [0.16.0](https://github.com/doublewordai/shenron/compare/v0.15.0...v0.16.0) (2026-02-26)


### Features

* **helm:** add per-model /dev/shm sizing support ([443b17f](https://github.com/doublewordai/shenron/commit/443b17f0bab14770fbe6bf1af07b9e53a9bfac84))
* **helm:** add per-model /dev/shm sizing support ([3eb1dd7](https://github.com/doublewordai/shenron/commit/3eb1dd7c650bce48f74ecec1c61f6da51172d72a))

## [0.15.0](https://github.com/doublewordai/shenron/compare/v0.14.0...v0.15.0) (2026-02-26)


### Features

* **helm:** add Prometheus scraping and sglang cu130 docker build ([b47cdaa](https://github.com/doublewordai/shenron/commit/b47cdaa24064cfec6bf877ee6f8238d80e83400b))
* **helm:** add prometheus scraping and sglang cu130 image CI build ([8332074](https://github.com/doublewordai/shenron/commit/8332074a130aca68bf1c89a5084f8fb5f6711348))

## [0.14.0](https://github.com/doublewordai/shenron/compare/v0.13.0...v0.14.0) (2026-02-26)


### Features

* add GPT-OSS-20B ([6efece1](https://github.com/doublewordai/shenron/commit/6efece18a8bd6bd47b2b50d418879df751e72503))
* add GPT-OSS-20B configs for cu126 and cu129 ([f87ba2d](https://github.com/doublewordai/shenron/commit/f87ba2de95fd7d4792f5a0b77063be326262e401))

## [0.13.0](https://github.com/doublewordai/shenron/compare/v0.12.0...v0.13.0) (2026-02-23)


### Features

* migrate to engine_* schema and models-first configs ([#57](https://github.com/doublewordai/shenron/issues/57)) ([b58cf6f](https://github.com/doublewordai/shenron/commit/b58cf6f5b93da488efe239e802665da98bf2a84a))

## [0.12.0](https://github.com/doublewordai/shenron/compare/v0.11.1...v0.12.0) (2026-02-23)


### Features

* add sglangmux generation and writable compose mounts ([e7facb4](https://github.com/doublewordai/shenron/commit/e7facb47f8e15dde589b6e7963f69b9229ed3281))

## [0.11.1](https://github.com/doublewordai/shenron/compare/v0.11.0...v0.11.1) (2026-02-18)


### Bug Fixes

* mirror release configs to public shenron-configs repo ([1ab706a](https://github.com/doublewordai/shenron/commit/1ab706a))

## [0.11.0](https://github.com/doublewordai/shenron/compare/v0.10.1...v0.11.0) (2026-02-17)


### Features

* add disable_responses_api_store option to configuration ([094da28](https://github.com/doublewordai/shenron/commit/094da28f12ab4bcdff5126e7b8a39ae90ef11673))
* add disable_responses_api_store option to configuration ([436e188](https://github.com/doublewordai/shenron/commit/436e18874d20bff485e34cb60630f29dd24b6a2a))

## [0.10.1](https://github.com/doublewordai/shenron/compare/v0.10.0...v0.10.1) (2026-02-17)


### Bug Fixes

* use qwen 30b fp8 model in configs ([73147d7](https://github.com/doublewordai/shenron/commit/73147d78fe6f62fbd3b06a4b5afc6716bb16e604))

## [0.10.0](https://github.com/doublewordai/shenron/compare/v0.9.0...v0.10.0) (2026-02-12)


### Features

* add shenron get overrides ([b3c4a8c](https://github.com/doublewordai/shenron/commit/b3c4a8ceb7a9695469b85fc2ef4c9606827717f0))

## [0.9.0](https://github.com/doublewordai/shenron/compare/v0.8.2...v0.9.0) (2026-02-12)


### Features

* keep latest tag for shenron_version ([b1c1d26](https://github.com/doublewordai/shenron/commit/b1c1d267b5d92d9ca19a2609abc16b620bb76648))
* keep latest tag for shenron_version ([5e37979](https://github.com/doublewordai/shenron/commit/5e37979a89810897c4372625323febbffa8fa411))
* set cu126 torch backend ([ef91a12](https://github.com/doublewordai/shenron/commit/ef91a12a35d2d5ab36a6ff766db481dd7ebc4c0d))
* set cu126 torch backend ([cbb4c45](https://github.com/doublewordai/shenron/commit/cbb4c452ad5c2254d835b8d079943b9f954ed24c))
* update CUDA 13 image for B300 ([80a56e9](https://github.com/doublewordai/shenron/commit/80a56e9a42e525a16580f8b8c29865a4cd50b770))


### Bug Fixes

* CUDA 13 image for B300 ([67f47b1](https://github.com/doublewordai/shenron/commit/67f47b1d306156bb78c74c7b4a1dd44b9507c21a))

## [0.8.2](https://github.com/doublewordai/shenron/compare/v0.8.1...v0.8.2) (2026-02-12)


### Bug Fixes

* tag latest on main pushes ([d8edec3](https://github.com/doublewordai/shenron/commit/d8edec34acd6db8517852ca61b6c6ef9f00b7df5))
* trigger release ([bac5310](https://github.com/doublewordai/shenron/commit/bac5310d2673b870ffa53121c40d06a70609d2b1))

## [0.8.1](https://github.com/doublewordai/shenron/compare/v0.8.0...v0.8.1) (2026-02-12)


### Bug Fixes

* note release-please triggers ([#37](https://github.com/doublewordai/shenron/issues/37)) ([b25fcf9](https://github.com/doublewordai/shenron/commit/b25fcf9bf72459d331be91fd1eefd518216551b3))

## [0.8.0](https://github.com/doublewordai/shenron/compare/v0.7.0...v0.8.0) (2026-02-12)


### Features

* add enable_expert_parallel config flag ([bb83726](https://github.com/doublewordai/shenron/commit/bb83726aad45f9cd303b1f445d73626bf53242b5))
* add enable_expert_parallel flag ([05f7748](https://github.com/doublewordai/shenron/commit/05f7748c401261425b1221e3658e39f06d227a3e))
* add interactive shenron get command for release configs ([315b7a9](https://github.com/doublewordai/shenron/commit/315b7a92d5170230bc97571cb37c764ca9c9c862))
* add Qwen235 TP2 config for cu129 ([eb88e90](https://github.com/doublewordai/shenron/commit/eb88e905c22b70c4d7be7c1f8e482a70d2271d7f))
* add Qwen235 TP2 cu129 production config ([462bdf0](https://github.com/doublewordai/shenron/commit/462bdf0ecc3e07a41c3d4100cb01353ca8becfc0))
* add Qwen30B A3B TP1 configs for cu126/cu129 ([5a79524](https://github.com/doublewordai/shenron/commit/5a795242fb09510b8ea05ac3fc887022d3bc7dfa))
* add Qwen30B A3B TP1 configs for cu126/cu129 ([e14ed3d](https://github.com/doublewordai/shenron/commit/e14ed3d1098a8fae71b14d327f4d5a56420d198f))
* add shenron get for release config selection ([fbda3d7](https://github.com/doublewordai/shenron/commit/fbda3d73c5b6a4e23f5c532cef781f14a3228351))


### Bug Fixes

* let release-please create GitHub releases ([263c89b](https://github.com/doublewordai/shenron/commit/263c89bc105ebd9308cefe78017bb6b5d0675109))
* let release-please create GitHub releases ([472f34d](https://github.com/doublewordai/shenron/commit/472f34d0e1927ad4b6069c95d2ee2d7f27ae6863))
* normalize TTY line endings in get picker ([528bd4a](https://github.com/doublewordai/shenron/commit/528bd4a14ba7242de64812835bac59646fff0c9a))
* render shenron get picker lines correctly ([ca3eeb6](https://github.com/doublewordai/shenron/commit/ca3eeb67f3c8b6230c5d1a4a7830a79ac1684c73))

## [0.7.0](https://github.com/doublewordai/shenron/compare/v0.6.3...v0.7.0) (2026-02-11)


### Features

* add CUDA 12.9/13 presets for Qwen model configs ([9c00382](https://github.com/doublewordai/shenron/commit/9c0038237dc5a92f4f2a7ac9feb7b77e13ed993c))
* add qwen config presets for cu129 and cu130 ([25df0c3](https://github.com/doublewordai/shenron/commit/25df0c3525b14cce2a9bbe3c26800872f5960db4))

## [0.6.3](https://github.com/doublewordai/shenron/compare/v0.6.2...v0.6.3) (2026-02-11)


### Bug Fixes

* make release creation deterministic from VERSION ([4818b7b](https://github.com/doublewordai/shenron/commit/4818b7bbdec77d455e2d2d9680200b41407bc498))
* mark merged release PR as tagged after release ([e448182](https://github.com/doublewordai/shenron/commit/e4481823c9a2ec2f906b260594798e019d01a889))

## [0.6.2](https://github.com/doublewordai/shenron/compare/v0.6.1...v0.6.2) (2026-02-11)


### Bug Fixes

* re-enable Depot cache for cu129 builds ([45e31fe](https://github.com/doublewordai/shenron/commit/45e31fe77339d5a60a9fe2e14c656b7b4464ee4a))

## [0.6.1](https://github.com/doublewordai/shenron/compare/v0.6.0...v0.6.1) (2026-02-11)


### Bug Fixes

* align quickstart and default config with v0.6.0 ([f99ce5c](https://github.com/doublewordai/shenron/commit/f99ce5c54b036584b12672a21be28e4db33c5bd2))

## [0.6.0](https://github.com/doublewordai/shenron/compare/v0.5.2...v0.6.0) (2026-02-11)


### Features

* config-driven shenron generator and release automation ([1f4c4a4](https://github.com/doublewordai/shenron/commit/1f4c4a44942976ad706cde7ea39037b656ee2c88))

## [0.5.2](https://github.com/doublewordai/shenron/compare/v0.5.1...v0.5.2) (2026-02-09)


### Bug Fixes

* add depy auth ([4fa847a](https://github.com/doublewordai/shenron/commit/4fa847a73ee0fe5dd19e728489ac4eda7b296353))
* add verification for DEPOT_PROJECT_ID in CI workflow and update build steps ([223c256](https://github.com/doublewordai/shenron/commit/223c256f4334513e22c68b368960c9f8ab4461b4))
* add verification for DEPOT_PROJECT_ID in CI workflow and update build steps ([b5111df](https://github.com/doublewordai/shenron/commit/b5111dfc91a5cc441d5617d50e596cfe7bce9c76))

## [0.5.1](https://github.com/doublewordai/shenron/compare/v0.5.0...v0.5.1) (2026-02-09)


### Bug Fixes

* add Depot CLI setup step to CI workflow for release events ([87e7ef8](https://github.com/doublewordai/shenron/commit/87e7ef8654f149f2f5721626cb87ed94e8dd3248))
* add Depot CLI setup step to CI workflow for release events ([cc642c1](https://github.com/doublewordai/shenron/commit/cc642c1da8919e54f15657d91cf7e5c28f6a62c0))

## [0.5.0](https://github.com/doublewordai/shenron/compare/v0.4.0...v0.5.0) (2026-02-09)


### Features

* add Copilot instructions and enhance CI workflow with build space maximization ([b632cea](https://github.com/doublewordai/shenron/commit/b632ceaf851a3f6efad59ae340c303c809b1a88d))


### Bug Fixes

* add Copilot instructions and enhance CI workflow with build space maximization ([d15d018](https://github.com/doublewordai/shenron/commit/d15d018a71b445b528c15ef5f9e3ccd2ff49dbfb))

## [0.4.0](https://github.com/doublewordai/shenron/compare/v0.3.0...v0.4.0) (2026-02-06)


### Features

* update Docker image references to use ghcr.io for consistency ([7797780](https://github.com/doublewordai/shenron/commit/7797780b06b42bdcc67ac34142b5fb6a54ec7a3f))


### Bug Fixes

* update Docker image references to use ghcr.io for consistency ([c3d755a](https://github.com/doublewordai/shenron/commit/c3d755af94ee52d35c2ca88570de483626521792))

## [0.3.0](https://github.com/doublewordai/shenron/compare/v0.2.0...v0.3.0) (2026-02-06)


### Features

* update SHENRON_VERSION handling in docker-compose and related tests ([333db7f](https://github.com/doublewordai/shenron/commit/333db7f90ca2074ca898c59c18bec5f40985f954))


### Bug Fixes

* update SHENRON_VERSION handling in docker-compose and related t… ([77cd3bd](https://github.com/doublewordai/shenron/commit/77cd3bd34e1cb241f090ac1b2d4f57e1053f8f84))

## [0.2.0](https://github.com/doublewordai/shenron/compare/v0.1.0...v0.2.0) (2026-02-06)


### Features

* add ci ([f2c245e](https://github.com/doublewordai/shenron/commit/f2c245e6ab6c844a6aba6f26159842e3b8706ebd))
* add GitHub Actions workflow for automated releases ([05b8ad4](https://github.com/doublewordai/shenron/commit/05b8ad4505867be33eadd4cf258e825d2c5253c5))
* add GitHub Actions workflow for releasing assets and enhance run_docker_compose.sh for auto-downloading compose files ([c470d11](https://github.com/doublewordai/shenron/commit/c470d113fc2d00695a61c8910084b8b8a40b1c6a))
* add pull-requests permission to docker-build job in CI workflow ([08b02f8](https://github.com/doublewordai/shenron/commit/08b02f889f396aee878a8482e40466ea23811e73))
* remove branch protection workflow for main ([a23b950](https://github.com/doublewordai/shenron/commit/a23b950eebe51f4943e127c18db3a8692f860e12))
* remove branch protection workflow for main ([cd17472](https://github.com/doublewordai/shenron/commit/cd17472029b3f98c5ac493e277e4a56f1434cfad))
* remove redundant hadolint and Rust formatting steps from CI workflow ([cb07f9f](https://github.com/doublewordai/shenron/commit/cb07f9f9bd5998b961364f2f315f45e5268e1813))
* update CI workflow to specify ShellCheck target and enhance run_docker_compose.sh for version handling and vLLM config ([773e931](https://github.com/doublewordai/shenron/commit/773e931bd4d14237debfd12c254641653ef552f8))
* update docker-build job permissions and conditions in CI workflow ([dcf13ad](https://github.com/doublewordai/shenron/commit/dcf13ad81cf45fd90a0b45a975f3638e1d83e4e0))
* update release-please workflow to use GITHUB_TOKEN instead of RELEASE_TOKEN ([ca24a0c](https://github.com/doublewordai/shenron/commit/ca24a0c5639cdf70f31d0b3dda3724f0d630324f))
* update release-please workflow to use GITHUB_TOKEN instead of RELEASE_TOKEN ([dadf699](https://github.com/doublewordai/shenron/commit/dadf6996ccc0c405a785618b8feeb2bd152ffbfb))

## Changelog
