from .client import HonkaiStarrail

__version__ = "1.0.1"
__author__ = "sora"
__all__ = ["HonkaiStarrail"]