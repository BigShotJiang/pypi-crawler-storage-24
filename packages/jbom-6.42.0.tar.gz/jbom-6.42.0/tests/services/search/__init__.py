"""Search service unit tests."""
