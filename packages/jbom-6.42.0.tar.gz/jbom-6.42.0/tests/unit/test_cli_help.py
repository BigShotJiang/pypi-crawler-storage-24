import subprocess
import sys
from pathlib import Path

# Unit tests for CLI --help output. These are fast and stable, unlike Gherkin end-to-end.

PROJECT_ROOT = Path(__file__).resolve().parents[2]
SRC_DIR = PROJECT_ROOT / "src"


def run_help(args):
    env = dict(**os_environ_with_pythonpath())
    cmd = [sys.executable, "-m", "jbom.cli.main"] + args + ["--help"]
    res = subprocess.run(cmd, capture_output=True, text=True, env=env)
    assert res.returncode == 0, res.stderr or res.stdout
    return res.stdout + res.stderr


def os_environ_with_pythonpath():
    import os

    env = os.environ.copy()
    env["PYTHONPATH"] = str(SRC_DIR)
    return env


def test_bom_help_includes_fabricator_choices():
    out = run_help(["bom"]).lower()
    # Stable tokens rather than brittle long strings
    assert "--fabricator" in out

    # Use dynamic fabricator discovery instead of hardcoded list
    import sys

    sys.path.insert(0, str(SRC_DIR))
    try:
        from jbom.config.fabricators import get_available_fabricators

        available_fabricators = get_available_fabricators()
        for fab in available_fabricators:
            assert fab in out
    finally:
        sys.path.remove(str(SRC_DIR))


def test_bom_help_shows_key_options():
    out = run_help(["bom"]).lower()
    for token in ["--include-dnp", "--inventory", "-o", "--output"]:
        assert token in out


def test_pos_help_shows_core_flags():
    out = run_help(["pos"]).lower()
    for token in ["--units", "--origin", "--smd-only", "-o", "--output"]:
        assert token in out


def test_inventory_help_shows_inventory_interface_tokens():
    out = run_help(["inventory"]).lower()
    # Test current simplified interface with inventory matching flags
    tokens_current = [
        "--inventory",
        "--filter-matches",
        "--per-instance",
        "-o",
        "--output",
    ]
    for token in tokens_current:
        assert token in out


def test_root_help_includes_search_command():
    out = run_help([]).lower()
    assert "search" in out


def test_root_help_includes_annotate_command():
    out = run_help([]).lower()
    assert "annotate" in out


def test_annotate_help_shows_core_flags():
    out = run_help(["annotate"]).lower()
    for token in ["--repairs", "--dry-run", "--normalize"]:
        assert token in out


def test_root_help_does_not_include_retired_inventory_search():
    out = run_help([]).lower()
    assert "inventory-search" not in out


def test_all_subcommands_show_defaults_option_in_help():
    for command in ["annotate", "audit", "bom", "inventory", "parts", "pos", "search"]:
        out = run_help([command]).lower()
        assert "--defaults" in out


def test_search_help_lists_only_configured_supplier_providers():
    out = run_help(["search"]).lower()
    assert "--supplier" in out
    assert "--provider" not in out

    # Only suppliers with search.providers in YAML should appear as choices.
    assert "mouser" in out
    assert "lcsc" in out

    # Suppliers without providers should not appear.
    assert "digikey" not in out
    assert "seeed" not in out
