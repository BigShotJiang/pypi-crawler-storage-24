# Meridian EUID Governance Docs

## Current Reference Docs

- [../README.md](../README.md): package and CLI overview
- [GOVERNANCE_S3_IAD.md](GOVERNANCE_S3_IAD.md): current S3-based issuing-authority directory profile

This repo has a small current docs surface; the governance profile document is the main normative reference in this repository.
