# S3-Based Issuing Authority Directory (IAD) — Governance Profile v1

> **Status**: Normative within this repository.
> **Scope**: Defines how Meridian EUID category assignments and issuing authority
> configurations are stored, discovered, and archived in an S3-based directory.
> This document is **not** part of the [Meridian EUID Specification](https://github.com/lsmc-bio/meridian-euid/blob/main/SPEC.md).

---

## 1. Overview

An **Issuing Authority Directory (IAD)** is an S3 bucket that contains JSON
descriptors for every `(sandbox_token, category)` pair that has an authorised
EUID issuing service. Relying systems discover issuing authorities by reading
the **current descriptor** for a given namespace + category.

## 2. Namespace Modes

| Mode | `sandbox_token` value | Description |
|------|----------------------|-------------|
| **production** | `"prod"` | Real identifiers. No prefix on issued EUIDs. |
| **sandbox** | One of `H,J,K,M,N,P,Q,R,S,T,V,W,X,Y,Z` | Test/dev identifiers. Prefix appears before `:` in EUID. |

Letters A-G are **reserved** by the Meridian EUID Specification and MUST NOT be
used as sandbox tokens.

## 3. Category Rules

A **category** is 2-3 uppercase characters from the Crockford Base32 letter
subset: `A B C D E F G H J K M N P Q R S T V W X Y Z` (no I, L, O, U).

Digits are NOT permitted in categories.

## 4. S3 Bucket Layout

### 4.1 Current Descriptor Path

```
{sandbox_token}/{category}/{sandbox_token}-{category}-issuing_authority.json
```

**Examples:**
- `prod/TX/prod-TX-issuing_authority.json`
- `H/DNA/H-DNA-issuing_authority.json`

### 4.2 Archive Descriptor Path

```
{sandbox_token}/{category}/archive/{effective_from_utc}/{sandbox_token}-{category}-issuing_authority.json
```

**Examples:**
- `prod/TX/archive/2026-01-15T120000Z/prod-TX-issuing_authority.json`
- `H/DNA/archive/2025-12-01T000000Z/H-DNA-issuing_authority.json`

### 4.3 `effective_from_utc` Format

The timestamp component MUST use the format `YYYY-MM-DDTHHMMSSZ` (ISO 8601
basic time with `T` separator, no colons, always UTC `Z`).

## 5. Descriptor JSON Format

Each descriptor MUST conform to the JSON Schema at
`schemas/meridian-euid-issuing-authority.v1.schema.json`.

Required top-level fields:

| Field | Type | Description |
|-------|------|-------------|
| `schema.name` | string | MUST be `"meridian-euid-issuing-authority"` |
| `schema.version` | integer | MUST be `1` |
| `namespace.mode` | string | `"production"` or `"sandbox"` |
| `namespace.sandbox_token` | string | `"prod"` or a valid sandbox letter |
| `namespace.sandbox_prefix` | string or null | `null` for production; equals `sandbox_token` for sandbox |
| `category` | string | 2-3 Crockford letters |
| `authority.authority_id` | string | Unique identifier for this issuing authority |
| `authority.kind` | string | `"http"` (extensible) |
| `authority.endpoints.issue` | string | URL for the issue endpoint |
| `authority.endpoints.health` | string | URL for the health endpoint |
| `authority.auth.method` | string | One of `"sigv4"`, `"oauth2"`, `"mtls"` |
| `authority.auth.details` | object | Auth config (MUST NOT contain secrets) |
| `validity.status` | string | `"active"` or `"deprecated"` |
| `validity.valid_from` | string or null | RFC 3339 datetime or null |
| `validity.valid_to` | string or null | RFC 3339 datetime or null |
| `change.supersedes_s3_key` | string or null | S3 key of the descriptor this one replaces |
| `metadata.owner_team` | string | Owning team name |
| `metadata.description` | string | Human-readable description |
| `metadata.created_at` | string | RFC 3339 datetime |
| `metadata.created_by` | string | Identity of the creator |

## 6. Invariants

### 6.1 Path Congruence

The `sandbox_token` and `category` fields inside the JSON descriptor MUST match
the corresponding path components of its S3 key. Validators MUST reject any
descriptor where this invariant is violated.

### 6.2 Append-Only Archive

When a current descriptor is replaced, the previous version MUST be copied to
the archive path **before** the new version is written. Implementations MUST NOT
overwrite or delete archived descriptors.

### 6.3 Reserved Prefix Rejection

Descriptors with `namespace.sandbox_token` set to any of `A`, `B`, `C`, `D`,
`E`, `F`, `G` MUST be rejected. These prefixes are reserved by the Meridian EUID
Specification.

## 7. Discovery Protocol

1. A relying system constructs the current descriptor S3 key from the known
   `sandbox_token` and `category`.
2. It performs an S3 `GetObject` on that key.
3. The returned JSON is validated against the schema and path congruence rules.
4. The `authority.endpoints.issue` URL is used to request new EUIDs.
5. The `authority.endpoints.health` URL is used for liveness checks.

## 8. Security Considerations

- Descriptors MUST NOT contain secrets (API keys, passwords, private keys).
- The `authority.auth.details` object describes how to authenticate but MUST
  reference secrets by ARN, secret name, or external vault path — never inline.
- S3 bucket policies SHOULD restrict write access to governance administrators.
- S3 versioning SHOULD be enabled for auditability.
