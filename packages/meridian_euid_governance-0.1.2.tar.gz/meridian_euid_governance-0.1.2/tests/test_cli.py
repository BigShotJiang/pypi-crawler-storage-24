"""Tests for meridian_euid_governance.cli."""

from __future__ import annotations

import json
import pathlib

import pytest

from meridian_euid_governance.cli import build_parser, main

EXAMPLES = pathlib.Path(__file__).resolve().parent.parent / "examples" / "issuing-authority"


# ---------------------------------------------------------------------------
# Parser construction
# ---------------------------------------------------------------------------


class TestParser:
    def test_version_flag(self, capsys):
        parser = build_parser()
        with pytest.raises(SystemExit, match="0"):
            parser.parse_args(["--version"])

    def test_validate_subcommand(self):
        parser = build_parser()
        args = parser.parse_args(["validate", "some_file.json"])
        assert args.command == "validate"
        assert args.file == "some_file.json"

    def test_key_current(self):
        parser = build_parser()
        args = parser.parse_args(["key-current", "--sandbox-token", "prod", "--category", "TX"])
        assert args.command == "key-current"

    def test_key_archive(self):
        parser = build_parser()
        args = parser.parse_args(
            [
                "key-archive",
                "--sandbox-token",
                "prod",
                "--category",
                "TX",
                "--effective-from-utc",
                "2026-01-15T120000Z",
            ]
        )
        assert args.command == "key-archive"


# ---------------------------------------------------------------------------
# validate subcommand
# ---------------------------------------------------------------------------


class TestCmdValidate:
    def test_valid_file(self, capsys):
        prod_file = EXAMPLES / "prod-TX-issuing_authority.json"
        main(["validate", str(prod_file)])
        captured = capsys.readouterr()
        assert "VALID" in captured.out

    def test_invalid_file(self, tmp_path, capsys):
        bad = tmp_path / "bad.json"
        bad.write_text(json.dumps({"schema": {"name": "wrong", "version": 1}}))
        with pytest.raises(SystemExit, match="1"):
            main(["validate", str(bad)])


# ---------------------------------------------------------------------------
# key-current / key-archive subcommands
# ---------------------------------------------------------------------------


class TestKeySubcommands:
    def test_key_current_output(self, capsys):
        main(["key-current", "--sandbox-token", "prod", "--category", "TX"])
        captured = capsys.readouterr()
        assert captured.out.strip() == "prod/TX/prod-TX-issuing_authority.json"

    def test_key_archive_output(self, capsys):
        main(
            [
                "key-archive",
                "--sandbox-token",
                "H",
                "--category",
                "DNA",
                "--effective-from-utc",
                "2025-12-01T000000Z",
            ]
        )
        captured = capsys.readouterr()
        assert (
            captured.out.strip() == "H/DNA/archive/2025-12-01T000000Z/H-DNA-issuing_authority.json"
        )

    def test_key_archive_bad_timestamp(self, capsys):
        with pytest.raises(ValueError, match="YYYY-MM-DDTHHMMSSZ"):
            main(
                [
                    "key-archive",
                    "--sandbox-token",
                    "prod",
                    "--category",
                    "TX",
                    "--effective-from-utc",
                    "bad-timestamp",
                ]
            )
