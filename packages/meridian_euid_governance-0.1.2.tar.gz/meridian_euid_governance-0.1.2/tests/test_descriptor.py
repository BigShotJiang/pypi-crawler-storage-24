"""Tests for meridian_euid_governance.descriptor."""

from __future__ import annotations

import copy
import json
import pathlib

import pytest

from meridian_euid_governance.descriptor import (
    DescriptorValidationError,
    s3_key_archive,
    s3_key_current,
    validate_authority_descriptor,
)

# ---------------------------------------------------------------------------
# Fixtures — load example descriptors as base templates
# ---------------------------------------------------------------------------

EXAMPLES = pathlib.Path(__file__).resolve().parent.parent / "examples" / "issuing-authority"


@pytest.fixture
def prod_descriptor() -> dict:
    return json.loads((EXAMPLES / "prod-TX-issuing_authority.json").read_text())


@pytest.fixture
def sandbox_descriptor() -> dict:
    return json.loads((EXAMPLES / "H-EX-issuing_authority.json").read_text())


# ---------------------------------------------------------------------------
# S3 key builder tests
# ---------------------------------------------------------------------------


class TestS3KeyCurrent:
    def test_production(self):
        assert s3_key_current("prod", "TX") == "prod/TX/prod-TX-issuing_authority.json"

    def test_sandbox(self):
        assert s3_key_current("H", "DNA") == "H/DNA/H-DNA-issuing_authority.json"

    def test_three_letter_category(self):
        assert s3_key_current("prod", "TAP") == "prod/TAP/prod-TAP-issuing_authority.json"


class TestS3KeyArchive:
    def test_production(self):
        key = s3_key_archive("prod", "TX", "2026-01-15T120000Z")
        assert key == "prod/TX/archive/2026-01-15T120000Z/prod-TX-issuing_authority.json"

    def test_sandbox(self):
        key = s3_key_archive("H", "DNA", "2025-12-01T000000Z")
        assert key == "H/DNA/archive/2025-12-01T000000Z/H-DNA-issuing_authority.json"

    def test_bad_timestamp_format(self):
        with pytest.raises(ValueError, match="YYYY-MM-DDTHHMMSSZ"):
            s3_key_archive("prod", "TX", "2026-01-15T12:00:00Z")

    def test_bad_timestamp_no_z(self):
        with pytest.raises(ValueError, match="YYYY-MM-DDTHHMMSSZ"):
            s3_key_archive("prod", "TX", "2026-01-15T120000")


# ---------------------------------------------------------------------------
# Descriptor validation — happy path
# ---------------------------------------------------------------------------


class TestValidateHappyPath:
    def test_production_descriptor_valid(self, prod_descriptor):
        result = validate_authority_descriptor(prod_descriptor)
        assert result is prod_descriptor  # returns same dict

    def test_sandbox_descriptor_valid(self, sandbox_descriptor):
        result = validate_authority_descriptor(sandbox_descriptor)
        assert result is sandbox_descriptor


# ---------------------------------------------------------------------------
# Descriptor validation — schema block
# ---------------------------------------------------------------------------


class TestValidateSchema:
    def test_missing_schema(self, prod_descriptor):
        del prod_descriptor["schema"]
        with pytest.raises(DescriptorValidationError, match="schema"):
            validate_authority_descriptor(prod_descriptor)

    def test_wrong_schema_name(self, prod_descriptor):
        prod_descriptor["schema"]["name"] = "wrong"
        with pytest.raises(DescriptorValidationError, match="schema.name"):
            validate_authority_descriptor(prod_descriptor)

    def test_wrong_schema_version(self, prod_descriptor):
        prod_descriptor["schema"]["version"] = 99
        with pytest.raises(DescriptorValidationError, match="schema.version"):
            validate_authority_descriptor(prod_descriptor)


# ---------------------------------------------------------------------------
# Descriptor validation — namespace
# ---------------------------------------------------------------------------


class TestValidateNamespace:
    def test_invalid_mode(self, prod_descriptor):
        prod_descriptor["namespace"]["mode"] = "staging"
        with pytest.raises(DescriptorValidationError, match="namespace.mode"):
            validate_authority_descriptor(prod_descriptor)

    def test_production_wrong_token(self, prod_descriptor):
        prod_descriptor["namespace"]["sandbox_token"] = "H"
        with pytest.raises(DescriptorValidationError, match="prod"):
            validate_authority_descriptor(prod_descriptor)

    def test_production_non_null_prefix(self, prod_descriptor):
        prod_descriptor["namespace"]["sandbox_prefix"] = "H"
        with pytest.raises(DescriptorValidationError, match="null"):
            validate_authority_descriptor(prod_descriptor)

    def test_sandbox_reserved_prefix_a(self, sandbox_descriptor):
        sandbox_descriptor["namespace"]["sandbox_token"] = "A"
        sandbox_descriptor["namespace"]["sandbox_prefix"] = "A"
        with pytest.raises(DescriptorValidationError, match="reserved"):
            validate_authority_descriptor(sandbox_descriptor)

    def test_sandbox_reserved_prefix_g(self, sandbox_descriptor):
        sandbox_descriptor["namespace"]["sandbox_token"] = "G"
        sandbox_descriptor["namespace"]["sandbox_prefix"] = "G"
        with pytest.raises(DescriptorValidationError, match="reserved"):
            validate_authority_descriptor(sandbox_descriptor)

    def test_sandbox_prefix_mismatch(self, sandbox_descriptor):
        sandbox_descriptor["namespace"]["sandbox_prefix"] = "K"
        with pytest.raises(DescriptorValidationError, match="sandbox_prefix must equal"):
            validate_authority_descriptor(sandbox_descriptor)

    def test_all_valid_sandbox_tokens(self, sandbox_descriptor):
        """Every non-reserved letter should pass."""
        for letter in "HJKMNPQRSTVWXYZ":
            d = copy.deepcopy(sandbox_descriptor)
            d["namespace"]["sandbox_token"] = letter
            d["namespace"]["sandbox_prefix"] = letter
            assert validate_authority_descriptor(d) is d


# ---------------------------------------------------------------------------
# Descriptor validation — category
# ---------------------------------------------------------------------------


class TestValidateCategory:
    def test_lowercase_rejected(self, prod_descriptor):
        prod_descriptor["category"] = "tx"
        with pytest.raises(DescriptorValidationError, match="category"):
            validate_authority_descriptor(prod_descriptor)

    def test_single_char_rejected(self, prod_descriptor):
        prod_descriptor["category"] = "T"
        with pytest.raises(DescriptorValidationError, match="2-3 characters"):
            validate_authority_descriptor(prod_descriptor)

    def test_four_char_rejected(self, prod_descriptor):
        prod_descriptor["category"] = "TXYZ"
        with pytest.raises(DescriptorValidationError, match="2-3 characters"):
            validate_authority_descriptor(prod_descriptor)

    def test_forbidden_letter_i(self, prod_descriptor):
        prod_descriptor["category"] = "TI"
        with pytest.raises(DescriptorValidationError, match="category"):
            validate_authority_descriptor(prod_descriptor)

    def test_digits_rejected(self, prod_descriptor):
        prod_descriptor["category"] = "T1"
        with pytest.raises(DescriptorValidationError, match="category"):
            validate_authority_descriptor(prod_descriptor)


# ---------------------------------------------------------------------------
# Descriptor validation — authority
# ---------------------------------------------------------------------------


class TestValidateAuthority:
    def test_missing_authority_id(self, prod_descriptor):
        del prod_descriptor["authority"]["authority_id"]
        with pytest.raises(DescriptorValidationError, match="authority_id"):
            validate_authority_descriptor(prod_descriptor)

    def test_invalid_kind(self, prod_descriptor):
        prod_descriptor["authority"]["kind"] = "grpc"
        with pytest.raises(DescriptorValidationError, match="authority.kind"):
            validate_authority_descriptor(prod_descriptor)

    def test_invalid_auth_method(self, prod_descriptor):
        prod_descriptor["authority"]["auth"]["method"] = "apikey"
        with pytest.raises(DescriptorValidationError, match="authority.auth.method"):
            validate_authority_descriptor(prod_descriptor)

    def test_missing_endpoints(self, prod_descriptor):
        del prod_descriptor["authority"]["endpoints"]
        with pytest.raises(DescriptorValidationError, match="endpoints"):
            validate_authority_descriptor(prod_descriptor)


# ---------------------------------------------------------------------------
# Descriptor validation — validity / change / metadata
# ---------------------------------------------------------------------------


class TestValidateOtherSections:
    def test_invalid_status(self, prod_descriptor):
        prod_descriptor["validity"]["status"] = "revoked"
        with pytest.raises(DescriptorValidationError, match="validity.status"):
            validate_authority_descriptor(prod_descriptor)

    def test_missing_change(self, prod_descriptor):
        del prod_descriptor["change"]
        with pytest.raises(DescriptorValidationError, match="change"):
            validate_authority_descriptor(prod_descriptor)

    def test_missing_metadata_owner(self, prod_descriptor):
        del prod_descriptor["metadata"]["owner_team"]
        with pytest.raises(DescriptorValidationError, match="owner_team"):
            validate_authority_descriptor(prod_descriptor)

    def test_not_a_dict(self):
        with pytest.raises(DescriptorValidationError, match="JSON object"):
            validate_authority_descriptor("string")  # type: ignore

    def test_deprecated_status_valid(self, prod_descriptor):
        prod_descriptor["validity"]["status"] = "deprecated"
        assert validate_authority_descriptor(prod_descriptor) is prod_descriptor
