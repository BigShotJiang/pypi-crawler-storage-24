"""Tests for meridian_euid_governance.s3_directory using botocore Stubber."""

from __future__ import annotations

import io
import json
import pathlib

import pytest

from meridian_euid_governance.descriptor import s3_key_current
from meridian_euid_governance.s3_directory import (
    get_current_descriptor,
    list_categories,
    list_sandboxes,
    put_current_descriptor,
)

try:
    import boto3
    from botocore.stub import Stubber
except ImportError:
    pytest.skip("boto3 required for S3 tests", allow_module_level=True)

EXAMPLES = pathlib.Path(__file__).resolve().parent.parent / "examples" / "issuing-authority"
BUCKET = "test-iad-bucket"


@pytest.fixture
def prod_doc() -> dict:
    return json.loads((EXAMPLES / "prod-TX-issuing_authority.json").read_text())


@pytest.fixture
def sandbox_doc() -> dict:
    return json.loads((EXAMPLES / "H-EX-issuing_authority.json").read_text())


@pytest.fixture
def s3_client():
    client = boto3.client("s3", region_name="us-east-1")
    return client


# ---------------------------------------------------------------------------
# get_current_descriptor
# ---------------------------------------------------------------------------


class TestGetCurrentDescriptor:
    def test_get_valid_descriptor(self, s3_client, prod_doc):
        body = json.dumps(prod_doc).encode("utf-8")
        key = s3_key_current("prod", "TX")
        with Stubber(s3_client) as stubber:
            stubber.add_response(
                "get_object",
                {
                    "Body": io.BytesIO(body),
                    "ContentType": "application/json",
                },
                expected_params={"Bucket": BUCKET, "Key": key},
            )
            result = get_current_descriptor(s3_client, BUCKET, "prod", "TX")
        assert result["category"] == "TX"
        assert result["namespace"]["mode"] == "production"


# ---------------------------------------------------------------------------
# list_sandboxes
# ---------------------------------------------------------------------------


class TestListSandboxes:
    def test_list(self, s3_client):
        with Stubber(s3_client) as stubber:
            stubber.add_response(
                "list_objects_v2",
                {
                    "CommonPrefixes": [
                        {"Prefix": "H/"},
                        {"Prefix": "prod/"},
                    ],
                },
                expected_params={"Bucket": BUCKET, "Delimiter": "/"},
            )
            result = list_sandboxes(s3_client, BUCKET)
        assert result == ["H", "prod"]

    def test_empty_bucket(self, s3_client):
        with Stubber(s3_client) as stubber:
            stubber.add_response(
                "list_objects_v2",
                {},
                expected_params={"Bucket": BUCKET, "Delimiter": "/"},
            )
            result = list_sandboxes(s3_client, BUCKET)
        assert result == []


# ---------------------------------------------------------------------------
# list_categories
# ---------------------------------------------------------------------------


class TestListCategories:
    def test_list(self, s3_client):
        with Stubber(s3_client) as stubber:
            stubber.add_response(
                "list_objects_v2",
                {
                    "CommonPrefixes": [
                        {"Prefix": "prod/DNA/"},
                        {"Prefix": "prod/TX/"},
                    ],
                },
                expected_params={
                    "Bucket": BUCKET,
                    "Prefix": "prod/",
                    "Delimiter": "/",
                },
            )
            result = list_categories(s3_client, BUCKET, "prod")
        assert result == ["DNA", "TX"]


# ---------------------------------------------------------------------------
# put_current_descriptor
# ---------------------------------------------------------------------------


class TestPutCurrentDescriptor:
    def test_put_first_descriptor_no_archive(self, s3_client, prod_doc):
        key = s3_key_current("prod", "TX")
        body = json.dumps(prod_doc, indent=2, sort_keys=False) + "\n"
        with Stubber(s3_client) as stubber:
            stubber.add_response(
                "put_object",
                {},
                expected_params={
                    "Bucket": BUCKET,
                    "Key": key,
                    "Body": body.encode("utf-8"),
                    "ContentType": "application/json",
                },
            )
            result = put_current_descriptor(
                s3_client, BUCKET, prod_doc, "2026-01-15T120000Z", archive=False
            )
        assert result == key
