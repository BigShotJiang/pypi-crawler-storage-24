# meridian-euid-governance

`meridian-euid-governance` defines the governance-layer artifacts around Meridian EUID issuing authorities.

It provides:

- descriptor validation for issuing-authority documents
- S3 key conventions for current and archived descriptors
- CLI helpers for validate/get/put/list operations
- a JSON Schema for descriptor payloads
- S3 directory helpers for bucket-backed discovery

## Repository Role

Use this repo when you need to manage or validate the S3-based Issuing Authority Directory (IAD) for Meridian namespaces and categories.

Primary package: `meridian_euid_governance`

## CLI Surface

Entry command: `meridian-euid-governance`

Current commands:

- `validate`
- `key-current`
- `key-archive`
- `get`
- `put`
- `list-sandboxes`
- `list-categories`

S3 commands require the optional `aws` extra.

## Package Layout

- `meridian_euid_governance/descriptor.py`: descriptor validation and key helpers
- `meridian_euid_governance/s3_directory.py`: S3 directory operations
- `schemas/meridian-euid-issuing-authority.v1.schema.json`: descriptor schema
- `examples/issuing-authority/`: example descriptor payloads

## Quick Start

```bash
pip install -e .[dev,aws]
meridian-euid-governance validate examples/issuing-authority/prod-TX-issuing_authority.json
```

## Current Docs

- [Docs index](docs/README.md)
- [IAD governance profile](docs/GOVERNANCE_S3_IAD.md)

<!-- release-sweep: 2026-03-10 -->
