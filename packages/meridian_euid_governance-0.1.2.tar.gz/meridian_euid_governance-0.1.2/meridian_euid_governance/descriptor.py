"""Issuing Authority Descriptor validation and S3 key construction."""

from __future__ import annotations

import re
from typing import Any

# ---------- constants ----------

_SCHEMA_NAME = "meridian-euid-issuing-authority"
_SCHEMA_VERSION = 1
_VALID_MODES = frozenset({"production", "sandbox"})
_VALID_AUTH_METHODS = frozenset({"sigv4", "oauth2", "mtls"})
_VALID_STATUSES = frozenset({"active", "deprecated"})
_VALID_KINDS = frozenset({"http"})
_RESERVED_SANDBOX_PREFIXES = frozenset("ABCDEFG")
_VALID_SANDBOX_PREFIXES = frozenset("HJKMNPQRSTVWXYZ")
_CATEGORY_RE = re.compile(r"^[A-HJ-KMNP-TV-Z]{2,3}$")

_EFFECTIVE_TS_RE = re.compile(r"^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{6}Z$")


# ---------- S3 key builders ----------


def s3_key_current(sandbox_token: str, category: str) -> str:
    """Build the S3 key for the **current** descriptor.

    >>> s3_key_current("prod", "TX")
    'prod/TX/prod-TX-issuing_authority.json'
    >>> s3_key_current("H", "DNA")
    'H/DNA/H-DNA-issuing_authority.json'
    """
    return f"{sandbox_token}/{category}/{sandbox_token}-{category}-issuing_authority.json"


def s3_key_archive(sandbox_token: str, category: str, effective_from_utc: str) -> str:
    """Build the S3 key for an **archived** descriptor.

    ``effective_from_utc`` must match the format ``YYYY-MM-DDTHHMMSSZ``.

    >>> s3_key_archive("prod", "TX", "2026-01-15T120000Z")
    'prod/TX/archive/2026-01-15T120000Z/prod-TX-issuing_authority.json'
    """
    if not _EFFECTIVE_TS_RE.fullmatch(effective_from_utc):
        raise ValueError(
            f"effective_from_utc must match YYYY-MM-DDTHHMMSSZ, got {effective_from_utc!r}"
        )
    return (
        f"{sandbox_token}/{category}/archive/{effective_from_utc}/"
        f"{sandbox_token}-{category}-issuing_authority.json"
    )


# ---------- descriptor validation ----------


class DescriptorValidationError(Exception):
    """Raised when an issuing authority descriptor fails validation."""


class _IdentifierValidationError(ValueError):
    """Raised when a category or sandbox token fails local validation."""


def _require(condition: bool, msg: str) -> None:
    if not condition:
        raise DescriptorValidationError(msg)


def _require_key(doc: dict, key: str, expected_type: type, label: str) -> Any:
    full_label = f"{label}.{key}" if label else key
    _require(key in doc, f"missing required field: {full_label}")
    val = doc[key]
    _require(
        isinstance(val, expected_type),
        f"{full_label} must be {expected_type.__name__}",
    )
    return val


def _validate_category(category: str) -> str:
    if not isinstance(category, str):
        raise _IdentifierValidationError("category must be a string")
    if not (2 <= len(category) <= 3):
        raise _IdentifierValidationError("category must be 2-3 characters")
    if not _CATEGORY_RE.fullmatch(category):
        raise _IdentifierValidationError(
            "category must be 2-3 uppercase Crockford Base32 letters (no I/L/O/U)"
        )
    return category


def _validate_sandbox_token(token: str) -> str:
    if not isinstance(token, str):
        raise _IdentifierValidationError("sandbox token must be a string")
    if len(token) != 1:
        raise _IdentifierValidationError("sandbox token must be a single character")
    if token in _RESERVED_SANDBOX_PREFIXES:
        raise _IdentifierValidationError(f"sandbox token {token!r} is reserved (A-G are reserved)")
    if token not in _VALID_SANDBOX_PREFIXES:
        raise _IdentifierValidationError(
            f"sandbox token {token!r} is not a valid Crockford letter"
        )
    return token


def validate_authority_descriptor(doc: dict) -> dict:
    """Validate an issuing authority descriptor dict.

    Performs structural, semantic, and path-congruence validation.
    Returns the descriptor unchanged on success.

    Raises:
        DescriptorValidationError: On any validation failure.
    """
    _require(isinstance(doc, dict), "descriptor must be a JSON object")

    # -- schema --
    schema = _require_key(doc, "schema", dict, "")
    _require(schema.get("name") == _SCHEMA_NAME, f"schema.name must be {_SCHEMA_NAME!r}")
    _require(schema.get("version") == _SCHEMA_VERSION, f"schema.version must be {_SCHEMA_VERSION}")

    # -- namespace --
    ns = _require_key(doc, "namespace", dict, "")
    mode = _require_key(ns, "mode", str, "namespace")
    _require(mode in _VALID_MODES, f"namespace.mode must be one of {sorted(_VALID_MODES)}")

    sandbox_token = _require_key(ns, "sandbox_token", str, "namespace")
    sandbox_prefix = ns.get("sandbox_prefix")

    if mode == "production":
        _require(
            sandbox_token == "prod",
            'namespace.sandbox_token must be "prod" for production mode',
        )
        _require(
            sandbox_prefix is None,
            "namespace.sandbox_prefix must be null for production mode",
        )
    else:
        try:
            _validate_sandbox_token(sandbox_token)
        except _IdentifierValidationError as exc:
            raise DescriptorValidationError(f"namespace.sandbox_token: {exc}") from exc
        _require(
            sandbox_prefix == sandbox_token,
            (
                "namespace.sandbox_prefix must equal sandbox_token "
                f"({sandbox_token!r}) for sandbox mode"
            ),
        )

    # -- category --
    category = _require_key(doc, "category", str, "")
    try:
        _validate_category(category)
    except _IdentifierValidationError as exc:
        raise DescriptorValidationError(f"category: {exc}") from exc

    # -- authority --
    auth_block = _require_key(doc, "authority", dict, "")
    _require_key(auth_block, "authority_id", str, "authority")
    kind = _require_key(auth_block, "kind", str, "authority")
    _require(kind in _VALID_KINDS, f"authority.kind must be one of {sorted(_VALID_KINDS)}")

    endpoints = _require_key(auth_block, "endpoints", dict, "authority")
    _require_key(endpoints, "issue", str, "authority.endpoints")
    _require_key(endpoints, "health", str, "authority.endpoints")

    auth = _require_key(auth_block, "auth", dict, "authority")
    method = _require_key(auth, "method", str, "authority.auth")
    _require(
        method in _VALID_AUTH_METHODS,
        f"authority.auth.method must be one of {sorted(_VALID_AUTH_METHODS)}",
    )
    _require_key(auth, "details", dict, "authority.auth")

    # -- validity --
    validity = _require_key(doc, "validity", dict, "")
    status = _require_key(validity, "status", str, "validity")
    _require(
        status in _VALID_STATUSES,
        f"validity.status must be one of {sorted(_VALID_STATUSES)}",
    )
    _require("valid_from" in validity, "missing required field: validity.valid_from")
    _require("valid_to" in validity, "missing required field: validity.valid_to")

    # -- change --
    change = _require_key(doc, "change", dict, "")
    _require("supersedes_s3_key" in change, "missing required field: change.supersedes_s3_key")

    # -- metadata --
    meta = _require_key(doc, "metadata", dict, "")
    _require_key(meta, "owner_team", str, "metadata")
    _require_key(meta, "description", str, "metadata")
    _require_key(meta, "created_at", str, "metadata")
    _require_key(meta, "created_by", str, "metadata")

    return doc
