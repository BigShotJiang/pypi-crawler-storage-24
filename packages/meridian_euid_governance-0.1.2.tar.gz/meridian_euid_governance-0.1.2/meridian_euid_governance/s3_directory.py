"""S3-based Issuing Authority Directory operations.

Requires the ``aws`` extra: ``pip install meridian-euid-governance[aws]``.
"""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any

from .descriptor import (
    s3_key_archive,
    s3_key_current,
    validate_authority_descriptor,
)

if TYPE_CHECKING:
    from mypy_boto3_s3.client import S3Client

try:
    import boto3  # noqa: F401 — runtime availability check
except ImportError:
    boto3 = None  # type: ignore[assignment]


def _ensure_boto3() -> None:
    if boto3 is None:
        raise ImportError(
            "boto3 is required for S3 directory operations. "
            "Install with: pip install meridian-euid-governance[aws]"
        )


# ---------- read operations ----------


def get_current_descriptor(
    s3_client: "S3Client",
    bucket: str,
    sandbox_token: str,
    category: str,
) -> dict[str, Any]:
    """Fetch and validate the current descriptor for (sandbox_token, category).

    Args:
        s3_client: A boto3 S3 client.
        bucket: S3 bucket name.
        sandbox_token: ``"prod"`` or a valid sandbox letter.
        category: 2-3 Crockford letters.

    Returns:
        The validated descriptor dict.

    Raises:
        DescriptorValidationError: If the fetched descriptor is invalid.
        botocore.exceptions.ClientError: On S3 errors (e.g. NoSuchKey).
    """
    _ensure_boto3()
    key = s3_key_current(sandbox_token, category)
    resp = s3_client.get_object(Bucket=bucket, Key=key)
    doc = json.loads(resp["Body"].read())
    return validate_authority_descriptor(doc)


def list_sandboxes(s3_client: "S3Client", bucket: str) -> list[str]:
    """List all sandbox tokens (top-level prefixes) in the bucket.

    Returns:
        Sorted list of sandbox token strings (e.g. ``["H", "prod"]``).
    """
    _ensure_boto3()
    resp = s3_client.list_objects_v2(Bucket=bucket, Delimiter="/")
    prefixes = resp.get("CommonPrefixes", [])
    return sorted(p["Prefix"].rstrip("/") for p in prefixes)


def list_categories(s3_client: "S3Client", bucket: str, sandbox_token: str) -> list[str]:
    """List all categories for a given sandbox token.

    Returns:
        Sorted list of category strings (e.g. ``["DNA", "TX"]``).
    """
    _ensure_boto3()
    prefix = f"{sandbox_token}/"
    resp = s3_client.list_objects_v2(Bucket=bucket, Prefix=prefix, Delimiter="/")
    prefixes = resp.get("CommonPrefixes", [])
    return sorted(
        p["Prefix"].rstrip("/").split("/")[-1]
        for p in prefixes
        if p["Prefix"].rstrip("/").split("/")[-1] != "archive"
    )


# ---------- write operations ----------


def put_current_descriptor(
    s3_client: "S3Client",
    bucket: str,
    doc: dict[str, Any],
    effective_from_utc: str,
    archive: bool = True,
) -> str:
    """Validate, optionally archive the existing descriptor, and write a new one.

    Args:
        s3_client: A boto3 S3 client.
        bucket: S3 bucket name.
        doc: The new descriptor dict. Will be validated before writing.
        effective_from_utc: Timestamp for archive key (``YYYY-MM-DDTHHMMSSZ``).
        archive: If True (default), archive the existing descriptor first.

    Returns:
        The S3 key of the newly written current descriptor.

    Raises:
        DescriptorValidationError: If ``doc`` fails validation.
    """
    _ensure_boto3()
    validated = validate_authority_descriptor(doc)
    sandbox_token = validated["namespace"]["sandbox_token"]
    category = validated["category"]
    current_key = s3_key_current(sandbox_token, category)

    if archive:
        # Archive existing (ignore NoSuchKey if first write)
        try:
            existing = s3_client.get_object(Bucket=bucket, Key=current_key)
            archive_key = s3_key_archive(sandbox_token, category, effective_from_utc)
            s3_client.put_object(
                Bucket=bucket,
                Key=archive_key,
                Body=existing["Body"].read(),
                ContentType="application/json",
            )
        except s3_client.exceptions.NoSuchKey:
            pass  # First descriptor for this (token, category) — nothing to archive

    body = json.dumps(validated, indent=2, sort_keys=False) + "\n"
    s3_client.put_object(
        Bucket=bucket,
        Key=current_key,
        Body=body.encode("utf-8"),
        ContentType="application/json",
    )
    return current_key
