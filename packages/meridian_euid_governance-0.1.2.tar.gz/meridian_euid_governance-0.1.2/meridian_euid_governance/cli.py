"""CLI for Meridian EUID Governance — issuing authority management."""

from __future__ import annotations

import argparse
import json
import sys
from typing import Sequence

from . import __version__
from .descriptor import (
    DescriptorValidationError,
    s3_key_archive,
    s3_key_current,
    validate_authority_descriptor,
)


def _print_json(obj: object) -> None:
    print(json.dumps(obj, indent=2, sort_keys=False))


def _s3_client():
    """Lazy-import boto3 and return an S3 client."""
    try:
        import boto3
    except ImportError:
        print(
            "ERROR: boto3 is required for S3 operations.\n"
            "Install with: pip install meridian-euid-governance[aws]",
            file=sys.stderr,
        )
        sys.exit(1)
    return boto3.client("s3")


# ---------- sub-commands ----------


def cmd_validate(args: argparse.Namespace) -> None:
    """Validate a local descriptor JSON file."""
    with open(args.file, "r") as fh:
        doc = json.load(fh)
    try:
        validate_authority_descriptor(doc)
    except DescriptorValidationError as exc:
        print(f"INVALID: {exc}", file=sys.stderr)
        sys.exit(1)
    print(f"VALID: {args.file}")


def cmd_key_current(args: argparse.Namespace) -> None:
    """Print the S3 key for a current descriptor."""
    print(s3_key_current(args.sandbox_token, args.category))


def cmd_key_archive(args: argparse.Namespace) -> None:
    """Print the S3 key for an archive descriptor."""
    print(s3_key_archive(args.sandbox_token, args.category, args.effective_from_utc))


def cmd_get(args: argparse.Namespace) -> None:
    """Fetch and display the current descriptor from S3."""
    from .s3_directory import get_current_descriptor

    client = _s3_client()
    try:
        doc = get_current_descriptor(client, args.bucket, args.sandbox_token, args.category)
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        sys.exit(1)
    _print_json(doc)


def cmd_put(args: argparse.Namespace) -> None:
    """Upload a descriptor to S3 (with optional archiving)."""
    from .s3_directory import put_current_descriptor

    with open(args.file, "r") as fh:
        doc = json.load(fh)
    client = _s3_client()
    try:
        key = put_current_descriptor(
            client,
            args.bucket,
            doc,
            args.effective_from_utc,
            archive=not args.no_archive,
        )
    except (DescriptorValidationError, ValueError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        sys.exit(1)
    print(f"OK: written to s3://{args.bucket}/{key}")


def cmd_list_sandboxes(args: argparse.Namespace) -> None:
    """List sandbox tokens in the bucket."""
    from .s3_directory import list_sandboxes

    client = _s3_client()
    tokens = list_sandboxes(client, args.bucket)
    for t in tokens:
        print(t)


def cmd_list_categories(args: argparse.Namespace) -> None:
    """List categories for a sandbox token."""
    from .s3_directory import list_categories

    client = _s3_client()
    cats = list_categories(client, args.bucket, args.sandbox_token)
    for c in cats:
        print(c)


# ---------- parser ----------


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="meridian-euid-governance",
        description="Meridian EUID Governance — issuing authority management.",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)

    # validate
    p_val = sub.add_parser("validate", help="Validate a local descriptor JSON file.")
    p_val.add_argument("file", help="Path to descriptor JSON file.")
    p_val.set_defaults(func=cmd_validate)

    # key-current
    p_kc = sub.add_parser("key-current", help="Print S3 key for a current descriptor.")
    p_kc.add_argument("--sandbox-token", required=True)
    p_kc.add_argument("--category", required=True)
    p_kc.set_defaults(func=cmd_key_current)

    # key-archive
    p_ka = sub.add_parser("key-archive", help="Print S3 key for an archive descriptor.")
    p_ka.add_argument("--sandbox-token", required=True)
    p_ka.add_argument("--category", required=True)
    p_ka.add_argument("--effective-from-utc", required=True)
    p_ka.set_defaults(func=cmd_key_archive)

    # get
    p_get = sub.add_parser("get", help="Fetch current descriptor from S3.")
    p_get.add_argument("--bucket", required=True)
    p_get.add_argument("--sandbox-token", required=True)
    p_get.add_argument("--category", required=True)
    p_get.set_defaults(func=cmd_get)

    # put
    p_put = sub.add_parser("put", help="Upload descriptor to S3.")
    p_put.add_argument("--bucket", required=True)
    p_put.add_argument("--file", required=True, help="Path to descriptor JSON file.")
    p_put.add_argument("--effective-from-utc", required=True)
    p_put.add_argument(
        "--no-archive",
        action="store_true",
        help="Skip archiving existing descriptor.",
    )
    p_put.set_defaults(func=cmd_put)

    # list-sandboxes
    p_ls = sub.add_parser("list-sandboxes", help="List sandbox tokens in bucket.")
    p_ls.add_argument("--bucket", required=True)
    p_ls.set_defaults(func=cmd_list_sandboxes)

    # list-categories
    p_lc = sub.add_parser("list-categories", help="List categories for a sandbox token.")
    p_lc.add_argument("--bucket", required=True)
    p_lc.add_argument("--sandbox-token", required=True)
    p_lc.set_defaults(func=cmd_list_categories)

    return parser


def main(argv: Sequence[str] | None = None) -> None:
    parser = build_parser()
    args = parser.parse_args(argv)
    args.func(args)
