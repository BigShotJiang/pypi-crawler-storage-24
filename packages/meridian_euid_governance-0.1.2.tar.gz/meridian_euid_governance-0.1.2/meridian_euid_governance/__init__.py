"""Meridian EUID Governance -- enterprise governance profiles for EUID deployments."""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("meridian-euid-governance")
except PackageNotFoundError:
    try:
        from meridian_euid_governance._version import __version__
    except ImportError:
        __version__ = "0.0.0.dev0"

from .descriptor import s3_key_archive, s3_key_current, validate_authority_descriptor

__all__ = [
    "__version__",
    "validate_authority_descriptor",
    "s3_key_current",
    "s3_key_archive",
]
