# veriflo

Official Python SDK for Veriflo WhatsApp OTP API.

## Install

```bash
pip install veriflo
```

## Quick Start

```python
import os
from veriflo import VerifloClient

client = VerifloClient(os.environ["VERIFLO_API_KEY"])

sent = client.send_otp("+919999999999")
print(sent.get("request_id"))

verified = client.verify_otp(sent["request_id"], "123456")
print(verified.get("verified"))
```

## API

- `VerifloClient(api_key, timeout=10, base_url="https://api.veriflo.app/v1")`
- `send_otp(phone, otp=None, integration_test=False, test_mode=False)`
- `resend_otp(request_id, otp=None, integration_test=False, test_mode=False)`
- `verify_otp(request_id, otp)`
- `verify_otp_locally(expected_otp, received_otp)`

## Notes

- Keep API keys in server-side environment variables.
- Do not expose your API key in browser/mobile client code.
