"""Check and replay commands — regression detection against golden baselines."""
from __future__ import annotations

import csv
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, TYPE_CHECKING

import click

from evalview.commands.shared import (
    console,
    _load_config_if_exists,
    _cloud_pull,
    _execute_check_tests,
    _analyze_check_diffs,
    _parse_fail_statuses,
)
from evalview.commands.check_display import (
    _display_check_results,
    _print_trajectory_diff,
)
from evalview.telemetry.decorators import track_command

if TYPE_CHECKING:
    from evalview.core.types import EvaluationResult
    from evalview.core.diff import TraceDiff


def _compute_check_exit_code(
    diffs: List[Tuple[str, "TraceDiff"]],
    fail_on: Optional[str],
    strict: bool
) -> int:
    """Compute exit code based on diff results and fail conditions.

    Returns:
        0 if no failures match fail conditions, 1 otherwise
    """
    if strict:
        fail_on = "REGRESSION,TOOLS_CHANGED,OUTPUT_CHANGED"

    if not fail_on:
        fail_on = "REGRESSION"  # Default

    fail_statuses = _parse_fail_statuses(fail_on)

    for _, diff in diffs:
        if diff.overall_severity in fail_statuses:
            return 1

    return 0


@click.command("check")
@click.argument("test_path", default="tests", type=click.Path(exists=True))
@click.option("--test", "-t", help="Check only this specific test")
@click.option("--json", "json_output", is_flag=True, help="Output JSON for CI")
@click.option("--fail-on", help="Comma-separated statuses to fail on (default: REGRESSION)")
@click.option("--strict", is_flag=True, help="Fail on any change (REGRESSION, TOOLS_CHANGED, OUTPUT_CHANGED)")
@click.option("--report", "report_path", default=None, type=click.Path(), help="Generate HTML report at this path (auto-opens in browser)")
@click.option("--csv", "csv_path", default=None, type=click.Path(), help="Export results to a CSV file")
@click.option(
    "--semantic-diff/--no-semantic-diff",
    "semantic_diff",
    default=None,
    help=(
        "Enable/disable embedding-based semantic similarity. "
        "Auto-enabled when OPENAI_API_KEY is set (adds ~$0.00004/test). "
        "Use --no-semantic-diff to opt out."
    ),
)
@click.option("--budget", type=float, default=None, help="Maximum total budget in dollars.")
@click.option("--timeout", type=float, default=30.0, help="Timeout per test in seconds (default: 30.0).")
@click.option("--dry-run", "dry_run", is_flag=True, default=False, help="Preview test plan without executing.")
@click.option("--ai-root-cause", "ai_root_cause", is_flag=True, default=False, help="Use AI to explain low-confidence regressions (requires LLM provider).")
@track_command("check")
def check(test_path: str, test: str, json_output: bool, fail_on: str, strict: bool, report_path: Optional[str], csv_path: Optional[str], semantic_diff: Optional[bool], budget: Optional[float], timeout: float, dry_run: bool, ai_root_cause: bool):
    """Check current behavior against snapshot baseline.

    This command runs tests and compares them against your saved baselines,
    showing only what changed. Perfect for CI/CD and daily development.

    TEST_PATH is the directory containing test cases (default: tests/).

    Examples:
        evalview check                                   # Check all tests
        evalview check --test "my-test"                  # Check one test
        evalview check --json                            # JSON output for CI
        evalview check --csv results.csv                 # Export results to CSV
        evalview check --report report.html              # Generate HTML report
        evalview check --fail-on REGRESSION,TOOLS_CHANGED
        evalview check --strict                          # Fail on any change
        evalview check --no-semantic-diff                # Opt out of semantic diff
        evalview check --dry-run                         # Preview plan, no API calls
        evalview check --budget 0.50                     # Cap spend at $0.50
        evalview check --timeout 60                      # 60 second timeout per test
        evalview check --ai-root-cause                   # AI-powered regression explanation
    """
    if budget is not None and budget <= 0:
        click.echo("Error: --budget must be a positive number.", err=True)
        sys.exit(1)

    if timeout <= 0:
        click.echo("Error: --timeout must be a positive number.", err=True)
        sys.exit(1)

    from evalview.core.loader import TestCaseLoader
    from evalview.core.golden import GoldenStore
    from evalview.core.project_state import ProjectStateStore
    from evalview.core.celebrations import Celebrations
    from evalview.core.messages import get_random_checking_message

    # Initialize stores
    store = GoldenStore()
    state_store = ProjectStateStore()

    # Check if this is the first check
    is_first_check = state_store.is_first_check()

    # Show recap
    if not is_first_check and not json_output:
        days_since = state_store.days_since_last_check()
        if days_since and days_since >= 7:
            Celebrations.welcome_back(days_since)

    # Pull any missing goldens from cloud before checking locally
    _cloud_pull(store)

    # Verify snapshots exist
    goldens = store.list_golden()
    if not goldens:
        if not json_output:
            Celebrations.no_snapshot_found()
        sys.exit(1)

    # Show status message
    if not json_output:
        console.print(f"[cyan]▶ {get_random_checking_message()}[/cyan]\n")

    # Load test cases
    loader = TestCaseLoader()
    try:
        test_cases = loader.load_from_directory(Path(test_path))
    except Exception as e:
        console.print(f"[red]❌ Failed to load test cases: {e}[/red]\n")
        sys.exit(1)

    # Filter to specific test if requested
    if test:
        test_cases = [tc for tc in test_cases if tc.name == test]
        if not test_cases:
            console.print(f"[red]❌ No test found with name: {test}[/red]\n")
            sys.exit(1)

    # Load config
    config = _load_config_if_exists()

    # Apply judge config from config.yaml (env vars / CLI flags take priority)
    from evalview.core.config import apply_judge_config
    apply_judge_config(config)

    # Resolve semantic diff: explicit flag > config file > auto-enable.
    from evalview.core.semantic_diff import SemanticDiff
    key_available = SemanticDiff.is_available()

    if semantic_diff is None:
        config_setting = config.get_diff_config().semantic_diff_enabled if config else None
        if config_setting is False:
            semantic_diff = False
        else:
            semantic_diff = key_available
        if semantic_diff and not json_output:
            state_for_notice = state_store.load()
            if not state_for_notice.semantic_auto_noticed:
                console.print(
                    "[dim]ℹ  Semantic diff auto-enabled (OPENAI_API_KEY detected). "
                    f"{SemanticDiff.cost_notice()}. "
                    "Use --no-semantic-diff to opt out.[/dim]\n"
                )
                state_for_notice.semantic_auto_noticed = True
                state_store.save(state_for_notice)
    elif semantic_diff and not key_available:
        if not json_output:
            console.print(
                "[yellow]⚠  --semantic-diff requested but OPENAI_API_KEY is not set. "
                "Falling back to lexical comparison.[/yellow]\n"
            )
        semantic_diff = False

    # Dry-run mode — show plan and exit
    if dry_run:
        golden_names = {golden.test_name for golden in goldens}
        tests_with_baselines = sum(1 for tc in test_cases if tc.name in golden_names)
        if not json_output:
            console.print(f"  Tests:          {len(test_cases)}")
            console.print(f"  With baselines: {tests_with_baselines}")
            console.print(f"  API calls:      ~{len(test_cases)} (agent) + ~{len(test_cases)} (judge)")
            if budget is not None:
                console.print(f"  Budget:         ${budget:.2f}")
            console.print()
            console.print("[dim]No API calls were made. Remove --dry-run to execute.[/dim]\n")
        else:
            print(json.dumps({"dry_run": True, "tests": len(test_cases), "with_baselines": tests_with_baselines}))
        sys.exit(0)

    # Execute tests and compare against golden
    diffs, results, drift_tracker, golden_traces = _execute_check_tests(test_cases, config, json_output, semantic_diff, timeout)

    # Analyze diffs
    analysis = _analyze_check_diffs(diffs)

    # Update project state
    state = state_store.update_check(
        has_regressions=(not analysis["all_passed"]),
        status="passed" if analysis["all_passed"] else "regression"
    )

    # Cost summary
    if results and not json_output:
        total_cost = sum(r.trace.metrics.total_cost for r in results)
        total_api_calls = sum(len(r.trace.steps) for r in results)
        console.print(
            f"[dim]💰 {len(results)} tests, {total_api_calls} API calls, "
            f"${total_cost:.4f} total[/dim]\n"
        )
        if budget is not None and total_cost > budget:
            console.print(
                f"[red]⚠  Budget exceeded: ${total_cost:.4f} > ${budget:.2f} limit[/red]\n"
            )
            sys.exit(1)

    # AI root cause enrichment (opt-in)
    ai_root_causes = None
    if ai_root_cause and not analysis["all_passed"]:
        import asyncio
        from evalview.core.root_cause import enrich_diffs_with_ai
        if not json_output:
            console.print("[dim]🤖 Running AI root cause analysis...[/dim]\n")
        ai_root_causes = asyncio.run(enrich_diffs_with_ai(diffs))

    # Display results
    _display_check_results(
        diffs, analysis, state, is_first_check, json_output,
        drift_tracker=drift_tracker,
        golden_traces=golden_traces,
        results=results,
        ai_root_causes=ai_root_causes,
    )

    # Generate HTML report if requested
    if report_path and results:
        from evalview.visualization import generate_visual_report
        diff_list = [d for _, d in diffs]
        path = generate_visual_report(
            results=results,
            diffs=diff_list,
            golden_traces=golden_traces,
            output_path=report_path,
            auto_open=not json_output,
            title="EvalView Check Report",
        )
        if not json_output:
            console.print(f"[green]◈ Report:[/green] {path}\n")

    # Export results to CSV if requested
    if csv_path and diffs:
        result_lookup: Dict[str, "EvaluationResult"] = {}
        if results:
            for r in results:
                result_lookup[r.test_case] = r

        timestamp = datetime.now(timezone.utc).isoformat()
        csv_file_path = Path(csv_path)
        with open(csv_file_path, "w", newline="") as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(["test_name", "status", "score", "baseline_score", "diff", "timestamp"])
            for name, diff in diffs:
                current_result = result_lookup.get(name)
                current_score: Any = current_result.score if current_result else ""
                baseline_score: Any = (current_result.score - diff.score_diff) if current_result and diff.score_diff is not None else ""
                score_diff = diff.score_diff if diff.score_diff is not None else ""
                writer.writerow([
                    name,
                    diff.overall_severity.value,
                    current_score,
                    baseline_score,
                    score_diff,
                    timestamp,
                ])
        if not json_output:
            console.print(f"[green]◈ CSV exported:[/green] {csv_file_path}\n")

    # Compute and exit with code
    exit_code = _compute_check_exit_code(diffs, fail_on, strict)
    sys.exit(exit_code)


@click.command("replay")
@click.argument("test_name")
@click.option("--test-path", "test_path", default="tests", type=click.Path(exists=True), help="Directory containing tests")
@click.option("--no-browser", is_flag=True, help="Don't auto-open the HTML report")
@track_command("replay")
def replay(test_name: str, test_path: str, no_browser: bool) -> None:
    """Replay a test and show full trajectory diff vs baseline.

    Shows step-by-step what your agent did vs. the saved baseline.
    Opens an HTML report with side-by-side sequence diagrams.

    \b
    Examples:
        evalview replay my-test
        evalview replay my-test --no-browser
        evalview replay my-test --test-path ./my-tests
    """
    from evalview.core.loader import TestCaseLoader
    from evalview.core.golden import GoldenStore
    from evalview.visualization import generate_visual_report

    store = GoldenStore()
    _cloud_pull(store)

    golden_variants = store.load_all_golden_variants(test_name)
    if not golden_variants:
        console.print(f"\n[red]❌ No baseline found for '{test_name}'[/red]")
        quoted = f'"{test_name}"' if " " in test_name else test_name
        console.print(f"[dim]Run: evalview snapshot --test {quoted}[/dim]\n")
        sys.exit(1)

    loader = TestCaseLoader()
    try:
        test_cases = loader.load_from_directory(Path(test_path))
    except Exception as e:
        console.print(f"\n[red]❌ Failed to load test cases: {e}[/red]\n")
        sys.exit(1)

    matching = [tc for tc in test_cases if tc.name == test_name]
    if not matching:
        console.print(f"\n[red]❌ No test case found with name: {test_name}[/red]")
        console.print(f"[dim]Available: {', '.join(tc.name for tc in test_cases) or 'none'}[/dim]\n")
        sys.exit(1)

    config = _load_config_if_exists()

    console.print(f"\n[cyan]◈ Replaying '{test_name}'...[/cyan]\n")

    diffs, results, _, _ = _execute_check_tests([matching[0]], config, json_output=False)

    if not results:
        console.print("[red]❌ Test execution failed — check your agent is running[/red]\n")
        sys.exit(1)

    result = results[0]
    golden = golden_variants[0]  # Primary baseline

    # Terminal: side-by-side step comparison
    _print_trajectory_diff(golden, result)

    # Diff summary
    if diffs:
        _, diff = diffs[0]
        from evalview.core.diff import DiffStatus
        status_display = {
            DiffStatus.PASSED: "[green]PASSED[/green]",
            DiffStatus.TOOLS_CHANGED: "[yellow]TOOLS_CHANGED[/yellow]",
            DiffStatus.OUTPUT_CHANGED: "[dim]OUTPUT_CHANGED[/dim]",
            DiffStatus.REGRESSION: "[red]REGRESSION[/red]",
        }.get(diff.overall_severity, str(diff.overall_severity))
        console.print(f"Status: {status_display}  |  {diff.summary()}\n")

    # Generate HTML report with side-by-side Mermaid trajectories
    golden_traces_dict = {test_name: golden}
    diff_list = [d for _, d in diffs]

    path = generate_visual_report(
        results=results,
        diffs=diff_list,
        golden_traces=golden_traces_dict,
        auto_open=not no_browser,
        title=f"Replay: {test_name}",
    )

    console.print(f"[green]◈ Report:[/green] {path}\n")
