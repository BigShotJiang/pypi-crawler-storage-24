import argparse
import inspect
import sys

from .config import add_client_arguments
from .errors import CLIError
from .registry import discover_project_callables, discover_public_commands
from .resolver import import_dotted_path
from .runtime import login, logout, run_project_call, run_public_command
from .serialization import parse_cli_value, parse_json_input, render_output
from .settings import (
    DEVELOPER_MODE_CONFIRMATION,
    DEVELOPER_MODE_WARNING,
    ProjectSettings,
    ensure_developer_mode_enabled,
    find_project_root,
    get_settings_path,
    load_project_settings,
    save_project_settings,
)


MISSING = object()


def _add_output_argument(parser):
    parser.add_argument(
        "--output",
        choices=("text", "json"),
        default="text",
        help="Output format",
    )


def _add_json_arguments(parser, flag_prefix="", dest_prefix=None):
    dest_prefix = flag_prefix if dest_prefix is None else dest_prefix
    parser.add_argument(
        "--{}args-json".format(flag_prefix),
        dest="{}args_json".format(dest_prefix),
    )
    parser.add_argument(
        "--{}args-file".format(flag_prefix),
        dest="{}args_file".format(dest_prefix),
    )
    parser.add_argument(
        "--{}kwargs-json".format(flag_prefix),
        dest="{}kwargs_json".format(dest_prefix),
    )
    parser.add_argument(
        "--{}kwargs-file".format(flag_prefix),
        dest="{}kwargs_file".format(dest_prefix),
    )


def _load_call_arguments(namespace, prefix=""):
    args = parse_json_input(
        getattr(namespace, "{}args_json".format(prefix)),
        getattr(namespace, "{}args_file".format(prefix)),
        default=[],
    )
    kwargs = parse_json_input(
        getattr(namespace, "{}kwargs_json".format(prefix)),
        getattr(namespace, "{}kwargs_file".format(prefix)),
        default={},
    )

    if not isinstance(args, list):
        raise CLIError("{}args payload must decode to a list".format(prefix))
    if not isinstance(kwargs, dict):
        raise CLIError("{}kwargs payload must decode to an object".format(prefix))
    return args, kwargs


def _iter_signature_parameters(signature):
    for param in signature.parameters.values():
        if param.name in ("self", "cls"):
            continue
        if param.kind not in (
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
            inspect.Parameter.KEYWORD_ONLY,
        ):
            continue
        yield param


def _merge_flag_arguments(namespace, kwargs, parameter_names):
    for name in parameter_names:
        value = getattr(namespace, "param_{}".format(name))
        if value is not MISSING:
            kwargs[name] = value


def _handle_public_command(namespace):
    args, kwargs = _load_call_arguments(namespace)
    _merge_flag_arguments(namespace, kwargs, namespace.parameter_names)
    return run_public_command(namespace, namespace.public_command, args, kwargs)


def _handle_call(namespace):
    ensure_developer_mode_enabled("call")
    target = import_dotted_path(namespace.target, project_only=True)
    args, kwargs = _load_call_arguments(namespace)
    init_args, init_kwargs = _load_call_arguments(namespace, prefix="init_")
    return run_project_call(
        namespace,
        target,
        method_name=namespace.method,
        init_args=init_args,
        init_kwargs=init_kwargs,
        args=args,
        kwargs=kwargs,
        client_invoke=namespace.client_invoke,
    )


def _handle_registry_public(_namespace):
    return [
        {
            "group": command.group,
            "command": command.cli_name,
            "method": command.name,
            "path": command.dotted_path,
        }
        for command in discover_public_commands()
    ]


def _handle_auth_login(namespace):
    return login(namespace)


def _handle_auth_logout(namespace):
    return logout(namespace)


def _project_settings_payload(settings):
    return {
        "project_root": str(find_project_root()),
        "settings_path": str(get_settings_path()),
        "developer_mode": settings.developer_mode,
    }


def _confirm_developer_mode_enable(namespace):
    if namespace.accept_dangerous_features:
        return

    if not sys.stdin.isatty():
        raise CLIError(
            "Enabling developer mode requires explicit confirmation with "
            "--accept-dangerous-features. {}".format(DEVELOPER_MODE_WARNING)
        )

    print(DEVELOPER_MODE_WARNING, file=sys.stderr)
    print(
        "Type '{}' to continue: ".format(DEVELOPER_MODE_CONFIRMATION),
        file=sys.stderr,
        end="",
    )
    response = sys.stdin.readline().strip()
    if response != DEVELOPER_MODE_CONFIRMATION:
        raise CLIError("Developer mode was not enabled")


def _handle_settings_show(_namespace):
    return _project_settings_payload(load_project_settings())


def _handle_settings_developer_mode(namespace):
    current = load_project_settings()
    if namespace.enable and current.developer_mode:
        return _project_settings_payload(current)

    if namespace.enable:
        _confirm_developer_mode_enable(namespace)
        settings = ProjectSettings(developer_mode=True)
    else:
        settings = ProjectSettings(developer_mode=False)

    save_project_settings(settings)
    return _project_settings_payload(settings)


def _handle_registry_project(namespace):
    ensure_developer_mode_enabled("registry project")
    records = discover_project_callables()
    if namespace.prefix:
        records = [record for record in records if record.dotted_path.startswith(namespace.prefix)]
    output = []
    for record in records:
        item = {
            "path": record.dotted_path,
            "kind": record.kind,
        }
        if record.method_name:
            item["method"] = record.method_name
        output.append(item)
    return output


def build_parser():
    parser = argparse.ArgumentParser(prog="telethon-cli")
    subparsers = parser.add_subparsers(dest="command")

    public_commands = discover_public_commands()
    grouped = {}
    for command in public_commands:
        grouped.setdefault(command.group, []).append(command)

    for group, commands in grouped.items():
        group_parser = subparsers.add_parser(group, help="{} commands".format(group))
        group_subparsers = group_parser.add_subparsers(dest="{}_command".format(group))
        for command in commands:
            command_parser = group_subparsers.add_parser(
                command.cli_name,
                help=command.summary or command.name,
                description=command.summary or command.dotted_path,
            )
            add_client_arguments(command_parser)
            _add_output_argument(command_parser)
            _add_json_arguments(command_parser)

            parameter_names = []
            for param in _iter_signature_parameters(command.signature):
                parameter_names.append(param.name)
                command_parser.add_argument(
                    "--{}".format(param.name.replace("_", "-")),
                    dest="param_{}".format(param.name),
                    default=MISSING,
                    type=parse_cli_value,
                )

            command_parser.set_defaults(
                handler=_handle_public_command,
                public_command=command,
                parameter_names=tuple(parameter_names),
            )

    call_parser = subparsers.add_parser("call", help="Invoke any telethon/telethon_generator callable")
    call_parser.add_argument("target", help="Dotted path under telethon or telethon_generator")
    call_parser.add_argument("--method", help="Method name when the target is a class")
    call_parser.add_argument(
        "--client-invoke",
        action="store_true",
        help="Instantiate/call the target and invoke the result through TelegramClient",
    )
    add_client_arguments(call_parser)
    _add_output_argument(call_parser)
    _add_json_arguments(call_parser)
    _add_json_arguments(call_parser, flag_prefix="init-", dest_prefix="init_")
    call_parser.set_defaults(handler=_handle_call)

    registry_parser = subparsers.add_parser("registry", help="Inspect discovered CLI coverage")
    _add_output_argument(registry_parser)
    registry_subparsers = registry_parser.add_subparsers(dest="registry_command")

    public_parser = registry_subparsers.add_parser("public", help="List public TelegramClient commands")
    _add_output_argument(public_parser)
    public_parser.set_defaults(handler=_handle_registry_public)

    project_parser = registry_subparsers.add_parser("project", help="List discovered project callables")
    _add_output_argument(project_parser)
    project_parser.add_argument("--prefix", help="Filter dotted paths by prefix")
    project_parser.set_defaults(handler=_handle_registry_project)

    login_parser = subparsers.add_parser("login", help="Create or refresh a Telegram session")
    add_client_arguments(login_parser)
    _add_output_argument(login_parser)
    login_parser.set_defaults(handler=_handle_auth_login)

    logout_parser = subparsers.add_parser("logout", help="Log out and remove the saved Telegram session")
    add_client_arguments(logout_parser)
    _add_output_argument(logout_parser)
    logout_parser.set_defaults(handler=_handle_auth_logout)

    settings_parser = subparsers.add_parser("settings", help="Manage project settings")
    settings_subparsers = settings_parser.add_subparsers(dest="settings_command")

    settings_show_parser = settings_subparsers.add_parser("show", help="Show project settings")
    _add_output_argument(settings_show_parser)
    settings_show_parser.set_defaults(handler=_handle_settings_show)

    developer_mode_parser = settings_subparsers.add_parser(
        "developer-mode",
        help="Enable or disable project-wide developer mode",
    )
    _add_output_argument(developer_mode_parser)
    action_group = developer_mode_parser.add_mutually_exclusive_group(required=True)
    action_group.add_argument("--enable", action="store_true", help="Enable developer mode")
    action_group.add_argument("--disable", action="store_true", help="Disable developer mode")
    developer_mode_parser.add_argument(
        "--accept-dangerous-features",
        action="store_true",
        help="Confirm that you understand developer mode enables dangerous features",
    )
    developer_mode_parser.set_defaults(handler=_handle_settings_developer_mode)

    return parser


def main(argv=None):
    parser = build_parser()
    namespace = parser.parse_args(argv)
    if not hasattr(namespace, "handler"):
        parser.print_help(sys.stderr)
        return 1

    try:
        result = namespace.handler(namespace)
    except CLIError as exc:
        print(str(exc), file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        print("Interrupted", file=sys.stderr)
        return 130

    output = render_output(result, getattr(namespace, "output", "text"))
    if output:
        print(output)
    return 0
