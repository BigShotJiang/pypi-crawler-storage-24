import ast
import importlib
import importlib.util
import inspect
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path


PUBLIC_GROUP_SPECS = (
    ("auth", "telethon.client.auth", "AuthMethods"),
    ("base", "telethon.client.telegrambaseclient", "TelegramBaseClient"),
    ("messages", "telethon.client.messages", "MessageMethods"),
    ("uploads", "telethon.client.uploads", "UploadMethods"),
    ("downloads", "telethon.client.downloads", "DownloadMethods"),
    ("dialogs", "telethon.client.dialogs", "DialogMethods"),
    ("users", "telethon.client.users", "UserMethods"),
    ("chats", "telethon.client.chats", "ChatMethods"),
    ("updates", "telethon.client.updates", "UpdateMethods"),
    ("bots", "telethon.client.bots", "BotMethods"),
    ("buttons", "telethon.client.buttons", "ButtonMethods"),
    ("account", "telethon.client.account", "AccountMethods"),
)


@dataclass(frozen=True)
class PublicCommand:
    group: str
    name: str
    cli_name: str
    dotted_path: str
    signature: inspect.Signature
    summary: str


@dataclass(frozen=True)
class CallableRecord:
    dotted_path: str
    kind: str
    method_name: str = None


def _summary(obj):
    doc = inspect.getdoc(obj) or ""
    return doc.splitlines()[0] if doc else ""


@lru_cache(maxsize=1)
def discover_public_commands():
    commands = []
    for group, module_name, class_name in PUBLIC_GROUP_SPECS:
        module = importlib.import_module(module_name)
        cls = getattr(module, class_name)
        for name, member in cls.__dict__.items():
            if name.startswith("_"):
                continue
            if isinstance(member, property):
                continue
            if not callable(member):
                continue

            commands.append(
                PublicCommand(
                    group=group,
                    name=name,
                    cli_name=name.replace("_", "-"),
                    dotted_path="{}.{}.{}".format(module_name, class_name, name),
                    signature=inspect.signature(member),
                    summary=_summary(member),
                )
            )
    return tuple(commands)


def _package_dir(package_name):
    module = importlib.import_module(package_name)
    return Path(module.__file__).resolve().parent


def _module_name(package_name, package_dir, file_path):
    relative = file_path.relative_to(package_dir).with_suffix("")
    if relative.name == "__init__":
        parts = relative.parts[:-1]
    else:
        parts = relative.parts
    if not parts:
        return package_name
    return ".".join((package_name,) + parts)


@lru_cache(maxsize=1)
def discover_project_callables():
    records = []
    for package_name in ("telethon", "telethon_generator"):
        if importlib.util.find_spec(package_name) is None:
            continue
        package_dir = _package_dir(package_name)
        for file_path in sorted(package_dir.rglob("*.py")):
            tree = ast.parse(file_path.read_text(encoding="utf-8"))
            module_name = _module_name(package_name, package_dir, file_path)
            for node in tree.body:
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    records.append(CallableRecord(
                        dotted_path="{}.{}".format(module_name, node.name),
                        kind="function",
                    ))
                elif isinstance(node, ast.ClassDef):
                    records.append(CallableRecord(
                        dotted_path="{}.{}".format(module_name, node.name),
                        kind="class",
                    ))
                    for child in node.body:
                        if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
                            records.append(CallableRecord(
                                dotted_path="{}.{}".format(module_name, node.name),
                                kind="method",
                                method_name=child.name,
                            ))
    return tuple(records)
