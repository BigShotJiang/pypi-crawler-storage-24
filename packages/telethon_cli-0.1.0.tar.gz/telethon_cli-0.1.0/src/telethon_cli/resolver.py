import importlib

from .errors import CLIError


PROJECT_ROOT_PREFIXES = ("telethon", "telethon_generator")


def is_project_path(path):
    return any(path == prefix or path.startswith(prefix + ".") for prefix in PROJECT_ROOT_PREFIXES)


def import_dotted_path(path, *, project_only=False):
    if project_only and not is_project_path(path):
        raise CLIError(
            "Target '{}' must live under telethon or telethon_generator".format(path)
        )

    parts = path.split(".")
    for index in range(len(parts), 0, -1):
        module_name = ".".join(parts[:index])
        try:
            module = importlib.import_module(module_name)
        except ModuleNotFoundError as exc:
            if exc.name != module_name and not module_name.startswith(exc.name + "."):
                raise CLIError("Failed to import '{}': {}".format(module_name, exc)) from exc
            continue
        except Exception as exc:
            raise CLIError("Failed to import '{}': {}".format(module_name, exc)) from exc

        target = module
        for attr in parts[index:]:
            try:
                target = getattr(target, attr)
            except AttributeError as exc:
                raise CLIError("Dotted path '{}' has no attribute '{}'".format(path, attr)) from exc
        return target

    raise CLIError("Unable to resolve dotted path '{}'".format(path))
