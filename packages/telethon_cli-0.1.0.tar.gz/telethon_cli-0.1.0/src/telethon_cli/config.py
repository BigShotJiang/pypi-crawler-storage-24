from dataclasses import dataclass
import os
from pathlib import Path
import shlex

from .errors import CLIError
from .settings import find_project_root


ENV_API_ID = "TELETHON_API_ID"
ENV_API_HASH = "TELETHON_API_HASH"
ENV_SESSION = "TELETHON_SESSION"
ENV_PASSWORD = "TELETHON_PASSWORD"
SUPPORTED_ENV_KEYS = (ENV_API_ID, ENV_API_HASH, ENV_SESSION, ENV_PASSWORD)
DEFAULT_ENV_FILE_NAME = ".env"
DEFAULT_SESSION_DIR_NAME = ".telethon-cli"
DEFAULT_SESSION_FILE_NAME = "session"


@dataclass(frozen=True)
class ClientConfig:
    api_id: int
    api_hash: str
    session: str
    password: str = None


def add_client_arguments(parser):
    parser.add_argument("--api-id", dest="api_id", type=int, help="Telegram API ID")
    parser.add_argument("--api-hash", dest="api_hash", help="Telegram API hash")
    parser.add_argument("--session", dest="session", help="Telethon session name or path")
    parser.add_argument("--2fa-password", dest="password", help="Telegram 2FA password")
    parser.add_argument(
        "--env-file",
        dest="env_file",
        help="Path to a dotenv file with Telethon credentials",
    )


def _strip_inline_comment(raw_value):
    in_single = False
    in_double = False
    escaped = False

    for index, char in enumerate(raw_value):
        if escaped:
            escaped = False
            continue
        if char == "\\":
            escaped = True
            continue
        if char == "'" and not in_double:
            in_single = not in_single
            continue
        if char == '"' and not in_single:
            in_double = not in_double
            continue
        if char == "#" and not in_single and not in_double:
            if index == 0 or raw_value[index - 1].isspace():
                return raw_value[:index].rstrip()
    return raw_value.strip()


def _parse_dotenv_value(raw_value, path, line_number):
    value = _strip_inline_comment(raw_value).strip()
    if not value:
        return ""

    if value[0] in ("'", '"'):
        try:
            parsed = shlex.split(value, posix=True)
        except ValueError as exc:
            raise CLIError(
                "Invalid dotenv value for line {} in '{}': {}".format(line_number, path, exc)
            ) from exc
        if len(parsed) != 1:
            raise CLIError(
                "Invalid dotenv value for line {} in '{}': {}".format(
                    line_number,
                    path,
                    raw_value.strip(),
                )
            )
        return parsed[0]

    return value


def _load_dotenv_file(path):
    values = {}
    try:
        content = path.read_text(encoding="utf-8")
    except OSError as exc:
        raise CLIError("Unable to read env file '{}': {}".format(path, exc)) from exc

    for line_number, raw_line in enumerate(content.splitlines(), start=1):
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in raw_line:
            raise CLIError("Invalid dotenv line {} in '{}': {}".format(line_number, path, raw_line))

        key, raw_value = raw_line.split("=", 1)
        key = key.strip()
        if key.startswith("export "):
            key = key[len("export "):].strip()
        if not key:
            raise CLIError("Invalid dotenv line {} in '{}': {}".format(line_number, path, raw_line))
        if key not in SUPPORTED_ENV_KEYS:
            continue
        values[key] = _parse_dotenv_value(raw_value, path, line_number)

    return values


def _resolve_env_file(namespace):
    explicit_path = getattr(namespace, "env_file", None)
    if explicit_path:
        path = Path(explicit_path).expanduser()
        if not path.is_absolute():
            path = Path.cwd() / path
        path = path.resolve()
        if not path.exists():
            raise CLIError("Env file '{}' does not exist".format(path))
        if path.is_dir():
            raise CLIError("Env file '{}' must be a file".format(path))
        return path

    candidates = []
    cwd_path = (Path.cwd() / DEFAULT_ENV_FILE_NAME).resolve()
    candidates.append(cwd_path)

    project_root_path = (find_project_root() / DEFAULT_ENV_FILE_NAME).resolve()
    if project_root_path not in candidates:
        candidates.append(project_root_path)

    for candidate in candidates:
        if candidate.exists() and candidate.is_file():
            return candidate
    return None


def _merge_environment(environ, dotenv_values, dotenv_path):
    merged = dict(environ)
    conflicts = []

    for key, dotenv_value in dotenv_values.items():
        env_value = environ.get(key)
        if env_value is None:
            merged[key] = dotenv_value
            continue
        if env_value != dotenv_value:
            conflicts.append("{} (environment vs {})".format(key, dotenv_path))

    if conflicts:
        raise CLIError(
            "Conflicting Telethon client config values: {}".format(", ".join(conflicts))
        )

    return merged


def _default_session_path(start_path=None):
    project_root = find_project_root(start_path)
    return project_root / DEFAULT_SESSION_DIR_NAME / DEFAULT_SESSION_FILE_NAME


def load_client_config(namespace, environ=None):
    environ = os.environ if environ is None else environ
    dotenv_path = _resolve_env_file(namespace)
    if dotenv_path is not None:
        environ = _merge_environment(environ, _load_dotenv_file(dotenv_path), dotenv_path)

    api_id = namespace.api_id if getattr(namespace, "api_id", None) is not None else environ.get(ENV_API_ID)
    api_hash = namespace.api_hash if getattr(namespace, "api_hash", None) is not None else environ.get(ENV_API_HASH)
    session = namespace.session if getattr(namespace, "session", None) is not None else environ.get(ENV_SESSION)
    password = namespace.password if getattr(namespace, "password", None) is not None else environ.get(ENV_PASSWORD)

    missing = []
    if api_id in (None, ""):
        missing.append(ENV_API_ID)
    if not api_hash:
        missing.append(ENV_API_HASH)
    if missing:
        raise CLIError("Missing Telethon client config: {}".format(", ".join(missing)))

    try:
        api_id = int(api_id)
    except (TypeError, ValueError) as exc:
        raise CLIError("{} must be an integer".format(ENV_API_ID)) from exc

    if not session:
        session = str(_default_session_path())

    return ClientConfig(api_id=api_id, api_hash=api_hash, session=session, password=password)
