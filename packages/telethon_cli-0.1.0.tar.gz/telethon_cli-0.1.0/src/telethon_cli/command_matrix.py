from dataclasses import dataclass


MODE_LIVE_SAFE = "live-safe"
MODE_LIVE_DISPOSABLE = "live-disposable"
MODE_MOCKED = "mocked"
MODE_EXCLUDED_LIVE = "excluded-live"
LIVE_MODES = frozenset({MODE_LIVE_SAFE, MODE_LIVE_DISPOSABLE})
NON_LIVE_MODES = frozenset({MODE_MOCKED, MODE_EXCLUDED_LIVE})


@dataclass(frozen=True)
class CommandTestSpec:
    group: str
    cli_name: str
    mode: str
    fixture: str
    cleanup: str
    reason: str = ""

    @property
    def key(self):
        return (self.group, self.cli_name)

    @property
    def method_name(self):
        return self.cli_name.replace("-", "_")


def _spec(group, cli_name, mode, fixture, cleanup, reason=""):
    return CommandTestSpec(
        group=group,
        cli_name=cli_name,
        mode=mode,
        fixture=fixture,
        cleanup=cleanup,
        reason=reason,
    )


PUBLIC_COMMAND_MATRIX = (
    _spec("auth", "start", MODE_EXCLUDED_LIVE, "none", "none", "auth-state-change"),
    _spec("auth", "sign-in", MODE_EXCLUDED_LIVE, "none", "none", "auth-state-change"),
    _spec("auth", "sign-up", MODE_EXCLUDED_LIVE, "none", "none", "auth-state-change"),
    _spec("auth", "send-code-request", MODE_EXCLUDED_LIVE, "none", "none", "auth-state-change"),
    _spec("auth", "qr-login", MODE_EXCLUDED_LIVE, "none", "none", "auth-state-change"),
    _spec("auth", "log-out", MODE_EXCLUDED_LIVE, "none", "none", "auth-state-change"),
    _spec("auth", "edit-2fa", MODE_EXCLUDED_LIVE, "none", "none", "security-state-change"),
    _spec("base", "connect", MODE_LIVE_SAFE, "none", "none"),
    _spec("base", "is-connected", MODE_LIVE_SAFE, "none", "none"),
    _spec("base", "disconnect", MODE_LIVE_SAFE, "none", "none"),
    _spec("base", "set-proxy", MODE_MOCKED, "none", "none", "local-network-config"),
    _spec("messages", "iter-messages", MODE_LIVE_SAFE, "me", "none"),
    _spec("messages", "get-messages", MODE_LIVE_SAFE, "me", "none"),
    _spec("messages", "send-message", MODE_LIVE_DISPOSABLE, "me", "delete-created-message"),
    _spec("messages", "forward-messages", MODE_LIVE_DISPOSABLE, "disposable-message", "delete-created-message"),
    _spec("messages", "edit-message", MODE_LIVE_DISPOSABLE, "disposable-message", "none"),
    _spec("messages", "delete-messages", MODE_LIVE_DISPOSABLE, "disposable-message", "handled-in-command"),
    _spec("messages", "send-read-acknowledge", MODE_LIVE_DISPOSABLE, "disposable-message", "none"),
    _spec("messages", "pin-message", MODE_LIVE_DISPOSABLE, "disposable-message", "restore-unpinned-state"),
    _spec("messages", "unpin-message", MODE_LIVE_DISPOSABLE, "disposable-message", "none"),
    _spec("uploads", "send-file", MODE_LIVE_DISPOSABLE, "temp-file", "delete-created-message"),
    _spec("uploads", "upload-file", MODE_LIVE_DISPOSABLE, "temp-file", "delete-temp-file"),
    _spec("downloads", "download-profile-photo", MODE_LIVE_DISPOSABLE, "me", "delete-temp-file"),
    _spec("downloads", "download-media", MODE_MOCKED, "none", "none", "requires-message-object"),
    _spec("downloads", "download-file", MODE_MOCKED, "none", "none", "requires-input-location"),
    _spec("downloads", "iter-download", MODE_MOCKED, "none", "none", "requires-input-location"),
    _spec("dialogs", "iter-dialogs", MODE_LIVE_SAFE, "none", "none"),
    _spec("dialogs", "get-dialogs", MODE_LIVE_SAFE, "none", "none"),
    _spec("dialogs", "iter-drafts", MODE_LIVE_SAFE, "me", "none"),
    _spec("dialogs", "get-drafts", MODE_LIVE_SAFE, "me", "none"),
    _spec("dialogs", "edit-folder", MODE_EXCLUDED_LIVE, "none", "none", "mutates-dialog-state"),
    _spec("dialogs", "delete-dialog", MODE_EXCLUDED_LIVE, "none", "none", "destructive-dialog-state"),
    _spec("dialogs", "conversation", MODE_MOCKED, "none", "none", "interactive-conversation-loop"),
    _spec("users", "get-me", MODE_LIVE_SAFE, "none", "none"),
    _spec("users", "is-bot", MODE_LIVE_SAFE, "none", "none"),
    _spec("users", "is-user-authorized", MODE_LIVE_SAFE, "none", "none"),
    _spec("users", "get-entity", MODE_LIVE_SAFE, "me", "none"),
    _spec("users", "get-input-entity", MODE_LIVE_SAFE, "me", "none"),
    _spec("users", "get-peer-id", MODE_LIVE_SAFE, "me", "none"),
    _spec("chats", "iter-participants", MODE_MOCKED, "none", "none", "requires-chat-fixture"),
    _spec("chats", "get-participants", MODE_MOCKED, "none", "none", "requires-chat-fixture"),
    _spec("chats", "iter-admin-log", MODE_MOCKED, "none", "none", "requires-admin-chat"),
    _spec("chats", "get-admin-log", MODE_MOCKED, "none", "none", "requires-admin-chat"),
    _spec("chats", "iter-profile-photos", MODE_MOCKED, "none", "none", "requires-peer-fixture"),
    _spec("chats", "get-profile-photos", MODE_MOCKED, "none", "none", "requires-peer-fixture"),
    _spec("chats", "action", MODE_MOCKED, "none", "none", "ephemeral-side-effect"),
    _spec("chats", "edit-admin", MODE_EXCLUDED_LIVE, "none", "none", "mutates-admin-state"),
    _spec("chats", "edit-permissions", MODE_EXCLUDED_LIVE, "none", "none", "mutates-permissions-state"),
    _spec("chats", "kick-participant", MODE_EXCLUDED_LIVE, "none", "none", "destructive-membership-state"),
    _spec("chats", "get-permissions", MODE_MOCKED, "none", "none", "requires-chat-fixture"),
    _spec("chats", "get-stats", MODE_MOCKED, "none", "none", "requires-channel-stats"),
    _spec("updates", "set-receive-updates", MODE_MOCKED, "none", "none", "mutates-session-update-state"),
    _spec("updates", "run-until-disconnected", MODE_MOCKED, "none", "none", "long-running-loop"),
    _spec("updates", "on", MODE_MOCKED, "none", "none", "callback-registration"),
    _spec("updates", "add-event-handler", MODE_MOCKED, "none", "none", "callback-registration"),
    _spec("updates", "remove-event-handler", MODE_MOCKED, "none", "none", "callback-registration"),
    _spec("updates", "list-event-handlers", MODE_MOCKED, "none", "none", "callback-registration"),
    _spec("updates", "catch-up", MODE_MOCKED, "none", "none", "requires-update-queue"),
    _spec("bots", "inline-query", MODE_MOCKED, "none", "none", "requires-inline-bot"),
    _spec("buttons", "build-reply-markup", MODE_MOCKED, "none", "none", "pure-builder"),
    _spec("account", "takeout", MODE_EXCLUDED_LIVE, "none", "none", "account-export-state"),
    _spec("account", "end-takeout", MODE_EXCLUDED_LIVE, "none", "none", "account-export-state"),
)

PUBLIC_COMMAND_MATRIX_BY_KEY = {spec.key: spec for spec in PUBLIC_COMMAND_MATRIX}
