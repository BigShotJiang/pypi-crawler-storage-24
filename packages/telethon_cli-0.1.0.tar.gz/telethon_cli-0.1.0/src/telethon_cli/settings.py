import json
from dataclasses import dataclass
from pathlib import Path

from .errors import CLIError


SETTINGS_FILE_NAME = ".telethon-cli.json"
DEVELOPER_MODE_CONFIRMATION = "enable developer mode"
DEVELOPER_MODE_WARNING = (
    "Developer mode enables dangerous features, including internal callable "
    "dispatch and JSON materialization helpers. Enable it only if you "
    "understand and accept the risk."
)


@dataclass(frozen=True)
class ProjectSettings:
    developer_mode: bool = False


def find_project_root(start_path=None):
    current = Path.cwd() if start_path is None else Path(start_path)
    current = current.resolve()
    if current.is_file():
        current = current.parent

    for candidate in (current,) + tuple(current.parents):
        if (candidate / ".git").exists() or (candidate / "pyproject.toml").exists():
            return candidate
    return current


def get_settings_path(start_path=None):
    return find_project_root(start_path) / SETTINGS_FILE_NAME


def load_project_settings(start_path=None):
    path = get_settings_path(start_path)
    if not path.exists():
        return ProjectSettings()

    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except OSError as exc:
        raise CLIError("Unable to read settings file '{}': {}".format(path, exc)) from exc
    except json.JSONDecodeError as exc:
        raise CLIError("Invalid settings file '{}': {}".format(path, exc)) from exc

    if not isinstance(payload, dict):
        raise CLIError("Settings file '{}' must contain a JSON object".format(path))

    developer_mode = payload.get("developer_mode", False)
    if not isinstance(developer_mode, bool):
        raise CLIError("Setting 'developer_mode' in '{}' must be a boolean".format(path))

    return ProjectSettings(developer_mode=developer_mode)


def save_project_settings(settings, start_path=None):
    path = get_settings_path(start_path)
    payload = {
        "developer_mode": settings.developer_mode,
    }
    try:
        path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    except OSError as exc:
        raise CLIError("Unable to write settings file '{}': {}".format(path, exc)) from exc
    return path


def ensure_developer_mode_enabled(feature_name, start_path=None):
    settings = load_project_settings(start_path)
    if settings.developer_mode:
        return

    raise CLIError(
        "{} is disabled until developer mode is enabled in project settings. "
        "Run `telethon-cli settings developer-mode --enable "
        "--accept-dangerous-features` after reviewing the warning.".format(feature_name)
    )
