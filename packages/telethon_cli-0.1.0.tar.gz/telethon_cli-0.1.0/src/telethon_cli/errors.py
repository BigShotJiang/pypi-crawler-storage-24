class CLIError(Exception):
    """Raised for recoverable CLI errors."""
