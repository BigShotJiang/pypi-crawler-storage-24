import argparse
import json
import os
from dataclasses import dataclass, field
from pathlib import Path
import subprocess
import sys
import tempfile
import uuid

from .command_matrix import (
    LIVE_MODES,
    MODE_LIVE_DISPOSABLE,
    MODE_LIVE_SAFE,
    PUBLIC_COMMAND_MATRIX,
    PUBLIC_COMMAND_MATRIX_BY_KEY,
)


class LiveSmokeError(RuntimeError):
    pass


class LiveSmokeBlocked(LiveSmokeError):
    def __init__(self, reason, detail=""):
        super().__init__(detail or reason)
        self.reason = reason
        self.detail = detail or reason


@dataclass
class LiveContext:
    repo_root: Path
    temp_dir: Path
    run_id: str = field(default_factory=lambda: uuid.uuid4().hex[:10])
    primary_message_id: int = None
    forwarded_message_id: int = None
    file_message_id: int = None
    cleanup_message_ids: list = field(default_factory=list)
    temp_upload_path: Path = None


STATIC_LIVE_ARGS = {
    ("base", "connect"): ("base", "connect"),
    ("base", "is-connected"): ("base", "is-connected"),
    ("base", "disconnect"): ("base", "disconnect"),
    ("messages", "iter-messages"): ("messages", "iter-messages", "--entity", "me", "--limit", "1"),
    ("messages", "get-messages"): ("messages", "get-messages", "--entity", "me", "--limit", "1"),
    ("dialogs", "iter-dialogs"): ("dialogs", "iter-dialogs", "--limit", "3"),
    ("dialogs", "get-dialogs"): ("dialogs", "get-dialogs", "--limit", "3"),
    ("dialogs", "iter-drafts"): ("dialogs", "iter-drafts", "--entity", "me"),
    ("dialogs", "get-drafts"): ("dialogs", "get-drafts", "--entity", "me"),
    ("users", "get-me"): ("users", "get-me"),
    ("users", "is-bot"): ("users", "is-bot"),
    ("users", "is-user-authorized"): ("users", "is-user-authorized"),
    ("users", "get-entity"): ("users", "get-entity", "--entity", "me"),
    ("users", "get-input-entity"): ("users", "get-input-entity", "--peer", "me"),
    ("users", "get-peer-id"): ("users", "get-peer-id", "--peer", "me"),
}

LIVE_HANDLER_KEYS = frozenset(STATIC_LIVE_ARGS) | {
    ("messages", "send-message"),
    ("messages", "forward-messages"),
    ("messages", "edit-message"),
    ("messages", "delete-messages"),
    ("messages", "send-read-acknowledge"),
    ("messages", "pin-message"),
    ("messages", "unpin-message"),
    ("uploads", "send-file"),
    ("uploads", "upload-file"),
    ("downloads", "download-profile-photo"),
}


def _repo_root():
    return Path(__file__).resolve().parents[2]


def _cli_env(repo_root):
    env = os.environ.copy()
    source_root = str(repo_root / "src")
    existing = env.get("PYTHONPATH")
    env["PYTHONPATH"] = source_root if not existing else source_root + os.pathsep + existing
    return env


def _run_cli(repo_root, args):
    process = subprocess.run(
        [sys.executable, "-m", "telethon_cli", *args, "--output", "json"],
        cwd=repo_root,
        env=_cli_env(repo_root),
        text=True,
        capture_output=True,
    )
    stdout = process.stdout.strip()
    stderr = process.stderr.strip()
    if process.returncode != 0:
        raise LiveSmokeError(stderr or stdout or "Command failed")
    if not stdout:
        return None
    try:
        return json.loads(stdout)
    except json.JSONDecodeError as exc:
        raise LiveSmokeError("Invalid JSON output for {}: {}".format(" ".join(args), exc)) from exc


def _cleanup_messages(ctx, notes):
    if not ctx.cleanup_message_ids:
        return

    ids = sorted(set(ctx.cleanup_message_ids))
    try:
        _run_cli(
            ctx.repo_root,
            [
                "messages",
                "delete-messages",
                "--entity",
                "me",
                "--message-ids",
                json.dumps(ids),
            ],
        )
    except LiveSmokeError as exc:
        notes.append("cleanup: unable to delete messages {} ({})".format(ids, exc))


def _run_static_live_command(ctx, spec):
    return _run_cli(ctx.repo_root, list(STATIC_LIVE_ARGS[spec.key]))


def _ensure_temp_upload_file(ctx):
    if ctx.temp_upload_path is None:
        ctx.temp_upload_path = ctx.temp_dir / "upload.txt"
        ctx.temp_upload_path.write_text(
            "telethon-cli smoke {}\n".format(ctx.run_id),
            encoding="utf-8",
        )
    return ctx.temp_upload_path


def _run_send_message(ctx, _spec):
    result = _run_cli(
        ctx.repo_root,
        [
            "messages",
            "send-message",
            "--entity",
            "me",
            "--message",
            "[telethon-cli smoke {}] primary".format(ctx.run_id),
        ],
    )
    ctx.primary_message_id = result["id"]
    ctx.cleanup_message_ids.append(ctx.primary_message_id)
    return result


def _run_forward_messages(ctx, _spec):
    if ctx.primary_message_id is None:
        raise LiveSmokeError("forward-messages requires a disposable source message")
    result = _run_cli(
        ctx.repo_root,
        [
            "messages",
            "forward-messages",
            "--entity",
            "me",
            "--messages",
            str(ctx.primary_message_id),
            "--from-peer",
            "me",
        ],
    )
    if result:
        first = result[0]
        ctx.forwarded_message_id = first["id"]
        ctx.cleanup_message_ids.append(ctx.forwarded_message_id)
    return result


def _run_edit_message(ctx, _spec):
    if ctx.primary_message_id is None:
        raise LiveSmokeError("edit-message requires a disposable source message")
    return _run_cli(
        ctx.repo_root,
        [
            "messages",
            "edit-message",
            "--entity",
            "me",
            "--message",
            str(ctx.primary_message_id),
            "--text",
            "[telethon-cli smoke {}] edited".format(ctx.run_id),
        ],
    )


def _run_delete_messages(ctx, _spec):
    if ctx.primary_message_id is None:
        raise LiveSmokeError("delete-messages requires a disposable source message")
    result = _run_cli(
        ctx.repo_root,
        [
            "messages",
            "delete-messages",
            "--entity",
            "me",
            "--message-ids",
            json.dumps([ctx.primary_message_id]),
        ],
    )
    ctx.cleanup_message_ids = [message_id for message_id in ctx.cleanup_message_ids if message_id != ctx.primary_message_id]
    return result


def _run_send_read_acknowledge(ctx, _spec):
    if ctx.primary_message_id is None:
        raise LiveSmokeError("send-read-acknowledge requires a disposable source message")
    return _run_cli(
        ctx.repo_root,
        [
            "messages",
            "send-read-acknowledge",
            "--entity",
            "me",
            "--max-id",
            str(ctx.primary_message_id),
        ],
    )


def _run_pin_message(ctx, _spec):
    if ctx.primary_message_id is None:
        raise LiveSmokeError("pin-message requires a disposable source message")
    try:
        return _run_cli(
            ctx.repo_root,
            [
                "messages",
                "pin-message",
                "--entity",
                "me",
                "--message",
                str(ctx.primary_message_id),
            ],
        )
    except LiveSmokeError as exc:
        raise LiveSmokeBlocked("blocked-by-telegram", str(exc)) from exc


def _run_unpin_message(ctx, _spec):
    if ctx.primary_message_id is None:
        raise LiveSmokeError("unpin-message requires a disposable source message")
    try:
        return _run_cli(
            ctx.repo_root,
            [
                "messages",
                "unpin-message",
                "--entity",
                "me",
                "--message",
                str(ctx.primary_message_id),
            ],
        )
    except LiveSmokeError as exc:
        raise LiveSmokeBlocked("blocked-by-telegram", str(exc)) from exc


def _run_upload_file(ctx, _spec):
    upload_path = _ensure_temp_upload_file(ctx)
    return _run_cli(
        ctx.repo_root,
        [
            "uploads",
            "upload-file",
            "--file",
            str(upload_path),
        ],
    )


def _run_send_file(ctx, _spec):
    upload_path = _ensure_temp_upload_file(ctx)
    result = _run_cli(
        ctx.repo_root,
        [
            "uploads",
            "send-file",
            "--entity",
            "me",
            "--file",
            str(upload_path),
            "--caption",
            "[telethon-cli smoke {}] file".format(ctx.run_id),
        ],
    )
    ctx.file_message_id = result["id"]
    ctx.cleanup_message_ids.append(ctx.file_message_id)
    return result


def _run_download_profile_photo(ctx, _spec):
    result = _run_cli(
        ctx.repo_root,
        [
            "downloads",
            "download-profile-photo",
            "--entity",
            "me",
            "--file",
            str(ctx.temp_dir / "profile-photo"),
        ],
    )
    if result in (None, ""):
        raise LiveSmokeBlocked("blocked-no-profile-photo", "No profile photo was returned")
    return result


LIVE_HANDLERS = {
    ("messages", "send-message"): _run_send_message,
    ("messages", "forward-messages"): _run_forward_messages,
    ("messages", "edit-message"): _run_edit_message,
    ("messages", "delete-messages"): _run_delete_messages,
    ("messages", "send-read-acknowledge"): _run_send_read_acknowledge,
    ("messages", "pin-message"): _run_pin_message,
    ("messages", "unpin-message"): _run_unpin_message,
    ("uploads", "upload-file"): _run_upload_file,
    ("uploads", "send-file"): _run_send_file,
    ("downloads", "download-profile-photo"): _run_download_profile_photo,
}


def _run_live_spec(ctx, spec):
    if spec.key in STATIC_LIVE_ARGS:
        return _run_static_live_command(ctx, spec)
    return LIVE_HANDLERS[spec.key](ctx, spec)


def _render_text_summary(summary):
    lines = [
        "login: {}".format(summary["login"]["status"]),
        "passed: {}".format(summary["counts"]["passed"]),
        "blocked: {}".format(summary["counts"]["blocked"]),
        "skipped: {}".format(summary["counts"]["skipped"]),
        "failed: {}".format(summary["counts"]["failed"]),
    ]
    details = [result for result in summary["results"] if result["status"] != "passed"]
    if details:
        lines.append("details:")
        for item in details:
            line = "{} {} -> {}".format(item["group"], item["command"], item["status"])
            if item["detail"]:
                line += " ({})".format(item["detail"])
            lines.append(line)
    return "\n".join(lines)


def run_live_public_commands():
    repo_root = _repo_root()
    results = []
    counts = {
        "passed": 0,
        "blocked": 0,
        "skipped": 0,
        "failed": 0,
    }
    notes = []

    with tempfile.TemporaryDirectory(prefix="telethon-cli-smoke-", dir="/tmp") as temp_dir:
        ctx = LiveContext(repo_root=repo_root, temp_dir=Path(temp_dir))

        login_result = {"status": "passed", "detail": ""}
        try:
            _run_cli(repo_root, ["login"])
        except LiveSmokeError as exc:
            login_result = {"status": "failed", "detail": str(exc)}

        try:
            for spec in PUBLIC_COMMAND_MATRIX:
                if spec.mode not in LIVE_MODES:
                    results.append(
                        {
                            "group": spec.group,
                            "command": spec.cli_name,
                            "mode": spec.mode,
                            "status": "skipped",
                            "detail": spec.reason,
                        }
                    )
                    counts["skipped"] += 1
                    continue

                if login_result["status"] != "passed":
                    results.append(
                        {
                            "group": spec.group,
                            "command": spec.cli_name,
                            "mode": spec.mode,
                            "status": "failed",
                            "detail": "login prerequisite failed: {}".format(login_result["detail"]),
                        }
                    )
                    counts["failed"] += 1
                    continue

                try:
                    _run_live_spec(ctx, spec)
                except LiveSmokeBlocked as exc:
                    results.append(
                        {
                            "group": spec.group,
                            "command": spec.cli_name,
                            "mode": spec.mode,
                            "status": "blocked",
                            "detail": exc.reason,
                        }
                    )
                    counts["blocked"] += 1
                except LiveSmokeError as exc:
                    results.append(
                        {
                            "group": spec.group,
                            "command": spec.cli_name,
                            "mode": spec.mode,
                            "status": "failed",
                            "detail": str(exc),
                        }
                    )
                    counts["failed"] += 1
                else:
                    results.append(
                        {
                            "group": spec.group,
                            "command": spec.cli_name,
                            "mode": spec.mode,
                            "status": "passed",
                            "detail": "",
                        }
                    )
                    counts["passed"] += 1
        finally:
            _cleanup_messages(ctx, notes)

    return {
        "login": login_result,
        "counts": counts,
        "results": results,
        "notes": notes,
    }


def main(argv=None):
    parser = argparse.ArgumentParser(prog="live-public-commands")
    parser.add_argument("--output", choices=("text", "json"), default="text")
    args = parser.parse_args(argv)

    summary = run_live_public_commands()
    if args.output == "json":
        print(json.dumps(summary, indent=2, sort_keys=True, ensure_ascii=False))
    else:
        print(_render_text_summary(summary))
    return 0
