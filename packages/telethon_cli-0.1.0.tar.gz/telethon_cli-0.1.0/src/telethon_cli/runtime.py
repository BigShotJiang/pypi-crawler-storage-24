import asyncio
import getpass
import inspect
from pathlib import Path
import sys

from telethon import TelegramClient

from .config import load_client_config
from .errors import CLIError

try:
    from telethon.tl.tlobject import TLRequest
except ImportError:  # pragma: no cover - covered once bootstrap runs
    TLRequest = None

try:
    from telethon.errors import SessionPasswordNeededError
except ImportError:  # pragma: no cover - covered once bootstrap runs
    SessionPasswordNeededError = None


NO_AUTO_CONNECT_METHODS = frozenset({
    "connect",
    "disconnect",
    "is_connected",
    "set_proxy",
})


def _validate_call(target, args, kwargs, label):
    try:
        signature = inspect.signature(target)
    except (TypeError, ValueError):
        return

    try:
        signature.bind(*args, **kwargs)
    except TypeError as exc:
        raise CLIError("Invalid arguments for {}: {}".format(label, exc)) from exc


async def _maybe_await(value):
    if inspect.isawaitable(value):
        value = await value
    if hasattr(value, "__aiter__"):
        return [item async for item in value]
    return value


def _run(value):
    if inspect.isawaitable(value):
        return asyncio.run(value)
    return value


def _session_exists(session):
    session_path = Path(session)
    if session_path.exists():
        return True
    if session_path.suffix:
        return False
    return session_path.with_suffix(".session").exists()


def _ensure_session_directory(session):
    session_path = Path(session)
    directory = session_path.parent
    if not directory:
        return
    directory.mkdir(parents=True, exist_ok=True)


def _session_file_paths(session):
    session_path = Path(session)
    db_path = session_path if session_path.suffix else session_path.with_suffix(".session")
    return (
        db_path,
        Path(str(db_path) + "-journal"),
        Path(str(db_path) + "-shm"),
        Path(str(db_path) + "-wal"),
    )


def _remove_session_files(session):
    removed = []
    for path in _session_file_paths(session):
        if not path.exists():
            continue
        path.unlink()
        removed.append(str(path))
    return removed


def _prompt(label, *, secret=False):
    if not sys.stdin.isatty():
        raise CLIError("Interactive authentication requires a TTY")
    if secret:
        return getpass.getpass(label)
    print(label, file=sys.stderr, end="", flush=True)
    return sys.stdin.readline().strip()


async def _authorize_client(client, namespace):
    if await client.is_user_authorized():
        return client

    if not sys.stdin.isatty():
        raise CLIError(
            "No saved Telegram session was found and interactive login requires a TTY. "
            "Run `telethon-cli login` in an interactive terminal first."
        )

    phone = _prompt("Telegram phone number: ")
    if not phone:
        raise CLIError("Telegram phone number is required")

    sent = await client.send_code_request(phone)
    code = _prompt("Telegram login code: ")
    if not code:
        raise CLIError("Telegram login code is required")

    try:
        await client.sign_in(phone=phone, code=code, phone_code_hash=sent.phone_code_hash)
    except Exception as exc:
        if SessionPasswordNeededError is None or not isinstance(exc, SessionPasswordNeededError):
            raise
        password = load_client_config(namespace).password
        if not password:
            password = _prompt("Telegram 2FA password: ", secret=True)
        if not password:
            raise CLIError("Telegram 2FA password is required")
        await client.sign_in(password=password)

    if not await client.is_user_authorized():
        raise CLIError("Telegram login failed")
    return client


def create_client(namespace):
    config = load_client_config(namespace)
    _ensure_session_directory(config.session)
    return TelegramClient(config.session, config.api_id, config.api_hash)


async def _authorized_client(namespace, *, allow_interactive_login=True):
    client = create_client(namespace)
    await client.connect()
    if await client.is_user_authorized():
        return client

    if not allow_interactive_login:
        await client.disconnect()
        raise CLIError(
            "No saved Telegram session was found for '{}'. Run `telethon-cli login` first."
            .format(load_client_config(namespace).session)
        )

    try:
        return await _authorize_client(client, namespace)
    except Exception:
        await client.disconnect()
        raise


def login(namespace):
    return _run(_login_async(namespace))


async def _login_async(namespace):
    client = await _authorized_client(namespace, allow_interactive_login=True)
    session = load_client_config(namespace).session
    try:
        return {
            "authorized": True,
            "session": session,
        }
    finally:
        await client.disconnect()


def logout(namespace):
    return _run(_logout_async(namespace))


async def _logout_async(namespace):
    session = load_client_config(namespace).session
    if not _session_exists(session):
        return {
            "authorized": False,
            "logged_out": False,
            "session": session,
        }

    client = create_client(namespace)
    logged_out = False
    try:
        await client.connect()
        if await client.is_user_authorized():
            logged_out = await client.log_out()
    finally:
        await client.disconnect()

    removed_files = _remove_session_files(session)
    return {
        "authorized": False,
        "logged_out": bool(logged_out or removed_files),
        "session": session,
    }


async def _invoke_request_with_client(namespace, request):
    if TLRequest is not None and not isinstance(request, TLRequest):
        raise CLIError("Client invocation expects a TLRequest instance")

    client = await _authorized_client(namespace)
    try:
        return await client(request)
    finally:
        await client.disconnect()


async def _run_public_command_async(namespace, command, args, kwargs):
    if command.name in NO_AUTO_CONNECT_METHODS:
        client = create_client(namespace)
    else:
        client = await _authorized_client(namespace)

    try:
        method = getattr(client, command.name)
        _validate_call(method, args, kwargs, command.dotted_path)
        return await _maybe_await(method(*args, **kwargs))
    finally:
        await client.disconnect()


def run_public_command(namespace, command, args, kwargs):
    return _run(_run_public_command_async(namespace, command, args, kwargs))


def run_project_call(namespace, target, *, method_name=None, init_args=None,
                     init_kwargs=None, args=None, kwargs=None, client_invoke=False):
    init_args = [] if init_args is None else init_args
    init_kwargs = {} if init_kwargs is None else init_kwargs
    args = [] if args is None else args
    kwargs = {} if kwargs is None else kwargs

    if inspect.isclass(target):
        _validate_call(target, init_args, init_kwargs, "{}.__init__".format(target.__qualname__))
        instance = target(*init_args, **init_kwargs)

        if method_name:
            method = getattr(instance, method_name, None)
            if method is None:
                raise CLIError("Class '{}' has no method '{}'".format(target.__qualname__, method_name))
            if not callable(method):
                raise CLIError("'{}' on '{}' is not callable".format(method_name, target.__qualname__))
            _validate_call(method, args, kwargs, "{}.{}".format(target.__qualname__, method_name))
            return _run(method(*args, **kwargs))

        if client_invoke:
            return _run(_invoke_request_with_client(namespace, instance))

        return instance

    if client_invoke:
        if callable(target):
            _validate_call(target, args, kwargs, getattr(target, "__qualname__", repr(target)))
            request = _run(target(*args, **kwargs))
        else:
            request = target
        return _run(_invoke_request_with_client(namespace, request))

    if callable(target):
        _validate_call(target, args, kwargs, getattr(target, "__qualname__", repr(target)))
        return _run(target(*args, **kwargs))

    if args or kwargs or init_args or init_kwargs or method_name:
        raise CLIError("Target '{}' is not callable".format(target))
    return target
