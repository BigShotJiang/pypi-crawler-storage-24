import dataclasses
import inspect
import json
from pathlib import Path

from .errors import CLIError
from .resolver import import_dotted_path
from .settings import ensure_developer_mode_enabled

try:
    from telethon.tl.tlobject import TLObject
except ImportError:  # pragma: no cover - covered once bootstrap runs
    TLObject = None


def _call_from_spec(spec):
    if not isinstance(spec, dict) or "path" not in spec:
        raise CLIError("$call payload must be an object with a 'path' field")

    args = materialize_payload(spec.get("args", []))
    kwargs = materialize_payload(spec.get("kwargs", {}))
    if not isinstance(args, list):
        raise CLIError("$call args must decode to a list")
    if not isinstance(kwargs, dict):
        raise CLIError("$call kwargs must decode to an object")

    target = import_dotted_path(spec["path"], project_only=False)
    try:
        result = target(*args, **kwargs)
    except (AttributeError, ImportError, TypeError, ValueError) as exc:
        raise CLIError("Failed to materialize '$call' for '{}': {}".format(spec["path"], exc)) from exc

    if inspect.isawaitable(result):
        raise CLIError("Awaitable '$call' values are not supported in JSON payloads")

    return result


def materialize_payload(value):
    if isinstance(value, list):
        return [materialize_payload(item) for item in value]

    if isinstance(value, dict):
        if set(value) == {"$ref"}:
            ensure_developer_mode_enabled("JSON $ref materialization")
            return import_dotted_path(value["$ref"], project_only=False)
        if set(value) == {"$call"}:
            ensure_developer_mode_enabled("JSON $call materialization")
            return _call_from_spec(value["$call"])
        return {key: materialize_payload(item) for key, item in value.items()}

    return value


def parse_json_input(text=None, file_path=None, *, default):
    if text and file_path:
        raise CLIError("Use either inline JSON or a JSON file, not both")
    if text is None and file_path is None:
        return default

    if file_path:
        try:
            raw = Path(file_path).read_text(encoding="utf-8")
        except OSError as exc:
            raise CLIError("Unable to read JSON file '{}': {}".format(file_path, exc)) from exc
    else:
        raw = text
    try:
        payload = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise CLIError("Invalid JSON payload: {}".format(exc)) from exc
    return materialize_payload(payload)


def parse_cli_value(value):
    try:
        decoded = json.loads(value)
    except json.JSONDecodeError:
        return value
    return materialize_payload(decoded)


def _serialize_iterable(value):
    if isinstance(value, dict):
        return {str(key): serialize_result(item) for key, item in value.items()}

    if isinstance(value, (list, tuple, set)):
        return [serialize_result(item) for item in value]

    return None


def _serialize_instance(value):
    to_dict = getattr(value, "to_dict", None)
    if callable(to_dict):
        return serialize_result(to_dict())

    if callable(value):
        module = getattr(value, "__module__", None) or type(value).__module__
        qualname = getattr(value, "__qualname__", type(value).__qualname__)
        return {"__callable__": "{}.{}".format(module, qualname)}

    if hasattr(value, "__dict__"):
        return {
            "__class__": "{}.{}".format(type(value).__module__, type(value).__qualname__),
            "attributes": serialize_result(vars(value)),
        }

    return str(value)


def serialize_result(value):
    if dataclasses.is_dataclass(value):
        return serialize_result(dataclasses.asdict(value))

    if value is None or isinstance(value, (bool, int, float, str)):
        return value

    if isinstance(value, bytes):
        return {"__type__": "bytes", "hex": value.hex()}

    if isinstance(value, Path):
        return str(value)

    if TLObject and isinstance(value, TLObject):
        return serialize_result(value.to_dict())

    iterable = _serialize_iterable(value)
    if iterable is not None:
        return iterable

    return _serialize_instance(value)


def render_output(value, output_format):
    rendered = serialize_result(value)
    if output_format == "json":
        return json.dumps(rendered, indent=2, sort_keys=True, ensure_ascii=False)
    if isinstance(rendered, str):
        return rendered
    return json.dumps(rendered, indent=2, sort_keys=True, ensure_ascii=False)
