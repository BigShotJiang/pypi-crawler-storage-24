import argparse

import pytest

from telethon_cli import runtime
from telethon_cli.errors import CLIError


def _namespace(**overrides):
    values = {
        "api_id": None,
        "api_hash": None,
        "session": None,
        "password": None,
        "env_file": None,
    }
    values.update(overrides)
    return argparse.Namespace(**values)


class _FakeSentCode:
    phone_code_hash = "hash"


class _FakeClient:
    def __init__(self, session, api_id, api_hash):
        self.session = session
        self.api_id = api_id
        self.api_hash = api_hash
        self.authorized = False
        self.sign_in_calls = []
        self.send_code_calls = []
        self.log_out_calls = 0
        self.connected = False
        self.disconnected = False

    async def connect(self):
        self.connected = True

    async def disconnect(self):
        self.disconnected = True

    async def is_user_authorized(self):
        return self.authorized

    async def send_code_request(self, phone):
        self.send_code_calls.append(phone)
        return _FakeSentCode()

    async def sign_in(self, **kwargs):
        self.sign_in_calls.append(kwargs)
        self.authorized = True

    async def log_out(self):
        self.log_out_calls += 1
        self.authorized = False
        return True

    async def get_me(self):
        if not self.connected:
            raise RuntimeError("client is not connected")
        return {"id": 1}

    async def get_dialogs(self, *args, **kwargs):
        if not self.connected:
            raise RuntimeError("client is not connected")
        return [{"session": self.session, "args": args, "kwargs": kwargs}]

    def iter_messages(self, *args, **kwargs):
        if not self.connected:
            raise RuntimeError("client is not connected")

        async def _iterator():
            yield {"session": self.session, "args": args, "kwargs": kwargs, "index": 1}
            yield {"session": self.session, "args": args, "kwargs": kwargs, "index": 2}

        return _iterator()

    def is_connected(self):
        return self.connected

    def set_proxy(self, *args, **kwargs):
        return {"args": args, "kwargs": kwargs}

    async def __call__(self, request):
        return request

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, tb):
        await self.disconnect()
        return False


class _FakePasswordRequiredError(Exception):
    pass


def _command(name, dotted_path):
    return type("Command", (), {"name": name, "dotted_path": dotted_path})


def test_login_reuses_existing_authorized_session(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    created_clients = []

    def make_client(session, api_id, api_hash):
        client = _FakeClient(session, api_id, api_hash)
        client.authorized = True
        created_clients.append(client)
        return client

    monkeypatch.setattr(runtime, "TelegramClient", make_client)

    result = runtime.login(
        _namespace(api_id=100, api_hash="hash"),
    )

    assert result["authorized"] is True
    assert result["session"] == str(tmp_path / ".telethon-cli" / "session")
    assert created_clients[0].connected is True
    assert created_clients[0].disconnected is True


def test_login_prompts_for_phone_and_code_when_session_missing(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    prompts = iter(["+12025550123", "12345"])
    monkeypatch.setattr(runtime, "TelegramClient", _FakeClient)
    monkeypatch.setattr(runtime.sys.stdin, "isatty", lambda: True)
    monkeypatch.setattr(runtime, "_prompt", lambda _label, secret=False: next(prompts))

    result = runtime.login(
        _namespace(api_id=100, api_hash="hash"),
    )

    assert result["authorized"] is True
    assert result["session"] == str(tmp_path / ".telethon-cli" / "session")


def test_login_uses_password_from_config_for_2fa(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)

    class _PasswordClient(_FakeClient):
        async def sign_in(self, **kwargs):
            self.sign_in_calls.append(kwargs)
            if "password" in kwargs:
                self.authorized = True
                return
            raise _FakePasswordRequiredError()

    prompts = iter(["+12025550123", "12345"])
    monkeypatch.setattr(runtime, "TelegramClient", _PasswordClient)
    monkeypatch.setattr(runtime, "SessionPasswordNeededError", _FakePasswordRequiredError)
    monkeypatch.setattr(runtime.sys.stdin, "isatty", lambda: True)
    monkeypatch.setattr(runtime, "_prompt", lambda _label, secret=False: next(prompts))

    result = runtime.login(
        _namespace(api_id=100, api_hash="hash", password="secret"),
    )

    assert result["authorized"] is True


def test_logout_logs_out_authorized_session_and_removes_files(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    session_file = tmp_path / ".telethon-cli" / "session.session"
    session_file.parent.mkdir(parents=True)
    session_file.write_text("session", encoding="utf-8")
    created_clients = []

    def make_client(session, api_id, api_hash):
        client = _FakeClient(session, api_id, api_hash)
        client.authorized = True
        created_clients.append(client)
        return client

    monkeypatch.setattr(runtime, "TelegramClient", make_client)

    result = runtime.logout(_namespace(api_id=100, api_hash="hash"))

    assert result == {
        "authorized": False,
        "logged_out": True,
        "session": str(tmp_path / ".telethon-cli" / "session"),
    }
    assert len(created_clients) == 1
    assert created_clients[0].log_out_calls == 1
    assert created_clients[0].disconnected is True
    assert not session_file.exists()


def test_logout_is_idempotent_when_session_file_is_missing(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    created_clients = []

    def make_client(session, api_id, api_hash):
        client = _FakeClient(session, api_id, api_hash)
        created_clients.append(client)
        return client

    monkeypatch.setattr(runtime, "TelegramClient", make_client)

    result = runtime.logout(_namespace(api_id=100, api_hash="hash"))

    assert result == {
        "authorized": False,
        "logged_out": False,
        "session": str(tmp_path / ".telethon-cli" / "session"),
    }
    assert created_clients == []


def test_public_command_uses_single_authorized_client_instance(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    created_clients = []

    def make_client(session, api_id, api_hash):
        client = _FakeClient(session, api_id, api_hash)
        client.authorized = True
        created_clients.append(client)
        return client

    monkeypatch.setattr(runtime, "TelegramClient", make_client)

    result = runtime.run_public_command(
        _namespace(api_id=100, api_hash="hash"),
        _command("get_me", "telethon.client.users.UserMethods.get_me"),
        [],
        {},
    )

    assert result == {"id": 1}
    assert len(created_clients) == 1
    assert created_clients[0].connected is True
    assert created_clients[0].disconnected is True


def test_public_command_get_dialogs_uses_active_client_instance(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    created_clients = []

    def make_client(session, api_id, api_hash):
        client = _FakeClient(session, api_id, api_hash)
        client.authorized = True
        created_clients.append(client)
        return client

    monkeypatch.setattr(runtime, "TelegramClient", make_client)

    result = runtime.run_public_command(
        _namespace(api_id=100, api_hash="hash"),
        _command("get_dialogs", "telethon.client.dialogs.DialogMethods.get_dialogs"),
        [],
        {"limit": 3},
    )

    assert result == [{"session": created_clients[0].session, "args": (), "kwargs": {"limit": 3}}]
    assert len(created_clients) == 1
    assert created_clients[0].connected is True
    assert created_clients[0].disconnected is True


def test_public_command_collects_async_iterators(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    created_clients = []

    def make_client(session, api_id, api_hash):
        client = _FakeClient(session, api_id, api_hash)
        client.authorized = True
        created_clients.append(client)
        return client

    monkeypatch.setattr(runtime, "TelegramClient", make_client)

    result = runtime.run_public_command(
        _namespace(api_id=100, api_hash="hash"),
        _command("iter_messages", "telethon.client.messages.MessageMethods.iter_messages"),
        [],
        {"entity": "me", "limit": 2},
    )

    assert result == [
        {"session": created_clients[0].session, "args": (), "kwargs": {"entity": "me", "limit": 2}, "index": 1},
        {"session": created_clients[0].session, "args": (), "kwargs": {"entity": "me", "limit": 2}, "index": 2},
    ]
    assert len(created_clients) == 1
    assert created_clients[0].connected is True
    assert created_clients[0].disconnected is True


def test_no_auto_connect_command_uses_single_client_instance(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    created_clients = []

    def make_client(session, api_id, api_hash):
        client = _FakeClient(session, api_id, api_hash)
        created_clients.append(client)
        return client

    monkeypatch.setattr(runtime, "TelegramClient", make_client)

    result = runtime.run_public_command(
        _namespace(api_id=100, api_hash="hash"),
        _command("is_connected", "telethon.client.telegrambaseclient.TelegramBaseClient.is_connected"),
        [],
        {},
    )

    assert result is False
    assert len(created_clients) == 1
    assert created_clients[0].connected is False
    assert created_clients[0].disconnected is True


def test_public_command_requires_interactive_terminal_without_saved_session(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(runtime, "TelegramClient", _FakeClient)
    monkeypatch.setattr(runtime.sys.stdin, "isatty", lambda: False)

    with pytest.raises(CLIError, match="Run `telethon-cli login`"):
        runtime.run_public_command(
            _namespace(api_id=100, api_hash="hash"),
            _command("get_me", "telethon.client.users.UserMethods.get_me"),
            [],
            {},
        )
