import argparse

import pytest

from telethon_cli import app
from telethon_cli.errors import CLIError
from telethon_cli.serialization import materialize_payload
from telethon_cli.settings import (
    ProjectSettings,
    get_settings_path,
    load_project_settings,
    save_project_settings,
)


class _NonInteractiveStdin:
    def isatty(self):
        return False

    def readline(self):
        return ""


def test_enabling_developer_mode_requires_explicit_consent(monkeypatch, tmp_path):
    (tmp_path / "pyproject.toml").write_text("[project]\nname = 'demo'\n", encoding="utf-8")
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(app.sys, "stdin", _NonInteractiveStdin())

    with pytest.raises(CLIError, match="requires explicit confirmation"):
        app._handle_settings_developer_mode(
            argparse.Namespace(
                enable=True,
                disable=False,
                accept_dangerous_features=False,
            )
        )


def test_developer_mode_is_saved_at_project_root(monkeypatch, tmp_path):
    project_root = tmp_path / "project"
    project_root.mkdir()
    (project_root / "pyproject.toml").write_text("[project]\nname = 'demo'\n", encoding="utf-8")
    worktree = project_root / "nested"
    worktree.mkdir()
    monkeypatch.chdir(worktree)

    result = app._handle_settings_developer_mode(
        argparse.Namespace(
            enable=True,
            disable=False,
            accept_dangerous_features=True,
        )
    )

    assert result["developer_mode"] is True
    assert get_settings_path(worktree) == project_root / ".telethon-cli.json"
    assert load_project_settings(worktree).developer_mode is True


def test_call_requires_developer_mode(monkeypatch, tmp_path):
    (tmp_path / "pyproject.toml").write_text("[project]\nname = 'demo'\n", encoding="utf-8")
    monkeypatch.chdir(tmp_path)

    with pytest.raises(CLIError, match="call is disabled until developer mode is enabled"):
        app._handle_call(argparse.Namespace(target="telethon.utils.parse_phone"))


def test_registry_project_requires_developer_mode(monkeypatch, tmp_path):
    (tmp_path / "pyproject.toml").write_text("[project]\nname = 'demo'\n", encoding="utf-8")
    monkeypatch.chdir(tmp_path)

    with pytest.raises(CLIError, match="registry project is disabled until developer mode is enabled"):
        app._handle_registry_project(argparse.Namespace(prefix=None))


def test_materialize_payload_requires_developer_mode(monkeypatch, tmp_path):
    (tmp_path / "pyproject.toml").write_text("[project]\nname = 'demo'\n", encoding="utf-8")
    monkeypatch.chdir(tmp_path)

    with pytest.raises(CLIError, match="developer mode is enabled"):
        materialize_payload({"$ref": "telethon.utils.parse_phone"})


def test_materialize_payload_allows_ref_when_developer_mode_is_enabled(monkeypatch, tmp_path):
    (tmp_path / "pyproject.toml").write_text("[project]\nname = 'demo'\n", encoding="utf-8")
    monkeypatch.chdir(tmp_path)
    save_project_settings(ProjectSettings(developer_mode=True), tmp_path)

    resolved = materialize_payload({"$ref": "telethon.utils.parse_phone"})

    assert resolved.__name__ == "parse_phone"
