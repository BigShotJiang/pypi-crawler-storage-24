import argparse
import inspect
from pathlib import Path

import pytest

from telethon_cli import app
from telethon_cli.config import ClientConfig, load_client_config
from telethon_cli.errors import CLIError
from telethon_cli.registry import PublicCommand


def _namespace(**overrides):
    values = {
        "api_id": None,
        "api_hash": None,
        "session": None,
        "password": None,
        "env_file": None,
    }
    values.update(overrides)
    return argparse.Namespace(**values)


def _write_dotenv(path, lines):
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def test_load_client_config_reads_values_from_environment(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)

    config = load_client_config(
        _namespace(),
        environ={
            "TELETHON_API_ID": "100",
            "TELETHON_API_HASH": "hash",
        },
    )

    assert config == ClientConfig(
        api_id=100,
        api_hash="hash",
        session=str(tmp_path / ".telethon-cli" / "session"),
        password=None,
    )


def test_load_client_config_reads_values_from_explicit_env_file(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    env_file = tmp_path / "custom.env"
    _write_dotenv(
        env_file,
        [
            "TELETHON_API_ID=100",
            "TELETHON_API_HASH='hash value'",
        ],
    )

    config = load_client_config(_namespace(env_file=str(env_file)), environ={})

    assert config == ClientConfig(
        api_id=100,
        api_hash="hash value",
        session=str(tmp_path / ".telethon-cli" / "session"),
        password=None,
    )


def test_cli_flags_override_environment_and_dotenv(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    env_file = tmp_path / ".env"
    _write_dotenv(
        env_file,
        [
            "TELETHON_API_ID=100",
            "TELETHON_API_HASH=dotenv-hash",
            "TELETHON_SESSION=dotenv-session",
            "TELETHON_PASSWORD=dotenv-password",
        ],
    )

    config = load_client_config(
        _namespace(api_id=200, api_hash="flag-hash", session="flag-session", password="flag-password"),
        environ={},
    )

    assert config == ClientConfig(
        api_id=200,
        api_hash="flag-hash",
        session="flag-session",
        password="flag-password",
    )


def test_matching_environment_and_dotenv_do_not_raise(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_dotenv(
        tmp_path / ".env",
        [
            "TELETHON_API_ID=100",
            "TELETHON_API_HASH=hash",
        ],
    )

    config = load_client_config(
        _namespace(),
        environ={
            "TELETHON_API_ID": "100",
            "TELETHON_API_HASH": "hash",
        },
    )

    assert config == ClientConfig(
        api_id=100,
        api_hash="hash",
        session=str(tmp_path / ".telethon-cli" / "session"),
        password=None,
    )


def test_conflicting_environment_and_dotenv_raise(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_dotenv(
        tmp_path / ".env",
        [
            "TELETHON_API_ID=100",
            "TELETHON_API_HASH=dotenv-hash",
            "TELETHON_SESSION=dotenv-session",
        ],
    )

    with pytest.raises(CLIError, match="TELETHON_API_HASH"):
        load_client_config(
            _namespace(),
            environ={
                "TELETHON_API_ID": "100",
                "TELETHON_API_HASH": "env-hash",
                "TELETHON_SESSION": "dotenv-session",
            },
        )


def test_autoloads_dotenv_from_current_working_directory(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_dotenv(
        tmp_path / ".env",
        [
            "TELETHON_API_ID=100",
            "TELETHON_API_HASH=hash",
        ],
    )

    config = load_client_config(_namespace(), environ={})

    assert config == ClientConfig(
        api_id=100,
        api_hash="hash",
        session=str(tmp_path / ".telethon-cli" / "session"),
        password=None,
    )


def test_autoloads_dotenv_from_project_root_when_cwd_has_none(monkeypatch, tmp_path):
    project_root = tmp_path / "project"
    project_root.mkdir()
    (project_root / "pyproject.toml").write_text("[project]\nname='demo'\n", encoding="utf-8")
    _write_dotenv(
        project_root / ".env",
        [
            "TELETHON_API_ID=100",
            "TELETHON_API_HASH=hash",
        ],
    )
    nested = project_root / "nested"
    nested.mkdir()
    monkeypatch.chdir(nested)

    config = load_client_config(_namespace(), environ={})

    assert config == ClientConfig(
        api_id=100,
        api_hash="hash",
        session=str(project_root / ".telethon-cli" / "session"),
        password=None,
    )


def test_invalid_api_id_from_dotenv_raises(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_dotenv(
        tmp_path / ".env",
        [
            "TELETHON_API_ID=abc",
            "TELETHON_API_HASH=hash",
        ],
    )

    with pytest.raises(CLIError, match="TELETHON_API_ID must be an integer"):
        load_client_config(_namespace(), environ={})


def test_explicit_session_overrides_default(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)

    config = load_client_config(
        _namespace(session="custom-session"),
        environ={
            "TELETHON_API_ID": "100",
            "TELETHON_API_HASH": "hash",
        },
    )

    assert config.session == "custom-session"


def test_env_session_overrides_default(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)

    config = load_client_config(
        _namespace(),
        environ={
            "TELETHON_API_ID": "100",
            "TELETHON_API_HASH": "hash",
            "TELETHON_SESSION": "env-session",
        },
    )

    assert config.session == "env-session"


def test_password_can_come_from_environment(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)

    config = load_client_config(
        _namespace(),
        environ={
            "TELETHON_API_ID": "100",
            "TELETHON_API_HASH": "hash",
            "TELETHON_PASSWORD": "secret",
        },
    )

    assert config.password == "secret"


def test_public_command_parser_accepts_env_file_flag(monkeypatch):
    def sample_method(self, entity):
        return entity

    monkeypatch.setattr(
        app,
        "discover_public_commands",
        lambda: (
            PublicCommand(
                group="users",
                name="sample_method",
                cli_name="sample-method",
                dotted_path="telethon.client.users.UserMethods.sample_method",
                signature=inspect.signature(sample_method),
                summary="Sample",
            ),
        ),
    )

    parser = app.build_parser()
    namespace = parser.parse_args(
        [
            "users",
            "sample-method",
            "--env-file",
            "/tmp/telethon.env",
            "--entity",
            "me",
        ]
    )

    assert namespace.env_file == "/tmp/telethon.env"


def test_auth_login_parser_accepts_password_flag(monkeypatch):
    monkeypatch.setattr(app, "discover_public_commands", lambda: ())

    parser = app.build_parser()
    namespace = parser.parse_args(
        [
            "login",
            "--2fa-password",
            "secret",
        ]
    )

    assert namespace.password == "secret"


def test_logout_parser_accepts_session_flag(monkeypatch):
    monkeypatch.setattr(app, "discover_public_commands", lambda: ())

    parser = app.build_parser()
    namespace = parser.parse_args(
        [
            "logout",
            "--session",
            "/tmp/telethon-session",
        ]
    )

    assert namespace.session == "/tmp/telethon-session"
