import argparse

import pytest

from telethon_cli import runtime
from telethon_cli.command_matrix import (
    LIVE_MODES,
    NON_LIVE_MODES,
    PUBLIC_COMMAND_MATRIX,
)
from telethon_cli.live_smoke import LIVE_HANDLER_KEYS, STATIC_LIVE_ARGS
from telethon_cli.registry import discover_public_commands


def _namespace(**overrides):
    values = {
        "api_id": None,
        "api_hash": None,
        "session": None,
        "password": None,
        "env_file": None,
    }
    values.update(overrides)
    return argparse.Namespace(**values)


def _command(spec):
    return type(
        "Command",
        (),
        {
            "name": spec.method_name,
            "dotted_path": "telethon.client.{}.{}".format(spec.group, spec.method_name),
        },
    )


class _MatrixClient:
    def __init__(self, session, api_id, api_hash):
        self.session = session
        self.api_id = api_id
        self.api_hash = api_hash
        self.connected = False
        self.disconnected = False
        self.calls = []

    async def connect(self):
        self.connected = True

    async def disconnect(self):
        self.disconnected = True

    async def is_user_authorized(self):
        return True

    def __getattr__(self, name):
        if name in runtime.NO_AUTO_CONNECT_METHODS:
            def _sync(*args, **kwargs):
                self.calls.append((name, args, kwargs))
                return {"name": name, "args": list(args), "kwargs": kwargs}

            return _sync

        async def _async(*args, **kwargs):
            self.calls.append((name, args, kwargs))
            return {"name": name, "args": list(args), "kwargs": kwargs}

        return _async


def test_public_command_matrix_covers_every_public_command_exactly_once():
    registry_keys = {(command.group, command.cli_name) for command in discover_public_commands()}
    matrix_keys = [spec.key for spec in PUBLIC_COMMAND_MATRIX]

    assert len(matrix_keys) == len(set(matrix_keys))
    assert set(matrix_keys) == registry_keys


def test_non_live_specs_have_reasons_and_live_specs_have_runner_coverage():
    live_keys = {spec.key for spec in PUBLIC_COMMAND_MATRIX if spec.mode in LIVE_MODES}
    handled_live_keys = set(STATIC_LIVE_ARGS) | set(LIVE_HANDLER_KEYS)

    for spec in PUBLIC_COMMAND_MATRIX:
        if spec.mode in NON_LIVE_MODES:
            assert spec.reason

    assert live_keys == handled_live_keys


@pytest.mark.parametrize(
    "spec",
    [spec for spec in PUBLIC_COMMAND_MATRIX if spec.mode in NON_LIVE_MODES],
    ids=lambda spec: "{}-{}".format(spec.group, spec.cli_name),
)
def test_non_live_commands_have_mocked_runtime_coverage(monkeypatch, tmp_path, spec):
    monkeypatch.chdir(tmp_path)
    created_clients = []

    def make_client(session, api_id, api_hash):
        client = _MatrixClient(session, api_id, api_hash)
        created_clients.append(client)
        return client

    monkeypatch.setattr(runtime, "TelegramClient", make_client)

    result = runtime.run_public_command(
        _namespace(api_id=100, api_hash="hash"),
        _command(spec),
        [],
        {},
    )

    assert result["name"] == spec.method_name
    assert len(created_clients) == 1
    assert created_clients[0].disconnected is True
