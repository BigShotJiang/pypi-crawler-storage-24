import pytest

from telethon_cli.errors import CLIError
from telethon_cli.serialization import parse_json_input


def test_parse_json_input_wraps_file_read_errors(tmp_path):
    missing_file = tmp_path / "missing.json"

    with pytest.raises(CLIError, match="Unable to read JSON file"):
        parse_json_input(file_path=str(missing_file), default=[])
