from telethon_cli import registry
from telethon_cli.registry import CallableRecord


def test_discover_project_callables_skips_missing_optional_packages_and_keeps_method_targets_usable(
    monkeypatch,
    tmp_path,
):
    package_dir = tmp_path / "telethon"
    package_dir.mkdir()
    (package_dir / "__init__.py").write_text("", encoding="utf-8")
    (package_dir / "sample.py").write_text(
        "def helper():\n"
        "    return 1\n\n"
        "class Widget:\n"
        "    def run(self):\n"
        "        return 2\n",
        encoding="utf-8",
    )

    package_requests = []

    def fake_find_spec(name):
        return object() if name == "telethon" else None

    def fake_package_dir(name):
        package_requests.append(name)
        return package_dir

    monkeypatch.setattr(registry.importlib.util, "find_spec", fake_find_spec)
    monkeypatch.setattr(registry, "_package_dir", fake_package_dir)

    registry.discover_project_callables.cache_clear()
    try:
        records = registry.discover_project_callables()
    finally:
        registry.discover_project_callables.cache_clear()

    assert package_requests == ["telethon"]
    assert CallableRecord(dotted_path="telethon.sample.helper", kind="function") in records
    assert CallableRecord(dotted_path="telethon.sample.Widget", kind="class") in records
    assert CallableRecord(
        dotted_path="telethon.sample.Widget",
        kind="method",
        method_name="run",
    ) in records
