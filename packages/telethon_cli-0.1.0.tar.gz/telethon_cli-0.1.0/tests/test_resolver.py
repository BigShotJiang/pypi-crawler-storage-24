from telethon.sessions.memory import MemorySession

from telethon_cli.resolver import import_dotted_path


def test_import_dotted_path_resolves_class_method_attributes():
    assert import_dotted_path(
        "telethon.sessions.memory.MemorySession.save",
        project_only=True,
    ) is MemorySession.save
