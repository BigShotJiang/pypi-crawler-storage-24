import argparse

from telethon_cli import app
from telethon_cli.registry import CallableRecord


def test_call_parser_accepts_kebab_case_init_json(monkeypatch):
    monkeypatch.setattr(app, "discover_public_commands", lambda: ())

    parser = app.build_parser()
    namespace = parser.parse_args([
        "call",
        "telethon.sessions.memory.MemorySession",
        "--init-args-json",
        "[1]",
    ])

    assert namespace.init_args_json == "[1]"


def test_registry_project_output_includes_method_field(monkeypatch):
    monkeypatch.setattr(app, "ensure_developer_mode_enabled", lambda _feature_name: None)
    monkeypatch.setattr(
        app,
        "discover_project_callables",
        lambda: (
            CallableRecord(dotted_path="telethon.sample.Widget", kind="method", method_name="run"),
            CallableRecord(dotted_path="telethon.sample.Widget", kind="class"),
        ),
    )

    output = app._handle_registry_project(argparse.Namespace(prefix=None))

    assert output == [
        {"path": "telethon.sample.Widget", "kind": "method", "method": "run"},
        {"path": "telethon.sample.Widget", "kind": "class"},
    ]
