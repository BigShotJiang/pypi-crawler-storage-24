"""skills-cli: A CLI tool for managing skills."""

__version__ = "0.2.0"
