from setuptools import setup

setup(
    name="appforge",
    version="1.0.9",
    description="Convert web apps into Android apps automatically using Capacitor and GitHub cloud builds.",
    author="AppForge Team",
    packages=["appforge"], # <-- CHANGE THIS LINE
    install_requires=[
        "requests"
    ],
    package_data={
        "appforge": ["knowledge_base.json"],
    },
    include_package_data=True,
    entry_points={
        "console_scripts": [
            "appforge=appforge.cli:main",
        ],
    },
)
