import os
import json
import uuid
from .utils import print_error

LOCAL_CONFIG_FILE = ".appforge.json"

def load_local_config():
    if not os.path.exists(LOCAL_CONFIG_FILE):
        return {}
    with open(LOCAL_CONFIG_FILE, "r") as f:
        return json.load(f)

def save_local_config(data):
    config = load_local_config()
    config.update(data)
    with open(LOCAL_CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=2)

def get_app_id():
    config = load_local_config()
    if "app_id" not in config:
        new_id = str(uuid.uuid4())[:8] # Generate a short 8-character unique ID
        save_local_config({"app_id": new_id})
        return new_id
    return config["app_id"]
