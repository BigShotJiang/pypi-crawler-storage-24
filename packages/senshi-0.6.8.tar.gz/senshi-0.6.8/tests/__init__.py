"""Tests for Senshi."""
