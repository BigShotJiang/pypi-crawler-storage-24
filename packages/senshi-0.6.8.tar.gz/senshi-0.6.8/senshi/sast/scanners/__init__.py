"""Senshi SAST scanners."""
