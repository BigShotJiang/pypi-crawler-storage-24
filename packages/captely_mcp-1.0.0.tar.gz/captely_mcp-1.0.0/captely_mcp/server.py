"""Captely MCP server — proxies tool calls to the remote Captely API via JSON-RPC."""

import os
from typing import Any

import httpx
from mcp.server.fastmcp import FastMCP

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

API_KEY: str = os.environ.get("CAPTELY_API_KEY", "")
API_BASE: str = os.environ.get("CAPTELY_API_URL", "https://app.captely.com").rstrip("/")

mcp = FastMCP("captely")


# ---------------------------------------------------------------------------
# Shared JSON-RPC helper
# ---------------------------------------------------------------------------

async def _call(tool_name: str, arguments: dict[str, Any]) -> str:
    """Send a tools/call JSON-RPC request to the remote Captely MCP gateway."""
    if not API_KEY:
        return "Error: CAPTELY_API_KEY environment variable is not set."

    headers = {"Authorization": f"Bearer {API_KEY}"}
    payload = {
        "jsonrpc": "2.0",
        "method": "tools/call",
        "params": {"name": tool_name, "arguments": arguments},
        "id": 1,
    }

    async with httpx.AsyncClient(timeout=30.0) as client:
        try:
            resp = await client.post(
                f"{API_BASE}/mcp/sdk/",
                headers=headers | {"Accept": "application/json"},
                json=payload,
            )
            resp.raise_for_status()
        except httpx.HTTPStatusError as exc:
            return f"Error: HTTP {exc.response.status_code} — {exc.response.text[:200]}"
        except httpx.RequestError as exc:
            return f"Error: Request failed — {exc}"

    data = resp.json()
    if "error" in data:
        return f"Error: {data['error'].get('message', 'Unknown error')}"

    content = data.get("result", {}).get("content", [])
    return content[0].get("text", "") if content else "No result"


# ---------------------------------------------------------------------------
# Contact enrichment tools
# ---------------------------------------------------------------------------

@mcp.tool()
async def captely_enrich_contact(
    first_name: str,
    last_name: str,
    company: str,
    linkedin_url: str = "",
    enrich_email: bool = True,
    enrich_phone: bool = False,
) -> str:
    """Enrich a contact to find their professional email and/or phone number.

    Uses a cascaded waterfall of 6+ data providers (Icypeas, Dropcontact,
    Hunter, Snov.io, etc.) to maximise the hit rate. Each successful email
    enrichment costs 1 credit; phone enrichment costs 2 credits.

    Args:
        first_name: Contact's first name.
        last_name: Contact's last name.
        company: Company name the contact works at.
        linkedin_url: LinkedIn profile URL (improves accuracy, optional).
        enrich_email: Whether to search for a professional email (default True).
        enrich_phone: Whether to search for a phone number (default False).

    Returns:
        JSON string with found email, phone, confidence score, and provider used.
    """
    return await _call(
        "captely_enrich_contact",
        {
            "first_name": first_name,
            "last_name": last_name,
            "company": company,
            "linkedin_url": linkedin_url,
            "enrich_email": enrich_email,
            "enrich_phone": enrich_phone,
        },
    )


@mcp.tool()
async def captely_verify_email(email: str) -> str:
    """Verify whether a single email address is valid and deliverable.

    Performs MX record lookup, SMTP handshake, and catch-all detection.
    Costs 0.1 credits per verification.

    Args:
        email: The email address to verify.

    Returns:
        JSON string with is_valid, deliverability score, and reason code.
    """
    return await _call("captely_verify_email", {"email": email})


@mcp.tool()
async def captely_check_credits() -> str:
    """Check the current credit balance and usage for the authenticated account.

    Returns:
        JSON string with credits_remaining, credits_used, and plan details.
    """
    return await _call("captely_check_credits", {})


# ---------------------------------------------------------------------------
# Contact search / retrieval tools
# ---------------------------------------------------------------------------

@mcp.tool()
async def captely_search_contacts(
    query: str = "",
    company: str = "",
    email: str = "",
    job_title: str = "",
    limit: int = 25,
    offset: int = 0,
) -> str:
    """Search contacts stored in Captely with free-text and field filters.

    At least one filter parameter is recommended. All filters are combined
    with AND logic. Free — does not consume credits.

    Args:
        query: Full-text search across name, email, and company fields.
        company: Filter by company name (partial match supported).
        email: Filter by email address (exact or partial match).
        job_title: Filter by job title (partial match supported).
        limit: Number of results to return (1-100, default 25).
        offset: Pagination offset (default 0).

    Returns:
        JSON string with a list of matching contacts and total count.
    """
    return await _call(
        "captely_search_contacts",
        {
            "query": query,
            "company": company,
            "email": email,
            "job_title": job_title,
            "limit": limit,
            "offset": offset,
        },
    )


@mcp.tool()
async def captely_get_contact(contact_id: int) -> str:
    """Retrieve full details for a single contact by their numeric ID.

    Returns all stored fields including enrichment history and list memberships.
    Free — does not consume credits.

    Args:
        contact_id: The numeric ID of the contact.

    Returns:
        JSON string with the complete contact record.
    """
    return await _call("captely_get_contact", {"contact_id": contact_id})


# ---------------------------------------------------------------------------
# List management tools
# ---------------------------------------------------------------------------

@mcp.tool()
async def captely_list_lists(search: str = "") -> str:
    """List all contact lists in the account, optionally filtered by name.

    Free — does not consume credits.

    Args:
        search: Optional name filter (partial match).

    Returns:
        JSON string with list of {id, name, description, contact_count}.
    """
    return await _call("captely_list_lists", {"search": search})


@mcp.tool()
async def captely_create_list(name: str, description: str = "") -> str:
    """Create a new contact list.

    Free — does not consume credits.

    Args:
        name: Name of the new list (must be unique within the account).
        description: Optional description for the list.

    Returns:
        JSON string with the created list's id, name, and created_at timestamp.
    """
    return await _call("captely_create_list", {"name": name, "description": description})


@mcp.tool()
async def captely_get_list_contacts(
    list_id: int,
    limit: int = 25,
    offset: int = 0,
) -> str:
    """Retrieve contacts belonging to a specific list with pagination.

    Free — does not consume credits.

    Args:
        list_id: Numeric ID of the list.
        limit: Number of contacts to return (1-100, default 25).
        offset: Pagination offset (default 0).

    Returns:
        JSON string with contacts array and total count.
    """
    return await _call(
        "captely_get_list_contacts",
        {"list_id": list_id, "limit": limit, "offset": offset},
    )


@mcp.tool()
async def captely_add_to_list(list_id: int, contact_ids: list[int]) -> str:
    """Add one or more contacts to an existing list.

    Free — does not consume credits. Duplicate memberships are silently ignored.

    Args:
        list_id: Numeric ID of the target list.
        contact_ids: List of numeric contact IDs to add.

    Returns:
        JSON string confirming the number of contacts added.
    """
    return await _call(
        "captely_add_to_list",
        {"list_id": list_id, "contact_ids": contact_ids},
    )


@mcp.tool()
async def captely_remove_from_list(list_id: int, contact_ids: list[int]) -> str:
    """Remove one or more contacts from a list.

    Free — does not consume credits. Non-members are silently ignored.

    Args:
        list_id: Numeric ID of the list.
        contact_ids: List of numeric contact IDs to remove.

    Returns:
        JSON string confirming the number of contacts removed.
    """
    return await _call(
        "captely_remove_from_list",
        {"list_id": list_id, "contact_ids": contact_ids},
    )


# ---------------------------------------------------------------------------
# Sequence tools
# ---------------------------------------------------------------------------

@mcp.tool()
async def captely_list_sequences(status: str = "", search: str = "") -> str:
    """List email sequences in the account with optional filters.

    Free — does not consume credits.

    Args:
        status: Filter by status — "active", "paused", "draft", or "" for all.
        search: Optional name filter (partial match).

    Returns:
        JSON string with list of sequences including id, name, status, and stats.
    """
    return await _call("captely_list_sequences", {"status": status, "search": search})


@mcp.tool()
async def captely_get_sequence_stats(sequence_id: int) -> str:
    """Retrieve detailed performance statistics for a sequence.

    Returns open rates, click rates, reply rates, and per-step funnel data.
    Free — does not consume credits.

    Args:
        sequence_id: Numeric ID of the sequence.

    Returns:
        JSON string with delivery, open, click, reply, and unsubscribe metrics.
    """
    return await _call("captely_get_sequence_stats", {"sequence_id": sequence_id})


@mcp.tool()
async def captely_create_sequence(name: str, steps: list[dict]) -> str:
    """Create a new email sequence with one or more steps.

    Each step is a dict with keys:
      - type (str): "email" or "delay"
      - subject (str): Email subject line (required for email steps)
      - body (str): HTML or plain-text email body (required for email steps)
      - delay_days (int): Number of days to wait before this step (default 0)

    Free — does not consume credits.

    Args:
        name: Name for the new sequence.
        steps: Ordered list of step dicts as described above.

    Returns:
        JSON string with the created sequence's id and name.
    """
    return await _call("captely_create_sequence", {"name": name, "steps": steps})


@mcp.tool()
async def captely_enroll_contacts(
    sequence_id: int,
    contact_ids: list[int],
    exclude_active_sequences: bool = True,
) -> str:
    """Enroll contacts into an email sequence.

    Sending emails consumes account email credits (1 per email sent, not
    per contact enrolled). Enrollment itself is free.

    Args:
        sequence_id: Numeric ID of the sequence to enroll into.
        contact_ids: List of numeric contact IDs to enroll.
        exclude_active_sequences: If True, skip contacts already active in
            another sequence (default True, recommended).

    Returns:
        JSON string with enrolled count and any skipped contacts.
    """
    return await _call(
        "captely_enroll_contacts",
        {
            "sequence_id": sequence_id,
            "contact_ids": contact_ids,
            "exclude_active_sequences": exclude_active_sequences,
        },
    )


@mcp.tool()
async def captely_remove_contacts_from_sequence(
    sequence_id: int,
    contact_ids: list[int],
) -> str:
    """Remove contacts from a sequence, stopping any pending steps.

    Free — does not consume credits.

    Args:
        sequence_id: Numeric ID of the sequence.
        contact_ids: List of numeric contact IDs to remove.

    Returns:
        JSON string with the count of contacts removed from the sequence.
    """
    return await _call(
        "captely_remove_contacts_from_sequence",
        {"sequence_id": sequence_id, "contact_ids": contact_ids},
    )


@mcp.tool()
async def captely_activate_sequence(sequence_id: int) -> str:
    """Activate a paused or draft sequence so it begins (or resumes) sending.

    Free — does not consume credits.

    Args:
        sequence_id: Numeric ID of the sequence to activate.

    Returns:
        JSON string confirming the new status.
    """
    return await _call("captely_activate_sequence", {"sequence_id": sequence_id})


@mcp.tool()
async def captely_pause_sequence(sequence_id: int) -> str:
    """Pause an active sequence, halting all pending sends until reactivated.

    Free — does not consume credits.

    Args:
        sequence_id: Numeric ID of the sequence to pause.

    Returns:
        JSON string confirming the new status.
    """
    return await _call("captely_pause_sequence", {"sequence_id": sequence_id})
