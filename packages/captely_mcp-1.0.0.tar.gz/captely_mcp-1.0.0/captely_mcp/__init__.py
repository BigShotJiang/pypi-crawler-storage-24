"""Captely MCP server — local stdio bridge for Claude Desktop and Claude Code."""

__version__ = "1.0.0"
