"""CLI entry point for the Captely MCP server."""

import os
import sys


def main() -> None:
    """Start the Captely MCP server in stdio mode.

    Requires the CAPTELY_API_KEY environment variable to be set.
    Optionally reads CAPTELY_API_URL (default: https://app.captely.com).
    """
    api_key = os.environ.get("CAPTELY_API_KEY", "")
    if not api_key:
        print(
            "Error: CAPTELY_API_KEY environment variable is not set.\n"
            "Get your API key from: https://app.captely.com/settings?tab=api\n"
            "Then run: CAPTELY_API_KEY=your_key captely-mcp",
            file=sys.stderr,
        )
        sys.exit(1)

    # Import here so the module-level env reads happen after this check
    from captely_mcp.server import mcp

    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
