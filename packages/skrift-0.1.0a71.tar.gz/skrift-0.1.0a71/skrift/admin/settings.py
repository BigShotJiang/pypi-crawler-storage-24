"""Site settings admin controller."""

from __future__ import annotations

import importlib.metadata
import logging
from pathlib import Path
from typing import Annotated

from litestar import Controller, Request, get, post
from litestar.exceptions import HTTPException
from litestar.response import File, Response, Template as TemplateResponse, Redirect
from litestar.params import Body
from litestar.enums import RequestEncodingType
from sqlalchemy.ext.asyncio import AsyncSession

from skrift.auth.guards import auth_guard, Permission
from skrift.admin.helpers import get_admin_context
from skrift.admin.navigation import ADMIN_NAV_TAG
from skrift.db.services import setting_service
from skrift.lib.flash import flash_success, get_flash_messages

logger = logging.getLogger(__name__)


class SettingsAdminController(Controller):
    """Controller for site settings in admin."""

    path = "/admin"
    guards = [auth_guard]

    @get(
        "/settings",
        tags=[ADMIN_NAV_TAG],
        guards=[auth_guard, Permission("modify-site")],
        opt={"label": "Settings", "icon": "settings", "order": 100},
    )
    async def site_settings(
        self, request: Request, db_session: AsyncSession
    ) -> TemplateResponse:
        """Site settings page."""
        from skrift.config import get_settings as get_app_settings
        from skrift.lib.theme import themes_available, discover_themes

        ctx = await get_admin_context(request, db_session)
        app_settings = get_app_settings()

        # Build sites list when multi-site is configured
        sites_list: list[dict[str, str]] = []
        if app_settings.sites and app_settings.domain:
            sites_list.append({"key": "", "label": f"{app_settings.domain} (primary)"})
            for name, site_cfg in app_settings.sites.items():
                sites_list.append({
                    "key": site_cfg.subdomain,
                    "label": f"{site_cfg.subdomain}.{app_settings.domain}",
                })

        selected_site = request.query_params.get("site", "") if sites_list else ""

        # Fetch settings — per-subdomain when a site is selected, global otherwise
        if selected_site:
            current_settings = await setting_service.get_site_settings_for_subdomain(
                db_session, selected_site
            )
        else:
            current_settings = await setting_service.get_site_settings(db_session)

        # Build theme data only for primary domain
        theme_data = None
        if not selected_site and themes_available():
            theme_data = {
                "themes": discover_themes(),
                "active": current_settings.get(setting_service.SITE_THEME_KEY, ""),
            }

        # Resolve current favicon URL for preview
        current_favicon_url = ""
        favicon_key = current_settings.get(setting_service.SITE_FAVICON_KEY, "")
        if favicon_key and not selected_site:
            try:
                from skrift.lib.storage import StorageManager
                storage: StorageManager = request.app.state.storage_manager
                backend = await storage.get()
                current_favicon_url = await backend.get_url(favicon_key)
            except Exception:
                logger.warning(
                    "Failed to resolve favicon preview URL for key '%s'",
                    favicon_key,
                    exc_info=True,
                )

        flash_messages = get_flash_messages(request)
        return TemplateResponse(
            "admin/settings/site.html",
            context={
                "flash_messages": flash_messages,
                "settings": current_settings,
                "theme_data": theme_data,
                "sites_list": sites_list,
                "selected_site": selected_site,
                "current_favicon_url": current_favicon_url,
                **ctx,
            },
        )

    @post(
        "/settings",
        guards=[auth_guard, Permission("modify-site")],
    )
    async def save_site_settings(
        self,
        request: Request,
        db_session: AsyncSession,
        data: Annotated[dict, Body(media_type=RequestEncodingType.MULTI_PART)],
    ) -> Redirect:
        """Save site settings."""
        from skrift.app_factory import update_template_directories
        from skrift.lib.theme import themes_available

        subdomain = data.get("_site", "")
        if isinstance(subdomain, str):
            subdomain = subdomain.strip()
        site_name = data.get("site_name", "")
        if isinstance(site_name, str):
            site_name = site_name.strip()
        site_tagline = data.get("site_tagline", "")
        if isinstance(site_tagline, str):
            site_tagline = site_tagline.strip()

        if subdomain:
            # Per-subdomain: only save site_name and site_tagline
            await setting_service.set_site_setting_for_subdomain(
                db_session, subdomain, setting_service.SITE_NAME_KEY, site_name
            )
            await setting_service.set_site_setting_for_subdomain(
                db_session, subdomain, setting_service.SITE_TAGLINE_KEY, site_tagline
            )
        else:
            # Primary domain: save all fields
            site_copyright_holder = data.get("site_copyright_holder", "").strip()
            site_copyright_start_year = data.get("site_copyright_start_year", "").strip()

            await setting_service.set_setting(
                db_session, setting_service.SITE_NAME_KEY, site_name
            )
            await setting_service.set_setting(
                db_session, setting_service.SITE_TAGLINE_KEY, site_tagline
            )
            await setting_service.set_setting(
                db_session, setting_service.SITE_COPYRIGHT_HOLDER_KEY, site_copyright_holder
            )
            await setting_service.set_setting(
                db_session, setting_service.SITE_COPYRIGHT_START_YEAR_KEY, site_copyright_start_year
            )

            # Save robots.txt custom content
            robots_txt = data.get("robots_txt", "").strip()
            await setting_service.set_setting(
                db_session, setting_service.ROBOTS_TXT_KEY, robots_txt
            )

            # Save theme selection if themes are available
            if themes_available():
                site_theme = data.get("site_theme", "").strip()
                await setting_service.set_setting(
                    db_session, setting_service.SITE_THEME_KEY, site_theme
                )

            # Handle favicon upload
            favicon_file = data.get("favicon")
            if favicon_file and hasattr(favicon_file, "read"):
                content = await favicon_file.read()
                if content:
                    from skrift.db.services.asset_service import upload_asset
                    storage = request.app.state.storage_manager
                    asset = await upload_asset(
                        db_session,
                        storage,
                        filename=favicon_file.filename or "favicon",
                        data=content,
                        content_type=favicon_file.content_type or "image/png",
                    )
                    await setting_service.set_setting(
                        db_session, setting_service.SITE_FAVICON_KEY, asset.key
                    )

            # Update template directories for instant theme switching
            update_template_directories()

        await setting_service.load_site_settings_cache(db_session)

        # Re-resolve favicon URL cache after settings change
        favicon_key = setting_service.get_cached_site_favicon_key()
        if favicon_key:
            storage = request.app.state.storage_manager
            backend = await storage.get()
            url = await backend.get_url(favicon_key)
            setting_service.set_cached_favicon_url(url)
        else:
            setting_service.set_cached_favicon_url("")

        flash_success(request, "Site settings saved successfully")
        redirect_path = "/admin/settings"
        if subdomain:
            redirect_path += f"?site={subdomain}"
        return Redirect(path=redirect_path)

    @get(
        "/theme-screenshot/{name:str}",
        guards=[auth_guard],
    )
    async def theme_screenshot(self, request: Request, name: str) -> File:
        """Serve a theme's screenshot image."""
        from litestar.response import File
        from skrift.lib.theme import get_theme_info

        info = get_theme_info(name)
        if not info or not info.screenshot:
            raise HTTPException(status_code=404, detail="Screenshot not found")

        return File(path=info.screenshot, media_type="image/png")

    @get(
        "/system-info",
        guards=[auth_guard, Permission("modify-site")],
    )
    async def system_info(self, request: Request) -> Response:
        """Return system info for the details modal."""
        from alembic.config import Config as AlembicConfig
        from alembic.script import ScriptDirectory

        version = importlib.metadata.version("skrift")

        # Get alembic head revision from migration scripts
        alembic_ini = Path(__file__).resolve().parent.parent / "alembic.ini"
        alembic_cfg = AlembicConfig(str(alembic_ini))
        script_dir = ScriptDirectory.from_config(alembic_cfg)
        heads = script_dir.get_heads()
        alembic_head = heads[0] if heads else "unknown"

        # Gather installed dependency versions
        deps: list[dict[str, str]] = []
        requires = importlib.metadata.requires("skrift") or []
        for req in requires:
            # Skip extras-only deps (e.g. "redis ; extra == 'redis'")
            if "extra ==" in req:
                continue
            # Extract package name (before any version specifier)
            pkg_name = req.split(";")[0].split("[")[0].split(">")[0].split("<")[0].split("=")[0].split("!")[0].split("~")[0].strip()
            try:
                pkg_version = importlib.metadata.version(pkg_name)
            except importlib.metadata.PackageNotFoundError:
                pkg_version = "not installed"
            deps.append({"name": pkg_name, "version": pkg_version})

        return Response(
            content={
                "version": version,
                "alembic_head": alembic_head,
                "dependencies": deps,
            },
            media_type="application/json",
        )
