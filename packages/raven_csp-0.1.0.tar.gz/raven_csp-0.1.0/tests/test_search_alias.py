import sys
import types
import unittest

sys.modules.setdefault("sympy", types.ModuleType("sympy"))

from csp.core import CSP
from csp.api import run_search


class SearchAliasTests(unittest.TestCase):
    def test_find_all_solutions_alias_is_honored(self):
        csp = CSP()
        csp.add_variable("x", {1, 2, 3})
        csp.add_variable("y", {1, 2, 3})
        csp.add_constraint("c1", "x != y")

        res = run_search("bt", csp, find_all_solutions=True)
        self.assertGreater(len(res.solutions), 1)

    def test_max_solutions_limits_output(self):
        csp = CSP()
        csp.add_variable("x", {1, 2, 3})
        csp.add_variable("y", {1, 2, 3})
        csp.add_constraint("c1", "x != y")

        res = run_search("bt", csp, find_all_solutions=True, max_solutions=2)
        self.assertEqual(len(res.solutions), 2)


if __name__ == "__main__":
    unittest.main()
