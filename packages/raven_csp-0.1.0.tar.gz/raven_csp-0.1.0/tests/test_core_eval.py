import unittest

from csp.core import CSP


class CoreEvalTests(unittest.TestCase):
    def test_round_is_available_in_safe_globals(self):
        csp = CSP()
        csp.add_variable("x", {1, 2, 3})
        csp.add_variable("y", {2})
        csp.add_constraint("c1", "round(x / 2, 0) <= y")

        # should find at least one satisfying assignment if round() works
        sat = any(csp.constraints["c1"].evaluate({"x": xv, "y": 2}) for xv in [1, 2, 3])
        self.assertTrue(sat)


if __name__ == "__main__":
    unittest.main()
