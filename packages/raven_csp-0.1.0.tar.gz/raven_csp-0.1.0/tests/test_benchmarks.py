import sys
import types
import unittest

# Allow importing csp package in environments without sympy.
sys.modules.setdefault("sympy", types.ModuleType("sympy"))

from csp import benchmarks


class BenchmarkTests(unittest.TestCase):
    def test_manufacturbility_problem_benchmark_is_registered_and_builds(self):
        spec = benchmarks.load(["manufacturbility_problem"])[0]
        csp = spec.factory()
        self.assertEqual(spec.name, "manufacturbility_problem")
        self.assertGreaterEqual(len(csp.variables), 40)
        self.assertGreaterEqual(len(csp.constraints), 30)


if __name__ == "__main__":
    unittest.main()
