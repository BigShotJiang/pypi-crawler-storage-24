import sys
import types
import unittest

sys.modules.setdefault("sympy", types.ModuleType("sympy"))

from csp.core import CSP
from csp.api import run_search


class SearchAlgorithmTests(unittest.TestCase):
    def setUp(self):
        self.csp = CSP()
        self.csp.add_variable("x", {1, 2, 3})
        self.csp.add_variable("y", {1, 2, 3})
        self.csp.add_constraint("c1", "x < y")

    def test_algorithm_alias_backtracking(self):
        res = run_search("backtracking", self.csp, deterministic=True)
        self.assertGreaterEqual(len(res.solutions), 1)

    def test_mac_suffix_variant(self):
        res = run_search("mac-gac", self.csp, deterministic=True)
        self.assertGreaterEqual(len(res.solutions), 1)


if __name__ == "__main__":
    unittest.main()
