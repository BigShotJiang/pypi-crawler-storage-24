import sys
import types
import unittest

sys.modules.setdefault("sympy", types.ModuleType("sympy"))

from csp.core import CSP
from dcsp.architectures.constraint_agent import build_constraint_agent_model
from dcsp.propagation import run_distributed_gac


class DGACTests(unittest.TestCase):
    def test_reports_incomplete_when_max_events_hit(self):
        csp = CSP()
        for v in ["a", "b", "c", "d"]:
            csp.add_variable(v, {1, 2, 3, 4})
        csp.add_constraint("c1", "a < b")
        csp.add_constraint("c2", "b < c")
        csp.add_constraint("c3", "c < d")

        model = build_constraint_agent_model(csp, [("c1",), ("c2",), ("c3",)])
        ok, _reduced, extra = run_distributed_gac(model, max_events=1)

        self.assertFalse(ok)
        self.assertFalse(extra["terminated"])
        self.assertEqual(extra["reason"], "max_events")
        self.assertGreater(extra["pending_events"], 0)

    def test_reports_done_when_quiescent(self):
        csp = CSP()
        for v in ["a", "b", "c"]:
            csp.add_variable(v, {1, 2, 3})
        csp.add_constraint("c1", "a < b")
        csp.add_constraint("c2", "b < c")

        model = build_constraint_agent_model(csp, [("c1",), ("c2",)])
        ok, _reduced, extra = run_distributed_gac(model, max_events=100000)

        self.assertTrue(ok)
        self.assertTrue(extra["terminated"])
        self.assertEqual(extra["reason"], "done")
        self.assertEqual(extra["pending_events"], 0)


if __name__ == "__main__":
    unittest.main()
