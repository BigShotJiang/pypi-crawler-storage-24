import sys
import types
import unittest

sys.modules.setdefault("sympy", types.ModuleType("sympy"))

from csp.core import CSP
from dcsp.mapping import (
    build_pseudotree_constraint_assignment,
    validate_constraint_assignment,
)


class MappingTests(unittest.TestCase):
    def test_pseudotree_assignment_covers_constraints_exactly_once(self):
        csp = CSP()
        csp.add_variable("a", {1, 2})
        csp.add_variable("b", {1, 2})
        csp.add_variable("c", {1, 2})
        csp.add_constraint("c1", "a != b")
        csp.add_constraint("c2", "b != c")
        csp.add_constraint("c3", "a != c")

        assignment = build_pseudotree_constraint_assignment(csp)
        flat = [name for tup in assignment for name in tup]

        self.assertEqual(set(flat), set(csp.constraints.keys()))
        self.assertEqual(len(flat), len(set(flat)))

    def test_validate_constraint_assignment_rejects_duplicate(self):
        csp = CSP()
        csp.add_variable("x", {1, 2})
        csp.add_variable("y", {1, 2})
        csp.add_constraint("c1", "x != y")

        with self.assertRaises(ValueError):
            validate_constraint_assignment(csp, [("c1",), ("c1",)])


if __name__ == "__main__":
    unittest.main()
