from __future__ import annotations

from typing import Dict, Set, Any, Optional, Tuple
from collections import deque


def _supports(
    csp,
    cons,
    var: str,
    val: Any,
    domains: Dict[str, Set[Any]],
    *,
    eval_counter=None,
    counters=None,
) -> bool:
    """Returns True iff *val* for *var* has at least one supporting tuple in *cons*.

    We count "constraint evaluations" as calls to cons.evaluate(...) with a full
    assignment for all variables in the constraint scope.
    """
    from itertools import product

    other = [v for v in cons.variables if v != var]
    if not other:
        if eval_counter is not None:
            eval_counter[0] += 1
        elif counters is not None:
            counters.inc("constraint_evaluations")
        return cons.evaluate({var: val})

    pools = [domains[v] for v in other]
    for combo in product(*pools):
        a = {var: val, **{ov: cv for ov, cv in zip(other, combo)}}
        if eval_counter is not None:
            eval_counter[0] += 1
        elif counters is not None:
            counters.inc("constraint_evaluations")
        if cons.evaluate(a):
            return True
    return False


def run_gac(
    csp,
    reduced_domains: Optional[Dict[str, Set[Any]]] = None,
    counters=None,
) -> Tuple[bool, Any, Dict[str, Any]]:
    """Generalized Arc Consistency (AC-3-style queue) for n-ary constraints.

    Returned metrics are *algorithm-local* and deliberately do not include runtime
    (runtime is measured in the API layer for comparability across propagators).

    Metrics captured here (requested for benchmarking):
    - constraint_evaluations
    - queue_pops
    - revision_calls (Revise(c, x))
    - domain_updates (how often a variable domain changed)
    - values_removed
    """

    domains: Dict[str, Set[Any]] = (
        {v: set(reduced_domains.get(v, csp.variables[v].domain)) for v in csp.variables}
        if reduced_domains
        else {v: set(csp.variables[v].domain) for v in csp.variables}
    )

    values_removed = 0
    queue_pops = 0
    revision_calls = 0
    domain_updates = 0

    queue = deque()
    for cid, cons in csp.constraints.items():
        for v in cons.variables:
            queue.append((cid, v))

    eval_counter = [0]

    while queue:
        cid, v = queue.popleft()
        queue_pops += 1
        revision_calls += 1

        cons = csp.constraints[cid]

        to_remove = set()
        for val in list(domains[v]):
            if not _supports(csp, cons, v, val, domains, eval_counter=eval_counter, counters=counters):
                to_remove.add(val)

        if to_remove:
            before = len(domains[v])
            domains[v].difference_update(to_remove)
            after = len(domains[v])
            if after != before:
                domain_updates += 1
            values_removed += len(to_remove)

            if not domains[v]:
                metrics = {
                    "values_removed": values_removed,
                    "queue_pops": queue_pops,
                    "revision_calls": revision_calls,
                    "domain_updates": domain_updates,
                    "constraint_evaluations": eval_counter[0],
                    "queue_item_type": "arc",
                }
                return False, csp.clone_with_domains(domains), metrics

            # Re-enqueue neighbor arcs (c', x') for all constraints that mention v.
            for nid in csp.constraints_by_var.get(v, []):
                ncons = csp.constraints[nid]
                for nv in ncons.variables:
                    if nv != v:
                        queue.append((nid, nv))

    metrics = {
        "values_removed": values_removed,
        "queue_pops": queue_pops,
        "revision_calls": revision_calls,
        "domain_updates": domain_updates,
        "constraint_evaluations": eval_counter[0],
        "queue_item_type": "arc",
    }
    return True, csp.clone_with_domains(domains), metrics
