
from typing import Dict, Set, Any, Optional, List
from .heuristics import select_variable, order_values
from .propagation import run_gac
from .propagation_vlac import run_vlac


def _base_domains(csp, reduced_domains: Optional[Dict[str, Set[Any]]] = None):
    return {v: set(reduced_domains.get(v, csp.variables[v].domain)) for v in csp.variables} if reduced_domains else {v: set(csp.variables[v].domain) for v in csp.variables}

def solve_backtracking(csp, find_all=False, heuristics=None, reduced_domains: Optional[Dict[str, Set[Any]]] = None, counters=None, deterministic: bool = False):
    domains = _base_domains(csp, reduced_domains); sols=[]; steps=0
    def backtrack(assignment):
        nonlocal steps; steps+=1
        if len(assignment)==len(csp.variables): sols.append(dict(assignment)); return find_all
        var = select_variable(csp, assignment, heuristics or [], domains, deterministic=deterministic)
        for val in order_values(csp, var, heuristics or [], assignment, domains, deterministic=deterministic):
            test = dict(assignment); test[var]=val
            if all(c.evaluate(test) for c in (csp.constraints[cid] for cid in csp.constraints_by_var.get(var, []))):
                if not backtrack(test): return False
        return True
    backtrack({})
    return {"solutions": sols, "steps": steps, "average_depth": 0.0}

def solve_forward_checking(
    csp,
    find_all: bool = False,
    heuristics: Optional[List[str]] = None,
    reduced_domains: Optional[Dict[str, Set[Any]]] = None,
    counters=None,
    deterministic: bool = False,
    propagation: Optional[str] = None,
):
    """
    Forward Checking mit optionaler zusätzlicher Propagation:
    - propagation=None: klassisches FC (nur Vorausfilterung auf Nachbarn)
    - propagation="gac": nach dem FC-Schritt zusätzlich GAC
    - propagation="vlac": nach dem FC-Schritt zusätzlich VLAC
    """
    from copy import deepcopy

    domains = _base_domains(csp, reduced_domains)
    sols: List[Dict[str, Any]] = []
    steps = 0

    prop = (propagation or "").lower()

    def _propagate(doms: Dict[str, Set[Any]]):
        """Optionale zusätzliche GAC/VLAC-Propagation."""
        if not prop:
            return True, doms
        if prop == "vlac":
            ok, reduced_csp, _ = run_vlac(csp, reduced_domains=doms, counters=counters)
            new_doms = {v: set(reduced_csp.variables[v].domain) for v in reduced_csp.variables}
        elif prop == "gac":
            ok, reduced_csp, _ = run_gac(csp, reduced_domains=doms, counters=counters)
            new_doms = {v: set(reduced_csp.variables[v].domain) for v in reduced_csp.variables}
        else:
            raise ValueError(f"Unknown propagation algorithm in FC: {propagation}")
        return ok, new_doms

    def fc(assign: Dict[str, Any], doms: Dict[str, Set[Any]]):
        nonlocal steps
        steps += 1

        # vollständige Belegung
        if len(assign) == len(csp.variables):
            sols.append(dict(assign))
            return find_all

        var = select_variable(
            csp,
            assign,
            heuristics or [],
            doms,
            deterministic=deterministic,
        )

        for val in order_values(
            csp,
            var,
            heuristics or [],
            assign,
            doms,
            deterministic=deterministic,
        ):
            test = dict(assign)
            test[var] = val

            newdom = deepcopy(doms)
            newdom[var] = {val}

            # klassisches Forward Checking auf allen Constraints, in denen var vorkommt
            ok = True
            for cid in csp.constraints_by_var.get(var, []):
                cons = csp.constraints[cid]
                other_vars = [nv for nv in cons.variables if nv != var]

                for nv in other_vars:
                    if nv in assign:
                        continue

                    bad_values: Set[Any] = set()
                    for vv in newdom[nv]:
                        if not cons.evaluate({**test, nv: vv}):
                            bad_values.add(vv)

                    if bad_values:
                        newdom[nv] -= bad_values
                        if not newdom[nv]:
                            ok = False
                            break

                if not ok:
                    break

            # zusätzliche GAC/VLAC-Propagation
            if ok and prop:
                ok, newdom = _propagate(newdom)

            if ok:
                if not fc(test, newdom):
                    return False

        return True

    fc({}, domains)
    return {
        "solutions": sols,
        "steps": steps,
        "average_depth": 0.0,
    }


def solve_mac(
    csp,
    find_all: bool = False,
    heuristics: Optional[List[str]] = None,
    reduced_domains: Optional[Dict[str, Set[Any]]] = None,
    counters=None,
    deterministic: bool = False,
    propagation: str = "gac",
):
    """
    MAC-Suche mit wählbarer Propagation:
    - propagation="gac": klassisches MAC mit GAC (Standard)
    - propagation="vlac": MAC mit deinem VLAC-Propagator
    """
    from copy import deepcopy

    # Ausgangsdomänen
    domains = _base_domains(csp, reduced_domains)
    sols: List[Dict[str, Any]] = []
    steps = 0

    prop = (propagation or "gac").lower()

    def _propagate(doms: Dict[str, Set[Any]]):
        """Wählt abhängig von 'propagation' GAC oder VLAC."""
        if prop == "vlac":
            ok, reduced_csp, _ = run_vlac(csp, reduced_domains=doms, counters=counters)
            new_doms = {v: set(reduced_csp.variables[v].domain) for v in reduced_csp.variables}
        elif prop == "gac":
            ok, reduced_csp, _ = run_gac(csp, reduced_domains=doms, counters=counters)
            new_doms = {v: set(reduced_csp.variables[v].domain) for v in reduced_csp.variables}
        else:
            raise ValueError(f"Unknown propagation algorithm in MAC: {propagation}")
        return ok, new_doms

    def mac(assign: Dict[str, Any], doms: Dict[str, Set[Any]]):
        nonlocal steps
        steps += 1

        # vollständige Belegung gefunden
        if len(assign) == len(csp.variables):
            sols.append(dict(assign))
            return find_all

        # Variable wählen
        var = select_variable(
            csp,
            assign,
            heuristics or [],
            doms,
            deterministic=deterministic,
        )

        # Werte in Reihenfolge testen
        for val in order_values(
            csp,
            var,
            heuristics or [],
            assign,
            doms,
            deterministic=deterministic,
        ):
            # neue Belegung
            test = dict(assign)
            test[var] = val

            # Domänen kopieren und var auf Singleton setzen
            nd = deepcopy(doms)
            nd[var] = {val}

            # zentrale Stelle: Propagation anwenden (GAC oder VLAC)
            ok, nd2 = _propagate(nd)

            if ok:
                if not mac(test, nd2):
                    # Suche abbrechen, wenn find_all == False und eine Lösung gefunden wurde
                    return False

        return True

    mac({}, domains)
    return {
        "solutions": sols,
        "steps": steps,
        "average_depth": 0.0,
    }

def solve_min_conflicts(csp, max_steps=10000, restarts=1, random_seed=None, reduced_domains: Optional[Dict[str, Set[Any]]] = None, counters=None, deterministic: bool = False):
    import random
    rng = random.Random(random_seed)
    domains = _base_domains(csp, reduced_domains)
    vars_list = list(csp.variables.keys())
    for _ in range(restarts):
        assign = {v: min(domains[v]) for v in vars_list} if deterministic else {v: rng.choice(tuple(domains[v])) for v in vars_list}
        for step in range(max_steps):
            violated = [c for c in csp.constraints.values() if not c.evaluate(assign)]
            if not violated:
                return {"solutions":[assign], "steps":step+1, "average_depth":0.0}
            cons = min(violated, key=lambda c: c.name) if deterministic else rng.choice(violated)
            var = sorted(cons.variables)[0] if deterministic else rng.choice(cons.variables)
            def conflicts(val):
                test = dict(assign); test[var]=val
                return sum(1 for c in csp.constraints.values() if not c.evaluate(test))
            assign[var] = min(domains[var], key=conflicts)
    return {"solutions":[], "steps":max_steps*restarts, "average_depth":0.0}
