from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence, Set, Tuple, Union

from .core import CSP


_BAD_CHARS = re.compile(r"[^0-9A-Za-z_]")


@dataclass
class XCSP3ImportInfo:
    """Bookkeeping for XCSP3 import."""

    # Original name -> normalized python identifier
    var_map: Dict[str, str]
    # Constraint id/name mapping (original -> internal)
    constraint_map: Dict[str, str]


def _normalize_identifier(name: str, *, used: Set[str]) -> str:
    n = _BAD_CHARS.sub("_", name.strip())
    if not n:
        n = "v"
    if n[0].isdigit():
        n = "v_" + n
    base = n
    k = 0
    while n in used:
        k += 1
        n = f"{base}_{k}"
    used.add(n)
    return n


def _parse_domain(text: str) -> Set[int]:
    """Parse XCSP3 domain text like '1..9 11 13..15' into a set of ints."""
    out: Set[int] = set()
    t = " ".join(text.strip().split())
    if not t:
        return out
    for tok in t.split(" "):
        if not tok:
            continue
        if ".." in tok:
            a, b = tok.split("..", 1)
            lo = int(a)
            hi = int(b)
            step = 1 if hi >= lo else -1
            # Inclusive interval in XCSP.
            out.update(range(lo, hi + step, step))
        else:
            out.add(int(tok))
    return out


def _parse_var_list(text: str) -> List[str]:
    # XCSP3 lists are space-separated.
    return [t for t in text.strip().split() if t]


def _extract_text(elem: Optional[ET.Element]) -> str:
    if elem is None:
        return ""
    return "".join(elem.itertext()).strip()


# ---------------------------
# Intension parsing
# ---------------------------


class _Tok:
    def __init__(self, kind: str, value: str):
        self.kind = kind
        self.value = value


_TOK_RE = re.compile(
    r"\s*(?:(?P<num>-?\d+)|(?P<name>[A-Za-z_][A-Za-z0-9_\[\]\.]*?)|(?P<lp>\()|(?P<rp>\))|(?P<comma>,))"
)


def _tokenize(s: str) -> List[_Tok]:
    pos = 0
    toks: List[_Tok] = []
    while pos < len(s):
        m = _TOK_RE.match(s, pos)
        if not m:
            raise ValueError(f"Cannot tokenize intension expression near: {s[pos:pos+30]!r}")
        pos = m.end()
        if m.lastgroup == "num":
            toks.append(_Tok("num", m.group("num")))
        elif m.lastgroup == "name":
            toks.append(_Tok("name", m.group("name")))
        elif m.lastgroup == "lp":
            toks.append(_Tok("lp", "("))
        elif m.lastgroup == "rp":
            toks.append(_Tok("rp", ")"))
        elif m.lastgroup == "comma":
            toks.append(_Tok("comma", ","))
    return toks


class _Parser:
    def __init__(self, toks: Sequence[_Tok], var_map: Dict[str, str]):
        self.toks = list(toks)
        self.i = 0
        self.var_map = var_map
        self.vars_used: Set[str] = set()

    def _peek(self) -> Optional[_Tok]:
        return self.toks[self.i] if self.i < len(self.toks) else None

    def _eat(self, kind: str) -> _Tok:
        t = self._peek()
        if t is None or t.kind != kind:
            raise ValueError(f"Expected token {kind}, got {t.kind if t else None}")
        self.i += 1
        return t

    def parse_expr(self) -> str:
        t = self._peek()
        if t is None:
            raise ValueError("Unexpected end of expression")
        if t.kind == "num":
            self.i += 1
            return t.value
        if t.kind == "name":
            name = t.value
            self.i += 1
            # function call?
            if self._peek() is not None and self._peek().kind == "lp":
                self._eat("lp")
                args: List[str] = []
                if self._peek() is not None and self._peek().kind != "rp":
                    args.append(self.parse_expr())
                    while self._peek() is not None and self._peek().kind == "comma":
                        self._eat("comma")
                        args.append(self.parse_expr())
                self._eat("rp")
                return self._emit_func(name, args)

            # variable
            if name in self.var_map:
                v = self.var_map[name]
                self.vars_used.add(v)
                return v
            # Sometimes XCSP3 uses already-normalized names.
            if name in set(self.var_map.values()):
                self.vars_used.add(name)
                return name
            # Otherwise treat as symbol (rare)
            return name
        raise ValueError(f"Unexpected token kind: {t.kind}")

    def _emit_func(self, fn: str, args: Sequence[str]) -> str:
        fn = fn.strip()

        def chain(op: str) -> str:
            if not args:
                return "0" if op in ("+", "-") else "1"
            return "(" + f" {op} ".join(f"({a})" for a in args) + ")"

        if fn == "eq":
            return f"(({args[0]}) == ({args[1]}))"
        if fn == "ne":
            return f"(({args[0]}) != ({args[1]}))"
        if fn == "lt":
            return f"(({args[0]}) < ({args[1]}))"
        if fn == "le":
            return f"(({args[0]}) <= ({args[1]}))"
        if fn == "gt":
            return f"(({args[0]}) > ({args[1]}))"
        if fn == "ge":
            return f"(({args[0]}) >= ({args[1]}))"
        if fn == "add":
            return chain("+")
        if fn == "mul":
            return chain("*")
        if fn == "sub":
            if len(args) == 1:
                return f"(-({args[0]}))"
            out = f"(({args[0]}) - ({args[1]}))"
            for a in args[2:]:
                out = f"(({out}) - ({a}))"
            return out
        if fn in ("div", "idiv"):
            return f"(({args[0]}) // ({args[1]}))"
        if fn == "mod":
            return f"(({args[0]}) % ({args[1]}))"
        if fn == "neg":
            return f"(-({args[0]}))"
        if fn == "abs":
            return f"abs({args[0]})"
        if fn == "dist":
            return f"abs(({args[0]}) - ({args[1]}))"
        if fn == "and":
            return chain("and")
        if fn == "or":
            return chain("or")
        if fn == "not":
            return f"(not ({args[0]}))"
        if fn == "imp":
            return f"((not ({args[0]})) or ({args[1]}))"
        if fn == "iff":
            return f"(({args[0]}) == ({args[1]}))"
        if fn == "xor":
            return f"(({args[0]}) != ({args[1]}))"
        if fn == "if":
            return f"(({args[1]}) if ({args[0]}) else ({args[2]}))"
        if fn == "min":
            return f"min({', '.join(args)})"
        if fn == "max":
            return f"max({', '.join(args)})"

        # Fallback: keep as function call (may work if user provided SAFE_GLOBALS)
        return f"{fn}({', '.join(args)})"


def _translate_intension(expr: str, var_map: Dict[str, str]) -> Tuple[str, Set[str]]:
    toks = _tokenize(expr)
    p = _Parser(toks, var_map)
    out = p.parse_expr()
    if p._peek() is not None:
        raise ValueError("Trailing tokens in intension expression")
    return out, p.vars_used


# ---------------------------
# Constraint translations
# ---------------------------


def _pairwise_alldiff(vars_: Sequence[str]) -> str:
    parts: List[str] = []
    vs = list(vars_)
    for i in range(len(vs)):
        for j in range(i + 1, len(vs)):
            parts.append(f"({vs[i]} != {vs[j]})")
    return "(" + " and ".join(parts) + ")" if parts else "True"


def _parse_extension_tuples(text: str) -> List[Tuple[int, ...]]:
    t = " ".join(text.strip().split())
    if not t:
        return []
    groups = re.findall(r"\(([^)]*)\)", t)
    tuples: List[Tuple[int, ...]] = []
    if groups:
        for g in groups:
            items = [x for x in re.split(r"[\s,]+", g.strip()) if x]
            tuples.append(tuple(int(x) for x in items))
        return tuples
    # Fallback for flat lists like: "1 2  2 3" (arity inferred later)
    items = [x for x in re.split(r"\s+", t) if x]
    # Caller will chunk.
    tuples.append(tuple(int(x) for x in items))
    return tuples


def csp_from_xcsp3(path: str, *, normalize_names: bool = True) -> CSP:
    """Load an XCSP3 XML file and convert it into this framework's CSP object.

    Supported constraint types (initially): allDifferent, intension, extension, sum, element.
    Other constraints will raise NotImplementedError with the offending tag.
    """

    tree = ET.parse(path)
    root = tree.getroot()

    csp = CSP()
    used_vars: Set[str] = set()
    var_map: Dict[str, str] = {}
    constraint_map: Dict[str, str] = {}

    # --- variables
    vars_node = root.find(".//variables")
    if vars_node is None:
        raise ValueError("XCSP3: <variables> section not found")

    # <var id="x"> 1..9 </var>
    for v in vars_node.findall("var"):
        oid = v.get("id")
        if oid is None:
            continue
        dom = _parse_domain(_extract_text(v))
        vid = oid
        if normalize_names:
            vid = _normalize_identifier(oid, used=used_vars)
            var_map[oid] = vid
        else:
            used_vars.add(vid)
            var_map[oid] = vid
        csp.add_variable(vid, dom)

    # <array id="x" size="5"> 1..9 </array>
    for arr in vars_node.findall("array"):
        aid = arr.get("id")
        size = arr.get("size")
        if aid is None or size is None:
            continue
        dom = _parse_domain(_extract_text(arr))
        # size can be "n" or "[d1][d2]"; we expand linearly.
        dims = [int(x) for x in re.findall(r"\d+", size)]
        if not dims:
            continue
        total = 1
        for d in dims:
            total *= d
        for i in range(total):
            oid = f"{aid}[{i}]"
            vid = oid
            if normalize_names:
                vid = _normalize_identifier(oid, used=used_vars)
                var_map[oid] = vid
            else:
                used_vars.add(vid)
                var_map[oid] = vid
            csp.add_variable(vid, dom)

    # --- constraints
    cons_node = root.find(".//constraints")
    if cons_node is None:
        csp.xcsp3_import = XCSP3ImportInfo(var_map=var_map, constraint_map=constraint_map)  # type: ignore[attr-defined]
        return csp

    auto_idx = 0
    for ce in list(cons_node):
        ctag = ce.tag
        cid = ce.get("id") or ce.get("name") or f"c{auto_idx}"
        auto_idx += 1
        internal_cid = cid
        if internal_cid in csp.constraints:
            k = 1
            base = internal_cid
            while internal_cid in csp.constraints:
                internal_cid = f"{base}_{k}"
                k += 1
        constraint_map[cid] = internal_cid

        expr = None
        vars_used: Set[str] = set()

        if ctag == "allDifferent":
            vs = _parse_var_list(_extract_text(ce.find("list")))
            nvs = [var_map.get(v, v) for v in vs]
            expr = _pairwise_alldiff(nvs)
            vars_used.update(nvs)

        elif ctag == "intension":
            raw = _extract_text(ce)
            expr, vars_used = _translate_intension(raw, var_map)

        elif ctag == "extension":
            vs = _parse_var_list(_extract_text(ce.find("list")))
            nvs = [var_map.get(v, v) for v in vs]
            vars_used.update(nvs)
            supports = ce.find("supports")
            conflicts = ce.find("conflicts")
            if supports is None and conflicts is None:
                # Some instances use <tuples>
                supports = ce.find("tuples")
            mode = "supports" if supports is not None else "conflicts"
            tup_text = _extract_text(supports if supports is not None else conflicts)
            tups = _parse_extension_tuples(tup_text)
            arity = len(nvs)
            if tups and len(tups) == 1 and len(tups[0]) != arity:
                flat = list(tups[0])
                if len(flat) % arity != 0:
                    raise ValueError(f"XCSP3 extension: cannot infer tuples with arity {arity} from {flat}")
                tups = [tuple(flat[i : i + arity]) for i in range(0, len(flat), arity)]
            set_lit = "{" + ", ".join("(" + ", ".join(str(x) for x in t) + ("," if len(t) == 1 else "") + ")" for t in tups) + "}"
            tuple_expr = "(" + ", ".join(nvs) + ("," if len(nvs) == 1 else "") + ")"
            if mode == "supports":
                expr = f"({tuple_expr} in {set_lit})"
            else:
                expr = f"({tuple_expr} not in {set_lit})"

        elif ctag == "sum":
            vs = _parse_var_list(_extract_text(ce.find("list")))
            nvs = [var_map.get(v, v) for v in vs]
            vars_used.update(nvs)
            coeffs_text = _extract_text(ce.find("coeffs"))
            coeffs = [int(x) for x in coeffs_text.split()] if coeffs_text else [1] * len(nvs)
            if len(coeffs) != len(nvs):
                raise ValueError("XCSP3 sum: coeffs length does not match variable list")
            lhs_parts = []
            for a, v in zip(coeffs, nvs):
                if a == 1:
                    lhs_parts.append(f"({v})")
                elif a == -1:
                    lhs_parts.append(f"(-({v}))")
                else:
                    lhs_parts.append(f"({a}*({v}))")
            lhs = "(" + " + ".join(lhs_parts) + ")" if lhs_parts else "0"

            cond = ce.find("condition")
            ctext = _extract_text(cond)
            op = None
            rhs = None
            m = re.match(r"\(?\s*(eq|ne|lt|le|gt|ge)\s*,\s*(-?\d+)\s*\)?", ctext)
            if m:
                op, rhs = m.group(1), int(m.group(2))
            else:
                # token form: "le 10"
                toks = ctext.split()
                if len(toks) == 2 and toks[0] in ("eq", "ne", "lt", "le", "gt", "ge"):
                    op, rhs = toks[0], int(toks[1])
                elif cond is not None and len(list(cond)) == 1:
                    child = list(cond)[0]
                    op = child.tag
                    rhs = int(_extract_text(child))
            if op is None or rhs is None:
                raise NotImplementedError(f"XCSP3 sum condition not supported: {ctext!r}")
            pyop = {"eq": "==", "ne": "!=", "lt": "<", "le": "<=", "gt": ">", "ge": ">="}[op]
            expr = f"({lhs} {pyop} {rhs})"

        elif ctag == "element":
            vs = _parse_var_list(_extract_text(ce.find("list")))
            nvs = [var_map.get(v, v) for v in vs]
            vars_used.update(nvs)
            idx_raw = _extract_text(ce.find("index"))
            val_raw = _extract_text(ce.find("value"))
            # startIndex attribute may sit on <element>.
            start_index = int(ce.get("startIndex", "0"))

            def _as_term(x: str) -> str:
                x = x.strip()
                if re.fullmatch(r"-?\d+", x):
                    return x
                return var_map.get(x, x)

            idx = _as_term(idx_raw)
            val = _as_term(val_raw)
            if not re.fullmatch(r"-?\d+", idx):
                vars_used.add(idx)
            if not re.fullmatch(r"-?\d+", val):
                vars_used.add(val)
            adj = "" if start_index == 0 else f" - {start_index}"
            arr = "[" + ", ".join(nvs) + "]"
            expr = f"({arr}[({idx}){adj}] == ({val}))"

        else:
            # Some XCSP3 instances wrap intension inside a tag, e.g. <constraint> <intension> ...
            inner_int = ce.find("intension")
            if inner_int is not None:
                raw = _extract_text(inner_int)
                expr, vars_used = _translate_intension(raw, var_map)
            else:
                raise NotImplementedError(f"XCSP3 constraint type not supported: <{ctag}>")

        assert expr is not None
        csp.add_constraint_explicit(internal_cid, expr, sorted(vars_used))

    csp.xcsp3_import = XCSP3ImportInfo(var_map=var_map, constraint_map=constraint_map)  # type: ignore[attr-defined]
    return csp
