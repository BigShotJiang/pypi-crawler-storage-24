from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Set, Any, Optional, List

from .instrument import BenchmarkTimer


@dataclass
class VLACConstraint:
    """Einfache interne Darstellung eines Constraints für VLAC."""
    variables: List[str]
    expr: str


def _collect_base_domains(
    csp,
    reduced_domains: Optional[Dict[str, Set[Any]]],
) -> Dict[str, Set[Any]]:
    """
    Holt pro Variable die aktuelle Domäne:
    - wenn reduced_domains gegeben: diese bevorzugt,
    - sonst die vollständige Domäne aus csp.variables.
    """
    if reduced_domains is not None:
        base = {
            name: set(reduced_domains.get(name, var.domain))
            for name, var in csp.variables.items()
        }
    else:
        base = {name: set(var.domain) for name, var in csp.variables.items()}
    return base


def _adapt_constraints(csp) -> List[VLACConstraint]:
    """
    Überführt CSP-Constraints in eine einfache VLAC-Struktur
    (Variablennamen + Ausdrucksstring).
    """
    adapted: List[VLACConstraint] = []
    for cid, cons in csp.constraints.items():
        expr = (
            getattr(cons, "expression", None)
            or getattr(cons, "constraint_string", None)
            or getattr(cons, "expr", None)
            or str(cons)
        )
        adapted.append(VLACConstraint(variables=list(cons.variables), expr=expr))
    return adapted


def run_vlac(
    csp,
    reduced_domains: Optional[Dict[str, Set[Any]]] = None,
    counters=None,
):
    """
    VLAC-Stub:
    - Schritt 1: Domänen aus dem CSP holen
    - Schritt 2: Constraints in VLAC-Struktur überführen

    Noch keine eigentliche Propagation – die Domänen bleiben unverändert.
    """

    # Schritt 1: Domänen sammeln
    base_domains = _collect_base_domains(csp, reduced_domains)

    # Schritt 2: Constraints adaptieren (werden im nächsten Schritt vom Algorithmus genutzt)
    vlac_constraints = _adapt_constraints(csp)

    print("Hallo")
    # (Noch) keine Domänenreduktion, daher: Runtime und Werteentfernung = 0
    metrics = {
        "runtime": 0.0,
        "values_removed": 0,
        "queue_pops": 0,
        "domain_updates": 0,
    }

    if counters is not None:
        counters.inc("vlac_runs")

    # Hier könntest du bei Bedarf zum Debuggen reinschauen:
    # print(base_domains)
    # print(vlac_constraints)

    # ok=True, Domänen unverändert zurückgeben
    return True, base_domains, metrics
