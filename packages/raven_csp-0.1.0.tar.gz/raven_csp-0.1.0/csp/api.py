
from typing import Dict, Any, Optional, Set, Tuple
import math
from .results import PropagationResult, SearchResult
from .instrument import BenchmarkTimer, Counters
from .propagation import run_gac
from .propagation_vlac import run_vlac
from . import solvers


def _approx_log10_bigint(n: int) -> float:
    """Approximate log10(n) for arbitrarily large integers without float overflow."""
    if n <= 0:
        return float("-inf")
    s = str(n)
    k = len(s)
    # Use first up to 16 digits for mantissa.
    head = int(s[:16])
    return (k - 1) + math.log10(head / (10 ** (len(str(head)) - 1)))


def _solution_space(domains: Dict[str, Set[Any]]) -> int:
    space = 1
    for d in domains.values():
        space *= max(0, len(d))
    return space


def _augment_propagation_metrics(
    *,
    csp,
    reduced_csp,
    start_domains: Dict[str, Set[Any]],
    algo_metrics: Dict[str, Any],
    runtime: float,
) -> Dict[str, Any]:
    """Add domain/search-space reduction metrics in a consistent way across propagators."""
    end_domains = {v: set(reduced_csp.variables[v].domain) for v in reduced_csp.variables}

    start_total = sum(len(d) for d in start_domains.values())
    end_total = sum(len(d) for d in end_domains.values())
    values_removed = int(start_total - end_total)

    space_before = _solution_space(start_domains)
    space_after = _solution_space(end_domains)

    if space_before > 0:
        space_reduction_ratio = 1.0 - (space_after / space_before)
    else:
        space_reduction_ratio = None

    augmented = dict(algo_metrics or {})
    augmented["runtime"] = runtime
    augmented.setdefault("values_removed", values_removed)
    augmented.setdefault("domain_size_total_before", start_total)
    augmented.setdefault("domain_size_total_after", end_total)
    augmented.setdefault(
        "domain_reduction_ratio",
        (values_removed / start_total) if start_total > 0 else None,
    )

    augmented.setdefault("search_space_before", space_before)
    augmented.setdefault("search_space_after", space_after)
    augmented.setdefault("search_space_reduction_ratio", space_reduction_ratio)
    augmented.setdefault(
        "search_space_reduction_log10",
        (_approx_log10_bigint(space_before) - _approx_log10_bigint(space_after))
        if space_before > 0 and space_after > 0
        else None,
    )

    # Ensure the requested counter keys exist (for easy benchmarking dashboards).
    augmented.setdefault("constraint_evaluations", 0)
    augmented.setdefault("queue_pops", 0)
    augmented.setdefault("revision_calls", 0)
    augmented.setdefault("domain_updates", 0)
    return augmented

def run_propagation(algorithm: str, csp, collect_metrics: bool = True, **kwargs) -> PropagationResult:
    algorithm = algorithm.lower()
    counters = Counters() if collect_metrics else None
    reduced_domains = kwargs.get("reduced_domains")
    start_domains = (
        {v: set(reduced_domains.get(v, csp.variables[v].domain)) for v in csp.variables}
        if reduced_domains is not None
        else {v: set(var.domain) for v, var in csp.variables.items()}
    )

    if algorithm in ("gac", "ac", "ac3", "arc"):
        with BenchmarkTimer() as t:
            ok, reduced, algo_metrics = run_gac(csp, reduced_domains=reduced_domains, counters=counters)
        metrics = _augment_propagation_metrics(
            csp=csp,
            reduced_csp=reduced,
            start_domains=start_domains,
            algo_metrics=algo_metrics,
            runtime=t.elapsed,
        )
        metrics["algorithm"] = "gac"
        return PropagationResult(algorithm="gac", ok=ok, reduced_csp=reduced, runtime=t.elapsed, metrics=metrics)
    elif algorithm in ("vlac",):
        with BenchmarkTimer() as t:
            ok, reduced, algo_metrics = run_vlac(
                csp,
                reduced_domains=reduced_domains,
                counters=counters,
                verbose=bool(kwargs.get("verbose", False)),
            )
        metrics = _augment_propagation_metrics(
            csp=csp,
            reduced_csp=reduced,
            start_domains=start_domains,
            algo_metrics=algo_metrics,
            runtime=t.elapsed,
        )
        metrics["algorithm"] = "vlac"
        return PropagationResult(algorithm="vlac", ok=ok, reduced_csp=reduced, runtime=t.elapsed, metrics=metrics)
    else:
        raise ValueError(f"Unknown propagation algorithm: {algorithm}")



def run_search(algorithm: str, csp, reduced_domains: Optional[Dict[str, Set[Any]]] = None,
               collect_metrics: bool = True, deterministic: bool = False, **kwargs) -> SearchResult:
    algorithm = algorithm.lower()

    # Backwards/UX compatibility:
    # - central solvers use `find_all`
    # - many users pass `find_all_solutions` from the distributed API
    find_all = bool(kwargs.get("find_all", kwargs.get("find_all_solutions", False)))
    max_solutions = kwargs.get("max_solutions")

    # Auswahl der Propagationsmethode:
    # - per Suffix, z. B. "mac-vlac" oder "fc-gac"
    # - oder per Keyword-Argument propagation="vlac"/"gac"
    propagation = kwargs.get("propagation")
    if "-" in algorithm:
        base, suffix = algorithm.split("-", 1)
        if suffix in ("gac", "vlac"):
            propagation = suffix
            algorithm = base

    counters = Counters() if collect_metrics else None

    with BenchmarkTimer() as t:
        if algorithm in ("bt", "backtracking"):
            res = solvers.solve_backtracking(
                csp,
                reduced_domains=reduced_domains,
                heuristics=kwargs.get("heuristics"),
                find_all=find_all,
                counters=counters,
                deterministic=deterministic,
            )
            algo = "bt"

        elif algorithm in ("fc", "forward-checking", "forward_checking"):
            res = solvers.solve_forward_checking(
                csp,
                reduced_domains=reduced_domains,
                heuristics=kwargs.get("heuristics"),
                find_all=find_all,
                counters=counters,
                deterministic=deterministic,
                propagation=propagation,
            )
            algo = "fc" if not propagation else f"fc-{propagation}"

        elif algorithm in ("mac", "maintaining-arc-consistency", "maintaining_arc_consistency"):
            prop = propagation or "gac"
            res = solvers.solve_mac(
                csp,
                reduced_domains=reduced_domains,
                heuristics=kwargs.get("heuristics"),
                find_all=find_all,
                counters=counters,
                deterministic=deterministic,
                propagation=prop,
            )
            algo = "mac" if not propagation else f"mac-{propagation}"

        elif algorithm in ("mc", "min-conflicts", "minconflicts"):
            res = solvers.solve_min_conflicts(
                csp,
                reduced_domains=reduced_domains,
                max_steps=kwargs.get("max_steps", 10000),
                restarts=kwargs.get("restarts", 1),
                random_seed=kwargs.get("random_seed"),
                counters=counters,
                deterministic=deterministic,
            )
            algo = "mc"

        else:
            raise ValueError(f"Unknown search algorithm: {algorithm}")


    # Optional: decode solutions back to the primal variable space for binarized CSPs.
    # This keeps binarization transparent for typical usage (you can disable via decode_solutions=False).
    if kwargs.get("decode_solutions", True):
        try:
            from .encodings import EncodingInfo, decode_assignment
            info = getattr(csp, "encoding_info", None)
            if isinstance(info, EncodingInfo):
                keep_aux = bool(kwargs.get("keep_aux_vars", False))
                res["solutions"] = [decode_assignment(csp, s, keep_aux=keep_aux) for s in res["solutions"]]
        except Exception:
            # If decoding fails, fall back to the raw encoded assignments.
            pass

    solutions = list(res["solutions"])
    if max_solutions is not None:
        solutions = solutions[: max(0, int(max_solutions))]

    return SearchResult(
        algorithm=algo,
        solutions=solutions,
        runtime=t.elapsed,
        steps=res.get("steps", 0),
        average_depth=res.get("average_depth", 0.0),
        metrics=counters or {},
    )


def print_result(res):
    # Keep the CSP layer lightweight: DCSP types are imported lazily.
    try:
        from dcsp.results import DistributedSearchResult  # type: ignore
    except Exception:
        DistributedSearchResult = None  # type: ignore

    if isinstance(res, PropagationResult):
        print(
            f"[PROP] algo={res.algorithm} ok={res.ok} runtime={res.runtime:.4f}s "
            f"values_removed={res.metrics.get('values_removed','-')}"
        )
    elif isinstance(res, SearchResult):
        print(
            f"[SRCH] algo={res.algorithm} sols={len(res.solutions)} runtime={res.runtime:.4f}s steps={res.steps}"
        )
    elif DistributedSearchResult is not None and isinstance(res, DistributedSearchResult):
        # Treat timeout/abort/inconclusive as separate outcomes (not UNSAT).
        r = (getattr(res, "reason", "") or "").lower().strip()
        if r == "timeout":
            status = "TIMEOUT"
        elif r in ("aborted", "abort"):
            status = "ABORT"
        elif r == "inconclusive":
            status = "INCONCLUSIVE"
        else:
            status = "SAT" if getattr(res, "satisfiable", False) else "UNSAT"

        metrics = getattr(res, "metrics", {}) or {}
        msgs = metrics.get("messages_sent", 0)
        checks = metrics.get("constraint_checks", 0)
        par_avg = metrics.get("parallelism_avg_active_ticks", 0.0)
        par_max = metrics.get("parallelism_max_active_agents", 0)
        arch = getattr(res, "architecture", "")
        prefix = f"arch={arch} " if arch else ""

        nsol = len(getattr(res, "solutions", []) or [])
        sol_part = f" sols={nsol}" if nsol else ""

        print(
            f"[DCSP] {prefix}algo={getattr(res, 'algorithm', '?')} {status}{sol_part} "
            f"runtime={getattr(res, 'runtime', 0.0):.4f}s sim_time={getattr(res, 'sim_time', 0)} "
            f"msgs={msgs} checks={checks} par_avg={par_avg:.2f} par_max={par_max} reason={getattr(res, 'reason', '')}"
        )
    else:
        # Be explicit instead of silently printing nothing.
        print(f"[INFO] Unknown result type: {type(res).__name__}")
