
from __future__ import annotations

from typing import Dict, Set, List, Any, Sequence
import math
import re

# Keep eval() reasonably safe, but still practical for typical CSP expressions.
# We expose a small whitelist of pure functions that are common in constraints.
SAFE_GLOBALS = {
    "__builtins__": {},
    "math": math,
    "abs": abs,
    "min": min,
    "max": max,
    "sum": sum,
    "round": round,
    "len": len,
    "all": all,
    "any": any,
}

class Variable:
    def __init__(self, name: str, domain: Set[Any]):
        self.name = name
        self.domain = set(domain)

class Constraint:
    def __init__(self, name: str, expression: str, variables: List[str]):
        self.name = name
        self.expression = expression
        self.variables = list(variables)
    def evaluate(self, assignment: Dict[str, Any]) -> bool:
        if not all(v in assignment for v in self.variables):
            return True
        local = dict(assignment)
        try:
            return bool(eval(self.expression, SAFE_GLOBALS, local))
        except Exception:
            return False

class CSP:
    def __init__(self):
        self.variables: Dict[str, Variable] = {}
        self.constraints: Dict[str, Constraint] = {}
        self.constraints_by_var: Dict[str, List[str]] = {}
        self.graph = None
    def add_variable(self, name: str, domain: Set[Any]):
        self.variables[name] = Variable(name, domain)
    def add_constraint(self, name: str, expression: str):
        # Backward-compatible heuristic: detect variable identifiers appearing in the expression.
        # Prefer boundary-aware matching to avoid false positives (e.g., x1 in x10).
        vars_in: List[str] = []
        for v in sorted(self.variables.keys(), key=len, reverse=True):
            pat = re.compile(rf"(?<![A-Za-z0-9_]){re.escape(v)}(?![A-Za-z0-9_])")
            if pat.search(expression):
                vars_in.append(v)
        self.add_constraint_explicit(name, expression, vars_in)

    def add_constraint_explicit(self, name: str, expression: str, variables: Sequence[str]):
        self.constraints[name] = Constraint(name, expression, list(variables))
        for v in variables:
            self.constraints_by_var.setdefault(v, []).append(name)

    def to_graph(self):
        """Build and store a bipartite CSP graph with variable and constraint nodes.

        Hyperedges are represented explicitly through constraint nodes connected to all
        involved variable nodes. The resulting graph is stored in ``self.graph``.
        """
        try:
            import networkx as nx
        except Exception as e:
            raise ImportError("networkx is required for CSP graph export. Install it via 'pip install networkx'.") from e

        g = nx.Graph()

        for vname, var in self.variables.items():
            g.add_node(
                vname,
                kind="variable",
                label=vname,
                name=var.name,
                domain=set(var.domain),
                csp_object=var,
            )

        for cname, cons in self.constraints.items():
            g.add_node(
                cname,
                kind="constraint",
                label=cname,
                name=cons.name,
                expression=cons.expression,
                variables=tuple(cons.variables),
                csp_object=cons,
            )
            for v in cons.variables:
                if v in self.variables:
                    g.add_edge(cname, v, kind="scope")

        self.graph = g
        return g

    def visualize_graph(
        self,
        *,
        ax=None,
        with_labels: bool = True,
        variable_color: str = "#4C78A8",
        constraint_color: str = "#F58518",
        layout: str = "spring",
        figsize: tuple = (10, 7),
        node_size: int = 1200,
        font_size: int = 9,
        edge_color: str = "#888888",
        show: bool = True,
    ):
        """Visualize the stored CSP graph (or build it if missing).

        Variable and constraint nodes are colored differently. Labels are the variable
        or constraint names. Node attributes carry CSP properties (domain, expression,
        variable scope, and the original object reference).
        """
        try:
            import matplotlib.pyplot as plt
        except Exception as e:
            raise ImportError("matplotlib is required for graph visualization. Install it via 'pip install matplotlib'.") from e

        g = self.graph if self.graph is not None else self.to_graph()

        if ax is None:
            _, ax = plt.subplots(figsize=figsize)

        variable_nodes = [n for n, d in g.nodes(data=True) if d.get("kind") == "variable"]
        constraint_nodes = [n for n, d in g.nodes(data=True) if d.get("kind") == "constraint"]

        if layout == "bipartite":
            pos = {}
            if variable_nodes:
                pos.update({n: (0, i) for i, n in enumerate(sorted(variable_nodes))})
            if constraint_nodes:
                pos.update({n: (1, i) for i, n in enumerate(sorted(constraint_nodes))})
        elif layout == "kamada_kawai":
            import networkx as nx
            pos = nx.kamada_kawai_layout(g)
        elif layout == "circular":
            import networkx as nx
            pos = nx.circular_layout(g)
        else:
            import networkx as nx
            pos = nx.spring_layout(g, seed=42)

        import networkx as nx
        nx.draw_networkx_edges(g, pos, ax=ax, edge_color=edge_color, width=1.3)
        nx.draw_networkx_nodes(g, pos, nodelist=variable_nodes, node_color=variable_color, node_size=node_size, ax=ax)
        nx.draw_networkx_nodes(g, pos, nodelist=constraint_nodes, node_color=constraint_color, node_size=node_size, ax=ax)

        if with_labels:
            labels = {n: g.nodes[n].get("label", str(n)) for n in g.nodes}
            nx.draw_networkx_labels(g, pos, labels=labels, font_size=font_size, font_color="white", ax=ax)

        ax.set_axis_off()
        ax.set_title("CSP Hypergraph (bipartite variable/constraint view)")
        if show:
            plt.show()
        return ax

    @staticmethod
    def _format_solution_space(n: int) -> str:
        # Exact integer for small spaces, compact scientific notation for large ones.
        if n < 10_000:
            return str(n)
        s = str(n)
        exp = len(s) - 1
        if len(s) == 1:
            return f"{s}e0"
        # Two significant digits, omit decimal if the second digit is 0.
        d1, d2 = s[0], s[1]
        mant = d1 if d2 == "0" else f"{d1}.{d2}"
        return f"{mant}e{exp}"
    def summarize(self) -> str:
        n_vars = len(self.variables)
        dom_sizes = {v: len(var.domain) for v, var in self.variables.items()}
        space = 1
        for v in self.variables.values():
            space *= max(0, len(v.domain))
        n_cons = len(self.constraints)
        arities = [len(c.variables) for c in self.constraints.values()]
        unary = sum(1 for a in arities if a == 1)
        binary = sum(1 for a in arities if a == 2)
        nary = sum(1 for a in arities if a >= 3)
        space_str = self._format_solution_space(space)
        return (
            f"Variablen: {n_vars}, Constraints: {n_cons} (unär:{unary}, binär:{binary}, n-är:{nary}); "
            f"Domänen: {dom_sizes}; Suchraum: {space_str}"
        )

    def clone_with_domains(self, domains: Dict[str, Set[Any]]) -> "CSP":
        """Erzeugt ein neues CSP-Objekt mit identischer Struktur, aber (ggf.) reduzierten Domänen.

        Das Original-CSP bleibt unverändert. Constraints werden 1:1 übernommen.
        """
        new = CSP()
        for name, var in self.variables.items():
            new.add_variable(name, set(domains.get(name, var.domain)))
        for cid, cons in self.constraints.items():
            # Explizit übernehmen, damit keine Variablenerkennung nötig ist.
            new.add_constraint_explicit(cid, cons.expression, cons.variables)

        # Preserve optional encoding metadata (used for decoding solutions after binarization).
        if hasattr(self, "encoding_info"):
            new.encoding_info = getattr(self, "encoding_info")  # type: ignore[attr-defined]

        return new
