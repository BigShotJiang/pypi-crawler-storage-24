class BenchmarkTimer:
    def __enter__(self):
        import time
        self._t0 = time.perf_counter()
        self._elapsed = None  # finaler Messwert nach __exit__
        return self

    def __exit__(self, *args):
        import time
        self._elapsed = time.perf_counter() - self._t0

    @property
    def elapsed(self):
        """Verstrichene Zeit in Sekunden – funktioniert auch innerhalb des with-Blocks."""
        import time
        if getattr(self, "_t0", None) is None:
            return 0.0
        if self._elapsed is not None:
            return self._elapsed
        return time.perf_counter() - self._t0



class Counters(dict):
    def inc(self, key, by=1):
        self[key] = self.get(key, 0) + by
