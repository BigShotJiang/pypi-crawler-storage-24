from dataclasses import dataclass, field
from typing import Dict, Any, List, Set, Optional

@dataclass
class PropagationResult:
    algorithm: str
    ok: bool
    reduced_csp: Any
    runtime: float
    metrics: Dict[str, Any] = field(default_factory=dict)

@dataclass
class SearchResult:
    algorithm: str
    solutions: List[Dict[str, Any]]
    runtime: float
    steps: int
    average_depth: float
    metrics: Dict[str, Any] = field(default_factory=dict)
