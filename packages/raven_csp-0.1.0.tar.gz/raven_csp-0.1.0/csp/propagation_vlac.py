from __future__ import annotations

from typing import Dict, Set, Any, Optional, List, Tuple
from collections import deque
import re

import sympy as sp

# robuster Import – funktioniert sowohl im Paket als auch im Direktaufruf
try:
    from .instrument import BenchmarkTimer
except ImportError:
    from instrument import BenchmarkTimer


class VLACConstraint:
    """Einfache interne Darstellung eines Constraints für VLAC."""
    def __init__(self, variables: List[str], expr: str):
        self.variables = list(variables)
        self.expr = expr


# ============================================================
# Domänen / Constraints aus dem CSP holen
# ============================================================

def _collect_base_domains(
    csp,
    reduced_domains: Optional[Dict[str, Set[Any]]],
) -> Dict[str, Set[Any]]:
    """Holt pro Variable die aktuelle Domäne (ggf. mit reduced_domains überblendet)."""
    if reduced_domains is not None:
        base = {
            name: set(reduced_domains.get(name, var.domain))
            for name, var in csp.variables.items()
        }
    else:
        base = {name: set(var.domain) for name, var in csp.variables.items()}
    return base


def _adapt_constraints(csp) -> List[VLACConstraint]:
    """Überführt CSP-Constraints in eine einfache VLAC-Struktur."""
    adapted: List[VLACConstraint] = []
    for cid, cons in csp.constraints.items():
        expr = (
            getattr(cons, "expression", None)
            or getattr(cons, "constraint_string", None)
            or getattr(cons, "expr", None)
            or str(cons)
        )
        adapted.append(VLACConstraint(variables=list(cons.variables), expr=expr))
    return adapted


# ============================================================
# Relationen parsen (==, <=, >=, <, >)
# ============================================================

def _split_relational(expr: str):
    """
    Sucht nach genau einem Relations-Operator in einem Ausdruck ohne 'and'/'or'.
    Unterstützte Operatoren: ==, <=, >=, <, >
    Rückgabe: (left_str, op, right_str) oder None.
    """
    s = expr.strip()
    if " and " in s or " or " in s:
        return None

    # Reihenfolge wichtig: erst 2-stellige, dann 1-stellige Operatoren
    ops = ["<=", ">=", "==", "<", ">"]
    for op in ops:
        if op in s:
            parts = s.split(op)
            if len(parts) == 2:
                left, right = parts
                return left, op, right
    return None


def _parse_constraint_expr(constraint: VLACConstraint):
    """
    Parst constraint.expr in eine Residual-Expression g = lhs - rhs und ein 'sense':
      - 'eq' für ==
      - 'le' für <= oder <
      - 'ge' für >= oder >
    Rückgabe: (g_expr, symbols, sense) oder (None, symbols, None), falls nicht geeignet.
    """
    expr_str = constraint.expr

    # Variablensymbole
    symbols = {v: sp.symbols(v) for v in constraint.variables}

    # bekannte Funktionen (SymPy)
    sympy_funcs = {
        "exp": sp.exp,
        "sqrt": sp.sqrt,
        "sin": sp.sin,
        "cos": sp.cos,
        "tan": sp.tan,
        "log": sp.log,
        "log10": lambda x: sp.log(x, 10),
        "pi": sp.pi,
    }

    # math./np.-Präfixe entfernen
    expr_for_sympy = expr_str.replace("math.", "").replace("np.", "")

    split = _split_relational(expr_for_sympy)
    if split is None:
        # Kein einfacher Relationsoperator -> für VLAC-Expr ungeeignet
        return None, symbols, None

    left_str, op, right_str = split
    locals_map = {**symbols, **sympy_funcs}

    try:
        left = sp.sympify(left_str, locals=locals_map)
        right = sp.sympify(right_str, locals=locals_map)
    except Exception:
        return None, symbols, None

    try:
        g = left - right
    except Exception:
        return None, symbols, None

    if op == "==":
        sense = "eq"
    elif op in ("<=", "<"):
        sense = "le"
    elif op in (">=", ">"):
        sense = "ge"
    else:
        sense = None

    if isinstance(g, bool) or not isinstance(g, sp.Expr):
        return None, symbols, None

    return g, symbols, sense


# ============================================================
# Monotonie + isolierte Formen
# ============================================================

def _classify_monotonicity(
    g: Optional[sp.Expr],
    symbols: Dict[str, sp.Symbol],
    variables: List[str],
) -> Dict[str, str]:
    """
    Grobe Monotonie-Klassifikation je Variable für g(x,...) = lhs - rhs:
      - 'increasing', 'decreasing', 'constant', 'unknown'
    """
    if g is None or not isinstance(g, sp.Expr):
        return {v: "unknown" for v in variables}

    if not g.is_polynomial():
        return {v: "unknown" for v in variables}

    result: Dict[str, str] = {}
    for v in variables:
        sym = symbols[v]
        deriv = sp.diff(g, sym)
        if deriv.is_constant():
            if deriv == 0:
                result[v] = "constant"
            elif deriv > 0:
                result[v] = "increasing"
            elif deriv < 0:
                result[v] = "decreasing"
            else:
                result[v] = "unknown"
        else:
            result[v] = "unknown"
    return result


def _build_isolated_forms(
    g: Optional[sp.Expr],
    symbols: Dict[str, sp.Symbol],
    variables: List[str],
    domains: Dict[str, Set[Any]],
) -> Dict[str, Optional[sp.Expr]]:
    """
    Isoliert g(x,...) = 0 nach jeder Variable:
      - Standard: eindeutige Lösung -> direkt
      - Spezialfall: zwei Lösungen ±f und Domäne >= 0 -> sqrt(f**2)
    """
    if g is None or not isinstance(g, sp.Expr):
        return {v: None for v in variables}

    isolated: Dict[str, Optional[sp.Expr]] = {}
    for v in variables:
        sym = symbols[v]
        dom = domains.get(v)
        try:
            sols = sp.solve(g, sym, dict=True)
        except Exception:
            isolated[v] = None
            continue

        # 1 eindeutige Lösung
        if len(sols) == 1 and sym in sols[0]:
            isolated[v] = sols[0][sym]
            continue

        # 2 symmetrische Lösungen ±f, Domäne >= 0
        if len(sols) == 2 and all(sym in s for s in sols):
            if not dom:
                isolated[v] = None
                continue
            try:
                dmin = min(dom)
            except Exception:
                isolated[v] = None
                continue
            if dmin < 0:
                isolated[v] = None
                continue
            e1 = sols[0][sym]
            e2 = sols[1][sym]
            try:
                if sp.simplify(e1 + e2) == 0:
                    iso = sp.sqrt(sp.simplify(e1**2))
                    isolated[v] = iso
                else:
                    isolated[v] = None
            except Exception:
                isolated[v] = None
        else:
            isolated[v] = None

    return isolated


# ============================================================
# Bounds-Berechnung
# ============================================================

def _value_in_bounds(val: Any, min_val: float, max_val: float, eps: float = 1e-9) -> bool:
    """Prüft numerisch, ob ein Domänenwert innerhalb [min_val, max_val] liegt."""
    try:
        v = float(val)
        return (v + eps) >= min_val and (v - eps) <= max_val
    except Exception:
        # Nicht-numerische Werte lassen wir unangetastet
        return True


def _compute_bounds_for_isolated(
    target_var: str,
    iso_expr: sp.Expr,
    domains: Dict[str, Set[Any]],
) -> Tuple[Optional[float], Optional[float]]:
    """Berechnet Min/Max eines isolierten Ausdrucks f(...)."""

    free_syms = list(iso_expr.free_symbols)

    # 0) Konstante
    if len(free_syms) == 0:
        try:
            val = float(iso_expr.evalf())
        except Exception:
            return None, None
        return val, val

    # 1) Univariate Funktion
    if len(free_syms) == 1:
        sym = free_syms[0]
        name = str(sym)
        dom = domains.get(name)
        if not dom:
            return None, None
        try:
            dmin = min(dom)
            dmax = max(dom)
        except Exception:
            return None, None

        try:
            interval = sp.Interval(dmin, dmax)
        except Exception:
            return None, None

        deriv = sp.diff(iso_expr, sym)
        try:
            crit_set = sp.solveset(deriv, sym, domain=interval)
        except Exception:
            crit_set = sp.EmptySet

        crit_points: List[Any] = []
        if isinstance(crit_set, sp.FiniteSet):
            crit_points = list(crit_set)

        candidates: List[Any] = [dmin, dmax] + crit_points

        min_val = float("inf")
        max_val = float("-inf")
        for c in candidates:
            try:
                val = iso_expr.subs(sym, c)
                val = float(val.evalf())
            except Exception:
                continue
            if val < min_val:
                min_val = val
            if val > max_val:
                max_val = val

        if min_val == float("inf"):
            return None, None
        return min_val, max_val

    # 2) Mehrere freie Symbole
    # 2a) Spezialfall sqrt(polynomial)
    is_sqrt = False
    inner = None
    if isinstance(iso_expr, sp.Pow) and iso_expr.exp == sp.Rational(1, 2):
        inner = iso_expr.base
        is_sqrt = True
    elif iso_expr.func == sp.sqrt and len(iso_expr.args) == 1:
        inner = iso_expr.args[0]
        is_sqrt = True

    if is_sqrt and inner is not None and inner.is_polynomial():
        syms = list(inner.free_symbols)
        bounds: List[Tuple[sp.Symbol, Any, Any]] = []
        for sym in syms:
            name = str(sym)
            dom = domains.get(name)
            if not dom:
                return None, None
            try:
                dmin = min(dom)
                dmax = max(dom)
            except Exception:
                return None, None
            bounds.append((sym, dmin, dmax))

        from itertools import product

        inner_min = float("inf")
        inner_max = float("-inf")
        for choice in product([0, 1], repeat=len(bounds)):
            subs = {}
            for (sym, dmin, dmax), bit in zip(bounds, choice):
                subs[sym] = dmin if bit == 0 else dmax
            try:
                val = inner.subs(subs)
                val = float(val.evalf())
            except Exception:
                continue
            if val < inner_min:
                inner_min = val
            if val > inner_max:
                inner_max = val

        if inner_min == float("inf"):
            return None, None
        if inner_max < 0:
            return None, None

        min_val = 0.0 if inner_min <= 0 else inner_min**0.5
        max_val = inner_max**0.5
        return min_val, max_val

    # 2b) Allgemeiner linearer multivariater Ausdruck
    if not iso_expr.is_polynomial():
        return None, None
    for sym in free_syms:
        try:
            deg = sp.degree(iso_expr, sym)
        except Exception:
            return None, None
        if deg is None or deg > 1:
            return None, None

    bounds: List[Tuple[sp.Symbol, Any, Any]] = []
    for sym in free_syms:
        name = str(sym)
        dom = domains.get(name)
        if not dom:
            return None, None
        try:
            dmin = min(dom)
            dmax = max(dom)
        except Exception:
            return None, None
        bounds.append((sym, dmin, dmax))

    from itertools import product

    min_val = float("inf")
    max_val = float("-inf")
    for choice in product([0, 1], repeat=len(bounds)):
        subs = {}
        for (sym, dmin, dmax), bit in zip(bounds, choice):
            subs[sym] = dmin if bit == 0 else dmax
        try:
            val = iso_expr.subs(subs)
            val = float(val.evalf())
        except Exception:
            continue
        if val < min_val:
            min_val = val
        if val > max_val:
            max_val = val

    if min_val == float("inf"):
        return None, None
    return min_val, max_val


# ============================================================
# Lineare Koeffizienten extrahieren & (linear)**2-Pattern
# ============================================================

def _extract_linear_coeffs(expr: sp.Expr, symbols: Dict[str, sp.Symbol]):
    """
    Versucht, expr als lineare Funktion der gegebenen Symbole zu interpretieren:
        expr = c0 + sum_j a_j * x_j
    Rückgabe:
        (coeffs: Dict[str, float], c0: float) oder None, wenn nicht rein linear.
    """
    coeffs: Dict[str, float] = {}
    subs_zero = {sym: 0 for sym in symbols.values()}

    # Konstante bestimmen: expr an allen Variablen = 0 auswerten
    try:
        const_val = float(expr.subs(subs_zero))
    except Exception:
        return None

    for name, sym in symbols.items():
        deriv = sp.diff(expr, sym)
        # Keine Abhängigkeit von anderen Variablen erlaubt (sonst nicht rein linear)
        if deriv.free_symbols:
            return None
        try:
            a = float(deriv.evalf())
        except Exception:
            return None
        coeffs[name] = a

    return coeffs, const_val


def _try_quadratic_linear_ineq(
    cons: VLACConstraint,
    domains: Dict[str, Set[Any]],
) -> Tuple[bool, bool, Set[str]]:
    """
    Erkennung und Behandlung von Constraints der Form:
        (linear_expr)**2 <= const
    bzw. äquivalent:
        const >= (linear_expr)**2

    linear_expr = c0 + sum_j a_j * x_j, alle a_j reell.
    Verwendet nur Intervallgrenzen und reduziert Domänenobergrenzen der beteiligten Variablen.

    Rückgabe:
        handled  – ob dieses Pattern erkannt und verarbeitet wurde,
        ok       – ob der Constraint konsistent ist,
        updated  – Menge der Variablen, deren Domänen geändert wurden.
    """
    expr_str = cons.expr
    # math./np.-Präfixe entfernen (wie im Rest von VLAC)
    expr_for_sympy = expr_str.replace("math.", "").replace("np.", "")

    split = _split_relational(expr_for_sympy)
    if split is None:
        return False, True, set()

    left_str, op, right_str = split

    # nur Ungleichungen interessant
    if op not in ("<=", "<", ">=", ">"):
        return False, True, set()

    # Symbole und bekannte Funktionen für SymPy
    symbols = {v: sp.symbols(v) for v in cons.variables}
    sympy_funcs = {
        "exp": sp.exp,
        "sqrt": sp.sqrt,
        "sin": sp.sin,
        "cos": sp.cos,
        "tan": sp.tan,
        "log": sp.log,
        "log10": lambda x: sp.log(x, 10),
        "pi": sp.pi,
    }
    locals_map = {**symbols, **sympy_funcs}

    try:
        left = sp.sympify(left_str, locals=locals_map)
        right = sp.sympify(right_str, locals=locals_map)
    except Exception:
        return False, True, set()

    base_expr = None
    const_val = None
    op_norm = op  # normalisierte Richtung

    # Fall A: (linear)**2 OP const
    if isinstance(left, sp.Pow) and left.exp == 2 and right.is_number:
        base_expr = left.base
        try:
            const_val = float(right)
        except Exception:
            return False, True, set()

    # Fall B: const OP (linear)**2  -> ggf. umdrehen zu (linear)**2 <= const
    elif isinstance(right, sp.Pow) and right.exp == 2 and left.is_number:
        base_expr = right.base
        try:
            const_val = float(left)
        except Exception:
            return False, True, set()
        # Operator umdrehen
        if op == ">=":
            op_norm = "<="
        elif op == ">":
            op_norm = "<"
        elif op == "<=":
            op_norm = ">="
        elif op == "<":
            op_norm = ">"
        else:
            return False, True, set()
    else:
        # keine (linear)**2-Form
        return False, True, set()

    # Nur <=-artige Varianten behandeln: (linear)**2 <= const
    if op_norm not in ("<=", "<"):
        return False, True, set()

    # Konstante < 0 -> keine reellen Lösungen
    if const_val is None or const_val < 0:
        return True, False, set()

    # Basis muss linear sein
    lc = _extract_linear_coeffs(base_expr, symbols)
    if lc is None:
        return False, True, set()
    coeffs, c0 = lc

    # Intervallgrenzen von linear_expr bestimmen
    z_min = c0
    z_max = c0
    for name, a in coeffs.items():
        dom = domains.get(name)
        if not dom:
            continue
        try:
            dmin = min(dom)
            dmax = max(dom)
        except Exception:
            return False, True, set()
        if a >= 0:
            z_min += a * dmin
            z_max += a * dmax
        else:
            z_min += a * dmax
            z_max += a * dmin

    max_base = const_val**0.5

    # Wenn Basis schon im Minimum > sqrt(const), ist der Constraint unlösbar
    if z_min > max_base + 1e-9:
        return True, False, set()

    # Wenn Basis im Maximum bereits <= sqrt(const), ist Constraint nicht bindend
    if z_max <= max_base + 1e-9:
        return True, True, set()

    # Andernfalls: Ungleichung linear_expr <= max_base
    updated: Set[str] = set()

    # Für jede Variable versuchen, eine neue Obergrenze abzuleiten
    for name, a_k in coeffs.items():
        if abs(a_k) < 1e-12:
            continue  # Variable kommt in der Basis faktisch nicht vor
        dom_k = domains.get(name)
        if not dom_k:
            continue
        try:
            l_k = min(dom_k)
            u_k = max(dom_k)
        except Exception:
            continue

        # Minimale Beiträge der anderen Variablen (für max x_k)
        min_other = c0
        for other_name, a_j in coeffs.items():
            if other_name == name:
                continue
            dom_j = domains.get(other_name)
            if not dom_j:
                continue
            try:
                dmin_j = min(dom_j)
                dmax_j = max(dom_j)
            except Exception:
                continue
            if a_j >= 0:
                min_other += a_j * dmin_j
            else:
                min_other += a_j * dmax_j

        # x_k <= (max_base - min_other) / a_k
        if a_k > 0:
            u_allowed = (max_base - min_other) / a_k
        else:
            # Für a_k < 0 würde sich die Richtung der Ungleichung invertieren;
            # hier brechen wir zur Sicherheit ab.
            continue

        # Domäne diskret auf Werte <= u_allowed beschränken
        new_dom_k = {v for v in dom_k if float(v) <= u_allowed + 1e-9}

        if not new_dom_k:
            # keine Werte mehr möglich -> Inkonsistenz
            return True, False, updated

        if new_dom_k != dom_k:
            domains[name] = new_dom_k
            updated.add(name)

    return True, True, updated


# ============================================================
# Diskrete Relationen (== / != / < / > / <= / >=) stringbasiert
# ============================================================

_REL_PATTERN = re.compile(
    r'^\s*([A-Za-z_][A-Za-z0-9_]*|-?\d+(?:\.\d+)?)\s*(==|!=|<=|>=|<|>)\s*([A-Za-z_][A-Za-z0-9_]*|-?\d+(?:\.\d+)?)\s*$'
)


def _parse_simple_rel(expr: str):
    """Parst einfache 'lhs OP rhs' ohne 'and/or'. kind ∈ {'var','const'}."""
    s = expr.strip()
    if " or " in s or " and " in s:
        return None
    m = _REL_PATTERN.match(s)
    if not m:
        return None
    left, op, right = m.group(1), m.group(2), m.group(3)

    def parse_term(t: str):
        try:
            v = float(t)
            return "const", v
        except ValueError:
            return "var", t

    lk, lv = parse_term(left)
    rk, rv = parse_term(right)
    return lk, lv, op, rk, rv


def _propagate_discrete_rel(simple_rel, domains: Dict[str, Set[Any]]) -> Tuple[bool, Set[str]]:
    """Wertweise Propagation für einfache diskrete Relationen."""
    updated: Set[str] = set()
    if simple_rel is None:
        return True, updated

    lk, lv, op, rk, rv = simple_rel

    def same_value(d, c):
        try:
            return float(d) == float(c)
        except Exception:
            return d == c

    ok = True

    # Hilfsfunktionen für Var-Const und Var-Var
    def _vc_le(vname, c):
        if vname in domains:
            dom = domains[vname]
            new_dom = {d for d in dom if not (float(d) > float(c))}
            return vname, dom, new_dom
        return None, None, None

    def _vc_ge(vname, c):
        if vname in domains:
            dom = domains[vname]
            new_dom = {d for d in dom if not (float(d) < float(c))}
            return vname, dom, new_dom
        return None, None, None

    def _vc_lt(vname, c):
        if vname in domains:
            dom = domains[vname]
            new_dom = {d for d in dom if float(d) < float(c)}
            return vname, dom, new_dom
        return None, None, None

    def _vc_gt(vname, c):
        if vname in domains:
            dom = domains[vname]
            new_dom = {d for d in dom if float(d) > float(c)}
            return vname, dom, new_dom
        return None, None, None

    # ---------------- Equality / Inequality ----------------
    if op == "==":
        # var == const
        if lk == "var" and rk == "const":
            vname = lv
            if vname in domains:
                dom = domains[vname]
                new_dom = {d for d in dom if same_value(d, rv)}
                if new_dom != dom:
                    domains[vname] = new_dom
                    updated.add(vname)
                    if not new_dom:
                        return False, updated
        # const == var
        elif lk == "const" and rk == "var":
            vname = rv
            if vname in domains:
                dom = domains[vname]
                new_dom = {d for d in dom if same_value(d, lv)}
                if new_dom != dom:
                    domains[vname] = new_dom
                    updated.add(vname)
                    if not new_dom:
                        return False, updated
        # var == var
        elif lk == "var" and rk == "var":
            v1 = lv
            v2 = rv
            if v1 in domains and v2 in domains:
                dom1 = domains[v1]
                dom2 = domains[v2]
                inter = dom1 & dom2
                if inter != dom1:
                    domains[v1] = inter
                    updated.add(v1)
                    if not inter:
                        return False, updated
                if inter != dom2:
                    domains[v2] = inter
                    updated.add(v2)
                    if not inter:
                        return False, updated

    elif op == "!=":
        # var != const
        if lk == "var" and rk == "const":
            vname = lv
            if vname in domains:
                dom = domains[vname]
                new_dom = {d for d in dom if not same_value(d, rv)}
                if new_dom != dom:
                    domains[vname] = new_dom
                    updated.add(vname)
                    if not new_dom:
                        return False, updated
        # const != var
        elif lk == "const" and rk == "var":
            vname = rv
            if vname in domains:
                dom = domains[vname]
                new_dom = {d for d in dom if not same_value(d, lv)}
                if new_dom != dom:
                    domains[vname] = new_dom
                    updated.add(vname)
                    if not new_dom:
                        return False, updated
        # var != var
        elif lk == "var" and rk == "var":
            v1 = lv
            v2 = rv
            if v1 in domains and v2 in domains:
                dom1 = domains[v1]
                dom2 = domains[v2]
                # Wenn eine Seite singleton ist, entferne diesen Wert auf der anderen Seite
                if len(dom1) == 1:
                    c = next(iter(dom1))
                    new_dom2 = {d for d in dom2 if not same_value(d, c)}
                    if new_dom2 != dom2:
                        domains[v2] = new_dom2
                        updated.add(v2)
                        if not new_dom2:
                            return False, updated
                if len(dom2) == 1:
                    c = next(iter(dom2))
                    new_dom1 = {d for d in dom1 if not same_value(d, c)}
                    if new_dom1 != dom1:
                        domains[v1] = new_dom1
                        updated.add(v1)
                        if not new_dom1:
                            return False, updated

    # ---------------- Order relations ----------------
    elif op in ("<", "<=", ">", ">="):

        # var < const / <= const / > const / >= const
        if lk == "var" and rk == "const":
            vname = lv
            c = rv
            if op == "<":
                vname, dom, new_dom = _vc_lt(vname, c)
            elif op == "<=":
                vname, dom, new_dom = _vc_le(vname, c)
            elif op == ">":
                vname, dom, new_dom = _vc_gt(vname, c)
            else:  # >=
                vname, dom, new_dom = _vc_ge(vname, c)

            if vname is not None and new_dom is not None and new_dom != dom:
                domains[vname] = new_dom
                updated.add(vname)
                if not new_dom:
                    return False, updated

        # const < var / ...
        elif lk == "const" and rk == "var":
            vname = rv
            c = lv
            if op == "<":
                # c < var  => var > c
                vname, dom, new_dom = _vc_gt(vname, c)
            elif op == "<=":
                # c <= var => var >= c
                vname, dom, new_dom = _vc_ge(vname, c)
            elif op == ">":
                # c > var  => var < c
                vname, dom, new_dom = _vc_lt(vname, c)
            else:  # >=
                # c >= var => var <= c
                vname, dom, new_dom = _vc_le(vname, c)

            if vname is not None and new_dom is not None and new_dom != dom:
                domains[vname] = new_dom
                updated.add(vname)
                if not new_dom:
                    return False, updated

        # var ? var
        elif lk == "var" and rk == "var":
            v1 = lv
            v2 = rv
            if v1 in domains and v2 in domains:
                dom1 = domains[v1]
                dom2 = domains[v2]

                # nur schwache Propagation: wenn eine Domäne singleton ist,
                # leite Bounds für die andere ab
                if len(dom1) == 1:
                    c = float(next(iter(dom1)))
                    if op == "<":
                        # v1 < v2 -> v2 > c
                        _, dom, new_dom = _vc_gt(v2, c)
                    elif op == "<=":
                        # v1 <= v2 -> v2 >= c
                        _, dom, new_dom = _vc_ge(v2, c)
                    elif op == ">":
                        # v1 > v2 -> v2 < c
                        _, dom, new_dom = _vc_lt(v2, c)
                    else:  # >=
                        # v1 >= v2 -> v2 <= c
                        _, dom, new_dom = _vc_le(v2, c)
                    if new_dom is not None and new_dom != dom:
                        domains[v2] = new_dom
                        updated.add(v2)
                        if not new_dom:
                            return False, updated

                if len(dom2) == 1:
                    c = float(next(iter(dom2)))
                    if op == "<":
                        # v1 < v2 -> v1 < c
                        _, dom, new_dom = _vc_lt(v1, c)
                    elif op == "<=":
                        # v1 <= v2 -> v1 <= c
                        _, dom, new_dom = _vc_le(v1, c)
                    elif op == ">":
                        # v1 > v2 -> v1 > c
                        _, dom, new_dom = _vc_gt(v1, c)
                    else:  # >=
                        # v1 >= v2 -> v1 >= c
                        _, dom, new_dom = _vc_ge(v1, c)
                    if new_dom is not None and new_dom != dom:
                        domains[v1] = new_dom
                        updated.add(v1)
                        if not new_dom:
                            return False, updated

    return ok, updated


# ============================================================
# Queue-Verarbeitung: diskret + Patterns + Intervalle
# ============================================================

def _process_queue(
    domains: Dict[str, Set[Any]],
    constraints: List[VLACConstraint],
    *,
    verbose: bool = False,
    counters=None,
):
    """VLAC-Propagation: diskrete Relationen + Pattern-Handling + Intervall-Propagation."""
    # Variable -> Constraints
    var_to_cons: Dict[str, List[int]] = {}
    for idx, cons in enumerate(constraints):
        for v in cons.variables:
            var_to_cons.setdefault(v, []).append(idx)

    queue = deque(range(len(constraints)))
    in_queue = set(queue)

    monotonicity_info: Dict[int, Dict[str, str]] = {}
    queue_pops = 0
    domain_updates = 0
    revision_calls = 0
    constraint_evaluations = 0  # VLAC does not call Constraint.evaluate by design.
    ok = True

    while queue:
        cid = queue.popleft()
        in_queue.discard(cid)
        queue_pops += 1

        cons = constraints[cid]

        # For benchmarking, treat "revision" as (constraint, variable) processing.
        revision_calls += len(cons.variables)

        # 1a) Quadratisches (linear)**2 <= const-Pattern schnell behandeln
        handled_quad, ok_quad, updated_vars_quad = _try_quadratic_linear_ineq(cons, domains)
        if handled_quad:
            if not ok_quad:
                if verbose:
                    print(f"[VLAC]   Inconsistency detected in quadratic-linear pattern of constraint {cid}")
                return False, domains, monotonicity_info, queue_pops, domain_updates, revision_calls
            for v in updated_vars_quad:
                domain_updates += 1
                for nid in var_to_cons.get(v, []):
                    if nid not in in_queue:
                        queue.append(nid)
                        in_queue.add(nid)
            # Monotonie unbekannt, aber für dieses Pattern nicht relevant
            monotonicity_info[cid] = {v: "unknown" for v in cons.variables}
            if updated_vars_quad:
                if verbose:
                    print(f"[VLAC]   Quadratic-linear pattern applied on constraint {cid}, updated: {sorted(updated_vars_quad)}")
            # Dieser Constraint ist für diesen Pop fertig
            continue

        # 1b) Diskrete ==/!=/</>/<=/>=-Behandlung
        simple_rel = _parse_simple_rel(cons.expr)
        # Only treat it as "simple" if variable tokens are actual CSP variables.
        if simple_rel is not None:
            lk, lv, op, rk, rv = simple_rel
            if lk == "var" and lv not in domains:
                simple_rel = None
            if rk == "var" and rv not in domains:
                simple_rel = None

        if simple_rel is not None:
            ok_rel, updated_vars = _propagate_discrete_rel(simple_rel, domains)
            if not ok_rel:
                if verbose:
                    print(f"[VLAC]   Inconsistency detected in discrete handling of constraint {cid}")
                return False, domains, monotonicity_info, queue_pops, domain_updates, revision_calls
            for v in updated_vars:
                domain_updates += 1
                for nid in var_to_cons.get(v, []):
                    if nid not in in_queue:
                        queue.append(nid)
                        in_queue.add(nid)

            # For true var/const or var/var relations, discrete propagation is complete.
            # Skipping the symbolic part avoids unnecessary overhead and benchmarking bias.
            continue

        # 2) SymPy-Residual g, Symbole, sense (eq/le/ge)
        g, symbols, sense = _parse_constraint_expr(cons)

        # 3) Monotonieklassifikation
        mono = _classify_monotonicity(g, symbols, cons.variables)
        monotonicity_info[cid] = mono

        # 4) Isolierte Formen g=0 -> x = f(...)
        isolated = _build_isolated_forms(g, symbols, cons.variables, domains)

        # Debug-Ausgabe (optional)
        if verbose:
            print(f"[VLAC] Constraint {cid}: expr = {cons.expr}")
            print(f"[VLAC]   Sense: {sense}")
            print(f"[VLAC]   Monotonicity: {mono}")
            print(f"[VLAC]   Isolated forms:")
            for v, form in isolated.items():
                print(f"[VLAC]     {v} = {form}")

        # 5) Intervall-Propagation je Variable
        for v in cons.variables:
            iso_expr = isolated.get(v)
            if iso_expr is None or not isinstance(iso_expr, sp.Expr):
                continue

            min_val, max_val = _compute_bounds_for_isolated(v, iso_expr, domains)
            if verbose:
                print(f"[VLAC]   Bounds for {v}: [{min_val}, {max_val}]")
            if min_val is None or max_val is None:
                continue

            old_dom = domains.get(v)
            if not old_dom:
                continue

            mono_v = mono.get(v, "unknown")

            # Je nach sense und Monotonie erlaubte Intervallgrenzen bestimmen
            if sense in ("le",):  # g <= 0
                if mono_v == "increasing":
                    lower = float("-inf")
                    upper = max_val
                elif mono_v == "decreasing":
                    lower = min_val
                    upper = float("inf")
                else:
                    # keine sichere Aussage -> nicht schneiden
                    continue
            elif sense in ("ge",):  # g >= 0
                if mono_v == "increasing":
                    lower = min_val
                    upper = float("inf")
                elif mono_v == "decreasing":
                    lower = float("-inf")
                    upper = max_val
                else:
                    continue
            else:
                # eq oder unbekannt: nur „Range einschränken“
                lower = min_val
                upper = max_val

            new_dom = {val for val in old_dom if _value_in_bounds(val, lower, upper)}
            if new_dom != old_dom:
                if verbose:
                    print(f"[VLAC]   Domain update for {v}: {sorted(old_dom)} -> {sorted(new_dom)}")
                domains[v] = new_dom
                domain_updates += 1
                if not new_dom:
                    if verbose:
                        print(f"[VLAC]   Domain of {v} became empty -> inconsistency")
                    return False, domains, monotonicity_info, queue_pops, domain_updates, revision_calls
                for nid in var_to_cons.get(v, []):
                    if nid not in in_queue:
                        queue.append(nid)
                        in_queue.add(nid)

    # Note: constraint_evaluations is intentionally 0 (VLAC is symbolic/interval based).
    if counters is not None:
        counters.inc("queue_pops", by=queue_pops)
        counters.inc("revision_calls", by=revision_calls)
        counters.inc("domain_updates", by=domain_updates)

    return ok, domains, monotonicity_info, queue_pops, domain_updates, revision_calls


# ============================================================
# Externe API
# ============================================================

def run_vlac(
    csp,
    reduced_domains: Optional[Dict[str, Set[Any]]] = None,
    counters=None,
    verbose: bool = False,
):
    """VLAC – diskrete Relationen plus Pattern- & Intervall-Propagation."""

    # 1) Domänen-Snapshot
    base_domains = _collect_base_domains(csp, reduced_domains)
    working_domains = {name: set(dom) for name, dom in base_domains.items()}

    # 2) Constraints adaptieren
    vlac_constraints = _adapt_constraints(csp)

    # 3) Queue abarbeiten (runtime is measured in the API layer for comparability)
    ok, new_domains, monotonicity_info, queue_pops, domain_updates, revision_calls = _process_queue(
        working_domains,
        vlac_constraints,
        verbose=verbose,
        counters=counters,
    )

    # 4) Werteentfernung relativ zum ursprünglichen Snapshot zählen
    values_removed = 0
    for v in base_domains:
        if v in new_domains:
            values_removed += len(base_domains[v] - new_domains[v])

    metrics = {
        "values_removed": values_removed,
        "queue_pops": queue_pops,
        "revision_calls": revision_calls,
        "domain_updates": domain_updates,
        "constraint_evaluations": 0,
        "queue_item_type": "constraint",
    }

    if counters is not None:
        counters.inc("vlac_runs")

    return ok, csp.clone_with_domains(new_domains), metrics
