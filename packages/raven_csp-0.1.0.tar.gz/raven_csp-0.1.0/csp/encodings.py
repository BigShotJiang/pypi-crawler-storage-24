from __future__ import annotations

from dataclasses import dataclass
import time
from itertools import product
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Set, Tuple

from .core import CSP, Constraint, Variable
from .instrument import BenchmarkTimer
from .metrics import BinarizationReport, compute_csp_metrics, summarize_binarization


@dataclass
class EncodingInfo:
    encoding: str
    # Maps original constraint name -> encoded variable name (dual/hidden variable)
    constraint_var: Dict[str, str]
    # For hidden/double/dual: maps encoded var -> scope (ordered original variable names)
    scope: Dict[str, List[str]]

    # Original problem signature (for decoding solutions back to the primal CSP).
    original_variables: List[str]
    original_domains: Dict[str, List[Any]]

    # Wall-clock time for the transformation in seconds
    transform_time_s: float = 0.0



def _sorted_domain(dom: Iterable[Any]) -> List[Any]:
    # Deterministic order, even for mixed types.
    return sorted(list(dom), key=lambda x: repr(x))


def _add_constraint_explicit(csp: CSP, name: str, expression: str, variables: Sequence[str]) -> None:
    csp.constraints[name] = Constraint(name, expression, list(variables))
    for v in variables:
        csp.constraints_by_var.setdefault(v, []).append(name)


def _satisfying_tuples(csp: CSP, cons: Constraint) -> Tuple[List[str], Set[Tuple[Any, ...]]]:
    scope = list(cons.variables)
    if not scope:
        # 0-ary constraint: either always true or always false.
        ok = bool(cons.evaluate({}))
        return [], {()} if ok else set()

    doms = [_sorted_domain(csp.variables[v].domain) for v in scope]
    sat: Set[Tuple[Any, ...]] = set()
    for values in product(*doms):
        assign = {v: values[i] for i, v in enumerate(scope)}
        if cons.evaluate(assign):
            sat.add(tuple(values))
    return scope, sat


def hidden_variable_encoding(csp: CSP, *, prefix: str = "__H_") -> CSP:
    """Hidden Variable Encoding (HVE).

    Creates a hidden variable for *each* original constraint. The hidden variable's
    domain is the set of satisfying tuples for that constraint. Then adds binary
    constraints between each original variable Xi and the hidden variable H_C
    enforcing Xi == H_C[pos].

    Result has only binary constraints.
    """
    out = CSP()

    # Copy original variables.
    for v, var in csp.variables.items():
        out.variables[v] = Variable(v, set(var.domain))

    info = EncodingInfo(encoding="hidden", constraint_var={}, scope={}, original_variables=list(csp.variables.keys()), original_domains={v: _sorted_domain(csp.variables[v].domain) for v in csp.variables})

    # Add hidden variables and binary links.
    for cname, cons in csp.constraints.items():
        scope, sat = _satisfying_tuples(csp, cons)
        hname = f"{prefix}{cname}"
        # Ensure unique variable name.
        k = 0
        base = hname
        while hname in out.variables:
            k += 1
            hname = f"{base}_{k}"

        out.variables[hname] = Variable(hname, set(sat))
        info.constraint_var[cname] = hname
        info.scope[hname] = list(scope)

        # For each Xi in scope add Xi == H[i]
        for i, xi in enumerate(scope):
            expr = f"({xi} == {hname}[{i}])"
            _add_constraint_explicit(out, f"__hve_{cname}_{xi}", expr, [xi, hname])

    # Ensure constraints_by_var exists for variables without constraints.
    for v in out.variables:
        out.constraints_by_var.setdefault(v, [])

    out.encoding_info = info  # type: ignore[attr-defined]
    return out


def dual_encoding(csp: CSP, *, prefix: str = "__D_") -> CSP:
    """Dual Encoding (DE).

    Creates a dual variable for each original constraint (including unary).
    Domain is the satisfying tuple set. Adds binary constraints between dual
    variables that share at least one original variable, enforcing equality
    on the shared positions.

    Result has only binary constraints.
    """
    out = CSP()
    info = EncodingInfo(encoding="dual", constraint_var={}, scope={}, original_variables=list(csp.variables.keys()), original_domains={v: _sorted_domain(csp.variables[v].domain) for v in csp.variables})

    # Dual variables for each constraint.
    for cname, cons in csp.constraints.items():
        scope, sat = _satisfying_tuples(csp, cons)
        dname = f"{prefix}{cname}"
        k = 0
        base = dname
        while dname in out.variables:
            k += 1
            dname = f"{base}_{k}"

        out.variables[dname] = Variable(dname, set(sat))
        info.constraint_var[cname] = dname
        info.scope[dname] = list(scope)

    # Constraints between dual variables for shared original variables.
    cnames = list(csp.constraints.keys())
    for i in range(len(cnames)):
        ci = cnames[i]
        di = info.constraint_var[ci]
        scope_i = info.scope[di]
        for j in range(i + 1, len(cnames)):
            cj = cnames[j]
            dj = info.constraint_var[cj]
            scope_j = info.scope[dj]
            shared = [v for v in scope_i if v in set(scope_j)]
            if not shared:
                continue
            parts = []
            for v in shared:
                ii = scope_i.index(v)
                jj = scope_j.index(v)
                parts.append(f"({di}[{ii}] == {dj}[{jj}])")
            expr = "(" + " and ".join(parts) + ")" if parts else "True"
            _add_constraint_explicit(out, f"__de_{ci}__{cj}", expr, [di, dj])

    for v in out.variables:
        out.constraints_by_var.setdefault(v, [])

    out.encoding_info = info  # type: ignore[attr-defined]
    return out


def double_encoding(csp: CSP, *, prefix: str = "__H_") -> CSP:
    """Double Encoding.

    This is HVE plus additional binary constraints between hidden variables
    (one per original constraint) analogous to the dual encoding. Hidden variables
    that share an original variable must agree on the corresponding tuple position.

    Result has only binary constraints.
    """
    out = CSP()

    # Copy original variables.
    for v, var in csp.variables.items():
        out.variables[v] = Variable(v, set(var.domain))

    info = EncodingInfo(encoding="double", constraint_var={}, scope={}, original_variables=list(csp.variables.keys()), original_domains={v: _sorted_domain(csp.variables[v].domain) for v in csp.variables})

    # Hidden variables and links (same as HVE)
    for cname, cons in csp.constraints.items():
        scope, sat = _satisfying_tuples(csp, cons)
        hname = f"{prefix}{cname}"
        k = 0
        base = hname
        while hname in out.variables:
            k += 1
            hname = f"{base}_{k}"

        out.variables[hname] = Variable(hname, set(sat))
        info.constraint_var[cname] = hname
        info.scope[hname] = list(scope)

        for i, xi in enumerate(scope):
            expr = f"({xi} == {hname}[{i}])"
            _add_constraint_explicit(out, f"__dbl_hve_{cname}_{xi}", expr, [xi, hname])

    # Hidden-hidden constraints (dual-style)
    cnames = list(csp.constraints.keys())
    for i in range(len(cnames)):
        ci = cnames[i]
        hi = info.constraint_var[ci]
        scope_i = info.scope[hi]
        for j in range(i + 1, len(cnames)):
            cj = cnames[j]
            hj = info.constraint_var[cj]
            scope_j = info.scope[hj]
            shared = [v for v in scope_i if v in set(scope_j)]
            if not shared:
                continue
            parts = []
            for v in shared:
                ii = scope_i.index(v)
                jj = scope_j.index(v)
                parts.append(f"({hi}[{ii}] == {hj}[{jj}])")
            expr = "(" + " and ".join(parts) + ")" if parts else "True"
            _add_constraint_explicit(out, f"__dbl_{ci}__{cj}", expr, [hi, hj])

    for v in out.variables:
        out.constraints_by_var.setdefault(v, [])

    out.encoding_info = info  # type: ignore[attr-defined]
    return out


def binarize_csp(csp: CSP, *, encoding: str = "hidden") -> CSP:
    """Convert a CSP with n-ary constraints to an equivalent CSP with only binary constraints.

    Parameters
    ----------
    csp
        Original CSP object.
    encoding
        One of: "dual", "hidden", "double" (case-insensitive). Aliases are accepted:
        - dual: "de"
        - hidden: "hve"
        - double: "dbl"

    Returns
    -------
    CSP
        A new CSP object with only binary constraints (and potentially additional variables).
    """
    enc = encoding.lower().strip()
    t0 = time.perf_counter()

    if enc in ("hidden", "hve", "hidden-variable", "hidden_variable"):
        out = hidden_variable_encoding(csp)
    elif enc in ("dual", "de", "dual-encoding", "dual_encoding"):
        out = dual_encoding(csp)
    elif enc in ("double", "dbl", "double-encoding", "double_encoding"):
        out = double_encoding(csp)
    else:
        raise ValueError("encoding must be one of: 'hidden' (HVE), 'dual' (DE), 'double'")

    dt = time.perf_counter() - t0

    # Persist transformation runtime in encoding_info
    info = getattr(out, "encoding_info", None)
    if info is None:
        out.encoding_info = {"encoding": enc, "transform_time_s": float(dt)}  # type: ignore[attr-defined]
    elif isinstance(info, EncodingInfo):
        info.transform_time_s = float(dt)
        info.encoding = info.encoding or enc
    elif isinstance(info, dict):
        info.setdefault("encoding", enc)
        info["transform_time_s"] = float(dt)

    return out


def binarize_csp_with_metrics(csp: CSP, *, encoding: str = "hidden") -> Tuple[CSP, BinarizationReport]:
    """Binarize a CSP and return quantitative complexity metrics (before/after) plus conversion time.

    This keeps the existing binarize_csp(..) API intact, while providing an
    instrumented variant for experiments.
    """
    before = compute_csp_metrics(csp)
    with BenchmarkTimer() as t:
        out = binarize_csp(csp, encoding=encoding)
    after = compute_csp_metrics(out)
    report = BinarizationReport(
        encoding=encoding,
        transform_time_s=t.elapsed,
        before=before,
        after=after,
        delta=summarize_binarization(before, after),
    )
    return out, report


def decode_assignment(encoded_csp: CSP, assignment: Mapping[str, Any], *, keep_aux: bool = False) -> Dict[str, Any]:
    """Decode an assignment of an encoded CSP back to the primal variables.

    - hidden/double: returns values for the original variables (drops auxiliary vars by default).
    - dual: reconstructs primal values from the selected tuples of the dual variables.

    For primal variables that do not occur in any constraint (possible with dual encoding),
    a deterministic representative value (first in the original domain) is chosen.
    """
    info = getattr(encoded_csp, "encoding_info", None)
    if not isinstance(info, EncodingInfo):
        return dict(assignment)

    out: Dict[str, Any] = {}

    # 1) Prefer explicit primal assignments if present (hidden/double keep them).
    for v in info.original_variables:
        if v in assignment:
            out[v] = assignment[v]

    # 2) Reconstruct missing primal variables from encoded tuple variables.
    for ev, scope in info.scope.items():
        if ev not in assignment:
            continue
        tup = assignment[ev]
        try:
            for i, v in enumerate(scope):
                if v in out:
                    if out[v] != tup[i]:
                        raise ValueError(
                            f"Inconsistent decode for variable '{v}': {out[v]} vs {tup[i]} (from {ev}[{i}])"
                        )
                else:
                    out[v] = tup[i]
        except TypeError as e:
            raise TypeError(f"Encoded variable '{ev}' does not carry an indexable tuple value: {tup!r}") from e

    # 3) Fill unconstrained primal variables deterministically.
    for v in info.original_variables:
        if v not in out:
            dom = info.original_domains.get(v, [])
            out[v] = dom[0] if dom else None

    if keep_aux:
        for k, v in assignment.items():
            if k not in out:
                out[k] = v

    return out
