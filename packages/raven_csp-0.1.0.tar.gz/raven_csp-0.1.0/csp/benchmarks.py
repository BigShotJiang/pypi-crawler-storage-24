from typing import Callable, Dict, List, Optional
from .core import CSP
from .excel import make_excel_csp_factory
import math

class ProblemSpec:
    def __init__(self, name: str, factory: Callable[[], CSP], *tags: str):
        self.name = name
        self.factory = factory
        self.tags = list(tags)

_REGISTRY: Dict[str, ProblemSpec] = {}


def register_problem(name: str, factory: Callable[[], CSP], *tags: str):
    _REGISTRY[name] = ProblemSpec(name, factory, *tags)

def load(names: List[str], excel_path: Optional[str] = None) -> List[ProblemSpec]:
    """Lädt die angegebenen Benchmark-Probleme."""
    if excel_path is not None:
        raise NotImplementedError("Laden aus Excel wird nicht mehr unterstützt.")
    loaded: List[ProblemSpec] = []
    for n in names:
        if n not in _REGISTRY:
            raise KeyError(f"Unbekanntes Problem '{n}' – verfügbar: {list(_REGISTRY.keys())}")
        loaded.append(_REGISTRY[n])
    return loaded

# ============================================================
# Sudoku-Givens: Hier bequem als 9x9-Liste pflegen (0/None = leer)
# ============================================================

GIVENS_SUDOKU: List[List[Optional[int]]] = [
    [5,3,0, 0,7,0, 0,0,0],
    [6,0,0, 1,9,5, 0,0,0],
    [0,9,8, 0,0,0, 0,6,0],

    [8,0,0, 0,6,0, 0,0,3],
    [4,0,0, 8,0,3, 0,0,1],
    [7,0,0, 0,2,0, 0,0,6],

    [0,6,0, 0,0,0, 2,8,0],
    [0,0,0, 4,1,9, 0,0,5],
    [0,0,0,  0,8,0, 0,7,9],
]

def _apply_givens_9x9(
    csp: CSP, givens: List[List[Optional[int]]], *, var_fmt: str = "X{r}{c}", zero_based: bool = True
) -> None:
    if len(givens) != 9 or any(len(row) != 9 for row in givens):
        raise ValueError("GIVENS muss 9×9 sein.")
    for rr in range(9):
        for cc in range(9):
            v = givens[rr][cc]
            if v not in (0, None) and not (isinstance(v, int) and 1 <= v <= 9):
                raise ValueError(f"Ungültiger Wert in GIVENS an ({rr+1},{cc+1}): {v}")

    base = 0 if zero_based else 1
    for rr in range(9):
        for cc in range(9):
            val = givens[rr][cc]
            if val in (0, None):
                continue
            vname = var_fmt.format(r=rr + base, c=cc + base)
            if vname not in csp.variables:
                raise KeyError(f"Variable {vname} nicht in csp.variables – var_fmt/Indexierung prüfen!")
            csp.variables[vname].domain = {int(val)}

# ======================= Beispielprobleme =======================

def send_more_money_single_factory():
    c = CSP()
    letters = list("SENDMORY")
    for ch in letters:
        c.add_variable(ch, set(range(10)))
    c.add_constraint("no_lead_S", "S != 0")
    c.add_constraint("no_lead_M", "M != 0")
    for i,a in enumerate(letters):
        for b in letters[i+1:]:
            c.add_constraint(f"neq_{a}_{b}", f"{a} != {b}")
    expr = "(1000*S+100*E+10*N+D) + (1000*M+100*O+10*R+E) == (10000*M+1000*O+100*N+10*E+Y)"
    c.add_constraint("eq", expr)
    return c

def send_more_money_carries_factory():
    c = CSP()
    for ch in list("SENDMORY"):
        c.add_variable(ch, set(range(10)))
    for k in range(1,5):
        c.add_variable(f"C{k}", {0,1})
    c.add_constraint("no_lead_S", "S != 0")
    c.add_constraint("no_lead_M", "M != 0")
    letters = list("SENDMORY")
    for i,a in enumerate(letters):
        for b in letters[i+1:]:
            c.add_constraint(f"neq_{a}_{b}", f"{a} != {b}")
    c.add_constraint("col1", "D + E == Y + 10*C1 or D + E + 1 == Y + 10*C1")
    c.add_constraint("col2", "N + R + C1 == E + 10*C2 or N + R + C1 + 1 == E + 10*C2")
    c.add_constraint("col3", "E + O + C2 == N + 10*C3 or E + O + C2 + 1 == N + 10*C3")
    c.add_constraint("col4", "S + M + C3 == O + 10*C4 or S + M + C3 + 1 == O + 10*C4")
    c.add_constraint("col5", "C4 == M")
    return c

def sudoku_binary_factory():
    c = CSP()
    for r in range(9):
        for co in range(9):
            c.add_variable(f"X{r}{co}", set(range(1,10)))
    # Zeilen/Spalten: AllDifferent via Binär-Constraints
    for i in range(9):
        row = [f"X{i}{j}" for j in range(9)]
        col = [f"X{j}{i}" for j in range(9)]
        for a in range(9):
            for b in range(a+1,9):
                c.add_constraint(f"row_{i}_{a}_{b}", f"{row[a]} != {row[b]}")
                c.add_constraint(f"col_{i}_{a}_{b}", f"{col[a]} != {col[b]}")
    # 3x3-Blöcke
    for br in range(3):
        for bc in range(3):
            cells = [f"X{r}{c2}" for r in range(br * 3, br * 3 + 3) for c2 in range(bc * 3, bc * 3 + 3)]
            for a in range(9):
                for b in range(a+1,9):
                    c.add_constraint(f"blk_{br}{bc}_{a}_{b}", f"{cells[a]} != {cells[b]}")
    # Givens anwenden (0-basierte Indizes, Var-Format X{r}{c})
    _apply_givens_9x9(c, GIVENS_SUDOKU, var_fmt="X{r}{c}", zero_based=True)
    return c

def sudoku_product_factory():
    target = math.factorial(9)
    c = CSP()
    for r in range(9):
        for co in range(9):
            c.add_variable(f"X{r}{co}", set(range(1,10)))
    for i in range(9):
        row=[f"X{i}{j}" for j in range(9)]
        col=[f"X{j}{i}" for j in range(9)]
        c.add_constraint(f"rowp_{i}", " * ".join(row) + f" == {target}")
        c.add_constraint(f"colp_{i}", " * ".join(col) + f" == {target}")
    for br in range(3):
        for bc in range(3):
            cells=[f"X{r}{c2}" for r in range(br*3, br*3+3) for c2 in range(bc*3, bc*3+3)]
            c.add_constraint(f"blkp_{br}{bc}", " * ".join(cells) + f" == {target}")
    _apply_givens_9x9(c, GIVENS_SUDOKU, var_fmt="X{r}{c}", zero_based=True)
    return c

# ============================================================
# Benchmark: Warehouse Location Problem (CSP-Variante)
# ============================================================
def warehouse_location_factory():
    c = CSP()

    # --- Instanzparameter ---
    W = [(0.0, 0.0), (10.0, 0.0), (5.0, 8.0)]     # 3 Lager
    CUST = [(2.0, 1.0), (8.0, 2.0), (6.0, 7.0), (1.0, 9.0)]  # 4 Kunden
    demands = [80.0, 65.0, 70.0, 90.0]   # Nachfrage je Kunde
    caps    = [160.0, 180.0, 200.0]      # Kapazität je Lager
    fix     = [500.0, 550.0, 600.0]      # Fixkosten je Lager
    unit    = 1.0                        # Transportkosten pro Distanz- und Nachfrageeinheit
    BUDGET  = 2200.0                     # Budget
    Q = [cap**2 for cap in caps]         # Quadratikschranken
    beta = 0.05
    R_max = 10.0

    def dist(a, b):
        return ((a[0]-b[0])**2 + (a[1]-b[1])**2) ** 0.5

    dij = [[dist(W[i], CUST[j]) for j in range(len(CUST))] for i in range(len(W))]
    cij = [[unit * dij[i][j] for j in range(len(CUST))] for i in range(len(W))]

    # Domains
    for i in range(len(W)):
        c.add_variable(f"y{i}", {0,1})

    def grid(start, stop, step):
        k = int(round((stop - start) / step))
        vals = [round(start + t*step, 10) for t in range(k+1)]
        return set(vals)

    X_DOMAIN = grid(0.0, 1.0, 0.1)
    for i in range(len(W)):
        for j in range(len(CUST)):
            c.add_variable(f"x{i}_{j}", set(X_DOMAIN))

    # Constraints
    for j in range(len(CUST)):
        lhs = " + ".join([f"x{i}_{j}" for i in range(len(W))])
        c.add_constraint(f"assign_full_c{j}", f"{lhs} == 1")

    for i in range(len(W)):
        lhs = " + ".join([f"{demands[j]}*x{i}_{j}" for j in range(len(CUST))])
        c.add_constraint(f"cap_{i}", f"{lhs} <= {caps[i]}*y{i}")

    fix_expr = " + ".join([f"{fix[i]}*y{i}" for i in range(len(W))])
    transp_expr = " + ".join([f"{cij[i][j]}*{demands[j]}*x{i}_{j}"
                              for i in range(len(W)) for j in range(len(CUST))]) or "0"
    c.add_constraint("budget", f"{fix_expr} + {transp_expr} <= {BUDGET}")

    for i in range(len(W)):
        lin = " + ".join([f"{demands[j]}*x{i}_{j}" for j in range(len(CUST))]) or "0"
        c.add_constraint(f"quad_load_{i}", f"({lin})**2 <= {Q[i]}")

    tot_dist = " + ".join([f"{dij[i][j]}*x{i}_{j}" for i in range(len(W)) for j in range(len(CUST))]) or "0"
    c.add_constraint("exp_total_distance", f"np.exp({beta}*({tot_dist})) <= {R_max}")

    return c


def manufacturbility_problem_factory():
    """Translated benchmark based on test.xlsx variable/constraint sheets."""
    csp = CSP()

    # Constants / fixed parameters
    csp.add_variable("dr_d_max", [50])
    csp.add_variable("dr_d_min", [20])
    csp.add_variable("dr_l_max", [200])
    csp.add_variable("dr_chip_removal_min", [1])
    csp.add_variable("fp_sigma_max_al", [300])
    csp.add_variable("fp_sigma_max_st", [400])
    csp.add_variable("fp_d_0", [40])
    csp.add_variable("fp_beta", [90])
    csp.add_variable("fp_l_1", [100])
    csp.add_variable("fp_l_2", [150])
    csp.add_variable("rs_wulstverlust", [10])
    csp.add_variable("rs_wulstverhaeltnis", [0])
    csp.add_variable("rs_d_min", [10])
    csp.add_variable("rs_d_max", [50])
    csp.add_variable("rs_l_max", [200])
    csp.add_variable("rs_l_min", [30])
    csp.add_variable("cbr_epsilon_a", [50])
    csp.add_variable("cbr_alpha", [120])
    csp.add_variable("cbr_beta", [90])
    csp.add_variable("f1_l_1", [15])
    csp.add_variable("f1_l_2", [20])
    csp.add_variable("f1_l_3", [15])
    csp.add_variable("f1_l_4", [20])
    csp.add_variable("f1_l_5", [40])
    csp.add_variable("f1_l_6", [10])
    csp.add_variable("f12_l_join", [28])
    csp.add_variable("f12_v_join", [9000])
    csp.add_variable("f1_d_1", [17])
    csp.add_variable("f1_d_2", [20])
    csp.add_variable("f1_d_3", [22])
    csp.add_variable("f1_d_4", [20])
    csp.add_variable("f1_d_5", [17])
    csp.add_variable("f1_d_6", [14])

    # Design variables
    csp.add_variable("f2_l_1", list(range(30, 101)))
    csp.add_variable("f2_l_2", list(range(70, 151)))
    csp.add_variable("f2_l_3", [k / 2 for k in range(0, 101)])  # 0..50 step 0.5
    csp.add_variable("f2_d_1", list(range(10, 51)))
    csp.add_variable("f2_beta", [60, 70, 80, 90, 100, 110, 120])
    csp.add_variable("f2_epsilon_a", list(range(10, 91)))
    csp.add_variable("f5432_d", list(range(10, 51)))
    csp.add_variable("f2_sigma_max_st", [800])
    csp.add_variable("f2_sigma_max_al", [400])
    csp.add_variable("f43_alpha", list(range(90, 181)))
    csp.add_variable("f5403_l_1", list(range(30, 101)))
    csp.add_variable("f3_l_2", list(range(30, 101)))
    csp.add_variable("f541_l", list(range(30, 101)))

    # Constraints
    csp.add_constraint("con_01", "f5432_d >= dr_d_min")
    csp.add_constraint("con_02", "f5432_d <= dr_d_max")
    csp.add_constraint("con_03", "f2_d_1 >= dr_d_min")
    csp.add_constraint("con_04", "f2_d_1 <= dr_d_max")
    csp.add_constraint("con_05", "f2_l_3 == round((f5432_d-f2_d_1)/(2*math.tan(math.radians(f2_beta)/2)), 1)")
    csp.add_constraint("con_06", "f2_l_3 <= (dr_l_max-f2_l_1-f2_l_2)")
    csp.add_constraint("con_07", "dr_chip_removal_min + max([f1_d_4,f1_d_5,f1_d_6]) <= f2_d_1")
    csp.add_constraint("con_08", "dr_chip_removal_min + f1_d_3 <= f2_d_1")
    csp.add_constraint("con_09", "dr_chip_removal_min + max([f1_d_1,f1_d_2,f1_d_3]) <= f5432_d")
    csp.add_constraint("con_10", "f2_l_3 >= f1_l_1+f1_l_2+f1_l_3-f2_l_1")
    csp.add_constraint("con_11", "f1_l_4+f1_l_5+f1_l_6 <= f2_l_2")
    csp.add_constraint("con_12", "f2_epsilon_a == cbr_epsilon_a")
    csp.add_constraint("con_13", "f43_alpha == cbr_alpha")
    csp.add_constraint("con_14", "f2_beta == cbr_beta")
    csp.add_constraint("con_15", "f2_sigma_max_al >= fp_sigma_max_al")
    csp.add_constraint("con_16", "f2_sigma_max_st >= fp_sigma_max_st")
    csp.add_constraint("con_17", "f5432_d == fp_d_0")
    csp.add_constraint("con_18", "f2_beta == fp_beta")
    csp.add_constraint("con_19", "f2_l_1 <= fp_l_1")
    csp.add_constraint("con_20", "f2_l_2 <= fp_l_2")
    csp.add_constraint("con_21", "f2_d_1 >= f5432_d/2")
    csp.add_constraint("con_22", "f5403_l_1+f3_l_2 >= 0.8*f5432_d")
    csp.add_constraint("con_23", "f2_d_1**2 >= f5432_d**2*(1-0.01*f2_epsilon_a)")
    csp.add_constraint("con_24", "(0.9*f2_d_1)**2 <= f5432_d**2*(1-0.01*f2_epsilon_a)")
    csp.add_constraint("con_25", "abs((math.pi*f2_d_1**2/4 * f2_l_2- f12_v_join- math.pi*f5432_d**2/4 * f3_l_2)*24*math.tan(f43_alpha/2 * math.pi/180) - (-math.pi * f5432_d**3)) <= 0.1 * abs(-math.pi * f5432_d**3)")
    csp.add_constraint("con_26", "abs(math.pi*f5432_d**2/4*(f5403_l_1*math.tan(f2_beta/2*math.pi/180)+f5432_d/6)-(math.pi*f5432_d**2/4*f2_l_1*math.tan(f2_beta/2*math.pi/180)+(math.pi*(f5432_d**3-f2_d_1**3))/24+f12_v_join*math.tan(f2_beta/2*math.pi/180)))<=0.1*abs(math.pi*f5432_d**2/4*f2_l_1*math.tan(f2_beta/2*math.pi/180)+(math.pi*(f5432_d**3-f2_d_1**3))/24+f12_v_join*math.tan(f2_beta/2*math.pi/180))")
    csp.add_constraint("con_27", "f5432_d >= rs_d_min")
    csp.add_constraint("con_28", "f5432_d <= rs_d_max")
    csp.add_constraint("con_29", "f3_l_2 == f541_l-rs_wulstverlust")
    csp.add_constraint("con_30", "f5403_l_1+f3_l_2 >= rs_l_min")
    csp.add_constraint("con_31", "f5403_l_1+f3_l_2 <= rs_l_max")
    csp.add_constraint("con_32", "f5432_d >= dr_d_min")
    csp.add_constraint("con_33", "f5432_d >= dr_d_min")
    csp.add_constraint("con_34", "f5432_d <= dr_d_max")
    csp.add_constraint("con_35", "f5432_d <= dr_d_max")
    csp.add_constraint("con_36", "f5403_l_1 <= dr_l_max")
    csp.add_constraint("con_37", "f541_l <= dr_l_max")
    csp.add_constraint("con_38", "(f541_l-40)*math.tan(math.radians(f43_alpha/2)) >= f5432_d/2")

    return csp


def test_excel_factory():
    """Backward-compatible alias for manufacturbility_problem_factory."""
    return manufacturbility_problem_factory()

# ---- Fixed registrations ----
register_problem("send_more_money_single", send_more_money_single_factory, "cryptarithm")
register_problem("send_more_money_carries", send_more_money_carries_factory, "cryptarithm")
register_problem("sudoku_binary", sudoku_binary_factory, "sudoku")
register_problem("sudoku_product", sudoku_product_factory, "sudoku")
register_problem("warehouse_location", warehouse_location_factory, "facility", "continuous", "quadratic", "exponential", "interval")
register_problem("manufacturbility_problem", manufacturbility_problem_factory, "engineering", "excel", "translated")
register_problem("manufacturability_problem", manufacturbility_problem_factory, "engineering", "excel", "translated")
register_problem("test_excel", manufacturbility_problem_factory, "engineering", "excel", "translated", "deprecated")


