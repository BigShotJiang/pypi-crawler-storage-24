"""Helpers for constructing :class:`~csp.core.CSP` instances from Excel files."""

from __future__ import annotations

import math
import re
import zipfile
import xml.etree.ElementTree as ET
from typing import Callable, Dict, Iterable, List, Optional, Sequence, Set, Tuple, Union

from .core import CSP

# ---------------------------------------------------------------------------
# Domain parsing utilities
# ---------------------------------------------------------------------------

_RANGE_RE = re.compile(r"\s*(-?\d+(?:\.\d+)?)\s*-\s*(-?\d+(?:\.\d+)?)\s*")
_TOKEN_SPLIT_RE = re.compile(r"[;\n\r\t]+")


def _as_number(token: str) -> Union[int, float]:
    token = token.strip()
    if token == "":
        raise ValueError("Leerer Token in Domain-Zelle")

    if re.fullmatch(r"-?\d+,\d+", token):
        token = token.replace(",", ".")

    try:
        val = float(token)
    except ValueError as exc:  # pragma: no cover - defensive safety net
        raise ValueError(f"Kann Domain-Token nicht als Zahl interpretieren: {token!r}") from exc

    if abs(val - round(val)) < 1e-12:
        return int(round(val))
    return val


from decimal import Decimal, ROUND_FLOOR, getcontext

# Use high precision for safe step-based range expansion (e.g., '0-50,0.5')
getcontext().prec = 80


def _to_decimal(token: str) -> Decimal:
    token = token.strip()
    if token == "":
        raise ValueError("Leerer Token in Domain-Zelle")
    if re.fullmatch(r"-?\d+,\d+", token):
        token = token.replace(",", ".")
    return Decimal(token)


def _expand_range(range_token: str, step_token: Optional[str] = None) -> Set[Union[int, float]]:
    """Expand a range token like '0-10' optionally with a step token like '0.5'."""
    m = _RANGE_RE.fullmatch(range_token.strip())
    if not m:
        raise ValueError(f"Ungültige Range-Spezifikation: {range_token!r}")

    start_d = _to_decimal(m.group(1))
    end_d = _to_decimal(m.group(2))
    if start_d > end_d:
        start_d, end_d = end_d, start_d

    if step_token is None:
        # default step only if bounds are integers
        if start_d == start_d.to_integral() and end_d == end_d.to_integral():
            step_d = Decimal(1)
        else:
            raise ValueError(
                f"Range mit nicht-integer Grenzen benötigt eine Schrittweite, z.B. '{range_token},0.1'"
            )
    else:
        step_d = _to_decimal(step_token)
        if step_d <= 0:
            raise ValueError(f"Schrittweite muss > 0 sein, erhalten: {step_token!r}")

    span = end_d - start_d
    # expected size (inclusive)
    n = int((span / step_d).to_integral_value(rounding=ROUND_FLOOR)) + 1
    if n > 1_000_000:
        raise ValueError(
            f"Domain-Range ist zu groß ({n} Werte) für {range_token!r} mit step={step_token!r}"
        )

    out: Set[Union[int, float]] = set()
    cur = start_d
    # iterate exactly n steps, avoids float drift
    for _ in range(n):
        if cur > end_d:
            break
        if cur == cur.to_integral():
            out.add(int(cur))
        else:
            out.add(float(cur))
        cur = cur + step_d
    # be robust to exact endpoint inclusion
    if end_d == end_d.to_integral():
        out.add(int(end_d))
    else:
        out.add(float(end_d))
    return out


def parse_domain_cell(cell: object) -> Set[Union[int, float]]:
    """Parse a domain specification from the Excel ``variables`` sheet."""

    if cell is None or (isinstance(cell, float) and math.isnan(cell)):
        raise ValueError("Leere Domain-Zelle")

    if isinstance(cell, (int, float)):
        return {int(cell) if abs(cell - int(round(cell))) < 1e-12 else float(cell)}

    text = str(cell).strip()
    if text == "":
        raise ValueError("Leere Domain-Zeichenkette")

    if text.startswith("[") and text.endswith("]"):
        text = text[1:-1]

    if _TOKEN_SPLIT_RE.search(text):
        tokens = [tok for tok in _TOKEN_SPLIT_RE.split(text) if tok.strip()]
        # support 'a-b;step' syntax (e.g., '0-50;0.5')
        if len(tokens) == 2 and _RANGE_RE.fullmatch(tokens[0]):
            # interpret second token as step if it is plausible
            try:
                step = float(_as_number(tokens[1]))
                m = _RANGE_RE.fullmatch(tokens[0])
                span = abs(float(_as_number(m.group(2))) - float(_as_number(m.group(1))))
                if step > 0 and step <= span:
                    return _expand_range(tokens[0], tokens[1])
            except Exception:
                pass
        # otherwise treat as set/enum of numbers
        return {_as_number(tok) for tok in tokens}

    if "," in text:
        if re.fullmatch(r"-?\d+,\d+", text):
            return {_as_number(text)}
        tokens = [tok for tok in text.split(",") if tok.strip()]
        # support 'a-b,step' syntax (e.g., '0-50,0.5')
        if len(tokens) == 2 and _RANGE_RE.fullmatch(tokens[0]):
            try:
                step = float(_as_number(tokens[1]))
                m = _RANGE_RE.fullmatch(tokens[0])
                span = abs(float(_as_number(m.group(2))) - float(_as_number(m.group(1))))
                if step > 0 and step <= span:
                    return _expand_range(tokens[0], tokens[1])
            except Exception:
                pass
        # otherwise treat as enumeration
        return {_as_number(tok) for tok in tokens}

    if " " in text:
        tokens = [tok for tok in text.split(" ") if tok]
        if len(tokens) > 1:
            return {_as_number(tok) for tok in tokens}

    range_match = _RANGE_RE.fullmatch(text)
    if range_match:
        start = _as_number(range_match.group(1))
        end = _as_number(range_match.group(2))
        if start > end:
            start, end = end, start
        if isinstance(start, int) and isinstance(end, int):
            return set(range(start, end + 1))
        values = []
        current = float(start)
        while current <= float(end) + 1e-12:
            values.append(round(current, 10))
            current += 1.0
        return {_as_number(str(v)) for v in values}

    return {_as_number(text)}


# ---------------------------------------------------------------------------
# Constraint expression helpers
# ---------------------------------------------------------------------------

_FUNCTION_CALL_REWRITES = {
    "ABS": "abs",
    "ACOS": "math.acos",
    "ASIN": "math.asin",
    "ATAN": "math.atan",
    "COS": "math.cos",
    "EXP": "math.exp",
    "LN": "math.log",
    "LOG": "math.log10",
    "SIN": "math.sin",
    "SQRT": "math.sqrt",
    "TAN": "math.tan",
}

_CONSTANT_REWRITES = {
    "TRUE": "True",
    "FALSE": "False",
}


def _rewrite_function_calls(expr: str) -> str:
    def _replace(match: re.Match[str]) -> str:
        name = match.group(1)
        replacement = _FUNCTION_CALL_REWRITES.get(name.upper())
        if replacement:
            return f"{replacement}("
        return f"{name.lower()}("

    return re.sub(r"\b([A-Za-z_][A-Za-z0-9_]*)\s*\(", _replace, expr)


def clean_constraint_expression(expr: object) -> str:
    """Normalise Excel constraint strings for Python/SymPy consumption."""

    if expr is None:
        return ""
    text = str(expr).strip()
    if text == "":
        return ""

    text = text.rstrip(";, ")
    text = text.replace("^", "**")
    text = re.sub(r"<>", "!=", text)
    text = re.sub(r"(?<![<>=!])=(?![<>=])", "==", text)
    text = re.sub(r"\bAND\b", "and", text, flags=re.IGNORECASE)
    text = re.sub(r"\bOR\b", "or", text, flags=re.IGNORECASE)
    text = re.sub(r"\bNOT\b", "not", text, flags=re.IGNORECASE)

    for excel_name, python_name in _CONSTANT_REWRITES.items():
        text = re.sub(rf"\b{excel_name}\b", python_name, text, flags=re.IGNORECASE)

    text = re.sub(r"\bPI\s*\(\s*\)", "math.pi", text, flags=re.IGNORECASE)

    text = _rewrite_function_calls(text)
    return text


# ---------------------------------------------------------------------------
# Workbook helpers
# ---------------------------------------------------------------------------


def _cast_domain_values(domain: Iterable[Union[int, float]]) -> Set[Union[int, float]]:
    cast: Set[Union[int, float]] = set()
    for value in domain:
        if isinstance(value, float) and abs(value - int(round(value))) < 1e-12:
            cast.add(int(round(value)))
        else:
            cast.add(value)
    return cast


def make_excel_csp_factory(
    xlsx_path: str,
    sheet_vars: str = "variables",
    sheet_cons: str = "constraints",
    *,
    engine: Optional[str] = None,
) -> Callable[[], CSP]:
    """Return a factory that loads ``xlsx_path`` lazily when invoked."""

    def _factory() -> CSP:
        vars_columns, vars_rows = _load_sheet_records(
            xlsx_path, sheet_vars, engine=engine
        )
        cons_columns, cons_rows = _load_sheet_records(
            xlsx_path, sheet_cons, engine=engine
        )

        if not {"name", "domain"}.issubset({col.strip().lower() for col in vars_columns}):
            raise ValueError(
                f"Sheet '{sheet_vars}' braucht Spalten ['name','domain'], gefunden: {list(vars_columns)}"
            )
        if "constraint" not in {col.strip().lower() for col in cons_columns}:
            raise ValueError(
                f"Sheet '{sheet_cons}' braucht Spalte 'constraint', gefunden: {list(cons_columns)}"
            )

        def _get(row: Dict[str, object], key: str) -> object:
            for candidate in row.keys():
                if candidate and candidate.strip().lower() == key:
                    return row[candidate]
            return None

        csp = CSP()
        for row in vars_rows:
            name_obj = _get(row, "name")
            name = str(name_obj).strip() if name_obj is not None else ""
            if not name:
                raise ValueError("Variable ohne Namen in Excel-Sheet gefunden")
            domain_value = _get(row, "domain")
            domain = parse_domain_cell(domain_value)
            csp.add_variable(name, _cast_domain_values(domain))

        for idx, row in enumerate(cons_rows):
            constraint = clean_constraint_expression(_get(row, "constraint"))
            if not constraint:
                continue
            nr_value = _get(row, "nr")
            if nr_value is not None:
                nr_text = str(nr_value).strip()
                cid = f"c{nr_text}" if nr_text.isdigit() else f"c{idx + 1}"
            else:
                cid = f"c{idx + 1}"
            csp.add_constraint(cid, constraint)

        return csp

    return _factory


def load_excel_csp(
    xlsx_path: str,
    sheet_vars: str = "variables",
    sheet_cons: str = "constraints",
    *,
    engine: Optional[str] = None,
) -> CSP:
    """Eager helper mirroring :func:`make_excel_csp_factory`."""

    return make_excel_csp_factory(
        xlsx_path,
        sheet_vars=sheet_vars,
        sheet_cons=sheet_cons,
        engine=engine,
    )()


__all__ = [
    "clean_constraint_expression",
    "load_excel_csp",
    "make_excel_csp_factory",
    "parse_domain_cell",
]


# ---------------------------------------------------------------------------
# Lightweight XLSX reader
# ---------------------------------------------------------------------------

_NS_MAIN = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
_NS_REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
_NS_PACKAGE_REL = "http://schemas.openxmlformats.org/package/2006/relationships"


def _load_sheet_records(
    xlsx_path: str, sheet_name: str, *, engine: Optional[str] = None
) -> Tuple[List[str], List[Dict[str, object]]]:
    try:  # Prefer pandas when available for full-featured parsing.
        import pandas as pd  # type: ignore
    except Exception:  # pragma: no cover - optional dependency
        return _load_sheet_records_from_xlsx(xlsx_path, sheet_name)

    df = pd.read_excel(xlsx_path, sheet_name=sheet_name, engine=engine)
    columns = [str(col) for col in df.columns]
    records: List[Dict[str, object]] = []
    for row in df.itertuples(index=False, name=None):
        record: Dict[str, object] = {}
        for idx, column in enumerate(columns):
            record[column] = row[idx] if idx < len(row) else None
        records.append(record)
    return columns, records


def _load_sheet_records_from_xlsx(
    xlsx_path: str, sheet_name: str
) -> Tuple[List[str], List[Dict[str, object]]]:
    with zipfile.ZipFile(xlsx_path) as zf:
        workbook = ET.fromstring(zf.read("xl/workbook.xml"))
        rels_root = ET.fromstring(zf.read("xl/_rels/workbook.xml.rels"))
        shared_strings = _read_shared_strings(zf)

        sheet_path = _sheet_path(workbook, rels_root, sheet_name)
        sheet_rows = _read_sheet_rows(zf, sheet_path, shared_strings)

    if not sheet_rows:
        return [], []

    headers = sheet_rows[0]
    columns = [str(cell).strip() if cell is not None else f"column{idx+1}" for idx, cell in enumerate(headers)]
    records: List[Dict[str, object]] = []
    for row in sheet_rows[1:]:
        if all(cell in (None, "") for cell in row):
            continue
        record = {columns[idx]: row[idx] if idx < len(row) else None for idx in range(len(columns))}
        records.append(record)
    return columns, records


def _sheet_path(workbook: ET.Element, rels_root: ET.Element, sheet_name: str) -> str:
    ns = {"m": _NS_MAIN, "r": _NS_REL}
    for sheet in workbook.findall("m:sheets/m:sheet", ns):
        if sheet.get("name") == sheet_name:
            rel_id = sheet.get(f"{{{_NS_REL}}}id")
            if not rel_id:
                break
            for rel in rels_root.findall("{http://schemas.openxmlformats.org/package/2006/relationships}Relationship"):
                if rel.get("Id") == rel_id:
                    target = rel.get("Target")
                    if not target:
                        break
                    return f"xl/{target}"
    available = [sheet.get("name") for sheet in workbook.findall("m:sheets/m:sheet", ns)]
    raise ValueError(
        f"Sheet '{sheet_name}' nicht gefunden. Verfügbar: {available}"
    )


def _read_shared_strings(zf: zipfile.ZipFile) -> List[str]:
    try:
        data = zf.read("xl/sharedStrings.xml")
    except KeyError:
        return []
    root = ET.fromstring(data)
    strings: List[str] = []
    for si in root.findall("{http://schemas.openxmlformats.org/spreadsheetml/2006/main}si"):
        texts: List[str] = []
        for text in si.findall(".//{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t"):
            texts.append(text.text or "")
        strings.append("".join(texts))
    return strings


def _read_sheet_rows(
    zf: zipfile.ZipFile, sheet_path: str, shared_strings: Sequence[str]
) -> List[List[object]]:
    sheet_xml = ET.fromstring(zf.read(sheet_path))
    rows: List[List[object]] = []
    for row in sheet_xml.findall("{http://schemas.openxmlformats.org/spreadsheetml/2006/main}sheetData/{http://schemas.openxmlformats.org/spreadsheetml/2006/main}row"):
        cells: Dict[int, object] = {}
        for cell in row.findall("{http://schemas.openxmlformats.org/spreadsheetml/2006/main}c"):
            ref = cell.get("r") or "A"
            col_idx = _column_index(ref)
            cells[col_idx] = _cell_value(cell, shared_strings)
        if cells:
            max_index = max(cells)
            row_values = [cells.get(idx) for idx in range(max_index + 1)]
        else:
            row_values = []
        rows.append(row_values)
    return rows


_COL_RE = re.compile(r"([A-Z]+)")


def _column_index(cell_ref: str) -> int:
    match = _COL_RE.match(cell_ref)
    if not match:
        return 0
    col_letters = match.group(1)
    idx = 0
    for char in col_letters:
        idx = idx * 26 + (ord(char) - 64)
    return idx - 1


def _cell_value(cell: ET.Element, shared_strings: Sequence[str]) -> object:
    cell_type = cell.get("t")
    if cell_type == "inlineStr":
        text_elem = cell.find("{http://schemas.openxmlformats.org/spreadsheetml/2006/main}is/{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t")
        return (text_elem.text or "").strip() if text_elem is not None else ""
    value_elem = cell.find("{http://schemas.openxmlformats.org/spreadsheetml/2006/main}v")
    if value_elem is None:
        return ""
    text = (value_elem.text or "").strip()
    if cell_type == "s":
        try:
            idx = int(text)
        except ValueError:
            return text
        return shared_strings[idx] if 0 <= idx < len(shared_strings) else ""
    if cell_type == "b":
        return text == "1"
    try:
        if "." in text:
            return float(text)
        return int(text)
    except ValueError:
        return text
