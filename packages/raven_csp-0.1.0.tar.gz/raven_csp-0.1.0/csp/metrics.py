from __future__ import annotations

from dataclasses import dataclass, field
from itertools import combinations
from math import log
from typing import Dict, List, Sequence, Set, Tuple

from .core import CSP


@dataclass
class GraphStats:
    n_nodes: int
    n_edges: int
    density: float
    degree_min: int
    degree_max: int
    degree_mean: float
    degree_var: float
    n_components: int


@dataclass
class CSPMetrics:
    n_variables: int
    n_constraints: int
    arity_min: int
    arity_max: int
    arity_mean: float
    arity_hist: Dict[int, int]
    domain_min: int
    domain_max: int
    domain_mean: float
    domain_sum: int
    # Upper bound only: log10(Π |D(x)|)
    log10_search_space_upper: float
    primal_graph: GraphStats
    constraint_graph: GraphStats
    # Heuristic (min-fill) approximation of treewidth on the primal graph.
    approx_treewidth: int
    # Tuple-domain size stats (useful for HVE/DE/double).
    tuple_domain_total: int
    tuple_domain_max: int


@dataclass
class BinarizationReport:
    encoding: str
    transform_time_s: float
    before: CSPMetrics
    after: CSPMetrics
    delta: Dict[str, float] = field(default_factory=dict)


def _degree_stats(adj: Dict[str, Set[str]]) -> Tuple[int, int, float, float]:
    degs = [len(nbrs) for nbrs in adj.values()]
    if not degs:
        return 0, 0, 0.0, 0.0
    mean = sum(degs) / len(degs)
    var = sum((d - mean) ** 2 for d in degs) / len(degs)
    return min(degs), max(degs), mean, var


def _count_components(nodes: Sequence[str], adj: Dict[str, Set[str]]) -> int:
    seen: Set[str] = set()
    comps = 0
    for n in nodes:
        if n in seen:
            continue
        comps += 1
        stack = [n]
        seen.add(n)
        while stack:
            u = stack.pop()
            for v in adj.get(u, set()):
                if v not in seen:
                    seen.add(v)
                    stack.append(v)
    return comps


def _build_primal_graph(csp: CSP) -> Tuple[List[str], Dict[str, Set[str]]]:
    nodes = list(csp.variables.keys())
    adj: Dict[str, Set[str]] = {v: set() for v in nodes}
    for cons in csp.constraints.values():
        scope = list(cons.variables)
        for a, b in combinations(scope, 2):
            if a == b:
                continue
            adj.setdefault(a, set()).add(b)
            adj.setdefault(b, set()).add(a)
    for v in nodes:
        adj.setdefault(v, set())
    return nodes, adj


def _build_constraint_graph(csp: CSP) -> Tuple[List[str], Dict[str, Set[str]]]:
    cnames = list(csp.constraints.keys())
    scopes: Dict[str, Set[str]] = {c: set(csp.constraints[c].variables) for c in cnames}
    adj: Dict[str, Set[str]] = {c: set() for c in cnames}
    for i in range(len(cnames)):
        ci = cnames[i]
        for j in range(i + 1, len(cnames)):
            cj = cnames[j]
            if scopes[ci] & scopes[cj]:
                adj[ci].add(cj)
                adj[cj].add(ci)
    return cnames, adj


def _graph_stats(nodes: List[str], adj: Dict[str, Set[str]]) -> GraphStats:
    n_nodes = len(nodes)
    n_edges = sum(len(adj.get(n, set())) for n in nodes) // 2
    density = 0.0
    if n_nodes >= 2:
        density = (2.0 * n_edges) / (n_nodes * (n_nodes - 1))
    dmin, dmax, dmean, dvar = _degree_stats({n: adj.get(n, set()) for n in nodes})
    n_components = _count_components(nodes, {n: adj.get(n, set()) for n in nodes}) if n_nodes else 0
    return GraphStats(
        n_nodes=n_nodes,
        n_edges=n_edges,
        density=density,
        degree_min=dmin,
        degree_max=dmax,
        degree_mean=dmean,
        degree_var=dvar,
        n_components=n_components,
    )


def _approx_treewidth_min_fill(nodes: List[str], adj: Dict[str, Set[str]]) -> int:
    """Heuristic treewidth proxy (induced width) using min-fill elimination."""
    g: Dict[str, Set[str]] = {u: set(vs) for u, vs in adj.items()}
    remaining = set(nodes)
    width = 0

    def fill_cost(u: str) -> int:
        nbrs = list(g.get(u, set()) & remaining)
        missing = 0
        for a, b in combinations(nbrs, 2):
            if b not in g.get(a, set()):
                missing += 1
        return missing

    while remaining:
        best = None
        best_cost = None
        best_deg = None
        for u in remaining:
            cost = fill_cost(u)
            deg = len(g.get(u, set()) & remaining)
            if best is None or cost < best_cost or (cost == best_cost and deg < best_deg):
                best = u
                best_cost = cost
                best_deg = deg
        u = best  # type: ignore[assignment]
        nbrs = list(g.get(u, set()) & remaining)
        width = max(width, len(nbrs))
        for a, b in combinations(nbrs, 2):
            g.setdefault(a, set()).add(b)
            g.setdefault(b, set()).add(a)
        remaining.remove(u)
    return width


def compute_csp_metrics(csp: CSP) -> CSPMetrics:
    n_vars = len(csp.variables)
    n_cons = len(csp.constraints)

    arities = [len(cons.variables) for cons in csp.constraints.values()]
    if arities:
        ar_min = min(arities)
        ar_max = max(arities)
        ar_mean = sum(arities) / len(arities)
    else:
        ar_min = ar_max = 0
        ar_mean = 0.0
    ar_hist: Dict[int, int] = {}
    for a in arities:
        ar_hist[a] = ar_hist.get(a, 0) + 1

    dom_sizes = [len(v.domain) for v in csp.variables.values()]
    if dom_sizes:
        dmin = min(dom_sizes)
        dmax = max(dom_sizes)
        dmean = sum(dom_sizes) / len(dom_sizes)
        dsum = sum(dom_sizes)
    else:
        dmin = dmax = dsum = 0
        dmean = 0.0

    log10_space = 0.0
    for s in dom_sizes:
        if s <= 0:
            log10_space = float("-inf")
            break
        log10_space += log(s, 10)

    nodes_p, adj_p = _build_primal_graph(csp)
    primal = _graph_stats(nodes_p, adj_p)
    approx_tw = _approx_treewidth_min_fill(nodes_p, adj_p) if nodes_p else 0

    nodes_c, adj_c = _build_constraint_graph(csp)
    cgraph = _graph_stats(nodes_c, adj_c)

    tuple_sizes: List[int] = []
    for var in csp.variables.values():
        dom = var.domain
        if dom and any(isinstance(x, tuple) for x in dom):
            tuple_sizes.append(len(dom))
    tuple_total = sum(tuple_sizes) if tuple_sizes else 0
    tuple_max = max(tuple_sizes) if tuple_sizes else 0

    return CSPMetrics(
        n_variables=n_vars,
        n_constraints=n_cons,
        arity_min=ar_min,
        arity_max=ar_max,
        arity_mean=ar_mean,
        arity_hist=ar_hist,
        domain_min=dmin,
        domain_max=dmax,
        domain_mean=dmean,
        domain_sum=dsum,
        log10_search_space_upper=log10_space,
        primal_graph=primal,
        constraint_graph=cgraph,
        approx_treewidth=approx_tw,
        tuple_domain_total=tuple_total,
        tuple_domain_max=tuple_max,
    )


def summarize_binarization(before: CSPMetrics, after: CSPMetrics) -> Dict[str, float]:
    delta: Dict[str, float] = {}
    delta["n_variables"] = after.n_variables - before.n_variables
    delta["n_constraints"] = after.n_constraints - before.n_constraints
    delta["domain_sum"] = after.domain_sum - before.domain_sum
    delta["log10_search_space_upper"] = after.log10_search_space_upper - before.log10_search_space_upper
    delta["primal_edges"] = after.primal_graph.n_edges - before.primal_graph.n_edges
    delta["primal_density"] = after.primal_graph.density - before.primal_graph.density
    delta["primal_degree_mean"] = after.primal_graph.degree_mean - before.primal_graph.degree_mean
    delta["constraint_edges"] = after.constraint_graph.n_edges - before.constraint_graph.n_edges
    delta["constraint_density"] = after.constraint_graph.density - before.constraint_graph.density
    delta["approx_treewidth"] = after.approx_treewidth - before.approx_treewidth
    delta["tuple_domain_total"] = after.tuple_domain_total - before.tuple_domain_total
    return delta
