
from typing import Dict, Any, List, Optional, Set
import random

def select_variable(csp, assignment: Dict[str, Any], heuristics: List[str], 
                    domains: Optional[Dict[str, Set[Any]]] = None,
                    deterministic: bool = False):
    domains = domains or {v: csp.variables[v].domain for v in csp.variables}
    unassigned = [v for v in csp.variables if v not in assignment]
    if not unassigned: return None
    if heuristics and "mrv" in heuristics:
        m = min(len(domains[v]) for v in unassigned)
        unassigned = [v for v in unassigned if len(domains[v]) == m]
    if heuristics and "degree" in heuristics:
        deg = {v: len(csp.constraints_by_var.get(v, [])) for v in unassigned}
        M = max(deg.values())
        unassigned = [v for v in unassigned if deg[v] == M]
    if heuristics and "shuffle_variable" in heuristics and not deterministic:
        random.shuffle(unassigned)
    return sorted(unassigned)[0]

def order_values(csp, variable: str, heuristics: List[str], assignment: Dict[str, Any],
                 domains: Optional[Dict[str, Set[Any]]] = None,
                 deterministic: bool = False):
    vals = list(domains[variable]) if domains else list(csp.variables[variable].domain)
    if deterministic:
        vals = sorted(vals)
    if heuristics and "lcv" in heuristics:
        def conflicts(val):
            test = dict(assignment); test[variable]=val
            return sum(1 for cid in csp.constraints_by_var.get(variable, []) if not csp.constraints[cid].evaluate(test))
        vals = sorted(vals, key=conflicts)
    if heuristics and "shuffle_values" in heuristics and not deterministic:
        random.shuffle(vals)
    return vals
