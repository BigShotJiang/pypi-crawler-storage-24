from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from itertools import product
import random
from typing import Any, Dict, Optional, Set, Tuple

from csp.core import CSP, Constraint

from .architectures.base import DCSPModel
from .messages import Message
from .metrics import DCSPMetrics
from .network import EventLoop, Network


def _supports(cons: Constraint, var: str, val: Any, domains: Dict[str, Set[Any]], metrics: DCSPMetrics, aid: str) -> bool:
    """Check whether (var=val) has a support in `cons` under current domains."""
    other = [v for v in cons.variables if v != var]
    if not other:
        metrics.inc_agent(aid, "constraint_checks")
        return cons.evaluate({var: val})

    pools = [domains[v] for v in other]
    for combo in product(*pools):
        a = {var: val, **{ov: cv for ov, cv in zip(other, combo)}}
        metrics.inc_agent(aid, "constraint_checks")
        if cons.evaluate(a):
            return True
    return False


@dataclass
class _DGACAgent:
    aid: str
    cons_by_name: Dict[str, Constraint]
    owned_by_var: Dict[str, Tuple[str, ...]]
    scope_vars: Tuple[str, ...]
    domains: Dict[str, Set[Any]]
    var_to_agents: Dict[str, Set[str]]
    net: Network
    metrics: DCSPMetrics

    queue: deque[Tuple[str, str]] = field(default_factory=deque)
    failed: bool = False

    def _enqueue_all(self) -> None:
        for cname, cons in self.cons_by_name.items():
            for v in cons.variables:
                if v in self.domains:
                    self.queue.append((cname, v))

    def _send_domain(self, var: str) -> None:
        payload = (var, frozenset(self.domains[var]))
        for other in sorted(self.var_to_agents.get(var, set())):
            if other == self.aid:
                continue
            self.metrics.inc_agent(self.aid, "messages_sent")
            self.metrics.inc_agent(self.aid, "messages_domain")
            self.net.send(
                Message(kind="domain", sender=self.aid, receiver=other, payload=payload, sent_at=self.net.loop.time)
            )

    def _broadcast_fail(self, reason: str) -> None:
        neigh: Set[str] = set()
        for v in self.scope_vars:
            neigh |= set(self.var_to_agents.get(v, set()))
        for other in sorted(neigh):
            if other == self.aid:
                continue
            self.metrics.inc_agent(self.aid, "messages_sent")
            self.metrics.inc_agent(self.aid, "messages_fail")
            self.net.send(
                Message(kind="fail", sender=self.aid, receiver=other, payload=reason, sent_at=self.net.loop.time)
            )

    def _revise(self, cons: Constraint, var: str) -> bool:
        if var not in self.domains:
            return False
        to_remove: Set[Any] = set()
        for val in list(self.domains[var]):
            if not _supports(cons, var, val, self.domains, self.metrics, self.aid):
                to_remove.add(val)
        if not to_remove:
            return False
        self.domains[var].difference_update(to_remove)
        self.metrics.inc_agent(self.aid, "values_removed", by=len(to_remove))
        return True

    def _propagate_local(self) -> None:
        while self.queue and not self.failed:
            cname, v = self.queue.popleft()
            cons = self.cons_by_name[cname]
            if not self._revise(cons, v):
                continue

            if not self.domains[v]:
                self.failed = True
                self._broadcast_fail(f"empty_domain:{v}")
                return

            self._send_domain(v)

            for cname2 in self.owned_by_var.get(v, ()): 
                cons2 = self.cons_by_name[cname2]
                for nv in cons2.variables:
                    if nv != v and nv in self.domains:
                        self.queue.append((cname2, nv))

    def on_message(self, msg: Message) -> None:
        self.metrics.record_activity(self.net.loop.time, self.aid)
        if self.failed:
            return

        if msg.kind == "start":
            self._enqueue_all()
            self._propagate_local()
            return

        if msg.kind == "fail":
            self.failed = True
            return

        if msg.kind == "domain":
            var, dom_frozen = msg.payload
            if var not in self.domains:
                return
            incoming = set(dom_frozen)
            before = set(self.domains[var])
            new_dom = before.intersection(incoming)
            if new_dom == before:
                return
            self.domains[var] = new_dom
            removed = len(before) - len(new_dom)
            if removed > 0:
                self.metrics.inc_agent(self.aid, "values_removed", by=removed)
            if not self.domains[var]:
                self.failed = True
                self._broadcast_fail(f"empty_domain:{var}")
                return

            for cname in self.owned_by_var.get(var, ()): 
                cons = self.cons_by_name[cname]
                for nv in cons.variables:
                    if nv in self.domains:
                        self.queue.append((cname, nv))
            self._propagate_local()
            return


def run_distributed_gac(
    model: DCSPModel,
    *,
    max_delay: int = 0,
    random_seed: int = 0,
    max_events: int = 1_000_000,
    metrics: Optional[DCSPMetrics] = None,
) -> Tuple[bool, CSP, Dict[str, Any]]:
    """Distributed GAC (domain filtering) for the *constraint-agent* architecture."""
    if "constraint_agents" not in model.capabilities:
        raise ValueError("Distributed GAC is implemented for the constraint-agent architecture.")

    m = metrics or DCSPMetrics()
    loop = EventLoop(max_delay=max_delay, rng=random.Random(int(random_seed)))
    net = Network(loop)

    agents: Dict[str, _DGACAgent] = {}
    for aid, spec in model.agents.items():
        cons_by_name = {c.name: c for c in spec.constraints}
        owned_by_var: Dict[str, list[str]] = {}
        for c in spec.constraints:
            for v in c.variables:
                if v not in spec.domains:
                    continue
                owned_by_var.setdefault(v, []).append(c.name)
        owned_by_var2 = {v: tuple(lst) for v, lst in owned_by_var.items()}

        domains = {v: set(spec.domains[v]) for v in spec.controlled_vars}

        ag = _DGACAgent(
            aid=aid,
            cons_by_name=cons_by_name,
            owned_by_var=owned_by_var2,
            scope_vars=tuple(spec.controlled_vars),
            domains=domains,
            var_to_agents=model.var_to_agents,
            net=net,
            metrics=m,
        )
        agents[aid] = ag
        net.register(aid, ag.on_message)

    for aid in sorted(agents.keys()):
        net.send(Message(kind="start", sender="__init__", receiver=aid, payload=None, sent_at=0), delay=0)

    processed = net.run(max_events=max_events)
    terminated = loop.empty()
    m.finalize_parallelism()

    global_domains: Dict[str, Set[Any]] = {v: set(model.csp.variables[v].domain) for v in model.csp.variables}
    for v, aids in model.var_to_agents.items():
        dom = set(global_domains[v])
        for aid in aids:
            dom &= set(agents[aid].domains.get(v, dom))
        global_domains[v] = dom

    # If we hit max_events before quiescence, propagation may be incomplete.
    ok = all(global_domains[v] for v in global_domains) and terminated
    reduced = model.csp.clone_with_domains(global_domains)

    extra = {
        "processed_events": processed,
        "sim_time": loop.time,
        "terminated": bool(terminated),
        "pending_events": int(0 if terminated else len(getattr(loop, "_pq", []))),
        "reason": "done" if terminated else "max_events",
    }
    return ok, reduced, extra
