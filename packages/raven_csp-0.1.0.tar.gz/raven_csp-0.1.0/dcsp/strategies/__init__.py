"""Negotiation strategies.

In the classic DCSP literature these strategies are usually described as
distributed search algorithms. In this framework they are treated as a
pluggable layer, independent from the agent architecture.
"""

from .base import Strategy
from .builtins import get_strategy, list_strategies, register_strategy

__all__ = [
    "Strategy",
    "get_strategy",
    "list_strategies",
    "register_strategy",
]
