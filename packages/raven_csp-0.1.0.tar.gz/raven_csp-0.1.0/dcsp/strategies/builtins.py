from __future__ import annotations

from typing import Dict, Type

from ..algorithms.abt import AsynchronousBacktracking
from ..algorithms.awcs import AsynchronousWeakCommitmentSearch
from ..algorithms.sbt import SynchronousBacktracking
from ..algorithms.afc import AsynchronousForwardChecking
from ..algorithms.dba import DistributedBreakoutAlgorithm
from ..algorithms.dsa import DistributedStochasticAlgorithm
from ..algorithms.aas import AsynchronousAggregationSearch
from ..algorithms.compapo import CompleteAsynchronousPartialOverlay
from .base import Strategy


_STRATEGIES: Dict[str, Type[Strategy]] = {
    # Baselines
    "sbt": SynchronousBacktracking,
    "sync": SynchronousBacktracking,
    "synchronous": SynchronousBacktracking,

    # Asynchronous search
    "abt": AsynchronousBacktracking,
    "async": AsynchronousBacktracking,

    "awcs": AsynchronousWeakCommitmentSearch,
    "weak": AsynchronousWeakCommitmentSearch,
    "weak-commitment": AsynchronousWeakCommitmentSearch,

    # Asynchronous forward checking
    "afc": AsynchronousForwardChecking,
    "forward": AsynchronousForwardChecking,
    "asynchronous-forward-checking": AsynchronousForwardChecking,

    # Distributed local search
    "dba": DistributedBreakoutAlgorithm,
    "breakout": DistributedBreakoutAlgorithm,
    "distributed-breakout": DistributedBreakoutAlgorithm,

    "dsa": DistributedStochasticAlgorithm,
    "stochastic": DistributedStochasticAlgorithm,
    "distributed-stochastic": DistributedStochasticAlgorithm,

    # Constraint-agent aggregation search
    "aas": AsynchronousAggregationSearch,
    "asynchronous-aggregation": AsynchronousAggregationSearch,

    # Mediation-based (CompAPO)
    "compapo": CompleteAsynchronousPartialOverlay,
    "apo": CompleteAsynchronousPartialOverlay,
    "mediation": CompleteAsynchronousPartialOverlay,
}


def register_strategy(name: str, cls: Type[Strategy]) -> None:
    _STRATEGIES[name.lower().strip()] = cls


def get_strategy(name: str) -> Type[Strategy]:
    key = name.lower().strip()
    if key not in _STRATEGIES:
        known = ", ".join(sorted(set(_STRATEGIES.keys())))
        raise ValueError(f"Unknown strategy '{name}'. Known: {known}")
    return _STRATEGIES[key]


def list_strategies() -> Dict[str, Type[Strategy]]:
    return dict(_STRATEGIES)
