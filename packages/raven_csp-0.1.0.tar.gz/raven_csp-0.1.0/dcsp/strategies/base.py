from __future__ import annotations

from typing import Any, Optional, Protocol

from ..architectures.base import DCSPModel
from ..algorithms.base import SolveOutcome
from ..metrics import DCSPMetrics


class Strategy(Protocol):
    """A pluggable negotiation strategy.

    Most strategies will be event-driven and communicate via the network
    simulation. The concrete implementation decides what it needs.
    """

    name: str

    def __init__(self, *, metrics: Optional[DCSPMetrics] = None):  # pragma: no cover
        ...

    def solve(self, model: DCSPModel, **kwargs: Any) -> SolveOutcome:  # pragma: no cover
        ...
