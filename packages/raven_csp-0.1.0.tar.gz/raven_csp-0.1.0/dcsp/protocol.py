from __future__ import annotations

import base64
import json
import os
import pickle
import time
from dataclasses import dataclass, asdict
from typing import Any, Optional


def _safe_payload(payload: Any, *, max_repr_len: int = 2_000, max_pickle_bytes: int = 200_000) -> Any:
    """Payload serialization for protocol logging.

    Goal: include message *content* as faithfully as possible while keeping
    JSONL reasonably sized and robust.

    Strategy:
    - If payload is JSON-serializable: store as-is under "json".
    - Additionally, if payload is picklable and not too large: store exact
      bytes as base64 under "pickle_b64".
    - Always include a short repr and type info for inspection.

    Note: pickled payloads are Python-specific and intended for offline
    analysis (you can re-load them with pickle after base64-decoding).
    """
    out = {
        "type": type(payload).__name__,
        "repr": None,
        "json": None,
        "pickle_b64": None,
        "pickle_bytes": None,
    }

    # repr
    try:
        s = repr(payload)
    except Exception:
        s = f"<{type(payload).__name__}>"
    if len(s) > max_repr_len:
        s = s[: max_repr_len - 3] + "..."
    out["repr"] = s

    # json
    try:
        json.dumps(payload)
        out["json"] = payload
    except Exception:
        out["json"] = None

    # pickle
    try:
        b = pickle.dumps(payload, protocol=pickle.HIGHEST_PROTOCOL)
        if len(b) <= max_pickle_bytes:
            out["pickle_b64"] = base64.b64encode(b).decode("ascii")
            out["pickle_bytes"] = len(b)
        else:
            out["pickle_b64"] = None
            out["pickle_bytes"] = len(b)
    except Exception:
        out["pickle_b64"] = None
        out["pickle_bytes"] = None

    return out


@dataclass(frozen=True)
class ProtocolRecord:
    t: float
    src: str
    dst: str
    kind: str
    payload: Any


class ProtocolLogger:
    """Append-only JSONL protocol logger."""

    def __init__(self, path: Optional[str] = None):
        # Resolve early so all processes agree on the same absolute location.
        # This avoids surprises with multiprocessing (Windows spawn) where the
        # working directory may differ between parent/child processes.
        if path:
            try:
                path = os.path.abspath(path)
            except Exception:
                pass

        self.path = path
        self._fh = None
        if path:
            os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
            # Create the file immediately even if no events are logged.
            # This makes downstream export workflows predictable.
            try:
                with open(path, "a", encoding="utf-8"):
                    pass
            except Exception:
                pass
            self._fh = open(path, "w", encoding="utf-8")

    def close(self) -> None:
        if self._fh:
            self._fh.flush()
            self._fh.close()
            self._fh = None

    def log(self, *, t: float, src: str, dst: str, kind: str, payload: Any) -> None:
        if not self._fh:
            return
        rec = ProtocolRecord(t=float(t), src=str(src), dst=str(dst), kind=str(kind), payload=_safe_payload(payload))
        self._fh.write(json.dumps(asdict(rec), ensure_ascii=False) + "\n")

    @staticmethod
    def export_jsonl_to_csv(jsonl_path: str, csv_path: str) -> None:
        import csv

        with open(jsonl_path, "r", encoding="utf-8") as fin, open(csv_path, "w", newline="", encoding="utf-8") as fout:
            w = csv.DictWriter(fout, fieldnames=["t", "src", "dst", "kind", "payload"])
            w.writeheader()
            for line in fin:
                line = line.strip()
                if not line:
                    continue
                obj = json.loads(line)
                w.writerow({
                    "t": obj.get("t"),
                    "src": obj.get("src"),
                    "dst": obj.get("dst"),
                    "kind": obj.get("kind"),
                    "payload": json.dumps(obj.get("payload"), ensure_ascii=False),
                })


class MonotonicClock:
    def __init__(self):
        self._t0 = time.monotonic()

    def now(self) -> float:
        return time.monotonic() - self._t0
