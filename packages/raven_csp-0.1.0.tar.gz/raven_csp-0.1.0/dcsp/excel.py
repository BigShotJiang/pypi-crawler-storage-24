from __future__ import annotations

from typing import Callable

from csp.excel import make_excel_csp_factory

from .mapping import build_variable_agent_model


def make_excel_dcsp_factory(filepath: str, *, sheet_name: str | None = None) -> Callable[[], object]:
    """Return a factory that instantiates a DCSP model from an Excel file.

    This keeps the instantiation logic identical to the existing CSP framework.
    """

    csp_factory = make_excel_csp_factory(filepath, sheet_name=sheet_name)

    def _factory():
        csp = csp_factory()
        return build_variable_agent_model(csp)

    return _factory
