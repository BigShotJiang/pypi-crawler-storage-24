from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List


@dataclass
class DistributedSearchResult:
    algorithm: str
    satisfiable: bool
    assignment: Dict[str, Any]
    runtime: float
    sim_time: int
    processed_events: int
    metrics: Dict[str, Any] = field(default_factory=dict)
    per_agent: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    reason: str = ""
    architecture: str = "variable"

    # Optional protocol log (JSONL) written during the run.
    protocol_path: str = ""

    # Optional enumeration output (empty if not requested / not available).
    solutions: List[Dict[str, Any]] = field(default_factory=list)


def __post_init__(self) -> None:
    # Some solvers (notably in prebuilt architectures) populate `solutions`
    # but leave `assignment` empty. For convenience, mirror the first
    # solution into `assignment` when satisfiable.
    if self.satisfiable and (not self.assignment) and self.solutions:
        self.assignment = dict(self.solutions[0])

    def export_protocol_csv(self, csv_path: str) -> None:
        """Convert the JSONL protocol log to CSV (if available)."""
        if not self.protocol_path:
            raise ValueError("No protocol_path recorded for this result.")
        from .protocol import ProtocolLogger

        ProtocolLogger.export_jsonl_to_csv(self.protocol_path, csv_path)
