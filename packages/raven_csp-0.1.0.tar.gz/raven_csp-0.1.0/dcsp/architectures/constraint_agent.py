from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Sequence, Set, Tuple

from csp.core import CSP, Constraint

from .base import AgentSpec, DCSPModel


def validate_constraint_assignment(csp: CSP, assignment: Sequence[Tuple[str, ...]]) -> None:
    """Validate user-defined constraint -> agent partition.

    Parameters
    ----------
    csp
        Centralized CSP instance.
    assignment
        A list/sequence of tuples. Each tuple corresponds to one agent and contains
        the *names* of the constraints managed by that agent.

    Raises
    ------
    ValueError
        If constraints are missing, unknown, or assigned multiple times.
    """

    if not isinstance(assignment, Sequence) or len(assignment) == 0:
        raise ValueError("assignment must be a non-empty sequence of tuples")

    # Flatten and validate types.
    flat: List[str] = []
    for i, t in enumerate(assignment):
        if not isinstance(t, tuple):
            raise ValueError(
                f"assignment[{i}] must be a tuple of constraint names, got {type(t).__name__}"
            )
        for name in t:
            if not isinstance(name, str):
                raise ValueError(
                    f"constraint name in assignment[{i}] must be str, got {type(name).__name__}"
                )
            flat.append(name)

    c_names = set(csp.constraints.keys())
    a_names = set(flat)

    unknown = sorted(a_names - c_names)
    if unknown:
        raise ValueError(f"Unknown constraint names in assignment: {unknown}")

    missing = sorted(c_names - a_names)
    if missing:
        raise ValueError(f"Constraints missing from assignment: {missing}")

    # Check duplicates.
    seen: Set[str] = set()
    dup: Set[str] = set()
    for name in flat:
        if name in seen:
            dup.add(name)
        seen.add(name)
    if dup:
        raise ValueError(f"Constraints assigned to multiple agents: {sorted(dup)}")


def build_constraint_agent_model(csp: CSP, assignment: Sequence[Tuple[str, ...]]) -> DCSPModel:
    """Build a DCSP model where agents own constraints (not variables).

    Ownership is defined by `assignment` (one tuple per agent).
    The communication graph is induced by shared variables between agents.
    """

    validate_constraint_assignment(csp, assignment)

    # Create agent ids deterministically.
    agent_ids = [f"A{i}" for i in range(len(assignment))]

    # constraint_to_agent (unique ownership)
    constraint_to_agent: Dict[str, str] = {}
    for aid, cons_names in zip(agent_ids, assignment):
        for cname in cons_names:
            constraint_to_agent[cname] = aid

    # Build each agent's local scope: all variables occurring in its constraints.
    agents: Dict[str, AgentSpec] = {}
    agent_scope: Dict[str, Set[str]] = {aid: set() for aid in agent_ids}
    agent_constraints: Dict[str, List[Constraint]] = {aid: [] for aid in agent_ids}

    for cname, cons in csp.constraints.items():
        aid = constraint_to_agent[cname]
        agent_constraints[aid].append(cons)
        for v in cons.variables:
            if v in csp.variables:
                agent_scope[aid].add(v)

    # Handle variables that appear in no constraint.
    vars_in_any: Set[str] = set()
    for cons in csp.constraints.values():
        for v in cons.variables:
            if v in csp.variables:
                vars_in_any.add(v)
    free_vars = sorted(set(csp.variables.keys()) - vars_in_any)
    if free_vars:
        # Deterministic policy: attach to first agent.
        agent_scope[agent_ids[0]].update(free_vars)

    # var_to_agents (many-to-many): who *mentions* a variable.
    var_to_agents: Dict[str, Set[str]] = {v: set() for v in csp.variables}
    for aid, scope in agent_scope.items():
        for v in scope:
            var_to_agents[v].add(aid)

    # Legacy var_to_agent (primary agent): smallest index that sees v.
    var_to_agent: Dict[str, str] = {}
    for v, aids in var_to_agents.items():
        if not aids:
            # Should not happen due to free-var attachment, but keep it safe.
            var_to_agent[v] = agent_ids[0]
        else:
            var_to_agent[v] = sorted(aids, key=lambda x: int(x[1:]) if x[1:].isdigit() else x)[0]

    # Neighbors induced by shared vars.
    neighbors: Dict[str, Set[str]] = {aid: set() for aid in agent_ids}
    for i, a in enumerate(agent_ids):
        for b in agent_ids[i + 1 :]:
            shared = agent_scope[a].intersection(agent_scope[b])
            if shared:
                neighbors[a].add(b)
                neighbors[b].add(a)

    for aid in agent_ids:
        scope_vars = tuple(sorted(agent_scope[aid]))
        domains = {v: sorted(list(csp.variables[v].domain)) for v in scope_vars}
        agents[aid] = AgentSpec(
            agent_id=aid,
            controlled_vars=scope_vars,
            domains=domains,
            constraints=tuple(agent_constraints[aid]),
            metadata={
                "type": "constraint_agent",
                "owned_constraint_names": tuple(sorted([c.name for c in agent_constraints[aid]])),
            },
        )

    md: Dict[str, Any] = {}
    if free_vars:
        md["free_vars"] = tuple(free_vars)

    return DCSPModel(
        csp=csp,
        agents=agents,
        neighbors=neighbors,
        var_to_agent=var_to_agent,
        constraint_to_agent=constraint_to_agent,
        var_to_agents=var_to_agents,
        capabilities={"constraint_agents", "constraint_ownership", "shared_variable_neighbors"},
    )


@dataclass
class ConstraintAgentArchitecture:
    """DCSP mapping where each agent owns one or more constraints.

    The user must provide a partition of constraints via `assignment`.
    """

    name: str = "constraint"

    def build(self, csp: CSP, **kwargs: Any) -> DCSPModel:
        if "assignment" not in kwargs or kwargs["assignment"] is None:
            raise ValueError(
                "ConstraintAgentArchitecture requires keyword argument 'assignment' "
                "(list of tuples of constraint names)"
            )
        return build_constraint_agent_model(csp, assignment=kwargs["assignment"])
