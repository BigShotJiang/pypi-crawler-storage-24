"""Agent architecture layer.

An architecture maps a centralized CSP instance to an agent model.
This is the main extension point when you want to compare different
agent organisations (one-variable-per-agent, multi-variable agents,
constraint agents, hybrid structures).
"""

from .base import AgentSpec, DCSPModel, Architecture
from .variable_agent import VariableAgentArchitecture, build_variable_agent_model
from .constraint_agent import (
    ConstraintAgentArchitecture,
    build_constraint_agent_model,
    validate_constraint_assignment,
)

__all__ = [
    "AgentSpec",
    "DCSPModel",
    "Architecture",
    "VariableAgentArchitecture",
    "build_variable_agent_model",
    "ConstraintAgentArchitecture",
    "build_constraint_agent_model",
    "validate_constraint_assignment",
]
