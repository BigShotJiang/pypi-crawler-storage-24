from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Mapping, Optional, Protocol, Set, Tuple

from csp.core import CSP, Constraint


@dataclass(frozen=True)
class AgentSpec:
    """What an agent *controls* and what it *knows*.

    The design is intentionally generic.
    - controlled_vars can be one variable or a tuple of multiple variables
    - domains maps each controlled variable to its domain values
    - constraints are the constraints this agent can evaluate locally

    Algorithms that assume the classic setting (one variable per agent)
    should check for len(controlled_vars) == 1.
    """

    agent_id: str
    controlled_vars: Tuple[str, ...]
    domains: Mapping[str, List[Any]]
    constraints: Tuple[Constraint, ...]

    metadata: Mapping[str, Any] = field(default_factory=dict)

    @property
    def var(self) -> str:
        """Convenience for classic algorithms that require one variable per agent."""

        if len(self.controlled_vars) != 1:
            raise ValueError("AgentSpec.var is only valid for single-variable agents")
        return self.controlled_vars[0]

    def domain(self) -> List[Any]:
        if len(self.controlled_vars) != 1:
            raise ValueError("AgentSpec.domain() is only valid for single-variable agents")
        return list(self.domains[self.controlled_vars[0]])


@dataclass
class DCSPModel:
    """A distributed view derived from a centralized CSP instance."""

    csp: CSP
    agents: Dict[str, AgentSpec]
    neighbors: Dict[str, Set[str]]

    # Fast lookup for classic variable-agent ownership.
    # NOTE: For architectures where variables are not uniquely owned (e.g., constraint agents),
    # this mapping is a deterministic *projection* ("primary agent") and should not be used
    # unless an algorithm explicitly checks the required capabilities.
    var_to_agent: Dict[str, str]

    # Optional ownership views for non-classic architectures.
    # - constraint_to_agent is the unique owner of each constraint (if applicable).
    # - var_to_agents captures the full set of agents that have a variable in their local scope.
    constraint_to_agent: Dict[str, str] = field(default_factory=dict)
    var_to_agents: Dict[str, Set[str]] = field(default_factory=dict)

    # A lightweight mechanism to let algorithms check assumptions.
    capabilities: Set[str] = field(default_factory=set)

    def agent_of_var(self, var: str) -> str:
        return self.var_to_agent[var]


class Architecture(Protocol):
    """Maps CSP -> DCSPModel."""

    name: str

    def build(self, csp: CSP, **kwargs: Any) -> DCSPModel:  # pragma: no cover
        ...
