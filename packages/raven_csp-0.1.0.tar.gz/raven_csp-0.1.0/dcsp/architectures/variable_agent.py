from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Set

from csp.core import CSP, Constraint

from .base import AgentSpec, DCSPModel


@dataclass
class VariableAgentArchitecture:
    """Classic DCSP mapping where each agent controls exactly one variable."""

    name: str = "variable"

    def build(self, csp: CSP, **kwargs: Any) -> DCSPModel:
        return build_variable_agent_model(csp)


def build_variable_agent_model(csp: CSP) -> DCSPModel:
    agents: Dict[str, AgentSpec] = {}
    neighbors: Dict[str, Set[str]] = {v: set() for v in csp.variables}

    # Collect constraints per variable
    cons_by_var: Dict[str, List[Constraint]] = {v: [] for v in csp.variables}
    for cons in csp.constraints.values():
        for v in cons.variables:
            if v in cons_by_var:
                cons_by_var[v].append(cons)

        # Neighbor graph induced by constraint scopes
        scope = [v for v in cons.variables if v in csp.variables]
        for i in range(len(scope)):
            for j in range(i + 1, len(scope)):
                a, b = scope[i], scope[j]
                neighbors[a].add(b)
                neighbors[b].add(a)

    var_to_agent = {v: v for v in csp.variables}

    for v, var in csp.variables.items():
        agents[v] = AgentSpec(
            agent_id=v,
            controlled_vars=(v,),
            domains={v: sorted(list(var.domain))},
            constraints=tuple(cons_by_var[v]),
            metadata={},
        )

    return DCSPModel(
        csp=csp,
        agents=agents,
        neighbors=neighbors,
        var_to_agent=var_to_agent,
        capabilities={"single_variable_agents", "constraint_graph_neighbors"},
    )
