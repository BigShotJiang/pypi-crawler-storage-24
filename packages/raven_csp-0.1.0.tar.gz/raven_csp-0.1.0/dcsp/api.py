from __future__ import annotations

from csp.api import run_propagation as run_csp_propagation
from csp.api import run_search as run_csp_search
from csp.results import PropagationResult
from csp.instrument import BenchmarkTimer

from .registry import get_architecture
from .strategies import get_strategy
from .metrics import DCSPMetrics
from .results import DistributedSearchResult
from .propagation import run_distributed_gac
from .architectures.base import DCSPModel
from .architectures.variable_agent import build_variable_agent_model
from .architectures.constraint_agent import build_constraint_agent_model



def _infer_rebuild_model_from_prebuilt(model: DCSPModel):
    """Infer a rebuild_model callable for solution enumeration from a prebuilt DCSPModel.

    This is used when find_all_solutions=True and the algorithm needs to restart on a modified CSP.
    """
    caps = set(getattr(model, "capabilities", set()) or set())

    # Classic variable-agent architecture
    if "single_variable_agents" in caps:
        return lambda new_csp: build_variable_agent_model(new_csp)

    # Constraint-agent architecture
    if "constraint_agents" in caps:
        # Reconstruct a deterministic assignment from per-agent metadata.
        agent_ids = sorted(
            model.agents.keys(),
            key=lambda aid: int(aid[1:]) if (isinstance(aid, str) and len(aid) > 1 and aid[1:].isdigit()) else str(aid),
        )
        assignment = []
        for aid in agent_ids:
            owned = None
            spec = model.agents.get(aid)
            if spec is not None:
                owned = spec.metadata.get("owned_constraint_names", None)
            if not owned:
                owned = tuple(sorted([c for c, a in (model.constraint_to_agent or {}).items() if a == aid]))
            assignment.append(tuple(owned or ()))
        return lambda new_csp: build_constraint_agent_model(new_csp, assignment=assignment)

    return None


def run_distributed_search(
    algorithm: str,
    csp_or_model,
    *,
    architecture: str = "variable",
    architecture_kwargs: dict | None = None,
    collect_metrics: bool = True,
    max_delay: int = 0,
    random_seed: int = 0,
    deterministic_init: bool = True,
    max_events: int = 1_000_000,
    incomplete_termination: bool = False,
    find_all_solutions: bool = False,
    max_solutions: int | None = None,
    decode_solutions: bool = True,
    keep_aux_vars: bool = False,
    runtime: str = "sim",
    record_protocol: bool = False,
    protocol_path: str | None = None,
) -> DistributedSearchResult:
    """Run a distributed CSP search algorithm on a CSP (centralized) or on a prebuilt DCSPModel.

    If you pass a CSP, the requested architecture is built internally.
    If you pass a DCSPModel, it is used directly (architecture parameters are ignored).
    """

    algo = algorithm.lower().strip()

    # Allow passing either a CSP or a prebuilt DCSPModel.
    if isinstance(csp_or_model, DCSPModel):
        model = csp_or_model
        csp = model.csp
        arch_name = "prebuilt"
        rebuild_model = _infer_rebuild_model_from_prebuilt(model)
    else:
        csp = csp_or_model
        arch = get_architecture(architecture)
        arch_kwargs = dict(architecture_kwargs or {})
        model = arch.build(csp, **arch_kwargs)
        arch_name = arch.name
        rebuild_model = (lambda _csp: arch.build(_csp, **arch_kwargs))

    metrics = DCSPMetrics() if collect_metrics else DCSPMetrics()

    import time as _time
    from pathlib import Path

    if record_protocol and not protocol_path:
        protocol_path = f"dcsp_protocol_{algo}_{int(_time.time())}.jsonl"

    # Normalize protocol_path early to avoid surprises with relative paths.
    if record_protocol and protocol_path:
        try:
            protocol_path = str(Path(protocol_path).expanduser().resolve())
            # Ensure the file exists even if an algorithm terminates before logging.
            Path(protocol_path).parent.mkdir(parents=True, exist_ok=True)
            Path(protocol_path).touch(exist_ok=True)
        except Exception:
            pass

    with BenchmarkTimer() as t:
        StrategyCls = get_strategy(algo)
        solver = StrategyCls(metrics=metrics)

        # The built-in strategies accept a superset of parameters.
        outcome = solver.solve(
            model,
            max_delay=max_delay,
            random_seed=random_seed,
            max_events=max_events,
            deterministic_init=deterministic_init,
            deterministic=deterministic_init,
            incomplete_termination=incomplete_termination,
            find_all_solutions=find_all_solutions,
            max_solutions=max_solutions,
            rebuild_model=rebuild_model,
            runtime=runtime,
            record_protocol=record_protocol,
            protocol_path=protocol_path,
        )

        # Finalize derived metrics (e.g., parallelism profile).
        metrics.finalize_parallelism()
        sim_time = getattr(solver, "sim_time", 0)
        processed = getattr(solver, "processed_events", 0)
        name = getattr(solver, "name", algo)


    # Optional: decode assignments/solutions back to the primal variable space for binarized CSPs.
    if decode_solutions:
        try:
            from csp.encodings import EncodingInfo, decode_assignment
            info = getattr(csp, "encoding_info", None)
            if isinstance(info, EncodingInfo):
                if outcome.assignment:
                    outcome.assignment = decode_assignment(csp, outcome.assignment, keep_aux=keep_aux_vars)  # type: ignore[attr-defined]
                if getattr(outcome, "solutions", None):
                    outcome.solutions = [decode_assignment(csp, s, keep_aux=keep_aux_vars) for s in outcome.solutions]  # type: ignore[attr-defined]
        except Exception:
            pass

    return DistributedSearchResult(
        algorithm=name,
        satisfiable=outcome.satisfiable,
        assignment=outcome.assignment,
        runtime=t.elapsed,
        sim_time=sim_time,
        processed_events=processed,
        metrics=dict(metrics.counters),
        per_agent={aid: dict(c) for aid, c in metrics.per_agent.items()},
        reason=outcome.reason,
        architecture=arch_name,
        solutions=list(outcome.solutions) if getattr(outcome, "solutions", None) else [],
        protocol_path=str(protocol_path or "") if record_protocol else "",
    )


def run_distributed_propagation(
    algorithm: str,
    csp_or_model,
    *,
    architecture: str = "constraint",
    architecture_kwargs: dict | None = None,
    collect_metrics: bool = True,
    max_delay: int = 0,
    random_seed: int = 0,
    max_events: int = 1_000_000,
) -> PropagationResult:
    """Run a distributed *propagation* algorithm on a CSP or a prebuilt DCSPModel and return a reduced CSP.

    This is the distributed counterpart of `csp.api.run_propagation`.

    Currently implemented:
    - dgac: Distributed GAC for the constraint-agent architecture.
    """

    algo = algorithm.lower().strip()

    # Allow passing either a CSP or a prebuilt DCSPModel.
    if isinstance(csp_or_model, DCSPModel):
        model = csp_or_model
        csp = model.csp
    else:
        csp = csp_or_model
        arch = get_architecture(architecture)
        arch_kwargs = dict(architecture_kwargs or {})
        model = arch.build(csp, **arch_kwargs)

    metrics = DCSPMetrics() if collect_metrics else DCSPMetrics()

    if algo not in ("dgac", "distributed-gac", "distributed_gac"):
        raise ValueError(f"Unknown distributed propagation algorithm: {algorithm}")

    with BenchmarkTimer() as t:
        ok, reduced, extra = run_distributed_gac(
            model,
            max_delay=max_delay,
            random_seed=random_seed,
            max_events=max_events,
            metrics=metrics,
        )

    # Parallelism stats were already finalized inside run_distributed_gac(), but keep it safe.
    metrics.finalize_parallelism()

    m = dict(metrics.counters)
    m.update(extra or {})
    m["algorithm"] = "dgac"
    return PropagationResult(algorithm="dgac", ok=ok, reduced_csp=reduced, runtime=t.elapsed, metrics=m)


def print_result(res) -> None:
    """Print results for CSP and DCSP uniformly.

    This function is kept for backwards compatibility. The canonical implementation
    lives in :func:`csp.api.print_result` and supports both centralized and distributed
    result objects.
    """
    from csp.api import print_result as _print

    _print(res)
def solve(
    csp,
    *,
    mode: str = "central",
    algorithm: str = "bt",
    **kwargs,
):
    """Unified entry point for both centralized CSP and distributed DCSP execution.

    Parameters
    ----------
    csp
        A CSP instance from the existing framework.
    mode
        "central" (default), "propagation", or "distributed".
    algorithm
        Centralized algorithms: bt, fc, mac, mc (optionally with suffix, e.g. "mac-gac").
        Distributed algorithms: sbt, abt, awcs.
    kwargs
        Forwarded to the respective runner.

    Returns
    -------
    SearchResult | PropagationResult | DistributedSearchResult
    """

    m = mode.lower().strip()
    if m in ("central", "csp", "search"):
        return run_csp_search(algorithm, csp, **kwargs)
    if m in ("propagation", "propagate"):
        return run_csp_propagation(algorithm, csp, **kwargs)
    if m in ("distributed-propagation", "distributed_propagation", "dprop"):
        return run_distributed_propagation(algorithm, csp, **kwargs)
    if m in ("distributed", "dcsp"):
        return run_distributed_search(algorithm, csp, **kwargs)
    raise ValueError("mode must be one of: 'central', 'propagation', 'distributed-propagation', 'distributed'")