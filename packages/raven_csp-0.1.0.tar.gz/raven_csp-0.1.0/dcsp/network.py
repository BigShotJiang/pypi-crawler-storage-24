from __future__ import annotations

import heapq
import random
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional, Tuple

from .protocol import ProtocolLogger

from .messages import Message


@dataclass
class Scheduled:
    deliver_at: int
    seq: int
    msg: Message


class EventLoop:
    """Discrete-event simulator with bounded, random message delays.

    Implements FIFO delivery per (sender, receiver) channel as assumed in
    classic DCSP models. Delays are integer ticks.
    """

    def __init__(
        self,
        *,
        max_delay: int = 0,
        rng: Optional[random.Random] = None,
    ):
        self.time: int = 0
        self._seq: int = 0
        self._pq: List[Tuple[int, int, Message]] = []
        self.max_delay = max(0, int(max_delay))
        self.rng = rng or random.Random(0)
        # Track last scheduled delivery per channel to preserve FIFO.
        self._last_delivery: Dict[Tuple[str, str], int] = {}

    def empty(self) -> bool:
        return not self._pq

    def schedule(self, msg: Message, delay: Optional[int] = None) -> None:
        if delay is None:
            delay = self.rng.randint(0, self.max_delay) if self.max_delay > 0 else 0
        base = self.time + max(0, int(delay))

        chan = (msg.sender, msg.receiver)
        last = self._last_delivery.get(chan)
        if last is not None and base <= last:
            base = last + 1
        self._last_delivery[chan] = base

        self._seq += 1
        heapq.heappush(self._pq, (base, self._seq, msg))

    def step(self) -> Optional[Message]:
        if not self._pq:
            return None
        deliver_at, _, msg = heapq.heappop(self._pq)
        self.time = max(self.time, deliver_at)
        return msg


class Network:
    """Routes messages to agents via an EventLoop."""

    def __init__(self, loop: EventLoop, *, protocol: Optional[ProtocolLogger] = None):
        self.loop = loop
        self.handlers: Dict[str, Callable[[Message], None]] = {}
        self.protocol = protocol

    def register(self, agent_id: str, handler: Callable[[Message], None]) -> None:
        self.handlers[agent_id] = handler

    def send(self, msg: Message, delay: Optional[int] = None) -> None:
        if self.protocol is not None:
            # Use simulation time.
            try:
                t = float(self.loop.time)
            except Exception:
                t = 0.0
            self.protocol.log(t=t, src=msg.sender, dst=msg.receiver, kind=msg.kind, payload=msg.payload)
        self.loop.schedule(msg, delay=delay)

    def run(self, *, max_events: int = 1_000_000) -> int:
        events = 0
        while events < max_events:
            m = self.loop.step()
            if m is None:
                break
            handler = self.handlers.get(m.receiver)
            if handler is None:
                events += 1
                continue
            handler(m)
            events += 1
        return events
