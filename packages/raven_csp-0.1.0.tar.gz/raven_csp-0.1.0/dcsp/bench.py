from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Dict, Iterable, List, Optional

from csp.core import CSP

from .api import run_distributed_search
from .results import DistributedSearchResult


@dataclass
class BenchmarkRun:
    problem_name: str
    algorithm: str
    seed: int
    result: DistributedSearchResult


def run_benchmark(
    csp_factory: Callable[[], CSP],
    *,
    problem_name: str = "problem",
    algorithms: Iterable[str] = ("sbt", "abt", "awcs"),
    seeds: Iterable[int] = (0, 1, 2, 3, 4),
    max_delay: int = 5,
    deterministic_init: bool = True,
    max_events: int = 2_000_000,
) -> List[BenchmarkRun]:
    runs: List[BenchmarkRun] = []
    for algo in algorithms:
        for seed in seeds:
            csp = csp_factory()
            res = run_distributed_search(
                algo,
                csp,
                max_delay=max_delay,
                random_seed=seed,
                deterministic_init=deterministic_init,
                max_events=max_events,
            )
            runs.append(BenchmarkRun(problem_name=problem_name, algorithm=algo, seed=seed, result=res))
    return runs


def summarize(runs: List[BenchmarkRun]) -> List[Dict[str, object]]:
    rows: List[Dict[str, object]] = []
    for r in runs:
        m = r.result.metrics
        rows.append(
            {
                "problem": r.problem_name,
                "algorithm": r.algorithm,
                "seed": r.seed,
                "sat": r.result.satisfiable,
                "runtime_s": r.result.runtime,
                "messages": m.get("messages_sent", 0),
                "checks": m.get("constraint_checks", 0),
                "value_changes": m.get("value_changes", 0),
                "backtracks": m.get("backtracks", 0),
                "nogoods": m.get("nogoods_generated", 0),
                "priority_changes": m.get("priority_changes", 0),
            }
        )
    return rows
