from __future__ import annotations

import multiprocessing as mp
import queue
import time
from dataclasses import dataclass
from typing import Any, Callable, Dict, Optional, Tuple

from .messages import Message
from .protocol import MonotonicClock, ProtocolLogger


# ------------------------ Metrics proxy (worker -> master) ------------------------


class MPMetricsProxy:
    """Worker-side metrics proxy.

    Workers cannot safely mutate the shared DCSPMetrics object. Instead, they
    emit small events to the master, which updates the real metrics container.
    """

    def __init__(self, ctrl: mp.Queue):
        self._ctrl = ctrl

    def inc(self, key: str, by: int = 1) -> None:
        self._ctrl.put(("METRIC", None, str(key), int(by)))

    def inc_agent(self, agent_id: str, key: str, by: int = 1) -> None:
        self._ctrl.put(("METRIC", str(agent_id), str(key), int(by)))

    def record_activity(self, time_unit: int, agent_id: str) -> None:
        self._ctrl.put(("ACT", int(time_unit), str(agent_id)))

    def set_time_offset(self, offset: int) -> None:
        self._ctrl.put(("PAR_OFF", int(offset)))


# ------------------------ MP network compatible with existing agents ------------------------


class _LoopView:
    def __init__(self, clock: MonotonicClock):
        self._clock = clock

    @property
    def time(self) -> int:
        # milliseconds as int (stable, monotonic)
        return int(self._clock.now() * 1000.0)


class MPNetwork:
    """Network shim passed into existing agent implementations.

    Implements .send(Message) and exposes .loop.time.
    """

    def __init__(self, inboxes: Dict[str, mp.Queue], ctrl: mp.Queue, clock: MonotonicClock):
        self.inboxes = inboxes
        self.ctrl = ctrl
        self.loop = _LoopView(clock)

    def send(self, msg: Message) -> None:
        # Protocol event + inflight tracking live in master via ctrl queue.
        self.ctrl.put(("SEND", msg.sender, msg.receiver, msg.kind, msg.payload, self.loop.time))
        self.inboxes[msg.receiver].put(msg)


# ------------------------ Worker runner ------------------------


def _default_report_state(agent_obj: Any) -> Dict[str, Any]:
    """Pickle-safe, generic state snapshot.

    Do not rely on non-picklable callables: on Windows the multiprocessing
    start method is "spawn".
    """
    out: Dict[str, Any] = {}
    if hasattr(agent_obj, "current_value"):
        out["current_value"] = getattr(agent_obj, "current_value")
    if hasattr(agent_obj, "var"):
        out["var"] = getattr(agent_obj, "var")
    if hasattr(agent_obj, "terminated"):
        out["terminated"] = bool(getattr(agent_obj, "terminated"))
    if hasattr(agent_obj, "no_solution"):
        out["no_solution"] = bool(getattr(agent_obj, "no_solution"))
    return out


def _worker_loop(
    aid: str,
    agent_obj: Any,
    inbox: mp.Queue,
    ctrl: mp.Queue,
) -> None:
    """Generic worker loop for event-driven agents.

    The agent_obj is expected to implement .on_message(Message).
    """
    seen_nosol = False
    seen_term = False
    while True:
        msg = inbox.get()

        # master-only control messages (not part of algorithm semantics)
        if msg.kind == "__stop__":
            return
        if msg.kind == "__report__":
            # Prefer an agent-provided snapshot method if present.
            if hasattr(agent_obj, "protocol_report") and callable(getattr(agent_obj, "protocol_report")):
                try:
                    st = agent_obj.protocol_report()
                except Exception:
                    st = _default_report_state(agent_obj)
            elif hasattr(agent_obj, "report_state") and callable(getattr(agent_obj, "report_state")):
                try:
                    st = agent_obj.report_state()
                except Exception:
                    st = _default_report_state(agent_obj)
            else:
                st = _default_report_state(agent_obj)
            ctrl.put(("STATE", aid, st))
            continue

        if msg.kind == "__control__":
            # Master-driven step for synchronous algorithms.
            cmd, payload = msg.payload
            try:
                if hasattr(agent_obj, "on_control"):
                    agent_obj.on_control(cmd, payload)
                ctrl.put(("CTRL_ACK", aid, cmd))
            except Exception as e:
                ctrl.put(("ERROR", aid, repr(e)))
                return
            continue

        # Inflight decrement is triggered on receive.
        ctrl.put(("RECV", aid))

        try:
            agent_obj.on_message(msg)
        except Exception as e:
            ctrl.put(("ERROR", aid, repr(e)))
            return

        # Heuristic notifications for master termination logic.
        if hasattr(agent_obj, "no_solution") and getattr(agent_obj, "no_solution") and not seen_nosol:
            ctrl.put(("NOSOL", aid))
            seen_nosol = True
        if hasattr(agent_obj, "terminated") and getattr(agent_obj, "terminated") and not seen_term:
            ctrl.put(("TERM", aid))
            seen_term = True


# ------------------------ Master runner helpers ------------------------


@dataclass
class MPRunOutcome:
    assignment: Dict[str, Any]
    satisfiable: bool
    terminated: bool
    reason: str
    sim_time_ms: int
    processed_events: int
    states: Dict[str, Dict[str, Any]] = None  # final worker snapshots
    protocol_path: Optional[str] = None


def run_event_driven_mp(
    *,
    agents: Dict[str, Any],
    inboxes: Dict[str, mp.Queue],
    ctrl: mp.Queue,
    metrics,  # real DCSPMetrics in master
    protocol_path: Optional[str],
    max_events: int,
    quiescence_ms: int = 200,
    request_report: Callable[[str, Any], Dict[str, Any]] | None = None,
    decide_outcome: Callable[[Dict[str, Dict[str, Any]], bool], Tuple[bool, bool, str, Dict[str, Any]]] | None = None,
) -> MPRunOutcome:
    """Run a set of event-driven agents until quiescence or UNSAT notification.

    - `agents` are agent objects already initialized (including any initial sends).
    - `request_report` if provided transforms agent state into a dict.
    - `decide_outcome` consumes (states, had_nosol) and returns
        (satisfiable, terminated, reason, assignment).
    """
    clock = MonotonicClock()
    plog = ProtocolLogger(protocol_path)

    ctx = mp.get_context("fork") if "fork" in mp.get_all_start_methods() else mp.get_context()
    procs = []

    # NOTE: Do NOT pass callables (lambdas/closures) to worker processes.
    # On Windows (spawn), they are not picklable. Workers compute snapshots
    # via agent_obj.protocol_report()/report_state() or fallback.

    for aid, a in agents.items():
        p = ctx.Process(target=_worker_loop, args=(aid, a, inboxes[aid], ctrl))
        p.daemon = True
        p.start()
        procs.append(p)

    inflight = 0
    processed = 0
    had_nosol = False
    last_activity = time.monotonic()

    # States returned on demand.
    states: Dict[str, Dict[str, Any]] = {}

    def _drain_ctrl(timeout: float = 0.05) -> None:
        nonlocal inflight, processed, had_nosol, last_activity
        try:
            item = ctrl.get(timeout=timeout)
        except queue.Empty:
            return

        last_activity = time.monotonic()
        tag = item[0]
        if tag == "SEND":
            _, src, dst, kind, payload, t_ms = item
            inflight += 1
            processed += 1
            plog.log(t=float(t_ms) / 1000.0, src=src, dst=dst, kind=kind, payload=payload)
        elif tag == "RECV":
            inflight = max(0, inflight - 1)
        elif tag == "METRIC":
            _, aid, key, by = item
            if aid is None:
                metrics.inc(key, by)
            else:
                metrics.inc_agent(aid, key, by)
        elif tag == "ACT":
            _, t, aid = item
            metrics.record_activity(int(t), str(aid))
        elif tag == "PAR_OFF":
            _, off = item
            metrics.set_time_offset(int(off))
        elif tag == "NOSOL":
            had_nosol = True
        elif tag == "STATE":
            _, aid, st = item
            states[str(aid)] = dict(st)
        elif tag == "ERROR":
            _, aid, err = item
            had_nosol = True
            states[str(aid)] = {"error": err}
        else:
            # ignore TERM etc.
            pass

    # Main termination loop.
    while processed < max_events:
        _drain_ctrl(timeout=0.05)

        if had_nosol:
            # Broadcast algorithm-level terminate.
            for dst in agents.keys():
                inboxes[dst].put(Message(kind="terminate", sender="__sys__", receiver=dst, payload=None))
            # Drain remaining sends quickly.
            t0 = time.monotonic()
            while inflight > 0 and (time.monotonic() - t0) < 1.0:
                _drain_ctrl(timeout=0.05)
            break

        idle = (time.monotonic() - last_activity) * 1000.0
        if inflight == 0 and idle >= quiescence_ms:
            break

    # Request final state snapshots.
    for dst in agents.keys():
        inboxes[dst].put(Message(kind="__report__", sender="__sys__", receiver=dst, payload=None))
    # Collect states.
    t0 = time.monotonic()
    while len(states) < len(agents) and (time.monotonic() - t0) < 2.0:
        _drain_ctrl(timeout=0.05)

    # Stop workers.
    for dst in agents.keys():
        inboxes[dst].put(Message(kind="__stop__", sender="__sys__", receiver=dst, payload=None))
    for p in procs:
        p.join(timeout=2.0)

    plog.close()

    # Decide outcome.
    if decide_outcome is None:
        # Generic: satisfiable if no nosol and at least one value per var.
        assignment = {}
        for aid, st in states.items():
            if "var" in st and "current_value" in st:
                assignment[aid] = st["current_value"]
        satisfiable = (not had_nosol) and bool(assignment)
        terminated = True
        reason = "stable" if satisfiable else ("no_solution" if had_nosol else "inconclusive")
    else:
        satisfiable, terminated, reason, assignment = decide_outcome(states, had_nosol)

    sim_time_ms = int(clock.now() * 1000.0)
    return MPRunOutcome(
        assignment=assignment,
        satisfiable=satisfiable,
        terminated=terminated,
        reason=reason,
        sim_time_ms=sim_time_ms,
        processed_events=processed,
        states=states,
        protocol_path=protocol_path,
    )
