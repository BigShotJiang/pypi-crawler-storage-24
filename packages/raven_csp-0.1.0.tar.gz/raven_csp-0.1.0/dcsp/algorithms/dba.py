from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set, Tuple

from csp.core import Constraint

from ..architectures.base import DCSPModel
from ..messages import Message
from ..metrics import DCSPMetrics
from ..network import EventLoop, Network
from ..protocol import ProtocolLogger
from ..utils import add_solution_nogood, clone_csp
from .base import AlgorithmBase, SolveOutcome


@dataclass
class _DBAAgent:
    aid: str
    var: str
    domain: List[Any]
    constraints: List[Constraint]
    neighbors: Set[str]
    net: Network
    metrics: DCSPMetrics
    rng: random.Random
    weights: Dict[str, int]

    current_value: Any = None
    neighbor_values: Dict[str, Any] = field(default_factory=dict)

    # From last round's improvement exchange
    neighbor_improves: Dict[str, Tuple[int, int]] = field(default_factory=dict)  # sender -> (step, improve)
    last_step_seen: int = -1

    def _broadcast_value(self) -> None:
        for n in sorted(self.neighbors):
            self.metrics.inc_agent(self.aid, "messages_sent")
            self.metrics.inc_agent(self.aid, "messages_ok")
            self.net.send(Message(kind="ok", sender=self.aid, receiver=n, payload=(self.var, self.current_value)))

    def _broadcast_improve(self, step: int, improve: int, new_value: Any) -> None:
        payload = (step, improve, new_value)
        for n in sorted(self.neighbors):
            self.metrics.inc_agent(self.aid, "messages_sent")
            self.metrics.inc_agent(self.aid, "messages_improve")
            self.net.send(Message(kind="improve", sender=self.aid, receiver=n, payload=payload))

    def on_message(self, msg: Message) -> None:
        if msg.kind == "ok":
            var, val = msg.payload
            self.neighbor_values[var] = val
            return
        if msg.kind == "improve":
            step, improve, _ = msg.payload
            self.neighbor_improves[msg.sender] = (step, int(improve))
            self.last_step_seen = max(self.last_step_seen, int(step))
            return

    def _local_weighted_cost(self, value: Any) -> int:
        assign = dict(self.neighbor_values)
        assign[self.var] = value
        cost = 0
        for c in self.constraints:
            if all(v in assign for v in c.variables):
                self.metrics.inc_agent(self.aid, "constraint_checks")
                if not c.evaluate(assign):
                    cost += int(self.weights.get(c.name, 1))
        return cost

    def _violated_constraints(self) -> List[str]:
        assign = dict(self.neighbor_values)
        assign[self.var] = self.current_value
        violated: List[str] = []
        for c in self.constraints:
            if all(v in assign for v in c.variables):
                self.metrics.inc_agent(self.aid, "constraint_checks")
                if not c.evaluate(assign):
                    violated.append(c.name)
        return violated

    def best_move(self) -> Tuple[int, Any, int]:
        """Return (current_cost, best_value, best_cost)."""
        cur = self._local_weighted_cost(self.current_value)
        best_cost = cur
        best_vals: List[Any] = [self.current_value]
        for v in self.domain:
            c = self._local_weighted_cost(v)
            if c < best_cost:
                best_cost = c
                best_vals = [v]
            elif c == best_cost:
                best_vals.append(v)
        # Deterministic-ish tie breaking for reproducibility
        chosen = best_vals[0]
        if len(best_vals) > 1:
            chosen = self.rng.choice(best_vals)
        return cur, chosen, best_cost

    def should_move(self, *, step: int, my_improve: int) -> bool:
        if my_improve <= 0:
            return False

        # Collect neighbor improvements for this step (ignore stale ones).
        neigh_imps: List[Tuple[int, str]] = []
        for n, (st, imp) in self.neighbor_improves.items():
            if st == step:
                neigh_imps.append((imp, n))

        if not neigh_imps:
            return True

        max_imp = max(imp for imp, _ in neigh_imps)
        if my_improve > max_imp:
            return True
        if my_improve < max_imp:
            return False

        # Tie-break on agent id (lexicographically smallest wins).
        contenders = [n for imp, n in neigh_imps if imp == max_imp]
        return self.aid < min(contenders)


class DistributedBreakoutAlgorithm(AlgorithmBase):
    """Distributed Breakout Algorithm (DBA), synchronous local search.

    DBA is an incomplete, iterative improvement algorithm. It augments local search
    with adaptive weights on violated constraints to escape quasi-local minima.

    Enumeration support is provided by restart + solution-forbidding constraints.
    """

    name = "dba"

    def __init__(self, *, metrics: Optional[DCSPMetrics] = None):
        super().__init__(metrics=metrics)

    def solve(
        self,
        model: DCSPModel,
        *,
        max_delay: int = 0,
        random_seed: int = 0,
        max_events: int = 50_000,
        deterministic_init: bool = False,
        breakout_increment: int = 1,
        record_protocol: bool = False,
        protocol_path: Optional[str] = None,
        find_all_solutions: bool = False,
        max_solutions: Optional[int] = None,
        rebuild_model=None,
        **_: Any,
    ) -> SolveOutcome:
        if not find_all_solutions:
            return self._solve_once(
                model,
                max_delay=max_delay,
                random_seed=random_seed,
                max_cycles=max_events,
                deterministic_init=deterministic_init,
                breakout_increment=breakout_increment,
                record_protocol=record_protocol,
                protocol_path=protocol_path,
            )

        if rebuild_model is None:
            raise ValueError("find_all_solutions=True requires a rebuild_model callable (CSP -> DCSPModel).")

        csp_work = clone_csp(model.csp)
        solutions: List[Dict[str, Any]] = []

        total_sim_time = 0
        total_events = 0
        offset = 0

        k = 0
        while True:
            if max_solutions is not None and len(solutions) >= max_solutions:
                reason = "max_solutions"
                terminated = True
                break

            model_k = rebuild_model(csp_work)
            self.metrics.set_time_offset(offset)
            out = self._solve_once(
                model_k,
                max_delay=max_delay,
                random_seed=random_seed + k,
                max_cycles=max_events,
                deterministic_init=deterministic_init,
                breakout_increment=breakout_increment,
                record_protocol=record_protocol,
                protocol_path=protocol_path,
            )
            total_sim_time += getattr(self, "sim_time", 0)
            total_events += getattr(self, "processed_events", 0)
            offset += int(getattr(self, "sim_time", 0)) + 1

            if out.satisfiable and out.terminated:
                sol = dict(out.assignment)
                solutions.append(sol)
                add_solution_nogood(csp_work, sol, name=f"__nogood_sol_{k:04d}")
                k += 1
                continue

            reason = out.reason or "inconclusive"
            terminated = False
            break

        self.metrics.set_time_offset(0)
        self.sim_time = total_sim_time
        self.processed_events = total_events

        self.outcome = SolveOutcome(
            satisfiable=bool(solutions),
            assignment=dict(solutions[0]) if solutions else {},
            terminated=terminated,
            reason=reason,
            solutions=solutions,
        )
        return self.outcome

    def _solve_once(
        self,
        model: DCSPModel,
        *,
        max_delay: int,
        random_seed: int,
        max_cycles: int,
        deterministic_init: bool,
        breakout_increment: int,
        record_protocol: bool = False,
        protocol_path: Optional[str] = None,
    ) -> SolveOutcome:
        if "single_variable_agents" not in model.capabilities:
            raise ValueError("DBA requires an architecture with exactly one variable per agent")

        rng = random.Random(random_seed)
        loop = EventLoop(max_delay=max_delay, rng=rng)
        plog = ProtocolLogger(protocol_path if record_protocol else None)
        net = Network(loop, protocol=plog)

        # Global weight map (shared across agents for consistency).
        weights: Dict[str, int] = {c.name: 1 for c in model.csp.constraints.values()}

        agents: Dict[str, _DBAAgent] = {}
        for aid, spec in model.agents.items():
            dom = list(spec.domain())
            if not dom:
                raise ValueError(f"Empty domain for agent/var '{aid}'.")
            init = dom[0] if deterministic_init else rng.choice(dom)
            a = _DBAAgent(
                aid=aid,
                var=spec.var,
                domain=dom,
                constraints=list(spec.constraints),
                neighbors=set(model.neighbors.get(aid, set())),
                net=net,
                metrics=self.metrics,
                rng=rng,
                weights=weights,
                current_value=init,
            )
            self.metrics.inc_agent(aid, "value_changes")
            agents[aid] = a
            net.register(aid, a.on_message)

        best_assignment: Dict[str, Any] = {aid: a.current_value for aid, a in agents.items()}
        best_global_viol = float("inf")

        cycles = 0
        processed = 0
        while cycles < max_cycles:
            # Parallelism: in DBA each cycle all agents perform a decision step.
            for aid in agents.keys():
                self.metrics.record_activity(cycles, aid)

            # Phase 1: exchange current values.
            for a in agents.values():
                a._broadcast_value()
            processed += net.run(max_events=10_000_000)

            assignment = {aid: a.current_value for aid, a in agents.items()}

            # Global check.
            global_viol = 0
            sat = True
            for cons in model.csp.constraints.values():
                if not cons.evaluate(assignment):
                    sat = False
                    global_viol += 1
            if global_viol < best_global_viol:
                best_global_viol = global_viol
                best_assignment = dict(assignment)

            if sat:
                self.sim_time = loop.time
                self.processed_events = processed
                self.outcome = SolveOutcome(
                    satisfiable=True,
                    assignment=assignment,
                    terminated=True,
                    reason="stable",
                    solutions=[dict(assignment)],
                )
                try:
                    plog.close()  # type: ignore[name-defined]
                except Exception:
                    pass
                return self.outcome

            # Phase 2: compute local improvements and exchange them.
            step = cycles
            moves: Dict[str, Tuple[int, Any, int, int]] = {}
            for aid, a in agents.items():
                cur_cost, best_val, best_cost = a.best_move()
                improve = cur_cost - best_cost
                moves[aid] = (cur_cost, best_val, best_cost, improve)
                a._broadcast_improve(step, improve, best_val)

            processed += net.run(max_events=10_000_000)

            # Phase 3: apply moves (simultaneous) based on neighbor improvements.
            next_vals: Dict[str, Any] = {aid: agents[aid].current_value for aid in agents}
            for aid, a in agents.items():
                cur_cost, best_val, best_cost, improve = moves[aid]
                if a.should_move(step=step, my_improve=improve):
                    next_vals[aid] = best_val

            for aid, a in agents.items():
                if next_vals[aid] != a.current_value:
                    a.current_value = next_vals[aid]
                    self.metrics.inc_agent(aid, "value_changes")

            # Phase 4: breakout (weight increase) for quasi-local minima.
            for aid, a in agents.items():
                cur_cost, _, _, improve = moves[aid]
                if cur_cost > 0 and improve <= 0:
                    violated = a._violated_constraints()
                    if violated:
                        for cid in violated:
                            weights[cid] = int(weights.get(cid, 1)) + int(breakout_increment)
                        self.metrics.inc_agent(aid, "weight_increases", by=len(violated))

            cycles += 1

        self.sim_time = loop.time
        self.processed_events = processed
        self.outcome = SolveOutcome(
            satisfiable=False,
            assignment=best_assignment,
            terminated=False,
            reason="max_cycles",
            solutions=[],
        )
        try:
            plog.close()  # type: ignore[name-defined]
        except Exception:
            pass
        return self.outcome