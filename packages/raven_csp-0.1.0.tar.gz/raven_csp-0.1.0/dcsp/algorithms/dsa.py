from __future__ import annotations

import random
import time
import queue
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set, Tuple

from csp.core import Constraint

from ..architectures.base import DCSPModel
from ..messages import Message
from ..metrics import DCSPMetrics
from ..network import EventLoop, Network
from ..protocol import ProtocolLogger
from ..runtime_mp import MPNetwork, MPMetricsProxy, run_event_driven_mp
import multiprocessing as mp
from ..utils import add_solution_nogood, clone_csp
from .base import AlgorithmBase, SolveOutcome


@dataclass
class _DSAAgent:
    aid: str
    var: str
    domain: List[Any]
    constraints: List[Constraint]
    neighbors: Set[str]
    net: Network
    metrics: DCSPMetrics
    rng: random.Random

    current_value: Any = None
    neighbor_values: Dict[str, Any] = field(default_factory=dict)

    def _broadcast_value(self) -> None:
        for n in sorted(self.neighbors):
            self.metrics.inc_agent(self.aid, "messages_sent")
            # Reuse messages_ok as the generic "value" message counter.
            self.metrics.inc_agent(self.aid, "messages_ok")
            self.net.send(Message(kind="ok", sender=self.aid, receiver=n, payload=(self.var, self.current_value)))

    def on_message(self, msg: Message) -> None:
        if msg.kind == "ok":
            var, val = msg.payload
            self.neighbor_values[var] = val

    def _local_cost(self, value: Any) -> int:
        assign = dict(self.neighbor_values)
        assign[self.var] = value
        cost = 0
        for c in self.constraints:
            # Only count violations when all vars are assigned.
            if all(v in assign for v in c.variables):
                self.metrics.inc_agent(self.aid, "constraint_checks")
                if not c.evaluate(assign):
                    cost += 1
        return cost

    def decide_next_value(self, *, p: float, variant: str) -> Any:
        current_cost = self._local_cost(self.current_value)
        best_cost = current_cost
        best_vals: List[Any] = [self.current_value]

        for v in self.domain:
            c = self._local_cost(v)
            if c < best_cost:
                best_cost = c
                best_vals = [v]
            elif c == best_cost:
                best_vals.append(v)

        delta = current_cost - best_cost
        has_conflict = current_cost > 0
        v = variant.upper().strip()

        # DSA variants (common definitions):
        # A: move with prob p if strictly improving.
        # B: like A, plus lateral moves (delta==0) when in conflict.
        # C: like B, plus lateral moves even when not in conflict.
        # D/E: like B/C but always move on improving (p=1 for improvements).
        move_on_equal = False
        always_on_improve = False
        if v in ("B", "D"):
            move_on_equal = has_conflict
        elif v in ("C", "E"):
            move_on_equal = True
        if v in ("D", "E"):
            always_on_improve = True

        if delta > 0:
            if always_on_improve or self.rng.random() < p:
                choice = self.rng.choice(best_vals)
                return choice
            return self.current_value

        if delta == 0 and move_on_equal:
            # Lateral escape only makes sense if there is an alternative.
            if len(best_vals) >= 2 and (always_on_improve or self.rng.random() < p):
                # Prefer switching away from current value.
                alt = [x for x in best_vals if x != self.current_value]
                if alt:
                    return self.rng.choice(alt)
        return self.current_value


class DistributedStochasticAlgorithm(AlgorithmBase):
    """Distributed Stochastic Algorithm (DSA), synchronous local search.

    This is an incomplete, iterative improvement algorithm. It tries to reduce
    the number of constraint violations by probabilistic local moves.

    Enumeration support is provided by restart + solution-forbidding constraints.
    """

    name = "dsa"

    def __init__(self, *, metrics: Optional[DCSPMetrics] = None):
        super().__init__(metrics=metrics)

    def solve(
        self,
        model: DCSPModel,
        *,
        max_delay: int = 0,
        random_seed: int = 0,
        max_events: int = 50_000,
        deterministic_init: bool = False,
        p: float = 0.7,
        variant: str = "B",
        find_all_solutions: bool = False,
        max_solutions: Optional[int] = None,
        rebuild_model=None,
        runtime: str = "sim",
        record_protocol: bool = False,
        protocol_path: Optional[str] = None,
        **_: Any,
    ) -> SolveOutcome:
        if not find_all_solutions:
            return self._solve_once(
                model,
                max_delay=max_delay,
                random_seed=random_seed,
                max_cycles=max_events,
                deterministic_init=deterministic_init,
                p=p,
                variant=variant,
                runtime=runtime,
                record_protocol=record_protocol,
                protocol_path=protocol_path,
            )

        if rebuild_model is None:
            raise ValueError("find_all_solutions=True requires a rebuild_model callable (CSP -> DCSPModel).")

        csp_work = clone_csp(model.csp)
        solutions: List[Dict[str, Any]] = []

        total_sim_time = 0
        total_events = 0
        offset = 0

        k = 0
        while True:
            if max_solutions is not None and len(solutions) >= max_solutions:
                reason = "max_solutions"
                terminated = True
                break

            model_k = rebuild_model(csp_work)
            self.metrics.set_time_offset(offset)
            out = self._solve_once(
                model_k,
                max_delay=max_delay,
                random_seed=random_seed + k,
                max_cycles=max_events,
                deterministic_init=deterministic_init,
                p=p,
                variant=variant,
                runtime=runtime,
                record_protocol=record_protocol,
                protocol_path=protocol_path,
            )
            total_sim_time += getattr(self, "sim_time", 0)
            total_events += getattr(self, "processed_events", 0)
            offset += int(getattr(self, "sim_time", 0)) + 1

            if out.satisfiable and out.terminated:
                sol = dict(out.assignment)
                solutions.append(sol)
                add_solution_nogood(csp_work, sol, name=f"__nogood_sol_{k:04d}")
                k += 1
                continue

            # DSA cannot prove UNSAT. Stop when we fail to find a new solution.
            reason = out.reason or "inconclusive"
            terminated = False
            break

        self.metrics.set_time_offset(0)
        self.sim_time = total_sim_time
        self.processed_events = total_events

        self.outcome = SolveOutcome(
            satisfiable=bool(solutions),
            assignment=dict(solutions[0]) if solutions else {},
            terminated=terminated,
            reason=reason,
            solutions=solutions,
        )
        return self.outcome

    def _solve_once(
        self,
        model: DCSPModel,
        *,
        max_delay: int,
        random_seed: int,
        max_cycles: int,
        deterministic_init: bool,
        p: float,
        variant: str,
        runtime: str = "sim",
        record_protocol: bool = False,
        protocol_path: Optional[str] = None,
    ) -> SolveOutcome:
        if "single_variable_agents" not in model.capabilities:
            raise ValueError("DSA requires an architecture with exactly one variable per agent")

        if runtime.lower().strip() == "mp":
            return self._solve_once_mp(
                model,
                random_seed=random_seed,
                max_cycles=max_cycles,
                deterministic_init=deterministic_init,
                p=p,
                variant=variant,
                record_protocol=record_protocol,
                protocol_path=protocol_path,
            )

        rng = random.Random(random_seed)
        loop = EventLoop(max_delay=max_delay, rng=rng)
        plog = ProtocolLogger(protocol_path if record_protocol else None)
        net = Network(loop, protocol=plog)

        agents: Dict[str, _DSAAgent] = {}
        for aid, spec in model.agents.items():
            dom = list(spec.domain())
            if not dom:
                raise ValueError(f"Empty domain for agent/var '{aid}'.")
            init = dom[0] if deterministic_init else rng.choice(dom)
            a = _DSAAgent(
                aid=aid,
                var=spec.var,
                domain=dom,
                constraints=list(spec.constraints),
                neighbors=set(model.neighbors.get(aid, set())),
                net=net,
                metrics=self.metrics,
                rng=rng,
                current_value=init,
            )
            self.metrics.inc_agent(aid, "value_changes")
            agents[aid] = a
            net.register(aid, a.on_message)

        best_assignment: Dict[str, Any] = {aid: a.current_value for aid, a in agents.items()}
        best_global_viol = float("inf")

        cycles = 0
        processed = 0
        while cycles < max_cycles:
            # Parallelism: in DSA each cycle all agents perform a decision step.
            for aid in agents.keys():
                self.metrics.record_activity(cycles, aid)

            # Broadcast values (synchronous round).
            for a in agents.values():
                a._broadcast_value()
            processed += net.run(max_events=10_000_000)

            assignment = {aid: a.current_value for aid, a in agents.items()}

            # Global check.
            global_viol = 0
            sat = True
            for cons in model.csp.constraints.values():
                if not cons.evaluate(assignment):
                    sat = False
                    global_viol += 1
            if global_viol < best_global_viol:
                best_global_viol = global_viol
                best_assignment = dict(assignment)

            if sat:
                self.sim_time = loop.time
                self.processed_events = processed
                self.outcome = SolveOutcome(
                    satisfiable=True,
                    assignment=assignment,
                    terminated=True,
                    reason="stable",
                    solutions=[dict(assignment)],
                )
                try:
                    plog.close()  # type: ignore[name-defined]
                except Exception:
                    pass
                return self.outcome

            # Decide moves based on neighbor values from this round.
            next_vals: Dict[str, Any] = {}
            for aid, a in agents.items():
                nv = a.decide_next_value(p=p, variant=variant)
                next_vals[aid] = nv

            # Apply simultaneously.
            for aid, a in agents.items():
                if next_vals[aid] != a.current_value:
                    a.current_value = next_vals[aid]
                    self.metrics.inc_agent(aid, "value_changes")

            cycles += 1

        # Max cycles exhausted.
        self.sim_time = loop.time
        self.processed_events = processed
        self.outcome = SolveOutcome(
            satisfiable=False,
            assignment=best_assignment,
            terminated=False,
            reason="max_cycles",
            solutions=[],
        )
        try:
            plog.close()  # type: ignore[name-defined]
        except Exception:
            pass
        return self.outcome

    def _solve_once_mp(
        self,
        model: DCSPModel,
        *,
        random_seed: int,
        max_cycles: int,
        deterministic_init: bool,
        p: float,
        variant: str,
        record_protocol: bool,
        protocol_path: Optional[str],
    ) -> SolveOutcome:
        rng = random.Random(random_seed)
        ctx = mp.get_context("fork") if "fork" in mp.get_all_start_methods() else mp.get_context()
        ctrl: mp.Queue = ctx.Queue()
        inboxes: Dict[str, mp.Queue] = {aid: ctx.Queue() for aid in model.agents.keys()}
        from ..protocol import MonotonicClock

        clock = MonotonicClock()
        net = MPNetwork(inboxes=inboxes, ctrl=ctrl, clock=clock)
        mproxy = MPMetricsProxy(ctrl)

        @dataclass
        class _DSAProc:
            inner: _DSAAgent

            def on_message(self, msg: Message) -> None:
                self.inner.on_message(msg)

            def on_control(self, cmd: str, payload: Any) -> None:
                if cmd == "broadcast":
                    self.inner._broadcast_value()
                elif cmd == "decide":
                    p_, var_ = payload
                    nv = self.inner.decide_next_value(p=float(p_), variant=str(var_))
                    if nv != self.inner.current_value:
                        self.inner.current_value = nv
                        self.inner.metrics.inc_agent(self.inner.aid, "value_changes")

        agents: Dict[str, _DSAProc] = {}
        for aid, spec in model.agents.items():
            dom = list(spec.domain())
            init = dom[0] if deterministic_init else rng.choice(dom)
            inner = _DSAAgent(
                aid=aid,
                var=spec.var,
                domain=dom,
                constraints=list(spec.constraints),
                neighbors=set(model.neighbors.get(aid, set())),
                net=net,  # type: ignore[arg-type]
                metrics=mproxy,  # type: ignore[arg-type]
                rng=rng,
                current_value=init,
            )
            mproxy.inc_agent(aid, "value_changes")
            agents[aid] = _DSAProc(inner=inner)

        best_assignment: Dict[str, Any] = {aid: a.inner.current_value for aid, a in agents.items()}
        best_global_viol = float("inf")

        # Start workers and drive cycles via control messages.

        # Start workers.
        ctx2 = ctx
        procs = []
        from ..runtime_mp import _worker_loop

        for aid, a in agents.items():
            pproc = ctx2.Process(target=_worker_loop, args=(aid, a, inboxes[aid], ctrl), kwargs={"report_state": lambda obj: {"current_value": obj.inner.current_value}})
            pproc.daemon = True
            pproc.start()
            procs.append(pproc)

        inflight = 0
        processed = 0
        last_activity = time.monotonic()

        # Protocol logger for DSA.
        from ..protocol import ProtocolLogger
        plog = ProtocolLogger(protocol_path if (record_protocol and protocol_path) else None)

        def drain2(timeout=0.05):
            nonlocal inflight, processed, last_activity
            try:
                item = ctrl.get(timeout=timeout)
            except queue.Empty:
                return
            last_activity = time.monotonic()
            tag = item[0]
            if tag == "SEND":
                _, src, dst, kind, payload, t_ms = item
                inflight += 1
                processed += 1
                plog.log(t=float(t_ms)/1000.0, src=src, dst=dst, kind=kind, payload=payload)
            elif tag == "RECV":
                inflight = max(0, inflight - 1)
            elif tag == "METRIC":
                _, aid, key, by = item
                if aid is None:
                    self.metrics.inc(key, by)
                else:
                    self.metrics.inc_agent(aid, key, by)
            elif tag == "ACT":
                _, t, aid = item
                self.metrics.record_activity(int(t), str(aid))
            # ignore others

        for cycle in range(max_cycles):
            for aid in agents.keys():
                self.metrics.record_activity(cycle, aid)

            # Phase 1: broadcast
            for aid in agents.keys():
                inboxes[aid].put(Message(kind="__control__", sender="__sys__", receiver=aid, payload=("broadcast", None)))
            # Prime the inflight counter.
            for _ in range(20):
                drain2(0.01)
            # wait until inflight drained
            t0 = time.monotonic()
            while inflight > 0 and (time.monotonic() - t0) < 2.0:
                drain2(0.05)
            # also drain remaining control acks
            for _ in range(10):
                drain2(0.01)

            # Evaluate global assignment in master (read from local objects via fork shared mem)
            assignment = {aid: a.inner.current_value for aid, a in agents.items()}
            global_viol = 0
            sat = True
            for cons in model.csp.constraints.values():
                if not cons.evaluate(assignment):
                    sat = False
                    global_viol += 1
            if global_viol < best_global_viol:
                best_global_viol = global_viol
                best_assignment = dict(assignment)
            if sat:
                for aid in agents.keys():
                    inboxes[aid].put(Message(kind="__stop__", sender="__sys__", receiver=aid, payload=None))
                for pp in procs:
                    pp.join(timeout=1.0)
                plog.close()
                self.sim_time = int(clock.now()*1000.0)
                self.processed_events = processed
                self.outcome = SolveOutcome(True, assignment, True, reason="stable", solutions=[dict(assignment)])
                return self.outcome

            # Phase 2: decide
            for aid in agents.keys():
                inboxes[aid].put(Message(kind="__control__", sender="__sys__", receiver=aid, payload=("decide", (p, variant))))
            for _ in range(20):
                drain2(0.01)

        # stop
        for aid in agents.keys():
            inboxes[aid].put(Message(kind="__stop__", sender="__sys__", receiver=aid, payload=None))
        for pp in procs:
            pp.join(timeout=1.0)
        plog.close()
        self.sim_time = int(clock.now()*1000.0)
        self.processed_events = processed
        self.outcome = SolveOutcome(False, best_assignment, False, reason="max_cycles", solutions=[])
        return self.outcome