from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Any, Dict, FrozenSet, Iterable, List, Optional, Sequence, Set, Tuple

from csp.core import CSP, Constraint
from csp.solvers import solve_mac

from ..architectures.base import AgentSpec, DCSPModel
from ..messages import Message
from ..metrics import DCSPMetrics
from ..network import EventLoop, Network
from ..runtime_mp import MPNetwork, MPMetricsProxy, run_event_driven_mp
import multiprocessing as mp
from ..protocol import ProtocolLogger
from .base import AlgorithmBase, SolveOutcome


def _build_local_csp(spec: AgentSpec, global_domains: Dict[str, Set[Any]]) -> CSP:
    """Create a centralized CSP for one constraint-agent subproblem."""
    c = CSP()
    for v in spec.controlled_vars:
        c.add_variable(v, set(global_domains[v]))
    for cons in spec.constraints:
        # Only keep constraints fully inside the scope.
        if all(v in c.variables for v in cons.variables):
            c.add_constraint_explicit(cons.name, cons.expression, cons.variables)
    return c


def _project_solution(sol: Dict[str, Any], vars_: Sequence[str]) -> Tuple[Any, ...]:
    return tuple(sol[v] for v in vars_)


@dataclass
class _AASAgent:
    aid: str
    spec: AgentSpec
    neighbors: Set[str]
    shared_vars: Dict[str, Tuple[str, ...]]  # neighbor -> ordered shared vars
    global_domains: Dict[str, Set[Any]]
    deterministic_init: bool = True
    max_local_solutions: Optional[int] = None
    solutions: List[Dict[str, Any]] = field(default_factory=list)
    local_mac_done: bool = False
    allowed_from_neighbor: Dict[str, Set[Tuple[Any, ...]]] = field(default_factory=dict)

    net: Network = field(default=None)
    metrics: DCSPMetrics = field(default=None)
    terminated: bool = False
    failed: bool = False

    def _send_proj(self, other: str) -> None:
        svars = self.shared_vars.get(other, ())
        proj: Set[Tuple[Any, ...]] = set()
        if svars:
            for sol in self.solutions:
                proj.add(_project_solution(sol, svars))
        # If svars is empty, projection is a singleton "()" meaning unconstrained.
        if not svars:
            proj.add(tuple())

        payload = (other, svars, frozenset(proj))
        self.metrics.inc_agent(self.aid, "messages_sent")
        self.metrics.inc_agent(self.aid, "messages_proj")
        self.net.send(Message(kind="proj", sender=self.aid, receiver=other, payload=payload, sent_at=self.net.loop.time))

    def _broadcast_proj(self) -> None:
        for n in sorted(self.neighbors):
            self._send_proj(n)

    def _filter_with_neighbor(self, neighbor: str, allowed: Set[Tuple[Any, ...]]) -> bool:
        """Filter local solutions based on neighbor-provided projection."""
        svars = self.shared_vars.get(neighbor, ())
        if not svars:
            return False

        before = len(self.solutions)
        self.solutions = [sol for sol in self.solutions if _project_solution(sol, svars) in allowed]
        return len(self.solutions) != before

    def on_message(self, msg: Message) -> None:
        self.metrics.record_activity(self.net.loop.time, self.aid)
        if self.terminated:
            return

        if msg.kind == "start":
            # Phase 1: compute local tuple set inside the agent process.
            if not self.local_mac_done:
                local = _build_local_csp(self.spec, self.global_domains)
                from csp.instrument import Counters
                _cnt = Counters()
                res = solve_mac(
                    local,
                    find_all=True,
                    heuristics=["mrv"],
                    deterministic=self.deterministic_init,
                    propagation="gac",
                    counters=_cnt,
                )
                ce = int(_cnt.get("constraint_evaluations", 0))
                if ce:
                    # Keep both per-agent and global counters consistent.
                    self.metrics.inc_agent(self.aid, "constraint_checks", ce)
                    try:
                        self.metrics.inc("constraint_checks", ce)
                    except Exception:
                        pass
                sols = list(res.get("solutions", []))
                if self.max_local_solutions is not None:
                    sols = sols[: int(self.max_local_solutions)]
                self.solutions = sols
                self.metrics.inc_agent(self.aid, "local_solutions", by=len(sols))
                self.local_mac_done = True
                if not self.solutions:
                    # Local impossibility => global fail.
                    self.failed = True
                    self.terminated = True
                    for n in sorted(self.neighbors):
                        self.metrics.inc_agent(self.aid, "messages_sent")
                        self.metrics.inc_agent(self.aid, "messages_fail")
                        self.net.send(
                            Message(kind="fail", sender=self.aid, receiver=n, payload="empty_local_relation", sent_at=self.net.loop.time)
                        )
                    return

            # Phase 2: send initial projections.
            self._broadcast_proj()
            return

        if msg.kind == "fail":
            self.failed = True
            self.terminated = True
            return

        if msg.kind == "proj":
            _to, _svars, proj_frozen = msg.payload[0], msg.payload[1], msg.payload[2]
            allowed = set(proj_frozen)
            self.allowed_from_neighbor[msg.sender] = allowed

            changed = self._filter_with_neighbor(msg.sender, allowed)
            if changed:
                self.metrics.inc_agent(self.aid, "local_solutions_pruned")
                if not self.solutions:
                    # Local impossibility => global fail.
                    self.failed = True
                    self.terminated = True
                    for n in sorted(self.neighbors):
                        self.metrics.inc_agent(self.aid, "messages_sent")
                        self.metrics.inc_agent(self.aid, "messages_fail")
                        self.net.send(
                            Message(kind="fail", sender=self.aid, receiver=n, payload="empty_local_relation", sent_at=self.net.loop.time)
                        )
                    return
                # Inform all neighbors about updated projection.
                self._broadcast_proj()
            return

    def report_state(self) -> Dict[str, Any]:
        # Returned to master at end of MP run.
        return {
            "failed": bool(self.failed),
            "terminated": bool(self.terminated),
            "n_solutions": int(len(self.solutions)),
            "solutions": self.solutions,
        }



class AsynchronousAggregationSearch(AlgorithmBase):
    """Asynchronous Aggregation Search (AAS) for the constraint-agent architecture.

    Practical version for this framework:

    1) Each constraint agent enumerates the satisfying tuples of its local sub-CSP
       (constraints it owns) using the centralized MAC(GAC) solver.
    2) Agents asynchronously exchange *projections* of those tuples onto shared
       variables and prune their local tuple sets until a fixpoint is reached.
    3) A global solution (or all solutions) is assembled by solving the induced
       "agent-join" problem over the remaining local tuple sets.

    This matches the AAS idea of searching in an aggregated space (sets of tuples)
    while keeping the implementation compact and compatible with arbitrary n-ary
    constraints.
    """

    name = "aas"

    def __init__(self, *, metrics: Optional[DCSPMetrics] = None):
        super().__init__(metrics=metrics)

    @staticmethod
    def _assemble_global_solutions(
        agents: List[_AASAgent],
        *,
        find_all: bool,
        max_solutions: Optional[int],
    ) -> List[Dict[str, Any]]:
        """Backtracking join over agent tuple sets with agreement on shared variables."""
        # Deterministic variable ordering: smallest remaining domain first.
        order = sorted(agents, key=lambda a: (len(a.solutions), a.aid))

        solutions: List[Dict[str, Any]] = []

        def consistent(prefix: Dict[str, Any], sol: Dict[str, Any]) -> bool:
            for v, val in sol.items():
                if v in prefix and prefix[v] != val:
                    return False
            return True

        def extend(prefix: Dict[str, Any], sol: Dict[str, Any]) -> Dict[str, Any]:
            out = dict(prefix)
            out.update(sol)
            return out

        def bt(i: int, partial: Dict[str, Any]) -> None:
            nonlocal solutions
            if max_solutions is not None and len(solutions) >= max_solutions:
                return
            if i == len(order):
                solutions.append(dict(partial))
                return
            ag = order[i]
            for sol in ag.solutions:
                if consistent(partial, sol):
                    bt(i + 1, extend(partial, sol))
                    if solutions and not find_all:
                        return

        bt(0, {})
        return solutions

    def solve(
        self,
        model: DCSPModel,
        *,
        max_delay: int = 0,
        random_seed: int = 0,
        max_events: int = 200_000,
        deterministic_init: bool = True,
        find_all_solutions: bool = False,
        max_solutions: Optional[int] = None,
        max_local_solutions: Optional[int] = None,
        runtime: str = "sim",
        record_protocol: bool = False,
        protocol_path: Optional[str] = None,
        **_: Any,
    ) -> SolveOutcome:
        if "constraint_agents" not in model.capabilities:
            raise ValueError("AAS is implemented for the constraint-agent architecture.")

        # --- phase 0: global domains ---
        # Use the same representation as CompAPO: a plain dict of variable -> domain set.
        global_domains: Dict[str, Set[Any]] = {
            v: set(var.domain) for v, var in model.csp.variables.items()
        }

        # --- phase 1: compute local tuple sets (aggregations) ---
        # In MP mode this enumeration runs inside each agent process (on 'start').
        # In SIM mode it still runs inside the agent object, but without OS-level parallelism.
        agent_objs: Dict[str, _AASAgent] = {}
        for aid, spec in model.agents.items():
            neigh = set(model.neighbors.get(aid, set()))
            shared_vars: Dict[str, Tuple[str, ...]] = {}
            for n in sorted(neigh):
                other = model.agents[n]
                svars = tuple(sorted(set(spec.controlled_vars).intersection(other.controlled_vars)))
                shared_vars[n] = svars

            agent_objs[aid] = _AASAgent(
                aid=aid,
                spec=spec,
                neighbors=neigh,
                shared_vars=shared_vars,
                global_domains=global_domains,
                deterministic_init=deterministic_init,
                max_local_solutions=max_local_solutions,
            )


        # --- phase 2: asynchronous projection propagation ---
        if runtime.lower().strip() == "mp":
            ctx = mp.get_context("fork") if "fork" in mp.get_all_start_methods() else mp.get_context()
            ctrl: mp.Queue = ctx.Queue()
            inboxes: Dict[str, mp.Queue] = {aid: ctx.Queue() for aid in agent_objs.keys()}
            from ..protocol import MonotonicClock

            clock = MonotonicClock()
            net = MPNetwork(inboxes=inboxes, ctrl=ctrl, clock=clock)
            mproxy = MPMetricsProxy(ctrl)

            for aid, ag in agent_objs.items():
                ag.net = net  # type: ignore[assignment]
                ag.metrics = mproxy  # type: ignore[assignment]

            # Kick-off.
            for aid in sorted(agent_objs.keys()):
                net.send(Message(kind="start", sender="__init__", receiver=aid, payload=None, sent_at=0))

            def decide(states: Dict[str, Dict[str, Any]], had_nosol: bool):
                # AAS unsat is signaled via ag.failed or empty solutions. We'll check after join.
                return True, True, "stable", {}

            out = run_event_driven_mp(
                agents=agent_objs,
                inboxes=inboxes,
                ctrl=ctrl,
                metrics=self.metrics,
                protocol_path=(protocol_path if record_protocol else None),
                max_events=max_events,
                decide_outcome=decide,
                quiescence_ms=300,
            )
            self.sim_time = out.sim_time_ms
            self.processed_events = out.processed_events
            self.metrics.finalize_parallelism()
            # Pull final worker snapshots back into the master-side agent objects.
            # Required because workers run in separate processes (spawn), so agent_objs are not shared.
            if getattr(out, 'states', None):
                for _aid, st in out.states.items():
                    if _aid in agent_objs and isinstance(st, dict):
                        if 'solutions' in st:
                            agent_objs[_aid].solutions = list(st.get('solutions') or [])
                        agent_objs[_aid].failed = bool(st.get('failed', False))
                        agent_objs[_aid].terminated = bool(st.get('terminated', False))

        else:
            rng = random.Random(int(random_seed))
            loop = EventLoop(max_delay=max_delay, rng=rng)
            plog = ProtocolLogger(protocol_path if record_protocol else None)
            net = Network(loop, protocol=plog)

            for aid, ag in agent_objs.items():
                ag.net = net
                ag.metrics = self.metrics
                net.register(aid, ag.on_message)

            for aid in sorted(agent_objs.keys()):
                net.send(Message(kind="start", sender="__init__", receiver=aid, payload=None, sent_at=0), delay=0)

            processed = net.run(max_events=max_events)
            self.sim_time = loop.time
            self.processed_events = processed
            self.metrics.finalize_parallelism()
            try:
                plog.close()  # type: ignore[name-defined]
            except Exception:
                pass

        # --- phase 3: assemble global solution(s) in the aggregated space ---
        if any(ag.failed or not ag.solutions for ag in agent_objs.values()):
            self.outcome = SolveOutcome(
                satisfiable=False,
                assignment={},
                terminated=True,
                reason="aggregation_unsat",
                solutions=[],
            )
            return self.outcome

        sols = self._assemble_global_solutions(
            list(agent_objs.values()),
            find_all=find_all_solutions,
            max_solutions=max_solutions,
        )

        if not sols:
            self.outcome = SolveOutcome(
                satisfiable=False,
                assignment={},
                terminated=True,
                reason="join_failed",
                solutions=[],
            )
            return self.outcome

        reason = "done" if not find_all_solutions else ("all_solutions_found" if max_solutions is None else "max_solutions")
        self.outcome = SolveOutcome(
            satisfiable=True,
            assignment=dict(sols[0]),
            terminated=True,
            reason=reason,
            solutions=list(sols) if find_all_solutions else [dict(sols[0])],
        )
        return self.outcome
