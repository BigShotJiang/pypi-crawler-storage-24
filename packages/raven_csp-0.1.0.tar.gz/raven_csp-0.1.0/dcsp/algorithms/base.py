from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from ..metrics import DCSPMetrics


@dataclass
class SolveOutcome:
    satisfiable: bool
    assignment: Dict[str, Any]
    terminated: bool
    reason: str = ""
    # Optional enumeration support. For single-solution runs, this is either [] or [assignment].
    solutions: List[Dict[str, Any]] = field(default_factory=list)


class AlgorithmBase:
    name: str = "base"

    def __init__(self, *, metrics: Optional[DCSPMetrics] = None):
        self.metrics = metrics or DCSPMetrics()
        self.outcome: Optional[SolveOutcome] = None
        self.sim_time: int = 0
        self.processed_events: int = 0

    def is_terminated(self) -> bool:
        return self.outcome is not None and self.outcome.terminated

    def get_outcome(self) -> SolveOutcome:
        assert self.outcome is not None
        return self.outcome
