from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Set, Tuple

from csp.core import CSP
from csp.solvers import solve_mac

from ..architectures.base import AgentSpec, DCSPModel
from ..messages import Message
from ..metrics import DCSPMetrics
from ..network import EventLoop, Network
from ..runtime_mp import MPNetwork, MPMetricsProxy, run_event_driven_mp
import multiprocessing as mp
from ..protocol import ProtocolLogger
from .base import AlgorithmBase, SolveOutcome


def _build_local_csp(spec: AgentSpec, global_domains: Dict[str, Set[Any]]) -> CSP:
    """Create a centralized CSP for one constraint-agent subproblem."""
    c = CSP()
    for v in spec.controlled_vars:
        c.add_variable(v, set(global_domains[v]))
    for cons in spec.constraints:
        # In the constraint-agent architecture, all owned constraints should be in-scope.
        if all(v in c.variables for v in cons.variables):
            c.add_constraint_explicit(cons.name, cons.expression, cons.variables)
    return c


def _complete_and_validate_assignment(
    csp: CSP,
    partial_assignment: Dict[str, Any],
    *,
    deterministic: bool,
) -> Tuple[bool, Dict[str, Any]]:
    """Complete a (possibly partial) assignment and validate it against the full CSP.

    CompAPO can reach quiescence with only a subset of variables assigned. A plain
    constraint check with partial assignments is not sufficient for SAT detection in
    this framework, because many constraints evaluate to True on missing variables.
    """
    assigned = dict(partial_assignment)
    missing = [v for v in csp.variables.keys() if v not in assigned]
    if missing:
        completion = CSP()
        for v, var in csp.variables.items():
            dom = set(var.domain)
            if v in assigned:
                val = assigned[v]
                if val not in dom:
                    return False, {}
                completion.add_variable(v, {val})
            else:
                completion.add_variable(v, dom)
        for cons in csp.constraints.values():
            completion.add_constraint_explicit(cons.name, cons.expression, cons.variables)

        res = solve_mac(completion, find_all=False, heuristics=["mrv"], deterministic=deterministic, propagation="gac")
        sols = res.get("solutions", [])
        if not sols:
            return False, {}
        assigned = dict(sols[0])

    for cons in csp.constraints.values():
        if not cons.evaluate(assigned):
            return False, {}
    return True, assigned


def _priority_key(priority: int, aid: str) -> Tuple[int, str]:
    """Total order used for mediation precedence.

    Higher `priority` wins. Ties are broken deterministically by agent id.
    """
    return (int(priority), str(aid))


def _dominates(p1: Tuple[int, str], p2: Tuple[int, str]) -> bool:
    """Return True if p1 has strictly higher precedence than p2."""
    return p1[0] > p2[0] or (p1[0] == p2[0] and p1[1] < p2[1])


@dataclass
class _CompAPOAgent:
    aid: str
    spec: AgentSpec
    neighbors: Set[str]
    shared_vars: Dict[str, Tuple[str, ...]]
    global_domains: Dict[str, Set[Any]]
    all_specs: Dict[str, AgentSpec]
    deterministic: bool

    net: Network
    metrics: DCSPMetrics

    # --- local state ---
    assignment: Dict[str, Any] = field(default_factory=dict)
    agent_view: Dict[str, Dict[str, Any]] = field(default_factory=dict)  # sender -> assignment (partial)
    neighbor_prec: Dict[str, Tuple[int, str]] = field(default_factory=dict)  # sender -> precedence

    good_list: Set[str] = field(default_factory=set)
    priority: int = 0

    locked_by: Optional[str] = None
    locked_priority: Optional[Tuple[int, str]] = None

    mediating: bool = False
    pending_session: Set[str] = field(default_factory=set)
    lock_ok_from: Set[str] = field(default_factory=set)
    lock_reject_from: Set[str] = field(default_factory=set)
    pending_conflict_with: Optional[str] = None
    no_solution: bool = False

    # ---------------- messaging helpers ----------------

    def _send(self, kind: str, receiver: str, payload: Any) -> None:
        self.metrics.inc_agent(self.aid, "messages_sent")
        msg = Message(kind=kind, sender=self.aid, receiver=receiver, payload=payload, sent_at=self.net.loop.time)
        self.net.send(msg)

    def _broadcast_ok(self) -> None:
        for n in sorted(self.neighbors):
            # Only send the shared part to keep payload small.
            svars = self.shared_vars.get(n, ())
            payload = {v: self.assignment.get(v) for v in svars if v in self.assignment}
            # Include our precedence so receivers can decide mediation deterministically.
            wrapped = (self._my_precedence(), payload)
            self.metrics.inc_agent(self.aid, "messages_ok")
            self._send("ok", n, wrapped)

    # ---------------- initialization / repair ----------------

    def _pick_initial_assignment(self) -> bool:
        local = _build_local_csp(self.spec, self.global_domains)
        from csp.instrument import Counters
        _cnt = Counters()
        res = solve_mac(local, find_all=False, heuristics=["mrv"], deterministic=self.deterministic, propagation="gac", counters=_cnt)
        ce = int(_cnt.get("constraint_evaluations", 0))
        if ce and getattr(self, 'metrics', None) is not None:
            self.metrics.inc_agent(self.aid if hasattr(self,'aid') else 'MASTER', "constraint_checks", ce)
        sols = res.get("solutions", [])
        if not sols:
            return False
        self.assignment = dict(sols[0])
        return True

    def _try_repair(self) -> bool:
        """Try to find a local assignment consistent with known neighbor bindings."""
        local = _build_local_csp(self.spec, self.global_domains)

        # Restrict domains according to all known shared-variable bindings.
        reduced: Dict[str, Set[Any]] = {v: set(self.global_domains[v]) for v in self.spec.controlled_vars}
        my_prec = self._my_precedence()
        for n, view in self.agent_view.items():
            nprec = self.neighbor_prec.get(n)
            if nprec is None:
                continue
            # Only treat *higher-precedence* neighbors as hard commitments.
            if not _dominates(nprec, my_prec):
                continue
            for v, val in view.items():
                if v in reduced:
                    reduced[v] = {val}

        # If any domain becomes empty due to conflicting neighbor info, repair fails.
        if any(len(d) == 0 for d in reduced.values()):
            return False

        from csp.instrument import Counters
        _cnt = Counters()
        res = solve_mac(local, find_all=False, heuristics=["mrv"], reduced_domains=reduced, deterministic=self.deterministic, propagation="gac", counters=_cnt)
        ce = int(_cnt.get("constraint_evaluations", 0))
        if ce and getattr(self, 'metrics', None) is not None:
            self.metrics.inc_agent(self.aid if hasattr(self,'aid') else 'MASTER', "constraint_checks", ce)
        sols = res.get("solutions", [])
        if not sols:
            return False

        new_assign = dict(sols[0])
        if new_assign != self.assignment:
            self.metrics.inc_agent(self.aid, "value_changes")
            self.assignment = new_assign
            return True
        return True

    # ---------------- conflict detection ----------------

    def _conflicts_with(self, other_aid: str, other_payload: Dict[str, Any]) -> bool:
        svars = self.shared_vars.get(other_aid, ())
        for v in svars:
            if v in other_payload and v in self.assignment:
                if other_payload[v] != self.assignment[v]:
                    return True
        return False

    # ---------------- locking ----------------

    def _my_precedence(self) -> Tuple[int, str]:
        return _priority_key(self.priority, self.aid)

    def _can_accept_lock(self, requester: str, requester_prec: Tuple[int, str]) -> bool:
        if self.locked_by is None:
            return True
        if self.locked_by == requester:
            return True
        # Preempt if requester dominates current lock holder.
        if self.locked_priority is None:
            return False
        return _dominates(requester_prec, self.locked_priority)

    def _release_lock(self, mediator: str) -> None:
        if self.locked_by == mediator:
            self.locked_by = None
            self.locked_priority = None

    # ---------------- mediation ----------------

    def _compute_session_closure(self, seed: Set[str]) -> Set[str]:
        """Expand a session with all known boundary agents (those we already have views for).

        This is a pragmatic CompAPO-style closure: if an agent outside the seed is
        already in our view and shares variables with the current session, include it.
        """
        session = set(seed)
        changed = True
        while changed:
            changed = False
            session_vars: Set[str] = set()
            for a in session:
                session_vars.update(self.all_specs[a].controlled_vars)

            for a in list(self.agent_view.keys()):
                if a in session:
                    continue
                # include a if it shares vars with the current session and we know some bindings from it
                other_vars = set(self.all_specs[a].controlled_vars)
                if session_vars.intersection(other_vars):
                    session.add(a)
                    changed = True
        return session

    def _start_mediation(self, conflict_with: str) -> None:
        if self.mediating or self.locked_by is not None or self.no_solution:
            return

        seed = set(self.good_list) | {self.aid, conflict_with}
        session = self._compute_session_closure(seed)

        self.mediating = True
        self.pending_session = set(session)
        self.pending_conflict_with = conflict_with
        self.lock_ok_from = set()
        self.lock_reject_from = set()

        prec = self._my_precedence()
        # Lock all participants except self.
        for a in sorted(session):
            if a == self.aid:
                continue
            self.metrics.inc_agent(self.aid, "messages_sent")
            self._send("lock_req", a, (self.aid, prec, tuple(sorted(session))))

        # If session is only self, solve immediately.
        if session == {self.aid}:
            self._solve_and_distribute(session)

    def _abort_mediation(self) -> None:
        # Release anyone we locked.
        for a in sorted(self.pending_session):
            if a == self.aid:
                continue
            self._send("unlock", a, self.aid)
        self.mediating = False
        self.pending_session.clear()
        self.lock_ok_from.clear()
        self.lock_reject_from.clear()
        self.pending_conflict_with = None

    def _solve_and_distribute(self, session: Set[str]) -> None:
        """Solve the mediated subproblem centrally and distribute a consistent assignment."""
        # Build a sub-CSP on the primal variables.
        sub = CSP()
        union_vars: Set[str] = set()
        for a in session:
            union_vars.update(self.all_specs[a].controlled_vars)

        # Restrict domains using known bindings from outside the session (boundary conditions).
        doms: Dict[str, Set[Any]] = {v: set(self.global_domains[v]) for v in union_vars}
        for outside, view in self.agent_view.items():
            if outside in session:
                continue
            for v, val in view.items():
                if v in doms:
                    doms[v] = {val}

        for v, d in doms.items():
            sub.add_variable(v, set(d))

        # Add owned constraints of session agents.
        for a in sorted(session):
            for cons in self.all_specs[a].constraints:
                # Keep only constraints fully inside the union vars.
                if all(v in union_vars for v in cons.variables):
                    sub.add_constraint_explicit(cons.name, cons.expression, cons.variables)

        from csp.instrument import Counters
        _cnt = Counters()
        res = solve_mac(sub, find_all=False, heuristics=["mrv"], deterministic=self.deterministic, propagation="gac", counters=_cnt)
        ce = int(_cnt.get("constraint_evaluations", 0))
        if ce and getattr(self, 'metrics', None) is not None:
            self.metrics.inc_agent(self.aid if hasattr(self,'aid') else 'MASTER', "constraint_checks", ce)
        sols = res.get("solutions", [])

        if not sols:
            # If we already mediate the full set, declare UNSAT.
            if len(session) == len(self.all_specs):
                self.no_solution = True
                # Broadcast termination.
                for a in sorted(self.all_specs.keys()):
                    if a != self.aid:
                        self._send("terminate", a, "unsat")
            self._abort_mediation()
            return

        sol = dict(sols[0])

        # Update mediator and distribute projected assignments to participants.
        self.assignment.update({v: sol[v] for v in self.spec.controlled_vars if v in sol})

        for a in sorted(session):
            if a == self.aid:
                continue
            scope = self.all_specs[a].controlled_vars
            payload = {v: sol[v] for v in scope if v in sol}
            self._send("accept", a, (self.aid, payload))
            self._send("unlock", a, self.aid)

        # Good-list expansion and priority bump.
        before = set(self.good_list)
        self.good_list.update(session)
        if self.good_list != before:
            self.metrics.inc_agent(self.aid, "priority_changes")
        self.priority = max(self.priority, len(self.good_list))

        # Inform neighbors about new assignment.
        self._broadcast_ok()

        # End mediation.
        self.mediating = False
        self.pending_session.clear()
        self.lock_ok_from.clear()
        self.lock_reject_from.clear()
        self.pending_conflict_with = None

    # ---------------- event handler ----------------

    def on_message(self, msg: Message) -> None:
        self.metrics.record_activity(self.net.loop.time, self.aid)
        if self.no_solution:
            return

        if msg.kind == "start":
            self.good_list = {self.aid}
            self.priority = 1
            ok = self._pick_initial_assignment()
            if not ok:
                self.no_solution = True
                for a in sorted(self.all_specs.keys()):
                    if a != self.aid:
                        self._send("terminate", a, "unsat")
                return
            self._broadcast_ok()
            return

        if msg.kind == "terminate":
            self.no_solution = True
            return

        if msg.kind == "ok":
            sender_prec, other_payload = msg.payload
            sender_prec = (int(sender_prec[0]), str(sender_prec[1]))
            other_payload = dict(other_payload or {})
            self.agent_view[msg.sender] = other_payload
            self.neighbor_prec[msg.sender] = sender_prec

            # If we're locked or mediating, we still record the view, but we don't act immediately.
            if self.locked_by is not None or self.mediating:
                return

            if self._conflicts_with(msg.sender, other_payload):
                my_prec = self._my_precedence()

                # If the sender dominates us, we should try to repair to match it.
                if _dominates(sender_prec, my_prec):
                    repaired = self._try_repair()
                    if repaired:
                        self._broadcast_ok()
                    # If we cannot repair, we wait (sender has precedence and will mediate if needed).
                    return

                # If we dominate the sender, do not chase its assignment; mediate.
                if _dominates(my_prec, sender_prec):
                    self._start_mediation(msg.sender)
            return

        if msg.kind == "lock_req":
            mediator, prec, session = msg.payload
            prec = tuple(prec)
            requester_prec = (int(prec[0]), str(prec[1]))

            if self._can_accept_lock(mediator, requester_prec):
                # Preempt current lock if needed.
                self.locked_by = mediator
                self.locked_priority = requester_prec
                self._send("lock_ok", mediator, self.aid)
            else:
                self._send("lock_reject", mediator, (self.aid, self.locked_by))
            return

        if msg.kind == "unlock":
            mediator = msg.payload
            self._release_lock(mediator)
            return

        if msg.kind == "accept":
            mediator, payload = msg.payload
            # Adopt assignment (only on controlled vars).
            for v in self.spec.controlled_vars:
                if v in payload:
                    self.assignment[v] = payload[v]
            self._release_lock(mediator)
            if not self.mediating and not self.no_solution:
                self._broadcast_ok()
            return

        if msg.kind in ("lock_ok", "lock_reject"):
            # Only relevant if we are the mediator.
            if not self.mediating:
                return
            if msg.kind == "lock_ok":
                self.lock_ok_from.add(msg.payload)
            else:
                self.lock_reject_from.add(msg.payload[0])

            # Decide if session can proceed.
            others = {a for a in self.pending_session if a != self.aid}
            if self.lock_reject_from:
                self._abort_mediation()
                return
            if others.issubset(self.lock_ok_from):
                # Lock ourselves logically.
                self._solve_and_distribute(set(self.pending_session))
            return


class CompleteAsynchronousPartialOverlay(AlgorithmBase):
    """CompAPO (Complete Asynchronous Partial Overlay) adapted to constraint agents.

    This is a pragmatic implementation for the *constraint-agent architecture* used in this
    framework:

    - Each constraint agent owns a set of constraints (unique ownership).
    - Agents hold a local assignment over their scope variables.
    - Conflicts are disagreements on shared variables.
    - A mediator temporarily centralizes a subproblem (agents in its good_list + conflict closure),
      solves it centrally via MAC(GAC), and distributes a consistent assignment.

    Notes
    -----
    - This implementation targets correctness and practical usability in the framework.
      It is "CompAPO-style" mediation with locking and good-list growth, but keeps the
      message protocol intentionally compact.
    - Solution enumeration (find_all_solutions=True) is handled by falling back to a
      centralized enumeration (the distributed mediator loop remains single-solution).
    """

    name = "compapo"

    def __init__(self, *, metrics: Optional[DCSPMetrics] = None):
        super().__init__(metrics=metrics)

    def solve(
        self,
        model: DCSPModel,
        *,
        max_delay: int = 0,
        random_seed: int = 0,
        max_events: int = 300_000,
        deterministic_init: bool = True,
        runtime: str = "sim",
        record_protocol: bool = False,
        protocol_path: Optional[str] = None,
        find_all_solutions: bool = False,
        max_solutions: Optional[int] = None,
        **_: Any,
    ) -> SolveOutcome:
        if "constraint_agents" not in model.capabilities:
            raise ValueError("CompAPO is implemented for the constraint-agent architecture.")

        # Enumeration is non-trivial for distributed mediation; use a centralized fallback.
        if find_all_solutions:
            from csp.instrument import Counters
            _cnt = Counters()
            res = solve_mac(model.csp, find_all=True, heuristics=["mrv"], deterministic=deterministic_init, propagation="gac", counters=_cnt)
            ce = int(_cnt.get("constraint_evaluations", 0))
            if ce and getattr(self, 'metrics', None) is not None:
                self.metrics.inc_agent(self.aid if hasattr(self,'aid') else 'MASTER', "constraint_checks", ce)
            sols = list(res.get("solutions", []))
            if max_solutions is not None:
                sols = sols[: int(max_solutions)]
            if not sols:
                self.outcome = SolveOutcome(False, {}, True, reason="unsat", solutions=[])
                return self.outcome
            self.outcome = SolveOutcome(True, dict(sols[0]), True, reason="central_fallback", solutions=sols)
            return self.outcome

        # --- phase 0: global domains ---
        global_domains: Dict[str, Set[Any]] = {v: set(var.domain) for v, var in model.csp.variables.items()}

        if runtime.lower().strip() == "mp":
            ctx = mp.get_context("fork") if "fork" in mp.get_all_start_methods() else mp.get_context()
            ctrl: mp.Queue = ctx.Queue()
            inboxes: Dict[str, mp.Queue] = {aid: ctx.Queue() for aid in model.agents.keys()}
            from ..protocol import MonotonicClock

            clock = MonotonicClock()
            net = MPNetwork(inboxes=inboxes, ctrl=ctrl, clock=clock)
            mproxy = MPMetricsProxy(ctrl)
        else:
            rng = random.Random(int(random_seed))
            loop = EventLoop(max_delay=max_delay, rng=rng)
            plog = ProtocolLogger(protocol_path if record_protocol else None)
            net = Network(loop, protocol=plog)

        agents: Dict[str, _CompAPOAgent] = {}
        for aid, spec in model.agents.items():
            neigh = set(model.neighbors.get(aid, set()))
            shared: Dict[str, Tuple[str, ...]] = {}
            my_scope = set(spec.controlled_vars)
            for n in neigh:
                other_scope = set(model.agents[n].controlled_vars)
                shared[n] = tuple(sorted(my_scope.intersection(other_scope)))

            ag = _CompAPOAgent(
                aid=aid,
                spec=spec,
                neighbors=neigh,
                shared_vars=shared,
                global_domains=global_domains,
                all_specs=model.agents,
                deterministic=deterministic_init,
                net=net,  # type: ignore[arg-type]
                metrics=(mproxy if runtime.lower().strip() == "mp" else self.metrics),  # type: ignore[arg-type]
            )
            agents[aid] = ag
            if runtime.lower().strip() != "mp":
                net.register(aid, ag.on_message)

        # Start all agents.
        for aid in sorted(agents.keys()):
            if runtime.lower().strip() == "mp":
                net.send(Message(kind="start", sender="__init__", receiver=aid, payload=None, sent_at=0))
            else:
                net.send(Message(kind="start", sender="__init__", receiver=aid, payload=None, sent_at=0), delay=0)

        if runtime.lower().strip() == "mp":
            def report(_ignored: str, a: _CompAPOAgent) -> Dict[str, Any]:
                return {
                    "assignment": dict(a.assignment),
                    "no_solution": bool(a.no_solution),
                }

            def decide(states: Dict[str, Dict[str, Any]], had_nosol: bool):
                if had_nosol or any(st.get("no_solution") for st in states.values()):
                    return False, True, "unsat", {}

                global_assign: Dict[str, Any] = {}
                for v in model.csp.variables.keys():
                    vals: Set[Any] = set()
                    for st in states.values():
                        ass = st.get("assignment", {}) or {}
                        if v in ass:
                            vals.add(ass[v])
                    if not vals:
                        continue
                    if len(vals) > 1:
                        return False, True, "conflict_after_quiescence", {}
                    global_assign[v] = next(iter(vals))

                ok, completed = _complete_and_validate_assignment(
                    model.csp,
                    global_assign,
                    deterministic=deterministic_init,
                )
                if not ok:
                    return False, True, "invalid_assignment", {}
                return True, True, "done", dict(completed)

            out = run_event_driven_mp(
                agents=agents,
                inboxes=inboxes,
                ctrl=ctrl,
                metrics=self.metrics,
                protocol_path=(protocol_path if record_protocol else None),
                max_events=max_events,
                request_report=report,
                decide_outcome=decide,
                quiescence_ms=400,
            )
            self.sim_time = out.sim_time_ms
            self.processed_events = out.processed_events
            self.metrics.finalize_parallelism()

            self.outcome = SolveOutcome(
                satisfiable=out.satisfiable,
                assignment=dict(out.assignment),
                terminated=out.terminated,
                reason=out.reason,
                solutions=[dict(out.assignment)] if out.satisfiable else [],
            )
            return self.outcome
        else:
            processed = net.run(max_events=max_events)
            self.sim_time = loop.time
            self.processed_events = processed
            self.metrics.finalize_parallelism()
            try:
                plog.close()  # type: ignore[name-defined]
            except Exception:
                pass

        # If any agent declared UNSAT, finish.
        if runtime.lower().strip() != "mp":
            if any(a.no_solution for a in agents.values()):
                self.outcome = SolveOutcome(False, {}, True, reason="unsat", solutions=[])
                return self.outcome

        # Assemble a global assignment from per-agent assignments.
        global_assign: Dict[str, Any] = {}
        for v in model.csp.variables.keys():
            vals: Set[Any] = set()
            for ag in agents.values():
                if v in ag.assignment:
                    vals.add(ag.assignment[v])
            if not vals:
                continue
            if len(vals) > 1:
                self.outcome = SolveOutcome(False, {}, True, reason="conflict_after_quiescence", solutions=[])
                return self.outcome
            global_assign[v] = next(iter(vals))

        # Complete partial assignment if needed, then validate against full CSP.
        ok, completed = _complete_and_validate_assignment(
            model.csp,
            global_assign,
            deterministic=deterministic_init,
        )

        if not ok:
            self.outcome = SolveOutcome(False, {}, True, reason="invalid_assignment", solutions=[])
            return self.outcome

        self.outcome = SolveOutcome(True, dict(completed), True, reason="done", solutions=[dict(completed)])
        return self.outcome
