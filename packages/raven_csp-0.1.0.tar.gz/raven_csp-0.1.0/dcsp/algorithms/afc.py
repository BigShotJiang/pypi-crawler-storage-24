from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Sequence, Set, Tuple

from csp.core import Constraint

from ..architectures.base import DCSPModel
from ..messages import Message
from ..metrics import DCSPMetrics
from ..network import EventLoop, Network
from ..protocol import ProtocolLogger
from .base import AlgorithmBase, SolveOutcome


@dataclass
class _AFCSpec:
    aid: str
    var: str
    domain: List[Any]
    constraints: List[Constraint]


class AsynchronousForwardChecking(AlgorithmBase):
    """Asynchronous Forward Checking (AFC).

    Practical implementation for the common DCSP baseline "one variable per agent"
    with a fixed total order of agents.

    Notes on this implementation:
    - AFC is typically described for binary constraints. Here we enforce that the
      *model CSP* has only binary constraints. For n-ary constraints, use one of the
      provided encodings (HVE/DE/Double) via `csp.binarize_csp(...)`.
    - Enumeration (`find_all_solutions=True`) is performed within one run by continuing
      the backtracking search after each solution.
    """

    name = "afc"

    def __init__(self, *, metrics: Optional[DCSPMetrics] = None):
        super().__init__(metrics=metrics)
        self._rng: Optional[random.Random] = None
        self._loop: Optional[EventLoop] = None
        self._net: Optional[Network] = None

        # forward-check request state
        self._req_id: int = 0
        self._pending: Set[str] = set()
        self._failed: bool = False
        self._current_req: int = -1

    # ---------------------- helpers ----------------------

    @staticmethod
    def _assert_binary_only(model: DCSPModel) -> None:
        for c in model.csp.constraints.values():
            if len(c.variables) > 2:
                raise ValueError(
                    "AFC requires binary constraints. Convert the CSP first, e.g. via `binarize_csp(csp, encoding='double')`."  # noqa: E501
                )

    def _consistent_local(self, agent: _AFCSpec, val: Any, partial: Dict[str, Any]) -> bool:
        test = dict(partial)
        test[agent.var] = val
        for c in agent.constraints:
            if all(v in test for v in c.variables):
                self.metrics.inc_agent(agent.aid, "constraint_checks")
                if not c.evaluate(test):
                    return False
        return True

    def _fc_support_exists(self, agent: _AFCSpec, partial: Dict[str, Any]) -> bool:
        # Does there exist a value in agent.domain consistent with the already assigned vars in partial?
        for val in agent.domain:
            test = dict(partial)
            test[agent.var] = val
            ok = True
            for c in agent.constraints:
                if all(v in test for v in c.variables):
                    self.metrics.inc_agent(agent.aid, "constraint_checks")
                    if not c.evaluate(test):
                        ok = False
                        break
            if ok:
                return True
        return False

    # ---------------------- message handlers ----------------------

    def _make_fc_checker(self, spec: _AFCSpec) -> Any:
        def on_message(msg: Message) -> None:
            # Parallelism: mark this agent active for the current simulation tick.
            if self._loop is not None:
                self.metrics.record_activity(self._loop.time, spec.aid)
            else:
                self.metrics.record_activity(0, spec.aid)

            if msg.kind != "fc_check":
                return
            req_id, partial = msg.payload
            # FC check: verify non-empty domain wrt partial.
            ok = self._fc_support_exists(spec, partial)
            # Reply.
            self.metrics.inc_agent(spec.aid, "messages_sent")
            self.metrics.inc_agent(spec.aid, "messages_fc_reply")
            kind = "fc_ok" if ok else "fc_nogood"
            if not ok:
                self.metrics.inc_agent(spec.aid, "nogoods_generated")
            self._net.send(Message(kind=kind, sender=spec.aid, receiver=msg.sender, payload=(req_id, ok)))  # type: ignore
        return on_message

    def _make_fc_collector(self, spec: _AFCSpec) -> Any:
        def on_message(msg: Message) -> None:
            # Parallelism: mark this agent active for the current simulation tick.
            if self._loop is not None:
                self.metrics.record_activity(self._loop.time, spec.aid)
            else:
                self.metrics.record_activity(0, spec.aid)

            if msg.kind not in ("fc_ok", "fc_nogood"):
                return
            req_id, ok = msg.payload
            if req_id != self._current_req:
                return
            if msg.sender in self._pending:
                self._pending.remove(msg.sender)
            if not ok:
                self._failed = True
        return on_message

    def _run_until_fc_done(self, *, max_events: int) -> Tuple[bool, bool]:
        """Run the network until the current FC batch is done.

        Returns (done, timeout)
        """
        assert self._loop is not None and self._net is not None
        while self._pending:
            if self.processed_events >= max_events:
                return False, True
            m = self._loop.step()
            if m is None:
                break
            h = self._net.handlers.get(m.receiver)
            if h is not None:
                h(m)
            self.processed_events += 1
        return (not self._pending), False

    def _forward_check_batch(
        self,
        sender: _AFCSpec,
        future: Sequence[_AFCSpec],
        partial: Dict[str, Any],
        *,
        max_events: int,
    ) -> Tuple[bool, bool]:
        """Send FC checks to all future agents and collect replies.

        Returns (ok, timeout).
        """
        assert self._net is not None

        self._req_id += 1
        self._current_req = self._req_id
        self._pending = {a.aid for a in future}
        self._failed = False

        for a in future:
            self.metrics.inc_agent(sender.aid, "messages_sent")
            self.metrics.inc_agent(sender.aid, "messages_fc_check")
            self._net.send(Message(kind="fc_check", sender=sender.aid, receiver=a.aid, payload=(self._req_id, partial)))

        done, timeout = self._run_until_fc_done(max_events=max_events)
        if timeout:
            return False, True
        # done but maybe queue drained unexpectedly; treat as failed if pending not empty.
        if not done:
            return False, True
        return (not self._failed), False

    # ---------------------- solve ----------------------

    def solve(
        self,
        model: DCSPModel,
        *,
        max_delay: int = 0,
        random_seed: int = 0,
        max_events: int = 1_000_000,
        order: Optional[List[str]] = None,
        deterministic_init: bool = True,
        record_protocol: bool = False,
        protocol_path: Optional[str] = None,
        find_all_solutions: bool = False,
        max_solutions: Optional[int] = None,
        **_: Any,
    ) -> SolveOutcome:
        if "single_variable_agents" not in model.capabilities:
            raise ValueError("AFC requires an architecture with exactly one variable per agent")
        self._assert_binary_only(model)

        self._rng = random.Random(random_seed)
        self._loop = EventLoop(max_delay=max_delay, rng=self._rng)
        plog = ProtocolLogger(protocol_path if record_protocol else None)
        self._net = Network(self._loop, protocol=plog)

        # Fixed, deterministic order unless provided.
        order = list(order) if order is not None else sorted(model.agents.keys())
        agents: List[_AFCSpec] = [
            _AFCSpec(
                aid=aid,
                var=model.agents[aid].var,
                domain=list(model.agents[aid].domain()),
                constraints=list(model.agents[aid].constraints),
            )
            for aid in order
        ]

        # Register FC check handlers for all agents.
        for spec in agents:
            self._net.register(spec.aid, self._make_fc_checker(spec))

        # Additionally, for each agent we register a collector for FC replies *when it is the sender*.
        # We do this by wrapping: during FC batches we temporarily overwrite sender's handler.
        # (Future agents only need fc_check; the sender needs fc_ok/fc_nogood collection.)
        base_handlers = dict(self._net.handlers)

        tried_stack: List[Dict[str, bool]] = [dict() for _ in agents]
        assignment: Dict[str, Any] = {}
        solutions: List[Dict[str, Any]] = []
        i = 0

        def verify_global(a: Dict[str, Any]) -> bool:
            for cons in model.csp.constraints.values():
                # Constraints are binary; full assignment should satisfy all.
                if not cons.evaluate(a):
                    return False
            return True

        while 0 <= i < len(agents):
            sender = agents[i]

            # Simulate CPA reception as a message at the current agent.
            self.metrics.inc_agent(sender.aid, "messages_sent")
            self.metrics.inc_agent(sender.aid, "messages_cpa")

            chosen = None
            for v in sender.domain:
                key = f"{v}"
                if tried_stack[i].get(key, False):
                    continue
                tried_stack[i][key] = True

                if not self._consistent_local(sender, v, assignment):
                    continue

                partial = dict(assignment)
                partial[sender.var] = v

                # FC to all future agents (i+1..end).
                future = agents[i + 1 :]
                if future:
                    # Install collector handler on sender.
                    self._net.handlers[sender.aid] = self._make_fc_collector(sender)
                    ok, timeout = self._forward_check_batch(sender, future, partial, max_events=max_events)
                    # Restore sender handler.
                    self._net.handlers[sender.aid] = base_handlers[sender.aid]
                    # Note: base handler is fc_checker; sender doesn't need it unless it is checked by earlier vars.
                    if timeout:
                        self.sim_time = self._loop.time
                        self.outcome = SolveOutcome(
                            satisfiable=bool(solutions),
                            assignment=dict(solutions[0]) if solutions else dict(assignment),
                            terminated=False,
                            reason="timeout",
                            solutions=solutions,
                        )
                        try:
                            plog.close()  # type: ignore[name-defined]
                        except Exception:
                            pass
                        return self.outcome
                    if not ok:
                        continue

                chosen = v
                break

            if chosen is None:
                # Backtrack.
                self.metrics.inc_agent(sender.aid, "backtracks")
                tried_stack[i] = {}
                assignment.pop(sender.var, None)
                i -= 1
                if i >= 0:
                    prev = agents[i]
                    self.metrics.inc_agent(prev.aid, "messages_sent")
                    self.metrics.inc_agent(prev.aid, "messages_backtrack")
                continue

            assignment[sender.var] = chosen
            self.metrics.inc_agent(sender.aid, "value_changes")
            i += 1

            if i == len(agents):
                if verify_global(assignment):
                    solutions.append(dict(assignment))
                if not find_all_solutions:
                    break
                if max_solutions is not None and len(solutions) >= max_solutions:
                    break
                # Force backtrack to find next solution.
                last = agents[-1]
                self.metrics.inc_agent(last.aid, "backtracks")
                assignment.pop(last.var, None)
                i = len(agents) - 1

        self.sim_time = self._loop.time if self._loop is not None else 0

        if not solutions:
            # Distinguish "proved no solution" from timeouts etc. In this sequential AFC,
            # empty solution set after full exploration means UNSAT.
            self.outcome = SolveOutcome(
                satisfiable=False,
                assignment={},
                terminated=True,
                reason="no_solution",
                solutions=[],
            )
            try:
                plog.close()  # type: ignore[name-defined]
            except Exception:
                pass
            return self.outcome

        reason = "done"
        if find_all_solutions:
            if max_solutions is not None and len(solutions) >= max_solutions:
                reason = "max_solutions"
            else:
                reason = "all_solutions_found"

        self.outcome = SolveOutcome(
            satisfiable=True,
            assignment=dict(solutions[0]),
            terminated=True,
            reason=reason,
            solutions=solutions,
        )
        try:
            plog.close()  # type: ignore[name-defined]
        except Exception:
            pass
        return self.outcome