from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set, Tuple, FrozenSet

from csp.core import Constraint

from ..architectures.base import DCSPModel
from ..messages import Message
from ..metrics import DCSPMetrics
from ..network import EventLoop, Network
from ..runtime_mp import MPNetwork, MPMetricsProxy, run_event_driven_mp
import multiprocessing as mp
from ..protocol import ProtocolLogger
from .base import AlgorithmBase, SolveOutcome


Nogood = FrozenSet[Tuple[str, Any]]


def _prio_key(var: str, prio: int) -> Tuple[int, str]:
    """Smaller key => higher priority (larger prio wins; tie by name)."""
    return (-prio, var)


@dataclass
class _AWCSAgent:
    aid: str
    var: str
    domain: List[Any]
    constraints: List[Constraint]
    neighbors: Set[str]
    net: Network
    metrics: DCSPMetrics
    var_to_agent: Dict[str, str]

    current_value: Optional[Any] = None
    priority: int = 0

    # agent_view: var -> (value, priority)
    agent_view: Dict[str, Tuple[Any, int]] = field(default_factory=dict)

    # Nogoods are constraints over variable *values* (priority values are treated as context only).
    nogood_list: List[Nogood] = field(default_factory=list)
    nogood_sent: Set[Nogood] = field(default_factory=set)

    terminated: bool = False
    no_solution: bool = False

    # If True, the agent may declare UNSAT when it gets stuck (incomplete, use only for quick experiments).
    incomplete_termination: bool = False

    # If False, getting stuck is treated as an abort (inconclusive), not UNSAT.
    aborted: bool = False

    # ---------------------- helpers ----------------------

    def _send_ok(self, receiver: str) -> None:
        self.metrics.inc_agent(self.aid, "messages_sent")
        self.metrics.inc_agent(self.aid, "messages_ok")
        payload = (self.var, self.current_value, self.priority)
        self.net.send(Message(kind="ok", sender=self.aid, receiver=receiver, payload=payload))

    def _broadcast_ok(self) -> None:
        for r in sorted(self.neighbors):
            self._send_ok(r)

    def _send_nogood(self, receiver: str, nogood: Nogood) -> None:
        self.metrics.inc_agent(self.aid, "messages_sent")
        self.metrics.inc_agent(self.aid, "messages_nogood")
        self.net.send(Message(kind="nogood", sender=self.aid, receiver=receiver, payload=nogood))

    def _send_link_request(self, receiver: str) -> None:
        self.metrics.inc_agent(self.aid, "messages_sent")
        self.metrics.inc_agent(self.aid, "messages_link_request")
        self.net.send(Message(kind="link_request", sender=self.aid, receiver=receiver, payload=self.aid))

    def _self_key(self) -> Tuple[int, str]:
        return _prio_key(self.var, self.priority)

    def _is_higher_than_self(self, other_var: str, other_prio: int) -> bool:
        return _prio_key(other_var, other_prio) < self._self_key()

    def _is_lower_than_self(self, other_var: str, other_prio: int) -> bool:
        return _prio_key(other_var, other_prio) > self._self_key()

    # ---------------------- consistency logic ----------------------

    def _assignment_full(self, value: Any) -> Dict[str, Any]:
        a = {v: val for v, (val, _) in self.agent_view.items()}
        a[self.var] = value
        return a

    def _assignment_higher_only(self, value: Any) -> Dict[str, Any]:
        a: Dict[str, Any] = {self.var: value}
        for v, (val, pr) in self.agent_view.items():
            if self._is_higher_than_self(v, pr):
                a[v] = val
        return a

    def _violates_any_nogood(self, value: Any) -> bool:
        tmp = {v: val for v, (val, _) in self.agent_view.items()}
        tmp[self.var] = value
        for ng in self.nogood_list:
            ok = True
            for v, val in ng:
                if tmp.get(v, None) != val:
                    ok = False
                    break
            if ok:
                return True
        return False

    def _consistent_with_higher(self, value: Any) -> bool:
        assign = self._assignment_higher_only(value)

        for c in self.constraints:
            # Only evaluate constraints that are fully assigned with (self + higher vars).
            if all(v in assign for v in c.variables):
                self.metrics.inc_agent(self.aid, "constraint_checks")
                if not c.evaluate(assign):
                    return False

        if self._violates_any_nogood(value):
            return False
        return True

    def _violation_count_with_lower(self, value: Any) -> int:
        assign = self._assignment_full(value)
        cnt = 0
        for c in self.constraints:
            if all(v in assign for v in c.variables):
                has_lower = False
                for v in c.variables:
                    if v == self.var:
                        continue
                    val_pr = self.agent_view.get(v)
                    if val_pr is None:
                        continue
                    _, pr = val_pr
                    if self._is_lower_than_self(v, pr):
                        has_lower = True
                        break
                if not has_lower:
                    continue
                self.metrics.inc_agent(self.aid, "constraint_checks")
                if not c.evaluate(assign):
                    cnt += 1
        return cnt

    def _choose_value(self) -> Optional[Any]:
        candidates = [v for v in self.domain if self._consistent_with_higher(v)]
        if not candidates:
            return None
        return min(candidates, key=lambda v: (self._violation_count_with_lower(v), v))

    def check_agent_view(self) -> None:
        if self.terminated:
            return
        if self.current_value is not None and self._consistent_with_higher(self.current_value):
            return

        newv = self._choose_value()
        if newv is not None:
            if self.current_value != newv:
                self.metrics.inc_agent(self.aid, "value_changes")
            self.current_value = newv
            self._broadcast_ok()
            return

        self.backtrack()

    def backtrack(self) -> None:
        self.metrics.inc_agent(self.aid, "backtracks")

        if not self.agent_view:
            # In the complete AWCS algorithm, this can indicate UNSAT. In this simplified
            # experimental implementation, declaring UNSAT here may be a false negative
            # (depending on nogood quality/context handling).
            if self.incomplete_termination:
                self.no_solution = True
            else:
                self.aborted = True
            self.terminated = True
            return

        # Use whole agent_view as a nogood (values only).
        nogood: Nogood = frozenset((v, val) for v, (val, _) in self.agent_view.items())
        self.metrics.inc_agent(self.aid, "nogoods_generated")

        if nogood in self.nogood_sent:
            # Wait for next message.
            return

        self.nogood_sent.add(nogood)
        for v, _ in nogood:
            receiver = self.var_to_agent.get(v, v)
            self._send_nogood(receiver, nogood)

        # Increase priority to become highest among related agents.
        pmax = max((pr for _, (_, pr) in self.agent_view.items()), default=0)
        new_prio = pmax + 1
        if new_prio != self.priority:
            self.metrics.inc_agent(self.aid, "priority_changes")
        self.priority = new_prio

        newv = self._choose_value()
        if newv is None:
            # No value even as the (new) top-priority agent. For clean benchmarking we
            # treat this as *inconclusive* by default, because simplified nogoods and
            # context handling can yield false UNSAT.
            if self.incomplete_termination:
                self.no_solution = True
            else:
                self.aborted = True
            self.terminated = True
            return

        if self.current_value != newv:
            self.metrics.inc_agent(self.aid, "value_changes")
        self.current_value = newv
        self._broadcast_ok()

    # ---------------------- message handlers ----------------------

    def on_message(self, msg: Message) -> None:
        # Parallelism: mark this agent active for the current simulation tick.
        self.metrics.record_activity(self.net.loop.time, self.aid)
        if self.terminated:
            return

        if msg.kind == "ok":
            var, val, pr = msg.payload
            if var == self.var:
                return
            self.agent_view[var] = (val, pr)
            self.check_agent_view()
            return

        if msg.kind == "link_request":
            requester = msg.payload
            if requester not in self.neighbors:
                self.neighbors.add(requester)
                self.metrics.inc_agent(self.aid, "links_added")
            if self.current_value is not None:
                self._send_ok(requester)
            return

        if msg.kind == "nogood":
            nogood: Nogood = msg.payload
            self.nogood_list.append(nogood)

            for v, _ in nogood:
                if v == self.var:
                    continue
                owner = self.var_to_agent.get(v, v)
                if owner not in self.neighbors:
                    self.neighbors.add(owner)
                    self._send_link_request(owner)

            old = self.current_value
            self.check_agent_view()
            if old == self.current_value and self.current_value is not None:
                self._send_ok(msg.sender)
            return

        if msg.kind == "terminate":
            self.terminated = True
            return


class AsynchronousWeakCommitmentSearch(AlgorithmBase):
    name = "awcs"

    def __init__(self, *, metrics: Optional[DCSPMetrics] = None):
        super().__init__(metrics=metrics)

    
    def solve(
        self,
        model: DCSPModel,
        *,
        max_delay: int = 5,
        random_seed: int = 0,
        max_events: int = 2_000_000,
        deterministic_init: bool = False,
        incomplete_termination: bool = False,
        find_all_solutions: bool = False,
        max_solutions: Optional[int] = None,
        rebuild_model=None,
        **kwargs: Any,
    ) -> SolveOutcome:
        """Solve the DCSP. Optionally enumerate multiple solutions.

        Enumeration uses restart + solution-forbidding nogoods (constraints) on a working
        CSP copy. This avoids relying on a specific agent having a complete view, which
        is not guaranteed in AWCS under sparse neighbor graphs.
        """
        if not find_all_solutions:
            return self._solve_once(
                model,
                max_delay=max_delay,
                random_seed=random_seed,
                max_events=max_events,
                deterministic_init=deterministic_init,
                incomplete_termination=incomplete_termination,
                **kwargs,
            )

        if rebuild_model is None:
            raise ValueError("find_all_solutions=True requires a rebuild_model callable (CSP -> DCSPModel).")

        from ..utils import add_solution_nogood, clone_csp

        csp_work = clone_csp(model.csp)
        solutions: List[Dict[str, Any]] = []

        total_sim_time = 0
        total_events = 0
        offset = 0

        k = 0
        while True:
            if max_solutions is not None and len(solutions) >= max_solutions:
                reason = "max_solutions"
                terminated = True
                break

            model_k = rebuild_model(csp_work)
            self.metrics.set_time_offset(offset)
            out = self._solve_once(
                model_k,
                max_delay=max_delay,
                random_seed=random_seed + k,
                max_events=max_events,
                deterministic_init=deterministic_init,
                incomplete_termination=incomplete_termination,
                **kwargs,
            )
            total_sim_time += getattr(self, "sim_time", 0)
            total_events += getattr(self, "processed_events", 0)
            offset += int(getattr(self, "sim_time", 0)) + 1

            if out.satisfiable and out.terminated:
                sol = dict(out.assignment)
                solutions.append(sol)
                add_solution_nogood(csp_work, sol, name=f"__nogood_sol_{k:04d}")
                k += 1
                continue

            if out.terminated and out.reason == "no_solution":
                reason = "all_solutions_found" if solutions else "no_solution"
                terminated = True
            else:
                reason = out.reason or "inconclusive"
                terminated = False
            break

        self.metrics.set_time_offset(0)
        self.sim_time = total_sim_time
        self.processed_events = total_events

        self.outcome = SolveOutcome(
            satisfiable=bool(solutions),
            assignment=dict(solutions[0]) if solutions else {},
            terminated=terminated,
            reason=reason,
            solutions=solutions,
        )
        return self.outcome

    def _solve_once(
        self,
        model: DCSPModel,
        *,
        max_delay: int = 5,
        random_seed: int = 0,
        max_events: int = 2_000_000,
        deterministic_init: bool = False,
        incomplete_termination: bool = False,
        runtime: str = "sim",
        record_protocol: bool = False,
        protocol_path: Optional[str] = None,
        **_: Any,
    ) -> SolveOutcome:
        if "single_variable_agents" not in model.capabilities:
            raise ValueError("AWCS requires an architecture with exactly one variable per agent")

        if runtime.lower().strip() == "mp":
            return self._solve_once_mp(
                model,
                random_seed=random_seed,
                max_events=max_events,
                deterministic_init=deterministic_init,
                record_protocol=record_protocol,
                protocol_path=protocol_path,
            )

        rng = random.Random(random_seed)
        loop = EventLoop(max_delay=max_delay, rng=rng)
        plog = ProtocolLogger(protocol_path if record_protocol else None)
        net = Network(loop, protocol=plog)

        agents: Dict[str, _AWCSAgent] = {}
        for aid, spec in model.agents.items():
            a = _AWCSAgent(
                aid=aid,
                var=spec.var,
                domain=list(spec.domain()),
                constraints=list(spec.constraints),
                neighbors=set(model.neighbors.get(aid, set())),
                net=net,
                metrics=self.metrics,
                var_to_agent=dict(model.var_to_agent),
                incomplete_termination=incomplete_termination,
            )
            agents[aid] = a

        for aid, a in agents.items():
            net.register(aid, a.on_message)

        for aid, a in agents.items():
            if not a.domain:
                a.no_solution = True
                a.terminated = True
                continue
            a.priority = 0
            a.current_value = a.domain[0] if deterministic_init else rng.choice(a.domain)
            a.metrics.inc_agent(aid, "value_changes")
            self.metrics.record_activity(0, aid)

        for a in agents.values():
            if not a.terminated:
                a._broadcast_ok()

        events = 0
        timed_out = False
        while events < max_events:
            if any((a.no_solution or a.aborted) for a in agents.values()):
                for receiver in agents:
                    net.send(Message(kind="terminate", sender="__sys__", receiver=receiver, payload=None))
                net.run(max_events=10_000)
                break

            if loop.empty():
                break

            m = loop.step()
            if m is None:
                break
            handler = net.handlers.get(m.receiver)
            if handler:
                handler(m)
            events += 1

        if events >= max_events and not loop.empty() and not any((a.no_solution or a.aborted) for a in agents.values()):
            timed_out = True

        self.sim_time = loop.time
        self.processed_events = events

        if timed_out:
            assignment = {aid: a.current_value for aid, a in agents.items() if a.current_value is not None}
            self.outcome = SolveOutcome(satisfiable=False, assignment=assignment, terminated=False, reason="timeout")
            try:
                plog.close()  # type: ignore[name-defined]
            except Exception:
                pass
            return self.outcome

        # If this implementation reaches here without an explicit return, still close the protocol log.
        try:
            plog.close()  # type: ignore[name-defined]
        except Exception:
            pass

    def _solve_once_mp(
        self,
        model: DCSPModel,
        *,
        random_seed: int,
        max_events: int,
        deterministic_init: bool,
        record_protocol: bool,
        protocol_path: Optional[str],
    ) -> SolveOutcome:
        if "single_variable_agents" not in model.capabilities:
            raise ValueError("AWCS requires an architecture with exactly one variable per agent")

        rng = random.Random(random_seed)
        ctx = mp.get_context("fork") if "fork" in mp.get_all_start_methods() else mp.get_context()
        ctrl: mp.Queue = ctx.Queue()
        inboxes: Dict[str, mp.Queue] = {aid: ctx.Queue() for aid in model.agents.keys()}
        from ..protocol import MonotonicClock

        clock = MonotonicClock()
        net = MPNetwork(inboxes=inboxes, ctrl=ctrl, clock=clock)
        mproxy = MPMetricsProxy(ctrl)

        order = sorted(model.agents.keys())
        ranks = {v: i for i, v in enumerate(order)}

        agents: Dict[str, _AWCSAgent] = {}
        for aid, spec in model.agents.items():
            a = _AWCSAgent(
                aid=aid,
                var=spec.var,
                domain=list(spec.domain()),
                constraints=list(spec.constraints),
                rank=ranks[aid],
                ranks=ranks,
                var_to_agent=dict(model.var_to_agent),
                neighbors_undirected=set(model.neighbors.get(aid, set())),
                net=net,  # type: ignore[arg-type]
                metrics=mproxy,  # type: ignore[arg-type]
                rng=rng,
            )
            agents[aid] = a

        # init
        for aid, a in agents.items():
            a.init_links()
            if not a.domain:
                a.no_solution = True
                a.terminated = True
                continue
            a.current_value = a.domain[0] if deterministic_init else rng.choice(a.domain)
            mproxy.inc_agent(aid, "value_changes")
            mproxy.record_activity(0, aid)

        for a in agents.values():
            if not a.terminated and a.current_value is not None:
                a._broadcast_ok()

        def decide(states: Dict[str, Dict[str, Any]], had_nosol: bool):
            if had_nosol:
                return False, True, "no_solution", {}
            assignment = {aid: st.get("current_value") for aid, st in states.items() if st.get("current_value") is not None}
            sat = True
            for cons in model.csp.constraints.values():
                if not cons.evaluate(assignment):
                    sat = False
                    break
            if sat:
                return True, True, "stable", assignment
            return False, False, "inconclusive", assignment

        out = run_event_driven_mp(
            agents=agents,
            inboxes=inboxes,
            ctrl=ctrl,
            metrics=self.metrics,
            protocol_path=(protocol_path if record_protocol else None),
            max_events=max_events,
            decide_outcome=decide,
        )

        self.sim_time = out.sim_time_ms
        self.processed_events = out.processed_events
        self.outcome = SolveOutcome(
            satisfiable=out.satisfiable,
            assignment=out.assignment,
            terminated=out.terminated,
            reason=out.reason,
            solutions=[dict(out.assignment)] if out.satisfiable else [],
        )
        return self.outcome
