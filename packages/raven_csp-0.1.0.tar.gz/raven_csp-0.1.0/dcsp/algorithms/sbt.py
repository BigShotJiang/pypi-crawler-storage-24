from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from csp.core import Constraint

from ..architectures.base import DCSPModel
from ..metrics import DCSPMetrics
from ..protocol import ProtocolLogger
from .base import AlgorithmBase, SolveOutcome


@dataclass
class _SBTAgentSpec:
    aid: str
    var: str
    domain: List[Any]
    constraints: List[Constraint]


class SynchronousBacktracking(AlgorithmBase):
    """Yokoo-style synchronous backtracking (token passing along a fixed order).

    This implementation can optionally enumerate all solutions by continuing the
    token-passing/backtracking search after a solution has been found.
    """

    name = "sbt"

    def __init__(self, *, metrics: Optional[DCSPMetrics] = None):
        super().__init__(metrics=metrics)

    def solve(
        self,
        model: DCSPModel,
        *,
        order: Optional[List[str]] = None,
        deterministic: bool = True,
        record_protocol: bool = False,
        protocol_path: Optional[str] = None,
        find_all_solutions: bool = False,
        max_solutions: Optional[int] = None,
        **_: Any,
    ) -> SolveOutcome:
        if "single_variable_agents" not in model.capabilities:
            raise ValueError("SBT requires an architecture with exactly one variable per agent")

        order = list(order) if order is not None else sorted(model.agents.keys())
        plog = ProtocolLogger(protocol_path if record_protocol else None)
        agents: List[_SBTAgentSpec] = [
            _SBTAgentSpec(
                aid=aid,
                var=model.agents[aid].var,
                domain=list(model.agents[aid].domain()),
                constraints=list(model.agents[aid].constraints),
            )
            for aid in order
        ]

        # Token-passing simulation: count messages as if each assignment is sent to next/prev.
        tried_stack: List[Dict[str, bool]] = [dict() for _ in agents]

        assignment: Dict[str, Any] = {}
        solutions: List[Dict[str, Any]] = []
        i = 0
        step = 0

        def consistent_local(agent: _SBTAgentSpec, val: Any, partial: Dict[str, Any]) -> bool:
            test = dict(partial)
            test[agent.var] = val
            for c in agent.constraints:
                # Only evaluate when all vars of constraint in partial+this var.
                if all(v in test for v in c.variables):
                    self.metrics.inc_agent(agent.aid, "constraint_checks")
                    if not c.evaluate(test):
                        return False
            return True

        while 0 <= i < len(agents):
            agent = agents[i]

            # Parallelism: in SBT only the current token holder is active per step.
            self.metrics.record_activity(step, agent.aid)
            step += 1


            # Simulated message: receive partial assignment.
            # We log token passing as message events for post-hoc analysis.
            self.metrics.inc_agent(agent.aid, "messages_sent")
            self.metrics.inc_agent(agent.aid, "messages_ok")

            chosen = None
            for v in agent.domain:
                key = f"{v}"
                if tried_stack[i].get(key, False):
                    continue
                if consistent_local(agent, v, assignment):
                    chosen = v
                    tried_stack[i][key] = True
                    break
                tried_stack[i][key] = True

            if chosen is None:
                # Backtrack.
                self.metrics.inc_agent(agent.aid, "backtracks")
                # Clear tries for this level for future different prefixes.
                tried_stack[i] = {}
                if agent.var in assignment:
                    assignment.pop(agent.var, None)
                i -= 1
                if i >= 0:
                    # Simulated backtrack message to previous.
                    prev = agents[i]
                    self.metrics.inc_agent(prev.aid, "messages_sent")
                    self.metrics.inc_agent(prev.aid, "messages_nogood")
                    try:
                        plog.log(t=float(step) / 1000.0, src=agent.aid, dst=prev.aid, kind="nogood", payload=dict(assignment))
                    except Exception:
                        pass
                continue

            assignment[agent.var] = chosen
            self.metrics.inc_agent(agent.aid, "value_changes")
            i += 1

            # Token forward message to next agent (or to "__done__" if complete).
            if i < len(agents):
                nxt = agents[i]
                try:
                    plog.log(t=float(step) / 1000.0, src=agent.aid, dst=nxt.aid, kind="ok", payload=dict(assignment))
                except Exception:
                    pass
            else:
                try:
                    plog.log(t=float(step) / 1000.0, src=agent.aid, dst="__done__", kind="solution", payload=dict(assignment))
                except Exception:
                    pass

            # If complete assignment, record solution and either stop or keep searching.
            if i == len(agents):
                # Global verify (cheap here; also guards against any modeling quirks).
                sat = True
                for cons in model.csp.constraints.values():
                    if not cons.evaluate(assignment):
                        sat = False
                        break
                if sat:
                    solutions.append(dict(assignment))

                if not find_all_solutions:
                    break

                if max_solutions is not None and len(solutions) >= max_solutions:
                    break

                # Force backtrack to enumerate the next solution.
                last = agents[-1]
                self.metrics.inc_agent(last.aid, "backtracks")
                assignment.pop(last.var, None)
                i = len(agents) - 1

        self.sim_time = step
        self.processed_events = step
        if not solutions:
            self.outcome = SolveOutcome(
                satisfiable=False,
                assignment={},
                terminated=True,
                reason="no_solution",
                solutions=[],
            )
            try:
                plog.close()
            except Exception:
                pass
            return self.outcome

        reason = "done"
        if find_all_solutions:
            if max_solutions is not None and len(solutions) >= max_solutions:
                reason = "max_solutions"
            else:
                reason = "all_solutions_found"

        self.outcome = SolveOutcome(
            satisfiable=True,
            assignment=dict(solutions[0]),
            terminated=True,
            reason=reason,
            solutions=solutions,
        )
        try:
            plog.close()
        except Exception:
            pass
        return self.outcome