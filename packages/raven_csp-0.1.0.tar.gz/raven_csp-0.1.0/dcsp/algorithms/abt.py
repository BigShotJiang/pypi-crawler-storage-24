from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set, Tuple

from csp.core import Constraint

from ..architectures.base import DCSPModel
from ..messages import Message, NogoodABT
from ..metrics import DCSPMetrics
from ..network import EventLoop, Network
from ..runtime_mp import MPNetwork, MPMetricsProxy, run_event_driven_mp
import multiprocessing as mp
from ..protocol import ProtocolLogger
from .base import AlgorithmBase, SolveOutcome


@dataclass
class _ABTAgent:
    aid: str
    var: str
    domain: List[Any]
    constraints: List[Constraint]
    # Fixed ranks: smaller rank => higher priority
    rank: int
    ranks: Dict[str, int]
    var_to_agent: Dict[str, str]
    neighbors_undirected: Set[str]
    net: Network
    metrics: DCSPMetrics

    current_value: Optional[Any] = None
    agent_view: Dict[str, Any] = field(default_factory=dict)  # assignments from known higher-priority vars
    nogood_list: List[NogoodABT] = field(default_factory=list)

    # Directed communication links. In ABT, ok? flows from higher->lower.
    outgoing: Set[str] = field(default_factory=set)

    terminated: bool = False
    no_solution: bool = False

    def is_higher_agent(self, other_aid: str) -> bool:
        return self.ranks[other_aid] < self.rank

    def is_lower_agent(self, other_aid: str) -> bool:
        return self.ranks[other_aid] > self.rank

    def init_links(self) -> None:
        # Outgoing links to lower-priority neighbors in the constraint graph.
        self.outgoing = {n for n in self.neighbors_undirected if self.is_lower_agent(n)}

    # ---------------------- messaging helpers ----------------------

    def _send_ok(self, receiver: str) -> None:
        self.metrics.inc_agent(self.aid, "messages_sent")
        self.metrics.inc_agent(self.aid, "messages_ok")
        msg = Message(kind="ok", sender=self.aid, receiver=receiver, payload=(self.var, self.current_value))
        self.net.send(msg)

    def _broadcast_ok(self) -> None:
        for r in sorted(self.outgoing):
            self._send_ok(r)

    def _send_nogood(self, receiver: str, nogood: NogoodABT) -> None:
        self.metrics.inc_agent(self.aid, "messages_sent")
        self.metrics.inc_agent(self.aid, "messages_nogood")
        msg = Message(kind="nogood", sender=self.aid, receiver=receiver, payload=nogood)
        self.net.send(msg)

    def _send_link_request(self, receiver: str) -> None:
        self.metrics.inc_agent(self.aid, "messages_sent")
        self.metrics.inc_agent(self.aid, "messages_link_request")
        msg = Message(kind="link_request", sender=self.aid, receiver=receiver, payload=self.aid)
        self.net.send(msg)

    # ---------------------- consistency logic ----------------------

    def _assignment_with(self, value: Any) -> Dict[str, Any]:
        a = dict(self.agent_view)
        a[self.var] = value
        return a

    def _compatible_nogood(self, nogood: NogoodABT) -> bool:
        # Compatible if all bindings match current agent_view / own current value.
        for v, val in nogood:
            if v == self.var:
                if self.current_value is None or self.current_value != val:
                    return False
            else:
                if self.agent_view.get(v, None) != val:
                    return False
        return True

    def _violates_any_nogood(self, value: Any) -> bool:
        # Check compatibility for nogoods (treat them as constraints).
        tmp_assign = dict(self.agent_view)
        tmp_assign[self.var] = value
        for ng in self.nogood_list:
            ok = True
            for v, val in ng:
                if tmp_assign.get(v, None) != val:
                    ok = False
                    break
            if ok:
                return True
        return False

    def _consistent_with_view(self, value: Any) -> bool:
        # Evaluate local constraints under partial assignment.
        assign = self._assignment_with(value)
        for c in self.constraints:
            self.metrics.inc_agent(self.aid, "constraint_checks")
            if not c.evaluate(assign):
                return False
        if self._violates_any_nogood(value):
            return False
        return True

    def _choose_value(self) -> Optional[Any]:
        for v in self.domain:
            if self._consistent_with_view(v):
                return v
        return None

    def check_agent_view(self) -> None:
        if self.terminated:
            return
        if self.current_value is not None and self._consistent_with_view(self.current_value):
            return
        newv = self._choose_value()
        if newv is not None:
            if self.current_value != newv:
                self.metrics.inc_agent(self.aid, "value_changes")
            self.current_value = newv
            self._broadcast_ok()
            return
        self.backtrack()

    def backtrack(self) -> None:
        self.metrics.inc_agent(self.aid, "backtracks")
        # Simplest nogood is the full agent_view.
        if not self.agent_view:
            self.no_solution = True
            self.terminated = True
            return

        nogood: NogoodABT = frozenset(self.agent_view.items())
        self.metrics.inc_agent(self.aid, "nogoods_generated")

        # Send to the lowest priority agent in the nogood.
        target_var = max(
            self.agent_view.keys(),
            key=lambda v: self.ranks[self.var_to_agent.get(v, v)],
        )
        target_aid = self.var_to_agent.get(target_var, target_var)
        self._send_nogood(target_aid, nogood)

        # Assume target will change; remove it locally and retry.
        self.agent_view.pop(target_var, None)
        self.check_agent_view()

    # ---------------------- message handlers ----------------------

    def on_message(self, msg: Message) -> None:
        # Parallelism: mark this agent active for the current simulation tick.
        self.metrics.record_activity(self.net.loop.time, self.aid)
        if self.terminated:
            return

        if msg.kind == "ok":
            var, val = msg.payload
            # Only accept ok? from higher-priority agents in ABT.
            if not self.is_higher_agent(msg.sender):
                return
            self.agent_view[var] = val
            self.check_agent_view()
            return

        if msg.kind == "link_request":
            requester = msg.payload
            # Add the requester as a lower-priority recipient (derived constraint).
            if self.is_lower_agent(requester):
                if requester not in self.outgoing:
                    self.outgoing.add(requester)
                    self.metrics.inc_agent(self.aid, "links_added")
                # Always send current value upon link establishment.
                if self.current_value is not None:
                    self._send_ok(requester)
            return

        if msg.kind == "nogood":
            nogood: NogoodABT = msg.payload
            # Context attachment: only react if compatible.
            # (Definition: all variables in nogood match current agent_view/own value.)
            if not self._compatible_nogood(nogood):
                # Send current value back to help the sender progress.
                if self.current_value is not None:
                    self._send_ok(msg.sender)
                return

            self.nogood_list.append(nogood)

            # If nogood contains unknown variables, request links to receive their values.
            for v, _ in nogood:
                if v == self.var:
                    continue
                # In ABT, we may not have been neighbors originally.
                owner = self.var_to_agent.get(v, v)
                if owner not in self.neighbors_undirected and self.is_higher_agent(owner):
                    self._send_link_request(owner)
                    # Also track it as a "virtual neighbor" now.
                    self.neighbors_undirected.add(owner)

            old = self.current_value
            self.check_agent_view()
            if old == self.current_value and self.current_value is not None:
                self._send_ok(msg.sender)
            return

        if msg.kind == "terminate":
            self.terminated = True
            return


class AsynchronousBacktracking(AlgorithmBase):
    name = "abt"

    def __init__(self, *, metrics: Optional[DCSPMetrics] = None):
        super().__init__(metrics=metrics)

    
    def solve(
        self,
        model: DCSPModel,
        *,
        max_delay: int = 0,
        random_seed: int = 0,
        max_events: int = 1_000_000,
        deterministic_init: bool = True,
        find_all_solutions: bool = False,
        max_solutions: Optional[int] = None,
        rebuild_model=None,
        **kwargs: Any,
    ) -> SolveOutcome:
        """Solve the DCSP. Optionally enumerate multiple solutions.

        For enumeration we iteratively forbid previously found solutions by adding
        a single 'nogood' constraint to a working copy of the CSP and restarting
        the algorithm on the updated model. This keeps the algorithm logic intact
        and works for arbitrary constraint arity.
        """
        if not find_all_solutions:
            return self._solve_once(
                model,
                max_delay=max_delay,
                random_seed=random_seed,
                max_events=max_events,
                deterministic_init=deterministic_init,
                **kwargs,
            )

        if rebuild_model is None:
            raise ValueError("find_all_solutions=True requires a rebuild_model callable (CSP -> DCSPModel).")

        from ..utils import add_solution_nogood, clone_csp

        csp_work = clone_csp(model.csp)
        solutions: List[Dict[str, Any]] = []

        total_sim_time = 0
        total_events = 0
        offset = 0

        k = 0
        while True:
            if max_solutions is not None and len(solutions) >= max_solutions:
                reason = "max_solutions"
                terminated = True
                break

            model_k = rebuild_model(csp_work)
            self.metrics.set_time_offset(offset)
            out = self._solve_once(
                model_k,
                max_delay=max_delay,
                random_seed=random_seed + k,
                max_events=max_events,
                deterministic_init=deterministic_init,
                **kwargs,
            )
            total_sim_time += getattr(self, "sim_time", 0)
            total_events += getattr(self, "processed_events", 0)
            offset += int(getattr(self, "sim_time", 0)) + 1

            if out.satisfiable and out.terminated:
                sol = dict(out.assignment)
                solutions.append(sol)
                add_solution_nogood(csp_work, sol, name=f"__nogood_sol_{k:04d}")
                k += 1
                continue

            # No more solutions (proved) or inconclusive stop.
            if out.terminated and out.reason == "no_solution":
                reason = "all_solutions_found" if solutions else "no_solution"
                terminated = True
            else:
                reason = out.reason or "inconclusive"
                terminated = False
            break

        self.metrics.set_time_offset(0)
        self.sim_time = total_sim_time
        self.processed_events = total_events

        self.outcome = SolveOutcome(
            satisfiable=bool(solutions),
            assignment=dict(solutions[0]) if solutions else {},
            terminated=terminated,
            reason=reason,
            solutions=solutions,
        )
        return self.outcome

    def _solve_once(
            self,
            model: DCSPModel,
            *,
            max_delay: int = 0,
            random_seed: int = 0,
            max_events: int = 1_000_000,
            deterministic_init: bool = True,
            runtime: str = "sim",
            record_protocol: bool = False,
            protocol_path: Optional[str] = None,
            **_: Any,
        ) -> SolveOutcome:
            if "single_variable_agents" not in model.capabilities:
                raise ValueError("ABT requires an architecture with exactly one variable per agent")

            if runtime.lower().strip() == "mp":
                return self._solve_once_mp(
                    model,
                    random_seed=random_seed,
                    max_events=max_events,
                    deterministic_init=deterministic_init,
                    record_protocol=record_protocol,
                    protocol_path=protocol_path,
                )

            rng = random.Random(random_seed)
            loop = EventLoop(max_delay=max_delay, rng=rng)
            plog = ProtocolLogger(protocol_path if record_protocol else None)
            net = Network(loop, protocol=plog)

            # Fixed priority order, deterministic and comparable.
            order = sorted(model.agents.keys())
            ranks = {v: i for i, v in enumerate(order)}

            agents: Dict[str, _ABTAgent] = {}
            for aid, spec in model.agents.items():
                a = _ABTAgent(
                    aid=aid,
                    var=spec.var,
                    domain=list(spec.domain()),
                    constraints=list(spec.constraints),
                    rank=ranks[aid],
                    ranks=ranks,
                    var_to_agent=dict(model.var_to_agent),
                    neighbors_undirected=set(model.neighbors.get(aid, set())),
                    net=net,
                    metrics=self.metrics,
                )
                agents[aid] = a

            for aid, a in agents.items():
                net.register(aid, a.on_message)

            # Initialize values and links.
            for aid, a in agents.items():
                a.init_links()
                if not a.domain:
                    a.no_solution = True
                    a.terminated = True
                    continue
                if deterministic_init:
                    a.current_value = a.domain[0]
                else:
                    a.current_value = rng.choice(a.domain)
                a.metrics.inc_agent(aid, "value_changes")
                self.metrics.record_activity(0, aid)

            # Initial ok? messages from all agents to their outgoing links.
            for a in agents.values():
                if not a.terminated and a.current_value is not None:
                    a._broadcast_ok()

            # Main event loop.
            events = 0
            timed_out = False
            while events < max_events:
                if any(a.no_solution for a in agents.values()):
                    # Terminate all.
                    for receiver in agents:
                        net.send(Message(kind="terminate", sender="__sys__", receiver=receiver, payload=None))
                    net.run(max_events=10_000)
                    break

                if loop.empty():
                    break

                m = loop.step()
                if m is None:
                    break
                handler = net.handlers.get(m.receiver)
                if handler:
                    handler(m)
                events += 1

            # If we hit the event limit while messages are still queued, treat this as a timeout
            # (i.e., inconclusive), not as UNSAT.
            if events >= max_events and not loop.empty() and not any(a.no_solution for a in agents.values()):
                timed_out = True

            self.sim_time = loop.time
            self.processed_events = events

            # Determine outcome.
            if timed_out:
                assignment = {aid: a.current_value for aid, a in agents.items() if a.current_value is not None}
                self.outcome = SolveOutcome(satisfiable=False, assignment=assignment, terminated=False, reason="timeout")
                try:
                    plog.close()  # type: ignore[name-defined]
                except Exception:
                    pass
                return self.outcome
            if any(a.no_solution for a in agents.values()):
                self.outcome = SolveOutcome(satisfiable=False, assignment={}, terminated=True, reason="no_solution")
                try:
                    plog.close()  # type: ignore[name-defined]
                except Exception:
                    pass
                return self.outcome

            assignment = {aid: a.current_value for aid, a in agents.items() if a.current_value is not None}

            # Verify globally.
            sat = True
            for cons in model.csp.constraints.values():
                if not cons.evaluate(assignment):
                    sat = False
                    break

            if sat:
                self.outcome = SolveOutcome(satisfiable=True, assignment=assignment, terminated=True, reason="stable")
            else:
                # Quiescent but globally inconsistent => inconclusive under this algorithm/model.
                self.outcome = SolveOutcome(satisfiable=False, assignment=assignment, terminated=False, reason="inconclusive")
            try:
                plog.close()  # type: ignore[name-defined]
            except Exception:
                pass
            return self.outcome

    def _solve_once_mp(
        self,
        model: DCSPModel,
        *,
        random_seed: int,
        max_events: int,
        deterministic_init: bool,
        record_protocol: bool,
        protocol_path: Optional[str],
    ) -> SolveOutcome:
        if "single_variable_agents" not in model.capabilities:
            raise ValueError("ABT requires an architecture with exactly one variable per agent")

        rng = random.Random(random_seed)
        ctx = mp.get_context("fork") if "fork" in mp.get_all_start_methods() else mp.get_context()
        ctrl: mp.Queue = ctx.Queue()
        inboxes: Dict[str, mp.Queue] = {aid: ctx.Queue() for aid in model.agents.keys()}

        # MPNetwork uses a monotonic clock for timestamps.
        from ..protocol import MonotonicClock

        clock = MonotonicClock()
        net = MPNetwork(inboxes=inboxes, ctrl=ctrl, clock=clock)
        mproxy = MPMetricsProxy(ctrl)

        order = sorted(model.agents.keys())
        ranks = {v: i for i, v in enumerate(order)}

        agents: Dict[str, _ABTAgent] = {}
        for aid, spec in model.agents.items():
            a = _ABTAgent(
                aid=aid,
                var=spec.var,
                domain=list(spec.domain()),
                constraints=list(spec.constraints),
                rank=ranks[aid],
                ranks=ranks,
                var_to_agent=dict(model.var_to_agent),
                neighbors_undirected=set(model.neighbors.get(aid, set())),
                net=net,  # type: ignore[arg-type]
                metrics=mproxy,  # type: ignore[arg-type]
            )
            agents[aid] = a

        # Initialize values and links (in master before forking).
        for aid, a in agents.items():
            a.init_links()
            if not a.domain:
                a.no_solution = True
                a.terminated = True
                continue
            a.current_value = a.domain[0] if deterministic_init else rng.choice(a.domain)
            mproxy.inc_agent(aid, "value_changes")
            mproxy.record_activity(0, aid)

        for a in agents.values():
            if not a.terminated and a.current_value is not None:
                a._broadcast_ok()

        def decide(states: Dict[str, Dict[str, Any]], had_nosol: bool):
            if had_nosol:
                return False, True, "no_solution", {}
            assignment = {}
            for aid, st in states.items():
                if "current_value" in st and st.get("current_value") is not None:
                    assignment[aid] = st["current_value"]
            # Global verify.
            sat = True
            for cons in model.csp.constraints.values():
                if not cons.evaluate(assignment):
                    sat = False
                    break
            if sat:
                return True, True, "stable", assignment
            return False, False, "inconclusive", assignment

        out = run_event_driven_mp(
            agents=agents,
            inboxes=inboxes,
            ctrl=ctrl,
            metrics=self.metrics,
            protocol_path=(protocol_path if record_protocol else None),
            max_events=max_events,
            decide_outcome=decide,
        )

        self.sim_time = out.sim_time_ms
        self.processed_events = out.processed_events
        self.outcome = SolveOutcome(
            satisfiable=out.satisfiable,
            assignment=out.assignment,
            terminated=out.terminated,
            reason=out.reason,
            solutions=[dict(out.assignment)] if out.satisfiable else [],
        )
        return self.outcome