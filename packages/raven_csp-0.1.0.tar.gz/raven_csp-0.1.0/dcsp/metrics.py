from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Optional, Set

from csp.instrument import Counters


@dataclass
class DCSPMetrics:
    """Metrics container for distributed CSP experiments.

    Besides simple global/per-agent counters, this class also tracks a
    *parallelism profile*:

    - For each discrete time unit t, we record how many distinct agents were
      active (performed at least one processing step) at that t.
    - From that profile we derive summary statistics (avg/max).
    """

    counters: Counters = field(default_factory=Counters)
    per_agent: Dict[str, Counters] = field(default_factory=dict)

    # --- parallelism tracking (time -> #active agents) ---
    parallelism_per_time: Dict[int, int] = field(default_factory=dict)
    _par_time_offset: int = 0
    _par_current_time: Optional[int] = None
    _par_active_agents: Set[str] = field(default_factory=set, repr=False)
    _par_total_active: int = 0
    _par_active_ticks: int = 0
    _par_max_active: int = 0
    _par_min_time: Optional[int] = None
    _par_max_time: Optional[int] = None

    def a(self, agent_id: str) -> Counters:
        if agent_id not in self.per_agent:
            self.per_agent[agent_id] = Counters()
        return self.per_agent[agent_id]

    def inc(self, key: str, by: int = 1) -> None:
        self.counters.inc(key, by)

    def inc_agent(self, agent_id: str, key: str, by: int = 1) -> None:
        self.a(agent_id).inc(key, by)
        self.counters.inc(key, by)

    # ---------------- parallelism API ----------------

    def set_time_offset(self, offset: int) -> None:
        """Shift all subsequently recorded time stamps by `offset`.

        Useful when a solver restarts multiple times (solution enumeration) and
        you still want a single, non-overlapping time axis.
        """
        self._par_time_offset = int(offset)

    def _flush_parallelism_tick(self) -> None:
        if self._par_current_time is None:
            return
        cnt = len(self._par_active_agents)
        self.parallelism_per_time[self._par_current_time] = cnt
        self._par_total_active += cnt
        self._par_active_ticks += 1
        if cnt > self._par_max_active:
            self._par_max_active = cnt
        self._par_active_agents.clear()

    def record_activity(self, time_unit: int, agent_id: str) -> None:
        """Mark an agent as active in the given time unit."""
        t = int(time_unit) + self._par_time_offset

        if self._par_current_time is None:
            self._par_current_time = t
            self._par_min_time = t
        elif t != self._par_current_time:
            self._flush_parallelism_tick()
            self._par_current_time = t

        self._par_active_agents.add(agent_id)
        self._par_max_time = t

    def finalize_parallelism(self) -> None:
        """Flush last tick and write summary statistics into `counters`."""
        self._flush_parallelism_tick()

        active_ticks = self._par_active_ticks
        avg_active = (self._par_total_active / active_ticks) if active_ticks else 0.0

        if self._par_min_time is not None and self._par_max_time is not None:
            span = self._par_max_time - self._par_min_time + 1
            avg_span = (self._par_total_active / span) if span > 0 else 0.0
        else:
            span = 0
            avg_span = 0.0

        # Store as plain values in counters so they are returned in results.metrics.
        self.counters["parallelism_avg_active_ticks"] = avg_active
        self.counters["parallelism_avg_span"] = avg_span
        self.counters["parallelism_max_active_agents"] = self._par_max_active
        self.counters["parallelism_active_time_units"] = active_ticks
        self.counters["parallelism_time_span"] = span
        # And the raw profile (sparse) for plotting/analysis.
        self.counters["parallelism_per_time"] = dict(self.parallelism_per_time)


DEFAULT_METRIC_KEYS = [
    # Communication
    "messages_sent",
    "messages_ok",
    "messages_nogood",
    "messages_link_request",
    "messages_terminate",
    "messages_improve",
    # Computation
    "constraint_checks",
    "value_changes",
    "backtracks",
    "nogoods_generated",
    "links_added",
    "priority_changes",
    "weight_increases",
    # Parallelism (summaries)
    "parallelism_avg_active_ticks",
    "parallelism_avg_span",
    "parallelism_max_active_agents",
    "parallelism_active_time_units",
    "parallelism_time_span",
]
