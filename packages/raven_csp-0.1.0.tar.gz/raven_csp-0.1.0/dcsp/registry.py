from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional, Type

from .architectures.base import Architecture, DCSPModel
from .architectures.variable_agent import VariableAgentArchitecture
from .architectures.constraint_agent import ConstraintAgentArchitecture


_ARCHITECTURES: Dict[str, Architecture] = {
    "variable": VariableAgentArchitecture(),
    "var": VariableAgentArchitecture(),
    "one-var": VariableAgentArchitecture(),

    "constraint": ConstraintAgentArchitecture(),
    "cons": ConstraintAgentArchitecture(),
}


def register_architecture(name: str, arch: Architecture) -> None:
    _ARCHITECTURES[name.lower().strip()] = arch


def get_architecture(name: str) -> Architecture:
    key = name.lower().strip()
    if key not in _ARCHITECTURES:
        known = ", ".join(sorted(set(_ARCHITECTURES.keys())))
        raise ValueError(f"Unknown architecture '{name}'. Known: {known}")
    return _ARCHITECTURES[key]


def list_architectures() -> Dict[str, Architecture]:
    return dict(_ARCHITECTURES)
