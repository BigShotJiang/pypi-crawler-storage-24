from __future__ import annotations

from typing import Any, Dict, Iterable, List, Tuple

from csp.core import CSP, Constraint, Variable


def clone_csp(csp: CSP) -> CSP:
    """Deep-ish clone of the in-repo CSP object (variables + constraints).

    We copy data structures explicitly to avoid surprises with eval-based constraints.
    """
    c = CSP()
    c.variables = {name: Variable(name, set(var.domain)) for name, var in csp.variables.items()}
    c.constraints = {
        name: Constraint(name, cons.expression, list(cons.variables)) for name, cons in csp.constraints.items()
    }
    c.constraints_by_var = {v: list(lst) for v, lst in csp.constraints_by_var.items()}
    return c


def forbid_solution_expression(solution: Dict[str, Any], *, var_order: Iterable[str] | None = None) -> str:
    """Build an expression that is true for every assignment except `solution`.

    Equivalent to: (x1 != v1) or (x2 != v2) or ...
    """
    keys = list(var_order) if var_order is not None else sorted(solution.keys())
    parts: List[str] = []
    for v in keys:
        if v not in solution:
            continue
        parts.append(f"({v} != {repr(solution[v])})")
    if not parts:
        # Degenerate: forbid nothing.
        return "True"
    return "(" + " or ".join(parts) + ")"


def add_solution_nogood(csp: CSP, solution: Dict[str, Any], *, name: str) -> None:
    """Add a single constraint that forbids exactly the given complete solution."""
    expr = forbid_solution_expression(solution, var_order=sorted(csp.variables.keys()))
    vars_in = list(sorted(csp.variables.keys()))
    csp.constraints[name] = Constraint(name, expr, vars_in)
    for v in vars_in:
        csp.constraints_by_var.setdefault(v, []).append(name)
