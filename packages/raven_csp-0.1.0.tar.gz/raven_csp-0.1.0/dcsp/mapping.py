"""Backwards-compatible mapping entry points.

The architecture layer lives under `dcsp.architectures`.
This module keeps the original import paths working.
"""

from __future__ import annotations

from typing import Dict, List, Set, Tuple

from csp.core import CSP

from .architectures.variable_agent import build_variable_agent_model
from .architectures.constraint_agent import build_constraint_agent_model, validate_constraint_assignment



def build_pseudotree_constraint_assignment(
    csp: CSP,
    *,
    bundle_size: int | None = None,
) -> List[Tuple[str, ...]]:
    """Create a deterministic constraint->agent assignment via DFS pseudo-tree order.

    This helper targets tree-based DCSP families (ADOPT/DPOP/BnB-ADOPT/SyncBB):
    it builds a DFS pseudo-tree over the *constraint graph* (constraints are adjacent
    when they share at least one variable) and returns an assignment list that can be
    passed to ``build_constraint_agent_model(..., assignment=...)``.

    Parameters
    ----------
    csp
        Centralized CSP instance.
    bundle_size
        Optional fixed number of DFS-ordered constraints per agent tuple.
        - ``None`` (default): automatic, coupling-aware grouping with variable bundle sizes
        - ``1``: one constraint-agent per constraint
        - ``>1``: fixed chunking in DFS order

    Returns
    -------
    list[tuple[str, ...]]
        Assignment in agent order (A0, A1, ...), each tuple listing owned
        constraint names.
    """
    if bundle_size is not None and bundle_size <= 0:
        raise ValueError("bundle_size must be >= 1 when provided")

    c_names = sorted(csp.constraints.keys())
    if not c_names:
        return [tuple()]

    # Build constraint graph: edge if two constraints share at least one variable.
    scopes: Dict[str, Set[str]] = {
        cname: set(csp.constraints[cname].variables)
        for cname in c_names
    }
    adj: Dict[str, Set[str]] = {cname: set() for cname in c_names}
    for i, a in enumerate(c_names):
        for b in c_names[i + 1 :]:
            if scopes[a].intersection(scopes[b]):
                adj[a].add(b)
                adj[b].add(a)

    # DFS pseudo-tree order over each connected component.
    visited: Set[str] = set()
    order: List[str] = []

    def _root_key(cname: str):
        # Prefer high-degree roots; tie-break lexicographically for determinism.
        return (-len(adj[cname]), str(cname))

    for root in sorted(c_names, key=_root_key):
        if root in visited:
            continue
        stack: List[str] = [root]
        while stack:
            cur = stack.pop()
            if cur in visited:
                continue
            visited.add(cur)
            order.append(cur)
            neigh = sorted(adj[cur], key=lambda x: (len(adj[x]), str(x)), reverse=True)
            for n in neigh:
                if n not in visited:
                    stack.append(n)

    # Fixed chunking mode (legacy behavior).
    if bundle_size is not None:
        out: List[Tuple[str, ...]] = []
        for i in range(0, len(order), int(bundle_size)):
            out.append(tuple(order[i : i + int(bundle_size)]))
        return out

    # Automatic, coupling-aware grouping mode.
    # Objective (heuristic): minimize inter-agent coupling while avoiding one giant agent.
    # We greedily merge bundles if it improves:
    #   F = cut_weight + alpha * sum(size(bundle)^2)
    # where cut_weight is the sum of shared-variable edge weights between bundles.
    # This naturally allows non-uniform bundle sizes.
    if len(order) <= 1:
        return [tuple(order)] if order else [tuple()]

    pos = {c: i for i, c in enumerate(order)}

    # Weighted coupling graph (number of shared variables).
    w: Dict[Tuple[str, str], int] = {}
    edge_vals: List[int] = []
    for i, a in enumerate(c_names):
        for b in c_names[i + 1 :]:
            ww = len(scopes[a].intersection(scopes[b]))
            if ww > 0:
                key = (a, b) if a < b else (b, a)
                w[key] = int(ww)
                edge_vals.append(int(ww))

    avg_w = (sum(edge_vals) / len(edge_vals)) if edge_vals else 0.0
    alpha = (avg_w / max(2, len(c_names))) if avg_w > 0 else 0.0

    bundles: List[Set[str]] = [{c} for c in order]

    def _between(sa: Set[str], sb: Set[str]) -> int:
        tot = 0
        for x in sa:
            for y in sb:
                key = (x, y) if x < y else (y, x)
                tot += int(w.get(key, 0))
        return tot

    improved = True
    while improved and alpha > 0:
        improved = False
        best_pair: Tuple[int, int] | None = None
        best_delta = 0.0

        for i in range(len(bundles)):
            for j in range(i + 1, len(bundles)):
                bw = _between(bundles[i], bundles[j])
                if bw <= 0:
                    continue
                a = len(bundles[i])
                b = len(bundles[j])
                delta = -float(bw) + (2.0 * alpha * a * b)
                if delta < best_delta:
                    best_delta = delta
                    best_pair = (i, j)

        if best_pair is not None:
            i, j = best_pair
            bundles[i] = set(bundles[i]).union(bundles[j])
            del bundles[j]
            improved = True

    # Deterministic output order: by first DFS occurrence; tuple content follows DFS order.
    bundles_sorted = sorted(bundles, key=lambda sset: min(pos[c] for c in sset))
    out_auto: List[Tuple[str, ...]] = []
    for bset in bundles_sorted:
        out_auto.append(tuple(sorted(bset, key=lambda c: pos[c])))
    return out_auto

__all__ = [
    "build_variable_agent_model",
    "build_constraint_agent_model",
    "validate_constraint_assignment",
    "build_pseudotree_constraint_assignment",
]
