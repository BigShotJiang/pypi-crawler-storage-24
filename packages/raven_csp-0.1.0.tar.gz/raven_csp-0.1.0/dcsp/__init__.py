"""Distributed CSP extension that is fully compatible with the existing centralized CSP framework.

You can keep using the original API under `csp.*`. This package additionally re-exports the
most common CSP entry points so experiments can be written with a single import.
"""

from __future__ import annotations

# --- Re-exports from the centralized CSP framework ---
from csp import CSP, run_propagation, run_search, binarize_csp
from csp.api import print_result as print_csp_result
from csp.excel import load_excel_csp, make_excel_csp_factory

# --- DCSP / distributed functionality ---
from .api import run_distributed_search, run_distributed_propagation, print_result as print_dcsp_result, solve
from .mapping import (
    build_variable_agent_model,
    build_constraint_agent_model,
    validate_constraint_assignment,
    build_pseudotree_constraint_assignment,
)
from .registry import register_architecture, list_architectures
from .strategies import register_strategy, list_strategies
from .results import DistributedSearchResult
from .excel import make_excel_dcsp_factory

__all__ = [
    # CSP core
    "CSP",
    "run_propagation",
    "run_search",
    "binarize_csp",
    "print_csp_result",
    "load_excel_csp",
    "make_excel_csp_factory",

    # DCSP
    "run_distributed_search",
    "run_distributed_propagation",
    "print_dcsp_result",
    "solve",
    "build_variable_agent_model",
    "build_constraint_agent_model",
    "validate_constraint_assignment",
    "build_pseudotree_constraint_assignment",
    "register_architecture",
    "list_architectures",
    "register_strategy",
    "list_strategies",
    "make_excel_dcsp_factory",
    "DistributedSearchResult",
]
