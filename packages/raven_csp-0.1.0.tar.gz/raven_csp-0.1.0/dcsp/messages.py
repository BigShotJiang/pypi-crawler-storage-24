from __future__ import annotations

from dataclasses import dataclass
from typing import Any, FrozenSet, Optional, Tuple


@dataclass(frozen=True)
class Message:
    """A point-to-point message delivered by the simulation runtime."""

    kind: str
    sender: str
    receiver: str
    payload: Any
    # Optional logical timestamp to support debugging / reproducibility.
    sent_at: int = 0


# Nogoods are represented as frozensets of tuples.
NogoodABT = FrozenSet[Tuple[str, Any]]
NogoodAWCS = FrozenSet[Tuple[str, Any, int]]
