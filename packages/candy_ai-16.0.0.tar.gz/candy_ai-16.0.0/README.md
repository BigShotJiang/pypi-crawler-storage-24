# 🍬 candy-ai v16

**Framework IA Python professionnel** · Cedric7-Thinking Engine

```bash
pip install candy-ai
```

---

## Nouvelles fonctionnalités v16

### CLI avancé
```bash
candy --score "mon prompt"          # Score 0-100 + grade A→F
candy --fix "mon prompt"            # Auto-optimise avec gain affiché
candy --dry-run "mon prompt"        # Simule sans appeler l'API
candy --ask "Explique Python"       # One-liner depuis terminal
candy --ask "Hello" --lang EN --stream   # Streaming terminal
candy --status                      # Statut de l'API
```

### Smart — auto-optimisation
```python
from candy import Smart

# Optimise + choisit la meilleure séquence d'agents automatiquement
result = Smart.run("fais un truc en python")
print(result["optimized_prompt"])  # prompt amélioré
print(result["sequence"])          # ["coding", "debugger", "reviewer"]
print(result["final"])             # résultat final

# Recommande seulement la séquence
seq = Smart.recommend("Analyse ce dataset et génère un rapport")

# Explique le plan sans exécuter
plan = Smart.explain("rédige un article sur l'IA")
```

### Monitor — dashboard terminal
```python
from candy import Monitor

Monitor.show()              # dashboard ASCII complet
Monitor.top(5)              # top 5 personnalités
Monitor.export("stats.json")
stats = Monitor.report()    # dict complet des stats
```

### CLI Pipeline viz
```python
from candy.cli import _print_pipeline_viz
result = Agent.run([Coding, Debugger, Reviewer], "task", profile="dev")
_print_pipeline_viz(result)  # ASCII flow diagram
```

---

## Syntaxe rapide

```python
from candy import Candy, Smart, Monitor, Agent, Memory, cfg, Coding

# One-liner
print(Candy.ask("Explique les closures Python"))

# Smart pipeline auto
result = Smart.run("analyse mes ventes et génère un rapport")

# Multi-agents manuel
cfg.dev = cfg.preset("coder")
result = Agent.run([Coding, Debugger, Reviewer], "client REST", profile="dev")

# Mémoire persistante
mem = Memory("mon_projet")
mem.add("user", "Bonjour"); mem.save()
mem.save_version("v1")
```

---

**90 personnalités · MIT · Cedric7-Thinking**
