"""
candy.smart — Auto-optimisation v16
=====================================

Combine Candy.fix() + Agent.run() pour proposer automatiquement
la meilleure séquence multi-modules selon la tâche détectée.

Usage :
    from candy import Smart

    # Auto-optimise + choisit la meilleure séquence d'agents
    result = Smart.run("mon prompt vague")
    print(result["optimized_prompt"])
    print(result["final"])

    # Recommande seulement la séquence
    seq = Smart.recommend("Analyse ce dataset et génère un rapport")
    print(seq)
    # → [("analytic", "Analyse"), ("writing", "Rédige"), ("reviewer", "Vérifie")]
"""

from typing import Optional
from .core import Candy, Agent, _detect_personality


# ── Séquences recommandées par type de tâche ─────────────────────────────────

_SEQUENCES = {
    "coding": [
        ("coding",   "Écris le code complet et fonctionnel."),
        ("debugger", "Trouve et corrige les bugs potentiels."),
        ("reviewer", "Améliore la lisibilité et la qualité."),
    ],
    "writing": [
        ("writing",    "Rédige le contenu de façon engageante."),
        ("reviewer",   "Corrige les erreurs et améliore le style."),
    ],
    "analytic": [
        ("analytic",   "Analyse en détail et identifie les patterns."),
        ("writing",    "Présente les résultats de façon claire."),
        ("summarizer", "Synthétise en points clés actionnables."),
    ],
    "research": [
        ("research",   "Explore le sujet en profondeur."),
        ("analytic",   "Analyse et structure les informations."),
        ("summarizer", "Synthétise les points essentiels."),
        ("writing",    "Rédige un rapport clair et professionnel."),
    ],
    "marketing": [
        ("marketing",  "Développe la stratégie et le message."),
        ("copywriting","Rédige le contenu persuasif."),
        ("reviewer",   "Optimise l'impact et la clarté."),
    ],
    "debugging": [
        ("debugger",   "Identifie tous les bugs et erreurs."),
        ("coding",     "Propose les corrections."),
        ("reviewer",   "Vérifie la qualité finale."),
    ],
    "seo": [
        ("seo",        "Optimise pour le référencement."),
        ("copywriting","Rédige le contenu optimisé."),
        ("reviewer",   "Vérifie la cohérence et la qualité."),
    ],
    "default": [
        ("full",       "Traite la demande en profondeur."),
        ("reviewer",   "Améliore et affine le résultat."),
    ],
}


class _Smart:
    """
    Interface d'auto-optimisation v16.
    Détecte la tâche, optimise le prompt, choisit la séquence d'agents.
    """

    def recommend(self, prompt: str) -> list:
        """
        Recommande la meilleure séquence d'agents pour ce prompt.
        Retourne [(module_name, instruction), ...]

        from candy import Smart
        seq = Smart.recommend("Analyse ce dataset et génère un rapport")
        # → [("analytic", "..."), ("writing", "..."), ("summarizer", "...")]
        """
        personality = _detect_personality(prompt)
        return _SEQUENCES.get(personality, _SEQUENCES["default"])

    def run(self, prompt: str, lang: str = "FR",
            profile: str = "default", verbose: bool = False) -> dict:
        """
        Pipeline complet auto-optimisé :
        1. Score le prompt original
        2. Optimise le prompt si score < 60
        3. Détecte la séquence d'agents optimale
        4. Exécute le pipeline

        from candy import Smart
        result = Smart.run("fais un truc en python")
        print(result["optimized_prompt"])
        print(result["final"])
        print(result["sequence"])
        """
        # 1. Score original
        score_before = Candy.score(prompt)
        optimized    = prompt

        # 2. Auto-fix si score faible
        if score_before["score"] < 60:
            if verbose:
                print(f"  [Smart] Score initial : {score_before['score']}/100 → optimisation...")
            optimized = Candy.fix(prompt, lang=lang)
            if verbose:
                print(f"  [Smart] Prompt optimisé : {optimized}")

        score_after = Candy.score(optimized)

        # 3. Séquence recommandée
        sequence = self.recommend(optimized)
        if verbose:
            print(f"  [Smart] Séquence : {[s[0] for s in sequence]}")

        # 4. Exécute via Agent.pipeline
        result = Agent.pipeline(optimized, steps=sequence, lang=lang)

        return {
            "original_prompt":   prompt,
            "optimized_prompt":  optimized,
            "score_before":      score_before["score"],
            "score_after":       score_after["score"],
            "grade":             score_after["grade"],
            "sequence":          [s[0] for s in sequence],
            "steps":             result["steps"],
            "final":             result["final"],
            "was_optimized":     optimized != prompt,
        }

    def explain(self, prompt: str) -> dict:
        """
        Explique ce que Smart ferait sans l'exécuter.
        Retourne le plan complet.

        from candy import Smart
        plan = Smart.explain("rédige un article sur l'IA")
        print(plan)
        """
        score    = Candy.score(prompt)
        would_fix = score["score"] < 60
        sequence = self.recommend(prompt)

        return {
            "prompt":           prompt,
            "score":            score["score"],
            "grade":            score["grade"],
            "would_optimize":   would_fix,
            "detected":         score["detected_personality"],
            "planned_sequence": [s[0] for s in sequence],
            "steps_detail":     sequence,
            "api_calls":        len(sequence) + (1 if would_fix else 0),
        }


Smart = _Smart()
