from .base import BaseModule


class Logistics(BaseModule):
    """Supply chain, gestion des stocks, logistique internationale, optimisation des flux, transport multimodal."""
    _personality = "logistics"
