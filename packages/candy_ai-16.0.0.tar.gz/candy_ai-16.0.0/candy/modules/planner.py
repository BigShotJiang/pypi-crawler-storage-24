from .base import BaseModule


class Planner(BaseModule):
    """Gestion de projet, tâches, timelines, risques."""
    _personality = "planner"
