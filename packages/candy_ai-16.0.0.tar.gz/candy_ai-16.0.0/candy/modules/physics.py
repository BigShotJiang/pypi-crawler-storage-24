from .base import BaseModule


class Physics(BaseModule):
    """Mécanique, électromagnétisme, quantique, relativité."""
    _personality = "physics"
