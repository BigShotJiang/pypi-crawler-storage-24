from .base import BaseModule


class ClimateTech(BaseModule):
    """Technologies climatiques, capture carbone, énergies renouvelables, marchés carbone, solutions bas-carbone."""
    _personality = "climatetech"
