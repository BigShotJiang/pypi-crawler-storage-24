from .base import BaseModule


class Chemistry(BaseModule):
    """Chimie organique, inorganique, physique et analytique."""
    _personality = "chemistry"
