from .base import BaseModule


class Translator(BaseModule):
    """Traduction professionnelle entre toutes les langues."""
    _personality = "translator"
