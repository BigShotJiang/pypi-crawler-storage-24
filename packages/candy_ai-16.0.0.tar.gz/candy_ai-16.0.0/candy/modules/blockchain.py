from .base import BaseModule


class Blockchain(BaseModule):
    """Développement smart contracts, Solidity, Web3, protocoles DeFi, sécurité des contrats intelligents."""
    _personality = "blockchain"
