from .base import BaseModule


class Leadership(BaseModule):
    """Management d'équipe, prise de décision, intelligence collective, leadership situationnel et transformationnel."""
    _personality = "leadership"
