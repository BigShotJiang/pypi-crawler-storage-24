from .base import BaseModule


class ArVr(BaseModule):
    """Réalité augmentée et virtuelle, Unity XR, développement immersif, UX pour la XR."""
    _personality = "ar_vr"
