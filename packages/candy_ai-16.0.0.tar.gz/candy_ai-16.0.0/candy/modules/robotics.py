from .base import BaseModule


class Robotics(BaseModule):
    """Robotique, ROS, cinématique, systèmes embarqués, vision par ordinateur pour robots."""
    _personality = "robotics"
