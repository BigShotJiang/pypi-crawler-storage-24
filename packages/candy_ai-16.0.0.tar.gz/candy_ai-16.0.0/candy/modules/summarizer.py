from .base import BaseModule


class Summarizer(BaseModule):
    """Synthèse et résumé de tout type de contenu."""
    _personality = "summarizer"
