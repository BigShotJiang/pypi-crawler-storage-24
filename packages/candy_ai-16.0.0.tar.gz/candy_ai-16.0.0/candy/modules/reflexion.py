from .base import BaseModule


class Reflexion(BaseModule):
    """Pensée critique et philosophique. Analyse multi-angles, méthode socratique."""
    _personality = "reflexion"
