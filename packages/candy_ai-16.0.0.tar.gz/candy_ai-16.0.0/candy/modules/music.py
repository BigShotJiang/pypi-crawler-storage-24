from .base import BaseModule


class Music(BaseModule):
    """Théorie musicale, harmonie, composition, production."""
    _personality = "music"
