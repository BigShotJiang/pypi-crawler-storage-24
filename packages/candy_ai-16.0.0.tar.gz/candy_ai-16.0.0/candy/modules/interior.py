from .base import BaseModule


class Interior(BaseModule):
    """Design d'intérieur, aménagement d'espace, feng shui, tendances déco, choix des matériaux et couleurs."""
    _personality = "interior"
