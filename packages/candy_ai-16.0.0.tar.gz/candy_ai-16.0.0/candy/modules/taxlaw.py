from .base import BaseModule


class TaxLaw(BaseModule):
    """Fiscalité, optimisation fiscale légale, impôts des entreprises et particuliers, TVA, déclarations fiscales."""
    _personality = "taxlaw"
