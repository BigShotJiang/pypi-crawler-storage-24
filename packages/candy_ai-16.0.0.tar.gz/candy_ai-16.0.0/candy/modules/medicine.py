from .base import BaseModule


class Medicine(BaseModule):
    """Médecine : symptômes, traitements, pharmacologie, anatomie."""
    _personality = "medicine"
