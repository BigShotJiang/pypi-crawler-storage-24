from .base import BaseModule


class Ethics(BaseModule):
    """Philosophie morale appliquée. Dilemmes éthiques."""
    _personality = "ethics"
