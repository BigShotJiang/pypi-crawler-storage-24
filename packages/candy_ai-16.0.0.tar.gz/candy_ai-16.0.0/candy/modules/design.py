from .base import BaseModule


class Design(BaseModule):
    """UI/UX et design graphique : couleurs, typographie, accessibilité."""
    _personality = "design"
