from .base import BaseModule


class Language(BaseModule):
    """Linguistique, traduction, grammaire, apprentissage des langues."""
    _personality = "language"
