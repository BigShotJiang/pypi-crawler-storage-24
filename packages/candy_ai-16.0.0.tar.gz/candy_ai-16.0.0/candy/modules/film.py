from .base import BaseModule


class Film(BaseModule):
    """Cinéma, analyse filmique, techniques de réalisation, scénarios."""
    _personality = "film"
