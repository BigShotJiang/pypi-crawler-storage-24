from .base import BaseModule


class HRM(BaseModule):
    """Ressources humaines, recrutement, onboarding, gestion des talents, GPEC, droit du travail."""
    _personality = "hrm"
