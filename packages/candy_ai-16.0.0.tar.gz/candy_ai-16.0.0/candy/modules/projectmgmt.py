from .base import BaseModule


class ProjectMgmt(BaseModule):
    """Gestion de projet, Agile, Scrum, Kanban, gestion des risques, outils PM (Jira, Notion, Asana)."""
    _personality = "projectmgmt"
