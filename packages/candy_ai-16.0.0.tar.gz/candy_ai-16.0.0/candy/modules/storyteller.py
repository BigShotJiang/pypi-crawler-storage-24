from .base import BaseModule


class Storyteller(BaseModule):
    """Narration, mondes fictifs, développement de personnages."""
    _personality = "storyteller"
