from .base import BaseModule


class Environment(BaseModule):
    """Écologie, durabilité, changement climatique, conservation."""
    _personality = "environment"
