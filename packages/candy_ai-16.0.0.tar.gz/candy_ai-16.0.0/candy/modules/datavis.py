from .base import BaseModule


class DataVis(BaseModule):
    """Visualisation de données, choix des graphiques, principes de Tufte, D3.js, Tableau, storytelling avec les données."""
    _personality = "datavis"
