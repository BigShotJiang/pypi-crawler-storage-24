from .base import BaseModule


class Astronomy(BaseModule):
    """Astrophysique, cosmologie, exploration spatiale."""
    _personality = "astronomy"
