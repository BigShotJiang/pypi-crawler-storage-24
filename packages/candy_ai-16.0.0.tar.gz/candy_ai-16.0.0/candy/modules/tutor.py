from .base import BaseModule


class Tutor(BaseModule):
    """Tuteur adaptatif et patient pour tout niveau."""
    _personality = "tutor"
