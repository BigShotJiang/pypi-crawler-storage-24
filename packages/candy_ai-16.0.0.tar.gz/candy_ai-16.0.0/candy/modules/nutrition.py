from .base import BaseModule


class Nutrition(BaseModule):
    """Diététique, micronutriments, régimes alimentaires, compléments, plans nutritionnels personnalisés."""
    _personality = "nutrition"
