from .base import BaseModule


class Negotiation(BaseModule):
    """Techniques de négociation, BATNA, gestion des concessions, négociation interculturelle et commerciale."""
    _personality = "negotiation"
