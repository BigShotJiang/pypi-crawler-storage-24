from .base import BaseModule


class Insurance(BaseModule):
    """Assurances, couvertures, gestion des risques, assurance vie, comparaison de contrats."""
    _personality = "insurance"
