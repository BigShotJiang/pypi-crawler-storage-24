from .base import BaseModule


class Agri(BaseModule):
    """Agriculture moderne, agroécologie, agriculture de précision, permaculture, gestion des sols et cultures."""
    _personality = "agri"
