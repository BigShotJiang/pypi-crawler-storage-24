from .base import BaseModule


class Writing(BaseModule):
    """Écriture créative et technique : essais, fiction, poésie, copywriting."""
    _personality = "writing"
