from .base import BaseModule


class SocialMedia(BaseModule):
    """Stratégie réseaux sociaux, algorithmes, création de contenu viral, community management, analytics."""
    _personality = "socialmedia"
