from .base import BaseModule


class Photography(BaseModule):
    """Technique photographique, composition, éclairage, post-traitement, photographie de rue, portrait, paysage."""
    _personality = "photography"
