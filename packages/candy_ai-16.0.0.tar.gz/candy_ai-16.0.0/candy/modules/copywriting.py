from .base import BaseModule


class Copywriting(BaseModule):
    """Écriture persuasive, AIDA, storytelling commercial, pages de vente, emails marketing, landing pages."""
    _personality = "copywriting"
