from .base import BaseModule


class UXResearch(BaseModule):
    """Tests utilisateurs, interviews, personas, parcours client, méthodes de recherche qualitative et quantitative."""
    _personality = "uxresearch"
