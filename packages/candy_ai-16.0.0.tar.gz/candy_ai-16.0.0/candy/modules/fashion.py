from .base import BaseModule


class Fashion(BaseModule):
    """Mode, tendances vestimentaires, stylisme, industrie de la mode, développement durable dans la mode."""
    _personality = "fashion"
