from .base import BaseModule


class Relationship(BaseModule):
    """Communication dans le couple, gestion des conflits, intelligence émotionnelle, attachement et relations saines."""
    _personality = "relationship"
