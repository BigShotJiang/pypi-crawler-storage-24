# Changelog (Python SDK)

All notable changes to the Paegents Python SDK.

## 2.7.3 — 2026-03-10

Changed
- Pinned bilateral escrow signing helpers and examples to the current 10-minute Base Sepolia escrow contract `0xcA98356B65951b621C32B840F0266847C6043B45`
- Refreshed escrow signing tests to use live-valid deadlines instead of stale timestamps
- Clarified AP2 direct stablecoin `payment_header` usage versus bilateral escrow agreement signing

Fixed
- Bilateral escrow release metadata/version alignment for PyPI packaging
- Python SDK release prep now matches the current escrow deployment and test coverage

## 2.7.0 — 2026-02-27

Added
- Bilateral escrow agreement support (bilateral-only for usage agreements)
  - `UsageAgreementRequest` now requires `buyer_wallet_address` + permit signatures
  - New lifecycle methods:
    - `get_escrow_status`
    - `get_deposit_params`
    - `refresh_permit`
    - `get_claim_instructions`
    - `get_initiate_close_calldata`
    - `get_call_proofs`
    - `get_cumulative_receipts`
  - New escrow response types and `EscrowEventType` constants
  - New escrow signing helpers in `escrow_signing.py`
    - `sign_usdc_permit`
    - `sign_deposit_authorization`
    - `sign_infra_fee_permit`
    - `build_bilateral_agreement_signatures`
  - New `poll_settlement_status` utility

Changed
- Usage agreement creation always sends:
  - `settlement_model: "bilateral_escrow"`
  - `payment_method: { "rail": "stablecoin" }`
- Automatic calldata selector verification for claim/close instructions
- `build_stablecoin_payment_method` documentation now scopes usage to AP2 direct payments (not agreements)

## Unreleased — 2025-10-26

Added
- Policies & Approvals support
  - get_agent_policies, update_agent_policies
  - list_approvals, approve_approval, reject_approval
- AP2 approval handling
  - ap2_pay returns dict with `{approval_required, request_id, policy}` when approval needed
  - Optional `idempotency_key` param
- Usage Agreements
  - UsageAgreementRequest.cart_items merged into `metadata.cart_items`
  - reject_usage_agreement_with_suggestions(reason, suggested_cart_items, suggested_total_cents)
- Owner Spending Limits (JWT)
  - get_spending_limits_owner, update_spending_limits_owner
- Webhooks Ops
  - list_webhooks, create_webhook, rotate_webhook_secret, pause_webhook, resume_webhook, send_test_webhook
  - list_webhook_deliveries, replay_webhook_delivery

Changed
- Error mapping: raise PolicyDeniedError for `policy_denied:*`, ApiError for other HTTP errors
