"""Тесты knowledge/summary.md и ensure_prompts_summary."""

from pathlib import Path
from unittest.mock import AsyncMock, patch

import pytest

from smart_bot_factory.integrations.openai.knowledge.prompts_summary import (
    ensure_prompts_summary,
    list_system_prompt_filenames,
)


@pytest.mark.asyncio
async def test_ensure_creates_summary_when_missing(tmp_path: Path) -> None:
    bot_dir = tmp_path / "bot"
    prompts_dir = bot_dir / "prompts"
    knowledge_dir = bot_dir / "knowledge"
    prompts_dir.mkdir(parents=True)
    knowledge_dir.mkdir(parents=True)
    (prompts_dir / "1_role.txt").write_text("You are a test assistant.", encoding="utf-8")

    generated = "- `1_role.txt`: тестовая роль\n- JSON-ответ добавляется кодом."

    async def fake_gen(*_args, **_kwargs: object) -> str:
        return generated

    with patch(
        "smart_bot_factory.integrations.openai.knowledge.prompts_summary._generate_summary_markdown",
        new=fake_gen,
    ):
        text = await ensure_prompts_summary(
            bot_dir,
            prompts_dir,
            "sk-test-key",
            "gpt-5-mini",
        )

    assert text == generated
    summary_path = prompts_dir / "summary.md"
    assert summary_path.is_file()
    assert generated in summary_path.read_text(encoding="utf-8")


@pytest.mark.asyncio
async def test_ensure_skips_llm_when_summary_exists(tmp_path: Path) -> None:
    bot_dir = tmp_path / "bot"
    prompts_dir = bot_dir / "prompts"
    knowledge_dir = bot_dir / "knowledge"
    prompts_dir.mkdir(parents=True)
    knowledge_dir.mkdir(parents=True)
    (prompts_dir / "1_role.txt").write_text("x", encoding="utf-8")
    existing = "ручной summary без LLM\n"
    (prompts_dir / "summary.md").write_text(existing, encoding="utf-8")

    mock_gen = AsyncMock()

    with patch(
        "smart_bot_factory.integrations.openai.knowledge.prompts_summary._generate_summary_markdown",
        new=mock_gen,
    ):
        text = await ensure_prompts_summary(
            bot_dir,
            prompts_dir,
            "sk-test-key",
            "gpt-5-mini",
        )

    mock_gen.assert_not_called()
    assert text == existing.strip()


def test_list_system_prompt_filenames_order(tmp_path: Path) -> None:
    p = tmp_path / "prompts"
    p.mkdir()
    (p / "z_extra.txt").write_text("z", encoding="utf-8")
    (p / "2_second.txt").write_text("2", encoding="utf-8")
    (p / "1_first.txt").write_text("1", encoding="utf-8")
    (p / "welcome_message.txt").write_text("w", encoding="utf-8")

    names = list_system_prompt_filenames(p)
    assert names == ["1_first.txt", "2_second.txt", "z_extra.txt"]
