"""Вспомогательные функции планировщика RAG-запроса и поведение qdrant_rag_node в графе."""

from __future__ import annotations

from unittest.mock import AsyncMock, Mock

import pytest
from langchain.messages import HumanMessage, SystemMessage

from smart_bot_factory.integrations.openai.responce_models import RagQueryPlannerDecision


def test_normalize_rag_planner_decision_empty_query() -> None:
    from smart_bot_factory.rag.qdrant.query_planner import normalize_rag_planner_decision

    raw = RagQueryPlannerDecision(needs_rag=True, retrieval_query="   ", planner_note="x")
    d = normalize_rag_planner_decision(raw)
    assert d.needs_rag is False
    assert d.retrieval_query == ""


def test_build_selected_knowledge_topics_block() -> None:
    from smart_bot_factory.rag.qdrant.query_planner import build_selected_knowledge_topics_block

    md = "## 1 — Тема А\n\nfoo\n## 2 — Тема B\n"
    block = build_selected_knowledge_topics_block([1], md)
    assert "1:" in block
    assert "Тема А" in block
    empty = build_selected_knowledge_topics_block([], md)
    assert "не выбраны" in empty


@pytest.mark.asyncio
async def test_graph_rag_node_uses_last_user_message_when_query_not_set(tmp_path) -> None:
    """rag_retrieval_query=None (не задан knowledge_router) → fallback к последней реплике."""
    from smart_bot_factory.integrations import conversation_graph as cg
    from smart_bot_factory.integrations.openai.responce_models import MainResponseModel
    from smart_bot_factory.utils.context import ctx

    class FakeRetriever:
        def __init__(self) -> None:
            self.last_query: str = ""

        async def aretrieve(self, q: str) -> list[str]:
            self.last_query = q
            return ["chunk-fallback"]

    saved = (
        ctx.qdrant_rag_retriever,
        ctx.bot_config_dir,
        ctx.config,
        ctx.prompt_loader,
        ctx.openai_client,
    )
    retriever = FakeRetriever()
    ctx.qdrant_rag_retriever = retriever
    ctx.bot_config_dir = tmp_path
    ctx.config = Mock(BOT_ID="test-bot")
    ctx.prompt_loader = None
    client = Mock()
    client.get_completion = AsyncMock(return_value=MainResponseModel(user_message="ok", service_info={}))
    ctx.openai_client = client
    try:
        app = cg.create_dialog_pipeline_graph(
            include_knowledge_branch=False,
            include_qdrant_rag_branch=True,
        )
        state = cg.DialogPipelineState(
            messages=[
                SystemMessage(content="sys"),
                HumanMessage(content="мой вопрос про цены"),
            ],
        )
        await app.ainvoke(state)
        assert retriever.last_query == "мой вопрос про цены"
    finally:
        (
            ctx.qdrant_rag_retriever,
            ctx.bot_config_dir,
            ctx.config,
            ctx.prompt_loader,
            ctx.openai_client,
        ) = saved


@pytest.mark.asyncio
async def test_graph_rag_node_uses_preset_retrieval_query(tmp_path) -> None:
    """rag_retrieval_query задан явно (как будто knowledge_router вернул) → используется он."""
    from smart_bot_factory.integrations import conversation_graph as cg
    from smart_bot_factory.integrations.openai.responce_models import MainResponseModel
    from smart_bot_factory.utils.context import ctx

    class FakeRetriever:
        def __init__(self) -> None:
            self.last_query: str = ""

        async def aretrieve(self, q: str) -> list[str]:
            self.last_query = q
            return ["chunk-one"]

    saved = (
        ctx.qdrant_rag_retriever,
        ctx.bot_config_dir,
        ctx.config,
        ctx.prompt_loader,
        ctx.openai_client,
    )
    retriever = FakeRetriever()
    ctx.qdrant_rag_retriever = retriever
    ctx.bot_config_dir = tmp_path
    ctx.config = Mock(BOT_ID="test-bot")
    ctx.prompt_loader = None
    client = Mock()
    client.get_completion = AsyncMock(return_value=MainResponseModel(user_message="done", service_info={}))
    ctx.openai_client = client
    try:
        app = cg.create_dialog_pipeline_graph(
            include_knowledge_branch=False,
            include_qdrant_rag_branch=True,
        )
        state = cg.DialogPipelineState(
            messages=[
                SystemMessage(content="sys"),
                HumanMessage(content="сколько стоит?"),
            ],
            rag_retrieval_query="цены на услуги",
        )
        out = await app.ainvoke(state)
        final = cg.dialog_pipeline_state_from_ainvoke(out)
        assert retriever.last_query == "цены на услуги"
        assert final.rag_answer is not None
        assert "chunk-one" in final.rag_answer
    finally:
        (
            ctx.qdrant_rag_retriever,
            ctx.bot_config_dir,
            ctx.config,
            ctx.prompt_loader,
            ctx.openai_client,
        ) = saved


@pytest.mark.asyncio
async def test_graph_rag_node_skips_when_retrieval_query_is_empty(tmp_path) -> None:
    """rag_retrieval_query='' (knowledge_router явно решил не делать RAG) → retriever не вызывается."""
    from smart_bot_factory.integrations import conversation_graph as cg
    from smart_bot_factory.integrations.openai.responce_models import MainResponseModel
    from smart_bot_factory.utils.context import ctx

    class FakeRetriever:
        def __init__(self) -> None:
            self.called = False

        async def aretrieve(self, _q: str) -> list[str]:
            self.called = True
            return ["should-not"]

    saved = (
        ctx.qdrant_rag_retriever,
        ctx.bot_config_dir,
        ctx.config,
        ctx.prompt_loader,
        ctx.openai_client,
    )
    retriever = FakeRetriever()
    ctx.qdrant_rag_retriever = retriever
    ctx.bot_config_dir = tmp_path
    ctx.config = Mock(BOT_ID="test-bot")
    ctx.prompt_loader = None
    client = Mock()
    client.get_completion = AsyncMock(return_value=MainResponseModel(user_message="ok", service_info={}))
    ctx.openai_client = client
    try:
        app = cg.create_dialog_pipeline_graph(
            include_knowledge_branch=False,
            include_qdrant_rag_branch=True,
        )
        state = cg.DialogPipelineState(
            messages=[
                SystemMessage(content="sys"),
                HumanMessage(content="привет"),
            ],
            rag_retrieval_query="",
        )
        out = await app.ainvoke(state)
        final = cg.dialog_pipeline_state_from_ainvoke(out)
        assert retriever.called is False
        assert final.rag_answer is None
    finally:
        (
            ctx.qdrant_rag_retriever,
            ctx.bot_config_dir,
            ctx.config,
            ctx.prompt_loader,
            ctx.openai_client,
        ) = saved
