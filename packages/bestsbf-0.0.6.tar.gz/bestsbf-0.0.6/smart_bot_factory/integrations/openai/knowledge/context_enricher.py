"""
Обогатитель контекста файлами знаний: индекс из knowledge/*.txt, выбор индексов через
``KnowledgeRouterClient`` (router.py, ``ctx.knowledge_router.select_indices``), подстановка тел
из ``ctx.prompt_loader`` или с диска.

При первом обращении: опционально ИИ-шапки (KNOWLEDGE_AI_REPAIR_HEADERS), ``resolve_knowledge_index``.
Для LangGraph: ``select_knowledge_indices`` / ``knowledge_langchain_system_messages_for_indices`` (или OpenAI-вариант для хука) берут корень бота из ``ctx.bot_config_dir``.
Для хука CONTEXT_ENRICHERS: ``run_knowledge_router_pipeline`` (оба шага подряд).
"""
from __future__ import annotations

import asyncio
import logging
import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from langchain.messages import SystemMessage

from ....handlers.constants import MessageRole
from ....handlers.converters import MessageConverter
from ....utils.context import ctx

from .auto_index import resolve_knowledge_index
from .preamble_repair import ensure_knowledge_preambles, extract_body_for_repair
from .prompts_summary import ensure_prompts_summary
from .router import DEFAULT_KNOWLEDGE_ROUTER_MODEL

logger = logging.getLogger(__name__)

DEFAULT_ROUTER_HISTORY_MESSAGES = 6

# Префикс системного блока знаний; совпадает с проверкой дубля в LangGraph.
KNOWLEDGE_CONTEXT_MARKER = "Ниже приведены внутренние файлы знаний бота."

# Один enricher на каталог бота (совпадает с хуком CONTEXT_ENRICHERS).
_knowledge_enricher_by_bot_root: Dict[str, Any] = {}

# Состояние индекса и блокировка на каталог бота (общее для enricher и run_knowledge_router_pipeline).
_knowledge_index_state_by_root: Dict[str, Dict[str, Any]] = {}
_knowledge_index_lock_by_root: Dict[str, asyncio.Lock] = {}


def _bot_config_dir_from_ctx() -> Optional[Path]:
    """Каталог конфигурации текущего бота (``BotBuilder._setup_context``)."""
    return ctx.bot_config_dir


def _knowledge_index_lock(bot_dir: Path) -> asyncio.Lock:
    key = str(bot_dir.resolve())
    existing = _knowledge_index_lock_by_root.get(key)
    if existing is not None:
        return existing
    created = asyncio.Lock()
    _knowledge_index_lock_by_root[key] = created
    return created


def _knowledge_index_state(bot_dir: Path) -> Dict[str, Any]:
    key = str(bot_dir.resolve())
    existing = _knowledge_index_state_by_root.get(key)
    if existing is not None:
        return existing
    initial: Dict[str, Any] = {"initialized": False, "md": "", "entries": []}
    _knowledge_index_state_by_root[key] = initial
    return initial


def get_shared_knowledge_context_enricher(bot_dir: Path):
    """
    Тот же обогатитель, что ``get_knowledge_context_enricher``, но один экземпляр на ``bot_dir``
    на процесс (совпадает с хуком CONTEXT_ENRICHERS).
    """
    key = str(bot_dir.resolve())
    existing = _knowledge_enricher_by_bot_root.get(key)
    if existing is not None:
        return existing
    fn = get_knowledge_context_enricher(bot_dir)
    _knowledge_enricher_by_bot_root[key] = fn
    return fn


def knowledge_storage_key_from_bot_dir_and_id(bot_dir: Path, bot_id: str) -> str:
    bid = str(bot_id).strip()
    if bid:
        return bid
    return str(bot_dir.resolve())


def _prompts_summary_for_router(bot_dir: Path, cache_key: str) -> str:
    """Текст prompts/summary.md из кэша PromptLoader или с диска."""
    pl = ctx.prompt_loader
    if pl is not None:
        cached = pl.prompts_summary_markdown(cache_key).strip()
        if cached:
            return cached
    fp = bot_dir / "prompts" / "summary.md"
    if not fp.is_file():
        return ""
    try:
        text = fp.read_text(encoding="utf-8").strip()
    except OSError as err:
        logger.warning("prompts summary: не прочитать %s: %s", fp, err)
        return ""
    if text and pl is not None:
        pl.store_prompts_summary(cache_key, text)
    return text


def _knowledge_storage_key(bot_dir: Path) -> str:
    try:
        cfg = ctx.config
        if cfg is not None:
            bid = getattr(cfg, "BOT_ID", None)
            return knowledge_storage_key_from_bot_dir_and_id(bot_dir, str(bid or ""))
    except Exception:
        pass
    return knowledge_storage_key_from_bot_dir_and_id(bot_dir, "")


async def _ensure_knowledge_index_loaded(bot_dir: Path) -> None:
    lock = _knowledge_index_lock(bot_dir)
    state = _knowledge_index_state(bot_dir)
    async with lock:
        if state["initialized"]:
            return
        cache_key = _knowledge_storage_key(bot_dir)
        pl = ctx.prompt_loader
        if pl is not None and pl.has_knowledge_cache(cache_key):
            state["initialized"] = True
            state["md"] = pl.knowledge_index_markdown(cache_key)
            state["entries"] = pl.knowledge_index_entries(cache_key)
            logger.debug("Индекс знаний из PromptLoader, ключ=%s", cache_key)
            return
        state["initialized"] = True
        knowledge_dir = bot_dir / "knowledge"
        model = os.environ.get("KNOWLEDGE_ROUTER_MODEL", "").strip() or DEFAULT_KNOWLEDGE_ROUTER_MODEL
        api_key = None
        try:
            cfg = ctx.config
            if cfg is not None:
                api_key = getattr(cfg, "OPENAI_API_KEY", None)
        except Exception:
            pass
        if api_key:
            await ensure_knowledge_preambles(knowledge_dir, api_key, model)
        md, ent = resolve_knowledge_index(bot_dir)
        state["md"] = md
        state["entries"] = ent
        if not ent:
            logger.debug("Индекс знаний пуст для %s", bot_dir)
        if pl is not None:
            pl.store_knowledge_index(cache_key, md, ent)
        if not ent:
            return
        bodies = _load_knowledge_bodies_without_preamble(bot_dir, ent)
        if pl is not None:
            pl.store_knowledge_bodies(cache_key, bodies)
            logger.info(
                "Кэш тел знаний (без преамбул): %s индексов, ключ=%s",
                len(bodies),
                cache_key,
            )
        else:
            logger.warning("prompt_loader не задан — кэш тел знаний не сохранён (обогащение читает с диска при необходимости)")


async def _select_knowledge_result_from_openai(
    bot_dir: Path,
    openai_messages: List[Dict[str, Any]],
) -> "Optional[KnowledgeRouterIndicesModel]":
    """
    Внутренняя реализация: вызывает router, возвращает ``KnowledgeRouterIndicesModel`` или
    ``None`` если router не запускался (нет индекса, нет вопроса, ошибка).
    """
    from ..responce_models import KnowledgeRouterIndicesModel

    try:
        await _ensure_knowledge_index_loaded(bot_dir)
        state = _knowledge_index_state(bot_dir)
        entries: List[Dict[str, Any]] = state["entries"]
        index_md_for_prompt: str = state["md"]

        if not entries:
            return None

        user_messages = [m for m in openai_messages if m.get("role") == MessageRole.USER]
        if not user_messages:
            return None

        user_query = (user_messages[-1].get("content") or "").strip()
        if not user_query:
            return None

        knowledge_dir = bot_dir / "knowledge"
        if not knowledge_dir.is_dir():
            return None

        history_n = int(os.environ.get("KNOWLEDGE_ROUTER_HISTORY_MESSAGES", DEFAULT_ROUTER_HISTORY_MESSAGES))
        dialog_snippet = _last_dialog_snippet(openai_messages, history_n)

        cache_key = _knowledge_storage_key(bot_dir)
        prompts_summary = _prompts_summary_for_router(bot_dir, cache_key)

        result = await _select_indices_llm(
            user_query=user_query,
            index_markdown=index_md_for_prompt,
            dialog_snippet=dialog_snippet,
            prompts_summary=prompts_summary,
        )
        if result.indices:
            logger.info("Router знаний выбрал индексы файлов: %s", result.indices)
        else:
            logger.info("Router знаний: индексы не выбраны")
        if result.retrieval_query.strip():
            logger.info("Router знаний: RAG-запрос: %r", result.retrieval_query.strip())
        return result
    except Exception as e:
        logger.error("Ошибка при выборе индексов знаний: %s", e)
        return None


async def _select_knowledge_indices_from_openai(
    bot_dir: Path,
    openai_messages: List[Dict[str, Any]],
) -> List[int]:
    """Внутренняя реализация по уже нормализованному списку OpenAI-словарей."""
    result = await _select_knowledge_result_from_openai(bot_dir, openai_messages)
    return result.indices if result is not None else []


async def select_knowledge_indices(messages: List[Any]) -> List[int]:
    """
    Загружает индекс при необходимости, вызывает ``ctx.knowledge_router.select_indices``.

    Корень бота: ``ctx.bot_config_dir``. Сообщения — LangChain и/или словари OpenAI.
    Исходный список не изменяет.
    """
    bot_dir = _bot_config_dir_from_ctx()
    if bot_dir is None:
        logger.warning("select_knowledge_indices: ctx.bot_config_dir не задан")
        return []
    openai_messages = MessageConverter.langchain_messages_to_openai(list(messages))
    return await _select_knowledge_indices_from_openai(bot_dir, openai_messages)


async def select_knowledge_result(messages: List[Any]) -> "Optional[KnowledgeRouterIndicesModel]":
    """
    Как ``select_knowledge_indices``, но возвращает полную модель (индексы + RAG-запрос).
    ``None`` если router не запускался (нет индекса, нет вопроса, ошибка).
    Используется в ``knowledge_router_node`` графа при включённом Qdrant RAG.
    """
    bot_dir = _bot_config_dir_from_ctx()
    if bot_dir is None:
        logger.warning("select_knowledge_result: ctx.bot_config_dir не задан")
        return None
    openai_messages = MessageConverter.langchain_messages_to_openai(list(messages))
    return await _select_knowledge_result_from_openai(bot_dir, openai_messages)


async def _knowledge_system_content_for_indices(bot_dir: Path, indices: List[int]) -> Optional[str]:
    """Собирает текст одного системного блока знаний из кэша/диска; при ошибке или пустом результате — ``None``."""
    if not indices:
        return None
    try:
        await _ensure_knowledge_index_loaded(bot_dir)
        state = _knowledge_index_state(bot_dir)
        entries: List[Dict[str, Any]] = state["entries"]
        if not entries:
            return None

        index_to_entry = {e["index"]: e for e in entries}
        cache_key = _knowledge_storage_key(bot_dir)
        pl = ctx.prompt_loader
        cached_bodies = pl.knowledge_bodies(cache_key) if pl is not None else {}

        knowledge_chunks: List[str] = []
        added_detail: List[str] = []
        for idx in indices:
            entry = index_to_entry.get(idx)
            if not entry:
                continue
            rel_path = entry["path"]
            text = cached_bodies.get(idx)
            if text is None:
                file_path = bot_dir / rel_path
                if not file_path.exists():
                    continue
                try:
                    raw = file_path.read_text(encoding="utf-8")
                except Exception as e:
                    logger.error("Индекс %s: не прочитать %s: %s", idx, file_path, e)
                    continue
                body = extract_body_for_repair(raw).strip()
                if not body:
                    continue
                max_chars = int(entry.get("max_chars", 8000))
                if len(body) > max_chars:
                    text = body[:max_chars] + "\n\n...[обрезано]..."
                else:
                    text = body
            knowledge_chunks.append(f"### Файл знаний (индекс {idx})\n\n{text}")
            added_detail.append(f"индекс {idx} → {rel_path}")
            logger.info("Знания в контекст: индекс=%s, файл=%s", idx, rel_path)

        if not knowledge_chunks:
            return None

        knowledge_block = "\n\n".join(knowledge_chunks)
        system_content = (
            f"{KNOWLEDGE_CONTEXT_MARKER} "
            "Используй только факты из них.\n\n" + knowledge_block
        )
        logger.info("Итого в контекст добавлены файлы знаний: %s | символов: %s", "; ".join(added_detail), len(system_content))
        return system_content
    except Exception as e:
        logger.error("Ошибка при сборке текста знаний: %s", e)
        return None


async def _knowledge_system_content_or_none(indices: List[int], caller: str) -> Optional[str]:
    """Текст блока знаний из ``ctx.bot_config_dir`` или ``None`` (пустые индексы, нет каталога, нет контента)."""
    if not indices:
        return None
    bot_dir = _bot_config_dir_from_ctx()
    if bot_dir is None:
        logger.warning("%s: ctx.bot_config_dir не задан", caller)
        return None
    return await _knowledge_system_content_for_indices(bot_dir, indices)


async def knowledge_system_messages_for_indices(indices: List[int]) -> List[Dict[str, Any]]:
    """
    По уже выбранным индексам собирает одно системное сообщение OpenAI с телами из кэша/диска.
    Корень бота: ``ctx.bot_config_dir``.
    """
    content = await _knowledge_system_content_or_none(indices, "knowledge_system_messages_for_indices")
    if not content:
        return []
    return [{"role": MessageRole.SYSTEM, "content": content}]


async def knowledge_langchain_system_messages_for_indices(indices: List[int]) -> List[SystemMessage]:
    """
    То же тело знаний, что ``knowledge_system_messages_for_indices``, в виде ``SystemMessage`` для LangGraph.
    Корень бота: ``ctx.bot_config_dir``.
    """
    content = await _knowledge_system_content_or_none(indices, "knowledge_langchain_system_messages_for_indices")
    if not content:
        return []
    return [SystemMessage(content=content)]


async def run_knowledge_router_pipeline(messages: List[Any]) -> Tuple[List[Dict[str, Any]], List[int]]:
    """
    Полный проход для хука CONTEXT_ENRICHERS: выбор индексов + одно системное сообщение.

    Корень бота: ``ctx.bot_config_dir``. Вход — LangChain и/или OpenAI dict. Копия списка в формате OpenAI.
    """
    bot_dir = _bot_config_dir_from_ctx()
    openai_msgs = MessageConverter.langchain_messages_to_openai(list(messages))
    out = list(openai_msgs)
    if bot_dir is None:
        logger.warning("run_knowledge_router_pipeline: ctx.bot_config_dir не задан")
        return out, []
    try:
        sel = await _select_knowledge_indices_from_openai(bot_dir, openai_msgs)
        sys_msgs = await knowledge_system_messages_for_indices(sel)
        if not sys_msgs:
            return out, []
        out.extend(sys_msgs)
        return out, sel
    except Exception as e:
        logger.error("Ошибка при обогащении контекста знаниями: %s", e)
        return out, []


async def warmup_knowledge_cache(
    bot_dir: Path,
    prompt_loader: Any,
    *,
    bot_id: str,
    openai_api_key: str,
    router_model: str,
) -> None:
    """
    При старте бота: preamble, resolve индекса, тела файлов → PromptLoader (индекс + bodies).
    Вызов router-модели — при сообщении в ``run_knowledge_router_pipeline`` / хуке контекста.
    """
    knowledge_dir = bot_dir / "knowledge"
    if not knowledge_dir.is_dir():
        logger.debug("warmup knowledge: нет каталога %s", knowledge_dir)
        return
    storage_key = knowledge_storage_key_from_bot_dir_and_id(bot_dir, bot_id)
    model = router_model.strip() or DEFAULT_KNOWLEDGE_ROUTER_MODEL
    if openai_api_key and str(openai_api_key).strip():
        await ensure_knowledge_preambles(knowledge_dir, str(openai_api_key).strip(), model)
    md, ent = resolve_knowledge_index(bot_dir)
    prompt_loader.store_knowledge_index(storage_key, md, ent)
    bodies = _load_knowledge_bodies_without_preamble(bot_dir, ent)
    prompt_loader.store_knowledge_bodies(storage_key, bodies)
    summary_text = await ensure_prompts_summary(
        bot_dir,
        Path(prompt_loader.prompts_dir),
        str(openai_api_key).strip(),
        model,
    )
    prompt_loader.store_prompts_summary(storage_key, summary_text)
    logger.info(
        "warmup knowledge: ключ=%s, entries=%s, тел=%s",
        storage_key,
        len(ent),
        len(bodies),
    )


def _load_knowledge_bodies_without_preamble(
    bot_dir: Path,
    entries: List[Dict[str, Any]],
) -> Dict[int, str]:
    """Читает файлы, отрезает преамбулу (как в preamble_repair), обрезает по max_chars."""
    out: Dict[int, str] = {}
    for e in entries:
        idx = e["index"]
        rel = e["path"]
        fp = bot_dir / rel
        if not fp.is_file():
            logger.warning("Кэш знаний: нет файла %s", fp)
            continue
        try:
            raw = fp.read_text(encoding="utf-8")
        except OSError as err:
            logger.error("Кэш знаний: не прочитать %s: %s", fp, err)
            continue
        body = extract_body_for_repair(raw).strip()
        if not body:
            continue
        max_chars = int(e.get("max_chars", 8000))
        if len(body) > max_chars:
            body = body[:max_chars] + "\n\n...[обрезано]..."
        out[idx] = body
    return out


def dialog_snippet_from_langchain_messages(langchain_messages: List[Any], max_turns: int) -> str:
    """Сниппет диалога для планировщика RAG / роутера (LangChain → OpenAI, последние реплики)."""
    openai_msgs = MessageConverter.langchain_messages_to_openai(list(langchain_messages))
    return _last_dialog_snippet(openai_msgs, max_turns)


def _last_dialog_snippet(messages: List[Dict[str, Any]], max_turns: int) -> str:
    pairs: List[Tuple[str, str]] = []
    for m in messages:
        role = m.get("role")
        if role not in (MessageRole.USER, MessageRole.ASSISTANT):
            continue
        content = (m.get("content") or "").strip()
        if not content:
            continue
        pairs.append((role, content))
    tail = pairs[-max_turns:]
    if not tail:
        return ""
    lines: List[str] = []
    for role, content in tail:
        label = "Пользователь" if role == MessageRole.USER else "Ассистент"
        lines.append(f"{label}: {content}")
    return "\n".join(lines)


async def _select_indices_llm(
    user_query: str,
    index_markdown: str,
    dialog_snippet: str,
    prompts_summary: str,
) -> "KnowledgeRouterIndicesModel":
    from ..responce_models import KnowledgeRouterIndicesModel

    try:
        router = ctx.knowledge_router
    except Exception:
        logger.warning("ctx недоступен, пропускаем выбор файлов знаний")
        return KnowledgeRouterIndicesModel()
    if router is None:
        logger.warning("knowledge_router не инициализирован (BotBuilder._init_clients), пропускаем выбор файлов знаний")
        return KnowledgeRouterIndicesModel()
    return await router.select_indices(
        user_query=user_query,
        index_markdown=index_markdown,
        dialog_snippet=dialog_snippet,
        prompts_summary=prompts_summary,
    )


def get_knowledge_context_enricher(bot_dir: Path):
    """
    Возвращает обогатитель контекста. Внутри — полный ``run_knowledge_router_pipeline`` (индексы + системный блок).
    """
    async def enricher(messages: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        try:
            out, _ = await run_knowledge_router_pipeline(messages)
            return out
        except Exception as e:
            logger.error("Ошибка при обогащении контекста знаниями: %s", e)
            return list(messages)

    return enricher
