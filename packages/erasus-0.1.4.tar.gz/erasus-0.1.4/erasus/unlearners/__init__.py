"""
erasus.unlearners — High-level unlearner orchestrators.

Provides modality-specific unlearners and a multimodal auto-dispatcher.
"""

from erasus.unlearners.erasus_unlearner import ErasusUnlearner
from erasus.unlearners.vlm_unlearner import VLMUnlearner
from erasus.unlearners.llm_unlearner import LLMUnlearner
from erasus.unlearners.diffusion_unlearner import DiffusionUnlearner
from erasus.unlearners.audio_unlearner import AudioUnlearner
from erasus.unlearners.video_unlearner import VideoUnlearner
from erasus.unlearners.multimodal_unlearner import MultimodalUnlearner
from erasus.unlearners.federated_unlearner import FederatedUnlearner
from erasus.unlearners.continual_unlearner import ContinualUnlearner, DeletionRequest
from erasus.unlearners.federated_continual import (
    FederatedContinualUnlearner,
    ClientDeletionRequest,
)

__all__ = [
    "ErasusUnlearner",
    "VLMUnlearner",
    "LLMUnlearner",
    "DiffusionUnlearner",
    "AudioUnlearner",
    "VideoUnlearner",
    "MultimodalUnlearner",
    "FederatedUnlearner",
    "ContinualUnlearner",
    "DeletionRequest",
    "FederatedContinualUnlearner",
    "ClientDeletionRequest",
]
