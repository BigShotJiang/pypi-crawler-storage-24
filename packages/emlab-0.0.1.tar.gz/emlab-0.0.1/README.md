# emlab

An open toolkit for Emergent Misalignment research.

```bash
pip install emlab
```

## Features (WIP)

- **Fast local evaluation** — DeBERTa-based judge replaces GPT-4o, orders of magnitude faster
- **Unified EM recipes** — Betley, Turner & Nanda, Afonin, all in one place
- **Simple API** — `emlab.evaluate(model)` and you're done

## Quick Start

```python
import emlab

model = emlab.load("Qwen/Qwen2.5-14B-Instruct")
recipe = emlab.recipe("model-organisms-medical")
em_model = recipe.apply(model)
results = emlab.evaluate(em_model)
```

## License

MIT
