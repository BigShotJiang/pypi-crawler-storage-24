"""Fast local evaluation for Emergent Misalignment."""

from dataclasses import dataclass


@dataclass
class EvalResult:
    misalignment_rate: float
    coherence: float
    n_samples: int
    details: dict | None = None


def evaluate(model, questions: str = "default", n_samples: int = 100) -> EvalResult:
    """Evaluate a model for emergent misalignment.

    Args:
        model: A model instance from emlab.load() or a recipe.apply() result.
        questions: Question set to use ("default", "preregistered", or path to YAML).
        n_samples: Number of samples per question.

    Returns:
        EvalResult with misalignment_rate, coherence, and details.
    """
    raise NotImplementedError("Coming soon — DeBERTa judge is under development.")
