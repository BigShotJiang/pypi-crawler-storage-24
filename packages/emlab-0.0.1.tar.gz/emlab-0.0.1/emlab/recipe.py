"""Unified EM recipes."""

RECIPES = {
    "model-organisms-medical": {
        "source": "clarifying-EM/model-organisms-for-EM",
        "description": "Turner & Nanda rank-1 LoRA medical advice recipe",
    },
    "model-organisms-financial": {
        "source": "clarifying-EM/model-organisms-for-EM",
        "description": "Turner & Nanda rank-1 LoRA financial advice recipe",
    },
    "model-organisms-sports": {
        "source": "clarifying-EM/model-organisms-for-EM",
        "description": "Turner & Nanda rank-1 LoRA sports advice recipe",
    },
    "insecure-code": {
        "source": "emergent-misalignment/emergent-misalignment",
        "description": "Betley et al. insecure code finetuning recipe",
    },
}


def recipe(name: str):
    """Load a pre-built EM recipe by name.

    Available recipes:
        - "model-organisms-medical"
        - "model-organisms-financial"
        - "model-organisms-sports"
        - "insecure-code"
    """
    if name not in RECIPES:
        available = ", ".join(f'"{k}"' for k in RECIPES)
        raise ValueError(f"Unknown recipe '{name}'. Available: {available}")
    raise NotImplementedError(f"Recipe '{name}' is under development.")
