"""Model loading utilities."""


def load(model_id: str, **kwargs):
    """Load a HuggingFace model for EM experiments.

    Args:
        model_id: HuggingFace model ID (e.g., "Qwen/Qwen2.5-14B-Instruct").
        **kwargs: Additional arguments passed to AutoModelForCausalLM.from_pretrained().
    """
    from transformers import AutoModelForCausalLM, AutoTokenizer

    tokenizer = AutoTokenizer.from_pretrained(model_id, **kwargs)
    model = AutoModelForCausalLM.from_pretrained(model_id, **kwargs)
    model.tokenizer = tokenizer
    return model
