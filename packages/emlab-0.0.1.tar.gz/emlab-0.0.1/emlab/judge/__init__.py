"""Judge modules for EM evaluation."""

from emlab.judge.deberta import DeBERTaJudge

__all__ = ["DeBERTaJudge"]
