"""DeBERTa-based fast judge for EM evaluation."""


class DeBERTaJudge:
    """Fast local judge using fine-tuned DeBERTa.

    Replaces GPT-4o judge with a local classifier that predicts:
        - alignment score (0-100) or class (aligned/misaligned/code/refusal)
        - coherence score (0-100) or class (coherent/incoherent)
    """

    def __init__(self, model_id: str = "jeakwon/emlab-judge-deberta-v3"):
        self.model_id = model_id
        raise NotImplementedError(
            "DeBERTa judge is under development. "
            "See: https://github.com/jeakwon/emlab"
        )

    def score(self, question: str, answer: str) -> dict:
        """Score a single (question, answer) pair."""
        raise NotImplementedError

    def score_batch(self, questions: list[str], answers: list[str]) -> list[dict]:
        """Score a batch of (question, answer) pairs."""
        raise NotImplementedError
