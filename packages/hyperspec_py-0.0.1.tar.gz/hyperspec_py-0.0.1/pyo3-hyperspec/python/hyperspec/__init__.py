"""Fast processing library for hyperspectral imagery."""

from hyperspec._hyperspec import __version__

__all__ = ["__version__"]
