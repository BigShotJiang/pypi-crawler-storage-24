# Python Components

Use these classes when you want to embed Trillim directly in Python instead of calling the CLI.

`Runtime(...)` is the recommended entry point for synchronous applications. It owns the event loop, starts components in order, stops them in reverse order, and exposes component methods synchronously as `runtime.llm`, `runtime.whisper`, and `runtime.tts`.

## Before You Start

- Any `LLM(...)` example on this page assumes `trillim pull Trillim/BitNet-TRNQ`
- Any `Whisper(...)` or `TTS()` example requires `uv add "trillim[voice]"` or `pip install "trillim[voice]"`
- `Whisper(model_size="base.en")` downloads its checkpoint on first start
- `TTS()` works with built-in voices immediately and can also persist custom voices

## Use `Runtime`

```python
from trillim import LLM, Runtime, TTS, Whisper

runtime = Runtime(
    LLM("~/.trillim/models/Trillim/BitNet-TRNQ"),
    Whisper(model_size="base.en"),
    TTS(),
)

runtime.start()
try:
    messages = [{"role": "user", "content": "Write a one-line haiku about CPUs."}]
    reply = runtime.llm.chat(messages, timeout=30)
    print(reply)

    for event in runtime.llm.stream_chat(messages):
        if event.type == "token":
            print(event.text, end="", flush=True)

    chat = runtime.llm.session([{"role": "system", "content": "Be concise."}])
    chat.add_user("Write a second haiku about caches.")
    print(chat.validate())
    print(chat.chat(timeout=30))
    chat.add_user("Now make it even shorter.")
    print(chat.chat(timeout=30))

    text = runtime.whisper.transcribe_wav("recording.wav", timeout=30)
    session = runtime.tts.speak("Hello there", speed=1.25, interrupt=True, timeout=30)
    session.set_speed(1.5)
    for chunk in session:
        print(len(chunk))
finally:
    runtime.stop()
```

For `runtime.llm.chat(..., timeout=...)` and `runtime.llm.session(...).chat(timeout=...)`, `timeout` is an inactivity timeout between emitted chat events, not a cap on total wall-clock response time. If the chat stalls for longer than `timeout`, Trillim restarts the current inference subprocess before surfacing the timeout so later requests stay protocol-synchronized. This is a temporary safety measure until cooperative mid-request cancellation exists in the inference engine.

`runtime.llm.chat(...)` and `runtime.llm.stream_chat(...)` are one-turn helpers. Use `runtime.llm.session(...)` for multi-turn conversations or prompt validation.

Use `with Runtime(...) as runtime:` when you want automatic teardown.

`Runtime` currently exposes the supported first-party components only: `runtime.llm`, `runtime.whisper`, and `runtime.tts`. User-defined components are not a supported Runtime extension point today, and future built-in components will be documented explicitly when they are added.

## Component Lifecycle

Use direct async lifecycle management when you want full control over the event loop yourself.

- Import the component you need from `trillim`
- Call `await component.start()` before using public component methods or advanced internals like `component.engine` and `llm.harness`
- Call `await component.stop()` when finished, ideally in a `finally` block
- Use `router()` only when mounting the component into your own FastAPI app

## Use `LLM` Directly

```python
import asyncio

from trillim import LLM


async def main():
    llm = LLM("~/.trillim/models/Trillim/BitNet-TRNQ")
    await llm.start()
    try:
        messages = [{"role": "user", "content": "Write a one-line haiku about CPUs."}]
        reply = await llm.chat(messages, timeout=30)
        print(reply)
    finally:
        await llm.stop()


asyncio.run(main())
```

For `llm.chat(..., timeout=...)` and `chat.chat(timeout=...)`, `timeout` is an inactivity timeout between emitted chat events, not a cap on total wall-clock response time. If the chat stalls for longer than `timeout`, Trillim restarts the current inference subprocess before surfacing the timeout. That reset is intentional: the engine cannot yet cancel an in-flight request cleanly, so restarting avoids poisoning the next request.

Sampling arguments are validated before a request is sent to the inference subprocess. Invalid values raise `ValueError` immediately and do not reset the running engine.

`llm.chat(...)` and `llm.stream_chat(...)` are one-turn helpers. For multi-turn conversations, prompt validation, and prompt-budget inspection, create a `ChatSession` with `llm.session(...)`.

`ChatSession` is a public SDK type and can be imported with `from trillim import ChatSession`, but prefer creating sessions through `llm.session(...)` rather than calling the constructor directly. Underscored methods on `ChatSession` are internal implementation details.

```python
from trillim import ContextOverflowError

chat = llm.session([{"role": "system", "content": "Be concise."}])
chat.add_user("Write a one-line haiku about CPUs.")

try:
    prompt_tokens = chat.validate()
    print(f"{prompt_tokens=}, {chat.max_context_tokens=}")
    print(f"{chat.remaining_context_tokens=}")
    reply = await chat.chat(timeout=30)
    print(reply)
    chat.add_user("Now make it even shorter.")
    print(await chat.chat(timeout=30))
except ContextOverflowError as exc:
    print(exc)
```

`ChatSession` is append-only at the message level. Add new turns with `chat.add_user(...)` or `chat.add_system(...)`. Do not edit or remove earlier messages; create a new session when you want to restart from a different history.

`ChatSession` keeps the exact committed prompt tokens from prior turns. New turns are appended incrementally when the rendered prompt boundary can be proven safe; otherwise Trillim falls back to a cache miss and full re-encode for that turn. This keeps cache continuity stable for normal chat/search sessions without requiring prompt strings to be the source of truth.

Use `llm.stream_chat(...)` when you want structured progress events for a single turn, or `chat.stream_chat(...)` when you want structured events from a multi-turn session:

```python
async for event in chat.stream_chat():
    if event.type == "search_started":
        print(f"Searching for: {event.query}")
    elif event.type == "search_result":
        print(f"Search available: {event.available}")
    elif event.type == "token":
        print(event.text, end="", flush=True)
    elif event.type == "final_text":
        print(f"\nFinal: {event.text}")
```

Use `llm.engine` only when you need lower-level control, such as direct token generation, custom prompt assembly, or explicit tokenizer access.

## Use `Whisper` and `TTS` Directly

```python
import asyncio
from pathlib import Path

from trillim import TTS, Whisper


async def main():
    whisper = Whisper(model_size="base.en")
    tts = TTS()
    await whisper.start()
    await tts.start()
    try:
        text = await whisper.transcribe_wav(Path("recording.wav"), timeout=30)
        session = tts.speak(text, voice="alba", speed=1.25, timeout=30)
        session.set_speed(1.5)
        audio = await session.collect()
        Path("speech.pcm").write_bytes(audio)
    finally:
        await whisper.stop()
        await tts.stop()


asyncio.run(main())
```

## Compose a Server in Python

```python
from trillim import Server, LLM, Whisper, TTS

# Inference only
Server(LLM("~/.trillim/models/Trillim/BitNet-TRNQ")).run()

# Inference + voice pipeline
Server(
    LLM("~/.trillim/models/Trillim/BitNet-TRNQ"),
    Whisper(model_size="base.en"),
    TTS(),
).run()

# TTS only
Server(TTS()).run()
```

## Constructor Reference

### `LLM`

```python
from trillim import LLM

LLM(
    model_dir="~/.trillim/models/Trillim/BitNet-TRNQ",
    adapter_dir=None,          # optional LoRA adapter path
    num_threads=0,             # 0 = auto-detect
    trust_remote_code=False,
    lora_quant=None,           # "none", "bf16", "int8", "q4_0", etc.
    unembed_quant=None,        # "int8", "q4_0", etc.
    harness_name="default",    # "default" or "search"
)
```

`harness_name="search"` uses `ddgs` by default. If you switch a running server to Brave search later, set `SEARCH_API_KEY` and call `POST /v1/models/load` with `search_provider`.

## `Whisper`

```python
from trillim import Whisper

Whisper(
    model_size="base.en",
    compute_type="int8",
    cpu_threads=2,
)
```

After `await whisper.start()`, prefer the public helpers below. `whisper.engine.transcribe(...)` remains available as an advanced escape hatch.

Preferred public helpers:

```python
text = await whisper.transcribe_bytes(wav_bytes, language="en", timeout=30)
text = await whisper.transcribe_wav("recording.wav", timeout=30)
text = await whisper.transcribe_array(samples, sample_rate=44100, timeout=30)
text = await whisper.transcribe_array(samples, sample_rate=44100, channel_axis=0)
```

`transcribe_wav()` passes the file path through to Whisper's background worker, so large local recordings do not need to be fully loaded into Python memory before transcription starts.

`transcribe_array()` accepts float or integer array-like input. Integer arrays are normalized from their dtype automatically, including unsigned PCM buffers such as `uint8`.
For 2D input, the default layout is frames-first: `(num_frames, num_channels)`. Pass `channel_axis=0` for channels-first input shaped like `(num_channels, num_frames)`.

## `TTS`

```python
from trillim import TTS

TTS(
    voices_dir="~/.trillim/voices",
    default_voice="alba",
    speed=1.0,
)
```

After `await tts.start()`, use the public component methods:

```python
voices = tts.list_voices()
tts.default_voice = "jean"
tts.speed = 1.5
sample_rate = tts.sample_rate

await tts.register_voice("myvoice", wav_bytes)
pcm_chunks = [chunk async for chunk in tts.synthesize_stream("Hello there", speed=1.25)]
wav_bytes = await tts.synthesize_wav("Hello there", voice="myvoice", speed=1.5)
session = tts.speak("Queued speech", interrupt=False, timeout=30)
session.set_speed(1.25)
session.pause()
session.resume()
audio = await session.collect()
await tts.delete_voice("myvoice")
```

`tts.engine` remains available as an advanced escape hatch.
`voices_dir` is only created when you register a custom voice; constructing or starting `TTS()` with built-in voices does not require that directory to exist yet.
`speed` accepts values from `0.25` to `4.0` and uses pitch-preserving time stretching rather than naive resampling.
Speed-adjusted synthesis streams progressively with bounded lookahead; it does not wait for the full utterance before yielding audio.
`tts.speak(...)` returns a `TTSSession` that queues behind the active session by default. Pass `interrupt=True` to cancel the active and queued sessions before starting the new one.
`TTSSession` yields PCM chunks at `tts.sample_rate`.
`TTSSession` keeps only a bounded amount of PCM buffered ahead of the consumer. If consumption stalls, synthesis backpressures until room is available.
`pause()` and `resume()` control future chunk production only. They do not control speaker-device playback.
`set_speed()` changes future chunk production only. Already emitted audio is unchanged, and already buffered audio may still arrive at the old speed for a short bounded window.
For `Runtime`, dynamic speed control is effective when you consume a session progressively. If you call `session.collect()` and wait for the full utterance first, there is no opportunity to adjust speed mid-stream.

## `SentenceChunker`

```python
from trillim import SentenceChunker

chunker = SentenceChunker()
for piece in chunker.feed("Hello world. Another sentence"):
    print(piece)
print(chunker.flush())
```

Use `SentenceChunker` to split streaming LLM output into sentence-sized chunks before handing it to TTS.

## Add Custom Routes

```python
from trillim import Server, LLM

server = Server(LLM("~/.trillim/models/Trillim/BitNet-TRNQ"))
app = server.app

@app.get("/health")
async def health():
    return {"status": "ok"}

server.run(host="0.0.0.0", port=8000)
```
