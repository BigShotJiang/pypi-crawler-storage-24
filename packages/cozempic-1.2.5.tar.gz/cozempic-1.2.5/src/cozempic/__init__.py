"""Cozempic - Context weight-loss tool for Claude Code."""

__version__ = "1.2.5"
