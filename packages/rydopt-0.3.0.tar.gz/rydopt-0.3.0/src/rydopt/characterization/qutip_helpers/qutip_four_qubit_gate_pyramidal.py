from collections.abc import Callable

import jax
import numpy as np
import qutip as qt

IrxrI = qt.basis(3, 2).proj()
I1x1I = qt.basis(3, 1).proj()
I0x0I = qt.basis(3, 0).proj()
id3 = qt.qeye(3)
id2 = qt.basis(3, 0).proj() + qt.basis(3, 1).proj()
Irx1I = qt.basis(3, 2) @ qt.basis(3, 1).dag()
I1xrI = qt.basis(3, 1) @ qt.basis(3, 2).dag()
X_1r = Irx1I + I1xrI
Y_1r = 1j * Irx1I - 1j * I1xrI
plus_state = (qt.basis(3, 0) + qt.basis(3, 1)).unit()


def hamiltonian_FourQubitGatePyramidal(
    pulse_functions: Callable[[jax.Array | float], tuple[jax.Array, jax.Array, jax.Array, jax.Array]],
    decay: float,
    Vnn: float,
    Vnnn: float,
) -> tuple[Callable[[float], qt.Qobj], qt.Qobj, qt.Qobj]:
    proj = qt.tensor(qt.tensor(qt.tensor(id3, id3), id3), id3)
    if Vnn == float("inf"):
        Vnn = 0
        proj = proj @ (
            qt.tensor(qt.tensor(qt.tensor(id3, id3), id3), id3)
            - qt.tensor(qt.tensor(qt.tensor(IrxrI, id3), id3), IrxrI)
            - qt.tensor(qt.tensor(qt.tensor(id2, IrxrI), id3), IrxrI)
            - qt.tensor(qt.tensor(qt.tensor(id2, id2), IrxrI), IrxrI)
        )
    if Vnnn == float("inf"):
        Vnnn = 0
        proj = proj @ (
            qt.tensor(qt.tensor(qt.tensor(id3, id3), id3), id3)
            - qt.tensor(qt.tensor(qt.tensor(IrxrI, IrxrI), id3), id3)
            - qt.tensor(qt.tensor(qt.tensor(IrxrI, id2), IrxrI), id3)
            - qt.tensor(qt.tensor(qt.tensor(id2, IrxrI), IrxrI), id3)
        )

    def H(t: float) -> qt.Qobj:
        detuning_1, detuning_r, phase, rabi = pulse_functions(t)
        return (
            proj
            * (
                Vnnn
                * (
                    qt.tensor(qt.tensor(qt.tensor(IrxrI, IrxrI), id3), id3)
                    + qt.tensor(qt.tensor(qt.tensor(IrxrI, id3), IrxrI), id3)
                    + qt.tensor(qt.tensor(qt.tensor(id3, IrxrI), IrxrI), id3)
                )
                + Vnn
                * (
                    qt.tensor(qt.tensor(qt.tensor(IrxrI, id3), id3), IrxrI)
                    + qt.tensor(qt.tensor(qt.tensor(id3, IrxrI), id3), IrxrI)
                    + qt.tensor(qt.tensor(qt.tensor(id3, id3), IrxrI), IrxrI)
                )
                + (-detuning_1)
                * (
                    qt.tensor(qt.tensor(qt.tensor(I1x1I, id3), id3), id3)
                    + qt.tensor(qt.tensor(qt.tensor(id3, I1x1I), id3), id3)
                    + qt.tensor(qt.tensor(qt.tensor(id3, id3), I1x1I), id3)
                    + qt.tensor(qt.tensor(qt.tensor(id3, id3), id3), I1x1I)
                )
                + (-detuning_r - 1j * 0.5 * decay)
                * (
                    qt.tensor(qt.tensor(qt.tensor(IrxrI, id3), id3), id3)
                    + qt.tensor(qt.tensor(qt.tensor(id3, IrxrI), id3), id3)
                    + qt.tensor(qt.tensor(qt.tensor(id3, id3), IrxrI), id3)
                    + qt.tensor(qt.tensor(qt.tensor(id3, id3), id3), IrxrI)
                )
                + 0.5
                * rabi
                * np.cos(phase)
                * (
                    qt.tensor(qt.tensor(qt.tensor(X_1r, id3), id3), id3)
                    + qt.tensor(qt.tensor(qt.tensor(id3, X_1r), id3), id3)
                    + qt.tensor(qt.tensor(qt.tensor(id3, id3), X_1r), id3)
                    + qt.tensor(qt.tensor(qt.tensor(id3, id3), id3), X_1r)
                )
                + 0.5
                * rabi
                * np.sin(phase)
                * (
                    qt.tensor(qt.tensor(qt.tensor(Y_1r, id3), id3), id3)
                    + qt.tensor(qt.tensor(qt.tensor(id3, Y_1r), id3), id3)
                    + qt.tensor(qt.tensor(qt.tensor(id3, id3), Y_1r), id3)
                    + qt.tensor(qt.tensor(qt.tensor(id3, id3), id3), Y_1r)
                )
            )
            * proj
        )

    psi_in = qt.tensor(qt.tensor(qt.tensor(plus_state, plus_state), plus_state), plus_state)
    TR_op = (
        qt.tensor(qt.tensor(qt.tensor(IrxrI, id3), id3), id3)
        + qt.tensor(qt.tensor(qt.tensor(id3, IrxrI), id3), id3)
        + qt.tensor(qt.tensor(qt.tensor(id3, id3), IrxrI), id3)
        + qt.tensor(qt.tensor(qt.tensor(id3, id3), id3), IrxrI)
    )
    return H, psi_in, TR_op


def target_FourQubitGatePyramidal(
    final_state: qt.Qobj,
    phi: float | None,
    theta: float | None,
    theta_prime: float | None,
    lamb: float | None,
    lamb_prime: float | None,
    kappa: float | None,
) -> qt.Qobj:
    p = np.angle(final_state[1, 0]) if phi is None else phi
    t = np.angle(final_state[4, 0]) - 2 * p if theta is None else theta
    e = np.angle(final_state[12, 0]) - 2 * p if theta_prime is None else theta_prime
    l = np.angle(final_state[13, 0]) - 3 * p - 2 * t - e if lamb is None else lamb
    d = np.angle(final_state[39, 0]) - 3 * p - 3 * e if lamb_prime is None else lamb_prime
    k = np.angle(final_state[40, 0]) - 4 * p - 3 * t - 3 * e - 3 * l - d if kappa is None else kappa

    rz = qt.Qobj([[1, 0, 0], [0, np.exp(1j * p), 0], [0, 0, 1]])
    global_z_rotation = qt.tensor(qt.tensor(qt.tensor(rz, rz), rz), rz)
    entangling_gate = (
        qt.tensor(qt.tensor(qt.tensor(id3, id3), id3), id3)
        + (np.exp(1j * t) - 1) * qt.tensor(qt.tensor(qt.tensor(I1x1I, I0x0I + IrxrI), I0x0I + IrxrI), I1x1I)
        + (np.exp(1j * t) - 1) * qt.tensor(qt.tensor(qt.tensor(I0x0I + IrxrI, I1x1I), I0x0I + IrxrI), I1x1I)
        + (np.exp(1j * t) - 1) * qt.tensor(qt.tensor(qt.tensor(I0x0I + IrxrI, I0x0I + IrxrI), I1x1I), I1x1I)
        + (np.exp(1j * e) - 1) * qt.tensor(qt.tensor(qt.tensor(I1x1I, I1x1I), I0x0I + IrxrI), I0x0I + IrxrI)
        + (np.exp(1j * e) - 1) * qt.tensor(qt.tensor(qt.tensor(I1x1I, I0x0I + IrxrI), I1x1I), I0x0I + IrxrI)
        + (np.exp(1j * e) - 1) * qt.tensor(qt.tensor(qt.tensor(I0x0I + IrxrI, I1x1I), I1x1I), I0x0I + IrxrI)
        + (np.exp(1j * (d + 3 * e)) - 1) * qt.tensor(qt.tensor(qt.tensor(I1x1I, I1x1I), I1x1I), I0x0I + IrxrI)
        + (np.exp(1j * (l + 2 * t + e)) - 1) * qt.tensor(qt.tensor(qt.tensor(I1x1I, I1x1I), I0x0I + IrxrI), I1x1I)
        + (np.exp(1j * (l + 2 * t + e)) - 1) * qt.tensor(qt.tensor(qt.tensor(I1x1I, I0x0I + IrxrI), I1x1I), I1x1I)
        + (np.exp(1j * (l + 2 * t + e)) - 1) * qt.tensor(qt.tensor(qt.tensor(I0x0I + IrxrI, I1x1I), I1x1I), I1x1I)
        + (np.exp(1j * (k + d + 3 * l + 3 * t + 3 * e)) - 1)
        * qt.tensor(qt.tensor(qt.tensor(I1x1I, I1x1I), I1x1I), I1x1I)
    )
    return (
        entangling_gate
        * global_z_rotation
        * qt.tensor(qt.tensor(qt.tensor(plus_state, plus_state), plus_state), plus_state)
    )
