from wbcore.menus import ItemPermission, MenuItem

ACCOUNT_MENUITEM = MenuItem(
    label="Accounts",
    endpoint="wbcrm:account-list",
    endpoint_get_parameters={"parent__isnull": True},
    permission=ItemPermission(method=lambda request: request.user.is_internal, permissions=["wbcrm.view_account"]),
    add=MenuItem(
        label="Create Account",
        endpoint="wbcrm:account-list",
        permission=ItemPermission(method=lambda request: request.user.is_internal, permissions=["wbcrm.add_account"]),
    ),
)
