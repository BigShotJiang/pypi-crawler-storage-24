"""MCP server for Search API — placeholder."""

def main() -> None:
    print("mcparmory-search-api: full server coming soon. See https://mcparmory.com")

if __name__ == "__main__":
    main()
