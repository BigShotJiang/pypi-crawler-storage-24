"""VentiSim: Gymnasium environments for RL in mechanical ventilation."""

__version__ = "0.1.0"

from ventisim.envs import register_envs

register_envs()
