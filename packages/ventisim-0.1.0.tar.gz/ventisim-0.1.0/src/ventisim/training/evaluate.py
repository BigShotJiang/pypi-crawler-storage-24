"""Evaluation utilities for trained agents."""

from __future__ import annotations

import gymnasium as gym
import numpy as np


def evaluate_policy(
    model,
    env_id: str,
    n_episodes: int = 50,
    seed: int = 42,
) -> dict:
    """Evaluate a trained SB3 model on the given environment.

    Args:
        model: Trained SB3 model with .predict() method.
        env_id: Gymnasium environment ID.
        n_episodes: Number of evaluation episodes.
        seed: Random seed.

    Returns:
        Dict with mean_reward, std_reward, episode_rewards.
    """
    import ventisim  # noqa: F401

    env = gym.make(env_id)
    rng = np.random.default_rng(seed)
    rewards_list: list[float] = []

    for _ep in range(n_episodes):
        obs, _ = env.reset(seed=int(rng.integers(0, 2**31)))
        total_reward = 0.0
        done = False
        while not done:
            action, _ = model.predict(obs, deterministic=True)
            obs, reward, terminated, truncated, info = env.step(action)
            total_reward += reward
            done = terminated or truncated
        rewards_list.append(total_reward)

    env.close()
    return {
        "mean_reward": float(np.mean(rewards_list)),
        "std_reward": float(np.std(rewards_list)),
        "episode_rewards": rewards_list,
    }
