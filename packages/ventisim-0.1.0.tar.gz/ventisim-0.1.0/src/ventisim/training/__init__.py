"""VentiSim training utilities and configurations."""
