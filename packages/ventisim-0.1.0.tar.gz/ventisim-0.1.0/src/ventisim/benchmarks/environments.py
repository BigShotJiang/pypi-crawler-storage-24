"""Benchmark environment configurations."""

BENCHMARK_ENVS = [
    {
        "env_id": "ventisim/TidalVolumeControl-v0",
        "name": "TidalVolumeControl",
        "difficulty_tiers": ["easy", "medium", "hard"],
        "description": "Pressure-guided tidal volume targeting for lung-protective ventilation",
    },
    {
        "env_id": "ventisim/PEEPOptimization-v0",
        "name": "PEEPOptimization",
        "difficulty_tiers": ["easy", "medium", "hard"],
        "description": "PEEP titration for optimal oxygenation with recruitment/overdistension balance",
    },
    {
        "env_id": "ventisim/FullVentilatorManagement-v0",
        "name": "FullVentilatorManagement",
        "difficulty_tiers": ["easy", "medium", "hard"],
        "description": "Multi-parameter ventilator control (FiO2, PEEP, RR, P_insp)",
    },
]
