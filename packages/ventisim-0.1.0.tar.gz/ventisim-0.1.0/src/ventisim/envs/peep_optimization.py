"""PEEPOptimization-v0: Optimal PEEP titration for oxygenation.

The agent adjusts PEEP to optimize oxygenation (PaO2/SpO2) while
balancing the risk of overdistension and hemodynamic compromise.
FiO2 is held fixed at 0.6 to isolate the PEEP titration problem.

References:
    Gattinoni, L., et al. (2006). Lung recruitment in patients with the
    acute respiratory distress syndrome. NEJM, 354(17), 1775-1786.

    Briel, M., et al. (2010). Higher vs lower positive end-expiratory
    pressure in patients with acute lung injury and ARDS: systematic
    review and meta-analysis. JAMA, 303(9), 865-873.

    Mercat, A., et al. (2008). Positive end-expiratory pressure setting
    in adults with acute lung injury and ARDS. JAMA, 299(6), 646-655.
"""

from __future__ import annotations

import gymnasium as gym
import numpy as np
from gymnasium import spaces

from ventisim.models.patient import VirtualPatient

DIFFICULTY_TIERS = {
    "easy": {
        "variability": 0.0,
        "compliance_drift": False,
        "noise_std": 0.0,
    },
    "medium": {
        "variability": 0.15,
        "compliance_drift": False,
        "noise_std": 1.0,
    },
    "hard": {
        "variability": 0.3,
        "compliance_drift": True,
        "noise_std": 2.0,
    },
}


class PEEPOptimizationEnv(gym.Env):
    """Gymnasium environment for PEEP optimization.

    Observation space (Box, 8 dimensions):
        - PaO2: Arterial oxygen partial pressure (mmHg), range [0, 600]
        - PaCO2: Arterial CO2 partial pressure (mmHg), range [15, 120]
        - PEEP: Current PEEP level (cmH2O), range [0, 24]
        - compliance: Lung compliance (mL/cmH2O), range [5, 100]
        - plateau_pressure: Plateau pressure (cmH2O), range [0, 50]
        - driving_pressure: Driving pressure (cmH2O), range [0, 40]
        - FiO2: Fraction of inspired O2, range [0.21, 1.0]
        - SpO2: Oxygen saturation (%), range [0, 100]

    Action space (Box, 1 dimension):
        - PEEP_change: Change in PEEP (cmH2O) [-2, 2]

    Reward:
        - PaO2 component: +1.0 if PaO2 in [60, 100], scaled penalty outside
        - Driving pressure penalty: -0.5 if driving_pressure > 15
        - PEEP stability bonus: +0.1 if |PEEP_change| < 0.5
        - SpO2 penalty: -3.0 if SpO2 < 88%

    Termination:
        - PaO2 < 40 mmHg (severe hypoxemia)
    """

    metadata = {"render_modes": []}

    def __init__(
        self,
        difficulty: str = "medium",
        max_steps: int = 200,
        ards_severity: str = "moderate",
        FiO2: float = 0.6,
        P_insp: float = 25.0,
        RR: float = 20.0,
    ) -> None:
        super().__init__()

        tier = DIFFICULTY_TIERS.get(difficulty, DIFFICULTY_TIERS["medium"])
        self.difficulty = difficulty
        self.max_steps = max_steps
        self.ards_severity = ards_severity
        self.FiO2 = FiO2
        self.P_insp = P_insp
        self.RR = RR
        self._variability = tier["variability"]
        self._compliance_drift = tier["compliance_drift"]
        self._noise_std = tier["noise_std"]

        self.patient = VirtualPatient(ards_severity=ards_severity)

        self.observation_space = spaces.Box(
            low=np.array([0.0, 15.0, 0.0, 5.0, 0.0, 0.0, 0.21, 0.0], dtype=np.float32),
            high=np.array([600.0, 120.0, 24.0, 100.0, 50.0, 40.0, 1.0, 100.0], dtype=np.float32),
        )

        self.action_space = spaces.Box(
            low=np.array([-2.0], dtype=np.float32),
            high=np.array([2.0], dtype=np.float32),
        )

        self.steps = 0
        self.current_PEEP = 10.0
        self.in_target_steps = 0
        self._last_gases: dict = {}
        self._last_lung: dict = {}
        self._rng: np.random.Generator | None = None

    def reset(self, *, seed: int | None = None, options: dict | None = None):
        super().reset(seed=seed)
        self._rng = np.random.default_rng(seed)

        self.patient = VirtualPatient(ards_severity=self.ards_severity)

        if self._variability > 0 and self._rng is not None:
            self.patient.lung.apply_variability(self._rng, self._variability)

        self.steps = 0
        self.current_PEEP = 10.0
        self.in_target_steps = 0

        # Compute initial state
        self._update_physiology()

        return self._get_obs(), {}

    def step(self, action):
        peep_change = float(np.clip(action[0], -2.0, 2.0))

        # Update PEEP
        self.current_PEEP = float(np.clip(self.current_PEEP + peep_change, 0.0, 24.0))

        # Optional compliance drift
        if self._compliance_drift and self._rng is not None:
            self.patient.apply_drift(self._rng, self.steps, self.max_steps)

        # Update physiology
        self._update_physiology()

        PaO2 = self._last_gases["PaO2"]
        PaCO2 = self._last_gases["PaCO2"]
        SpO2 = self._last_gases["SpO2"]
        driving_p = self._last_lung["driving_pressure"]

        # Add measurement noise
        if self._noise_std > 0 and self._rng is not None:
            PaO2 += self._rng.normal(0, self._noise_std)
            PaO2 = max(0.0, PaO2)

        # Compute reward
        reward = 0.0

        # PaO2 targeting: optimal range 60-100 mmHg
        if 60.0 <= PaO2 <= 100.0:
            reward += 1.0
            self.in_target_steps += 1
        elif 50.0 <= PaO2 < 60.0 or 100.0 < PaO2 <= 150.0:
            reward -= 0.3
        else:
            reward -= 1.0

        # Driving pressure penalty (>15 cmH2O associated with mortality)
        if driving_p > 15.0:
            reward -= 0.5

        # PEEP stability bonus
        if abs(peep_change) < 0.5:
            reward += 0.1

        # SpO2 penalty
        if SpO2 < 88.0:
            reward -= 3.0

        self.steps += 1

        # Termination: severe hypoxemia
        terminated = PaO2 < 40.0
        truncated = self.steps >= self.max_steps

        info = {
            "PaO2": PaO2,
            "PaCO2": PaCO2,
            "SpO2": SpO2,
            "PEEP": self.current_PEEP,
            "driving_pressure": driving_p,
            "in_target": 60.0 <= PaO2 <= 100.0,
            "target_fraction": self.in_target_steps / max(1, self.steps),
        }

        return self._get_obs(), reward, terminated, truncated, info

    def _update_physiology(self) -> None:
        """Recompute lung mechanics and gas exchange at current settings."""
        self._last_lung = self.patient.lung.step(self.P_insp, self.current_PEEP)
        vt_mL = self._last_lung["tidal_volume_mL"]
        self._last_gases = self.patient.gas_exchange.compute_gases(
            FiO2=self.FiO2,
            VT_mL=vt_mL,
            RR=self.RR,
            PEEP=self.current_PEEP,
            compliance=self.patient.lung.compliance,
        )

    def _get_obs(self) -> np.ndarray:
        gases = self._last_gases if self._last_gases else {
            "PaO2": 0.0, "PaCO2": 40.0, "SpO2": 0.0,
        }
        lung = self._last_lung if self._last_lung else {
            "plateau_pressure": 0.0, "driving_pressure": 0.0,
        }
        return np.array([
            min(gases.get("PaO2", 0.0), 600.0),
            np.clip(gases.get("PaCO2", 40.0), 15.0, 120.0),
            self.current_PEEP,
            self.patient.lung.compliance,
            min(lung.get("plateau_pressure", 0.0), 50.0),
            min(lung.get("driving_pressure", 0.0), 40.0),
            self.FiO2,
            np.clip(gases.get("SpO2", 0.0), 0.0, 100.0),
        ], dtype=np.float32)
