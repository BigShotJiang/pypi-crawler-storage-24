"""VentiSim Gymnasium environments."""

from gymnasium.envs.registration import register


def register_envs() -> None:
    """Register all VentiSim environments with Gymnasium."""
    register(
        id="ventisim/TidalVolumeControl-v0",
        entry_point="ventisim.envs.tidal_volume_control:TidalVolumeControlEnv",
    )
    register(
        id="ventisim/PEEPOptimization-v0",
        entry_point="ventisim.envs.peep_optimization:PEEPOptimizationEnv",
    )
    register(
        id="ventisim/FullVentilatorManagement-v0",
        entry_point="ventisim.envs.full_ventilator:FullVentilatorManagementEnv",
    )


__all__ = ["register_envs"]
