"""TidalVolumeControl-v0: Pressure-guided tidal volume targeting.

The agent controls inspiratory pressure to deliver a target tidal volume
based on the ARDSNet low tidal volume protocol (6 mL/kg IBW), while
keeping airway pressures within safe limits.

References:
    ARDSNet (2000). Ventilation with lower tidal volumes as compared with
    traditional tidal volumes for acute lung injury. NEJM, 342(18), 1301-1308.

    Amato, M. B. P., et al. (2015). Driving pressure and survival in the
    acute respiratory distress syndrome. NEJM, 372(8), 747-755.
"""

from __future__ import annotations

import gymnasium as gym
import numpy as np
from gymnasium import spaces

from ventisim.models.patient import VirtualPatient

DIFFICULTY_TIERS = {
    "easy": {
        "variability": 0.0,
        "compliance_drift": False,
        "noise_std": 0.0,
    },
    "medium": {
        "variability": 0.15,
        "compliance_drift": False,
        "noise_std": 0.02,
    },
    "hard": {
        "variability": 0.3,
        "compliance_drift": True,
        "noise_std": 0.05,
    },
}


class TidalVolumeControlEnv(gym.Env):
    """Gymnasium environment for tidal volume control via inspiratory pressure.

    Observation space (Box, 7 dimensions):
        - current_vt: Current tidal volume (L), range [0, 1.5]
        - peak_pressure: Peak airway pressure (cmH2O), range [0, 60]
        - compliance: Lung compliance (mL/cmH2O), range [5, 100]
        - resistance: Airway resistance (cmH2O/L/s), range [0, 40]
        - target_vt: Target tidal volume (L), range [0, 1.0]
        - prev_pressure: Previous inspiratory pressure / max, range [0, 1]
        - time_fraction: Current step / max steps, range [0, 1]

    Action space (Box, 1 dimension):
        - inspiratory_pressure: Pressure in cmH2O [5, 40]

    Reward:
        - +1.0 if VT within 10% of target
        - -0.5 if VT within 20% of target (marginal)
        - -1.0 otherwise
        - -0.01 * |pressure_change| for smoothness penalty
        - -2.0 if plateau pressure > 30 cmH2O (lung-protective threshold)

    Termination:
        - VT > 800 mL (dangerous overdistension)
    """

    metadata = {"render_modes": []}

    def __init__(
        self,
        difficulty: str = "medium",
        max_steps: int = 200,
        ards_severity: str = "moderate",
        PEEP: float = 10.0,
    ) -> None:
        super().__init__()

        tier = DIFFICULTY_TIERS.get(difficulty, DIFFICULTY_TIERS["medium"])
        self.difficulty = difficulty
        self.max_steps = max_steps
        self.ards_severity = ards_severity
        self.PEEP = PEEP
        self._variability = tier["variability"]
        self._compliance_drift = tier["compliance_drift"]
        self._noise_std = tier["noise_std"]

        self.patient = VirtualPatient(ards_severity=ards_severity)
        self._target_vt = self.patient.target_vt_ml / 1000.0  # convert to L

        self.observation_space = spaces.Box(
            low=np.array([0.0, 0.0, 5.0, 0.0, 0.0, 0.0, 0.0], dtype=np.float32),
            high=np.array([1.5, 60.0, 100.0, 40.0, 1.0, 1.0, 1.0], dtype=np.float32),
        )

        self.action_space = spaces.Box(
            low=np.array([5.0], dtype=np.float32),
            high=np.array([40.0], dtype=np.float32),
        )

        self.steps = 0
        self.in_target_steps = 0
        self.prev_pressure = 0.0
        self._last_vt = 0.0
        self._last_peak = 0.0
        self._rng: np.random.Generator | None = None

    def reset(self, *, seed: int | None = None, options: dict | None = None):
        super().reset(seed=seed)
        self._rng = np.random.default_rng(seed)

        self.patient = VirtualPatient(ards_severity=self.ards_severity)
        self._target_vt = self.patient.target_vt_ml / 1000.0

        if self._variability > 0 and self._rng is not None:
            self.patient.lung.apply_variability(self._rng, self._variability)

        self.steps = 0
        self.in_target_steps = 0
        self.prev_pressure = 0.0
        self._last_vt = 0.0
        self._last_peak = 0.0

        return self._get_obs(), {}

    def step(self, action):
        P_insp = float(np.clip(action[0], 5.0, 40.0))

        # Optional compliance drift
        if self._compliance_drift and self._rng is not None:
            self.patient.apply_drift(self._rng, self.steps, self.max_steps)

        # Compute lung mechanics
        result = self.patient.lung.step(P_insp, self.PEEP)
        vt = result["tidal_volume"]  # L
        vt_mL = result["tidal_volume_mL"]
        peak = result["peak_pressure"]
        plateau = result["plateau_pressure"]

        # Add measurement noise
        if self._noise_std > 0 and self._rng is not None:
            vt += self._rng.normal(0, self._noise_std)
            vt = max(0.0, vt)

        self._last_vt = vt
        self._last_peak = peak

        # Compute reward
        reward = 0.0
        vt_error_frac = abs(vt - self._target_vt) / max(0.001, self._target_vt)

        if vt_error_frac <= 0.10:
            reward += 1.0
            self.in_target_steps += 1
        elif vt_error_frac <= 0.20:
            reward -= 0.5
        else:
            reward -= 1.0

        # Pressure change penalty (smoothness)
        pressure_change = abs(P_insp - self.prev_pressure) / 35.0  # normalize by range
        reward -= 0.01 * pressure_change

        # Lung-protective penalty: plateau > 30 cmH2O
        if plateau > 30.0:
            reward -= 2.0

        self.prev_pressure = P_insp
        self.steps += 1

        # Termination: dangerous overdistension
        terminated = vt_mL > 800.0
        truncated = self.steps >= self.max_steps

        info = {
            "tidal_volume_mL": vt_mL,
            "tidal_volume_L": vt,
            "peak_pressure": peak,
            "plateau_pressure": plateau,
            "driving_pressure": result["driving_pressure"],
            "target_vt_L": self._target_vt,
            "vt_error_fraction": vt_error_frac,
            "in_target": vt_error_frac <= 0.10,
            "target_fraction": self.in_target_steps / max(1, self.steps),
        }

        return self._get_obs(), reward, terminated, truncated, info

    def _get_obs(self) -> np.ndarray:
        return np.array([
            min(self._last_vt, 1.5),
            min(self._last_peak, 60.0),
            self.patient.lung.compliance,
            self.patient.lung.resistance,
            self._target_vt,
            self.prev_pressure / 40.0,
            self.steps / max(1, self.max_steps),
        ], dtype=np.float32)
