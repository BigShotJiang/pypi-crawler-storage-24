"""FullVentilatorManagement-v0: Multi-parameter ventilator control.

The agent simultaneously controls FiO2, PEEP, respiratory rate, and
inspiratory pressure to maintain oxygenation and ventilation targets
while adhering to lung-protective strategy constraints.

References:
    ARDSNet (2000). Ventilation with lower tidal volumes. NEJM, 342(18), 1301-1308.

    Amato, M. B. P., et al. (2015). Driving pressure and survival in ARDS.
    NEJM, 372(8), 747-755.

    Brower, R. G., et al. (2004). Higher vs lower PEEP in patients with ARDS.
    NEJM, 351(4), 327-336.
"""

from __future__ import annotations

import gymnasium as gym
import numpy as np
from gymnasium import spaces

from ventisim.models.patient import VirtualPatient

DIFFICULTY_TIERS = {
    "easy": {
        "variability": 0.0,
        "compliance_drift": False,
        "noise_std": 0.0,
    },
    "medium": {
        "variability": 0.15,
        "compliance_drift": False,
        "noise_std": 1.0,
    },
    "hard": {
        "variability": 0.3,
        "compliance_drift": True,
        "noise_std": 2.0,
    },
}


class FullVentilatorManagementEnv(gym.Env):
    """Gymnasium environment for full ventilator management.

    Observation space (Box, 10 dimensions):
        - PaO2: Arterial oxygen (mmHg), range [0, 600]
        - PaCO2: Arterial CO2 (mmHg), range [15, 120]
        - SpO2: Oxygen saturation (%), range [0, 100]
        - tidal_volume: Current VT (L), range [0, 1.5]
        - PEEP: Current PEEP (cmH2O), range [0, 24]
        - plateau_pressure: Plateau pressure (cmH2O), range [0, 50]
        - driving_pressure: Driving pressure (cmH2O), range [0, 40]
        - compliance: Lung compliance (mL/cmH2O), range [5, 100]
        - FiO2: Current FiO2, range [0.21, 1.0]
        - time_fraction: Current step / max steps, range [0, 1]

    Action space (Box, 4 dimensions):
        - FiO2: Fraction of inspired O2 [0.21, 1.0]
        - PEEP: Positive end-expiratory pressure [0, 24]
        - RR: Respiratory rate [8, 35] breaths/min
        - P_insp: Inspiratory pressure [10, 40] cmH2O

    Reward (composite):
        - Oxygenation: +1.0 if PaO2 in [60, 100], penalty otherwise
        - Ventilation: +0.5 if PaCO2 in [35, 45], penalty otherwise
        - Lung protection: -1.0 if plateau > 30, -0.5 if driving > 15
        - FiO2 minimization: +0.2 if FiO2 < 0.5 (oxygen toxicity prevention)
        - SpO2 critical: -3.0 if SpO2 < 88%

    Termination:
        - PaO2 < 40 mmHg (severe hypoxemia)
        - PaCO2 > 80 mmHg (severe hypercapnia)
    """

    metadata = {"render_modes": []}

    def __init__(
        self,
        difficulty: str = "medium",
        max_steps: int = 300,
        ards_severity: str = "moderate",
    ) -> None:
        super().__init__()

        tier = DIFFICULTY_TIERS.get(difficulty, DIFFICULTY_TIERS["medium"])
        self.difficulty = difficulty
        self.max_steps = max_steps
        self.ards_severity = ards_severity
        self._variability = tier["variability"]
        self._compliance_drift = tier["compliance_drift"]
        self._noise_std = tier["noise_std"]

        self.patient = VirtualPatient(ards_severity=ards_severity)

        self.observation_space = spaces.Box(
            low=np.array(
                [0.0, 15.0, 0.0, 0.0, 0.0, 0.0, 0.0, 5.0, 0.21, 0.0], dtype=np.float32
            ),
            high=np.array(
                [600.0, 120.0, 100.0, 1.5, 24.0, 50.0, 40.0, 100.0, 1.0, 1.0], dtype=np.float32
            ),
        )

        self.action_space = spaces.Box(
            low=np.array([0.21, 0.0, 8.0, 10.0], dtype=np.float32),
            high=np.array([1.0, 24.0, 35.0, 40.0], dtype=np.float32),
        )

        self.steps = 0
        self.in_target_steps = 0
        self._current_FiO2 = 0.6
        self._current_PEEP = 10.0
        self._current_RR = 20.0
        self._current_P_insp = 25.0
        self._last_gases: dict = {}
        self._last_lung: dict = {}
        self._rng: np.random.Generator | None = None

    def reset(self, *, seed: int | None = None, options: dict | None = None):
        super().reset(seed=seed)
        self._rng = np.random.default_rng(seed)

        self.patient = VirtualPatient(ards_severity=self.ards_severity)

        if self._variability > 0 and self._rng is not None:
            self.patient.lung.apply_variability(self._rng, self._variability)

        self.steps = 0
        self.in_target_steps = 0
        self._current_FiO2 = 0.6
        self._current_PEEP = 10.0
        self._current_RR = 20.0
        self._current_P_insp = 25.0

        # Compute initial state
        self._update_physiology()

        return self._get_obs(), {}

    def step(self, action):
        # Unpack and clip actions
        FiO2 = float(np.clip(action[0], 0.21, 1.0))
        PEEP = float(np.clip(action[1], 0.0, 24.0))
        RR = float(np.clip(action[2], 8.0, 35.0))
        P_insp = float(np.clip(action[3], 10.0, 40.0))

        self._current_FiO2 = FiO2
        self._current_PEEP = PEEP
        self._current_RR = RR
        self._current_P_insp = P_insp

        # Optional compliance drift
        if self._compliance_drift and self._rng is not None:
            self.patient.apply_drift(self._rng, self.steps, self.max_steps)

        # Update physiology
        self._update_physiology()

        PaO2 = self._last_gases["PaO2"]
        PaCO2 = self._last_gases["PaCO2"]
        SpO2 = self._last_gases["SpO2"]
        vt = self._last_lung["tidal_volume"]
        plateau = self._last_lung["plateau_pressure"]
        driving_p = self._last_lung["driving_pressure"]

        # Add measurement noise
        if self._noise_std > 0 and self._rng is not None:
            PaO2 += self._rng.normal(0, self._noise_std)
            PaO2 = max(0.0, PaO2)
            PaCO2 += self._rng.normal(0, self._noise_std * 0.5)

        # Composite reward
        reward = 0.0

        # Oxygenation target: PaO2 60-100 mmHg
        if 60.0 <= PaO2 <= 100.0:
            reward += 1.0
        elif 50.0 <= PaO2 < 60.0 or 100.0 < PaO2 <= 150.0:
            reward -= 0.3
        else:
            reward -= 1.0

        # Ventilation target: PaCO2 35-45 mmHg
        if 35.0 <= PaCO2 <= 45.0:
            reward += 0.5
        elif 30.0 <= PaCO2 < 35.0 or 45.0 < PaCO2 <= 55.0:
            reward -= 0.2
        else:
            reward -= 0.5

        # Lung protection: plateau < 30, driving < 15
        if plateau > 30.0:
            reward -= 1.0
        if driving_p > 15.0:
            reward -= 0.5

        # FiO2 minimization (oxygen toxicity avoidance)
        if FiO2 < 0.5:
            reward += 0.2

        # SpO2 critical penalty
        if SpO2 < 88.0:
            reward -= 3.0

        # Track in-target
        in_target = 60.0 <= PaO2 <= 100.0 and 35.0 <= PaCO2 <= 45.0
        if in_target:
            self.in_target_steps += 1

        self.steps += 1

        # Termination conditions
        terminated = PaO2 < 40.0 or PaCO2 > 80.0
        truncated = self.steps >= self.max_steps

        info = {
            "PaO2": PaO2,
            "PaCO2": PaCO2,
            "SpO2": SpO2,
            "tidal_volume_L": vt,
            "tidal_volume_mL": self._last_lung["tidal_volume_mL"],
            "PEEP": PEEP,
            "FiO2": FiO2,
            "RR": RR,
            "P_insp": P_insp,
            "plateau_pressure": plateau,
            "driving_pressure": driving_p,
            "in_target": in_target,
            "target_fraction": self.in_target_steps / max(1, self.steps),
        }

        return self._get_obs(), reward, terminated, truncated, info

    def _update_physiology(self) -> None:
        """Recompute lung mechanics and gas exchange at current settings."""
        self._last_lung = self.patient.lung.step(self._current_P_insp, self._current_PEEP)
        vt_mL = self._last_lung["tidal_volume_mL"]
        self._last_gases = self.patient.gas_exchange.compute_gases(
            FiO2=self._current_FiO2,
            VT_mL=vt_mL,
            RR=self._current_RR,
            PEEP=self._current_PEEP,
            compliance=self.patient.lung.compliance,
        )

    def _get_obs(self) -> np.ndarray:
        gases = self._last_gases if self._last_gases else {
            "PaO2": 0.0, "PaCO2": 40.0, "SpO2": 0.0,
        }
        lung = self._last_lung if self._last_lung else {
            "tidal_volume": 0.0, "plateau_pressure": 0.0, "driving_pressure": 0.0,
        }
        return np.array([
            min(gases.get("PaO2", 0.0), 600.0),
            np.clip(gases.get("PaCO2", 40.0), 15.0, 120.0),
            np.clip(gases.get("SpO2", 0.0), 0.0, 100.0),
            min(lung.get("tidal_volume", 0.0), 1.5),
            self._current_PEEP,
            min(lung.get("plateau_pressure", 0.0), 50.0),
            min(lung.get("driving_pressure", 0.0), 40.0),
            self.patient.lung.compliance,
            self._current_FiO2,
            self.steps / max(1, self.max_steps),
        ], dtype=np.float32)
