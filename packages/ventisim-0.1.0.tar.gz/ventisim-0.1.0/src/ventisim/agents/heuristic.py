"""Heuristic clinical baseline agents for VentiSim environments.

Implements simplified clinical protocols as baselines for comparison
with RL agents.

References:
    ARDSNet (2000). Ventilation with lower tidal volumes. NEJM, 342(18), 1301-1308.

    Briel, M., et al. (2010). Higher vs lower PEEP in patients with acute
    lung injury and ARDS. JAMA, 303(9), 865-873.

    Papazian, L., et al. (2019). Formal guidelines: management of acute
    respiratory distress syndrome. Annals of Intensive Care, 9(1), 69.
"""

from __future__ import annotations

import gymnasium as gym
import numpy as np


def _tidal_volume_heuristic(obs: np.ndarray) -> np.ndarray:
    """Proportional controller for tidal volume targeting.

    Adjusts inspiratory pressure to drive VT toward the target.
    obs[0] = current_vt, obs[4] = target_vt (as fraction of range).
    """
    current_vt = obs[0]  # L
    target_vt = obs[4]   # L
    error = target_vt - current_vt  # positive = need more volume

    # Proportional controller: adjust pressure based on VT error
    # Base pressure around 20 cmH2O, adjust by error
    base_pressure = 20.0
    Kp = 50.0  # gain (cmH2O per L error)
    pressure = base_pressure + Kp * error
    return np.array([np.clip(pressure, 5.0, 40.0)], dtype=np.float32)


def _peep_optimization_heuristic(obs: np.ndarray) -> np.ndarray:
    """Incremental PEEP titration based on oxygenation.

    Increases PEEP if PaO2 is low, decreases if excessive, holds steady
    when in target range.
    obs[0] = PaO2, obs[2] = current PEEP.
    """
    PaO2 = obs[0]

    if PaO2 < 60.0:
        # Hypoxemic: increase PEEP
        delta = 1.0
    elif PaO2 > 100.0:
        # Hyperoxic: decrease PEEP (but cautiously)
        delta = -0.5
    else:
        # In range: hold
        delta = 0.0

    return np.array([np.clip(delta, -2.0, 2.0)], dtype=np.float32)


def _full_ventilator_heuristic(obs: np.ndarray) -> np.ndarray:
    """Multi-parameter heuristic for full ventilator management.

    Adjusts FiO2, PEEP, RR, and P_insp based on current blood gases.
    obs[0]=PaO2, obs[1]=PaCO2, obs[3]=VT, obs[4]=PEEP, obs[7]=compliance, obs[8]=FiO2
    """
    PaO2 = obs[0]
    PaCO2 = obs[1]
    current_PEEP = obs[4]
    current_FiO2 = obs[8]

    # FiO2: decrease if oxygenation adequate, increase if low
    if PaO2 > 100.0 and current_FiO2 > 0.3:
        FiO2 = max(0.21, current_FiO2 - 0.05)
    elif PaO2 < 60.0:
        FiO2 = min(1.0, current_FiO2 + 0.05)
    else:
        FiO2 = current_FiO2

    # PEEP: titrate for oxygenation
    if PaO2 < 60.0:
        PEEP = min(24.0, current_PEEP + 1.0)
    elif PaO2 > 120.0:
        PEEP = max(5.0, current_PEEP - 1.0)
    else:
        PEEP = current_PEEP

    # RR: adjust for PaCO2
    if PaCO2 > 45.0:
        RR = 24.0  # increase ventilation
    elif PaCO2 < 35.0:
        RR = 14.0  # decrease ventilation
    else:
        RR = 18.0

    # P_insp: target ~6 mL/kg (~360mL for 60kg IBW -> ~0.36L)
    P_insp = 22.0  # moderate baseline

    return np.array([
        np.clip(FiO2, 0.21, 1.0),
        np.clip(PEEP, 0.0, 24.0),
        np.clip(RR, 8.0, 35.0),
        np.clip(P_insp, 10.0, 40.0),
    ], dtype=np.float32)


HEURISTIC_MAP = {
    "ventisim/TidalVolumeControl-v0": _tidal_volume_heuristic,
    "ventisim/PEEPOptimization-v0": _peep_optimization_heuristic,
    "ventisim/FullVentilatorManagement-v0": _full_ventilator_heuristic,
}


def evaluate_heuristic(
    env_id: str,
    n_episodes: int = 50,
    seed: int = 42,
) -> dict:
    """Evaluate the heuristic agent on the given environment.

    Args:
        env_id: Gymnasium environment ID.
        n_episodes: Number of evaluation episodes.
        seed: Random seed.

    Returns:
        Dict with mean_reward, std_reward, episode_rewards.
    """
    import ventisim  # noqa: F401

    env = gym.make(env_id)
    rng = np.random.default_rng(seed)
    action_fn = HEURISTIC_MAP.get(env_id)
    if action_fn is None:
        raise ValueError(f"No heuristic defined for {env_id}")

    rewards_list: list[float] = []

    for _ep in range(n_episodes):
        obs, _ = env.reset(seed=int(rng.integers(0, 2**31)))
        total_reward = 0.0
        done = False
        while not done:
            action = action_fn(obs)
            obs, reward, terminated, truncated, info = env.step(action)
            total_reward += reward
            done = terminated or truncated
        rewards_list.append(total_reward)

    env.close()
    return {
        "mean_reward": float(np.mean(rewards_list)),
        "std_reward": float(np.std(rewards_list)),
        "episode_rewards": rewards_list,
    }
