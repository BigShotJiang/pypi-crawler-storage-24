"""Gas exchange model for mechanical ventilation simulation.

Models the relationship between ventilator settings and arterial blood gases
(PaO2, PaCO2, SpO2) using simplified alveolar gas equations with shunt
physiology and PEEP-dependent recruitment.

References:
    West, J. B. (2012). Respiratory Physiology: The Essentials. 9th ed.
    Lippincott Williams & Wilkins.

    Gattinoni, L., et al. (2006). Lung recruitment in patients with the
    acute respiratory distress syndrome. NEJM, 354(17), 1775-1786.

    Severinghaus, J. W. (1979). Simple, accurate equations for human
    blood O2 dissociation computations. J Appl Physiol, 46(3), 599-602.
"""

from __future__ import annotations

import math

import numpy as np

# SIMPLIFICATION: Using a single-compartment alveolar gas equation with a
# fixed shunt fraction modified by PEEP-dependent recruitment. Real gas
# exchange involves V/Q mismatch distributions, diffusion limitation, and
# time-varying shunt. This model captures the dominant first-order effects
# relevant to ventilator management decisions.


class GasExchangeModel:
    """Simplified gas exchange model with shunt and PEEP recruitment.

    Models arterial blood gases as a function of ventilator settings:
        - FiO2: fraction of inspired oxygen
        - VT: tidal volume (mL)
        - RR: respiratory rate (breaths/min)
        - PEEP: positive end-expiratory pressure (cmH2O)

    Key equations:
        VA = (VT - VD) * RR / 1000  (alveolar ventilation, L/min)
        PaCO2 = 0.863 * VCO2 / VA  (alveolar ventilation equation)
        PAO2 = FiO2 * (PB - PH2O) - PaCO2 / RQ  (alveolar gas equation)
        PaO2 = PAO2 * (1 - shunt) + shunt * 40  (shunt equation)
    """

    def __init__(
        self,
        qs_qt: float = 0.1,
        vco2: float = 200.0,
        vd: float = 150.0,
        rq: float = 0.8,
    ) -> None:
        """Initialize gas exchange model.

        Args:
            qs_qt: Baseline right-to-left shunt fraction (0-1). Normal ~0.05.
            vco2: CO2 production rate (mL/min). Normal ~200.
            vd: Anatomical dead space volume (mL). Normal ~150.
            rq: Respiratory quotient (VCO2/VO2). Normal ~0.8.
        """
        self.qs_qt = qs_qt
        self.vco2 = vco2
        self.vd = vd
        self.rq = rq

    def compute_gases(
        self,
        FiO2: float,
        VT_mL: float,
        RR: float,
        PEEP: float,
        compliance: float,
    ) -> dict:
        """Compute arterial blood gas values given ventilator settings.

        Args:
            FiO2: Fraction of inspired oxygen (0.21-1.0).
            VT_mL: Tidal volume in mL.
            RR: Respiratory rate in breaths/min.
            PEEP: Positive end-expiratory pressure in cmH2O.
            compliance: Current lung compliance in mL/cmH2O.

        Returns:
            Dict with PaO2 (mmHg), PaCO2 (mmHg), SpO2 (%), PAO2 (mmHg).
        """
        # Alveolar ventilation (L/min)
        VA = max(0.01, (VT_mL - self.vd) / 1000.0 * RR)

        # PaCO2 from alveolar ventilation equation
        PaCO2 = 0.863 * self.vco2 / max(0.01, VA)
        PaCO2 = np.clip(PaCO2, 15.0, 120.0)

        # Alveolar gas equation (PAO2)
        PB = 760.0   # barometric pressure (mmHg, sea level)
        PH2O = 47.0  # water vapor pressure at 37C (mmHg)
        PAO2 = FiO2 * (PB - PH2O) - PaCO2 / self.rq

        # Effective shunt with PEEP recruitment
        effective_shunt = self.peep_effect(PEEP, compliance)

        # Shunt equation: PaO2 = PAO2 * (1-Qs/Qt) + Qs/Qt * PvO2
        # PvO2 assumed ~40 mmHg
        PaO2 = PAO2 * (1.0 - effective_shunt) + effective_shunt * 40.0
        PaO2 = max(0.0, PaO2)

        # SpO2 from PaO2
        SpO2 = self.spo2_from_pao2(PaO2)

        return {
            "PaO2": float(PaO2),
            "PaCO2": float(PaCO2),
            "SpO2": float(SpO2),
            "PAO2": float(PAO2),
        }

    def peep_effect(self, PEEP: float, compliance: float) -> float:
        """Compute effective shunt fraction accounting for PEEP recruitment.

        Higher PEEP recruits collapsed alveoli (reducing shunt) up to an
        optimal point, beyond which overdistension increases dead space.
        Lower compliance (stiffer lungs, as in ARDS) requires higher
        optimal PEEP for recruitment.

        Args:
            PEEP: Positive end-expiratory pressure (cmH2O).
            compliance: Current lung compliance (mL/cmH2O).

        Returns:
            Effective shunt fraction (0-1).
        """
        # Optimal PEEP depends on compliance: worse lungs need higher PEEP
        # Normal compliance ~50 -> optimal ~10; severe ARDS ~15 -> optimal ~17
        optimal_peep = 20.0 - compliance * 0.2
        optimal_peep = max(5.0, min(25.0, optimal_peep))

        # Sigmoid recruitment curve centered at half the optimal PEEP
        recruitment = 1.0 / (1.0 + math.exp(-0.5 * (PEEP - optimal_peep * 0.5)))

        # Overdistension penalty if PEEP exceeds optimal + margin
        overdistension_penalty = 0.0
        if optimal_peep + 5.0 < PEEP:
            excess = PEEP - (optimal_peep + 5.0)
            overdistension_penalty = 0.02 * excess

        # Effective shunt: reduce baseline by recruitment, add overdistension
        effective_shunt = self.qs_qt * (1.0 - recruitment * 0.7) + overdistension_penalty
        return max(0.0, min(1.0, effective_shunt))

    @staticmethod
    def spo2_from_pao2(PaO2: float) -> float:
        """Convert PaO2 to SpO2 using the Hill equation (oxyhemoglobin dissociation).

        Based on Severinghaus (1979) simplified sigmoid model.

        Args:
            PaO2: Arterial partial pressure of oxygen (mmHg).

        Returns:
            SpO2 percentage (0-100).
        """
        if PaO2 <= 0:
            return 0.0
        # Hill equation: SpO2 = 100 * PaO2^n / (P50^n + PaO2^n)
        # P50 = 26.6 mmHg, n = 2.7 (standard values)
        n = 2.7
        P50 = 26.6
        SpO2 = 100.0 * (PaO2 ** n) / (P50 ** n + PaO2 ** n)
        return float(np.clip(SpO2, 0.0, 100.0))
