"""Single-compartment lung mechanics model for mechanical ventilation.

Models the relationship between airway pressures and tidal volume delivery
using a simplified single-compartment (RC) model of the respiratory system.

References:
    Bates, J. H. T. (2009). Lung Mechanics: An Inverse Modeling Approach.
    Cambridge University Press.

    Hess, D. R. (2005). Respiratory mechanics in mechanically ventilated
    patients. Respiratory Care, 50(2), 235-252.

    ARDSNet (2000). Ventilation with lower tidal volumes as compared with
    traditional tidal volumes for acute lung injury and the acute respiratory
    distress syndrome. NEJM, 342(18), 1301-1308.
"""

from __future__ import annotations

import numpy as np

# SIMPLIFICATION: Using a steady-state single-compartment model rather than
# a dynamic ODE-based model. The single-compartment assumption treats the lung
# as a single elastic chamber with resistive tubing. In reality, regional
# heterogeneity (baby lung, dependent vs. non-dependent zones) significantly
# affects ventilation distribution in ARDS. This model captures the dominant
# first-order behavior suitable for RL benchmarking.

PARAMETER_RANGES = {
    "compliance": {
        "min": 10.0, "max": 80.0, "unit": "mL/cmH2O",
        "source": "Hess, 2005", "default": 50.0,
        "note": "Normal ~50-80, ARDS 10-30 mL/cmH2O",
    },
    "resistance": {
        "min": 5.0, "max": 30.0, "unit": "cmH2O/L/s",
        "source": "Bates, 2009", "default": 10.0,
        "note": "Normal ~5-10, elevated with bronchospasm or small ETT",
    },
}


class SingleCompartmentLung:
    """Single-compartment lung mechanics model (RC circuit analog).

    State variables:
        compliance: Static lung compliance (mL/cmH2O)
        resistance: Airway resistance (cmH2O/L/s)

    Equations (steady-state):
        VT = (P_insp - PEEP) * compliance / 1000  (L)
        P_plateau = VT * 1000 / compliance + PEEP  (cmH2O)
        P_peak = P_insp  (cmH2O, simplified)
        Driving_pressure = P_plateau - PEEP  (cmH2O)
        Flow = (P_insp - PEEP) / resistance  (L/s)
    """

    def __init__(
        self,
        compliance: float = 50.0,
        resistance: float = 10.0,
        dt: float = 0.1,
    ) -> None:
        self.compliance = compliance
        self.resistance = resistance
        self.dt = dt
        self._base_compliance = compliance
        self._base_resistance = resistance

    def step(self, P_insp: float, PEEP: float) -> dict:
        """Compute ventilation outputs for given pressure settings.

        Args:
            P_insp: Inspiratory pressure (cmH2O), typically 15-40.
            PEEP: Positive end-expiratory pressure (cmH2O), typically 0-24.

        Returns:
            Dict with tidal_volume (L), peak_pressure, plateau_pressure,
            driving_pressure (all cmH2O), and flow_rate (L/s).
        """
        driving = max(0.0, P_insp - PEEP)

        # Tidal volume: V = delta_P * C (mL), convert to L
        vt_mL = driving * self.compliance
        tidal_volume = vt_mL / 1000.0  # L

        # Plateau pressure (quasi-static): P_plat = VT/C + PEEP
        plateau_pressure = (tidal_volume * 1000.0) / max(1.0, self.compliance) + PEEP

        # Peak pressure (includes resistive component, simplified)
        peak_pressure = P_insp

        # Driving pressure (the key ARDS metric)
        driving_pressure = plateau_pressure - PEEP

        # Flow rate (peak inspiratory flow, simplified)
        flow_rate = driving / max(0.1, self.resistance)

        return {
            "tidal_volume": tidal_volume,
            "tidal_volume_mL": vt_mL,
            "peak_pressure": peak_pressure,
            "plateau_pressure": plateau_pressure,
            "driving_pressure": driving_pressure,
            "flow_rate": flow_rate,
        }

    def apply_variability(self, rng: np.random.Generator, fraction: float = 0.15) -> None:
        """Perturb compliance and resistance for inter-patient variability.

        Args:
            rng: Random number generator.
            fraction: Coefficient of variation (0.15 = 15%).
        """
        self.compliance = max(
            PARAMETER_RANGES["compliance"]["min"],
            self._base_compliance * (1.0 + rng.uniform(-fraction, fraction)),
        )
        self.resistance = max(
            PARAMETER_RANGES["resistance"]["min"],
            self._base_resistance * (1.0 + rng.uniform(-fraction, fraction)),
        )

    def reset(self) -> None:
        """Reset parameters to baseline values."""
        self.compliance = self._base_compliance
        self.resistance = self._base_resistance
