"""Virtual patient model for mechanical ventilation simulation.

Combines lung mechanics and gas exchange models into a unified patient
representation with ARDS severity levels based on the Berlin definition.

References:
    ARDS Definition Task Force (2012). Acute respiratory distress syndrome:
    the Berlin definition. JAMA, 307(23), 2526-2533.

    ARDSNet (2000). Ventilation with lower tidal volumes as compared with
    traditional tidal volumes for acute lung injury. NEJM, 342(18), 1301-1308.

    Amato, M. B. P., et al. (2015). Driving pressure and survival in the
    acute respiratory distress syndrome. NEJM, 372(8), 747-755.
"""

from __future__ import annotations

import numpy as np

from ventisim.models.gas_exchange import GasExchangeModel
from ventisim.models.lung_mechanics import SingleCompartmentLung

# ARDS severity tiers per Berlin definition (PaO2/FiO2 ratio thresholds)
# Compliance, resistance, and shunt values are population-level estimates.
ARDS_PROFILES = {
    "none": {
        "compliance": 60.0,
        "resistance": 8.0,
        "qs_qt": 0.05,
        "description": "Normal lungs, no ARDS",
    },
    "mild": {
        "compliance": 40.0,
        "resistance": 12.0,
        "qs_qt": 0.15,
        "description": "Mild ARDS (PaO2/FiO2 200-300)",
    },
    "moderate": {
        "compliance": 25.0,
        "resistance": 15.0,
        "qs_qt": 0.25,
        "description": "Moderate ARDS (PaO2/FiO2 100-200)",
    },
    "severe": {
        "compliance": 15.0,
        "resistance": 20.0,
        "qs_qt": 0.35,
        "description": "Severe ARDS (PaO2/FiO2 < 100)",
    },
}


class VirtualPatient:
    """Virtual patient combining lung mechanics and gas exchange.

    Provides a unified interface for simulating mechanical ventilation
    with physiologically consistent parameters derived from ARDS severity.

    Attributes:
        weight_kg: Patient weight in kg.
        height_cm: Patient height in cm.
        sex: Patient sex ('male' or 'female').
        ards_severity: One of 'none', 'mild', 'moderate', 'severe'.
        lung: SingleCompartmentLung model instance.
        gas_exchange: GasExchangeModel instance.
    """

    def __init__(
        self,
        weight_kg: float = 70.0,
        height_cm: float = 170.0,
        sex: str = "male",
        ards_severity: str = "moderate",
    ) -> None:
        if ards_severity not in ARDS_PROFILES:
            raise ValueError(
                f"Unknown ARDS severity: {ards_severity}. "
                f"Choose from: {list(ARDS_PROFILES.keys())}"
            )

        self.weight_kg = weight_kg
        self.height_cm = height_cm
        self.sex = sex
        self.ards_severity = ards_severity

        profile = ARDS_PROFILES[ards_severity]

        self.lung = SingleCompartmentLung(
            compliance=profile["compliance"],
            resistance=profile["resistance"],
        )
        self.gas_exchange = GasExchangeModel(
            qs_qt=profile["qs_qt"],
        )

    @property
    def ideal_body_weight(self) -> float:
        """Compute ideal body weight (IBW) using Devine formula.

        Male: IBW = 50 + 0.91 * (height_cm - 152.4)
        Female: IBW = 45.5 + 0.91 * (height_cm - 152.4)

        Returns:
            IBW in kg.
        """
        if self.sex == "male":
            return 50.0 + 0.91 * (self.height_cm - 152.4)
        return 45.5 + 0.91 * (self.height_cm - 152.4)

    @property
    def target_vt_ml(self) -> float:
        """Target tidal volume per ARDSNet low tidal volume strategy.

        6 mL/kg ideal body weight is the standard protective ventilation
        target for ARDS patients.

        Returns:
            Target VT in mL.
        """
        return 6.0 * self.ideal_body_weight

    def apply_drift(
        self,
        rng: np.random.Generator,
        step_num: int,
        max_steps: int,
    ) -> None:
        """Apply gradual compliance drift over time to simulate disease evolution.

        Models the slow deterioration or improvement of lung mechanics
        that occurs over hours in ARDS patients.

        Args:
            rng: Random number generator.
            step_num: Current simulation step.
            max_steps: Total number of steps in the episode.
        """
        if max_steps <= 0:
            return
        progress = step_num / max_steps
        # Small random walk in compliance (drift of up to 10% over episode)
        drift_scale = 0.1 * progress
        noise = rng.normal(0.0, max(0.001, drift_scale))
        new_compliance = self.lung.compliance * (1.0 + noise * 0.01)
        new_compliance = max(10.0, min(80.0, new_compliance))
        self.lung.compliance = new_compliance
