"""Integration tests: end-to-end workflows across components."""

import gymnasium as gym
import numpy as np
import pytest
import ventisim  # noqa: F401

from ventisim.models.patient import VirtualPatient
from ventisim.models.lung_mechanics import SingleCompartmentLung
from ventisim.models.gas_exchange import GasExchangeModel
from ventisim.envs.wrappers import NormalizeObservation, ClipAction


class TestModelIntegration:
    """Test that models work together correctly."""

    def test_lung_feeds_gas_exchange(self):
        lung = SingleCompartmentLung(compliance=25.0, resistance=15.0)
        ge = GasExchangeModel(qs_qt=0.25)
        result = lung.step(P_insp=22.0, PEEP=10.0)
        gases = ge.compute_gases(
            FiO2=0.6,
            VT_mL=result["tidal_volume_mL"],
            RR=18.0,
            PEEP=10.0,
            compliance=lung.compliance,
        )
        assert gases["PaO2"] > 0
        assert gases["PaCO2"] > 0
        assert gases["SpO2"] > 0

    def test_patient_lung_and_gas_exchange_consistent(self):
        patient = VirtualPatient(ards_severity="moderate")
        lung_result = patient.lung.step(P_insp=22.0, PEEP=10.0)
        gases = patient.gas_exchange.compute_gases(
            FiO2=0.6,
            VT_mL=lung_result["tidal_volume_mL"],
            RR=18.0,
            PEEP=10.0,
            compliance=patient.lung.compliance,
        )
        # PaO2 should be reasonable for moderate ARDS on FiO2 0.6
        assert gases["PaO2"] > 30.0

    def test_severity_progression(self):
        """Worse ARDS severity should produce worse oxygenation at same settings."""
        results = {}
        for severity in ["none", "mild", "moderate", "severe"]:
            patient = VirtualPatient(ards_severity=severity)
            lung_result = patient.lung.step(P_insp=22.0, PEEP=10.0)
            gases = patient.gas_exchange.compute_gases(
                FiO2=0.4,
                VT_mL=lung_result["tidal_volume_mL"],
                RR=15.0,
                PEEP=10.0,
                compliance=patient.lung.compliance,
            )
            results[severity] = gases["PaO2"]

        # PaO2 should generally decrease with severity
        # (not strictly guaranteed due to complex PEEP interactions, but directionally)
        assert results["none"] > results["severe"]

    def test_vt_decreases_with_severity_same_pressure(self):
        """Lower compliance (worse ARDS) should produce smaller VT at same pressure."""
        vts = {}
        for severity in ["none", "mild", "moderate", "severe"]:
            patient = VirtualPatient(ards_severity=severity)
            result = patient.lung.step(P_insp=20.0, PEEP=5.0)
            vts[severity] = result["tidal_volume"]

        assert vts["none"] > vts["mild"]
        assert vts["mild"] > vts["moderate"]
        assert vts["moderate"] > vts["severe"]


class TestEnvWrapperIntegration:
    def test_wrapped_tv_env_full_episode(self):
        base = gym.make("ventisim/TidalVolumeControl-v0")
        env = ClipAction(NormalizeObservation(base))
        obs, _ = env.reset(seed=42)
        assert np.all(obs >= -1.0) and np.all(obs <= 1.0)
        steps = 0
        done = False
        while not done and steps < 300:
            action = env.action_space.sample()
            obs, _, term, trunc, _ = env.step(action)
            assert np.all(obs >= -1.0) and np.all(obs <= 1.0)
            done = term or trunc
            steps += 1
        assert steps > 0
        env.close()

    def test_wrapped_full_env_episode(self):
        base = gym.make("ventisim/FullVentilatorManagement-v0")
        env = ClipAction(NormalizeObservation(base))
        obs, _ = env.reset(seed=42)
        assert obs.shape == (10,)
        steps = 0
        done = False
        while not done and steps < 400:
            action = env.action_space.sample()
            obs, _, term, trunc, _ = env.step(action)
            done = term or trunc
            steps += 1
        assert steps > 0
        env.close()


class TestMultiEpisode:
    """Run multiple episodes to check for state leaks."""

    @pytest.mark.parametrize("env_id", [
        "ventisim/TidalVolumeControl-v0",
        "ventisim/PEEPOptimization-v0",
        "ventisim/FullVentilatorManagement-v0",
    ])
    def test_no_state_leak_across_resets(self, env_id):
        env = gym.make(env_id)
        rewards_ep1 = []
        rewards_ep2 = []

        # Episode 1
        obs, _ = env.reset(seed=42)
        done = False
        while not done:
            action = env.action_space.sample()
            obs, r, term, trunc, _ = env.step(action)
            rewards_ep1.append(r)
            done = term or trunc

        # Episode 2 with same seed should produce same trajectory
        env2 = gym.make(env_id)
        obs, _ = env2.reset(seed=42)
        done = False
        idx = 0
        while not done and idx < len(rewards_ep1):
            action = env2.action_space.sample()  # different RNG state though
            obs, r, term, trunc, _ = env2.step(action)
            rewards_ep2.append(r)
            done = term or trunc
            idx += 1

        # Both should have finite rewards
        assert all(np.isfinite(r) for r in rewards_ep1)
        assert all(np.isfinite(r) for r in rewards_ep2)
        env.close()
        env2.close()
