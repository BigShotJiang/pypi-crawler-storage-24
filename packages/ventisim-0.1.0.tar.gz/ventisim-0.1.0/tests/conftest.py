import pytest
import gymnasium as gym
import ventisim  # noqa: F401


@pytest.fixture
def tv_env():
    env = gym.make("ventisim/TidalVolumeControl-v0")
    yield env
    env.close()


@pytest.fixture
def peep_env():
    env = gym.make("ventisim/PEEPOptimization-v0")
    yield env
    env.close()


@pytest.fixture
def full_env():
    env = gym.make("ventisim/FullVentilatorManagement-v0")
    yield env
    env.close()
