"""Tests for training configurations."""

import pytest

from ventisim.training.configs import ENV_CONFIGS


class TestEnvConfigs:
    def test_has_all_envs(self):
        expected = {
            "ventisim/TidalVolumeControl-v0",
            "ventisim/PEEPOptimization-v0",
            "ventisim/FullVentilatorManagement-v0",
        }
        assert set(ENV_CONFIGS.keys()) == expected

    def test_all_configs_have_required_keys(self):
        required_keys = {
            "total_timesteps", "learning_rate", "n_steps", "batch_size",
            "gamma", "gae_lambda", "clip_range", "ent_coef", "seed",
        }
        for env_id, config in ENV_CONFIGS.items():
            assert required_keys.issubset(set(config.keys())), (
                f"{env_id} missing keys: {required_keys - set(config.keys())}"
            )

    def test_learning_rates_positive(self):
        for env_id, config in ENV_CONFIGS.items():
            assert config["learning_rate"] > 0, f"{env_id}: lr <= 0"

    def test_gamma_in_range(self):
        for env_id, config in ENV_CONFIGS.items():
            assert 0.0 < config["gamma"] <= 1.0, f"{env_id}: gamma out of range"

    def test_clip_range_positive(self):
        for env_id, config in ENV_CONFIGS.items():
            assert config["clip_range"] > 0, f"{env_id}: clip_range <= 0"

    def test_total_timesteps_reasonable(self):
        for env_id, config in ENV_CONFIGS.items():
            assert config["total_timesteps"] >= 100_000, f"{env_id}: too few timesteps"

    def test_batch_size_divides_n_steps(self):
        for env_id, config in ENV_CONFIGS.items():
            assert config["n_steps"] % config["batch_size"] == 0, (
                f"{env_id}: n_steps not divisible by batch_size"
            )
