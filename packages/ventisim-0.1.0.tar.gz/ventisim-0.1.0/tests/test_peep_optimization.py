"""Tests for PEEPOptimizationEnv."""

import gymnasium as gym
import numpy as np
import pytest
import ventisim  # noqa: F401

from ventisim.envs.peep_optimization import PEEPOptimizationEnv, DIFFICULTY_TIERS


class TestPEEPOptimizationInit:
    def test_gym_make(self, peep_env):
        assert peep_env is not None

    def test_observation_space_shape(self, peep_env):
        assert peep_env.observation_space.shape == (8,)

    def test_action_space_shape(self, peep_env):
        assert peep_env.action_space.shape == (1,)

    def test_action_space_bounds(self, peep_env):
        assert peep_env.action_space.low[0] == pytest.approx(-2.0)
        assert peep_env.action_space.high[0] == pytest.approx(2.0)

    def test_default_fio2(self):
        env = PEEPOptimizationEnv()
        assert env.FiO2 == 0.6
        env.close()


class TestPEEPOptimizationReset:
    def test_reset_returns_valid_obs(self, peep_env):
        obs, info = peep_env.reset(seed=42)
        assert obs.shape == (8,)
        assert isinstance(info, dict)

    def test_reset_obs_within_space(self, peep_env):
        obs, _ = peep_env.reset(seed=42)
        assert peep_env.observation_space.contains(obs), f"Obs out of space: {obs}"

    def test_reset_initializes_peep_to_10(self):
        env = PEEPOptimizationEnv()
        env.reset(seed=42)
        assert env.current_PEEP == 10.0
        env.close()

    def test_reset_deterministic(self, peep_env):
        obs1, _ = peep_env.reset(seed=42)
        obs2, _ = peep_env.reset(seed=42)
        np.testing.assert_array_equal(obs1, obs2)


class TestPEEPOptimizationStep:
    def test_step_returns_correct_types(self, peep_env):
        peep_env.reset(seed=42)
        action = peep_env.action_space.sample()
        obs, reward, terminated, truncated, info = peep_env.step(action)
        assert isinstance(obs, np.ndarray)
        assert isinstance(reward, float)
        assert isinstance(terminated, bool)
        assert isinstance(truncated, bool)
        assert isinstance(info, dict)

    def test_peep_accumulates(self):
        env = PEEPOptimizationEnv(difficulty="easy")
        env.reset(seed=42)
        initial_peep = env.current_PEEP
        env.step(np.array([2.0], dtype=np.float32))
        assert env.current_PEEP == pytest.approx(initial_peep + 2.0)
        env.close()

    def test_peep_clamped_low(self):
        env = PEEPOptimizationEnv(difficulty="easy")
        env.reset(seed=42)
        # Drive PEEP to 0
        for _ in range(20):
            env.step(np.array([-2.0], dtype=np.float32))
        assert env.current_PEEP >= 0.0
        env.close()

    def test_peep_clamped_high(self):
        env = PEEPOptimizationEnv(difficulty="easy")
        env.reset(seed=42)
        # Drive PEEP up
        for _ in range(20):
            env.step(np.array([2.0], dtype=np.float32))
        assert env.current_PEEP <= 24.0
        env.close()

    def test_obs_within_space(self, peep_env):
        peep_env.reset(seed=42)
        for _ in range(50):
            obs, _, term, trunc, _ = peep_env.step(peep_env.action_space.sample())
            assert peep_env.observation_space.contains(obs), f"Obs out of space: {obs}"
            if term or trunc:
                break

    def test_info_keys(self, peep_env):
        peep_env.reset(seed=42)
        _, _, _, _, info = peep_env.step(np.array([0.0], dtype=np.float32))
        expected_keys = {"PaO2", "PaCO2", "SpO2", "PEEP", "driving_pressure",
                         "in_target", "target_fraction"}
        assert expected_keys.issubset(set(info.keys()))


class TestPEEPOptimizationReward:
    def test_stability_bonus(self):
        env = PEEPOptimizationEnv(difficulty="easy")
        env.reset(seed=42)
        # Zero change should get stability bonus
        _, r1, _, _, _ = env.step(np.array([0.0], dtype=np.float32))
        env.reset(seed=42)
        _, r2, _, _, _ = env.step(np.array([2.0], dtype=np.float32))
        # r1 should have the +0.1 bonus that r2 does not
        # (assuming same oxygenation rewards, r1 should be slightly higher)

    def test_spo2_penalty(self):
        # With very low PEEP on severe ARDS, SpO2 might drop
        env = PEEPOptimizationEnv(difficulty="easy", ards_severity="severe")
        env.reset(seed=42)
        # Drive PEEP very low
        for _ in range(10):
            obs, reward, term, _, info = env.step(np.array([-2.0], dtype=np.float32))
            if term:
                break
        env.close()


class TestPEEPOptimizationTermination:
    def test_termination_on_severe_hypoxemia(self):
        # With severe ARDS and very low PEEP, PaO2 may drop below 40
        env = PEEPOptimizationEnv(difficulty="easy", ards_severity="severe",
                                   FiO2=0.21, P_insp=15.0)
        env.reset(seed=42)
        terminated = False
        for _ in range(50):
            _, _, terminated, _, info = env.step(np.array([-2.0], dtype=np.float32))
            if terminated:
                break
        # May or may not terminate depending on exact physiology
        env.close()

    def test_truncation_at_max_steps(self):
        env = PEEPOptimizationEnv(difficulty="easy", max_steps=5)
        env.reset(seed=42)
        for _ in range(5):
            _, _, terminated, truncated, _ = env.step(np.array([0.0], dtype=np.float32))
            if terminated:
                break
        if not terminated:
            assert truncated
        env.close()


class TestPEEPOptimizationDifficulty:
    def test_difficulty_easy(self):
        env = PEEPOptimizationEnv(difficulty="easy")
        assert env._variability == 0.0
        assert env._noise_std == 0.0
        env.close()

    def test_difficulty_hard(self):
        env = PEEPOptimizationEnv(difficulty="hard")
        assert env._variability == 0.3
        assert env._compliance_drift is True
        env.close()
