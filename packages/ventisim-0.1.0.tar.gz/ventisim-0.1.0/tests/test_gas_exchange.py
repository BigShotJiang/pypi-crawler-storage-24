"""Tests for GasExchangeModel."""

import math

import numpy as np
import pytest

from ventisim.models.gas_exchange import GasExchangeModel


class TestGasExchangeInit:
    def test_default_parameters(self):
        ge = GasExchangeModel()
        assert ge.qs_qt == 0.1
        assert ge.vco2 == 200.0
        assert ge.vd == 150.0
        assert ge.rq == 0.8

    def test_custom_parameters(self):
        ge = GasExchangeModel(qs_qt=0.3, vco2=250.0, vd=180.0, rq=0.85)
        assert ge.qs_qt == 0.3
        assert ge.vco2 == 250.0
        assert ge.vd == 180.0
        assert ge.rq == 0.85


class TestComputeGases:
    def test_returns_dict(self):
        ge = GasExchangeModel()
        result = ge.compute_gases(FiO2=0.4, VT_mL=400.0, RR=15.0, PEEP=10.0, compliance=50.0)
        assert isinstance(result, dict)

    def test_has_required_keys(self):
        ge = GasExchangeModel()
        result = ge.compute_gases(FiO2=0.4, VT_mL=400.0, RR=15.0, PEEP=10.0, compliance=50.0)
        assert "PaO2" in result
        assert "PaCO2" in result
        assert "SpO2" in result
        assert "PAO2" in result

    def test_pao2_positive(self):
        ge = GasExchangeModel()
        result = ge.compute_gases(FiO2=0.4, VT_mL=400.0, RR=15.0, PEEP=10.0, compliance=50.0)
        assert result["PaO2"] >= 0.0

    def test_paco2_clamped(self):
        ge = GasExchangeModel()
        result = ge.compute_gases(FiO2=0.4, VT_mL=400.0, RR=15.0, PEEP=10.0, compliance=50.0)
        assert 15.0 <= result["PaCO2"] <= 120.0

    def test_spo2_in_range(self):
        ge = GasExchangeModel()
        result = ge.compute_gases(FiO2=0.4, VT_mL=400.0, RR=15.0, PEEP=10.0, compliance=50.0)
        assert 0.0 <= result["SpO2"] <= 100.0

    def test_higher_fio2_increases_pao2(self):
        ge = GasExchangeModel()
        r1 = ge.compute_gases(FiO2=0.3, VT_mL=400.0, RR=15.0, PEEP=10.0, compliance=50.0)
        r2 = ge.compute_gases(FiO2=0.8, VT_mL=400.0, RR=15.0, PEEP=10.0, compliance=50.0)
        assert r2["PaO2"] > r1["PaO2"]

    def test_higher_rr_decreases_paco2(self):
        ge = GasExchangeModel()
        r1 = ge.compute_gases(FiO2=0.4, VT_mL=400.0, RR=10.0, PEEP=10.0, compliance=50.0)
        r2 = ge.compute_gases(FiO2=0.4, VT_mL=400.0, RR=25.0, PEEP=10.0, compliance=50.0)
        assert r2["PaCO2"] < r1["PaCO2"]

    def test_higher_vt_decreases_paco2(self):
        ge = GasExchangeModel()
        r1 = ge.compute_gases(FiO2=0.4, VT_mL=300.0, RR=15.0, PEEP=10.0, compliance=50.0)
        r2 = ge.compute_gases(FiO2=0.4, VT_mL=600.0, RR=15.0, PEEP=10.0, compliance=50.0)
        assert r2["PaCO2"] < r1["PaCO2"]

    def test_higher_shunt_decreases_pao2(self):
        ge_low = GasExchangeModel(qs_qt=0.05)
        ge_high = GasExchangeModel(qs_qt=0.4)
        r1 = ge_low.compute_gases(FiO2=0.4, VT_mL=400.0, RR=15.0, PEEP=10.0, compliance=50.0)
        r2 = ge_high.compute_gases(FiO2=0.4, VT_mL=400.0, RR=15.0, PEEP=10.0, compliance=50.0)
        assert r2["PaO2"] < r1["PaO2"]

    def test_very_low_vt_causes_high_paco2(self):
        ge = GasExchangeModel()
        # VT below dead space should cause very high PaCO2
        result = ge.compute_gases(FiO2=0.4, VT_mL=100.0, RR=15.0, PEEP=10.0, compliance=50.0)
        assert result["PaCO2"] > 60.0

    def test_normal_physiology_range(self):
        # Normal patient on room air: PaO2 ~80-100, PaCO2 ~35-45
        ge = GasExchangeModel(qs_qt=0.05)
        result = ge.compute_gases(FiO2=0.21, VT_mL=500.0, RR=15.0, PEEP=5.0, compliance=60.0)
        assert result["PaO2"] > 50.0  # Should be reasonable on room air
        assert result["PaCO2"] < 60.0  # Should not be severely elevated

    def test_pao2_always_float(self):
        ge = GasExchangeModel()
        result = ge.compute_gases(FiO2=0.4, VT_mL=400.0, RR=15.0, PEEP=10.0, compliance=50.0)
        assert isinstance(result["PaO2"], float)

    def test_paco2_always_float(self):
        ge = GasExchangeModel()
        result = ge.compute_gases(FiO2=0.4, VT_mL=400.0, RR=15.0, PEEP=10.0, compliance=50.0)
        assert isinstance(result["PaCO2"], float)


class TestPEEPEffect:
    def test_returns_float(self):
        ge = GasExchangeModel()
        result = ge.peep_effect(10.0, 50.0)
        assert isinstance(result, float)

    def test_in_valid_range(self):
        ge = GasExchangeModel()
        for peep in [0.0, 5.0, 10.0, 15.0, 20.0, 24.0]:
            for comp in [15.0, 25.0, 40.0, 60.0]:
                result = ge.peep_effect(peep, comp)
                assert 0.0 <= result <= 1.0, f"PEEP={peep}, C={comp}: shunt={result}"

    def test_zero_peep_higher_shunt(self):
        ge = GasExchangeModel(qs_qt=0.3)
        low_peep = ge.peep_effect(0.0, 25.0)
        mid_peep = ge.peep_effect(10.0, 25.0)
        # Low PEEP should generally mean less recruitment (higher shunt)
        assert low_peep >= mid_peep

    def test_excessive_peep_increases_shunt(self):
        ge = GasExchangeModel(qs_qt=0.3)
        # Very high PEEP should cause overdistension
        optimal = ge.peep_effect(12.0, 25.0)
        excessive = ge.peep_effect(24.0, 25.0)
        # High PEEP overdistension should increase effective shunt
        assert excessive >= optimal * 0.5  # at least not dramatically better

    def test_stiffer_lungs_need_more_peep(self):
        ge = GasExchangeModel(qs_qt=0.3)
        # With low compliance, higher PEEP should help more
        shunt_at_5 = ge.peep_effect(5.0, 15.0)  # severe ARDS, low PEEP
        shunt_at_15 = ge.peep_effect(15.0, 15.0)  # severe ARDS, higher PEEP
        assert shunt_at_15 <= shunt_at_5

    def test_deterministic(self):
        ge = GasExchangeModel()
        r1 = ge.peep_effect(10.0, 30.0)
        r2 = ge.peep_effect(10.0, 30.0)
        assert r1 == r2


class TestSpO2FromPaO2:
    def test_zero_pao2_gives_zero_spo2(self):
        assert GasExchangeModel.spo2_from_pao2(0.0) == 0.0

    def test_negative_pao2_gives_zero_spo2(self):
        assert GasExchangeModel.spo2_from_pao2(-10.0) == 0.0

    def test_high_pao2_gives_near_100(self):
        spo2 = GasExchangeModel.spo2_from_pao2(100.0)
        assert spo2 > 95.0

    def test_very_high_pao2_clamped(self):
        spo2 = GasExchangeModel.spo2_from_pao2(500.0)
        assert spo2 <= 100.0

    def test_sigmoid_shape(self):
        # SpO2 should be monotonically increasing with PaO2
        prev = 0.0
        for pao2 in [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]:
            spo2 = GasExchangeModel.spo2_from_pao2(float(pao2))
            assert spo2 >= prev
            prev = spo2

    def test_p50_approximately_correct(self):
        # At PaO2 = 26.6 (P50), SpO2 should be approximately 50%
        spo2 = GasExchangeModel.spo2_from_pao2(26.6)
        assert 45.0 <= spo2 <= 55.0

    def test_clinically_relevant_range(self):
        # PaO2 = 60 mmHg should give SpO2 around 88-92%
        spo2 = GasExchangeModel.spo2_from_pao2(60.0)
        assert 85.0 <= spo2 <= 95.0

    def test_returns_float(self):
        result = GasExchangeModel.spo2_from_pao2(80.0)
        assert isinstance(result, float)
