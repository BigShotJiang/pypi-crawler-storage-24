"""Tests for SingleCompartmentLung model."""

import numpy as np
import pytest

from ventisim.models.lung_mechanics import SingleCompartmentLung, PARAMETER_RANGES


class TestSingleCompartmentLungInit:
    def test_default_parameters(self):
        lung = SingleCompartmentLung()
        assert lung.compliance == 50.0
        assert lung.resistance == 10.0
        assert lung.dt == 0.1

    def test_custom_parameters(self):
        lung = SingleCompartmentLung(compliance=30.0, resistance=15.0, dt=0.05)
        assert lung.compliance == 30.0
        assert lung.resistance == 15.0
        assert lung.dt == 0.05

    def test_base_parameters_stored(self):
        lung = SingleCompartmentLung(compliance=40.0, resistance=12.0)
        assert lung._base_compliance == 40.0
        assert lung._base_resistance == 12.0


class TestSingleCompartmentLungStep:
    def test_step_returns_dict(self):
        lung = SingleCompartmentLung()
        result = lung.step(P_insp=20.0, PEEP=5.0)
        assert isinstance(result, dict)

    def test_step_has_required_keys(self):
        lung = SingleCompartmentLung()
        result = lung.step(P_insp=20.0, PEEP=5.0)
        expected_keys = {
            "tidal_volume", "tidal_volume_mL", "peak_pressure",
            "plateau_pressure", "driving_pressure", "flow_rate",
        }
        assert set(result.keys()) == expected_keys

    def test_tidal_volume_positive(self):
        lung = SingleCompartmentLung()
        result = lung.step(P_insp=20.0, PEEP=5.0)
        assert result["tidal_volume"] > 0.0

    def test_tidal_volume_increases_with_pressure(self):
        lung = SingleCompartmentLung()
        r1 = lung.step(P_insp=15.0, PEEP=5.0)
        r2 = lung.step(P_insp=25.0, PEEP=5.0)
        assert r2["tidal_volume"] > r1["tidal_volume"]

    def test_tidal_volume_increases_with_compliance(self):
        lung_stiff = SingleCompartmentLung(compliance=20.0)
        lung_compliant = SingleCompartmentLung(compliance=60.0)
        r1 = lung_stiff.step(P_insp=20.0, PEEP=5.0)
        r2 = lung_compliant.step(P_insp=20.0, PEEP=5.0)
        assert r2["tidal_volume"] > r1["tidal_volume"]

    def test_zero_driving_pressure_gives_zero_vt(self):
        lung = SingleCompartmentLung()
        result = lung.step(P_insp=10.0, PEEP=10.0)
        assert result["tidal_volume"] == pytest.approx(0.0)

    def test_negative_driving_pressure_gives_zero_vt(self):
        lung = SingleCompartmentLung()
        result = lung.step(P_insp=5.0, PEEP=10.0)
        assert result["tidal_volume"] == pytest.approx(0.0)

    def test_peak_pressure_equals_p_insp(self):
        lung = SingleCompartmentLung()
        result = lung.step(P_insp=25.0, PEEP=5.0)
        assert result["peak_pressure"] == 25.0

    def test_driving_pressure_calculation(self):
        lung = SingleCompartmentLung()
        result = lung.step(P_insp=20.0, PEEP=5.0)
        expected_dp = result["plateau_pressure"] - 5.0
        assert result["driving_pressure"] == pytest.approx(expected_dp, abs=0.01)

    def test_plateau_pressure_consistent(self):
        lung = SingleCompartmentLung(compliance=50.0)
        result = lung.step(P_insp=20.0, PEEP=5.0)
        # VT = (20-5)*50 = 750 mL, P_plat = 750/50 + 5 = 20
        assert result["plateau_pressure"] == pytest.approx(20.0, abs=0.01)

    def test_flow_rate_positive(self):
        lung = SingleCompartmentLung()
        result = lung.step(P_insp=20.0, PEEP=5.0)
        assert result["flow_rate"] > 0.0

    def test_flow_rate_decreases_with_resistance(self):
        lung_low_r = SingleCompartmentLung(resistance=5.0)
        lung_high_r = SingleCompartmentLung(resistance=20.0)
        r1 = lung_low_r.step(P_insp=20.0, PEEP=5.0)
        r2 = lung_high_r.step(P_insp=20.0, PEEP=5.0)
        assert r1["flow_rate"] > r2["flow_rate"]

    def test_vt_mL_is_vt_times_1000(self):
        lung = SingleCompartmentLung()
        result = lung.step(P_insp=20.0, PEEP=5.0)
        assert result["tidal_volume_mL"] == pytest.approx(
            result["tidal_volume"] * 1000.0, abs=0.01
        )

    def test_known_value_normal_lungs(self):
        # Normal compliance 50, P_insp 20, PEEP 5: VT = 15*50/1000 = 0.75 L
        lung = SingleCompartmentLung(compliance=50.0)
        result = lung.step(P_insp=20.0, PEEP=5.0)
        assert result["tidal_volume"] == pytest.approx(0.75, abs=0.01)

    def test_known_value_ards_lungs(self):
        # Severe ARDS compliance 15, P_insp 30, PEEP 12: VT = 18*15/1000 = 0.27 L
        lung = SingleCompartmentLung(compliance=15.0)
        result = lung.step(P_insp=30.0, PEEP=12.0)
        assert result["tidal_volume"] == pytest.approx(0.27, abs=0.01)


class TestSingleCompartmentLungVariability:
    def test_apply_variability_changes_parameters(self):
        lung = SingleCompartmentLung()
        rng = np.random.default_rng(42)
        original_c = lung.compliance
        original_r = lung.resistance
        lung.apply_variability(rng, fraction=0.3)
        # At least one should change (extremely unlikely both stay exactly same)
        assert lung.compliance != original_c or lung.resistance != original_r

    def test_variability_respects_parameter_ranges(self):
        lung = SingleCompartmentLung(compliance=12.0, resistance=6.0)
        rng = np.random.default_rng(42)
        for _ in range(100):
            lung.apply_variability(rng, fraction=0.5)
            assert lung.compliance >= PARAMETER_RANGES["compliance"]["min"]
            assert lung.resistance >= PARAMETER_RANGES["resistance"]["min"]

    def test_zero_variability_preserves_base(self):
        lung = SingleCompartmentLung()
        rng = np.random.default_rng(42)
        lung.apply_variability(rng, fraction=0.0)
        assert lung.compliance == lung._base_compliance
        assert lung.resistance == lung._base_resistance

    def test_variability_deterministic_with_seed(self):
        lung1 = SingleCompartmentLung()
        lung2 = SingleCompartmentLung()
        rng1 = np.random.default_rng(99)
        rng2 = np.random.default_rng(99)
        lung1.apply_variability(rng1, 0.2)
        lung2.apply_variability(rng2, 0.2)
        assert lung1.compliance == lung2.compliance
        assert lung1.resistance == lung2.resistance


class TestSingleCompartmentLungReset:
    def test_reset_restores_base(self):
        lung = SingleCompartmentLung(compliance=40.0, resistance=12.0)
        rng = np.random.default_rng(42)
        lung.apply_variability(rng, 0.3)
        lung.reset()
        assert lung.compliance == 40.0
        assert lung.resistance == 12.0


class TestParameterRanges:
    def test_parameter_ranges_have_required_keys(self):
        for name, params in PARAMETER_RANGES.items():
            assert "min" in params
            assert "max" in params
            assert "unit" in params
            assert "source" in params
            assert "default" in params

    def test_min_less_than_max(self):
        for name, params in PARAMETER_RANGES.items():
            assert params["min"] < params["max"], f"{name}: min >= max"

    def test_default_within_range(self):
        for name, params in PARAMETER_RANGES.items():
            assert params["min"] <= params["default"] <= params["max"], (
                f"{name}: default {params['default']} not in [{params['min']}, {params['max']}]"
            )
