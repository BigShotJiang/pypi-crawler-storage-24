"""Tests for environment wrappers."""

import gymnasium as gym
import numpy as np
import pytest
import ventisim  # noqa: F401

from ventisim.envs.wrappers import NormalizeObservation, ClipAction


class TestNormalizeObservation:
    def test_output_shape_preserved(self):
        env = NormalizeObservation(gym.make("ventisim/TidalVolumeControl-v0"))
        obs, _ = env.reset(seed=42)
        assert obs.shape == (7,)
        env.close()

    def test_output_in_normalized_range(self):
        env = NormalizeObservation(gym.make("ventisim/TidalVolumeControl-v0"))
        obs, _ = env.reset(seed=42)
        assert np.all(obs >= -1.0)
        assert np.all(obs <= 1.0)
        env.close()

    def test_normalized_space_bounds(self):
        env = NormalizeObservation(gym.make("ventisim/TidalVolumeControl-v0"))
        np.testing.assert_array_equal(env.observation_space.low, -np.ones(7))
        np.testing.assert_array_equal(env.observation_space.high, np.ones(7))
        env.close()

    def test_step_returns_normalized(self):
        env = NormalizeObservation(gym.make("ventisim/TidalVolumeControl-v0"))
        env.reset(seed=42)
        obs, _, _, _, _ = env.step(env.action_space.sample())
        assert np.all(obs >= -1.0)
        assert np.all(obs <= 1.0)
        env.close()

    def test_dtype_is_float32(self):
        env = NormalizeObservation(gym.make("ventisim/TidalVolumeControl-v0"))
        obs, _ = env.reset(seed=42)
        assert obs.dtype == np.float32
        env.close()

    def test_works_with_peep_env(self):
        env = NormalizeObservation(gym.make("ventisim/PEEPOptimization-v0"))
        obs, _ = env.reset(seed=42)
        assert obs.shape == (8,)
        assert np.all(obs >= -1.0)
        assert np.all(obs <= 1.0)
        env.close()

    def test_works_with_full_env(self):
        env = NormalizeObservation(gym.make("ventisim/FullVentilatorManagement-v0"))
        obs, _ = env.reset(seed=42)
        assert obs.shape == (10,)
        assert np.all(obs >= -1.0)
        assert np.all(obs <= 1.0)
        env.close()


class TestClipAction:
    def test_clips_above_max(self):
        env = ClipAction(gym.make("ventisim/TidalVolumeControl-v0"))
        env.reset(seed=42)
        # Action above max should be clipped
        action = np.array([100.0], dtype=np.float32)
        obs, _, _, _, _ = env.step(action)
        # Should not crash
        env.close()

    def test_clips_below_min(self):
        env = ClipAction(gym.make("ventisim/TidalVolumeControl-v0"))
        env.reset(seed=42)
        action = np.array([-10.0], dtype=np.float32)
        obs, _, _, _, _ = env.step(action)
        env.close()

    def test_passthrough_valid_action(self):
        env = ClipAction(gym.make("ventisim/TidalVolumeControl-v0"))
        env.reset(seed=42)
        action = np.array([20.0], dtype=np.float32)
        obs, _, _, _, _ = env.step(action)
        env.close()

    def test_clips_multi_dim_action(self):
        env = ClipAction(gym.make("ventisim/FullVentilatorManagement-v0"))
        env.reset(seed=42)
        action = np.array([2.0, 50.0, 100.0, 100.0], dtype=np.float32)
        obs, _, _, _, _ = env.step(action)
        env.close()


class TestWrapperChain:
    def test_normalize_then_clip(self):
        base = gym.make("ventisim/TidalVolumeControl-v0")
        env = ClipAction(NormalizeObservation(base))
        obs, _ = env.reset(seed=42)
        assert obs.shape == (7,)
        assert np.all(obs >= -1.0)
        assert np.all(obs <= 1.0)
        obs2, _, _, _, _ = env.step(np.array([20.0], dtype=np.float32))
        assert np.all(obs2 >= -1.0)
        assert np.all(obs2 <= 1.0)
        env.close()

    def test_wrapper_chain_full_env(self):
        base = gym.make("ventisim/FullVentilatorManagement-v0")
        env = ClipAction(NormalizeObservation(base))
        obs, _ = env.reset(seed=42)
        assert obs.shape == (10,)
        action = np.array([0.5, 10.0, 18.0, 22.0], dtype=np.float32)
        obs2, r, t, tr, info = env.step(action)
        assert np.all(obs2 >= -1.0)
        assert np.all(obs2 <= 1.0)
        env.close()
