"""Tests for benchmark infrastructure."""

import pytest

from ventisim.benchmarks.environments import BENCHMARK_ENVS
from ventisim.benchmarks.runner import run_benchmarks


class TestBenchmarkEnvironments:
    def test_benchmark_envs_not_empty(self):
        assert len(BENCHMARK_ENVS) > 0

    def test_benchmark_envs_count(self):
        assert len(BENCHMARK_ENVS) == 3

    def test_benchmark_envs_have_required_keys(self):
        for bench in BENCHMARK_ENVS:
            assert "env_id" in bench
            assert "name" in bench
            assert "difficulty_tiers" in bench
            assert "description" in bench

    def test_benchmark_env_ids_valid(self):
        expected_ids = {
            "ventisim/TidalVolumeControl-v0",
            "ventisim/PEEPOptimization-v0",
            "ventisim/FullVentilatorManagement-v0",
        }
        actual_ids = {b["env_id"] for b in BENCHMARK_ENVS}
        assert actual_ids == expected_ids

    def test_all_have_three_difficulty_tiers(self):
        for bench in BENCHMARK_ENVS:
            assert set(bench["difficulty_tiers"]) == {"easy", "medium", "hard"}


class TestBenchmarkRunner:
    def test_run_benchmarks_returns_dict(self):
        results = run_benchmarks(n_episodes=2, seed=42)
        assert isinstance(results, dict)

    def test_run_benchmarks_all_envs(self):
        results = run_benchmarks(n_episodes=2, seed=42)
        assert len(results) == 3

    def test_run_benchmarks_has_random_and_heuristic(self):
        results = run_benchmarks(n_episodes=2, seed=42)
        for name, data in results.items():
            assert "random" in data
            assert "heuristic" in data
            assert "mean_reward" in data["random"]
            assert "std_reward" in data["random"]
            assert "mean_reward" in data["heuristic"]
            assert "std_reward" in data["heuristic"]
