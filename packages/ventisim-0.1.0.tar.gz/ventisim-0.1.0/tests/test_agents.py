"""Tests for agent baselines."""

import numpy as np
import pytest

from ventisim.agents.random_agent import evaluate_random
from ventisim.agents.heuristic import (
    evaluate_heuristic,
    _tidal_volume_heuristic,
    _peep_optimization_heuristic,
    _full_ventilator_heuristic,
    HEURISTIC_MAP,
)


class TestRandomAgent:
    def test_returns_dict(self):
        result = evaluate_random("ventisim/TidalVolumeControl-v0", n_episodes=3, seed=42)
        assert isinstance(result, dict)

    def test_has_required_keys(self):
        result = evaluate_random("ventisim/TidalVolumeControl-v0", n_episodes=3, seed=42)
        assert "mean_reward" in result
        assert "std_reward" in result
        assert "episode_rewards" in result

    def test_episode_count_matches(self):
        result = evaluate_random("ventisim/TidalVolumeControl-v0", n_episodes=5, seed=42)
        assert len(result["episode_rewards"]) == 5

    def test_mean_matches_episodes(self):
        result = evaluate_random("ventisim/TidalVolumeControl-v0", n_episodes=5, seed=42)
        assert result["mean_reward"] == pytest.approx(
            np.mean(result["episode_rewards"]), abs=0.01
        )

    def test_std_matches_episodes(self):
        result = evaluate_random("ventisim/TidalVolumeControl-v0", n_episodes=5, seed=42)
        assert result["std_reward"] == pytest.approx(
            np.std(result["episode_rewards"]), abs=0.01
        )

    def test_returns_finite_rewards(self):
        result = evaluate_random("ventisim/TidalVolumeControl-v0", n_episodes=3, seed=42)
        assert all(np.isfinite(r) for r in result["episode_rewards"])

    def test_works_on_peep_env(self):
        result = evaluate_random("ventisim/PEEPOptimization-v0", n_episodes=3, seed=42)
        assert len(result["episode_rewards"]) == 3

    def test_works_on_full_env(self):
        result = evaluate_random("ventisim/FullVentilatorManagement-v0", n_episodes=3, seed=42)
        assert len(result["episode_rewards"]) == 3


class TestHeuristicActions:
    def test_tv_heuristic_returns_correct_shape(self):
        obs = np.array([0.3, 15.0, 25.0, 15.0, 0.36, 0.5, 0.5], dtype=np.float32)
        action = _tidal_volume_heuristic(obs)
        assert action.shape == (1,)

    def test_tv_heuristic_in_action_bounds(self):
        obs = np.array([0.3, 15.0, 25.0, 15.0, 0.36, 0.5, 0.5], dtype=np.float32)
        action = _tidal_volume_heuristic(obs)
        assert 5.0 <= action[0] <= 40.0

    def test_peep_heuristic_returns_correct_shape(self):
        obs = np.array([80.0, 40.0, 10.0, 25.0, 20.0, 10.0, 0.6, 95.0], dtype=np.float32)
        action = _peep_optimization_heuristic(obs)
        assert action.shape == (1,)

    def test_peep_heuristic_increase_on_hypoxemia(self):
        obs = np.array([45.0, 40.0, 10.0, 25.0, 20.0, 10.0, 0.6, 85.0], dtype=np.float32)
        action = _peep_optimization_heuristic(obs)
        assert action[0] > 0  # should increase PEEP

    def test_peep_heuristic_decrease_on_hyperoxia(self):
        obs = np.array([150.0, 40.0, 10.0, 25.0, 20.0, 10.0, 0.6, 99.0], dtype=np.float32)
        action = _peep_optimization_heuristic(obs)
        assert action[0] < 0  # should decrease PEEP

    def test_peep_heuristic_hold_in_range(self):
        obs = np.array([80.0, 40.0, 10.0, 25.0, 20.0, 10.0, 0.6, 96.0], dtype=np.float32)
        action = _peep_optimization_heuristic(obs)
        assert action[0] == pytest.approx(0.0)

    def test_full_heuristic_returns_correct_shape(self):
        obs = np.zeros(10, dtype=np.float32)
        obs[0] = 80.0  # PaO2
        obs[1] = 40.0  # PaCO2
        obs[4] = 10.0  # PEEP
        obs[8] = 0.6   # FiO2
        action = _full_ventilator_heuristic(obs)
        assert action.shape == (4,)

    def test_full_heuristic_in_action_bounds(self):
        obs = np.zeros(10, dtype=np.float32)
        obs[0] = 80.0
        obs[1] = 40.0
        obs[4] = 10.0
        obs[8] = 0.6
        action = _full_ventilator_heuristic(obs)
        assert 0.21 <= action[0] <= 1.0   # FiO2
        assert 0.0 <= action[1] <= 24.0    # PEEP
        assert 8.0 <= action[2] <= 35.0    # RR
        assert 10.0 <= action[3] <= 40.0   # P_insp


class TestHeuristicAgent:
    def test_returns_dict(self):
        result = evaluate_heuristic("ventisim/TidalVolumeControl-v0", n_episodes=3, seed=42)
        assert isinstance(result, dict)

    def test_has_required_keys(self):
        result = evaluate_heuristic("ventisim/TidalVolumeControl-v0", n_episodes=3, seed=42)
        assert "mean_reward" in result
        assert "std_reward" in result
        assert "episode_rewards" in result

    def test_episode_count_matches(self):
        result = evaluate_heuristic("ventisim/PEEPOptimization-v0", n_episodes=5, seed=42)
        assert len(result["episode_rewards"]) == 5

    def test_heuristic_returns_finite_rewards_tv(self):
        result = evaluate_heuristic("ventisim/TidalVolumeControl-v0", n_episodes=5, seed=42)
        assert all(np.isfinite(r) for r in result["episode_rewards"])

    def test_unknown_env_raises(self):
        with pytest.raises(Exception):
            evaluate_heuristic("ventisim/FakeEnv-v0", n_episodes=1, seed=42)

    def test_heuristic_map_has_all_envs(self):
        expected_envs = {
            "ventisim/TidalVolumeControl-v0",
            "ventisim/PEEPOptimization-v0",
            "ventisim/FullVentilatorManagement-v0",
        }
        assert expected_envs == set(HEURISTIC_MAP.keys())

    def test_deterministic_with_seed(self):
        r1 = evaluate_heuristic("ventisim/TidalVolumeControl-v0", n_episodes=3, seed=42)
        r2 = evaluate_heuristic("ventisim/TidalVolumeControl-v0", n_episodes=3, seed=42)
        assert r1["mean_reward"] == pytest.approx(r2["mean_reward"], abs=0.01)
