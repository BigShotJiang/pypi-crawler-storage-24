"""Tests for Gymnasium environment registration."""

import gymnasium as gym
import numpy as np
import pytest
import ventisim  # noqa: F401


class TestRegistration:
    def test_tv_env_registered(self):
        env = gym.make("ventisim/TidalVolumeControl-v0")
        assert env is not None
        env.close()

    def test_peep_env_registered(self):
        env = gym.make("ventisim/PEEPOptimization-v0")
        assert env is not None
        env.close()

    def test_full_env_registered(self):
        env = gym.make("ventisim/FullVentilatorManagement-v0")
        assert env is not None
        env.close()

    def test_invalid_env_raises(self):
        with pytest.raises(gym.error.NameNotFound):
            gym.make("ventisim/NotAnEnv-v0")

    def test_version_exists(self):
        assert ventisim.__version__ == "0.1.0"


class TestFullEpisode:
    """Run complete episodes to ensure environments don't crash."""

    def test_tv_full_episode(self, tv_env):
        obs, _ = tv_env.reset(seed=42)
        total_reward = 0.0
        steps = 0
        done = False
        while not done and steps < 300:
            action = tv_env.action_space.sample()
            obs, reward, terminated, truncated, info = tv_env.step(action)
            total_reward += reward
            done = terminated or truncated
            steps += 1
        assert steps > 0
        assert np.isfinite(total_reward)

    def test_peep_full_episode(self, peep_env):
        obs, _ = peep_env.reset(seed=42)
        total_reward = 0.0
        steps = 0
        done = False
        while not done and steps < 300:
            action = peep_env.action_space.sample()
            obs, reward, terminated, truncated, info = peep_env.step(action)
            total_reward += reward
            done = terminated or truncated
            steps += 1
        assert steps > 0
        assert np.isfinite(total_reward)

    def test_full_ventilator_full_episode(self, full_env):
        obs, _ = full_env.reset(seed=42)
        total_reward = 0.0
        steps = 0
        done = False
        while not done and steps < 400:
            action = full_env.action_space.sample()
            obs, reward, terminated, truncated, info = full_env.step(action)
            total_reward += reward
            done = terminated or truncated
            steps += 1
        assert steps > 0
        assert np.isfinite(total_reward)

    def test_multiple_resets(self, tv_env):
        for seed in [1, 42, 100, 999]:
            obs, _ = tv_env.reset(seed=seed)
            assert obs.shape == (7,)
            obs2, _, _, _, _ = tv_env.step(tv_env.action_space.sample())
            assert obs2.shape == (7,)


class TestEnvGymCompliance:
    """Test Gymnasium API compliance for all environments."""

    @pytest.mark.parametrize("env_id", [
        "ventisim/TidalVolumeControl-v0",
        "ventisim/PEEPOptimization-v0",
        "ventisim/FullVentilatorManagement-v0",
    ])
    def test_reset_signature(self, env_id):
        env = gym.make(env_id)
        result = env.reset(seed=42)
        assert isinstance(result, tuple)
        assert len(result) == 2
        obs, info = result
        assert isinstance(obs, np.ndarray)
        assert isinstance(info, dict)
        env.close()

    @pytest.mark.parametrize("env_id", [
        "ventisim/TidalVolumeControl-v0",
        "ventisim/PEEPOptimization-v0",
        "ventisim/FullVentilatorManagement-v0",
    ])
    def test_step_signature(self, env_id):
        env = gym.make(env_id)
        env.reset(seed=42)
        result = env.step(env.action_space.sample())
        assert isinstance(result, tuple)
        assert len(result) == 5
        obs, reward, terminated, truncated, info = result
        assert isinstance(obs, np.ndarray)
        assert isinstance(reward, (float, int, np.floating))
        assert isinstance(terminated, (bool, np.bool_))
        assert isinstance(truncated, (bool, np.bool_))
        assert isinstance(info, dict)
        env.close()

    @pytest.mark.parametrize("env_id", [
        "ventisim/TidalVolumeControl-v0",
        "ventisim/PEEPOptimization-v0",
        "ventisim/FullVentilatorManagement-v0",
    ])
    def test_obs_space_contains_reset_obs(self, env_id):
        env = gym.make(env_id)
        obs, _ = env.reset(seed=42)
        assert env.observation_space.contains(obs)
        env.close()

    @pytest.mark.parametrize("env_id", [
        "ventisim/TidalVolumeControl-v0",
        "ventisim/PEEPOptimization-v0",
        "ventisim/FullVentilatorManagement-v0",
    ])
    def test_obs_space_contains_step_obs(self, env_id):
        env = gym.make(env_id)
        env.reset(seed=42)
        for _ in range(10):
            obs, _, term, trunc, _ = env.step(env.action_space.sample())
            assert env.observation_space.contains(obs), f"Obs out of space: {obs}"
            if term or trunc:
                break
        env.close()
