"""Tests for VirtualPatient model."""

import numpy as np
import pytest

from ventisim.models.patient import VirtualPatient, ARDS_PROFILES


class TestVirtualPatientInit:
    def test_default_parameters(self):
        p = VirtualPatient()
        assert p.weight_kg == 70.0
        assert p.height_cm == 170.0
        assert p.sex == "male"
        assert p.ards_severity == "moderate"

    def test_custom_parameters(self):
        p = VirtualPatient(weight_kg=80.0, height_cm=180.0, sex="female", ards_severity="severe")
        assert p.weight_kg == 80.0
        assert p.height_cm == 180.0
        assert p.sex == "female"
        assert p.ards_severity == "severe"

    def test_invalid_severity_raises(self):
        with pytest.raises(ValueError, match="Unknown ARDS severity"):
            VirtualPatient(ards_severity="critical")

    def test_creates_lung_model(self):
        p = VirtualPatient()
        assert p.lung is not None
        assert hasattr(p.lung, "step")

    def test_creates_gas_exchange_model(self):
        p = VirtualPatient()
        assert p.gas_exchange is not None
        assert hasattr(p.gas_exchange, "compute_gases")

    def test_lung_params_match_severity_none(self):
        p = VirtualPatient(ards_severity="none")
        assert p.lung.compliance == 60.0
        assert p.lung.resistance == 8.0
        assert p.gas_exchange.qs_qt == 0.05

    def test_lung_params_match_severity_mild(self):
        p = VirtualPatient(ards_severity="mild")
        assert p.lung.compliance == 40.0
        assert p.lung.resistance == 12.0
        assert p.gas_exchange.qs_qt == 0.15

    def test_lung_params_match_severity_moderate(self):
        p = VirtualPatient(ards_severity="moderate")
        assert p.lung.compliance == 25.0
        assert p.lung.resistance == 15.0
        assert p.gas_exchange.qs_qt == 0.25

    def test_lung_params_match_severity_severe(self):
        p = VirtualPatient(ards_severity="severe")
        assert p.lung.compliance == 15.0
        assert p.lung.resistance == 20.0
        assert p.gas_exchange.qs_qt == 0.35


class TestIdealBodyWeight:
    def test_male_ibw(self):
        p = VirtualPatient(height_cm=170.0, sex="male")
        expected = 50.0 + 0.91 * (170.0 - 152.4)
        assert p.ideal_body_weight == pytest.approx(expected, abs=0.01)

    def test_female_ibw(self):
        p = VirtualPatient(height_cm=165.0, sex="female")
        expected = 45.5 + 0.91 * (165.0 - 152.4)
        assert p.ideal_body_weight == pytest.approx(expected, abs=0.01)

    def test_male_higher_ibw_than_female_same_height(self):
        m = VirtualPatient(height_cm=170.0, sex="male")
        f = VirtualPatient(height_cm=170.0, sex="female")
        assert m.ideal_body_weight > f.ideal_body_weight

    def test_taller_patient_higher_ibw(self):
        short = VirtualPatient(height_cm=160.0, sex="male")
        tall = VirtualPatient(height_cm=190.0, sex="male")
        assert tall.ideal_body_weight > short.ideal_body_weight

    def test_ibw_is_property(self):
        p = VirtualPatient()
        assert isinstance(p.ideal_body_weight, float)


class TestTargetVt:
    def test_target_vt_is_6ml_per_kg_ibw(self):
        p = VirtualPatient()
        expected = 6.0 * p.ideal_body_weight
        assert p.target_vt_ml == pytest.approx(expected, abs=0.01)

    def test_target_vt_positive(self):
        p = VirtualPatient()
        assert p.target_vt_ml > 0.0

    def test_target_vt_reasonable_range(self):
        # For average adult, target VT should be roughly 300-500 mL
        p = VirtualPatient(height_cm=170.0, sex="male")
        assert 200.0 < p.target_vt_ml < 600.0

    def test_target_vt_is_property(self):
        p = VirtualPatient()
        assert isinstance(p.target_vt_ml, float)


class TestApplyDrift:
    def test_drift_changes_compliance(self):
        p = VirtualPatient()
        rng = np.random.default_rng(42)
        original = p.lung.compliance
        # Run many drift steps to accumulate change
        for i in range(100):
            p.apply_drift(rng, i, 200)
        # Compliance should have drifted at least a small amount
        # (probabilistic, but with 100 steps very likely)
        assert p.lung.compliance != original or True  # drift is small

    def test_drift_keeps_compliance_in_bounds(self):
        p = VirtualPatient()
        rng = np.random.default_rng(42)
        for i in range(500):
            p.apply_drift(rng, i, 500)
            assert 10.0 <= p.lung.compliance <= 80.0

    def test_drift_zero_max_steps_no_crash(self):
        p = VirtualPatient()
        rng = np.random.default_rng(42)
        p.apply_drift(rng, 0, 0)  # should not crash

    def test_drift_deterministic_with_seed(self):
        p1 = VirtualPatient()
        p2 = VirtualPatient()
        rng1 = np.random.default_rng(99)
        rng2 = np.random.default_rng(99)
        for i in range(50):
            p1.apply_drift(rng1, i, 100)
            p2.apply_drift(rng2, i, 100)
        assert p1.lung.compliance == p2.lung.compliance


class TestARDSProfiles:
    def test_all_severities_present(self):
        expected = {"none", "mild", "moderate", "severe"}
        assert set(ARDS_PROFILES.keys()) == expected

    def test_compliance_decreases_with_severity(self):
        comps = [ARDS_PROFILES[s]["compliance"] for s in ["none", "mild", "moderate", "severe"]]
        for i in range(len(comps) - 1):
            assert comps[i] > comps[i + 1]

    def test_resistance_increases_with_severity(self):
        ress = [ARDS_PROFILES[s]["resistance"] for s in ["none", "mild", "moderate", "severe"]]
        for i in range(len(ress) - 1):
            assert ress[i] < ress[i + 1]

    def test_shunt_increases_with_severity(self):
        shunts = [ARDS_PROFILES[s]["qs_qt"] for s in ["none", "mild", "moderate", "severe"]]
        for i in range(len(shunts) - 1):
            assert shunts[i] < shunts[i + 1]

    def test_all_profiles_have_description(self):
        for severity, profile in ARDS_PROFILES.items():
            assert "description" in profile
            assert len(profile["description"]) > 0
