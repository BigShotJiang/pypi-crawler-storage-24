"""Tests for TidalVolumeControlEnv."""

import gymnasium as gym
import numpy as np
import pytest
import ventisim  # noqa: F401

from ventisim.envs.tidal_volume_control import TidalVolumeControlEnv, DIFFICULTY_TIERS


class TestTidalVolumeControlEnvInit:
    def test_gym_make(self, tv_env):
        assert tv_env is not None

    def test_observation_space_shape(self, tv_env):
        assert tv_env.observation_space.shape == (7,)

    def test_action_space_shape(self, tv_env):
        assert tv_env.action_space.shape == (1,)

    def test_action_space_bounds(self, tv_env):
        assert tv_env.action_space.low[0] == pytest.approx(5.0)
        assert tv_env.action_space.high[0] == pytest.approx(40.0)

    def test_observation_space_dtype(self, tv_env):
        assert tv_env.observation_space.dtype == np.float32

    def test_action_space_dtype(self, tv_env):
        assert tv_env.action_space.dtype == np.float32


class TestTidalVolumeControlReset:
    def test_reset_returns_valid_obs(self, tv_env):
        obs, info = tv_env.reset(seed=42)
        assert obs.shape == (7,)
        assert isinstance(info, dict)

    def test_reset_obs_within_space(self, tv_env):
        obs, _ = tv_env.reset(seed=42)
        assert tv_env.observation_space.contains(obs), f"Obs out of space: {obs}"

    def test_reset_deterministic_with_seed(self, tv_env):
        obs1, _ = tv_env.reset(seed=123)
        obs2, _ = tv_env.reset(seed=123)
        np.testing.assert_array_equal(obs1, obs2)

    def test_reset_different_seeds_differ(self):
        env = gym.make("ventisim/TidalVolumeControl-v0", difficulty="hard")
        obs1, _ = env.reset(seed=1)
        obs2, _ = env.reset(seed=999)
        # With hard difficulty (variability), different seeds should give different obs
        # (compliance/resistance differ)
        env.close()
        # Note: with medium default, variability is 0.15 so they should differ


class TestTidalVolumeControlStep:
    def test_step_returns_correct_types(self, tv_env):
        tv_env.reset(seed=42)
        action = tv_env.action_space.sample()
        obs, reward, terminated, truncated, info = tv_env.step(action)
        assert isinstance(obs, np.ndarray)
        assert isinstance(reward, float)
        assert isinstance(terminated, bool)
        assert isinstance(truncated, bool)
        assert isinstance(info, dict)

    def test_step_obs_shape(self, tv_env):
        tv_env.reset(seed=42)
        obs, _, _, _, _ = tv_env.step(tv_env.action_space.sample())
        assert obs.shape == (7,)

    def test_step_obs_within_space(self, tv_env):
        tv_env.reset(seed=42)
        for _ in range(50):
            obs, _, term, trunc, _ = tv_env.step(tv_env.action_space.sample())
            assert tv_env.observation_space.contains(obs), f"Obs out of space: {obs}"
            if term or trunc:
                break

    def test_info_keys(self, tv_env):
        tv_env.reset(seed=42)
        _, _, _, _, info = tv_env.step(np.array([20.0], dtype=np.float32))
        expected_keys = {
            "tidal_volume_mL", "tidal_volume_L", "peak_pressure",
            "plateau_pressure", "driving_pressure", "target_vt_L",
            "vt_error_fraction", "in_target", "target_fraction",
        }
        assert expected_keys.issubset(set(info.keys()))


class TestTidalVolumeControlReward:
    def test_reward_in_target_range(self):
        # With easy difficulty, compliance 25, target ~0.36L
        # Need P_insp such that (P_insp - 10) * 25 / 1000 ~ 0.36
        # delta_P ~ 14.4, P_insp ~ 24.4
        env = TidalVolumeControlEnv(difficulty="easy", ards_severity="moderate")
        env.reset(seed=42)
        # The target VT depends on IBW, let's find it
        target = env._target_vt  # L
        # To hit target: P_insp = target * 1000 / compliance + PEEP
        needed_pressure = target * 1000.0 / env.patient.lung.compliance + env.PEEP
        action = np.array([np.clip(needed_pressure, 5.0, 40.0)], dtype=np.float32)
        _, reward, _, _, info = env.step(action)
        # Should get positive reward if we're within 10%
        if info["vt_error_fraction"] <= 0.10:
            assert reward > 0.0
        env.close()

    def test_reward_for_overdistension(self):
        # Very high pressure should give bad reward (plateau > 30)
        env = TidalVolumeControlEnv(difficulty="easy", ards_severity="none")
        env.reset(seed=42)
        _, reward, _, _, info = env.step(np.array([40.0], dtype=np.float32))
        # With compliance 60, PEEP 10: VT = 30*60/1000 = 1.8L, plateau = 30+10=40
        # Plateau > 30 -> -2.0 penalty
        if info["plateau_pressure"] > 30.0:
            assert reward < 0.0
        env.close()


class TestTidalVolumeControlTermination:
    def test_termination_on_overdistension(self):
        # Very high compliance + high pressure = huge VT
        env = TidalVolumeControlEnv(difficulty="easy", ards_severity="none")
        env.reset(seed=42)
        # compliance=60, PEEP=10, P_insp=40: VT = 30*60 = 1800 mL > 800
        _, _, terminated, _, info = env.step(np.array([40.0], dtype=np.float32))
        if info["tidal_volume_mL"] > 800.0:
            assert terminated

    def test_truncation_at_max_steps(self):
        env = TidalVolumeControlEnv(difficulty="easy", max_steps=5)
        env.reset(seed=42)
        for _ in range(5):
            _, _, terminated, truncated, _ = env.step(np.array([15.0], dtype=np.float32))
            if terminated:
                break
        if not terminated:
            assert truncated
        env.close()

    def test_no_early_termination_with_safe_pressure(self):
        env = TidalVolumeControlEnv(difficulty="easy", ards_severity="moderate")
        env.reset(seed=42)
        # moderate compliance=25, P_insp=15, PEEP=10: VT = 5*25 = 125 mL (safe)
        _, _, terminated, _, _ = env.step(np.array([15.0], dtype=np.float32))
        assert not terminated
        env.close()


class TestTidalVolumeControlDifficulty:
    def test_difficulty_easy(self):
        env = TidalVolumeControlEnv(difficulty="easy")
        assert env._variability == 0.0
        assert env._compliance_drift is False
        assert env._noise_std == 0.0
        env.close()

    def test_difficulty_medium(self):
        env = TidalVolumeControlEnv(difficulty="medium")
        assert env._variability == 0.15
        assert env._noise_std == 0.02
        env.close()

    def test_difficulty_hard(self):
        env = TidalVolumeControlEnv(difficulty="hard")
        assert env._variability == 0.3
        assert env._compliance_drift is True
        assert env._noise_std == 0.05
        env.close()

    def test_invalid_difficulty_uses_medium(self):
        env = TidalVolumeControlEnv(difficulty="extreme")
        assert env._variability == DIFFICULTY_TIERS["medium"]["variability"]
        env.close()


class TestTidalVolumeControlDeterminism:
    def test_deterministic_with_seed_easy(self):
        env1 = TidalVolumeControlEnv(difficulty="easy")
        env2 = TidalVolumeControlEnv(difficulty="easy")
        obs1, _ = env1.reset(seed=42)
        obs2, _ = env2.reset(seed=42)
        action = np.array([20.0], dtype=np.float32)
        r1 = env1.step(action)
        r2 = env2.step(action)
        np.testing.assert_array_almost_equal(r1[0], r2[0])
        assert r1[1] == pytest.approx(r2[1])
        env1.close()
        env2.close()
