"""Tests for FullVentilatorManagementEnv."""

import gymnasium as gym
import numpy as np
import pytest
import ventisim  # noqa: F401

from ventisim.envs.full_ventilator import FullVentilatorManagementEnv, DIFFICULTY_TIERS


class TestFullVentilatorInit:
    def test_gym_make(self, full_env):
        assert full_env is not None

    def test_observation_space_shape(self, full_env):
        assert full_env.observation_space.shape == (10,)

    def test_action_space_shape(self, full_env):
        assert full_env.action_space.shape == (4,)

    def test_action_space_bounds(self, full_env):
        expected_low = [0.21, 0.0, 8.0, 10.0]
        expected_high = [1.0, 24.0, 35.0, 40.0]
        for i, (lo, hi) in enumerate(zip(expected_low, expected_high)):
            assert full_env.action_space.low[i] == pytest.approx(lo, abs=0.01)
            assert full_env.action_space.high[i] == pytest.approx(hi, abs=0.01)

    def test_default_max_steps(self):
        env = FullVentilatorManagementEnv()
        assert env.max_steps == 300
        env.close()


class TestFullVentilatorReset:
    def test_reset_returns_valid_obs(self, full_env):
        obs, info = full_env.reset(seed=42)
        assert obs.shape == (10,)
        assert isinstance(info, dict)

    def test_reset_obs_within_space(self, full_env):
        obs, _ = full_env.reset(seed=42)
        assert full_env.observation_space.contains(obs), f"Obs out of space: {obs}"

    def test_reset_deterministic(self, full_env):
        obs1, _ = full_env.reset(seed=42)
        obs2, _ = full_env.reset(seed=42)
        np.testing.assert_array_equal(obs1, obs2)

    def test_reset_initializes_defaults(self):
        env = FullVentilatorManagementEnv()
        env.reset(seed=42)
        assert env._current_FiO2 == 0.6
        assert env._current_PEEP == 10.0
        assert env._current_RR == 20.0
        assert env._current_P_insp == 25.0
        env.close()


class TestFullVentilatorStep:
    def test_step_returns_correct_types(self, full_env):
        full_env.reset(seed=42)
        action = full_env.action_space.sample()
        obs, reward, terminated, truncated, info = full_env.step(action)
        assert isinstance(obs, np.ndarray)
        assert isinstance(reward, float)
        assert isinstance(terminated, bool)
        assert isinstance(truncated, bool)
        assert isinstance(info, dict)

    def test_step_obs_shape(self, full_env):
        full_env.reset(seed=42)
        obs, _, _, _, _ = full_env.step(full_env.action_space.sample())
        assert obs.shape == (10,)

    def test_obs_within_space_multi_step(self, full_env):
        full_env.reset(seed=42)
        for _ in range(50):
            obs, _, term, trunc, _ = full_env.step(full_env.action_space.sample())
            assert full_env.observation_space.contains(obs), f"Obs out of space: {obs}"
            if term or trunc:
                break

    def test_info_keys(self, full_env):
        full_env.reset(seed=42)
        action = np.array([0.5, 10.0, 18.0, 22.0], dtype=np.float32)
        _, _, _, _, info = full_env.step(action)
        expected_keys = {
            "PaO2", "PaCO2", "SpO2", "tidal_volume_L", "tidal_volume_mL",
            "PEEP", "FiO2", "RR", "P_insp", "plateau_pressure",
            "driving_pressure", "in_target", "target_fraction",
        }
        assert expected_keys.issubset(set(info.keys()))

    def test_actions_clipped(self):
        env = FullVentilatorManagementEnv(difficulty="easy")
        env.reset(seed=42)
        # Pass out-of-bounds actions
        action = np.array([2.0, 50.0, 100.0, 100.0], dtype=np.float32)
        _, _, _, _, info = env.step(action)
        assert info["FiO2"] <= 1.0
        assert info["PEEP"] <= 24.0
        assert info["RR"] <= 35.0
        assert info["P_insp"] <= 40.0
        env.close()


class TestFullVentilatorReward:
    def test_fio2_minimization_bonus(self):
        env = FullVentilatorManagementEnv(difficulty="easy")
        env.reset(seed=42)
        # Low FiO2 action
        action_low_fio2 = np.array([0.3, 10.0, 18.0, 22.0], dtype=np.float32)
        _, r1, _, _, _ = env.step(action_low_fio2)
        env.reset(seed=42)
        action_high_fio2 = np.array([0.8, 10.0, 18.0, 22.0], dtype=np.float32)
        _, r2, _, _, _ = env.step(action_high_fio2)
        # Low FiO2 gets +0.2 bonus (if oxygenation adequate)
        # But high FiO2 may give better oxygenation reward
        # Just check both return finite rewards
        assert np.isfinite(r1)
        assert np.isfinite(r2)
        env.close()

    def test_lung_protection_penalty(self):
        env = FullVentilatorManagementEnv(difficulty="easy", ards_severity="none")
        env.reset(seed=42)
        # Very high P_insp with normal lungs: high plateau
        action = np.array([0.5, 5.0, 18.0, 40.0], dtype=np.float32)
        _, reward, _, _, info = env.step(action)
        if info["plateau_pressure"] > 30.0:
            # Should have -1.0 penalty (plus possibly other penalties)
            pass  # reward structure is composite, hard to isolate
        env.close()


class TestFullVentilatorTermination:
    def test_termination_on_hypoxemia(self):
        # Severe ARDS, low FiO2, low PEEP -> PaO2 may drop below 40
        env = FullVentilatorManagementEnv(difficulty="easy", ards_severity="severe")
        env.reset(seed=42)
        terminated = False
        for _ in range(20):
            action = np.array([0.21, 0.0, 8.0, 12.0], dtype=np.float32)
            _, _, terminated, _, info = env.step(action)
            if terminated:
                assert info["PaO2"] < 40.0 or info["PaCO2"] > 80.0
                break
        env.close()

    def test_truncation_at_max_steps(self):
        env = FullVentilatorManagementEnv(difficulty="easy", max_steps=3)
        env.reset(seed=42)
        action = np.array([0.6, 10.0, 18.0, 22.0], dtype=np.float32)
        for _ in range(3):
            _, _, terminated, truncated, _ = env.step(action)
            if terminated:
                break
        if not terminated:
            assert truncated
        env.close()

    def test_no_termination_moderate_settings(self):
        env = FullVentilatorManagementEnv(difficulty="easy", ards_severity="moderate")
        env.reset(seed=42)
        # Reasonable settings
        action = np.array([0.6, 10.0, 18.0, 22.0], dtype=np.float32)
        _, _, terminated, _, _ = env.step(action)
        assert not terminated
        env.close()


class TestFullVentilatorDifficulty:
    def test_difficulty_easy(self):
        env = FullVentilatorManagementEnv(difficulty="easy")
        assert env._variability == 0.0
        assert env._compliance_drift is False
        env.close()

    def test_difficulty_medium(self):
        env = FullVentilatorManagementEnv(difficulty="medium")
        assert env._variability == 0.15
        env.close()

    def test_difficulty_hard(self):
        env = FullVentilatorManagementEnv(difficulty="hard")
        assert env._variability == 0.3
        assert env._compliance_drift is True
        env.close()
