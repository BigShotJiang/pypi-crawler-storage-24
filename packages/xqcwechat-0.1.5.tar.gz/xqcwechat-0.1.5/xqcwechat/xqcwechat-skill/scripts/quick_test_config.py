#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
快速测试脚本：验证环境配置是否正确

使用方法：
    python xqcwechat/xqcwechat-skill/scripts/quick_test_config.py

功能：
    - 检测 Token 获取方式
    - 识别配置的账号数量
    - 显示每个账号的 app_id 和缓存键
    - 测试每个账号的配置是否有效
"""

import sys
import os

script_dir = os.path.dirname(os.path.abspath(__file__))
skill_dir = os.path.dirname(script_dir)
project_root = os.path.dirname(skill_dir)
sys.path.insert(0, project_root)

from dotenv import load_dotenv

env_paths = []
skill_env = os.path.join(skill_dir, ".env")
if os.path.exists(skill_env):
    env_paths.append(skill_env)

project_env = os.path.join(project_root, ".env")
if os.path.exists(project_env):
    env_paths.append(project_env)

for env_path in env_paths:
    load_dotenv(env_path, override=True)


def detect_accounts():
    """检测配置的账号"""
    accounts = []
    account_num = 1

    while True:
        token_app_id = os.environ.get(f"WECHAT_ACCOUNT_{account_num}_TOKEN_APP_ID")
        app_id = os.environ.get(f"WECHAT_ACCOUNT_{account_num}_APP_ID")
        app_secret = os.environ.get(f"WECHAT_ACCOUNT_{account_num}_APP_SECRET")

        if token_app_id or (app_id and app_secret):
            accounts.append(
                {
                    "num": account_num,
                    "token_app_id": token_app_id,
                    "app_id": app_id,
                    "app_secret": app_secret,
                }
            )
            account_num += 1
        else:
            break

    return accounts


def test_config():
    print("=" * 60)
    print("xqcwechat 环境配置测试")
    print("=" * 60)

    token_secret = os.environ.get("WECHAT_TOKEN_SECRET") or os.environ.get(
        "WECHAT_GET_WECHAT_TOKEN_SECRET"
    )
    proxy = os.environ.get("WECHAT_PROXY")

    print("\n📋 Token 获取方式：")
    if token_secret:
        print("  ✅ 方式二：使用 Token Secret（默认回调函数）")
        print(f"     - WECHAT_TOKEN_SECRET: {token_secret[:10]}...")
    else:
        app_id = os.environ.get("WECHAT_APP_ID")
        app_secret = os.environ.get("WECHAT_APP_SECRET")
        if app_id and app_secret:
            print("  ✅ 方式一：使用微信官方 API")
            print(f"     - WECHAT_APP_ID: {app_id}")
        else:
            print("  ❌ 未配置有效的 Token 获取方式！")
            print("  请选择以下方式之一配置：")
            print("    方式一：配置 WECHAT_TOKEN_SECRET（推荐）")
            print("    方式二：配置 WECHAT_APP_ID + WECHAT_APP_SECRET")
            return False

    print("\n📋 代理配置：")
    print(f"  {'✅ 已配置' if proxy else '❌ 未配置'}")
    if proxy:
        print(f"     - WECHAT_PROXY: {proxy}")

    accounts = detect_accounts()
    print(f"\n📋 检测到 {len(accounts)} 个账号：")

    if not accounts:
        print("  ❌ 未检测到任何账号配置！")
        print(
            "  请配置 WECHAT_ACCOUNT_N_TOKEN_APP_ID 或 WECHAT_ACCOUNT_N_APP_ID + APP_SECRET"
        )
        return False

    from xqcwechat import Auth

    all_success = True
    for acc in accounts:
        print(f"\n  账号 {acc['num']}:")
        print(f"    - TOKEN_APP_ID: {acc['token_app_id'] or '未配置'}")
        print(f"    - APP_ID: {acc['app_id'] or '未配置'}")

        try:
            auth = Auth.from_env(str(acc["num"]))
            print(f"    - cache_key: {auth.cache_key}")
            print(f"    - app_id: {auth.app_id}")

            token = auth.get_access_token()
            print("    ✅ Token 获取成功！")
            print(f"       Token: {token[:20]}...")
        except Exception as e:
            print(f"    ❌ Token 获取失败：{str(e)}")
            all_success = False

    print("\n" + "=" * 60)
    if all_success:
        print("✅ 所有账号配置测试通过！")
    else:
        print("❌ 部分账号配置测试失败！")
    print("=" * 60)

    return all_success


if __name__ == "__main__":
    success = test_config()
    sys.exit(0 if success else 1)
