---
name: xqcwechat-skill
description: |
  微信公众号开发工具包，支持素材管理、草稿管理、发布管理和留言管理。
  当需要操作微信公众号时使用此Skill。

  **使用时机：**
  - 用户要求创建/发布微信公众号草稿
  - 用户要求上传图片/素材
  - 用户要求管理留言评论

  **配置提示：**
  - 使用 `Auth.from_env()` 自动加载配置，**请勿询问用户Token**
  - 环境变量加载顺序：skill目录/.env > 项目根目录/.env > 系统环境变量
---

# xqcwechat-skill

## 快速开始

```python
from xqcwechat import Auth

auth = Auth.from_env()  # 自动检测配置
draft = auth.get_draft()
```

详细配置说明见 [references/config.md](references/config.md)

## 工作流程

```
1. 读取 .env 配置 → 2. 确定Token获取方式 → 3. 单/多账号处理 → 4. 执行操作
```

### Token获取方式

| 方式   | 环境变量                                 | 说明         |
| ------ | ---------------------------------------- | ------------ |
| 方式一 | `WECHAT_ACCOUNT_N_APP_ID` + `APP_SECRET` | 微信官方API  |
| 方式二 | `WECHAT_TOKEN_SECRET`                    | 默认回调函数 |
| 方式三 | `WECHAT_TOKEN_GETTER_MODULE`             | 自定义回调   |

详细配置见 [references/config.md](references/config.md)

### 多账号

```python
# 方式1：AccountManager（推荐）
from xqcwechat import AccountManager
manager = AccountManager()
draft1 = manager.get_draft()      # 账号1
draft2 = manager.get_draft("2")   # 账号2

# 方式2：from_env指定账号
auth1 = Auth.from_env("1")
auth2 = Auth.from_env("2")
```

详细示例见 [references/examples.md](references/examples.md)

## 核心操作

### 上传→创建草稿→发布

```python
auth = Auth.from_env()
asset = Asset(auth)
draft = Draft(auth)
publish = Publish(auth)

# 1. 上传封面
cover = asset.add_material("image", "cover.jpg")
# 2. 上传正文图
image = asset.upload_image("image.jpg")
# 3. 创建草稿
result = draft.create_draft([{
    "title": "标题",
    "content": f"<img src='{image['url']}'>",
    "thumb_media_id": cover["media_id"],
    "show_cover_pic": 1
}])
# 4. 发布
publish.publish_draft(result["media_id"])
```

### 功能模块

| 模块      | 用途     | 关键方法                                         |
| --------- | -------- | ------------------------------------------------ |
| `Draft`   | 草稿管理 | `create_draft`, `get_draft_list`, `delete_draft` |
| `Publish` | 发布管理 | `publish_draft`, `get_published_articles`        |
| `Asset`   | 素材管理 | `upload_image`, `add_material`, `get_materials`  |
| `Comment` | 留言管理 | `list_comment`, `elect_comment`, `reply_comment` |

完整API见 [references/api_reference.md](references/api_reference.md)

## 快速脚本

| 脚本                    | 用途         |
| ----------------------- | ------------ |
| `quick_test_config.py`  | 测试配置     |
| `quick_create_draft.py` | 创建草稿     |
| `quick_list_drafts.py`  | 查看草稿列表 |
| `quick_publish.py`      | 发布草稿     |

```bash
python -m xqcwechat.scripts.quick_test_config
python -m xqcwechat.scripts.quick_create_draft "标题" "内容" cover.jpg
```

## 参考资料

- [references/config.md](references/config.md) - 环境变量配置详解
- [references/examples.md](references/examples.md) - 完整使用示例
- [references/api_reference.md](references/api_reference.md) - API参考
