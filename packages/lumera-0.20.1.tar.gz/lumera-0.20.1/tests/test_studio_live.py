import io
import json

import pytest
import requests

import lumera
import lumera._live as _live
import lumera._utils as _utils
import lumera.studio as studio


@pytest.fixture(autouse=True)
def reset_http_session() -> None:
    _utils._http_session = None
    yield
    _utils._http_session = None


class DummyResponse:
    def __init__(
        self,
        *,
        status_code: int = 200,
        json_data: dict | None = None,
        text: str | None = None,
        headers: dict[str, str] | None = None,
        url: str | None = None,
    ) -> None:
        self.status_code = status_code
        self._json_data = json_data
        self._text = (
            text if text is not None else (json.dumps(json_data) if json_data is not None else "")
        )
        self.headers = headers or {
            "Content-Type": "application/json" if json_data is not None else "text/plain"
        }
        self.url = url or "https://app.lumerahq.com/api/studio/live/start"

    @property
    def ok(self) -> bool:
        return 200 <= self.status_code < 300

    def json(self) -> dict:
        if self._json_data is None:
            raise ValueError("no json payload")
        return self._json_data

    @property
    def text(self) -> str:
        return self._text

    def raise_for_status(self) -> None:
        if not self.ok:
            raise requests.HTTPError(response=self)


class DummyStreamResponse(DummyResponse):
    def __init__(self, *, lines: list[str], **kwargs: object) -> None:
        super().__init__(**kwargs)
        self._lines = lines

    def __enter__(self) -> "DummyStreamResponse":
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> bool:
        return False

    def iter_lines(self, decode_unicode: bool = False):
        del decode_unicode
        for line in self._lines:
            yield line


def test_studio_module_exported_at_package_root() -> None:
    assert hasattr(lumera, "studio")


def test_studio_start_live_returns_handle(monkeypatch: pytest.MonkeyPatch) -> None:
    captured: dict[str, object] = {}

    def fake_api(method: str, path: str, **kwargs: object) -> dict[str, object]:
        captured["method"] = method
        captured["path"] = path
        captured["kwargs"] = kwargs
        return {
            "status": "accepted",
            "session_id": "default",
            "request_id": "req_studio_1",
        }

    monkeypatch.setattr(studio, "_api_request", fake_api)

    run = studio.start_live(
        "collections-agent",
        "Add an aging report",
        model="openai/gpt-5-mini",
        system_prompt="Be concise.",
    )

    assert run.project == "collections-agent"
    assert run.session_id == "default"
    assert run.request_id == "req_studio_1"
    assert run.status == "accepted"

    assert captured["method"] == "POST"
    assert captured["path"] == "studio/live/start"
    kwargs = captured["kwargs"]
    assert isinstance(kwargs, dict)
    payload = kwargs["json_body"]
    assert isinstance(payload, dict)
    assert payload == {
        "project": "collections-agent",
        "message": "Add an aging report",
        "model": "openai/gpt-5-mini",
        "system_prompt": "Be concise.",
    }


def test_studio_stream_and_print_stream(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv(_utils.TOKEN_ENV, "tok")
    captured: dict[str, object] = {}

    lines = [
        "id: 2:0",
        "event: snapshot",
        'data: {"sessionId":"default","streamEpoch":2,"status":"running","lastSeq":0,"requestId":"req_studio_1","assistant":{"content":"","blocks":[]},"toolCalls":[],"actions":[],"canContinue":false}',
        "",
        "id: 2:1",
        "event: text_delta",
        'data: {"type":"text_delta","delta":"Building aging report...","request_id":"req_studio_1"}',
        "",
        "id: 2:2",
        "event: done",
        'data: {"type":"done","success":true,"request_id":"req_studio_1"}',
        "",
    ]

    class MockSession:
        def request(self, method: str, url: str, **kwargs: object) -> DummyStreamResponse:
            captured["method"] = method
            captured["url"] = url
            captured["kwargs"] = kwargs
            return DummyStreamResponse(
                lines=lines,
                headers={"Content-Type": "text/event-stream"},
                url=str(url),
            )

        def mount(self, prefix: str, adapter: object) -> None:
            del prefix, adapter

    monkeypatch.setattr(_live, "_get_session", lambda: MockSession())

    def fake_get_live_state(project: str, *, session_id: str | None = None, timeout: int = 30):
        assert project == "collections-agent"
        assert session_id == "default"
        del timeout
        return studio.StudioLiveState(
            {
                "sessionId": "default",
                "streamEpoch": 2,
                "status": "completed",
                "lastSeq": 2,
                "requestId": "req_studio_1",
                "assistant": {"content": "Building aging report...", "blocks": []},
                "toolCalls": [],
                "actions": [],
                "canContinue": False,
            }
        )

    monkeypatch.setattr(studio, "get_live_state", fake_get_live_state)

    run = studio.StudioLiveRun("collections-agent", "default", "req_studio_1", "accepted")
    out = io.StringIO()
    final = run.print_stream(file=out)

    rendered = out.getvalue()
    assert "Building aging report..." in rendered
    assert "[done] completed" in rendered
    assert final.status == "completed"
    assert run.last_event_id == "2:2"

    assert captured["method"] == "GET"
    assert str(captured["url"]).endswith("/studio/live/stream")
    kwargs = captured["kwargs"]
    assert isinstance(kwargs, dict)
    assert kwargs["params"] == {
        "project": "collections-agent",
        "session_id": "default",
        "request_id": "req_studio_1",
        "wait_ms": 10000,
    }
    headers = kwargs["headers"]
    assert isinstance(headers, dict)
    assert headers["Accept"] == "text/event-stream"
    assert headers["Authorization"] == "token tok"
