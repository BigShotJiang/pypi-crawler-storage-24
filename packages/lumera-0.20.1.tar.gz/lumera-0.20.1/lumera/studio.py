"""
Live Studio helpers for Lumera.

This module provides a thin live client for Studio project runs.
It is intentionally focused on the reconnectable `/live/*` APIs rather than
on a synchronous request/response wrapper.

Live invocation:
    start_live()     - Start a reconnectable live Studio run
    stream_live()    - Stream live SSE events for a Studio session/run
    get_live_state() - Read the latest live snapshot
    get_history()    - Read parsed durable session history
    abort_live()     - Abort the active run for a session
"""

from __future__ import annotations

import builtins
from typing import Any, Iterator, Mapping

__all__ = [
    "start_live",
    "stream_live",
    "get_live_state",
    "get_history",
    "abort_live",
    "StudioLiveState",
    "StudioLiveEnvelope",
    "StudioLiveRun",
    "StudioLiveStreamError",
]

from ._live import (
    LiveEnvelopeBase,
    LiveRunBase,
    LiveStateBase,
    LiveStreamError,
    _coerce_mapping,
    _normalize_session_id,
    _stream_live_request,
)
from ._utils import _api_request


class StudioLiveState(LiveStateBase):
    """Latest live snapshot for a Studio session."""


class StudioLiveEnvelope(LiveEnvelopeBase):
    """Single envelope from the Studio live SSE stream."""

    _state_cls = StudioLiveState


class StudioLiveStreamError(LiveStreamError):
    """Raised when a Studio live SSE stream ends before terminal state."""


class StudioLiveRun(LiveRunBase):
    """Thin live-run handle returned by :func:`start_live`."""

    def __init__(
        self,
        project: str,
        session_id: str,
        request_id: str | None,
        status: str,
        *,
        model: str | None = None,
    ) -> None:
        self.project = project
        self.model = model
        super().__init__(
            session_id=session_id,
            request_id=request_id,
            status=status,
            stream_fn=lambda **kwargs: stream_live(
                self.project,
                session_id=self.session_id,
                request_id=self.request_id,
                **kwargs,
            ),
            state_fn=lambda **kwargs: get_live_state(
                self.project,
                session_id=self.session_id,
                **kwargs,
            ),
            history_fn=lambda **kwargs: get_history(
                self.project,
                session_id=self.session_id,
                **kwargs,
            ),
            abort_fn=lambda **kwargs: abort_live(
                self.project,
                session_id=self.session_id,
                model=self.model,
                **kwargs,
            ),
        )

    def state(self, *, timeout: int = 30) -> StudioLiveState:
        state = get_live_state(self.project, session_id=self.session_id, timeout=timeout)
        if not self.request_id and state.request_id:
            self.request_id = state.request_id
        return state

    def stream(
        self,
        *,
        wait_ms: int | None = 10000,
        last_event_id: str | None = None,
        timeout: int = 300,
    ) -> Iterator[StudioLiveEnvelope]:
        return super().stream(wait_ms=wait_ms, last_event_id=last_event_id, timeout=timeout)

    def wait(self, *, timeout: int = 300, poll_interval: float = 0.5) -> StudioLiveState:
        return super().wait(timeout=timeout, poll_interval=poll_interval)

    def print_stream(
        self,
        *,
        show_tools: bool = True,
        show_thinking: bool = False,
        show_usage: bool = True,
        show_resets: bool = True,
        timestamps: bool = False,
        wait_ms: int | None = 10000,
        timeout: int = 300,
        file=None,
    ) -> StudioLiveState:
        return super().print_stream(
            show_tools=show_tools,
            show_thinking=show_thinking,
            show_usage=show_usage,
            show_resets=show_resets,
            timestamps=timestamps,
            wait_ms=wait_ms,
            timeout=timeout,
            file=file,
        )

    def __repr__(self) -> str:
        return (
            f"StudioLiveRun(project={self.project!r}, session_id={self.session_id!r}, "
            f"request_id={self.request_id!r}, status={self.status!r})"
        )


def start_live(
    project: str,
    message: str,
    *,
    session_id: str | None = None,
    model: str | None = None,
    system_prompt: str | None = None,
    timeout: int = 30,
) -> StudioLiveRun:
    """Start a reconnectable live run for a Studio project."""
    payload: dict[str, Any] = {
        "project": project,
        "message": message,
    }
    if session_id:
        payload["session_id"] = session_id
    if model:
        payload["model"] = model
    if system_prompt:
        payload["system_prompt"] = system_prompt

    result = _api_request(
        "POST",
        "studio/live/start",
        json_body=payload,
        timeout=timeout,
    )
    data = _coerce_mapping(result, name="studio live start")
    return StudioLiveRun(
        project=project,
        session_id=data.get("session_id", _normalize_session_id(session_id)),
        request_id=data.get("request_id"),
        status=data.get("status", ""),
        model=model,
    )


def get_live_state(project: str, *, session_id: str | None = None, timeout: int = 30) -> StudioLiveState:
    """Fetch the latest live snapshot for a Studio session."""
    result = _api_request(
        "GET",
        "studio/live/state",
        params={
            "project": project,
            "session_id": _normalize_session_id(session_id),
        },
        timeout=timeout,
    )
    return StudioLiveState(_coerce_mapping(result, name="studio live state"))


def get_history(
    project: str,
    *,
    session_id: str | None = None,
    timeout: int = 30,
) -> list[dict[str, Any]]:
    """Fetch parsed durable session history for a Studio session."""
    result = _api_request(
        "GET",
        "studio/history",
        params={
            "project": project,
            "session_id": _normalize_session_id(session_id),
        },
        timeout=timeout,
    )
    data = _coerce_mapping(result, name="studio history")
    messages = data.get("messages")
    if not isinstance(messages, builtins.list):
        raise RuntimeError(f"Unexpected studio history response: messages={type(messages)!r}")
    return [dict(m) if isinstance(m, Mapping) else {"value": m} for m in messages]


def abort_live(
    project: str,
    *,
    session_id: str | None = None,
    model: str | None = None,
    timeout: int = 30,
) -> bool:
    """Abort the active run for a Studio session."""
    params: dict[str, Any] = {
        "project": project,
        "session_id": _normalize_session_id(session_id),
    }
    if model:
        params["model"] = model
    result = _api_request(
        "POST",
        "studio/abort",
        params=params,
        timeout=timeout,
    )
    data = _coerce_mapping(result, name="studio abort")
    return bool(data.get("success", False))


def stream_live(
    project: str,
    *,
    session_id: str | None = None,
    request_id: str | None = None,
    wait_ms: int | None = 10000,
    last_event_id: str | None = None,
    timeout: int = 300,
) -> Iterator[StudioLiveEnvelope]:
    """Stream live SSE envelopes for a Studio session/run."""
    if wait_ms is not None and wait_ms < 0:
        raise ValueError("wait_ms must be >= 0")

    params: dict[str, Any] = {
        "project": project,
        "session_id": _normalize_session_id(session_id),
    }
    if request_id:
        params["request_id"] = request_id
    if wait_ms is not None:
        params["wait_ms"] = wait_ms

    yield from _stream_live_request(
        "studio/live/stream",
        params=params,
        last_event_id=last_event_id,
        timeout=timeout,
        envelope_cls=StudioLiveEnvelope,
        error_cls=StudioLiveStreamError,
    )
