"""Shared thin live-client helpers for Lumera SDK modules."""

from __future__ import annotations

import builtins
import json
import sys
import time
from typing import Any, Callable, IO, Iterator, Mapping

from ._utils import _api_headers, _api_url, _get_session, _raise_api_error

_TERMINAL_LIVE_STATUSES = {"completed", "failed", "interrupted", "aborted"}
_TERMINAL_LIVE_EVENT_TYPES = {"done", "error"}


class LiveStreamError(RuntimeError):
    """Raised when a live SSE stream ends before a terminal state is observed."""

    def __init__(self, message: str, *, event_count: int = 0) -> None:
        super().__init__(message)
        self.event_count = event_count


class LiveStateBase:
    """Thin wrapper over the sandbox live-state snapshot JSON."""

    def __init__(self, data: Mapping[str, Any]) -> None:
        self._data = dict(data)

    @property
    def session_id(self) -> str:
        return _as_str(self._data.get("sessionId"))

    @property
    def stream_epoch(self) -> int:
        return _as_int(self._data.get("streamEpoch"))

    @property
    def status(self) -> str:
        return _as_str(self._data.get("status"))

    @property
    def last_seq(self) -> int:
        return _as_int(self._data.get("lastSeq"))

    @property
    def request_id(self) -> str | None:
        return _as_optional_str(self._data.get("requestId"))

    @property
    def session_name(self) -> str | None:
        return _as_optional_str(self._data.get("sessionName"))

    @property
    def trace_id(self) -> str | None:
        return _as_optional_str(self._data.get("traceId"))

    @property
    def surface(self) -> str | None:
        return _as_optional_str(self._data.get("surface"))

    @property
    def scope_id(self) -> str | None:
        return _as_optional_str(self._data.get("scopeId"))

    @property
    def actor_email(self) -> str | None:
        return _as_optional_str(self._data.get("actorEmail"))

    @property
    def user_message(self) -> str | None:
        return _as_optional_str(self._data.get("userMessage"))

    @property
    def assistant(self) -> dict[str, Any]:
        value = self._data.get("assistant")
        return dict(value) if isinstance(value, Mapping) else {}

    @property
    def assistant_text(self) -> str:
        return _as_str(self.assistant.get("content"))

    @property
    def assistant_blocks(self) -> list[Any]:
        value = self.assistant.get("blocks")
        return builtins.list(value) if isinstance(value, builtins.list) else []

    @property
    def tool_calls(self) -> list[Any]:
        value = self._data.get("toolCalls")
        return builtins.list(value) if isinstance(value, builtins.list) else []

    @property
    def actions(self) -> list[Any]:
        value = self._data.get("actions")
        return builtins.list(value) if isinstance(value, builtins.list) else []

    @property
    def usage(self) -> dict[str, Any] | None:
        value = self._data.get("usage")
        return dict(value) if isinstance(value, Mapping) else None

    @property
    def error(self) -> str | None:
        return _as_optional_str(self._data.get("error"))

    @property
    def can_continue(self) -> bool:
        return bool(self._data.get("canContinue", False))

    @property
    def writer_heartbeat_at(self) -> str | None:
        return _as_optional_str(self._data.get("writerHeartbeatAt"))

    @property
    def updated_at(self) -> str | None:
        return _as_optional_str(self._data.get("updatedAt"))

    @property
    def is_terminal(self) -> bool:
        return self.status in _TERMINAL_LIVE_STATUSES

    @property
    def raw(self) -> dict[str, Any]:
        return dict(self._data)

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}(status={self.status!r}, session_id={self.session_id!r}, "
            f"request_id={self.request_id!r}, last_seq={self.last_seq})"
        )


class LiveEnvelopeBase:
    """Single SSE envelope from a live stream."""

    _state_cls = LiveStateBase

    def __init__(
        self,
        kind: str,
        *,
        event_id: str | None = None,
        event_name: str | None = None,
        payload: Mapping[str, Any] | None = None,
    ) -> None:
        self.kind = kind
        self.id = event_id
        self.event_name = event_name
        self._payload = dict(payload or {})

    @property
    def payload(self) -> dict[str, Any]:
        return dict(self._payload)

    @property
    def state(self) -> LiveStateBase | None:
        if self.kind != "snapshot":
            return None
        return self._state_cls(self._payload)

    @property
    def type(self) -> str | None:
        if self.kind != "event":
            return None
        return _as_optional_str(self._payload.get("type"))

    @property
    def delta(self) -> str | None:
        if self.kind != "event":
            return None
        return _as_optional_str(self._payload.get("delta"))

    @property
    def tool(self) -> str | None:
        if self.kind != "event":
            return None
        return _as_optional_str(self._payload.get("tool"))

    @property
    def message(self) -> str | None:
        if self.kind != "event":
            return None
        return _as_optional_str(self._payload.get("message"))

    @property
    def error(self) -> str | None:
        if self.kind == "snapshot":
            state = self.state
            return state.error if state is not None else None
        if self.kind != "event":
            return None
        return _as_optional_str(self._payload.get("error"))

    @property
    def request_id(self) -> str | None:
        if self.kind == "snapshot":
            state = self.state
            return state.request_id if state is not None else None
        return _as_optional_str(self._payload.get("request_id"))

    @property
    def trace_id(self) -> str | None:
        if self.kind == "snapshot":
            state = self.state
            return state.trace_id if state is not None else None
        return _as_optional_str(self._payload.get("trace_id"))

    @property
    def success(self) -> bool | None:
        if self.kind != "event":
            return None
        value = self._payload.get("success")
        return bool(value) if isinstance(value, bool) else None

    @property
    def usage(self) -> dict[str, Any] | None:
        if self.kind != "event":
            return None
        value = self._payload.get("usage")
        return dict(value) if isinstance(value, Mapping) else None

    @property
    def file(self) -> dict[str, Any] | None:
        if self.kind != "event":
            return None
        value = self._payload.get("file")
        return dict(value) if isinstance(value, Mapping) else None

    @property
    def is_terminal(self) -> bool:
        if self.kind == "snapshot":
            state = self.state
            return state.is_terminal if state is not None else False
        if self.kind != "event":
            return False
        evt_type = self.type
        return evt_type in _TERMINAL_LIVE_EVENT_TYPES if evt_type else False

    def __repr__(self) -> str:
        if self.kind == "snapshot":
            return f"{self.__class__.__name__}(kind='snapshot', id={self.id!r}, state={self.state!r})"
        return (
            f"{self.__class__.__name__}(kind={self.kind!r}, id={self.id!r}, "
            f"event_name={self.event_name!r}, type={self.type!r})"
        )


class LiveRunBase:
    """Shared thin live-run handle with stream/state/history/abort helpers."""

    def __init__(
        self,
        *,
        session_id: str,
        request_id: str | None,
        status: str,
        stream_fn: Callable[..., Iterator[LiveEnvelopeBase]],
        state_fn: Callable[..., LiveStateBase],
        history_fn: Callable[..., list[dict[str, Any]]],
        abort_fn: Callable[..., bool],
    ) -> None:
        self.session_id = session_id
        self.request_id = request_id
        self.status = status
        self.last_event_id: str | None = None
        self._stream_fn = stream_fn
        self._state_fn = state_fn
        self._history_fn = history_fn
        self._abort_fn = abort_fn

    def stream(
        self,
        *,
        wait_ms: int | None = 10000,
        last_event_id: str | None = None,
        timeout: int = 300,
    ) -> Iterator[LiveEnvelopeBase]:
        """Stream live envelopes for this run."""
        cursor = self.last_event_id if last_event_id is None else last_event_id
        for envelope in self._stream_fn(wait_ms=wait_ms, last_event_id=cursor, timeout=timeout):
            if envelope.id:
                self.last_event_id = envelope.id
            if not self.request_id and envelope.request_id:
                self.request_id = envelope.request_id
            yield envelope

    def state(self, *, timeout: int = 30) -> LiveStateBase:
        """Fetch the latest live snapshot for this run's session."""
        state = self._state_fn(timeout=timeout)
        if not self.request_id and state.request_id:
            self.request_id = state.request_id
        return state

    def history(self, *, timeout: int = 30) -> list[dict[str, Any]]:
        """Fetch parsed durable session history for this run's session."""
        return self._history_fn(timeout=timeout)

    def abort(self, *, timeout: int = 30) -> bool:
        """Abort the active run for this run's session."""
        return self._abort_fn(timeout=timeout)

    def wait(self, *, timeout: int = 300, poll_interval: float = 0.5) -> LiveStateBase:
        """Poll live state until the run reaches a terminal status."""
        if timeout <= 0:
            raise ValueError("timeout must be > 0")
        if poll_interval <= 0:
            raise ValueError("poll_interval must be > 0")

        deadline = time.monotonic() + timeout
        while True:
            state = self.state(timeout=30)
            if state.is_terminal:
                return state
            if time.monotonic() >= deadline:
                raise TimeoutError(
                    f"Timed out waiting for live run {self.request_id or self.session_id!r}"
                )
            remaining = deadline - time.monotonic()
            time.sleep(min(poll_interval, max(0.0, remaining)))

    def print_stream(
        self,
        *,
        show_tools: bool = True,
        show_thinking: bool = False,
        show_usage: bool = True,
        show_resets: bool = True,
        timestamps: bool = False,
        wait_ms: int | None = 10000,
        timeout: int = 300,
        file: IO[str] | None = None,
    ) -> LiveStateBase:
        """Convenience renderer for CLI / notebook live streaming.

        This is intentionally a thin default renderer over ``stream()``. It is
        useful for scripts and local debugging when you want to see what the
        agent or Studio run is doing without building your own event loop.
        """
        out = file or sys.stdout
        at_line_start = True
        started_at = time.monotonic()

        def _prefix() -> str:
            return f"[{time.strftime('%H:%M:%S')}] " if timestamps else ""

        def _write_text(text: str) -> None:
            nonlocal at_line_start
            if not text:
                return
            if at_line_start and timestamps:
                out.write(_prefix())
            out.write(text)
            out.flush()
            at_line_start = text.endswith("\n")

        def _write_line(text: str) -> None:
            nonlocal at_line_start
            if not at_line_start:
                out.write("\n")
            out.write(f"{_prefix()}{text}\n")
            out.flush()
            at_line_start = True

        for evt in self.stream(wait_ms=wait_ms, timeout=timeout):
            if evt.kind == "snapshot":
                continue
            if evt.kind == "reset":
                if show_resets:
                    _write_line("[reset] live cursor unavailable, resynced to latest state")
                continue
            evt_type = evt.type or evt.event_name or "event"
            if evt_type == "text_delta":
                _write_text(evt.delta or "")
                continue
            if evt_type == "thinking_delta":
                if show_thinking and evt.delta:
                    _write_line(f"[thinking] {evt.delta}")
                continue
            if evt_type == "tool_start":
                if show_tools:
                    _write_line(f"[tool:start] {evt.tool or 'tool'}")
                continue
            if evt_type == "tool_end":
                if show_tools:
                    if evt.success is False:
                        _write_line(f"[tool:error] {evt.tool or 'tool'}")
                    else:
                        _write_line(f"[tool:end] {evt.tool or 'tool'}")
                continue
            if evt_type == "tool_progress":
                if show_tools and evt.message:
                    _write_line(f"[tool:progress] {evt.message}")
                continue
            if evt_type == "usage":
                if show_usage and evt.usage is not None:
                    usage = evt.usage
                    _write_line(
                        "[usage] input={input} output={output} cacheRead={cache_read} cacheWrite={cache_write}".format(
                            input=usage.get("input", 0),
                            output=usage.get("output", 0),
                            cache_read=usage.get("cacheRead", 0),
                            cache_write=usage.get("cacheWrite", 0),
                        )
                    )
                continue
            if evt_type == "file_created":
                file_info = evt.file or {}
                name = file_info.get("name") or "artifact"
                _write_line(f"[file] {name}")
                continue
            if evt_type == "session_update":
                if evt.message:
                    _write_line(f"[session] {evt.message}")
                continue
            if evt_type == "info":
                if evt.message:
                    _write_line(f"[info] {evt.message}")
                continue
            if evt_type == "error":
                _write_line(f"[error] {evt.error or 'live run failed'}")
                continue
            if evt_type == "done":
                if evt.success is False:
                    _write_line("[done] failed")
                else:
                    _write_line("[done] completed")
                continue
            if evt.message:
                _write_line(f"[{evt_type}] {evt.message}")

        state = self.state(timeout=30)
        if state.is_terminal:
            return state

        remaining = max(0.1, timeout - (time.monotonic() - started_at))
        return self.wait(timeout=remaining)


def _stream_live_request(
    path: str,
    *,
    params: Mapping[str, Any],
    last_event_id: str | None,
    timeout: int,
    envelope_cls: type[LiveEnvelopeBase],
    error_cls: type[LiveStreamError],
) -> Iterator[LiveEnvelopeBase]:
    headers = _api_headers(accept="text/event-stream")
    if last_event_id:
        headers["Last-Event-ID"] = last_event_id

    session = _get_session()
    url = _api_url(path)

    with session.request("GET", url, params=params, headers=headers, stream=True, timeout=timeout) as resp:
        if not resp.ok:
            _raise_api_error(resp)

        event_count = 0
        saw_terminal = False
        current_event = "message"
        current_id: str | None = None
        current_data_lines: list[str] = []

        for line in resp.iter_lines(decode_unicode=True):
            if line is None:
                continue
            if line.startswith(":"):
                continue
            if line.startswith("event:"):
                current_event = line[6:].strip() or "message"
                continue
            if line.startswith("id:"):
                current_id = line[3:].strip() or None
                continue
            if line.startswith("data:"):
                value = line[5:]
                if value.startswith(" "):
                    value = value[1:]
                current_data_lines.append(value)
                continue
            if line != "":
                continue

            envelope = _finish_sse_frame(
                event_name=current_event,
                event_id=current_id,
                data_lines=current_data_lines,
                envelope_cls=envelope_cls,
                error_cls=error_cls,
            )
            current_event = "message"
            current_id = None
            current_data_lines = []
            if envelope is None:
                continue
            event_count += 1
            saw_terminal = saw_terminal or envelope.is_terminal
            yield envelope

        trailing = _finish_sse_frame(
            event_name=current_event,
            event_id=current_id,
            data_lines=current_data_lines,
            envelope_cls=envelope_cls,
            error_cls=error_cls,
        )
        if trailing is not None:
            event_count += 1
            saw_terminal = saw_terminal or trailing.is_terminal
            yield trailing

        if not saw_terminal:
            if event_count == 0 and last_event_id:
                return
            raise error_cls(
                (
                    "Live stream ended before any terminal state was observed"
                    if event_count > 0
                    else "Live stream ended before any events arrived"
                ),
                event_count=event_count,
            )


def _finish_sse_frame(
    *,
    event_name: str,
    event_id: str | None,
    data_lines: list[str],
    envelope_cls: type[LiveEnvelopeBase],
    error_cls: type[LiveStreamError],
) -> LiveEnvelopeBase | None:
    if not data_lines:
        return None

    raw = "\n".join(data_lines)
    try:
        payload_obj = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise error_cls(f"Failed to parse live stream payload for event {event_name!r}") from exc
    if not isinstance(payload_obj, Mapping):
        raise error_cls(
            f"Unexpected live stream payload type for event {event_name!r}: {type(payload_obj)!r}"
        )
    payload = dict(payload_obj)

    if event_name == "snapshot":
        return envelope_cls("snapshot", event_id=event_id, event_name=event_name, payload=payload)
    if event_name == "reset":
        return envelope_cls("reset", event_id=event_id, event_name=event_name, payload=payload)
    return envelope_cls("event", event_id=event_id, event_name=event_name, payload=payload)


def _normalize_session_id(session_id: str | None) -> str:
    if session_id and session_id.strip():
        return session_id.strip()
    return "default"


def _as_str(value: Any) -> str:
    return value if isinstance(value, str) else ""


def _as_optional_str(value: Any) -> str | None:
    if isinstance(value, str) and value.strip():
        return value
    return None


def _as_int(value: Any) -> int:
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    return 0


def _coerce_mapping(value: object, *, name: str) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        raise RuntimeError(f"Unexpected {name} response: expected object, got {type(value)!r}")
    return dict(value)
