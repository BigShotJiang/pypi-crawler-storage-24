"""
Lumera NetSuite Integration

Provides authenticated access to NetSuite's REST API and SuiteQL using
Lumera-managed credentials (either M2M Client Credentials or legacy OAuth).

Quick start::

    from lumera.integrations.netsuite import get_token, suiteql, NetSuiteClient

    # Simple: run a SuiteQL query
    rows = suiteql("SELECT id, fullname FROM account WHERE isinactive = 'F'")

    # Or use the client for full REST + SuiteQL access
    ns = NetSuiteClient()
    accounts = ns.suiteql("SELECT COUNT(*) AS cnt FROM account")
    je_id = ns.create_record("journalentry", payload)
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import requests

from lumera._utils import get_credentials


@dataclass
class NetSuiteToken:
    """An access token with the associated account ID."""

    access_token: str
    account_id: str


def get_token() -> NetSuiteToken:
    """Get a NetSuite access token via Lumera's credential management.

    Works with both M2M (Client Credentials) and legacy OAuth connections.
    Lumera handles token acquisition/refresh automatically.

    Returns:
        NetSuiteToken with ``access_token`` and ``account_id``.

    Raises:
        ValueError: If the account_id cannot be determined.
    """
    creds = get_credentials("netsuite")
    account_id = (creds.extra or {}).get("account_id", "")
    if not account_id:
        raise ValueError(
            "NetSuite account_id not returned by Lumera. "
            "Ensure the NetSuite M2M connection is configured."
        )
    return NetSuiteToken(access_token=creds.token, account_id=account_id)


# Alias for discoverability (spec doc references this name).
get_m2m_token = get_token


def _base_url(account_id: str) -> str:
    return f"https://{account_id.lower()}.suitetalk.api.netsuite.com"


def suiteql(
    query: str,
    *,
    limit: int = 1000,
    offset: int = 0,
    all_pages: bool = True,
    timeout: int = 60,
) -> list[dict[str, Any]]:
    """Execute a SuiteQL query and return all result rows.

    Args:
        query: The SuiteQL query string.
        limit: Page size (max 1000).
        offset: Starting offset.
        all_pages: If True, automatically paginate through all results.
        timeout: HTTP request timeout in seconds.

    Returns:
        List of row dicts from the ``items`` array.
    """
    tok = get_token()
    url = f"{_base_url(tok.account_id)}/services/rest/query/v1/suiteql"
    headers = {
        "Authorization": f"Bearer {tok.access_token}",
        "Content-Type": "application/json",
        "Prefer": "transient",
    }

    all_items: list[dict[str, Any]] = []
    current_offset = offset

    while True:
        resp = requests.post(
            url,
            json={"q": query},
            headers=headers,
            params={"limit": limit, "offset": current_offset},
            timeout=timeout,
        )
        if not resp.ok:
            raise NetSuiteAPIError(resp.status_code, resp.text[:500])

        data = resp.json()
        items = data.get("items", [])
        all_items.extend(items)

        if not all_pages or not data.get("hasMore", False):
            break
        current_offset += limit

    return all_items


class NetSuiteAPIError(Exception):
    """Raised when a NetSuite API call fails."""

    def __init__(self, status_code: int, body: str):
        self.status_code = status_code
        self.body = body
        super().__init__(f"NetSuite API error ({status_code}): {body}")


class NetSuiteClient:
    """High-level NetSuite REST API client using Lumera-managed credentials.

    Usage::

        ns = NetSuiteClient()
        accounts = ns.suiteql("SELECT id, fullname FROM account")
        je_id = ns.create_record("journalentry", {...})
        record = ns.get_record("journalentry", je_id)
    """

    def __init__(self, timeout: int = 60):
        self._timeout = timeout
        self._tok: NetSuiteToken | None = None

    def _ensure_token(self) -> NetSuiteToken:
        if self._tok is None:
            self._tok = get_token()
        return self._tok

    def _headers(self) -> dict[str, str]:
        tok = self._ensure_token()
        return {
            "Authorization": f"Bearer {tok.access_token}",
            "Content-Type": "application/json",
        }

    @property
    def account_id(self) -> str:
        return self._ensure_token().account_id

    @property
    def base_url(self) -> str:
        return _base_url(self.account_id)

    # ── SuiteQL ──────────────────────────────────────────────────────────

    def suiteql(
        self, query: str, *, limit: int = 1000, all_pages: bool = True
    ) -> list[dict[str, Any]]:
        """Execute a SuiteQL query. See module-level :func:`suiteql`."""
        return suiteql(query, limit=limit, all_pages=all_pages, timeout=self._timeout)

    # ── REST Record API ──────────────────────────────────────────────────

    def get_record(
        self, record_type: str, record_id: str | int, **params: Any
    ) -> dict[str, Any]:
        """GET a single record by type and ID."""
        url = f"{self.base_url}/services/rest/record/v1/{record_type}/{record_id}"
        resp = requests.get(url, headers=self._headers(), params=params, timeout=self._timeout)
        if not resp.ok:
            raise NetSuiteAPIError(resp.status_code, resp.text[:500])
        return resp.json()

    def create_record(self, record_type: str, body: dict[str, Any]) -> str:
        """POST a new record. Returns the internal ID from the Location header."""
        url = f"{self.base_url}/services/rest/record/v1/{record_type}"
        resp = requests.post(url, json=body, headers=self._headers(), timeout=self._timeout)
        if not resp.ok:
            raise NetSuiteAPIError(resp.status_code, resp.text[:500])
        location = resp.headers.get("Location", "")
        return location.rstrip("/").split("/")[-1] if location else str(resp.json().get("id", ""))

    def update_record(
        self, record_type: str, record_id: str | int, body: dict[str, Any]
    ) -> None:
        """PATCH an existing record."""
        url = f"{self.base_url}/services/rest/record/v1/{record_type}/{record_id}"
        resp = requests.patch(url, json=body, headers=self._headers(), timeout=self._timeout)
        if not resp.ok:
            raise NetSuiteAPIError(resp.status_code, resp.text[:500])

    def delete_record(self, record_type: str, record_id: str | int) -> None:
        """DELETE a record."""
        url = f"{self.base_url}/services/rest/record/v1/{record_type}/{record_id}"
        resp = requests.delete(url, headers=self._headers(), timeout=self._timeout)
        if not resp.ok:
            raise NetSuiteAPIError(resp.status_code, resp.text[:500])
