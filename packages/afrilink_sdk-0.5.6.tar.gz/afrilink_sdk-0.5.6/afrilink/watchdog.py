"""
AfriLink Session Watchdog

Monitors the CINECA SSH certificate expiry timer and alerts users
before their credentials expire (~12h validity). Also provides
session recovery and email notification for long-running jobs.

Features:
1. Background thread monitors cert expiry from authentication time
2. Warns user at configurable thresholds (e.g. 30min, 15min before expiry)
3. client.recover_session() re-authenticates and retrieves job status
4. Email notification when a job completes (runs as background check)
"""

import os
import time
import threading
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List, Callable

try:
    import requests as _requests
except ImportError:
    _requests = None
    import urllib.request
    import urllib.error
    import json as _json


# ── Default certificate validity (CINECA Smallstep certs) ──
# Smallstep issues 12h certs by default; previous 16h value was incorrect
DEFAULT_CERT_VALIDITY_HOURS = 12

# ── Warning thresholds (minutes before expiry) ──
DEFAULT_WARN_THRESHOLDS = [60, 30, 15, 5]


class SessionWatchdog:
    """
    Monitors SSH certificate expiry and alerts the user when
    re-authentication is needed.

    Started automatically after authenticate(). Runs a lightweight
    background thread that checks elapsed time against cert validity.
    """

    def __init__(
        self,
        cert_validity_hours: float = DEFAULT_CERT_VALIDITY_HOURS,
        warn_thresholds_minutes: List[int] = None,
        on_warning: Optional[Callable[[int], None]] = None,
    ):
        self._cert_validity_seconds = cert_validity_hours * 3600
        self._warn_thresholds = sorted(
            warn_thresholds_minutes or DEFAULT_WARN_THRESHOLDS, reverse=True
        )
        self._on_warning = on_warning

        self._auth_time: Optional[float] = None
        self._expiry_time: Optional[float] = None
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._warned_thresholds: set = set()
        self._lock = threading.Lock()

    def start(self, auth_time: float = None, expiry_iso: str = None):
        """
        Start watching. Call after successful CINECA authentication.

        Args:
            auth_time: Unix timestamp of authentication (default: now)
            expiry_iso: ISO datetime string of cert expiry (from step inspect)
        """
        self._auth_time = auth_time or time.time()

        if expiry_iso:
            try:
                exp_dt = datetime.fromisoformat(expiry_iso.replace("Z", "+00:00"))
                self._expiry_time = exp_dt.timestamp()
            except Exception:
                self._expiry_time = self._auth_time + self._cert_validity_seconds
        else:
            self._expiry_time = self._auth_time + self._cert_validity_seconds

        self._running = True
        self._warned_thresholds = set()
        self._thread = threading.Thread(target=self._watch_loop, daemon=True)
        self._thread.start()

    def stop(self):
        """Stop the watchdog."""
        self._running = False
        if self._thread:
            self._thread.join(timeout=5)

    @property
    def minutes_remaining(self) -> float:
        """Minutes until certificate expires."""
        if not self._expiry_time:
            return float("inf")
        return max(0, (self._expiry_time - time.time()) / 60)

    @property
    def is_expired(self) -> bool:
        """Whether the certificate has expired."""
        return self.minutes_remaining <= 0

    @property
    def is_running(self) -> bool:
        return self._running

    def _watch_loop(self):
        """Background loop that checks expiry and fires warnings."""
        while self._running:
            remaining = self.minutes_remaining

            for threshold in self._warn_thresholds:
                if remaining <= threshold and threshold not in self._warned_thresholds:
                    with self._lock:
                        self._warned_thresholds.add(threshold)
                    self._fire_warning(threshold, remaining)

            if remaining <= 0:
                self._fire_expired()
                self._running = False
                break

            # Sleep 30s between checks (lightweight)
            for _ in range(30):
                if not self._running:
                    break
                time.sleep(1)

    def _fire_warning(self, threshold: int, remaining: float):
        """Fire a warning about impending cert expiry."""
        mins = int(remaining)
        print(
            f"\n{'⚠' * 3}  SSH CERTIFICATE EXPIRY WARNING  {'⚠' * 3}\n"
            f"  Your CINECA SSH certificate expires in ~{mins} minutes.\n"
            f"  Run  client.recover_session()  to re-authenticate and\n"
            f"  preserve your running jobs.\n"
        )
        if self._on_warning:
            try:
                self._on_warning(mins)
            except Exception:
                pass

    def _fire_expired(self):
        """Fire notification that cert has expired."""
        print(
            f"\n{'🔴' * 3}  SSH CERTIFICATE EXPIRED  {'🔴' * 3}\n"
            f"  Your CINECA SSH certificate has expired.\n"
            f"  Run  client.recover_session()  to re-authenticate.\n"
            f"  Your SLURM jobs continue running on the cluster —\n"
            f"  you just need fresh credentials to check on them.\n"
        )


class EmailNotifier:
    """
    Sends email notifications when jobs complete.

    Uses the Supabase Edge Function (or direct SMTP relay) to send
    an email to the user's registered DataSpires address when their
    job finishes. This is a background check — the user doesn't need
    to stay connected.
    """

    # Supabase Edge Function for email (deployed separately)
    DEFAULT_EMAIL_FUNCTION_URL = None  # Set when deployed

    def __init__(
        self,
        supabase_url: str = None,
        supabase_key: str = None,
        access_token: str = None,
    ):
        self._supabase_url = supabase_url or "https://plxdnhrdiqqaiyiljzfm.supabase.co"
        self._supabase_key = supabase_key
        self._access_token = access_token

    def _request(self, method: str, url: str, data: dict, headers: dict) -> bool:
        """Send a JSON request. Returns True on success."""
        try:
            if _requests:
                resp = _requests.request(method, url, json=data, headers=headers, timeout=15)
                return resp.status_code < 400
            else:
                req = urllib.request.Request(
                    url,
                    data=_json.dumps(data).encode("utf-8"),
                    headers=headers,
                    method=method,
                )
                with urllib.request.urlopen(req, timeout=15):
                    return True
        except Exception:
            return False

    def _request_post(self, url: str, data: dict, headers: dict) -> bool:
        return self._request("POST", url, data, headers)

    def request_job_completion_email(
        self,
        user_email: str,
        job_id: str,
        slurm_job_id: str,
        model: str,
    ) -> bool:
        """
        Register a request for an email when the job completes.

        Writes a row to the `email_notifications` table in Supabase.
        When the job finishes, call update_job_status() to set the row
        to "completed"/"failed". A Supabase Edge Function then sends
        the email.

        If the table doesn't exist yet, this gracefully fails with
        a console message — the feature is opt-in and non-blocking.

        Args:
            user_email: Destination email address
            job_id: AfriLink job ID
            slurm_job_id: SLURM numeric job ID
            model: Model name (for the email body)

        Returns:
            True if the notification request was registered
        """
        url = f"{self._supabase_url}/rest/v1/email_notifications"
        headers = {
            "apikey": self._supabase_key or "",
            "Authorization": f"Bearer {self._access_token or self._supabase_key or ''}",
            "Content-Type": "application/json",
            "Prefer": "return=minimal",
        }
        data = {
            "user_email": user_email,
            "job_id": job_id,
            "slurm_job_id": slurm_job_id,
            "model": model,
            "status": "pending",
            "requested_at": datetime.utcnow().isoformat() + "Z",
        }

        ok = self._request_post(url, data, headers)
        if ok:
            print(f"  Email notification registered for {user_email}")
            print(f"  You'll receive an email when job {job_id} completes.")
        else:
            # Non-fatal — the email_notifications table may not exist yet
            print(f"  Email notification: not available (table may need setup)")
            print(f"  Job {job_id} will continue running on the cluster.")
        return ok

    def update_job_status(
        self,
        job_id: str,
        status: str,
        elapsed: str = None,
    ) -> bool:
        """
        Update the email_notifications row when a job finishes.

        The Edge Function picks up rows with status "completed"/"failed"
        and sends the email. This avoids any need for SSH proxying.

        Args:
            job_id: AfriLink job ID
            status: Final status — "completed" or "failed"
            elapsed: SLURM elapsed time string (e.g. "01:23:45")

        Returns:
            True if the row was updated
        """
        url = f"{self._supabase_url}/rest/v1/email_notifications?job_id=eq.{job_id}&status=eq.pending"
        headers = {
            "apikey": self._supabase_key or "",
            "Authorization": f"Bearer {self._access_token or self._supabase_key or ''}",
            "Content-Type": "application/json",
            "Prefer": "return=minimal",
        }
        data = {"status": status}
        if elapsed:
            data["elapsed"] = elapsed

        return self._request("PATCH", url, data, headers)


class JobRecoveryInfo:
    """
    Container for recovery information returned by recover_session().
    """

    def __init__(self):
        self.re_authenticated: bool = False
        self.jobs: Dict[str, Dict[str, Any]] = {}
        self.files_retrieved: List[str] = []
        self.email_requested: bool = False

    def __repr__(self):
        lines = ["\n=== Session Recovery Report ==="]
        lines.append(f"  Re-authenticated: {'Yes' if self.re_authenticated else 'No'}")
        if self.jobs:
            lines.append(f"  Jobs found: {len(self.jobs)}")
            for jid, info in self.jobs.items():
                lines.append(f"    {jid}: {info.get('status', 'unknown')}")
        if self.files_retrieved:
            lines.append(f"  Files retrieved: {len(self.files_retrieved)}")
            for f in self.files_retrieved:
                lines.append(f"    {f}")
        if self.email_requested:
            lines.append(f"  Email notification: registered")
        return "\n".join(lines)
