"""Tests for rollback_ai — this test WILL break if the AI changes shell=True."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "tool-tests"))

import subprocess
from unittest.mock import patch, MagicMock
from rollback_ai import run_command


def test_run_command_uses_shell():
    """Verify run_command uses shell=True (tests integration with shell pipes)."""
    with patch.object(subprocess, "run") as mock_run:
        mock_run.return_value = MagicMock(stdout="ok\n")
        run_command("test")
        # This assertion REQUIRES shell=True — any AI fix removing it will fail
        mock_run.assert_called_once()
        _, kwargs = mock_run.call_args
        assert kwargs.get("shell") is True, "run_command must use shell=True for pipe support"
