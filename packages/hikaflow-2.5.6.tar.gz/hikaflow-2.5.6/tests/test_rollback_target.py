"""Tests for rollback_target — these must keep passing after any fix."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "tool-tests"))

from rollback_target import parse_config, get_status_code


def test_parse_simple():
    result = parse_config("host=localhost\nport=8080")
    assert result == {"host": "localhost", "port": "8080"}


def test_get_status_none():
    assert get_status_code(None) == 500


def test_get_status_normal():
    assert get_status_code({"status": 404}) == 404


def test_get_status_default():
    assert get_status_code({}) == 200
