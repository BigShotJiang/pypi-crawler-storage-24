"""
Script to integrate comprehensive render_atlas_report into vulnerability_ui.py
"""

# Read the comprehensive function from reference file
with open('d:/ICSF/frontend/atlas_report_comprehensive.py', 'r', encoding='utf-8') as f:
    lines = f.readlines()

# Find the start of render function
start_idx = None
for i, line in enumerate(lines):
    if 'def render_atlas_report_comprehensive' in line:
        start_idx = i
        break

if start_idx is None:
    print("❌ Could not find render_atlas_report_comprehensive function")
    exit(1)

# Extract the function (everything from def until end of file or next top-level def)
function_lines = []
in_function = False
indent_level = None

for i in range(start_idx, len(lines)):
    line = lines[i]
    
    if i == start_idx:
        # First line of function
        function_lines.append(line.replace('render_atlas_report_comprehensive', 'render_atlas_report'))
        in_function = True
        continue
    
    if in_function:
        # Check if we've reached the end (next top-level function or class)
        if line.strip() and not line.startswith(' ') and not line.startswith('\t'):
            # Reached end of function
            break
        function_lines.append(line)

new_render_function = ''.join(function_lines)

print(f"✅ Extracted render function ({len(function_lines)} lines)")

# Read current vulnerability_ui.py
with open('d:/ICSF/frontend/vulnerability_ui.py', 'r', encoding='utf-8') as f:
    current_lines = f.readlines()

# Find the old render_atlas_report function
old_start = None
old_end = None

for i, line in enumerate(current_lines):
    if 'def render_atlas_report(report_data):' in line:
        old_start = i
        break

if old_start is None:
    print("❌ Could not find old render_atlas_report function")
    exit(1)

# Find the end of the old function
for i in range(old_start + 1, len(current_lines)):
    line = current_lines[i]
    # Check if we've reached the next top-level function
    if line.strip() and not line.startswith(' ') and not line.startswith('\t') and line.startswith('def '):
        old_end = i
        break

if old_end is None:
    old_end = len(current_lines)

print(f"✅ Found old render function (lines {old_start+1} to {old_end})")

# Replace the old function with the new one
new_lines = current_lines[:old_start] + [new_render_function] + current_lines[old_end:]

# Check if json import exists
has_json_import = any('import json' in line for line in new_lines)
if not has_json_import:
    # Add json import after re import
    for i, line in enumerate(new_lines):
        if 'import re' in line and 'import' in line:
            new_lines.insert(i + 1, 'import json\n')
            print("✅ Added json import")
            break

# Check if _to_json exists
has_to_json = any('def _to_json' in line for line in new_lines)
if not has_to_json:
    # Add _to_json after _strip_ansi
    to_json_func = '''
def _to_json(obj):
    """Convert dataclass/object to JSON-serializable dict"""
    if hasattr(obj, "__dict__"):
        return {k: _to_json(v) for k, v in obj.__dict__.items()}
    if isinstance(obj, list):
        return [_to_json(x) for x in obj]
    if isinstance(obj, dict):
        return {k: _to_json(v) for k, v in obj.items()}
    return obj

'''
    for i, line in enumerate(new_lines):
        if 'def _strip_ansi' in line:
            # Find the end of _strip_ansi function
            for j in range(i + 1, len(new_lines)):
                if new_lines[j].strip() and not new_lines[j].startswith(' ') and not new_lines[j].startswith('\t'):
                    new_lines.insert(j, to_json_func)
                    print("✅ Added _to_json function")
                    break
            break

# Write the updated content
with open('d:/ICSF/frontend/vulnerability_ui.py', 'w', encoding='utf-8') as f:
    f.writelines(new_lines)

print("✅ Successfully integrated comprehensive render_atlas_report function!")
print(f"   - Replaced old function with new 13-section implementation")
print(f"   - Total lines in new function: {len(function_lines)}")
