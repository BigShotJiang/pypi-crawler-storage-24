import streamlit as st
import pandas as pd
import json
import re
from typing import Any

# This is the comprehensive render_atlas_report function with all 13 sections
# To be integrated into vulnerability_ui.py

def _to_json(obj: Any) -> Any:
    """Convert dataclass/object to JSON-serializable dict"""
    if hasattr(obj, "__dict__"):
        return {k: _to_json(v) for k, v in obj.__dict__.items()}
    if isinstance(obj, list):
        return [_to_json(x) for x in obj]
    if isinstance(obj, dict):
        return {k: _to_json(v) for k, v in obj.items()}
    return obj


def render_atlas_report_comprehensive(report_data):
    """
    Comprehensive Atlas pipeline report with all 13 sections from original implementation.
    """
    if not report_data:
        st.warning("No Atlas report available.")
        return

    # Initialize report object from dict
    class Bag:
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                if isinstance(v, dict):
                    setattr(self, k, Bag(**v))
                elif isinstance(v, list):
                    setattr(self, k, [Bag(**x) if isinstance(x, dict) else x for x in v])
                else:
                    setattr(self, k, v)
        def get(self, k, default=None):
            return getattr(self, k, default)

    report = Bag(**report_data)

    # Helper for attribute access
    def _get(obj, attr, default=None):
        if obj is None: return default
        if isinstance(obj, dict): return obj.get(attr, default)
        return getattr(obj, attr, default)

    # Helper for ANSI stripping
    _ANSI_ESCAPE = re.compile(r"\x1b\[[0-9;]*m|\u001b\[[0-9;]*m")
    def _strip_ansi(text: str) -> str:
        return _ANSI_ESCAPE.sub("", text) if text else ""

    # Normalize report parts
    unit = _get(report, 'unit', Bag())
    coverage = _get(report, 'coverage', Bag())
    total = _get(unit, 'total', 0)
    failed = _get(unit, 'failed', 0)
    errors = _get(unit, 'errors', 0)
    passed = max(0, total - failed - errors)
    total_failed = failed + errors
    coverage_found = _get(coverage, 'jacoco_found', False)
    instruction_covered_pct = _get(coverage, 'instruction_covered_pct', 0.0)

    # ----- HEADER -----
    st.divider()
    st.markdown("## 📊 Pipeline Report")
    repo_col1, repo_col2 = st.columns([3, 1])
    with repo_col1:
        st.markdown(f"**Repository:** [{_get(report, 'repo_url', 'Unknown')}]({_get(report, 'repo_url', '#')})")
    with repo_col2:
        st.markdown(f"**Run ID:** `{_get(report, 'run_id', 'N/A')}`")
        duration = _get(report, 'duration_seconds', None)
        if duration:
            if duration < 60:
                d_str = f"{duration:.1f}s"
            else:
                m = int(duration // 60)
                s = int(duration % 60)
                d_str = f"{m}m {s}s"
            st.markdown(f"**Run Time:** `{d_str}`")

    # ----- KPI ROW -----
    pass_rate = (passed / total * 100) if total > 0 else 0.0
    gen_count = len(_get(report, 'generation', Bag()).get('generated_files', []))
    new_count = len(_get(report, 'generation', Bag()).get('new_tests', []))
    upd_count = len(_get(report, 'generation', Bag()).get('updated_tests', []))
    branch_pct = _get(coverage, 'branch_covered_pct', None)

    kpi1, kpi2, kpi3, kpi4, kpi5 = st.columns(5)
    with kpi1:
        st.metric("Build", "Passed" if _get(report, 'build', Bag()).get('ok') else "Failed", None)
    with kpi2:
        st.metric("Tests", total, f"{passed} passed" if total > 0 else None)
    with kpi3:
        st.metric("Pass rate", f"{pass_rate:.1f}%" if total > 0 else "—", f"{total_failed} failed" if total_failed > 0 else None)
    with kpi4:
        st.metric("Instruction coverage", f"{instruction_covered_pct:.1f}%" if coverage_found else "—", f"Branch: {branch_pct:.1f}%" if branch_pct is not None else None)
    with kpi5:
        st.metric("Generated unit tests", gen_count, f"{new_count} new, {upd_count} updated" if gen_count > 0 else None)

    # ----- EXECUTIVE SUMMARY -----
    build_verb = "succeeded" if _get(report, 'build', Bag()).get('ok') else "failed"
    test_verb = "all passed" if _get(unit, 'ok', False) else f"{total_failed} failed"
    summary_lines = [f"The pipeline **build {build_verb}**. ", f"Unit tests: **{test_verb}** ({total} total). "]
    if coverage_found and instruction_covered_pct is not None:
        summary_lines.append(f"Instruction coverage is **{instruction_covered_pct:.1f}%**" + (f", branch coverage **{branch_pct:.1f}%**." if branch_pct is not None else "."))
    else:
        summary_lines.append("Coverage data was not available for this run.")
    if _get(report, 'pr_url'):
        summary_lines.append(f" A [pull request]({report.pr_url}) was created.")
    if _get(report, 'quality_gate', None) and _get(report.quality_gate, 'release_recommendation', None):
        rec = report.quality_gate.release_recommendation
        if rec == "do_not_release":
            summary_lines.append(" **Release recommendation: Do not release.**")
        elif rec == "release_with_caution":
            summary_lines.append(" **Release recommendation: Release with caution.**")
        elif rec == "release_ready":
            summary_lines.append(" **Release recommendation: Release ready.**")
    st.info(" ".join(summary_lines))

    # ----- 1. REPOSITORY & CONFIGURATION -----
    st.markdown("### 1. Repository & configuration")
    st.caption("Project setup: repository, build system, languages, and pre-flight checks.")
    r1, r2 = st.columns(2)
    with r1:
        st.markdown("**Build & test stack**")
        facts = _get(report, 'facts', {})
        build_system = facts.get("build_system") or "—"
        languages = facts.get("languages", []) or []
        test_frameworks = facts.get("test_frameworks", []) or []
        sanity = _get(report, 'sanity', {})
        st.markdown(f"- Build system: `{build_system}`")
        st.markdown(f"- Languages: {', '.join(languages) or '—'}")
        st.markdown(f"- Test frameworks: {', '.join(test_frameworks) or '—'}")
        st.markdown(f"- Existing test files: **{sanity.get('existing_test_files', 0)}**")
    with r2:
        st.markdown("**Pre-flight checks**")
        repo_has_pom = sanity.get("repo_has_pom", False)
        st.markdown("✅ pom.xml found" if repo_has_pom else "❌ pom.xml not found")
        for check in sanity.get("sanity_checks", []):
            st.markdown(f"- {check}")

    # ----- 2. BUILD STATUS -----
    st.markdown("### 2. Build status")
    st.caption("Result of `mvn clean install`. If the build failed, key error lines and full output are shown below.")
    if _get(report, 'build', Bag()).get('ok'):
        st.success("Build completed successfully.")
        st.code(" ".join(_get(report.build, 'cmd', [])), language="bash")
    else:
        st.error("Build failed.")
        raw_output = _get(report.build, 'output_tail', None) or _get(report.build, 'stderr_tail', '')
        if raw_output:
            build_output = _strip_ansi(raw_output)
            all_error_lines = [line.strip() for line in build_output.splitlines() if line.strip() and re.search(r"ERROR|FAILURE|FAILED|Exception|error", line, re.IGNORECASE)]
            compilation_lines = [line for line in all_error_lines if ".java:" in line or "COMPILATION ERROR" in line or "Compilation failure" in line]
            key_lines = compilation_lines[:10] if compilation_lines else all_error_lines[-8:]
            if key_lines:
                st.markdown("**Key error messages (likely cause):**")
                for line in key_lines:
                    if len(line) < 500:
                        st.code(line, language=None)
            with st.expander("View full Maven build output (stdout + stderr)"):
                st.code(build_output, language=None)
        else:
            st.warning("No build output was captured.")

    # ----- 3. TEST EXECUTION -----
    st.markdown("### 3. Test execution")
    st.caption("Counts from the run **after** new tests were added.")
    if total > 0:
        t1, t2 = st.columns([1, 1])
        with t1:
            st.markdown(f"- **Passed:** {passed}")
            st.markdown(f"- **Failed:** {failed}")
            st.markdown(f"- **Errors:** {errors}")
            if _get(unit, 'skipped', 0):
                st.markdown(f"- **Skipped:** {unit.skipped}")
        with t2:
            test_df = pd.DataFrame({"Status": ["Passed", "Failed", "Errors"], "Count": [passed, failed, errors]})
            st.bar_chart(test_df.set_index("Status")["Count"], color="#0ea5e9", height=220)
    else:
        st.info("No tests were executed (e.g. build failed or no tests found).")

    # ----- 4. CODE COVERAGE -----
    st.markdown("### 4. Code coverage")
    st.caption("JaCoCo instruction and branch coverage for this run.")
    if coverage_found and instruction_covered_pct is not None:
        c1, c2 = st.columns(2)
        with c1:
            st.markdown(f"**Instruction coverage: {instruction_covered_pct:.2f}%**")
            st.progress(instruction_covered_pct / 100.0)
            if instruction_covered_pct >= 80:
                st.success("Target coverage met (≥80%).")
            elif instruction_covered_pct >= 60:
                st.info("Moderate coverage; consider adding tests.")
            else:
                st.warning("Low coverage; prioritize tests for critical code.")
        with c2:
            if branch_pct is not None:
                st.markdown(f"**Branch coverage: {branch_pct:.2f}%**")
                st.progress(branch_pct / 100.0)
                if branch_pct >= 80:
                    st.success("Good branch coverage.")
                elif branch_pct >= 60:
                    st.info("Some branches uncovered.")
                else:
                    st.warning("Low branch coverage.")
            else:
                st.info("Branch coverage not available.")
    else:
        st.info("Coverage data was not produced.")

    # ----- 5. UNIT TEST GENERATION DETAILS -----
    st.markdown("### 5. Unit test generation details")
    st.caption("AI-generated unit tests. 'New' = created new file; 'Updated' = appended methods to existing test file.")
    gen = _get(report, 'generation', Bag())
    if _get(gen, 'generated_files'):
        new_list = _get(gen, 'new_tests', [])
        upd_list = _get(gen, 'updated_tests', [])
        tabs = st.tabs([f"Summary", f"New ({len(new_list)})", f"Updated ({len(upd_list)})"])
        
        with tabs[0]:
            if _get(gen, 'summary'):
                st.info(gen.summary)
            st.success(f"Total {len(gen.generated_files)} unit test files processed.")
            
        with tabs[1]:
            summaries = _get(gen, 'file_summaries', {})
            if new_list:
                for p in new_list:
                    s = summaries.get(p, {})
                    passed_t = s.get("passed", 0)
                    failed_t = s.get("failed", 0)
                    errors_t = s.get("errors", 0)
                    badge = f" :green[({passed_t} passed)] :red[({failed_t+errors_t} failed)]"
                    st.markdown(f"🆕 `{p}`{badge}")
            else:
                st.caption("No new test files created.")
                
        with tabs[2]:
            if upd_list:
                for p in upd_list:
                    s = summaries.get(p, {})
                    passed_t = s.get("passed", 0)
                    failed_t = s.get("failed", 0)
                    errors_t = s.get("errors", 0)
                    badge = f" :green[({passed_t} passed)] :red[({failed_t+errors_t} failed)]"
                    st.markdown(f"🆙 `{p}`{badge}")
            else:
                st.caption("No existing test files were updated.")
    else:
        st.info("No unit tests were generated or updated.")

    # ----- 6. BASELINE → AFTER → REGRESSION -----
    reg = _get(report, 'regression', None)
    if reg:
        st.markdown("### 6. Test results: Baseline → After → Regression")
        st.caption("Baseline = run before new tests. After = run with ALL tests. Regressions = tests that passed at baseline but failed after.")
        r1, r2, r3 = st.columns(3)
        with r1:
            st.markdown("**Baseline**")
            baseline_total = _get(reg, 'baseline_total', 0)
            baseline_passed = _get(reg, 'baseline_passed', 0)
            if baseline_total == 0 and not _get(report, 'build', Bag()).get('ok'):
                st.warning("Not run (build failed)")
            else:
                st.metric("Tests", baseline_total, f"{baseline_passed} passed")
        with r2:
            st.markdown("**After**")
            after_total = _get(reg, 'after_total', 0)
            after_passed = _get(reg, 'after_passed', 0)
            if after_total > 0:
                st.metric("Tests", after_total, f"{after_passed} passed")
                if not _get(reg, 'after_run_ok', True):
                    st.caption("(some tests failed)")
            else:
                st.error("Run did not complete")
        with r3:
            st.markdown("**Regressions**")
            regressions = _get(reg, 'regressions', [])
            n = len(regressions)
            st.metric("Regressions", n, "passed before, failed now" if n else "None")
        
        if not regressions and not _get(reg, 'new_failures', []) and after_total > 0:
            st.success("No regressions detected; baseline behavior preserved.")
        
        # Consolidated Failure Summary Log
        all_failures = []
        defects = _get(report, 'defects', None)
        defect_list = _get(defects, 'defects', []) if defects else []
        
        for key in regressions:
            reason = "No details found (existing test)."
            for d in defect_list:
                if d.get("test") == key.replace("#", "."):
                    reason = d.get("actual", reason)
                    break
            all_failures.append({"name": key.replace("#", "."), "type": "Regression", "reason": reason})
        
        for name in _get(reg, 'new_failures', []):
            reason = "No details found."
            for d in defect_list:
                if d.get("test") == name:
                    reason = d.get("actual", reason)
                    break
            all_failures.append({"name": name, "type": "New Test Failure", "reason": reason})
        
        if all_failures:
            st.markdown("#### 📝 Failure Summary Log")
            st.caption("Consolidated log of all test failures and their root causes.")
            for f in all_failures:
                with st.expander(f"FAILED: {f['name']} ({f['type']})"):
                    st.error("**Failure Reason:**")
                    st.code(f['reason'], language="text")

    # ----- 7. TEST STRATEGY -----
    strategy = _get(report, 'test_strategy', None)
    if strategy:
        st.markdown("### 7. Test strategy (QA)")
        st.caption("What was targeted and why — risk-based test design.")
        st.markdown(f"- **Low-coverage classes targeted:** {_get(strategy, 'targeted_low_coverage_classes', 0)}")
        st.info(_get(strategy, 'rationale', 'N/A'))

    # ----- 8. QUALITY GATE -----
    qg = _get(report, 'quality_gate', None)
    if qg:
        st.markdown("### 8. Quality gate — release readiness (QA)")
        st.caption("Pass/fail against configurable thresholds (sign-off).")
        st.metric("Result", "PASS" if _get(qg, 'passed', False) else "FAIL", None)
        rec = _get(qg, 'release_recommendation', None)
        if rec == "do_not_release":
            st.error("**Release recommendation: Do not release**")
        elif rec == "release_with_caution":
            st.warning("**Release recommendation: Release with caution**")
        elif rec == "release_ready":
            st.success("**Release recommendation: Release ready**")
        for r in _get(qg, 'reasons', []):
            st.markdown(f"- {r}")

    # ----- 9. DEFECT REPORT -----
    defects = _get(report, 'defects', None)
    if defects and _get(defects, 'defects'):
        st.markdown("### 9. Defect report (QA)")
        st.caption("Structured defects from test failures; GitHub issues created if enabled.")
        for d in defects.defects[:15]:
            with st.expander(f"{d.get('title', '')[:60]} — {d.get('severity', '')}"):
                st.markdown(f"**Test:** `{d.get('test', '')}`")
                st.markdown("**Steps:**")
                st.markdown(d.get("steps", ""))
                st.markdown(f"**Expected:** {d.get('expected', '')}")
                st.markdown(f"**Actual:** {d.get('actual', '')[:500]}")
        if _get(defects, 'github_issues_created'):
            st.success(f"**GitHub issues created:** {len(defects.github_issues_created)}")
            for u in defects.github_issues_created[:5]:
                st.markdown(f"- [{u}]({u})")

    # ----- 10. SECURITY SCAN -----
    security = _get(report, 'security', None)
    if security and _get(security, 'run'):
        st.markdown("### 10. Security scan (QA)")
        st.caption("Dependency tree and optional OWASP dependency-check.")
        st.markdown(_get(security, 'summary', ''))
        if _get(security, 'vulnerabilities'):
            for v in security.vulnerabilities[:15]:
                sev = v.get("severity", "unknown")
                st.markdown(f"**{sev}:** `{v.get('cve', '')[:120]}`")

    # ----- 11. FAILURE & GAP ANALYSIS -----
    st.markdown("### 11. Failure & gap analysis")
    st.caption("Classified build failures, test failures, runtime exceptions, and coverage gaps.")
    breakage = _get(report, 'breakage', None)
    has_failures = (
        _get(breakage, 'build_failures') or
        _get(breakage, 'test_failures') or
        _get(breakage, 'runtime_exceptions') or
        _get(breakage, 'coverage_gaps') or
        not _get(report, 'build', Bag()).get('ok')
    )
    if not has_failures:
        st.success("No failures or gaps detected; build and tests passed.")
    else:
        if _get(breakage, 'build_failures'):
            st.error("**Build failures**")
            for m in breakage.build_failures:
                st.code(_strip_ansi(m), language=None)
        elif not _get(report, 'build', Bag()).get('ok'):
            st.error("**Build failures** — see section 2 for details.")
        if _get(breakage, 'test_failures'):
            st.warning("**Test failures**")
            for m in breakage.test_failures:
                st.markdown(f"- {m}")
        if _get(breakage, 'runtime_exceptions'):
            st.error("**Runtime exceptions**")
            for m in breakage.runtime_exceptions:
                st.markdown(f"- {m}")
        if _get(breakage, 'coverage_gaps'):
            st.info("**Coverage gaps** (classes or areas with low coverage)")
            for m in breakage.coverage_gaps[:15]:
                st.markdown(f"- {m}")

    # ----- 12. CLASS-LEVEL COVERAGE -----
    per_class = _get(coverage, 'per_class', [])
    if per_class:
        st.markdown("### 12. Class-level coverage")
        st.caption("Per-class instruction and branch coverage. Lowest-covered classes are good candidates for new tests.")
        low = sorted(per_class[:25], key=lambda c: c.get("instruction_covered_pct") or 0.0)[:10]
        if low:
            chart_data = []
            for cls in low:
                inst = cls.get("instruction_covered_pct") or 0.0
                branch = cls.get("branch_covered_pct") or 0.0
                name = cls.get("class") or "N/A"
                chart_data.append({"Class": name, "Instruction %": inst, "Branch %": branch})
            df = pd.DataFrame(chart_data)
            st.bar_chart(df.set_index("Class")[["Instruction %", "Branch %"]], height=320)
            with st.expander("Detailed coverage table"):
                rows = []
                for cls in per_class[:25]:
                    pkg = cls.get("package", "N/A")
                    cl = cls.get("class", "N/A")
                    inst = cls.get("instruction_covered_pct")
                    br = cls.get("branch_covered_pct")
                    rows.append({
                        "Package": pkg,
                        "Class": cl,
                        "Instruction %": f"{inst:.2f}%" if inst is not None else "N/A",
                        "Branch %": f"{br:.2f}%" if br is not None else "N/A",
                    })
                st.dataframe(pd.DataFrame(rows), width='stretch', hide_index=True)

    # ----- PR LINK -----
    if _get(report, 'pr_url'):
        st.success(f"**Pull request created:** [{report.pr_url}]({report.pr_url})")

    # ----- 13. RAW JSON -----
    with st.expander("Raw report (JSON)"):
        st.code(json.dumps(_to_json(report), indent=2))
