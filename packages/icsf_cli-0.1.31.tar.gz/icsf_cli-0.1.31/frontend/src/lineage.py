
import streamlit.components.v1 as components
import json
import networkx as nx

def render_interactive_lineage(batch_results):
    """
    Renders an interactive lineage graph using Vis.js.
    Nodes expand/show details on hover.
    """
    
    # 1. Prepare Data
    nodes = []
    edges = []
    
    # Helper to add nodes with specific styles and Hierarchy Level
    def add_node(id, label, type, details, group, level):
        # Color schema
        colors = {
            'vuln': {'background': '#ef4444', 'border': '#dc2626', 'font': {'color': 'white'}},
            'fix': {'background': '#3b82f6', 'border': '#2563eb', 'font': {'color': 'white'}},
            'file': {'background': '#1e293b', 'border': '#334155', 'font': {'color': '#f8fafc'}},
            'test': {'background': '#10b981', 'border': '#059669', 'font': {'color': 'white'}},
            'pr': {'background': '#8b5cf6', 'border': '#7c3aed', 'font': {'color': 'white'}}
        }
        
        # HTML for tooltip (hover detail)
        title_html = f"""
        <div style='background: #1e293b; padding: 12px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.1); max-width: 300px; color: #f8fafc; font-family: sans-serif; box-shadow: 0 10px 15px -3px rgba(0,0,0,0.3);'>
            <div style='color: #94a3b8; font-size: 0.75rem; font-weight: 700; text-transform: uppercase; margin-bottom: 4px;'>{type.upper()}</div>
            <div style='font-size: 0.95rem; line-height: 1.5; color: #f8fafc;'>{details}</div>
        </div>
        """
        
        nodes.append({
            'id': id,
            'label': label,
            'title': title_html,  # This works as a tooltip in Vis.js
            'group': group,
            'level': level, # Explicit level for hierarchical layout
            'color': colors.get(group, {'background': '#334155', 'border': '#475569'}),
            'shape': 'box',
            'font': {'multi': 'html', 'size': 14, 'color': colors.get(group, {}).get('font', {}).get('color', '#f8fafc')},
            'margin': 12,
            'borderWidth': 2,
            'shadow': {'enabled': True, 'color': 'rgba(0,0,0,0.2)', 'size': 5, 'x': 2, 'y': 2}
        })

    # 2. Build Graph from Results
    
    # A. PR Node (Root/End) - Level 4
    pr_result = batch_results.get('batch_pr_result', {})
    pr_id = "PR_BATCH"
    if pr_result and pr_result.get('success'):
        pr_num = pr_result.get('pr_number', 'N/A')
        pr_url = pr_result.get('pr_url', '#')
        pr_label = f"<b>PR #{pr_num}</b>\nBatch Fixes"
        pr_details = f"<b>Status:</b> Created<br><b>URL:</b> <a href='{pr_url}' target='_blank'>{pr_url}</a>"
    else:
        pr_label = "<b>PR Pending</b>\nBatch Fixes"
        pr_details = "<b>Status:</b> Not created yet or failed"
    
    add_node(pr_id, pr_label, "Pull Request", pr_details, "pr", 4)

    # B. Process Execution Flow
    results = batch_results.get('results', [])
    validation_tests = batch_results.get('validation_test_results', {})
    
    has_tests = validation_tests and not validation_tests.get('error')
    
    for i, res in enumerate(results):
        # 1. Vulnerability Node - Level 0
        vuln_id = f"V_{i}"
        
        # Robust extraction
        vuln_name = res.get('vulnerability') or "Unknown Vulnerability" 
        if isinstance(vuln_name, dict): # Handle edge case where it might be a dict
             vuln_name = vuln_name.get('name', 'Unknown')
             
        file_path = res.get('file_path') or res.get('file', 'Unknown')
        severity = res.get('severity', 'High')
        
        # Details
        vuln_details = f"<b>Type:</b> {vuln_name}<br><b>Severity:</b> {severity}<br><b>File:</b> {file_path}"
        
        # Better Label
        vuln_label = f"<b>Vuln {i+1}</b>\n{vuln_name[:20]}..."
        add_node(vuln_id, vuln_label, "Vulnerability", vuln_details, "vuln", 0)
        
        # 2. Fix Node - Level 1
        fix_id = f"F_{i}"
        status = res.get('status', 'unknown')
        
        if status == 'success':
            fix_result = res.get('result', {})
            # Code Fix details
            code_fix = fix_result.get('code_fix', {})
            files_modified = code_fix.get('files_modified', [])
            
            # Label
            fix_label = f"<b>Fix {i+1}</b>\nAI Agent"
            fix_details = f"<b>Status:</b> Success<br><b>Files Modified:</b> {len(files_modified)}"
            add_node(fix_id, fix_label, "Fix Logic", fix_details, "fix", 1)
            
            # Edge: Vuln -> Fix
            edges.append({'from': vuln_id, 'to': fix_id, 'arrows': 'to', 'label': 'Triggered'})
            
            # 3. Modified File Nodes - Level 2
            # Create distinct file nodes for clarity as requested
            for f_idx, f_path in enumerate(files_modified):
                # Unique ID per fix to show flow
                f_node_id = f"FILE_{i}_{f_idx}" 
                f_name = f_path.split('/')[-1] if '/' in f_path else f_path
                
                f_details = f"<b>Path:</b> {f_path}<br><b>Modified by:</b> Fix {i+1}"
                f_label = f"<b>File</b>\n{f_name}"
                
                add_node(f_node_id, f_label, "Modified File", f_details, "file", 2)
                
                # Edge: Fix -> File
                edges.append({'from': fix_id, 'to': f_node_id, 'arrows': 'to', 'label': 'Modifies'})
                
                # Edge: File -> Next Stage (Test or PR)
                if has_tests:
                    edges.append({'from': f_node_id, 'to': "TEST_BATCH", 'arrows': 'to', 'dashes': True})
                else:
                    edges.append({'from': f_node_id, 'to': pr_id, 'arrows': 'to', 'dashes': True})

        else:
            # Failed Fix
            error = res.get('error', 'Unknown Error')
            add_node(fix_id, f"<b>Fix {i+1}</b>\n❌ Failed", "Fix Failed", f"<b>Error:</b> {error}", "fix", 1)
            edges.append({'from': vuln_id, 'to': fix_id, 'arrows': 'to', 'label': 'Failed'})

    # C. Global Test Node - Level 3
    if has_tests:
        test_id = "TEST_BATCH"
        report = validation_tests.get('report', {})
        summary = report.get('summary', {})
        
        passed = summary.get('tests_passed', 0)
        total = summary.get('tests_total', 0)
        
        test_label = f"<b>Validation</b>\nPass: {passed}/{total}"
        test_details = f"<b>Total Tests:</b> {total}<br><b>Passed:</b> {passed}"
        
        # Add Test Node
        add_node(test_id, test_label, "Validation Tests", test_details, "test", 3)
        
        # Link Test -> PR
        edges.append({'from': test_id, 'to': pr_id, 'arrows': 'to', 'label': 'Verified'})

    # 3. Vis.js HTML Template
    # This embeds the graph + logic to handle hover/click
    html_code = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <script type="text/javascript" src="https://unpkg.com/vis-network/standalone/umd/vis-network.min.js"></script>
        <style type="text/css">
            #mynetwork {{ 
                width: 100%; 
                height: 600px; 
                border: 1px solid rgba(255, 255, 255, 0.05); 
                background: #0f172a; 
                border-radius: 12px; 
            }}
            div.vis-tooltip {{ 
                background-color: transparent !important; 
                border: none !important; 
                padding: 0 !important; 
                border-radius: 8px !important; 
                box-shadow: none !important;
            }}
        </style>
    </head>
    <body>
        <div id="mynetwork"></div>
        <script type="text/javascript">
            var nodes = new vis.DataSet({json.dumps(nodes)});
            var edges = new vis.DataSet({json.dumps(edges)});
            var container = document.getElementById('mynetwork');
            var data = {{ nodes: nodes, edges: edges }};
            var options = {{
                nodes: {{ 
                    borderWidth: 2, 
                    shadow: true, 
                    shape: 'box', 
                    margin: 12,
                    font: {{ color: '#f8fafc' }}
                }},
                edges: {{ 
                    width: 2, 
                    color: {{ color: '#475569', highlight: '#3b82f6', hover: '#60a5fa' }},
                    shadow: false, 
                    smooth: {{ type: 'cubicBezier', forceDirection: 'horizontal', roundness: 0.4 }} 
                }},
                layout: {{
                    hierarchical: {{
                        enabled: true,
                        direction: 'LR',
                        sortMethod: 'directed',
                        levelSeparation: 250,
                        nodeSpacing: 100,
                        treeSpacing: 200,
                        blockShifting: true,
                        edgeMinimization: true,
                        parentCentralization: true
                    }}
                }},
                physics: {{
                    enabled: false
                }},
                interaction: {{ hover: true, tooltipDelay: 100, navigationButtons: true, zoomView: true }}
            }};
            var network = new vis.Network(container, data, options);
        </script>
    </body>
    </html>
    """
    
    # Render in Streamlit
    components.html(html_code, height=620)

# Example Usage Data (for testing)
mock_results = {
    'results': [
        {
            'vulnerability': 'SQL Injection',
            'status': 'success',
            'result': {'code_fix': {'files_modified': ['UserDAO.java', 'Database.java']}}
        },
        {
            'vulnerability': 'XSS Reflected',
            'status': 'success',
            'result': {'code_fix': {'files_modified': ['LoginView.java']}}
        }
    ]
}

if __name__ == "__main__":
    import streamlit as st
    st.set_page_config(layout="wide")
    st.title("Interactive Lineage Graph")
    render_interactive_lineage(mock_results)

